package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.utils.Functions.{getDateDiff, timeToCustomTime2}
import com.sf.gis.scala.pns.utils.SparkUtils.{writeToHive, writeToHiveNoP}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer


/**
 * GIS-RDS-PNS 价值线路指标监控需求V1.4
 * 需求方：刘俊荣（ft80006349）
 * @author 徐游飞（01417347）
 * 任务ID：674359
 * 任务名称：价值线路执行率
 * git 未提交
 */
object GisEtaJiaZhiExecution {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def etaStdLineConfJiaZhi(spark: SparkSession) = {
    import spark.implicits._
    val query_sql =
      s"""
         |select
         |  std_id,
         |  src_deptcode,
         |  dest_deptcode,
         |  line_code,
         |  plan_time,
         |  vehicle,
         |  is_econ,
         |  update_time,
         |  delete_flag,
         |  b.value_time
         |FROM
         |  (
         |    SELECT
         |      std_id,
         |      src_deptcode,
         |      dest_deptcode,
         |      line_code,
         |      plan_time,
         |      vehicle,
         |      is_econ,
         |      update_time,
         |      delete_flag
         |    FROM
         |      dm_gis.eta_std_line_conf
         |    where
         |      is_econ = '0'
         |  ) as a
         |  left join (
         |    select
         |      std_id as si,
         |      value_time
         |    from
         |      dm_gis.eta_std_line_prop
         |  ) as b on a.std_id = b.si
         |""".stripMargin
    println("eta_std_line_conf表取数sql：")
    println(query_sql)

    val df_conf_jiazhi = spark.sql(query_sql)
      .withColumn("update_time_yyMMdd", timeToCustomTime2('update_time, lit("yyyy-MM-dd HH:mm:ss"), lit("yyyyMMdd")))
      .withColumn("value_time_yyMMdd", timeToCustomTime2('value_time, lit("yyyy-MM-dd HH:mm:ss"), lit("yyyyMMdd")))
      .withColumn("online_date", when('update_time_yyMMdd > "20230101", 'update_time_yyMMdd).otherwise("20230101"))
      .withColumn("online_date_1", when('value_time_yyMMdd > "20230101", 'value_time_yyMMdd).otherwise("20230101"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 结果表1保存至hive（不分区）
    val cols_conf = spark.sql("""select * from dm_gis.eta_std_line_conf_jiazhi limit 0""").schema.map(_.name).map(col)
    writeToHiveNoP(spark,df_conf_jiazhi.select(cols_conf: _*),"dm_gis.eta_std_line_conf_jiazhi")

    df_conf_jiazhi
  }

  def gisEtaStdlineAbnormalDailyResultJiaZhi(spark: SparkSession, dayBefore1: String) = {

    val start_date = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", 2)
    val end_date = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", -2)

    val query_sql =
      s"""
         |SELECT
         |  task_id,
         |  task_area_code,
         |  task_subid,
         |  conduct_type,
         |  line_code,
         |  vehicle_type,
         |  src,
         |  start_dept,
         |  end_dept,
         |  driver_id,
         |  driver_name,
         |  task_inc_day,
         |  error_type,
         |  sim1,
         |  sim5,
         |  vehicle_serial,
         |  inc_day
         |FROM
         |  dm_gis.gis_eta_stdline_abnormal_daily_result
         |  where inc_day >= '$start_date'
         |  and inc_day <= '$end_date'
         |  and task_inc_day >= '$start_date'
         |  and task_inc_day <= '$dayBefore1'
         |  and del_type = '0'
         |  and carrier_type = '0'
         |""".stripMargin
    println("gis_eta_stdline_abnormal_daily_result表取数sql：")
    println(query_sql)

    import spark.implicits._
    val df_abnormal_jiazhi = spark.sql(query_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_subid,'task_inc_day).orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .drop("rn")
      .withColumn("inc_day",lit('task_inc_day))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 结果表2保存至hive
    val cols_abnormal = spark.sql("""select * from dm_gis.gis_eta_stdline_abnormal_daily_result_jiazhi limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_abnormal_jiazhi.select(cols_abnormal: _*),Seq("inc_day"),"dm_gis.gis_eta_stdline_abnormal_daily_result_jiazhi")

    df_abnormal_jiazhi
  }

  // 切割获取linevehicle字段
  def getLinevehicle = udf((linemload: String) => {
    val linevehicle = new ArrayBuffer[String]()
    if(linemload != null && linemload.trim != ""){
      val arr = linemload.split("_")

      for(i <- 0 until arr.length-1){
        linevehicle.append(arr(i))
      }
    }
    linevehicle.mkString("_")
  })


  def etaStdJiaZhiTheoretical(spark: SparkSession) = {
    val result_new_sql =
      s"""
         |select
         |  concat_ws('_',linevehicle,mload) as linemload,
         |  linevehicle as linevehicle,
         |  std_id as std_id,
         |  linemload_std_miles1 as theoretical_mileage,
         |  linemload_std_miles3 as actual_mileage,
         |  linemload_std_cost1 as theoretical_cost,
         |  linemload_std_cost3 as actual_cost,
         |  linemload_std_road_fee1 as theoretical_tolls,
         |  linemload_std_road_fee3 as actual_tolls
         |from
         |  dm_gis.gis_eta_vl_result_new
         |where
         |  update_res = '{"result":{"code":"5","info":"完成字段更新"},"status":"0"}'
         |""".stripMargin

    val result_old_sql =
      s"""
         |select
         |  linemload as linemload,
         |  linevehicle as linevehicle,
         |  std_id as std_id,
         |  rt_dist as theoretical_mileage,
         |  avg_act_dist as actual_mileage,
         |  rt_cost as theoretical_cost,
         |  avg_act_cost as actual_cost,
         |  rt_tolls as theoretical_tolls,
         |  avg_act_toll as actual_tolls
         |from
         |  dm_gis.gis_eta_vl_result_old
         |where
         |  update_res = '{"result":{"code":"5","info":"完成字段更新"},"status":"0"}'
         |""".stripMargin

    val jzxl_dtl_sql =
      s"""
         |select
         |  linemload as linemload,
         |  linemload as linevehicle,
         |  '' as std_id,
         |  plan_dis as theoretical_mileage,
         |  avg_act_dist as actual_mileage,
         |  plan_allcost as theoretical_cost,
         |  avg_act_cost as actual_cost,
         |  plan_toll as theoretical_tolls,
         |  avg_act_toll as actual_tolls
         |from
         |  dm_gis.gis_eta_stdline_jzxl_dtl
         |""".stripMargin

    import spark.implicits._
    val df_result_new = spark.sql(result_new_sql)
      .groupBy("std_id")
      .agg(
        max('linemload) as "linemload",
        max('linevehicle) as "linevehicle",
        avg('theoretical_mileage) as "theoretical_mileage",
        avg('actual_mileage) as "actual_mileage",
        avg('theoretical_cost) as "theoretical_cost",
        avg('actual_cost) as "actual_cost",
        avg('theoretical_tolls) as "theoretical_tolls",
        avg('actual_tolls) as "actual_tolls"
      )
      .select("linemload","linevehicle","std_id","theoretical_mileage","actual_mileage","theoretical_cost","actual_cost","theoretical_tolls","actual_tolls")

    val df_result_old = spark.sql(result_old_sql)
      .groupBy("std_id")
      .agg(
        max('linemload) as "linemload",
        max('linevehicle) as "linevehicle",
        avg('theoretical_mileage) as "theoretical_mileage",
        avg('actual_mileage) as "actual_mileage",
        avg('theoretical_cost) as "theoretical_cost",
        avg('actual_cost) as "actual_cost",
        avg('theoretical_tolls) as "theoretical_tolls",
        avg('actual_tolls) as "actual_tolls"
      )
      .select("linemload","linevehicle","std_id","theoretical_mileage","actual_mileage","theoretical_cost","actual_cost","theoretical_tolls","actual_tolls")


    val df_jzxl_dtl = spark.sql(jzxl_dtl_sql).withColumn("linevehicle",getLinevehicle('linevehicle))
      .groupBy("linemload")
      .agg(
        max('std_id) as "std_id",
        max('linevehicle) as "linevehicle",
        avg('theoretical_mileage) as "theoretical_mileage",
        avg('actual_mileage) as "actual_mileage",
        avg('theoretical_cost) as "theoretical_cost",
        avg('actual_cost) as "actual_cost",
        avg('theoretical_tolls) as "theoretical_tolls",
        avg('actual_tolls) as "actual_tolls"
      )
      .select("linemload","linevehicle","std_id","theoretical_mileage","actual_mileage","theoretical_cost","actual_cost","theoretical_tolls","actual_tolls")


    val df_theoretical = df_result_new
      .union(df_result_old)
      .union(df_jzxl_dtl)
      .withColumn("diff_cost", 'theoretical_cost.cast("double") - 'actual_cost.cast("double"))
      .withColumn("diff_road_fee", 'theoretical_tolls.cast("double") - 'actual_tolls.cast("double"))
      .withColumn("diff_fuel", 'diff_cost.cast("double") - 'diff_road_fee.cast("double"))
      .withColumn("diff_dist", 'theoretical_mileage.cast("double") - 'actual_mileage.cast("double"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 结果表3保存至hive(不分区)
    val cols_theoretical = spark.sql("""select * from dm_gis.eta_std_jiazhi_theoretical limit 0""").schema.map(_.name).map(col)
    writeToHiveNoP(spark,df_theoretical.select(cols_theoretical: _*),"dm_gis.eta_std_jiazhi_theoretical")

    df_theoretical
  }

  def etaStdLineRecallJiaZhi(spark: SparkSession, dayBefore1: String) = {

    val start_date = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", 2)
    val end_date = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", -2)

    import spark.implicits._
    val recall_sql =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  carrier_name,
         |  concat_ws('_',line_code,start_dept,end_dept,vehicle_type) as linevehicle,
         |  concat_ws('_',line_code,start_dept,end_dept,vehicle_type,actual_capacity_load) as linemload,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  vehicle_type,
         |  axls_number,
         |  log_dist,
         |  duration,
         |  time,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  error_type,
         |  pns_dist,
         |  pns_time,
         |  src,
         |  line_distance_std,
         |  line_time_std,
         |  sim1,
         |  sim5,
         |  conduct_type,
         |  ac_is_run_ontime_std,
         |  halfway_integrate_rate,
         |  std_id,
         |  task_inc_day,
         |  inc_day
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day >= '$start_date'
         |  and inc_day <= '$end_date'
         |  and task_inc_day >= '$start_date'
         |  and task_inc_day <= '$dayBefore1'
         |  and error_type = '0'
         |  and carrier_type = '0'
         |  and std_id in (
         |    select
         |      std_id
         |    from
         |      dm_gis.eta_std_line_conf_jiazhi
         |  )
         |""".stripMargin

    val df_recall = spark.sql(recall_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_subid,'task_inc_day).orderBy(desc("inc_day"))))
      .filter('rn === 1)
      .drop("rn")
      .withColumn("inc_day",lit('task_inc_day))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 结果表4(任务明细中间表)保存至hive
    val cols_recall = spark.sql("""select * from dm_gis.eta_std_line_recall_jiazhi limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_recall.select(cols_recall: _*),Seq("inc_day"),"dm_gis.eta_std_line_recall_jiazhi")

    df_recall
  }


  def etaStdLineRecallJiaZhi2(spark: SparkSession, dayBefore1: String, df_1: DataFrame, df_2: DataFrame, df_3: DataFrame, df_4: DataFrame) = {
    import spark.implicits._

    val df_3_tmp1 = df_3.select("std_id", "theoretical_cost", "diff_cost", "diff_road_fee", "diff_fuel", "diff_dist")
      .filter('std_id =!= "")
      .withColumn("flag3",lit("true"))
    val df_3_tmp2 = df_3.select("linemload", "theoretical_cost", "diff_cost", "diff_road_fee", "diff_fuel", "diff_dist")
      .filter('std_id === "")
      .withColumn("flag3",lit("true"))

    val df_join = df_4
      .join(df_1.select("std_id","online_date","online_date_1").distinct(),Seq("std_id"),"left")
      .join(df_2.select("task_subid","task_inc_day").withColumn("flag2",lit("true")).distinct(),Seq("task_subid","task_inc_day"),"left")
      .join(df_3_tmp1,Seq("std_id"), "left")

    val df_join_1 = df_join.filter('flag3 === "true")
      .select("task_area_code","task_id","line_code","carrier_name","task_subid","start_dept","end_dept","start_type","end_type","linevehicle","linemload","vehicle_serial","actual_depart_tm",
        "actual_arrive_tm","line_time","line_distance","actual_run_time","is_stop","transoport_level","vehicle_type","axls_number","rt_dist","highwaymileage","toll_charge",
        "error_type","pns_dist","pns_time","src","line_distance_std","line_time_std","sim1","sim5","conduct_type","ac_is_run_ontime_std","halfway_integrate_rate","std_id",
        "task_inc_day","inc_day","online_date","online_date_1","flag2","theoretical_cost","diff_cost","diff_road_fee","diff_fuel","diff_dist")

    val df_join_2 = df_join.filter('flag3.isNull)
      .drop("theoretical_cost", "diff_cost", "diff_road_fee", "diff_fuel", "diff_dist","flag3")
      .join(df_3_tmp2, Seq("linemload"), "left")
      .select("task_area_code","task_id","line_code","carrier_name","task_subid","start_dept","end_dept","start_type","end_type","linevehicle","linemload","vehicle_serial","actual_depart_tm",
        "actual_arrive_tm","line_time","line_distance","actual_run_time","is_stop","transoport_level","vehicle_type","axls_number","rt_dist","highwaymileage","toll_charge",
        "error_type","pns_dist","pns_time","src","line_distance_std","line_time_std","sim1","sim5","conduct_type","ac_is_run_ontime_std","halfway_integrate_rate","std_id",
        "task_inc_day","inc_day","online_date","online_date_1","flag2","theoretical_cost","diff_cost","diff_road_fee","diff_fuel","diff_dist")

    val df_join_all = df_join_1.union(df_join_2)
      .withColumn("date_diff",getDateDiff('task_inc_day,'online_date_1,lit("yyyyMMdd"),lit(0)).cast("double"))
      .withColumn("statistical_marker",when('date_diff >= -30 && 'date_diff <= 0,0)  //上线前一个月内
        .when('date_diff < -30,1) //上线前一个月外
        .when('date_diff >= 2,2) //需要统计上线后累积的数据
        .when('date_diff > 0 && 'date_diff < 2 ,3) //需要统计上线后累积的数据
      )
      .withColumn("task_type",when('flag2 === "true",1).otherwise(0))
      .withColumn("theoretical_cost",when('theoretical_cost.isNotNull,'theoretical_cost).otherwise(0))
      .withColumn("diff_cost",when('diff_cost.isNotNull,'diff_cost).otherwise(0))
      .withColumn("diff_road_fee",when('diff_road_fee.isNotNull,'diff_road_fee).otherwise(0))
      .withColumn("diff_fuel",when('diff_fuel.isNotNull,'diff_fuel).otherwise(0))
      .withColumn("diff_dist",when('diff_dist.isNotNull,'diff_dist).otherwise(0))
      .withColumn("inc_day",lit('task_inc_day))

    // 结果表4_1(任务明细表)保存至hive
    val cols_recall_jiazhi_1 = spark.sql("""select * from dm_gis.eta_std_line_recall_jiazhi_1 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_join_all.select(cols_recall_jiazhi_1: _*),Seq("inc_day"),"dm_gis.eta_std_line_recall_jiazhi_1")

  }

  def etaJiaZhiExeStatistics(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._

    // 取全量数据,inc_day小于跑数日期前一天
    val df_statistics = spark.sql(s"""select * from dm_gis.eta_std_line_recall_jiazhi_1 where inc_day <= '$dayBefore1'""")
      .groupBy("task_area_code", "line_code","vehicle_type","linevehicle","std_id","online_date_1")
      .agg(
        count(when('statistical_marker === 0 && 'conduct_type === 1 && 'task_type === 1, 'task_subid).otherwise(null)) as "online_before_exe",
        count(when('statistical_marker === 0 && 'task_type === 1, 'task_subid).otherwise(null)) as "online_before_task_num",
        count(when('statistical_marker === 2 && 'conduct_type === 1 && 'task_type === 1 && 'task_inc_day === dayBefore1, 'task_subid).otherwise(null)) as "online_after_exe",
        count(when('statistical_marker === 2 && 'task_type === 1 && 'task_inc_day === dayBefore1, 'task_subid).otherwise(null)) as "online_after_task_num",
        avg('diff_cost) as "diff_cost",
        avg('diff_road_fee) as "diff_road_fee",
        avg('diff_fuel) as "diff_fuel",
        avg('diff_dist) as "diff_dist"
      )
      .withColumn("online_before_exe_rate",when('online_before_task_num =!= 0,'online_before_exe / 'online_before_task_num).otherwise(0))
      .withColumn("online_after_exe_rate",when('online_after_task_num =!= 0,'online_after_exe / 'online_after_task_num).otherwise(0))
      .withColumn("diff_fluctuation",'online_before_exe_rate - 'online_after_exe_rate)
      .withColumn("inc_day", lit(dayBefore1))
      .filter('online_after_task_num =!= 0)
      .withColumn("online_date",lit(""))  //

    // 结果表5保存至hive
    val cols_statistics = spark.sql("""select * from dm_gis.eta_jiazhi_exe_statistics limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_statistics.select(cols_statistics: _*),Seq("inc_day"),"dm_gis.eta_jiazhi_exe_statistics")

  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始  ++++")
    // 价值线路配置表（结果表1）
    val df_1 = etaStdLineConfJiaZhi(spark)  // 全量数据，不分区
    // 剔除临时未执行问题表（结果表2）
    val df_2 = gisEtaStdlineAbnormalDailyResultJiaZhi(spark,dayBefore1)
    // 理论降本表（结果表3）
    val df_3 = etaStdJiaZhiTheoretical(spark)  // 全量数据，不分区
    // 价值线路任务明细表（结果表4）
    val df_4 = etaStdLineRecallJiaZhi(spark,dayBefore1)
    // 价值线路任务明细表（结果表4_1）
    etaStdLineRecallJiaZhi2(spark, dayBefore1, df_1, df_2, df_3, df_4)

    // 计算执行率统计表（结果表5）（每天更新跑数前三天数据，分别跑t-1,t-2,t-3）
    etaJiaZhiExeStatistics(spark, dayBefore3)
    etaJiaZhiExeStatistics(spark, dayBefore2)
    etaJiaZhiExeStatistics(spark, dayBefore1)

    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}