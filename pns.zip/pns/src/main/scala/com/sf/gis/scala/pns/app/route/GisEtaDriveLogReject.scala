package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.slf4j.LoggerFactory

import java.text.SimpleDateFormat
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

class GisEtaDriveLogReject extends Serializable {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

  /**
     * 取数dm_gis.gis_eta_jiazhi_cost
   *
   * @param spark SparkSession
     */
    def gis_eta_jiazhi_cost(spark: SparkSession): DataFrame = {
      spark.udf.register("get_before_day", get_min_date_before_30day _)

      // 结果表3关联配置表获取 value_date
//      val df_source = getValueDate(spark)
//      df_source.createOrReplaceTempView("source_table")

        val sql =
            s"""
               |select
               |    *
               |from
               |(
               |    select
               |        row_number() over(partition by task_id order by inc_day desc) rn,
               |        task_area_code,
               |        task_id,
               |        miles,
               |        road_fee,
               |        if(rt_dist > accrual_dist, rt_dist, accrual_dist) / 1000           as re_miles,
               |        miles / (if(rt_dist > accrual_dist, rt_dist, accrual_dist) / 1000) as miles_ratio,
               |        toll_charge                                                        as re_road_fee,
               |        if(toll_charge <= 1, 1, road_fee / toll_charge)                    as road_fee_ratio,
               |        grd1,
               |        inc_day,
               |        get_before_day(substr(value_date,0,10), 180)                                   as nday
               |    from dm_gis.gis_eta_jiazhi_cost_value_date
               |    where value_date is not null and value_date <> ''
               |) t
               |where rn = 1 and inc_day >= nday
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * udf: 计算online_date里最小日期往前推30天的日期，返回日期格式yyyyMMdd
     * @param online_date 用 | 拼接的日期字符串
     * @return
     */
    def get_min_date_before_30day(online_date: String, n: Int): String = {
        if (StringUtils.isEmpty(online_date)) {
            return ""
        }
        val splits = online_date.split("\\|")
        var date = "3000-01-01"
        for (split <- splits) {
            if (split < date) {
                date = split
            }
        }
      //DateUtil.getBeforeNDay(date.replace("-", ""), n)
      DateUtil.getDayBefore(date.replace("-", ""),"yyyyMMdd",n)
    }

    /**
     * 取分组聚合需要的维度字段
     * @param spark SparkSession
     * @return
     */
    def group_grd1_assign(spark: SparkSession): RDD[Row] = {
        val table1 = gis_eta_jiazhi_cost(spark)
        table1.createOrReplaceTempView("t1")
        val sql =
            s"""
               |select
               |    grd1,
               |    miles,
               |    miles_ratio,
               |    road_fee_ratio,
               |    road_fee
               |from t1
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql).rdd
    }

    /**
     * 对grd1分组求对应列的平均值、标准差等
     * @param spark SparkSession
     * @return
     */
    def group_grd1_assign_rdd(spark: SparkSession): DataFrame = {
        val sourceRDD = group_grd1_assign(spark)
        val finalRdd = sourceRDD
            .map(x => (if (x.isNullAt(0)) "" else x.getString(0),
                       if (x.isNullAt(1) || StringUtils.isEmpty(x.getString(1))) 0.0 else x.getString(1).toDouble,
                       if (x.isNullAt(2)) 0.0 else x.getDouble(2),
                       if (x.isNullAt(3)) 0.0 else x.getDouble(3),
                       if (x.isNullAt(4) || StringUtils.isEmpty(x.getString(4))) 0.0 else x.getString(4).toDouble
            ))
            .groupBy(x => x._1)
            .map(x => {
                val grd1 = x._1
                val milesArray = ArrayBuffer[Double]()
                val milesRatioArray = ArrayBuffer[Double]()
                val roadFeeRatioArray = ArrayBuffer[Double]()
                val roadFeeArray = ArrayBuffer[Double]()
                for (data <- x._2) {
                    milesArray.append(data._2)
                    milesRatioArray.append(data._3)
                    roadFeeRatioArray.append(data._4)
                    roadFeeArray.append(data._5)
                }
                // miles相关计算
                val miles_range = milesArray.max - milesArray.min
                val tuple1: (Double, Double) = get_standard_deviation_and_mean(milesArray)
                val miles_mean = tuple1._1
                val miles_mode = get_mode(milesArray)
                val miles_std = tuple1._2

                // miles_ratio相关计算
                val miles_ratio_mode = get_mode(milesRatioArray)
                val miles_ratio_std = get_standard_deviation_and_mean(milesRatioArray)._2

                // road_fee相关计算
                val road_fee_range = roadFeeArray.max - roadFeeArray.min
                val tuple2 = get_standard_deviation_and_mean(roadFeeArray)
                val road_fee_mean = tuple2._1
                val road_fee_mode = get_mode(roadFeeArray)
                val raod_fee_std = tuple2._2

                // road_fee_ratio相关计算
                val road_fee_ratio_mode = get_mode(roadFeeRatioArray)
                val road_fee_ratio_std = get_standard_deviation_and_mean(roadFeeRatioArray)._2

                (grd1, miles_range, miles_mean, miles_mode, miles_std, miles_ratio_mode, miles_ratio_std,
                    road_fee_range, road_fee_mean, road_fee_mode, raod_fee_std, road_fee_ratio_mode,
                    road_fee_ratio_std)
            })

        import spark.implicits._
        finalRdd.toDF("grd1", "miles_range", "miles_mean", "miles_mode", "miles_std",
            "miles_ratio_mode", "miles_ratio_std", "road_fee_range", "road_fee_mean", "road_fee_mode",
            "road_fee_std", "road_fee_ratio_mode", "road_fee_ratio_std")
    }

    /**
     * 求众数
     * @param array ArrayBuffer
     * @return
     */
    def get_mode(array: ArrayBuffer[Double]): Double = {
        val map = new mutable.HashMap[Double, Int]
        for (data <- array) {
            map.put(data, map.getOrElse(data, 0) + 1)
        }
        var ans: Double = 0
        var cnt = 0
        for ((key, value) <- map) {
            if (value > cnt) {
                ans = key
                cnt = value
            }
        }
        ans
    }

    /**
     * 求均值
     * @param array ArrayBuffer
     * @return
     */
    def get_mean(array: ArrayBuffer[Double]): Double = {
        var sum: Double = 0
        for (data <- array) {
            sum += data
        }
        sum / array.length
    }

    /**
     * 求标准差
     * @param array ArrayBuffer
     * @return
     */
    def get_standard_deviation_and_mean(array: ArrayBuffer[Double]): (Double, Double) = {
        val mean = get_mean(array)
        var variance: Double = 0
        for (data <- array) {
            variance += Math.pow(data - mean, 2)
        }
        (mean, Math.sqrt(variance / array.length))
    }

    /**
     * udf: 用于判读逻辑剔除字段
     * @param base base
     * @param base_range base_range
     * @param base_mean base_mean
     * @param base_mode base_mode
     * @param base_std base_std
     * @param base_ratio base_ratio
     * @param base_ratio_mode base_ratio_mode
     * @param base_ratio_std base_ratio_std
     * @return
     */
    def judge_flag(base: String,
                   base_range: Double,
                   base_mean: Double,
                   base_mode: Double,
                   base_std: Double,
                   base_ratio: Double,
                   base_ratio_mode: Double,
                   base_ratio_std: Double): Int = {
        if (StringUtils.isEmpty(base)) {
            return 1
        }
        val data = base.toDouble
        if (data == 0) {
            return 1
        }
        val f1 = (data < (base_mode - 3 * base_std)) || (data > (base_mode + 3 * base_std))
        val f2 = (base_ratio < (base_ratio_mode - 3 * base_ratio_std)) || (base_ratio > (base_ratio_mode + 3 * base_ratio_std))
        val f3 = base_range > 0.1 * base_mean
        if (f1 && f2 && f3) {
            return 2
        }
        0
    }

    def execute(spark: SparkSession): Unit = {
        val incDay = new SimpleDateFormat("yyyyMMdd").format(System.currentTimeMillis())
        val table2 = group_grd1_assign_rdd(spark)
        table2.createOrReplaceTempView("t2")
        spark.udf.register("judge_flag", judge_flag _)

        val sql =
            s"""
               |insert overwrite table dm_gis.gis_eta_drive_log_reject partition (inc_day = '$incDay')
               |select
               |    task_area_code,
               |    task_id,
               |    miles,
               |    road_fee,
               |    re_miles,
               |    miles_ratio,
               |    re_road_fee,
               |    road_fee_ratio,
               |    grd1,
               |    miles_range,
               |    miles_mean,
               |    miles_mode,
               |    miles_std,
               |    miles_ratio_mode,
               |    miles_ratio_std,
               |    miles_flag,
               |    road_fee_range,
               |    road_fee_mean,
               |    road_fee_mode,
               |    road_fee_std,
               |    road_fee_ratio_mode,
               |    road_fee_ratio_std,
               |    road_fee_flag,
               |    case when road_fee_flag = 0 and miles_flag = 0 then 0
               |         when road_fee_flag = 0 and miles_flag != 0 then miles_flag
               |         when road_fee_flag != 0 and miles_flag = 0 then road_fee_flag
               |         else concat(road_fee_flag, "|", miles_flag) end reject_flag,
               |    inc_day
               |from
               |(
               |    select
               |        t1.task_area_code,
               |        t1.task_id,
               |        t1.miles,
               |        t1.road_fee,
               |        t1.re_miles,
               |        t1.miles_ratio,
               |        t1.re_road_fee,
               |        t1.road_fee_ratio,
               |        t1.grd1,
               |        t2.miles_range,
               |        t2.miles_mean,
               |        t2.miles_mode,
               |        t2.miles_std,
               |        t2.miles_ratio_mode,
               |        t2.miles_ratio_std,
               |        judge_flag(t1.miles, t2.miles_range, t2.miles_mean, t2.miles_mode, t2.miles_std,
               |                    t1.miles_ratio, t2.miles_ratio_mode, t2.miles_ratio_std) as miles_flag,
               |        t2.road_fee_range,
               |        t2.road_fee_mean,
               |        t2.road_fee_mode,
               |        t2.road_fee_std,
               |        t2.road_fee_ratio_mode,
               |        t2.road_fee_ratio_std,
               |        judge_flag(t1.road_fee, t2.road_fee_range, t2.road_fee_mean, t2.road_fee_mode, t2.road_fee_std,
               |                    t1.road_fee_ratio, t2.road_fee_ratio_mode, t2.road_fee_ratio_std) as road_fee_flag,
               |        t1.inc_day
               |    from t1
               |    left join t2
               |    on t1.grd1 = t2.grd1
               |) t
               |""".stripMargin
      println(sql)
      spark.sql(sql)
      println("数据插入dm_gis.gis_eta_drive_log_reject完成")
    }
}

object GisEtaDriveLogReject {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaDriveLogReject
        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession
        task.execute(spark)
        spark.stop()
        task.LOGGER.info("任务执行完成")
    }
}
