package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.app.route.GisEtaJiazhiCostStatNew.gisEtaJiazhiCostStatNew
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

/**
 * GIS-RDS-PNS 价值线路指标监控需求V1.7
 * 需求方：刘思嘉（01420030）
 * @author 徐游飞（01417347）
 * 任务ID：674830
 * 任务名称：价值线路新增逻辑_6.1&6.2
 */
class GisEtaJiaZhiCostCompute {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    /**
     * 取数dm_gis.gis_eta_jiazhi_cost
     * @param spark SparkSession
     * @param incDay incDay
     * @return
     */
    def gis_eta_jiazhi_cost(spark: SparkSession, dayBefore1: String): DataFrame = {
        val sql =
            s"""
               |select
               |    *
               |from dm_gis.gis_eta_jiazhi_cost_new
               |where inc_day = '$dayBefore1' and task_inc_day in (
               |        select max(task_inc_day) task_inc_day
               |        from dm_gis.gis_eta_jiazhi_cost_new
               |        where inc_day = '$dayBefore1'
               |    )
               |""".stripMargin
        LOGGER.info(sql)
        val df_3_2 = spark.sql(sql)


        import spark.implicits._
        val value_date_sql =
            s"""
               |select
               |  std_id,
               |  substr(value_date,0,10) as value_date
               |from
               |  dm_gis.gis_eta_jiazhi_cost_value_date
               |where
               |  inc_day = '$dayBefore1'
               |""".stripMargin

        val df_value_date = spark.sql(value_date_sql)
          .withColumn("rn", row_number().over(Window.partitionBy('std_id).orderBy(asc("value_date"))))
          .filter('rn === 1)
          .drop("rn")
        val df_ret = df_3_2.join(df_value_date, Seq("std_id"), "left")
          .withColumn("online_date",'value_date)
        //
        df_ret
    }

    /**
     * 取数dm_gis.gis_eta_drive_log_reject
     * @param spark SparkSession
     * @return
     */
    def gis_eta_drive_log_reject(spark: SparkSession): DataFrame = {
        val sql =
            s"""
               |select
               |    task_id,
               |    miles_flag,
               |    road_fee_flag,
               |    reject_flag
               |from dm_gis.gis_eta_drive_log_reject
               |where inc_day in (select max(inc_day) inc_day from dm_gis.gis_eta_drive_log_reject)
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 取数dm_gis.gis_eta_jiazhi_cost_grd1
     * @param spark SparkSession
     * @return
     */
    def gis_eta_jiazhi_cost_grd1(spark: SparkSession, dayBefore1: String): DataFrame = {
        val sql =
            s"""
               |select
               |    grd1,
               |    cp_road_fee1,
               |    cp_fuel_cost1,
               |    cp_miles1,
               |    cp_sum_cost1,
               |    unexe_road_fee1,
               |    unexe_fuel_cost1,
               |    unexe_miles1,
               |    unexe_sum_cost1
               |from dm_gis.gis_eta_jiazhi_cost_grd1
               |where inc_day = '$dayBefore1'
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 取数dm_gis.gis_eta_jiazhi_cost_grd2
     * @param spark SparkSession
     * @return
     */
    def gis_eta_jiazhi_cost_grd2(spark: SparkSession, incDay: String): DataFrame = {
        val sql =
            s"""
               |select
               |    grd2,
               |    cp_road_fee2,
               |    cp_fuel_cost2,
               |    cp_miles2,
               |    cp_sum_cost2,
               |    unexe_road_fee2,
               |    unexe_fuel_cost2,
               |    unexe_miles2,
               |    unexe_sum_cost2
               |from dm_gis.gis_eta_jiazhi_cost_grd2
               |where inc_day = '$incDay'
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def execute(spark: SparkSession, dayBefore1: String): Unit = {
        // 获取hive源数据
        val table1 = gis_eta_jiazhi_cost(spark, dayBefore1)
        val table3 = gis_eta_jiazhi_cost_grd1(spark, dayBefore1)

        import spark.implicits._
        // 成本计算更新表55,优化更新统计逻辑
        val df_ret = table1.join(table3,Seq("grd1"),"left")
          .withColumn("road_fee_flag",when('road_fee_flag.isNotNull and 'road_fee_flag =!= "",'road_fee_flag)
            .when('road_fee.isNull or 'road_fee === "" or 'road_fee === 0,1)
            .otherwise(0))
          .withColumn("miles_flag",when('miles_flag.isNotNull and 'miles_flag =!= "",'miles_flag)
            .when('miles.isNull or 'miles === "" or 'miles === 0,1)
            .otherwise(0))
          .withColumn("diff_flag",when('unexe_sum_cost1.isNotNull and 'unexe_sum_cost1 =!= "" and 'unexe_sum_cost1 =!= 0,1)
            .when('cp_sum_cost1.isNotNull and 'cp_sum_cost1 =!= "" and 'cp_sum_cost1 =!= 0,2)
            .otherwise(null))
          .withColumn("reject_flag",when('reject_flag.isNotNull and 'reject_flag =!= "",'reject_flag)
            .when('road_fee_flag === 0 and 'miles_flag === 0,0)
            .when('road_fee_flag === 0 and 'miles_flag =!= 0,'miles_flag)
            .when('road_fee_flag =!= 0 and 'miles_flag === 0,'road_fee_flag)
            .otherwise(concat_ws("|",'road_fee_flag,'miles_flag)))
          .na.fill(0.0, Array("unexe_road_fee1", "cp_road_fee1","unexe_miles1","cp_miles1","unexe_fuel_cost1","cp_fuel_cost1","unexe_sum_cost1","cp_sum_cost1"))
          .withColumn("re_road_fee",when('unexe_road_fee1 === 0.0 and 'cp_road_fee1 =!= 0.0,'cp_road_fee1)
            .when('cp_road_fee1 === 0.0 and 'unexe_road_fee1 =!= 0.0,'unexe_road_fee1)
            .when('cp_road_fee1 =!= 0.0 and 'unexe_road_fee1 =!= 0.0,('unexe_road_fee1+'cp_road_fee1)/2)
            .otherwise(null))
          .withColumn("re_miles",when('unexe_miles1 === 0.0 and 'cp_miles1 =!= 0.0,'cp_miles1)
            .when('cp_miles1 === 0.0 and 'unexe_miles1 =!= 0.0,'unexe_miles1)
            .when('cp_miles1 =!= 0.0 and 'unexe_miles1 =!= 0.0,('unexe_miles1+'cp_miles1)/2)
            .otherwise(null))
          .withColumn("re_fuel_cost",when('unexe_fuel_cost1 === 0.0 and 'cp_fuel_cost1 =!= 0.0,'cp_fuel_cost1)
            .when('cp_fuel_cost1 === 0.0 and 'unexe_fuel_cost1 =!= 0.0,'unexe_fuel_cost1)
            .when('cp_fuel_cost1 =!= 0.0 and 'unexe_fuel_cost1 =!= 0.0,('unexe_fuel_cost1+'cp_fuel_cost1)/2)
            .otherwise(null))
          .withColumn("re_sum_cost",when('unexe_sum_cost1 === 0.0 and 'cp_sum_cost1 =!= 0.0,'cp_sum_cost1)
            .when('cp_sum_cost1 === 0.0 and 'unexe_sum_cost1 =!= 0.0,'unexe_sum_cost1)
            .when('cp_sum_cost1 =!= 0.0 and 'unexe_sum_cost1 =!= 0.0,('unexe_sum_cost1+'cp_sum_cost1)/2)
            .otherwise(null))
          .withColumn("task_flag",when('conduct_type === 1 and 'reject_flag === 0 and 'sum_cost.isNotNull and 'sum_cost =!= "" and ('diff_flag === 1 or 'diff_flag === 2),1)
            .when('conduct_type === 3,3)
            .when('conduct_type === 1 and 'reject_flag === 0 and 'sum_cost.isNotNull and 'sum_cost =!= "" and ('diff_flag === 3 or 'diff_flag === 4),2)
            .otherwise(0)
          )
          .withColumn("diff_road_fee",'road_fee - 're_road_fee)
          .withColumn("diff_fuel_cost",'fuel_cost - 're_fuel_cost)
          .withColumn("diff_miles",'miles - 're_miles)
          .withColumn("diff_sum_cost",'sum_cost - 're_sum_cost)
          .withColumn("cp_road_fee2",lit(""))
          .withColumn("cp_fuel_cost2",lit(""))
          .withColumn("cp_miles2",lit(""))
          .withColumn("cp_sum_cost2",lit(""))
          .withColumn("unexe_road_fee2",lit(""))
          .withColumn("unexe_fuel_cost2",lit(""))
          .withColumn("unexe_miles2",lit(""))
          .withColumn("unexe_sum_cost2",lit(""))
          .withColumn("online_date_1",'online_date)

        // 结果表保存至hive
        val cols = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_compute55 limit 0""").schema.map(_.name).map(col)
        writeToHive(spark,df_ret.select(cols: _*),Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_compute55")
        LOGGER.info("dm_gis.gis_eta_jiazhi_cost_compute表数据插入完成")
    }
}

object GisEtaJiaZhiCostCompute {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaJiaZhiCostCompute
        if (args == null || args.length != 1 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入参数")
            return
        }
        val dayBefore1 = DateUtil.getDayBefore(args(0), "yyyyMMdd", 1)
        task.LOGGER.info("#################################################")
        task.LOGGER.info("dayBefore1: [{}]", dayBefore1)
        task.LOGGER.info("#################################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession
        // 成本计算更新表55,优化更新统计逻辑
        task.execute(spark, dayBefore1)
        // 计算结果表6_1（每次更新跑数前三天的数据）
        gisEtaJiazhiCostStatNew(spark, dayBefore1)
        task.LOGGER.info("任务执行完成")
    }
}