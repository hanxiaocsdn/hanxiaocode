package com.sf.gis.scala.pns.app

import java.text.SimpleDateFormat
import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * @Description:路桥费账单信息统计
 * 需求人员：01425174 崔淑娴
 * @Author: lixiangzhi 01405644
 * @Date:20240104
 * 任务id:961116
 * 任务名称：RPMP服务调用量统计表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object RpmpServiceCallCnt {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def beeLogsGis(spark: SparkSession, incDay: String,endDay:String) = {
    import spark.implicits._
    val beeLogsSql=
      s"""
        |select
        |*
        |from dm_gis.bee_logs_gis_pns_mp_collect
        |where inc_day>='${incDay}' and inc_day<='$获取最大ownerid'
        |""".stripMargin
    val rpmpServiceCallDf: DataFrame = SparkUtils.getRowToJsonClear(spark, beeLogsSql,2000).map(obj => {
      val log: JSONObject = JSONUtil.getJsonObjectMulti(obj, "log")
      val message: JSONObject = JSONUtil.getJsonObjectMulti(log, "message")
      val appName: String = message.getString("appName")
      val dateTime: String = message.getString("dateTime")
      val sn: String = message.getString("sn")
      val typeStr: String = message.getString("type")
      val urlObj: JSONObject = JSONUtil.getJsonObjectMulti(message, "url")
      val ak: String = urlObj.getString("ak")
      val url: String = urlObj.getString("url")
      val starts: String = urlObj.getString("starts")
      val addressStarts: String = urlObj.getString("addressStarts")
      var starts_num = 0
      if (StringUtils.isNoneEmpty(starts)) {
        val startsArray: Array[String] = starts.split("\\|")
        starts_num = startsArray.size
      } else if (StringUtils.isNoneEmpty(addressStarts)) {
        val addressStartsArray: JSONArray = JSON.parseArray(addressStarts)
        starts_num = addressStartsArray.size
      }
      val ends: String = urlObj.getString("ends")
      val addressEnds: String = urlObj.getString("addressEnds")
      var ends_num = 0
      if (StringUtils.isNoneEmpty(ends)) {
        val endsArray: Array[String] = ends.split("\\|")
        ends_num = endsArray.size
      } else if (StringUtils.isNoneEmpty(addressEnds)) {
        val addressEndsArray: JSONArray = JSON.parseArray(addressEnds)
        ends_num = addressEndsArray.size
      }
      var diagonal: String = urlObj.getString("diagonal")
      if (StringUtils.isEmpty(diagonal)) {
        diagonal = "0"
      }
      val data: JSONObject = JSONUtil.getJsonObjectMulti(message, "data")
      val status: String = data.getString("status")
      var calls = 0
      if(status=="0" && diagonal=="0"){
        calls = starts_num * ends_num
      }else if(status=="0" && diagonal=="1"){
        calls = starts_num
      }
      obj.put("appName", appName)
      obj.put("dateTime", dateTime)
      obj.put("sn", sn)
      obj.put("ak", ak)
      obj.put("type", typeStr)
      obj.put("url", url)
      obj.put("starts_num", starts_num)
      obj.put("ends_num", ends_num)
      obj.put("diagonal", diagonal)
      obj.put("calls", calls)
      obj.put("status", status)
      obj
    }).map(obj => {
      CaseRpmpServiceCall(
        obj.getString("appName"),
        obj.getString("dateTime"),
        obj.getString("sn"),
        obj.getString("ak"),
        obj.getString("type"),
        obj.getString("url"),
        obj.getString("starts_num"),
        obj.getString("ends_num"),
        obj.getString("diagonal"),
        obj.getString("calls"),
        obj.getString("status"),
        obj.getString("inc_day")
      )
    }).toDF()
    SparkWrite.writeToHiveDynamic(spark,rpmpServiceCallDf,"inc_day","dm_gis.dm_pns_rpmp_service_call_cnt_di")
    //SparkWrite.writeToHive(spark,rpmpServiceCallDf,"inc_day",incDay,"dm_gis.dm_pns_rpmp_service_call_cnt_di")
  }

  def execute(incDay: String,endDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取表bee_logs_gis_pns_mp_collect表并解析
    beeLogsGis(spark, incDay,endDay)

    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val endDay: String = args(1)
    execute(incDay,endDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseRpmpServiceCall(
                                  appName:String,
                                  dateTime:String,
                                  sn:String,
                                  ak:String,
                                  typeStr:String,
                                  url:String,
                                  starts_num:String,
                                  ends_num:String,
                                  diagonal:String,
                                  calls:String,
                                  status:String,
                                  inc_day:String
                                )

}
