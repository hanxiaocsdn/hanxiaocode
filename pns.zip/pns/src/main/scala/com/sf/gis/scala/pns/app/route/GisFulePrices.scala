package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}

object GisFulePrices {
    def main(args: Array[String]): Unit = {
        val incDay = args(0)
//        val minDay = DateUtil.getBeforeNDay(incDay, -30)
//        val curMonth = DateUtil.getBeforeNMonth(incDay, 0)
//        val lastMonth = DateUtil.getBeforeNMonth(incDay, -1)

        val minDay = DateUtil.getDayBefore(incDay,"yyyyMMdd",30)
        val curMonth = DateUtil.getMouthBefore(incDay, 0)
        val lastMonth = DateUtil.getMouthBefore(incDay, 1)

        printf("incDay: %s, minDay: %s, curMonth: %s, lastMonth: %s", incDay, minDay, curMonth, lastMonth)
        val SparkInfo = SparkUtil.getSpark("GisFulePrices")
        val spark = SparkInfo.getSession

        val sql =
            s"""
               |with t1 as (
               |	select
               |		fuel_prices
               |	from
               |	(
               |		select
               |			fuel_prices,
               |            start_tm,
               |			row_number() over(partition by driving_log_item_id order by created_tm desc) rn
               |		from ods_vms.tt_vms_driving_log_item
               |		where task_id <> ''
               |			and task_id is not null
               |			and length(task_id) < 15
               |			and inc_month in ('$curMonth', '$lastMonth')
               |	) t
               |	where rn = 1 and date_format(start_tm, 'yyyyMMdd') >= '$minDay'
               |        and '$incDay' >= date_format(start_tm, 'yyyyMMdd')
               |)
               |insert into dm_gis.gis_fule_prices
               |select
               |    '$incDay',
               |	avg(fuel_prices) fuel_prices
               |from t1 where fuel_prices > 2
               |
               |""".stripMargin
        println("#################################################")
        println(sql)
        println("#################################################")
        spark.sql(sql)
        spark.stop()
    }
}
