package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.SparkUtil
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class GisEtaJiaZhiCostStat {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private lazy final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    /**
     * dm_gis.gis_eta_jiazhi_cost_compute取数
     * @param spark SparkSession
     * @param incDay incDay
     * @return
     */
    def gis_eta_jiazhi_cost_compute(spark: SparkSession, incDay: String): DataFrame = {
        spark.udf.register("get_min_day", new GisEtaDriveLogReject().get_min_date_before_30day _)
        LOGGER.info("udf函数注册")
        val sql =
            s"""
               |select
               |    *
               |from
               |(
               |select
               |    task_area_code,
               |    carrier_name,
               |    line_code,
               |    source,
               |    get_min_day(online_date, 0) as online_date,
               |    task_inc_day,
               |    conduct_type,
               |    reject_flag,
               |    task_id,
               |    cast(re_sum_cost as double) re_sum_cost,
               |    cast(re_road_fee as double) re_road_fee,
               |    cast(re_fuel_cost as double) re_fuel_cost,
               |    cast(re_miles as double) re_miles,
               |    cast(sum_cost as double) sum_cost,
               |    cast(road_fee as double) road_fee,
               |    cast(fuel_cost as double) fuel_cost,
               |    cast(miles as double) miles,
               |    cast(diff_sum_cost as double) diff_sum_cost,
               |    cast(diff_road_fee as double) diff_road_fee,
               |    cast(diff_fuel_cost as double) diff_fuel_cost,
               |    cast(diff_miles as double) diff_miles,
               |    diff_flag
               |from dm_gis.gis_eta_jiazhi_cost_compute
               |where inc_day = '$incDay'
               |) t
               |where task_inc_day >= online_date
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 分组计算
     * @param spark SparkSession
     * @param incDay incDay
     * @return
     */
    def group_calculate(spark: SparkSession, incDay: String): RDD[Cost] = {
        val rdd = gis_eta_jiazhi_cost_compute(spark, incDay).rdd
        LOGGER.info("=================>table转RDD")
        rdd
            .map(x => {
                val task_area_code = if (x.isNullAt(0)) "" else x.getString(0)
                val carrier_name = if (x.isNullAt(1)) "" else x.getString(1)
                val line_code = if (x.isNullAt(2)) "" else x.getString(2)
                val source = if (x.isNullAt(3)) "" else x.getString(3)
                val online_date = if (x.isNullAt(4)) "" else x.getString(4)
                val task_inc_day = if (x.isNullAt(5)) "" else x.getString(5)
                val conduct_type = if (x.isNullAt(6)) "" else x.getString(6)
                val reject_flag = if (x.isNullAt(7)) "" else x.getString(7)
                val task_id = if (x.isNullAt(8)) "" else x.getString(8)
                val re_sum_cost = if (x.isNullAt(9)) 0.0 else x.getDouble(9)
                val re_road_fee = if (x.isNullAt(10)) 0.0 else x.getDouble(10)
                val re_fuel_cost = if (x.isNullAt(11)) 0.0 else x.getDouble(11)
                val re_miles = if (x.isNullAt(12)) 0.0 else x.getDouble(12)
                val sum_cost = if (x.isNullAt(13)) Double.MinValue else x.getDouble(13)
                val road_fee = if (x.isNullAt(14)) 0.0 else x.getDouble(14)
                val fuel_cost = if (x.isNullAt(15)) 0.0 else x.getDouble(15)
                val miles = if (x.isNullAt(16)) 0.0 else x.getDouble(16)
                val diff_sum_cost = if (x.isNullAt(17)) 0.0 else x.getDouble(17)
                val diff_road_fee = if (x.isNullAt(18)) 0.0 else x.getDouble(18)
                val diff_fuel_cost = if (x.isNullAt(19)) 0.0 else x.getDouble(19)
                val diff_miles = if (x.isNullAt(20)) 0.0 else x.getDouble(20)
                val diff_flag = if (x.isNullAt(21)) "" else x.getString(21)
                Tuple22(task_area_code, carrier_name, line_code, source, online_date, task_inc_day, conduct_type,
                    reject_flag, task_id, re_sum_cost, re_road_fee, re_fuel_cost, re_miles, sum_cost,
                    road_fee, fuel_cost, miles, diff_sum_cost, diff_road_fee, diff_fuel_cost, diff_miles, diff_flag)
            })
            .groupBy(x => (x._1, x._2, x._3, x._4, x._5, x._6))
            .map(x => {
                val task_area_code = x._1._1
                val carrier_name = x._1._2
                val line_code = x._1._3
                val source = x._1._4
                val online_date = x._1._5
                val task_inc_day = x._1._6
                val line_num_sum = 1
                var line_num = 0
                var num_sum = 0
                var num = 0
                var reject_num = 0
                var re_cost_sum: Double = 0
                var re_road_fee_sum: Double = 0
                var re_fuel_cost_sum: Double = 0
                var re_miles_sum: Double = 0
                var cost_sum: Double = 0
                var road_fee_sum: Double = 0
                var fuel_cost_sum: Double = 0
                var miles_sum: Double = 0
                var diff_cost_sum: Double = 0
                var diff_road_fee_sum: Double = 0
                var diff_fuel_cost_sum: Double = 0
                var diff_miles_sum: Double = 0
                var cnt = 0
                for (data <- x._2) {
//                    if ("1".equals(data._7) && "0".equals(data._8) && Double.MinValue != data._14 && ("1".equals(data._22) || "2".equals(data._22))) {
                    if ("1".equals(data._7) && ("0".equals(data._8) || !nonEmpty(data._8)) && Double.MinValue != data._14 && ("1".equals(data._22) || "2".equals(data._22)) && data._18 <= 0) {
                        line_num = 1
                        num += 1
                        re_cost_sum += data._10
                        re_road_fee_sum += data._11
                        re_fuel_cost_sum += data._12
                        re_miles_sum += data._13
                        cost_sum += data._14
                        road_fee_sum += data._15
                        fuel_cost_sum += data._16
                        miles_sum += data._17
                        diff_cost_sum += data._18
                        diff_road_fee_sum += data._19
                        diff_fuel_cost_sum += data._20
                        diff_miles_sum += data._21
                        cnt += 1
                    }
//                    if ("1".equals(data._7) && (!"0".equals(data._8) || Double.MinValue == data._14 || "".equals(data._22) || "3".equals(data._22) || "4".equals(data._22))) {
                    if ("1".equals(data._7) && (("0".equals(data._8) || !nonEmpty(data._8)) || Double.MinValue == data._14 || "".equals(data._22) || "3".equals(data._22) || "4".equals(data._22) || data._18 > 0)) {
                        reject_num += 1
                    }
                    num_sum += 1
                }
                val re_cost_mean = if (num != 0) re_cost_sum / cnt else 0
                val re_road_fee_mean = if (num != 0) re_road_fee_sum / cnt else 0
                val re_fuel_cost_mean = if (num != 0) re_fuel_cost_sum / cnt else 0
                val re_miles_mean = if (num != 0) re_miles_sum / cnt else 0
                val cost_mean = if (num != 0) cost_sum / cnt else 0
                val road_fee_mean = if (num != 0) road_fee_sum / cnt else 0
                val fuel_cost_mean = if (num != 0) fuel_cost_sum / cnt else 0
                val miles_mean = if (num != 0) miles_sum / cnt else 0
                val diff_cost_mean = if (num != 0) diff_cost_sum / cnt else 0
                val diff_road_fee_mean = if (num != 0) diff_road_fee_sum / cnt else 0
                val diff_fuel_cost_mean = if (num != 0) diff_fuel_cost_sum / cnt else 0
                val diff_miles_mean = if (num != 0) diff_miles_sum / cnt else 0
                Cost(task_area_code, carrier_name, line_code, source, online_date, task_inc_day,
                    line_num_sum, line_num, num_sum, num, reject_num, re_cost_mean, re_road_fee_mean,
                    re_fuel_cost_mean, re_miles_mean, cost_mean, road_fee_mean, fuel_cost_mean,
                    miles_mean, diff_cost_mean, diff_road_fee_mean, diff_fuel_cost_mean, diff_miles_mean)
            })
    }

    /**
     * 插入数据
     * @param spark SparkSession
     * @param incDay incDay
     */
    def insert_gis_eta_jiazhi_cost_stat(spark: SparkSession, incDay: String): Unit = {
      import spark.implicits._
        val frame = group_calculate(spark, incDay).toDF()
        LOGGER.info("==================>RDD计算成功")
        frame.createOrReplaceTempView("t1")

        val sql =
            s"""
               |insert overwrite table dm_gis.gis_eta_jiazhi_cost_stat partition (inc_day = '$incDay')
               |select
               |    *,
               |    if(cost != 0, diff_cost / cost, 0)                as rate,
               |    if(roadfee != 0, diff_roadfee / roadfee, 0)       as road_fee_rate,
               |    if(fuel_cost != 0, diff_fuel_cost / fuel_cost, 0) as fuel_cost_rate,
               |    if(miles != 0, diff_miles / miles, 0)             as miles_rate
               |from
               |(
               |    select
               |        *,
               |        cost_mean * num           as cost,
               |        road_fee_mean * num       as roadfee,
               |        fuel_cost_mean * num      as fuel_cost,
               |        miles_mean * num          as miles,
               |        re_cost_mean * num        as re_cost,
               |        re_road_fee_mean * num    as re_roadfee,
               |        re_fuel_cost_mean * num   as re_fuel_cost,
               |        re_miles_mean * num       as re_miles,
               |        diff_cost_mean * num      as diff_cost,
               |        diff_road_fee_mean * num  as diff_roadfee,
               |        diff_fuel_cost_mean * num as diff_fuel_cost,
               |        diff_miles_mean * num     as diff_miles
               |    from t1
               |) t
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def execute(spark: SparkSession, incDay: String): Unit = {
        insert_gis_eta_jiazhi_cost_stat(spark, incDay)
    }

  def nonEmpty(str:String):Boolean={
    str!=null && !str.isEmpty
  }
}

object GisEtaJiaZhiCostStat {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaJiaZhiCostStat
        if (args == null || args.length != 1 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入参数")
            return
        }
        val incDay = args(0)
        task.LOGGER.info("#########################################")
        task.LOGGER.info("inc_day: [{}]", incDay)
        task.LOGGER.info("#########################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession
        task.execute(spark, incDay)
        task.LOGGER.info("任务执行完成")

        spark.stop()
    }
}
