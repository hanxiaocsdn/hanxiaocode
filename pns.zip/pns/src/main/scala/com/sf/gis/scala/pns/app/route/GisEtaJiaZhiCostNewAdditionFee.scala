package com.sf.gis.scala.pns.app.route

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.base.util.StringUtils.nonEmpty
import com.sf.gis.scala.pns.app.route.StandObj.AdditionFee
import com.sf.gis.scala.pns.app.valueLine.StandardLineNewPrecept.parseQMData
import com.sf.gis.scala.pns.utils.Functions.{getDateDiff, isEmptyOrNull, stdCoordsToPoints, timeToCustomTime2}
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * GIS-RDS-PNS 价值线路指标监控需求V2.0
 * 需求方：刘思嘉（01420030）
 * @author 徐游飞（01417347）
 * 任务ID：757160
 * 任务名称：价值线路降本逻辑优化_3.2.1&4.1.1&55.1
 */
object GisEtaJiaZhiCostNewAdditionFee {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val QM_URL: String = "http://rp-c-gd.int.sfcloud.local:1090/qm_point?"
  val QM_AK: String = ""
//  val QM_URL: String = "http://gis-int.int.sfdc.com.cn:1080/rp/qm_point/sf"
//  val QM_AK: String = "d6a1f9b11d2441fc8fc1ffb5eb3e61d6"

  val parallelism = 10
  val akMinuLimit = 4000

  // 获取hive源数据
  def getDataSource(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    val compute55_sql =
      s"""
         |select
         |  grd1,
         |  task_id,
         |  task_area_code,
         |  task_inc_day,
         |  conduct_type,
         |  update_uint_fuel,
         |  fuel_prices,
         |  vehicle_type,
         |  length,
         |  weight,
         |  axls_number,
         |  mload,
         |  diff_sum_cost,
         |  inc_day
         |from
         |  dm_gis.gis_eta_jiazhi_cost_compute55
         |where
         |  inc_day = '$dayBefore1'
         |  and conduct_type = '1'
         |""".stripMargin
    println(compute55_sql)
    val df_compute55 = spark.sql(compute55_sql)
      .withColumn("diff_sum_cost",'diff_sum_cost.cast("double"))
      .withColumn("diff_sum_cost",when(isEmptyOrNull('diff_sum_cost),0.0).otherwise('diff_sum_cost))
      .filter('diff_sum_cost >= 0.0 )
      .drop("diff_sum_cost")

    val grd1_str = df_compute55.select("grd1").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''",",'")

    val cost_new_sql =
      s"""
         |select
         |  grd1,
         |  task_id,
         |  task_area_code,
         |  task_inc_day,
         |  conduct_type,
         |  update_uint_fuel,
         |  fuel_prices,
         |  vehicle_type,
         |  length,
         |  weight,
         |  axls_number,
         |  mload,
         |  inc_day
         |from
         |  dm_gis.gis_eta_jiazhi_cost_new
         |where
         |  inc_day = '$dayBefore1'
         |  and conduct_type != 1
         |  and task_inc_day >= '20221001'
         |  and task_inc_day <= '$dayBefore1'
         |  and task_type in ('1', '2')
         |  and grd1 in ($grd1_str)
         |""".stripMargin
    val df_cost_new = spark.sql(cost_new_sql)

    val conf_sql =
      s"""
         |select
         |  a.std_id as std_id_jz,
         |  concat_ws('_',line_code,src_deptcode,dest_deptcode,vehicle) as linevehicle,
         |  a.add_reason,
         |  b.value_time as online_date_jz
         |from
         |  dm_gis.eta_std_line_conf a
         |  left join dm_gis.eta_std_line_prop b on a.std_id = b.std_id
         |where
         |  a.delete_flag = '0'
         |  and is_econ = '0'
         |  and value_time is not null
         |  and value_time <> ''
         |""".stripMargin
    val df_conf = spark.sql(conf_sql)
      // 根据grd1去重，保留inc_day最新的一条
      .withColumn("rn", row_number().over(Window.partitionBy('linevehicle).orderBy(desc("online_date_jz"),asc("std_id_jz"))))
      .filter('rn === 1)
      .drop("rn")

    (df_compute55,df_cost_new,df_conf)
  }

  def getRecallData(spark: SparkSession, dayBefore1: String, task_id_str: String) = {
    import spark.implicits._
    val recall_sql =
      s"""
         |select
         |  task_id,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  conduct_type as conduct_type_recall,
         |  is_run_ontime,
         |  vehicle_serial,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  is_stop,
         |  error_type,
         |  concat_ws('_',line_code,start_dept,end_dept,vehicle_type) as linevehicle,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  accrual_dist,
         |  stop_over_zone_code,
         |  transoport_level,
         |  carrier_name,
         |  rt_dist,
         |  rt_coords,
         |  std_id,
         |  inc_day as inc_day_1
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day >= '20221001'
         |  and inc_day <= '$dayBefore1'
         |  and carrier_type = '0'
         |  and error_type = '0'
         |  and task_id in ($task_id_str)
         |""".stripMargin
    val df_recall = spark.sql(recall_sql)
      // 根据task_subid去重，保留inc_day最新的一条
      .withColumn("rn", row_number().over(Window.partitionBy('task_subid).orderBy(desc("inc_day_1"))))
      .filter('rn === 1)
      .drop("rn","inc_day_1")

    df_recall
  }

  // 调qm接口
  def runQMInteface3(ak:String, obj: JSONObject): JSONObject = {

    val test = 0
    val stype = 0
    val etype = 0
    val plate = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "")
    val weight = JSONUtil.getJsonVal(obj, "weight_new", "")
    val Mload = JSONUtil.getJsonVal(obj, "mload_new", "")
    val Size = JSONUtil.getJsonVal(obj, "length_new", "")
    val axlenumber = JSONUtil.getJsonVal(obj, "axls_number_new", "")
    val mode = 2
    val speed = 1
    val No = JSONUtil.getJsonVal(obj, "task_subid", "")
    val Toll = 1
    val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
    val points = stdCoordsToPoints(rt_coords)

    //初始化接口请求参数
    val param = s"test=$test&stype=$stype&etype=$etype&plate=$plate&vehicle=$vehicle&weight=$weight&Mload=$Mload&Size=$Size&axlenumber=$axlenumber&mode=$mode&speed=$speed&No=$No&Toll=$Toll&points=$points"

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_URL,param,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析qm接口返回值
    val httpData =  parseQMData(retJSONObject)
    obj.put("t_status",httpData._1)
    obj.put("t_distance",httpData._2)
    obj.put("t_tolls",httpData._3)
    obj.put("t_etc_toll",httpData._4)
    obj.put("t_highspeed_distance",httpData._5)
    obj.put("t_toll_distance",httpData._6)
    obj
  }

  def gisEtaJiaZhiCostCompute55AdditionFee(spark: SparkSession, df_addition_fee: DataFrame, dayBefore1: String) = {

    import spark.implicits._
    val df_grd1_fee = df_addition_fee
      .filter('conduct_type =!= 1 && !isEmptyOrNull('sum_cost_new) && 'reject_flag === 0)
      .groupBy("grd1")
      .agg(
        avg("road_fee_new") as "re_road_fee_new",
        avg("fuel_cost_new") as "re_fuel_cost_new",
        avg("miles_new") as "re_miles_new",
        avg("sum_cost_new") as "re_sum_cost_new"
      )
      .withColumn("inc_day",lit(dayBefore1))

    // 结果表4_1_1保存至hive
    val cols_grd1 = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_grd1_addition_fee limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_grd1_fee.select(cols_grd1: _*),Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_grd1_addition_fee")

    val df_compute55_fee = df_addition_fee
      .drop("inc_day")
      .filter('conduct_type === 1 && !isEmptyOrNull('sum_cost_new) && 'reject_flag === 0 && 'task_inc_day === 'inc_day)
      .join(df_grd1_fee,Seq("grd1"),"left")
      .withColumn("rt_dist", sum('rt_dist).over(Window.partitionBy('task_id)))
      .withColumn("accrual_dist", sum('accrual_dist).over(Window.partitionBy('task_id)))
      .withColumn("diff_road_fee_new", 'road_fee_new - 're_road_fee_new)
      .withColumn("diff_fuel_cost_new", 'fuel_cost_new - 're_fuel_cost_new)
      .withColumn("diff_miles_new", 'miles_new - 're_miles_new)
      .withColumn("diff_sum_cost_new", 'sum_cost_new - 're_sum_cost_new)
      .withColumn("diff_flag", lit(1))
      .withColumn("task_flag", lit(1))
      .withColumn("inc_day",lit(dayBefore1))

    // 结果表55_1保存至hive
    val cols_55_fee = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_compute55_addition_fee limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_compute55_fee.select(cols_55_fee: _*),Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_compute55_addition_fee")

  }

  // 总油费和总成本计算（空值情况特殊处理，保持为空）
  def getfuelCostNew(fuel_prices: String,update_uint_fuel: String,miles_new: Double,road_fee_new: Double) = {

    var fuel_cost_new = ""
    var sum_cost_new = ""

    if(nonEmpty(fuel_prices) && nonEmpty(update_uint_fuel)){
      val fuel_cost_new_tmp = fuel_prices.toDouble * update_uint_fuel.toDouble * miles_new / 100
      fuel_cost_new = fuel_cost_new_tmp.toString
      sum_cost_new = (road_fee_new + fuel_cost_new_tmp).toString
    }

    (fuel_cost_new,sum_cost_new)
  }

  def execute(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._

    // 获取hive源数据
    val dataSource = getDataSource(spark,dayBefore1)
    val df_compute55 = dataSource._1
    val df_cost_new32 = dataSource._2
    val df_conf = dataSource._3

    // 获取线下std_id数据
    val df_param: DataFrame = spark.read
      .format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/user/01417347/upload/data/价值线路车参数据.csv")
      .withColumnRenamed("weight","weight_yw")
      .withColumnRenamed("mload","mload_yw")
      .withColumnRenamed("length","length_yw")
      .withColumnRenamed("axle_number","axls_number_yw")

    // 任务成本表和成本计算更新表合并
    val df_fee_re = df_cost_new32
      .union(df_compute55)
      .toDF()
      .withColumn("conduct_type_task",'conduct_type)
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 获取 recall 表数据（过滤只选取task_id在合并表里的数据，缩短join耗时）
    val task_id_str = df_fee_re.select("task_id").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''",",'")
    val df_recall = getRecallData(spark, dayBefore1, task_id_str)

    // 合并表管理conf表和recall表和线下车参表
    val df_all_join = df_fee_re
      .join(df_recall,Seq("task_id"),"inner")
      .join(df_conf,Seq("linevehicle"),"inner")
      .join(df_param,Seq("vehicle_serial"),"left")
      .withColumn("weight_new",when(!isEmptyOrNull('weight_yw),'weight_yw).otherwise('weight))
      .withColumn("mload_new",when(!isEmptyOrNull('mload_yw),'mload_yw).otherwise('mload))
      .withColumn("length_new",when(!isEmptyOrNull('length_yw),'length_yw).otherwise('length))
      .withColumn("axls_number_new",when(!isEmptyOrNull('axls_number_yw),'axls_number_yw).otherwise('axls_number))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val cols_1 = spark.sql("""select * from dm_gis.fee_all_join_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_all_join.withColumn("inc_day",lit(dayBefore1)).select(cols_1: _*),Seq("inc_day"),"dm_gis.fee_all_join_detail")
      //  val df_all_join = spark.sql(s"select * from dm_gis.fee_re_xyf_tmp where inc_day = '$dayBefore1'")

    val invokeCnt = df_all_join.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "757160", "价值线路降本逻辑优化_3.2.1&4.1.1&55.1", "获取收费字段", QM_URL, QM_AK, invokeCnt, parallelism)
    // 调QM匹配接口,获取收费字段
    val rdd_all_join = SparkNet.runInterfaceWithAkLimit(spark, df_all_join.rdd.map(row2Json), runQMInteface3, parallelism, QM_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)

    val df_cost_new = rdd_all_join.map(obj=>{
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      var grd1 = JSONUtil.getJsonVal(obj, "grd1", "")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val task_inc_day = JSONUtil.getJsonVal(obj, "task_inc_day", "")
      val conduct_type = JSONUtil.getJsonVal(obj, "conduct_type", "")
      val conduct_type_task = JSONUtil.getJsonVal(obj, "conduct_type_task", "")
      val update_uint_fuel = JSONUtil.getJsonVal(obj, "update_uint_fuel", "")
      val fuel_prices = JSONUtil.getJsonVal(obj, "fuel_prices", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
      val length = JSONUtil.getJsonVal(obj, "length", "")
      val weight = JSONUtil.getJsonVal(obj, "weight", "")
      val axls_number = JSONUtil.getJsonVal(obj, "axls_number", "")
      val mload = JSONUtil.getJsonVal(obj, "mload", "")
      val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
      val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
      val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
      val start_type = JSONUtil.getJsonVal(obj, "start_type", "")
      val end_type = JSONUtil.getJsonVal(obj, "end_type", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val conduct_type_recall = JSONUtil.getJsonVal(obj, "conduct_type_recall", "")
      val is_run_ontime = JSONUtil.getJsonVal(obj, "is_run_ontime", "")
      val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
      val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
      val is_stop = JSONUtil.getJsonVal(obj, "is_stop", "")
      val error_type = JSONUtil.getJsonVal(obj, "error_type", "")
      val start_longitude = JSONUtil.getJsonVal(obj, "start_longitude", "")
      val start_latitude = JSONUtil.getJsonVal(obj, "start_latitude", "")
      val end_longitude = JSONUtil.getJsonVal(obj, "end_longitude", "")
      val end_latitude = JSONUtil.getJsonVal(obj, "end_latitude", "")
      val accrual_dist = JSONUtil.getJsonVal(obj, "accrual_dist", "")
      val stop_over_zone_code = JSONUtil.getJsonVal(obj, "stop_over_zone_code", "")
      val transoport_level = JSONUtil.getJsonVal(obj, "transoport_level", "")
      val carrier_name = JSONUtil.getJsonVal(obj, "carrier_name", "")
      val rt_dist = JSONUtil.getJsonVal(obj, "rt_dist", "")
      val rt_coords = JSONUtil.getJsonVal(obj, "rt_coords", "")
      val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
      val std_id_jz = JSONUtil.getJsonVal(obj, "std_id_jz", "")
      val add_reason = JSONUtil.getJsonVal(obj, "add_reason", "")
      val online_date_jz = JSONUtil.getJsonVal(obj, "online_date_jz", "")
      val height = JSONUtil.getJsonVal(obj, "height", "")
      val length_yw = JSONUtil.getJsonVal(obj, "length_yw", "")
      val width = JSONUtil.getJsonVal(obj, "width", "")
      val weight_yw = JSONUtil.getJsonVal(obj, "weight_yw", "")
      val mload_yw = JSONUtil.getJsonVal(obj, "mload_yw", "")
      val axls_number_yw = JSONUtil.getJsonVal(obj, "axls_number_yw", "")
      val emitstand = JSONUtil.getJsonVal(obj, "emitstand", "")
      val energy = JSONUtil.getJsonVal(obj, "energy", "")
      val platecolor = JSONUtil.getJsonVal(obj, "platecolor", "")
      val passport = JSONUtil.getJsonVal(obj, "passport", "")
      val car_type = JSONUtil.getJsonVal(obj, "car_type", "")
      val axls_number_new = JSONUtil.getJsonVal(obj, "axls_number_new", "")

      // qm接口返回字段
      val t_status = JSONUtil.getJsonValInt(obj, "t_status", 404)
      val t_highspeed_distance = JSONUtil.getJsonDouble(obj, "t_highspeed_distance", 0.0)
      val t_tolls = JSONUtil.getJsonDouble(obj, "t_tolls", 0.0)
      val t_toll_distance = JSONUtil.getJsonDouble(obj, "t_toll_distance", 0.0)
      val t_distance = JSONUtil.getJsonDouble(obj, "t_distance", 0.0)
      val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")

      val miles_new = t_distance / 1000
      val road_fee_new = t_tolls
      grd1 = s"${grd1}_${start_dept}_${end_dept}_${axls_number_new}"

      // 打标用于后续过滤接口返回异常的数据
      var flag = 1
      if((t_status == 0 && t_tolls >= 0.0) || (t_status == 0 && t_tolls == 0.0 && t_highspeed_distance == 0.0 && t_toll_distance == 0.0)) flag = 0
      // 总油费和总成本计算（空值情况特殊处理，保持为空）
      val (fuel_cost_new,sum_cost_new) = getfuelCostNew(fuel_prices,update_uint_fuel,miles_new,road_fee_new)

      AdditionFee(vehicle_serial,linevehicle,task_id,grd1,task_area_code,task_inc_day,conduct_type,conduct_type_task,update_uint_fuel,fuel_prices,vehicle_type,
        length,weight,axls_number,mload,task_subid,start_dept,end_dept,start_type,end_type,line_code,conduct_type_recall,is_run_ontime,actual_depart_tm,
        actual_arrive_tm,is_stop,error_type,start_longitude,start_latitude,end_longitude,end_latitude,accrual_dist,stop_over_zone_code,transoport_level,
        carrier_name,rt_dist,rt_coords,std_id,std_id_jz,add_reason,online_date_jz,height,length_yw,width,weight_yw,mload_yw,axls_number_yw,
        emitstand,energy,platecolor,passport,car_type,flag,miles_new,road_fee_new,fuel_cost_new,sum_cost_new,inc_day)
    }).toDF()

    val df_addition_fee = df_cost_new
      .withColumn("conduct_type",when('std_id_jz === 'std_id && 'conduct_type === 1,1).otherwise(3))
      .withColumn("carrier_type",lit(0))
      .withColumn("error_type",lit(0))
      .withColumn("weight",when(!isEmptyOrNull('weight_yw),'weight_yw).otherwise('weight))
      .withColumn("mload",when(!isEmptyOrNull('mload_yw),'mload_yw).otherwise('mload))
      .withColumn("length",when(!isEmptyOrNull('length_yw),'length_yw).otherwise('length))
      .withColumn("axls_number",when(!isEmptyOrNull('axls_number_yw),'axls_number_yw).otherwise('axls_number))
      .withColumn("reject_flag",'flag)
      .withColumn("linevehicle_jz",'linevehicle)
      .withColumn("add_reason",when('add_reason.contains("融合") || 'add_reason.contains("未来排班"),"融合源")
        .when('add_reason.contains("新方案"),"新方案")
        .when('add_reason.contains("旧方案"),"旧方案")
        .otherwise("标准")
      )
      .withColumn("online_date_jz",timeToCustomTime2('online_date_jz,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("date_diff",getDateDiff('task_inc_day,'online_date_jz,lit("yyyyMMdd"),lit(0)).cast("int"))
      .withColumn("task_type",when('task_inc_day >= 'online_date_jz,1)
        .when('task_inc_day < 'online_date_jz && 'date_diff <= 60,2)
        .otherwise(0)
      )
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 结果表3_2_1保存至hive
    val cols_ret = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_new_addition_fee limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_addition_fee.select(cols_ret: _*),Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_new_addition_fee")

    //计算 结果表4_1_1 和 结果表55_1
    gisEtaJiaZhiCostCompute55AdditionFee(spark,df_addition_fee,dayBefore1)

    df_addition_fee.unpersist()
    df_all_join.unpersist()
    df_fee_re.unpersist()
  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始20231021  ++++")
    execute(spark,dayBefore1)
    logger.error("++++++++  任务完成20231021  ++++")

    spark.stop()
  }

}
