package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.JSON
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{CityUtils, HashKeyPartitioner}
import com.sf.gis.scala.pns.utils.HttpUtil
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

/**
 * @ProductManager: 顺丰速运用户
 * @Author: 01374443 张想远 (郭老师代码改造)
 * @CreateTime: 2023-03-07 14:06
 * @TaskId:226260
 * @TaskName:AnalyzeBikeOverSpeed
 * @Description: 骑行超速轨迹辨识
 */
//骑行超速轨迹辨识
object AnalyzeBikeOverSpeed {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  case class User(bn: String, un: String, full_name: String, position_name: String, vehicle_id: Int, vehicle_name: String)

  case class Job(tmstart: Long, tmend: Long, tmfrom: String, tmto: String)

  val useCache = false
  var jobtimeSqlPrinted = false
  val url = "http://gis-rss-exprpqx.int.sfdc.com.cn:1080/analyzetrackspeed"

  def main(args: Array[String]): Unit = {

    val checkDate = args(0)
    val sparkSession = Spark.getSparkSession(appName)
    init(sparkSession, checkDate)
  }


  def initJobTime(sparkSession: SparkSession, dayid: String) = {
    val sql =
      s"""
         |select
         |  dept_code bn,
         |  loginid un,
         |  full_name,
         |  position_name,
         |  vehicle_id,
         |  vehicle_name,
         |  tmstart,
         |  tmend,
         |  tmfrom,
         |  tmto
         |from
         |  (
         |    select
         |      dept_code,
         |      loginid,
         |      start_time tmstart,
         |      end_time tmend,
         |      from_unixtime(start_time, 'yyyy-MM-dd HH:mm:ss') as tmfrom,
         |      from_unixtime(end_time, 'yyyy-MM-dd HH:mm:ss') as tmto
         |    from
         |      dm_tc_waybillinfo.schedule_width_data
         |    where
         |      inc_day = '$dayid'
         |      and start_time is not null
         |      and end_time is not null
         |      and (
         |        batch_code like '%P'
         |        or batch_code like '%D'
         |      )
         |  ) a
         |  left join (
         |    select
         |      org_code,
         |      full_name,
         |      position_name,
         |      vehicle,emp_num
         |    from
         |      ods_sgsrss.res_user
         |    where
         |      inc_day = '$dayid' group by org_code,full_name,position_name,vehicle,emp_num
         |  ) b on a.dept_code = b.org_code and a.loginid=b.emp_num
         |  left join (
         |    select
         |      vehicle_name,
         |      vehicle_id
         |    from
         |      ods_sgsrss.tm_rss_vehicle_config
         |    where
         |      inc_day = '$dayid' group by vehicle_id,vehicle_name
         |  ) c on b.vehicle = c.vehicle_id
         |where
         |  vehicle is not null
         |group by
         |  dept_code,
         |  loginid,
         |  full_name,
         |  position_name,
         |  vehicle_id,
         |  vehicle_name,
         |  tmstart,
         |  tmend,
         |  tmfrom,
         |  tmto
         |""".stripMargin

    logger.error(sql)
    val originData = sparkSession.sql(sql).rdd.map(d => {
      try {
        //512S,41207474,魏巧魁,收派员,7,三轮电动车,1607506200,1607513400,2020-12-09 17:30:00,2020-12-09 19:30:00
        /*
        +-------+--------+---------+-------------+----------+------------+----------+----------+-------------------+-------------------+
        |bn     |un      |full_name|position_name|vehicle_id|vehicle_name|tmstart   |tmend     |tmfrom             |tmto               |
        +-------+--------+---------+-------------+----------+------------+----------+----------+-------------------+-------------------+
        |028AM  |01088621|魏家红   |收派员       |1         |燃油汽车    |1607498833|1607516532|2020-12-09 15:27:13|2020-12-09 20:22:12|
*/
        val bn = d.getString(0)
        val un = d.getString(1)
        val full_name = d.getString(2)
        val position_name = d.getString(3)
        val vehicle_id = Integer.parseInt(d.get(4).toString.trim)
        val vehicle_name = d.getString(5)
        val tmstart = java.lang.Long.parseLong(d.get(6).toString.trim)
        val tmend = java.lang.Long.parseLong(d.get(7).toString.trim)
        val tmfrom = d.getString(8)
        val tmto = d.getString(9)
        (User(bn, un, full_name, position_name, vehicle_id, vehicle_name), Job(tmstart, tmend, tmfrom, tmto))
      } catch {
        case e: Exception => {
          logger.error(e.getMessage + "\t" + e.getCause)
          null
        }
      }
    }).filter(_ != null)
    //      //估计有两亿太大了
    //      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    //    logger.error("originData数量:" + originData.count())

    val job = originData.groupByKey().map(d => {
      val user = d._1
      val tms = d._2.toSeq.sortBy(_.tmstart)
      val tmSeq = new mutable.HashMap[Int, (Long, Long)]()

      var p0 = (tms(0).tmstart, tms(0).tmend)
      tmSeq.put(0, p0)
      //容差 300 秒 改为 0秒，只记录上班期间超速，不记录上下班途中是否超速
      val delta = 0
      (1 to tms.length - 1).foreach(i => {
        val p1 = (tms(i).tmstart, tms(i).tmend)
        if (p1._1 > p0._2 + delta) { //相离
          p0 = p1
          tmSeq.put(tmSeq.keys.size, p1)
        } else if (p1._1 >= p0._1 && p1._1 <= p0._2 && p1._2 > p0._2) { // 相交
          p0 = (p0._1, p1._2)
          tmSeq.put(tmSeq.keys.size - 1, p0)
        }
      })
      (user, tmSeq.values)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    (job, sql)
  }

  def saveDetailData(sparkSession: SparkSession, dayid: String, originSql: String) = {
    import sparkSession.implicits._
      val tmpView = "tmpView" + System.currentTimeMillis()
    val querysql =
      """
        |select
        |  distinct a.`date`,
        |  a.city,
        |  a.branch,
        |  a.`user`,
        |  b.full_name,
        |  b.position_name,
        |  b.vehicle_name,
        |  a.speeds
        |from
        |  (
        |    SELECT
        |      get_json_object(log, '$.branch') as branch,
        |      get_json_object(log, '$.city') as city,
        |      get_json_object(log, '$.date') as `date`,
        |      get_json_object(log, '$.user') as `user`,
        |      get_json_object(log, '$.vehicle') as vehicle,
        |      get_json_object(log, '$.speeds') as speeds
        |    FROM
        |      dm_gis.analyze_bike_over_speed t
        |    where
        |""".stripMargin +
        s"inc_day = '${dayid}' " +
        """and get_json_object(log, '$.speeds') IS NOT NULL
          |      and get_json_object(log, '$.speeds')  <> ''
          |  ) a
          |""".stripMargin +
        s"""
           |  left join ($originSql ) b on a.branch = b.bn
           |  and a.`user` = b.un
           |""".stripMargin

    logger.error(querysql)

    sparkSession.sql(querysql).rdd.map(d => {
      val city = d.getString(1)
      val bn = d.getString(2)
      val un = d.getString(3)
      val name = d.getString(4)
      val title = d.getString(5)
      val vehicle = d.getString(6)
      try {
        val speeds = JSON.parseArray(d.getString(7))
        (0 to speeds.size() - 1).map(i => {
          //{"endlink":"雁栖东二路","limitspeed":25,"maxspeed":39,"startlink":"雁栖东二路","time":120,"timestamp":1535019252}
          val r = speeds.getJSONObject(i)
          val tmStart = r.getString("timestamp")
          val tmContinue = r.getString("time")
          val start = r.getString("startlink")
          val end = r.getString("endlink")
          val limitspeed = r.getString("limitspeed")
          val maxspeed = r.getString("maxspeed")
          (city, bn, un, name, title, vehicle, tmStart, tmContinue, start, end, limitspeed, maxspeed)
        })
      } catch {
        case e: Exception => {
          logger.error(e.getMessage)
          logger.error(e.getCause)
          null
        }
      }
    }).filter(d => d != null).flatMap(d => d).toDF("city", "bn", "un", "name", "title", "vehicle", "tmStart", "tmContinue", "start", "end", "limitspeed", "maxspeed")
      .repartition(1).createOrReplaceTempView(tmpView)

    val tableName = "dm_gis.analyze_bike_over_speed_detail"

    val sql = s"insert overwrite table ${tableName} partition(inc_day='$dayid') select * from $tmpView "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def runOverSpeed(sparkSession: SparkSession, dayid: String,
                   bjobtm: Broadcast[collection.Map[String, Iterable[(Long, Long)]]],
                   bjobve: Broadcast[collection.Map[String, Int]],
                   userCnt: Int, uns: Array[String]) = {
    var tableName = "dm_gis.analyze_bike_over_speed"
    var batchSize = 5000
    val loopCount = Math.ceil(userCnt.toDouble / batchSize.toDouble).toInt
    var start = 0
    var end = 0
    var invokeCnt = 0l
    var errorCnt = 0l

    val srcsql = s"select  bn,un,zx,zy,ac,tp,tm,ak,sp,be from dm_gis.esg_gis_loc_trajectory t where t.inc_day='$dayid'" +
      s" group by bn,un,zx,zy,ac,tp,tm,ak,sp,be"
    logger.error(srcsql)
    val totoalPointDf = sparkSession.sql(srcsql).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    totoalPointDf.createOrReplaceTempView(s"src_$dayid")
    var cnt = totoalPointDf.count()
    while (cnt == 0) {
      logger.error(s"【$dayid】初始化轨迹异常，轨迹数：0，退出")
      System.exit(-1)
    }
    var totalDataRdd: RDD[(String)] = null
    for (i <- 0 to loopCount) {
      start = i * batchSize
      end = Math.min((i + 1) * batchSize, userCnt)

      val istart = start
      val iend = end
      val idx = i

      if (start < userCnt) {
        System.err.println("【" + dayid + "】用户数：" + userCnt + "\t批量：" + batchSize + "\t迭代数：" + loopCount + "\t批次：" + idx + "\t【" + istart + " - " + iend + "】")

        val bncnd = uns.slice(istart, iend).map(_.split(",")(0)).mkString("'", "','", "'")
        val uncnd = uns.slice(istart, iend).map(_.split(",")(1)).mkString("'", "','", "'")

        var sql = s"select bn,un,zx,zy,ac,tp,tm,ak,sp,be from src_$dayid where un in(" + uncnd + ") and bn in(" + bncnd + ")"
        val postResult = sparkSession.sql(sql).rdd.groupBy(d => d.getString(0) + "," + d.getString(1))
          .map(d => {
          val key = d._1.split(",")
          val bn = key(0)
          val un = key(1)
          //val paths = d._2.toSeq.sortBy(_.getString(6).toLong)
          //取ak中最多轨迹点数的一组轨迹
          val paths = d._2.groupBy(_.getString(7)).toIndexedSeq.sortBy(d => d._2.size).reverse(0)._2.toSeq.sortBy(_.getString(6).toLong)
          val job = bjobtm.value.getOrElse(d._1, null)
          if (job != null) {
            val result = job.map(tm => {
              val path = paths.filter(d => {
                val t = d.getString(6).toLong
                t >= tm._1 && t <= tm._2
              })
              val cityCode = CityUtils.getCityCodeFromOrgCode(bn)
              val vehicle_id = bjobve.value.getOrElse(d._1, 0)
              val vehicle = getFinalVehicle(vehicle_id)
              val rst = postData(cityCode, bn, un, vehicle, dayid, path, url)

              if (rst._3 == null)
                null
              else {
                try {
                  val json = JSON.parseObject(rst._3)
                  if (json.getIntValue("ret") == 4 || json.getString("user") == null || json.getString("user") == "null")
                    null
                  else
                    rst
                } catch {
                  case e: Exception => {
                    null
                  }
                }
              }
            })
            result.filter(_ != null)
          } else {
            null
          }
        }).filter(_ != null).flatMap(d => d).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error(s"【$dayid】批次：【$idx】处理成功：" + postResult.filter(d => d._3 != null && d._4 == null).count + "，处理失败：" + postResult.filter(_._4 != null).count)
        if (totalDataRdd == null) {
          totalDataRdd = postResult.filter(_._4 == null).map(obj => (obj._3)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
          logger.error("总结果数：" + totalDataRdd.count())
        } else {
          val tmpResult = totalDataRdd
          totalDataRdd = totalDataRdd.union(postResult.filter(_._4 == null).map(obj => (obj._3))).repartition(10).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
          logger.error("总结果数：" + totalDataRdd.count())
          tmpResult.unpersist()
        }
        postResult.unpersist()
        logger.error(s"【$dayid】批次：【$idx】处理完成")
      }
    }
    import sparkSession.implicits._
    val tmpView = "tmpView" + System.currentTimeMillis()
    totalDataRdd.toDF("log").createOrReplaceTempView(tmpView)
    val sql = s"insert overwrite table $tableName partition(inc_day='$dayid') select * from $tmpView "
    logger.error(sql)
    sparkSession.sql(sql)
    totalDataRdd.unpersist()
  }

  def init(sparkSession: SparkSession, dayid: String): Unit = {

    logger.error(s"即将开始车行轨迹超速判别：【$dayid】")
    logger.error("============================================================")
    logger.error("当前目录：" + System.getProperty("user.dir"))
    logger.error("============================================================")

    var (jobs, originSql) = initJobTime(sparkSession, dayid)
    val jobCnt = jobs.count()
    while (jobCnt == 0) {
      //配置依赖后，此处不应该再进入了
      logger.error(s"【$dayid】初始化任务时段异常，用户数：0,退出任务")
      System.exit(-1)
    }
    logger.error(s"【$dayid】用户数：" + jobCnt)
    val uns = jobs.map(d => d._1.bn + "," + d._1.un).distinct().collect().sortBy(d => d)
    val userCnt = uns.length
    logger.error(s"【$dayid】初始化任务时段完毕，用户数：$userCnt")

    val jobtm = jobs.map(d => (d._1.bn + "," + d._1.un, d._2)).collectAsMap()
    val bjobtm = sparkSession.sparkContext.broadcast(jobtm)
    val jobve = jobs.map(d => (d._1.bn + "," + d._1.un, d._1.vehicle_id)).distinct().collectAsMap
    val bjobve = sparkSession.sparkContext.broadcast(jobve)
    jobs.unpersist()

    runOverSpeed(sparkSession, dayid, bjobtm, bjobve, userCnt, uns)
    logger.error("开始记录明细")
    saveDetailData(sparkSession, dayid, originSql)

    logger.error(s"【$dayid】处理完成")

  }

  def postData(cityCode: String, bn: String, un: String, vehicle: String, dayid: String, paths: Iterable[Row], url: String) = {
    //        Util.memTime()
    val pathsRows = paths.toIndexedSeq.sortBy(d => d.getString(6).toLong)
    val sb = new StringBuilder()
    var c = 0
    sb.append(s"""{"duration":120,"city":"$cityCode","branch":"$bn","vehicle":$vehicle,"userid":"$un","carnum":"$un","date":"$dayid","tracks":[""")

    for (i <- 0 to pathsRows.size - 1) {
      try {
        // bn,un,zx,zy,ac,tp,tm,ak,sp,be
        val row = pathsRows(i)
        val x = row.getString(2).toDouble
        val y = row.getString(3).toDouble
        var ac = row.getString(4).toInt
        var tp = row.getString(5).toInt
        var tm = row.get(6).toString.toLong
        val sp = row.getString(8).toDouble
        val be = row.getString(9).toDouble

        if (tm >= 100000000000L)
          tm = (tm / 1000).toInt
        if (c > 0)
          sb.append(",")

        sb.append("{\"type\":" + tp + ",\"x\":" + x + ",\"y\":" + y + ",\"accuracy\":" + ac + ",\"speed\":" + sp + ",\"azimuth\":" + be + ",\"time\":" + tm + "}")
        c += 1
      } catch {
        case e: Exception => {
          System.err.println("轨迹数据错误：\n" + pathsRows(i))
          e.printStackTrace()
        }
      }
    }
    sb.append("]")
    sb.append("}")

    val req = sb.toString()
    //var ret = -200
    //var result = ""
    //System.err.println("开始提交数据：轨迹数：" + pathsRows.length + "，发送字节：" + str.length)
    HttpUtil.tryPostWithDetail(url, req, 3)
  }

  def getFinalVehicle(vehicle_id: Int) = {
    /*
1	燃油汽车	30.0	2017-09-12 14:48:09	20180814
2	二轮摩托车	20.0	2017-09-12 14:48:09	20180814
3	自行车	10.0	2017-09-12 14:48:09	20180814
4	二轮电动车	15.0	2017-09-12 14:48:09	20180814
5	步行	4.0	2017-09-12 14:48:09	20180814
6	三轮摩托车	20.0	2017-09-12 14:48:09	20180814
7	三轮电动车	15.0	2017-09-12 14:48:09	20180814
8	电动汽车	30.0	2017-09-12 14:48:09	20180814
==>
0为未知
1-2为骑行:1电动车,2摩托车
3-5为车行:3小客车,4小货车,5大货车
*/
    if ("1,8".split(",").contains(vehicle_id.toString))
      "3"
    else if ("3,4,5,7".split(",").contains(vehicle_id.toString))
      "1"
    else if ("2,6".split(",").contains(vehicle_id.toString))
      "2"
    else "0"
  }

}
