package com.sf.gis.scala.pns.app

import java.text.SimpleDateFormat
import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
/**
 * @Description:路桥费账单信息统计
 * 需求人员：01434085 翟冰雪
 * @Author: lixiangzhi 01405644
 * @Date:20240104
 * 任务id:959767
 * 任务名称：路桥费账单信息表
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object RoadBridgeBillInfoStatistic {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readSupplierRoadbridgeFees(spark: SparkSession, endDay: String) = {
    val supplierRoadbridgeFeesSql=
      s"""
        |select
        |task_id,vehicle_type,task_result,mload,plate
        |from dm_gis.dm_supplier_roadbridge_fees_dtl
        |where inc_day = '$endDay'
        |and task_status='6'
        |""".stripMargin
    val supplierRoadbridgeFeesMap: collection.Map[String, JSONObject] = SparkUtils.getRowToJsonClear(spark, supplierRoadbridgeFeesSql).map(obj => {
      (obj.getString("task_id"), obj)
    }).collectAsMap()
    supplierRoadbridgeFeesMap
  }

  def timeToLong(enDateTime: String) = {
    var enDateTimeMs:Long=0
    if (StringUtils.isNoneEmpty(enDateTime)){
      enDateTimeMs = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(enDateTime).getTime/1000
    }
    enDateTimeMs
  }

  def processSupplierRecall(spark: SparkSession, incDay: String) = {
    import spark.implicits._

    val trackMergeSql=
      s"""
        |select * from dm_gis.dm_pns_track_merge_di where inc_day='$incDay'
        |""".stripMargin
    val lineDistanceRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark,trackMergeSql).filter(obj => {
      val enDateTime: String = obj.getString("endatetime")
      val actual_depart_tm: String = obj.getString("actual_depart_tm")
      val exDateTime: String = obj.getString("exdatetime")
      val actual_arrive_tm: String = obj.getString("actual_arrive_tm")
      StringUtils.isNotEmpty(enDateTime) &&
      StringUtils.isNotEmpty(actual_depart_tm) &&
      StringUtils.isNotEmpty(exDateTime) &&
      StringUtils.isNotEmpty(actual_arrive_tm) &&
        enDateTime >= actual_depart_tm &&
        exDateTime <= actual_arrive_tm
    }).map(obj => {
      val trackOrigin: String = JSONUtil.getJsonValSingle(obj, "track")
      val track: JSONArray = JSON.parseArray(trackOrigin)
      val actual_depart_tm: String = obj.getString("actual_depart_tm")
      val actual_arrive_tm: String = obj.getString("actual_arrive_tm")
      val enDateTime: String = obj.getString("endatetime")
      val exDateTime: String = obj.getString("exdatetime")
      val enDateTimeMs: Long = timeToLong(enDateTime)
      val exDateTimeMs: Long = timeToLong(exDateTime)
      val actual_depart_tm_ms: Long = timeToLong(actual_depart_tm)
      val actual_arrive_tm_ms: Long = timeToLong(actual_arrive_tm)
      val enDiffMap = new util.ArrayList[(Long,String,String)]()
      val exDiffMap = new util.ArrayList[(Long,String,String)]()
      val actualArray = new util.ArrayList[String]()
      for (i <- 0 until (track.size())) {
        val trackObj: JSONObject = track.getJSONObject(i)
        val dx: String = trackObj.getString("dx")
        val dy: String = trackObj.getString("dy")
        val tm: Long = JSONUtil.getJsonLong(trackObj, "tm", 0)
        if (enDateTimeMs != 0 && tm != 0) {
          val en_diff: Long = (enDateTimeMs - tm).abs
          enDiffMap.add((en_diff, dx, dy))
        }
        if (exDateTimeMs != 0 && tm != 0) {
          val ex_diff: Long = (exDateTimeMs - tm).abs
          exDiffMap.add((ex_diff, dx, dy))
        }
        if (actual_depart_tm_ms != 0 && tm != 0 && tm >= actual_depart_tm_ms && tm <= actual_arrive_tm_ms) {
          actualArray.append(dx + "," + dy)
        }
      }
      if (enDiffMap.nonEmpty){
        val enDiffMin = enDiffMap.minBy(_._1)
        val en_dx: String = enDiffMin._2
        val en_dy: String = enDiffMin._3
        obj.put("en_coordinate", en_dx+","+en_dy)
      }
      if (exDiffMap.nonEmpty){
        val exDiffMin = exDiffMap.minBy(_._1)
        val ex_dx: String = exDiffMin._2
        val ex_dy: String = exDiffMin._3
        obj.put("ex_coordinate", ex_dx+","+ex_dy)
      }
      if (actualArray.nonEmpty){
        val trackStr: String = actualArray.mkString("|")
        obj.put("trackStr", trackStr)
      }
      obj
    }).groupBy(_.getString("task_id")).map(obj => {
      val list: List[JSONObject] = obj._2.toList
      val en_plaza_name: String = list.map(_.getString("enplazaname")).mkString("|")
      val ex_plaza_name: String = list.map(_.getString("explazaname")).mkString("|")
      val en_coordinate: String = list.map(_.getString("en_coordinate")).mkString("|")
      val ex_coordinate: String = list.map(_.getString("ex_coordinate")).mkString("|")
      val fee: Double = list.map(_.getDoubleValue("fee")).sum / 100
      val discount_fee: Double = (list.map(_.getDoubleValue("discountfee")).sum) / 100
      val discount_before_amount = fee + discount_fee
      val tmpObj: JSONObject = list.maxBy(_.getDoubleValue("vehicle_weight"))
      tmpObj.put("en_plaza_name", en_plaza_name)
      tmpObj.put("ex_plaza_name", ex_plaza_name)
      tmpObj.put("en_coordinate", en_coordinate)
      tmpObj.put("ex_coordinate", ex_coordinate)
      tmpObj.put("fee", fee)
      tmpObj.put("discount_fee", discount_fee)
      tmpObj.put("discount_before_amount", discount_before_amount)
      tmpObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调线路里程接口的数据量:"+lineDistanceRdd.count())
    //supplierJoinRecallRdd.unpersist()
    val httpQmPoint = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "959767", "线路里程接口", "线路开始时间和轨迹点调接口返回线路里程和高速里程", "http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf", "c47a02ed48df432e91c9276b00d2067d", lineDistanceRdd.count(), 60)
    val returnQmPointRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,lineDistanceRdd, SfNetInteface.qmPointInterface, 60, "c47a02ed48df432e91c9276b00d2067d", 50000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpQmPoint)
    val qmPointMidRdd: RDD[JSONObject] = returnQmPointRdd.repartition(600).map(obj => {
      val route: JSONObject = JSONUtil.getJsonObjectMulti(obj, "ret.route")
      val paths: JSONArray = JSONUtil.getJsonArrayMulti(route, "paths")
      val distanceArray = new util.ArrayList[Double]()
      val tollDistanceArray = new util.ArrayList[Double]()
      for (i <- 0 until (paths.size())) {
        val pathsObj: JSONObject = paths.getJSONObject(i)
        val distance: Double = pathsObj.getDoubleValue("distance")
        val toll_distance: Double = pathsObj.getDoubleValue("toll_distance")
        distanceArray.append(distance)
        tollDistanceArray.append(toll_distance)
      }
      val distance: Double = distanceArray.sum / 1000
      val toll_distance: Double = tollDistanceArray.sum / 1000
      obj.put("distance", distance)
      obj.put("toll_distance", toll_distance)
      obj.remove("ret")

      val start_dept: String = obj.getString("start_dept")
      val end_dept: String = obj.getString("end_dept")
      val vehicle_toll_type: String = obj.getString("vehicle_toll_type")
      val en_plaza_name: String = obj.getString("en_plaza_name")
      val ex_plaza_name: String = obj.getString("ex_plaza_name")
      val fee: Double = obj.getDoubleValue("fee")
      val discount_fee: String = obj.getString("discount_fee")
      val std_id: String = obj.getString("std_id")
      val fee_per_kilometer: Double = fee / distance
      val fee_per_toll_kilometer: Double = fee / toll_distance
      obj.put("fee_per_kilometer", fee_per_kilometer)
      obj.put("fee_per_toll_kilometer", fee_per_toll_kilometer)
      ((start_dept, end_dept, vehicle_toll_type, en_plaza_name, ex_plaza_name, fee, discount_fee, std_id), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val frequency: Int = list.size
      val tmpList: List[JSONObject] = list.map(json => {
        json.put("frequency", frequency)
        json
      })
      tmpList.iterator
    }).map(obj => {
      val start_dept: String = obj.getString("start_dept")
      val end_dept: String = obj.getString("end_dept")
      val vehicle_toll_type: String = obj.getString("vehicle_toll_type")
      val en_plaza_name: String = obj.getString("en_plaza_name")
      val ex_plaza_name: String = obj.getString("ex_plaza_name")
      ((start_dept, end_dept, vehicle_toll_type, en_plaza_name, ex_plaza_name), obj)
    }).groupByKey().flatMap(obj => {
      val list: List[JSONObject] = obj._2.toList
      val den_frequency: Int = list.size
      val tmpList: List[JSONObject] = list.map(json => {
        val frequency: Int = json.getIntValue("frequency")
        val rate: Double = frequency / den_frequency.toDouble
        json.put("rate", rate)
        json.put("den_frequency", den_frequency)
        json
      })
      tmpList.iterator
    })
    val qmPointDf = qmPointMidRdd.map(obj=>{
      CaseRoadBridgeBillInfo(
        obj.getString("start_dept"),
        obj.getString("start_coordinate"),
        obj.getString("end_dept"),
        obj.getString("end_coordinate"),
        obj.getString("vehicle_form"),
        obj.getString("vehicle_toll_type"),
        obj.getString("number_axes"),
        obj.getString("vehicle_length"),
        obj.getString("vehicle_weight"),
        obj.getString("etc_card_type"),
        obj.getString("en_plaza_name"),
        obj.getString("en_coordinate"),
        obj.getString("ex_plaza_name"),
        obj.getString("ex_coordinate"),
        obj.getString("discount_before_amount"),
        obj.getString("fee"),
        obj.getString("discount_fee"),
        obj.getString("frequency"),
        obj.getString("rate"),
        obj.getString("std_id"),
        obj.getString("distance"),
        obj.getString("toll_distance"),
        obj.getString("line_time"),
        obj.getString("fee_per_kilometer"),
        obj.getString("fee_per_toll_kilometer"),
        obj.getString("den_frequency")
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("路桥费账单信息数据量:"+qmPointDf.count())
    lineDistanceRdd.unpersist()
    SparkWrite.writeToHive(spark,qmPointDf,"inc_day",incDay,"dm_gis.dm_pns_road_bridge_bill_info_di",20)

  }

  def plateTrackMerge(spark: SparkSession, supplierRoadbridgeFeesMap: collection.Map[String, JSONObject], incDay: String) = {
    import spark.implicits._
    val etaStdLineRecallSql=
      s"""
        |select
        |task_id,actual_depart_tm,actual_arrive_tm,start_dept,start_longitude,start_latitude,end_dept,end_longitude,end_latitude,line_time,std_id,
        |concat(start_longitude,',',start_latitude) as start_coordinate,
        |concat(end_longitude,',',end_latitude) as end_coordinate
        |from dm_gis.eta_std_line_recall
        |where inc_day = '$incDay'
        |--limit 10000
        |""".stripMargin
    val supplierRoadbridgeFeesBc: Broadcast[collection.Map[String, JSONObject]] = spark.sparkContext.broadcast(supplierRoadbridgeFeesMap)
    val supplierJoinRecallRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, etaStdLineRecallSql, 2000).map(obj => {
      val task_id: String = obj.getString("task_id")
      val supplierRoadbridgeFeesValue: collection.Map[String, JSONObject] = supplierRoadbridgeFeesBc.value
      val rightObj: JSONObject = supplierRoadbridgeFeesValue.getOrElse(task_id, null)
      if (rightObj!=null){
        obj.fluentPutAll(rightObj)
      }
      (obj,rightObj)
    }).filter(_._2!=null).map(obj=>{
      obj._1
    }).map(obj => {
      val mload: Double = obj.getDoubleValue("mload")
      val vehicle_type: Int = obj.getIntValue("vehicle_type")
      var vehicle_form = ""
      if (mload <= 1) {
        vehicle_form = "微型货车"
      } else if (mload > 1 && mload <= 3) {
        vehicle_form = "轻型货车"
      } else if (mload > 3 && mload < 7) {
        vehicle_form = "中型货车"
      } else if (mload >= 7) {
        vehicle_form = "重型货车"
      }
      var vehicle_toll_type = ""
      var number_axes = Int.MaxValue
      var vehicle_length = Double.MaxValue
      var vehicle_weight = Int.MaxValue
      if (vehicle_type == 11) {
        vehicle_toll_type = "一类货车"
        number_axes = 2
        vehicle_length = 4.2
        vehicle_weight = 2
      } else if (vehicle_type == 12) {
        vehicle_toll_type = "二类货车"
        number_axes = 2
        vehicle_length = 6.2
        vehicle_weight = 5
      } else if (vehicle_type == 13) {
        vehicle_toll_type = "三类货车"
        number_axes = 2
        vehicle_length = 9.6
        vehicle_weight = 8
      } else if (vehicle_type == 14) {
        vehicle_toll_type = "四类货车"
        number_axes = 4
        vehicle_length = 12.5
        vehicle_weight = 12
      } else if (vehicle_type == 15) {
        vehicle_toll_type = "五类货车"
        number_axes = 5
        vehicle_length = 14
        vehicle_weight = 25
      } else if (vehicle_type == 16) {
        vehicle_toll_type = "六类货车"
        number_axes = 6
        vehicle_length = 17
        vehicle_weight = 30
      } else if (vehicle_type == 1) {
        vehicle_toll_type = "一类客车"
        number_axes = 9
        vehicle_length = 5
        vehicle_weight = 2
      } else if (vehicle_type == 2) {
        vehicle_toll_type = "二类客车"
        number_axes = 18
        vehicle_length = 5.5
        vehicle_weight = 5
      } else if (vehicle_type == 3) {
        vehicle_toll_type = "三类客车"
        number_axes = 38
        vehicle_length = 6
        vehicle_weight = 8
      } else if (vehicle_type == 4) {
        vehicle_toll_type = "四类客车"
        number_axes = 40
        vehicle_length = 6.5
        vehicle_weight = 12
      }

      obj.put("vehicle_form", vehicle_form)
      obj.put("vehicle_toll_type", vehicle_toll_type)
      obj.put("number_axes", number_axes)
      obj.put("vehicle_length", vehicle_length)
      obj.put("vehicle_weight", vehicle_weight)
      obj.put("etc_card_type", "")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("需要调历史轨迹接口的数据量:"+supplierJoinRecallRdd.count())
    val httpTrack = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "959767", "路桥费账单信息", "车牌和时间范围获取融合轨迹点", "http://gis-vms-query-new.sf-express.com:80/trackquery-new/api/integrate", "79c7c3c1d99a4e77959846626af422aa", supplierJoinRecallRdd.count(), 60)
    val returnTrackMergeRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,supplierJoinRecallRdd, SfNetInteface.trackMergeInterface, 60, "79c7c3c1d99a4e77959846626af422aa", 3000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpTrack)
    val value: RDD[JSONObject] = returnTrackMergeRdd.repartition(600).map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "ret.result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(result, "data")
      val track: JSONArray = JSONUtil.getJsonArrayMulti(data, "track")
      obj.put("track", track)
      obj.remove("ret")
      obj
    }).flatMap(obj => {
      val task_result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "task_result")
      val body: JSONArray = JSONUtil.getJsonArrayMulti(task_result, "body")
      val tmpArray = new util.ArrayList[JSONObject]()
      for (i <- 0 until (body.size())) {
        val bodyObj: JSONObject = body.getJSONObject(i)
        obj.fluentPutAll(bodyObj)
        obj.remove(task_result)
        tmpArray.add(obj)
      }
      tmpArray.iterator()
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("测试中间数据1:"+value.count())
    val trackMergeDf: DataFrame = value.map(obj => {
      CaseTrackMerge(
        obj.getString("task_id"),
        obj.getString("vehicle_type"),
        obj.getString("task_result"),
        obj.getString("mload"),
        obj.getString("plate"),
        obj.getString("actual_depart_tm"),
        obj.getString("actual_arrive_tm"),
        obj.getString("start_dept"),
        obj.getString("start_longitude"),
        obj.getString("start_latitude"),
        obj.getString("end_dept"),
        obj.getString("end_longitude"),
        obj.getString("end_latitude"),
        obj.getString("line_time"),
        obj.getString("std_id"),
        obj.getString("start_coordinate"),
        obj.getString("end_coordinate"),
        obj.getString("track"),
        obj.getString("fee"),
        obj.getString("enDateTime"),
        obj.getString("exDateTime"),
        obj.getString("enPlazaName"),
        obj.getString("exPlazaName"),
        obj.getString("exVehicleType"),
        obj.getString("vehicle_form"),
        obj.getString("vehicle_toll_type"),
        obj.getString("number_axes"),
        obj.getString("vehicle_length"),
        obj.getString("vehicle_weight"),
        obj.getString("etc_card_type"),
        obj.getString("discountFee")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,trackMergeDf,"inc_day",incDay,"dm_gis.dm_pns_track_merge_di",20)
  }

  def execute(incDay: String,endDay:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取表dm_supplier_roadbridge_fees_dtl
    val supplierRoadbridgeFeesMap = readSupplierRoadbridgeFees(spark, endDay)
    //调车辆接口返回轨迹点
    plateTrackMerge(spark,supplierRoadbridgeFeesMap,incDay)
    //关联eta_std_line_recall，生成相应标签和统计指标
    processSupplierRecall(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val endDay: String = args(1)
    logger.error("incDay:"+incDay+",endDay:"+endDay)
    execute(incDay,endDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseRoadBridgeBillInfo(
                                      start_dept:String,
                                      start_coordinate:String,
                                      end_dept:String,
                                      end_coordinate:String,
                                      vehicle_form:String,
                                      vehicle_toll_type:String,
                                      number_axes:String,
                                      vehicle_length:String,
                                      vehicle_weight:String,
                                      etc_card_type:String,
                                      en_plaza_name:String,
                                      en_coordinate:String,
                                      ex_plaza_name:String,
                                      ex_coordinate:String,
                                      discount_before_amount:String,
                                      fee:String,
                                      discount_fee:String,
                                      frequency:String,
                                      rate:String,
                                      std_id:String,
                                      distance:String,
                                      toll_distance:String,
                                      line_time:String,
                                      fee_per_kilometer:String,
                                      fee_per_toll_kilometer:String,
                                      den_frequency:String
                                   )

  case class CaseTrackMerge(
                            task_id:String,
                            vehicle_type:String,
                            task_result:String,
                            mload:String,
                            plate:String,
                            actual_depart_tm:String,
                            actual_arrive_tm:String,
                            start_dept:String,
                            start_longitude:String,
                            start_latitude:String,
                            end_dept:String,
                            end_longitude:String,
                            end_latitude:String,
                            line_time:String,
                            std_id:String,
                            start_coordinate:String,
                            end_coordinate:String,
                            track:String,
                            fee:String,
                            enDateTime:String,
                            exDateTime:String,
                            enPlazaName:String,
                            exPlazaName:String,
                            exVehicleType:String,
                            vehicle_form:String,
                            vehicle_toll_type:String,
                            number_axes:String,
                            vehicle_length:String,
                            vehicle_weight:String,
                            etc_card_type:String,
                            discountfee:String
                           )

}
