package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.base.util.StringUtils.nonEmpty
import com.sf.gis.scala.pns.utils.Functions.{doubleToPercent, isEmptyOrNull, timestampToTime, tranTimeToLong}
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import java.util.Date
import scala.collection.mutable.ArrayBuffer

/**
 * 【燃油耗能】车辆载货/自定义任务燃油管控
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：688490
 * 任务名称：车辆载货/自定义任务燃油管控
 */
object VehicleFuleConsumeDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  //val Track_Query: String = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"
  val TrackQueryUrl: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"  // 新轨迹中台迁移 20230821
  val TrackQueryAK: String = "93ec117f7f1b4226b4e537c4802319e9"
  val parallelism = 10
  val akMinuLimit = 4000

  //解析线路查询接口返回值
  def parseTrackQueryHttpData(ret: JSONObject): (String, String, Double, Double) = {
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = JSONUtil.getJsonVal(ret, "status", "")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = JSONUtil.getJsonVal(JSONUtil.getJsonObjectMulti(ret, "result"), "msg", "")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, 0.0, 0.0)
      } else {
        var distance = 0.0
        var rate = 0.0
        try{
          distance = ret.getJSONObject("result").getJSONObject("data").getDouble("len")
          rate = ret.getJSONObject("result").getJSONObject("data").getJSONObject("rate").getDouble("offTime")

        }catch {
          case e: Exception => logger.error(e)
        }
        return (codeStatue, "成功", distance, rate)
      }
    }
    ("22", "接口返回值为空", 0.0, 0.0)
  }


  /**
   * 调用轨迹查询接口,获取里程和轨迹完整率
   * @param spark
   * @param dataDF
   */
  def runTrackQueryInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val place_time = JSONUtil.getJsonLong(obj, "place_time", 0)
    val place_time2 = JSONUtil.getJsonLong(obj, "place_time2", 0)

    // 将时间戳转换成接口需要的格式
    val fm = new SimpleDateFormat("yyyyMMddHHmmss")
    val beginDateTime = fm.format(new Date(place_time))
    val endDateTime = fm.format(new Date(place_time2))

    //初始化轨迹查询接口请求参数
    val param = new JSONObject()
    param.put("compensate", "true")
    param.put("addpoint", 1)
    param.put("type", "0")
    param.put("offTime",60)
    param.put("un",vehicle_serial)
    param.put("unType","0")
    param.put("beginDateTime",beginDateTime)
    param.put("endDateTime",endDateTime)
    param.put("ak", ak)
    param.put("hasRate", "true")
    param.put("rectify", "true")

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(TrackQueryUrl,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析线路查询接口返回值
    val httpData: (String, String, Double, Double) = parseTrackQueryHttpData(retJSONObject)

    // 查询线路接口新增字段
    obj.put("distance",httpData._3)
    obj.put("rate",httpData._4)
    // 辅助字段
    obj.put("codeStatue",httpData._1)
    obj.put("msg",httpData._2)

    obj
  }

  // 获取加油订单表数据
  def getOilOrderData(spark: SparkSession, dayBefore1: String, dayBefore30: String) = {

    import spark.implicits._
    val order_sql =
      s"""
         |select
         |  order_no,  -- 订单id
         |  vehicle_serial,  --车牌
         |  place_time as place_time_old,      --下单时间
         |  inc_day
         |from
         |  ods_fyep.tt_oil_order
         |where
         |  inc_day >= '$dayBefore30'
         |  and inc_day <= '$dayBefore1'
         |  and state = 5
         |""".stripMargin
    println("获取加油订单表数据 sql语句：")
    println(order_sql)

    val df_order = spark.sql(order_sql)
      .withColumn("place_time_tm",tranTimeToLong('place_time_old,lit("yyyy-MM-dd HH:mm:ss"))) // 时间格式转时间戳
      .withColumn("rn", row_number().over(Window.partitionBy('order_no).orderBy(desc("inc_day"))))
      .filter('rn === 1)  // 按照订单id去重
      .withColumn("rn_num", row_number().over(Window.partitionBy('vehicle_serial).orderBy(desc("place_time_tm"))))
      .filter('rn_num <= 2)  // 每个车牌取最近两次加油数据
      .groupBy("vehicle_serial")
      .agg(
        max(when('rn_num === 2,'place_time_tm)) as "place_time",   //第一次加油时间
        max(when('rn_num === 1,'place_time_tm)) as "place_time2",  //第二次加油时间
        max('inc_day) as "inc_day"
      )
      .filter('inc_day === dayBefore1 && length('place_time) === 13 && !isEmptyOrNull('vehicle_serial))  // 过滤掉t-1当天没有加油订单，车牌为空和上次加油订单在t-30天之前的数据

    df_order
  }

  // 获取车辆任务数据
  def getTaskDetailData(spark: SparkSession, dayBefore1: String, dayBefore30: String) = {

    import spark.implicits._
    val dayBefore_1 = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", -2)
    // 获取载货任务数据
    val recall1_sql =
      s"""
         |select
         |  task_id,  --任务id
         |  vehicle_serial,  --车牌
         |  actual_depart_tm,  --发车时间
         |  actual_arrive_tm,  --到车时间
         |  driver_name,  --司机姓名
         |  driver_id,  --司机工号
         |  last_update_tm,
         |  inc_day,
         |  '载货任务' as type   --任务类型
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day >= '$dayBefore30'
         |  and inc_day <= '$dayBefore_1'
         |""".stripMargin
    println("获取载货任务数据 sql语句：")
    println(recall1_sql)

    val df_recall1 = spark.sql(recall1_sql)
      .withColumn("actual_depart_tm",tranTimeToLong('actual_depart_tm,lit("yyyy-MM-dd HH:mm:ss"))) // 时间格式转时间戳
      .withColumn("actual_arrive_tm",tranTimeToLong('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss"))) // 时间格式转时间戳
      .select("task_id","vehicle_serial","actual_depart_tm","actual_arrive_tm","driver_name","driver_id","last_update_tm","type")

    // 获取空驶任务数据
    val parse1_sql =
      s"""
         |select
         |  task_id,  --任务id
         |  vehicle_serial,  --车牌
         |  actual_depart_tm,  --发车时间
         |  actual_arrive_tm,  --到车时间
         |  driver_name,  --司机姓名
         |  driver_id,  --司机工号
         |  update_tm as last_update_tm,
         |  '空驶任务' as type   --任务类型
         |from
         |  dm_gis.gis_eta_ts_accural_parse1
         |where
         |  inc_day >= '$dayBefore30'
         |  and inc_day <= '$dayBefore_1'
         |  and length(task_id) > 20
         |""".stripMargin
    println("获取空驶任务数据 sql语句：")
    println(parse1_sql)


    // 获取非任务场景数据
    val non_task_sql =
      s"""
         |select
         |  '' as task_id,--任务id
         |  vehicle_serial,--车牌
         |  cast(start_time as BIGINT) * 1000 as actual_depart_tm,--发车时间
         |  cast(end_time as BIGINT) * 1000 as actual_arrive_tm,--到车时间
         |  '' as driver_name,--司机姓名
         |  sfcode as driver_id,--司机工号
         |  '' as last_update_tm,
         |  '非任务场景' as type --任务类型
         |from
         |  dm_gis.gis_eta_non_task_track_info
         |where
         |  inc_day >= '$dayBefore30'
         |  and inc_day <= '$dayBefore1'
         |  and task_type = '非任务场景'
         |""".stripMargin
    println("获取非任务场景数据 sql语句：")
    println(non_task_sql)
    val non_task_df = spark.sql(non_task_sql)
      .select("task_id","vehicle_serial","actual_depart_tm","actual_arrive_tm","driver_name","driver_id","last_update_tm","type")

    val df_task = spark.sql(parse1_sql)
      .select("task_id","vehicle_serial","actual_depart_tm","actual_arrive_tm","driver_name","driver_id","last_update_tm","type")
      .union(df_recall1)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("last_update_tm"))))
      .filter('rn === 1)  // 按照订task_id去重
      .drop("rn")
      .select("task_id","vehicle_serial","actual_depart_tm","actual_arrive_tm","driver_name","driver_id","last_update_tm","type")
      .union(non_task_df)

    df_task
  }

  // 获取副驾驶司机数据
  def getDeputyDriverData(spark: SparkSession, dayBefore1: String, dayBefore30: String) = {

    import spark.implicits._
    val dayBefore_1 = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", -2)
    // 获取副驾数据
    val deputy_sql =
      s"""
         |select
         |  task_id,  --任务id
         |  deputy_driver_account,  --副驾工号
         |  deputy_driver_name,  --副驾姓名
         |  last_update_tm
         |from
         |  dm_grd.grd_new_task_detail
         |where
         |  inc_day >= '$dayBefore30'
         |  and inc_day <= '$dayBefore_1'
         |  and state = 6
         |""".stripMargin
    println("获取副驾数据 sql语句：")
    println(deputy_sql)

    val df_deputy = spark.sql(deputy_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("last_update_tm"))))
      .filter('rn === 1)  // 按照订task_id去重
      .drop("rn","last_update_tm")

    df_deputy
  }

  // 时间间隔格式化
  def formatTimeInterval: UserDefinedFunction = udf((interval: Double) => {
    var ret: String = ""
    try {
      val time_diff = scala.math.round(interval)
      val hour = scala.math.floor(time_diff / 60).toInt
      val minute = scala.math.floor(time_diff % 60).toInt
      if(hour == 0 && minute == 0){
        ret = "0"
      }else if(hour == 0 && minute != 0){
        ret = s"${minute}M"
      }else{
        ret = s"${hour}H${minute}M"
      }

    } catch {
      case e: Exception => println("经纬度异常" + e.getMessage)
    }

    ret
  })


  def run(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore30 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 30)

    // 获取加油订单表数据
    val df_order = getOilOrderData(spark, dayBefore1,dayBefore30)
    // 获取车辆任务数据
    val df_task = getTaskDetailData(spark, dayBefore1,dayBefore30)
    // 获取副驾驶司机数据
    val df_deputy = getDeputyDriverData(spark, dayBefore1,dayBefore30)

    // 将两次加油时间差超过5天的数据拆分，分段计算里程
    val rdd_order = df_order.rdd.map(row2Json)
      .flatMap(obj=>{
        val vehicle_serial = JSONUtil.getJsonVal(obj,"vehicle_serial","")
        val inc_day = JSONUtil.getJsonVal(obj,"inc_day","")
        val place_time = JSONUtil.getJsonLong(obj, "place_time", 0)
        val place_time2 = JSONUtil.getJsonLong(obj, "place_time2", 0)

        val time_diff = (place_time2 - place_time).toDouble
        val tm_5 = 1*24*60*60*1000L  // 1天时间戳差值（毫秒）
        val j = (time_diff / tm_5).ceil.toInt

        val dataArray = new ArrayBuffer[JSONObject]()
        for(i <- 0 until j){
          val obj_new = new JSONObject()
          if(j == 1){
            dataArray.append(obj)
          }else if(i < j-1){
            obj_new.put("vehicle_serial",vehicle_serial)
            obj_new.put("inc_day",inc_day)
            obj_new.put("place_time",place_time+(tm_5)*i)
            obj_new.put("place_time2",place_time+(tm_5)*(i+1))
            dataArray.append(obj_new)
          }else if(i == j-1){
            obj_new.put("vehicle_serial",vehicle_serial)
            obj_new.put("inc_day",inc_day)
            obj_new.put("place_time",place_time+(tm_5)*i)
            obj_new.put("place_time2",place_time2)
            dataArray.append(obj_new)
          }
        }

        dataArray.iterator
      })

    val invokeCnt_1 = rdd_order.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "688490", "车辆载货/自定义任务燃油管控", "获取里程和轨迹完整率", TrackQueryUrl, TrackQueryAK, invokeCnt_1, parallelism)
    // 调标准线路查询接口
    val rdd_order_dist = SparkNet.runInterfaceWithAkLimit(spark, rdd_order, runTrackQueryInteface, parallelism, TrackQueryAK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)

    val df_order_dist = rdd_order_dist.map(obj => {
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val place_time = JSONUtil.getJsonVal(obj, "place_time", "")
      val place_time2 = JSONUtil.getJsonVal(obj, "place_time2", "")
      val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")

      val dist = JSONUtil.getJsonVal(obj, "distance", "")
      val dist_rate = JSONUtil.getJsonVal(obj, "rate", "")
      val codeStatue = JSONUtil.getJsonVal(obj, "codeStatue", "")
      val msg = JSONUtil.getJsonVal(obj, "msg", "")

      (vehicle_serial,place_time,place_time2,dist,dist_rate,codeStatue,msg,inc_day)
    }).toDF ("vehicle_serial","place_time","place_time2","dist","dist_rate","codeStatue","msg","inc_day")

    // 将分段里程合并
    val df_order_ret = df_order_dist
      .groupBy("vehicle_serial")
      .agg(
        min('place_time) as "place_time",
        max('place_time2) as "place_time2",
        sum('dist) as "dist",
        avg('dist_rate) as "dist_rate",
        max('inc_day) as "inc_day",
        concat_ws("|",collect_list('codeStatue)) as "codeStatue_1",
        concat_ws("|",collect_list('msg)) as "msg_1"
      )

    // 按车牌关联获取加油区间的所有任务数据
    val df_order_task = df_order_ret
      .join(df_task,Seq("vehicle_serial"),"left")
      .join(df_deputy,Seq("task_id"),"left")  // 关联获取副驾驶信息
      .withColumn("place_time_order",'place_time)
      .withColumn("place_time2_order",'place_time2)
      .withColumn("delete_type",when('actual_depart_tm >= 'place_time2 or 'actual_arrive_tm <= 'place_time,0).otherwise(1))  //将不在加油区间的任务打标剔除
      .withColumn("place_time",when('actual_depart_tm < 'place_time and 'actual_arrive_tm > 'place_time,'place_time).otherwise('actual_depart_tm))
      .withColumn("place_time2",when('actual_arrive_tm > 'place_time2 and 'actual_depart_tm < 'place_time2,'place_time2).otherwise('actual_arrive_tm))
      .filter('delete_type === 1) //将不在加油区间的任务剔除

    val invokeCnt_2 = df_order_task.count()
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "688490", "车辆载货/自定义任务燃油管控", "获取里程和轨迹完整率", TrackQueryUrl, TrackQueryAK, invokeCnt_2, parallelism)
    // 调标准线路查询接口
    val rdd_order_task_dist = SparkNet.runInterfaceWithAkLimit(spark, df_order_task.rdd.map(row2Json), runTrackQueryInteface, parallelism, TrackQueryAK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    // 将有主副驾驶的任务拆开成两个任务
    val df_consume_detail = rdd_order_task_dist.flatMap(obj => {
      val deputy_driver_account = JSONUtil.getJsonVal(obj, "deputy_driver_account", "")
      val deputy_driver_name = JSONUtil.getJsonVal(obj, "deputy_driver_name", "")

      val dataArray = new ArrayBuffer[JSONObject]()
      val obj_zhu = new JSONObject()
      obj_zhu.put("obj",obj)
      obj_zhu.put("driver_type","主驾")
      dataArray.append(obj_zhu)  // 主驾

      if(nonEmpty(deputy_driver_account) || nonEmpty(deputy_driver_name)){
        val obj_fu = new JSONObject()
        obj_fu.put("obj",obj)
        obj_fu.put("driver_type","副驾")
        dataArray.append(obj_fu)  //副驾
      }

      dataArray.iterator
    }).map(o=>{

      val obj = JSONUtil.getJsonObjectMulti(o, "obj")
      val driver_type = JSONUtil.getJsonVal(o, "driver_type", "")

      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val place_time = JSONUtil.getJsonLong(obj, "place_time_order", 0L)
      val place_time2 = JSONUtil.getJsonLong(obj, "place_time2_order", 0L)
      val dist = JSONUtil.getJsonDouble(obj, "dist", 0.0)
      val dist_rate = JSONUtil.getJsonVal(obj, "dist_rate", "")
      val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val actual_depart_tm = JSONUtil.getJsonLong(obj, "place_time", 0L)
      val actual_arrive_tm = JSONUtil.getJsonLong(obj, "place_time2", 0L)
      var driver_name = JSONUtil.getJsonVal(obj, "driver_name", "")
      var driver_id = JSONUtil.getJsonVal(obj, "driver_id", "")
      val deputy_driver_account = JSONUtil.getJsonVal(obj, "deputy_driver_account", "")
      val deputy_driver_name = JSONUtil.getJsonVal(obj, "deputy_driver_name", "")
      val `type` = JSONUtil.getJsonVal(obj, "type", "")
      var distance = JSONUtil.getJsonDouble(obj, "distance", 0.0)
      val rate = JSONUtil.getJsonVal(obj, "rate", "")
      val codeStatue_1 = JSONUtil.getJsonVal(obj, "codeStatue_1", "")
      val msg_1 = JSONUtil.getJsonVal(obj, "msg_1", "")
      val codeStatue_2 = JSONUtil.getJsonVal(obj, "codeStatue", "")
      val msg_2 = JSONUtil.getJsonVal(obj, "msg", "")

      // 如果有副驾驶，则里程主副驾各一半
      if(nonEmpty(deputy_driver_account) || nonEmpty(deputy_driver_name)){
        if(driver_type.equals("主驾")){
          distance = distance / 2
        }else{
          distance = distance / 2
          driver_name = deputy_driver_name
          driver_id = deputy_driver_account
        }
      }

      (vehicle_serial,place_time,place_time2,dist,dist_rate,task_id,actual_depart_tm,actual_arrive_tm,driver_name,driver_id,`type`,distance,rate,driver_type,
        codeStatue_1,msg_1,codeStatue_2,msg_2,deputy_driver_account,deputy_driver_name,inc_day)
    })
      .toDF("vehicle_serial","place_time","place_time2","dist","dist_rate","task_id","actual_depart_tm","actual_arrive_tm", "driver_name","driver_id",
        "type","distance","rate","driver_type","codeStatue_1","msg_1","codeStatue_2","msg_2","deputy_driver_account","deputy_driver_name","inc_day")
      .withColumn("task_distance", sum('distance).over(Window.partitionBy('vehicle_serial)))
      .withColumn("interval",('place_time2 - 'place_time) / (1000*60.0))
      .withColumn("task_time",('actual_arrive_tm - 'actual_depart_tm) / (1000*60.0))
      .withColumn("task_time_rt",doubleToPercent('task_time / 'interval))  // 转换成百分比，保留两位小数
      .withColumn("distance_rt",doubleToPercent('distance / 'dist))  // 转换成百分比，保留两位小数
      .withColumn("no_task_dist",'dist - 'task_distance)
      .withColumn("no_task_dist_rt",doubleToPercent('no_task_dist / 'dist))  // 转换成百分比，保留两位小数
      // 格式转换
      .withColumn("place_time",timestampToTime('place_time,lit("yyyy-MM-dd HH:mm:ss")))  // 转换成时间格式
      .withColumn("place_time2",timestampToTime('place_time2,lit("yyyy-MM-dd HH:mm:ss")))  // 转换成时间格式
      .withColumn("actual_depart_tm",timestampToTime('actual_depart_tm,lit("yyyy-MM-dd HH:mm:ss")))  // 转换成时间格式
      .withColumn("actual_arrive_tm",timestampToTime('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss")))  // 转换成时间格式
      //.withColumn("interval",round('interval,0).cast("int"))  // 时间间隔，保留两位小数，单位：分钟
      .withColumn("interval",formatTimeInterval('interval))  // 时间格式：30H20M
      .withColumn("task_time",formatTimeInterval('task_time)) // 时间格式：30H20M
      .withColumn("no_task_dist",round('no_task_dist/1000,2))  // 转换成千米，保留两位小数
      .withColumn("dist",round('dist/1000,2)) // 转换成千米，保留两位小数
      .withColumn("dist_rate",doubleToPercent('dist_rate))  // 转换成百分比，保留两位小数
      .withColumn("distance",round('distance/1000,2))  // 转换成千米，保留两位小数
      .withColumn("rate",doubleToPercent('rate))  // 转换成百分比，保留两位小数

    // 获取线下人脸识别试点车辆数据
    val df_pilot_vehicle: DataFrame = spark.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/user/01417347/upload/data/人脸识别试点车辆_20230818.csv")

    val df_ret = df_consume_detail
      .join(df_pilot_vehicle,Seq("vehicle_serial"),"left")
      .withColumn("pilot_vehicle",when('pilot_vehicle === "是","是").otherwise("否"))

    // 结果表保存至hive
    val cols_dtl = spark.sql("""select * from dm_gis.vehicle_fule_consume_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_dtl: _*),Seq("inc_day"),"dm_gis.vehicle_fule_consume_detail")

  }

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，即跑数日期
    val incDay = args(0)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016  ++++")
    // 每天更新t-3两天数据
    run(spark, dayBefore2)
    logger.error("++++++++  任务完成 20231016  ++++")

    spark.stop()
  }

}
