package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, desc, explode, lit, row_number, split, trim, when}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.text.SimpleDateFormat
import java.util.Date

import scala.collection.mutable.ArrayBuffer

/**
 *需求名称：路桥费与结算路桥费不一致验证
 *需求方：廖静文(01430321)
 *开发: 周勇(01390943)
 *任务创建时间：20230411
 *任务id：698650（每天06:10执行）
 **/
object DeviceTrackBridgeFee {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args:Array[String] )={

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    val dayvar=args(0)

    logger.info("获取原表数据，调用接口：")
    val res_data=get_data(spark,dayvar).repartition(200)

    //获取接口返回的结果表
    val traces_data=spark.sql(
      s"""
         |select * from dm_gis.dm_devicetrackbridgefee_orgdata
         |where inc_day='$dayvar'
         |""".stripMargin)
      .withColumn("hebing_str",explode(split($"hebing","[|]")))
      .withColumn("hb_strarry",split($"hebing_str","_"))
      .withColumn("ak",$"hb_strarry"(0))
      .withColumn("starta",$"hb_strarry"(1))
      .withColumn("enda",$"hb_strarry"(2))
      .withColumn("timea",$"hb_strarry"(3))
      .withColumn("errormsg",$"hb_strarry"(4))
      .withColumn("time_slot",$"hb_strarry"(5))
      .persist(StorageLevel.MEMORY_AND_DISK)

    //关联主表
    logger.info("拆分结果表关联：")
    val table_cols = spark.sql("""select * from dm_gis.dm_devicetrack_bridgefee_resultdata limit 0""").schema.map(_.name).map(col)
    val final_data2=res_data.join(traces_data,Seq("task_subid"),"left")
      .withColumn("returnmsg",when($"errormsg".isNotNull && trim($"errormsg") =!="","false").otherwise("true"))
      .withColumn("actual_run_time_tmp",$"actual_run_time"*60)
      .withColumn("time_slot_tmp1", when($"actual_run_time_tmp">=600 && $"actual_run_time_tmp"<1800,"[600-1800)").
        when($"actual_run_time_tmp">=1800 && $"actual_run_time_tmp"<3600,"[1800-3600)").
        when($"actual_run_time_tmp">=3600 && $"actual_run_time_tmp"<7200,"[3600-7200)").
        when($"actual_run_time_tmp">=7200 ,"2小时以上").otherwise(""))
      .withColumn("time_slot",when($"errormsg".like("%轨迹点为空%") || $"errormsg".like ("%查询时间范围有误%"),$"time_slot_tmp1")
        .when($"errormsg".like("%错误%") ,"错误")
        .otherwise($"time_slot"))

      .withColumn("inc_day",lit(dayvar))
      .select(table_cols: _*)

    //全量数据存dm表
    writeToHive(spark, final_data2.coalesce(10), Seq("inc_day"), "dm_gis.dm_devicetrack_bridgefee_resultdata")

    spark.close()
  }


  def get_data(spark:SparkSession,dayvar:String): DataFrame ={
    import spark.implicits._

    //标准路由监控回溯表
    val recall_data=spark.sql(s"""select task_id,start_dept,end_dept,vehicle_serial,actual_depart_tm,actual_arrive_tm,
                                 |vehicle_serial as un,actual_depart_tm as begindatetime,if_evaluate_time,line_code,
                                 |actual_arrive_tm as enddatetime,actual_run_time,transoport_level,carrier_type,task_subid,last_update_tm
                                 |from  dm_gis.eta_std_line_recall
                                 |where inc_day='$dayvar'
                                 |""".stripMargin)
      .withColumn("rank", row_number().over(Window.partitionBy("task_subid")
        .orderBy(desc("last_update_tm"))))
      .filter($"rank"===1)
      .persist(StorageLevel.MEMORY_AND_DISK)

    //护航设备明细表
    val device_hh=spark.sql(
      s"""
         |select *,carplate as un
         |from  dm_arss.dm_device_hh_dtl_di
         |where inc_day='$dayvar'
         |""".stripMargin)
      .drop("inc_day")

    //2个表关联
    val res_data=recall_data.join(device_hh,Seq("un"),"left")

    //type='0'
    val fee_data_0=recall_data.select("task_subid","un","begindatetime","enddatetime")
      .withColumn("inc_type",lit("0"))

    //type='401'
    val fee_data_401=recall_data.select("task_subid","un","begindatetime","enddatetime")
      .withColumn("inc_type",lit("401"))

    //type='1011'
    val fee_data_1011=recall_data.select("task_subid","un","begindatetime","enddatetime")
      .withColumn("inc_type",lit("1011"))

    //各type类型合并
    val fee_data=fee_data_0.union(fee_data_401).union(fee_data_1011)

    val (excutors, cores) = Spark.getExcutorInfo(spark)

    //计算并行数
    val calPartitions = excutors * cores * 3
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, fee_data, calPartitions).persist(StorageLevel.MEMORY_AND_DISK)
    val OilRdd_result=Multi_Oilpoint(spark,sql_Rdd,calPartitions)

    //结果数据计算
    val traces_data: DataFrame =OilRdd_result.map(
      obj=>{
        val ret = obj.getString( "ret")
        var task_subid=obj.getString("task_subid")
        var un=obj.getString("un")
        var begindatetime=obj.getString("begindatetime")
        var enddatetime=obj.getString("enddatetime")
        var inc_type=obj.getString("inc_type")

        val ret_json= JSON.parseObject(ret)
        var status="1"
        //val status: String = ret_json.getString("status")
        try{
          status = ret_json.getString("status")
        }catch {
          case e:Exception =>
            logger.error("轨迹缺失")
        }
        val needArr = new ArrayBuffer[String]()
        var hebing=""
        var ak=""
        var time=0L
        var start=""
        var end=""
        var time_slot=""
        var errmsg=""
        var result_hebing=""

        if (status == "0" || status==0) {
          val track = ret_json.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          val s=track.size()

          if(s>=2){
            //将起始时间加入计算
            ak=track.getJSONObject(0).getString("ak")
            start=obj.getString("begindatetime")
            end=tranTimeToStrings(track.getJSONObject(0).getString("tm").concat("000"))
            time=TimeDiffSecond(start,end)
            //errmsg=obj.getString("errmsg")

            if( time>600){time_slot=timeflag(time)
              result_hebing=
                ak.concat("_").
                  concat(start).concat("_").
                  concat(end).concat("_").
                  concat(time.toString).concat("_").
                  concat(errmsg).concat("_").
                  concat(time_slot)
              needArr.append(result_hebing)
            }
            //中间位置计算
            for(i<-0 until s-1){
              val track_i=track.getJSONObject(i)
              val tm_ak=track_i.getString("ak")
              val tm_i=track_i.getString("tm")
              val track_i_x=track_i.getString("zx")
              val track_i_y=track_i.getString("zy")
              val track_i_xy=track_i_x.concat(",").concat(track_i_y)
              val track_i1=track.getJSONObject(i+1)
              val tm_ak1=track_i1.getString("ak")
              val tm_i1=track_i1.getString("tm")
              val track_i_x1=track_i1.getString("zx")
              val track_i_y1=track_i1.getString("zy")
              val track_i_xy1=track_i_x1.concat(",").concat(track_i_y1)
              //距离
              val dis=getDistance(track_i_xy,track_i_xy1)
              //时间差：秒
              val dif_sec=TimeDiffSecond(tranTimeToStrings(tm_i.concat("000")),tranTimeToStrings(tm_i1.concat("000")))

              if(dis>=1000 && dif_sec>600){
                ak=tm_ak
                start=tranTimeToStrings(track_i.getString("tm").concat("000"))
                end=tranTimeToStrings(track_i1.getString("tm").concat("000"))
                time=TimeDiffSecond(start,end)

                if( time>600)
                {time_slot=timeflag(time)
                  result_hebing= ak.concat("_").
                    concat(start).concat("_").
                    concat(end).concat("_").
                    concat(time.toString).concat("_").
                    concat(errmsg).concat("_").
                    concat(time_slot)
                  needArr.append(result_hebing)
                }
              }
            }

            //将结尾时间加入计算
            ak=track.getJSONObject(s-1).getString("ak")
            start=tranTimeToStrings(track.getJSONObject(s-1).getString("tm").concat("000"))
            end=obj.getString("enddatetime")
            time=TimeDiffSecond(start,end)

            if( time>600){time_slot=timeflag(time)
              result_hebing=
                ak.concat("_").
                  concat(start).concat("_").
                  concat(end).concat("_").
                  concat(time.toString).concat("_").
                  concat(errmsg).concat("_").
                  concat(time_slot)
              needArr.append(result_hebing)
            }

          }
          hebing=needArr.mkString("|")
        }
        else{
          errmsg=if(ret==null) {"轨迹缺失"} else {ret}
          time_slot="轨迹缺失"
          result_hebing=
            ak.concat("_").
              concat(start).concat("_").
              concat(end).concat("_").
              concat(time.toString).concat("_").
              concat(errmsg).concat("_").
              concat(time_slot)
          needArr.append(result_hebing)
          hebing=needArr.mkString("|")}
        (task_subid,un,begindatetime,enddatetime,inc_type,hebing)
      }

    ).toDF("task_subid","un","begindatetime","enddatetime" ,"inc_type","hebing")
      .select("task_subid","inc_type","hebing")
      .withColumn("inc_day",lit(dayvar))

    //数据存dm表
    writeToHive(spark, traces_data.coalesce(15), Seq("inc_day"), "dm_gis.dm_devicetrackbridgefee_orgdata")

    return  res_data
  }

  //时间差标签
  def timeflag(timedif:Long): String ={
    if(timedif>=600 && timedif<1800){"[600-1800)"}
    else if(timedif>=1800 && timedif<3600){"[1800-3600)"}
    else if(timedif>=3600 && timedif<7200){"[3600-7200)"}
    else if(timedif>=7200){"2小时以上"}
    else {""}
  }

  //定义获取url数据
  def Oilpoint_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新接口
    //val url="http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrate"
    val url="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"
    try {

      val input_type=obj.getString("inc_type")
      val un=obj.getString("un")
      val begindatetime=obj.getString("begindatetime").replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")
      val enddatetime=obj.getString("enddatetime").replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")

      val parm_str=s"""{
                      |"type": "$input_type",
                      |"un": "$un",
                      |"unType": "0",
                      |"rectify": "false",
                      |"ak": "26c3efb97871433db3bc70cbf6ae95b5",
                      |"beginDateTime": $begindatetime,
                      |"endDateTime": $enddatetime,
                      |"hasRate": "true"
                      |}
                      |""".stripMargin

      val retStr: String = HttpInvokeUtil.sendPost(url,parm_str,5)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
      //logger.info("返回parm_str："+parm_str)
      logger.error("返回正确数据，车牌号："+un)
      //Thread.sleep(100)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret",tmp)
        obj.put("errmsg",e.getMessage)
        val un=obj.getString("un")
        logger.error("返回错误数据，车牌号："+un)
        logger.error("错误信息："+e.getMessage)
    }
    obj
  }

  //调取接口并发请求
  def Multi_Oilpoint(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"
    val httpAk="26c3efb97871433db3bc70cbf6ae95b5"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "698650", "【轨迹】路桥费与结算路桥费不一致验证",
      "调取接口的路桥费，验证结算路桥费是否一致",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, Oilpoint_url, 10, "26c3efb97871433db3bc70cbf6ae95b5", 5000)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    returnAtRDD
  }

  //定义函数存入数据
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  //计算地图距离
  def rad(d: Double): Double = d * Math.PI / 180.0

  def getDistance(x:String,y:String): Double = {
    val lng1=x.split(",")(0).toDouble
    val lat1=x.split(",")(1).toDouble
    val lng2=y.split(",")(0).toDouble
    val lat2=y.split(",")(1).toDouble

    val EARTH_RADIUS: Double = 6378.137
    val radLat1: Double = rad(lat1)
    val radLat2: Double = rad(lat2)
    val a: Double = radLat1 - radLat2
    val b: Double = rad(lng1) - rad(lng2)
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)))
    s = s * EARTH_RADIUS
    s = s * 10000d.round / 10000d
    s = s * 1000
    s
  }
  //时间戳转化：输入秒
  def tranTimeToStrings(tm:String) :String={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val tim = fm.format(new Date(tm.toLong))
    tim
  }
  //定义时间差计算：秒，str2比str1大,传入格式：2022-09-30 15:30:18，例如返回结果：300
  def TimeDiffSecond(str1: String, str2: String): Long = {
    var datedf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //转换时间戳：毫秒
    val x1 = datedf.parse(str1).getTime
    val x2 = datedf.parse(str2).getTime
    //除以1000就是秒为单位
    val x3 = (x2 - x1) / 1000
    return x3
  }
}
