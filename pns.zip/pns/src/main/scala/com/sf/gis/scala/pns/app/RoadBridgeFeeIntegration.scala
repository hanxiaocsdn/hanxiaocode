package com.sf.gis.scala.pns.app

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

/**
 **需求名称：路桥费信息整合
 **任务id：777085
 **研发：01390943周勇，需求方：01367324李小璐
 **日期：2023-07-11
 **需求背景：Sf自营车收费账单为月度，其对应的任务和轨迹量大，下载到线下处理周期长，线上处理加快迭代周期。
 **/

object RoadBridgeFeeIntegration {
  //****获取应用名称
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args:Array[String]): Unit = {
    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._

    //获取日期：上月最后一天
    val dayvar=args(0)
    //获取月份
    val monthvar = dayvar.substring(0,6)
    //取跑数T-180日期
    val dayvar180 = getdaysBeforeOrAfter(dayvar, -180)

    logger.error("接收输入变量dayvar:"+dayvar)
    logger.error("接收输入变量monthvar:"+monthvar)
    logger.error("接收输入变量dayvar180:"+dayvar180)

    //获取recall表
    val recall_data0=spark.sql(
      s"""
        |select '1' as task_type,task_id,trim(vehicle_serial) as vehicle,actual_depart_tm,actual_arrive_tm,inc_day,error_type,halfway_integrate_rate
        |from dm_gis.eta_std_line_recall
        |where substr(inc_day,0,6)='$monthvar'
        |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("vehicle","actual_depart_tm","actual_arrive_tm").orderBy(desc("inc_day"))))
      .filter($"rank"==="1")
      .drop("rank")
      .repartition(1000)

    logger.error("recall_data0数据量为："+recall_data0.count())

    //获取账单表
    val consumption_data=spark.sql(
      s"""
         |select  trim(car_no) as vehicle,
         |trim(etc_entry_date) as etc_entry_date,
         |trim(etc_entry_time) as etc_entry_time,
         |trim(etc_out_date) as etc_out_date,
         |trim(etc_out_time) as etc_out_time,
         |trim(entry_name) as entry_name,
         |trim(out_name) as out_name,
         |trim(actual_amount) as actual_amount
         |from dm_gis.dm_consumption_data_dtl
         |where substr(inc_day,0,6)='$monthvar'
         |""".stripMargin)
      .withColumn("etc_entry_time_detail",concat($"etc_entry_date",lit(" "),$"etc_entry_time"))
      .withColumn("etc_out_time_detail",concat($"etc_out_date",lit(" "),$"etc_out_time"))
      .withColumn("is_staycar",when(($"entry_name"===$"out_name" && $"etc_entry_time_detail" =!= $"etc_out_time_detail"
        && !$"entry_name".like("%站%") )|| $"etc_entry_time_detail".isNull || trim($"etc_entry_time_detail")==="","是").otherwise("否"))

    logger.error("consumption_data数据量为："+consumption_data.count())

    //本表只保留有账单的数据
    val recall_data=recall_data0.join(broadcast(consumption_data.select("vehicle").distinct()),Seq("vehicle"))
      .withColumn("flag",lit("1"))
      //index为唯一识别号
      .withColumn("index",row_number().over(Window.partitionBy("flag").orderBy(desc("actual_depart_tm"))))
      .repartition(6000)
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("recall_data数据量为："+recall_data.count())

    //获取车辆建制表，经修改迭代，需要将totalweight值传给loadweight
    val vehicle_data=spark.sql(
      s"""
         |select  trim(licenseno) as licenseno,
         |trim(licenseno) as vehicle,
         |trim(typelicense) as typelicense,
         |trim(numberofaxles) as numberofaxles,
         |trim(totalweight) as totalweight,
         |trim(network) as network,
         |trim(outerlength) as outerlength,
         |trim(outerwidth) as outerwidth,
         |trim(totalweight) as loadweight,
         |trim(emissionstandard) as emissionstandard,
         |trim(fueltype) as fueltype,
         |trim(cardtype) as cardtype,
         |trim(serialnumber) as serialnumber
         |from dm_gis.dm_vehicle_organization_dtl
         |where substr(inc_day,0,6)='$monthvar'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("vehicle").orderBy(desc("serialnumber"))))
      .filter($"rank"==="1")
      .drop("rank")
      //添加id映射
      .withColumn("vehicle_classify_id",when($"typelicense".isin("封闭货车（小轻客）","封密货车（电动小轻客）","小型汽车","小型客车"),"201")
        .when($"typelicense".isin("封闭货车（电动大轻客）","中型客车"),"202")
        .when($"numberofaxles"==="2" && $"outerlength".cast("double")<6 && $"totalweight".cast("double")<4.5,"101")
        .when($"numberofaxles"==="2" && ($"outerlength".cast("double")>=6 || $"totalweight".cast("double")>=4.5),"102")
        .when($"numberofaxles"==="3","103")
        .when($"numberofaxles"==="4","104")
        .when($"numberofaxles"==="5","105")
        .when($"numberofaxles"==="6","106")
        .otherwise("")
      )
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("vehicle_data数据量为："+vehicle_data.count())

      //recall表与账单表关联计算
    val recall_data_consumption=recall_data.join(broadcast(consumption_data),Seq("vehicle"),"left")
      .filter($"etc_entry_time_detail">=$"actual_depart_tm" && $"etc_out_time_detail"<=$"actual_arrive_tm")
      .withColumn("actual_amount",when($"actual_amount".isNull || trim($"actual_amount")==="",0).otherwise($"actual_amount").cast("double"))
      .groupBy("index")
      .agg(concat_ws("|",collect_list($"entry_name")) as "highway_start_name",
        concat_ws("|",collect_list($"out_name")) as "highway_end_name",
        sum($"actual_amount") as "total_actual_amount",
        sum(when($"is_staycar"==="是",$"actual_amount").otherwise(0.0)) as "staycar_amount",
        concat_ws("|",collect_list($"etc_entry_time_detail")) as "endatetime",
        concat_ws("|",collect_list($"etc_out_time_detail")) as "exdatetime"
      )
      .withColumn("real_amount",round($"total_actual_amount"-$"staycar_amount",2))

    logger.error("recall_data_consumption数据量为："+recall_data_consumption.count())

    //任务表
    val task_detail=spark.sql(
      s"""
         |select task_id,vehicle_serial,gc_vehicle_serial as licenseno,gc_vehicle_serial as gc_vehicle
         |from dm_grd.grd_new_task_detail
         |where inc_day>='$dayvar180' and inc_day<='$dayvar'
         |and trim(gc_vehicle_serial) !=''
         |and gc_vehicle_serial is not null
         |and state = 6
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("task_id").orderBy(desc("task_id"))))
      .filter($"rank"==="1")
      .drop("rank")
      .persist(StorageLevel.MEMORY_AND_DISK)

    //临时测试
    //  spark.sql("drop table if exists tmp_dm_gis.tmp_zy_task_detail")
    //  task_detail.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tmp_zy_task_detail")

    val task_detail1=task_detail.join(vehicle_data,Seq("licenseno"),"left")
      .select("task_id","numberofaxles","gc_vehicle")
      .withColumnRenamed("numberofaxles","gc_axis1")

    //临时测试
    //spark.sql("drop table if exists tmp_dm_gis.tmp_zy_task_detail1")
    //task_detail1.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tmp_zy_task_detail1")

    val task_detail2=task_detail.select("vehicle_serial","licenseno","task_id")
      .withColumn("rank",row_number().over(Window.partitionBy("vehicle_serial","licenseno").orderBy(desc("task_id"))))
      .filter($"rank"==="1")
      .drop("rank")
      .join(vehicle_data,Seq("licenseno"),"left")
      .groupBy("vehicle_serial")
      .agg(
        concat_ws("|",collect_list($"numberofaxles")) as "gc_axis2"
      )
      .withColumnRenamed("vehicle_serial","vehicle")

    //临时测试
    //spark.sql("drop table if exists tmp_dm_gis.tmp_zy_task_detail2")
    //task_detail2.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.tmp_zy_task_detail2")

    //行车轨迹，过滤所需要的轨迹明细
    val loc_trajectory=spark.sql(
      s"""
         |select un as vehicle,ac as accuracy,be as azimuth,sp as speed,tm as time,zx as x,zy as y,tm
         |from dm_gis.esg_gis_loc_trajectory
         |where substr(inc_day,0,6)='$monthvar'
         |""".stripMargin)
      .join(recall_data.select("vehicle"),Seq("vehicle"),"leftsemi")

    logger.error("loc_trajectory数据量为："+loc_trajectory.count())

    val loc_trajectory1=recall_data.join(loc_trajectory,Seq("vehicle"),"left")
      .withColumn("trace_tm",when($"tm".isNull || trim($"tm")==="","").otherwise(tranTimeToStrings_udf($"tm")))
      .filter($"trace_tm">=$"actual_depart_tm" && $"trace_tm"<=$"actual_arrive_tm")
      .withColumn("dis_rank", row_number().over(Window.partitionBy("index")
        .orderBy(asc("tm"))))
      .withColumn("dis_rank2",concat(lit("index"),lpad($"dis_rank",5,"0")))
      .withColumn("accuracy_tmp",concat_ws(":",lit("\"accuracy\""),$"accuracy"))
      .withColumn("azimuth_tmp",concat_ws(":",lit("\"azimuth\""),$"azimuth"))
      .withColumn("speed_tmp",concat_ws(":",lit("\"speed\""),$"speed"))
      .withColumn("time_tmp",concat_ws(":",lit("\"time\""),$"tm"))
      .withColumn("x_tmp",concat_ws(":",lit("\"x\""),$"x"))
      .withColumn("y_tmp",concat_ws(":",lit("\"y\""),$"y"))
      .withColumn("tmp",concat_ws(",",$"accuracy_tmp",$"azimuth_tmp",$"speed_tmp",$"time_tmp",$"x_tmp",$"y_tmp"))
      .withColumn("tmp2",concat(lit("{"),$"tmp",lit("}")))
      .withColumn("tmp3",concat($"dis_rank2",lit("__"),$"tmp2"))
      .groupBy("index")
      .agg(concat_ws(",",sort_array(collect_list($"tmp3"))) as "tmp4"
      )
      .withColumn("tmp5",concat(lit("{\"tracks\":["),$"tmp4",lit("]}")))
      .drop("tmp4")
      .select(col("*"), expr("regexp_replace(tmp5, 'index([0-9]{5})__', '')").as("coords")
      )
      .select("index","coords")
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("loc_trajectory1数据量为："+loc_trajectory1.count())

    //结果汇总关联,用唯一键index关联
    val res_data=recall_data
      .join(broadcast(recall_data_consumption),Seq("index"),"left")
      .withColumn("discout_amount",lit(""))
      .withColumn("fee_type",lit(""))
      .withColumn("discout_amount",lit(""))
      .withColumn("discout_amount",lit(""))
      .join(broadcast(vehicle_data),Seq("vehicle"),"left")
      .join(broadcast(task_detail1),Seq("task_id"),"left")
      .join(broadcast(task_detail2),Seq("vehicle"),"left")
      .withColumn("gc_axis",when($"gc_axis1".isNotNull && trim($"gc_axis1") =!="",$"gc_axis1").
        when($"gc_axis2".isNotNull && trim($"gc_axis2") =!="" ,$"gc_axis2").otherwise("")
      )
      .withColumn("gc_macthtype",when($"gc_axis1".isNotNull && trim($"gc_axis1") =!="","赋值真实匹配").
        when($"gc_axis2".isNotNull && trim($"gc_axis2") =!="" ,"赋值历史匹配").otherwise("")
      )
      .join(loc_trajectory1,Seq("index"),"left")
      .filter($"real_amount".isNotNull && trim($"real_amount") =!="" && $"real_amount".cast("double")>0)

    //存入dm表
    val tb_cols = spark.sql("""select * from dm_gis.dm_roadbridgefee_integration_dtl limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, res_data.coalesce(15).select(tb_cols:_*), Seq("inc_day"), "dm_gis.dm_roadbridgefee_integration_dtl")

    logger.error("执行完成")
    spark.close()

  }

  //往前推n天
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

  //时间戳转化：输入秒
  def tranTimeToStrings(tm:String) :String={
    val fm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val tm1=tm.concat("000")
    val tim = fm.format(new Date(tm1.toLong))
    tim
  }

  val tranTimeToStrings_udf=udf(tranTimeToStrings _)

}
