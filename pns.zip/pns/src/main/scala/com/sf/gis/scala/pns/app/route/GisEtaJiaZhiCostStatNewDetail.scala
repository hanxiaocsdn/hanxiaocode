package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.utils.Functions.timeToCustomTime
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

/**
 * GIS-RDS-PNS 价值线路指标监控需求V1.7
 * 需求方：刘思嘉（01420030）
 * 需求描述：根据业务方需求，通过时效管控方案识别出需要丰图进行线路评估的一二级长途干线线路，使用丰图已有功能接口找到准点率高的线路进行替换，以提高准点率。
 * @author 徐游飞（01417347）
 * 迭代更新 周勇（01390943）
 * 任务ID：691878
 * 任务名称：价值线路监控指标结果表6_2&6_22
 **/
object GisEtaJiaZhiCostStatNewDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def getSourceData(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {

    import spark.implicits._
    // 获取执行率明细表（结果表4）数据
    val jiazhi_1_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall_jiazhi_1
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |  and task_type = '1'
         |  and statistical_marker = '2'
         |""".stripMargin
    println("获取执行率明细表（结果表4）数据 sql语句：")
    println(jiazhi_1_sql)
    val df_jiazhi_1 = spark.sql(jiazhi_1_sql)

    // 获取表6_1数据
    val stat_new_sql =
      s"""
         |select
         |  line_code,
         |  vehicle_type,
         |  online_date_1,
         |  task_area_code,
         |  inc_day,
         |  diff_sum_cost_mean,
         |  diff_road_fee_mean,
         |  diff_fuel_cost_mean,
         |  diff_miles_mean,
         |  sum_cost_mean,
         |  road_fee_mean,
         |  fuel_cost_mean,
         |  miles_mean,
         |  re_sum_cost_mean,
         |  re_road_fee_mean,
         |  re_fuel_cost_mean,
         |  re_miles_mean
         |from
         |  dm_gis.gis_eta_jiazhi_cost_stat_new
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |  and diff_cost_flag in ('0','2')
         |  and 	online_date_1 != ''
         |  and 	online_date_1 is not null
         |""".stripMargin
    println("获取表6_1数据 sql语句：")
    println(stat_new_sql)
    val df_stat_new = spark.sql(stat_new_sql)
      .withColumn("online_date_1", when('online_date_1 > "20230101", 'online_date_1).otherwise("20230101"))

    // 获取表6_1数据：全量
    val stat_new_all_sql =
      s"""
         |select *
         |from
         |  dm_gis.gis_eta_jiazhi_cost_stat_new
         |where
         |  inc_day<='$dayBefore1'
         |  and diff_cost_flag in ('0','2')
         |  and online_date_1 != ''
         |  and online_date_1 is not null
         |""".stripMargin
    //conduct_type=1&diff_sum_cost_mean不为空
    println("获取表6_1数据全量 sql语句：")
    println(stat_new_all_sql)
    val df_stat_new_all = spark.sql(stat_new_all_sql)
      .withColumn("online_date_1", when('online_date_1 > "20230101", 'online_date_1).otherwise("20230101"))
      .withColumn("inc_day_new",$"inc_day")
      .drop("inc_day")

    // 获取单趟降本表_服务方数据(结果表6_1_1)：全量
    val stat_new_fee_sql =
      s"""
         |select *
         |from
         |  dm_gis.gis_eta_jiazhi_cost_stat_new_addition_fee
         |where
         |  inc_day<='$dayBefore1'
         |  and diff_cost_flag in ('0','2')
         |  and online_date_1 != ''
         |  and online_date_1 is not null
         |""".stripMargin

    println("获取表6_1_1数据 sql语句：")
    println(stat_new_fee_sql)
    val df_stat_new_fee_all = spark.sql(stat_new_fee_sql)
      .withColumn("online_date_1", when('online_date_1 > "20230101", 'online_date_1).otherwise("20230101"))
      .withColumn("inc_day_new",$"inc_day")
      .drop("inc_day")

    // 获取价值线路执行率数据
    val statistics_sql =
      s"""
         |select
         |  line_code,
         |  vehicle_type,
         |  online_date_1,
         |  task_area_code,
         |  inc_day,
         |  online_before_exe,
         |  online_before_task_num
         |from
         |  dm_gis.eta_jiazhi_exe_statistics
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println("获取价值线路执行率数据 sql语句：")
    println(statistics_sql)
    val df_statistics = spark.sql(statistics_sql)
      .groupBy("task_area_code","line_code","vehicle_type","online_date_1","inc_day")
      .agg(
        sum('online_before_exe) as "online_before_exe",
        sum('online_before_task_num) as "online_before_task_num"
      )

    // 获取油价表数据
    val fule_prices_sql =
      s"""
         |select
         |  fuel_prices,
         |  inc_day
         |from
         |  dm_gis.gis_fule_prices
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println("获取数据当天油价数据 sql语句：")
    println(fule_prices_sql)
    val df_fule_prices = spark.sql(fule_prices_sql)

    // 获取车辆油耗表数据
    val vehicle_fule_sql =
      s"""
         |select
         |  vehicle_serial,
         |  update_uint_fuel,
         |  inc_day
         |from
         |  dm_gis.gis_vehicle_fule_stat
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println("获取车辆油耗表数据数据 sql语句：")
    println(vehicle_fule_sql)
    val df_vehicle_fule = spark.sql(vehicle_fule_sql)

    (df_jiazhi_1,df_stat_new,df_stat_new_all,df_stat_new_fee_all,df_statistics,df_fule_prices,df_vehicle_fule)
  }

  def run(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)

    // 获取hive 源数据
    val (df_jiazhi_1,df_stat_new,df_stat_new_all,df_stat_new_fee_all,df_statistics,df_fule_prices,df_vehicle_fule) = getSourceData(spark, dayBefore1, dayBefore3)

    //20230420新增
    //获取表6_1全量数据
    //由于jiazhi_1表是取多天的，所以要根据inc_day汇总
    val df_ret_all = df_jiazhi_1.join(df_stat_new_all,Seq("line_code", "vehicle_type", "online_date_1", "task_area_code"), "left")
      .filter($"online_date_1"<=$"inc_day")
      .filter($"inc_day_new"<=$"inc_day")
      .groupBy("line_code", "vehicle_type", "online_date_1", "task_area_code", "inc_day")
      .agg(mean($"diff_sum_cost_mean".cast("double")) as "diff_sum_cost_mean_adjust",
        mean($"diff_road_fee_mean".cast("double")) as "diff_road_fee_mean_adjust",
        mean($"diff_fuel_cost_mean".cast("double")) as "diff_fuel_cost_mean_adjust",
        mean($"diff_miles_mean".cast("double")) as "diff_miles_mean_adjust",
        mean($"sum_cost_mean".cast("double")) as "sum_cost_mean_adjust",
        mean($"road_fee_mean".cast("double")) as "road_fee_mean_adjust",
        mean($"fuel_cost_mean".cast("double")) as "fuel_cost_mean_adjust",
        mean($"miles_mean".cast("double")) as "miles_mean_adjust",
        mean($"re_sum_cost_mean".cast("double")) as "re_sum_cost_mean_adjust",
        mean($"re_road_fee_mean".cast("double")) as "re_road_fee_mean_adjust",
        mean($"re_fuel_cost_mean".cast("double")) as "re_fuel_cost_mean_adjust",
        mean($"re_miles_mean".cast("double")) as "re_miles_mean_adjust")

    // 20230520新增
    // 获取单趟降本表_服务方数据(结果表6_1_1)
    //由于jiazhi_1表是取多天的，所以要根据inc_day汇总
    val df_ret_fee_all = df_jiazhi_1.join(df_stat_new_fee_all,Seq("line_code", "vehicle_type", "online_date_1", "task_area_code"), "left")
      .filter($"online_date_1"<=$"inc_day")
      .filter($"inc_day_new"<=$"inc_day")
      .groupBy("line_code", "vehicle_type", "online_date_1", "task_area_code", "inc_day")
      .agg(mean($"diff_sum_cost_mean_new".cast("double")) as "diff_sum_cost_mean_adjust_new",
        mean($"diff_road_fee_mean_new".cast("double")) as "diff_road_fee_mean_adjust_new",
        mean($"diff_fuel_cost_mean_new".cast("double")) as "diff_fuel_cost_mean_adjust_new",
        mean($"diff_miles_mean_new".cast("double")) as "diff_miles_mean_adjust_new",
        mean($"sum_cost_mean_new".cast("double")) as "sum_cost_mean_adjust_new",
        mean($"road_fee_mean_new".cast("double")) as "road_fee_mean_adjust_new",
        mean($"fuel_cost_mean_new".cast("double")) as "fuel_cost_mean_adjust_new",
        mean($"miles_mean_new".cast("double")) as "miles_mean_adjust_new",
        mean($"re_sum_cost_mean_new".cast("double")) as "re_sum_cost_mean_adjust_new",
        mean($"re_road_fee_mean_new".cast("double")) as "re_road_fee_mean_adjust_new",
        mean($"re_fuel_cost_mean_new".cast("double")) as "re_fuel_cost_mean_adjust_new",
        mean($"re_miles_mean_new".cast("double")) as "re_miles_mean_adjust_new")

    val df_ret = df_jiazhi_1
      .join(df_stat_new, Seq("line_code", "vehicle_type", "online_date_1", "task_area_code", "inc_day"), "left")
      .join(df_statistics, Seq("line_code", "vehicle_type", "online_date_1", "task_area_code", "inc_day"), "left")
      .withColumn("conduct_type", when('conduct_type === 1, "已执行").otherwise("未执行"))
      .withColumn("ac_is_run_ontime_std", when('ac_is_run_ontime_std === 1.0, "准点").otherwise("超时"))
      .withColumn("mload", getMload('linemload))
      .withColumn("online_flag", getOnlineFlag('online_date_1))

    // 结果表6_2保存至hive
    val cols_dtl = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_stat_new_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_ret.select(cols_dtl: _*), Seq("inc_day"), "dm_gis.gis_eta_jiazhi_cost_stat_new_detail")

    // 结果表6_22增加字段
    val df_ret2 = df_ret
      .join(df_ret_all, Seq("line_code", "vehicle_type", "online_date_1", "task_area_code", "inc_day"), "left")
      .join(df_ret_fee_all, Seq("line_code", "vehicle_type", "online_date_1", "task_area_code", "inc_day"), "left")
      .join(df_fule_prices, Seq("inc_day"), "left")
      .join(df_vehicle_fule, Seq("vehicle_serial","inc_day"), "left")
      //.withColumn("final_flag",getFinalFlag('diff_sum_cost_mean_adjust,'diff_sum_cost_mean_adjust_new))
      .withColumn("final_flag",when('diff_sum_cost_mean_adjust.isNotNull && 'diff_sum_cost_mean_adjust =!= 0.0,0)
        .when('diff_sum_cost_mean_adjust_new.isNotNull && 'diff_sum_cost_mean_adjust_new =!= 0.0,1)
        .otherwise(""))
      // 单趟降本
      .withColumn("diff_distm_final",when('final_flag === 0,'diff_miles_mean_adjust).otherwise('diff_miles_mean_adjust_new))
      .withColumn("diff_rfm_final",when('final_flag === 0,'diff_road_fee_mean_adjust).otherwise('diff_road_fee_mean_adjust_new))
      .withColumn("diff_fcm_final",'diff_distm_final * 'fuel_prices * 'update_uint_fuel / 100)
      .withColumn("diff_scm_final",'diff_fcm_final + 'diff_rfm_final)
      // 对照成本
      .withColumn("re_dist_final",when('final_flag === 0,'re_miles_mean_adjust).otherwise('re_miles_mean_adjust_new))
      .withColumn("re_rfm_final",when('final_flag === 0,'re_road_fee_mean_adjust).otherwise('re_road_fee_mean_adjust_new))
      .withColumn("re_fcm_final",'re_dist_final * 'fuel_prices * 'update_uint_fuel / 100)
      .withColumn("re_scm_final",'re_fcm_final + 're_rfm_final)
      // 执行成本
      .withColumn("distm_final",when('final_flag === 0,'miles_mean_adjust).otherwise('miles_mean_adjust_new))
      .withColumn("rfm_final",when('final_flag === 0,'road_fee_mean_adjust).otherwise('road_fee_mean_adjust_new))
      .withColumn("fcm_final",'distm_final * 'fuel_prices * 'update_uint_fuel / 100)
      .withColumn("scm_final",'fcm_final + 'rfm_final)

    // 结果表6_22保存至hive
    val cols_dtl2 = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_stat_new_detail2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_ret2.select(cols_dtl2: _*), Seq("inc_day"), "dm_gis.gis_eta_jiazhi_cost_stat_new_detail2")

  }

  /**
   * adjust 和 adjust_new 按顺序选择非空非0的值
   * @return
   */
  def getFinalField = udf((adjust: Double,adjust_new: Double) => {
    var ret_final = 0.0
    if(adjust != null && adjust != 0){
      ret_final = adjust
    }else if (adjust_new != null && adjust_new != 0){
      ret_final = adjust_new
    }

    ret_final
  })

  /**
   * adjust 和 adjust_new 按顺序选择非空非0的值
   * @return
   */
  def getFinalFlag = udf((adjust: Double,adjust_new: Double) => {
    var ret_final = ""
    if(adjust != null || adjust_new != null){
      if(adjust != null && adjust != 0){
        ret_final = "0"
      }else if (adjust_new != null && adjust_new != 0){
        ret_final = "1"
      }
    }

    ret_final
  })

  /**
   * 将online_date_1上线时间映射成中文
   * @return
   */
  def getOnlineFlag = udf((online_date: String) => {
    var online_flag = ""
    if(online_date != null && online_date.trim != ""){
      if(online_date.equals("20230101")){
        online_flag = "2022年上线"
      }else{
        val time = timeToCustomTime(online_date, "yyyyMMdd", "yyyy-MM-dd").split("-")
        val year = time(0)
        val month = time(1)
        online_flag = s"${year}年${month}月上线"
      }
    }
    online_flag
  })

  /**
   * 将linemload按_分割，取最后一个
   * @return
   */
  def getMload = udf((linemload: String) => {
    var mload = ""
    if(linemload != null && linemload.trim != ""){
      val arr1 = linemload.split("_")
      if(arr1.length != 0) mload = arr1(arr1.length-1)
    }
    mload
  })

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，即跑数日期
    val incDay = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始20230407  ++++")
    run(spark, incDay)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()

  }
}
