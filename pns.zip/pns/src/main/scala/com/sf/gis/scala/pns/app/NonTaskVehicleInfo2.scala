package com.sf.gis.scala.pns.app


import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.app.NonTaskVehicleInfo.sortField
import com.sf.gis.scala.pns.utils.Functions.isEmptyOrNull
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 * 【燃油耗能】车辆载货/自定义任务燃油管控V1.1
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：789419
 * 任务名称：非任务场景下轨迹明细_关联人脸识别结果
 */
object NonTaskVehicleInfo2 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )


  def getGisEtaNonTaskTrackInfo2(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)

    // 获取人脸识别入参数据
    val track_info_sql =
      s"""
         |select
         |  vehicle_serial,
         |  task_id,
         |  coords,
         |  task_type,
         |  start_time,
         |  end_time,
         |  distance,
         |  task_time,
         |  hq_code,
         |  hq_name,
         |  area_code,
         |  area_name,
         |  motorcade_name,
         |  inc_day
         |from
         |  dm_gis.gis_eta_non_task_track_info
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("获取人脸识别入参数据 sql语句：")
    println(track_info_sql)
    val df_track_info = spark.sql(track_info_sql)

    // 获取人脸识别结果
    val face_img_sql =
      s"""
         |select
         |  record_id,
         |  sfcode,
         |  score
         |from
         |  dm_gis.tt_fengtu_face_img
         |where
         |  inc_day = '$dayBefore1'
         |  and result <> ''
         |  and result is not null
         |  and sfcode <> ''
         |  and sfcode is not null
         |""".stripMargin
    println("获取人脸识别结果数据 sql语句：")
    println(face_img_sql)
    val df_face_img = spark.sql(face_img_sql)

    // 获取人脸识别入参数据
    val push_detail_sql =
      s"""
         |select
         |  car_no as vehicle_serial,
         |  start_time,
         |  end_time,
         |  record_id
         |from
         |  dm_gis.plan_face_recognition_push_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println("获取人脸识别图片推送明细表数据 sql语句：")
    println(push_detail_sql)

    val df_push_detail = spark.sql(push_detail_sql)
      .join(df_face_img,Seq("record_id"),"left")
      .withColumn("score_double",when(isEmptyOrNull('score),0.0).otherwise('score.cast("double")))
      .withColumn("num", row_number().over(Window.partitionBy('vehicle_serial,'start_time,'end_time).orderBy(desc("score_double"))))
      .groupBy("vehicle_serial","start_time","end_time")
      .agg(
        max(when('num === 1, 'sfcode).otherwise(0)) as "sfcode",
        max(when('num === 1, 'score).otherwise(0)) as "score",

        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('sfcode)) as "sfcode1",
        concat_ws("|",collect_list('score)) as "score1"
      )
      .withColumn("sfcode1",sortField('num,'sfcode1))
      .withColumn("score1",sortField('num,'score1))
      .drop("num")

    // 人脸识别入参数据关联结果数据
    val df_ret = df_track_info
      .join(df_push_detail,Seq("vehicle_serial","start_time","end_time"),"left")

    // 结果表保存至hive
    val cols_ret = spark.sql("""select * from dm_gis.gis_eta_non_task_track_info limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_ret: _*),Seq("inc_day"),"dm_gis.gis_eta_non_task_track_info")

//    // 结果表保存至hive
//    val cols_ret = spark.sql("""select * from dm_gis.gis_eta_non_task_track_info_tmp limit 0""").schema.map(_.name).map(col)
//    writeToHive(spark,df_ret.select(cols_ret: _*),Seq("inc_day"),"dm_gis.gis_eta_non_task_track_info_tmp")

  }

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，即跑数日期
    val incDay = args(0)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始  20231019  ++++")

    // 每天更新t-3两天数据,人脸识别入参数据关联识别结果
     getGisEtaNonTaskTrackInfo2(spark, dayBefore2)  // 跑T-3

    logger.error("++++++++  任务完成  20231019  ++++")

    spark.stop()
  }

}
