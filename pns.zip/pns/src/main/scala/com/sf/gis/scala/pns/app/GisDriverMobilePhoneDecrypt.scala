package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{col, lit}

/**
 * GIS-RSS-PNS:【路径规划系统】 用反司机电话解密需求
 * 需求方：马荣（ft80006356）
 * @author 徐游飞（01417347）
 * 任务ID：696882(已下线)
 * 任务名称：司机电话解析
 */
object GisDriverMobilePhoneDecrypt {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val CHECK_URL: String = s"http://gis-int2.int.sfdc.com.cn:1080/tals/tals/normalized?ak=%s&tel=%s&cityCode=&isCheckCc=true"

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    // 获取线下待解密数据
    val df_original: DataFrame = spark.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("hdfs://sfbdp1/user/ft80006356/upload/driverID22.csv")

    // 调用标准线路线路更新接口
    val updateLineRDD = SparkNet.runInterfaceWithAkLimit(spark, df_original.rdd.map(row2Json), runCheckCcInteface, 10, "d83f7e6e87774f8c8adeac798664398e", 2000)

    import spark.implicits._
    val df_ret = updateLineRDD.map(obj=>{
      val driver_id = JSONUtil.getJsonVal(obj,"driver_id","")
      val driver_name = JSONUtil.getJsonVal(obj,"driver_name","")
      val main_driver_mobilephone = JSONUtil.getJsonVal(obj,"decrypt_tel","")

      (driver_id,driver_name,main_driver_mobilephone)
    }).toDF("driver_id","driver_name","main_driver_mobilephone")
      .withColumn("inc_day",lit(incDay))

    val ret_cols = spark.sql("""select * from dm_gis.gis_driver_mobilephone_decrypt_dt limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(ret_cols: _*),Seq("inc_day"),"dm_gis.gis_driver_mobilephone_decrypt_dt")

  }

  /**
   * 调电话解密接口
   * @param spark
   * @param dataDF
   */
  def runCheckCcInteface(ak:String, obj: JSONObject): JSONObject = {

    val tel = JSONUtil.getJsonVal(obj,"main_driver_mobilephone","")
    val driver_id = JSONUtil.getJsonVal(obj,"driver_id","")

    var retJSONObject = new JSONObject()
    var infos_str = ""
    var decrypt_tel = ""
    try {
      val start_url = String.format(CHECK_URL, ak, tel)
      infos_str = HttpInvokeUtil.sendGet(start_url, "UTF-8", 3)
      retJSONObject = JSON.parseObject(infos_str)
      decrypt_tel = retJSONObject.getJSONObject("result").getJSONArray("tels").getJSONObject(0).getString("tel")

    } catch {
      case e: Exception => logger.error(s"$driver_id and $tel 返回信息有异常" + e.getMessage)
    }

    obj.put("decrypt_tel",decrypt_tel)
    obj
  }


}
