package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer

/**
 * 路径规划-货运里程和时长计算_V1.0
 * 需求方：陈俊璋（01432447）
 * @author 徐游飞（01417347）
 * 任务ID：965243(已下线)
 * 任务名称：货运里程和时长计算
 */
object GetDistanceTestGD2 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  //val url: String = "http://gis-apis.int.sfcloud.local:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&ak=05c604d8aa0e417ba5fac98245dec5a7&opt=gd1&Vehicle=8&size=16.5&mload=36&axleNumber=4&planDate=202401050600"
  val url: String = "http://gis-apis.int.sfcloud.local:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&Vehicle=%s&size=%s&mload=%s&axleNumber=%s&planDate=%s&ak=05c604d8aa0e417ba5fac98245dec5a7&opt=gd2"

  def nonEmpty(str: String): Boolean = {
    str != null && !str.isEmpty
  }

  def execute(spark: SparkSession, inc_day: String) = {
    import spark.implicits._

    val df_data = spark.read
      .format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .option("inferSchema", "true")
      .load(s"/user/01417347/upload/data/test_$inc_day.csv")

    df_data.printSchema()
    println("partitions = " + df_data.rdd.getNumPartitions)
    println(s"test_$inc_day.csv 数据量 =" + df_data.count())
    df_data.show(2,false)

    val df_ret = df_data.rdd.map(row2Json)
      .repartition(300)
      .map(obj => {
        val line_sect = JSONUtil.getJsonVal(obj, "line_sect", "")
        val start_dept_name = JSONUtil.getJsonVal(obj, "start_dept_name", "")
        val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
        val start_name_simp = JSONUtil.getJsonVal(obj, "start_name_simp", "")
        val start_name_site = JSONUtil.getJsonVal(obj, "start_name_site", "")
        val start_port = JSONUtil.getJsonVal(obj, "start_port", "")
        val start_address = JSONUtil.getJsonVal(obj, "start_address", "")
        val x1 = JSONUtil.getJsonVal(obj, "x1", "")
        val y1 = JSONUtil.getJsonVal(obj, "y1", "")
        val end_dept_name = JSONUtil.getJsonVal(obj, "end_dept_name", "")
        val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
        val end_name_simp = JSONUtil.getJsonVal(obj, "end_name_simp", "")
        val end_name_site = JSONUtil.getJsonVal(obj, "end_name_site", "")
        val end_port = JSONUtil.getJsonVal(obj, "end_port", "")
        val end_address = JSONUtil.getJsonVal(obj, "end_address", "")
        val x2 = JSONUtil.getJsonVal(obj, "x2", "")
        val y2 = JSONUtil.getJsonVal(obj, "y2", "")
        val direction = JSONUtil.getJsonVal(obj, "direction", "")
        val is_same_direct = JSONUtil.getJsonVal(obj, "is_same_direct", "")
        val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")
        val length = JSONUtil.getJsonVal(obj, "length", "")
        val mload = JSONUtil.getJsonVal(obj, "mload", "")
        val plan_time = JSONUtil.getJsonVal(obj, "plan_time", "")
        val axlenumber = JSONUtil.getJsonVal(obj, "axlenumber", "")
        val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
        val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
        val linevehicle = JSONUtil.getJsonVal(obj, "linevehicle", "")

        val urls = String.format(url, x1,y1,x2,y2,vehicle_type,length,mload,axlenumber,actual_depart_tm)
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)

        val ret = response

        var status = ""
        var dist = ""
        var time = ""
        var coords = ""
        if (nonEmpty(response)) {
          var jsonObj = try {
            JSON.parseObject(response)
          } catch {
            case e: Exception => {
              logger.error("error url ----->" + urls + "  error data --->" + response)
              new JSONObject()
            }
          }

          val result = JSONUtil.getJSONObject(jsonObj, "result")
          dist = JSONUtil.getJsonVal(result, "dist", "")
          time = JSONUtil.getJsonVal(result, "time", "")
          status = JSONUtil.getJsonVal(jsonObj, "status", "")
          val coords_arr = JSONUtil.getJsonArrayMulti(result, "coords" )

          val tmp_arr = new ArrayBuffer[String]()
          for(i <- 0 until(coords_arr.size())){
            val x = coords_arr.getJSONArray(i).getString(0)
            val y = coords_arr.getJSONArray(i).getString(1)
            tmp_arr.append(s"$x,$y")
          }

          coords = tmp_arr.mkString("|")
        }

        Test11(line_sect,start_dept_name,start_dept, start_name_simp, start_name_site, start_port, start_address, x1, y1,end_dept_name,
          end_dept, end_name_simp, end_name_site, end_port, end_address, x2, y2, direction, is_same_direct,vehicle_type, length, mload,
          plan_time, axlenumber, actual_depart_tm, line_code, linevehicle, urls, ret, dist, time, status, coords)
      }).toDF()
      .withColumn("inc_day",lit(inc_day))

    df_ret.printSchema()
    df_ret.select("line_code","linevehicle","dist","time","status","coords").show(1,false)

    // 将已推送数据追加写入结果表
    val cols = spark.sql("""select * from dm_gis.dm_gd_distance_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols: _*),Seq("inc_day"),"dm_gis.dm_gd_distance_di")

  }

  case class Test11(
                     line_sect: String,
                     start_dept_name: String,
                     start_dept: String,
                     start_name_simp: String,
                     start_name_site: String,
                     start_port: String,
                     start_address: String,
                     x1: String,
                     y1: String,
                     end_dept_name: String,
                     end_dept: String,
                     end_name_simp: String,
                     end_name_site: String,
                     end_port: String,
                     end_address: String,
                     x2: String,
                     y2: String,
                     direction: String,
                     is_same_direct: String,
                     vehicle_type: String,
                     length: String,
                     mload: String,
                     plan_time: String,
                     axlenumber: String,
                     actual_depart_tm: String,
                     line_code: String,
                     linevehicle: String,
                     url: String,
                     ret: String,
                     dist: String,
                     time: String,
                     status: String,
                     coords: String
                   )

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20240112  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
