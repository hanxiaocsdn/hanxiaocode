package com.sf.gis.scala.pns.app.valueLine

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.app.valueLine.StandardLineNewPrecept.getDfMloadStd
import org.apache.log4j.Logger

/**
 * GIS-RSS-PNS：【价值线路】筛选工艺流程线上化需求——旧方案
 * 需求方：刘俊荣（ft80006349）
 * @author 徐游飞（01417347）
 * 任务ID：926794
 * 任务名称：筛选工艺流程线上化_旧方案部分—4
 */
object StandardLineNewPrecept_old4 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val dayBefore1 = args(0)
    val dayBefore31 = args(1)
    val month = args(2)
    val monthBefore1 = args(3)
    //日期检查
    logger.error("DayBefore1="+dayBefore1)
    logger.error("dayBefore31="+dayBefore31)
    logger.error("month="+month)
    logger.error("monthBefore1="+monthBefore1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231207 ++++")
    // 获取过滤掉接口返回异常后的任务数据
    val df_mload_trackDF_filter = spark.sql(s"select * from dm_gis.mload_track_filter_detail where inc_day = '$dayBefore1'")
    // 获取标准线路关联pass配置后数据
    val df_mload = spark.sql(s"select * from dm_gis.df_mload_detail where inc_day = '$dayBefore1'")
    // 7.3.4 统计成本
    getDfMloadStd(spark,df_mload_trackDF_filter,df_mload,dayBefore1)

    logger.error("++++++++  任务结束  ++++")
    spark.stop()
  }
}
