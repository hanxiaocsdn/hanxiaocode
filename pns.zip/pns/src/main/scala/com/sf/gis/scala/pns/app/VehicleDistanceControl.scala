package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.pns.app.VehicleFuleConsumeDetail.parseTrackQueryHttpData
import com.sf.gis.scala.pns.utils.Functions.{timeToCustomTime, timestampToTime, tranTimeToLong}
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable.ArrayBuffer

/**
 * 【燃油耗能】
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：915285
 * 任务名称：车辆载货/空驶/无任务场景下里程监控
 */
object VehicleDistanceControl {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val TrackQueryUrl: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"  // 新轨迹中台迁移 20230821
  val TrackQueryAK: String = "93ec117f7f1b4226b4e537c4802319e9"
  val parallelism = 10
  val akMinuLimit = 2000

  def getDataSource(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    val inc_month = incDay.substring(0,6)
    val monthBefore1 = DateUtil.getMouthBefore(incDay, 1).substring(0,6)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)

    // 获取车辆数据
    val vehicle_sql =
      s"""
         |select
         |  vehicle_code  as  vehicle_serial,
         |  vehicle_ton,
         |  vehicle_brand_wheelbase,
         |  area_name,
         |  area_code,
         |  motorcade_name,
         |  count(*) cnt
         |from
         |  dm_tdsp.dm_tp_grd_fuel_park_urgent_fuel_explode_mi
         |where
         |  inc_month in (
         |    select
         |      max(inc_month) inc_month
         |    from
         |      dm_tdsp.dm_tp_grd_fuel_park_urgent_fuel_explode_mi
         |    where
         |      inc_month >= '$monthBefore1'
         |  )
         |group by
         |  vehicle_code,
         |  vehicle_ton,
         |  vehicle_brand_wheelbase,
         |  area_name,
         |  area_code,
         |  motorcade_name
         |""".stripMargin
    println("车辆表（主表）：")
    println(vehicle_sql)
    val df_vehicle = spark.sql(vehicle_sql).drop("cnt")

    // 空驶任务
    val customize_sql =
      s"""
         |select
         |  concat(	dept_code,'',serial)  as  task_id,
         |  vehicle_code            as  vehicle_serial,
         |  created_datetime        as  actual_depart_tm,
         |  ''                      as  actual_arrive_tm,
         |  ''                      as  actual_run_time,
         |  ''                      as  driver_name,
         |  user_name               as  main_driver_account,
         |  '否'                    as  type,
         |  ''                      as  drive_start_time,
         |  ''                      as  drive_end_time,
         |  origin_code             as  src_zone_code,
         |  destination_code        as  dest_zone_code,
         |  ''                      as  dist,
         |  ''                      as  all_dist,
         |  ''                      as  accrual_dist,
         |  ''                      as  line_distance,
         |  ''                      as  rt_dist,
         |  ''                      as  log_dist,
         |  ''                      as  actual_arrive_date,
         |  '空驶任务'               as  task_id_type
         |from
         |  ods_shiva_ground.tt_customize_task
         |where
         |  inc_day = '$dayBefore1'
         |  and task_state = '3'
         |""".stripMargin
    println("空驶任务：")
    println(customize_sql)
    val df_customize = spark.sql(customize_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("actual_depart_tm"))))
      .filter('rn === 1)  // 按照订单id去重
      .drop("rn")

    // 载货任务
    val task_sql =
      s"""
         |select
         |  task_id                 as  task_id,
         |  vehicle_serial          as  vehicle_serial,
         |  actual_depart_tm        as  actual_depart_tm,
         |  actual_arrive_tm        as  actual_arrive_tm,
         |  actual_run_time         as  actual_run_time,
         |  driver_name             as  driver_name,
         |  main_driver_account     as  main_driver_account,
         |  '否'                    as  type,
         |  ''                      as  drive_start_time,
         |  ''                      as  drive_end_time,
         |  src_zone_code           as  src_zone_code,
         |  dest_zone_code          as  dest_zone_code,
         |  ''                      as  dist,
         |  ''                      as  all_dist,
         |  ''                      as  accrual_dist,
         |  ''                      as  line_distance,
         |  ''                      as  rt_dist,
         |  ''                      as  log_dist,
         |  ''                      as  actual_arrive_date,
         |  '载货任务'               as  task_id_type
         |from
         |  dwd_o.dwd_tp_grd_task_dtl_di
         |where
         |  inc_day = '$dayBefore1'
         |  and carrier_type = '0'
         |  and state = '6'
         |""".stripMargin
    println("载货任务：")
    println(task_sql)
    val df_task = spark.sql(task_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("actual_arrive_tm"))))
      .filter('rn === 1)  // 按照订单id去重
      .drop("rn")

    // 无任务
    val non_task_sql =
      s"""
         |select
         |  task_id                      as  task_id,
         |  vehicle_serial               as  vehicle_serial,
         |  start_time                   as  actual_depart_tm,
         |  end_time                     as  actual_arrive_tm,
         |  ''                           as  actual_run_time,
         |  ''                           as  driver_name,
         |  sfcode                       as  main_driver_account,
         |  '否'                         as  type,
         |  ''                           as  drive_start_time,
         |  ''                           as  drive_end_time,
         |  ''                           as  src_zone_code,
         |  ''                           as  dest_zone_code,
         |  round(distance / 1000 ,2)    as  dist,
         |  round(distance / 1000 ,2)    as  all_dist,
         |  round(distance / 1000 ,2)    as  accrual_dist,
         |  round(distance / 1000 ,2)    as  line_distance,
         |  round(distance / 1000 ,2)    as  rt_dist,
         |  ''                           as  log_dist,
         |  ''                           as  actual_arrive_date,
         |  '无任务'                      as  task_id_type
         |from
         |  dm_gis.gis_eta_non_task_track_info
         |where
         |  inc_day = '$dayBefore3'
         |  and task_type = '非任务场景'
         |""".stripMargin
    println("非任务场景：")
    println(non_task_sql)
    val df_non_task = spark.sql(non_task_sql)
      .withColumn("actual_depart_tm",timestampToTime('actual_depart_tm.cast("Long")*1000,lit("yyyy-MM-dd HH:mm:ss")))
      .withColumn("actual_arrive_tm",timestampToTime('actual_arrive_tm.cast("Long")*1000,lit("yyyy-MM-dd HH:mm:ss")))
      .withColumn("drive_id",lit(""))

    // 获取计提数据
    val nostop_sql =
      s"""
         |select
         |  task_id,
         |  accrual_dist as accrual_dist_jt,
         |  line_distance as line_distance_jt,
         |  rt_dist as rt_dist_jt,
         |  log_dist as log_dist_jt,
         |  actual_arrive_tm as actual_arrive_tm_jt
         |from
         |  dm_gis.eta_std_line_nostop_all
         |where
         |  inc_day >= '$dayBefore2'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println("自营任务计提信息表：")
    println(nostop_sql)
    val df_nostop = spark.sql(nostop_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("actual_arrive_tm_jt"))))
      .filter('rn === 1)  // 按照订单id去重
      .drop("rn")

    // 获取双驾数据
    val driving_sql =
      s"""
         |select
         |  task_id,
         |  drive_tms,
         |  drive_members,
         |  end_tm
         |from
         |  ods_vms.tt_vms_driving_log_item
         |where
         |  inc_month >= '$monthBefore1'
         |  and inc_month <= '$inc_month'
         |  and task_id <> ''
         |  and task_id <> 'null'
         |  and task_id is not null
         |""".stripMargin
    println("双驾表：")
    println(driving_sql)
    val df_driving = spark.sql(driving_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("end_tm"))))
      .filter('rn === 1)  // 按照订单id去重
      .drop("rn","end_tm")

    (df_vehicle,df_customize,df_task,df_non_task,df_nostop,df_driving)
  }

  /**
   * 调用轨迹查询接口,获取里程和轨迹完整率
   * @param spark
   * @param dataDF
   */
  def runTrackQueryInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val drive_start_time = JSONUtil.getJsonVal(obj, "drive_start_time", "")
    val drive_end_time = JSONUtil.getJsonVal(obj, "drive_end_time", "")

    // 将时间戳转换成接口需要的格式
    val beginDateTime = timeToCustomTime(drive_start_time, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
    val endDateTime = timeToCustomTime(drive_end_time, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")

    //初始化轨迹查询接口请求参数
    val param = new JSONObject()
    param.put("compensate", "true")
    param.put("addpoint", 1)
    param.put("type", "0")
    param.put("offTime",60)
    param.put("un",vehicle_serial)
    param.put("unType","0")
    param.put("beginDateTime",beginDateTime)
    param.put("endDateTime",endDateTime)
    param.put("ak", ak)
    param.put("hasRate", "true")
    param.put("rectify", "true")

    var retJSONObject = new JSONObject()
    if(beginDateTime != "" && endDateTime != ""){
      try {
        val retStr: String = HttpInvokeUtil.sendPost(TrackQueryUrl,param.toJSONString,3)
        retJSONObject = JSON.parseObject(retStr)
      } catch {
        case e: Exception => logger.error(e)
      }
    }
    //解析线路查询接口返回值
    val httpData: (String, String, Double, Double) = parseTrackQueryHttpData(retJSONObject)

    // 查询线路接口新增字段
    obj.put("distance",httpData._3)
    obj.put("rate",httpData._4)
    // 辅助字段
    obj.put("param",param.toJSONString)
    obj.put("codeStatue",httpData._1)
    obj.put("msg",httpData._2)

    obj
  }

  // 判断是否双驾
  def isDoubleDriver = udf((drive_tms: String,drive_members: String) => {
    var `type` = "否"
    if(drive_tms != null && drive_tms.trim != "" && drive_members != null && drive_members.trim != ""){

      val drive_tm_arr = drive_tms.split(";")
      val drive_id_arr = drive_members.split(";")
      if(drive_tm_arr.length > 1 && drive_tm_arr.length == drive_id_arr.length) `type` = "是"
    }
    `type`
  })

  def run(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    // 获取加油订单表数据
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val (df_vehicle,df_customize,df_task,df_non_task,df_nostop,df_driving) = getDataSource(spark, incDay)

    // 载货任务
    val df_zaihuo = df_vehicle.join(df_task, Seq("vehicle_serial"), "inner")
    // 空驶任务
    val df_kongshi = df_vehicle.join(df_customize, Seq("vehicle_serial"), "inner")
    // 空驶载货任务合并，判断是否双驾
    val df_task_all = df_zaihuo.union(df_kongshi).join(df_driving, Seq("task_id"), "left")
      .withColumn("type",isDoubleDriver('drive_tms,'drive_members)) // 判断是否双驾
    // 无任务场景
    val df_no_task = df_vehicle.join(df_non_task, Seq("vehicle_serial"), "inner")
      .select("vehicle_serial","vehicle_ton","vehicle_brand_wheelbase","area_name","area_code","motorcade_name","task_id_type","task_id",
        "actual_depart_tm","actual_arrive_tm","actual_run_time","driver_name","main_driver_account","type","drive_id","drive_start_time","drive_end_time","src_zone_code",
        "dest_zone_code","dist","all_dist","accrual_dist", "line_distance","rt_dist","log_dist","actual_arrive_date")
    // 单驾驶员任务
    val df_single_driver = df_task_all.filter('type === "否")
      .join(df_nostop,Seq("task_id"), "inner")
      .withColumn("actual_arrive_tm",when('task_id_type === "空驶任务",'actual_arrive_tm_jt).otherwise('actual_arrive_tm))
      .withColumn("drive_id",lit(""))
      .withColumn("dist",round('accrual_dist_jt.cast("double") / 1000,2))
      .withColumn("all_dist",round('accrual_dist_jt.cast("double") / 1000,2))
      .withColumn("accrual_dist",round('accrual_dist_jt.cast("double") / 1000,2))
      .withColumn("line_distance",round('line_distance_jt.cast("double") / 1000,2))
      .withColumn("rt_dist",round('rt_dist_jt.cast("double") / 1000,2))
      .withColumn("log_dist",'log_dist_jt)
      .select("vehicle_serial","vehicle_ton","vehicle_brand_wheelbase","area_name","area_code","motorcade_name","task_id_type","task_id",
        "actual_depart_tm","actual_arrive_tm","actual_run_time","driver_name","main_driver_account","type","drive_id","drive_start_time","drive_end_time","src_zone_code",
        "dest_zone_code","dist","all_dist","accrual_dist", "line_distance","rt_dist","log_dist","actual_arrive_date")

    // 双驾驶员任务里程拆分
    val rdd_double_drive = df_task_all.filter('type === "是")
      //.filter('vehicle_serial === "云A01RF6")
      .rdd.map(row2Json).flatMap(obj=>{
      var drive_tms = JSONUtil.getJsonVal(obj, "drive_tms", "")
      val drive_members = JSONUtil.getJsonVal(obj, "drive_members", "")
      val main_driver_account = JSONUtil.getJsonVal(obj, "main_driver_account", "")
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
      val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")

      val drive_arr = new ArrayBuffer[JSONObject]()
      if(drive_tms.isEmpty){
        val obj_tmp = new JSONObject()
        obj.put("drive_id",main_driver_account)
        obj_tmp.put("data_obj",obj)
        obj_tmp.put("vehicle_serial",vehicle_serial)
        obj_tmp.put("drive_start_time",actual_depart_tm)
        obj_tmp.put("drive_end_time",actual_arrive_tm)
        obj_tmp.put("drive_id",main_driver_account)
        drive_arr.append(obj_tmp)

      }else{
        drive_tms = s"$drive_tms;$actual_arrive_tm"
        val drive_tm_arr = drive_tms.split(";")
        val drive_id_arr = drive_members.split(";")

        for(i <- 0 until drive_tm_arr.length-1){
          val obj_tmp = new JSONObject()
          val drive_start_time = drive_tm_arr(i)
          val drive_end_time = drive_tm_arr(i+1)
          val drive_id = drive_id_arr(i)
          obj.put("drive_id",drive_id)
          obj_tmp.put("data_obj",obj)
          obj_tmp.put("vehicle_serial",vehicle_serial)
          obj_tmp.put("drive_start_time",drive_start_time)
          obj_tmp.put("drive_end_time",drive_end_time)
          obj_tmp.put("drive_id",drive_id)

          drive_arr.append(obj_tmp)
        }
      }
      drive_arr.iterator
    })

    val invokeCnt_1 = rdd_double_drive.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "915285", "车辆载货/空驶/无任务场景下里程监控", "获取里程和轨迹完整率", TrackQueryUrl, TrackQueryAK, invokeCnt_1, parallelism)
    // 调标准线路查询接口，获取里程
    val rdd_drive_dist = SparkNet.runInterfaceWithAkLimit(spark, rdd_double_drive, runTrackQueryInteface, parallelism, TrackQueryAK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    logger.error("httpInvokeId = " + httpInvokeId_1 + "  invokeCnt = " + invokeCnt_1)

    val df_double_driver = rdd_drive_dist.map(obj=>{
      val data_obj = JSONUtil.getJsonObjectMulti(obj, "data_obj")
      val distance_jk = JSONUtil.getJsonDouble(obj, "distance",0.0)

      val task_id = JSONUtil.getJsonVal(data_obj, "task_id", "")
      val vehicle_ton = JSONUtil.getJsonVal(data_obj, "vehicle_ton", "")
      val vehicle_brand_wheelbase = JSONUtil.getJsonVal(data_obj, "vehicle_brand_wheelbase", "")
      val area_name = JSONUtil.getJsonVal(data_obj, "area_name", "")
      val area_code = JSONUtil.getJsonVal(data_obj, "area_code", "")
      val motorcade_name = JSONUtil.getJsonVal(data_obj, "motorcade_name", "")
      val actual_depart_tm = JSONUtil.getJsonVal(data_obj, "actual_depart_tm", "")
      val actual_arrive_tm = JSONUtil.getJsonVal(data_obj, "actual_arrive_tm", "")
      val actual_run_time = JSONUtil.getJsonVal(data_obj, "actual_run_time", "")
      val `type` = JSONUtil.getJsonVal(data_obj, "type", "")
      val src_zone_code = JSONUtil.getJsonVal(data_obj, "src_zone_code", "")
      val dest_zone_code = JSONUtil.getJsonVal(data_obj, "dest_zone_code", "")
      val actual_arrive_date = JSONUtil.getJsonVal(data_obj, "actual_arrive_date", "")
      val task_id_type = JSONUtil.getJsonVal(data_obj, "task_id_type", "")
      var drive_tms = JSONUtil.getJsonVal(data_obj, "drive_tms", "")
      val drive_members = JSONUtil.getJsonVal(data_obj, "drive_members", "")
      val driver_name = JSONUtil.getJsonVal(data_obj, "driver_name", "")
      val main_driver_account = JSONUtil.getJsonVal(data_obj, "main_driver_account", "")

      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val drive_id = JSONUtil.getJsonVal(obj, "drive_id","")
      val drive_start_time = JSONUtil.getJsonVal(obj, "drive_start_time", "")
      val drive_end_time = JSONUtil.getJsonVal(obj, "drive_end_time", "")

      VehicleDistance(vehicle_serial,vehicle_ton,vehicle_brand_wheelbase,area_name,area_code,motorcade_name,task_id_type,task_id,actual_depart_tm,actual_arrive_tm,
        actual_run_time, driver_name,main_driver_account,`type`,drive_id,drive_start_time,drive_end_time,src_zone_code,dest_zone_code,distance_jk,actual_arrive_date)
    }).toDF()
      .join(df_nostop,Seq("task_id"), "inner")
      .withColumn("actual_arrive_tm",when('task_id_type === "空驶任务",'actual_arrive_tm_jt).otherwise('actual_arrive_tm))
      .withColumn("distance_sum",sum('distance_jk).over(Window.partitionBy('vehicle_serial,'task_id,'drive_id)))
      .withColumn("dist",round('distance_jk.cast("double") / 1000,2))
      .withColumn("all_dist",round('accrual_dist_jt.cast("double") / 1000,2))
      .withColumn("accrual_dist",round('distance_sum.cast("double") / 1000,2))
      .withColumn("line_distance",round('distance_sum.cast("double") / 1000,2))
      .withColumn("rt_dist",round('distance_jk.cast("double") / 1000,2))
      .withColumn("log_dist",'log_dist_jt.cast("double")/2)
      .select("vehicle_serial","vehicle_ton","vehicle_brand_wheelbase","area_name","area_code","motorcade_name","task_id_type","task_id",
        "actual_depart_tm","actual_arrive_tm","actual_run_time","driver_name","main_driver_account","type","drive_id","drive_start_time","drive_end_time","src_zone_code",
        "dest_zone_code","dist","all_dist","accrual_dist", "line_distance","rt_dist","log_dist","actual_arrive_date")

    // 所有数据合并
    val df_ret = df_double_driver  // 双驾（载货和空驶）
      .union(df_single_driver)     // 单驾（载货和空驶）
      .union(df_no_task)           // 无任务
      .withColumn("actual_arrive_date",substring('actual_arrive_tm,0,10))
      .withColumn("start_timestamp",tranTimeToLong('actual_depart_tm,lit("yyyy-MM-dd HH:mm:ss")))
      .withColumn("end_timestamp",tranTimeToLong('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss")))
      .withColumn("actual_run_time",when('task_id_type === "载货任务",'actual_run_time)
        .otherwise(round(('end_timestamp - 'start_timestamp)/1000/60).cast("int")))
      .withColumn("inc_day",lit(dayBefore1))
      .na.fill("", Seq("task_id","task_id_type","drive_id","drive_start_time","drive_end_time","main_driver_account","actual_depart_tm","actual_arrive_tm"))
      .withColumn("id",when('type === "是",md5(concat('task_id,'task_id_type,'drive_id,'drive_start_time,'drive_end_time,'inc_day,rand(10))))
        .otherwise(md5(concat('task_id,'task_id_type,'main_driver_account,'actual_depart_tm,'actual_arrive_tm,'inc_day,rand(10))))
      )

    // 结果表保存至hive
    val cols_dtl = spark.sql("""select * from dm_gis.eta_vehicle_distance_control_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_dtl: _*),Seq("inc_day"),"dm_gis.eta_vehicle_distance_control_di")

  }

  case class VehicleDistance(
                              vehicle_serial : String,
                              vehicle_ton : String,
                              vehicle_brand_wheelbase : String,
                              area_name : String,
                              area_code : String,
                              motorcade_name : String,
                              task_id_type : String,
                              task_id : String,
                              actual_depart_tm : String,
                              actual_arrive_tm : String,
                              actual_run_time : String,
                              driver_name : String,
                              main_driver_account : String,
                              `type` : String,
                              drive_id : String,
                              drive_start_time : String,
                              drive_end_time : String,
                              src_zone_code : String,
                              dest_zone_code : String,
                              distance_jk : Double,
                              actual_arrive_date : String
                            )

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，即跑数日期
    val incDay = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231204  ++++")
    run(spark, incDay)
    logger.error("++++++++  任务完成 20231204  ++++")

    spark.stop()
  }

}
