package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.SparkUtil

import java.text.SimpleDateFormat

object GisVehicleFuleStat {
    def main(args: Array[String]): Unit = {
        val SparkInfo = SparkUtil.getSpark("GisVehicleFuleStat")
        val spark = SparkInfo.getSession

        val incDay = new SimpleDateFormat("yyyyMMdd").format(System.currentTimeMillis())

        val sql =
            s"""
               |with t1 as (
               |	select
               |		vehicle_serial,
               |		length_weight
               |	from
               |	(
               |		select
               |			vehicle_serial,
               |			length_weight,
               |			row_number() over(partition by vehicle_serial order by month) rn
               |		FROM dm_gis.gis_vehicle_fule
               |		where 0 < uint_fuel_month and uint_fuel_month < 60
               |	) t
               |	where rn = 1
               |),
               |t2 as (
               |	select
               |		vehicle_serial,
               |		round(avg(uint_fuel_month), 2) uint_fuel
               |	from dm_gis.gis_vehicle_fule
               |	where 0 < uint_fuel_month and uint_fuel_month < 60
               |	group by vehicle_serial
               |),
               |t3 as (
               |	select
               |		t1.vehicle_serial,
               |		t1.length_weight,
               |		t2.uint_fuel
               |	from t1
               |	left join t2
               |	on t1.vehicle_serial = t2.vehicle_serial
               |),
               |t4 as (
               |	select
               |		length_weight,
               |		round(avg(uint_fuel), 2) as uint_fuel_cartype
               |	from t3
               |	group by length_weight
               |)
               |insert overwrite table dm_gis.gis_vehicle_fule_stat partition (inc_day = '$incDay')
               |select
               |	t3.vehicle_serial,
               |	t3.length_weight,
               |	t3.uint_fuel,
               |	t4.uint_fuel_cartype,
               |	round((t3.uint_fuel - t4.uint_fuel_cartype) / t4.uint_fuel_cartype, 2) uint_fuel_rate,
               |	if(abs(round((t3.uint_fuel - t4.uint_fuel_cartype) / t4.uint_fuel_cartype, 2)) > 0.05, t4.uint_fuel_cartype, t3.uint_fuel) update_uint_fuel
               |from t3
               |left join t4
               |on t3.length_weight = t4.length_weight
               |""".stripMargin
        println("##################################################################")
        println(sql)
        println("##################################################################")
        spark.sql(sql)
        println("任务执行完成")
        spark.stop()
    }
}
