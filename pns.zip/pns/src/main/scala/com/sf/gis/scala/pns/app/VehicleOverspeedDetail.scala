package com.sf.gis.scala.pns.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.pns.utils.Functions.{doubleToPercent, isEmptyOrNull, timeToCustomTime, timeToCustomTime2, timestampToTime, tranTimeToLong}
import com.sf.gis.scala.pns.utils.SparkUtils.{row2Json, writeToHive}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import java.util.Date
import scala.collection.JavaConversions.asScalaBuffer
import scala.collection.mutable.{ArrayBuffer, ListBuffer}


/**
 * 【燃油耗能】车辆超速数据摸底_V1.0
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：773089(已下线)
 * 任务名称：车辆超速段判定
 */
object VehicleOverspeedDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  //val Track_Query: String = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"
  val Track_Query: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"  // 新轨迹中台迁移 20230821

  //解析线路查询接口返回值
  def parseTrackQueryHttpData(ret: JSONObject):(String,String,ArrayBuffer[(Long,Double,Long,Double,Double,Double)]) = {
    val ret_arr = new ArrayBuffer[(Long,Double,Long,Double,Double,Double)]
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, ret_arr)
      } else {
        var history_path = new JSONArray()
        try{
          history_path = ret.getJSONObject("result").getJSONObject("data").getJSONArray("track")
        }catch {
          case e: Exception => logger.error(e)
        }

        // 循环获取超速时间段的起始时间和速度
        var flag_start = 0
        var flag_end = 0
        var index_prev = 0
        var tm_start = 0L
        var sp_start = 0.0
        var tm_end = 0L
        var sp_end = 0.0
        var max_sp = Double.MinValue
        var min_sp = Double.MaxValue

        for(i <- 0 until history_path.size()){
          val track = history_path.getJSONObject(i)
          val sp = track.getDouble("sp")  // 速度
          val tm = track.getLong("tm") // 时间戳

          if(flag_start == 0){
            if(sp >= 95){
              index_prev = i
              tm_start = tm
              sp_start = sp
              max_sp = sp
              min_sp = sp
              flag_start = 1

            }
          }else{
            if(sp >= 95 && index_prev == i-1){
              index_prev = i
              tm_end = tm
              sp_end = sp
              if(max_sp <= sp){
                max_sp = sp
              }else{
                min_sp = sp
              }
              flag_end = 1

            }else if(flag_start == 1 && flag_end == 1 && (tm_end - tm_start) >= 10 && (tm_end - tm_start) <= 120){    // 连续速度大于95，且开始和结束时间差再10-120秒之间
              ret_arr.append((tm_start,sp_start,tm_end,sp_end,max_sp,min_sp))

              flag_start = 0
              flag_end = 0
            }else{
              flag_start = 0
              flag_end = 0
            }
          }

        }

        return (codeStatue, "成功", ret_arr)
      }
    }
    ("22", "接口返回值为空", ret_arr)
  }


  def getOverspeedDistance(vehicle_serial: String, ak:String, dataArr: ArrayBuffer[(Long,Double,Long,Double,Double,Double)]) = {
    // 查询线路接口新增字段
    val len_JSONArr = new JSONArray()
    // 将时间戳转换成接口需要的格式
    val fm = new SimpleDateFormat("yyyyMMddHHmmss")
    for (data <- dataArr) {
      val tm_start = data._1
      val sp_start = data._2
      val tm_end = data._3
      val sp_end = data._4
      val max_sp = data._5
      val min_sp = data._6
      var len = 0.0

      val beginDateTime = fm.format(new Date(tm_start*1000))
      val endDateTime = fm.format(new Date(tm_end*1000))

      //初始化轨迹查询接口请求参数
      val param = new JSONObject()
      param.put("type", "401")
      param.put("un",vehicle_serial)
      param.put("unType","0")
      param.put("beginDateTime",beginDateTime)
      param.put("endDateTime",endDateTime)
      param.put("ak", ak)

      try {
        val retStr: String = HttpInvokeUtil.sendPost(Track_Query,param.toJSONString,3)
        len = JSON.parseObject(retStr).getJSONObject("result").getJSONObject("data").getDouble("len")
      } catch {
        case e: Exception => logger.error(e)
      }
      val obj = new JSONObject()
      obj.put("vehicle_serial",vehicle_serial)
      obj.put("tm_start",tm_start)
      obj.put("sp_start",sp_start)
      obj.put("tm_end",tm_end)
      obj.put("sp_end",sp_end)
      obj.put("max_sp",max_sp)
      obj.put("min_sp",min_sp)
      obj.put("len",len)

      len_JSONArr.append(obj)
    }
    len_JSONArr
  }

  /**
   * 调用轨迹查询接口,获取里程和轨迹完整率
   *
   * @param spark
   * @param dataDF
   */
  def runTrackQueryInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
    val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")

    // 将时间戳转换成接口需要的格式
    val beginDateTime = timeToCustomTime(actual_depart_tm, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
    val endDateTime = timeToCustomTime(actual_arrive_tm, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")

    //初始化轨迹查询接口请求参数
    val param = new JSONObject()
    param.put("type", "401")
    param.put("un",vehicle_serial)
    param.put("unType","0")
    param.put("beginDateTime",beginDateTime)
    param.put("endDateTime",endDateTime)
    param.put("ak", ak)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(Track_Query,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析线路查询接口返回值
    val httpData = parseTrackQueryHttpData(retJSONObject)

    // 调轨迹查询接口获取超速时段行驶距离
    val len_JSONArr = getOverspeedDistance(vehicle_serial, ak, httpData._3)

    obj.put("len_JSONArr",len_JSONArr)

    // 辅助字段
    obj.put("codeStatue",httpData._1)
    obj.put("msg",httpData._2)

    obj
  }

  def run(spark: SparkSession, incDay: String) = {

    import spark.implicits._
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore7 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 7)
    // 获取副驾数据
    val recall_sql =
      s"""
         |select
         |  task_id,  --任务id
         |  task_subid,
         |  vehicle_serial,
         |  actual_depart_tm,
         |  actual_arrive_tm
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day >= '$dayBefore7'
         |  and inc_day <= '$dayBefore1'
         |  and carrier_type = '0'
         |  and transoport_level in ('1','2')
         |""".stripMargin
    println("获数据 sql语句：")
    println(recall_sql)

    val df_recall = spark.sql(recall_sql)
      .withColumn("actual_depart_day", timeToCustomTime2('actual_depart_tm, lit("yyyy-MM-dd HH:mm:ss"), lit("yyyyMMdd")))
      .filter('actual_depart_day >= dayBefore7 && 'actual_depart_day <= dayBefore1)

    // 调标准线路查询接口
    val rdd_recall = SparkNet.runInterfaceWithAkLimit(spark, df_recall.rdd.map(row2Json), runTrackQueryInteface, 20, "93ec117f7f1b4226b4e537c4802319e9", 5000)

    val df_ret = rdd_recall.flatMap(obj=>{
      val len_JSONArr = JSONUtil.getJsonArrayMulti(obj,"len_JSONArr")

      val ret_arr = new ArrayBuffer[JSONObject]()
      for (i <- len_JSONArr.indices) {
        val len_obj = len_JSONArr.getJSONObject(i)
        len_obj.put("old_obj",obj)

        ret_arr.append(len_obj)
      }
      ret_arr.iterator
    }).map(obj=>{

      val old_obj = JSONUtil.getJsonObjectMulti(obj, "old_obj")
      val task_id = JSONUtil.getJsonVal(old_obj, "task_id","")
      val task_subid = JSONUtil.getJsonVal(old_obj, "task_subid","")
      val actual_depart_tm = JSONUtil.getJsonVal(old_obj, "actual_depart_tm","")
      val actual_arrive_tm = JSONUtil.getJsonVal(old_obj, "actual_arrive_tm","")

      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial","")
      val start_time = JSONUtil.getJsonLong(obj, "tm_start",0L)*1000  //转为13位时间戳
      val start_sp = JSONUtil.getJsonVal(obj, "sp_start","")
      val end_time = JSONUtil.getJsonLong(obj, "tm_end",0L)*1000  //转为13位时间戳
      val end_sp = JSONUtil.getJsonVal(obj, "sp_end","")
      val max_sp = JSONUtil.getJsonVal(obj, "max_sp","")
      val min_sp = JSONUtil.getJsonVal(obj, "min_sp","")
      val len = JSONUtil.getJsonDouble(obj, "len",0.0)
      var avg_sp = 0.0
      val time = (end_time - start_time) / 1000
      if(time != 0) avg_sp = (len / time) * 3.6   // 米/秒 转换成 千米/小时

      (task_id,task_subid,vehicle_serial,actual_depart_tm,actual_arrive_tm,start_time,end_time,time,start_sp,end_sp,max_sp,min_sp,avg_sp)
    }).toDF("task_id","task_subid","vehicle_serial","actual_depart_tm","actual_arrive_tm","start_time","end_time","time","start_sp","end_sp","max_sp","min_sp","avg_sp")
      .withColumn("start_time",timestampToTime('start_time,lit("yyyy-MM-dd HH:mm:ss")))  // 转换成时间格式
      .withColumn("end_time",timestampToTime('end_time,lit("yyyy-MM-dd HH:mm:ss")))  // 转换成时间格式
      .withColumn("inc_day",lit(dayBefore1))

    // 结果表保存至hive
    val cols_dtl = spark.sql("""select * from dm_gis.vehicle_overspeed_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_dtl: _*),Seq("inc_day"),"dm_gis.vehicle_overspeed_detail")

  }

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，即跑数日期
    val incDay = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20230822  ++++")
    run(spark, incDay)
    logger.error("++++++++  任务完成   ++++")

    spark.stop()
  }

}
