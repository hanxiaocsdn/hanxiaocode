package com.sf.gis.scala.pns.app.valueLine

import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.pns.app.valueLine.StandardLineNewPrecept.runStatisticalCost
import org.apache.log4j.Logger

/**
 * GIS-RSS-PNS：【价值线路】筛选工艺流程线上化需求——旧方案
 * 需求方：刘俊荣（ft80006349）
 * @author 徐游飞（01417347）
 * 任务ID：926793
 * 任务名称：筛选工艺流程线上化_旧方案部分—3
 */
object StandardLineNewPrecept_old3 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val dayBefore1 = args(0)
    val dayBefore31 = args(1)
    val month = args(2)
    val monthBefore1 = args(3)
    //日期检查
    logger.error("DayBefore1="+dayBefore1)
    logger.error("dayBefore31="+dayBefore31)
    logger.error("month="+month)
    logger.error("monthBefore1="+monthBefore1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231207 ++++")
    // 获取标准线路关联pass配置后数据
    val lineConfPassDF5 = spark.sql(
      s"""
         |select
         |  *
         |from
         |  dm_gis.pass_join_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin)

    // 获取过滤掉接口返回异常后的任务数据
    val df_mload = spark.sql(
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  linevehicle,
         |  linemload,
         |  unitprice,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  plf_flag,
         |  vehicle_type,
         |  axls_number,
         |  log_dist,
         |  duration,
         |  time,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  error_type,
         |  pns_dist,
         |  pns_time,
         |  src,
         |  line_distance_std,
         |  line_time_std,
         |  sim1,
         |  sim5,
         |  conduct_type,
         |  is_run_ontime_std,
         |  is_run_ontime,
         |  tl_time,
         |  halfway_integrate_rate,
         |  biz_type,
         |  require_category,
         |  std_toll_charge,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  std_id,
         |  task_inc_day,
         |  height,
         |  length,
         |  width,
         |  weight,
         |  mload,
         |  mload_1,
         |  axle_number,
         |  emitstand,
         |  energy,
         |  car_type
         |from
         |  dm_gis.dm_line_task_mload_di
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin)

    val df_task = spark.sql(
      s"""
         |select
         |  task_subid,
         |  t_status,
         |  t_highspeed_distance,
         |  t_tolls,
         |  t_etc_toll,
         |  t_toll_distance,
         |  t_distance
         |from
         |  dm_gis.dm_task_filter_detail_di
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin)

    val df_task_filter = df_mload.join(df_task,Seq("task_subid"),"left")
    // 7.2.3 统计成本
    runStatisticalCost(spark,df_task_filter,lineConfPassDF5,dayBefore1)

    logger.error("++++++++  任务结束  ++++")
    spark.stop()
  }
}
