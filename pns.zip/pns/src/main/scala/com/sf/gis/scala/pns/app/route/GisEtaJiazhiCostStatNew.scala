package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.pns.utils.Functions.timeToCustomTime
import com.sf.gis.scala.pns.utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._


/**
 * GIS-RDS-PNS 价值线路指标监控需求V1.7
 * 需求方：刘思嘉（01420030）
 * @author 徐游飞（01417347）
 * 任务ID：674830
 * 任务名称：价值线路新增逻辑_6.1&6.2
 * git 未提交
 */
object GisEtaJiazhiCostStatNew {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  // 获取hive源数据
  def getDataSource(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    val start_date = DateUtil.getDayBefore(dayBefore1, "yyyyMMdd", 2)
    val end_date = dayBefore1
    // 获取结果表5数据
    val compute_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.gis_eta_jiazhi_cost_compute55
         |where
         |  inc_day >= '$start_date'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println("获取结果表5数据 sql语句：")
    println(compute_sql)
    val df_compute = spark.sql(compute_sql)
      .withColumn("online_date_1_old",getOnline_date('online_date_1))
      .withColumn("online_date_1", when('online_date_1_old > "20230101", 'online_date_1_old).otherwise("20230101"))
      .filter('conduct_type === 1 && 'reject_flag === 0 && 'sum_cost =!= "" && ('diff_flag === 1 || 'diff_flag === 2))

    // 获取价值执行率数据
    val exe_sql =
      s"""
         |select
         |  task_area_code,
         |  line_code,
         |  vehicle_type,
         |  online_date,
         |  online_date_1,
         |  online_before_exe,
         |  online_before_task_num,
         |  online_after_exe,
         |  online_after_task_num,
         |  diff_cost,
         |  diff_fuel,
         |  diff_dist,
         |  diff_road_fee,
         |  inc_day
         |from
         |  dm_gis.eta_jiazhi_exe_statistics
         |where
         |  inc_day >= '$start_date'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println("获取价值执行率数据 sql语句：")
    println(exe_sql)
    val df_exe = spark.sql(exe_sql)
      .groupBy("task_area_code","line_code","vehicle_type","online_date_1","inc_day")
      .agg(
        sum('online_before_exe) as "online_before_exe",
        sum('online_before_task_num) as "online_before_task_num",
        sum('online_after_exe) as "online_after_exe",
        sum('online_after_task_num) as "online_after_task_num",
        avg('diff_cost) as "diff_cost",
        avg('diff_fuel) as "diff_fuel",
        avg('diff_dist) as "diff_dist",
        avg('diff_road_fee) as "diff_road_fee_expect"
      )

    (df_compute,df_exe)
  }

  def gisEtaJiazhiCostStatNew(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    // 获取hive源数据
    val (df_compute,df_exe) = getDataSource(spark, dayBefore1)

    // 结果表55和执行率表关联再统计指标
    val df_start_new = df_compute
      .groupBy("task_area_code", "line_code", "vehicle_type", "online_date_1", "inc_day")
      .agg(
        sum('miles) as "miles",
        sum('road_fee) as "road_fee",
        sum('fuel_cost) as "fuel_cost",
        sum('sum_cost) as "sum_cost",
        sum('re_road_fee) as "re_road_fee",
        sum('re_miles) as "re_miles",
        sum('re_fuel_cost) as "re_fuel_cost",
        sum('re_sum_cost) as "re_sum_cost",
        sum('diff_road_fee) as "diff_road_fee",
        sum('diff_fuel_cost) as "diff_fuel_cost",
        sum('diff_miles) as "diff_miles",
        sum('diff_sum_cost) as "diff_sum_cost",
        count('task_id) as "num_sum",
        count('task_id) as "num",
        max('online_date_1_old) as "online_date_1_old"
      )
      .join(df_exe,Seq("task_area_code","line_code","vehicle_type","online_date_1","inc_day"),"inner")
      .withColumn("online_date_1",'online_date_1_old)
      .na.fill("", Array("sum_cost"))
      .withColumn("diff_cost_flag", when('diff_sum_cost === 0, 0)
        .when('diff_sum_cost > 0, 1)
        .when('diff_sum_cost < 0, 2))
      .withColumn("road_fee_mean", when('num =!= 0, 'road_fee / 'num).otherwise(0))
      .withColumn("miles_mean", when('num =!= 0, 'miles / 'num).otherwise(0))
      .withColumn("fuel_cost_mean", when('num =!= 0, 'fuel_cost / 'num).otherwise(0))
      .withColumn("sum_cost_mean", when('num =!= 0, 'sum_cost / 'num).otherwise(0))
      .withColumn("re_miles_mean", when('num =!= 0, 're_miles / 'num).otherwise(0))
      .withColumn("re_road_fee_mean", when('num =!= 0, 're_road_fee / 'num).otherwise(0))
      .withColumn("re_fuel_cost_mean", when('num =!= 0, 're_fuel_cost / 'num).otherwise(0))
      .withColumn("re_sum_cost_mean", when('num =!= 0, 're_sum_cost / 'num).otherwise(0))
      .withColumn("diff_road_fee_mean", when('num =!= 0, 'diff_road_fee / 'num).otherwise(0))
      .withColumn("diff_fuel_cost_mean", when('num =!= 0, 'diff_fuel_cost / 'num).otherwise(0))
      .withColumn("diff_miles_mean", when('num =!= 0, 'diff_miles / 'num).otherwise(0))
      .withColumn("diff_sum_cost_mean", when('num =!= 0, 'diff_sum_cost / 'num).otherwise(0))
      .withColumn("online_after_exe_rate", when('online_after_task_num =!= 0, 'online_after_exe / 'online_after_task_num).otherwise(0))
      .withColumn("online_before_exe_rate", when('online_before_task_num =!= 0, 'online_before_exe / 'online_before_task_num).otherwise(0))
      .withColumn("diff_fluctuation", 'online_after_exe_rate - 'online_before_exe_rate)
      .withColumn("num_new", 'online_after_task_num * 'diff_fluctuation)
      .withColumn("exe_flag", when('diff_fluctuation === 0, 0)
        .when('diff_fluctuation > 0, 1)
        .when('diff_fluctuation < 0, 2))
      .withColumn("diff_sum_cost_all", when('exe_flag === 2,0).otherwise('diff_sum_cost_mean * 'num_new))
      .withColumn("diff_roadfee_all",when('exe_flag === 2,0).otherwise('diff_road_fee_mean * 'num_new))
      .withColumn("diff_miles_all",when('exe_flag === 2,0).otherwise('diff_miles_mean * 'num_new))
      .withColumn("diff_fuel_cost_all",when('exe_flag === 2,0).otherwise('diff_fuel_cost_mean * 'num_new))
      .withColumn("sum_cost_all", 'sum_cost_mean * 'num_new)
      .withColumn("roadfee_all", 'road_fee_mean * 'num_new)
      .withColumn("miles_all", 'miles_mean * 'num_new)
      .withColumn("fuel_cost_all", 'fuel_cost_mean * 'num_new)
      .withColumn("re_sum_cost_all", 're_sum_cost_mean * 'num_new)
      .withColumn("re_roadfee_all", 're_road_fee_mean * 'num_new)
      .withColumn("re_miles_all", 're_miles_mean * 'num_new)
      .withColumn("re_fuel_cost_all", 're_fuel_cost_mean * 'num_new)
      .withColumn("diff_sum_cost_exe",'diff_sum_cost_mean * 'online_after_exe)
      .withColumn("diff_roadfee_exe",'diff_road_fee_mean * 'online_after_exe)
      .withColumn("diff_miles_exe",'diff_miles_mean * 'online_after_exe)
      .withColumn("diff_fuel_cost_exe",'diff_fuel_cost_mean * 'online_after_exe)
      .withColumn("diff_sum_cost_unexe",'diff_sum_cost_mean * ('online_after_task_num - 'online_after_exe))
      .withColumn("diff_roadfee_unexe",'diff_road_fee_mean * ('online_after_task_num - 'online_after_exe))
      .withColumn("diff_miles_unexe",'diff_miles_mean * ('online_after_task_num - 'online_after_exe))
      .withColumn("diff_fuel_cost_unexe",'diff_fuel_cost_mean * ('online_after_task_num - 'online_after_exe))
      .withColumn("diff_cost_expect",'diff_cost * 'num_new)
      .withColumn("diff_road_fee_expect",'diff_road_fee_expect * 'num_new)
      .withColumn("diff_fuel_expect",'diff_fuel * 'num_new)
      .withColumn("diff_dist_expect",'diff_dist * 'num_new)

    // 结果表6_1保存至hive
    val cols_start_new = spark.sql("""select * from dm_gis.gis_eta_jiazhi_cost_stat_new limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_start_new.select(cols_start_new: _*),Seq("inc_day"),"dm_gis.gis_eta_jiazhi_cost_stat_new")
  }

  // 获取online_date里的最早日期
  def getOnline_date  = udf((online_date: String)  => {
    var date_min = ""
    if(online_date != null && online_date.trim != ""){

      val date_arr = online_date.split("\\|")
      date_min = date_arr.min

    }
    timeToCustomTime(date_min,"yyyy-MM-dd","yyyyMMdd")
  })

}