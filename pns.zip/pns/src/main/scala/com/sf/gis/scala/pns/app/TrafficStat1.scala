package com.sf.gis.scala.pns.app

import java.nio.charset.Charset
import java.sql.{Connection, DriverManager}
import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DbUtil
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang.StringUtils
import org.apache.http.HttpEntity
import org.apache.http.client.methods.{CloseableHttpResponse, HttpPost}
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager: 已下线
 * @Author: 01374443 张想远 (单天赐代码改造)
 * @CreateTime: 2023-03-03 14:06
 * @TaskId:229759
 * @TaskName:TrafficStat1
 * @Description: 道路交通指标统计,貌似即将下线
 */
object TrafficStat1 {
  val excute = true
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  //  val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

  var url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8mb4&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"
  val user = "gis_oms_pns"
  val password = "gis_oms_pns@123@"

  val format2 = new SimpleDateFormat("yyyyMMdd")


  def main(args: Array[String]): Unit = {
    //    val urlp: URL = ClassLoader.getSystemResource("log4j.properties")
    //    PropertyConfigurator.configure(urlp)

    if (!excute) {
      logger.error("不执行程序")
      println("the end ...")
      return
    }


    logger.error("获取和设置日期...")
    var runDate = ""
    var beforeDate = ""
    var nextDate = ""
    var argcount = args.length
    if (argcount == 0) argcount = 1
    val sparkSession = Spark.getSparkSession(appName)
    for (i <- 0 to argcount - 1) {
      if (args.length == 0) {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_MONTH, -1)
        runDate = format2.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, -1)
        beforeDate = format2.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, 2)
        nextDate = format2.format(calendar.getTime)
      }
      else {
        runDate = args(i)
        val calendar = Calendar.getInstance()
        calendar.setTime(format2.parse(runDate))
        calendar.add(Calendar.DAY_OF_MONTH, -1)
        beforeDate = format2.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, 2)
        nextDate = format2.format(calendar.getTime)
      }

      logger.error("开始处理" + runDate)

      traffic_time_log_parse_base_v(sparkSession, runDate)

      traffic_time_log_parse_historytrack_v(sparkSession, runDate)

      traffic_time_log_parse_rectify_v(sparkSession, runDate)

      traffic_time_log_parse_tmctrack_v(sparkSession, runDate)

      traffic_time_log_parse_routepoint_v(sparkSession, runDate)

      traffic_time_log_parse_request_tracks_v(sparkSession, runDate)

      traffic_time_log_parse_report_v(sparkSession, runDate, beforeDate)

      traffic_time_log_parse_weather(sparkSession, runDate, beforeDate)

      traffic_time_log_parse_blockinfo_base_v(sparkSession, runDate, beforeDate)

      traffic_time_log_parse_blockinfo_v(sparkSession, runDate, nextDate)


      traffic_time_log_stat_v(sparkSession, runDate, nextDate)
      traffic_time_log_stat_timeout_v(sparkSession, runDate, nextDate)

      push_traffic_stat_data(sparkSession, runDate)


    }


    sparkSession.stop()
    println("the end ...")

  }


  //拥堵日志解析
  def traffic_time_log_parse_base_v(sparkSession: SparkSession, runDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_base_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_base_v_flag_sql = "select log from dm_gis.gis_lss_core_wifi_log where inc_day='" + runDate + "' and log LIKE '%trafficBlock%' limit 1"
    logger.error(traffic_time_log_parse_base_v_flag_sql)
    var traffic_time_log_parse_base_v_count = sparkSession.sql(traffic_time_log_parse_base_v_flag_sql)
    var traffic_time_log_parse_base_v_flag = traffic_time_log_parse_base_v_count.take(1).length == 0
    if (traffic_time_log_parse_base_v_flag) {
      logger.error("dm_gis.gis_lss_core_wifi_log没有符合条件的数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_base_v_sql = "select log from dm_gis.gis_lss_core_wifi_log where inc_day='" + runDate + "' and log LIKE '%trafficBlock%'"
      logger.error(traffic_time_log_parse_base_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_base_v_sql)
        .na.fill("")
        .rdd.map(row => {
        var log = ""
        if (!row.isNullAt(0)) log = row.getString(0)

        var arg = ""
        var business = ""
        var date = ""
        var id = ""
        var result = ""
        var _type = ""

        if (!StringUtils.isEmpty(log)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(log)
          } catch {
            case ex: Exception => {}
          }
          if (jsonObject != null) {
            arg = getString(jsonObject, "arg")
            business = getString(jsonObject, "business")
            date = getString(jsonObject, "date")
            id = getString(jsonObject, "id")
            result = getString(jsonObject, "result")
            _type = getString(jsonObject, "type")
          }
        }
        (arg, business, date, id, result, _type)
      }).toDF("arg", "business", "date", "id", "result", "type").repartition(1)
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)

      val table = "dm_gis.traffic_time_log_parse_base_v"
      saveData(sparkSession, tmpView, table, runDate)
    }

  }

  def saveData(sparkSession: SparkSession, tmpView: String, tableName: String, runDate: String): Unit = {
    val sql = s"insert overwrite table $tableName partition(inc_day='$runDate') select * from $tmpView";
    logger.error(sql)
    sparkSession.sql(sql)

  }

  //历史轨迹查询日志表
  def traffic_time_log_parse_historytrack_v(sparkSession: SparkSession, runDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_historytrack_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_historytrack_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_historytrack_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_historytrack_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and type='historyTrack' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_historytrack_v_flag_sql)
    var traffic_time_log_parse_historytrack_v_count = sparkSession.sql(traffic_time_log_parse_historytrack_v_flag_sql)
    var traffic_time_log_parse_historytrack_v_flag = traffic_time_log_parse_historytrack_v_count.take(1).length == 0
    if (traffic_time_log_parse_historytrack_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_historytrack_v_sql = "select date,id,result from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and type='historyTrack'"
        .format(runDate)
      logger.error(traffic_time_log_parse_historytrack_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_historytrack_v_sql).na.fill("")
        .rdd.map(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var result = "";
        if (!row.isNullAt(2)) result = row.getString(2)
        var status = ""
        var tracks = ""

        if (!StringUtils.isEmpty(result)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(result)
          } catch {
            case ex: Exception => {}
          }
          if (jsonObject != null) {
            status = getString(jsonObject, "status")
            tracks = getString(jsonObject, "tracks")
          }
        }

        (tm, taskid, status, tracks)
      }).toDF("tm", "taskid", "status", "tracks").repartition(1)
      val table = "dm_gis.traffic_time_log_parse_historytrack_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }
  }


  //纠偏日志表
  def traffic_time_log_parse_rectify_v(sparkSession: SparkSession, runDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_rectify_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_rectify_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_rectify_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_rectify_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and business='trafficBlock' and type='rectify' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_rectify_v_flag_sql)
    var traffic_time_log_parse_rectify_v_count = sparkSession.sql(traffic_time_log_parse_rectify_v_flag_sql)
    var traffic_time_log_parse_rectify_v_flag = traffic_time_log_parse_rectify_v_count.take(1).length == 0
    if (traffic_time_log_parse_rectify_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_rectify_v_sql = "select date,id,arg,result from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and business='trafficBlock' and type='rectify'"
        .format(runDate)
      logger.error(traffic_time_log_parse_rectify_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_rectify_v_sql).na.fill("")
        .rdd.map(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "-";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var arg = "";
        if (!row.isNullAt(2)) arg = row.getString(2)
        var result = "";
        if (!row.isNullAt(3)) result = row.getString(3)

        var ret = ""
        var errorCode = ""
        var rectifyresult = ""

        if (!StringUtils.isEmpty(result)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(result)
          } catch {
            case ex: Exception => {
              errorCode = result
            }
          }

          if (jsonObject != null) {
            ret = getString(jsonObject, "ret")
            if (StringUtils.isEmpty(ret)) errorCode = result
            rectifyresult = getString(jsonObject, "tracks")
          }
        }
        if (StringUtils.isEmpty(ret)) ret = ""
        if (StringUtils.isEmpty(rectifyresult)) rectifyresult = ""

        (tm, taskid, arg, ret, errorCode, rectifyresult)
      }).toDF("tm", "taskid", "arg", "ret", "errorCode", "rectifyresult").repartition(1)

      val table = "dm_gis.traffic_time_log_parse_rectify_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }
  }


  //拥堵查询日志表
  def traffic_time_log_parse_tmctrack_v(sparkSession: SparkSession, runDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_tmctrack_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_tmctrack_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_tmctrack_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_tmctrack_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and business='trafficBlock' and type='tmcTrack' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_tmctrack_v_flag_sql)
    var traffic_time_log_parse_tmctrack_v_count = sparkSession.sql(traffic_time_log_parse_tmctrack_v_flag_sql)
    var traffic_time_log_parse_tmctrack_v_flag = traffic_time_log_parse_tmctrack_v_count.take(1).length == 0
    if (traffic_time_log_parse_tmctrack_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_tmctrack_v_sql = "select date,id,arg,result from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and business='trafficBlock' and type='tmcTrack'"
        .format(runDate)
      logger.error(traffic_time_log_parse_tmctrack_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_tmctrack_v_sql).na.fill("")
        .rdd.map(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var arg = "";
        if (!row.isNullAt(2)) arg = row.getString(2)
        var result = "";
        if (!row.isNullAt(3)) result = row.getString(3)

        var ret = ""
        var errorCode = ""
        var tmcresult = ""

        if (!StringUtils.isEmpty(result)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(result)
          } catch {
            case ex: Exception => {
              ret = "失败"
              errorCode = result
            }
          }

          if (jsonObject != null) {
            tmcresult = getString(jsonObject, "tracks")
            if (!StringUtils.isEmpty(tmcresult)) {
              ret = "成功"
            }
            else {
              ret = "失败"
              errorCode = result
            }
          }
        }
        if (StringUtils.isEmpty(ret)) {
          ret = "失败"
          errorCode = result
        }


        (tm, taskid, arg, ret, errorCode, tmcresult)
      }).toDF("tm", "taskid", "arg", "ret", "errorCode", "tmcresult").repartition(1)

      val table = "dm_gis.traffic_time_log_parse_tmctrack_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //拥堵查询轨迹点列表
  def traffic_time_log_parse_request_tracks_v(sparkSession: SparkSession, runDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_request_tracks_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_request_tracks_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_request_tracks_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_request_tracks_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_rectify_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_request_tracks_v_flag_sql)
    var traffic_time_log_parse_request_tracks_v_count = sparkSession.sql(traffic_time_log_parse_request_tracks_v_flag_sql)
    var traffic_time_log_parse_request_tracks_v_flag = traffic_time_log_parse_request_tracks_v_count.take(1).length == 0
    if (traffic_time_log_parse_request_tracks_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_rectify_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_request_tracks_v_sql = "select a.tm,a.taskid,a.rectifyresult,b.tmcresult from dm_gis.traffic_time_log_parse_rectify_v a left join dm_gis.traffic_time_log_parse_tmctrack_v b on a.taskid = b.taskid where a.inc_day='%s' and a.taskid is not null and a.taskid<>'' and a.rectifyresult is not null and a.rectifyresult<>'' and a.rectifyresult<>'-' and a.rectifyresult<>'[]' and b.inc_day='%s' and b.tmcresult is not null and b.tmcresult<>'' and b.tmcresult<>'-' and b.tmcresult<>'[]'"
        .format(runDate, runDate)
      logger.error(traffic_time_log_parse_request_tracks_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_request_tracks_v_sql).na.fill("")
        .rdd.flatMap(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var tracks1 = "";
        if (!row.isNullAt(2)) tracks1 = row.getString(2)
        var tracks2 = "";
        if (!row.isNullAt(3)) tracks2 = row.getString(3)

        var tracksList: List[Array[String]] = List()

        if (!StringUtils.isEmpty(tracks1)) {
          var tracksArray1: JSONArray = null
          var tracksArray2: JSONArray = null
          try {
            tracksArray1 = JSON.parseArray(tracks1)
            tracksArray2 = JSON.parseArray(tracks2)
          }
          catch {
            case ex: Exception => {}
          }
          if (tracksArray1 != null && tracksArray1.size() > 0) {
            for (j <- 0 to tracksArray1.size() - 1) {
              val trackObject1 = tracksArray1.getJSONObject(j)
              var trackObject2: JSONObject = null
              if (tracksArray2 != null && tracksArray2.size() > j + 1) {
                trackObject2 = tracksArray2.getJSONObject(j)
              }
              var errorCode = ""
              var rticspeed = ""
              var _type = ""
              var dir = ""
              var rticspeed_1 = ""
              var type_1 = ""
              var dir_1 = ""
              var level_2 = ""
              var type_2 = ""
              var description_2 = ""
              if (trackObject2 != null) {
                val flow = trackObject2.getJSONArray("flow")
                if (flow != null && flow.size() > 0) {
                  val flow0 = flow.getJSONObject(0)
                  if (flow0 != null) {
                    rticspeed = getString(flow0, "speed")
                    _type = getString(flow0, "status")
                    dir = getString(flow0, "dir")
                  }
                  if (flow.size() > 1) {
                    val flow1 = flow.getJSONObject(1)
                    if (flow1 != null) {
                      rticspeed_1 = getString(flow1, "speed")
                      type_1 = getString(flow1, "status")
                      dir_1 = getString(flow1, "dir")
                    }
                  }
                }
                else {
                  _type = "0"
                  errorCode = "rtic db not exist this link"
                }

                val warn = trackObject2.getJSONArray("warn")
                if (warn != null && warn.size() > 0) {
                  val warn0 = warn.getJSONObject(0)
                  if (warn0 != null) {
                    level_2 = getString(warn0, "level")
                    type_2 = getString(warn0, "type")
                    description_2 = getString(warn0, "description")
                  }
                }
              }
              if (trackObject1 != null) {
                var index = getString(trackObject1, "index")
                var time = getString(trackObject1, "time")
                var x = getString(trackObject1, "x")
                var y = getString(trackObject1, "y")
                var trackspeed = getString(trackObject1, "speed")
                var sw_id = getString(trackObject1, "SWID")
                var jySpeed = getString(trackObject1, "static_speed")
                var roadclass = getString(trackObject1, "roadclass")
                var speed_limit = getString(trackObject1, "speed_limit")
                var status = getString(trackObject1, "status")
                var sumdist = getString(trackObject1, "sumdist")

                var speedCompare = ""
                if (Array("2", "3", "4").contains(_type)) {
                  if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(jySpeed)
                    && trackspeed.toDouble < jySpeed.toDouble * 0.8) speedCompare = "0"
                  else if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(jySpeed)
                    && !StringUtils.isEmpty(rticspeed)
                    && trackspeed.toDouble >= jySpeed.toDouble * 0.8
                    && trackspeed.toDouble >= rticspeed.toDouble * 1.2) speedCompare = "3"
                  else if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(jySpeed)
                    && trackspeed.toDouble >= jySpeed.toDouble * 0.8) speedCompare = "1"
                  else if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(rticspeed)
                    && trackspeed.toDouble >= rticspeed.toDouble * 1.2) speedCompare = "2"
                }
                else if ("1".equalsIgnoreCase(_type)) {
                  if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(jySpeed)
                    && trackspeed.toDouble >= jySpeed.toDouble * 0.8) speedCompare = "4"
                  else if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(jySpeed)
                    && !StringUtils.isEmpty(rticspeed)
                    && trackspeed.toDouble < jySpeed.toDouble * 0.8
                    && trackspeed.toDouble >= 0
                    && trackspeed.toDouble < rticspeed.toDouble * 0.8) speedCompare = "7"
                  else if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(jySpeed)
                    && trackspeed.toDouble < jySpeed.toDouble * 0.8
                    && trackspeed.toDouble >= 0) speedCompare = "5"
                  else if (!StringUtils.isEmpty(trackspeed)
                    && !StringUtils.isEmpty(rticspeed)
                    && trackspeed.toDouble < rticspeed.toDouble * 0.8) speedCompare = "6"
                }
                else if ("0".equalsIgnoreCase(_type)) {
                  if ((StringUtils.isEmpty(errorCode)
                    || "-".equalsIgnoreCase(errorCode))
                    && "0".equalsIgnoreCase(sw_id)) {
                    speedCompare = "8"
                  }
                  else if (!StringUtils.isEmpty(errorCode)
                    && !"-".equalsIgnoreCase(errorCode)) speedCompare = "9"
                }

                tracksList = tracksList :+ Array(tm, taskid, index, errorCode, time, x, y, trackspeed, sw_id, jySpeed, rticspeed, _type, speedCompare, dir, rticspeed_1, type_1, dir_1, roadclass, speed_limit, status, sumdist, level_2, type_2, description_2)
              }
            }
          }
        }

        tracksList
      }).toDF("tm", "taskid", "index", "errorCode", "time", "x", "y", "trackspeed", "sw_id", "jySpeed", "rticspeed", "type", "speedCompare", "dir", "rticspeed_1", "type_1", "dir_1", "roadclass", "speed_limit", "status", "sumdist", "level_2", "type_2", "description_2")
        .repartition(1)

      val table = "dm_gis.traffic_time_log_parse_request_tracks_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //非拥堵计算表
  def traffic_time_log_parse_routepoint_v(sparkSession: SparkSession, runDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_routepoint_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_routepoint_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_routepoint_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_routepoint_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and business='trafficBlock' and type='routePoint' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_routepoint_v_flag_sql)
    var traffic_time_log_parse_routepoint_v_count = sparkSession.sql(traffic_time_log_parse_routepoint_v_flag_sql)
    var traffic_time_log_parse_routepoint_v_flag = traffic_time_log_parse_routepoint_v_count.take(1).length == 0
    if (traffic_time_log_parse_routepoint_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_routepoint_v_sql = "select date,id,arg,result from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and business='trafficBlock' and type='routePoint'"
        .format(runDate)
      logger.error(traffic_time_log_parse_routepoint_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_routepoint_v_sql).na.fill("")
        .rdd.map(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var arg = "";
        if (!row.isNullAt(2)) arg = row.getString(2)
        var result = "";
        if (!row.isNullAt(3)) result = row.getString(3)

        var status = ""

        if (!StringUtils.isEmpty(result)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(result)
          } catch {
            case ex: Exception => {
            }
          }

          if (jsonObject != null) {
            status = getString(jsonObject, "status")
          }
        }

        (tm, taskid, arg, status, result)
      }).toDF("tm", "taskid", "arg", "status", "result").repartition(1)

      val table = "dm_gis.traffic_time_log_parse_routepoint_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //拥堵结果明细表
  def traffic_time_log_parse_report_v(sparkSession: SparkSession, runDate: String, beforeDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_report_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_report_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_report_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_report_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and type='report' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_report_v_flag_sql)
    var traffic_time_log_parse_report_v_count = sparkSession.sql(traffic_time_log_parse_report_v_flag_sql)
    var traffic_time_log_parse_report_v_flag = traffic_time_log_parse_report_v_count.take(1).length == 0
    if (traffic_time_log_parse_report_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_report_v_sql = "select date,id,result,inc_day from dm_gis.traffic_time_log_parse_base_v where inc_day>='%s' and inc_day <='%s' and type='report'"
        .format(beforeDate, runDate)
      logger.error(traffic_time_log_parse_report_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_report_v_sql).na.fill("")
        .rdd.map(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var result = "";
        if (!row.isNullAt(2)) result = row.getString(2)

        val inc_day = row.getString(3)

        var requirementId = ""
        var vehicle = ""
        var version = ""
        var realBlockStartTime = ""
        var realBlockEndTime = ""
        var realBlockTimes = ""
        var duration = ""
        var newBlockTimes = ""

        if (!StringUtils.isEmpty(result)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(result)
          } catch {
            case ex: Exception => {}
          }
          if (jsonObject != null) {
            requirementId = getString(jsonObject, "requirementId")
            vehicle = getString(jsonObject, "vehicle")
            version = getString(jsonObject, "version")
            realBlockStartTime = getString(jsonObject, "realBlockStartTime")
            realBlockEndTime = getString(jsonObject, "realBlockEndTime")
            duration = getString(jsonObject, "duration")
            newBlockTimes = getString(jsonObject, "newBlockTimes")
            if (StringUtils.isEmpty(duration)) duration = "0.0"
            if (!StringUtils.isEmpty(realBlockStartTime) && !StringUtils.isEmpty(realBlockEndTime)) realBlockTimes = (realBlockEndTime.toLong - realBlockStartTime.toLong).toString
            if (!StringUtils.isEmpty(realBlockTimes) && !StringUtils.isEmpty(duration)) newBlockTimes = (realBlockTimes.toDouble - duration.toDouble).toString
          }
        }

        Row(tm, taskid, requirementId, vehicle, version, realBlockTimes, realBlockStartTime, realBlockEndTime, duration, newBlockTimes, inc_day)
      })
        .groupBy(row => row.getString(1))
        .flatMap(item => {
          var tracksList: List[(String, String, String, String, String, String, String, String, String, String, String)] = List()
          var taskid = item._1
          var i = 0
          if (item._2.size > 0) {
            item._2.toList.sortBy(row => row.getString(0)).foreach(row => {
              i = i + 1
              var tm = "";
              if (!row.isNullAt(0)) tm = row.getString(0)
              var requirementId = "";
              if (!row.isNullAt(2)) requirementId = row.getString(2)
              var vehicle = "";
              if (!row.isNullAt(3)) vehicle = row.getString(3)
              var version = "";
              if (!row.isNullAt(4)) version = row.getString(4)
              var realBlockTimes = "";
              if (!row.isNullAt(5)) realBlockTimes = row.getString(5)
              var realBlockStartTime = "";
              if (!row.isNullAt(6)) realBlockStartTime = row.getString(6)
              var realBlockEndTime = "";
              if (!row.isNullAt(7)) realBlockEndTime = row.getString(7)
              var duration = "";
              if (!row.isNullAt(8)) duration = row.getString(8)
              var newBlockTimes = "";
              if (!row.isNullAt(9)) newBlockTimes = row.getString(9)
              val inc_day = row.getString(10)

              if (runDate.equalsIgnoreCase(inc_day)) tracksList = tracksList :+ (tm, taskid, requirementId, vehicle, version, realBlockTimes, realBlockStartTime, realBlockEndTime, duration, newBlockTimes, i.toString)
            })
          }

          tracksList
        }).toDF("tm", "taskid", "requirementId", "vehicle", "version", "realBlockTimes", "realBlockStartTime", "realBlockEndTime", "duration", "NewBlockTimes", "id")
        .repartition(1)

      val table = "dm_gis.traffic_time_log_parse_report_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //拥堵结果明细表
  def traffic_time_log_parse_weather(sparkSession: SparkSession, runDate: String, beforeDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_weather")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_weather where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_weather已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_weather_flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and type='weather' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_weather_flag_sql)
    var traffic_time_log_parse_weather_count = sparkSession.sql(traffic_time_log_parse_weather_flag_sql)
    var traffic_time_log_parse_weather_flag = traffic_time_log_parse_weather_count.take(1).length == 0
    if (traffic_time_log_parse_weather_flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_weather_sql = "select date,id,result,inc_day from dm_gis.traffic_time_log_parse_base_v where inc_day>='%s' and inc_day <='%s' and type='weather'"
        .format(beforeDate, runDate)
      logger.error(traffic_time_log_parse_weather_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_weather_sql).na.fill("")
        .rdd.map(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var result = "";
        if (!row.isNullAt(2)) result = row.getString(2)

        val inc_day = row.getString(3)

        var requirement_id = ""
        var vehicle = ""
        var level = ""
        var _type = ""
        var weather_time = ""
        var weather_starttime = ""
        var weather_endtime = ""
        var weather_mileage = ""
        var weather_startlongitude = ""
        var weather_startlatitude = ""
        var weather_endlongitude = ""
        var weather_endlatitude = ""

        if (!StringUtils.isEmpty(result)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(result)
          } catch {
            case ex: Exception => {}
          }
          if (jsonObject != null) {
            requirement_id = getString(jsonObject, "requirementId")
            vehicle = getString(jsonObject, "vehicle")
            level = getString(jsonObject, "level")
            _type = getString(jsonObject, "type")
            weather_starttime = getString(jsonObject, "weatherStartTime")
            weather_endtime = getString(jsonObject, "weatherEndTime")
            weather_mileage = getString(jsonObject, "weatherMileage")
            weather_startlongitude = getString(jsonObject, "weatherStartLongitude")
            weather_startlatitude = getString(jsonObject, "weatherStartLatitude")
            weather_endlongitude = getString(jsonObject, "weatherEndLongitude")
            weather_endlatitude = getString(jsonObject, "weatherEndLatitude")
            if (!StringUtils.isEmpty(weather_starttime) && !StringUtils.isEmpty(weather_endtime)) weather_time = (weather_endtime.toLong - weather_starttime.toLong).toString
          }
        }

        if (StringUtils.isEmpty(tm)) tm = ""
        if (StringUtils.isEmpty(taskid)) taskid = ""
        if (StringUtils.isEmpty(requirement_id)) requirement_id = ""
        if (StringUtils.isEmpty(vehicle)) vehicle = ""
        if (StringUtils.isEmpty(level)) level = ""
        if (StringUtils.isEmpty(_type)) _type = ""
        if (StringUtils.isEmpty(weather_time)) weather_time = ""
        if (StringUtils.isEmpty(weather_starttime)) weather_starttime = ""
        if (StringUtils.isEmpty(weather_endtime)) weather_endtime = ""
        if (StringUtils.isEmpty(weather_mileage)) weather_mileage = ""
        if (StringUtils.isEmpty(weather_startlongitude)) weather_startlongitude = ""
        if (StringUtils.isEmpty(weather_startlatitude)) weather_startlatitude = ""
        if (StringUtils.isEmpty(weather_endlongitude)) weather_endlongitude = ""
        if (StringUtils.isEmpty(weather_endlatitude)) weather_endlatitude = ""

        Row(tm, taskid, requirement_id, vehicle, level, _type, weather_time, weather_starttime, weather_endtime, weather_mileage, weather_startlongitude, weather_startlatitude, weather_endlongitude, weather_endlatitude, inc_day)
      })
        .groupBy(row => row.getString(1))
        .flatMap(item => {
          var tracksList: List[(String, String, String, String, String, String, String, String, String, String, String, String, String, String, String)] = List()
          var taskid = item._1
          var i = 0
          if (item._2.size > 0) {
            item._2.toList.sortBy(row => row.getString(0)).foreach(row => {
              i = i + 1
              var tm = "";
              if (!row.isNullAt(0)) tm = row.getString(0)
              var requirement_id = "";
              if (!row.isNullAt(2)) requirement_id = row.getString(2)
              var vehicle = "";
              if (!row.isNullAt(3)) vehicle = row.getString(3)
              var level = "";
              if (!row.isNullAt(4)) level = row.getString(4)
              var _type = "";
              if (!row.isNullAt(5)) _type = row.getString(5)
              var weather_time = "";
              if (!row.isNullAt(6)) weather_time = row.getString(6)
              var weather_starttime = "";
              if (!row.isNullAt(7)) weather_starttime = row.getString(7)
              var weather_endtime = "";
              if (!row.isNullAt(8)) weather_endtime = row.getString(8)
              var weather_mileage = "";
              if (!row.isNullAt(9)) weather_mileage = row.getString(9)
              var weather_startlongitude = "";
              if (!row.isNullAt(10)) weather_startlongitude = row.getString(10)
              var weather_startlatitude = "";
              if (!row.isNullAt(11)) weather_startlatitude = row.getString(11)
              var weather_endlongitude = "";
              if (!row.isNullAt(12)) weather_endlongitude = row.getString(12)
              var weather_endlatitude = "";
              if (!row.isNullAt(13)) weather_endlatitude = row.getString(13)
              val inc_day = row.getString(14)

              if (runDate.equalsIgnoreCase(inc_day)) tracksList = tracksList :+ (tm, taskid, i.toString, requirement_id, vehicle, level, _type, weather_time, weather_starttime, weather_endtime, weather_mileage, weather_startlongitude, weather_startlatitude, weather_endlongitude, weather_endlatitude)
            })
          }
          tracksList
        }).toDF("tm", "taskid", "id", "requirement_id", "vehicle", "level", "type", "weather_time", "weather_starttime", "weather_endtime", "weather_mileage", "weather_startlongitude", "weather_startlatitude", "weather_endlongitude", "weather_endlatitude")
        .repartition(1)

      val table = "dm_gis.traffic_time_log_parse_weather"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //任务基础数据表-解析
  def traffic_time_log_parse_blockinfo_base_v(sparkSession: SparkSession, runDate: String, beforeDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_blockinfo_base_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_blockinfo_base_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_blockinfo_base_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_blockinfo_base_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and type='blockInfo' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_blockinfo_base_v_flag_sql)
    var traffic_time_log_parse_blockinfo_base_v_count = sparkSession.sql(traffic_time_log_parse_blockinfo_base_v_flag_sql)
    var traffic_time_log_parse_blockinfo_base_v_flag = traffic_time_log_parse_blockinfo_base_v_count.take(1).length == 0
    if (traffic_time_log_parse_blockinfo_base_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_blockinfo_base_v_temp_sql = "select date,id,result from dm_gis.traffic_time_log_parse_base_v where inc_day='%s' and type='blockInfo'"
        .format(runDate)
      logger.error(traffic_time_log_parse_blockinfo_base_v_temp_sql)

      val result_rdd = sparkSession.sql(traffic_time_log_parse_blockinfo_base_v_temp_sql).na.fill("")
        .rdd.map(row => {

        var tm = "";
        if (!row.isNullAt(0)) tm = row.getString(0)
        var taskid = "";
        if (!row.isNullAt(1)) taskid = row.getString(1)
        var result = "";
        if (!row.isNullAt(2)) result = row.getString(2)

        var vehicle = ""
        var vehicleType = ""
        var weight = ""
        var length = ""
        var startDate = ""
        var endDate = ""
        var srcZoneCode = ""
        var destZoneCode = ""
        var srcLongitude = ""
        var srcLatitude = ""
        var destLongitude = ""
        var destLatitude = ""
        var planRunTime = "" //; if(!row.isNullAt(4)) planRunTime = row.getLong(4).toDouble
        var actualRunTime = ""
        var actualOverTime = ""
        var IsActualTimeOut = ""

        var actualRunTime_new = "" //; if(!row.isNullAt(3)) actualRunTime_new = row.getLong(3).toDouble// / (1000 * 60)).formatted("%.2f").toDouble
        var actualOverTime_new = ""
        var IsActualTimeOut_new = ""

        val resultArray = getTaskResult(taskid)
        planRunTime = resultArray(0)
        actualRunTime_new = resultArray(1)

        if (!StringUtils.isEmpty(result)) {
          var jsonObject: JSONObject = null
          try {
            jsonObject = JSON.parseObject(result)
          } catch {
            case ex: Exception => {}
          }
          if (jsonObject != null) {
            vehicle = getString(jsonObject, "vehicle")
            vehicleType = getString(jsonObject, "vehicleType")
            weight = getString(jsonObject, "weight")
            length = getString(jsonObject, "length")
            startDate = getString(jsonObject, "startDate")
            endDate = getString(jsonObject, "endDate")
            srcZoneCode = getString(jsonObject, "srcZoneCode")
            destZoneCode = getString(jsonObject, "destZoneCode")
            srcLongitude = getString(jsonObject, "srcLongitude")
            srcLatitude = getString(jsonObject, "srcLatitude")
            destLongitude = getString(jsonObject, "destLongitude")
            destLatitude = getString(jsonObject, "destLatitude")
            //planRunTime = getDoubleValue(jsonObject, "planRunTime")
            actualRunTime = getString(jsonObject, "actualRunTime")
            if (!StringUtils.isEmpty(actualRunTime)
              && !StringUtils.isEmpty(planRunTime)) actualOverTime = (actualRunTime.toLong - planRunTime.toLong).toString
            if (!StringUtils.isEmpty(actualOverTime)
              && actualOverTime.toDouble > 1) IsActualTimeOut = "1"
            else if (!StringUtils.isEmpty(actualOverTime)
              && actualOverTime.toDouble <= 1) IsActualTimeOut = "0"
            if (!StringUtils.isEmpty(actualRunTime_new)
              && !StringUtils.isEmpty(planRunTime)) actualOverTime_new = (actualRunTime_new.toDouble - planRunTime.toLong).toString
            if (!StringUtils.isEmpty(actualOverTime_new)
              && actualOverTime_new.toDouble > 1) IsActualTimeOut_new = "1"
            else if (!StringUtils.isEmpty(actualOverTime_new)
              && actualOverTime_new.toDouble <= 1) IsActualTimeOut_new = "0"
          }
        }

        if (StringUtils.isEmpty(srcZoneCode)) srcZoneCode = "-"
        (tm, taskid, vehicle, vehicleType, weight, length, startDate, endDate, srcZoneCode, destZoneCode, srcLongitude, srcLatitude, destLongitude, destLatitude, planRunTime, actualRunTime, actualOverTime, IsActualTimeOut, actualRunTime_new, actualOverTime_new, IsActualTimeOut_new)
      }).toDF("tm", "taskid", "vehicle", "vehicleType", "weight", "length", "startDate", "endDate", "srcZoneCode", "destZoneCode", "srcLongitude", "srcLatitude", "destLongitude", "destLatitude", "planRunTime", "actualRunTime", "actualOverTime", "IsActualTimeOut", "actualRunTime_new", "actualOverTime_new", "IsActualTimeOut_new")
        .repartition(1)
      val table = "dm_gis.traffic_time_log_parse_blockinfo_base_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //任务基础数据表-关联
  def traffic_time_log_parse_blockinfo_v(sparkSession: SparkSession, runDate: String, nextDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_parse_blockinfo_v")

    val flag_sql = "select * from dm_gis.traffic_time_log_parse_blockinfo_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(flag_sql)
    var flag_count = sparkSession.sql(flag_sql)
    var flag = flag_count.take(1).length == 0
    if (!flag) {
      logger.error("dm_gis.traffic_time_log_parse_blockinfo_v已有数据%s，放弃执行".format(runDate))
      return
    }

    val traffic_time_log_parse_blockinfo_flag_sql = "select * from dm_gis.traffic_time_log_parse_blockinfo_base_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_parse_blockinfo_flag_sql)
    var traffic_time_log_parse_blockinfo_count = sparkSession.sql(traffic_time_log_parse_blockinfo_flag_sql)
    var traffic_time_log_parse_blockinfo_flag = traffic_time_log_parse_blockinfo_count.take(1).length == 0
    if (traffic_time_log_parse_blockinfo_flag) {
      logger.error("dm_gis.traffic_time_log_parse_blockinfo_base_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_parse_blockinfo_base_v_sql = "select tm,taskid,vehicle,vehicleType,weight,length,startDate,endDate,srcZoneCode,destZoneCode,srcLongitude,srcLatitude,destLongitude,destLatitude,planRunTime,actualRunTime,actualOverTime,IsActualTimeOut,actualRunTime_new,actualOverTime_new,IsActualTimeOut_new from dm_gis.traffic_time_log_parse_blockinfo_base_v where inc_day='%s'"
        .format(runDate)
      logger.error(traffic_time_log_parse_blockinfo_base_v_sql)
      val traffic_time_log_parse_blockinfo_base_v_new = sparkSession.sql(traffic_time_log_parse_blockinfo_base_v_sql).na.fill("")
      traffic_time_log_parse_blockinfo_base_v_new.createOrReplaceTempView("traffic_time_log_parse_blockinfo_base_v_new")

      val traffic_time_log_parse_report_v_sql = "select taskid,cast(round(sum(realBlockTimes)/60,2) as string) as realBlockTimes,cast(round(sum(duration)/60,2) as string) as duration,cast(round(sum(NewBlockTimes)/60,2) as string) as NewBlockTimes from dm_gis.traffic_time_log_parse_report_v where inc_day>='%s' and inc_day <='%s' and taskid is not null and taskid<>'' and taskid<>'-' group by taskid"
        .format(runDate, nextDate)
      logger.error(traffic_time_log_parse_report_v_sql)
      val traffic_time_log_parse_report_v_new = sparkSession.sql(traffic_time_log_parse_report_v_sql).na.fill("")
      traffic_time_log_parse_report_v_new.createOrReplaceTempView("traffic_time_log_parse_report_v_new")

      val traffic_time_log_parse_weather_sql = "select taskid,cast(sum(weather_time) as string) as weather_time,cast(sum(weather_mileage) as string) as weather_mileage from dm_gis.traffic_time_log_parse_weather where inc_day>='%s' and inc_day <='%s' and taskid is not null and taskid<>'' and taskid<>'-' group by taskid"
        .format(runDate, nextDate)
      logger.error(traffic_time_log_parse_weather_sql)
      val traffic_time_log_parse_weather_new = sparkSession.sql(traffic_time_log_parse_weather_sql).na.fill("")
      traffic_time_log_parse_weather_new.createOrReplaceTempView("traffic_time_log_parse_weather_new")

      val traffic_time_log_parse_blockinfo_base_v_report_sql = "select a.tm,a.taskid,a.vehicle,a.vehicleType,a.weight,a.length,a.startDate,a.endDate,a.srcZoneCode,a.destZoneCode,a.srcLongitude,a.srcLatitude,a.destLongitude,a.destLatitude,a.planRunTime,a.actualRunTime,a.actualOverTime,a.IsActualTimeOut,a.actualRunTime_new,a.actualOverTime_new,a.IsActualTimeOut_new,b.realBlockTimes,b.duration,b.NewBlockTimes,c.weather_time,c.weather_mileage from traffic_time_log_parse_blockinfo_base_v_new a left join traffic_time_log_parse_report_v_new b on a.taskid = b.taskid left join traffic_time_log_parse_weather_new c on a.taskid=c.taskid"
      logger.error(traffic_time_log_parse_blockinfo_base_v_report_sql)
      val traffic_time_log_parse_blockinfo_base_v_report_new = sparkSession.sql(traffic_time_log_parse_blockinfo_base_v_report_sql).na.fill("")
        .rdd
        .map(row => {

          var planRunTime = "";
          if (!row.isNullAt(14)) planRunTime = row.getString(14)
          var actualRunTime = "";
          if (!row.isNullAt(15)) actualRunTime = row.getString(15)
          var actualRunTime_new = "";
          if (!row.isNullAt(18)) actualRunTime_new = row.getString(18)
          //var actualOverTime_new = ""; if(!row.isNullAt(19)) actualOverTime_new = row.getString(19)
          //var IsActualTimeOut_new = ""; if(!row.isNullAt(20)) IsActualTimeOut_new = row.getString(20)
          var realBlockTimes = "";
          if (!row.isNullAt(21)) realBlockTimes = row.getString(21)
          var NewBlockTimes = "";
          if (!row.isNullAt(23)) NewBlockTimes = row.getString(23)

          var compensateOverTime = ""
          var IscompensateTimeOut = ""
          var compensateOverTime_new = ""
          var IscompensateTimeOut_new = ""
          var NewBlockTimesOverTime = ""
          var IsNewBlockTimesTimeOut = ""

          if (!StringUtils.isEmpty(actualRunTime)
            && !StringUtils.isEmpty(planRunTime)
            && !StringUtils.isEmpty(realBlockTimes))
            compensateOverTime = (actualRunTime.toDouble - planRunTime.toDouble - realBlockTimes.toDouble).toString
          if (!StringUtils.isEmpty(compensateOverTime)
            && compensateOverTime.toDouble > 1) IscompensateTimeOut = "1"
          else if (!StringUtils.isEmpty(compensateOverTime)
            && compensateOverTime.toDouble <= 1) IscompensateTimeOut = "0"
          if (!StringUtils.isEmpty(actualRunTime_new)
            && !StringUtils.isEmpty(planRunTime)
            && !StringUtils.isEmpty(realBlockTimes))
            compensateOverTime_new = (actualRunTime_new.toDouble - planRunTime.toDouble - realBlockTimes.toDouble).toString
          if (!StringUtils.isEmpty(compensateOverTime_new)
            && compensateOverTime_new.toDouble > 1) IscompensateTimeOut_new = "1"
          else if (!StringUtils.isEmpty(compensateOverTime_new)
            && compensateOverTime_new.toDouble <= 1) IscompensateTimeOut_new = "0"
          if (!StringUtils.isEmpty(actualRunTime_new)
            && !StringUtils.isEmpty(planRunTime)
            && !StringUtils.isEmpty(NewBlockTimes))
            NewBlockTimesOverTime = (actualRunTime_new.toDouble - planRunTime.toDouble - NewBlockTimes.toDouble).toString
          if (!StringUtils.isEmpty(NewBlockTimesOverTime)
            && NewBlockTimesOverTime.toDouble > 1) IsNewBlockTimesTimeOut = "1"
          else if (!StringUtils.isEmpty(NewBlockTimesOverTime)
            && NewBlockTimesOverTime.toDouble <= 1) IsNewBlockTimesTimeOut = "0"
          Row.fromSeq(row.toSeq ++ Seq(compensateOverTime, IscompensateTimeOut, compensateOverTime_new, IscompensateTimeOut_new, NewBlockTimesOverTime, IsNewBlockTimesTimeOut))
          //          ConnectorGrantsMulti.merge(row, ConnectorGrantsMulti(compensateOverTime,IscompensateTimeOut,compensateOverTime_new,IscompensateTimeOut_new,NewBlockTimesOverTime,IsNewBlockTimesTimeOut))
        })
      val saveColumns = Array("tm", "taskid", "vehicle", "vehicleType", "weight", "length", "startDate", "endDate", "srcZoneCode", "destZoneCode", "srcLongitude", "srcLatitude", "destLongitude", "destLatitude", "planRunTime", "actualRunTime", "actualOverTime", "IsActualTimeOut", "actualRunTime_new", "actualOverTime_new", "IsActualTimeOut_new", "realBlockTimes", "duration", "NewBlockTimes", "weather_time", "weather_mileage", "compensateOverTime", "IscompensateTimeOut", "compensateOverTime_new", "IscompensateTimeOut_new", "NewBlockTimesOverTime", "IsNewBlockTimesTimeOut")
      val schemaEle = new ArrayBuffer[StructField]()
      val keySave = saveColumns
      if (keySave == null) {
        for (i <- saveColumns.indices) {
          schemaEle.append(StructField(saveColumns(i), StringType, nullable = true))
        }
      }
      val traffic_time_log_parse_blockinfo_base_v_report_schema = StructType(schemaEle.toArray)
      var rowDf = sparkSession.createDataFrame(traffic_time_log_parse_blockinfo_base_v_report_new, traffic_time_log_parse_blockinfo_base_v_report_schema)
      rowDf.createOrReplaceTempView("traffic_time_log_parse_blockinfo_base_v_report_dataframe")


      val traffic_time_log_parse_request_tracks_v_sql = "select taskid,speedCompare,type from dm_gis.traffic_time_log_parse_request_tracks_v where inc_day>='%s' and inc_day <='%s' and taskid is not null and taskid<>'' and taskid<>'-'"
        .format(runDate, nextDate)
      logger.error(traffic_time_log_parse_request_tracks_v_sql)
      val traffic_time_log_parse_request_tracks_v_new = sparkSession.sql(traffic_time_log_parse_request_tracks_v_sql).na.fill("")
        .rdd.groupBy(row => row.getString(0))
        .map(item => {

          var taskid = item._1
          var tracksCounts = 0
          var noSwidCounts = 0
          var norticCounts = 0
          var ydCounts = 0
          var yd_0_Counts = 0
          var yd_1_Counts = 0
          var yd_2_Counts = 0
          var yd_3_Counts = 0
          var tcCounts = 0
          var tc_0_Counts = 0
          var tc_1_Counts = 0
          var tc_2_Counts = 0
          var tc_3_Counts = 0

          if (item._2.size > 0) {
            item._2.foreach(row => {
              var speedCompare = "";
              if (!row.isNullAt(1)) speedCompare = row.getString(1)
              var _type = "";
              if (!row.isNullAt(2)) _type = row.getString(2)
              tracksCounts = tracksCounts + 1
              if (!StringUtils.isEmpty(speedCompare)) {
                if ("8".equalsIgnoreCase(speedCompare)) noSwidCounts = noSwidCounts + 1
                else if ("9".equalsIgnoreCase(speedCompare)) norticCounts = norticCounts + 1
                else if ("0".equalsIgnoreCase(speedCompare)) yd_0_Counts = yd_0_Counts + 1
                else if ("1".equalsIgnoreCase(speedCompare)) yd_1_Counts = yd_1_Counts + 1
                else if ("2".equalsIgnoreCase(speedCompare)) yd_2_Counts = yd_2_Counts + 1
                else if ("3".equalsIgnoreCase(speedCompare)) yd_3_Counts = yd_3_Counts + 1
                else if ("4".equalsIgnoreCase(speedCompare)) tc_0_Counts = tc_0_Counts + 1
                else if ("5".equalsIgnoreCase(speedCompare)) tc_1_Counts = tc_1_Counts + 1
                else if ("6".equalsIgnoreCase(speedCompare)) tc_2_Counts = tc_2_Counts + 1
                else if ("7".equalsIgnoreCase(speedCompare)) tc_3_Counts = tc_3_Counts + 1
              }
              if (!StringUtils.isEmpty(_type)) {
                if ("2".equalsIgnoreCase(_type)
                  || "3".equalsIgnoreCase(_type)) ydCounts = ydCounts + 1
                else if ("1".equalsIgnoreCase(_type)) tcCounts = tcCounts + 1
              }
            })
          }

          (taskid, tracksCounts.toString, noSwidCounts.toString, norticCounts.toString, ydCounts.toString, yd_0_Counts.toString, yd_1_Counts.toString, yd_2_Counts.toString, yd_3_Counts.toString, tcCounts.toString, tc_0_Counts.toString, tc_1_Counts.toString, tc_2_Counts.toString, tc_3_Counts.toString)
        }).toDF("taskid", "tracksCounts", "noSwidCounts", "norticCounts", "ydCounts", "yd_0_Counts",
        "yd_1_Counts", "yd_2_Counts", "yd_3_Counts", "tcCounts", "tc_0_Counts", "tc_1_Counts", "tc_2_Counts",
        "tc_3_Counts")

      traffic_time_log_parse_request_tracks_v_new.createOrReplaceTempView("traffic_time_log_parse_request_tracks_v_dataframe")

      val traffic_time_log_parse_blockinfo_sql = "select a.tm,a.taskid,a.vehicle,a.vehicleType,a.weight,a.length,a.startDate,a.endDate,a.srcZoneCode,a.destZoneCode,a.srcLongitude,a.srcLatitude,a.destLongitude,a.destLatitude,a.planRunTime,a.actualRunTime,a.actualOverTime,a.IsActualTimeOut,a.actualRunTime_new,a.actualOverTime_new,a.IsActualTimeOut_new,a.realBlockTimes,a.duration,a.NewBlockTimes,a.compensateOverTime,a.IscompensateTimeOut,a.compensateOverTime_new,a.IscompensateTimeOut_new,a.NewBlockTimesOverTime,a.IsNewBlockTimesTimeOut,b.tracksCounts,b.noSwidCounts,b.norticCounts,b.ydCounts,b.yd_0_Counts,b.yd_1_Counts,b.yd_2_Counts,b.yd_3_Counts,b.tcCounts,b.tc_0_Counts,b.tc_1_Counts,b.tc_2_Counts,b.tc_3_Counts,a.weather_time,a.weather_mileage from traffic_time_log_parse_blockinfo_base_v_report_dataframe a left join traffic_time_log_parse_request_tracks_v_dataframe b on a.taskid = b.taskid"
      logger.error(traffic_time_log_parse_blockinfo_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_parse_blockinfo_sql).na.fill("")
        .repartition(1)
      val table = "dm_gis.traffic_time_log_parse_blockinfo_v"

      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //拥堵服务日志监控-业务量
  def traffic_time_log_stat_v(sparkSession: SparkSession, runDate: String, nextDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_stat_v")

    val traffic_time_log_stat_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_blockinfo_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_stat_v_flag_sql)
    var traffic_time_log_stat_v_count = sparkSession.sql(traffic_time_log_stat_v_flag_sql)
    var traffic_time_log_stat_v_flag = traffic_time_log_stat_v_count.take(1).length == 0
    if (traffic_time_log_stat_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_blockinfo_v没有数据%s，放弃执行".format(runDate))
    }
    else {
      val traffic_time_log_stat_v_base_sql = "select taskid,srcZoneCode,realBlockTimes,IsActualTimeOut_new,IscompensateTimeOut_new,IsNewBlockTimesTimeOut,tracksCounts from dm_gis.traffic_time_log_parse_blockinfo_v where inc_day='%s' and taskid is not null and taskid<>'' and taskid<>'-'"
        .format(runDate)
      logger.error(traffic_time_log_stat_v_base_sql)
      val traffic_time_log_stat_v_base_new = sparkSession.sql(traffic_time_log_stat_v_base_sql).na.fill("")
        .rdd.groupBy(row => row.getString(0)).map(item => {
        val tmp = item._2.toList(0)
        (tmp.getString(0), tmp.getString(1), tmp.getString(2), tmp.getString(3), tmp.getString(4), tmp.getString(5), tmp.getString(6))
      }).toDF("taskid", "srcZoneCode", "realBlockTimes", "IsActualTimeOut_new", "IscompensateTimeOut_new",
        "IsNewBlockTimesTimeOut", "tracksCounts")
      traffic_time_log_stat_v_base_new.createOrReplaceTempView("traffic_time_log_stat_v_base_new")


      val traffic_time_log_parse_request_sql = "select taskid from dm_gis.traffic_time_log_parse_tmctrack_v where inc_day>='%s' and inc_day <='%s' and taskid is not null and taskid<>'' and ret='成功' group by taskid"
        .format(runDate, nextDate)
      logger.error(traffic_time_log_parse_request_sql)
      val traffic_time_log_parse_request_new = sparkSession.sql(traffic_time_log_parse_request_sql).na.fill("")
      traffic_time_log_parse_request_new.createOrReplaceTempView("traffic_time_log_parse_request_new")


      val traffic_time_log_stat_v_sql = "select a.taskid,a.srcZoneCode,a.realBlockTimes,a.IsActualTimeOut_new,a.IscompensateTimeOut_new,a.IsNewBlockTimesTimeOut,a.tracksCounts,b.taskid as task_request from traffic_time_log_stat_v_base_new a left join traffic_time_log_parse_request_new b on a.taskid = b.taskid"
      logger.error(traffic_time_log_stat_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_stat_v_sql).na.fill("")
        .rdd.groupBy(row => row.getString(1))
        .map(item => {
          var srcZoneCode = item._1

          var task_count = 0
          var tracks_count = 0
          var request_count = 0
          var block_count = 0
          var not_timeout_count = 0
          var timeout_count = 0
          var timeout_block_count = 0
          var timeout_compensate_not_count = 0
          var new_timeout_compensate_not_count = 0

          if (item._2.size > 0) {
            item._2.foreach(row => {
              task_count = task_count + 1
              var realBlockTimes = "";
              if (!row.isNullAt(2)) realBlockTimes = row.getString(2)
              var IsActualTimeOut_new = "";
              if (!row.isNullAt(3)) IsActualTimeOut_new = row.getString(3)
              var IscompensateTimeOut_new = "";
              if (!row.isNullAt(4)) IscompensateTimeOut_new = row.getString(4)
              var IsNewBlockTimesTimeOut = "";
              if (!row.isNullAt(5)) IsNewBlockTimesTimeOut = row.getString(5)
              var tracksCounts = "";
              if (!row.isNullAt(6)) tracksCounts = row.getString(6)
              var task_request = row.getString(7)
              if (!StringUtils.isEmpty(tracksCounts)
                && tracksCounts.toDouble > 0)
                tracks_count = tracks_count + 1
              if (!StringUtils.isEmpty(task_request)) {
                request_count = request_count + 1
                if (!StringUtils.isEmpty(IsActualTimeOut_new)
                  && "0".equalsIgnoreCase(IsActualTimeOut_new))
                  not_timeout_count = not_timeout_count + 1
                if (!StringUtils.isEmpty(IsActualTimeOut_new)
                  && "1".equalsIgnoreCase(IsActualTimeOut_new))
                  timeout_count = timeout_count + 1
                if (!StringUtils.isEmpty(IsActualTimeOut_new)
                  && "1".equalsIgnoreCase(IsActualTimeOut_new)
                  && !StringUtils.isEmpty(realBlockTimes)
                  && realBlockTimes.toDouble > 0)
                  timeout_block_count = timeout_block_count + 1
                if (!StringUtils.isEmpty(IsActualTimeOut_new)
                  && "1".equalsIgnoreCase(IsActualTimeOut_new)
                  && !StringUtils.isEmpty(IscompensateTimeOut_new)
                  && "0".equalsIgnoreCase(IscompensateTimeOut_new))
                  timeout_compensate_not_count = timeout_compensate_not_count + 1
                if (!StringUtils.isEmpty(IsActualTimeOut_new)
                  && "1".equalsIgnoreCase(IsActualTimeOut_new)
                  && !StringUtils.isEmpty(IsNewBlockTimesTimeOut)
                  && "0".equalsIgnoreCase(IsNewBlockTimesTimeOut))
                  new_timeout_compensate_not_count = new_timeout_compensate_not_count + 1
              }
              if (!StringUtils.isEmpty(realBlockTimes)
                && realBlockTimes.toDouble > 0)
                block_count = block_count + 1
            })
          }

          (srcZoneCode, task_count.toString, tracks_count.toString, request_count.toString, block_count.toString, not_timeout_count.toString, timeout_count.toString, timeout_block_count.toString, timeout_compensate_not_count.toString, new_timeout_compensate_not_count.toString)
        }).toDF("srcZoneCode", "task_count", "tracks_count", "request_count", "block_count", "not_timeout_count", "timeout_count", "timeout_block_count", "timeout_compensate_not_count", "new_timeout_compensate_not_count")
        .repartition(1)

      val table = "dm_gis.traffic_time_log_stat_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  //拥堵服务日志监控-超时分布
  def traffic_time_log_stat_timeout_v(sparkSession: SparkSession, runDate: String, nextDate: String): Unit = {
    import sparkSession.implicits._
    logger.error("开始统计traffic_time_log_stat_timeout_v")

    val traffic_time_log_stat_timeout_v_flag_sql = "select * from dm_gis.traffic_time_log_parse_blockinfo_v where inc_day='%s' limit 1"
      .format(runDate)
    logger.error(traffic_time_log_stat_timeout_v_flag_sql)
    var traffic_time_log_stat_timeout_v_count = sparkSession.sql(traffic_time_log_stat_timeout_v_flag_sql)
    var traffic_time_log_stat_timeout_v_flag = traffic_time_log_stat_timeout_v_count.take(1).length == 0
    if (traffic_time_log_stat_timeout_v_flag) {
      logger.error("dm_gis.traffic_time_log_parse_blockinfo_v没有数据%s，放弃执行".format(runDate))
    }
    else {

      val traffic_time_log_stat_v_base_sql = "select taskid,srcZoneCode,IsActualTimeOut_new,IscompensateTimeOut_new,actualOverTime_new,compensateOverTime_new,IsNewBlockTimesTimeOut,NewBlockTimesOverTime from dm_gis.traffic_time_log_parse_blockinfo_v where inc_day='%s' and taskid is not null and taskid<>'' and taskid<>'-'"
        .format(runDate)
      logger.error(traffic_time_log_stat_v_base_sql)
      val traffic_time_log_stat_v_base_new = sparkSession.sql(traffic_time_log_stat_v_base_sql).na.fill("")
        .rdd.groupBy(row => row.getString(0)).map(item => {

        val tmp = item._2.toList(0)
        (tmp.getString(0), tmp.getString(1), tmp.getString(2), tmp.getString(3), tmp.getString(4), tmp.getString(5),
          tmp.getString(6), tmp.getString(7))
      }).toDF("taskid", "srcZoneCode", "IsActualTimeOut_new", "IscompensateTimeOut_new", "actualOverTime_new", "compensateOverTime_new", "IsNewBlockTimesTimeOut", "NewBlockTimesOverTime")

      traffic_time_log_stat_v_base_new.createOrReplaceTempView("traffic_time_log_stat_v_base_new")

      val traffic_time_log_parse_request_sql = "select taskid from dm_gis.traffic_time_log_parse_tmctrack_v where inc_day>='%s' and inc_day <='%s' and taskid is not null and taskid<>'' and taskid<>'-' and ret='成功' group by taskid"
        .format(runDate, nextDate)
      logger.error(traffic_time_log_parse_request_sql)
      val traffic_time_log_parse_request_new = sparkSession.sql(traffic_time_log_parse_request_sql).na.fill("")
      traffic_time_log_parse_request_new.createOrReplaceTempView("traffic_time_log_parse_request_new")


      //val traffic_time_log_stat_timeout_v_sql = "select srcZoneCode,IsActualTimeOut_new,IscompensateTimeOut_new,actualOverTime_new,compensateOverTime_new from dm_gis.traffic_time_log_parse_blockinfo_v where inc_day='%s' and (IsActualTimeOut_new = 1 or IscompensateTimeOut_new = 1)"
      val traffic_time_log_stat_timeout_v_sql = "select a.taskid,a.srcZoneCode,a.IsActualTimeOut_new,a.IscompensateTimeOut_new,a.actualOverTime_new,a.compensateOverTime_new,a.IsNewBlockTimesTimeOut,a.NewBlockTimesOverTime,b.taskid as task_request from traffic_time_log_stat_v_base_new a left join traffic_time_log_parse_request_new b on a.taskid = b.taskid"
      //.format(runDate)
      logger.error(traffic_time_log_stat_timeout_v_sql)
      val result_rdd = sparkSession.sql(traffic_time_log_stat_timeout_v_sql).na.fill("")
        .rdd.groupBy(row => row.getString(1))
        .flatMap(item => {
          var srcZoneCode = item._1
          var resultList: List[Array[String]] = List()

          var timeout_count = 0
          var compensate_timeout_count = 0
          var new_compensate_timeout_count = 0
          var timeout_1_5_count = 0
          var timeout_5_10_count = 0
          var timeout_10_20_count = 0
          var timeout_20_30_count = 0
          var timeout_30_40_count = 0
          var timeout_40_50_count = 0
          var timeout_50_60_count = 0
          var timeout_60_70_count = 0
          var timeout_70_80_count = 0
          var timeout_80_90_count = 0
          var timeout_90_100_count = 0
          var timeout_100_count = 0
          var compensate_timeout_1_5_count = 0
          var compensate_timeout_5_10_count = 0
          var compensate_timeout_10_20_count = 0
          var compensate_timeout_20_30_count = 0
          var compensate_timeout_30_40_count = 0
          var compensate_timeout_40_50_count = 0
          var compensate_timeout_50_60_count = 0
          var compensate_timeout_60_70_count = 0
          var compensate_timeout_70_80_count = 0
          var compensate_timeout_80_90_count = 0
          var compensate_timeout_90_100_count = 0
          var compensate_timeout_100_count = 0
          var new_compensate_timeout_1_5_count = 0
          var new_compensate_timeout_5_10_count = 0
          var new_compensate_timeout_10_20_count = 0
          var new_compensate_timeout_20_30_count = 0
          var new_compensate_timeout_30_40_count = 0
          var new_compensate_timeout_40_50_count = 0
          var new_compensate_timeout_50_60_count = 0
          var new_compensate_timeout_60_70_count = 0
          var new_compensate_timeout_70_80_count = 0
          var new_compensate_timeout_80_90_count = 0
          var new_compensate_timeout_90_100_count = 0
          var new_compensate_timeout_100_count = 0

          if (item._2.size > 0) {
            item._2.foreach(row => {
              var IsActualTimeOut_new = "";
              if (!row.isNullAt(2)) IsActualTimeOut_new = row.getString(2)
              var IscompensateTimeOut_new = "";
              if (!row.isNullAt(3)) IscompensateTimeOut_new = row.getString(3)
              var actualOverTime_new = "";
              if (!row.isNullAt(4)) actualOverTime_new = row.getString(4)
              var compensateOverTime_new = "";
              if (!row.isNullAt(5)) compensateOverTime_new = row.getString(5)
              var IsNewBlockTimesTimeOut = "";
              if (!row.isNullAt(6)) IsNewBlockTimesTimeOut = row.getString(6)
              var NewBlockTimesOverTime = "";
              if (!row.isNullAt(7)) NewBlockTimesOverTime = row.getString(7)
              var task_request = row.getString(8)

              if (!StringUtils.isEmpty(task_request)) {
                if (!StringUtils.isEmpty(IsActualTimeOut_new)
                  && "1".equalsIgnoreCase(IsActualTimeOut_new)) {
                  timeout_count = timeout_count + 1
                  if (!StringUtils.isEmpty(actualOverTime_new)
                    && actualOverTime_new.toDouble > 1) {
                    if (actualOverTime_new.toDouble <= 5) timeout_1_5_count = timeout_1_5_count + 1
                    else if (actualOverTime_new.toDouble <= 10) timeout_5_10_count = timeout_5_10_count + 1
                    else if (actualOverTime_new.toDouble <= 20) timeout_10_20_count = timeout_10_20_count + 1
                    else if (actualOverTime_new.toDouble <= 30) timeout_20_30_count = timeout_20_30_count + 1
                    else if (actualOverTime_new.toDouble <= 40) timeout_30_40_count = timeout_30_40_count + 1
                    else if (actualOverTime_new.toDouble <= 50) timeout_40_50_count = timeout_40_50_count + 1
                    else if (actualOverTime_new.toDouble <= 60) timeout_50_60_count = timeout_50_60_count + 1
                    else if (actualOverTime_new.toDouble <= 70) timeout_60_70_count = timeout_60_70_count + 1
                    else if (actualOverTime_new.toDouble <= 80) timeout_70_80_count = timeout_70_80_count + 1
                    else if (actualOverTime_new.toDouble <= 90) timeout_80_90_count = timeout_80_90_count + 1
                    else if (actualOverTime_new.toDouble <= 100) timeout_90_100_count = timeout_90_100_count + 1
                    else if (actualOverTime_new.toDouble > 100) timeout_100_count = timeout_100_count + 1
                  }

                  if (!StringUtils.isEmpty(IscompensateTimeOut_new)
                    && !"0".equalsIgnoreCase(IscompensateTimeOut_new)) {
                    compensate_timeout_count = compensate_timeout_count + 1
                    if (!StringUtils.isEmpty(compensateOverTime_new)
                      && compensateOverTime_new.toDouble > 1) {
                      if (compensateOverTime_new.toDouble <= 5) compensate_timeout_1_5_count = compensate_timeout_1_5_count + 1
                      else if (compensateOverTime_new.toDouble <= 10) compensate_timeout_5_10_count = compensate_timeout_5_10_count + 1
                      else if (compensateOverTime_new.toDouble <= 20) compensate_timeout_10_20_count = compensate_timeout_10_20_count + 1
                      else if (compensateOverTime_new.toDouble <= 30) compensate_timeout_20_30_count = compensate_timeout_20_30_count + 1
                      else if (compensateOverTime_new.toDouble <= 40) compensate_timeout_30_40_count = compensate_timeout_30_40_count + 1
                      else if (compensateOverTime_new.toDouble <= 50) compensate_timeout_40_50_count = compensate_timeout_40_50_count + 1
                      else if (compensateOverTime_new.toDouble <= 60) compensate_timeout_50_60_count = compensate_timeout_50_60_count + 1
                      else if (compensateOverTime_new.toDouble <= 70) compensate_timeout_60_70_count = compensate_timeout_60_70_count + 1
                      else if (compensateOverTime_new.toDouble <= 80) compensate_timeout_70_80_count = compensate_timeout_70_80_count + 1
                      else if (compensateOverTime_new.toDouble <= 90) compensate_timeout_80_90_count = compensate_timeout_80_90_count + 1
                      else if (compensateOverTime_new.toDouble <= 100) compensate_timeout_90_100_count = compensate_timeout_90_100_count + 1
                      else if (compensateOverTime_new.toDouble > 100) compensate_timeout_100_count = compensate_timeout_100_count + 1
                    }
                  }

                  if (!StringUtils.isEmpty(IsNewBlockTimesTimeOut)
                    && !"0".equalsIgnoreCase(IsNewBlockTimesTimeOut)) {
                    new_compensate_timeout_count = new_compensate_timeout_count + 1
                    if (!StringUtils.isEmpty(NewBlockTimesOverTime)
                      && NewBlockTimesOverTime.toDouble > 1) {
                      if (NewBlockTimesOverTime.toDouble <= 5) new_compensate_timeout_1_5_count = new_compensate_timeout_1_5_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 10) new_compensate_timeout_5_10_count = new_compensate_timeout_5_10_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 20) new_compensate_timeout_10_20_count = new_compensate_timeout_10_20_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 30) new_compensate_timeout_20_30_count = new_compensate_timeout_20_30_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 40) new_compensate_timeout_30_40_count = new_compensate_timeout_30_40_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 50) new_compensate_timeout_40_50_count = new_compensate_timeout_40_50_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 60) new_compensate_timeout_50_60_count = new_compensate_timeout_50_60_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 70) new_compensate_timeout_60_70_count = new_compensate_timeout_60_70_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 80) new_compensate_timeout_70_80_count = new_compensate_timeout_70_80_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 90) new_compensate_timeout_80_90_count = new_compensate_timeout_80_90_count + 1
                      else if (NewBlockTimesOverTime.toDouble <= 100) new_compensate_timeout_90_100_count = new_compensate_timeout_90_100_count + 1
                      else if (NewBlockTimesOverTime.toDouble > 100) new_compensate_timeout_100_count = new_compensate_timeout_100_count + 1
                    }
                  }
                }
              }
            })
          }

          resultList = resultList :+ Array(srcZoneCode, "实际运行", timeout_count.toString, timeout_1_5_count.toString, timeout_5_10_count.toString, timeout_10_20_count.toString, timeout_20_30_count.toString, timeout_30_40_count.toString, timeout_40_50_count.toString, timeout_50_60_count.toString, timeout_60_70_count.toString, timeout_70_80_count.toString, timeout_80_90_count.toString, timeout_90_100_count.toString, timeout_100_count.toString)
          resultList = resultList :+ Array(srcZoneCode, "拥堵补偿后", compensate_timeout_count.toString, compensate_timeout_1_5_count.toString, compensate_timeout_5_10_count.toString, compensate_timeout_10_20_count.toString, compensate_timeout_20_30_count.toString, compensate_timeout_30_40_count.toString, compensate_timeout_40_50_count.toString, compensate_timeout_50_60_count.toString, compensate_timeout_60_70_count.toString, compensate_timeout_70_80_count.toString, compensate_timeout_80_90_count.toString, compensate_timeout_90_100_count.toString, compensate_timeout_100_count.toString)
          resultList = resultList :+ Array(srcZoneCode, "新拥堵补偿后", new_compensate_timeout_count.toString, new_compensate_timeout_1_5_count.toString, new_compensate_timeout_5_10_count.toString, new_compensate_timeout_10_20_count.toString, new_compensate_timeout_20_30_count.toString, new_compensate_timeout_30_40_count.toString, new_compensate_timeout_40_50_count.toString, new_compensate_timeout_50_60_count.toString, new_compensate_timeout_60_70_count.toString, new_compensate_timeout_70_80_count.toString, new_compensate_timeout_80_90_count.toString, new_compensate_timeout_90_100_count.toString, new_compensate_timeout_100_count.toString)
          resultList
        }).map(obj => {
        (obj(0), obj(1), obj(2), obj(3), obj(4), obj(5), obj(6), obj(7), obj(8), obj(9), obj(10), obj(11), obj(12),
          obj(13), obj(14))
      }).toDF("srcZoneCode", "stat_type", "timeout_count", "timeout_1_5_count", "timeout_5_10_count", "timeout_10_20_count", "timeout_20_30_count", "timeout_30_40_count", "timeout_40_50_count", "timeout_50_60_count", "timeout_60_70_count", "timeout_70_80_count", "timeout_80_90_count", "timeout_90_100_count", "timeout_100_count")
        .repartition(1)
      val table = "dm_gis.traffic_time_log_stat_timeout_v"
      val tmpView = "tmp" + System.currentTimeMillis()
      result_rdd.createOrReplaceTempView(tmpView)
      saveData(sparkSession, tmpView, table, runDate)
    }

  }


  // 推送拥堵服务日志监控结果到数据库
  def push_traffic_stat_data(sparkSession: SparkSession, runDate: String): Unit = {
    logger.error("推送%s的拥堵服务日志监控结果到数据库...".format(runDate))
    var table = ""
    var structs: Array[String] = null

    logger.error("推送%s的结果到TRAFFIC_BLOCK...".format(runDate))
    table = "TRAFFIC_BLOCK"
    structs = Array("ID", "STAT_DATE", "ZC", "TASK_COUNT", "TRACKS_COUNT", "REQUEST_COUNT", "BLOCK_COUNT", "NOT_TIMEOUNT_COUNT", "TIMEOUNT_COUNT", "TIMEOUNT_BLOCK_COUNT", "TIMEOUT_COMPENSATE_NOT_COUNT", "NEW_TIMEOUT_COMPENSATE_NOT_COUNT")
    saveToMysql(get_traffic_block_rdd(sparkSession, runDate), table, structs, runDate)

    logger.error("推送%s的结果到TRAFFIC_TIMEOUT...".format(runDate))
    table = "TRAFFIC_TIMEOUT"
    structs = Array("ID", "STAT_DATE", "ZC", "STAT_TYPE", "TIMEOUT_COUNT", "TIMEOUT15", "TIMEOUT510", "TIMEOUT1020", "TIMEOUT2030", "TIMEOUT3040", "TIMEOUT4050", "TIMEOUT5060", "TIMEOUT6070", "TIMEOUT7080", "TIMEOUT8090", "TIMEOUT90100", "TIMEOUT100")
    saveToMysql(get_traffic_timeout_rdd(sparkSession, runDate), table, structs, runDate)

  }


  // 获取traffic_block的统计结果
  def get_traffic_block_rdd(sparkSession: SparkSession, runDate: String): RDD[Array[Any]] = {
    val sql = "select srcZoneCode,cast(task_count as int) as task_count,cast(tracks_count as int) as tracks_count,cast(request_count as int) as request_count,cast(block_count as int) as block_count,cast(not_timeout_count as int) as not_timeout_count,cast(timeout_count as int) as timeout_count,cast(timeout_block_count as int) as timeout_block_count,cast(timeout_compensate_not_count as int) as timeout_compensate_not_count,cast(new_timeout_compensate_not_count as int) as new_timeout_compensate_not_count from dm_gis.traffic_time_log_stat_v where inc_day='%s'"
      .format(runDate)
    logger.error(sql)

    var rdd = sparkSession.sql(sql).na.fill("").rdd.map(row => {
      var ID = ""
      var STAT_DATE = runDate
      var srcZoneCode = row.getString(0)

      ID = DigestUtils.md5Hex(STAT_DATE + srcZoneCode)
      (Seq(ID, STAT_DATE) ++ row.toSeq).toArray
    })

    return rdd
  }


  // 获取traffic_timeout的统计结果
  def get_traffic_timeout_rdd(sparkSession: SparkSession, runDate: String): RDD[Array[Any]] = {
    val sql = "select srcZoneCode,stat_type,cast(timeout_count as int) as timeout_count,cast(timeout_1_5_count as int) as timeout_1_5_count,cast(timeout_5_10_count as int) as timeout_5_10_count,cast(timeout_10_20_count as int) as timeout_10_20_count,cast(timeout_20_30_count as int) as timeout_20_30_count,cast(timeout_30_40_count as int) as timeout_30_40_count,cast(timeout_40_50_count as int) as timeout_40_50_count,cast(timeout_50_60_count as int) as timeout_50_60_count,cast(timeout_60_70_count as int) as timeout_60_70_count,cast(timeout_70_80_count as int) as timeout_70_80_count,cast(timeout_80_90_count as int) as timeout_80_90_count,cast(timeout_90_100_count as int) as timeout_90_100_count,cast(timeout_100_count as int) as timeout_100_count from dm_gis.traffic_time_log_stat_timeout_v where inc_day='%s'"
      .format(runDate)
    logger.error(sql)

    var rdd = sparkSession.sql(sql).na.fill("").rdd.map(row => {
      var ID = ""
      var STAT_DATE = runDate
      var srcZoneCode = row.getString(0)
      var stat_type = row.getString(1)

      ID = DigestUtils.md5Hex(STAT_DATE + srcZoneCode + stat_type)

      (Seq(ID, STAT_DATE) ++ row.toSeq).toArray
    })

    return rdd
  }


  def getString(jsonObject: JSONObject, key: String) = {
    var result = ""
    try {
      if (jsonObject.containsKey(key)) result = jsonObject.getString(key)
    }
    catch {
      case ex: Exception => {}
    }
    if (StringUtils.isEmpty(result)) result = ""

    result
  }


  //查询车辆信息接口
  def getTaskResult(taskId: String): Array[String] = {
    val result = new Array[String](2)
    result(0) = null
    result(1) = null
    if (StringUtils.isEmpty(taskId) || "-".equalsIgnoreCase(taskId)) return result
    val url = "http://trtms-ground-int-gw.int.sfdc.com.cn:1080/shiva-trtms-ground-russtask/taskMonitorRestService/getTaskResult"
    var httpResult = "" //
    val client = HttpClients.createDefault()
    breakable(
      for (i <- 1 to 3) {
        try {
          val post: HttpPost = new HttpPost(url)
          post.addHeader("Content-Type", "application/json; charset=utf-8")
          post.setEntity(new StringEntity("{\"taskId\":\"" + taskId + "\"}", Charset.forName("UTF-8")))
          val response: CloseableHttpResponse = client.execute(post)
          val entity: HttpEntity = response.getEntity
          httpResult = EntityUtils.toString(entity, "UTF-8")
          if (StringUtils.isEmpty(httpResult)) {
            Thread.sleep(1500)
          }
          else {
            val jsonObject = JSON.parseObject(httpResult)
            if (jsonObject != null && jsonObject.getBooleanValue("success")) {
              val resultObject = jsonObject.getJSONObject("result")
              if (resultObject != null) {
                val planRunTime = getString(resultObject, "planRunTime")
                val actualRunTime = getString(resultObject, "actualRunTime")
                if (planRunTime != null) result(0) = planRunTime
                if (actualRunTime != null) result(1) = actualRunTime
                Thread.sleep(400)
                break
              }
              Thread.sleep(1500)
            }
            else {
              Thread.sleep(1500)
            }
          }
        }
        catch {
          case ex: Exception => {
          }
        }
      })

    client.close()
    return result
  }


  def saveToMysql(indexRdd: RDD[Array[Any]], table: String, structs: Array[String], date: String): Unit = {
    try {
      val connection = getConnection()
      val fields = structs.mkString(",")
      val values = structs.map(_ => "?").mkString(",")
      val deleteSql = s"DELETE FROM $table WHERE STAT_DATE='$date'"
      println(">>>清除当日数据：" + deleteSql)
      DbUtil.execute(connection, deleteSql, null)
      val params = indexRdd.collect().toList
      logger.error(">>>当日统计指标数据量：" + params.size)
      val insertSql =
        s"""
           |INSERT INTO $table ($fields)
           |VALUES ($values)
             """.stripMargin
      DbUtil.batchListExecute(connection, insertSql, params)
      connection.close()
      logger.error(">>>指标入mysql库的" + table + "表结束！")
    } catch {
      case e: Exception => logger.error(">>>指标mysql库的" + table + "异常：" + e)
    }
  }


  def getConnection(): Connection = {
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    @transient val connection = DriverManager.getConnection(url, user, password)
    connection
  }


}
