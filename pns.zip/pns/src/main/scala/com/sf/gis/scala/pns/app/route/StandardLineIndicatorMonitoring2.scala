package com.sf.gis.scala.pns.app.route

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.{Logger, LoggerFactory}

class StandardLineIndicatorMonitoring2 {

    private final val CLASS_NAME: String = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER: Logger = LoggerFactory.getLogger(CLASS_NAME)

    /**
     * 结果表一车牌去重
     * @param spark SparkSession
     * @param incMonth incDay
     * @return
     */
    def gis_eta_jiazhi_task(spark: SparkSession, incMonth: String, prevMonth: String): DataFrame = {
        val sql =
            s"""
               |select vehicle_serial
               |from dm_gis.gis_eta_jiazhi_task
               |where substr(inc_day, 1, 6) in ('$incMonth', '$prevMonth')
               |group by vehicle_serial
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * 处理ods_vms.tt_vms_driving_log表
     * @param spark SparkSession
     * @param incMonth 月
     * @return
     */
    def tt_vms_driving_log(spark: SparkSession, incMonth: String): DataFrame = {
        val sql =
            s"""
               |select
               |	vehiclecode,
               |	sum(day_miles) miles_month,
               |	sum(day_fuel) fuel_month,
               |	count(1) days_month,
               |	inc_month
               |from ods_vms.tt_vms_driving_log
               |where inc_month = '$incMonth'
               |group by vehiclecode, inc_month
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def execute(spark: SparkSession, incDay: String, curMonth: String, prevMonth: String, csvPath: String): Unit = {
        LOGGER.info("结果表1：dm_gis.gis_eta_jiazhi_task")
        val result1 = gis_eta_jiazhi_task(spark, curMonth, prevMonth)
        LOGGER.info("行车日志汇总表（中间表5）：ods_vms.tt_vms_driving_log")
        val table5 = tt_vms_driving_log(spark, curMonth)
        LOGGER.info("车辆信息表（中间表4）：ods_vms.tm_vms_vehicle")
        val table4 = new StandardLineIndicatorMonitoring1().merge_tm_vms_vehicle_and_csv_file(spark, incDay, csvPath)

        LOGGER.info("##########################注册临时视图查询##########################")

        result1.createOrReplaceTempView("r1")
        table5.createOrReplaceTempView("t5")
        table4.createOrReplaceTempView("t4")

        val sql =
            s"""
               |insert overwrite table dm_gis.gis_vehicle_fule partition (month = '$curMonth')
               |select
               |    t5.vehiclecode,
               |    t4.axle_number,
               |    t4.length,
               |    t4.weight,
               |    t4.mload,
               |    t5.miles_month,
               |    t5.fuel_month,
               |    t5.days_month,
               |    t4.length_weight,
               |    round(t5.fuel_month/t5.miles_month*100, 2)
               |from t5
               |inner join r1 on t5.vehiclecode = r1.vehicle_serial
               |left join t4 on t5.vehiclecode = t4.vehicle_serial
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
        LOGGER.info("#################dm_gis.gis_vehicle_fule写入完成#################关")
    }
}

object StandardLineIndicatorMonitoring2 {
    def main(args: Array[String]): Unit = {
        val task = new StandardLineIndicatorMonitoring2
        task.LOGGER.info("args length: [{}]", args.length)
        if (args == null || args.length != 2) {
            task.LOGGER.error("请传入日期参数和csv文件路径参数")
            return
        }
        val incDay = args(0)
        val csvPath = args(1)
        if (StringUtils.isEmpty(incDay) || StringUtils.isEmpty(csvPath)) {
            task.LOGGER.error("参数错误存在空值")
            return
        }
//        val curMonth = DateUtil.getBeforeNMonth(incDay, 0)
//        val prevMonth = DateUtil.getBeforeNMonth(incDay, -1)

        val curMonth = DateUtil.getMouthBefore(incDay, 0)
        val prevMonth = DateUtil.getMouthBefore(incDay, 1)

        task.LOGGER.info("###########################################################")
        task.LOGGER.info("incDay: [{}]", incDay)
        task.LOGGER.info("curMonth: [{}]", curMonth)
        task.LOGGER.info("csvPath: [{}]", csvPath)
        task.LOGGER.info("prevMonth: [{}]", prevMonth)
        task.LOGGER.info("###########################################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession

        task.execute(spark, incDay, curMonth, prevMonth, csvPath)

        task.LOGGER.info("任务执行完成")

        spark.stop()
    }
}
