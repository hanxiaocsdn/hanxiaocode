package com.sf.gis.scala.base.config

import java.sql.DriverManager

import com.sf.gis.scala.base.util.StringUtils
import org.apache.spark.sql.SparkSession

/***
 * 用于获取网址，防止网址变更
 */
object DomainConfig {
  /**
   * 通过mysql获取domain
   * @param name
   * @return
   */
  def queryFromMysql(name:String) ={
    var ret = ""
    try {
      val url: String = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useUnicode=true&amp;characterEncoding=utf-8"
      val username: String = "gis_oms_rds"
      val password: String = "gis_oms_rds@123@"
      Class.forName("com.mysql.jdbc.Driver");
      val conn = DriverManager.getConnection(url, username, password)
      val sql = s"select `domain` from domain_config where name = '${name}' limit 1"
      val ps = conn.prepareStatement(sql)
      val result = ps.executeQuery()

      while (result.next()) {
        ret = result.getString("domain")
      }
    }catch {
      case exception: Exception=> println(exception)
    }
    ret
  }

  def queryFromHive(spark: SparkSession, name: String): String = {
    val sql = s"select domain from dm_gis.domain_config where name='${name}' "
    println(sql)
    val data = spark.sql(sql).rdd.map(obj=>{
      obj.getString(0)
    }).collect()
    if(data.size>0){
      data(0)
    }else{
      ""
    }
  }

  def findRongZaiDomain(spark:SparkSession): String ={
    //优先从mysql获取
    var domain = queryFromMysql("rongzai")
    if(StringUtils.nonEmpty(domain)){
      println("容灾:"+domain)
      return domain
    }
    //取不到从表中获取
    domain = queryFromHive(spark,"rongzai")
    if(StringUtils.nonEmpty(domain)){
      println("容灾:"+domain)
      return domain
    }
    throw new Exception("没有找到配置的域名")
  }


}
