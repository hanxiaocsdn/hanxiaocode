package com.sf.gis.scala.base.spark

import java.sql.DriverManager
import java.util.{Map, Properties}

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

object SparkUtils {
  //aggregateByKey的柯里化函数,将JSONObject聚合成List[JSONObject]
  val seqOp = (a: List[JSONObject], b: JSONObject) => a.size match {
    case 0 => List(b)
    case _ => b::a
  }

  val combOp = (a: List[JSONObject], b: List[JSONObject]) => {
    a ::: b
  }

  val seqOpRow = (a: List[Row], b: Row) => a.size match {
    case 0 => List(b)
    case _ => b::a
  }

  val combOpRow = (a: List[Row], b: List[Row]) => {
    a ::: b
  }






  def df2Hive(spark:SparkSession,rdd: RDD[Row],schema:StructType,saveMode:String,descTable:String,partitionSchm:String,incDay:String,logger: Logger): Unit = {
    logger.error(s"写入hive ${descTable}中...")
    val df = spark.sqlContext.createDataFrame(rdd,schema)
    //写入前删除分区数据
    val dropSql = s"alter table $descTable drop if exists partition($partitionSchm='$incDay')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(partitionSchm).saveAsTable(descTable)

    logger.error(s"写入分区${incDay}成功")
  }

  def df2HivePs(spark:SparkSession,rdd: RDD[Row],schema:StructType,saveMode:String,descTable:String,incDay:String,region:String,logger: Logger,partitionDay:String,partitionRegion:String): Unit = {
    logger.error(s"写入hive ${descTable}中...")
    val df = spark.sqlContext.createDataFrame(rdd,schema)
    //写入前删除分区数据
    val dropSql = s"alter table $descTable drop if exists partition($incDay='$partitionDay',$region='$partitionRegion')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(incDay,region).saveAsTable(descTable)

    logger.error(s"写入分区 $partitionDay,$partitionRegion 成功")
  }

  def df2Hive(spark:SparkSession, df:DataFrame,saveMode:String,descTable:String,partitionSchm:String,incDay:String,logger: Logger): Unit = {
    logger.error(s"写入hive ${descTable}中...")

    //写入前删除分区数据
    val dropSql = s"alter table ${descTable} drop if exists partition($partitionSchm='$incDay')"
    logger.error(dropSql)
    spark.sql(dropSql)

    df.write.format("hive").mode(saveMode).partitionBy(partitionSchm).saveAsTable(descTable)

    logger.error(s"写入分区${partitionSchm}成功")
  }

  def getRowToJson( spark:SparkSession,querySql:String,parNum:Int=200 ) ={
    val sourDf = spark.sql(querySql)
      //.persist(StorageLevel.DISK_ONLY)

    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    println(s"共获取数据:${sourRdd.count()}")
    sourRdd
  }
  //统计数量之后清楚缓存
  def getRowToJsonClear( spark:SparkSession,querySql:String,parNum:Int=200 ) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    println(s"共获取数据:${sourDf.count()}")
    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    })
    sourDf.unpersist()
    sourRdd
  }
  def getDfToJson( spark:SparkSession,sourDf:DataFrame,parNum:Int=200 ) ={
    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    })
    //println(s"共获取数据:${sourRdd.count()}")

    //sourDf.unpersist()

    sourRdd
  }

  def getRowToJsonTurp( spark:SparkSession,querySql:String,key:String,parNum:Int=200 ) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.DISK_ONLY)

    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      (jsonObj.getString(key),jsonObj)
    }).persist(StorageLevel.DISK_ONLY)

    sourRdd
  }



  /**
    * 限制spark分区中ak使用数量
    * @param stratTime
    * @param cnt
    * @param index
    * @param limitMin
    * @param logger
    */
  def limitAkUse( stratTime:StratTime,cnt:Cnt,index:Int,limitMin:Int,logger:Logger ) ={
    cnt.cnt += 1

    if ( cnt.cnt == limitMin  ) {
      val endTime = System.currentTimeMillis() - stratTime.stratTime

      if( endTime <= 60 * 1000 ){
        logger.error( s"分区$index,每分钟访问量超过限制$limitMin,休眠${60*1000 - endTime } ms中" )
        Thread.sleep(60*1000 - endTime )
      }

      stratTime.stratTime = System.currentTimeMillis()
      cnt.cnt = 0
    }
  }

}
