package com.sf.gis.scala.base.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.ShellExcutor
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
 * 不推荐使用，存在删除风险
 */
object SaveResultUtil {

  //将JsonObject格式数据入库到hive中
  def saveResult(logger:Logger,spark: SparkSession,saveRDD:RDD[JSONObject], saveResult:(RDD[JSONObject],String) => Unit,saveTable:String,date: String): Unit = {
    logger.error(">>>开始入库...<<<")
    val deParSql = s"alter table dm_gis.$saveTable drop if  exists partition(inc_day='$date')"
    spark.sql(deParSql)

    val path = s"/user/hive/warehouse/dm_gis.db/$saveTable/inc_day=$date"

    logger.error(path)

    ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R %s",path))

    saveResult(saveRDD,path)

    val addSql =  s"""LOAD DATA INPATH '$path' INTO TABLE dm_gis.$saveTable PARTITION (inc_day='${date}')""";
    logger.error(addSql)
    spark.sql(addSql)
  }

  def saveResult(logger:Logger,spark: SparkSession,saveRDD:RDD[JSONObject], saveResult:(RDD[JSONObject],String) => Unit,saveTable:String,date: String,hdfsPathPrefix:String): Unit = {
    logger.error(">>>开始入库...<<<")

    val deParSql = s"alter table dm_gis.$saveTable drop if exists partition(inc_day='$date')"
    logger.error(deParSql)
    spark.sql(deParSql)

    val path = s"$hdfsPathPrefix/user/hive/warehouse/dm_gis.db/$saveTable/inc_day=$date"

    logger.error(path)

    ShellExcutor.exeCmd(String.format(s"hdfs dfs -rm -R $hdfsPathPrefix/user/hive/warehouse/dm_gis.db/%s/inc_day=%s",saveTable,date))

    saveResult(saveRDD,path)

    val addSql =  s"""LOAD DATA INPATH '$path' INTO TABLE dm_gis.$saveTable PARTITION (inc_day='${date}')""";
    logger.error(addSql)
    spark.sql(addSql)
  }
}
