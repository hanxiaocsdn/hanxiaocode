package com.sf.gis.scala.base.util

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-03-07 15:30
 * @TaskId:
 * @TaskName:
 * @Description:城市代码工具类
 */
object CityUtils {
  def getCityCodeFromOrgCode(bn:String)={
    var t:String = try {
      val c = if(bn.length>3) bn.substring(0, 4) else null
      Integer.parseInt(c)
      c
    } catch {case e: Exception => { null }}
    if(t==null) t = try {
      val c = if(bn.length>2) bn.substring(0, 3) else null
      Integer.parseInt(c)
      c
    } catch {case e: Exception => { null }}
    if(t==null) t=""
    t
  }
}
