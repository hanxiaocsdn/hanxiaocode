package com.sf.gis.scala.base.custom_module

import java.util

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.net_module.{HttpCommonAccess, IHttpCommonGet, IHttpCommonPost}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger

import scala.collection.JavaConverters._

/**
 * Created by 01374443 on 2021/4/2.
 */
object SfNetIntefaceAoi {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)


  /**
   * 坐标获取aoi和zc
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def xyToAoiZc(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doPost(obj, keyMap.asJava, CommonUrl.xyToAoiZc, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonPost() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("x", "y")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("x")) && !StringUtils.isBlank(parmMap.get("y"))
      }

      /**
       * 拼接传入数据体
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalBody(parmMap: util.Map[String, String]): String = {
        val body = new JSONObject()
        body.put("ak", ak)
        val coords = new JSONArray()
        val coord = new JSONObject()
        coord.put("lng", parmMap.get("x"))
        coord.put("lat", parmMap.get("y"))
        coords.add(coord)
        body.put("coords", coords)
        body.toJSONString
      }
    })
    return obj
  }

  /**
   * aoiid获取aoi信息
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def aoiIdInfo(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("aoiId")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("aoiId"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.aoiIdInfo.format(parmMap.get("aoiId"), ak)
      }
    })
    return obj
  }
  /**
   * 根据坐标获取aoi信息
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def aoiInfoDataAoitype(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("x","y")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("x")) && !StringUtils.isBlank(parmMap.get("y"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.aoiInfoDataAoitype.format(parmMap.get("x"),parmMap.get("y"), ak)
      }
    })
    return obj
  }

  def bactchXyToAoiFix(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doPost(obj, keyMap.asJava, CommonUrl.batchXyToAoi2, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonPost() {
      /**
        * 获取网址需要的参数在数据体中的名称数组
        * @return
        */
      override def urlNeedKey(): Array[String] = {
        Array("xyList")
      }

      /**
        * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
        * 正确返回true,错误返回false
        *
        * @param parmMap 参数值映射
        * @return
        */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("xyList"))
      }

      /**
        * 拼接传入数据体
        *
        * @param parmMap 参数值映射
        * @return
        */
      override def createFinalBody(parmMap: util.Map[String, String]): String = {
        parmMap.get("xyList")
      }
    })
    return obj
  }

  def aoiInfoDataAoi2(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("x","y")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("x")) && !StringUtils.isBlank(parmMap.get("y"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.aoiInfoDataAoi2.format(parmMap.get("x"),parmMap.get("y"), ak)
      }
    })
    return obj
  }
  def aoiInfoDept2(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("x","y")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("x")) && !StringUtils.isBlank(parmMap.get("y"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.aoiInfoDept2.format(parmMap.get("x"),parmMap.get("y"), ak)
      }
    })
    return obj
  }

  def xyAroundAoiWithCenterDistance(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("x","y","radius")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("x")) && !StringUtils.isBlank(parmMap.get("y")) && !StringUtils.isBlank(parmMap.get("radius"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.xyAroundAoiCenterDisUrl.format(parmMap.get("x"),parmMap.get("y"), parmMap.get("radius"))
      }
    })
    return obj
  }
  /**
   * 坐标获取aoi和zc
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def trackToAoi(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doPost(obj, keyMap.asJava, CommonUrl.trackAoiUrl, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonPost() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("trackList")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("trackList"))
      }

      /**
       * 拼接传入数据体
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalBody(parmMap: util.Map[String, String]): String = {
        parmMap.get("trackList")
      }
    })
    return obj
  }
  def bactchXyToAoi(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doPost(obj, keyMap.asJava, CommonUrl.batchXyToAoi, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonPost() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("xyList")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("xyList"))
      }

      /**
       * 拼接传入数据体
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalBody(parmMap: util.Map[String, String]): String = {
        parmMap.get("xyList")
      }
    })
    return obj
  }

  def main(args: Array[String]): Unit = {
    println(Thread.currentThread.getStackTrace()(1).getMethodName)
    //    val dd = new JSONObject()
    //    dd.put("address","深圳市软件产业基地")
    //    dd.put("city","755")
    //    val keyMap=Map("address"->"address","citycode"->"city")
    //    val ff = rdsGeoSplitTestEnv("",dd,keyMap)
    //    println(ff.toJSONString)
  }
}
