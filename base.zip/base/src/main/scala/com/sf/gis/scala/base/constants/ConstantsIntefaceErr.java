package com.sf.gis.scala.base.constants;

/**
 * Created by 01374443 on 2021/4/7.
 */
public class ConstantsIntefaceErr {
    //ak分钟超限
    public  static int akLimitErrMinu=109;
    //gd超限警告
    public static int qpsLimitErr=140;
    public static String qpsLimitErrMsg="LIMIT";
}
