package com.sf.gis.scala.base.custom_module

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util
import java.util.{Calendar, Date}

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.constant.InfConstant
import com.sf.gis.java.base.util.{HttpConnection, HttpInvokeUtil, TimeOutUrlUtil}
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.http.HttpStatus
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import scala.collection.JavaConversions._
import scala.util.control.Breaks
/**
 * Created by 01374443 on 2021/4/2.
 */
object SfNetInteface {

  //审补地址下线
  val delUrl ="http://gis-cms-bg.sf-express.com/cms/api/address/deleteRgsbAddr"
  //审补入cms库
  val cmsUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd"

  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
   * 车牌请求轨迹接口获取路桥费
   * @param
   * @return
   */
  def customerDetailsInterface() = {
    val tokenUrl="https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=ww389059b0120e6648&corpsecret=ChyQ5bDDdFAyg77fPAgwqWHeTC139H5Px79ZCDDT3s0"
    var access_token = ""
    try {
      val retToken: JSONObject = HttpInvokeUtil.httpGetJSON(tokenUrl,3)
      access_token = retToken.getString("access_token")
      println(retToken)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调token接口异常:"+e.getMessage)
    }
    val url="https://developer.work.weixin.qq.com/document/path/92994?access_token=%s"
    val finalUrl: String = url.format(access_token)
    try {
      val json = new JSONObject()
      val userid_list = new util.ArrayList[String]()
      userid_list.append("LiuBo")
      userid_list.append("CaiYingWei")
      json.put("userid_list",userid_list)
      json.put("cursor","")
      json.put("limit",100)
      val retStr: String = HttpInvokeUtil.sendPost(finalUrl,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      println(ret)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调客户详情接口异常:"+e.getMessage)
    }

  }

  /**
   * 车牌请求轨迹接口获取路桥费
   * @param obj
   * @return
   */
  def trackRoadBridgeFeesInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
    try {

      val json = new JSONObject()
      val beginDateTime: String = JSONUtil.getJsonValSingle(obj, "task_start_time").replace("-","").replace(":","").replace(" ","")
      val endDateTime: String = JSONUtil.getJsonValSingle(obj, "task_end_time").replace("-","").replace(":","").replace(" ","")
      val carrier_plate: String = JSONUtil.getJsonValSingle(obj, "carrier_plate")
      if(StringUtils.isBlank(beginDateTime)){
        return obj
      }
      val vehicle_len: Double = JSONUtil.getJsonDouble(obj, "vehicle_len",0.0)
      val axles: Int = JSONUtil.getJsonValInt(obj, "axles",0)
      var load = 3.6
      var weight = 3.6
      if (vehicle_len>=6){
        load = 9.6
        weight = 9.6
      }
      val vehicleInfo = new JSONObject()
      vehicleInfo.put("load",load)
      vehicleInfo.put("axis",axles)
      vehicleInfo.put("weight",weight)
      vehicleInfo.put("length",5.4)
      json.put("ak",ak)
      json.put("type","0")
      json.put("un",carrier_plate)
      json.put("unType","0")
      json.put("hasRate",true)
      json.put("offTime","120")
      json.put("beginDateTime",beginDateTime)
      json.put("endDateTime",endDateTime)
      json.put("vehicleInfo",vehicleInfo)
      logger.error("json:"+json.toJSONString)
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString,3)
      val ret: JSONObject = JSON.parseObject(retStr)
      //val status: String = ret.getString("status")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(ret, "result.data")
      val etctollCharge: String = data.getString("etctollCharge")
      val tollCharge: String = data.getString("tollCharge")
      obj.put("etctollCharge",etctollCharge)
      obj.put("tollCharge",tollCharge)
      //obj.put("url",url)
      //obj.put("json",json)
      //obj.put("status",status)
      //obj.put("ret",ret)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调qmPoint接口异常:"+e.getMessage)
        obj.put("trackHoldPointException",e.getMessage)
    }
    obj
  }
  /**
   * 调历史轨迹接口寻找停留点
   * @param obj
   * @return
   */
  def trackHoldPointInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/queryDetail"
    try {
      val json = new JSONObject()
      val beginDateTime: String = JSONUtil.getJsonValSingle(obj, "beginDateTime").replace("-","").replace(":","").replace(" ","")
      val endDateTime: String = JSONUtil.getJsonValSingle(obj, "endDateTime").replace("-","").replace(":","").replace(" ","")
      if (StringUtils.isEmpty(beginDateTime) || StringUtils.isEmpty(endDateTime)){
        return obj
      }
      val vehicle: String = JSONUtil.getJsonValSingle(obj, "vehicle")
      json.put("un",vehicle)
      json.put("beginDateTime",beginDateTime)
      json.put("endDateTime",endDateTime)
      json.put("type","0")
      json.put("ak",ak)
      json.put("opt","all")
      json.put("stayDuration","120")
      json.put("stayRadius","50")
      json.put("addpoint","1")
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString,3)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调qmPoint接口异常:"+e.getMessage)
        obj.put("trackHoldPointException",e.getMessage)
    }
    obj
  }


  /**
   * 轨迹点获取线路里程和高速里程
   * @param obj

   * @return
   */
  def qmPointInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf"
    try {
      val json = new JSONObject()
      val points: String = JSONUtil.getJsonValSingle(obj, "trackStr")
      json.put("ak",ak)
      json.put("Vehicle",1)
      json.put("test",1)
      json.put("mode",2)
      json.put("opt","sf2")
      json.put("points",points)
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString,3)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调qmPoint接口异常:"+e.getMessage)
        obj.put("qmPointException",e.getMessage)
    }
    obj
  }
  /**
   * 车牌和时间范围获取轨迹点
   * @param obj

   * @return
   */
  def trackMergeInterface(ak:String,obj:JSONObject) = {
    val url="http://gis-vms-query-new.sf-express.com:80/trackquery-new/api/integrate"
    try {
      val json = new JSONObject()
      val plate: String = obj.getString("plate")
      val actual_depart_tm: String = obj.getString("actual_depart_tm").replace("-","").replace(" ","").replace(":","")
      val actual_arrive_tm: String = obj.getString("actual_arrive_tm").replace("-","").replace(" ","").replace(":","")

      json.put("ak",ak)
      json.put("type",0)
      json.put("un",plate)
      json.put("unType",0)
      json.put("rectify",true)
      json.put("beginDateTime",actual_depart_tm)
      json.put("endDateTime",actual_arrive_tm)
      json.put("offTime",120)
      json.put("hasRate",true)
      val retStr: String = TimeOutUrlUtil.sendPost(url,json.toJSONString,3, 120000)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调trackMerge接口异常:"+e.getMessage)
        obj.put("trackMergeException",e.getMessage)
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressMd5更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressMd5AoiCheckK8sInterface(ak:String,obj:JSONObject) = {
    val url="http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrMd5AoiCheck"
    try {
      val json = new JSONObject()
      val citycode: String = obj.getString("city_code")
      val groupid1: String = obj.getString("groupid1")
      val groupidArray = new JSONArray()
      groupidArray.add(groupid1)
      json.put("cityCode",citycode)
      json.put("addressMd5s",groupidArray)
      json.put("aoiCheckTag",5)
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      val success: String = ret.getString("success")
      if (success=="true"){
        logger.error(">>>>>>addressMd5接口更新")
      }
      obj.put("success",success)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressMd5接口异常:"+e.getMessage)
        obj.put("addressMd5Exception",e.getMessage)
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressId更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressIdAoiCheckK8sInterface(ak:String,obj:JSONObject) = {
    val url="http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck"
    try {
      val citycode: String = obj.getString("city_code")
      val groupid1: String = obj.getString("groupid1")
      val groupidArray = new JSONArray()
      groupidArray.add(groupid1)
      val json = new JSONObject()
      json.put("cityCode",citycode)
      json.put("addressIds",groupidArray)
      json.put("aoiCheckTag",5)
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      val success: String = ret.getString("success")
      val message: String = ret.getString("message")
      if (success=="true"){
        logger.error(">>>>>>addressId接口更新")
      }
      obj.put("success",success)
      obj.put("message",message)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
        obj.put("addressIdException",e.getMessage)
    }
    obj
  }
  /**
   * 添加审补标准地址aoi接口,post接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def rgsbAddInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/rgsbAdd"
    try {
      val cityCode: String = obj.getString("city_code")
      val znoCode: String = obj.getString("org_code")
      val address: String = obj.getString("address")
      val aoiId: String = obj.getString("finalaoiid")
      val operUserName: String = obj.getString("emp_code")
      val addressSave = new JSONObject()
      addressSave.put("cityCode",cityCode)
      addressSave.put("address",address)
      addressSave.put("znoCode",znoCode)
      addressSave.put("type","2")
      addressSave.put("src","1")
      addressSave.put("aoiId",aoiId)
      addressSave.put("aoiSource","S99")
      addressSave.put("lockCheck","0")
      val json = new JSONObject()
      json.put("ak",ak)
      json.put("operSource","ARSS")
      json.put("operUserName",operUserName)
      json.put("addressSave",addressSave)
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      val success: String = ret.getString("success")
      logger.error("json:"+json.toJSONString)
      logger.error("ret:"+ret.toJSONString)
      if (success=="true"){
        obj.put("updateaoiid_result","True")
        logger.error(">>>>>>成功添加审补标准地址")
      }else{
        val message: String = ret.getString("message")
        obj.put("updateaoiid_result",message)
      }
      obj.put("success",success)
      obj.put("ret",ret)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调审补接口异常:"+e.getMessage)
        obj.put("updateaoiid_result",e.getMessage)
    }
    obj
  }

  /**
   * 地址不详接口
   * @param obj  传入的json对象
   * @return
   */
  def addrUnknownInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/ar/api?address=%s&datatype=r01&extention=0&opt=&ak=%s"
    try {
      val address: String = JSONUtil.getJsonValSingle(obj, "req_addresseeaddr")
      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl: String = url.format(URLEncoder.encode(address,"utf-8"),ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      logger.error("finalUrl:"+finalUrl)
      //obj.put("finalUrl",finalUrl)
      obj.put("ret",ret)
      if (ret != null) {
        obj.put("addr_unknown_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("addr_unknown_result",tmp)
    }
    obj
  }
  /**
   * 输入地址获取地址关键词
   * @param obj  传入的json对象

   * @return
   */
  def addrKeywordInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/iad/api/keyword?address=%s&ak=%s&addrType=0"
    try {
      val address: String = JSONUtil.getJsonValSingle(obj, "consignee_addr")
      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl: String = url.format(URLEncoder.encode(address,"utf-8"),ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("addr_keyword_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("addr_keyword_result",tmp)
    }
    obj
  }

  /**
   * 跑标准微服务接口获取adcode
   * @param obj  传入的json对象

   * @return
   */
  def adcodeInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal?address=%s&city=%s&ak=%s&opt=normdetail"
    try {
      val address: String = JSONUtil.getJsonValSingle(obj, "req_address")
      val citycode: String = JSONUtil.getJsonValSingle(obj, "citycode")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(citycode)){
        return obj
      }
      val finalUrl: String = url.format(URLEncoder.encode(address,"utf-8"),citycode,ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("ret_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret_result",tmp)
    }
    obj
  }


  /**
   * 跑运单接口
   * @param obj  传入的json对象

   * @return
   */
  def waybillnoInterface(obj:JSONObject): JSONObject = {
    val url="http://10.240.22.110:8101/delivery/"
    try {
      val waybillno = obj.getString("waybillno")
      if(StringUtils.isBlank(waybillno)){
        return obj
      }
      val finalUrl = url + waybillno
      obj.put("finalUrl",finalUrl)
      val ret: JSONArray = HttpInvokeUtil.httpGetArray(finalUrl,3)
      obj.put("ret",ret)

      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("waybillno_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("waybillno_result",tmp)
    }
    obj
  }
  /**
   * 跑AT接口
   * @param obj  传入的json对象

   * @return
   */
  def aoiRadiusInterface(obj:JSONObject): JSONObject = {
    val url="http://sds-core-datarun.sf-express.com/datarun/aoi/getGeomAoiBase?aoiId=%s&radius=%s"
    try {
      val aoi_id = obj.getString("aoi_id")
      val radius = obj.getString("radius")
      //logger.error("aoi_id:"+aoi_id)
      if(StringUtils.isBlank(aoi_id) || StringUtils.isBlank(radius)){
        return obj
      }
      val finalUrl: String = url.format(aoi_id,radius)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑天气查询接口,post接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def coordinateWeatherInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/getRainArea?"
    val json = new JSONObject()
    val data = new JSONArray()
    //val now = new Date()
    //val timestamp: String = (now.getTime / 1000).toString
    val timestamp: Long = obj.getLongValue("timestamp")/1000
    val x: Double = obj.getString("longitude").toDouble

    val y: Double = obj.getString("latitude").toDouble

    val coordinates = new JSONObject()
    coordinates.put("x",x)
    coordinates.put("y",y)
    data.add(coordinates)

    json.put("data",data)
    json.put("timestamp",timestamp)
    json.put("ak",ak)
    json.put("typhoon", 1)
    obj.put("req", json.toJSONString)
    logger.error("===>>>>>:"+json.toJSONString)
    val retStr: String = TimeOutUrlUtil.sendPost(url,json.toJSONString,1,10000)
    val ret: JSONObject = JSON.parseObject(retStr)
    val CODE: String = JSONUtil.getJsonValSingle(ret, "CODE")
    //val CODE: String = ret.getString("CODE")
    logger.error("===>>>:"+CODE)
    //obj.put("weatherRet",ret)
    if (CODE=="1"){
      obj.put("weatherRet",ret)
      println("weatherRet:"+ret)
    }
    obj
  }
  /**
   * 跑天气查询接口,post接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def weatherInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/getRainArea?"
    try {
      val json = new JSONObject()
      val data = new JSONArray()
      val time: String = obj.getString("time")
      val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val date: Date = sdf.parse(time)
      val timestamp: String = ((date.getTime)/1000).toString

      val x: Double = obj.getString("centerx").toDouble

      val y: Double = obj.getString("centery").toDouble

      val coordinates = new JSONObject()
      coordinates.put("x",x)
      coordinates.put("y",y)
      data.add(coordinates)

      json.put("data",data)
      json.put("timestamp",timestamp)
      json.put("ak",ak)
      logger.error("===>>>>>:"+json.toJSONString)
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      val CODE: String = ret.getString("CODE")
      //logger.error("===>>>:"+CODE)
      if (CODE=="1"){
        obj.put("weatherRet",ret)
      }
      //Thread.sleep(2*1000)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("weatherRet",tmp)
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressMd5更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressMd5AoiCheckInterface4(obj:JSONObject) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrMd5AoiCheck"

    try {
      val citycode: String = obj.getString("city_code")
      val groupid: String = obj.getString("groupid")
      val groupidArray = new JSONArray()
      groupidArray.add(groupid)
      val json = new JSONObject()
      json.put("cityCode",citycode)
      json.put("addressMd5s",groupidArray)
      json.put("aoiCheckTag",4)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")
        if (success=="true"){
          logger.error(">>>>>>addressMd5接口更新")
        }
        obj.put("success",success)
      }

    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
        obj.put("exception","调addressMd5接口异常")
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressMd5更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressMd5AoiCheckInterface(obj:(String, Iterable[String])) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrMd5AoiCheck"
    try {
      val json = new JSONObject()
      val citycode: String = obj._1
      val groupid: scala.List[String] = obj._2.toList
      json.put("cityCode",citycode)
      json.put("addressMd5s",groupid)
      json.put("aoiCheckTag",5)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")
        if (success=="true"){
          logger.error(">>>>>>addressMd5接口更新")
        }
      }

    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
    }
  }
  /**
   * 地址AOI判错更新(通过addressId更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressIdAoiCheckInterface4(obj:JSONObject) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck"
    try {
      val citycode: String = obj.getString("city_code")
      val groupid: String = obj.getString("groupid")
      val groupidArray = new JSONArray()
      groupidArray.add(groupid)
      val json = new JSONObject()
      json.put("cityCode",citycode)
      json.put("addressIds",groupidArray)
      json.put("aoiCheckTag",4)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")

        if (success=="true"){
          logger.error(">>>>>>addressId接口更新")
        }

        obj.put("success",success)
      }
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
        obj.put("exception","调addressId接口异常")
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressId更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressIdAoiCheckInterface(obj:(String, Iterable[String])) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck"
    try {
      val json = new JSONObject()
      val citycode: String = obj._1
      val groupid: scala.List[String] = obj._2.toList
      json.put("cityCode",citycode)
      json.put("addressIds",groupid)
      json.put("aoiCheckTag",5)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")

        if (success=="true"){
          logger.error(">>>>>>addressId接口更新")
        }
        Thread.sleep(10*1000)
      }

    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
    }
  }
  /**
   * 跑GIS-ASS-RDS-CHK查询接口,post接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def areaInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/chkquery/tc/teamCode"
    try {
      val json = new JSONObject()
      val address: String = JSONUtil.getJsonValSingle(obj, "address")
      println("address"+address)
      val cityCode: String = JSONUtil.getJsonValSingle(obj, "cityCode")
      json.put("address",address)
      json.put("cityCode",cityCode)
      json.put("sysCode","BDP")
      json.put("addressType","2")
      json.put("type","1")
      json.put("ak",ak)
      if(StringUtils.isBlank(address)||StringUtils.isBlank(cityCode)){
        return obj
      }
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      val retCode: String = ret.getString("retCode")
      if (retCode=="1"){
        obj.put("areaRet",ret)
      }

    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("areaRet",tmp)
    }
    obj
  }
  /**
   * 跑AT接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def atOtherInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?ak=%s&address=%s&city=%s&opt=zh&callDispatch=1&isNotUnderCall=1&needAoiArea=1&company=%s"
    try {
      val address = obj.getString("req_address")
      val city = obj.getString("citycode")
      val company = obj.getString("req_comp_name")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city,URLEncoder.encode(company,"utf-8"))
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atOtherInterface(ak,obj)
        }
        obj.put("atRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atRet",tmp)
    }
    obj
  }
  /**
   * 跑ATP接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def atpInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=%s&address=%s&city=%s&opt=zh&company=%s"
    try {
      val address = obj.getString("req_address")
      val city = obj.getString("citycode")
      val company = obj.getString("req_comp_name")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city,URLEncoder.encode(company,"utf-8"))
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atpInterface(ak,obj)
        }
        obj.put("atpRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atpRet",tmp)
    }
    obj
  }

  /**
   * 跑SLA数据指标
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def slaInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://kong.int.sfcloud.local/prilog/v1/AccessMonitor/dataGridBySysCodeAndModuleNameAndUrl?sysCode=%s&moduleName=%s&urlRegrex=%s&startTimestamp=%s&endTimestamp=%s&env=%s"
    val apikey = ak
    val user_account = "01421359"
    val env = "ALL"
    val moduleName = ""
    try {
      val sysCode = obj.getString("sys_code")
      val urlRegrex = obj.getString("api")
      val startTimestamp = obj.getString("startTimestamp")
      val endTimestamp = obj.getString("endTimestamp")
      val finalUrl: String = url.format(sysCode, moduleName, urlRegrex, startTimestamp, endTimestamp, env)
      var count = 3
      var ret = new JSONObject()
      val categoryLoop = new Breaks
      categoryLoop.breakable {
        for (i<-1 until(count)){
          val httpGet = new HttpGet(finalUrl)
          httpGet.addHeader("apikey", apikey)
          httpGet.addHeader("user-account", user_account)
          try {
            val httpClient = HttpClients.custom.build
            val response = httpClient.execute(httpGet)
            try if (response.getStatusLine.getStatusCode == HttpStatus.SC_OK) {
              val result = EntityUtils.toString(response.getEntity, "utf-8")
              ret = JSON.parseObject(result)
              obj.put("atpRet",ret)
              obj.put("finalUrl",finalUrl)
              if (ret.getString("success")=="true"){
                 categoryLoop.break()
              }
            }
            catch {
              case e: Exception =>
            } finally {
              httpGet.releaseConnection()
              if (httpClient != null) httpClient.close()
              if (response != null) response.close()
            }
          }
        }
      }



    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atpRet",tmp)
    }

    obj
  }

  /**
   * 判断precision跑aoi接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def aoiXYInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=%s"
    try {
      val precision_gd: Integer = obj.getInteger("precision_gd")
      if (precision_gd==2){
        val x = obj.getString("gd_x")
        val y = obj.getString("gd_y")
        if(StringUtils.isNoneBlank(x)||StringUtils.isNoneBlank(y)){
          val finalUrl = url.format(x,y,ak)
          val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
          if (ret != null) {
            if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep((60-second)*1000)
              return aoiXYInterface(ak,obj)
            }
            obj.put("gdAoiRet",ret)
          }
        }
      }
      val precision_rh: Integer = obj.getInteger("precision_rh")
      if (precision_rh==2){
        val x = obj.getString("rh_x")
        val y = obj.getString("rh_y")
        if(StringUtils.isNoneBlank(x)||StringUtils.isNoneBlank(y)){
          val finalUrl = url.format(x,y,ak)
          val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
          if (ret != null) {
            if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep((60-second)*1000)
              return aoiXYInterface(ak,obj)
            }
            obj.put("rhAoiRet",ret)
          }
        }
      }
      val precision_tc: Integer = obj.getInteger("precision_tc")
      if (precision_tc==2){
        val x = obj.getString("tc_x")
        val y = obj.getString("tc_y")
        if(StringUtils.isNoneBlank(x)||StringUtils.isNoneBlank(y)){
          val finalUrl = url.format(x,y,ak)
          val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
          if (ret != null) {
            if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep((60-second)*1000)
              return aoiXYInterface(ak,obj)
            }
            obj.put("tcAoiRet",ret)
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("aoiRet",tmp)
    }
    obj
  }
  /**
   * 跑aoi接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def aoiInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=%s"
    try {
      val x = obj.getString("x")
      val y = obj.getString("y")
      if(StringUtils.isBlank(x)||StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl = url.format(x,y,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return aoiInterface(ak,obj)
        }
        obj.put("aoiRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("aoiRet",tmp)
    }
    obj
  }
  /**
   * 跑at接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def atInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=zh"
    try {
      val address = obj.getString("address")
      val cityCode = obj.getString("citycode")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(cityCode)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),cityCode,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atInterface(ak,obj)
        }
        obj.put("atRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atRet",tmp)
    }
    obj
  }
  /**
   * 跑楼栋数据
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def buildingId(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/building/address/identify?address=%s&cityCode=%s&ak=%s"
    try {
      val address = obj.getString("address")
      val cityCode = obj.getString("cityCode")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(cityCode)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),cityCode,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return buildingId(ak,obj)
        }
        obj.put("buildingIdRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("buildingIdRet",tmp)
    }
    obj
  }
  /**
   * 地址可达
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def addrReach(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&ak=%s&extention=0&datatype=r01&opt="
    try {
      val province = JSONUtil.getJsonValSingle(obj,"province")
      val city = JSONUtil.getJsonValSingle(obj,"city")
      val district = JSONUtil.getJsonValSingle(obj,"district")
      val address = JSONUtil.getJsonValSingle(obj,"address")
      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(province,"utf-8"),URLEncoder.encode(city,"utf-8"),URLEncoder.encode(district,"utf-8"),URLEncoder.encode(address,"utf-8"),ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return addrReach(ak,obj)
        }
        obj.put("addrReachRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("addrReachRet",tmp)
    }
    obj
  }
  /**
   * 跑容灾接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def rdsRzNorm(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=normdetail"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city: String = JSONUtil.getJsonValSingle(obj,"citycode")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),city,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return addrReach(ak,obj)
        }
        obj.put("rdsRzNormRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("rdsRzRet",tmp)
    }
    obj
  }

  /**
   * 跑ab合库效果测试接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def rdsAbMergeXiaoguoCeshi(ak:String,obj:JSONObject): JSONObject = {
    val url="http://10.240.162.41:8082/atdispatch/api?address=%s&city=%s&ak=&opt=normdetail&geoType=9991-1024016241"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"citycode")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),city,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return rdsAbMergeXiaoguoCeshi(ak,obj)
        }
        obj.put("rdsAbMergeXgcsRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("rdsAbMergeXgcsRet",tmp)
    }
    obj
  }
  /**
   * 跑tc接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def geotcgis(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=tc2&address=%s&city=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"city_code")

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geogdgis(ak,obj)
        }
        obj.put("geotcgis",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("geotcgis",tmp)
    }
    obj
  }
  /**
   * 跑rh接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def georhgis(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=rh1&address=%s&city=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"city_code")

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geogdgis(ak,obj)
        }
        obj.put("georhgis",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("georhgis",tmp)
    }
    obj
  }
  /**
   * 跑gd2接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def geogd2gis(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=gd2&address=%s&city=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"city_code")

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geogdgis(ak,obj)
        }
        obj.put("geogdgis",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("geogdgis",tmp)
    }
    obj
  }
  /**
   * 跑高德接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def geogdgis(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=gd2&address=%s&city=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"citycode")

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geogdgis(ak,obj)
        }
        obj.put("geogdgis",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("geogdgis",tmp)
    }
    obj
  }

  /**
   * 跑MAPA接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def geoMa1(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=ma1&address=%s&city=%s"
    try {

      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"citycode")
      val finalUrl: String = url.format(ak,URLEncoder.encode(address,"utf-8"),city)

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }

      val ret:JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)

      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geoMa1(ak,obj)
        }
        obj.put("geoMa1",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("geoMa1",tmp)
    }
    obj
  }
  /**
   * 跑点落面服务接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def checksDepot(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=%s&lat=%s&ak=%s"
    try {
      val x = JSONUtil.getJsonValSingle(obj,"x")
      val y = JSONUtil.getJsonValSingle(obj,"y")
      if(StringUtils.isBlank(x) || StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl = url.format(x,y,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return checksDepot(ak,obj)
        }
        obj.put("checksDepot",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("checksDepot",tmp)
    }
    obj
  }
  /**
   * 快运audit数据更新接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def kyAudit(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/ky/audit/inc?ak=%s&address=%s&tc=%s&citycode=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val citycode = JSONUtil.getJsonValSingle(obj,"citycode")
      val tc = JSONUtil.getJsonValSingle(obj,"tc")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(citycode) || StringUtils.isBlank(tc)){
        return obj
      }
      val finalUrl = url.format(ak,address,tc,citycode)
      println(finalUrl)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return kyAudit(ak,obj)
        }
        obj.put("kyAudit",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("kyAudit",tmp)
    }
    obj
  }


  /**01412406
   * 审补地址下线/压入cms审补库
   * @param ak   ak值
   * @param obj  传入的json对象
   * @param operUserName  下线人名称
   * @param operSource  下线人工号
   * @param retry  重试次数
   * @param ty  del:地址下线/cms:压入审补库
   * @return
   */

  def rgsbAddr(operUserName:String,operSource:String,ak:String,obj:JSONObject,retry:Int,ty:String) ={

    var addrUrl=""
    var count = 1
    var httpData: util.Map[String, AnyRef] = null
    var ret: JSONObject = new JSONObject()
    val city_code = JSONUtil.getJsonVal(obj,"city_code","")
    val gis_to_sys_groupid = JSONUtil.getJsonVal(obj,"gis_to_sys_groupid","")
    val zc = JSONUtil.getJsonVal(obj,"zc","")
    val checkAoiId = JSONUtil.getJsonVal(obj,"checkAoiId","")
    val address = JSONUtil.getJsonVal(obj,"address","")

    val parm = new JSONObject()
    parm.put("ak", ak)
    parm.put("operSource", operSource)
    parm.put("operUserName", operUserName)
    val addressObject = new JSONObject()

    ty match {
      case "del" => {
        //地址下线
        addrUrl= delUrl
        addressObject.put("cityCode", city_code)
        addressObject.put("addressMd5", gis_to_sys_groupid)
        addressObject.put("type", 2)
        parm.put("addressDel", addressObject)

      }
      case "cms" => {
        //压入cms审补库
        addrUrl= cmsUrl
        addressObject.put("cityCode", city_code)
        addressObject.put("address", address)
        addressObject.put("znoCode",zc)
        addressObject.put("aoiId",checkAoiId)
        parm.put("addressSave",addressObject)
      }

    }


    if(StringUtils.isNotEmpty(addrUrl)){
      httpData = HttpConnection.sendPost(addrUrl, parm.toJSONString)


      while (!httpData.getOrDefault("code","").equals("1") && count < retry){
        count=count+1
        val second = Calendar.getInstance().get(Calendar.SECOND)
        Thread.sleep(60 - second)
        httpData = HttpConnection.sendPost(addrUrl, parm.toJSONString)
      }



      if (httpData.get("content") != null ) {
        val content = httpData.get("content").toString
        ret = JSON.parseObject(content)
        ret
      }
      else{
        val code = httpData.get("code")
        ret.put("code",code)
        ret
      }

    }
    ret
  }


  //  /**
  //    * 工单地址匹配标准库数据
  //    * http://10.220.21.90:1080/atdispatch/api?ak=c274bbf7007c411c8e21a6abe31a9886&address=%s&city=%s&opt=normdetail
  //    * @param ak   ak值
  //    * @param obj  传入的json对象
  //    * @param retry  重试次数
  //    * @return
  //    */
  //  def getNormInfo(ak:String,obj:JSONObject,retry:Int) ={
  //    val url ="http://10.220.21.90:1080/atdispatch/api?ak=%s&address=%s&city=%s&opt=normdetail"
  //    val city = JSONUtil.getJsonVal(obj,"city","")
  //    val address = JSONUtil.getJsonVal(obj,"address","")
  //    var ret: JSONObject = null
  //    try{
  //      if(!city.isEmpty && !address.isEmpty){
  //        val inputurl = String.format(url,ak,URLEncoder.encode(address, "utf-8"),city)
  //         ret = HttpClientUtil.getJsonByGet(inputurl,retry)
  //      }
  //      ret
  //    }catch {
  //      case e:Exception=>logger.error(e)
  //       ret.put("myException",e.toString)
  //       ret
  //    }
  //
  //  }

  /**
   * 通过经纬度获取快运单元区域 01412406

   * http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY
   * @param ak   ak值
   * @param obj  传入的json对象
   * @param retry  重试次数
   * @return
   */
  def getAoiEare(ak:String,obj:JSONObject,retry:Int) ={
    val url ="http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=%s&lat=%s&ak=%s"
    val lng = JSONUtil.getJsonVal(obj,"lng","")
    val lat = JSONUtil.getJsonVal(obj,"lat","")
    var ret: JSONObject = null
    try{
      if(!lng.isEmpty && !lat.isEmpty){
        ret = HttpClientUtil.getJsonByGet(String.format(url,lng,lat,ak),retry)
      }
      ret
    }catch {
      case e:Exception=>logger.error(e)
        ret.put("myException",e.toString)
        ret
    }

  }


  /** 01412406
   * 判断跟AOI名称相似度  http://10.119.72.209:8080/rds_web/noControl/similar
   * @param obj  传入的json对象
   * @param retry  重试次数
   * @return
   */

  def getsimilar(obj:JSONObject,retry:Int) ={
    val url ="http://10.119.72.209:8080/rds_web/noControl/similar/%s/%s"

    var keyword = obj.getString("keyword")
    var checkAoiName = obj.getString("checkAoiName")
    keyword = if(keyword != null) keyword.trim else keyword
    checkAoiName = if(checkAoiName != null) checkAoiName.trim else checkAoiName

    var ret: JSONObject = null
    try{

      ret = HttpClientUtil.getJsonByGet(String.format(url,keyword,checkAoiName),retry)
      ret
    }catch {
      case e:Exception=>logger.error(e)
        ret.put("myException",e.toString)
        ret
    }
  }



  /**01412406
   * 获取DBZC  http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-int.int.sfdc.com.cn:1080/eds/api/cache/query
   * @param obj  传入的json对象
   * @param ak  传入的ak
   * @param retry  重试次数
   * @return
   */

  def getDbzc(ak:String,obj:JSONObject,retry:Int) = {
    val url = "http://gis-int.int.sfdc.com.cn:1080/eds/api/cache/query?ak=%s&type=3&aoi=%s"
    var zcList = List[String]()
    var checkAoiId = JSONUtil.getJsonVal(obj, "checkAoiId", "")
    try {
      val ret = HttpClientUtil.getJsonByGet(String.format(url, ak, checkAoiId), retry)
      val zcJsonArray = try {
        //获取德邦zc
        ret.getJSONObject("result").getJSONArray("deppon")
      } catch {
        case _ => null
      }


      if (zcJsonArray != null) {
        if (zcJsonArray.size() == 1)
          zcList = zcJsonArray.getJSONObject(0).getString("dept") :: zcList
        //如果返回ZC个数为2，且2个ZC相等，取其中一个zc返回；若2个ZC不相等，则2个都返回
        else {
          val zc1 = zcJsonArray.getJSONObject(0).getString("dept")
          val zc2 = zcJsonArray.getJSONObject(1).getString("dept")

          if (zc1.equals(zc2))
            zcList = zc1 :: zcList
          else {
            zcList = zc1 :: zcList
            zcList = zc2 :: zcList
          }
        }

      }

    } catch {
      case e: Exception => logger.error(e)
    }

    zcList
  }

  def main(args: Array[String]): Unit = {
    val dd = new JSONObject()
    dd.put("address","广东省深圳市宝安区海雅缤纷城君誉-C单元建安一路99号顺丰标快1")
    dd.put("citycode","755")
    dd.put("tc","755FG123")
    val ff = kyAudit("f14167603f8c48acbb31655a2f987578",dd)
    println(ff.toJSONString)
  }
}
