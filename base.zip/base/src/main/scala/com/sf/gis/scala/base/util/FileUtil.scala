package com.sf.gis.scala.base.util

import java.io.{BufferedReader, IOException, InputStream, InputStreamReader}
import java.util.Properties

object FileUtil {
  /**
   * 从资源路径下获取属性
   * @param configPath
   * @return
   */
  def getFilePropertieRes(configPath: String): Properties = {
    val props = new Properties
    var in: InputStream = null
    var isr: InputStreamReader = null
    var bf: BufferedReader = null
    try {
      in = this.getClass.getClassLoader.getResourceAsStream(configPath)
      //            in = AppConfig.class.getClassLoader().getResourceAsStream(configPath);
      isr = new InputStreamReader(in, "UTF-8") //解决读取中文出现乱码
      bf = new BufferedReader(isr)
      props.load(bf)
    } catch {
      case e: Exception =>
        e.printStackTrace()
    } finally {
      try
        if (bf != null) bf.close()
      catch {
        case e: IOException =>
          e.printStackTrace()
      }
      try
        if (isr != null) isr.close()
      catch {
        case e: IOException =>
          e.printStackTrace()
      }
      try
        if (in != null) in.close()
      catch {
        case e: IOException =>
          e.printStackTrace()
      }
    }
    props
  }
}
