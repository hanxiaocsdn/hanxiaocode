package com.sf.gis.scala.base.pojo

class Cnt(var cnt:Int)
