package com.sf.gis.scala.base.constants;

public enum HttpExceptionType {
    retry,//需要重试，次数为设定重试次数
    akLimit,//ak限制，直接重跑，不累计重试次数
    tsLimit//图商qps限制，直接重跑，不累计重试次数
}
