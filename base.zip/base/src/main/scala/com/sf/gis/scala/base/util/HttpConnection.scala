package com.sf.gis.scala.base.util

import java.io.{BufferedReader, InputStream, InputStreamReader}

import org.apache.http.client.config.RequestConfig
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
import org.apache.http.impl.client.{CloseableHttpClient, HttpClients}
import org.apache.log4j.Logger

/**
  * Created by 01368078 on 2018/2/7.
  */
object HttpConnection {
  @transient lazy val logger = Logger.getLogger(this.getClass)

  def doGet(url : String, charset : String) : String = {
    var re : String = null
    var contentSb = new StringBuilder
    var br : BufferedReader = null
    var isr : InputStreamReader = null
    var is : InputStream = null
    var client : CloseableHttpClient = null
    var httpGet : HttpGet = null

    var response : CloseableHttpResponse = null
    try{
      client = HttpClients.createDefault()
      httpGet  = new HttpGet(url)
      val requestConfig = RequestConfig.custom().setConnectTimeout(5000).setConnectionRequestTimeout(5000).setSocketTimeout(5000).build()
      httpGet.setConfig(requestConfig)
      response = client.execute(httpGet)
      var entity = response.getEntity
      is = entity.getContent
      isr = new InputStreamReader(is, charset)
      br = new BufferedReader(isr)
      var line  = br.readLine()
      while (line != null){
        contentSb.append(line + "\r\n")
        line = br.readLine()
      }
      re = contentSb.toString
    }catch {
      case e : Exception => {
        logger.error("GET请求出现异常！=>"+url, e)
      }
    }finally {
      try{
        if(br != null){
          br.close()
        }
      }catch {
        case e : Exception =>{
          logger.error(e)
        }
      }
      try{
        if(isr != null){
          isr.close()
        }
      }catch {
        case e : Exception =>{
          logger.error(e)
        }
      }
      try{
        if(is != null){
          is.close()
        }
      }catch {
        case e : Exception =>{
          logger.error(e)
        }
      }

      try{
        if(response != null)
          response.close()
      }catch {
        case  e : Exception=> {
          logger.error(e)
        }
      }
      try{
        if(httpGet != null)
          httpGet.releaseConnection()
      }catch {
        case  e : Exception=> {
          logger.error(e)
        }
      }
      try{
        if(client != null)
          client.close()
      }catch {
        case  e : Exception=> {
          logger.error(e)
        }
      }

      if(true){}
    }
    re
  }
}
