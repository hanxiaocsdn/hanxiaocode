package com.sf.gis.scala.base

import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import org.apache.log4j.Logger
object AkUtil {
  /**
   * 限制spark分区中ak使用数量
   * @param stratTime
   * @param cnt
   * @param index
   * @param limitMin
   * @param logger
   */
  def limitAkUse( stratTime:StratTime,cnt:Cnt,index:Int,limitMin:Int,logger:Logger ) ={
    cnt.cnt += 1

    if ( cnt.cnt == limitMin  ) {
      val endTime = System.currentTimeMillis() - stratTime.stratTime

      if( endTime <= 60 * 1000 ){
        logger.error( s"分区$index,每分钟访问量超过限制$limitMin,休眠${60*1000 - endTime } ms中" )
        Thread.sleep(60*1000 - endTime )
      }

      stratTime.stratTime = System.currentTimeMillis()
      cnt.cnt = 0
    }
  }
}
