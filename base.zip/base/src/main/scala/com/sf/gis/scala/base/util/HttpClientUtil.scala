package com.sf.gis.scala.base.util

import java.io.InputStream

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet, HttpPost}
import org.apache.http.entity.{ContentType, StringEntity}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.log4j.Logger

/**
  * Created by 01375125 on 2018/11/6.
  * HttpClient工具类
  */
object HttpClientUtil {
  val logger:Logger = Logger.getLogger(this.getClass.getName.replaceAll("$",""))

  /**
    * 访问http请求，返回字符串结果
    * @param url
    * @return
    */
  def getStrByGet(url:String,charset:String="UTF-8"): String ={
    val httpClient = HttpClients.createDefault()
    try {
      val httpGet = new HttpGet(url)
      var httpResponse:CloseableHttpResponse = null
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity:HttpEntity = httpResponse.getEntity

        try{
          val stringEntity = EntityUtils.toString(httpEntity, charset)
          return stringEntity
        }
        catch {
          case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
        }
      }
      httpResponse.close()
    } catch {
      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
    }
    httpClient.close()
    null
  }

  /**
    * 访问http请求，返回字符串结果
    * @param url
    * @return
    */
  def getStreamByGet(url:String): InputStream ={
    val httpClient = HttpClients.createDefault()
    var is: InputStream= null
    val httpGet = new HttpGet(url)
    var httpResponse:CloseableHttpResponse = null

    try {
      httpResponse = httpClient.execute(httpGet)
    } catch {
      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
    }
    if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
      val httpEntity:HttpEntity = httpResponse.getEntity
      if(httpEntity!=null){

        try {
          is = httpEntity.getContent
        } catch {
          case e:Exception =>logger.error(">>>获取数据流失败："+e)
        }
      }

    }
    is
  }

  /**
    * 访问http请求，返回JSON结果
    * @param url
    * @return
    */
  def getJsonByGet(url:String): JSONObject ={
    val httpClient = HttpClients.createDefault()
    var jsonObj:JSONObject = null
    try {
      var httpResponse:CloseableHttpResponse = null
      val httpGet = new HttpGet(url)
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity:HttpEntity = httpResponse.getEntity

        try{
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          try {
            jsonObj = JSON.parseObject(stringEntity)
          } catch {
            case e:Exception =>logger.error(">>>结果转换json独享异常："+e)
          }
        }
        catch {
          case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
        }
      }
      httpResponse.close()
    } catch {
      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
    }
    httpClient.close()
    jsonObj
  }
  /**
    * 访问http请求，返回JSON结果
    * @param url
    * @param tryCnt 调用次数 包括自己
    * @return
    */
  def getJsonByGet(url:String,tryCnt:Int): JSONObject = {
    val httpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = null
    var count = 0
    while (count < tryCnt) {
      count = count + 1
      try {
        var httpResponse: CloseableHttpResponse = null
        val httpGet = new HttpGet(url)
        httpResponse = httpClient.execute(httpGet)
        if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
          val httpEntity: HttpEntity = httpResponse.getEntity
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          jsonObj = JSON.parseObject(stringEntity)
          count = tryCnt
        }
        httpResponse.close()
      }
      catch {
        case e: Exception => logger.error(">>>获取httpResponse异常：" + e)
          Thread.sleep(1000)
      }

  }
    httpClient.close()
    jsonObj
  }
  /**
   * 访问http请求，返回JSON结果
   * @param url
   * @return
   */
  def getJsonByGetWithError(url:String,tryCnt:Int): JSONObject = {
    val httpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = new JSONObject()
    var count = 0
    while (count < tryCnt) {
      count = count + 1
      try {
        var httpResponse: CloseableHttpResponse = null
        val httpGet = new HttpGet(url)
        httpResponse = httpClient.execute(httpGet)
        if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
          val httpEntity: HttpEntity = httpResponse.getEntity
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          jsonObj = JSON.parseObject(stringEntity)
          count = tryCnt
        }
        httpResponse.close()
      }
      catch {
        case e: Exception =>{
          logger.error(">>>获取httpResponse异常：" + e)
          Thread.sleep(count*1000)
          jsonObj.put("httpErr",s"${count}次,"+e)
        }
      }
    }
    httpClient.close()
    jsonObj
  }
  /**
   * 进行post请求，失败后重试一次
   * @param url
   * @param reqJson
   * @param logger
   * @return
   */
  def doPost(url:String,reqJson:JSONObject,logger:Logger) = {
    var resbonseBody = "{}"

    try {
      resbonseBody = HttpUtils.post(url, reqJson, "utf-8")
    } catch {
      case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
        try {
          resbonseBody = HttpUtils.post(url, reqJson, "utf-8")
        } catch {
          case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
            resbonseBody = "发送post请求失败:" + e.toString
        }
    }
    resbonseBody
  }

  /**
   * 访问http请求，返回字符串结果
   * @param url
   * @return
   */
  def getStrByGetFromTargetCharset(url:String,charset:String="UTF-8"): String ={
    val httpClient = HttpClients.createDefault()
    try {
      val httpGet = new HttpGet(url)
      var httpResponse:CloseableHttpResponse = null
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity:HttpEntity = httpResponse.getEntity

        try{
          val stringEntity = EntityUtils.toString(httpEntity, charset)
          return stringEntity
        }
        catch {
          case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
        }
      }
      httpResponse.close()
    } catch {
      case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
    }
    httpClient.close()
    null
  }
  def tryPost(url:String,para:String,tryTimes:Int,currentTrys:Int=0,msgLength:Int= -1):JSONObject = {
    // --jars httpclient-4.5.3.jar
    var result:JSONObject = null
    try{
      result =  HttpUtils.urlConnectionPostJson(url,para,30*1000)
    }catch{
      case e:Exception=>{
        if(msgLength== -1)
          logger.error("++++++++++++++++++++++++++++++++\n"+para)
        else if(msgLength>0){
          logger.error("--------------------------------"+(para.substring(0,Math.min(para.length,msgLength))))
        }
        logger.error(e)
        if(currentTrys<tryTimes){
          val wait = (currentTrys+1) * 2
          //System.err.println("retry waiting seconds: "+ wait)
          Thread.sleep(wait * 500)
          result = tryPost(url,para,tryTimes,currentTrys+1,msgLength)
        }
      }
    }
    result
  }
  /**
   * http post请求
   * @param url
   * @param json
   * @return
   */
  def getJsonByPostJson(url: String, json: String): JSONObject = {
    // 创建Httpclient对象
    val httpClient = HttpClients.createDefault
    var httpResponse:CloseableHttpResponse  = null
    var jsonObj:JSONObject = null
    try { // 创建Http Post请求
      val httpPost = new HttpPost(url)
      val requestConfig = RequestConfig.custom().setConnectTimeout(20000).setConnectionRequestTimeout(20000).setSocketTimeout(20000).build()
      httpPost.setConfig(requestConfig)
      // 创建请求内容
      val entity = new StringEntity(json, ContentType.APPLICATION_JSON)
      httpPost.setEntity(entity)
      // 执行http请求
      httpResponse = httpClient.execute(httpPost)
      val stringEntity = EntityUtils.toString(httpResponse.getEntity, "utf-8")
      println("返回："+stringEntity)
      try {
        jsonObj = JSON.parseObject(stringEntity)
      } catch {
        case e:Exception =>logger.error(">>>结果转换json独享异常："+e)
      }
    } catch {
      case e: Exception =>logger.error(">>>解析异常："+e)
    }
    if(httpResponse!=null)
      httpResponse.close()
    if(httpClient!=null)
      httpClient.close()
    jsonObj
  }




}
