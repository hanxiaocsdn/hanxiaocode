package com.sf.gis.scala.base.spark

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.custom_module.SfNetIntefaceCommon
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.custom_module._
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01374443 on 2020/7/27.
 */
object SparkNetNew {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
   * * 从geo获取分词
   *
   * @param jObject     输入数据
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   */
  def queryLastestSplitFromRds(sparkSession: SparkSession, jObject: RDD[JSONObject], parallelism: Int, minuLimit: Int, cityCodeKey: String, addressKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey)
    println("jObject:" + jObject.count())
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceRds.rdsGeoSplitTestEnv, keyMap,
      parallelism, "2b47c30dc44a48de9db4d13b3009871a", minuLimit, httpTimeOutMill).map(obj => {
      obj.put("rdsSplit", JSONUtil.getJsonValMulti(obj, "rdsGeoSplitTestEnv.result.other.normresp.result.splitResult"))
      if (!saveTotal) {
        obj.remove("rdsGeoSplitTestEnv")
      }
      println("dddd1")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("切词运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 切词服务获取切词
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   * @param cityCodeKey 城市代码字段名称
   *
   **/
  def querySplit(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                 addressKey: String, cityCodeKey: String,
                 saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("address" -> addressKey, "cityCode" -> cityCodeKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceCommon.splitApi, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val data = JSONUtil.getJsonArrayMulti(obj, "splitApi.result.data.info")
      val splitBuffer = new StringBuffer()
      for (i <- 0 until data.size()) {
        val item = data.getJSONObject(i)
        val name = JSONUtil.getJsonValSingle(item, "name")
        val level = JSONUtil.getJsonValSingle(item, "level")
        val prop = JSONUtil.getJsonValSingle(item, "prop")
        splitBuffer.append(name + "^" + prop + level)
        if (i != data.size() - 1) {
          splitBuffer.append("|")
        }
      }
      val ret = splitBuffer.toString
      obj.put("split_info", ret)
      if (!saveTotal) {
        obj.remove("splitApi")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("切词服务获取切词接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 切词服务获取切词
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   * @param cityCodeKey 城市代码字段名称
   *
   **/
  def queryNormlizeAddr(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                        addressKey: String, cityCodeKey: String,
                        saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("address" -> addressKey,"citycode"->cityCodeKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceCommon.normlizeApi, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("normAddr", JSONUtil.getJsonValMulti(obj, "normlizeApi.address"))
      if (!saveTotal) {
        obj.remove("normlizeApi")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("地址规范化接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 获取地理编码服务ma1值
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryMapAMa1(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int, cityCodeKey: String, addressKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceGeo.geoInfoMa1, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val result = obj.getJSONObject("geoInfoMa1.result")
      obj.put("ma1X", JSONUtil.getJsonValMulti(obj, "xcoord"))
      obj.put("ma1Y", JSONUtil.getJsonValMulti(obj, "ycoord"))
      obj.put("ma1Precision", JSONUtil.getJsonValMulti(obj, "precision"))
      if (!saveTotal) {
        obj.remove("geoInfoMa1")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("ma1运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 获取图商服务高德值
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryTsGd(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int, cityCodeKey: String, addressKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceGeo.geoInfoGd, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("gdX", JSONUtil.getJsonValMulti(obj, "geoInfoGd.result.xcoord"))
      obj.put("gdY", JSONUtil.getJsonValMulti(obj, "geoInfoGd.result.ycoord"))
      obj.put("gdPrecision", JSONUtil.getJsonValMulti(obj, "geoInfoGd.result.precision"))
      if (!saveTotal) {
        obj.remove("geoInfoGd")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("图商高德运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 获取图商服务
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryTsXy(sparkSession: SparkSession, jObject: RDD[JSONObject],
                ak: String, parallelism: Int, minuLimit: Int, cityCodeKey: String,
                addressKey: String,tsType:String, saveTotal: Boolean = false,
                httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey,"opt"->"opt")
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject.map(obj=>{
      obj.put("opt",tsType)
      obj
    }), SfNetIntefaceGeo.geoInfoTs, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("tsX", JSONUtil.getJsonValMulti(obj, "geoInfoTs.result.xcoord"))
      obj.put("tsY", JSONUtil.getJsonValMulti(obj, "geoInfoTs.result.ycoord"))
      obj.put("tsPrecision", JSONUtil.getJsonValMulti(obj, "geoInfoTs.result.precision"))
      if (!saveTotal) {
        obj.remove("geoInfoTs")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("图商运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 获取rds容灾派件综合
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryRdsPaiZh(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int, cityCodeKey: String, addressKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceRds.rdsRzPaiZh, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val tcs = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "rdsRzPaiZh.result.tcs")
      obj.put("rdsPaiZhZcSrc", JSONUtil.getJsonValSingle(tcs, "atDeptSrc"))
      obj.put("rdsPaiZhZc", JSONUtil.getJsonValSingle(tcs, "dept"))
      obj.put("rdsPaiZhGid", JSONUtil.getJsonValSingle(tcs, "groupid"))
      obj.put("rdsPaiZhAoiid", JSONUtil.getJsonValSingle(tcs, "aoiid"))
      obj.put("rdsPaiZhAoiSrc", JSONUtil.getJsonValSingle(tcs, "atAoiSrc"))
      obj.put("rdsPaiZhAoicode", JSONUtil.getJsonValSingle(tcs, "aoicode"))
      obj.put("rdsPaiZhKeyWord", JSONUtil.getJsonValSingle(tcs, "keyWord"))
      val normRespResult = JSONUtil.getJsonObjectMulti(obj, "rdsRzPaiZh.result.other.normresp.result")
      obj.put("rdsPaiZhSplitResult", JSONUtil.getJsonValSingle(normRespResult, "splitResult"))
      val geocoders = JSONUtil.getJsonArrayMulti(normRespResult, "geocoder");
      val groupArray = new ArrayBuffer[String]()
      val filterArray = new ArrayBuffer[String]()
      val nameArray = new ArrayBuffer[String]()
      val levelArray = new ArrayBuffer[String]()
      val matchIdArray = new ArrayBuffer[String]()
      val standardizationArray = new ArrayBuffer[String]()
      for (i <- 0 until geocoders.size()) {
        val geocoder = geocoders.getJSONObject(i)
        groupArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        filterArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        nameArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        levelArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        matchIdArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        standardizationArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
      }
      obj.put("rdsPaiZhGroupGroup", groupArray.mkString("$"))
      obj.put("rdsPaiZhFilter", filterArray.mkString("$"))
      obj.put("rdsPaiZhMatchName", nameArray.mkString("$"))
      obj.put("rdsPaiZhMatchId", matchIdArray.mkString("$"))
      obj.put("rdsPaiZhMatchLevel", levelArray.mkString("$"))
      obj.put("rdsPaiZhStandardization", standardizationArray.mkString("$"))
      if (!saveTotal) {
        obj.remove("rdsRzPaiZh")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("RDS容灾zh运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 获取rds容灾派件norm标准库
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryRdsPaiNorm(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int, cityCodeKey: String, addressKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceRds.rdsRzPaiNorm, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val tcs = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "rdsRzPaiNorm.result.tcs")
      obj.put("rdsPaiNormZcSrc", JSONUtil.getJsonValSingle(tcs, "atDeptSrc"))
      obj.put("rdsPaiNormZc", JSONUtil.getJsonValSingle(tcs, "dept"))
      obj.put("rdsPaiNormGid", JSONUtil.getJsonValSingle(tcs, "groupid"))
      obj.put("rdsPaiNormAoiid", JSONUtil.getJsonValSingle(tcs, "aoiid"))
      obj.put("rdsPaiNormAoiSrc", JSONUtil.getJsonValSingle(tcs, "atAoiSrc"))
      obj.put("rdsPaiNormAoicode", JSONUtil.getJsonValSingle(tcs, "aoicode"))
      obj.put("rdsPaiNormKeyWord", JSONUtil.getJsonValSingle(tcs, "keyWord"))
      val normRespResult = JSONUtil.getJsonObjectMulti(obj, "rdsRzPaiNorm.result.other.normresp.result")
      obj.put("rdsPaiNormSplitResult", JSONUtil.getJsonValSingle(normRespResult, "splitResult"))
      val geocoders = JSONUtil.getJsonArrayMulti(normRespResult, "geocoder");
      val groupArray = new ArrayBuffer[String]()
      val filterArray = new ArrayBuffer[String]()
      val nameArray = new ArrayBuffer[String]()
      val levelArray = new ArrayBuffer[String]()
      val matchIdArray = new ArrayBuffer[String]()
      val standardizationArray = new ArrayBuffer[String]()
      for (i <- 0 until geocoders.size()) {
        val geocoder = geocoders.getJSONObject(i)
        groupArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        filterArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        nameArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        levelArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        matchIdArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        standardizationArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
      }
      obj.put("rdsPaiNormGroupGroup", groupArray.mkString("$"))
      obj.put("rdsPaiNormFilter", filterArray.mkString("$"))
      obj.put("rdsPaiNormMatchName", nameArray.mkString("$"))
      obj.put("rdsPaiNormMatchId", matchIdArray.mkString("$"))
      obj.put("rdsPaiNormMatchLevel", levelArray.mkString("$"))
      obj.put("rdsPaiNormStandardization", standardizationArray.mkString("$"))
      if (!saveTotal) {
        obj.remove("rdsRzPaiNorm")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("RDS容灾norm运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 获取rds容灾派件norm标准库明细
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryRdsPaiNormDetail(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int, cityCodeKey: String, addressKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceRds.rdsRzPaiNormDetail, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val tcs = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "rdsRzPaiNormDetail.result.tcs")
      obj.put("rdsPaiNormZcSrc", JSONUtil.getJsonValSingle(tcs, "atDeptSrc"))
      obj.put("rdsPaiNormZc", JSONUtil.getJsonValSingle(tcs, "dept"))
      obj.put("rdsPaiNormGid", JSONUtil.getJsonValSingle(tcs, "groupid"))
      obj.put("rdsPaiNormAoiid", JSONUtil.getJsonValSingle(tcs, "aoiid"))
      obj.put("rdsPaiNormAoiSrc", JSONUtil.getJsonValSingle(tcs, "atAoiSrc"))
      obj.put("rdsPaiNormAoicode", JSONUtil.getJsonValSingle(tcs, "aoicode"))
      obj.put("rdsPaiNormKeyWord", JSONUtil.getJsonValSingle(tcs, "keyWord"))
      val normRespResult = JSONUtil.getJsonObjectMulti(obj, "rdsRzPaiNormDetail.result.other.normresp.result")
      obj.put("rdsPaiNormSplitResult", JSONUtil.getJsonValSingle(normRespResult, "splitResult"))
      val geocoders = JSONUtil.getJsonArrayMulti(normRespResult, "geocoder");
      val groupArray = new ArrayBuffer[String]()
      val filterArray = new ArrayBuffer[String]()
      val nameArray = new ArrayBuffer[String]()
      val levelArray = new ArrayBuffer[String]()
      val matchIdArray = new ArrayBuffer[String]()
      val standardizationArray = new ArrayBuffer[String]()
      for (i <- 0 until geocoders.size()) {
        val geocoder = geocoders.getJSONObject(i)
        groupArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        filterArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        nameArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        levelArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        matchIdArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
        standardizationArray.append(JSONUtil.getJsonValSingle(geocoder, "group"))
      }
      obj.put("rdsPaiNormGroupGroup", groupArray.mkString("$"))
      obj.put("rdsPaiNormFilter", filterArray.mkString("$"))
      obj.put("rdsPaiNormMatchName", nameArray.mkString("$"))
      obj.put("rdsPaiNormMatchId", matchIdArray.mkString("$"))
      obj.put("rdsPaiNormMatchLevel", levelArray.mkString("$"))
      obj.put("rdsPaiNormStandardization", standardizationArray.mkString("$"))
      val args = JSONUtil.getJsonObjectMulti(obj, "rdsRzPaiNormDetail.result.other.arg")
      obj.put("rdsPaiNormNormalizeAddr", JSONUtil.getJsonValSingle(args, "address"))
      if (!saveTotal) {
        obj.remove("rdsRzPaiNormDetail")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("RDS容灾normdetail运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 获取楼栋信息
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param cityCodeKey 城市代码字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryBuildingInfo(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int, cityCodeKey: String, addressKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("citycode" -> cityCodeKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceCommon.buildingInfo, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {

      val args = JSONUtil.getJsonObjectMulti(obj, "buildingInfo.result")
      obj.put("buildingInfoBuildingId", JSONUtil.getJsonValSingle(args, "buildingId"))
      if (!saveTotal) {
        obj.remove("buildingInfo")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取楼栋信息接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 地址可达获取四级地址
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param provinceKey 省份字段名称
   * @param cityNameKey 城市名字段名称
   * @param districtKey 区字段名称
   * @param addressKey  地址字段名称
   *
   **/
  def queryAddrReach(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                     provinceKey: String, cityNameKey: String, districtKey: String, addressKey: String,
                     saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("province" -> provinceKey, "cityName" -> cityNameKey, "district" -> districtKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceCommon.addrReach, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {

      val district = JSONUtil.getJsonObjectMulti(obj, "addrReach.district")
      obj.put("addrReachProvince", JSONUtil.getJsonValSingle(district, "province"))
      obj.put("addrReachCity", JSONUtil.getJsonValSingle(district, "city"))
      obj.put("addrReachCounty", JSONUtil.getJsonValSingle(district, "county"))
      obj.put("addrReachTown", JSONUtil.getJsonValSingle(district, "town"))
      if (!saveTotal) {
        obj.remove("addrReach")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取地址可达接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 地址可达灰度测试
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   *
   **/
  def queryAddrReachGray(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         provinceKey: String, cityNameKey: String, districtKey: String, addressKey: String,
                         saveTotal: Boolean = false, httpTimeOutMill: Int = 5000,
                         parmMap:util.HashMap[String,String]): RDD[JSONObject] = {
    val keyMap = Map("province" -> provinceKey, "cityName" -> cityNameKey, "district" -> districtKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitDynamicMultiThread(sparkSession, jObject, SfNetIntefaceCommon.addrReachGray, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill,parmMap).map(obj => {
      val result = JSONUtil.getJsonObjectMulti(obj, "addrReachGray")
      val district = JSONUtil.getJsonObjectMulti(result, "district")

      obj.put("r_province", JSONUtil.getJsonValSingle(district, "province"))
      obj.put("r_province", JSONUtil.getJsonValSingle(district, "province"))
      obj.put("r_city", JSONUtil.getJsonValSingle(district, "city"))
      obj.put("r_county", JSONUtil.getJsonValSingle(district, "county"))
      obj.put("r_town", JSONUtil.getJsonValSingle(district, "town"))
      obj.put("r_village", JSONUtil.getJsonValSingle(district, "village"))
      obj.put("r_detailinfo", JSONUtil.getJsonValSingle(district, "detailinfo"))

      obj.put("r_result", JSONUtil.getJsonValSingle(result, "result"))
      val r_src = JSONUtil.getJsonValSingle(result, "src")
      obj.put("r_src", r_src)
      if("ar-geo".equals(r_src)){
        val bxy = JSONUtil.getJsonObjectMulti(result, "extention.POI.BXY")
        obj.put("r_bxy_province", JSONUtil.getJsonValSingle(bxy, "province"))
        obj.put("r_bxy_city", JSONUtil.getJsonValSingle(bxy, "city"))
        obj.put("r_bxy_county", JSONUtil.getJsonValSingle(bxy, "county"))
        obj.put("r_bxy_town", JSONUtil.getJsonValSingle(bxy, "town"))
        obj.put("r_bxy_village", JSONUtil.getJsonValSingle(bxy, "village"))
        obj.put("r_bxy_detailinfo", JSONUtil.getJsonValSingle(bxy, "detailinfo"))
      }
      obj.put("r_city_code", JSONUtil.getJsonValSingle(result, "city_code"))
      obj.put("r_detail_addr", JSONUtil.getJsonValSingle(result, "detail_addr"))
      obj.put("r_detail_level", JSONUtil.getJsonValSingle(result, "detail_level"))
      obj.put("r_detail_addr_special", JSONUtil.getJsonValSingle(result, "detail_addr_special"))
      obj.put("r_detail_type", JSONUtil.getJsonValSingle(result, "detail_type"))
      obj.put("r_town_only", JSONUtil.getJsonValSingle(result, "town_only"))
      obj.put("r_splite_result_iad", JSONUtil.getJsonVal(result, "extention.splite_result_iad",""))

      val myException = JSONUtil.getJsonObjectMulti(result, "myException")
      if(myException!=null && !myException.isEmpty){
        obj.put("myException",myException)
      }
      val r_result = JSONUtil.getJsonValSingle(result, "result","")
      val r_province = JSONUtil.getJsonValSingle(district, "province")
      if (!saveTotal || !r_province.isEmpty) {
        obj.remove("addrReachGray")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取地址可达接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 地址可达生产测试
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   *
   **/
  def addrReachGrayByUrl(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         provinceKey: String, cityNameKey: String, districtKey: String, addressKey: String,
                         saveTotal: Boolean = false, httpTimeOutMill: Int = 5000,
                         parmMap:util.HashMap[String,String]): RDD[JSONObject] = {
    val keyMap = Map("province" -> provinceKey, "cityName" -> cityNameKey, "district" -> districtKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitDynamicMultiThread(sparkSession, jObject, SfNetIntefaceCommon.addrReachGrayByUrl, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill,parmMap).map(obj => {
      val result = JSONUtil.getJsonObjectMulti(obj, "addrReachGrayByUrl")
      val district = JSONUtil.getJsonObjectMulti(result, "district")
      obj.put("r_province", JSONUtil.getJsonValSingle(district, "province"))
      obj.put("r_city", JSONUtil.getJsonValSingle(district, "city"))
      obj.put("r_county", JSONUtil.getJsonValSingle(district, "county"))
      obj.put("r_town", JSONUtil.getJsonValSingle(district, "town"))
      obj.put("r_village", JSONUtil.getJsonValSingle(district, "village"))
      obj.put("r_detailinfo", JSONUtil.getJsonValSingle(district, "detailinfo"))

      obj.put("r_result", JSONUtil.getJsonValSingle(result, "result"))
      val r_src = JSONUtil.getJsonValSingle(result, "src")
      obj.put("r_src", r_src)
      if("ar-geo".equals(r_src)){
        val bxy = JSONUtil.getJsonObjectMulti(result, "extention.POI.BXY")
        obj.put("r_bxy_province", JSONUtil.getJsonValSingle(bxy, "province"))
        obj.put("r_bxy_city", JSONUtil.getJsonValSingle(bxy, "city"))
        obj.put("r_bxy_county", JSONUtil.getJsonValSingle(bxy, "county"))
        obj.put("r_bxy_town", JSONUtil.getJsonValSingle(bxy, "town"))
        obj.put("r_bxy_village", JSONUtil.getJsonValSingle(bxy, "village"))
        obj.put("r_bxy_detailinfo", JSONUtil.getJsonValSingle(bxy, "detailinfo"))
      }
      obj.put("r_city_code", JSONUtil.getJsonValSingle(result, "city_code"))
      obj.put("r_detail_addr", JSONUtil.getJsonValSingle(result, "detail_addr"))
      obj.put("r_detail_level", JSONUtil.getJsonValSingle(result, "detail_level"))
      obj.put("r_detail_addr_special", JSONUtil.getJsonValSingle(result, "detail_addr_special"))
      obj.put("r_detail_type", JSONUtil.getJsonValSingle(result, "detail_type"))
      obj.put("r_town_only", JSONUtil.getJsonValSingle(result, "town_only"))
      obj.put("r_splite_result_iad", JSONUtil.getJsonVal(result, "extention.splite_result_iad",""))

      val myException = JSONUtil.getJsonObjectMulti(result, "myException")
      if(myException!=null && !myException.isEmpty){
        obj.put("myException",myException)
      }
      val r_result = JSONUtil.getJsonValSingle(result, "result","")
      val r_province = JSONUtil.getJsonValSingle(district, "province")
      if (!saveTotal || !r_province.isEmpty) {
        obj.remove("addrReachGrayByUrl")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取地址可达接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 地址可达灰度测试
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   *
   **/
  def queryAddrReachTest(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         provinceKey: String, cityNameKey: String, districtKey: String, addressKey: String,
                         saveTotal: Boolean = false, httpTimeOutMill: Int = 5000,
                         parmMap:util.HashMap[String,String]): RDD[JSONObject] = {
    val keyMap = Map("province" -> provinceKey, "cityName" -> cityNameKey, "district" -> districtKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitDynamicMultiThread(sparkSession, jObject, SfNetIntefaceCommon.addrReachTest, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill,parmMap).map(obj => {
      val result = JSONUtil.getJsonObjectMulti(obj, "addrReachTest")
      val district = JSONUtil.getJsonObjectMulti(result, "district")
      obj.put("r_province", JSONUtil.getJsonValSingle(district, "province"))
      obj.put("r_province", JSONUtil.getJsonValSingle(district, "province"))
      obj.put("r_city", JSONUtil.getJsonValSingle(district, "city"))
      obj.put("r_county", JSONUtil.getJsonValSingle(district, "county"))
      obj.put("r_town", JSONUtil.getJsonValSingle(district, "town"))
      obj.put("r_village", JSONUtil.getJsonValSingle(district, "village"))
      obj.put("r_detailinfo", JSONUtil.getJsonValSingle(district, "detailinfo"))

      obj.put("r_result", JSONUtil.getJsonValSingle(result, "result"))
      val r_src = JSONUtil.getJsonValSingle(result, "src")
      obj.put("r_src", r_src)
      if("ar-geo".equals(r_src)){
        val bxy = JSONUtil.getJsonObjectMulti(result, "extention.POI.BXY")
        obj.put("r_bxy_province", JSONUtil.getJsonValSingle(bxy, "province"))
        obj.put("r_bxy_city", JSONUtil.getJsonValSingle(bxy, "city"))
        obj.put("r_bxy_county", JSONUtil.getJsonValSingle(bxy, "county"))
        obj.put("r_bxy_town", JSONUtil.getJsonValSingle(bxy, "town"))
        obj.put("r_bxy_village", JSONUtil.getJsonValSingle(bxy, "village"))
        obj.put("r_bxy_detailinfo", JSONUtil.getJsonValSingle(bxy, "detailinfo"))
      }
      obj.put("r_city_code", JSONUtil.getJsonValSingle(result, "city_code"))
      obj.put("r_detail_addr", JSONUtil.getJsonValSingle(result, "detail_addr"))
      obj.put("r_detail_level", JSONUtil.getJsonValSingle(result, "detail_level"))
      obj.put("r_detail_addr_special", JSONUtil.getJsonValSingle(result, "detail_addr_special"))
      obj.put("r_detail_type", JSONUtil.getJsonValSingle(result, "detail_type"))
      obj.put("r_town_only", JSONUtil.getJsonValSingle(result, "town_only"))
      obj.put("r_splite_result_iad", JSONUtil.getJsonVal(result, "extention.splite_result_iad",""))
      val myException = JSONUtil.getJsonObjectMulti(result, "myException")
      if(myException!=null && !myException.isEmpty){
        obj.put("myException",myException)
      }
      val r_result = JSONUtil.getJsonValSingle(result, "result","")
      if (!saveTotal ) {
        obj.remove("addrReachTest")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取地址可达接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 客诉zc模型灰度测试
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   *
   **/
  def queryZcModeGray(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         cityCodeKey: String, addressKey: String,
                         saveTotal: Boolean = false, httpTimeOutMill: Int = 5000,
                         parmMap:util.HashMap[String,String]): RDD[JSONObject] = {
    val keyMap = Map("city" -> cityCodeKey, "address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitDynamicMultiThread(sparkSession, jObject, SfNetIntefaceCommon.zcModeGray, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill,parmMap).map(obj => {
      val zcModeGray = JSONUtil.getJsonObjectMulti(obj, "zcModeGray")
      val result = JSONUtil.getJsonObjectMulti(zcModeGray, "result")
      obj.put("r_dept", JSONUtil.getJsonValSingle(result, "dept"))
      obj.put("r_zctag", JSONUtil.getJsonValSingle(result, "zcTag"))
      val myException = JSONUtil.getJsonObjectMulti(result, "myException")
      if(myException!=null && !myException.isEmpty){
        obj.put("myException",myException)
      }
      if (!saveTotal) {
        obj.remove("zcModeGray")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取zc模型接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  def queryZcModeGrayTmp(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                      cityCodeKey: String, addressKey: String, mobileKey: String,
                      saveTotal: Boolean = false, httpTimeOutMill: Int = 5000,
                      parmMap:util.HashMap[String,String]): RDD[JSONObject] = {
    val keyMap = Map("city" -> cityCodeKey, "address" -> addressKey, "mobile" -> mobileKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitDynamicMultiThread(sparkSession, jObject, SfNetIntefaceCommon.zcModeGrayTmp, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill,parmMap).map(obj => {
      val zcModeGray = JSONUtil.getJsonObjectMulti(obj, "zcModeGrayTmp")
      val result = JSONUtil.getJsonObjectMulti(zcModeGray, "result")
      obj.put("r_dept", JSONUtil.getJsonValSingle(result, "dept"))
      obj.put("r_zctag", JSONUtil.getJsonValSingle(result, "zcTag"))
      obj.put("r_aoi", JSONUtil.getJsonValSingle(result, "aoi"))
      obj.put("r_aoi_tag", JSONUtil.getJsonValSingle(result, "aoiTag"))
      val myException = JSONUtil.getJsonObjectMulti(result, "myException")
      if(myException!=null && !myException.isEmpty){
        obj.put("myException",myException)
      }
      if (!saveTotal) {
        obj.remove("zcModeGray")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取zc模型接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * seg切词获取四级地址
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   *
   **/
  def querySegSplit(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                    addressKey: String,
                    saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceCommon.segSplit, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {

      val data = JSONUtil.getJsonObjectMulti(obj, "segSplit.data")
      obj.put("segSplitProvince", JSONUtil.getJsonValSingle(data, "province"))
      obj.put("segSplitCity", JSONUtil.getJsonValSingle(data, "city"))
      obj.put("segSplitCounty", JSONUtil.getJsonValSingle(data, "county"))
      obj.put("segSplitTown", JSONUtil.getJsonValSingle(data, "town"))
      obj.put("segSplitCitycode", JSONUtil.getJsonValSingle(data, "citycode"))
      obj.put("segSplitMark", JSONUtil.getJsonValSingle(data, "result.mark"))
      if (!saveTotal) {
        obj.remove("segSplit")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("获取seg切词四级地址接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 坐标获取网点和aoi
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param xKey        经度字段名称
   * @param yKey        纬度字段名称
   *
   **/
  def queryXyToAoiZc(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                     xKey: String, yKey: String,
                     saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("x" -> xKey, "y" -> yKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.xyToAoiZc, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val aoi_data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "xyToAoiZc.result.data.aois")
      aoi_data.remove("aoi_lat")
      aoi_data.remove("aoi_lng")
      obj.put("xyToAoiZcAoiId", JSONUtil.getJsonValSingle(aoi_data, "aoi_id"))
      obj.put("xyToAoiZcAoiCode", JSONUtil.getJsonValSingle(aoi_data, "aoi_code"))
      obj.put("xyToAoiZcAoiName", JSONUtil.getJsonValSingle(aoi_data, "aoi_name"))
      obj.put("xyToAoiZcZc", JSONUtil.getJsonValSingle(aoi_data, "zc"))
      if (!saveTotal) {
        obj.remove("xyToAoiZc")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("坐标获取网点接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * aoiid获取aoi信息
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param aoiIdKey    aoiId字段名称
   *
   *
   **/
  def queryAoiIdInfo(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                     aoiIdKey: String,
                     saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("aoiId" -> aoiIdKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.aoiIdInfo, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "aoiIdInfo.result.data")
      obj.put("aoiIdInfoAoiCode", JSONUtil.getJsonValSingle(data, "aoi_code"))
      obj.put("aoiIdInfoAoiName", JSONUtil.getJsonValSingle(data, "aoi_name"))
      obj.put("aoiIdInfoZc", JSONUtil.getJsonValSingle(data, "zno_code"))
      obj.put("aoiIdInfoCityCode", JSONUtil.getJsonValSingle(data, "city_code"))
      if (!saveTotal) {
        obj.remove("aoiIdInfo")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("aoiid获取aoi信息接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 获取德邦网点和aoi的面积交叉比例
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param aoiIdKey    aoiId字段名称
   *
   *
   **/
  def queryDeponZcIntersectAoi(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                               deponZcKey: String, aoiIdKey: String,
                               saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("deponZc" -> deponZcKey, "aoiId" -> aoiIdKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceDeppon.deponZcIntersectAoi, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "deponZcIntersectAoi.result.data")
      obj.put("aPercent", JSONUtil.getJsonValSingle(data, "aPercent"))
      if (!saveTotal) {
        obj.remove("deponZcIntersectAoi")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("德邦网点和aoiid的面积交叉比例接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }


  /**
   * 坐标获取顺心信息，包括顺心网点
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param xKey        x字段名称
   * @param yKey        y字段名称
   *
   **/
  def queryXyToSxInfo(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                      xKey: String, yKey: String,
                      saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("x" -> xKey, "y" -> yKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceSx.xyToSxInfo, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val map_data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "xyToSxInfo.result.map_data")
      obj.put("sxZc", JSONUtil.getJsonValSingle(map_data, "code"))
      if (!saveTotal) {
        obj.remove("xyToSxInfo")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("坐标获取顺心信息接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 地址获取顺心信息，包括顺心网点
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   *
   **/
  def queryAddrToSxInfo(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                        addressKey: String,
                        saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceSx.addrToSxInfo, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val map_data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "addrToSxInfo.result.map_data")
      obj.put("sxZc", JSONUtil.getJsonValSingle(map_data, "code"))
      if (!saveTotal) {
        obj.remove("addrToSxInfo")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("地址获取顺心信息接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }

  /**
   * 地址获取顺心信息，包括顺心网点
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param addressKey  地址字段名称
   *
   **/
  def queryAddrToSxInfoV4(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                          addressKey: String,
                          saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("address" -> addressKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceSx.addrToSxInfoV4, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      val result = JSONUtil.getJsonObjectMulti(obj, "addrToSxInfoV4.result")
      val sxData = JSONUtil.getJsonObjectMulti(result, "sxData")
      val areaData = JSONUtil.getJsonObjectMulti(result, "areaData")

      obj.put("v4Zc", JSONUtil.getJsonValSingle(sxData, "code"))
      obj.put("v4Src", JSONUtil.getJsonValSingle(sxData, "codeSource"))
      obj.put("v4Tag", JSONUtil.getJsonValSingle(sxData, "tag"))
      obj.put("v4CityCode", JSONUtil.getJsonValSingle(areaData, "cityCode"))
      obj.put("v4Town", JSONUtil.getJsonValSingle(areaData, "town"))
      obj.put("v4Mark", JSONUtil.getJsonValSingle(areaData, "mark"))
      obj.put("v4Msg", JSONUtil.getJsonValSingle(result, "msg"))
      if (!saveTotal) {
        obj.remove("addrToSxInfoV4")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("地址获取顺心信息V4接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 坐标获取网点和aoi
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param xKey        经度字段名称
   * @param yKey        纬度字段名称
   *
   **/
  def queryXyToAoiZcAoi2(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         xKey: String, yKey: String,
                         saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("x" -> xKey, "y" -> yKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.aoiInfoDataAoi2, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      //      val aoi_data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "xyToAoiZc.result.data.aois")
      //      aoi_data.remove("aoi_lat")
      //      aoi_data.remove("aoi_lng")
      //      obj.put("xyToAoiZcAoiId", JSONUtil.getJsonValSingle(aoi_data, "aoi_id"))
      //      obj.put("xyToAoiZcAoiCode", JSONUtil.getJsonValSingle(aoi_data, "aoi_code"))
      //      obj.put("xyToAoiZcAoiName", JSONUtil.getJsonValSingle(aoi_data, "aoi_name"))
      //      obj.put("xyToAoiZcZc", JSONUtil.getJsonValSingle(aoi_data, "zc"))
      if (!saveTotal) {
        obj.remove("aoiInfoDataAoi2")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("坐标获取aoi接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 坐标获取网点和aoi
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param xKey        经度字段名称
   * @param yKey        纬度字段名称
   *
   **/
  def queryXyToAoiZcDept2(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         xKey: String, yKey: String,
                         saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("x" -> xKey, "y" -> yKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.aoiInfoDept2, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      //      val aoi_data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "xyToAoiZc.result.data.aois")
      //      aoi_data.remove("aoi_lat")
      //      aoi_data.remove("aoi_lng")
      //      obj.put("xyToAoiZcAoiId", JSONUtil.getJsonValSingle(aoi_data, "aoi_id"))
      //      obj.put("xyToAoiZcAoiCode", JSONUtil.getJsonValSingle(aoi_data, "aoi_code"))
      //      obj.put("xyToAoiZcAoiName", JSONUtil.getJsonValSingle(aoi_data, "aoi_name"))
      //      obj.put("xyToAoiZcZc", JSONUtil.getJsonValSingle(aoi_data, "zc"))
      if (!saveTotal) {
        obj.remove("aoiInfoDept2")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("坐标获取aoi接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 调用dept坐标获取网点和aoi类型
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param xKey        经度字段名称
   * @param yKey        纬度字段名称
   *
   **/
  def queryXyToAoiZcAoitype(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         xKey: String, yKey: String,
                         saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {
    val keyMap = Map("x" -> xKey, "y" -> yKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.aoiInfoDataAoitype, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      //      val aoi_data = JSONUtil.getJsonArrayMultiOfFirstObject(obj, "xyToAoiZc.result.data.aois")
      //      aoi_data.remove("aoi_lat")
      //      aoi_data.remove("aoi_lng")
      //      obj.put("xyToAoiZcAoiId", JSONUtil.getJsonValSingle(aoi_data, "aoi_id"))
      //      obj.put("xyToAoiZcAoiCode", JSONUtil.getJsonValSingle(aoi_data, "aoi_code"))
      //      obj.put("xyToAoiZcAoiName", JSONUtil.getJsonValSingle(aoi_data, "aoi_name"))
      //      obj.put("xyToAoiZcZc", JSONUtil.getJsonValSingle(aoi_data, "zc"))
      if (!saveTotal) {
        obj.remove("aoiInfoDataAoitype")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("坐标获取aoi类型接口运行完毕,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 坐标周围范围内的所有aoi，以及到aoi中心的的距离
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param xKey        经度字段名称
   * @param yKey        纬度字段名称
   *
   **/
  def qeuryXyAroundAoiWithCenterDistance(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                            xKey: String, yKey: String,radiusKey:String, radius:Int,
                            saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {

    val keyMap = Map("x" -> xKey, "y" -> yKey,"radius"->radiusKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject.map(obj=>{
      if(radius != -1) {
        obj.put(radiusKey,radius.toString)
      }
      obj
    }), SfNetIntefaceAoi.xyAroundAoiWithCenterDistance, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("aroundAoiArray",JSONUtil.getJsonArrayMulti(obj,"xyAroundAoiWithCenterDistance.data"))
      obj.put("aroundAoiException",JSONUtil.getJsonObjectMulti(obj,"xyAroundAoiWithCenterDistance.myException"))
      if (!saveTotal) {
        obj.remove("xyAroundAoiWithCenterDistance")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("坐标周围范围内的所有aoi，以及到aoi中心的的距离,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 轨迹点切割aoi
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param trackKey    坐标点列表字段名称
   *
   **/
  def queryTrackToAoi(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         trackKey: String,
                      showAoiCode:String,
                      buffRange:String,
                      saveTotal: Boolean = false,
                      httpTimeOutMill: Int = 5000): RDD[JSONObject] = {

    val keyMap = Map("trackList" -> trackKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.trackToAoi, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("trackRetList",JSONUtil.getJsonArrayMulti(obj,"trackToAoi.data"))
      if (!saveTotal) {
        obj.remove("trackToAoi")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("轨迹获取aoi,整体数量为:" + retRdd.count());
    retRdd
  }
  /**
   * 批量坐标获取aoi
   *
   * @param jObject     输入数据
   * @param ak          接口ak
   * @param parallelism 并行度
   * @param minuLimit   数量/分钟限制
   * @param trackKey    坐标点列表字段名称
   *
   **/
  def queryBactchXyToAoi(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                      trackKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {

    val keyMap = Map("xyList" -> trackKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.bactchXyToAoi, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("xyAoiRetList",JSONUtil.getJsonArrayMulti(obj,"bactchXyToAoi.data"))
      if (!saveTotal) {
        obj.remove("bactchXyToAoi")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("批量坐标获取aoi,整体数量为:" + retRdd.count());
    retRdd
  }


  def queryBactchXyToAoiFix(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                            trackKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {

    val keyMap = Map("xyList" -> trackKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject, SfNetIntefaceAoi.bactchXyToAoiFix, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("xyAoiRetList",JSONUtil.getJsonArrayMulti(obj,"bactchXyToAoiFix.data"))
      if (!saveTotal) {
        obj.remove("bactchXyToAoi")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("批量坐标获取aoi,整体数量为:" + retRdd.count());
    logger.error("接口地址" + CommonUrl.batchXyToAoi2);
    retRdd
  }


  def main(args: Array[String]): Unit = {
    val splitBuffer = new ArrayBuffer[String]()
    splitBuffer.append("dd")
    println(splitBuffer.toString())

    val ak = null
    val keyMap: Map[String, String] = Map("x"->"chnl_lgt","y"->"chnl_lat","radius"->"radius")
    val obj = new JSONObject()
    obj.put("radius",3000)
    obj.put("chnl_lat","113.93758893013")
    obj.put("chnl_lgt","22.514772101122276")
    val dd = SfNetIntefaceAoi.xyAroundAoiWithCenterDistance(ak,obj,keyMap,2000)
    println(dd.toJSONString)
  }
}
