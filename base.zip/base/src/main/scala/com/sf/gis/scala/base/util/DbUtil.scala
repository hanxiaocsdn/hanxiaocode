package com.sf.gis.scala.base.util

import java.sql.{Connection, PreparedStatement, SQLException}

import com.alibaba.druid.pool.DruidDataSource

import scala.collection.mutable.ArrayBuffer
import org.apache.log4j.Logger
/**
 * Created by 01375125 on 2018/8/22.
 */

object DbUtil {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  /**
   * 批量把数据插入到mysql数据库
   *
   * @param sql
   * @param paramList
   */
  def executeBatchSql(conn: Connection, sql: String, paramList: Array[Array[String]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)
      for (params: Array[String] <- paramList) {
        if (params != null) {
          for (i <- params.indices) ps.setString(i + 1, params(i).toString)
          ps.addBatch()
        }

      }
      ps.executeBatch()
      conn.commit()
      ps.close()
      //      conn.close()
    } catch {
      case e: Exception => println(String.format(e + ">>>数据批量操作异常: %s", sql))
    }
  }

  /**
   * 批量执行
   *
   * @param sql
   * @param paramList
   */
  def batchListExecute(conn: Connection, sql: String, paramList: List[Array[Any]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)
      for (params: Array[Any] <- paramList) {
        if (params != null) {
          for (i <- 0 until params.length) ps.setString(i + 1, params(i).toString)
          ps.addBatch()
        }
      }
      ps.executeBatch()
      conn.commit()
      ps.close()
    } catch {
      case e: Exception => logger.error(String.format(e + ">>>数据批量操作异常: %s", sql))
    }
  }

  /**
   * 批量把数据插入到mysql数据库
   *
   * @param sql
   * @param paramList
   */
  def batchExecute(conn: Connection, sql: String, paramList: ArrayBuffer[Array[Any]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)
      for (params: Array[Any] <- paramList) {
        if (params != null) {
          for (i <- params.indices) ps.setString(i + 1, params(i).toString)
          ps.addBatch()
        }

      }
      ps.executeBatch()
      conn.commit()
      ps.close()
      //      conn.close()
    } catch {
      case e: Exception => println(String.format(e + ">>>数据批量操作异常: %s", sql))
    }
  }


  /**
   * 把数据插入到mysql数据库
   *
   * @param sql
   * @param params
   */
  def execute(conn: Connection, sql: String, params: Array[Any]=null): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(true)
      if (params != null) {
        for (i <- params.indices) ps.setString(i + 1, params(i).toString)
      }
      ps.executeUpdate()

      ps.close()
    } catch {
      case e: Exception => {
        println(">>>数据库操作异常," + e + ",sql:" + sql)
        if(params!=null){
          println("param:" + params.mkString(","))
        }

      }

    }
  }


  /**
   * 执行查询语句
   *
   * @param conn
   * @param sql
   */
  def querySql(conn: Connection, sql: String): Unit = {
    //    val list = new ArrayBuffer[]()
    try {
      val ps = conn.prepareStatement(sql)
      //noinspection ScalaUnusedSymbol
      val rs = ps.executeQuery()
      /*while(rs.next()){
        val row = Array
      }*/

      ps.close()
    } catch {
      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
      case e: Exception => println("数据库操作异常：" + e + ">>>")
    }
  }


  /**
   * 查询语句
   *
   * @param conn
   * @param sql
   * @param params
   * @param columns
   * @return
   */
  def selectColumns(conn: Connection, sql: String, params: Array[String], columns: Array[String]): ArrayBuffer[Array[String]] = {
    var ps: PreparedStatement = null
    var rows: ArrayBuffer[Array[String]] = new ArrayBuffer[Array[String]]
    try {
      ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- params.indices) ps.setString(i + 1, params(i))
      }
      val rs = ps.executeQuery()
      while (rs.next()) {
        val row: Array[String] = new Array[String](columns.length)
        for (i <- row.indices) {
          val field = rs.getObject(columns(i))
          if (field != null) {
            row(i) = field.toString
          } else {
            row(i) = ""
          }
        }
        rows += row
      }

    } catch {
      case e: SQLException => println(">>>查询数据异常：" + e)

    }
    rows
  }

  /**
   * 查询语句
   *
   * @param conn
   * @param sql
   * @param columns
   * @return
   */
  def selectColumns(conn: Connection, sql: String, columns: Array[String]): ArrayBuffer[Array[String]] = {
    selectColumns(conn, sql, null, columns)
  }

  def selectColumn(conn: Connection, sql: String, params: Array[String], columns: Array[String]): ArrayBuffer[String] = {
    var ps: PreparedStatement = null
    var rows: ArrayBuffer[String] = new ArrayBuffer[String]
    try {
      ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- params.indices) ps.setString(i + 1, params(i))
      }
      val rs = ps.executeQuery()
      while (rs.next()) {
        val field = rs.getObject(1)
        if (field != null) {
          rows += field.toString
        } else {
          rows += ""
        }
      }
    } catch {
      case e: SQLException => println(">>>查询数据异常：" + e)
    }
    rows
  }

  def selectColumn(conn: Connection, sql: String, columns: Array[String]): ArrayBuffer[String] = {
    selectColumn(conn, sql, null, columns)
  }

  /**
   * 获取数据库连接
   *
   * @return
   */
  def getConnection(driver:String,url:String,userName:String,password:String): Connection = {
    var conn:Connection = null
    var dataSource:DruidDataSource=null
    try{
      dataSource = new DruidDataSource()

      dataSource.setDriverClassName(driver)
      dataSource.setUrl(url)
      dataSource.setUsername(userName)
      dataSource.setPassword(password)
      dataSource.setMaxActive(20)
      dataSource.setMaxWait(1000)
      dataSource.setRemoveAbandoned(false)
      conn = dataSource.getConnection
    }catch {
      case e: Exception =>println(">>>mysql数据库连接异常："+e)
    }
    conn
  }
  def testPU(): Unit = {


  }


}