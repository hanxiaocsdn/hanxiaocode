package com.sf.gis.scala.base.spark

import java.util
import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.{Executors, LinkedBlockingQueue}

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.constants.HttpExceptionType
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.concurrent.{ExecutionContext, ExecutionContextExecutorService}
import scala.util.Random

/**
 * Created by 01374443 on 2020/7/27.
 */
object SparkNetBase {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)
  //http接口因为超时等异常的失败，重试三次
  val httpRetryCnt = 3
  /**
   * 跑接口，控制并发
   * @param sparkSession
   * @param dataRdd 数据体
   * @param fun 具体的http接口
   * @param keyMap http接口需要的字段映射
   * @param parallelism 接口最大并行度
   * @param ak 接口ak，若不需要ak，可传空
   * @param limitOfMinu 分钟访问量
   * @param readTimeOutMill http连接读取超时时间
   * @return
   */
  def runInterfaceWithAkLimitMultiThread(sparkSession: SparkSession,
                                         dataRdd: RDD[JSONObject], fun: (String, JSONObject, Map[String, String],Int) => JSONObject,
                                         keyMap: Map[String, String], parallelism: Int, ak: String, limitOfMinu: Int,
                                         readTimeOutMill:Int,defaultPoolSize:Int=0): RDD[JSONObject] = {
    val (excutors,cores) = Spark.getExcutorInfo(sparkSession)
    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    //此处多核情况未考虑,需要加入多核情况
    //目前的task数量控制在资源最大核数，实际并不是特别合理，最好是有个几倍差，这样能减少倾斜风险
    var maxParallelism = parallelism
    if (parallelism > excutors) {
      maxParallelism = excutors;
    }
    logger.error("最大分区数：" + maxParallelism)
    val curPartition = dataRdd.getNumPartitions
    var runRdd: RDD[JSONObject] = null
    if (curPartition != maxParallelism) {
      //重分区，增加随机key
      runRdd = dataRdd.repartition(maxParallelism)
      logger.error("重分区：" + maxParallelism)
    } else {
      runRdd = dataRdd
    }
    var maxMinueOfPartition = limitOfMinu / maxParallelism
    if (parallelism > maxParallelism) {
      maxMinueOfPartition = limitOfMinu / maxParallelism;
    }
    logger.error("单分区ak最大分钟限制：" + maxMinueOfPartition)

    var poolSize = parallelism / maxParallelism
    if (poolSize == 0) {
      poolSize = 1
    }
    if(defaultPoolSize!=0){
      //以传入参数为第一 解决复杂场景
      poolSize=defaultPoolSize
    }
    logger.error("线程池数量:" + poolSize)

    val retRdd = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu = maxMinueOfPartition
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)
      val retList = new LinkedBlockingQueue[JSONObject]
      if (poolSize != 1) {
        //多线程运行，起线程池
        val threadPool = Executors.newFixedThreadPool(poolSize)
        implicit val ec: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(threadPool)
        partitions.foreach(obj => {
          threadPool.submit(new Runnable {
            override def run(): Unit = {
              akLimitMultiThreadDetail(partitionLimitMinu, partitionsCount, lastMin,
                timeInt, fun, retList, ak, obj, keyMap,readTimeOutMill)
              retList.add(obj)
            }
          })
        })
        threadPool.shutdown()
        while (!threadPool.isTerminated()) {
          Thread.sleep(100)
        }
      } else {
        //单线程运行，起线程池
        partitions.foreach(obj => {
          akLimitMultiThreadDetail(partitionLimitMinu, partitionsCount, lastMin,
            timeInt, fun, retList, ak, obj, keyMap,readTimeOutMill)
          retList.add(obj)
        })
      }
      logger.error("end")
      retList.toArray().iterator
    }).map(obj => obj.asInstanceOf[JSONObject])
//      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("接口运行完毕:" + retRdd.count())
//    retRdd.take(2).foreach(obj => {
//      logger.error(obj.toJSONString)
//    })
    retRdd
  }
  /**
   * 跑接口，控制并发
   * @param sparkSession
   * @param dataRdd 数据体
   * @param fun 具体的http接口
   * @param keyMap http接口需要的字段映射
   * @param parallelism 接口最大并行度
   * @param ak 接口ak，若不需要ak，可传空
   * @param limitOfMinu 分钟访问量
   * @param readTimeOutMill http连接读取超时时间
   * @return
   */
  def runInterfaceWithAkLimitDynamicMultiThread(sparkSession: SparkSession,
                                         dataRdd: RDD[JSONObject], fun: (String, JSONObject, Map[String, String],Int,util.HashMap[String,String]) => JSONObject,
                                         keyMap: Map[String, String], parallelism: Int, ak: String, limitOfMinu: Int,
                                         readTimeOutMill:Int,parmMap:util.HashMap[String,String],defaultPoolSize:Int=0): RDD[JSONObject] = {
    val (excutors,cores) = Spark.getExcutorInfo(sparkSession)
    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    //此处多核情况未考虑,需要加入多核情况
    //目前的task数量控制在资源最大核数，实际并不是特别合理，最好是有个几倍差，这样能减少倾斜风险
    var maxParallelism = parallelism
    if (parallelism > excutors) {
      maxParallelism = excutors;
    }
    logger.error("最大分区数：" + maxParallelism)
    val curPartition = dataRdd.getNumPartitions
    var runRdd: RDD[JSONObject] = null
    if (curPartition != maxParallelism) {
      //重分区，增加随机key
      runRdd = dataRdd.map(obj=>{
        (Random.nextInt(maxParallelism),obj)
      }).repartition(maxParallelism).values
      logger.error("重分区：" + maxParallelism)
    } else {
      runRdd = dataRdd
    }
    var maxMinueOfPartition = limitOfMinu / maxParallelism
    if (parallelism > maxParallelism) {
      maxMinueOfPartition = limitOfMinu / maxParallelism;
    }
    logger.error("单分区ak最大分钟限制：" + maxMinueOfPartition)

    var poolSize = parallelism / maxParallelism
    if (poolSize == 0) {
      poolSize = 1
    }
    if(defaultPoolSize!=0){
      //以传入参数为第一 解决复杂场景
      poolSize=defaultPoolSize
    }
    logger.error("线程池数量:" + poolSize)

    val retRdd = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu = maxMinueOfPartition
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)
      val retList = new LinkedBlockingQueue[JSONObject]
      if (poolSize != 1) {
        //多线程运行，起线程池
        val threadPool = Executors.newFixedThreadPool(poolSize)
        implicit val ec: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(threadPool)
        partitions.foreach(obj => {
          threadPool.submit(new Runnable {
            override def run(): Unit = {
              akLimitMultiThreadDetailDynamic(partitionLimitMinu, partitionsCount, lastMin,
                timeInt, fun, retList, ak, obj, keyMap,readTimeOutMill,parmMap)
              retList.add(obj)
            }
          })
        })
        threadPool.shutdown()
        while (!threadPool.isTerminated()) {
          Thread.sleep(100)
        }
      } else {
        //单线程运行，起线程池
        partitions.foreach(obj => {
          akLimitMultiThreadDetailDynamic(partitionLimitMinu, partitionsCount, lastMin,
            timeInt, fun, retList, ak, obj, keyMap,readTimeOutMill,parmMap)
          retList.add(obj)
        })
      }
      logger.error("end")
      retList.toArray().iterator
    }).map(obj => obj.asInstanceOf[JSONObject])
    //      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    //    logger.error("接口运行完毕:" + retRdd.count())
    //    retRdd.take(2).foreach(obj => {
    //      logger.error(obj.toJSONString)
    //    })
    retRdd
  }
  def akLimitMultiThreadDetail(partitionLimitMinu: Int, partitionsCount: AtomicInteger, lastMin: AtomicInteger,
                               timeInt: AtomicInteger, fun: (String, JSONObject, Map[String, String],Int) => JSONObject,
                               retList: LinkedBlockingQueue[JSONObject], ak: String,
                               obj: JSONObject, keyMap: Map[String, String],readTimeOutMill:Int): Unit = {

    if (partitionsCount.incrementAndGet() % 1000 == 0) {
      logger.error(partitionsCount)
    }
    var cnt = 0
    while(cnt < httpRetryCnt){
      try{
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }
        fun(ak, obj, keyMap,readTimeOutMill)
        cnt = httpRetryCnt
      }catch {
        case e:Exception =>{
          if(e.getMessage.startsWith(HttpExceptionType.retry.name())
            || e.getMessage.equals(HttpExceptionType.tsLimit.name())){
            //重试等异常重试，累计次数
            cnt = cnt + 1
          }else if(e.getMessage.equals(HttpExceptionType.akLimit.name())
            ){
            //ak限制重试，不累计次数
          }else{
            //普通异常，直接退出
            cnt = httpRetryCnt
          }
          logger.error(e+",cnt:"+cnt)
        }
      }

    }

  }
  def akLimitMultiThreadDetailDynamic(partitionLimitMinu: Int, partitionsCount: AtomicInteger, lastMin: AtomicInteger,
                               timeInt: AtomicInteger, fun: (String, JSONObject, Map[String, String],Int,util.HashMap[String,String]) => JSONObject,
                               retList: LinkedBlockingQueue[JSONObject], ak: String,
                               obj: JSONObject, keyMap: Map[String, String],readTimeOutMill:Int,
                                      parmMap:util.HashMap[String,String]): Unit = {

    if (partitionsCount.incrementAndGet() % 1000 == 0) {
      logger.error(partitionsCount)
    }
    var cnt = 0
    while(cnt < httpRetryCnt){
      try{
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }
        fun(ak, obj, keyMap,readTimeOutMill,parmMap)
        cnt = httpRetryCnt
      }catch {
        case e:Exception =>{
          if(e.getMessage.startsWith(HttpExceptionType.retry.name())
            || e.getMessage.equals(HttpExceptionType.tsLimit.name())){
            //重试等异常重试，累计次数
            cnt = cnt + 1
          }else if(e.getMessage.equals(HttpExceptionType.akLimit.name())
          ){
            //ak限制重试，不累计次数
          }else{
            //普通异常，直接退出
            cnt = httpRetryCnt
          }
          logger.error(e+",cnt:"+cnt)
        }
      }

    }

  }

}
