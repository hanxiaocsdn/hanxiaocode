package com.sf.gis.scala.base.net_module;

import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.base.constants.ConstantsIntefaceErr;
import com.sf.gis.scala.base.constants.HttpExceptionType;
import com.sf.gis.scala.base.util.HttpUtils;
import com.sf.gis.scala.base.util.JSONUtil;


import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class HttpCommonAccess {

    /**
     * 初始化url参数值
     *
     * @param keys
     * @param keyMap
     * @param obj
     * @return
     */
    private static Map<String, String> initMap(String[] keys, Map<String, String> keyMap, JSONObject obj) {
        Map<String, String> ret = new HashMap<>();
        for (String key : keys) {
            if (keyMap != null && keyMap.containsKey(key)) {
                ret.put(key, JSONUtil.getJsonValSingle(obj, keyMap.get(key), ""));
            } else {
                ret.put(key, JSONUtil.getJsonValSingle(obj, key, ""));
            }
        }
        return ret;
    }

    /**
     * get方法
     *
     * @param ak
     * @param obj
     * @param keyMap
     * @param httpTimeout
     * @param retFlag
     * @param iaccess
     */
    public static void doGet(JSONObject obj, Map<String, String> keyMap,
                             Integer httpTimeout, String retFlag, IHttpCommonGet iaccess) throws Exception {
        try {
            Map<String, String> parmMap = initMap(iaccess.urlNeedKey(), keyMap, obj);
            if (!iaccess.checkParm(parmMap)) {
                JSONObject tmp = new JSONObject();
                tmp.put("myException", "parm invalid");
                obj.put(retFlag, tmp);
                return;
            }
            String finalUrl = iaccess.createFinalUrl(parmMap);

            JSONObject ret = HttpUtils.urlConnectionGetJson(finalUrl, httpTimeout);
            Integer errCode = JSONUtil.getJsonValMultiInt(ret, "result.err", 0);
            String errMsg = JSONUtil.getJsonValMulti(ret, "result.msg.info","" );
            if (errCode == ConstantsIntefaceErr.akLimitErrMinu) {
                int second = Calendar.getInstance().get(Calendar.SECOND);
                System.out.println("超过ak限制，休眠后重试~");
                Thread.sleep((60 - second) * 1000);
                throw new Exception(HttpExceptionType.akLimit.name());
            }else if(errCode ==ConstantsIntefaceErr.qpsLimitErr && errMsg.contains(ConstantsIntefaceErr.qpsLimitErrMsg)){
                int second = Calendar.getInstance().get(Calendar.SECOND);
                System.out.println("超过图商qps限制，休眠后重试~");
                Thread.sleep((1) * 1000);
                throw new Exception(HttpExceptionType.tsLimit.name());
            }
            obj.put(retFlag, ret);
        } catch (Exception e) {
            JSONObject tmp = new JSONObject();
            tmp.put("myException", e.getMessage());
            obj.put(retFlag, tmp);
            throw e;
        }
    }
    /**
     * get方法
     *
     * @param ak
     * @param obj
     * @param keyMap
     * @param httpTimeout
     * @param retFlag
     * @param iaccess
     */
    public static void doGetStr(JSONObject obj, Map<String, String> keyMap,
                                Integer httpTimeout, String retFlag, IHttpCommonGet iaccess) throws Exception {
        try {
            Map<String, String> parmMap = initMap(iaccess.urlNeedKey(), keyMap, obj);
            if (!iaccess.checkParm(parmMap)) {
                JSONObject tmp = new JSONObject();
                tmp.put("myException", "parm invalid");
                obj.put(retFlag, tmp);
                return;
            }
            String finalUrl = iaccess.createFinalUrl(parmMap);
            String ret = HttpUtils.urlConnectionGetStr(finalUrl, httpTimeout);
            obj.put(retFlag, ret);
        } catch (Exception e) {
            JSONObject tmp = new JSONObject();
            tmp.put("myException", e.getMessage());
            obj.put(retFlag, tmp);
            throw e;
        }
    }
    /**
     * post方法
     *
     * @param ak
     * @param obj
     * @param keyMap
     * @param httpTimeout
     * @param retFlag
     * @param iaccess
     */
    public static void doPost(JSONObject obj, Map<String, String> keyMap, String url,
                              Integer httpTimeout, String retFlag, IHttpCommonPost iaccess) throws Exception {
        try {
            Map<String, String> parmMap = initMap(iaccess.urlNeedKey(), keyMap, obj);
            if (!iaccess.checkParm(parmMap)) {
                JSONObject tmp = new JSONObject();
                tmp.put("myException", "parm invalid");
                obj.put(retFlag, tmp);
                return;
            }
            String finalBody = iaccess.createFinalBody(parmMap);
            JSONObject ret = HttpUtils.urlConnectionPostJson(url, finalBody, httpTimeout);
            if (JSONUtil.getJsonValMultiInt(ret, "result.err", 0) == ConstantsIntefaceErr.akLimitErrMinu) {
                int second = Calendar.getInstance().get(Calendar.SECOND);
                System.out.println("超过ak限制，休眠后重试~");
                Thread.sleep((60 - second) * 1000);
                throw new Exception(HttpExceptionType.akLimit.name());
            }
            obj.put(retFlag, ret);

        } catch (Exception e) {
            JSONObject tmp = new JSONObject();
            tmp.put("myException", e.getMessage());
            obj.put(retFlag, tmp);
            throw e;
        }
    }
}
