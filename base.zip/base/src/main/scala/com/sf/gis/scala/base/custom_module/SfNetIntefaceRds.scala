package com.sf.gis.scala.base.custom_module

import java.net.URLEncoder
import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.net_module.{HttpCommonAccess, IHttpCommonGet}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger

import scala.collection.JavaConverters._

/**
 * Created by 01374443 on 2021/4/2.
 */
object SfNetIntefaceRds {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
   * 访问rds的geo获取切词，此接口只包含特定索引，所以只能用获取切词
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def rdsGeoSplitTestEnv(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address", "citycode")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address")) && !StringUtils.isBlank(parmMap.get("citycode"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.geoSplitUrl.format(URLEncoder.encode(parmMap.get("address"), "utf-8"), parmMap.get("citycode"), ak)
      }
    })
    return obj
  }
  /**
   * rds容灾派件综合
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def rdsRzPaiZh(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address", "citycode")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address")) && !StringUtils.isBlank(parmMap.get("citycode"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.rdsRzPaiZhUrl.format(URLEncoder.encode(parmMap.get("address"), "utf-8"), parmMap.get("citycode"), ak)
      }
    })
    return obj
  }
  /**
   * rds容灾派件norm
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def rdsRzPaiNorm(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address", "citycode")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address")) && !StringUtils.isBlank(parmMap.get("citycode"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.rdsRzPaiNormUrl.format(URLEncoder.encode(parmMap.get("address"), "utf-8"), parmMap.get("citycode"), ak)
      }
    })
    return obj
  }
  /**
   * rds容灾派件normdetail
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def rdsRzPaiNormDetail(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address", "citycode")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address")) && !StringUtils.isBlank(parmMap.get("citycode"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.rdsRzPaiNormDetailUrl.format(URLEncoder.encode(parmMap.get("address"), "utf-8"), parmMap.get("citycode"), ak)
      }
    })
    return obj
  }
  def main(args: Array[String]): Unit = {
    println(Thread.currentThread.getStackTrace()(1).getMethodName)
    //    val dd = new JSONObject()
    //    dd.put("address","深圳市软件产业基地")
    //    dd.put("city","755")
    //    val keyMap=Map("address"->"address","citycode"->"city")
    //    val ff = rdsGeoSplitTestEnv("",dd,keyMap)
    //    println(ff.toJSONString)
  }
}
