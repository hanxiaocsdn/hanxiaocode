package com.sf.gis.scala.base.constants;

public enum ServerType {
    chkshou,
    chkpai,
    seg,
    segcx,
    ars,
    chkquery,
    geo
    ;
    public static ServerType matchServerType(String serverTypeStr) throws Exception {
        ServerType[] serverTypes = ServerType.values();
        for(ServerType serverType:serverTypes){
            if(serverType.name().equals(serverTypeStr)){
                return serverType;
            }
        }
        throw new Exception("no serverType");
    }

}
