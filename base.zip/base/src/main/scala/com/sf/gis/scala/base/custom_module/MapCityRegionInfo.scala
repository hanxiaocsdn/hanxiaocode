package com.sf.gis.scala.base.custom_module

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer

/** *
 * 指标系统中的城市代码，城市code，大区的映射关系
 */
object MapCityRegionInfo {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
   * 标准化省市区数据
   *
   * @return
   */
  def queryCityRegionMap(spark: SparkSession): Broadcast[Map[String, ArrayBuffer[Array[String]]]] = {
    val sql = "select area,region,city,citycode,province from dm_gis.city_name_map group by area,region,city,citycode,province "
    logger.error("拉取城市映射:" + sql)
    val dataList = spark.sql(sql).collect()
    logger.error("整体数据量:" + dataList.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    dataList.foreach(obj => {
      val item = Array(obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4))
      val cityCode = obj.getString(3)
      if (cityMap.contains(cityCode)) {
        val cityCodeList = cityMap.apply(cityCode)
        cityCodeList += item
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += item
        cityMap += (cityCode -> cityCodeList)
      }
    })
    spark.sparkContext.broadcast(cityMap)
  }
  /**
   * 标准化省市区数据
   *
   * @return
   */
  def queryCityRegionMapGroupByCityCode(spark: SparkSession): Map[String, Map[String, String]] = {
    val sql = "select area,region,city,citycode,province,adcode from dm_gis.city_name_map group by area,region,city,citycode,province,adcode "
    logger.error("拉取城市映射:" + sql)
    val dataList = spark.sql(sql).collect()
    logger.error("整体数据量:" + dataList.size)
    var cityMap: Map[String, Map[String, String]] = Map()
    dataList.foreach(obj => {
      val cityCode = obj.getString(3)
      var map : Map[String, String] = Map()
      map += ("province" ->  obj.getString(4))
      map += ("region" -> obj.getString(1))
      map += ("city" -> obj.getString(2))
      map += ("city_code" -> cityCode)
      map += ("adcode" -> obj.getString(5))
      cityMap += (cityCode -> map)
    })
    cityMap
  }
  /**
   * 标准化省市区数据,部分历史遗留代码的字段顺序不一样
   *
   * @return
   */
  def queryCityRegionMapOld(spark: SparkSession): Broadcast[Map[String, ArrayBuffer[Array[String]]]] = {
    val sql = "select province,region,city,citycode,area from dm_gis.city_name_map group by province,region,city,citycode,area "
    logger.error("拉取城市映射:" + sql)
    val dataList = spark.sql(sql).collect()
    logger.error("整体数据量:" + dataList.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    dataList.foreach(obj => {
      val item = Array(obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4))
      val cityCode = obj.getString(3)
      if (cityMap.contains(cityCode)) {
        val cityCodeList = cityMap.apply(cityCode)
        cityCodeList += item
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += item
        cityMap += (cityCode -> cityCodeList)
      }
    })
    spark.sparkContext.broadcast(cityMap)
  }
  /**
   * 标准化大区城市数据
   *
   * @return
   */
  def queryRegionCitycodeMap(spark: SparkSession): Map[String, ArrayBuffer[Array[String]]] = {
    val sql = "select region,city,citycode,adcode,area from dm_gis.city_name_map group by region,city,citycode,adcode,area "
    logger.error("拉取城市映射:" + sql)
    val dataList = spark.sql(sql).collect()
    logger.error("整体数据量:" + dataList.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    dataList.foreach(obj => {
      val item = Array(obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4))
      val cityCode = obj.getString(2)
      if (cityMap.contains(cityCode)) {
        val cityCodeList = cityMap.apply(cityCode)
        cityCodeList += item
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += item
        cityMap += (cityCode -> cityCodeList)
      }
    })
    cityMap
  }
  /**
   * 通过城市代码和地址来推断城市名称
   * @param cityCode
   * @param address
   * @param cityRegionMap
   * @return
   */
  def queryCityNameInfo(cityCode: String, address: String,
                        cityRegionMap: Map[String, ArrayBuffer[Array[String]]]):JSONObject= {
    if (cityCode == null || cityCode.isEmpty) {
      return null
    }
    if (cityRegionMap.contains(cityCode)) {
      val ret = new JSONObject()
      ret.put("citycode", cityCode)
      val cityList: ArrayBuffer[Array[String]] = cityRegionMap.apply(cityCode)
      if (cityList.length == 1) {
        //如果只有一个list，一一对应的，直接返回
        ret.put("province", cityList(0)(4))
        ret.put("region", cityList(0)(1))
        ret.put("city", cityList(0)(2))
        ret.put("area", cityList(0)(0))
      } else if (cityList.length > 1) {
        //一个城市代码对应多个城市名
        ret.put("province", cityList(0)(4))
        ret.put("region", cityList(0)(1))
        ret.put("area", cityList(0)(0))
        for (cityObj <- cityList) {
          val city = cityObj(2)
          val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
          if (address != null && (address.contains(city) || address.contains(city1))) {
            ret.put("city", cityObj(2))
          } else {
            if (ret.getString("city") == null) {
              ret.put("city", "-")
            }
          }
        }
      }
      return ret
    }
    null
  }
  /**
    * 标准化省市区数据,集团标准，部分地区与大区顺序相反
    *
    * @return
    */
  def queryCityRegionMapNew(spark: SparkSession): Broadcast[Map[String, ArrayBuffer[Array[String]]]] = {
    //    val sql = "select province,region,city,citycode,area from dm_gis.city_name_map group by province,region,city,citycode,area "
    val sql =
      """select
        |prov_name as province
        |,region_name as region
        |,city_name as city
        |,city_code as citycode
        |,area_name as area
        |from dm_gis.dim_city_info_df
        |where inc_day = ${inc_day}
      """.stripMargin
    logger.error("拉取城市映射:" + sql)
    val dataList = spark.sql(sql).collect()
    logger.error("整体数据量:" + dataList.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    dataList.foreach(obj => {
      val item = Array(obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4))
      val cityCode = obj.getString(3)
      if (cityMap.contains(cityCode)) {
        val cityCodeList = cityMap.apply(cityCode)
        cityCodeList += item
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += item
        cityMap += (cityCode -> cityCodeList)
      }
    })
    spark.sparkContext.broadcast(cityMap)
  }

  /**
    * 标准化省市区数据
    *剔除辛集市，定州市
    * @return
    */

   def queryCityRegionMap2(spark: SparkSession): Broadcast[Map[String, ArrayBuffer[Array[String]]]] = {
    val sql = "select area,region,city,citycode,province from dm_gis.city_name_map where city not in ('辛集市','定州市')" +
      " group by area,region,city,citycode,province "
    logger.error("拉取城市映射:" + sql)
    val dataList = spark.sql(sql).collect()
    logger.error("整体数据量:" + dataList.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    dataList.foreach(obj => {
      val item = Array(obj.getString(0), obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4))
      val cityCode = obj.getString(3)
      if (cityMap.contains(cityCode)) {
        val cityCodeList = cityMap.apply(cityCode)
        cityCodeList += item
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += item
        cityMap += (cityCode -> cityCodeList)
      }
    })
    spark.sparkContext.broadcast(cityMap)
  }
}
