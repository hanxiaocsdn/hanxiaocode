package com.sf.gis.scala.base.pojo

class StratTime(var stratTime:Long)
