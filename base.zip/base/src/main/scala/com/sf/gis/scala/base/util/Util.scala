package com.sf.gis.scala.base.util

import java.io.{BufferedReader, FileInputStream, InputStreamReader}
import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date}

//import com.mysql.jdbc.Connection
import org.apache.spark.SparkConf

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01375125 on 2018/7/7.
  */
object Util {
  def main(args: Array[String]): Unit = {
  }









  def readResouceToList(): Unit ={
    val path = System.getProperty("user.dir") + "/xiaogeno_out.csv"
    val buff = new BufferedReader(new InputStreamReader(new FileInputStream(path),"utf-8"))
    while(buff.readLine()!=null){

    }

  }

//  /**
//    * 配置spark的conf
//    * @param appName
//    * @return
//    */
//  def getLocalConf(appName:String): SparkConf = {
//    val master = "local[*]"
//    val conf = new SparkConf().setAppName(appName)
//    if (JavaUtil.EN == 1) conf.setMaster(master)
//    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
//    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
//    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
//    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
//    conf.set("quota.consumer.default", (10485760 * 2).toString)
//    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
//      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
//    conf
//  }

  /**
    * 配置spark的conf
    * @param appName
    * @return
    */
  def getSparkConf(appName:String): SparkConf = {

    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("hive.exec.dynamic.partition","true")
    conf.set("hive.exec.dynamic.partition.mode","nonstrict")
    conf.set("spark.network.timeout","3000s")
//        conf.set("spark.executor.instances","40")

    //    conf.set("spark.executor.cores","4")
    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")

    println(Sakyamuni.getSakyamuni)

    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    conf
  }

  /**
    * 获得两个字符串日期中所有日期的字符格式集合
    *
    * @param startDateStr
    * @param endDateStr
    * @return
    */
  def getBetweenDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      val startDate:Date = sdf.parse(startDateStr)
      val endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(startDate, endDate)

      for(date <- dateList) dateListStr += sdf.format(date)

    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }

  /**
    * 获得两个字符串日期中所有日期的字符格式集合
    *
    * @param startDateStr
    * @param endDateStr
    * @return
    */
  def getBetweenDatesStr(startDateStr: String, endDateStr: String,separator:String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      val startDate:Date = sdf.parse(startDateStr)
      val endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(startDate, endDate)

      for(date <- dateList) dateListStr += sdf.format(date)

    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }



  /**
    * 获得两个日期之间的所有日期列表
    *
    * @param start
    * @param end
    * @return
    */
  def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
    val result = new ArrayBuffer[Date]
    val tempStart = Calendar.getInstance
    tempStart.setTime(start)

    tempStart.add(Calendar.DAY_OF_YEAR, 1)
    val tempEnd = Calendar.getInstance
    tempEnd.setTime(end)
    while (tempStart.before(tempEnd)) {
      result += tempStart.getTime
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    result
  }

  /**
    * 获取某天日期之后几天的日期字符串
    * @param inputDateStr 日期
    * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
    */
  def getDay(inputDateStr:String, num:Int): String ={
    getDay(inputDateStr,num,"-")
  }



  /**
    * 获取某天日期之后几天的日期字符串
    * @param inputDateStr 日期
    * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
    * @param separator 日期分隔符
    * @return
    */
  def getDay(inputDateStr:String, num:Int,separator:String): String ={
    val dateStrFormat = "yyyy"+separator+"MM"+separator+"dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    val inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

/*  /**
    * 获取本机日历日期
    *
    * @param delta
    * @return
    */
  def dateDelta(delta: Int): String = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }*/

  /**
    * 获取本机日历日期
    *
    * @param delta
    * @return
    */
  def dateDelta(delta: Int): String = {
    dateDelta(delta,"-")
  }

  /**
    * 获取本机日历日期
    *
    * @param delta
    * @return
    */
  def dateDelta(delta: Int,separator:String): String = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }





  /**
    * 读取csv配置文件，获得城市代码的中文名字
    * @param citycode
    * @return
    */
  def getCityName(citycode:String): String ={



    ""
  }

  /**
    * 读取csv配置文件，获得城市名字的城市代码
    * @param cityname
    * @return
    */
  def getCityCode(cityname:String): String ={

    ""
  }


//  /**
//    * 单条操作
//    *
//    * @param sql
//    * @param params
//    */
//  def executeSql(conn:Connection,sql: String, params: Array[String]): Unit = {
//    try {
//      val ps = conn.prepareStatement(sql)
//      if (params != null) {
//        for (i <- params.indices) ps.setString(i + 1, params(i))
//      }
//      //noinspection ScalaUnusedSymbol
//      //      println(sql)
//      val update = ps.executeUpdate()
//      ps.close()
//    } catch {
//      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
//      case e: Exception => println(">>>数据库操作异常："+e)
//    }
//  }

//  /**
//    * 批量操作
//    * @param sql
//    * @param paramList
//    */
//  def executeSql1(conn:Connection,sql: String, paramList:ArrayBuffer[Array[String]]): Unit = {
//    try {
//      val ps = conn.prepareStatement(sql)
//      conn.setAutoCommit(false)
//
//      for(params:Array[String] <- paramList){
//
//        if (params != null) {
//          for (i <- params.indices) ps.setString(i + 1, params(i))
//          ps.addBatch()
//        }
//
//      }
//      // val update = ps.executeUpdate()
//      ps.executeBatch()
//      conn.commit()
//      ps.close()
//      conn.close()
//    } catch {
//      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
//      case e: Exception => println(">>>数据库操作异常："+e)
//    }
//  }

  /**
    * 时间字符串转换成毫秒值
    * 样例：2018-10-24 09:54:47 236 ==> 1540346087236
    *
    * @param time
    * @return
    */
  @throws[ParseException]
  def timeToLong(time: String, format: String): Long = {
    val sf = new SimpleDateFormat(format)
    sf.parse(time).getTime
  }

}
