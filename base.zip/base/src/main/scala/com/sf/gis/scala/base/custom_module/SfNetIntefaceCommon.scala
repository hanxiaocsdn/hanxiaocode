package com.sf.custom_module

import java.net.URLEncoder
import java.util
import java.util.Date

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.net_module.{HttpCommonAccess, IHttpCommonGet}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger

import collection.JavaConverters._

/**
 * Created by 01374443 on 2021/4/2.
 */
object SfNetIntefaceCommon {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)


  /**
   * 获取楼栋信息
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def buildingInfo(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address", "citycode")
      }

      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.buildingIdUrl.format(URLEncoder.encode(parmMap.get("address"), "utf-8").replaceAll("\\+","%20"), parmMap.get("citycode"), ak)
      }
    })
    return obj
  }
  /**
   * 地址可达
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def addrReach(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("province", "cityName","district","address")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.addReachUrl.format(parmMap.get("province"),parmMap.get("cityName"),parmMap.get("district"),
          URLEncoder.encode(parmMap.get("address"), "utf-8").replaceAll("\\+","%20"), ak)
      }
    })
    return obj
  }
  /**
   * 地址可达
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def addrReachGray(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int,
                    extraMap:java.util.HashMap[String, String]): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("province", "cityName","district","address")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
//        !StringUtils.isBlank(parmMap.get("address"))
        if(extraMap!=null && extraMap.containsKey("exitHour")){
          val hour = new Date().getHours
          val exitHourMin = extraMap.get("exitHourMin").toInt
          val exitHourMax = extraMap.get("exitHourMax").toInt
          if(hour >= exitHourMin && hour <= exitHourMax ){
            return false
          }
        }
        true
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        var address = parmMap.get("address")
        if(!StringUtils.isBlank(address)){
          address = URLEncoder.encode(address, "utf-8").replaceAll("\\+","%20")
        }
        var province = parmMap.get("province")
        if(!StringUtils.isBlank(province)){
          province = URLEncoder.encode(province, "utf-8").replaceAll("\\+","%20")
        }
        var cityName = parmMap.get("cityName")
        if(!StringUtils.isBlank(cityName)){
          cityName = URLEncoder.encode(cityName, "utf-8").replaceAll("\\+","%20")
        }
        var district = parmMap.get("district")
        if(!StringUtils.isBlank(district)){
          district = URLEncoder.encode(district, "utf-8").replaceAll("\\+","%20")
        }
        CommonUrl.addReachUrlGray.format(province,cityName,district,address, ak)
      }
    })
    return obj
  }
  /**
   * 地址可达
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def addrReachGrayByUrl(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int,
                    extraMap:java.util.HashMap[String, String]): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("province", "cityName","district","address")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        //        !StringUtils.isBlank(parmMap.get("address"))
        if(extraMap!=null && extraMap.containsKey("exitHour")){
          val hour = new Date().getHours
          val exitHourMin = extraMap.get("exitHourMin").toInt
          val exitHourMax = extraMap.get("exitHourMax").toInt
          if(hour >= exitHourMin && hour <= exitHourMax ){
            return false
          }
        }
        true
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        var address = parmMap.get("address")
//        if(!StringUtils.isBlank(address)){
//          address = URLEncoder.encode(address, "utf-8").replaceAll("\\+","%20")
//        }
        //这个测试用的是客户原始url进行访问，因此地址字段存的就是所有的数据
        address+ak
      }
    })
    return obj
  }

  /**
   * 地址可达
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def addrReachTest(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int,
                    extraMap:java.util.HashMap[String, String]): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("province", "cityName","district","address")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        //        !StringUtils.isBlank(parmMap.get("address"))
        if(extraMap!=null && extraMap.containsKey("exitHour")){
          val hour = new Date().getHours
          val exitHourMin = extraMap.get("exitHourMin").toInt
          val exitHourMax = extraMap.get("exitHourMax").toInt
          if(hour >= exitHourMin && hour <= exitHourMax ){
            return false
          }
        }
        true
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        var address = parmMap.get("address")
        if(!StringUtils.isBlank(address)){
          address = URLEncoder.encode(address, "utf-8").replaceAll("\\+","%20")
        }
        var province = parmMap.get("province")
        if(!StringUtils.isBlank(province)){
          province = URLEncoder.encode(province, "utf-8").replaceAll("\\+","%20")
        }
        var cityName = parmMap.get("cityName")
        if(!StringUtils.isBlank(cityName)){
          cityName = URLEncoder.encode(cityName, "utf-8").replaceAll("\\+","%20")
        }
        var district = parmMap.get("district")
        if(!StringUtils.isBlank(district)){
          district = URLEncoder.encode(district, "utf-8").replaceAll("\\+","%20")
        }
        CommonUrl.addReacheUrlTest.format(province,cityName,district,address, ak)
      }
    })
    return obj
  }
  /**
   * 客诉zc模型灰度
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def zcModeGray(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int,
                    extraMap:java.util.HashMap[String, String]): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("city","address")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        //        !StringUtils.isBlank(parmMap.get("address"))
        if(extraMap!=null && extraMap.containsKey("exitHour")){
          val hour = new Date().getHours
          val exitHourMin = extraMap.get("exitHourMin").toInt
          val exitHourMax = extraMap.get("exitHourMax").toInt
          if(hour >= exitHourMin && hour <= exitHourMax ){
            return false
          }
        }
        true
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        var address = parmMap.get("address")
        if(!StringUtils.isBlank(address)){
          address = URLEncoder.encode(address, "utf-8").replaceAll("\\+","%20")
        }

        var cityCode = parmMap.get("city")
        if(!StringUtils.isBlank(cityCode)){
          cityCode = URLEncoder.encode(cityCode, "utf-8").replaceAll("\\+","%20")
        }
        CommonUrl.zcModeUrl.format(cityCode,address, ak)
      }
    })
    return obj
  }

  def zcModeGrayTmp(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int,
                 extraMap:java.util.HashMap[String, String]): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("city","address","mobile")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        //        !StringUtils.isBlank(parmMap.get("address"))
        if(extraMap!=null && extraMap.containsKey("exitHour")){
          val hour = new Date().getHours
          val exitHourMin = extraMap.get("exitHourMin").toInt
          val exitHourMax = extraMap.get("exitHourMax").toInt
          if(hour >= exitHourMin && hour <= exitHourMax ){
            return false
          }
        }
        true
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        var address = parmMap.get("address")
        if(!StringUtils.isBlank(address)){
          address = URLEncoder.encode(address, "utf-8").replaceAll("\\+","%20")
        }

        var cityCode = parmMap.get("city")
        if(!StringUtils.isBlank(cityCode)){
          cityCode = URLEncoder.encode(cityCode, "utf-8").replaceAll("\\+","%20")
        }

        var mobile = parmMap.get("mobile")
        if(!StringUtils.isBlank(mobile)){
          mobile = URLEncoder.encode(mobile, "utf-8").replaceAll("\\+","%20")
        }
        CommonUrl.zcModeUrl_tmp.format(cityCode,address, ak,mobile)
      }
    })
    return obj
  }
  /**
   * seg切分地址，获取四级地址
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def segSplit(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.segSplitUrl.format(URLEncoder.encode(parmMap.get("address"),"UTF-8").replaceAll("\\+","%20"), ak)
      }
    })
    return obj
  }
  /**
   * 分词
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def splitApi(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGet(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address","cityCode")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address")) && !StringUtils.isBlank(parmMap.get("cityCode"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.splitUrl.format(URLEncoder.encode(parmMap.get("address"),"UTF-8").replaceAll("\\+","%20"),parmMap.get("cityCode"), ak)
      }
    })
    return obj
  }
  /**
   * 地址规范化
   *
   * @param ak
   * @param obj         数据体
   * @param keyMap      关键字映射
   * @param httpTimeout http超时时间
   * @return
   */
  def normlizeApi(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doGetStr(obj, keyMap.asJava, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonGet() {
      /**
       * 获取网址需要的参数在数据体中的名称数组
       *
       * @return
       */
      override def urlNeedKey(): Array[String] = {
        Array("address","citycode")
      }
      /**
       * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
       * 正确返回true,错误返回false
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("address"))
      }

      /**
       * 拼接最终网址
       *
       * @param parmMap 参数值映射
       * @return
       */
      override def createFinalUrl(parmMap: util.Map[String, String]): String = {
        CommonUrl.standardUrl.format(URLEncoder.encode(parmMap.get("address"),"UTF-8").replaceAll("\\+","%20"),parmMap.get("citycode"))
      }
    })
    return obj
  }
  def main(args: Array[String]): Unit = {
    println(Thread.currentThread.getStackTrace()(1).getMethodName)
    //    val dd = new JSONObject()
    //    dd.put("address","深圳市软件产业基地")
    //    dd.put("city","755")
    //    val keyMap=Map("address"->"address","citycode"->"city")
    //    val ff = rdsGeoSplitTestEnv("",dd,keyMap)
    //    println(ff.toJSONString)
  }
}
