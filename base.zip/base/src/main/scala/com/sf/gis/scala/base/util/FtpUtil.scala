package com.sf.gis.scala.base.util

import java.io.{BufferedReader, InputStreamReader}
import java.net.InetSocketAddress

import sun.net.ftp.FtpClient

import scala.collection.mutable.ArrayBuffer

object FtpUtil {
  /**
    * 连接FTP服务
    *
    * @param url      //IP地址
    * @param port     //端口号
    * @param username //用户名
    * @param password //密码
    * @return
    */
  def connectFtp(url:String,port:Int,username:String,password:String): FtpClient ={
    val address = new InetSocketAddress(url,port)
    val ftp = FtpClient.create()
    ftp.connect(address)
    ftp.login(username,password.toCharArray)
    ftp.setBinaryType()
    ftp
  }

  /**
    * 取ftp上的文件内容
    *
    * @param ftpFile
    * @param ftp
    * @return
    */
  def downLoad(ftpFile:String,ftp:FtpClient): ArrayBuffer[String] ={
    var arr:ArrayBuffer[String] = ArrayBuffer()
    var str = ""
    val is = ftp.getFileStream(ftpFile)
    val br = new BufferedReader(new InputStreamReader(is, "utf-8"))
    while (str != null){
      str = br.readLine()
      if(str != null){
        arr += str
      }
    }
    br.close()
    arr
  }
}