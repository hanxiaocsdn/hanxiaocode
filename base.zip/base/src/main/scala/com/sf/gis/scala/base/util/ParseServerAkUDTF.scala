package com.sf.gis.scala.base.util

import com.alibaba.fastjson.JSON
import com.sf.gis.scala.base.constants.ServerType
import org.apache.hadoop.hive.ql.exec.{UDFArgumentException, UDFArgumentLengthException}
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory
import org.apache.hadoop.hive.serde2.objectinspector.{ObjectInspector, ObjectInspectorFactory, StructObjectInspector}

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2024-01-02 20:27
 * @TaskId:
 * @TaskName:
 * @Description:
 */
class ParseServerAkUDTF extends GenericUDTF{
  override def initialize(argOIs: Array[ObjectInspector]): StructObjectInspector = {
    val fieldNames = new java.util.ArrayList[String]
    val fieldOIs = new java.util.ArrayList[ObjectInspector]
    fieldNames.add("ak")
    fieldNames.add("timeHour")
    //这里定义的是输出列字段类型
    fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector)
    fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector)
    ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs)
  }
  override def process(args: Array[AnyRef]): Unit = {
    val log = JSON.parseObject(args(0).toString)
    val dataType = args(1).toString
    val createTime = JSONUtil.getJsonValSingle(log,"createTime")
    val timeHour = createTime.substring(0,13)
    if(dataType.equals(ServerType.chkquery.name())){
      val message = log.getJSONObject("message")
      val dataType = message.getString("dataType")
      if("teamCodeBatchCotrollerArg".equals(dataType)){
        val requests = message.getJSONArray("requests")
        for(i<- 0 until requests.size()){
          val ak = requests.getJSONObject(i).getString("ak")
          val ret = Array(ak,timeHour)
          forward(ret)
          return
        }
      }else if("teamCodeCotrollerArgs".equals(dataType)){
        val requests = message.getJSONObject("request")
        val ak = requests.getString("ak");
        val ret = Array(ak,timeHour);
        forward(ret)
        return
      }
    }
    return
  }

  override def close(): Unit = {

  }
}
