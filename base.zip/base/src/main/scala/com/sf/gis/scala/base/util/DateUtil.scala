package com.sf.gis.scala.base.util

import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date, Objects}

import scala.collection.mutable.ArrayBuffer

object DateUtil {
  def getDate(size:Int): String ={
    getDate(size,"")
  }
  /**
   * 获取本机日历日期的字符串数字
   * @param size
   * @return
   */
  def getDateStr(size: Int, separator:String): String = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, size)
    val date = sdf.format(cal.getTime)
    date
  }
  /**
   * 时间戳毫秒转换为时分秒
   * @param timestamp
   * @return
   */
  def longToTime(timestamp:Long,format:String="yyyy-MM-dd HH:mm:ss SSS",duration:Long=0L): String ={
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp+duration))
    } catch {
      case e:Exception =>println(">>>时间戳解析异常:"+e)
    }
    datetime
  }
  /**
   * 时间戳秒转换为时分秒
   * @param timestamp
   * @return
   */
  def longToTimes(timestamp:Long,format:String="yyyy-MM-dd HH:mm:ss",duration:Long=0L): String ={
    var datetime = ""
    try {
      var sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp*1000+duration))
    } catch {
      case e:Exception =>println(">>>时间戳解析异常:"+e)
    }
    datetime
  }
  /**
   * 获取本机日历日期字符串，默认无分隔符
   * @param size
   * @return
   */
  def getDateStr(size: Int): String = {
    val incDay = getDateStr(size,"")
    incDay
  }



  /**
   * 获取昨日，无分隔符
   * @return
   */
  def getYesterday: String ={
    getDateStr(-1,"")
  }

  /**
   * 获取昨日
   * @param sep 分隔符
   * @return
   */
  def getYesterday(sep:String): String ={
    getDateStr(-1,sep)
  }

  /**
   * 获取今天，默认""分隔
   * @return
   */
  def getToday: String ={
    getDateStr(0,"")
  }

  /**
   * 获取今天
   * @param sep 日期分隔符
   * @return
   */
  def getToday(sep:String): String ={
    getDateStr(0,sep)
  }


  /**
   * 获取Date格式的相距天数为size的Date结果
   * @param inputDate
   * @param size
   * @return
   */
  def getDateNum(inputDate:Date,size:Int): Date ={
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, size)
    val outPutDate = tempDate.getTime
    outPutDate
  }

  /**
   * 获得两个字符串日期中所有日期的字符格式集合(左闭右开)
   * @param startDateStr
   * @param endDateStr
   * @return
   */
  def getTwoDatesStr(startDateStr: String, endDateStr: String,separator:String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      var startDate:Date = sdf.parse(startDateStr)
      var endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(getDateNum(startDate,-1), endDate)
      for(date <- dateList) dateListStr += (sdf.format(date))
    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }

  /**
   * 获得两个字符串日期中所有日期的字符格式集合(左闭右开)
   * @param startDateStr
   * @param endDateStr
   * @return
   */
  def getTwoDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
    getTwoDatesStr(startDateStr,endDateStr,"")
  }

  /**
   * 获取某天字符日期之前、后几天的日期字符串
   * @param inputDateStr 日期
   * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
   * @param separator 日期分隔符
   * @return
   */
  def getDateStr(inputDateStr:String, num:Int, separator:String): String ={
    val dateStrFormat = "yyyy"+separator+"MM"+separator+"dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    var inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

  /**
   * 改变日期的分隔符
   * @param inputdate 输入的日期
   * @param inputSep 输入日期的分隔符
   * @param outputSep 输出日期的分隔符
   * @return
   */
  def changeDateSep(inputdate:String, inputSep:String,outputSep:String): String ={
    val inputSdf = new SimpleDateFormat("yyyy"+inputSep+"MM"+inputSep+"dd")
    val inputFormatDate:Date = inputSdf.parse(inputdate)
    val outputSdf = new SimpleDateFormat("yyyy"+outputSep+"MM"+outputSep+"dd")
    val outPutDateStr = outputSdf.format(inputFormatDate)
    outPutDateStr
  }

  /**
   * 获取某天日期之后几天的日期字符串
   * @param inputDateStr 日期
   * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
   */
  def getDateStr(inputDateStr:String, num:Int): String ={
    getDateStr(inputDateStr,num,"")
  }


  /**
   * 获得两个Date格式日期之间的所有日期列表(左右开区间)
   *
   * @param start
   * @param end
   * @return
   */
  def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
    val result = new ArrayBuffer[Date]
    val tempStart = Calendar.getInstance
    tempStart.setTime(start)
    tempStart.add(Calendar.DAY_OF_YEAR, 1)
    val tempEnd = Calendar.getInstance
    tempEnd.setTime(end)
    while (tempStart.before(tempEnd)) {
      result += (tempStart.getTime)
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    result
  }

  /**
   * 获取本机日历日期
   *
   * @param delta
   * @return
   */
  def dateDelta(delta: Int): String = {
    dateDelta(delta,"-")
  }

  /**
   * 获取本机日历日期
   *
   * @param delta
   * @return
   */
  def dateDelta(delta: Int,separator:String): String = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }
  /**
   * 日期转时间戳
   *
   * @param s
   * @return
   */
  def dateToStamp(s: String,formate:String = "yyyyMMdd HHmmss"): Long = {
    var ts : Long = -1
    val simpleDateFormat = new SimpleDateFormat(formate)
    try{
      val date = simpleDateFormat.parse(s)
      ts = date.getTime
    }catch {
      case e : Exception =>
    }
    ts
  }
  /**
   * 获取某天日期之后几天的日期字符串
   * @param inputDateStr 日期
   * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
   * @param separator 日期分隔符
   * @return
   */
  def getDay(inputDateStr:String, num:Int,separator:String): String ={
    val dateStrFormat = "yyyy"+separator+"MM"+separator+"dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    val inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }
  /**
   * 获取本机日历日期的字符串数字
   * @param size
   * @return
   */
  def getDate(size: Int, separator:String): String = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, size)
    val date = sdf.format(cal.getTime)
    date
  }
  /**
   * 获取历史每个月的第一天
   * @param size
   * @return
   */
  def getLastMonthFirst(size: Int, separator:String) ={
    var period:String=""
    var cal:Calendar =Calendar.getInstance();
    var df:SimpleDateFormat = new SimpleDateFormat("yyyyMMdd");
    cal.add(Calendar.MONTH, -size)
    cal.set(Calendar.DATE, 1)
    period=df.format(cal.getTime())
    period
  }
  /**
   * 获取前几个小时时间
   * @param num
   * @return
   */
  def getHourStr(inputDateStr:String, num:Int, separator:String): String ={
    val dateStrFormat = "yyyy"+separator+"MM"+separator+"dd"+separator+"HH"
    val sdf = new SimpleDateFormat(dateStrFormat)
    var inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.HOUR_OF_DAY, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }
  /**
   * 获取前几分钟时间
   * @param num
   * @return
   */
  def getMinuteStr(inputDateStr:String, num:Int): String ={
    val dateStrFormat = "yyyy-MM-dd HH:mm:ss"
    val sdf = new SimpleDateFormat(dateStrFormat)
    val inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.MINUTE, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

  def getWeek(date:String ) ={
    val sdf = new SimpleDateFormat("yyyyMMdd")
    var inputDate:Date = sdf.parse(date)
    val  weeks = Array("7","1" ,"2","3","4","5","6")
    val  cal = Calendar.getInstance()
    cal.setTime(inputDate)
    var  week_index = cal.get(Calendar.DAY_OF_WEEK) - 1
    if(week_index<0){
      week_index = 0
    }
    weeks(week_index)
  }

  /**
   * Get week info by date String
   *
   * @return 星期信息
   */
  def getWeekOfDateChinese(date:String ) ={
    val sdf = new SimpleDateFormat("yyyyMMdd")
    var inputDate:Date = sdf.parse(date)
    val  weeks = Array("周日", "周一", "周二", "周三", "周四", "周五", "周六")
    val  cal = Calendar.getInstance()
    cal.setTime(inputDate)
    var  week_index = cal.get(Calendar.DAY_OF_WEEK) - 1
    if(week_index<0){
      week_index = 0
    }
    weeks(week_index)
  }
  def getMonthDate(year:String, i: String): (String, String) = {
    var startDate = ""
    var endDate = ""
    var year_month = ""
    if(i.length == 1) year_month = year + "0" + i
    else year_month = year + i
    startDate = year_month + "01"
    val format = new SimpleDateFormat("yyyyMMdd")
    val calendar = Calendar.getInstance()
    calendar.setTime(format.parse(startDate))
    calendar.add(Calendar.MONTH, 1)
    calendar.add(Calendar.DAY_OF_MONTH, -1)
    endDate = format.format(calendar.getTime)

    (startDate, endDate)
  }

  def converDayToChinese(date:String): String ={
    val year = date.substring(0,4)
    val month = date.substring(4,6)
    val day =date.substring(6,8)
    return year+"年"+month+"月"+day+"日"
  }

  def daysDiff(fromDay:String,endDay:String) ={
    val from = fromDay.replaceAll("-","")
    val to = endDay.replaceAll("-","")
    var t = from
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)

    t = to
    val endtm = Calendar.getInstance()
    endtm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)

    val millis = endtm.getTimeInMillis - begintm.getTimeInMillis
    millis / 24 / 60 / 60 / 1000
  }
  def tranTstampToTime(colValue: String): String = {
    val sdf3 = new SimpleDateFormat("yyyyMMddHHmmss")
    var time = "0"
    try {
      time = sdf3.format(new Date(colValue.toLong * 1000))
    } catch {
      case e: Exception =>
    }
    time
  }


  def getMonthStr(inputDateStr: String, num: Int, separator: String): String = {
    val dateStrFormat = "yyyy" + separator + "MM" + separator + "dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    var inputDate: Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.MONTH, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

  /**
   * 获取月的第一天跟最后一天
   * num：负数 往前num个月 正数 往后num个月
   *
   * @param size
   * @return
   */

  def getMonthBEStr(inputDateStr: String, num: Int, separator: String) = {
    val dateStrFormat = "yyyy" + separator + "MM" + separator + "dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    var inputDate: Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.MONTH, num)
    tempDate.set(Calendar.DAY_OF_MONTH, tempDate.getActualMinimum(Calendar.DAY_OF_MONTH))
    val outFirstPutDate = tempDate.getTime
    val firstDateStr = sdf.format(outFirstPutDate)
    tempDate.set(Calendar.DAY_OF_MONTH, tempDate.getActualMaximum(Calendar.DAY_OF_MONTH))
    val outEndPutDate = tempDate.getTime
    val endDateStr = sdf.format(outEndPutDate)
    (firstDateStr, endDateStr)
  }

  def main(args: Array[String]): Unit = {
    //println(DateUtil.getDateStr(-2))
    println(DateUtil.getLastMonthFirst(1,""))
  }
}
