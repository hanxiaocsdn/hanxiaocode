package com.sf.gis.scala.base.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import com.sf.gis.scala.base.constants.HttpExceptionType;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import java.io.*;
import java.net.*;
import java.nio.charset.Charset;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

/**
 * Created by 01374443 on 2021/4/2.
 */
public class HttpUtils {
    static Logger logger = Logger.getLogger(HttpUtils.class.getName());

//    /**
//     * 休眠机制
//     *
//     * @param count
//     * @param url
//     * @param e
//     * @throws Exception
//     */
//    private static void sleep(int count, String url, Exception e) throws Exception {
//        try {
//            if (count == 0) {
//                logger.error(url + "," + e.getMessage());
//                throw new Exception(e.getMessage());
//            } else if (count == 1) {
//                Thread.sleep(500);
//            } else if (count == 2) {
//                Thread.sleep(250);
//            } else if (count == 3) {
//                Thread.sleep(125);
//            }
//        } catch (InterruptedException e1) {
//        }
//    }

    /**
     * UrlConnection Get JSON
     *
     * @param url
     * @param retryTime
     * @param httpTimeout
     * @return
     * @throws Exception
     */
    public static JSONObject urlConnectionGetJson(String url, Integer httpTimeout) throws Exception {
        HttpURLConnection httpConnection = null;
        String retStr = null;
        try {
            URL urlGet = new URL(url);

            httpConnection = (HttpURLConnection) urlGet.openConnection();
            httpConnection.setRequestMethod("GET");
            // 设置是否向HttpURLConnection输出
            httpConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//            httpConnection.setDoOutput(false);
//            httpConnection.setDoInput(true);
            httpConnection.setConnectTimeout(httpTimeout);
            httpConnection.setReadTimeout(httpTimeout);
            // 设置是否使用缓存
            httpConnection.setUseCaches(true);
            // 设置此 HttpURLConnection 实例是否应该自动执行 HTTP 重定向
            httpConnection.setInstanceFollowRedirects(true);

            httpConnection.connect();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(httpConnection.getInputStream(),"utf-8"));
            ) {
                StringBuffer sb = new StringBuffer();
                String line = null;
                while ((line = reader.readLine()) != null) { // 循环从流中读取
                    sb.append(line);
                }
                retStr = sb.toString();
            }
        } catch (Exception e) {
            throw new Exception(HttpExceptionType.retry.name() + "--" + e.getMessage());
        } finally {
            if (httpConnection != null) {
                httpConnection.disconnect();
            }
        }
        if (retStr != null) {
            return JSON.parseObject(retStr);
        } else {
            return null;
        }

    }

    /**
     * UrlConnection Get 字符串
     *
     * @param url
     * @param retryTime
     * @return
     * @throws Exception
     */
    public static String urlConnectionGetStr(String url, Integer httpTimeout) throws Exception {
        HttpURLConnection httpConnection = null;
        try {
            URL urlGet = new URL(url);

            httpConnection = (HttpURLConnection) urlGet.openConnection();
            httpConnection.setRequestMethod("GET");
            // 设置是否向HttpURLConnection输出
            httpConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//            httpConnection.setDoOutput(false);
//            httpConnection.setDoInput(true);
            httpConnection.setConnectTimeout(httpTimeout);
            httpConnection.setReadTimeout(httpTimeout);
            // 设置是否使用缓存
            httpConnection.setUseCaches(true);
            // 设置此 HttpURLConnection 实例是否应该自动执行 HTTP 重定向
            httpConnection.setInstanceFollowRedirects(true);
            httpConnection.connect();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(httpConnection.getInputStream(),"utf-8"));
            ) {
                StringBuffer sb = new StringBuffer();
                String line = null;
                while ((line = reader.readLine()) != null) { // 循环从流中读取
                    sb.append(line);
                }
                return sb.toString();
            }
        } catch (Exception e) {
            throw new Exception(HttpExceptionType.retry.name() + "--" + e.getMessage());
        } finally {
            if (httpConnection != null) {
                httpConnection.disconnect();
            }
        }
    }

    /**
     * UrlConnection post获取JSON
     *
     * @param url
     * @param retryTime
     * @param httpTimeout
     * @return
     * @throws Exception
     */
    public static JSONObject urlConnectionPostJson(String url, String body, Integer httpTimeout) throws Exception {
        HttpURLConnection httpConnection = null;
        String retStr = null;
        try {
            URL urlGet = new URL(url);
            httpConnection = (HttpURLConnection) urlGet.openConnection();
            httpConnection.setRequestMethod("POST");
            // 设置是否向HttpURLConnection输出
            httpConnection.setRequestProperty("Content-Type", "application/json");
            httpConnection.setDoOutput(true);
            httpConnection.setDoInput(true);
            httpConnection.setConnectTimeout(httpTimeout);
            httpConnection.setReadTimeout(httpTimeout);
            // 设置是否使用缓存
            httpConnection.setUseCaches(true);
            // 设置此 HttpURLConnection 实例是否应该自动执行 HTTP 重定向
            httpConnection.setInstanceFollowRedirects(true);
//            httpConnection.connect();
            try ( // 获取URLConnection对象对应的输出流
                  PrintWriter out = new PrintWriter(new OutputStreamWriter(httpConnection.getOutputStream(), "utf-8"));) {
                // 发送请求参数
                out.print(body);
                // flush输出流的缓冲
                out.flush();
            }

            try (
                // 获取URLConnection对象对应的输出流
                PrintWriter out = new PrintWriter(new OutputStreamWriter(httpConnection.getOutputStream(), "utf-8"));

                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(httpConnection.getInputStream(), "utf-8"));
            ) {
                StringBuffer sb = new StringBuffer();
                String line = null;
                while ((line = reader.readLine()) != null) { // 循环从流中读取
                    sb.append(line);
                }
                retStr = sb.toString();
            }
        } catch (Exception e) {
            throw new Exception(HttpExceptionType.retry.name() + "--" + e.getMessage());
        } finally {
            if (httpConnection != null) {
                httpConnection.disconnect();
            }
        }
        if(retStr != null){
            return JSON.parseObject(retStr);
        }else{
            return null;
        }
    }
    /**
     * 发送post请求
     *
     * @param url      路径
     * @param json     参数(json类型)
     * @param encoding 编码格式
     * @return
     * @throws ParseException
     * @throws IOException
     */
    public static String post(String url, JSON json, String encoding) throws ParseException, IOException {
        String body = "";
        try(
                //创建httpclient对象
                CloseableHttpClient client = HttpClients.createDefault();
        ){

            //创建post方式请求对象
            HttpPost httpPost = new HttpPost(url);

            //装填参数
            StringEntity s = new StringEntity(json.toString(), "utf-8");
            s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,
                    "application/json"));
            //设置参数到请求对象中
            httpPost.setEntity(s);
            //System.out.println("请求地址："+url);

            //设置header信息
            //指定报文头【Content-type】、【User-Agent】
            httpPost.setHeader("Content-type", "application/json");
            httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");

            //执行请求操作，并拿到结果（同步阻塞）
            CloseableHttpResponse response = client.execute(httpPost);
            //获取结果实体
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                //按指定编码转换结果实体为String类型
                body = EntityUtils.toString(entity, encoding);
            }
            EntityUtils.consume(entity);
            //释放链接
            response.close();
        }

        return body;
    }
    public static String postForm(String url, Map<String,String> map, String encoding) throws ParseException, IOException{
        String body = "";
        //创建httpclient对象
        CloseableHttpClient client = HttpClients.createDefault();
        //创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);

        List<BasicNameValuePair> nvps = new ArrayList<BasicNameValuePair>();
        if(map!=null){
            for (Map.Entry<String, String> entry : map.entrySet()) {
                nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
        }
        //设置参数到请求对象中
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, encoding));

        //设置连接超时时间 为3秒
        RequestConfig config = RequestConfig.custom().setConnectTimeout(2000000).setConnectionRequestTimeout(2000000).setSocketTimeout(2000000).build();
        httpPost.setConfig(config);

        //执行请求操作，并拿到结果（同步阻塞）
        CloseableHttpResponse response = client.execute(httpPost);
        //获取结果实体
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            //按指定编码转换结果实体为String类型
            body = EntityUtils.toString(entity, encoding);
        }
        EntityUtils.consume(entity);
        //释放链接
        response.close();
        return body;
    }
    public static String postFormWithTimeOut(String url, Map<String,String> map, String encoding,Integer timeOut) throws ParseException, IOException{
        String body = "";
        //创建httpclient对象
        CloseableHttpClient client = HttpClients.createDefault();
        //创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);

        List<BasicNameValuePair> nvps = new ArrayList<BasicNameValuePair>();
        if(map!=null){
            for (Map.Entry<String, String> entry : map.entrySet()) {
                nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
        }
        //设置参数到请求对象中
        httpPost.setEntity(new UrlEncodedFormEntity(nvps, encoding));

        //设置连接超时时间 为3秒
        RequestConfig config = RequestConfig.custom().setConnectTimeout(timeOut).setConnectionRequestTimeout(timeOut).setSocketTimeout(timeOut).build();
        httpPost.setConfig(config);

        //执行请求操作，并拿到结果（同步阻塞）
        CloseableHttpResponse response = client.execute(httpPost);
        //获取结果实体
        HttpEntity entity = response.getEntity();
        if (entity != null) {
            //按指定编码转换结果实体为String类型
            body = EntityUtils.toString(entity, encoding);
        }
        EntityUtils.consume(entity);
        //释放链接
        response.close();
        return body;
    }
    /**
     * This method is used to get all ip addresses from the network interfaces.
     * network interfaces: eth0, wlan0, l0, vmnet1, vmnet8
     */
    public static ArrayList getAllIpAddress() {
        ArrayList  ipList = new ArrayList();
        try {
            //get all network interface
            Enumeration<NetworkInterface> allNetworkInterfaces =
                    NetworkInterface.getNetworkInterfaces();
            NetworkInterface networkInterface = null;

            //check if there are more than one network interface
            while (allNetworkInterfaces.hasMoreElements()) {
                //get next network interface
                networkInterface = allNetworkInterfaces.nextElement();
                //output interface's name
                System.out.println("network interface: " +
                        networkInterface.getDisplayName());

                //get all ip address that bound to this network interface
                Enumeration<InetAddress> allInetAddress =
                        networkInterface.getInetAddresses();

                InetAddress ipAddress = null;

                //check if there are more than one ip addresses
                //band to one network interface
                while (allInetAddress.hasMoreElements()) {
                    //get next ip address
                    ipAddress = allInetAddress.nextElement();
                    if (ipAddress != null && ipAddress instanceof Inet4Address) {
                        ipList.add(ipAddress.getHostAddress());
                    }
                }
            }

        } catch (SocketException e) {
            e.printStackTrace();
        }
        return ipList;
    }//end method getAllIpAddress
    /**
     * get http request content
     * @param url url
     * @return http get request response content
     */
    public static String postJson(String url, JSONObject parameters,Map<String,String> headParm){
        CloseableHttpClient httpclient = HttpClients.createDefault();
        HttpPost httpPost = new HttpPost(url);
        httpPost.addHeader("Content-type", "application/json");
        httpPost.setHeader("Accept", "application/json");
        httpPost.setEntity(new StringEntity(parameters.toString(), Charset.forName("UTF-8")));

        if(headParm!=null){
            for(Map.Entry<String,String> entrySet : headParm.entrySet()){
                httpPost.addHeader(entrySet.getKey(),entrySet.getValue());
            }
        }
        /** set timeout、request time、socket timeout */
        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(60 * 1000)
                .setConnectionRequestTimeout(60 * 1000)
                .setSocketTimeout(60 * 1000)
                .setRedirectsEnabled(true)
                .build();
        httpPost.setConfig(requestConfig);
        String responseContent = null;
        CloseableHttpResponse response = null;

        try {
            response = httpclient.execute(httpPost);
            //check response status is 200
            if (response.getStatusLine().getStatusCode() == 200) {
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    responseContent = EntityUtils.toString(entity, "UTF-8");
                }else{
                    logger.warn("http entity is null");
                }
            }else{
                logger.error("http get:"+response.getStatusLine().getStatusCode()+" response status code is not 200!");
            }
        }catch (Exception e){
            logger.error(e.getMessage(),e);
        }finally {
            try {
                if (response != null) {
                    EntityUtils.consume(response.getEntity());
                    response.close();
                }
            } catch (IOException e) {
                logger.error(e.getMessage(),e);
            }

            if (!httpPost.isAborted()) {
                httpPost.releaseConnection();
                httpPost.abort();
            }

            try {
                httpclient.close();
            } catch (IOException e) {
                logger.error(e.getMessage(),e);
            }
        }
        return responseContent;
    }
}
