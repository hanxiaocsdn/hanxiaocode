
package com.sf.gis.scala.base.constants;

public class CommonUrl {
    //地理编码
    //调用地理编码mapa服务，类型：ma1
    public static String mapAUrl = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=ma1&ak=%s";
    //调用地理编码图商服务，类型：高德
    public static String tsGdUrl = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=gd2&ak=%s";
    public static String tsUrl = "http://gis-int.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=%s&ak=%s";
    //调用效果测试的geo服务，获取切词，服务下午5点后不定时更新，短时间可用，只包含一个城市的索引，不可用于索引大组等相关数据
    public static String geoSplitUrl = "http://10.119.72.210:8082/atdispatch/api?address=%s&city=%s&ak=%s&opt=normdetail&geoType=5678-1011980249";
    //com.sf.gis.rds
    //rds派件容灾 综合
    public static String rdsRzPaiZhUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&opt=zh&ak=%s";
    //rds派件容灾 normdetail
    public static String rdsRzPaiNormDetailUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&opt=norm&ak=%s";
    //rds派件容灾 norm
    public static String rdsRzPaiNormUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&opt=normDetail&ak=%s";

    public static String suyunbatchXyToAoi="http://sds-core-datarun.sf-express.com/datarun/track/getTrackAois?showAoiCode=1&buffRange=30";


    //dept2，坐标获取网点，aoi等
    //坐标获取网点，aoi post方法
    public static String xyToAoiZc = "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/coord";
    //aoiid获取aoi信息
    public static String aoiIdInfo = "http://gis-apis.int.sfcloud.local:1080/dept2/zctc/aoiid?aoi_id=%s&ak=%s&opt=area";
    //坐标获取aoi信息
    public static String aoiInfoDataAoi2 = "http://gis-apis.int.sfcloud.local:1080/dept/byxy?x=%s&y=%s&opt=aoi2&geom=0&ak=%s";


    public static String aoiInfoDept2 = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&geom=0&ak=%s";


    public static String aoiInfoDataAoitype = "http://gis-apis.int.sfcloud.local:1080/dept/byxy?x=%s&y=%s&opt=aoitype&geom=0&ak=%s";
    public static String trackAoiUrl="http://sds-core-datarun.sf-express.com/datarun/track/getTrackAois?showAoiCode=1&buffRange=0";
    public static String batchXyToAoi="http://sds-core-datarun.sf-express.com/datarun/track/getCoorAoiDist?dist=0";
    public static String batchXyToAoi2="http://sds-core-datarun.int.sfcloud.local/datarun/track/getTrackAois?showAoiCode=1";
    //坐标周围范围内的aoi，以及到中心的距离
    public static String xyAroundAoiCenterDisUrl = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorGeomAoiBase?x=%s&y=%s&radius=%s&typeDist=center";
    //楼栋
    public static String buildingIdUrl = "http://gis-int.int.sfdc.com.cn:1080/building/address/identify?address=%s&cityCode=%s&ak=%s";

    //地址可达获取四级地址
    public static String addReachUrl = "http://gis-int.int.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&ak=%s&extention=0&datatype=r01&opt=";
    public static String addReachUrlGray = "http://gis-int.int.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&extention=1&opt=&ak=%s";
    public static String addReacheUrlTest = "http://gis-int.intsit.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&extention=1&opt=&ak=%s";
    //客诉ZC模型 灰度接口
    public static String zcModeUrl = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getTeam?city=%s&address=%s&ak=%s&ks15Contain=true&isNotUnderCall=0&src=chk_dispatch";
    public static String zcModeUrl_tmp = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getTeam?city=%s&address=%s&ak=%s&mobile=%s";
    //seg切词，获取四级地址
    public static String segSplitUrl = "http://gis-int.int.sfdc.com.cn:1080/seg/api/split?address=%s&ak=%s";
    //分词服务
    public static String splitUrl = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=%s";
    //规范化
//    public static String standardUrl="http://10.119.82.208:8096/rule?address=%s";
    public static String standardUrl="http://10.117.0.13:8096/checkrule?address=%s&city=%s&ruleid=";
    //德邦相关接口
    //获取AOI与德邦多边形面积相交占比
    public static String deponZcIntersectAoiUrl="http://gis-int2.int.sfdc.com.cn:1080/eds/area/query?zc=%s&aoi=%s&ak=%s";

    //快运相关接口 和 顺心貌似重叠
    //顺心相关接口 坐标获取顺心网点
    public static String xyToSxInfo="http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?lng=%s&lat=%s&ak=%s&sys_type=SX";
    //地址获取顺心网点
    public static String addrToSxInfo="http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data/?address=%s&ak=%s&sys_type=SX&showserver=true";
    //地址获取顺心网点
    public static String addrToSxInfoV4="http://gis-apis.int.sfcloud.local:1080/sx/v4/api?address=%s&ak=%s";

    //cms
    //获取四级地址
    public static String cmsAoiTown="http://gis-ass-dqs.sf-express.com/emap/api/efs/getDtsByAois?aoiId=%s&hasGeom=false";

}
