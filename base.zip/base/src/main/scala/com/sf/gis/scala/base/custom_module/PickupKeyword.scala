package com.sf.gis.scala.base.custom_module

import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.KeyInfo
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.spark.rdd.RDD

object PickupKeyword {
  /**
   * 根据分词提取主体词
   * @param data 数据体
   * @param splitKeyName 分词字段名
   * @return
   */
  def pickupKeyword(data: RDD[JSONObject], splitKeyName: String): RDD[JSONObject] = {
    data.map(obj => {
      val keyInfo = parseAddress(JSONUtil.getJsonValSingle(obj, splitKeyName))
      obj.put("key_tag", keyInfo.get("key_tag"))
      obj.put("key_level", keyInfo.get("key_level"))
      obj.put("key_word", keyInfo.get("key_word"))
      obj.put("key_13", keyInfo.get("key_13"))
      obj.put("key_levels", keyInfo.get("key_levels"))
      obj
    })
  }


  def parseAddress(splitInfo: String): util.Map[String, String] = {
    var uselessIndex = splitInfo.indexOf(";")
    var validSplit = splitInfo
    if (uselessIndex > 0) {
      validSplit = validSplit.substring(0, uselessIndex)
    }
    val keyInfo = new KeyInfo(validSplit)
    keyInfo.pick_key
  }

  def main(args: Array[String]): Unit = {
    val map = parseAddress("广东省^11,深圳市软件产业基地^213;13")
    println(map)
  }
}
