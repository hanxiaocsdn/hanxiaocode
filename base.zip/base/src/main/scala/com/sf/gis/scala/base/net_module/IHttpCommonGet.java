package com.sf.gis.scala.base.net_module;

import java.util.Map;

public interface IHttpCommonGet {
    /**
     * 获取网址需要的参数在数据体中的名称数组
     * @return
     */
    public String[] urlNeedKey();

    /**
     * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
     * 正确返回true,错误返回false
     * @param parmMap 参数值映射
     * @return
     */
    public boolean checkParm(Map<String, String> parmMap);

    /**
     * 拼接最终网址
     * @param parmMap 参数值映射
     * @return
     */
    public String createFinalUrl(Map<String, String> parmMap);

}
