package com.sf.gis.scala.base.util

import com.sf.gis.java.base.util.DistanceUtils.getDistance
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object Functions {

  // 获取起点与终点的距离
  def getDist: UserDefinedFunction = udf((startx: String, starty: String, start_srcx_dept: String, start_srcy_dept: String) => {
    var dist: Double = 0.0
    try {
      dist = getDistance(startx.toDouble, starty.toDouble, start_srcx_dept.toDouble, start_srcy_dept.toDouble)
    } catch {
      case e: Exception => println("经纬度异常" + e.getMessage)
    }
    dist
  })

}
