package com.sf.gis.java.base.util;

import com.sf.gis.java.base.dto.KeyInfo;
import jodd.util.StringUtil;
import org.apache.commons.lang.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 地址工具类
 * @author 01370539 created on Aug.12 2021
 */
public class AddrUtil {

    private static final String falseKeyPattern = "^[\\d]+[号]?信箱$";
    private static final String[] falseKeyArr = {"邮政","邮政局","邮政所","邮政快递","中国邮政","邮政代办所","邮政储蓄银行","中心学校","中心小学","人民医院","中心医院","民政局","农业农村局","农行","农业银行","中国农业银行","快递超市"};
    private static final Map<String, Integer> falseKeyMap = new HashMap<String, Integer>();
    static {
        for (String falseKey : falseKeyArr) {
            falseKeyMap.put(falseKey, 1);
        }
    }

    /**
     * 中文转换为数字，大写字母转化为小写字母
     * @param param 地址
     * @return 中文转换为数字，大写字母转化为小写字母
     */
    public static String transferNumber(String param) {
        if(StringUtil.isEmpty(param)) {
            return "";
        }
        return param.replaceAll("零","0").replaceAll("一","1").replaceAll("二","2").replaceAll("三","3")
                .replaceAll("四","4").replaceAll("五","5").replaceAll("六","6").replaceAll("七","7")
                .replaceAll("八","8").replaceAll("九","9").toLowerCase();
    }

    public static String getKey(String addrSplit) {
        if (StringUtils.isNotEmpty(addrSplit)) {
            com.sf.KeyInfo key = new com.sf.KeyInfo(addrSplit.split(";")[0]);
            Map<String, String> keyMap = key.pick_key();
            if (keyMap != null) {
                return transferNumber(keyMap.get("key_word"));
            }
        }
        return addrSplit;
    }

    public static KeyInfo getKeyInfo(String addrSplit) {
        KeyInfo keyInfo = new KeyInfo();
        if (StringUtils.isNotEmpty(addrSplit)) {
            com.sf.KeyInfo key = new com.sf.KeyInfo(addrSplit.split(";")[0]);
            Map<String, String> keyMap = key.pick_key();
            if (keyMap != null) {
                keyInfo.setKey(transferNumber(keyMap.get("key_word")));
                keyInfo.setKeyLevel(keyMap.get("key_levels"));
            }
        }
        return keyInfo;
    }

    /**
     * 提取地址中符合正则的字符
     * @param str
     * @param regex
     * @return
     */
    public static String getMatch(String str, String regex) {
        StringBuilder sb = new StringBuilder();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        while (matcher.find()) {
            sb.append(matcher.group());
        }
        return sb.toString();
    }

    public static String processKey(String key, String village) {
        if (StringUtils.isEmpty(key)) {
            return key;
        }
        String[] keyArr = key.split(";");
        Map<String, Integer> keyMap = new HashMap<>();
        boolean isUse;
        for (String tmpKey : keyArr) {
            isUse = true;
            if (falseKeyMap.get(tmpKey) != null || (StringUtils.isNotEmpty(village) && tmpKey.equals(village))) {
                isUse = false;
            } else if (tmpKey.matches(falseKeyPattern)) {
                isUse = false;
            }
            if (isUse) {
                keyMap.put(tmpKey, 1);
            }
        }
        String result = "";
        for (String tmpKey : keyMap.keySet()) {
            if (StringUtils.isNotEmpty(result)) {
                result += ";";
            }
            result += tmpKey;
        }
        return result;
    }
}
