package com.sf.gis.java.base.dto;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

/**
 * spark信息
 * @author 01370539 Created on Apr.30 2021
 */
public class SparkInfo {
	private SparkConf conf;
	private SparkSession session;
	private JavaSparkContext context;

	public SparkConf getConf() {
		return conf;
	}

	public void setConf(SparkConf conf) {
		this.conf = conf;
	}

	public SparkSession getSession() {
		return session;
	}

	public void setSession(SparkSession session) {
		this.session = session;
	}

	public JavaSparkContext getContext() {
		return context;
	}

	public void setContext(JavaSparkContext context) {
		this.context = context;
	}

}
