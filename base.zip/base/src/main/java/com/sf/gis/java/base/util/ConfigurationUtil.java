package com.sf.gis.java.base.util;

import com.csvreader.CsvReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.*;


public class ConfigurationUtil {
    private static Logger logger = LoggerFactory.getLogger(ConfigurationUtil.class);

    public static List<String> loadFileByConf(String fileName) {
        return loadFileByConf(fileName, "UTF-8");
    }

    public static List<String> loadFileByConf(String fileName, String charset) {
        List<String> list = new ArrayList<>();
        try (InputStreamReader in = new InputStreamReader(ConfigurationUtil.class.getClassLoader().getResourceAsStream(File.separator + "conf/" + fileName), charset)) {
            BufferedReader br = new BufferedReader(in);
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
            br.close();
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return list;
    }

    public static Properties loadPropertiesByConf(String fileName) {
        return loadPropertiesByConf(fileName, "UTF-8");
    }

    public static Properties loadPropertiesByConf(String fileName, String charset) {
        Properties props = null;
        try (InputStreamReader in = new InputStreamReader(new FileInputStream(System.getProperty("user.dir") + "/conf/" + fileName), charset)) {
            props = new Properties();
            props.load(in);
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return props;
    }

    public static Properties loadProperties2(String fileName, String charset) {
        logger.error("filename:{}", fileName);
        Properties props = null;
        try (InputStreamReader in = new InputStreamReader(ConfigurationUtil.class.getClassLoader().getResourceAsStream(fileName), charset)) {
            props = new Properties();
            props.load(in);
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return props;
    }

    public static Properties loadProperties3(String fileName, String charset) {
        logger.error("filename:{}", fileName);
        Properties props = null;
        try (InputStreamReader in = new InputStreamReader(ConfigurationUtil.class.getClassLoader().getResourceAsStream(fileName), charset)) {
            props = new Properties();
            props.load(in);
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return props;
    }

    public static Properties loadProperties2(String fileName) {
        return loadProperties2(fileName, "UTF-8");
    }

    public static Properties loadProperties(String fileName, String charset) {
        Properties props = null;
        try (InputStreamReader in = new InputStreamReader(new FileInputStream(System.getProperty("user.dir") + "/conf/" + fileName), charset)) {
            props = new Properties();
            props.load(in);
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return props;
    }

    public static Properties loadProperties(String fileName) {
        return loadProperties(fileName, "UTF-8");
    }

    public static Map<String, String> loadMap(String filename, String key, String value) {
        return loadMap(filename, key.toUpperCase(), value.toUpperCase(), "UTF-8");
    }

    public static Map<String, String> loadMap(String filename, String key, String value, String charset) {
        Map<String, String> map = new HashMap<>();
        try (InputStreamReader in = new InputStreamReader(ConfigurationUtil.class.getClassLoader().getResourceAsStream(File.separator + "conf/" + filename), charset)) {
            CsvReader csvReader = new CsvReader(in, ',');
            csvReader.setSafetySwitch(false);
            csvReader.readHeaders();
            while (csvReader.readRecord()) {
                map.put(csvReader.get(key), csvReader.get(value));
            }
            csvReader.close();
            logger.error("cityinfo size {}", map.size());
        } catch (Exception e) {
            logger.error("load citycode error.", e);
        }
        return map;
    }
}
