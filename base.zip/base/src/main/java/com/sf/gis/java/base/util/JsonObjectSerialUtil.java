package com.sf.gis.java.base.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;

/**
 * Json序列化
 * @author 01370539 Created On: May.07 2021
 */
public class JsonObjectSerialUtil {
	private static final Logger logger = LoggerFactory.getLogger(JsonObjectSerialUtil.class);

    /**
     * Object to Json String
     * @param sourceObject 需要转化为json字符串的对象
     * @return 转化后的结果
     */
	public static String getStringFromObject(Object sourceObject) {
		String jsonStr = null;
		try {
			if (sourceObject != null) {
				jsonStr = JSON.toJSONString(sourceObject);
			}
		} catch (Exception e) {
			logger.error("Ojbejct Serial Error! ", e);
			return null;
		}
		return jsonStr;
	}

    /**
     * Json String to Object
     * @param jsonStr json
     * @param c 期望转换成的对象类
     * @param <T> 期望转换成的对象
     * @return 转换后的结果
     */
	public static <T> T getObjectFromString(String jsonStr, Class<T> c) {
		T rtnObject;
		try {
			jsonStr = jsonStr.replace("\\", "");
			rtnObject = JSON.parseObject(jsonStr, c);
		} catch (Exception e) {
			logger.error("Ojbejct Serial Error! jsonStr - " + jsonStr, e);
			return null;
		}

		return rtnObject;
	}

}
