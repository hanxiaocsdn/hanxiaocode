package com.sf.gis.java.base.constant;

/**
 * 所有工程通用的，通过各个工程改变的系统级的可变常量
 * @author 01370539 Created on Apr.30 2021
 */
public class SysConstant {

    // 分区数量，根据动态设置参数自动计算得到
    public static int PARTITION_COUNT = 16;
    public static int THREAD_COUNT = 16;

    public static int PARALLELISM_HBASE = 50;
    public static int PARALLELISM_REDIS = 50;
    public static int PARALLELISM_FTP = 50;
}
