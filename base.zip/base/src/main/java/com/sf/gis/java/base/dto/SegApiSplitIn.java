package com.sf.gis.java.base.dto;

public class SegApiSplitIn {
    private String ak = "";  // 必填项。授权ak
    private String province = "";  // 非必填。中文省份名称，如“广东省
    private String citycode = "";  // 非必填。城市代码，如“755”
    private String city = "";  // 非必填。中文城市名称，如“深圳市”
    private String county = "";  // 非必填。中文区县名称，如“南山区”
    private String town = "";  // 非必填。中文乡镇街道名称，如“粤海街道”
    private String address = "";  // 必填。地址
    private String level = "";  // 非必填。要返回的地址级别：level=4（默认值），则返回4级地址：省市区街道 level=3，则返回3级地址：省市区
    private String origin = "";  // 非必填。等于town时，意思是根据addresstext 是否包含街道信息，决定是否返回town。如无此需求，建议不传此参数，即默认返回town
    private String compare = "";  // 非必填。对比传入的省市区与服务返回的结果是否一致，对应返参result字段，现在传入compare=1 和不传入都会比较
    private String orderno = "";  // 非必填。调用方系统生成的唯一标识，建议传入此参数，以供出现问题时可快速在日志中定位
    private String showcode = ""; // 非必填。等于1时，显示provinceCode，cityLevCode，countyCode，townCode
    private String la = ""; // 非必填。种识别标记（当前主要应用与港澳台业务，用户前端登录时会选择语种，由前端传参给服务）；=cht时，输出繁体三级行政区划；=en时，输出英文三级行政区划；=chs时，输出简体三级行政区划；=空值，或不传，默认简体
    private String addresstag = ""; // 非必填。=src 表示寄件地址；=dest 表示派件地址；=other，包括例如地址簿里新建地址时候调用

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getCompare() {
        return compare;
    }

    public void setCompare(String compare) {
        this.compare = compare;
    }

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public String getShowcode() {
        return showcode;
    }

    public void setShowcode(String showcode) {
        this.showcode = showcode;
    }

    public String getLa() {
        return la;
    }

    public void setLa(String la) {
        this.la = la;
    }

    public String getAddresstag() {
        return addresstag;
    }

    public void setAddresstag(String addresstag) {
        this.addresstag = addresstag;
    }

    @Override
    public String toString() {
        return "SegApiSplitIn{" +
                "ak='" + ak + '\'' +
                ", province='" + province + '\'' +
                ", citycode='" + citycode + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", town='" + town + '\'' +
                ", address='" + address + '\'' +
                ", level='" + level + '\'' +
                ", origin='" + origin + '\'' +
                ", compare='" + compare + '\'' +
                ", orderno='" + orderno + '\'' +
                ", showcode='" + showcode + '\'' +
                ", la='" + la + '\'' +
                ", addresstag='" + addresstag + '\'' +
                '}';
    }
}
