package com.sf.gis.java.base.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.pojo.ZcInfo;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 网点相关API
 * @author 01370539 created on Jul.06 2021
 */
public class ZcApi {
    private static final Logger logger = LoggerFactory.getLogger(ZcApi.class);

    /**
     * 丰网点落面接口，根据坐标获取网点
     * @param ak ak
     * @param lng 经度
     * @param lat 纬度
     * @return 网点信息
     */
    public static ZcInfo checksDepotData(String ak, String lng, String lat) {
        String url = null;
        ZcInfo zcInfo = new ZcInfo();
        zcInfo.setLng(lng);
        zcInfo.setLat(lat);
        try {
            if(StringUtils.isNotEmpty(lng) && StringUtils.isNotEmpty(lat)){
                url = String.format(HttpConstant.HTTP_URL_EFSMS_CHECKSDEPOTDATA, ak, lng, lat);
                String result = HttpInvokeUtil.sendGet(url);
                if (StringUtils.isEmpty(result)) {
                    logger.error("checksDepotData resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            Boolean is_true = resultJson.getBoolean("is_true");
                            if(is_true == true){
                                JSONArray mapDataArr = resultJson.getJSONArray("map_data");
                                if (mapDataArr != null && mapDataArr.size() > 0) {
                                    JSONObject extendAttr = mapDataArr.getJSONObject(0).getJSONObject("extend_attr");
                                    if (extendAttr != null) {
                                        String firstDeptCode = extendAttr.getString("firstDeptCode");
                                        if (StringUtils.isNotEmpty(firstDeptCode)) {
                                            zcInfo.setZc(firstDeptCode.substring(firstDeptCode.indexOf("_") + 1));
                                        } else {
                                            logger.error("firstDeptCode is null. checksDepotData resp error. url - {}, resp - {}", url, result);
                                        }
                                    } else {
                                        logger.error("extend_attr is null. checksDepotData resp error. url - {}, resp - {}", url, result);
                                    }
                                } else {
                                    logger.error("map_data is null. checksDepotData resp error. url - {}, resp - {}", url, result);
                                }
                            }
                        } else {
                            logger.error("result is null. checksDepotData resp error. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("status is 1. checksDepotData resp error. url - {}, resp - {}", url, result);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("request checksDepotData error. url: {}, e: {}", url, e);
        }
        return zcInfo;
    }

    public static String checksDepotDataNew(String ak, String lng, String lat) {
        String url = null;
        try {
            if(StringUtils.isNotEmpty(lng) && StringUtils.isNotEmpty(lat)){
                url = String.format(HttpConstant.HTTP_URL_EFSMS_CHECKSDEPOTDATA, ak, lng, lat);
                String result = HttpInvokeUtil.sendGet(url);
                if (StringUtils.isEmpty(result)) {
                    logger.error("checksDepotData resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            Boolean is_true = resultJson.getBoolean("is_true");
                            if(is_true == true){
                                JSONArray mapDataArr = resultJson.getJSONArray("map_data");
                                if (mapDataArr != null && mapDataArr.size() > 0) {
                                    JSONObject extendAttr = mapDataArr.getJSONObject(0).getJSONObject("extend_attr");
                                    if (extendAttr != null) {
                                        String firstDeptCode = extendAttr.getString("firstDeptCode");
                                        if (StringUtils.isNotEmpty(firstDeptCode)) {
                                            return firstDeptCode.substring(firstDeptCode.indexOf("_") + 1);
                                        }
                                    }
                                }
                            }else {
                                return "not_covered";
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("request checksDepotData error. url: {}, e: {}", url, e);
        }
        return null;
    }

    /**
     * 丰网模型接口
     * @param cityCode 城市编码
     * @param address 地址
     * @return 获取到的网点相关信息
     */
    public static String zc(String cityCode, String address) {
        String url = null;
        try {
            url = String.format(HttpConstant.HTTP_URL_ZC, cityCode, address.replaceAll(" ", ""));
            String result = HttpInvokeUtil.sendGet(url);
            if (StringUtils.isEmpty(result)) {
                logger.error("zc resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getDoubleValue("confidence_zc") == 1) {
                    return rsJson.getString("depponzc");
                }
            }
        } catch (Exception e) {
            logger.error("request zc error. url: {}, e: {}", url, e);
        }
        return "";
    }
}
