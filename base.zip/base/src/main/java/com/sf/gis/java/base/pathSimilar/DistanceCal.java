package com.sf.gis.java.base.pathSimilar;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/7/5
*/


import com.vividsolutions.jts.geom.*;
import com.vividsolutions.jts.io.ParseException;
import com.vividsolutions.jts.io.WKTReader;

import java.io.IOException;
import java.util.List;

import static com.sf.gis.java.base.pathSimilar.TrackVector.*;


public class DistanceCal {
    static double EARTH_RADIUS = 6378137.0;    //单位M

    static private double getRad(double d) {
        return d * Math.PI / 180.0;
    }

    //算法1:求两点之间的距离(比较粗略，但是GD/BD地图采用此算法)
    static public double getGreatCircleDistance(double lng1, double lat1, double lng2, double lat2) {

        try {
            double radLat1 = getRad(lat1);
            double radLat2 = getRad(lat2);

            double dy = radLat1 - radLat2;  //a
            double dx = getRad(lng1) - getRad(lng2);    //b

            double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(dy / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(dx / 2), 2)));
            s = s * EARTH_RADIUS;
            s = Math.round(s * 10000) / 10000.0;

            return s;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    static private double getLongt(double longt1, double lat1, double distance) {
        return (180 * distance) / (Math.PI * EARTH_RADIUS * Math.cos(lat1 * Math.PI / 180));
    }


    static private double getLat(double longt1, double lat1, double distance) {
        return distance / 111000;
    }

    static public Polygon createRingPolygon(GeometryFactory geometryFactory, double x, double y, double radius) {
        double lgtDis = getLongt(x, y, radius);
        double latDis = getLat(x, y, radius);
        System.out.println(lgtDis + "," + latDis);
        Coordinate c0 = new Coordinate(x - lgtDis, y - latDis);
        Coordinate c1 = new Coordinate(x - lgtDis, y);
        Coordinate c2 = new Coordinate(x - lgtDis, y + latDis);
        Coordinate c3 = new Coordinate(x, y + latDis);
        Coordinate c4 = new Coordinate(x + lgtDis, y + latDis);
        Coordinate c5 = new Coordinate(x + lgtDis, y);
        Coordinate c6 = new Coordinate(x + lgtDis, y - latDis);
        Coordinate c7 = new Coordinate(x, y - latDis);
        Coordinate[] cArray = new Coordinate[]{c0, c1, c2, c3, c4, c5, c6, c7, c0};

        LinearRing line = geometryFactory.createLinearRing(cArray);
        Polygon polygon = geometryFactory.createPolygon(line, null);
        return polygon;
    }

    public static String createMaxRec(GeometryFactory geometryFactory, String polygonStr, Double lng, Double lat) throws ParseException {
        WKTReader wKTReader = new WKTReader(geometryFactory);
        Polygon polygon = (Polygon) wKTReader.read(polygonStr);
        Coordinate[] points = polygon.getCoordinates();
        double minX = lng, maxX = lng, minY = lat, maxY = lat;
        for (Coordinate point : points) {
            minX = point.x > minX ? minX : point.x;
            minY = point.y > minY ? minY : point.y;
            maxX = point.x > maxX ? point.x : maxX;
            maxY = point.y > maxY ? point.y : maxY;
        }
        double extendXmin = getLongt(minX, minY, 500);
        double extendYmin = getLat(minX, minY, 500);
        double extendXmax = getLongt(maxX, maxY, 500);
        double extendYmax = getLat(maxX, maxY, 500);
        Coordinate c0 = new Coordinate(minX-extendXmin, minY-extendYmin);
        Coordinate c1 = new Coordinate(minX-extendXmin, maxY+extendYmax);
        Coordinate c2 = new Coordinate(maxX+extendXmax, maxY+extendYmax);
        Coordinate c3 = new Coordinate(maxX+extendXmax, minY-extendYmin);
        Coordinate[] cArray = new Coordinate[]{c0, c1, c2, c3, c0};
        LinearRing line = geometryFactory.createLinearRing(cArray);
        Polygon rec = geometryFactory.createPolygon(line, null);
        return rec.toString();
    }



    public static double pointToLine(Track p, Track p1, Track p2, Track closest, int pType){

        double x = p.getX();
        double y = p.getY();
        double x1 = p1.getX();
        double y1 = p1.getY();
        double x2 = p2.getX();
        double y2 = p2.getY();


        if (p1.getX() == p2.getX() && p1.getY() == p2.getY()){
            return Distance_meters(x,y,x1,y1);
        }


        TrackVector va  = getVector(p,p1);
        TrackVector vb  = getVector(p2,p1);

        double dot = dot(va, vb);

        //垂足在vb的反方向上
        if (dot < 0)
        {
//            if (closest != null) p1 = closest;
//            if (pType != 0) pType = 0;
            return Distance_meters(x,y,x1,y1);
        }


        double square = norm2(vb);	//|b|^2
        //|a||b|cos / |b|^2
        double s = dot / square;
        if (s > 1)
        {
//            if (closest != null) p2 = closest;
//            if (pType != 0) pType = 1;
            return Distance_meters(x,y,x2,y2);
        }


//        double cross = Cross(va, vb);

//        if (closest != NULL) *closest = p1 + vb * s;
//        if (pType != NULL)*pType = 2;
        //距离 = |a||b|sin / |b|

//        return cross / Math.sqrt(square);


        TrackVector v3 = addVector(p1, multiVectorDouble(vb, s));

        return Distance_meters(x,y, v3.getX(),v3.getY());

    }





    public double alSegmentDis(double x, double y, double x1, double y1, double x2, double y2) {
        double dis =0;

        double a, b, c;

        a = getGreatCircleDistance(x1, y1, x2, y2 );// 线段的长度

        b = getGreatCircleDistance(x1,y1, x, y); // point1到点的距离

        c = getGreatCircleDistance(x2, y2, x, y);//point2到点的距离

        if(c + b == a) {// 点在线段上

            dis = 0;

            return dis;
        }

        if(c * c >= a * a + b * b) {
            dis = b;
            return dis;

        }

        if(b * b >= a * a + c * c) {

            dis = c;

            return dis;

        }


        double p = (a + b + c) /2;

        double s = Math.sqrt(p * (p - a) * (p - b) * (p - c));

        dis = 2* s / a;

        return dis;

    }



    static public double jtsGeomP2L(double x, double y, double x1, double y1, double x2, double y2) {

        GeometryFactory geometryFactory = new GeometryFactory(new PrecisionModel(PrecisionModel.FLOATING), 4326);

        Coordinate c = new Coordinate(x , y);
        Coordinate c1 = new Coordinate(x1, y1);
        Coordinate c2 = new Coordinate(x2, y2);

        WKTReader wktReader = new WKTReader(geometryFactory);

        Coordinate[] cArray = new Coordinate[]{c1, c2};

        LinearRing line = geometryFactory.createLinearRing(cArray);
        LinearRing line2 = geometryFactory.createLinearRing(cArray);

        Geometry difference = line.difference(line2);

        double distance = c.distance(c);

        return distance;
    }




    public static double sampleP2L(double x, double y, double x1, double y1, double x2, double y2){

        double d1 = (x2 - x1) * (x - x1) + (y2 - y1) * (y - y1);
        double d2 = (x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1);
        if (d1 < d2){
            return getGreatCircleDistance(x, y, x1, y1);
        }
        if (d1 >= d2) {
            return getGreatCircleDistance(x, y, x2, y2);
        }
        double r = d1 / d2;
        double px = x1 + (x2 - x1) * r;
        double py = y1 + (y2 - y1) * r;
        return getGreatCircleDistance(x, y, px, py);
    }




    public static double pointToLineDist (double pointLng, double pointLat, double startLng, double startLat, double endLng, double endLat){

        double disatance1 = getGreatCircleDistance(pointLng,pointLat,startLng,startLat);
        double disatance2 = getGreatCircleDistance(pointLng,pointLat,endLng,endLat);
        double disatance3 = getGreatCircleDistance(startLng,startLat,endLng,endLat);

        double area = (disatance1 + disatance2 + disatance3) / 2;

        return 2 * area / disatance3;

    }



    public static double pointToPolygonalLine(Track point,List<Track> otherTracklist, Track closest, int pIndex, int pType){
        double minDis = 1E10;
        Track temp = null;
        int nTempType = 0;
        int num = otherTracklist.size();
        Track track0 = new Track();
        if (otherTracklist.size() != 0 ) track0 = otherTracklist.get(0);

        if (num == 1)
        {
            minDis = Distance_meters(point.x,point.y,track0.x,track0.y);
        }

        for (int i = 1; i < num; i++){
            double dis = pointToLine(point, otherTracklist.get(i - 1), otherTracklist.get(i),temp,nTempType);

            if (dis < minDis){

//                if (closest != null)
//                {
//    				temp = closest;
//                    if (pType != 0)
//                    {
//					    nTempType = pType;
//                    }
//                    if (pIndex != 0)
//                    {
//                        switch (nTempType)
//                        {
//                            case 0:
//                            case 2:
//						    pIndex = i - 1;
//                                break;
//                            default:
//						    pIndex = i;
//                                if (pType != 0)
//							    pType = 0;
//                                break;
//                        }
//                    }
//                }
                minDis = dis;

            }

        }

        return minDis;

    }



    public static double Distance_meters(double x1, double y1, double x2, double y2)
    {
        double dx = x2 - x1;
        double dy = y2 - y1;
        double sx = dx * Math.cos(y1 * 0.01745329252f);
        return Math.sqrt(sx * sx + dy * dy) * 111195.0;
    }





    public static void main(String[] args) throws IOException {

        Track track0 = new Track(113.915109336,22.511672372);
        Track track1 = new Track(113.915970325,22.511476623);
        Track track2 = new Track(113.915458024,22.511285830);


        double v = pointToLine(track0, track1, track2,null,0);


        System.out.println(v);

    }


}
