package com.sf.gis.java.base.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.dto.ArInfo;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 行政区域API
 * @author 01370539
 * Created on Jul.29 2022
 */
public class ArApi {
    private static final Logger logger = LoggerFactory.getLogger(ArApi.class);

    public static Map<String, ArInfo> queryBatchAdcode(List<String> coordList, String ak) {
       String xy="";
        if (coordList != null && coordList.size() > 0) {
            int i = 0;
            for (String coord : coordList) {
                if (i == 0) {
                    xy = coord;
                } else {
                    xy += "@" + coord;
                }
                i++;
            }
        }
        return queryBatchAdcode(xy, ak);
    }

    public static Map<String, ArInfo> queryBatchAdcode(String xy, String ak) {
        String url = null;
        Map<String, ArInfo> rsMap = new HashMap<>();
        try {
            if (StringUtils.isNotEmpty(xy) && StringUtils.isNotEmpty(ak)) {
                String[] xyArr = xy.split("@");
                url = String.format(HttpConstant.HTTP_URL_QUERYBATCHADCODE, xy, ak);
                queryBatchAdcode(url, rsMap, xyArr, 0);
            }
        } catch(Exception e){
            logger.error("request queryBatchAdcode error. url: {}, e: {}", url, e);
        }
        return rsMap;
    }

    private static void queryBatchAdcode(String url, Map<String, ArInfo> rsMap, String[] xyArr, int isAttemptCntStatus1) {
        String result = HttpInvokeUtil.sendGet(url, FixedConstant.MAX_TRY_TIME_THREE);
        if (StringUtils.isEmpty(result)) {
            logger.error("queryBatchAdcode resp null. url - {}", url);
        } else {
            JSONObject rsJson = JSON.parseObject(result);
            if (rsJson.getInteger("status") == 0) {
                parseRs(rsJson, rsMap, xyArr, url, result);
            } else {
                if (isAttemptCntStatus1 < 10) {
                    queryBatchAdcode(url, rsMap, xyArr, ++isAttemptCntStatus1);
                } else {
                    logger.error("status is 1. queryBatchAdcode resp error. url - {}, resp - {}", url, result);
                }
            }
        }
    }

    private static void parseRs(JSONObject rsJson, Map<String, ArInfo> rsMap, String[] xyArr, String url, String result) {
        JSONObject resultJson = rsJson.getJSONObject("result");
        if (resultJson != null) {
            JSONArray dataArr = resultJson.getJSONArray("data");
            if (dataArr != null && dataArr.size() > 0) {
                JSONObject data;
                ArInfo ar;
                for (int i = 0; i < dataArr.size(); i++) {
                    data = dataArr.getJSONObject(i);
                    ar = new ArInfo();
                    ar.setProvince(data.getString("province"));
                    ar.setCity(data.getString("city"));
                    ar.setCounty(data.getString("county"));
                    ar.setTown(data.getString("town"));
                    ar.setAdcode(data.getString("adcode"));
                    ar.setCityCode(data.getString("citycode"));
                    rsMap.put(xyArr[i], ar);
                }
            } else {
                logger.error("data is null. queryBatchAdcode resp error. url - {}, resp - {}", url, result);
            }
        } else {
            logger.error("result is null. queryBatchAdcode resp error. url - {}, resp - {}", url, result);
        }
    }

}
