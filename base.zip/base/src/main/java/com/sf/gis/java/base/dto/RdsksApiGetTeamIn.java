package com.sf.gis.java.base.dto;

/**
 * KS入参
 */
public class RdsksApiGetTeamIn {
    private String ak;   // 必填项，授权AK
    private String opt;   // 非必填项，zh.返回所有ks结果（ks1到ks15返回各个源结果,可以组合多个以逗号分隔，例: opt=ks1,ks15）
    private String adcode;  // 非必填项，adcode
    private String province;  // 非必填项，省
    private String city;  // 必填项，城市编码
    private String cityName;  // 非必填项，城市名称
    private String district;  // 非必填项，区
    private String dept;  // 非必填项，网点
    private String address;  // 必填项，地址
    private String filter;  // 非必填项，过滤
    private String attachment;  // 非必填项，附加参数
    private String company;  // 非必填项，公司名
    private String mobile;  // 非必填项，手机
    private String tel;  // 非必填项，座机
    private String tc;  // 非必填项，单元区域
    private String x;  // 非必填项，经度
    private String y;  // 非必填项，纬度

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFilter() {
        return filter;
    }

    public void setFilter(String filter) {
        this.filter = filter;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getTc() {
        return tc;
    }

    public void setTc(String tc) {
        this.tc = tc;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    @Override
    public String toString() {
        return "RdsksApiGetTeamIn{" +
                "ak='" + ak + '\'' +
                ", opt='" + opt + '\'' +
                ", adcode='" + adcode + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", cityName='" + cityName + '\'' +
                ", district='" + district + '\'' +
                ", dept='" + dept + '\'' +
                ", address='" + address + '\'' +
                ", filter='" + filter + '\'' +
                ", attachment='" + attachment + '\'' +
                ", company='" + company + '\'' +
                ", mobile='" + mobile + '\'' +
                ", tel='" + tel + '\'' +
                ", tc='" + tc + '\'' +
                ", x='" + x + '\'' +
                ", y='" + y + '\'' +
                '}';
    }
}
