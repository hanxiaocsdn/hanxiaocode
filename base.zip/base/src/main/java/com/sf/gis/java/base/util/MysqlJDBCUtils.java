package com.sf.gis.java.base.util;

import com.alibaba.druid.pool.DruidDataSourceFactory;

import javax.sql.DataSource;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;


public class MysqlJDBCUtils {
    private static DataSource dataSource;
    private static Properties properties;

    /**
     * 获取数据库连接
     *
     * @return void
     */
    public static Connection getConnection(String druidFile) {
        Connection connection = null;
        try {
            //1. 创建一个Properties对象
            properties = new Properties();
            //2. 加载配置文件
            properties.load(MysqlJDBCUtils.class.getClassLoader().getResourceAsStream(druidFile));
            //3. 根据配置文件创建DataSource,这里用到了druid-1.1.10.jar
            dataSource = DruidDataSourceFactory.createDataSource(properties);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            connection = dataSource.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }

    /**
     * 生成md5值
     *
     * @param sqls 插入语句集合
     * @param size 批量插入大小
     * @return void
     */
    public static void insertBatch(Connection conn, List<String> sqls, int size) throws SQLException {
        //insertSql = "insert ignore into " + tableName + " set " + setColumns;


        PreparedStatement pstmt = conn.prepareStatement("");
        int addBatchTime = 0;

        conn.setAutoCommit(false);

        try {
            for (String sql : sqls) {
                pstmt.addBatch(sql);
                if (addBatchTime++ == size) {
                    addBatchTime = 0;
                    pstmt.executeBatch();
                    conn.commit();
                }
            }

            pstmt.executeBatch();
            conn.commit();
        } catch (Exception e) {
            throw e;
        } finally {
            close(null, pstmt, conn);
        }
    }

    /**
     * 获取表的列名集合
     *
     * @param tableName 目标表名
     * @return ArrayList<String>
     */
    public static ArrayList<String> getColums(Connection conn, String tableName) throws SQLException {
        ArrayList<String> columnsList = new ArrayList<>();


        if (conn == null)
            throw new RuntimeException("获取数据库连接失败");

        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            String sql = "select COLUMN_NAME from information_schema.COLUMNS where table_name ='" + tableName + "'" +
                    " and COLUMN_NAME not in ('ID','STAT_DATE','CREATE_TIME','CREATE_USER','MODIFY_TIME','MODIFY_USER');";

            pstmt = conn.prepareStatement("");

            ResultSet resultSet = pstmt.executeQuery(sql);
            while (resultSet.next()) {
                columnsList.add(resultSet.getString(1));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(rs, pstmt, conn);
            return columnsList;
        }
    }

    /**
     * 关闭数据库连接
     *
     * @param rs
     * @return void
     */
    public static void close(ResultSet rs, Statement stmt, Connection con) throws SQLException {
        if (rs != null)
            rs.close();
        if (stmt != null)
            stmt.close();
        if (con != null)
            con.close();
    }


    public static String getDbProp(String prop) {
        return "\n\n\n>>>>>>>>>>>>>>>db的配置为<<<<<<<<<<<<<<<\n" + properties.getProperty(prop) + "\n\n\n";
    }

    public static void query(Connection conn, String tableName) throws SQLException {

        if (conn == null)
            throw new RuntimeException("获取数据库连接失败");

        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            String sql = "select * from " + tableName + ";";

            pstmt = conn.prepareStatement("");

            ResultSet resultSet = pstmt.executeQuery(sql);
            while (resultSet.next()) {
                System.out.println("ID=" + resultSet.getString(0) + ",STAT_DATE=" + resultSet.getString(1) +
                        ",AK=" + resultSet.getString(2) + ",DATA_TYPE=" + resultSet.getString(3)
                        + ",DETAIL_TYPE=" + resultSet.getString(4) + ",USER_AMOUNT=" + resultSet.getString(5)
                        + ",REQ_AMOUNT=" + resultSet.getString(6) + ",ADDR_ND_REQ_AMOUNT=" + resultSet.getString(7)
                        + ",ADDR_ND_USER_AMOUNT=" + resultSet.getString(8) + ",ADDR_MODIFY_AMOUNT=" + resultSet.getString(9)
                        + ",ADDR_ND_TRANS_AMOUNT=" + resultSet.getString(10) + ",ADDR_ND_MODIFY_1_AMOUNT=" + resultSet.getString(11)
                        + ",ADDR_ND_MODIFY_1_TRANS_AMOUNT=" + resultSet.getString(12));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(rs, pstmt, conn);
        }
    }

    public static void main(String[] args) throws SQLException {
//        query("gis_oms_lip_ars.ADDR_ND_TRANS_RATE");
    }
}