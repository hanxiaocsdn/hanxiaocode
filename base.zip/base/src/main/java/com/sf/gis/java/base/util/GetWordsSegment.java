package com.sf.gis.java.base.util;

import com.sf.KeyInfo;

import java.io.Serializable;
import java.util.Map;

public class GetWordsSegment implements Serializable {

    public static Map<String, String> parseAddress(String address) {
        int uselessIndex;
        if ((uselessIndex = address.indexOf(";")) > 0) {
            address = address.substring(0, uselessIndex);
        }
        KeyInfo keyInfo = new KeyInfo(address);
        System.out.println(keyInfo.pick_key());
        return keyInfo.pick_key();
    }

    // 先调用上面的方法,在把上面的方法传入到下面的方法获得关键字
//    public static String parseKeyword(Map<String, String> keyMap) {
//        StringBuilder parseKeyword = new StringBuilder();
//        String keyLevels = keyMap.get("key_levels");
//        String keyword = keyMap.get("key_word");
//        int index;
//        if ((index = keyLevels.lastIndexOf("13^")) > -1) {
//            int keyLen = keyLevels.substring(0, index+3).split("|").length;
//            String[] keyWords = keyword.split("|");
//            if (keyWords.length < keyLen) {
//                return filterAddress(keyword);
//            }
//            for (int i = 0; i < keyLen; i++) {
//                parseKeyword.append(keyWords[i]);
//            }
//            System.out.println(filterAddress(parseKeyword.toString()));
//            return filterAddress(parseKeyword.toString());
//        }
//        System.out.println(filterAddress(parseKeyword.toString()));
//        return filterAddress(keyword);
//    }

    public static String filterAddress(String address) {
        return address.replaceAll("|", "");
    }



    public static void main(String[] args) {



        String s = "浙江省杭州市余杭区良渚街道纤石村村委旁巍绿农业";
        Map<String, String> stringStringMap = parseAddress(s);
        System.out.println(stringStringMap);
    }
}
