package com.sf.gis.java.base.util;

import com.github.davidmoten.geo.LatLong;
import com.sf.gis.java.base.api.ArApi;
import com.sf.gis.java.base.dto.ArInfo;
import com.sf.gis.java.base.dto.PointDto;
import com.sf.gis.java.base.dto.StayPointDto;
import com.vividsolutions.jts.geom.Point;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 轨迹相关工具类
 * @author 01370539
 * Created on Jul.28 2022
 */
public class TrajectoryUtil {
    public static final Logger logger = LoggerFactory.getLogger(TrajectoryUtil.class);

    /**
     * 停留轨迹点挖掘
     *
     * @param pdList
     *            带有时间标志的轨迹点集合
     * @param tmSpan
     *            时间周期（和集合中点的时间保持一致，用于进行点的分段）
     * @param radiusMax
     *            要切割的区域最大半径(单位：米)
     * @param pointSizeMin
     *            要切割的区域最小的轨迹点数量
     * @return 停留点集合
     */
    public static List<StayPointDto> trackStayPointDm(List<PointDto> pdList, int tmSpan, int radiusMax, int pointSizeMin) {
        List<StayPointDto> resultList = new ArrayList<>();
        pdList.sort(Comparator.comparing(PointDto::getTm)); // 按照时间对序列点进行排序

        // 以时间为范围切割轨迹点
        Map<Integer, Long> keyMap = new HashMap<>(); // 分隔后的点都有一个key，用来存储每个周期的点集合对应的key
        Map<Long, List<PointDto>> spMap = splitPointByTm(pdList, tmSpan, keyMap); // 按照时间周期对点进行切割，形成多个点集合
        pdList.clear();

        // 初步筛选符合要求的轨迹点集合（如果集合内的点数量以及第一个点和最后一个点时间的点之间的距离满足要求，则进行筛选）
        double dis;
        PointDto first;
        PointDto last;
        List<Integer> indexList = new ArrayList<>();
        long key;
        List<PointDto> tmpList;
        for (int i = 0; i < keyMap.size(); i++) {
            key = keyMap.get(i);
            tmpList = spMap.get(key);
            if (tmpList.size() >= pointSizeMin) {
                first = tmpList.get(0);
                last = tmpList.get(tmpList.size() - 1);
                dis = GeometryUtil.getDistance(GeometryUtil.createPoint(first.getLng(), first.getLat()), GeometryUtil.createPoint(last.getLng(), last.getLat()));
                if (dis >= 0 && dis <= radiusMax) {
                    indexList.add(i);
                }
            }
        }

        long curKey;
        int curIndex;
        LatLong center;
        Point centerPoint;
        boolean isContinue;
        for (int index : indexList) {
            curKey = keyMap.get(index);
            tmpList = spMap.get(curKey);
            if (tmpList != null) {
                center = getCenterPoint(tmpList); // 找到中间点集合的中心点
                centerPoint = GeometryUtil.createPoint(center.getLon(), center.getLat());

                pdList = new ArrayList<>(); // 用来存储可以聚集在一起的点集合
                pdList.addAll(tmpList);
                if (index > 0) {
                    curIndex = index;
                    isContinue = true;
                    while (isContinue && --curIndex >= 0) {
                        curKey = keyMap.get(curIndex);
                        tmpList = spMap.get(curKey);
                        if (tmpList != null) {
                            isContinue = addAggrPoint(tmpList, false, centerPoint, radiusMax, pdList);
                            spMap.remove(curKey);
                        } else {
                            break;
                        }
                    }
                }
                if (index < keyMap.size() - 1) {
                    curIndex = index;
                    isContinue = true;
                    while (isContinue && ++curIndex <= keyMap.size() - 1) {
                        curKey = keyMap.get(curIndex);
                        tmpList = spMap.get(curKey);
                        if (tmpList != null) {
                            isContinue = addAggrPoint(tmpList, true, centerPoint, radiusMax, pdList);
                            spMap.remove(curKey);
                        } else {
                            break;
                        }
                    }
                }
                pdList.sort(Comparator.comparing(PointDto::getTm));
                first = pdList.get(0);
                last = pdList.get(pdList.size() - 1);
                center = getCenterPoint(pdList);
                resultList.add(new StayPointDto(String.valueOf(keyMap.get(index)),
                        GeometryUtil.getDistance(GeometryUtil.createPoint(first.getLng(), first.getLat()), GeometryUtil.createPoint(last.getLng(), last.getLat())), pdList.size(),
                        last.getTm() - first.getTm(), center.getLon(), center.getLat(), -1, pdList));
            }
        }
        return resultList;
    }

    /**
     * 对于轨迹点按照固定距离范围进行聚合
     *
     * @param pdList
     * @param radiusMax
     * @return
     */
    public static Map<String, String> trackStayPointAgr(String gh, List<PointDto> pdList, int radiusMax) {
        pdList.sort((a, b) -> a.getId().compareTo(b.getId()));
        Map<String, PointDto> pdMap = new HashMap<>();
        pdList.forEach(pd -> pdMap.put(pd.getId(), pd));

        Map<String, List<PointDto>> resultMap = new HashMap<>();
        List<PointDto> resultList;

        int chkIndex;
        PointDto chkPd;
        PointDto curPd;
        double dis;
        for (int i = 0, size = pdList.size(); i < size; i++) {
            curPd = pdMap.get(pdList.get(i).getId());
            if (curPd != null) {
                resultList = new ArrayList<>();
                logger.error("id: {}", gh+"_"+curPd.getId());
                resultMap.put(gh + "_" + curPd.getId(), resultList);
                resultList.add(curPd);
                chkIndex = i + 1;
                while (chkIndex < size) {
                    chkPd = pdMap.get(pdList.get(chkIndex).getId());
                    if (chkPd != null) {
                        dis = GeometryUtil.getDistance(GeometryUtil.createPoint(curPd.getLng(), curPd.getLat()), GeometryUtil.createPoint(chkPd.getLng(), chkPd.getLat()));
                        if (dis <= radiusMax / 2) {
                            resultList.add(chkPd);
                            pdMap.remove(chkPd.getId());
                        }
                    }
                    chkIndex++;
                }
            }
        }
        pdMap.clear();
        pdList.clear();

        Map<String, String> rsFinalMap = new HashMap<>();
        int cnt;
        for (String id : resultMap.keySet()) {
            cnt = resultMap.get(id).size();
            for (PointDto pd : resultMap.get(id)) {
                rsFinalMap.put(pd.getId(), id + "#" + cnt);
            }
        }
        resultMap.clear();
        return rsFinalMap;
    }

    /**
     * 在一串时间序列的轨迹点内挖掘到起始点某个距离卡点固定范围内的点
     *
     * @param pdList
     *            轨迹序列
     * @param disSpan
     *            距离检查值
     * @param disSpanRange
     *            距离检查点前后的范围值
     * @return 给各个轨迹打标签
     */
    public static List<StayPointDto> trackDis2spDm(List<PointDto> pdList, int tmSpan, int disSpan, int disSpanRange) {

        List<StayPointDto> resultList = new ArrayList<>();
        pdList.sort(Comparator.comparing(PointDto::getTm)); // 按照时间对序列点进行排序
        double lastMileage = 0;
        double startPdMileage = 0;
        double endPdMileage = 0;
        double curPdMileage = 0;

        // 以时间为范围切割轨迹点
        Map<Integer, Long> keyMap = new HashMap<>(); // 分隔后的点都有一个key，用来存储每个周期的点集合对应的key
        Map<Long, List<PointDto>> spMap = splitPointByTm(pdList, tmSpan, keyMap); // 按照时间周期对点进行切割，形成多个点集合
        pdList.clear();

        PointDto pdFirst;
        PointDto pdLast;
        PointDto pdCur;
        PointDto pdLastGrpLast = null;
        LatLong center;

        Long key;
        List<PointDto> tmpList = null;
        boolean isStartMatch;
        boolean isEndMatch;
        boolean isChkNxt;
        for (int index = 0; index < keyMap.size(); index++) {
            isStartMatch = false;
            isEndMatch = false;
            isChkNxt = false;

            key = keyMap.get(index);
            tmpList = spMap.get(key);
            pdFirst = tmpList.get(0);
            pdLast = tmpList.get(tmpList.size() - 1);

            if (pdLastGrpLast != null) {
                startPdMileage = lastMileage
                        + GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdLastGrpLast.getLng(), pdLastGrpLast.getLat()));
            } else {
                startPdMileage = lastMileage;
            }
            isStartMatch = isInDisRange(startPdMileage, disSpan, disSpanRange);

            endPdMileage = startPdMileage + GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdLast.getLng(), pdLast.getLat()));
            isEndMatch = isInDisRange(endPdMileage, disSpan, disSpanRange);

            if (!isStartMatch && !isEndMatch) {
                if (Math.floor(startPdMileage / disSpan) != Math.floor(endPdMileage / disSpan)) {
                    for (int i = 1; i <= tmpList.size() - 2; i++) {
                        pdCur = tmpList.get(i);
                        curPdMileage = startPdMileage
                                + GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdCur.getLng(), pdCur.getLat()));
                        if (isInDisRange(curPdMileage, disSpan, disSpanRange)) {
                            pdList.add(pdCur);
                            isChkNxt = true;
                        } else {
                            if (isChkNxt) {
                                break;
                            }
                        }
                    }
                }
            } else if (isStartMatch && !isEndMatch) {
                pdList.add(pdFirst);
                for (int i = 1; i <= tmpList.size() - 1; i++) {
                    pdCur = tmpList.get(i);
                    curPdMileage = startPdMileage + GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdCur.getLng(), pdCur.getLat()));
                    if (isInDisRange(curPdMileage, disSpan, disSpanRange)) {
                        pdList.add(pdCur);
                    } else {
                        break;
                    }
                }
            } else {
                if (!isStartMatch && isEndMatch) {
                    pdList.add(pdLast);
                    for (int i = tmpList.size() - 2; i >= 0; i--) {
                        pdCur = tmpList.get(i);
                        curPdMileage = startPdMileage
                                + GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdCur.getLng(), pdCur.getLat()));
                        if (isInDisRange(curPdMileage, disSpan, disSpanRange)) {
                            pdList.add(pdCur);
                        } else {
                            break;
                        }
                    }
                } else if (isStartMatch && isEndMatch) {
                    pdList.addAll(tmpList);
                }
                isChkNxt = true;

                while (isChkNxt) {
                    index++;
                    if (index < keyMap.size()) {
                        key = keyMap.get(index);
                        tmpList = spMap.get(key);
                        pdLast = tmpList.get(tmpList.size() - 1);

                        endPdMileage = startPdMileage
                                + GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdLast.getLng(), pdLast.getLat()));
                        isEndMatch = isInDisRange(endPdMileage, disSpan, disSpanRange);
                        if (isEndMatch) {
                            pdList.addAll(tmpList);
                        } else {
                            isChkNxt = false;
                            for (int i = 0; i <= tmpList.size() - 1; i++) {
                                pdCur = tmpList.get(i);
                                curPdMileage = startPdMileage
                                        + GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdCur.getLng(), pdCur.getLat()));
                                if (isInDisRange(curPdMileage, disSpan, disSpanRange)) {
                                    pdList.add(pdCur);
                                } else {
                                    break;
                                }
                            }
                        }
                    } else {
                        isChkNxt = false;
                    }
                }
            }
            if (pdList.size() > 0) {
                pdList.sort(Comparator.comparing(PointDto::getTm));
                center = getCenterPoint(pdList);
                curPdMileage = startPdMileage + GeometryUtil.getDistance(GeometryUtil.createPoint(center.getLon(), center.getLat()), GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()));
                pdFirst = pdList.get(0);
                pdLast = pdList.get(pdList.size() - 1);
                resultList.add(new StayPointDto(String.valueOf(key),
                        GeometryUtil.getDistance(GeometryUtil.createPoint(pdFirst.getLng(), pdFirst.getLat()), GeometryUtil.createPoint(pdLast.getLng(), pdLast.getLat())), pdList.size(),
                        pdLast.getTm() - pdFirst.getTm(), center.getLon(), center.getLat(), curPdMileage, new ArrayList<>(pdList)));
                pdList.clear();
            }
            lastMileage = endPdMileage;
            pdLastGrpLast = pdLast;

        }
        return resultList;
    }

    // 检查点是否否和在距离检查点的范围内
    private static boolean isInDisRange(double mileage, int dis2sp, int dis2spRange) {
        double dis = mileage % dis2sp;
        if ((dis < dis2sp && dis >= dis2sp - dis2spRange) || (dis >= 0 && dis <= dis2spRange)) {
            return true;
        } else {
            return false;
        }
    }

    private static Map<Long, List<PointDto>> splitPointByTm(List<PointDto> pdList, int tmSpan, Map<Integer, Long> keyMap) {
        Map<Long, List<PointDto>> spMap = new HashMap<>();
        List<PointDto> tmpList; // 临时的点集合变量
        long endTm = pdList.get(0).getTm() + tmSpan; // 时间的最小范围
        for (PointDto track : pdList) {
            while (track.getTm() > endTm) {
                endTm += tmSpan;
            }
            tmpList = spMap.get(endTm);
            if (tmpList == null) {
                tmpList = new ArrayList<>();
                spMap.put(endTm, tmpList);
                if (keyMap != null) {
                    keyMap.put(keyMap.size(), endTm);
                }
            }
            tmpList.add(track);
        }
        return spMap;
    }

    private static boolean addAggrPoint(List<PointDto> chkList, boolean isDesc, Point centerPoint, int radiusMax, List<PointDto> pdList) {
        if (isDesc) {
            chkList.sort((a, b) -> b.getTm().compareTo(a.getTm()));
        }
        boolean isDrctAdd = false;
        PointDto first = chkList.get(0);
        double dis = GeometryUtil.getDistance(GeometryUtil.createPoint(first.getLng(), first.getLat()), centerPoint);
        if (dis <= radiusMax) {
            pdList.addAll(chkList);
            return true;
        } else {
            for (PointDto pd : chkList) {
                if (isDrctAdd) {
                    pdList.add(pd);
                } else {
                    dis = GeometryUtil.getDistance(GeometryUtil.createPoint(pd.getLng(), pd.getLat()), centerPoint);
                    if (dis <= radiusMax) {
                        pdList.add(pd);
                        isDrctAdd = true;
                    }
                }
            }
            return false;
        }
    }

    // 寻找中心点
    private static LatLong getCenterPoint(List<PointDto> pdList) {
        LinkedList<LatLong> llList = new LinkedList<>();
        for (PointDto pd : pdList) {
            llList.add(new LatLong(pd.getLat(), pd.getLng()));
        }
        return GeometryUtil.getCenter(llList);
    }
}
