package com.sf.gis.java.base.dto;

import com.mchange.v2.c3p0.AbstractConnectionCustomizer;

import java.sql.Connection;
import java.sql.Statement;

public class ConnectionCustomizer extends AbstractConnectionCustomizer {

    @Override
    public void onAcquire(Connection c, String parentDataSourceIdentityToken) throws Exception {
        Statement stmt = null;
        try {
            stmt = c.createStatement();
            stmt.executeUpdate("set names utf8mb4");
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }
}
