package com.sf.gis.java.base.dto;

import com.github.davidmoten.geo.LatLong;

import java.io.Serializable;
import java.util.*;

public class CoordInfo implements Serializable {
    private String uuid;
    private String key;
    private String lat;
    private String lng;
    private List<LatLong> llList = new LinkedList<>();
    private Map<String, CoordInfo> subMap = new HashMap<>();

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public List<LatLong> getLlList() {
        return llList;
    }

    public void setLlList(List<LatLong> llList) {
        this.llList = llList;
    }

    public Map<String, CoordInfo> getSubMap() {
        return subMap;
    }

    public void setSubMap(Map<String, CoordInfo> subMap) {
        this.subMap = subMap;
    }

    @Override
    public String toString() {
        return "Coordinates{" +
                "uuid='" + uuid + '\'' +
                ", key='" + key + '\'' +
                ", lat='" + lat + '\'' +
                ", lng='" + lng + '\'' +
                ", llList.size='" + llList.size() + '\'' +
                ", subMap.size='" + subMap.size() + '\'' +
                '}';
    }
}
