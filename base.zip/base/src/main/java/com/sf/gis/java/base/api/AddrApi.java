package com.sf.gis.java.base.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.KeyInfo;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.dto.*;
import com.sf.gis.java.base.util.AddrUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.StrUtils;
import com.sf.gis.java.base.util.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.URLEncoder;
import java.util.Map;

/**
 * 提供和地址相关服务
 *
 * @author 01370539 Created on May.28 2021
 */
public class AddrApi {
    private static final Logger logger = LoggerFactory.getLogger(AddrApi.class);

    /**
     * 根据地址获取地址的切词
     *
     * @param ak       ak
     * @param addr     地址
     * @param cityCode 城市编码
     * @return 地址主体信息
     */
    public static AddrInfo split(String ak, String cityCode, String addr) {
        String url = null;
        AddrInfo ai = new AddrInfo();
        ai.setAddr(addr);
        ai.setCityCode(cityCode);
        try {
            url = String.format(HttpConstant.HTTP_URL_SPLIT, ak, cityCode, addr);
            String result = HttpInvokeUtil.sendGet(url);
            if (StringUtils.isEmpty(result)) {
                logger.error("split resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getInteger("status") == 0) {
                    JSONObject resultJson = rsJson.getJSONObject("result");
                    if (resultJson != null) {
                        JSONObject dataJson = resultJson.getJSONObject("data");
                        if (dataJson != null) {
                            JSONArray infoArr = dataJson.getJSONArray("info");
                            JSONObject infoJson;
                            String split = "";
                            for (int i = 0; i < infoArr.size(); i++) {
                                infoJson = infoArr.getJSONObject(i);
                                split += (StringUtils.isEmpty(split) ? "" : ",") + infoJson.getString("name") + "^" + infoJson.getString("prop") + infoJson.getString("level");
                                if (infoJson.getInteger("level") == 6) {
                                    ai.setLast6(AddrUtil.transferNumber(infoJson.getString("name")).toLowerCase());
                                } else if (infoJson.getInteger("level") == 13) {
                                    if (infoJson.getInteger("prop") == 6) {
                                        ai.setLast613(AddrUtil.transferNumber(infoJson.getString("name")).toLowerCase());
                                    } else {
                                        ai.setLast13(AddrUtil.transferNumber(infoJson.getString("name")).toLowerCase());
                                    }
                                } else if (infoJson.getInteger("level") == 14) {
                                    ai.setLast14(AddrUtil.transferNumber(infoJson.getString("name")).toLowerCase());
                                }
                            }
                            ai.setSplit(split);
                            if (StringUtils.isNotEmpty(split)) {
                                KeyInfo key = new KeyInfo(split);
                                Map<String, String> keyMap = key.pick_key();
                                if (keyMap != null) {
                                    ai.setKeyword(AddrUtil.transferNumber(keyMap.get("key_word")).toLowerCase());
                                    ai.setKeytag(AddrUtil.transferNumber(keyMap.get("key_tag")).toLowerCase());
                                }
                            }
                        } else {
                            logger.error("data is null. split resp error. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("result is null. split resp error. url - {}, resp - {}", url, result);
                    }
                } else {
                    logger.error("status is 1. split resp error. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", url, e);
        }
        return ai;
    }

    /**
     * 根据地址获取坐标
     *
     * @param ak       ak
     * @param opt      opt:gd2, ma1等
     * @param cityCode 城市编码
     * @param addr     地址
     * @return 图上坐标
     */
    public static AddrInfo geo(String ak, String opt, String cityCode, String addr) {
        String url = null;
        AddrInfo ai = new AddrInfo();
        ai.setAddr(addr);
        ai.setCityCode(cityCode);
        try {
            if (StringUtils.isNotEmpty(addr)) {
                url = String.format(HttpConstant.HTTP_URL_GEO, ak, opt, cityCode, addr.replaceAll(" ", ""));
                String result = HttpInvokeUtil.sendGet(url);
                if (result == null) {
                    logger.error("geo resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            ai.setLng(resultJson.getString("xcoord"));
                            ai.setLat(resultJson.getString("ycoord"));
                            ai.setPrecision(resultJson.getString("precision"));
                            JSONObject otherJson = resultJson.getJSONObject("other");
                            if (otherJson != null) {
                                ai.setSplit(otherJson.getString("splitResult"));
                            } else {
                                logger.error("geo result is null. url - {}, resp - {}", url, result);
                            }
                        } else {
                            logger.error("geo result is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("geo status = 1. url - {}, resp - {}", url, result);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("request geo error. url: {}, e: {}", url, e);
        }
        return ai;
    }

    /**
     * 地址拆分服务
     *
     * @param param 地址拆分入参
     * @return 地址相关信息
     */
    public static AddrInfo segApiSplit(SegApiSplitIn param) {
        String url = null;
        AddrInfo ai = new AddrInfo();
        ai.setAddr(param.getAddress());
        if (StringUtils.isNotEmpty(param.getAk()) && StringUtils.isNotEmpty(param.getAddress())) {
            try {
                url = UrlUtil.assembleUrl(HttpConstant.HTTP_URL_SEG_API_SPLIT, param);
                String result = HttpInvokeUtil.sendGet(url);
                if (result == null) {
                    logger.error("segApiSplit resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            JSONObject dataJson = resultJson.getJSONObject("data");
                            if (dataJson != null) {
                                ai.setProvince(dataJson.getString("province"));
                                ai.setCity(dataJson.getString("city"));
                                ai.setCounty(dataJson.getString("county"));
                                ai.setTown(dataJson.getString("town"));
                                ai.setAdcode(dataJson.getString("adcode"));
                                ai.setCityCode(dataJson.getString("citycode"));
                                ai.setDetailAddr(dataJson.getString("detailaddr"));
                                ai.setLng(dataJson.getString("lng"));
                                ai.setLat(dataJson.getString("lat"));
                            } else {
                                logger.error("segApiSplit data is null. url - {}, resp - {}", url, result);
                            }
                        } else {
                            logger.error("segApiSplit result is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("segApiSplit status = 1. url - {}, resp - {}", url, result);
                    }
                }
            } catch (Exception e) {
                logger.error("request segApiSplit error. url: {}, e: {}", url, e);
            }
        } else {
            logger.error("request segApiSplit 缺少必填项： {}", param.toString());
        }
        return ai;
    }

    public static AddrInfo atdispatchApi(AtdispatchApiIn param) {
        return atdispatchApi(param, FixedConstant.HTTP_TYPE_PR);
    }

    public static AddrInfo atdispatchApi(AtdispatchApiIn param, String httpType) {
        String url = null;
        String result = null;
        AddrInfo ai = new AddrInfo();
        ai.setAddr(param.getAddress());
        ai.setCityCode(param.getCity());
        if (StringUtils.isNotEmpty(param.getAk()) && StringUtils.isNotEmpty(param.getCity()) && StringUtils.isNotEmpty(param.getAddress())) {
            if (!param.getAddress().startsWith("DE")) {
                param.setAddress(URLEncoder.encode(param.getAddress()));
            }
            try {
                String http = HttpConstant.HTTP_URL_ATDISPATCH_API;
                if (FixedConstant.HTTP_TYPE_RUNDATA.equals(httpType)) {
                    http = HttpConstant.HTTP_URL_RUNDATA_ATDISPATCH_API;
                }
                url = UrlUtil.assembleUrl(http, param);
                result = HttpInvokeUtil.sendGet(url);
                if (result == null) {
                    logger.error("atdispatch/api resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            JSONArray tcsArr = resultJson.getJSONArray("tcs");
                            if (tcsArr != null && tcsArr.size() > 0) {
                                JSONObject tcJson = tcsArr.getJSONObject(0);
                                ai.setZc(tcJson.getString("dept"));
                                ai.setZcSrc(tcJson.getString("atDeptSrc"));
                                ai.setAoiId(tcJson.getString("aoiid"));
                                ai.setAoiCode(tcJson.getString("aoicode"));
                                ai.setAoiSrc(tcJson.getString("atAoiSrc"));
                                ai.setAoiUnit(tcJson.getString("aoiUnit"));
                                ai.setGroupId(tcJson.getString("groupid"));
                            } else {
                                logger.error("atdispatch/api tcs is null. url - {}, resp - {}", url, result);
                            }
                            JSONObject idList = resultJson.getJSONObject("id_list");
                            if (idList != null) {
                                ai.setChknId(idList.getString("chknId"));
                                ai.setNormId(idList.getString("normId"));
                            }
                        } else {
                            logger.error("atdispatch/api result is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("atdispatch/api status = 1. url - {}, resp - {}", url, result);
                    }
                }
            } catch (Exception e) {
                logger.error("request atdispatch/api error. url: {}, result: {}, e: {}", url, result, e);
            }
        } else {
            logger.error("request atdispatch/api 缺少必填项： {}", param.toString());
        }
        return ai;
    }

    /**
     * 收件服务
     * @param param 入参
     * @return 地址相关信息
     */
    public static AddrInfo atconsigneeTeamByaddr(AtconsigneeTeamByaddrIn param) {
        String url = null;
        AddrInfo ai = new AddrInfo();
        ai.setAddr(param.getAddress());
        ai.setCityCode(param.getCity());

        if (StringUtils.isNotEmpty(param.getAk()) && StringUtils.isNotEmpty(param.getCity()) && StringUtils.isNotEmpty(param.getAddress())) {
            try {
                url = UrlUtil.assembleUrl(HttpConstant.HTTP_URL_ATCONSIGNEE_TEAM_BYADDR, param);
                String result = HttpInvokeUtil.sendGet(url);
                if (result == null) {
                    logger.error("atconsignee/team/byaddr resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson == null) {
                        logger.error("atconsignee/team/byaddr rsJson null. url - {}, result - {}", url, result);
                    }else {
                        if (rsJson.getInteger("status") == 0) {
                            JSONObject resultJson = rsJson.getJSONObject("result");
                            if (resultJson != null) {
                                JSONArray tcsArr = resultJson.getJSONArray("tcs");
                                if (tcsArr != null && tcsArr.size() > 0) {
                                    JSONObject tcJson = tcsArr.getJSONObject(0);
                                    ai.setZc(tcJson.getString("dept"));
                                    ai.setZcSrc(tcJson.getString("atDeptSrc"));
                                    ai.setAoiId(tcJson.getString("aoiid"));
                                    ai.setAoiCode(tcJson.getString("aoicode"));
                                    ai.setAoiSrc(tcJson.getString("atAoiSrc"));
                                } else {
                                    logger.error("atconsignee/team/byaddr tcs is null. url - {}, resp - {}", url, result);
                                }
                            } else {
                                logger.error("atconsignee/team/byaddr result is null. url - {}, resp - {}", url, result);
                            }
                        } else {
                            logger.error("atconsignee/team/byaddr status = 1. url - {}, resp - {}", url, result);
                        }
                    }
                }
            } catch (Exception e) {
                logger.error("request atconsignee/team/byaddr error. url: {}, e: {}", url, e);
            }
        } else {
            logger.error("request atconsignee/team/byaddr 缺少必填项： {}", param.toString());
        }
        return ai;
    }

    public static AddrInfo mapb(String ak, String opt, String cityCode, String address) {
        String url = null;
        AddrInfo ai = new AddrInfo();
        ai.setAddr(address);
        ai.setCityCode(cityCode);
        try {
            if (StringUtils.isNotEmpty(address)) {
                url = String.format(HttpConstant.HTTP_URL_MAPB, URLEncoder.encode(address, FixedConstant.CHARSET_UTF), cityCode, ak, opt);
                String result = HttpInvokeUtil.sendGet(url);
                if (result == null) {
                    logger.error("atdispatch resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            JSONObject otherJson = resultJson.getJSONObject("other");
                            if (otherJson != null) {
                                JSONObject normrespJson = otherJson.getJSONObject("normresp");
                                if (normrespJson != null) {
                                    JSONObject resultJsonSec = normrespJson.getJSONObject("result");
                                    if (resultJsonSec != null) {
                                        JSONArray geocoderArray = resultJsonSec.getJSONArray("geocoder");
                                        if (geocoderArray != null && geocoderArray.size() > 0) {
                                            for (int i = 0; i < geocoderArray.size(); i++) {
                                                JSONObject jsonObject = geocoderArray.getJSONObject(i);
                                                String filter = jsonObject.getString("filter");
                                                String level = jsonObject.getString("level");
                                                if (StringUtils.isNotEmpty(filter) && StringUtils.isNotEmpty(level) &&
                                                        (StringUtils.equals(filter, "1") || StringUtils.equals(filter, "2") || StringUtils.equals(filter, "8")) &&
                                                        (StringUtils.equals(level, "GL_COUNTRY") || StringUtils.equals(level, "GL_PROVINCE") || StringUtils.equals(level, "GL_CITY") || StringUtils.equals(level, "GL_COUNTY") ||
                                                                StringUtils.equals(level, "GL_DEV_ZONE") || StringUtils.equals(level, "GL_TOWN") || StringUtils.equals(level, "GL_LINE") || StringUtils.equals(level, "GL_ROAD"))) {
                                                    String x = jsonObject.getString("x");
                                                    String y = jsonObject.getString("y");
                                                    ai.setLng(x);
                                                    ai.setLat(y);
                                                    return ai;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            logger.error("atdispatch result is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("atdispatch status = 1. url - {}, resp - {}", url, result);
                    }
                }
            }
        } catch (Exception e) {
            logger.error("request atdispatch error. url: {}, e: {}", url, e);
        }
        return ai;
    }

    public static String splitResult(String ak, String opt, String cityCode, String address) {
        String url = null;
        String result = "";
        try {
            url = String.format(HttpConstant.HTTP_URL_MAPB, URLEncoder.encode(address, FixedConstant.CHARSET_UTF), cityCode, ak, opt);
            result = HttpInvokeUtil.sendGet(url);
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", url, e);
        }
        return result;
    }

    public static String getSiteByAoi(String aoi) {
        String url = null;
        String site = "";
        try {
            url = String.format(HttpConstant.HTTP_URL_ZC_BY_AOI, aoi);
            String content = HttpInvokeUtil.sendGet(url);
            if (StringUtils.isNotEmpty(content)) {
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null && jsonObject.getInteger("code") == 200) {
                    JSONArray data = jsonObject.getJSONArray("data");
                    if (data != null && data.size() > 0) {
                        JSONObject jsonObject1 = data.getJSONObject(0);
                        String code = jsonObject1.getString("code");
                        if (StringUtils.isNotEmpty(code)) {
                            site = code.split("_")[1];
                        }
                    }
                }
            }
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", url, e);
        }
        return site;
    }

    public static String rlsFnsroutelabel(String address, String cityCode) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("sys_code", "GIS-RLS-CORE");
        jsonObject.put("ak", "3fdbd7a64f1c457faac06e415ca59c98");
        jsonObject.put("showserver", true);

        JSONObject fwOrderInfo = new JSONObject();
        fwOrderInfo.put("waybillNo", "000000000000");
        fwOrderInfo.put("destCityCode", cityCode);
        fwOrderInfo.put("destAddr", address);
        fwOrderInfo.put("sourceCityCode", "571");
        fwOrderInfo.put("sourceDeptCode", "");
        fwOrderInfo.put("sourceAddr", "浙江省杭州市上城区丁兰街道丁兰街道明珠一号3幢");

        jsonObject.put("fwOrderInfo", fwOrderInfo);
        logger.error("jsonObject:{}", jsonObject.toJSONString());
        String result = "";
        try {
            result = HttpInvokeUtil.sendPost(HttpConstant.HTTP_URL_RLS_FNSROUTELABEL, jsonObject.toJSONString());
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", HttpConstant.HTTP_URL_RLS_FNSROUTELABEL, e);
        }
        return result;
    }

    public static String deletergsbaddr(String address, String cityCode, String ak, String operSource, String operUserName, String type) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("ak", ak);
        jsonObject.put("operSource", operSource);
        jsonObject.put("operUserName", operUserName);

        JSONObject addressDel = new JSONObject();
        addressDel.put("cityCode", cityCode);
        addressDel.put("address", address);
        addressDel.put("type", type);
        jsonObject.put("addressDel", addressDel);
        logger.error("jsonObject:{}", jsonObject.toJSONString());
        String result = "";
        try {
            result = HttpInvokeUtil.sendPost(HttpConstant.HTTP_URL_DELETERGSBADDR, jsonObject.toJSONString());
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", HttpConstant.HTTP_URL_DELETERGSBADDR, e);
        }
        return result;
    }

    public static String segErraddress(String address, String emp_code) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("address", address);
        jsonObject.put("emp_code", emp_code);
        logger.error("jsonObject:{}", jsonObject.toJSONString());
        String result = "";
        try {
            result = HttpInvokeUtil.sendPost(HttpConstant.HTTP_URL_SEG_ERRADDRESS, jsonObject.toJSONString());
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", HttpConstant.HTTP_URL_SEG_ERRADDRESS, e);
        }
        return result;
    }

    public static String pushChknWrongAoiTask(String ak, String city, String dept, String aoiid, String address, String taskSource) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("ak", ak);
        jsonObject.put("city", city);
        jsonObject.put("dept", dept);
        jsonObject.put("aoiid", aoiid);
        jsonObject.put("address", address);
        jsonObject.put("taskSource", taskSource);
        logger.error("jsonObject:{}", jsonObject.toJSONString());

        String result = "";
        try {
            result = HttpInvokeUtil.sendPost(HttpConstant.HTTP_URL_PUSHCHKNWRONGAOITASK, jsonObject.toJSONString());
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", HttpConstant.HTTP_URL_PUSHCHKNWRONGAOITASK, e);
        }
        return result;
    }

    public static String pushExportQuery(String cityCode, String date) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.add("KY");
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cityCode", cityCode);
        jsonObject.put("beginDate", date + " " + "00:00:00");
        jsonObject.put("endDate", date + " " + "23:59:59");
        jsonObject.put("staTypes", jsonArray);
        jsonObject.put("pageNo", 1);
        jsonObject.put("pageSize", 5000);

        logger.error("jsonObject:{}", jsonObject.toJSONString());

        String result = "";
        try {
            result = HttpInvokeUtil.sendPost(HttpConstant.HTTP_URL_EXPORTQUERY, jsonObject.toJSONString());
        } catch (Exception e) {
            logger.error("request error. url: {}, e: {}", HttpConstant.HTTP_URL_EXPORTQUERY, e);
        }
        return result;
    }

    public static String getStdAddrByGroupId(String cityCode, String groupId) {
        String url = null;
        String result = "";
        try {
            url = String.format(HttpConstant.HTTP_URL_GROUP, cityCode, groupId);
            result = HttpInvokeUtil.sendGet(url);
        } catch (Exception e) {
            logger.error("request error. url: {}, e: {}", url, e);
        }
        return result;
    }

    public static String getNormAddr(String address, String cityCode, String ak, String opt) {
        String url = null;
        String result = "";
        try {
            url = String.format(HttpConstant.HTTP_URL_NORMAL, URLEncoder.encode(address, FixedConstant.CHARSET_UTF), cityCode, ak, opt);
            result = HttpInvokeUtil.sendGet(url);
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", url, e);
        }
        return result;
    }

    public static String getAddrSimilarity(String ak, String beforeAddr, String afterAddr) {
        String url = null;
        String result = "";
        try {
            url = String.format(HttpConstant.HTTP_URL_ADDR_SIMILARITY, ak, URLEncoder.encode(beforeAddr, FixedConstant.CHARSET_UTF), URLEncoder.encode(afterAddr, FixedConstant.CHARSET_UTF));
            logger.error("url:{}", url);
            result = HttpInvokeUtil.sendGet(url);
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", url, e);
        }
        return result;
    }

    public static String getfwWaybill(String fwWaybill) {
        String url = null;
        String result = "";
        try {
            url = String.format(HttpConstant.HTTP_URL_QUERYFWWAYBILL, fwWaybill);
            logger.error("url:{}", url);
            result = HttpInvokeUtil.sendGet(url);
        } catch (Exception e) {
            logger.error("request split error. url: {}, e: {}", url, e);
        }
        return result;
    }

    public static String rgsbAdd(String ak, String address, String cityCode, String znoCode, String aoiId, String operSource, String operUserName) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("ak", ak);
        jsonObject.put("operSource", operSource);
        jsonObject.put("operUserName", operUserName);
        JSONObject addressSave = new JSONObject();
        addressSave.put("cityCode", cityCode);
        addressSave.put("address", address);
        addressSave.put("znoCode", znoCode);
        addressSave.put("aoiId", aoiId);
        addressSave.put("zcCheck", 1);
        addressSave.put("type", 1);
        jsonObject.put("addressSave", addressSave);
        logger.error("jsonObject:{}", jsonObject.toJSONString());
        String result = "";
        try {
            result = HttpInvokeUtil.sendPostNew(HttpConstant.HTTP_URL_RGSBADD, jsonObject.toJSONString(), FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request error. url: {}, e: {}", HttpConstant.HTTP_URL_RGSBADD, e);
        }
        return result;
    }

    /**
     * 根据地址获取坐标
     *
     * @param ak       ak
     * @param opt      opt: normdetail
     * @param cityCode 城市编码
     * @param address  地址
     * @return 标准化地址
     */
    public static StandardAddrInfo atdispatchNormal(String ak, String opt, String cityCode, String address) {
        String url = null;
        StandardAddrInfo sd = new StandardAddrInfo();
        try {
            url = String.format(HttpConstant.HTTP_URL_ATDISPATCH_NORMAL, ak, opt, cityCode, URLEncoder.encode(address, FixedConstant.CHARSET_UTF));
            String result = HttpInvokeUtil.sendGet(url);
            if (result == null) {
                logger.error("atdispatchNormal resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                sd.setResult(rsJson.toJSONString());
                if (rsJson.getInteger("status") == 0) {
                    String resultStr = rsJson.getString("result");
                    if (resultStr != null && resultStr.length() > 2) {
                        String resultStr_1 = resultStr.replaceAll("\\[", "").replaceAll("\\]", "");
                        String[] resArr = resultStr_1.split(",");
                        if (resArr != null && resArr.length > 0) {
                            sd.setStandardAddr(resArr[0]);
                        } else {
                            logger.error("atdispatchNormal resArr is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("atdispatchNormal resultStr is null. url - {}, resp - {}", url, result);
                    }
                } else {
                    logger.error("atdispatchNormal status = 1. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request atdispatchNormal error. url: {}, e: {}", url, e);
        }
        return sd;
    }

    public static AddrInfo arApi(ArApiIn param) {
        String url = null;
        AddrInfo ai = new AddrInfo();
        if (StringUtils.isNotEmpty(param.getAk()) && StringUtils.isNotEmpty(param.getAddress())) {
            try {
                url = UrlUtil.assembleUrl(HttpConstant.HTTP_URL_AR_API, param);
                String result = HttpInvokeUtil.sendGet(url);
                if (result == null) {
                    logger.error("arApi resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject districtJson = rsJson.getJSONObject("district");
                        if (districtJson != null) {
                            ai.setProvince(districtJson.getString("province"));
                            ai.setCity(districtJson.getString("city"));
                            ai.setCounty(districtJson.getString("county"));
                            ai.setTown(districtJson.getString("town"));
                            ai.setVillage(districtJson.getString("village"));
                            ai.setDetailInfo(districtJson.getString("detailinfo"));
                        }
                        JSONObject extentionJson = rsJson.getJSONObject("extention");
                        if (extentionJson != null) {
                            ai.setKeyword(extentionJson.getString("key"));
                        }
                        ai.setCityCode(rsJson.getString("city_code"));
                        ai.setDetailAddr(rsJson.getString("detail_addr"));
                    } else {
                        logger.error("arApi resp null. url - {}, result - {}", url, result);
                    }
                }
            } catch (Exception e) {
                logger.error("request arApi error. url: {}, e: {}", url, e);
            }
        } else {
            logger.error("request arApi 缺少必填项： {}", param.toString());
        }
        return ai;
    }

    public static AddrInfo rdsksApiGetTeam(RdsksApiGetTeamIn param, int maxTryTime) {
        String url = null;
        AddrInfo ai = new AddrInfo();
        ai.setAddr(param.getAddress());
        ai.setCityCode(param.getCity());
        if (StringUtils.isNotEmpty(param.getAk()) && StringUtils.isNotEmpty(param.getCity()) && StringUtils.isNotEmpty(param.getAddress())) {
            try {
                url = UrlUtil.assembleUrl(HttpConstant.HTTP_URL_RDSKS_API_GETTEAM, param);
                String result = HttpInvokeUtil.sendGet(url, maxTryTime);
                if (result == null) {
                    logger.error("rdsks/api/getTeam resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson != null && rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            ai.setAoiId(resultJson.getString("aoi"));
                            ai.setAoiCode(resultJson.getString("aoiCode"));
                            ai.setAoiSrc(resultJson.getString("aoiTag"));
                            ai.setZc(resultJson.getString("dept"));
                            ai.setZcSrc(resultJson.getString("zcTag"));
                        } else {
                            logger.error("rdsks/api/getTeam result is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("rdsks/api/getTeam status != 0. url - {}, resp - {}", url, result);
                    }
                }
            } catch (Exception e) {
                logger.error("request rdsks/api/getTeam error. url: {}, e: {}", url, e);
            }
        } else {
            logger.error("request rdsks/api/getTeam 缺少必填项： {}", param.toString());
        }
        return ai;
    }

    public static ChkQueryTcTeamCodeOut chkQueryTcTeamCode(ChkQueryTcTeamCodeIn paramIn){
        ChkQueryTcTeamCodeOut cqOut = new ChkQueryTcTeamCodeOut();
        cqOut.setSysOrderNo(paramIn.getSysOrderNo());
        cqOut.setCityCode(paramIn.getCityCode());
        cqOut.setAddress(paramIn.getAddress());
        if (StringUtils.isNotEmpty(paramIn.getAk()) && StringUtils.isNotEmpty(paramIn.getSysCode()) && StringUtils.isNotEmpty(paramIn.getCityCode()) && StringUtils.isNotEmpty(paramIn.getAddressType()) && StringUtils.isNotEmpty(paramIn.getAddress())) {
            String result = null;
            try {
                String param = JSONObject.toJSONString(paramIn);
                result = HttpInvokeUtil.sendPostRetCode(HttpConstant.HTTP_URL_CHKQUERY_TC_TEAMCODE, param, FixedConstant.MAX_TRY_TIME_THREE);
                cqOut.setRs(result);
                if (result == null) {
                    logger.error("chkquery/tc/teamCode resp null. url - {}, param - {}, rs - {}", HttpConstant.HTTP_URL_CHKQUERY_TC_TEAMCODE, param, result);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson != null) {
                        cqOut.setDeptCode(rsJson.getString("deptCode"));
                        cqOut.setTeamCode(rsJson.getString("teamCode"));
                        cqOut.setAoiId(rsJson.getString("aoiId"));
                        cqOut.setAoiCode(rsJson.getString("aoiCode"));
                        cqOut.setAoiAreaCode(rsJson.getString("aoiAreaCode"));
                        cqOut.setAoiUnit(rsJson.getString("aoiUnit"));
                        cqOut.setAddressKeyword(rsJson.getString("addressKeyword"));
                        cqOut.setLpTransCode(rsJson.getString("lpTransCode"));
                        cqOut.setAoiTypeCode(rsJson.getString("aoiTypeCode"));
                        cqOut.setVirMapArea(rsJson.getString("virMapArea"));
                        cqOut.setVirMapAreaMode(rsJson.getString("virMapAreaMode"));
                        cqOut.setVirMapDept(rsJson.getString("virMapDept"));
                        cqOut.setVirMapCustMark(rsJson.getString("virMapCustMark"));
                        cqOut.setAoiAreaGroup(rsJson.getString("aoiAreaGroup"));
                        cqOut.setDeptGroup(rsJson.getString("deptGroup"));
                        cqOut.setInnerMark(rsJson.getString("innerMark"));
                        cqOut.setVillageCode(rsJson.getString("villageCode"));
                        cqOut.setVillageClassCode(rsJson.getString("villageClassCode"));
                        cqOut.setVillageFlag(rsJson.getString("villageFlag"));
                        cqOut.setVillageTownDist(rsJson.getString("villageTownDist"));
                        cqOut.setOriginDept(rsJson.getString("originDept"));
                        cqOut.setAoiAreaGroupPf(rsJson.getString("aoiAreaGroupPf"));
                        cqOut.setPoiIds(rsJson.getString("poiIds"));
                        cqOut.setPoiLevel(rsJson.getString("poiLevel"));
                        cqOut.setAppliedAoiId(rsJson.getString("appliedAoiId"));
                        cqOut.setAppliedAoiCode(rsJson.getString("appliedAoiCode"));
                        cqOut.setAppliedAoiTypeCode(rsJson.getString("appliedAoiTypeCode"));
                        cqOut.setAppliedAoiInfo(rsJson.getString("appliedAoiInfo"));
                    } else {
                        logger.error("chkquery/tc/teamCode rsJson null. url - {}, param - {}, rs - {}", HttpConstant.HTTP_URL_CHKQUERY_TC_TEAMCODE, param, result);
                    }
                }
            } catch (Exception e) {
                logger.error("request chkquery/tc/teamCode error. url - {}, param - {}, rs - {}", HttpConstant.HTTP_URL_CHKQUERY_TC_TEAMCODE, paramIn.toString(), result);
            }
        } else {
            logger.error("request chkquery/tc/teamCode 缺少必填项： {}", paramIn.toString());
        }
        return cqOut;
    }

    public static void main(String[] args) {
//        AtconsigneeTeamByaddrIn param = new AtconsigneeTeamByaddrIn();
//        param.setAk("0376a9aa84724dd2a995f858dd963346");
//        param.setOpt("zh");
//        param.setCallDispatch("1");
//        param.setIsNotUnderCall("1");
//        param.setNeedAoiArea("1");
//        param.setProvince(StrUtils.processInvalidCharacter("广东省 "));
//        param.setCity("755");
//        param.setDistrict("南山区 ");
//        param.setAddress("广东省深圳市南山区软件产业基地1栋A座");
//        param.setTel("DEEQAVTk7mJd7HYPVPH6rGHzhM3LA%3D");
//        param.setMobile("DEEQAVTk7mJd7HYPVPH6rGHzhM3LA%3D");
//        param.setCompany(StrUtils.processInvalidCharacter("广东省韶关市浈江区风采街道\n维也纳酒店停车场旁,边梦\t之馨70号"));
//        param.setContacts("杨芳翠 ");
//        param.setCustomerAccount("7550215247");
//        AddrInfo aoi = AddrApi.atconsigneeTeamByaddr(param);
//        System.out.println(aoi.toString());
//        System.out.println(arApi("吉林省长春市吉林省长春市双阳区泰富F区十二号楼", "ffc9595f015e4d2a96b565fc2dc1157a"));
        ChkQueryTcTeamCodeIn paramIn = new ChkQueryTcTeamCodeIn();
        paramIn.setAk("c28d9ad462a8493e8e6fd968d601598d");
        paramIn.setAddress("莲花街道彩田路3001号彩福大厦");
        paramIn.setCityCode("755");
        paramIn.setProvince("浙江省");
        paramIn.setCity("金华市");
        paramIn.setCounty("义乌市");
        paramIn.setSysOrderNo("ba940df65bda7bc0aaba2d89a5187c21_1");
        paramIn.setPhone("DEEQAVTj89Zm0eApzZKu0541NNg4E");
        paramIn.setContactsName("唯品会");
        paramIn.setMobile("DEEQAVTj89Zm0eApzZKu0541NNg4E");
        paramIn.setCompany("唯品会（中国）有限公司");
        paramIn.setCustomerAccount("5125882630");
        ChkQueryTcTeamCodeOut result = chkQueryTcTeamCode(paramIn);
        System.out.println(result.toString());
    }
}

