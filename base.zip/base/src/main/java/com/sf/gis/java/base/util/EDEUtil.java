package com.sf.gis.java.base.util;

import org.apache.commons.codec.digest.DigestUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.security.MessageDigest;

/**
 * 加解密工具类
 * @author 01370539 created on Aug.19 2021
 */
public class EDEUtil {
    private static final Logger logger = LoggerFactory.getLogger(EDEUtil.class);

	public static void main(String[] args) throws Exception{
        System.out.println(DigestUtils.md5Hex("广东省深圳市龙岗区南湾街道上李郎村第二工业区F栋五楼海威讯电子有限公司"));
	}

	/**
	 * 简单加密解密算法 执行一次加密，两次解密
	 */
	public static String enAndDeSimple(String inStr) {

		char[] a = inStr.toCharArray();
		for (int i = 0; i < a.length; i++) {
			a[i] = (char) (a[i] ^ 't');
		}
		return  new String(a);
	}

}
