package com.sf.gis.java.base.util;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.*;
import org.apache.spark.SparkConf;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-08-17 16:14
 * @TaskId:
 * @TaskName:
 * @Description: 工具类, 用于上传接口访问记录,用于记录一次接口调用的开始和结束信息
 * <p>
 * 请务必在driver线程中使用
 */
public class BdpTaskRecordUtil {
    private static final Logger logger = LoggerFactory.getLogger(BdpTaskRecordUtil.class);
    //生产环境
    private static String tokenUrl = "http://gis-ass-oms-uimp.sf-express.com:8090/uimp/api/common/token";
    private static String addNetworkRecordUrl = "http://gis-ass-oms-uimp.sf-express.com:8090/uimp/api/outer/sim/bdp_invoke_http_detail/add";
    private static String updateNetworkRecordUrl = "http://gis-ass-oms-uimp.sf-express.com:8090/uimp/api/outer/sim/bdp_invoke_http_detail/update";

    private static String addBdpTaskRecordUrl = "http://gis-ass-oms-uimp.sf-express.com:8090/uimp/api/outer/sim/bdp_task_detail/add";
    private static String updateBdpTaskRecordUrl = "http://gis-ass-oms-uimp.sf-express.com:8090/uimp/api/outer/sim/bdp_task_detail/update";

    //    private static Boolean isTest = true;
//    static {
//        if (isTest) {
//            //测试环境
//            tokenUrl = "http://gis-ass-oms-uimp.sit.sf-express.com:8088/uimp/api/common/token";
//            addNetworkRecordUrl = "http://gis-ass-oms-uimp.sit.sf-express.com:8088/uimp/api/outer/sim/bdp_invoke_http_detail/add";
//            updateNetworkRecordUrl = "http://gis-ass-oms-uimp.sit.sf-express.com:8088/uimp/api/outer/sim/bdp_invoke_http_detail/update";
//            addBdpTaskRecordUrl = "http://gis-ass-oms-uimp.sit.sf-express.com:8088/uimp/api/outer/sim/bdp_task_detail/add";
//            updateBdpTaskRecordUrl = "http://gis-ass-oms-uimp.sit.sf-express.com:8088/uimp/api/outer/sim/bdp_task_detail/update";
//        }
//    }
    //用于访问接口的token，有效期限30天
    private static String token = null;

    /**
     * 开始此次网络接口调用 前使用
     *
     * @param account:            工号
     * @param taskId：             任务id
     * @param taskName:           任务名称
     * @param taskDescription     : 任务描述
     * @param httpUrl             ：接口url
     * @param httpAk              ： ak
     * @param dataCnt             ： 即将调用的接口的数据总量
     * @param invokeThreadCnt：并发数
     * @return id: 用于标识此次上传的唯一id，后续使用此id做结束更新
     */
    public static String startRunNetworkInterface(
            SparkSession spark,
            String account, String taskId, String taskName, String taskDescription, String httpUrl,
            String httpAk, long dataCnt, int invokeThreadCnt) {
        try {
            String urlStandard = standardUrl(httpUrl);
            NetAccessRecordAddParm parm = new NetAccessRecordAddParm(taskId, taskName, taskDescription, urlStandard, httpAk, dataCnt, invokeThreadCnt);
            parm.setTaskOwner(account);
            updateExcutorInfo(parm, spark, taskId);
            parm.checkEmpty();
//            if (StrUtils.isBlank(token)) {
            token = queryToken(account);
//            }
            if (StrUtils.isBlank(token)) {
                logger.error("*******************获取到token为空，请与服务平台联系***************");
                return null;
            }

            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("Authorization", "Bearer " + token);
            String retStr = HttpConnection.httpPost(3, addNetworkRecordUrl, JSON.toJSONString(parm), headerMap);
            NetAccessRecordResp retJson = JSON.parseObject(retStr, NetAccessRecordResp.class);
            if (retJson.getCode() != 0) {
                logger.error("retJson:" + retJson.getMsg());
                logger.error("************接口记录接口-开始-失败**********");
            }
            return retJson.getData();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 此次接口调用结束
     *
     * @param account : 账号/工号，用于获取tocken
     * @param id：     开始时上传记录返回的id
     * @return
     */
    public static void endNetworkInterface(String account, String id) {
        try {
            NetAccessRecordEndParm netAccessRecordEndParm = new NetAccessRecordEndParm(id);
            netAccessRecordEndParm.checkEmpty();
            if (StrUtils.isBlank(token)) {
                token = queryToken(account);
            }
            if (StrUtils.isBlank(token)) {
                logger.error("*******************获取到token为空，请与服务平台联系***************");
                return;
            }

            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("Authorization", "Bearer " + token);
            String retStr = HttpConnection.httpPost(3, updateNetworkRecordUrl, JSON.toJSONString(netAccessRecordEndParm), headerMap);
            NetAccessRecordResp retJson = JSON.parseObject(retStr, NetAccessRecordResp.class);
            if (retJson.getCode() != 0) {
                logger.error("retJson:" + retJson.getMsg());
                logger.error("************接口记录接口-更新-失败**********");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return;
    }


    /**
     * 开始bdp任务时调用
     *
     * @param account:        工号
     * @param taskId：         任务id
     * @param taskName:       任务名称
     * @param taskDescription : 任务描述
     * @return id: 用于标识此次上传的唯一id，后续使用此id做结束更新
     */
    private static String startBdpTask(
            SparkSession spark,
            String account, String taskId, String taskName, String taskDescription) {
        try {
            BdpTaskRecordAddParm parm = new BdpTaskRecordAddParm(taskId, taskName, taskDescription);
            parm.setTaskOwner(account);
            updateExcutorInfo(parm, spark, taskId);
            parm.checkEmpty();
            if (StrUtils.isBlank(token)) {
                token = queryToken(account);
            }
            if (StrUtils.isBlank(token)) {
                logger.error("*******************获取到token为空，请与服务平台联系***************");
                return null;
            }

            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("Authorization", "Bearer " + token);
            String retStr = HttpConnection.httpPost(3, addBdpTaskRecordUrl, JSON.toJSONString(parm), headerMap);
            NetAccessRecordResp retJson = JSON.parseObject(retStr, NetAccessRecordResp.class);
            if (retJson.getCode() != 0) {
                logger.error("retJson:" + retJson.getMsg());
                logger.error("************BDP任务记录接口-开始-失败**********");
            }
            return retJson.getData();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 此次bdp任务调用结束
     *
     * @param account : 账号/工号，用于获取tocken
     * @param id：     开始时上传记录返回的id
     * @return
     */
    private static void endBdpTask(String account, String id) {
        try {
            NetAccessRecordEndParm netAccessRecordEndParm = new NetAccessRecordEndParm(id);
            netAccessRecordEndParm.checkEmpty();
            if (StrUtils.isBlank(token)) {
                token = queryToken(account);
            }
            if (StrUtils.isBlank(token)) {
                logger.error("*******************获取到token为空，请与服务平台联系***************");
                return;
            }

            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("Authorization", "Bearer " + token);
            String retStr = HttpConnection.httpPost(3, updateBdpTaskRecordUrl, JSON.toJSONString(netAccessRecordEndParm), headerMap);
            NetAccessRecordResp retJson = JSON.parseObject(retStr, NetAccessRecordResp.class);
            if (retJson.getCode() != 0) {
                logger.error("retJson:" + retJson.getMsg());
                logger.error("************BDP任务记录接口-更新-失败**********");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return;
    }


    /**
     * 获取token
     *
     * @param account 账号：填写工号
     * @return token 字符串
     */
    private static String queryToken(String account) {
        NetAccessRecordTokenParm tokenParm = new NetAccessRecordTokenParm(account);
        try {
            String retStr = HttpConnection.httpPost(3, tokenUrl, JSON.toJSONString(tokenParm));
            NetAccessRecordResp retJson = JSON.parseObject(retStr, NetAccessRecordResp.class);
            return retJson.getData();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    private static int converUnit(String mem) {
        if (mem.endsWith("G") || mem.endsWith("g")) {
            Integer memInt = Integer.valueOf(mem.substring(0, mem.length() - 1));
            return memInt;
        } else if (mem.endsWith("M") || mem.endsWith("m")) {
            Integer memInt = Integer.valueOf(mem.substring(0, mem.length() - 1)) / 1024;
            return memInt;
        }
        return 0;
    }

    private static void updateExcutorInfo(BdpTaskRecordAddParm parm, SparkSession spark, String taskId) {
        if (spark == null) {
            logger.error("非spark任务");
            return;
        }
        SparkConf sparkConf = spark.sparkContext().getConf();
        Integer excutorCore = Integer.valueOf(sparkConf.get("spark.executor.cores", "0"));
        Integer excutorInstance = Integer.valueOf(sparkConf.get("spark.executor.instances", "0"));
        String excutorMemory = sparkConf.get("spark.executor.memory", "0");
        logger.error("excutorMemory:" + excutorMemory);
        String excutorOverhead = sparkConf.get("spark.executor.memoryOverhead", "0");
        logger.error("excutorOverhead:" + excutorOverhead);
        parm.setTaskExeCores(excutorCore);
        parm.setTaskExeInstance(excutorInstance);
        parm.setTaskExeMem(converUnit(excutorMemory));
        parm.setTaskExeOhMem(converUnit(excutorOverhead));
        if (sparkConf.contains("spark.sf.userId")) {
            String userId = sparkConf.get("spark.sf.userId");
            if (!StrUtils.isBlank(userId)) {
                parm.setTaskOwner(userId);
            }
        }

        try {
            if (sparkConf.contains("spark.jars")) {
                String userDir = sparkConf.get("spark.jars");
                if (!StrUtils.isBlank(userDir) && !StrUtils.isBlank(taskId)) {
                    if (!userDir.contains(taskId)) {
                        parm.setTaskDescription("此任务id疑似异常，请参考以下数据id:" + userDir + "--" + parm.getTaskDescription());
                    }
                }
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }


    }

//    private static String extendDesc(SparkSession spark, String taskDescription) {
//        JSONObject json = new JSONObject();
//        json.put("description", taskDescription);
//        SparkConf sparkConf = spark.sparkContext().getConf();
//        Integer excutorCore = Integer.valueOf(sparkConf.get("spark.executor.cores", "0"));
//        Integer excutorInstance = Integer.valueOf(sparkConf.get("spark.executor.instances", "0"));
//        String excutorMemory = sparkConf.get("spark.executor.memory", "0");
//        String excutorOverhead = sparkConf.get("spark.executor.memoryOverhead", "0");
//        json.put("resource", excutorCore + "," + excutorInstance + "," + excutorMemory + "," + excutorOverhead);
//        return json.toJSONString();
//    }

    /**
     * 标准化url
     *
     * @param inputUrl 输入url
     * @return 标准化后的url
     */
    private static String standardUrl(String inputUrl) {
        if (StrUtils.isBlank(inputUrl)) {
            logger.error("*******************所填网址为空，请注意是否填错***************");
            return inputUrl;
        }
        String standardUrl = inputUrl;
        if (!standardUrl.startsWith("http")) {
            standardUrl = "http://" + standardUrl;
        }
        if (standardUrl.contains("?")) {
            standardUrl = standardUrl.split("\\?")[0];
        }
        return standardUrl;
    }


    private static void main(String[] args) {
//        SparkConf conf = new SparkConf().setAppName("dd");
//        SparkSession sparksesison = SparkSession.builder().config(conf).getOrCreate();
//        String bdpTaskId = startBdpTask(sparksesison, "01374443", "1221", "我只是个测试", "这个任务好");
//            System.out.println(bdpTaskId);
//            String id = startRunNetworkInterface(sparksesison, "01374443", "1221", "我只是个测试", "这个接口好",
//                    "http://dd",
//                    "1234567890123456", 12, 1);
//            System.out.println(id);
//            endNetworkInterface("01374443", id);
        endBdpTask("01374443", null);
//        System.out.println(standardUrl("http://ddd?ggg=hhh"));
    }

}
