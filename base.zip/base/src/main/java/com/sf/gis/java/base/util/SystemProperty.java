package com.sf.gis.java.base.util;

public class SystemProperty {
    public static String fileSeparator = System.getProperty("file.separator");
    public static String homeDir = System.getProperty("user.dir");

}
