package com.sf.gis.java.base.svc;

import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.csvreader.CsvReader;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ConfigUtil;

/**
 * 国家行政区域信息获取服务类
 * @author 01370539 Created on Apr.30 2021
 */
public class AdminAreaService {
	private final Logger logger = LoggerFactory.getLogger(AdminAreaService.class);

    /**
     * get admin area info from csv
     * @param jsc JavaSparkContext
     * @return 行政区域相关信息
     */
	public Broadcast<Map<String, Map<String, String>>> getCityMapFromCSV(JavaSparkContext jsc) {
		Broadcast<Map<String, Map<String, String>>> cityBc = null;
		try (InputStream in = ConfigUtil.getConfStream("admin_area.csv")) {
			CsvReader reader = new CsvReader(in, ',', Charset.forName(FixedConstant.CHARSET_UTF));
			reader.readHeaders();
			reader.setSafetySwitch(false);

            Map<String, String> cityNameMap = new HashMap<>();
            Map<String, String> cityRegionMap = new HashMap<>();
            String cityname;
			while (reader.readRecord()) {
				cityname = cityNameMap.get(reader.get("citycode"));
                cityNameMap.put(reader.get("citycode"), StringUtils.isEmpty(cityname) ? reader.get("city") : (cityname + "|" + reader.get("city")));
                cityRegionMap.put(reader.get("citycode"), reader.get("region"));
			}
			reader.close();
			Map<String, Map<String, String>> cityMap = new HashMap<>();
			cityMap.put(FixedConstant.LOG_STAT_AA_CITY, cityNameMap);
			cityMap.put(FixedConstant.LOG_STAT_AA_REGION, cityRegionMap);
			cityBc = jsc.broadcast(cityMap);
		} catch (Exception e) {
			logger.error("getCityMapFromCSV execute error. ", e);
		}
		return cityBc;
	}

}
