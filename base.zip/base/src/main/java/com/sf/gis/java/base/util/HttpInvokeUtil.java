package com.sf.gis.java.base.util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.pathSimilar.Tuple2;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * HTTP调用工具类
 *
 * @author 01370539 Created On: May.07 2021
 */
public class HttpInvokeUtil {

    private static final Logger logger = LoggerFactory.getLogger(HttpInvokeUtil.class);

    private static final PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static CloseableHttpClient httpClient = null;
    private static boolean isInitConnection = false;

    static {
        initConnectionManager();
    }

    /**
     * 初始化连接池
     */
    public static void initConnectionManager() {
        try {
            connManager.setMaxTotal(5); // 设置整个连接池最大连接数 根据自己的场景决定
            // 是路由的默认最大连接（该值默认为2），限制数量实际使用DefaultMaxPerRoute并非MaxTotal。设置过小无法支持大并发(ConnectionPoolTimeoutException: Timeout waiting for connection from pool)，路由是对maxTotal的细分。
            connManager.setDefaultMaxPerRoute(5);// （目前只有一个路由，因此让他等于最大值）
            SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setSoTimeout(30000).setTcpNoDelay(true).build();
            connManager.setDefaultSocketConfig(socketConfig);

            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(30000).setConnectTimeout(30000).setSocketTimeout(30000).build();
            httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(connManager).build();
        } catch (Exception e) {
            logger.error("initConnectionManager error. ", e);
        }
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限，默认编码：UTF-8; 当结果为空时，默认会重试一次
     * @param url 请求的url
     * @return 请求结果
     */
    public static String sendGet(String url) {
        return sendGet(url, FixedConstant.CHARSET_UTF, FixedConstant.MAX_TRY_TIME_ONCE);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限; 当结果为空时，默认会重试一次
     * @param url 请求的url
     * @param charset 编码格式
     * @return 请求结果
     */
    public static String sendGet(String url, String charset) {
        return sendGet(url, charset, FixedConstant.MAX_TRY_TIME_ONCE);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限，默认编码：UTF-8
     * @param url 请求的url
     * @param maxTryTime 当返回结果为空时的尝试次数
     * @return 请求结果
     */
    public static String sendGet(String url, int maxTryTime) {
        return sendGet(url, FixedConstant.CHARSET_UTF, maxTryTime);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限
     * @param url 请求的url
     * @param charset 编码格式
     * @param maxTryTime 当返回结果为空时的尝试次数
     * @return 请求结果
     */
    public static String sendGet(String url, String charset, int maxTryTime) {
        Map<String, String> headerMap = null;
        return sendGet(url, headerMap, charset, maxTryTime);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限，默认编码：UTF-8; 当结果为空时，默认会重试一次
     * @param url 请求的url
     * @param headerKey header参数
     * @param headerValue header参数值
     * @return 请求结果
     */
    public static String sendGet(String url, String headerKey, String headerValue) {
        return sendGet(url, headerKey, headerValue, FixedConstant.CHARSET_UTF, FixedConstant.MAX_TRY_TIME_ONCE);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限，默认编码UTF-8; 当结果为空时，默认会重试一次
     * @param url 请求的url
     * @param headerMap header中要添加的参数
     * @return 请求结果
     */
    public static String sendGet(String url, Map<String, String> headerMap) {
        return sendGet(url, headerMap, FixedConstant.CHARSET_UTF, FixedConstant.MAX_TRY_TIME_ONCE);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限; 当结果为空时，默认会重试一次
     * @param url 请求的url
     * @param headerKey header参数
     * @param headerValue header参数值
     * @param charset 编码格式
     * @return 请求结果
     */
    public static String sendGet(String url, String headerKey, String headerValue, String charset) {
        return sendGet(url, headerKey, headerValue, charset, FixedConstant.MAX_TRY_TIME_ONCE);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限; 当结果为空时，默认会重试一次
     * @param url 请求的url
     * @param headerMap header中要添加的参数
     * @param charset 编码格式
     * @return 请求结果
     */
    public static String sendGet(String url, Map<String, String> headerMap, String charset) {
        return sendGet(url, headerMap, charset, FixedConstant.MAX_TRY_TIME_ONCE);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限, 默认编码格式：UTF-8
     * @param url 请求的url
     * @param headerKey header参数
     * @param headerValue header参数值
     * @param maxTryTime 当返回结果为空时的尝试次数
     * @return 请求结果
     */
    public static String sendGet(String url, String headerKey, String headerValue, int maxTryTime) {
        return sendGet(url, headerKey, headerValue, FixedConstant.CHARSET_UTF, maxTryTime);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限, 默认编码格式：UTF-8
     * @param url 请求的url
     * @param headerMap header中要添加的参数
     * @param maxTryTime 当返回结果为空时的尝试次数
     * @return 请求结果
     */
    public static String sendGet(String url, Map<String, String> headerMap, int maxTryTime) {
        return sendGet(url, headerMap, FixedConstant.CHARSET_UTF, maxTryTime);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限
     * @param url 请求的url
     * @param headerKey header参数
     * @param headerValue header参数值
     * @param charset 编码格式
     * @param maxTryTime 当返回结果为空时的尝试次数
     * @return 请求结果
     */
    public static String sendGet(String url, String headerKey, String headerValue, String charset, int maxTryTime) {
        Map<String, String> headerMap = null;
        if (StringUtils.isNotEmpty(headerKey) && StringUtils.isNotEmpty(headerValue)) {
            headerMap = new HashMap<>();
            headerMap.put(headerKey, headerValue);
        }
        return sendGet(url, headerMap, charset, maxTryTime);
    }

    /**
     * get请求，AK受限时会休眠5s并重复调用，直到AK不受限
     * @param url 请求的url
     * @param headerMap header中要添加的参数
     * @param charset 编码格式
     * @param maxTryTime 当返回结果为空时的尝试次数
     * @return 请求结果
     */
    public static String sendGet(String url, Map<String, String> headerMap, String charset, int maxTryTime) {
        String jsonStr = getReq(url, headerMap, charset);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(jsonStr) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                jsonStr = getReq(url, headerMap, charset);
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(jsonStr), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                jsonStr = getReq(url, headerMap, charset);
            }
        } catch (Exception e) {
        }
        return jsonStr;
    }

    /**
     * get请求
     * @param url 请求的url
     * @param headerMap header中要添加的参数
     * @param charset 编码格式
     * @return 请求结果
     */
    private static String getReq(String url, Map<String, String> headerMap, String charset) {
        logger.debug("start send get req with header, url - {}.", url);
        String result = "";
        HttpGet httpGet = null;
        CloseableHttpResponse httpResp = null;
        HttpEntity httpEntity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }
            httpGet = new HttpGet(url);
            if (headerMap != null) {
                for (String key : headerMap.keySet()) {
                    httpGet.addHeader(key, headerMap.get(key));
                }
            }
            httpResp = httpClient.execute(httpGet);
            httpEntity = httpResp.getEntity();
            result = EntityUtils.toString(httpEntity, charset);
        } catch (Exception e) {
            logger.error("execute access http get url err. " + url, e);
            return result;
        } finally {
            try {
                if (result != null) {
                    if (httpGet != null) {
                        EntityUtils.consume(httpEntity);
                        httpGet.releaseConnection();
                    }
                    if (httpResp != null) {
                        httpResp.close();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        logger.debug("end get req， url - {}.", url);
        return result;
    }

    public static String sendPost2(String url, String param, int maxTryTime) {
        String content = sendPost(url, param);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                content = sendPost(url, param);
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(content))) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = sendPost(url, param);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    public static String sendPostNew(String url, String param, int maxTryTime) {
        String content = sendPost(url, param);
        int tryTime = 0;
        try {
            while ((StringUtils.isEmpty(content) || (StringUtils.isNotEmpty(content) && content.contains("false"))) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                content = sendPost(url, param);
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            JSONObject jsonObject = JSONObject.parseObject(content);
            while (isAcTime(jsonObject, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = sendPost(url, param);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }
    public static String sendPostOld(String req, String param, int maxTryTime) {
        String content = sendPost(req, param);
        int tryTime = 0;
        while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            logger.error("try time {}: {}", maxTryTime, req);
            content = sendPost(req, param);
        }
        return content;
    }
    public static void main(String[] args) throws Exception {
//        String url = "http://10.119.72.210:8080/ac_web/nc/reqGet/http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?ak=0376a9aa84724dd2a995f858dd963346&opt=zh&needAoiArea=1&callDispatch=1&isNotUnderCall=1&province=甘肃省&city=939&district=礼县&address=%E7%94%98%E8%82%83%E7%9C%81%E9%99%87%E5%8D%97%E5%B8%82%E7%A4%BC%E5%8E%BF%E5%9F%8E%E5%85%B3%E9%95%87%E5%98%89%E5%85%B4%E5%98%89%E5%9B%AD&tel=DEEQAVTu1I1z0%2FhQdj4JogIy30VgU%3D&mobile=DEEQAVTu1I1z0%2FhQdj4JogIy30VgU%3D&contacts=姜莉萍";
//        System.out.println("1-------------" + sendGet(url));
//        System.out.println("2-------------" + sendGet(url,2));
//        System.out.println("3-------------" + sendGet(url,"UTF-8"));
//        System.out.println("4-------------" + sendGet(url,"UTF-8",2));
//        url = "http://10.207.13.111:8080/transform/gd/queryPoi?keywords=广东省深圳市软件产业基地1栋A座";
//        System.out.println("5-------------" + sendGet(url, "ak", "8bb09e5e110845f39a000391668e3e80"));
//        System.out.println("6-------------" + sendGet(url, "ak", "8bb09e5e110845f39a000391668e3e80",2));
//        System.out.println("7-------------" + sendGet(url, "ak", "8bb09e5e110845f39a000391668e3e80","UTF-8"));
//        System.out.println("8-------------" + sendGet(url, "ak", "8bb09e5e110845f39a000391668e3e80","UTF-8",2));
//        Map<String, String> headerMap = new HashMap<>();
//        headerMap.put("ak", "8bb09e5e110845f39a000391668e3e80");
//        System.out.println("9-------------" + sendGet(url, headerMap));
//        System.out.println("10-------------" + sendGet(url, headerMap,2));
//        System.out.println("11-------------" + sendGet(url, headerMap,"UTF-8"));
//        System.out.println("12-------------" + sendGet(url, headerMap,"UTF-8",2));

        List<Tuple2<Integer, String>> tt= new ArrayList<>();
        tt.add(new Tuple2<>(1, "abc"));
        tt.add(new Tuple2<>(3, "efg"));
        tt.add(new Tuple2<>(2, "fdg"));
        tt.sort((a, b) -> a.first >= b.first ? -1:1);
        tt.forEach(o -> System.out.println(o.first + "---" + o.second));
    }

    public static String sendPostHeader(String url, String param, int maxTryTime, String header, String value, String charset, String outputCharset) {
        String content = sendPostHeader(url, param, header, value, charset, outputCharset);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                content = sendPostHeader(url, param, header, value, charset, outputCharset);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }



    private static boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    private static boolean isAcTimeRetCode(JSONObject json) {
        String status = json.getString("retCode");
        if (!"0".equals(status)) {
            return false;
        }
        try {
            String msg = json.getString("retMsg");
            return (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    private static boolean isAcTime(JSONObject json) {
        int status = json.getInteger("CODE");
        if (status != 1) {
            return false;
        }
        try {
            String msg = json.getString("MSG");
            return (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public static String sendPostByParam(String url, Map<String, String> headerMap, Map<String, String> bodyMap) {

        String jsonStr = "";
        HttpPost post = null;
        CloseableHttpResponse response = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }
            post = new HttpPost(url);

            for(Map.Entry<String, String> entry : headerMap.entrySet()){
                post.addHeader(entry.getKey(), entry.getValue());
            }

            List<NameValuePair> parameters = new ArrayList<>();
            for(Map.Entry<String, String> entry : bodyMap.entrySet()){
                parameters.add(new BasicNameValuePair(entry.getKey(), entry.getValue()));
            }
            // 构造一个form表单式的实体
            UrlEncodedFormEntity formEntity = new UrlEncodedFormEntity(parameters, Consts.UTF_8);
            post.setEntity(formEntity);

            response = httpClient.execute(post);
            return EntityUtils.toString(response.getEntity(), Consts.UTF_8);
        } catch (Exception e) {

            return null;
        } finally {
            try {
                if (jsonStr != null) {
                    if (post != null) {
                        EntityUtils.consume(entity);
                        post.releaseConnection();
                    }
                    if (response != null) {
                        response.close();
                    }
                }
            } catch (Exception e) {
            }
        }
    }

    /**
     * 发送post请求,配置多个请求头参数
     * @param url   请求地址
     * @param param 请求参数
     * @param headers 请求头参数
     * @return 请求返回的结果
     */
    public static String postMultiHeader(String url, String param, Map<String, String> headers) {
        String jsonStr = null;
        CloseableHttpResponse response = null;
        HttpPost post = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }

            post = new HttpPost(url);
//            post.setHeader("Content-Type", "application/json");
            post.setHeader("Connection", "Keep-Alive");
            post.setHeader("Accept", "application/json");

            // 添加Header
            for (String key : headers.keySet()) {
                String header = key;
                String value = headers.get(key);
                logger.error("Header: " + header + ", Value: " + value);
                post.setHeader(header, value);
            }

            HttpEntity re = new StringEntity(param, "UTF-8");
            post.setEntity(re);

            response = httpClient.execute(post);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, "UTF-8");
        } catch (Exception e) {
            logger.error("resonse - {}", response);
            logger.error("readContentFromPost err. ", e);
        } finally {
            try {
                if (jsonStr != null) {
                    EntityUtils.consume(entity);
                    post.releaseConnection();
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return jsonStr;
    }

    /**
     * 发送post请求,配置多个请求头参数
     * @param url   请求地址
     * @param param 请求参数
     * @param headers 请求头参数
     * @param maxTryTime 最大重试次数
     * @return 请求返回的结果
     */
    public static String sendPostMultiHeader(String url, String param, Map<String, String> headers, int maxTryTime) {
        String content = postMultiHeader(url, param, headers);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                content = postMultiHeader(url, param, headers);
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(content), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = postMultiHeader(url, param, headers);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }


    /**
     * 发送post请求
     *
     * @param url   请求地址
     * @param param 请求参数
     * @return 请求返回的结果
     */
    public static String sendPostHeader(String url, String param, String header, String value, String charset, String outputCharset) {
        String jsonStr = null;
        CloseableHttpResponse response = null;
        HttpPost post = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }

            post = new HttpPost(url);
            post.setHeader("Content-Type", "application/json");
            post.setHeader("Connection", "Keep-Alive");
            post.setHeader("Accept", "application/json");
            post.setHeader(header, value);
            HttpEntity re = new StringEntity(param, charset);
            post.setEntity(re);

            response = httpClient.execute(post);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, outputCharset);
        } catch (Exception e) {
            logger.error("resonse - {}", response);
            logger.error("readContentFromPost err. ", e);
        } finally {
            try {
                if (jsonStr != null) {
                    EntityUtils.consume(entity);
                    post.releaseConnection();
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return jsonStr;
    }

    public static String sendPost(String url, String param) {
        return sendPost(url, param, FixedConstant.MAX_TRY_TIME_ONCE);
    }

    public static String sendPost(String url, String param, int maxTryTime) {
        String content = post(url, param);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                content = post(url, param);
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(content), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = post(url, param);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    public static String sendPostRetCode(String url, String param, int maxTryTime) {
        String content = post(url, param);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                content = post(url, param);
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTimeRetCode(JSONObject.parseObject(content))) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = post(url, param);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }

    /**
     * 发送post请求
     *
     * @param url   请求地址
     * @param param 请求参数
     * @return 请求返回的结果
     */
    private static String post(String url, String param) {
        String jsonStr = null;
        CloseableHttpResponse response = null;
        HttpPost post = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }

            post = new HttpPost(url);
            post.setHeader("Content-Type", "application/json");
            post.setHeader("Connection", "Keep-Alive");
            HttpEntity re = new StringEntity(param, "UTF-8");
            post.setEntity(re);

            response = httpClient.execute(post);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, "utf-8");
        } catch (Exception e) {
            logger.error("resonse - {}", response);
            logger.error("readContentFromPost err. ", e);
        } finally {
            try {
                if (jsonStr != null) {
                    EntityUtils.consume(entity);
                    post.releaseConnection();
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return jsonStr;
    }

    /**
     * 发送日志文件方法
     *
     * @param url  接收文件接口连接
     * @param file 发送文件
     */
    public static String sendFile(String url, File file, Map<String, String> param) {
        String jsonStr = null;
        CloseableHttpResponse response = null;
        HttpPost post = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }

            post = new HttpPost(url);
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.addBinaryBody("file", file);
            builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
            builder.setCharset(StandardCharsets.UTF_8);
            for (Map.Entry<String, String> entry : param.entrySet()) {
                builder.addTextBody(entry.getKey(), entry.getValue());
            }
            HttpEntity re = builder.build();
            post.setEntity(re);

            response = httpClient.execute(post);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, "utf-8");
        } catch (Exception e) {
            logger.error("resonse - {}", response);
            logger.error("readContentFromPost err. ", e);
        } finally {
            try {
                if (jsonStr != null) {
                    EntityUtils.consume(entity);
                    post.releaseConnection();
                    response.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return jsonStr;

    }


    /**
     * 进行get请求
     *
     * @param url        请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static JSONObject httpGetJSON(String url, int maxTryTime) {
        int count = maxTryTime;
        JSONObject ret;
        while (count-- > 0) {
            HttpGet httpGet = new HttpGet(url);
            try (CloseableHttpClient httpClient = HttpClients.custom().build();
                 CloseableHttpResponse response = httpClient.execute(httpGet)) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    ret = JSON.parseObject(result);
                    return ret;
                }
            } catch (Exception e) {
                sleep(count, url, e);
            } finally {
                httpGet.releaseConnection();
            }
        }
        return null;
    }

    /**
     * 进行get请求
     *
     * @param url        请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static JSONArray httpGetArray(String url, int maxTryTime) {
        int count = maxTryTime;
        JSONArray ret;
        while (count-- > 0) {
            HttpGet httpGet = new HttpGet(url);
            try (CloseableHttpClient httpClient = HttpClients.custom().build();
                 CloseableHttpResponse response = httpClient.execute(httpGet)) {
                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    ret = JSON.parseArray(result);
                    return ret;
                }
            } catch (Exception e) {
                sleep(count, url, e);
            } finally {
                httpGet.releaseConnection();
            }
        }
        return null;
    }

    private static void sleep(int count, String url, Exception e) {
        try {
            if (count == 0) {
                logger.error(url + "," + e.getMessage());
            } else if (count == 1) {
                Thread.sleep(500);
            } else if (count == 2) {
                Thread.sleep(250);
            } else if (count == 3) {
                Thread.sleep(125);
            }
        } catch (InterruptedException e1) {
        }
    }

    public static byte[] postGetByte(String url, JSON json, int retryCnt) throws ParseException, IOException {

        byte[] fileBytes = null;
        //创建httpclient对象
        CloseableHttpClient client = HttpClients.createDefault();
        //创建post方式请求对象
        HttpPost httpPost = new HttpPost(url);

        //装填参数
        StringEntity s = new StringEntity(json.toString(), "utf-8");
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE,
                "application/json"));
        //设置参数到请求对象中
        httpPost.setEntity(s);
        //System.out.println("请求地址："+url);

        //设置header信息
        //指定报文头【Content-type】、【User-Agent】
        httpPost.setHeader("Content-type", "application/json");
        httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
        int count = 0;
        while (count++ < retryCnt)
            try (
                    //执行请求操作，并拿到结果（同步阻塞）
                    CloseableHttpResponse response = client.execute(httpPost);
            ) {
                //获取结果实体
                HttpEntity entity = response.getEntity();
                if (entity != null) {
                    //按指定编码转换结果实体为String类型
                    fileBytes = input2byte(entity.getContent());
                }
                EntityUtils.consume(entity);
                return fileBytes;
            } catch (Exception e) {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
                continue;
            }
        return fileBytes;
    }

    /**
     * inputStream转换为byte字节数组
     *
     * @param inStream
     * @return
     * @throws IOException
     */
    public static final byte[] input2byte(InputStream inStream) throws IOException {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        byte[] buff = new byte[100];
        int rc = 0;
        while ((rc = inStream.read(buff, 0, 100)) > 0) {
            swapStream.write(buff, 0, rc);
        }
        byte[] in2b = swapStream.toByteArray();
        return in2b;
    }

    /**
     * 检查是否在调用时间内
     * @param invokeStartTm 允许调用开始时间 HHmmss
     * @param invokeEndTm 允许调用结束时间 HHmmss
     * @return
     */
    public static boolean isCanInvoke(long invokeStartTm, long invokeEndTm) {
        long tm = Long.parseLong(DateUtil.getCurrentDate("HHmmss"));
        boolean rs;
        if (invokeEndTm > invokeStartTm) {
            rs = tm < invokeEndTm && tm > invokeStartTm;
        } else if (invokeEndTm == invokeStartTm) {
            rs = false;
        } else {
            rs = tm < invokeEndTm || tm > invokeStartTm;
        }
        return rs;
    }

    /**
     * 检查是否在调用时间内
     * @param invokeStartTm 允许调用开始时间 HHmmss
     * @param invokeEndTm 允许调用结束时间 HHmmss
     * @return
     */
    public static boolean isCanInvoke(String invokeStartTm, String invokeEndTm) {
        long tm = Long.parseLong(DateUtil.getCurrentDate("HHmmss"));
        boolean rs;
        long startTm = Long.parseLong(invokeStartTm);
        long endTm = Long.parseLong(invokeEndTm);
        if (endTm > startTm) {
            rs = tm < endTm && tm > startTm;
        } else if (endTm == startTm) {
            rs = false;
        } else {
            rs = tm < endTm || tm > startTm;
        }
        return rs;
    }
    public static String sendGet2(String url, String charset, int maxTryTime, String key, String value) {
        String jsonStr = sendGet2(url, charset, key, value);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(jsonStr) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                if (StringUtils.isNotEmpty(charset)) {
                    jsonStr = sendGet(url, charset);
                } else {
                    jsonStr = sendGet2(url, FixedConstant.CHARSET_UTF, key, value);
                }
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(jsonStr), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                jsonStr = HttpInvokeUtil.sendGet(url, maxTryTime);
            }
        } catch (Exception e) {

        }
        return jsonStr;
    }
    private static String sendGet2(String url, String charset, String key, String value) {
        logger.debug("start send get, url - {}.", url);
        String jsonStr = "";
        HttpGet get = null;
        CloseableHttpResponse response = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }
            get = new HttpGet(url);
            get.addHeader(key, value);
            response = httpClient.execute(get);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, charset);

        } catch (Exception e) {
            logger.error("execute access http get url err. " + url, e);
            return jsonStr;
        } finally {
            try {
                if (jsonStr != null) {
                    if (get != null) {
                        EntityUtils.consume(entity);
                        get.releaseConnection();
                    }
                    if (response != null) {
                        response.close();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        logger.debug("end get， url - {}.", url);
        return jsonStr;
    }
}
