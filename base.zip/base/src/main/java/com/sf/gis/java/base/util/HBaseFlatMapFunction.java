package com.sf.gis.java.base.util;

import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.util.Collector;

import java.util.ArrayList;

/**
 * GIS-LSS-TLOC：【壹竿-督导】步数统计_V1.0 kafka2hbase(需求人：01422773)
 * 20220802 created by 01417629
 */
public class HBaseFlatMapFunction extends RichFlatMapFunction<String,String> {
    @Override
    public void flatMap(String s, Collector<String> collector) throws Exception {
        /*JSONArray  jsonArray = JSONArray.parseArray(s);
        for (int i = 0; i <jsonArray.size() ; i++) {
            JSONObject json = JSONArray.parseObject(jsonArray.get(i).toString());
            String id = JSONUtil.getJsonVal(json, "id","");
            String un = JSONUtil.getJsonVal(json, "un","");
            String bn = JSONUtil.getJsonVal(json, "bn","");
            String num = JSONUtil.getJsonVal(json, "num","");
            String oNum = JSONUtil.getJsonVal(json, "oNum","");
            String tm = JSONUtil.getJsonVal(json, "tm","");
            //传入时间戳，得到类似格式：20160223 做到毫秒
            String trunc = DateUtil.truncTime(tm);
            String md5Key = un + "_" + trunc + "_" + id;
            String rowKey = SaltUtil.generateSaltNew(md5Key, 100) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;
            ArrayList<String> res = new ArrayList<>();
            res.add(rowKey);
            res.add(id);
            res.add(un);
            res.add(bn);
            res.add(num);
            res.add(oNum);
            if(StringUtils.isNotBlank(tm)){
                res.add(tm.substring(0,10));
            }else{
                res.add(tm);
            }
            String res_message = String.join("\t", res);
            collector.collect(res_message);
        }*/
    }
}
