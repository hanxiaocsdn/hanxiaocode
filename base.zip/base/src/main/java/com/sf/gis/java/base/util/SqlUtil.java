package com.sf.gis.java.base.util;

import com.sf.gis.java.base.constant.FixedConstant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * sql处理工具类
 * @author 01370539 Created On: May.07 2021
 */
public class SqlUtil {
    private static final Logger logger = LoggerFactory.getLogger(SqlUtil.class);

    /**
     * 从sql文件读取sql，sql文件必须存放在sql目录下
     * @param sqlFile sql文件
     * @param args 参数值
     * @return 参数被赋值的sql语句
     */
    public static String getSqlStr(String sqlFile, Object... args) {
        String sql = null;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(ConfigUtil.getSqlStream(sqlFile), FixedConstant.CHARSET_UTF));
            StringBuilder builder = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().startsWith("#") && !line.trim().startsWith("--")) {
                    builder.append(line).append(" ");
                }
            }
            sql = builder.toString().replaceAll("\\s+", " ").trim();
            sql = String.format(sql, args);
        } catch (Exception e) {
            logger.error("getSqlStr execute err.", e);
        }
        return sql;
    }
}