package com.sf.gis.java.base.dto;

public class ChkQueryTcTeamCodeIn {
    private String ak;
    private String address;
    private String sysCode = "BDP_OMS";
    private String cityCode;
    private String addressType = "1";
    private String province;
    private String city;
    private String county;
    private String sysOrderNo;
    private String phone;
    private String contactsName;;
    private String mobile;
    private String company;
    private String type = "1";
    private String opt = "aoi";
    private String keyword = "1";
    private String customerAccount;
    private String virMap = "1";
    private String aoiAreaGroupMark = "1";
    private String deptGroupMark = "1";
    private String villageMark = "1";
    private String villageDistMark = "1";
    private String poiMark = "1";
    private String appliedAoiMark = "1";

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSysCode() {
        return sysCode;
    }

    public void setSysCode(String sysCode) {
        this.sysCode = sysCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getContactsName() {
        return contactsName;
    }

    public void setContactsName(String contactsName) {
        this.contactsName = contactsName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getCustomerAccount() {
        return customerAccount;
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount;
    }

    public String getVirMap() {
        return virMap;
    }

    public void setVirMap(String virMap) {
        this.virMap = virMap;
    }

    public String getAoiAreaGroupMark() {
        return aoiAreaGroupMark;
    }

    public void setAoiAreaGroupMark(String aoiAreaGroupMark) {
        this.aoiAreaGroupMark = aoiAreaGroupMark;
    }

    public String getDeptGroupMark() {
        return deptGroupMark;
    }

    public void setDeptGroupMark(String deptGroupMark) {
        this.deptGroupMark = deptGroupMark;
    }

    public String getVillageMark() {
        return villageMark;
    }

    public void setVillageMark(String villageMark) {
        this.villageMark = villageMark;
    }

    public String getVillageDistMark() {
        return villageDistMark;
    }

    public void setVillageDistMark(String villageDistMark) {
        this.villageDistMark = villageDistMark;
    }

    public String getPoiMark() {
        return poiMark;
    }

    public void setPoiMark(String poiMark) {
        this.poiMark = poiMark;
    }

    public String getAppliedAoiMark() {
        return appliedAoiMark;
    }

    public void setAppliedAoiMark(String appliedAoiMark) {
        this.appliedAoiMark = appliedAoiMark;
    }

    @Override
    public String toString() {
        return "ChkQueryTcTeamCodeIn{" +
                "ak='" + ak + '\'' +
                ", address='" + address + '\'' +
                ", sysCode='" + sysCode + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", addressType='" + addressType + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", sysOrderNo='" + sysOrderNo + '\'' +
                ", phone='" + phone + '\'' +
                ", contactsName='" + contactsName + '\'' +
                ", mobile='" + mobile + '\'' +
                ", company='" + company + '\'' +
                ", type='" + type + '\'' +
                ", opt='" + opt + '\'' +
                ", keyword='" + keyword + '\'' +
                ", customerAccount='" + customerAccount + '\'' +
                ", virMap='" + virMap + '\'' +
                ", aoiAreaGroupMark='" + aoiAreaGroupMark + '\'' +
                ", deptGroupMark='" + deptGroupMark + '\'' +
                ", villageMark='" + villageMark + '\'' +
                ", villageDistMark='" + villageDistMark + '\'' +
                ", poiMark='" + poiMark + '\'' +
                ", appliedAoiMark='" + appliedAoiMark + '\'' +
                '}';
    }
}
