package com.sf.gis.java.base.dto;

import java.io.Serializable;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-08-17 17:16
 * @TaskId:
 * @TaskName:
 * @Description: 用于获取token的参数
 */
public class NetAccessRecordTokenParm implements Serializable {
    //账号 工号
    private String accountNo;
    public NetAccessRecordTokenParm(){

    }
    public NetAccessRecordTokenParm(String accountNo) {
        this.accountNo = accountNo;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String account) {
        this.accountNo = accountNo;
    }
}
