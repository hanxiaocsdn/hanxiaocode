package com.sf.gis.java.base.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/*

*StreamHandler class

*/

public class StreamHandler extends Thread {
	private  static Logger logger = LoggerFactory.getLogger(StreamHandler.class);
	private InputStream m_inputStream;

	StreamHandler(InputStream is) {
		this.m_inputStream = is;
	}

	@Override
	public void run()

	{
		InputStreamReader isr = null;
		BufferedReader br = null;

		try {

			// 设置编码方式，否则输出中文时容易乱码
			isr = new InputStreamReader(m_inputStream, "utf-8");
			br = new BufferedReader(isr);
			String line;
			while ((line = br.readLine()) != null) {
				logger.error(line);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				if(br != null){
					br.close();
				}
				if(isr != null){
					isr.close();
				}
			} catch (IOException ex) {
				logger.error(ex.getMessage());
			}
		}
	}
}
