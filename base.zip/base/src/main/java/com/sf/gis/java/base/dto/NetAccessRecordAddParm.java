package com.sf.gis.java.base.dto;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.StrUtils;


import java.io.Serializable;
import java.util.Date;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-08-17 17:21
 * @TaskId:
 * @TaskName:
 * @Description: 接口访问记录新增接口的参数
 */
public class NetAccessRecordAddParm extends BdpTaskRecordAddParm implements Serializable {
    //接口url
    private String httpUrl;
    //接口AK
    private String httpAk;
    //调用数据量
    private long dataCnt;
    //并发
    private int invokeThreadCnt;
    //起始时间
    private String invokeStartTm;


    public NetAccessRecordAddParm() {
    }

    public NetAccessRecordAddParm(String taskId, String taskName, String taskDescription, String httpUrl, String httpAk, long dataCnt, int invokeThreadCnt) {
       super(taskId,taskName,taskDescription);
        this.httpUrl = httpUrl;
        if(!StrUtils.isBlank(httpAk) && httpAk.length() == 16){
            this.httpAk = httpAk.substring(0,5)+"****"+httpAk.substring(9,16);
        }else{
            this.httpAk = httpAk;
        }

        this.dataCnt = dataCnt;
        this.invokeThreadCnt = invokeThreadCnt;
        this.invokeStartTm = DateUtil.formatDate(new Date(), "yyyyMMddHHmmss");
    }


    public String getHttpUrl() {
        return httpUrl;
    }

    public void setHttpUrl(String httpUrl) {
        this.httpUrl = httpUrl;
    }

    public String getHttpAk() {
        return httpAk;
    }

    public void setHttpAk(String httpAk) {
        this.httpAk = httpAk;
    }

    public long getDataCnt() {
        return dataCnt;
    }

    public void setDataCnt(long dataCnt) {
        this.dataCnt = dataCnt;
    }

    public int getInvokeThreadCnt() {
        return invokeThreadCnt;
    }

    public void setInvokeThreadCnt(int invokeThreadCnt) {
        this.invokeThreadCnt = invokeThreadCnt;
    }

    public String getInvokeStartTm() {
        return invokeStartTm;
    }

    public void setInvokeStartTm(String invokeStartTm) {
        this.invokeStartTm = invokeStartTm;
    }

    public void checkEmpty() {
        super.checkEmpty();
        if (StrUtils.isBlank(httpUrl)) {
            System.out.println("***************请务必填写httpUrl************");
        }
        if (StrUtils.isBlank(httpUrl)) {
            System.out.println("***************请务必确认是否真的没有Ak************");
        }
        if (dataCnt <= 0) {
            System.out.println("***************请认真填写数据量dataCnt************");
        }
        if (invokeThreadCnt == 0) {
            System.out.println("***************请认真填写并行度invokeThreadCnt************");
        }
    }
}

