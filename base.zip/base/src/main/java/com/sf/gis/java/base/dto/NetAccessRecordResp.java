package com.sf.gis.java.base.dto;

import java.io.Serializable;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-08-17 16:53
 * @TaskId:
 * @TaskName:
 * @Description: 接口访问记录的相关接口响应体
 */
public class NetAccessRecordResp implements Serializable {
    //返回码
    private int code;
    //返回消息
    private String msg;
    //返回的数据
    private String data;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
