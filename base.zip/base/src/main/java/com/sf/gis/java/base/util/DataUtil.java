package com.sf.gis.java.base.util;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.*;
import javax.persistence.Column;
import javax.persistence.Table;

import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import jodd.util.StringUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.*;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 从数据库中加载数据工具类
 *
 * @author 01370539 Created On: Mar.24 2021
 */
public class DataUtil {
    private static final Logger logger = LoggerFactory.getLogger(DataUtil.class);

    /**
     * 从hive表load数据
     *
     * @param ss  SparkSession
     * @param sql sql
     * @return 查询到的数据
     */
    public static JavaRDD<Row> loadData(SparkSession ss, String sql) {
        return select(ss, sql, SysConstant.PARTITION_COUNT).toJavaRDD();
    }

    private static Dataset<Row> select(SparkSession ss, String sql, int partitionNum) {
        logger.error("sql: {}", sql);
        return ss.sql(sql).repartition(partitionNum);
    }

    /**
     * 从hive表load数据，并映射到对象中
     *
     * @param sparkInfo spark相关，包括SparkSession、JavaSparkContext
     * @param sql       sql
     * @param outClass  需要映射到的具体的对象类信息
     * @param <T>       查询到的数据需要映射成的对象类型
     * @return 查询到的数据
     */
    public static <T> JavaRDD<T> loadData(SparkInfo sparkInfo, String sql, Class<T> outClass) {
        return mapToObjectRdd(select(sparkInfo.getSession(), sql, SysConstant.PARTITION_COUNT), sparkInfo.getContext(), outClass);
    }

    /**
     * 从hive表load数据，并映射到对象中
     *
     * @param sparkInfo spark相关，包括SparkSession、JavaSparkContext
     * @param fileUrl   文件路径
     * @param outClass  需要映射到的具体的对象类信息
     * @param <T>       查询到的数据需要映射成的对象类型
     * @return 查询到的数据
     */
    public static <T> JavaRDD<T> loadFile(SparkInfo sparkInfo, String fileUrl, String encoding, Class<T> outClass) {
        Dataset<Row> ds = sparkInfo.getSession().read().option("inferSchema", "false").option("multiline", "true").option("header", "true").option("encoding", encoding).csv(fileUrl).repartition(SysConstant.PARTITION_COUNT);
        logger.error("select: result count: {}", ds.count());
        return mapToObjectRdd(ds, sparkInfo.getContext(), outClass);
    }

    /**
     * 从hive表load数据，并映射到对象中
     *
     * @param ss           sparkSession
     * @param sparkContext sparkContext
     * @param sql          sql
     * @param outClass     需要映射到的具体的对象类信息
     * @param <T>          查询到的数据需要映射成的对象类型
     * @return 查询到的数据
     */
    public static <T> JavaRDD<T> loadData(SparkSession ss, JavaSparkContext sparkContext, String sql, Class<T> outClass) {
        return mapToObjectRdd(select(ss, sql, SysConstant.PARTITION_COUNT), sparkContext, outClass);
    }

    public static <T> JavaRDD<T> mapToObjectRdd(Dataset<Row> ds, JavaSparkContext sparkContext, Class<T> outClass) {
        if (ds == null || sparkContext == null || outClass == null || !outClass.isAnnotationPresent(Table.class)) {
            logger.error("dataset can't be null and outClass must be annotationed by Table");
            return null;
        }

        Set<String> columnSet = new HashSet<>(Arrays.asList(ds.columns()));
        Broadcast<Set<String>> columnSetBc = sparkContext.broadcast(columnSet);

        return ds.toJavaRDD().map(row -> {
            T bean;
            try {
                bean = outClass.newInstance();
            } catch (Exception e) {
                bean = outClass.getConstructor(outClass).newInstance(null);
            }
            Field[] fields = ClzUtil.getAllFieldArr(outClass);
            for (Field field : fields) {
                if (field.isAnnotationPresent(Column.class)) {
                    String columnName = field.getAnnotation(Column.class).name();
                    if (columnSetBc.value().contains(columnName)) {
                        Object columnValue = row.getAs(columnName);
                        BeanUtils.setProperty(bean, field.getName(), columnValue == null ? "" : columnValue);
                    }
                }
            }
            return bean;
        });
    }

    private static <T> Object[] getValues(T t, Broadcast<String[]> bc) {
        String[] columns = bc.getValue();
        Field[] fields = t.getClass().getDeclaredFields();
        Map<String, Object> tempMap = new HashMap<>();
        Column[] cols;
        for (Field field : fields) {
            field.setAccessible(true);
            cols = field.getAnnotationsByType(Column.class);
            if (cols.length > 0) {
                try {
                    tempMap.put(cols[0].name(), field.get(t));
                } catch (IllegalAccessException e) {
                    logger.error("get values error.", e);
                }
            }
        }
        Object[] result = new Object[columns.length];
        for (int i = 0; i < columns.length; i++) {
            result[i] = tempMap.get(columns[i]);
        }
        return result;
    }

    /**
     * 保存数据到hive，覆盖原始分区
     *
     * @param sparkInfo      spark相关信息
     * @param tblName        hive table name
     * @param tClass         the pojo class which reflect table
     * @param rddT           the data need to save
     * @param partitionField partition field
     * @param <T>            pojo class type
     */
    public static <T> void saveOverwrite(SparkInfo sparkInfo, String tblName, Class<T> tClass, JavaRDD<T> rddT, String... partitionField) {
        saveOverwrite(sparkInfo.getSession(), sparkInfo.getContext(), tblName, tClass, rddT, partitionField);
    }

    /**
     * 保存数据到hive，覆盖原始分区
     *
     * @param ss             SparkSession
     * @param jsc            JavaSparkContext
     * @param tblName        hive table name
     * @param tClass         the pojo class which reflect table
     * @param rddT           the data need to save
     * @param partitionField partition field
     * @param <T>            pojo class type
     */
    public static <T> void saveOverwrite(SparkSession ss, JavaSparkContext jsc, String tblName, Class<T> tClass, JavaRDD<T> rddT, String... partitionField) {
        save(ss, jsc, tblName, tClass, rddT, "overwrite", partitionField);
    }

    /**
     * 保存数据到hive，覆盖原始分区
     *
     * @param sparkInfo      spark相关信息
     * @param tblName        hive table name
     * @param tClass         the pojo class which reflect table
     * @param rddT           the data need to save
     * @param partitionField partition field
     * @param <T>            pojo class type
     */
    public static <T> void saveInto(SparkInfo sparkInfo, String tblName, Class<T> tClass, JavaRDD<T> rddT, String... partitionField) {
        saveInto(sparkInfo.getSession(), sparkInfo.getContext(), tblName, tClass, rddT, partitionField);
    }

    /**
     * 保存数据到hive，增加新分区/已有分区增加数据
     *
     * @param ss             SparkSession
     * @param jsc            JavaSparkContext
     * @param tblName        hive table name
     * @param tClass         the pojo class which reflect table
     * @param rddT           the data need to save
     * @param partitionField partition field
     * @param <T>            pojo class type
     */

    public static <T> void saveInto(SparkSession ss, JavaSparkContext jsc, String tblName, Class<T> tClass, JavaRDD<T> rddT, String... partitionField) {
        save(ss, jsc, tblName, tClass, rddT, "into", partitionField);
    }

    private static <T> void save(SparkSession ss, JavaSparkContext jsc, String tblName, Class<T> tClass, JavaRDD<T> rddT, String insertAction, String... partitionField) {
        String[] columnNames = ClzUtil.getColumnArr(tClass);
        Broadcast<String[]> bc = jsc.broadcast(columnNames);
        JavaRDD<Row> rows = rddT.map(o -> RowFactory.create(getValues(o, bc))).persist(StorageLevel.MEMORY_AND_DISK_SER());

        if (rows.count() > 0) {
            List<StructField> structFieldList = new ArrayList<>();
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }

            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = ss.createDataFrame(rows.repartition(ComputePartUtil.computePart(rows.count())), structType);
            String tmpTableName = tClass.getSimpleName() + System.currentTimeMillis();
            ds.createOrReplaceTempView(tmpTableName);
            String sql;
            int length = partitionField.length;
            if (length == 0) {
                sql = String.format("insert " + insertAction + " table " + tblName + " select * from %s", tmpTableName);
            } else {
                String partitionStr = "";
                for (String pf : partitionField) {
                    if (StringUtil.isEmpty(partitionStr)) {
                        partitionStr = pf;
                    } else {
                        partitionStr += "," + pf;
                    }
                }
                sql = String.format("insert " + insertAction + " table " + tblName + " partition(" + partitionStr + ") " + "select * from %s", tmpTableName);
            }
            logger.error(sql);
            ss.sql(sql);
            rows.unpersist();
            ss.catalog().dropTempView(tmpTableName);
        }
        logger.error("save end");
    }

    /**
     * load data from mysql by sql
     *
     * @param jsc    JavaSparkContext
     * @param conn   Connection
     * @param sql    sql
     * @param tClass the pojo which need to transfer
     * @param <T>    the pojo which need to transfer
     * @return the result
     */
    public static <T> JavaRDD<T> loadData(JavaSparkContext jsc, Connection conn, String sql, Class<T> tClass) {
        return jsc.parallelize(loadData(conn, sql, tClass));
    }

    /**
     * load data from mysql by sql
     *
     * @param conn   Connection
     * @param sql    sql
     * @param tClass the pojo class need transfer
     * @param <T>    the pojo which need to transfer
     * @return the result
     */
    public static <T> List<T> loadData(Connection conn, String sql, Class<T> tClass) {
        List<T> tList = new ArrayList<>();
        try {
            if (conn != null) {
                logger.error("select: sql: {}", sql);
                ResultSet rs = conn.prepareStatement(sql).executeQuery();

                T t;
                Field[] fields = tClass.getDeclaredFields();
                Column[] cols;
                while (rs.next()) {
                    try {
                        t = tClass.newInstance();
                    } catch (Exception e) {
                        t = tClass.getConstructor(tClass).newInstance(null);
                    }

                    for (Field field : fields) {
                        field.setAccessible(true);
                        cols = field.getAnnotationsByType(Column.class);
                        if (cols.length > 0) {
                            try {
                                field.set(t, rs.getString(cols[0].name()));
                            } catch (Exception ignored) {
                            }
                        }
                    }
                    tList.add(t);
                }
                rs.close();

            }
        } catch (Exception e) {
            logger.error("loadData execute error. conn - {}, sql - {}, e - {}", conn, sql, e);
        }
        return tList;
    }

    /**
     * 获取分区
     *
     * @param ss            SparkSession
     * @param tblName       表名
     * @param partitionName 分区字段名
     * @return 已有分区信息
     */
    public HashSet<String> getPartitions(SparkSession ss, String tblName, String partitionName) {
        String sql = "select distinct(" + partitionName + ") from " + tblName;
        return new HashSet<>(ss.sql(sql).toJavaRDD().map(row -> row.getString(0)).collect());
    }
}
