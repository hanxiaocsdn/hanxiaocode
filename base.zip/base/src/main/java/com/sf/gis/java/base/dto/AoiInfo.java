package com.sf.gis.java.base.dto;

import java.io.Serializable;

/**
 * AOI相关信息
 * @author 01370539 Created on Apr.30 2021
 */
public class AoiInfo implements Serializable {
    public double lng;  // 经度
    public double lat;  // 维度
    public String aoiId;  // aoiid
    public String aoiName;  // aoi名称
    public String aoiCode;  // aoicode
    public String aoiAreaCode;  // aoiAreaCode
    public String aoiZc;  // aoiZc
    public String aoiType;  // aoi类型
    public String aoiTypeName;  // aoi类型名称
    public String cityCode;  // 城市编码
    public String znoCode;  // 网点
    public double dist;  // 距离（坐标与aoi的距离）

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiName() {
        return aoiName;
    }

    public void setAoiName(String aoiName) {
        this.aoiName = aoiName;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiAreaCode() {
        return aoiAreaCode;
    }

    public void setAoiAreaCode(String aoiAreaCode) {
        this.aoiAreaCode = aoiAreaCode;
    }

    public String getAoiZc() {
        return aoiZc;
    }

    public void setAoiZc(String aoiZc) {
        this.aoiZc = aoiZc;
    }

    public String getAoiType() {
        return aoiType;
    }

    public void setAoiType(String aoiType) {
        this.aoiType = aoiType;
    }

    public String getAoiTypeName() {
        return aoiTypeName;
    }

    public void setAoiTypeName(String aoiTypeName) {
        this.aoiTypeName = aoiTypeName;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getZnoCode() {
        return znoCode;
    }

    public void setZnoCode(String znoCode) {
        this.znoCode = znoCode;
    }

    public double getDist() {
        return dist;
    }

    public void setDist(double dist) {
        this.dist = dist;
    }
}
