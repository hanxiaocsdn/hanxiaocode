package com.sf.gis.java.base.constant;

/**
 * 接口相关常量
 * @author 01370539 created on Jul.8 2021
 */
public class InfConstant {

    public static int AK_RESTRICTIONS_109 = 109;  // ak每分钟超限
}
