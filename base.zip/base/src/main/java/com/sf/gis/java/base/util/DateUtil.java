package com.sf.gis.java.base.util;


import com.google.i18n.phonenumbers.NumberParseException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

/**
 * 日期工具类，提供日期相关公共方法
 *
 * @author 01370539 Created On: Mar.24 2021
 */
public class DateUtil {
    private static final Logger logger = LoggerFactory.getLogger(DateUtil.class);
    private static final String DEFAULT_DATE_FORMAT = "yyyyMMdd";
    private static final String DATE_MONTH_FORMAT = "yyyyMM";
    public static final String DEFAULT_FORMAT_TRUNC = "yyyyMMdd";

    public static final DateFormat getDateFormat(String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat;
    }

    public static final Date parse(String dateString, String format) {
        Date date = null;
        if (null != dateString && !"".equals(dateString)) {
            DateFormat dateFormat = getDateFormat(format);
            try {
                date = dateFormat.parse(dateString);
            } catch (ParseException e) {
                // 解析错误，直接返回
                return null;
            }
        }
        return date;
    }

    public static final String format(Date date, String format) {
        String dataString = "";
        if (null != date) {
            DateFormat dateFormat = getDateFormat(format);
            dataString = dateFormat.format(date);
        }
        return dataString;
    }

    public static Date trunc(Date date, String format) {
        return DateUtil.parse(DateUtil.format(date, format), format);
    }

    /**
     * 传入时间戳
     * 将时间戳转换成date类型，比如时间是20160118 11:38:05
     * 然后将时间截取到天：20160118
     * @param time
     * @return
     */
    public static String truncTime(String time) {
        String str = "";
        try {
            Date date = DateUtil.trunc(new Date(Long.parseLong(time)), DEFAULT_FORMAT_TRUNC);
            str = DateUtil.format(date, DEFAULT_FORMAT_TRUNC);
        }catch(RuntimeException e) {

        }

        return str;
    }

    /**
     * get current date time, default to second, format is: yyyy-MM-dd HH:mm:ss
     *
     * @return 当前日期时间，到秒，格式为：yyyy-MM-dd HH:mm:ss
     */
    public static String getCurrentDatetime() {
        String result = null;
        try {
            SimpleDateFormat DATE_FORMAT_2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            result = DATE_FORMAT_2.format(new Date());
        } catch (Exception e) {
            logger.error("getCurrentDatetime execute exception, exception info: ", e);
            System.err.println("getCurrentDatetime execute exception, exception info: " + e);
        }
        return result;
    }

    /**
     * 返回当前时间yymmdd格式，减多少天
     * @param date
     * @param diff
     * @return
     */
    public static String getCurrentDayDiff(String date, int diff) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Date dt = sdf.parse( date );
        Calendar rightNow = Calendar.getInstance();
        rightNow.setTime(dt);
        rightNow.add( Calendar.DATE, diff );
        Date dateTmp = rightNow.getTime();
        String currentDate = sdf.format(dateTmp);

        return currentDate ;
    }

    /**
     * Get current date time, default to millisecond, format is: yyyy-MM-dd HH:mm:ss.SSS
     *
     * @return 当前日期时间，到毫秒，格式为：yyyy-MM-dd HH:mm:ss.SSS
     */
    public static String getCurrentDatetimesss() {
        String result = null;
        try {
            SimpleDateFormat DATE_FORMAT_2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
            result = DATE_FORMAT_2.format(new Date());
        } catch (Exception e) {
            logger.error("getCurrentDatetimesss execute exception, exception info: ", e);
            System.err.println("getCurrentDatetimesss execute exception, exception info: " + e);
        }
        return result;
    }

    /**
     * Get current Date, format is: yyyyMMdd
     *
     * @return 当前日期，格式为：yyyyMMdd
     */
    public static String getCurrentDate() {
        String result = null;
        try {
            SimpleDateFormat DATE_FORMAT_2 = new SimpleDateFormat("yyyyMMdd");
            result = DATE_FORMAT_2.format(new Date());
        } catch (Exception e) {
            logger.error("getCurrentDate execute exception, exception info: ", e);
            System.err.println("getCurrentDate execute exception, exception info: " + e);
        }
        return result;
    }

    /**
     * Get current date
     *
     * @param format date format
     * @return 当前日期，格式为参数传递的格式
     */
    public static String getCurrentDate(String format) {
        String result = null;
        try {
            SimpleDateFormat DATE_FORMAT_2 = new SimpleDateFormat(format);
            result = DATE_FORMAT_2.format(new Date());
        } catch (Exception e) {
            logger.error("getCurrentDate execute exception, exception info: ", e);
            System.err.println("getCurrentDate execute exception, exception info: " + e);
        }
        return result;
    }

    public static String getCurrentDateBefore(String format) {
        return getDayBefore(getCurrentDate(), format, 1);
    }

    public static String getCurrentDateBefore(String format, int days) {
        return getDayBefore(getCurrentDate(), format, days);
    }

    public static String getCurrentDateAfter(String format) {
        return getDayAfter(getCurrentDate(), format, 1);
    }

    public static String getCurrentDateAfter(String format, int days) {
        return getDayAfter(getCurrentDate(), format, days);
    }

    /**
     * Get current time, format is: HH:mm
     *
     * @return 当前时间，格式为：HH:mm
     */
    public static String getCurrentTime() {
        String result = null;
        try {
            SimpleDateFormat DATE_FORMAT_2 = new SimpleDateFormat("HH:mm");
            result = DATE_FORMAT_2.format(new Date());
        } catch (Exception e) {
            logger.error("getCurrentTime execute exception, exception info: ", e);
            System.err.println("getCurrentTime execute exception, exception info: " + e);
        }
        return result;
    }

    /**
     * Format date to default format string, default format: yyyy-MM-dd HH:mm:ss
     *
     * @param date 日期
     * @return 格式化后的日期，格式为：yyyy-MM-dd HH:mm:ss
     */
    public static String formatDate(Date date) {
        if (date == null) {
            return null;
        }
        String result = null;
        try {
            SimpleDateFormat DATE_FORMAT_2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            result = DATE_FORMAT_2.format(date);
        } catch (Exception e) {
            logger.error("formatDateToDefaultDatetimeStr execute exception, exception info: ", e);
            System.err.println("formatDateToDefaultDatetimeStr execute exception, exception info: " + e);
        }
        return result;
    }

    /**
     * Format date to the format you set
     *
     * @param date   日期
     * @param format 期望格式化的样式
     * @return 格式化后的结果
     */
    public static String formatDate(Date date, String format) {
        if (date == null) {
            return null;
        }
        try {
            SimpleDateFormat DATE_FORMAT_2 = new SimpleDateFormat(format);
            return DATE_FORMAT_2.format(date);
        } catch (Exception e) {
            logger.error("formatDateToSetFormatStr execute exception, exception info: ", e);
            System.err.println("formatDateToSetFormatStr execute exception, exception info: " + e);
        }
        return null;
    }

    /**
     * Translate date which is String format "yyyy-MM-dd HH:mm:ss" to Date format
     *
     * @param str 日期字符串
     * @return 日期类型的数据
     */
    public static Date getDateFromStr(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }
        Date dateValue;

        try {
            dateValue = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);

        } catch (Exception e) {
            logger.error("getDateFromStr: format date error: source date - " + str, e);
            System.err.println("getDateFromStr execute exception, exception info: " + e);
            return null;
        }

        return dateValue;
    }

    public static String formatDate(String dateStr, String srcFormat, String destFormat) {
        if (StringUtils.isEmpty(dateStr) || StringUtils.isEmpty(srcFormat) || StringUtils.isEmpty(destFormat)) {
            return null;
        }
        String rs;
        try {
            Date date = new SimpleDateFormat(srcFormat).parse(dateStr);
            SimpleDateFormat sdfDest = new SimpleDateFormat(destFormat);
            rs = sdfDest.format(date);
        } catch (Exception e) {
            logger.error("getDateFromStr: format date error: source date - " + dateStr, e);
            System.err.println("getDateFromStr execute exception, exception info: " + e);
            return null;
        }

        return rs;
    }

    /**
     * Translate date which is String format "2021-09-13T01:05:13.963Z" to Date format
     *
     * @param str 日期字符串
     * @return 日期类型的数据
     */
    public static Date getDateFromUsStr(String str) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }
        Date dateValue;

        try {
            dateValue = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).parse(str.replace("Z", "+0000"));
        } catch (Exception e) {
            logger.error("getDateFromUsStr: format date error: source date - " + str, e);
            System.err.println("getDateFromUsStr execute exception, exception info: " + e);
            return null;
        }

        return dateValue;
    }

    /**
     * Translate date which is String format "2021-09-13T01:05:13.963Z" to Date string format
     *
     * @param str    日期字符串
     * @param format 目标格式
     * @return 日期字符串
     */
    public static String getDateStrFromUsStr(String str, String format) {
        return formatDate(getDateFromUsStr(str), format);
    }

    /**
     * Translate date which is String format like param "format" to Date format
     *
     * @param str    日期字符串
     * @param format 日期字符串的格式
     * @return 日期类型的数据
     */
    public static Date getDateFromStr(String str, String format) {
        if (StringUtils.isEmpty(str)) {
            return null;
        }
        Date dateValue;

        try {
            dateValue = new SimpleDateFormat(format).parse(str);
        } catch (Exception e) {
            logger.error("getDateFromStr: format date error: source date - " + str, e);
            System.err.println("getDateFromStr execute exception, exception info: " + e);
            return null;
        }

        return dateValue;
    }

    /**
     * Translate date which is long format String to String format like param "format"
     *
     * @param longStr 长整形数据的日期字符串
     * @param format  期望格式化的样式
     * @return 格式化后的数据
     */
    public static String getDateFromLongStr(String longStr, String format) {
        if (StringUtils.isEmpty(longStr)) {
            return null;
        }
        String dateValue;

        try {
            dateValue = new SimpleDateFormat(format).format(new Date(Long.parseLong(longStr)));
        } catch (Exception e) {
            logger.error("getDateFromLongStr: format date error: source date - " + longStr, e);
            System.err.println("getDateFromStr execute exception, exception info: " + e);
            return null;
        }

        return dateValue;
    }

    /**
     * Get week info by Date
     *
     * @param dt 日期类型的数据
     * @return 星期信息
     */
    public static String getWeekOfDate(Date dt) {
        String[] weekDays = {"7", "1", "2", "3", "4", "5", "6"};
        Calendar cal = Calendar.getInstance();
        cal.setTime(dt);
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0)
            w = 0;
        return weekDays[w];
    }

    /**
     * Get week info by date String
     *
     * @param dt     字符串类型的日期数据
     * @param format 日期数据的样式
     * @return 星期信息
     */
    public static String getWeekOfDate(String dt, String format) {
        String[] weekDays = {"7", "1", "2", "3", "4", "5", "6"};
        Calendar cal = Calendar.getInstance();
        cal.setTime(Objects.requireNonNull(getDateFromStr(dt, format)));
        int w = cal.get(Calendar.DAY_OF_WEEK) - 1;
        if (w < 0)
            w = 0;
        return weekDays[w];
    }

    /**
     * 获取时间差，单位毫秒
     *
     * @param oldTime
     * @param newTime
     * @param timeFormat
     * @return
     * @throws ParseException
     */
    public static long getTime(String oldTime, String newTime, String timeFormat) throws ParseException {

        SimpleDateFormat df = new SimpleDateFormat(timeFormat);
        long NTime = df.parse(newTime).getTime();
        //从对象中拿到时间
        long OTime = df.parse(oldTime).getTime();
        long diff = (NTime - OTime);
        return diff;
    }


    /**
     * get the day before specifiedDay
     *
     * @param specifiedDay 日期数据
     * @param dateFormat   日期数据格式
     * @param beforeCount  如果需要前一天的数据，则为1
     * @return 获取期望的日期数据
     */
    public static String getDayBefore(String specifiedDay, String dateFormat, int beforeCount) {
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat(dateFormat).parse(specifiedDay);
        } catch (Exception e) {
            logger.error("getDayBefore execute error. ", e);
        }
        c.setTime(Objects.requireNonNull(date));
        int day = c.get(Calendar.DATE);
        c.set(Calendar.DATE, day - beforeCount);

        return new SimpleDateFormat(dateFormat).format(c.getTime());
    }

    public static String getMonthBefore(String specifiedMonth, String dateFormat, int beforeCount) {
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat(dateFormat).parse(specifiedMonth);
        } catch (Exception e) {
            logger.error("getDayBefore execute error. ", e);
        }
        c.setTime(Objects.requireNonNull(date));
        int month = c.get(Calendar.MONTH);
        c.set(Calendar.MONTH, month - beforeCount);

        return new SimpleDateFormat(dateFormat).format(c.getTime());
    }

    /**
     * get the day before specifiedDay
     *
     * @param specifiedDay 日期数据
     * @param dateFormatIn 日期数据格式
     * @param beforeCount  如果需要前一天的数据，则为1
     * @return 获取期望的日期数据
     */
    public static String getDayBefore(String specifiedDay, int beforeCount, String dateFormatIn, String dateFormatOut) {
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat(dateFormatIn).parse(specifiedDay);
        } catch (Exception e) {
            logger.error("getDayBefore execute error. ", e);
        }
        c.setTime(Objects.requireNonNull(date));
        int day = c.get(Calendar.DATE);
        c.set(Calendar.DATE, day - beforeCount);

        return new SimpleDateFormat(dateFormatOut).format(c.getTime());
    }

    /**
     * get the day after specifiedDay
     *
     * @param specifiedDay 具体日期
     * @param dateFormat   具体日期的格式
     * @param afterCount   如果需要后一天的日期，则为1
     * @return 期望的日期数据
     */
    public static String getDayAfter(String specifiedDay, String dateFormat, int afterCount) {
        Calendar c = Calendar.getInstance();
        Date date = null;
        try {
            date = new SimpleDateFormat(dateFormat).parse(specifiedDay);
        } catch (Exception e) {
            logger.error("getDayAfter execute error. ", e);
        }
        c.setTime(Objects.requireNonNull(date));
        int day = c.get(Calendar.DATE);
        c.set(Calendar.DATE, day + afterCount);

        return new SimpleDateFormat(dateFormat).format(c.getTime());
    }

    /**
     * Get date list
     *
     * @param startDate  开始日期
     * @param endDate    结束日期
     * @param dateFormat 日期的格式
     * @return 开始和结束日期期间内的日期列表，包含开始和结束日期
     */
    public static List<String> getDateList(String startDate, String endDate, String dateFormat) {
        List<String> dateList = new ArrayList<>();
        if (Long.parseLong(startDate.replaceAll("[^\\d]", "")) > Long.parseLong(endDate.replaceAll("[^\\d]", "")))
            return dateList;
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        String lastDate = startDate;
        dateList.add(lastDate);
        try {
            Calendar cal = Calendar.getInstance();
            while (!StringUtils.equalsIgnoreCase(lastDate, endDate)) {
                cal.setTime(sdf.parse(lastDate));
                cal.add(Calendar.DAY_OF_MONTH, 1);
                lastDate = sdf.format(cal.getTime());
                dateList.add(lastDate);
            }
        } catch (Exception e) {
            logger.error("get dateList error. beginDate: {}, endDate: {}", startDate, endDate);
        }
        return dateList;
    }

    public static void main(String[] args) throws NumberParseException, ParseException {
//	    KeyInfo k = new KeyInfo("江西省^11,萍乡市^12,芦溪县^13,万龙山乡^15,君澜温泉住宅小区^213,5栋^214");
//	    Map<String, String> t = k.pick_key();
//		System.out.println(t.get("key_word"));
//        System.out.println(t.get("key_tag"));
//        PhoneNumberOfflineGeocoder phoneNumberOfflineGeocoder = PhoneNumberOfflineGeocoder.getInstance();
//        PhoneNumberUtil phoneUtil = PhoneNumberUtil.getInstance();
//        Phonenumber.PhoneNumber referencePhonenumber = phoneUtil.parse("17327911830", "CN");
//        String location = phoneNumberOfflineGeocoder.getDescriptionForNumber(referencePhonenumber, Locale.CHINA);
//        String regex = ".*([a-zA-Z0-9]{1,4})(号楼|号院|栋|座|幢|坐|区|期|组).*";
//        Matcher m = Pattern.compile(regex).matcher("软件产业基地A00000座");
//        System.out.println("result: " + m.matches());

//        KeyInfo key = new KeyInfo("广东省^11,深圳市^12,龙华区^03,大信花园^213,二期^613,15栋^214");
//        Map<String, String> keyMap = key.pick_key();
//        if (keyMap != null) {
//            System.out.println(AddrUtil.transferNumber(keyMap.get("key_word")).toLowerCase());
//            System.out.println(AddrUtil.transferNumber(keyMap.get("key_tag")).toLowerCase());
//        }
//        List<Date> list = new ArrayList<>();
//        list.add(new Date(1645576384));
//        list.add(new Date(1645696384));
//        list.sort((a,b) -> a.compareTo(b));
//        System.out.println(list.get(0));
//        System.out.println(list.get(1));
//
////        System.out.println(new Date(1645576384));
//        System.out.println(DateUtil.formatDate(new Date(Long.parseLong("1645576384")), "yyyyMMddHHmmssSSS"));
//        System.out.println(DateUtil.formatDate(new Date(Long.parseLong("1645696384")), "yyyyMMddHHmmssSSS"));
//        System.out.println(Long.parseLong("1645696384")-Long.parseLong("1645576384"));
//        System.out.println(getTime(DateUtil.formatDate(new Date(Long.parseLong("1645576384")), "yyyyMMddHHmmssSSS"), DateUtil.formatDate(new Date(Long.parseLong("1645696384")), "yyyyMMddHHmmssSSS"), "yyyyMMddHHmmssSSS"));

//        System.out.println(DateUtil.formatDate(new Date(Long.parseLong("1645576384")), "yyyyMMddHHmmss").substring(0, 10));
//        System.out.println(14 / 15);


//        System.out.println("123".substring(0,1));

//        List<String> time = new ArrayList<>();
//        time.add("202103051236");
//        time.add("202103061236");
//        time.add("202103041236");
//        time.add("202103091236");
//        time.sort((a, b) -> a.compareTo(b));
//        time.forEach(o -> System.out.println(o));
//
//        System.out.println(getTime("19841006125323", "19841006125423", "yyyyMMddHHmmss") / 1000);
        System.out.println(getMonthBefore(getCurrentDate("yyyyMM"), "yyyyMM", 1));
    }

    /**
     * 返回当前时间戳差值的分钟值
     *
     * @param tm1
     * @param tm2
     * @return
     */
    public static long getCurrentMinDiff(long tm1, long tm2) {
        long res = (tm2 - tm1) / (1000 * 60);
        return res > 1440 || res < 0 ? -1 : res;
    }

    /**
     * 获取指定时间往前多少天的日期, 不包含当天
     *
     * @param dateTime
     * @param daysCount
     * @param pattern
     * @return
     * @throws ParseException
     */
    public static List<String> getDaysAgoMulti(String dateTime, int daysCount, String pattern) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(sdf.parse(dateTime));
        int tmpDays = daysCount;
        List<String> list = new ArrayList<>();
        while (tmpDays > 0) {
            calendar.add(Calendar.DAY_OF_MONTH, -1);
            list.add(sdf.format(calendar.getTime()));
            tmpDays--;
        }
        return list;
    }

    public static String getDaysBefore(int delta, String dateFormat) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate localDate = LocalDate.now();
        return localDate.minusDays(delta).format(df);
    }

    public static String getDaysBefore(String spDate, int delta) {
        return getDaysBefore(spDate, delta, DEFAULT_DATE_FORMAT);
    }

    public static String getDaysBefore(String spDate, int delta, String dateFormat) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate localDate = LocalDate.parse(spDate, df);
        return localDate.minusDays(delta).format(df);
    }

    public static String dateToStamp(String s) {
        String res = "";
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date date = simpleDateFormat.parse(s);
            long ts = date.getTime();
            res = String.valueOf(ts);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    public static String tmToDate(String tm, String formate) {
        String sd = "";
        if (StringUtils.isNotEmpty(tm)) {
            SimpleDateFormat sdf = new SimpleDateFormat(formate);
            sd = sdf.format(new Date(Long.parseLong(tm)));      // 时间戳转换成时间
        }
        return sd;
    }

    public static long getLongFromDate(String s, String format) {
        long res = 0;
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
            Date date = simpleDateFormat.parse(s);
            res = date.getTime();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return res;
    }

    /**
     * 时间按月分片
     *
     * @param startDate
     * @param endDate
     * @param yyyyMMddFormat
     * @param yyMMFormat
     * @return
     */
    public static List<String[]> dateSliceByMonth(String startDate, String endDate, String yyyyMMddFormat, String yyMMFormat) throws ParseException {
        List<String[]> dateSlice = new ArrayList<>();
        String tempStartDate = startDate;
        SimpleDateFormat yyyyMMdd = new SimpleDateFormat(yyyyMMddFormat);
        SimpleDateFormat yyyyMM = new SimpleDateFormat(yyMMFormat);
        while (tempStartDate.compareTo(endDate) <= 0) {
            Date tempStartD = yyyyMMdd.parse(tempStartDate);
            Calendar cal = Calendar.getInstance();
            cal.setTime(tempStartD);

            int last = cal.getActualMaximum(Calendar.DAY_OF_MONTH);  //获取当前月份最后一天
            cal.set(Calendar.DAY_OF_MONTH, last);
            String tempEndDate = yyyyMMdd.format(cal.getTime());    //获取最后一天日期
            if (tempEndDate.compareTo(endDate) > 0) {
                tempEndDate = endDate;
            }
            String month = yyyyMM.format(cal.getTime());    //获取当前月份
            dateSlice.add(new String[]{month, tempStartDate, tempEndDate}); //月份，开始日期，结束日期

            cal.add(Calendar.DAY_OF_MONTH, 1);  //下个月1号
            tempStartDate = yyyyMMdd.format(cal.getTime());
        }
        return dateSlice;
    }

    public static String parseFormat(String date) {
        if (StringUtils.isNotEmpty(date)) {
            SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMdd");
            SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
            try {
                date = sdf2.format(sdf1.parse(date));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return date;
    }

    public static String getMouthBefore(String date, int delta) {
        return getMouthBefore(date, delta, DEFAULT_DATE_FORMAT);
    }

    public static String getMouthBefore(String date, int delta, String dateFormat) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate localDate = LocalDate.parse(date, df);
        localDate = localDate.minusMonths(delta);
        return localDate.format(df);
    }

    public static String getFirstDayOfMonth(String date) {
        return getFirstDayOfMonth(date, DEFAULT_DATE_FORMAT);
    }

    public static String getFirstDayOfMonth(String date, String dateFormat) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate localDate = LocalDate.parse(date, df);
        return localDate.with(TemporalAdjusters.firstDayOfMonth()).format(df);
    }

    public static String getLastDayOfMonth(String date) {
        return getLastDayOfMonth(date, DEFAULT_DATE_FORMAT);
    }

    public static String getLastDayOfMonth(String date, String dateFormat) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(dateFormat);
        LocalDate localDate = LocalDate.parse(date, df);
        return localDate.with(TemporalAdjusters.lastDayOfMonth()).format(df);
    }

    public static String getTheTimeInSeconds() {
        SimpleDateFormat time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        return time.format(date);
    }
}
