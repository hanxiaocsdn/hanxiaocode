package com.sf.gis.java.base.dto;

/**
 * At收入参
 */
public class AtconsigneeTeamByaddrIn {

    private String ak = "";  // 必填项
    private String opt = "";   // 非必填。识别策略-zh或缺省：综合识别策略，内部有一套识别算法。norm：标准库识别；normdetail：标准库识别带返回详细识别信息；chkn：审补库识别；phonenew：新电话库识别；dispatch：派件识别；tc2：tc2识别；schd：sch识别
    private String needAoiArea = "";  // 非必填。是否显示AOI区域 - 1：显示
    private String callDispatch = "";  // 非必填。是否调用派件 - 1：调用
    private String isNotUnderCall = "";  // 非必填。是否非下call - 1：是
    private String province = "";  // 非必填。省名称
    private String city = "";  // 必填。cityCode
    private String cityName = "";  // 非必填。城市名称
    private String district = "";  // 非必填。区名称
    private String address = "";  // 必填。地址
    private String tel = "";  // 非必填。座机
    private String mobile = "";  // 非必填。手机
    private String company = "";  // 非必填。公司名称
    private String contacts = "";  // 非必填。联系人
    private String customerAccount = ""; // 非必填。月结账号

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    public String getNeedAoiArea() {
        return needAoiArea;
    }

    public void setNeedAoiArea(String needAoiArea) {
        this.needAoiArea = needAoiArea;
    }

    public String getCallDispatch() {
        return callDispatch;
    }

    public void setCallDispatch(String callDispatch) {
        this.callDispatch = callDispatch;
    }

    public String getIsNotUnderCall() {
        return isNotUnderCall;
    }

    public void setIsNotUnderCall(String isNotUnderCall) {
        this.isNotUnderCall = isNotUnderCall;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getContacts() {
        return contacts;
    }

    public void setContacts(String contacts) {
        this.contacts = contacts;
    }

    public String getCustomerAccount() {
        return customerAccount;
    }

    public void setCustomerAccount(String customerAccount) {
        this.customerAccount = customerAccount;
    }

    @Override
    public String toString() {
        return "AtconsigneeTeamByaddrIn{" +
                "ak='" + ak + '\'' +
                ", opt='" + opt + '\'' +
                ", needAoiArea='" + needAoiArea + '\'' +
                ", callDispatch='" + callDispatch + '\'' +
                ", isNotUnderCall='" + isNotUnderCall + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", cityName='" + cityName + '\'' +
                ", district='" + district + '\'' +
                ", address='" + address + '\'' +
                ", tel='" + tel + '\'' +
                ", mobile='" + mobile + '\'' +
                ", company='" + company + '\'' +
                ", contacts='" + contacts + '\'' +
                ", customerAccount='" + customerAccount + '\'' +
                '}';
    }
}
