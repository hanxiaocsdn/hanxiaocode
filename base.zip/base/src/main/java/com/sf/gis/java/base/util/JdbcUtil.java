package com.sf.gis.java.base.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.Properties;
import ru.yandex.clickhouse.*;
import ru.yandex.clickhouse.settings.ClickHouseProperties;

public class JdbcUtil {

    private static final Logger logger = LoggerFactory.getLogger(JdbcUtil.class);

    public static Connection getMysqlConnection(String dbCfgName) {
        Properties dbPro = ConfigUtil.loadPropertiesConfiguration(dbCfgName);
        return getMysqlConnection(dbPro.get("url").toString(), dbPro.get("user").toString(), dbPro.get("password").toString());
    }

    public static Connection getMysqlConnection(String url, String user, String password) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            logger.info("getMysqlConnection err. ", e);
        }
        return null;
    }

    public static Connection getClickHouseConnection(String dbCfgName) {
        Properties dbPro = ConfigUtil.loadPropertiesConfiguration(dbCfgName);
        return getClickHouseConnection(dbPro.get("url").toString(), dbPro.get("user").toString(), dbPro.get("password").toString());
    }

    /**
     * 获取clickhouse的连接
     * @param url eg:jdbc:clickhouse://<first-host>:<port>,<second-host>:<port>/<database>
     * @param user 用户名
     * @param password 密码
     * @return ch库的连接
     */
    public static Connection getClickHouseConnection(String url, String user, String password) {
        Connection conn = null;
        try {
            ClickHouseProperties prop=new ClickHouseProperties();
            prop.setUser(user);
            prop.setPassword(password);
            BalancedClickhouseDataSource dataSource = new BalancedClickhouseDataSource(url, prop);
            conn = dataSource.getConnection();
            if (conn != null) {
                logger.error("clickhouse连接成功！{}", url);
            }
        } catch (Exception e) {
            logger.info("getClickHouseConnection err. ", e);
        }
        return conn;
    }

    /**
     * 释放资源
     */
    public static void close(Connection conn, Statement stmt, ResultSet rs) {
        if (stmt!=null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(conn, rs);
    }

    /**
     * 释放资源
     */
    public static void close(Connection conn, PreparedStatement pstm, ResultSet rs) {
        if (pstm!=null) {
            try {
                pstm.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        close(conn, rs);
    }

    private static void close(Connection conn, ResultSet rs) {
        if (rs!=null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (conn!=null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
