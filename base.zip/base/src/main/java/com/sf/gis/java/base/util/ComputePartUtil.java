package com.sf.gis.java.base.util;

public class ComputePartUtil {
    public static int computePart(long count) {
        int partSize = Integer.valueOf("2000000");
        return (int) (count % partSize == 0 ? count / partSize : count / partSize + 1);
    }
}
