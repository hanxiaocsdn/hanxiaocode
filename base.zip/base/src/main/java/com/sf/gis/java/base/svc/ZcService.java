package com.sf.gis.java.base.svc;

import com.github.davidmoten.geo.LatLong;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.pojo.AoiInfo;
import com.sf.gis.java.base.pojo.ZcInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import org.apache.spark.api.java.JavaRDD;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 网点服务类
 * @author 01370539 created on Aug.16 2021
 */
public class ZcService {
    private static final Logger logger = LoggerFactory.getLogger(ZcService.class);

    /**
     * 网点坐标获取
     * @param si spark相关信息
     * @return 网点坐标信息
     */
    public JavaRDD<ZcInfo> getZcPoint(SparkInfo si) {
        String sql = "select code zc, lat, lng from dm_gis.polygon_all where inc_day = '" + DateUtil.getDayBefore(DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY), FixedConstant.DATE_FORMATE_INCDAY, 2) + "' and type = '1'";
        return DataUtil.loadData(si, sql, ZcInfo.class);
    }
    /**
     * 网点坐标获取，经过城市编码过滤
     * @param si spark相关信息
     * @param cityCode 城市编码
     * @return 网点坐标信息
     */
    public JavaRDD<ZcInfo> getZcPoint(SparkInfo si, String cityCode) {
        String sql = "select code zc, lat, lng from dm_gis.polygon_all where inc_day = '" + DateUtil.getDayBefore(DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY), FixedConstant.DATE_FORMATE_INCDAY, 2) + "' and city_code = '" + cityCode + "' and type = '1'";
        return DataUtil.loadData(si, sql, ZcInfo.class);
    }

    public JavaRDD<AoiInfo> getCmsAoi(SparkInfo si) {
        String sql = "select aoi_id, aoi_code, aoi_name, city_code, zno_code, fa_type, other_name, road_name, road_number, geom_area from dm_gis.cms_aoi where inc_day = '" + DateUtil.getDayBefore(DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY), FixedConstant.DATE_FORMATE_INCDAY, 1) + "' and del_flag = 0";
        return DataUtil.loadData(si, sql, AoiInfo.class);
    }

    public JavaRDD<AoiInfo> getCmsAoi(SparkInfo si, String cityCode) {
        String sql = "select aoi_id, aoi_code, aoi_name, city_code, zno_code, fa_type, other_name, road_name, road_number, geom_area from dm_gis.cms_aoi where inc_day = '" + DateUtil.getDayBefore(DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY), FixedConstant.DATE_FORMATE_INCDAY, 1) + "' and city_code = '" + cityCode + "' and del_flag = 0";
        return DataUtil.loadData(si, sql, AoiInfo.class);
    }
}
