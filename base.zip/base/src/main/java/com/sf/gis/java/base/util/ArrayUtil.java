package com.sf.gis.java.base.util;

import java.util.List;

public class ArrayUtil {
    public static String joinArr(Object[] arr, String sep) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < arr.length; i++) {
            Object item = arr[i];
            if (i == arr.length - 1) {
                builder.append(item != null ? item.toString() : "");
            } else {
                builder.append(item != null ? item.toString() : "").append(sep);
            }
        }
        return builder.toString();
    }

    public static String joinArr(String sep, Object... args) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < args.length; i++) {
            Object item = args[i];
            if (i == args.length - 1) {
                builder.append(item != null ? item.toString() : "");
            } else {
                builder.append(item != null ? item.toString() : "").append(sep);
            }
        }
        return builder.toString();
    }

    public static String joinArr(List<String> list, String sep) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < list.size(); i++) {
            String item = list.get(i);
            if (i == list.size() - 1) {
                builder.append(item != null ? item.toString() : "");
            } else {
                builder.append(item != null ? item.toString() : "").append(sep);
            }
        }
        return builder.toString();
    }

}
