package com.sf.gis.java.base.util;

import org.apache.hadoop.util.hash.MurmurHash;

import java.io.IOException;
import java.text.ParseException;

import static com.alibaba.druid.util.Utils.md5;

public class SaltUtil {

	public static String generateSalt(String value, int partition) {
		StringBuffer salt = new StringBuffer("");
		long hashCode = MurmurHash.getInstance().hash(value.getBytes());

		if(hashCode < 0) {
			hashCode = 0 - hashCode;
		}

		long mod = hashCode % partition;
		if(partition <= 10) {
			salt.append(mod);
		} else if(partition <= 100) {
			salt.append(String.format("%02d", mod));
		} else if(partition <= 1000) {
			salt.append(String.format("%03d", mod));
		} else if(partition <= 10000) {
			salt.append(String.format("%04d", mod));
		}

		return salt.toString();
	}

	public static String generateSaltNew(String value, int partition) {
		String md5 = MD5Util.getMD5(value).toLowerCase();
//		System.out.println(md5);

		StringBuffer salt = new StringBuffer("");
		//int hashCode = value.hashCode();
		long hashCode = MurmurHash.getInstance().hash(md5.getBytes());

		if(hashCode < 0) {
			hashCode = 0 - hashCode;
		}

		long mod = hashCode % partition;
		if(partition <= 10) {
			salt.append(mod);
		} else if(partition <= 100) {
			salt.append(String.format("%02d", mod));
		} else if(partition <= 1000) {
			salt.append(String.format("%03d", mod));
		} else if(partition <= 10000) {
			salt.append(String.format("%04d", mod));
		}

		return salt.toString();
	}

	public static void main(String[] args) throws ParseException, IOException {
    	int dataTbPartitionNum = 10; // hbae表预分区数量
		String waybillno = "123456"; //金管家运单号
		String date = "20200611" ; //金管家日期
		String status = "0" ; //0:代表普通数据, 1：为失败数据
		String ip = "ip1" ; //机器ip, 实际长度越小也好，能用简单数字标识就最好。

		String md5Key = md5(date) ;  // 32位的md5小写值，为了打散hash值  ，实际只存储16位,能够满足数据量级
		String rowkey = SaltUtil.generateSalt(md5Key, dataTbPartitionNum) + "_" + md5Key.substring(0,16)+"_"+status+"_"+ip + "_" + waybillno;
		System.out.println(rowkey);
		//数据需要存储的value值:
		// 除了接口传过来的数据，还需要存储以下值：
		// state：数据处理状态(方便查找问题)，默认为0，已处理为1
		// ip : 服务器ip(不变的映射后ip，越短越好)
	}
	
}