package com.sf.gis.java.base.dto;

import java.io.Serializable;

public class PointDto implements Serializable {
    private String id;   // 点的ID（唯一标识一个点）
    private double lng;  // 经度
    private double lat;   // 纬度
    private Long tm;   // 时间（长整形）

    public PointDto() {
    }

    public PointDto(String id, double lng, double lat, Long tm) {
        this.id = id;
        this.lng = lng;
        this.lat = lat;
        this.tm = tm;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public Long getTm() {
        return tm;
    }

    public void setTm(Long tm) {
        this.tm = tm;
    }

    @Override
    public String toString() {
        return "PointDto{" +
                "id='" + id + '\'' +
                "lng='" + lng + '\'' +
                ", lat='" + lat + '\'' +
                ", tm='" + tm + '\'' +
                '}';
    }
}
