package com.sf.gis.java.base.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Table
public class WbTrack implements Serializable {

    @Column(name = "waybill_no")
    private String waybillNo;

    @Column(name = "aoi_id")
    private String aoiId;

    @Column(name = "courier")
    private String courier;

    @Column(name = "bar_scan_tm")
    private String barScanTm;

    @Column(name = "lng_track")
    private String lngTrack;

    @Column(name = "lat_track")
    private String latTrack;

    @Column(name = "tm_track")
    private String tmTrack;

    @Column(name = "id_track")
    private String idTrack;

    @Column(name = "tp_track")
    private String tpTrack;

    @Column(name = "ac_track")
    private String acTrack;

    @Column(name = "bn_track")
    private String bnTrack;

    @Column(name = "ewl_track")
    private String ewlTrack;

    @Column(name = "app_track")
    private String appTrack;

    @Column(name = "dis")
    private String dis;

    @Column(name = "inc_day")
    private String incDay;

    public WbTrack(){
    }

    public WbTrack(WbTrack wbTrack) {
        this.waybillNo = wbTrack.getWaybillNo();
        this.aoiId = wbTrack.getAoiId();
        this.courier = wbTrack.getCourier();
        this.barScanTm = wbTrack.getBarScanTm();
        this.lngTrack = wbTrack.getLngTrack();
        this.latTrack = wbTrack.getLatTrack();
        this.tmTrack = wbTrack.getTmTrack();
        this.idTrack = wbTrack.getIdTrack();
        this.tpTrack = wbTrack.getTpTrack();
        this.acTrack = wbTrack.getAcTrack();
        this.bnTrack = wbTrack.getBnTrack();
        this.ewlTrack = wbTrack.getEwlTrack();
        this.appTrack = wbTrack.getAppTrack();
        this.dis = wbTrack.getDis();
        this.incDay = wbTrack.getIncDay();
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getCourier() {
        return courier;
    }

    public void setCourier(String courier) {
        this.courier = courier;
    }

    public String getBarScanTm() {
        return barScanTm;
    }

    public void setBarScanTm(String barScanTm) {
        this.barScanTm = barScanTm;
    }

    public String getLngTrack() {
        return lngTrack;
    }

    public void setLngTrack(String lngTrack) {
        this.lngTrack = lngTrack;
    }

    public String getLatTrack() {
        return latTrack;
    }

    public void setLatTrack(String latTrack) {
        this.latTrack = latTrack;
    }

    public String getTmTrack() {
        return tmTrack;
    }

    public void setTmTrack(String tmTrack) {
        this.tmTrack = tmTrack;
    }

    public String getIdTrack() {
        return idTrack;
    }

    public void setIdTrack(String idTrack) {
        this.idTrack = idTrack;
    }

    public String getTpTrack() {
        return tpTrack;
    }

    public void setTpTrack(String tpTrack) {
        this.tpTrack = tpTrack;
    }

    public String getAcTrack() {
        return acTrack;
    }

    public void setAcTrack(String acTrack) {
        this.acTrack = acTrack;
    }

    public String getBnTrack() {
        return bnTrack;
    }

    public void setBnTrack(String bnTrack) {
        this.bnTrack = bnTrack;
    }

    public String getEwlTrack() {
        return ewlTrack;
    }

    public void setEwlTrack(String ewlTrack) {
        this.ewlTrack = ewlTrack;
    }

    public String getAppTrack() {
        return appTrack;
    }

    public void setAppTrack(String appTrack) {
        this.appTrack = appTrack;
    }

    public String getDis() {
        return dis;
    }

    public void setDis(String dis) {
        this.dis = dis;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "WbTrack{" +
                "waybillNo='" + waybillNo + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", courier='" + courier + '\'' +
                ", barScanTm='" + barScanTm + '\'' +
                ", lngTrack='" + lngTrack + '\'' +
                ", latTrack='" + latTrack + '\'' +
                ", tmTrack='" + tmTrack + '\'' +
                ", idTrack='" + idTrack + '\'' +
                ", tpTrack='" + tpTrack + '\'' +
                ", acTrack='" + acTrack + '\'' +
                ", bnTrack='" + bnTrack + '\'' +
                ", ewlTrack='" + ewlTrack + '\'' +
                ", appTrack='" + appTrack + '\'' +
                ", dis='" + dis + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
