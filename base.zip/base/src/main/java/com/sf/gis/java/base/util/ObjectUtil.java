package com.sf.gis.java.base.util;

import com.sf.gis.java.base.pojo.SortAnnotation;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import javax.persistence.Column;

/**
 * Created by 01374443 on 2021/4/26.
 */

public class ObjectUtil {
    public static HashMap<String, Object> toHashMapByAnnotationColumn(Object obj) throws IllegalArgumentException, IllegalAccessException {
        HashMap<String, Object> map = new HashMap<>();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (Field field : fields) {
            Column tmp = field.getAnnotation(Column.class);
            if (tmp == null) {
                continue;
            }
            String varName = tmp.name();
            boolean accessFlag = field.isAccessible();
            field.setAccessible(true);

            Object o = field.get(obj);
            if (o != null)
                map.put(varName, o.toString());

            field.setAccessible(accessFlag);
        }

        return map;
    }

    public static List<String> getAnnotationColumn(Class<?> inputClass) throws Exception {
        Object obj = inputClass.newInstance();
        List<String> ret = new ArrayList<>();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (Field field : fields) {
            Column tmp = field.getAnnotation(Column.class);
            if (tmp == null) {
                continue;
            }
            String varName = tmp.name();
            ret.add(varName);
        }
        return ret;
    }

    /**
     * 获取排序注解类的注解
     *
     * @param obj 需要获取排序注解的对象
     * @return 注解信息
     */
    public static HashMap<String, Object> toHashMapBySortAnnotation(Object obj) throws IllegalArgumentException, IllegalAccessException {
        HashMap<String, Object> map = new HashMap<>();
        Field[] fields = obj.getClass().getDeclaredFields();
        for (Field field : fields) {
            SortAnnotation tmp = field.getAnnotation(SortAnnotation.class);
            if (tmp == null) {
                continue;
            }
            String varName = field.getName();
            boolean accessFlag = field.isAccessible();
            field.setAccessible(true);

            Object o = field.get(obj);
            if (o != null)
                map.put(varName, o.toString());

            field.setAccessible(accessFlag);
        }

        return map;
    }

    /**
     * 按照对应列的标号获取数据
     *
     * @param obj 需要按照标号获取数据的对象
     * @return 按照对应列的标号获取到的数据
     */
    public static String[] toArrayByColumns(Object obj, List<Integer> columns) throws IllegalArgumentException, IllegalAccessException {
        Field[] fields = obj.getClass().getDeclaredFields();
        String[] ret = new String[columns.size()];
        for (int i = 0; i < columns.size(); i++) {
            Field field = fields[columns.get(i)];
            Object o = field.get(obj);
            if (o != null)
                ret[i] = o.toString();
            else
                ret[i] = "";
        }
        return ret;
    }

    /**
     * 按照排序注解类的排序，输出列名
     *
     * @param fields 字段数组
     * @return 排序后的结果
     */
    public static List<Integer> getAnnotationColumnBySort(Field[] fields) {
        List<Integer[]> ret = new ArrayList<>();
        for (int i = 0, len = fields.length; i < len; i++) {
            SortAnnotation tmp = fields[i].getAnnotation(SortAnnotation.class);
            if (tmp == null) {
                continue;
            }
            int sort = tmp.sort();
            ret.add(new Integer[]{i, sort});
        }
        ret.sort((p1, p2) -> p1[1]-p2[1]);
        return ret.stream().map(x -> x[0]).collect(Collectors.toList());
    }

    /**
     * 按照排序注解类的排序，输出列名
     *
     * @param fields 字段名
     * @return 排序后的结果
     */
    public static String[] getColumnsNameByFieldIndex(Field[] fields, List<Integer> columns) {

        String[] ret = new String[columns.size()];
        for (int i = 0; i < columns.size(); i++) {
            ret[i] = fields[columns.get(i)].getName();
        }
        return ret;
    }
}
