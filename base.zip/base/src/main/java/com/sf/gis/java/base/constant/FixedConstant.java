package com.sf.gis.java.base.constant;

/**
 * 所有工程公用的不可变常量
 * @author 01370539 Created on Apr.30 2021
 */
public class FixedConstant {
	public static final String CHARSET_UTF = "UTF-8"; // 编码格式
	public static final String LOG_LEVEL_ERROR = "ERROR"; // 日志级别：ERROR

    /***************** 行政区域统计维度 *****************/
	public static final String LOG_STAT_AA_ALL = "ALL"; // 全部
	public static final String LOG_STAT_AA_REGION = "REGION";// 大区
	public static final String LOG_STAT_AA_CITY = "CITY";// 城市

    /***************** 数据类型 *****************/
    public static final String CLASS_TYPE_INT = "int";
    public static final String CLASS_TYPE_FLOAT = "float";
    public static final String CLASS_TYPE_STRING = "java.lang.String";
    public static final String CLASS_TYPE_BOOLEAN = "boolean";
    public static final String CLASS_TYPE_DATE = "java.util.Date";

    public static final int MAX_TRY_TIME_ONCE = 1; // 最大尝试次数
    public static final int MAX_TRY_TIME_THREE = 3; // 最大尝试次数

    public static final String DATE_FORMATE_INCDAY = "yyyyMMdd"; // inc_day的格式
    public static final String DATE_FORMATE_MIN = "yyyy-MM-dd HH:mm:ss"; // inc_day的格式
    public static final String DATE_FROMAT_YYYYMMDD_GAPLESS = "yyyyMMdd";

    /************** 分隔符、参数值、结果值 **************/
    public static final String HYPHEN = "-";

    /************** 位置 **************/
    public static final String DIR_LINE = "LINE";
    public static final String DIR_RIGHT = "RIGHT";
    public static final String DIR_LEFT = "LEFT";

    /************** 服务类型 **************/
    public static final String HTTP_TYPE_PR = "PR"; // 生产环境
    public static final String HTTP_TYPE_RUNDATA = "RUNDATA"; // RUNDATA环境
    public static final String HTTP_TYPE_SIT = "SIT"; // 测试环境
}
