package com.sf.gis.java.base.constant;

/**
 * 网络接口调用状态
 */
public enum NetAccessState {
    start, //接口调用即将开始
    over;  //接口调用即将结束
}
