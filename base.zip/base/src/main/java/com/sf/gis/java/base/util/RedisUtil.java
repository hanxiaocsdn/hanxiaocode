package com.sf.gis.java.base.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.jedis.ShardedJedis;
import redis.clients.jedis.util.Pool;

import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

/**
 * Redis 工具类
 */
public class RedisUtil {
    private static final Logger logger = LoggerFactory.getLogger(RedisUtil.class);

    public static JedisSentinelPool initJedisPool(String cfgFileName) {
        Properties prop = ConfigUtil.loadPropertiesConfiguration(cfgFileName);
        JedisPoolConfig config = new JedisPoolConfig();
        config.setMinIdle(Integer.parseInt(prop.getProperty("MAX_IDLE")));
        config.setMinIdle(Integer.parseInt(prop.getProperty("MIN_IDLE")));
        config.setMaxWaitMillis(Integer.parseInt(prop.getProperty("MAX_WAIT_MILLIS")));
        String[] sentinelArr = prop.getProperty("SENTINELS").split(",");
        Set<String> sentinelSet = new HashSet<>();
        for (String sentinel : sentinelArr) {
            sentinelSet.add(new HostAndPort( sentinel.split(":")[0], Integer.parseInt(sentinel.split(":")[1])).toString());
        }
        return new JedisSentinelPool(prop.getProperty("MASTER_NAME"), sentinelSet, config, Integer.parseInt(prop.getProperty("TIMEOUT")), prop.getProperty("PASSWORD"));
    }
}
