package com.sf.gis.java.base.util;

import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sf.gis.java.base.constant.FixedConstant;

/**
 * 应用的工具类，包含一些应用共有方法
 *
 * @author 01370539 Created on Mar.25 2021
 */
public class SparkUtil {
    private static final Logger logger = LoggerFactory.getLogger(SparkUtil.class);

    /**
     * 进行spark配置
     *
     * @param className 启动spark的类
     * @return spark相关信息
     */
    public static SparkInfo getSpark(String className) {

        SparkInfo sparkInfo = getSpark4File(className);
        setCfgSplit(sparkInfo);
        return sparkInfo;
    }

    public static SparkInfo getSpark4GisBd(String className) {
        SparkInfo sparkInfo = new SparkInfo();

        // 修改spark的序列化方式，默认为org.apache.spark.serializer.JavaSerializer
        System.setProperty("spark.serializer", "org.apache.spark.serializer.KryoSerializer");

        SparkSession sparkSession = SparkSession.builder().config("hive.exec.dynamic.partition", true).config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport().getOrCreate();
        JavaSparkContext sparkContext = JavaSparkContext.fromSparkContext(sparkSession.sparkContext());
        sparkContext.setLogLevel(FixedConstant.LOG_LEVEL_ERROR);

        // Initialize spark.
        SparkConf sparkConf = sparkContext.getConf().setAppName(className).set("spark.port.maxRetries", "100").set("spark.driver.allowMultipleContexts", "true")
                .set("spark.streaming.stopGracefullyOnShutdown", "true").set("quota.producer.default", (10485760 * 2) + "").set("quota.consumer.default", (10485760 * 2) + "")
                .set("cache.max.bytes.buffering", (10485760 * 2) + "").set("spark.sql.broadcastTimeout", "86400");

        SysConstant.PARTITION_COUNT = Integer.parseInt(sparkContext.getConf().get("spark.executor.instances", "16")) * Integer.parseInt(sparkContext.getConf().get("spark.executor.cores", "2")) * 2;

        logger.error("partitions: {}", SysConstant.PARTITION_COUNT);
        logger.error("spark.executor.instances is {}", sparkContext.getConf().get("spark.executor.instances", "16"));
        logger.error("spark.executor.cores is {}", sparkContext.getConf().get("spark.executor.cores", "2"));

        sparkInfo.setConf(sparkConf);
        sparkInfo.setSession(sparkSession);
        sparkInfo.setContext(sparkContext);

        setCfgSplit(sparkInfo);

        return sparkInfo;
    }

    /**
     * 进行spark配置
     *
     * @param className 启动spark的类
     * @return spark相关信息
     */
    public static SparkInfo getSpark4File(String className) {

        SparkInfo sparkInfo = new SparkInfo();

        // 修改spark的序列化方式，默认为org.apache.spark.serializer.JavaSerializer
        System.setProperty("spark.serializer", "org.apache.spark.serializer.KryoSerializer");

        // Initialize spark.
        SparkConf sparkConf = new SparkConf().setAppName(className).set("spark.port.maxRetries", "999").set("spark.driver.allowMultipleContexts", "true")
                .set("spark.streaming.stopGracefullyOnShutdown", "true").set("spark.shuffle.service.enabled", "true").set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
                .set("spark.kryoserializer.buffer.max", "512m")
                .set("quota.producer.default", (10485760 * 2) + "").set("quota.consumer.default", (10485760 * 2) + "")
                .set("cache.max.bytes.buffering", (10485760 * 2) + "").set("spark.sql.broadcastTimeout", "86400")
                .set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=12288M")
                .set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=12288M")
                .set("spark.shuffle.compress", "true")
                .set("spark.sql.hive.mergeFiles", "true")
                .set("spark.maxRemoteBlockSizeFetchToMem", "270532608")
                .set("spark.sql.adaptive.enabled", "true")
                .set("spark.sql.adaptive.shuffle.targetPostShuffleInputSize", "67108864b")
                //.set("spark.shuffle.spill.numElementsForceSpillThreshold", "2000000")
                .set("spark.sql.adaptive.join.enabled", "true")
                .set("spark.sql.autoBroadcastJoinThreshold", "20971520");

        JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);
        sparkContext.setLogLevel(FixedConstant.LOG_LEVEL_ERROR);

        SparkSession sparkSession = SparkSession.builder().config(sparkConf).config("hive.exec.dynamic.partition", true).config("hive.exec.dynamic.partition.mode", "nonstrict").enableHiveSupport()
                .getOrCreate();

        SysConstant.PARTITION_COUNT = Integer.parseInt(sparkContext.getConf().get("spark.executor.instances", "16")) * Integer.parseInt(sparkContext.getConf().get("spark.executor.cores", "2")) * 10;
        SysConstant.THREAD_COUNT = Integer.parseInt(sparkContext.getConf().get("spark.executor.instances", "16")) * Integer.parseInt(sparkContext.getConf().get("spark.executor.cores", "2"));
        logger.error("partitions: {}", SysConstant.PARTITION_COUNT);
        logger.error("spark.executor.instances is {}", sparkContext.getConf().get("spark.executor.instances", "16"));
        logger.error("spark.executor.cores is {}", sparkContext.getConf().get("spark.executor.cores", "2"));

        sparkInfo.setConf(sparkConf);
        sparkInfo.setSession(sparkSession);
        sparkInfo.setContext(sparkContext);
        return sparkInfo;
    }

    public static void setCfgSplit(SparkInfo si) {
        // 每个Map最大数据大小
        si.getSession().sql("set mapred.max.split.size=120000000");
        // 每个节点处理的最小split
        si.getSession().sql("set mapred.min.split.size.per.node = 120000000");
        // 每个机架处理的最小split
        si.getSession().sql("set mapred.min.split.size.per.rack = 120000000");
        // 执行map前进行小文件合并
        si.getSession().sql("set hive.input.format = org.apache.hadoop.hive.ql.io.CombineHiveInputFormat");
    }
}
