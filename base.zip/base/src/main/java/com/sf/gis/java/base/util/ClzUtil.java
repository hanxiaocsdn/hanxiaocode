package com.sf.gis.java.base.util;

import javax.persistence.Column;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class ClzUtil {

    public static List<Field> getAllFieldList(Class<?> clazz) {
        Class<?> clazzTmp = clazz;
        List<Field> fieldList = new ArrayList<>();
        while (clazzTmp != null) {
            fieldList.addAll(new ArrayList<>(Arrays.asList(clazzTmp.getDeclaredFields())));
            clazzTmp = clazzTmp.getSuperclass();
        }
        return fieldList;
    }

    public static Field[] getAllFieldArr(Class<?> clazz) {
        List<Field> fieldList = getAllFieldList(clazz);
        Field[] fields = new Field[fieldList.size()];
        fieldList.toArray(fields);
        return fields;
    }

    public static <T> List<String> getColumnList(Class<T> tClass) {
        List<String> result = new LinkedList<>();
        Field[] fields = tClass.getDeclaredFields();
        Column[] cols;
        for (Field field : fields) {
            cols = field.getAnnotationsByType(Column.class);
            if (cols.length > 0) {
                result.add(cols[0].name());
            }
        }
        return result;
    }

    public static <T> String[] getColumnArr(Class<T> tClass) {
        List<String> result = getColumnList(tClass);
        return result.toArray(new String[result.size()]);
    }
}
