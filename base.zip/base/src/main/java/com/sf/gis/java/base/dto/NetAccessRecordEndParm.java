package com.sf.gis.java.base.dto;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.StrUtils;


import java.io.Serializable;
import java.util.Date;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-08-17 17:43
 * @TaskId:
 * @TaskName:
 * @Description: 网络接口调用结束时，上传需要的参数
 */
public class NetAccessRecordEndParm implements Serializable {
    //开始时返回的记录id
    private String id;
    //结束时间
    private String invokeEndTm;
    //结束时间
    private String taskEndTm;
    public NetAccessRecordEndParm(){

    }

    public NetAccessRecordEndParm(String id) {
        this.id = id;
        this.invokeEndTm = DateUtil.formatDate(new Date(), "yyyyMMddHHmmss");
        this.taskEndTm = invokeEndTm;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getInvokeEndTm() {
        return invokeEndTm;
    }

    public void setInvokeEndTm(String invokeEndTm) {
        this.invokeEndTm = invokeEndTm;
    }

    public String getTaskEndTm() {
        return taskEndTm;
    }

    public void setTaskEndTm(String taskEndTm) {
        this.taskEndTm = taskEndTm;
    }

    public void checkEmpty() {
        if(StrUtils.isBlank(id)){
            System.out.println("***********请务必上传id,从开始的记录返回值中获取*****************");
        }
    }
}
