package com.sf.gis.java.base.util;

import com.mchange.v2.c3p0.ComboPooledDataSource;
import com.sf.shiva.oms.csm.utils.common.dto.NsCfgDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class DbUtil {
    private static volatile DbUtil instance;
    private static ComboPooledDataSource dataSource;
    private static Logger logger = LoggerFactory.getLogger(DbUtil.class);
    private static volatile Properties props =null;

    private DbUtil() throws PropertyVetoException {
        dataSource = new ComboPooledDataSource();

        dataSource.setDriverClass(props.getProperty("driver"));
        dataSource.setJdbcUrl(props.getProperty("url"));
        dataSource.setUser(props.getProperty("username"));
        dataSource.setPassword(props.getProperty("password"));
        dataSource.setInitialPoolSize(Integer.parseInt(props.getProperty("initialPoolSize")));
        dataSource.setMinPoolSize(Integer.parseInt(props.getProperty("minPoolSize")));
        dataSource.setMaxPoolSize(Integer.parseInt(props.getProperty("maxPoolSize")));
        dataSource.setMaxStatements(Integer.parseInt(props.getProperty("maxStatement")));
        dataSource.setConnectionCustomizerClassName("com.sf.gis.java.base.dto.ConnectionCustomizer");
    }

    public static DbUtil getInstance(String fileName){
        instance = null;
        if(instance == null){
            synchronized (DbUtil.class){
                if(instance == null){
                    try {
                        props = ConfigUtil.loadPropertiesConfiguration(fileName);
                        instance = new DbUtil();
                    } catch (PropertyVetoException e) {
                        logger.error("创建数据库连接池异常", e);
                    }
                }
            }
        }
        return instance;
    }

    public Connection getConn(){
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
        } catch (SQLException e) {
            logger.error(String.format("获取数据库连接异常:driver-%s,db-%s,user-%s,passwd-%s", props.getProperty("driver"),
                    props.getProperty("url"), props.getProperty("username"), props.getProperty("password")), e);
        }
        return conn;
    }

    public static List<NsCfgDto> getNsCfgList() {
        String dbConfig = "rls-mysql.properties";
        Connection conn = DbUtil.getInstance(dbConfig).getConn();
        List<NsCfgDto> nsCfgList = new ArrayList<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select ns_code,ns_type_code,check_code_rule,extend from TM_NS_CFG");
            while (rs.next()) {
                NsCfgDto nsCfgDto = new NsCfgDto();
                String ns_code = rs.getString(1);
                String ns_type_code = rs.getString(2);
                String check_code_rule = rs.getString(3);
                String extend = rs.getString(4);

                nsCfgDto.setNsCode(ns_code);
                nsCfgDto.setNsTypeCode(ns_type_code);
                nsCfgDto.setCheckCodeRule(check_code_rule);
                nsCfgDto.setExtend(extend);
                nsCfgList.add(nsCfgDto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return nsCfgList;
    }

}
