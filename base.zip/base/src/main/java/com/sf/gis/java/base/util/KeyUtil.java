package com.sf.gis.java.base.util;

import org.apache.commons.lang3.StringUtils;

public class KeyUtil {

    private static final String EMPTY_KEY_AGENT_1 = "1";

    public static String keyLinkWithUnderline(String... agrs) {
        String key = "";
        if (agrs.length >= 1) {
            for (String agr : agrs) {
                key += agr + "_";
            }
            key = key.substring(0, key.length() - 1);
        }
        return key;
    }

    public static String[] keySplitWithUnderline(String agr) {
        if (StringUtils.isEmpty(agr)) {
            return null;
        } else {
            return agr.split("_");
        }
    }

    public static String keyLinkedWthUlRpEptKey(String... agrs) {
        String key = "";
        if (agrs.length >= 1) {
            for (String agr : agrs) {
                key += (StringUtils.isEmpty(agr) ? EMPTY_KEY_AGENT_1 : agr) + "_";
            }
            key = key.substring(0, key.length() - 1);
        }
        return key;
    }

    public static String[] keySplitWthUlRpEptKey(String agr) {
        if (StringUtils.isEmpty(agr)) {
            return null;
        } else {
            String[] rsArr = agr.split("_");
            for (int i = 0; i < rsArr.length; i++) {
                rsArr[i] = EMPTY_KEY_AGENT_1.equals(rsArr[i]) ? "" : rsArr[i];
            }
            return rsArr;
        }
    }

    public static void main(String[] args) {
        String key = keyLinkedWthUlRpEptKey("dfdfd", "", "eee", "", "ffff");
        System.out.println(key);
        System.out.println(keySplitWthUlRpEptKey(key));
    }
}
