package com.sf.gis.java.base.dto;

/**
 * At派入参
 */
public class AtdispatchApiIn {
    private String ak = "";  // 必填项
    private String opt = "";   // 非必填。识别策略-zh或缺省：综合识别策略，内部有一套识别算法。norm：标准库识别；normdetail：标准库识别带返回详细识别信息；chkn：审补库识别；phonenew：新电话库识别；dispatch：派件识别；tc2：tc2识别；schd：sch识别
    private String province = "";  // 非必填。省名称
    private String city = "";  // 必填。cityCode
    private String cityName = "";  // 非必填。城市名称
    private String district = "";  // 非必填。区名称
    private String address = "";  // 必填。地址
    private String tel = "";  // 非必填。座机
    private String mobile = "";  // 非必填。手机
    private String company = "";  // 非必填。公司名称

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    @Override
    public String toString() {
        return "AtdispatchApiIn{" +
                "ak='" + ak + '\'' +
                ", opt='" + opt + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", cityName='" + cityName + '\'' +
                ", district='" + district + '\'' +
                ", address='" + address + '\'' +
                ", tel='" + tel + '\'' +
                ", mobile='" + mobile + '\'' +
                ", company='" + company + '\'' +
                '}';
    }
}
