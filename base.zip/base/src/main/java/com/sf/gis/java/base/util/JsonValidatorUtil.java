package com.sf.gis.java.base.util;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

public class JsonValidatorUtil {
    private CharacterIterator it;
    private char c;
    private int col;

    public JsonValidatorUtil() {
    }

    /**
     * 验证一个字符串是否是合法的JSON串
     *
     * @param input 要验证的字符串
     * @return true-合法 ，false-非法
     */
    public boolean validate(String input) {
        input = input.trim();
        boolean ret = valid(input);
        return ret;
    }

    private boolean valid(String input) {
        if ("".equals(input)) return true;

        boolean ret = true;
        it = new StringCharacterIterator(input);
        c = it.first();
        col = 1;
        if (!value()) {
            ret = error("value", 1);
        } else {
            skipWhiteSpace();
            if (c != CharacterIterator.DONE) {
                ret = error("end", col);
            }
        }

        return ret;
    }

    private boolean value() {
        return literal("true") || literal("false") || literal("null") || string() || number() || object() || array();
    }

    private boolean literal(String text) {
        CharacterIterator ci = new StringCharacterIterator(text);
        char t = ci.first();
        if (c != t) return false;

        int start = col;
        boolean ret = true;
        for (t = ci.next(); t != CharacterIterator.DONE; t = ci.next()) {
            if (t != nextCharacter()) {
                ret = false;
                break;
            }
        }
        nextCharacter();
        if (!ret) error("literal " + text, start);
        return ret;
    }

    private boolean array() {
        return aggregate('[', ']', false);
    }

    private boolean object() {
        return aggregate('{', '}', true);
    }

    private boolean aggregate(char entryCharacter, char exitCharacter, boolean prefix) {
        if (c != entryCharacter) return false;
        nextCharacter();
        skipWhiteSpace();
        if (c == exitCharacter) {
            nextCharacter();
            return true;
        }

        for (; ; ) {
            if (prefix) {
                int start = col;
                if (!string()) return error("string", start);
                skipWhiteSpace();
                if (c != ':') return error("colon", col);
                nextCharacter();
                skipWhiteSpace();
            }
            if (value()) {
                skipWhiteSpace();
                if (c == ',') {
                    nextCharacter();
                } else if (c == exitCharacter) {
                    break;
                } else {
                    return error("comma or " + exitCharacter, col);
                }
            } else {
                return error("value", col);
            }
            skipWhiteSpace();
        }

        nextCharacter();
        return true;
    }

    private boolean number() {
        if (!Character.isDigit(c) && c != '-') return false;
        int start = col;
        if (c == '-') nextCharacter();
        if (c == '0') {
            nextCharacter();
        } else if (Character.isDigit(c)) {
            while (Character.isDigit(c))
                nextCharacter();
        } else {
            return error("number", start);
        }
        if (c == '.') {
            nextCharacter();
            if (Character.isDigit(c)) {
                while (Character.isDigit(c))
                    nextCharacter();
            } else {
                return error("number", start);
            }
        }
        if (c == 'e' || c == 'E') {
            nextCharacter();
            if (c == '+' || c == '-') {
                nextCharacter();
            }
            if (Character.isDigit(c)) {
                while (Character.isDigit(c))
                    nextCharacter();
            } else {
                return error("number", start);
            }
        }
        return true;
    }

    private boolean string() {
        if (c != '"') return false;

        int start = col;
        boolean escaped = false;
        for (nextCharacter(); c != CharacterIterator.DONE; nextCharacter()) {
            if (!escaped && c == '\\') {
                escaped = true;
            } else if (escaped) {
                if (!escape()) {
                    return false;
                }
                escaped = false;
            } else if (c == '"') {
                nextCharacter();
                return true;
            }
        }
        return error("quoted string", start);
    }

    private boolean escape() {
        int start = col - 1;
        if (" \\\"/bfnrtu".indexOf(c) < 0) {
            return error("escape sequence  \\\",\\\\,\\/,\\b,\\f,\\n,\\r,\\t  or  \\uxxxx ", start);
        }
        if (c == 'u') {
            if (!ishex(nextCharacter()) || !ishex(nextCharacter()) || !ishex(nextCharacter())
                    || !ishex(nextCharacter())) {
                return error("unicode escape sequence  \\uxxxx ", start);
            }
        }
        return true;
    }

    private boolean ishex(char d) {
        return "0123456789abcdefABCDEF".indexOf(c) >= 0;
    }

    private char nextCharacter() {
        c = it.next();
        ++col;
        return c;
    }

    private void skipWhiteSpace() {
        while (Character.isWhitespace(c)) {
            nextCharacter();
        }
    }

    private boolean error(String type, int col) {
//        System.out.printf("type: %s, col: %s%s", type, col, System.getProperty("line.separator"));
        return false;
    }

    public static void main(String[] args) {
        String jsonStr = "{\n" +
                "  \"status\": 0,\n" +
                "  \"result\": {\n" +
                "    \"match_level\": 9,\n" +
                "    \"type\": \"POI\",\n" +
                "    \"precision\": 2,\n" +
                "    \"xcoord\": 113.939344,\n" +
                "    \"ycoord\": 22.524545,\n" +
                "    \"adcode\": \"440305\",\n" +
                "    \"regcode\": \"755\",\n" +
                "    \"adname\": [\n" +
                "      \"广东省\",\n" +
                "      \"深圳市\",\n" +
                "      \"南山区\"\n" +
                "    ],\n" +
                "    \"src_address\": \"广东省深圳市南山区软件产业基地1A21楼\",\n" +
                "    \"src\": \"rh44\",\n" +
                "    \"cc\": \"1\",\n" +
                "    \"sn\": \"0077272023010519290945761107\",\n" +
                "    \"guid\": \"5CA12C92-512E-4FD2-9484-24BFE05C5DC6\",\n" +
                "    \"address2\": \"软件产业基地1a栋21楼\",\n" +
                "    \"query\": {\n" +
                "      \"adcode\": \"440300\",\n" +
                "      \"address\": \"广东省深圳市南山区软件产业基地1A21楼\"\n" +
                "    },\n" +
                "    \"other\": {\n" +
                "      \"name\": \"广东省深圳市南山区软件产业基地1a@21层\",\n" +
                "      \"adcode\": 440305,\n" +
                "      \"filter\": 2,\n" +
                "      \"level\": \"GL_POI\",\n" +
                "      \"score\": 1,\n" +
                "      \"sflag\": 0,\n" +
                "      \"dataSrc\": 21,\n" +
                "      \"key\": \"3|4\",\n" +
                "      \"id\": \"3533E4DFCDD911E7A485000C29E27523\",\n" +
                "      \"splitResult\": \"广东省^11,深圳市^12,南山区^13,软件产业基地^213,1a栋^214,21楼^216;16\",\n" +
                "      \"address\": \"软件产业基地1a\",\n" +
                "      \"group\": \"EC666EC2F49211E88368B4432652D5BE\",\n" +
                "      \"normalized\": \"广东省深圳市南山区软件产业基地1A栋21楼\",\n" +
                "      \"aoi\": \"053529ADB3F14AC09305B5E096884E14\",\n" +
                "      \"confidence\": 98,\n" +
                "      \"floor\": \"21\",\n" +
                "      \"fineAddress\": true,\n" +
                "      \"prov_city_dist\": \"广东省|深圳市|南山区\",\n" +
                "      \"mainid\": \"6834115\",\n" +
                "      \"match_address\": \"广东省深圳市南山区粤海街道学府路软件产业基地1A栋\",\n" +
                "      \"poi_typecode\": \"120100\",\n" +
                "      \"is_fine_address\": true,\n" +
                "      \"road_level\": 0\n" +
                "    },\n" +
                "    \"addSplitInfo\": [\n" +
                "      {\n" +
                "        \"match\": 1,\n" +
                "        \"prop\": 1,\n" +
                "        \"level\": 1,\n" +
                "        \"text\": \"广东省\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"match\": 1,\n" +
                "        \"prop\": 1,\n" +
                "        \"level\": 2,\n" +
                "        \"text\": \"深圳市\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"match\": 1,\n" +
                "        \"prop\": 1,\n" +
                "        level\": 3,\n" +
                "        \"text\": \"南山区\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"match\": 1,\n" +
                "        \"prop\": 2,\n" +
                "        \"level\": 13,\n" +
                "        \"text\": \"软件产业基地\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"match\": 1,\n" +
                "        \"prop\": 2,\n" +
                "        \"level\": 14,\n" +
                "        \"text\": \"1a栋\"\n" +
                "      },\n" +
                "      {\n" +
                "        \"match\": 0,\n" +
                "        \"prop\": 2,\n" +
                "        \"level\": 16,\n" +
                "        \"text\": \"21楼\"\n" +
                "      }\n" +
                "    ],\n" +
                "    \"matchInfo\": {\n" +
                "      \"src\": {\n" +
                "        \"in_level\": \"GL_BUILDING_FLOOR\",\n" +
                "        \"in_index\": 16,\n" +
                "        \"geo_type\": \"单元房间\",\n" +
                "        \"geo_level\": 11\n" +
                "      },\n" +
                "      \"match\": {\n" +
                "        \"in_level\": \"GL_POI\",\n" +
                "        \"in_index\": 13,\n" +
                "        \"geo_type\": \"POI\",\n" +
                "        \"geo_level\": 9\n" +
                "      },\n" +
                "      \"is_whole_match\": 0\n" +
                "    }\n" +
                "  }\n" +
                "}";
        System.out.println(new JsonValidatorUtil().validate(jsonStr));
    }
}
