package com.sf.gis.java.base.dto;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.StrUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-08-17 17:21
 * @TaskId:
 * @TaskName:
 * @Description: bdp任务记录新增实例的参数
 */
public class BdpTaskRecordAddParm implements Serializable {
    //任务id
    private String taskId;
    //任务名称
    private String taskName;
    //任务描述
    private String taskDescription="";
    //接口url
    //任务负责人
    private String taskOwner;
    //执行节点数
    private int taskExeInstance;
    //单节点core数量
    private int taskExeCores;
    //单节点内存
    private int taskExeMem;
    //单节点堆外内存
    private int taskExeOhMem;
    //任务开始时间
    private String taskStartTm;

    public BdpTaskRecordAddParm() {
    }

    public BdpTaskRecordAddParm(String taskId, String taskName, String taskDescription
           ) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.taskDescription = taskDescription;
        this.taskStartTm = DateUtil.formatDate(new Date(), "yyyyMMddHHmmss");
    }

    public void checkEmpty() {
        if (StrUtils.isBlank(taskId)) {
            System.out.println("***************请务必填写taskId************");
        }
        if (StrUtils.isBlank(taskName)) {
            System.out.println("***************请务必填写taskName************");
        }
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDescription() {
        return taskDescription;
    }

    public void setTaskDescription(String taskDescription) {
        this.taskDescription = taskDescription;
    }

    public String getTaskOwner() {
        return taskOwner;
    }

    public void setTaskOwner(String taskOwner) {
        this.taskOwner = taskOwner;
    }

    public int getTaskExeInstance() {
        return taskExeInstance;
    }

    public void setTaskExeInstance(int taskExeInstance) {
        this.taskExeInstance = taskExeInstance;
    }

    public int getTaskExeCores() {
        return taskExeCores;
    }

    public void setTaskExeCores(int taskExeCores) {
        this.taskExeCores = taskExeCores;
    }

    public int getTaskExeMem() {
        return taskExeMem;
    }

    public void setTaskExeMem(int taskExeMem) {
        this.taskExeMem = taskExeMem;
    }

    public int getTaskExeOhMem() {
        return taskExeOhMem;
    }

    public void setTaskExeOhMem(int taskExeOhMem) {
        this.taskExeOhMem = taskExeOhMem;
    }

    public String getTaskStartTm() {
        return taskStartTm;
    }

    public void setTaskStartTm(String taskStartTm) {
        this.taskStartTm = taskStartTm;
    }
}

