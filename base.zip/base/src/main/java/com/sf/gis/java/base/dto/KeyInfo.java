package com.sf.gis.java.base.dto;

/**
 * 主体相关信息
 * @author 01370539 created on Sep.1 2021
 */
public class KeyInfo {
    private String addr;   // 地址
    private String split;  // 通过地址获取的切词
    private String key;  // 通过切词获取的主体
    private String keyLevel;  // 通过切词获取的主体的级别

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getSplit() {
        return split;
    }

    public void setSplit(String split) {
        this.split = split;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getKeyLevel() {
        return keyLevel;
    }

    public void setKeyLevel(String keyLevel) {
        this.keyLevel = keyLevel;
    }

    @Override
    public String toString() {
        return "SplitInfo{" +
                "addr='" + addr + '\'' +
                ", split='" + split + '\'' +
                ", key='" + key + '\'' +
                ", keyLevel='" + keyLevel + '\'' +
                '}';
    }
}
