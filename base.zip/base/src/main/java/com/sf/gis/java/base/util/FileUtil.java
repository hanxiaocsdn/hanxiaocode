package com.sf.gis.java.base.util;

import com.sf.gis.java.base.constant.FixedConstant;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.activation.MimetypesFileTypeMap;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.*;

/**
 * sql处理工具类
 *
 * @author 01370539 Created On: May.07 2021
 */
public class FileUtil {
    private static final Logger logger = LoggerFactory.getLogger(com.sf.gis.java.base.util.FileUtil.class);

    /**
     * 从绝对路径下获取文件属性
     * @param configPath
     * @return
     */
    public static Properties getFilePropertiesAbs(String configPath) {
        Properties props = new Properties();
        try (InputStream in = FileUtil.class.getClassLoader().getResourceAsStream(configPath);
             InputStreamReader isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
             BufferedReader bf = new BufferedReader(isr);
        ) {
            props.load(bf);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return props;
    }
    public static Properties getFileProperties(String configPath) {
        Properties props = new Properties();
        try (InputStream in = FileUtil.class.getClassLoader().getResourceAsStream(configPath);
             InputStreamReader isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
             BufferedReader bf = new BufferedReader(isr);
        ) {
            props.load(bf);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return props;
    }

    public static String getQuerySql(String fileName) throws IOException {
        //文件后缀为txt,sql等不能被识别
        return IOUtils.toString(FileUtil.class.getClassLoader().getResourceAsStream(fileName));
    }
}

