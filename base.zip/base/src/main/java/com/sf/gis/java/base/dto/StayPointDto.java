package com.sf.gis.java.base.dto;

import java.io.Serializable;
import java.util.List;

public class StayPointDto implements Serializable {
    private String id;   // 滞留点ID
    private double dis;   // 按照滞留点集合时间序列排序，首尾点之间的距离
    private int pCnt;   // 滞留点集合中的点数量
    private long spTm;    // 按照滞留点集合时间序列排序，首尾点之间的时间
    private double centerLng;     // 滞留点集合的中心点经度
    private double centerLat;     // 滞留点集合的中心点纬度
    private double dis2sp;   // 与起始点的距离
    private List<PointDto> pList;     // 滞留点集合

    public StayPointDto(){
    }

    public StayPointDto(String id, double dis, int spSize, long spTm, double spCenterLng, double spCenterLat, double dis2sp, List<PointDto> pList) {
        this.id = id;
        this.dis = dis;
        this.pCnt = spSize;
        this.spTm = spTm;
        this.centerLng = spCenterLng;
        this.centerLat = spCenterLat;
        this.dis2sp = dis2sp;
        this.pList = pList;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getDis() {
        return dis;
    }

    public void setDis(double dis) {
        this.dis = dis;
    }

    public int getpCnt() {
        return pCnt;
    }

    public void setpCnt(int pCnt) {
        this.pCnt = pCnt;
    }

    public long getSpTm() {
        return spTm;
    }

    public void setSpTm(long spTm) {
        this.spTm = spTm;
    }

    public double getCenterLng() {
        return centerLng;
    }

    public void setCenterLng(double centerLng) {
        this.centerLng = centerLng;
    }

    public double getCenterLat() {
        return centerLat;
    }

    public void setCenterLat(double centerLat) {
        this.centerLat = centerLat;
    }

    public double getDis2sp() {
        return dis2sp;
    }

    public void setDis2sp(double dis2sp) {
        this.dis2sp = dis2sp;
    }

    public List<PointDto> getpList() {
        return pList;
    }

    public void setpList(List<PointDto> pList) {
        this.pList = pList;
    }

    @Override
    public String toString() {
        return "StayPoint{" +
                "spId='" + id + '\'' +
                ", dis=" + dis +
                ", spSize='" + pCnt + '\'' +
                ", spTm='" + spTm + '\'' +
                ", spCenterLng='" + centerLng + '\'' +
                ", spCenterLat='" + centerLat + '\'' +
                ", pList=" + pList +
                ", dis2sp=" + dis2sp +
                '}';
    }
}
