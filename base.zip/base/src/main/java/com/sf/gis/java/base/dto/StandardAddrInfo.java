package com.sf.gis.java.base.dto;

import java.io.Serializable;

/**
 * Created by 01417629 on 2021-11-11
 */
public class StandardAddrInfo implements Serializable {
    private String addr;   // 地址
    private String cityCode;  // 通过地址获取的切词
    private String standardAddr;  // 通过切词获取的主体
    private String result;  // 通过切词获取的主体的级别

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getStandardAddr() {
        return standardAddr;
    }

    public void setStandardAddr(String standardAddr) {
        this.standardAddr = standardAddr;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "SplitInfo{" +
                "addr='" + addr + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", standardAddr='" + standardAddr + '\'' +
                ", result='" + result + '\'' +
                '}';
    }
}
