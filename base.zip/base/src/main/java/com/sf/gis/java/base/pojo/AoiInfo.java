package com.sf.gis.java.base.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 网点相关信息
 * @author 01370539 created on Jan.29 2024
 */
@Table
public class AoiInfo implements Serializable {
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_code")
    private String aoiCode;
    @Column(name = "aoi_name")
    private String aoiName;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "zno_code")
    private String znoCode;
    @Column(name = "fa_type")
    private String faType;
    @Column(name = "other_name")
    private String otherName;
    @Column(name = "road_name")
    private String 	roadName;
    @Column(name = "road_number")
    private String roadNumber;
    @Column(name = "geom_area")
    private String geomArea;

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiName() {
        return aoiName;
    }

    public void setAoiName(String aoiName) {
        this.aoiName = aoiName;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getZnoCode() {
        return znoCode;
    }

    public void setZnoCode(String znoCode) {
        this.znoCode = znoCode;
    }

    public String getFaType() {
        return faType;
    }

    public void setFaType(String faType) {
        this.faType = faType;
    }

    public String getOtherName() {
        return otherName;
    }

    public void setOtherName(String otherName) {
        this.otherName = otherName;
    }

    public String getRoadName() {
        return roadName;
    }

    public void setRoadName(String roadName) {
        this.roadName = roadName;
    }

    public String getRoadNumber() {
        return roadNumber;
    }

    public void setRoadNumber(String roadNumber) {
        this.roadNumber = roadNumber;
    }

    public String getGeomArea() {
        return geomArea;
    }

    public void setGeomArea(String geomArea) {
        this.geomArea = geomArea;
    }

    @Override
    public String toString() {
        return "AoiInfo{" +
                "aoiId='" + aoiId + '\'' +
                ", aoiCode='" + aoiCode + '\'' +
                ", aoiName='" + aoiName + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", znoCode='" + znoCode + '\'' +
                ", faType='" + faType + '\'' +
                ", otherName='" + otherName + '\'' +
                ", roadName='" + roadName + '\'' +
                ", roadNumber='" + roadNumber + '\'' +
                ", geomArea='" + geomArea + '\'' +
                '}';
    }
}
