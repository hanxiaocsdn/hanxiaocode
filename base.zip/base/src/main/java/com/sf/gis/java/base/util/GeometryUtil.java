package com.sf.gis.java.base.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.davidmoten.geo.GeoHash;
import com.github.davidmoten.geo.LatLong;
import com.google.common.collect.Sets;
import com.sf.gis.java.base.constant.FixedConstant;
import com.vividsolutions.jts.geom.*;
import jdk.nashorn.internal.parser.JSONParser;
import org.apache.commons.compress.utils.Lists;
import org.apache.commons.lang.StringUtils;
import org.geotools.factory.CommonFactoryFinder;
import org.geotools.geometry.jts.JTSFactoryFinder;
import org.geotools.referencing.GeodeticCalculator;
import org.opengis.filter.Filter;
import org.opengis.filter.FilterFactory2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.vividsolutions.jts.io.ParseException;
import com.vividsolutions.jts.io.WKTReader;

import java.awt.geom.Point2D;
import java.io.FileReader;
import java.util.*;

public class GeometryUtil {

	private static final Logger logger = LoggerFactory.getLogger(GeometryUtil.class);

	private static final GeometryFactory geometryFactory = JTSFactoryFinder.getGeometryFactory(null);

    public final static Double SLICE_UP_RATIO = 0.005;
    public final static Double SLICE_UP_SCH_RATIO = 0.025;
    public final static Double SLICE_UP_ZNO_RATIO = 0.05;

    public final static Double SLICE_UP_100_RATIO = 0.001;
    public final static Double SLICE_UP_50_RATIO = 0.0005;

    public final static Double SLICE_TRACK_RATIO = 0.01;

	/**
	 * create a point
	 * 
	 * @param x:109.013388
	 * @param y:32.715519
	 * @return Point
	 */
	public static Point createPoint(double x, double y) {
		Coordinate coord = new Coordinate(x, y);
		return geometryFactory.createPoint(coord);
	}

	public static Point createPoint(String x, String y) {
		if (StringUtils.isEmpty(x) || StringUtils.isEmpty(y)) {
			return null;
		}
		return createPoint(Double.parseDouble(x), Double.parseDouble(y));
	}

	/**
	 * create a point by WKT
	 * 
	 * @param param:"POINT (109.013388 32.715519)"
	 * @return Point
	 * @throws ParseException ParseException
	 */
	public static Point createPointByWKT(String param) throws ParseException {
		WKTReader reader = new WKTReader(geometryFactory);
		return (Point) reader.read(param);
	}

	/**
	 * create multiPoint by wkt
	 * 
	 * @param param:"MULTIPOINT(109.013388 32.715519,119.32488 31.435678)"
	 * @return MultiPoint
	 */
	public static MultiPoint createMulPointByWKT(String param) throws ParseException {
		WKTReader reader = new WKTReader(geometryFactory);
		return (MultiPoint) reader.read(param);
	}

	/**
	 * 
	 * create a line
	 * 
	 * @return LineString
	 */
	public static LineString createLine() {
		Coordinate[] coords = new Coordinate[] { new Coordinate(2, 2), new Coordinate(2, 2) };
		return geometryFactory.createLineString(coords);
	}

	/**
	 * create a line by WKT
	 * 
	 * @param param:"LINESTRING(0 0, 2 0)"
	 * @return LineString
	 * @throws ParseException ParseException
	 */
	public static LineString createLineByWKT(String param) throws ParseException {
		WKTReader reader = new WKTReader(geometryFactory);
        return (LineString) reader.read(param);
	}

	/**
	 * create multiLine
	 * 
	 * @return MultiLineString
	 */
	public static MultiLineString createMLine() {
		Coordinate[] coords1 = new Coordinate[] { new Coordinate(2, 2), new Coordinate(2, 2) };
		LineString line1 = geometryFactory.createLineString(coords1);
		Coordinate[] coords2 = new Coordinate[] { new Coordinate(2, 2), new Coordinate(2, 2) };
		LineString line2 = geometryFactory.createLineString(coords2);
		LineString[] lineStrings = new LineString[2];
		lineStrings[0] = line1;
		lineStrings[1] = line2;
        return geometryFactory.createMultiLineString(lineStrings);
	}

	/**
	 * create multiLine by WKT
	 * 
	 * @param param:"MULTILINESTRING((0 0, 2 0),(1 1,2 2))"
	 * @return MultiLineString
	 * @throws ParseException ParseException
	 */
	public static MultiLineString createMLineByWKT(String param) throws ParseException {
		WKTReader reader = new WKTReader(geometryFactory);
		return (MultiLineString) reader.read(param);
	}

	/**
	 * create a polygon(多边形) by WKT
	 * 
	 * @param param:"POLYGON((20 10, 30 0, 40 10, 30 20, 20 10))"
	 * @return Polygon
	 * @throws ParseException ParseException
	 */
	public static Polygon createPolygonByWKT(String param) throws ParseException {
		WKTReader reader = new WKTReader(geometryFactory);
        return (Polygon) reader.read(param);
	}

	/**
	 * create multi polygon by wkt
	 * 
	 * @param param:"MULTIPOLYGON(((40 10, 30 0, 40 10, 30 20, 40 10),(30 10, 30 0, 40 10, 30 20, 30 10)))"
	 * @return MultiPolygon
	 * @throws ParseException ParseException
	 */
	public static MultiPolygon createMulPolygonByWKT(String param) throws ParseException {
		WKTReader reader = new WKTReader(geometryFactory);
        return (MultiPolygon) reader.read(param);
	}

	/**
	 * create GeometryCollection contain point or multiPoint or line or multiLine or polygon or multiPolygon
	 * 
	 * @return GeometryCollection
	 * @throws ParseException ParseException
	 */
	public static GeometryCollection createGeoCollect(String param) throws ParseException {
		LineString line = createLine();
		Polygon poly = createPolygonByWKT(param);
		Polygon poly1 = createPolygonByWKT(param);
		String key = GeoHash.encodeHash(1,1,1);
		List<String> keys = GeoHash.neighbours(key);

		Geometry g1 = geometryFactory.createGeometry(line);
		Geometry g2 = geometryFactory.createGeometry(poly);
		Geometry[] garray = new Geometry[] { g1, g2 };
        return geometryFactory.createGeometryCollection(garray);
	}

	/**
	 * create a Circle 创建一个圆，圆心(x,y) 半径RADIUS
	 * 
	 * @param x 经度
	 * @param y 维度
	 * @param RADIUS 半径
	 * @return Polygon
	 */
	public static Polygon createCircle(double x, double y, final double RADIUS) {
		final int SIDES = 32;// 圆上面的点个数
		Coordinate[] coords = new Coordinate[SIDES + 1];
		for (int i = 0; i < SIDES; i++) {
			double angle = ((double) i / (double) SIDES) * Math.PI * 2.0;
			double dx = Math.cos(angle) * RADIUS;
			double dy = Math.sin(angle) * RADIUS;
			coords[i] = new Coordinate(x + dx, y + dy);
		}
		coords[SIDES] = coords[0];
		LinearRing ring = geometryFactory.createLinearRing(coords);
        return geometryFactory.createPolygon(ring, null);
	}

    public static String getPolygonStrByLatLong(List<LatLong> points) {
        if (points.isEmpty()) {
            return null;
        }
        String rs = "";
        for (LatLong point : points) {
            rs += point.getLon() + " " + point.getLat() + ",";
        }
        rs += points.get(0).getLon() + " " + points.get(0).getLat() + ",";
        rs = "POLYGON((" + rs.substring(0, rs.lastIndexOf(",")) + "))";
        return rs;
    }

    public static String getPolygonStrByPoints(List<Point> points) {
        if (points.isEmpty()) {
            return null;
        }
        String rs = "";
        for (Point point : points) {
            rs += point.getX() + " " + point.getY() + ",";
        }
        rs += points.get(0).getX() + " " + points.get(0).getY() + ",";
        rs = "POLYGON((" + rs.substring(0, rs.lastIndexOf(",")) + "))";
        return rs;
    }

	public static Filter getFilter(Geometry g) {
		FilterFactory2 ff = CommonFactoryFinder.getFilterFactory2(null);
        return ff.intersects(ff.property("the_geom"), ff.literal(g));
	}

	public static double getDegree(double meter) {
		return meter / (2 * Math.PI * 6371004) * 360;
	}

	public static double getMeter(double degree) {
		return degree * (2 * Math.PI * 6371004) / 360;
	}

	public static double getDistance(Point p1, Point p2) {
	    return getMeter(p1.distance(p2));
    }

    public static double getDistance(String x1, String y1, String x2, String y2) {
        return getMeter(createPoint(x1, y1).distance(createPoint(x2, y2)));
    }
    
    public static double getDistance(double x1, double y1, double x2, double y2) {
        return getMeter(createPoint(x1, y1).distance(createPoint(x2, y2)));
    }

    public static double getDistance(Point p1, Polygon p2) {
        return getMeter(p1.distance(p2));
    }

    public static double getDistance(Point p1, LineString line) {
        return getMeter(p1.distance(line));
    }

    public static double getDistance(Polygon p1, LineString line) {
        return getMeter(p1.distance(line));
    }

    public static double getDistance(List<LatLong> llList, LatLong ll) throws ParseException {
	    if (llList.size() == 1) {
            return getMeter(createPoint(llList.get(0).getLon(), llList.get(0).getLat()).distance(createPoint(ll.getLon(), ll.getLat())));
        } else {
            return getMeter(createLineByWKT(getLineStr(llList)).distance(createPoint(ll.getLon(), ll.getLat())));
        }
    }

    public static double getDistance(List<LatLong> llList1, List<LatLong> llList2) throws ParseException {
        if (llList1.size() == 1 && llList2.size() == 1) {
            return getMeter(createPoint(llList1.get(0).getLon(), llList1.get(0).getLat()).distance(createPoint(llList2.get(0).getLon(), llList2.get(0).getLat())));
        } else if (llList1.size() > 1 && llList2.size() == 1) {
            return getDistance(llList1, llList2.get(0));
        } else if (llList1.size() == 1 && llList2.size() > 1) {
            return getDistance(llList2, llList1.get(0));
        } else {
            return getMeter(createLineByWKT(getLineStr(llList1)).distance(createLineByWKT(getLineStr(llList2))));
        }
    }
    // 计算点到线段的最短距离
    public static double pointToLineStringDistance(Point point, LineString lineString) {
        GeometryFactory geometryFactory = new GeometryFactory();
        Coordinate[] coordinates = lineString.getCoordinates();

        double minDistance = Double.POSITIVE_INFINITY;

        for (int i = 0; i < coordinates.length - 1; i++) {
            Point startPoint = geometryFactory.createPoint(coordinates[i]);
            Point endPoint = geometryFactory.createPoint(coordinates[i + 1]);

            LineSegment lineSegment = new LineSegment(startPoint.getCoordinate(), endPoint.getCoordinate());

            double distance = lineSegment.distance(point.getCoordinate());
            minDistance = Math.min(minDistance, distance);
        }

        return minDistance;
    }

    public static String getLineStr(List<LatLong> llList) {
        StringBuffer lineSb = new StringBuffer("LINESTRING(");
        llList.forEach(temp -> lineSb.append(temp.getLon()).append(" ").append(temp.getLat()).append(", "));
        return lineSb.substring(0, lineSb.length() - 2) + ")";
    }

    public static String getLineStrFromPointList(List<Point> llList) {
        StringBuffer lineSb = new StringBuffer("LINESTRING(");
        llList.forEach(temp -> lineSb.append(temp.getX()).append(" ").append(temp.getY()).append(", "));
        return lineSb.substring(0, lineSb.length() - 2) + ")";
    }

    public static String getPointStr(Point point) {
        return new StringBuffer("POINT(").append(point.getX()).append(" ").append(point.getY()).append(")").toString();

    }

	public static LatLong getCenter(LinkedList<LatLong> llList) {
        int total = llList.size();
        double X = 0, Y = 0, Z = 0;

        LatLong ll;
        while(!llList.isEmpty()) {
            ll = llList.pollFirst();
            if(ll != null) {
                double lat, lon, x, y, z;
                lat = ll.getLat() * Math.PI / 180;
                lon = ll.getLon() * Math.PI / 180;
                x = Math.cos(lat) * Math.cos(lon);
                y = Math.cos(lat) * Math.sin(lon);
                z = Math.sin(lat);
                X += x;
                Y += y;
                Z += z;
            }
        }


        X = X / total;
        Y = Y / total;
        Z = Z / total;
        double Lon = Math.atan2(Y, X);
        double Hyp = Math.sqrt(X * X + Y * Y);
        double Lat = Math.atan2(Z, Hyp);
        double longitude = Lon * 180 / Math.PI;
        double latitude = Lat * 180 / Math.PI;
        return new LatLong(latitude, longitude);
    }

    public static List<String> coorAreaSlice(double x, double y,double ratio){
        String slice = sliceUpCoordinate(x, y,ratio);
        String[] split = slice.split("-");
        Integer row = Integer.valueOf(split[0]);
        Integer column = Integer.valueOf(split[1]);

        List<String> slices = Lists.newArrayList();
        slices.add(row - 1 +"-"+ column);
        slices.add(slice);
        slices.add(row + 1 +"-"+ column);

        slices.add(row - 1 +"-"+ (column+1));
        slices.add(row +"-"+ (column+1));
        slices.add(row+1 +"-"+ (column+1));

        slices.add(row - 1 +"-"+ (column-1));
        slices.add(row +"-"+ (column-1));
        slices.add(row+1 +"-"+ (column-1));
        return slices;
    }

    public static List<String> coorAreaSlice(String slice){
        String[] split = slice.split("-");
        Integer row = Integer.valueOf(split[0]);
        Integer column = Integer.valueOf(split[1]);

        List<String> slices = Lists.newArrayList();
        slices.add(row - 1 +"-"+ column);
        slices.add(slice);
        slices.add(row + 1 +"-"+ column);

        slices.add(row - 1 +"-"+ (column+1));
        slices.add(row +"-"+ (column+1));
        slices.add(row+1 +"-"+ (column+1));

        slices.add(row - 1 +"-"+ (column-1));
        slices.add(row +"-"+ (column-1));
        slices.add(row+1 +"-"+ (column-1));
        return slices;
    }

    public static Set<String> sliceUpMultiByWkt(String geomWkt) throws Exception {
        return sliceUpMultiByWkt(geomWkt, SLICE_UP_RATIO);
    }

    public static Set<String> sliceUpMultiByWkt(MultiPolygon geomWkt) throws Exception {
        return sliceUpMultiByWkt(geomWkt, SLICE_UP_RATIO);
    }

    public static Set<String> sliceUpMultiByWkt(String geomWkt, Double ratio) throws Exception {
        return sliceUp(createMulPolygonByWKT(geomWkt).getCoordinates(), ratio);
    }

    public static Set<String> sliceUpMultiByWkt(MultiPolygon geomWkt, Double ratio) throws Exception {
        return sliceUp(geomWkt.getCoordinates(), ratio);
    }

    /**
     * 计算面的瓦片编号(按默认瓦片大小500M*500M)
     * @param geomWkt 面的空间数据（wkt格式）
     * @return 瓦片编号（可能为多个）
     * @throws Exception
     */
    public static Set<String> sliceUpByWkt(String geomWkt) throws Exception {
        return sliceUpByWkt(geomWkt, SLICE_UP_RATIO);
    }

    /**
     * 计算面的瓦片编号
     * @param geomWkt 面的空间数据（wkt格式）
     * @param ratio 瓦片大小
     * @return瓦片编号（可能为多个）
     * @throws Exception
     */
    public static Set<String> sliceUpByWkt(String geomWkt, Double ratio) throws Exception {
        return sliceUp(createPolygonByWKT(geomWkt).getCoordinates(), ratio);
    }

    private static Set<String> sliceUp(Coordinate[] coordinates){
        return sliceUp(coordinates, SLICE_UP_RATIO);
    }

    public static Set<String> sliceUp(Coordinate[] coordinates,Double ratio){
        Set<String> slice_str = Sets.newHashSet();
        double minX = 1E9;
        double maxX = -1;
        double minY = 1E9;
        double maxY = -1;

        int minRow;
        int maxRow;
        int minColumn;
        int maxColumn;

        for (Coordinate coordinate : coordinates) {
            double x = coordinate.x + 180;
            double y = coordinate.y + 90;
            if (x > maxX) {
                maxX = x;
            }

            if (x < minX) {
                minX = x;
            }

            if (y > maxY) {
                maxY = y;
            }

            if (y < minY) {
                minY = y;
            }
        }

        if (maxX > -1 && maxY > -1 && minX < 1E9 && minY < 1E9) {
            minRow = (int) (minX / ratio);
            maxRow = (int) (maxX / ratio);
            minColumn = (int) (minY / ratio);
            maxColumn = (int) (maxY / ratio);

            if (minX % ratio != 0.0) {
                minRow += 1;
            } else if (minRow % 2 == 1) {
                minRow += 1;
            }

            if (maxX % ratio != 0.0) {
                maxRow += 1;
            } else if (maxRow % 2 == 1) {
                maxRow += 1;
            }

            if (minY % ratio != 0.0) {
                minColumn += 1;
            } else if (minColumn % 2 == 1) {
                minColumn += 1;
            }

            if (maxY % ratio != 0.0) {
                maxColumn += 1;
            } else if (maxColumn % 2 == 1) {
                maxColumn += 1;
            }

            for (int i = minRow; i <= maxRow; i++) {
                for (int j = minColumn; j <= maxColumn; j++) {
                    slice_str.add(i + "-" + j);
                }
            }
        }
        return slice_str;
    }

    public static String sliceUpCoordinate(Coordinate coordinate) {
        return sliceUpCoordinate(coordinate.x, coordinate.y);
    }

    public static String sliceUpCoordinate(String x, String y) {
        return sliceUpCoordinate(Double.parseDouble(x), Double.parseDouble(y));
    }

    /**
     * 计算点的瓦片编号
     * @param x
     * @param y
     * @return
     */
    public static String sliceUpCoordinate(double x, double y) {
        Double ratio = 0.005;

        int minRow;
        int minColumn;

        x = x + 180;
        y = y + 90;

        minRow = (int) (x / ratio);
        minColumn = (int) (y / ratio);

        if (x % ratio != 0.0) {
            minRow += 1;
        } else if (minRow % 2 == 1) {
            minRow += 1;
        }

        if (y % ratio != 0.0) {
            minColumn += 1;
        } else if (minColumn % 2 == 1) {
            minColumn += 1;
        }

        return minRow + "-" + minColumn;
    }

    public static String sliceUpCoordinate(String x, String y,double ratio) {
        return sliceUpCoordinate(Double.parseDouble(x), Double.parseDouble(y), ratio);
    }

    /**
     * 计算点的瓦片编号
     * @param x
     * @param y
     * @return
     */
    public static String sliceUpCoordinate(double x, double y,double ratio) {
        int minRow;
        int minColumn;

        x = x + 180;
        y = y + 90;

        minRow = (int) (x / ratio);
        minColumn = (int) (y / ratio);

        if (x % ratio != 0.0) {
            minRow += 1;
        } else if (minRow % 2 == 1) {
            minRow += 1;
        }

        if (y % ratio != 0.0) {
            minColumn += 1;
        } else if (minColumn % 2 == 1) {
            minColumn += 1;
        }

        return minRow + "-" + minColumn;
    }


    /**
     * 重叠面积比例 > score 校验
     *
     * @param baseWkt
     *            基准面wkt
     * @param targetWkt
     *            对比面wkt
     * @param score
     *            阈值，如： 5% 传 score = 5
     * @return
     */
    public static boolean isOverlay(String baseWkt, String targetWkt, Integer score,Integer schScore) {
        //相交面积和aoi面积比例 默认为10%重叠
        if (Objects.isNull(score)) {
            score = 10;
        }
        //相交面积和单元区域面积比例 默认为10%重叠
        if (Objects.isNull(schScore)) {
            schScore = 10;
        }

        WKTReader wktReader = new WKTReader();
        Geometry baseGeo = null;
        Geometry targetGeo = null;
        try {
            baseGeo = wktReader.read(baseWkt);
            targetGeo = wktReader.read(targetWkt);
            if (!Objects.isNull(baseGeo) && !Objects.isNull(targetGeo) && !baseGeo.isEmpty() && !targetGeo.isEmpty()) {
                Geometry intersectGeo = baseGeo.intersection(targetGeo);
                if (!Objects.isNull(intersectGeo) && !intersectGeo.isEmpty()) {
                    double baseArea = baseGeo.getArea();
                    double intersectArea = intersectGeo.getArea();
                    double targetArea = targetGeo.getArea();
                    Integer intersetScore = new Double((intersectArea / baseArea * 100)).intValue();
                    Integer intersetSchScore = new Double((intersectArea/targetArea * 100)).intValue();
                    if (intersetSchScore>=schScore || intersetScore >= score) {
                        return true;
                    }
                }
            }
        } catch (ParseException e) {
            logger.error("wkt isOverlay error: {}", e);
        }
        return false;
    }
    //通过传入点集合，返回多边形
    public static Polygon getNormalExtend(List<String> coords) {
        try {
            ArrayList<Coordinate> coordinateList = new ArrayList<>();
            for (int i = 0; i < coords.size(); i++) {
                String corrd = (String)coords.get(i);
                String[] split = corrd.split(",");
                double minX = (Double.parseDouble(split[0]));
                double minY = (Double.parseDouble(split[1]));
                Coordinate coordinate = new Coordinate(minX, minY);
                coordinateList.add(coordinate);
            }
            Coordinate[] coordinates = coordinateList.toArray(new Coordinate[coordinateList.size()]);
        /*for (String corrd:coords){
            String[] split = corrd.split(",");
            double minX = Double.parseDouble(split[0]);
            double minY = Double.parseDouble(split[1]);
            coordinates
            coordinates = new Coordinate[]{new Coordinate(minX, minY)};
        }*/
            return geometryFactory.createPolygon(coordinates);
        }catch (Exception e){
            e.printStackTrace();
            System.out.println(e);
            return null;
        }

    }
    //计算点在曲线的右侧还是左侧
    public static boolean isPointOnLeft(LineString line, Point point) {
        int crossings = 0;
        Coordinate p = point.getCoordinate();

        for (int i = 0; i < line.getNumPoints() - 1; i++) {
            Coordinate p1 = line.getCoordinateN(i);
            Coordinate p2 = line.getCoordinateN(i + 1);

            // 检查射线与线段的交点情况
            if ((p1.y <= p.y && p.y < p2.y || p2.y <= p.y && p.y < p1.y) &&
                    p.x < p1.x + (p.y - p1.y) / (p2.y - p1.y) * (p2.x - p1.x)) {
                crossings++;
            }
        }
        // 若交点个数为奇数，则点在左侧（内部），否则在右侧（外部）
        return crossings % 2 != 0;
    }
    //通过传入点集合，返回多边形
    public static Polygon getNormalOherExtend(List<String> coords) {
        try {
            ArrayList<Coordinate> coordinateList = new ArrayList<>();
            for (int i = 0; i < coords.size(); i++) {
                String corrd = (String)coords.get(i);
                String[] split = corrd.split(",");
                double minX = (Double.parseDouble(split[0]))/3600;
                double minY = (Double.parseDouble(split[1]))/3600;
                Coordinate coordinate = new Coordinate(minX, minY);
                coordinateList.add(coordinate);
            }
            Coordinate[] coordinates = coordinateList.toArray(new Coordinate[coordinateList.size()]);
        /*for (String corrd:coords){
            String[] split = corrd.split(",");
            double minX = Double.parseDouble(split[0]);
            double minY = Double.parseDouble(split[1]);
            coordinates
            coordinates = new Coordinate[]{new Coordinate(minX, minY)};
        }*/
            return geometryFactory.createPolygon(coordinates);
        }catch (Exception e){
            e.printStackTrace();
            System.out.println(e);
            return null;
        }

    }
    public static WKTReader getWktReader() {
        WKTReader wktReader = new WKTReader(geometryFactory);
        return wktReader;
    }
    public static Geometry fromWkt(String wkt) {
        WKTReader reader = getWktReader();

        try {
            return reader.read(wkt);
        } catch (Exception var3) {
            return null;
        }
    }

    /**
     * 散点形成凸包
     * @param points
     * @return
     */
    public static List<Point> convexHull(List<Point> points) {
        List<Point> shellPoint = new LinkedList<>();
        Point minPoint = null;
        double nowBearing;
        double nextBearing;
        double preBearing;
        double nextLength;
        Point nowPoint;
        Point nextPoint = null;
        if (!points.isEmpty()) {
            // 元素小于3个时，必是凸包直接返回
            if (points.size() <= 3) {
                shellPoint.addAll(points);
                return shellPoint;
            }

            // 求最左下元素
            for (Point point : points) {
                if (minPoint == null) {
                    minPoint = point;
                    continue;
                }
                if (minPoint.getX() > point.getX())
                    minPoint = point;
                else if (minPoint.getX() == point.getX()) {
                    if (point.getY() < minPoint.getY())
                        minPoint = point;
                }
            }
            shellPoint.add(minPoint); // 最左下元素定时凸包元素，加入集合
            nowPoint = minPoint;
            preBearing = 0; // 之前凸包元素指向最近凸包元素的角度（相对与y轴顺时针）
            while (true) {
                nextBearing = 360;
                nextLength = Double.MAX_VALUE;
//                logger.error("点集合大小:"+points.size());
//                logger.error("点集合:"+points);
                for (Point point : points) {
                    if (point.equals(nowPoint))
                        continue;
                    nowBearing = calculateBearingToPoint(preBearing, nowPoint, point);

                    if (nextBearing == nowBearing) {
                        if (nextLength < (Math.pow(point.getX() - nowPoint.getX(), 2) + Math.pow(point.getY() - nowPoint.getY(), 2))) {
                            nextLength = Math.pow(point.getX() - nowPoint.getX(), 2) + Math.pow(point.getY() - nowPoint.getY(), 2);
                            nextPoint = point;
                        }
                    } else if (nextBearing > nowBearing) {
                        nextLength = Math.pow(point.getX() - nowPoint.getX(), 2) + Math.pow(point.getY() - nowPoint.getY(), 2);
                        nextBearing = nowBearing;
                        nextPoint = point;
                    }
                }
//                logger.error("minPoint为:"+minPoint+",nextPoint为:"+nextPoint+",点集合为:"+points);
                if (nextPoint == null || minPoint.equals(nextPoint)) {
                    logger.error("跳出循环");
                    break;
                }

                nowPoint = nextPoint;
                preBearing += nextBearing;
                if(preBearing>360){
                    break;
                }
                System.out.println(minPoint+","+nextPoint+","+preBearing);
                shellPoint.add(nextPoint);
            }

        }
        return shellPoint;
    }

    private static double calculateBearingToPoint(double currentBearing, Point curPoint, Point nxtPoint) {
        double angle;
        double x = nxtPoint.getX() - curPoint.getX();
        double y = nxtPoint.getY() - curPoint.getY();
        angle = Math.atan2(x, y) * 180.0 / Math.PI - currentBearing;
        return angle < 0 ? angle + 360 : angle;
    }

    public static Geometry getCoorPolygon(List<Point> points) {
        if (points != null && !points.isEmpty()) {
            Point[] pointArr = new Point[points.size()];

            for(int i = 0; i < points.size(); ++i) {
                pointArr[i] = (Point)points.get(i);
            }

            MultiPoint multiPoint = new MultiPoint(pointArr, new GeometryFactory());
            return multiPoint.convexHull();
        } else {
            return null;
        }
    }
    public static Double meterToDeg(double meter) {
        return meter * 8.983152841195214E-6D;
    }

    public static double calAngle(double x1, double y1, double x2, double y2) {
        double x = Math.abs(x1 - x2);
        double y = Math.abs(y1 - y2);
        double z = Math.sqrt(x * x + y * y);
        double angle = Math.asin(y / z) / Math.PI * 180;

        if (x1 > x2) {
            angle = 180 - angle;
        }

        if (y1 > y2) {
            angle = -angle;
        }

        if (angle < 0) {
            angle += 360;
        }

        return angle;
    }

    /**
     * 计算点相较于线的位置（在线的哪边）
     * @param lineStartX
     * @param lineStartY
     * @param lineEndX
     * @param lineEndY
     * @param pointX
     * @param pointY
     * @return
     */
    public static String calDir(double lineStartX, double lineStartY, double lineEndX, double lineEndY, double pointX, double pointY) {
        double lineDegree = calAngle(lineStartX, lineStartY, lineEndX, lineEndY);
        double pointDegree = calAngle(lineStartX, lineStartY, pointX, pointY);
        return dir(lineDegree, pointDegree);
    }

    public static String calDir(Point lineStart, Point lineEnd, Point chkPoint) {
        double lineDegree = calAngle(lineStart.getX(), lineStart.getY(), lineStart.getX(), lineStart.getY());
        double pointDegree = calAngle(lineStart.getX(), lineStart.getY(), chkPoint.getX(), chkPoint.getY());
        return dir(lineDegree, pointDegree);
    }

    private static String dir(double rs1, double rs2) {
        double rs = rs2 - rs1;
        if (rs == 0 || rs == 180 || rs == -180) {
            return FixedConstant.DIR_LINE;
        } else {
            if (rs1 >= 0 && rs1 <= 180) {
                if (rs > 0 && rs < 180) {
                    return FixedConstant.DIR_LEFT;
                } else {
                    return FixedConstant.DIR_RIGHT;
                }
            } else {
                if (rs > -180 && rs < 0) {
                    return FixedConstant.DIR_RIGHT;
                } else {
                    return FixedConstant.DIR_LEFT;
                }
            }
        }

    }
    public static void main(String[] args) throws Exception{
        String x = "116.43876247965281";
        String y = "30.249936003569825";
        List<Point> shellPoint = new LinkedList<>();
        Point point = GeometryUtil.createPoint(x, y);
        shellPoint.add(point);
        List<Point> points = GeometryUtil.convexHull(shellPoint);
        for (Point point1 : points) {
            System.out.println(point1);
        }
        if (Double.parseDouble(y) <= 90 && Double.parseDouble(y) >= -90) {
            System.out.println(GeoHash.encodeHash(Double.parseDouble(y), Double.parseDouble(x), 6));
        } else {
            System.out.println("---------");
        }
        //System.out.println(GisNoUtil.sliceUpCoordinate(x, y));
//        String geom_wkt = "POLYGON((113.06570292790636 23.42028553737103,113.06552980346167 23.419517183110543,113.06574761867522 23.41950244360835,113.06577980518342 23.419689498248218,113.06614914981765 23.419588783077927,113.06617677211761 23.419453218659157,113.0665458729891 23.419382709498322,113.06657910346985 23.419152946072387,113.06651002889338 23.41881639728166,113.06685268878937 23.418557321383346,113.06699216365814 23.41846871582854,113.06733548641205 23.418626236773832,113.0678182840347 23.41903972836272,113.06790411472319 23.419152946072387,113.06817862205206 23.419605815942006,113.06821080856024 23.41997500218855,113.06818935088813 23.420260505512672,113.06640981178133 23.420279496204984,113.06570292790636 23.42028553737103))";
//        System.out.println(sliceUpByWkt(geom_wkt, 0.5));
//
//        sliceUpByWkt(geom_wkt, 0.5).forEach(o -> System.out.println("----" + o));
//
//        System.out.println(sliceUpCoordinate(113.06570292790636,23.42028553737103, 0.5));
//        System.out.println(getMeter(0.005));
//        System.out.println(getMeter(0.05));
//        System.out.println(getMeter(0.5));
//        System.out.println(getMeter(5));
        String line;
        try (Scanner sc = new Scanner(new FileReader("D:/citykwt.csv"))){
            while (sc.hasNext()) {
                line = sc.nextLine();
                System.out.println(DateUtil.getCurrentDatetimesss());
                System.out.println(createMulPolygonByWKT(line).distance(createPoint(110.21198, 20.780169)));
                System.out.println(DateUtil.getCurrentDatetimesss());
                System.out.println("----------------");
                System.out.println(DateUtil.getCurrentDatetimesss());
                System.out.println(createMulPolygonByWKT(line).contains(createPoint(110.21198, 20.780169)));
                System.out.println(DateUtil.getCurrentDatetimesss());
            }
        }

//        List<LatLong> llList = new ArrayList<>();
//        llList.add(new LatLong(22.69167559851195, 113.97257750853899));
//        llList.add(new LatLong(22.691556818124198, 113.97235220298171));
//        llList.add(new LatLong(22.690666198730497, 113.97287607193));
//        llList.add(new LatLong(22.690289820914927, 113.97242730483413));
//
//		String muti = "POLYGON ((113.97257750853899 22.69167559851195, 113.97235220298171 22.691556818124198, 113.97287607193 22.690666198730497, 113.97242730483413 22.690289820914927, 113.97275989875197 22.689755302953742, 113.97266333922745 22.68909210184448, 113.97178357467057 22.688646666461906, 113.97082870826127 22.688983217773554, 113.96907990798356 22.691348952197885, 113.96919792518021 22.691645903424686, 113.9718801341951 22.692804007060232, 113.97207325324418 22.69236848205506, 113.97257750853899 22.69167559851195))";
//		Geometry ge = createPolygonByWKT(muti);
//		Point point = createPoint(113.973498, 22.690417);
//
//		System.out.println(getMeter(ge.distance(point)));
//        System.out.println(getDistance(llList, new LatLong(22.690417, 113.973498)));
    }
}
