package com.sf.gis.java.base.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * 网点相关信息
 * @author 01370539 created on Jul.06 2021
 */
@Table
public class ZcInfo implements Serializable {
    @Column(name = "zc")
    private String zc;
    @Column(name = "lng")
    private String lng;
    @Column(name = "lat")
    private String lat;

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }


}
