package com.sf.gis.java.base.dto;

public class ArApiIn {
    private String ak;  // 必填项。授权ak
    private String opt;  // 非必填项。空（默认），外部调用必须为空或不填，按业务逻辑综合调用；tip1-纯文本调用；geo1-地理编码调用；cx-包含展馆地址判断的逻辑，CX专用
    private String datatype;  // 非必填项。s01：寄件(用户维度：寄件，小哥维度：收件)-微服务兼
    private String province;  // 非必填项。省信息，中文
    private String city;  // 非必填项。城市信息，中文
    private String district;  // 非必填项。区县信息，中文
    private String address;  // 必填项。
    private String extention;  // 非必填项。0：不显示附加信息（默认）；1：显示附加信息(非对外)
    private String exact;  // 非必填项。说明：默认会将province + city + district + address进行拼接组合后进行查询，如果组合后的完整地址province + city + districe 与 address 字段中的省市区冲突，此字段含义为：1：不进行拼接，以address为准再查询一次；0：直接返回结果，不再做二次查询；

    public String getAk() {
        return ak;
    }

    public void setAk(String ak) {
        this.ak = ak;
    }

    public String getOpt() {
        return opt;
    }

    public void setOpt(String opt) {
        this.opt = opt;
    }

    public String getDatatype() {
        return datatype;
    }

    public void setDatatype(String datatype) {
        this.datatype = datatype;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getExtention() {
        return extention;
    }

    public void setExtention(String extention) {
        this.extention = extention;
    }

    public String getExact() {
        return exact;
    }

    public void setExact(String exact) {
        this.exact = exact;
    }

    @Override
    public String toString() {
        return "ArApiIn{" +
                "ak='" + ak + '\'' +
                ", opt='" + opt + '\'' +
                ", datatype='" + datatype + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", district='" + district + '\'' +
                ", address='" + address + '\'' +
                ", extention='" + extention + '\'' +
                ", exact='" + exact + '\'' +
                '}';
    }
}
