package com.sf.gis.java.base.util;

import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;

import java.time.ZoneId;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.connector.file.sink.FileSink;
import org.apache.flink.configuration.GlobalConfiguration;
import org.apache.flink.streaming.api.functions.sink.filesystem.OutputFileConfig;
import org.apache.flink.streaming.api.functions.sink.filesystem.StreamingFileSink;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Text;
import org.apache.flink.core.fs.Path;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Flink工具类
 * @author 01370539 Created On: May.07 2021
 */
public class FlinkUtil {
	public static final Logger logger = LoggerFactory.getLogger(FlinkUtil.class);

	private static final boolean asyncCheckpoints = false;
	private static final long checkpointInterval = 5000;
	private static final String checkpointDir = System.getProperty("ckDir");
	private static final int numberRetries = 7;
	private static final int retryDelay = 10;

    /**
     * 获取执行环境
     * @return 执行环境
     */
	public static StreamExecutionEnvironment getExecutionEnv() {
		final StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

		if (checkpointInterval > 0 && !StringUtils.isEmpty(checkpointDir)) {
			logger.error("setting chechpoint...");
			env.enableCheckpointing(checkpointInterval);
			logger.error(checkpointDir);
			env.setStateBackend(new FsStateBackend(checkpointDir, asyncCheckpoints));

			// 设置模式为exactly-once （这是默认值）
			env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

			// 确保检查点之间有至少500 ms的间隔【checkpoint最小间隔】
			env.getCheckpointConfig().setMinPauseBetweenCheckpoints(500);
			// 检查点必须在两分钟内完成，或者被丢弃【checkpoint的超时时间】
			env.getCheckpointConfig().setCheckpointTimeout(120000);
			// 同一时间只允许进行一个检查点
			env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
			// 表示一旦Flink处理程序被cancel后，会保留Checkpoint数据，以便根据实际需要恢复到指定的Checkpoint【详细解释见备注】
			env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
		}

		if (numberRetries > 0) {
			env.setRestartStrategy(RestartStrategies.fixedDelayRestart(
					// 尝试重启次数
					numberRetries,
					// 延迟时间间隔
					Time.of(retryDelay, TimeUnit.SECONDS)));
		}

		return env;
	}

	private static int getPid() {
		RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
		String name = runtime.getName(); // format: "pid@hostname"
		try {
			return Integer.parseInt(name.substring(0, name.indexOf('@')));
		} catch (Exception e) {
			return -1;
		}
	}

	/**
     * 滚动写入hdfs策略
	 * withRolloverInterval：它至少包含 15 分钟的数据; withInactivityInterval：最近 5 分钟没有收到新的记录; withMaxPartSize：文件大小达到 1GB （写入最后一条记录后）
	 */
	public static void initHdfsSink(DataStream<String> dataStream, String outputPath,Integer sinkParallelism) {
		OutputFileConfig outputFileConfig = OutputFileConfig.builder()
				.build();
		StreamingFileSink<String> bucketingSink = StreamingFileSink
				.forRowFormat(new Path(outputPath), new SimpleStringEncoder<String>("UTF-8"))
				.withBucketAssigner(new DateTimeBucketAssigner("yyyyMMdd", ZoneId.of("Asia/Shanghai")))
				.withRollingPolicy(DefaultRollingPolicy.builder()
				.withRolloverInterval(8 * 60 * 1000L)
				.withMaxPartSize(1024 * 1024 * 128L)
				.withInactivityInterval(8 * 60 * 1000L)
				.build()).withOutputFileConfig(outputFileConfig).build();
		dataStream.addSink(bucketingSink).setParallelism(sinkParallelism);
	}
}
