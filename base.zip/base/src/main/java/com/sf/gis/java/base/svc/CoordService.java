package com.sf.gis.java.base.svc;

import com.github.davidmoten.geo.LatLong;
import com.sf.gis.java.base.dto.CoordInfo;
import com.sf.gis.java.base.util.GeometryUtil;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;

/**
 * 坐标相关服务类
 * @author 01370539 created on Aug.9 2021
 */
public class CoordService {
    private static final Logger logger = LoggerFactory.getLogger(CoordService.class);

    /**
     * 坐标聚合,形成固定范围内的做标集
     * @param rddCoord 坐标集
     * @param dis 需要聚合的坐标之间的距离
     * @return 进行子集归类后的结果
     */
    public JavaRDD<CoordInfo> converge(JavaRDD<CoordInfo> rddCoord, int dis) {
        return rddCoord.mapToPair(temp -> new Tuple2<>(temp.getKey(), temp)).groupByKey().flatMap(tp -> {
            List<CoordInfo> resultList = new ArrayList<>();

            Map<String, CoordInfo> idMap = new HashMap<>();
            tp._2.forEach(temp -> idMap.put(temp.getUuid(), temp));
            logger.error("start the converge, key - {} have value count - {}", tp._1, idMap.size());

            CoordInfo ci = null;
            CoordInfo subCi;
            LatLong subLl;

            List<String> idList = new ArrayList<>(idMap.keySet());
            int totalSize = idList.size();
            String id;
            String subId;
            for (int i = 0; i < totalSize; i++) {
                id = idList.get(i);
                ci = idMap.get(id);
                if (ci != null) {
                    if (ci.getSubMap().get(ci.getUuid()) == null) {
                        ci.getLlList().add(new LatLong(Double.parseDouble(ci.getLat()), Double.parseDouble(ci.getLng())));
                        ci.getSubMap().put(ci.getUuid(), ci);
                        idMap.remove(id);
                    }

                    for (int j = i+1; j < totalSize; j++) {
                        subId = idList.get(j);
                        subCi = idMap.get(subId);
                        if (subCi != null) {
                            subLl = new LatLong(Double.parseDouble(subCi.getLat()), Double.parseDouble(subCi.getLng()));
                            if (GeometryUtil.getDistance(ci.getLlList(), subLl) <= dis) {
                                if (subCi.getSubMap().get(subCi.getUuid()) == null) {
                                    subCi.getLlList().add(new LatLong(Double.parseDouble(subCi.getLat()), Double.parseDouble(subCi.getLng())));
                                    subCi.getSubMap().put(subCi.getUuid(), subCi);
                                }
                                ci.getLlList().addAll(subCi.getLlList());
                                ci.getSubMap().putAll(subCi.getSubMap());
                                idMap.remove(subId);
                            }
                        }
                    }
                    resultList.add(ci);
                    logger.error("It's a parent. need converge: total size: {}, cal count: {}, cal id {}, subList.size - {}", totalSize, i, id, ci.getSubMap().size());
                } else {
                    logger.error("It's a sub, don't need converge: total size: {}, cal count: {}, cal id {}", totalSize, i, id);
                }
            }
            logger.error("after converge, key - {}, count : {}", tp._1, resultList.size());
            return resultList.iterator();
        });
    }

    /**
     * 获取中心点坐标并赋予子集
     * @param rddCoord 坐标集
     * @return 获取子集中心点后的结果
     */
    public JavaPairRDD<String, LatLong> getCenter(JavaRDD<CoordInfo> rddCoord) {
        return rddCoord.flatMapToPair(temp -> {
            List<Tuple2<String, LatLong>> resultList = new ArrayList<>();

            LinkedList<LatLong> llList = new LinkedList<>(temp.getLlList());
            LatLong center = GeometryUtil.getCenter(llList);
            for (CoordInfo ci : temp.getSubMap().values()) {
                resultList.add(new Tuple2<>(ci.getUuid(), center));
            }
            return resultList.iterator();
        });
    }
}
