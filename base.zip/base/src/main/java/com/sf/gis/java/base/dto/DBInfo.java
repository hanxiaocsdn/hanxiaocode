package com.sf.gis.java.base.dto;

import com.sf.gis.java.base.util.ConfigUtil;
import org.apache.commons.lang.StringUtils;

import java.util.Properties;

/**
 * 数据库相关信息
 * @author 01370539 Created on May.7 2021
 */
public class DBInfo {

    private final String driver;
    private final String url;
    private final String user;
    private final String password;
    public DBInfo(String dbConfigFileName) {
        Properties properties = ConfigUtil.loadPropertiesConfiguration(dbConfigFileName);
        driver = properties.getProperty("driver");
        url = properties.getProperty("url");
        user = properties.getProperty("user");
        password = properties.getProperty("password");
    }
    public DBInfo(String driver,String url,String user, String password) {
        this.driver = driver;
        this.url = url;
        this.user = user;
        this.password = password;
    }
    public String getDriver() {
        return this.driver;
    }

    public String getUrl() {
        return this.url;
    }

    public String getUser() {
        return this.user;
    }

    public String getPassword() {
        return this.password;
    }

}
