package com.sf.gis.java.base.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import org.apache.commons.lang.StringUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.Cell;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.filter.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.util.*;

/**
 * 和hbase交互的工具类
 *
 * @author 01370539 created on Jul.21 2021
 */
public class HbaseUtil {
    private static final Logger logger = LoggerFactory.getLogger(HbaseUtil.class);
    private static final DecimalFormat DECIMAL_FORMAT2 = new DecimalFormat("00");
    private static final DecimalFormat DECIMAL_FORMAT3 = new DecimalFormat("000");
    private static final DecimalFormat DECIMAL_FORMAT4 = new DecimalFormat("0000");

    private static volatile Connection conn;
    private static Properties properties;
    private static volatile Configuration hbasecConf;

    /**
     * 设置hbase配置信息
     *
     * @param prop hbase配置信息
     */
    public static void setProperties(Properties prop) {
        properties = prop;
    }

    // 获取hbase配置
    private static Configuration getHbaseConf() {
        Configuration hbaseConf = null;
        try {
            //获取hbase的conf
            hbaseConf = HBaseConfiguration.create();

            //设置写入的表
            hbaseConf.set("hbase.zookeeper.quorum", properties.getProperty("hbase.zookeeper.quorum"));
            hbaseConf.set("hbase.zookeeper.property.clientPort", properties.getProperty("hbase.zookeeper.property.clientPort"));
            hbaseConf.set("zookeeper.znode.parent", properties.getProperty("zookeeper.znode.parent"));

            logger.error("hbase.zookeeper.quorum.value: {}", properties.getProperty("hbase.zookeeper.quorum"));
            logger.error("hbase.zookeeper.property.clientPort.value: {}", properties.getProperty("hbase.zookeeper.property.clientPort"));
            logger.error("zookeeper.znode.parent.value: {}", properties.getProperty("zookeeper.znode.parent"));
        } catch (Exception e) {
            logger.error(">>>连接hbase失败:" + e);
        }
        return hbaseConf;
    }

    // 获取hbase配置
    public static Configuration getHbaseConfNew() {
        if (hbasecConf == null) {
            synchronized (HbaseUtil.class) {
                if (hbasecConf == null) {
                    try {
                        hbasecConf = getHbaseConf();
                    } catch (Exception e) {
                        logger.error(">>>获取hbasecConf对象失败:" + e);
                    }
                }
            }
        }
        return hbasecConf;
    }


    /**
     * 获取hbse链接
     *
     * @return hbase链接
     */
    public static Connection getConnection() {
        if (conn == null) {
            synchronized (HbaseUtil.class) {
                if (conn == null) {
                    try {
                        Configuration hbaseConf = getHbaseConf();
                        conn = ConnectionFactory.createConnection(hbaseConf);
                    } catch (Exception e) {
                        logger.error(">>>获取conn对象失败:" + e);
                    }
                }
            }
        }
        return conn;
    }

    /**
     * 获取表
     *
     * @param conn    链接
     * @param tblName 表名
     * @return 表信息
     */
    public static Table getTable(Connection conn, String tblName) {
        Table table = null;
        try {
            table = conn.getTable(TableName.valueOf(tblName));
        } catch (Exception e) {
            logger.error(">>>获取Table对象失败:" + e);
        }
        return table;
    }

    /**
     * 获取表
     *
     * @param tblName 表名
     * @return 表信息
     */
    public static Table getTable(String tblName) {
        Table table = null;
        try {
            table = getConnection().getTable(TableName.valueOf(tblName));
        } catch (Exception e) {
            logger.error(">>>获取Table对象失败: {}", e);
        }
        return table;
    }

    /**
     * 清空表，保存表分区
     *
     * @param tblName 表名
     */
    public static void truncateTable(String tblName) {
        try {
            Admin admin = getConnection().getAdmin();
            TableName tables = TableName.valueOf(tblName);
            admin.disableTable(tables);
            admin.truncateTable(tables, true);
        } catch (Exception e) {
            logger.error(">>>清空表失败: {}", e);
        }
    }

    /**
     * 获取 hbase 存储的 key
     *
     * @param rule        客户自定义的key规则
     * @param regionCount hbase库的分区数
     * @return 最终的 row key
     */
    public static String getRowKey(String rule, int regionCount) {
        String hashcode = String.valueOf((rule.hashCode() % regionCount)).replaceAll("-", "");
        int regionLen = String.valueOf(regionCount - 1).length();
        if (hashcode.length() == regionLen) {
            return hashcode + "_" + rule;
        } else {
            if (regionLen == 2) {
                return DECIMAL_FORMAT2.format(Integer.parseInt(hashcode)) + "_" + rule;
            } else if (regionLen == 3) {
                return DECIMAL_FORMAT3.format(Integer.parseInt(hashcode)) + "_" + rule;
            } else {
                return DECIMAL_FORMAT4.format(Integer.parseInt(hashcode)) + "_" + rule;
            }
        }
    }

    public static void save(Table table, List<Put> putList) {
        try {
            Instant begins = Instant.now();
            boolean flag = addPuts(table, putList);
            Instant finish = Instant.now();
            if (flag) {
                logger.info("put size = " + putList.size() + " success - time " + Duration.between(begins, finish).getSeconds() + "s");
                putList.clear();
            } else {
                for (int j = 0; j < 3; j++) {
                    Thread.sleep(5 * 1000);
                    begins = Instant.now();
                    flag = addPuts(table, putList);
                    finish = Instant.now();
                    if (flag) {
                        logger.info("put size = " + putList.size() + " success - time " + Duration.between(begins, finish).getSeconds() + "s");
                        break;
                    }
                }
                if (!flag) {
                    logger.error("error - {}" + putList.size());
                }
                putList.clear();
            }
        } catch (Exception e) {
            logger.error("put to hbase error .", e);
        }
    }

    public static void delete(Table table, List<Delete> deletes) {
        try {
            logger.info("begin delete " + deletes.size());
            Instant begins = Instant.now();
            int size = deletes.size();
            boolean flag = deleteKeys(table, deletes);
            Instant finish = Instant.now();
            if (flag) {
                logger.info("delete size = " + size + " success - time " + Duration.between(begins, finish).getSeconds() + "s");
                deletes.clear();
            } else {
                for (int j = 0; j < 3; j++) {
                    Thread.sleep(5 * 1000);
                    begins = Instant.now();
                    flag = deleteKeys(table, deletes);
                    finish = Instant.now();
                    if (flag) {
                        logger.info("delete size = " + size + " success - time " + Duration.between(begins, finish).getSeconds() + "s");
                        break;
                    }
                }
                if (!flag) {
                    logger.error("error - {}" + size);
                }
                deletes.clear();
            }
        } catch (Exception e) {
            logger.error("delete from hbase error .", e);
        }
    }

    public static boolean addPuts(Table table, List<Put> putList) {
        boolean flag = false;
        try {
            table.put(putList);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("put PutList error.." + e);
        }
        return flag;
    }

    public static List<JSONObject> getByKeys(Table table, List<Get> keys, String family, String column) throws Exception {
        List<JSONObject> list = new ArrayList<>();
        Result[] results = table.get(keys);
        for (Result result : results) {
            String value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
            if (value == null) {
                list.add(null);
            } else {
                list.add(JSONObject.parseObject(EDEUtil.enAndDeSimple(value)));
            }
        }
        return list;
    }

    public static List<JSONArray> getByKeysForArray(Table table, List<Get> keys, String family, String column) {
        List<JSONArray> list = new ArrayList<>();
        try {
            Result[] results = table.get(keys);
            for (Result result : results) {
                String value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
                if (value == null) {
                    list.add(null);
                } else {
                    list.add(JSONObject.parseArray(value));
                }
            }
        } catch (Exception e) {
            logger.error("get keys from hbase error.", e);
        }
        return list;
    }

    public static List<JSONObject> getByKeys2(Table table, List<Get> keys, String family, String column) {
        List<JSONObject> list = new ArrayList<>();
        try {
            Result[] results = table.get(keys);
            for (Result result : results) {
                String value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
                if (value == null) {
                    list.add(null);
                } else {
                    list.add(JSONObject.parseObject(value));
                }
            }
        } catch (Exception e) {
            logger.error(">>>查询失败:" + e);
        }
        return list;
    }

    public static List<JSONObject> getByKeysNoDecrypt(Table table, List<Get> keys, String family, String column) throws Exception {
        List<JSONObject> list = new ArrayList<>();
        Result[] results = table.get(keys);
        for (Result result : results) {
            String value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
            if (value == null) {
                list.add(null);
            } else {
                list.add(JSONObject.parseObject(value));
            }
        }
        return list;
    }

    public static <T> List<T> getByKeys2(Table table, List<Get> keys, String family, String column, TypeReference<T> clazz) {
        List<T> list = new ArrayList<>();
        try {
            Result[] results = table.get(keys);
            for (Result result : results) {
                String value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
                if (value == null) {
                    list.add(null);
                } else {
                    list.add(JSONObject.parseObject(value, clazz));
                }
            }
        } catch (Exception e) {
            logger.error(">>>查询失败:" + e);
        }
        return list;
    }

    public static boolean deleteKeys(Table table, List<Delete> deletes) {
        boolean flag = false;
        try {
            table.delete(deletes);
            flag = true;
        } catch (Exception e) {
            e.printStackTrace();
            logger.error("put PutList error.." + e);
        }
        return flag;
    }

    public static Put getPut(String rowKey, String family, String column, String value) {
        Put rowPut = null;
        try {
            rowPut = new Put(Bytes.toBytes(rowKey));
            if (value == null) {
                rowPut.addColumn(Bytes.toBytes(family), Bytes.toBytes(column), Bytes.toBytes(""));
            } else {
                rowPut.addColumn(Bytes.toBytes(family), Bytes.toBytes(column), Bytes.toBytes(value));
            }
        } catch (Exception e) {
            logger.error(">>>构建Put失败:" + e);
        }
        return rowPut;
    }

    public static Get getGet(String rowKey, String family, String column) {
        Get get = null;
        try {
            get = new Get(Bytes.toBytes(rowKey));
            get.addColumn(Bytes.toBytes(family), Bytes.toBytes(column));
        } catch (Exception e) {
            logger.error(">>>构建Get失败:" + e);
        }
        return get;
    }

    /**
     * 构建转换数据
     *
     * @param obj
     * @return
     */
    public static Put convert(JSONObject obj) {
        Put put = null;
        try {
            //设置主键，这里测试，使用系统时间
            long longtTime = System.currentTimeMillis();
            SimpleDateFormat dfTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");
            String saveTime = dfTime.format(new Date(longtTime));
            put = new Put(Bytes.toBytes(saveTime));
            put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("date"), Bytes.toBytes(saveTime));
            put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("wrong_value"), Bytes.toBytes(obj.toString()));
        } catch (Exception e) {
            logger.error(">>>数据转换失败：" + e);
        }
        return put;
    }


    /**
     * 根据rowKey精确查询单行数据单行值
     *
     * @param rowkey
     * @param family
     * @param column
     * @return
     */
    public static String getByKey(Table table, String rowkey, String family, String column) {
        String value = null;
        try {
            //单个get查询
            Get get = new Get(Bytes.toBytes(rowkey));
            get.addColumn(Bytes.toBytes(family), Bytes.toBytes(column));
            Result result = table.get(get);
            value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
        } catch (Exception e) {
            logger.error(">>>查询失败:" + e);
        }
        return value;
    }

    public static Result getByKey(Table table, String rowkey) {
        Result result = null;
        try {
            //单个get查询
            Get get = new Get(Bytes.toBytes(rowkey));
            result = table.get(get);
        } catch (Exception e) {
            logger.error(">>>查询失败:" + e);
        }
        return result;
    }

    /**
     * 根据rowKey精确查询单行数据的多列值
     *
     * @param rowkey
     * @param family
     * @param columns
     * @return
     */
    public static List<String> getByKey(Table table, String rowkey, String family, List<String> columns) {
        List<String> list = new ArrayList<>();
        try {
            Get get = new Get(Bytes.toBytes(rowkey));
            get.addFamily(family.getBytes());
            Result result = table.get(get);
            for (String column : columns) {
                list.add(Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column))));
            }
        } catch (Exception e) {
            logger.error(">>>查询失败:" + e);
        }
        return list;
    }


    /**
     * 根据subKey模糊批量查询多行数据
     *
     * @param subKey
     * @param family
     * @param column
     * @return
     */
    public static List<String> scanBySubKey(Table table, String subKey, String family, String column) {
        List<String> list = new ArrayList<>();
        //批量模糊查询
        RowFilter filter = new RowFilter(CompareFilter.CompareOp.EQUAL, new SubstringComparator(subKey));
        Scan scan = new Scan();
        scan.setCaching(100);
        scan.setFilter(filter);
        ResultScanner rs = null;
        try {
            rs = table.getScanner(scan);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (rs != null) {
            for (Result result : rs) {
                if (result.containsColumn(Bytes.toBytes(family), Bytes.toBytes(column))) {
                    String value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
                    list.add(value);
                }
            }
        }
        return list;
    }

    /**
     * 根据前缀查询多行数据
     *
     * @param prefixKey
     * @param family
     * @param column
     * @return
     */
    public static List<String> scanByPrefixKey(Table table, String prefixKey, String family, String column) {
        List<String> list = new ArrayList<>();
        Scan scan = new Scan();
        scan.setCaching(100);
        scan.setMaxResultSize(1000);
        scan.setFilter(new PrefixFilter(prefixKey.getBytes()));
        ResultScanner rs = null;
        try {
            rs = table.getScanner(scan);
        } catch (Exception e) {
            e.printStackTrace();
        }
		/*if (rs != null) {
			for (Result result : rs) {
				if (result.containsColumn(Bytes.toBytes(family), Bytes.toBytes(column))) {
					String value = Bytes.toString(result.getValue(Bytes.toBytes(family), Bytes.toBytes(column)));
					list.add("1");
				}
			}
		}*/
        return list;
    }

    /**
     * 根据rowKey删除整行
     *
     * @param table
     * @param rowKey
     */
    public static void deleteByKey(Table table, String rowKey) {
        try {
            table.delete(new Delete(rowKey.getBytes()));
        } catch (Exception e) {
            logger.error(">>>删除操作失败：" + e);
        }

    }

    /**
     * 删除rowKey的某簇的某列
     *
     * @param table
     * @param rowkey
     * @param family
     * @param column
     */
    public static void deleteByColumn(Table table, String rowkey, String family, String column) {
        try {
            Delete delete = new Delete(rowkey.getBytes());
            delete.addColumn(family.getBytes(), column.getBytes());
            table.delete(delete);
        } catch (Exception e) {
            logger.error(">>>删除操作失败：" + e);
        }

    }


    /**
     * 删除rowKey的某个family
     *
     * @param table
     * @param rowkey
     * @param family
     */
    public static void deleteByFamily(Table table, String rowkey, String family) {
        try {
            Delete delete = new Delete(rowkey.getBytes());
            delete.addFamily(family.getBytes());
            table.delete(delete);
        } catch (Exception e) {
            logger.error(">>>删除操作失败：" + e);
        }

    }


    /**
     * 根据rowKey模糊删除
     *
     * @param table
     * @param subKey
     */
    public static void deleteByKeys(Table table, String subKey) {
        try {
            //批量模糊删除
            RowFilter filter = new RowFilter(CompareFilter.CompareOp.EQUAL, new SubstringComparator(subKey));
            Scan scan = new Scan();
            scan.setFilter(filter);
            ResultScanner scanners = table.getScanner(scan);
            List<Delete> keyList = new ArrayList<>();
            Delete delete = null;
            //注意：scala和java的for循环有区别，需要引入转换
            for (Result scanner : scanners) {
                String rowKey = new String(scanner.getRow());
                delete = new Delete(rowKey.getBytes());
                keyList.add(delete);
            }
            table.delete(keyList);
        } catch (Exception e) {
            logger.error(">>>删除操作失败：" + e);
        }
    }


    /**
     * 不知道rowkey，删除某簇的某列的所有数据
     *
     * @param table
     */
    public static void deleteByColumnWithoutKey(Table table, String family, String column) {
        try {
            Scan scan = new Scan();
            scan.addColumn(family.getBytes(), column.getBytes());
            ResultScanner scanner = table.getScanner(scan);
            List<Delete> deletes = new ArrayList<>();
            for (Result result : scanner) {
                byte[] rowKey = result.getRow();
                Delete delete = new Delete(rowKey);
                if (result.containsColumn(family.getBytes(), column.getBytes())) {
                    delete.addColumn(family.getBytes(), column.getBytes());
                    deletes.add(delete);
                }
                if (deletes.size() == 10000) {
                    table.delete(deletes);
                    deletes.clear();
                }
            }
            if (!deletes.isEmpty() && deletes.size() < 10000) {
                table.delete(deletes);
            }
        } catch (Exception e) {
            logger.error(">>>删除操作失败：" + e);
        }

    }

    public static String getKeyStr(String key, int partitionCount) {
        String hashcode = String.valueOf(Math.abs(key.hashCode()) % partitionCount);

        int pttCntLen = String.valueOf(partitionCount).length();
        StringBuffer formatStr = new StringBuffer();
        for (int i = 0; i < pttCntLen; i++) {
            formatStr.append("0");
        }
        DecimalFormat df = new DecimalFormat(formatStr.toString());

        String rowKey;
        if (hashcode.length() == pttCntLen) {
            rowKey = hashcode + "_" + key;
        } else {
            rowKey = df.format(Integer.parseInt(hashcode)) + "_" + key;
        }
        return rowKey;
    }

    /**
     * 使用该类，必须先调用该方法
     *
     * @param hbase_zookeeper_quorum
     * @param hbase_zookeeper_property_clientPort
     * @param zookeeper_znode_parent
     * @return
     */
    public synchronized static Connection init(String hbase_zookeeper_quorum, String hbase_zookeeper_property_clientPort, String zookeeper_znode_parent) {
        if (conn == null) {
            try {
                Configuration conf = HBaseConfiguration.create();

                conf.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum);
                conf.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_property_clientPort);
                conf.set("zookeeper.znode.parent", zookeeper_znode_parent);

                conf.set("hbase.client.retries.number", "10");

                conn = ConnectionFactory.createConnection(conf);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return conn;
    }
    /**
     * 添多条记录
     * @param tableName
     * @param columnFamily
     * @param valueMap
     * @throws IOException
     */
    public static void put(String tableName, String columnFamily, HashMap<String, HashMap<String, String>> valueMap) throws IOException {
        Table table = null;

        try {
            if(null != valueMap && !valueMap.isEmpty()) {

                table = conn.getTable(TableName.valueOf(tableName));

                List<Put> putList = new ArrayList<Put>();

                byte[] cf = Bytes.toBytes(columnFamily);

                for(HashMap.Entry<String, HashMap<String, String>> entry : valueMap.entrySet()) {
                    String rowkey = entry.getKey();
                    Map<String, String> values = entry.getValue();


                    Set<String> set = values.keySet();

                    Put p = new Put(Bytes.toBytes(rowkey));

                    for(String column : set) {
                        String value = values.get(column);
                        try {
                            p.addColumn(cf, Bytes.toBytes(column), Bytes.toBytes(value));
                        } catch (Exception e){
                            throw  new RuntimeException("rowkey:"+rowkey+",column:"+column+",value:"+value);
                        }
                    }

                    putList.add(p);
                }
                table.put(putList);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeStream(table);
        }
    }

    /**
     * 添多条记录
     * @param table
     * @param columnFamily
     * @param valueMap
     * @throws IOException
     */
    public static void put(Table table, String columnFamily, Map<String, Map<String, String>> valueMap) throws IOException {
        try {
            if(null != valueMap && !valueMap.isEmpty()) {
                List<Put> putList = new ArrayList<Put>();

                byte[] cf = Bytes.toBytes(columnFamily);

                for(Map.Entry<String, Map<String, String>> entry : valueMap.entrySet()) {
                    String rowkey = entry.getKey();
                    Map<String, String> values = entry.getValue();

                    Set<String> set = values.keySet();

                    Put p = new Put(Bytes.toBytes(rowkey));
                    for(String column : set) {
                        String value = values.get(column);
                        p.addColumn(cf, Bytes.toBytes(column), Bytes.toBytes(value));
                    }

                    putList.add(p);
                }

                table.put(putList);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {

        }
    }
    /**
     * 添多条记录
     * @param tableName
     * @param value
     * @param exception
     * @throws IOException
     */
    public static void put(String tableName, String rowKey, String value, String exception, String dt) throws IOException {
        Table table = null;

        try {
            table = conn.getTable(TableName.valueOf(tableName));

            Put p = new Put(Bytes.toBytes(rowKey));
            //p.setWriteToWAL(false);
            p.addColumn(Bytes.toBytes("f"), Bytes.toBytes("raw"), value==null?Bytes.toBytes(""):Bytes.toBytes(value));
            p.addColumn(Bytes.toBytes("f"), Bytes.toBytes("exp"), exception==null?Bytes.toBytes(""):Bytes.toBytes(exception));
            p.addColumn(Bytes.toBytes("f"), Bytes.toBytes("dt"), dt==null?Bytes.toBytes(""):Bytes.toBytes(dt));

            table.put(p);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            IOUtils.closeStream(table);
        }
    }
    public static HashMap<String,HashMap<String,String>> getRegex(String tableName,String regexKey) throws IOException {
        Table table = conn.getTable(TableName.valueOf(tableName));
        Scan scan = new Scan();

        //按rowkey匹配是否包含传进来的regexKey的过滤器
        Filter filter = new RowFilter(CompareFilter.CompareOp.EQUAL,
                new SubstringComparator(regexKey));

        scan.setFilter(filter);
        ResultScanner scanner = table.getScanner(scan);

        HashMap<String,HashMap<String,String>> rowMap = new HashMap();
        HashMap<String,String> valueMap = null;

        for (Result r : scanner) {
            valueMap = new HashMap();

            for ( Cell cell : r.rawCells() )
                valueMap.put( Bytes.toString(CellUtil.cloneQualifier(cell)),Bytes.toString(CellUtil.cloneValue(cell)) );

            rowMap.put(Bytes.toString(r.getRow()),valueMap);
        }

        scanner.close();

        return rowMap;
    }
}
