package com.sf.gis.java.base.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TrackInfo implements Serializable {

    @Column(name = "lng")
    private String lng;

    @Column(name = "lat")
    private String lat;

    @Column(name = "aoi_id")
    private String aoiId;

    @Column(name = "inc_day")
    private String incDay;

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    @Override
    public String toString() {
        return "TrackInfo{" +
                "lng='" + lng + '\'' +
                ", lat='" + lat + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", incDay='" + incDay + '\'' +
                '}';
    }
}
