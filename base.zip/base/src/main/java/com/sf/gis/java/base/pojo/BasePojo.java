package com.sf.gis.java.base.pojo;

import java.io.Serializable;

/**
 * 与数据库实现一一对应的父类
 * @author 01370539 Created on May.7 2021
 */
public class BasePojo implements Serializable {
}
