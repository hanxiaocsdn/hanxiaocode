package com.sf.gis.java.base.dto;

/**
 * 地址相关信息
 * @author 01370539 Created on May.28 2021
 */
public class AddrInfo {
    private String addr;  // 地址
    private String province;
    private String city;
    private String county;
    private String town;
    private String village;
    private String detailInfo;
    private String adcode;
    private String cityCode;  // 地址所属城市
    private String split;  // 地址的切词
    private String keyword;  // 主体
    private String keytag;  // 标签
    private String last6;  // 切词中最后一个6
    private String last13;  // 切词中最后一个13
    private String last613;  // 切词中最后一个613
    private String last14;  // 切词中最后一个14
    private String lng;  // 地址的经度
    private String lat;  // 地址的纬度
    private String precision;  // 坐标精度
    private String zc;
    private String zcSrc;
    private String aoiId;
    private String aoiCode;
    private String aoiSrc;
    private String aoiUnit;
    private String detailAddr;
    private String chknId;
    private String normId;
    private String groupId;

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getDetailInfo() {
        return detailInfo;
    }

    public void setDetailInfo(String detailInfo) {
        this.detailInfo = detailInfo;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getSplit() {
        return split;
    }

    public void setSplit(String split) {
        this.split = split;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getKeytag() {
        return keytag;
    }

    public void setKeytag(String keytag) {
        this.keytag = keytag;
    }

    public String getLast6() {
        return last6;
    }

    public void setLast6(String last6) {
        this.last6 = last6;
    }

    public String getLast13() {
        return last13;
    }

    public void setLast13(String last13) {
        this.last13 = last13;
    }

    public String getLast613() {
        return last613;
    }

    public void setLast613(String last613) {
        this.last613 = last613;
    }

    public String getLast14() {
        return last14;
    }

    public void setLast14(String last14) {
        this.last14 = last14;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getPrecision() {
        return precision;
    }

    public void setPrecision(String precision) {
        this.precision = precision;
    }

    public String getZc() {
        return zc;
    }

    public void setZc(String zc) {
        this.zc = zc;
    }

    public String getZcSrc() {
        return zcSrc;
    }

    public void setZcSrc(String zcSrc) {
        this.zcSrc = zcSrc;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiSrc() {
        return aoiSrc;
    }

    public void setAoiSrc(String aoiSrc) {
        this.aoiSrc = aoiSrc;
    }

    public String getAoiUnit() {
        return aoiUnit;
    }

    public void setAoiUnit(String aoiUnit) {
        this.aoiUnit = aoiUnit;
    }

    public String getDetailAddr() {
        return detailAddr;
    }

    public void setDetailAddr(String detailAddr) {
        this.detailAddr = detailAddr;
    }

    public String getChknId() {
        return chknId;
    }

    public void setChknId(String chknId) {
        this.chknId = chknId;
    }

    public String getNormId() {
        return normId;
    }

    public void setNormId(String normId) {
        this.normId = normId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @Override
    public String toString() {
        return "AddrInfo{" +
                "addr='" + addr + '\'' +
                ", province='" + province + '\'' +
                ", city='" + city + '\'' +
                ", county='" + county + '\'' +
                ", town='" + town + '\'' +
                ", village='" + village + '\'' +
                ", detailInfo='" + detailInfo + '\'' +
                ", adcode='" + adcode + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", split='" + split + '\'' +
                ", keyword='" + keyword + '\'' +
                ", keytag='" + keytag + '\'' +
                ", last6='" + last6 + '\'' +
                ", last13='" + last13 + '\'' +
                ", last613='" + last613 + '\'' +
                ", last14='" + last14 + '\'' +
                ", lng='" + lng + '\'' +
                ", lat='" + lat + '\'' +
                ", precision='" + precision + '\'' +
                ", zc='" + zc + '\'' +
                ", zcSrc='" + zcSrc + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiCode='" + aoiCode + '\'' +
                ", aoiSrc='" + aoiSrc + '\'' +
                ", aoiUnit='" + aoiUnit + '\'' +
                ", detailAddr='" + detailAddr + '\'' +
                ", chknId='" + chknId + '\'' +
                ", normId='" + normId + '\'' +
                ", groupId='" + groupId + '\'' +
                '}';
    }
}
