package com.sf.gis.java.base.util;

import com.github.houbb.opencc4j.util.ZhConverterUtil;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringNumUtils {

    private static String[] numArray = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九"};

    /**
     * 阿拉伯数字转中文,不包含单位
     * 10023:一零零二三
     */
    public static String toChinese(String str) {
        StringBuffer sb = new StringBuffer();
        for (char c : str.toCharArray()) {
            if (StringUtils.isNumeric(String.valueOf(c))) {
                sb.append(numArray[Integer.parseInt(String.valueOf(c))]);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static int transferChineseNumber2ArabNumber(String chineseNumber) {
        String aval = "零一二三四五六七八九";
        String bval = "十百千万亿";
        int[] bnum = {10, 100, 1000, 10000, 100000000};
        int num = 0;
        char[] arr = chineseNumber.toCharArray();
        int len = arr.length;
        Stack<Integer> stack = new Stack<Integer>();
        for (int i = 0; i < len; i++) {
            char s = arr[i];
            //跳过零
            if (s == '零') {
                continue;
            }
            //用下标找到对应数字
            int index = bval.indexOf(s);
            //如果不在bval中，即当前字符为数字，直接入栈
            if (index == -1) {
                stack.push(aval.indexOf(s));
            } else { //当前字符为单位。
                int tempsum = 0;
                int val = bnum[index];
                //如果栈为空则直接入栈
                if (stack.isEmpty()) {
                    stack.push(val);
                    continue;
                }
                //如果栈中有比val小的元素则出栈，累加，乘N，再入栈
                while (!stack.isEmpty() && stack.peek() < val) {
                    tempsum += stack.pop();
                }
                //判断是否经过乘法处理
                if (tempsum == 0) {
                    stack.push(val);
                } else {
                    stack.push(tempsum * val);
                }
            }
        }
        //计算最终的和
        while (!stack.isEmpty()) {
            num += stack.pop();
        }
        return num;
    }

    public static String outputArabNumberString(String chineseNumberString) {
        String reg = "[零一二三四五六七八九十百千万亿]+";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(chineseNumberString);
        List<String> chineseNumbers = new ArrayList<>(16);
        List<Integer> arabNumbers = new ArrayList<>(16);
        boolean isNumberFirst = false;
        while (matcher.find()) {
            chineseNumbers.add(matcher.group());
            // 转化成阿拉伯数字
            int arabNum = transferChineseNumber2ArabNumber(matcher.group());
            arabNumbers.add(arabNum);
        }
        String[] arrStr = chineseNumberString.split(reg);

        StringBuilder transferedNumber = new StringBuilder();

        // 数字的数量不大于文字的数量。
        // 如果结尾不是数字，则文字数量比数字数量多一（即使数字位于第一个也不会有影响）；如果结尾是数字，则数字文本数量相等。
        for (int i = 0; i < arrStr.length; i++) {
            // 先拼文字再拼数字，即使数字在第一个也会存在一个空的字符串（""），先拼也不会有影响
            transferedNumber.append(arrStr[i]);
            if (i < arabNumbers.size()) {
                transferedNumber.append(arabNumbers.get(i));
            }
        }
        return transferedNumber.toString();
    }

    public static String outputArabNumberString(String chineseNumberString, String reg) {
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(chineseNumberString);
        List<String> chineseNumbers = new ArrayList<>(16);
        List<Integer> arabNumbers = new ArrayList<>(16);
        boolean isNumberFirst = false;
        while (matcher.find()) {
            chineseNumbers.add(matcher.group());
            // 转化成阿拉伯数字
            int arabNum = transferChineseNumber2ArabNumber(matcher.group());
            arabNumbers.add(arabNum);
        }
        String[] arrStr = chineseNumberString.split(reg);

        StringBuilder transferedNumber = new StringBuilder();

        // 数字的数量不大于文字的数量。
        // 如果结尾不是数字，则文字数量比数字数量多一（即使数字位于第一个也不会有影响）；如果结尾是数字，则数字文本数量相等。
        for (int i = 0; i < arrStr.length; i++) {
            // 先拼文字再拼数字，即使数字在第一个也会存在一个空的字符串（""），先拼也不会有影响
            transferedNumber.append(arrStr[i]);
            if (i < arabNumbers.size()) {
                transferedNumber.append(arabNumbers.get(i));
            }
        }
        return transferedNumber.toString();
    }

    //字符串中繁体字转换成简体字
    public static String changeToSimpleChinese(String searchName) {
        StringBuilder stringBuilder = new StringBuilder();
        int n = 0;
        for (int i = 0; i < searchName.length(); i++) {
            n = (int) searchName.charAt(i);
            char c = searchName.charAt(i);
            String s = String.valueOf(c);
            if (!(19968 <= n && n < 40869)) {
                stringBuilder.append(c);
            } else {
                List<String> strings = ZhConverterUtil.toSimple(c);
                if (strings != null) {
                    int z = 1;
                    //下面用于解决：如果出现简体字转简体居然不是同一个字的时候
                    for (String string : strings) {
                        if (string.equals(s)) {
                            stringBuilder.append(string);
                        } else if (strings.size() == z) {
                            stringBuilder.append(strings.get(0));
                        }
                        z++;
                    }
                } else {
                    stringBuilder.append(c);
                }
            }
        }
        return stringBuilder.toString();
    }

    public static String fixnulltoStr(String str) {
        if (str == null || str.trim().toLowerCase().equals("null")) {
            return "";
        }
        return str;
    }

    public static void main(String[] args) {
        System.out.println(outputArabNumberString("好11十一楼"));
    }


    public static String change_chinese_to_arabic_in_centence(String x) {
        String[] strings1 = {"〇", "一", "二", "三", "四", "五", "六", "七", "八", "九", "零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖", "貮", "两", "十", "拾", "百", "佰", "千", "仟", "万", "萬", "亿", "億", "兆"};
        List<String> list1 = Arrays.asList(strings1);
        String[] strings2 = {"兆", "億", "亿", "萬", "万", "仟", "千", "佰", "百"};
        List<String> list2 = Arrays.asList(strings2);
        String xx = "";
        String yy = "";
        for (int j = 0; j < x.length(); j++) {
            String i = x.charAt(j) + "";
            if (!list1.contains(i)) {
                if (!yy.equals("")) {
                    if (list2.contains(yy)) {
                        yy = yy;
                    } else {
                        yy = chinese_to_arabic(yy) + "";
                    }
                    xx += yy;
                }
                xx += i;
                yy = "";
            } else {
                yy += i;
                if (j == x.length() - 1) {
                    if (list2.contains(yy)) {
                        yy = yy;
                    } else {
                        yy = chinese_to_arabic(yy) + "";
                    }
                    xx += yy;
                }
            }
        }
        return xx.toLowerCase();
    }

    public static long chinese_to_arabic(String cn) {
        HashMap<String, Integer> CN_NUM = new HashMap<String, Integer>() {{
            put("〇", 0);
            put("一", 1);
            put("二", 2);
            put("三", 3);
            put("四", 4);
            put("五", 5);
            put("六", 6);
            put("七", 7);
            put("八", 8);
            put("九", 9);

            put("零", 0);
            put("壹", 1);
            put("贰", 2);
            put("叁", 3);
            put("肆", 4);
            put("伍", 5);
            put("陆", 6);
            put("柒", 7);
            put("捌", 8);
            put("玖", 9);

            put("貮", 2);
            put("两", 2);

        }};

        HashMap<String, Long> CN_UNIT = new HashMap<String, Long>() {{
            put("十", 10L);
            put("拾", 10L);
            put("百", 100L);
            put("佰", 100L);
            put("千", 1000L);
            put("仟", 1000L);
            put("万", 10000L);
            put("萬", 10000L);
            put("亿", 100000000L);
            put("億", 100000000L);
            put("兆", 1000000000000L);
        }};

        long unit = 0;
        ArrayList<Long> ldig = new ArrayList<>();
        StringBuilder sb = new StringBuilder(cn);
        String reverseCn = sb.reverse().toString();
        for (int i = 0; i < reverseCn.length(); i++) {
            String cndig = reverseCn.charAt(i) + "";
            if (CN_UNIT.containsKey(cndig)) {
                unit = CN_UNIT.get(cndig);
                if (unit == 10000L || unit == 100000000L) {
                    ldig.add(unit);
                    unit = 1;
                }
            } else {
                long dig = CN_NUM.get(cndig);
                if (unit != 0) {
                    dig *= unit;
                    unit = 0;
                }
                ldig.add(dig);
            }
        }

        if (unit == 10) {
            ldig.add(10L);
        }

        long val = 0;
        long tmp = 0;
        for (int i = ldig.size() - 1; i >= 0; i--) {
            Long x = ldig.get(i);
            if (x == 10000L || x == 100000000L) {
                val += tmp * x;
                tmp = 0;
            } else {
                tmp += x;
            }
        }
        val += tmp;
        return val;
    }
}
