package com.sf.gis.java.base.util;

import org.apache.commons.lang3.StringUtils;

/**
 * @ProductManager:
 * @Author: 01374443
 * @CreateTime: 2023-08-17 21:02
 * @TaskId:
 * @TaskName:
 * @Description:
 */
public class StrUtils {
    public static boolean isBlank(String str ) {
        if (str != null && !str.trim().isEmpty()) {
            return false;
        }
        return true;
    }

    public static String processInvalidCharacter(String param) {
        return StringUtils.isNotEmpty(param) ? param.trim().replaceAll(" ", "").replaceAll("[\\\\,\\t\\r\\n'\"\\|，^_=*`&{}り<>%:“”、/ 　(null)(NULL)]", "") : param;
    }
}
