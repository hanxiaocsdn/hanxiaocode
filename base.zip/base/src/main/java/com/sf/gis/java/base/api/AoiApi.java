package com.sf.gis.java.base.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.dto.AoiInfo;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.JsonObjectSerialUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 提供获取AOI的各种方式
 *
 * @author 01370539 Created on Apr.30 2021
 */
public class AoiApi {
    private static final Logger logger = LoggerFactory.getLogger(AoiApi.class);

    /**
     * 根据坐标获取AOI信息
     *
     * @param distance 在坐标多少范围内找AOI
     * @param lng      坐标经度
     * @param lat      坐标维度
     * @return AOI相关信息
     */
    public static AoiInfo getCoorAoiByDist(String distance, String lng, String lat) {
        String url = null;
        AoiInfo aoiInfo = new AoiInfo();
        try {
            url = String.format(HttpConstant.HTTP_URL_GETCOORAOI, distance, lng, lat);
            String result = HttpInvokeUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (result == null) {
                logger.error("getCoorAoi resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getBoolean("success")) {
                    JSONArray dataArr = rsJson.getJSONArray("data");
                    if (dataArr != null && dataArr.size() > 0) {
                        aoiInfo = JsonObjectSerialUtil.getObjectFromString(dataArr.getString(0), AoiInfo.class);
                    } else {
                        logger.error("getCoorAoi resp error. url - {}, resp - {}", url, result);
                    }
                } else {
                    logger.error("getCoorAoi resp error. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request getCoorAoi error. url: {}, e: {}", url, e);
        }
        return aoiInfo;
    }

    /**
     * 根据坐标获取AOI区域相关信息
     * @param lng      坐标经度
     * @param lat      坐标维度
     * @return AOI区域相关信息
     */
    public static AoiInfo getAoiAreaByPoint(String lng, String lat) {
        String url = null;
        AoiInfo aoiInfo = new AoiInfo();
        try {
            url = String.format(HttpConstant.HTTP_URL_GETAOIAREABYPOINT, lng, lat);
            String result = HttpInvokeUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (result == null) {
                logger.error("getAoiAreaByPoint resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getBoolean("success")) {
                    JSONObject data = rsJson.getJSONObject("data");
                    if (data != null) {
                        aoiInfo.setCityCode(data.getString("cityCode"));
                        aoiInfo.setAoiAreaCode(data.getString("areaCode"));
                        aoiInfo.setZnoCode(data.getString("znoCode"));
                    } else {
                        logger.error("getAoiAreaByPoint resp error. url - {}, resp - {}", url, result);
                    }
                } else {
                    logger.error("getAoiAreaByPoint resp error. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request getAoiAreaByPoint error. url: {}, e: {}", url, e);
        }
        return aoiInfo;
    }

    /**
     * 根据坐标获取AOIID
     * @param lng      坐标经度
     * @param lat      坐标维度
     * @return AOI ID
     */
    public static String getAoiIdByPoint(String lng, String lat) {
        String url = null;
        try {
            url = String.format(HttpConstant.HTTP_URL_GETAOIIDBYPOINT, lng, lat);
            String result = HttpInvokeUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (result == null) {
                logger.error("getAoiIdByPoint resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getBoolean("success")) {
                    JSONObject data = rsJson.getJSONObject("data");
                    if (data != null) {
                        return data.getString("id");
                    } else {
                        logger.error("getAoiIdByPoint resp error. url - {}, resp - {}", url, result);
                    }
                } else {
                    logger.error("getAoiIdByPoint resp error. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request getAoiIdByPoint error. url: {}, e: {}", url, e);
        }
        return null;
    }

    /**
     * 获取AOI边界和坐标之间的距离
     * @param aoiId AOI ID
     * @param lng      坐标经度
     * @param lat      坐标维度
     * @return AOI相关信息
     */
    public static double getCoorAoiDist(String aoiId, String lng, String lat) {
        String url = null;
        try {
            url = String.format(HttpConstant.HTTP_URL_GETCOORAOIDIST, aoiId, lng, lat);
            String result = HttpInvokeUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (result == null) {
                logger.error("getCoorAoiByDist resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getBoolean("success")) {
                   return rsJson.getDoubleValue("data");
                } else {
                    logger.error("getCoorAoiByDist resp error. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request getCoorAoiByDist error. url: {}, e: {}", url, e);
        }
        return -1;
    }


    /**
     * 获取AOI边界质检的距离
     * @param aoiId1 AOI ID 1
     * @param aoiId1 AOI ID 2
     * @return AOI边界之间的距离
     */
    public static double getCoorAoiToAoiDist(String aoiId1, String aoiId2) {
        String url = null;
        try {
            url = String.format(HttpConstant.HTTP_URL_GETAOITOAOIDIST, aoiId1, aoiId2);
            String result = HttpInvokeUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (result == null) {
                logger.error("getCoorAoiToAoiDist resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getBoolean("success")) {
                    return rsJson.getDoubleValue("data");
                } else {
                    logger.error("getCoorAoiToAoiDist resp error. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request getCoorAoiToAoiDist error. url: {}, e: {}", url, e);
        }
        return -1;
    }

    /**
     * 根据坐标获取AOI和网点等信息
     * @param ak ak
     * @param opt opt:aoi等
     * @param x 经度
     * @param y 纬度
     * @return AOI相关信息
     */
    public static AoiInfo byxy(String ak, String opt, String x, String y) {
        String url = null;
        AoiInfo ai = new AoiInfo();
        ai.setLng(Double.parseDouble(x));
        ai.setLat(Double.parseDouble(y));
        try {
            url = String.format(HttpConstant.HTTP_URL_DEPT2_BYXY_HAVEOPT, ak, opt, x, y);
            String result = HttpInvokeUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (result == null) {
                logger.error("byxy resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getInteger("status") == 0) {
                    JSONObject resultJson = rsJson.getJSONObject("result");
                    if (resultJson != null) {
                        JSONArray dataArr = resultJson.getJSONArray("data");
                        if (dataArr != null && dataArr.size() > 0) {
                            ai.setZnoCode(dataArr.getJSONObject(0).getString("zno_code"));
                        } else {
                            logger.error("byxy data is null. url - {}, resp - {}", url, result);
                        }
                        JSONArray aoidataArr = resultJson.getJSONArray("aoi_data");
                        if (aoidataArr != null && aoidataArr.size() > 0) {
                            ai.setAoiId(aoidataArr.getJSONObject(0).getString("aoi_id"));
                            ai.setAoiCode(aoidataArr.getJSONObject(0).getString("aoi_code"));
                            ai.setAoiName(aoidataArr.getJSONObject(0).getString("aoi_name"));
                            ai.setAoiAreaCode(aoidataArr.getJSONObject(0).getString("aoi_area_code"));
                            ai.setAoiZc(aoidataArr.getJSONObject(0).getString("aoi_zc"));
                        } else {
                            logger.error("byxy aoi_data is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("byxy result is null. url - {}, resp - {}", url, result);
                    }
                } else {
                    logger.error("byxy status = 1. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request byxy error. url: {}, e: {}", url, e);
        }
        return ai;
    }

    public static AoiInfo byxyNew(String ak, String opt, String x, String y) {
        String url = null;
        AoiInfo ai = new AoiInfo();
        if(StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)){
            ai.setLng(Double.parseDouble(x));
            ai.setLat(Double.parseDouble(y));
            try {
                url = String.format(HttpConstant.HTTP_URL_DEPT2_BYXY_HAVEOPT, ak, opt, x, y);
                String result = HttpInvokeUtil.sendGet(url);
                if (result == null) {
                    logger.error("byxy resp null. url - {}", url);
                } else {
                    JSONObject rsJson = JSON.parseObject(result);
                    if (rsJson.getInteger("status") == 0) {
                        JSONObject resultJson = rsJson.getJSONObject("result");
                        if (resultJson != null) {
                            JSONArray dataArr = resultJson.getJSONArray("data");
                            if (dataArr != null && dataArr.size() > 0) {
                                ai.setZnoCode(dataArr.getJSONObject(0).getString("zno_code"));
                            } else {
                                logger.error("byxy data is null. url - {}, resp - {}", url, result);
                            }
                            JSONArray aoidataArr = resultJson.getJSONArray("aoi_data");
                            if (aoidataArr != null && aoidataArr.size() > 0) {
                                ai.setAoiId(aoidataArr.getJSONObject(0).getString("aoi_id"));
                                ai.setAoiCode(aoidataArr.getJSONObject(0).getString("aoi_code"));
                                ai.setAoiName(aoidataArr.getJSONObject(0).getString("aoi_name"));
                            } else {
                                ai.setAoiCode("not_covered");
                                logger.error("byxy aoi_data is null. url - {}, resp - {}", url, result);
                            }
                        } else {
                            ai.setAoiCode("not_covered");
                            logger.error("byxy result is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("byxy status = 1. url - {}, resp - {}", url, result);
                    }
                }
            } catch (Exception e) {
                logger.error("request byxy error. url: {}, e: {}", url, e);
            }
        }
        return ai;
    }

    /**
     * 根据坐标获取AOI和网点等信息
     * @param ak ak
     * @param x 经度
     * @param y 纬度
     * @return AOI相关信息
     */
    public static AoiInfo byxy(String ak, String x, String y) {
        String url = null;
        AoiInfo ai = new AoiInfo();
        ai.setLng(Double.parseDouble(x));
        ai.setLat(Double.parseDouble(y));
        try {
            url = String.format(HttpConstant.HTTP_URL_DEPT2_BYXY_NOOPT, ak, x, y);
            String result = HttpInvokeUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
            if (result == null) {
                logger.error("byxy resp null. url - {}", url);
            } else {
                JSONObject rsJson = JSON.parseObject(result);
                if (rsJson.getInteger("status") == 0) {
                    JSONObject resultJson = rsJson.getJSONObject("result");
                    if (resultJson != null) {
                        JSONObject dataJson = resultJson.getJSONObject("data");
                        if (dataJson != null) {
                            JSONObject aoiJson = dataJson.getJSONObject("aoi");
                            if (aoiJson != null) {
                                ai.setAoiId(aoiJson.getString("aoi_id"));
                                ai.setAoiName(aoiJson.getString("aoi_name"));
                                ai.setAoiCode(aoiJson.getString("aoi_code"));
                                ai.setAoiType(aoiJson.getString("aoi_type"));
                                ai.setAoiTypeName(aoiJson.getString("aoi_type_name"));
                            } else {
                                logger.error("byxy aoi is null. url - {}, resp - {}", url, result);
                            }
                        } else {
                            logger.error("byxy data is null. url - {}, resp - {}", url, result);
                        }
                    } else {
                        logger.error("byxy result is null. url - {}, resp - {}", url, result);
                    }
                } else {
                    logger.error("byxy status = 1. url - {}, resp - {}", url, result);
                }
            }
        } catch (Exception e) {
            logger.error("request byxy error. url: {}, e: {}", url, e);
        }
        return ai;
    }

    public static String getAoiNameAndType(String aoi, String ak, String opt) {
        String url = null;
        String result = "";
        try {
            url = String.format(HttpConstant.HTTP_URL_AOI_NAME_TYPE, aoi, ak, opt);
            result = HttpInvokeUtil.sendGet(url);
        } catch (Exception e) {
            logger.error("request byxy error. url: {}, e: {}", url, e);
        }
        return result;
    }

    public static String updateAddrAoiId(String cityCode, String addressId, String aoiid, String operSource, String operUserName) {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cityCode", cityCode);
        jsonObject.put("addressId", addressId);
        jsonObject.put("aoiId", aoiid);
        jsonObject.put("operSource", operSource);
        jsonObject.put("operUserName", operUserName);
        logger.error("jsonObject:{}", jsonObject.toJSONString());
        String result = "";
        try {
            result = HttpInvokeUtil.sendPost(HttpConstant.HTTP_URL_UPDATEADDRAOIID, jsonObject.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
        } catch (Exception e) {
            logger.error("request error. url: {}, e: {}", HttpConstant.HTTP_URL_UPDATEADDRAOIID, e);
        }
        return result;
    }
}
