package com.sf.gis.java.base.constant;

/**
 * 通过配置文件获取
 * @author 01370539 Created on May.27 2021
 */
public class HttpConstant {
    public static String AC_LIMIT_CODE="109,110,111,112";

    /************************************************ 生产环境接口 ************************************************/

    // 根据坐标获取AOI的http请求路径，杨俊(01374035)提供
    public static String HTTP_URL_GETCOORAOI="http://sds-core-datarun.int.sfcloud.local/datarun/track/getCoorAoiByDist?dist=%s&lng=%s&lat=%s";

    // 获取坐标到AOI边界的距离，杨俊(01374035)提供
    public static String HTTP_URL_GETCOORAOIDIST="http://sds-core-datarun.int.sfcloud.local/datarun/aoi/getCoorAoiDist?aoiId=%s&x=%s&y=%s&type=side";

    // 获取AOI之间的距离，杨俊(01374035)提供
    public static String HTTP_URL_GETAOITOAOIDIST="http://sds-core-datarun.int.sfcloud.local/datarun/aoi/getAoiToAoiDist?aoiIdOne=%s&aoiIdTwo=%s";

    // 根据坐标获取aoi区域，杨俊(01374035)提供
    public static String HTTP_URL_GETAOIAREABYPOINT="http://sds-core-datarun.int.sfcloud.local/datarun/aoi/getAoiAreaByPoint?x=%s&y=%s";

    // 根据坐标获取AOIID，杨俊(01374035)提供
    public static String HTTP_URL_GETAOIIDBYPOINT="http://sds-core-datarun.int.sfcloud.local/datarun/aoi/getAoiIdByPoint?x=%s&y=%s";

    // 获取地址分词
    public static String HTTP_URL_SPLIT="http://gis-int.int.sfdc.com.cn:1080/split/api?ak=%s&citycode=%s&address=%s";

    // 根据地址获取图商坐标
    public static String HTTP_URL_GEO="http://gis-int2.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=%s&city=%s&address=%s";

    // 根据坐标获取对应的aoi信息
    public static String HTTP_URL_DEPT2_BYXY_HAVEOPT ="http://gis-apis.int.sfcloud.local:1080/dept2/byxy?ak=%s&opt=%s&x=%s&y=%s";

    // 根据坐标获取对应的aoi信息
    public static String HTTP_URL_DEPT2_BYXY_NOOPT ="http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy?ak=%s&x=%s&y=%s";

    // 地址拆分服务
    public static String HTTP_URL_SEG_API_SPLIT ="http://gis-int.int.sfdc.com.cn:1080/seg/api/split?ak=%s&opt=%s&province=%s&city=%s&county=%s&address=%s";

    // 丰网点落面接口
    public static String HTTP_URL_EFSMS_CHECKSDEPOTDATA="http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=fns&ak=%s&lng=%s&lat=%s";

    // 丰网模型识别接口
    public static String HTTP_URL_ZC="http://gis-ass-mls-aoi.int.sfcloud.local:1080/zc?cuted=0&citycode=%s&address=%s";

    // 派件服务
    public static String HTTP_URL_ATDISPATCH_API="http://gis-apis.int.sfcloud.local:1080/atdispatch/api?ak=%s&opt=%s&city=%s&address=%s&tel=%s&company=%s";

    //map坐标获取
    public static String HTTP_URL_MAPB="http://gis-apis.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=%s&company=";

    //aoi获取网点
    public static String HTTP_URL_ZC_BY_AOI =  "http://gis-ass-dqs.sf-express.com/emap/api/efs/getEfsBusiFeatureByAois?aoiId=%s&layerAbbr=FNSFIRST";

    //丰网服务
    public static String HTTP_URL_RLS_FNSROUTELABEL =  "http://gis-int.int.sfdc.com.cn:1080/rlsfns/api/fnsRouteLabel";

    public static String HTTP_URL_GROUP =  "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressId=%s";

    public static String HTTP_URL_NORMAL = "http://gis-apis.int.sfcloud.local:1080/atdispatch/api/normal?address=%s&city=%s&ak=%s&opt=%s";

    //地址相似度
    public static String HTTP_URL_ADDR_SIMILARITY = "http://gis-apis.int.sfcloud.local:1080/rdsks/api/getSimilar?ak=%s&beforeAddress=%s&afterAddress=%s";

    public static String HTTP_URL_RDSKS_API_GETTEAM = "http://gis-apis.int.sfcloud.local:1080/rdsks/api/getTeam?ak=%s&city=%s&address=%s&dept=%s";

    public static String HTTP_URL_AOI_NAME_TYPE = "http://gis-apis.int.sfcloud.local:1080/dept2/zctc/aoiid?aoi_id=%s&ak=%s&opt=%s";

    public static String HTTP_URL_UPDATEADDRAOIID = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId";

    public static String HTTP_URL_DELETERGSBADDR = "http://gis-cms-bg.sf-express.com/cms/api/address/deleteRgsbAddr";

    public static String HTTP_URL_PUSHCHKNWRONGAOITASK = "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushChknWrongAoiTask";

    public static String HTTP_URL_PUSHNORMHISTASK = "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushNormHisTask";

    public static String HTTP_URL_EXPORTQUERY = "http://gis-aos-cgcs.sf-express.com/audit/api/exportQuery/norm";

    public static String HTTP_URL_RGSBADD = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd";

    // 经纬度查询行政区域
    public static String HTTP_URL_QUERYBATCHADCODE="http://gis-int.int.sfdc.com.cn:1080/adcode/api/querybatchadcode?opt=GetBatchAdcode&cc=1&xy=%s&ak=%s";

    public static String HTTP_URL_QUERYFWWAYBILL="http://gis-ass-aos.sf-express.com:1080/api/queryFwWaybill?waybillNo=%s";

    public static String HTTP_URL_SEG_ERRADDRESS="http://seg.sf-express.com/erraddress/ErrorAddressCollect/errorAddressByManualOperation";

    public static String HTTP_URL_ATCONSIGNEE_TEAM_BYADDR="http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?needAoiArea=1&callDispatch=1&isNotUnderCall=1&ak=%s&province=%s&city=%s&cityName=%s&district=%s&address=%s&tel=%s&mobile=%s&company=%s&contacts=%s&customerAccount=%s";

    public static String HTTP_URL_AR_API = "http://gis-int.int.sfdc.com.cn:1080/ar/api?address=%s&datatype=r01&ak=%s";

    public static String HTTP_URL_CHKQUERY_TC_TEAMCODE = "http://gis-int.int.sfdc.com.cn:1080/chkquery/tc/teamCode";


    /************************************************ RUNDATA 环境接口 ************************************************/
    public static String HTTP_URL_RUNDATA_ATDISPATCH_API = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?city=%s&address=%s&ak=%s&opt=%s";
    //容灾环境AT派微服务规范化接口
    public static String HTTP_URL_ATDISPATCH_NORMAL="http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api/normal?ak=%s&opt=%s&city=%s&address=%s";
}
