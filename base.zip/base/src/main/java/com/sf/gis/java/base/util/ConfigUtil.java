package com.sf.gis.java.base.util;

import java.io.*;
import java.lang.reflect.Field;
import java.util.*;

import com.csvreader.CsvReader;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 配置文件处理工具类
 *
 * @author 01370539 Created On: Apr.13, 2021
 */
public class ConfigUtil {
    private static final Logger logger = LoggerFactory.getLogger(ConfigUtil.class);

    /**
     * Load Properties
     *
     * @param fileName property file name
     * @return config info
     */
    public static Properties loadPropertiesConfiguration(String fileName) {
        Properties prpts = null;
        try (InputStream in = ConfigUtil.class.getResourceAsStream(File.separator + "conf/" + fileName)) {
            prpts = new Properties();
            prpts.load(in);
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return prpts;
    }

    /**
     * 读取配置文件，配置文件需放在conf目录
     *
     * @param fileName 文件名称
     * @return config file stream
     */
    public static InputStream getConfStream(String fileName) {
        return ConfigUtil.class.getResourceAsStream(File.separator + "conf/" + fileName);
    }

    /**
     * 读取sql文件
     *
     * @param fileName，sql文件需放在sql目录
     * @return sql file stream
     */
    public static InputStream getSqlStream(String fileName) {
        return ConfigUtil.class.getResourceAsStream(File.separator + "sql/" + fileName);
    }

    /**
     * 读取配置文件信息，并映射到常量类中
     *
     * @param confName 配置文件名称，配置文件需要放在conf目录下
     * @param clz      需要映射的类
     */
    public static void loadPropertiesConfiguration(String confName, Class<?> clz) {
        loadConfiguration(confName, clz);
    }

    private static void loadConfiguration(String file, Class<?> configurationClass) {
        try {
            Properties properties = loadPropertiesConfiguration(file);
            setProperties(properties, configurationClass);
        } catch (Exception e) {
            logger.error("Error occur when load configuration file!", e);
        }
    }

    private static void setProperties(Map<Object, Object> valueMap, Class<?> configurationClass) {
        for (Object key : valueMap.keySet()) {
            Object value = valueMap.get(key);
            setPropertie(String.valueOf(key), String.valueOf(value), configurationClass);
        }
    }

    private static void setPropertie(String key, String value, Class<?> _class) {
        try {
            Field field = _class.getDeclaredField(key);
            switch (field.getType().getName()) {
                case FixedConstant.CLASS_TYPE_INT:
                    int intValue = Integer.parseInt(value);
                    field.setInt(null, intValue);
                    break;
                case FixedConstant.CLASS_TYPE_FLOAT:
                    float floatValue = Float.parseFloat(value);
                    field.setFloat(null, floatValue);
                    break;
                case FixedConstant.CLASS_TYPE_STRING:
                    field.set(null, value);
                    break;
                case FixedConstant.CLASS_TYPE_BOOLEAN:
                    boolean booleanValue = Boolean.parseBoolean(value);
                    field.set(null, booleanValue);
                    break;
                case FixedConstant.CLASS_TYPE_DATE:
                    Date dataValue = DateUtil.getDateFromStr(value);
                    if (dataValue != null) {
                        field.set(null, dataValue);
                    }
                    break;
            }
        } catch (Exception e) {
            logger.error("There is no field named:" + key + " in class:" + _class.getSimpleName(), e);
        }
    }

    public static Map<String, String> parserConfig(String filePath) throws IOException {
        Map<String, String> configMap;
        Properties prop = new Properties();
        try (InputStreamReader isr = new InputStreamReader(new FileInputStream(filePath), "UTF-8");
             BufferedReader bufferedReader = new BufferedReader(isr);) {
            prop.load(bufferedReader);
            configMap = new HashMap<>();
            for (Object key : prop.keySet()) {
                configMap.put((String) key, prop.getProperty((String) key));
            }
        }
        return configMap;
    }

    public static Map<String, String> loadDistrictTownMap(String filename, String key, String value1, String value2, String charset) {
        Map<String, String> map = new HashMap<>();
        try (InputStreamReader in = new InputStreamReader(ConfigUtil.class.getResourceAsStream(File.separator + "conf/" + filename), charset)) {
            CsvReader csvReader = new CsvReader(in, ',');
            csvReader.setSafetySwitch(false);
            csvReader.readHeaders();
            while (csvReader.readRecord()) {
                map.put(csvReader.get(key), csvReader.get(value1) + "," + csvReader.get(value2));
            }
            csvReader.close();
            logger.error("district map size {}", map.size());
        } catch (Exception e) {
            logger.error("load district error.", e);
        }
        return map;
    }

    public static Map<String, Integer> loadDistrictMap(String filename, String key, String value, String charset) {
        Map<String, Integer> map = new HashMap<>();
        try (InputStreamReader in = new InputStreamReader(ConfigUtil.class.getResourceAsStream(File.separator + "conf/" + filename), charset)) {
            CsvReader csvReader = new CsvReader(in, ',');
            csvReader.setSafetySwitch(false);
            csvReader.readHeaders();
            while (csvReader.readRecord()) {
                map.put(csvReader.get(key), StringUtils.isNotEmpty(csvReader.get(value)) ? Integer.parseInt(csvReader.get(value)) : 0);
            }
            csvReader.close();
            logger.error("xzqh_pcct map size {}", map.size());
        } catch (Exception e) {
            logger.error("load xzqh_pcct error.", e);
        }
        return map;
    }

    public static List<String> loadFileByConf(String fileName, String charset) {
        List<String> list = new ArrayList<>();
        System.out.println(System.getProperty("user.dir") + "/src/main/resource/conf/" + fileName);
        try (InputStreamReader in = new InputStreamReader(new FileInputStream(System.getProperty("user.dir") + "/src/main/resource/conf/" + fileName), charset)) {
            BufferedReader br = new BufferedReader(in);
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
            br.close();
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return list;
    }

    public static List<String> loadFileByConfNew(String fileName, String charset) {
        List<String> list = new ArrayList<>();
        try (InputStreamReader in = new InputStreamReader(new FileInputStream(System.getProperty("user.dir") + "/conf/" + fileName), charset)) {
            BufferedReader br = new BufferedReader(in);
            String line;
            br.readLine();
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
            br.close();
        } catch (Exception e) {
            logger.error("load properties {} error. ", fileName, e);
        }
        return list;
    }
}
