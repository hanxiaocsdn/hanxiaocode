package com.sf.gis.java.base.dto;

public class ChkQueryTcTeamCodeOut {
    private String sysOrderNo;
    private String address;
    private String cityCode;
    private String deptCode;
    private String teamCode;
    private String aoiId;
    private String aoiCode;
    private String aoiAreaCode;
    private String aoiUnit;
    private String addressKeyword;
    private String lpTransCode;
    private String aoiTypeCode;
    private String virMapArea;
    private String virMapAreaMode;
    private String virMapDept;
    private String virMapCustMark;
    private String aoiAreaGroup;
    private String deptGroup;
    private String innerMark;
    private String villageCode;
    private String villageClassCode;
    private String villageFlag;
    private String villageTownDist;
    private String originDept;
    private String aoiAreaGroupPf;
    private String poiIds;
    private String poiLevel;
    private String appliedAoiId;
    private String appliedAoiCode;
    private String appliedAoiTypeCode;
    private String appliedAoiInfo;
    private String rs;

    public String getSysOrderNo() {
        return sysOrderNo;
    }

    public void setSysOrderNo(String sysOrderNo) {
        this.sysOrderNo = sysOrderNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getTeamCode() {
        return teamCode;
    }

    public void setTeamCode(String teamCode) {
        this.teamCode = teamCode;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoiAreaCode() {
        return aoiAreaCode;
    }

    public void setAoiAreaCode(String aoiAreaCode) {
        this.aoiAreaCode = aoiAreaCode;
    }

    public String getAoiUnit() {
        return aoiUnit;
    }

    public void setAoiUnit(String aoiUnit) {
        this.aoiUnit = aoiUnit;
    }

    public String getAddressKeyword() {
        return addressKeyword;
    }

    public void setAddressKeyword(String addressKeyword) {
        this.addressKeyword = addressKeyword;
    }

    public String getLpTransCode() {
        return lpTransCode;
    }

    public void setLpTransCode(String lpTransCode) {
        this.lpTransCode = lpTransCode;
    }

    public String getAoiTypeCode() {
        return aoiTypeCode;
    }

    public void setAoiTypeCode(String aoiTypeCode) {
        this.aoiTypeCode = aoiTypeCode;
    }

    public String getVirMapArea() {
        return virMapArea;
    }

    public void setVirMapArea(String virMapArea) {
        this.virMapArea = virMapArea;
    }

    public String getVirMapAreaMode() {
        return virMapAreaMode;
    }

    public void setVirMapAreaMode(String virMapAreaMode) {
        this.virMapAreaMode = virMapAreaMode;
    }

    public String getVirMapDept() {
        return virMapDept;
    }

    public void setVirMapDept(String virMapDept) {
        this.virMapDept = virMapDept;
    }

    public String getVirMapCustMark() {
        return virMapCustMark;
    }

    public void setVirMapCustMark(String virMapCustMark) {
        this.virMapCustMark = virMapCustMark;
    }

    public String getAoiAreaGroup() {
        return aoiAreaGroup;
    }

    public void setAoiAreaGroup(String aoiAreaGroup) {
        this.aoiAreaGroup = aoiAreaGroup;
    }

    public String getDeptGroup() {
        return deptGroup;
    }

    public void setDeptGroup(String deptGroup) {
        this.deptGroup = deptGroup;
    }

    public String getInnerMark() {
        return innerMark;
    }

    public void setInnerMark(String innerMark) {
        this.innerMark = innerMark;
    }

    public String getVillageCode() {
        return villageCode;
    }

    public void setVillageCode(String villageCode) {
        this.villageCode = villageCode;
    }

    public String getVillageClassCode() {
        return villageClassCode;
    }

    public void setVillageClassCode(String villageClassCode) {
        this.villageClassCode = villageClassCode;
    }

    public String getVillageFlag() {
        return villageFlag;
    }

    public void setVillageFlag(String villageFlag) {
        this.villageFlag = villageFlag;
    }

    public String getVillageTownDist() {
        return villageTownDist;
    }

    public void setVillageTownDist(String villageTownDist) {
        this.villageTownDist = villageTownDist;
    }

    public String getOriginDept() {
        return originDept;
    }

    public void setOriginDept(String originDept) {
        this.originDept = originDept;
    }

    public String getAoiAreaGroupPf() {
        return aoiAreaGroupPf;
    }

    public void setAoiAreaGroupPf(String aoiAreaGroupPf) {
        this.aoiAreaGroupPf = aoiAreaGroupPf;
    }

    public String getPoiIds() {
        return poiIds;
    }

    public void setPoiIds(String poiIds) {
        this.poiIds = poiIds;
    }

    public String getPoiLevel() {
        return poiLevel;
    }

    public void setPoiLevel(String poiLevel) {
        this.poiLevel = poiLevel;
    }

    public String getAppliedAoiId() {
        return appliedAoiId;
    }

    public void setAppliedAoiId(String appliedAoiId) {
        this.appliedAoiId = appliedAoiId;
    }

    public String getAppliedAoiCode() {
        return appliedAoiCode;
    }

    public void setAppliedAoiCode(String appliedAoiCode) {
        this.appliedAoiCode = appliedAoiCode;
    }

    public String getAppliedAoiTypeCode() {
        return appliedAoiTypeCode;
    }

    public void setAppliedAoiTypeCode(String appliedAoiTypeCode) {
        this.appliedAoiTypeCode = appliedAoiTypeCode;
    }

    public String getAppliedAoiInfo() {
        return appliedAoiInfo;
    }

    public void setAppliedAoiInfo(String appliedAoiInfo) {
        this.appliedAoiInfo = appliedAoiInfo;
    }

    public String getRs() {
        return rs;
    }

    public void setRs(String rs) {
        this.rs = rs;
    }

    @Override
    public String toString() {
        return "ChkQueryTcTeamCodeOut{" +
                "sysOrderNo='" + sysOrderNo + '\'' +
                ", address='" + address + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", deptCode='" + deptCode + '\'' +
                ", teamCode='" + teamCode + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiCode='" + aoiCode + '\'' +
                ", aoiAreaCode='" + aoiAreaCode + '\'' +
                ", aoiUnit='" + aoiUnit + '\'' +
                ", addressKeyword='" + addressKeyword + '\'' +
                ", lpTransCode='" + lpTransCode + '\'' +
                ", aoiTypeCode='" + aoiTypeCode + '\'' +
                ", virMapArea='" + virMapArea + '\'' +
                ", virMapAreaMode='" + virMapAreaMode + '\'' +
                ", virMapDept='" + virMapDept + '\'' +
                ", virMapCustMark='" + virMapCustMark + '\'' +
                ", aoiAreaGroup='" + aoiAreaGroup + '\'' +
                ", deptGroup='" + deptGroup + '\'' +
                ", innerMark='" + innerMark + '\'' +
                ", villageCode='" + villageCode + '\'' +
                ", villageClassCode='" + villageClassCode + '\'' +
                ", villageFlag='" + villageFlag + '\'' +
                ", villageTownDist='" + villageTownDist + '\'' +
                ", originDept='" + originDept + '\'' +
                ", aoiAreaGroupPf='" + aoiAreaGroupPf + '\'' +
                ", poiIds='" + poiIds + '\'' +
                ", poiLevel='" + poiLevel + '\'' +
                ", appliedAoiId='" + appliedAoiId + '\'' +
                ", appliedAoiCode='" + appliedAoiCode + '\'' +
                ", appliedAoiTypeCode='" + appliedAoiTypeCode + '\'' +
                ", appliedAoiInfo='" + appliedAoiInfo + '\'' +
                ", rs='" + rs + '\'' +
                '}';
    }
}
