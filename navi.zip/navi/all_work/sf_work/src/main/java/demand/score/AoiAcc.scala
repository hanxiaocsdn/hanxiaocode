package demand.score

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import demand.utils._
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

object AoiAcc {
  val appName:String = this.getClass.getSimpleName.replace("$","")
  val logger:Logger = Logger.getLogger(appName)
  val format = FastDateFormat.getInstance("yyyyMMdd")
  var partition = 20
  var run_flag = true

  type Data = (SparkSession,String)=>RDD[JSONObject]

  def main(args: Array[String]): Unit = {
    val date = args(0)
    val mode = args(1)
    if(!StringUtils.isEmpty(mode) && "http,compute".split(",").contains(mode)){
      val spark = SparkUtil.getSparkSession(appName)
      var dataF:Data = null
      var table = ""
      var structs:Array[String] = null
      var keys:Array[String] = null

      mode match {
        case "http" =>
          partition = 20
          table = "aoi_accuracy_http_result"
          dataF = getData1
          structs = Array("req_address","citycode","finalzc","aoisrc","finalaoiid","finalaoicode","tag1","tag2","r_aoi","gj_aoiid_t","gj_aoicode_t","gj_aoiname_t","aoi_id_54","aoi_code_54","aoi_name_54","gd_aoiid","gd_aoicode","gd_aoiname","mapa_aoiid","mapa_aoicode","mapa_aoiname","tc_aoiid","tc_aoicode","tc_aoiname","bd_aoiid","bd_aoicode","bd_aoiname","key_word","aoiid_dispatch_chkn","aoicode_dispatch_chkn","aoiid_dispatch_norm","aoicode_dispatch_norm","gd_xcoord","gd_ycoord","tc_xcoord","tc_ycoord","bd_xcoord","bd_ycoord","groupid","freq")
          keys = structs
        case "compute" =>
          partition = 10
          table = "aoi_accuracy_compute_result"
          dataF = getData2
          structs = Array("req_address","citycode","finalzc","aoisrc","finalaoiid","finalaoicode","tag1","tag2","r_aoi","gj_aoiid_t","gj_aoicode_t","gj_aoiname_t","aoi_id_54","aoi_code_54","aoi_name_54","gd_aoiid","gd_aoicode","gd_aoiname","mapa_aoiid","mapa_aoicode","mapa_aoiname","tc_aoiid","tc_aoicode","tc_aoiname","bd_aoiid","bd_aoicode","bd_aoiname","key_word","aoiid_dispatch_chkn","aoicode_dispatch_chkn","aoiid_dispatch_norm","aoicode_dispatch_norm","gd_xcoord","gd_ycoord","tc_xcoord","tc_ycoord","bd_xcoord","bd_ycoord","raois1","raois2","raoiss","raois3","is_aoiright","src_rightaoi","aoiid_right","aoicode_right","result_flag","groupid","freq")
          keys = structs
      }

      logger.error(">>>处理类型：" + mode)
      logger.error(">>>处理日期：" + date)
      Stat(spark, dataF, table, structs, keys, date)

      spark.stop()
      logger.error(">>>处理完毕---------------")
    }
  }


  def Stat(spark:SparkSession, getData:(SparkSession,String)=>RDD[JSONObject], table:String, structs:Array[String], keys:Array[String], date:String): Unit = {
    val resultRdd = getData(spark, date)

    filterRddToHive(spark,resultRdd,table,structs,keys,date)
    resultRdd.unpersist()
  }


  def getData1(spark:SparkSession, date:String):RDD[JSONObject] ={
    var sql=""
    sql =
      s"""
         |select req_address,groupid,get_json_object(extra, '$$.citycode') as citycode,finalzc,get_json_object(extra, '$$.aoisrc') as aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,54_aoi_id as aoi_id_54,54_aoi_code as aoi_code_54,54_aoi_name as aoi_name_54,(case when gd_aoiid is not null and gd_aoiid <> '' then gd_aoiid else get_json_object(tsaoibody, '$$.gd_aoiid') end) as gd_aoiid,(case when gd_aoicode is not null and gd_aoicode <> '' then gd_aoicode else get_json_object(tsaoibody, '$$.gd_aoicode') end) as gd_aoicode,(case when gd_aoiname is not null and gd_aoiname <> '' then gd_aoiname else get_json_object(tsaoibody, '$$.gd_aoiname') end) as gd_aoiname,(case when mapa_aoiid is not null and mapa_aoiid <> '' then mapa_aoiid else get_json_object(tsaoibody, '$$.mapa_aoiid') end) as mapa_aoiid,(case when mapa_aoicode is not null and mapa_aoicode <> '' then mapa_aoicode else get_json_object(tsaoibody, '$$.mapa_aoicode') end) as mapa_aoicode,(case when mapa_aoiname is not null and mapa_aoiname <> '' then mapa_aoiname else get_json_object(tsaoibody, '$$.mapa_aoiname')end) as mapa_aoiname,get_json_object(tsaoibody, '$$.tc_aoiid') as tc_aoiid,get_json_object(tsaoibody, '$$.tc_aoicode') as tc_aoicode,get_json_object(tsaoibody, '$$.tc_aoiname') as tc_aoiname,get_json_object(tsaoibody, '$$.bd_aoiid') as bd_aoiid,get_json_object(tsaoibody, '$$.bd_aoicode') as bd_aoicode,get_json_object(tsaoibody, '$$.bd_aoiname') as bd_aoiname,key_word from dm_gis.aoi_accuracy_54_aoiname_ret_bsp where inc_day='$date' and tag1='wrong' and get_json_object(extra, '$$.aoisrc') in ('chk','dispatch-chkn')
       """.stripMargin
    val logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd.map(json=>{
      var key = ""
      if(json!=null){
        key = json.toJSONString
      }
      (key,json)
    })
      .groupByKey()
      .map(obj=>{
        val list = obj._2.toList
        val freq = list.size
        val json = obj._2.toList.head
        json.put("freq",freq)
        json
      })
      .map(json=>{
        var req_address = ""
        var citycode = ""
        if(json!=null){
          req_address = json.getString("req_address")
          citycode = json.getString("citycode")
          if(StringUtils.isEmpty(req_address)) req_address = ""
          if(StringUtils.isEmpty(citycode)) citycode = ""
        }
        ((req_address,citycode), json)
      })
      .groupByKey()
      .flatMap(obj=>{
        val list = new ArrayBuffer[JSONObject]()
        val req_address = obj._1._1
        val citycode = obj._1._2
        val jsonList = obj._2.toList

        var aoiid_dispatch_chkn = ""
        var aoicode_dispatch_chkn = ""
        var aoiid_dispatch_norm = ""
        var aoicode_dispatch_norm = ""

        var gd_xcoord = ""
        var gd_ycoord = ""
        var gd_aoiid = ""
        var gd_aoicode = ""
        var gd_aoiname = ""
        var tc_xcoord = ""
        var tc_ycoord = ""
        var tc_aoiid = ""
        var tc_aoicode = ""
        var tc_aoiname = ""
        var bd_xcoord = ""
        var bd_ycoord = ""
        var bd_aoiid = ""
        var bd_aoicode = ""
        var bd_aoiname = ""

        val address = req_address.replaceAll("\n", "").replaceAll("\t", "").replaceAll(" ", "").replaceAll("^", "").replaceAll(" 。", "")
        val resultObject_chkn = atdispatch(address, citycode, "chkn")
        if(resultObject_chkn!=null){
          val resultObject_chkn2 = resultObject_chkn.getJSONObject("result")
          if(resultObject_chkn2!=null){
            val tcs = resultObject_chkn2.getJSONArray("tcs")
            if(tcs!=null && tcs.size()>0){
              val tcs0 = tcs.getJSONObject(0)
              if(tcs0!=null){
                aoiid_dispatch_chkn = tcs0.getString("aoiid")
                aoicode_dispatch_chkn = tcs0.getString("aoicode")
              }
            }
          }
        }

        val resultObject_norm = atdispatch(address, citycode, "norm")
        if(resultObject_norm!=null){
          val resultObject_norm2 = resultObject_norm.getJSONObject("result")
          if(resultObject_norm2!=null){
            val tcs = resultObject_norm2.getJSONArray("tcs")
            if(tcs!=null && tcs.size()>0){
              val tcs0 = tcs.getJSONObject(0)
              if(tcs0!=null){
                aoiid_dispatch_norm = tcs0.getString("aoiid")
                aoicode_dispatch_norm = tcs0.getString("aoicode")
              }
            }
          }
        }

        val resultObject_gd = geo(address, citycode, "gd2")
        if(resultObject_gd!=null){
          val resultObject_gd2 = resultObject_gd.getJSONObject("result")
          if(resultObject_gd2!=null){
            gd_xcoord = resultObject_gd2.getString("xcoord")
            gd_ycoord = resultObject_gd2.getString("ycoord")
            if(!StringUtils.isEmpty(gd_xcoord) && !StringUtils.isEmpty(gd_ycoord)){
              val resultObject_gd_dept = dept2(gd_xcoord,gd_ycoord)
              if(resultObject_gd_dept!=null){
                val resultObject_gd_dept2 = resultObject_gd_dept.getJSONObject("result")
                if(resultObject_gd_dept2!=null){
                  val aoi_data = resultObject_gd_dept2.getJSONArray("aoi_data")
                  if(aoi_data!=null && aoi_data.size()>0){
                    val aoi_data0 = aoi_data.getJSONObject(0)
                    if(aoi_data0!=null){
                      gd_aoiid = aoi_data0.getString("aoi_id")
                      gd_aoicode = aoi_data0.getString("aoi_code")
                      gd_aoiname = aoi_data0.getString("aoi_name")
                    }
                  }
                }
              }
            }
          }
        }

        val resultObject_tc = geo(address, citycode, "tc2")
        if(resultObject_tc!=null){
          val resultObject_tc2 = resultObject_tc.getJSONObject("result")
          if(resultObject_tc2!=null){
            tc_xcoord = resultObject_tc2.getString("xcoord")
            tc_ycoord = resultObject_tc2.getString("ycoord")
            if(!StringUtils.isEmpty(tc_xcoord) && !StringUtils.isEmpty(tc_ycoord)){
              val resultObject_tc_dept = dept2(tc_xcoord,tc_ycoord)
              if(resultObject_tc_dept!=null){
                val resultObject_tc_dept2 = resultObject_tc_dept.getJSONObject("result")
                if(resultObject_tc_dept2!=null){
                  val aoi_data = resultObject_tc_dept2.getJSONArray("aoi_data")
                  if(aoi_data!=null && aoi_data.size()>0){
                    val aoi_data0 = aoi_data.getJSONObject(0)
                    if(aoi_data0!=null){
                      tc_aoiid = aoi_data0.getString("aoi_id")
                      tc_aoicode = aoi_data0.getString("aoi_code")
                      tc_aoiname = aoi_data0.getString("aoi_name")
                    }
                  }
                }
              }
            }
          }
        }

        val resultObject_bd = geo(address, citycode, "bd2")
        if(resultObject_bd!=null){
          val resultObject_bd2 = resultObject_bd.getJSONObject("result")
          if(resultObject_bd2!=null){
            bd_xcoord = resultObject_bd2.getString("xcoord")
            bd_ycoord = resultObject_bd2.getString("ycoord")
            if(!StringUtils.isEmpty(bd_xcoord) && !StringUtils.isEmpty(bd_ycoord)){
              val resultObject_bd_dept = dept2(bd_xcoord,bd_ycoord)
              if(resultObject_bd_dept!=null){
                val resultObject_bd_dept2 = resultObject_bd_dept.getJSONObject("result")
                if(resultObject_bd_dept2!=null){
                  val aoi_data = resultObject_bd_dept2.getJSONArray("aoi_data")
                  if(aoi_data!=null && aoi_data.size()>0){
                    val aoi_data0 = aoi_data.getJSONObject(0)
                    if(aoi_data0!=null){
                      bd_aoiid = aoi_data0.getString("aoi_id")
                      bd_aoicode = aoi_data0.getString("aoi_code")
                      bd_aoiname = aoi_data0.getString("aoi_name")
                    }
                  }
                }
              }
            }
          }
        }

        if(StringUtils.isEmpty(aoiid_dispatch_chkn)) aoiid_dispatch_chkn = ""
        if(StringUtils.isEmpty(aoicode_dispatch_chkn)) aoicode_dispatch_chkn = ""
        if(StringUtils.isEmpty(aoiid_dispatch_norm)) aoiid_dispatch_norm = ""
        if(StringUtils.isEmpty(aoicode_dispatch_norm)) aoicode_dispatch_norm = ""
        if(StringUtils.isEmpty(gd_xcoord)) gd_xcoord = ""
        if(StringUtils.isEmpty(gd_ycoord)) gd_ycoord = ""
        if(StringUtils.isEmpty(gd_aoiid)) gd_aoiid = ""
        if(StringUtils.isEmpty(gd_aoicode)) gd_aoicode = ""
        if(StringUtils.isEmpty(gd_aoiname)) gd_aoiname = ""
        if(StringUtils.isEmpty(tc_xcoord)) tc_xcoord = ""
        if(StringUtils.isEmpty(tc_ycoord)) tc_ycoord = ""
        if(StringUtils.isEmpty(tc_aoiid)) tc_aoiid = ""
        if(StringUtils.isEmpty(tc_aoicode)) tc_aoicode = ""
        if(StringUtils.isEmpty(tc_aoiname)) tc_aoiname = ""
        if(StringUtils.isEmpty(bd_xcoord)) bd_xcoord = ""
        if(StringUtils.isEmpty(bd_ycoord)) bd_ycoord = ""
        if(StringUtils.isEmpty(bd_aoiid)) bd_aoiid = ""
        if(StringUtils.isEmpty(bd_aoicode)) bd_aoicode = ""
        if(StringUtils.isEmpty(bd_aoiname)) bd_aoiname = ""

        if(jsonList.nonEmpty){
          for(i<-jsonList.indices){
            val json = jsonList(i)
            json.put("aoiid_dispatch_chkn", aoiid_dispatch_chkn)
            json.put("aoicode_dispatch_chkn", aoicode_dispatch_chkn)
            json.put("aoiid_dispatch_norm", aoiid_dispatch_norm)
            json.put("aoicode_dispatch_norm", aoicode_dispatch_norm)

            val tag2 = json.getString("tag2")
            if("wrong_f".equalsIgnoreCase(tag2) || "info_notin_gis".equalsIgnoreCase(tag2)){
              json.put("gd_xcoord", gd_xcoord)
              json.put("gd_ycoord", gd_ycoord)
              json.put("gd_aoiid", gd_aoiid)
              json.put("gd_aoicode", gd_aoicode)
              json.put("gd_aoiname", gd_aoiname)
              json.put("tc_xcoord", tc_xcoord)
              json.put("tc_ycoord", tc_ycoord)
              json.put("tc_aoiid", tc_aoiid)
              json.put("tc_aoicode", tc_aoicode)
              json.put("tc_aoiname", tc_aoiname)
              json.put("bd_xcoord", bd_xcoord)
              json.put("bd_ycoord", bd_ycoord)
              json.put("bd_aoiid", bd_aoiid)
              json.put("bd_aoicode", bd_aoicode)
              json.put("bd_aoiname", bd_aoiname)
            }
            list += json
          }
        }
        list
      }).mapPartitions(obj => {

      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val it = obj.next()
        val city_code = JSONUtil.getJsonVal(it,"city_code","")
        val address = JSONUtil.getJsonVal(it,"address","")
        val json : JSONObject = getAddressStandard(url_1,address,city_code)
        val response = JSONUtil.getJsonVal(json,"response","")
        val standard = JSONUtil.getJsonVal(json,"standard","")
        it.put("standard_response",response)
        it.put("standard",standard)
        arrayBuffer.append(it)
      }
      arrayBuffer.iterator
    }).repartition(partition).persist()

    logger.error(">>>日志量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }


  def getData2(spark:SparkSession, date:String):RDD[JSONObject] ={
    var sql2=""
    sql2 =
      s"""
         |select a.key_word,a.finalzc,a.r_aoi,a.city_code,b.flag from
         |(select key_word,finalzc,r_aoi,city_code from dm_gis.aoi_accuracy_correct_res_i_shou where inc_day='$date') a
         |left join
         |(select city_code,aoi_code,'true' as flag from dm_gis.cms_aoi_sch where source='sz' and del_flag<>'1') b
         |on a.city_code=b.city_code and a.r_aoi=aoi_code
       """.stripMargin
    val logRdd2 = getValidJson(spark, sql2)
    val resultRdd2 = logRdd2
      .filter(json=> "true".equalsIgnoreCase(json.getString("flag")))
      .map(json=>{
        var key_word = ""
        var finalzc = ""
        var city_code = ""
        var r_aoi = ""
        if(json!=null){
          key_word = json.getString("key_word")
          finalzc = json.getString("finalzc")
          city_code = json.getString("city_code")
          r_aoi = json.getString("r_aoi")
        }
        if(StringUtils.isEmpty(key_word)) key_word = ""
        if(StringUtils.isEmpty(finalzc)) finalzc = ""
        if(StringUtils.isEmpty(city_code)) city_code = ""
        if(StringUtils.isEmpty(r_aoi)) r_aoi = ""
        ((key_word, finalzc, city_code), r_aoi)
      })
      .groupByKey()
      .map(obj=>{
        var key_word = obj._1._1
        var finalzc = obj._1._2
        var city_code = obj._1._3
        val r_aois = new ArrayBuffer[String]()
        val r_aoiList = obj._2.toList
        if(r_aoiList.nonEmpty){
          for(i<-r_aoiList.indices){
            val r_aoi = r_aoiList(i)
            if(!StringUtils.isEmpty(r_aoi)) r_aois += r_aoi
          }
        }
        val r_aois_set = r_aois.toSet
        val newJson = new JSONObject()
        newJson.put("key_word",key_word)
        newJson.put("finalzc",finalzc)
        newJson.put("city_code",city_code)
        if(r_aois_set!=null && r_aois_set.nonEmpty) newJson.put("r_aois",r_aois_set.mkString("[\"","\",\"","\"]"))
        newJson
      })
      .repartition(6400).persist()

    logger.error(">>>日志量："+resultRdd2.count())
    logRdd2.unpersist()

    var sql1=""
    sql1 =
      s"""
         |select * from dm_gis.aoi_accuracy_http_result where inc_day='$date'
       """.stripMargin
    val logRdd1 = getValidJson(spark, sql1)

    val resultRdd1_grouped1 = logRdd1.map(json=>{
      var key_word = ""
      var finalzc = ""
      var citycode = ""
      if(json!=null){
        key_word = json.getString("key_word")
        finalzc = json.getString("finalzc")
        citycode = json.getString("citycode")
      }
      if(StringUtils.isEmpty(key_word)) key_word = ""
      if(StringUtils.isEmpty(finalzc)) finalzc = ""
      if(StringUtils.isEmpty(citycode)) citycode = ""
      ((key_word,finalzc,citycode), json)
    })
      .groupByKey()

    val resultRdd2_grouped1 = resultRdd2
      .map(json=>{
        var key_word = ""
        var finalzc = ""
        var city_code = ""
        if(json!=null){
          key_word = json.getString("key_word")
          finalzc = json.getString("finalzc")
          city_code = json.getString("city_code")
        }
        if(StringUtils.isEmpty(key_word)) key_word = ""
        if(StringUtils.isEmpty(finalzc)) finalzc = ""
        if(StringUtils.isEmpty(city_code)) city_code = ""
        ((key_word,finalzc,city_code), json)
      })
      .filter(obj => !StringUtils.isEmpty(obj._1._1) && !StringUtils.isEmpty(obj._1._2) && !StringUtils.isEmpty(obj._1._3))
      .groupByKey()

    val resultRdd_grouped1 = resultRdd1_grouped1.leftOuterJoin(resultRdd2_grouped1)
      .flatMap(obj=>{
        val list = new ArrayBuffer[JSONObject]()
        var jsonList = obj._2._1.toList
        var jsonList2:scala.List[JSONObject] = null
        if(obj._2._2.nonEmpty) jsonList2 = obj._2._2.get.toList
        var r_aois:JSONArray = null
        if(jsonList2!=null && jsonList2.nonEmpty){
          val json = jsonList2.head
          if(json!=null){
            r_aois = json.getJSONArray("r_aois")
          }
        }
        if(jsonList!=null && jsonList.nonEmpty){
          for(i<-jsonList.indices){
            val json = jsonList(i)
            if(json!=null){
              if(r_aois!=null && r_aois.size()>0) json.put("raois1", r_aois)
              list += json
            }
          }
        }
        list
      })
      .map(json=>{
        var key_word = ""
        var finalaoicode = ""
        var city_code = ""
        if(json!=null){
          key_word = json.getString("key_word")
          finalaoicode = json.getString("finalaoicode")
          city_code = json.getString("citycode")
        }
        if(StringUtils.isEmpty(key_word)) key_word = ""
        if(StringUtils.isEmpty(finalaoicode)) finalaoicode = ""
        else finalaoicode = finalaoicode.substring(0, finalaoicode.length - 6)
        if(StringUtils.isEmpty(city_code)) city_code = ""
        ((key_word,finalaoicode,city_code), json)
      })
      .groupByKey()

    val resultRdd_grouped2 = resultRdd_grouped1.leftOuterJoin(resultRdd2_grouped1)
      .flatMap(obj=>{
        val finalaoicode = obj._1._2
        val list = new ArrayBuffer[JSONObject]()
        var jsonList = obj._2._1.toList
        var jsonList2:scala.List[JSONObject] = null
        if(obj._2._2.nonEmpty) jsonList2 = obj._2._2.get.toList
        var r_aois:JSONArray = null
        if(jsonList2!=null && jsonList2.nonEmpty){
          val json = jsonList2.head
          if(json!=null){
            r_aois = json.getJSONArray("r_aois")
          }
        }
        if(jsonList!=null && jsonList.nonEmpty){
          for(i<-jsonList.indices){
            val json = jsonList(i)
            if(json!=null){
              val finalzc = json.getString("finalzc")
              if(!StringUtils.isEmpty(finalzc) && !finalaoicode.equalsIgnoreCase(finalzc)){
                if(r_aois!=null && r_aois.size()>0) {
                  json.put("raois2", r_aois)
                  val raois_temp = new ArrayBuffer[String]()
                  for(m<-0.until(r_aois.size())){
                    val value = r_aois.getString(m)
                    if(!StringUtils.isEmpty(value)) raois_temp += value
                  }
                  val raois1 = json.getJSONArray("raois1")
                  if(raois1!=null && raois1.size()>0){
                    for(n<-0.until(raois1.size())){
                      val value = raois1.getString(n)
                      if(!StringUtils.isEmpty(value)) raois_temp += value
                    }
                  }
                  val raois_set = raois_temp.toSet
                  if(raois_set!=null && raois_set.nonEmpty) json.put("raoiss", raois_set.mkString("[\"","\",\"","\"]"))
                }
                else json.put("raoiss", json.getString("raois1"))
              }
              else json.put("raoiss", json.getString("raois1"))
              list += json
            }
          }
        }
        list
      })
      .map(json=>{
        var key_word = ""
        var city_code = ""
        if(json!=null){
          key_word = json.getString("key_word")
          city_code = json.getString("citycode")
        }
        if(StringUtils.isEmpty(key_word)) key_word = ""
        if(StringUtils.isEmpty(city_code)) city_code = ""
        ((key_word,city_code), json)
      })
      .groupByKey()

    val resultRdd2_grouped2 = resultRdd2
      .map(json=>{
        var key_word = ""
        var city_code = ""
        if(json!=null){
          key_word = json.getString("key_word")
          city_code = json.getString("city_code")
        }
        if(StringUtils.isEmpty(key_word)) key_word = ""
        if(StringUtils.isEmpty(city_code)) city_code = ""
        ((key_word,city_code), json)
      })
      .filter(obj => !StringUtils.isEmpty(obj._1._1) && !StringUtils.isEmpty(obj._1._2))
      .groupByKey()
      .map(obj=>{
        val key = obj._1
        val newJson = new JSONObject()
        val jsonList = obj._2.toList
        val r_aois = new ArrayBuffer[String]()
        if(jsonList!=null && jsonList.nonEmpty){
          for(i<-jsonList.indices){
            val json = jsonList(i)
            if(json!=null){
              val r_aoisi = json.getJSONArray("r_aois")
              if(r_aoisi!=null && r_aoisi.size()>0){
                for(j<-0.until(r_aoisi.size())){
                  val value = r_aoisi.getString(j)
                  if(!StringUtils.isEmpty(value)) r_aois += value
                }
              }
            }
          }
        }
        val r_aois_set = r_aois.toSet
        if(r_aois_set!=null && r_aois_set.nonEmpty) newJson.put("r_aois", r_aois_set.mkString("[\"","\",\"","\"]"))
        (key,newJson)
      })
      .groupByKey()

    val resultRdd = resultRdd_grouped2.leftOuterJoin(resultRdd2_grouped2)
      .flatMap(obj=>{
        val list = new ArrayBuffer[JSONObject]()
        var jsonList = obj._2._1.toList
        var jsonList2:scala.List[JSONObject] = null
        if(obj._2._2.nonEmpty) jsonList2 = obj._2._2.get.toList
        var r_aois:JSONArray = null
        if(jsonList2!=null && jsonList2.nonEmpty){
          val json = jsonList2.head
          if(json!=null){
            r_aois = json.getJSONArray("r_aois")
          }
        }
        if(jsonList!=null && jsonList.nonEmpty){
          for(i<-jsonList.indices){
            val json = jsonList(i)
            if(json!=null){
              if(r_aois!=null && r_aois.size()>0) json.put("raois3", r_aois)
              list += json
            }
          }
        }
        list
      })
      .map(json=>{
        var is_aoiright = ""
        var src_rightaoi = ""
        var aoiid_right = ""
        var aoicode_right = ""
        if(json!=null){
          val aoisrc = json.getString("aoisrc")
          if("chk".equalsIgnoreCase(aoisrc)){
            if(condition1("aoiid_dispatch_chkn","aoicode_dispatch_chkn",json)){
              is_aoiright = "1"
              src_rightaoi = "delete_s_y1"
              aoiid_right = json.getString("aoiid_dispatch_chkn")
              aoicode_right = json.getString("aoicode_dispatch_chkn")
            }
            else if(condition1("aoiid_dispatch_norm","aoicode_dispatch_norm",json)){
              is_aoiright = "1"
              aoiid_right = json.getString("aoiid_dispatch_norm")
              aoicode_right = json.getString("aoicode_dispatch_norm")
              if(!StringUtils.isEmpty(json.getString("aoiid_dispatch_chkn"))) src_rightaoi = "delete_sp_y1"
              else src_rightaoi = "delete_s_y1"
            }
            else if(condition2("aoiid_dispatch_chkn","aoicode_dispatch_chkn",json)){
              is_aoiright = "1"
              src_rightaoi = "delete_s_y2"
              aoiid_right = json.getString("aoiid_dispatch_chkn")
              aoicode_right = json.getString("aoicode_dispatch_chkn")
            }
            else if(condition2("aoiid_dispatch_norm","aoicode_dispatch_norm",json)){
              is_aoiright = "1"
              aoiid_right = json.getString("aoiid_dispatch_norm")
              aoicode_right = json.getString("aoicode_dispatch_norm")
              if(!StringUtils.isEmpty(json.getString("aoiid_dispatch_chkn"))) src_rightaoi = "delete_sp_y2"
              else src_rightaoi = "delete_s_y2"
            }
            else if(condition3("aoiid_dispatch_chkn","aoicode_dispatch_chkn",json)){
              is_aoiright = "1"
              src_rightaoi = "delete_s_y3"
              aoiid_right = json.getString("aoiid_dispatch_chkn")
              aoicode_right = json.getString("aoicode_dispatch_chkn")
            }
            else if(condition3("aoiid_dispatch_norm","aoicode_dispatch_norm",json)){
              is_aoiright = "1"
              aoiid_right = json.getString("aoiid_dispatch_norm")
              aoicode_right = json.getString("aoicode_dispatch_norm")
              if(!StringUtils.isEmpty(json.getString("aoiid_dispatch_chkn"))) src_rightaoi = "delete_sp_y3"
              else src_rightaoi = "delete_s_y3"
            }
          }
          else if(condition1("aoiid_dispatch_norm","aoicode_dispatch_norm",json)){
            is_aoiright = "1"
            src_rightaoi = "delete_p_y1"
            aoiid_right = json.getString("aoiid_dispatch_norm")
            aoicode_right = json.getString("aoicode_dispatch_norm")
          }
          else if(condition2("aoiid_dispatch_norm","aoicode_dispatch_norm",json)){
            is_aoiright = "1"
            src_rightaoi = "delete_p_y2"
            aoiid_right = json.getString("aoiid_dispatch_norm")
            aoicode_right = json.getString("aoicode_dispatch_norm")
          }
          else if(condition3("aoiid_dispatch_norm","aoicode_dispatch_norm",json)){
            is_aoiright = "1"
            src_rightaoi = "delete_p_y3"
            aoiid_right = json.getString("aoiid_dispatch_norm")
            aoicode_right = json.getString("aoicode_dispatch_norm")
          }
        }
        json.put("is_aoiright", is_aoiright)
        json.put("src_rightaoi", src_rightaoi)
        json.put("aoiid_right", aoiid_right)
        json.put("aoicode_right", aoicode_right)

        json
      })
      .repartition(partition).persist()

    val tmpRdd = resultRdd
      .filter(json=> "1".equalsIgnoreCase(json.getString("is_aoiright")))
      .flatMap(json=>{
        val list = new ArrayBuffer[JSONObject]()
        if(json!=null){
          val src_rightaoi = json.getString("src_rightaoi")
          if(!StringUtils.isEmpty(src_rightaoi) && src_rightaoi.contains("_sp_")){
            val json1 = new JSONObject()
            json1.fluentPutAll(json)
            json1.put("src_rightaoi", src_rightaoi.replaceAll("_sp_", "_s_"))
            val json2 = new JSONObject()
            json2.fluentPutAll(json)
            json2.put("src_rightaoi", src_rightaoi.replaceAll("_sp_", "_p_"))
            list += json1
            list += json2
          }
          else list += json
        }
        list
      })
      .map(json=>{
        var citycode = json.getString("citycode")
        var req_address = json.getString("req_address")
        var src_rightaoi = json.getString("src_rightaoi")
        if(StringUtils.isEmpty(citycode)) citycode = ""
        if(StringUtils.isEmpty(req_address)) req_address = ""
        if(StringUtils.isEmpty(src_rightaoi)) src_rightaoi = ""

        ((citycode, req_address, src_rightaoi),json)
      })
      .groupByKey()
      .map(obj=>{
        var result_flag = ""

        val key = obj._1
        var citycode = key._1
        var req_address = key._2
        var src_rightaoi = key._3
        var json = obj._2.toList.head

        if(run_flag){
//          val address = req_address.replaceAll("\n", "").replaceAll("\t", "").replaceAll(" ", "").replaceAll("^", "").replaceAll(" 。", "")
          val address = req_address
          if(src_rightaoi.contains("_s_")){
            val resultObject = deleteRgsbAddr(citycode, address, "1")
            if(resultObject!=null){
              val success = resultObject.getString("success")
              if("true".equalsIgnoreCase(success)) result_flag = "1"
            }
          }
          if(src_rightaoi.contains("_p_")){
            val resultObject = deleteRgsbAddr(citycode, address, "2")
            if(resultObject!=null){
              val success = resultObject.getString("success")
              if("true".equalsIgnoreCase(success)) result_flag = "2"
            }
          }
          if(src_rightaoi.contains("_sp_")){
            val resultObject1 = deleteRgsbAddr(citycode, address, "1")
            if(resultObject1!=null){
              val success = resultObject1.getString("success")
              if("true".equalsIgnoreCase(success)) result_flag = "1"
            }
            val resultObject2 = deleteRgsbAddr(citycode, address, "2")
            if(resultObject2!=null){
              val success = resultObject2.getString("success")
              if("true".equalsIgnoreCase(success)) result_flag = result_flag + "2"
            }
          }
        }
        json.put("result_flag", result_flag)

        json
      })

    logger.error(">>>日志量："+resultRdd.count())
    logger.error(">>>日志量："+tmpRdd.count())
    resultRdd2.unpersist()
    logRdd1.unpersist()
    tmpRdd.unpersist()
    resultRdd
  }


  def getData3(spark:SparkSession, date:String):RDD[JSONObject] ={
    var sql=""
    sql =
      s"""
         |select * from dm_gis.aoi_accuracy_compute_result where inc_day='$date'
       """.stripMargin
    val logRdd = getValidJson(spark, sql)
    val resultRdd = logRdd.map(json=>{
      var key = ""
      if(json!=null){
        key = json.toJSONString
      }
      (key,json)
    })
      .groupByKey()
      .map(obj=>{
        val list = obj._2.toList
        val freq = list.size
        val json = obj._2.toList.head
        json.put("freq",freq)
        json
      })
      .map(json=>{
        var req_address = ""
        var citycode = ""
        if(json!=null){
          req_address = json.getString("req_address")
          citycode = json.getString("citycode")
          if(StringUtils.isEmpty(req_address)) req_address = ""
          if(StringUtils.isEmpty(citycode)) citycode = ""
        }
        ((req_address,citycode), json)
      })
      .groupByKey()
      .flatMap(obj=>{
        val list = new ArrayBuffer[JSONObject]()
        val req_address = obj._1._1
        val citycode = obj._1._2
        val jsonList = obj._2.toList

        var aoiid_dispatch_chkn = ""
        var aoicode_dispatch_chkn = ""
        var aoiid_dispatch_norm = ""
        var aoicode_dispatch_norm = ""

        var gd_xcoord = ""
        var gd_ycoord = ""
        var gd_aoiid = ""
        var gd_aoicode = ""
        var gd_aoiname = ""
        var tc_xcoord = ""
        var tc_ycoord = ""
        var tc_aoiid = ""
        var tc_aoicode = ""
        var tc_aoiname = ""
        var bd_xcoord = ""
        var bd_ycoord = ""
        var bd_aoiid = ""
        var bd_aoicode = ""
        var bd_aoiname = ""

        val address = req_address.replaceAll("\n", "").replaceAll("\t", "").replaceAll(" ", "").replaceAll("^", "").replaceAll(" 。", "")
        val resultObject_chkn = atdispatch(address, citycode, "chkn")
        if(resultObject_chkn!=null){
          val resultObject_chkn2 = resultObject_chkn.getJSONObject("result")
          if(resultObject_chkn2!=null){
            val tcs = resultObject_chkn2.getJSONArray("tcs")
            if(tcs!=null && tcs.size()>0){
              val tcs0 = tcs.getJSONObject(0)
              if(tcs0!=null){
                aoiid_dispatch_chkn = tcs0.getString("aoiid")
                aoicode_dispatch_chkn = tcs0.getString("aoicode")
              }
            }
          }
        }

        val resultObject_norm = atdispatch(address, citycode, "norm")
        if(resultObject_norm!=null){
          val resultObject_norm2 = resultObject_norm.getJSONObject("result")
          if(resultObject_norm2!=null){
            val tcs = resultObject_norm2.getJSONArray("tcs")
            if(tcs!=null && tcs.size()>0){
              val tcs0 = tcs.getJSONObject(0)
              if(tcs0!=null){
                aoiid_dispatch_norm = tcs0.getString("aoiid")
                aoicode_dispatch_norm = tcs0.getString("aoicode")
              }
            }
          }
        }

        val resultObject_gd = geo(address, citycode, "gd2")
        if(resultObject_gd!=null){
          val resultObject_gd2 = resultObject_gd.getJSONObject("result")
          if(resultObject_gd2!=null){
            gd_xcoord = resultObject_gd2.getString("xcoord")
            gd_ycoord = resultObject_gd2.getString("ycoord")
            if(!StringUtils.isEmpty(gd_xcoord) && !StringUtils.isEmpty(gd_ycoord)){
              val resultObject_gd_dept = dept2(gd_xcoord,gd_ycoord)
              if(resultObject_gd_dept!=null){
                val resultObject_gd_dept2 = resultObject_gd_dept.getJSONObject("result")
                if(resultObject_gd_dept2!=null){
                  val aoi_data = resultObject_gd_dept2.getJSONArray("aoi_data")
                  if(aoi_data!=null && aoi_data.size()>0){
                    val aoi_data0 = aoi_data.getJSONObject(0)
                    if(aoi_data0!=null){
                      gd_aoiid = aoi_data0.getString("aoi_id")
                      gd_aoicode = aoi_data0.getString("aoi_code")
                      gd_aoiname = aoi_data0.getString("aoi_name")
                    }
                  }
                }
              }
            }
          }
        }

        val resultObject_tc = geo(address, citycode, "tc2")
        if(resultObject_tc!=null){
          val resultObject_tc2 = resultObject_tc.getJSONObject("result")
          if(resultObject_tc2!=null){
            tc_xcoord = resultObject_tc2.getString("xcoord")
            tc_ycoord = resultObject_tc2.getString("ycoord")
            if(!StringUtils.isEmpty(tc_xcoord) && !StringUtils.isEmpty(tc_ycoord)){
              val resultObject_tc_dept = dept2(tc_xcoord,tc_ycoord)
              if(resultObject_tc_dept!=null){
                val resultObject_tc_dept2 = resultObject_tc_dept.getJSONObject("result")
                if(resultObject_tc_dept2!=null){
                  val aoi_data = resultObject_tc_dept2.getJSONArray("aoi_data")
                  if(aoi_data!=null && aoi_data.size()>0){
                    val aoi_data0 = aoi_data.getJSONObject(0)
                    if(aoi_data0!=null){
                      tc_aoiid = aoi_data0.getString("aoi_id")
                      tc_aoicode = aoi_data0.getString("aoi_code")
                      tc_aoiname = aoi_data0.getString("aoi_name")
                    }
                  }
                }
              }
            }
          }
        }

        val resultObject_bd = geo(address, citycode, "bd2")
        if(resultObject_bd!=null){
          val resultObject_bd2 = resultObject_bd.getJSONObject("result")
          if(resultObject_bd2!=null){
            bd_xcoord = resultObject_bd2.getString("xcoord")
            bd_ycoord = resultObject_bd2.getString("ycoord")
            if(!StringUtils.isEmpty(bd_xcoord) && !StringUtils.isEmpty(bd_ycoord)){
              val resultObject_bd_dept = dept2(bd_xcoord,bd_ycoord)
              if(resultObject_bd_dept!=null){
                val resultObject_bd_dept2 = resultObject_bd_dept.getJSONObject("result")
                if(resultObject_bd_dept2!=null){
                  val aoi_data = resultObject_bd_dept2.getJSONArray("aoi_data")
                  if(aoi_data!=null && aoi_data.size()>0){
                    val aoi_data0 = aoi_data.getJSONObject(0)
                    if(aoi_data0!=null){
                      bd_aoiid = aoi_data0.getString("aoi_id")
                      bd_aoicode = aoi_data0.getString("aoi_code")
                      bd_aoiname = aoi_data0.getString("aoi_name")
                    }
                  }
                }
              }
            }
          }
        }

        if(StringUtils.isEmpty(aoiid_dispatch_chkn)) aoiid_dispatch_chkn = ""
        if(StringUtils.isEmpty(aoicode_dispatch_chkn)) aoicode_dispatch_chkn = ""
        if(StringUtils.isEmpty(aoiid_dispatch_norm)) aoiid_dispatch_norm = ""
        if(StringUtils.isEmpty(aoicode_dispatch_norm)) aoicode_dispatch_norm = ""
        if(StringUtils.isEmpty(gd_xcoord)) gd_xcoord = ""
        if(StringUtils.isEmpty(gd_ycoord)) gd_ycoord = ""
        if(StringUtils.isEmpty(gd_aoiid)) gd_aoiid = ""
        if(StringUtils.isEmpty(gd_aoicode)) gd_aoicode = ""
        if(StringUtils.isEmpty(gd_aoiname)) gd_aoiname = ""
        if(StringUtils.isEmpty(tc_xcoord)) tc_xcoord = ""
        if(StringUtils.isEmpty(tc_ycoord)) tc_ycoord = ""
        if(StringUtils.isEmpty(tc_aoiid)) tc_aoiid = ""
        if(StringUtils.isEmpty(tc_aoicode)) tc_aoicode = ""
        if(StringUtils.isEmpty(tc_aoiname)) tc_aoiname = ""
        if(StringUtils.isEmpty(bd_xcoord)) bd_xcoord = ""
        if(StringUtils.isEmpty(bd_ycoord)) bd_ycoord = ""
        if(StringUtils.isEmpty(bd_aoiid)) bd_aoiid = ""
        if(StringUtils.isEmpty(bd_aoicode)) bd_aoicode = ""
        if(StringUtils.isEmpty(bd_aoiname)) bd_aoiname = ""

        if(jsonList.nonEmpty){
          for(i<-jsonList.indices){
            val json = jsonList(i)
            json.put("aoiid_dispatch_chkn", aoiid_dispatch_chkn)
            json.put("aoicode_dispatch_chkn", aoicode_dispatch_chkn)
            json.put("aoiid_dispatch_norm", aoiid_dispatch_norm)
            json.put("aoicode_dispatch_norm", aoicode_dispatch_norm)

            val tag2 = json.getString("tag2")
            if("wrong_f".equalsIgnoreCase(tag2) || "info_notin_gis".equalsIgnoreCase(tag2)){
              json.put("gd_xcoord", gd_xcoord)
              json.put("gd_ycoord", gd_ycoord)
              json.put("gd_aoiid", gd_aoiid)
              json.put("gd_aoicode", gd_aoicode)
              json.put("gd_aoiname", gd_aoiname)
              json.put("tc_xcoord", tc_xcoord)
              json.put("tc_ycoord", tc_ycoord)
              json.put("tc_aoiid", tc_aoiid)
              json.put("tc_aoicode", tc_aoicode)
              json.put("tc_aoiname", tc_aoiname)
              json.put("bd_xcoord", bd_xcoord)
              json.put("bd_ycoord", bd_ycoord)
              json.put("bd_aoiid", bd_aoiid)
              json.put("bd_aoicode", bd_aoicode)
              json.put("bd_aoiname", bd_aoiname)
            }
            list += json
          }
        }
        list
      })
      .repartition(partition).persist()

    logger.error(">>>日志量："+resultRdd.count())
    logRdd.unpersist()
    resultRdd
  }




  def getValidJson(spark:SparkSession, sql: String): (RDD[JSONObject])={
    println("sql="+sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.repartition(6400).map(row=>{
      val json = new JSONObject()
      for(i<-fields.indices){
        json.put(header(i),row.get(i))
      }
      json
    }).filter(_!=null).repartition(6400).persist()
    logger.error(">>>日志量："+logRdd.count())
    logRdd
  }


  def filterRddToHive(spark:SparkSession, resultRdd:RDD[JSONObject],table: String, structs:Array[String], keys:Array[String],date:String): Unit ={
    saveJSONObjectRDDToHive(spark,resultRdd,table,structs,keys,date)
  }


  def saveJSONObjectRDDToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs:Array[String], keys:Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    var database = ""
    if(StringUtils.isEmpty(dataBase)) database = "dm_gis"
    else database = dataBase
    logger.error(">>>table=" + database + "." + table)
    spark.sql(s"use $database")
    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    val structType = DataTypes.createStructType(structFileds)
    val rowRdd = resultRdd.filter(_!=null).map(obj => {
      var row: Row = null
      try {
        val v = new Array[String](keys.length)
        for (i <- keys.indices) v(i) = JsonUtil.getJsonVal(obj, keys(i), "")
        row = RowFactory.create(v: _*)
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
      }
      row
    }).filter(_ != null)
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    val tempView = String.format("%s_temp_view", table)
    df.createOrReplaceTempView(tempView)
    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
    logger.error(">>>删除分区：" + deleteSql)
    spark.sql(deleteSql)
    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    logger.error(">>>新建分区：" + createPartitionSql)
    spark.sql(createPartitionSql)
    spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
    logger.error(">>>数据入hive库结束!")
  }




  def atdispatch(address:String, city:String, opt:String): JSONObject ={
    var jsonObject:JSONObject = null
    val url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=87106f6380af4df0845a693eee58843c&opt=%s&address=%s&city=%s"
      .format(opt, address, city)
    breakable(
      for(i<-0.until(5)){
        try {
          jsonObject = HttpClientUtil.getJsonByGet(url)
          logger.error(">>>访问atdispatch：url=" + url + ", json="+jsonObject)
          Thread.sleep(350)
          if(jsonObject!=null){
            val status = jsonObject.getString("status")
            if("0".equalsIgnoreCase(status)) break
            else Thread.sleep(350)
          }
          if(i >= 4) break
        } catch {
          case e:Exception =>logger.error(">>>访问atdispatch异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
        }
      }
    )
    jsonObject
  }


  def geo(address:String, city:String, opt:String): JSONObject ={
    var jsonObject:JSONObject = null
    val url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=87106f6380af4df0845a693eee58843c&opt=%s&address=%s&city=%s"
      .format(opt, address, city)
    breakable(
      for(i<-0.until(5)){
        try {
          jsonObject = HttpClientUtil.getJsonByGet(url)
          logger.error(">>>访问geo：url=" + url + ", json="+jsonObject)
          Thread.sleep(350)
          if(jsonObject!=null){
            val status = jsonObject.getString("status")
            if("0".equalsIgnoreCase(status)) break
            else if("1".equalsIgnoreCase(status) && jsonObject.getJSONObject("result")!=null && jsonObject.getJSONObject("result").getJSONObject("msg")!=null && "USER_DAILY_QUERY_OVER_LIMIT".equalsIgnoreCase(jsonObject.getJSONObject("result").getJSONObject("msg").getString("info"))) break
            else Thread.sleep(350)
          }
          if(i >= 4) break
        } catch {
          case e:Exception =>logger.error(">>>访问geo异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
        }
      }
    )
    jsonObject
  }


  def dept2(x:String, y:String): JSONObject ={
    var jsonObject:JSONObject = null
    /*val url = "http://gis-int.int.sfdc.com.cn:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=c2ee00ecb0164098b58569b5bdffe60d"
      .format(x, y)*/
    val url = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=c2ee00ecb0164098b58569b5bdffe60d"
      .format(x, y)
    breakable(
      for(i<-0.until(5)){
        try {
          jsonObject = HttpClientUtil.getJsonByGet(url)
          logger.error(">>>访问dept2：url=" + url + ", json="+jsonObject)
          Thread.sleep(350)
          if(jsonObject!=null){
            val status = jsonObject.getString("status")
            if("0".equalsIgnoreCase(status)) break
            else Thread.sleep(350)
          }
          if(i >= 4) break
        } catch {
          case e:Exception =>logger.error(">>>访问dept2异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
        }
      }
    )
    jsonObject
  }


  def deleteRgsbAddr(city:String, address:String, _type:String): JSONObject ={
    var jsonObject:JSONObject = null
//    val url = "http://gis-cms-bg.sf-express.com/cms/api/address/deleteRgsbAddr?ak=321&operSource=cms&cityCode=%s&address=%s&type=%s"
//      .format(city, address, _type)
    val url = "http://gis-cms-bg.sf-express.com/cms/api/address/deleteRgsbAddr"
    val json = new JSONObject()
    json.put("ak","3321")
    json.put("operSource","cms")
    val addressDel = new JSONObject()
    addressDel.put("cityCode",city)
    addressDel.put("address",address)
    addressDel.put("type",_type)
    json.put("addressDel",addressDel)

    breakable(
      for(i<-0.until(5)){
        try {
          jsonObject = HttpClientUtil.getJsonByPostJson(url, json.toJSONString)
          logger.error(">>>访问deleteRgsbAddr：url" + i + "=" + url + ", json="+json + ", result="+jsonObject)
          Thread.sleep(6000)
          if(jsonObject!=null){
            val code = jsonObject.getString("code")
            if("0".equalsIgnoreCase(code)) break
            else Thread.sleep(6000)
          }
          if(i >= 4) break
        } catch {
          case e:Exception =>logger.error(">>>访问deleteRgsbAddr：url" + i + "=" + url + ", json="+json + ", result="+jsonObject)
        }
      }
    )
    jsonObject
  }


  def condition1(x:String, y:String, json:JSONObject): Boolean = {
    var flag = false
    val r_aoi = json.getString("r_aoi")
    val gj_aoiid_t = json.getString("gj_aoiid_t")
    val aoi_id_54 = json.getString("aoi_id_54")
    val gd_aoiid = json.getString("gd_aoiid")
    val tc_aoiid = json.getString("tc_aoiid")
    val bd_aoiid = json.getString("bd_aoiid")
    val raoiss = json.getJSONArray("raoiss")
    var x_value = json.getString(x)
    var y_value = json.getString(y)
    if(StringUtils.isEmpty(x_value)) x_value = ""
    if(StringUtils.isEmpty(y_value)) y_value = ""

    if(raoiss!=null && raoiss.size() > 1) return false
    else if(raoiss!=null && raoiss.size() == 1 && !y_value.equalsIgnoreCase(raoiss.getString(0))) return false
    else if(!StringUtils.isEmpty(r_aoi) && (!r_aoi.equalsIgnoreCase(y_value) && !x_value.equalsIgnoreCase(gj_aoiid_t) && !x_value.equalsIgnoreCase(aoi_id_54))) return false
    else{
      val list1 = new ArrayBuffer[String]()
      var flag1 = false
      if(!StringUtils.isEmpty(gd_aoiid)) list1 += gd_aoiid
      if(!StringUtils.isEmpty(tc_aoiid)) list1 += tc_aoiid
      if(!StringUtils.isEmpty(bd_aoiid)) list1 += bd_aoiid
      breakable(
        for(value<-list1){
          if(x_value.equalsIgnoreCase(value) || y_value.equalsIgnoreCase(value)) {
            flag1 = true
            break
          }
        }
      )
      if(flag1){
        var count = 0
        val list2 = new ArrayBuffer[String]()
        if(!StringUtils.isEmpty(r_aoi)) list2 += r_aoi
        if(!StringUtils.isEmpty(gj_aoiid_t)) list2 += gj_aoiid_t
        if(!StringUtils.isEmpty(aoi_id_54)) list2 += aoi_id_54
        val valutList = new ArrayBuffer[String]()
        valutList += x_value
        valutList += y_value
        list1 ++= list2
        breakable(
          for(value1<-valutList){
            breakable(
              for(value<-list1){
                if(value1.equalsIgnoreCase(value)) {
                  count = count + 1
                  if(count>=2){
                    flag = true
                    break
                  }
                }
              }
            )
          }
        )
      }
      else return false
    }
    flag
  }


  def condition2(x:String, y:String, json:JSONObject): Boolean = {
    var flag = false
    val r_aoi = json.getString("r_aoi")
    val gj_aoiid_t = json.getString("gj_aoiid_t")
    val aoi_id_54 = json.getString("aoi_id_54")
    val gd_aoiid = json.getString("gd_aoiid")
    val tc_aoiid = json.getString("tc_aoiid")
    val bd_aoiid = json.getString("bd_aoiid")
    val raois3 = json.getJSONArray("raois3")
    var x_value = json.getString(x)
    var y_value = json.getString(y)
    if(StringUtils.isEmpty(x_value)) x_value = ""
    if(StringUtils.isEmpty(y_value)) y_value = ""

    if(raois3!=null && raois3.size() > 1) return false
    else if(!StringUtils.isEmpty(r_aoi) && (!r_aoi.equalsIgnoreCase(y_value) && !x_value.equalsIgnoreCase(gj_aoiid_t) && !x_value.equalsIgnoreCase(aoi_id_54))) return false
    else{
      val list1 = new ArrayBuffer[String]()
      var flag1 = false
      if(!StringUtils.isEmpty(gd_aoiid)) list1 += gd_aoiid
      if(!StringUtils.isEmpty(tc_aoiid)) list1 += tc_aoiid
      if(!StringUtils.isEmpty(bd_aoiid)) list1 += bd_aoiid
      breakable(
        for(value<-list1){
          if(x_value.equalsIgnoreCase(value)) {
            flag1 = true
            break
          }
        }
      )
      if(flag1){
        var count = 0
        val list2 = new ArrayBuffer[String]()
        if(!StringUtils.isEmpty(gj_aoiid_t)) list2 += gj_aoiid_t
        if(!StringUtils.isEmpty(aoi_id_54)) list2 += aoi_id_54
        val valutList = new ArrayBuffer[String]()
        valutList += x_value
        list1 ++= list2
        breakable(
          for(value1<-valutList){
            breakable(
              for(value<-list1){
                if(value1.equalsIgnoreCase(value)) {
                  count = count + 1
                  if(count>=2){
                    flag = true
                    break
                  }
                }
              }
            )
          }
        )
      }
      else return false
    }
    flag
  }


  def condition3(x:String, y:String, json:JSONObject): Boolean = {
    val r_aoi = json.getString("r_aoi")
    val gj_aoiid_t = json.getString("gj_aoiid_t")
    val aoi_id_54 = json.getString("aoi_id_54")
    val raois3 = json.getJSONArray("raois3")
    var x_value = json.getString(x)
    var y_value = json.getString(y)
    if(StringUtils.isEmpty(x_value)) x_value = ""
    if(StringUtils.isEmpty(y_value)) y_value = ""

    if(raois3==null || raois3.size() != 1 || !y_value.equalsIgnoreCase(raois3.getString(0))) false
    else if(!StringUtils.isEmpty(r_aoi) && (!r_aoi.equalsIgnoreCase(y_value) && !x_value.equalsIgnoreCase(gj_aoiid_t) && !x_value.equalsIgnoreCase(aoi_id_54))) false
    else true
  }


}
