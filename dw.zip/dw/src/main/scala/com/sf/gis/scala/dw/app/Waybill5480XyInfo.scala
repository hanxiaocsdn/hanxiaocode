package com.sf.gis.scala.dw.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil}
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.spark.{Spark, SparkNetNew, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{FileUtil, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/** *
 * 可以优化坐标排重，暂时没做，差不多减少1/3的坐标量，高峰过后需要做起来(20231031)
 * 40000w*0.3
 * 任务id:374591   任务名称：运单5480坐标及信息-跑坐标接口
 */
object Waybill5480XyInfo {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  var calPartitions = 50
  var prop = FileUtil.getFilePropertieRes("waybill_5480_xy_info.properties")
  val dept_2_dept_aoi_ak = prop.getProperty("dept_2_dept_aoi_ak")
  val retTable = "dm_gis.t_gdl_waybill_state_info"
  def readFengyuanData(sparkSession: SparkSession, incDay: String,
                       sgsTableName:String): RDD[JSONObject] = {
    var operatimeColumn = "operatime_new"
    var citycodeColumn = "city_code";
//    if(sgsTableName.equals("ods_kafka_sgs.sgs_exp_core_bizlog_data")){
//      operatimeColumn = "operatime"
//      citycodeColumn="citycodedb"
//    }
    val sql = "select waybill_no,lgt,lat,ac,tm,type,city_code from ( select waybillno waybill_no,eventlng lgt, " +
      s"eventlat lat,eventaccuracy ac,$operatimeColumn tm,if(eventtype='31124','P','S') type,$citycodeColumn city_code,row_number() over(partition BY waybillno,eventtype order by $operatimeColumn desc )" +
      s" as rank from $sgsTableName " +
      s"where inc_day ='$incDay' and eventtype in ('31124','31201') and  eventlng <> '' and eventlng<>'null' and eventlng is not null " +
      s"and eventlat <> ''  and eventlat<>'null' and eventlat is not null ) a where rank=1  "
    logger.error("源数据sql:" + sql)
    val (dataRdd, columns) = SparkRead.readHiveAsJson(sparkSession, sql)
    dataRdd
  }

  def runDept(sparkSession: SparkSession, originDataRdd: RDD[JSONObject],
              runInterFaceFlag:String): RDD[JSONObject] = {
    if("noRunInterface".equals(runInterFaceFlag)){
      logger.error("不跑接口")
      return originDataRdd
    }
    val parllCnt = 125
    val id = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01374443","374591","运单5480坐标及信息-跑坐标接口","用于回挂宽表妥投坐标的aoi和网点信息",CommonUrl.xyToAoiZc,dept_2_dept_aoi_ak,originDataRdd.count(),parllCnt)
//    val deptRdd = SparkNetNew.queryXyToAoiZc(sparkSession, originDataRdd, dept_2_dept_aoi_ak, 150, 100000,
    val deptRdd = SparkNetNew.queryXyToAoiZc(sparkSession, originDataRdd, dept_2_dept_aoi_ak, parllCnt, 150000,
      "lgt", "lat", false)
    BdpTaskRecordUtil.endNetworkInterface("01374443",id)
    originDataRdd.unpersist()
    deptRdd
  }

  def mergeShouPai(deptRdd: RDD[JSONObject]): RDD[JSONObject] = {
    val mergeRdd = deptRdd.map(obj => {
      val dataType = obj.getString("type")
      if (dataType.equals("P")) {
        obj.put("delivery_lgt", obj.getString("lgt"))
        obj.put("delivery_lat", obj.getString("lat"))
        obj.put("delivery_ac", obj.getString("ac"))
        obj.put("delivery_tm", obj.getString("tm"))
        obj.put("delivery_xy_aoiid", obj.getString("xyToAoiZcAoiId"))
        obj.put("delivery_xy_dept", obj.getString("xyToAoiZcZc"))
      } else {
        obj.put("consign_lgt", obj.getString("lgt"))
        obj.put("consign_lat", obj.getString("lat"))
        obj.put("consign_ac", obj.getString("ac"))
        obj.put("consign_tm", obj.getString("tm"))
        obj.put("consign_xy_aoiid", obj.getString("xyToAoiZcAoiId"))
        obj.put("consign_xy_dept", obj.getString("xyToAoiZcZc"))
      }
      obj.remove("lgt")
      obj.remove("lat")
      obj.remove("ac")
      obj.remove("tm")
      obj.remove("xyToAoiZcAoiId")
      obj.remove("xyToAoiZcZc")
      (obj.getString("waybill_no"), obj)
    }).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("收件派件合并后数量:" + mergeRdd.count())
    deptRdd.unpersist()
    mergeRdd
  }

  def saveRdd(sparkSession: SparkSession, retRdd: RDD[JSONObject], incDay: String): Unit = {
    if (retRdd.count() == 0) {
      logger.error("没数据，请检查~~~")
      System.exit(-1)
    }
    val saveColumns = Array("waybill_no", "delivery_lgt", "delivery_lat", "delivery_ac", "delivery_xy_dept",
      "delivery_xy_aoiid", "delivery_tm", "consign_lgt", "consign_lat", "consign_ac", "consign_xy_dept",
      "consign_xy_aoiid", "consign_tm")

    SparkWrite.save2HiveStatic(sparkSession, retRdd, saveColumns, retTable,
      Array(("inc_day", incDay)))
  }

  def saveCacheData(sparkSession: SparkSession, deptRdd: RDD[JSONObject], incDay: String) = {
    val dropIncDay = DateUtil.getDayBefore(incDay, "yyyyMMdd", 7)

    val cacheTable = "dm_gis.t_mid_waybill_state_info_cache"
    logger.error("缓存表：" + cacheTable)
    //    val dropSql = s"alter table $cacheTable drop if exists partition(inc_day='$dropIncDay') "
    //    logger.error(dropSql)
    //    sparkSession.sql(dropSql)
    SparkWrite.save2HiveStaticSingleColumn(sparkSession, deptRdd, cacheTable, Array(("inc_day", incDay)))
  }

  def joinCacheRdd(sparkSession: SparkSession, incDay: String, originDataRdd: RDD[JSONObject],
                   citycodes: Array[String]): (RDD[JSONObject], RDD[JSONObject]) = {
    logger.error("获取缓存数据")
    val sql = s"select log from dm_gis.t_mid_waybill_state_info_cache where inc_day='$incDay' " +
      " and get_json_object(log,'$.xyToAoiZcZc') <> '' and get_json_object(log,'$.xyToAoiZcAoiId') <> '' "
    logger.error(sql)
    val (cacheRdd, columns) = SparkRead.readHiveAsRow(sparkSession, sql)

    val cacheJoinRdd = cacheRdd.map(row => {
      val obj = JSONUtil.parseStr2Json(row.getString(0))
      if (obj != null) {
        val key = Array(obj.getString("waybill_no"), obj.getString("type"),
          obj.getString("lgt"), obj.getString("lat")).mkString("_")
        (key, obj)
      } else {
        (null, null)
      }
    }).filter(obj => obj._1 != null)
    val joinRdd = originDataRdd.map(obj => {
      val key = Array(obj.getString("waybill_no"), obj.getString("type"),
        obj.getString("lgt"), obj.getString("lat")).mkString("_")
      (key, obj)
    }).leftOuterJoin(cacheJoinRdd).map(obj => {
      val left = obj._2._1
      val rightOp = obj._2._2
      if (rightOp.nonEmpty) {
        val right = rightOp.get
        left.put("xyToAoiZcZc", right.getString("xyToAoiZcZc"))
        left.put("xyToAoiZcAoiId", right.getString("xyToAoiZcAoiId"))
        left.put("xyToAoiZcAoiCode", right.getString("xyToAoiZcAoiCode"))
        left.put("xyToAoiZcAoiName", right.getString("xyToAoiZcAoiName"))
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("关联后数量:" + joinRdd.count())
    cacheRdd.unpersist()
    val cityCodesBc = sparkSession.sparkContext.broadcast(citycodes)
    logger.error("临时只跑派件网点信息数据------")
    val cacheDataRdd = joinRdd.filter(obj => {
      obj.containsKey("xyToAoiZcZc") || !cityCodesBc.value.contains(obj.getString("city_code"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val runDeptRdd = joinRdd.filter(obj => !obj.containsKey("xyToAoiZcZc") && cityCodesBc.value.contains(obj.getString("city_code"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("不跑数量:" + cacheDataRdd.count() + ",待跑数量:" + runDeptRdd.count())
    joinRdd.unpersist()
    (runDeptRdd, cacheDataRdd)
  }

  def start(incDay: String, citycodes: Array[String],runInterFaceFlag:String,
            sgsTableName:String): Unit = {
    //高峰资源
    //"spark.executor.memory"->"12g"
    val confMap = Map[String,String]()
    val sparkSession = Spark.getSparkSession(className,confMap)
    logger.error("开始获取丰源收件和丰源派件数据")
    val originDataRdd = readFengyuanData(sparkSession, incDay,sgsTableName)
    logger.error("关联缓存表")
    val (runDeptRdd, cacheRdd) = joinCacheRdd(sparkSession, incDay, originDataRdd, citycodes)

    logger.error("开始坐标跑网点aoi")
    val deptRdd = runDept(sparkSession, runDeptRdd,runInterFaceFlag)
    val totalRdd = deptRdd.union(cacheRdd).repartition(2000).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("总数:" + totalRdd.count())
    deptRdd.unpersist()
    cacheRdd.unpersist()
    if(!"noRunInterface".equals(runInterFaceFlag)){
      logger.error("保存跑数结果数据到记录表")
      saveCacheData(sparkSession, totalRdd, incDay)
    }
    logger.error("开始合并收派件")
    //    logger.error("先补充45天坐标数据，网点和aoi单独补充")
    val retRdd = mergeShouPai(totalRdd)
    logger.error("保存结果入库")
    saveRdd(sparkSession, retRdd, incDay)
  }

  def main(args: Array[String]): Unit = {
    var incDay = args(0)
    var citycodes = args(1).split(",")
    var runInterFaceFlag = ""
    if(args.length>2){
      runInterFaceFlag = args(2)
    }
    //原始表，有时候，会出问题，就用这张:ods_kafka_sgs.sgs_exp_core_bizlog_data,格式不一样，不能用
    //从外部传进来
    var sgsTableName ="ods_inc_sgs_core.inc_sgs_task_flow_new"
//    if(args.length>3){
//      sgsTableName = args(3)
//    }
    logger.error("日期：" + incDay + ",城市:" + args(1)+",sgs表:"+sgsTableName)
    start(incDay, citycodes,runInterFaceFlag,sgsTableName)
    logger.error("结束流程~")
  }
}


