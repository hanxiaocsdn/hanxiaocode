package com.sf.gis.scala.dw.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.spark.{Spark, SparkNetNew, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.FileUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/** *
 * 按照批次跑接口数据
 * 40000w*0.3
 * 任务id: 915778
 * 任务名称：运单5480坐标及信息-跑接口
 * * 开发：张想远
 * * 业务：蓝媛青
 */
object Waybill5480XyInfoSecondStep {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  var prop = FileUtil.getFilePropertieRes("waybill_5480_xy_info.properties")
  val dept_2_dept_aoi_ak = prop.getProperty("dept_2_dept_aoi_ak")
  val runDeptRetMidTableName = "dm_gis.dw_sds_waybill_state_info_dept_ret_mid3_di"

  def queryOriginData(sparkSession: SparkSession, incDay: String, batch: Int) = {
    val sql = s"select lgt,lat from ${Waybill5480XyInfoFirstStep.noRepeatMidTableName} where " +
      s" inc_day = '${incDay}' and batch = '${batch}' "
    logger.error("源数据sql:" + sql)
    val (dataRdd, columns) = SparkRead.readHiveAsJson(sparkSession, sql,-1)
    dataRdd
  }

  def runDept(sparkSession: SparkSession, runDeptRdd: RDD[JSONObject]) = {
    val parllCnt = 100
    val id = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession,"01374443","374591","运单5480坐标及信息-跑坐标接口","用于回挂宽表妥投坐标的aoi和网点信息",CommonUrl.xyToAoiZc,dept_2_dept_aoi_ak,runDeptRdd.count(),parllCnt)
    //    val deptRdd = SparkNetNew.queryXyToAoiZc(sparkSession, originDataRdd, dept_2_dept_aoi_ak, 150, 100000,
    val deptRdd = SparkNetNew.queryXyToAoiZc(sparkSession, runDeptRdd, dept_2_dept_aoi_ak, parllCnt, 150000,
      "lgt", "lat", false)
    BdpTaskRecordUtil.endNetworkInterface("01374443",id)
    runDeptRdd.unpersist()
    deptRdd
  }

  def saveRunRet(sparkSession: SparkSession,incDay:String,
                 batch: Int, deptRdd: RDD[JSONObject]): Unit = {
    val saveArray = Array("lgt","lat","xyToAoiZcAoiId","xyToAoiZcZc")
    SparkWrite.save2HiveStaticRandom(sparkSession,deptRdd,saveArray,runDeptRetMidTableName,Array(("inc_day",incDay),("batch",batch+"")),50)
  }

  def start(incDay: String, batch:Int): Unit = {
    //高峰资源
    //"spark.executor.memory"->"12g"
    val confMap = Map[String,String]()
    val sparkSession = Spark.getSparkSession(className,confMap)
    logger.error("获取输入数据")
    val inputDataRdd = queryOriginData(sparkSession,incDay,batch)
    logger.error("开始跑接口")
    logger.error("开始坐标跑网点aoi")
    val deptRdd = runDept(sparkSession, inputDataRdd)
    logger.error("写入数据")
    saveRunRet(sparkSession,incDay,batch,deptRdd)
  }

  def main(args: Array[String]): Unit = {
    var incDay = args(0)
    var batch = args(1).toInt
    logger.error("日期：" + incDay + ",批次:" + batch)
    start(incDay, batch)
    logger.error("结束流程~")
  }
}


