package com.sf.gis.scala.dw.app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/** *
 * 获取丰源数据，按照坐标排重拆分
 * 40000w*0.3
 * 任务id:  915778
 * 任务名称：运单5480坐标及信息-预处理，获取原始数据，排重拆分批次
 * * 开发：张想远
 * * 业务：蓝媛青
 */
object Waybill5480XyInfoFirstStep {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)
  val noRepeatMidTableName = "dm_gis.dw_sds_waybill_state_info_no_repeat_mid2_di"
  val originMidTableName = "dm_gis.dw_sds_waybill_state_info_origin_mid1_di"

  def readFengyuanData(sparkSession: SparkSession, incDay: String,
                       sgsTableName: String) = {
    var operatimeColumn = "operatime_new"
    var citycodeColumn = "city_code"
    var sql = s" insert overwrite table ${originMidTableName} partition(inc_day='${incDay}') " +
      "select waybill_no,lgt,lat,ac,tm,type,city_code from ( select waybillno waybill_no,eventlng lgt, " +
      s"eventlat lat,eventaccuracy ac,$operatimeColumn tm,if(eventtype='31124','P','S') type,$citycodeColumn city_code,row_number() over(partition BY waybillno,eventtype order by $operatimeColumn desc )" +
      s" as rank from $sgsTableName " +
      s"where inc_day ='$incDay' and eventtype in ('31124','31201') and  eventlng <> '' and eventlng<>'null' and eventlng is not null " +
      s"and eventlat <> ''  and eventlat<>'null' and eventlat is not null ) a where rank=1  "
//    sql = sql + " limit 10000 ";
    logger.error("源数据sql:" + sql)
    sparkSession.sql(sql)
  }


  def groupByRandom(sparkSession: SparkSession, incDay: String,
                    batchCnt: Int): Unit = {

    var sql = s" " +
      s"select lgt,lat,cast(rand()*${batchCnt} as int ) as batch " +
      s"from  ${originMidTableName} where inc_day='${incDay}' group by lgt,lat "
    logger.error(sql)
    val tmpViewName = "tmp_" + System.currentTimeMillis()
    sparkSession.sql(sql).repartition(25).createOrReplaceTempView(tmpViewName)
    sql = s"insert overwrite table ${noRepeatMidTableName} partition(inc_day,batch) select lgt,lat, '${incDay}' as inc_day,batch " +
      s" from ${tmpViewName} "
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(incDay: String, citycodes: Array[String], batchCnt: Int,
            sgsTableName: String): Unit = {
    //高峰资源
    //"spark.executor.memory"->"12g"
    val confMap = Map[String, String]()
    val sparkSession = Spark.getSparkSession(className, confMap)
    logger.error("获取丰源收件和丰源派件数据, 存储为中间表")
    readFengyuanData(sparkSession, incDay, sgsTableName)
    logger.error("按坐标排重存储分")
    groupByRandom(sparkSession, incDay, batchCnt)
    logger.error("第一步预处理完毕")
  }

  def main(args: Array[String]): Unit = {
    var incDay = args(0)
    var citycodes = args(1).split(",")
    var batchCnt = args(2).toInt
    //原始表，有时候，会出问题，就用这张:ods_kafka_sgs.sgs_exp_core_bizlog_data,格式不一样，不能用
    //从外部传进来
    var sgsTableName = "ods_inc_sgs_core.inc_sgs_task_flow_new"
    //    if(args.length>3){
    //      sgsTableName = args(3)
    //    }
    logger.error("日期：" + incDay + ",城市:" + args(1) + ",sgs表:" + sgsTableName)
    start(incDay, citycodes, batchCnt, sgsTableName)
    logger.error("结束流程~")
  }
}


