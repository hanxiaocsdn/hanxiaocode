package com.sf.gis.scala.dw.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/** *
 * 回挂原始表，写入最终结果表
 * 40000w*0.3
 * 任务id:915778
 * 任务名称：运单5480坐标及信息-回挂
 * 开发：张想远
 * 业务：蓝媛青
 */
object Waybill5480XyInfoThirdStep {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

//  val retTableNameTest = "tmp_dm_gis.t_gdl_waybill_state_info_01374443"

  def queryOriginData(sparkSession: SparkSession, incDay: String) = {

    val sql = s" select waybill_no,a.lgt,a.lat,ac,tm,type,city_code,aoiid,zc from " +
      s" (select waybill_no,lgt,lat,ac,tm,type,city_code from ${Waybill5480XyInfoFirstStep.originMidTableName} " +
      s" where inc_day='${incDay}') a" +
      s" left join " +
      s"(select lgt,lat,aoiid,zc from ${Waybill5480XyInfoSecondStep.runDeptRetMidTableName} where " +
      s" inc_day = '${incDay}')b " +
      s" on a.lgt=b.lgt and a.lat=b.lat "
    logger.error("源数据sql:" + sql)
    val (dataRdd, columns) = SparkRead.readHiveAsJson(sparkSession, sql)
    dataRdd
  }


  def saveRunRet(sparkSession: SparkSession, incDay: String,
                 deptRdd: RDD[JSONObject]): Unit = {
    val saveArray = Array("waybill_no", "delivery_lgt", "delivery_lat", "delivery_ac", "delivery_xy_dept",
      "delivery_xy_aoiid", "delivery_tm", "consign_lgt", "consign_lat", "consign_ac", "consign_xy_dept",
      "consign_xy_aoiid", "consign_tm")
    SparkWrite.save2HiveStaticRandom(sparkSession, deptRdd, saveArray, Waybill5480XyInfo.retTable, Array(("inc_day", incDay)), 50)
  }

  def groupByWaybill(sparkSession: SparkSession, inputDataRdd: RDD[JSONObject]) = {
    val mergeRdd = inputDataRdd.map(obj => {
      val dataType = obj.getString("type")
      if (dataType.equals("P")) {
        obj.put("delivery_lgt", obj.getString("lgt"))
        obj.put("delivery_lat", obj.getString("lat"))
        obj.put("delivery_ac", obj.getString("ac"))
        obj.put("delivery_tm", obj.getString("tm"))
        obj.put("delivery_xy_aoiid", obj.getString("aoiid"))
        obj.put("delivery_xy_dept", obj.getString("zc"))
      } else {
        obj.put("consign_lgt", obj.getString("lgt"))
        obj.put("consign_lat", obj.getString("lat"))
        obj.put("consign_ac", obj.getString("ac"))
        obj.put("consign_tm", obj.getString("tm"))
        obj.put("consign_xy_aoiid", obj.getString("aoiid"))
        obj.put("consign_xy_dept", obj.getString("zc"))
      }
      obj.remove("lgt")
      obj.remove("lat")
      obj.remove("ac")
      obj.remove("tm")
      obj.remove("aoiid")
      obj.remove("zc")
      (obj.getString("waybill_no"), obj)
    }).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("收件派件合并后数量:" + mergeRdd.count())
    inputDataRdd.unpersist()
    mergeRdd
  }

  def start(incDay: String): Unit = {
    //高峰资源
    //"spark.executor.memory"->"12g"
    val confMap = Map[String, String]()
    val sparkSession = Spark.getSparkSession(className, confMap)
    logger.error("获取输入数据")
    val inputDataRdd = queryOriginData(sparkSession, incDay)
    logger.error("开始用运单号聚合收派")
    val waybillRdd = groupByWaybill(sparkSession, inputDataRdd)
    logger.error("写入数据")
    saveRunRet(sparkSession, incDay, waybillRdd)
  }

  def main(args: Array[String]): Unit = {
    var incDay = args(0)
    logger.error("日期：" + incDay)
    start(incDay)
    logger.error("结束流程~")
  }
}


