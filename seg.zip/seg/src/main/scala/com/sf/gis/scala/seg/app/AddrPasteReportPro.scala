package com.sf.gis.scala.seg.app

import java.sql.{Connection, DriverManager}

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, DbUtil, JSONUtil, StringUtils}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01375125 on 2020/1/14.
 * 任务id:225248
 * 任务名称：地址粘贴指标统计
 * 开发：张想远
 * 业务：匡可心
 */
object AddrPasteReportPro {
  private val appName: String = this.getClass.getSimpleName.replace("$", "")
  private val logger = LoggerFactory.getLogger(appName)

  //cx埋点指标
  case class CxPointIndexObj(statDate: String, cxPointCnt: Long, dlvMatchCnt: Long, puMatchCnt: Long, paiMatchCnt: Long)

  //pai日志匹配指标（收件、派件）
  case class PaiIndexObj(statDate: String, matchType: String, paiMatchCnt: Int, rdsMatchCnt: Int, nameCnt: Int, phoneCnt: Int, mobileCnt: Int, provinceCnt: Int, cityCnt: Int, countyCnt: Int, townCnt: Int, addressCnt: Int)

  def main(args: Array[String]): Unit = {
    start(args)
    //    test()
  }

  def start(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    if (args.length == 0) {
      //代码内部传入日期参数
      val date = DateUtil.getYesterday
      //      val date = "20191227"
      handleTask(spark, date)
    } else if (args.length == 1) {
      val param = args(0)
      if (param.length == 8) {
        val date = args(0)
        //传入参数，单天任务
        handleTask(spark, date)
      } else {
        //传入参数，滚动两天任务
        val startDate = DateUtil.getDateStr(-2)
        val endDate = DateUtil.getYesterday
        batchTask(spark, startDate, endDate)
      }
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      val startDate = args(0)
      val endDate = args(1)
      batchTask(spark, startDate, endDate)
    }


    spark.stop()
  }


  /**
   * 批量任务
   *
   * @param spark
   * @param startDate
   * @param endDate
   */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      handleTask(spark, date)
    }
  }

  def handleTask(spark: SparkSession, date: String): Unit = {
    logger.error(">>>处理地址粘贴日志：日期=" + date + "-------------appName=" + appName)
    logger.error(">>>获取埋点数据")
    val cxPointRdd = getCxPointLog(spark, date)

    logger.error(">>>获取Pai地址粘贴的数据") //sn为key
    val paiRdd = getPaiLog(spark, date)

    logger.error(">>>获取收件下call数据")
    val omsfromRdd = getOmsfromLog(spark, date)

    logger.error(">>>获取派件日志数据：")
    val omstoRdd = getOmstoLog(spark, date)

    logger.error(">>>统计cx埋点指标并将指标数据保存到mysql中----------------")
    statCxPointIndex(spark, date, cxPointRdd, omsfromRdd, omstoRdd, paiRdd)

    logger.error(">>>统计的pai日志指标保存到mysql数据库中-------------------")
    statPaiLogIndex(date, cxPointRdd, omsfromRdd, omstoRdd, paiRdd)


    paiRdd.unpersist()
    omsfromRdd.unpersist()
    omstoRdd.unpersist()

  }

  /**
   * 统计派件日志指标
   *
   * @param spark
   * @param date
   * @param omsfromRdd
   * @param omstoRdd
   * @param paiRdd
   */
  def statCxPointIndex(spark: SparkSession, date: String, cxPointRdd: RDD[(String, JSONObject)], omsfromRdd: RDD[(String, JSONObject)], omstoRdd: RDD[(String, JSONObject)], paiRdd: RDD[(String, JSONObject)]): Unit = {
    val cxJoinPaiRdd = cxPointRdd.leftOuterJoin(paiRdd).map(obj => {
      val cxJson = obj._2._1
      val paiObj = obj._2._2
      if (paiObj.nonEmpty) {
        val paiBody = paiObj.get
        cxJson.put("paiBody", paiBody)
      }
      val appointmentno = cxJson.getString("appointmentno")
      (appointmentno, cxJson)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val cxJoinPaiOkRdd = cxJoinPaiRdd.filter(obj => {
      obj._2.getJSONObject("paiBody") != null
    })
    val cxJoinPaiCount = cxJoinPaiOkRdd.count()
    logger.error(">>>埋点数据关联上pai日志数据量(cx的sn->pai的sn)：" + cxJoinPaiCount)
    cxJoinPaiOkRdd.take(1).foreach(println)

    val cxJoinOmsfromRdd = cxJoinPaiRdd.leftOuterJoin(omsfromRdd).map(obj => {
      val cxJson = obj._2._1
      val omsfromObj = obj._2._2
      var flag = false
      var orderno: String = null
      if (omsfromObj.nonEmpty) {
        val omsfromJson = omsfromObj.get
        cxJson.put("puBody", omsfromJson)
        orderno = omsfromJson.getString("orderno")
      }
      (orderno, cxJson)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val cxPointJoinPuOkRdd = cxJoinOmsfromRdd.filter(_._1 != null)
    val cxJoinPuCount = cxPointJoinPuOkRdd.count()
    logger.error(">>>cx埋点关联上收件下call的数据量(cx的appointmentno->收件的orderno)：" + cxJoinPuCount)
    cxPointJoinPuOkRdd.take(1).foreach(println)

    val cxJoinDlvRdd = cxJoinOmsfromRdd.leftOuterJoin(omstoRdd).map(obj => {
      val cxPointJson = obj._2._1
      val dlvObj = obj._2._2
      if (dlvObj.nonEmpty) {
        val dlvJson = dlvObj.get
        cxPointJson.put("dlvBody", dlvJson)
      }
      cxPointJson
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val cxJoinDlvOkRdd = cxJoinDlvRdd.filter(_.getJSONObject("dlvBody") != null)
    val cxJoinDlvCount = cxJoinDlvOkRdd.count()
    logger.error(">>>埋点数据关联上rds派件的数据量（收件的orderno->派件的req_orderno）：" + cxJoinDlvCount)
    cxJoinDlvOkRdd.take(1).foreach(println)

    val cxPointCount = cxPointRdd.count()
    val cxPointIndexObj = CxPointIndexObj(date, cxPointCount, cxJoinDlvCount, cxJoinPuCount, cxJoinPaiCount)
    logger.error(">>>统计的埋点指标保存到mysql数据库中")
    println(cxPointIndexObj)
    saveCxPointToMysql(cxPointIndexObj, date)

    //    logger.error(">>>埋点数据明细入hive库")
    //    saveCxDataToHive(spark,date,cxJoinDlvRdd)
    cxJoinPaiRdd.unpersist()
    cxJoinOmsfromRdd.unpersist()
    cxJoinDlvRdd.unpersist()

    logger.error("------埋点数据处理完成！")
  }


  /**
   * cx埋点明细数据存hive表
   *
   * @param spark
   */
  def saveCxDataToHive(spark: SparkSession, incDay: String, resultRdd: RDD[JSONObject]): Unit = {
    val dataBase = "dm_gis"
    val table = "cx_point_join_detail"
    logger.error(">>>table=" + dataBase + "." + table)
    spark.sql(s"use $dataBase")
    //1 构造DataFrame的元数据 StructField
    val structFileds = new java.util.ArrayList[StructField]()
    val structs = Array("sn", "appointmentno", "entry_type", "pai_personname", "pai_phone", "pai_province", "pai_city", "pai_county", "pai_town", "pai_addresstext", "pai_detailaddr", "from_orderno", "from_name", "from_phone", "from_mobile", "from_province", "from_city", "from_county", "from_address", "to_orderno", "to_name", "to_phone", "to_mobile", "to_province", "to_city", "to_county", "to_address")
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    //2 构建StructType用于DataFrame的元数据描述
    val structType = DataTypes.createStructType(structFileds)
    //3 构建Row格式数据集RDD[Row]
    val rowRdd = resultRdd.map(obj => {
      var row: Row = null
      try {
        val names = Array("sn", "appointmentno", "entry_type", "paiBody.personName", "paiBody.phoneNumber", "paiBody.province", "paiBody.city", "paiBody.county", "paiBody.town", "paiBody.addresstext", "paiBody.detailaddr", "puBody.orderno", "puBody.contactsname", "puBody.phone", "puBody.mobile", "puBody.province", "puBody.city", "puBody.county", "puBody.address", "dlvBody.req_orderno", "dlvBody.req_addresseecontacts", "dlvBody.req_addresseephone", "dlvBody.req_addresseemobile", "dlvBody.req_province", "dlvBody.req_city", "dlvBody.req_area", "dlvBody.receiver_addr")
        val values = new Array[String](names.length)
        for (i <- names.indices) values(i) = JSONUtil.getJsonVal(obj, names(i), "").replaceAll("[\\r\\n\\t]", "")
        row = RowFactory.create(values(0), values(1), values(2), values(3), values(4), values(5), values(6), values(7), values(8), values(9), values(10), values(11), values(12), values(13), values(14), values(15), values(16), values(17), values(18), values(19), values(20), values(21), values(22), values(23), values(24), values(25), values(26))
      } catch {
        case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
      }
      row
    }).filter(_ != null)
    // 4 构建DataFrame
    val df: DataFrame = spark.createDataFrame(rowRdd, structType)
    //5 基于Datarame创建临时表
    val tempView = String.format("%s_temp_view", table)
    df.createOrReplaceTempView(tempView)
    //6 分区、表等操作
    val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
    logger.error(">>>删除分区：" + deleteSql)
    spark.sql(deleteSql)
    val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
    logger.error(">>>新建分区：" + createPartitionSql)
    spark.sql(createPartitionSql)
    //7 把临时表的数据刷进hive表中
    spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
    logger.error(">>>数据入hive库结束!")
  }


  /**
   * 统计pai日志指标数据
   *
   * @param date
   * @param omsfromRdd
   * @param omstoRdd
   * @param paiRdd
   */
  def statPaiLogIndex(date: String, cxPointRdd: RDD[(String, JSONObject)], omsfromRdd: RDD[(String, JSONObject)], omstoRdd: RDD[(String, JSONObject)], paiRdd: RDD[(String, JSONObject)]): Unit = {
    val paiJoinCxRdd = paiRdd.leftOuterJoin(cxPointRdd).map(obj => {
      val paiJson = obj._2._1
      val cxPointObj = obj._2._2
      var appointmentno: String = null
      if (cxPointObj.nonEmpty) {
        val cxPointJson = cxPointObj.get
        if (cxPointJson.getString("appointmentno") != null) appointmentno = cxPointJson.getString("appointmentno")
        paiJson.put("appointmentno", appointmentno)
      }
      (appointmentno, paiJson)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val paiJoinCxOkRdd = paiJoinCxRdd.filter(_._1 != null).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val paiJoinCxBadRdd = paiJoinCxRdd.filter(_._1 == null).values.persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>pai日志关联上cx埋点后的数据量(pai的sn关联cx的sn)：" + paiJoinCxOkRdd.count())
    logger.error(">>>pai日志未关联上cx埋点后的数据量(pai的sn关联cx的sn)：" + paiJoinCxBadRdd.count())
    paiJoinCxRdd.unpersist()
    paiJoinCxOkRdd.take(1).foreach(println)
    paiJoinCxBadRdd.take(1).foreach(println)
    cxPointRdd.unpersist()
    val paiJoinPuRdd = paiJoinCxOkRdd.leftOuterJoin(omsfromRdd).map(obj => {
      val paiJson = obj._2._1
      val puObj = obj._2._2
      var orderno: String = null
      if (puObj.nonEmpty) {
        val puJson = puObj.get
        orderno = puJson.getString("orderno")
        paiJson.put("puBody", puJson)
      }
      (orderno, paiJson)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val paiJoinPuOkRdd = paiJoinPuRdd.filter(_._1 != null).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val paiJoinPuBadRdd = paiJoinPuRdd.filter(_._1 == null).values.persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>pai日志关联上收件数据量(用关联上的cx的appointmentno去关联收件sysorderno)：" + paiJoinPuOkRdd.count())
    logger.error(">>>pai日志未关联上收件数据量(用关联上的cx的appointmentno去关联收件sysorderno)：" + paiJoinPuBadRdd.count())
    paiJoinCxOkRdd.unpersist()
    paiJoinPuRdd.unpersist()
    paiJoinPuOkRdd.take(1).foreach(println)
    paiJoinPuBadRdd.take(1).foreach(println)

    val paiJoinDlvRdd = paiJoinPuOkRdd.leftOuterJoin(omstoRdd).map(obj => {
      val paiJson = obj._2._1
      val dlvObj = obj._2._2
      if (dlvObj.nonEmpty) {
        val dlvJson = dlvObj.get
        paiJson.put("dlvBody", dlvJson)
      }
      paiJson
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val paiJoinDlvOkRdd = paiJoinDlvRdd.filter(_.getJSONObject("dlvBody") != null)
    val paiJoinDlvOkCount = paiJoinDlvOkRdd.count()
    logger.error(">>>关联rds派件之后的数据量(用关联上收件的orderno去关联派件的req_orderno)：" + paiJoinDlvOkCount + ",开始计算指标")
    paiJoinDlvOkRdd.take(1).foreach(println)
    val totalRdd = paiJoinCxBadRdd.union(paiJoinPuBadRdd).union(paiJoinDlvRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("总数据量:" + totalRdd.count())
    paiJoinPuBadRdd.unpersist()
    paiJoinCxBadRdd.unpersist()
    paiJoinDlvRdd.unpersist()
    val rowRdd = totalRdd.map(json => {
      var paiMatchCnt = 1
      var puMatchCnt, puNameCnt, puPhoneCnt, puMobileCnt, puProvinceCnt, puCityCnt, puCountyCnt, puTownCnt, puAddressCnt = 0
      var dlvMatchCnt, dlvNameCnt, dlvPhoneCnt, dlvMobileCnt, dlvProvinceCnt, dlvCityCnt, dlvCountyCnt, dlvTownCnt, dlvAddressCnt = 0

      val paiName = json.getString("personName")
      val paiPhone = json.getString("phoneNumber")
      val paiMobile = json.getString("mobile")
      val paiProvince = json.getString("province")
      val paiCity = json.getString("city")
      val paiCounty = json.getString("county")
      val paiTown = json.getString("town")
      val paiAddress = json.getString("detailaddr")

      val puBody = json.getJSONObject("puBody")
      if (puBody != null) {
        puMatchCnt = 1 //匹配上收件的量
        val puName = puBody.getString("contactsname")
        val puPhone = puBody.getString("phone")
        val puMobile = puBody.getString("mobile")
        val puProvince = puBody.getString("province")
        val puCity = puBody.getString("city")
        val puCounty = puBody.getString("county")
        val puTown = puBody.getString("town")
        val puAddress = puBody.getString("address")

        if (paiName != null && puName != null && paiName == puName) puNameCnt = 1
        if (paiPhone != null && puPhone != null && paiPhone == puPhone) puPhoneCnt = 1
        if (paiMobile != null && puMobile != null && paiMobile == puMobile) puMobileCnt = 1
        if (paiProvince != null && puProvince != null && paiProvince == puProvince) puProvinceCnt = 1
        if (paiCity != null && puCity != null && paiCity == puCity) puCityCnt = 1
        if (paiCounty != null && puCounty != null && paiCounty == puCounty) puCountyCnt = 1
        if (paiTown != null && puTown != null && paiTown == puTown) puTownCnt = 1
        if (paiAddress != null && puAddress != null && paiAddress == puAddress) puAddressCnt = 1
      }
      val dlvBody = json.getJSONObject("dlvBody")
      if (dlvBody != null) {
        dlvMatchCnt = 1 //匹配上收件的量
        val dlvName = dlvBody.getString("req_addresseecontacts")
        val dlvPhone = dlvBody.getString("req_addresseephone")
        val dlvMobile = dlvBody.getString("req_addresseemobile")
        val dlvProvince = dlvBody.getString("req_province")
        val dlvCity = dlvBody.getString("req_city")
        val dlvCounty = dlvBody.getString("req_area")
        val dlvTown = dlvBody.getString("req_town")
        val dlvAddress = dlvBody.getString("receiver_addr")

        if (paiName != null && dlvName != null && paiName == dlvName) dlvNameCnt = 1
        if (paiPhone != null && dlvPhone != null && paiPhone == dlvPhone) dlvPhoneCnt = 1
        if (paiMobile != null && dlvMobile != null && paiMobile == dlvMobile) dlvMobileCnt = 1
        if (paiProvince != null && dlvProvince != null && paiProvince == dlvProvince) dlvProvinceCnt = 1
        if (paiCity != null && dlvCity != null && paiCity == dlvCity) dlvCityCnt = 1
        if (paiCounty != null && dlvCounty != null && paiCounty == dlvCounty) dlvCountyCnt = 1
        if (paiTown != null && dlvTown != null && paiTown == dlvTown) dlvTownCnt = 1
        if (paiAddress != null && dlvAddress != null && paiAddress == dlvAddress) dlvAddressCnt = 1
      }
      val puRowIndex = PaiIndexObj(date, "PU", paiMatchCnt, puMatchCnt, puNameCnt, puPhoneCnt, puMobileCnt, puProvinceCnt, puCityCnt, puCountyCnt, puTownCnt, puAddressCnt)
      val dlvRowIndex = PaiIndexObj(date, "DLV", paiMatchCnt, dlvMatchCnt, dlvNameCnt, dlvPhoneCnt, dlvMobileCnt, dlvProvinceCnt, dlvCityCnt, dlvCountyCnt, dlvTownCnt, dlvAddressCnt)
      (date, puRowIndex, dlvRowIndex)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val rowPuIndexRdd = rowRdd.map(obj => {
      (date, obj._2)
    })

    val puIndex = rowPuIndexRdd.reduceByKey((c1, c2) => {
      PaiIndexObj(c1.statDate, c1.matchType, c1.paiMatchCnt + c2.paiMatchCnt, c1.rdsMatchCnt + c2.rdsMatchCnt, c1.nameCnt + c2.nameCnt, c1.phoneCnt + c2.phoneCnt, c1.mobileCnt + c2.mobileCnt, c1.provinceCnt + c2.provinceCnt, c1.cityCnt + c2.cityCnt, c1.countyCnt + c2.countyCnt, c1.townCnt + c2.townCnt, c1.addressCnt + c2.addressCnt)
    }).map(_._2).collect().toList.head
    println(puIndex)

    val rowDlvIndexRdd = rowRdd.map(obj => {
      (date, obj._3)
    })

    val dlvIndex = rowDlvIndexRdd.reduceByKey((c1, c2) => {
      PaiIndexObj(c1.statDate, c1.matchType, c1.paiMatchCnt + c2.paiMatchCnt, c1.rdsMatchCnt + c2.rdsMatchCnt, c1.nameCnt + c2.nameCnt, c1.phoneCnt + c2.phoneCnt, c1.mobileCnt + c2.mobileCnt, c1.provinceCnt + c2.provinceCnt, c1.cityCnt + c2.cityCnt, c1.countyCnt + c2.countyCnt, c1.townCnt + c2.townCnt, c1.addressCnt + c2.addressCnt)
    }).map(_._2).collect().toList.head
    println(dlvIndex)

    savePaiPointToMysql(puIndex, dlvIndex, date)

    rowRdd.unpersist()
  }

  /**
   * 保存cx统计指标到msql中
   *
   * @param date
   */
  def savePaiPointToMysql(puObj: PaiIndexObj, dlvObj: PaiIndexObj, date: String): Unit = {
    try {
      val connection = getConnection
      val reportTableName = "ADDR_PAI_RDS_MATCH_STAT"
      val deleteSql = s"DELETE FROM $reportTableName WHERE STATDATE='$date'"
      println(">>>删除报表数据：" + deleteSql)
      DbUtil.execute(connection, deleteSql, null)
      val reportSql =
        s"""
          INSERT INTO $reportTableName (STATDATE,MATCH_TYPE,PAI_MATCH_CNT,RDS_MATCH_CNT,NAME_CNT,PHONE_CNT,MOBILE_CNT,PROVINCE_CNT,CITY_CNT,COUNTY_CNT,TOWN_CNT,ADDRESS_CNT) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
       """.stripMargin
      val dlvIndexList = Array(dlvObj.statDate, dlvObj.matchType, dlvObj.paiMatchCnt, dlvObj.rdsMatchCnt, dlvObj.nameCnt, dlvObj.phoneCnt, dlvObj.mobileCnt, dlvObj.provinceCnt, dlvObj.cityCnt, dlvObj.countyCnt, dlvObj.townCnt, dlvObj.addressCnt)
      DbUtil.execute(connection, reportSql, dlvIndexList)

      val puIndexList = Array(puObj.statDate, puObj.matchType, puObj.paiMatchCnt, puObj.rdsMatchCnt, puObj.nameCnt, puObj.phoneCnt, puObj.mobileCnt, puObj.provinceCnt, puObj.cityCnt, puObj.countyCnt, puObj.townCnt, puObj.addressCnt)
      DbUtil.execute(connection, reportSql, puIndexList)

      logger.error(">>>pai指标入库结束！")
      connection.close()
    } catch {
      case e: Exception => logger.error(">>>指标入库异常：" + e)
    }
  }


  /**
   * 保存cx统计指标到msql中
   *
   * @param obj
   * @param date
   */
  def saveCxPointToMysql(obj: CxPointIndexObj, date: String): Unit = {
    try {
      val connection = getConnection
      val reportTableName = "ADDR_CX_POINT_MATCH_STAT"
      val deleteSql = s"DELETE FROM $reportTableName WHERE STATDATE='$date'"
      println(">>>删除报表数据：" + deleteSql)
      DbUtil.execute(connection, deleteSql, null)
      val reportSql =
        s"""
          INSERT INTO $reportTableName (STATDATE,CX_POINT_CNT,DLV_MATCH_CNT,PU_MATCH_CNT,PAI_MATCH_CNT) VALUES (?,?,?,?,?)
       """.stripMargin
      val reportIndexList = Array(obj.statDate, obj.cxPointCnt, obj.dlvMatchCnt, obj.puMatchCnt, obj.paiMatchCnt)
      DbUtil.execute(connection, reportSql, reportIndexList)
      logger.error(">>>cx报表指标入库结束！")
      connection.close()
    } catch {
      case e: Exception => logger.error(">>>指标入库异常：" + e)
    }
  }

  def getConnection: Connection = {
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_addr?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8mb4&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"
    @transient val connection = DriverManager.getConnection(url, "gis_oms_addr", "gis_oms_addr@123@")
    connection
  }


  /**
   * 获取cx埋点数据
   *
   * @param spark
   * @return
   */
  def getCxPointLog(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    val sql =
      s"""
         |select properties_sn as sn,properties['appointmentNo'] appointmentno,properties ['entryType'] as entry_type
         |from ods_inc_ubas.product_inc_ubas_cx where dt='$date' and event_id = 'XCX1035'
       """.stripMargin
    println("sql=" + sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val resultRdd = df.rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i))
      val sn = json.getString("sn")
      (sn, json)
    }).filter(_._1 != null).reduceByKey((o1, o2) => o1).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>cx埋点数据量(sn为key)：" + resultRdd.count())
    resultRdd.take(1).foreach(println)
    resultRdd
  }

  /**
   * 获取pai的日志
   *
   * @param spark
   * @return
   */
  def getPaiLog(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    val sql =
      s"select " +
        "get_json_object(log,'$.message') " +
        s"  from dm_gis.gis_rss_seg_cloud_log_collect_new where inc_day='$date'"

    println("sql=" + sql)
    val filterRdd = spark.sql(sql).rdd.map(row => {
      val log = row.getString(0)
      var json: JSONObject = null
      try {
        json = JSON.parseObject(log)
      } catch {
        case e: Exception => logger.error(">>>转换json异常：" + e)
      }
      var isValid = false
      if (json != null) {
        val _type = json.getString("type")
        if (_type != null && _type == "url_e") isValid = true
      }
      (isValid, json)
    }).filter(_._1).values.filter(json => {
      var flag = false
      val urlObj = json.getJSONObject("url")
      if (urlObj != null) {
        val ak = urlObj.getString("ak")
        if (ak != null) flag = ak == "14e9ee810854c40f5ae9414f2a62c8cc"
      }
      flag
    })
    filterRdd.take(1).foreach(println)

    val paiRdd = filterRdd.map(json => {
      val dateTime = json.getString("dateTime")
      var personName = ""
      var phoneNumber = ""
      var company = ""
      var province = ""
      var city = ""
      var citycode = ""
      var county = ""
      var detailAddress = ""
      var addresstext = ""
      var sn = ""
      if (json.getString("sn") != null) sn = json.getString("sn")
      val url = json.getJSONObject("url")
      if (url != null) {
        addresstext = url.getString("addresstext")
      }

      val dataObj = json.getJSONObject("data")
      if (dataObj != null) {
        val resultObj = dataObj.getJSONObject("result")
        if (resultObj != null) {
          val paidata = resultObj.getJSONObject("paidata")
          if (paidata != null) {
            val jsonArray = paidata.getJSONArray("personName")
            if (jsonArray != null) {
              val nameList = new ArrayBuffer[String]()
              for (i <- 0.until(jsonArray.size())) {
                nameList += jsonArray.getString(i)
              }
              personName = nameList.mkString("|")
            }
            if (paidata.getString("phoneNumber") != null) phoneNumber = paidata.getString("phoneNumber")
            if (paidata.getString("company") != null) company = paidata.getString("company")
          }

          val innerData = resultObj.getJSONObject("data")
          if (innerData != null) {
            if (innerData.getString("province") != null) province = innerData.getString("province")
            if (innerData.getString("city") != null) city = innerData.getString("city")
            if (innerData.getString("citycode") != null) citycode = innerData.getString("citycode")
            if (innerData.getString("county") != null) county = innerData.getString("county")
            var town = ""
            var detailaddr = ""
            if (innerData.getString("town") != null) town = innerData.getString("town")
            if (innerData.getString("detailaddr") != null) detailaddr = innerData.getString("detailaddr")
            detailAddress = town + detailaddr
          }
        }
      }
      val newJson = new JSONObject()
      newJson.put("dateTime", dateTime)
      newJson.put("personName", personName)
      newJson.put("phoneNumber", phoneNumber)
      newJson.put("company", company)
      newJson.put("province", province)
      newJson.put("city", city)
      newJson.put("citycode", citycode)
      newJson.put("county", county)
      newJson.put("addresstext", addresstext)
      newJson.put("detailaddr", detailAddress)
      newJson.put("sn", sn)
      (sn, newJson)
    }).filter(obj => obj._1 != null && !obj._1.isEmpty).reduceByKey((o1, o2) => o1).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>根据sn排重后pai日志数据量（sn为key）：" + paiRdd.count())
    paiRdd.take(1).foreach(println)
    paiRdd
  }

  /**
   * 获取pai的日志
   *
   * @param spark
   * @return
   */
  def getPaiLogOld(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    val sql =
      s"""
         |select logs from dm_gis_ass_rds.ods_gis_rss_seg_pai_logs_bee_loganalysis where inc_day='$date'
       """.stripMargin
    println("sql=" + sql)
    val filterRdd = spark.sql(sql).rdd.map(row => {
      val line = row.getString(0)
      line
      //systemcollect.log#
    }).filter(_.contains("system.log#{")).map(line => {
      var json: JSONObject = null
      try {
        val log = StringUtils.pickGroup1Str(line, "system.log#(.*)")
        json = JSON.parseObject(log)
      } catch {
        case e: Exception => logger.error(">>>转换json异常：" + e)
      }
      var isValid = false
      if (json != null) {
        val _type = json.getString("type")
        if (_type != null && _type == "url_e") isValid = true
      }
      (isValid, json)
    }).filter(_._1).values.filter(json => {
      var flag = false
      val urlObj = json.getJSONObject("url")
      if (urlObj != null) {
        val ak = urlObj.getString("ak")
        if (ak != null) flag = ak == "14e9ee810854c40f5ae9414f2a62c8cc"
      }
      flag
    })
    filterRdd.take(1).foreach(println)

    val paiRdd = filterRdd.map(json => {
      val dateTime = json.getString("dateTime")
      var personName = ""
      var phoneNumber = ""
      var company = ""
      var province = ""
      var city = ""
      var citycode = ""
      var county = ""
      var detailAddress = ""
      var addresstext = ""
      var sn = ""
      if (json.getString("sn") != null) sn = json.getString("sn")
      val url = json.getJSONObject("url")
      if (url != null) {
        addresstext = url.getString("addresstext")
      }

      val dataObj = json.getJSONObject("data")
      if (dataObj != null) {
        val resultObj = dataObj.getJSONObject("result")
        if (resultObj != null) {
          val paidata = resultObj.getJSONObject("paidata")
          if (paidata != null) {
            val jsonArray = paidata.getJSONArray("personName")
            if (jsonArray != null) {
              val nameList = new ArrayBuffer[String]()
              for (i <- 0.until(jsonArray.size())) {
                nameList += jsonArray.getString(i)
              }
              personName = nameList.mkString("|")
            }
            if (paidata.getString("phoneNumber") != null) phoneNumber = paidata.getString("phoneNumber")
            if (paidata.getString("company") != null) company = paidata.getString("company")
          }

          val innerData = resultObj.getJSONObject("data")
          if (innerData != null) {
            if (innerData.getString("province") != null) province = innerData.getString("province")
            if (innerData.getString("city") != null) city = innerData.getString("city")
            if (innerData.getString("citycode") != null) citycode = innerData.getString("citycode")
            if (innerData.getString("county") != null) county = innerData.getString("county")
            var town = ""
            var detailaddr = ""
            if (innerData.getString("town") != null) town = innerData.getString("town")
            if (innerData.getString("detailaddr") != null) detailaddr = innerData.getString("detailaddr")
            detailAddress = town + detailaddr
          }
        }
      }
      val newJson = new JSONObject()
      newJson.put("dateTime", dateTime)
      newJson.put("personName", personName)
      newJson.put("phoneNumber", phoneNumber)
      newJson.put("company", company)
      newJson.put("province", province)
      newJson.put("city", city)
      newJson.put("citycode", citycode)
      newJson.put("county", county)
      newJson.put("addresstext", addresstext)
      newJson.put("detailaddr", detailAddress)
      newJson.put("sn", sn)
      (sn, newJson)
    }).filter(_._1 != null).reduceByKey((o1, o2) => o1).repartition(100).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>根据sn排重后pai日志数据量（sn为key）：" + paiRdd.count())
    paiRdd.take(1).foreach(println)
    paiRdd
  }

  /**
   * 获取派件日志数据
   *
   * @param spark
   */
  def getOmstoLog(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    val sql =
      s"""
         |select inc_day,req_waybillno,req_orderno,req_addresseecontacts,req_addresseephone,req_addresseemobile,req_province,req_city,req_area,req_body
         |from dm_gis.gis_rds_omsto where inc_day='$date'
       """.stripMargin
    println(">>>sql=" + sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val omstoRdd = df.rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i))
      var receiverAddr = ""
      try {
        val req_body = json.getString("req_body")
        var req_body_json = JSON.parseObject(req_body)
        receiverAddr = req_body_json.getString("receiverAddr")
      } catch {
        case e: Exception => logger.error(">>>pai日志转json异常：" + e)

      }
      json.put("receiver_addr", receiverAddr)
      json.remove("req_body")
      val req_orderno = json.getString("req_orderno")
      (req_orderno, json)
    }).filter(_._1 != null).reduceByKey((o1, o2) => o1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>获取派件日志量（req_orderno作key且排重）：" + omstoRdd.count())
    omstoRdd.take(1).foreach(println)
    omstoRdd
  }

  /**
   * 获取收件日志
   */
  def getOmsfromLog(spark: SparkSession, date: String): RDD[(String, JSONObject)] = {
    val sql =
      s"""
         |select inc_day,sysorderno ,waybillno,orderno,contactsname,phone,mobile,province,city,county,address
         | from dm_gis.gis_rds_omsfrom where inc_day='$date'
       """.stripMargin
    println("sql=" + sql)
    val df = spark.sql(sql)
    val fields = df.schema.fields
    val resultRdd = df.rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) json.put(fields(i).name, row.getString(i))
      val sysorderno = json.getString("sysorderno")
      (sysorderno, json)
    }).filter(t => {
      t._1 != null && t._1 != "null"
    }).reduceByKey((o1, o2) => o1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>收件下call的数据量（sysorderno作key排重）：" + resultRdd.count())
    resultRdd.take(1).foreach(println)
    resultRdd
  }


}
