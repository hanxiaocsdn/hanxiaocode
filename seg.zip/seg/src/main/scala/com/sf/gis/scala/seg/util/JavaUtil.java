package com.sf.gis.scala.seg.util;

import org.apache.commons.io.IOUtils;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

/**
 * Created by 01375125 on 2018/7/9.
 * java工具类
 */
public class JavaUtil implements Serializable{


    private static final long serialVersionUID = 147258369L;
    // 1-测试，
    // 2-oms生产，
    // 3-派件妥投生产
    // 4-线下日志
    // 5-输入提示的
    // 6-路由分单的
    // 7-高低精审补库测试
    // 8-高低精审补库生产
    // 9-错分生产
    // 11-重量区间

    public static int EN = 2;

    private int flag;

    public int getFlag() {
        return flag;
    }

    public void setFlag(int flag) {
        this.flag = flag;
    }

    public JavaUtil(int flag) {
        this.flag = flag;
    }

    public JavaUtil() {
    }

    /**
     * 获取配置文件中属性
     * @param key: key
     * @return String: 结果
     */
    public static String getString(String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {

            String configPath = null;
            if(EN == 1)//测试的库
                configPath = "debug-config.properties";
            else if(EN == 2)//生产的库
                configPath = "pro-config.properties";
            else if(EN == 3)//错分的项目
                configPath = "wrong-config.properties";
            else if(EN == 4)//oms离线的项目
                configPath = "offline_pro-config.properties";
            else if(EN == 5)//输入提示的项目
                configPath = "input.properties";
            else if(EN == 6)//rds路由分单的项目
                configPath = "rds.properties";
            else if(EN == 7)//高低精库测试
                configPath = "precision_debug.properties";
            else if(EN == 8)//高低精库生产
                configPath = "precision.properties";
            else if(EN == 9)//错分测试
                configPath = "wd.properties";
            else if(EN == 10)//错分生产
                configPath = "wd.properties";
            in = JavaUtil .class.getClassLoader().getResourceAsStream(configPath);
//            in = AppConfig.class.getClassLoader().getResourceAsStream(configPath);


            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }


    /**
     * 获取配置文件中属性
     * @param key: key
     * @return String: 结果
     */
    public  String get(String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {

            String configPath = null;
            if(flag == 1)//测试的库
                configPath = "debug-config.properties";
            else if(flag == 2)//生产的库
                configPath = "pro-config.properties";
            else if(flag == 3)//错分的项目
                configPath = "wrong-config.properties";
            else if(flag == 4)//oms离线的项目
                configPath = "offline_pro-config.properties";
            else if(flag == 5)//输入提示的项目
                configPath = "input.properties";
            else if(flag == 6)//rds路由分单的项目
                configPath = "rds.properties";
            else if(flag == 7)//高低精库测试
                configPath = "precision_debug.properties";
            else if(flag == 8)//高低精库生产
                configPath = "precision.properties";
            else if(flag == 9)//错分测试
                configPath = "wd.properties";
            else if(flag == 10)//错分生产
                configPath = "wd.properties";
            else if(flag == 11)//重量区间映射数据
                configPath = "kafka-weight.properties";
            else if(flag == 12)//地址拆分
                configPath = "addr.properties";
            in = JavaUtil .class.getClassLoader().getResourceAsStream(configPath);
//            in = AppConfig.class.getClassLoader().getResourceAsStream(configPath);
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }

    public static String getQuerySql(String fileName) throws IOException {
        //文件后缀为txt,sql等不能被识别
        return IOUtils.toString(JavaUtil .class.getClassLoader().getResourceAsStream(fileName));
    }


    /**
     * 获取某个配置文件中某个属性的值
     * @param key: key
     * @return String: 结果
     */
    public static String get(String configName,String key){
        String value=null;
        Properties props = new Properties();
        InputStream in = null;
        InputStreamReader isr = null;
        BufferedReader bf = null;
        try {
            in = JavaUtil .class.getClassLoader().getResourceAsStream(configName);
            isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
            bf = new BufferedReader(isr);
            props.load(bf);
            value = props.getProperty(key);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (bf != null)
                    bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (isr != null)
                    isr.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if (in != null)
                    in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        return value;
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    @SuppressWarnings("unused")
    public static Properties getProp(String fileName) {
        Properties props = new Properties();

        try (InputStreamReader in = new InputStreamReader(JavaUtil .class.getClassLoader().getResourceAsStream(fileName), "utf-8")) {
            props.load(in);
        } catch (IOException e) {
            System.out.println("Load properties file error! file name:" + fileName + "\n" + e);
        }
        return props;
    }

    /**
     * 读取资源文件
     * @param key: key
     * @return String: 结果
     */
    public static String get(String key,Properties props) {
        return props.getProperty(key);
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    public static BufferedReader readFile(String fileName) {
        BufferedReader buff = null;
        try{
            InputStreamReader in = new InputStreamReader(JavaUtil .class.getClassLoader().getResourceAsStream(fileName), "utf-8");
            buff = new BufferedReader(in);
        }catch(IOException ignored){

        }
        return buff;
    }


    /**
     * 读取资源文件
     * @param fileName: 文件名
     * @return String: 结果
     */
    public static InputStream readFileAsIn(String fileName) {
        InputStream ins = null;
        try {
            ins = JavaUtil .class.getClassLoader().getResourceAsStream(fileName);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ins;
    }

    /**
     *
     * @param time
     *           时间
     * @param num
     *           加的数，-num就是减去
     * @return
     *          减去相应的数量的天的日期
     * @throws ParseException Date
     */
    public static String dayAddNum(String time, Integer num) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        Date date = format.parse(time);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, num);
        Date newTime = calendar.getTime();
        return format.format(newTime);
    }

    public static String getNewDayFormat(String day){
        Date parse = null;
        String dateString = "";
        try {
            parse = new SimpleDateFormat("yyyyMMdd").parse(day);
            dateString = new SimpleDateFormat("yyyy-MM-dd").format(parse);
        } catch (ParseException e) {
            dateString=null;
        }

        return dateString;
    }


    public static String getNewDayFormat1(String day){
        Date parse = null;
        String dateString = "";
        try {
            parse = new SimpleDateFormat("yyyy-MM-dd").parse(day);
            dateString = new SimpleDateFormat("yyyyMMdd").format(parse);
        } catch (ParseException e) {
            dateString=null;
        }

        return dateString;
    }

    public static void main(String[] args) {

//        List<String> betweenDatesStr = getBetweenDatesStr("2018-06-25", "2018-07-05");
//        System.out.println(betweenDatesStr);
//        String name =  JavaUtil.class.getClass().getName();
//        String name =  JavaUtil.class.getName();
//        System.out.println("name:"+name);
//
//        String name1 = get("rds.properties","oms.mysql.driver");
//        System.out.println(name1);


    }

}
