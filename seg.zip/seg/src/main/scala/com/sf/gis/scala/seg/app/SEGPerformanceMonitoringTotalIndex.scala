package com.sf.gis.scala.seg.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.seg.util.{DbUtils, JavaUtil, MD5Util, Util}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 获取seg服务总性能数据，然后存入Mysql
 */
object SEGPerformanceMonitoringTotalIndex {

  @transient lazy val logger: Logger = Logger.getLogger(SEGPerformanceMonitoringTotalIndex.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  /**
   * 获取SparkSession，执行业务逻辑
   * @param args 当天统计时间(yyyyMMdd)
   */
  def main(args: Array[String]): Unit = {

    val incDay = args(0)

    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    getSegTotalIndex(spark,incDay)

    spark.catalog.clearCache()

    spark.close()
  }


  /**
   * 统计seg服务总性能指标，然后写入Mysql表
   * @param spark
   * @param parDay
   * configFile ： Mysql配置文件
   * descTableName ： Mysql目标表
   */
  def getSegTotalIndex(spark:SparkSession,parDay:String)={
    println(parDay)

    val stat_date = JavaUtil.getNewDayFormat(parDay)
    println(stat_date)

    val configFile = "addr.properties"

    val descTableName = "SEG_MONITORING_TOTAL_INDEX"

    val querySql =
      s"""
         |select
         |  logs
         |from dm_gis.ods_kafka_bee_logs_gis_rss_seg
         |where inc_day = '$parDay'
       """.stripMargin

    val calSql_1 =
      s"""
         |SELECT
         |	 t1.dates						AS dates
         |	,split(t1.name,'-')[1]      	AS srName
         |	,sum(t1.req_total)             	AS req_totals
         |	,sum(t1.res_total)             	AS res_totals
         |	,sum(t1.res_time)              	AS res_times
         |FROM
         |(
         |	SELECT
         |		 tt1.dates 																AS dates
         |		,tt1.name 																AS name
         |		,count(case when tt1.types = 'url_s' then tt1.types else null end) 		AS req_total
         |		,count(case when tt1.types = 'url_e' then tt1.types else null end) 		AS res_total
         |		,sum(case when tt1.types = 'url_e' then tt1.times else 0 end)			AS res_time
         |	FROM
         |	(
         |		SELECT
         |			 ttt1.dates 								AS dates
         |			,concat(ttt1.random,'-',ttt1.serviceName) 	AS name
         |			,ttt1.types									AS types
         |			,ttt1.times         						AS times
         |		FROM
         |		(
         |			SELECT
         |				 dates
         |				,CASE WHEN SPLIT(ak,' ')[1]='14e9ee810854c40f5ae9414f2a62c8cc' THEN 'segcx' ELSE 'seg' END AS serviceName
         |				,types
         |				,times
         |				,SPLIT(ak,' ')[0] AS random
         |			FROM gis_ass_adds_log_parse
         |      WHERE dates = '$stat_date'
         |		) ttt1
         |	) tt1
         |	GROUP BY
         |		 tt1.dates
         |		,tt1.name
         |)t1
         |GROUP BY
         |	 t1.dates
         |	,split(t1.name,'-')[1]
         |""".stripMargin

    val calSql_2 =
      s"""
         |SELECT
         |	 dates
         |	,'seg' 					AS name
         |	,times
         |	,row_number() over(ORDER BY times)      AS rn
         |FROM gis_ass_adds_log_parse
         |WHERE types = 'url_e' AND dates = '$stat_date'
         |AND SPLIT(ak,' ')[1] != '14e9ee810854c40f5ae9414f2a62c8cc'
         |
         |UNION ALL
         |
         |SELECT
         |	 dates
         |	,'segcx' 				AS name
         |	,times
         |	,row_number() over(ORDER BY times)      AS rn
         |FROM gis_ass_adds_log_parse
         |WHERE types = 'url_e' AND dates = '$stat_date'
         |AND SPLIT(ak,' ')[1] = '14e9ee810854c40f5ae9414f2a62c8cc'
         |""".stripMargin

    val calSql_3 =
      s"""
         |SELECT
         |	 t1.dates 																	AS dates
         |	,t1.name 																	AS serviceName
         |  ,'ALL'                                    AS ak
         |	,t1.req_total 																AS req_total
         |	,CASE WHEN t1.avg_res_time is null THEN '0' ELSE t1.avg_res_time END AS avg_res_time
         |	,SUM(CASE WHEN t1.rn = t1.equal_90 THEN t1.times ELSE 0 END) 				AS times_90
         |	,SUM(CASE WHEN t1.rn = t1.equal_95 THEN t1.times ELSE 0 END) 				AS times_95
         |	,SUM(CASE WHEN t1.rn = t1.equal_99 THEN t1.times ELSE 0 END) 				AS times_99
         |FROM
         |	(
         |		SELECT
         |			 tt1.dates 												AS dates
         |			,tt1.name 												AS name
         |			,tt1.times 												AS times
         |			,tt1.rn 												AS rn
         |			,tt1.req_total 											AS req_total
         |			,CAST((tt1.res_times/tt1.req_total) AS decimal(10,0))  AS avg_res_time
         |			,ROUND(tt1.res_total * 0.9) 							AS equal_90
         |			,ROUND(tt1.res_total * 0.95) 							AS equal_95
         |			,ROUND(tt1.res_total * 0.99) 							AS equal_99
         |		FROM
         |		(
         |			SELECT
         |				 ttt1.dates 												AS dates
         |				,ttt1.name 													AS name
         |				,ttt1.times 												AS times
         |				,ttt1.rn 													AS rn
         |				,ttt1.req_totals    										AS req_total
         |				,ttt1.res_totals    										AS res_total
         |				,ttt1.res_times     										AS res_times
         |			FROM
         |      seg_monitoring_total_join_temp ttt1
         |		) tt1
         |	) t1
         |WHERE t1.rn = t1.equal_90 OR t1.rn = t1.equal_95 OR t1.rn = t1.equal_99
         |GROUP BY
         |	 t1.dates
         |	,t1.name
         |	,t1.req_total
         |	,t1.avg_res_time
         |""".stripMargin

    val calSql_seg_ak =
      s"""
         |SELECT
         |	 t.dates 				AS dates
         |	,t.name 				AS serviceName
         |	,t.ak 					AS ak
         |	,t.req_total 			AS req_total
         |	,CASE WHEN t.avg_res_time is null THEN 0 ELSE t.avg_res_time END AS avg_res_time
         |	,SUM(times_90) 			AS times_90
         |	,SUM(times_95) 			AS times_95
         |	,SUM(times_99) 			AS times_99
         |FROM
         |(
         |	SELECT
         |		 t1.dates 												AS dates
         |		,t1.name 												AS name
         |		,t1.ak 													AS ak
         |		,t1.req_total 											AS req_total
         |		,CAST(t1.avg_res_time AS decimal(10,0)) 				AS avg_res_time
         |		,CASE WHEN t1.rn = t1.equal_90 THEN t1.times ELSE 0 END AS times_90
         |		,CASE WHEN t1.rn = t1.equal_95 THEN t1.times ELSE 0 END AS times_95
         |		,CASE WHEN t1.rn = t1.equal_99 THEN t1.times ELSE 0 END AS times_99
         |	FROM
         |	(
         |		SELECT
         |			 tt1.dates 													AS dates
         |			,tt1.name 													AS name
         |			,tt1.ak 													AS ak
         |			,tt1.times 													AS times
         |			,tt1.types 													AS types
         |			,tt1.req_total 												AS req_total
         |			,tt1.res_time/tt1.req_total									AS avg_res_time
         |			,case when tt1.types = 'url_e' then tt1.rn else null end 	AS rn
         |			,ROUND(tt1.res_total * 0.9) 				AS equal_90
         |			,ROUND(tt1.res_total * 0.95) 				AS equal_95
         |			,ROUND(tt1.res_total * 0.99) 				AS equal_99
         |		FROM
         |		(
         |			SELECT
         |				 ttt1.dates 																							AS dates
         |				,ttt1.name 																								AS name
         |				,ttt1.ak 																								AS ak
         |				,ttt1.times 																							AS times
         |				,ttt1.types 																							AS types
         |				,count(case when ttt1.types = 'url_s' then ttt1.types else null end) over(partition by ttt1.dates,ttt1.name,ttt1.ak) 														AS req_total
         |				,count(case when ttt1.types = 'url_e' then ttt1.types else null end) over(partition by ttt1.dates,ttt1.name,ttt1.ak) 														AS res_total
         |				,sum(case when ttt1.types = 'url_e' then times else 0 end) over(partition by ttt1.dates,ttt1.name,ttt1.ak)		AS res_time
         |				,row_number() over(partition by ttt1.types,ttt1.dates,ttt1.name,ttt1.ak order by ttt1.times) 								AS rn
         |			FROM
         |			(
         |				SELECT
         |					 dates
         |					,'seg' AS name
         |					,SPLIT(ak,' ')[1] AS ak
         |					,times
         |					,types
         |				FROM gis_ass_adds_log_parse
         |				WHERE SPLIT(ak,' ')[1] !='14e9ee810854c40f5ae9414f2a62c8cc'
         |			) ttt1
         |		) tt1
         |	) t1 WHERE t1.rn = t1.equal_90 or t1.rn = t1.equal_95 or t1.rn = t1.equal_99
         |) t
         |GROUP BY
         |	 t.dates
         |	,t.name
         |	,t.ak
         |	,t.req_total
         |	,t.avg_res_time
         |""".stripMargin

    logger.error(querySql)

    import spark.implicits._

    //获取来源表数据，然后解析logs字段，注册SparkSQL临时表
    logger.error(">>>>>>>>>>>>>>>>>开始解析logs，注册SparkSQL临时表")
    val queryDF = spark.sql(querySql).rdd.repartition(400).map(obj => {
      val logs = obj.toString()

      val rand = (Math.random() * 100).asInstanceOf[Int]

      var message = ("","","","",0)

      val msg = try{
        JSON.parseObject(JSON.parseArray(logs).get(0).toString).getJSONObject("message")
      }catch {
        case e:Exception => null
      }

      if(msg == null){
        logger.error(">>>>>>>>>>>>>>>>>>msg is null<<<<<<<<<<<<<<<<")
      }else{
        var types = ""
        var date_time = ""
        var dates = ""
        var ak = ""
        var times = 0
        try{
          types = msg.getString("type")
        }catch {
          case e:Exception => ""
        }
        try{
          date_time = msg.getString("dateTime")
          dates = date_time.substring(0,10)
        }catch {
          case e:Exception => ""
        }
        try{
          ak = rand + " " + msg.getJSONObject("url").getString("ak")
        }catch {
          case e:Exception => ""
        }
        try{
          times = msg.getInteger("time")
        }catch {
          case e:Exception => 0
        }
        message = (types,date_time,dates,ak,times)
      }

      message
    }).map(msg => Logs(msg._1,msg._2,msg._3,msg._4,msg._5))
      .toDF().persist(StorageLevel.DISK_ONLY)
    queryDF.createOrReplaceTempView("gis_ass_adds_log_parse")
    queryDF.printSchema()
    queryDF.show(5)

    logger.error(">>>>>>>>>>>>>>>>>开始统计seg性能指标-1: " + calSql_1)
    //val resultRDD_1 = spark.sql(calSql_1).rdd.persist(StorageLevel.DISK_ONLY)
    val resultRDD_1 = Util.getRowToJson1(spark,calSql_1,200)
    val smallRDD = spark.sparkContext.broadcast(resultRDD_1.collect())

    logger.error(">>>>>>>>>>>>>>>>>开始统计segcx性能指标-2: " + calSql_2)
    //val resultRDD_2 = spark.sql(calSql_2).rdd.persist(StorageLevel.DISK_ONLY)
    val resultRDD_2 = Util.getRowToJson1(spark,calSql_2,200)

    logger.error(">>>>>>>>>>>>>>>>>开始统计segcx性能指标-3: " + calSql_3)
    val resultRDD_3 = leftJoinRDD(spark,resultRDD_2,smallRDD,calSql_3)

    resultRDD_1.unpersist()
    resultRDD_2.unpersist()

    logger.error(">>>>>>>>>>>>>>>>>开始统计seg性能指标-4: " + calSql_seg_ak)
    val resultRDD_seg_ak = Util.getRowToJson(spark,calSql_seg_ak,200)
    queryDF.unpersist()
    spark.sql("drop table if exists gis_ass_adds_log_parse")

    val resultRDD = resultRDD_3.union(resultRDD_seg_ak).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>>>>>>>>>>>>>>>将统计seg性能指标写入hive表的数据量："+resultRDD.count())

    logger.error(">>>>>>>>>>>>>>>>>将统计seg性能指标写入hive表")
    saveResult2Hive(spark,resultRDD,parDay)

    logger.error(">>>>>>>>>>>>>>>>>将统计seg性能指标写入Mysql表")
    save2Mysql(resultRDD,configFile,descTableName,stat_date)

    resultRDD.unpersist()
    resultRDD_seg_ak.unpersist()

  }


  def leftJoinRDD(spark : SparkSession,resultRDD_2 : RDD[JSONObject],smallRDD : Broadcast[Array[JSONObject]],calSql_3 : String): RDD[JSONObject] ={

      val schemaString = "dates,name,times,rn,req_totals,res_totals,res_times"

      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))

      val schema = StructType(fields)

      val rdd = resultRDD_2.map(bigObj =>{
        val json = new JSONObject()

        val iter = smallRDD.value.iterator

        while(iter.hasNext){
          val records = iter.next()
          json.put(records.getString("dates") + "," + records.getString("srName"),records.getString("req_totals") + "," + records.getString("res_totals") + "," + records.getString("res_times"))
        }

        val dates = bigObj.getString("dates")
        val name = bigObj.getString("name")
        val times = bigObj.getString("times")
        val rn = bigObj.getString("rn")

        val key = dates + "," + name

        val littleTableValue = json.getOrDefault(key,",,").toString

        val req_totals = littleTableValue.split(",")(0)
        val res_totals = littleTableValue.split(",")(1)
        val res_times = littleTableValue.split(",")(2)

        (dates,name,times,rn,req_totals,res_totals,res_times)
      }).map(attr => Row(attr._1,attr._2,attr._3,attr._4,attr._5,attr._6,attr._7))

      val df = spark.createDataFrame(rdd,schema).persist(StorageLevel.DISK_ONLY)
      df.createOrReplaceTempView("seg_monitoring_total_join_temp")
      df.printSchema()
      df.show(5)

      logger.error(">>>>>>>>>>>>>>>>>开始统计segcx性能指标-3: " + calSql_3)
      val resultRDD_3 = Util.getRowToJson1(spark,calSql_3,200)

      resultRDD_3
  }

  /**
   * 保存数据到MySQL
   * @param resultRDD
   * @param configFile
   * @param descTableName
   */
  def save2Mysql(resultRDD : RDD[JSONObject],configFile : String,descTableName : String,stat_date : String) = {
    val javaUtil = new JavaUtil()
    javaUtil.setFlag(12)
    val conn = DbUtils.getConnection(javaUtil)

    val md5Instance = MD5Util.getMD5Instance

    try {
      logger.error(">>>>>>>>>开始插入数据库<<<<<<<<<<")

      val parDay = JavaUtil.getNewDayFormat1(stat_date)

      val delSql = String.format(s"delete from $descTableName where stat_date='%s'", parDay)
      logger.error(">>>保存之前，删除当天的数据:" + delSql)
      DbUtils.executeSql(conn, delSql)

      val insertSql = s"insert into $descTableName (`ID`,`STAT_DATE`,`SERVICE_NAME`,`AK`,`REQ_TOTAL`" +
        s",`AVG_RES_TIME`,`TIMES_90`,`TIMES_95`,`TIMES_99`) values(?,?,?,?,?,?,?,?,?)"

      logger.error(">>>>>>>>>insertSql<<<<<<<<<<: "+insertSql)

      var insertParams: Array[Any] = null

      resultRDD.collect().foreach(row => {
        val id = MD5Util.getMD5(md5Instance,Array(row.getString("dates"),row.getString("serviceName"),row.getString("ak")).mkString("_"))
        insertParams = Array(id,JavaUtil.getNewDayFormat1(row.getString("dates")),row.getString("serviceName"),row.getString("ak"),row.getString("req_total"),row.getString("avg_res_time"),row.getString("times_90"),row.getString("times_95"),row.getString("times_99"))

        DbUtils.execute(conn,insertSql,insertParams)
      })
      logger.error(s">>>>>>>>>>>指标入库量: ${resultRDD.count()}<<<<<<<<<<<<<")

    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }



  /**
   *
   * @param spark
   * @param
   */
  def saveResult2Hive(spark : SparkSession,resultRDD : RDD[JSONObject],parDay : String): Unit ={
    //目标库表名称
    val descDBName = "default"
    val descTableName = "seg_monitoring_total_index"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay')
         |SELECT
         | *
         |FROM seg_monitoring_total_index_temp
         |""".stripMargin

    try{
      val schemaString = "id,dates,serviceName,ak,req_total,avg_res_time,times_90,times_95,times_99"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)

      val rdd = resultRDD.coalesce(20).map(obj => {
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance,Array(obj.getString("dates"),obj.getString("serviceName")).mkString("_"))
        val dates = JavaUtil.getNewDayFormat1(obj.getString("dates"))

        val sb = new StringBuilder()
        sb.append(id).append("\t\t\t")
        sb.append(dates).append("\t\t\t")
        sb.append(obj.getString("serviceName")).append("\t\t\t")
        sb.append(obj.getString("ak")).append("\t\t\t")
        sb.append(obj.getString("req_total")).append("\t\t\t")
        sb.append(obj.getString("avg_res_time")).append("\t\t\t")
        sb.append(obj.getString("times_90")).append("\t\t\t")
        sb.append(obj.getString("times_95")).append("\t\t\t")
        sb.append(obj.getString("times_99")).append("\t\t\t")

        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
        ,attr(5),attr(6),attr(7),attr(8)))

      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("seg_monitoring_total_index_temp")

      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }


case class Logs(types : String,date_time : String,dates : String,ak : String,times : Int)



}
