package com.sf.gis.scala.seg.app

import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:匡可心
 * @Author: 01374443
 * @CreateTime: 2023-10-10 18:32
 * @TaskId:856101
 * @TaskName:seg测试环境测试-获取工单
 * @Description:seg跑测试环境测试使用
 */
object AddsRunSitTestGetTestData {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)


  def groupByAddrAk(sparkSession: SparkSession, incDay: String, randomValue: Int) = {
    val groupTableName = "dm_gis.dwd_gis_ass_adds_log_parse_groupby_address_ak_mid"

    val sql =
      s"""
         |insert overwrite  table ${groupTableName} partition(inc_day='${incDay}')
         |select `type`,`datetime`,`date`,ak,`time`,src,detailsrc,sn,province,city,county,town,adcode,citycode,detailaddr,orderno,istown,address,level,
         |origin,compare,showcode,province_code,citylev_code,county_code,town_code,result,multiple,`mark`,addresssuffix,province_req,city_req,county_req,
         |town_req,conflict,morethan,opt,lng,lat,tip_province,tip_city,tip_county,tip_town,rand()*${randomValue},la from (
         |    select a.*, row_number() over(partition by address,ak order by rand()) as rank from  dm_gis.gis_ass_adds_log_parse a where
         |    inc_day='${incDay}' and type='url_e' and  address not like 'DE#%') b where  rank = 1
         |""".stripMargin
    logger.error(sql)
    sparkSession.sql(sql)

    val groupTableCnt = sparkSession.sql(s"select count(1) from ${groupTableName} where inc_day='${incDay}' ").collect()(0).getLong(0)
    logger.error("排重后数据量:" + groupTableCnt)
    (groupTableName, groupTableCnt)
  }

  def queryTargetCntData(sparkSession: SparkSession, groupTableName: String,
                         groupTableCnt: Long,
                         randomValue: Int,
                         incDay: String) = {
    val limitTableName = "dm_gis.dwd_gis_ass_adds_log_parse_random_1000w_mid"
//    var limitCnt = 10000000*1.0 / groupTableCnt * 1.2 * randomValue
    var limitCnt = randomValue*2
    logger.error("limitCnt:" + limitCnt)
    val sql =
      s"""
         |insert overwrite  table ${limitTableName}  partition(inc_day='${incDay}')
         |select  `type`,`datetime`,`date`,ak,`time`,src,detailsrc,sn,province,city,county,town,adcode,citycode,detailaddr,orderno,istown,address,
         |level,origin,compare,showcode,province_code,citylev_code,county_code,town_code,result,multiple,`mark`,addresssuffix,province_req,city_req,
         |county_req,town_req,conflict,morethan,opt,lng,lat,tip_province,tip_city,tip_county,tip_town,rand_value,la
         |from ${groupTableName} where inc_day='${incDay}' and rand_value<${limitCnt}
         |
         |""".stripMargin
    logger.error(sql)
    sparkSession.sql(sql)
    limitTableName
  }

  def queryRunData(sparkSession: SparkSession, incDay: String, limitTableName: String) = {
    val runDataTableName = "dm_gis.dwd_gis_ass_adds_log_parse_random_1000w_run_data_mid"
    val sql =
      s"""
         |insert overwrite table ${runDataTableName}
         |select md5(concat(province_req,'_',city_req,'_',county_req,'_',
         |town_req,'_',address,'_',opt,'_',origin,'_',level)),
         |regexp_replace(province_req, '[\\r\\n\\0\\t,\\.\\"]+', '') province_req,
         |regexp_replace(city_req, '[\\r\\n\\0\\t,\\.\\"]+', '')city_req,
         |regexp_replace(county_req, '[\\r\\n\\0\\t,\\.\\"]+', '')county_req,
         |regexp_replace(town_req, '[\\r\\n\\0\\t,\\.\\"]+', '')town_req,
         |regexp_replace(address, '[\\r\\n\\0\\t,\\.\\"]+', '') address,
         |regexp_replace(opt, '[\\r\\n\\0\\t,\\.\\"]+', '') opt,
         |regexp_replace(origin, '[\\r\\n\\0\\t,\\.\\"]+', '') origin,
         |regexp_replace(level, '[\\r\\n\\0\\t,\\.\\"]+', '') level,
         |regexp_replace(la, '[\\r\\n\\0\\t,\\.\\"]+', '') la
         |from ${limitTableName} where inc_day='${incDay}'
         |group by province_req,city_req,county_req,town_req,address,opt,origin,level,la
         |""".stripMargin
    logger.error(sql)
    sparkSession.sql(sql)
  }

  def start(incDay: String): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    logger.error("获取按地址ak排重后的随机数据")
    val randomValue = 20000000
    val (groupTableName, groupTableCnt) = groupByAddrAk(sparkSession, incDay, randomValue)
    logger.error("获取指定数量的数据")
    val limitTableName = queryTargetCntData(sparkSession, groupTableName, groupTableCnt, randomValue, incDay)
    logger.error("按照接口字段排重取数据")
    queryRunData(sparkSession, incDay, limitTableName)
    logger.error("生成数据完毕")
  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    logger.error("incDay:" + incDay)
    start(incDay)
  }

  //  CREATE TABLE `tmp_dm_gis.tmp_gis_ass_adds_log_parse_01374443_groupby_address_ak`(
  //    `type` string,
  //    `datetime` string,
  //    `date` string,
  //    `ak` string,
  //    `time` int,
  //    `src` string,
  //    `detailsrc` string,
  //    `sn` string,
  //    `province` string,
  //    `city` string,
  //    `county` string,
  //    `town` string,
  //    `adcode` string,
  //    `citycode` string,
  //    `detailaddr` string,
  //    `orderno` string,
  //    `istown` string,
  //    `address` string COMMENT '请求查询的地址',
  //  `level` string COMMENT '地址级别',
  //  `origin` string COMMENT 'town信息',
  //  `compare` string COMMENT '对比是否一致',
  //  `showcode` string COMMENT '是否显示省市区街道编码',
  //  `province_code` string COMMENT '省编码，六位',
  //  `citylev_code` string COMMENT '市编码，六位',
  //  `county_code` string COMMENT '区（县）编码，六位',
  //  `town_code` string COMMENT '镇（街道）编码，十二位',
  //  `result` string COMMENT '对比传入的省市区与服务端返回的结果是否一致',
  //  `multiple` string COMMENT '输入地址是否符合规范',
  //  `mark` string COMMENT '请求地址中是否包含省市区任意信息',
  //  `addresssuffix` string COMMENT '系统识别的详细地址（带街道）',
  //  `province_req` string COMMENT '请求查询的省',
  //  `city_req` string COMMENT '请求查询的市',
  //  `county_req` string COMMENT '请求查询的区',
  //  `town_req` string COMMENT '请求查询的街道',
  //  `conflict` string COMMENT '对比传入的省市区与服务端返回的结果是否一致',
  //  `morethan` string COMMENT '判断输入地址是否有多个省市区街道',
  //  `opt` string COMMENT '请求查询的模块',
  //  `lng` string COMMENT '经度',
  //  `lat` string COMMENT '纬度',
  //  `tip_province` string COMMENT 'tipProvince',
  //  `tip_city` string COMMENT 'tipCity',
  //  `tip_county` string COMMENT 'tipCounty',
  //  `tip_town` string COMMENT 'tipTown',
  //  `rand_value` double,
  //   `la` string
  //  )
  //  PARTITIONED BY (
  //    `inc_day` string)
  //  ROW FORMAT SERDE
  //  'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
  //  WITH SERDEPROPERTIES (
  //    'field.delim'='\u0001',
  //  'line.delim'='\n',
  //  'serialization.format'='\u0001')

  //******************

  //  CREATE TABLE `tmp_dm_gis.tmp_gis_ass_adds_log_parse_01374443_random_1000w`(
  //    `type` string,
  //    `datetime` string,
  //    `date` string,
  //    `ak` string,
  //    `time` int,
  //    `src` string,
  //    `detailsrc` string,
  //    `sn` string,
  //    `province` string,
  //    `city` string,
  //    `county` string,
  //    `town` string,
  //    `adcode` string,
  //    `citycode` string,
  //    `detailaddr` string,
  //    `orderno` string,
  //    `istown` string,
  //    `address` string COMMENT '请求查询的地址',
  //  `level` string COMMENT '地址级别',
  //  `origin` string COMMENT 'town信息',
  //  `compare` string COMMENT '对比是否一致',
  //  `showcode` string COMMENT '是否显示省市区街道编码',
  //  `province_code` string COMMENT '省编码，六位',
  //  `citylev_code` string COMMENT '市编码，六位',
  //  `county_code` string COMMENT '区（县）编码，六位',
  //  `town_code` string COMMENT '镇（街道）编码，十二位',
  //  `result` string COMMENT '对比传入的省市区与服务端返回的结果是否一致',
  //  `multiple` string COMMENT '输入地址是否符合规范',
  //  `mark` string COMMENT '请求地址中是否包含省市区任意信息',
  //  `addresssuffix` string COMMENT '系统识别的详细地址（带街道）',
  //  `province_req` string COMMENT '请求查询的省',
  //  `city_req` string COMMENT '请求查询的市',
  //  `county_req` string COMMENT '请求查询的区',
  //  `town_req` string COMMENT '请求查询的街道',
  //  `conflict` string COMMENT '对比传入的省市区与服务端返回的结果是否一致',
  //  `morethan` string COMMENT '判断输入地址是否有多个省市区街道',
  //  `opt` string COMMENT '请求查询的模块',
  //  `lng` string COMMENT '经度',
  //  `lat` string COMMENT '纬度',
  //  `tip_province` string COMMENT 'tipProvince',
  //  `tip_city` string COMMENT 'tipCity',
  //  `tip_county` string COMMENT 'tipCounty',
  //  `tip_town` string COMMENT 'tipTown',
  //  `rand_value` double,
  //  `la` string)
  //  PARTITIONED BY (
  //    `inc_day` string)
  //  ROW FORMAT SERDE
  //  'org.apache.hadoop.hive.ql.io.orc.OrcSerde'
  //  WITH SERDEPROPERTIES (
  //    'field.delim'='\u0001',
  //  'line.delim'='\n',
  //  'serialization.format'='\u0001')

  //*********************
  //  CREATE TABLE `tmp_dm_gis.tmp_gis_ass_adds_log_parse_01374443_random_1000w_run_data`(
  //    `md5` string,
  //    `province_req` string,
  //    `city_req` string,
  //    `county_req` string,
  //    `town_req` string,
  //    `address` string,
  //    `opt` string,
  //    `origin` string,
  //    `level` string,
  //    `la` string)
  //  ROW FORMAT SERDE
  //  'org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe'
  //  WITH SERDEPROPERTIES (
  //    'field.delim'='\t',
  //  'line.delim'='\n',
  //  'serialization.format'='\t')
  //  STORED AS INPUTFORMAT
  //  'org.apache.hadoop.mapred.TextInputFormat'
  //  OUTPUTFORMAT
  //  'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
}
