package com.sf.gis.scala.seg.app

import java.net.URLEncoder
import java.time.{Duration, Instant}
import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.SaveResultUtil
import com.sf.gis.scala.seg.bean.Waybill
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.io.Source

/*
select
  *,
  alldist / allamount as allper,
  dispatchdist / dispatchamount as disper,
  zydist / zyamount as zyper
from
  dm_gis.address_agg_value_conversion_dist t1
  join (
    select
      tmp1.empcode
    from
      (
        select
          empcode,
          count(distinct incday) cnt
        from
          dm_gis.address_agg_value_conversion_dist
        where
          inc_day = '20200624'
          and substr(incday, 0, 4) = '2020'
          and dispatchdist != 0
        group by
          empcode
        having
          cnt >= 10
      ) tmp1
      join (
        select
          empcode,
          count(distinct incday) cnt
        from
          dm_gis.address_agg_value_conversion_dist
        where
          inc_day = '20200624'
          and substr(incday, 0, 4) = '2019'
          and dispatchdist != 0
        group by
          empcode
        having
          cnt >= 10
      ) tmp2 on tmp1.empcode = tmp2.empcode
    where
      tmp1.cnt - tmp2.cnt > -7
      and tmp1.cnt - tmp2.cnt < 7
  ) t2
on t1.empcode = t2.empcode
where
  t1.inc_day = '20200624'
* */
/**
 *  源头和结果数据都为空，先注释，待删除， 01374443 20231025
 */
object AddressAggregationValueConversionByAll {
//  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//  //派件难度-特殊入仓与电梯（GIS-ASS-ADDS）接口
//  val vasUrl= "http://gis-int2.int.sfdc.com.cn:1080/diff/api/vas?address=%s&citycode=%s&opt=ataoi&ak=8bb09e5e110845f39a000391668e3e80"
//
//  //地址聚合服务接口
//  val addAggUrl = "http://gis-int2.int.sfdc.com.cn:1080/agg/api/AddressAggregation?address=%s&citycode=%s&level=13&ak=11fbd8a3b26545fa9df84ded1f3debb3"
//
//  //常规骑行服务
//  val rpUrl = "http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&opt=sf1&type=1&strategy=0&ak=fb4065ab53174149a49d31fe0ce1d8b9"

//  val empcodeSpeedPath = "小哥交通工具默认速度.csv"
//  val saveLostBillTable= "Address_Agg_value_Conversion_LostBill"
//  val saveTimeCostTable = "Address_Agg_value_SaveTimeCost"
//  val parDate = "20200624"
//
//  def main(args: Array[String]): Unit = {
//    val spark = Spark.getSparkSession(appName)
//
//    //flag=0 计算漏单率，入库且计算时间成本；flag=1 只计算楼漏单率且入库；flag=2 不计算漏单率，只计算时间成本
//    val flag = if (args.length == 0) "0" else args(0)
//
//    println(s"flag=$flag")
//
//
//    if (flag == "0" || flag == "1" || flag == "2") {
//
//      val rdd = getDispatchData(spark)
//
//      if (flag == "1")
//      //计算漏单率入库
//      calculateMissedOrders(rdd,spark)
//
//      if (flag == "2")
//      //计算时间成本
//      calculateSaveTimeCosts(rdd,spark)
//
//      if (flag == "0"){
//        //计算漏单率
//        calculateMissedOrders(rdd,spark)
//        //计算时间成本
//        calculateSaveTimeCosts(rdd,spark)
//      }
//    }else{
//      logger.error("请输入正确参数如：0,1,2")
//    }
//
//    spark.close()
//  }
//
//  def calculateSaveTimeCosts(rdd:RDD[Waybill],spark:SparkSession) {
//    val dispuchRDD = rdd.filter( obj => StringUtils.isNoneBlank(obj.getAoiid()) )
//      .map(obj => {
//          ((obj.getCouriercode,obj.getIncday,obj.getZonecode,obj.getCitycode),obj)
//       }).groupByKey().map(obj => {
//          val list = obj._2.toList
//          (obj._1,list)
//       }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error(s"按工号聚合后的派件数据:${dispuchRDD.count()}")
//
//    val empList = dispuchRDD.keys.map(_._1).collect().toList.distinct
//
//    //获取收件数据
//    val recieveMap = getRecieveMap(spark,empList)
//
//    //关联收件派件数据
//    val joinRDD = getJoinRDD(dispuchRDD,recieveMap)
//
//    //根据aoiid查询aoi坐标
//    val aoiRDD = getAoiRDD(joinRDD)
//
//    //aoiRDD.collect().foreach(logger.error)
//
//    //调用常规骑行接口,计算小哥折返路程
//    val returnJourneyRDD = getReturnJourney(aoiRDD)
//
//    //returnJourneyRDD.collect().foreach(logger.error)
//
//    //入库到hive
//    SaveResultUtil.saveResult(logger,spark,returnJourneyRDD,saveReturnJourney,"address_agg_value_conversion_dist",parDate)
//  }
//
//  val saveReturnJourney = (saveRDD:RDD[JSONObject],path:String) => {
//    saveRDD.map(obj => {
//      val sb = new StringBuilder()
//      sb.append(obj.getString("empCode")).append("\t")
//      sb.append(obj.getString("incday")).append("\t")
//      sb.append(obj.getString("zc")).append("\t")
//      sb.append(obj.getString("citycode")).append("\t")
//      sb.append(obj.getString("allAmount")).append("\t")
//      sb.append(obj.getString("dispatchAmount")).append("\t")
//      sb.append(obj.getString("zyAmount")).append("\t")
//      sb.append(obj.getString("allDist")).append("\t")
//      sb.append(obj.getString("dispatchDist")).append("\t")
//      sb.append(obj.getString("zyDist"))
//
//      sb.toString()
//    }).saveAsTextFile(path)
//  }
//
//  def getReturnJourney(joinRDD: RDD[((String, String, String, String), List[Waybill])]):RDD[JSONObject]={
//
//    logger.error(">>>计算骑行服务开始<<<")
//    val returnJourneyRDD = joinRDD.map(elem =>{
//      var allDist = 0d
//      var dispatchDist = 0d
//      var zyDist = 0d
//      val list =  elem._2
//
//      //截取最早和最晚派件之间的收件派件订单
//      var sortList = list.sortWith((e1,e2) => e1.getTimeps.compareTo(e2.getTimeps) < 0)
//      val firstDipu = sortList.indexWhere( _.isDispatch )
//      val lastDipu = sortList.lastIndexWhere( _.isDispatch )
//      sortList = sortList.slice( firstDipu,lastDipu + 1)
//
//      val dispatchList = sortList.filter(_.isDispatch)
//
//      var zyList = List[Waybill]()
//      var keyList = List[String]()
//
//      //最优路径，取aoi第一次出现的值
//      dispatchList.map(elem => {
//        if(! keyList.contains(elem.getAoix+elem.getAoiy)){
//          zyList = elem :: zyList
//          keyList = (elem.getAoix+elem.getAoiy) :: keyList
//        }
//      })
//
//      //计算收件派件全量里程
//      if (sortList.size > 1){
//        allDist = calDist(sortList)
//      }
//
//      //计算收件里程
//      if (dispatchList.size > 1){
//        dispatchDist = calDist(dispatchList)
//      }
//
//      //计算最优路径里程
//      if (zyList.size > 1){
//        zyDist = calDist(zyList)
//      }
//
//      val json = new JSONObject()
//      json.put("empCode",elem._1._1)
//      json.put("incday",elem._1._2)
//      json.put("zc",elem._1._3)
//      json.put("citycode",elem._1._4)
//      json.put("allAmount",sortList.size)
//      json.put("dispatchAmount",dispatchList.size)
//      json.put("zyAmount",zyList.size)
//      json.put("allDist",allDist)
//      json.put("dispatchDist",dispatchDist)
//      json.put("zyDist",zyDist)
//
//      json
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error("获取有效行程个数：" +  returnJourneyRDD.count)
//
//    returnJourneyRDD
//  }
//
//  def calDist(list:List[Waybill]) ={
//    var dist = 0d
//    var resp = ""
//
//    for(i <- 1 until list.size -1 ){
//      val previous = list(i-1)
//      val current = list(i)
//      val query = String.format( rpUrl,previous.getAoix,previous.getAoiy,current.getAoix,current.getAoiy )
//
//      //调用骑行服务接口
//
//      var json = new JSONObject()
//
//      try{
//        resp = Source.fromURL(query, "utf-8").mkString
//        json = JSON.parseObject(resp)
//      } catch {
//        case e:Exception => logger.error(e)
//          resp = Source.fromURL(query, "utf-8").mkString
//          json = JSON.parseObject(resp)
//      }
//
//      val status = json.getInteger("status")
//      if (status == 0) {
//        val distString = json.getJSONObject("result").getString("dist")
//
//        if (StringUtils.isNotBlank(distString) )
//          dist += distString.toDouble
//      }
//    }
//
//    dist
//  }
//
//  def getAoiRDD(joinRDD: RDD[((String, String, String, String), scala.List[Waybill])])={
//
//    logger.error(">>>开始查询aoi坐标<<<")
//
//    val aoiRDD = joinRDD.map(obj => {
//      var aoilist =  List[Waybill]()
//
//      obj._2.foreach(elem => {
//        val query = String.format(aoiUrl,elem.getAoiid)
//        val resp = Source.fromURL(query, "utf-8").mkString
//
//        elem.setAoiResp(resp)
//
//        var aoiX = ""
//        var aoiY = ""
//
//        try {
//          val central_coord =  JSON.parseObject(resp).getJSONObject("result").getJSONArray("data").getJSONObject(0).getJSONObject("central_coord")
//          aoiX =  central_coord.getString("x")
//          aoiY = central_coord.getString("y")
//        } catch { case e:Exception => }
//
//        elem.setAoix(aoiX)
//        elem.setAoiy(aoiY)
//        aoilist = elem :: aoilist
//      })
//
//      aoilist = aoilist.filter(elem => StringUtils.isNoneBlank(elem.getAoix) && StringUtils.isNoneBlank(elem.getAoiy))
//
//      (obj._1,aoilist)
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    aoiRDD
//  }
//
//  def getJoinRDD(dispuchRDD: RDD[((String, String, String, String), scala.List[Waybill])],recieveMap: Map[(String, String, String, String), scala.List[Waybill]])={
//
//    //关联收件和派件订单
//    val joinRDD = dispuchRDD.map(obj => {
//      var arr = obj._2
//
//      //按工号合并收件和派件
//      if (recieveMap.contains(obj._1)) {
//        arr = obj._2 ::: recieveMap.get(obj._1).get
//      }
//
//      (obj._1,arr)
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    joinRDD
//  }
//
//  def getRecieveMap(spark: SparkSession,empList:List[String])={
//    logger.error(">>>开始获取收件数据<<<")
//
//    val querySql =
//      s"""
//         |select
//         | waybillno,
//         | userid,
//         | dept_code,
//         | operatime_new,
//         | consignor_addr,
//         | eventlng,
//         | eventlat
//         |from dm_tdos.middle_gis_pick_way_info
//         |where dt='$parDate' and userid in ('${empList.mkString("','")}')
//         | and eventlng is not null and eventlng <> '' and eventlng <>'null'
//         | and eventlat is not null and eventlat <> '' and eventlat <>'null'
//         | and consignor_addr is not null and consignor_addr <> '' and consignor_addr <>'null'
//         | and dept_code is not null and dept_code <> '' and dept_code <>'null'
//         | and waybillno is not null and waybillno <> '' and waybillno <>'null'
//         |""".stripMargin
//
//    logger.error(querySql)
//
//    //获取收件数据
//    val recieveRDD = spark.sql(querySql)
//      .rdd.repartition(50).map(obj => {
//      val waybill = new Waybill
//      waybill.setWaybillno(obj.getString(0))
//      waybill.setCouriercode(obj.getString(1))
//      waybill.setZonecode(obj.getString(2))
//      waybill.setTimeps(obj.getString(3))
//      waybill.setConsigneeaddr(obj.getString(4))
//      waybill.setLongitude(obj.getString(5))
//      waybill.setLatitude(obj.getString(6))
//      waybill.setCitycode(obj.getString(2).substring(0, 3))
//      waybill.setIncday(obj.getString(3).substring(0, 10).replaceAll("-", ""))
//      waybill.setKeyword("")
//      waybill.setAoiid("")
//      waybill.setStatus(1)
//      waybill.setDispatch(false)
//
//      waybill
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error(s">>>获取收件数据：${recieveRDD.count()}<<<")
//
//    //跑地址聚合获取aoiid
//    val recieveMap = getKeyword(recieveRDD)
//      .filter( obj => StringUtils.isNoneBlank(obj.getAoiid()) )
//      .map(obj => {
//        ((obj.getCouriercode,obj.getIncday,obj.getZonecode,obj.getCitycode),obj)
//      }).groupByKey().map(obj => {
//        val list = obj._2.toList
//        (obj._1,list)
//      }).collect().toMap
//
//    //recieveMap.foreach(println)
//    logger.error(s"聚合收件数据：共${recieveMap.size}")
//
//    recieveMap
//  }
//
//  def calculateMissedOrders(rdd:RDD[Waybill],spark:SparkSession)={
//
//    val lostBillSaveRDD = keywordStat(rdd)
//
//    //入库到hive
//    SaveResultUtil.saveResult(logger,spark,lostBillSaveRDD,saveLostBill,saveLostBillTable,parDate)
//
//    lostBillSaveRDD
//  }
//
//  val saveLostBill = (saveRDD:RDD[JSONObject],path:String) => {
//    saveRDD.map(obj => {
//      val sb = new StringBuilder()
//      sb.append(obj.getString("城市")).append("\t")
//      sb.append(obj.getString("网点")).append("\t")
//      sb.append(obj.getString("日期")).append("\t")
//      sb.append(obj.getString("小哥")).append("\t")
//      sb.append(obj.getString("总量")).append("\t")
//      sb.append(obj.getString("漏单总量")).append("\t")
//      sb.append(obj.getString("漏单率"))
//
//      sb.toString()
//    }).saveAsTextFile(path)
//  }
//
//  def keywordStat(resultRdd:RDD[Waybill])= {
//    logger.error("计算漏单情况:")
//
//    val rdd = resultRdd.filter(obj => StringUtils.isNotBlank(obj.getKeyword))
//      .map(obj => {
//        ((obj.getCitycode, obj.getZonecode, obj.getIncday, obj.getCouriercode), obj)
//      }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error("查询数据量:" + rdd.count())
//    val start = Instant.now()
//
//    val keywordStatRDD = rdd.groupByKey().map(key => {
//      val list = key._2.toList.sortBy(el => (el.getTimeps, el.getKeyword))
//      var cnt = 0
//      val map = new util.HashMap[String, Integer]()
//
//      for (waybill <- list) {
//        if (map.get(waybill.getKeyword) == null) {
//          cnt += 1
//          map.put(waybill.getKeyword, cnt)
//        }
//      }
//
//      val set = new util.HashSet[String]()
//      val timeSet = new util.HashSet[String]()
//      var aggAddr = ""
//      var aggAoi = ""
//      var num = 0
//      var max = 0
//
//      for (waybill <- list) {
//        timeSet.add(waybill.getTimeps)
//        val next = (waybill.getKeyword.equals(aggAddr) && !"****".equals(waybill.getKeyword)) || ("****".equals(aggAddr) && aggAoi.equals(waybill.getAoiid))
//        if (next) {
//          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
//            num += 1
//          }
//        } else {
//          set.add(waybill.getKeyword)
//          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
//            num += 1
//          }
//        }
//        if (map.get(waybill.getKeyword) > max) {
//          max = map.get(waybill.getKeyword)
//        }
//        aggAddr = waybill.getKeyword
//        aggAoi = waybill.getAoiid
//      }
//
//      val jsonObj = new JSONObject()
//      jsonObj.put("城市",key._1._1)
//      jsonObj.put("网点",key._1._2)
//      jsonObj.put("日期",key._1._3)
//      jsonObj.put("小哥",key._1._4)
//      jsonObj.put("总量",list.size)
//      jsonObj.put("漏单总量",num)
//      jsonObj.put("漏单率",(num.toDouble/list.size).formatted("%.4f"))
//
//      jsonObj
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error("城市 网点 日期 小哥分组共：" +keywordStatRDD.count())
//
//    val end = Instant.now()
//    logger.error("统计耗时:" + Duration.between(start, end).getSeconds + "s")
//
//    keywordStatRDD
//  }
//
//  def getDispatchData(sparkSession: SparkSession)= {
//
//    val querySql = s"select * from dm_gis.address_agg_value_conversion_tempres where inc_day='$parDate' and  dispatch is not null"
//    //and couriercode in ('001038')
//    logger.error(querySql)
//
//    var vasRDD = sparkSession.sql(querySql).repartition(50).rdd.map(row => {
//
//      val waybill = new Waybill
//      waybill.setWaybillno(row.getString(0))
//      waybill.setCouriercode(row.getString(1))
//      waybill.setZonecode(row.getString(2))
//      waybill.setTimeps(row.getString(3))
//      waybill.setConsigneeaddr(row.getString(4))
//      waybill.setLongitude(row.getString(5))
//      waybill.setLatitude(row.getString(6))
//      waybill.setCitycode(row.getString(7))
//      waybill.setIncday(row.getString(8))
//      waybill.setKeyword(row.getString(9))
//      waybill.setAoiid(row.getString(10))
//      waybill.setStatus(row.getInt(11))
//      waybill.setLongitude_s(row.getString(12))
//      waybill.setLatitude_s(row.getString(13))
//      waybill.setDispatch(row.getBoolean(14))
//
//      waybill
//
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    val cnt = vasRDD.count()
//
//    logger.error(s">>>从缓存中查询派件共:$cnt<<<")
//
//    if ( 0 == cnt ) {
//      vasRDD =  getSourDispatchRDD(sparkSession)
//    }
//
//    vasRDD
//  }
//
//  def getSourDispatchRDD(sparkSession: SparkSession) = {
//    logger.error(">>>从源数据中查询派件<<<")
//
//    val dispatchTable = "dm_tdos.application_gis_way_info"
//
//    //获取派件数据并过滤掉客户声音数据
//    val sql =
//      s"""
//         | select
//         |        t1.waybillno,t1.80_userid,t1.80_user_dept,t1.80_operatime_new,t1.consignee_addr,t1.80_lng,t1.80_lat,t1.204_lng,t1.204_lat
//         |      from (
//         |          select
//         |          t1.waybillno,
//         |          t2.bill_no,
//         |          t1.80_userid,
//         |          t1.80_user_dept,
//         |          t1.80_operatime_new,
//         |          t1.consignee_addr,
//         |          t1.80_lng,
//         |          t1.80_lat,
//         |          t1.204_lng,
//         |          t1.204_lat
//         |          from dm_tdos.application_gis_way_info t1
//         |          left join ods_inc_sgs_core.tt_delivery_oms_change_record t2
//         |          on t1.waybillno = t2.bill_no
//         |          where t1.inc_day = '$parDate'
//         |          and t1.waybillno is not null and t1.waybillno <> '' and t1.waybillno <> 'null'
//         |          and t1.consignee_addr is not null and t1.consignee_addr <> 'null' and t1.consignee_addr <> ''
//         |          and t1.80_lng is not null and t1.80_lng <> 'null' and t1.80_lng <> ''
//         |          and t1.80_lat is not null and t1.80_lat <> 'null' and t1.80_lat <> ''
//         |          and t1.80_user_dept is not null and t1.80_user_dept <> 'null' and t1.80_user_dept <> ''
//         |) t1
//         |JOIN (
//         |           select tmp1.80_userid from (
//         |                select
//         |                  80_userid,
//         |                  count(distinct REGEXP_replace(substr(80_operatime_new, 0, 11),'-','')) cnt
//         |                from
//         |                  dm_tdos.application_gis_way_info
//         |                where
//         |                  inc_day = '$parDate' and substr(80_operatime_new, 0, 4)='2020'
//         |                group by
//         |                  80_userid
//         |                having cnt > 20
//         |            ) tmp1
//         |            join
//         |            (
//         |                select
//         |                  80_userid,
//         |                  count(distinct REGEXP_replace(substr(80_operatime_new, 0, 11),'-','')) cnt
//         |                from
//         |                  dm_tdos.application_gis_way_info
//         |                where
//         |                  inc_day = '$parDate' and substr(80_operatime_new, 0, 4)='2019'
//         |                group by
//         |                  80_userid
//         |                having cnt > 20
//         |            ) tmp2
//         |            on tmp1.80_userid = tmp2.80_userid
//         |            where tmp1.cnt - tmp2.cnt > -7 and tmp1.cnt - tmp2.cnt < 7
//         |) t2
//         | on  t1.80_userid = t2.80_userid
//         |where t1.bill_no is null
//        """.stripMargin
//
//      //and t1.80_userid in ('000354','005339','005400','01040680','01056704','01059318','01080461','01082249','01082465','01082560')
//
//      /*s"""
//      select
//        waybillno,80_userid,80_user_dept,80_operatime_new,consignee_addr,80_lng,80_lat,204_lng,204_lat
//      from (
//          select
//            t1.waybillno,
//            t2.bill_no,
//            t1.80_userid,
//            t1.80_user_dept,
//            t1.80_operatime_new,
//            t1.consignee_addr,
//            t1.80_lng,
//            t1.80_lat,
//            t1.204_lng,
//            t1.204_lat
//          from $dispatchTable t1
//          left join ods_inc_sgs_core.tt_delivery_oms_change_record t2
//          on t1.waybillno = t2.bill_no
//          where t1.inc_day = '$parDate'
//            and t1.waybillno is not null and t1.waybillno <> '' and t1.waybillno <> 'null'
//            and t1.consignee_addr is not null and t1.consignee_addr <> 'null' and t1.consignee_addr <> ''
//            and t1.80_lng is not null and t1.80_lng <> 'null' and t1.80_lng <> ''
//            and t1.80_lat is not null and t1.80_lat <> 'null' and t1.80_lat <> ''
//            and t1.80_user_dept is not null and t1.80_user_dept <> 'null' and t1.80_user_dept <> ''
//       ) tmp where tmp.bill_no is null and 80_userid in ('000354','005339','005400','01040680','01056704','01059318','01080461','01082249','01082465','01082560')
//      """.stripMargin*/
//
//    //and 80_userid in ('001038')
//
//    logger.error(sql)
//
//    val rdd = sparkSession.sql(sql).repartition(50).rdd.map(row => {
//
//      val waybill = new Waybill
//      waybill.setWaybillno(row.getString(0))
//      waybill.setCouriercode(row.getString(1))
//      waybill.setZonecode(row.getString(2))
//      waybill.setTimeps(row.getString(3))
//      waybill.setConsigneeaddr(row.getString(4))
//      waybill.setLongitude(row.getString(5))
//      waybill.setLatitude(row.getString(6))
//      waybill.setCitycode(row.getString(2).substring(0, 3))
//      waybill.setIncday(row.getString(3).substring(0, 10).replaceAll("-", ""))
//      waybill.setKeyword("")
//      waybill.setAoiid("")
//      waybill.setStatus(1)
//      waybill.setLongitude_s(row.getString(7))
//      waybill.setLatitude_s(row.getString(8))
//      waybill.setDispatch(true)
//
//      waybill
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error(s"过滤客户声音后获取派件数据：${rdd.count()}")
//
//    //跑派件难度-特殊入仓与电梯（GIS-ASS-ADDS）接口，获取C类区域（住宅区）运单
//    val vasRDD = getVasRDD(rdd)
//
//    val finalSourRDD = getKeyword(vasRDD)
//
//    val saveRDD = finalSourRDD.map(obj => {
//        val jsonObj = new JSONObject()
//        jsonObj.put("waybillno",obj.getWaybillno)
//        jsonObj.put("empCode",obj.getCouriercode)
//        jsonObj.put("zonecode",obj.getZonecode)
//        jsonObj.put("timeps",obj.getTimeps)
//        jsonObj.put("consigneeaddr",obj.getConsigneeaddr)
//        jsonObj.put("longitude",obj.getLongitude)
//        jsonObj.put("latitude",obj.getLatitude)
//        jsonObj.put("citycode",obj.getCitycode)
//        jsonObj.put("incday",obj.getIncday)
//        jsonObj.put("keyword",obj.getKeyword)
//        jsonObj.put("aoiid",obj.getAoiid)
//        jsonObj.put("status",obj.getStatus)
//        jsonObj.put("longitude_s",obj.getLongitude_s)
//        jsonObj.put("latitude_s",obj.getLatitude_s)
//        jsonObj.put("dispatch",obj.isDispatch)
//
//        jsonObj
//    })
//
//    //将过滤后的结果预存hive
//    SaveResultUtil.saveResult(logger,sparkSession,saveRDD,saveVas,"address_agg_value_conversion_tempres",parDate)
//
//    finalSourRDD
//  }
//
//  def getVasRDD(rdd: RDD[Waybill])={
//    val vasRDD = rdd.map(waybill => {
//
//      val query = String.format(vasUrl, URLEncoder.encode(waybill.getConsigneeaddr, "utf-8"), waybill.getCitycode)
//      val resp = Source.fromURL(query, "utf-8").mkString
//
//      val aoiTypeCode = try { JSON.parseObject(resp).getJSONObject("result").getJSONObject("adata").getString("aoitypecode") }
//      catch {case e: Exception => "-1"}
//
//      if ("120301".equals(aoiTypeCode) || "120302".equals(aoiTypeCode))
//        waybill
//      else null
//
//    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error(s"获取c类区域订单：${vasRDD.count()}\n\n\n")
//
//    rdd.unpersist()
//
//
//    vasRDD
//  }
//
//  val saveVas = (saveRDD: RDD[JSONObject],path:String) => {
//    saveRDD.map(obj => {
//      val sb = new StringBuilder()
//      sb.append(obj.getString("waybillno")).append("\t")
//      sb.append(obj.getString("empCode")).append("\t")
//      sb.append(obj.getString("zonecode")).append("\t")
//      sb.append(obj.getString("timeps")).append("\t")
//      sb.append(obj.getString("consigneeaddr")).append("\t")
//      sb.append(obj.getString("longitude")).append("\t")
//      sb.append(obj.getString("latitude")).append("\t")
//      sb.append(obj.getString("citycode")).append("\t")
//      sb.append(obj.getString("incday")).append("\t")
//      sb.append(obj.getString("keyword")).append("\t")
//      sb.append(obj.getString("aoiid")).append("\t")
//      sb.append(obj.getInteger("status")).append("\t")
//      sb.append(obj.getString("longitude_s")).append("\t")
//      sb.append(obj.getString("latitude_s")).append("\t")
//      sb.append(obj.getBoolean("dispatch"))
//
//      sb.toString()
//    }).saveAsTextFile(path)
//  }
//
//
//  def getKeyword(rdd: RDD[Waybill]): RDD[Waybill] = {
//    logger.error("开始查询地址聚合接口")
//
//    val result = getAggregationAddr(rdd)
//    val successRdd = result.filter(waybill => waybill.getStatus == 0).persist(StorageLevel.MEMORY_AND_DISK)
//
//    logger.error("查询成功数据量:" + successRdd.count())
//    rdd.unpersist()
//    successRdd
//  }
//
//
//  //调用接口获取地址聚合结果
//  def getAggregationAddr(rdd: RDD[Waybill]): RDD[Waybill] = {
//    rdd.map(waybill => {
//      var keyWord = ""
//      var aoiid = ""
//      var status = 1
//
//      if (StringUtils.isNotBlank(waybill.getConsigneeaddr)) {
//        val query = String.format(addAggUrl, URLEncoder.encode(waybill.getConsigneeaddr, "utf-8"), waybill.getCitycode)
//        val resp = Source.fromURL(query, "utf-8").mkString
//
//        logger.error(resp)
//        val json = JSON.parseObject(resp)
//        status = json.getInteger("status")
//
//        if (status == 0) {
//          val data = json.getJSONObject("result").getJSONObject("data")
//          if (data != null) {
//            if (data.getString("key_word") != null) {
//              keyWord = data.getString("key_word")
//            }
//            if (data.getString("aoi_id") != null) {
//              aoiid = data.getString("aoi_id")
//            }
//          }
//        }
//      }
//
//      waybill.setKeyword(keyWord)
//      waybill.setAoiid(aoiid)
//      waybill.setStatus(status)
//
//      waybill
//    })
//  }


}
