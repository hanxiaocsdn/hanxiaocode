package com.sf.gis.scala.seg.app

import java.util.Properties

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.seg.util.{DbUtils, JavaUtil, MD5Util, Util}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 获取seg服务请求峰值，然后存入Mysql
 */
//noinspection DuplicatedCode
object SEGPerformanceMonitoringMaxReqTotal {
  @transient lazy val logger: Logger = Logger.getLogger(SEGPerformanceMonitoringMaxReqTotal.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    getMaxRequest(spark,incDay)
    spark.close()
  }


  /**
   * 统计seg服务请求峰值，然后写入Mysql表
   * @param spark
   * @param parDay
   * configFile ： Mysql配置文件
   * descTableName ： Mysql目标表
   */
  def getMaxRequest(spark:SparkSession,parDay:String)={
    println(parDay)
    val configFile = "addr.properties"
    val mysqlTableName = "SEG_MONITORING_INDEX_MINUTES"
    val finalTableName = "SEG_MONITORING_INDEX_MINUTES_MAX"
    val dir = "$"
    val calSql =
      s"""
         |SELECT
         |	 statdate
         |	,service_name
         |	,ak
         |	,MAX(per_minute_req_total)              	AS max_req_total
         |FROM seg_monitoring_index_minutes_temp
         |WHERE statdate = '$parDay'
         |GROUP BY
         |   statdate
         |  ,service_name
         |  ,ak
         |""".stripMargin
    val resultDF = readMysql(spark,configFile,mysqlTableName)
    resultDF.createOrReplaceTempView("seg_monitoring_index_minutes_temp")
    logger.error(calSql)
    import spark.implicits._
    logger.error(">>>>>>>>>>>>>>>>>开始统计性能指标: " + calSql)
    val resultRDD = Util.getRowToJson(spark,calSql)
    logger.error(">>>>>>>>>>>>>>>>>将统计seg性能指标写入Mysql表")
    save2Mysql(resultRDD,configFile,finalTableName,parDay)
    saveResult2Hive(spark,resultRDD,parDay)
    resultRDD.unpersist()
  }


  /**
   * 读MySQL表
   * @param spark
   * @param configFile
   * @param mysqlTableName
   */
  def readMysql(spark: SparkSession,configFile : String,mysqlTableName : String) = {
    val props: Properties = new Properties()
    props.setProperty("user", "gis_oms_addr")
    props.setProperty("password", "gis_oms_addr@123@")
    logger.error(">>>>>>>>>开始读数据<<<<<<<<<<")
    val resultDF = spark.read.jdbc("jdbc:mysql://10.119.72.209:3306/gis_oms_lip_addr?useUnicode=true&amp;characterEncoding=utf-8",mysqlTableName,props)
    logger.error(">>>>>>>>>>>读数据结束<<<<<<<<<<<<<")
    resultDF
  }

  /**
   * 保存数据到MySQL
   * @param resultRDD
   * @param configFile
   * @param finalTableName
   */
  def save2Mysql(resultRDD : RDD[JSONObject],configFile : String,finalTableName : String,parDay : String) = {
    val javaUtil = new JavaUtil()
    javaUtil.setFlag(12)
    val conn = DbUtils.getConnection(javaUtil)
    val md5Instance = MD5Util.getMD5Instance
    try {
      logger.error(">>>>>>>>>开始插入数据库<<<<<<<<<<")
      val delSql = String.format(s"delete from $finalTableName where stat_date='%s'", parDay)
      logger.error(">>>保存之前，删除当天的数据:" + delSql)
      DbUtils.executeSql(conn, delSql)
      val insertSql = s"insert into $finalTableName (`ID`,`STAT_DATE`,`SERVICE_NAME`,`AK`,`MAX_REQ_TOTAL`) values(?,?,?,?,?)"
      logger.error(">>>>>>>>>insertSql<<<<<<<<<<: "+insertSql)
      var insertParams: Array[Any] = null
      resultRDD.collect().foreach(row => {
        val id = MD5Util.getMD5(md5Instance,Array(row.getString("statdate"),row.getString("service_name"),JSONUtil.getJsonVal(row,"ak","")).mkString("_"))
        insertParams = Array(id,parDay,row.getString("service_name"),JSONUtil.getJsonVal(row,"ak",""),row.getString("max_req_total"))
        DbUtils.execute(conn,insertSql,insertParams)
      })
      logger.error(s">>>>>>>>>>>指标入库量: ${resultRDD.count()}<<<<<<<<<<<<<")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }


  /**
   *
   * @param spark
   * @param
   */
  def saveResult2Hive(spark : SparkSession,resultRDD : RDD[JSONObject],parDay : String): Unit ={
    //目标库表名称
    val descDBName = "default"
    val descTableName = "seg_monitoring_index_minutes_max"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay')
         |SELECT
         | *
         |FROM seg_monitoring_index_minutes_max_temp
         |""".stripMargin

    try{
      val schemaString = "stat_date,service_name,ak,max_req_total"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = resultRDD.map(obj => {
        val sb = new StringBuilder()
        sb.append(obj.getString("statdate")).append("\t\t\t")
        sb.append(obj.getString("service_name")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"ak","")).append("\t\t\t")
        sb.append(obj.getString("max_req_total")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("seg_monitoring_index_minutes_max_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }


case class Logs(types : String,date_time : String,dates : String,ak : String,times : Int)



}
