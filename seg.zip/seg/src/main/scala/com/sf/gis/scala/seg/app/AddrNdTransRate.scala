package com.sf.gis.scala.seg.app


import com.sf.gis.java.base.util.{FileUtil, MD5Util, MysqlJDBCUtils}
import com.sf.gis.scala.base.spark.Spark
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}

import scala.collection.mutable.ListBuffer

/**
 * 地址可达服务-地址不详转化率 by 蓝媛青
 * Created by 01394386 on 2020/4/30.
 */
object AddrNdTransRate {

  case class AddrNdTransRateObj(
                                 AK: String,
                                 DATA_TYPE: String,
                                 DETAIL_TYPE: String,
                                 USER_AMOUNT: Int,
                                 REQ_AMOUNT: Int,
                                 ADDR_ND_REQ_AMOUNT: Int,
                                 ADDR_ND_USER_AMOUNT: Int,
                                 ADDR_MODIFY_AMOUNT: Int,
                                 ADDR_ND_TRANS_AMOUNT: Int,
                                 ADDR_ND_MODIFY_1_AMOUNT: Int,
                                 ADDR_ND_MODIFY_1_TRANS_AMOUNT: Int
                               )

  @transient lazy val logger: Logger = Logger.getLogger(AddrNdTransRate.getClass)

  val appName: String = this.getClass.getSimpleName.replaceAll("$", "")
  val querySql = FileUtil.getQuerySql("addrNdTransRate.csv")
  val descTableName = "ADDR_ND_TRANS_RATE"

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)

    val partitionDay = args(0)

    /*val dateList = Array("20200612","20200613","20200615","20200616","20200617")
    dateList.foreach(elem => run(spark,elem))*/

    run(spark, partitionDay)

    spark.close()
  }

  def run(spark: SparkSession, partitionDay: String): Unit = {
    val querySourceSql =
      """select
            parse_url(get_json_object(substring(log,instr(log,"{")),"$.url.url"),"QUERY","req_sn") as req_sn,
            get_json_object(substring(log,instr(log,"{")),"$.url.ak") as ak,
            get_json_object(substring(log,instr(log,"{")),"$.url.datatype") as datatype,
            get_json_object(substring(log,instr(log,"{")),"$.data.result.detail_type") as detail_type,
            get_json_object(substring(log,instr(log,"{")),"$.data.result.detail_addr") as detail_addr,
            get_json_object(substring(log,instr(log,"{")),"$.url.address") as addresses,
            get_json_object(substring(log, instr(log, "{")), "$.type") as type,
            get_json_object(substring(log,instr(log,"{")),"$.dateTime") as dateTime
         from dm_gis.bee_logs_gis_ar_collect
         where parse_url(get_json_object(substring(log,instr(log,"{")),"$.url.url"),"QUERY","req_sn") is not null
            and get_json_object(substring(log,instr(log,"{")),"$.url.ak") is not null
            and get_json_object(substring(log,instr(log,"{")),"$.url.datatype") is not null
            and get_json_object(substring(log,instr(log,"{")),"$.data.result.detail_type") is not null
            and inc_day=""".stripMargin

    spark.sql(querySourceSql + s"\'$partitionDay\'").createOrReplaceTempView("temp")

    logger.error("\n\n>>>>>>>>>>>>querySourceSqls<<<<<<<<<<<<\n" + querySourceSql + s"\'$partitionDay\'" + "\n\n")

    logger.error("\n\n>>>>>>>>>>>>querySqls<<<<<<<<<<<<<\n" + querySql + "\n\n")

    logger.error("\n\n>>>>>>>>>>>>开始计算地址转化不详率<<<<<<<<<<<<<\n" + querySql + "\n\n")

    val resultRDD = spark.sql(querySql).rdd

    saveDb(spark, resultRDD, partitionDay)
  }

  /**
   * 获取表的列名集合
   *
   * @param spark        SparkSession
   * @param resultRDD    计算结果
   * @param partitionDay 查询hive分区
   * @return ArrayList<String>
   */
  def saveDb(spark: SparkSession, resultRDD: RDD[Row], partitionDay: String) = {

    val connection = MysqlJDBCUtils.getConnection("conf/druid.properties")

    var listBuffer = ListBuffer[String]()
    //获取目标表所有列名
    import scala.collection.JavaConversions._
    val columnList = MysqlJDBCUtils.getColums(connection, descTableName)
    val md5Instance = MD5Util.getMD5Instance
    var insertSql = s"""insert into $descTableName set """

    var insertCount = 0
    try {
      logger.error(">>>>>>>>>开始插入数据库s<<<<<<<<<<")

      //存入hive
      //saveHive(spark,resultRDD,descTableName,partitionDay)

      //存入mysql
      resultRDD.collect().foreach(one => {
        val id = MD5Util.getMD5(md5Instance, Array(partitionDay, one.get(0), one.get(1), one.get(2)).mkString("_"))
        insertSql = s"""insert into $descTableName set ID='$id',STAT_DATE='$partitionDay',"""

        for (elem <- columnList) insertSql += elem + "=\'" + one.get(columnList.indexOf(elem)) + "\',"
        insertSql = insertSql.substring(0, insertSql.lastIndexOf(","))

        logger.error(insertSql)
        listBuffer += insertSql

        if (listBuffer.size == 1000) {
          MysqlJDBCUtils.insertBatch(connection, listBuffer, 100)
          listBuffer = ListBuffer[String]()
        }

        insertCount += 1
      })

      MysqlJDBCUtils.insertBatch(connection, listBuffer, 1000)
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

    logger.error(s">>>插入数据库完成,共插入$insertCount!<<<")
  }

  def saveHive(sparkSession: SparkSession, resultDF: DataFrame, saveTable: String, partitionDay: String): Unit = {
    logger.error(s">>>>>>>>>>>>>>>>>inert into table $saveTable <<<<<<<<<<<<<<<<<<<<")
    resultDF.write.format("Hive").mode(SaveMode.Append).saveAsTable(s"dm_gis.$saveTable")
  }

}
