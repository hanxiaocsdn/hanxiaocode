package com.sf.gis.scala.seg.app

import java.sql.{Connection, DriverManager}
import java.text.{DecimalFormat, SimpleDateFormat}
import java.util.Date

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, DbUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

/**
  * Created by 01375125 on 2019/12/3.
  * --seg日志拆分
 * 任务id:225247
 * 任务名称：seg地址拆分日志统计
 * 业务：匡可心
 * 开发:张想远
  */
object AddrSegLogProStat {
  private val appName:String = this.getClass.getSimpleName.replace("$","")
  private val logger = LoggerFactory.getLogger(appName)

  case class IndexObj(ak:String,province:String, citycode:String, city:String, statDate:String, resp_cnt:Int, success_cnt:Int,fail_cnt:Int, overtime_cnt:Int, trouble_addr_cnt:Int, geo_cnt:Int, tip_cnt:Int, tc_cnt:Int, guess_cnt:Int, xy_count:Int, xy_geo_count:Int, xy_gd_count:Int, xy_tip_count:Int, province_cnt:Int, citycode_cnt:Int, city_cnt:Int, county_cnt:Int, town_cnt:Int, adcode_cnt:Int, detailaddr_cnt:Int, addresssuffix_cnt:Int)
  case class IpIndexObj(ip:String, statDate:String, resp_cnt:Int, ip_resp_cx1_cnt:Int)

  def main(args: Array[String]): Unit = {
    start(args)

    //start(Array[String]("20200521"))
  }

  def start(args: Array[String]): Unit ={
    val spark = Spark.getSparkSession(appName)

   /* val spark = SparkSession.builder().appName("CSVFileTest").master("local[4]").getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")*/

    if (args.length == 0) {
      //代码内部传入日期参数
      val date = DateUtil.getYesterday
      handleTask(spark, date)
    } else if (args.length == 1) {
      //传入参数，单天任务
      val date = args(0)
      handleTask(spark, date)
    } else if (args.length == 2) {
      //传入参数，多天任务 [左闭右开)
      val startDate = args(0)
      val endDate = args(1)
      batchTask(spark, startDate, endDate)
    }

    spark.stop()
  }

  def temp(): Unit ={
    val spark = Spark.getSparkSession(appName)
    val startDate = "20200106"
    val endDate = "20200114"
    batchTask(spark, startDate, endDate)

  }

  /**
    * 批量任务
    *
    * @param spark
    * @param startDate
    * @param endDate
    */
  def batchTask(spark: SparkSession, startDate: String, endDate: String): Unit = {
    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
    for (date <- dateList) {
      handleTask(spark, date)
    }
  }

  def handleTask(spark:SparkSession,date:String): Unit = {
    logger.error("-----------start-------开始"+date+"号的任务，appName="+appName+"-------------")
    logger.error(">>>解析转寄退回日志")
    val logRdd = parseData(spark,date)
    val logCount = logRdd.count()
    if(logCount>0){
      logger.error(">>>统计指标")
      val (statIndexRdd,ipIndexRdd) = statIndex(logRdd,date)
      logRdd.unpersist()

      logger.error(">>>指标入库")

      logger.error(s">>>入库ADDR_SEG_STAT共：${statIndexRdd.count()}条<<<")
      //statIndexRdd.take(3).foreach(one => logger.error(one.toString))

      logger.error(s">>>入库ADDR_SEG_IP共：${ipIndexRdd.count()}条<<<")
      //ipIndexRdd.take(3).foreach(one => logger.error(one.toString))

      saveIndexToMysql(statIndexRdd,ipIndexRdd,date)
      statIndexRdd.unpersist()
      ipIndexRdd.unpersist()
    }
    logger.error(">>>程序结束！")
  }



  def saveIndexToMysql(indexRdd:RDD[IndexObj],ipIndexRdd:RDD[IpIndexObj],date:String): Unit ={
    try {
      val connection = getConnection
      val reportTableName = "ADDR_SEG_STAT"
      val deleteSql = s"DELETE FROM $reportTableName WHERE STATDATE='$date'"
      println(">>>删除报表数据："+deleteSql)
      DbUtil.execute(connection,deleteSql,null)
      val reportSql =
        s"""
          INSERT INTO $reportTableName (AK,PROVINCE,CITYCODE,CITY,STATDATE,RESP_CNT,SUCCESS_CNT,FAIL_CNT,OVERTIME_CNT,TROUBLE_ADDR_CNT,GEO_CNT,TIP_CNT,TC_CNT,GUESS_CNT,XY_COUNT,XY_GEO_COUNT,XY_GD_COUNT,XY_TIP_COUNT,PROVINCE_CNT,CITYCODE_CNT,CITY_CNT,COUNTY_CNT,TOWN_CNT,ADCODE_CNT,DETAILADDR_CNT,ADDRESSSUFFIX_CNT) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
       """.stripMargin
      val reportIndexList = indexRdd.map(o => {
        Array(o.ak, o.province, o.citycode, o.city, o.statDate, o.resp_cnt, o.success_cnt, o.fail_cnt, o.overtime_cnt, o.trouble_addr_cnt, o.geo_cnt, o.tip_cnt, o.tc_cnt, o.guess_cnt, o.xy_count, o.xy_geo_count, o.xy_gd_count, o.xy_tip_count, o.province_cnt, o.citycode_cnt, o.city_cnt, o.county_cnt, o.town_cnt, o.adcode_cnt, o.detailaddr_cnt, o.addresssuffix_cnt)
      }).collect().toList
      DbUtil.batchListExecute(connection, reportSql, reportIndexList)
      logger.error(">>>报表指标入库结束！")

      val ipTableName = "ADDR_SEG_IP"
      val deleteIpSql = s"DELETE FROM $ipTableName WHERE STATDATE='$date'"
      println(">>>删除Ip调用量数据："+deleteIpSql)
      DbUtil.execute(connection,deleteIpSql,null)
      val ipSql =
        s"""
          INSERT INTO $ipTableName (STATDATE,IP,RESP_CNT,RESP_CX1_CNT)VALUES(?,?,?,?)
       """.stripMargin

      val ipIndexList = ipIndexRdd.take(10000).map(o => {
        Array(o.statDate, o.ip, o.resp_cnt,o.ip_resp_cx1_cnt)
      }).toList
      DbUtil.batchListExecute(connection, ipSql, ipIndexList)
      logger.error(">>>IP调用量指标入库结束！")
      connection.close()
    } catch {
      case e:Exception =>logger.error(">>>指标入库异常："+e)
    }

  }

  def getConnection: Connection ={
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_addr?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8mb4&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true"
    @transient val connection = DriverManager.getConnection(url,"gis_oms_addr","gis_oms_addr@123@")
    connection
  }


  /**
    * 统计指标
    * @param inputRdd
    * @return
    */
  def statIndex(inputRdd:RDD[JSONObject],date:String): (RDD[IndexObj],RDD[IpIndexObj]) ={
    val rowIndexRdd = inputRdd.map(json=>{
      val datatime = json.getString("dateTime")
      val statDate = json.getString("statDate")
      var ak ="-"
      var ip ="-"
      var province = "-"
      var citycode = "-"
      var city = "-"
      var status = "-"

      var resp_cnt,ip_resp_cx1_cnt,success_cnt,fail_cnt,overtime_cnt,trouble_addr_cnt,geo_cnt,tip_cnt,tc_cnt,guess_cnt,xy_count,xy_geo_count,xy_gd_count,xy_tip_count,province_cnt,citycode_cnt,city_cnt,county_cnt,town_cnt,adcode_cnt,detailaddr_cnt,addresssuffix_cnt=0
      var time = -1
      resp_cnt=1 //返回量

      try {
        val urlObj = json.getJSONObject("url" )
        if (urlObj != null) {
          val remoteIp = urlObj.getString("remoteIp" )
          if (remoteIp != null) ip = remoteIp
          if (urlObj.getString("ak") != null) ak = urlObj.getString("ak" )
          val opt = urlObj.getString("opt")
          if (opt != null && opt == "cx1") ip_resp_cx1_cnt = 1 //ip返回量，只统计opt=cx1的量
        }
        time = json.getInteger("time")
        val dataObj = json.getJSONObject("data")
        if (dataObj != null) {
          val resultObj = dataObj.getJSONObject("result")
          if (StringUtils.isNoneEmpty(dataObj.getString("status"))) {
            status = dataObj.getString("status")
          }
          if (resultObj != null) {
            if (status.equals("1")) {
              fail_cnt = 1
              val msg = resultObj.getString("msg")
              if (StringUtils.isNotBlank(msg)) {
                if (msg.equals("地址不详或地址冲突")) {
                  trouble_addr_cnt = 1
                } else if (msg.contains("timeout") && msg.contains("rcp")) {
                  overtime_cnt = 1
                }
              }
            } else {
              success_cnt = 1
              val src = resultObj.getString("src")
              if (src != null) {
                if (src.contains("geo")) {
                  geo_cnt = 1
                } else if (src.contains("tip")) {
                  tip_cnt = 1
                } else if (src.contains("tc")) {
                  tc_cnt = 1
                } else if (src.contains("guess")) {
                  guess_cnt = 1
                }
              }
              val innerData = resultObj.getJSONObject("data")

              if (innerData != null) {

                if (StringUtils.isNotBlank(innerData.getString("province"))) {
                  province =innerData.getString("province")
                  province_cnt = 1
                }

                if (StringUtils.isNotBlank(innerData.getString("citycode"))){
                  citycode = innerData.getString("citycode")
                  citycode_cnt = 1
                }

                if (StringUtils.isNotBlank(innerData.getString("city"))){
                  city = innerData.getString("city")
                  city_cnt = 1
                }

                val county = innerData.getString("county")
                if (StringUtils.isNotBlank(county)) county_cnt = 1
                val town = innerData.getString("town")
                if (StringUtils.isNotBlank(town)) town_cnt = 1
                val adcode = innerData.getString("adcode")
                if (StringUtils.isNotBlank(adcode)) adcode_cnt = 1
                val detailaddr = innerData.getString("detailaddr")
                if (StringUtils.isNotBlank(detailaddr)) detailaddr_cnt = 1
                val addressSuffix = innerData.getString("addressSuffix")
                if (StringUtils.isNotBlank(addressSuffix)) addresssuffix_cnt = 1

                val lng = innerData.getString("lng")
                val lat = innerData.getString("lat")
                if (StringUtils.isNotBlank(lng) && StringUtils.isNotBlank(lat)){
                  xy_count = 1
                  if(src!=null && src.contains("geo") && !"geo|gd".equalsIgnoreCase(src)) xy_geo_count = 1
                  if("geo|gd".equalsIgnoreCase(src)) xy_gd_count = 1
                  if(src!=null && src.contains("tip")) xy_tip_count = 1
                }
              }
            }

          }
        }
      } catch {
        case e:Exception =>logger.error(">>>计算异常："+e)
      }
      ((ak,ip,province,citycode,city,statDate),ip_resp_cx1_cnt,(resp_cnt,success_cnt,fail_cnt,overtime_cnt,trouble_addr_cnt,geo_cnt,tip_cnt,tc_cnt,guess_cnt,xy_count,xy_geo_count,xy_gd_count,xy_tip_count,province_cnt,citycode_cnt,city_cnt,county_cnt,town_cnt,adcode_cnt,detailaddr_cnt,addresssuffix_cnt),time)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    rowIndexRdd.take(1).foreach(println)
    val timeIndexRdd =rowIndexRdd.map(row=>{
      (row._1._1,row._4)
    }).filter(obj=> "c4066396181d4041bbe63bf5f1607d5f".equals(obj._1) && obj._2 != -1 )
    val count = timeIndexRdd.count()
    val total =  timeIndexRdd.reduceByKey((obj1,obj2)=>{
      obj1+obj2
    })

    val totalCount = total.values.collect()

    logger.error(s">>>ak=c4066396181d4041bbe63bf5f1607d5f聚合后大小:${totalCount.size}<<<")

    val totalCountTime =totalCount(0)
    val per = totalCountTime*1.0 / count
    logger.error("总数:"+count+",总时长："+totalCountTime+",平均时间:"+per)
    val gt200 = timeIndexRdd.filter(obj=> obj._2 > 200).count()
    logger.error("大于200Ms时长数量:"+gt200)


    val reportIndexRdd = rowIndexRdd.map(row=>{
      val k = row._1
      val v = row._3
      ((k._1,k._3,k._4,k._5,k._6),v)
    }).reduceByKey((t1,t2)=>{
      (t1._1+t2._1,t1._2+t2._2,t1._3+t2._3,t1._4+t2._4,t1._5+t2._5,t1._6+t2._6,t1._7+t2._7,t1._8+t2._8,t1._9+t2._9,t1._10+t2._10,t1._11+t2._11,t1._12+t2._12,t1._13+t2._13,t1._14+t2._14,t1._15+t2._15,t1._16+t2._16,t1._17+t2._17,t1._18+t2._18,t1._19+t2._19,t1._20+t2._20,t1._21+t2._21)
    }).map(obj=>{
      val k = obj._1
      val v = obj._2
      IndexObj(k._1, k._2, k._3, k._4,k._5, v._1, v._2, v._3, v._4, v._5, v._6, v._7, v._8, v._9, v._10, v._11, v._12, v._13, v._14, v._15,v._16, v._17, v._18, v._19, v._20, v._21)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>统计报表指标数："+reportIndexRdd.count())

    val ipIndexRdd = rowIndexRdd.map(row=>{
      val k = row._1
      val ip_resp_cx1_cnt = row._2
      val resp_cnt = row._3._1
      ((k._2,k._6),(resp_cnt,ip_resp_cx1_cnt))
    }).reduceByKey((o1,o2)=>{
      (o1._1+o2._1,o2._2+o2._2)
    }).sortBy(_._2._2,false).map(obj=>{
      IpIndexObj(obj._1._1,obj._1._2,obj._2._1,obj._2._2)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>统计IP调用量指标数："+ipIndexRdd.count())
    rowIndexRdd.unpersist()
    (reportIndexRdd,ipIndexRdd)
  }




  /**
    * 计算两数比例，保留4位小数
    * @param dividend 被除数
    * @param divisor 除数
    * @return
    */
  def getRate(dividend:Double,divisor:Double): String = {
    var tcRate = "0.0000"
    val df = new DecimalFormat("0.0000")
    try {
      val value = dividend / divisor
      tcRate = value.formatted("%.4f")
    } catch {
      case e: Exception => logger.error(">>>计算比例异常：" + e)
    }
    tcRate
  }


  /**
    * 时间字符串转换成毫秒值
    * 样例：2018-10-24 09:54:47 236 ==> 1540346087236
    * @param time
    * @return
    */
  def timeToLong(time:String): Long ={
    val sdf:SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
    val longTime = sdf.parse(time).getTime
    longTime
  }

  /**
    * long值转换成时间
    * @param time
    * @return
    */
  def longToTime(time:Long): String ={
    var createTime:String=null
    try {
      val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS")
      val createDate = new Date(time)
      createTime = sdf.format(createDate)
    } catch {
      case e:Exception =>logger.error(">>>转换失败："+e+",time:"+time)
    }
    createTime
  }

  /**
    * 关联日志
    * @param inputRdd
    * @return
    */
  def joinLog(inputRdd:RDD[JSONObject]): RDD[JSONObject] ={
    val returnRdd = inputRdd.filter(json=>{
      val dataType = json.getString("type")
      dataType != null && dataType == "url_e"
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>返回的数据量："+returnRdd.count())
    returnRdd.take(1).foreach(println)
    returnRdd
  }

  /**
    * 解析日志
    * @param spark
    * @param date
    * @return
    */
  def parseData(spark:SparkSession, date:String): RDD[JSONObject] ={

    /*val sql =
      s"""
         |select rawjson from stg_kafka_rtc.gis_rss_seg_cloud_log_collect where inc_day='$date'
       """.stripMargin*/

    /*val path = ClassLoader.getSystemClassLoader().getResource("gis_rss_seg_cloud_log_collect.csv").getPath()
    val querySourceDF =
      spark.read.option("header", true).option("delimiter", "\t").option("inferSchema", true).csv(path)
    querySourceDF.createOrReplaceTempView("gis_rss_seg_cloud_log_collect")*/

    val sql = s" select logs from dm_gis.ods_kafka_bee_logs_gis_rss_seg where inc_day='$date'"

    logger.error(">>>query sql <<<\n" + sql)
    val logRdd = spark.sql(sql).rdd.map(row => {
      val line = row.getString(0)
      line
    })

    logRdd.take(3).foreach(println)

    val outputRdd = logRdd.map( log => {
      var json:JSONObject = null
      try {
        //val line: String = StringUtil.pickGroup1Str(log, "system.log#(.*)")
        //val line: String = StringUtil.pickGroup1Str(log, "systemcollect.log#(.*)")

        /*val line: String = log.replaceAll("\\\"\\{","{")
                              .replaceAll("\\}\\\"","}")
                              .replace("\\","")

          json = JSON.parseObject(line).getJSONObject("message")*/

        val jsonAll = JSON.parseObject(log)
        json = JSON.parseObject(jsonAll.getString("message"))

        val statDate = json.getString("dateTime").split(" ")(0).replaceAll("-","")
        json.put("statDate",statDate)
      } catch {
        case e:Exception =>logger.error(">>>提取和转json失败："+e)
      }
      json
    }).filter(json=>{
      if(json!=null){
        val statDate = json.getString("statDate")
        statDate !=null && statDate==date
      }else{
        false
      }
    }).filter(json=>{
      val dataType = json.getString("type")
      dataType != null && dataType == "url_e"
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>解析后返回的日志量："+outputRdd.count())

    outputRdd.take(1).foreach(println)
    outputRdd
  }

}
