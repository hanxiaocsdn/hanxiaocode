package com.sf.gis.scala.seg.app

import java.sql.DriverManager
import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.custom_module.MapCityRegionInfo
import com.sf.gis.scala.base.spark.Spark
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang3.StringUtils
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}

import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:BSP地址解析生产日志存表入库(01381101)
 * @Author: 01417629
 * @CreateTime:
 * @TaskId:224180
 * @TaskName:
 * @Description:
 */
object ADDSegBspLogParse {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = LoggerFactory.getLogger(ADDSegBspLogParse.getClass)
  val hotCities = "" //('Adams','Carter')"
  val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

  case class LogParse(dataType: String, dateTime: String,
                      date: String, ak: String, time: Int, src: String, detailSrc: String,
                      sn: String, province: String, city: String, county: String, town: String,
                      adcode: String, citycode: String, detailaddr: String, orderno: String,
                      isTown: String, address: String, level: String, origin: String, la: String,
                      compare: String, showcode: String, province_code: String, citylev_code: String,
                      county_code: String, town_code: String, result: String, tipProvince: String, tipCity: String, tipCounty: String, tipTown: String, multiple: String,
                      mark: String, addressSuffix: String,
                      province_req: String, city_req: String, county_req: String, town_req: String,
                      conflict: String, moreThan: String, opt: String, lng: String,
                      lat: String
                     )

  def main(args: Array[String]): Unit = {
    val parDay_1 = args(0)
    val spark = Spark.getSparkSession(appName)
    saveResult(spark,parDay_1)
  }

  def saveResult(spark: SparkSession, parDay_1: String) = {
    import spark.implicits._
    val gis_ass_adds_log_parse_new = spark.sql(s"select logs as log from dm_gis.ods_kafka_bee_logs_gis_rss_seg_bsp where inc_day='$parDay_1'").na.fill("").rdd.map(row => {
      var log = ""
      if (!row.isNullAt(0)) log = row.getString(0)
      var _type = ""
      var dateTime = ""
      var date = ""
      var ak = "-"
      var time = -1
      var src = ""
      var detailSrc = ""
      var sn = ""
      var province = ""
      var city = ""
      var county = ""
      var town = ""
      var adcode = ""
      var citycode = ""
      var detailaddr = ""
      var orderno = ""
      var isTown = ""

      var address = ""
      var level = ""
      var origin = ""
      var compare = ""
      var showcode = ""
      var province_code = ""
      var citylev_code = ""
      var county_code = ""
      var town_code = ""
      var result = ""
      var multiple = ""
      var mark = ""

      var addressSuffix = ""
      var province_req = ""
      var city_req = ""
      var county_req = ""
      var town_req = ""
      var conflict = ""
      var moreThan = ""
      var opt = ""
      var lng = ""
      var lat = ""
      var tipProvince = ""
      var tipCity = ""
      var tipCounty = ""
      var tipTown = ""
      var la = ""

      try {
        val logObject = JSON.parseObject(log)
        if (logObject != null) {
          var logString = logObject.getString("message")
          logString = logString.replaceAll("\\\\\\\\t", "").replaceAll("\\\\\\\\n", "")
          logString = logString.replaceAll("\n", "").replaceAll("\t", "")
          val jsonObject = JSON.parseObject(logString)

          dateTime = jsonObject.getString("dateTime")
          if (!StringUtils.isEmpty(dateTime) && dateTime.length >= 11) date = dateTime.substring(0, 10).replaceAll("-", "")
          _type = jsonObject.getString("type")
          sn = jsonObject.getString("sn")
          time = jsonObject.getIntValue("time")
          val urlObject = jsonObject.getJSONObject("url")
          if (urlObject != null) ak = urlObject.getString("ak")
          if (urlObject != null) orderno = urlObject.getString("orderno")
          if (urlObject != null) province_req = urlObject.getString("province")
          if (urlObject != null) city_req = urlObject.getString("city")
          if (urlObject != null) county_req = urlObject.getString("county")
          if (urlObject != null) town_req = urlObject.getString("town")
          if (urlObject != null) opt = urlObject.getString("opt")
          if (urlObject != null) la = urlObject.getString("la")
          val dataObject = jsonObject.getJSONObject("data")
          if (dataObject == null) {
            detailSrc = "NORS"
          }
          else {
            val resultObject = dataObject.getJSONObject("result")
            if (resultObject != null) {
              result = resultObject.getString("result")
              multiple = resultObject.getString("multiple")
              mark = resultObject.getString("mark")
              conflict = resultObject.getString("conflict")
              moreThan = resultObject.getString("moreThan")
              val queryObject = resultObject.getJSONObject("query")
              if (queryObject != null) {
                address = queryObject.getString("address")
                if (!StringUtils.isEmpty(address)) address = address.replaceAll("\t", "").replaceAll("\n", "")
                level = queryObject.getString("level")
                origin = queryObject.getString("origin")
                compare = queryObject.getString("compare")
                showcode = queryObject.getString("showcode")
              }
              detailSrc = resultObject.getString("src")
              val dataObject2 = resultObject.getJSONObject("data")
              if (dataObject2 == null) {
                detailSrc = "NORS"
              }
              else {
                province = dataObject2.getString("province")
                if (StringUtils.isEmpty(province)) detailSrc = "NORS"
                city = dataObject2.getString("city")
                county = dataObject2.getString("county")
                town = dataObject2.getString("town")
                adcode = dataObject2.getString("adcode")
                citycode = dataObject2.getString("citycode")
                detailaddr = dataObject2.getString("detailaddr")
                if (!StringUtils.isEmpty(county) && !StringUtils.isEmpty(town)) isTown = "true"

                province_code = dataObject2.getString("provinceCode")
                citylev_code = dataObject2.getString("cityLevCode")
                county_code = dataObject2.getString("countyCode")
                town_code = dataObject2.getString("townCode")

                tipProvince = dataObject2.getString("tipProvince")
                tipCity = dataObject2.getString("tipCity")
                tipCounty = dataObject2.getString("tipCounty")
                tipTown = dataObject2.getString("tipTown")


                addressSuffix = dataObject2.getString("addressSuffix")

                lng = dataObject2.getString("lng")
                lat = dataObject2.getString("lat")
              }
            }
            else detailSrc = "NORS"
          }
        }
      }
      catch {
        case ex: Exception => {
          detailSrc = "NORS"
        }
      }


      if (StringUtils.isEmpty(_type)) _type = ""
      if (StringUtils.isEmpty(dateTime)) dateTime = ""
      if (StringUtils.isEmpty(ak) || StringUtils.isBlank(ak) || ak == None) ak = "-"
      if (StringUtils.isEmpty(detailSrc) || StringUtils.isBlank(detailSrc) || detailSrc == None) detailSrc = "NORS"
      if (StringUtils.isEmpty(sn)) sn = ""
      if (StringUtils.isEmpty(province)) province = ""
      if (StringUtils.isEmpty(city) || StringUtils.isBlank(city) || city == None) city = ""
      if (StringUtils.isEmpty(county)) county = ""
      if (StringUtils.isEmpty(town)) town = ""
      if (StringUtils.isEmpty(adcode)) adcode = ""
      if (StringUtils.isEmpty(citycode)) citycode = ""
      if (StringUtils.isEmpty(detailaddr)) detailaddr = ""
      else detailaddr = detailaddr.replaceAll("\t", "")
      if (StringUtils.isEmpty(date)) date = ""
      if (StringUtils.isEmpty(orderno)) orderno = ""
      ak = StringUtils.stripToEmpty(StringUtils.trimToEmpty(ak))
      detailSrc = StringUtils.stripToEmpty(StringUtils.trimToEmpty(detailSrc))
      city = StringUtils.stripToEmpty(StringUtils.trimToEmpty(city))
      if (!StringUtils.isEmpty(detailSrc)) detailSrc = detailSrc.toUpperCase
      else detailSrc = "NORS"
      if (ak.length < 10 || ak.length > 49) ak = "-"
      if (!detailSrc.matches("[A-z|0-9]+")) detailSrc = "NORS"
      //          if (city.length < 3) city = "-"
      if (detailSrc.contains("|")) src = detailSrc.split("\\|")(0)
      else src = detailSrc

      if (StringUtils.isEmpty(address)) address = ""
      if (StringUtils.isEmpty(level)) level = ""
      if (StringUtils.isEmpty(origin)) origin = ""
      if (StringUtils.isEmpty(compare)) compare = ""
      if (StringUtils.isEmpty(showcode)) showcode = ""
      if (StringUtils.isEmpty(province_code)) province_code = ""
      if (StringUtils.isEmpty(citylev_code)) citylev_code = ""
      if (StringUtils.isEmpty(county_code)) county_code = ""
      if (StringUtils.isEmpty(town_code)) town_code = ""
      if (StringUtils.isEmpty(result)) result = ""
      if (StringUtils.isEmpty(multiple)) multiple = ""
      if (StringUtils.isEmpty(mark)) mark = ""

      if (StringUtils.isEmpty(addressSuffix)) addressSuffix = ""
      if (StringUtils.isEmpty(province_req)) province_req = ""
      if (StringUtils.isEmpty(city_req)) city_req = ""
      if (StringUtils.isEmpty(county_req)) county_req = ""
      if (StringUtils.isEmpty(town_req)) town_req = ""
      if (StringUtils.isEmpty(conflict)) conflict = ""
      if (StringUtils.isEmpty(moreThan)) moreThan = ""
      if (StringUtils.isEmpty(opt)) opt = ""
      if (StringUtils.isEmpty(lng)) lng = ""
      if (StringUtils.isEmpty(lat)) lat = ""

      if (StringUtils.isEmpty(tipProvince)) tipProvince = ""
      if (StringUtils.isEmpty(tipCity)) tipCity = ""
      if (StringUtils.isEmpty(tipCounty)) tipCounty = ""
      if (StringUtils.isEmpty(tipTown)) tipTown = ""
      if (StringUtils.isEmpty(la)) la = ""


      LogParse(_type.replaceAll("\t", "").replaceAll("\n", ""),
        dateTime.replaceAll("\t", "").replaceAll("\n", ""),
        date.replaceAll("\t", "").replaceAll("\n", ""),
        ak.replaceAll("\t", "").replaceAll("\n", ""),
        time, src.replaceAll("\t", "").replaceAll("\n", ""),
        detailSrc.replaceAll("\t", "").replaceAll("\n", ""),
        sn.replaceAll("\t", "").replaceAll("\n", ""),
        province.replaceAll("\t", "").replaceAll("\n", ""),
        city.replaceAll("\t", "").replaceAll("\n", ""),
        county.replaceAll("\t", "").replaceAll("\n", ""),
        town.replaceAll("\t", "").replaceAll("\n", ""),
        adcode.replaceAll("\t", "").replaceAll("\n", ""),
        citycode.replaceAll("\t", "").replaceAll("\n", ""),
        detailaddr.replaceAll("\t", "").replaceAll("\n", ""),
        orderno.replaceAll("\t", "").replaceAll("\n", ""),
        isTown.replaceAll("\t", "").replaceAll("\n", ""),
        address.replaceAll("\t", "").replaceAll("\n", ""),
        level.replaceAll("\t", "").replaceAll("\n", ""),
        origin.replaceAll("\t", "").replaceAll("\n", ""),
        la.replaceAll("\t", "").replaceAll("\n", ""),
        compare.replaceAll("\t", "").replaceAll("\n", ""),
        showcode.replaceAll("\t", "").replaceAll("\n", ""),
        province_code.replaceAll("\t", "").replaceAll("\n", ""),
        citylev_code.replaceAll("\t", "").replaceAll("\n", ""),
        county_code.replaceAll("\t", "").replaceAll("\n", ""),
        town_code.replaceAll("\t", "").replaceAll("\n", ""),
        result.replaceAll("\t", "").replaceAll("\n", ""),
        tipProvince.replaceAll("\t", "").replaceAll("\n", ""),
        tipCity.replaceAll("\t", "").replaceAll("\n", ""),
        tipCounty.replaceAll("\t", "").replaceAll("\n", ""),
        tipTown.replaceAll("\t", "").replaceAll("\n", ""),
        multiple.replaceAll("\t", "").replaceAll("\n", ""),
        mark.replaceAll("\t", "").replaceAll("\n", ""),
        addressSuffix.replaceAll("\t", "").replaceAll("\n", ""),
        province_req.replaceAll("\t", "").replaceAll("\n", ""),
        city_req.replaceAll("\t", "").replaceAll("\n", ""),
        county_req.replaceAll("\t", "").replaceAll("\n", ""),
        town_req.replaceAll("\t", "").replaceAll("\n", ""),
        conflict.replaceAll("\t", "").replaceAll("\n", ""),
        moreThan.replaceAll("\t", "").replaceAll("\n", ""),
        opt.replaceAll("\t", "").replaceAll("\n", ""),
        lng.replaceAll("\t", "").replaceAll("\n", ""),
        lat.replaceAll("\t", "").replaceAll("\n", "")
      )
    }).filter(row => parDay_1.equalsIgnoreCase(row.date)).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val tmpView = "tmp" + System.currentTimeMillis()
    gis_ass_adds_log_parse_new.createOrReplaceTempView(tmpView)
    val insertSql = s"insert overwrite table dm_gis.dwd_gis_rss_seg_bsp_log_parse_di partition(inc_day=$parDay_1) select * from $tmpView"
    logger.error(insertSql)
    spark.sql(insertSql)
    logger.error("导入到dm_gis.dwd_gis_rss_seg_bsp_log_parse_di表")
  }
}
