package com.sf.gis.scala.seg.app

import com.alibaba.fastjson.JSON
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.seg.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel


/**
 * 获取seg服务总性能数据，然后存入Mysql
 */
//noinspection DuplicatedCode
object SEGPerformanceMonitoringLogParse {
  @transient lazy val logger: Logger = Logger.getLogger(SEGPerformanceMonitoringLogParse.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val logParseData = getSegLogParse(spark,incDay)
    saveResult2Hive(spark,logParseData,incDay)
    logParseData.unpersist()
    spark.close()
  }


  /**
   * 解析seg服务性能日志
   * @param spark
   * @param parDay
   */
  def getSegLogParse(spark:SparkSession,parDay:String) : RDD[(String, String, String, String, String)]={
    logger.error(parDay)
    val querySql =
      s"""
         |select
         |  logs
         |from dm_gis.ods_kafka_bee_logs_gis_rss_seg
         |where inc_day = '$parDay'
       """.stripMargin
    logger.error(querySql)
    val logParseData = spark.sql(querySql).rdd.repartition(1000).map(obj => {
      try{
        val logs = JSON.parseObject(JSON.parseArray(obj.toString()).get(0).toString)
        val message = JSONUtil.getJsonVal(logs,"message","")
        val msg = JSON.parseObject(message)
        val types = JSONUtil.getJsonVal(msg,"type","")
        val date_time = JSONUtil.getJsonVal(msg,"dateTime","")
        val dates = date_time.substring(0,10)
        val url = JSONUtil.getJsonVal(msg,"url","")
        val urls = JSON.parseObject(url)
        val ak = JSONUtil.getJsonVal(urls,"ak","")
        val times = JSONUtil.getJsonVal(msg,"time","0")
        (types,date_time,dates,ak,times)
      }catch {
        case e: Exception => logger.error(e)
          ("","","","","0")
      }
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>>>>>>>>>>>>>>>>>获取解析日志数据量: "+logParseData.count())
    logParseData
  }


  /**
   *
   * @param spark
   * @param
   */
  def saveResult2Hive(spark : SparkSession,logParseData : RDD[(String, String, String, String, String)],parDay : String): Unit ={
    import spark.implicits._
    val descDBName = "default"
    val descTableName = "seg_monitoring_log_parse"
    val dropSQL =
      s"""
         |alter table default.seg_monitoring_log_parse drop if exists partition(inc_day = '$parDay')
         |""".stripMargin
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay')
         |SELECT
         | *
         |FROM seg_monitoring_log_parse_temp
         |""".stripMargin
    try{
      val queryDF = logParseData.coalesce(100).map(msg => Logs(msg._1,msg._2,msg._3,msg._4,msg._5))
        .toDF().persist(StorageLevel.DISK_ONLY)
      queryDF.createOrReplaceTempView("seg_monitoring_log_parse_temp")
      queryDF.printSchema()
      queryDF.show(5)
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>删除最新分区数据: "+dropSQL)
      spark.sql(dropSQL)
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive表: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
      spark.sql("drop table if exists seg_monitoring_log_parse_temp")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }

  case class Logs(types : String,date_time : String,dates : String,ak : String,times : String)

}
