package com.sf.gis.scala.seg.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.seg.util.{DbUtils, JavaUtil, MD5Util, Util}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 获取seg服务总性能数据，然后存入Mysql
 */
//noinspection DuplicatedCode
object SEGPerformanceMonitoringTotalIndexCal {
  @transient lazy val logger: Logger = Logger.getLogger(SEGPerformanceMonitoringTotalIndexCal.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    getSegTotalIndex(spark,incDay)
    spark.close()
  }


  /**
   * 统计seg服务总性能指标，然后写入Mysql表
   * @param spark
   * @param parDay
   * configFile ： Mysql配置文件
   * descTableName ： Mysql目标表
   */
  def getSegTotalIndex(spark:SparkSession,parDay:String)={
    println(parDay)
    val configFile = "addr.properties"
    val descTableName = "SEG_MONITORING_TOTAL_INDEX"
    val sql =
      s"""
         |SELECT * FROM default.seg_monitoring_total_index_tmp WHERE inc_day='$parDay'
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>sql: " + sql)
    val resultRDD = Util.getRowToJson(spark,sql)
    logger.error(">>>>>>>>>>>>>>>>>将统计seg性能指标写入Mysql表")
    save2Mysql(resultRDD,configFile,descTableName,parDay)
    resultRDD.unpersist()
  }




  /**
   * 保存数据到MySQL
   * @param resultRDD
   * @param configFile
   * @param descTableName
   */
  def save2Mysql(resultRDD : RDD[JSONObject],configFile : String,descTableName : String,parDay : String) = {
    val javaUtil = new JavaUtil()
    javaUtil.setFlag(12)
    val conn = DbUtils.getConnection(javaUtil)
    val md5Instance = MD5Util.getMD5Instance
    try {
      logger.error(">>>>>>>>>开始插入数据库<<<<<<<<<<")
      val delSql = String.format(s"delete from $descTableName where stat_date='%s'", parDay)
      logger.error(">>>保存之前，删除当天的数据:" + delSql)
      DbUtils.executeSql(conn, delSql)
      val insertSql = s"insert into $descTableName (`ID`,`STAT_DATE`,`SERVICE_NAME`,`AK`,`REQ_TOTAL`" +
        s",`AVG_RES_TIME`,`TIMES_90`,`TIMES_95`,`TIMES_99`) values(?,?,?,?,?,?,?,?,?)"
      logger.error(">>>>>>>>>insertSql<<<<<<<<<<: "+insertSql)
      var insertParams: Array[Any] = null
      resultRDD.collect().foreach(row => {
        val id = MD5Util.getMD5(md5Instance,Array(row.getString("dates"),row.getString("servicename"),JSONUtil.getJsonVal(row,"ak","")).mkString("_"))
        insertParams = Array(id,parDay,row.getString("servicename"),JSONUtil.getJsonVal(row,"ak",""),0,row.getString("avg_res_time").toInt
          ,row.getString("times_90").toInt,row.getString("times_95").toInt,row.getString("times_99").toInt)
        DbUtils.execute(conn,insertSql,insertParams)
      })
      logger.error(s">>>>>>>>>>>指标入库量: ${resultRDD.count()}<<<<<<<<<<<<<")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }


case class Logs(types : String,date_time : String,dates : String,ak : String,times : Int)



}
