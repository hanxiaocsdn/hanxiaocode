package com.sf.gis.scala.seg.bean;

import scala.Serializable;

public class EFSMSLog implements Serializable {
    private String type;
    private String dateTime;
    private String sn;
    private String url_s;
    private String url_e;
    private String url_white;
    private String url_geo;
    private String url_tc;
    private String url_efsdb;
    private String url_other;
    private String city_code;
    private String address;
    private String sys_type;
    private String data;
    private String src;
    private String code;
    private String chname;
    private String level;
    private String remarks;

    public String getType() {
        return type==null?"":type;
    }

    public EFSMSLog setType(String type) {
        this.type = type;
        return this;
    }
    public String getDateTime() {
        return dateTime==null?"":dateTime;
    }

    public EFSMSLog setDateTime(String dateTime) {
        this.dateTime = dateTime;
        return this;
    }

    public String getUrl_other() {
        return url_other==null?"":url_other;
    }

    public EFSMSLog setUrl_other(String url_other) {
        this.url_other = url_other;
        return this;
    }

    public String getSn() {
        return sn==null?"":sn;
    }

    public EFSMSLog setSn(String sn) {
        this.sn = sn;
        return this;
    }

    public String getUrl_s() {
        return url_s==null?"":url_s;
    }

    public EFSMSLog setUrl_s(String url_s) {
        this.url_s = url_s;
        return this;
    }

    public String getUrl_e() {
        return url_e==null?"":url_e;
    }

    public EFSMSLog setUrl_e(String url_e) {
        this.url_e = url_e;
        return this;
    }

    public String getUrl_white() {
        return url_white==null?"":url_white;
    }

    public EFSMSLog setUrl_white(String url_white) {
        this.url_white = url_white;
        return this;
    }

    public String getUrl_geo() {
        return url_geo==null?"":url_geo;
    }

    public EFSMSLog setUrl_geo(String url_geo) {
        this.url_geo = url_geo;
        return this;
    }

    public String getUrl_tc() {
        return url_tc==null?"":url_tc;
    }

    public EFSMSLog setUrl_tc(String url_tc) {
        this.url_tc = url_tc;
        return this;
    }

    public String getUrl_efsdb() {
        return url_efsdb==null?"":url_efsdb;
    }

    public EFSMSLog setUrl_efsdb(String url_efsdb) {
        this.url_efsdb = url_efsdb;
        return this;
    }

    public String getCity_code() {
        return city_code==null?"":city_code;
    }

    public EFSMSLog setCity_code(String city_code) {
        this.city_code = city_code;
        return this;
    }

    public String getAddress() {
        return address==null?"":address;
    }

    public EFSMSLog setAddress(String address) {
        this.address = address;
        return this;
    }

    public String getSys_type() {
        return sys_type==null?"":sys_type;
    }

    public EFSMSLog setSys_type(String sys_type) {
        this.sys_type = sys_type;
        return this;
    }

    public String getData() {
        return data==null?"":data;
    }

    public EFSMSLog setData(String data) {
        this.data = data;
        return this;
    }

    public String getSrc() {
        return src==null?"":src;
    }

    public EFSMSLog setSrc(String src) {
        this.src = src;
        return this;
    }

    public String getCode() {
        return code==null?"":code;
    }

    public EFSMSLog setCode(String code) {
        this.code = code;
        return this;
    }

    public String getChname() {
        return chname==null?"":chname;
    }

    public EFSMSLog setChname(String chname) {
        this.chname = chname;
        return this;
    }

    public String getLevel() {
        return level==null?"":level;
    }

    public EFSMSLog setLevel(String level) {
        this.level = level;
        return this;
    }

    public String getRemarks() {
        return remarks==null?"":remarks;
    }

    public EFSMSLog setRemarks(String remarks) {
        this.remarks = remarks;
        return this;
    }

    @Override
    public String  toString() {
        return "EFSMSLog{" +
                "type='" + type + '\'' +
                ", dateTime='" + dateTime + '\'' +
                ", sn='" + sn + '\'' +
                ", url_s='" + url_s + '\'' +
                ", url_e='" + url_e + '\'' +
                ", url_white='" + url_white + '\'' +
                ", url_geo='" + url_geo + '\'' +
                ", url_tc='" + url_tc + '\'' +
                ", url_efsdb='" + url_efsdb + '\'' +
                ", url_other='" + url_other + '\'' +
                ", city_code='" + city_code + '\'' +
                ", address='" + address + '\'' +
                ", sys_type='" + sys_type + '\'' +
                ", data='" + data + '\'' +
                ", src='" + src + '\'' +
                ", code='" + code + '\'' +
                ", chname='" + chname + '\'' +
                ", level='" + level + '\'' +
                ", remarks='" + remarks + '\'' +
                '}';
    }
}
