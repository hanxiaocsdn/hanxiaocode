package com.sf.gis.scala.seg.app

import java.sql.DriverManager
import java.text.SimpleDateFormat
import java.util.Calendar

import com.alibaba.fastjson.JSON
import com.sf.gis.scala.base.custom_module.MapCityRegionInfo
import com.sf.gis.scala.base.spark.Spark
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.SaveMode
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}

import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:
 * @Author: 01374443 张想远 (单天赐代码改造)
 * @CreateTime: 2023-03-03 14:06
 * @TaskId:224180,
 * @TaskName:ADDSLogStat
 * @Description:
 */
object ADDSLogStatService {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = LoggerFactory.getLogger(ADDSLogStatService.getClass)
  val hotCities = "" //('Adams','Carter')"
  val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

  case class LogParse(dataType: String, dateTime: String,
                      date: String, ak: String, time: Int, src: String, detailSrc: String,
                      sn: String, province: String, city: String, county: String, town: String,
                      adcode: String, citycode: String, detailaddr: String, orderno: String,
                      isTown: String, address: String, level: String, origin: String,
                      compare: String, showcode: String, province_code: String, citylev_code: String,
                      county_code: String, town_code: String, result: String, multiple: String,
                      mark: String, addressSuffix: String,
                      province_req: String, city_req: String, county_req: String, town_req: String,
                      conflict: String, moreThan: String, opt: String, lng: String,
                      lat: String,tipProvince : String,tipCity : String,tipCounty : String,tipTown : String, la:String
                     )

  def main(args: Array[String]): Unit = {
    val sparkSession = Spark.getSparkSession(appName)
    val cityMap = MapCityRegionInfo.queryCityRegionMapGroupByCityCode(sparkSession)
    import sparkSession.implicits._
    var tmpView = "tmp"
    var insertSql = ""
    Class.forName("com.mysql.jdbc.Driver").newInstance()
    @transient val connection = DriverManager.getConnection(
      "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_addr?characterEncoding=utf8",
      "gis_oms_addr",
      "gis_oms_addr@123@")


    logger.error("获取和设置日期...")
    var cDate = ""
    var runDate = ""
    var fromDate = ""
    var toDate = ""
    var beforeDate = ""
    var argcount = args.length
    if (argcount == 0) argcount = 1
    for (i <- 0 to argcount - 1) {
      if (args.length == 0) {
        val format = new SimpleDateFormat("yyyyMMdd")
        val calendar = Calendar.getInstance()
        cDate = format.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, -1)
        runDate = format.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, -1)
        beforeDate = format.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, -5)
        fromDate = format.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, 12)
        toDate = format.format(calendar.getTime)
      }
      else {
        val format = new SimpleDateFormat("yyyyMMdd")
        val date = format.parse(args(i))
        val calendar = Calendar.getInstance()
        calendar.setTime(date)
        runDate = args(i)
        calendar.add(Calendar.DAY_OF_MONTH, 1)
        cDate = format.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, -2)
        beforeDate = format.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, -5)
        fromDate = format.format(calendar.getTime)
        calendar.add(Calendar.DAY_OF_MONTH, 12)
      }

      logger.error("开始处理" + runDate)

      logger.error("读取dm_gis.ods_kafka_bee_logs_gis_rss_seg的当天信息")
      val bee_logs_gis_rss_seg_new_count = sparkSession.sql("select * from dm_gis.ods_kafka_bee_logs_gis_rss_seg where inc_day='" + runDate + "' or inc_day='" + cDate + "' limit 1")
      val bee_logs_gis_rss_seg_new_flag = bee_logs_gis_rss_seg_new_count.take(1).length == 0
      if (bee_logs_gis_rss_seg_new_flag) {
        logger.error("未从dm_gis.ods_kafka_bee_logs_gis_rss_seg取得日志数据，数量为0，放弃执行程序")
        logger.error("没有获取到数据！")
      }
      else {

        val gis_ass_adds_log_parse_new = sparkSession.sql("select logs from dm_gis.ods_kafka_bee_logs_gis_rss_seg where inc_day='" + runDate + "' or inc_day='" + cDate + "'").na.fill("").rdd.map(row => {
          var log = ""
          if (!row.isNullAt(0)) log = row.getString(0)
          var _type = ""
          var dateTime = ""
          var date = ""
          var ak = "-"
          var time = -1
          var src = ""
          var detailSrc = ""
          var sn = ""
          var province = ""
          var city = ""
          var county = ""
          var town = ""
          var adcode = ""
          var citycode = ""
          var detailaddr = ""
          var orderno = ""
          var isTown = ""

          var address = ""
          var level = ""
          var origin = ""
          var compare = ""
          var showcode = ""
          var province_code = ""
          var citylev_code = ""
          var county_code = ""
          var town_code = ""
          var result = ""
          var multiple = ""
          var mark = ""

          var addressSuffix = ""
          var province_req = ""
          var city_req = ""
          var county_req = ""
          var town_req = ""
          var conflict = ""
          var moreThan = ""
          var opt = ""
          var lng = ""
          var lat = ""
          var tipProvince  = ""
          var tipCity  = ""
          var tipCounty  = ""
          var tipTown  = ""
          var la = ""

          try {
            val logObject = JSON.parseObject(log)
            if (logObject != null) {
              var logString = logObject.getString("message")
              logString = logString.replaceAll("\\\\\\\\t", "").replaceAll("\\\\\\\\n", "")
              logString = logString.replaceAll("\n", "").replaceAll("\t", "")
              val jsonObject = JSON.parseObject(logString)

              dateTime = jsonObject.getString("dateTime")
              if (!StringUtils.isEmpty(dateTime) && dateTime.length >= 11) date = dateTime.substring(0, 10).replaceAll("-", "")
              _type = jsonObject.getString("type")
              sn = jsonObject.getString("sn")
              time = jsonObject.getIntValue("time")
              val urlObject = jsonObject.getJSONObject("url")
              if (urlObject != null) ak = urlObject.getString("ak")
              if (urlObject != null) orderno = urlObject.getString("orderno")
              if (urlObject != null) province_req = urlObject.getString("province")
              if (urlObject != null) city_req = urlObject.getString("city")
              if (urlObject != null) county_req = urlObject.getString("county")
              if (urlObject != null) town_req = urlObject.getString("town")
              if (urlObject != null) opt = urlObject.getString("opt")
              if (urlObject != null) la = urlObject.getString("la")
              val dataObject = jsonObject.getJSONObject("data")
              if (dataObject == null) {
                detailSrc = "NORS"
              }
              else {
                val resultObject = dataObject.getJSONObject("result")
                if (resultObject != null) {
                  result = resultObject.getString("result")
                  multiple = resultObject.getString("multiple")
                  mark = resultObject.getString("mark")
                  conflict = resultObject.getString("conflict")
                  moreThan = resultObject.getString("moreThan")
                  val queryObject = resultObject.getJSONObject("query")
                  if (queryObject != null) {
                    address = queryObject.getString("address")
                    if (!StringUtils.isEmpty(address)) address = address.replaceAll("\t", "").replaceAll("\n", "")
                    level = queryObject.getString("level")
                    origin = queryObject.getString("origin")
                    compare = queryObject.getString("compare")
                    showcode = queryObject.getString("showcode")
                  }
                  detailSrc = resultObject.getString("src")
                  val dataObject2 = resultObject.getJSONObject("data")
                  if (dataObject2 == null) {
                    detailSrc = "NORS"
                  }
                  else {
                    province = dataObject2.getString("province")
                    if (StringUtils.isEmpty(province)) detailSrc = "NORS"
                    city = dataObject2.getString("city")
                    county = dataObject2.getString("county")
                    town = dataObject2.getString("town")
                    adcode = dataObject2.getString("adcode")
                    citycode = dataObject2.getString("citycode")
                    detailaddr = dataObject2.getString("detailaddr")
                    if (!StringUtils.isEmpty(county) && !StringUtils.isEmpty(town)) isTown = "true"

                    province_code = dataObject2.getString("provinceCode")
                    citylev_code = dataObject2.getString("cityLevCode")
                    county_code = dataObject2.getString("countyCode")
                    town_code = dataObject2.getString("townCode")

                    tipProvince = dataObject2.getString("tipProvince")
                    tipCity = dataObject2.getString("tipCity")
                    tipCounty = dataObject2.getString("tipCounty")
                    tipTown = dataObject2.getString("tipTown")


                    addressSuffix = dataObject2.getString("addressSuffix")

                    lng = dataObject2.getString("lng")
                    lat = dataObject2.getString("lat")
                  }
                }
                else detailSrc = "NORS"
              }
            }
          }
          catch {
            case ex: Exception => {
              detailSrc = "NORS"
            }
          }


          if (StringUtils.isEmpty(_type)) _type = ""
          if (StringUtils.isEmpty(dateTime)) dateTime = ""
          if (StringUtils.isEmpty(ak) || StringUtils.isBlank(ak) || ak == None) ak = "-"
          if (StringUtils.isEmpty(detailSrc) || StringUtils.isBlank(detailSrc) || detailSrc == None) detailSrc = "NORS"
          if (StringUtils.isEmpty(sn)) sn = ""
          if (StringUtils.isEmpty(province)) province = ""
          if (StringUtils.isEmpty(city) || StringUtils.isBlank(city) || city == None) city = ""
          if (StringUtils.isEmpty(county)) county = ""
          if (StringUtils.isEmpty(town)) town = ""
          if (StringUtils.isEmpty(adcode)) adcode = ""
          if (StringUtils.isEmpty(citycode)) citycode = ""
          if (StringUtils.isEmpty(detailaddr)) detailaddr = ""
          else detailaddr = detailaddr.replaceAll("\t", "")
          if (StringUtils.isEmpty(date)) date = ""
          if (StringUtils.isEmpty(orderno)) orderno = ""
          ak = StringUtils.stripToEmpty(StringUtils.trimToEmpty(ak))
          detailSrc = StringUtils.stripToEmpty(StringUtils.trimToEmpty(detailSrc))
          city = StringUtils.stripToEmpty(StringUtils.trimToEmpty(city))
          if (!StringUtils.isEmpty(detailSrc)) detailSrc = detailSrc.toUpperCase
          else detailSrc = "NORS"
          if (ak.length < 10 || ak.length > 49) ak = "-"
          if (!detailSrc.matches("[A-z|0-9]+")) detailSrc = "NORS"
//          if (city.length < 3) city = "-"
          if (detailSrc.contains("|")) src = detailSrc.split("\\|")(0)
          else src = detailSrc

          if (StringUtils.isEmpty(address)) address = ""
          if (StringUtils.isEmpty(level)) level = ""
          if (StringUtils.isEmpty(origin)) origin = ""
          if (StringUtils.isEmpty(compare)) compare = ""
          if (StringUtils.isEmpty(showcode)) showcode = ""
          if (StringUtils.isEmpty(province_code)) province_code = ""
          if (StringUtils.isEmpty(citylev_code)) citylev_code = ""
          if (StringUtils.isEmpty(county_code)) county_code = ""
          if (StringUtils.isEmpty(town_code)) town_code = ""
          if (StringUtils.isEmpty(result)) result = ""
          if (StringUtils.isEmpty(multiple)) multiple = ""
          if (StringUtils.isEmpty(mark)) mark = ""

          if (StringUtils.isEmpty(addressSuffix)) addressSuffix = ""
          if (StringUtils.isEmpty(province_req)) province_req = ""
          if (StringUtils.isEmpty(city_req)) city_req = ""
          if (StringUtils.isEmpty(county_req)) county_req = ""
          if (StringUtils.isEmpty(town_req)) town_req = ""
          if (StringUtils.isEmpty(conflict)) conflict = ""
          if (StringUtils.isEmpty(moreThan)) moreThan = ""
          if (StringUtils.isEmpty(opt)) opt = ""
          if (StringUtils.isEmpty(lng)) lng = ""
          if (StringUtils.isEmpty(lat)) lat = ""

          if (StringUtils.isEmpty(tipProvince )) tipProvince  = ""
          if (StringUtils.isEmpty(tipCity )) tipCity  = ""
          if (StringUtils.isEmpty(tipCounty )) tipCounty  = ""
          if (StringUtils.isEmpty(tipTown )) tipTown  = ""
          if (StringUtils.isEmpty(la )) la  = ""





          LogParse(_type.replaceAll("\t", "").replaceAll("\n", ""),
            dateTime.replaceAll("\t", "").replaceAll("\n", ""),
            date.replaceAll("\t", "").replaceAll("\n", ""),
            ak.replaceAll("\t", "").replaceAll("\n", ""),
            time, src.replaceAll("\t", "").replaceAll("\n", ""),
            detailSrc.replaceAll("\t", "").replaceAll("\n", ""),
            sn.replaceAll("\t", "").replaceAll("\n", ""),
            province.replaceAll("\t", "").replaceAll("\n", ""),
            city.replaceAll("\t", "").replaceAll("\n", ""),
            county.replaceAll("\t", "").replaceAll("\n", ""),
            town.replaceAll("\t", "").replaceAll("\n", ""),
            adcode.replaceAll("\t", "").replaceAll("\n", ""),
            citycode.replaceAll("\t", "").replaceAll("\n", ""),
            detailaddr.replaceAll("\t", "").replaceAll("\n", ""),
            orderno.replaceAll("\t", "").replaceAll("\n", ""),
            isTown.replaceAll("\t", "").replaceAll("\n", ""),
            address.replaceAll("\t", "").replaceAll("\n", ""),
            level.replaceAll("\t", "").replaceAll("\n", ""),
            origin.replaceAll("\t", "").replaceAll("\n", ""),
            compare.replaceAll("\t", "").replaceAll("\n", ""),
            showcode.replaceAll("\t", "").replaceAll("\n", ""),
            province_code.replaceAll("\t", "").replaceAll("\n", ""),
            citylev_code.replaceAll("\t", "").replaceAll("\n", ""),
            county_code.replaceAll("\t", "").replaceAll("\n", ""),
            town_code.replaceAll("\t", "").replaceAll("\n", ""),
            result.replaceAll("\t", "").replaceAll("\n", ""),
            multiple.replaceAll("\t", "").replaceAll("\n", ""),
            mark.replaceAll("\t", "").replaceAll("\n", ""),
            addressSuffix.replaceAll("\t", "").replaceAll("\n", ""),
            province_req.replaceAll("\t", "").replaceAll("\n", ""),
            city_req.replaceAll("\t", "").replaceAll("\n", ""),
            county_req.replaceAll("\t", "").replaceAll("\n", ""),
            town_req.replaceAll("\t", "").replaceAll("\n", ""),
            conflict.replaceAll("\t", "").replaceAll("\n", ""),
            moreThan.replaceAll("\t", "").replaceAll("\n", ""),
            opt.replaceAll("\t", "").replaceAll("\n", ""),
            lng.replaceAll("\t", "").replaceAll("\n", ""),
            lat.replaceAll("\t", "").replaceAll("\n", ""),
            tipProvince .replaceAll("\t", "").replaceAll("\n", ""),
            tipCity .replaceAll("\t", "").replaceAll("\n", ""),
            tipCounty .replaceAll("\t", "").replaceAll("\n", ""),
            tipTown .replaceAll("\t", "").replaceAll("\n", ""),
            la.replaceAll("\t", "").replaceAll("\n", "")
          )
        }).filter(row => runDate.equalsIgnoreCase(row.date)).toDF().repartition(400).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        tmpView = "tmp" + System.currentTimeMillis()
        gis_ass_adds_log_parse_new.createOrReplaceTempView(tmpView)
        insertSql = s"insert overwrite table dm_gis.gis_ass_adds_log_parse partition(inc_day=$runDate) select * from $tmpView"
        logger.error(insertSql)
        sparkSession.sql(insertSql)
        logger.error("导入到dm_gis.gis_ass_adds_log_parse表")


        logger.error("开始统计gis_ass_adds_log_stat_ak")
        val gis_ass_adds_log_parse_group_ak_total_request_freq = sparkSession.sql("select ak,count(1) as total_request_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_s' group by ak")
        val gis_ass_adds_log_parse_group_ak_total_freq = sparkSession.sql("select ak,src,detailSrc,count(1) as total_response_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_e' group by ak,src,detailSrc")
        val gis_ass_adds_log_parse_group_ak_province_freq = sparkSession.sql("select ak,src,detailSrc,count(1) as province_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and province<>'' and city='' and type = 'url_e'  group by ak,src,detailSrc")
        val gis_ass_adds_log_parse_group_ak_city_freq = sparkSession.sql("select ak,src,detailSrc,count(1) as city_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and city<>'' and county='' and type = 'url_e'  group by ak,src,detailSrc")
        val gis_ass_adds_log_parse_group_ak_county_freq = sparkSession.sql("select ak,src,detailSrc,count(1) as county_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and county<>'' and town='' and type = 'url_e'  group by ak,src,detailSrc")
        val gis_ass_adds_log_parse_group_ak_town_freq = sparkSession.sql("select ak,src,detailSrc,count(1) as town_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and county<>'' and town<>'' and type = 'url_e'  group by ak,src,detailSrc")

        gis_ass_adds_log_parse_group_ak_total_request_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_total_request_freq")
        gis_ass_adds_log_parse_group_ak_total_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_total_freq")
        gis_ass_adds_log_parse_group_ak_province_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_province_freq")
        gis_ass_adds_log_parse_group_ak_city_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_freq")
        gis_ass_adds_log_parse_group_ak_county_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_county_freq")
        gis_ass_adds_log_parse_group_ak_town_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_town_freq")

        val gis_ass_adds_log_parse_group_ak_total_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,b.total_request_freq,a.total_response_freq from gis_ass_adds_log_parse_group_ak_total_freq a left join gis_ass_adds_log_parse_group_ak_total_request_freq b on a.ak=b.ak")
        gis_ass_adds_log_parse_group_ak_total_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_total_freq2")
        val gis_ass_adds_log_parse_group_ak_province_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.total_request_freq,a.total_response_freq,b.province_freq from gis_ass_adds_log_parse_group_ak_total_freq2 a left join gis_ass_adds_log_parse_group_ak_province_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc")
        gis_ass_adds_log_parse_group_ak_province_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_province_freq2")
        val gis_ass_adds_log_parse_group_ak_city_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.total_request_freq,a.total_response_freq,a.province_freq,b.city_freq from gis_ass_adds_log_parse_group_ak_province_freq2 a left join gis_ass_adds_log_parse_group_ak_city_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc")
        gis_ass_adds_log_parse_group_ak_city_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_freq2")
        val gis_ass_adds_log_parse_group_ak_county_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.total_request_freq,a.total_response_freq,a.province_freq,a.city_freq,b.county_freq from gis_ass_adds_log_parse_group_ak_city_freq2 a left join gis_ass_adds_log_parse_group_ak_county_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc")
        gis_ass_adds_log_parse_group_ak_county_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_county_freq2")
        val gis_ass_adds_log_parse_group_ak_town_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.total_request_freq,a.total_response_freq,a.province_freq,a.city_freq,a.county_freq,b.town_freq from gis_ass_adds_log_parse_group_ak_county_freq2 a left join gis_ass_adds_log_parse_group_ak_town_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc")

        val gis_ass_adds_log_stat_ak_new = gis_ass_adds_log_parse_group_ak_town_freq2.na.fill("").rdd.map(row => {
          var ak = row.getString(0)
          var src = row.getString(1)
          var detailSrc = row.getString(2)
          var total_request_freq = 0l
          var total_response_freq = 0l
          var province_freq = 0l
          var city_freq = 0l
          var county_freq = 0l
          var town_freq = 0l
          if (!row.isNullAt(3)) total_request_freq = row.getLong(3)
          if (!row.isNullAt(4)) total_response_freq = row.getLong(4)
          if (!row.isNullAt(5)) province_freq = row.getLong(5)
          if (!row.isNullAt(6)) city_freq = row.getLong(6)
          if (!row.isNullAt(7)) county_freq = row.getLong(7)
          if (!row.isNullAt(8)) town_freq = row.getLong(8)

          if (StringUtils.isEmpty(ak)) ak = "-"
          (ak, src, detailSrc, total_request_freq, total_response_freq, province_freq, city_freq, county_freq, town_freq)
        }).toDF("ak", "src", "detailSrc", "total_request_freq", "total_response_freq",
          "province_freq", "city_freq", "county_freq", "town_freq")
          .repartition(1)

        tmpView = "tmp" + System.currentTimeMillis()
        gis_ass_adds_log_stat_ak_new.createOrReplaceTempView(tmpView)
        insertSql = s"insert overwrite table dm_gis.gis_ass_adds_log_stat_ak partition(inc_day=$runDate) select * from $tmpView"
        logger.error(insertSql)
        sparkSession.sql(insertSql)
        logger.error("导入到dm_gis.gis_ass_adds_log_stat_ak表")


        logger.error("开始统计gis_ass_adds_log_stat_city")
        val gis_ass_adds_log_parse_group_city_total_request_freq = sparkSession.sql("select count(1) as request_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_s'")
        val gis_ass_adds_log_parse_group_city_total_freq = sparkSession.sql("select src,detailSrc,city,count(1) as total_response_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_e'  group by src,detailSrc,city")
        val gis_ass_adds_log_parse_group_city_province_freq = sparkSession.sql("select src,detailSrc,city,count(1) as province_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and province<>'' and city='' and type = 'url_e'  group by src,detailSrc,city")
        val gis_ass_adds_log_parse_group_city_city_freq = sparkSession.sql("select src,detailSrc,city,count(1) as city_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and city<>'' and county='' and type = 'url_e'  group by src,detailSrc,city")
        val gis_ass_adds_log_parse_group_city_county_freq = sparkSession.sql("select src,detailSrc,city,count(1) as county_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and county<>'' and town='' and type = 'url_e'  group by src,detailSrc,city")
        val gis_ass_adds_log_parse_group_city_town_freq = sparkSession.sql("select src,detailSrc,city,count(1) as town_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and county<>'' and town<>'' and type = 'url_e'  group by src,detailSrc,city")

        gis_ass_adds_log_parse_group_city_total_request_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_total_request_freq")
        gis_ass_adds_log_parse_group_city_total_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_total_freq")
        gis_ass_adds_log_parse_group_city_province_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_province_freq")
        gis_ass_adds_log_parse_group_city_city_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_city_freq")
        gis_ass_adds_log_parse_group_city_county_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_county_freq")
        gis_ass_adds_log_parse_group_city_town_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_town_freq")

        val gis_ass_adds_log_parse_group_city_total_freq2 = sparkSession.sql("select src,detailSrc,city,(SELECT request_freq FROM gis_ass_adds_log_parse_group_city_total_request_freq) AS total_request_freq,total_response_freq from gis_ass_adds_log_parse_group_city_total_freq")
        gis_ass_adds_log_parse_group_city_total_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_total_freq2")
        val gis_ass_adds_log_parse_group_city_province_freq2 = sparkSession.sql("select a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,b.province_freq from gis_ass_adds_log_parse_group_city_total_freq2 a left join gis_ass_adds_log_parse_group_city_province_freq b on a.detailSrc=b.detailSrc and a.city=b.city")
        gis_ass_adds_log_parse_group_city_province_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_province_freq2")
        val gis_ass_adds_log_parse_group_city_city_freq2 = sparkSession.sql("select a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,a.province_freq,b.city_freq from gis_ass_adds_log_parse_group_city_province_freq2 a left join gis_ass_adds_log_parse_group_city_city_freq b on a.detailSrc=b.detailSrc and a.city=b.city")
        gis_ass_adds_log_parse_group_city_city_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_city_freq2")
        val gis_ass_adds_log_parse_group_city_county_freq2 = sparkSession.sql("select a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,a.province_freq,a.city_freq,b.county_freq from gis_ass_adds_log_parse_group_city_city_freq2 a left join gis_ass_adds_log_parse_group_city_county_freq b on a.detailSrc=b.detailSrc and a.city=b.city")
        gis_ass_adds_log_parse_group_city_county_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_city_county_freq2")
        val gis_ass_adds_log_parse_group_city_town_freq2 = sparkSession.sql("select a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,a.province_freq,a.city_freq,a.county_freq,b.town_freq from gis_ass_adds_log_parse_group_city_county_freq2 a left join gis_ass_adds_log_parse_group_city_town_freq b on a.detailSrc=b.detailSrc and a.city=b.city")


        val gis_ass_adds_log_stat_city_new = gis_ass_adds_log_parse_group_city_town_freq2.na.fill("").rdd.map(row => {
          var province = ""
          var region = ""
          var city = row.getString(2)
          var citycode = ""
          var src = row.getString(0)
          var detailSrc = row.getString(1)
          var total_request_freq = 0l
          var total_response_freq = 0l
          var province_freq = 0l
          var city_freq = 0l
          var county_freq = 0l
          var town_freq = 0l

          //caca
          if (!row.isNullAt(3)) total_request_freq = row.getLong(3)
          if (!row.isNullAt(4)) total_response_freq = row.getLong(4)
          if (!row.isNullAt(5)) province_freq = row.getLong(5)
          if (!row.isNullAt(6)) city_freq = row.getLong(6)
          if (!row.isNullAt(7)) county_freq = row.getLong(7)
          if (!row.isNullAt(8)) town_freq = row.getLong(8)

          var cityInfoMap = cityMap.get(city)
          if (cityInfoMap == None) {
          }
          else {
            province = cityInfoMap.get.get("province").get
            region = cityInfoMap.get.get("region").get
            citycode = cityInfoMap.get.get("city_code").get
          }
          if (StringUtils.isEmpty(province)) province = "-"
          if (StringUtils.isEmpty(region)) region = "-"
          if (StringUtils.isEmpty(citycode)) citycode = "-"
          if (StringUtils.isEmpty(city)) city = "-"

          (province, region, city, citycode, src, detailSrc, total_request_freq, total_response_freq, province_freq, city_freq, county_freq, town_freq)
        }).toDF("province", "region", "city", "citycode", "src", "detailSrc", "total_request_freq", "total_response_freq", "province_freq", "city_freq", "county_freq", "town_freq")
          .repartition(1)
        tmpView = "tmp" + System.currentTimeMillis()
        gis_ass_adds_log_stat_city_new.createOrReplaceTempView(tmpView)
        insertSql = s"insert overwrite table dm_gis.gis_ass_adds_log_stat_city partition(inc_day=$runDate) select * from $tmpView"
        logger.error(insertSql)
        sparkSession.sql(insertSql)
        logger.error("导入到dm_gis.gis_ass_adds_log_stat_city表")


        logger.error("开始统计gis_ass_adds_log_stat_ak_city")
        val gis_ass_adds_log_parse_group_ak_city_total_request_freq = sparkSession.sql("select ak,count(1) as total_request_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_s'  group by ak")
        val gis_ass_adds_log_parse_group_ak_city_total_freq = sparkSession.sql("select ak,src,detailSrc,city,count(1) as total_response_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_e'  group by ak,src,detailSrc,city")
        val gis_ass_adds_log_parse_group_ak_city_province_freq = sparkSession.sql("select ak,src,detailSrc,city,count(1) as province_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and province<>'' and city='' and type = 'url_e'  group by ak,src,detailSrc,city")
        val gis_ass_adds_log_parse_group_ak_city_city_freq = sparkSession.sql("select ak,src,detailSrc,city,count(1) as city_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and city<>'' and county='' and type = 'url_e'  group by ak,src,detailSrc,city")
        val gis_ass_adds_log_parse_group_ak_city_county_freq = sparkSession.sql("select ak,src,detailSrc,city,count(1) as county_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and county<>'' and town='' and type = 'url_e'  group by ak,src,detailSrc,city")
        val gis_ass_adds_log_parse_group_ak_city_town_freq = sparkSession.sql("select ak,src,detailSrc,city,count(1) as town_freq from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and county<>'' and town<>'' and type = 'url_e'  group by ak,src,detailSrc,city")

        gis_ass_adds_log_parse_group_ak_city_total_request_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_total_request_freq")
        gis_ass_adds_log_parse_group_ak_city_total_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_total_freq")
        gis_ass_adds_log_parse_group_ak_city_province_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_province_freq")
        gis_ass_adds_log_parse_group_ak_city_city_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_city_freq")
        gis_ass_adds_log_parse_group_ak_city_county_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_county_freq")
        gis_ass_adds_log_parse_group_ak_city_town_freq.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_town_freq")

        val gis_ass_adds_log_parse_group_ak_city_total_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.city,b.total_request_freq,a.total_response_freq from gis_ass_adds_log_parse_group_ak_city_total_freq a left join gis_ass_adds_log_parse_group_ak_city_total_request_freq b on a.ak=b.ak")
        gis_ass_adds_log_parse_group_ak_city_total_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_total_freq2")
        val gis_ass_adds_log_parse_group_ak_city_province_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,b.province_freq from gis_ass_adds_log_parse_group_ak_city_total_freq2 a left join gis_ass_adds_log_parse_group_ak_city_province_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc and a.city=b.city")
        gis_ass_adds_log_parse_group_ak_city_province_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_province_freq2")
        val gis_ass_adds_log_parse_group_ak_city_city_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,a.province_freq,b.city_freq from gis_ass_adds_log_parse_group_ak_city_province_freq2 a left join gis_ass_adds_log_parse_group_ak_city_city_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc and a.city=b.city")
        gis_ass_adds_log_parse_group_ak_city_city_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_city_freq2")
        val gis_ass_adds_log_parse_group_ak_city_county_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,a.province_freq,a.city_freq,b.county_freq from gis_ass_adds_log_parse_group_ak_city_city_freq2 a left join gis_ass_adds_log_parse_group_ak_city_county_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc and a.city=b.city")
        gis_ass_adds_log_parse_group_ak_city_county_freq2.createOrReplaceTempView("gis_ass_adds_log_parse_group_ak_city_county_freq2")
        val gis_ass_adds_log_parse_group_ak_city_town_freq2 = sparkSession.sql("select a.ak,a.src,a.detailSrc,a.city,a.total_request_freq,a.total_response_freq,a.province_freq,a.city_freq,a.county_freq,b.town_freq from gis_ass_adds_log_parse_group_ak_city_county_freq2 a left join gis_ass_adds_log_parse_group_ak_city_town_freq b on a.ak=b.ak and a.detailSrc=b.detailSrc and a.city=b.city")

        val gis_ass_adds_log_stat_ak_city_new = gis_ass_adds_log_parse_group_ak_city_town_freq2.na.fill("").rdd.map(row => {
          var ak = row.getString(0)
          var province = ""
          var region = ""
          var city = row.getString(3)
          var citycode = ""
          var src = row.getString(1)
          var detailSrc = row.getString(2)
          var total_request_freq = 0l
          var total_response_freq = 0l
          var province_freq = 0l
          var city_freq = 0l
          var county_freq = 0l
          var town_freq = 0l

          if (!row.isNullAt(4)) total_request_freq = row.getLong(4)
          if (!row.isNullAt(5)) total_response_freq = row.getLong(5)
          if (!row.isNullAt(6)) province_freq = row.getLong(6)
          if (!row.isNullAt(7)) city_freq = row.getLong(7)
          if (!row.isNullAt(8)) county_freq = row.getLong(8)
          if (!row.isNullAt(9)) town_freq = row.getLong(9)

          var cityInfoMap = cityMap.get(city)
          if (cityInfoMap == None) {
          }
          else {
            province = cityInfoMap.get.get("province").get
            region = cityInfoMap.get.get("region").get
            citycode = cityInfoMap.get.get("city_code").get
          }
          if (StringUtils.isEmpty(province)) province = "-"
          if (StringUtils.isEmpty(region)) region = "-"
          if (StringUtils.isEmpty(citycode)) citycode = "-"
          if (StringUtils.isEmpty(city)) city = "-"

          if (StringUtils.isEmpty(ak)) ak = "-"
          (ak, province, region, city, citycode, src, detailSrc, total_request_freq, total_response_freq, province_freq, city_freq, county_freq, town_freq)
        }).toDF("ak", "province", "region", "city", "citycode", "src", "detailSrc", "total_request_freq", "total_response_freq", "province_freq", "city_freq", "county_freq", "town_freq")
          .repartition(1)
        tmpView = "tmp" + System.currentTimeMillis()
        gis_ass_adds_log_stat_ak_city_new.createOrReplaceTempView(tmpView)
        insertSql = s"insert overwrite table dm_gis.gis_ass_adds_log_stat_ak_city partition(inc_day=$runDate) select * from $tmpView"
        logger.error(insertSql)
        sparkSession.sql(insertSql)
        logger.error("导入到dm_gis.gis_ass_adds_log_stat_ak_city表")


        logger.error("开始统计gis_ass_adds_log_stat_orderno_ak")
        val x1 = sparkSession.sql("select if(ak='' or ak is null, '-', ak) as ak,orderno,count(1) as total_request_freq,count(IF (orderno = '' or orderno is null, TRUE, NULL)) AS no_orderno_freq,count(IF (orderno <> '' and orderno is not null, TRUE, NULL)) AS has_orderno_freq,IF(orderno <> '' and orderno is not null,1,0) as distinct_orderno_freq,count(IF (orderno <> '' and orderno is not null and isTown = 'true', TRUE, NULL)) AS town_freq1 from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_e' group by ak,orderno")
        val x2 = sparkSession.sql("select if(a.ak='' or a.ak is null, '-', a.ak) as ak,a.orderno,IF(a.orderno <> '' and a.orderno is not null,1,0) as town_freq2 from dm_gis.gis_ass_adds_log_parse a, (select ak,orderno,max(dateTime) dateTime from dm_gis.gis_ass_adds_log_parse where inc_day ='" + runDate + "' and type = 'url_e' group by ak,orderno) b where a.ak = b.ak and a.orderno = b.orderno and a.dateTime = b.dateTime and a.isTown='true' and a.inc_day = '" + runDate + "' and a.type = 'url_e' group by a.ak,a.orderno")
        x1.createOrReplaceTempView("x1")
        x2.createOrReplaceTempView("x2")
        val gis_ass_adds_log_stat_orderno_ak_orderno_new = sparkSession.sql("select x1.ak,x1.orderno,x1.total_request_freq,x1.has_orderno_freq,x1.no_orderno_freq,x1.distinct_orderno_freq,x1.town_freq1,x2.town_freq2" +
          " from x1 left join x2 on x1.ak=x2.ak and x1.orderno = x2.orderno").na.fill("")
          .repartition(100)
        tmpView = "tmp" + System.currentTimeMillis()
        gis_ass_adds_log_stat_orderno_ak_orderno_new.createOrReplaceTempView(tmpView)
        insertSql = s"insert overwrite table dm_gis.gis_ass_adds_log_stat_orderno_ak_orderno partition(inc_day=$runDate) select * from $tmpView"
        logger.error(insertSql)
        sparkSession.sql(insertSql)
        logger.error("导入到dm_gis.gis_ass_adds_log_stat_orderno_ak_orderno表")

        val xx = sparkSession.sql("select ak,sum(total_request_freq) as total_request_freq,sum(has_orderno_freq) as has_orderno_freq,sum(no_orderno_freq) as no_orderno_freq," +
          "sum(distinct_orderno_freq) as distinct_orderno_freq,sum(town_freq1) as town_freq1, sum(town_freq2) as town_freq2 from dm_gis.gis_ass_adds_log_stat_orderno_ak_orderno where inc_day='" + runDate + "' group by ak")
          .rdd
          .map(row => {
            var ak = row.getString(0)
            var total_request_freq = row.getLong(1)
            var has_orderno_freq = row.getLong(2)
            var no_orderno_freq = row.getLong(3)
            var distinct_orderno_freq = row.getLong(4)
            var town_freq1 = row.getLong(5)
            var town_ratio1 = 0.0
            var town_freq2 = 0l
            if (!row.isNullAt(6)) town_freq2 = row.getLong(6)
            var town_ratio2 = 0.0
            if (StringUtils.isEmpty(ak)) ak = "-"

            if (total_request_freq > 0) town_ratio1 = ((town_freq1.toDouble / total_request_freq.toDouble) * 100).formatted("%.2f").toDouble
            if (total_request_freq > 0) town_ratio2 = ((town_freq2.toDouble / total_request_freq.toDouble) * 100).formatted("%.2f").toDouble
            (ak, total_request_freq, has_orderno_freq, no_orderno_freq, distinct_orderno_freq, town_freq1, town_ratio1, town_freq2, town_ratio2)
          }).toDF("ak", "total_request_freq", "has_orderno_freq", "no_orderno_freq", "distinct_orderno_freq", "town_freq1", "town_ratio1", "town_freq2", "town_ratio2")
          .repartition(1)

        tmpView = "tmp" + System.currentTimeMillis()
        xx.createOrReplaceTempView(tmpView)
        insertSql = s"insert overwrite table dm_gis.gis_ass_adds_log_stat_orderno_ak partition(inc_day=$runDate) select * from $tmpView"
        logger.error(insertSql)
        sparkSession.sql(insertSql)
        logger.error("导入到dm_gis.gis_ass_adds_log_stat_orderno_ak表")

        logger.error("开始推送到mysql...")
        val gis_ass_adds_log_stat_ak = sparkSession.sql("select ak,src,detailSrc,total_request_freq,total_response_freq,province_freq,city_freq,county_freq,town_freq from dm_gis.gis_ass_adds_log_stat_ak where inc_day='" + runDate + "'").na.fill("").rdd.map(row => {
          val ak = row.getString(0)
          val src = row.getString(1)
          val detailSrc = row.getString(2)
          val id = DigestUtils.md5Hex(runDate + ak + src + detailSrc)
          (id, runDate, ak, src, detailSrc, row.getLong(3).toInt, row.getLong(4).toInt, row.getLong(5).toInt, row.getLong(6).toInt, row.getLong(7).toInt, row.getLong(8).toInt, row.getLong(8).toInt)
        })

        val gis_ass_adds_log_stat_city = sparkSession.sql("select province,region,city,citycode,src,detailSrc,total_request_freq,total_response_freq,province_freq,city_freq,county_freq,town_freq from dm_gis.gis_ass_adds_log_stat_city where inc_day='" + runDate + "'").na.fill("").rdd.map(row => {
          val city = row.getString(2)
          val src = row.getString(4)
          val detailSrc = row.getString(5)
          val id = DigestUtils.md5Hex(runDate + city + src + detailSrc)
          (id, runDate, row.getString(0), row.getString(1), city, row.getString(3), src, detailSrc, row.getLong(6).toInt, row.getLong(7).toInt, row.getLong(8).toInt, row.getLong(9).toInt, row.getLong(10).toInt, row.getLong(11).toInt, row.getLong(11).toInt)
        })


        val gis_ass_adds_log_stat_orderno_ak = sparkSession.sql("select ak,total_request_freq,has_orderno_freq,no_orderno_freq,distinct_orderno_freq,town_freq1,town_freq2 from dm_gis.gis_ass_adds_log_stat_orderno_ak where inc_day='" + runDate + "'").na.fill("").rdd.map(row => {
          val ak = row.getString(0)
          val id = DigestUtils.md5Hex(runDate + ak)
          (id, runDate, "-", "-", "-", "-", ak, row.getLong(1).toInt, row.getLong(2).toInt, row.getLong(3).toInt, row.getLong(4).toInt, row.getLong(5).toInt, row.getLong(6).toInt)
        })


        val gis_ass_adds_log_stat_ak_dataframe = gis_ass_adds_log_stat_ak.toDF("ID", "STAT_DATE", "AK", "RESP_TYPE", "RESP_TYPE_SUB", "REQ", "RESP", "RESP_P", "RESP_PC", "RESP_PCD", "RESP_PCDS", "RESP_S")
        val gis_ass_adds_log_stat_city_dataframe = gis_ass_adds_log_stat_city.toDF("ID", "STAT_DATE", "PROVINCE", "REGION", "CITY", "CITY_CODE", "RESP_TYPE", "RESP_TYPE_SUB", "REQ", "RESP", "RESP_P", "RESP_PC", "RESP_PCD", "RESP_PCDS", "RESP_S")

        val gis_ass_adds_log_stat_orderno_ak_dataframe = gis_ass_adds_log_stat_orderno_ak.toDF("ID", "STAT_DATE", "PROVINCE", "REGION", "CITY", "CITY_CODE", "AK", "TOTAL", "ORDER", "ORDER_NO", "GRP", "GRP_ANALYSIS_PER", "GRP_ANALYSIS_LAST")


        var flag2 = false
        breakable(
          for (i <- 1 to 10) {
            try {
              logger.error("清除mysql当天的gis_ass_adds_log_stat_ak的数据...")
              val sql_ak = "delete from ADDS_AK where STAT_DATE = '" + runDate + "'"
              val statement_ak = connection.createStatement
              statement_ak.executeUpdate(sql_ak)

              logger.error("清除mysql当天的gis_ass_adds_log_stat_city的数据...")
              val sql_city = "delete from ADDS_ADMIN where STAT_DATE = '" + runDate + "'"
              val statement_city = connection.createStatement
              statement_city.executeUpdate(sql_city)


              logger.error("清除mysql当天的gis_ass_adds_log_stat_orderno_ak的数据...")
              val sql_orderno_ak = "delete from SHX_STAT where STAT_DATE = '" + runDate + "'"
              val statement_orderno_ak = connection.createStatement
              statement_orderno_ak.executeUpdate(sql_orderno_ak)


              logger.error("将当天的gis_ass_adds_log_stat_ak的数据存入mysql...")
              gis_ass_adds_log_stat_ak_dataframe.write.mode(SaveMode.Append).format("jdbc")
                .option("url", "jdbc:mysql://10.119.72.209:3306") //10.202.43.235
                .option("dbtable", "gis_oms_lip_addr.ADDS_AK")
                .option("user", "gis_oms_addr")
                .option("password", "gis_oms_addr@123@")
                .save()

              logger.error("将当天的gis_ass_adds_log_stat_city的数据存入mysql...")
              gis_ass_adds_log_stat_city_dataframe.write.mode(SaveMode.Append).format("jdbc")
                .option("url", "jdbc:mysql://10.119.72.209:3306") //10.202.43.235
                .option("dbtable", "gis_oms_lip_addr.ADDS_ADMIN")
                .option("user", "gis_oms_addr")
                .option("password", "gis_oms_addr@123@")
                .save()


              logger.error("将当天的gis_ass_adds_log_stat_orderno_ak的数据存入mysql...")
              gis_ass_adds_log_stat_orderno_ak_dataframe.write.mode(SaveMode.Append).format("jdbc")
                .option("url", "jdbc:mysql://10.119.72.209:3306") //10.202.43.235
                .option("dbtable", "gis_oms_lip_addr.SHX_STAT")
                .option("user", "gis_oms_addr")
                .option("password", "gis_oms_addr@123@")
                .save()


              logger.error("清除和更新mysql的Ak的数据...")
              val sql_aks = "delete from AK where PROJECT = 'ADDS'"
              val sql_aks_insert = "insert into AK(Id,AK,PROJECT) select ID, AK,'ADDS' from ADDS_AK where AK<>'' and AK<>'-' and AK is not null group by AK"
              val statement_aks = connection.createStatement
              statement_aks.executeUpdate(sql_aks)
              statement_aks.executeUpdate(sql_aks_insert)


              if (!StringUtils.isEmpty(hotCities)) {
                val gis_ass_adds_log_stat_ak_city = sparkSession.sql("select ak,province,region,city,citycode,src,detailSrc,total_request_freq,total_response_freq,province_freq,city_freq,county_freq,town_freq from dm_gis.gis_ass_adds_log_stat_ak_city where inc_day='" + runDate + "' and city in " + hotCities).na.fill("").rdd.map(row => {
                  val ak = row.getString(0)
                  val city = row.getString(3)
                  val src = row.getString(5)
                  val detailSrc = row.getString(6)
                  val id = DigestUtils.md5Hex(runDate + city + ak + src + detailSrc)
                  (id, runDate, row.getString(1), row.getString(2), city, row.getString(4), ak, src, detailSrc, row.getLong(7).toInt, row.getLong(8).toInt, row.getLong(9).toInt, row.getLong(10).toInt, row.getLong(11).toInt, row.getLong(12).toInt, row.getLong(12).toInt)
                }).filter(row => row._7.length <= 34)

                val gis_ass_adds_log_stat_ak_city_dataframe = gis_ass_adds_log_stat_ak_city.toDF("ID", "STAT_DATE", "PROVINCE", "REGION", "CITY", "CITY_CODE", "AK", "RESP_TYPE", "RESP_TYPE_SUB", "REQ", "RESP", "RESP_P", "RESP_PC", "RESP_PCD", "RESP_PCDS", "RESP_S")

                logger.error("清除mysql当天的gis_ass_adds_log_stat_ak_city的热门城市数据...")
                val sql_ak_city = "delete from ADDS_MAJOR where STAT_DATE = '" + runDate + "'"
                val statement_ak_city = connection.createStatement
                statement_ak_city.executeUpdate(sql_ak_city)

                logger.error("将当天的gis_ass_adds_log_stat_ak_city的热门城市数据存入mysql...")
                gis_ass_adds_log_stat_ak_city_dataframe.write.mode(SaveMode.Append).format("jdbc")
                  .option("url", "jdbc:mysql://10.119.72.209:3306") //10.202.43.235
                  .option("dbtable", "gis_oms_lip_addr.ADDS_MAJOR")
                  .option("user", "gis_oms_addr")
                  .option("password", "gis_oms_addr@123@")
                  .save()
              }

              flag2 = true
              break

            }
            catch {
              case ex: Exception => {
                logger.error("【推送到mysql时出错第" + i + "次】\nexception:\n" + ex.getCause + "\n")
                Thread.sleep(1000 * 60)
              }
            }
          }
        )

        if (!flag2) throw new Exception()


      }


    }
    logger.error("the end ...")

  }


}
