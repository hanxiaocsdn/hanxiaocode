package com.sf.gis.scala.seg.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.seg.util.{DbUtils, JavaUtil, MD5Util, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}


/**
 * 获取seg服务超时量数据，然后写入Mysql
 */
//noinspection DuplicatedCode
object SEGPerformanceMonitoringTimeOut {
  @transient lazy val logger: Logger = Logger.getLogger(SEGPerformanceMonitoringTimeOut.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    getSegTimeOut(spark,incDay)
    spark.close()
  }


  /**
   * 统计seg服务总性能指标，然后写入Mysql表
   * @param spark
   * @param parDay
   * configFile ： Mysql配置文件
   * descTableName ： Mysql目标表
   */
  def getSegTimeOut(spark:SparkSession,parDay:String)={
    println(parDay)
    val configFile = "addr.properties"
    val descTableName = "SEG_MONITORING_TIME_OUT"
    val calSql =
      s"""
         |SELECT
         |	 a.dates
         |	,a.serviceName
         |	,a.ak
         |	,(a.200MS + a.500MS  + a.1000MS + a.2000MS + a.3000MS + a.THAN_3000MS) AS total
         |	,a.200MS
         |	,a.500MS
         |  ,a.1000MS
         |	,a.2000MS
         |	,a.3000MS
         |	,a.THAN_3000MS
         |FROM
         |(
         |	SELECT
         |		 t.dates 														AS dates
         |		,t.name 														AS serviceName
         |		,'ALL'                                                          AS ak
         |		,sum(t.200MS) 											AS 200MS
         |		,sum(t.500MS) 											AS 500MS
         |		,sum(t.1000MS) 											AS 1000MS
         |		,sum(t.2000MS) 										AS 2000MS
         |		,sum(t.3000MS)                     					AS 3000MS
         |		,sum(t.THAN_3000MS) 												AS THAN_3000MS
         |	FROM
         |	(
         |		SELECT
         |			 a.dates AS dates
         |			,CASE WHEN a.ak='14e9ee810854c40f5ae9414f2a62c8cc' THEN 'segcx' ELSE 'seg' END 	AS name
         |			,CASE WHEN a.times >= 0 AND a.times < 200 THEN 1 ELSE 0 END 	AS 200MS
         |			,CASE WHEN a.times >= 200 AND a.times < 500 THEN 1 ELSE 0 END 	AS 500MS
         |			,CASE WHEN a.times >= 500 AND a.times < 1000 THEN 1 ELSE 0 END 	AS 1000MS
         |			,CASE WHEN a.times >= 1000 AND a.times < 2000 THEN 1 ELSE 0 END AS 2000MS
         |			,CASE WHEN a.times >= 2000 AND a.times < 3000 THEN 1 ELSE 0 END AS 3000MS
         |			,CASE WHEN a.times >= 3000 THEN 1 ELSE 0 END 					AS THAN_3000MS
         |		FROM
         |		(
         |			SELECT
         |				 dates
         |				,ak
         |				,CAST(times AS int) AS times
         |			FROM
         |			default.seg_monitoring_log_parse
         |			WHERE inc_day = '$parDay'
         |			and date_format(dates,'yyyyMMdd') = '$parDay'
         |			and types = 'url_e'
         |		) a
         |	) t
         |	GROUP BY
         |		 t.dates
         |		,t.name
         |) a
         |
         |UNION ALL
         |
         |SELECT
         |	 b.dates
         |	,b.serviceName
         |	,b.ak
         |	,(b.200MS + b.500MS  + b.1000MS + b.2000MS + b.3000MS + b.THAN_3000MS) AS total
         |	,b.200MS
         |	,b.500MS
         |  ,b.1000MS
         |	,b.2000MS
         |	,b.3000MS
         |	,b.THAN_3000MS
         |FROM
         |(
         |	SELECT
         |		t.dates 														AS dates
         |		,t.name 														AS serviceName
         |		,t.ak 															AS ak
         |		,sum(t.200MS) 											AS 200MS
         |		,sum(t.500MS) 											AS 500MS
         |		,sum(t.1000MS) 											AS 1000MS
         |		,sum(t.2000MS) 										AS 2000MS
         |		,sum(t.3000MS)                     					AS 3000MS
         |		,sum(t.THAN_3000MS) 												AS THAN_3000MS
         |	FROM
         |	(
         |		SELECT
         |			 a.dates AS dates
         |			,'seg' AS name
         |			,a.ak AS ak
         |			,CASE WHEN a.times >= 0 AND a.times < 200 THEN 1 ELSE 0 END 	AS 200MS
         |			,CASE WHEN a.times >= 200 AND a.times < 500 THEN 1 ELSE 0 END 	AS 500MS
         |			,CASE WHEN a.times >= 500 AND a.times < 1000 THEN 1 ELSE 0 END 	AS 1000MS
         |			,CASE WHEN a.times >= 1000 AND a.times < 2000 THEN 1 ELSE 0 END AS 2000MS
         |			,CASE WHEN a.times >= 2000 AND a.times < 3000 THEN 1 ELSE 0 END AS 3000MS
         |			,CASE WHEN a.times >= 3000 THEN 1 ELSE 0 END 					AS THAN_3000MS
         |		FROM
         |		(
         |			SELECT
         |				 dates
         |				,ak
         |				,CAST(times AS int) AS times
         |			FROM
         |			default.seg_monitoring_log_parse
         |			WHERE inc_day = '$parDay'
         |			and date_format(dates,'yyyyMMdd') = '$parDay'
         |			and types = 'url_e'
         |		) a
         |	) t
         |	GROUP BY
         |		t.dates
         |		,t.name
         |		,t.ak
         |) b
       """.stripMargin
    import spark.implicits._
    logger.error(">>>>>>>>>>>>>>>>>sql: " + calSql)
    val resultRDD = Util.getRowToJson(spark,calSql)
    resultRDD.take(5).foreach(println(_))
    logger.error(">>>>>>>>>>>>>>>>>将统计seg性能指标写入Mysql表")
    save2Mysql(resultRDD,configFile,descTableName,parDay)
    saveResult2Hive(spark,resultRDD,parDay)
    resultRDD.unpersist()
  }

  /**
   * 保存数据到MySQL
   * @param resultRDD
   * @param configFile
   * @param descTableName
   */
  def save2Mysql(resultRDD : RDD[JSONObject], configFile : String, descTableName : String,parDay : String) = {
    val javaUtil = new JavaUtil()
    javaUtil.setFlag(12)
    val conn = DbUtils.getConnection(javaUtil)
    val md5Instance = MD5Util.getMD5Instance
    try {
      logger.error(">>>>>>>>>开始插入数据库<<<<<<<<<<")
      val delSql = String.format(s"delete from $descTableName where stat_date='%s'", parDay)
      logger.error(">>>保存之前，删除当天的数据:" + delSql)
      DbUtils.executeSql(conn, delSql)
      val insertSql = s"insert into $descTableName (`ID`,`STAT_DATE`,`STAT_DATETIME`,`SERVICE_NAME`,`AK`,`REQ_TOTAL`" +
        s",`MS200`,`MS500`,`MS1000`,`MS2000`,`MS3000`,`THAN_3000MS`) values(?,?,?,?,?,?,?,?,?,?,?,?)"
      logger.error(">>>>>>>>>insertSql<<<<<<<<<<: "+insertSql)
      var insertParams: Array[Any] = null
      resultRDD.collect().foreach(row => {
        val id = MD5Util.getMD5(md5Instance,Array(parDay,row.getString("serviceName"),JSONUtil.getJsonVal(row,"ak","")).mkString("_"))
        insertParams = Array(id,parDay,"NULL",row.getString("serviceName"),JSONUtil.getJsonVal(row,"ak","")
          ,row.getString("total"),row.getString("200MS"),row.getString("500MS"),row.getString("1000MS")
          ,row.getString("2000MS"),row.getString("3000MS"),row.getString("THAN_3000MS"))
        DbUtils.execute(conn,insertSql,insertParams)
      })
      logger.error(s">>>>>>>>>>>指标入库量: ${resultRDD.count()}<<<<<<<<<<<<<")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }


  /**
   *
   * @param spark
   * @param
   */
  def saveResult2Hive(spark : SparkSession,resultRDD : RDD[JSONObject],parDay : String): Unit ={
    //目标库表名称
    val descDBName = "default"
    val descTableName = "seg_monitoring_index_time_out"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay')
         |SELECT
         | *
         |FROM seg_monitoring_index_time_out_temp
         |""".stripMargin
    try{
      val schemaString = "stat_date,stat_datetime,service_name,ak,total,ms200,ms500,ms1000,ms2000,ms3000,than_3000ms"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = resultRDD.map(obj => {
        val sb = new StringBuilder()
        sb.append(parDay).append("\t\t\t")
        sb.append("NULL").append("\t\t\t")
        sb.append(obj.getString("serviceName")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"ak","")).append("\t\t\t")
        sb.append(obj.getString("total")).append("\t\t\t")
        sb.append(obj.getString("200MS")).append("\t\t\t")
        sb.append(obj.getString("500MS")).append("\t\t\t")
        sb.append(obj.getString("1000MS")).append("\t\t\t")
        sb.append(obj.getString("2000MS")).append("\t\t\t")
        sb.append(obj.getString("3000MS")).append("\t\t\t")
        sb.append(obj.getString("THAN_3000MS")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
        ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("seg_monitoring_index_time_out_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  case class Message(types : String,date_time : String,dates : String,ak : String,times : Int)

}
