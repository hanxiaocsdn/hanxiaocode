package com.sf.gis.scala.seg.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import com.sf.gis.scala.seg.util.SfNetIntefaceSeg
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * @Description:地址识别客诉自动化处理
 * 需求人员：01324490 金姣
 * @Author: lixiangzhi 01405644
 * @Date:
 * 任务id:781624
 * 任务名称：地址识别客诉自动化处理
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object AddressRecognizeCustomerComplaintNew {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readCustomerComplaint(spark: SparkSession, incDay: String) = {
    val customerComplaintSql=
      s"""
        |select * from dm_gis.ft_customer_complaint_mi where inc_day='$incDay'
        |""".stripMargin
    logger.error(customerComplaintSql)
    val customerComplaintRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, customerComplaintSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("客诉数据量:"+customerComplaintRdd.count())
    val sendDayRdd: RDD[String] = customerComplaintRdd.map(obj => {
      val send_time: String = JSONUtil.getJsonValSingle(obj, "send_time")
      var send_day:String =""
      if (send_time.length==19 || send_time.length==10){
        send_day = send_time.substring(0, 10).replace("-", "")
      }
      send_day
    }).filter(str=>{
      StringUtils.isNoneEmpty(str)
    })
    val endDay: String = sendDayRdd.max()
    val startDay: String = sendDayRdd.min()
    logger.error("寄件时间最大值为"+endDay+",最小值为"+startDay)
    (customerComplaintRdd,startDay,endDay)
  }

  def joinOtherTable(spark: SparkSession, customerComplaintRdd: RDD[JSONObject], incDay: String,startDay:String,endDay:String) = {
    var filter_day = startDay
    while (filter_day<=endDay){
      val filterDayRdd: RDD[((String, String), JSONObject)] = customerComplaintRdd.map(obj => {
        val send_time: String = JSONUtil.getJsonValSingle(obj, "send_time")
        var send_day: String = ""
        if (send_time.length == 19) {
          send_day = send_time.substring(0, 10).replace("-", "")
        }
        ((obj.getString("waybill_no"), send_day), obj)
      }).filter(_._1._2 == filter_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
      if (filterDayRdd.count()!=0){
        //获取tt_waybill_info表
        val joinSql=
          s"""
            |select
            |t1.waybill_no,send_time,
            |order_id,
            |order_no as orderno,
            |ak,src,province_req,city_req,county_req,address,opt,province,city,county,town,detailaddr,addresssuffix,tip_province,tip_city,tip_county,tip_town,result,
            |src_sys_type,src_sys_name,src_subsys_code
            |from
            |(
            |	select
            |	waybill_no,send_time
            |	from dm_gis.ft_customer_complaint_mi
            |	where inc_day='$incDay'
            |	and regexp_replace(substr(send_time,0,10),'-','')='$filter_day'
            |) t1
            |left join
            |(
            |	select waybill_no,order_id,order_no
            |	from dm_gis.tt_waybill_info
            |	where inc_day='$filter_day'
            | group by waybill_no,order_id,order_no
            |) t2
            |on t1.waybill_no=t2.waybill_no
            |left join
            |(
            |	select inner_order_no,src_sys_type,src_sys_name,src_subsys_code
            |	from dwd.dwd_order_info_di
            |	where inc_day='$filter_day'
            | group by inner_order_no,src_sys_type,src_sys_name,src_subsys_code
            |) t3
            |on t2.order_no=t3.inner_order_no
            |left join
            |(
            |	select orderno,ak,src,province_req,city_req,county_req,address,opt,province,city,county,town,detailaddr,addresssuffix,tip_province,tip_city,tip_county,tip_town,result,inc_day
            |	from dm_gis.gis_ass_adds_log_parse
            |	where inc_day='$filter_day'
            |) t4
            |on t2.order_id=t4.orderno
            |""".stripMargin
        logger.error(joinSql)
        val joinWaybillInfoDf: DataFrame = spark.sql(joinSql)
        joinWaybillInfoDf.repartition(2).createOrReplaceTempView("joinWaybillInfoTmp")
        spark.sql(s"insert into table dm_gis.dm_customer_complaint_join_other_mi partition(inc_day='$incDay') select * from joinWaybillInfoTmp")
      }
      logger.error("dm_customer_complaint_join_other_mi分区"+filter_day+"写入完成")
      filter_day = DateUtil.getDateStr(filter_day, 1, "")
    }
    val nullSendTimeSql=
      s"""
        |insert into table dm_gis.dm_customer_complaint_join_other_mi partition(inc_day='$incDay')
        |select
        |waybill_no,send_time,
        |'' as ak,
        |'' as src,
        |'' as province_req,
        |'' as city_req,
        |'' as county_req,
        |'' as address,
        |'' as opt,
        |'' as province,
        |'' as city,
        |'' as county,
        |'' as town,
        |'' as detailaddr,
        |'' as addresssuffix,
        |'' as tip_province,
        |'' as tip_city,
        |'' as tip_county,
        |'' as tip_town,
        |'' as result,
        |'' as src_sys_type,
        |'' as src_sys_name,
        |'' as src_subsys_code
        |from dm_gis.ft_customer_complaint_mi
        |where inc_day='$incDay'
        |and (send_time='' or send_time is null)
        |""".stripMargin
    spark.sql(nullSendTimeSql)
  }

  def processInterface(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    val joinOtherSql=
      s"""
        |select * from dm_gis.dm_customer_complaint_join_other_new_mi where inc_day='$incDay'
        |--and waybill_no='SF1445578468629'
        |""".stripMargin
    val joinOtherRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, joinOtherSql).distinct()
    val addTagRdd: RDD[JSONObject] = joinOtherRdd.map(obj => {
      val ak: String = JSONUtil.getJsonValSingle(obj, "ak")
      val send_time: String = JSONUtil.getJsonValSingle(obj, "send_time")
      var tag1 = ""
      var tag2 = ""
      if (send_time==""){
        tag1 = "寄件时间为空"
        tag2 = "需查看投诉内容"
      }else{
        if (ak == "") {
          tag1 = "没有调用seg"
          tag2 = "不需要加白名单"
        }else if(ak=="14e9ee810854c40f5ae9414f2a62c8cc"){
          val result: String = obj.getString("result")
          if (result == "1") {
            tag1 = "seg识别没问题"
            tag2 = "不需要加白名单"
          }
        }
      }

      obj.put("tag1",tag1)
      obj.put("tag2",tag2)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val notNullTag1Rdd: RDD[JSONObject] = addTagRdd.filter(_.getString("tag1") != "")
    val nullTag1Rdd: RDD[JSONObject] = addTagRdd.filter(_.getString("tag1") == "").map(obj=>{
      val province_req: String = obj.getString("province_req")
      val city_req: String = obj.getString("city_req")
      val county_req: String = obj.getString("county_req")
      val address: String = obj.getString("address")
      val address_req = province_req+city_req+county_req+address
      obj.put("address_req",address_req)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调seg服务接口数据量:"+nullTag1Rdd.count())
    val nullTag1Cnt: Long = nullTag1Rdd.count()
    val httpSegService = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "781624", "地址识别客诉自动化处理new", "获取地址分词结果", "http://gis-int.int.sfdc.com.cn:1080/seg/api/split?ak=%s&opt=cx1&address=%s", "b4baa4d569bc416ab0f66dc2017c108c", nullTag1Cnt, 1)
    val returnSegRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,nullTag1Rdd, SfNetIntefaceSeg.segServiceInterface, 1, "b4baa4d569bc416ab0f66dc2017c108c", 2000)
    val segRdd: RDD[JSONObject] = returnSegRdd.repartition(600).map(obj => {
      val resultObj: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val src_seg: String = resultObj.getString("src")
      val result_seg: String = resultObj.getString("result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(resultObj, "data")
      val province_seg: String = data.getString("province")
      val city_seg: String = data.getString("city")
      val county_seg: String = data.getString("county")
      val town_seg: String = data.getString("town")
      val tip_province_seg: String = data.getString("tipProvince")
      val tip_city_seg: String = data.getString("tipCity")
      val tip_county_seg: String = data.getString("tipCounty")
      val tip_town_seg: String = data.getString("tipTown")
      val detailaddr_seg: String = data.getString("detailaddr")
      val address_suffix_seg: String = data.getString("addressSuffix")
      obj.put("src_seg", src_seg)
      obj.put("result_seg", result_seg)
      obj.put("province_seg", province_seg)
      obj.put("city_seg", city_seg)
      obj.put("county_seg", county_seg)
      obj.put("town_seg", town_seg)
      obj.put("tip_province_seg", tip_province_seg)
      obj.put("tip_city_seg", tip_city_seg)
      obj.put("tip_county_seg", tip_county_seg)
      obj.put("tip_town_seg", tip_town_seg)
      obj.put("detailaddr_seg", detailaddr_seg)
      obj.put("address_suffix_seg", address_suffix_seg)
      obj.remove("api_result")
      var tag1: String = obj.getString("tag1")
      var tag2: String = obj.getString("tag2")
      val ak: String = JSONUtil.getJsonValSingle(obj, "ak")
      if (result_seg == "1") {
        if (src_seg == "white") {
          tag1 = "seg识别问题"
          tag2 = "已存在白名单"
        } else {
          if (ak=="14761f7edeef49bbb6451a3b8c546b47"){
            tag1="seg识别没问题"
            tag2="不需要加白名单"
          }else{
            tag1 = "seg识别问题"
            tag2 = "服务已修复"
          }
        }
      }
      obj.put("tag1", tag1)
      obj.put("tag2", tag2)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val resultEqual1Rdd: RDD[JSONObject] = segRdd.filter(_.getString("tag1") != "")
    val resultUnEqual1Rdd: RDD[JSONObject] = segRdd.filter(_.getString("tag1") == "").persist(StorageLevel.MEMORY_AND_DISK_SER)
    resultUnEqual1Rdd.take(10).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpSegService)
    logger.error("调ts坐标接口数据量:"+resultUnEqual1Rdd.count())
    val httpGeoTsGis = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "781624", "地址识别客诉自动化处理new", "获取地址坐标", "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=ts&address=%s", "b4baa4d569bc416ab0f66dc2017c108c", resultUnEqual1Rdd.count(), 1)
    val returnTsRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,resultUnEqual1Rdd, SfNetIntefaceSeg.geoTsGisInterface, 1, "b4baa4d569bc416ab0f66dc2017c108c", 2000)
    val tsRdd: RDD[JSONObject] = returnTsRdd.repartition(600).map(obj => {
      val resultObj: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val match_level: Int = resultObj.getIntValue("match_level")
      val xcoord: String = resultObj.getString("xcoord")
      val ycoord: String = resultObj.getString("ycoord")
      obj.put("match_level", match_level)
      obj.put("xcoord", xcoord)
      obj.put("ycoord", ycoord)
      obj.remove("api_result")
      var tag1: String = obj.getString("tag1")
      var tag2: String = obj.getString("tag2")
      if (!(match_level >= 5 || match_level == -1)) {
        tag1 = "seg识别问题"
        tag2 = "无法定位需人工添加白名单"
      }
      obj.put("tag1", tag1)
      obj.put("tag2", tag2)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val notNullMatchLevelRdd: RDD[JSONObject] = tsRdd.filter(_.getString("tag1") != "")
    val nullMatchLevelRdd: RDD[JSONObject] = tsRdd.filter(_.getString("tag1") == "").persist(StorageLevel.MEMORY_AND_DISK_SER)
    nullMatchLevelRdd.take(10).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpGeoTsGis)
    logger.error("调坐标查询行政区划接口数据量:"+nullMatchLevelRdd.count())
    val httpQueryBatchAdcode = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "781624", "地址识别客诉自动化处理new", "获取adcode信息", "http://gis-int.int.sfdc.com.cn:1080/adcode/api/querybatchadcode?opt=GetBatchAdcode&cc=1&xy=%s&ak=%s", "b4baa4d569bc416ab0f66dc2017c108c", nullMatchLevelRdd.count(), 1)
    val returnQueryBatchAdcodeRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,nullMatchLevelRdd, SfNetIntefaceSeg.queryBatchAdcodeInterface, 1, "b4baa4d569bc416ab0f66dc2017c108c", 2000)
    val queryBatchAdcodeRdd: RDD[JSONObject] = returnQueryBatchAdcodeRdd.repartition(600).map(obj => {
      val resultObj: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val data: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(resultObj, "data")
      val province_f: String = data.getString("province")
      val city_f: String = data.getString("city")
      val county_f: String = data.getString("county")
      val town_f: String = data.getString("town")
      val adcode_f: String = data.getString("adcode")
      val citycode_f: String = data.getString("citycode")
      val funcADCode: String = data.getString("funcADCode")
      val funcAreaCode: String = data.getString("funcAreaCode")
      val funcCountyName: String = data.getString("funcCountyName")
      val funcTownName: String = data.getString("funcTownName")
      obj.put("province_f", province_f)
      obj.put("city_f", city_f)
      obj.put("county_f", county_f)
      obj.put("town_f", town_f)
      obj.put("adcode_f", adcode_f)
      obj.put("citycode_f", citycode_f)
      obj.put("funcADCode", funcADCode)
      obj.put("funcAreaCode", funcAreaCode)
      obj.put("funcCountyName", funcCountyName)
      obj.put("funcTownName", funcTownName)
      val tip_province: String = obj.getString("tip_province_seg")
      val tip_city: String = obj.getString("tip_city_seg")
      val tip_county: String = obj.getString("tip_county_seg")
      val tip_town: String = obj.getString("tip_town_seg")
      obj.remove("api_result")
      var tag1: String = obj.getString("tag1")
      var tag2: String = obj.getString("tag2")
      if (!((province_f == tip_province && city_f == tip_city && county_f == tip_county)
        || (province_f == tip_province && city_f == tip_city && funcCountyName == tip_county))) {
        tag1 = "seg识别问题"
        tag2 = "定位不一致需人工添加白名单"
      }else if(province_f == tip_province && city_f == tip_city && county_f == tip_county){
        val addWhiteTag="1"
        obj.put("addWhiteTag",addWhiteTag)
      }else if(province_f == tip_province && city_f == tip_city && funcCountyName == tip_county){
        val addWhiteTag="2"
        obj.put("addWhiteTag",addWhiteTag)
      }
      obj.put("tag1", tag1)
      obj.put("tag2", tag2)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val notNullQueryBatchAdcodeRdd: RDD[JSONObject] = queryBatchAdcodeRdd.filter(_.getString("tag1") != "")
    val nullQueryBatchAdcodeRdd: RDD[JSONObject] = queryBatchAdcodeRdd.filter(_.getString("tag1") == "").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调添加白名单接口数据量:"+nullQueryBatchAdcodeRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpQueryBatchAdcode)
    val httpAddWhite = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "781624", "地址识别客诉自动化处理new", "添加地址进入白名单数据库", "http://gis-int.int.sfdc.com.cn:1080/seg/api/white/add?address=%s&province=%s&city=%s&county=%s&town=%s&detailinfo=%s&adcode=%s&citycode=%s&addresssuffix=%s&x=%s&y=%s&ak=%s", "b4baa4d569bc416ab0f66dc2017c108c", nullQueryBatchAdcodeRdd.count(), 1)
    val returnAddWhiteRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,nullQueryBatchAdcodeRdd, SfNetIntefaceSeg.addWhiteInterface, 1, "b4baa4d569bc416ab0f66dc2017c108c", 2000)
    val addWhiteRdd: RDD[JSONObject] = returnAddWhiteRdd.repartition(600).map(obj => {
      val resultObj: JSONObject = JSONUtil.getJsonObjectMulti(obj, "api_result.result")
      val msg: String = resultObj.getString("msg")
      obj.put("msg",msg)
      obj.remove("api_result")
      var tag1: String = obj.getString("tag1")
      var tag2: String = obj.getString("tag2")
      if (msg == "添加地址白名单成功") {
        tag1 = "seg识别问题"
        tag2 = "已自动添加白名单"
      }else{
        tag1 = "seg识别问题"
        tag2 = "添加白名单失败"
      }
      obj.put("tag1", tag1)
      obj.put("tag2", tag2)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val resultRdd: RDD[JSONObject] = addWhiteRdd
      .union(notNullTag1Rdd)
      .union(resultEqual1Rdd)
      .union(notNullMatchLevelRdd)
      .union(notNullQueryBatchAdcodeRdd)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("结果表数据量:"+resultRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpAddWhite)
    val resultDf: DataFrame = resultRdd.map(obj => {
      CustomerComplaint(
        obj.getString("waybill_no"),
        obj.getString("send_time"),
        obj.getString("order_id"),
        obj.getString("src_sys_type"),
        obj.getString("src_sys_name"),
        obj.getString("src_subsys_code"),
        obj.getString("ak"),
        obj.getString("orderno"),
        obj.getString("src"),
        obj.getString("province_req"),
        obj.getString("city_req"),
        obj.getString("county_req"),
        obj.getString("address"),
        obj.getString("opt"),
        obj.getString("province"),
        obj.getString("city"),
        obj.getString("county"),
        obj.getString("town"),
        obj.getString("detailaddr"),
        obj.getString("addresssuffix"),
        obj.getString("tip_province"),
        obj.getString("tip_city"),
        obj.getString("tip_county"),
        obj.getString("tip_town"),
        obj.getString("province_f"),
        obj.getString("city_f"),
        obj.getString("county_f"),
        obj.getString("town_f"),
        obj.getString("adcode_f"),
        obj.getString("citycode_f"),
        obj.getString("funcADCode"),
        obj.getString("funcAreaCode"),
        obj.getString("funcCountyName"),
        obj.getString("funcTownName"),
        obj.getString("src_seg"),
        obj.getString("result_seg"),
        obj.getString("match_level"),
        obj.getString("xcoord"),
        obj.getString("ycoord"),
        obj.getString("addWhiteTag"),
        obj.getString("msg"),
        obj.getString("tag1"),
        obj.getString("tag2"),
        obj.getString("province_seg"),
        obj.getString("city_seg"),
        obj.getString("county_seg"),
        obj.getString("town_seg"),
        obj.getString("tip_province_seg"),
        obj.getString("tip_city_seg"),
        obj.getString("tip_county_seg"),
        obj.getString("tip_town_seg"),
        obj.getString("detailaddr_seg"),
        obj.getString("address_suffix_seg")
      )
    }).toDF()
    resultDf.repartition(1).createOrReplaceTempView("resultTmp")
    spark.sql(s"insert overwrite table dm_gis.dm_address_recognize_customer_complaint_mi partition(inc_day='$incDay') select * from resultTmp")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取客户投诉表
    //val (customerComplaintRdd,startDay,endDay) = readCustomerComplaint(spark, incDay)
    //关联tt_waybill_info、gis_ass_adds_log_parse、dwd_order_info_di
    //joinOtherTable(spark,customerComplaintRdd,incDay,startDay,endDay)
    //调接口
    processInterface(spark,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
  case class CustomerComplaint(
                                waybill_no:String,
                                send_time:String,
                                order_id:String,
                                src_sys_type:String,
                                src_sys_name:String,
                                src_subsys_code:String,
                                ak:String,
                                orderno:String,
                                src:String,
                                province_req:String,
                                city_req:String,
                                county_req:String,
                                address:String,
                                opt:String,
                                province:String,
                                city:String,
                                county:String,
                                town:String,
                                detailaddr:String,
                                addresssuffix:String,
                                tip_province:String,
                                tip_city:String,
                                tip_county:String,
                                tip_town:String,
                                province_f:String,
                                city_f:String,
                                county_f:String,
                                town_f:String,
                                adcode_f:String,
                                citycode_f:String,
                                funcADCode:String,
                                funcAreaCode:String,
                                funcCountyName:String,
                                funcTownName:String,
                                src_seg:String,
                                result_seg:String,
                                match_level:String,
                                xcoord:String,
                                ycoord:String,
                                addWhiteTag:String,
                                msg:String,
                                tag1:String,
                                tag2:String,
                                province_seg:String,
                                city_seg:String,
                                county_seg:String,
                                town_seg:String,
                                tip_province_seg:String,
                                tip_city_seg:String,
                                tip_county_seg:String,
                                tip_town_seg:String,
                                detailaddr_seg:String,
                                address_suffix_seg:String
                              )
}
