package com.sf.gis.scala.seg.util

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util
import java.util.{Calendar, Date}

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.constant.InfConstant
import com.sf.gis.java.base.util.{HttpConnection, HttpInvokeUtil}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.httpclient.HttpStatus
import org.apache.commons.lang3.StringUtils
import org.apache.http.client.methods.HttpGet
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.log4j.Logger

/**
 * Created by 01374443 on 2021/4/2.
 */
object SfNetIntefaceSeg {

  //审补地址下线
  val delUrl ="http://gis-cms-bg.sf-express.com/cms/api/address/deleteRgsbAddr"
  //审补入cms库
  val cmsUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd"

  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
   * 添加白名单接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def addWhiteInterface(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/seg/api/white/add?address=%s&province=%s&city=%s&county=%s&town=%s&detailinfo=%s&adcode=%s&citycode=%s&addresssuffix=%s&x=%s&y=%s&ak=%s"
    try {

      val address = JSONUtil.getJsonValSingle(obj,"address_req")
      val province = JSONUtil.getJsonValSingle(obj,"province_f")
      val city = JSONUtil.getJsonValSingle(obj,"city_f")
      var town = JSONUtil.getJsonValSingle(obj,"town_f")
      var county = JSONUtil.getJsonValSingle(obj,"county_f")
      val detailinfo = JSONUtil.getJsonValSingle(obj,"detailaddr_seg")
      val adcode = JSONUtil.getJsonValSingle(obj,"adcode_f")
      val citycode = JSONUtil.getJsonValSingle(obj,"citycode_f")
      val addresssuffix = JSONUtil.getJsonValSingle(obj,"address_suffix_seg")
      val x = JSONUtil.getJsonValSingle(obj,"xcoord")
      val y = JSONUtil.getJsonValSingle(obj,"ycoord")

      val addWhiteTag = JSONUtil.getJsonValSingle(obj,"addWhiteTag")
      if (addWhiteTag=="2"){
        county = JSONUtil.getJsonValSingle(obj,"funcCountyName")
        town = JSONUtil.getJsonValSingle(obj,"funcTownName")
      }
      if(StringUtils.isBlank(address) || StringUtils.isBlank(province)
        || StringUtils.isBlank(city) || StringUtils.isBlank(county)
        || StringUtils.isBlank(town) || StringUtils.isBlank(detailinfo)
        || StringUtils.isBlank(adcode) || StringUtils.isBlank(citycode)
        || StringUtils.isBlank(addresssuffix) || StringUtils.isBlank(x)
        || StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl = url.format(
        URLEncoder.encode(address,"utf-8"),
        URLEncoder.encode(province,"utf-8"),
        URLEncoder.encode(city,"utf-8"),
        URLEncoder.encode(county,"utf-8"),
        URLEncoder.encode(town,"utf-8"),
        URLEncoder.encode(detailinfo,"utf-8"),
        adcode,citycode,
        URLEncoder.encode(addresssuffix,"utf-8"),
        x,y,ak)
      logger.error("finalUrl:"+finalUrl)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 坐标查询行政区划接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def queryBatchAdcodeInterface(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/adcode/api/querybatchadcode?opt=GetBatchAdcode&cc=1&xy=%s&ak=%s"
    try {
      val xcoord = JSONUtil.getJsonValSingle(obj,"xcoord")
      val ycoord = JSONUtil.getJsonValSingle(obj,"ycoord")
      val xy = xcoord+","+ycoord
      if(StringUtils.isBlank(xcoord) || StringUtils.isBlank(ycoord)){
        return obj
      }
      val finalUrl = url.format(xy,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }

  /**
   * 跑ts坐标接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def geoTsGisInterface(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=ts&address=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address_req")

      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"))
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }

  /**
   * 跑seg服务接口
   * @param obj  传入的json对象

   * @return
   */
  def segServiceInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/seg/api/split?ak=%s&opt=cx1&address=%s"
    try {
      val address = obj.getString("address_req")
      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl: String = url.format(ak,URLEncoder.encode(address,"utf-8"))
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      //Thread.sleep(5000)
      logger.error("finalUrl:"+finalUrl)
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }

  /**
   * 跑公司分词接口
   * @param obj  传入的json对象

   * @return
   */
  def companySplitInterface(obj:JSONObject): JSONObject= {
    val url="http://10.119.82.211:5025/api/seg"
    try {
      //logger.error("aoi_id:"+aoi_id)
      val text: String = obj.getString("owner_name")
      if(StringUtils.isBlank(text)){
        return obj
      }
      val tmpObj = new JSONObject()
      tmpObj.put("text",text)
      tmpObj.put("base","")

      val retStr: String = HttpInvokeUtil.sendPost(url,tmpObj.toString)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("url",url)
      logger.error("ret:"+ret)
      logger.error("text:"+text)
      logger.error("url:"+url)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑电话加密接口
   * @param obj  传入的json对象

   * @return
   */
  def encryptPhoneInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/tals/tals/normalized?ak=%s&tel=%s&cityCode="
    try {
      val tel = obj.getString("phone_part")
      if(StringUtils.isBlank(tel)){
        return obj
      }
      val finalUrl: String = url.format(ak,tel)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      logger.error("ret:"+ret)
      //Thread.sleep(5000)
      logger.error("finalUrl:"+finalUrl)
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑aoiCircle接口
   * @param obj  传入的json对象

   * @return
   */
  def aoiPolygonInterface(obj:JSONObject): JSONObject= {
    val url="http://sds-core-datarun.sf-express.com/datarun/aoi/getWktAoi"
    try {
      //logger.error("aoi_id:"+aoi_id)
      val polygon: String = obj.getString("polygon")
      if(StringUtils.isBlank(polygon)){
        return obj
      }
      val tmpObj = new JSONObject()
      tmpObj.put("wkt",polygon)

      val retStr: String = HttpInvokeUtil.sendPost(url,tmpObj.toString)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("url",url)
      //logger.error("ret:"+ret)
      //logger.error("polygon:"+polygon)
      //logger.error("url:"+url)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * aoi点落面接口
   * @param obj  传入的json对象

   * @return
   */
  def aoiAreaInterface(obj:JSONObject): JSONObject = {
    val url="http://sds-core-datarun.sf-express.com/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=0.1"
    try {
      val x = obj.getString("x")
      val y = obj.getString("y")
      if(StringUtils.isBlank(x) || StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl: String = url.format(x,y)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      val code: Int = ret.getInteger("code")
      if(code==200){
        logger.error("调接口成功,code="+code)
      }else{
        logger.error("调接口失败,code="+code)
      }
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 高德地址接口
   * @param obj  传入的json对象
   * @return
   */
  def gdAddresssInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-gw.int.sfdc.com.cn:9080/transform/gd/queryPoi?keywords=%s&city="
    try {
      val owner_name: String = obj.getString("owner_name")
      if(StringUtils.isBlank(owner_name)){
        return obj
      }
      val finalUrl: String = url.format(URLEncoder.encode(owner_name,"utf-8"))
      val ret: String = HttpInvokeUtil.sendGet(finalUrl,"ak",ak,3)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",JSON.parseObject(ret))
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 两个aoicode间隔距离
   * @param obj  传入的json对象
   * @return
   */
  def aoicodeDistanceInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-apis.int.sfcloud.local:1080/dept2/routeplan/aoi?city_code1=%s&aoi_code1=%s&aoi_code2=%s&city_code2=%s&ak=%s"
    try {
      val city_code1: String = obj.getString("citycode")
      val city_code2: String = obj.getString("citycode2")
      val aoi_code1: String = obj.getString("aoicode")
      val aoi_code2: String = obj.getString("aoicode2")
      if(StringUtils.isBlank(city_code1) || StringUtils.isBlank(city_code2) || StringUtils.isBlank(aoi_code1) || StringUtils.isBlank(aoi_code2)){
        return obj
      }
      val finalUrl: String = url.format(city_code1,aoi_code1,aoi_code2,city_code2)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 地址获取aoi坐标
   * @param obj  传入的json对象
   * @return
   */
  def addressGeocoderInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=&city=&address=%s"
    try {
      val address: String = obj.getString("reg_location")
      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl: String = url.format(ak,URLEncoder.encode(address,"utf-8"))
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 地址获取aoi信息和坐标
   * @param obj  传入的json对象
   * @return
   */
  def addressAoiInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=zh&showserver=true"
    try {
      val address: String = obj.getString("reg_location")
      val citycode: String = obj.getString("citycode")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(citycode)){
        return obj
      }
      val finalUrl: String = url.format(URLEncoder.encode(address,"utf-8"),citycode,ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑传统规划接口1
   * @param obj  传入的json对象

   * @return
   */
  def normalPlanInterfaceStation(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s&type=0&cc=1&strategy=0&opt=sf2&passport=100000&tolls=1&test=0&stype=0&etype=0&pathCount=1&rarefy=0&fencedist=50&merge=4&fixedroute=2"
    try {
      val belong_x: String = obj.getString("belong_x")
      val belong_y: String = obj.getString("belong_y")
      val lng: String = obj.getString("lng")
      val lat: String = obj.getString("lat")
      val roadClass: String = obj.getString("roadClass")
      //logger.error("aoi_id:"+aoi_id)
      if(StringUtils.isBlank(belong_x) || StringUtils.isBlank(belong_y) || StringUtils.isBlank(lng) || StringUtils.isBlank(lat)){
        return obj
      }
      val finalUrl: String = url.format(belong_x,belong_y,lng,lat,ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  def slaInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://kong.int.sfcloud.local/prilog/v1/AccessMonitor/dataGridBySysCodeAndModuleNameAndUrl?sysCode=%s&moduleName=%s&urlRegrex=%s&startTimestamp=%s&endTimestamp=%s&env=%s"
    val apikey = ak
    val user_account = "01421359"
    val env = "ALL"
    val moduleName = ""
    try {
      val sysCode = obj.getString("sys_code")
      val urlRegrex = obj.getString("api")
      val startTimestamp = obj.getString("startTimestamp")
      val endTimestamp = obj.getString("endTimestamp")
      val finalUrl: String = url.format(sysCode, moduleName, urlRegrex, startTimestamp, endTimestamp, env)
      var count = 3
      var ret = new JSONObject()
      while ( {
        {
          count -= 1; count + 1
        } > 0
      }) {
        val httpGet = new HttpGet(finalUrl)
        httpGet.addHeader("apikey", apikey)
        httpGet.addHeader("user-account", user_account)
        try {
          val httpClient = HttpClients.custom.build
          val response = httpClient.execute(httpGet)
          try if (response.getStatusLine.getStatusCode == HttpStatus.SC_OK) {
            val result = EntityUtils.toString(response.getEntity, "utf-8")
            ret = JSON.parseObject(result)
            obj.put("atpRet",ret)
            obj.put("finalUrl",finalUrl)
          }
          catch {
            case e: Exception =>logger.error(e)
          } finally {
            httpGet.releaseConnection()
            if (httpClient != null) httpClient.close()
            if (response != null) response.close()
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atpRet",tmp)
    }
    obj
  }
  /**
   * 跑传统规划接口
   * @param obj  传入的json对象

   * @return
   */
  def swidInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/qRoad?ak=%s&x1=%s&y1=%s&x2=%s&y2=%s&toll=0&inner=0&furniture=0&fw2=0&poi=0&exprIndex=-1&mask=35&gzip=0&output=json&roadAttrToken=6134FAA5B6B6ED55E87EA116466734ED"
    try {
      val x1: String = obj.getString("minlng")
      val y1: String = obj.getString("minlat")
      val x2: String = obj.getString("maxlng")
      val y2: String = obj.getString("maxlat")
      //logger.error("aoi_id:"+aoi_id)
      if(StringUtils.isBlank(x1) || StringUtils.isBlank(y1) || StringUtils.isBlank(x2) || StringUtils.isBlank(y2)){
        return obj
      }
      val finalUrl: String = url.format(ak,x1,y1,x2,y2)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }

  /**
   * 集散圈接口
   * @param obj  传入的json对象

   * @return
   */
  def stationClusterInterface(obj:JSONObject): JSONObject = {
    val url="http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/StationClusterRect?"
    try {
      //logger.error("aoi_id:"+aoi_id)
      val stationsStr: String = obj.toJSONString
      if(StringUtils.isBlank(stationsStr)){
        return obj
      }
      val retStr: String = HttpInvokeUtil.sendPost(url,stationsStr)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("stationsStr",stationsStr)
      //logger.error("ret:"+ret)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑传统规划接口
   * @param obj  传入的json对象

   * @return
   */
  def normalPlanInterface2(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s&type=0&cc=1&strategy=0&opt=sf2&passport=100000&tolls=1&test=0&stype=0&etype=0&pathCount=1&rarefy=0&fencedist=50&merge=4&fixedroute=2"
    try {
      val belong_x: String = obj.getString("x1")
      val belong_y: String = obj.getString("y1")
      val lng: String = obj.getString("x2")
      val lat: String = obj.getString("y2")
      val roadClass: String = obj.getString("roadClass")
      //logger.error("aoi_id:"+aoi_id)
      if(StringUtils.isBlank(belong_x) || StringUtils.isBlank(belong_y) || StringUtils.isBlank(lng) || StringUtils.isBlank(lat)){
        return obj
      }
      val finalUrl: String = url.format(belong_x,belong_y,lng,lat,ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑传统规划接口
   * @param obj  传入的json对象

   * @return
   */
  def normalPlanInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&merge=3&opt=sf3&vehicle=6&ak=%s"
    try {
      val belong_x: String = obj.getString("belong_x")
      val belong_y: String = obj.getString("belong_y")
      val lng: String = obj.getString("lng")
      val lat: String = obj.getString("lat")
      //logger.error("aoi_id:"+aoi_id)
      if(StringUtils.isBlank(belong_x) || StringUtils.isBlank(belong_y) || StringUtils.isBlank(lng) || StringUtils.isBlank(lat)){
        return obj
      }
      val finalUrl: String = url.format(belong_x,belong_y,lng,lat,ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      val result: JSONObject = JSONUtil.getJsonObjectMulti(ret, "result")
      val d_dist: Double = JSONUtil.getJsonDouble(result, "dist",Int.MaxValue)
      obj.put("d_dist",d_dist)
      //obj.put("finalUrl",finalUrl)
      /*if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }*/
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑geoPoi接口
   * @param obj  传入的json对象
   * @return
   */
  def geoPoiInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s"
    try {
      val x: String = obj.getString("agr_lng")
      val y: String = obj.getString("agr_lat")
      //logger.error("aoi_id:"+aoi_id)
      if(StringUtils.isBlank(x) || StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl: String = url.format(x,y,ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      obj.put("finalUrl",finalUrl)
      if (ret!=null){
        obj.put("api_result",ret)
      }else{
        obj.put("api_result","接口异常返回为null")
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }

  /**
   * 跑aoiCircle接口
   * @param obj  传入的json对象

   * @return
   */
  def aoiCircleInterface(obj:JSONObject): JSONObject = {
    val url="http://sds-core-datarun.sf-express.com/datarun/aoi/getCircleAoiBase?x=%s&y=%s&radius=500"
    try {
      val x = obj.getString("agr_lng")
      val y = obj.getString("agr_lat")
      //logger.error("x:"+x)
      //logger.error("y:"+y)
      if(StringUtils.isBlank(x) || StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl: String = url.format(x,y)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      val code: Int = ret.getInteger("code")
      if(code==200){
        logger.error("调接口成功,code="+code)
      }else{
        logger.error("调接口失败,code="+code)
      }
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 节假日接口
   * @param year
   * @return
   */
  def holidaysInterface(year: String): JSONObject = {
    val url="https://api.apihubs.cn/holiday/get?cn=1&month=%s"
    val obj = new JSONObject()
    try {
      if(StringUtils.isEmpty(year)){
        return null
      }
      val finalUrl: String = url.format(year)
      logger.error("finalUrl"+finalUrl)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      /*if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return holidaysInterface(day)
        }
        obj.put("atRet",ret)
      }*/
      obj.put("ret",ret)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atRet",tmp)
    }
    obj
  }
  /**
   * 输入地址获取地址关键词
   * @param obj  传入的json对象

   * @return
   */
  def addrKeywordInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/iad/api/keyword?address=%s&ak=%s&addrType=0"
    try {
      val address: String = JSONUtil.getJsonValSingle(obj, "consignee_addr")
      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl: String = url.format(URLEncoder.encode(address,"utf-8"),ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("addr_keyword_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("addr_keyword_result",tmp)
    }
    obj
  }

  /**
   * 跑标准微服务接口获取adcode
   * @param obj  传入的json对象

   * @return
   */
  def adcodeInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal?address=%s&city=%s&ak=%s&opt=normdetail"
    try {
      val address: String = JSONUtil.getJsonValSingle(obj, "req_address")
      val citycode: String = JSONUtil.getJsonValSingle(obj, "citycode")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(citycode)){
        return obj
      }
      val finalUrl: String = url.format(URLEncoder.encode(address,"utf-8"),citycode,ak)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("ret_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret_result",tmp)
    }
    obj
  }


  /**
   * 跑运单接口
   * @param obj  传入的json对象

   * @return
   */
  def waybillnoInterface(obj:JSONObject): JSONObject = {
    val url="http://10.240.22.110:8101/delivery/"
    try {
      val waybillno = obj.getString("waybillno")
      if(StringUtils.isBlank(waybillno)){
        return obj
      }
      val finalUrl = url + waybillno
      obj.put("finalUrl",finalUrl)
      val ret: JSONArray = HttpInvokeUtil.httpGetArray(finalUrl,3)
      obj.put("ret",ret)

      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("waybillno_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("waybillno_result",tmp)
    }
    obj
  }
  /**
   * 跑AT接口
   * @param obj  传入的json对象

   * @return
   */
  def aoiRadiusInterface(obj:JSONObject): JSONObject = {
    val url="http://sds-core-datarun.sf-express.com/datarun/aoi/getGeomAoiBase?aoiId=%s&radius=%s"
    try {
      val aoi_id = obj.getString("aoi_id")
      val radius = obj.getString("radius")
      //logger.error("aoi_id:"+aoi_id)
      if(StringUtils.isBlank(aoi_id) || StringUtils.isBlank(radius)){
        return obj
      }
      val finalUrl: String = url.format(aoi_id,radius)
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      //logger.error("ret:"+ret)
      if (ret != null) {
        obj.put("api_result",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("api_result",tmp)
    }
    obj
  }
  /**
   * 跑天气查询接口,post接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def coordinateWeatherInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/getRainArea?"
    val json = new JSONObject()
    val data = new JSONArray()
    //val now = new Date()
    //val timestamp: String = (now.getTime / 1000).toString
    val timestamp: Long = obj.getLongValue("timestamp")/1000
    val x: Double = obj.getString("longitude").toDouble

    val y: Double = obj.getString("latitude").toDouble

    val coordinates = new JSONObject()
    coordinates.put("x",x)
    coordinates.put("y",y)
    data.add(coordinates)

    json.put("data",data)
    json.put("timestamp",timestamp)
    json.put("ak",ak)
    logger.error("===>>>>>:"+json.toJSONString)
    val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
    val ret: JSONObject = JSON.parseObject(retStr)
    val CODE: String = JSONUtil.getJsonValSingle(ret, "CODE")
    //val CODE: String = ret.getString("CODE")
    logger.error("===>>>:"+CODE)
    //obj.put("weatherRet",ret)
    if (CODE=="1"){
      obj.put("weatherRet",ret)
      println("weatherRet:"+ret)
    }
    obj
  }
  /**
   * 跑天气查询接口,post接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def weatherInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/getRainArea?"
    try {
      val json = new JSONObject()
      val data = new JSONArray()
      val time: String = obj.getString("time")
      val sdf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val date: Date = sdf.parse(time)
      val timestamp: String = ((date.getTime)/1000).toString

      val x: Double = obj.getString("centerx").toDouble

      val y: Double = obj.getString("centery").toDouble

      val coordinates = new JSONObject()
      coordinates.put("x",x)
      coordinates.put("y",y)
      data.add(coordinates)

      json.put("data",data)
      json.put("timestamp",timestamp)
      json.put("ak",ak)
      logger.error("===>>>>>:"+json.toJSONString)
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      val CODE: String = ret.getString("CODE")
      //logger.error("===>>>:"+CODE)
      if (CODE=="1"){
        obj.put("weatherRet",ret)
      }
      //Thread.sleep(2*1000)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("weatherRet",tmp)
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressMd5更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressMd5AoiCheckInterface4(obj:JSONObject) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrMd5AoiCheck"

    try {
      val citycode: String = obj.getString("city_code")
      val groupid: String = obj.getString("groupid")
      val groupidArray = new JSONArray()
      groupidArray.add(groupid)
      val json = new JSONObject()
      json.put("cityCode",citycode)
      json.put("addressMd5s",groupidArray)
      json.put("aoiCheckTag",4)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")
        if (success=="true"){
          logger.error(">>>>>>addressMd5接口更新")
        }
        obj.put("success",success)
      }

    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
        obj.put("exception","调addressMd5接口异常")
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressMd5更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressMd5AoiCheckInterface(obj:(String, Iterable[String])) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrMd5AoiCheck"
    try {
      val json = new JSONObject()
      val citycode: String = obj._1
      val groupid: scala.List[String] = obj._2.toList
      json.put("cityCode",citycode)
      json.put("addressMd5s",groupid)
      json.put("aoiCheckTag",5)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")
        if (success=="true"){
          logger.error(">>>>>>addressMd5接口更新")
        }
      }

    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
    }
  }
  /**
   * 地址AOI判错更新(通过addressId更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressIdAoiCheckInterface4(obj:JSONObject) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck"
    try {
      val citycode: String = obj.getString("city_code")
      val groupid: String = obj.getString("groupid")
      val groupidArray = new JSONArray()
      groupidArray.add(groupid)
      val json = new JSONObject()
      json.put("cityCode",citycode)
      json.put("addressIds",groupidArray)
      json.put("aoiCheckTag",4)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")

        if (success=="true"){
          logger.error(">>>>>>addressId接口更新")
        }

        obj.put("success",success)
      }
    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
        obj.put("exception","调addressId接口异常")
    }
    obj
  }
  /**
   * 地址AOI判错更新(通过addressId更新接口),post接口
   * @param obj  key：string和value：Iterable[String]的元祖

   * @return 不返回值
   */
  def addressIdAoiCheckInterface(obj:(String, Iterable[String])) = {
    val url="http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck"
    try {
      val json = new JSONObject()
      val citycode: String = obj._1
      val groupid: scala.List[String] = obj._2.toList
      json.put("cityCode",citycode)
      json.put("addressIds",groupid)
      json.put("aoiCheckTag",5)
      if(StringUtils.isNoneBlank(citycode)|| groupid.nonEmpty){
        val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
        val ret: JSONObject = JSON.parseObject(retStr)
        val success: String = ret.getString("success")

        if (success=="true"){
          logger.error(">>>>>>addressId接口更新")
        }
        Thread.sleep(10*1000)
      }

    } catch {
      case e: Exception => logger.error(e)
        logger.error("调addressId接口异常:"+e.getMessage)
    }
  }
  /**
   * 跑GIS-ASS-RDS-CHK查询接口,post接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def areaInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/chkquery/tc/teamCode"
    try {
      val json = new JSONObject()
      val address: String = JSONUtil.getJsonValSingle(obj, "address")
      println("address"+address)
      val cityCode: String = JSONUtil.getJsonValSingle(obj, "cityCode")
      json.put("address",address)
      json.put("cityCode",cityCode)
      json.put("sysCode","BDP")
      json.put("addressType","2")
      json.put("type","1")
      json.put("ak",ak)
      if(StringUtils.isBlank(address)||StringUtils.isBlank(cityCode)){
        return obj
      }
      val retStr: String = HttpInvokeUtil.sendPost(url,json.toJSONString)
      val ret: JSONObject = JSON.parseObject(retStr)
      val retCode: String = ret.getString("retCode")
      if (retCode=="1"){
        obj.put("areaRet",ret)
      }

    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("areaRet",tmp)
    }
    obj
  }
  /**
   * 跑AT接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def atOtherInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?ak=%s&address=%s&city=%s&opt=zh&callDispatch=1&isNotUnderCall=1&needAoiArea=1&company=%s"
    try {
      val address = obj.getString("req_address")
      val city = obj.getString("citycode")
      val company = obj.getString("req_comp_name")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city,URLEncoder.encode(company,"utf-8"))
      val ret: JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atOtherInterface(ak,obj)
        }
        obj.put("atRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atRet",tmp)
    }
    obj
  }
  /**
   * 跑ATP接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def atpInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=%s&address=%s&city=%s&opt=zh&company=%s"
    try {
      val address = obj.getString("req_address")
      val city = obj.getString("citycode")
      val company = obj.getString("req_comp_name")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city,URLEncoder.encode(company,"utf-8"))
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atpInterface(ak,obj)
        }
        obj.put("atpRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atpRet",tmp)
    }
    obj
  }
  /**
   * 判断precision跑aoi接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def aoiXYInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=%s"
    try {
      val precision_gd: Integer = obj.getInteger("precision_gd")
      if (precision_gd==2){
        val x = obj.getString("gd_x")
        val y = obj.getString("gd_y")
        if(StringUtils.isNoneBlank(x)||StringUtils.isNoneBlank(y)){
          val finalUrl = url.format(x,y,ak)
          val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
          if (ret != null) {
            if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep((60-second)*1000)
              return aoiXYInterface(ak,obj)
            }
            obj.put("gdAoiRet",ret)
          }
        }
      }
      val precision_rh: Integer = obj.getInteger("precision_rh")
      if (precision_rh==2){
        val x = obj.getString("rh_x")
        val y = obj.getString("rh_y")
        if(StringUtils.isNoneBlank(x)||StringUtils.isNoneBlank(y)){
          val finalUrl = url.format(x,y,ak)
          val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
          if (ret != null) {
            if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep((60-second)*1000)
              return aoiXYInterface(ak,obj)
            }
            obj.put("rhAoiRet",ret)
          }
        }
      }
      val precision_tc: Integer = obj.getInteger("precision_tc")
      if (precision_tc==2){
        val x = obj.getString("tc_x")
        val y = obj.getString("tc_y")
        if(StringUtils.isNoneBlank(x)||StringUtils.isNoneBlank(y)){
          val finalUrl = url.format(x,y,ak)
          val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
          if (ret != null) {
            if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep((60-second)*1000)
              return aoiXYInterface(ak,obj)
            }
            obj.put("tcAoiRet",ret)
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("aoiRet",tmp)
    }
    obj
  }
  /**
   * 跑aoi接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def aoiInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=%s"
    try {
      val x = obj.getString("x")
      val y = obj.getString("y")
      if(StringUtils.isBlank(x)||StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl = url.format(x,y,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return aoiInterface(ak,obj)
        }
        obj.put("aoiRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("aoiRet",tmp)
    }
    obj
  }
  /**
   * 跑at接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def atInterface(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=zh"
    try {
      val address = obj.getString("address")
      val cityCode = obj.getString("citycode")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(cityCode)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),cityCode,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return atInterface(ak,obj)
        }
        obj.put("atRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("atRet",tmp)
    }
    obj
  }
  /**
   * 跑楼栋数据
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def buildingId(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/building/address/identify?address=%s&cityCode=%s&ak=%s"
    try {
      val address = obj.getString("address")
      val cityCode = obj.getString("cityCode")
      if(StringUtils.isBlank(address)||StringUtils.isBlank(cityCode)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),cityCode,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return buildingId(ak,obj)
        }
        obj.put("buildingIdRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("buildingIdRet",tmp)
    }
    obj
  }
  /**
   * 地址可达
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def addrReach(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/ar/api?province=%s&city=%s&district=%s&address=%s&ak=%s&extention=0&datatype=r01&opt="
    try {
      val province = JSONUtil.getJsonValSingle(obj,"province")
      val city = JSONUtil.getJsonValSingle(obj,"city")
      val district = JSONUtil.getJsonValSingle(obj,"district")
      val address = JSONUtil.getJsonValSingle(obj,"address")
      if(StringUtils.isBlank(address)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(province,"utf-8"),URLEncoder.encode(city,"utf-8"),URLEncoder.encode(district,"utf-8"),URLEncoder.encode(address,"utf-8"),ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return addrReach(ak,obj)
        }
        obj.put("addrReachRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("addrReachRet",tmp)
    }
    obj
  }
  /**
   * 跑容灾接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def rdsRzNorm(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=normdetail"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city: String = JSONUtil.getJsonValSingle(obj,"citycode")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),city,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return addrReach(ak,obj)
        }
        obj.put("rdsRzNormRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("rdsRzRet",tmp)
    }
    obj
  }

  /**
   * 跑ab合库效果测试接口
   * @param ak   ak值
   * @param obj  传入的json对象

   * @return
   */
  def rdsAbMergeXiaoguoCeshi(ak:String,obj:JSONObject): JSONObject = {
    val url="http://10.240.162.41:8082/atdispatch/api?address=%s&city=%s&ak=&opt=normdetail&geoType=9991-1024016241"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"citycode")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(URLEncoder.encode(address,"utf-8"),city,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return rdsAbMergeXiaoguoCeshi(ak,obj)
        }
        obj.put("rdsAbMergeXgcsRet",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("rdsAbMergeXgcsRet",tmp)
    }
    obj
  }

  /**
   * 跑rh接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def georhgis(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=rh1&address=%s&city=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"city_code")

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geogdgis(ak,obj)
        }
        obj.put("georhgis",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("georhgis",tmp)
    }
    obj
  }
  /**
   * 跑gd2接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def geogd2gis(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=gd2&address=%s&city=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"city_code")

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geogdgis(ak,obj)
        }
        obj.put("geogdgis",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("geogdgis",tmp)
    }
    obj
  }
  /**
   * 跑高德接口
   * @param ak   ak值
   * @param obj  传入的json对象

   *
   */

  def geogdgis(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=gd2&address=%s&city=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"citycode")

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }
      val finalUrl = url.format(ak,URLEncoder.encode(address,"utf-8"),city)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geogdgis(ak,obj)
        }
        obj.put("geogdgis",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("geogdgis",tmp)
    }
    obj
  }

  /**
   * 跑MAPA接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def geoMa1(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=ma1&address=%s&city=%s"
    try {

      val address = JSONUtil.getJsonValSingle(obj,"address")
      val city = JSONUtil.getJsonValSingle(obj,"citycode")
      val finalUrl: String = url.format(ak,URLEncoder.encode(address,"utf-8"),city)

      if(StringUtils.isBlank(address) || StringUtils.isBlank(city)){
        return obj
      }

      val ret:JSONObject = HttpInvokeUtil.httpGetJSON(finalUrl,3)

      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return geoMa1(ak,obj)
        }
        obj.put("geoMa1",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("geoMa1",tmp)
    }
    obj
  }
  /**
   * 跑点落面服务接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def checksDepot(ak:String,obj:JSONObject): JSONObject = {
    val url="http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=%s&lat=%s&ak=%s"
    try {
      val x = JSONUtil.getJsonValSingle(obj,"x")
      val y = JSONUtil.getJsonValSingle(obj,"y")
      if(StringUtils.isBlank(x) || StringUtils.isBlank(y)){
        return obj
      }
      val finalUrl = url.format(x,y,ak)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return checksDepot(ak,obj)
        }
        obj.put("checksDepot",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("checksDepot",tmp)
    }
    obj
  }
  /**
   * 快运audit数据更新接口
   * @param ak   ak值
   * @param obj  传入的json对象
   *
   */
  def kyAudit(ak:String,obj:JSONObject): JSONObject = {

    val url="http://gis-int.int.sfdc.com.cn:1080/ky/audit/inc?ak=%s&address=%s&tc=%s&citycode=%s"
    try {
      val address = JSONUtil.getJsonValSingle(obj,"address")
      val citycode = JSONUtil.getJsonValSingle(obj,"citycode")
      val tc = JSONUtil.getJsonValSingle(obj,"tc")
      if(StringUtils.isBlank(address) || StringUtils.isBlank(citycode) || StringUtils.isBlank(tc)){
        return obj
      }
      val finalUrl = url.format(ak,address,tc,citycode)
      println(finalUrl)
      val ret = HttpInvokeUtil.httpGetJSON(finalUrl,3)
      if (ret != null ) {
        if(ret.getInteger("status")!=0 && ret.getJSONObject("result").getInteger("err")==InfConstant.AK_RESTRICTIONS_109){
          val second = Calendar.getInstance().get(Calendar.SECOND)
          Thread.sleep((60-second)*1000)
          return kyAudit(ak,obj)
        }
        obj.put("kyAudit",ret)
      }
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("kyAudit",tmp)
    }
    obj
  }


  /**01412406
   * 审补地址下线/压入cms审补库
   * @param ak   ak值
   * @param obj  传入的json对象
   * @param operUserName  下线人名称
   * @param operSource  下线人工号
   * @param retry  重试次数
   * @param ty  del:地址下线/cms:压入审补库
   * @return
   */

  def rgsbAddr(operUserName:String,operSource:String,ak:String,obj:JSONObject,retry:Int,ty:String) ={

    var addrUrl=""
    var count = 1
    var httpData: util.Map[String, AnyRef] = null
    var ret: JSONObject = new JSONObject()
    val city_code = JSONUtil.getJsonVal(obj,"city_code","")
    val gis_to_sys_groupid = JSONUtil.getJsonVal(obj,"gis_to_sys_groupid","")
    val zc = JSONUtil.getJsonVal(obj,"zc","")
    val checkAoiId = JSONUtil.getJsonVal(obj,"checkAoiId","")
    val address = JSONUtil.getJsonVal(obj,"address","")

    val parm = new JSONObject()
    parm.put("ak", ak)
    parm.put("operSource", operSource)
    parm.put("operUserName", operUserName)
    val addressObject = new JSONObject()

    ty match {
      case "del" => {
        //地址下线
        addrUrl= delUrl
        addressObject.put("cityCode", city_code)
        addressObject.put("addressMd5", gis_to_sys_groupid)
        addressObject.put("type", 2)
        parm.put("addressDel", addressObject)

      }
      case "cms" => {
        //压入cms审补库
        addrUrl= cmsUrl
        addressObject.put("cityCode", city_code)
        addressObject.put("address", address)
        addressObject.put("znoCode",zc)
        addressObject.put("aoiId",checkAoiId)
        parm.put("addressSave",addressObject)
      }

    }


    if(StringUtils.isNotEmpty(addrUrl)){
      httpData = HttpConnection.sendPost(addrUrl, parm.toJSONString)


      while (!httpData.getOrDefault("code","").equals("1") && count < retry){
        count=count+1
        val second = Calendar.getInstance().get(Calendar.SECOND)
        Thread.sleep(60 - second)
        httpData = HttpConnection.sendPost(addrUrl, parm.toJSONString)
      }



      if (httpData.get("content") != null ) {
        val content = httpData.get("content").toString
        ret = JSON.parseObject(content)
        ret
      }
      else{
        val code = httpData.get("code")
        ret.put("code",code)
        ret
      }

    }
    ret
  }


  //  /**
  //    * 工单地址匹配标准库数据
  //    * http://10.220.21.90:1080/atdispatch/api?ak=c274bbf7007c411c8e21a6abe31a9886&address=%s&city=%s&opt=normdetail
  //    * @param ak   ak值
  //    * @param obj  传入的json对象
  //    * @param retry  重试次数
  //    * @return
  //    */
  //  def getNormInfo(ak:String,obj:JSONObject,retry:Int) ={
  //    val url ="http://10.220.21.90:1080/atdispatch/api?ak=%s&address=%s&city=%s&opt=normdetail"
  //    val city = JSONUtil.getJsonVal(obj,"city","")
  //    val address = JSONUtil.getJsonVal(obj,"address","")
  //    var ret: JSONObject = null
  //    try{
  //      if(!city.isEmpty && !address.isEmpty){
  //        val inputurl = String.format(url,ak,URLEncoder.encode(address, "utf-8"),city)
  //         ret = HttpClientUtil.getJsonByGet(inputurl,retry)
  //      }
  //      ret
  //    }catch {
  //      case e:Exception=>logger.error(e)
  //       ret.put("myException",e.toString)
  //       ret
  //    }
  //
  //  }



  def main(args: Array[String]): Unit = {
    val dd = new JSONObject()
    dd.put("address","广东省深圳市宝安区海雅缤纷城君誉-C单元建安一路99号顺丰标快1")
    dd.put("citycode","755")
    dd.put("tc","755FG123")
    val ff = kyAudit("f14167603f8c48acbb31655a2f987578",dd)
    println(ff.toJSONString)
  }
}
