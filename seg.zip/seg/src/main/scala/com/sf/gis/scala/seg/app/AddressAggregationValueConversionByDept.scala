package com.sf.gis.scala.seg.app

import java.io.InputStreamReader
import java.net.URLEncoder
import java.time.{Duration, Instant}
import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.SaveResultUtil
import com.sf.gis.scala.seg.bean.Waybill
import org.apache.commons.csv.CSVFormat
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.{HashMap, Set}
import scala.io.Source


/*
SELECT  substring(tmp1.opdate,0,4),tmp1.opdate,tmp1.znocode,tmp1.dipuamout / tmp2.cnt,tmp1.dispatchdist / tmp2.cnt from
(select znocode,opdate,SUM(dipuamout) dipuamout,sum(dispatchdist) dispatchdist
from dm_gis.address_agg_value_conversion_diprec where inc_day='20200624' and dipuamout != 0 and dispatchdist != 0
group by znocode,opdate )tmp1
join (
    select znocode,count(distinct opdate) cnt
    from dm_gis.address_agg_value_conversion_diprec where inc_day='20200624' and dipuamout != 0 and dispatchdist != 0
    group by znocode
) tmp2
on tmp1.znocode = tmp2.znocode
* */

object AddressAggregationValueConversionByDept {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  //派件难度-特殊入仓与电梯（GIS-ASS-ADDS）接口
  val  vasUrl= "http://gis-int2.int.sfdc.com.cn:1080/diff/api/vas?address=%s&citycode=%s&opt=ataoi&ak=8bb09e5e110845f39a000391668e3e80"
  //地址聚合服务接口
  val addAggUrl = "http://gis-int2.int.sfdc.com.cn:1080/agg/api/AddressAggregation?address=%s&citycode=%s&level=13&ak=11fbd8a3b26545fa9df84ded1f3debb3"
  //常规骑行服务
  val rpUrl = "http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&opt=sf1&type=1&strategy=0&ak=fb4065ab53174149a49d31fe0ce1d8b9"

  val empcodeSpeedPath = "小哥交通工具默认速度.csv"
  val saveLostBillTable= "Address_Agg_value_Conversion_LostBill"
  val saveTimeCostTable = "Address_Agg_value_SaveTimeCost"
  val parDate = "20200624"

  def main(args: Array[String]): Unit = {
    val spark =Spark.getSparkSession(appName)

    //flag=0 计算漏单率，入库且计算时间成本；flag=1 只计算楼漏单率且入库；flag=2 不计算漏单率，只计算时间成本
    val flag = if (args.length == 0) "0" else args(0)

    println(s"flag=$flag")


    if (flag == "0" || flag == "1" || flag == "2") {

      val rdd = getDispatchData(spark)

      if (flag == "1")
      //计算漏单率入库
      calculateMissedOrders(rdd,spark)

      if (flag == "2")
      //计算时间成本
      calculateSaveTimeCosts(rdd,spark)

      if (flag == "0"){
        //计算漏单率
        calculateMissedOrders(rdd,spark)
        //计算时间成本
        calculateSaveTimeCosts(rdd,spark)
      }
    }else{
      logger.error("请输入正确参数如：0,1,2")
    }

    spark.close()
  }

  val saveLostBill = (saveRDD:RDD[JSONObject],path:String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("城市")).append("\t")
      sb.append(obj.getString("网点")).append("\t")
      sb.append(obj.getString("日期")).append("\t")
      sb.append(obj.getString("小哥")).append("\t")
      sb.append(obj.getString("总量")).append("\t")
      sb.append(obj.getString("漏单总量")).append("\t")
      sb.append(obj.getString("漏单率"))

      sb.toString()
    }).saveAsTextFile(path)
  }

  val getSpeed = (transportation:String) => transportation match {
    case "步行" => 4
    case "自行车" => 10
    case _ if transportation.contains("电动车")  => 15
    case _ if transportation.contains("摩托车")  => 20
    case _ if transportation.contains("汽车") => 30
    case _ => 0
  }

  val saveTimeCost = (saveRDD:RDD[JSONObject],path:String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("cityCode")).append("\t")
      sb.append(obj.getString("date")).append("\t")
      sb.append(obj.getString("empCode")).append("\t")
      sb.append(obj.getString("dist")).append("\t")
      sb.append(obj.getString("saveTime")).append("\t")
      sb.append(obj.getString("cutCosts"))

      sb.toString()
    }).saveAsTextFile(path)
  }

  def calculateSaveTimeCosts(rdd:RDD[Waybill],spark:SparkSession){
    //那就从上一票派件单的地址对应的坐标到当前这一票上门取件的坐标，两者之间的轨迹剔除，以及下一票派件地址对应的坐标之间的轨迹剔除。
    //获取处于派件最早最晚之间的收件信息
    val dispuchRDD = rdd.map(obj => {

      ((obj.getCouriercode,obj.getIncday,obj.getZonecode,obj.getCitycode),obj)
    }).groupByKey().map(obj => {

      val list = obj._2.toList
      (obj._1,list)
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error(s"按工号聚合后的派件数据:${dispuchRDD.count()}")

    val empList = dispuchRDD.keys.map(_._1).collect().toList.distinct

    //获取收件数据
    val  recieveMap = getRecieveMap(spark,empList)

    //关联收件派件数据
    val joinRDD = getJoinRDD(dispuchRDD,recieveMap)

    //调用常规骑行接口,计算小哥折返路程
    val returnJourneyRDD = getReturnJourney(joinRDD)

    //入库到hive
    SaveResultUtil.saveResult(logger,spark,returnJourneyRDD,returnJourney,"address_agg_value_conversion_diprec",parDate)
  }



  val returnJourney = (saveRDD:RDD[JSONObject],path:String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("empCode")).append("\t")
      sb.append(obj.getString("opDate")).append("\t")
      sb.append(obj.getString("znoCode")).append("\t")
      sb.append(obj.getString("cityCode")).append("\t")
      sb.append(obj.getDouble("receiveAmount")).append("\t")
      sb.append(obj.getDouble("dipuAmout")).append("\t")
      sb.append(obj.getDouble("recevieDist")).append("\t")
      sb.append(obj.getDouble("dispatchDist")).append("\t")
      sb.append(obj.getDouble("dist")).append("\t")
      sb.append(obj.getString("respString"))

      sb.toString()
    }).saveAsTextFile(path)
  }

  def getRecieveMap(spark: SparkSession,empList:List[String])={
    val querySql =
      s"""
        |select
        | waybillno,
        | userid,
        | dept_code,
        | operatime_new,
        | consignor_addr,
        | eventlng,
        | eventlat
        |from dm_tdos.middle_gis_pick_way_info
        |where dt='$parDate' and userid in ('${empList.mkString("','")}')
        | and eventlng is not null and eventlng <> '' and eventlng <>'null'
        | and eventlat is not null and eventlat <> '' and eventlat <>'null'
        |""".stripMargin

    logger.error(querySql)

    //获取收件数据
    val recieveMap = spark.sql(querySql)
      .rdd.repartition(50).map(obj => {
      val waybill = new Waybill
      waybill.setWaybillno(obj.getString(0))
      waybill.setCouriercode(obj.getString(1))
      waybill.setZonecode(obj.getString(2))
      waybill.setTimeps(obj.getString(3))
      waybill.setConsigneeaddr(obj.getString(4))
      waybill.setLongitude(obj.getString(5))
      waybill.setLatitude(obj.getString(6))
      waybill.setCitycode(obj.getString(2).substring(0, 3))
      waybill.setIncday(obj.getString(3).substring(0, 10).replaceAll("-", ""))
      waybill.setKeyword("")
      waybill.setAoiid("")
      waybill.setStatus(1)
      waybill.setDispatch(false)

      waybill
    }).map(obj => {
      ((obj.getCouriercode,obj.getIncday,obj.getZonecode,obj.getCitycode),obj)
    }).groupByKey().map(obj => {
      val list = obj._2.toList
      (obj._1,list)
    }).collect().toMap

    //recieveMap.foreach(println)
    logger.error(s"获取收件数据：共${recieveMap.size}")

    recieveMap
  }

  def getJoinRDD(dispuchRDD: RDD[((String, String, String, String), scala.List[Waybill])],recieveMap: Map[(String, String, String, String), scala.List[Waybill]])={

    //关联收件和派件订单
    val joinRDD = dispuchRDD.filter(_._2.size > 1).map(obj => {
      var arr = obj._2

      //按工号合并收件和派件
      if (recieveMap.contains(obj._1)) {
        arr = obj._2 ::: recieveMap.get(obj._1).get
      }

      arr = arr.sortBy( _.getTimeps )

      val firstDipu = arr.indexWhere( _.isDispatch )
      val lastDipu = arr.lastIndexWhere( _.isDispatch )

      //截取最早和最晚派件之间的收件派件订单
      arr = arr.slice( firstDipu,lastDipu + 1)

      val dipuAmout = arr.filter( _.isDispatch ).size.toDouble
      val receiveAmount = arr.filter( ! _.isDispatch ).size.toDouble

      val jsonObj = new JSONObject()
      jsonObj.put("empCode",obj._1._1)
      jsonObj.put("opDate",obj._1._2)
      jsonObj.put("znoCode",obj._1._3)
      jsonObj.put("cityCode",obj._1._4)
      jsonObj.put("receiveAmount",receiveAmount)
      jsonObj.put("dipuAmout",dipuAmout)

      (jsonObj,arr)
    })

    joinRDD
  }

  def calculateMissedOrders(rdd:RDD[Waybill],spark:SparkSession)={
    val resultRdd = getKeyword(rdd).persist(StorageLevel.MEMORY_AND_DISK)

    val lostBillSaveRDD = keywordStat(resultRdd)

    //入库到hive
    SaveResultUtil.saveResult(logger,spark,lostBillSaveRDD,saveLostBill,saveLostBillTable,parDate)

    lostBillSaveRDD
  }

  def getDispatchData(sparkSession: SparkSession)= {

    val querySql = s"select * from dm_gis.address_agg_value_conversion_tempres where inc_day='$parDate' and  dispatch is not null"
    //and couriercode in ('001038')
    logger.error(querySql)

    var vasRDD = sparkSession.sql(querySql).repartition(50).rdd.map(row => {

      val waybill = new Waybill
      waybill.setWaybillno(row.getString(0))
      waybill.setCouriercode(row.getString(1))
      waybill.setZonecode(row.getString(2))
      waybill.setTimeps(row.getString(3))
      waybill.setConsigneeaddr(row.getString(4))
      waybill.setLongitude(row.getString(5))
      waybill.setLatitude(row.getString(6))
      waybill.setCitycode(row.getString(7))
      waybill.setIncday(row.getString(8))
      waybill.setKeyword(row.getString(9))
      waybill.setAoiid(row.getString(10))
      waybill.setStatus(row.getInt(11))
      waybill.setLongitude_s(row.getString(12))
      waybill.setLatitude_s(row.getString(13))
      waybill.setDispatch(row.getBoolean(14))

      waybill

    }).persist(StorageLevel.MEMORY_AND_DISK)

    val cnt = vasRDD.count()

    logger.error(s">>>从缓存中查询派件共:$cnt<<<")

    if ( 0 == cnt ) {
      vasRDD =  getSourDispatchRDD(sparkSession)
    }

    vasRDD
  }

  def getSourDispatchRDD(sparkSession: SparkSession) = {
    logger.error(">>>从源数据中查询派件<<<")

    val dispatchTable = "dm_tdos.application_gis_way_info"

    //获取派件数据并过滤掉客户声音数据
    val sql =
      s"""
      select
        waybillno,80_userid,80_user_dept,80_operatime_new,consignee_addr,80_lng,80_lat,204_lng,204_lat
      from (
          select
            t1.waybillno,
            t2.bill_no,
            t1.80_userid,
            t1.80_user_dept,
            t1.80_operatime_new,
            t1.consignee_addr,
            t1.80_lng,
            t1.80_lat,
            t1.204_lng,
            t1.204_lat
          from $dispatchTable t1
          left join ods_inc_sgs_core.tt_delivery_oms_change_record t2
          on t1.waybillno = t2.bill_no
          where t1.inc_day = '$parDate'
            and t1.waybillno is not null and t1.waybillno <> '' and t1.waybillno <> 'null'
            and t1.consignee_addr is not null and t1.consignee_addr <> 'null' and t1.consignee_addr <> ''
            and t1.80_lng is not null and t1.80_lng <> 'null' and t1.80_lng <> ''
            and t1.80_lat is not null and t1.80_lat <> 'null' and t1.80_lat <> ''
       ) tmp where tmp.bill_no is null
      """.stripMargin

    //and 80_userid in ('001038')

    logger.error(sql)

    val rdd = sparkSession.sql(sql).repartition(50).rdd.map(row => {

      val waybill = new Waybill
      waybill.setWaybillno(row.getString(0))
      waybill.setCouriercode(row.getString(1))
      waybill.setZonecode(row.getString(2))
      waybill.setTimeps(row.getString(3))
      waybill.setConsigneeaddr(row.getString(4))
      waybill.setLongitude(row.getString(5))
      waybill.setLatitude(row.getString(6))
      waybill.setCitycode(row.getString(2).substring(0, 3))
      waybill.setIncday(row.getString(3).substring(0, 10).replaceAll("-", ""))
      waybill.setKeyword("")
      waybill.setAoiid("")
      waybill.setStatus(1)
      waybill.setLongitude_s(row.getString(7))
      waybill.setLatitude_s(row.getString(8))
      waybill.setDispatch(true)

      waybill
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error(s"过滤客户声音后获取派件数据：${rdd.count()}")

    //跑派件难度-特殊入仓与电梯（GIS-ASS-ADDS）接口，获取C类区域（住宅区）运单
    val (vasRDD,saveRDD) = getVasRDD(rdd)

    //将过滤后的结果预存hive
    SaveResultUtil.saveResult(logger,sparkSession,saveRDD,saveVas,"address_agg_value_conversion_tempres",parDate)

    vasRDD
  }

  def getVasRDD(rdd: RDD[Waybill])={
    val vasRDD = rdd.map(waybill => {

      val query = String.format(vasUrl, URLEncoder.encode(waybill.getConsigneeaddr, "utf-8"), waybill.getCitycode)
      val resp = Source.fromURL(query, "utf-8").mkString

      val aoiTypeCode = try { JSON.parseObject(resp).getJSONObject("result").getJSONObject("adata").getString("aoitypecode") }
      catch {case e: Exception => "-1"}

      if ("120301".equals(aoiTypeCode) || "120302".equals(aoiTypeCode))
        waybill
      else null

    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error(s"获取c类区域订单：${vasRDD.count()}\n\n\n")

    rdd.unpersist()

    val saveRDD = vasRDD.map(obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("waybillno",obj.getWaybillno)
      jsonObj.put("empCode",obj.getCouriercode)
      jsonObj.put("zonecode",obj.getZonecode)
      jsonObj.put("timeps",obj.getTimeps)
      jsonObj.put("consigneeaddr",obj.getConsigneeaddr)
      jsonObj.put("longitude",obj.getLongitude)
      jsonObj.put("latitude",obj.getLatitude)
      jsonObj.put("citycode",obj.getCitycode)
      jsonObj.put("incday",obj.getIncday)
      jsonObj.put("keyword",obj.getKeyword)
      jsonObj.put("aoiid",obj.getAoiid)
      jsonObj.put("status",obj.getStatus)
      jsonObj.put("longitude_s",obj.getLongitude_s)
      jsonObj.put("latitude_s",obj.getLatitude_s)
      jsonObj.put("dispatch",obj.isDispatch)

      jsonObj
    })

    (vasRDD,saveRDD)
  }

  val saveVas = (saveRDD: RDD[JSONObject],path:String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("waybillno")).append("\t")
      sb.append(obj.getString("empCode")).append("\t")
      sb.append(obj.getString("zonecode")).append("\t")
      sb.append(obj.getString("timeps")).append("\t")
      sb.append(obj.getString("consigneeaddr")).append("\t")
      sb.append(obj.getString("longitude")).append("\t")
      sb.append(obj.getString("latitude")).append("\t")
      sb.append(obj.getString("citycode")).append("\t")
      sb.append(obj.getString("incday")).append("\t")
      sb.append(obj.getString("keyword")).append("\t")
      sb.append(obj.getString("aoiid")).append("\t")
      sb.append(obj.getInteger("status")).append("\t")
      sb.append(obj.getString("longitude_s")).append("\t")
      sb.append(obj.getString("latitude_s")).append("\t")
      sb.append(obj.getBoolean("dispatch"))


      sb.toString()
    }).saveAsTextFile(path)
  }

  def getKeyword(rdd: RDD[Waybill]): RDD[Waybill] = {
    logger.error("开始查询接口")

    val result = getAggregationAddr(rdd)
    val successRdd = result.filter(waybill => waybill.getStatus == 0).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("成功数据量:" + successRdd.count())
    rdd.unpersist()
    successRdd
  }

  //调用接口获取地址聚合结果
  def getAggregationAddr(rdd: RDD[Waybill]): RDD[Waybill] = {
    rdd.map(waybill => {
      var keyWord = ""
      var aoiid = ""
      var status = 1

      if (StringUtils.isNotBlank(waybill.getConsigneeaddr)) {
        val query = String.format(addAggUrl, URLEncoder.encode(waybill.getConsigneeaddr, "utf-8"), waybill.getCitycode)
        val resp = Source.fromURL(query, "utf-8").mkString

        logger.error(resp)
        val json = JSON.parseObject(resp)
        status = json.getInteger("status")

        if (status == 0) {
          val data = json.getJSONObject("result").getJSONObject("data")
          if (data != null) {
            if (data.getString("key_word") != null) {
              keyWord = data.getString("key_word")
            }
            if (data.getString("aoi_id") != null) {
              aoiid = data.getString("aoi_id")
            }
          }
        }
      }

      waybill.setKeyword(keyWord)
      waybill.setAoiid(aoiid)
      waybill.setStatus(status)

      waybill
    })
  }

  def keywordStat(resultRdd:RDD[Waybill])= {
    logger.error("计算漏单情况:")

    val rdd = resultRdd.filter(obj => StringUtils.isNotBlank(obj.getKeyword))
      .map(obj => {
        ((obj.getCitycode, obj.getZonecode, obj.getIncday, obj.getCouriercode), obj)
      }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("查询数据量:" + rdd.count())
    val start = Instant.now()

    val keywordStatRDD = rdd.groupByKey().map(key => {
      val list = key._2.toList.sortBy(el => (el.getTimeps, el.getKeyword))
      var cnt = 0
      val map = new util.HashMap[String, Integer]()

      for (waybill <- list) {
        if (map.get(waybill.getKeyword) == null) {
          cnt += 1
          map.put(waybill.getKeyword, cnt)
        }
      }

      val set = new util.HashSet[String]()
      val timeSet = new util.HashSet[String]()
      var aggAddr = ""
      var aggAoi = ""
      var num = 0
      var max = 0

      for (waybill <- list) {
        timeSet.add(waybill.getTimeps)
        val next = (waybill.getKeyword.equals(aggAddr) && !"****".equals(waybill.getKeyword)) || ("****".equals(aggAddr) && aggAoi.equals(waybill.getAoiid))
        if (next) {
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        } else {
          set.add(waybill.getKeyword)
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        }
        if (map.get(waybill.getKeyword) > max) {
          max = map.get(waybill.getKeyword)
        }
        aggAddr = waybill.getKeyword
        aggAoi = waybill.getAoiid
      }

      val jsonObj = new JSONObject()
      jsonObj.put("城市",key._1._1)
      jsonObj.put("网点",key._1._2)
      jsonObj.put("日期",key._1._3)
      jsonObj.put("小哥",key._1._4)
      jsonObj.put("总量",list.size)
      jsonObj.put("漏单总量",num)
      jsonObj.put("漏单率",(num.toDouble/list.size).formatted("%.4f"))

      jsonObj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("城市 网点 日期 小哥分组共：" +keywordStatRDD.count())

    val end = Instant.now()
    logger.error("统计耗时:" + Duration.between(start, end).getSeconds + "s")

    keywordStatRDD
  }

  def getEmpList(spark:SparkSession,lostBillSaveRDD:RDD[JSONObject]):Set[String] ={
    logger.error("开始筛选漏单的小哥工号")
    val empSet: Set[String] = Set()
    lostBillSaveRDD.collect().foreach(obj => {

      if(obj.getString("漏单率").toDouble > 0d) {
        empSet.add(obj.getString("小哥"))
      }

    })

    spark.sparkContext.broadcast(empSet)
    logger.error("empList的大小为："+empSet.size)

    empSet
  }

  def getReturnJourney(empListRDD:RDD[(JSONObject,List[Waybill])])={
    logger.error("计算行程开始")

    val returnJourneyRDD = empListRDD.map(elem =>{
      var recevieDist = 0d
      var dispatchDis = 0d
      val list =  elem._2
      var respString = ""

      list.foreach(obj => {
        //80为妥投视为终点，204为出仓，视为起点
        val e_lat = obj.getLatitude
        val s_lat = if (obj.isDispatch) obj.getLatitude_s else list(list.indexOf(obj)-1).getLatitude
        val e_lng = obj.getLongitude
        val s_lng = if (obj.isDispatch) obj.getLongitude_s else list(list.indexOf(obj)-1).getLongitude

        val query = String.format( rpUrl,s_lng,s_lat,e_lng,e_lat )

        //调用骑行服务接口
        var resp = ""
        var json = new JSONObject()

        try{
          resp = Source.fromURL(query, "utf-8").mkString
          json = JSON.parseObject(resp)
        } catch {
          case e:Exception => logger.error(e)
            resp = Source.fromURL(query, "utf-8").mkString
            json = JSON.parseObject(resp)
        }

        val status = json.getInteger("status")

        if (status == 0) {
          val distString = json.getJSONObject("result").getString("dist")
          if (StringUtils.isNotBlank(distString) )
            if (obj.isDispatch)
              dispatchDis += distString.toDouble
            else recevieDist += distString.toDouble
        } else {
          respString += obj.getWaybillno+",收/派件"+obj.isDispatch+","+resp + "|"
        }

      })

      val json = elem._1

      json.put("recevieDist",recevieDist)
      json.put("dispatchDist",dispatchDis)
      json.put("dist",dispatchDis - recevieDist)
      json.put("respString",respString)

      json
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("获取有效行程个数：" +  returnJourneyRDD.count)

    returnJourneyRDD
  }

  def getSpeedMap(spark: SparkSession) ={
    logger.error("计算交通工具映射速度开始")

    val speedMap = HashMap[String,Int]()

    val in = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream(empcodeSpeedPath), "utf-8")

    val records = CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord().parse(in).iterator()
    while (records.hasNext){
      val elem = records.next()
      speedMap.put(elem.get("工号"),getSpeed(elem.get("交通类型")))
    }

    spark.sparkContext.broadcast(speedMap)

    logger.error("speedMap 大小为：" + speedMap.size)

    speedMap
  }

  def getSaveRDD(returnJourneyRDD:  RDD[((String, String, String), (Integer, Double,String))],speedMap: HashMap[String, Int]):RDD[JSONObject]={
    logger.error("计算节省时间&成本开始")

    val saveRDD = returnJourneyRDD.map(obj => {
      val speed = speedMap.getOrElse(obj._1._3,0)
      val dist = obj._2._2

      //dist:m   speed/km/h  saveTime:h  cutCosts:块
      val saveTime = if (speed == 0) 0 else (dist/1000/ speed).formatted("%.4f").toDouble
      val cutCosts = if (saveTime == 0) 0 else (saveTime * (8000d / 26 / 10)).formatted("%.4f").toDouble

      val jsonObj = new JSONObject()
      jsonObj.put("cityCode",obj._1._1)
      jsonObj.put("date",obj._1._2)
      jsonObj.put("empCode",obj._1._3)
      jsonObj.put("dist",dist/1000)
      jsonObj.put("saveTime",saveTime)
      jsonObj.put("cutCosts",cutCosts)

      jsonObj
    })/*.filter(_.getDouble("saveTime") != 0d)*/
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("获取有效节省时间&成本数量："+ saveRDD.count())

    saveRDD
  }
}
