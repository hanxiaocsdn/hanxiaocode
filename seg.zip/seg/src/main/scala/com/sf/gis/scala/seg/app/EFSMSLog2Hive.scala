package com.sf.gis.scala.seg.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.ShellExcutor
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.seg.bean.EFSMSLog
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * 原始数据已不存在，已经下线
 */
object EFSMSLog2Hive {
  @transient lazy val logger: Logger = Logger.getLogger(EFSMSLog2Hive.getClass)

  val calPartition = 5000
  val savePartition = 300
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    start
  }

  def start(): Unit = {
   val spark = Spark.getSparkSession(appName)

    val totalDays = 1
    for (i <- 1 to totalDays) {
      val logDays: Int = -i
      val incDay: String = DateUtil.dateDelta(logDays, "")
      val sepDay: String = DateUtil.dateDelta(logDays, "-")
      val date = incDay
      println(date, sepDay)
      run(spark, date, sepDay)
    }
  }

  def run(spark:SparkSession,partitionDay:String,sepDay:String): Unit ={
    val querySourceSql =
      """select get_json_object(logs,"$.message")
        | from dm_gis.ods_kafka_gis_ass_efsms_bee_logs
        | where inc_day =""".stripMargin

    //substring(logs,instr(logs,"{"))

    logger.error(querySourceSql + s"'$partitionDay'")
    val querySourceDF= spark.sql(querySourceSql + s"'$partitionDay'").persist(StorageLevel.DISK_ONLY)

    logger.error("查询原始数据共："+querySourceDF.count())

    //解析log json 成EFSMSLog类型，并返回(sn:String,EFSMSLog)的数据
    //val efsmsLogRDD = getEfsmsLogRDDFromDS(querySourceDS)
    val efsmsLogRDD = getEfsmsLogRDDFromDF(querySourceDF):RDD[(String,EFSMSLog)]
    logger.error("数量："+efsmsLogRDD.count())
    querySourceDF.unpersist()


    //按sn相同分组后合并成一个EFSMSLog
    val totalEFSMSLogRDD = getTotalEFSMSLogRDD(efsmsLogRDD)

    //totalEFSMSLogRDD.collect().foreach(println)

    logger.error(">>>>清洗数据："+totalEFSMSLogRDD.count()+"条<<<<\n"+totalEFSMSLogRDD.take(2).toList.toString())
    totalEFSMSLogRDD.unpersist()
    saveResult(spark,totalEFSMSLogRDD,partitionDay)
    efsmsLogRDD.unpersist()
  }

  def getTotalEFSMSLogRDD(efsmsLogRDD:RDD[(String,EFSMSLog)]): RDD[EFSMSLog] ={
    /*val totalEFSMSLogRDD = efsmsLogRDD.groupByKey().map(one =>{
      val efsmsLog = new EFSMSLog()
      one._2.foreach(obj =>{
        getTotalEFSMSLog(obj,efsmsLog)
      })

      efsmsLog.setType(one._2.toList.length.toString)
    }).persist(StorageLevel.DISK_ONLY)*/

    val totalEFSMSLogRDD = efsmsLogRDD.reduceByKey( (obj1,obj2) =>{
      getTotalEFSMSLog(obj2,obj1)
    }).values.persist(StorageLevel.DISK_ONLY)

    totalEFSMSLogRDD
  }


  def getTotalEFSMSLog(objSR:EFSMSLog,objDest:EFSMSLog): EFSMSLog ={
    objSR.getType match{
      case "url_s" => objDest.setDateTime(objSR.getDateTime).setSn(objSR.getSn).setUrl_s(objSR.getUrl_s)
      case "url_e" => objDest.setUrl_e(objSR.getUrl_e).setCity_code(objSR.getCity_code).setAddress(objSR.getAddress)
          .setSys_type(objSR.getSys_type).setData(objSR.getData).setSrc(objSR.getSrc).setCode(objSR.getCode).setChname(objSR.getChname)
          .setLevel(objSR.getLevel).setRemarks(objSR.getRemarks)
      case "white" => objDest.setUrl_white(objSR.getUrl_white)
      case "geo" => objDest.setUrl_geo(objSR.getUrl_geo)
      case "tc" => objDest.setUrl_tc(objSR.getUrl_tc)
      case "efsdb" => objDest.setUrl_efsdb(objSR.getUrl_efsdb)
      case "other" => objDest.setUrl_other(objSR.getUrl_other)
    }

    objDest
  }

  //数据源为本地文件,解析log后返回成(String,EFSMSLog)格式的rdd
  def getEfsmsLogRDDFromDS(querySourceDS:Dataset[String]): RDD[(String,EFSMSLog)] ={
    val efsmsLogRDD = querySourceDS.rdd.repartition(calPartition).map(obj =>{
      val efsmsLog = new EFSMSLog()
      var jo =new JSONObject()
      try{
        jo=JSON.parseObject(obj)
        SetUrlTypeJson(getJsonObject(jo,"type"),jo,efsmsLog,obj)
      }catch {
        case e: Exception => logger.error(e+s"\n>>>解析json异常1<<<\n$obj")
          (null,null)
      }

      (getJsonObject(jo,"sn"),efsmsLog)
    }).filter(obj => obj._1 !=null &&  obj._1 !="" && obj._2 != null).persist(StorageLevel.DISK_ONLY)

    efsmsLogRDD
  }

  //数据源为hive,解析log后返回成(String,EFSMSLog)格式的rdd
  def getEfsmsLogRDDFromDF(querySourceDF:DataFrame): RDD[(String,EFSMSLog)] ={
    val efsmsLogRDD = querySourceDF.rdd.repartition(calPartition).map(obj =>{
      val efsmsLog = new EFSMSLog()
      var jo =new JSONObject()
      try{
        jo =JSON.parseObject(obj.getString(0))
        SetUrlTypeJson(getJsonObject(jo,"type"),jo,efsmsLog,obj.getString(0))
      }catch {
        case e: Exception => logger.error(e+s"\n>>>解析json异常1<<<\n$obj")
          (null,null)
      }

      (getJsonObject(jo,"sn"),efsmsLog)
    }).filter(obj => obj._1 !=null &&  obj._1 !="" && obj._2 != null).persist(StorageLevel.DISK_ONLY)

    efsmsLogRDD
  }

  //根据log中的type类型匹配设置不同参数
  def SetUrlTypeJson(urlType: String,jo: JSONObject,efsmsLog:EFSMSLog,log:String): EFSMSLog ={
    urlType match {
      case "url_s" => efsmsLog.setType("url_s").setDateTime(getJsonObject(jo,"dateTime")).setSn(getJsonObject(jo,"sn")).setUrl_s(log)
      case "url_e" => efsmsLog.setType("url_e").setUrl_e(log).setCity_code(getJsonObject(jo,("url","city_code"))).setAddress(getJsonObject(jo,("url","address")))
        .setSys_type(getJsonObject(jo,("url","sys_type"))).setData(getJsonObject(jo,"data")).setSrc(getJsonObject(jo,("data","result","src")))
        .setCode(getJsonObject(jo,("data","result","map_data","code",log))).setChname(getJsonObject(jo,("data","result","map_data","chname",log))).setLevel(getJsonObject(jo,("data","result","map_data","level",log)))
        .setRemarks(getJsonObject(jo,("data","result","map_data","remarks",log)))
      case "white" => efsmsLog.setType("white").setUrl_white(log)
      case "geo" => efsmsLog.setType("geo").setUrl_geo(log)
      case "tc" => efsmsLog.setType("tc").setUrl_tc(log)
      case "efsdb" => efsmsLog.setType("efsdb").setUrl_efsdb(log)
      case _ => efsmsLog.setType("other").setUrl_other(log)
    }
     efsmsLog
  }

  //按不同参数解析json
  def getJsonObject(jo: JSONObject,obj: Object): String = {
    try{
      obj match {
        case x:String =>
          jo.getString(s"$x")
        case (x:String, y:String) =>
          jo.getJSONObject(s"$x").getString(s"$y")
        case (x:String, y:String, z:String) =>
          jo.getJSONObject(s"$x").getJSONObject(s"$y").getString(s"$z")
        case (x:String, y:String, z:String, h:String,log:String) =>
          jo.getJSONObject(s"$x").getJSONObject(s"$y").getJSONArray(s"$z").getJSONObject(0).getString(s"$h")
      }
    }catch {
      case e: Exception => logger.error(e+s"\n>>>解析json异常2<<<\n$obj")
        ""
    }
  }
  //入库到hive中
  def saveResult(spark: SparkSession, efsmsLogRDD: RDD[EFSMSLog], date: String): Unit = {
    logger.error(">>>开始入库...<<<")
    val saveTable= "GIS_ASS_EFSMS_BEE_LOGS"

    val addParSql = s"alter table dm_gis.$saveTable add if not exists partition(inc_day='$date')"
    spark.sql(addParSql)

    val path = s"/user/hive/warehouse/dm_gis.db/$saveTable/inc_day=$date"

    logger.error(path)

    ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R /user/hive/warehouse/dm_gis.db/%s/inc_day=%s", saveTable, date))

    efsmsLogRDD.repartition(savePartition).map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getDateTime).append("\t")
      sb.append(obj.getSn).append("\t")
      sb.append(obj.getUrl_s).append("\t")
      sb.append(obj.getUrl_e).append("\t")
      sb.append(obj.getUrl_white).append("\t")
      sb.append(obj.getUrl_geo).append("\t")
      sb.append(obj.getUrl_tc).append("\t")
      sb.append(obj.getUrl_efsdb).append("\t")
      sb.append(obj.getUrl_other).append("\t")
      sb.append(obj.getCity_code).append("\t")
      sb.append(obj.getAddress).append("\t")
      sb.append(obj.getSys_type).append("\t")
      sb.append(obj.getData).append("\t")
      sb.append(obj.getSrc).append("\t")
      sb.append(obj.getCode).append("\t")
      sb.append(obj.getChname).append("\t")
      sb.append(obj.getLevel).append("\t")
      sb.append(obj.getRemarks)

      sb.toString()
    }).saveAsTextFile(path)

    val addSql =  s"""LOAD DATA INPATH '$path' INTO TABLE dm_gis.$saveTable PARTITION (inc_day='${date}')""";
    logger.error(addSql)
    spark.sql(addSql)
  }
}
