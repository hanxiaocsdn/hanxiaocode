package com.sf.gis.scala.seg.app

import java.io.InputStreamReader
import java.net.URLEncoder
import java.time.{Duration, Instant}
import java.util
import org.apache.commons.csv.CSVFormat
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.SaveResultUtil
import com.sf.gis.scala.seg.bean.Waybill
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.{HashMap, Set}
import scala.io.Source

/*地址聚价值折算需求:
* Step1 新增基础数据：
惠州、东莞相同小哥的业务数据（详见之前邮件）
à 张磊      5/21(本周四)完成
Step2漏单率计算：
基于惠州、东莞的基础数据进行遗漏率计算 （具体到每个小哥身上）
à GIS   待排期（依赖项：Step1）
Step3路程计算：
将有漏单率的数据筛选出来，计算每个小哥的折返路程
à GIS   待排期（依赖项：Step1/Step2）
Step4 速度获取：
获取小哥工号对应的交通工具及其默认速度信息
à 徐美婴    时间待定（依赖项：Step3）
Step5 节省时间计算：
根据折返路程及其速度计算每个小哥的节省时间
à GIS    时间待定（依赖项：Step4）
Step6 节省时间换算为节省成本：
按小哥每天工作10小时、一个月工作26天、月薪8000元来换算成本
à GIS    时间待定（依赖项：Step5）
* */

/*
* 提供数据相应sql：
* 1.提供所有的小哥节省时间和成本数据（按地区，日期分组）
  select * from dm_gis.Address_Agg_value_SaveTimeCost

* 2.提供按城市 日期 小哥分组的总量、漏单总量、漏单率
  select * from Address_Agg_value_Conversion_LostBill

* * 3.提供城市的漏单率
  select city,`date`,sum(billamount),sum(lostbillamount), sum(lostbillamount)/ sum(billamount) from dm_gis.Address_Agg_value_Conversion_LostBill  group by `date`,city

* * 4.提供按城市 小哥分组的总量、漏单总量、漏单率，平均漏单率
  select city,empcode,sum(billamount),sum(lostbillamount),sum(lostbillamount)/ sum(billamount) from dm_gis.Address_Agg_value_Conversion_LostBill  group by city,empcode

* * 5.查询表重小哥前后两个月的天数
  select temp1.empcode,(temp1.cnt - temp2.cnt)
  from(
      select empcode,substring(`date`, 0, 6) as dt,count(1) as cnt
      from  dm_gis.Address_Agg_value_Conversion_LostBill
      where inc_day = '20200608'
      group by  empcode,substring(`date`, 0, 6)) temp1
  join (select empcode,substring(`date`, 0, 6) as dt,count(1) as cnt
        from  dm_gis.Address_Agg_value_Conversion_LostBill
        where inc_day = '20200608'
        group by  empcode,substring(`date`, 0, 6)) temp2
  on temp1.empcode = temp2.empcode
  where temp1.dt = '202004'
    and temp2.dt = '201908';

* 6.提供小哥,201908,202006的 日平均漏单率
  select tmp1.empcode,tmp1.avgPer,tmp2.avgPer from
  (
    select empcode,substring(`date`, 0, 6) dt,avg(lostbillper) avgPer
      from dm_gis.Address_Agg_value_Conversion_LostBill
      where inc_day='20200608' group by empcode,substring(`date`, 0, 6)
  ) tmp1
  join
  (
    select empcode,substring(`date`, 0, 6) dt,avg(lostbillper) avgPer
      from dm_gis.Address_Agg_value_Conversion_LostBill
      where inc_day='20200608' group by empcode,substring(`date`, 0, 6)
  ) tmp2
  on tmp1.empcode = tmp2.empcode
  and tmp1.dt='201908' and tmp2.dt='202004'

  * 7.提供小哥日平均路程
  select
  tmp1.empcode ,
  tmp1.cnt as cmt_08,
  tmp2.cnt as cmt_04,
  tmp1.totalDist astotalDist_08,
  tmp2.totalDist astotalDist_04,
  tmp1.totalDist / tmp1.cnt as avgDist_08,
  tmp2.totalDist / tmp2.cnt as avgDist_04,
  tmp1.totalSavetime/ tmp1.cnt as avgSavetime_08,
  tmp2.totalSavetime / tmp2.cnt as avgSavetime_04,
  tmp1.totalcutcosts/ tmp1.cnt as avgCutcosts_08,
  tmp2.totalcutcosts / tmp2.cnt as avgCutcosts_04
from
  (
    select
      empcode,
      count(distinct `date`) as cnt,
      sum(dist)/1000 totalDist,
      sum(savetime) totalSavetime,
      sum(cutcosts) totalcutcosts
    from
      dm_gis.Address_Agg_value_SaveTimeCost
    where
      inc_day = '20200608' and substring(`date`, 0, 6)='201908'
    group by
      empcode
  ) tmp1
  join (
    select
      empcode,
      count(distinct `date`) as cnt,
      sum(dist)/1000 totalDist,
      sum(savetime) totalSavetime,
      sum(cutcosts) totalcutcosts
    from
      dm_gis.Address_Agg_value_SaveTimeCost
    where
      inc_day = '20200608' and substring(`date`, 0, 6)='202004'
    group by
      empcode
  ) tmp2 on tmp1.empcode = tmp2.empcode
*/

object AddressAggregationValueConversion {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  //地址聚合服务接口
  val addAggUrl = "http://gis-int2.int.sfdc.com.cn:1080/agg/api/AddressAggregation?address=%s&citycode=%s&level=13&ak=11fbd8a3b26545fa9df84ded1f3debb3"
  //常规骑行服务
  val rpUrl = "http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&opt=sf1&type=1&strategy=0&ak=8bb09e5e110845f39a000391668e3e80"

  val empcodeSpeedPath = "小哥交通工具默认速度.csv"
  val saveLostBillTable= "Address_Agg_value_Conversion_LostBill"
  val saveTimeCostTable = "Address_Agg_value_SaveTimeCost"
  val parDate = "20200608"

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)

    //flag=0 计算漏单率，入库且计算时间成本；flag=1 只计算楼漏单率且入库；flag=2 不计算漏单率，只计算时间成本
    val flag = if (args.length == 0) "0" else args(0)


    if (flag == "0" || flag == "1" || flag == "2") {
      val rdd = getData(spark)

      if (flag == "1")
      //计算漏单率入库
      calculateMissedOrders(rdd,spark)

      if (flag == "2")
      //计算时间成本
      calculateSaveTimeCosts(rdd,spark)

      if (flag == "0"){
        //计算漏单率
        calculateSaveTimeCosts(rdd,spark)
        //计算时间成本
        calculateSaveTimeCosts(rdd,spark)
      }
    }else{
      logger.error("请输入正确参数如：0,1,2")
    }

    /*    //筛选漏单率大于0的小哥工号(后面决定不用根据漏单率大于0来过滤，计算路程)
    val empSet = getEmpList(spark,lostBillSaveRDD)

    lostBillSaveRDD.unpersist()

    //获取漏单率大于0的数据
    val empListRDD = rdd.filter(obj => empSet.contains(obj.getCouriercode)).persist(StorageLevel.MEMORY_AND_DISK)*/

  }

  val saveLostBill = (saveRDD:RDD[JSONObject],path:String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("城市")).append("\t")
      sb.append(obj.getString("日期")).append("\t")
      sb.append(obj.getString("小哥")).append("\t")
      sb.append(obj.getString("总量")).append("\t")
      sb.append(obj.getString("漏单总量")).append("\t")
      sb.append(obj.getString("漏单率"))

      sb.toString()
    }).saveAsTextFile(path)
  }

  val getSpeed = (transportation:String) => transportation match {
    case "步行" => 4
    case "自行车" => 10
    case _ if transportation.contains("电动车")  => 15
    case _ if transportation.contains("摩托车")  => 20
    case _ if transportation.contains("汽车") => 30
    case _ => 0
  }

  val saveTimeCost = (saveRDD:RDD[JSONObject],path:String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("cityCode")).append("\t")
      sb.append(obj.getString("date")).append("\t")
      sb.append(obj.getString("empCode")).append("\t")
      sb.append(obj.getString("dist")).append("\t")
      sb.append(obj.getString("saveTime")).append("\t")
      sb.append(obj.getString("cutCosts"))

      sb.toString()
    }).saveAsTextFile(path)
  }

  def calculateSaveTimeCosts(rdd:RDD[Waybill],spark:SparkSession){
    //调用常规骑行接口,计算小哥折返路程
    val returnJourneyRDD = getReturnJourney(rdd)

    rdd.unpersist()

    //映射交通工具默认速度
    val speedMap = getSpeedMap(spark)

    //计算节省时间和节省成本
    val saveTimeCostRDD = getSaveRDD(returnJourneyRDD,speedMap)

    //入库到hive
    SaveResultUtil.saveResult(logger,spark,saveTimeCostRDD,saveTimeCost,saveTimeCostTable,parDate)
  }

  def calculateMissedOrders(rdd:RDD[Waybill],spark:SparkSession)={
    val resultRdd = getKeyword(rdd).persist(StorageLevel.MEMORY_AND_DISK)

    //val (lostBillSaveRDD,lostBillByCitySaveRDD) = keywordStat(resultRdd)
    val lostBillSaveRDD = keywordStat(resultRdd)

    //入库到hive
    SaveResultUtil.saveResult(logger,spark,lostBillSaveRDD,saveLostBill,saveLostBillTable,parDate)

    //Util.saveResult(spark,lostBillByCitySaveRDD,saveLostBill,saveLostBillTable,parDate)
    //lostBillByCitySaveRDD.unpersist()

    lostBillSaveRDD
  }

  def getData(sparkSession: SparkSession)= {

    val table = "dm_tdos.application_gis_way_info"
    /*val sql=s"""select
                waybillno,
                80_userid,
                80_user_dept,
                80_operatime_new,
                consignee_addr,
                80_lng,
                80_lat,
                204_lng,
                204_lat
               from $table
               where inc_day = '$parDate'
                and consignee_addr is not null
                and consignee_addr<>'null'
                and consignee_addr<>'' """.stripMargin*/
    //and 80_app_code='unite'
    //and 80_userid in ('40291810','40425241','01223427','40581114','40037970','478361','40490044','273703')

    //计算
    val sql =
      s"""
        select
          waybillno,
          80_userid,
          80_user_dept,
          80_operatime_new,
          consignee_addr,
          80_lng,
          80_lat,
          204_lng,
          204_lat
        from $table
        where inc_day = '$parDate'
          and consignee_addr is not null
          and consignee_addr<>'null'
          and consignee_addr<>''
          and 80_userid in ('354','5339','5400','1040680','1056704','1059318','1080461','1082249',
                            '1082465','1082560','1089538','1090878','1093984','1099874','1100243',
                            '1101185','1105541','1130164','1136223','1138011','11530','1153161',
                            '1161016','1165139','1176178','1198906','1199383','1200423','1203586',
                            '1203966','1210429','1227171','1229099','12549','1319302','1326868',
                            '1326880','1328081','1349258','1352615','1355350','1358173','13622',
                            '1366106','22297','35859','55303','63111','80205','92374','93124',
                            '97308','125188','129121','129375','130024','131278','136515',
                            '136564','146122','146437','165314','186460','197024','201007',
                            '212676','225393','248727','251313','278879','302591','316385',
                            '322918','339763','344581','350173','361303','367723','368321',
                            '387446','40013585','40015022','40022027','40039270','40040387',
                            '40047766','40049230','40057354','40076303','40082792','40083479',
                            '40086500','40097376','40112632','40113267','40114430','40114714',
                            '40116014','40190349','40214272','40221194','40226245','40239425',
                            '40241412','40243515','40246850','40248431','40248651','40263481',
                            '40270120','40270124','40291150','40291841','40293736','40296531',
                            '40297156','40298792','40310866','40318836','40321642','40323076',
                            '40328553','40328905','40339738','40343893','40355668','40356611',
                            '40366938','40376978','40376980','40378641','40384767','40399767',
                            '40412741','40423432','40425241','40427564','40429446','404601',
                            '40463401','40485173','40500208','40525547','40528806','40530752',
                            '40532810','40538107','40551559','40565557','40568318','40568952',
                            '40570242','40571415','40575289','40576488','40577876','40578074',
                            '40587632','40588158','40590224','40590782','40593661','40598000',
                            '40598591','40605422','40606773','40611464','40627209','40631140',
                            '40643869','40646648','40653153','40659283','414450','441969','447828',
                            '478361','483631','484366','487149','529245','567489','577702','580882',
                            '642357','653208','664733','682650','691966','697162','698056','700007',
                            '700388','708394','721831','722393','736711','774846','782576','785351',
                            '803899','820004','822559','832700','845562','850295','851825','857752','865651','880716','885382')
      """.stripMargin

    val rdd = sparkSession.sql(sql).rdd.map(row => {
      val waybill = new Waybill
      waybill.setWaybillno(row.getString(0))
      waybill.setCouriercode(row.getString(1))
      waybill.setZonecode(row.getString(2))
      waybill.setTimeps(row.getString(3))
      waybill.setConsigneeaddr(row.getString(4))
      waybill.setLongitude(row.getString(5))
      waybill.setLatitude(row.getString(6))
      waybill.setCitycode(row.getString(2).substring(0, 3))
      waybill.setIncday(row.getString(3).substring(0, 10).replaceAll("-", ""))
      waybill.setKeyword("")
      waybill.setAoiid("")
      waybill.setStatus(1)
      waybill.setLongitude_s(row.getString(7))
      waybill.setLatitude_s(row.getString(8))

      waybill
    }).repartition(200).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error(s"共获取数据：${rdd.count()}")

    rdd
  }

  def getKeyword(rdd: RDD[Waybill]): RDD[Waybill] = {
    logger.error("开始查询接口")

    val result = getAggregationAddr(rdd)
    val successRdd = result.filter(waybill => waybill.getStatus == 0).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("成功数据量:" + successRdd.count())
    rdd.unpersist()
    successRdd
  }

  //调用接口获取地址聚合结果
  def getAggregationAddr(rdd: RDD[Waybill]): RDD[Waybill] = {
    rdd.map(waybill => {
      var keyWord = ""
      var aoiid = ""
      var status = 1

      if (StringUtils.isNotBlank(waybill.getConsigneeaddr)) {
        val query = String.format(addAggUrl, URLEncoder.encode(waybill.getConsigneeaddr, "utf-8"), waybill.getCitycode)
        val resp = Source.fromURL(query, "utf-8").mkString

        logger.error(resp)
        val json = JSON.parseObject(resp)
        status = json.getInteger("status")

        if (status == 0) {
          val data = json.getJSONObject("result").getJSONObject("data")
          if (data != null) {
            if (data.getString("key_word") != null) {
              keyWord = data.getString("key_word")
            }
            if (data.getString("aoi_id") != null) {
              aoiid = data.getString("aoi_id")
            }
          }
        }
      }

      waybill.setKeyword(keyWord)
      waybill.setAoiid(aoiid)
      waybill.setStatus(status)

      waybill
    })
  }

  def keywordStat(resultRdd:RDD[Waybill])= {

    val rdd = resultRdd.filter(obj => StringUtils.isNotBlank(obj.getKeyword))
      .map(obj => {
        ((obj.getCitycode, obj.getIncday, obj.getCouriercode), obj)
      }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("查询数据量:" + rdd.count())
    val start = Instant.now()

    val result = rdd.groupByKey().map(key => {
      val list = key._2.toList.sortBy(el => (el.getTimeps, el.getKeyword))
      var cnt = 0
      val map = new util.HashMap[String, Integer]()

      for (waybill <- list) {
        if (map.get(waybill.getKeyword) == null) {
          cnt += 1
          map.put(waybill.getKeyword, cnt)
        }
      }

      val set = new util.HashSet[String]()
      val timeSet = new util.HashSet[String]()
      var aggAddr = ""
      var aggAoi = ""
      var num = 0
      var max = 0

      for (waybill <- list) {
        timeSet.add(waybill.getTimeps)
        val next = (waybill.getKeyword.equals(aggAddr) && !"****".equals(waybill.getKeyword)) || ("****".equals(aggAddr) && aggAoi.equals(waybill.getAoiid))
        if (next) {
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        } else {
          set.add(waybill.getKeyword)
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        }
        if (map.get(waybill.getKeyword) > max) {
          max = map.get(waybill.getKeyword)
        }
        aggAddr = waybill.getKeyword
        aggAoi = waybill.getAoiid
      }

      (key._1, list.size, num,(num.toDouble/list.size).formatted("%.4f"))
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("计算漏单情况:")
    logger.error("计算城市 日期 小哥|总量|漏单总量|漏单率")

    val lostBillSaveRDD = result.map(obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("城市",obj._1._1)
      jsonObj.put("日期",obj._1._2)
      jsonObj.put("小哥",obj._1._3)
      jsonObj.put("总量",obj._2)
      jsonObj.put("漏单总量",obj._3)
      jsonObj.put("漏单率",obj._4)

      jsonObj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("城市 日期 小哥分组共：" +lostBillSaveRDD.count())

    /* logger.error("计算 城市 日期 |总量|漏单总量|漏单率")

     val lostBillByCitySaveRDD= result.groupBy(obj=> (obj._1._1,obj._1._2)).map(obj => {
       val total = obj._2.map(obj =>obj._2).sum
       val lostTotal = obj._2.map(obj =>obj._3).sum

       val per = (lostTotal / (total + 0.0)).formatted("%.4f")

       val jsonObj = new JSONObject()
       jsonObj.put("城市",obj._1._1)
       jsonObj.put("日期",obj._1._2)
       jsonObj.put("小哥","999999999")
       jsonObj.put("总量",total)
       jsonObj.put("漏单总量",lostTotal)
       jsonObj.put("漏单率",per)

       jsonObj

       //logger.error( obj._1._1 + " " + obj._1._2 + " " + total + " " + lostTotal + " " + per )
     }).repartition(50)

     logger.error("城市 日期分组共：" +lostBillByCitySaveRDD.count())*/

    val end = Instant.now()
    logger.error("统计耗时:" + Duration.between(start, end).getSeconds + "s")

    //(lostBillSaveRDD,lostBillByCitySaveRDD)
    lostBillSaveRDD
  }

  def getEmpList(spark:SparkSession,lostBillSaveRDD:RDD[JSONObject]):Set[String] ={
    logger.error("开始筛选漏单的小哥工号")
    val empSet: Set[String] = Set()
    lostBillSaveRDD.collect().foreach(obj => {

      if(obj.getString("漏单率").toDouble > 0d) {
        empSet.add(obj.getString("小哥"))
      }

    })

    spark.sparkContext.broadcast(empSet)
    logger.error("empList的大小为："+empSet.size)

    empSet
  }

  def getReturnJourney(empListRDD:RDD[Waybill])={
    logger.error("计算行程开始")

    val returnJourneyRDD = empListRDD.map(obj =>{
      val e_lat = obj.getLatitude
      val s_lat = obj.getLatitude_s
      val e_lng = obj.getLongitude
      val s_lng = obj.getLongitude_s

      val query = String.format(rpUrl,e_lng, e_lat, s_lng,s_lat)

      //调用骑行服务接口
      var resp = ""
      var json = new JSONObject()

      try{
        resp = Source.fromURL(query, "utf-8").mkString
        json = JSON.parseObject(resp)
      } catch {
        case e:Exception => logger.error(e)
          resp = Source.fromURL(query, "utf-8").mkString
          json = JSON.parseObject(resp)
      }

      val status = json.getInteger("status")
      var dist = 0d

      if (status == 0) {
        val distString = json.getJSONObject("result").getString("dist")
        if (StringUtils.isNotBlank(distString) )
          dist = distString.toDouble
      }

      logger.error(resp)

      ((obj.getCitycode,obj.getIncday,obj.getCouriercode),(status,dist,resp))
    }).filter(obj => obj._2._1 == 0).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("获取有效行程个数：" +  returnJourneyRDD.count)

    returnJourneyRDD
  }

  def getSpeedMap(spark: SparkSession) ={
    logger.error("计算交通工具映射速度开始")

    val speedMap = HashMap[String,Int]()

    val in = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream(empcodeSpeedPath), "utf-8")

    val records = CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord().parse(in).iterator()
    while (records.hasNext){
      val elem = records.next()
      speedMap.put(elem.get("工号"),getSpeed(elem.get("交通类型")))
    }

    spark.sparkContext.broadcast(speedMap)

    logger.error("speedMap 大小为：" + speedMap.size)

    speedMap
  }

  def getSaveRDD(returnJourneyRDD:  RDD[((String, String, String), (Integer, Double,String))],speedMap: HashMap[String, Int]):RDD[JSONObject]={
    logger.error("计算节省时间&成本开始")

    val saveRDD = returnJourneyRDD.map(obj => {
      val speed = speedMap.getOrElse(obj._1._3,0)
      val dist = obj._2._2

      //dist:m   speed/km/h  saveTime:h  cutCosts:块
      val saveTime = if (speed == 0) 0 else (dist/1000/ speed).formatted("%.4f").toDouble
      val cutCosts = if (saveTime == 0) 0 else (saveTime * (8000d / 26 / 10)).formatted("%.4f").toDouble

      val jsonObj = new JSONObject()
      jsonObj.put("cityCode",obj._1._1)
      jsonObj.put("date",obj._1._2)
      jsonObj.put("empCode",obj._1._3)
      jsonObj.put("dist",dist/1000)
      jsonObj.put("saveTime",saveTime)
      jsonObj.put("cutCosts",cutCosts)

      jsonObj
    })/*.filter(_.getDouble("saveTime") != 0d)*/
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("获取有效节省时间&成本数量："+ saveRDD.count())

    saveRDD
  }
}
