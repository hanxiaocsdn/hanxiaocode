package com.sf.gis.scala.seg.app

import java.net.URLEncoder
import java.time.{Duration, Instant}
import java.util

import com.alibaba.fastjson.JSON
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.seg.bean.Waybill
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.io.Source

/**
 * 王慧珺
 * 地址聚合收益计算
 */
object LostBillStatNew {
  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)

  /*case class Waybill(waybillno: String, couriercode: String, zonecode: String, timeps: String, consigneeaddr: String,
             longitude: String, latitude: String, citycode: String, incday: String, keyword: String, aoiid: String, status: Int)*/

  val url = "http://gis-int2.int.sfdc.com.cn:1080/agg/api/AddressAggregation?address=%s&citycode=%s&level=13&ak=11fbd8a3b26545fa9df84ded1f3debb3"
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    for (arg <- args) {
      logger.error(arg)
    }

    val table = args(0)
    val saveTable = args(1)
    val city = args(2)
    val date = args(3).replaceAll("-", "")
    val partition = args(4).toInt
    val onlystat = args(5).toInt //模式一: 1:跑接口获取聚合地址并保存到hive,再统计	2:只统计	(1已跑)
    // 模式二:3统计
    val percent = args(6).toInt

    val spark = Spark.getSparkSession(appName)

    if (onlystat == 1) {
      val rdd = getData(spark, table, city, date).persist(StorageLevel.MEMORY_AND_DISK)
      logger.error("总数据量:" + rdd.count())
      val resultRdd = getKeyword(rdd, partition)
      save(spark, resultRdd, saveTable, city, date)
      resultRdd.unpersist()
      //统计
      //getKeywordData(spark, saveTable, city, date)
    } else if (onlystat == 2) {
      logger.error("onlystat:" + onlystat)
      keywordStat(spark, saveTable, city, date, percent)
    } else {
      //similarityStat(spark, table, city, date, percent)
    }
    spark.stop()
  }

  /*def similarityStat(sparkSession: SparkSession, table: String, city: String, date: String, percent: Double): Unit = {
    var sql = ""
    /*if ("all".equals(date) || "".equals(date)) {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,longitude,latitude from $table " +
          s"where substr(zone_code,0,3)='$city' and longitude is not null and longitude != -1.0"
    } else {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,longitude,latitude from $table " +
          s"where substr(zone_code,0,3)='$city' and regexp_replace(substr(time_ps,0,10),'-','')='$date' and longitude is not null and longitude != -1.0"
    }*/

    /*if ("all".equals(date) || "".equals(date)) {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,longitude,latitude from $table " +
          s"where city='$city' and status='0' and keyword != ''"
    } else {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,longitude,latitude from $table " +
          s"where city='$city' and incday='$date' and status='0' and keyword != ''"
    }*/
    if ("all".equals(date) || "".equals(date)) {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,eventlng,eventlat from tmp_dm_tdos.cgj_12_26_09_3 " +
        s"where eventlng != '' and eventlng != '0.0'"
    } else {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,longitude,latitude from $table " +
        s"where city='$city' and incday='$date' and status='0' and keyword != ''"
    }
    logger.error(sql)
    val rdd = sparkSession.sql(sql).rdd.map(row => {
      val waybill = new Waybill
      waybill.setWaybillno(row.getString(0))
      waybill.setCouriercode(row.getString(1))
      waybill.setZonecode(row.getString(2))
      waybill.setTimeps(row.getString(3))
      waybill.setConsigneeaddr(row.getString(4))
      waybill.setLongitude(row.getString(5))
      waybill.setLatitude(row.getString(6))
      waybill.setCitycode(waybill.getZonecode.substring(0, 3))
      waybill.setIncday(waybill.getTimeps.substring(0, 10).replaceAll("-", ""))
      waybill.setKeyword("")
      waybill.setAoiid("")
      waybill.setStatus(1)
      val key = String.format("%s_%s", waybill.getIncday, waybill.getCouriercode)
      (key, waybill)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("查询数据量:" + rdd.count())
    val start = Instant.now()
    val resultList = rdd.groupByKey().map(key => {
      val list = key._2.toList.sortBy(_.getTimeps)
      val result = groupBydis(list.to[ListBuffer])
      val sortList = Waybill.sort(result).asScala
      //			val sortList = result.asScala
      var cnt = 0
      val map = new util.HashMap[String, Integer]()
      for (waybill <- sortList) {
        if (map.get(waybill.getKeyword) == null) {
          cnt += 1
          map.put(waybill.getKeyword, cnt)
        }
      }
      val set = new util.HashSet[String]()
      val timeSet = new util.HashSet[String]()
      var aggAddr = ""
      var aggAoi = ""
      var num = 0
      var max = 0
      for (waybill <- sortList) {
        timeSet.add(waybill.getTimeps)
        val next = waybill.getKeyword.equals(aggAddr)
        if (next) {
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        } else {
          set.add(waybill.getKeyword)
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        }
        if (map.get(waybill.getKeyword) > max) {
          max = map.get(waybill.getKeyword)
        }
        aggAddr = waybill.getKeyword
        aggAoi = waybill.getAoiid
      }
      (key._1, sortList.size, timeSet.size(), map.size(), num)
    }).collect()
    rdd.unpersist()

    var total = 0
    var lostTotal = 0
    var size = 0
    var lostSize = 0
    resultList.foreach(el => {
      //println("分组:" + el._1 + "	运单量:" + el._2 + "	时间去重量:" + el._3 + "	keyword去重量" + el._4 + "	漏单量:" + el._5)
      total += el._2
      lostTotal += el._5
      if (el._3 * 1.0 / el._2 >= percent) {
        size += el._2
        lostSize += el._5
      }
    })
    logger.error("keyword非空运单总量:" + total)
    logger.error("漏单总量:" + lostTotal)
    logger.error("漏单率:" + (lostTotal / (total + 0.0)).formatted("%.4f"))
    logger.error("按" + percent + "剔除运单量:" + size)
    logger.error("按" + percent + "剔除漏单量:" + lostSize)
    logger.error("按" + percent + "剔除漏单率:" + (lostSize / (size + 0.0)).formatted("%.4f"))
    val end = Instant.now()
    logger.error("统计耗时:" + Duration.between(start, end).getSeconds + "s")
  }*/

  /*def groupBydis(list: ListBuffer[Waybill]): util.ArrayList[Waybill] = {
    val resultList = new util.ArrayList[Waybill]()
    if (list.nonEmpty) {
      val waybill = list.head
      val otherList = ListBuffer[Waybill]()
      val uuid = UUID.randomUUID.toString.replaceAll("-", "")
      for (el <- list) {
        if (DistanceTool.getGreatCircleDistance(waybill.getLongitude.toDouble, waybill.getLatitude.toDouble,
          el.getLongitude.toDouble, el.getLatitude.toDouble) <= 20) {
          el.setKeyword(uuid)
          resultList.add(el)
        } else {
          otherList += el
        }
      }
      resultList.addAll(groupBydis(otherList))
    }
    resultList
  }*/


  def keywordStat(sparkSession: SparkSession, table: String, city: String, date: String, percent: Double): Unit = {
    var sql: String = ""
    if ("all".equals(date) || "".equals(date)) {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,longitude,latitude,citycode,inc_day,keyword,aoiid from dm_gis.$table " +
        s"where city='$city' and status='0' and keyword != ''"
    } else {
      sql = s"select waybillno,couriercode,zone_code,time_ps,consignee_addr,longitude,latitude,citycode,inc_day,keyword,aoiid from dm_gis.$table " +
        s"where city='$city' and incday='$date' and status='0' and keyword != ''"
    }
    logger.error(sql)
    val rdd = sparkSession.sql(sql).rdd.map(row => {
      val waybill = new Waybill
      waybill.setWaybillno(row.getString(0))
      waybill.setCouriercode(row.getString(1))
      waybill.setZonecode(row.getString(2))
      waybill.setTimeps(row.getString(3))
      waybill.setConsigneeaddr(row.getString(4))
      waybill.setLongitude(row.getString(5))
      waybill.setLatitude(row.getString(6))
      waybill.setCitycode(row.getString(7))
      waybill.setIncday(row.getString(8))
      waybill.setKeyword(row.getString(9))
      waybill.setAoiid(row.getString(10))
      waybill.setStatus(0)
      val key = String.format("%s_%s_%s", waybill.getCitycode, waybill.getIncday, waybill.getCouriercode)
      (key, waybill)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("查询数据量:" + rdd.count())
    val start = Instant.now()
    val result = rdd.groupByKey().map(key => {
      val list = key._2.toList.sortBy(el => (el.getTimeps, el.getKeyword))
      var cnt = 0
      val map = new util.HashMap[String, Integer]()
      for (waybill <- list) {
        if (map.get(waybill.getKeyword) == null) {
          cnt += 1
          map.put(waybill.getKeyword, cnt)
        }
      }
      val set = new util.HashSet[String]()
      val timeSet = new util.HashSet[String]()
      var aggAddr = ""
      var aggAoi = ""
      var num = 0
      var max = 0
      for (waybill <- list) {
        timeSet.add(waybill.getTimeps)
        val next = (waybill.getKeyword.equals(aggAddr) && !"****".equals(waybill.getKeyword)) || ("****".equals(aggAddr) && aggAoi.equals(waybill.getAoiid))
        if (next) {
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        } else {
          set.add(waybill.getKeyword)
          if (set.contains(waybill.getKeyword) && map.get(waybill.getKeyword) < max) {
            num += 1
          }
        }
        if (map.get(waybill.getKeyword) > max) {
          max = map.get(waybill.getKeyword)
        }
        aggAddr = waybill.getKeyword
        aggAoi = waybill.getAoiid
      }
      (key._1, list.size, timeSet.size(), map.size(), num)
    }).collect()
    rdd.unpersist()
    logger.error("打印小哥的漏单情况:")
    logger.error("城市_日期_小哥|总量|漏单总量|漏单率|剔除运单量|剔除漏单量|剔除漏单率")
    result.foreach(obj => {
      val total = obj._2
      val lostTotal = obj._5
      var size = 0
      var lostSize = 0
      if (obj._3 / (obj._2 + 0.0) >= percent) {
        size += obj._2
        lostSize += obj._5
      }
      val per = (lostTotal / (total + 0.0)).formatted("%.4f")
      val lostPer = (lostSize / (size + 0.0)).formatted("%.4f")
      logger.error(obj._1 + "|" + total + "|" + lostTotal + "|" + per +
        "|" + size + "|" + lostSize + "|" + lostPer)
    })
    var total = 0
    var lostTotal = 0
    var size = 0
    var lostSize = 0
    result.foreach(el => {
      //println("分组:" + el._1 + "	运单量:" + el._2 + "	时间去重量:" + el._3 + "	keyword去重量" + el._4 + "	漏单量:" + el._5)
      total += el._2
      lostTotal += el._5
      if (el._3 / (el._2 + 0.0) >= percent) {
        size += el._2
        lostSize += el._5
      }
    })
    logger.error("keyword非空运单总量:" + total)
    logger.error("漏单总量:" + lostTotal)
    logger.error("漏单率:" + (lostTotal / (total + 0.0)).formatted("%.4f"))
    logger.error("按" + percent + "剔除运单量:" + size)
    logger.error("按" + percent + "剔除漏单量:" + lostSize)
    logger.error("按" + percent + "剔除漏单率:" + (lostSize / (size + 0.0)).formatted("%.4f"))
    val end = Instant.now()
    logger.error("统计耗时:" + Duration.between(start, end).getSeconds + "s")
  }

  def getData(sparkSession: SparkSession, table: String, city: String, date: String): RDD[Waybill] = {
    var sql: String = ""
    if ("all".equals(date) || "".equals(date)) {
      sql = s"select waybillno,80_userid,80_user_dept,80_operatime_new,consignee_addr,'' 80_lng,'' latitude from $table where substr(80_user_dept,0,3)='$city' and 80_app_code='unite' " +
        s" and consignee_addr is not null and consignee_addr<>'null' and consignee_addr<>'' "
    } else {
      sql = s"select waybillno,80_userid,80_user_dept,80_operatime_new,consignee_addr,'' 80_lng,'' latitude from $table where substr(80_user_dept,0,3)='$city' and 80_app_code='unite' " +
        s" and consignee_addr is not null and consignee_addr<>'null' and consignee_addr<>'' " +
        s" and regexp_replace(substr(time_ps,0,10),'-','')='$date'"
    }
    logger.error(sql)
    sparkSession.sql(sql).rdd.map(row => {
      val waybill = new Waybill
      waybill.setWaybillno(row.getString(0))
      waybill.setCouriercode(row.getString(1))
      waybill.setZonecode(row.getString(2))
      waybill.setTimeps(row.getString(3))
      waybill.setConsigneeaddr(row.getString(4))
      waybill.setLongitude(row.getString(5))
      waybill.setLatitude(row.getString(6))
      waybill.setCitycode(row.getString(2).substring(0, 3))
      waybill.setIncday(row.getString(3).substring(0, 10).replaceAll("-", ""))
      waybill.setKeyword("")
      waybill.setAoiid("")
      waybill.setStatus(1)
      waybill
    }).repartition(1200)
  }

  def getKeyword(rdd: RDD[Waybill], partition: Int): RDD[Waybill] = {
    logger.error("开始查询接口")
    val start = Instant.now()
    val result = getAggregationAddr(rdd)
    val successRdd = result.filter(waybill => waybill.getStatus == 0).persist(StorageLevel.MEMORY_AND_DISK)
    val failedRdd = result.filter(waybill => waybill.getStatus == 1).repartition(10).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("成功数据量:" + successRdd.count())
    logger.error("失败数据量:" + failedRdd.count())
    rdd.unpersist()
    logger.error("===try again===")
    var end = Instant.now()
    logger.error("耗时:" + Duration.between(start, end).getSeconds + "s")
    val lastRdd = getAggregationAddr(failedRdd).persist(StorageLevel.MEMORY_AND_DISK)
    failedRdd.unpersist()
    logger.error("成功数据量:" + lastRdd.filter(waybill => waybill.getStatus == 0).count())
    logger.error("失败数据量:" + lastRdd.filter(waybill => waybill.getStatus == 1).count())
    end = Instant.now()
    logger.error("耗时:" + Duration.between(start, end).getSeconds + "s")
    val endRdd = successRdd.union(lastRdd).repartition(partition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("总数据量:" + endRdd.count())
    successRdd.unpersist()
    lastRdd.unpersist()
    endRdd
  }

  def getAggregationAddr(rdd: RDD[Waybill]): RDD[Waybill] = {
    rdd.map(waybill => {
      var keyWord = ""
      var aoiid = ""
      var status = 1
      if (StringUtils.isNotBlank(waybill.getConsigneeaddr)) {
        val query = String.format(url, URLEncoder.encode(waybill.getConsigneeaddr, "utf-8"), waybill.getCitycode)
        val resp = Source.fromURL(query, "utf-8").mkString
        logger.error(resp)
        val json = JSON.parseObject(resp)
        status = json.getInteger("status")
        if (status == 0) {
          val data = json.getJSONObject("result").getJSONObject("data")
          if (data != null) {
            if (data.getString("key_word") != null) {
              keyWord = data.getString("key_word")
            }
            if (data.getString("aoi_id") != null) {
              aoiid = data.getString("aoi_id")
            }
          }
        }
      }
      waybill.setKeyword(keyWord)
      waybill.setAoiid(aoiid)
      waybill.setStatus(status)
      waybill
    })
  }

  def save(sparkSession: SparkSession, resultRdd: RDD[Waybill], saveTable: String, city: String, date: String): Unit = {
    val deleteSql = s"alter table dm_gis.$saveTable drop if  exists partition(city='$city',incday='$date')"
    sparkSession.sql(deleteSql)
    val path = s"/user/hive/warehouse/dm_gis.db/$saveTable/city=$city/incday=$date"
    logger.error(path)
    resultRdd.map(waybill => {
      val sb = new StringBuilder
      sb.append(waybill.getWaybillno).append("\t")
        .append(waybill.getCouriercode).append("\t")
        .append(waybill.getZonecode).append("\t")
        .append(waybill.getTimeps).append("\t")
        .append(waybill.getConsigneeaddr).append("\t")
        .append(waybill.getLongitude).append("\t")
        .append(waybill.getLatitude).append("\t")
        .append(waybill.getIncday).append("\t")
        .append(waybill.getCitycode).append("\t")
        .append(waybill.getKeyword).append("\t")
        .append(waybill.getAoiid).append("\t")
        .append(waybill.getStatus)
    }).saveAsTextFile(path)
    sparkSession.sql(s"alter table dm_gis.$saveTable add if not exists partition(city='$city',incday='$date')")
  }
}
