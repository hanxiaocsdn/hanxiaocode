package com.sf.gis.scala.seg.bean;

import scala.Serializable;

import java.util.Comparator;
import java.util.List;

public class Waybill implements Serializable {
	private String waybillno;
	private String couriercode;
	private String zonecode;
	private String timeps;
	private String consigneeaddr;
	private String longitude;
	private String latitude;
	private String longitude_s;
	private String latitude_s;
	private String citycode;
	private String incday;
	private String keyword;
	private String aoiid;
	private String aoix;
	private String aoiy;
	private int status;
	private boolean isDispatch = false;
	private String aoiResp;

	public String getAoiResp() {
		return aoiResp;
	}

	public void setAoiResp(String aoiResp) {
		this.aoiResp = aoiResp;
	}

	public String getAoix() {
		return aoix;
	}

	public void setAoix(String aoix) {
		this.aoix = aoix;
	}

	public String getAoiy() {
		return aoiy;
	}

	public void setAoiy(String aoiy) {
		this.aoiy = aoiy;
	}

	public boolean isDispatch() {
		return isDispatch;
	}

	public void setDispatch(boolean dispatch) {
		isDispatch = dispatch;
	}

	public String getLongitude_s() {
		return longitude_s;
	}

	public void setLongitude_s(String longitude_s) {
		this.longitude_s = longitude_s;
	}

	public String getLatitude_s() {
		return latitude_s;
	}

	public void setLatitude_s(String latitude_s) {
		this.latitude_s = latitude_s;
	}

	public String getWaybillno() {
		return waybillno;
	}

	public void setWaybillno(String waybillno) {
		this.waybillno = waybillno;
	}

	public String getCouriercode() {
		return couriercode;
	}

	public void setCouriercode(String couriercode) {
		this.couriercode = couriercode;
	}

	public String getZonecode() {
		return zonecode;
	}

	public void setZonecode(String zonecode) {
		this.zonecode = zonecode;
	}

	public String getTimeps() {
		return timeps;
	}

	public void setTimeps(String timeps) {
		this.timeps = timeps;
	}

	public String getConsigneeaddr() {
		return consigneeaddr;
	}

	public void setConsigneeaddr(String consigneeaddr) {
		this.consigneeaddr = consigneeaddr;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	public String getIncday() {
		return incday;
	}

	public void setIncday(String incday) {
		this.incday = incday;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getAoiid() {
		return aoiid;
	}

	public void setAoiid(String aoiid) {
		this.aoiid = aoiid;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public static List<Waybill> sort(List<Waybill> list) {
		list.sort(Comparator.comparing(Waybill::getTimeps));
		return list;
	}


	@Override
	public String toString() {
		return "Waybill{" +
				"waybillno='" + waybillno + '\'' +
				", couriercode='" + couriercode + '\'' +
				", zonecode='" + zonecode + '\'' +
				", aoiResp='" + aoiResp + '\'' +
				", status=" + status + '\'' +
				", isDispatch=" + isDispatch +
				'}';
	}
}
