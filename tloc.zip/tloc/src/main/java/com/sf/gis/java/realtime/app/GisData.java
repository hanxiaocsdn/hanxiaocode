package com.sf.gis.java.realtime.app;

import com.sf.gis.java.realtime.sink.GisHBaseSinkFunction;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.utils.ParameterTool;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer08;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * Created by 01328365 on 2019/3/20.
 * 对应实时任务id：2083796
 * 轨迹数据写入hbase，此任务很重要
 * 业务方为轨迹使用者
 */
public class GisData {

    public static Logger logger = LoggerFactory.getLogger(GisData.class);
    public final String topic = "GIS_TEST";

    public static void main(String[] args) throws Exception {
        if (args == null || args.length <= 0) {
            args = new String[]{
                    //"--input-topic", "uss_operation_waybill_01",
                    //"--bootstrap.servers", "10.202.77.208:9092,10.202.77.210:9092,10.202.77.211:9092",
                    //"--zookeeper.connect", "10.202.77.208:2181",
                    "--topic", "GIS_TEST",
                    "--bootstrap.servers", "10.202.24.5:9094,10.202.24.6:9094 ",
                    "--zookeeper.connect", "10.202.24.5:2181,10.202.24.6:2181,10.202.24.7:2181/kafka/other",
                    "--group.id", "gis_data_group01",
                    "--zkQuorum", "10.202.34.200,10.202.34.201",
                    "--srcParallelism", "4",
                    "--sinkParallelism", "4"
            };
        }

        // parse input arguments
        ParameterTool parameterTool = ParameterTool.fromArgs(args);

        String topic = parameterTool.getRequired("topic");
        String groupId = parameterTool.getRequired("group.id");
        String bootstrapServers = parameterTool.getRequired("bootstrap.servers");
        String zookeeperConnect = parameterTool.getRequired("zookeeper.connect");
        int srcParallelism = parameterTool.getInt("srcParallelism", 4);
        int sinkParallelism = parameterTool.getInt("sinkParallelism", 1);
        String offsetReset = parameterTool.get("auto.offset.reset", "");

        System.out.println("=============== topic:" + topic);
        System.out.println("=============== groupId:" + groupId);
        System.out.println("=============== bootstrapServers:" + bootstrapServers);
        System.out.println("=============== zookeeperConnect:" + zookeeperConnect);
        System.out.println("=============== srcParallelism:" + srcParallelism);
        System.out.println("=============== sinkParallelism:" + sinkParallelism);
        System.out.println("=============== auto.offset.reset:" + offsetReset);

        logger.info("=============== topic:" + topic);
        logger.info("=============== groupId:" + groupId);
        logger.info("=============== bootstrapServers:" + bootstrapServers);
        logger.info("=============== zookeeperConnect:" + zookeeperConnect);
        logger.info("=============== parallelism:" + sinkParallelism);
        logger.info("=============== auto.offset.reset:" + offsetReset);

        Map<String, String> kafkaProperties = new HashMap<String, String>();
        kafkaProperties.put("bootstrap.servers", bootstrapServers);
        kafkaProperties.put("group.id", groupId);
        kafkaProperties.put("zookeeper.connect", zookeeperConnect);

        String zkQuorum = parameterTool.getRequired("zkQuorum");
        String humanTableName = parameterTool.get("humanTb", "gis:tloc_human_history");
        String carTableName = parameterTool.get("carTb", "gis:tloc_car_history");

        String userTableName = parameterTool.get("userTb", "gis_date_user_new");
        String logTableName = parameterTool.get("logHbaseTb", "gis:gis_history_fail_new");//--------没有输入这个参数-----
        int dataTbPartitionNum = parameterTool.getInt("dataTb.pNum", 100);//轨迹数据表 100个预分区
        int userTbPartitionNum = parameterTool.getInt("userTb.pNum", 20);//用户表 20个预分区
        int hbaseCommitBatchSize = parameterTool.getInt("batchSize", 100);//提交时候缓存条数

        String shAk = parameterTool.get("shAk", "6,7,8,9,10,11,12,13,14,15,16,17,18,19,23,24");
        //缓存默认大小100万条
        int gisGuavaCacheMaxSize = parameterTool.getInt("cacheSize", 10000 * 100);
        //默认过期时间25小时
        int expireHour = parameterTool.getInt("expireHour", 25);

        int numberRetries = parameterTool.getInt("numberRetries", 7);//重试次数
        int retryDelay = parameterTool.getInt("retryDelay", 10);//重试间隔

        System.out.println("=============== zkQuorum:" + zkQuorum);
        System.out.println("=============== humanTableName:" + humanTableName);
        System.out.println("=============== carTableName:" + carTableName);

        System.out.println("=============== userTableName:" + userTableName);
        System.out.println("=============== logTableName:" + logTableName);
        System.out.println("=============== dataTbPartitionNum:" + dataTbPartitionNum);
        System.out.println("=============== userTbPartitionNum:" + userTbPartitionNum);
        System.out.println("=============== numberOfExecutionRetries:" + numberRetries);
        System.out.println("=============== retryDelay:" + retryDelay);
        System.out.println("=============== shAk:" + shAk);
        System.out.println("=============== gisGuavaCacheMaxSize:" + gisGuavaCacheMaxSize);
        System.out.println("=============== expireHour:" + expireHour);

        logger.info("=============== zkQuorum:" + zkQuorum);
        logger.info("=============== humanTableName:" + humanTableName);
        logger.info("=============== carTableName:" + carTableName);

        logger.info("=============== userTableName:" + userTableName);
        logger.info("=============== logTableName:" + logTableName);
        logger.info("=============== dataTbPartitionNum:" + dataTbPartitionNum);
        logger.info("=============== userTbPartitionNum:" + userTbPartitionNum);
        logger.info("=============== numberOfExecutionRetries:" + numberRetries);
        logger.info("=============== retryDelay:" + retryDelay);
        logger.info("=============== shAk:" + shAk);
        logger.info("=============== gisGuavaCacheMaxSize:" + gisGuavaCacheMaxSize);
        logger.info("=============== expireHour:" + expireHour);

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //设置最大重试次数	接口已经废弃
        //env.setNumberOfExecutionRetries(numberRetries);
        //设置job失败后等待多长时间做重试	接口已经废弃
        //env.getConfig().setExecutionRetryDelay(retryDelay);

        if (numberRetries > 0) {
            env.setRestartStrategy(RestartStrategies.fixedDelayRestart(
                    // 尝试重启次数
                    numberRetries,
                    // 延迟时间间隔
                    Time.of(retryDelay, TimeUnit.SECONDS)
            ));
        }


        //设置全局并行度
        //if(parallelism > 0) {
        //env.setParallelism(parallelism);
        //}

        long checkpointInterval = parameterTool.getLong("c-interval", 5000);
        final String checkpointDir = parameterTool.get("c-dir", "");

        System.out.println("=============== checkpointInterval:" + checkpointInterval);
        System.out.println("=============== checkpointDir:" + checkpointDir);

        logger.info("=============== checkpointInterval:" + checkpointInterval);
        logger.info("=============== checkpointDir:" + checkpointDir);

        if (checkpointInterval > 0 && !StringUtils.isEmpty(checkpointDir)) {
            logger.info("setting chechpoint...");
            env.enableCheckpointing(checkpointInterval);
            boolean asyncCheckpoints = parameterTool.getBoolean("async-checkpoints", false);
            env.setStateBackend(new FsStateBackend(checkpointDir, asyncCheckpoints));

            // 设置模式为exactly-once （这是默认值）
            env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);

            // 确保检查点之间有至少500 ms的间隔【checkpoint最小间隔】
            env.getCheckpointConfig().setMinPauseBetweenCheckpoints(500);
            // 检查点必须在一分钟内完成，或者被丢弃【checkpoint的超时时间】
            env.getCheckpointConfig().setCheckpointTimeout(120000);
            // 同一时间只允许进行一个检查点
            env.getCheckpointConfig().setMaxConcurrentCheckpoints(1);
            // 表示一旦Flink处理程序被cancel后，会保留Checkpoint数据，以便根据实际需要恢复到指定的Checkpoint【详细解释见备注】
            env.getCheckpointConfig().enableExternalizedCheckpoints(CheckpointConfig.ExternalizedCheckpointCleanup.RETAIN_ON_CANCELLATION);
        }

        String jobId = parameterTool.get("jobId", "gis_gps_data");
        String jobName = parameterTool.get("jobName", "gis_gps_data");

        System.out.println("=============== jobId:" + jobId);
        System.out.println("=============== jobName:" + jobName);

        //BdpFlinkKafkaConsumer08 bdpFlinkKafkaConsumer08 = new BdpFlinkKafkaConsumer08(jobId, jobName, json);

        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", bootstrapServers);
        properties.setProperty("zookeeper.connect", zookeeperConnect);
        properties.setProperty("group.id", groupId);

        FlinkKafkaConsumer08<String> gisDataKafkaConsumer = new FlinkKafkaConsumer08<String>(topic, new SimpleStringSchema(), properties);

        if (offsetReset.toLowerCase().equals("earliest")) {
            gisDataKafkaConsumer.setStartFromEarliest();
        } else if (offsetReset.toLowerCase().equals("latest")) {
            gisDataKafkaConsumer.setStartFromLatest();
        }

        DataStream<String> gisDataStream = env.addSource(gisDataKafkaConsumer)
                .name("GIS_LSS_TLOC_SOURCE").uid("GIS_LSS_TLOC_SOURCE").setParallelism(srcParallelism);

        System.out.println("--------------输出数据-------------------------");
        //输出到hbase
        gisDataStream.addSink(new GisHBaseSinkFunction(zkQuorum, humanTableName, userTableName, logTableName, dataTbPartitionNum,
                userTbPartitionNum, hbaseCommitBatchSize, shAk, gisGuavaCacheMaxSize, expireHour, carTableName)).name("GIS_LSS_TLOC_PATH_SOURCE").uid("GIS_LSS_TLOC_PATH_SOURCE").setParallelism(sinkParallelism);

        env.execute(jobName);
    }

}
