package com.sf.gis.java.realtime.util;

import com.sf.gis.java.base.util.MD5Util;
import org.apache.hadoop.hbase.util.MD5Hash;
import org.apache.hadoop.util.hash.MurmurHash;

import java.io.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class SaltUtil {
	
	/**
	 * 根据输入值，计算前缀
	 * @param value
	 * @param partition 预分区个数
	 * @return
	 */
	public static String generateSalt(String value, int partition) {
		//没有做预分区情况
		if(partition <= 0) {
			return MD5Hash.getMD5AsHex(value.getBytes()).substring(0, 8);
		}
		
		StringBuffer salt = new StringBuffer("");
		//int hashCode = value.hashCode();
		long hashCode = MurmurHash.getInstance().hash(value.getBytes());

		if(hashCode < 0) {
			hashCode = 0 - hashCode;
		}
		
		long mod = hashCode % partition;
		if(partition <= 10) {
			salt.append(mod);
		} else if(partition <= 100) {
			salt.append(String.format("%02d", mod));
		} else if(partition <= 1000) {
			salt.append(String.format("%03d", mod));
		} else if(partition <= 10000) {
			salt.append(String.format("%04d", mod));
		}
		
		return salt.toString();
	}
	public static String generateSaltNew(String value, int partition) {
		String md5 = MD5Util.getMD5(value).toLowerCase();
//		System.out.println(md5);

		StringBuffer salt = new StringBuffer("");
		//int hashCode = value.hashCode();
		long hashCode = MurmurHash.getInstance().hash(md5.getBytes());

		if(hashCode < 0) {
			hashCode = 0 - hashCode;
		}

		long mod = hashCode % partition;
		if(partition <= 10) {
			salt.append(mod);
		} else if(partition <= 100) {
			salt.append(String.format("%02d", mod));
		} else if(partition <= 1000) {
			salt.append(String.format("%03d", mod));
		} else if(partition <= 10000) {
			salt.append(String.format("%04d", mod));
		}

		return salt.toString();
	}
	/**
	 * 生成分区文件
	 * @param partition
	 * @throws IOException
	 */
    public static void createPartitionFile(int partition) throws IOException {
    	if(partition <= 0) {
    		return;
    	}
    	
		File file = new File("D:/"+partition+".txt");
		
		if(!file.exists()) {
			file.createNewFile();
		}
		
		FileOutputStream fos = new FileOutputStream(file);
		OutputStreamWriter osw = new OutputStreamWriter(fos, "utf-8");
		BufferedWriter bw = new BufferedWriter(osw);
		
		StringBuffer val = new StringBuffer();
		for(int mod=1; mod<partition; mod++) {
			if(partition <= 10) {
				val.append(mod);
			} else if(partition <= 100) {
				val.append(String.format("%02d", mod));
			} else if(partition <= 1000) {
				val.append(String.format("%03d", mod));
			} else if(partition <= 10000) {
				val.append(String.format("%04d", mod));
			}
			
			bw.write(val.toString());
			if(mod != partition-1) {
				bw.newLine();
			}
			bw.flush();
			val.delete(0, val.length());
		}
		
		if(bw != null) {
			bw.close();
		}
		
		if(osw != null) {
			osw.close();
		}
		
		if(fos != null) {
			fos.close();
		}
	}
    
    
    /**
	 * 生成分区文件
	 * @param partition
	 * @throws IOException
	 */
    public static List<String> getPartitionList(int partition) throws IOException {
    	List<String> list = new ArrayList<String>();
    	
    	if(partition <= 0) {
    		return list;
    	}
		
		for(int mod=1; mod<partition; mod++) {
			if(partition <= 10) {
				System.out.println(mod);
			} else if(partition <= 100) {
				System.out.println(String.format("%02d", mod));
			} else if(partition <= 1000) {
				System.out.println(String.format("%03d", mod));
			} else if(partition <= 10000) {
				System.out.println(String.format("%04d", mod));
			}
		}
		
		return list;
	}
	
	public static void main(String[] args) throws ParseException, IOException {
    	int dataTbPartitionNum = 100;
    	String un = "冀AA333";
    	int ak = 7;
		long tm = 1591409509;
    	String trunc = DateUtil.truncTime(tm*1000+"");

		String md5Key = un + "_" + trunc + "_" +ak ;
		long hashCode =0- MurmurHash.getInstance().hash(md5Key.getBytes());
		System.out.println(""+hashCode);
		String rowkey = SaltUtil.generateSaltNew(md5Key, dataTbPartitionNum) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;
		System.out.println(rowkey);

		String xx = SaltUtil.generateSalt(ak+trunc+un, dataTbPartitionNum) + "_" + ak + "_" + trunc + "_" + un + "_" + tm;
		System.out.println(xx);
		//483081533712

        int partition = 120;
        String salt = SaltUtil.generateSalt("3", partition);
        System.out.println(salt);



    	//createPartitionFile(partition);
    	
    	/*
		createPartitionFile(3);
		createPartitionFile(20);
		createPartitionFile(35);
		createPartitionFile(220);
		createPartitionFile(800);
		createPartitionFile(1400);
		*/
		
//		getPartitionList(partition);

	}
	
}