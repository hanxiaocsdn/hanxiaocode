package com.sf.gis.java.tloc.kafka;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.base.util.JSONUtil;
import com.sf.gis.scala.base.util.StringUtils;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.util.Collector;

import java.util.ArrayList;

/**
 * GIS-LSS-TLOC：【壹竿-督导】步数统计_V1.0 kafka2hive(需求人：01422773)
 * 20220802 created by 01417629
 */
public class HiveFlatMapFunction extends RichFlatMapFunction<String,String> {
    @Override
    public void flatMap(String s, Collector<String> collector) throws Exception {
        JSONArray  jsonArray = JSONArray.parseArray(s);
        for (int i = 0; i <jsonArray.size() ; i++) {
            JSONObject json = JSONArray.parseObject(jsonArray.get(i).toString());
            String id = JSONUtil.getJsonVal(json, "id","");
            String un = JSONUtil.getJsonVal(json, "un","");
            String bn = JSONUtil.getJsonVal(json, "bn","");
            String num = JSONUtil.getJsonVal(json, "num","");
            String oNum = JSONUtil.getJsonVal(json, "oNum","");
            String tm = JSONUtil.getJsonVal(json, "tm","");
            String type = JSONUtil.getJsonVal(json, "type","");
            ArrayList<String> res = new ArrayList<>();
            res.add(id);
            res.add(un);
            res.add(bn);
            res.add(num);
            res.add(oNum);
            if(StringUtils.isNotBlank(tm) && tm.length() >= 10){
                res.add(tm.substring(0,10));
            }else{
                res.add(tm);
            }
            res.add(type);
            String res_message = String.join("\t", res);
            collector.collect(res_message);
        }
    }
}
