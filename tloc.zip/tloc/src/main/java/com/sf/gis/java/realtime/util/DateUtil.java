package com.sf.gis.java.realtime.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtil {
    
    //yyyyMMddHHmmssSSS
    public static final String DEFAULT_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String MILL_FORMAT_ = "yyyy-MM-dd HH:mm:ss SSS";

    public static final String DEFAULT_FORMAT_TRUNC = "yyyyMMdd";
    
    public static final DateFormat getDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat(DEFAULT_FORMAT);
        return dateFormat;
    }
    
    public static final DateFormat getTruncDateFormat() {
        DateFormat dateFormat = new SimpleDateFormat(DEFAULT_FORMAT_TRUNC);
        return dateFormat;
    }
    
    public static final DateFormat getDateFormat(String format) {
        DateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat;
    }
    
    public static final String format(Date date, String format) {
        String dataString = "";
        if (null != date) {
            DateFormat dateFormat = getDateFormat(format);
            dataString = dateFormat.format(date);
        }
        return dataString;
    }
    
    public static final String format(Date date, DateFormat dateFormat) {
        String dataString = "";
        if (null != date) {
            dataString = dateFormat.format(date);
        }
        return dataString;
    }

    public static final Date parse(String dateString, String format) {
        Date date = null;
        if (null != dateString && !"".equals(dateString)) {
            DateFormat dateFormat = getDateFormat(format);
            try {
                date = dateFormat.parse(dateString);
            } catch (ParseException e) {
                // 解析错误，直接返回
                return null;
            }
        }
        return date;
    }
    
    public static final Date parse(String dateString, DateFormat dateFormat) {
        Date date = null;
        if (null != dateString && !"".equals(dateString)) {
            try {
                date = dateFormat.parse(dateString);
            } catch (ParseException e) {
                // 解析错误，直接返回
                return null;
            }
        }
        return date;
    }
    
    public static final Date parse(String dateString) {
        Date date = null;
        if (null != dateString && !"".equals(dateString)) {
            DateFormat dateFormat = getDateFormat(DateUtil.DEFAULT_FORMAT);
            try {
                date = dateFormat.parse(dateString);
            } catch (ParseException e) {
                // 解析错误，直接返回
                return null;
            }
        }
        return date;
    }

    /**
     * 将毫秒数换算成x天x时x分x秒
     * 
     * @param millis
     * @return
     */
    public static final String format(long millis) {
        int ss = 1000;
        int mi = ss * 60;
        int hh = mi * 60;
        int dd = hh * 24;

        long day = millis / dd;
        long hour = (millis - day * dd) / hh;
        long minute = (millis - day * dd - hour * hh) / mi;
        long second = (millis - day * dd - hour * hh - minute * mi) / ss;

        StringBuffer hhmmss = new StringBuffer();
        if (day > 0) {
            hhmmss.append(day + "天");
        }
        if (hour > 0) {
            hhmmss.append(hour + "小时");
        }
        if (minute > 0) {
            hhmmss.append(minute + "分");
        }
        if (second > 0) {
            hhmmss.append(second + "秒");
        }else{
            hhmmss.append("不到一秒钟");
        }
        return hhmmss.toString();
    }
    
    /**
     * 获得当前年份
     * @return
     */
    public static String getYear() {
        return String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
    }
    
    public static String getYear(Date date) {
        if(date == null) {
            return "";
        }
        Calendar beginCal = Calendar.getInstance();
        beginCal.setTime(date);
        return String.valueOf(beginCal.get(Calendar.YEAR));
    }
    
    public static String getYear(String date) {
        if(date == null || date.trim().equals("")) {
            return "";
        }
        
        String year = "";
        DateFormat dateFormat = getDateFormat("yyyy-mm-dd");
        try {
            Calendar beginCal = Calendar.getInstance();
            beginCal.setTime(dateFormat.parse(date));
            year = String.valueOf(beginCal.get(Calendar.YEAR));
        } catch (ParseException e) {
            // 解析错误，直接返回
            year = "";
        }
        
        return year;
    }
    
    public static String getYear(String date, String format) {
    	if(date == null || date.trim().equals("")) {
            return "";
        }
        
        String year = "";
        DateFormat dateFormat = getDateFormat(format);
        try {
            Calendar beginCal = Calendar.getInstance();
            beginCal.setTime(dateFormat.parse(date));
            year = String.valueOf(beginCal.get(Calendar.YEAR));
        } catch (ParseException e) {
            // 解析错误，直接返回
            year = "";
        }
        
        return year;
    }
    
    // 获得本周星期日的日期
    public static String getCurrentWeekday() {
        int mondayPlus = getMondayPlus();
        GregorianCalendar currentDate = new GregorianCalendar();
        currentDate.add(GregorianCalendar.DATE, mondayPlus+6);
        Date monday = currentDate.getTime();
        DateFormat df = DateFormat.getDateInstance();
        String preMonday = df.format(monday);
        return preMonday;
    }
    
    // 获得当前日期与本周日相差的天数
    private static int getMondayPlus() {
        Calendar cd = Calendar.getInstance();
        // 获得今天是一周的第几天，星期日是第一天，星期二是第二天......
        int dayOfWeek = cd.get(Calendar.DAY_OF_WEEK)-1; //因为按中国礼拜一
        if (dayOfWeek == 1) {
            return 0;
        } else {
            return 1 - dayOfWeek;
        }
    }
    
    public static Date getTomorrow(String hour) {
        //获取当前日期  
        Date date = new Date();  
        String nowDate = DateUtil.format(date, "yyyy-MM-dd");  
        nowDate = nowDate + hour.trim();
        
        //通过日历获取下一天日期  
        Calendar cal = Calendar.getInstance();  
        cal.setTime(DateUtil.parse(nowDate, "yyyy-MM-dd HH:mm:ss"));  
        cal.add(Calendar.DAY_OF_YEAR, +1);  
        
        return cal.getTime();
    }
    
    public static int compareTo(Date d1, Date d2) {
    	return d1.compareTo(d2);
    }
    
    public static Date trunc(Date date, String format) {
    	return DateUtil.parse(DateUtil.format(date, format), format);
    }
    
    public static Date trunc(Date date) {
    	return DateUtil.parse(DateUtil.format(date, "yyyy-MM-dd"), "yyyy-MM-dd");
    }
    
    public static Date trunc(Date date, DateFormat dateFormat) {
    	return DateUtil.parse(DateUtil.format(date, dateFormat), dateFormat);
    }
    
    
    public static int monthsBetween(Date d1, Date d2) {
        Calendar c = Calendar.getInstance();
        c.setTime(d1);
        int year1 = c.get(Calendar.YEAR);
        int month1 = c.get(Calendar.MONTH);
         
        c.setTime(d2);
        int year2 = c.get(Calendar.YEAR);
        int month2 = c.get(Calendar.MONTH);
         
        int result;
        if(year1 == year2) {
            result = month1 - month2;
        } else {
            result = 12*(year1 - year2) + month1 - month2;
        }
        return Math.abs(result);
    }
    
    public static Date addMonth(Date date, int month) {
    	Calendar c = Calendar.getInstance();
    	c.setTime(date); 
        c.add(Calendar.MONTH, month);
        
        return c.getTime();
    }
    
    /**
     * 传入时间戳
     * 将时间戳转换成date类型，比如时间是2016-01-18 11:38:05
     * 然后将时间截取到天：2016-01-18
     * 得到天的时间戳
     * 然后反转
     * @param timeStr
     * @return
     */
    public static String truncReverse(String timeStr, DateFormat dateFormat) {
    	StringBuffer sb = new StringBuffer();
    	try {
    		long time = Long.parseLong(timeStr);
    		long truncDate = DateUtil.trunc(new Date(time), dateFormat).getTime();
    		sb.append(truncDate+"");
    	}catch(RuntimeException e) {
    		
    	}
    	
    	return sb.reverse().toString();
    }
    
    /**
     * 传入时间戳
     * 将时间戳转换成date类型，比如时间是20160118 11:38:05
     * 然后将时间截取到天：20160118
     * @param timeStr
     * @param dateFormat
     * @return
     */
    public static String trunc(String timeStr, DateFormat dateFormat) {
    	String dateStr = "";
    	try {
    		long time = Long.parseLong(timeStr);
    		Date date = DateUtil.trunc(new Date(time), dateFormat);
    		dateStr = DateUtil.format(date, dateFormat);
    	}catch(RuntimeException e) {
    		
    	}
    	
    	return dateStr;
    }

    /**
     * 传入时间戳
     * 将时间戳转换成date类型，比如时间是20160118 11:38:05
     * 然后将时间截取到天：20160118
     * @param time
     * @return
     */
    public static String truncTime(String time) {
    	String str = "";
    	try {
    		Date date = DateUtil.trunc(new Date(Long.parseLong(time)), DEFAULT_FORMAT_TRUNC);
    		str = DateUtil.format(date, DEFAULT_FORMAT_TRUNC);
    	}catch(RuntimeException e) {
    		
    	}
    	
    	return str;
    }

    public static String getCurrDatetime(){
        SimpleDateFormat dfTime = new SimpleDateFormat(MILL_FORMAT_);
        String datetime = dfTime.format(new Date());
        return datetime;
    }
    
    public static void main(String[] args) {

        test();
    	/*
        String aa = getCurrentWeekday();
        System.out.println(aa);
        
        Date date = DateUtil.parse(DateUtil.getCurrentWeekday() + " 01:00:00", "yyyy-MM-dd hh:mm:ss");
        System.out.println(date);
        
        System.out.println(getTomorrow("02:00:00"));
        
        System.out.println(DateUtil.format(new Date(), "yyyy-MM-dd HH:mm:ss"));
        */
    	
    	/*
    	Locale.setDefault(new Locale("en", "US"));
    	Date d1 = DateUtil.parse("December 13 2016, 23:59:55.000", "MMMMM dd yyyy, hh:mm:ss");
        System.out.println(d1);
        System.out.println(DateUtil.format(d1, "yyyy-MM-dd HH:mm:ss"));
        */
    	
    	System.out.println("===== " + System.currentTimeMillis());
    	Date date = new Date(1493111764958L);
    	System.out.println(DateUtil.format(date, DateUtil.DEFAULT_FORMAT));
    	
    	String dateStr = "2017-01-19 00:00:00";
    	System.out.println(DateUtil.truncTime(System.currentTimeMillis()+""));
    	
    	//1484668800
    	//1484755200
    	
    	/*
    	long time = 1481885188*1000L;
    	Date date = new Date(time);
    	
    	String str = DateUtil.format(date, "yyyy-MM-dd HH:mm:ss");
    	System.out.println(str);
    	new StringBuffer(str).reverse();
    	
    	long truncDate = DateUtil.trunc(date).getTime();
    	System.out.println(truncDate);
    	System.out.println(DateUtil.format(new Date(truncDate), "yyyy-MM-dd HH:mm:ss"));
    	
    	String sss = DateUtil.truncReverse("1481885188", DateUtil.getTruncDateFormat());
    	System.out.println(sss);
    	
    	System.out.println(DateUtil.trunc("1481885188", DateUtil.getTruncDateFormat()));
    	
    	System.out.println();
    	*/
    }

    public static void test(){
        String currDatetime = getCurrDatetime();
        System.out.println(currDatetime);
    }
    
}