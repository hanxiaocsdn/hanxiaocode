package com.sf.gis.java.realtime.util;//package com.sf.gis.common.util;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//
//import com.fasterxml.jackson.databind.DeserializationFeature;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//
//public class JsonUtil
//{
//  private static ObjectMapper mapper = new ObjectMapper();
//
//  static {
//    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//  }
//
//  public static <T> T readData(String json, Class<T> classType)
//  {
//    try {
//      return mapper.readValue(json, classType);
//    } catch (IOException e) {
//      throw new RuntimeException(e);
//    }
//  }
//
//  public static String writeValueAsString(Object value) {
//    try {
//      return mapper.writeValueAsString(value);
//    } catch (IOException e) {
//      throw new RuntimeException(e);
//    }
//  }
//
//  public static JsonNode readTree(String content) {
//    try {
//      return mapper.readTree(content);
//    } catch (IOException e) {
//      throw new RuntimeException(e);
//    }
//  }
//
//  public static List<Map<String, String>> readList(String content) {
//	  List<Map<String, String>> list = new ArrayList<Map<String, String>>();
//	  try {
//		  JsonNode node = mapper.readTree(content);
//		  Iterator<JsonNode> itNode = node.elements();
//		  while(itNode.hasNext()) {
//			  Map<String, String> map = new HashMap<String, String>();
//			  JsonNode nodeTemp = itNode.next();
//			  Iterator<String> itStr = nodeTemp.fieldNames();
//			  while(itStr.hasNext()) {
//				  String key = itStr.next();
//				  String value = nodeTemp.get(key).toString();
//				  map.put(key, value);
//			  }
//			  list.add(map);
//		  }
//	  } catch (IOException e) {
//	      throw new RuntimeException(e);
//	  }
//
//	  return list;
//  }
//
//  public static Map<String, String> readMap(String content) {
//	  return readData(content, Map.class);
//  }
//
//  public static ObjectMapper getMapper() {
//    return mapper;
//  }
//
//  public static <T> T readData(JsonNode jsonNode, Class<? extends T> clazz) {
//    try {
//      return mapper.readValue(jsonNode.traverse(), clazz);
//    } catch (Exception e) {
//      throw new RuntimeException(e);
//    }
//  }
//
//  public static void main(String[] args) {
//	  Map<String, Object> mapTemp = new HashMap<String, Object>();
//	  mapTemp.put("id", 111);
//	  mapTemp.put("name", "zhangsan");
//
//	  System.out.println(JsonUtil.writeValueAsString(mapTemp));
//
//	  Map<String, String> map = readMap(JsonUtil.writeValueAsString(mapTemp));
//	  System.out.println(map);
//}
//}
