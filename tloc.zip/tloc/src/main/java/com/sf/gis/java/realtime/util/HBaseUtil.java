package com.sf.gis.java.realtime.util;

import com.alibaba.fastjson.JSON;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.CellUtil;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;
import org.apache.hadoop.io.IOUtils;

import java.io.IOException;
import java.util.*;

/**
 * 
 * @author huangchm
 *
 */
public class HBaseUtil {
	
	public static final String SALT_SEPARATOR = "_";
	
	private static Connection connection;

	/**
	 * 使用该类，必须先调用该方法
	 * @param hbase_zookeeper_quorum
	 * @param hbase_zookeeper_property_clientPort
	 * @param zookeeper_znode_parent
	 * @return
	 */
	public synchronized static Connection init(String hbase_zookeeper_quorum, String hbase_zookeeper_property_clientPort, String zookeeper_znode_parent) {
		if(connection == null) {
			try {
				Configuration conf = HBaseConfiguration.create();
						
				conf.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum);
    	        conf.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_property_clientPort);
	            conf.set("zookeeper.znode.parent", zookeeper_znode_parent);

				conf.set("hbase.client.retries.number", "11");
				
				connection = ConnectionFactory.createConnection(conf);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return connection;
	}
	
    /**
     * 添多条记录
     * @param tableName
     * @param columnFamily
     * @param valueMap
     * @throws IOException
     */
    public static void put(String tableName, String columnFamily, Map<String, Map<String, String>> valueMap) throws IOException {
    	Table table = null;
    	
    	try {
	    	if(null != valueMap && !valueMap.isEmpty()) {
	    		table = connection.getTable(TableName.valueOf(tableName));
	    		
	    		List<Put> putList = new ArrayList<Put>();
	        	
	    		byte[] cf = Bytes.toBytes(columnFamily);
	    		
	        	for(Map.Entry<String, Map<String, String>> entry : valueMap.entrySet()) {
	        		String rowkey = entry.getKey();
	        		Map<String, String> values = entry.getValue();
	        		
	        		Set<String> set = values.keySet();
	            	
	        		Put p = new Put(Bytes.toBytes(rowkey));
	            	for(String column : set) {
	            		String value = values.get(column);
	                	p.addColumn(cf, Bytes.toBytes(column), Bytes.toBytes(value));
	            	}
	            	
	            	putList.add(p);
	        	}
	        	
	        	table.put(putList);
	    	}
    	} catch (IOException e) {
			e.printStackTrace();
		} finally {
    		IOUtils.closeStream(table);
    	}
    }
    
    /**
     * 添多条记录
     * @param table
     * @param columnFamily
     * @param valueMap
     * @throws IOException
     */
    public static void put(Table table, String columnFamily, Map<String, Map<String, String>> valueMap) throws IOException {
    	try {
	    	if(null != valueMap && !valueMap.isEmpty()) {
	    		List<Put> putList = new ArrayList<Put>();
	        	
	    		byte[] cf = Bytes.toBytes(columnFamily);
	    		
	        	for(Map.Entry<String, Map<String, String>> entry : valueMap.entrySet()) {
	        		String rowkey = entry.getKey();
	        		Map<String, String> values = entry.getValue();
	        		
	        		Set<String> set = values.keySet();
	            	
	        		Put p = new Put(Bytes.toBytes(rowkey));
	            	for(String column : set) {
	            		String value = values.get(column);
	                	p.addColumn(cf, Bytes.toBytes(column), Bytes.toBytes(value));
	            	}
	            	
	            	putList.add(p);
	        	}
	        	
	        	table.put(putList);
	    	}
    	} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} finally {
    		
    	}
    }
    
    /**
     * 添多条记录
     * @param tableName
     * @param value
     * @param exception
     * @throws IOException
     */
    public static void put(String tableName, String rowKey, String value, String exception, String dt) throws IOException {
    	Table table = null;
    	
    	try {
    		table = connection.getTable(TableName.valueOf(tableName));

    		Put p = new Put(Bytes.toBytes(rowKey));
			//p.setWriteToWAL(false);
    		p.addColumn(Bytes.toBytes("f"), Bytes.toBytes("raw"), value==null? Bytes.toBytes(""): Bytes.toBytes(value));
    		p.addColumn(Bytes.toBytes("f"), Bytes.toBytes("exp"), exception==null? Bytes.toBytes(""): Bytes.toBytes(exception));
			p.addColumn(Bytes.toBytes("f"), Bytes.toBytes("dt"), dt==null? Bytes.toBytes(""): Bytes.toBytes(dt));
    		
    		table.put(p);
    	} catch (IOException e) {
			e.printStackTrace();
		} finally {
    		IOUtils.closeStream(table);
    	}
    }


	public static void putLog(String tableName, Map<String, Map<String, String>> valueHumanMap, Map<String, Map<String, String>> valueMapDateUser,Map<String, Map<String, String>> valueMapCar, Exception e) throws IOException {
		String salt = new Random().nextInt(10)+"";

		String rowKey = new StringBuffer(salt).append("_").append(System.currentTimeMillis()+"").reverse().toString();

		//当某条数据出现异常不至于导致整个job失败
		if(!valueHumanMap.isEmpty()) {
			HBaseUtil.put(tableName, rowKey, JSON.toJSONString(valueHumanMap.keySet()), ExceptionUtil.getStackTraceMsg(e), "d");
		}

		if(!valueMapDateUser.isEmpty()) {
			HBaseUtil.put(tableName, rowKey, JSON.toJSONString(valueMapDateUser.keySet()), ExceptionUtil.getStackTraceMsg(e), "u");
		}
		if(!valueMapCar.isEmpty()) {
			HBaseUtil.put(tableName, rowKey, JSON.toJSONString(valueMapCar.keySet()), ExceptionUtil.getStackTraceMsg(e), "car");
		}
	}

    /**
     * 添多条记录
     * @param table
     * @param rowKey
     * @param value
     * @throws IOException
     */
    public static void put(Table table, String rowKey, String value) throws IOException {
    	try {
    		Put p = new Put(Bytes.toBytes(rowKey));
    		p.addColumn("info".getBytes(), "raw".getBytes(), value==null?"".getBytes():value.getBytes());
    		
    		table.put(p);
    	} catch (IOException e) {
			e.printStackTrace();
		} finally {
    	}
    }

	public static byte[] get(String tableName, String rowKey) {
		Table table = null;
		byte[] bytes = null;

		try {
			table = connection.getTable(TableName.valueOf(tableName));

			//拿到rowKey中，某个列的数据
			Get get = new Get(Bytes.toBytes(rowKey));

			Result result = table.get(get);

			for(org.apache.hadoop.hbase.Cell cell : result.rawCells()) {
				//注意，需要使用Bytes.toString(keyValue.getFamily())方式，如果采用new String(keyValue.getFamily())会出现中文乱码
				//String key = Bytes.toString(keyValue.getFamily()) + ":" + Bytes.toString(keyValue.getQualifier());
				bytes = CellUtil.cloneValue(cell);
				break;
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeStream(table);
		}

		return bytes;
	}

	public static Map<String, String> get(String tableName, String rowKey, Map<String, List<String>> cfColumns) {
		Table table = null;
		Map<String, String> mapEntry = new HashMap<String, String>();

		try {
			table = connection.getTable(TableName.valueOf(tableName));

			//拿到rowKey中，某个列的数据
			Get get = new Get(Bytes.toBytes(rowKey));

			if(cfColumns != null && !cfColumns.isEmpty()) {
				for(Map.Entry<String, List<String>> entry : cfColumns.entrySet()) {
					byte[] cf = Bytes.toBytes(entry.getKey());
					List<String> columns = entry.getValue();

					for(String column : columns) {
						get.addColumn(cf, Bytes.toBytes(column));
					}
				}
			}

			Result result = table.get(get);

			//返回值不需要rowkey
			//mapLine.put("row_key", rowKey);

			for(org.apache.hadoop.hbase.Cell cell : result.rawCells()) {
				//注意，需要使用Bytes.toString(keyValue.getFamily())方式，如果采用new String(keyValue.getFamily())会出现中文乱码
				//String key = Bytes.toString(keyValue.getFamily()) + ":" + Bytes.toString(keyValue.getQualifier());
				String key = Bytes.toString(CellUtil.cloneQualifier(cell));
				String val = Bytes.toString(CellUtil.cloneValue(cell));
				mapEntry.put(key, val==null?"":val);
			}

			mapEntry.put("rowKey", rowKey);
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			IOUtils.closeStream(table);
		}
		return mapEntry;
	}


	public static void main(String[] args) {
		//时间戳
		String tm = "1553677619";
		//用户工号
		String un = "车牌1号";
		//设备id
		String id = "1111";
		//传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
		long tmTemp = Long.parseLong(tm)*1000;
		String trunc = DateUtil.truncTime(tmTemp+"");

		String ak = "18";

		//http://10.202.15.146:8789/BDPGateWay/other/gis/18/车牌1号/2019-03-27
		//http://10.202.105.140:8789/BDPGateWay/other/gis/18/车牌1号/2019-03-27

		//100个预分区
		String rowkey = SaltUtil.generateSalt(ak+trunc+un, 100) + "_" + ak + "_" + trunc + "_" + un + "_" + tm;

		HBaseUtil.init("10.202.34.200", "2181", "/hbase");

		byte[] bytes = HBaseUtil.get("gis_history_new", rowkey);
		System.out.println("================= " + Bytes.toString(bytes));

		Map<String, String> map = HBaseUtil.get("gis_history_new", rowkey, null);
		System.out.println(map);
    }
}