package com.sf.gis.java.tloc.kafka;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.HbaseUtil;
import com.sf.gis.java.base.util.MD5Util;
import com.sf.gis.java.base.util.SaltUtil;
import com.sf.gis.scala.base.util.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class StepCountHBaseSinkFunction extends RichSinkFunction<String> {

	public static Logger logger = LoggerFactory.getLogger(StepCountHBaseSinkFunction.class);

	private static final long serialVersionUID = 1L;

	public final static String zkQuorum = "cnsz17pl6541,cnsz17pl6542,cnsz17pl6543,cnsz17pl6544,cnsz17pl6545";

	public final static String ZK_PARENT = "/hbase";

	public final static String ZK_PORT = "2181";

	public final static String TABLE_NAME = "gis:gis_sensor";

	public final static String COLUMN_FAMILY_NAME = "info";

	public final static int BATCH_SIZE = 100;

	public final static int DATATABLE_PARTITION_NUM = 100;

	private static Connection connection = null;
	
	@Override
	public void open(Configuration parameters) {
		try {
			connection = HbaseUtil.init(zkQuorum, ZK_PORT, ZK_PARENT);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @param value 从kafka接收的每一条记录都是数组，数组中的每一个原始都是一条   [{},{},},{}...]
	 * @throws Exception
	 */
	@Override
	public void invoke(String value) {
		if(!org.apache.commons.lang3.StringUtils.isEmpty(value)) {
			try {
				JSONArray jsonArray = JSON.parseArray(value);
				//将轨迹点写出到hbase
				if(jsonArray != null && !jsonArray.isEmpty()) {
					putList(jsonArray);
				}
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void putList(JSONArray jsonArray) {
		Table table = null;
		Map<String, Map<String, String>> valueHumanMap = new HashMap<String, Map<String, String>>();
		try {
			table = connection.getTable(TableName.valueOf(TABLE_NAME));
			long index = 0;
			Iterator it = jsonArray.iterator();
            while(it.hasNext()) {
				Map<String, String> mapTemp = new HashMap<String, String>();
				try {
					Map<String, Object> map = (Map)it.next();
					Set<String> keySet = map.keySet();
					Iterator<String> keySetIt = keySet.iterator();
					while(keySetIt.hasNext()) {
						String key = keySetIt.next();
						String value = map.get(key).toString();
						String valueTemp = value.replace("\"", "");
						mapTemp.put(key, valueTemp);
                    }
					map.clear();
					//时间戳
					String time = mapTemp.get("tm");
					String tm = "";
					if(StringUtils.isNotBlank(time)){
						tm = time.substring(0,10);
						mapTemp.put("tm",tm);
					}
					//用户工号
					String un = mapTemp.get("un");
					//type
					String type = mapTemp.get("type");
					//设备id
					String id = mapTemp.get("id");
					//传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
					long tmTemp = 0;
					if(StringUtils.isNotBlank(tm)){
						tmTemp = Long.parseLong(tm)*1000;
					}
					String trunc = DateUtil.truncTime(tmTemp+"");
					//100个预分区
					String md5Key = un + "_" + trunc + "_" + id + "_" + type ;
					String rowkey = SaltUtil.generateSaltNew(md5Key, DATATABLE_PARTITION_NUM) + "_" + MD5Util.getMD5(md5Key) + "_" + tm;
					valueHumanMap.put(rowkey, mapTemp);

					if(index != 0 && index%BATCH_SIZE == 0) {
						if(!valueHumanMap.isEmpty()) {
							HbaseUtil.put(table, COLUMN_FAMILY_NAME, valueHumanMap);
							valueHumanMap.clear();
						}
						index = 0;
					}
					index = index + 1;
				} catch(Exception e) {
					e.printStackTrace();
				}
			}
			if(!valueHumanMap.isEmpty()) {
				HbaseUtil.put(table, COLUMN_FAMILY_NAME, valueHumanMap);
				valueHumanMap.clear();
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			//保证关闭连接
			IOUtils.closeStream(table);
		}
	}

	@Override
	public void close() throws Exception {
		//IOUtils.closeStream(connection);
	}

}
