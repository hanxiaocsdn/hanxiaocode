package com.sf.gis.java.realtime.sink;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.google.common.cache.LoadingCache;
import com.sf.gis.java.base.util.MD5Util;
import com.sf.gis.java.realtime.util.DateUtil;
import com.sf.gis.java.realtime.util.HBaseUtil;

import com.sf.gis.java.realtime.util.SaltUtil;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.*;

public class GisHBaseSinkFunction extends RichSinkFunction<String> {

	public static Logger logger = LoggerFactory.getLogger(GisHBaseSinkFunction.class);

	private static final long serialVersionUID = 1L;

	public final static String ZK_PARENT = "/hbase";

	public final static String ZK_PORT = "2181";

	public final static String HBASE_USER_NAME = "hdfs";

	public final static String COLUMN_FAMILY_NAME = "info";

	public final int DATATABLE_PARTITION_NUM = 100;

	public final int USERTABLE_PARTITION_NUM = 20;

	private String zkQuorum;

	private String zkPort = ZK_PORT;

	private String zkParent = ZK_PARENT;

	private String userName = HBASE_USER_NAME;

	private String dataTableName;

	private String logTableName;

	private String userTableName;

	private String columnFamily = COLUMN_FAMILY_NAME;

	private int dataTbPartitionNum = DATATABLE_PARTITION_NUM;

	private int userTbPartitionNum = USERTABLE_PARTITION_NUM;

	private int hbaseCommitBatchSize;

	private String hbase_columnFamily = "info";

//	private String hbase_columnFamilySH = "sh";

	private String shAk = "";

	private int expireHour;
	private String carTableName;
	private long gisGuavaCacheMaxSize;

	private transient Connection connection;

	private transient LoadingCache<String, Integer> gisCache = null;



	public GisHBaseSinkFunction(String zkQuorum, String dataTableName, String userTableName, String logTableName, int dataTbPartitionNum,
                                int userTbPartitionNum, int hbaseCommitBatchSize, String shAk, int gisGuavaCacheMaxSize, int expireHour,
                                String carTableName) {
		this(zkQuorum, ZK_PORT, ZK_PARENT, HBASE_USER_NAME, dataTableName, userTableName,logTableName, dataTbPartitionNum,
				userTbPartitionNum, hbaseCommitBatchSize, shAk, gisGuavaCacheMaxSize, expireHour,carTableName);
	}

	public GisHBaseSinkFunction(String zkQuorum, String zkPort, String zkParent, String userName,
                                String dataTableName, String userTableName, String logTableName, int dataTbPartitionNum,
                                int userTbPartitionNum, int hbaseCommitBatchSize, String shAk, int gisGuavaCacheMaxSize,
                                int expireHour, String carTableName) {
		this.zkQuorum = zkQuorum;
		this.zkPort = zkPort;
		this.zkParent = zkParent;
		this.userName = userName;
		this.dataTableName = dataTableName;
		this.userTableName = userTableName;
		this.logTableName = logTableName;
		this.dataTbPartitionNum = dataTbPartitionNum;
		this.userTbPartitionNum = userTbPartitionNum;
		this.hbaseCommitBatchSize = hbaseCommitBatchSize;
		this.shAk = shAk;
		this.gisGuavaCacheMaxSize = gisGuavaCacheMaxSize;
		this.expireHour = expireHour;
		this.carTableName = carTableName;
	}
	
	@Override
	public void open(Configuration parameters) throws Exception {
		super.open(parameters);
		
		org.apache.hadoop.conf.Configuration conf = HBaseConfiguration.create();
		
		conf.set("hbase.zookeeper.quorum", zkQuorum);
        conf.set("hbase.zookeeper.property.clientPort", zkPort);
        conf.set("zookeeper.znode.parent", zkParent);

		//conf.set("simple.user.name", userName);
		//conf.set("hbase.client.userprovider.class", "org.apache.hadoop.hbase.security.SimpleUserProvider");
		conf.set("hbase.client.retries.number", "11");

		connection = HBaseUtil.init(zkQuorum, zkPort, zkParent);

		//参考：https://www.cnblogs.com/ngy0217/p/8795634.html
//		gisCache = CacheBuilder.newBuilder().maximumSize(gisGuavaCacheMaxSize)
//				//当缓存项在指定的时间段内没有更新就会被回收
//				.expireAfterWrite(expireHour, TimeUnit.HOURS)
//				.recordStats()
//				.build(new CacheLoader<String, Integer>() {
//					@Override
//					public Integer load(String key) throws Exception {
//						//当key对应的value不存在时，返回 null;
//						return null;
//					}
//				});
	}

	/**
	 * @param value 从kafka接收的每一条记录都是数组，数组中的每一个原始都是一条gps记录   [{},{},},{}...]
	 * @throws Exception
	 */
	@Override
	public void invoke(String value) throws Exception {
		if(!org.apache.commons.lang3.StringUtils.isEmpty(value)) {
			try {
				//解析数组
				//System.out.println(value);
				//List<Map<String, String>> contentList = JsonUtil.readList(value);
				JSONArray jsonArray = JSON.parseArray(value);

				//将轨迹点写出到hbase
				if(jsonArray != null && !jsonArray.isEmpty()) {
					putList(jsonArray);
				}

				//打印缓存命中情况
				//logCacheState();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 打印缓存命中情况
	 */
	private void logCacheState() {
		logger.info("**** gisCache stat info:{}", gisCache.stats());
	}

	public void putList(List<Map<String, String>> mapList) {

	}

	public void putList(JSONArray jsonArray) {
		List<String> hbase_sh_ak_list = new ArrayList<String>();
		//String[] hbase_sh_ak_arr = "6,7,8,9,10,11,12,13,14,15,16,17,18,19,23,24".split(",");
		String[] hbase_sh_ak_arr = shAk.split(",");
		for(String line : hbase_sh_ak_arr) {
			hbase_sh_ak_list.add(line);
		}

		Table table_human = null;
		Table table_du = null;
		Table table_car = null;

		Map<String, Map<String, String>> valueHumanMap = new HashMap<String, Map<String, String>>();
//		Map<String, Map<String, String>> valueMapSH = new HashMap<String, Map<String, String>>();
		Map<String, Map<String, String>> valueMapCar = new HashMap<String, Map<String, String>>();

		//统计每天不同的用户列表，设备号任一条都可以
		Map<String, Map<String, String>> valueMapDateUser = new HashMap<String, Map<String, String>>();

//		String logTableName = logTableName;

		try {
			table_human = connection.getTable(TableName.valueOf(dataTableName));
			table_du = connection.getTable(TableName.valueOf(userTableName));
			table_car = connection.getTable(TableName.valueOf(carTableName));
			long index = 0;

			Iterator it = jsonArray.iterator();
//            System.out.println("-------------------------------------data start---------------------"+DateUtil.getCurrDatetime());
            while(it.hasNext()) {
				Map<String, String> mapTemp = new HashMap<String, String>();

				try {
					Map<String, Object> map = (Map)it.next();

					Set<String> keySet = map.keySet();
					Iterator<String> keySetIt = keySet.iterator();
					while(keySetIt.hasNext()) {
						String key = keySetIt.next();
						String value = map.get(key).toString();
						String valueTemp = value.replace("\"", "");
						mapTemp.put(key, valueTemp);
//                        System.out.println(key+"="+valueTemp);
                    }

					map.clear();

					//时间戳
					String tm = mapTemp.get("tm");
					//用户工号
					String un = mapTemp.get("un");
					//设备id
					String id = mapTemp.get("id");
					//传入时间戳，得到类似格式：20160223,推送过来的数据只到秒级,需要*1000，做到毫秒
					long tmTemp = Long.parseLong(tm)*1000;
					String trunc = DateUtil.truncTime(tmTemp+"");

					String ak = mapTemp.get("ak");

					//100个预分区
					String md5Key = un + "_" + trunc + "_" +ak ;
//					System.out.println("un="+un+",trunc="+trunc+",ak="+ak);
					String rowkey = SaltUtil.generateSaltNew(md5Key, dataTbPartitionNum) + "_" + MD5Util.getMD5(md5Key).toLowerCase() + "_" + tm;

//                    System.out.println("rowKey="+rowkey);


//					//舒华项目数据
//					if(hbase_sh_ak_list.contains(ak)) {
//						valueMapSH.put(rowkey, mapTemp);
//					} else {
//						valueMap.put(rowkey, mapTemp);
//					}
					if(!"1".equals(ak)){
						valueMapCar.put(rowkey,mapTemp);
					} else {
						valueHumanMap.put(rowkey, mapTemp);
					}

					//统计每天不同的用户列表，设备号任一条都可以
					//20个预分区
					String rowkeyDateUser = SaltUtil.generateSalt(ak+trunc, userTbPartitionNum)+ "_" + ak + "_" + trunc + "_" + un + "_" + id;

					if(!valueMapDateUser.containsKey(rowkeyDateUser)) {
//						if(!getFromCache(rowkeyDateUser)) {
//							Map<String, String> mapDateUser = new HashMap<String, String>();
//							mapDateUser.put("un", un);
//							valueMapDateUser.put(rowkeyDateUser, mapDateUser);
//
//							gisCache.put(rowkeyDateUser, 1);
//						}
					}

					if(index != 0 && index%hbaseCommitBatchSize == 0) {
						if(!valueHumanMap.isEmpty()) {
							HBaseUtil.put(table_human, hbase_columnFamily, valueHumanMap);
							valueHumanMap.clear();
						}

						//舒华项目数据
//						if(!valueMapSH.isEmpty()) {
//							HBaseUtil.put(table, hbase_columnFamilySH, valueMapSH);
//							valueMapSH.clear();
//						}
						//car
						if(!valueMapCar.isEmpty()) {
							HBaseUtil.put(table_car, hbase_columnFamily, valueMapCar);
							valueMapCar.clear();
						}
						if(!valueMapDateUser.isEmpty()) {
							HBaseUtil.put(table_du, hbase_columnFamily, valueMapDateUser);
							valueMapDateUser.clear();
						}

						index = 0;
					}

					index = index + 1;
				} catch(Exception e) {
					HBaseUtil.putLog(logTableName, valueHumanMap, valueMapDateUser,valueMapCar, e);
					logger.info("===========================异常记录:" + mapTemp);
				}
			}

//            System.out.println("-------------------------------------data end---------------------"+DateUtil.getCurrDatetime());

			if(!valueHumanMap.isEmpty()) {
				HBaseUtil.put(table_human, hbase_columnFamily, valueHumanMap);
				valueHumanMap.clear();
			}

			//舒华项目数据
//			if(!valueMapSH.isEmpty()) {
//				HBaseUtil.put(table, hbase_columnFamilySH, valueMapSH);
//				valueMapSH.clear();
//			}
			//car
			if(!valueMapCar.isEmpty()) {
				HBaseUtil.put(table_car, hbase_columnFamily, valueMapCar);
				valueMapCar.clear();
			}
			if(!valueMapDateUser.isEmpty()) {
				HBaseUtil.put(table_du, hbase_columnFamily, valueMapDateUser);
				valueMapDateUser.clear();
			}
		} catch(Exception e) {
			e.printStackTrace();

			try {
				HBaseUtil.putLog(logTableName, valueHumanMap, valueMapDateUser,valueMapCar, e);
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		} finally {
			//保证关闭连接
			IOUtils.closeStream(table_human);
			IOUtils.closeStream(table_du);
			IOUtils.closeStream(table_car);
		}
	}

	private Map<String, String> castToMap(Object obj) {
		Map<String, String> map = null;
		try {
			map = (Map)obj;
		} catch (Exception e) {
		}

		return map;
	}

//	private boolean getFromCache(String rowKey) {
//		boolean exists = false;
//		try {
////			Integer v = gisCache.get(rowKey);
//			if(gisCache!=null && gisCache.get(rowKey) != null) {
//				exists = true;
//			}
//		} catch(Exception e) {
//			e.printStackTrace();
//		}
//
//		return exists;
//	}

	@Override
	public void close() throws Exception {
		//IOUtils.closeStream(connection);
	}

}
