package com.sf.scala.tloc.onsiteapp

import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-05-16  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之竞对数据预处理
 */
object ClimbBuildingDiscernCompetitor {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )

    val saveClimbBuildingKey = Array( "waybill_no","aoi_id","copyphonetime","copy_sign_time","toujingye","toujingye_brand","toujingye_dis","date_time_timestamp")
    val saveClimbBuildingTmpKey = Array("source_kt","waybill_no","dept_code","emp_code","addr","phone","floor","addr_new","signin_time","aoiid","building","lngbuild","latbuild","lng80","lat80","outaoi","outbuilding","step","doing","onsite","tag")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val end_day=args(1)

        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取爬楼识别竞对站点信息数据")
        val dataRdd = getCompetitor(sparkSession,end_day)
        logger.error("开始存储爬楼识别竞对站点数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_competitor_info",Array(("inc_day", end_day)), 25)

    }

    def getCompetitor(spark:SparkSession,end_day:String)={

        var sql=
            s"""
              |
              | select
              |waybill_no
              |,a.trajectory_data
              |,a.date_time_timestamp
              |,a.aoi_id
              |,b.station_brand_list
              |,c.copyphonetime
              |,case when c.copyphonetime is not null and c.copyphonetime <>'' then cast(abs(c.copyphonetime - date_time_timestamp) as string) else '' end as copy_sign_time
              |from
              |(select waybill_no,trajectory_data,date_time_timestamp,aoi_id from tmp_dm_gis.gis_onsite_service_trajectory_info  where inc_day='$end_day' ) a
              |left join
              |(
              |select aoi_id,concat_ws(';',collect_set(concat(longitude,'_',latitude,'_',station_brand))) as station_brand_list
              |from
              |  dm_gis.competitor_result
              | where inc_day in (select inc_day from dm_gis.competitor_result order by inc_day desc limit 1)
              | and has_station = '1'
              | and station_status = '1'
              | and station_brand not in ('CN','CNYZ','CNGZ')
              | group by aoi_id
              |) b on a.aoi_id=b.aoi_id
              |left join
              |(select properties_waybillno,substr(max(nvl(properties_operatime,'')),0,10) as copyphonetime from dm_sfxg.product_inc_ubas_next_app where inc_day='$end_day'  and event_id='21510' and properties_waybillno is not null and properties_waybillno<>'' group by properties_waybillno) c on a.waybill_no=c.properties_waybillno
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,8000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val copy_sign_time=obj.getString("copy_sign_time")
            var distance=(-1.0)
            var station_brand=""
            var toujingye="0"
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_data")
                val station_brand_list = obj.getString("station_brand_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    for (trajectory <- trajectory_list.split(";")) {
                        if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                            if (trajectory.split("_")(2).nonEmpty && trajectory.split("_")(2).toLong >= (date_time_timestamp.toLong - 30) && trajectory.split("_")(2).toLong <= (date_time_timestamp.toLong + 30)&&trajectory.split("_")(3).nonEmpty&&trajectory.split("_")(3).toInt<=50) {
                                val zx = trajectory.split("_")(0)
                                val zy = trajectory.split("_")(1)
                                if(StringUtils.nonEmpty(station_brand_list)&&station_brand_list.split(";").length>0){
                                    for(station_brand_data<-station_brand_list.split(";")){
                                        val dis=try{
                                            GeometryUtil.getDistance(zx,zy,station_brand_data.split("_")(0),station_brand_data.split("_")(1))
                                        }catch {
                                            case e:Exception=>{
                                                logger.error("error "+e.getMessage)
                                                -1.0
                                            }
                                        }
                                        if(distance>=0.0){
                                            if(distance<dis){
                                                distance=dis
                                                station_brand=station_brand_data.split("_")(2)
                                            }
                                        }else{
                                            distance=dis
                                            station_brand=station_brand_data.split("_")(2)

                                        }


                                    }

                                }
                            }
                        }
                    }
                }
            }

            if(StringUtils.nonEmpty(copy_sign_time)&&copy_sign_time.toDouble<3000.0&&distance>=0.0&&distance<=80){
                toujingye="1"
                obj.put("toujingye_dis", distance)

            }else{
                station_brand=""

            }
            obj.put("toujingye", toujingye)
            obj.put("toujingye_brand", station_brand)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }



}
