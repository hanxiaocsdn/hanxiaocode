package com.sf.scala.tloc.onsiteapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.scala.tloc.onsiteapp.ClimbBuildingDiscern.getHour
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks._

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-05-26  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之路随网运单单独处理
 */
object ClimbBuildingDiscernRoadWaybillJudge {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val CoorAoiDist="http://sds-core-datarun.int.sfcloud.local/datarun/aoi/getCoorAoiDist?aoiId=%s&x=%s&y=%s&type=side"
    val saveClimbBuildingKey = Array("waybill_no","dest_zone_code","dest_dist_code","dest_city_code","dest_county","dest_division_code","dest_area_code","dest_hq_code","dest_type_code","emp_code","signer_name","date_time","consignee_comp_name","consignee_addr","decrypt_phone","consignee_phone","consignee_cont_name","decrypt_mobile","consignee_mobile","inner_parcel_flag","self_send_flag","self_pickup_flag","delivery_lgt","delivery_lat","dest_province","aoi_id","aoi_name","aoi_address","aoi_type_code","aoi_type_name","aoicode","outaoi")
    val saveClimbBuildingMidKey = Array("waybill_no","dest_zone_code","dest_dist_code","dest_city_code","dest_county","dest_division_code","dest_area_code","dest_hq_code","dest_type_code","emp_code","signer_name","date_time","consignee_comp_name","consignee_addr","decrypt_phone","consignee_phone","consignee_cont_name","decrypt_mobile","consignee_mobile","inner_parcel_flag","self_send_flag","self_pickup_flag","delivery_lgt","delivery_lat","dest_province","aoi_id","aoi_name","aoi_address","aoi_type_code","aoi_type_name","aoicode")

    val atdispatchUrl="http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&company=%s&ak=d4c3a0f6ed0044df8c1e4f0cc1dbfe6f"
    def main(args: Array[String]): Unit = {
        val target_table=args(0)
//        val start_day=args(1)
        val end_day=args(1)
        val start_day=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val aoiInfoBroadCastMap: Broadcast[collection.Map[String, String]] = getAoiCodeInfo(sparkSession)
        logger.error("获取爬楼识别数据")
        val dataRdd =judgeRoadWaybill(sparkSession,end_day,start_day,aoiInfoBroadCastMap)
        logger.error("开始存储爬楼识别轨迹数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingMidKey, "tmp_dm_gis.gis_onsite_service_road_waybill_info_mid",Array(("inc_day", end_day)), 25)
        logger.error("开始跑路随网点outaoi判定数据")
        val resultRdd = judgeOutAoi(sparkSession, end_day)
        logger.error("开始存储不上门路随网数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_road_waybill_info",Array(("inc_day", end_day)), 25)

    }



    def judgeRoadWaybill(spark:SparkSession,end_day:String,start_day:String,aoiInfoBroadCastMap: Broadcast[collection.Map[String, String]])={
        var sql=
            s"""
              |
              |select a.*,c.dist_cn_name as city_name
              |from
              |(select * from tmp_dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and dest_dist_code='755' and waybill_no is not null and waybill_no<>'') a
              |inner join
              |(select req_waybillno,req_destcitycode,finalaoiid,finalaoidetailsrc from dm_gis.gis_rds_omsto where inc_day<='$end_day' and inc_day>'$start_day' and finalaoidetailsrc='road') b
              |on a.waybill_no=b.req_waybillno and a.dest_dist_code=b.req_destcitycode and a.aoi_id=b.finalaoiid
              |left join (select dist_city_code,dist_cn_name from dim.dim_pub_district_info_df where inc_day='$end_day' and dist_type_en='City' group by dist_city_code,dist_cn_name ) c
              |on a.dest_dist_code=c.dist_city_code
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01407499", "692265", "不上门模型-路随网点数据", "", atdispatchUrl, "d4c3a0f6ed0044df8c1e4f0cc1dbfe6f", dataRdd.count(), 20)

        val aoiRdd = dataRdd.mapPartitionsWithIndex((index, iter) => {
            val aoiInfoMap = aoiInfoBroadCastMap.value
            for (obj <- iter) yield {
                val dist_city_code = obj.getString("dest_dist_code")
                val city_name = obj.getString("city_name")
                val dest_county = obj.getString("dest_county")
                val consignee_addr = obj.getString("consignee_addr")
                val consignee_comp_name = obj.getString("consignee_comp_name")
                if(StringUtils.nonEmpty(consignee_addr)){
                    val (aoi_id, aoi_code) = getAtdispatch(consignee_addr, dist_city_code, consignee_comp_name, city_name, dest_county)
                    if (aoiInfoMap.contains(aoi_id)) {
                        obj.put("aoi_name", aoiInfoMap.get(aoi_id).get.split("\001")(0))
                        obj.put("aoi_type_code", aoiInfoMap.get(aoi_id).get.split("\001")(1))
                    } else {
                        obj.put("aoi_name", "")
                        obj.put("aoi_type_code", "")
                    }
                    obj.put("aoi_address", "")
                    obj.put("aoi_type_name", "")
                    obj.put("aoi_id", aoi_id)
                    obj.put("aoicode", aoi_code)

                }

                obj
            }

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("更新路随网点aoi信息---》"+aoiRdd.count())
        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)
        aoiRdd

    }

    def judgeOutAoi(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select a.*,d.trajectory_data,d.date_time_timestamp from
              |(select * from tmp_dm_gis.gis_onsite_service_road_waybill_info_mid where inc_day='$end_day') a
              |left join (select * from tmp_dm_gis.gis_onsite_service_trajectory_info where inc_day='$end_day') d on a.waybill_no=d.waybill_no
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiUpdateRdd = dataRdd.mapPartitionsWithIndex((index, iter) => {
            for (obj <- iter) yield {
                val aoi_id = obj.getString("aoi_id")
                val trajectory_list = obj.getString("trajectory_data")
                val date_time_timestamp = obj.getString("date_time_timestamp")
                var outaoi = "-1"
                val array = new JSONArray()
                if (date_time_timestamp != null && date_time_timestamp.nonEmpty) {
                    if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                        val trajectory_arr: Array[String] = trajectory_list.split(";")
                        //排序
                        val trajectory_sort_list = sortTrajectory_list(trajectory_arr, date_time_timestamp)
                        var outaoicnt = 0L
                        var allcnt = 0L
                        breakable {
                            for (trajectory <- trajectory_sort_list) {
                                if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 3) {
                                    if (trajectory.split("_")(3).nonEmpty && trajectory.split("_")(3).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(3).toLong <= (date_time_timestamp.toLong + 180)) {
                                        val temObj = new JSONObject()
                                        allcnt += 1
                                        var zx = trajectory.split("_")(1)
                                        var zy = trajectory.split("_")(2)
                                        if (zx.nonEmpty && zy.nonEmpty && aoi_id.nonEmpty) {
                                            val distace = getAoiDistance(aoi_id, zx, zy).toDouble
                                            temObj.put("aoi_id",aoi_id)
                                            temObj.put("zx",zx)
                                            temObj.put("zy",zy)
                                            temObj.put("distace",distace)
                                            array.add(temObj)
                                            //                                            array.put(temObj)
                                            if (distace <= 100.0) {
                                                outaoi = "0"
                                                break
                                            } else if (distace > 100.0) {
                                                outaoicnt += 1
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (outaoicnt >= 5 && aoi_id.nonEmpty && (!outaoi.equals("0"))) {
                            outaoi = "1"

                        } else if (outaoi.equals("0")) {
                            outaoi = "0"
                        } else {
                            outaoi = "-1"
                        }
                    }
                }
                obj.put("outaoi", outaoi)
                obj.put("decrypt_phone", array)
                obj.put("decrypt_mobile", date_time_timestamp)
                obj

            }

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("更新路随网点outaoi信息---》"+aoiUpdateRdd.count())
        aoiUpdateRdd

    }

    def sortTrajectory_list(trajectoryArr:Array[String],date_time_timestamp:String)={
        val listBuffer: ListBuffer[String] = ListBuffer()
        for (trajectory <- trajectoryArr) {
            if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                if(trajectory.split("_")(2).nonEmpty){
                    val time_diff = math.abs(trajectory.split("_")(2).toLong - date_time_timestamp.toLong)
                    val trajectory_new=time_diff.toString+"_"+trajectory
                    listBuffer+=trajectory_new
                }
            }
        }
        listBuffer.sortBy(x => x).toArray

    }

    def getAoiDistance(aoiid:String,x:String,y:String)={
        val url = String.format(CoorAoiDist, aoiid,x,y)
        //接口访问限制 每分钟5000
        var nowHour = getHour()

        if(!(nowHour>=21||(nowHour>=0&&nowHour<9))){
            Thread.sleep(50)
        }else{
            Thread.sleep(30)
        }

        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case _=>{
                logger.error("error url-----> "+url)
                null
            }
        }
        var distance=JSONUtil.getJsonVal(jSONObject,"data","")

        if(distance.isEmpty){
            logger.error("erredata----->"+jSONObject)
            distance="100"
        }
        //        logger.error("y---->"+y+"x---->"+x+"---aoiid is " +aoiid+"aoi distance is "+distance)
        distance
    }

    def getAtdispatch(addr:String,city:String,company:String,cityName:String,district:String)={



        var nowHour = getHour()
//        while (!(nowHour>=22||(nowHour>=0&&nowHour<7))){
//            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
//            Thread.sleep(1000*60)
//            nowHour = getHour()
//
//        }

        Thread.sleep(270)
        val url=String.format(atdispatchUrl,URLEncoder.encode(addr,"utf-8"),city,company)
        val response = HttpInvokeUtil.sendGet(url, "utf-8", 5)
        var aoi_id=""
        var aoi_code=""
//        logger.error(" at派 服务result is --->"+response)
        if(StringUtils.nonEmpty(response)){
            var jsonObj=try{
                JSON.parseObject(response).getJSONObject("result")
            }catch{
                case e:Exception=>{
                    logger.error("error url ----->"+url+"  error data --->"+response)
                    new JSONObject()
                }
            }
            var resultObject=new JSONObject()
            if(!jsonObj.isEmpty) {
                try{
                    resultObject = jsonObj.getJSONArray("tcs").getJSONObject(0)
                }catch {case e:Exception=>{
                    logger.error("get at pai data erro-->"+e.getMessage)
                }}

            }
            aoi_id=JSONUtil.getJsonVal(resultObject,"aoiid","")
            aoi_code=JSONUtil.getJsonVal(resultObject,"aoicode","")
        }
        (aoi_id,aoi_code)

    }

    def getAoiCodeInfo(spark:SparkSession)={


        var sql="select aoi_id,aoi_name,fa_type from dm_gis.cms_aoi_sch"
        logger.error("aoi信息"+sql)
        val (originRdd, columns) = SparkRead.readHiveAsJson(spark, sql)
        val aoiInfoMap: collection.Map[String, String] = originRdd.map(obj => {
            val aoi_id = obj.getString("aoi_id")
            val aoi_name = obj.getString("aoi_name")
            val fa_type = obj.getString("fa_type")
            (aoi_id, aoi_name+"\001"+fa_type)

        }).collectAsMap()

        val aoiInfoMapBroadcast: Broadcast[collection.Map[String, String]] = spark.sparkContext.broadcast(aoiInfoMap)
        aoiInfoMapBroadcast

    }

}
