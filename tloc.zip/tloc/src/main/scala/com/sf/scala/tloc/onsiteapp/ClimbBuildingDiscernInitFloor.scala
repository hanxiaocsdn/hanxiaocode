package com.sf.scala.tloc.onsiteapp

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.scala.tloc.onsiteapp.ClimbBuildingDiscern.getHour
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-12-29  16:25
 * @TaskId:958081
 * @TaskName:不上门模型之初始化楼层
 * @Description:每天更新当天未签收数据的楼层数据
 */
object ClimbBuildingDiscernInitFloor {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val CoorAoiDist="http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=d4c3a0f6ed0044df8c1e4f0cc1dbfe6f"
    val saveClimbBuildingKey = Array("waybill_no","dest_dist_code","consignee_addr","signin_tm","floor")
    val saveClimbBuildingMidKey = Array("dest_dist_code","consignee_addr","floor")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val start_day=args(1)
        val end_date=args(2)
        val mode=args(3)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        mode match {
            case "daily"=>updateDailyFloor(sparkSession,end_day)
            case "complete"=>completeFloor(sparkSession,end_day,start_day,end_date)
        }


    }

    def updateDailyFloor(sparkSession:SparkSession,end_day:String)={
        logger.error("获取爬楼识别楼层数据")
        val dataRdd = getFloor(sparkSession,end_day)
        logger.error("开始存储爬楼识别楼层数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "dm_gis.dm_onsite_waybill_floor_mid_data_di",Array(("inc_day", end_day)), 25)


    }

    def completeFloor(spark:SparkSession,end_day:String,start_day:String,end_date:String)={
        logger.error("获取爬楼识别楼层数据")
        val resultRdd = getFloorAll(spark, end_day, start_day, end_date)
        logger.error("开始存储爬楼识别楼层数据")
        SparkWrite.save2HiveStaticNew(spark, resultRdd, saveClimbBuildingKey, "dm_gis.dm_onsite_waybill_floor_info_di",Array(("inc_day", end_day)), 25)

    }


    def getFloorAll(spark:SparkSession,end_day:String,start_day:String,end_date:String)={
        var start=end_date+" 00:00:00"
        var end=end_date+" 23:59:59"

        var sql=
            s"""
              |
              |select a.*,b.floor,case when b.waybill_no is not null and b.waybill_no<>'' then '1' else '0' end as flag from
              |(select * from dm_gis.dm_waybill_pai_dtl_di where inc_day='$end_day' and dest_dist_code='755' ) a
              |left join
              |(select waybill_no,`floor` from dm_gis.dm_onsite_waybill_floor_mid_data_di where inc_day>='$start_day' and inc_day<='$end_day' and dest_dist_code='755' and signin_tm between '$start' and '$end' group by waybill_no,floor) b
              |on a.waybill_no=b.waybill_no
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val needrunDataRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("flag")) && x.getString("flag").equals("0"))
        val notNeedRunRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("flag")) && x.getString("flag").equals("1"))
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01407499", "734420", "不上门模型-楼层", "", CoorAoiDist, "d4c3a0f6ed0044df8c1e4f0cc1dbfe6f", needrunDataRdd.count(), 40)
        val resultRdd = needrunDataRdd.mapPartitionsWithIndex((index, iter) => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for(obj <- iter){
                try{
                    var floor=""
                    val consignee_addr = obj.getString("consignee_addr")
                    val citycode = obj.getString("dest_dist_code")
                    if(StringUtils.nonEmpty(consignee_addr)&&consignee_addr.matches("(.*)([0-9]|[\u4e00-\u9fa5]|室|楼|层|樓|栋|号|房)(.*)")){
                        floor= getFloorInterfaceData(consignee_addr, citycode)
                    }

                    obj.put("floor", floor)

                }catch {
                    case e:Exception=>logger.error(e.getMessage)
                }
                listBuffer+=obj
            }
            listBuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调用接口数据量----》"+resultRdd.count())
        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)
        resultRdd.union(notNeedRunRdd)

    }

    def getFloor(spark:SparkSession,end_day:String)={

        var sql=
            s"""
              |
              |
              |select waybill_no,dest_dist_code,consignee_addr
              |,case when addr_geo is not null and addr_geo<>'' and (addr_geo regexp '216' or addr_geo regexp '217') then '1' when addr_geo is not null and addr_geo<>'' then '0' else '-1' end as addr_flag ,
              |case when addr_geo is not null and addr_geo<>'' and (addr_geo regexp '216' or addr_geo regexp '217') then addr_geo  else '' end as addr_geo
              |
              |from dm_gis.dm_onsite_waybill_addr_mid_data_di where inc_day='$end_day'
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val df = spark.sql(sql)
        val columns = df.columns
        val dataRdd = df.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getString(i))
            }
            jObj
        })

        val joinFloorRdd=dataRdd.mapPartitionsWithIndex((index, iter) => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for(obj <- iter){
                try{
                    val addr_geo = obj.getString("addr_geo")
                    val addr_flag = obj.getString("addr_flag")
                    var floor=""
                    var islevel17=true


                    var (floor_g,islevel17_g) = parseJsonData(addr_geo)
                    islevel17=islevel17_g
                    floor=floor_g
                    if(StringUtils.nonEmpty(addr_flag)&&addr_flag.equals("0")){
                        islevel17=false
                    }
//                    if(!StringUtils.nonEmpty(floor)){
//                        val splitresult = obj.getString("splitresult")
//                        val (floor_s,islevel17flag)=checkAddrSplitResult(splitresult,islevel17)
//                        islevel17=islevel17flag
//                        floor=floor_s
//                    }
                    val consignee_addr = obj.getString("consignee_addr")
                    if(StringUtils.nonEmpty(consignee_addr)&&consignee_addr.matches("(.*)([0-9]|[\u4e00-\u9fa5]|室|楼|层|樓)(.*)")&&islevel17){
                        islevel17=true
                    }else{
                        islevel17=false
                    }
                    if(StringUtils.nonEmpty(consignee_addr)&&consignee_addr.matches("(.*)(丰巢|蜂巢|菜鸟|驿站|快递柜|快递点|快递架|快递合作点|快递站|快递室|快递箱|快递房|快递框|快递棚|快递桌子|快递小屋|快递间|包裹柜|包裹点|包裹架|包裹合作点|包裹站|包裹室|包裹箱|包裹房|包裹框|包裹棚|包裹桌子|包裹小屋|包裹间|顺丰站点|E站|兔喜|网点|柜子|代收点|慧湖|点部|服务室|货柜|货架|抽屉柜|云柜|自提柜|监控室|服务站|蜜罐|宜家|快递中心|淘宝|百世|美佳|幺零幺|优家|淘老大|便利|邮家|熊猫|金河|家乐美|物架|小蜜蜂|小兵|京东|顺丰点|门卫|门房|门岗|收发室|签收室|保安室|值班室|服务室|传达室)(.*)")&&(!consignee_addr.matches("(.*)(不要放|勿放|禁止放|勿投|别放|不要给我放|别给我放|拒绝放|拒放|勿存放|不放)(.*)"))) floor="1"
                    obj.put("floor", floor)
                    obj.put("islevel17",islevel17)
                    obj.remove(addr_geo)
                }catch {
                    case e:Exception=>logger.error(e.getMessage)
                }
                listBuffer+=obj
            }
            listBuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        val floorIsNotEmptyRdd = joinFloorRdd.filter(obj => StringUtils.nonEmpty(obj.getString("floor"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联数据获得楼层数据量----》"+floorIsNotEmptyRdd.count())
        val notLevel17Rdd = joinFloorRdd.filter(obj => !(StringUtils.nonEmpty(obj.getString("islevel17")) && obj.getString("islevel17").toBoolean)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("没有17级分词的--》"+notLevel17Rdd.count())
        val existLevel17Rdd = joinFloorRdd.filter(obj => (!StringUtils.nonEmpty(obj.getString("floor"))) && StringUtils.nonEmpty(obj.getString("islevel17")) && obj.getString("islevel17").toBoolean).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("存在17级分词的---》"+existLevel17Rdd.count())
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01407499", "734420", "不上门模型-楼层", "", CoorAoiDist, "d4c3a0f6ed0044df8c1e4f0cc1dbfe6f", existLevel17Rdd.count(), 40)

        val resultRdd = existLevel17Rdd.mapPartitionsWithIndex((index, iter) => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for(obj <- iter){
                try{
                    val consignee_addr = obj.getString("consignee_addr")
                    val citycode = obj.getString("dest_dist_code")
                    var floor= getFloorInterfaceData(consignee_addr, citycode)
                    obj.put("floor", floor)

                }catch {
                    case e:Exception=>logger.error(e.getMessage)
                }
                listBuffer+=obj
            }
            listBuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调用接口数据量----》"+resultRdd.count())
        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)
        dataRdd.unpersist()
        resultRdd.union(floorIsNotEmptyRdd).union(notLevel17Rdd)

    }




    def checkAddrSplitResult(splitresult:String,islevel17:Boolean)={
        var floor=""
        var level17flag=true
        if(StringUtils.nonEmpty(splitresult)){
            level17flag=false
            val splitResultArr = splitresult.split(",")
            for(i<-0 until splitResultArr.size) {
                val name_s = splitResultArr(i).split("\\^")(0)
                val level_s = splitResultArr(i).split("\\^")(1)
                if(level_s.equals("216")){
                    floor=name_s.replaceAll("[^x00-xff]","").replaceAll("[A-Za-z]","")
                }
                if(islevel17){
                    if(level_s.equals("217")){
                        level17flag=true

                    }
                }
            }

        }

        (floor,level17flag)


    }
    def parseJsonData(addr_geo:String)={
        var floor=""
        var islevel17=true
        val array = JSONUtil.getJsonArrayFromObject(JSONUtil.parseJSONObject(addr_geo), "result.addSplitInfo")
        if(array.size()>0){
            islevel17=false
            for(i <- 0 until array.size()){
                val level = array.getJSONObject(i).getString("level")
                val name = array.getJSONObject(i).getString("text")
                if(StringUtils.nonEmpty(level)&&level.equals("16")){
                    floor=name.replaceAll("[^x00-xff]","").replaceAll("[A-Za-z]","")
                    islevel17=true
                }else if(StringUtils.nonEmpty(level)&&level.equals("17")){
                    islevel17=true

                }

            }
        }
        (floor,islevel17)




    }



    def getFloorInterfaceData(addr:String,citycode:String): String ={

        var floor=""
        if(StringUtils.nonEmpty(addr)&&addr.matches("(.*)(丰巢|蜂巢|菜鸟|驿站|快递柜|快递点|快递架|快递合作点|快递站|快递室|快递箱|快递房|快递框|快递棚|快递桌子|快递小屋|快递间|包裹柜|包裹点|包裹架|包裹合作点|包裹站|包裹室|包裹箱|包裹房|包裹框|包裹棚|包裹桌子|包裹小屋|包裹间|顺丰站点|E站|兔喜|网点|柜子|代收点|慧湖|点部|服务室|货柜|货架|抽屉柜|云柜|自提柜|监控室|服务站|蜜罐|宜家|快递中心|淘宝|百世|美佳|幺零幺|优家|淘老大|便利|邮家|熊猫|金河|家乐美|物架|小蜜蜂|小兵|京东|顺丰点|门卫|门房|门岗|收发室|签收室|保安室|值班室|服务室|传达室)(.*)")&&(!addr.matches("(.*)(不要放|勿放|禁止放|勿投|别放|不要给我放|别给我放|拒绝放|拒放|勿存放|不放)(.*)"))){
            floor="1"
            return floor
        }

        var nowHour = getHour()
        while (nowHour>=7&&nowHour<9){
            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
            Thread.sleep(1000*60)
            nowHour = getHour()
        }
        val url = String.format(CoorAoiDist, URLEncoder.encode(addr,"utf-8"),citycode)
        //接口访问限制 每分钟5000
        Thread.sleep(65)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case _=>{
                logger.error("error url-----> "+url)
                null
            }
        }
//        logger.error(jSONObject)
        floor=JSONUtil.getJsonVal(jSONObject,"result.data.floor","")
        floor

    }


}
