package com.sf.scala.tloc.onsiteapp

import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:674932
 * @TaskName:不上门模型
 * @Description:不上门模型之wifi数据预处理
 */
object ClimbBuildingDiscernEwl {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveClimbBuildingKey = Array( "waybill_no","dest_zone_code","dest_dist_code","dest_county","emp_code","consignee_addr","date_time","ewl_data")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val start_day=args(1)
        val end_day=args(2)
        val citycode=args(3)
        val tm_diff=args(4)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取爬楼识别数据")
        val dataRdd = getTrajectory(sparkSession,start_day,end_day,citycode,tm_diff)

//        val dataRdd = getTrajectoryTest(sparkSession,start_day,end_day,citycode,tm_diff)
        logger.error("开始存储爬楼识别轨迹数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, target_table,Array(("inc_day", end_day)), 25)

    }

    def getTrajectory(spark:SparkSession,start_day:String,end_day:String,citycode:String,tm_diff:String)={

        var sql=
            s"""
              |
              |select
              | waybill_no
              | ,dest_zone_code
              | ,dest_dist_code
              | ,dest_county
              | ,consignee_addr
              | ,emp_code
              | ,date_time
              | ,aoicode
              | ,aoi_id
              | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
              | ,trajectory_list
              | from
              | (select * from dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and dest_dist_code regexp '$citycode' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
              | left join (select un,concat_ws('tttt',collect_set(concat(timestamp,'_',ewl))) as trajectory_list  from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day'  and ewl<>'' and ewl is not null and un is not null and un<>'' group by un) d on a.emp_code=d.un
              |
              |""".stripMargin

        if(StringUtils.nonEmpty(citycode)&&citycode.equals("all")){
            sql=
                s"""
                   |
                   |select
                   | waybill_no
                   | ,dest_zone_code
                   | ,dest_dist_code
                   | ,dest_county
                   | ,consignee_addr
                   | ,emp_code
                   | ,date_time
                   | ,aoicode
                   | ,aoi_id
                   | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
                   | ,trajectory_list
                   | from
                   | (select * from dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and dest_dist_code !regexp '852|853|886' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
                   | left join (select un,concat_ws('tttt',collect_set(concat(timestamp,'_',ewl))) as trajectory_list  from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day'  and ewl<>'' and ewl is not null and un is not null and un<>'' group by un) d on a.emp_code=d.un
                   |
                   |""".stripMargin

        }

        //and regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode'
        //and ac<100
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,8000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val trajectorySet = new mutable.HashSet[String]()
            var trajectory_data=""
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split("tttt").length > 0) {
                    for (trajectory <- trajectory_list.split("tttt")) {
                        if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 1) {
                            if (trajectory.split("_")(0).nonEmpty && trajectory.split("_")(0).toLong >= (date_time_timestamp.toLong - tm_diff.toLong) && trajectory.split("_")(0).toLong <= (date_time_timestamp.toLong + tm_diff.toLong)) {
                                if(trajectory.split("_")(1)!=null&&trajectory.split("_")(1).nonEmpty){
                                    trajectorySet.add(trajectory.split("_")(1))
//                                    try{
//                                        val trajectoryjson = JSON.parseArray(trajectory.split("_")(1))
//                                        for(i <- 0 until trajectoryjson.size() ){
//                                            trajectorySet.add(trajectoryjson.getJSONObject(i).toString())
//                                        }
//                                    }catch {case e:Exception=>logger.error("error reason"+e.getMessage+"erre ewl data--->"+trajectory)}



                                }

                            }
                        }
                    }
                }
            }
            if(trajectorySet.size>0){
                trajectory_data=trajectorySet.mkString("|")
            }
//            trajectory_data="["+trajectory_data+"]"
            obj.put("ewl_data", trajectory_data)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }


    def getTrajectoryTest(spark:SparkSession,start_day:String,end_day:String,citycode:String,tm_diff:String)={

        var sql=
            s"""
               |
               |select
               | waybill_no
               | ,dest_zone_code
               | ,dest_dist_code
               | ,dest_county
               | ,consignee_addr
               | ,emp_code
               | ,date_time
               | ,aoicode
               | ,aoi_id
               | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
               | ,trajectory_list
               | from
               | (select * from dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and dest_dist_code regexp '$citycode' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
               | left join (select un,concat_ws('tttt',collect_set(concat(tm,'_',ewl))) as trajectory_list  from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day'  and ewl<>'' and ewl is not null and un is not null and un<>'' group by un) d on a.emp_code=d.un
               |
               |""".stripMargin

        sql=
            s"""
               |
               |select
               | waybill_no
               | ,dest_zone_code
               | ,dest_dist_code
               | ,dest_county
               | ,consignee_addr
               | ,emp_code
               | ,date_time
               | ,aoicode
               | ,aoi_id
               | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
               | ,trajectory_list
               | from
               | (select * from dm_gis.gis_onsite_service_info_v2 where inc_day='$start_day' and dest_dist_code regexp '$citycode' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
               | left join (select un,concat_ws('tttt',collect_set(concat(tm,'_',ewl))) as trajectory_list  from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$start_day'  and ewl<>'' and ewl is not null and un is not null and un<>'' group by un) d on a.emp_code=d.un
               |
               |""".stripMargin

        //and regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode'
        //and ac<100
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,8000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val trajectorySet = new mutable.HashSet[String]()
            var trajectory_data=""
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split("tttt").length > 0) {
                    for (trajectory <- trajectory_list.split("tttt")) {
                        if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 1) {
                            if (trajectory.split("_")(0).nonEmpty && trajectory.split("_")(0).toLong >= (date_time_timestamp.toLong - tm_diff.toLong) && trajectory.split("_")(0).toLong <= (date_time_timestamp.toLong)) {
                                if(trajectory.split("_")(1)!=null&&trajectory.split("_")(1).nonEmpty){
                                    trajectorySet.add(trajectory.split("_")(1))
                                    //                                    try{
                                    //                                        val trajectoryjson = JSON.parseArray(trajectory.split("_")(1))
                                    //                                        for(i <- 0 until trajectoryjson.size() ){
                                    //                                            trajectorySet.add(trajectoryjson.getJSONObject(i).toString())
                                    //                                        }
                                    //                                    }catch {case e:Exception=>logger.error("error reason"+e.getMessage+"erre ewl data--->"+trajectory)}



                                }

                            }
                        }
                    }
                }
            }
            if(trajectorySet.size>0){
                trajectory_data=trajectorySet.mkString("|")
            }
            //            trajectory_data="["+trajectory_data+"]"
            obj.put("ewl_data", trajectory_data)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }



}
