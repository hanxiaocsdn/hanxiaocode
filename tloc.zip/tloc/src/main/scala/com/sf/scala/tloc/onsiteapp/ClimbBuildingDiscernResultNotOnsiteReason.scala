package com.sf.scala.tloc.onsiteapp

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}
import scala.util.{Failure, Success, Try}

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:734517
 * @TaskName:不上门模型
 * @Description:不上门模型之最终结果关联V1.5
 */
object ClimbBuildingDiscernResultNotOnsiteReason {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    //TODO 新增字段：aoi_limit_cnt（事中弹窗未达AOI数据量）, poi_limit_cnt（事中弹窗未达POI数据量）
    val saveClimbBuildingKey = Array("waybill_no","dest_zone_code","dest_dist_code","dest_city_code","dest_county","dest_division_code","dest_area_code","dest_hq_code","dest_type_code","emp_code","signer_name","signin_tm","consignee_comp_name","consignee_addr","consignee_phone","consignee_cont_name","consignee_mobile","inner_parcel_flag","self_send_flag","self_pickup_flag","delivery_lgt","delivery_lat","dest_province","aoi_id","aoi_name","aoi_address","aoi_type_code","aoi_type_name","aoicode","floor","isclimb","addr_new","building","buildingid","lngbuild","latbuild","lng80","lat80","outaoi","istougui","iszhuanjituihui","iscopyphone","isfwsjg2g","isexternal","cntyizhan100","istjy","outbuilding","step","doing","wifi","wifi_aoi","out_wifi_aoi","wifi_poi","out_wifi_poi","wifi_floor","out_wifi_floor","deliver_address","is_phone_eff","onsite","tag","kesu_onsite","remark","kesu_tougui","kesu_chaping","kesu_toujingye","bianlidian","xingguanjia","copyphonetime","copy_sign_time","toujingye_dis","toujingye","toujingye_brand","yuyinzhijian","pianhao","bukeru","xiaoyuan","xingzhengcun","not_onsite_tag","aoi_area_code","aoi_area_type","onsite_source","doing_time","properties_scene","properties_type","properties_content","properties_time","buildingid_src")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val start_day=args(1)
        val end_day=args(2)
        val citycode=args(3)
        val from_table=args(4)
        val end_date=args(5)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("获取爬楼识别数据")
        val dataRdd = getAllResultData(sparkSession,start_day,end_day,citycode,from_table,end_date,aoiWhiteMapBroad,bldWhiteMapBroad)
        //        TODO 待解封后放开（新增字段：aoi_limit_cnt（事中弹窗未达AOI数据量）, poi_limit_cnt（事中弹窗未达POI数据量）），到时需给表增加两个字段
        //        logger.error("新增字段：事中弹窗未达AOI数据量,事中弹窗未达POI数据量")
        //        val aoiPoiCntRdd = getAoiPoiLimitCnt(sparkSession, end_day, dataRdd)
        logger.error("开始存储爬楼识别数据")
        //        SparkWrite.save2HiveStatic(sparkSession, dataRdd, saveClimbBuildingKey, "dm_gis.gis_onsite_keti",null, 25)
        //dm_gis.gis_onsite_service_v2
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service",Array(("inc_day", end_day)), 25)

        //        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "dm_gis.gis_onsite_service_v3",Array(("inc_day", end_day)), 600)



    }


    def getBulidingWkt(spark:SparkSession)={
        var sql="select wkt,buildingId from dm_gis.building_info "
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val buildingMap: Map[String, String] = originRdd.map(obj => {
            val buildingId = obj.getString("buildingId")
            val wkt = obj.getString("wkt")
            (buildingId, wkt)

        }).collect().toMap
        spark.sparkContext.broadcast(buildingMap)

    }

    def getAoiWkt(spark:SparkSession)={
        var sql="select wkt,aoiid from dm_gis.building_info "
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiMap: Map[String, String] = originRdd.map(obj => {
            val aoiid = obj.getString("aoiid")
            val wkt = obj.getString("wkt")
            (aoiid, wkt)

        }).collect().toMap
        spark.sparkContext.broadcast(aoiMap)

    }

    def getAoiPoiLimitCnt(spark: SparkSession, date: String, dataRdd: RDD[JSONObject]): RDD[JSONObject] = {
        val startDate = DateUtil.getDaysBefore(date, 2)
        val endDate = DateUtil.getDaysBefore(date, -1)
        val lbs_log_pnsaoi_sql = s"select waybill_no,match_type from dm_gis.lbs_log_pnsaoi where inc_day between '$startDate' and '$endDate' and match_type in ('AOI_LIMIT','POI_LIMIT')"
        logger.error(lbs_log_pnsaoi_sql)
        val (lbsRdd, columns) = SparkRead.readHiveAsJson(spark, lbs_log_pnsaoi_sql)

        val aoiCntRdd = lbsRdd.filter(o => "AOI_LIMIT".equals(o.getString("match_type"))).map(o => (o.getString("waybill_no"), 1)).reduceByKey((o1, o2) => o1 + o2).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        val poiCntRdd = lbsRdd.filter(o => "POI_LIMIT".equals(o.getString("match_type"))).map(o => (o.getString("waybill_no"), 1)).reduceByKey((o1, o2) => o1 + o2).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("aoiCntRdd cnt:" + aoiCntRdd.count())
        logger.error("poiCntRdd cnt:" + poiCntRdd.count())
        lbsRdd.unpersist()

        val aoiPoiCntRdd = dataRdd.map(o => (o.getString("waybill_no"), o)).leftOuterJoin(aoiCntRdd).map(tp => {
            val left = tp._2._1
            val right = tp._2._2
            if (right.nonEmpty) {
                left.put("aoi_limit_cnt", right.get)
            }
            (left.getString("waybill_no"), left)
        }).leftOuterJoin(poiCntRdd).map(tp => {
            val left = tp._2._1
            val right = tp._2._2
            if (right.nonEmpty) {
                left.put("poi_limit_cnt", right.get)
            }
            left
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("aoiPoiCntRdd cnt:" + aoiPoiCntRdd.count())
        dataRdd.unpersist()
        aoiCntRdd.unpersist()
        poiCntRdd.unpersist()
        aoiPoiCntRdd
    }

    def getAllResultData(spark:SparkSession,start_day:String,end_day:String,citycode:String,from_table:String,end_date:String,aoiWhiteMapBroad:Broadcast[Map[String, String]],bldWhiteMapBroad:Broadcast[Map[String, String]])={
        val start=DateUtil.getDaysBefore(end_day,5)
        var sql=
            s"""
               |
               |select
               |a.*
               |,b.yuyinzhijian
               |,b.pianhao
               |,b.bukeru
               |,b.xingzhengcun
               |,b.not_onsite_tag
               |,l.floor
               |,c.aoi_area_code
               |,c.aoi_area_type
               |,cast(unix_timestamp(a.signin_tm,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
               |,d.kesu_onsite as kesu_onsite
               |,d.remark as remark
               |,d.kesu_tougui as kesu_tougui
               |,d.kesu_chaping as kesu_chaping
               |,d.kesu_toujingye as kesu_toujingye
               |,e.properties_type
               |,e.properties_content
               |,e.properties_time
               |,e.properties_scene
               |,case when i.waybill_no is not null then '1' else '0' end as istjy
               |from
               |(select waybill_no,dest_zone_code,dest_dist_code,dest_city_code,dest_county,dest_division_code,dest_area_code,dest_hq_code,dest_type_code,emp_code,signer_name,signin_tm,consignee_comp_name,consignee_addr,consignee_phone,consignee_cont_name,consignee_mobile,inner_parcel_flag,self_send_flag,self_pickup_flag,delivery_lgt,delivery_lat,dest_province,aoi_id,aoi_name,aoi_address,aoi_type_code,aoi_type_name,aoicode,isclimb,addr_new,building,buildingid,lngbuild,latbuild,lng80,lat80,outaoi,istougui,iszhuanjituihui,iscopyphone,isfwsjg2g,isexternal,cntyizhan100,outbuilding,step,doing,wifi,wifi_aoi,out_wifi_aoi,wifi_poi,out_wifi_poi,wifi_floor,out_wifi_floor,deliver_address,is_phone_eff,bianlidian,xingguanjia,copyphonetime,copy_sign_time,toujingye_dis,toujingye,toujingye_brand,doing_time,buildingid_src
               | from (
               |select *,cast(row_number()over(partition by waybill_no order by signin_tm desc) as string) as rnk from tmp_dm_gis.gis_onsite_service_mid_data where inc_day='$end_day'  and waybill_no<>''
               |) t
               |where t.rnk=1) a
               |left join (select * from tmp_dm_gis.gis_onsite_service_not_onsite_tag_info where inc_day='$end_day' and waybill_no<>'') b on a.waybill_no=b.waybill_no
               |left join (select floor,waybill_no from dm_gis.dm_onsite_waybill_floor_info_di where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' group by floor,waybill_no) l on a.waybill_no=l.waybill_no
               |left join (select aoi_id,aoi_area_code,aoi_area_type from dim.dim_aoi_info group by aoi_id,aoi_area_code,aoi_area_type) c on a.aoi_id=c.aoi_id
               |left join (select * from tmp_dm_gis.gis_onsite_service_kesu_info where inc_day='$end_day' ) d on a.waybill_no=d.waybill_no
               |left join (select waybillno,properties_type,properties_content,from_unixtime(cast (time/1000 as bigint)) as properties_time,properties['scene']  as properties_scene from (
               |select * ,row_number()over(partition by waybillno order by time desc ) rnk from dm_sfxg.product_inc_ubas_next_app where inc_day>='$start' and inc_day<='$end_date' and waybillno<>'' and event_id='1320'
               |) x
               |where x.rnk=1) e on a.waybill_no=e.waybillno
               |left join (select waybill_no from dm_gis.dm_lbs_tjy_detail_to_operation_di_new where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' group by waybill_no) i on a.waybill_no=i.waybill_no
               |
               |
               |""".stripMargin

        //dm_gis.gis_onsite_service_kesu_info
        logger.error(sql)
        //select waybill_no,concat_ws('|',collect_set(ewl_data)) wifi ,concat_ws(',',collect_set(aoi_id)) wifi_aoi,concat_ws(',',collect_set(bld_id)) wifi_poi,concat_ws(',',collect_set(regexp_replace(floor,'[A-Za-z\\u4e00-\\u9fa5]',''))) wifi_floor from $from_table where inc_day='$end_day' and aoi_rate>=0.9 and bld_rate>=0.9 and floor_rate>=0.9 group by waybill_no
        val (telRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,6000)
        val resultRdd = telRdd.map(obj => {
            val aoiWhiteMap = aoiWhiteMapBroad.value
            val bldWhiteMap = bldWhiteMapBroad.value
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val bulidType = obj.getString("bulidtype")
            val buildingid = obj.getString("buildingid")
            var isClimb = obj.getString("isclimb")
            var outbuilding = obj.getString("outbuilding")
            var aoiid = obj.getString("aoi_id")

            var onsite_source=""
            var wifi_poi = obj.getString("wifi_poi")
            var outaoi=obj.getString("outaoi")
            var wifi_aoi=obj.getString("wifi_aoi")
            var floor = obj.getString("floor")



            //istougui，iszhuanjituihui，istjy
            val istougui = obj.getString("istougui")
            val iszhuanjituihui = obj.getString("iszhuanjituihui")
            val istjy = obj.getString("istjy")

            val isfwsjg2g= obj.getString("isfwsjg2g")
            val bianlidian = obj.getString("bianlidian")
            val xingguanjia = obj.getString("xingguanjia")
            //            val toujingye = null
            val toujingye = obj.getString("toujingye")
            val wifi_floor = obj.getString("wifi_floor")
            val consignee_addr=obj.getString("consignee_addr")
            val doing_times=obj.getString("doing_time")
            val (out_wifi_aoi,out_wifi_poi,out_wifi_floor)=getwifiInfo(wifi_aoi,wifi_poi,wifi_floor,buildingid,aoiid,floor)

            var stepStr = obj.getString("step")
            var step=(-1L)
            if(stepStr!=null&&stepStr.nonEmpty){
                step=stepStr.toLong
            }
            var onsite = "-1"
            var tag = "null"
            var doing =obj.getString("doing")
            try{

                if(StringUtils.nonEmpty(floor)){
                    floor = obj.getString("floor").replaceAll("[A-Za-z]","")
                    if(floor.length>3||floor.toLong>100||(floor.toLong<(-2))){
                        floor=""
                    }

                }
                if(!(StringUtils.nonEmpty(floor)&&floor.toLong >= 2&&floor.toLong<=9)){
                    isClimb="0"
                    obj.put("isclimb",isClimb)
                }

                if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                    if(StringUtils.nonEmpty(bulidType)&&bulidType.equals("aoi_one")){
                        outbuilding=outaoi
                    }
                    /* step 计算 */
                    if(doing==null){
                        doing=""
                    }
                    val doingSet = doing.split(",").toSet

                    if (outaoi!=null&&outaoi.equals("1")) {
                        onsite = "0"
                        tag = "outaoi"
                        onsite_source="1-1"
                    }else if((outaoi!=null&&outaoi.equals("-1")&&out_wifi_aoi!=null&&out_wifi_aoi.equals("1")&&aoiWhiteMap.contains(wifi_aoi))){
                        onsite = "0"
                        tag = "outaoi"
                        onsite_source="1-2"

                    }
                    else if((istougui!=null&&istougui.equals("1"))||(istjy!=null&&istjy.equals("1"))||(bianlidian!=null&&bianlidian.equals("是"))||(xingguanjia!=null&&xingguanjia.equals("是"))){
                        onsite = "0"
                        tag = "outbuilding"
                        onsite_source="2-1"

                    }else if((toujingye!=null&&toujingye.equals("1"))){
                        onsite = "0"
                        tag = "outbuilding"
                        onsite_source="2-2"


                    }
                    else if ((outbuilding!=null&&outbuilding.equals("1"))) {
                        onsite = "0"
                        tag = "outbuilding"
                        onsite_source="2-3"
                    }else if(outbuilding!=null&&outbuilding.equals("-1")&&out_wifi_poi!=null&&out_wifi_poi.equals("1")&&bldWhiteMap.contains(wifi_poi)){
                        onsite = "0"
                        tag = "outbuilding"
                        onsite_source="2-5"
                    }
                    else if(outbuilding!=null&&outaoi!=null&&outaoi.equals("-1")&&outbuilding.equals("-1")){
                        onsite = "-1"
                        tag="null"
                        onsite_source="2-4"
                    }
                    //条件3
                    else if(StringUtils.nonEmpty(consignee_addr)&&consignee_addr.matches("(.*)(丰巢|蜂巢|菜鸟|驿站|快递柜|快递点|快递架|快递合作点|快递站|快递室|快递箱|快递房|快递框|快递棚|快递桌子|快递小屋|快递间|包裹柜|包裹点|包裹架|包裹合作点|包裹站|包裹室|包裹箱|包裹房|包裹框|包裹棚|包裹桌子|包裹小屋|包裹间|顺丰站点|E站|兔喜|网点|柜子|代收点|慧湖|点部|服务室|货柜|货架|抽屉柜|云柜|自提柜|监控室|服务站|蜜罐|宜家|快递中心|淘宝|百世|美佳|幺零幺|优家|淘老大|便利|邮家|熊猫|金河|家乐美|物架|小蜜蜂|小兵|京东|顺丰点|门卫|门房|门岗|收发室|签收室|保安室|值班室|服务室|传达室)(.*)")&&(!consignee_addr.matches("(.*)(不要放|勿放|禁止放|勿投|别放|不要给我放|别给我放|拒绝放|拒放|勿存放|不放)(.*)"))){
                        onsite = "0"
                        tag = "nofloor"
                        floor="1"
                        onsite_source="3-3"
                    }
                    //条件4
                    else if (isClimb!=null&&isClimb.equals("0")&&step!=null&&step >= 0 && step < 50&&doing.nonEmpty&&floor!=null&&floor.nonEmpty&& floor.toInt >= 3&&(!( doingSet.contains("4")))&&(doingSet.contains("0")||doingSet.contains("1")||doingSet.contains("2")||doingSet.contains("5"))&&judgeDoingTimes("0,1,2,5",doing_times)) {
                        //                    if ((!(doingSet.contains("3") || doingSet.contains("4")))&&(doingSet.contains("1")||doingSet.contains("2")||doingSet.contains("5"))) {
                        onsite = "0"
                        tag = "nofloor"
                        onsite_source="3-4"
                        //                    }
                    }
                    //条件5
                    else if (isClimb!=null&&isClimb.equals("0")&&floor!=null&&floor.nonEmpty && floor.toInt >= 3&&step>=50L&&doing!=null&doing.nonEmpty&&(doingSet.contains("4"))&&judgeDoingTimes("4",doing_times)) {
                        //                    if (doingSet.contains("3") || doingSet.contains("4")) {
                        onsite = "1"
                        tag = "standby"
                        onsite_source="3-5"
                        //                    }

                    }
                    //条件6
                    else if (isClimb!=null&&isClimb.equals("0")&&step >= 0 && step < 50&&doing.nonEmpty&&floor!=null&&floor.nonEmpty&& floor.toInt >= 1&&floor.toInt <= 2&&(!(doingSet.contains("3") || doingSet.contains("4")||doingSet.contains("2")))&&(doingSet.contains("0")||doingSet.contains("1")||doingSet.contains("5"))&&judgeDoingTimes("0,1,5",doing_times)) {
                        //                    if ((!(doingSet.contains("3") || doingSet.contains("4")||doingSet.contains("2")))&&(doingSet.contains("1")||doingSet.contains("5"))) {
                        onsite = "0"
                        tag = "nofloor"
                        onsite_source="3-6"
                        //                    }
                    }
                    //条件7
                    else if (isClimb!=null&&isClimb.equals("0")&&floor!=null&&floor.nonEmpty && floor.toInt >= 1&&floor.toInt <= 2&&step>=50&&doing!=null&doing.nonEmpty&&(doingSet.contains("3") || doingSet.contains("4")|| doingSet.contains("2"))&&judgeDoingTimes("3,4,2",doing_times)) {
                        //                    if (doingSet.contains("3") || doingSet.contains("4")|| doingSet.contains("2")) {
                        onsite = "1"
                        tag = "standby"
                        onsite_source="3-7"
                        //                    }

                    }
                    //条件8
                    else if (isClimb!=null&&isClimb.equals("1")&&doing!=null&&floor!=null&&floor.nonEmpty && floor.toInt >= 3&&step>=0&&step<(40+floor.toInt*10)&&(!((doingSet.contains("3")) || (doingSet.contains("4"))))&&(doingSet.contains("0")||doingSet.contains("1")||doingSet.contains("5")||(doingSet.contains("2")))&&judgeDoingTimes("0,1,2,5",doing_times)) {
                        //                    if ((!((doingSet.contains("3")) || (doingSet.contains("4"))||(doingSet.contains("2"))))&&(doingSet.contains("1")||doingSet.contains("5"))) {
                        onsite = "0"
                        tag = "nofloor"
                        onsite_source="3-8"
                        //                    }
                    }
                    //条件9
                    else if (isClimb!=null&&isClimb.equals("1")&&doing!=null&&floor!=null&&floor.nonEmpty && floor.toInt >= 3&&step>=(40+floor.toInt*10)&&(doingSet.contains("3") || doingSet.contains("4"))&&judgeDoingTimes("3,4",doing_times)) {
                        //                    if (doingSet.contains("3") || doingSet.contains("4")|| doingSet.contains("2")) {
                        onsite = "1"
                        tag = "standby"
                        onsite_source="3-9"
                        //                    }
                    }
                    //条件10
                    else if (isClimb!=null&&isClimb.equals("1")&&doing.nonEmpty&&floor!=null&&floor.nonEmpty&& floor.toInt >= 1&&floor.toInt <= 2&&step >= 0 && step < (40+floor.toInt*10)&&(!(doingSet.contains("3") || doingSet.contains("4")||doingSet.contains("2")))&&(doingSet.contains("0")||doingSet.contains("1")||doingSet.contains("5"))&&judgeDoingTimes("0,1,5",doing_times)) {
                        //                    if ((!(doingSet.contains("3") || doingSet.contains("4")||doingSet.contains("2")))&&(doingSet.contains("1")||doingSet.contains("5"))) {
                        onsite = "0"
                        tag = "nofloor"
                        onsite_source="3-10"
                        //                    }
                    }
                    //条件11
                    else if (isClimb!=null&&isClimb.equals("1")&&floor!=null&&floor.nonEmpty && floor.toInt >= 1&&floor.toInt <= 2&&step>=(40+floor.toInt*10)&&doing!=null&doing.nonEmpty&&(doingSet.contains("3") || doingSet.contains("4")|| doingSet.contains("2"))&&judgeDoingTimes("2,3,4",doing_times)) {
                        //                    if (doingSet.contains("3") || doingSet.contains("4")|| doingSet.contains("2")) {
                        onsite = "1"
                        tag = "standby"
                        onsite_source="3-11"
                        //                    }

                    }

                    //条件12
                    else if((!StringUtils.nonEmpty(isClimb))&&floor!=null&&floor.nonEmpty && floor.toInt >= 3&&step>=50L&&doing!=null&doing.nonEmpty&&(doingSet.contains("3") || doingSet.contains("4"))&&judgeDoingTimes("3,4",doing_times)){
                        onsite = "1"
                        tag = "standby"
                        onsite_source="3-12"

                    }
                    //条件13
                    else if((!StringUtils.nonEmpty(isClimb))&&floor!=null&&floor.nonEmpty &&floor.toInt >= 1&&floor.toInt <= 2&&step >= 0 && step < 50&&(!(doingSet.contains("3") || doingSet.contains("4")||doingSet.contains("2")))&&(doingSet.contains("0")||doingSet.contains("1")||doingSet.contains("5"))&&judgeDoingTimes("0,1,5",doing_times)){
                        onsite = "0"
                        tag = "nofloor"
                        onsite_source="3-13"

                    }
                    //条件3
                    else if(floor!=null&&floor.nonEmpty&&floor.equals("0")){
                        onsite = "-1"
                        tag="null"
                        onsite_source="3-2"

                    }
                    else{
                        onsite = "-1"
                        tag="null"
                        onsite_source="3-15"
                    }

                }else{
                    obj.put("date_time_timestamp","")

                }

                if(!(StringUtils.nonEmpty(floor)&&floor.toLong >= 2&&floor.toLong<=9)){
                    isClimb="0"
                    obj.put("isclimb",isClimb)
                }

            }catch {case e:Exception=>logger.error(e.getMessage)}

            obj.put("out_wifi_aoi",out_wifi_aoi)
            obj.put("out_wifi_poi",out_wifi_poi)
            obj.put("out_wifi_floor",out_wifi_floor)
            obj.put("outbuilding", outbuilding)
            obj.put("onsite", onsite)
            obj.put("floor",floor)
            obj.put("onsite_source",onsite_source)
            obj.put("tag", tag)
            obj
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算结果数据-----》"+resultRdd.count())
        telRdd.unpersist()
        val group_Rdd:RDD[((String, String), Iterable[JSONObject])] = resultRdd.groupBy(x => (x.getString("emp_code"),x.getString("consignee_phone")))
        val sortRdd = group_Rdd.map(x => (x._1, x._2.toList.sortBy(_.getString("date_time_timestamp"))))
        //        logger.error("计算结果数据1----》"+sortRdd.count())
        val dataRdd = sortRdd.flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var templistBuffer: ListBuffer[JSONObject] = ListBuffer()
            var date_time_timestamp = x._2.head.getString("date_time_timestamp")
            var phone = x._2.head.getString("consignee_phone")
            var onsite = x._2.head.getString("onsite")
            var tag = x._2.head.getString("tag")
            var floor=x._2.head.getString("floor")
            var onsite_source=x._2.head.getString("onsite_source")
            //            if(!(floor!=null&&(!floor.equals("0")))){
            //                tag="null"
            //                onsite="-1"
            //            }



            if( x._2.length>=2){
                tag="null"
                onsite="-1"
                onsite_source="3-15"
                for (index <- 0 until x._2.length) {

                    if(x._2(index).getString("tag") != null&&(x._2(index).getString("tag").equals("outbuilding")||x._2(index).getString("tag").equals("outaoi"))){
                        listBuffer += x._2(index)


                    }else if(x._2(index).getString("outaoi") != null&&x._2(index).getString("outaoi").equals("-1")&&x._2(index).getString("outbuilding") != null&&x._2(index).getString("outbuilding").equals("-1")&&x._2(index).getString("out_wifi_poi") != null&&x._2(index).getString("out_wifi_poi").equals("-1")){
                        listBuffer += x._2(index)

                    }
                    else{
                        if (date_time_timestamp != null && x._2(index).getString("date_time_timestamp") != null && date_time_timestamp.nonEmpty && x._2(index).getString("date_time_timestamp").nonEmpty) {
                            if (math.abs(date_time_timestamp.toLong - x._2(index).getString("date_time_timestamp").toLong) < 600) {
                                if(x._2(index).getString("floor")!=null&&(!x._2(index).getString("floor").equals("0"))){
                                    if(tag!=null&&(!tag.equals("null"))){
                                        templistBuffer+=x._2(index)
                                    }else{
                                        onsite = x._2(index).getString("onsite")
                                        tag = x._2(index).getString("tag")
                                        onsite_source=x._2(index).getString("onsite_source")
                                        templistBuffer+=x._2(index)
                                        //                        listBuffer += x._2(index)

                                    }

                                }else {
                                    templistBuffer+=x._2(index)

                                }
                            } else {
                                if(templistBuffer.size>0){
                                    var not_onsite_tag_9_flag=true
                                    for(i <-0 until templistBuffer.size){
                                        val obj = templistBuffer(i)
                                        if(!tag.equals("null")){
                                            if((StringUtils.nonEmpty(obj.getString("tag"))&&obj.getString("tag").equals(tag)&&StringUtils.nonEmpty(obj.getString("onsite_source"))&&obj.getString("onsite_source").equals(onsite_source))&&not_onsite_tag_9_flag){

                                                //                                                obj.put("tag",tag)
                                                not_onsite_tag_9_flag=false
                                            }else{
                                                obj.put("not_onsite_tag","9")

                                            }
                                            obj.put("tag",tag)
                                            obj.put("onsite",onsite)
                                            obj.put("onsite_source",onsite_source)

                                        }
                                        listBuffer +=obj

                                    }
                                }

                                templistBuffer=ListBuffer()
                                tag="null"
                                onsite="-1"
                                onsite_source="3-15"
                                date_time_timestamp = x._2(index).getString("date_time_timestamp")
                                if(x._2(index).getString("floor")!=null&&(!x._2(index).getString("floor").equals("0"))){
                                    onsite = x._2(index).getString("onsite")
                                    tag = x._2(index).getString("tag")
                                    onsite_source=x._2(index).getString("onsite_source")
                                }
                                phone = x._2(index).getString("consignee_phone")
                                templistBuffer+=x._2(index)
                                //                            listBuffer += x._2(index)
                            }
                        }else{
                            listBuffer += x._2(index)


                        }

                    }
                }

            }else{
                templistBuffer.append(x._2.head)
            }

            if(templistBuffer.size>0){
                var not_onsite_tag_9_flag=true
                for(i <-0 until templistBuffer.size){
                    val obj = templistBuffer(i)
                    if(!tag.equals("null")){
                        if((StringUtils.nonEmpty(obj.getString("tag"))&&obj.getString("tag").equals(tag)&&StringUtils.nonEmpty(obj.getString("onsite_source"))&&obj.getString("onsite_source").equals(onsite_source))&&not_onsite_tag_9_flag){


                            not_onsite_tag_9_flag=false
                        }else{
                            obj.put("not_onsite_tag","9")

                        }
                        obj.put("tag",tag)
                        obj.put("onsite",onsite)
                        obj.put("onsite_source",onsite_source)

                    }
                    listBuffer +=obj

                }
            }
            listBuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算结果数据-----》"+dataRdd.count())

        signFirstOrderOfOutAoi(dataRdd).distinct()


    }

    def signFirstOrderOfOutAoi(dataRdd: RDD[JSONObject])={
        val needSignRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("tag")) && StringUtils.nonEmpty(x.getString("not_onsite_tag")) && (x.getString("tag").equals("outaoi") || x.getString("tag").equals("outbuilding")) && x.getString("not_onsite_tag").equals("8"))
        val normalDataRdd = dataRdd.filter(x => !(StringUtils.nonEmpty(x.getString("tag")) && StringUtils.nonEmpty(x.getString("not_onsite_tag")) && (x.getString("tag").equals("outaoi") || x.getString("tag").equals("outbuilding")) && x.getString("not_onsite_tag").equals("8")))
        val group_Rdd:RDD[((String, String), Iterable[JSONObject])] = needSignRdd.groupBy(x => (x.getString("emp_code"),x.getString("consignee_phone")))
        val sortRdd = group_Rdd.map(x => (x._1, x._2.toList.sortBy(_.getString("date_time_timestamp"))))
        val signRdd = sortRdd.flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var templistBuffer: ListBuffer[JSONObject] = ListBuffer()
            var date_time_timestamp = x._2.head.getString("date_time_timestamp")
            if( x._2.length>=2){
                for (index <- 0 until x._2.length) {
                    if (date_time_timestamp != null && x._2(index).getString("date_time_timestamp") != null && date_time_timestamp.nonEmpty && x._2(index).getString("date_time_timestamp").nonEmpty) {
                        if (math.abs(date_time_timestamp.toLong - x._2(index).getString("date_time_timestamp").toLong) < 600) {
                            templistBuffer+=x._2(index)
                        } else {
                            if(templistBuffer.size>0){
                                for(i <-0 until templistBuffer.size){
                                    val obj = templistBuffer(i)
                                    if(i>0){
                                        obj.put("not_onsite_tag","9")

                                    }
                                    listBuffer +=obj
                                }
                            }
                            templistBuffer=ListBuffer()
                            date_time_timestamp = x._2(index).getString("date_time_timestamp")
                            templistBuffer+=x._2(index)
                        }
                    }else{
                        listBuffer += x._2(index)
                    }
                }
            }else{
                templistBuffer.append(x._2.head)
            }
            if(templistBuffer.size>0){
                for(i <-0 until templistBuffer.size){
                    val obj = templistBuffer(i)
                    if(i>0){
                        obj.put("not_onsite_tag","9")
                    }
                    listBuffer +=obj
                }
            }
            listBuffer
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算结果数据-----》"+signRdd.count())
        signRdd.union(normalDataRdd)


    }
    def getwifiInfo(wifi_aoi:String,wifi_poi:String,wifi_floor:String,buildingid:String,aoiid:String,floor:String)={
        var out_wifi_poi="1"
        var out_wifi_aoi="1"
        var out_wifi_floor="1"
        if(aoiid!=null&&aoiid.nonEmpty){
            if(wifi_aoi!=null&&wifi_aoi.nonEmpty){
                for(wifi_aoi_id<-wifi_aoi.split(",")){
                    if(wifi_aoi_id.equals(aoiid)){
                        out_wifi_aoi="0"
                    }

                }

            }else{
                out_wifi_aoi="-1"
            }
        }else{
            out_wifi_aoi="-1"
        }

        if(buildingid!=null&&buildingid.nonEmpty){
            if(wifi_poi!=null&&wifi_poi.nonEmpty){
                for(wifi_poi_id<-wifi_poi.split(",")){
                    if(wifi_poi_id.equals(buildingid)){
                        out_wifi_poi="0"
                    }

                }

            }else{
                out_wifi_poi="-1"
            }
        }else{
            out_wifi_poi="-1"
        }

        try {
            if(floor!=null&&floor.nonEmpty){
                if(wifi_floor!=null&&wifi_floor.nonEmpty){
                    for(wifi_floor_id<-wifi_floor.split(",")){
                        if(wifi_floor_id!=null&&wifi_floor_id.nonEmpty){
                            val floor_diff=math.abs(floor.toInt-wifi_floor_id.toInt)
                            if(floor_diff==1||floor_diff==0){
                                out_wifi_floor="0"
                            }
                        }
                    }
                }else{
                    out_wifi_floor="-1"
                }
            }else{
                out_wifi_floor="-1"
            }
        }catch {case e:Exception=>{
            out_wifi_floor="-1"


        }}




        (out_wifi_aoi,out_wifi_poi,out_wifi_floor)

    }






    def getTimestamp(s: String) : Option[Long] = s match {
        case "" => Some(0)
        case _ => {
            val format = new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss")
            Try(format.parse(s).getTime/1000) match {
                case Success(t) => Some(t)
                case Failure(_) => Some(0)
            }
        }
    }

    def getFingerWhite(spark:SparkSession)={
        var sql=
            """
              |
              |
              |select guid,`level`,in_use from (
              |select guid,`level`,in_use,row_number()over(partition by guid,`level` order by update_date desc ) rnk from dm_gis.gis_wifi_finger_white_list
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("aoi")).map(obj => {
            val guid = obj.getString("guid")
            val in_use = obj.getString("in_use")
            (guid, in_use)
        }).collect().toMap

        val bldWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("bld")).map(obj => {
            val guid = obj.getString("guid")
            val in_use = obj.getString("in_use")
            (guid, in_use)
        }).collect().toMap
        (spark.sparkContext.broadcast(aoiWhiteMap),spark.sparkContext.broadcast(bldWhiteMap))



    }

    def judgeDoingTimes(doings:String,doing_times:String)={
        var flag=false
        val doingArr = doings.split(",")
        val doingTimesArr = doing_times.split(",")
        breakable {
            if(doingArr.length>=1&&doingTimesArr.length>=1){
                for(i<-0 until(doingArr.size)){
                    for(j<-0 until(doingTimesArr.size)){
                        if(doingTimesArr(j).split(":")(0).equals(doingArr(i))){
                            if(doingTimesArr(j).split(":").size>1&&doingTimesArr(j).split(":")(1).toDouble>=0.1){
                                flag=true
                                break
                            }
                        }
                    }
                }
            }
        }
        flag

    }

}
