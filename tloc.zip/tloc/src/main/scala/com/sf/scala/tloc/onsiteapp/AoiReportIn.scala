package com.sf.scala.tloc.onsiteapp

import com.alibaba.fastjson.JSONObject

import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:
 * @Author: 01407499
 * @CreateTime: 2024-02-28 10:43
 * @TaskId:459021
 * @TaskName:AoiReportInCompute
 * @Description:
 */

object AoiReportIn {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    var partition = 20
    var run_flag = true
    type Data = (SparkSession,String)=>RDD[JSONObject]
    def main(args: Array[String]): Unit = {
        val date = args(0)
        val mode = args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        if(!StringUtils.isEmpty(mode) && "http,compute".split(",").contains(mode)){
            var dataF:Data = null
            var table = ""
            var structs:Array[String] = null
            var keys:Array[String] = null

            mode match {
                case "http" =>
                    partition = 20
                    table = "dm_gis.aoi_report_save_http_result2"
                    dataF = getData1
                    structs = Array("order_id","address","zno_code","city_code","staff_id","opt_date","update_date","cd_flag","address_check","aoi_area_code","aoi_area_code_chk","aoi_id","aoi_id_check","aoi_id_remark","aoi_type","aoi_type_check","waybill_date","aoi_area_code_remark","address_remark","aoi_type_remark","aoi_range_check","aoi_range_remark","other","opt_day","waybill_day","delivery_lgt","delivery_lat","delivery_xy_aoiid","gj_aoiid_t","gj_aoicode_t","gj_aoiname_t","tag1","tag2","tag3","r_aoi","bottomcorrected","aoi_area_ids_staff_id","gd_xcoord","gd_ycoord","gd_aoiid","gd_aoicode","gd_aoiname","tc_xcoord","tc_ycoord","tc_aoiid","tc_aoicode","tc_aoiname","bd_xcoord","bd_ycoord","bd_aoiid","bd_aoicode","bd_aoiname","rightaoiid_pre","dis_delivery_aoiid","dis_delivery_aoiidremark")
                    keys = structs
                case "compute" =>
                    partition = 1
                    table = "dm_gis.aoi_report_save_compute_result2"
                    dataF = getData2
                    structs = Array("order_id","address","zno_code","city_code","staff_id","opt_date","update_date","cd_flag","address_check","aoi_area_code","aoi_area_code_chk","aoi_id","aoi_id_check","aoi_id_remark","aoi_type","aoi_type_check","waybill_date","aoi_area_code_remark","address_remark","aoi_type_remark","aoi_range_check","aoi_range_remark","other","opt_day","waybill_day","delivery_lgt","delivery_lat","delivery_xy_aoiid","gj_aoiid_t","gj_aoicode_t","gj_aoiname_t","tag1","tag2","tag3","r_aoi","bottomcorrected","aoi_area_ids_staff_id","gd_xcoord","gd_ycoord","gd_aoiid","gd_aoicode","gd_aoiname","tc_xcoord","tc_ycoord","tc_aoiid","tc_aoicode","tc_aoiname","bd_xcoord","bd_ycoord","bd_aoiid","bd_aoicode","bd_aoiname","rightaoiid_pre","dis_delivery_aoiid","dis_delivery_aoiidremark","aoi_id_area","rightaoiid_area","gd_aoiarea","bd_aoiarea","tc_aoiarea","aoi_name","aoi_name_remark","dis_delivery_gdaoiid","dis_delivery_bdaoiid","dis_delivery_tcaoiid","rightaoiid_pre1","rightaoiid_pre2","rightaoiid_pre3","isright_aoi_id","isright_aoi_id_remark","rightaoiid","tag","rgsbadd_result")
                    keys = structs
            }

            logger.error(">>>处理类型：" + mode)
            logger.error(">>>处理日期：" + date)
            Stat(sparkSession, dataF, table, structs, keys, date)
            logger.error(">>>处理完毕---------------")
        }
    }


    def Stat(spark:SparkSession, getData:(SparkSession,String)=>RDD[JSONObject], table:String, structs:Array[String], keys:Array[String], date:String): Unit = {
        val resultRdd = getData(spark, date)

        SparkWrite.save2HiveStatic(spark, resultRdd, keys, table,Array(("inc_day", date)), 25)
        resultRdd.unpersist()
    }

    def getData1(spark:SparkSession, date:String):RDD[JSONObject] ={
        val startDate = DateUtil.getDateStr(date, -10)
        val endDate = date
        var sql=""
        sql =
            s"""
               |	select a.order_id,a.address,a.zno_code,a.city_code,a.staff_id,a.opt_date,a.update_date,a.cd_flag,a.address_check,a.aoi_area_code,a.aoi_area_code_chk,a.aoi_id,a.aoi_id_check,a.aoi_id_remark,a.aoi_type,a.aoi_type_check,a.waybill_date,a.aoi_area_code_remark,a.address_remark,a.aoi_type_remark,a.aoi_range_check,a.aoi_range_remark,a.other,a.opt_day,a.waybill_day,a.delivery_lgt,a.delivery_lat,a.delivery_xy_aoiid,a.gj_aoiid_t,a.gj_aoicode_t,a.gj_aoiname_t,a.tag1,a.tag2,a.tag3,a.r_aoi,a.bottomcorrected,d.aoi_area_ids_staff_id from
               |	(
               |		select t1.order_id,t1.address,t1.zno_code,t1.city_code,t1.staff_id,t1.opt_date,t1.update_date,t1.cd_flag,t1.address_check,t1.aoi_area_code,t1.aoi_area_code_chk,t1.aoi_id,t1.aoi_id_check,t1.aoi_id_remark,t1.aoi_type,t1.aoi_type_check,t1.waybill_date,t1.aoi_area_code_remark,t1.address_remark,t1.aoi_type_remark,t1.aoi_range_check,t1.aoi_range_remark,t1.other,t1.opt_day,t1.waybill_day,b1.delivery_lgt,b1.delivery_lat,b1.delivery_xy_aoiid,c1.gj_aoiid_t,c1.gj_aoicode_t,c1.gj_aoiname_t,c1.tag1,c1.tag2,c1.tag3,c1.r_aoi,c1.bottomcorrected from
               |		((select get_json_object(data, '$$.order_id') as order_id,regexp_replace(get_json_object(data, '$$.address'),'[\\r\\n\\t\\0, \\s, \\.]+','') as address,get_json_object(data, '$$.zno_code') as zno_code,get_json_object(data, '$$.city_code') as city_code,get_json_object(data, '$$.staff_id') as staff_id,get_json_object(data, '$$.opt_date') as opt_date,get_json_object(data, '$$.update_date') as update_date,get_json_object(data, '$$.cd_flag') as cd_flag,get_json_object(data, '$$.address_check') as address_check,get_json_object(data, '$$.aoi_area_code') as aoi_area_code,get_json_object(data, '$$.aoi_area_code_chk') as aoi_area_code_chk,get_json_object(data, '$$.aoi_id') as aoi_id,get_json_object(data, '$$.aoi_id_check') as aoi_id_check,get_json_object(data, '$$.aoi_id_remark') as aoi_id_remark,get_json_object(data, '$$.aoi_type') as aoi_type,get_json_object(data, '$$.aoi_type_check') as aoi_type_check,get_json_object(data, '$$.waybill_date') as waybill_date,get_json_object(data, '$$.aoi_area_code_remark') as aoi_area_code_remark,regexp_replace(get_json_object(data, '$$.address_remark'), '[\\r\\n\\t\\0, \\s, \\.]+', '') as address_remark,get_json_object(data, '$$.aoi_type_remark') as aoi_type_remark,get_json_object(data, '$$.aoi_range_check') as aoi_range_check,get_json_object(data, '$$.aoi_range_remark') as aoi_range_remark,regexp_replace(get_json_object(data, '$$.other'),'[\\r\\n\\t\\0, \\s, \\.]+','') as other,from_unixtime(cast(get_json_object(data, '$$.opt_date')/1000 as bigint),'yyyyMMdd') as opt_day,from_unixtime(cast(get_json_object(data, '$$.waybill_date')/1000 as bigint),'yyyyMMdd') as waybill_day from dm_gis.gis_ads_transfer_sds_aoi_report where inc_day='$date' and get_json_object(data, '$$.cd_flag')='1') t1
               |		left join (select waybill_no,inc_day,src_dist_code,consign_lgt as delivery_lgt,consign_lat as delivery_lat,'' as delivery_xy_aoiid from dm_gis.tt_order_hook where inc_day between '$startDate' and '$endDate' group by waybill_no,inc_day,src_dist_code,consign_lgt,consign_lat) b1 on t1.waybill_day=b1.inc_day and t1.city_code=b1.src_dist_code and t1.order_id=b1.waybill_no
               |		left join (select waybillno,inc_day,city_code,gj_aoiid_t,gj_aoicode_t,regexp_replace(gj_aoiname_t,'[\\r\\n\\t\\0, \\s, \\.]+','') as gj_aoiname_t,tag1,tag2,'' as tag3,r_aoi,'' as bottomcorrected from dm_gis.aoi_accuracy_54_aoiname_ret_bsp where inc_day between '$startDate' and '$endDate' group by waybillno,inc_day,city_code,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,tag1,tag2,r_aoi) c1 on t1.waybill_day=c1.inc_day and t1.city_code=c1.city_code and t1.order_id=c1.waybillno)
               |	union all
               |		select t2.order_id,t2.address,t2.zno_code,t2.city_code,t2.staff_id,t2.opt_date,t2.update_date,t2.cd_flag,t2.address_check,t2.aoi_area_code,t2.aoi_area_code_chk,t2.aoi_id,t2.aoi_id_check,t2.aoi_id_remark,t2.aoi_type,t2.aoi_type_check,t2.waybill_date,t2.aoi_area_code_remark,t2.address_remark,t2.aoi_type_remark,t2.aoi_range_check,t2.aoi_range_remark,t2.other,t2.opt_day,t2.waybill_day,b2.delivery_lgt,b2.delivery_lat,b2.delivery_xy_aoiid,c2.gj_aoiid_t,c2.gj_aoicode_t,c2.gj_aoiname_t,c2.tag1,c2.tag2,c2.tag3,c2.r_aoi,c2.bottomcorrected from
               |		((select get_json_object(data, '$$.order_id') as order_id,regexp_replace(get_json_object(data, '$$.address'),'[\\r\\n\\t\\0, \\s, \\.]+','') as address,get_json_object(data, '$$.zno_code') as zno_code,get_json_object(data, '$$.city_code') as city_code,get_json_object(data, '$$.staff_id') as staff_id,get_json_object(data, '$$.opt_date') as opt_date,get_json_object(data, '$$.update_date') as update_date,get_json_object(data, '$$.cd_flag') as cd_flag,get_json_object(data, '$$.address_check') as address_check,get_json_object(data, '$$.aoi_area_code') as aoi_area_code,get_json_object(data, '$$.aoi_area_code_chk') as aoi_area_code_chk,get_json_object(data, '$$.aoi_id') as aoi_id,get_json_object(data, '$$.aoi_id_check') as aoi_id_check,get_json_object(data, '$$.aoi_id_remark') as aoi_id_remark,get_json_object(data, '$$.aoi_type') as aoi_type,get_json_object(data, '$$.aoi_type_check') as aoi_type_check,get_json_object(data, '$$.waybill_date') as waybill_date,get_json_object(data, '$$.aoi_area_code_remark') as aoi_area_code_remark,regexp_replace(get_json_object(data, '$$.address_remark'), '[\\r\\n\\t\\0, \\s, \\.]+', '') as address_remark,get_json_object(data, '$$.aoi_type_remark') as aoi_type_remark,get_json_object(data, '$$.aoi_range_check') as aoi_range_check,get_json_object(data, '$$.aoi_range_remark') as aoi_range_remark,regexp_replace(get_json_object(data, '$$.other'),'[\\r\\n\\t\\0, \\s, \\.]+','') as other,from_unixtime(cast(get_json_object(data, '$$.opt_date')/1000 as bigint),'yyyyMMdd') as opt_day,from_unixtime(cast(get_json_object(data, '$$.waybill_date')/1000 as bigint),'yyyyMMdd') as waybill_day from dm_gis.gis_ads_transfer_sds_aoi_report where inc_day='$date' and get_json_object(data, '$$.cd_flag')='2') t2
               |		left join (select waybill_no,inc_day,dest_dist_code,delivery_lgt,delivery_lat,delivery_xy_aoiid from dm_gis.tt_waybill_hook where inc_day between '$startDate' and '$endDate' group by waybill_no,inc_day,dest_dist_code,delivery_lgt,delivery_lat,delivery_xy_aoiid) b2 on t2.waybill_day=b2.inc_day and t2.city_code=b2.dest_dist_code and t2.order_id=b2.waybill_no
               |		left join (select waybillno,inc_day,city_code,gj_aoiid_t,gj_aoicode_t,regexp_replace(gj_aoiname_t,'[\\r\\n\\t\\0, \\s, \\.]+','') as gj_aoiname_t,tag1,tag2,tag3,r_aoi,bottomcorrected from dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected where inc_day between '$startDate' and '$endDate' group by waybillno,inc_day,city_code,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,tag1,tag2,tag3,r_aoi,bottomcorrected) c2 on t2.waybill_day=c2.inc_day and t2.city_code=c2.city_code and t2.order_id=c2.waybillno)
               |	) a
               |	left join (select m.loginid,m.inc_day,concat('[',concat_ws(',', collect_list(concat('"',m.aoi_area_id,'"'))),']') as aoi_area_ids_staff_id from (select loginid,inc_day,aoi_area_id from dm_tc_waybillinfo.schedule_width_data where inc_day between '$startDate' and '$endDate' and aoi_area_id is not null and aoi_area_id<>'' group by loginid,inc_day,aoi_area_id) m group by m.loginid,m.inc_day) d on a.waybill_day=d.inc_day and a.staff_id=d.loginid
               |union all
               |select get_json_object(data, '$$.order_id') as order_id,regexp_replace(get_json_object(data, '$$.address'),'[\\r\\n\\t\\0, \\s, \\.]+','') as address,get_json_object(data, '$$.zno_code') as zno_code,get_json_object(data, '$$.city_code') as city_code,get_json_object(data, '$$.staff_id') as staff_id,get_json_object(data, '$$.opt_date') as opt_date,get_json_object(data, '$$.update_date') as update_date,get_json_object(data, '$$.cd_flag') as cd_flag,get_json_object(data, '$$.address_check') as address_check,get_json_object(data, '$$.aoi_area_code') as aoi_area_code,get_json_object(data, '$$.aoi_area_code_chk') as aoi_area_code_chk,get_json_object(data, '$$.aoi_id') as aoi_id,get_json_object(data, '$$.aoi_id_check') as aoi_id_check,get_json_object(data, '$$.aoi_id_remark') as aoi_id_remark,get_json_object(data, '$$.aoi_type') as aoi_type,get_json_object(data, '$$.aoi_type_check') as aoi_type_check,get_json_object(data, '$$.waybill_date') as waybill_date,get_json_object(data, '$$.aoi_area_code_remark') as aoi_area_code_remark,regexp_replace(get_json_object(data, '$$.address_remark'), '[\\r\\n\\t\\0, \\s, \\.]+', '') as address_remark,get_json_object(data, '$$.aoi_type_remark') as aoi_type_remark,get_json_object(data, '$$.aoi_range_check') as aoi_range_check,get_json_object(data, '$$.aoi_range_remark') as aoi_range_remark,regexp_replace(get_json_object(data, '$$.other'),'[\\r\\n\\t\\0, \\s, \\.]+','') as other,from_unixtime(cast(get_json_object(data, '$$.opt_date')/1000 as bigint),'yyyyMMdd') as opt_day,from_unixtime(cast(get_json_object(data, '$$.waybill_date')/1000 as bigint),'yyyyMMdd') as waybill_day,'' as delivery_lgt,'' as delivery_lat,'' as delivery_xy_aoiid,'' as gj_aoiid_t,'' as gj_aoicode_t,'' as gj_aoiname_t,'' as tag1,'' as tag2,'' as tag3,'' as r_aoi,'' as bottomcorrected,'' as aoi_area_ids_staff_id from dm_gis.gis_ads_transfer_sds_aoi_report where inc_day='$date' and get_json_object(data, '$$.cd_flag') not in ('1','2')
       """.stripMargin
        val logRdd = SparkRead.readHiveAsJson(spark, sql)._1
        val resultRdd = logRdd.map(json=>{
                if(json!=null){
                    val cd_flag = json.getString("cd_flag")
                    val delivery_lgt = json.getString("delivery_lgt")
                    val delivery_lat = json.getString("delivery_lat")
                    if("1".equalsIgnoreCase(cd_flag) && !StringUtils.isEmpty(delivery_lgt) && !StringUtils.isEmpty(delivery_lat)){
                        val resultObject = dept2(delivery_lgt, delivery_lat)
                        if(resultObject!=null){
                            val resultObject2 = resultObject.getJSONObject("result")
                            if(resultObject2!=null){
                                val aoi_data = resultObject2.getJSONArray("aoi_data")
                                if(aoi_data!=null && aoi_data.size()>0){
                                    val aoi_data0 = aoi_data.getJSONObject(0)
                                    if(aoi_data0!=null){
                                        val delivery_xy_aoiid = aoi_data0.getString("aoi_id")
                                        if(!StringUtils.isEmpty(delivery_xy_aoiid)) json.put("delivery_xy_aoiid", delivery_xy_aoiid)
                                    }
                                }
                            }
                        }
                    }

                    val aoi_id = json.getString("aoi_id")
                    val aoi_id_remark = json.getString("aoi_id_remark")
                    if(!StringUtils.isEmpty(delivery_lgt) && !StringUtils.isEmpty(delivery_lat)){
                        if(!StringUtils.isEmpty(aoi_id)){
                            val resultObject = getCoorAoiDist(delivery_lgt, delivery_lat, aoi_id)
                            if(resultObject!=null){
                                val data = resultObject.getString("data")
                                if(!StringUtils.isEmpty(data)) json.put("dis_delivery_aoiid", data)
                            }
                        }
                        if(!StringUtils.isEmpty(aoi_id_remark)){
                            val resultObject = getCoorAoiDist(delivery_lgt, delivery_lat, aoi_id_remark)
                            if(resultObject!=null){
                                val data = resultObject.getString("data")
                                if(!StringUtils.isEmpty(data)) json.put("dis_delivery_aoiidremark", data)
                            }
                        }
                    }
                }
                json
            })
            .map(json=>{
                var address = ""
                var city_code = ""
                //        var aoi_id_check = ""
                if(json!=null){
                    address = json.getString("address")
                    city_code = json.getString("city_code")
                    //          aoi_id_check = json.getString("aoi_id_check")
                    if(StringUtils.isEmpty(address)) address = ""
                    if(StringUtils.isEmpty(city_code)) city_code = ""
                    //          if(StringUtils.isEmpty(aoi_id_check)) aoi_id_check = ""
                }
                //        ((address,city_code,aoi_id_check), json)
                ((address,city_code), json)
            })
            .groupByKey()
            .flatMap(obj=>{
                val list = new ArrayBuffer[JSONObject]()
                val address = obj._1._1
                val city_code = obj._1._2
                //        val aoi_id_check = obj._1._3
                val jsonList = obj._2.toList

                var gd_xcoord = ""
                var gd_ycoord = ""
                var gd_aoiid = ""
                var gd_aoicode = ""
                var gd_aoiname = ""
                var tc_xcoord = ""
                var tc_ycoord = ""
                var tc_aoiid = ""
                var tc_aoicode = ""
                var tc_aoiname = ""
                var bd_xcoord = ""
                var bd_ycoord = ""
                var bd_aoiid = ""
                var bd_aoicode = ""
                var bd_aoiname = ""

                //        if("3".equalsIgnoreCase(aoi_id_check)){
                val resultObject_gd = geo(address, city_code, "gd2")
                if(resultObject_gd!=null){
                    val resultObject_gd2 = resultObject_gd.getJSONObject("result")
                    if(resultObject_gd2!=null){
                        gd_xcoord = resultObject_gd2.getString("xcoord")
                        gd_ycoord = resultObject_gd2.getString("ycoord")
                        if(!StringUtils.isEmpty(gd_xcoord) && !StringUtils.isEmpty(gd_ycoord)){
                            val resultObject_gd_dept = dept2(gd_xcoord,gd_ycoord)
                            if(resultObject_gd_dept!=null){
                                val resultObject_gd_dept2 = resultObject_gd_dept.getJSONObject("result")
                                if(resultObject_gd_dept2!=null){
                                    val aoi_data = resultObject_gd_dept2.getJSONArray("aoi_data")
                                    if(aoi_data!=null && aoi_data.size()>0){
                                        val aoi_data0 = aoi_data.getJSONObject(0)
                                        if(aoi_data0!=null){
                                            gd_aoiid = aoi_data0.getString("aoi_id")
                                            gd_aoicode = aoi_data0.getString("aoi_code")
                                            gd_aoiname = aoi_data0.getString("aoi_name")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                val resultObject_tc = geo(address, city_code, "tc2")
                if(resultObject_tc!=null){
                    val resultObject_tc2 = resultObject_tc.getJSONObject("result")
                    if(resultObject_tc2!=null){
                        tc_xcoord = resultObject_tc2.getString("xcoord")
                        tc_ycoord = resultObject_tc2.getString("ycoord")
                        if(!StringUtils.isEmpty(tc_xcoord) && !StringUtils.isEmpty(tc_ycoord)){
                            val resultObject_tc_dept = dept2(tc_xcoord,tc_ycoord)
                            if(resultObject_tc_dept!=null){
                                val resultObject_tc_dept2 = resultObject_tc_dept.getJSONObject("result")
                                if(resultObject_tc_dept2!=null){
                                    val aoi_data = resultObject_tc_dept2.getJSONArray("aoi_data")
                                    if(aoi_data!=null && aoi_data.size()>0){
                                        val aoi_data0 = aoi_data.getJSONObject(0)
                                        if(aoi_data0!=null){
                                            tc_aoiid = aoi_data0.getString("aoi_id")
                                            tc_aoicode = aoi_data0.getString("aoi_code")
                                            tc_aoiname = aoi_data0.getString("aoi_name")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                val resultObject_bd = geo(address, city_code, "bd2")
                if(resultObject_bd!=null){
                    val resultObject_bd2 = resultObject_bd.getJSONObject("result")
                    if(resultObject_bd2!=null){
                        bd_xcoord = resultObject_bd2.getString("xcoord")
                        bd_ycoord = resultObject_bd2.getString("ycoord")
                        if(!StringUtils.isEmpty(bd_xcoord) && !StringUtils.isEmpty(bd_ycoord)){
                            val resultObject_bd_dept = dept2(bd_xcoord,bd_ycoord)
                            if(resultObject_bd_dept!=null){
                                val resultObject_bd_dept2 = resultObject_bd_dept.getJSONObject("result")
                                if(resultObject_bd_dept2!=null){
                                    val aoi_data = resultObject_bd_dept2.getJSONArray("aoi_data")
                                    if(aoi_data!=null && aoi_data.size()>0){
                                        val aoi_data0 = aoi_data.getJSONObject(0)
                                        if(aoi_data0!=null){
                                            bd_aoiid = aoi_data0.getString("aoi_id")
                                            bd_aoicode = aoi_data0.getString("aoi_code")
                                            bd_aoiname = aoi_data0.getString("aoi_name")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if(StringUtils.isEmpty(gd_xcoord)) gd_xcoord = ""
                if(StringUtils.isEmpty(gd_ycoord)) gd_ycoord = ""
                if(StringUtils.isEmpty(gd_aoiid)) gd_aoiid = ""
                if(StringUtils.isEmpty(gd_aoicode)) gd_aoicode = ""
                if(StringUtils.isEmpty(gd_aoiname)) gd_aoiname = ""
                if(StringUtils.isEmpty(tc_xcoord)) tc_xcoord = ""
                if(StringUtils.isEmpty(tc_ycoord)) tc_ycoord = ""
                if(StringUtils.isEmpty(tc_aoiid)) tc_aoiid = ""
                if(StringUtils.isEmpty(tc_aoicode)) tc_aoicode = ""
                if(StringUtils.isEmpty(tc_aoiname)) tc_aoiname = ""
                if(StringUtils.isEmpty(bd_xcoord)) bd_xcoord = ""
                if(StringUtils.isEmpty(bd_ycoord)) bd_ycoord = ""
                if(StringUtils.isEmpty(bd_aoiid)) bd_aoiid = ""
                if(StringUtils.isEmpty(bd_aoicode)) bd_aoicode = ""
                if(StringUtils.isEmpty(bd_aoiname)) bd_aoiname = ""
                //        }

                var set2 = Set[String]()
                if(!StringUtils.isEmpty(gd_aoiid)) set2 = set2.+(gd_aoiid)
                if(!StringUtils.isEmpty(tc_aoiid)) set2 = set2.+(tc_aoiid)
                if(!StringUtils.isEmpty(bd_aoiid)) set2 = set2.+(bd_aoiid)

                var equal_flag = false
                if(!StringUtils.isEmpty(gd_aoiid) && !StringUtils.isEmpty(tc_aoiid) && gd_aoiid.equalsIgnoreCase(tc_aoiid)
                    && !StringUtils.isEmpty(bd_aoiid) && gd_aoiid.equalsIgnoreCase(bd_aoiid)) equal_flag = true

                if(jsonList.nonEmpty){
                    for(i<-jsonList.indices){
                        val json = jsonList(i)
                        var rightaoiid_pre = ""

                        //            if("3".equalsIgnoreCase(aoi_id_check)){
                        val delivery_xy_aoiid = json.getString("delivery_xy_aoiid")
                        val gj_aoiid_t  = json.getString("gj_aoiid_t")
                        var rightaoiid_pre_tmp = ""
                        var set1 = Set[String]()
                        if(!StringUtils.isEmpty(delivery_xy_aoiid)) set1 = set1.+(delivery_xy_aoiid)
                        if(!StringUtils.isEmpty(gj_aoiid_t)) set1 = set1.+(gj_aoiid_t)
                        val set = set1.intersect(set2)
                        if(set.size == 1){
                            rightaoiid_pre_tmp = set.head
                        }

                        if(equal_flag){
                            rightaoiid_pre = gd_aoiid
                        }
                        else if(!StringUtils.isEmpty(rightaoiid_pre_tmp)){
                            rightaoiid_pre = rightaoiid_pre_tmp
                        }
                        //            }

                        json.put("gd_xcoord", gd_xcoord)
                        json.put("gd_ycoord", gd_ycoord)
                        json.put("gd_aoiid", gd_aoiid)
                        json.put("gd_aoicode", gd_aoicode)
                        json.put("gd_aoiname", gd_aoiname)
                        json.put("tc_xcoord", tc_xcoord)
                        json.put("tc_ycoord", tc_ycoord)
                        json.put("tc_aoiid", tc_aoiid)
                        json.put("tc_aoicode", tc_aoicode)
                        json.put("tc_aoiname", tc_aoiname)
                        json.put("bd_xcoord", bd_xcoord)
                        json.put("bd_ycoord", bd_ycoord)
                        json.put("bd_aoiid", bd_aoiid)
                        json.put("bd_aoicode", bd_aoicode)
                        json.put("bd_aoiname", bd_aoiname)
                        json.put("rightaoiid_pre", rightaoiid_pre)

                        list += json
                    }
                }
                list
            })
            .repartition(partition).persist()

        logger.error(">>>日志量："+resultRdd.count())
        logRdd.unpersist()
        resultRdd
    }

    def getData2(spark:SparkSession, date:String):RDD[JSONObject] ={
        var sql=""
        sql =
            s"""
               |select t1.order_id,t1.address,t1.zno_code,t1.city_code,t1.staff_id,t1.opt_date,t1.update_date,t1.cd_flag,t1.address_check,t1.aoi_area_code,t1.aoi_area_code_chk,t1.aoi_id,t1.aoi_id_check,t1.aoi_id_remark,t1.aoi_type,t1.aoi_type_check,t1.waybill_date,t1.aoi_area_code_remark,t1.address_remark,t1.aoi_type_remark,t1.aoi_range_check,t1.aoi_range_remark,t1.other,t1.opt_day,t1.waybill_day,t1.delivery_lgt,t1.delivery_lat,t1.delivery_xy_aoiid,t1.gj_aoiid_t,t1.gj_aoicode_t,t1.gj_aoiname_t,t1.tag1,t1.tag2,t1.tag3,t1.r_aoi,t1.bottomcorrected,t1.aoi_area_ids_staff_id,t1.gd_xcoord,t1.gd_ycoord,t1.gd_aoiid,t1.gd_aoicode,t1.gd_aoiname,t1.tc_xcoord,t1.tc_ycoord,t1.tc_aoiid,t1.tc_aoicode,t1.tc_aoiname,t1.bd_xcoord,t1.bd_ycoord,t1.bd_aoiid,t1.bd_aoicode,t1.bd_aoiname,t1.rightaoiid_pre,t1.dis_delivery_aoiid,t1.dis_delivery_aoiidremark,c.aoi_id_area,e.rightaoiid_area,g.gd_aoiarea,i.bd_aoiarea,k.tc_aoiarea,b.aoi_name,l.aoi_name_remark from
               |	(select order_id,address,zno_code,city_code,staff_id,opt_date,update_date,cd_flag,address_check,aoi_area_code,aoi_area_code_chk,aoi_id,aoi_id_check,aoi_id_remark,aoi_type,aoi_type_check,waybill_date,aoi_area_code_remark,address_remark,aoi_type_remark,aoi_range_check,aoi_range_remark,other,opt_day,waybill_day,delivery_lgt,delivery_lat,delivery_xy_aoiid,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,tag1,tag2,tag3,r_aoi,bottomcorrected,aoi_area_ids_staff_id,gd_xcoord,gd_ycoord,gd_aoiid,gd_aoicode,gd_aoiname,tc_xcoord,tc_ycoord,tc_aoiid,tc_aoicode,tc_aoiname,bd_xcoord,bd_ycoord,bd_aoiid,bd_aoicode,bd_aoiname,rightaoiid_pre,dis_delivery_aoiid,dis_delivery_aoiidremark from dm_gis.aoi_report_save_http_result2 where inc_day='$date') t1
               |	left join (select aoi_id,aoi_code,aoi_name from dm_gis.cms_aoi_sch where source='sz' and del_flag<>'1') b on t1.aoi_id=b.aoi_id
               |	left join (select aoi_id as aoi_code,aoi_area_code as aoi_id_area from dm_tc_waybillinfo.aoi_area_aoi group by aoi_code,aoi_area_code) c on b.aoi_code=c.aoi_code
               |	left join (select aoi_id,aoi_code from dm_gis.cms_aoi_sch where source='sz' and del_flag<>'1') d on t1.rightaoiid_pre=d.aoi_id
               |	left join (select aoi_id as aoi_code,aoi_area_code as rightaoiid_area from dm_tc_waybillinfo.aoi_area_aoi group by aoi_code,aoi_area_code) e on d.aoi_code=e.aoi_code
               |	left join (select aoi_id,aoi_code from dm_gis.cms_aoi_sch where source='sz' and del_flag<>'1') f on t1.gd_aoiid=f.aoi_id
               |	left join (select aoi_id as aoi_code,aoi_area_code as gd_aoiarea from dm_tc_waybillinfo.aoi_area_aoi group by aoi_code,aoi_area_code) g on f.aoi_code=g.aoi_code
               |	left join (select aoi_id,aoi_code from dm_gis.cms_aoi_sch where source='sz' and del_flag<>'1') h on t1.bd_aoiid=h.aoi_id
               |	left join (select aoi_id as aoi_code,aoi_area_code as bd_aoiarea from dm_tc_waybillinfo.aoi_area_aoi group by aoi_code,aoi_area_code) i on h.aoi_code=i.aoi_code
               |	left join (select aoi_id,aoi_code from dm_gis.cms_aoi_sch where source='sz' and del_flag<>'1') j on t1.tc_aoiid=j.aoi_id
               |	left join (select aoi_id as aoi_code,aoi_area_code as tc_aoiarea from dm_tc_waybillinfo.aoi_area_aoi group by aoi_code,aoi_area_code) k on j.aoi_code=k.aoi_code
               |	left join (select aoi_id,aoi_name as aoi_name_remark from dm_gis.cms_aoi_sch where source='sz' and del_flag<>'1') l on t1.aoi_id_remark=l.aoi_id
       """.stripMargin
        val logRdd = SparkRead.readHiveAsJson(spark, sql)._1

        val resultRdd = logRdd
            .map(json=>{
                if(json!=null){
                    var dis_delivery_gdaoiid = ""
                    var dis_delivery_bdaoiid = ""
                    var dis_delivery_tcaoiid = ""
                    var rightaoiid_pre1 = ""
                    var rightaoiid_pre2 = ""
                    var rightaoiid_pre3 = ""
                    var isright_aoi_id = ""
                    var isright_aoi_id_remark = ""
                    var rightaoiid = ""
                    var tag = ""

                    var rightaoiid_pre = ""
                    var rightaoiid_area = ""
                    rightaoiid_pre  = json.getString("rightaoiid_pre")
                    rightaoiid_area  = json.getString("rightaoiid_area")

                    val delivery_xy_aoiid = json.getString("delivery_xy_aoiid")
                    val aoi_id_remark = json.getString("aoi_id_remark")
                    val aoi_id = json.getString("aoi_id")
                    val gd_aoiid = json.getString("gd_aoiid")
                    val tc_aoiid = json.getString("tc_aoiid")
                    val bd_aoiid = json.getString("bd_aoiid")
                    val aoi_id_area  = json.getString("aoi_id_area")
                    val aoi_area_ids_staff_id  = json.getString("aoi_area_ids_staff_id")
                    val gj_aoiid_t  = json.getString("gj_aoiid_t")
                    val address  = json.getString("address")
                    val aoi_name  = json.getString("aoi_name")
                    val aoi_name_remark  = json.getString("aoi_name_remark")
                    val aoi_id_check  = json.getString("aoi_id_check")
                    val aoi_area_code_chk  = json.getString("aoi_area_code_chk")
                    val dis_delivery_aoiidremark  = json.getString("dis_delivery_aoiidremark")
                    val dis_delivery_aoiid  = json.getString("dis_delivery_aoiid")
                    val gd_aoiarea  = json.getString("gd_aoiarea")
                    val bd_aoiarea  = json.getString("bd_aoiarea")
                    val tc_aoiarea  = json.getString("tc_aoiarea")
                    val delivery_lgt = json.getString("delivery_lgt")
                    val delivery_lat = json.getString("delivery_lat")
                    val aoi_type_check = json.getString("aoi_type_check")

                    var address_contain_flag = false
                    if(!StringUtils.isEmpty(address) && !StringUtils.isEmpty(aoi_name)){
                        if(aoi_name.endsWith("村") && (address.endsWith(aoi_name) || address.endsWith(aoi_name.substring(0,aoi_name.length - 1)))) address_contain_flag = true
                        if(!address_contain_flag && address.endsWith("村") && (address.endsWith(aoi_name) || address.endsWith(aoi_name + "村"))) address_contain_flag = true
                    }

                    val array =  Array(gd_aoiid,tc_aoiid,bd_aoiid)

                    var equal_flag = true

                    if(address_contain_flag){
                        rightaoiid_pre = ""
                        rightaoiid_area = ""
                        isright_aoi_id = "1"
                        isright_aoi_id_remark = "0"
                        rightaoiid = aoi_id
                        tag = "0"
                    }
                    else if("3".equalsIgnoreCase(aoi_id_check) || "3".equalsIgnoreCase(aoi_area_code_chk)){
                        if((!StringUtils.isEmpty(delivery_xy_aoiid) && !StringUtils.isEmpty(aoi_id_remark) && delivery_xy_aoiid.equalsIgnoreCase(aoi_id_remark)) ||
                            (!StringUtils.isEmpty(dis_delivery_aoiidremark) && !StringUtils.isEmpty(dis_delivery_aoiid)
                                && dis_delivery_aoiidremark.toDouble <= 5 && dis_delivery_aoiid.toDouble > 5)){
                            rightaoiid_pre = ""
                            rightaoiid_area = ""
                            if(!StringUtils.isEmpty(aoi_id) && aoi_id.equalsIgnoreCase(aoi_id_remark)){
                                isright_aoi_id = "1"
                                isright_aoi_id_remark = "1"
                                rightaoiid = delivery_xy_aoiid
                                tag = "1"
                            }
                            else{
                                isright_aoi_id = "0"
                                isright_aoi_id_remark = "1"
                                rightaoiid = delivery_xy_aoiid
                                tag = "1"
                            }
                        }
                        else if(!StringUtils.isEmpty(aoi_id_remark) && array.contains(aoi_id_remark)
                            && (StringUtils.isEmpty(aoi_id) || !array.contains(aoi_id))
                            && (StringUtils.isEmpty(delivery_xy_aoiid) || !array.contains(delivery_xy_aoiid))){
                            rightaoiid_pre = ""
                            rightaoiid_area = ""
                            isright_aoi_id = "0"
                            isright_aoi_id_remark = "1"
                            rightaoiid = aoi_id_remark
                            tag = "2"
                        }
                        else if(!StringUtils.isEmpty(delivery_xy_aoiid) && !StringUtils.isEmpty(aoi_id) && delivery_xy_aoiid.equalsIgnoreCase(aoi_id)
                            && !StringUtils.isEmpty(aoi_id_area) && !StringUtils.isEmpty(aoi_area_ids_staff_id) && aoi_area_ids_staff_id.contains(aoi_id_area)
                            && !StringUtils.isEmpty(aoi_id) && array.contains(aoi_id)){
                            rightaoiid_pre = ""
                            rightaoiid_area = ""
                            isright_aoi_id = "1"
                            isright_aoi_id_remark = "0"
                            rightaoiid = delivery_xy_aoiid
                            tag = "3"
                        }
                        else if(((!StringUtils.isEmpty(gd_aoiid) && !StringUtils.isEmpty(tc_aoiid) && gd_aoiid.equalsIgnoreCase(tc_aoiid)
                            && !StringUtils.isEmpty(bd_aoiid) && gd_aoiid.equalsIgnoreCase(bd_aoiid))
                            || !StringUtils.isEmpty(rightaoiid_pre))
                            && (!StringUtils.isEmpty(aoi_area_ids_staff_id) && !StringUtils.isEmpty(rightaoiid_area) && aoi_area_ids_staff_id.contains(rightaoiid_area)
                            && !StringUtils.isEmpty(rightaoiid_pre) && !rightaoiid_pre.equalsIgnoreCase(aoi_id))){
                            if(!StringUtils.isEmpty(rightaoiid_pre) && rightaoiid_pre.equalsIgnoreCase(aoi_id_remark)){
                                isright_aoi_id = "0"
                                isright_aoi_id_remark = "1"
                                rightaoiid = rightaoiid_pre
                                tag = "4"
                            }
                            else{
                                isright_aoi_id = "0"
                                isright_aoi_id_remark = "0"
                                rightaoiid = rightaoiid_pre
                                tag = "4"
                            }
                        }
                        else{

                            if(!StringUtils.isEmpty(delivery_lgt) && !StringUtils.isEmpty(delivery_lat)){
                                if(!StringUtils.isEmpty(aoi_area_ids_staff_id) && !StringUtils.isEmpty(gd_aoiarea) && aoi_area_ids_staff_id.contains(gd_aoiarea)){
                                    val resultObject = getCoorAoiDist(delivery_lgt,delivery_lat,gd_aoiid)
                                    if(resultObject!=null){
                                        dis_delivery_gdaoiid = resultObject.getString("data")
                                        if(!StringUtils.isEmpty(dis_delivery_gdaoiid)) {
                                            json.put("dis_delivery_gdaoiid", dis_delivery_gdaoiid)
                                            if(dis_delivery_gdaoiid.toDouble <= 5) {
                                                rightaoiid_pre1 = gd_aoiid
                                                json.put("rightaoiid_pre1", rightaoiid_pre1)
                                            }
                                        }
                                    }
                                }
                                if(!StringUtils.isEmpty(aoi_area_ids_staff_id) && !StringUtils.isEmpty(bd_aoiarea) && aoi_area_ids_staff_id.contains(bd_aoiarea)){
                                    val resultObject = getCoorAoiDist(delivery_lgt,delivery_lat,bd_aoiid)
                                    if(resultObject!=null){
                                        dis_delivery_bdaoiid = resultObject.getString("data")
                                        if(!StringUtils.isEmpty(dis_delivery_bdaoiid)) {
                                            json.put("dis_delivery_bdaoiid", dis_delivery_bdaoiid)
                                            if(dis_delivery_bdaoiid.toDouble <= 5) {
                                                rightaoiid_pre2 = bd_aoiid
                                                json.put("rightaoiid_pre2", rightaoiid_pre2)
                                            }
                                        }
                                    }
                                }
                                if(!StringUtils.isEmpty(aoi_area_ids_staff_id) && !StringUtils.isEmpty(tc_aoiarea) && aoi_area_ids_staff_id.contains(tc_aoiarea)){
                                    val resultObject = getCoorAoiDist(delivery_lgt,delivery_lat,tc_aoiid)
                                    if(resultObject!=null){
                                        dis_delivery_tcaoiid = resultObject.getString("data")
                                        if(!StringUtils.isEmpty(dis_delivery_tcaoiid)) {
                                            json.put("dis_delivery_tcaoiid", dis_delivery_tcaoiid)
                                            if(dis_delivery_tcaoiid.toDouble <= 5) {
                                                rightaoiid_pre3 = tc_aoiid
                                                json.put("rightaoiid_pre3", rightaoiid_pre3)
                                            }
                                        }
                                    }
                                }
                            }

                            val temp = Array(rightaoiid_pre1,rightaoiid_pre2,rightaoiid_pre3)
                            val temp_set = temp.filter(x => !StringUtils.isEmpty(x)).toSet
                            if(temp_set.size == 1){
                                rightaoiid_pre = ""
                                rightaoiid_area = ""
                                val temp_rightaoiid = temp_set.head
                                equal_flag = true
                                if(!StringUtils.isEmpty(temp_rightaoiid) && temp_rightaoiid.equalsIgnoreCase(aoi_id)){
                                    isright_aoi_id = "1"
                                    isright_aoi_id_remark = "0"
                                    rightaoiid = temp_rightaoiid
                                    tag = "5"
                                }
                                else{
                                    isright_aoi_id = "0"
                                    isright_aoi_id_remark = "0"
                                    rightaoiid = temp_rightaoiid
                                    tag = "5"
                                }
                            }
                            else{
                                equal_flag = false
                            }
                        }
                    }

                    if((!equal_flag || (!address_contain_flag && !"3".equalsIgnoreCase(aoi_id_check) && !"3".equalsIgnoreCase(aoi_area_code_chk))) && "3".equalsIgnoreCase(aoi_type_check)){
                        if(((!StringUtils.isEmpty(gd_aoiid) && !StringUtils.isEmpty(tc_aoiid) && gd_aoiid.equalsIgnoreCase(tc_aoiid)
                            && !StringUtils.isEmpty(bd_aoiid) && gd_aoiid.equalsIgnoreCase(bd_aoiid))
                            || !StringUtils.isEmpty(rightaoiid_pre))
                            && (!StringUtils.isEmpty(aoi_area_ids_staff_id) && !StringUtils.isEmpty(rightaoiid_area) && aoi_area_ids_staff_id.contains(rightaoiid_area))
                            && ((!StringUtils.isEmpty(rightaoiid_pre) && rightaoiid_pre.equalsIgnoreCase(aoi_id))
                            || (StringUtils.isEmpty(aoi_id) || !array.contains(aoi_id)))){
                            if(!StringUtils.isEmpty(rightaoiid_pre) && rightaoiid_pre.equalsIgnoreCase(aoi_id)){
                                isright_aoi_id = "1"
                                isright_aoi_id_remark = "0"
                                rightaoiid = rightaoiid_pre
                                tag = "1"
                            }
                            else if(StringUtils.isEmpty(aoi_id) || !array.contains(aoi_id)){
                                isright_aoi_id = "0"
                                isright_aoi_id_remark = "0"
                                rightaoiid = rightaoiid_pre
                                tag = "1"
                            }
                        }
                        else if(!StringUtils.isEmpty(delivery_xy_aoiid) && !StringUtils.isEmpty(aoi_id) && delivery_xy_aoiid.equalsIgnoreCase(aoi_id)){
                            isright_aoi_id = "1"
                            isright_aoi_id_remark = "0"
                            rightaoiid = delivery_xy_aoiid
                            tag = "2"
                        }
                    }


                    if(!StringUtils.isEmpty(isright_aoi_id)) json.put("isright_aoi_id", isright_aoi_id)
                    if(!StringUtils.isEmpty(isright_aoi_id_remark)) json.put("isright_aoi_id_remark", isright_aoi_id_remark)
                    if(!StringUtils.isEmpty(rightaoiid)) json.put("rightaoiid", rightaoiid)
                    if(!StringUtils.isEmpty(tag)) json.put("tag", tag)
                    if(StringUtils.isEmpty(rightaoiid_pre)) json.put("rightaoiid_pre", rightaoiid_pre)
                    if(StringUtils.isEmpty(rightaoiid_area)) json.put("rightaoiid_area", rightaoiid_area)
                }
                json
            })
            .map(json=>{
                var isright_aoi_id = json.getString("isright_aoi_id")
                var city_code = json.getString("city_code")
                var address = json.getString("address")
                var zno_code = json.getString("zno_code")
                var rightaoiid = json.getString("rightaoiid")
                var cd_flag = json.getString("cd_flag")
                if(StringUtils.isEmpty(isright_aoi_id)) isright_aoi_id = ""
                if(StringUtils.isEmpty(city_code)) city_code = ""
                if(StringUtils.isEmpty(address)) address = ""
                if(StringUtils.isEmpty(zno_code)) zno_code = ""
                if(StringUtils.isEmpty(rightaoiid)) rightaoiid = ""
                if(StringUtils.isEmpty(cd_flag)) cd_flag = ""

                ((isright_aoi_id, city_code, address, zno_code, rightaoiid, cd_flag), json)
            })
            .groupByKey()
            .flatMap(obj=>{
                val list = new ArrayBuffer[JSONObject]()
                val jsonList = obj._2.toList

                var rgsbadd_result = ""
                val isright_aoi_id = obj._1._1
                if("0".equalsIgnoreCase(isright_aoi_id) && ("1".equalsIgnoreCase(obj._1._6) || "2".equalsIgnoreCase(obj._1._6))){
                    val key = obj._1
                    val city_code = key._2
                    val address = key._3
                    val zno_code = key._4
                    val rightaoiid = key._5
                    val cd_flag = key._6

                    if(run_flag){
                        val resultObject = rgsbAdd(city_code, address, zno_code, rightaoiid, cd_flag)
                        if(resultObject!=null){
                            val success = resultObject.getString("success")
                            if("true".equalsIgnoreCase(success)) rgsbadd_result = "true"
                            else if("false".equalsIgnoreCase(success)) rgsbadd_result = resultObject.getString("message")
                            else rgsbadd_result = resultObject.toJSONString
                        }
                        else rgsbadd_result = "result is not json or http error"
                    }
                    else rgsbadd_result = "not run"

                }

                for(json<-jsonList){
                    if(json!=null){
                        json.put("rgsbadd_result", rgsbadd_result)
                        list += json
                    }
                }

                list
            }).repartition(2).persist()

        logger.error(">>>日志量："+resultRdd.count())
        resultRdd
    }






    def geo(address:String, city:String, opt:String): JSONObject ={
        var jsonObject:JSONObject = null
        val url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=87106f6380af4df0845a693eee58843c&opt=%s&address=%s&city=%s"
            .format(opt, address, city)
        breakable(
            for(i<-0.until(5)){
                try {
                    jsonObject = HttpClientUtil.getJsonByGet(url)
                    logger.error(">>>访问geo：url=" + url + ", json="+jsonObject)
                    Thread.sleep(350)
                    if(jsonObject!=null){
                        val status = jsonObject.getString("status")
                        if("0".equalsIgnoreCase(status)) break
                        else if("1".equalsIgnoreCase(status) && jsonObject.getJSONObject("result")!=null && jsonObject.getJSONObject("result").getJSONObject("msg")!=null && "USER_DAILY_QUERY_OVER_LIMIT".equalsIgnoreCase(jsonObject.getJSONObject("result").getJSONObject("msg").getString("info"))) break
                        else Thread.sleep(350)
                    }
                    if(i >= 4) break
                } catch {
                    case e:Exception =>logger.error(">>>访问geo异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
                }
            }
        )
        jsonObject
    }


    def dept2(x:String, y:String): JSONObject ={
        var jsonObject:JSONObject = null
        val url = "http://gis-int.int.sfdc.com.cn:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=c2ee00ecb0164098b58569b5bdffe60d"
            .format(x, y)
        breakable(
            for(i<-0.until(5)){
                try {
                    jsonObject = HttpClientUtil.getJsonByGet(url)
                    logger.error(">>>访问dept2：url=" + url + ", json="+jsonObject)
                    Thread.sleep(350)
                    if(jsonObject!=null){
                        val status = jsonObject.getString("status")
                        if("0".equalsIgnoreCase(status)) break
                        else Thread.sleep(350)
                    }
                    if(i >= 4) break
                } catch {
                    case e:Exception =>logger.error(">>>访问dept2异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
                }
            }
        )
        jsonObject
    }


    def getCoorAoiDist(delivery_lgt:String, delivery_lat:String, aoi_id:String): JSONObject ={
        var jsonObject:JSONObject = null
        val url = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?x=%s&y=%s&aoiId=%s&type=side"
            .format(delivery_lgt, delivery_lat, aoi_id)
        breakable(
            for(i<-0.until(5)){
                try {
                    jsonObject = HttpClientUtil.getJsonByGet(url)
                    logger.error(">>>访问getCoorAoiDist：url=" + url + ", json="+jsonObject)
                    Thread.sleep(350)
                    if(jsonObject!=null){
                        val status = jsonObject.getString("code")
                        if("200".equalsIgnoreCase(status)) break
                        else Thread.sleep(350)
                    }
                    if(i >= 4) break
                } catch {
                    case e:Exception =>logger.error(">>>访问getCoorAoiDist异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
                }
            }
        )
        jsonObject
    }


    def rgsbAdd(city_code:String, address:String, zno_code:String, aoiid:String, src:String): JSONObject ={
        var jsonObject:JSONObject = null
        val url = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd"
        val json = new JSONObject()
        json.put("ak","7577390e76cc40b6ad6542640edd9d84")
        json.put("operSource","xgfk")
        val addressSave = new JSONObject()
        addressSave.put("cityCode",city_code)
        addressSave.put("address",address)
        addressSave.put("znoCode",zno_code)
        addressSave.put("aoiId",aoiid)
        addressSave.put("src",src)
        addressSave.put("type","1")
        json.put("addressSave",addressSave)

        breakable(
            for(i<-0.until(5)){
                try {
                    jsonObject = HttpClientUtil.getJsonByPostJson(url, json.toJSONString)
                    logger.error(">>>访问rgsbAdd：url" + i + "=" + url + ", json="+json + ", result="+jsonObject)
                    Thread.sleep(6000)
                    if(jsonObject!=null){
                        val success = jsonObject.getString("success")
                        if("true".equalsIgnoreCase(success)) break
                        else Thread.sleep(6000)
                    }
                    if(i >= 4) break
                } catch {
                    case e:Exception =>logger.error(">>>访问rgsbAdd：url" + i + "=" + url + ", json="+json + ", result="+jsonObject)
                }
            }
        )
        jsonObject
    }

}
