package com.sf.scala.tloc.onsiteapp

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.graph.aoi.common.util.KeyWordUtil
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util
import java.util.Calendar
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks._
import scala.util.{Failure, Success, Try}

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:692265
 * @TaskName:爬楼识别跑数
 * @Description:不上门模型之楼栋识别，调用接口耗时2h+
 */

object ClimbBuildingDiscern {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val buildUrl="http://sds-core-datarun.sf-express.com/datarun/building/getCoorPoiDist?x=%s&y=%s&poiId=%s&type=side"
    val buildingUrl ="http://gis-int.int.sfdc.com.cn:1080/building/address/identify?showserver=true&ak=3eb300d2e06947f7945cd02530a32fd2&cityCode=%s&address=%s&phone=%s&mobile=%s"
    val poiUrl="http://gis-gw.int.sfdc.com.cn:9080/atpoi/api"
    val saveClimbBuildingTmpKey = Array("waybill_no","zone_code","citycode","emp_code","address","phone","floor","similarity_address","date_time","aoicode","aoiname","buildingName","lngbuild","latbuild","isClimb","buildingId","bulidType","build_err_msg","climb_err_msg")
    val saveClimbBuildingKey = Array("waybill_no","dest_zone_code","dest_dist_code","dest_city_code","dest_county","dest_division_code","dest_area_code","dest_hq_code","dest_type_code","emp_code","signer_name","date_time","consignee_comp_name","consignee_addr","decrypt_phone","consignee_phone","consignee_cont_name","decrypt_mobile","consignee_mobile","inner_parcel_flag","self_send_flag","self_pickup_flag","delivery_lgt","delivery_lat","dest_province","aoi_id","aoi_name","aoi_address","aoi_type_code","aoi_type_name","aoicode","floor","isclimb","addr_new","building","buildingid","bulidtype","lngbuild","latbuild","build_err_msg","climb_err_msg","buildingid_src")
    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val start_day=args(1)
        val group_num=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
//        logger.error("获取楼栋信息维表数据")
//        val buildingMap: Broadcast[Map[String, String]] = getBulidingWkt(sparkSession)

        logger.error("获取爬楼识别数据")
        getAoiInfo(sparkSession,end_day,start_day,group_num)

//        val dataRdd=getAoiInfoV2(sparkSession,end_day,start_day)
//        SparkWrite.save2HiveStatic(sparkSession, dataRdd, saveClimbBuildingKey, "dm_gis.gis_onsite_service_build_discern_info",Array(("inc_day", end_day)), 25)
//
    }

    def getAoiInfo(spark: SparkSession,end_day:String,start_day:String,group_num:String)={

        //dm_gis.gis_onsite_service_info_v3 kt
        //dm_gis.gis_onsite_service_info_v10 phone
        var sql_poi=s"select poi_id  from dim.dim_poi_info_df  where inc_day='$end_day'"
        val poiWhiteSet = SparkRead.readHiveAsJson(spark, sql_poi)._1.map(x => x.getString("poi_id")).collect().toSet
        val poiWhiteSetBro = spark.sparkContext.broadcast(poiWhiteSet)

        var sql_white=
            """
              |
              |
              |
              |select * from dm_gis.aoi_building where type in ('全部完备','部分完备')
              |
              |
              |""".stripMargin

        //and city not in('571','755','411','510','592','022')

        val aoiWhiteSet = SparkRead.readHiveAsJson(spark, sql_white)._1.map(x => x.getString("aoiid").trim).collect().toSet
        val aoiWhiteSetBro = spark.sparkContext.broadcast(aoiWhiteSet)

        var sql=
            s"""
              |
              |select
              |a.*
              |,b.is_elevator
              |,c.keyword
              |,c.is_climb
              |,c.is_elevator2
              |,d.building
              |,d.buildingids
              |from
              |(select * from dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
              |left join
              |(select aoi_id,city_code,is_elevator  from
              |(
              |select *,row_number()over(partition by aoi_id order by update_time desc ) as rnk from dm_gis.td_aoi_elevator_result_aos where inc_day='$end_day' and is_delete='0' and aoi_id<>''
              |
              |)t where t.rnk=1) b  on a.dest_dist_code=b.city_code and a.aoi_id=b.aoi_id
              |left join
              |(select aoi_id,city_code,is_climb ,keyword,is_elevator as is_elevator2  from
              |(
              |select *,row_number()over(partition by aoi_id order by update_time desc ) as rnk from dm_gis.td_aoi_keyword_result_aos where inc_day='$end_day' and is_delete='0' and aoi_id<>'' and keyword<>''
              |
              |)t where t.rnk=1 ) c on a.dest_dist_code=c.city_code and a.aoi_id=c.aoi_id
              |left join (select waybill_no,'' as building,addressee_aoi_id as buildingids from  dwd.dwd_waybill_info_dtl_di where inc_day>='$start_day' and inc_day<='$end_day' and addressee_aoi_id<>'') d on a.waybill_no=d.waybill_no
              |
              |
              |
              |
              |""".stripMargin

        sql=
            s"""
              |
              |select * from tmp_dm_gis.dm_gis_onsite_service_waybill_mid_di where inc_day='$end_day' and group_num='$group_num'
              |
              |""".stripMargin
        logger.error("爬楼识别aoi"+sql)
        val (originRdd, columns) = SparkRead.readHiveAsJson(spark, sql)
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01407499", "692265", "不上门模型-楼栋识别", "", buildingUrl, "3eb300d2e06947f7945cd02530a32fd2", originRdd.count(), 50)

        val dataRdd: RDD[JSONObject] = originRdd.mapPartitionsWithIndex((index, iter) => {
            val poiWhiteSet = poiWhiteSetBro.value
            val aoiWhiteSet = aoiWhiteSetBro.value



            for (obj <- iter) yield {
                try{
                    val citycode = obj.getString("dest_dist_code")
                    val address = try {
                        obj.getString("consignee_addr").replace(" ","").replaceAll("\n","")
                    }catch {
                        case _=>{
                            ""
                        }
                    }
                    val phone=obj.getString("decrypt_phone")
                    val mobile=obj.getString("consignee_mobile")
                    val zone_code=obj.getString("dest_zone_code")
                    val aoi_id=obj.getString("aoi_id")
                    val keyword=obj.getString("keyword")
                    var is_elevator=obj.getString("is_elevator")
                    var buildingid=obj.getString("buildingids")

                    var isClimb=""
                    if(StringUtils.nonEmpty(is_elevator)){
                        if(is_elevator.equals("1"))
                            isClimb="0"
                        else if(is_elevator.equals("0")) {
                            isClimb="1"

                        }else if(is_elevator.equals("2")){
                            is_elevator=obj.getString("is_elevator2")
                            if(StringUtils.nonEmpty(keyword)){
                                //||KeyWordUtil.similarity(address,keyword)>0.7
                                if(address.contains(keyword)){
                                    isClimb=obj.getString("is_climb")
                                }

                            }

                        }

                    }

                    val (buildingName,lngbuild,latbuild,buildingId,bulidType,build_err_msg) = getBuildingName(address, citycode,phone,mobile,aoi_id)

                    obj.put("isclimb", isClimb)
                    //数据量较大，暂时只跑以下城市的楼栋识别
                    val citycodearr=Array("755","020","769","010","021","573","512","574","871","451","579","898","513","023","517","991")

                    if(StringUtils.nonEmpty(buildingId)&&buildingId.length>5){
                        obj.put("buildingid",buildingId)
                        obj.put("building",buildingName)
                        obj.put("buildingid_src","1")
                        obj.put("build_err_msg",build_err_msg)

                    }else if(StringUtils.nonEmpty(buildingid)&&poiWhiteSet.contains(buildingid)){
                        obj.put("buildingid_src","2")
                        obj.put("buildingid",buildingid)

                    }
                    else if(StringUtils.nonEmpty(aoi_id)&&aoiWhiteSet.contains(aoi_id.trim)){
                        val tmpobj = new JSONObject()
                        tmpobj.put("mobile", mobile)
                        tmpobj.put("tel", phone)
                        tmpobj.put("cityCode", citycode)
                        tmpobj.put("address", address)
                        tmpobj.put("aoiId", aoi_id)
                        tmpobj.put("requestId", "1")
                        val (buildingids,buildingnames,build_err) = getInterfaceData(tmpobj)
                        obj.put("climb_err_msg",build_err)
                        if(StringUtils.nonEmpty(buildingids)){
                            obj.put("buildingid",buildingids)
                            obj.put("building",buildingnames)
                            obj.put("buildingid_src","3")
                        }
                    }else{
                        obj.put("buildingid","")
                    }
                    if(obj.getString("date_time")==null)
                        obj.put("date_time","")
                }catch {case e:Exception=>logger.error(e.getStackTrace)}


                obj
            }
        }).distinct().repartition(25).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("爬楼识别数据量："+dataRdd.count())
        logger.error("savekey--->"+saveClimbBuildingKey.toString)
        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)
        dataRdd.take(10).foreach(println)

        saveDataToHive(spark,dataRdd,end_day,group_num)


//        dataRdd

    }


    def getAoiInfoV2(spark: SparkSession,end_day:String,start_day:String)={

        //dm_gis.gis_onsite_service_info_v3 kt
        //dm_gis.gis_onsite_service_info_v10 phone
        var sql_poi=s"select poi_id  from dim.dim_poi_info_df  where inc_day='$end_day'"
        val poiWhiteSet = SparkRead.readHiveAsJson(spark, sql_poi)._1.map(x => x.getString("poi_id")).collect().toSet
        val poiWhiteSetBro = spark.sparkContext.broadcast(poiWhiteSet)

        var sql_white=
            """
              |
              |
              |
              |select * from dm_gis.aoi_building where type in ('全部完备','部分完备')
              |
              |
              |""".stripMargin

        //and city not in('571','755','411','510','592','022')

        val aoiWhiteSet = SparkRead.readHiveAsJson(spark, sql_white)._1.map(x => x.getString("aoiid").trim).collect().toSet
        val aoiWhiteSetBro = spark.sparkContext.broadcast(aoiWhiteSet)

        var sql=
            s"""
               |
               |select
               |a.*
               |,b.is_elevator
               |,c.keyword
               |,c.is_climb
               |,c.is_elevator2
               |,d.building
               |,d.buildingids
               |from
               |(select * from dm_gis.dm_waybill_pai_dtl_di where inc_day='$end_day' and dest_dist_code='755' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
               |left join
               |(select aoi_id,city_code,is_elevator  from
               |(
               |select *,row_number()over(partition by aoi_id order by update_time desc ) as rnk from dm_gis.td_aoi_elevator_result_aos where inc_day='$end_day' and is_delete='0' and aoi_id<>''
               |
               |)t where t.rnk=1) b  on a.dest_dist_code=b.city_code and a.aoi_id=b.aoi_id
               |left join
               |(select aoi_id,city_code,is_climb ,keyword,is_elevator as is_elevator2  from
               |(
               |select *,row_number()over(partition by aoi_id order by update_time desc ) as rnk from dm_gis.td_aoi_keyword_result_aos where inc_day='$end_day' and is_delete='0' and aoi_id<>'' and keyword<>''
               |
               |)t where t.rnk=1 ) c on a.dest_dist_code=c.city_code and a.aoi_id=c.aoi_id
               |left join (select waybill_no,'' as building,addressee_aoi_id as buildingids from  dwd.dwd_waybill_info_dtl_di where inc_day>='$start_day' and inc_day<='$end_day' and addressee_aoi_id<>'') d on a.waybill_no=d.waybill_no
               |
               |
               |
               |
               |""".stripMargin

        logger.error("爬楼识别aoi"+sql)
        val (originRdd, columns) = SparkRead.readHiveAsJson(spark, sql)
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01407499", "692265", "不上门模型-楼栋识别", "", buildingUrl, "3eb300d2e06947f7945cd02530a32fd2", originRdd.count(), 50)

        val dataRdd: RDD[JSONObject] = originRdd.mapPartitionsWithIndex((index, iter) => {
            val poiWhiteSet = poiWhiteSetBro.value
            val aoiWhiteSet = aoiWhiteSetBro.value
            for (obj <- iter) yield {
                try{
                    val citycode = obj.getString("dest_dist_code")
                    val address = try {
                        obj.getString("consignee_addr").replace(" ","").replaceAll("\n","")
                    }catch {
                        case _=>{
                            ""
                        }
                    }
                    val phone=obj.getString("decrypt_phone")
                    val mobile=obj.getString("consignee_mobile")
                    val zone_code=obj.getString("dest_zone_code")
                    val aoi_id=obj.getString("aoi_id")
                    val keyword=obj.getString("keyword")
                    var is_elevator=obj.getString("is_elevator")
                    var buildingid=obj.getString("buildingids")

                    var isClimb=""
                    if(StringUtils.nonEmpty(is_elevator)){
                        if(is_elevator.equals("1"))
                            isClimb="0"
                        else if(is_elevator.equals("0")) {
                            isClimb="1"

                        }else if(is_elevator.equals("2")){
                            is_elevator=obj.getString("is_elevator2")
                            if(StringUtils.nonEmpty(keyword)){
                                if(address.contains(keyword)||KeyWordUtil.similarity(address,keyword)>0.7){
                                    isClimb=obj.getString("is_climb")
                                }

                            }

                        }

                    }

                    val (buildingName,lngbuild,latbuild,buildingId,bulidType,build_err_msg) = getBuildingName(address, citycode,phone,mobile,aoi_id)

                    obj.put("isclimb", isClimb)
                    //数据量较大，暂时只跑以下城市的楼栋识别
                    val citycodearr=Array("755","020","769","010","021","573","512","574","871","451","579","898","513","023","517","991")

                    if(StringUtils.nonEmpty(buildingId)&&buildingId.length>5){
                        obj.put("buildingid",buildingId)
                        obj.put("building",buildingName)
                        obj.put("buildingid_src","1")
                        obj.put("build_err_msg",build_err_msg)

                    }else if(StringUtils.nonEmpty(buildingid)&&poiWhiteSet.contains(buildingid)){
                        obj.put("buildingid_src","2")
                        obj.put("buildingid",buildingid)

                    }
                    else if(StringUtils.nonEmpty(aoi_id)&&aoiWhiteSet.contains(aoi_id.trim)){
                        val tmpobj = new JSONObject()
                        tmpobj.put("mobile", mobile)
                        tmpobj.put("tel", phone)
                        tmpobj.put("cityCode", citycode)
                        tmpobj.put("address", address)
                        tmpobj.put("aoiId", aoi_id)
                        tmpobj.put("requestId", "1")
                        val (buildingids,buildingnames,build_err) = getInterfaceData(tmpobj)
                        obj.put("climb_err_msg",build_err)
                        if(StringUtils.nonEmpty(buildingids)){
                            obj.put("buildingid",buildingids)
                            obj.put("building",buildingnames)
                            obj.put("buildingid_src","3")
                        }
                    }else{
                        obj.put("buildingid","")
                    }
                    if(obj.getString("date_time")==null)
                        obj.put("date_time","")
                }catch {case e:Exception=>logger.error(e.getStackTrace)}


                obj
            }
        }).distinct().repartition(25).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("爬楼识别数据量："+dataRdd.count())
        logger.error("savekey--->"+saveClimbBuildingKey.toString)
        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)
        dataRdd.take(10).foreach(println)

//        saveDataToHive(spark,dataRdd,end_day,group_num)


        dataRdd

    }

    def saveDataToHive(sparkSession:SparkSession,standardRdd:RDD[JSONObject],end_date:String,group_num:String)={

        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveClimbBuildingKey.indices) {
            schemaEle.append(StructField(saveClimbBuildingKey.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        val rowRdd = standardRdd.map(obj => {
            val row = new ArrayBuffer[String]
            for (i <- saveClimbBuildingKey.indices) {
                var tmpStr = JSONUtil.getJsonValSingle(obj, saveClimbBuildingKey.apply(i))
                row.append(tmpStr)
            }
            val ret = Row.fromSeq(row)
            ret
        })

        sparkSession.createDataFrame(rowRdd, schema).createOrReplaceTempView("tmp_result")

        var sql_w=
            s"""
               |
               |insert overwrite table tmp_dm_gis.dm_gis_onsite_service_build_discern_di partition(inc_day='$end_date',group_num='$group_num')
               |select
               |waybill_no
               |,dest_zone_code
               |,dest_dist_code
               |,dest_city_code
               |,dest_county
               |,dest_division_code
               |,dest_area_code
               |,dest_hq_code
               |,dest_type_code
               |,emp_code
               |,signer_name
               |,date_time
               |,consignee_comp_name
               |,consignee_addr
               |,decrypt_phone
               |,consignee_phone
               |,consignee_cont_name
               |,decrypt_mobile
               |,consignee_mobile
               |,inner_parcel_flag
               |,self_send_flag
               |,self_pickup_flag
               |,delivery_lgt
               |,delivery_lat
               |,dest_province
               |,aoi_id
               |,aoi_name
               |,aoi_address
               |,aoi_type_code
               |,aoi_type_name
               |,aoicode
               |,floor
               |,isclimb
               |,addr_new
               |,building
               |,buildingid
               |,bulidtype
               |,lngbuild
               |,latbuild
               |,build_err_msg
               |,climb_err_msg
               |,buildingid_src
               |from
               |tmp_result
               |
               |
               |
               |
               |""".stripMargin

        logger.error("存储标准化数据sql---》"+sql_w)
        sparkSession.sql(sql_w)
        logger.error("存储标准化数据完毕")

    }

    def getBuildingName(addr:String,citycode:String,phone:String,mobile:String,aoi_id:String): (String, String, String, String, String, String) ={

        //楼栋识别只有六个城市数据
        val citycodearr=Array("571","755","411","510","592","022")


        var nowHour = getHour()
        //楼栋识别只有六个城市数据



        val url=String.format(buildingUrl,citycode,URLEncoder.encode(addr,"utf-8").replaceAll("\\+","%20"),phone,mobile)
        var buildingName=""
        var lngbuild=""
        var latbuild=""
        var buildingId=""
        var bulidType=""
        var resultObj="接口无返回值"
        var status=""
        var aoiId="null"
        var build_err_msg="老楼栋服务接口"
        var msg=""
        if(!citycodearr.contains(citycode)){
            return (buildingName,lngbuild,latbuild,buildingId,bulidType,build_err_msg)
        }

        if(!(nowHour>=19||(nowHour>=0&&nowHour<9))){
            Thread.sleep(50)
        }else{
            Thread.sleep(25)
        }
        var jSONObject=new JSONObject()
        breakable {
            for(i<- 0 until 5){
                jSONObject = try {
                    HttpUtils.urlConnectionGetJson(url, 5000)
                }
                catch {
                    case _=>{
                        logger.error("error url-----> "+url)
                        build_err_msg="接口无返回值"
                        null
                    }

                }
                status=JSONUtil.getJsonVal(jSONObject,"status","-1")
                if(status.equals("-1")){
                    logger.error("access faill---->"+jSONObject)



                }else if(StringUtils.nonEmpty(msg)&&msg.contains("too")&&msg.contains("many")){
                    logger.error("access faill---->"+jSONObject)
                    Thread.sleep(10000)

                }
                else{
                    break
                }
            }

        }

//        GisUtil.getCoorDist()
        if(jSONObject!=null)
            {
//                logger.error("error data ------>"+jSONObject)
//                logger.error("error url-----> "+url)
                build_err_msg=jSONObject.toString()
                resultObj=jSONObject.toString()
                buildingName=try {
                    jSONObject.getJSONObject("result").getString("buildingName")
                }catch {case _=>{
                    ""
                }}

                lngbuild=try {
                    jSONObject.getJSONObject("result").getString("x")
                }catch {case _=>{
                    ""
                }}

                latbuild=try {
                    jSONObject.getJSONObject("result").getString("y")
                }catch {case _=>{
                    ""
                }}

                aoiId=JSONUtil.getJsonVal(jSONObject, "result.aoiId", "")
                bulidType = JSONUtil.getJsonVal(jSONObject, "result.type", "")
                if(bulidType.equals("aoi_one")){
                    buildingId=""
                }else{
                    val buildingIds= JSONUtil.getJsonVal(jSONObject, "result.buildingId", "")
                    val geocoderArray = JSONUtil.getJsonArrayFromObject(jSONObject, "result.others.geocoder")
                    for(i <- 0 until geocoderArray.size()){
                        val obj = geocoderArray.getJSONObject(i)
                        if(buildingIds.nonEmpty&&buildingIds.equals(JSONUtil.getJsonVal(obj,"id",""))){
                            buildingId= JSONUtil.getJsonVal(obj, "cell1", "").split("\\|")(0)
                        }

                    }
                }

//            if(status.equals("-1")){
//                build_err_msg=jSONObject.toString()
//            }

            }
            if(!(aoi_id!=null&&aoi_id.nonEmpty&&aoiId!=null&&aoiId.nonEmpty&&aoi_id.equals(aoiId))){
                buildingId=""
                buildingName=""
            }


//        (buildingName,url,jSONObject)
        (buildingName,lngbuild,latbuild,buildingId,bulidType,build_err_msg)
    }

    def getAoiCodeInfo(spark:SparkSession)={


        var sql="select aoi_id,aoi_code from dm_gis.cms_aoi_sch"
        logger.error("aoi信息"+sql)
        val (originRdd, columns) = SparkRead.readHiveAsJson(spark, sql)
        val aoiInfoMap: collection.Map[String, String] = originRdd.map(obj => {
            val aoi_id = obj.getString("aoi_id")
            val aoi_code = obj.getString("aoi_code")
            (aoi_id, aoi_code)

        }).collectAsMap()

        val aoiInfoMapBroadcast: Broadcast[collection.Map[String, String]] = spark.sparkContext.broadcast(aoiInfoMap)
        aoiInfoMapBroadcast

    }

    def getTimestamp(s: String) : Option[Long] = s match {
        case "" => Some(0)
        case _ => {
            val format = new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss")
            Try(format.parse(s).getTime/1000) match {
                case Success(t) => Some(t)
                case Failure(_) => Some(0)
            }
        }
    }

    def getSimilarityOfTwoAddr(AddrA:String,AddrB:String)={
        var Similarity=0.0
        try{
            if(AddrA.nonEmpty&&AddrB.nonEmpty){
                val addrA = AddrA.getBytes.toList
                val addrB = AddrB.getBytes.toList
                val intersectAddr = addrA.intersect(addrB)
                Similarity=(intersectAddr.length.toDouble/addrA.length.toDouble + intersectAddr.length.toDouble/addrB.length.toDouble)/2
            }
        }catch{
            case _=>{
                Similarity=0.0
            }
        }

        Similarity
    }

    /**
     * 访问http请求，返回JSON结果
     * @param url
     * @return
     */
    def getJsonByGet(url:String): JSONObject ={
        val httpClient = HttpClients.createDefault()
        var stringEntity:String = null
        var jsonObj:JSONObject = null
        var httpGet = new HttpGet(url)
        httpGet.setHeader("ak","606106a824974620a56d53f366485cd8")
        var httpResponse:CloseableHttpResponse = null
        try {
            httpResponse = httpClient.execute(httpGet)
        } catch {
            case e:Exception =>logger.error(">>>获取httpResponse异常："+e)
        }
        if (httpResponse!=null && httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
            val httpEntity:HttpEntity = httpResponse.getEntity
            try{
                stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
                try {
                    jsonObj = JSON.parseObject(stringEntity)
                } catch {
                    case e:Exception =>logger.error(">>>结果转换json独享异常："+e)
                }
            }
            catch {
                case e:Exception=>logger.error(">>>获取stringEntity异常："+e)
            }
        }
        httpResponse.close()
        httpClient.close()
        jsonObj
    }

    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }

    def getInterfaceData(parm:JSONObject)={

        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak","d4c3a0f6ed0044df8c1e4f0cc1dbfe6f")
        var nowHour = getHour()
        var build_err_msg="调用新楼栋服务接口"
        var status=""
        var msg=""
        if(nowHour>=0&&nowHour<4){
            Thread.sleep(140)
        }else{
            Thread.sleep(220)
        }

        var jSONObject=new JSONObject()
        breakable {
            for(i<- 0 until 5){
                jSONObject = try {
                    JSON.parseObject(HttpUtils.postJson(poiUrl, parm, stringToString))
                }
                catch {
                    case _=>{
                        logger.error("error url-----> "+poiUrl)
                        build_err_msg="接口无返回值"
                        new JSONObject()
                    }
                }
                status=JSONUtil.getJsonVal(jSONObject,"status","-1")
                msg=JSONUtil.getJsonVal(jSONObject,"result.msg","")
                if(status.equals("-1")){
                    logger.error("access faill---->"+jSONObject)
                }else if(StringUtils.nonEmpty(msg)&&msg.contains("too")&&msg.contains("many")){
                    logger.error("access faill---->"+jSONObject)
                    Thread.sleep(10000)

                }
                else{
                    break
                }
            }

        }

        val buildingid = JSONUtil.getJsonVal(jSONObject, "result.data.buildingId", "")
        val buildingname = JSONUtil.getJsonVal(jSONObject, "result.data.buildingName", "")
        if(!jSONObject.isEmpty){
            build_err_msg=jSONObject.toString()
        }

        (buildingid,buildingname,build_err_msg)




    }


    def judgeOutBuilding(date_time_timestamp:String,buildingId:String,trajectory_list:String,buildingMap:Map[String, String],citycode:String)={

        var outbuilding = "-1"
        var lngbuild=""
        if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
            if(buildingId!=null&&buildingId.nonEmpty){
                //                val trajectory_list = obj.getString("trajectory_data")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    var outBulidAllcnt=0l
                    var outBulidcnt=0l
                    breakable {
                        for (trajectory <- trajectory_list.split(";")) {
                            if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                                if (trajectory.split("_")(2).nonEmpty && trajectory.split("_")(2).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(2).toLong <= (date_time_timestamp.toLong + 180)) {
                                    var zx = trajectory.split("_")(0)
                                    var zy = trajectory.split("_")(1)
                                    var ac = trajectory.split("_")(3)
                                    if (zx.nonEmpty && zy.nonEmpty&&ac.nonEmpty&&ac.toLong<=50) {
                                        outBulidAllcnt+=1
                                        var wkt=""
                                        var distace=(-1.0)
                                        if(buildingMap.contains(buildingId)){
                                            wkt=buildingMap.getOrElse(buildingId,"")
                                        }
                                        if(StringUtils.nonEmpty(wkt)){
                                            distace = getGeoData(wkt,zx.toDouble,zy.toDouble)
                                        }
                                        if(distace<0)
                                            distace = getBuildDist(buildingId,zx,zy,citycode)

                                        if (distace <= 50.0&&distace>=0.0) {
                                            outbuilding = "0"
                                            break
                                        }else if(distace>50.0){
                                            outBulidcnt+=1
                                        }

                                        lngbuild=lngbuild+zx+"_"+zy+"_"+distace+";"
                                    }
                                }
                            }
                        }

                    }

                    if(outBulidcnt>=5&&(!outbuilding.equals("0"))){
                        outbuilding="1"

                    }else if(outbuilding.equals("0")){
                        outbuilding="0"
                    }else{
                        outbuilding="-1"
                    }
                }


            }


        }


        (outbuilding,lngbuild)


    }

    def getBuildDist(buildid:String,x:String,y:String,citycode:String): Double ={

        var nowHour = getHour()
        val citycodearr=Array("755","020","769","010","021","573","512","574","871","451","579","898","513","023","517","991")
        var dist=(-1.0)
        //        if(!citycodearr.contains(citycode)){
        //            return dist
        //        }
        if(nowHour>22){
            return dist
        }
        val url=String.format(buildUrl,x,y,buildid)

        Thread.sleep(70)
        var status=""
        var jSONObject=new JSONObject()
        breakable {
            for(i<- 0 until 5){
                jSONObject = try {
                    HttpUtils.urlConnectionGetJson(url, 5000)
                }
                catch {
                    case _=>{
                        logger.error("error url-----> "+url)
                        null
                    }
                }
                status=JSONUtil.getJsonVal(jSONObject,"success","false")
                if(!status.equals("true")){
                    logger.error("access faill---->"+jSONObject)
                }else{
                    break
                }
            }

        }
        if(jSONObject!=null){
            try{
                dist=JSONUtil.getJsonVal(jSONObject,"data","").toDouble
            }catch {case e:Exception=>{}}


        }
        dist

    }

    def getGeoData(wkt:String,x:Double,y:Double)={
        import com.sf.gis.uabs.common.util.GeoUtil
        var distance=(-1.0)
        try{
            val geom = GeoUtil.fromWkt(wkt)
            val point = GeoUtil.fromWkt(GeoUtil.buildPointWkt(x, y))
            distance = GeoUtil.getDistM(point.distance(geom))
        }catch {
            case _=>{
                logger.error("wkt------>"+wkt)
                distance=(-1.0)

            }
        }
        distance

    }

    def getBulidingWkt(spark:SparkSession)={
        var sql="select wkt,buildingid from dm_gis.building_info "
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val buildingMap: Map[String, String] = originRdd.map(obj => {
            val buildingId = obj.getString("buildingid")
            val wkt = obj.getString("wkt")
            (buildingId, wkt)

        }).collect().toMap
        spark.sparkContext.broadcast(buildingMap)

    }
}
