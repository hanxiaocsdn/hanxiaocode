package com.sf.scala.tloc.onsiteapp

import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之步数统计
 */
object ClimbBuildingDiscernStep {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveClimbBuildingKey = Array( "waybill_no","emp_code","date_time","aoicode","aoi_id","step","date_time_timestamp")
    val saveClimbBuildingTmpKey = Array("source_kt","waybill_no","dept_code","emp_code","addr","phone","floor","addr_new","signin_time","aoiid","building","lngbuild","latbuild","lng80","lat80","outaoi","outbuilding","step","doing","onsite","tag")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val start_day=args(1)
        val end_day=args(2)
        val citycode=args(3)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取爬楼识别数据")
        val dataRdd = getStep(sparkSession,start_day,end_day,citycode)
        logger.error("开始存储爬楼识别步数数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_step_info",Array(("inc_day", end_day)), 25)

    }

    def getStep(spark:SparkSession,start_day:String,end_day:String,citycode:String)={

        //dm_gis.gis_sensor_step_add
        //dm_gis.gis_sensor_step
        var sql=
            s"""
              |
              |  select
              | waybill_no
              | ,emp_code
              | ,date_time
              | ,aoicode
              | ,aoi_id
              | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
              | ,step_list
              | from
              | (select * from tmp_dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day'  and dest_dist_code='755' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
              | left join (select un,concat_ws(';',collect_set(concat(tm,'_',num))) as step_list from dm_gis.gis_sensor_step_add where  inc_day='$end_day' and !regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' and  app in ('sfxg','sfdg') and un is not null and un<>'' group by un) e on a.emp_code=e.un
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,4000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            var num_bf = 0L
            var num_sign = 0L
            var step = -1L
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val step_list = obj.getString("step_list")
                if (step_list!=null&&step_list.nonEmpty && step_list.split(";").length > 0) {
                    var step_tm_3 = 0L
                    var step_tm_20 = 0L
                    for (steps <- step_list.split(";")) {
                        if (steps!=null&&steps.nonEmpty && steps.split("_").length >= 1) {
                            if (steps.split("_")(0).nonEmpty && steps.split("_")(0).toLong >= (date_time_timestamp.toLong - 120) && steps.split("_")(0).toLong <= (date_time_timestamp.toLong)) {
                                if (Math.abs(steps.split("_")(0).toLong - date_time_timestamp.toLong) > step_tm_3 && steps.split("_")(1).nonEmpty) {
                                    step_tm_3 = Math.abs(steps.split("_")(0).toLong - date_time_timestamp.toLong)
                                    num_bf = steps.split("_")(1).toLong
                                }
                            }
                            if (steps.split("_")(0).nonEmpty && steps.split("_")(0).toLong >= (date_time_timestamp.toLong - 300) && steps.split("_")(0).toLong <= (date_time_timestamp.toLong-120)) {
                                if (Math.abs(steps.split("_")(0).toLong - date_time_timestamp.toLong) > step_tm_20 && steps.split("_")(1).nonEmpty) {
                                    step_tm_20 = Math.abs(steps.split("_")(0).toLong - date_time_timestamp.toLong)
                                    num_sign = steps.split("_")(1).toLong
                                }
                            }
                        }
                    }
                }
                if(Math.abs(num_sign)>0&&Math.abs(num_bf)>0){
                    step = Math.abs(num_sign - num_bf)
                }
            }
            obj.put("step", step)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        resultRdd

    }



}
