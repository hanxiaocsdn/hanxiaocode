package com.sf.scala.tloc.onsiteapp

import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-05-16  16:25
 * @TaskId:692265
 * @TaskName:不上门跑数
 * @Description:不上门模型之预处理doing数据
 */
object ClimbBuildingDiscernDoing {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveClimbBuildingKey = Array( "waybill_no","emp_code","date_time","aoicode","aoi_id","doing","date_time_timestamp","doing_time")
    val saveClimbBuildingTmpKey = Array("source_kt","waybill_no","dept_code","emp_code","addr","phone","floor","addr_new","signin_time","aoiid","building","lngbuild","latbuild","lng80","lat80","outaoi","outbuilding","step","doing","onsite","tag")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val start_day=args(1)
        val end_day=args(2)
        val citycode=args(3)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sqlContext.setConf("spark.sql.shuffle.partitions", "500")
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取爬楼识别数据")
        val dataRdd = getDoing(sparkSession,start_day,end_day,citycode)
        logger.error("开始存储爬楼识别步数数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_sensor_doing_info",Array(("inc_day", end_day)), 25)

    }



    def getDoing(spark:SparkSession,start_day:String,end_day:String,citycode:String)={

        var sql=
            s"""
              |
              | select
              | waybill_no
              | ,emp_code
              | ,date_time
              | ,aoicode
              | ,aoi_id
              | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
              | ,doing_list
              | from
              | (select * ,substr(cast(unix_timestamp(date_time,'yyyy-MM-dd HH:mm:ss') as string),0,6) tm_sub  from tmp_dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and dest_dist_code='755' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
              | left join (select un,substr(tm,0,6) as tm_sub,concat_ws(';',collect_set(concat(tm,'_',doing))) as doing_list from dm_gis.gis_sensor_doing where  inc_day='$end_day' and !regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' and un is not null and un<>'' group by un,substr(tm,0,6)) f on a.emp_code=f.un and a.tm_sub=f.tm_sub
              |
              |""".stripMargin


        sql=
            s"""
              |
              |select
              | waybill_no
              | ,emp_code
              | ,date_time
              | ,aoicode
              | ,aoi_id
              | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
              | ,doing_list
              | from
              | (select *  from dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
              | left join (select un,concat_ws(';',collect_set(concat(nvl(tm,''),'_',doing,'_',nvl(stm,''),'_',nvl(etm,'')))) as doing_list from dm_gis.gis_sensor_doing where  inc_day='$end_day' and !regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' and un is not null and un<>'' and doing<>'' and doing is not null group by un ) f on a.emp_code=f.un
              |
              |
              |
              |""".stripMargin


        sql=
            s"""
               |
               |select
               | waybill_no
               | ,emp_code
               | ,date_time
               | ,aoicode
               | ,aoi_id
               | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
               | ,doing_list
               | from
               | (select * ,substr(cast(unix_timestamp(date_time,'yyyy-MM-dd HH:mm:ss') as string),0,6) tm_sub  from tmp_dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day'  and dest_dist_code='755' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
               | left join (select un,case when tm is not null and tm<>'' then substr(tm,0,6) when stm is not null and stm<>'' then substr(stm,0,6) end as tm_sub,concat_ws(';',collect_set(concat(nvl(tm,''),'_',doing,'_',nvl(stm,''),'_',nvl(etm,'')))) as doing_list from dm_gis.gis_sensor_doing where  inc_day='$end_day' and regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '755' and un is not null and un<>'' and doing<>''  group by un,case when tm is not null and tm<>'' then substr(tm,0,6) when stm is not null and stm<>'' then substr(stm,0,6) end) f on a.emp_code=f.un and a.tm_sub=f.tm_sub
               |
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,2000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            var doing = ""
            var doing_time=""

            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val doingMap = new mutable.HashMap[String, Long]()
                val doing_list = obj.getString("doing_list")

                if (doing_list!=null&&doing_list.nonEmpty && doing_list.split(";").length > 0) {
                    for (doings <- doing_list.split(";")) {
                        if (doings!=null&&doings.nonEmpty && doings.split("_").length >= 1) {
                            if (doings.split("_")(0).nonEmpty ) {
                                if(doings.split("_")(0).toLong >= (date_time_timestamp.toLong - 300) && doings.split("_")(0).toLong <= date_time_timestamp.toLong){
//                                    doingSet.add(doings.split("_")(1))
                                    if(doingMap.contains(doings.split("_")(1))){
                                        doingMap.put(doings.split("_")(1),doingMap.get(doings.split("_")(1)).get+1L)
                                    }else{
                                        doingMap.put(doings.split("_")(1),1L)
                                    }
                                }

                            }else if(StringUtils.nonEmpty(doings.split("_")(2))&&StringUtils.nonEmpty(doings.split("_")(3))){
                                val stm=doings.split("_")(2)
                                val etm=doings.split("_")(3)
                                var start=0L
                                var end=0L
                                if(stm.toLong<(date_time_timestamp.toLong - 300)){
                                    start=(date_time_timestamp.toLong - 300)

                                }else if(stm.toLong>=(date_time_timestamp.toLong - 300)&&stm.toLong<date_time_timestamp.toLong){
                                    start=stm.toLong

                                }else{
                                    start=date_time_timestamp.toLong
                                }

                                if(etm.toLong>(date_time_timestamp.toLong - 300)&&etm.toLong<=date_time_timestamp.toLong){
                                    end=etm.toLong

                                }else if(stm.toLong>date_time_timestamp.toLong){
                                    end=date_time_timestamp.toLong

                                }

                                val freq=(end-start)/3
                                if(freq>0){
                                    if(doingMap.contains(doings.split("_")(1))){
                                        doingMap.put(doings.split("_")(1),doingMap.get(doings.split("_")(1)).get+freq)

                                    }else{
                                        doingMap.put(doings.split("_")(1),freq)
                                    }
                                }

                            }
                        }
                    }
                }
                val total = doingMap.values.sum.toDouble
                for(value<-doingMap){
                    doing_time=doing_time+","+value._1+":"+(value._2)/total
                }
                doing = doingMap.keySet.mkString(",")
            }
            if(doing_time.length>1){
                doing_time=doing_time.substring(1)
            }else{
                doing_time=""
            }


            obj.put("doing", doing)
            obj.put("doing_time", doing_time)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        resultRdd
    }

}
