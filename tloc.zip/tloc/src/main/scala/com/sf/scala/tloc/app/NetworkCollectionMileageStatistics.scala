package com.sf.scala.tloc.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.{DistanceTool, JSONUtil}
import com.sf.scala.tloc.utils.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * 【车油补】网点集里程统计_V1.0
 * 需求方：丁汀（01430258）
 *
 * @author 韩笑（01417629）
 *         Created on Mar.14 2023
 *         任务信息：：614166（网点集里程统计，一次性任务、2023年1月1日--2023年2月28日）
 */
object NetworkCollectionMileageStatistics {
  @transient lazy val logger: Logger = Logger.getLogger(NetworkCollectionMileageStatistics.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  def getBqData(spark: SparkSession, bqPath_1: String, bqPath_2: String) = {
    val df1: DataFrame = spark.read
      .option("inferschema", false)
      .option("header", false)
      .option("encoding", "UTF-8")
      .csv(bqPath_1)
      .toDF("month", "area", "dept", "emp_code", "emp_name", "postion", "total_all_dis", "all_bc_dis", "total_dept_dis", "kj_cz_bc_dis", "gl_area_yx_bc_dis", "dept_bc_dis", "total_kj_cz_dis", "total_gl_aoi_dis", "jb_dis", "db_xl_dis", "gchd_bc_dis", "sp_weight", "sp_cnt", "yx_cq_day")
      .persist(StorageLevel.MEMORY_AND_DISK)
    val df2: DataFrame = spark.read
      .option("inferschema", false)
      .option("header", false)
      .option("encoding", "UTF-8")
      .csv(bqPath_2)
      .toDF("month", "area", "dept", "emp_code", "emp_name", "postion", "total_all_dis", "all_bc_dis", "total_dept_dis", "kj_cz_bc_dis", "gl_area_yx_bc_dis", "dept_bc_dis", "total_kj_cz_dis", "total_gl_aoi_dis", "jb_dis", "db_xl_dis", "gchd_bc_dis", "sp_weight", "sp_cnt", "yx_cq_day")
      .persist(StorageLevel.MEMORY_AND_DISK)
    val df = df1.union(df2).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    df1.unpersist()
    df2.unpersist()
    logger.error(s"getBqData共 ${df.count()}")
    df.show(2)
    df
  }

  def getYdbData(spark: SparkSession, ydbPath_1: String, ydbPath_2: String) = {
    val df1: DataFrame = spark.read
      .option("inferschema", false)
      .option("header", false)
      .option("encoding", "UTF-8")
      .csv(ydbPath_1)
      .toDF("month", "area", "dept", "emp_code", "car_number", "car_type", "start_time", "end_time", "bt_type", "dis", "dis_rate", "nd_ratio", "nh_bz", "price_type", "price_bz", "bt_jiner", "xn_ratio", "end_nodify_time")
      .persist(StorageLevel.MEMORY_AND_DISK)
    val df2: DataFrame = spark.read
      .option("inferschema", false)
      .option("header", false)
      .option("encoding", "UTF-8")
      .csv(ydbPath_2)
      .toDF("month", "area", "dept", "emp_code", "car_number", "car_type", "start_time", "end_time", "bt_type", "dis", "dis_rate", "nd_ratio", "nh_bz", "price_type", "price_bz", "bt_jiner", "xn_ratio", "end_nodify_time")
      .persist(StorageLevel.MEMORY_AND_DISK)
    val df = df1.union(df2).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    df1.unpersist()
    df2.unpersist()
    logger.error(s"getYdbData共 ${df.count()}")
    df.show(2)
    df
  }

  def getPzData(spark: SparkSession, lcpzPath: String) = {
    val df: DataFrame = spark.read
      .option("inferschema", false)
      .option("header", false)
      .option("encoding", "UTF-8")
      .csv(lcpzPath)
      .toDF("dept_code", "dept_name", "dis_type", "eff_month", "un_eff_month", "final_modifyer", "final_modify_time")
      .persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s"getPzData共 ${df.count()}")
    df.show(2)
    df
  }

  def saveDetailData(spark: SparkSession, bqData: DataFrame, ydcData: DataFrame, pzData: DataFrame, distanceRdd: RDD[JSONObject], parDay_1: String) = {
    bqData.createOrReplaceTempView("bq_data_table")
    ydcData.createOrReplaceTempView("ydc_data_table")
    pzData.createOrReplaceTempView("pz_data_table")

    val schemaString = "dept_code_t1,dept_code_t2"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
    )
    val schema = StructType(fields)
    val rdd = distanceRdd.map(obj => {
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(obj, "dept_code_t1", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "dept_code_t2", "")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1)))
    val df = spark.createDataFrame(rdd, schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("distance_temp")

    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "net_statis_detail_data"

    //将明细数据插入表中
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	 t1.*
         |	,t2.dis
         |	,t2.price_type
         |	,t2.bt_jiner
         |	,t3.dept_name
         |	,t4.dept_code_5
         |from
         |
         |(
         |	select month,area,dept,emp_code,total_all_dis,all_bc_dis,total_dept_dis,dept_bc_dis from bq_data_table
         |) as t1
         |
         |
         |left join
         |
         |(
         |	select regexp_replace(month,'-','') as month,area,dept,emp_code,dis,price_type,bt_jiner from ydc_data_table
         |) as t2
         |
         |on t1.month = t2.month
         |and t1.area = t2.area
         |and t1.dept = t2.dept
         |and t1.emp_code = t2.emp_code
         |
         |left join
         |
         |(
         |	select dept_code,dept_name from pz_data_table group by dept_code,dept_name
         |) as t3
         |
         |on t1.dept = t3.dept_code
         |
         |left join
         |
         |(
         |	select dept_code_t1,concat_ws(',',collect_set(dept_code_t2)) as dept_code_5 from distance_temp group by dept_code_t1
         |) as t4
         |
         |on t1.dept = t4.dept_code_t1
         |""".stripMargin

    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: " + insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }

  def getDeptData(spark: SparkSession, parDay_1: String) = {
    val dr = "$"
    val sql =
      s"""
         |select
         |	t1.area_code
         |	,t1.dept_code as dept_code_t1
         |	,t1.longitude as longitude_t1
         |	,t1.latitude as latitude_t1
         |	,t2.dept_code as dept_code_t2
         |	,t2.longitude as longitude_t2
         |	,t2.latitude as latitude_t2
         |from
         |
         |(
         |	select
         |		 area_code
         |		,dept_code
         |		,longitude
         |		,latitude
         |	from dim.dim_dept_info_df where inc_day = '$parDay_1'
         | and longitude <> '' and longitude is not null
         | and latitude <> '' and latitude is not null
         | and longitude rlike '^\\\\d+\\\\.\\\\d+$dr'
         |and latitude rlike '^\\\\d+\\\\.\\\\d+$dr'
         |and delete_flg = '0'
         |) as t1
         |
         |left join
         |
         |(
         |	select
         |		area_code
         |		,dept_code
         |		,longitude
         |		,latitude
         |	from dim.dim_dept_info_df where inc_day = '$parDay_1'
         | and longitude <> '' and longitude is not null
         | and latitude <> '' and latitude is not null
         | and longitude rlike '^\\\\d+\\\\.\\\\d+$dr'
         |and latitude rlike '^\\\\d+\\\\.\\\\d+$dr'
         |and delete_flg = '0'
         |) as t2
         |
         |on t1.area_code = t2.area_code
         |
         |where t2.longitude is not null
         |and t2.latitude is not null
         |""".stripMargin
    val rdd = Util.getRowToJsonNew_1(spark, sql, 1000)
    val distinceRdd = rdd.map(obj => {
      val longitude_t1 = JSONUtil.getJsonVal(obj, "longitude_t1", "").toDouble
      val latitude_t1 = JSONUtil.getJsonVal(obj, "latitude_t1", "").toDouble
      val longitude_t2 = JSONUtil.getJsonVal(obj, "longitude_t2", "").toDouble
      val latitude_t2 = JSONUtil.getJsonVal(obj, "latitude_t2", "").toDouble
      //获取网点之间的距离
      val distance = DistanceTool.getGreatCircleDistance(longitude_t1, latitude_t1, longitude_t2, latitude_t2)
      obj.put("distance", distance)
      obj
    }).filter(obj => {
      val distince = JSONUtil.getJsonVal(obj, "distance", "")
      distince.nonEmpty && distince.toDouble < 5000
    }).persist(StorageLevel.MEMORY_AND_DISK)
    distinceRdd.take(2).foreach(println(_))
    logger.error(s"distinceRdd共 ${distinceRdd.count()}")
    distinceRdd
  }

  def saveResultData(spark: SparkSession, parDay_1: String) = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "net_statis_result_data"

    //
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	month
         |    ,area
         |    ,dept
         |    ,price_type
         |    ,dept_name
         |    ,dept_code_5
         |	,sum(bt_dis) over(partition by month,area,dept_code_5,price_type order by month,area,dept_code_5,price_type) as bt_dis_final
         |	,sum(bt_jiner_sum) over(partition by month,area,dept_code_5,price_type order by month,area,dept_code_5,price_type) as bt_jiner_final
         |	,sum(dept_ji_zong_dis_sum) over(partition by month,area,dept_code_5,price_type order by month,area,dept_code_5,price_type) as dept_ji_zong_dis_final
         |	,sum(dept_ji_quan_dis_sum) over(partition by month,area,dept_code_5,price_type order by month,area,dept_code_5,price_type) as dept_ji_quan_dis_final
         |from
         |(
         |	select
         |	   month
         |    ,area
         |    ,dept
         |    ,price_type
         |    ,dept_name
         |    ,dept_code_5
         |    ,sum(dis) as bt_dis
         |    ,sum(bt_jiner) as bt_jiner_sum
         |    ,sum(dept_ji_zong_dis) as dept_ji_zong_dis_sum
         |    ,sum(dept_ji_quan_dis) as dept_ji_quan_dis_sum
         |from
         |
         |(
         |	SELECT
         |    month
         |    ,area
         |    ,dept
         |    ,emp_code
         |    ,total_all_dis
         |    ,all_bc_dis
         |    ,total_dept_dis
         |    ,dept_bc_dis
         |    ,dis
         |    ,price_type
         |    ,bt_jiner
         |    ,dept_name
         |    ,dept_code_5
         |    ,(cast(total_all_dis as decimal(10,4)) + cast(all_bc_dis as decimal(10,4))) as dept_ji_zong_dis
         |    ,(cast(total_dept_dis as decimal(10,4)) + cast(dept_bc_dis as decimal(10,4))) as dept_ji_quan_dis
         | FROM dm_gis.net_statis_detail_data
         |  where inc_day = '$parDay_1'
         |) as t1
         |group by
         |  month
         |  ,area
         |  ,dept
         |  ,price_type
         |  ,dept_name
         |  ,dept_code_5
         |) as t2
         |""".stripMargin

    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: " + insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }

  def run(spark: SparkSession, parDay_1: String, parDay_2: String, bqPath_1: String, bqPath_2: String, ydbPath_1: String, ydbPath_2: String, lcpzPath: String) = {
    //加载巴枪轨迹里程月报数据
    val bqData = getBqData(spark, bqPath_1, bqPath_2)

    //加载油电补结果表
    val ydcData = getYdbData(spark, ydbPath_1, ydbPath_2)

    //加载里程规则配置表
    val pzData = getPzData(spark, lcpzPath)

    //获取中心网点5KM范围内的网点集
    val distanceRdd = getDeptData(spark, parDay_1)

    //保存明细相关字段
    saveDetailData(spark, bqData, ydcData, pzData, distanceRdd, parDay_1)

    //保存统计结果
    saveResultData(spark, parDay_1)
  }

  def main(args: Array[String]): Unit = {
    //配置sparkconf，生成sparksession对象
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    //接收脚本参数
    val parDay_1 = args(0) //t
    val parDay_2 = args(1) //t-1
    val bqPath_1 = args(2) //巴枪轨迹里程月报(1月)路径
    val bqPath_2 = args(3) //巴枪轨迹里程月报(2月)路径
    val ydbPath_1 = args(4) //油电补数据文件(1月)路径
    val ydbPath_2 = args(5) //油电补数据文件(2月)路径
    val lcpzPath = args(6) //里程规则配置数据文件路径

    //运行主代码
    run(spark, parDay_1, parDay_2, bqPath_1, bqPath_2, ydbPath_1, ydbPath_2, lcpzPath)

    //关闭spark
    spark.close()
  }
}
