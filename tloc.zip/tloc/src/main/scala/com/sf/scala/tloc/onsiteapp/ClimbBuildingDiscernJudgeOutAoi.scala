package com.sf.scala.tloc.onsiteapp

import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil}
import com.sf.scala.tloc.onsiteapp.ClimbBuildingDiscern.getHour
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks._

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之判定outaoi
 */
object ClimbBuildingDiscernJudgeOutAoi {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val CoorAoiDist="http://sds-core-datarun.int.sfcloud.local/datarun/aoi/getCoorAoiDist?aoiId=%s&x=%s&y=%s&type=side"
    val saveClimbBuildingKey = Array( "waybill_no","emp_code","date_time","aoicode","aoi_id","outaoi","date_time_timestamp")
    val saveClimbBuildingTmpKey = Array("source_kt","waybill_no","dept_code","emp_code","addr","phone","floor","addr_new","signin_time","aoiid","building","lngbuild","latbuild","lng80","lat80","outaoi","outbuilding","step","doing","onsite","tag")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
//        val start_day=args(1)
        val end_day=args(1)
        val city_code=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取爬楼识别数据")
//        val dataRdd = judgeOutAoi(sparkSession,end_day)
//        val dataRdd =judgeOutAoiNew(sparkSession,end_day,city_code)
        val dataRdd =judgeOutAoiV2(sparkSession,end_day,city_code)

        logger.error("开始存储爬楼识别轨迹数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_outaoi_info",Array(("inc_day", end_day)), 25)

    }

    /**
     * 老版outaoi判定逻辑
     * 因为调用接口计算坐标到aoi距离太慢故弃用
     * @param spark
     * @param end_day
     * @return
     */
    def judgeOutAoi(spark:SparkSession,end_day:String)={

        var sql=
            s"""
              |
              | select * from dm_gis.gis_onsite_service_trajectory_info where inc_day='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,2000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val aoi_id=obj.getString("aoi_id")
            var outaoi="-1"
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_data")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    val trajectory_arr: Array[String] = trajectory_list.split(";")
                    //排序
                    val trajectory_sort_list = sortTrajectory_list(trajectory_arr, date_time_timestamp)
                    var outaoicnt=0L
                    var allcnt=0L
                    breakable {
                        for (trajectory <- trajectory_sort_list) {
                            if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 3) {
                                if (trajectory.split("_")(3).nonEmpty && trajectory.split("_")(3).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(3).toLong <= (date_time_timestamp.toLong + 180)) {
                                    allcnt+=1
                                    var zx = trajectory.split("_")(1)
                                    var zy = trajectory.split("_")(2)
                                    if ( zx.nonEmpty && zy.nonEmpty&&aoi_id.nonEmpty) {
                                        val distace = getAoiDistance(aoi_id,zx,zy).toDouble
                                        if (distace <= 100.0) {
                                            outaoi = "0"
                                            break
                                        }else if(distace>100.0){
                                            outaoicnt+=1
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if(outaoicnt>=5&&aoi_id.nonEmpty&&(!outaoi.equals("0"))){
                        outaoi = "1"

                    }else if(outaoi.equals("0")){
                        outaoi="0"
                    }else{
                        outaoi = "-1"
                    }
                }
            }
            obj.put("outaoi", outaoi)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }

    def judgeOutAoiNew(spark:SparkSession,end_day:String,citycode:String)={

        var sql=
            s"""
               |
               | select
               | a.waybill_no
               | ,emp_code
               | ,date_time
               | ,aoicode
               | ,aoi_id
               | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
               | ,trajectory_list
               | from
               | (select * from dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
               | left join (select waybill_no,concat_ws(';',collect_set(concat(dis,'_',tm_track))) as trajectory_list  from dm_gis.dwb_wb_track_dlv_di where  inc_day='$end_day' and !regexp_replace(substring(bn_track, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' and ac_track<100 and dis>=0 and waybill_no is not null and waybill_no<>'' group by waybill_no) d on a.waybill_no=d.waybill_no
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,2000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val aoi_id=obj.getString("aoi_id")
            var outaoi="-1"
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    val trajectory_arr: Array[String] = trajectory_list.split(";")
                    //排序
//                    val trajectory_sort_list = sortTrajectory_list(trajectory_arr, date_time_timestamp)
                    var outaoicnt=0L
                    var allcnt=0L
                    breakable {
                        for (trajectory <- trajectory_arr) {
                            if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 1) {
                                if (trajectory.split("_")(1).nonEmpty && trajectory.split("_")(1).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(1).toLong <= (date_time_timestamp.toLong + 180)) {
                                    allcnt+=1
                                    val distace = trajectory.split("_")(0).toDouble
                                    if (distace <= 100.0&&distace>=0.0) {
                                        outaoi = "0"
                                        break
                                    }else if(distace>100.0){
                                        outaoicnt+=1
                                    }

                                }
                            }
                        }
                    }

                    if(outaoicnt>=5&&aoi_id.nonEmpty&&(!outaoi.equals("0"))){
                        outaoi = "1"

                    }else if(outaoi.equals("0")){
                        outaoi="0"
                    }else{
                        outaoi = "-1"
                    }
                }
            }
            obj.put("outaoi", outaoi)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }

    def judgeOutAoiV2(spark:SparkSession,end_day:String,citycode:String)={

        var sql=
            s"""
               |
               | select
               | a.waybill_no
               | ,emp_code
               | ,date_time
               | ,aoicode
               | ,aoi_id
               | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
               | ,trajectory_list
               | from
               | (select * from tmp_dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and dest_dist_code='755' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
               | left join (select waybill_no,concat_ws(';',collect_set(concat(dis,'_',tm_track,'_',ac_track,'_',tp_track))) as trajectory_list  from dm_gis.dwd_newwb_track_dlv_di where  inc_day='$end_day' and !regexp_replace(substring(bn_track, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' and ac_track<100 and dis>=0 and waybill_no is not null and waybill_no<>'' group by waybill_no) d on a.waybill_no=d.waybill_no
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,2000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val aoi_id=obj.getString("aoi_id")
            var outaoi="-1"
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    val trajectory_arr: Array[String] = trajectory_list.split(";")
                    //排序
                    //                    val trajectory_sort_list = sortTrajectory_list(trajectory_arr, date_time_timestamp)
                    var outaoicnt=0L
                    var allcnt=0L
                    breakable {
                        for (trajectory <- trajectory_arr) {
                            if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 1) {
                                if (trajectory.split("_")(1).nonEmpty && trajectory.split("_")(1).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(1).toLong <= (date_time_timestamp.toLong + 180)) {
                                    if(trajectory.split("_")(3).nonEmpty&&trajectory.split("_")(3).equals("5")){
                                        if(trajectory.split("_")(2).nonEmpty&&trajectory.split("_")(2).toLong<50){
                                            allcnt+=1
                                            val distace = trajectory.split("_")(0).toDouble
                                            if (distace <= 100.0&&distace>=0.0) {
                                                outaoi = "0"
                                                break
                                            }else if(distace>100.0){
                                                outaoicnt+=1
                                            }
                                        }
                                    }else{
                                        allcnt+=1
                                        val distace = trajectory.split("_")(0).toDouble
                                        if (distace <= 100.0&&distace>=0.0) {
                                            outaoi = "0"
                                            break
                                        }else if(distace>100.0){
                                            outaoicnt+=1
                                        }

                                    }
                                }
                            }
                        }
                    }

                    if(outaoicnt>=5&&aoi_id.nonEmpty&&(!outaoi.equals("0"))){
                        outaoi = "1"

                    }else if(outaoi.equals("0")){
                        outaoi="0"
                    }else{
                        outaoi = "-1"
                    }
                }
            }
            obj.put("outaoi", outaoi)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }

    def sortTrajectory_list(trajectoryArr:Array[String],date_time_timestamp:String)={
        val listBuffer: ListBuffer[String] = ListBuffer()
        for (trajectory <- trajectoryArr) {
            if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                if(trajectory.split("_")(2).nonEmpty){
                    val time_diff = math.abs(trajectory.split("_")(2).toLong - date_time_timestamp.toLong)
                    val trajectory_new=time_diff.toString+"_"+trajectory
                    listBuffer+=trajectory_new
                }
            }
        }
        listBuffer.sortBy(x => x).toArray

    }

    def getAoiDistance(aoiid:String,x:String,y:String)={
        val url = String.format(CoorAoiDist, aoiid,x,y)
        //接口访问限制 每分钟50000
        var nowHour = getHour()

        if(!(nowHour>=21||(nowHour>=0&&nowHour<9))){
            Thread.sleep(60)
        }else{
            Thread.sleep(30)
        }

        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case _=>{
                logger.error("error url-----> "+url)
                null
            }
        }
        var distance=JSONUtil.getJsonVal(jSONObject,"data","")

        if(distance.isEmpty){
            logger.error("erredata----->"+jSONObject)
            distance="100"
        }
        //        logger.error("y---->"+y+"x---->"+x+"---aoiid is " +aoiid+"aoi distance is "+distance)
        distance
    }

}
