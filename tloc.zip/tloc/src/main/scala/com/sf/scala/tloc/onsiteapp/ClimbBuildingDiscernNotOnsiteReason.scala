package com.sf.scala.tloc.onsiteapp

import com.sf.gis.java.util.DateUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-05-26  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之不上门原因判定
 */
object ClimbBuildingDiscernNotOnsiteReason {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )

    val saveClimbBuildingKey = Array("waybill_no","signin_tm","consignee_addr","holiday_legal_cn","operation","service_code","yuyinzhijian","pianhao","bukeru","xiaoyuan","xingzhengcun","not_onsite_tag")
    val saveClimbBuildingTmpKey = Array("source_kt","waybill_no","dept_code","emp_code","addr","phone","floor","addr_new","signin_time","aoiid","building","lngbuild","latbuild","lng80","lat80","outaoi","outbuilding","step","doing","onsite","tag")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val end_day=args(1)
        val start_day=args(2)

        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("不上门原因判定")
        val dataRdd = getCompetitor(sparkSession,end_day,start_day)
        logger.error("开始存储不上门原因数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_not_onsite_tag_info",Array(("inc_day", end_day)), 25)

    }

    def getCompetitor(spark:SparkSession,end_day:String,start_day:String)={

        val start=DateUtil.getCurrentDayDiff(end_day,-3)
        val end=DateUtil.getCurrentDayDiff(end_day,1)
        var sql=
            s"""
              |
              |select
              |a.*
              |,c.holiday_legal_cn
              |,d.operation
              |,f.service_code
              |,case when g.waybillno is not null and g.waybillno<>'' then '1' else '0' end as xiaoyuan
              |,case when h.class_code is not null and h.class_code='220' then '1' else '0' end as xingzhengcun
              |,case when i.pick='1'  then '0'  when i.pick='2' then '1' else null end as bukeru
              |,j.yuyinzhijian
              |,case when a.consignee_addr regexp '丰巢|蜂巢|菜鸟|驿站|快递柜|快递点|快递架|快递合作点|快递站|快递室|快递箱|快递房|快递框|快递棚|快递桌子|快递小屋|快递间|包裹柜|包裹点|包裹架|包裹合作点|包裹站|包裹室|包裹箱|包裹房|包裹框|包裹棚|包裹桌子|包裹小屋|包裹间|顺丰站点|E站|兔喜|网点|柜子|代收点|慧湖|点部|服务室|货柜|货架|抽屉柜|云柜|自提柜|监控室|服务站|蜜罐|宜家|快递中心|淘宝|百世|美佳|幺零幺|优家|淘老大|便利|邮家|熊猫|金河|家乐美|物架|小蜜蜂|小兵|京东|顺丰点|门卫|门房|门岗|收发室|签收室|保安室|值班室|服务室|传达室|超市|便利店' and !(a.consignee_addr  regexp '不要放|勿放|禁止放|勿投|别放|不要给我放|别给我放|拒绝放|拒放|勿存放|不放') then '1' else '0' end as addr_ziqu
              |,k.isfwsjg2g
              |,l.require_type
              |from
              |(select * from dm_gis.gis_onsite_service_mid_data where inc_day='$end_day' and waybill_no is not null and waybill_no<>'') a
              |left join
              |(select waybillno,from_unixtime(max(ceil(barscantm/1000)),'yyyy-MM-dd') barscantm  from  ods_kafka_fvp.fvp_core_fact_route_rt where inc_day='$end_day'  and opcode='204' group by waybillno) b on a.waybill_no=b.waybillno
              |left join dm_gis.ddjy_dim_holiday_legal_cn_yi c on b.barscantm=c.`date`
              |left join
              |( select waybill_no waybillno ,operation  from ods_shiva_oms.tt_operation_waybill_special_handler where inc_day<='$end_day' and inc_day>='$start_day' and  code='32024' and waybill_no is not null and waybill_no<>'' group by waybill_no ,operation) d on a.waybill_no=d.waybillno
              |left join
              |(select waybillno,case when split(max(concat(create_time,'\001',service_code)),'\001')[1] regexp '1|2|4|6|7|8|19|32|41|48' then '0' when concat_ws(',',collect_set(service_code)) regexp '5|21|22|23|24|25|33|39|44|28' then '1' end as service_code  from ods_awsm.awsm_requirement where inc_day<='$end_day' and inc_day>='$start_day' and  (`status`='30' or `status`='20')  and waybillno<>'' group by waybillno) f on a.waybill_no=f.waybillno
              |left join (select waybillno from dm_gis.gis_eta_navi_campus_dispatch_v2 where inc_day<='$end_day' and inc_day>='$start_day' and stumark='1'  group by waybillno ) g on a.waybill_no=g.waybillno
              |left join (select aoi_id,class_code from
              |(
              |select aoi_id,village_guid from (
              |select aoi_id,village_guid,row_number()over(partition by aoi_id order by update_date desc  ) rnk from dm_gis.cms_aoi_village where inc_day='$end_day'
              |
              |)t where t.rnk=1)
              |a
              |left join
              |(
              |select class_code,guid from dm_gis.emap_district_village
              | where inc_day in (select inc_day from dm_gis.emap_district_village order by inc_day desc limit 1)
              |) b on a.village_guid=b.guid) h on a.aoi_id=h.aoi_id
              |left join (select aoi_id,pick from (
              |select aoi_id,pick,row_number()over(partition by aoi_id order by update_date) as rnk from dm_gis.aoi_building_lift where inc_day='$end_day' and aoi_id<>''
              |) t
              |where t.rnk=1   ) i on a.aoi_id=i.aoi_id
              |left join (select max(case when fn_score_at is not null and fn_score_at<>'' and fs_srdnames_at is not null and fs_srdnames_at<>'' and !(fs_srdnames_at regexp '不上门') then '1' when fn_score_at='100' and (fs_srdnames_at is null or fs_srdnames_at='') then '1' when fn_score_at<>'' and fn_score_at is not null and fs_srdnames_at regexp '不上门' and shuke='1' then '1'  else '0' end) as yuyinzhijian,waybill_no waybillno,qcs_emp_code	as emp_code  from dm_aicc_xg_qcs.dm_tb_isqa_order_result_sum_di where inc_day<='$end_day' and inc_day>='$start' and waybill_no<>''  and fn_score_at<>'' group by waybill_no,qcs_emp_code) j on a.waybill_no=j.waybillno and a.emp_code=j.emp_code
              |left join (select waybill_no,istougui,iszhuanjituihui,iscopyphone,isfwsjg2g,isexternal,cntyizhan100 from dm_gis.lbs_loc_index where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' group by waybill_no,istougui,iszhuanjituihui,iscopyphone,isfwsjg2g,isexternal,cntyizhan100) k on a.waybill_no=k.waybill_no
              |left join (select waybill_no,require_type from (
              |
              |select waybill_no,require_type,row_number()over(partition by waybill_no order by create_tm desc) rnk  from dwd_o.dwd_cust_fdbk_dtl_di where inc_day>='$start' and inc_day<='$end'  and (require_type regexp '自取' or  require_type='改上门-指定位置')
              |
              |) t
              |where t.rnk=1) l on a.waybill_no=l.waybill_no
              |
              |
              |
              |""".stripMargin

        sql=
            s"""
              |
              |select
              |a.*
              |,c.holiday_legal_cn
              |,d.operation
              |,f.service_code
              |,case when g.waybillno is not null and g.waybillno<>'' then '1' else '0' end as xiaoyuan
              |,case when h.class_code is not null and h.class_code='220' then '1' else '0' end as xingzhengcun
              |,case when i.pick='1'  then '0'  when i.pick='2' then '1' else null end as bukeru
              |,j.yuyinzhijian
              |,case when a.consignee_addr regexp '丰巢|蜂巢|菜鸟|驿站|快递柜|快递点|快递架|快递合作点|快递站|快递室|快递箱|快递房|快递框|快递棚|快递桌子|快递小屋|快递间|包裹柜|包裹点|包裹架|包裹合作点|包裹站|包裹室|包裹箱|包裹房|包裹框|包裹棚|包裹桌子|包裹小屋|包裹间|顺丰站点|E站|兔喜|网点|柜子|代收点|慧湖|点部|服务室|货柜|货架|抽屉柜|云柜|自提柜|监控室|服务站|蜜罐|宜家|快递中心|淘宝|百世|美佳|幺零幺|优家|淘老大|便利|邮家|熊猫|金河|家乐美|物架|小蜜蜂|小兵|京东|顺丰点|门卫|门房|门岗|收发室|签收室|保安室|值班室|服务室|传达室|超市|便利店' and !(a.consignee_addr  regexp '不要放|勿放|禁止放|勿投|别放|不要给我放|别给我放|拒绝放|拒放|勿存放|不放') then '1' else '0' end as addr_ziqu
              |,k.isfwsjg2g
              |,l.require_type
              |from
              |(select * from tmp_dm_gis.gis_onsite_service_mid_data where inc_day='$end_day' and waybill_no is not null and waybill_no<>'') a
              |left join
              |(select waybillno,from_unixtime(max(ceil(barscantm/1000)),'yyyy-MM-dd') barscantm  from  ods_kafka_fvp.fvp_core_fact_route_rt where inc_day='$end_day'  and opcode='204' group by waybillno) b on a.waybill_no=b.waybillno
              |left join (select case when is_work='Y' then '工作日' when public_holiday<>'' then '法定节假日' end as holiday_legal_cn,day_name from dim.dim_calendar_cfg_yi) c on b.barscantm=c.`day_name`
              |left join
              |( select waybill_no waybillno ,operation  from ods_shiva_oms.tt_operation_waybill_special_handler where inc_day<='$end_day' and inc_day>='$start_day' and  code='32024' and waybill_no is not null and waybill_no<>'' group by waybill_no ,operation) d on a.waybill_no=d.waybillno
              |left join
              |(select waybillno,split(max(concat(create_time,'\001',service_code)),'\001')[1] as service_code  from ods_awsm.awsm_requirement where inc_day<='$end_day' and inc_day>='$start_day' and  (`status`='30' or `status`='20')  and waybillno<>'' group by waybillno) f on a.waybill_no=f.waybillno
              |left join (select waybillno from dm_gis.gis_eta_navi_campus_dispatch_v2 where inc_day<='$end_day' and inc_day>='$start_day' and stumark='1'  group by waybillno ) g on a.waybill_no=g.waybillno
              |left join (select aoi_id,class_code from
              |(
              |select aoi_id,village_guid from (
              |select aoi_id,village_guid,row_number()over(partition by aoi_id order by update_date desc  ) rnk from dm_gis.cms_aoi_village where inc_day='$end_day'
              |
              |)t where t.rnk=1)
              |a
              |left join
              |(
              |select class_code,guid from dm_gis.emap_district_village
              | where inc_day in (select inc_day from dm_gis.emap_district_village order by inc_day desc limit 1)
              |) b on a.village_guid=b.guid) h on a.aoi_id=h.aoi_id
              |left join (select aoi_id,pick from (
              |select aoi_id,pick,row_number()over(partition by aoi_id order by update_date desc) as rnk from dm_gis.aoi_building_lift where inc_day='$end_day' and aoi_id<>''
              |) t
              |where t.rnk=1   ) i on a.aoi_id=i.aoi_id
              |left join (select max(case when fn_score_at is not null and fn_score_at<>'' and fs_srdnames_at is not null and fs_srdnames_at<>'' and !(fs_srdnames_at regexp '不上门') then '1' when fn_score_at='100' and (fs_srdnames_at is null or fs_srdnames_at='') then '1' when fn_score_at<>'' and fn_score_at is not null and fs_srdnames_at regexp '不上门' and shuke='1' then '1'  else '0' end) as yuyinzhijian,waybill_no waybillno,qcs_emp_code	as emp_code  from dm_aicc_xg_qcs.dm_tb_isqa_order_result_sum_di where inc_day<='$end_day' and inc_day>='$start' and waybill_no<>''  and fn_score_at<>'' group by waybill_no,qcs_emp_code) j on a.waybill_no=j.waybillno and a.emp_code=j.emp_code
              |left join (select waybill_no,istougui,iszhuanjituihui,iscopyphone,isfwsjg2g,isexternal,cntyizhan100 from tmp_dm_gis.lbs_loc_index where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' group by waybill_no,istougui,iszhuanjituihui,iscopyphone,isfwsjg2g,isexternal,cntyizhan100) k on a.waybill_no=k.waybill_no
              |left join (select waybill_no,require_type from (
              |
              |select waybill_no,require_type,row_number()over(partition by waybill_no order by create_tm desc) rnk  from dwd_o.dwd_cust_fdbk_dtl_di where inc_day>='$start' and inc_day<='$end'  and (require_type regexp '自取' or  require_type='改上门-指定位置')
              |
              |) t
              |where t.rnk=1) l on a.waybill_no=l.waybill_no
              |
              |
              |
              |""".stripMargin
        //dm_gis.gis_onsite_service_mid_data

        //1|2|4|6|7|8|19|28|32|41|48
        //1|2|4|6|7|8|19|32|41|48
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,8000)
        val resultRdd=dataRdd.map(obj => {
            val operation = obj.getString("operation")
            val holiday_legal_cn = obj.getString("holiday_legal_cn")
            val service_code = obj.getString("service_code")
            val xiaoyuan = obj.getString("xiaoyuan")
            val xingzhengcun = obj.getString("xingzhengcun")
            val xingguanjia = obj.getString("xingguanjia")
            val inner_parcel_flag = obj.getString("inner_parcel_flag")
            val require_type=obj.getString("require_type")

            val bukeru = obj.getString("bukeru")
            val yuyinzhijian = obj.getString("yuyinzhijian")
            val addr_ziqu = obj.getString("addr_ziqu")
            val isfwsjg2g = obj.getString("isfwsjg2g")
            var not_onsite_tag=""
            var pianhao="0"
            val resultSet = new mutable.HashSet[String]()
            if(StringUtils.nonEmpty(operation)&&operation.split(";").size>0){
                for(operationItem<-operation.split(";")){
                    if(StringUtils.nonEmpty(operationItem)&&operationItem.startsWith("6")&&StringUtils.nonEmpty(holiday_legal_cn)&&holiday_legal_cn.equals("工作日")){
                        pianhao="1"
                    }else if(StringUtils.nonEmpty(operationItem)&&operationItem.startsWith("8")&&StringUtils.nonEmpty(holiday_legal_cn)&&holiday_legal_cn.equals("法定节假日")){
                        pianhao="1"
                    }

                }
            }

            if(StringUtils.nonEmpty(service_code)&&Array("5","21","22","23","24","25","33","39","44","28").contains(service_code)){
                pianhao="1"
            }
            if(StringUtils.nonEmpty(service_code)&&Array("1","2","4","6","7","8","19","32","41","48").contains(service_code)){
                pianhao="0"
            } else if(StringUtils.nonEmpty(require_type)){
                if(require_type.contains("节假日自取")&&StringUtils.nonEmpty(holiday_legal_cn)&&holiday_legal_cn.equals("法定节假日")){
                    pianhao="1"

                }else if(require_type.contains("工作日自取")&&StringUtils.nonEmpty(holiday_legal_cn)&&holiday_legal_cn.equals("工作日")){
                    pianhao="1"
                }else{
                    pianhao="1"
                }

            }
            if(StringUtils.nonEmpty(yuyinzhijian)&&yuyinzhijian.equals("1")){
                resultSet.add("1")
            }
            if(StringUtils.nonEmpty(pianhao)&&pianhao.equals("1")){
                resultSet.add("2")
            }
            if(StringUtils.nonEmpty(bukeru)&&bukeru.equals("1")){
                resultSet.add("3")
            }
            if(StringUtils.nonEmpty(xiaoyuan)&&xiaoyuan.equals("1")){
                resultSet.add("4")
            }
            if(StringUtils.nonEmpty(xingzhengcun)&&xingzhengcun.equals("1")){
                resultSet.add("5")
            }
            if(StringUtils.nonEmpty(isfwsjg2g)&&isfwsjg2g.equals("1")){
                resultSet.add("6")
            }
            if(StringUtils.nonEmpty(addr_ziqu)&&addr_ziqu.equals("1")){
                resultSet.add("7")
            }
            if(StringUtils.nonEmpty(inner_parcel_flag)&&inner_parcel_flag.equals("1")){
                resultSet.add("10")
            }
            if(StringUtils.nonEmpty(xingguanjia)&&xingguanjia.equals("是")){
                resultSet.add("11")
            }
            if(resultSet.size>0){
                not_onsite_tag=resultSet.mkString(",")
            }else{
                not_onsite_tag="8"
            }

            obj.put("pianhao",pianhao)
            obj.put("not_onsite_tag",not_onsite_tag)
            obj
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }



}
