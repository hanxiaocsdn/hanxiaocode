package com.sf.scala.tloc.app
import com.sf.gis.java.base.util.{HbaseUtil, JsonArraySortUtil, SaltUtil}
import java.text.SimpleDateFormat
import java.time.{Duration, Instant}
import java.util

import scala.collection.JavaConverters._
import com.alibaba.druid.util.Utils.md5
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.AkUtil
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpUtils, SaveResultUtil}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/*
*汪勇项目-袁佳
*/
object TracksSimilarityCompare {
  System.setProperty("hadoop.home.dir", "C:\\dev\\hadoop\\hadoop-common-2.2.0-bin-master")

  @transient lazy val logger: Logger = Logger.getLogger(this.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  //测试
  //val comparetracksUrl = "http://10.202.116.145:18081/comparetracks"
  //val returnSimilarityUrl = "http://gis-int.intsit.sfdc.com.cn:1080/smgr/api/tracks/similarity/result"
  //val zkQuorum = "10.202.34.200,10.202.34.201,10.202.34.202,10.202.34.203,10.202.116.36,10.202.116.37,10.202.116.38,10.202.116.39,10.202.116.40";

  //生产
  val comparetracksUrl = "http://gis-lss-xsd.int.sfdc.com.cn:1080/comparetracks"

  val returnSimilarityUrl = "http://gis-int2.int.sfdc.com.cn:1080/smgr/api/tracks/similarity/result"
  val returnSimilarityLimitMin = 30000 / 150

  //zk
  val zkQuorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
  val zkPort = "2181";
  val zkParent = "/hbase";

  val dataTbPartitionNum = 10 // hbae表预分区数量
  val calpartition = 400


  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Spark.getSparkConf(appName, null)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    //val parDay = "20200704"
    val parDay = args(0)

    //获取星管家轨迹数据
    val (xgjRDD, xgjEmpList) = getXGJTrackRdd(spark, parDay)

    //获取小哥纠偏前轨迹数据,并通过工号关联两个轨迹并判断纠偏前轨迹是否在妥投时间和交接时间内
    val xiaogeTrackRDD = getXiaogeTrackRdd(spark, parDay, xgjEmpList)

    //通过工号关联轨迹数据,并判断纠偏前轨迹是否在妥投时间和交接时间内
    val joinRdd = doJoin(xgjRDD, xiaogeTrackRDD)

    //调用轨迹对比接口,得到相似度的值
    val similarityRdd = getSimilarity(joinRdd, ">>>调用轨迹对比接口获取相似度<<<")

    logger.error(s">>>获取到有效的的similarity：共 ${similarityRdd.filter(obj => 0d != obj.getDouble("similarity")).count()}<<<")

    //调用星管家写数据接口，进行数据结果回传
    val returnRdd = returnSimilarity(similarityRdd)

    //将回传失败结果写回hbase,由后端服务进行处理
    writeHbase(returnRdd)

    //写入hive
    SaveResultUtil.saveResult(logger, spark, returnRdd, saveSimilarity, "xgj_xg_tracks_similarity_compare", parDay)
  }

  val saveSimilarity = (saveRDD: RDD[JSONObject], path: String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("waybill_no")).append("\t")
      sb.append(obj.getString("emp_no")).append("\t")
      sb.append(obj.getString("start_time")).append("\t")
      sb.append(obj.getString("end_time")).append("\t")
      sb.append(obj.getString("similarity")).append("\t")
      sb.append(StringUtils.deleteWhitespace(obj.getString("reqJson"))).append("\t")
      sb.append(StringUtils.deleteWhitespace(obj.getString("compareResp"))).append("\t")
      sb.append(obj.getString("erroInfo")).append("\t")
      sb.append(obj.getString("tracks1")).append("\t")
      sb.append(obj.getString("tracks2")).append("\t")
      sb.append(StringUtils.deleteWhitespace(obj.getString("returnReq"))).append("\t")
      sb.append(StringUtils.deleteWhitespace(obj.getString("returnResp"))).append("\t")
      sb.append(obj.getString("state")).append("\t")
      sb.append(obj.getString("rowKey")).append("\t")
      sb.append(obj.getString("status")).append("\t")
      sb.append(obj.getString("smgr_no"))

      sb.toString()
    }).saveAsTextFile(path)
  }

  val seqOp = (a: List[JSONObject], b: JSONObject) => a.size match {
    case 0 => List(b)
    case _ => b :: a
  }

  val combOp = (a: List[JSONObject], b: List[JSONObject]) => {
    a ::: b
  }

  def writeHbase(returnRdd: RDD[JSONObject]) = {
    val hTable = "gis:tloc_wangyong_history"
    val family = "info"

    returnRdd.foreachPartition(iter => {
      val keyMap = new util.HashMap[String, util.HashMap[String, String]]()
      HbaseUtil.init(zkQuorum, zkPort, zkParent)

      iter.foreach(obj => {
        val status = obj.getString("status")
        val state = obj.getString("state")

        val valueMap = new util.HashMap[String, String]()
        val key = obj.getString("rowKey")

        //status:1 返回失败,重新生成一行数据 ; status:1 返回成功,将相似度和计算状态插入当前行
        if ("1".equals(status)) {
          val key1 = key.replace("_0_", "_1_")
          val valueMap1 = new util.HashMap[String, String]()

          val smgr_no = obj.getString("smgr_no")
          valueMap1.put("emp_no", obj.getString("emp_no"))
          valueMap1.put("end_time", obj.getString("end_time"))
          valueMap1.put("smgr_no", if (StringUtils.isNotBlank(smgr_no)) smgr_no else "")
          valueMap1.put("start_time", obj.getString("start_time"))
          valueMap1.put("tracks", obj.getString("tracks"))
          valueMap1.put("waybill_no", obj.getString("waybill_no"))
          valueMap1.put("state", state)
          valueMap1.put("similarity", obj.getString("similarity"))

          keyMap.put(key1, valueMap1)
        }

        valueMap.put("state", state)
        valueMap.put("similarity", obj.getString("similarity"))
        keyMap.put(key, valueMap)
      })

      if (!keyMap.isEmpty)
        HbaseUtil.put(hTable, family, keyMap)
    })

    logger.error("写入hbase成功")

  }

  def doPost(url: String, reqJson: JSONObject) = {
    var resbonseBody = "{}"

    try {
      resbonseBody = HttpUtils.post(url, reqJson, "utf-8")
    } catch {
      case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
        try {
          resbonseBody = HttpUtils.post(url, reqJson, "utf-8")
        } catch {
          case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
            resbonseBody = "发送post请求失败:" + e.toString
        }
    }

    resbonseBody
  }

  def doPostSingle(url: String, reqJson: JSONObject) = {
    var resbonseBody = "{}"

    try {
      resbonseBody = HttpUtils.post(url, reqJson, "utf-8")
    } catch {
      case e: Exception => logger.error(e + s"\n>>>发送post请求失败<<<\n$reqJson")
        resbonseBody = "发送post请求失败:" + e.toString
    }

    resbonseBody
  }

  def returnSimilarity(similarityRdd: RDD[JSONObject]) = {
    logger.error(">>>开始回传相似度<<<")
    val returnRdd = similarityRdd.mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)

      for (obj <- iter) yield {
        val similarity = obj.getDouble("similarity")

        //0:为计算相似度成功;1:计算相似度失败
        val state = if (0 == similarity) 1 else 0
        obj.put("state", state)

        val reqJson = new JSONObject()
        reqJson.put("ak", "8fb9ff4645124ea1ae0e6bc93690a14d")
        reqJson.put("waybill_no", obj.getString("waybill_no"))
        reqJson.put("emp_no", obj.getString("emp_no"))
        reqJson.put("start_time", obj.getString("start_time"))
        reqJson.put("end_time", obj.getString("end_time"))
        reqJson.put("smgr_no", obj.getString("smgr_no"))
        reqJson.put("tracks", obj.getJSONArray("tracks"))
        reqJson.put("similarity", similarity)

        val start = System.currentTimeMillis()
        //返回相似度数据
        val resbonseBody = doPostSingle(returnSimilarityUrl, reqJson)
        val end = System.currentTimeMillis()
        logger.error(s"回传cost ->${end - start}:$reqJson")

        //限制ak使用
        AkUtil.limitAkUse(startTime, cnt, index, returnSimilarityLimitMin, logger)

        obj.put("returnReq", reqJson)
        obj.put("returnResp", resbonseBody)

        //2:返回成功  1:返回失败
        val status = try {
          JSON.parseObject(resbonseBody).getInteger("status")
        } catch {
          case e: Exception => 1
        }
        obj.put("status", if (0 == status) 0 else 1)

        obj
      }
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共返回数据:${returnRdd.count()}")

    similarityRdd.unpersist()

    val count = returnRdd.filter(0 == _.getInteger("status")).count()

    logger.error(s">>>回传相似度成功：$count<<<")

    if (count == 0)
      throw new RuntimeException(s"回传相似度接口异常:${returnRdd.take(3).foreach(obj => logger.error(obj.getString("returnResp")))}")
    else returnRdd

  }

  def getSimilarity(joinRdd: RDD[JSONObject], infos: String) = {
    logger.error(s"$infos")

    val similarityRdd = joinRdd.map(obj => {
      var similarity = 0d

      val xgjTracksJson = JSON.parseArray(obj.getString("tracks1"))
      val xgTracksJson = try {
        JSON.parseArray(obj.getString("tracks2"))
      } catch {
        case e: Exception => logger.error(e + obj.toString); null
      }

      if (xgTracksJson != null && !xgTracksJson.isEmpty) {
        val reqJson = new JSONObject()
        reqJson.put("vehicle", 1)
        reqJson.put("retflag", 2)
        reqJson.put("tracktype", 2)
        reqJson.put("tracks1", xgjTracksJson)
        reqJson.put("tracks2", xgTracksJson)

        obj.put("reqJson", reqJson)

        val start = System.currentTimeMillis()
        val resbonseBody = doPost(comparetracksUrl, reqJson)
        val end = System.currentTimeMillis()
        logger.error(s"比较相似度cost ->${end - start}:$reqJson")

        obj.put("compareResp", resbonseBody)

        if (!resbonseBody.contains("发送post请求失败")) {
          similarity = try {
            JSON.parseObject(resbonseBody).getDouble("similarity1")
          } catch {
            case _ => similarity
          }
        }
      }

      obj.put("similarity", similarity)

      obj
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共获取相似度数据共:${similarityRdd.count()}")
    joinRdd.unpersist()

    similarityRdd
  }

  def doJoin(xgjRDD: RDD[(String, JSONObject)], xiaogeTrackRDD: RDD[(String, JSONArray)]) = {
    logger.error(">>>开始关联小哥星管家轨迹<<<")
    val simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")

    val joinRdd = xgjRDD.leftOuterJoin(xiaogeTrackRDD).map(obj => {
      val leftBody = obj._2._1
      val ringhtBody = obj._2._2.getOrElse(null)

      //将交接时间和妥投时间换算成秒级的时间戳
      val start_time = simpleDateFormat.parse(leftBody.getString("start_time")).getTime / 1000
      val end_time = simpleDateFormat.parse(leftBody.getString("end_time")).getTime / 1000

      //匹配是否获取到小哥轨迹数据
      if (ringhtBody != null && !ringhtBody.isEmpty) {

        //判断小哥轨迹是否存在类型,纬度,经度,时间,且轨迹是否在交接时间和妥投时间之间
        val xiaogeTrackListTmp = new JSONArray()
        var errorInfo = ""

        val start = Instant.now()

        for (i <- 0 until ringhtBody.size()) {
          val json = ringhtBody.getJSONObject(i)

          if (!json.containsKey("error") &&
            json.getLong("time") >= start_time && json.getLong("time") <= end_time
          )
            xiaogeTrackListTmp.add(json)
          else {
            val error = json.getString("error")
            errorInfo += ("|" + (if (error == null) s"小哥轨迹时间${json.getLong("time")},不在交接时间${start_time}和妥投时间${end_time} 之间" else error))
          }
        }

        val end = Instant.now()

        val costTime = Duration.between(start, end).getSeconds
        if (costTime > 30) logger.error(costTime + "--" + ringhtBody.toJSONString)

        logger.error("cost->" + costTime + "size->" + ringhtBody.size())

        leftBody.put("erroInfo", s"$errorInfo")

        //将匹配的轨迹转成JSONArray
        if (!xiaogeTrackListTmp.isEmpty) {
          leftBody.fluentPut("tracks2", xiaogeTrackListTmp)
        } else leftBody.put("erroInfo", "未匹配到有效的轨迹：" + leftBody.getString("erroInfo"))

      } else leftBody.put("erroInfo", s"未匹配到小哥工号${obj._1}")

      leftBody
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>共关联:${joinRdd.count()}<<<")

    xgjRDD.unpersist()
    xiaogeTrackRDD.unpersist()

    joinRdd
  }

  def getXiaogeTrackRdd(spark: SparkSession, parDay: String, xgjEmpList: List[String]) = {

    val xiaogeTrackTable = "dm_gis.esg_gis_loc_trajectory"

    val querySql =
      s"""select
         | REGEXP_REPLACE(un,"^[0]+",""),zx,zy,tp,ac,sp,be,tm
         |from $xiaogeTrackTable
         |where inc_day='$parDay' and REGEXP_REPLACE(un,"^[0]+","") in ('${xgjEmpList.mkString("','")}')
         |""".stripMargin

    logger.error(querySql)
    //val sdff = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    // 时间戳转换成时间
    val xiaogeTrackRDD = spark.sql(querySql).rdd.repartition(calpartition).map(obj => {
      val empCode = obj.getString(0).replaceAll("^[0]+", "")
      val json = new JSONObject()
      val zx = obj.getString(1).toDouble
      val zy = obj.getString(2).toDouble
      val tp = obj.getString(3).toInt
      val tm = obj.getString(7).toInt

      json.put("type", tp)
      json.put("x", zx)
      json.put("y", zy)
      json.put("accuracy", if (StringUtils.isBlank(obj.getString(4))) 15 else obj.getString(4).toInt)
      json.put("speed", if (StringUtils.isBlank(obj.getString(5))) 0 else obj.getString(5).toDouble)
      json.put("azimuth", if (StringUtils.isBlank(obj.getString(6))) 0 else obj.getString(6).toDouble)
      json.put("time", tm)

      //定位类型,纬度,经度,时间戳调用接口是为必填参数
      if (tm == null
        || zx == null
        || zy == null
        || tp == null)
        json.put("error", s"缺失定位类型|纬度|经度|时间戳:${json.toString}")

      (empCode, json)

    }).aggregateByKey(List[JSONObject]())(seqOp, combOp).map(
      obj => {
        val xiaogeTrackList = obj._2

        val jsonArray = new JSONArray()

        xiaogeTrackList.foreach(elem => jsonArray.add(elem))

        val tracks2 = JsonArraySortUtil.jsonArraySortInt(jsonArray, "time", false)

        (obj._1, tracks2)
      }
    ).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>获取小哥纠偏前轨迹数据共：${xiaogeTrackRDD.count()}<<<")

    println(xgjEmpList.diff(xiaogeTrackRDD.keys.collect()))

    xiaogeTrackRDD
  }

  def getXGJTrackRdd(spark: SparkSession, parDay: String) = {
    val hTable = "gis:tloc_wangyong_history"
    val md5Key = md5(parDay) // 32位的md5小写值，为了打散hash值  ，实际只存储16位,能够满足数据量级
    val regexRowkey = SaltUtil.generateSalt(md5Key, dataTbPartitionNum) + "_" + md5Key.substring(0, 16) + "_" + 0

    println(s"开始运行$parDay")
    println("regexRowkey=" + regexRowkey)

    HbaseUtil.init(zkQuorum, zkPort, zkParent)
    val xgjMap = HbaseUtil.getRegex(hTable, regexRowkey)

    val xgjEmpList = xgjMap.asScala.map(one => one._2.get("emp_no").replaceAll("^[0]+", "")).toList.distinct

    logger.error(s">>>共获取星管家轨迹数据共：${xgjMap.size}<<<")
    logger.error(s">>>共获取星管家员工工号：${xgjEmpList.size}<<<")

    val xgjList = xgjMap.asScala.toList
    xgjMap.clear()

    val xgjRDD = spark.sparkContext.parallelize(xgjList, calpartition).map(obj => {
      val json = new JSONObject()
      val valueMap = obj._2
      val trackArray = JSON.parseArray(valueMap.get("tracks"))

      //排序并将tm换成s级
      var tracksSort = JsonArraySortUtil.jsonArraySortIntToStr(trackArray, "tm", false)

      tracksSort = tracksSort.replaceAll("ac", "accuracy").replaceAll("be", "azimuth")
        .replaceAll("tm", "time").replaceAll("sp", "speed")

      val trackSortArray = JSON.parseArray(tracksSort)

      json.put("rowKey", obj._1)
      json.put("waybill_no", valueMap.get("waybill_no"))
      json.put("emp_no", valueMap.get("emp_no"))
      json.put("start_time", valueMap.get("start_time"))
      json.put("end_time", valueMap.get("end_time"))
      json.put("smgr_no", valueMap.get("smgr_no"))
      json.put("tracks", trackArray)
      json.put("tracks1", trackSortArray)
      (valueMap.get("emp_no"), json)
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共获取星管家数据:${xgjRDD.count()}")

    (xgjRDD, xgjEmpList)
  }
}
