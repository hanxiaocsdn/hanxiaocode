package com.sf.scala.tloc.onsiteapp

import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之轨迹数据预处理
 */
object ClimbBuildingDiscernTrajectory {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )

    val saveClimbBuildingKey = Array( "waybill_no","emp_code","date_time","aoicode","aoi_id","trajectory_data","date_time_timestamp")
    val saveClimbBuildingTmpKey = Array("source_kt","waybill_no","dept_code","emp_code","addr","phone","floor","addr_new","signin_time","aoiid","building","lngbuild","latbuild","lng80","lat80","outaoi","outbuilding","step","doing","onsite","tag")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val start_day=args(1)
        val end_day=args(2)
        val citycode=args(3)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取爬楼识别数据")
//        val dataRdd = getTrajectory(sparkSession,start_day,end_day,citycode)
        val dataRdd = getTrajectoryNew(sparkSession,start_day,end_day,citycode)
        logger.error("开始存储爬楼识别轨迹数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_trajectory_info",Array(("inc_day", end_day)), 25)

    }

    def getTrajectory(spark:SparkSession,start_day:String,end_day:String,citycode:String)={

        var sql=
            s"""
              |
              |select
              | waybill_no
              | ,emp_code
              | ,date_time
              | ,aoicode
              | ,aoi_id
              | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
              | ,trajectory_list
              | from
              | (select * from tmp_dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day'  and dest_dist_code='755' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
              | left join (select un,concat_ws(';',collect_set(concat(zx,'_',zy,'_',tm,'_',ac))) as trajectory_list  from dm_gis.esg_gis_loc_trajectory_ewl where  inc_day='$end_day' and !regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' and ac<100 and zx<>'' and zy<>'' and un is not null and un<>'' group by un) d on a.emp_code=d.un
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,8000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val trajectorySet = new mutable.HashSet[String]()
            var trajectory_data=""
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    for (trajectory <- trajectory_list.split(";")) {
                        if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                            if (trajectory.split("_")(2).nonEmpty && trajectory.split("_")(2).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(2).toLong <= (date_time_timestamp.toLong + 180)) {
                                trajectorySet.add(trajectory)
                            }
                        }
                    }
                }
            }
            if(trajectorySet.size>0){
                trajectory_data=trajectorySet.mkString(";")
            }
            obj.put("trajectory_data", trajectory_data)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }


    def getTrajectoryNew(spark:SparkSession,start_day:String,end_day:String,citycode:String)={

        var sql=
            s"""
               |
               |select
               | waybill_no
               | ,emp_code
               | ,date_time
               | ,aoicode
               | ,aoi_id
               | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
               | ,trajectory_list
               | from
               | (select * from tmp_dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day'  and dest_dist_code='755' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
               | left join (select un,concat_ws(';',collect_set(concat(zx,'_',zy,'_',tm,'_',ac,'_',tp))) as trajectory_list  from dm_gis.esg_gis_loc_trajectory_ewl where  inc_day='$end_day' and !regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' and ac<100 and zx<>'' and zy<>'' and un is not null and un<>'' group by un) d on a.emp_code=d.un
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,8000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val trajectorySet = new mutable.HashSet[String]()
            var trajectory_data=""
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    for (trajectory <- trajectory_list.split(";")) {
                        if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                            if (trajectory.split("_")(2).nonEmpty && trajectory.split("_")(2).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(2).toLong <= (date_time_timestamp.toLong + 180)) {
                                if(trajectory.split("_")(4).nonEmpty&&trajectory.split("_")(4).equals("5")){
                                    if(trajectory.split("_")(3).nonEmpty&&trajectory.split("_")(3).toLong<50){
                                        trajectorySet.add(trajectory)
                                    }
                                }else{
                                    trajectorySet.add(trajectory)
                                }

                            }
                        }
                    }
                }
            }
            if(trajectorySet.size>0){
                trajectory_data=trajectorySet.mkString(";")
            }
            obj.put("trajectory_data", trajectory_data)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }


}
