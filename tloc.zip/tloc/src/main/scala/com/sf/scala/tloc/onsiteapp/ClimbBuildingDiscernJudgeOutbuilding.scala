package com.sf.scala.tloc.onsiteapp

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.scala.tloc.onsiteapp.ClimbBuildingDiscern.getHour
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之判定outbuilding
 */
object ClimbBuildingDiscernJudgeOutbuilding {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val buildUrl="http://sds-core-datarun.sf-express.com/datarun/building/getCoorPoiDist?x=%s&y=%s&poiId=%s&type=side"

    val saveClimbBuildingKey = Array("waybill_no","zone_code","citycode","emp_code","address","phone","floor","similarity_address","date_time","aoicode","aoiname","buildingname","lngbuild","latbuild","isclimb","buildingid","bulidtype","outbuilding","buildingid_src")

    val saveKey=Array("waybill_no","dest_zone_code","dest_dist_code","dest_city_code","dest_county","dest_division_code","dest_area_code","dest_hq_code","dest_type_code","emp_code","signer_name","date_time","consignee_comp_name","consignee_addr","consignee_phone","consignee_cont_name","consignee_mobile","inner_parcel_flag","self_send_flag","self_pickup_flag","delivery_lgt","delivery_lat","dest_province","aoi_id","aoi_name","aoi_address","aoi_type_code","aoi_type_name","aoicode","isclimb","addr_new","building","buildingid","bulidtype","lngbuild","latbuild","outbuilding","buildingid_src")
    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val end_day=args(1)
        val group_num=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取楼栋信息数据")
        val buildingMap: Broadcast[Map[String, String]] = getBulidingWkt(sparkSession)
        logger.error("获取爬楼识别outbuild数据")

        judgeOutbuildingNew(sparkSession,buildingMap, end_day,group_num)

    }

    def judgeOutbuildingNew(spark:SparkSession,buildingBroadcastMap:Broadcast[Map[String, String]],end_day:String,group_num:String)={

        var sql=
            s"""
               |
               |  select
               | a.*
               | ,b.trajectory_data
               | ,b.date_time_timestamp
               | from
               | (select * from dm_gis.gis_onsite_service_build_discern_info where inc_day='$end_day') a
               | left join (select waybill_no,trajectory_data,date_time_timestamp from dm_gis.gis_onsite_service_trajectory_info where inc_day='$end_day'  )b
               | on a.waybill_no=b.waybill_no
               |
               |
               |""".stripMargin

        sql=
            s"""
              |
              |select
              | a.*
              | ,b.trajectory_data
              | ,b.date_time_timestamp
              | from
              | (select * from tmp_dm_gis.dm_gis_onsite_service_build_discern_di where inc_day='$end_day' and group_num='$group_num') a
              | left join (select waybill_no,trajectory_data,date_time_timestamp from tmp_dm_gis.gis_onsite_service_trajectory_info where inc_day='$end_day'  )b
              | on a.waybill_no=b.waybill_no
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,2000)
        val resultRdd=dataRdd.map(obj => {
            val buildingMap = buildingBroadcastMap.value
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val buildingId = obj.getString("buildingid")
            val citycode = obj.getString("dest_dist_code")
            var outbuilding = "-1"
            var lngbuild=""
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                if(buildingId!=null&&buildingId.nonEmpty){
                    val trajectory_list = obj.getString("trajectory_data")
                    if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                        var outBulidAllcnt=0l
                        var outBulidcnt=0l
                        breakable {
                            for (trajectory <- trajectory_list.split(";")) {
                                if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                                    if (trajectory.split("_")(2).nonEmpty && trajectory.split("_")(2).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(2).toLong <= (date_time_timestamp.toLong + 180)) {
                                        var zx = trajectory.split("_")(0)
                                        var zy = trajectory.split("_")(1)
                                        var ac = trajectory.split("_")(3)
                                        if (zx.nonEmpty && zy.nonEmpty&&ac.nonEmpty&&ac.toLong<=50) {
                                            outBulidAllcnt+=1
                                            var wkt=""
                                            var distace=(-1.0)
                                            if(buildingMap.contains(buildingId)){
                                                wkt=buildingMap.getOrElse(buildingId,"")
                                            }
                                            if(StringUtils.nonEmpty(wkt)){
                                                distace = getGeoData(wkt,zx.toDouble,zy.toDouble)
                                            }
                                            if(distace<0)
                                                distace = getBuildDist(buildingId,zx,zy,citycode)

                                            if (distace <= 50.0&&distace>=0.0) {
                                                outbuilding = "0"
                                                break
                                            }else if(distace>50.0){
                                                outBulidcnt+=1
                                            }

                                            lngbuild=lngbuild+zx+"_"+zy+"_"+distace+";"
                                        }
                                    }
                                }
                            }

                        }

                        if(outBulidcnt>=5&&(!outbuilding.equals("0"))){
                            outbuilding="1"

                        }else if(outbuilding.equals("0")){
                            outbuilding="0"
                        }else{
                            outbuilding="-1"
                        }
                    }


                }


            }
            obj.put("outbuilding", outbuilding)
            obj.put("lngbuild", lngbuild)
            obj
        }).repartition(25).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        saveDataToHive(spark,resultRdd,end_day,group_num)

//        resultRdd

    }


    def saveDataToHive(sparkSession:SparkSession,standardRdd:RDD[JSONObject],end_date:String,group_num:String)={

        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveKey.indices) {
            schemaEle.append(StructField(saveKey.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        val rowRdd = standardRdd.map(obj => {
            val row = new ArrayBuffer[String]
            for (i <- saveKey.indices) {
                var tmpStr = JSONUtil.getJsonValSingle(obj, saveKey.apply(i))
                row.append(tmpStr)
            }
            val ret = Row.fromSeq(row)
            ret
        })

        sparkSession.createDataFrame(rowRdd, schema).createOrReplaceTempView("tmp_result")

        var sql_w=
            s"""
               |
               |insert overwrite table tmp_dm_gis.dm_gis_onsite_service_outbuilding_di partition(inc_day='$end_date',group_num='$group_num')
               |select
               |waybill_no
               |,dest_zone_code
               |,dest_dist_code
               |,dest_city_code
               |,dest_county
               |,dest_division_code
               |,dest_area_code
               |,dest_hq_code
               |,dest_type_code
               |,emp_code
               |,signer_name
               |,date_time
               |,consignee_comp_name
               |,consignee_addr
               |,consignee_phone
               |,consignee_cont_name
               |,consignee_mobile
               |,inner_parcel_flag
               |,self_send_flag
               |,self_pickup_flag
               |,delivery_lgt
               |,delivery_lat
               |,dest_province
               |,aoi_id
               |,aoi_name
               |,aoi_address
               |,aoi_type_code
               |,aoi_type_name
               |,aoicode
               |,isclimb
               |,addr_new
               |,building
               |,buildingid
               |,bulidtype
               |,lngbuild
               |,latbuild
               |,outbuilding
               |,buildingid_src
               |from
               |tmp_result
               |
               |
               |
               |
               |""".stripMargin

        logger.error("存储outbuilding数据sql---》"+sql_w)
        sparkSession.sql(sql_w)
        logger.error("存储outbuilding数据完毕")

    }
    def judgeOutBuilding(date_time_timestamp:String,buildingId:String,trajectory_list:String,buildingMap:Map[String, String],citycode:String)={

        var outbuilding = "-1"
        var lngbuild=""
        if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
            if(buildingId!=null&&buildingId.nonEmpty){
//                val trajectory_list = obj.getString("trajectory_data")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split(";").length > 0) {
                    var outBulidAllcnt=0l
                    var outBulidcnt=0l
                    breakable {
                        for (trajectory <- trajectory_list.split(";")) {
                            if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 2) {
                                if (trajectory.split("_")(2).nonEmpty && trajectory.split("_")(2).toLong >= (date_time_timestamp.toLong - 180) && trajectory.split("_")(2).toLong <= (date_time_timestamp.toLong + 180)) {
                                    var zx = trajectory.split("_")(0)
                                    var zy = trajectory.split("_")(1)
                                    var ac = trajectory.split("_")(3)
                                    if (zx.nonEmpty && zy.nonEmpty&&ac.nonEmpty&&ac.toLong<=50) {
                                        outBulidAllcnt+=1
                                        var wkt=""
                                        var distace=(-1.0)
                                        if(buildingMap.contains(buildingId)){
                                            wkt=buildingMap.getOrElse(buildingId,"")
                                        }
                                        if(StringUtils.nonEmpty(wkt)){
                                            distace = getGeoData(wkt,zx.toDouble,zy.toDouble)
                                        }
                                        if(distace<0)
                                            distace = getBuildDist(buildingId,zx,zy,citycode)

                                        if (distace <= 50.0&&distace>=0.0) {
                                            outbuilding = "0"
                                            break
                                        }else if(distace>50.0){
                                            outBulidcnt+=1
                                        }

                                        lngbuild=lngbuild+zx+"_"+zy+"_"+distace+";"
                                    }
                                }
                            }
                        }

                    }

                    if(outBulidcnt>=5&&(!outbuilding.equals("0"))){
                        outbuilding="1"

                    }else if(outbuilding.equals("0")){
                        outbuilding="0"
                    }else{
                        outbuilding="-1"
                    }
                }


            }


        }


        (outbuilding,lngbuild)


    }

    def getBulidingWkt(spark:SparkSession)={
        var sql="select wkt,buildingid from dm_gis.building_info "
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val buildingMap: Map[String, String] = originRdd.map(obj => {
            val buildingId = obj.getString("buildingid")
            val wkt = obj.getString("wkt")
            (buildingId, wkt)

        }).collect().toMap
        spark.sparkContext.broadcast(buildingMap)

    }



    def getBuildDist(buildid:String,x:String,y:String,citycode:String): Double ={

        var nowHour = getHour()
        val citycodearr=Array("755","020","769","010","021","573","512","574","871","451","579","898","513","023","517","991")
        var dist=(-1.0)
//        if(!citycodearr.contains(citycode)){
//            return dist
//        }
        if(nowHour>22){
            return dist
        }
        val url=String.format(buildUrl,x,y,buildid)

        Thread.sleep(50)
        var status=""
        var jSONObject=new JSONObject()
        breakable {
            for(i<- 0 until 5){
                jSONObject = try {
                    HttpUtils.urlConnectionGetJson(url, 5000)
                }
                catch {
                    case _=>{
                        logger.error("error url-----> "+url)
                        null
                    }
                }
                status=JSONUtil.getJsonVal(jSONObject,"success","false")
                if(!status.equals("true")){
                    logger.error("access faill---->"+jSONObject)
                }else{
                    break
                }
            }

        }
        if(jSONObject!=null){
            try{
                dist=JSONUtil.getJsonVal(jSONObject,"data","").toDouble
            }catch {case e:Exception=>{}}


        }
        dist

    }

    def getGeoData(wkt:String,x:Double,y:Double)={
        import com.sf.gis.uabs.common.util.GeoUtil
        var distance=(-1.0)
        try{
            val geom = GeoUtil.fromWkt(wkt)
            val point = GeoUtil.fromWkt(GeoUtil.buildPointWkt(x, y))
            distance = GeoUtil.getDistM(point.distance(geom))
        }catch {
            case _=>{
                logger.error("wkt------>"+wkt)
                distance=(-1.0)

            }
        }
        distance

    }

}
