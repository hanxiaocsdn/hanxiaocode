package com.sf.scala.tloc.onsiteapp

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import scala.util.{Failure, Success, Try}

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-02-16  16:25
 * @TaskId:692265
 * @TaskName:不上门模型
 * @Description:不上门模型之中间结果关联
 */
object ClimbBuildingDiscernUnionData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveClimbBuildingKey = Array("waybill_no","dest_zone_code","dest_dist_code","dest_city_code","dest_county","dest_division_code","dest_area_code","dest_hq_code","dest_type_code","emp_code","signer_name","signin_tm","consignee_comp_name","consignee_addr","consignee_phone","consignee_cont_name","consignee_mobile","inner_parcel_flag","self_send_flag","self_pickup_flag","delivery_lgt","delivery_lat","dest_province","aoi_id","aoi_name","aoi_address","aoi_type_code","aoi_type_name","aoicode","isclimb","addr_new","building","buildingid","lngbuild","latbuild","lng80","lat80","outaoi","istougui","iszhuanjituihui","iscopyphone","isfwsjg2g","isexternal","cntyizhan100","istjy","outbuilding","step","doing","wifi","wifi_aoi","out_wifi_aoi","wifi_poi","out_wifi_poi","wifi_floor","out_wifi_floor","deliver_address","is_phone_eff","kesu_onsite","remark","kesu_tougui","kesu_chaping","kesu_toujingye","bianlidian","xingguanjia","copyphonetime","copy_sign_time","toujingye_dis","toujingye","toujingye_brand","doing_time","buildingid_src")

    def main(args: Array[String]): Unit = {
        val target_table=args(0)
        val start_day=args(1)
        val end_day=args(2)
        val citycode=args(3)
        val from_table=args(4)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val roadWaybillRdd: RDD[(String,JSONObject)] = getRoadWaybill(sparkSession, end_day)
        logger.error("获取爬楼识别数据")
        val dataRdd = getAllResultData(sparkSession,start_day,end_day,citycode,from_table,roadWaybillRdd)
        logger.error("开始存储爬楼识别数据")
        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "tmp_dm_gis.gis_onsite_service_mid_data",Array(("inc_day", end_day)), 600)
//        SparkWrite.save2HiveStaticNew(sparkSession, dataRdd, saveClimbBuildingKey, "dm_gis.gis_onsite_service_mid_data_v3",Array(("inc_day", end_day)), 600)



    }



    def getRoadWaybill(spark:SparkSession,end_day:String)={
        var sql=s"select *,row_number()over(partition by waybill_no  order by date_time desc ) as rnk from dm_gis.gis_onsite_service_road_waybill_info where inc_day='$end_day' "
        sql=
            s"""
              |
              |select * from (
              |select *,cast ( row_number()over(partition by waybill_no  order by date_time desc ) as string) as rnk from tmp_dm_gis.gis_onsite_service_road_waybill_info where inc_day='$end_day'
              |) t
              |where t.rnk=1
              |
              |""".stripMargin
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = originRdd.map(obj => (obj.getString("waybill_no"), obj))
        resultRdd
    }

    def getAoiWkt(spark:SparkSession)={
        var sql="select wkt,aoiid from dm_gis.building_info "
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiMap: Map[String, String] = originRdd.map(obj => {
            val aoiid = obj.getString("aoiid")
            val wkt = obj.getString("wkt")
            (aoiid, wkt)

        }).collect().toMap
        spark.sparkContext.broadcast(aoiMap)

    }

    def getAllResultData(spark:SparkSession,start_day:String,end_day:String,citycode:String,from_table:String,roadWaybillRdd: RDD[(String,JSONObject)])={
        //dm_gis.dm_gis_onsite_service_outbuilding_di
        //dm_gis.gis_onsite_service_outbuilding_info

        var sql=
            s"""
              |
              |select
              | a.*
              | ,b.step
              | ,c.doing
              | ,c.doing_time
              | ,d.outaoi
              | ,e.eventlng as lng80
              | ,e.eventlat as lat80
              | ,cast(unix_timestamp(a.signin_tm,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
              | ,f.wifi
              | ,f.wifi_aoi
              | ,f.wifi_poi
              | ,f.wifi_floor
              | ,g.deliver_address
              | ,g.is_phone_eff
              | ,h.istougui
              | ,h.iszhuanjituihui
              | ,h.iscopyphone
              | ,h.isfwsjg2g
              | ,h.isexternal
              | ,h.cntyizhan100
              | ,case when i.waybill_no is not null then '1' else '0' end as istjy
              | ,'' as kesu_onsite
              | ,'' as remark
              | ,'' as kesu_tougui
              | ,'' as kesu_chaping
              | ,'' as kesu_toujingye
              | ,j.is_cvs_deliver as bianlidian
              | ,k.is_star_hskpr_deliver as xingguanjia
              | ,m.copyphonetime
              | ,m.copy_sign_time
              | ,m.toujingye
              | ,m.toujingye_brand
              | ,m.toujingye_dis
              | from
              | (select
              | *,
              | date_time as signin_tm
              | from tmp_dm_gis.dm_gis_onsite_service_outbuilding_di where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' and consignee_phone is not null and consignee_phone<>'' and !dest_dist_code regexp '$citycode' ) a
              | left join (select waybill_no,step from tmp_dm_gis.gis_onsite_service_step_info where inc_day='$end_day' and waybill_no is not null and waybill_no<>'')b on a.waybill_no=b.waybill_no
              | left join (select waybill_no,doing,doing_time from tmp_dm_gis.gis_onsite_service_sensor_doing_info where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' )c on a.waybill_no=c.waybill_no
              | left join (select waybill_no,outaoi from tmp_dm_gis.gis_onsite_service_outaoi_info where inc_day='$end_day' and waybill_no is not null and waybill_no<>'')d on a.waybill_no=d.waybill_no
              | left join (select waybillno as waybill_no ,eventlng,eventlat from ods_inc_sgs_core.inc_sgs_task_flow_new where inc_day>='$start_day' and inc_day<='$end_day' and eventtype ='31124'  and !city_code regexp '$citycode' and waybillno is not null and waybillno<>'' group by waybillno ,eventlng,eventlat) e on a.waybill_no=e.waybill_no
              | left join (select waybill_no,concat_ws('|',collect_set(ewl_data)) wifi ,concat_ws(',',collect_set(aoi_id)) wifi_aoi,concat_ws(',',collect_set(bld_id)) wifi_poi,concat_ws(',',collect_set(regexp_replace(floor,'[A-Za-z\\u4e00-\\u9fa5]',''))) wifi_floor from dm_gis.gis_onsite_service_wifi_result where inc_day='$end_day' group by waybill_no) f on a.waybill_no=f.waybill_no
              | left join
              |(select waybill_no,deliver_address,is_phone_eff from dm_analysis.danko_pd_deliver_phone_detail where inc_day='$end_day'  and !regexp_replace(substring(area_code, 0, 3), '[a-zA-Z]*', '') regexp '$citycode' ) g on a.waybill_no=g.waybill_no
              |left join (select waybill_no,istougui,iszhuanjituihui,iscopyphone,isfwsjg2g,isexternal,cntyizhan100 from tmp_dm_gis.lbs_loc_index where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' group by waybill_no,istougui,iszhuanjituihui,iscopyphone,isfwsjg2g,isexternal,cntyizhan100) h on a.waybill_no=h.waybill_no
              |left join (select waybill_no from dm_gis.dm_lbs_tjy_detail_to_operation_di_new where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' group by waybill_no) i on a.waybill_no=i.waybill_no
              |left join (select waybill_no,is_cvs_deliver from dm_terminal.cvs_deliver_dtl_di where inc_day='$end_day' group by waybill_no,is_cvs_deliver) j on a.waybill_no=j.waybill_no
              |left join (select waybill_no,is_star_hskpr_deliver from dwd_o.dwd_pd_star_hskpr_deliver_di where inc_day='$end_day' group by waybill_no,is_star_hskpr_deliver ) k on a.waybill_no=k.waybill_no
              |left join (select * from tmp_dm_gis.gis_onsite_service_competitor_info where inc_day='$end_day' and waybill_no is not null and waybill_no<>'') m on a.waybill_no=m.waybill_no
              |
              |
              |""".stripMargin

        logger.error(sql)
        //select waybill_no,concat_ws('|',collect_set(ewl_data)) wifi ,concat_ws(',',collect_set(aoi_id)) wifi_aoi,concat_ws(',',collect_set(bld_id)) wifi_poi,concat_ws(',',collect_set(regexp_replace(floor,'[A-Za-z\\u4e00-\\u9fa5]',''))) wifi_floor from $from_table where inc_day='$end_day' and aoi_rate>=0.9 and bld_rate>=0.9 and floor_rate>=0.9 group by waybill_no
        val (telRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,6000)
        val resultRdd = telRdd.map(obj => (obj.getString("waybill_no"), obj)).leftOuterJoin(roadWaybillRdd).map(x => {
            val leftObj = x._2._1
            var consignee_addr=leftObj.getString("consignee_addr")
            val rightOption = x._2._2
            if (rightOption.nonEmpty) {
                leftObj.fluentPutAll(rightOption.get)
            }
            val buildingid = leftObj.getString("buildingid")
            var aoiid = leftObj.getString("aoi_id")
            var wifi_poi = leftObj.getString("wifi_poi")
            var wifi_aoi=leftObj.getString("wifi_aoi")
            val floor = leftObj.getString("floor")
            val wifi_floor = leftObj.getString("wifi_floor")
            val (out_wifi_aoi,out_wifi_poi,out_wifi_floor)=getwifiInfo(wifi_aoi,wifi_poi,wifi_floor,buildingid,aoiid,floor)
            leftObj.put("consignee_addr",consignee_addr)
            leftObj.put("out_wifi_aoi",out_wifi_aoi)
            leftObj.put("out_wifi_poi",out_wifi_poi)
            leftObj.put("out_wifi_floor",out_wifi_floor)
            leftObj
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("合并数据完毕-----》"+resultRdd.count())

        resultRdd


    }
    def getwifiInfo(wifi_aoi:String,wifi_poi:String,wifi_floor:String,buildingid:String,aoiid:String,floor:String)={
        var out_wifi_poi="1"
        var out_wifi_aoi="1"
        var out_wifi_floor="1"
        if(aoiid!=null&&aoiid.nonEmpty){
            if(wifi_aoi!=null&&wifi_aoi.nonEmpty){
                for(wifi_aoi_id<-wifi_aoi.split(",")){
                    if(wifi_aoi_id.equals(aoiid)){
                        out_wifi_aoi="0"
                    }

                }

            }else{
                out_wifi_aoi="-1"
            }
        }else{
            out_wifi_aoi="-1"
        }

        if(buildingid!=null&&buildingid.nonEmpty){
            if(wifi_poi!=null&&wifi_poi.nonEmpty){
                for(wifi_poi_id<-wifi_poi.split(",")){
                    if(wifi_poi_id.equals(buildingid)){
                        out_wifi_poi="0"
                    }

                }

            }else{
                out_wifi_poi="-1"
            }
        }else{
            out_wifi_poi="-1"
        }

        try {
            if(floor!=null&&floor.nonEmpty){
                if(wifi_floor!=null&&wifi_floor.nonEmpty){
                    for(wifi_floor_id<-wifi_floor.split(",")){
                        if(wifi_floor_id!=null&&wifi_floor_id.nonEmpty){
                            val floor_diff=math.abs(floor.toInt-wifi_floor_id.toInt)
                            if(floor_diff==1||floor_diff==0){
                                out_wifi_floor="0"
                            }
                        }
                    }
                }else{
                    out_wifi_floor="-1"
                }
            }else{
                out_wifi_floor="-1"
            }
        }catch {case e:Exception=>{
            out_wifi_floor="-1"


        }}




        (out_wifi_aoi,out_wifi_poi,out_wifi_floor)

    }




    def getTimestamp(s: String) : Option[Long] = s match {
        case "" => Some(0)
        case _ => {
            val format = new SimpleDateFormat("yyyy-MM-dd' 'HH:mm:ss")
            Try(format.parse(s).getTime/1000) match {
                case Success(t) => Some(t)
                case Failure(_) => Some(0)
            }
        }
    }

}
