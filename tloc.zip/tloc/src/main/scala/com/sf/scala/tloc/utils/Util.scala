package com.sf.scala.tloc.utils

import java.io.{BufferedReader, FileInputStream, InputStreamReader}
import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date}

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.mysql.jdbc.Connection
import com.sf.gis.java.base.util.GeometryUtil
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01375125 on 2018/7/7.
  */
object Util {
  def main(args: Array[String]): Unit = {
  }

  def getRowToJsonNew_1( spark:SparkSession,querySql:String,num : Int) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK)
    val colList = sourDf.columns
    val sourRdd = sourDf.rdd.repartition(num).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    println(s"共获取数据:${sourRdd.count()}")
    sourDf.unpersist()
    sourRdd
  }

  def getSparkConf(appName:String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "999")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")//长期存在于NodeManager进程中的一个辅助服务。通过该服务来抓取shuffle数据，减少了Executor的压力，在Executor GC的时候也不会影响其他Executor的任务运行
    conf.set("spark.shuffle.service.enabled", "true")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
    conf.set("spark.kryoserializer.buffer.max", "128m")
    conf.set("spark.network.timeout", "3000s")
    conf.set("spark.executor.memoryOverhead", "16G")
    conf.set("spark.yarn.executor.memoryOverhead", "8G")
    conf.set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
    conf.set("spark.rpc.askTimeout", "600s")
    conf.set("spark.shuffle.compress", "true")
    conf.set("spark.sql.hive.mergeFiles", "true")
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
    conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic") //开启动态分区
    conf.set("hive.orc.splits.include.file.footer", "true") //是否将元数据保存在orc文件中
    conf.set("hive.exec.orc.default.stripe.size", "268435456") //默认256M
    conf.set("hive.exec.orc.split.strategy", "BI")//参数控制在读取ORC表时生成split的策略。BI策略以文件为粒度进行split划分；ETL策略会将文件进行切分，多个stripe组成一个split；HYBRID策略为：当文件的平均大小大于hadoop最大split值（默认256 * 1024 * 1024）时使用ETL策略，否则使用BI策略。
    conf.set("spark.sql.hive.convertMetastoreOrc", "true") //开启矢量化
    conf.set("spark.sql.orc.enableVectorizedReader", "true") //开启矢量化 ,矢量化需要100列内,并且字段是基本字段,非null arrays等
    conf.set("spark.sql.crossJoin.enabled", "true") //开启笛卡尔积
    conf.set("spark.sql.orc.filterPushdown", "true") //谓词下推
    conf.set("spark.sql.broadcastTimeout", "1200") //增加获取广播变量超时时间
    conf.set("hive.exec.dynamic.partition", "true")
    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    conf.set("hive.exec.max.dynamic.partitions", "10000")
    conf.set("hive.exec.max.dynamic.partitions.pernode", " 10000")
    conf.set("hive.exec.max.created.files", " 1000000")
    conf.set("hive.merge.mapredfiles", "true")
    conf.set("hive.merge.mapfiles", "true")
    conf.set("hive.merge.size.per.task", "134217728")
    conf.set("hive.merge.smallfiles.avgsize", "134217728")
    conf.set("mapreduce.input.fileinputformat.split.maxsize", "134217728")
    conf.set("mapreduce.input.fileinputformat.split.minsize.per.rack", "134217728")
    conf.set("mapreduce.input.fileinputformat.split.minsize.per.node", "134217728")
    conf.set("hive.merge.sparkfiles", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)

    //        conf.set("spark.executor.instances","40")

    //    conf.set("spark.executor.cores","4")
    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")

    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    conf
  }

}
