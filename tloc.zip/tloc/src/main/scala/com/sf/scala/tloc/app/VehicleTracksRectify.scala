package com.sf.scala.tloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, FileUtil, JsonArraySortUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpClientUtil, SaveResultUtil}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/*
* 主要用于获取024大区或者车补小哥的轨迹,根据工号,app版本,设备id,bn,ak 分组后 进行纠偏
* */
object VehicleTracksRectify {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  //纠偏服务
  val rectifyUrl = "http://gis-lss-xsd.int.sfdc.com.cn:1080/rectifytracks"
  val calPartition = 300

  def main(args: Array[String]): Unit = {
    //start
    for (i <- Range(0, 10)) {
      test()
    }
  }

  def test(): Unit = {
    val jsonString = FileUtil.getQuerySql("test.csv")
    val reqJson = JSON.parseObject(jsonString)
    println(HttpClientUtil.doPost(rectifyUrl, reqJson, logger))
    print("\n\n\n")
  }

  def start(): Unit = {
    val spark = Spark.getSparkSession(appName)

    val totalDays = 1
    //val totalDays = 7
    for (i <- 1 to totalDays) {
      val logDays: Int = -i
      //val logDays: Int = -i-2
      val incDay: String = DateUtil.getCurrentDateAfter("yyyyMMdd", logDays)
      val sepDay: String = DateUtil.getCurrentDateAfter("yyyy-MM-dd", logDays)
      val date = incDay
      println(date, incDay, sepDay)
      //run(spark, incDay)
      run(spark, "20200902")
    }
  }

  def run(spark: SparkSession, parDate: String): Unit = {
    //获取小哥轨迹
    val trackRdd = getTrackRdd(spark, parDate)
    //val trackRdd = getO24TrackRdd(spark,parDate)

    //按工号,ak,v,id聚合小哥轨迹
    val aggrTrackRdd = getAggrTrackRdd(trackRdd)

    //调用纠偏服务进行纠偏
    val rectifyRdd = rectifyTracks(aggrTrackRdd)

    rectifyRdd.collect().foreach(logger.error)

    return

    //写入hive
    SaveResultUtil.saveResult(logger, spark, rectifyRdd, saveRectify, "vehicle_tracks_rectify", parDate, "hdfs://sfbd")

    rectifyRdd.unpersist()
  }

  def getO24TrackRdd(spark: SparkSession, parDate: String): RDD[((String, String, String, String, String), JSONObject)] = {
    val querySql =
      s"""
         |select regexp_replace(t1.un, '^(0+)', '') as emp_code,
         |       t1.id,t1.v,t1.ak,t1.zx,t1.zy,t1.ac,t1.be,t1.sp,t1.tp,t1.tm,t1.bn
         |from dm_gis.esg_gis_loc_trajectory t1
         |join
         |(
         | select emp_code
         | from
         | (
         |    select
         |         regexp_replace(deliver_emp_code, '^(0+)', '')  as emp_code
         |    from dm_gis.tt_waybill_hook
         |    where inc_day='$parDate'
         |        and deliver_emp_code is not null and deliver_emp_code <> ''
         |        and dest_dist_code in ('024','412','414','416','417','418','419','421','427','429')
         |    union all
         |    select
         |        regexp_replace(consignee_emp_code, '^(0+)', '') as emp_code
         |    from dm_gis.tt_order_hook
         |    where inc_day='$parDate'
         |        and consignee_emp_code is not null and consignee_emp_code <> ''
         |        and src_dist_code in ('024','412','414','416','417','418','419','421','427','429')
         | ) tmp group by emp_code
         |) t2
         |on regexp_replace(t1.un, '^(0+)', '') = t2.emp_code
         |where t1.inc_day = '$parDate' and t1.un <> '' and from_unixtime(t1.tm,'yyyyMM')=substr('$parDate',0,6)
         |""".stripMargin

    //where t1.emp_code = '419764'

    logger.error(querySql)

    val trackRDD = spark.sql(querySql).repartition(calPartition).rdd.map(obj => {
      try {
        val empCode = obj.getString(0).replaceAll("^[0]+", "")
        val json = new JSONObject()
        val zx = if (StringUtils.isNotBlank(obj.getString(4))) obj.getString(4).toDouble else null
        val zy = if (StringUtils.isNotBlank(obj.getString(5))) obj.getString(5).toDouble else null
        val tp = if (StringUtils.isNotBlank(obj.getString(9))) obj.getString(9).toInt else null
        val tm = if (StringUtils.isNotBlank(obj.getString(10))) obj.getString(10).toInt else null

        json.put("type", tp)
        json.put("x", zx)
        json.put("y", zy)
        json.put("accuracy", if (StringUtils.isBlank(obj.getString(6))) 15 else obj.getString(6).toInt)
        json.put("speed", if (StringUtils.isBlank(obj.getString(8))) 0 else obj.getString(8).toDouble)
        json.put("azimuth", if (StringUtils.isBlank(obj.getString(7))) 0 else obj.getString(7).toDouble)
        json.put("time", tm)

        //定位类型,纬度,经度,时间戳调用接口是为必填参数
        if (tm == null
          || zx == null
          || zy == null
          || tp == null)
          json.put("error", s"缺失定位类型|纬度|经度|时间戳:${json.toString}")

        //(工号,ak,app版本,id,网点)
        ((empCode, obj.getString(3), obj.getString(1), obj.getString(2), obj.getString(11)), json)
      } catch {
        case e: Exception => throw new RuntimeException("obj" + obj + e)
      }
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>共获取024小哥轨迹点:${trackRDD.count()}<<<")

    trackRDD
  }

  val saveRectify = (saveRDD: RDD[JSONObject], path: String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("emp_code")).append("\t")
      sb.append(obj.getString("ak")).append("\t")
      sb.append(obj.getString("app_version")).append("\t")
      sb.append(obj.getString("device_id")).append("\t")
      sb.append(obj.getString("tracks")).append("\t")
      sb.append(obj.getString("rectifyTrack")).append("\t")
      sb.append(obj.getString("error")).append("\t")
      sb.append(StringUtils.deleteWhitespace(obj.getString("reqJson"))).append("\t")
      sb.append(StringUtils.deleteWhitespace(obj.getString("resbonseBody"))).append("\t")
      sb.append(obj.getString("zc"))

      sb.toString()
    }).saveAsTextFile(path)
  }

  def rectifyTracks(aggrTrackRdd: RDD[JSONObject]): RDD[JSONObject] = {
    logger.error(">>>开始调用纠偏服务<<<")

    val rectifyRdd = aggrTrackRdd.map(obj => {
      val tracks = obj.getJSONArray("tracks")
      obj.replace("tracks", tracks)

      if (tracks != null && tracks.size() > 0) {
        var reqJson = new JSONObject()
        reqJson.put("vehicle", 1)
        reqJson.put("retflag", 1)
        reqJson.put("addpoint", 0)
        reqJson.put("tracks", tracks)

        var resbonseBody = HttpClientUtil.doPost(rectifyUrl, reqJson, logger)

        var rectifyTrack = null: JSONObject

        if (!resbonseBody.contains("发送post请求失败") && resbonseBody.contains("tracks")) {
          try {
            val respJson = JSON.parseObject(resbonseBody)
            val rectifySourceTrack = respJson.getJSONArray("tracks")

            if (rectifySourceTrack != null && !rectifySourceTrack.isEmpty) {
              rectifyTrack = new JSONObject()
              val trackArray = new JSONArray()

              for (i <- 0 until rectifySourceTrack.size()) {
                val item = tracks.getJSONObject(i)
                val jsonObj = new JSONObject()
                jsonObj.put("x", item.getDouble("x"))
                jsonObj.put("y", item.getDouble("y"))
                jsonObj.put("tm", item.getBigInteger("time"))

                trackArray.add(jsonObj)
              }

              rectifyTrack.put("ret", respJson.getInteger("ret"))
              rectifyTrack.put("tracks", trackArray)
            }

            /*rectifyTrack = resbonseBody.replaceAll("(\"sum_dist.*?,)|(\"reliable.*?,)|(\"matchOrder.*?,)|(\"index.*?,)|(\"milltime.*?,)|(\"type.*?,)".stripMargin,"")
                .replaceAll("time","tm")*/
            reqJson = new JSONObject()
            resbonseBody = ""
          } catch {
            case e: Exception => logger.error(e.getMessage)
          }
        }

        obj.put("reqJson", reqJson)
        obj.put("resbonseBody", resbonseBody)

        if (rectifyTrack != null && !rectifyTrack.isEmpty)
          obj.put("rectifyTrack", rectifyTrack)
        else
          obj.put("rectifyTrack", "")
      }

      obj
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>获取有效的纠偏轨迹${rectifyRdd.filter(obj => StringUtils.isNotBlank(obj.getString("rectifyTrack"))).count()}<<<")

    aggrTrackRdd.unpersist()
    rectifyRdd
  }

  def getAggrTrackRdd(trackRdd: RDD[((String, String, String, String, String), JSONObject)]): RDD[JSONObject] = {

    val aggrTrackRdd = trackRdd.aggregateByKey(List[JSONObject]())(Spark.seqOp, Spark.combOp).map(
      obj => {
        val xiaogeTrackList = obj._2

        val jsonArray = new JSONArray()
        var errorInfo = ""

        xiaogeTrackList.foreach(elem => {
          if (!elem.containsKey("error"))
            jsonArray.add(elem)
          else
            errorInfo += elem.getString("error")
        }
        )

        val tracks = JsonArraySortUtil.jsonArraySortInt(jsonArray, "time", false)

        val jsonObj = new JSONObject()
        jsonObj.put("emp_code", obj._1._1)
        jsonObj.put("ak", obj._1._2)
        jsonObj.put("app_version", obj._1._3)
        jsonObj.put("device_id", obj._1._4)
        jsonObj.put("zc", obj._1._5)
        jsonObj.put("tracks", tracks)
        jsonObj.put("error", errorInfo)

        jsonObj
      }
    ).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>聚合后轨迹:${aggrTrackRdd.count()}<<<")
    trackRdd.unpersist()

    aggrTrackRdd
  }

  def getTrackRdd(spark: SparkSession, parDate: String): RDD[((String, String, String, String, String), JSONObject)] = {
    val querySql =
      s"""
         |select
         |   t2.emp_code,t1.id,t1.v,t1.ak,t1.zx,t1.zy,t1.ac,t1.be,t1.sp,t1.tp,t1.tm,t1.bn
         |from
         |  ( select regexp_replace(un, '^(0+)', '') as emp_code,*
         |    from dm_gis.esg_gis_loc_trajectory
         |    where inc_day = '$parDate' and un <> ''
         |      and zx>0 and zy>0
         |   ) t1
         |right join (
         |    select
         |      distinct regexp_replace(emp_code, '^(0+)', '') as emp_code
         |    from
         |      dm_vms.tm_vms_vehicle_subsicy
         |    where
         |      inc_day = '$parDate'
         |      and emp_code <> ''
         |) t2 on t1.emp_code = t2.emp_code
         |where from_unixtime(cast(tm as int),'yyyyMMdd')=substr('$parDate',0,6) and t1.emp_code = '1000040'
         |""".stripMargin


    // where t1.emp_code = '419764'
    // group by un,ak,tm,zx,zy,ac,tp,sp,be
    // ak,tm,zx,zy,ac,tp,sp,be
    logger.error(querySql)

    val trackRDD = spark.sql(querySql).repartition(calPartition).rdd.map(obj => {
      try {
        val empCode = obj.getString(0).replaceAll("^[0]+", "")
        val json = new JSONObject()

        val zx = if (StringUtils.isNotBlank(obj.getString(4))) obj.getString(4).toDouble else null
        val zy = if (StringUtils.isNotBlank(obj.getString(5))) obj.getString(5).toDouble else null
        val tp = if (StringUtils.isNotBlank(obj.getString(9))) obj.getString(9).toInt else null
        val tm = if (StringUtils.isNotBlank(obj.getString(10))) obj.getString(10).toInt else null

        json.put("type", tp)
        json.put("x", zx)
        json.put("y", zy)
        json.put("accuracy", if (StringUtils.isBlank(obj.getString(6))) 15 else obj.getString(6).toInt)
        json.put("speed", if (StringUtils.isBlank(obj.getString(8))) 0 else obj.getString(8).toDouble)
        json.put("azimuth", if (StringUtils.isBlank(obj.getString(7))) 0 else obj.getString(7).toDouble)
        json.put("time", tm)

        //定位类型,纬度,经度,时间戳调用接口是为必填参数
        if (tm == null
          || zx == null
          || zy == null
          || tp == null
        )
          json.put("error", s"缺失定位类型|纬度|经度|时间戳:${json.toString}")

        //(工号,ak,app版本,id,网点)
        ((empCode, obj.getString(3), obj.getString(1), obj.getString(2), obj.getString(11)), json)

      } catch {
        case e: Exception => throw new RuntimeException("obj" + obj + e)
      }
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>共获取车辆轨迹点:${trackRDD.count()}<<<")

    trackRDD
  }
}
