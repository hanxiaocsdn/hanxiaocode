-- 
-- 
-- 需求方：熊志芳(01378520)
-- 需求： id: 1627337  【运营专项】产品协同输出版本质量报表_V1.0_数据侧
-- @author 张小琼 （01416344）
-- Created on 2023-03-22
-- 任务信息： ID：683179  项目质量评估指标
-- 

-- 用户需求  dm_effect.dm_ti_urs_user_need
-- 系统需求  dm_effect.dm_ti_rm_system_need
-- 研发任务  dm_effect.dm_ti_rm_develop_task
-- 版本缺陷  dm_effect.dm_ti_rm_version_bug
-- 生产缺陷  dm_effect.dm_ti_rm_prod_bug
-- 技术债务  dm_effect.dm_ti_rm_technical_debt
-- 产品协同表  dm_effect.ti_iterative_project
-- 分类表  dm_effect.ti_iterative_project_category
-- 模块表  dm_effect.ti_iterative_module
-- 迭代信息表  dm_effect.ti_iterative_spring
-- 版本号  dm_effect.ti_jira_version
-- 研发人员  dm_effect.dm_ti_common_issue_developers
-- 邮件通知人员  dm_effect.dm_ti_common_issue_email_notifiers
-- 测试人员  dm_effect.dm_ti_common_issue_testers
-- 产品协同关系表 dm_effect.ti_iterative_project_system_rel
-- dm_effect.ti_iterative_change_group  （日志变更组信息）
-- dm_effect.ti_iterative_change_item  （日志变更细节）
 
-- 2023-06-05 标签（需求变更、加急需求）
-- dm_effect.ti_common_issue_label （事项标签）
-- dm_effect.ti_iterative_label （标签）

-- -----------------------------------------------------------------------
-- 事项标签 -- 2023-06-05 修改
drop table if exists dm_gis_uimp.dwd_ti_common_issue_label;
create table dm_gis_uimp.dwd_ti_common_issue_label stored as parquet as 
select t0.id,t0.issue_id,t0.label_id,t1.label 
from ( select id,issue_id,label_id from dm_effect.ti_common_issue_label ) as t0 
left join ( select label_id,label from dm_effect.ti_iterative_label where label in ('需求变更','加急需求','紧急需求') ) as t1 
on t0.label_id=t1.label_id
;

-- 需求相关
drop table if exists dm_gis_uimp.dwd_ti_rm_system_need;
create table dm_gis_uimp.dwd_ti_rm_system_need stored as parquet as 
select 
sys_code,t1.id,t1.name,issue_type_id,t0.issue_id,issue_key,urs_user_need_id,user_need_id,
iterative_id,category_id,summary,status_id,priority_id,predict_person_day,
created,updated,dev_plain_completion_date,dev_manager_code, dev_manager_name,publish_time,dev_center_id,
dev_center_name,version_id,sign,story_type,modules,change_sign,
dev_start_time,dev_end_time,test_start_time,test_end_time,pre_publish_time,
t2.label  
from (
select id,project_id,sys_code,issue_type_id,issue_id,issue_key,urs_user_need_id,user_need_id,
iterative_id,category_id,summary,status_id,priority_id,predict_person_day,
created,updated,dev_plain_completion_date,dev_manager_code, dev_manager_name,publish_time,dev_center_id,
dev_center_name,version_id,sign,story_type,modules,change_sign,
dev_start_time,dev_end_time,test_start_time,test_end_time,pre_publish_time
from dm_effect.dm_ti_rm_system_need where dev_center_id='10039268' and created>='2023-01-01' 
) as t0 
left join ( select id,project_id,name from dm_effect.ti_iterative_spring ) as t1 
on t0.iterative_id=t1.id 
left join (select issue_id,label from dm_gis_uimp.dwd_ti_common_issue_label group by issue_id,label) as t2 
on t0.issue_id=t2.issue_id
;


-- 需求（历史日志）
drop table if exists dm_gis_uimp.dwd_ti_rm_system_need_history;
create table dm_gis_uimp.dwd_ti_rm_system_need_history stored as parquet as 
select sys_code,name,t0.issue_type_id,t0.issue_id,issue_key,urs_user_need_id,
iterative_id,category_id,summary,status_id,priority_id,
t2.old_string,t2.new_string  
from dm_gis_uimp.dwd_ti_rm_system_need as t0 
left join dm_effect.ti_iterative_change_group as t1 
on t0.issue_id=t1.issue_id 
left join dm_effect.ti_iterative_change_item as t2 
on t1.id=t2.group_id
;


-- 版本缺陷（bug）相关
drop table if exists dm_gis_uimp.dwd_dm_ti_rm_version_bug;
create table dm_gis_uimp.dwd_dm_ti_rm_version_bug stored as parquet as 
select 
t0.id,sys_code,t1.name,issue_id,issue_type_id,system_need_id,
system_need_key,summary,iterative_id,status_id,
created,updated,bug_level,fix_result,bug_type,reopen_reason,fix_count 
from (
select 
id,sys_code,issue_id,issue_type_id,system_need_id,
system_need_key,summary,iterative_id,status_id,
created,updated,bug_level,fix_result,bug_type,reopen_reason,fix_count 
from dm_effect.dm_ti_rm_version_bug where  created>='2023-01-01' ) as t0 
left join ( select id,project_id,name from dm_effect.ti_iterative_spring ) as t1 
on t0.iterative_id=t1.id
;


-- bug (历史日志)
drop table if exists dm_gis_uimp.dwd_dm_ti_rm_version_bug_history;
create table dm_gis_uimp.dwd_dm_ti_rm_version_bug_history stored as parquet as 
select t0.id,sys_code,t0.issue_id,t0.name,t0.issue_type_id,system_need_id,
system_need_key,summary,iterative_id,status_id,
created,updated,bug_level,fix_result,bug_type,reopen_reason,fix_count,
t2.id as log_id,t2.old_string,t2.new_string  
from dm_gis_uimp.dwd_dm_ti_rm_version_bug as t0 
left join dm_effect.ti_iterative_change_group as t1 
on t0.issue_id=t1.issue_id 
left join dm_effect.ti_iterative_change_item as t2 
on t1.id=t2.group_id
;


-- -------------------------------------
-- 项目质量评估表
create table dm_gis_uimp.dws_ti_pjt_qlt_stat(
sys_code string comment '系统编码',
name string comment '迭代版本名称',
name_id string comment '版本所在表的id',
test_end_time string comment '测试实际完成时间',
xq_cnt int comment '需求数',
xqbg_cnt int comment '需求变更数',
jjxq_cnt int comment '紧急需求数',
tcyq_days int comment '提测延期天数',
fbyq_days int comment '发布延期天数',
bug_cnt int comment 'bug数',
yzbug_cnt int comment '严重bug数',
reopenbug_cnt int comment 'reopen bug数',
ylbug_cnt int comment '遗留bug数'
)
COMMENT '项目质量评估' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_stat partition(inc_day='$firstDay') 
-- select 
-- sys_code,name,
-- if(xq_cnt is not null,xq_cnt,0) as xq_cnt,
-- if(xqbg_cnt is not null,xqbg_cnt,0) as xqbg_cnt,
-- if(jjxq_cnt is not null,jjxq_cnt,0) as jjxq_cnt,
-- if(tcyq_days is not null,tcyq_days,0) as tcyq_days,
-- if(fbyq_days is not null,fbyq_days,0) as fbyq_days,
-- if(bug_cnt is not null,bug_cnt,0) as bug_cnt,
-- if(yzbug_cnt is not null,yzbug_cnt,0) as yzbug_cnt,
-- if(reopenbug_cnt is not null,reopenbug_cnt,0) as reopenbug_cnt,
-- if(ylbug_cnt is not null,ylbug_cnt,0) as ylbug_cnt 
-- from (
-- select 
-- t0.sys_code,t0.name,xq_cnt,xqbg_cnt,jjxq_cnt,tcyq_days,fbyq_days,bug_cnt,yzbug_cnt,reopenbug_cnt,ylbug_cnt 
-- from (
-- select sys_code,name,
-- count(1) as xq_cnt,
-- sum(case when locate('紧急需求',name)>0 then 1 else 0 end) as jjxq_cnt,
-- sum(case when dev_end_time<>'' and dev_plain_completion_date<>'' and datediff(dev_end_time,dev_plain_completion_date)>=0 then datediff(dev_end_time,dev_plain_completion_date) else null end) as tcyq_days,
-- sum(case when publish_time<>'' and pre_publish_time<>'' and datediff(publish_time,pre_publish_time)>=0 then datediff(publish_time,pre_publish_time) else null end) as fbyq_days  
-- from  dm_gis_uimp.dwd_ti_rm_system_need group by sys_code,name order by sys_code,name 
-- ) as t0 
-- left join (
-- select sys_code,name,
-- sum(case when locate('#',new_string)>0 then 1 else 0 end ) as xqbg_cnt 
-- from dm_gis_uimp.dwd_ti_rm_system_need_history  group by sys_code,name order by sys_code,name 
-- ) as t1 on t0.sys_code=t1.sys_code and t0.name=t1.name 
-- left join (
-- select sys_code,name,
-- count(1) as bug_cnt,
-- sum(case when bug_level in ('10202','10203') then 1 else 0 end) as yzbug_cnt,
-- sum(case when status_id<>'6' then 1 else 0 end) as ylbug_cnt 
-- from dm_gis_uimp.dwd_dm_ti_rm_version_bug group by sys_code,name order by sys_code,name 
-- ) as t2 on t0.sys_code=t2.sys_code and t0.name=t2.name 
-- left join (
-- select sys_code,name,
-- sum(case when old_string='测试中' and new_string='研发中' then 1 else 0 end) as reopenbug_cnt
-- from dm_gis_uimp.dwd_dm_ti_rm_version_bug_history group by sys_code,name order by sys_code,name 
-- ) as t3 on t0.sys_code=t3.sys_code and t0.name=t3.name 
-- ) as t 
-- ;

-- 2023-06-05 修改
insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_stat partition(inc_day='$firstDay') 
select 
sys_code,name,name_id,test_end_time,
if(xq_cnt is not null,xq_cnt,0) as xq_cnt,
if(xqbg_cnt is not null,xqbg_cnt,0) as xqbg_cnt,
if(jjxq_cnt is not null,jjxq_cnt,0) as jjxq_cnt,
if(tcyq_days is not null,tcyq_days,0) as tcyq_days,
if(fbyq_days is not null,fbyq_days,0) as fbyq_days,
if(bug_cnt is not null,bug_cnt,0) as bug_cnt,
if(yzbug_cnt is not null,yzbug_cnt,0) as yzbug_cnt,
if(reopenbug_cnt is not null,reopenbug_cnt,0) as reopenbug_cnt,
if(ylbug_cnt is not null,ylbug_cnt,0) as ylbug_cnt 
from (
select 
t0.sys_code,t0.name,t0.name_id,t0.test_end_time,xq_cnt,xqbg_cnt,jjxq_cnt,tcyq_days,fbyq_days,bug_cnt,yzbug_cnt,reopenbug_cnt,ylbug_cnt 
from (
select sys_code,name,max(id) as name_id,max(test_end_time) as test_end_time,
count(1) as xq_cnt,
sum(case when label='需求变更' then 1 else 0 end) as xqbg_cnt,
sum(case when label in ('加急需求','紧急需求') then 1 else 0 end) as jjxq_cnt,
sum(case when dev_end_time<>'' and dev_plain_completion_date<>'' and datediff(dev_end_time,dev_plain_completion_date)>=0 then datediff(dev_end_time,dev_plain_completion_date) else 0 end) as tcyq_days,
sum(case when test_end_time<>'' and pre_publish_time<>'' and datediff(test_end_time,pre_publish_time)>=0 then datediff(test_end_time,pre_publish_time) else 0 end) as fbyq_days  
from  dm_gis_uimp.dwd_ti_rm_system_need group by sys_code,name order by sys_code,name 
) as t0 
left join (
select sys_code,name,
count(1) as bug_cnt,
sum(case when bug_level in ('10202','10203') then 1 else 0 end) as yzbug_cnt,
sum(case when status_id<>'6' then 1 else 0 end) as ylbug_cnt 
from dm_gis_uimp.dwd_dm_ti_rm_version_bug group by sys_code,name order by sys_code,name 
) as t2 on t0.sys_code=t2.sys_code and t0.name=t2.name 
left join (
select sys_code,name,
sum(case when old_string='测试中' and new_string='研发中' then 1 else 0 end) as reopenbug_cnt
from dm_gis_uimp.dwd_dm_ti_rm_version_bug_history group by sys_code,name order by sys_code,name 
) as t3 on t0.sys_code=t3.sys_code and t0.name=t3.name 
) as t 
;



-- v1.3需求
create table dm_gis_uimp.dws_ti_pjt_qlt_score(
sys_code string comment '系统编码',
name string comment '迭代版本名称',
name_id string comment '版本所在表的id',
test_end_time string comment '测试实际完成时间',
tcyq_score int comment '提测延期得分',
fbyq_score int comment '发布延期得分',
xqbg_score int comment '需求变更得分',
bug_score int comment 'bug得分',
yzbug_score int comment '严重bug得分',
reopenbug_score int comment 'reopen bug得分',
tcyq_wscore decimal(10,2) comment '提测延期权重得分',
fbyq_wscore decimal(10,2) comment '发布延期权重得分',
xqbg_wscore decimal(10,2) comment '需求变更权重得分',
bug_wscore decimal(10,2) comment 'bug权重得分',
yzbug_wscore decimal(10,2) comment '严重bug权重得分',
reopenbug_wscore decimal(10,2) comment 'reopen bug权重得分',
project_wscore  decimal(10,2) comment '项目得分',
project_hlevel  int comment '项目健康度' 
)
COMMENT '项目质量评估分值' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
-- insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_score partition(inc_day='$firstDay') 
-- select sys_code,name,xq_cnt,xqbg_score,jjxq_score,tcyq_score,fbyq_score,bug_score,yzbug_score,reopenbug_score,
-- xqbg_score+jjxq_score+tcyq_score+fbyq_score+bug_score+yzbug_score+reopenbug_score as total_score 
-- from (
-- select sys_code,name,xq_cnt,
-- if(xqbg_score is not null,xqbg_score,0) as xqbg_score,
-- if(jjxq_score is not null,jjxq_score,0) as jjxq_score,
-- if(tcyq_score is not null,tcyq_score,0) as tcyq_score,
-- if(fbyq_score is not null,fbyq_score,0) as fbyq_score,
-- if(bug_score is not null,bug_score,0) as bug_score,
-- if(yzbug_score is not null,yzbug_score,0) as yzbug_score,
-- if(reopenbug_score is not null,reopenbug_score,0) as reopenbug_score  
-- from (
-- select 
-- sys_code,name,
-- xq_cnt, 
-- case when xqbg_ratio>=0.8 then 1 
--      when xqbg_ratio<0.8 and xqbg_ratio>=0.6 then 2
--      when xqbg_ratio<0.6 and xqbg_ratio>0.4 then 3
--      when xqbg_ratio<0.4 and xqbg_ratio>0.3 then 4
--      when xqbg_ratio<0.3 then 5
--      else null end  as  xqbg_score,
-- case when jjxq_ratio>=0.8 then 1 
--      when jjxq_ratio<0.8 and jjxq_ratio>=0.6 then 2
--      when jjxq_ratio<0.6 and jjxq_ratio>0.4 then 3
--      when jjxq_ratio<0.4 and jjxq_ratio>0.3 then 4
--      when jjxq_ratio<0.3 then 5
--      else null end  as  jjxq_score,
-- case when tcyq_ratio>=4 then 1 
--      when tcyq_ratio<4 and tcyq_ratio>=2 then 2
--      when tcyq_ratio<2 and tcyq_ratio>1 then 3
--      when tcyq_ratio<1 and tcyq_ratio>0.5 then 4
--      when tcyq_ratio<0.5 then 5
--      else null end  as  tcyq_score,
-- case when fbyq_ratio>=4 then 1 
--      when fbyq_ratio<4 and fbyq_ratio>=2 then 2
--      when fbyq_ratio<2 and fbyq_ratio>1 then 3
--      when fbyq_ratio<1 and fbyq_ratio>0.5 then 4
--      when fbyq_ratio<0.5 then 5
--      else null end  as  fbyq_score,
-- case when bug_ratio>=20 then 1 
--      when bug_ratio<20 and bug_ratio>=15 then 2
--      when bug_ratio<15 and bug_ratio>10 then 3
--      when bug_ratio<10 and bug_ratio>5 then 4
--      when bug_ratio<5 then 5
--      else null end  as  bug_score,
-- case when yzbug_ratio>=4 then 1 
--      when yzbug_ratio<4 and yzbug_ratio>=2 then 2
--      when yzbug_ratio<2 and yzbug_ratio>1 then 3
--      when yzbug_ratio<1 and yzbug_ratio>0.5 then 4
--      when yzbug_ratio<0.5 then 5
--      else null end  as  yzbug_score,
-- case when reopenbug_ratio>=4 then 1 
--      when reopenbug_ratio<4 and reopenbug_ratio>=2 then 2
--      when reopenbug_ratio<2 and reopenbug_ratio>1 then 3
--      when reopenbug_ratio<1 and reopenbug_ratio>0.5 then 4
--      when reopenbug_ratio<0.5 then 5
--      else null end  as  reopenbug_score
-- from (
-- select 
-- sys_code,name,
-- xq_cnt, 
-- xqbg_cnt/xq_cnt as xqbg_ratio,
-- jjxq_cnt/xq_cnt as jjxq_ratio, 
-- tcyq_days/xq_cnt as tcyq_ratio,
-- fbyq_days/xq_cnt as fbyq_ratio,
-- bug_cnt/xq_cnt as bug_ratio,
-- yzbug_cnt/xq_cnt as yzbug_ratio,
-- reopenbug_cnt/xq_cnt as reopenbug_ratio 
-- from dm_gis_uimp.dws_ti_pjt_qlt_stat 
-- where inc_day='$firstDay' 
-- ) as t 
-- ) as tt 
-- ) as ttt 
-- ;

insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_score partition(inc_day='$firstDay') 
select sys_code,name,name_id,test_end_time,
tcyq_score,
fbyq_score,
xqbg_score,
bug_score,
yzbug_score,
reopenbug_score,
cast(tcyq_wscore as decimal(10,2)) as tcyq_wscore,
cast(fbyq_wscore as decimal(10,2)) as fbyq_wscore,
cast(xqbg_wscore as decimal(10,2)) as xqbg_wscore,
cast(bug_wscore as decimal(10,2)) as bug_wscore,
cast(yzbug_wscore as decimal(10,2)) as yzbug_wscore,
cast(reopenbug_wscore as decimal(10,2)) as reopenbug_wscore,
project_wscore,
case when project_wscore<3.5 then 1 
when project_wscore<4 and project_wscore>=3.5 then 2 
when project_wscore<4.5 and project_wscore>=4 then 3 
when project_wscore<5 and project_wscore>=4.5 then 4 
when project_wscore>=5 then 5 
else null end  as  project_hlevel  
from (
select sys_code,name,name_id,test_end_time,
tcyq_score,
fbyq_score,
xqbg_score,
bug_score,
yzbug_score,
reopenbug_score,
tcyq_wscore,
fbyq_wscore,
xqbg_wscore,
bug_wscore,
yzbug_wscore,
reopenbug_wscore,
tcyq_wscore+fbyq_wscore+xqbg_wscore+bug_wscore+yzbug_wscore+reopenbug_wscore as project_wscore 
from (
select sys_code,name,name_id,test_end_time,
if(tcyq_score is not null,tcyq_score,0) as tcyq_score,
if(fbyq_score is not null,fbyq_score,0) as fbyq_score,
if(xqbg_score is not null,xqbg_score,0) as xqbg_score,
if(bug_score is not null,bug_score,0) as bug_score,
if(yzbug_score is not null,yzbug_score,0) as yzbug_score,
if(reopenbug_score is not null,reopenbug_score,0) as reopenbug_score,
if(tcyq_score is not null,0.1*tcyq_score,0) as tcyq_wscore,
if(fbyq_score is not null,0.3*fbyq_score,0) as fbyq_wscore,
if(xqbg_score is not null,0.2*xqbg_score,0) as xqbg_wscore,
if(bug_score is not null,0.1*bug_score,0) as bug_wscore,
if(yzbug_score is not null,0.2*yzbug_score,0) as yzbug_wscore,
if(reopenbug_score is not null,0.1*reopenbug_score,0) as reopenbug_wscore 
from (
select 
sys_code,name,name_id,test_end_time,
case when tcyq_days>=4 then 1 
     when tcyq_days<4 and tcyq_days>=3 then 2
     when tcyq_days<3 and tcyq_days>=2 then 3
     when tcyq_days<2 and tcyq_days>=1 then 4
     when tcyq_days<1 and tcyq_days>=0 then 5
     else null end  as  tcyq_score,
case when fbyq_days>=4 then 1 
     when fbyq_days<4 and fbyq_days>=3 then 2
     when fbyq_days<3 and fbyq_days>=2 then 3
     when fbyq_days<2 and fbyq_days>=1 then 4
     when fbyq_days<1 and fbyq_days>=0 then 5
     else null end  as  fbyq_score,
case when xqbg_cnt>=4 then 1 
     when xqbg_cnt<4 and xqbg_cnt>=3 then 2
     when xqbg_cnt<3 and xqbg_cnt>=2 then 3
     when xqbg_cnt<2 and xqbg_cnt>=1 then 4
     when xqbg_cnt<1 and xqbg_cnt>=0 then 5
     else null end  as  xqbg_score,
case when bug_cnt>=15 then 1 
     when bug_cnt<15 and bug_cnt>=10 then 2
     when bug_cnt<10 and bug_cnt>=5 then 3
     when bug_cnt<5 and bug_cnt>=1 then 4
     when bug_cnt<1 and bug_cnt>=0 then 5
     else null end  as  bug_score,
case when yzbug_cnt>=4 then 1 
     when yzbug_cnt<4 and yzbug_cnt>=3 then 2
     when yzbug_cnt<3 and yzbug_cnt>=2 then 3
     when yzbug_cnt<2 and yzbug_cnt>=1 then 4
     when yzbug_cnt<1 and yzbug_cnt>=0 then 5
     else null end  as  yzbug_score,
case when reopenbug_cnt>=4 then 1 
     when reopenbug_cnt<4 and reopenbug_cnt>=3 then 2
     when reopenbug_cnt<3 and reopenbug_cnt>=2 then 3
     when reopenbug_cnt<2 and reopenbug_cnt>=1 then 4
     when reopenbug_cnt<1 and reopenbug_cnt>=0 then 5
     else null end  as  reopenbug_score 
from (
select 
sys_code,name,name_id,test_end_time,
tcyq_days,
fbyq_days,
xqbg_cnt,
bug_cnt,
yzbug_cnt,
reopenbug_cnt  
from dm_gis_uimp.dws_ti_pjt_qlt_stat 
where inc_day='$firstDay' 
) as t 
) as tt 
) as ttt 
) as tttt 
;



-- -- 交付效率指标
-- -- select 
-- -- stat_month,count(1) as xq_cnt 
-- -- from (
-- -- select substr(created,0,7) as stat_month 
-- -- from dm_gis_uimp.dwd_ti_rm_system_need 
-- -- ) as t group by stat_month
-- create table dm_gis_uimp.dws_ti_pjt_qlt_delivery_efficiency(
-- stat_month string comment '月份',
-- bug_cnt double comment '生产缺陷',
-- fb_cnt double comment '发布数',
-- yf_cnt_days double comment '研发人天',
-- test_cnt_days double comment '测试人天',
-- jfzq_days  double comment '交付周期（avg）' 
-- )
-- COMMENT '项目质量交付效率指标' 
-- PARTITIONED BY (inc_day STRING COMMENT '分区日期')
-- STORED AS parquet
-- tblproperties ('parquet.compression'='snappy')
-- ;

-- drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_bug;
-- create table dm_gis_uimp.tmp_ti_prod_collaboration_bug as 
-- select 
-- stat_month,count(1) as bug_cnt 
-- from (
-- select 
-- t0.sys_code,t0.name,substr(created,0,7) as stat_month  
-- from ( select 
-- sys_code,name,created 
-- from dm_gis_uimp.dwd_dm_ti_rm_version_bug where created>'2023-01-01' ) as t0 
-- left join (select sys_code,name from dm_gis_uimp.dwd_ti_rm_system_need group by sys_code,name) as t1 
-- on t0.sys_code=t1.sys_code and t0.name=t1.name 
-- where t1.sys_code is not null 
-- ) as t group by stat_month 
-- ;

-- drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_fb;
-- create table dm_gis_uimp.tmp_ti_prod_collaboration_fb as 
-- select 
-- stat_month,count(1) as fb_cnt 
-- from (
-- select substr(publish_time,0,7) as stat_month 
-- from dm_gis_uimp.dwd_ti_rm_system_need where publish_time is not null and publish_time<>'' 
-- ) as t group by stat_month
-- ;

-- drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren;
-- create table dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren as 
-- select 
-- stat_month,sum(yf_cnt/yf_days) as yf_cnt_days 
-- from (
-- select id,stat_month,yf_days,count(distinct user_code) as yf_cnt
-- from (
-- select 
-- id,substr(dev_end_time,0,7) as stat_month,datediff(dev_end_time,dev_start_time) as yf_days,user_code 
-- from (
-- select t0.id,dev_start_time,dev_end_time,t1.user_code
-- from (select id,dev_start_time,dev_end_time  from dm_effect.dm_ti_rm_system_need  
-- where dev_center_id='10039268' and created>='2023-01-01' 
-- and dev_start_time is not null and dev_start_time<>'' and dev_end_time is not null and dev_end_time<>'') as t0 
-- left join  dm_effect.dm_ti_common_issue_developers as t1 
-- on t0.id=t1.local_issue_id	
-- ) as t 
-- ) as tt group by id,stat_month,yf_days
-- ) as ttt group by stat_month
-- ;

-- drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_test_ren;
-- create table dm_gis_uimp.tmp_ti_prod_collaboration_test_ren as 
-- select 
-- stat_month,sum(test_cnt/test_days) as test_cnt_days 
-- from (
-- select id,stat_month,test_days,count(distinct user_code) as test_cnt
-- from (
-- select 
-- id,substr(test_end_time,0,7) as stat_month,datediff(test_end_time,test_start_time) as test_days,user_code 
-- from (
-- select t0.id,test_start_time,test_end_time,t1.user_code
-- from (select id,test_start_time,test_end_time  from dm_effect.dm_ti_rm_system_need  
-- where dev_center_id='10039268' and created>='2023-01-01' 
-- and test_start_time is not null and test_start_time<>'' and test_end_time is not null and test_end_time<>'') as t0 
-- left join  dm_effect.dm_ti_common_issue_testers as t1 
-- on t0.id=t1.local_issue_id	
-- ) as t 
-- ) as tt group by id,stat_month,test_days
-- ) as ttt group by stat_month
-- ;

-- drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_jfzq;
-- create table dm_gis_uimp.tmp_ti_prod_collaboration_jfzq as 
-- select 
-- stat_month,avg(jfzq_days) as jfzq_days  
-- from (
-- select substr(publish_time,0,7) as stat_month,datediff(publish_time,created) as jfzq_days 
-- from dm_gis_uimp.dwd_ti_rm_system_need
-- where publish_time is not null and publish_time<>''
-- ) as t group by stat_month 
-- ;

-- insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_delivery_efficiency partition(inc_day='$firstDay') 
-- select t0.stat_month,bug_cnt,fb_cnt,yf_cnt_days,test_cnt_days,jfzq_days 
-- from dm_gis_uimp.tmp_ti_prod_collaboration_bug as t0 
-- left join dm_gis_uimp.tmp_ti_prod_collaboration_fb as t1 
-- on t0.stat_month=t1.stat_month 
-- left join dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren as t2 
-- on t0.stat_month=t2.stat_month 
-- left join dm_gis_uimp.tmp_ti_prod_collaboration_test_ren as t3 
-- on t0.stat_month=t3.stat_month 
-- left join dm_gis_uimp.tmp_ti_prod_collaboration_jfzq as t4 
-- on t0.stat_month=t4.stat_month 
-- ;

-- 用户需求交付周期趋势
create table dm_gis_uimp.dws_ti_pjt_qlt_lead_time_trends(
stat_month string comment '月份',
jfzq_days double comment '交付周期天数（avg）',
jfzq_7days_ratio double comment '一周交付占比',
jfzq_14days_ratio double comment '两周交付占比' 
)
COMMENT '项目质量交付周期指标' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_lead_time_trends partition(inc_day='$firstDay') 
select stat_month,avg(jfzq_days) as jfzq_days,sum(if(jfzq_days<=7,1,0))/count(1) as jfzq_7days_ratio,sum(if(jfzq_days<=14,1,0))/count(1) as jfzq_14days_ratio  
from (
select substr(publish_time,0,7) as stat_month,datediff(publish_time,created) as jfzq_days 
from (
select id,issue_id,created,publish_time 
from (
select id,issue_id,created,publish_time from dm_effect.dm_ti_urs_user_need 
where dev_center_id='10039268' and created>'2023-01-01' 
) as t0  
left join (select user_need_id from dm_effect.dm_ti_rm_system_need where dev_center_id='10039268' and created>='2023-01-01' ) as t1 
on t0.issue_id=t1.user_need_id 
where t1.user_need_id is not null 
group by id,issue_id,created,publish_time 
) as t 
) as tt where stat_month is not null  group by stat_month 
;



----------------------------------------------------------------------
-- v1.2  需求  2023.06.13
-- 系统交付效率指标 (支持单个系统维度)
create table dm_gis_uimp.dws_ti_pjt_qlt_delivery_efficiency(
sys_code string comment '系统编码',
stat_month string comment '月份',
bug_cnt double comment '生产缺陷',
fb_cnt double comment '发布数',
yf_cnt_days double comment '研发人天',
test_cnt_days double comment '测试人天',
jfzq_days  double comment '交付周期（avg）' 
)
COMMENT '项目质量交付效率指标' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_verison_cnt;
create table dm_gis_uimp.tmp_ti_prod_collaboration_verison_cnt stored as parquet as 
select 
sys_code,stat_month,count(distinct name) as verison_cnt  
from (
select sys_code,substr(created,0,7) as stat_month,name 
from dm_gis_uimp.dwd_ti_rm_system_need where created is not null and created<>'' 
) as t group by sys_code,stat_month
;


drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_bug;
create table dm_gis_uimp.tmp_ti_prod_collaboration_bug stored as parquet as 
select 
sys_code,stat_month,count(1) as bug_cnt 
from (
select 
t0.sys_code,t0.name,substr(created,0,7) as stat_month  
from ( select 
sys_code,name,created 
from dm_gis_uimp.dwd_dm_ti_rm_version_bug where created>'2023-01-01' ) as t0 
left join (select sys_code,name from dm_gis_uimp.dwd_ti_rm_system_need group by sys_code,name) as t1 
on t0.sys_code=t1.sys_code and t0.name=t1.name 
where t1.sys_code is not null 
) as t group by sys_code,stat_month 
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_fb;
create table dm_gis_uimp.tmp_ti_prod_collaboration_fb stored as parquet as 
select 
sys_code,stat_month,count(1) as fb_cnt 
from (
select sys_code,substr(test_end_time,0,7) as stat_month 
from dm_gis_uimp.dwd_ti_rm_system_need where test_end_time is not null and test_end_time<>'' 
) as t group by sys_code,stat_month
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren;
create table dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren stored as parquet as 
select 
sys_code,stat_month,sum(yf_cnt/yf_days) as yf_cnt_days 
from (
select id,sys_code,stat_month,yf_days,count(distinct user_code) as yf_cnt
from (
select 
id,sys_code,substr(dev_end_time,0,7) as stat_month,datediff(dev_end_time,dev_start_time) as yf_days,user_code 
from (
select t0.id,sys_code,dev_start_time,dev_end_time,t1.user_code
from (select id,sys_code,dev_start_time,dev_end_time  from dm_effect.dm_ti_rm_system_need  
where dev_center_id='10039268' and created>='2023-01-01' 
and dev_start_time is not null and dev_start_time<>'' and dev_end_time is not null and dev_end_time<>'') as t0 
left join  dm_effect.dm_ti_common_issue_developers as t1 
on t0.id=t1.local_issue_id	
) as t 
) as tt group by id,sys_code,stat_month,yf_days
) as ttt group by sys_code,stat_month
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_test_ren;
create table dm_gis_uimp.tmp_ti_prod_collaboration_test_ren stored as parquet as 
select 
sys_code,stat_month,sum(test_cnt/test_days) as test_cnt_days 
from (
select id,sys_code,stat_month,test_days,count(distinct user_code) as test_cnt
from (
select 
id,sys_code,substr(test_end_time,0,7) as stat_month,datediff(test_end_time,test_start_time) as test_days,user_code 
from (
select t0.id,sys_code,test_start_time,test_end_time,t1.user_code
from (select id,sys_code,test_start_time,test_end_time  from dm_effect.dm_ti_rm_system_need  
where dev_center_id='10039268' and created>='2023-01-01' 
and test_start_time is not null and test_start_time<>'' and test_end_time is not null and test_end_time<>'') as t0 
left join  dm_effect.dm_ti_common_issue_testers as t1 
on t0.id=t1.local_issue_id	
) as t 
) as tt group by id,sys_code,stat_month,test_days
) as ttt group by sys_code,stat_month
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_jfzq;
create table dm_gis_uimp.tmp_ti_prod_collaboration_jfzq stored as parquet as 
select 
sys_code,stat_month,avg(jfzq_days) as jfzq_days  
from (
select sys_code,substr(test_end_time,0,7) as stat_month,datediff(test_end_time,created) as jfzq_days 
from dm_gis_uimp.dwd_ti_rm_system_need
where test_end_time is not null and test_end_time<>''
) as t group by sys_code,stat_month 
;



insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_delivery_efficiency partition(inc_day='$firstDay') 
select t0.sys_code,t0.stat_month,
cast(bug_cnt/verison_cnt as decimal(10,2)) as bug_cnt,
cast(fb_cnt/verison_cnt as decimal(10,2)) as fb_cnt,
cast(yf_cnt_days/verison_cnt as decimal(10,2)) as yf_cnt_days,
cast(test_cnt_days/verison_cnt as decimal(10,2)) as test_cnt_days,
cast(jfzq_days/verison_cnt as decimal(10,2)) as jfzq_days  
from dm_gis_uimp.tmp_ti_prod_collaboration_verison_cnt as t0 
left join dm_gis_uimp.tmp_ti_prod_collaboration_bug as t01 
on t0.sys_code=t01.sys_code and t0.stat_month=t01.stat_month
left join dm_gis_uimp.tmp_ti_prod_collaboration_fb as t1 
on t0.sys_code=t1.sys_code and t0.stat_month=t1.stat_month 
left join dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren as t2 
on t0.sys_code=t2.sys_code and t0.stat_month=t2.stat_month 
left join dm_gis_uimp.tmp_ti_prod_collaboration_test_ren as t3 
on t0.sys_code=t3.sys_code and t0.stat_month=t3.stat_month 
left join dm_gis_uimp.tmp_ti_prod_collaboration_jfzq as t4 
on t0.sys_code=t4.sys_code and t0.stat_month=t4.stat_month 
;




-- 系统需求交付速度  (支持单个系统维度)
-- 系统需求交付周期：系统需求发布时间-系统需求创建时间    publish_time,created   
-- (v1.3 改 系统需求交付周期：系统需求待发布时间-系统需求创建时间    test_end_time,created   
-- 系统需求等待研发时长：研发实际开始日期-创建系统需求时间  dev_start_time,created
-- 系统需求研发时长:研发实际完成日期-研发实际开始日期   dev_end_time,dev_start_time
-- 系统需求等待测试时长:测试实际开始日期-研发实际完成日期  test_start_time,dev_end_time
-- 系统需求测试时长:测试实际完成日期-测试实际开始日期  test_end_time,test_start_time
create table dm_gis_uimp.dws_ti_pjt_qlt_delivery_speed(
sys_code string comment '系统编码',
stat_month string comment '月份',
jfzq_days double comment '交付周期(天)',
wait_rd_days double comment '等待研发时长(天)',
rd_days double comment '研发时长(天)',
wait_test_days double comment '等待测试时长(天)',
test_days double comment '测试时长(天)' 
)
COMMENT '项目质量系统需求交付速度' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_delivery_speed partition(inc_day='$firstDay') 
select sys_code,stat_month,
cast(jfzq/(24*verison_cnt) as decimal(10,2)) as jfzq_days,
cast(ddyfsc/(24*verison_cnt) as decimal(10,2)) as wait_rd_days,
cast(yfsc/(24*verison_cnt) as decimal(10,2)) as rd_days,
cast(ddcssc/(24*verison_cnt) as decimal(10,2)) as wait_test_days,
cast(cssc/(24*verison_cnt) as decimal(10,2)) as test_days 
from (
select 
sys_code,stat_month,count(distinct name) as verison_cnt,
sum(jfzq) as jfzq,
sum(ddyfsc) as ddyfsc,
sum(yfsc) as yfsc,
sum(ddcssc) as ddcssc,
sum(cssc) as cssc 
from (
select sys_code,substr(created,0,7) as stat_month,name,
(hour(test_end_time)-hour(created)+datediff(test_end_time,created)*24) as jfzq,
(hour(dev_start_time)-hour(created)+datediff(dev_start_time,created)*24) as ddyfsc,
(hour(dev_end_time)-hour(dev_start_time)+datediff(dev_end_time,dev_start_time)*24) as yfsc,
(hour(test_start_time)-hour(dev_end_time)+datediff(test_start_time,dev_end_time)*24) as ddcssc,
(hour(test_end_time)-hour(test_start_time)+datediff(test_end_time,test_start_time)*24) as cssc 
from dm_gis_uimp.dwd_ti_rm_system_need where created is not null and created<>'' 
) as t group by sys_code,stat_month 
) as tt 
;


------------------------------------------------------------------------
-- 20230727 v1.3 新增 系统版本维度的交付效率指标和交付速度

-- 系统交付效率指标 （版本维度）
create table dm_gis_uimp.dws_ti_pjt_qlt_delivery_efficiency_bb(
sys_code string comment '系统编码',
name string comment '版本',
name_id string comment '版本所在表的id',
test_end_time string comment '测试实际完成时间',
bug_cnt double comment '生产缺陷',
fb_cnt double comment '发布数',
yf_cnt_days double comment '研发人天',
test_cnt_days double comment '测试人天',
jfzq_days  double comment '交付周期（avg）' 
)
COMMENT '项目质量交付效率指标（版本维度）' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_bug;
create table dm_gis_uimp.tmp_ti_prod_collaboration_bug stored as parquet as 
select 
sys_code,name,count(1) as bug_cnt 
from (
select 
t0.sys_code,t0.name,substr(created,0,7) as stat_month  
from ( select 
sys_code,name,created 
from dm_gis_uimp.dwd_dm_ti_rm_version_bug where created>'2023-01-01' ) as t0 
left join (select sys_code,name from dm_gis_uimp.dwd_ti_rm_system_need group by sys_code,name) as t1 
on t0.sys_code=t1.sys_code and t0.name=t1.name 
where t1.sys_code is not null 
) as t group by sys_code,name 
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_fb;
create table dm_gis_uimp.tmp_ti_prod_collaboration_fb stored as parquet as 
select 
sys_code,name,count(1) as fb_cnt 
from (
select sys_code,name,substr(test_end_time,0,7) as stat_month 
from dm_gis_uimp.dwd_ti_rm_system_need where test_end_time is not null and test_end_time<>'' 
) as t group by sys_code,name 
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren;
create table dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren stored as parquet as 
select 
sys_code,name,sum(yf_cnt/yf_days) as yf_cnt_days 
from (
select id,sys_code,name,yf_days,count(distinct user_code) as yf_cnt
from (
select 
id,sys_code,name,substr(dev_end_time,0,7) as stat_month,datediff(dev_end_time,dev_start_time) as yf_days,user_code 
from (
select t0.id,sys_code,t2.name,dev_start_time,dev_end_time,t1.user_code
from (select id,sys_code,iterative_id,dev_start_time,dev_end_time  from dm_effect.dm_ti_rm_system_need  
where dev_center_id='10039268' and created>='2023-01-01' 
and dev_start_time is not null and dev_start_time<>'' and dev_end_time is not null and dev_end_time<>'') as t0 
left join  dm_effect.dm_ti_common_issue_developers as t1 
on t0.id=t1.local_issue_id 
left join  ( select id,project_id,name from dm_effect.ti_iterative_spring ) as t2 
on t0.iterative_id=t2.id 
) as t 
) as tt group by id,sys_code,name,yf_days
) as ttt group by sys_code,name 
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_test_ren;
create table dm_gis_uimp.tmp_ti_prod_collaboration_test_ren stored as parquet as 
select 
sys_code,name,sum(test_cnt/test_days) as test_cnt_days 
from (
select id,sys_code,name,test_days,count(distinct user_code) as test_cnt
from (
select 
id,sys_code,name,substr(test_end_time,0,7) as stat_month,datediff(test_end_time,test_start_time) as test_days,user_code 
from (
select t0.id,sys_code,t2.name,test_start_time,test_end_time,t1.user_code
from (select id,sys_code,iterative_id,test_start_time,test_end_time  from dm_effect.dm_ti_rm_system_need  
where dev_center_id='10039268' and created>='2023-01-01' 
and test_start_time is not null and test_start_time<>'' and test_end_time is not null and test_end_time<>'') as t0 
left join  dm_effect.dm_ti_common_issue_testers as t1 
on t0.id=t1.local_issue_id	
left join  ( select id,project_id,name from dm_effect.ti_iterative_spring ) as t2 
on t0.iterative_id=t2.id 
) as t 
) as tt group by id,sys_code,name,test_days
) as ttt group by sys_code,name
;

drop table if exists dm_gis_uimp.tmp_ti_prod_collaboration_jfzq;
create table dm_gis_uimp.tmp_ti_prod_collaboration_jfzq stored as parquet as 
select 
sys_code,name,avg(jfzq_days) as jfzq_days  
from (
select sys_code,name,substr(test_end_time,0,7) as stat_month,datediff(test_end_time,created) as jfzq_days 
from dm_gis_uimp.dwd_ti_rm_system_need
where test_end_time is not null and test_end_time<>''
) as t group by sys_code,name 
;



insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_delivery_efficiency_bb partition(inc_day='$firstDay') 
select t0.sys_code,t0.name,t0.name_id,t0.test_end_time,
cast(bug_cnt as decimal(10,2)) as bug_cnt,
cast(fb_cnt as decimal(10,2)) as fb_cnt,
cast(yf_cnt_days as decimal(10,2)) as yf_cnt_days,
cast(test_cnt_days as decimal(10,2)) as test_cnt_days,
cast(jfzq_days as decimal(10,2)) as jfzq_days  
from (select sys_code,name,max(id) as name_id,max(test_end_time) as test_end_time  from dm_gis_uimp.dwd_ti_rm_system_need group by sys_code,name) as t0 
left join dm_gis_uimp.tmp_ti_prod_collaboration_bug as t01 
on t0.sys_code=t01.sys_code and t0.name=t01.name
left join dm_gis_uimp.tmp_ti_prod_collaboration_fb as t1 
on t0.sys_code=t1.sys_code and t0.name=t1.name 
left join dm_gis_uimp.tmp_ti_prod_collaboration_yf_ren as t2 
on t0.sys_code=t2.sys_code and t0.name=t2.name 
left join dm_gis_uimp.tmp_ti_prod_collaboration_test_ren as t3 
on t0.sys_code=t3.sys_code and t0.name=t3.name 
left join dm_gis_uimp.tmp_ti_prod_collaboration_jfzq as t4 
on t0.sys_code=t4.sys_code and t0.name=t4.name 
;




-- 系统需求交付速度  (版本维度)
create table dm_gis_uimp.dws_ti_pjt_qlt_delivery_speed_bb(
sys_code string comment '系统编码',
name string comment '版本',
name_id string comment '版本所在表的id',
test_end_time string comment '测试实际完成时间',
jfzq_days double comment '交付周期(天)',
wait_rd_days double comment '等待研发时长(天)',
rd_days double comment '研发时长(天)',
wait_test_days double comment '等待测试时长(天)',
test_days double comment '测试时长(天)' 
)
COMMENT '项目质量系统需求交付速度（版本维度）' 
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis_uimp.dws_ti_pjt_qlt_delivery_speed_bb partition(inc_day='$firstDay') 
select 
sys_code,name,max(id) as name_id,max(test_end_time) as test_end_time,
cast(sum(jfzq)/24 as decimal(10,2)) as jfzq_days,
cast(sum(ddyfsc)/24 as decimal(10,2)) as wait_rd_days,
cast(sum(yfsc)/24 as decimal(10,2)) as rd_days,
cast(sum(ddcssc)/24 as decimal(10,2)) as wait_test_days,
cast(sum(cssc)/24 as decimal(10,2)) as test_days 
from (
select sys_code,name,id,test_end_time,
(hour(test_end_time)-hour(created)+datediff(test_end_time,created)*24) as jfzq,
(hour(dev_start_time)-hour(created)+datediff(dev_start_time,created)*24) as ddyfsc,
(hour(dev_end_time)-hour(dev_start_time)+datediff(dev_end_time,dev_start_time)*24) as yfsc,
(hour(test_start_time)-hour(dev_end_time)+datediff(test_start_time,dev_end_time)*24) as ddcssc,
(hour(test_end_time)-hour(test_start_time)+datediff(test_end_time,test_start_time)*24) as cssc 
from dm_gis_uimp.dwd_ti_rm_system_need where created is not null and created<>'' 
) as t group by sys_code,name 
;