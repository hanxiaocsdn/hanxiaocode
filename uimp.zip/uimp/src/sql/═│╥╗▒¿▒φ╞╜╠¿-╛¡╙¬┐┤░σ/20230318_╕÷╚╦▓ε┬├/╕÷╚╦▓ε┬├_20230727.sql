-- 
-- 
-- 需求方：林中莉(01423677)
-- 需求： id: 1786019  【经营看板专项】个人差旅招待明细表_数据侧_V1.9
-- @author 张小琼 （01416344）
-- Created on 2023-07-27
-- 任务信息： ID：683500  丰图个人差旅招待明细
-- 

-- 线上数据源
-- dm_gis_uimp ods_ft_ers_form_base_area_data	张小琼	详见3 数据统计方式	按照月度T-1	1.根据inc_day，取每月1日的记录 2.business_type in ('1000','1007','1004','FTKJRC10','FTKJRC04')
-- dm_gis_uimp ods_ft_ers_form_expense_area_data			按照月度T-1	1.根据inc_day，取每月1日的记录 2.business_type in ('1000','1007','1004','FTKJRC10','FTKJRC04')
-- dm_gis_uimp ods_plf_form_body			按照月度T-1	1.根据inc_day，取每月1日的记录 2.order_status等于'80','82','90','91','93'
-- dm_gis_uimp plf_form_account_detail			按照月度T-1	1.根据inc_day，取每月1日的记录 2.order_status等于'80','82','90','91','93'
-- dm_gis_uimp ods_issp_emp_data			T-1	无
-- dm_gis_uimp ods_issp_emp_data_ext			T-1	无
-- dm_gis_uimp ods_ft_emp_out			T-1	无
-- dm_gis_uimp ods_issp_org_data_virtual			T-1	无
-- dm_gis_uimp ods_issp_business_line			T-1	无
-- dm_gis_uimp ods_issp_org_data			T-1	org_name like ‘%丰图科技%’
-- dm_gis_uimp ods_pms_project			T-1	无
-- dm_gis_uimp dwd_crm_opp_res			T-1	无

-- 线下数据源
-- 1)招待费_团购礼品明细表
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_tuangou`(
order_no	string comment '订单号',
fy_date	string comment '费用所属期间',
company_name	string comment '购买公司名称',
trade_name	string comment '商品名称',
tax_rate	string comment '销项税率',
gift_number	string comment '数量',
unit_price	string comment '单价',
total_amount	string comment '结算总金额',
remark	string comment '备注',
job_no	string comment '需求人_工号',
full_name	string comment '需求人_姓名',
ssp2_dc	string comment '关联ssp2单据编号',
is_settle	string comment '是否无需结算',
no_settle_reason	string comment '无需结算原因',
project_code	string comment '项目代码'
)
COMMENT '招待费_团购礼品明细表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/招待费_团购礼品明细表_2023年2月1日提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_tuangou partition (inc_day='20230201');
LOAD DATA  INPATH '/user/01416344/upload/招待费_团购礼品明细表_2023年3月1日提供_45602_结算173507_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_tuangou partition (inc_day='20230301');
LOAD DATA  INPATH '/user/01416344/upload/招待费_团购礼品明细表_2023年4月1日提供_30498_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_tuangou partition (inc_day='20230401');
LOAD DATA  INPATH '/user/01416344/upload/招待费_团购礼品明细表_2023年5月12日提供_30498_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_tuangou partition (inc_day='20230512');
-- v1.5 替换
LOAD DATA  INPATH '/user/01416344/upload/招待费_团购礼品明细表_2023年2月1日提供_V1.1（待导入）.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_tuangou partition (inc_day='20230201');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/招待费_团购礼品明细表_2023年6月12日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_tuangou partition (inc_day='20230612');



-- 2)招待费_丰享礼品明细表
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_fengxiang`(
recon_system	string comment '对账系统',
order_no	string comment '订单号',
ext_order_no	string comment '外部订单号',
trans_serial_no	string comment '交易流水号',
trans_name	string comment '交易名称',
trans_time	string comment '交易时间',
pay_method	string comment '支付方式',
trans_amount	string comment '交易金额',
desens_account	string comment '脱敏账号',
job_no	string comment '交易账户_工号',
full_name	string comment '交易账户_姓名',
supplier	string comment '供应商',
bill_set	string comment '账套',
cost_center	string comment '成本中心',
order_status	string comment '订单状态',
bill_no	string comment '账单编号',
is_generate_bill	string comment '是否生成账单',
is_reconcile	string comment '是否对账',
reconcile_results	string comment '对账结果',
reconcile_exception	string comment '对账异常说明',
fy_date	string comment '费用所属期间',
ssp2_dc	string comment '关联ssp2单据编号',
is_settle	string comment '是否无需结算',
no_settle_reason	string comment '无需结算原因',
project_code	string comment '项目代码' 
)
COMMENT '招待费_丰享礼品明细表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/招待费_丰享礼品明细表_2023年2月1日提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_fengxiang partition (inc_day='20230201');
LOAD DATA  INPATH '/user/01416344/upload/招待费_丰享礼品明细表_2023年3月1日提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_fengxiang partition (inc_day='20230301');
LOAD DATA  INPATH '/user/01416344/upload/招待费_丰享礼品明细表_2023年4月1日提供_194488.4_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_fengxiang partition (inc_day='20230401');
LOAD DATA  INPATH '/user/01416344/upload/招待费_丰享礼品明细表_2023年5月12日提供_194488.4_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_fengxiang partition (inc_day='20230512');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/招待费_丰享礼品明细表_2023年6月12日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_fengxiang partition (inc_day='20230612');
-- 20230801 导入
LOAD DATA  INPATH '/user/01416344/upload/【待导入】招待费_丰享礼品明细表_2023年8月7日提供_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_fengxiang partition (inc_day='20230801');
-- 20230901 导入
LOAD DATA  INPATH '/user/01416344/upload/招待费_丰享礼品明细表_2023年9月6日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_fengxiang partition (inc_day='20230901');



-- 3)差旅费_外包差旅明细表
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_outsource`(
submit_dpt	string comment '提交人部门名称',
create_name	string comment '制单人名称',
is_allow_print	string comment '允许制单人和审批人打印节点标记',
is_only_creator_print	string comment '仅制单人打印单据',
appr_date	string comment '单据审核通过日期',
is_creator_print	string comment '制单人不可打印',
voucher_status	string comment '凭证状态',
voucher_generation_time	string comment '凭证生成时间',
print_cnt	string comment '打印次数/次',
print_status	string comment '打印状态',
last_printer	string comment '最后打印人名称',
last_print_time	string comment '最后打印时间',
legal	string comment '法人实体名称',
appr_status	string comment '审批状态',
template_name	string comment '单据模板名称',
odd_no	string comment '单号',
title	string comment '标题',
submitter_name	string comment '提交人名称',
submit_date	string comment '提交日期',
bear_dpt	string comment '费用承担部门名称',
reimburse_amount	string comment '报销金额',
reimburse_date	string comment '报销日期',
pay_amount	string comment '支付金额',
content_desc	string comment '描述',
application_name	string comment '关联申请名称',
job_no	string comment '员工工号',
project_code	string comment '项目代码',
region_name	string comment '所属大区名称',
bu_name	string comment '所属bu名称',
supplier	string comment '直属上级名称',
responsible_person_name	string comment '供应商负责人名称',
project_account_name	string comment '项目台账名称',
bu_1_name	string comment '经营单元1名称',
previous_time	string comment '前一节点审批时间',
ssp2_dc	string comment '关联ssp2单据编号',
is_settle	string comment '是否无需结算',
no_settle_reason	string comment '无需结算原因'
)
COMMENT '差旅费_外包差旅明细表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/差旅费_外包差旅明细表_2023年4月12日提供_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_outsource partition (inc_day='20230412');
LOAD DATA  INPATH '/user/01416344/upload/差旅费_外包差旅明细表_2023年5月12日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_outsource partition (inc_day='20230512');
-- v1.5 替换
LOAD DATA  INPATH '/user/01416344/upload/差旅费_外包差旅明细表_2023年4月12日提供_V1.2（待导入）.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_outsource partition (inc_day='20230412');
LOAD DATA  INPATH '/user/01416344/upload/差旅费_外包差旅明细表_2023年5月12日提供_V1.1（待导入）.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_outsource partition (inc_day='20230512');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/差旅费_外包差旅明细表_2023年6月12日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_outsource partition (inc_day='20230612');
-- 20230801 导入
LOAD DATA  INPATH '/user/01416344/upload/【待导入0809】202307外包差旅.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_outsource partition (inc_day='20230801');
-- 20230901 导入
LOAD DATA  INPATH '/user/01416344/upload/差旅费_外包差旅明细表_导入2023年9月7日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_outsource partition (inc_day='20230901');


-- 4) 差旅费_差旅房租明细表 v1.3版本
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_rental`(
company_code	string comment '公司代码',
year_month	string comment '年度/月份',
document_number 	string comment '凭证编号',
entry_text	string comment '文本',
general_ledger_amount	string comment '总帐金额',
project_code	string comment '项目代码',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
demander string comment '需求人'
)
COMMENT '差旅费_差旅房租明细表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/差旅费_差旅房租明细表_2023年3月12日提供_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_rental partition (inc_day='20230312');
LOAD DATA  INPATH '/user/01416344/upload/差旅费_差旅房租明细表_2023年4月12日提供_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_rental partition (inc_day='20230412');
LOAD DATA  INPATH '/user/01416344/upload/差旅费_差旅房租明细表_2023年5月12日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_rental partition (inc_day='20230512');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/差旅费_差旅房租明细表_2023年6月12日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_rental partition (inc_day='20230612');
-- 20230801 导入
LOAD DATA  INPATH '/user/01416344/upload/【待导入】差旅费_差旅房租明细表_导入2023年8月7日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_rental partition (inc_day='20230801');
-- 20230901 导入
LOAD DATA  INPATH '/user/01416344/upload/差旅费_差旅房租明细表_导入2023年9月7日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_rental partition (inc_day='20230901');




-- 5)ERS预提明细表
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_ers_withhold`(
document_number	string comment '单据编号',
project_code	string comment '项目代码',
company_code	string comment '公司代码',
applicant	string comment '申请人',
account_name	string comment '科目名称',
cost_center	string comment '成本中心',
amount_including_tax	string comment '含税金额',
entry_text	string comment '入账文本',
withhold_period	string comment '预提期间' 
)
COMMENT 'ERS预提明细表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/ERS预提明细表_2023年3月7日提供_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_ers_withhold partition (inc_day='20230307');
LOAD DATA  INPATH '/user/01416344/upload/ERS预提明细表_2023年4月7日提供_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_ers_withhold partition (inc_day='20230407');
LOAD DATA  INPATH '/user/01416344/upload/ERS预提明细表_2023年5月8日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_ers_withhold partition (inc_day='20230508');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/ERS预提明细表_2023年6月12日提供_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_ers_withhold partition (inc_day='20230612');
-- 20230801 导入
LOAD DATA  INPATH '/user/01416344/upload/ERS预提明细表_导入2023年8月4日_V1.1【已收集待导入】.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_ers_withhold partition (inc_day='20230801');
-- 20230901 导入
LOAD DATA  INPATH '/user/01416344/upload/ERS预提明细表_导入2023年9月6日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_ers_withhold partition (inc_day='20230901');



-- 6)机票对账报表
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_air`(
company_code	string comment '公司代码',
corporate_name	string comment '公司名称',
cost_center	string comment '成本中心',
cost_bearing_organization	string comment '费用承担组织',
project_code	string comment '项目代码',
keycustomer_code	string comment '大客户代码',
service_abbreviation	string comment '服务商简称',
ticket_type	string comment '机票类型',
passenger_id	string comment '乘客工号',
passenger_name	string comment '乘客姓名',
application_number	string comment '出差申请单号',
travel_category	string comment '出差类别',
service_provider	string comment '服务商',
order_number	string comment '订单号',
supplier_order_number	string comment '供应商订单号',
order_status	string comment '订单状态',
booking_type	string comment '预订类型',
ticket_number	string comment '票号',
ticket_time	string comment '出票/退票时间',
takeoff_time	string comment '起飞时间',
trip	string comment '行程',
ticket_price	string comment '票价',
ticket_tax	string comment '基建费/机票税',
fuel_cost	string comment '燃油费',
refund_fee	string comment '退票费',
rescheduling_fee	string comment '改期费',
price_difference	string comment '升舱费/差价',
rescheduling	string comment '改期手续费',
service_charge	string comment '服务费',
account_adjustment	string comment '调账',
total	string comment '合计',
platform_tag_status	string comment '平台标记状态',
bill_number	string comment '账单编号',
reconciliation_period	string comment '对账期',
billing_status	string comment '账单状态',
creation_labor_number	string comment '账单创建人工号',
creation_labor_name	string comment '账单创建人姓名',
reconciliation_org	string comment '对账组织',
creation_time	string comment '账单创建时间',
settlement_batch_number	string comment '结算批号',
settlement_batch_status	string comment '结算批状态',
create_uid	string comment '结算批创建人工号create_uid',
create_name	string comment '结算批创建人姓名create_name',
settlement_batch_creattime	string comment '结算批创建时间',
classification	string comment '分类' 
)
COMMENT '机票对账报表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/air_20230412.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_air partition (inc_day='20230412');
-- 新导入
LOAD DATA  INPATH '/user/01416344/upload/机票对账报表_2023年5月1日提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_air partition (inc_day='20230501');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/机票对账报表2023年6月提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_air partition (inc_day='20230601');
-- 2023801 导入
LOAD DATA  INPATH '/user/01416344/upload/【待导入】机票对账报表_导入2023年8月7日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_air partition (inc_day='20230801');
-- 2023901 导入
LOAD DATA  INPATH '/user/01416344/upload/机票对账报表_导入2023年9月7日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_air partition (inc_day='20230901');



-- 7)酒店对账报表
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_hotel`(
company_code	string comment '公司代码',
corporate_name	string comment '公司名称',
cost_center	string comment '成本中心',
cost_bearing_organization	string comment '费用承担组织',
project_code	string comment '项目代码',
keycustomer_code	string comment '大客户代码',
service_abbreviation	string comment '服务商简称',
hotel_type	string comment '酒店类型',
check_in_job_no	string comment '入住人工号',
check_in_person	string comment '入住人姓名',
application_number	string comment '出差申请单号',
travel_category	string comment '出差类别',
order_number	string comment '订单号',
supplier_order_number	string comment '供应商订单号',
order_status	string comment '订单状态',
confirm_cancel_time	string comment '确认/取消时间',
check_in_date	string comment '入住日期',
departure_date	string comment '离店日期',
hotel_name	string comment '酒店名称',
residing_city	string comment '入住城市',
nights	string comment '间夜数',
house_price	string comment '房价(元)',
cancellation_fee	string comment '取消费用(元)',
service_fee	string comment '服务费(元)',
account_adjustment	string comment '调账(元)',
total	string comment '合计',
platform_tag_status	string comment '平台标记状态',
bill_number	string comment '账单编号',
reconciliation_period	string comment '对账期',
billing_status	string comment '账单状态',
creation_labor_number	string comment '账单创建人工号',
creation_labor_name	string comment '账单创建人姓名',
reconciliation_org	string comment '对账组织',
creation_time	string comment '账单创建时间',
settlement_batch_number	string comment '结算批号',
settlement_batch_status	string comment '结算批状态',
create_uid	string comment '结算批创建人工号',
create_name	string comment '结算批创建人姓名',
settlement_batch_creattime	string comment '结算批创建时间',
classification	string comment '分类'
)
COMMENT '酒店对账报表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/hotel_20230412.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_hotel partition (inc_day='20230412');
-- 新导入
LOAD DATA  INPATH '/user/01416344/upload/酒店对账报表_2023年5月1日提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_hotel partition (inc_day='20230501');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/酒店对账报表2023年6月提供_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_hotel partition (inc_day='20230601');
-- 20230801 导入
LOAD DATA  INPATH '/user/01416344/upload/【待导入】酒店对账报表-_导入2023年8月2日_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_hotel partition (inc_day='20230801');
-- 20230901 导入
LOAD DATA  INPATH '/user/01416344/upload/酒店对账报表-_导入2023年9月7日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_hotel partition (inc_day='20230901');


-- 8)用车对账报表
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_car`(
company_code	string comment '公司代码',
corporate_name	string comment '公司名称',
cost_center	string comment '成本中心',
cost_bearing_organization	string comment '费用承担组织',
project_code	string comment '项目代码',
keycustomer_code	string comment '大客户代码',
service_abbreviation	string comment '服务商简称',
use_scenarios	string comment '用车场景',
passenger_id	string comment '乘客工号',
passenger_name	string comment '乘客姓名',
phone_number	string comment '乘客手机号',
application_number	string comment '出差申请单号',
travel_category	string comment '出差类别',
service_provider	string comment '服务商',
order_number	string comment '订单号',
supplier_order_number	string comment '供应商订单号',
order_status	string comment '订单状态',
start_time	string comment '开始时间',
end_time	string comment '结束时间',
departure	string comment '出发地',
destination	string comment '目的地',
vehicle_expenses	string comment '用车费用',
account_adjustment	string comment '调账',
platform_tag_status	string comment '平台标记状态',
bill_number	string comment '账单编号',
kilometers_traveled	string comment '行驶公里数',
vehicle_model	string comment '用车车型',
reason	string comment '乘车理由',
reconciliation_period	string comment '对账期',
billing_status	string comment '账单状态',
creation_labor_number	string comment '账单创建人工号',
creation_labor_name	string comment '账单创建人姓名',
reconciliation_org	string comment '对账组织',
creation_time	string comment '账单创建时间',
settlement_batch_number	string comment '结算批号',
settlement_batch_status	string comment '结算批状态',
create_uid	string comment '结算批创建人工号create_uid',
create_name	string comment '结算批创建人姓名create_name',
settlement_batch_creattime	string comment '结算批创建时间',
classification	string comment '分类'
)
COMMENT '用车对账报表'
PARTITIONED BY (`inc_day` string)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/car_20230412.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_car partition (inc_day='20230412');
-- 新导入
LOAD DATA  INPATH '/user/01416344/upload/用车对账报表_2023年5月1日提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_car partition (inc_day='20230501');
-- 20230613 导入
LOAD DATA  INPATH '/user/01416344/upload/用车对账报表2023年6月提供.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_car partition (inc_day='20230601');
-- 20230801 导入
LOAD DATA  INPATH '/user/01416344/upload/【待导入0814】用车对账报表_导入2023年8月7日_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_car partition (inc_day='20230801');
-- 20230901 导入
LOAD DATA  INPATH '/user/01416344/upload/用车对账报表_导入2023年9月7日_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_car partition (inc_day='20230901');



-- 项目代码所属业务中心
CREATE  TABLE `dm_gis_uimp.ods_personal_travel_ssywzx`(
field_cz768__c	string comment '所属业务中心代码',
ssywzx	string comment '所属业务中心'
)
COMMENT '项目代码所属业务中心映射表'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/所属业务中心映射_20230523.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_personal_travel_ssywzx;



----------------------------------------------

-- 取值场景1：差旅房租
CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_rent_act_amount`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
rent_act_amount string comment '差旅费_差旅房租_实际数'
)
COMMENT '差旅房租对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;

-- 取值场景1 差旅房租_实际数
insert overwrite table dm_gis_uimp.dwd_personal_travel_rent_act_amount partition(stat_month='$statMonth')
select demander,if(project_code is not null,project_code,'') as project_code,end_unit,end_line,general_ledger_amount from dm_gis_uimp.ods_personal_travel_rental where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','')
;

-- 取值场景2：ERS预提
CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_ers_acc_amount`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
cost_center	string comment '原单据的成本中心',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
entertain_ers_acc_amount	string comment '招待费_个人垫付费用_ers_预提数',
travel_ers_acc_amount	string comment '差旅费_个人垫付费用_ers_预提数' 
)
COMMENT 'ERS预提对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;


alter table dm_gis_uimp.dwd_personal_travel_ers_acc_amount add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dwd_personal_travel_ers_acc_amount change cost_center cost_center string after project_code;


-- -- 招待费_个人垫付费用_ERS_预提数 （业务招待费）
drop table if exists dm_gis_uimp.tmp_ers_entertainment_expenses;
create table dm_gis_uimp.tmp_ers_entertainment_expenses stored as parquet as 
select 
applicant,project_code,cost_center,sum(amount_including_tax) as amount_including_tax 
from (
select applicant,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,
amount_including_tax,withhold_period
from dm_gis_uimp.ods_personal_travel_ers_withhold where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and account_name='业务招待费' 
union all 
select applicant,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,
-amount_including_tax,withhold_period
from dm_gis_uimp.ods_personal_travel_ers_withhold where inc_day>=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-','')  and inc_day<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
and account_name='业务招待费' 
) as t group by applicant,project_code,cost_center   
;


-- -- 招待费_个人垫付费用_ERS_预提数 （差旅费）
drop table if exists dm_gis_uimp.tmp_ers_travel_expenses;
create table dm_gis_uimp.tmp_ers_travel_expenses stored as parquet as 
select 
applicant,project_code,cost_center,sum(amount_including_tax) as amount_including_tax 
from (
select applicant,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,
amount_including_tax,withhold_period
from dm_gis_uimp.ods_personal_travel_ers_withhold where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and account_name='差旅费' 
union all 
select applicant,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,
-amount_including_tax,withhold_period
from dm_gis_uimp.ods_personal_travel_ers_withhold where inc_day>=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-','')  and inc_day<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
and account_name='差旅费' 
) as t group by applicant,project_code,cost_center 
;

-- 
insert overwrite table dm_gis_uimp.dwd_personal_travel_ers_acc_amount partition(stat_month='$statMonth')
select applicant,project_code,cost_center,end_unit,end_line,entertain_ers_acc_amount,travel_ers_acc_amount  
from (
select 
if(t0.applicant is not null,t0.applicant,t1.applicant) as applicant,
if(t0.project_code is not null,t0.project_code,t1.project_code) as project_code,
if(t0.cost_center is not null,t0.cost_center,t1.cost_center) as cost_center,
if(t0.end_unit is not null,t0.end_unit,t1.end_unit) as end_unit,
if(t0.end_line is not null,t0.end_line,t1.end_line) as end_line,
entertain_ers_acc_amount,travel_ers_acc_amount 
from (select applicant,project_code,cost_center,'' as end_unit,'' as end_line,amount_including_tax as entertain_ers_acc_amount from dm_gis_uimp.tmp_ers_entertainment_expenses ) as t0 
full outer join (
select applicant,project_code,cost_center,'' as end_unit,'' as end_line,amount_including_tax as travel_ers_acc_amount from dm_gis_uimp.tmp_ers_travel_expenses ) as t1 
on t0.applicant=t1.applicant and t0.project_code=t1.project_code and t0.cost_center=t1.cost_center 
) as t
;




-- 取值场景3：ERS实际数_招待费
CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_entertain_ers_act_amount`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
cost_center	string comment '原单据的成本中心',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
entertain_ers_act_amount	string comment '招待费_个人垫付费用_ers_实际数' 
)
COMMENT 'ERS实际数_招待费对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;

alter table dm_gis_uimp.dwd_personal_travel_entertain_ers_act_amount add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dwd_personal_travel_entertain_ers_act_amount change cost_center cost_center string after project_code;

-- cost_center 取值逻辑
-- 根据ods_ft_ers_form_base_area_data的order_no关联ods_ft_ers_form_expense_area_data的order_no，
-- 取ods_ft_ers_form_expense_area_data表的cost_center字段。
-- 其中，会存在多个cost_center，需要分多行展示。
drop table if exists dm_gis_uimp.tmp_personal_travel_entertain_ers_act_amount;
create table dm_gis_uimp.tmp_personal_travel_entertain_ers_act_amount stored as parquet as 
select t0.order_no,job_no,project_code,if(cost_center is not null,cost_center,'') as cost_center,end_unit,end_line,tax_exclude_amount as entertain_ers_act_amount 
from (select order_no,apply_user as job_no,if(project_code is not null,project_code,'') as project_code,'' as end_unit,'' as end_line 
from dm_gis_uimp.ods_ft_ers_form_base_area_data 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
and business_type in ('FTKJRC04') 
and status_code in ('failPayDoc','finishDoc','paidDoc','payingDoc','refundDoc','refundingDoc','waitPayDoc') 
and (account_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and account_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd') ) 
) as t0 
left join (select order_no,cost_center,tax_exclude_amount from dm_gis_uimp.ods_ft_ers_form_expense_area_data 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
) as t1 
on t0.order_no=t1.order_no
;


drop table if exists dm_gis_uimp.tmp_personal_travel_entertain_ers_act_amount_1;
create table dm_gis_uimp.tmp_personal_travel_entertain_ers_act_amount_1 stored as parquet as 
select t3.order_no,job_no,project_code,if(cost_center is not null,cost_center,'') as cost_center,end_unit,end_line,-tax_exclude_amount as entertain_ers_act_amount 
from (select order_no,apply_user as job_no,if(project_code is not null,project_code,'') as project_code,'' as end_unit,'' as end_line  
from dm_gis_uimp.ods_ft_ers_form_base_area_data 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
and business_type in ('FTKJRC04') 
and status_code in ('invalidDoc') 
and (reversal_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and reversal_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd') ) 
and (account_time<add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) or account_time>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd') ) 
) as t3 
left join (select order_no,cost_center,tax_exclude_amount from dm_gis_uimp.ods_ft_ers_form_expense_area_data 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
) as t4 
on t3.order_no=t4.order_no 
;

-- 
insert overwrite table dm_gis_uimp.dwd_personal_travel_entertain_ers_act_amount partition(stat_month='$statMonth')
select job_no,project_code,cost_center,end_unit,end_line,sum(entertain_ers_act_amount) as  entertain_ers_act_amount 
from (
select job_no,project_code,cost_center,end_unit,end_line,entertain_ers_act_amount from dm_gis_uimp.tmp_personal_travel_entertain_ers_act_amount 
union all 
select job_no,project_code,cost_center,end_unit,end_line,entertain_ers_act_amount from dm_gis_uimp.tmp_personal_travel_entertain_ers_act_amount_1 
) as t group by job_no,project_code,cost_center,end_unit,end_line 
;





-- 取值场景4：ERS实际数_差旅费
-- 1.ods_ft_ers_form_base_area_data.business_type in ('1000','1007','1004','FTKJRC10') 
-- 2.且根据ods_ft_ers_form_expense_area_data的order_no关联ods_ft_ers_form_base_area_data。ods_ft_ers_form_base_area_data的status_code in ('failPayDoc','finishDoc','paidDoc','payingDoc','refundDoc','refundingDoc','waitPayDoc') 
-- 3.且根据ods_ft_ers_form_expense_area_data的order_no关联ods_ft_ers_form_base_area_data。ods_ft_ers_form_base_area_data的account_time字段符合“年度月份”跑数期间。
CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_travel_ers_act_amount`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
cost_center	string comment '原单据的成本中心',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
travel_ers_act_amount	string comment '差旅费_个人垫付费用_ers_实际数' 
)
COMMENT 'ERS实际数_差旅费对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;

alter table dm_gis_uimp.dwd_personal_travel_travel_ers_act_amount add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dwd_personal_travel_travel_ers_act_amount change cost_center cost_center string after project_code;

-- 
drop table if exists dm_gis_uimp.tmp_personal_travel_travel_ers_act_amount;
create table dm_gis_uimp.tmp_personal_travel_travel_ers_act_amount stored as parquet as 
select 
apply_user as job_no,project_code,if(cost_center is not null,cost_center,'') as cost_center,'' as end_unit,'' as end_line,tax_exclude_amount as travel_ers_act_amount
from 
(
select 
t1.apply_user,t1.project_code,t0.order_no,t0.cost_center,t0.tax_exclude_amount,t0.original_amount,t1.business_type,t1.status_code,t1.account_time  
from (
select 
order_no,cost_center,tax_exclude_amount,original_amount 
from 
dm_gis_uimp.ods_ft_ers_form_expense_area_data
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
) as t0 
left join (
select apply_user,if(project_code is not null,project_code,'') as project_code,order_no,business_type,status_code,account_time from dm_gis_uimp.ods_ft_ers_form_base_area_data 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd')  
and status_code in ('failPayDoc','finishDoc','paidDoc','payingDoc','refundDoc','refundingDoc','waitPayDoc') 
and business_type in ('1000','1007','1004','FTKJRC10')  
and (account_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and account_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd') ) 
  ) as t1 
on t0.order_no=t1.order_no
where t1.order_no is not null
) as t  
;

drop table if exists dm_gis_uimp.tmp_personal_travel_travel_ers_act_amount_1;
create table dm_gis_uimp.tmp_personal_travel_travel_ers_act_amount_1 stored as parquet as 
select 
apply_user as job_no,project_code,if(cost_center is not null,cost_center,'') as cost_center,'' as end_unit,'' as end_line,-tax_exclude_amount as travel_ers_act_amount
from 
(
select 
t1.apply_user,t1.project_code,t0.order_no,t0.cost_center,t0.tax_exclude_amount,t0.original_amount,t1.business_type,t1.status_code,t1.account_time  
from (
select 
order_no,cost_center,tax_exclude_amount,original_amount 
from 
dm_gis_uimp.ods_ft_ers_form_expense_area_data
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
) as t0 
left join (
select apply_user,if(project_code is not null,project_code,'') as project_code,order_no,business_type,status_code,account_time from dm_gis_uimp.ods_ft_ers_form_base_area_data 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd')  
and status_code in ('invalidDoc') 
and business_type in ('FTKJRC04')
and (reversal_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and reversal_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd') ) 
and (account_time<add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) or account_time>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd') ) 
  ) as t1 
on t0.order_no=t1.order_no
where t1.order_no is not null
) as tt 
;

insert overwrite table dm_gis_uimp.dwd_personal_travel_travel_ers_act_amount partition(stat_month='$statMonth')
select 
job_no,project_code,cost_center,end_unit,end_line,sum(travel_ers_act_amount) as travel_ers_act_amount 
from (
select job_no,project_code,cost_center,'' as end_unit,'' as end_line,travel_ers_act_amount
from dm_gis_uimp.tmp_personal_travel_travel_ers_act_amount 
union all 
select job_no,project_code,cost_center,'' as end_unit,'' as end_line,travel_ers_act_amount
from dm_gis_uimp.tmp_personal_travel_travel_ers_act_amount_1
) as ttt group by job_no,project_code,cost_center,end_unit,end_line 
;





-- 取值场景5：礼品、外包差旅_实际数
-- 1.历史所有导入的线下文件“招待费_团购礼品明细表”和“招待费_丰享礼品明细表”中：
-- ①“关联SSP2单据编号”字段不为空，且在ods_plf_form_body表的order_no字段里存在。
-- ②且ods_plf_form_body表的posting_time字段属于本期跑的期间
-- 20230727 v1.9
-- ②且ods_plf_form_body表的posting_time或audit_finish_time字段属于本期跑的期间，
-- 优先根据posting_time判断，如果posting_time为空则根据audit_finish_time判断

CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
cost_center	string comment '原单据的成本中心',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
gifts_act_amount	string comment '招待费_礼品_实际数',
outsource_act_amount	string comment '差旅费_外包差旅_实际数' 
)
COMMENT '礼品、外包差旅_实际数对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;

alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount change cost_center cost_center string after project_code;

-- 礼品
-- 实际数 
drop table if exists dm_gis_uimp.tmp_gifts_act_amount;
create table dm_gis_uimp.tmp_gifts_act_amount stored as parquet as 
select 
t0.order_no,t0.posting_time,t0.inc_day,
t1.job_no,t1.project_code,t1.cost_center,t1.amount,t1.ssp2_dc,t1.is_settle,t1.fy_date  
from (
select order_no,posting_time,audit_finish_time,inc_day from dm_gis_uimp.ods_plf_form_body 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
and  (
  (posting_time<>'' and posting_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and posting_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd')) 
or (posting_time is null or posting_time='') and (audit_finish_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and audit_finish_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd')) 
)
) as t0 
left join ( 
select job_no,if(project_code is not null,project_code,'') as project_code,'' as cost_center,total_amount as amount,ssp2_dc,is_settle,fy_date from  dm_gis_uimp.ods_personal_travel_tuangou 
where ssp2_dc is not null and ssp2_dc<>'' 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,cost_center,trans_amount as amount,ssp2_dc,is_settle,fy_date from  dm_gis_uimp.ods_personal_travel_fengxiang 
where ssp2_dc is not null and ssp2_dc<>''  ) as t1 
on t0.order_no=t1.ssp2_dc
where t1.ssp2_dc is not null
;

-- 外包差旅
-- ods_plf_form_body 表的 posting_time 字段属于“年度月份”
-- 取 plf_form_account_detail 中(foreign_money-security_deposit_money)/security_deposit_money
-- 实际数
drop table if exists dm_gis_uimp.tmp_outsource_act_amount_1;
create table dm_gis_uimp.tmp_outsource_act_amount_1 stored as parquet as 
select 
t0.order_no,t0.posting_time,t0.inc_day,
t1.job_no,t1.project_code,t1.cost_center,t1.amount,t1.ssp2_dc,t1.is_settle  
from (
select order_no,posting_time,inc_day from dm_gis_uimp.ods_plf_form_body 
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') 
and  (
  (posting_time<>'' and posting_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and posting_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd')) 
or (posting_time is null or posting_time='') and (audit_finish_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and audit_finish_time<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd')) 
)
) as t0 
left join ( select job_no,if(project_code is not null,project_code,'') as project_code,bear_dpt as cost_center,pay_amount as amount,ssp2_dc,is_settle 
from  dm_gis_uimp.ods_personal_travel_outsource 
where ssp2_dc is not null and ssp2_dc<>'' 
) as t1 
on t0.order_no=t1.ssp2_dc
where t1.ssp2_dc is not null 
;

drop table if exists dm_gis_uimp.tmp_outsource_act_amount_2;
create table dm_gis_uimp.tmp_outsource_act_amount_2 as 
select 
t0.order_no,avg_rate,t0.inc_day,
t1.job_no,t1.project_code,t1.cost_center,t1.amount,t1.ssp2_dc,t1.is_settle  
from (
select order_no,(sum(foreign_money)-sum(security_deposit_money))/sum(security_deposit_money) as avg_rate,inc_day from dm_gis_uimp.ods_plf_form_account_detail  
where inc_day=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') group by order_no,inc_day ) as t0 
left join ( select order_no,job_no,project_code,cost_center,amount,ssp2_dc,is_settle from  dm_gis_uimp.tmp_outsource_act_amount_1  
) as t1  
on t0.order_no=t1.order_no
where t1.order_no is not null 
;

drop table if exists dm_gis_uimp.tmp_outsource_act_amount_3;
create table dm_gis_uimp.tmp_outsource_act_amount_3 as 
select order_no,job_no,project_code,cost_center,amount/(1+avg_rate) as amount from dm_gis_uimp.tmp_outsource_act_amount_2 as t0 
;


insert overwrite table dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount partition(stat_month='$statMonth')
select if(t0.job_no is not null,t0.job_no,t1.job_no) as job_no,
if(t0.project_code is not null,t0.project_code,t1.project_code) as project_code,
if(t0.cost_center is not null,t0.cost_center,t1.cost_center) as cost_center,
if(t0.end_unit is not null,t0.end_unit,t1.end_unit) as end_unit,
if(t0.end_line is not null,t0.end_line,t1.end_line) as end_line,
gifts_act_amount,outsource_act_amount from (
select job_no,if(project_code is not null,project_code,'') as project_code,
if(cost_center is not null,cost_center,'') as cost_center,
'' as end_unit,'' as end_line,sum(amount) as gifts_act_amount 
from dm_gis_uimp.tmp_gifts_act_amount group by job_no,project_code,cost_center ) as t0 
full outer join (
select job_no,if(project_code is not null,project_code,'') as project_code,
if(cost_center is not null,cost_center,'') as cost_center,
'' as end_unit,'' as end_line,sum(amount) as outsource_act_amount  
from dm_gis_uimp.tmp_outsource_act_amount_3 group by job_no,project_code,cost_center ) as t1 
on t0.job_no=t1.job_no and t0.project_code=t1.project_code  and t0.cost_center=t1.cost_center
;


-- 取值场景6：礼品、外包差旅_预提、无需结算
CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_gifts_outsource_acc_amount`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
cost_center	string comment '原单据的成本中心',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
gifts_acc_amount_no_settlement	string comment '招待费_礼品_预提数_无需结算',
gifts_acc_amount	string comment '招待费_礼品_预提数',
outsource_acc_amount_no_settlement	string comment '差旅费_外包差旅_预提_无需结算',
outsource_acc_amount	string comment '差旅费_外包差旅_预提数' 
)
COMMENT '礼品、外包差旅_预提、无需结算对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;

alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_acc_amount add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_acc_amount change cost_center cost_center string after project_code;


-- 礼品
-- 无需结算
drop table if exists dm_gis_uimp.tmp_gifts_acc_amount_no_settlement;
create table dm_gis_uimp.tmp_gifts_acc_amount_no_settlement as 
select job_no,if(project_code is not null,project_code,'') as project_code,
'' as cost_center,
total_amount as amount,ssp2_dc,is_settle,fy_date from  dm_gis_uimp.ods_personal_travel_tuangou 
where (ssp2_dc is null or ssp2_dc='') and is_settle='是' and inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','')
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,
if(cost_center is not null,cost_center,'') as cost_center,
trans_amount as amount,ssp2_dc,is_settle,fy_date from  dm_gis_uimp.ods_personal_travel_fengxiang 
where (ssp2_dc is null or ssp2_dc='') and is_settle='是' and inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
;

-- 预提数 
drop table if exists dm_gis_uimp.tmp_gifts_acc_amount;
create table dm_gis_uimp.tmp_gifts_acc_amount as 
select 
job_no,project_code,cost_center,sum(amount) as amount  
from 
(
select job_no,if(project_code is not null,project_code,'') as project_code,
'' as cost_center,
total_amount as amount from  dm_gis_uimp.ods_personal_travel_tuangou 
where (ssp2_dc is null or ssp2_dc='') and inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','')
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,
if(cost_center is not null,cost_center,'') as cost_center,
trans_amount as amount from  dm_gis_uimp.ods_personal_travel_fengxiang 
where (ssp2_dc is null or ssp2_dc='') and inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
-- 20230810 去掉本期间的实际数
-- union all 
-- select job_no,if(project_code is not null,project_code,'') as project_code,
-- cost_center,
-- -gifts_act_amount as amount from dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount where  stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) and gifts_act_amount is not null  
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,
cost_center,
-amount as amount from dm_gis_uimp.tmp_gifts_acc_amount_no_settlement 
) as t
group by job_no,project_code,cost_center
;

-- 外包差旅
-- 无需结算
drop table if exists dm_gis_uimp.tmp_outsource_act_amount_no_settlement;
create table dm_gis_uimp.tmp_outsource_act_amount_no_settlement as 
select job_no,project_code,bear_dpt as cost_center,pay_amount as amount,ssp2_dc,is_settle from  dm_gis_uimp.ods_personal_travel_outsource 
where (ssp2_dc is null or ssp2_dc='')  and is_settle='是' and inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
;

-- 预提数 
drop table if exists dm_gis_uimp.tmp_outsource_acc_amount;
create table dm_gis_uimp.tmp_outsource_acc_amount as 
select 
job_no,project_code,cost_center,sum(amount) as amount  
from 
(
select job_no,if(project_code is not null,project_code,'') as project_code,bear_dpt as cost_center,pay_amount as amount from  dm_gis_uimp.ods_personal_travel_outsource where (ssp2_dc is null or ssp2_dc='') and inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','')
-- 20230810 去掉本期间的实际数
-- union all 
-- select job_no,if(project_code is not null,project_code,'') as project_code,cost_center,-outsource_act_amount as amount from dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount where  stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) and outsource_act_amount is not null
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,cost_center,-amount from dm_gis_uimp.tmp_outsource_act_amount_no_settlement
) as t
group by job_no,project_code,cost_center 
;


drop table if exists dm_gis_uimp.tmp_personal_travel_gifts_outsource_jobno;
create table dm_gis_uimp.tmp_personal_travel_gifts_outsource_jobno as 
select job_no,project_code,cost_center from (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center  from dm_gis_uimp.tmp_gifts_acc_amount_no_settlement 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.tmp_gifts_acc_amount 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.tmp_outsource_act_amount_no_settlement 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.tmp_outsource_acc_amount 
) as t group by job_no,project_code,cost_center 
;

insert overwrite table dm_gis_uimp.dwd_personal_travel_gifts_outsource_acc_amount partition(stat_month='$statMonth')
select t0.job_no,t0.project_code,t0.cost_center,'' as end_unit,'' as end_line,
gifts_acc_amount_no_settlement,gifts_acc_amount,outsource_acc_amount_no_settlement,outsource_acc_amount from dm_gis_uimp.tmp_personal_travel_gifts_outsource_jobno as t0 
left join  (select job_no,project_code,cost_center,sum(amount) as gifts_acc_amount_no_settlement from dm_gis_uimp.tmp_gifts_acc_amount_no_settlement group by job_no,project_code,cost_center) as t1 
on t0.job_no=t1.job_no and t0.project_code=t1.project_code and t0.cost_center=t1.cost_center 
left join  (select job_no,project_code,cost_center,amount as gifts_acc_amount from dm_gis_uimp.tmp_gifts_acc_amount ) as t2 
on t0.job_no=t2.job_no  and t0.project_code=t2.project_code and t0.cost_center=t2.cost_center 
left join  (select job_no,project_code,cost_center,sum(amount) as outsource_acc_amount_no_settlement from dm_gis_uimp.tmp_outsource_act_amount_no_settlement group by job_no,project_code,cost_center) as t3 
on t0.job_no=t3.job_no  and t0.project_code=t3.project_code and t0.cost_center=t3.cost_center  
left join  (select job_no,project_code,cost_center,amount as outsource_acc_amount from dm_gis_uimp.tmp_outsource_acc_amount ) as t4 
on t0.job_no=t4.job_no  and t0.project_code=t4.project_code and t0.cost_center=t4.cost_center  
;

-- 取值场景7：机票酒店用车_实际数
CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_act`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
cost_center	string comment '原单据的成本中心',
air_hotel_car_act_amount	string comment '机票酒店用车_实际数' 
)
COMMENT '机票酒店用车_实际数对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;

alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_act add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_act change cost_center cost_center string after project_code;

-- 差旅费_机票酒店用车_实际数
drop table if exists dm_gis_uimp.tmp_personal_travel_air_act;
create table dm_gis_uimp.tmp_personal_travel_air_act stored as parquet as 
select passenger_id,project_code,cost_center,total from (
select passenger_id,if(project_code is not null,project_code,'') as project_code, 
if(cost_center is not null,cost_center,'') as cost_center,
if( (settlement_batch_creattime>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and settlement_batch_creattime<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd')) 
and settlement_batch_status in ('记账成功','冲销失败','付款成功','付款失败') and travel_category in ('一般出差','历练出差','顺航外派','顺航监修监改','国际一般出差','国际历练出差','长期出差'),total,0) as  total  
from dm_gis_uimp.ods_personal_travel_air 
where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and classification='实际数'   
) as t where  total<>0 
;


drop table if exists dm_gis_uimp.tmp_personal_travel_hotel_act;
create table dm_gis_uimp.tmp_personal_travel_hotel_act stored as parquet as 
select check_in_job_no,project_code,cost_center,total from (
select check_in_job_no,if(project_code is not null,project_code,'') as project_code,
if(cost_center is not null,cost_center,'') as cost_center,
if( (settlement_batch_creattime>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and settlement_batch_creattime<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd')) 
and settlement_batch_status in ('记账成功','冲销失败','付款成功','付款失败') and travel_category in ('一般出差','历练出差','顺航外派','顺航监修监改','国际一般出差','国际历练出差','长期出差'),total,0) as  total    
from dm_gis_uimp.ods_personal_travel_hotel 
where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and classification='实际数' 
) as t where  total<>0 
;

drop table if exists dm_gis_uimp.tmp_personal_travel_car_act;
create table dm_gis_uimp.tmp_personal_travel_car_act stored as parquet as 
select passenger_id,project_code,cost_center,vehicle_expenses from (
select passenger_id,if(project_code is not null,project_code,'') as project_code,
if(cost_center is not null,cost_center,'') as cost_center, 
if( (settlement_batch_creattime>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1) and settlement_batch_creattime<from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd')) 
and settlement_batch_status in ('记账成功','冲销失败','付款成功','付款失败') and travel_category in ('一般出差','历练出差','顺航外派','顺航监修监改','国际一般出差','国际历练出差','长期出差'),vehicle_expenses,0) as  vehicle_expenses   
from dm_gis_uimp.ods_personal_travel_car 
where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and classification='实际数' 
) as t where  vehicle_expenses<>0 
;

insert overwrite table dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_act partition(stat_month='$statMonth') 
select passenger_id as job_no,project_code,cost_center,total as air_hotel_car_act_amount   
from (
select passenger_id,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,total from dm_gis_uimp.tmp_personal_travel_air_act 
union all 
select check_in_job_no as passenger_id,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,total from dm_gis_uimp.tmp_personal_travel_hotel_act 
union all 
select passenger_id,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,vehicle_expenses as total from dm_gis_uimp.tmp_personal_travel_car_act 
) as t 
;



-- 取值场景8：机票酒店用车_预提数
-- 1.分类为“预提数”
-- 2.且各对账报表的导入时间为本月
-- 3.且“用车场景”不包含文案“公务”或者“加班”
-- 4.且“出差类别”为：一般出差、历练出差、顺航外派、顺航监修监改、国际一般出差、国际历练出差、长期出差。
CREATE  TABLE `dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_acc`(
job_no	string comment '员工工号',
project_code	string comment '项目代码',
cost_center	string comment '原单据的成本中心',
air_hotel_car_acc_amount	string comment '机票酒店用车_预提数' 
)
COMMENT '机票酒店用车_预提数对账报表'
PARTITIONED BY (`stat_month` string comment '统计月份')
;

alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_acc add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_acc change cost_center cost_center string after project_code;

-- 差旅费_机票酒店用车_预提数
insert overwrite table dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_acc partition(stat_month='$statMonth') 
select 
passenger_id as job_no,project_code,cost_center,total as air_hotel_car_acc_amount 
from (
select passenger_id,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,total  from dm_gis_uimp.ods_personal_travel_air 
where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and classification='预提数' and travel_category in ('一般出差','历练出差','顺航外派','顺航监修监改','国际一般出差','国际历练出差','长期出差')
union all 
select check_in_job_no as passenger_id,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,total from dm_gis_uimp.ods_personal_travel_hotel 
where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and classification='预提数' and travel_category in ('一般出差','历练出差','顺航外派','顺航监修监改','国际一般出差','国际历练出差','长期出差')
union all 
select passenger_id,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,vehicle_expenses as total  from dm_gis_uimp.ods_personal_travel_car 
where inc_day>=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMMdd') and inc_day<replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),1),'-','') 
and classification='预提数' and use_scenarios not in ('公务用车','加班用车') and travel_category in ('一般出差','历练出差','顺航外派','顺航监修监改','国际一般出差','国际历练出差','长期出差')
) as t 
;



-- 取值场景9：（除差旅房租外）最终确认的经营单元、业务线  (没有增加“除差旅房租外”这个处理逻辑，业务可导出后手动修改)
CREATE  TABLE `dm_gis_uimp.dws_personal_travel_receive_detail`(
job_no	string comment '员工工号',
project_code string comment '项目代码',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
emp_name	string comment '员工姓名',
position_name	string comment '员工职位名称',
org_name	string comment '员工所属组织',
bu_line	string comment '所属业务线',
bu_unit	string comment '所属经营单元',
cost	string comment '员工成本中心',
hire_date	string comment '员工入职日期',
leave_date	string comment '员工离职日期',
emp_type	string comment '员工类型',
entertain_ers_act_amount	string comment '招待费_个人垫付费用_ers_实际数',
entertain_ers_acc_amount	string comment '招待费_个人垫付费用_ers_预提数',
gifts_act_amount	string comment '招待费_礼品_实际数',
gifts_acc_amount_no_settlement	string comment '招待费_礼品_预提数_无需结算',
gifts_acc_amount	string comment '招待费_礼品_预提数',
outsource_act_amount	string comment '差旅费_外包差旅_实际数',
outsource_acc_amount_no_settlement	string comment '差旅费_外包差旅_预提_无需结算',
outsource_acc_amount	string comment '差旅费_外包差旅_预提数',
rent_act_amount	string comment '差旅费_差旅房租_实际数',
travel_ers_act_amount	string comment '差旅费_个人垫付费用_ers_实际数',
travel_ers_acc_amount	string comment '差旅费_个人垫付费用_ers_预提数',
air_hotel_car_act_amount		string comment '差旅费_机票酒店用车_实际数',
air_hotel_car_acc_amount		string comment '差旅费_机票酒店用车_预提数',
is_cost		string comment '本期间是否发生差旅招待费',
project_name	string comment '项目名称',
project_unit	string comment '项目所属经营单元',
project_line	string comment '项目所属业务线',
project_type	string comment '项目类型',
cost_center	string comment '原单据的成本中心',
is_rent  string comment '是否差旅房租'
)
COMMENT '丰图个人差旅招待明细表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

alter table dm_gis_uimp.dws_personal_travel_receive_detail add columns (cost_center	string comment '原单据的成本中心') CASCADE;
alter table dm_gis_uimp.dws_personal_travel_receive_detail add columns (is_rent  string comment '是否差旅房租') CASCADE;

-- 一、数据准备
-- 1.当前报表字段：员工所属业务线、员工所属组织、项目代码
-- 2.ods_pms_project表的项目代码code、业务中心title_d、项目类型name_m、项目名称title_a。
-- 3.dwd_crm_opp_res表的项目代码field_kvx2b__c、业务中心field_0d6eG__c、项目名称name。
-- 4.ods_issp_org_data_virtual表的业务线编码line_code、经营单元编码unit_id、成本中心kostl
-- 5.ods_issp_business_line表的业务线编码line_code、业务线名称line_name
-- 6.ods_issp_org_data表的org_id、组织简称stext

-- 二、准备虚拟组织架构表
-- 1.ods_issp_org_data_virtual表增加字段line_name、unit_name、is_valid
-- (1)根据ods_issp_org_data_virtual.unit_id关联ods_issp_org_data.org_id，unit_name取ods_issp_org_data.stext的值、is_valid取ods_issp_org_data.is_valid的值。
-- (2)根据ods_issp_org_data_virtual.unit_id关联联ods_issp_business_line.line_code，line_name取ods_issp_business_line.line_name的值。

-- 三、准备项目类型、项目所属业务线、所属业务中心
-- 1.根据项目代码分别关联dwd_crm_opp_res.field_kvx2b__c和ods_pms_project.code，
-- (1)取ods_pms_project.title_d，定义为项目所属业务中心；
-- (2)直接取dwd_crm_opp_res.field_0d6eG__c，定义为项目所属业务中心；
-- (3)取ods_pms_project.name_m，定义为项目类型。
-- (4)取dwd_crm_opp_res.name和ods_pms_project.title_a，定义为项目名称；
-- 2.根据项目所属业务中心 关联虚拟组织架构表的unit_name，取line_name，定义为项目所属业务线。

-- 四、（除差旅房租外）取最终确认的经营单元、最终确认的业务线
-- 1.定义费用承担部门、费用承担业务线编码、费用承担经营单元名称
-- (1)费用承担部门优先取“原单据的成本中心”字段，如果它为空，则取“员工成本中心”字段
-- (2)根据费用承担部门 匹配虚拟组织架构表ods_issp_org_data_virtual的kostl字段。当is_valid等于Y，取line_code的值，定义为费用承担业务线；取unit_name的值，定义为费用承担经营单元名称。
-- 2.判断最终确认的经营单元
-- (1)如果费用承担部门 等于SF05673，则最终确认的经营单元 赋值“大区业务中心”；
-- (2)如果费用承担部门 不等于SF05673 并且 line_code=1004或1003，则最终确认的经营单元取“费用承担经营单元名称”字段。
-- (3)除此之外，最终确认的经营单元 优先取“项目所属业务中心”字段；如果它为空，则取“费用承担经营单元名称”字段。
-- 3.判断最终确认的业务线：根据最终确认的经营单元 关联虚拟组织架构表的unit_name，取line_name，定义为最终确认的业务线。

-- 五、（仅差旅房租外）取最终确认的经营单元、最终确认的业务线
-- 取导入文件《差旅费_差旅房租明细表》的“最终确认的经营单元、最终确认的业务线”字段。


drop table if exists dm_gis_uimp.tmp_ft_emp_out_line_name_stext;
create table dm_gis_uimp.tmp_ft_emp_out_line_name_stext stored as parquet as 
select emp_num,name,position_name_cn,org_name,org_id_in,cost,entry_date,termination_date,t1.line_code,t1.kostl,t2.line_name,t3.stext from dm_gis_uimp.ods_ft_emp_out as t0 
left join (select org_id,line_code,unit_id,kostl from dm_gis_uimp.ods_issp_org_data_virtual) as t1 
on t0.org_id_in=t1.org_id 
left join (select line_code,line_name from dm_gis_uimp.ods_issp_business_line) as t2 
on t1.line_code=t2.line_code 
left join (select org_id,stext from dm_gis_uimp.ods_issp_org_data ) as t3 
on t1.unit_id=t3.org_id 
;

drop table if exists dm_gis_uimp.tmp_issp_emp_data_line_name_stext;
create table dm_gis_uimp.tmp_issp_emp_data_line_name_stext stored as parquet as 
select emp_num,emp_name,position_name,org_name,t0.org_id,hire_date,t1.line_code,t1.kostl,t2.line_name,t3.stext from dm_gis_uimp.ods_issp_emp_data as t0 
left join (select org_id,line_code,unit_id,kostl from dm_gis_uimp.ods_issp_org_data_virtual) as t1 
on t0.org_id=t1.org_id 
left join (select line_code,line_name from dm_gis_uimp.ods_issp_business_line) as t2 
on t1.line_code=t2.line_code 
left join (select org_id,stext from dm_gis_uimp.ods_issp_org_data ) as t3 
on t1.unit_id=t3.org_id 
;

drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_all;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_all stored as parquet as 
select job_no,project_code from (
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_rent_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_ers_acc_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_entertain_ers_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_travel_ers_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_gifts_outsource_acc_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_act where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code from dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_acc where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
) as t group by job_no,project_code
;

drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_all_org;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_all_org stored as parquet as 
select 
t0.job_no,t0.project_code,
if(t3.zhrzzqc is not null,t3.zhrzzqc,t1.org_name) as org_name,
if(t2.line_code is not null,t2.line_code,t1.line_code) as line_code,
if(t2.line_name is not null,t2.line_name,t1.line_name) as bu_line,
if(t2.stext is not null,t2.stext,t1.stext) as bu_unit 
from dm_gis_uimp.tmp_personal_travel_job_project_code_all as t0  
left join (select emp_num,name,position_name_cn,org_name,org_id_in,cost,entry_date,termination_date,line_code,line_name,stext from dm_gis_uimp.tmp_ft_emp_out_line_name_stext ) as t1 
on t0.job_no=t1.emp_num 
left join (select emp_num,emp_name,position_name,org_name,org_id,hire_date,line_code,line_name,stext from dm_gis_uimp.tmp_issp_emp_data_line_name_stext ) as t2 
on t0.job_no=t2.emp_num 
left join (select emp_num,zhrzzqc from dm_gis_uimp.ods_issp_emp_data_ext where zhrzzqc like '%丰图科技%' and zhrzzqc<>'' group by emp_num,zhrzzqc) as t3 
on t0.job_no=t3.emp_num
;



-- 二、准备虚拟组织架构表
drop table if exists dm_gis_uimp.tmp_personal_travel_data_virtual;
create table dm_gis_uimp.tmp_personal_travel_data_virtual stored as parquet as 
select t0.line_code,unit_id,line_name,stext as unit_name,is_valid,kostl from dm_gis_uimp.ods_issp_org_data_virtual  as t0 
left join ( select org_id,stext,is_valid from dm_gis_uimp.ods_issp_org_data where stext is not null  group by  org_id,stext,is_valid) as t1 
on t0.unit_id=t1.org_id 
left join ( select line_code,line_name from dm_gis_uimp.ods_issp_business_line where line_name is not null group by line_code,line_name ) as t2 
on t0.line_code=t2.line_code
;

-- 三、准备项目类型、项目所属业务线、所属业务中心
-- 1.根据项目代码分别关联dwd_crm_opp_res.field_kvx2b__c和ods_pms_project.code 
drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_1;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_1 stored as parquet as 
select t0.job_no,t0.project_code,org_name,line_code,bu_line,bu_unit,title_d,field_0d6eG__c,name_m,title_a,name  from dm_gis_uimp.tmp_personal_travel_job_project_code_all_org as t0 
left join ( select field_kvx2b__c,field_cz768__c,field_0d6eG__c,name from dm_gis_uimp.dwd_crm_opp_res group by field_kvx2b__c,field_cz768__c,field_0d6eG__c,name) as t1 
on t0.project_code=t1.field_kvx2b__c 
left join ( select code,title_d,name_m,title_a from dm_gis_uimp.ods_pms_project group by code,title_d,name_m,title_a) as t2 
on t0.project_code=t2.code 
;

-- 2.根据项目所属业务中心 关联虚拟组织架构表的unit_name，取line_name，定义为项目所属业务线。
drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_2;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_2 stored as parquet as 
select job_no,project_code,org_name,t0.line_code,bu_line,bu_unit,title_d,name_m,title_a,t1.line_code as t1_line_code,t1.line_name as t1_line_name from 
(select job_no,project_code,org_name,line_code,bu_line,bu_unit,if(title_d is not null,title_d,field_0d6eG__c) as title_d,name_m,if(name is not null,name,title_a) as title_a  
from dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_1) as t0 
left join ( select unit_name,line_name,line_code  from dm_gis_uimp.tmp_personal_travel_data_virtual group by unit_name,line_name,line_code ) as t1 
on t0.title_d=t1.unit_name
;


-- 四、（除差旅房租外）取最终确认的经营单元、最终确认的业务线
-- 1.定义费用承担部门、费用承担业务线编码、费用承担经营单元名称
-- (1)费用承担部门优先取“原单据的成本中心”字段，如果它为空，则取“员工成本中心”字段
-- (2)根据费用承担部门 匹配虚拟组织架构表ods_issp_org_data_virtual的kostl字段。当is_valid等于Y，取line_code的值，定义为费用承担业务线；取unit_name的值，定义为费用承担经营单元名称。
-- 2.判断最终确认的经营单元
-- (1)如果费用承担部门 等于SF05673，则最终确认的经营单元 赋值“大区业务中心”；
-- (2)如果费用承担部门 不等于SF05673 并且 line_code=1004或1003，则最终确认的经营单元取“费用承担经营单元名称”字段。
-- (3)除此之外，最终确认的经营单元 优先取“项目所属业务中心”字段；如果它为空，则取“费用承担经营单元名称”字段。
-- 3.判断最终确认的业务线：根据最终确认的经营单元 关联虚拟组织架构表的unit_name，取line_name，定义为最终确认的业务线。
drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_center;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_center stored as parquet as 
select job_no,project_code,cost_center from (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.dwd_personal_travel_ers_acc_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.dwd_personal_travel_entertain_ers_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.dwd_personal_travel_travel_ers_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.dwd_personal_travel_gifts_outsource_acc_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_act where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
union all 
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center from dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_acc where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) 
) as t group by job_no,project_code,cost_center
;

drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_bm;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_bm  stored as parquet as 
select 
job_no,project_code,cost_center,if(cost_center is not null and cost_center<>'',cost_center,cost) as cost_bm 
from (
select 
job_no,project_code,cost_center,if(t1.cost is not null and t1.cost<>'',t1.cost,t2.kostl) as cost 
from dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_center as t0 
left join (select emp_num,name,position_name_cn,org_name,org_id_in,cost,entry_date,termination_date,line_name,stext from dm_gis_uimp.tmp_ft_emp_out_line_name_stext ) as t1
on t0.job_no=t1.emp_num 
left join (select emp_num,kostl,leave_date from dm_gis_uimp.ods_issp_emp_data_ext ) as t2 
on t0.job_no=t2.emp_num 
) as t 
;

drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_bm_1;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_bm_1  stored as parquet as 
select 
t0.job_no,t0.project_code,cost_center,cost_bm,title_d,is_valid,line_code as cost_ywx,unit_name as cost_jydymc 
from dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_bm as t0 
left join (select kostl,line_code,unit_name,is_valid from dm_gis_uimp.tmp_personal_travel_data_virtual group by kostl,line_code,unit_name,is_valid ) as t1 
on t0.cost_bm=t1.kostl
left join (select job_no,project_code,title_d from dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_2 group by job_no,project_code,title_d ) as t2 
on t0.job_no=t2.job_no and t0.project_code=t2.project_code
;

drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit  stored as parquet as
select job_no,project_code,cost_center,cost_bm,end_unit,line_name as end_line 
from (
select  
job_no,project_code,cost_center,cost_bm,
case when cost_bm REGEXP 'SF05673' then '大区业务中心' 
     when cost_bm NOT REGEXP 'SF05673' and cost_ywx in ('1003','1004') then cost_jydymc 
     when title_d<>'' then title_d 
     else cost_jydymc end  as end_unit 
from dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit_cost_bm_1
) as t0 
left join (select line_code,unit_id,line_name,unit_name,is_valid from dm_gis_uimp.tmp_personal_travel_data_virtual group by line_code,unit_id,line_name,unit_name,is_valid) as t1 
on t0.end_unit=t1.unit_name 
;



-- 项目所属经营单元、项目业务线、项目类型、项目名称
drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_3;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_3 stored as parquet as 
select t0.job_no,t0.project_code,t1.cost_center,org_name,bu_line,bu_unit,title_d,name_m,title_a,t1_line_code,t1_line_name,end_unit,end_line 
from (
select job_no,project_code,org_name,bu_line,bu_unit,title_d,name_m,title_a,t1_line_code,t1_line_name from dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_2 ) as t0 
left join (
select job_no,project_code,cost_center,end_unit,end_line from dm_gis_uimp.tmp_personal_travel_job_project_code_end_unit 
) as t1 
on t0.job_no=t1.job_no and t0.project_code=t1.project_code 
where t1.job_no is not null
;



-- （除差旅房租外）
drop table if exists dm_gis_uimp.tmp_personal_travel_receive_detail_norent;
create table dm_gis_uimp.tmp_personal_travel_receive_detail_norent stored as parquet as 
select t0.job_no,t0.project_code,t0.end_unit,t0.end_line,
if(t11.name is not null,t11.name,t12.emp_name) as emp_name,
if(t12.position_name is not null,t12.position_name,t11.position_name_cn) as position_name,
t0.org_name,t0.bu_line,t0.bu_unit,
if(t11.cost is not null,t11.cost,t13.kostl) as cost,
if(t12.hire_date is not null,t12.hire_date,t11.entry_date) as hire_date,
if(t13.leave_date is not null,t13.leave_date,t11.termination_date) as leave_date,
if(t14.emp_num is not null,'正式','外包') as emp_type,
entertain_ers_act_amount,
entertain_ers_acc_amount,
gifts_act_amount,
gifts_acc_amount_no_settlement,
gifts_acc_amount,
outsource_act_amount,
outsource_acc_amount_no_settlement,
outsource_acc_amount,
travel_ers_act_amount,
travel_ers_acc_amount,
air_hotel_car_act_amount,
air_hotel_car_acc_amount,
if( (entertain_ers_act_amount is null or entertain_ers_act_amount=0) 
and (entertain_ers_acc_amount is null or entertain_ers_acc_amount=0)
and (gifts_act_amount is null or gifts_act_amount=0)
and (gifts_acc_amount_no_settlement is null or gifts_acc_amount_no_settlement=0)
and (gifts_acc_amount is null or gifts_acc_amount=0)
and (outsource_act_amount is null or outsource_act_amount=0)
and (outsource_acc_amount_no_settlement is null or outsource_acc_amount_no_settlement=0)
and (outsource_acc_amount is null or outsource_acc_amount=0)
and (travel_ers_act_amount is null or travel_ers_act_amount=0)
and (travel_ers_acc_amount is null or travel_ers_acc_amount=0)
and (air_hotel_car_act_amount is null or air_hotel_car_act_amount=0)
and (air_hotel_car_acc_amount is null or air_hotel_car_acc_amount=0) ,0,1  ) as is_cost,
title_a as project_name,
title_d as project_unit,
t1_line_name as project_line,
name_m as project_type,
t0.cost_center     
from dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_3 as t0 
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,entertain_ers_acc_amount,
travel_ers_acc_amount from dm_gis_uimp.dwd_personal_travel_ers_acc_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6)  ) as t2 
on t0.job_no=t2.job_no and t0.project_code=t2.project_code and t0.cost_center=t2.cost_center
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,sum(if(entertain_ers_act_amount is not null,entertain_ers_act_amount,0)) as entertain_ers_act_amount from dm_gis_uimp.dwd_personal_travel_entertain_ers_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) group by job_no,project_code,cost_center ) as t3 
on t0.job_no=t3.job_no and t0.project_code=t3.project_code  and t0.cost_center=t3.cost_center
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,sum(if(travel_ers_act_amount is not null,travel_ers_act_amount,0)) as travel_ers_act_amount from dm_gis_uimp.dwd_personal_travel_travel_ers_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) group by job_no,project_code,cost_center ) as t4 
on t0.job_no=t4.job_no and t0.project_code=t4.project_code  and t0.cost_center=t4.cost_center
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,gifts_act_amount,
outsource_act_amount from dm_gis_uimp.dwd_personal_travel_gifts_outsource_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6)  ) as t5 
on t0.job_no=t5.job_no and t0.project_code=t5.project_code  and t0.cost_center=t5.cost_center
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,gifts_acc_amount_no_settlement,
gifts_acc_amount,outsource_acc_amount_no_settlement,outsource_acc_amount from dm_gis_uimp.dwd_personal_travel_gifts_outsource_acc_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6)  ) as t6 
on t0.job_no=t6.job_no and t0.project_code=t6.project_code  and t0.cost_center=t6.cost_center
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,sum(if(air_hotel_car_act_amount is not null,air_hotel_car_act_amount,0)) as air_hotel_car_act_amount from dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_act where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) group by job_no,project_code,cost_center ) as t7 
on t0.job_no=t7.job_no and t0.project_code=t7.project_code  and t0.cost_center=t7.cost_center
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,if(cost_center is not null,cost_center,'') as cost_center,sum(if(air_hotel_car_acc_amount is not null,air_hotel_car_acc_amount,0)) as air_hotel_car_acc_amount  from dm_gis_uimp.dwd_personal_travel_gifts_outsource_air_hotel_car_acc where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) group by job_no,project_code,cost_center ) as t8 
on t0.job_no=t8.job_no and t0.project_code=t8.project_code  and t0.cost_center=t8.cost_center
left join (select emp_num,name,position_name_cn,org_name,org_id_in,cost,entry_date,termination_date,line_name,stext from dm_gis_uimp.tmp_ft_emp_out_line_name_stext ) as t11 
on t0.job_no=t11.emp_num 
left join (select emp_num,emp_name,position_name,org_name,org_id,hire_date,line_name,stext from dm_gis_uimp.tmp_issp_emp_data_line_name_stext ) as t12 
on t0.job_no=t12.emp_num 
left join (select emp_num,kostl,leave_date from dm_gis_uimp.ods_issp_emp_data_ext ) as t13 
on t0.job_no=t13.emp_num 
left join (select emp_num from dm_gis_uimp.ods_issp_emp_data where  emp_num is not null and emp_num<>'' group by emp_num) as t14 
on t0.job_no=t14.emp_num
;


-- 五、（仅差旅房租）取最终确认的经营单元、最终确认的业务线
-- 取导入文件《差旅费_差旅房租明细表》的“最终确认的经营单元、最终确认的业务线”字段。
-- select job_no,project_code,end_unit,end_line from dm_gis_uimp.dwd_personal_travel_rent_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6);

drop table if exists dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_4;
create table dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_4 stored as parquet as 
select t0.job_no,t0.project_code,org_name,bu_line,bu_unit,title_d,name_m,title_a,t1_line_code,t1_line_name,end_unit,end_line 
from (
select job_no,project_code,org_name,bu_line,bu_unit,title_d,name_m,title_a,t1_line_code,t1_line_name from dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_2 ) as t0 
left join (
select job_no,project_code,end_unit,end_line from dm_gis_uimp.dwd_personal_travel_rent_act_amount  where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) group by job_no,project_code,end_unit,end_line
) as t1 
on t0.job_no=t1.job_no and t0.project_code=t1.project_code 
where t1.job_no is not null
;

-- （仅差旅房租）
drop table if exists dm_gis_uimp.tmp_personal_travel_receive_detail_rent;
create table dm_gis_uimp.tmp_personal_travel_receive_detail_rent stored as parquet as 
select t0.job_no,t0.project_code,t0.end_unit,t0.end_line,
if(t11.name is not null,t11.name,t12.emp_name) as emp_name,
if(t12.position_name is not null,t12.position_name,t11.position_name_cn) as position_name,
t0.org_name,t0.bu_line,t0.bu_unit,
if(t11.cost is not null,t11.cost,t13.kostl) as cost,
if(t12.hire_date is not null,t12.hire_date,t11.entry_date) as hire_date,
if(t13.leave_date is not null,t13.leave_date,t11.termination_date) as leave_date,
if(t14.emp_num is not null,'正式','外包') as emp_type,
rent_act_amount,
title_a as project_name,
title_d as project_unit,
t1_line_name as project_line,
name_m as project_type,
'' as cost_center     
from dm_gis_uimp.tmp_personal_travel_job_project_code_all_org_4 as t0 
left join (
select job_no,if(project_code is not null,project_code,'') as project_code,end_unit,end_line,sum(if(rent_act_amount is not null,rent_act_amount,0)) as rent_act_amount from dm_gis_uimp.dwd_personal_travel_rent_act_amount where stat_month=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),0,6) group by job_no,project_code,end_unit,end_line ) as t1 
on t0.job_no=t1.job_no and t0.project_code=t1.project_code and t0.end_unit=t1.end_unit and t0.end_line=t1.end_line
left join (select emp_num,name,position_name_cn,org_name,org_id_in,cost,entry_date,termination_date,line_name,stext from dm_gis_uimp.tmp_ft_emp_out_line_name_stext ) as t11 
on t0.job_no=t11.emp_num 
left join (select emp_num,emp_name,position_name,org_name,org_id,hire_date,line_name,stext from dm_gis_uimp.tmp_issp_emp_data_line_name_stext ) as t12 
on t0.job_no=t12.emp_num 
left join (select emp_num,kostl,leave_date from dm_gis_uimp.ods_issp_emp_data_ext ) as t13 
on t0.job_no=t13.emp_num 
left join (select emp_num from dm_gis_uimp.ods_issp_emp_data where  emp_num is not null and emp_num<>'' group by emp_num) as t14 
on t0.job_no=t14.emp_num
;



-- 
insert overwrite table dm_gis_uimp.dws_personal_travel_receive_detail partition(inc_day='$statMonth') 
select 
job_no,project_code,end_unit,end_line,
emp_name,
position_name,
org_name,bu_line,bu_unit,
cost,
hire_date,
leave_date,
emp_type,
entertain_ers_act_amount,
entertain_ers_acc_amount,
gifts_act_amount,
gifts_acc_amount_no_settlement,
gifts_acc_amount,
outsource_act_amount,
outsource_acc_amount_no_settlement,
outsource_acc_amount,
rent_act_amount,
travel_ers_act_amount,
travel_ers_acc_amount,
air_hotel_car_act_amount,
air_hotel_car_acc_amount,
is_cost,
project_name,
project_unit,
project_line,
project_type,
cost_center,
is_rent
from (
select 
job_no,project_code,end_unit,end_line,
emp_name,
position_name,
org_name,bu_line,bu_unit,
cost,
hire_date,
leave_date,
emp_type,
entertain_ers_act_amount,
entertain_ers_acc_amount,
gifts_act_amount,
gifts_acc_amount_no_settlement,
gifts_acc_amount,
outsource_act_amount,
outsource_acc_amount_no_settlement,
outsource_acc_amount,
'' rent_act_amount,
travel_ers_act_amount,
travel_ers_acc_amount,
air_hotel_car_act_amount,
air_hotel_car_acc_amount,
is_cost,
project_name,
project_unit,
project_line,
project_type,
cost_center,
'0' as is_rent
from dm_gis_uimp.tmp_personal_travel_receive_detail_norent 
union all 
select 
job_no,project_code,end_unit,end_line,
emp_name,
position_name,
org_name,bu_line,bu_unit,
cost,
hire_date,
leave_date,
emp_type,
'' entertain_ers_act_amount,
'' entertain_ers_acc_amount,
'' gifts_act_amount,
'' gifts_acc_amount_no_settlement,
'' gifts_acc_amount,
'' outsource_act_amount,
'' outsource_acc_amount_no_settlement,
'' outsource_acc_amount,
rent_act_amount,
'' travel_ers_act_amount,
'' travel_ers_acc_amount,
'' air_hotel_car_act_amount,
'' air_hotel_car_acc_amount,
'' as is_cost,
project_name,
project_unit,
project_line,
project_type,
cost_center,
'1' as is_rent
from dm_gis_uimp.tmp_personal_travel_receive_detail_rent  
) as t 
;



