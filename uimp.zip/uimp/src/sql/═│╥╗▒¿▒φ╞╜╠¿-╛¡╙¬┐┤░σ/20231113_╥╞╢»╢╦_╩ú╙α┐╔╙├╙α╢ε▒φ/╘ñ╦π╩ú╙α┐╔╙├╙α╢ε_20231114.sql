-- 
-- 需求方：林中莉(01423677)
-- 需求： 预算可用余额 （每3分钟推一次，衡鉴展示）
-- @author 张小琼 （01416344）
-- Created on 2023-11-14
-- 任务信息： ID：903540  预算可用余额_预算
-- 


-- 预算表(hive表)
create table dm_gis_uimp.gis_forecast(
id string comment '预算主键id',
b_year string comment '年度',
bu_no string comment  'BU/专项编码，经营单元编码' ,
bu_name string comment  'BU/专项名称，经营单元名称' ,
busi_type_code string comment  '业务类型编号' ,
busi_type_name string comment  '业务类型名称' ,
project_code string comment  '项目代码' ,
projec_name string comment  '项目名称' ,
cost_center_code string comment  '成本中心编号' ,
cost_center_name string comment  '成本中心名称' ,
business_number string comment  '业务线编码' ,
business_name string comment  '业务线名称' ,
fs_first_code string comment  '预算一级科目编号' ,
fs_first_name string comment  '预算一级科目名称' ,
fs_second_code string comment  '预算二级科目编号' ,
fs_second_name string comment  '预算二级科目名称' ,
acount string comment  '预算金额' ,
apply_acount string comment  '占用金额' ,
use_acount string comment  '消耗金额' ,
remain_acount string comment  '剩余可用预算金额' ,
dept_manager_mp_no string comment  '部门负责人工号',
inc_datetime  string comment '数据写入时间'
)
COMMENT '预算剩余可用gis-forecast表'
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


--
drop table if exists dm_gis_uimp.tmp_gis_forecast_desolve;
create table dm_gis_uimp.tmp_gis_forecast_desolve stored as parquet as 
select 
get_json_object(msg,'$.queryTime') as query_time,
get_json_object(msg,'$.data') as content 
from dm_gis_uimp.ods_issp_kafka_tmp 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='REMAIN_BUDGET' 
;

-- 
insert overwrite table dm_gis_uimp.gis_forecast partition(inc_day='$firstDay')
select 
get_json_object(row_json,'$.id') as id,
get_json_object(row_json,'$.year') as b_year,
get_json_object(row_json,'$.buNo') as bu_no,
get_json_object(row_json,'$.buName') as bu_name,
get_json_object(row_json,'$.busiTypeCode') as busi_type_code,
get_json_object(row_json,'$.busiTypeName') as busi_type_name,
get_json_object(row_json,'$.projectCode') as project_code,
get_json_object(row_json,'$.projectName') as projec_name,
get_json_object(row_json,'$.costCenterCode') as cost_center_code,
get_json_object(row_json,'$.costCenterName') as cost_center_name,
get_json_object(row_json,'$.businessNumber') as business_number,
get_json_object(row_json,'$.businessName') as business_name,
get_json_object(row_json,'$.fsFirstCode') as fs_first_code,
get_json_object(row_json,'$.fsFirstName') as fs_first_name,
get_json_object(row_json,'$.fsSecondCode') as fs_second_code,
get_json_object(row_json,'$.fsSecondName') as fs_second_name,
get_json_object(row_json,'$.acount') as acount,
get_json_object(row_json,'$.applyAcount') as apply_acount,
get_json_object(row_json,'$.useAcount') as use_acount,
get_json_object(row_json,'$.remainAcount') as remain_acount,
get_json_object(row_json,'$.deptManagerEmpNo') as dept_manager_mp_no,
query_time as inc_datetime
from dm_gis_uimp.tmp_gis_forecast_desolve as t 
lateral view explode(split(regexp_replace(regexp_replace(content , '\\[|\\]',''),'\\}\\,\\{','\\}\\;\\{'),'\\;')) datas as row_json
;


-- 线下导测试数据
create table dm_gis_uimp.tmp_csv_gis_forecast(
id string comment '预算主键id',
b_year string comment '年度',
bu_no string comment  'BU/专项编码，经营单元编码' ,
bu_name string comment  'BU/专项名称，经营单元名称' ,
busi_type_code string comment  '业务类型编号' ,
busi_type_name string comment  '业务类型名称' ,
project_code string comment  '项目代码' ,
projec_name string comment  '项目名称' ,
cost_center_code string comment  '成本中心编号' ,
cost_center_name string comment  '成本中心名称' ,
business_number string comment  '业务线编码' ,
business_name string comment  '业务线名称' ,
fs_first_code string comment  '预算一级科目编号' ,
fs_first_name string comment  '预算一级科目名称' ,
fs_second_code string comment  '预算二级科目编号' ,
fs_second_name string comment  '预算二级科目名称' ,
acount string comment  '预算金额' ,
apply_acount string comment  '占用金额' ,
use_acount string comment  '消耗金额' ,
remain_acount string comment  '剩余可用预算金额' ,
dept_manager_mp_no string comment  '部门负责人工号',
inc_datetime  string comment '数据写入时间'
)
COMMENT '预算剩余可用gis-forecast表'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/剩余可用余额表_测试数据.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.tmp_csv_gis_forecast;

insert overwrite table dm_gis_uimp.gis_forecast partition(inc_day='')
select * from dm_gis_uimp.tmp_csv_gis_forecast;

drop table dm_gis_uimp.tmp_csv_gis_forecast;


-- clickhouse表
CREATE TABLE gis_oms_uimp_fd.gis_forecast
(
    `id` String COMMENT '预算主键id',
    `b_year` String COMMENT '年度',
    `bu_no` String COMMENT 'BU/专项编码，经营单元编码',
    `bu_name` String COMMENT 'BU/专项名称，经营单元名称',
    `busi_type_code` String COMMENT '业务类型编号',
    `busi_type_name` String COMMENT '业务类型名称',
    `project_code` String COMMENT '项目代码',
    `projec_name` String COMMENT '项目名称',
    `cost_center_code` String COMMENT '成本中心编号',
    `cost_center_name` String COMMENT '成本中心名称',
    `business_number` String COMMENT '业务线编码',
    `business_name` String COMMENT '业务线名称',
    `fs_first_code` String COMMENT '预算一级科目编号',
    `fs_first_name` String COMMENT '预算一级科目名称',
    `fs_second_code` String COMMENT '预算二级科目编号',
    `fs_second_name` String COMMENT '预算二级科目名称',
    `acount` Decimal(32, 10) COMMENT '预算金额',
    `apply_acount` Decimal(32, 10) COMMENT '占用金额',
    `use_acount` Decimal(32, 10) COMMENT '消耗金额',
    `remain_acount` Decimal(32, 10) COMMENT '剩余可用预算金额',
    `dept_manager_mp_no` String COMMENT '部门负责人工号',
    `inc_datetime` String COMMENT '数据写入时间',
    `inc_day` String COMMENT '跑数日期',
    `CREATE_TIME` DateTime DEFAULT now() COMMENT '创建日期',
    `CREATE_USER` String COMMENT '创建人',
    `MODIFY_TIME` DateTime DEFAULT now() COMMENT '更新日期',
    `MODIFY_USER` String COMMENT '更新人'
)
ENGINE = MergeTree
PARTITION BY inc_day
ORDER BY inc_day
SETTINGS index_granularity = 8192
COMMENT '预算剩余可用gis-forecast表'


select 
id,
b_year,
bu_no,
bu_name,
if(busi_type_code is not null,busi_type_code,'') as busi_type_code,
if(busi_type_name is not null,busi_type_name,'') as busi_type_name,
if(project_code is not null,project_code,'') as project_code,
if(projec_name is not null,projec_name,'') as projec_name,
if(cost_center_code is not null,cost_center_code,'') as cost_center_code,
if(cost_center_name is not null,cost_center_name,'') as cost_center_name,
if(business_number is not null,business_number,'') as business_number,
if(business_name is not null,business_name,'') as business_name,
if(fs_first_code is not null,fs_first_code,'') as fs_first_code,
if(fs_first_name is not null,fs_first_name,'') as fs_first_name,
if(fs_second_code is not null,fs_second_code,'') as fs_second_code,
if(fs_second_name is not null,fs_second_name,'') as fs_second_name,
cast(replace(acount,',','') as decimal(10,2)) as acount,
cast(replace(apply_acount,',','') as decimal(10,2)) as apply_acount,
cast(replace(use_acount,',','') as decimal(10,2)) as use_acount,
cast(replace(remain_acount,',','') as decimal(10,2)) as remain_acount,
if(dept_manager_mp_no is not null,dept_manager_mp_no,'') as dept_manager_mp_no,
inc_datetime 
from dm_gis_uimp.gis_forecast 
where inc_day='$[time(yyyyMMdd,-1d)]' limit 1 



{"bu_name":null,"business_name":null,"acount":"10000.99","use_acount":"765","dept_manager_mp_no":"01258405","business_number":null,"project_code":null,"fs_first_name":"运营投入","inc_datetime":"2023-11-16 14:21:39","busi_type_name":null,"fs_first_code":"1011","busi_type_code":null,"projec_name":null,"fs_second_name":"差旅招待","remain_acount":"9235.99","b_year":"2023","bu_no":"null","apply_acount":"0","fs_second_code":"10110001","id":"78","cost_center_name":"丰图科技算法中心规划算法部","cost_center_code":"SF0562802"}
{"bu_name":null,"business_name":null,"acount":"0","use_acount":null,"dept_manager_mp_no":"01258405","business_number":null,"project_code":null,"fs_first_name":"运营投入","inc_datetime":"2023-11-16 14:21:39","busi_type_name":null,"fs_first_code":"1011","busi_type_code":null,"projec_name":null,"fs_second_name":"差旅招待","remain_acount":"0","b_year":"2023","bu_no":"null","apply_acount":null,"fs_second_code":"10110001","id":"77","cost_center_name":"丰图科技算法中心地址算法部","cost_center_code":"SF0562801"}
{"bu_name":"采购部","business_name":"货运地图与加油地图业务线","acount":"130400","use_acount":"9255","dept_manager_mp_no":"01233793","business_number":"1006","project_code":null,"fs_first_name":"运营投入","inc_datetime":"2023-11-16 14:21:39","busi_type_name":null,"fs_first_code":"1011","busi_type_code":null,"projec_name":null,"fs_second_name":"差旅招待","remain_acount":"107082","b_year":"2023","bu_no":"20002088","apply_acount":"14063","fs_second_code":"10110001","id":"75","cost_center_name":"丰图科技","cost_center_code":"SF056"}



insert into default.gis_forecast 
(id,b_year,bu_no,bu_name,busi_type_code,busi_type_name,project_code,projec_name,
cost_center_code,cost_center_name,business_number,business_name,fs_first_code,fs_first_name,
fs_second_code,fs_second_name,acount,apply_acount,use_acount,remain_acount,dept_manager_mp_no,inc_datetime ) 
FORMAT JSONEachRow {"bu_name":null,"business_name":null,"acount":"10000.99","use_acount":"765","dept_manager_mp_no":"01258405","business_number":null,"project_code":null,"fs_first_name":"运营投入","inc_datetime":"2023-11-16 14:21:39","busi_type_name":null,"fs_first_code":"1011","busi_type_code":null,"projec_name":null,"fs_second_name":"差旅招待","remain_acount":"9235.99","b_year":"2023","bu_no":"null","apply_acount":"0","fs_second_code":"10110001","id":"78","cost_center_name":"丰图科技算法中心规划算法部","cost_center_code":"SF0562802"}