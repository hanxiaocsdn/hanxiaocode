--
-- 需求方：林中莉(01423677)
-- 需求： 存货收发存汇总表 期末库存维度余额调整
-- @author 张小琼 （01416344）
-- Created on 2024-01-23
-- 任务信息： ID：731751	采购数据_先写到ods再开发dwd
--


-- 存货收发存汇总表 INVENTORY-RECEIPT-DELIVERY
create table if not exists  dm_gis_uimp.dwc_purchase_INVENTORY_RECEIPT_DELIVERY(
query_time	string comment '查询时间',
FMATERIALNAME	string comment '物料名称',
FMATERIALGROUP	string comment '物料分组',
FMODEL	string comment '规格型号',
FSTOCKSTATUSNAME	string comment '库存状态',
FSTOCKId	string comment '仓库',
FACCTGRANGEID	string comment '核算范围编码',
FACCTGRANGENAME	string comment '核算范围名称',
FINITQty	string comment '期初结存数量',
FINITPrice	string comment '期初结存单价',
FINITAMOUNT	string comment '期初结存金额',
FRECEIVEQty	string comment '本期收入数量',
FRECEIVEPrice	string comment '本期收入单价',
FRECEIVEAmount	string comment '本期收入金额',
FSENDQty	string comment '本期发出数量',
FSENDPrice	string comment '本期发出单价',
FSENDAmount	string comment '本期发出金额',
FENDQty	string comment '期末结存数量',
FENDPrice	string comment '期末结存单价',
FENDAmount	string comment '期末结存金额',
FMATERIALBASEID	string comment '物料编码',
F_TTHM_BaseProperty	string comment '财务分类',
FMATERPROPERTY string comment '物料属性',
FMATERTYPE string comment '存货类别',
FLOTNO string comment '批号',
FASSIPROPNAME string comment '辅助属性',
FBOMNO string comment 'BOM版本',
FPLANNO string comment '计划跟踪号',
FOWNERNAME string comment '货主',
FSTOCKORGNAME string comment '库存组织',
FSTOCKPLACENAME string comment '仓位',
FUNITNAME string comment '基本单位' 
)
COMMENT '采购数据_存货收发存汇总表dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/存货收发存汇总表dwc_purchase_inventory_receipt_delivery-替换inc_day20231231.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_INVENTORY_RECEIPT_DELIVERY partition(inc_day='20231231');



-- 期末库存维度余额调整   HS_INIV_EXCEPTION_BALANCE_RPT 
create table if not exists  dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt(
queryTime	string comment'查询时间',
FMaterialId	string comment'物料编码',
FMATERIALNAME	string comment'物料名称',
FMATERPROPERTY	string comment'物料属性',
FMATERTYPE	string comment'存货类别',
FMATERIALGROUP	string comment'物料分组',
FMODEL	string comment'规格型号',
FSTOCKSTATUS	string comment'库存状态',
FLOT	string comment'批号',
FAUXPROP	string comment'辅助属性',
FBOM	string comment'BOM版本',
FMTONO	string comment'计划跟踪号',
FOWNER	string comment'货主',
FSTOCKORG	string comment'库存组织',
FSTOCK	string comment'仓库',
FSTOCKLOC	string comment'仓位',
FACCTGRANGEID	string comment'核算范围编码',
FACCTGRANGENAME	string comment'核算范围名称',
FUNIT	string comment'基本单位',
FEXPENSENUMBER	string comment'费用项目编码',
FEXPENSENAME	string comment'费用项目名称',
FQTY	string comment'期末数量',
FPrice	string comment'库存维度期末单价',
FAmount	string comment'库存维度期末金额',
FACCTGDIMEPrice	string comment'核算维度期末单价',
FACCTGDIMEAmount	string comment'核算维度期末金额',
FDIFFAMOUNT	string comment'金额差异',
FADJAMOUNT	string comment'调整金额',
FAdjustBillNo	string comment'成本调整单编号',
FADJUSTBILLSEQ	string comment'成本调整单行号'
)
COMMENT '采购数据_期末库存维度余额调整dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/期末库存维度余额调整dwc_purchase_hs_iniv_exception_balance_rpt-替换inc_day20240101.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt partition(inc_day='20240101');
