-- 
-- 需求方：林中莉(01423677)
-- 需求： id: 1618967  GIS-ISSP-CORE：【经营看板专项】回款业绩底表_V1.0
-- @author 张小琼 （01416344）
-- Created on 2023-04-06
-- 任务信息： ID：694478  丰图合同回款收入签单业绩
-- 

-- 1 回款
-- 线上数据源
-- ods_bill_amt_ret_claim_form 数字孪生_历史回款业绩表
-- dwd_crm_con_base CRM销售合同基础表 

-- 线下数据源
-- 数字孪生_历史回款业绩表
-- 字段	示例
-- id	1-207
-- 合同编号	C001230109137974
-- 实际回款金额(万元)	10
-- 实际回款时间	2023/1/9
-- 回款进度	2023M1W2
-- 回款月份	2023-01
-- 合同回款周期	28
-- 计划进度	计划内
-- 回款类型	初验款
-- 回款条件达成时间	2022/12/12
-- 节点类型	验收款
-- 是否问题款	是
-- 应收款回款周期	28


-- 建历史回款业绩表
CREATE  TABLE `dm_gis_uimp.ods_history_collection_performance`(
id  string comment 'id',
contract_code  string comment '合同编号',
actual_collection_amount  string comment '实际回款金额(万元)',
actual_collection_time	string comment '实际回款时间',
collection_progress	string comment '回款进度',
collection_month  string comment '回款月份',
collection_cycle  string comment '合同回款周期',
planned	string comment '计划进度',
collection_type	string comment '回款类型',
completion_time	string comment '回款条件达成时间',
node_type  string comment '节点类型',
is_prob_payment	string comment '是否问题款',
receivable_cycle  string comment '应收款回款周期' 
)
COMMENT '数字孪生_历史回款业绩表'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/lshk_20230406.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_history_collection_performance;



-- 回款业绩
CREATE  TABLE `dm_gis_uimp.dws_collection_performance`(
id  string comment 'id',
contract_code  string comment '合同编号',
actual_collection_amount  string comment '实际回款金额',
actual_collection_time	string comment '实际回款时间',
collection_month  string comment '回款月份',
collection_cycle  string comment '合同回款周期',
collection_progress	string comment '回款进度',
ssq string comment '项目名称',
field_kvx2b__c string comment '商机代码',
record_type string comment '业务线',
field_6ohea__c string comment '业务中心',
field_y1cnk__c__r string comment '营销中心',
field_0EuIa__c string comment '行业',
field_r8qu9__c__r string comment '所属省份',
field_tfeh7__c__r string comment '所属城市',
regional_type string comment '区域类型',
owner__r_name string comment '销售经理',
field_lzwcy__c__r_name string comment '项目经理',
field_b1cxa__c__r string comment '对方主体(甲方)',
field_cby7l__c string comment '合同金额(含税，万元)',
field_mk1fa__c string comment '合同签订日期',
field_g7ya1__c string comment '是否框架合同',
field_0mn82__c string comment '是否背靠背',
field_kClKF__c string comment '签单业绩确认方式（按合同签章1；按回款认领2；按收入确认3；其他other）',
bukrs string comment '公司代码' 
)
COMMENT '丰图回款业绩表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 2023.12.20 增加字段
field_kClKF__c  签单业绩确认方式（按合同签章1；按回款认领2；按收入确认3；其他other）

-- 2023.12.27 增加字段
-- 公司代码 bukrs
-- 1、BDP：dws_collection_performance 新增字段，取 ods_bill_amt_ret_claim_form.bukrs

-- 2024.01.08 增加字段
销售经理工号   owner__r_no



-- 
drop table if exists dm_gis_uimp.tmp_collection_performance;
create table dm_gis_uimp.tmp_collection_performance as 
select 
id,contract_code,actual_collection_amount,actual_collection_time,collection_month,bukrs  
from (
select 
claim_form_no as id,company_contract_code as contract_code,
if(status='7',-1*amt_claimed/1000000,amt_claimed/1000000) as actual_collection_amount,
-- substr(if(length(approved_date)=13,FROM_UNIXTIME(cast(approved_date/1000 as int)),approved_date),1,10) as actual_collection_time,
-- 2024.01.18 
-- 如果approveData和entry_acct_period为同一年份，则取approveData，并转成2023-01-09的格式;否则，取entry_acct_period所在年份的最后一天
case when substr(if(length(approved_date)=13,FROM_UNIXTIME(cast(approved_date/1000 as int)),approved_date),1,4)=substr(entry_acct_period,1,4) then substr(if(length(approved_date)=13,FROM_UNIXTIME(cast(approved_date/1000 as int)),approved_date),1,10) 
    when substr(if(length(approved_date)=13,FROM_UNIXTIME(cast(approved_date/1000 as int)),approved_date),1,4)!=substr(entry_acct_period,1,4) then date_add(add_months(concat(substr(entry_acct_period,1,4),'-12-01'),1),-1) 
else '' end as actual_collection_time,
entry_acct_period as  collection_month,
bukrs  
from dm_gis_uimp.ods_bill_amt_ret_claim_form 
where status in ('1','7') 
-- and from_unixtime(cast(approved_date/1000 as int),'yyyyMM')=from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyyMM')
union all 
select 
id,contract_code,actual_collection_amount,actual_collection_time,collection_month,'' AS bukrs  
from dm_gis_uimp.ods_history_collection_performance 
) as t 
group by id,contract_code,actual_collection_amount,actual_collection_time,collection_month,bukrs   
;



-- firstDay=$date_param
-- day1=`date -d "$firstDay" +%Y%m01`
-- statMonth=`date -d "-1 month $day1" +%Y%m`
-- echo $firstDay $statMonth
insert overwrite table dm_gis_uimp.dws_collection_performance partition(inc_day='$firstDay') 
select 
id,contract_code,actual_collection_amount,actual_collection_time,collection_month,
if(t1.name is not null,datediff(actual_collection_time,t1.field_mk1fa__c)/30,datediff(actual_collection_time,t2.field_mk1fa__c)/30) as collection_cycle,
if(t1.name is not null,t1.field_eoks3__c,t2.field_eoks3__c) collection_progress,
if(t1.name is not null,t1.field_2mhq1__c__r,t2.field_2mhq1__c__r) ssq,
if(t1.name is not null,t1.field_kvx2b__c,t2.field_kvx2b__c) field_kvx2b__c,
if(t1.name is not null,t1.record_type,t2.record_type) record_type,
if(t1.name is not null,t1.field_6ohea__c,t2.field_6ohea__c) field_6ohea__c,
if(t1.name is not null,t1.field_y1cnk__c__r,t2.field_y1cnk__c__r) field_y1cnk__c__r,
if(t1.name is not null,t1.field_0EuIa__c,t2.field_0EuIa__c) field_0EuIa__c,
if(t1.name is not null,t1.field_r8qu9__c__r,t2.field_r8qu9__c__r) field_r8qu9__c__r,
if(t1.name is not null,t1.field_tfeh7__c__r,t2.field_tfeh7__c__r) field_tfeh7__c__r,
if(t1.name is not null,t1.regional_type,t2.regional_type) regional_type,
if(t1.name is not null,t1.owner__r_name,t2.owner__r_name) owner__r_name,
if(t1.name is not null,t1.field_lzwcy__c__r_name,t2.field_lzwcy__c__r_name) field_lzwcy__c__r_name,
if(t1.name is not null,t1.field_b1cxa__c__r,t2.field_b1cxa__c__r) field_b1cxa__c__r,
if(t1.name is not null,t1.field_cby7l__c,t2.field_cby7l__c) field_cby7l__c,
if(t1.name is not null,t1.field_mk1fa__c,t2.field_mk1fa__c) field_mk1fa__c,
if(t1.name is not null,t1.field_g7ya1__c,t2.field_g7ya1__c) field_g7ya1__c,
if(t1.name is not null,t1.field_0mn82__c,t2.field_0mn82__c) field_0mn82__c,
if(t1.name is not null,t1.field_kClKF__c,t2.field_kClKF__c) field_kClKF__c,
bukrs,
if(t1.name is not null,t1.owner__r_no,t2.owner__r_no) owner__r_no 

from dm_gis_uimp.tmp_collection_performance as t0 
left join (
select 
name,field_eoks3__c,field_2mhq1__c__r,field_kvx2b__c,record_type,field_6ohea__c,field_y1cnk__c__r,field_0EuIa__c,field_r8qu9__c__r,field_tfeh7__c__r,regional_type,owner__r_name,
field_p83vd__c_r_name as field_lzwcy__c__r_name,
field_b1cxa__c__r,field_cby7l__c,
from_unixtime(cast(substr(field_mk1fa__c,0,10) as bigint),'yyyy-MM-dd') as field_mk1fa__c,
field_g7ya1__c,field_0mn82__c,field_kClKF__c,owner__r_no,
inc_month  
from dm_gis_uimp.dwd_crm_con_base_mf  
where inc_month>='202301' and life_status!='invalid' 
) as t1 
on  t0.contract_code=t1.name and substr(replace(t0.actual_collection_time,'-',''),1,6)=t1.inc_month 
left join (
select name,field_eoks3__c,field_2mhq1__c__r,field_kvx2b__c,record_type,field_6ohea__c,field_y1cnk__c__r,field_0EuIa__c,field_r8qu9__c__r,field_tfeh7__c__r,regional_type,owner__r_name,
field_lzwcy__c__r_name,
field_b1cxa__c__r,field_cby7l__c,
field_mk1fa__c,
field_g7ya1__c,field_0mn82__c,field_kClKF__c,owner__r_no,
inc_month 
from (select 
name,field_eoks3__c,field_2mhq1__c__r,field_kvx2b__c,record_type,field_6ohea__c,field_y1cnk__c__r,field_0EuIa__c,field_r8qu9__c__r,field_tfeh7__c__r,regional_type,owner__r_name,
field_p83vd__c_r_name as field_lzwcy__c__r_name,
field_b1cxa__c__r,field_cby7l__c,
from_unixtime(cast(substr(field_mk1fa__c,0,10) as bigint),'yyyy-MM-dd') as field_mk1fa__c,
field_g7ya1__c,field_0mn82__c,field_kClKF__c,owner__r_no,
inc_month,
row_number() over(partition by field_eoks3__c,inc_month order by last_modified_time desc ) as rn     
from dm_gis_uimp.dwd_crm_con_base_mf  
where inc_month>='202301' and life_status!='invalid' ) as t where t.rn=1 
) as t2 
on  t0.contract_code=t2.field_eoks3__c and substr(replace(t0.actual_collection_time,'-',''),1,6)=t2.inc_month 
;

-- 2 收入
-- 线下数据源
CREATE  TABLE `dm_gis_uimp.ods_history_income_performance`(
id	string comment	 'id',
contract_code	string comment	 '合同编号',
income_included_tax_amount 	string comment	 '收入含税金额(万元)',
income_excluding_tax_amount	string comment	 '收入不含税金额(万元)',
revenue_time	string comment	 '收入时间',
revenue_month	string comment	 '收入月份',
revenue_progress	string comment	 '收入进度',
allocation_remarks	string comment	 '分摊备注',
acceptance_materials	string comment	 '验收材料',
node_type	string comment	 '收入节点类型', 
revenue_cycle	string comment '收入周期'
)
COMMENT '数字孪生_历史收入业绩表'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/lssr_20230406.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_history_income_performance ;




-- 收入业绩
CREATE  TABLE `dm_gis_uimp.dws_income_performance`(
id	string comment	 'id',
contract_code	string comment	 '合同编号',
income_included_tax_amount 	string comment	 '收入含税金额(万元)',
income_excluding_tax_amount	string comment	 '收入不含税金额(万元)',
revenue_time	string comment	 '收入时间',
revenue_month	string comment	 '收入月份',
node_type	string comment	 '收入节点类型', 
revenue_cycle	string comment '收入周期',
field_kvx2b__c	string comment '商机代码',
field_2mhq1__c__r	string comment '项目名称',
record_type	string comment '业务线',
field_6ohea__c	string comment '业务中心',
field_y1cnk__c__r	string comment '营销中心',
field_0EuIa__c	string comment '行业',
field_r8qu9__c__r	string comment '所属省份',
field_tfeh7__c__r	string comment '所属城市',
regional_type	string comment '区域类型',
field_lzwcy__c__r_name	string comment '项目经理',
owner__r_name	string comment '销售经理',
field_cby7l__c	string comment '合同金额(含税，万元)',
field_mk1fa__c	string comment '合同签订日期',
field_9necq__c	string comment '是否有合格收款权',
charge_off_type  string comment '',
field_kClKF__c  string comment '',
ecp_contract_code  string comment 'CTC合同编号',
bukrs string comment '公司代码',
field_b1cxa__c__r string comment '客户代码',
field_b1cxa__c__r2 string comment '客户名称',
tax_rate string comment '税率' 
)
COMMENT '丰图收入业绩表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 2023.12.20 增加字段
charge_off_type 
field_kClKF__c

-- 2023.12.27 增加字段
-- CTC合同编号 ecp_contract_code
-- 1、BDP：dws_income_performance新增字段，取dws_bill_income_performance_detail.ecp_contract_code
-- 公司代码 bukrs
-- 1、BDP：dws_income_performance新增字段，取dws_bill_income_performance_detail.company_code
-- 客户代码 field_b1cxa__c__r
-- 1、BDP：dws_income_performance新增字段，取dws_bill_income_performance_detail.customer_name
-- 税率 tax_rate
-- 1、BDP：dws_income_performance新增字段，取dws_bill_income_performance_detail.tax_rate
-- 客户名称 field_b1cxa__c__r2
-- 1、BDP：dws_income_performance新增字段，取dws_bill_income_performance_detail.customer_name_val

-- 2024.01.08 增加字段
销售经理工号   owner__r_no

--
insert overwrite table dm_gis_uimp.dws_bill_income_performance_detail 
select 
id,income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,
staff_name,business_type,customer_name,contract_sign_scene,trim(company_contract_code) as company_contract_code,order_code,trim(ecp_contract_code) as ecp_contract_code,
company_code,has_collection_right,has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,
accept_count,hardware_count,service_begin_date,service_end_date,share_month,share_rate_amount,project_phase,
project_phase_progress,project_complete_date,project_phase_amount,income_node,confirm_status,performance_id,
if(order_type='1',charge_Off_Rate_Amount,current_rate_amount) as rate_amount,
if(order_type='1',charge_Off_Amount,current_amount) as amount,
order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type,customer_name_val  
from dm_gis_uimp.ods_bill_income_confirm 
;


-- 
drop table if exists dm_gis_uimp.tmp_income_performance;
create table dm_gis_uimp.tmp_income_performance as 
select 
id,contract_code,income_included_tax_amount,income_excluding_tax_amount,revenue_time,revenue_month,revenue_progress,allocation_remarks,acceptance_materials,
charge_off_type,
node_type,revenue_cycle,
ecp_contract_code,bukrs,field_b1cxa__c__r,tax_rate,field_b1cxa__c__r2      
from (
select income_number as id,company_contract_code as contract_code,
rate_amount/1000000 as income_included_tax_amount,amount/1000000 as income_excluding_tax_amount,
from_unixtime(cast(substr(order_date,0,10) as bigint),'yyyy-MM-dd') as revenue_time,
substr(from_unixtime(cast(substr(enter_account_date,0,10) as bigint),'yyyy-MM-dd'),0,7) as revenue_month,
'' as revenue_progress,'' as allocation_remarks,'' as acceptance_materials,
charge_off_type,
income_node as node_type,'' as revenue_cycle,
ecp_contract_code,company_code as bukrs,customer_name as field_b1cxa__c__r,tax_rate,customer_name_val as field_b1cxa__c__r2   
from dm_gis_uimp.dws_bill_income_performance_detail 
where 
-- from_unixtime(cast(substr(order_date,0,10) as bigint),'yyyyMM')=substr('$firstDay',1,6) 
-- and 
from_unixtime(cast(substr(order_date,0,10) as bigint),'yyyyMMdd')<='$firstDay' 
union all 
select id,contract_code,income_included_tax_amount,income_excluding_tax_amount,revenue_time,revenue_month,revenue_progress,allocation_remarks,acceptance_materials,
'' as charge_off_type,
node_type,revenue_cycle,
'' ecp_contract_code,'' as bukrs,'' as field_b1cxa__c__r,'' as tax_rate,'' as field_b1cxa__c__r2    
from dm_gis_uimp.ods_history_income_performance  
) as t 
group by id,contract_code,income_included_tax_amount,income_excluding_tax_amount,revenue_time,revenue_month,revenue_progress,allocation_remarks,acceptance_materials,
charge_off_type,
node_type,revenue_cycle,
ecp_contract_code,bukrs,field_b1cxa__c__r,tax_rate,field_b1cxa__c__r2      
;




-- 
insert overwrite table dm_gis_uimp.dws_income_performance partition(inc_day='$firstDay') 
select 
id,contract_code,income_included_tax_amount,income_excluding_tax_amount,revenue_time,revenue_month,node_type,
revenue_cycle,field_kvx2b__c, field_2mhq1__c__r, record_type, field_6ohea__c, field_y1cnk__c__r, field_0EuIa__c, 
field_r8qu9__c__r,field_tfeh7__c__r,regional_type,field_lzwcy__c__r_name,owner__r_name,field_cby7l__c,field_mk1fa__c,field_9necq__c,
charge_off_type,field_kClKF__c,ecp_contract_code,bukrs,field_b1cxa__c__r,tax_rate,field_b1cxa__c__r2,owner__r_no    
from (
select 
id,contract_code,income_included_tax_amount,income_excluding_tax_amount,revenue_time,revenue_month,charge_off_type,node_type,
if(t1.name is not null,datediff(revenue_time,t1.field_mk1fa__c)/30,datediff(revenue_time,t2.field_mk1fa__c)/30) as revenue_cycle,
if(t1.name is not null,t1.field_kvx2b__c,t2.field_kvx2b__c) field_kvx2b__c, 
if(t1.name is not null,t1.field_2mhq1__c__r,t2.field_2mhq1__c__r) field_2mhq1__c__r, 
if(t1.name is not null,t1.record_type,t2.record_type) record_type, 
if(t1.name is not null,t1.field_6ohea__c,t2.field_6ohea__c) field_6ohea__c, 
if(t1.name is not null,t1.field_y1cnk__c__r,t2.field_y1cnk__c__r) field_y1cnk__c__r, 
if(t1.name is not null,t1.field_0EuIa__c,t2.field_0EuIa__c) field_0EuIa__c, 
if(t1.name is not null,t1.field_r8qu9__c__r,t2.field_r8qu9__c__r) field_r8qu9__c__r, 
if(t1.name is not null,t1.field_tfeh7__c__r,t2.field_tfeh7__c__r) field_tfeh7__c__r, 
if(t1.name is not null,t1.regional_type,t2.regional_type) regional_type, 
if(t1.name is not null,t1.field_lzwcy__c__r_name,t2.field_lzwcy__c__r_name) field_lzwcy__c__r_name, 
if(t1.name is not null,t1.owner__r_name,t2.owner__r_name) owner__r_name, 
if(t1.name is not null,t1.field_cby7l__c,t2.field_cby7l__c) field_cby7l__c, 
if(t1.name is not null,t1.field_mk1fa__c,t2.field_mk1fa__c) field_mk1fa__c, 
if(t1.name is not null,t1.field_9necq__c,t2.field_9necq__c) field_9necq__c,
if(t1.name is not null,t1.field_kClKF__c,t2.field_kClKF__c) field_kClKF__c,
ecp_contract_code,bukrs,field_b1cxa__c__r,tax_rate,field_b1cxa__c__r2,
if(t1.name is not null,t1.owner__r_no,t2.owner__r_no) owner__r_no, 
row_number() over(partition by id order by contract_code desc ) as rn 
from dm_gis_uimp.tmp_income_performance as t0 
left join 
(
select 
name,
field_eoks3__c,
field_kvx2b__c, field_2mhq1__c__r, record_type, field_6ohea__c, field_y1cnk__c__r, field_0EuIa__c, 
field_r8qu9__c__r, field_tfeh7__c__r, regional_type, 
field_p83vd__c_r_name as field_lzwcy__c__r_name, owner__r_name, 
field_cby7l__c, 
from_unixtime(cast(substr(field_mk1fa__c,0,10) as bigint),'yyyy-MM-dd') as field_mk1fa__c, 
field_9necq__c,field_kClKF__c,owner__r_no,
inc_month   
from dm_gis_uimp.dwd_crm_con_base_mf 
where inc_month>='202301' and life_status!='invalid' 
) as t1 
on t0.contract_code=t1.name and substr(replace(t0.revenue_time,'-',''),1,6)=t1.inc_month 
left join 
(select name,
field_eoks3__c,
field_kvx2b__c, field_2mhq1__c__r, record_type, field_6ohea__c, field_y1cnk__c__r, field_0EuIa__c, 
field_r8qu9__c__r, field_tfeh7__c__r, regional_type, 
field_lzwcy__c__r_name, owner__r_name, 
field_cby7l__c, 
field_mk1fa__c, 
field_9necq__c,field_kClKF__c,owner__r_no,
inc_month 
from (select 
name,
field_eoks3__c,
field_kvx2b__c, field_2mhq1__c__r, record_type, field_6ohea__c, field_y1cnk__c__r, field_0EuIa__c, 
field_r8qu9__c__r, field_tfeh7__c__r, regional_type, 
field_p83vd__c_r_name as field_lzwcy__c__r_name, owner__r_name, 
field_cby7l__c, 
from_unixtime(cast(substr(field_mk1fa__c,0,10) as bigint),'yyyy-MM-dd') as field_mk1fa__c, 
field_9necq__c,field_kClKF__c,owner__r_no,
inc_month,      
row_number() over(partition by field_eoks3__c,inc_month order by last_modified_time desc ) as rn     
from dm_gis_uimp.dwd_crm_con_base_mf  
where inc_month>='202301' and life_status!='invalid' ) as t where t.rn=1 
) as t2 
on t0.contract_code=t2.field_eoks3__c and substr(replace(t0.revenue_time,'-',''),1,6)=t2.inc_month 
) as tt 
where tt.rn=1
;



-- 3 签单
-- 线下数据源
CREATE  TABLE `dm_gis_uimp.ods_history_sign_bill_performance`(
id	string comment 'id',
contract_code	string comment '合同编号',
contract_amount	string comment '合同金额(含税，万元)',
contract_progress	string comment '合同进度',
performance_date	string comment '业绩日期',
performance_month	string comment '业绩月份',
subcontracting_ratio	string comment '分包比例',
self_ratio	string comment '自有产品占比',
predicted_gross_ratio	string comment '预测毛利率',
subcontracting_amount	string comment '分包金额(万元)',
own_product_share	string comment '自有产品份额',
predicted_gross_amount	string comment '预测毛利额',
total_cost	string comment '成本合计(万元)',
opp_create_time	string comment '商机创建时间',
opp_order_cycle	string comment '商机成单周期',
down_payment	string comment '首付款',
warranty_deposit	string comment '质保金',
down_payment_ratio	string comment '首付款比例',
quality_deposit_ratio	string comment '质保金比例' 
)
COMMENT '数字孪生_历史签单业绩表'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/user/01416344/upload/lsqd_20230406.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_history_sign_bill_performance ;



-- 丰图签单业绩表
CREATE  TABLE `dm_gis_uimp.dws_sign_bill_performance`(
id	string comment 'id',
contract_code	string comment '合同编号',
contract_amount	string comment '合同金额(含税，万元)',
contract_progress	string comment '合同进度',
performance_date	string comment '业绩日期',
performance_month	string comment '业绩月份',
subcontracting_ratio	string comment '分包比例',
self_ratio	string comment '自有产品占比',
predicted_gross_ratio	string comment '预测毛利率',
subcontracting_amount	string comment '分包金额(万元)',
own_product_share	string comment '自有产品份额',
predicted_gross_amount	string comment '预测毛利额',
total_cost	string comment '成本合计(万元)',
opp_create_time	string comment '商机创建时间',
opp_order_cycle	string comment '商机成单周期',
field_kvx2b__c	string comment '商机代码',
field_5z1Wh__c	string comment '财务代码',
field_2mhq1__c__r	string comment '项目名称',
record_type	string comment '业务线',
field_6ohea__c	string comment '业务中心',
field_y1cnk__c__r	string comment '营销中心',
field_0EuIa__c	string comment '行业',
field_mk1fa__c	string comment '合同签订日期',
field_1i5qf__c	string comment '合同标题',
field_r8qu9__c__r	string comment '所属省份',
field_tfeh7__c__r	string comment '所属城市',
regional_type	string comment '区域类型',
owner__r_name	string comment '销售经理',
field_lzwcy__c__r_name	string comment '项目经理',
field_b1cxa__c__r	string comment '对方主体(甲方)',
field_r1qLi__c__r	string comment '最终业主',
field_ncq72__c	string comment '我司主体(乙方)',
field_3lv8r__c	string comment '项目方式',
field_st4vh__c	string comment '丰图是否有转包',
field_42sl8__c	string comment '合同签署路径',
field_9necq__c	string comment '是否有合格收款权',
field_iqha2__c	string comment '是否新客户',
field_g7ya1__c	string comment '是否框架合同',
field_0mn82__c	string comment '是否背靠背',
crm_customer_code	string comment 'CRM系统客户编码',
down_payment	string comment '首付款',
warranty_deposit	string comment '质保金',
down_payment_ratio	string comment '首付款比例',
quality_deposit_ratio	string comment '质保金比例',
ecp_contract_code  string comment 'CTC合同编号' 
) 
COMMENT '丰图签单业绩表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 2023.12.27 增加字段 
-- CTC合同编号 ecp_contract_code 
-- 1、BDP：dws_sign_bill_performance新增字段，
--   dwd_crm_con_base.field_eoks3__c
--   dws_collection_performance.collection_progress
--   dws_income_performance.ecp_contract_code
--   dwd_crm_con_sa_res的 field_dbszu__c
--   数字孪生_历史签单业绩表的合同编号

-- 2024.01.08 增加字段
销售经理工号   owner__r_no



-- dwd_crm_con_base_A
drop table if exists dm_gis_uimp.tmp_dwd_crm_con_base_a;
create table dm_gis_uimp.tmp_dwd_crm_con_base_a as 
select id,name,field_eoks3__c,field_cby7l__c,field_k2wb3__c,
field_8oa2s__c,
field_j7N16__c,field_2mhq1__c__r 
from dm_gis_uimp.dwd_crm_con_base  
where field_kClKF__c='1' and life_status!='invalid' 
;


-- dwd_crm_con_base_B
drop table if exists dm_gis_uimp.tmp_dwd_crm_con_base_b;
create table dm_gis_uimp.tmp_dwd_crm_con_base_b as 
select 
id,name,field_eoks3__c,farmout_amount,field_cby7l__c,cost_amount,
field_kvx2b__c,field_5z1Wh__c,field_2mhq1__c__r,record_type,field_6ohea__c,field_y1cnk__c__r,field_0EuIa__c,field_mk1fa__c,field_1i5qf__c,field_r8qu9__c__r,
field_tfeh7__c__r,regional_type,owner__r_name,field_lzwcy__c__r_name,field_b1cxa__c__r,field_r1qLi__c__r,field_ncq72__c,field_3lv8r__c,field_st4vh__c,
field_42sl8__c,field_9necq__c,field_iqha2__c,field_g7ya1__c,field_0mn82__c,owner__r_no,
inc_month  
from dm_gis_uimp.dwd_crm_con_base_mf   
where inc_month>='202301' and life_status!='invalid' 
;

--
drop table if exists dm_gis_uimp.tmp_sign_bill_performance;
create table dm_gis_uimp.tmp_sign_bill_performance as 
select 
id,contract_code,contract_amount,contract_progress,performance_date,performance_month,opp_create_time,ecp_contract_code  
from (
-- 入库方式1：dwd_crm_con_base_A
select 
id,
t0.name as contract_code,
field_k2wb3__c/10000 as contract_amount,
field_8oa2s__c as contract_progress,
substr(if(length(field_j7N16__c)=13,FROM_UNIXTIME(cast(field_j7N16__c/1000 as int)),field_j7N16__c),1,10) as performance_date,
field_8oa2s__c as performance_month,
t1.create_time as opp_create_time,
field_eoks3__c as ecp_contract_code 
from dm_gis_uimp.tmp_dwd_crm_con_base_a  as t0 
left join (select name,from_unixtime(cast(substr(create_time,0,10) as bigint),'yyyy-MM-dd') as create_time from dm_gis_uimp.dwd_crm_opp_res where life_status<>'invalid') as t1 
on t0.field_2mhq1__c__r=t1.name  

-- 入库方式2：回款业绩底表dws_collection_performance
union all 
select 
id,
contract_code,
actual_collection_amount as contract_amount,
'' as contract_progress,
substr(if(length(actual_collection_time)=13,FROM_UNIXTIME(cast(actual_collection_time/1000 as int)),actual_collection_time),1,10) as performance_date,
collection_month as performance_month,
'' as opp_create_time,
collection_progress as ecp_contract_code  
from dm_gis_uimp.dws_collection_performance where inc_day='$firstDay' and field_kClKF__c='2' 

-- 入库方式3：数字孪生_历史签单业绩表
union all 
select 
id,contract_code,contract_amount,contract_progress,performance_date,performance_month,opp_create_time,'' as ecp_contract_code  
from dm_gis_uimp.ods_history_sign_bill_performance   

-- 入库方式4：收入业绩底表dws_income_performance
union all 
select id,contract_code,
income_included_tax_amount as contract_amount,
'' as contract_progress,
revenue_time as performance_date,
revenue_month as performance_month,
'' as opp_create_time,
ecp_contract_code  
from dm_gis_uimp.dws_income_performance  where inc_day='$firstDay' and field_kClKF__c='3' 

-- 入库方式5：销售合同补充协议dwd_crm_con_sa_res
union all 
select 
name as id,
field_f2e2x__c__r as contract_code,
field_gwmlx__c/10000 as contract_amount,
'' as contract_progress,
substr(if(length(field_6p3h1__c)=13,FROM_UNIXTIME(cast(field_6p3h1__c/1000 as int)),field_6p3h1__c),1,10) as performance_date,
substr(if(length(field_6p3h1__c)=13,FROM_UNIXTIME(cast(field_6p3h1__c/1000 as int)),field_6p3h1__c),1,7) as performance_month,
'' as opp_create_time,
field_dbszu__c as ecp_contract_code 

from  dm_gis_uimp.dwd_crm_con_sa_res  where life_status<>'invalid' and field_12cdo__c='1' 

) as t 
group by id,contract_code,contract_amount,contract_progress,performance_date,performance_month,opp_create_time,ecp_contract_code  
;


-- 
insert overwrite table dm_gis_uimp.dws_sign_bill_performance partition(inc_day='$firstDay') 
select 
id,contract_code,contract_amount,contract_progress,performance_date,performance_month,
subcontracting_ratio,
self_ratio,
predicted_gross_ratio,
contract_amount*subcontracting_ratio as subcontracting_amount,
contract_amount*self_ratio as own_product_share,
contract_amount*predicted_gross_ratio as predicted_gross_amount,
contract_amount*(1-predicted_gross_ratio) as total_cost,
opp_create_time,
revenue_cycle,
field_kvx2b__c,field_5z1Wh__c,field_2mhq1__c__r,record_type,field_6ohea__c,field_y1cnk__c__r,field_0EuIa__c,field_mk1fa__c,field_1i5qf__c,field_r8qu9__c__r,
field_tfeh7__c__r,regional_type,owner__r_name,field_lzwcy__c__r_name,field_b1cxa__c__r,field_r1qLi__c__r,field_ncq72__c,field_3lv8r__c,field_st4vh__c,
field_42sl8__c,field_9necq__c,field_iqha2__c,field_g7ya1__c,field_0mn82__c,
'' as crm_customer_code,
'' as down_payment,
'' as warranty_deposit,
'' as down_payment_ratio,
'' as quality_deposit_ratio,
ecp_contract_code,
owner__r_no  
from (
select 
t0.id,contract_code,contract_amount,contract_progress,performance_date,performance_month,
farmout_amount/field_cby7l__c as subcontracting_ratio,
(field_cby7l__c-farmout_amount)/field_cby7l__c as self_ratio,
(field_cby7l__c-cost_amount)/field_cby7l__c as predicted_gross_ratio,
opp_create_time,
datediff(performance_date,opp_create_time)/30 as revenue_cycle,
field_kvx2b__c,field_5z1Wh__c,field_2mhq1__c__r,record_type,field_6ohea__c,field_y1cnk__c__r,field_0EuIa__c,field_mk1fa__c,field_1i5qf__c,field_r8qu9__c__r,
field_tfeh7__c__r,regional_type,owner__r_name,field_lzwcy__c__r_name,field_b1cxa__c__r,field_r1qLi__c__r,field_ncq72__c,field_3lv8r__c,field_st4vh__c,
field_42sl8__c,field_9necq__c,field_iqha2__c,field_g7ya1__c,field_0mn82__c,ecp_contract_code,owner__r_no    
from dm_gis_uimp.tmp_sign_bill_performance as t0 
left join dm_gis_uimp.tmp_dwd_crm_con_base_b as t1 
on t0.contract_code=t1.name and substr(replace(t0.performance_date,'-',''),1,6)=t1.inc_month 
) as t 
;


-- 4 合同归属年份
CREATE  TABLE `dm_gis_uimp.dws_contract_ownership_year`(
id	string comment 'id',
con_no	string comment '合同编号',
con_year  string comment '归属年份'
) 
COMMENT '丰图合同归属年份'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
insert overwrite table dm_gis_uimp.dws_contract_ownership_year partition(inc_day='$firstDay') 
select 
id,name as con_no,
if(field_g7ya1__c='0' and field_kfify__c='Ds0flz6NM',performance_month,collection_month) as con_year
from (select id,name,field_eoks3__c,field_g7ya1__c,field_kfify__c 
from dm_gis_uimp.dwd_crm_con_base 
where life_status!='invalid' and field_xvoay__c_filename is not null and field_xvoay__c_filename<>'' and record_type='record_5t5WI__c' ) as t0 
left join (select contract_code,min(performance_month) as performance_month from dm_gis_uimp.dws_sign_bill_performance where inc_day='$firstDay' group by contract_code) as t1 
on t0.name=t1.contract_code 
left join (
select contract_code,min(collection_month) as collection_month from dm_gis_uimp.dws_collection_performance where inc_day='$firstDay' group by contract_code
) as t2 
on t0.name=t2.contract_code
;