-- 
-- 需求方：林中莉(01423677)
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2023-06-28
-- 任务信息： ID：772870  供应商信息表
-- 

-- 供应商信息表
create table  dm_gis_uimp.ods_csv_supplier_info(
supplier_no string comment'供应商账号', 
sap_id string comment'SAP编码', 
company_name string comment'企业名称', 
province string comment'省份', 
city string comment'市', 
sup_status string comment'供应商状态', 
performance_level string comment'绩效等级', 
service_scope string comment'服务范围', 
Admitted_category string comment'准入品类',
Purchase_group string comment'采购组', 
core_competence string comment'核心能力', 
Admitted_date string comment'准入日期'
) 
COMMENT '供应商信息表'
PARTITIONED BY (`inc_month` string COMMENT '行为发生日期：yyyyMM')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

-- 
-- LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/供应商信息报表szl-0627-lzl更新数据规范.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_supplier_info partition(inc_month='202306');

LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/供应商信息报表szl_V1.1_20230717.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_supplier_info partition(inc_month='202306');

-- 20230807 改
LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/供应商信息报表szl_V1.3_20230807.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_supplier_info partition(inc_month='202306');



-- 历史供应商下单明细表（最后修改日期在0627以及之前的数据）  
-- 20230714 增加了后面3个字段
create table  dm_gis_uimp.ods_csv_supplier_history_place(
order_no string comment'采购订单编号', 
approved_date string comment'审核日期', 
sap_id string comment'供应商SAP编码', 
supplier_name string comment'供应商名称', 
history_project string comment'历史合作项目', 
purchase_amount string comment'采购含税金额',
item_code string comment'物料编码',
purchase_quantity string comment'采购数量', 
purchase_amount_notax string comment'采购不含税金额'
) 
COMMENT '历史供应商下单明细表'
PARTITIONED BY (`inc_month` string COMMENT '行为发生日期：yyyyMM')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

-- 
-- LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/历史供应商下单明细表（最后修改日期在0627以及之前的数据）.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_supplier_history_place partition(inc_month='202306');

-- 20230714 改
LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/历史供应商下单明细表（最后修改日期在0627以及之前的数据）_V1.1.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_supplier_history_place partition(inc_month='202306');


