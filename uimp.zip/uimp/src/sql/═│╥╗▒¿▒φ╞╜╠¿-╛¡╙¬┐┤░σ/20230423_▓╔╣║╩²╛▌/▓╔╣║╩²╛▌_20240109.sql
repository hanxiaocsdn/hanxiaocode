
-- 
-- 需求方：林中莉(01423677)
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2023-04-24
-- 任务信息： 731751  采购数据_先写到ods再开发dwd
-- 


-- 采购订单 PUR_PURCHASEORDER
-- 采购价目表 PUR_PRICECATEGORY
-- 存货收发存汇总表 INVENTORY-RECEIPT-DELIVERY
-- 其他出库单 OTHER-DELIVERY-ORDERS
-- 物料分组 BD_MATERIAL_GROUP
-- 销售出库单表 SALES-OUTBOUND-ORDERS

-- 20230524 SRM的采购数据
-- 询价基础信息：PurchaseEnquiryHead
-- 询价行信息：PurchaseEnquiryItem
-- 招标基础信息：PurchaseBiddingHead
-- 招标行信息：PurchaseBiddingItem
-- 竞价基础信息：PurchaseEbiddingHead
-- 竞价行信息：PurchaseEbiddingItem

-- 20230609 
-- 收料通知单  MATERIAL-RECEIPT-NOTICE、MATERIAL-RECEIPT-NOTICE-ALL
-- 期末库存维度余额调整   HS_INIV_EXCEPTION_BALANCE_RPT

---- 20230612
-- 退货通知单 RETURN-SALES-MEMO,RETURN-SALES-MEMO-ALL
-- 销售退货单 RETURN-SALES

-- 采购订单
create table if not exists  dm_gis_uimp.ods_kafka_PUR_PURCHASEORDER(
content string comment '接口返回的json数据'    
)
comment '采购数据-采购订单' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 采购价目表
create table if not exists  dm_gis_uimp.ods_kafka_PUR_PRICECATEGORY(
content string comment '接口返回的json数据'    
)
comment '采购数据-采购价目表' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 存货收发存汇总表
create table if not exists  dm_gis_uimp.ods_kafka_INVENTORY_RECEIPT_DELIVERY(
query_time string comment 'queryTime',
content string comment '接口返回的json数据'    
)
comment '采购数据-存货收发存汇总表' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 其他出库单
create table if not exists  dm_gis_uimp.ods_kafka_OTHER_DELIVERY_ORDERS(
content string comment '接口返回的json数据'    
)
comment '采购数据-其他出库单' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 物料分组
create table if not exists  dm_gis_uimp.ods_kafka_BD_MATERIAL_GROUP(
content string comment '接口返回的json数据'    
)
comment '采购数据-物料分组' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 销售出库单表
create table if not exists  dm_gis_uimp.ods_kafka_SALES_OUTBOUND_ORDERS(
content string comment '接口返回的json数据'    
)
comment '采购数据-销售出库单表' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

---- SRM

-- 询价基础信息：PurchaseEnquiryHead
create table if not exists  dm_gis_uimp.ods_kafka_PurchaseEnquiryHead(
content string comment '接口返回的json数据'    
)
comment '采购数据-SRM询价基础信息' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 询价行信息：PurchaseEnquiryItem
create table if not exists  dm_gis_uimp.ods_kafka_PurchaseEnquiryItem(
content string comment '接口返回的json数据'    
)
comment '采购数据-SRM询价行信息' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');
-- 招标基础信息：PurchaseBiddingHead
create table if not exists  dm_gis_uimp.ods_kafka_PurchaseBiddingHead(
content string comment '接口返回的json数据'    
)
comment '采购数据-SRM招标基础信息' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');
-- 招标行信息：PurchaseBiddingItem
create table if not exists  dm_gis_uimp.ods_kafka_PurchaseBiddingItem(
content string comment '接口返回的json数据'    
)
comment '采购数据-SRM招标行信息' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');
-- 竞价基础信息：PurchaseEbiddingHead
create table if not exists  dm_gis_uimp.ods_kafka_PurchaseEbiddingHead(
content string comment '接口返回的json数据'    
)
comment '采购数据-SRM竞价基础信息' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');
-- 竞价行信息：PurchaseEbiddingItem
create table if not exists  dm_gis_uimp.ods_kafka_PurchaseEbiddingItem(
content string comment '接口返回的json数据'    
)
comment '采购数据-SRM竞价行信息' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


---- 20230609 
-- 收料通知单  MATERIAL-RECEIPT-NOTICE、MATERIAL-RECEIPT-NOTICE-ALL
create table if not exists  dm_gis_uimp.ods_kafka_material_receipt_notice(
content string comment '接口返回的json数据'    
)
comment '采购数据-收料通知单' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 期末库存维度余额调整   HS_INIV_EXCEPTION_BALANCE_RPT
create table if not exists  dm_gis_uimp.ods_kafka_hs_iniv_exception_balance_rpt(
query_time string comment 'queryTime',
content string comment '接口返回的json数据'    
)
comment '采购数据-期末库存维度余额调整' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

---- 20230612
-- 退货通知单 RETURN-SALES-MEMO,RETURN-SALES-MEMO-ALL
create table if not exists  dm_gis_uimp.ods_kafka_return_sales_memo(
content string comment '接口返回的json数据'    
)
comment '采购数据-退货通知单' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 销售退货单 RETURN-SALES
create table if not exists  dm_gis_uimp.ods_kafka_return_sales(
content string comment '接口返回的json数据'    
)
comment '采购数据-销售退货单' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 
set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set mapreduce.input.fileinputformat.split.maxsize=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.rack=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.node=268435456;
set mapred.max.split.size=268435456;
set mapred.min.split.size.per.node=268435456;
set mapred.min.split.size.per.rack=268435456;
--设置jvm重用
set mapred.job.reuse.jvm.num.tasks=10;

insert overwrite table dm_gis_uimp.ods_kafka_PUR_PURCHASEORDER partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='PUR_PURCHASEORDER' 
) as t group by content,inc_day 
) as t1 where t1.content<>'[]'
;

-- 2023.12.11 ods_kafka_pur_purchaseorder 补数 2022年及之前的采购订单 （量太大，kafka不方便处理，换成线下手工导入）
-- 
CREATE  TABLE `dm_gis_uimp.ods_history_purchaseorder_plus_20231211`(
msg  string comment '' 
)
COMMENT ''
STORED AS TEXTFILE
;

LOAD DATA  INPATH '获取2022年以及之前审批通过的采购订单_20231211_puls.txt' OVERWRITE INTO TABLE dm_gis_uimp.ods_history_purchaseorder_plus_20231211;

insert into dm_gis_uimp.ods_kafka_PUR_PURCHASEORDER partition(inc_day='$firstDay')
select get_json_object(msg,'$.data') as content  
from dm_gis_uimp.ods_history_purchaseorder_plus_20231211
;

-- 2024.01.09 ods_kafka_pur_purchaseorder 补数(需要补到 20231211 分区，因为原本那天kafka是没数的 )  【汇总】需要手工推BDP_20240109.txt 
-- 
CREATE  TABLE `dm_gis_uimp.ods_history_purchaseorder_plus_20240109`(
msg  string comment '' 
)
COMMENT ''
STORED AS TEXTFILE
;

LOAD DATA  INPATH '【汇总】需要手工推BDP_20240109_plus.txt' OVERWRITE INTO TABLE dm_gis_uimp.ods_history_purchaseorder_plus_20240109;

insert into dm_gis_uimp.ods_kafka_PUR_PURCHASEORDER partition(inc_day='20231211')
select msg   
from dm_gis_uimp.ods_history_purchaseorder_plus_20240109
;





insert overwrite table dm_gis_uimp.ods_kafka_PUR_PRICECATEGORY partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag') in ('PUR_PRICECATEGORY','PUR_PURCHASEORDER-ALL')
) as t group by content,inc_day 
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_INVENTORY_RECEIPT_DELIVERY partition(inc_day)
select query_time,content,inc_day from (
select query_time,content,inc_day 
from (select 
get_json_object(msg,'$.queryTime') as query_time,
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='INVENTORY-RECEIPT-DELIVERY' 
) as t group by query_time,content,inc_day 
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_OTHER_DELIVERY_ORDERS partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='OTHER-DELIVERY-ORDERS' 
) as t group by content,inc_day 
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_BD_MATERIAL_GROUP partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='BD_MATERIAL_GROUP' 
) as t group by content,inc_day 
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_SALES_OUTBOUND_ORDERS partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='SALES-OUTBOUND-ORDERS' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

-- 20230524 增加
insert overwrite table dm_gis_uimp.ods_kafka_PurchaseEnquiryHead partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='PurchaseEnquiryHead' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_PurchaseEnquiryItem partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='PurchaseEnquiryItem' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_PurchaseBiddingHead partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='PurchaseBiddingHead' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_PurchaseBiddingItem partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='PurchaseBiddingItem' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_PurchaseEbiddingHead partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='PurchaseEbiddingHead' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_PurchaseEbiddingItem partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='PurchaseEbiddingItem' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

-- 20230609 增加
insert overwrite table dm_gis_uimp.ods_kafka_material_receipt_notice partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (
select get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag') in ('MATERIAL-RECEIPT-NOTICE','MATERIAL-RECEIPT-NOTICE-ALL')
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

insert overwrite table dm_gis_uimp.ods_kafka_hs_iniv_exception_balance_rpt partition(inc_day)
select query_time,content,inc_day from (
select query_time,content,inc_day 
from (select 
get_json_object(msg,'$.queryTime') as query_time,
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='HS_INIV_EXCEPTION_BALANCE_RPT' 
) as t group by query_time,content,inc_day 
) as t1 where t1.content<>'[]'
;


-- 20230612 增加
-- 退货通知单 RETURN-SALES-MEMO,RETURN-SALES-MEMO-ALL
insert overwrite table dm_gis_uimp.ods_kafka_return_sales_memo partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (
select get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag') in ('RETURN-SALES-MEMO','RETURN-SALES-MEMO-ALL')
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;

-- 销售退货单 RETURN-SALES
insert overwrite table dm_gis_uimp.ods_kafka_return_sales partition(inc_day)
select content,inc_day from (
select content,inc_day 
from (
select get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_kafka_issp_msg 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='RETURN-SALES' 
) as t group by content,inc_day
) as t1 where t1.content<>'[]'
;



------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- 数据解析
-- 采购订单 PUR_PURCHASEORDER
create table if not exists  dm_gis_uimp.dwc_purchase_PUR_PURCHASEORDER(
FBillNo	string comment '单据编号',
FDocumentStatus	string comment '单据状态',
FDate	string comment '采购日期',
FPurchaseOrgId_FNumber	string comment '采购组织',
FSupplierId_FNumber	string comment '供应商编码',
FSupplierId_FName	string comment '供应商名称',
FPurchaseDeptId_FNumber	string comment '采购部门_组织ID',
FPurchaseDeptId_FName	string comment '采购部门_组织全称',
FCreatorId_FUserAccount	string comment '创建人',
FCreateDate	string comment '创建日期',
FModifierId_FUserAccount	string comment '最后修改人',
FModifyDate	string comment '最后修改日期',
FApproveDate	string comment '审核日期',
FCancelDate	string comment '作废日期',
FCancelStatus	string comment '作废状态',
FPurchaserId_FNumber	string comment '采购员',
FPurchaserId_FName	string comment '采购员',
FBillTypeID_FName	string comment '单据类型',
FVersionNo	string comment '版本号',
FChangeDate	string comment '变更日期',
FChangeReason	string comment '变更原因',
FChangeStatus	string comment '变更状态',
F_TTHM_POContractNo	string comment '采购合同号',
F_TTHM_GA154	string comment 'GA154编号',
F_TTHM_HTYXQ	string comment '合同有效期(月)',
F_TTHM_HTQSDate	string comment '合同起始日期',
F_TTHM_HTZZDate	string comment '合同终止日期',
F_PYFD_GA154Amount	string comment 'GA154预计采购金额',
F_TTHM_CGHTLX	string comment '合同类型',
F_TTHM_BusinessCenter	string comment '所属业务中心',
F_TTHM_CostCenter	string comment '成本中心',
FPayConditionId_FName	string comment '付款条件',
FMaterialId_FNumber	string comment '物料编码',
FQty	string comment '采购数量',
FPrice	string comment '单价',
FEntryTaxRate	string comment '税率%',
FEntryAmount	string comment '金额',
FAllAmount	string comment '价税合计',
FStockInQty	string comment '累计入库数量',
FMaterialName	string comment '物料名称',
FMaterialType	string comment '物料类别',
FTaxPrice	string comment '含税单价',
FUnitId_FName	string comment '采购单位',
F_TTHM_ProjectCode	string comment '项目编号',
F_TTHM_EntryName	string comment '项目名称',
F_TTHM_MaterialGroup	string comment '物料分组',
FChangeFlag	string comment '变更标志',
F_TTHM_MaterialGroupNumber	string comment '物料分组编码',
F_TTHM_Amount	string comment '物料预计总金额',
FALLPAYAPPLYAMOUNT	string comment '累计付款申请金额',
f_tthm_purcontent string comment '采购内容',
f_tthm_zbnx	string comment '销售质保期(月)',
f_tthm_zbdqdate	string comment '销售质保到期日',
f_tthm_cpzbq	string comment '产品质保期(月)',
f_tthm_isspecialproject	string comment '是否专项合作价格',
f_tthm_purchasegroup	string comment '采购组',
fmaterialid_fspecification	string comment '物料规格描述',
fclosestatus	string comment '关闭状态',
fcloserid_fuseraccount	string comment '关闭人',
fclosedate	string comment '关闭日期',
fmanualclose	string comment '手工关闭',
fmrpclosestatus	string comment '业务关闭',
freceiveqty	string comment '累计收料数量',
fbasereceiveqty	string comment '累计收料数量(基本)',
fmrbqty	string comment '累计退料数量',
fbasemrbqty	string comment '累计退料数量(基本)',
f_tthm_budtaxprice	string comment '含税预算单价',
FSrcBillTypeId string COMMENT '源单类型',
FSrcBillNo string COMMENT '源单编号' 
) 
COMMENT '采购数据_采购订单dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 2023.09.20 增加字段
-- f_tthm_purcontentstring comment '采购内容',
-- f_tthm_zbnx	string comment '销售质保期(月)',
-- f_tthm_zbdqdate	string comment '销售质保到期日',
-- f_tthm_cpzbq	string comment '产品质保期(月)',
-- f_tthm_isspecialproject	string comment '是否专项合作价格',
-- f_tthm_purchasegroup	string comment '采购组',
-- fmaterialid_fspecification	string comment '物料规格描述',
-- fclosestatus	string comment '关闭状态',
-- fcloserid_fuseraccount	string comment '关闭人',
-- fclosedate	string comment '关闭日期',
-- fmanualclose	string comment '手工关闭',
-- fmrpclosestatus	string comment '业务关闭',
-- freceiveqty	string comment '累计收料数量',
-- fbasereceiveqty	string comment '累计收料数量(基本)',
-- fmrbqty	string comment '累计退料数量',
-- fbasemrbqty	string comment '累计退料数量(基本)',
-- f_tthm_budtaxprice	string comment '含税预算单价'


-- 2023.11.29 新增字段 FSrcBillTypeId string COMMENT '源单类型', FSrcBillNo string COMMENT '源单编号' 


-- 
drop table if exists dm_gis_uimp.tmp_parsing_PUR_PURCHASEORDER;
create table dm_gis_uimp.tmp_parsing_PUR_PURCHASEORDER stored as textfile as 
SELECT explode(split(regexp_replace(content,'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) AS row_data 
FROM dm_gis_uimp.ods_kafka_PUR_PURCHASEORDER where inc_day='$firstDay' and content<>'[]'
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_pur_purchaseorder/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_PUR_PURCHASEORDER partition(inc_day='$firstDay');

-- 采购价目表 PUR_PRICECATEGORY
create table if not exists  dm_gis_uimp.dwc_purchase_PUR_PRICECATEGORY(
FDocumentStatus	string comment '单据状态',
FForbidStatus	string comment '禁用',
FName	string comment '名称',
FNumber	string comment '编码',
FCreateDate	string comment '创建日期',
FModifyDate	string comment '最后修改日期',
FSupplierID_FNumber	string comment '供应商',
FSupplierID_FName	string comment '供应商',
FPriceType	string comment '价格类型',
FIsIncludedTax	string comment '含税',
FForbidDate	string comment '禁用日期',
FPriceObject	string comment '价目表对象',
FDefPriceListId	string comment '默认价目表',
FIsPriceExcludeTax	string comment '价外税',
F_TTHM_ProjectCODE	string comment '项目代码',
F_TTHM_ContractNO	string comment '合同号',
FMaterialId_FNumber	string comment '物料编码',
FEntryEffectiveDate	string comment '生效日期',
FEntryExpiryDate	string comment '失效日期',
FMaterialName	string comment '物料名称',
FToQty	string comment '至（大于等于）',
FPriceCoefficient	string comment '价格系数',
FDisableDate	string comment '业务禁用日期',
FDisableStatus	string comment '行禁用',
FUpPrice	string comment '价格上限',
FDownPrice	string comment '价格下限',
FPrice	string comment '单价',
FUnitID	string comment '计价单位',
FTaxPrice	string comment '含税单价',
FTaxRate	string comment '税率%',
FRowAuditStatus	string comment '行审核状态',
FFROMQTY	string comment '从（小于）',
FPRICEFROM	string comment '价格来源',
FMaterialGroupId	string comment '物料分组编码' 
) 
COMMENT '采购数据_采购价目表dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;


-- 
drop table if exists dm_gis_uimp.tmp_parsing_PUR_PRICECATEGORY;
create table dm_gis_uimp.tmp_parsing_PUR_PRICECATEGORY stored as textfile as 
SELECT explode(split(regexp_replace(content,'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) AS row_data 
FROM dm_gis_uimp.ods_kafka_PUR_PRICECATEGORY where inc_day='$firstDay' and content<>'[]'
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_pur_pricecategory/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_PUR_PRICECATEGORY partition(inc_day='$firstDay');



-- 存货收发存汇总表 INVENTORY-RECEIPT-DELIVERY
create table if not exists  dm_gis_uimp.dwc_purchase_INVENTORY_RECEIPT_DELIVERY(
query_time	string comment '查询时间',
FMATERIALNAME	string comment '物料名称',
FMATERIALGROUP	string comment '物料分组',
FMODEL	string comment '规格型号',
FSTOCKSTATUSNAME	string comment '库存状态',
FSTOCKId	string comment '仓库',
FACCTGRANGEID	string comment '核算范围编码',
FACCTGRANGENAME	string comment '核算范围名称',
FINITQty	string comment '期初结存数量',
FINITPrice	string comment '期初结存单价',
FINITAMOUNT	string comment '期初结存金额',
FRECEIVEQty	string comment '本期收入数量',
FRECEIVEPrice	string comment '本期收入单价',
FRECEIVEAmount	string comment '本期收入金额',
FSENDQty	string comment '本期发出数量',
FSENDPrice	string comment '本期发出单价',
FSENDAmount	string comment '本期发出金额',
FENDQty	string comment '期末结存数量',
FENDPrice	string comment '期末结存单价',
FENDAmount	string comment '期末结存金额',
FMATERIALBASEID	string comment '物料编码',
F_TTHM_BaseProperty	string comment '财务分类',
FMATERPROPERTY string comment '物料属性',
FMATERTYPE string comment '存货类别',
FLOTNO string comment '批号',
FASSIPROPNAME string comment '辅助属性',
FBOMNO string comment 'BOM版本',
FPLANNO string comment '计划跟踪号',
FOWNERNAME string comment '货主',
FSTOCKORGNAME string comment '库存组织',
FSTOCKPLACENAME string comment '仓位',
FUNITNAME string comment '基本单位' 
)
COMMENT '采购数据_存货收发存汇总表dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
drop table if exists dm_gis_uimp.tmp_parsing_INVENTORY_RECEIPT_DELIVERY;
create table dm_gis_uimp.tmp_parsing_INVENTORY_RECEIPT_DELIVERY row format delimited  fields terminated by ',' stored as textfile  as 
select query_time,row_data 
FROM (select query_time,content from dm_gis_uimp.ods_kafka_INVENTORY_RECEIPT_DELIVERY where inc_day='$firstDay' and content<>'[]' ) as t 
lateral view explode(split(regexp_replace(get_json_object(get_json_object(content,'$.Result'),'$.Rows'),'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) t1 as  row_data
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_inventory_receipt_delivery/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_INVENTORY_RECEIPT_DELIVERY partition(inc_day='$firstDay');



-- 其他出库单 OTHER-DELIVERY-ORDERS
create table if not exists  dm_gis_uimp.dwc_purchase_OTHER_DELIVERY_ORDERS(
FBillNo	string comment '单据编号',
FDocumentStatus	string comment '单据状态',
FDate	string comment '出库日期',
FBillTypeID	string comment '单据类型',
FCustId	string comment '客户',
FCreatorId_FUserAccount	string comment '创建人',
FCreateDate	string comment '创建日期',
FModifyDate	string comment '最后修改日期',
FCancelStatus	string comment '作废状态',
FCancelDate	string comment '作废日期',
FApproveDate	string comment '审核日期',
F_TTHM_PushToYJDF	string comment '一件代发',
F_TTHM_Text_CostCenter	string comment '成本中心',
F_TTHM_Text_BusinessCenter	string comment '所属业务中心',
FMaterialId	string comment '物料编码',
FMaterialName	string comment '物料名称',
FStockId	string comment '发货仓库',
FUnitID	string comment '单位',
FModel	string comment '规格型号',
F_TTHM_ProjectCode	string comment '项目编号',
F_TTHM_EntryName	string comment '项目名称',
F_TTHM_ReturncourierNo	string comment '运单号',
F_TTHM_CWFLS	string comment '财务分类',
F_TTHM_XSHTH	string comment '销售合同号',
F_TTHM_BaseProperty	string comment '存货类别',
F_TTHM_SJDM	string comment '商机代码',
F_TTHM_DeliveryEfficiency	string comment '发货时效',	
F_TTHM_Datetime_CKSQDTime	 string comment '出库申请单审核时间',
FDeptId_FNumber	string comment '领料部门',
F_TTHM_CKLX	string comment '其他出库类型',
FQty	string comment '实发数量',
FJoinQty	string comment '关联数量',
FSrcBillNo	string comment '源单编号' 
)
COMMENT '采购数据_其他出库单dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
drop table if exists dm_gis_uimp.tmp_parsing_OTHER_DELIVERY_ORDERS;
create table dm_gis_uimp.tmp_parsing_OTHER_DELIVERY_ORDERS stored as textfile as 
SELECT explode(split(regexp_replace(content,'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) AS row_data 
FROM dm_gis_uimp.ods_kafka_OTHER_DELIVERY_ORDERS where inc_day='$firstDay' and content<>'[]' 
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_other_delivery_orders/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_other_delivery_orders partition(inc_day='$firstDay');


-- 物料分组 BD_MATERIAL_GROUP
create table if not exists  dm_gis_uimp.dwc_purchase_BD_MATERIAL_GROUP(
FID	string comment '分组内码',
FNUMBER	string comment '分组编码',
FGROUPID	string comment '物料分组',
FPARENTID	string comment '父分组内码',
FFULLPARENTID	string comment '全路径父分组内码',
FLEFT	string comment 'FLEFT',
FRIGHT	string comment 'FRIGHT',
FNAME	string comment '物料分组名称',
FDESCRIPTION	string comment '物料分组描述'
)
COMMENT '采购数据_物料分组dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;


-- 
insert overwrite table dm_gis_uimp.dwc_purchase_BD_MATERIAL_GROUP partition(inc_day='$firstDay') 
select 
get_json_object(a_json,'$.FID') as FID,
get_json_object(a_json,'$.FNUMBER') as FNUMBER,
get_json_object(a_json,'$.FGROUPID') as FGROUPID,
get_json_object(a_json,'$.FPARENTID') as FPARENTID,
get_json_object(a_json,'$.FFULLPARENTID') as FFULLPARENTID,
get_json_object(a_json,'$.FLEFT') as FLEFT,
get_json_object(a_json,'$.FRIGHT') as FRIGHT,
get_json_object(a_json,'$.FNAME') as FNAME,
get_json_object(a_json,'$.FDESCRIPTION') as FDESCRIPTION 
from
(
select split(regexp_replace(regexp_extract(get_json_object(get_json_object(content,'$.Result'),'$.NeedReturnData'),'(\\[)(.*?)(\\])',2),'\\},\\{','\\}|\\{'),'\\|') as a_list
from dm_gis_uimp.ods_kafka_BD_MATERIAL_GROUP where inc_day='$firstDay'  and content<>'[]' 
) t
lateral view explode(a_list) t1 as a_json
;



-- 销售出库单表 SALES-OUTBOUND-ORDERS
create table if not exists  dm_gis_uimp.dwc_purchase_SALES_OUTBOUND_ORDERS(
F_TTHM_Text_CostCenter	string comment '成本中心',
FDate	string comment '出库日期',
FCreatorId_FUserAccount	string comment '创建人',
FCreateDate	string comment '创建日期',
FBillNo	string comment '单据编号',
FBillTypeID	string comment '单据类型',
FDocumentStatus	string comment '单据状态',
F_TTHM_DeliveryEfficiency	string comment '发货时效/H',
F_TTHM_Datetime_FHTZD	string comment '发货通知单审核时间',
FCustomerID	string comment '客户',
F_TTHM_PushToYJDF	string comment '是否推一件代发',
F_TTHM_Text_BusinessCenter	string comment '所属业务中心',
FCarriageNO	string comment '运单号',
FModifyDate	string comment '最后修改日期',
FCancelDate	string comment '作废日期',
FApproveDate	string comment '审核日期',
FCancelStatus	string comment '作废状态',
F_TTHM_CWFLS	string comment '财务分类',
FStockID	string comment '仓库',
F_TTHM_CHLB	string comment '存货类别',
FMateriaModel	string comment '规格型号',
F_TTHM_CustPONum	string comment '客户合同号',
FUnitID	string comment '库存单位',
F_TTHM_SrcSONum	string comment '来源销售单号',
F_TTHM_SrcSOSeq	string comment '来源销售行号',
F_TTHM_SJDM	string comment '商机代码',
FMaterialID	string comment '物料编码',
FMaterialName	string comment '物料名称',
F_TTHM_ProjectCode	string comment '项目编号',
F_TTHM_EntryName	string comment '项目名称',
F_TTHM_DNNumber string comment '发货通知单号',
FSaleDeptID_FNumber	string comment '销售部门',
FJoinInStockQty	string comment '关联入库数量',
FReturnQty	string comment '关联退货数量',
FRealQty	string comment '实发数量',
FActQty	string comment '实收数量'
)
COMMENT '采购数据_销售出库单表dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
drop table if exists dm_gis_uimp.tmp_parsing_SALES_OUTBOUND_ORDERS;
create table dm_gis_uimp.tmp_parsing_SALES_OUTBOUND_ORDERS stored as textfile as 
SELECT explode(split(regexp_replace(content,'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) AS row_data 
FROM dm_gis_uimp.ods_kafka_SALES_OUTBOUND_ORDERS where inc_day='$firstDay' and content<>'[]'
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_sales_outbound_orders/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_sales_outbound_orders partition(inc_day='$firstDay');


---- 20230609 
-- 收料通知单  MATERIAL-RECEIPT-NOTICE、MATERIAL-RECEIPT-NOTICE-ALL
create table if not exists  dm_gis_uimp.dwc_purchase_material_receipt_notice(
FBillNo	string comment '单据编号',
FDocumentStatus	string comment '单据状态',
FCreateDate	string comment '创建日期',
FModifyDate	string comment '最后修改日期',
FApproveDate	string comment '审核日期',
FCancelDate	string comment '作废日期',
F_TTHM_POContractNo	string comment '采购合同号',
F_PYFD_Text	string comment '发货通知单号',
F_TTHM_Date	string comment '供应商发货日期' 
) 
COMMENT '采购数据_收料通知单dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
drop table if exists dm_gis_uimp.tmp_parsing_material_receipt_notice;
create table dm_gis_uimp.tmp_parsing_material_receipt_notice stored as textfile as 
SELECT explode(split(regexp_replace(content,'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) AS row_data 
FROM dm_gis_uimp.ods_kafka_material_receipt_notice where inc_day='$firstDay' and content<>'[]'
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_material_receipt_notice/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_material_receipt_notice partition(inc_day='$firstDay');



-- 期末库存维度余额调整   HS_INIV_EXCEPTION_BALANCE_RPT 
create table if not exists  dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt(
queryTime	string comment'查询时间',
FMaterialId	string comment'物料编码',
FMATERIALNAME	string comment'物料名称',
FMATERPROPERTY	string comment'物料属性',
FMATERTYPE	string comment'存货类别',
FMATERIALGROUP	string comment'物料分组',
FMODEL	string comment'规格型号',
FSTOCKSTATUS	string comment'库存状态',
FLOT	string comment'批号',
FAUXPROP	string comment'辅助属性',
FBOM	string comment'BOM版本',
FMTONO	string comment'计划跟踪号',
FOWNER	string comment'货主',
FSTOCKORG	string comment'库存组织',
FSTOCK	string comment'仓库',
FSTOCKLOC	string comment'仓位',
FACCTGRANGEID	string comment'核算范围编码',
FACCTGRANGENAME	string comment'核算范围名称',
FUNIT	string comment'基本单位',
FEXPENSENUMBER	string comment'费用项目编码',
FEXPENSENAME	string comment'费用项目名称',
FQTY	string comment'期末数量',
FPrice	string comment'库存维度期末单价',
FAmount	string comment'库存维度期末金额',
FACCTGDIMEPrice	string comment'核算维度期末单价',
FACCTGDIMEAmount	string comment'核算维度期末金额',
FDIFFAMOUNT	string comment'金额差异',
FADJAMOUNT	string comment'调整金额',
FAdjustBillNo	string comment'成本调整单编号',
FADJUSTBILLSEQ	string comment'成本调整单行号'
)
COMMENT '采购数据_期末库存维度余额调整dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
drop table if exists dm_gis_uimp.tmp_parsing_hs_iniv_exception_balance_rpt;
create table dm_gis_uimp.tmp_parsing_hs_iniv_exception_balance_rpt row format delimited  fields terminated by ',' stored as textfile  as 
select query_time,row_data 
FROM (select query_time,content from dm_gis_uimp.ods_kafka_hs_iniv_exception_balance_rpt where inc_day='$firstDay' and content<>'[]' ) as t 
lateral view explode(split(regexp_replace(get_json_object(get_json_object(content,'$.Result'),'$.Rows'),'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) t1 as  row_data
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_hs_iniv_exception_balance_rpt/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt partition(inc_day='$firstDay');

-- 20230612 
-- 退货通知单 RETURN-SALES-MEMO,RETURN-SALES-MEMO-ALL
create table if not exists  dm_gis_uimp.dwc_purchase_return_sales_memo(
FBillNo	string comment'	单据编号',
FDocumentStatus	string comment'	单据状态',
FSaledeptid_FNumber	string comment'	销售部门',
FCancelDate	string comment'	作废日期',
FCancelStatus	string comment'	作废状态',
FModifyDate	string comment'	最后修改日期',
FApproveDate	string comment'	审核日期',
FCreateDate	string comment'	创建日期',
FMaterialId_FNumber	string comment'	物料编码',
FMaterialName	string comment'	物料名称',
FQty	string comment'	退货数量',
FBaseJoinretQty	string comment'	运维提单寄回数',
FBaseSumRetQty	string comment'	仓库实收数',
FRmType	string comment'	退货类型',
F_TTHM_WLMRGYS	string comment'	供应商',
F_TTHM_Returned	string comment'	退回件对应项目名称',
FDate	string comment'	日期',
FRetcustId_FName	string comment'	退货客户',
F_TTHM_Text_BusinessCenter	string comment'	所属业务中心',
FStockId	string comment'	仓库',
F_TTHM_CustPONum	string comment'	来源退货合同号',
F_TTHM_ProjectCode	string comment'	项目编号',
F_TTHM_EntryName	string comment'	项目名称',
F_PYFD_Qty2	string comment'	仓库实发数',
F_TTHM_Combo_Symptoms	string comment'	故障现象'
)
COMMENT '采购数据_退货通知单dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
drop table if exists dm_gis_uimp.tmp_parsing_return_sales_memoe;
create table dm_gis_uimp.tmp_parsing_return_sales_memoe stored as textfile as 
SELECT explode(split(regexp_replace(content,'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) AS row_data 
FROM dm_gis_uimp.ods_kafka_return_sales_memo where inc_day='$firstDay' and content<>'[]'
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_return_sales_memoe/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_return_sales_memo partition(inc_day='$firstDay');



-- 销售退货单 RETURN-SALES
create table if not exists  dm_gis_uimp.dwc_purchase_return_sales(
FBillNo	string comment'	单据编号',
FDocumentStatus	string comment'	单据状态',
FRetcustId_FName	string comment'	退货客户',
FSaledeptid_FNumber	string comment'	销售部门',
FCreateDate	string comment'	创建日期',
FModifyDate	string comment'	最后修改日期',
FApproveDate	string comment'	审核日期',
FCancelDate	string comment'	作废日期',
FCancelStatus	string comment'	作废状态',
F_TTHM_Text_BusinessCenter	string comment'	所属业务中心',
FMaterialId_FNumber	string comment'	物料编码',
FMaterialName	string comment'	物料名称',
FRealQty	string comment'	退货数量',
FStockId	string comment'	仓库',
FReturnType	string comment'	退货类型',
F_TTHM_ProjectCode	string comment'	项目编号',
F_TTHM_SHDBQty	string comment'	运维提单寄回数',
F_TTHM_LJSHDBQty	string comment'	仓库实收数',
F_TTHM_QTCKLJQty	string comment'	仓库实发数',
F_Aqa_MXCustPONum	string comment'	来源退货合同号',
F_TTHM_WLMRGYS	string comment'	供应商',
F_TTHM_Returned	string comment'	退回件对应项目名称',
FDate	string comment'	退货日期',
F_TTHM_Combo	string comment'	初步责任判定',
FLot	string comment'	批号'
)
COMMENT '采购数据_销售退货单dwc'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;


-- 
drop table if exists dm_gis_uimp.tmp_parsing_return_sales;
create table dm_gis_uimp.tmp_parsing_return_sales stored as textfile as 
SELECT explode(split(regexp_replace(content,'^\\[\\[|\\]\\]$',''),'\\]\\,\\[')) AS row_data 
FROM dm_gis_uimp.ods_kafka_return_sales where inc_day='$firstDay' and content<>'[]'
;

LOAD DATA  INPATH 'hdfs://sfbd/user/hive/warehouse/ft/DM/dm_gis_uimp/tmp_parsing_return_sales/000000_0' OVERWRITE INTO TABLE dm_gis_uimp.dwc_purchase_return_sales partition(inc_day='$firstDay');





------------------------------------------------------------------------------------
------------------------------------------------------------------------------------
-- dwd 开发
-- 采购订单 PUR_PURCHASEORDER
create table if not exists  dm_gis_uimp.dwd_purchase_PUR_PURCHASEORDER(
FBillNo	string comment '单据编号',
FDocumentStatus	string comment '单据状态',
FDate	string comment '采购日期',
FPurchaseOrgId_FNumber	string comment '采购组织',
FSupplierId_FNumber	string comment '供应商编码',
FSupplierId_FName	string comment '供应商名称',
FPurchaseDeptId_FNumber	string comment '采购部门_组织ID',
FPurchaseDeptId_FName	string comment '采购部门_组织全称',
FCreatorId_FUserAccount	string comment '创建人',
FCreateDate	string comment '创建日期',
FModifierId_FUserAccount	string comment '最后修改人',
FModifyDate	string comment '最后修改日期',
FApproveDate	string comment '审核日期',
FCancelDate	string comment '作废日期',
FCancelStatus	string comment '作废状态',
FPurchaserId_FNumber	string comment '采购员',
FPurchaserId_FName	string comment '采购员',
FBillTypeID_FName	string comment '单据类型',
FVersionNo	string comment '版本号',
FChangeDate	string comment '变更日期',
FChangeReason	string comment '变更原因',
FChangeStatus	string comment '变更状态',
F_TTHM_POContractNo	string comment '采购合同号',
F_TTHM_GA154	string comment 'GA154编号',
F_TTHM_HTYXQ	string comment '合同有效期(月)',
F_TTHM_HTQSDate	string comment '合同起始日期',
F_TTHM_HTZZDate	string comment '合同终止日期',
F_PYFD_GA154Amount	string comment 'GA154预计采购金额',
F_TTHM_CGHTLX	string comment '合同类型',
F_TTHM_BusinessCenter	string comment '所属业务中心',
F_TTHM_CostCenter	string comment '成本中心',
FPayConditionId_FName	string comment '付款条件',
FMaterialId_FNumber	string comment '物料编码',
FQty	string comment '采购数量',
FPrice	string comment '单价',
FEntryTaxRate	string comment '税率%',
FEntryAmount	string comment '金额',
FAllAmount	string comment '价税合计',
FStockInQty	string comment '累计入库数量',
FMaterialName	string comment '物料名称',
FMaterialType	string comment '物料类别',
FTaxPrice	string comment '含税单价',
FUnitId_FName	string comment '采购单位',
F_TTHM_ProjectCode	string comment '项目编号',
F_TTHM_EntryName	string comment '项目名称',
F_TTHM_MaterialGroup	string comment '物料分组',
FChangeFlag	string comment '变更标志',
F_TTHM_MaterialGroupNumber	string comment '物料分组编码',
F_TTHM_Amount	string comment '物料预计总金额',
FALLPAYAPPLYAMOUNT	string comment '累计付款申请金额',
f_tthm_purcontent string comment '采购内容',
f_tthm_zbnx	string comment '销售质保期(月)',
f_tthm_zbdqdate	string comment '销售质保到期日',
f_tthm_cpzbq	string comment '产品质保期(月)',
f_tthm_isspecialproject	string comment '是否专项合作价格',
f_tthm_purchasegroup	string comment '采购组',
fmaterialid_fspecification	string comment '物料规格描述',
fclosestatus	string comment '关闭状态',
fcloserid_fuseraccount	string comment '关闭人',
fclosedate	string comment '关闭日期',
fmanualclose	string comment '手工关闭',
fmrpclosestatus	string comment '业务关闭',
freceiveqty	string comment '累计收料数量',
fbasereceiveqty	string comment '累计收料数量(基本)',
fmrbqty	string comment '累计退料数量',
fbasemrbqty	string comment '累计退料数量(基本)',
f_tthm_budtaxprice	string comment '含税预算单价',
FSrcBillTypeId string COMMENT '源单类型',
FSrcBillNo string COMMENT '源单编号'
) 
COMMENT '采购数据_采购订单dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 2023.11.29 新增字段   ①　源单类型 FSrcBillTypeId  ②　源单编号 FSrcBillNo
alter table dm_gis_uimp.dwd_purchase_PUR_PURCHASEORDER add columns (FSrcBillTypeId string COMMENT '源单类型') cascade;
alter table dm_gis_uimp.dwd_purchase_PUR_PURCHASEORDER add columns (FSrcBillNo string COMMENT '源单编号') cascade;

-- 
drop table if exists dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_last1;
create table dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_last1 stored as parquet as 
select 
FBillNo,FModifyDate,inc_day 
from (select FBillNo,FModifyDate,inc_day,
row_number() over(partition by FBillNo order by FModifyDate desc,inc_day desc) as rn 
from dm_gis_uimp.dwc_purchase_PUR_PURCHASEORDER where inc_day>'20230815' and inc_day<='$firstDay' and FBillNo<>'[]' 
) as t 
where t.rn=1
;

-- 
insert overwrite table dm_gis_uimp.dwd_purchase_PUR_PURCHASEORDER partition(inc_day='$firstDay')
select 
t0.FBillNo,FDocumentStatus,FDate,FPurchaseOrgId_FNumber,FSupplierId_FNumber,FSupplierId_FName,FPurchaseDeptId_FNumber,FPurchaseDeptId_FName,FCreatorId_FUserAccount,FCreateDate,
FModifierId_FUserAccount,t0.FModifyDate,FApproveDate,FCancelDate,FCancelStatus,FPurchaserId_FNumber,FPurchaserId_FName,FBillTypeID_FName,FVersionNo,FChangeDate,FChangeReason,FChangeStatus,F_TTHM_POContractNo,
F_TTHM_GA154,F_TTHM_HTYXQ,F_TTHM_HTQSDate,F_TTHM_HTZZDate,F_PYFD_GA154Amount,F_TTHM_CGHTLX,F_TTHM_BusinessCenter,F_TTHM_CostCenter,FPayConditionId_FName,FMaterialId_FNumber,FQty,FPrice,FEntryTaxRate,FEntryAmount,
FAllAmount,FStockInQty,FMaterialName,FMaterialType,FTaxPrice,FUnitId_FName,F_TTHM_ProjectCode,F_TTHM_EntryName,F_TTHM_MaterialGroup,FChangeFlag,F_TTHM_MaterialGroupNumber,F_TTHM_Amount,FALLPAYAPPLYAMOUNT,
f_tthm_purcontent,f_tthm_zbnx,f_tthm_zbdqdate,f_tthm_cpzbq,f_tthm_isspecialproject,f_tthm_purchasegroup,fmaterialid_fspecification,
fclosestatus,fcloserid_fuseraccount,fclosedate,fmanualclose,fmrpclosestatus,freceiveqty,fbasereceiveqty,fmrbqty,fbasemrbqty,f_tthm_budtaxprice,
FSrcBillTypeId,FSrcBillNo  
from (
select FBillNo,FDocumentStatus,FDate,FPurchaseOrgId_FNumber,FSupplierId_FNumber,FSupplierId_FName,FPurchaseDeptId_FNumber,FPurchaseDeptId_FName,FCreatorId_FUserAccount,FCreateDate,
FModifierId_FUserAccount,FModifyDate,FApproveDate,FCancelDate,FCancelStatus,FPurchaserId_FNumber,FPurchaserId_FName,FBillTypeID_FName,FVersionNo,FChangeDate,FChangeReason,FChangeStatus,F_TTHM_POContractNo,
F_TTHM_GA154,F_TTHM_HTYXQ,F_TTHM_HTQSDate,F_TTHM_HTZZDate,F_PYFD_GA154Amount,F_TTHM_CGHTLX,F_TTHM_BusinessCenter,F_TTHM_CostCenter,FPayConditionId_FName,FMaterialId_FNumber,FQty,FPrice,FEntryTaxRate,FEntryAmount,
FAllAmount,FStockInQty,FMaterialName,FMaterialType,FTaxPrice,FUnitId_FName,F_TTHM_ProjectCode,F_TTHM_EntryName,F_TTHM_MaterialGroup,FChangeFlag,F_TTHM_MaterialGroupNumber,F_TTHM_Amount,FALLPAYAPPLYAMOUNT,
f_tthm_purcontent,f_tthm_zbnx,f_tthm_zbdqdate,f_tthm_cpzbq,f_tthm_isspecialproject,f_tthm_purchasegroup,fmaterialid_fspecification,
fclosestatus,fcloserid_fuseraccount,fclosedate,fmanualclose,fmrpclosestatus,freceiveqty,fbasereceiveqty,fmrbqty,fbasemrbqty,f_tthm_budtaxprice,
FSrcBillTypeId,FSrcBillNo,inc_day  
from dm_gis_uimp.dwc_purchase_PUR_PURCHASEORDER where inc_day>'20230815' and inc_day<='$firstDay' and FBillNo<>'[]' ) as t0 
left join dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_last1 as t1 
on t0.FBillNo=t1.FBillNo and t0.FModifyDate=t1.FModifyDate and t0.inc_day=t1.inc_day 
where t1.FBillNo is not null
;


-- 采购价目表 PUR_PRICECATEGORY
create table if not exists  dm_gis_uimp.dwd_purchase_PUR_PRICECATEGORY(
FDocumentStatus	string comment '单据状态',
FForbidStatus	string comment '禁用',
FName	string comment '名称',
FNumber	string comment '编码',
FCreateDate	string comment '创建日期',
FModifyDate	string comment '最后修改日期',
FSupplierID_FNumber	string comment '供应商',
FSupplierID_FName	string comment '供应商',
FPriceType	string comment '价格类型',
FIsIncludedTax	string comment '含税',
FForbidDate	string comment '禁用日期',
FPriceObject	string comment '价目表对象',
FDefPriceListId	string comment '默认价目表',
FIsPriceExcludeTax	string comment '价外税',
F_TTHM_ProjectCODE	string comment '项目代码',
F_TTHM_ContractNO	string comment '合同号',
FMaterialId_FNumber	string comment '物料编码',
FEntryEffectiveDate	string comment '生效日期',
FEntryExpiryDate	string comment '失效日期',
FMaterialName	string comment '物料名称',
FToQty	string comment '至（大于等于）',
FPriceCoefficient	string comment '价格系数',
FDisableDate	string comment '业务禁用日期',
FDisableStatus	string comment '行禁用',
FUpPrice	string comment '价格上限',
FDownPrice	string comment '价格下限',
FPrice	string comment '单价',
FUnitID	string comment '计价单位',
FTaxPrice	string comment '含税单价',
FTaxRate	string comment '税率%',
FRowAuditStatus	string comment '行审核状态',
FFROMQTY	string comment '从（小于）',
FPRICEFROM	string comment '价格来源',
FMaterialGroupId	string comment '物料分组编码',
inc_date string comment 'inc_day日期'
) 
COMMENT '采购数据_采购价目表dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
insert overwrite table dm_gis_uimp.dwd_purchase_PUR_PRICECATEGORY partition(inc_day='$firstDay')
select FDocumentStatus,FForbidStatus,FName,t0.FNumber,FCreateDate,FModifyDate,FSupplierID_FNumber,FSupplierID_FName,FPriceType,FIsIncludedTax,
FForbidDate,FPriceObject,FDefPriceListId,FIsPriceExcludeTax,F_TTHM_ProjectCODE,F_TTHM_ContractNO,FMaterialId_FNumber,FEntryEffectiveDate,FEntryExpiryDate,
FMaterialName,FToQty,FPriceCoefficient,FDisableDate,FDisableStatus,FUpPrice,FDownPrice,FPrice,FUnitID,FTaxPrice,FTaxRate,FRowAuditStatus,FFROMQTY,FPRICEFROM,FMaterialGroupId,
t0.inc_day as  inc_date  
from (
select FDocumentStatus,FForbidStatus,FName,FNumber,FCreateDate,FModifyDate,FSupplierID_FNumber,FSupplierID_FName,FPriceType,FIsIncludedTax,
FForbidDate,FPriceObject,FDefPriceListId,FIsPriceExcludeTax,F_TTHM_ProjectCODE,F_TTHM_ContractNO,FMaterialId_FNumber,FEntryEffectiveDate,FEntryExpiryDate,
FMaterialName,FToQty,FPriceCoefficient,FDisableDate,FDisableStatus,FUpPrice,FDownPrice,FPrice,FUnitID,FTaxPrice,FTaxRate,FRowAuditStatus,FFROMQTY,FPRICEFROM,FMaterialGroupId,
inc_day 
from dm_gis_uimp.dwc_purchase_PUR_PRICECATEGORY where inc_day>='20230421' and inc_day<='$firstDay' and FDocumentStatus<>'[]' ) as t0 
left join (
select FNumber,max(inc_day) as inc_day from dm_gis_uimp.dwc_purchase_PUR_PRICECATEGORY where inc_day>='20230421' and inc_day<='$firstDay' and FNumber<>'[]' group by FNumber 
) as t1 
on t0.inc_day=t1.inc_day and t0.FNumber=t1.FNumber 
where t1.inc_day is not null 
;


-- 存货收发存汇总表 INVENTORY-RECEIPT-DELIVERY
create table if not exists  dm_gis_uimp.dwd_purchase_INVENTORY_RECEIPT_DELIVERY(
query_time	string comment '查询时间',
FMATERIALNAME	string comment '物料名称',
FMATERIALGROUP	string comment '物料分组',
FMODEL	string comment '规格型号',
FSTOCKSTATUSNAME	string comment '库存状态',
FSTOCKId	string comment '仓库',
FACCTGRANGEID	string comment '核算范围编码',
FACCTGRANGENAME	string comment '核算范围名称',
FINITQty	string comment '期初结存数量',
FINITPrice	string comment '期初结存单价',
FINITAMOUNT	string comment '期初结存金额',
FRECEIVEQty	string comment '本期收入数量',
FRECEIVEPrice	string comment '本期收入单价',
FRECEIVEAmount	string comment '本期收入金额',
FSENDQty	string comment '本期发出数量',
FSENDPrice	string comment '本期发出单价',
FSENDAmount	string comment '本期发出金额',
FENDQty	string comment '期末结存数量',
FENDPrice	string comment '期末结存单价',
FENDAmount	string comment '期末结存金额',
FMATERIALBASEID	string comment '物料编码',
F_TTHM_BaseProperty	string comment '财务分类',
FMATERPROPERTY string comment '物料属性',
FMATERTYPE string comment '存货类别',
FLOTNO string comment '批号',
FASSIPROPNAME string comment '辅助属性',
FBOMNO string comment 'BOM版本',
FPLANNO string comment '计划跟踪号',
FOWNERNAME string comment '货主',
FSTOCKORGNAME string comment '库存组织',
FSTOCKPLACENAME string comment '仓位',
FUNITNAME string comment '基本单位'  
)
COMMENT '采购数据_存货收发存汇总表dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
insert overwrite table dm_gis_uimp.dwd_purchase_INVENTORY_RECEIPT_DELIVERY partition(inc_day='$firstDay')
select 
query_time,FMATERIALNAME,FMATERIALGROUP,FMODEL,FSTOCKSTATUSNAME,FSTOCKId,FACCTGRANGEID,FACCTGRANGENAME,
FINITQty,FINITPrice,FINITAMOUNT,FRECEIVEQty,FRECEIVEPrice,FRECEIVEAmount,FSENDQty,FSENDPrice,FSENDAmount,FENDQty,FENDPrice,FENDAmount,FMATERIALBASEID,F_TTHM_BaseProperty,
FMATERPROPERTY,FMATERTYPE,FLOTNO,FASSIPROPNAME,FBOMNO,FPLANNO,FOWNERNAME,FSTOCKORGNAME,FSTOCKPLACENAME,FUNITNAME   
from dm_gis_uimp.dwc_purchase_INVENTORY_RECEIPT_DELIVERY where inc_day='$firstDay'
;



-- 其他出库单 OTHER-DELIVERY-ORDERS
create table if not exists  dm_gis_uimp.dwd_purchase_OTHER_DELIVERY_ORDERS(
FBillNo	string comment '单据编号',
FDocumentStatus	string comment '单据状态',
FDate	string comment '出库日期',
FBillTypeID	string comment '单据类型',
FCustId	string comment '客户',
FCreatorId_FUserAccount	string comment '创建人',
FCreateDate	string comment '创建日期',
FModifyDate	string comment '最后修改日期',
FCancelStatus	string comment '作废状态',
FCancelDate	string comment '作废日期',
FApproveDate	string comment '审核日期',
F_TTHM_PushToYJDF	string comment '一件代发',
F_TTHM_Text_CostCenter	string comment '成本中心',
F_TTHM_Text_BusinessCenter	string comment '所属业务中心',
FMaterialId	string comment '物料编码',
FMaterialName	string comment '物料名称',
FStockId	string comment '发货仓库',
FUnitID	string comment '单位',
FModel	string comment '规格型号',
F_TTHM_ProjectCode	string comment '项目编号',
F_TTHM_EntryName	string comment '项目名称',
F_TTHM_ReturncourierNo	string comment '运单号',
F_TTHM_CWFLS	string comment '财务分类',
F_TTHM_XSHTH	string comment '销售合同号',
F_TTHM_BaseProperty	string comment '存货类别',
F_TTHM_SJDM	string comment '商机代码',
F_TTHM_DeliveryEfficiency	string comment '发货时效',	
F_TTHM_Datetime_CKSQDTime	 string comment '出库申请单审核时间',
FDeptId_FNumber	string comment '领料部门',
F_TTHM_CKLX	string comment '其他出库类型',
FQty	string comment '实发数量',
FJoinQty	string comment '关联数量',
FSrcBillNo	string comment '源单编号',
inc_date string comment 'inc_day日期'
)
COMMENT '采购数据_其他出库单dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
insert overwrite table dm_gis_uimp.dwd_purchase_OTHER_DELIVERY_ORDERS partition(inc_day='$firstDay')
select t0.FBillNo,FDocumentStatus,FDate,FBillTypeID,FCustId,FCreatorId_FUserAccount,FCreateDate,FModifyDate,FCancelStatus,FCancelDate,FApproveDate,F_TTHM_PushToYJDF,F_TTHM_Text_CostCenter,
F_TTHM_Text_BusinessCenter,FMaterialId,FMaterialName,FStockId,FUnitID,FModel,F_TTHM_ProjectCode,F_TTHM_EntryName,F_TTHM_ReturncourierNo,F_TTHM_CWFLS,F_TTHM_XSHTH,F_TTHM_BaseProperty,F_TTHM_SJDM,F_TTHM_DeliveryEfficiency,F_TTHM_Datetime_CKSQDTime,
FDeptId_FNumber,F_TTHM_CKLX,FQty,FJoinQty,FSrcBillNo,
t0.inc_day as  inc_date 
from (
select FBillNo,FDocumentStatus,FDate,FBillTypeID,FCustId,FCreatorId_FUserAccount,FCreateDate,FModifyDate,FCancelStatus,FCancelDate,FApproveDate,F_TTHM_PushToYJDF,F_TTHM_Text_CostCenter,
F_TTHM_Text_BusinessCenter,FMaterialId,FMaterialName,FStockId,FUnitID,FModel,F_TTHM_ProjectCode,F_TTHM_EntryName,F_TTHM_ReturncourierNo,F_TTHM_CWFLS,F_TTHM_XSHTH,F_TTHM_BaseProperty,F_TTHM_SJDM,F_TTHM_DeliveryEfficiency,F_TTHM_Datetime_CKSQDTime,
FDeptId_FNumber,F_TTHM_CKLX,FQty,FJoinQty,FSrcBillNo,
inc_day 
from dm_gis_uimp.dwc_purchase_OTHER_DELIVERY_ORDERS where inc_day>='20230421' and inc_day<='$firstDay' and FBillNo<>'[]') as t0 
left join (
select FBillNo,max(inc_day) as inc_day from dm_gis_uimp.dwc_purchase_OTHER_DELIVERY_ORDERS where inc_day>='20230421' and inc_day<='$firstDay' and FBillNo<>'[]' group by FBillNo 
) as t1 
on t0.inc_day=t1.inc_day and t0.FBillNo=t1.FBillNo 
where t1.inc_day is not null 
;



-- 物料分组 BD_MATERIAL_GROUP
create table if not exists  dm_gis_uimp.dwd_purchase_BD_MATERIAL_GROUP(
FID	string comment '分组内码',
FNUMBER	string comment '分组编码',
FGROUPID	string comment '物料分组',
FPARENTID	string comment '父分组内码',
FFULLPARENTID	string comment '全路径父分组内码',
FLEFT	string comment 'FLEFT',
FRIGHT	string comment 'FRIGHT',
FNAME	string comment '物料分组名称',
FDESCRIPTION	string comment '物料分组描述'
)
COMMENT '采购数据_物料分组dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
insert overwrite table dm_gis_uimp.dwd_purchase_BD_MATERIAL_GROUP partition(inc_day='$firstDay')
select 
FID,FNUMBER,FGROUPID,FPARENTID,FFULLPARENTID,FLEFT,FRIGHT,FNAME,FDESCRIPTION
from dm_gis_uimp.dwc_purchase_BD_MATERIAL_GROUP where inc_day='$firstDay'
;



-- 销售出库单表 SALES-OUTBOUND-ORDERS
create table if not exists  dm_gis_uimp.dwd_purchase_SALES_OUTBOUND_ORDERS(
F_TTHM_Text_CostCenter	string comment '成本中心',
FDate	string comment '出库日期',
FCreatorId_FUserAccount	string comment '创建人',
FCreateDate	string comment '创建日期',
FBillNo	string comment '单据编号',
FBillTypeID	string comment '单据类型',
FDocumentStatus	string comment '单据状态',
F_TTHM_DeliveryEfficiency	string comment '发货时效/H',
F_TTHM_Datetime_FHTZD	string comment '发货通知单审核时间',
FCustomerID	string comment '客户',
F_TTHM_PushToYJDF	string comment '是否推一件代发',
F_TTHM_Text_BusinessCenter	string comment '所属业务中心',
FCarriageNO	string comment '运单号',
FModifyDate	string comment '最后修改日期',
FCancelDate	string comment '作废日期',
FApproveDate	string comment '审核日期',
FCancelStatus	string comment '作废状态',
F_TTHM_CWFLS	string comment '财务分类',
FStockID	string comment '仓库',
F_TTHM_CHLB	string comment '存货类别',
FMateriaModel	string comment '规格型号',
F_TTHM_CustPONum	string comment '客户合同号',
FUnitID	string comment '库存单位',
F_TTHM_SrcSONum	string comment '来源销售单号',
F_TTHM_SrcSOSeq	string comment '来源销售行号',
F_TTHM_SJDM	string comment '商机代码',
FMaterialID	string comment '物料编码',
FMaterialName	string comment '物料名称',
F_TTHM_ProjectCode	string comment '项目编号',
F_TTHM_EntryName	string comment '项目名称',
F_TTHM_DNNumber string comment '发货通知单号',
FSaleDeptID_FNumber	string comment '销售部门',
FJoinInStockQty	string comment '关联入库数量',
FReturnQty	string comment '关联退货数量',
FRealQty	string comment '实发数量',
FActQty	string comment '实收数量',
inc_date string comment 'inc_day日期'
)
COMMENT '采购数据_销售出库单表dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

--
insert overwrite table dm_gis_uimp.dwd_purchase_SALES_OUTBOUND_ORDERS partition(inc_day='$firstDay')
select F_TTHM_Text_CostCenter,FDate,FCreatorId_FUserAccount,FCreateDate,t0.FBillNo,FBillTypeID,FDocumentStatus,F_TTHM_DeliveryEfficiency,F_TTHM_Datetime_FHTZD,FCustomerID,F_TTHM_PushToYJDF,
F_TTHM_Text_BusinessCenter,FCarriageNO,FModifyDate,FCancelDate,FApproveDate,FCancelStatus,F_TTHM_CWFLS,FStockID,F_TTHM_CHLB,FMateriaModel,F_TTHM_CustPONum,FUnitID,F_TTHM_SrcSONum,
F_TTHM_SrcSOSeq,F_TTHM_SJDM,FMaterialID,FMaterialName,F_TTHM_ProjectCode,F_TTHM_EntryName,F_TTHM_DNNumber,
FSaleDeptID_FNumber,FJoinInStockQty,FReturnQty,FRealQty,FActQty,
t0.inc_day as  inc_date    
from (
select
F_TTHM_Text_CostCenter,FDate,FCreatorId_FUserAccount,FCreateDate,FBillNo,FBillTypeID,FDocumentStatus,F_TTHM_DeliveryEfficiency,F_TTHM_Datetime_FHTZD,FCustomerID,F_TTHM_PushToYJDF,
F_TTHM_Text_BusinessCenter,FCarriageNO,FModifyDate,FCancelDate,FApproveDate,FCancelStatus,F_TTHM_CWFLS,FStockID,F_TTHM_CHLB,FMateriaModel,F_TTHM_CustPONum,FUnitID,F_TTHM_SrcSONum,
F_TTHM_SrcSOSeq,F_TTHM_SJDM,FMaterialID,FMaterialName,F_TTHM_ProjectCode,F_TTHM_EntryName,F_TTHM_DNNumber,
FSaleDeptID_FNumber,FJoinInStockQty,FReturnQty,FRealQty,FActQty,
inc_day 
from dm_gis_uimp.dwc_purchase_SALES_OUTBOUND_ORDERS where inc_day>='20230421' and inc_day<='$firstDay' and F_TTHM_Text_CostCenter<>'' ) as t0 
left join (
select FBillNo,max(inc_day) as inc_day from dm_gis_uimp.dwc_purchase_SALES_OUTBOUND_ORDERS where inc_day>='20230421' and inc_day<='$firstDay' and FBillNo<>'' group by FBillNo 
) as t1 
on t0.inc_day=t1.inc_day and t0.FBillNo=t1.FBillNo 
where t1.inc_day is not null 
;



-- 20230612 
-- 退货通知单 RETURN-SALES-MEMO,RETURN-SALES-MEMO-ALL
create table if not exists  dm_gis_uimp.dwd_purchase_return_sales_memo(
FBillNo	string comment'	单据编号',
FDocumentStatus	string comment'	单据状态',
FSaledeptid_FNumber	string comment'	销售部门',
FCancelDate	string comment'	作废日期',
FCancelStatus	string comment'	作废状态',
FModifyDate	string comment'	最后修改日期',
FApproveDate	string comment'	审核日期',
FCreateDate	string comment'	创建日期',
FMaterialId_FNumber	string comment'	物料编码',
FMaterialName	string comment'	物料名称',
FQty	string comment'	退货数量',
FBaseJoinretQty	string comment'	运维提单寄回数',
FBaseSumRetQty	string comment'	仓库实收数',
FRmType	string comment'	退货类型',
F_TTHM_WLMRGYS	string comment'	供应商',
F_TTHM_Returned	string comment'	退回件对应项目名称',
FDate	string comment'	日期',
FRetcustId_FName	string comment'	退货客户',
F_TTHM_Text_BusinessCenter	string comment'	所属业务中心',
FStockId	string comment'	仓库',
F_TTHM_CustPONum	string comment'	来源退货合同号',
F_TTHM_ProjectCode	string comment'	项目编号',
F_TTHM_EntryName	string comment'	项目名称',
F_PYFD_Qty2	string comment'	仓库实发数',
F_TTHM_Combo_Symptoms	string comment'	故障现象',
inc_date string comment 'inc_day日期'
)
COMMENT '采购数据_退货通知单dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- F_TTHM_Text_CostCenter
insert overwrite table dm_gis_uimp.dwd_purchase_return_sales_memo partition(inc_day='$firstDay')
select 
t0.FBillNo,FDocumentStatus,FSaledeptid_FNumber,FCancelDate,FCancelStatus,FModifyDate,FApproveDate,FCreateDate,FMaterialId_FNumber,FMaterialName,FQty,FBaseJoinretQty,
FBaseSumRetQty,FRmType,F_TTHM_WLMRGYS,F_TTHM_Returned,FDate,FRetcustId_FName,F_TTHM_Text_BusinessCenter,FStockId,F_TTHM_CustPONum,F_TTHM_ProjectCode,F_TTHM_EntryName,F_PYFD_Qty2,F_TTHM_Combo_Symptoms,
t0.inc_day as  inc_date    
from (
select
FBillNo,FDocumentStatus,FSaledeptid_FNumber,FCancelDate,FCancelStatus,FModifyDate,FApproveDate,FCreateDate,FMaterialId_FNumber,FMaterialName,FQty,FBaseJoinretQty,
FBaseSumRetQty,FRmType,F_TTHM_WLMRGYS,F_TTHM_Returned,FDate,FRetcustId_FName,F_TTHM_Text_BusinessCenter,FStockId,F_TTHM_CustPONum,F_TTHM_ProjectCode,F_TTHM_EntryName,F_PYFD_Qty2,F_TTHM_Combo_Symptoms,
inc_day 
from dm_gis_uimp.dwc_purchase_return_sales_memo where inc_day>='20230421' and inc_day<='$firstDay' and FBillNo<>'' ) as t0 
left join (
select FBillNo,max(inc_day) as inc_day from dm_gis_uimp.dwc_purchase_return_sales_memo where inc_day>='20230421' and inc_day<='$firstDay' and FBillNo<>'' group by FBillNo 
) as t1 
on t0.inc_day=t1.inc_day and t0.FBillNo=t1.FBillNo 
where t1.inc_day is not null 
;



-- 销售退货单 RETURN-SALES
create table if not exists  dm_gis_uimp.dwd_purchase_return_sales(
FBillNo	string comment'	单据编号',
FDocumentStatus	string comment'	单据状态',
FRetcustId_FName	string comment'	退货客户',
FSaledeptid_FNumber	string comment'	销售部门',
FCreateDate	string comment'	创建日期',
FModifyDate	string comment'	最后修改日期',
FApproveDate	string comment'	审核日期',
FCancelDate	string comment'	作废日期',
FCancelStatus	string comment'	作废状态',
F_TTHM_Text_BusinessCenter	string comment'	所属业务中心',
FMaterialId_FNumber	string comment'	物料编码',
FMaterialName	string comment'	物料名称',
FRealQty	string comment'	退货数量',
FStockId	string comment'	仓库',
FReturnType	string comment'	退货类型',
F_TTHM_ProjectCode	string comment'	项目编号',
F_TTHM_SHDBQty	string comment'	运维提单寄回数',
F_TTHM_LJSHDBQty	string comment'	仓库实收数',
F_TTHM_QTCKLJQty	string comment'	仓库实发数',
F_Aqa_MXCustPONum	string comment'	来源退货合同号',
F_TTHM_WLMRGYS	string comment'	供应商',
F_TTHM_Returned	string comment'	退回件对应项目名称',
FDate	string comment'	退货日期',
F_TTHM_Combo	string comment'	初步责任判定',
FLot	string comment'	批号',
inc_date string comment 'inc_day日期'
)
COMMENT '采购数据_销售退货单dwd'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

-- 
insert overwrite table dm_gis_uimp.dwd_purchase_return_sales partition(inc_day='$firstDay')
select 
t0.FBillNo,FDocumentStatus,FRetcustId_FName,FSaledeptid_FNumber,FCreateDate,FModifyDate,FApproveDate,FCancelDate,FCancelStatus,F_TTHM_Text_BusinessCenter,FMaterialId_FNumber,
FMaterialName,FRealQty,FStockId,FReturnType,F_TTHM_ProjectCode,F_TTHM_SHDBQty,F_TTHM_LJSHDBQty,F_TTHM_QTCKLJQty,F_Aqa_MXCustPONum,F_TTHM_WLMRGYS,F_TTHM_Returned,FDate,F_TTHM_Combo,FLot,
t0.inc_day as  inc_date    
from (
select
FBillNo,FDocumentStatus,FRetcustId_FName,FSaledeptid_FNumber,FCreateDate,FModifyDate,FApproveDate,FCancelDate,FCancelStatus,F_TTHM_Text_BusinessCenter,FMaterialId_FNumber,
FMaterialName,FRealQty,FStockId,FReturnType,F_TTHM_ProjectCode,F_TTHM_SHDBQty,F_TTHM_LJSHDBQty,F_TTHM_QTCKLJQty,F_Aqa_MXCustPONum,F_TTHM_WLMRGYS,F_TTHM_Returned,FDate,F_TTHM_Combo,FLot,
inc_day 
from dm_gis_uimp.dwc_purchase_return_sales where inc_day>='20230421' and inc_day<='$firstDay' and FBillNo<>'' ) as t0 
left join (
select FBillNo,max(inc_day) as inc_day from dm_gis_uimp.dwc_purchase_return_sales where inc_day>='20230421' and inc_day<='$firstDay' and FBillNo<>'' group by FBillNo 
) as t1 
on t0.inc_day=t1.inc_day and t0.FBillNo=t1.FBillNo 
where t1.inc_day is not null 
;



------------------------------------------------------------------------------------
------------------------------------------------------------------------------------

-- 采购数据_采购支出明细表
create table if not exists  dm_gis_uimp.dws_purchase_contract_ledger_details(
action_day	string comment '行为发生日期',
fbillno	string comment '采购订单编号',
fpurchaserid_fnumber	string comment '采购员工号',
fpurchaserid_fname	string comment '采购员姓名',
fpurchasedeptid_fnumber string comment '采购部门_组织ID',
fpurchasedeptid_fname string comment '采购部门_组织全称',
fmaterialname	string comment '物料名称',
fmaterialid_fnumber	string comment '物料编码',
fid	string comment '物料分组ID',
ffullparentid	string comment '物料分组全路径父分组内码',
one_j	string comment '一级级品类id',
two_j	string comment '二级品类id',
one_j_name	string comment '一级品类名称',
two_j_name	string comment '二级品类名称',
line_code	string comment '业务线',
line_name	string comment '业务线名称',
f_tthm_businesscenter	string comment '经营单元',
f_tthm_projectcode	string comment '项目代码',
f_tthm_entryname	string comment '项目名称',
fdate	string comment '采购日期',
fapprovedate string comment '审核日期',
fchangedate string comment '变更日期',
fpayconditionid_fname	string comment '付款方式',
fsupplierid_fnumber	string comment '供应商编码',
fsupplierid_fname	string comment '供应商名称',
f_tthm_pocontractno	string comment '合同编号',
f_tthm_cghtlx	string comment '合同类型',
fentrytaxrate	string comment '税率',
f_tthm_amount	string comment 'pu154预算金额',
fqty	string comment '采购数量',
fentryamount	string comment '采购金额（未含税）',
fallamount	string comment '采购金额（含税）',
fentryamount_unitprice	string comment '采购单价（未含税）',
fallamount_unitprice	string comment '采购单价（含税）',
ckx	string comment '参考系',
ckx_price	string comment '参考系价格',
ckx_amount	string comment '参考系金额',
jb_amount	string comment '降本金额',
cg_type	string comment '采购类型',
cgts_type string comment '特殊采购类型',
cgxy_price string comment '采购寻源单价',
cgxy_amount	string comment '采购寻源金额',
fallpayapplyamount string comment '已付款金额',
nopay_amount string comment '剩余未付金额',
notes string comment '采购内容',
f_tthm_cpzbq string comment '产品质保期(月)',
fmaterialid_fspecification string comment '物料描述',
f_tthm_htqsdate   string comment '合同起始日期',
f_tthm_htzzdate  string comment '合同终止日期',	
f_tthm_htyxq  string comment '合同有效期(月)'
)
COMMENT '采购数据_采购支出明细表'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 2024.01.09 增加字段
alter table dm_gis_uimp.dws_purchase_contract_ledger_details add columns(f_tthm_htqsdate   string comment '合同起始日期') cascade;
alter table dm_gis_uimp.dws_purchase_contract_ledger_details add columns(f_tthm_htzzdate  string comment '合同终止日期') cascade;	
alter table dm_gis_uimp.dws_purchase_contract_ledger_details add columns(f_tthm_htyxq  string comment '合同有效期(月)') cascade;



-- 线下导入数据
create table if not exists  dm_gis_uimp.tmp_purchase_contract_ledger_details_20240109(
action_day	string comment '行为发生日期',
fbillno	string comment '采购订单编号',
fpurchaserid_fnumber	string comment '采购员工号',
fpurchaserid_fname	string comment '采购员姓名',
fpurchasedeptid_fnumber string comment '采购部门_组织ID',
fpurchasedeptid_fname string comment '采购部门_组织全称',
fmaterialname	string comment '物料名称',
fmaterialid_fnumber	string comment '物料编码',
fid	string comment '物料分组ID',
ffullparentid	string comment '物料分组全路径父分组内码',
one_j	string comment '一级级品类id',
two_j	string comment '二级品类id',
one_j_name	string comment '一级品类名称',
two_j_name	string comment '二级品类名称',
line_code	string comment '业务线',
line_name	string comment '业务线名称',
f_tthm_businesscenter	string comment '经营单元',
f_tthm_projectcode	string comment '项目代码',
f_tthm_entryname	string comment '项目名称',
fdate	string comment '采购日期',
fapprovedate string comment '审核日期',
fchangedate string comment '变更日期',
fpayconditionid_fname	string comment '付款方式',
fsupplierid_fnumber	string comment '供应商编码',
fsupplierid_fname	string comment '供应商名称',
f_tthm_pocontractno	string comment '合同编号',
f_tthm_cghtlx	string comment '合同类型',
fentrytaxrate	string comment '税率',
f_tthm_amount	string comment 'pu154预算金额',
fqty	string comment '采购数量',
fentryamount	string comment '采购金额（未含税）',
fallamount	string comment '采购金额（含税）',
fentryamount_unitprice	string comment '采购单价（未含税）',
fallamount_unitprice	string comment '采购单价（含税）',
ckx	string comment '参考系',
ckx_price	string comment '参考系价格',
ckx_amount	string comment '参考系金额',
jb_amount	string comment '降本金额',
cg_type	string comment '采购类型',
cgts_type	string comment '特殊采购类型',
cgxy_amount	string comment '采购寻源金额',
fallpayapplyamount string comment '已付款金额',
nopay_amount string comment '剩余未付金额',
notes string comment '采购内容',
f_tthm_cpzbq string comment '产品质保期(月)',
fmaterialid_fspecification string comment '物料描述',
f_tthm_htqsdate   string comment '合同起始日期',
f_tthm_htzzdate  string comment '合同终止日期',	
f_tthm_htyxq  string comment '合同有效期(月)',
inc_day string COMMENT '日期：yyyyMMdd'
)
COMMENT '临时导数采购数据'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/采购订单202301010815数据_V1.4（对应治水需求V.19）.csv' OVERWRITE INTO TABLE dm_gis_uimp.tmp_purchase_contract_ledger_details_20240109;

set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
insert overwrite table dm_gis_uimp.dws_purchase_contract_ledger_details partition(inc_day)
select 
action_day, fbillno, fpurchaserid_fnumber, fpurchaserid_fname,
fpurchasedeptid_fnumber, fpurchasedeptid_fname, fmaterialname,
fmaterialid_fnumber, fid, ffullparentid, one_j, two_j,
one_j_name, two_j_name, line_code, line_name,
f_tthm_businesscenter, f_tthm_projectcode, f_tthm_entryname,
fdate, fapprovedate, fchangedate, fpayconditionid_fname,
fsupplierid_fnumber, fsupplierid_fname, f_tthm_pocontractno,
f_tthm_cghtlx, fentrytaxrate, f_tthm_amount, fqty,
fentryamount, fallamount, fentryamount_unitprice,
fallamount_unitprice, ckx, ckx_price, ckx_amount, jb_amount,
cg_type, 
cgts_type, '' cgxy_price,
cgxy_amount, fallpayapplyamount, nopay_amount, notes,
f_tthm_cpzbq, fmaterialid_fspecification,
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq,

inc_day
from dm_gis_uimp.tmp_purchase_contract_ledger_details_20240109;

drop table dm_gis_uimp.tmp_purchase_contract_ledger_details_20240109;

-- 通用物料表
create table if not exists  dm_gis_uimp.ods_csv_purchase_material(
material_no	string comment '物料编码' 
)
COMMENT '通用物料表'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;




-- 采购订单基表（dwd每日）
drop table if exists dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder;
create table dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder stored as parquet as 
select row_number() OVER(ORDER BY RAND()) as row_id,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,
fmaterialname,f_tthm_costcenter,fmaterialid_fnumber,f_tthm_materialgroupnumber,f_tthm_businesscenter,f_tthm_projectcode,f_tthm_entryname,
fdate,fapprovedate,fcanceldate,fchangedate,fcreatedate,fmodifydate,
fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,fqty,
fclosestatus,
fmrpclosestatus,
fbasereceiveqty,
fbasemrbqty,
fentryamount,fallamount,
f_tthm_budtaxprice,FPrice,ftaxprice,
fallpayapplyamount,
f_tthm_purcontent as notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
FSrcBillNo,
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq,
f_tthm_isspecialproject,
inc_day
from dm_gis_uimp.dwd_purchase_pur_purchaseorder 
where inc_day='$firstDay'
-- and ((fapprovedate is not null and fapprovedate<>'null' and  fapprovedate>'2023-08-15' and fcreatedate>='2023-01-01')
-- -- and ((fapprovedate is not null and fapprovedate<>'null' and  fapprovedate>'2023-08-15' and fcreatedate>='2023-01-01') 
-- -- or fbillno in (select fbillno from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' and fbillno is not null and fbillno<>'' group by fbillno )
-- -- )
-- -- 审核日期（fapprovedate）不为空，且小于2023.01.01；创建日期（fcreatedate）小于2023.01.01； inc_day大于20231012 
-- or (fapprovedate is not null and fapprovedate<>'null' and  fapprovedate<'2023-01-01' and fcreatedate<'2023-01-01')
-- )
-- 2024.01.12 修改
-- 条件1：【dwd中，审核日期（fapprovedate）不为空，inc_day大于20231012】
-- 或者条件2：【在手工的数据里出现过20230101~20231011】
and ((fapprovedate is not null and fapprovedate<>'null') 
or (fbillno in (select fbillno from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' and fbillno is not null and fbillno<>'' group by fbillno ) )
)
;


-- 一级品类ID 二级品类ID
drop table if exists dm_gis_uimp.tmp_dwd_purchase_bd_material_group;
create table dm_gis_uimp.tmp_dwd_purchase_bd_material_group stored as parquet as 
select t0.fid,t0.fnumber,t0.ffullparentid,t0.fname,t0.ffullparentid_split,ssize,one_j,two_j,t1.fname as one_j_name,t2.fname as two_j_name 
from ( select fid,fnumber,ffullparentid,fname,split(ffullparentid,'\\.') as ffullparentid_split,size(split(ffullparentid,'\\.')) as ssize,
case when size(split(ffullparentid,'\\.'))<=2 then fid  else  split(ffullparentid,'\\.')[2] end as one_j,
case when size(split(ffullparentid,'\\.'))=3 then fid  when size(split(ffullparentid,'\\.'))>3 then split(ffullparentid,'\\.')[3] else  null end as two_j 
from dm_gis_uimp.dwd_purchase_bd_material_group where inc_day='$firstDay' ) as t0 
left join (select fid,fname from dm_gis_uimp.dwd_purchase_bd_material_group where inc_day='$firstDay' and fid is not null and fid<>'' group by fid,fname) as t1 
on t0.one_j=t1.fid 
left join (select fid,fname from dm_gis_uimp.dwd_purchase_bd_material_group where inc_day='$firstDay' and fid is not null and fid<>'' group by fid,fname) as t2 
on t0.two_j=t2.fid 
;

-- 业务线
-- 1、数据准备
-- dwd_purchase_pur_purchaseorder.f_tthm_costcenter
-- ods_efp_cost_language.kostl、ktext
-- ods_issp_org_data_virtual.unit_id、line_code、kostl
-- ods_issp_org_data表的stext、org_id
-- ods_issp_business_line表的line_code、line_name

-- 2.取值逻辑
-- ①根据dwd_purchase_pur_purchaseorder.f_tthm_costcenter关联ods_issp_org_data_virtual.kostl，
-- 取ods_issp_org_data_virtual表的line_code。定义为业务线
-- 再根据line_code，取line_name。定义为业务线名称

-- ②根据dwd_purchase_pur_purchaseorder.f_tthm_costcenter关联ods_efp_cost_language.kostl，
-- 取ods_efp_cost_language.ktext；如果kostl≠SF056且ktext里的包含“丰图科技”文案，则需要去掉ktext里的“丰图科技”文案。
drop table if exists dm_gis_uimp.tmp_efp_cost_language;
create table dm_gis_uimp.tmp_efp_cost_language stored as parquet as 
select t0.kostl,t0.ktext,t1.kostl as t1_kostl,t1.bkzkp
from (select kostl,datbi,kokrs,ktext from dm_gis_uimp.ods_efp_cost_language where spras='ZH' ) as t0 
left join (select kostl,datbi,kokrs,bkzkp from dm_gis_uimp.ods_efp_cost where bkzkp is null or bkzkp='') as t1 
on t0.kostl=t1.kostl and t0.datbi=t1.datbi and t0.kokrs=t1.kokrs
where t1.kostl is not null
;

drop table if exists dm_gis_uimp.tmp_dwd_purchase_costcenter_bu_line;
create table dm_gis_uimp.tmp_dwd_purchase_costcenter_bu_line stored as parquet as 
select 
f_tthm_costcenter,t1.unit_id,t1.line_code,t1.kostl,t2.ktext,t3.line_name,
if(t1.kostl<>'SF056',replace(t2.ktext,'丰图科技',''),t2.ktext) as f_tthm_businesscenter 
from (select f_tthm_costcenter from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder  group by  f_tthm_costcenter) as t0 
left join (
select unit_id,line_code,kostl from dm_gis_uimp.ods_issp_org_data_virtual where kostl<>'' group by unit_id,line_code,kostl ) as t1 
on t0.f_tthm_costcenter=t1.kostl
left join (
select kostl,ktext from dm_gis_uimp.tmp_efp_cost_language group by kostl,ktext ) as t2 
on t0.f_tthm_costcenter=t2.kostl
left join (
select line_code,line_name from dm_gis_uimp.ods_issp_business_line  group by line_code,line_name ) as t3 
on t1.line_code=t3.line_code
;




-- 采购数量
-- 1、数据准备
-- fqty：采购数量
-- fclosestatus：订单关闭状态
-- fmrpclosestatus：行关闭状态
-- fbasereceiveqty：累计收料数量(基本)
-- fbasemrbqty：累计退料数量(基本)

-- 2、取值规则：
-- 如果Fclosestatus≠B 且 fmrpclosestatus≠B（即订单和行均未关闭），则取fqty。
-- 否则取fbasereceiveqty减fbasemrbqty。

-- 参考系
-- 1、数据准备
-- f_tthm_budtaxprice（含税预算单价）
-- Ftaxprice（含税单价）

-- 2、取值规则
-- （1）如果本月采购数据的“合同类型”为“A”，参考系 设置为“预算”，“参考系价格”值取f_tthm_budtaxprice。
-- （2）如果本月采购数据的“合同类型”为“A”，留空


-- 行为发生日期字段





-- 采购类型 特殊采购类型 采购寻源单价 采购寻源金额  
-- srm
drop table if exists dm_gis_uimp.tmp_dwd_purchase_srm_join;
create table dm_gis_uimp.tmp_dwd_purchase_srm_join stored as parquet as 
select t0.n_number,purchase_type,special_purchase_type,t0.update_time as update_time_h,supplier_code,material_number,ctc_contract_code,t1.update_time as update_time_i,fbk_amount,require_quantity   
from (select n_number,purchase_type,special_purchase_type,update_time from dm_gis_uimp.dwd_purchase_srm_head where inc_day>='20230520' ) as t0 
left join ( select n_number,supplier_code,material_number,ctc_contract_code,update_time,fbk_amount,require_quantity from dm_gis_uimp.dwd_purchase_srm_item where inc_day>='20230520' ) as t1 
on t0.n_number=t1.n_number 
;

-- material_number,ctc_contract_code,supplier_code
-- fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber
drop table if exists dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time;
create table dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time stored as parquet as 
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,n_number,purchase_type,special_purchase_type,update_time_h,update_time_i,fbk_amount,require_quantity  
from (select 
if(fmaterialid_fnumber is not null,fmaterialid_fnumber,'') as fmaterialid_fnumber,
if(f_tthm_pocontractno is not null,f_tthm_pocontractno,'') as f_tthm_pocontractno,
if(fsupplierid_fnumber is not null,fsupplierid_fnumber,'') as fsupplierid_fnumber 
from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder group by fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber) as t0 
left join (
select n_number,purchase_type,special_purchase_type,update_time_h,
if(supplier_code is not null,supplier_code,'') as supplier_code,
if(material_number is not null,material_number,'') as material_number,
if(ctc_contract_code is not null,ctc_contract_code,'') as ctc_contract_code,
update_time_i,fbk_amount,require_quantity   
from dm_gis_uimp.tmp_dwd_purchase_srm_join group by n_number,purchase_type,special_purchase_type,update_time_h,supplier_code,material_number,ctc_contract_code,update_time_i,fbk_amount,require_quantity ) as t1 
on t0.fmaterialid_fnumber=t1.material_number and t0.f_tthm_pocontractno=t1.ctc_contract_code and t0.fsupplierid_fnumber=t1.supplier_code
;

drop table if exists dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time_h;
create table dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time_h stored as parquet as 
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,purchase_type,special_purchase_type,update_time_h 
from (
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,purchase_type,special_purchase_type,update_time_h,
row_number() over(partition by fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber order by update_time_h desc) as rn 
from dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time 
) as t where t.rn=1
;

drop table if exists dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time_i;
create table dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time_i stored as parquet as 
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,fbk_amount,require_quantity,update_time_i 
from (
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,fbk_amount,require_quantity,update_time_i,
row_number() over(partition by fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber order by update_time_i desc) as rn 
from dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time 
) as t where t.rn=1
;









------------------------------------------------
------------------------------------------------

-- 采购订单基表（dwc每日）
drop table if exists dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder;
create table dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder stored as parquet as 
select 
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,
fmaterialname,f_tthm_costcenter,fmaterialid_fnumber,f_tthm_materialgroupnumber,f_tthm_businesscenter,f_tthm_projectcode,f_tthm_entryname,
fdate,fapprovedate,fcanceldate,fchangedate,fcreatedate,fmodifydate,
fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,fqty,
fclosestatus,
fmrpclosestatus,
fbasereceiveqty,
fbasemrbqty,
fentryamount,fallamount,
f_tthm_budtaxprice,FPrice,ftaxprice,
fallpayapplyamount,
f_tthm_purcontent as notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq, 
inc_day
from dm_gis_uimp.dwc_purchase_pur_purchaseorder 
where inc_day='$firstDay'
-- and ((fapprovedate is not null and fapprovedate<>'null' and  fapprovedate>'2023-08-15' and fcreatedate>='2023-01-01') 
-- -- and ((fapprovedate is not null and fapprovedate<>'null' and  fapprovedate>'2023-08-15' and fcreatedate>='2023-01-01') 
-- -- or fbillno in (select fbillno from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' and fbillno is not null and fbillno<>'' group by fbillno )
-- -- )
-- or (fapprovedate is not null and fapprovedate<>'null' and  fapprovedate<'2023-01-01' and fcreatedate<'2023-01-01')
-- )
-- 2024.01.12 修改
-- 条件1：【dwd中，审核日期（fapprovedate）不为空，inc_day大于20231012】
-- 或者条件2：【在手工的数据里出现过20230101~20231011】
and ((fapprovedate is not null and fapprovedate<>'null') 
or (fbillno in (select fbillno from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' and fbillno is not null and fbillno<>'' group by fbillno ) )
)
;


-- -- 一级品类ID 二级品类ID
-- drop table if exists dm_gis_uimp.tmp_dwd_purchase_bd_material_group;
-- create table dm_gis_uimp.tmp_dwd_purchase_bd_material_group stored as parquet as 
-- select t0.fid,t0.fnumber,t0.ffullparentid,t0.fname,t0.ffullparentid_split,ssize,one_j,two_j,t1.fname as one_j_name,t2.fname as two_j_name 
-- from ( select fid,fnumber,ffullparentid,fname,split(ffullparentid,'\\.') as ffullparentid_split,size(split(ffullparentid,'\\.')) as ssize,
-- case when size(split(ffullparentid,'\\.'))<=2 then fid  else  split(ffullparentid,'\\.')[2] end as one_j,
-- case when size(split(ffullparentid,'\\.'))=3 then fid  when size(split(ffullparentid,'\\.'))>3 then split(ffullparentid,'\\.')[3] else  null end as two_j 
-- from dm_gis_uimp.dwd_purchase_bd_material_group where inc_day='$firstDay' ) as t0 
-- left join (select fid,fname from dm_gis_uimp.dwd_purchase_bd_material_group where inc_day='$firstDay' and fid is not null and fid<>'' group by fid,fname) as t1 
-- on t0.one_j=t1.fid 
-- left join (select fid,fname from dm_gis_uimp.dwd_purchase_bd_material_group where inc_day='$firstDay' and fid is not null and fid<>'' group by fid,fname) as t2 
-- on t0.two_j=t2.fid 
-- ;


-- 业务线
-- drop table if exists dm_gis_uimp.tmp_efp_cost_language;
-- create table dm_gis_uimp.tmp_efp_cost_language stored as parquet as 
-- select t0.kostl,t0.ktext,t1.kostl as t1_kostl,t1.bkzkp
-- from (select kostl,datbi,kokrs,ktext from dm_gis_uimp.ods_efp_cost_language where spras='ZH' ) as t0 
-- left join (select kostl,datbi,kokrs,bkzkp from dm_gis_uimp.ods_efp_cost where bkzkp is null or bkzkp='') as t1 
-- on t0.kostl=t1.kostl and t0.datbi=t1.datbi and t0.kokrs=t1.kokrs
-- where t1.kostl is not null
-- ;

drop table if exists dm_gis_uimp.tmp_dwc_purchase_costcenter_bu_line;
create table dm_gis_uimp.tmp_dwc_purchase_costcenter_bu_line stored as parquet as 
select 
f_tthm_costcenter,t1.unit_id,t1.line_code,t1.kostl,t2.ktext,t3.line_name,
if(t1.kostl<>'SF056',replace(t2.ktext,'丰图科技',''),t2.ktext) as f_tthm_businesscenter 
from (select f_tthm_costcenter from dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder  group by  f_tthm_costcenter) as t0 
left join (
select unit_id,line_code,kostl from dm_gis_uimp.ods_issp_org_data_virtual where kostl<>'' group by unit_id,line_code,kostl ) as t1 
on t0.f_tthm_costcenter=t1.kostl
left join (
select kostl,ktext from dm_gis_uimp.tmp_efp_cost_language group by kostl,ktext ) as t2 
on t0.f_tthm_costcenter=t2.kostl
left join (
select line_code,line_name from dm_gis_uimp.ods_issp_business_line  group by line_code,line_name ) as t3 
on t1.line_code=t3.line_code
;



-- 采购类型 特殊采购类型 采购寻源单价 采购寻源金额  
-- srm
-- drop table if exists dm_gis_uimp.tmp_dwd_purchase_srm_join;
-- create table dm_gis_uimp.tmp_dwd_purchase_srm_join stored as parquet as 
-- select t0.n_number,purchase_type,special_purchase_type,t0.update_time as update_time_h,supplier_code,material_number,ctc_contract_code,t1.update_time as update_time_i,fbk_amount  
-- from (select n_number,purchase_type,special_purchase_type,update_time from dm_gis_uimp.dwd_purchase_srm_head where inc_day>='20230520' ) as t0 
-- left join ( select n_number,supplier_code,material_number,ctc_contract_code,update_time,fbk_amount from dm_gis_uimp.dwd_purchase_srm_item where inc_day>='20230520' ) as t1 
-- on t0.n_number=t1.n_number 
-- ;

-- material_number,ctc_contract_code,supplier_code
-- fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber
drop table if exists dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time;
create table dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time stored as parquet as 
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,n_number,purchase_type,special_purchase_type,update_time_h,update_time_i,fbk_amount,require_quantity 
from (select 
if(fmaterialid_fnumber is not null,fmaterialid_fnumber,'') as fmaterialid_fnumber,
if(f_tthm_pocontractno is not null,f_tthm_pocontractno,'') as f_tthm_pocontractno,
if(fsupplierid_fnumber is not null,fsupplierid_fnumber,'') as fsupplierid_fnumber 
from dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder group by fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber) as t0 
left join (
select n_number,purchase_type,special_purchase_type,update_time_h,
if(supplier_code is not null,supplier_code,'') as supplier_code,
if(material_number is not null,material_number,'') as material_number,
if(ctc_contract_code is not null,ctc_contract_code,'') as ctc_contract_code,
update_time_i,fbk_amount,require_quantity   
from dm_gis_uimp.tmp_dwd_purchase_srm_join group by n_number,purchase_type,special_purchase_type,update_time_h,supplier_code,material_number,ctc_contract_code,update_time_i,fbk_amount,require_quantity ) as t1 
on t0.fmaterialid_fnumber=t1.material_number and t0.f_tthm_pocontractno=t1.ctc_contract_code and t0.fsupplierid_fnumber=t1.supplier_code
;

drop table if exists dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time_h;
create table dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time_h stored as parquet as 
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,purchase_type,special_purchase_type,update_time_h 
from (
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,purchase_type,special_purchase_type,update_time_h,
row_number() over(partition by fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber order by update_time_h desc) as rn 
from dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time 
) as t where t.rn=1
;

drop table if exists dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time_i;
create table dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time_i stored as parquet as 
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,fbk_amount,require_quantity,update_time_i 
from (
select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,fbk_amount,require_quantity,update_time_i,
row_number() over(partition by fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber order by update_time_i desc) as rn 
from dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time 
) as t where t.rn=1
;



-- 临时汇总表
drop table if exists dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder_main;
create table dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder_main stored as parquet as 
select action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,
line_code,kostl,ktext,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,
fentryamount,fallamount,FPrice,ftaxprice,
ckx,
case when f_tthm_cghtlx='A' and ckx='预算' then f_tthm_budtaxprice else null end as ckx_price,
cg_type,
cgts_type,
cgxy_price,
cgxy_price*fqty as cgxy_amount,
fallpayapplyamount,
nopay_amount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq 
from (
select replace(substr(fapprovedate,1,10),'-','') as action_day,
t0.fbillno,t0.fpurchaserid_fnumber,t0.fpurchaserid_fname,t0.fpurchasedeptid_fnumber,t0.fpurchasedeptid_fname,t0.fmaterialname,t0.fmaterialid_fnumber,
t1.fid,t1.ffullparentid,t1.one_j,t1.two_j,t1.one_j_name,t1.two_j_name,
t2.line_code,t2.kostl,t2.ktext,t2.line_name,t2.f_tthm_businesscenter,
t0.f_tthm_projectcode,t0.f_tthm_entryname,t0.fdate,t0.fapprovedate,t0.fchangedate,t0.fpayconditionid_fname,t0.fsupplierid_fnumber,t0.fsupplierid_fname,t0.f_tthm_pocontractno,t0.f_tthm_cghtlx,t0.fentrytaxrate,t0.f_tthm_amount,
if((t0.fclosestatus is null or t0.fclosestatus<>'B') and (t0.fmrpclosestatus is null or t0.fmrpclosestatus<>'B'),t0.fqty,t0.fbasereceiveqty-t0.fbasemrbqty) as fqty,
t0.fentryamount,t0.fallamount,FPrice,ftaxprice,
case when t0.f_tthm_cghtlx='A' then '预算' else null end as ckx,
t0.f_tthm_budtaxprice,
t5.purchase_type as cg_type,
t5.special_purchase_type as cgts_type,
t6.fbk_amount as cgxy_price,
t0.fallpayapplyamount,
t0.fallamount-t0.fallpayapplyamount as nopay_amount,
t0.notes,
t0.f_tthm_cpzbq,
t0.fmaterialid_fspecification,
-- 2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq  
from (select 
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,
fmaterialname,f_tthm_costcenter,fmaterialid_fnumber,f_tthm_materialgroupnumber,f_tthm_businesscenter,f_tthm_projectcode,f_tthm_entryname,
fdate,fapprovedate,fcanceldate,fchangedate,fcreatedate,fmodifydate,
fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,fqty,
fclosestatus,
fmrpclosestatus,
fbasereceiveqty,
fbasemrbqty,
fentryamount,fallamount,
f_tthm_budtaxprice,FPrice,ftaxprice,
fallpayapplyamount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq,
inc_day
from dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder)  as t0 
left join (select fid,fnumber,ffullparentid,one_j,two_j,one_j_name,two_j_name from dm_gis_uimp.tmp_dwd_purchase_bd_material_group group by fid,fnumber,ffullparentid,one_j,two_j,one_j_name,two_j_name) as t1 
on t0.f_tthm_materialgroupnumber=t1.fnumber 
left join (select f_tthm_costcenter,unit_id,line_code,kostl,ktext,line_name,f_tthm_businesscenter from dm_gis_uimp.tmp_dwc_purchase_costcenter_bu_line group by f_tthm_costcenter,unit_id,line_code,kostl,ktext,line_name,f_tthm_businesscenter) as t2 
on t0.f_tthm_costcenter=t2.f_tthm_costcenter 
left join (select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,purchase_type,special_purchase_type  from dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time_h) as t5 
on if(t0.fmaterialid_fnumber is not null,t0.fmaterialid_fnumber,'')=t5.fmaterialid_fnumber 
and if(t0.f_tthm_pocontractno is not null,t0.f_tthm_pocontractno,'')=t5.f_tthm_pocontractno 
and if(t0.fsupplierid_fnumber is not null,t0.fsupplierid_fnumber,'')=t5.fsupplierid_fnumber
left join (select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,fbk_amount/require_quantity as fbk_amount from dm_gis_uimp.tmp_dwc_purchase_srm_join_update_time_i) as t6 
on if(t0.fmaterialid_fnumber is not null,t0.fmaterialid_fnumber,'')=t6.fmaterialid_fnumber 
and if(t0.f_tthm_pocontractno is not null,t0.f_tthm_pocontractno,'')=t6.f_tthm_pocontractno 
and if(t0.fsupplierid_fnumber is not null,t0.fsupplierid_fnumber,'')=t6.fsupplierid_fnumber 
) as t 
;






-- 写入到结果表(dwc每天的)
create table if not exists  dm_gis_uimp.dwc_purchase_contract_ledger_details_di(
action_day	string comment '行为发生日期',
fbillno	string comment '采购订单编号',
fpurchaserid_fnumber	string comment '采购员工号',
fpurchaserid_fname	string comment '采购员姓名',
fpurchasedeptid_fnumber string comment '采购部门_组织ID',
fpurchasedeptid_fname string comment '采购部门_组织全称',
fmaterialname	string comment '物料名称',
fmaterialid_fnumber	string comment '物料编码',
fid	string comment '物料分组ID',
ffullparentid	string comment '物料分组全路径父分组内码',
one_j	string comment '一级级品类id',
two_j	string comment '二级品类id',
one_j_name	string comment '一级品类名称',
two_j_name	string comment '二级品类名称',
line_code	string comment '业务线',
line_name	string comment '业务线名称',
f_tthm_businesscenter	string comment '经营单元',
f_tthm_projectcode	string comment '项目代码',
f_tthm_entryname	string comment '项目名称',
fdate	string comment '采购日期',
fapprovedate string comment '审核日期',
fchangedate string comment '变更日期',
fpayconditionid_fname	string comment '付款方式',
fsupplierid_fnumber	string comment '供应商编码',
fsupplierid_fname	string comment '供应商名称',
f_tthm_pocontractno	string comment '合同编号',
f_tthm_cghtlx	string comment '合同类型',
fentrytaxrate	string comment '税率',
f_tthm_amount	string comment 'pu154预算金额',
fqty	string comment '采购数量',
fentryamount	string comment '采购金额（未含税）',
fallamount	string comment '采购金额（含税）',
fentryamount_unitprice	string comment '采购单价（未含税）',
fallamount_unitprice	string comment '采购单价（含税）',
ckx	string comment '参考系',
ckx_price	string comment '参考系价格',
ckx_amount	string comment '参考系金额',
jb_amount	string comment '降本金额',
cg_type	string comment '采购类型',
cgts_type string comment '特殊采购类型',
cgxy_price string comment '采购寻源单价',
cgxy_amount	string comment '采购寻源金额',
fallpayapplyamount string comment '已付款金额',
nopay_amount string comment '剩余未付金额',
notes string comment '采购内容',
f_tthm_cpzbq string comment '产品质保期(月)',
fmaterialid_fspecification string comment '物料描述',
f_tthm_htqsdate   string comment '合同起始日期',
f_tthm_htzzdate  string comment '合同终止日期',	
f_tthm_htyxq  string comment '合同有效期(月)' 

)
COMMENT '采购数据_采购支出明细表（dwc每日）'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


insert overwrite table dm_gis_uimp.dwc_purchase_contract_ledger_details_di partition(inc_day='$firstDay')
select action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,line_code,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,fentryamount,fallamount,fentryamount_unitprice,fallamount_unitprice,ckx,ckx_price,ckx_amount,jb_amount,cg_type,
cgts_type,cgxy_price,
cgxy_amount,fallpayapplyamount,
nopay_amount,notes,f_tthm_cpzbq,fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq 
from (
select 
action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,
line_code,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,
-- fentryamount	采购金额（未含税）		公式=采购数量*采购单价（未含税）
-- fallamount	采购金额（含税）		公式=采购数量*采购单价（含税）
-- fentryamount_unitprice	采购单价（未含税）		直接取字段：FPrice
-- fallamount_unitprice	采购单价（含税）		直接取字段：FTaxPrice
FPrice*fqty as fentryamount,
FTaxPrice*fqty as fallamount,
FPrice as fentryamount_unitprice,
FTaxPrice as fallamount_unitprice,
ckx,ckx_price,
ckx_price*fqty as ckx_amount,
if(ckx_price is null or ckx_price*fqty=0.0,null,ckx_price*fqty-fallamount) as jb_amount,
cg_type,
cgts_type,cgxy_price,
cgxy_amount,
fallpayapplyamount,
nopay_amount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq 
from (
select action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,
line_code,kostl,ktext,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,
fentryamount,fallamount,FPrice,FTaxPrice,
ckx,
ckx_price,
cg_type,
cgts_type,cgxy_price,
cgxy_amount,
fallpayapplyamount,
nopay_amount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq  
from dm_gis_uimp.tmp_dwc_purchase_pur_purchaseorder_main 
) as t 
) as tt
;





-----------------------------------------------
-----------------------------------------------
-- 优先从手工里取，再从dwc里取第一次(fbillno)
drop table if exists dm_gis_uimp.tmp_purchase_fbillno_first;
create table dm_gis_uimp.tmp_purchase_fbillno_first stored as parquet as 
select 
if(t0.fbillno is not null,t0.fbillno,t1.fbillno) as fbillno,
if(t0.action_day is not null,t0.action_day,t1.action_day) as action_day,
if(t0.fpurchaserid_fnumber is not null,t0.fpurchaserid_fnumber,t1.fpurchaserid_fnumber) as fpurchaserid_fnumber,
if(t0.fpurchaserid_fname is not null,t0.fpurchaserid_fname,t1.fpurchaserid_fname) as fpurchaserid_fname,
if(t0.fpurchasedeptid_fnumber is not null,t0.fpurchasedeptid_fnumber,t1.fpurchasedeptid_fnumber) as fpurchasedeptid_fnumber,
if(t0.fpurchasedeptid_fname is not null,t0.fpurchasedeptid_fname,t1.fpurchasedeptid_fname) as fpurchasedeptid_fname,
if(t0.cg_type is not null,t0.cg_type,t1.cg_type) as cg_type,
if(t0.cgts_type is not null,t0.cgts_type,t1.cgts_type) as cgts_type,
if(t0.fdate is not null,t0.fdate,t1.fdate) as fdate
from (
select fbillno,action_day,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,cg_type,cgts_type,fdate 
from (
select 
fbillno,action_day,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,
cg_type,cgts_type,fdate,row_number() over(partition by fbillno order by action_day desc) as rn 
from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' and fbillno is not null and fbillno<>''
) as t where t.rn=1
) as t0 
full outer join (
select 
fbillno,action_day,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,cg_type,cgts_type,fdate 
from (
select fbillno,action_day,
fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,
cg_type,cgts_type,fdate,row_number() over(partition by fbillno order by action_day desc) as rn 
from dm_gis_uimp.dwc_purchase_contract_ledger_details_di  
where inc_day>'20230815' and inc_day<='$firstDay' 
and ( (fapprovedate is not null and fapprovedate<>'null' and  fapprovedate>'2023-08-15') 
or inc_day='20231211' )
) as t where t.rn=1 
) as t1 
on t0.fbillno=t1.fbillno
;

-- 优先从手工里取，再从dwc里取第一次(fbillno、fmaterialid_fnumber)
drop table if exists dm_gis_uimp.tmp_purchase_fbillno_fmaterialid_fnumber_first;
create table dm_gis_uimp.tmp_purchase_fbillno_fmaterialid_fnumber_first stored as parquet as 
select 
if(t0.fbillno is not null,t0.fbillno,t1.fbillno) as fbillno,
if(t0.fmaterialid_fnumber is not null,t0.fmaterialid_fnumber,t1.fmaterialid_fnumber) as fmaterialid_fnumber,
if(t0.action_day is not null,t0.action_day,t1.action_day) as action_day,
if(t0.cgxy_price is not null,t0.cgxy_price,t1.cgxy_price) as cgxy_price  
from (
select fbillno,fmaterialid_fnumber,action_day,cgxy_price 
from (
select fbillno,fmaterialid_fnumber,action_day,cgxy_price,row_number() over(partition by fbillno,fmaterialid_fnumber order by action_day desc) as rn 
from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' and fbillno is not null and fbillno<>''
) as t where t.rn=1
) as t0 
full outer join (
select fbillno,fmaterialid_fnumber,action_day,cgxy_price 
from (
select fbillno,fmaterialid_fnumber,action_day,cgxy_price,row_number() over(partition by fbillno,fmaterialid_fnumber order by action_day desc) as rn 
from dm_gis_uimp.dwc_purchase_contract_ledger_details_di  
where inc_day>'20230815' and inc_day<='$firstDay' 
and ( (fapprovedate is not null and fapprovedate<>'null' and  fapprovedate>'2023-08-15') 
or inc_day='20231211' )
) as t where t.rn=1 
) as t1 
on t0.fbillno=t1.fbillno and t0.fmaterialid_fnumber=t1.fmaterialid_fnumber
;

-- 2023.12.1 参考系 参考价格
-- 1、如果dwd中，FSrcBillNo（源单编号）字段均为空，则，
-- （1）如果dwd的f_tthm_budtaxprice（含税预算单价）不为空且不为0，则参考系设置为“预算”、“参考系价格”取dwc的字段f_tthm_budtaxprice字段。
-- （2）如果dwd的f_tthm_budtaxprice为空或为0，则根据fbillno+fmaterialid_fnumber 查手工导入的数据，
-- ①如果存在手工导入数据，且唯一(参考系价格ckx_price)，则取手工导入的参考系、参考系价格。
-- ②如果存在手工导入数据，且不唯一(参考系价格ckx_price)，则参考系设置为“预算”、参考系价格留空。
drop table if exists dm_gis_uimp.tmp_dws_purchase_ckx_price_cnt;
create table dm_gis_uimp.tmp_dws_purchase_ckx_price_cnt stored as parquet as 
select fbillno,fmaterialid_fnumber,count(1) as ckx_price_cnt 
from (select fbillno,fmaterialid_fnumber,ckx_price from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' 
group by fbillno,fmaterialid_fnumber,ckx_price
) as t group by fbillno,fmaterialid_fnumber
;

-- 手工导入数据 ckx_price 唯一的
drop table if exists dm_gis_uimp.tmp_dws_purchase_ckx_price;
create table dm_gis_uimp.tmp_dws_purchase_ckx_price stored as parquet as 
select 
t0.fbillno,t0.fmaterialid_fnumber,ckx,ckx_price 
from (select fbillno,fmaterialid_fnumber from dm_gis_uimp.tmp_dws_purchase_ckx_price_cnt where ckx_price_cnt=1 ) as t0 
left join (select fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815') as t1 
on t0.fbillno=t1.fbillno and t0.fmaterialid_fnumber=t1.fmaterialid_fnumber
;

-- FSrcBillNo（源单编号）字段均为空
drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnull;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnull stored as parquet as 
select 
t0.row_id,t0.fbillno,t0.fmaterialid_fnumber,
case when f_tthm_budtaxprice is not null and f_tthm_budtaxprice<>0 then '预算' 
when (t1.ckx is not null and t1.ckx<>'') then t1.ckx 
else '预算' end as ckx,
case when f_tthm_budtaxprice is not null and f_tthm_budtaxprice<>0 then f_tthm_budtaxprice 
when (t1.ckx_price is not null and t1.ckx_price<>'') then t1.ckx_price 
else '' end as ckx_price 
from (select 
row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice 
from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder where FSrcBillNo is null or trim(FSrcBillNo)='' ) as t0 
left join (select fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_ckx_price group by fbillno,fmaterialid_fnumber,ckx,ckx_price) as t1 
on t0.fbillno=t1.fbillno and t0.fmaterialid_fnumber=t1.fmaterialid_fnumber
;


-- 2、如果dwd中，FSrcBillNo（源单编号）字段存在值，则，
-- （1）如果fmaterialid_fnumber在通用物料表中，则参考系设置为“无”、参考系价格留空。
-- （2）如果fmaterialid_fnumber不在通用物料表中，则根据fbillno+fmaterialid_fnumber 查手工导入的数据，
-- ①如果存在手工导入数据 且唯一，则取手工导入的参考系、参考系价格。
-- ②如果存在手工导入数据 且不唯一、或者不存在手工导入数据中，则按以下方式处理:
-- 2.1、如果dwd中f_tthm_htqsdate为空，则参考系设置为“预算”、参考系取t0.f_tthm_budtaxprice。

-- FSrcBillNo（源单编号）字段均存在值
drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull stored as parquet as 
select 
t0.row_id,t0.fbillno,t0.fmaterialid_fnumber,f_tthm_budtaxprice,
fsupplierid_fnumber,f_tthm_projectcode,
f_tthm_htqsdate,f_tthm_isspecialproject, 
case when t1.material_no is not null  then '无' 
when t1.material_no is null and (t2.ckx is not null and t2.ckx<>'') then t2.ckx 
when t1.material_no is null and (t2.ckx is null or t2.ckx='') and (f_tthm_htqsdate is null or f_tthm_htqsdate='') then '预算'
else  '下一步' end as ckx,
case when t1.material_no is not null  then '' 
when t1.material_no is null and (t2.ckx_price is not null and t2.ckx_price<>'') then t2.ckx_price 
when t1.material_no is null and (t2.ckx_price is null or t2.ckx_price='') and (f_tthm_htqsdate is null or f_tthm_htqsdate='') then f_tthm_budtaxprice 
else  '' end as ckx_price 
from (select 
row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice,
fsupplierid_fnumber,f_tthm_projectcode,
f_tthm_htqsdate,f_tthm_isspecialproject 
from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder where trim(FSrcBillNo)<>'' ) as t0 
left join (select material_no  from dm_gis_uimp.ods_csv_purchase_material group by material_no) as t1 
on t0.fmaterialid_fnumber=t1.material_no
left join (select fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_ckx_price group by fbillno,fmaterialid_fnumber,ckx,ckx_price) as t2 
on t0.fbillno=t2.fbillno and t0.fmaterialid_fnumber=t2.fmaterialid_fnumber
;




-- 2.2、如果dwd中f_tthm_htqsdate不为空，且f_tthm_isspecialproject='1'，则
-- 根据fmaterialid_fnumber+fsupplierid_fnumber+f_tthm_projectcode，匹配dwd中除了它自己（t0.fbillno）的t1.fapprovedate不为空、且t0.f_tthm_htqsdate减t1.f_tthm_htqsdate的值大于0且最小的数据，
-- （1）如果匹配得到，则参考系设置为“历史价格_专项价格”，参考系单价取任一个t1.ftaxprice，即t1.ftaxprice有多个时，也只取1个。
-- （2）如果匹配不到，则参考系设置为“预算”、参考系取t0.f_tthm_budtaxprice。
-- 2.3、如果dwd中，f_tthm_isspecialproject<>'1'，且t0.f_tthm_htqsdate不为空，则
-- 根据fmaterialid_fnumber+fsupplierid_fnumber，匹配dwd（表命名t1）中t1.fapprovedate不为空、且t1.f_tthm_isspecialproject<>'1'、且t0.f_tthm_htqsdate减t1.f_tthm_htqsdate的值大于0且最小的t1，
-- （1）如果匹配得到，则参考系设置为“历史价格_通用价格”，参考系单价取任一个t1.ftaxprice，即t1.ftaxprice有多个时，也只取1个。
-- （2）如果匹配不到，则参考系设置为“预算”、参考系取t0.f_tthm_budtaxprice。

-- f_tthm_isspecialproject='1'
drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1 stored as parquet as 
select 
t0.row_id,t0.fbillno,t0.fmaterialid_fnumber,
t0.f_tthm_htqsdate as t0_htqsdate,t1.f_tthm_htqsdate as t1_htqsdate,
t1.ftaxprice,t0.f_tthm_budtaxprice,
t1.fbillno as t1_fbillno  
from (select row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice,
fsupplierid_fnumber,f_tthm_projectcode,
f_tthm_htqsdate,f_tthm_isspecialproject 
from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull 
where ckx='下一步' and (f_tthm_htqsdate is not null and f_tthm_htqsdate<>'') and f_tthm_isspecialproject='1' ) as t0 
left join (select fbillno,fmaterialid_fnumber,fsupplierid_fnumber,f_tthm_projectcode,f_tthm_htqsdate,ftaxprice  from  dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder 
where fapprovedate is not null and fapprovedate<>'' 
-- 2024.01.09 
union all 
select fbillno,fmaterialid_fnumber,fsupplierid_fnumber,f_tthm_projectcode,f_tthm_htqsdate,fallamount_unitprice as ftaxprice  from  dm_gis_uimp.dws_purchase_contract_ledger_details 
where inc_day='20230815' and fapprovedate is not null and fapprovedate<>'' 

) as t1 
on t0.fmaterialid_fnumber=t1.fmaterialid_fnumber and t0.fsupplierid_fnumber=t1.fsupplierid_fnumber  and t0.f_tthm_projectcode=t1.f_tthm_projectcode 
;

drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1_res1;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1_res1 stored as parquet as 
select 
row_id,fbillno,fmaterialid_fnumber,
'历史价格_专项价格' as ckx,
ftaxprice as ckx_price 
from (select row_id,fbillno,fmaterialid_fnumber,
diff_htqsdate,ftaxprice,f_tthm_budtaxprice, 
row_number() over(partition by row_id,fbillno,fmaterialid_fnumber order by diff_htqsdate desc ) as rn 
from (select row_id,fbillno,fmaterialid_fnumber,
unix_timestamp(replace(t0_htqsdate,'T',' '))-unix_timestamp(replace(t1_htqsdate,'T',' ')) as diff_htqsdate,
ftaxprice,f_tthm_budtaxprice 
from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1 
where fbillno<>t1_fbillno 
) as t where diff_htqsdate>0
) as tt where tt.rn=1
;

drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1_res2;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1_res2 stored as parquet as 
select 
row_id,fbillno,fmaterialid_fnumber,
'预算' as ckx,
f_tthm_budtaxprice as ckx_price 
from (select row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1 group by row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice ) as t
where row_id not in (select row_id from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1_res1)
;




-- f_tthm_isspecialproject<>'1'
drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1 stored as parquet as 
select 
t0.row_id,t0.fbillno,t0.fmaterialid_fnumber,
t0.f_tthm_htqsdate as t0_htqsdate,t1.f_tthm_htqsdate as t1_htqsdate,
t1.ftaxprice,t0.f_tthm_budtaxprice,
t1.fbillno as t1_fbillno 
from (select row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice,
fsupplierid_fnumber,f_tthm_projectcode,
f_tthm_htqsdate,f_tthm_isspecialproject 
from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull 
where ckx='下一步' and f_tthm_isspecialproject<>'1' and (f_tthm_htqsdate is not null and f_tthm_htqsdate<>'')  ) as t0 
left join (select fbillno,fmaterialid_fnumber,fsupplierid_fnumber,f_tthm_projectcode,f_tthm_htqsdate,ftaxprice  from  dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder 
where fapprovedate is not null and fapprovedate<>'' and f_tthm_isspecialproject<>'1' 
-- 2024.01.09 
union all 
select fbillno,fmaterialid_fnumber,fsupplierid_fnumber,f_tthm_projectcode,f_tthm_htqsdate,fallamount_unitprice as ftaxprice  from  dm_gis_uimp.dws_purchase_contract_ledger_details  
where inc_day='20230815' and fapprovedate is not null and fapprovedate<>'' 


) as t1 
on t0.fmaterialid_fnumber=t1.fmaterialid_fnumber and t0.fsupplierid_fnumber=t1.fsupplierid_fnumber  
;


drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1_res1;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1_res1 stored as parquet as 
select row_id,fbillno,fmaterialid_fnumber,
'历史价格_通用价格' as ckx,
ftaxprice as ckx_price 
from (select row_id,fbillno,fmaterialid_fnumber,
diff_htqsdate,ftaxprice,f_tthm_budtaxprice, 
row_number() over(partition by row_id,fbillno,fmaterialid_fnumber order by diff_htqsdate desc ) as rn 
from (select row_id,fbillno,fmaterialid_fnumber,
unix_timestamp(replace(t0_htqsdate,'T',' '))-unix_timestamp(replace(t1_htqsdate,'T',' ')) as diff_htqsdate,
ftaxprice,f_tthm_budtaxprice   
from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1 
where fbillno<>t1_fbillno 
) as t where diff_htqsdate>0
) as tt where tt.rn=1 
;

drop table if exists dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1_res2;
create table dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1_res2 stored as parquet as 
select 
row_id,fbillno,fmaterialid_fnumber,
'预算' as ckx,
f_tthm_budtaxprice as ckx_price 
from (select row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1 group by row_id,fbillno,fmaterialid_fnumber,f_tthm_budtaxprice ) as t
where row_id not in (select row_id from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1_res1)
;




drop table if exists dm_gis_uimp.tmp_dwd_purchase_ckx_res;
create table dm_gis_uimp.tmp_dwd_purchase_ckx_res stored as parquet as 
select 
t0.row_id,t0.fbillno,t0.fmaterialid_fnumber,
case 
when t1.ckx is not null then t1.ckx
when t2.ckx is not null then t2.ckx
when t3.ckx is not null then t3.ckx 
when t4.ckx is not null then t4.ckx
when t5.ckx is not null then t5.ckx 
else t6.ckx end as ckx, 
case 
when t1.ckx_price is not null then t1.ckx_price
when t2.ckx_price is not null then t2.ckx_price
when t3.ckx_price is not null then t3.ckx_price 
when t4.ckx_price is not null then t4.ckx_price
when t5.ckx_price is not null then t5.ckx_price 
else t6.ckx_price end as ckx_price 
from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder as t0 
left join (select row_id,fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnull  ) as t1 
on t0.row_id=t1.row_id and t0.fbillno=t1.fbillno and t0.fmaterialid_fnumber=t1.fmaterialid_fnumber
left join (
select row_id,fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull where ckx<>'下一步' ) as t2 
on t0.row_id=t2.row_id and t0.fbillno=t2.fbillno and t0.fmaterialid_fnumber=t2.fmaterialid_fnumber
left join (
select row_id,fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1_res1 ) as t3 
on t0.row_id=t3.row_id 
left join (
select row_id,fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_1_res2 ) as t4 
on t0.row_id=t4.row_id  
left join (
select row_id,fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1_res1 ) as t5 
on t0.row_id=t5.row_id 
left join (
select row_id,fbillno,fmaterialid_fnumber,ckx,ckx_price from dm_gis_uimp.tmp_dws_purchase_fsrcbillno_isnotnull_project_not1_res2 ) as t6 
on t0.row_id=t6.row_id 
;



-- 临时汇总表
drop table if exists dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_main;
create table dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_main stored as parquet as 
select action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,
line_code,kostl,ktext,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,
FPrice*fqty as fentryamount,
FTaxPrice*fqty as fallamount,
FPrice as fentryamount_unitprice,
FTaxPrice as fallamount_unitprice,
ckx,
-- case when f_tthm_cghtlx='A' and ckx='预算' then f_tthm_budtaxprice else null end as ckx_price,
ckx_price,
cg_type,
cgts_type,cgxy_price,
cgxy_price*fqty as cgxy_amount,
fallpayapplyamount,
FTaxPrice*fqty-fallpayapplyamount as nopay_amount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq  
from (
select t3.action_day,
t0.fbillno,t3.fpurchaserid_fnumber,t3.fpurchaserid_fname,t3.fpurchasedeptid_fnumber,t3.fpurchasedeptid_fname,
t0.fmaterialname,t0.fmaterialid_fnumber,
t1.fid,t1.ffullparentid,t1.one_j,t1.two_j,t1.one_j_name,t1.two_j_name,
t2.line_code,t2.kostl,t2.ktext,t2.line_name,t2.f_tthm_businesscenter,
t0.f_tthm_projectcode,t0.f_tthm_entryname,
t3.fdate,
t0.fapprovedate,t0.fchangedate,t0.fpayconditionid_fname,t0.fsupplierid_fnumber,t0.fsupplierid_fname,t0.f_tthm_pocontractno,t0.f_tthm_cghtlx,t0.fentrytaxrate,t0.f_tthm_amount,
if((t0.fclosestatus is null or t0.fclosestatus<>'B') and (t0.fmrpclosestatus is null or t0.fmrpclosestatus<>'B'),t0.fqty,t0.fbasereceiveqty-t0.fbasemrbqty) as fqty,
-- t0.fentryamount,t0.fallamount,
-- case when t0.f_tthm_cghtlx='A' then '预算' else null end as ckx,
t0.FPrice,
t0.FTaxPrice,
t7.ckx,
t7.ckx_price,
t0.f_tthm_budtaxprice,
t3.cg_type as cg_type,
t3.cgts_type as cgts_type,
t4.cgxy_price as cgxy_price,
t0.fallpayapplyamount,
-- t0.fallamount-t0.fallpayapplyamount as nopay_amount,
t0.notes,
t0.f_tthm_cpzbq,
t0.fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq  
from (select row_id,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,
fmaterialname,f_tthm_costcenter,fmaterialid_fnumber,f_tthm_materialgroupnumber,f_tthm_businesscenter,f_tthm_projectcode,f_tthm_entryname,
fdate,fapprovedate,fcanceldate,fchangedate,fcreatedate,fmodifydate,
fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,fqty,
fclosestatus,
fmrpclosestatus,
fbasereceiveqty,
fbasemrbqty,
-- fentryamount,fallamount,
f_tthm_budtaxprice,FPrice,ftaxprice,
fallpayapplyamount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq,
inc_day
from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder)  as t0 
left join (select fid,fnumber,ffullparentid,one_j,two_j,one_j_name,two_j_name from dm_gis_uimp.tmp_dwd_purchase_bd_material_group group by fid,fnumber,ffullparentid,one_j,two_j,one_j_name,two_j_name) as t1 
on t0.f_tthm_materialgroupnumber=t1.fnumber 
left join (select f_tthm_costcenter,unit_id,line_code,kostl,ktext,line_name,f_tthm_businesscenter from dm_gis_uimp.tmp_dwd_purchase_costcenter_bu_line group by f_tthm_costcenter,unit_id,line_code,kostl,ktext,line_name,f_tthm_businesscenter) as t2 
on t0.f_tthm_costcenter=t2.f_tthm_costcenter 
left join (select fbillno,action_day,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,cg_type,cgts_type,fdate from dm_gis_uimp.tmp_purchase_fbillno_first ) as t3 
on t0.fbillno=t3.fbillno 
left join (select fbillno,fmaterialid_fnumber,action_day,cgxy_price from dm_gis_uimp.tmp_purchase_fbillno_fmaterialid_fnumber_first ) as t4 
on t0.fbillno=t4.fbillno and t0.fmaterialid_fnumber=t4.fmaterialid_fnumber
left join (select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,purchase_type,special_purchase_type  from dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time_h) as t5 
on if(t0.fmaterialid_fnumber is not null,t0.fmaterialid_fnumber,'')=t5.fmaterialid_fnumber 
and if(t0.f_tthm_pocontractno is not null,t0.f_tthm_pocontractno,'')=t5.f_tthm_pocontractno 
and if(t0.fsupplierid_fnumber is not null,t0.fsupplierid_fnumber,'')=t5.fsupplierid_fnumber
left join (select fmaterialid_fnumber,f_tthm_pocontractno,fsupplierid_fnumber,fbk_amount/require_quantity as fbk_amount from dm_gis_uimp.tmp_dwd_purchase_srm_join_update_time_i) as t6 
on if(t0.fmaterialid_fnumber is not null,t0.fmaterialid_fnumber,'')=t6.fmaterialid_fnumber 
and if(t0.f_tthm_pocontractno is not null,t0.f_tthm_pocontractno,'')=t6.f_tthm_pocontractno 
and if(t0.fsupplierid_fnumber is not null,t0.fsupplierid_fnumber,'')=t6.fsupplierid_fnumber 
left join (select row_id,ckx,ckx_price from dm_gis_uimp.tmp_dwd_purchase_ckx_res ) as t7 
on t0.row_id=t7.row_id 
) as t 
;


-- 补上手工导入的fbillno没有发生变更的
drop table if exists dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_other;
create table dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_other stored as parquet as 
select 
action_day,
t0.fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,line_code,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,fentryamount,fallamount,fentryamount_unitprice,fallamount_unitprice,ckx,ckx_price,ckx_amount,jb_amount,cg_type,cgts_type,cgxy_price,cgxy_amount,fallpayapplyamount,
nopay_amount,notes,f_tthm_cpzbq,fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq  
from (
select 
action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,line_code,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,fentryamount,fallamount,fentryamount_unitprice,fallamount_unitprice,ckx,ckx_price,ckx_amount,jb_amount,cg_type,cgts_type,cgxy_price,cgxy_amount,fallpayapplyamount,
nopay_amount,notes,f_tthm_cpzbq,fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq 
from dm_gis_uimp.dws_purchase_contract_ledger_details where inc_day='20230815' 
) as t0 
left join (select fbillno from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_main group by fbillno) as t1 
on t0.fbillno=t1.fbillno 
where t1.fbillno is null
;




-- 写入到结果表
insert overwrite table dm_gis_uimp.dws_purchase_contract_ledger_details partition(inc_day='$firstDay')
select action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,line_code,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,fentryamount,fallamount,fentryamount_unitprice,fallamount_unitprice,ckx,ckx_price,ckx_amount,jb_amount,cg_type,cgts_type,cgxy_price,cgxy_amount,fallpayapplyamount,
nopay_amount,notes,f_tthm_cpzbq,fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq 
from (
select 
action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,
line_code,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,
fentryamount,fallamount,
-- fentryamount/fqty as fentryamount_unitprice,
-- fallamount/fqty as fallamount_unitprice,
fentryamount_unitprice,
fallamount_unitprice,
ckx,ckx_price,
ckx_price*fqty as ckx_amount,
if(ckx_price is null or ckx_price*fqty=0.0,null,ckx_price*fqty-fallamount) as jb_amount,
cg_type,
cgts_type,cgxy_price,
cgxy_amount,
fallpayapplyamount,
nopay_amount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq 
from (
select action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,
line_code,kostl,ktext,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,
fentryamount,
fallamount,
fentryamount_unitprice,
fallamount_unitprice,
ckx,
ckx_price,
cg_type,
cgts_type,cgxy_price,
cgxy_amount,
fallpayapplyamount,
nopay_amount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq  
from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_main 
) as t 
union all 
select 
action_day,
fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,
fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,line_code,line_name,f_tthm_businesscenter,
f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,f_tthm_amount,
fqty,fentryamount,fallamount,fentryamount_unitprice,fallamount_unitprice,ckx,ckx_price,ckx_amount,jb_amount,cg_type,cgts_type,cgxy_price,cgxy_amount,fallpayapplyamount,
nopay_amount,notes,f_tthm_cpzbq,fmaterialid_fspecification,
--  2024.01.09
f_tthm_htqsdate,f_tthm_htzzdate,f_tthm_htyxq  
from dm_gis_uimp.tmp_dwd_purchase_pur_purchaseorder_other
) as tt
;







-- hive2ck 
select action_day,fbillno,fpurchaserid_fnumber,fpurchaserid_fname,fpurchasedeptid_fnumber,fpurchasedeptid_fname,fmaterialname,fmaterialid_fnumber,fid,ffullparentid,one_j,two_j,one_j_name,two_j_name,
line_code,line_name,f_tthm_businesscenter,f_tthm_projectcode,f_tthm_entryname,fdate,fapprovedate,fchangedate,fpayconditionid_fname,fsupplierid_fnumber,fsupplierid_fname,f_tthm_pocontractno,f_tthm_cghtlx,fentrytaxrate,
cast(f_tthm_amount as double) as f_tthm_amount,
fqty,
cast(fentryamount as double) as fentryamount,
cast(fallamount as double) as fallamount,
cast(fentryamount_unitprice as double) as fentryamount_unitprice,
cast(fallamount_unitprice as double) as fallamount_unitprice,
ckx,
cast(ckx_price as double) as ckx_price,
cast(ckx_amount as double) as ckx_amount,
cast(jb_amount as double) as jb_amount,
cg_type,
cgts_type,
cast(cgxy_price as double) as cgxy_price,
cast(cgxy_amount as double) as cgxy_amount,
cast(fallpayapplyamount as double) as fallpayapplyamount,
cast(nopay_amount as double) as nopay_amount,
notes,
f_tthm_cpzbq,
fmaterialid_fspecification,
f_tthm_htqsdate,
f_tthm_htzzdate,	
f_tthm_htyxq,
inc_day 
from dm_gis_uimp.dws_purchase_contract_ledger_details 
where inc_day='$[time(yyyyMMdd,+0d)]'
