-- 
-- 数据同步项目管理系统（PMS）
-- 需求方：林中莉(01423677)
-- 需求： id: 1593568   【信息化标准服务】表数据同步_V1.6 
-- @author 张小琼 （01416344）
-- Created on 2023-02-28
-- 任务信息： 669948 ods_pms项目管理系统数据 每天6点5分执行
-- 


-- 项目信息表
CREATE  TABLE `dm_gis_uimp.ods_pms_project`(
`id` string COMMENT '项目ID',
`code` string COMMENT '项目代码',
`title_a` string COMMENT '项目名称',
`name_s` string COMMENT '状态',
`title_d` string COMMENT '所属组合',
`date01` string COMMENT '计划开始日期',
`date02` string COMMENT '计划结束日期',
`name_b` string COMMENT '项目类别,#费用统计类项目',
`str60` string COMMENT '关联商机代码',
`name_k` string COMMENT '所属公司, #系统字典表示例',
`name_l` string COMMENT '所属成本中心',
`name_m` string COMMENT '项目类型,#专项管理类项目',
`value_n` string COMMENT '所属业务中心',
`value_o` string COMMENT '所属营销中心',
`value_p` string COMMENT '所属行业',
`value_q` string COMMENT '细分行业',
`last_update_time` string COMMENT '修改日期' 
)
COMMENT '项目信息表'
STORED AS parquet 
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- ETL脚本模式同步
-- SELECT  a.id,
--  a.code,
--  a.title as title_a,
--  s.name as name_s,
--  d.title as title_d,
--  a.date01, 
--  a.date02, 
--  b.name as name_b,
--  a.str60,
--  k.name as name_k,
--  l.name as name_l,
--  m.name as name_m,
--  n.value as value_n,
--  o.value as value_o,
--  p.value as value_p,
--  q.value as value_q,
-- a.lastUpdateTime as last_update_time  
-- FROM 
--   gis_iis_pms.WF_Object w left outer join gis_iis_pms.WF_SchemaStatus s on s.id = w.status and s.schemaID = w.objectSubType and s.companyID = w.companyID,  
--   gis_iis_pms.ET_Project a left outer join gis_iis_pms.FM_FormSchema b on b.id = a.category and b.companyID = a.companyID
--  	left outer join gis_iis_pms.ET_Portfolio d on d.id = a.sys03 and d.companyID= a.companyID 
--  	left outer join gis_iis_pms.FT_CompanyCode k on a.enum41=k.id  and k.companyid=a.companyid
-- left outer join gis_iis_pms.FT_CostCenter l on a.enum39=l.id  and l.companyid=a.companyid
-- left outer join gis_iis_pms.ET_table904 m on a.enum49=m.id  and m.companyid=a.companyid
-- left outer join gis_iis_pms.fm_fORMFIELDVALUES n on a.enum35=n.id and a.category = n.referenceID and n.fieldID = 167 and n.companyID = a.companyID
-- left outer join gis_iis_pms.fm_fORMFIELDVALUES o on a.enum42=o.id and a.category = o.referenceID and o.fieldID = 174 and o.companyID = a.companyID
-- left outer join gis_iis_pms.fm_fORMFIELDVALUES p on a.enum36=p.id and a.category = p.referenceID and p.fieldID = 168 and p.companyID = a.companyID
-- left outer join gis_iis_pms.fm_fORMFIELDVALUES q on a.enum37=q.id and a.category = q.referenceID and q.fieldID = 169 and q.companyID = a.companyID
--  where  w.objectID = a.id and w.objectType = 50 and w.companyID = a.companyID

SELECT  a.id,
 a.code,
 a.title as title_a,
 s.name as name_s,
title_d,
 a.date01, 
 a.date02, 
 name_b,
 a.str60,
name_k,
name_l,
name_m,
value_n,
value_o,
value_p,
value_q,
a.lastUpdateTime as last_update_time  
FROM 
  gis_iis_pms.WF_Object w left outer join gis_iis_pms.WF_SchemaStatus s on s.id = w.status and s.schemaID = w.objectSubType and s.companyID = w.companyID,  
  gis_iis_pms.ET_Project a left outer join (select id,name as name_b,companyID from gis_iis_pms.FM_FormSchema ) as b on b.id = a.category and b.companyID = a.companyID
 	left outer join (select id,title as title_d,companyID from gis_iis_pms.ET_Portfolio) as d on d.id = a.sys03 and d.companyID= a.companyID 
 	left outer join (select name as name_k,id,companyid from gis_iis_pms.FT_CompanyCode ) as k on a.enum41=k.id  and k.companyid=a.companyid
left outer join (select name as name_l,id,companyid from gis_iis_pms.FT_CostCenter) as l on a.enum39=l.id  and l.companyid=a.companyid
left outer join (select name as name_m,id,companyid from gis_iis_pms.ET_table904) as m on a.enum49=m.id  and m.companyid=a.companyid
left outer join (select id,referenceID,fieldID,companyID,value as value_n from gis_iis_pms.fm_fORMFIELDVALUES ) as  n on a.enum35=n.id and a.category = n.referenceID and n.fieldID = 167 and n.companyID = a.companyID
left outer join (select id,referenceID,fieldID,companyID,value as value_o from gis_iis_pms.fm_fORMFIELDVALUES ) as  o on a.enum42=o.id and a.category = o.referenceID and o.fieldID = 174 and o.companyID = a.companyID
left outer join (select id,referenceID,fieldID,companyID,value as value_p from gis_iis_pms.fm_fORMFIELDVALUES ) as p on a.enum36=p.id and a.category = p.referenceID and p.fieldID = 168 and p.companyID = a.companyID
left outer join (select id,referenceID,fieldID,companyID,value as value_q from gis_iis_pms.fm_fORMFIELDVALUES ) as q on a.enum37=q.id and a.category = q.referenceID and q.fieldID = 169 and q.companyID = a.companyID
 where  w.objectID = a.id and w.objectType = 50 and w.companyID = a.companyID





-- 收入预算表
CREATE  TABLE `dm_gis_uimp.ods_pms_income`(
`id` string COMMENT '项目ID',
`code` string COMMENT '项目代码',
`title_d` string COMMENT '项目名',
`id_c` string COMMENT '收益类型ID',
`code_c` string COMMENT '收益类型编码',
`name_c` string COMMENT '收益类型名称',
`parentid` string COMMENT '收益类型父ID',
`name_b` string COMMENT '收益科目',
`id_e` string COMMENT '所属管理阶段ID',
`name_e` string COMMENT '所属管理阶段名称',
`year_e` string COMMENT '所属年',
`month_e` string COMMENT '所属月',
`phasevalue` string COMMENT '预算金额（元）',
`assign_date` string COMMENT '分配时间',
`companyid` string COMMENT '' 
)
COMMENT '收入预算表'
STORED AS parquet 
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- select d.id,
--   d.code,
--   d.title as title_d,
--   c.id as id_c,
--   c.code as code_c,
--   c.name as name_c,
--   c.parentid as parentid,
--   b.name as name_b,
--   e.id as id_e,
--   e.name as name_e,
--   a.year as year_e,
--   a.month + 1 as month_e,
--   a.phasevalue as phasevalue,
--   a.assignDate as assign_date, 
--   a.companyid
-- from gis_iis_pms.et_income a left outer join gis_iis_pms.ET_BenefitType b on a.incometypeid =b.id and a.companyid=b.companyid
-- left outer join gis_iis_pms.ET_BenefitType c on b.parentID =c.id and b.companyid=c.companyid
-- left outer join gis_iis_pms.et_project d on a.projectid=d.id and a.companyid=d.companyid
-- left outer join gis_iis_pms.et_lifephase e on a.phaseid = e.id and a.companyid=e.companyid

select d.id,
  d.code,
title_d,
id_c,
code_c,
name_c,
parentid_c,
name_b,
id_e,
name_e,
  a.year as year_e,
  a.month + 1 as month_e,
  a.phasevalue as phasevalue,
  a.assignDate as assign_date, 
  a.companyid
from gis_iis_pms.et_income a left outer join (select id,name as name_b,companyid,parentID from gis_iis_pms.ET_BenefitType ) as b on a.incometypeid =b.id and a.companyid=b.companyid
left outer join (select id as id_c,code as code_c,name as name_c,parentid as parentid_c,companyid  from gis_iis_pms.ET_BenefitType ) as  c on b.parentID =c.id_c and b.companyid=c.companyid
left outer join (select id,code,title as title_d,companyid from gis_iis_pms.et_project) as  d  on a.projectid=d.id and a.companyid=d.companyid
left outer join (select id as id_e,name as name_e,companyid from gis_iis_pms.et_lifephase ) as  e on a.phaseid = e.id_e and a.companyid=e.companyid




-- 成本预算表
CREATE  TABLE `dm_gis_uimp.ods_pms_cost`(
`project_id` string COMMENT '项目ID',
`code_b` string COMMENT '项目代码',
`title` string COMMENT '项目名称',
`id_e` string COMMENT '成本类型ID',
`code_e` string COMMENT '成本类型编码',
`name_e` string COMMENT '成本类型名称',
`parentid` string COMMENT '成本类型父ID',
`name_d` string COMMENT '成本科目',
`id_c` string COMMENT '所属管理阶段ID',
`name_c` string COMMENT '所属管理阶段名称',
`cost_value` string COMMENT '预算值',
`assign_date` string COMMENT '分配时间',
`year_a` string COMMENT '',
`month_a` string COMMENT '',
`company_id` string COMMENT '' 
)
COMMENT '成本预算表'
STORED AS parquet 
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- select a.projectID as project_id, 
--   b.code as code_b,
--   b.title as title,
--   e.id as id_e,
--   e.code as code_e,
--   e.name AS name_e,
--   e.parentid as parentid,
--   d.name AS name_d,
--   c.id AS id_c,
--   c.name AS name_c,   
--   a.costValue AS cost_value, 
--   a.assignDate AS assign_date, 
--   a.year AS year_a, 
--   (a.month + 1) AS month_a, 
--   a.companyID as company_id 
--   from gis_iis_pms.et_costBudget a
--   left outer join gis_iis_pms.et_project b on a.projectid=b.id and a.companyid=b.companyid
--   left outer join gis_iis_pms.et_lifephase c on a.phaseID=c.id and a.companyid=c.companyid
--   left outer join gis_iis_pms.et_expensetype d on a.costTypeID=d.id and a.companyid=d.companyid
--   left outer join gis_iis_pms.et_expensetype e on d.parentid=e.id and d.companyid=e.companyid

select a.projectID as project_id, 
code_b,
title_b,
  e.id as id_e,
  e.code as code_e,
  e.name AS name_e,
  e.parentid as parentid,
name_d,
id_c,
name_c,   
  a.costValue AS cost_value, 
  a.assignDate AS assign_date, 
  a.year AS year_a, 
  (a.month + 1) AS month_a, 
  a.companyID as company_id 
  from gis_iis_pms.et_costBudget a
  left outer join (select id,companyid,code as code_b,title as title_b  from gis_iis_pms.et_project ) as b on a.projectid=b.id and a.companyid=b.companyid
  left outer join (select companyid,id as id_c,name AS name_c from gis_iis_pms.et_lifephase ) as c on a.phaseID=c.id_c and a.companyid=c.companyid
  left outer join (select id,companyid,parentid,name as name_d from gis_iis_pms.et_expensetype ) as  d on a.costTypeID=d.id and a.companyid=d.companyid
  left outer join gis_iis_pms.et_expensetype e on d.parentid=e.id and d.companyid=e.companyid