
-- 
-- 
-- 需求方：林中莉(01423677)
-- 需求： 1805857 林中莉(01423677) 创建于 2023-05-23 19:01:22 GIS-ISSP-CORE：【经营看板专项】物料数据同步BDP_V1.0
-- @author 张小琼 （01416344）
-- Created on 2023-05-25
-- 任务信息： 任务ID：731751 采购数据_先写到ods再开发dwd	
-- 

-- 
-- 来源类型	来源详细信息
-- mysql	数据库地址：gisissp-m.db.sfcloud.local
-- 端口号：3306
-- 库名：gisissp
-- 表名：erp_material
-- 用户名：gisissp
-- 密码：Gis@ISSP@GIS

-- 建表
create table dm_gis_uimp.ods_mysql_erp_material(
material_id	string comment '物料序号（ID）',
nnumber	string comment '物料编码',
nname	string comment '物料名称',
use_org_id	string comment '使用组织',
create_com_id	string comment '公司代码',
specification	string comment '物料规格描述',
ddescription	string comment '物料描述',
material_group	string comment '物料分组',
base_property	string comment '物料分组编码',
supplier	string comment '供应商名称',
brand	string comment '品牌',
combo	string comment '物料状态',
cwkf	string comment '财务分类',
erp_cis_id	string comment '物料属性',
category_id	string comment '存货类别',
tax_type	string comment '税分类',
tax_rate_id	string comment '默认税率',
base_unit_id	string comment '基本单位',
gross_weight	string comment '毛重',
new_weight	string comment '净重',
weight_unit_id	string comment '重量单位',
llength	string comment '长',
width	string comment '宽',
height	string comment '高',
volume	string comment '体积',
volume_unit_id	string comment '尺寸单位',
suite	string comment '套件',
forbid_status	string comment '禁用状态',
document_status	string comment '数据状态',
check_incoming	string comment '来料检验',
create_time	string comment '创建时间',
update_time	string comment '修改日期',
store_unit	string comment '库存单位',
purchase_unit_id	string comment '采购单位'
)
comment '采购数据-物料数据丰图MDM系统' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- etl  
select 
material_id,number,name,use_org_id,create_com_id,specification,description,material_group,base_property,supplier,brand,combo,cwkf,erp_cis_id,category_id,tax_type,tax_rate_id,base_unit_id,gross_weight,new_weight,weight_unit_id,length,width,height,volume,volume_unit_id,suite,forbid_status,document_status,check_incoming,create_time,update_time,store_unit,purchase_unit_id 
from gisissp.erp_material 