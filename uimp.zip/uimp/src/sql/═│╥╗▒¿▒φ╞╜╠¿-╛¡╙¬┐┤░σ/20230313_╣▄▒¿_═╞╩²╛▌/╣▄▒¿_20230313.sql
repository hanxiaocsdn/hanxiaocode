-- 
-- 管报数据
-- 需求方：
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2023-03-13
-- 任务信息： 
-- 

-- 1. excel导入dbp
create table dm_gis_uimp.tmp_ft_management_report_detail(
id string comment 'id',
fi_category string comment '类别',
fi_tag string comment '标识',
company_code string comment '公司代码',
yyyy_mm string comment '年度/月份',
posting_period string comment '过帐期间',
document_nubmer string comment '凭证编号',
posting_key string comment '记帐代码',
profit_center string comment '利润中心',
tr_prt string comment 'Tr.prt',
gl_account string comment '总账科目',
account_name string comment '科目名称',
account_name_lvl3 string comment '预算三级科目',
account_name_lvl2 string comment '预算二级科目',
account_name_lvl1 string comment '预算一级科目',
gl_amount string comment'总帐金额',
t_text string comment '文本',
client string comment '客户',
supplier string comment '供应商',
xref3 string comment '参考码3',
local_currency_amount string comment'本币金额',
local_currency string comment '本币',
acct string comment '科目',
bp_cost_center string comment '业务伙伴成本中心',
cost_center string comment '成本中心',
cost_center_name string comment '成本中心名称',
cc_business_unit string comment '成本中心对应经营单元',
cc_business_line string comment '成本中心对应业务线',
center_name_type string comment '成本中心类型',
ledgers_project string comment '总分类帐项目',
project_id string comment '项目代码',
project_name string comment '项目名称',
p_business_unit string comment '项目对应经营单元',
p_business_line string comment '项目对应业务线',
project_type string comment '项目类型',
project_category string comment '项目类别',
project string comment '项目',
clearing_document string comment '清帐凭证',
d_distribution string comment '分配',
reverse_posting string comment '反记帐',
functional_area string comment '功能范围',
functional_area_text string comment '功能范围文本',
revenue_category string comment '收入类别',
tbc_account string comment '需判定的科目',
confirmed_budget_item_lvl4 string comment '确定预算4级分类',
confirmed_budget_item_lvl3 string comment '确定预算3级分类',
confirmed_budget_item_lvl2 string comment '确定预算2级分类',
confirmed_budget_item_lvl1 string comment '确定预算1级分类',
confirmed_business_unit string comment '最终确认的经营单元',
confirmed_business_line string comment '最终确认的业务线' 
) 
comment '管报(临时)' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'='\t')
STORED AS TEXTFILE
;

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/gb_data_20230313.csv' OVERWRITE INTO TABLE dm_gis_uimp.tmp_ft_management_report_detail;



-- 2. 数据加密 
-- 加密字段： gl_amount、local_currency_amount、project_id、project_name
create table dm_gis_uimp.ods_ft_management_report_detail(
id string comment 'id',
fi_category string comment '类别',
fi_tag string comment '标识',
company_code string comment '公司代码',
yyyy_mm string comment '年度/月份',
posting_period string comment '过帐期间',
document_nubmer string comment '凭证编号',
posting_key string comment '记帐代码',
profit_center string comment '利润中心',
tr_prt string comment 'Tr.prt',
gl_account string comment '总账科目',
account_name string comment '科目名称',
account_name_lvl3 string comment '预算三级科目',
account_name_lvl2 string comment '预算二级科目',
account_name_lvl1 string comment '预算一级科目',
gl_amount string comment'总帐金额',
t_text string comment '文本',
client string comment '客户',
supplier string comment '供应商',
xref3 string comment '参考码3',
local_currency_amount string comment'本币金额',
local_currency string comment '本币',
acct string comment '科目',
bp_cost_center string comment '业务伙伴成本中心',
cost_center string comment '成本中心',
cost_center_name string comment '成本中心名称',
cc_business_unit string comment '成本中心对应经营单元',
cc_business_line string comment '成本中心对应业务线',
center_name_type string comment '成本中心类型',
ledgers_project string comment '总分类帐项目',
project_id string comment '项目代码',
project_name string comment '项目名称',
p_business_unit string comment '项目对应经营单元',
p_business_line string comment '项目对应业务线',
project_type string comment '项目类型',
project_category string comment '项目类别',
project string comment '项目',
clearing_document string comment '清帐凭证',
d_distribution string comment '分配',
reverse_posting string comment '反记帐',
functional_area string comment '功能范围',
functional_area_text string comment '功能范围文本',
revenue_category string comment '收入类别',
tbc_account string comment '需判定的科目',
confirmed_budget_item_lvl4 string comment '确定预算4级分类',
confirmed_budget_item_lvl3 string comment '确定预算3级分类',
confirmed_budget_item_lvl2 string comment '确定预算2级分类',
confirmed_budget_item_lvl1 string comment '确定预算1级分类',
confirmed_business_unit string comment '最终确认的经营单元',
confirmed_business_line string comment '最终确认的业务线' 
) 
comment '管报' 
PARTITIONED BY ( inc_day string COMMENT '分区日期')
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- hive 端
select base64(cast(gl_amount as binary)) as gl_amount,base64(cast(local_currency_amount as binary)) as local_currency_amount from dm_gis_uimp.ods_ft_management_report_detail 

-- clickhouse 端
select base64Decode(gl_amount) as gl_amount,base64Decode(local_currency_amount) as local_currency_amount from ft_management_report_detail