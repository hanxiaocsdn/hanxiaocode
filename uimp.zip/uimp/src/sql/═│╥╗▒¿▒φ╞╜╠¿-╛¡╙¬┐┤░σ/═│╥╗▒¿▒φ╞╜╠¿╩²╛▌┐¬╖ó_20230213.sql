-- 
-- 需求方：林中莉(01423677)
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2022-09-16
-- 任务信息： ID：484385  ods_SSP供应商结算云(丰图)
-- 

-- dm_gis_uimp   库名    统一指标管理平台
-- 有问题可进“问题答疑群”咨询。1、差旅平台: https://btrip.sf-express.com/home.html#/homePage          2、报销平台：http://ers.sf-express.com/module/index.html    

-- SSP供应商结算云数据
-- "ods_ssp2.plf_form_business_data_cfg（表单业务源数据表）" 分类主数据表，用来对业务类型、单据类型、业务事项做名称转换 lessee_no="FTFIN"
-- "ods_ssp2.plf_form_body（SSP供应商结算云的表单主体表）"     表单主体表  lessee_no="FTFIN"
-- "ods_ssp2.plf_form_account_detail（SSP供应商结算云的表单明细数据表）"  表单明细表  lessee_no="FTFIN"
--  ods_ssp2.plf_form_apprecial_tax_detail（SSP供应商结算云的增值税专票明细表）
--  ods_ssp2.plf_form_life   (表单操作记录表)
-- 丰味数据 
--  dm_meal.ft_meal_order_detail 订单明细表
--  dm_meal.ft_meal_order_pay_detail 交易明细表
--  dm_meal.ft_meal_ot_apply_form_dtl 加班申请明细
-- 丰享数据
--  ods_fx_dwd.dwd_feng_tu_order_detail 丰图的丰享数据同步表


CREATE  TABLE `dm_gis_uimp.ods_plf_form_business_data_cfg`(
`id` int COMMENT 'id',
`data_type` int COMMENT '数据类型 1 所属组织 2 单据类型 3 业务类型 4 业务事项 5 组织细分',
`data_value` string COMMENT '名称',
`data_code` string COMMENT '编码',
`create_user` string COMMENT '创建人',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '更新人',
`update_time` string COMMENT '更新时间',
`is_enabled` int COMMENT '有效状态 1 有效 0 无效',
`lessee_no` string COMMENT '租户编码')
COMMENT '表单业务源数据表'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE  TABLE `dm_gis_uimp.ods_plf_form_body`(
`body_id` bigint COMMENT '主键ID',
`lessee_no` string COMMENT '租户编码',
`organization_code` string COMMENT '所属组织编码',
`fractionize_organization_code` string COMMENT '细分组织编码',
`order_no` string COMMENT '单据编号',
`order_type_code` string COMMENT '单据类型编码',
`business_type_code` string COMMENT '业务类型编码',
`order_name` string COMMENT '单据名称',
`company_code` string COMMENT '公司代码',
`company_name` string COMMENT '公司名称',
`currency_type` string COMMENT '币种',
`currency_rate` decimal(4,2) COMMENT '汇率',
`create_id` string COMMENT '创建人',
`apply_id` string COMMENT '申请人',
`cost_center` string COMMENT '成本中心',
`cost_center_name` string COMMENT '成本中心名称',
`is_prepay` int COMMENT '是否预付，0否，1是',
`is_verifi` int COMMENT '0 核销 1 支付 2 核销并支付',
`is_sterilisation` int COMMENT '是否冲销',
`bankl` string COMMENT '银行代码',
`pay_type` string COMMENT '支付方式：1正常支付，2银行托收，3支票，4总部代付',
`supplier_account` string COMMENT '供应商编码',
`supplier_name` string COMMENT '供应商名称',
`account_name` string COMMENT '收款单位',
`bank_account` string COMMENT '收款账号',
`account_code` string COMMENT '开户行信息',
`matter_desc` string COMMENT '事项说明',
`payment_desc` string COMMENT '付款说明',
`is_total_pay` int COMMENT '是否统付，0否，1是',
`order_status` int COMMENT '单据状态：删除(0) 新建(10) 待提交(20) 等待影像(30) 待提交流程(40) ecp处理中(50) 待提交fsop(60) 提交FSOP异常(61) fsop处理中(70) 财务过账中(80) 过账失败(81) 单据完成(82) 单据冲销中(90)冲销失败(91) 冲销成功(92) 单据已付款(100) 单据付款失败(101)',
`voucher_status` int COMMENT '凭证调用状态（0、未开始:可以改数据 1、调用中:锁数据 2、失败：可以改数据 3、成功：锁数据 4、超时：锁数据 5、处理中：锁数据 6、其他：锁数据）',
`screenage_status` int COMMENT '影像状态, 0、删除，1、已上传，2、业务退单，3、业务补单，4、扫描退单，5、扫描补单',
`screenage_no` string COMMENT '影像号',
`screenage_no_his` string COMMENT '影像号历史',
`payment_no` string COMMENT '付款凭证号',
`voucher_no` string COMMENT 'SAP凭证号',
`verifi_no` string COMMENT '冲销凭证号',
`verifi_order_no` string COMMENT '冲销单据号',
`purchase_no` string COMMENT '采购订单号',
`error_msg` string COMMENT '错误信息',
`reject_type` int COMMENT '驳回类型(1、退单退影像；2、退单补影像；3、仅退影像；4、仅补影像；5、退单不退影像)',
`again_submit_type` int COMMENT '驳回后再次提交类型 (1 直送至我； 2 逐级审批)',
`fsop_reject_method` int COMMENT '共享分单驳回方式(0,非财务驳回 1,财务驳回)',
`totol_foreign_money` decimal(24,2) COMMENT '总的交易货币金额',
`total_cur_pay_money` decimal(24,2) COMMENT '总的本次应付金额',
`is_apprecia_job_byuse` int COMMENT '是否被增值税抽数定时器使用标志',
`benchmark_time` string COMMENT '基准日期',
`posting_time` string COMMENT '过账日期',
`business_depart_person` string COMMENT '地区业务管理部门负责人',
`financial_approver` string COMMENT '财务审批人',
`financial_approver_name` string COMMENT '财务审批人名称',
`suggest_info` string COMMENT '审批建议',
`term_of_payment` string COMMENT '付款条件',
`contract_no` string COMMENT '合同号',
`version_num` string COMMENT '合同版本号',
`bvtyp` string COMMENT '合作银行类型',
`payment_time` string COMMENT '付款日期',
`expect_payment_time` string COMMENT '期望付款日期',
`is_cat_image` int COMMENT '是否收到EIOS的确认消息，0否，1是',
`is_notice_fsop` int COMMENT '是否通知分单系统，0否，1是',
`is_notice_eios` int COMMENT '是否通知eios',
`image_num` int COMMENT '影像数量',
`image_upload_time` string COMMENT '影像上传时间',
`image_scaner_user` string COMMENT '影像扫描人',
`reasons_for_payment` string COMMENT '线下支付原因',
`approval_enter` string COMMENT '审核入口: FSOP审批入口， SSP审核入口',
`data_type` int COMMENT '数据分类，1 外围推送无需审批 2 外围推送需要审批 3 SSP预付表单填写',
`image_source` string COMMENT '影像来源',
`measure_core` string COMMENT '预算编码',
`payment_status` string COMMENT '支付状态',
`bank_call_msg` string COMMENT '银行响应消息',
`front_origin` string COMMENT '外围系统编码',
`detail_sum` int COMMENT '明细数量',
`template_code` string COMMENT '单据模板编码',
`flow_code` string COMMENT '流程编码',
`template_node_id` int COMMENT '当前流程节点(关联流程节点配置表)',
`reject_node_id` int COMMENT '退回节点',
`ecp_run_id` string COMMENT 'ecp_run_id',
`ele_inv_flag` string COMMENT '是否都是电子发票 Y是 N不是',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '修改人',
`update_time` string COMMENT '记录最后一次更新时间戳',
`attr1` string COMMENT '大写金额',
`attr2` string COMMENT '初审描述',
`attr3` string COMMENT '备用字段3',
`attr4` string COMMENT '备用字段4',
`attr5` string COMMENT '备用字段5',
`create_name` string COMMENT '创建人姓名',
`apply_name` string COMMENT '申请人姓名',
`business_depart_person_name` string COMMENT '地区业务管理部门负责人姓名',
`company_merge_flag` string COMMENT '公司账套合并标记',
`swift_code` string COMMENT '国际付款的SWIFT/BIC',
`payment_frozen_status` string COMMENT '付款冻结状态(Y:是 X:推送FPE)',
`country` string COMMENT '国别',
`standard_money` string COMMENT '本位币',
`standard_money_amount` decimal(24,2) COMMENT '本位币金额',
`push_fpe_flag` int COMMENT '是否集成过账(0:自动 1:手动)',
`account_detail_currency_type` string COMMENT '费用明细币种',
`practice_payment_currency_type` string COMMENT '实际付款币种',
`practice_payment_amount` decimal(12,2) COMMENT '实际付款金额',
`is_exist_ele_invoice` string COMMENT '是否存在电子发票',
`is_exist_paper_material` string COMMENT '是否存在纸质材料',
`audit_user_first` string COMMENT '初审人',
`audit_user_second` string COMMENT '复审人',
`audit_finish_time` string COMMENT '复审时间',
`other_business_type` string COMMENT '业务大类',
`other_area` string COMMENT '大区',
`other_bu` string COMMENT 'bu',
`biz_type` string COMMENT '支付云业务类型',
`pay_way` string COMMENT '支付云付款方式',
`total_contract_amount` string COMMENT '总合同金额',
`total_payments_num` string COMMENT '总付款次数',
`current_payments_num` string COMMENT '本次款次数',
`is_project_special` string COMMENT '是否客户项目专属投入',
`attr6` string COMMENT '预留字段',
`attr7` string COMMENT '预留字段',
`attr8` string COMMENT '预留字段',
`attr9` string COMMENT '预留字段',
`attr10` string COMMENT '预留字段',
`attr11` string COMMENT '预留字段',
`attr12` string COMMENT '预留字段')
COMMENT '表单主体表'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE  TABLE `dm_gis_uimp.ods_plf_form_account_detail`(
`detail_id` bigint COMMENT '明细编号',
`lessee_no` string COMMENT '租户编码',
`order_no` string COMMENT '单据编号',
`order_type_code` string COMMENT '单据类型编码',
`business_type_code` string COMMENT '业务类型编码',
`business_item_code` string COMMENT '业务事项编码',
`cost_center` string COMMENT '成本中心',
`cost_center_name` string COMMENT '成本中心名称',
`kostl_no` string COMMENT '反向成本中心',
`kostl_reverse_name` string COMMENT '反向成本中心名称',
`customer_code` string COMMENT '客户代码',
`customer_name` string COMMENT '客户名称',
`project_code` string COMMENT '项目代码',
`project_code_name` string COMMENT '项目代码名称',
`big_customer_code` string COMMENT '大客户项目代码',
`big_customer_name` string COMMENT '大客户项目描述',
`foreign_money` decimal(24,2) COMMENT '交易货币金额',
`pay_type` string COMMENT '支付方式：1正常支付，2银行托收，3支票，4总部代付',
`budget_examine` string COMMENT '预算查看',
`security_deposit_money` string COMMENT '不含税金额',
`security_deposit_money_handler` string COMMENT '手工修改不含税金额',
`bill_type` string COMMENT '票据类型',
`post_attr` string COMMENT '岗位属性',
`employment_mode` string COMMENT '用工模式',
`license_plate_no` string COMMENT '车牌号',
`supplier_account` string COMMENT '供应商编码',
`supplier_name` string COMMENT '供应商名称',
`bvtyp_type` string COMMENT '合作银行类型',
`banks_code` string COMMENT '银行国家代码',
`dtaws_code` string COMMENT '指令码',
`umskz_flag` string COMMENT '特别总账标识',
`zlspr_flag` string COMMENT '付款冻结',
`prctr` string COMMENT '利润中心',
`xref3` string COMMENT '参考码3',
`ihrez_no` string COMMENT '虚拟合同号',
`account_name` string COMMENT '收款单位',
`bank_account` string COMMENT '收款账号',
`account_code` string COMMENT '开户行信息',
`is_monthly_statement` int COMMENT '是否月结',
`is_support_value` int COMMENT '是否保价',
`asset_card_no` string COMMENT '资产卡片号',
`io_order_no` string COMMENT 'IO订单号/采购订单号',
`asset_net_worth` decimal(24,2) COMMENT '资产净值',
`tax_rate` decimal(4,2) COMMENT '税率',
`tax_code` string COMMENT '税码',
`is_enjoy_tax_reliefs` int COMMENT '是否享受减免税',
`invoice_type` string COMMENT '发票类型',
`claim_type` string COMMENT '认领类型',
`quarter_rate` decimal(4,2) COMMENT '季度利率',
`capitalization_money` decimal(24,2) COMMENT '资本化金额',
`sgtxt` string COMMENT '行文本',
`account_voucher_no` string COMMENT '会计凭证号',
`first_purchase_date` string COMMENT '首次购置日期',
`cbe_code` string COMMENT 'CBE编码',
`expense_incurred_during` string COMMENT '费用发生期间',
`quality_retention_money` decimal(24,2) COMMENT '质保金/核销金额',
`account_item_no` string COMMENT '会计凭证行项目号',
`purchase_order_no` string COMMENT '采购订单号',
`purchase_item_no` string COMMENT '采购凭证的项目编号',
`retirement_date` string COMMENT '报废日期',
`cancel_lation_date` string COMMENT '预计核销日期',
`is_amortization` int COMMENT '是否摊销(0代表否，1代表是)',
`trade_partner` string COMMENT '贸易伙伴',
`is_remove_tax` int COMMENT '是否拆税，1是，0是',
`invoice_no` string COMMENT '发票号码',
`claimant_no` string COMMENT '索赔编号',
`exception_traffic_no` string COMMENT '交通事故异常编号',
`bus_contract_no` string COMMENT '业务合同编号',
`io_code` string COMMENT 'IO编码',
`order_number` string COMMENT '订单编号',
`material_group` string COMMENT '物料组',
`line_num` string COMMENT '行号',
`business_date` string COMMENT '业务日期',
`cost_type` string COMMENT '费用类型',
`line_count` int COMMENT '数量',
`line_unit` string COMMENT '单位',
`voucher_no` string COMMENT 'SAP凭证号',
`payment_no` string COMMENT '付款凭证号',
`posting_time` string COMMENT '过账日期',
`payment_time` string COMMENT '付款日期',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '操作人',
`update_time` string COMMENT '记录最后一次更新时间戳',
`attr1` string COMMENT 'Y',
`attr2` string COMMENT '备用字段2',
`attr3` string COMMENT '备用字段3',
`attr4` string COMMENT '备用字段4',
`attr5` string COMMENT '备用字段5',
`attr6` string COMMENT '备用字段6',
`attr7` string COMMENT '备用字段7',
`attr8` string COMMENT '备用字段8',
`attr9` string COMMENT '备用字段9',
`attr10` string COMMENT '备用字段10',
`saknr` string COMMENT '会计科目',
`cost_more_company_flag` string COMMENT '成本中心跨账套使用',
`amortization` string COMMENT '摊销科目',
`invoice_currency` string COMMENT '预付:发票货币/应付:付款货币',
`invoice_tax_amount` decimal(12,2) COMMENT '发票税额',
`invoice_date` string COMMENT '发票日期',
`withholding_tax_rate` decimal(12,4) COMMENT '预付:代扣税税率/应付:预扣税税率',
`withholding_tax_amount` decimal(12,2) COMMENT '预付:代扣税税额/应付:预扣税税额',
`invoice_currency_rate` decimal(9,6) COMMENT '发票货币汇率',
`payment_currency_amount` decimal(12,2) COMMENT '付款货币金额',
`beic_req_id` string COMMENT '支付云Beic请求ID',
`product_code` string COMMENT '产品代码',
`base_date` string COMMENT '基准日',
`due_date` string COMMENT '到期日',
`flight_no` string COMMENT '航班号',
`route_code` string COMMENT '路线编码',
`start_address` string COMMENT '起始地',
`end_address` string COMMENT '目的地',
`fpe_business_item_code` string COMMENT 'fpe业务事项编码',
`transit_dr` string COMMENT '中转科目借方',
`transit_cr` string COMMENT '中转科目贷方')
COMMENT '表单明细数据表'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

CREATE  TABLE `dm_gis_uimp.ods_plf_form_apprecial_tax_detail`(
`apprecia_id` bigint COMMENT '明细编号',
`lessee_no` string COMMENT '租户',
`order_no` string COMMENT '单据编号',
`order_type_code` string COMMENT '单据类型编码',
`business_type_code` string COMMENT '业务类型编码',
`invoice_date` string COMMENT '开票日期',
`invoice_no` string COMMENT '发票号码',
`invoice_code` string COMMENT '发票代码',
`tax_rate` string COMMENT '税率',
`mwskz` string COMMENT '税码',
`tax_money` decimal(24,2) COMMENT '税额',
`totol_money` decimal(24,2) COMMENT '总额',
`zc_reason` string COMMENT '进项转出编码，01：员工福利费、业务招待费、不认证或转出 02：多开发票部分转出',
`result_time` string COMMENT '结果集时间戳',
`create_user` string COMMENT '创建人',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '操作人',
`update_time` string COMMENT '操作时间',
`attr1` string COMMENT '备用字段1',
`attr2` string COMMENT '备用字段2',
`attr3` string COMMENT '备用字段3',
`attr4` string COMMENT '备用字段4',
`attr5` string COMMENT '备用字段5',
`invoice_source` string COMMENT '发票来源(1:EIOS确认 2:用户录入)',
`invoice_status` string COMMENT '发票状态(0:已删除 1:有效)',
`tax_out_amount` double COMMENT '进项税转出金额',
`check_result` string COMMENT '发票校验结果\;0-未比对，1-一致，2-不一致')
COMMENT '增值税专票明细表'
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE TABLE `dm_gis_uimp.ods_ft_meal_order_detail`(
`sys_code` string COMMENT '系统来源编码',
`sys_name_zh` string COMMENT '系统来源名称(简体)',
`sys_name_en` string COMMENT '系统来源名称(英文)',
`sys_name_tw` string COMMENT '系统来源名称(繁体)',
`order_code` string COMMENT '订单号',
`outer_order_code` string COMMENT '外部订单号',
`order_name_zh` string COMMENT '订单名称(简体)',
`order_name_en` string COMMENT '订单名称(英文)',
`order_name_tw` string COMMENT '订单名称(繁体)',
`order_type_code` string COMMENT '订单类型编码(staffCanteen/takeout/onsiteShop/otMeals/otNightMeal/meetingMeal)',
`order_type_name_zh` string COMMENT '订单类型名称(简体)',
`order_type_name_en` string COMMENT '订单类型名称(英文)',
`order_type_name_tw` string COMMENT '订单类型名称(繁体)',
`ot_apply_no` string COMMENT '加班申请号(订单类型为加班或加班宵夜必填)',
`order_source_code` string COMMENT '订单来源编码(pc/app/wx/oth)',
`order_source_name_zh` string COMMENT '订单来源名称(简体)',
`order_source_name_en` string COMMENT '订单来源名称(英文)',
`order_source_name_tw` string COMMENT '订单来源名称(繁体)',
`order_status_code` string COMMENT '订单状态编码',
`order_status_name_zh` string COMMENT '订单状态名称(简体)',
`order_status_name_en` string COMMENT '订单状态名称(英文)',
`order_status_name_tw` string COMMENT '订单状态名称(繁体)',
`login_user_name` string COMMENT '消费者账号',
`emp_name_zh` string COMMENT '消费者姓名(简体)',
`emp_name_en` string COMMENT '消费者姓名(英文)',
`emp_name_tw` string COMMENT '消费者姓名(繁体)',
`sob_code` string COMMENT '账套编码(公司代码)',
`cc_code` string COMMENT '成本中心编码',
`suppl_code` string COMMENT '供应商编码',
`suppl_name_zh` string COMMENT '供应商名称(简体)',
`suppl_name_en` string COMMENT '供应商名称(英文)',
`suppl_name_tw` string COMMENT '供应商名称(繁体)',
`order_time` timestamp COMMENT '下单时间',
`order_count` int COMMENT '数量',
`order_receiver` string COMMENT '收件人名称',
`receiv_addr` string COMMENT '收件人地址',
`receiv_addr_mask` string COMMENT '收件人地址掩码',
`receiv_addr_encrypt` string COMMENT '收件人地址密文',
`expct_receiv_time` timestamp COMMENT '期望收货时间',
`curr_code` string COMMENT '货币代码',
`curr_sign` string COMMENT '货币符号',
`order_amount` decimal(16,2) COMMENT '订单金额',
`enterprisepay_amount` decimal(16,2) COMMENT '公司结算',
`mealcardpay_amount` decimal(16,2) COMMENT '员工餐卡',
`alipay_amount` decimal(16,2) COMMENT '支付宝',
`wechatpay_amount` decimal(16,2) COMMENT '微信支付',
`unionpay_amount` decimal(16,2) COMMENT '银联支付',
`otherpay_amount` decimal(16,2) COMMENT '其他支付',
`cancel_reason_code` int COMMENT '取消原因编码',
`cancel_reason_name_zh` string COMMENT '取消原因名称(简体)',
`cancel_reason_name_en` string COMMENT '取消原因名称(英文)',
`cancel_reason_name_tw` string COMMENT '取消原因名称(繁体)',
`cancel_reason_msg_zh` string COMMENT '具体取消原因(简体)',
`cancel_reason_msg_en` string COMMENT '具体取消原因(英文)',
`cancel_reason_msg_tw` string COMMENT '具体取消原因(繁体)',
`order_eval_level` int COMMENT '评价等级(1-5)',
`order_remark_zh` string COMMENT '备注说明(简体)',
`order_remark_en` string COMMENT '备注说明(英文)',
`order_remark_tw` string COMMENT '备注说明(繁体)',
`pc_order_url` string COMMENT 'pc订单详情url',
`app_order_url` string COMMENT 'app订单详情url',
`encrypt_mode` string COMMENT '加密模式(sf/local)',
`is_valid` string COMMENT '是否有效（Y/N）',
`data_source` string COMMENT '数据来源(local/bdus等)',
`create_user` string COMMENT '创建者账号',
`create_time` timestamp COMMENT '创建时间',
`update_user` string COMMENT '更新者账号',
`update_time` timestamp COMMENT '更新时间')
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE TABLE `dm_gis_uimp.ods_ft_meal_order_pay_detail`(
`order_id` bigint COMMENT '订单ID',
`order_code` string COMMENT '订单号',
`outer_order_code` string COMMENT '外部订单号',
`pay_id` string COMMENT '交易流水号',
`pay_time` timestamp COMMENT '交易时间',
`pay_mode_code` string COMMENT '支付方式编码(mealcard/alipay/wechatPay/unionPay/enterprisePay/otherPay)',
`pay_mode_name_zh` string COMMENT '支付方式名称(简体)',
`pay_mode_name_en` string COMMENT '支付方式名称(英文)',
`pay_mode_name_tw` string COMMENT '支付方式名称(繁体)',
`curr_code` string COMMENT '货币代码',
`curr_sign` string COMMENT '货币符号',
`pay_amount` decimal(16,2) COMMENT '交易金额',
`pay_account_no` string COMMENT '交易账户编码',
`suppl_code` string COMMENT '供应商编码',
`pay_account_name_zh` string COMMENT '交易账户名称(中文)',
`pay_account_name_en` string COMMENT '交易账户名称(英文)',
`pay_account_name_tw` string COMMENT '交易账户名称(繁体)',
`suppl_name_zh` string COMMENT '供应商名称(中文)',
`suppl_name_en` string COMMENT '供应商名称(英文)',
`suppl_name_tw` string COMMENT '供应商名称(繁体)',
`pay_name_zh` string COMMENT '交易名称(中文)',
`pay_name_tw` string COMMENT '交易名称(繁体)',
`pay_name_en` string COMMENT '交易名称(英文)',
`refund_reason_code` int COMMENT '退款原因编码（数据字典）',
`refund_reason_name_zh` string COMMENT '退款原因名称(简体)',
`refund_reason_name_en` string COMMENT '退款原因名称(英文)',
`refund_reason_name_tw` string COMMENT '退款原因名称(繁体)',
`refund_reason_msg_zh` string COMMENT '退款详细描述(简体)',
`refund_reason_msg_en` string COMMENT '退款详细描述(英文)',
`refund_reason_msg_tw` string COMMENT '退款详细描述(繁体)',
`is_valid` string COMMENT '是否有效（Y/N）',
`data_source` string COMMENT '数据来源(local/bdus等)',
`create_user` string COMMENT '创建者账号',
`create_time` timestamp COMMENT '创建时间',
`update_user` string COMMENT '更新者账号',
`update_time` timestamp COMMENT '更新时间',
`sob_code` string COMMENT '账套编码',
`cc_code` string COMMENT '成本中心编码',
`order_status_code` string COMMENT '订单状态编码',
`order_status_name_zh` string COMMENT '订单状态名称(简体)',
`order_status_name_en` string COMMENT '订单状态名称(英文)',
`order_status_name_tw` string COMMENT '订单状态名称(繁体)',
`check_status_code` string COMMENT '对账状态编码',
`check_status_name_zh` string COMMENT '对账状态名称(简体)',
`check_status_name_en` string COMMENT '对账状态名称(英文)',
`check_status_name_tw` string COMMENT '对账状态名称(繁体)')
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE TABLE `dm_gis_uimp.ods_ft_meal_ot_apply_form_dtl`(
`ot_form_code` string COMMENT '申请单号(OT(2位)+YYMMDDHH24MINSSMS(15位)+6位随机码)',
`ot_form_name_zh` string COMMENT '申请单名称(简体)',
`ot_form_name_en` string COMMENT '申请单名称(英文)',
`ot_form_name_tw` string COMMENT '申请单名称(繁体)',
`ot_apply_code` string COMMENT '加班申请类型编码(otMeals:加班餐\;otNightMeal:加班宵夜)',
`ot_apply_name_zh` string COMMENT '申请类型名称(简体)',
`ot_apply_name_en` string COMMENT '申请类型名称(英文)',
`ot_apply_name_tw` string COMMENT '申请类型名称(繁体)',
`login_channel_code` string COMMENT '渠道来源编码(pc/app/wx/oth)',
`login_channel_name_zh` string COMMENT '渠道来源名称(简体)',
`login_channel_name_en` string COMMENT '渠道来源名称(英文)',
`login_channel_name_tw` string COMMENT '渠道来源名称(繁体)',
`ot_form_status_code` string COMMENT '状态编码(submit/order/del/applied/done/settled)',
`ot_form_status_name_zh` string COMMENT '状态名称(简体)',
`ot_form_status_name_en` string COMMENT '状态名称(英文)',
`ot_form_status_name_tw` string COMMENT '状态名称(繁体)',
`apv_status_code` string COMMENT '审批状态编码(draft/pending/agreed/reject/exempt)',
`apv_status_name_zh` string COMMENT '审批状态名称(简体)',
`apv_status_name_en` string COMMENT '审批状态名称(英文)',
`apv_status_name_tw` string COMMENT '审批状态名称(繁体)',
`apply_user_login_no` string COMMENT '申请人账号',
`apply_user_name_zh` string COMMENT '申请人姓名(简体)',
`apply_user_name_en` string COMMENT '申请人姓名(英文)',
`apply_user_name_tw` string COMMENT '申请人姓名(繁体)',
`org_id` bigint COMMENT '所属组织ID',
`org_name_zh` string COMMENT '所属组织名称(简体)',
`org_name_en` string COMMENT '所属组织名称(英文)',
`org_name_tw` string COMMENT '所属组织名称(繁体)',
`sob_code` string COMMENT '账套编号',
`cc_code` string COMMENT '成本中心编码',
`submit_time` timestamp COMMENT '提交时间',
`apply_date` date COMMENT '申请日期',
`wkday_type_code` string COMMENT '工作日类型编码',
`wkday_type_name_zh` string COMMENT '工作日类型名称(简体)',
`wkday_type_name_en` string COMMENT '工作日类型名称(英文)',
`wkday_type_name_tw` string COMMENT '工作日类型名称(繁体)',
`ot_mls_scene_code` string COMMENT '加班用餐类型编码(breakf/lunch/dinner/supper)',
`ot_mls_scene_name_zh` string COMMENT '加班用餐名称(简体)',
`ot_mls_scene_name_en` string COMMENT '加班用餐名称(英文)',
`ot_mls_scene_name_tw` string COMMENT '加班用餐名称(繁体)',
`submt_start_time` string COMMENT '点餐开始时间(hh24:min)',
`submt_end_time` string COMMENT '点餐截止时间(hh24:min)',
`std_amount` decimal(32,2) COMMENT '标准金额',
`curr_code` string COMMENT '货币代码',
`curr_sign` string COMMENT '货币符号',
`is_project_flag` string COMMENT '是否项目(Y/N)',
`project_code` string COMMENT '项目代码',
`project_name_zh` string COMMENT '项目名称(简体)',
`project_name_en` string COMMENT '项目名称(英文)',
`project_name_tw` string COMMENT '项目名称(繁体)',
`ot_apply_reason_zh` string COMMENT '加班原因(简体)',
`ot_apply_reason_en` string COMMENT '加班原因(英文)',
`ot_apply_reason_tw` string COMMENT '加班原因(繁体)',
`ot_apply_remark_zh` string COMMENT '备注说明(简体)',
`ot_apply_remark_en` string COMMENT '备注说明(英文)',
`ot_apply_remark_tw` string COMMENT '备注说明(繁体)',
`order_code` string COMMENT '订单号',
`outer_order_code` string COMMENT '外部订单号',
`is_valid` string COMMENT '是否有效（Y/N）',
`data_source` string COMMENT '数据来源(local/bdus等)',
`create_user` string COMMENT '创建者账号',
`create_time` timestamp COMMENT '创建时间',
`update_user` string COMMENT '更新者账号',
`update_time` timestamp COMMENT '更新时间',
`ot_form_confmn_status_code` string COMMENT '合规状态编码',
`ot_form_confmn_status_name_zh` string COMMENT '合规状态名称(简体)',
`ot_form_confmn_status_name_en` string COMMENT '合规状态名称(英文)',
`ot_form_confmn_status_name_tw` string COMMENT '合规状态名称(繁体)',
`conformance_text` string COMMENT '合规条件',
`ot_form_pay_status` string COMMENT '支付方式编码',
`ot_form_pay_name_zh` string COMMENT '支付方式名称(简体)',
`ot_form_pay_name_en` string COMMENT '支付方式名称(英文)',
`ot_form_pay_name_tw` string COMMENT '支付方式名称(繁体)',
`apply_month` string COMMENT '申请月份(YYYYMM)',
`consume_amount` decimal(32,2) COMMENT '消费/申请金额')
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE EXTERNAL TABLE `dm_gis_uimp.ods_feng_tu_order_detail`(
`pid` bigint COMMENT '行号',
`pay_time` string COMMENT '支付时间',
`job_number` string COMMENT '工号',
`emp_user_name` string COMMENT '姓名',
`product_name` string COMMENT '产品名称',
`product_spec_desc` string COMMENT '商品规格',
`sale_unit_price` decimal(18,2) COMMENT '销售单价',
`quantity` int COMMENT '销量',
`real_freight_total_amount` decimal(18,2) COMMENT '商品实收+运费',
`order_id` bigint COMMENT '订单号',
`order_status_name` string COMMENT '订单状态',
`pay_state` string COMMENT '支付状态',
`pay_type_desc` string COMMENT '支付类型',
`order_type` string COMMENT '订单类型',
`output_tax_rate` int COMMENT '销项税率(单位%)',
`order_item_id` bigint COMMENT '订单明细ID',
`item_refund_amount` decimal(12,2) COMMENT '明细退款金额',
`order_refund_amount` decimal(12,2) COMMENT '订单退款金额')
COMMENT '丰图同步信息表'
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;




-- 跑数

set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set mapreduce.input.fileinputformat.split.maxsize=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.rack=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.node=268435456;
set mapred.max.split.size=268435456;
set mapred.min.split.size.per.node=268435456;
set mapred.min.split.size.per.rack=268435456;
--设置jvm重用
set mapred.job.reuse.jvm.num.tasks=10;

insert overwrite table dm_gis_uimp.ods_plf_form_business_data_cfg partition(inc_day)
select id, data_type, data_value, data_code, create_user, create_time , update_user , update_time, is_enabled, lessee_no,inc_day
from  ods_ssp2.plf_form_business_data_cfg where lessee_no='FTFIN' and inc_day=
;

insert overwrite table dm_gis_uimp.ods_plf_form_body partition(inc_day)
select 
body_id,lessee_no,organization_code,fractionize_organization_code,order_no,order_type_code,business_type_code,order_name,company_code,company_name,currency_type,currency_rate,create_id,apply_id,cost_center,cost_center_name,is_prepay,is_verifi,is_sterilisation,
bankl,pay_type,supplier_account,supplier_name,account_name,bank_account,account_code,matter_desc,payment_desc,is_total_pay,order_status,voucher_status,screenage_status,screenage_no,screenage_no_his,payment_no,voucher_no,verifi_no,verifi_order_no,purchase_no,
error_msg,reject_type,again_submit_type,fsop_reject_method,totol_foreign_money,total_cur_pay_money,is_apprecia_job_byuse,benchmark_time,posting_time,business_depart_person,financial_approver,financial_approver_name,suggest_info,term_of_payment,contract_no,
version_num,bvtyp,payment_time,expect_payment_time,is_cat_image,is_notice_fsop,is_notice_eios,image_num,image_upload_time,image_scaner_user,reasons_for_payment,approval_enter,data_type,image_source,measure_core,payment_status,bank_call_msg,front_origin,
detail_sum,template_code,flow_code,template_node_id,reject_node_id,ecp_run_id,ele_inv_flag,create_time,update_user,update_time,attr1,attr2,attr3,attr4,attr5,create_name,apply_name,business_depart_person_name,company_merge_flag,swift_code,payment_frozen_status,
country,standard_money,standard_money_amount,push_fpe_flag,account_detail_currency_type,practice_payment_currency_type,practice_payment_amount,is_exist_ele_invoice,is_exist_paper_material,audit_user_first,audit_user_second,audit_finish_time,other_business_type,
other_area,other_bu,biz_type,pay_way,total_contract_amount,total_payments_num,current_payments_num,is_project_special,attr6,attr7,attr8,attr9,attr10,attr11,attr12
,inc_day
from ods_ssp2.plf_form_body where lessee_no='FTFIN' and inc_day=
;

insert overwrite table dm_gis_uimp.ods_plf_form_account_detail partition(inc_day)
select 
detail_id,lessee_no,order_no,order_type_code,business_type_code,business_item_code,cost_center,cost_center_name,kostl_no,kostl_reverse_name,customer_code,customer_name,
project_code,project_code_name,big_customer_code,big_customer_name,foreign_money,pay_type,budget_examine,security_deposit_money,security_deposit_money_handler,bill_type,
post_attr,employment_mode,license_plate_no,supplier_account,supplier_name,bvtyp_type,banks_code,dtaws_code,umskz_flag,zlspr_flag,prctr,xref3,ihrez_no,account_name,
bank_account,account_code,is_monthly_statement,is_support_value,asset_card_no,io_order_no,asset_net_worth,tax_rate,tax_code,is_enjoy_tax_reliefs,invoice_type,claim_type,
quarter_rate,capitalization_money,sgtxt,account_voucher_no,first_purchase_date,cbe_code,expense_incurred_during,quality_retention_money,account_item_no,purchase_order_no,
purchase_item_no,retirement_date,cancel_lation_date,is_amortization,trade_partner,is_remove_tax,invoice_no,claimant_no,exception_traffic_no,bus_contract_no,io_code,
order_number,material_group,line_num,business_date,cost_type,line_count,line_unit,voucher_no,payment_no,posting_time,payment_time,create_time,update_user,update_time,
attr1,attr2,attr3,attr4,attr5,attr6,attr7,attr8,attr9,attr10,saknr,cost_more_company_flag,amortization,invoice_currency,invoice_tax_amount,invoice_date,
withholding_tax_rate,withholding_tax_amount,invoice_currency_rate,payment_currency_amount,beic_req_id,product_code,base_date,due_date,flight_no,route_code,start_address,
end_address,fpe_business_item_code,transit_dr,transit_cr
,inc_day
from ods_ssp2.plf_form_account_detail where lessee_no='FTFIN' and inc_day=
;


insert overwrite table dm_gis_uimp.ods_plf_form_apprecial_tax_detail partition(inc_day)
select 
apprecia_id,lessee_no,order_no,order_type_code,business_type_code,invoice_date,invoice_no,invoice_code,tax_rate,mwskz,tax_money,totol_money,zc_reason,result_time,
create_user,create_time,update_user,update_time,attr1,attr2,attr3,attr4,attr5,invoice_source,invoice_status,tax_out_amount,check_result
,inc_day 
from ods_ssp2.plf_form_apprecial_tax_detail where lessee_no='FTFIN' and inc_day=
;



--丰味
insert overwrite table dm_gis_uimp.ods_ft_meal_order_detail partition(inc_day)
select 
sys_code,sys_name_zh,sys_name_en,sys_name_tw,order_code,outer_order_code,order_name_zh,order_name_en,order_name_tw,order_type_code,
order_type_name_zh,order_type_name_en,order_type_name_tw,ot_apply_no,order_source_code,order_source_name_zh,order_source_name_en,
order_source_name_tw,order_status_code,order_status_name_zh,order_status_name_en,order_status_name_tw,login_user_name,emp_name_zh,
emp_name_en,emp_name_tw,sob_code,cc_code,suppl_code,suppl_name_zh,suppl_name_en,suppl_name_tw,order_time,order_count,order_receiver,
receiv_addr,receiv_addr_mask,receiv_addr_encrypt,expct_receiv_time,curr_code,curr_sign,order_amount,enterprisepay_amount,mealcardpay_amount,
alipay_amount,wechatpay_amount,unionpay_amount,otherpay_amount,cancel_reason_code,cancel_reason_name_zh,cancel_reason_name_en,cancel_reason_name_tw,
cancel_reason_msg_zh,cancel_reason_msg_en,cancel_reason_msg_tw,order_eval_level,order_remark_zh,order_remark_en,order_remark_tw,pc_order_url,app_order_url,
encrypt_mode,is_valid,data_source,create_user,create_time,update_user,update_time
,inc_day 
from dm_meal.ft_meal_order_detail where inc_day=
;

insert overwrite table  dm_gis_uimp.ods_ft_meal_order_pay_detail partition(inc_day) 
select 
order_id,order_code,outer_order_code,pay_id,pay_time,pay_mode_code,pay_mode_name_zh,pay_mode_name_en,pay_mode_name_tw,curr_code,curr_sign,pay_amount,pay_account_no,
suppl_code,pay_account_name_zh,pay_account_name_en,pay_account_name_tw,suppl_name_zh,suppl_name_en,suppl_name_tw,pay_name_zh,pay_name_tw,pay_name_en,refund_reason_code,
refund_reason_name_zh,refund_reason_name_en,refund_reason_name_tw,refund_reason_msg_zh,refund_reason_msg_en,refund_reason_msg_tw,is_valid,data_source,create_user,
create_time,update_user,update_time,sob_code,cc_code,order_status_code,order_status_name_zh,order_status_name_en,order_status_name_tw,check_status_code,check_status_name_zh,
check_status_name_en,check_status_name_tw
,inc_day 
from dm_meal.ft_meal_order_pay_detail where inc_day=
;



insert overwrite table  dm_gis_uimp.ods_ft_meal_ot_apply_form_dtl partition(inc_day) 
select 
ot_form_code,ot_form_name_zh,ot_form_name_en,ot_form_name_tw,ot_apply_code,ot_apply_name_zh,ot_apply_name_en,ot_apply_name_tw,login_channel_code,login_channel_name_zh,
login_channel_name_en,login_channel_name_tw,ot_form_status_code,ot_form_status_name_zh,ot_form_status_name_en,ot_form_status_name_tw,apv_status_code,apv_status_name_zh,
apv_status_name_en,apv_status_name_tw,apply_user_login_no,apply_user_name_zh,apply_user_name_en,apply_user_name_tw,org_id,org_name_zh,org_name_en,org_name_tw,sob_code,cc_code,
submit_time,apply_date,wkday_type_code,wkday_type_name_zh,wkday_type_name_en,wkday_type_name_tw,ot_mls_scene_code,ot_mls_scene_name_zh,ot_mls_scene_name_en,ot_mls_scene_name_tw,
submt_start_time,submt_end_time,std_amount,curr_code,curr_sign,is_project_flag,project_code,project_name_zh,project_name_en,project_name_tw,ot_apply_reason_zh,ot_apply_reason_en,
ot_apply_reason_tw,ot_apply_remark_zh,ot_apply_remark_en,ot_apply_remark_tw,order_code,outer_order_code,is_valid,data_source,create_user,create_time,update_user,update_time,
ot_form_confmn_status_code,ot_form_confmn_status_name_zh,ot_form_confmn_status_name_en,ot_form_confmn_status_name_tw,conformance_text,ot_form_pay_status,ot_form_pay_name_zh,
ot_form_pay_name_en,ot_form_pay_name_tw,apply_month,consume_amount
,inc_day 
from dm_meal.ft_meal_ot_apply_form_dtl where inc_day=
;


--丰享
insert overwrite table  dm_gis_uimp.ods_feng_tu_order_detail  partition(inc_day)  
select 
pid,pay_time,job_number,emp_user_name,product_name,product_spec_desc,sale_unit_price,quantity,real_freight_total_amount,order_id,order_status_name,pay_state,pay_type_desc,
order_type,output_tax_rate,order_item_id,item_refund_amount,order_refund_amount
,inc_day 
from ods_fx_dwd.dwd_feng_tu_order_detail where inc_day=
;



------------------------------------------------
------------------------------------------------
-- url: jdbc:mysql://gisissp-m.db.sfcloud.local:3306/gisissp?serverTimezone=Asia/Shanghai&characterEncoding=utf8&useSSL=false
-- username: gisissp
-- password: Gis@ISSP@GIS
-- 表名：issp_emp_data、issp_emp_data_ext


------------------------------------------------
--1、采购台账报表需求：https://doc.sf-express.com/view/l/t1luugs
--2、历史合同详情获取方案：https://doc.sf-express.com/view/l/tot955q
--


------------------------------------------------
------------------------------------------------
-- 
-- 需求方：林中莉(01423677)
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2022-09-16
-- 任务信息： 实时任务ID:  20002985   ISSP_TO_HIVE  
--           离线任务ID：  573870   ctc合同报表_kafka写到不同表
-- 

-- kafka生产数据
-- MOM访问地址
-- http://tkafka-a1ytGmq8.kafka.sfcloud.local:1080/mom-mon/monitor/requestService.pub
-- 集群名: gis_issp_core_88tjwx8j
-- 版本: 2.5.1
-- topic: ISSP_DM_BDP
-- 生产者校验码： bJs0kyio
-- 消费组： DM_BDP
-- 消费组检验码：xjdVlife
--

-- 增量CTC合同数据接收
create table if not exists  dm_gis_uimp.ods_issp_kafka_tmp(
msg string comment 'kafka数据' 
)
comment 'issp_kafka' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
stored as textfile 
;

--
select get_json_object(msg,'$.tag'),get_json_object(msg,'$.data') from dm_gis_uimp.ods_issp_kafka_tmp limit 100


-- 历史CTC合同数据
create table if not exists  dm_gis_uimp.ods_ctc_history_tmp(
ht_code string,
msg string  
)
comment 'ctc合同历史' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES
("separatorChar"=",")
STORED AS TEXTFILE
tblproperties("skip.header.line.count"="1");

LOAD DATA  INPATH '/user/01416344/upload/ctc_history_detail.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_ctc_history_tmp;



--------------------2022.11.11------------------------
-- kafka数据分别写入不同表
-- CTC
create table if not exists  dm_gis_uimp.ods_issp_ctc(
content string comment '接口返回的json数据'    
)
comment 'CTC' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- CMR-CON
drop table if exists  dm_gis_uimp.ods_issp_cmr_con;
create table if not exists  dm_gis_uimp.ods_issp_cmr_con(
content string comment '接口返回的json数据'    
)
comment 'CMR-CON' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- CMR-OPP
drop table if exists dm_gis_uimp.ods_issp_cmr_opp;
create table if not exists  dm_gis_uimp.ods_issp_cmr_opp(
content string comment '接口返回的json数据'    
)
comment 'CMR-OPP' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- CRM-CON-SA (2023.08.31 开始kafka跑数)
drop table if exists dm_gis_uimp.ods_issp_cmr_con_sa;
create table if not exists  dm_gis_uimp.ods_issp_cmr_con_sa(
content string comment '接口返回的json数据'    
)
comment 'CRM-CON-SA' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- YKB-APPLY
create table if not exists  dm_gis_uimp.ods_issp_ykb_apply(
content string comment '接口返回的json数据'    
)
comment 'YKB-APPLY' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');



-- YKB-EMP
create table if not exists  dm_gis_uimp.ods_issp_ykb_emp(
content string comment '接口返回的json数据'    
)
comment 'YKB-EMP' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');



-- 
set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;

insert overwrite table dm_gis_uimp.ods_issp_ctc partition(inc_day='$firstDay')
select 
get_json_object(msg,'$.data') as content 
from dm_gis_uimp.ods_issp_kafka_tmp 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='CTC' 
;

insert overwrite table dm_gis_uimp.ods_issp_cmr_con partition(inc_day='$firstDay')
select 
get_json_object(msg,'$.data') as content  
from dm_gis_uimp.ods_issp_kafka_tmp 
where inc_day='$firstDay' and  get_json_object(msg,'$.tag')='CMR-CON' 
;

insert overwrite table dm_gis_uimp.ods_issp_cmr_opp partition(inc_day='$firstDay')
select 
get_json_object(msg,'$.data') as content  
from dm_gis_uimp.ods_issp_kafka_tmp 
where inc_day='$firstDay' and  get_json_object(msg,'$.tag')='CMR-OPP' 
;

insert overwrite table dm_gis_uimp.ods_issp_cmr_con_sa partition(inc_day='$firstDay')
select 
get_json_object(msg,'$.data') as content 
from dm_gis_uimp.ods_issp_kafka_tmp 
where inc_day='$firstDay' and get_json_object(msg,'$.tag')='CRM-CON-SA' 
;

insert overwrite table dm_gis_uimp.ods_issp_ykb_apply partition(inc_day='$firstDay')
select 
get_json_object(msg,'$.data') as content  
from dm_gis_uimp.ods_issp_kafka_tmp 
where  inc_day='$firstDay' and get_json_object(msg,'$.tag')='YKB-APPLY' 
;

insert overwrite table dm_gis_uimp.ods_issp_ykb_emp partition(inc_day='$firstDay')
select 
get_json_object(msg,'$.data') as content  
from dm_gis_uimp.ods_issp_kafka_tmp 
where  inc_day='$firstDay' and get_json_object(msg,'$.tag')='YKB-EMP' 
;


-----------------------------------
-- 
-- 需求方：林中莉(01423677)
-- 需求： ctc合同报表 
-- @author 张小琼 （01416344）
-- Created on 2022-09-16
-- 任务信息：  离线任务ID： 575522  ctc合同报表_跑报表中间数据
--            离线任务ID： 575484  ctc合同报表_跑报表结果表
-- 

-- 一般采购合同台账
-- 建表
create table dm_gis_uimp.dws_contract_base(
qyzt string comment '签约主体',
contract_no string comment '合同编号',
contract_stat string comment '合同状态',
gys_name string comment '供应商名称',
gys_code string comment '供应商编码',
business_lines string comment '业务线',
htss_bu string comment 'BU',
htss_dq string comment '大区',
enable_date string comment '合同开始日期',
disable_date string comment '合同结束日期',
htlx string comment '是否框架合同',
htgsxmdm string comment '销售项目',
contract_content string comment '合同内容',
is_withholding string comment '是否需要预提',
creater_name string comment '经办人',
create_organization string comment '采购组织',
amount string comment '合同金额',
tax_point string comment '税率',
payment_condition string comment '付款条件',
paid_money string comment '已付款金额_合同',
paid_yly_total string comment '已付款已履约_汇总',
paid_yly_sys string comment '已付款已履约_系统',
paid_yly_hand string comment '已付款已履约_手工',
paid_wly_total string comment '已付款已履约_汇总',
ad_payment_total string comment '预付账款_汇总',
ad_payment_sys string comment '预付账款_系统',
ad_payment_hand string comment '预付账款_手工',
earnest_total string comment '其他应收押金/保证金_汇总',
earnest_sys string comment '其他应收押金/保证金_系统',
earnest_hand string comment '其他应收押金/保证金_手工',
ad_payment_off string comment '预付账款_已核销',
earnest_off string comment '其他应收押金/保证金_已核销',
ad_payment_on string comment '预付账款_未核销',
earnest_on string comment '其他应收押金/保证金_未核销',
no_payment string comment '未付款合同金额',
no_payment_yly_total string comment '未付款已履约_汇总',
payable_fi string comment '应付账款_FI',
payable_estimate string comment '应付暂估',
payable_other string comment '其他应付款_质保金',
payable_balance string comment '应付余额',
invoiced_amount string comment '已开票合同金额',
no_invoiced_amount string comment '未开票合同金额'
) 
comment '一般采购合同台账' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
STORED AS TEXTFILE;


-- 1、场景1
-- 数据导入1: 初始化"一般采购合同台账"
-- 字段：签约主体 合同编号 合同状态 供应商名称 供应商编码 BU 大区 合同开始日期 合同结束日期 是否框架合同 销售项目 合同内容 经办人 采购组织 合同金额 税率 付款条件 已开票合同金额
drop table if exists dm_gis_uimp.ods_contract_base_input;
create table dm_gis_uimp.ods_contract_base_input(
qyzt string comment '签约主体',
contract_no string comment '合同编号',
contract_stat string comment '合同状态',
gys_name string comment '供应商名称',
gys_code string comment '供应商编码',
htss_bu string comment 'BU',
htss_dq string comment '大区',
enable_date string comment '合同开始日期',
disable_date string comment '合同结束日期',
htlx string comment '是否框架合同',
htgsxmdm string comment '销售项目',
contract_content string comment '合同内容',
creater_name string comment '经办人',
create_organization string comment '采购组织',
amount string comment '合同金额',
tax_point string comment '税率',
payment_condition string comment '付款条件',
invoiced_amount string comment '已开票合同金额',
jzrq string comment ''
) 
comment '初始化一般采购合同台账' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
;

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/data_input_1_1115.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_base_input partition (inc_day='20221115');
LOAD DATA  INPATH '/user/01416344/upload/data_input_1_1123.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_base_input partition (inc_day='20221123');

-- 数据导入2: 手工整理的财务数据
-- 字段：合同编号 是否需要预提 已付款已履约_手工 预付账款_手工 其他应收押金/保证金_手工 预付账款_已核销 其他应收押金/保证金_已核销 应付账款_FI 应付暂估 其他应付款_质保金
drop table if exists dm_gis_uimp.ods_contract_handwork_input;
create table dm_gis_uimp.ods_contract_handwork_input(
contract_no string comment '合同编号',
is_withholding string comment '是否需要预提',
paid string comment '已付款已履约_手工',
ad_payment string comment '预付账款_手工',
earnest string comment '其他应收押金/保证金_手工',
ad_payment_off string comment '预付账款_已核销',
earnest_off string comment '其他应收押金/保证金_已核销',
payable_fi string comment '应付账款_FI',
payable_estimate string comment '应付暂估',
payable_other string comment '其他应付款_质保金',
jzrq string comment ''
) 
comment '手工整理的财务数据' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
;

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/data_input_2_1115.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_handwork_input partition (inc_day='20221115');
LOAD DATA  INPATH '/user/01416344/upload/data_input_2_1123.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_handwork_input partition (inc_day='20221123');


-- 数据导入4：BU-业务线映射关系
-- 字段：BU 业务线
create table dm_gis_uimp.dim_bu_business_lines(
bu string comment 'BU',
business_lines string comment '业务线'
) 
comment 'BU-业务线映射关系' 
STORED AS TEXTFILE;


insert overwrite table  dm_gis_uimp.dim_bu_business_lines values 
 ('保险BU', '交通货运业务线')
,('运营商BU', '交通货运业务线')
,('创新BU', '交通货运业务线')
,('交通BU', '交通货运业务线')
,('交警BU', '交通货运业务线')
,('数字政府BU', '数字孪生业务线')
,('图安BU', '数字孪生业务线')
,('产业经济BU', '数字孪生业务线')
,('未来产城BU', '数字孪生业务线')
,('智慧社区BU', '智慧社区业务线');


-- 数据导入5：状态名称-状态ID映射关系
-- 字段：合同状态名称 合同状态id
create table dm_gis_uimp.dim_contract_stat_id(
contract_stat string comment '合同状态名称',
contract_stat_id string comment '合同状态id'
) 
comment '状态名称-状态ID映射关系' 
STORED AS TEXTFILE;

insert into  dm_gis_uimp.dim_contract_stat_id values ('草稿','101')
,('创建异常','199')
,('待审核','201')
,('审核中','202')
,('审批通过','203')
,('审批驳回','204')
,('审批撤回','205')
,('审批流程启动失败','206')
,('审批流程已发起','207')
,('审批异常','209')
,('待签章','301')
,('已发起签章','302')
,('签章拒签','305')
,('签章过期','307')
,('签章异常','309')
,('待生效','401')
,('已生效','403')
,('已终止','404')
,('已到期','405')
,('已失效','406')
,('生效已变更','407')
,('发起推送异常','501')
,('已删除','-1');


-- 2、场景2和场景3
-- 2.1、dm_gis_uimp.ods_issp_ctc  
create table dm_gis_uimp.dwd_issp_ctc(
contract_code string comment '合同编号', 
contract_status  string comment '合同状态', 
enable_date string comment '合同开始日期', 
disable_date string comment '合同结束日期', 
contract_name string comment '合同内容', 
creater_code string comment '经办人工号', 
creater_name string comment '经办人', 
create_organization string comment '采购组织', 
create_organization_name string comment '采购组织',
supplier_code string comment '签约主体', 
supplier_name string comment '供应商名称', 
supplier_code_gys string comment '供应商编码', 
tax_point string comment '税率', 
payment_condition string comment '付款条件',
contract_type string comment '合同类别', 
htss_bu string comment 'BU', 
htss_dq string comment '大区', 
htlx string comment '是否框架合同', 
htgsxmdm string comment '销售项目', 
amount string comment '合同金额'
)
COMMENT "CTC合同" 
PARTITIONED BY (inc_day STRING COMMENT "日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
int_sql=" select content from dm_gis_uimp.ods_issp_ctc where inc_day='' "
out_table1="dm_gis_uimp.dwd_issp_ctc"
main="com.sf.gis.scala.tals.app.UimpCtcApp"


-- -- 20221114测试
-- drop table if exists dm_gis_uimp.dwd_issp_ctc_tmp;
-- create table dm_gis_uimp.dwd_issp_ctc_tmp(
-- contract_code string comment '合同编号', 
-- contract_status  string comment '合同状态', 
-- enable_date string comment '合同开始日期', 
-- disable_date string comment '合同结束日期', 
-- contract_name string comment '合同内容', 
-- creater_code string comment '经办人工号', 
-- creater_name string comment '经办人', 
-- create_organization string comment '采购组织', 
-- create_organization_name string comment '采购组织',
-- supplier_code string comment '签约主体', 
-- supplier_name string comment '供应商名称', 
-- supplier_code_gys string comment '供应商编码', 
-- tax_point string comment '税率', 
-- payment_condition string comment '付款条件',
-- contract_type string comment '合同类别', 
-- htss_bu string comment 'BU', 
-- htss_dq string comment '大区', 
-- htlx string comment '是否框架合同', 
-- htgsxmdm string comment '销售项目', 
-- amount string comment '合同金额'
-- )
-- row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
-- STORED AS TEXTFILE
-- tblproperties('skip.header.line.count'='1');

-- -- load_data
-- LOAD DATA  INPATH '/user/01416344/upload/ctc_history.csv' OVERWRITE INTO TABLE dm_gis_uimp.dwd_issp_ctc_tmp;



-- 2.2、dm_gis_uimp.ods_plf_form_body
-- contract_no,update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,order_no,totol_foreign_money 


select contract_no,update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,order_no,totol_foreign_money 
from dm_gis_uimp.ods_plf_form_body

-- 2.3、dm_gis_uimp.ods_plf_form_apprecial_tax_detail
-- order_no,totol_money
select order_no,totol_money from dm_gis_uimp.ods_plf_form_apprecial_tax_detail

-- 2.4、数据导入2  数据导入4  数据导入5


-----------------------------------
-- 跑数
-- 合同基础字段部分 (手工导入的和系统的取最新)
drop table if exists dm_gis_uimp.dwd_issp_ctc_union_tmp;
create table dm_gis_uimp.dwd_issp_ctc_union_tmp as 
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
amount,tax_point,payment_condition,jzrq,inc_day 
from 
(
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
amount,tax_point,payment_condition,jzrq,inc_day,
row_number() over(partition by contract_no order by inc_day desc) as rn 
from 
(
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
amount,tax_point,payment_condition,jzrq,inc_day
from dm_gis_uimp.ods_contract_base_input where contract_no<>'' and inc_day>='20221101' 
union all 
select 
supplier_code as qyzt,
contract_code as contract_no, 
contract_status  as contract_stat, 
supplier_name as gys_name, 
supplier_code_gys as gys_code, 
htss_bu, 
htss_dq, 
enable_date, 
disable_date, 
htlx, 
htgsxmdm, 
contract_name as contract_content, 
concat(creater_code,'/',creater_name) as creater_name, 
concat(create_organization,'/',create_organization_name) as create_organization,
amount,
tax_point, 
payment_condition,
concat(substr(inc_day,1,4),'-',substr(inc_day,5,2),'-',substr(inc_day,7,2)) as jzrq,
inc_day
from dm_gis_uimp.dwd_issp_ctc where contract_code<>'' and inc_day>='20221101'
) as t 
) as t1 where t1.rn=1
;


-- 合同算账部分
-- 手工
drop table if exists dm_gis_uimp.ods_contract_handwork_tmp;
create table dm_gis_uimp.ods_contract_handwork_tmp as 
select 
contract_no,is_withholding,paid,ad_payment,earnest,ad_payment_off,earnest_off,payable_fi,payable_estimate,payable_other,inc_day 
from 
(
select contract_no,is_withholding,paid,ad_payment,earnest,ad_payment_off,earnest_off,payable_fi,payable_estimate,payable_other,inc_day,
row_number() over(partition by contract_no order by inc_day desc)  as rn 
from dm_gis_uimp.ods_contract_handwork_input where contract_no<>'' and inc_day>='20221101'
) as t 
where t.rn=1
;
-- 系统
drop table if exists dm_gis_uimp.ods_contract_sys_tmp ;
create table dm_gis_uimp.ods_contract_sys_tmp as 
select 
contract_no,
sum(case when order_status in ('90') and order_type_code in ('OT1','OT3') then total_cur_pay_money else 0 end ) as paid_yly_sys,
sum(case when order_status in ('90') and order_type_code in ('OT5') and business_type_code not in ('BT32') then total_cur_pay_money else 0 end ) as ad_payment_sys,
sum(case when order_status in ('90') and order_type_code in ('OT5') and business_type_code in ('BT32') then total_cur_pay_money else 0 end ) as earnest_sys,
sum(case when order_type_code in ('OT3')  then totol_foreign_money else 0 end ) as invoiced_amount1,
sum(case when order_type_code in ('OT1')  then totol_money else 0 end ) as invoiced_amount2
from 
(
select t0.contract_no,t0.jzrq, 
update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,totol_foreign_money,
t2.totol_money 
from dm_gis_uimp.dwd_issp_ctc_union_tmp as t0 
left join (
select contract_no,update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,order_no,totol_foreign_money,inc_day  
from dm_gis_uimp.ods_plf_form_body 
where length(contract_no)>6 and order_status in ('79','80','81','82','90') and inc_day>='20221101' 
) as t1 
on t0.contract_no=t1.contract_no and t0.jzrq<=t1.update_time 
left join (select order_no,sum(totol_money) as totol_money from dm_gis_uimp.ods_plf_form_apprecial_tax_detail where order_no<>'' and inc_day>='20221101' group by order_no) as t2 
on t1.order_no=t2.order_no
where t1.contract_no is not null 
) as t 
group by contract_no
;



-- 场景2和场景3数据
-- (t2.paid_yly_sys+t1.paid)+(t2.ad_payment_sys+t1.ad_payment-t1.ad_payment_off)+(t2.earnest_sys+t1.ad_payment_off-t1.earnest_off) as paid_money,
-- t2.paid_yly_sys+t1.paid as paid_yly_total,
-- t2.paid_yly_sys,
-- t1.paid as paid_yly_hand,
-- (t2.ad_payment_sys+t1.ad_payment-t1.ad_payment_off)+(t2.earnest_sys+t1.ad_payment_off-t1.earnest_off) as paid_wly_total,
-- (t2.ad_payment_sys+t1.ad_payment) as ad_payment_total,
-- t2.ad_payment_sys,
-- t1.ad_payment as ad_payment_hand,
-- (t2.earnest_sys+t1.ad_payment_off) as earnest_total,
-- t2.earnest_sys,
-- t1.earnest as earnest_hand,
-- t1.ad_payment_off as ad_payment_off,
-- t1.earnest_off as earnest_off,
-- (t2.ad_payment_sys+t1.ad_payment-t1.ad_payment_off) as ad_payment_on,
-- (t2.earnest_sys+t1.ad_payment_off-t1.earnest_off) as earnest_on,
-- t0.amount-((t2.paid_yly_sys+t1.paid)+(t2.ad_payment_sys+t1.ad_payment-t1.ad_payment_off)+(t2.earnest_sys+t1.ad_payment_off-t1.earnest_off)) as no_payment,
-- (t1.payable_fi+t1.payable_estimate+t1.payable_other) as no_payment_yly_total,
-- t1.payable_fi as payable_fi,
-- t1.payable_estimate as payable_estimate,
-- t1.payable_other as payable_other,
-- (t1.payable_fi+t1.payable_estimate+t1.payable_other)-((t2.ad_payment_sys+t1.ad_payment-t1.ad_payment_off)+(t2.earnest_sys+t1.ad_payment_off-t1.earnest_off)) as payable_balance,
-- invoiced_amount1+invoiced_amount2 as invoiced_amount,
-- t0.amount-(invoiced_amount1+invoiced_amount2) as no_invoiced_amount

insert overwrite table dm_gis_uimp.dws_contract_base partition(inc_day='20221115')
select 
qyzt,
contract_no,
contract_stat,
gys_name,
gys_code,
business_lines,
htss_bu,
htss_dq,
enable_date,
disable_date,
htlx,
htgsxmdm,
contract_content,
is_withholding,
creater_name,
create_organization,
amount,
tax_point,
payment_condition,
(paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off) as paid_money,
paid_yly_sys+paid as paid_yly_total,
paid_yly_sys,
paid as paid_yly_hand,
(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off) as paid_wly_total,
(ad_payment_sys+ad_payment) as ad_payment_total,
ad_payment_sys,
ad_payment as ad_payment_hand,
(earnest_sys+ad_payment_off) as earnest_total,
earnest_sys,
earnest as earnest_hand,
ad_payment_off as ad_payment_off,
earnest_off as earnest_off,
(ad_payment_sys+ad_payment-ad_payment_off) as ad_payment_on,
(earnest_sys+ad_payment_off-earnest_off) as earnest_on,
amount-((paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off)) as no_payment,
(payable_fi+payable_estimate+payable_other) as no_payment_yly_total,
payable_fi as payable_fi,
payable_estimate as payable_estimate,
payable_other as payable_other,
(payable_fi+payable_estimate+payable_other)-((ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off)) as payable_balance,
invoiced_amount1+invoiced_amount2 as invoiced_amount,
amount-(invoiced_amount1+invoiced_amount2) as no_invoiced_amount
from 
(
select 
t0.qyzt,
t0.contract_no,
t4.contract_stat,
t0.gys_name,
t0.gys_code,
t3.business_lines,
t0.htss_bu,
t0.htss_dq,
t0.enable_date,
t0.disable_date,
t0.htlx,
t0.htgsxmdm,
t0.contract_content,
t1.is_withholding,
t0.creater_name,
t0.create_organization,
t0.amount,
t0.tax_point,
t0.payment_condition,
case when t1.paid is not null and t1.paid<>'' then t1.paid else 0.0 end as paid,
case when t1.ad_payment is not null and t1.ad_payment<>''  then t1.ad_payment else 0.0 end  as ad_payment,
case when t1.ad_payment_off is not null and t1.ad_payment_off<>'' then t1.ad_payment_off else 0.0 end  as ad_payment_off,
case when t1.earnest_off is not null and t1.earnest_off<>'' then t1.earnest_off else 0.0 end  as earnest_off,
case when t1.payable_fi is not null and t1.payable_fi<>'' then t1.payable_fi else 0.0 end  as payable_fi,
case when t1.payable_estimate is not null and t1.payable_estimate<>'' then t1.payable_estimate else 0.0 end  as payable_estimate,
case when t1.payable_other is not null and t1.payable_other<>'' then t1.payable_other else 0.0 end  as payable_other,
case when t1.earnest is not null and t1.earnest<>'' then t1.earnest else 0.0 end  as earnest, 
case when invoiced_amount1 is not null and invoiced_amount1<>'' then invoiced_amount1 else 0.0 end  as invoiced_amount1,
case when invoiced_amount2 is not null and invoiced_amount2<>'' then invoiced_amount2 else 0.0 end  as invoiced_amount2,
case when t2.paid_yly_sys is not null and t2.paid_yly_sys<>'' then t2.paid_yly_sys else 0.0 end  as paid_yly_sys,
case when t2.ad_payment_sys is not null and t2.ad_payment_sys<>'' then t2.ad_payment_sys else 0.0 end  as ad_payment_sys,
case when t2.earnest_sys is not null and t2.earnest_sys<>'' then t2.earnest_sys else 0.0 end  as earnest_sys 
from (
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
cast(regexp_replace(amount,'[\u4e00-\u9fa5]','') as double) as amount,
tax_point,payment_condition,jzrq,inc_day  
from dm_gis_uimp.dwd_issp_ctc_union_tmp 
) as t0 
left join dm_gis_uimp.ods_contract_handwork_tmp as t1 
on t0.contract_no=t1.contract_no 
left join dm_gis_uimp.ods_contract_sys_tmp as t2 
on t0.contract_no=t2.contract_no 
left join dm_gis_uimp.dim_bu_business_lines as t3 
on t0.htss_bu=t3.bu 
left join dm_gis_uimp.dim_contract_stat_id as t4 
on t0.contract_stat=t4.contract_stat_id 
) as t 
;



---------------------------------------
-- 无采购合同台账
create table dm_gis_uimp.dws_contract_no(
qyzt string comment '签约主体',
contract_no string comment '合同编号',
contract_stat string comment '合同状态',
gys_name string comment '供应商名称',
gys_code string comment '供应商编码',
business_lines string comment '业务线',
htss_bu string comment 'BU',
htss_dq string comment '大区',
enable_date string comment '合同开始日期',
disable_date string comment '合同结束日期',
htlx string comment '是否框架合同',
htgsxmdm string comment '销售项目',
contract_content string comment '合同内容',
is_withholding string comment '是否需要预提',
creater_name string comment '经办人',
create_organization string comment '采购组织',
amount string comment '合同金额',
tax_point string comment '税率',
payment_condition string comment '付款条件',
paid_money string comment '已付款金额_合同',
paid_yly_total string comment '已付款已履约_汇总',
paid_yly_sys string comment '已付款已履约_系统',
paid_yly_hand string comment '已付款已履约_手工',
paid_wly_total string comment '已付款已履约_汇总',
ad_payment_total string comment '预付账款_汇总',
ad_payment_sys string comment '预付账款_系统',
ad_payment_hand string comment '预付账款_手工',
earnest_total string comment '其他应收押金/保证金_汇总',
earnest_sys string comment '其他应收押金/保证金_系统',
earnest_hand string comment '其他应收押金/保证金_手工',
ad_payment_off string comment '预付账款_已核销',
earnest_off string comment '其他应收押金/保证金_已核销',
ad_payment_on string comment '预付账款_未核销',
earnest_on string comment '其他应收押金/保证金_未核销',
no_payment string comment '未付款合同金额',
no_payment_yly_total string comment '未付款已履约_汇总',
payable_fi string comment '应付账款_FI',
payable_estimate string comment '应付暂估',
payable_other string comment '其他应付款_质保金',
payable_balance string comment '应付余额',
invoiced_amount string comment '已开票合同金额',
no_invoiced_amount string comment '未开票合同金额'
) 
comment '无采购合同台账' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
STORED AS TEXTFILE;

-- 需要数据：数据导入3  数据导入2 数据导入4

-- 数据导入3: 无采购合同台账基础信息
-- 字段：签约主体 合同编号 合同状态 供应商名称 供应商编码 BU 大区 合同开始日期 合同结束日期 是否框架合同 销售项目 合同内容 经办人 采购组织 合同金额 税率 付款条件
drop table if exists dm_gis_uimp.ods_contract_wopo_input;
create table dm_gis_uimp.ods_contract_wopo_input(
qyzt string comment '签约主体',
contract_no string comment '合同编号',
contract_stat string comment '合同状态',
gys_name string comment '供应商名称',
gys_code string comment '供应商编码',
htss_bu string comment 'BU',
htss_dq string comment '大区',
enable_date string comment '合同开始日期',
disable_date string comment '合同结束日期',
htlx string comment '是否框架合同',
htgsxmdm string comment '销售项目',
contract_content string comment '合同内容',
creater_name string comment '经办人',
create_organization string comment '采购组织',
amount string comment '合同金额',
tax_point string comment '税率',
payment_condition string comment '付款条件',
jzrq string comment ''
) 
comment '无采购合同台账基础信息' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
;

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/data_input_3_1123.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_wopo_input partition (inc_day='20221123');


----
insert overwrite table dm_gis_uimp.dws_contract_no partition(inc_day='20221123')
select 
qyzt,
contract_no,
contract_stat,
gys_name,
gys_code,
business_lines,
htss_bu,
htss_dq,
enable_date,
disable_date,
htlx,
htgsxmdm,
contract_content,
is_withholding,
creater_name,
create_organization,
amount,
tax_point,
payment_condition,
(paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off) as paid_money,
paid_yly_sys+paid as paid_yly_total,
paid_yly_sys,
paid as paid_yly_hand,
(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off) as paid_wly_total,
(ad_payment_sys+ad_payment) as ad_payment_total,
ad_payment_sys,
ad_payment as ad_payment_hand,
(earnest_sys+ad_payment_off) as earnest_total,
earnest_sys,
earnest as earnest_hand,
ad_payment_off as ad_payment_off,
earnest_off as earnest_off,
(ad_payment_sys+ad_payment-ad_payment_off) as ad_payment_on,
(earnest_sys+ad_payment_off-earnest_off) as earnest_on,
amount-((paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off)) as no_payment,
(payable_fi+payable_estimate+payable_other) as no_payment_yly_total,
payable_fi as payable_fi,
payable_estimate as payable_estimate,
payable_other as payable_other,
(payable_fi+payable_estimate+payable_other)-((ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+ad_payment_off-earnest_off)) as payable_balance,
invoiced_amount1+invoiced_amount2 as invoiced_amount,
amount-(invoiced_amount1+invoiced_amount2) as no_invoiced_amount
from 
(
select 
t0.qyzt,
t0.contract_no,
t3.contract_stat,
t0.gys_name,
t0.gys_code,
t2.business_lines,
t0.htss_bu,
t0.htss_dq,
t0.enable_date,
t0.disable_date,
t0.htlx,
t0.htgsxmdm,
t0.contract_content,
t1.is_withholding,
t0.creater_name,
t0.create_organization,
case when t0.amount is not null and t0.amount<>'' then t0.amount else 0.0 end as amount,
t0.tax_point,
t0.payment_condition,
case when t1.paid is not null and t1.paid<>'' then t1.paid else 0.0 end as paid,
case when t1.ad_payment is not null and t1.ad_payment<>''  then t1.ad_payment else 0.0 end  as ad_payment,
case when t1.ad_payment_off is not null and t1.ad_payment_off<>'' then t1.ad_payment_off else 0.0 end  as ad_payment_off,
case when t1.earnest_off is not null and t1.earnest_off<>'' then t1.earnest_off else 0.0 end  as earnest_off,
case when t1.payable_fi is not null and t1.payable_fi<>'' then t1.payable_fi else 0.0 end  as payable_fi,
case when t1.payable_estimate is not null and t1.payable_estimate<>'' then t1.payable_estimate else 0.0 end  as payable_estimate,
case when t1.payable_other is not null and t1.payable_other<>'' then t1.payable_other else 0.0 end  as payable_other,
case when t1.earnest is not null and t1.earnest<>'' then t1.earnest else 0.0 end  as earnest, 
0.0 as invoiced_amount1,
0.0 as invoiced_amount2,
0.0 as paid_yly_sys,
0.0 as ad_payment_sys,
0.0 as earnest_sys 
from (
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,amount,tax_point,payment_condition,jzrq,inc_day 
from (
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,amount,tax_point,payment_condition,jzrq,inc_day,
row_number() over(partition by contract_no order by inc_day desc) rn   
from dm_gis_uimp.ods_contract_wopo_input where  inc_day>='20220101' ) as trn 
where trn.rn=1 
) as t0 
left join dm_gis_uimp.ods_contract_handwork_tmp as t1 
on t0.contract_no=t1.contract_no 
left join dm_gis_uimp.dim_bu_business_lines as t2 
on t0.htss_bu=t2.bu 
left join dm_gis_uimp.dim_contract_stat_id as t3 
on t0.contract_stat=t3.contract_stat_id 
) as t 
;

-- 李宇成修改
drop table if exists dm_gis_uimp.dwd_issp_ctc_union_tmp;
create table dm_gis_uimp.dwd_issp_ctc_union_tmp as 
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
amount,tax_point,payment_condition,jzrq,inc_day 
from 
(
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
amount,tax_point,payment_condition,jzrq,inc_day,
row_number() over(partition by contract_no order by inc_day desc) as rn 
from 
(
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
amount,tax_point,payment_condition,jzrq,inc_day
from dm_gis_uimp.ods_contract_base_input where contract_no<>'' and inc_day>='20221101' 
union all 
select 
supplier_code as qyzt,
contract_code as contract_no, 
contract_status  as contract_stat, 
supplier_name as gys_name, 
supplier_code_gys as gys_code, 
htss_bu, 
htss_dq, 
enable_date, 
disable_date, 
htlx, 
htgsxmdm, 
contract_name as contract_content, 
concat_ws('/',creater_code,creater_name) as creater_name, 
concat_ws('/',create_organization,create_organization_name) as create_organization,
amount,
tax_point, 
payment_condition,
concat(substr(inc_day,1,4),'-',substr(inc_day,5,2),'-',substr(inc_day,7,2)) as jzrq,
inc_day
from dm_gis_uimp.dwd_issp_ctc where contract_code<>'' and inc_day>='20221101' and (contract_type<>'销售类' or contract_type is null) and contract_status<>'101'
) as t 
) as t1 where t1.rn=1
;



drop table if exists dm_gis_uimp.ods_contract_handwork_tmp;
create table dm_gis_uimp.ods_contract_handwork_tmp as 
select 
contract_no,is_withholding,paid,ad_payment,earnest,ad_payment_off,earnest_off,payable_fi,payable_estimate,payable_other,inc_day 
from 
(
select contract_no,inc_day,
is_withholding,
sum(paid) over(partition by contract_no) as paid,
sum(ad_payment) over(partition by contract_no) as ad_payment,
sum(earnest) over(partition by contract_no) as earnest,
sum(ad_payment_off) over(partition by contract_no) as ad_payment_off,
sum(earnest_off) over(partition by contract_no) as earnest_off,
sum(payable_fi) over(partition by contract_no) as payable_fi,
sum(payable_estimate) over(partition by contract_no) as payable_estimate,
sum(payable_other) over(partition by contract_no) as payable_other,
row_number() over(partition by contract_no order by inc_day desc)  as rn 
from dm_gis_uimp.ods_contract_handwork_input where contract_no<>'' and inc_day>='20221101'
) as t 
where t.rn=1
;


drop table dm_gis_uimp.ods_contract_sys_tmp;
create table dm_gis_uimp.ods_contract_sys_tmp as 
select 
t.contract_no,
sum(case when order_status in ('90') and order_type_code in ('OT1','OT3') then total_cur_pay_money else 0 end ) as paid_yly_sys,
sum(case when order_status in ('90') and order_type_code in ('OT5') and business_type_code not in ('BT32') then total_cur_pay_money else 0 end ) as ad_payment_sys,
sum(case when order_status in ('90') and order_type_code in ('OT5') and business_type_code in ('BT32') then total_cur_pay_money else 0 end ) as earnest_sys,
sum(case when order_type_code in ('OT3')  then totol_foreign_money else 0 end ) as invoiced_amount1,
sum(case when order_type_code in ('OT1')  then totol_money else 0 end ) as invoiced_amount2,
sum(invoiced_amount) as invoiced_amount3
from 
(
	select t0.contract_no,t0.jzrq, 
	update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,totol_foreign_money,
	t2.totol_money 
	from dm_gis_uimp.dwd_issp_ctc_union_tmp as t0 
	left join (
		select contract_no,update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,order_no,totol_foreign_money,inc_day  
		from dm_gis_uimp.ods_plf_form_body 
		where length(contract_no)>6 and order_status in ('79','80','81','82','90') and inc_day='$firstDay'
	) as t1 
	on t0.contract_no=t1.contract_no and t0.jzrq<=t1.update_time 
	left join (
		select order_no,sum(totol_money) as totol_money 
		from dm_gis_uimp.ods_plf_form_apprecial_tax_detail 
		where order_no<>'' and inc_day>='20221101' 
		group by order_no
	) as t2 
	on t1.order_no=t2.order_no
	where t1.contract_no is not null 
) as t 
	left join (
		select invoiced_amount,contract_no from dm_gis_uimp.ods_contract_base_input group by invoiced_amount,contract_no
	) as t3
	on t.contract_no = t3.contract_no
group by t.contract_no
;

insert overwrite table dm_gis_uimp.dws_contract_base partition(inc_day='$firstDay')
select 
qyzt,
contract_no,
contract_stat,
gys_name,
gys_code,
business_lines,
htss_bu,
htss_dq,
enable_date,
disable_date,
htlx,
htgsxmdm,
contract_content,
is_withholding,
creater_name,
create_organization,
amount,
tax_point,
payment_condition,
(paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off) as paid_money,
paid_yly_sys+paid as paid_yly_total,
paid_yly_sys,
paid as paid_yly_hand,
(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off) as paid_wly_total,
(ad_payment_sys+ad_payment) as ad_payment_total,
ad_payment_sys,
ad_payment as ad_payment_hand,
(earnest_sys+earnest) as earnest_total,
earnest_sys,
earnest as earnest_hand,
ad_payment_off as ad_payment_off,
earnest_off as earnest_off,
(ad_payment_sys+ad_payment-ad_payment_off) as ad_payment_on,
(earnest_sys+earnest-earnest_off) as earnest_on,
amount-((paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off)) as no_payment,
(payable_fi+payable_estimate+payable_other) as no_payment_yly_total,
payable_fi as payable_fi,
payable_estimate as payable_estimate,
payable_other as payable_other,
(payable_fi+payable_estimate+payable_other)-((ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off)) as payable_balance,
invoiced_amount1+invoiced_amount2+invoiced_amount3 as invoiced_amount,
amount-(invoiced_amount1+invoiced_amount2+invoiced_amount3) as no_invoiced_amount
from 
(
select 
t0.qyzt,
t0.contract_no,
t4.contract_stat,
t0.gys_name,
t0.gys_code,
t3.business_lines,
t0.htss_bu,
t0.htss_dq,
t0.enable_date,
t0.disable_date,
t0.htlx,
t0.htgsxmdm,
t0.contract_content,
t1.is_withholding,
t0.creater_name,
t0.create_organization,
case when t0.amount is null or t0.amount='' then 0.0 else t0.amount end as amount,
t0.tax_point,
t0.payment_condition,
case when t1.paid is null or t1.paid='' then 0.0 else t1.paid end as paid,
case when t1.ad_payment is null or t1.ad_payment='' then 0.0 else t1.ad_payment end  as ad_payment,
case when t1.ad_payment_off is null   or t1.ad_payment_off=''  then 0.0 else t1.ad_payment_off end  as ad_payment_off,
case when t1.earnest_off is null  or t1.earnest_off=''   then 0.0 else t1.earnest_off end  as earnest_off,
case when t1.payable_fi is null  or t1.payable_fi=''   then 0.0 else t1.payable_fi end  as payable_fi,
case when t1.payable_estimate is null  or t1.payable_estimate=''  then 0.0 else t1.payable_estimate  end  as payable_estimate,
case when t1.payable_other is null  or t1.payable_other=''  then 0.0 else t1.payable_other end  as payable_other,
case when t1.earnest is null  or t1.earnest=''  then 0.0 else t1.earnest end  as earnest, 
case when invoiced_amount1 is null  or invoiced_amount1=''  then 0.0 else invoiced_amount1 end  as invoiced_amount1,
case when invoiced_amount2 is null  or invoiced_amount2=''  then 0.0 else invoiced_amount2 end  as invoiced_amount2,
case when invoiced_amount3 is null or invoiced_amount3=''  then 0.0 else invoiced_amount3 end  as invoiced_amount3,
case when t2.paid_yly_sys is null  or t2.paid_yly_sys=''  then 0.0 else t2.paid_yly_sys end  as paid_yly_sys,
case when t2.ad_payment_sys is null   or t2.ad_payment_sys='' then 0.0 else t2.ad_payment_sys end  as ad_payment_sys,
case when t2.earnest_sys is null  or t2.earnest_sys=''  then 0.0 else t2.earnest_sys end  as earnest_sys 
from (
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,
cast(regexp_replace(amount,'[\u4e00-\u9fa5]','') as double) as amount,
tax_point,payment_condition,jzrq,inc_day  
from dm_gis_uimp.dwd_issp_ctc_union_tmp 
) as t0 
left join dm_gis_uimp.ods_contract_handwork_tmp as t1 
on t0.contract_no=t1.contract_no 
left join dm_gis_uimp.ods_contract_sys_tmp as t2 
on t0.contract_no=t2.contract_no 
left join dm_gis_uimp.dim_bu_business_lines as t3 
on t0.htss_bu=t3.bu 
left join dm_gis_uimp.dim_contract_stat_id as t4 
on t0.contract_stat=t4.contract_stat_id 
) as t 
;


insert overwrite table dm_gis_uimp.dws_contract_no partition(inc_day='$firstDay')
select 
qyzt,
contract_no,
contract_stat,
gys_name,
gys_code,
business_lines,
htss_bu,
htss_dq,
enable_date,
disable_date,
htlx,
htgsxmdm,
contract_content,
is_withholding,
creater_name,
create_organization,
amount,
tax_point,
payment_condition,
(paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off) as paid_money,
paid_yly_sys+paid as paid_yly_total,
paid_yly_sys,
paid as paid_yly_hand,
(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off) as paid_wly_total,
(ad_payment_sys+ad_payment) as ad_payment_total,
ad_payment_sys,
ad_payment as ad_payment_hand,
(earnest_sys+earnest) as earnest_total,
earnest_sys,
earnest as earnest_hand,
ad_payment_off as ad_payment_off,
earnest_off as earnest_off,
(ad_payment_sys+ad_payment-ad_payment_off) as ad_payment_on,
(earnest_sys+earnest-earnest_off) as earnest_on,
amount-((paid_yly_sys+paid)+(ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off)) as no_payment,
(payable_fi+payable_estimate+payable_other) as no_payment_yly_total,
payable_fi as payable_fi,
payable_estimate as payable_estimate,
payable_other as payable_other,
(payable_fi+payable_estimate+payable_other)-((ad_payment_sys+ad_payment-ad_payment_off)+(earnest_sys+earnest-earnest_off)) as payable_balance,
invoiced_amount1+invoiced_amount2 as invoiced_amount,
amount-(invoiced_amount1+invoiced_amount2) as no_invoiced_amount
from 
(
select 
t0.qyzt,
t0.contract_no,
t3.contract_stat,
t0.gys_name,
t0.gys_code,
t2.business_lines,
t0.htss_bu,
t0.htss_dq,
t0.enable_date,
t0.disable_date,
t0.htlx,
t0.htgsxmdm,
t0.contract_content,
t1.is_withholding,
t0.creater_name,
t0.create_organization,
case when t0.amount is null or t0.amount='' then 0.0 else t0.amount end as amount,
t0.tax_point,
t0.payment_condition,
case when t1.paid is null or t1.paid='' then 0.0 else t1.paid end as paid,
case when t1.ad_payment is null or t1.ad_payment='' then 0.0 else t1.ad_payment end  as ad_payment,
case when t1.ad_payment_off is null   or t1.ad_payment_off=''  then 0.0 else t1.ad_payment_off end  as ad_payment_off,
case when t1.earnest_off is null  or t1.earnest_off=''   then 0.0 else t1.earnest_off end  as earnest_off,
case when t1.payable_fi is null  or t1.payable_fi=''   then 0.0 else t1.payable_fi end  as payable_fi,
case when t1.payable_estimate is null  or t1.payable_estimate=''  then 0.0 else t1.payable_estimate  end  as payable_estimate,
case when t1.payable_other is null  or t1.payable_other=''  then 0.0 else t1.payable_other end  as payable_other,
case when t1.earnest is null  or t1.earnest=''  then 0.0 else t1.earnest end  as earnest, 
0.0 as invoiced_amount1,
0.0 as invoiced_amount2,
0.0 as paid_yly_sys,
0.0 as ad_payment_sys,
0.0 as earnest_sys 
from (
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,amount,tax_point,payment_condition,jzrq,inc_day 
from (
select 
qyzt,contract_no,contract_stat,gys_name,gys_code,htss_bu,htss_dq,enable_date,disable_date,htlx,htgsxmdm,contract_content,creater_name,create_organization,amount,tax_point,payment_condition,jzrq,inc_day,
row_number() over(partition by contract_no order by inc_day desc) rn   
from dm_gis_uimp.ods_contract_wopo_input where  inc_day>='20220101' ) as trn 
where trn.rn=1 
) as t0 
left join dm_gis_uimp.ods_contract_handwork_tmp as t1 
on t0.contract_no=t1.contract_no 
left join dm_gis_uimp.dim_bu_business_lines as t2 
on t0.htss_bu=t2.bu 
left join dm_gis_uimp.dim_contract_stat_id as t3 
on t0.contract_stat=t3.contract_stat_id 
) as t 
;


---- 2022-12-29
--SSP供应商结算云数据
--新增： ods_ssp2.plf_form_life   (表单操作记录表)

CREATE TABLE dm_gis_uimp.ods_plf_form_life(
`id` bigint COMMENT 'ID',
`bus_type` string COMMENT '业务类型',
`bus_key` string COMMENT '业务主键',
`order_no` string COMMENT '单据编号',
`operate_type` string COMMENT '操作类型-编码',
`operate_result` string COMMENT '操作结果',
`operate_desc` string COMMENT '操作类型-描述',
`operate_cue` string COMMENT '操作类型-操作提示',
`remark` string COMMENT '备注',
`create_user` string COMMENT '创建人',
`create_time` string COMMENT '创建时间',
`lessee_no` string COMMENT '租户')
COMMENT '表单操作记录表'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set mapreduce.input.fileinputformat.split.maxsize=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.rack=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.node=268435456;
set mapred.max.split.size=268435456;
set mapred.min.split.size.per.node=268435456;
set mapred.min.split.size.per.rack=268435456;
--设置jvm重用
set mapred.job.reuse.jvm.num.tasks=10;

insert overwrite table dm_gis_uimp.ods_plf_form_life partition(inc_day)
select id,bus_type,bus_key,order_no,operate_type,operate_result,operate_desc,operate_cue,remark,create_user,create_time,lessee_no,inc_day 
from  ods_ssp2.plf_form_life  where  inc_day=$firstDay
;



----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
---- 2023-01-05 
-- SAP901系统的丰图凭证数据  源表：SAPSR3.ZBSEG
-- oracle连接信息：
-- efp.db.sfdc.com.cn:1521/efp
-- sapsr3
-- BEIC_ETL
-- SAP2BEIC_etl#2022
create table dm_gis_uimp.ods_sap_zbseg(
mandt     string  ,
bukrs     string  ,
belnr     string  ,
gjahr     string  ,
buzei     string  ,
buzid     string  ,
cpudt     string  ,
augdt     string  ,
augcp     string  ,
augbl     string  ,
bschl     string  ,
koart     string  ,
umskz     string  ,
umsks     string  ,
zumsk     string  ,
shkzg     string  ,
gsber     string  ,
pargb     string  ,
mwskz     string  ,
qsskz     string  ,
dmbtr     string  ,
wrbtr     string  ,
kzbtr     string  ,
pswbt     string  ,
pswsl     string  ,
txbhw     string  ,
txbfw     string  ,
mwsts     string  ,
wmwst     string  ,
hwbas     string  ,
fwbas     string  ,
hwzuz     string  ,
fwzuz     string  ,
shzuz     string  ,
stekz     string  ,
mwart     string  ,
txgrp     string  ,
ktosl     string  ,
qsshb     string  ,
kursr     string  ,
gbetr     string  ,
bdiff     string  ,
bdif2     string  ,
valut     string  ,
zuonr     string  ,
sgtxt     string  ,
zinkz     string  ,
vbund     string  ,
bewar     string  ,
altkt     string  ,
vorgn     string  ,
fdlev     string  ,
fdgrp     string  ,
fdwbt     string  ,
fdtag     string  ,
fkont     string  ,
kokrs     string  ,
kostl     string  ,
projn     string  ,
aufnr     string  ,
vbeln     string  ,
vbel2     string  ,
posn2     string  ,
eten2     string  ,
anln1     string  ,
anln2     string  ,
anbwa     string  ,
bzdat     string  ,
pernr     string  ,
xumsw     string  ,
xhres     string  ,
xkres     string  ,
xopvw     string  ,
xcpdd     string  ,
xskst     string  ,
xsauf     string  ,
xspro     string  ,
xserg     string  ,
xfakt     string  ,
xuman     string  ,
xanet     string  ,
xskrl     string  ,
xinve     string  ,
xpanz     string  ,
xauto     string  ,
xncop     string  ,
xzahl     string  ,
saknr     string  ,
hkont     string  ,
kunnr     string  ,
lifnr     string  ,
filkd     string  ,
xbilk     string  ,
gvtyp     string  ,
hzuon     string  ,
zfbdt     string  ,
zterm     string  ,
zbd1t     string  ,
zbd2t     string  ,
zbd3t     string  ,
zbd1p     string  ,
zbd2p     string  ,
skfbt     string  ,
sknto     string  ,
wskto     string  ,
zlsch     string  ,
zlspr     string  ,
zbfix     string  ,
hbkid     string  ,
bvtyp     string  ,
nebtr     string  ,
mwsk1     string  ,
dmbt1     string  ,
wrbt1     string  ,
mwsk2     string  ,
dmbt2     string  ,
wrbt2     string  ,
mwsk3     string  ,
dmbt3     string  ,
wrbt3     string  ,
rebzg     string  ,
rebzj     string  ,
rebzz     string  ,
rebzt     string  ,
zollt     string  ,
zolld     string  ,
lzbkz     string  ,
landl     string  ,
diekz     string  ,
samnr     string  ,
abper     string  ,
vrskz     string  ,
vrsdt     string  ,
disbn     string  ,
disbj     string  ,
disbz     string  ,
wverw     string  ,
anfbn     string  ,
anfbj     string  ,
anfbu     string  ,
anfae     string  ,
blnbt     string  ,
blnkz     string  ,
blnpz     string  ,
mschl     string  ,
mansp     string  ,
madat     string  ,
manst     string  ,
maber     string  ,
esrnr     string  ,
esrre     string  ,
esrpz     string  ,
klibt     string  ,
qsznr     string  ,
qbshb     string  ,
qsfbt     string  ,
navhw     string  ,
navfw     string  ,
matnr     string  ,
werks     string  ,
menge     string  ,
meins     string  ,
erfmg     string  ,
erfme     string  ,
bpmng     string  ,
bprme     string  ,
ebeln     string  ,
ebelp     string  ,
zekkn     string  ,
elikz     string  ,
vprsv     string  ,
peinh     string  ,
bwkey     string  ,
bwtar     string  ,
bustw     string  ,
rewrt     string  ,
rewwr     string  ,
bonfb     string  ,
bualt     string  ,
psalt     string  ,
nprei     string  ,
tbtkz     string  ,
spgrp     string  ,
spgrm     string  ,
spgrt     string  ,
spgrg     string  ,
spgrv     string  ,
spgrq     string  ,
stceg     string  ,
egbld     string  ,
eglld     string  ,
rstgr     string  ,
ryacq     string  ,
rpacq     string  ,
rdiff     string  ,
rdif2     string  ,
prctr     string  ,
xhkom     string  ,
vname     string  ,
recid     string  ,
egrup     string  ,
vptnr     string  ,
vertt     string  ,
vertn     string  ,
vbewa     string  ,
depot     string  ,
txjcd     string  ,
imkey     string  ,
dabrz     string  ,
popts     string  ,
fipos     string  ,
kstrg     string  ,
nplnr     string  ,
aufpl     string  ,
aplzl     string  ,
projk     string  ,
paobjnr   string  ,
pasubnr   string  ,
spgrs     string  ,
spgrc     string  ,
btype     string  ,
etype     string  ,
xegdr     string  ,
lnran     string  ,
hrkft     string  ,
dmbe2     string  ,
dmbe3     string  ,
dmb21     string  ,
dmb22     string  ,
dmb23     string  ,
dmb31     string  ,
dmb32     string  ,
dmb33     string  ,
mwst2     string  ,
mwst3     string  ,
navh2     string  ,
navh3     string  ,
sknt2     string  ,
sknt3     string  ,
bdif3     string  ,
rdif3     string  ,
hwmet     string  ,
glupm     string  ,
xragl     string  ,
uzawe     string  ,
lokkt     string  ,
fistl     string  ,
geber     string  ,
stbuk     string  ,
txbh2     string  ,
txbh3     string  ,
pprct     string  ,
xref1     string  ,
xref2     string  ,
kblnr     string  ,
kblpos    string  ,
sttax     string  ,
fkber     string  ,
obzei     string  ,
xnegp     string  ,
rfzei     string  ,
ccbtc     string  ,
kkber     string  ,
empfb     string  ,
xref3     string  ,
dtws1     string  ,
dtws2     string  ,
dtws3     string  ,
dtws4     string  ,
gricd     string  ,
grirg     string  ,
gityp     string  ,
xpypr     string  ,
kidno     string  ,
absbt     string  ,
idxsp     string  ,
linfv     string  ,
kontt     string  ,
kontl     string  ,
txdat     string  ,
agzei     string  ,
pycur     string  ,
pyamt     string  ,
bupla     string  ,
secco     string  ,
lstar     string  ,
cession_kz string ,
prznr     string  ,
ppdiff    string  ,
ppdif2    string  ,
ppdif3    string  ,
penlc1    string  ,
penlc2    string  ,
penlc3    string  ,
penfc     string  ,
pendays   string  ,
penrc     string  ,
grant_nbr string  ,
sctax     string  ,
fkber_long string ,
gmvkz     string  ,
srtype    string  ,
intreno   string  ,
measure   string  ,
auggj     string  ,
ppa_ex_ind string ,
docln     string  ,
segment   string  ,
psegment  string  ,
pfkber    string  ,
hktid     string  ,
kstar     string  ,
xlgclr    string  ,
taxps     string  ,
pays_prov string  ,
pays_tran string  ,
mndid     string  ,
xfrge_bseg string ,
re_bukrs  string  ,
re_account string ,
pgeber    string  ,
pgrant_nbr string ,
budget_pd string  ,
pbudget_pd string ,
perop_beg string  ,
perop_end string  ,
fastpay   string  ,
ignr_ivref string ,
fmfgus_key string ,
fmxdocnr  string  ,
fmxyear   string  ,
fmxdocln  string  ,
fmxzekkn  string  ,
prodper   string  ,
timestamp_a string  
) 
COMMENT 'SAP901系统的丰图凭证数据'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;



-- 跑数
insert overwrite table dm_gis_uimp.ods_sap_zbseg partition(inc_day='$firstDay')
select * from  dm_gis_uimp.ods_sap_zbseg_mid  
;


----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------
---- 2023-02-01 
-- 丰图人员组织信息
-- 数据库信息：
-- url: jdbc:mysql://gisissp-m.db.sfcloud.local:3306/gisissp?serverTimezone=Asia/Shanghai&characterEncoding=utf8&useSSL=false
-- username: gisissp
-- password: Gis@ISSP@GIS 

-- issp_emp_data 人员主表-通用字段
create table dm_gis_uimp.ods_issp_emp_data(
emp_num string ,
emp_name string ,
emp_source string ,
emp_type string ,
job_id string ,
job_name string ,
position_id string ,
position_name string ,
org_id string ,
org_code string ,
org_name string ,
sex string ,
age string ,
phone_num string ,
net_code string ,
natio string ,
email string ,
position_attr string ,
supervisor_number string ,
supervisor_name string ,
hire_date string ,
ssqy_code string ,
ssqy_txt string ,
update_time string ,
first_name string ,
office_phone string ,
source_type string ,
tenant_id string 
)
COMMENT '人员主表-通用字段'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- issp_emp_data_ext 人员主表-非通用字段
create table dm_gis_uimp.ods_issp_emp_data_ext(
emp_num string,
emp_id string,
birthday string,
leave_date string,
job_change_date string,
leave_reason string,
create_by string,
create_time string,
area string,
education string,
effect_date string,
hukou_type string,
hukou string,
height string,
weight string,
supplier_id string,
supplier_name string,
contract_id string,
grad_time string,
card_type string,
contacts string,
contacts_phone string,
driving_type string,
is_employer string,
bus_mode string,
import_time string,
gc_area_code string,
gc_area_net_code string,
is_sf_to_comp string,
register_date_time string,
out_date_time string,
remark string,
updator string,
auditing_date string,
mount_guard_date string,
out_type string,
out_sort string,
is_install_fs string,
is_gps_clock string,
sap_account string,
gc_area_id string,
sap_org_id string,
net_change_date string,
is_long_period string,
mandt string,
serno string,
abkrs string,
abkrs_txt string,
address string,
ass_category string,
ass_reason string,
blood_type string,
btrtl string,
btrtl_txt string,
bukrs string,
bukrs_txt string,
channel_name string,
cn_race string,
date_from string,
emp_cate_code string,
fkber string,
fkber_txt string,
is_odo_cj string,
is_odo_mj string,
job_date_from string,
kostl string,
kostl_txt string,
last_org_name string,
last_zno string,
marital_status string,
office_addr string,
old_last_name string,
pcn_pcode string,
pcn_pcode_txt string,
persg string,
persg_txt string,
persk string,
persk_txt string,
person_type string,
position_group string,
position_type string,
postal_code string,
probation_end_date string,
recruit_channel string,
sf_date string,
speciality string,
stell string,
stell_txt string,
vacation_start_date string,
werks string,
werks_txt string,
zhrzgzt string,
zhrzgzt_txt string,
zhrzzqc string,
zhrlzlx string,
position_ass_date string,
zhrzjdsj string,
mstbr string,
identifier string,
bank string,
banka string,
bankn string,
update_time string,
grpvl string,
icnum_a string,
ictyp string,
ictyp_a string,
molga string,
orgeh_lv1 string,
orgtx_lv1 string,
useto string,
zhrgzd string,
zhrgzd_up string,
zhrgzdmc string,
zhrgzdmc_up string,
zhrjfgs string,
zhrjfgsmc string,
zhrjrhmdlx string,
zhrldhtqsrq string,
zhrldhtzzrq string,
zhrrllx string,
zhrrllx_t string,
zhrsrrq string,
cancel_flag string,
supplier_attr string,
issuing_organization string,
bussiness_type string,
bussiness_area string,
frdevic_invalid_time string,
operat_area string,
ris_status string,
valid_date string,
duty_num string,
is_sfmail string,
is_internet string,
is_insf string,
area_short string,
area_objid string,
major_code string,
is_pub_acc string,
zhrtkcm string,
zhrgycm string,
zhrgkcm string,
zhrjob_p string,
zhrjob_pname string,
stell_p string,
stell_ptxt string,
zhrxw string,
zhrtw string,
zhrxm string,
zhryw string,
banka_fund string,
bankn_fund string,
banka_fee string,
bankn_fee string,
ssfid string,
personal_phone string,
zhrsfbcz string,
zhrsfgf string,
is_in_ad string,
banks string,
emftx string,
bankcode string,
zhrxzxm string
)
COMMENT '人员主表-非通用字段'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- ft_emp_out 丰图外包人员-主表
create table dm_gis_uimp.ods_ft_emp_out(
tenant_id string,
data_status string,
create_by string,
create_name string,
update_by string,
update_name string,
document_type string,
domain_account string,
emp_num string,
emp_type string,
english_name string,
entry_date string,
fs_permission string,
identification_number string,
landline string,
work_place string,
termination_date string,
superior_no string,
superior_name string,
source_emp_num string,
sf_mailbox_permission string,
sf_mailbox_name string,
sex string,
post_flag string,
position_name_tw string,
position_name_en string,
position_name_cn string,
position_level_name string,
position_level string,
position_id string,
position_attribute string,
network_meeting_permission string,
mailbox string,
org_id_out string,
org_id_in string,
org_name string,
phone_number string,
name string,
org_code string,
sf_mailbox_address string,
country_code string,
create_time string,
update_time string,
cost string,
category string
)
COMMENT '丰图外包人员-主表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- efp_cost  成本中心-主表
create table dm_gis_uimp.ods_efp_cost(
kokrs string,
kostl string,
datbi string,
datab string,
prctr string,
bkzkp string,
delfg string,
create_time string,
update_time string,
zuf01 string,
zuf02 string,
zuf03 string,
tenant_id string
)
COMMENT '成本中心-主表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- efp_cost_language 成本中心-语言子表
create table dm_gis_uimp.ods_efp_cost_language(
kokrs string,
kostl string,
datbi string,
spras string,
ktext string,
ltext string,
delfg string,
zuf01 string,
zuf02 string,
zuf03 string,
create_time string,
update_time string
)
COMMENT '成本中心-语言子表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- issp_org_data 组织-主表 
create table dm_gis_uimp.ods_issp_org_data(
org_id string,
org_id_parent string,
org_path string,
org_name string,
org_address string,
org_type string,
org_code string,
date_from string,
date_to string,
manager string,
manager_name string,
org_function string,
org_cj string,
zzgn_name string,
is_xzzz string,
net_code string,
inner_addr string,
org_yjzz string,
zsuv_pernr string,
zsuv_plans string,
zsuv_plstx string,
update_time string,
is_valid string,
zzcreated_by string,
zzcreated_on string,
zzcreated_ts string,
loc_id string,
zhrxzzz string,
kostl string,
kostl_txt string,
persa string,
zhrzzdj string,
zhrzzdj_txt string,
org_desc1 string,
org_desc2 string,
org_desc3 string,
stext string,
zhrglx string,
zhrsfssw string,
zhrssyw string,
zhrzzcc string,
zhrzzzlxt string,
area_short string,
area_objid string,
tenant_id string
)
COMMENT '组织-主表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- issp_org_data 组织-主表 (保存每天全量)
create table dm_gis_uimp.ods_issp_org_data_df(
org_id string,
org_id_parent string,
org_path string,
org_name string,
org_address string,
org_type string,
org_code string,
date_from string,
date_to string,
manager string,
manager_name string,
org_function string,
org_cj string,
zzgn_name string,
is_xzzz string,
net_code string,
inner_addr string,
org_yjzz string,
zsuv_pernr string,
zsuv_plans string,
zsuv_plstx string,
update_time string,
is_valid string,
zzcreated_by string,
zzcreated_on string,
zzcreated_ts string,
loc_id string,
zhrxzzz string,
kostl string,
kostl_txt string,
persa string,
zhrzzdj string,
zhrzzdj_txt string,
org_desc1 string,
org_desc2 string,
org_desc3 string,
stext string,
zhrglx string,
zhrsfssw string,
zhrssyw string,
zhrzzcc string,
zhrzzzlxt string,
area_short string,
area_objid string,
tenant_id string,
org_id_c1c2 string 
)
COMMENT '组织-主表（每天全量）'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- insert overwrite table dm_gis_uimp.ods_issp_org_data_df partition(inc_day='')
-- select * from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%'
-- ;

-- 2023.12.21 修改
-- 一、ods_issp_org_data_df新增org_id_c1c2字段，取值规则如下：
-- 1、组织架构的顶层为丰图科技org_id=10039268，为第0层
-- 2、如果org_id为第1或2层，取org_id
-- 3、如果org_id为第3层，取org_id_parent
-- 4、除此之外留空

-- 0级 （丰图科技）
-- select org_id,org_id_parent,org_name from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' and  org_id='10039268'

-- 1级组织    
-- select org_id,org_id_parent,org_name from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' and  org_id_parent='10039268'

-- 2级组织
drop table if exists dm_gis_uimp.tmp_org_id_c2_all;
create table dm_gis_uimp.tmp_org_id_c2_all stored as parquet as 
select org_id,org_id_parent,org_name from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' and  org_id_parent in 
(select org_id from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' and  org_id_parent='10039268' and org_id is not null and org_id<>'')
;

-- 3级组织 
drop table if exists dm_gis_uimp.tmp_org_id_c3_all;
create table dm_gis_uimp.tmp_org_id_c3_all stored as parquet as 
select org_id,org_id_parent,org_name from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' and  org_id_parent in 
(select org_id from dm_gis_uimp.tmp_org_id_c2_all where org_id is not null and org_id<>'')
;



insert overwrite table dm_gis_uimp.ods_issp_org_data_df partition(inc_day='')
select 
t0.org_id,t0.org_id_parent,org_path,org_name,org_address,org_type,org_code,date_from,date_to,manager,manager_name,org_function,org_cj,zzgn_name,is_xzzz,net_code,inner_addr,org_yjzz,zsuv_pernr,zsuv_plans,zsuv_plstx,update_time,is_valid,zzcreated_by,zzcreated_on,zzcreated_ts,loc_id,zhrxzzz,kostl,kostl_txt,persa,zhrzzdj,zhrzzdj_txt,org_desc1,org_desc2,org_desc3,stext,zhrglx,zhrsfssw,zhrssyw,zhrzzcc,zhrzzzlxt,area_short,area_objid,tenant_id,
case when (t0.org_id='10039268' or t1.org_id is not null or t2.org_id is not null) then t0.org_id
when t3.org_id is not null then t0.org_id_parent 
else null end as org_id_c1c2 
from (SELECT org_id,org_id_parent,org_path,org_name,org_address,org_type,org_code,date_from,date_to,manager,manager_name,org_function,org_cj,zzgn_name,is_xzzz,net_code,inner_addr,org_yjzz,zsuv_pernr,zsuv_plans,zsuv_plstx,update_time,is_valid,zzcreated_by,zzcreated_on,zzcreated_ts,loc_id,zhrxzzz,kostl,kostl_txt,persa,zhrzzdj,zhrzzdj_txt,org_desc1,org_desc2,org_desc3,stext,zhrglx,zhrsfssw,zhrssyw,zhrzzcc,zhrzzzlxt,area_short,area_objid,tenant_id FROM dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' 
) as t0 
left join (select org_id from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' and  org_id_parent='10039268' group by org_id) as t1 
on t0.org_id=t1.org_id 
left join (select org_id from dm_gis_uimp.tmp_org_id_c2_all group by org_id) as t2 
on t0.org_id=t2.org_id 
left join (select org_id from dm_gis_uimp.tmp_org_id_c3_all group by org_id) as t3 
on t0.org_id=t3.org_id
;




-- issp_org_data_virtual（此表2023.02.02上线）组织-虚拟组织子表
create table dm_gis_uimp.ods_issp_org_data_virtual(
id string,
org_id string,
org_parent_id string,
order_no string,
line_code string,
unit_id string,
kostl string,
prctr string,
line_manager_num string,
org_manager_num string,
org_pmo_num string,
hrbp_num string,
projectfi_num string,
modify_by_num string,
modify_by_name string,
modify_at string,
create_by_num string,
create_by_name string,
create_at string,
budget_manager_num string comment '预算负责人',
unit_manager_num  string comment '经营单元负责人' 
)
COMMENT '组织-虚拟组织子表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- dm_gis_uimp.ods_issp_org_data_virtual增加【unit_manager_num经营单元负责人】字段
-- 取值规则：根据表中unit_id，关联ods_issp_org_data_virtual.id，查出对应org_manager_num
insert overwrite table dm_gis_uimp.ods_issp_org_data_virtual 
select id,t0.org_id,org_parent_id,order_no,line_code,unit_id,kostl,prctr,line_manager_num,
t0.org_manager_num,
org_pmo_num,hrbp_num,projectfi_num,modify_by_num,modify_by_name,modify_at,create_by_num,create_by_name,
create_at,budget_manager_num,
t1.org_manager_num as  unit_manager_num 
from gisissp.issp_org_data_virtual as t0 
left join (select org_id,org_manager_num from dm_gis_uimp.ods_issp_org_data_virtual group by org_id,org_manager_num) as t1 
on t0.unit_id=t1.org_id 
;


-- 2023.12.15 组织-虚拟组织子表  （日快照）
create table dm_gis_uimp.ods_issp_org_data_virtual_df(
id string,
org_id string,
org_parent_id string,
order_no string,
line_code string,
unit_id string,
kostl string,
prctr string,
line_manager_num string,
org_manager_num string,
org_pmo_num string,
hrbp_num string,
projectfi_num string,
modify_by_num string,
modify_by_name string,
modify_at string,
create_by_num string,
create_by_name string,
create_at string,
budget_manager_num string comment '预算负责人',
unit_manager_num  string comment '经营单元负责人' 
)
COMMENT '组织-虚拟组织子表(日快照)'
PARTITIONED BY (inc_day STRING COMMENT '分区日期')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- 
insert overwrite table dm_gis_uimp.ods_issp_org_data_virtual_df partition(inc_day='') 
select id,org_id,org_parent_id,order_no,line_code,unit_id,kostl,prctr,line_manager_num,
org_manager_num,
org_pmo_num,hrbp_num,projectfi_num,modify_by_num,modify_by_name,modify_at,create_by_num,create_by_name,
create_at,budget_manager_num,
unit_manager_num 
from dm_gis_uimp.ods_issp_org_data_virtual
;



-- issp_business_line（此表2023.02.02上线）丰图业务线-主表
create table dm_gis_uimp.ods_issp_business_line(
id string,
line_code string,
line_name string,
line_pmo_no string,
line_pmo_name string,
manager_no string,
manager_name string,
status string,
create_by_emp_no string,
create_by_emp_name string,
create_at string,
modify_by_emp_no string,
modify_by_emp_name string,
modify_at string 
)
COMMENT '丰图业务线-主表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;




-- efp_com_code 丰图公司代码
create table dm_gis_uimp.ods_mysql_efp_com_code_af(
BUKRS string,
WAERS string,
BUTXT string,
LAND1 string,
KTOPL string,
FIKRS string,
REMARK string,
FLG_DELETE string,
ZZCUSTOM1 string,
ZZCUSTOM2 string,
ZZCUSTOM3 string,
CREATE_TIME string,
UPDATE_TIME string,
ACCGP string,
tenant_id  string 
) 
COMMENT '丰图公司代码'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- 丰图公司代码 (日分区)
create table dm_gis_uimp.ods_mysql_efp_com_code_df(
BUKRS string,
WAERS string,
BUTXT string,
LAND1 string,
KTOPL string,
FIKRS string,
REMARK string,
FLG_DELETE string,
ZZCUSTOM1 string,
ZZCUSTOM2 string,
ZZCUSTOM3 string,
CREATE_TIME string,
UPDATE_TIME string,
ACCGP string,
tenant_id  string 
) 
COMMENT '丰图公司代码'
PARTITIONED by (inc_day string comment '')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


insert overwrite table dm_gis_uimp.ods_mysql_efp_com_code_df partition (inc_day='')
select * from dm_gis_uimp.ods_mysql_efp_com_code_af
;







----------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------

-- ftbill
-- 数据库类型：MySQL
-- 地址：100.96.162.70
-- 端口：3306
-- 库名：ftbill
-- 用户名：ftbill_read
-- 密码：ftbill@2023

-- 2023.12.19 从mysql获取已暂停
-- bill_amt_ret_claim_form 回款认领表 
create table dm_gis_uimp.ods_bill_amt_ret_claim_form(
id	string comment '序号，用于生成5位流水号',
claim_form_no	string comment '回款认领单编号',
company_contract_code	string comment '公司合同编号',
order_code	string comment '订单编号（支持多个订单，使用英文;分割）',
payment_id	string comment '流水批次号',
amt_claimed	string comment '本次认领金额合计(单位：分) 绝对值',
entry_acct_period	string comment '入账期间',
bukrs	string comment '公司代码',
butxt	string comment '公司名称',
trade_time	string comment '交易日期',
obj_acct_name	string comment '打款方户名',
amt	string comment '交易金额(单位：分)',
customer_name	string comment '客户名称',
contract_amount	string comment '合同金额(单位：分)',
amt_order	string comment '订单金额',
status	string comment '单据状态（-1-已保存，0-已提交，1-审核通过，2-审核不通过，3-失效，4-系统认领待确认，5-系统撤销待确认，6-已反审核，7-已冲销）',
modify_at	string comment '修改日期',
create_at	string comment '创建时间',
claimed_at	string comment '认领日期',
emp_no	string comment '认领人工号',
emp_name	string comment '认领人姓名',
amt_claimed_plus	string comment '认领金额合计正负状态（0-负数，1-正数）',
check_status	string comment '核算状态',
order_type	string comment '单据类型',
origin_claim_form_no	string comment '原认领单号',
ecp_contract_code	string comment 'ECP合同编号',
unit_name	string comment '经营单元',
supplementary_agreement_code	string comment '合同补充协议编号',
source	string comment '数据来源' 
)
COMMENT '回款认领表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- 2023.12.14  改成调接口获取数据，增加字段
alter table dm_gis_uimp.ods_bill_amt_ret_claim_form add columns (review_empNo	string comment'审核人工号');
alter table dm_gis_uimp.ods_bill_amt_ret_claim_form add columns (review_empName	string comment'审核人姓名');
alter table dm_gis_uimp.ods_bill_amt_ret_claim_form add columns (de_review_empNo	string comment'反审核人工号');
alter table dm_gis_uimp.ods_bill_amt_ret_claim_form add columns (de_review_empName	string comment'反审核人姓名');
alter table dm_gis_uimp.ods_bill_amt_ret_claim_form add columns (de_review_reason	string comment'反审核原因');
alter table dm_gis_uimp.ods_bill_amt_ret_claim_form add columns (amt_to_be_claim	string comment'');
alter table dm_gis_uimp.ods_bill_amt_ret_claim_form add columns (approved_date	string comment'回款认领/冲销审批通过时间');


-- bill_amt_ret_claim_form 回款认领表 (从api获取数据)
CREATE TABLE `dm_gis_uimp.ods_bill_amt_ret_claim_form_mid`(
`id` string,
`claimformno` string,
`supplementaryagreementcode` string,
`ordertype` string,
`originclaimformno` string,
`ecpcontractcode` string,
`unitname` string,
`companycontractcode` string,
`reviewempno` string,
`reviewempname` string,
`dereviewempno` string,
`dereviewempname` string,
`dereviewreason` string,
`paymentid` string,
`amtclaimed` string,
`amttobeclaim` string,
`entryacctperiod` string,
`bukrs` string,
`butxt` string,
`tradetime` string,
`objacctname` string,
`amt` string,
`customername` string,
`contractamount` string,
`ordercode` string,
`amtorder` string,
`status` string,
`checkstatus` string,
`modifyat` string,
`createat` string,
`claimedat` string,
`empno` string,
`empname` string,
`approveddate` string
)
COMMENT '回款认领表(api获取数据)'
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


insert overwrite table dm_gis_uimp.ods_bill_amt_ret_claim_form  
select 
id,claim_form_no,company_contract_code,order_code,payment_id,amt_claimed,entry_acct_period,bukrs,butxt,trade_time,obj_acct_name,
amt,customer_name,contract_amount,amt_order,status,modify_at,create_at,claimed_at,emp_no,emp_name,amt_claimed_plus,check_status,
order_type,origin_claim_form_no,ecp_contract_code,unit_name,supplementary_agreement_code,source,
review_empno,review_empname,de_review_empno,de_review_empname,de_review_reason,amt_to_be_claim,approved_date  
from (select 
if(t1.claimformno is not null,t1.id,t0.id) as id,
if(t1.claimformno is not null,claimFormNo,t0.claim_form_no) as claim_form_no,
if(t1.claimformno is not null,companyContractCode,t0.company_contract_code) as company_contract_code,
if(t1.claimformno is not null,orderCode,t0.order_code) as order_code,
if(t1.claimformno is not null,paymentId,t0.payment_id) as payment_id,
if(t1.claimformno is not null,amtClaimed,t0.amt_claimed) as amt_claimed,
if(t1.claimformno is not null,entryAcctPeriod,t0.entry_acct_period) as entry_acct_period,
if(t1.claimformno is not null,t1.bukrs,t0.bukrs) as bukrs,
if(t1.claimformno is not null,t1.butxt,t0.butxt) as butxt,
if(t1.claimformno is not null,t1.tradeTime,t0.trade_time) as trade_time,
if(t1.claimformno is not null,t1.objAcctName,t0.obj_acct_name) as obj_acct_name,

if(t1.claimformno is not null,t1.amt,t0.amt) as amt,
if(t1.claimformno is not null,t1.customerName,t0.customer_name) as customer_name,
if(t1.claimformno is not null,t1.contractAmount,t0.contract_amount) as contract_amount,
if(t1.claimformno is not null,t1.amtOrder,t0.amt_order) as amt_order,
if(t1.claimformno is not null,t1.status,t0.status) as status,
if(t1.claimformno is not null,t1.modifyAt,t0.modify_at) as modify_at,
if(t1.claimformno is not null,t1.createAt,t0.create_at) as create_at,
if(t1.claimformno is not null,t1.claimedAt,t0.claimed_at) as claimed_at,
if(t1.claimformno is not null,t1.empNo,t0.emp_no) as emp_no,
if(t1.claimformno is not null,t1.empName,t0.emp_name) as emp_name,
if(t1.claimformno is not null,'',t0.amt_claimed_plus) as amt_claimed_plus,
if(t1.claimformno is not null,t1.checkStatus,t0.check_status) as check_status,

if(t1.claimformno is not null,t1.orderType,t0.order_type) as order_type,
if(t1.claimformno is not null,t1.originClaimFormNo,t0.origin_claim_form_no) as origin_claim_form_no,
if(t1.claimformno is not null,t1.ecpContractCode,t0.ecp_contract_code) as ecp_contract_code,
if(t1.claimformno is not null,t1.unitName,t0.unit_name) as unit_name,
if(t1.claimformno is not null,t1.supplementaryAgreementCode,t0.supplementary_agreement_code) as supplementary_agreement_code,
if(t1.claimformno is not null,'',t0.source) as source,

if(t1.claimformno is not null,t1.reviewEmpNo,t0.review_empno) as review_empno,
if(t1.claimformno is not null,t1.reviewEmpName,t0.review_empname) as review_empname,
if(t1.claimformno is not null,t1.deReviewEmpNo,t0.de_review_empno) as de_review_empno,
if(t1.claimformno is not null,t1.deReviewEmpName,t0.de_review_empname) as de_review_empname,
if(t1.claimformno is not null,t1.deReviewReason,t0.de_review_reason) as de_review_reason,
if(t1.claimformno is not null,t1.amtToBeClaim,t0.amt_to_be_claim) as amt_to_be_claim,
if(t1.claimformno is not null,t1.approveddate,t0.approved_date) as approved_date 

from (SELECT id,claim_form_no,company_contract_code,order_code,payment_id,amt_claimed,entry_acct_period,bukrs,butxt,trade_time,obj_acct_name,
amt,customer_name,contract_amount,amt_order,status,modify_at,create_at,claimed_at,emp_no,emp_name,amt_claimed_plus,check_status,
order_type,origin_claim_form_no,ecp_contract_code,unit_name,supplementary_agreement_code,source,
review_empno,review_empname,de_review_empno,de_review_empname,de_review_reason,amt_to_be_claim,approved_date  
FROM dm_gis_uimp.ods_bill_amt_ret_claim_form ) as t0 
FULL OUTER JOIN 
(SELECT id,claimformno,supplementaryagreementcode,ordertype,originclaimformno,ecpcontractcode,unitname,companycontractcode,reviewempno,
reviewempname,dereviewempno,dereviewempname,dereviewreason,paymentid,amtclaimed,amttobeclaim,entryacctperiod,bukrs,butxt,tradetime,
objacctname,amt,customername,contractamount,ordercode,amtorder,status,checkstatus,modifyat,createat,claimedat,empno,empname,approveddate 
FROM dm_gis_uimp.ods_bill_amt_ret_claim_form_mid where inc_day='') as t1 
on t0.claim_form_no=t1.claimformno 
) as t group by id,claim_form_no,company_contract_code,order_code,payment_id,amt_claimed,entry_acct_period,bukrs,butxt,trade_time,obj_acct_name,
amt,customer_name,contract_amount,amt_order,status,modify_at,create_at,claimed_at,emp_no,emp_name,amt_claimed_plus,check_status,
order_type,origin_claim_form_no,ecp_contract_code,unit_name,supplementary_agreement_code,source,
review_empno,review_empname,de_review_empno,de_review_empname,de_review_reason,amt_to_be_claim,approved_date  
;


-- 回款认领表 (每日分区存)
CREATE TABLE `dm_gis_uimp.ods_bill_amt_ret_claim_form_df`(
`id` string COMMENT '序号，用于生成5位流水号',
`claim_form_no` string COMMENT '回款认领单编号',
`company_contract_code` string COMMENT '公司合同编号',
`order_code` string COMMENT '订单编号（支持多个订单，使用英文\;分割）',
`payment_id` string COMMENT '流水批次号',
`amt_claimed` string COMMENT '本次认领金额合计(单位：分) 绝对值',
`entry_acct_period` string COMMENT '入账期间',
`bukrs` string COMMENT '公司代码',
`butxt` string COMMENT '公司名称',
`trade_time` string COMMENT '交易日期',
`obj_acct_name` string COMMENT '打款方户名',
`amt` string COMMENT '交易金额(单位：分)',
`customer_name` string COMMENT '客户名称',
`contract_amount` string COMMENT '合同金额(单位：分)',
`amt_order` string COMMENT '订单金额',
`status` string COMMENT '单据状态（-1-已保存，0-已提交，1-审核通过，2-审核不通过，3-失效，4-系统认领待确认，5-系统撤销待确认，6-已反审核，7-已冲销）',
`modify_at` string COMMENT '修改日期',
`create_at` string COMMENT '创建时间',
`claimed_at` string COMMENT '认领日期',
`emp_no` string COMMENT '认领人工号',
`emp_name` string COMMENT '认领人姓名',
`amt_claimed_plus` string COMMENT '认领金额合计正负状态（0-负数，1-正数）',
`check_status` string COMMENT '核算状态',
`order_type` string COMMENT '单据类型',
`origin_claim_form_no` string COMMENT '原认领单号',
`ecp_contract_code` string COMMENT 'ECP合同编号',
`unit_name` string COMMENT '经营单元',
`supplementary_agreement_code` string COMMENT '合同补充协议编号',
`source` string COMMENT '数据来源',
`review_empno` string COMMENT '审核人工号',
`review_empname` string COMMENT '审核人姓名',
`de_review_empno` string COMMENT '反审核人工号',
`de_review_empname` string COMMENT '反审核人姓名',
`de_review_reason` string COMMENT '反审核原因',
`amt_to_be_claim` string COMMENT '',
`approved_date` string COMMENT '回款认领/冲销审批通过时间')
COMMENT '回款认领表 (每日分区存)'
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


--
insert overwrite table dm_gis_uimp.ods_bill_amt_ret_claim_form_df partition(inc_day='$firstDay')  
select 
id,claim_form_no,company_contract_code,order_code,payment_id,amt_claimed,entry_acct_period,bukrs,butxt,trade_time,obj_acct_name,
amt,customer_name,contract_amount,amt_order,status,modify_at,create_at,claimed_at,emp_no,emp_name,amt_claimed_plus,check_status,
order_type,origin_claim_form_no,ecp_contract_code,unit_name,supplementary_agreement_code,source,
review_empno,review_empname,de_review_empno,de_review_empname,de_review_reason,amt_to_be_claim,approved_date  
from dm_gis_uimp.ods_bill_amt_ret_claim_form
;



-- 2023.12.19 从mysql获取已暂停
-- bill_income_confirm 收入确认单表
create table dm_gis_uimp.ods_bill_income_confirm(
id string,
income_number string,
enter_account_date string,
cheack_status string,
order_number string,
order_date string,
accept_date string,
create_by string,
staff_num string,
staff_name string,
business_type string,
customer_name string,
contract_sign_scene string,
company_contract_code string,
order_code string,
ecp_contract_code string,
company_code string,
has_collection_right string,
has_bkb_customer string,
order_status string,
settlement_currency string,
contract_amount string,
hardware_host_num string,
accept_count string,
hardware_count string,
service_begin_date string,
service_end_date string,
share_month string,
share_rate_amount string,
project_phase string,
project_phase_progress string,
project_complete_date string,
project_phase_amount string,
income_node string,
confirm_status string,
performance_id string,
order_type string,
adjust_number string,
supplement_contract_code string,
performance_type string,
performance_detail string,
tax_rate string,
charge_off_rate_amount string,
contract_performance_id string,
charge_off_amount string,
income_rate_amount string,
charge_off_type string  
)
COMMENT '收入确认单表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- 2023.12.14  改成调接口获取数据，增加字段
alter table dm_gis_uimp.ods_bill_income_confirm add columns (customer_name_val	string comment'客户名称');
alter table dm_gis_uimp.ods_bill_income_confirm add columns (current_rate_amount	string comment'	本次验收含税总金额');
alter table dm_gis_uimp.ods_bill_income_confirm add columns (current_amount	string comment'	本次验收不含税总金额');
alter table dm_gis_uimp.ods_bill_income_confirm add columns (performance_rate_amount	string comment'	履约含税金额');
alter table dm_gis_uimp.ods_bill_income_confirm add columns (performance_amount	string comment'	履约不含税金额');
alter table dm_gis_uimp.ods_bill_income_confirm add columns (income_amount	string comment'	收入不含税金额');

-- bill_income_confirm 收入确认单表(api获取数据)
CREATE TABLE `dm_gis_uimp.ods_bill_income_comfirm_mid`(
`id` string,
`incomenumber` string,
`businesstype` string,
`orderdate` string,
`enteraccountdate` string,
`companycode` string,
`customername` string,
`customernameval` string,
`ordernumber` string,
`companycontractcode` string,
`orderstatus` string,
`ordertype` string,
`ecpcontractcode` string,
`ordercode` string,
`cheackstatus` string,
`performanceid` string,
`performancetype` string,
`performancedetail` string,
`taxrate` string,
`currentrateamount` string,
`currentamount` string,
`performancerateamount` string,
`performanceamount` string,
`incomenode` string,
`adjustnumber` string,
`supplementcontractcode` string,
`chargeoffrateamount` string,
`chargeoffamount` string,
`chargeofftype` string,
`incomerateamount` string,
`incomeamount` string
)
COMMENT '收入确认单表(api获取数据)'
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


insert overwrite table dm_gis_uimp.ods_bill_income_confirm 
select 
id,income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,staff_name,
business_type,customer_name,contract_sign_scene,company_contract_code,order_code,ecp_contract_code,company_code,has_collection_right,
has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,accept_count,hardware_count,service_begin_date,
service_end_date,share_month,share_rate_amount,project_phase,project_phase_progress,project_complete_date,project_phase_amount,income_node,
confirm_status,performance_id,order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type,
customer_name_val,current_rate_amount,current_amount,performance_rate_amount,performance_amount,income_amount  
from (select 
if(t1.incomenumber is not null ,t1.id,t0.id) as id,
if(t1.incomenumber is not null,t1.incomenumber,t0.income_number) as income_number,
if(t1.incomenumber is not null,t1.enteraccountdate,t0.enter_account_date) as enter_account_date,
if(t1.incomenumber is not null,t1.cheackstatus,t0.cheack_status) as cheack_status,
if(t1.incomenumber is not null,t1.ordernumber,t0.order_number) as order_number,
if(t1.incomenumber is not null,t1.orderdate,t0.order_date) as order_date,
if(t1.incomenumber is not null,'',t0.accept_date) as accept_date,
if(t1.incomenumber is not null,'',t0.create_by) as create_by,
if(t1.incomenumber is not null,'',t0.staff_num) as staff_num,
if(t1.incomenumber is not null,'',t0.staff_name) as staff_name,

if(t1.incomenumber is not null,t1.businesstype,t0.business_type) as business_type,
if(t1.incomenumber is not null,t1.customername,t0.customer_name) as customer_name,
if(t1.incomenumber is not null,'',t0.contract_sign_scene) as contract_sign_scene,
if(t1.incomenumber is not null,companyContractCode,t0.company_contract_code) as company_contract_code,
if(t1.incomenumber is not null,orderCode,t0.order_code) as order_code,
if(t1.incomenumber is not null,ecpContractCode,t0.ecp_contract_code) as ecp_contract_code,
if(t1.incomenumber is not null,companyCode,t0.company_code) as company_code,
if(t1.incomenumber is not null,'',t0.has_collection_right) as has_collection_right,

if(t1.incomenumber is not null,'',t0.has_bkb_customer) as has_bkb_customer,
if(t1.incomenumber is not null,orderStatus,t0.order_status) as order_status,
if(t1.incomenumber is not null,'',t0.settlement_currency) as settlement_currency,
if(t1.incomenumber is not null,'',t0.contract_amount) as contract_amount,
if(t1.incomenumber is not null,'',t0.hardware_host_num) as hardware_host_num,
if(t1.incomenumber is not null,'',t0.accept_count) as accept_count,
if(t1.incomenumber is not null,'',t0.hardware_count) as hardware_count,
if(t1.incomenumber is not null,'',t0.service_begin_date) as service_begin_date,

if(t1.incomenumber is not null,'',t0.service_end_date) as service_end_date,
if(t1.incomenumber is not null,'',t0.share_month) as share_month,
if(t1.incomenumber is not null,'',t0.share_rate_amount) as share_rate_amount,
if(t1.incomenumber is not null,'',t0.project_phase) as project_phase,
if(t1.incomenumber is not null,'',t0.project_phase_progress) as project_phase_progress,
if(t1.incomenumber is not null,'',t0.project_complete_date) as project_complete_date,
if(t1.incomenumber is not null,'',t0.project_phase_amount) as project_phase_amount,
if(t1.incomenumber is not null,incomeNode,t0.income_node) as income_node,

if(t1.incomenumber is not null,'',t0.confirm_status) as confirm_status,
if(t1.incomenumber is not null,performanceId,t0.performance_id) as performance_id,
if(t1.incomenumber is not null,orderType,t0.order_type) as order_type,
if(t1.incomenumber is not null,adjustNumber,t0.adjust_number) as adjust_number,
if(t1.incomenumber is not null,supplementContractCode,t0.supplement_contract_code) as supplement_contract_code,
if(t1.incomenumber is not null,performanceType,t0.performance_type) as performance_type,
if(t1.incomenumber is not null,performanceDetail,t0.performance_detail) as performance_detail,
if(t1.incomenumber is not null,taxRate,t0.tax_rate) as tax_rate,
if(t1.incomenumber is not null,chargeOffRateAmount,t0.charge_off_rate_amount) as charge_off_rate_amount,

if(t1.incomenumber is not null,'',t0.contract_performance_id) as contract_performance_id,
if(t1.incomenumber is not null,chargeOffAmount,t0.charge_off_amount) as charge_off_amount,
if(t1.incomenumber is not null,incomeRateAmount,t0.income_rate_amount) as income_rate_amount,
if(t1.incomenumber is not null,chargeOffType,t0.charge_off_type) as charge_off_type,

if(t1.incomenumber is not null,customerNameVal,t0.customer_name_val) as customer_name_val,
if(t1.incomenumber is not null,currentRateAmount,t0.current_rate_amount) as current_rate_amount,
if(t1.incomenumber is not null,currentAmount,t0.current_amount) as current_amount,
if(t1.incomenumber is not null,performanceRateAmount,t0.performance_rate_amount) as performance_rate_amount,
if(t1.incomenumber is not null,performanceAmount,t0.performance_amount) as performance_amount,
if(t1.incomenumber is not null,incomeAmount,t0.income_amount) as income_amount 

from (SELECT id,income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,staff_name,
business_type,customer_name,contract_sign_scene,company_contract_code,order_code,ecp_contract_code,company_code,has_collection_right,
has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,accept_count,hardware_count,service_begin_date,
service_end_date,share_month,share_rate_amount,project_phase,project_phase_progress,project_complete_date,project_phase_amount,income_node,
confirm_status,performance_id,order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type,
customer_name_val,current_rate_amount,current_amount,performance_rate_amount,performance_amount,income_amount  
FROM dm_gis_uimp.ods_bill_income_confirm
) as t0 
FULL OUTER JOIN (
SELECT id,incomenumber,businesstype,orderdate,enteraccountdate,companycode,customername,customernameval,ordernumber,companycontractcode,orderstatus,
ordertype,ecpcontractcode,ordercode,cheackstatus,performanceid,performancetype,performancedetail,taxrate,currentrateamount,currentamount,performancerateamount,
performanceamount,incomenode,adjustnumber,supplementcontractcode,chargeoffrateamount,chargeoffamount,chargeofftype,incomerateamount,incomeamount 
FROM dm_gis_uimp.ods_bill_income_comfirm_mid where inc_day=''
) as t1 
on t0.income_number=t1.incomenumber 
) as t group by id,income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,staff_name,
business_type,customer_name,contract_sign_scene,company_contract_code,order_code,ecp_contract_code,company_code,has_collection_right,
has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,accept_count,hardware_count,service_begin_date,
service_end_date,share_month,share_rate_amount,project_phase,project_phase_progress,project_complete_date,project_phase_amount,income_node,
confirm_status,performance_id,order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type,
customer_name_val,current_rate_amount,current_amount,performance_rate_amount,performance_amount,income_amount  
;

-- 收入确认单表 (每日分区存储)
CREATE TABLE `dm_gis_uimp.ods_bill_income_confirm_df`(
`id` string,
`income_number` string,
`enter_account_date` string,
`cheack_status` string,
`order_number` string,
`order_date` string,
`accept_date` string,
`create_by` string,
`staff_num` string,
`staff_name` string,
`business_type` string,
`customer_name` string,
`contract_sign_scene` string,
`company_contract_code` string,
`order_code` string,
`ecp_contract_code` string,
`company_code` string,
`has_collection_right` string,
`has_bkb_customer` string,
`order_status` string,
`settlement_currency` string,
`contract_amount` string,
`hardware_host_num` string,
`accept_count` string,
`hardware_count` string,
`service_begin_date` string,
`service_end_date` string,
`share_month` string,
`share_rate_amount` string,
`project_phase` string,
`project_phase_progress` string,
`project_complete_date` string,
`project_phase_amount` string,
`income_node` string,
`confirm_status` string,
`performance_id` string,
`order_type` string,
`adjust_number` string,
`supplement_contract_code` string,
`performance_type` string,
`performance_detail` string,
`tax_rate` string,
`charge_off_rate_amount` string,
`contract_performance_id` string,
`charge_off_amount` string,
`income_rate_amount` string,
`charge_off_type` string,
`customer_name_val` string COMMENT '客户名称',
`current_rate_amount` string COMMENT '',
`current_amount` string COMMENT '',
`performance_rate_amount` string COMMENT '',
`performance_amount` string COMMENT '',
`income_amount` string COMMENT ''
)
COMMENT '收入确认单表' 
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- 
insert overwrite table dm_gis_uimp.ods_bill_income_confirm_df partition(inc_day='$firstDay')
select 
id,income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,staff_name,
business_type,customer_name,contract_sign_scene,company_contract_code,order_code,ecp_contract_code,company_code,has_collection_right,
has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,accept_count,hardware_count,service_begin_date,
service_end_date,share_month,share_rate_amount,project_phase,project_phase_progress,project_complete_date,project_phase_amount,income_node,
confirm_status,performance_id,order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type,
customer_name_val,current_rate_amount,current_amount,performance_rate_amount,performance_amount,income_amount  
from dm_gis_uimp.ods_bill_income_confirm
;

-- bill_performance_duty 收入履约义务表
create table dm_gis_uimp.ods_bill_performance_duty(
id string,
order_number string,
performance_type string,
performance_detail string,
tax_rate string,
amount_including_tax string,
current_rate_amount string,
current_amount string,
tax_amount string,
income_node string,
income_number string,
share_month string,
service_begin_date string,
accept_count string,
company_contract_code string,
order_code string,
unshare_month string,
shared_rate_amount string 
)
COMMENT '收入履约义务表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- 收入履约义务表(每日分区存)
create table dm_gis_uimp.ods_bill_performance_duty_df(
id string,
order_number string,
performance_type string,
performance_detail string,
tax_rate string,
amount_including_tax string,
current_rate_amount string,
current_amount string,
tax_amount string,
income_node string,
income_number string,
share_month string,
service_begin_date string,
accept_count string,
company_contract_code string,
order_code string,
unshare_month string,
shared_rate_amount string 
)
COMMENT '收入履约义务表(每日分区存)'
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

insert overwrite table dm_gis_uimp.ods_bill_performance_duty_df partition(inc_day='$firstDay')
select 
id,
order_number,
performance_type,
performance_detail,
tax_rate,
amount_including_tax,
current_rate_amount,
current_amount,
tax_amount,
income_node,
income_number,
share_month,
service_begin_date,
accept_count,
company_contract_code,
order_code,
unshare_month,
shared_rate_amount 
from dm_gis_uimp.ods_bill_performance_duty
;




-- 20230221  1583647  【信息化标准服务】表数据同步_V1.5
-- bill_service_share  服务分摊表
create table dm_gis_uimp.ods_bill_service_share( 
id string,
income_confirm_date string,
income_beconfirm_date string,
service_rate_amount string,
service_amount string,
confirm_status string,
order_number string,
income_number string,
performance_id string 
)
COMMENT '服务分摊表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- 服务分摊表(每日分区存)
create table dm_gis_uimp.ods_bill_service_share_df( 
id string,
income_confirm_date string,
income_beconfirm_date string,
service_rate_amount string,
service_amount string,
confirm_status string,
order_number string,
income_number string,
performance_id string 
)
COMMENT '服务分摊表(每日分区存)'
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

-- 
insert overwrite table dm_gis_uimp.ods_bill_service_share_df partition (inc_day='')
select 
id,
income_confirm_date,
income_beconfirm_date,
service_rate_amount,
service_amount,
confirm_status,
order_number,
income_number,
performance_id 
from dm_gis_uimp.ods_bill_service_share
;


-- 收入业绩明细表 开发
-- 
create table dm_gis_uimp.dws_bill_income_performance_detail( 
id	string	comment 'id',
income_number	string	comment '收入确认单编号',
enter_account_date	string	comment '入账日期:时间戳，毫秒',
cheack_status	string	comment '核算状态',
order_number	string	comment '验收单编号',
order_date	string	comment '单据日期:时间戳，毫秒',
accept_date	string	comment '验收日期:时间戳，毫秒',
create_by	string	comment '制单人',
staff_num	string	comment '制单人工号',
staff_name	string	comment '制单人姓名',
business_type	string	comment '业务类型',
customer_name	string	comment '客户名称(结算客户)',
contract_sign_scene	string	comment '合同签订场景',
company_contract_code	string	comment '公司合同编号',
order_code	string	comment '销售订单编号',
ecp_contract_code	string	comment 'ecp合同编号',
company_code	string	comment '公司代码',
has_collection_right	string	comment '是否有合格验收权:0是1否',
has_bkb_customer	string	comment '回款是否BKB终端客户:0是1否',
order_status	string	comment '单据状态:0保存、1已提交、2审批中、3审批通过、4审批不通过',
settlement_currency	string	comment '结算币别',
contract_amount	string	comment '合同金额',
hardware_host_num	string	comment '硬件主机数',
accept_count	string	comment '验收数量',
hardware_count	string	comment '服务对应硬件数量',
service_begin_date	string	comment '服务开始日期:时间戳，毫秒',
service_end_date	string	comment '服务结束日期:时间戳，毫秒',
share_month	string	comment '分摊月份数',
share_rate_amount	string	comment '分摊服务含税金额',
project_phase	string	comment '项目阶段',
project_phase_progress	string	comment '项目阶段进度',
project_complete_date	string	comment '项目实际完成时间:时间戳，毫秒',
project_phase_amount	string	comment '项目阶段确认收入（含税）',
income_node	string	comment '收入确认节点',
confirm_status	string	comment '是否已确认:0是1否',
performance_id	string	comment '履约义务id',
rate_amount	string	comment '收入含税金额',
amount	string	comment '收入不含税金额',
order_type	string	comment '单据类型:0收入确认(默认)、1收入冲销',
adjust_number	string	comment '调整单编号',
supplement_contract_code	string	comment '合同补充协议编号',
performance_type	string	comment '履约类型',
performance_detail	string	comment '履约明细',
tax_rate	string	comment '税率',
charge_off_rate_amount	string	comment '本次冲销含税金额',
contract_performance_id	string	comment '订单/合同履约义务id',
charge_off_amount	string	comment '本次冲销不含税金额',
income_rate_amount	string	comment '本次验收含税总金额',
charge_off_type	string	comment '收入冲销类型（审计冲销、其他冲销）'  
)
COMMENT '收入确认金额表'
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


-- -- 
-- insert overwrite table dm_gis_uimp.dws_bill_income_performance_detail 
-- select 
-- id,t0.income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,
-- staff_name,business_type,customer_name,contract_sign_scene,company_contract_code,order_code,ecp_contract_code,
-- company_code,has_collection_right,has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,
-- accept_count,hardware_count,service_begin_date,service_end_date,share_month,share_rate_amount,project_phase,
-- project_phase_progress,project_complete_date,project_phase_amount,income_node,confirm_status,performance_id,
-- service_rate_amount/100  as rate_amount,
-- service_amount/100 as amount,
-- order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
-- contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type 
-- from ( select * from dm_gis_uimp.ods_bill_income_confirm where income_node='XgeoVyp48' ) as t0 
-- left join ( select income_number,service_rate_amount,service_amount from dm_gis_uimp.ods_bill_service_share ) as t1 
-- on t0.income_number=t1.income_number 
-- union all 
-- select 
-- t0.id,income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,
-- staff_name,business_type,customer_name,contract_sign_scene,company_contract_code,order_code,ecp_contract_code,
-- company_code,has_collection_right,has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,
-- accept_count,hardware_count,service_begin_date,service_end_date,share_month,share_rate_amount,project_phase,
-- project_phase_progress,project_complete_date,project_phase_amount,income_node,confirm_status,performance_id,
-- current_rate_amount/100 as rate_amount,
-- current_amount/100 as amount,
-- order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
-- contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type 
-- from ( select * from dm_gis_uimp.ods_bill_income_confirm where income_node!='XgeoVyp48' ) as t0 
-- left join ( select id,current_rate_amount,current_amount from dm_gis_uimp.ods_bill_performance_duty ) as t1 
-- on t0.performance_id=t1.id 
-- ;

-- 
insert overwrite table dm_gis_uimp.dws_bill_income_performance_detail 
select 
id,income_number,enter_account_date,cheack_status,order_number,order_date,accept_date,create_by,staff_num,
staff_name,business_type,customer_name,contract_sign_scene,company_contract_code,order_code,ecp_contract_code,
company_code,has_collection_right,has_bkb_customer,order_status,settlement_currency,contract_amount,hardware_host_num,
accept_count,hardware_count,service_begin_date,service_end_date,share_month,share_rate_amount,project_phase,
project_phase_progress,project_complete_date,project_phase_amount,income_node,confirm_status,performance_id,
if(order_type='1',income_rate_amount*(-1),income_rate_amount) as rate_amount,
if(order_type='1',income_rate_amount*(-1)/(1+tax_rate),income_rate_amount/(1+tax_rate)) as amount,
order_type,adjust_number,supplement_contract_code,performance_type,performance_detail,tax_rate,charge_off_rate_amount,
contract_performance_id,charge_off_amount,income_rate_amount,charge_off_type 
from dm_gis_uimp.ods_bill_income_confirm 
;





-- 2023.10.23  ft_emp_out  (丰图外包人员,每月1号生成快照)  
create table dm_gis_uimp.dwd_ft_emp_out_month(
tenant_id string,
data_status string,
create_by string,
create_name string,
update_by string,
update_name string,
document_type string,
domain_account string,
emp_num string,
emp_type string,
english_name string,
entry_date string,
fs_permission string,
identification_number string,
landline string,
work_place string,
termination_date string,
superior_no string,
superior_name string,
source_emp_num string,
sf_mailbox_permission string,
sf_mailbox_name string,
sex string,
post_flag string,
position_name_tw string,
position_name_en string,
position_name_cn string,
position_level_name string,
position_level string,
position_id string,
position_attribute string,
network_meeting_permission string,
mailbox string,
org_id_out string,
org_id_in string,
org_name string,
phone_number string,
name string,
org_code string,
sf_mailbox_address string,
country_code string,
create_time string,
update_time string,
cost string,
category string
)
COMMENT '丰图外包人员-主表（每月1号快照表）'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

insert overwrite table dm_gis_uimp.dwd_ft_emp_out_month partition(inc_day='')
select 
tenant_id,data_status,create_by,create_name,update_by,update_name,document_type,domain_account,emp_num,emp_type,english_name,entry_date,fs_permission,
identification_number,landline,work_place,termination_date,superior_no,superior_name,source_emp_num,sf_mailbox_permission,sf_mailbox_name,sex,post_flag,
position_name_tw,position_name_en,position_name_cn,position_level_name,position_level,position_id,position_attribute,network_meeting_permission,mailbox,
org_id_out,org_id_in,org_name,phone_number,name,org_code,sf_mailbox_address,country_code,create_time,update_time,cost,category 
from dm_gis_uimp.ods_ft_emp_out 
;


-- 2023.11.21   (人员主表,每月1号生成快照)
-- issp_emp_data 人员主表-通用字段
create table dm_gis_uimp.dwd_issp_emp_data_month(
emp_num string ,
emp_name string ,
emp_source string ,
emp_type string ,
job_id string ,
job_name string ,
position_id string ,
position_name string ,
org_id string ,
org_code string ,
org_name string ,
sex string ,
age string ,
phone_num string ,
net_code string ,
natio string ,
email string ,
position_attr string ,
supervisor_number string ,
supervisor_name string ,
hire_date string ,
ssqy_code string ,
ssqy_txt string ,
update_time string ,
first_name string ,
office_phone string ,
source_type string ,
tenant_id string 
)
COMMENT '人员主表-通用字段（每月1号快照表）'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

insert overwrite table dm_gis_uimp.dwd_issp_emp_data_month partition(inc_day='')
select 
emp_num,emp_name,emp_source,emp_type,job_id,job_name,position_id,position_name,org_id,org_code,org_name,
sex,age,phone_num,net_code,natio,email,position_attr,supervisor_number,supervisor_name,hire_date,ssqy_code,ssqy_txt,
update_time,first_name,office_phone,source_type,tenant_id 
from dm_gis_uimp.ods_issp_emp_data 
;

-- issp_emp_data_ext 人员主表-非通用字段
create table dm_gis_uimp.dwd_issp_emp_data_ext_month(
emp_num string,
emp_id string,
birthday string,
leave_date string,
job_change_date string,
leave_reason string,
create_by string,
create_time string,
area string,
education string,
effect_date string,
hukou_type string,
hukou string,
height string,
weight string,
supplier_id string,
supplier_name string,
contract_id string,
grad_time string,
card_type string,
contacts string,
contacts_phone string,
driving_type string,
is_employer string,
bus_mode string,
import_time string,
gc_area_code string,
gc_area_net_code string,
is_sf_to_comp string,
register_date_time string,
out_date_time string,
remark string,
updator string,
auditing_date string,
mount_guard_date string,
out_type string,
out_sort string,
is_install_fs string,
is_gps_clock string,
sap_account string,
gc_area_id string,
sap_org_id string,
net_change_date string,
is_long_period string,
mandt string,
serno string,
abkrs string,
abkrs_txt string,
address string,
ass_category string,
ass_reason string,
blood_type string,
btrtl string,
btrtl_txt string,
bukrs string,
bukrs_txt string,
channel_name string,
cn_race string,
date_from string,
emp_cate_code string,
fkber string,
fkber_txt string,
is_odo_cj string,
is_odo_mj string,
job_date_from string,
kostl string,
kostl_txt string,
last_org_name string,
last_zno string,
marital_status string,
office_addr string,
old_last_name string,
pcn_pcode string,
pcn_pcode_txt string,
persg string,
persg_txt string,
persk string,
persk_txt string,
person_type string,
position_group string,
position_type string,
postal_code string,
probation_end_date string,
recruit_channel string,
sf_date string,
speciality string,
stell string,
stell_txt string,
vacation_start_date string,
werks string,
werks_txt string,
zhrzgzt string,
zhrzgzt_txt string,
zhrzzqc string,
zhrlzlx string,
position_ass_date string,
zhrzjdsj string,
mstbr string,
identifier string,
bank string,
banka string,
bankn string,
update_time string,
grpvl string,
icnum_a string,
ictyp string,
ictyp_a string,
molga string,
orgeh_lv1 string,
orgtx_lv1 string,
useto string,
zhrgzd string,
zhrgzd_up string,
zhrgzdmc string,
zhrgzdmc_up string,
zhrjfgs string,
zhrjfgsmc string,
zhrjrhmdlx string,
zhrldhtqsrq string,
zhrldhtzzrq string,
zhrrllx string,
zhrrllx_t string,
zhrsrrq string,
cancel_flag string,
supplier_attr string,
issuing_organization string,
bussiness_type string,
bussiness_area string,
frdevic_invalid_time string,
operat_area string,
ris_status string,
valid_date string,
duty_num string,
is_sfmail string,
is_internet string,
is_insf string,
area_short string,
area_objid string,
major_code string,
is_pub_acc string,
zhrtkcm string,
zhrgycm string,
zhrgkcm string,
zhrjob_p string,
zhrjob_pname string,
stell_p string,
stell_ptxt string,
zhrxw string,
zhrtw string,
zhrxm string,
zhryw string,
banka_fund string,
bankn_fund string,
banka_fee string,
bankn_fee string,
ssfid string,
personal_phone string,
zhrsfbcz string,
zhrsfgf string,
is_in_ad string,
banks string,
emftx string,
bankcode string,
zhrxzxm string
)
COMMENT '人员主表-非通用字段（每月1号快照表）'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


insert overwrite table dm_gis_uimp.dwd_issp_emp_data_ext_month partition(inc_day='')
select 
emp_num,emp_id,birthday,leave_date,job_change_date,leave_reason,create_by,create_time,area,education,effect_date,hukou_type,hukou,height,weight,supplier_id,supplier_name,contract_id,grad_time,card_type,contacts,contacts_phone,driving_type,is_employer,
bus_mode,import_time,gc_area_code,gc_area_net_code,is_sf_to_comp,register_date_time,out_date_time,remark,updator,auditing_date,mount_guard_date,out_type,out_sort,is_install_fs,is_gps_clock,sap_account,gc_area_id,sap_org_id,net_change_date,is_long_period,
mandt,serno,abkrs,abkrs_txt,address,ass_category,ass_reason,blood_type,btrtl,btrtl_txt,bukrs,bukrs_txt,channel_name,cn_race,date_from,emp_cate_code,fkber,fkber_txt,is_odo_cj,is_odo_mj,job_date_from,kostl,kostl_txt,last_org_name,last_zno,marital_status,office_addr,
old_last_name,pcn_pcode,pcn_pcode_txt,persg,persg_txt,persk,persk_txt,person_type,position_group,position_type,postal_code,probation_end_date,recruit_channel,sf_date,speciality,stell,stell_txt,vacation_start_date,werks,werks_txt,zhrzgzt,zhrzgzt_txt,zhrzzqc,zhrlzlx,
position_ass_date,zhrzjdsj,mstbr,identifier,bank,banka,bankn,update_time,grpvl,icnum_a,ictyp,ictyp_a,molga,orgeh_lv1,orgtx_lv1,useto,zhrgzd,zhrgzd_up,zhrgzdmc,zhrgzdmc_up,zhrjfgs,zhrjfgsmc,zhrjrhmdlx,zhrldhtqsrq,zhrldhtzzrq,zhrrllx,zhrrllx_t,zhrsrrq,cancel_flag,supplier_attr,
issuing_organization,bussiness_type,bussiness_area,frdevic_invalid_time,operat_area,ris_status,valid_date,duty_num,is_sfmail,is_internet,is_insf,area_short,area_objid,major_code,is_pub_acc,zhrtkcm,zhrgycm,zhrgkcm,zhrjob_p,zhrjob_pname,stell_p,stell_ptxt,zhrxw,zhrtw,zhrxm,zhryw,
banka_fund,bankn_fund,banka_fee,bankn_fee,ssfid,personal_phone,zhrsfbcz,zhrsfgf,is_in_ad,banks,emftx,bankcode,zhrxzxm 
from dm_gis_uimp.ods_issp_emp_data_ext 
;