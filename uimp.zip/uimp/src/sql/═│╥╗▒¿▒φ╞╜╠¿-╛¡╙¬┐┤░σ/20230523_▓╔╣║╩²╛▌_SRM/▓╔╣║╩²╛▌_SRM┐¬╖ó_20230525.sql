
-- 
-- 
-- 需求方：林中莉(01423677)
-- 需求： 1803744 林中莉(01423677) 创建于 2023-05-23 09:54:36 GIS-ISSP-CORE：【经营看板专项】寻源协同信息表_V1.0
-- @author 张小琼 （01416344）
-- Created on 2023-05-25
-- 任务信息： 任务ID：731751 采购数据_先写到ods再开发dwd	
-- 

-- kafka 到 hive 在“采购数据_0424.sql”已经处理

-- 寻源协同头信息表
-- 根据【询价基础信息：PurchaseEnquiryHead、招标基础信息：PurchaseBiddingHead、竞价基础信息：PurchaseEbiddingHead】解析生成寻源协同头信息表。
-- PurchaseEnquiryHead里的enquiry_number
-- PurchaseBiddingHead里的bidding_number
-- PurchaseEbiddingHead里的ebidding_number
create table dm_gis_uimp.dwd_purchase_srm_head (
n_number  string comment '单号',
purchase_type	string comment '采购类型',
special_purchase_type	string comment '特殊采购类型',
update_time	string comment '更新时间'
)
COMMENT '采购数据_SRM寻源协同头信息表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;

-- 
insert overwrite table dm_gis_uimp.dwd_purchase_srm_head partition(inc_day='$firstDay')  
select n_number,purchase_type,special_purchase_type,update_time 
from (
select get_json_object(ss.col,'$.enquiry_number') as n_number,
get_json_object(ss.col,'$.purchase_type') as purchase_type,
get_json_object(ss.col,'$.special_purchase_type') as special_purchase_type,
get_json_object(ss.col,'$.update_time') as update_time
from (select 
split(regexp_replace(regexp_extract(content,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis_uimp.ods_kafka_PurchaseEnquiryHead where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
union all 
select get_json_object(ss.col,'$.bidding_number') as n_number,
get_json_object(ss.col,'$.purchase_type') as purchase_type,
get_json_object(ss.col,'$.special_purchase_type') as special_purchase_type,
get_json_object(ss.col,'$.update_time') as update_time
from (select 
split(regexp_replace(regexp_extract(content,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis_uimp.ods_kafka_PurchaseBiddingHead where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
union all 
select get_json_object(ss.col,'$.ebidding_number') as n_number,
get_json_object(ss.col,'$.purchase_type') as purchase_type,
get_json_object(ss.col,'$.special_purchase_type') as special_purchase_type,
get_json_object(ss.col,'$.update_time') as update_time
from (select 
split(regexp_replace(regexp_extract(content,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis_uimp.ods_kafka_PurchaseEbiddingHead where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
) as t
;


-- 寻源协同行信息表
-- 根据【询价行信息：PurchaseEnquiryItem、招标行信息：PurchaseBiddingItem、竞价行信息：PurchaseEbiddingItem】解析生成寻源协同行信息表。
create table dm_gis_uimp.dwd_purchase_srm_item (
n_number	string comment '单号',
item_number	string comment '行序号',
item_status	string comment '行状态',
supplier_name	string comment '供应商名称',
supplier_code	string comment 'SAP供应商编码',
cate_code	string comment '品类',
cate_name	string comment '品类名称',
fbk_amount	string comment '市场寻源金额',
material_number	string comment '物料编码',
material_name	string comment '物料名称',
purchase_unit	string comment '采购单位',
ga_code	string comment 'PU154编码',
budget_amount	string comment 'PU154预算金额',
demand_project_number	string comment '项目编码',
demand_project_name	string comment '项目名称',
tax_rate	string comment '税率',
fbk9	string comment '付款条件',
require_quantity	string comment '需求数量',
source_number	string comment '来源单号',
price	string comment '含税单价',
tax_amount	string comment '含税总额',
net_price	string comment '未税单价',
net_amount	string comment '未税总额',
pre_unit_price	string comment '含税预算单价',
ctc_contract_code	string comment 'ctc合同编码',
ctc_contract_name	string comment 'ctc合同名称',
ctc_contract_start_time	string comment 'ctc合同开始时间',
ctc_contract_end_time	string comment 'ctc合同结束时间',
ctc_contract_amount	string comment 'ctc合同金额',
update_time	string comment '更新时间' 
)
COMMENT '采购数据_SRM寻源协同行信息表'
PARTITIONED BY (`inc_day` string)
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 
insert overwrite table dm_gis_uimp.dwd_purchase_srm_item partition(inc_day='$firstDay')  
select 
n_number,item_number,item_status,supplier_name,supplier_code,cate_code,cate_name,fbk_amount,material_number,
material_name,purchase_unit,ga_code,budget_amount,demand_project_number,demand_project_name,tax_rate,fbk9,require_quantity,
source_number,price,tax_amount,net_price,net_amount,pre_unit_price,ctc_contract_code,ctc_contract_name,ctc_contract_start_time,ctc_contract_end_time,ctc_contract_amount,update_time 
from (
select get_json_object(ss.col,'$.enquiry_number') as n_number,
get_json_object(ss.col,'$.item_number') as item_number,
get_json_object(ss.col,'$.item_status') as item_status,
get_json_object(ss.col,'$.supplier_name') as supplier_name,
get_json_object(ss.col,'$.supplier_code') as supplier_code,
get_json_object(ss.col,'$.cate_code') as cate_code,
get_json_object(ss.col,'$.cate_name') as cate_name,
get_json_object(ss.col,'$.fbk5') as fbk_amount,
get_json_object(ss.col,'$.material_number') as material_number,
get_json_object(ss.col,'$.material_name') as material_name,
get_json_object(ss.col,'$.purchase_unit') as purchase_unit,
get_json_object(ss.col,'$.ga_code') as ga_code,
get_json_object(ss.col,'$.budget_amount') as budget_amount,
get_json_object(ss.col,'$.demand_project_number') as demand_project_number,
get_json_object(ss.col,'$.demand_project_name') as demand_project_name,
get_json_object(ss.col,'$.tax_rate') as tax_rate,
get_json_object(ss.col,'$.fbk9') as fbk9,
get_json_object(ss.col,'$.require_quantity') as require_quantity,
get_json_object(ss.col,'$.source_number') as source_number,
get_json_object(ss.col,'$.price') as price,
get_json_object(ss.col,'$.tax_amount') as tax_amount,
get_json_object(ss.col,'$.net_price') as net_price,
get_json_object(ss.col,'$.net_amount') as net_amount,
get_json_object(ss.col,'$.pre_unit_price') as pre_unit_price,
get_json_object(ss.col,'$.ctc_contract_code') as ctc_contract_code,
get_json_object(ss.col,'$.ctc_contract_name') as ctc_contract_name,
get_json_object(ss.col,'$.ctc_contract_start_time') as ctc_contract_start_time,
get_json_object(ss.col,'$.ctc_contract_end_time') as ctc_contract_end_time,
get_json_object(ss.col,'$.ctc_contract_amount') as ctc_contract_amount,
get_json_object(ss.col,'$.update_time') as update_time 
from (select 
split(regexp_replace(regexp_extract(content,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis_uimp.ods_kafka_PurchaseEnquiryItem where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
union all 
select get_json_object(ss.col,'$.bidding_number') as n_number,
get_json_object(ss.col,'$.item_number') as item_number,
get_json_object(ss.col,'$.item_status') as item_status,
get_json_object(ss.col,'$.supplier_name') as supplier_name,
get_json_object(ss.col,'$.supplier_code') as supplier_code,
get_json_object(ss.col,'$.cate_code') as cate_code,
get_json_object(ss.col,'$.cate_name') as cate_name,
get_json_object(ss.col,'$.fbk6') as fbk_amount,
get_json_object(ss.col,'$.material_number') as material_number,
get_json_object(ss.col,'$.material_name') as material_name,
get_json_object(ss.col,'$.purchase_unit') as purchase_unit,
get_json_object(ss.col,'$.ga_code') as ga_code,
get_json_object(ss.col,'$.budget_amount') as budget_amount,
get_json_object(ss.col,'$.demand_project_number') as demand_project_number,
get_json_object(ss.col,'$.demand_project_name') as demand_project_name,
get_json_object(ss.col,'$.tax_rate') as tax_rate,
get_json_object(ss.col,'$.fbk9') as fbk9,
get_json_object(ss.col,'$.require_quantity') as require_quantity,
get_json_object(ss.col,'$.source_number') as source_number,
get_json_object(ss.col,'$.price') as price,
get_json_object(ss.col,'$.tax_amount') as tax_amount,
get_json_object(ss.col,'$.net_price') as net_price,
get_json_object(ss.col,'$.net_amount') as net_amount,
get_json_object(ss.col,'$.pre_unit_price') as pre_unit_price,
get_json_object(ss.col,'$.ctc_contract_code') as ctc_contract_code,
get_json_object(ss.col,'$.ctc_contract_name') as ctc_contract_name,
get_json_object(ss.col,'$.ctc_contract_start_time') as ctc_contract_start_time,
get_json_object(ss.col,'$.ctc_contract_end_time') as ctc_contract_end_time,
get_json_object(ss.col,'$.ctc_contract_amount') as ctc_contract_amount,
get_json_object(ss.col,'$.update_time') as update_time 
from (select 
split(regexp_replace(regexp_extract(content,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis_uimp.ods_kafka_PurchaseBiddingItem where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
union all 
select get_json_object(ss.col,'$.ebidding_number') as n_number,
get_json_object(ss.col,'$.item_number') as item_number,
get_json_object(ss.col,'$.item_status') as item_status,
get_json_object(ss.col,'$.supplier_name') as supplier_name,
get_json_object(ss.col,'$.supplier_code') as supplier_code,
get_json_object(ss.col,'$.cate_code') as cate_code,
get_json_object(ss.col,'$.cate_name') as cate_name,
get_json_object(ss.col,'$.fbk5') as fbk_amount,
get_json_object(ss.col,'$.material_number') as material_number,
get_json_object(ss.col,'$.material_name') as material_name,
get_json_object(ss.col,'$.purchase_unit') as purchase_unit,
get_json_object(ss.col,'$.ga_code') as ga_code,
get_json_object(ss.col,'$.budget_amount') as budget_amount,
get_json_object(ss.col,'$.demand_project_number') as demand_project_number,
get_json_object(ss.col,'$.demand_project_name') as demand_project_name,
get_json_object(ss.col,'$.tax_rate') as tax_rate,
get_json_object(ss.col,'$.fbk9') as fbk9,
get_json_object(ss.col,'$.require_quantity') as require_quantity,
get_json_object(ss.col,'$.source_number') as source_number,
get_json_object(ss.col,'$.price') as price,
get_json_object(ss.col,'$.tax_amount') as tax_amount,
get_json_object(ss.col,'$.net_price') as net_price,
get_json_object(ss.col,'$.net_amount') as net_amount,
get_json_object(ss.col,'$.pre_unit_price') as pre_unit_price,
get_json_object(ss.col,'$.ctc_contract_code') as ctc_contract_code,
get_json_object(ss.col,'$.ctc_contract_name') as ctc_contract_name,
get_json_object(ss.col,'$.ctc_contract_start_time') as ctc_contract_start_time,
get_json_object(ss.col,'$.ctc_contract_end_time') as ctc_contract_end_time,
get_json_object(ss.col,'$.ctc_contract_amount') as ctc_contract_amount,
get_json_object(ss.col,'$.update_time') as update_time 
from (select 
split(regexp_replace(regexp_extract(content,'^\\[(.+)\\]$',1),'\\}\\,\\{', '\\}\\|\\|\\{'),'\\|\\|') as dstr
from dm_gis_uimp.ods_kafka_PurchaseEbiddingItem where inc_day='$firstDay'  ) pp
lateral view explode(pp.dstr) ss as col 
) as t 
;