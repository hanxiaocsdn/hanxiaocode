-- 
-- 需求方：林中莉(01423677)
-- 需求： 用户需求id: 1938705  GIS-ISSP-CORE：【经营看板专项】商机明细表_数据侧_V1.1
-- @author 张小琼 （01416344）
-- Created on 2023-08-10
-- 任务信息： ID：786765  商机明细表(dm_dwd_crm_opp_dtl_di每月生成快照)
-- 

-- 商机明细表(每月生成快照)  采用数据模型建表
create table dm_gis_uimp.dm_dwd_crm_opp_dtl_di(
id string comment '_id',
last_modified_time string comment '最后修改时间',
contract_date__c string comment '合同实施日期',
close_date string comment '结单日期',
field_g773s__c string comment '纳入预测日期',
preimplement_date__c string comment '售前实施日期',
preinvest_date__c string comment '售前投入日期',
field_uk3cf__c string comment '预计签单时间',
sap_datbis__c string comment 'SAP项目结束时间',
sap_datab__c string comment 'SAP项目开始时间',
create_time string comment '创建时间',
stg_changed_time string comment '阶段变更时间',
field_jgrga__c string comment '预计签单金额（万元)',
field_1ft1d__c string comment '预计签单金额（元）',
field_gw12o__c string comment '预期规模（台）',
field_4fr3e__c string comment '产品方向（交通货运）',
field_wil66__c string comment '成本中心',
owner_department string comment '负责人主属部门',
field_m14t0__c string comment '工号',
field_0n284__c__r string comment '国家',
sales_status string comment '阶段状态',
field_bwv15__c string comment '客户合同签订方式',
account_id__r string comment '客户名称',
field_gwafr__c__r string comment '区',
field_kvx2b__c string comment '商机代码',
sales_stage string comment '商机阶段',
name string comment '商机名称',
life_status string comment '生命状态',
field_r5b9e__c__r string comment '省',
field_vnxdv__c__r string comment '市',
field_43dhc__c string comment '是否纳入预测',
field_cz768__c string comment '所属业务中心',
field_bgr8v__c string comment '所属营销中心',
field_qjotp__c string comment '项目运作方式',
record_type string comment '业务类型',
created_by__r_name string comment '创建人',
owner__r_name string comment '负责人',
field_ao14e__c__r_name string comment '解决方案负责人',
field_e5pbb__c__r_name string comment '业务中心负责人',
field_0EuIa__c string comment '行业',
field_0d6eG__c string comment '经营单元（签单）',
field_pA96Q__c  string comment '原因类别（沉默原因字段）',
field_FJobx__c  string comment '沉默前商机阶段',
field_n2cW1__c  string comment '项目累计提前投入成本（元）'  
)
comment '商机明细表(每月生成快照)' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

alter table dm_gis_uimp.dm_dwd_crm_opp_dtl_di add columns (field_pA96Q__c  string comment '原因类别（沉默原因字段）') cascade;
alter table dm_gis_uimp.dm_dwd_crm_opp_dtl_di add columns (field_FJobx__c  string comment '沉默前商机阶段') cascade;

-- 20230915 商机明细表_数据侧_V1.2  增加字段  $[time(yyyyMMdd,-0d)]
alter table dm_gis_uimp.dm_dwd_crm_opp_dtl_di add columns (field_n2cW1__c  string comment '项目累计提前投入成本（元）') cascade;

insert overwrite table dm_gis_uimp.dm_dwd_crm_opp_dtl_di partition(inc_day='$firtDay') 
select 
id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, create_time, stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, record_type, created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c      
from dm_gis_uimp.dwd_crm_opp_res 
;




-- 商机明细表(年表)  
create table dm_gis_uimp.dm_dwd_crm_opp_dtl_year(
id string comment '_id',
last_modified_time string comment '最后修改时间',
contract_date__c string comment '合同实施日期',
close_date string comment '结单日期',
field_g773s__c string comment '纳入预测日期',
preimplement_date__c string comment '售前实施日期',
preinvest_date__c string comment '售前投入日期',
field_uk3cf__c string comment '预计签单时间',
sap_datbis__c string comment 'SAP项目结束时间',
sap_datab__c string comment 'SAP项目开始时间',
create_time string comment '创建时间',
stg_changed_time string comment '阶段变更时间',
field_jgrga__c string comment '预计签单金额（万元)',
field_1ft1d__c string comment '预计签单金额（元）',
field_gw12o__c string comment '预期规模（台）',
field_4fr3e__c string comment '产品方向（交通货运）',
field_wil66__c string comment '成本中心',
owner_department string comment '负责人主属部门',
field_m14t0__c string comment '工号',
field_0n284__c__r string comment '国家',
sales_status string comment '阶段状态',
field_bwv15__c string comment '客户合同签订方式',
account_id__r string comment '客户名称',
field_gwafr__c__r string comment '区',
field_kvx2b__c string comment '商机代码',
sales_stage string comment '商机阶段',
name string comment '商机名称',
life_status string comment '生命状态',
field_r5b9e__c__r string comment '省',
field_vnxdv__c__r string comment '市',
field_43dhc__c string comment '是否纳入预测',
field_cz768__c string comment '所属业务中心',
field_bgr8v__c string comment '所属营销中心',
field_qjotp__c string comment '项目运作方式',
record_type string comment '业务类型',
created_by__r_name string comment '创建人',
owner__r_name string comment '负责人',
field_ao14e__c__r_name string comment '解决方案负责人',
field_e5pbb__c__r_name string comment '业务中心负责人',
field_0EuIa__c string comment '行业',
field_0d6eG__c string comment '经营单元（签单）' ,
field_pA96Q__c  string comment '原因类别（沉默原因字段）',
field_FJobx__c  string comment '沉默前商机阶段',
field_n2cW1__c  string comment '项目累计提前投入成本（元）' ,
manual_update_time string comment '线下手动更新时间' ,
year_initialvalue string  comment '期初值年份',
version_no_initialvalue string  comment '期初值版本' 
)
comment '商机明细表(年表)' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 创建临时表并线下导入数据
create table dm_gis_uimp.tmp_csv_dm_dwd_crm_opp_dtl_year(
id string comment '_id',
last_modified_time string comment '最后修改时间',
contract_date__c string comment '合同实施日期',
close_date string comment '结单日期',
field_g773s__c string comment '纳入预测日期',
preimplement_date__c string comment '售前实施日期',
preinvest_date__c string comment '售前投入日期',
field_uk3cf__c string comment '预计签单时间',
sap_datbis__c string comment 'SAP项目结束时间',
sap_datab__c string comment 'SAP项目开始时间',
create_time string comment '创建时间',
stg_changed_time string comment '阶段变更时间',
field_jgrga__c string comment '预计签单金额（万元)',
field_1ft1d__c string comment '预计签单金额（元）',
field_gw12o__c string comment '预期规模（台）',
field_4fr3e__c string comment '产品方向（交通货运）',
field_wil66__c string comment '成本中心',
owner_department string comment '负责人主属部门',
field_m14t0__c string comment '工号',
field_0n284__c__r string comment '国家',
sales_status string comment '阶段状态',
field_bwv15__c string comment '客户合同签订方式',
account_id__r string comment '客户名称',
field_gwafr__c__r string comment '区',
field_kvx2b__c string comment '商机代码',
sales_stage string comment '商机阶段',
name string comment '商机名称',
life_status string comment '生命状态',
field_r5b9e__c__r string comment '省',
field_vnxdv__c__r string comment '市',
field_43dhc__c string comment '是否纳入预测',
field_cz768__c string comment '所属业务中心',
field_bgr8v__c string comment '所属营销中心',
field_qjotp__c string comment '项目运作方式',
record_type string comment '业务类型',
created_by__r_name string comment '创建人',
owner__r_name string comment '负责人',
field_ao14e__c__r_name string comment '解决方案负责人',
field_e5pbb__c__r_name string comment '业务中心负责人',
field_0EuIa__c string comment '行业',
field_0d6eG__c string comment '经营单元（签单）' ,
field_pA96Q__c  string comment '原因类别（沉默原因字段）',
field_FJobx__c  string comment '沉默前商机阶段',
field_n2cW1__c  string comment '项目累计提前投入成本（元）' ,
manual_update_time string comment '线下手动更新时间' ,
year_initialvalue string  comment '期初值年份',
version_no_initialvalue string  comment '期初值版本',
inc_day string COMMENT ''
)
comment '商机明细表(临时导数年表)' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/dm_dwd_crm_opp_dtl_di_2023年期初值_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.tmp_csv_dm_dwd_crm_opp_dtl_year;


-- 写入到dm_gis_uimp.dm_dwd_crm_opp_dtl_year
set hive.exec.dynamic.partition=true;
set hive.exec.dynamic.partition.mode=nonstrict;
insert overwrite table dm_gis_uimp.dm_dwd_crm_opp_dtl_year partition(inc_day)
select * from dm_gis_uimp.tmp_csv_dm_dwd_crm_opp_dtl_year;

-- 删除临时表
drop table dm_gis_uimp.tmp_csv_dm_dwd_crm_opp_dtl_year;
