-- 
-- 
-- 需求方： 林中莉(01423677)
-- 需求： 1827267  【经营看板专项】库存分析看板_V1.0_数据测
-- @author 张小琼 （01416344）
-- Created on 2023-06-05
-- 任务信息： ID：765557  库存分析看板
-- 

-- 线上数据源：
-- 存货收发存汇总表  dm_gis_uimp.dwc_purchase_inventory_receipt_delivery	T-1	存货收发存汇总表：1.根据inc_day，取每月1日的数据 2.“物料编码”字段不包含文本“合计”		
-- 期末库存维度余额调整 dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt 
-- 销售出库单 dm_gis_uimp.dwd_purchase_sales_outbound_orders	T-1	1.根据inc_day，取每周六的数据 2.“销售出库单创建时间”为本周的
-- 其他出库单 dm_gis_uimp.dwd_purchase_other_delivery_orders	T-1	1.根据inc_day，取每周六的数据 2.“其他出库单创建时间”为本周的

-- etl   hive2ck
-- 存货收发存汇总表 dm_gis_uimp.dwc_purchase_inventory_receipt_delivery
lastDay=`date -d "-1 day $firstDay" +%Y%m%d`

drop table if exists dm_gis_uimp.dwc_purchase_inventory_receipt_delivery_1;
create table dm_gis_uimp.dwc_purchase_inventory_receipt_delivery_1 stored as parquet as 
select 
if(query_time is not null,query_time,'') as query_time,
if(fmaterialname is not null,fmaterialname,'') as fmaterialname,
if(fmaterialgroup is not null,fmaterialgroup,'') as fmaterialgroup,
if(fmodel is not null,regexp_replace(fmodel,'\t',' '),'') as fmodel,
if(fstockstatusname is not null,fstockstatusname,'') as fstockstatusname,
if(fstockid is not null,fstockid,'') as fstockid,
if(facctgrangeid is not null,facctgrangeid,'') as facctgrangeid,
if(facctgrangename is not null,facctgrangename,'') as facctgrangename,
if(finitqty is not null,regexp_replace(finitqty,',',''),'') as finitqty,
if(finitprice is not null,regexp_replace(finitprice,',',''),'') as finitprice,
if(finitamount is not null,regexp_replace(finitamount,',',''),'') as finitamount,
if(freceiveqty is not null,regexp_replace(freceiveqty,',',''),'') as freceiveqty,
if(freceiveprice is not null,regexp_replace(freceiveprice,',',''),'') as freceiveprice,
if(freceiveamount is not null,regexp_replace(freceiveamount,',',''),'') as freceiveamount,
if(fsendqty is not null,regexp_replace(fsendqty,',',''),'') as fsendqty,
if(fsendprice is not null,regexp_replace(fsendprice,',',''),'') as fsendprice,
if(fsendamount is not null,regexp_replace(fsendamount,',',''),'') as fsendamount,
if(fendqty is not null,regexp_replace(fendqty,',',''),'') as fendqty,
if(fendprice is not null,regexp_replace(fendprice,',',''),'') as fendprice,
if(fendamount is not null,regexp_replace(fendamount,',',''),'') as fendamount,
if(fmaterialbaseid is not null,fmaterialbaseid,'') as fmaterialbaseid,
if(f_tthm_baseproperty is not null,f_tthm_baseproperty,'') as f_tthm_baseproperty,
if(fmaterproperty is not null,fmaterproperty,'') as fmaterproperty,
if(fmatertype is not null,fmatertype,'') as fmatertype,
if(flotno is not null,flotno,'') as flotno,
if(fassipropname is not null,fassipropname,'') as fassipropname,
if(fbomno is not null,fbomno,'') as fbomno,
if(fplanno is not null,fplanno,'') as fplanno,
if(fownername is not null,fownername,'') as fownername,
if(fstockorgname is not null,fstockorgname,'') as fstockorgname,
if(fstockplacename is not null,fstockplacename,'') as fstockplacename,
if(funitname is not null,funitname,'') as funitname,
inc_day 
from dm_gis_uimp.dwc_purchase_inventory_receipt_delivery 
where inc_day='$lastDay'
;


-- 非工作日维表
CREATE  TABLE `dm_gis_uimp.dim_not_work_day`(
d_date	string comment '日期,格式：yyyy-MM-dd',
is_workday	string comment '是否工作日[1:非工作日 0:工作日]'
)
COMMENT '非工作日维表'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;


LOAD DATA  INPATH '/user/01416344/upload/not_work_day_lab_20230605.csv' OVERWRITE INTO TABLE dm_gis_uimp.dim_not_work_day;

-- 期末库存维度余额调整 dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt
drop table if exists dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt_1;
create table dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt_1 stored as parquet as 
select 
if(querytime is not null,querytime,'') as querytime,
if(fmaterialid is not null,fmaterialid,'') as fmaterialid,
if(fmaterialname is not null,fmaterialname,'') as fmaterialname,
if(fmaterproperty is not null,fmaterproperty,'') as fmaterproperty,
if(fmatertype is not null,fmatertype,'') as fmatertype,
if(fmaterialgroup is not null,fmaterialgroup,'') as fmaterialgroup,
if(fmodel is not null,fmodel,'') as fmodel,
if(fstockstatus is not null,fstockstatus,'') as fstockstatus,
if(flot is not null,flot,'') as flot,
if(fauxprop is not null,fauxprop,'') as fauxprop,
if(fbom is not null,fbom,'') as fbom,
if(fmtono is not null,fmtono,'') as fmtono,
if(fowner is not null,fowner,'') as fowner,
if(fstockorg is not null,fstockorg,'') as fstockorg,
if(fstock is not null,fstock,'') as fstock,
if(fstockloc is not null,fstockloc,'') as fstockloc,
if(facctgrangeid is not null,facctgrangeid,'') as facctgrangeid,
if(facctgrangename is not null,facctgrangename,'') as facctgrangename,
if(funit is not null,funit,'') as funit,
if(fexpensenumber is not null,fexpensenumber,'') as fexpensenumber,
if(fexpensename is not null,fexpensename,'') as fexpensename,
if(fqty is not null,regexp_replace(fqty,',',''),'') as fqty,
if(fprice is not null,regexp_replace(fprice,',',''),'') as fprice,
if(famount is not null,regexp_replace(famount,',',''),'') as famount,
if(facctgdimeprice is not null,regexp_replace(facctgdimeprice,',',''),'') as facctgdimeprice,
if(facctgdimeamount is not null,regexp_replace(facctgdimeamount,',',''),'') as facctgdimeamount,
if(fdiffamount is not null,regexp_replace(fdiffamount,',',''),'') as fdiffamount,
if(fadjamount is not null,regexp_replace(fadjamount,',',''),'') as fadjamount,
if(fadjustbillno is not null,fadjustbillno,'') as fadjustbillno,
if(fadjustbillseq is not null,fadjustbillseq,'') as fadjustbillseq,
inc_day 
from dm_gis_uimp.dwc_purchase_hs_iniv_exception_balance_rpt  
where inc_day='$firstDay'
;





-- 准备发货时效
-- ①销售发货(仓库)、销售发货(供应商)
CREATE  TABLE dm_gis_uimp.dws_purchase_sales_shipment(
fbillno	string comment '单据编号',
fcreatedate	string comment '创建日期',
fhf_type	string comment '发货方类型',
ckfhsx	string comment '仓库发货时效(小时)',
gysfhsx	string comment '供应商发货时效(小时)' 
)
COMMENT '销售发货'
PARTITIONED BY (`inc_day` string comment '')
stored as parquet 
tblproperties ('parquet.compression'='snappy')
;


drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment;
create table dm_gis_uimp.tmp_purchase_sales_shipment stored as parquet as 
select 
fbillno,f_tthm_dnnumber,fcreatedate,fcreatedate1,t1.d_date as lab1,f_tthm_pushtoyjdf,f_tthm_datetime_fhtzd,f_tthm_datetime_fhtzd1,t2.d_date as lab2 
from (
select 
fbillno,f_tthm_dnnumber,
from_unixtime(unix_timestamp(substr(fcreatedate,1,19), 'yyyy-MM-dd\'\T\'HH:mm:ss')) as fcreatedate,
substr(fcreatedate,1,10) as fcreatedate1,
f_tthm_pushtoyjdf,
from_unixtime(unix_timestamp(substr(f_tthm_datetime_fhtzd,1,19), 'yyyy-MM-dd\'\T\'HH:mm:ss')) as f_tthm_datetime_fhtzd,
substr(f_tthm_datetime_fhtzd,1,10) as f_tthm_datetime_fhtzd1 
from 
dm_gis_uimp.dwd_purchase_sales_outbound_orders where inc_day='$firstDay' ) as t0 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.fcreatedate1=t1.d_date 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t2 
on t0.f_tthm_datetime_fhtzd1=t2.d_date 
;


drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_workday;
create table dm_gis_uimp.tmp_purchase_sales_shipment_workday stored as parquet as 
select start_date,end_date,pos,real_date,is_workday 
from (
select
  start_date,end_date,pos,date_add(start_date, pos) as real_date
FROM
  (
    select f_tthm_datetime_fhtzd1 as start_date,fcreatedate1 as end_date
    from dm_gis_uimp.tmp_purchase_sales_shipment
    group by f_tthm_datetime_fhtzd1,fcreatedate1
  ) tmp lateral view posexplode(split(space(datediff(end_date, start_date)), '')) t as pos,val
) as t0 
left join (select d_date,is_workday from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.real_date=t1.d_date 
;

drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_workday_1;
create table dm_gis_uimp.tmp_purchase_sales_shipment_workday_1 stored as parquet as 
select fbillno,f_tthm_dnnumber,fcreatedate,fcreatedate1,lab1,f_tthm_pushtoyjdf,f_tthm_datetime_fhtzd,f_tthm_datetime_fhtzd1,lab2,notworkdays 
from dm_gis_uimp.tmp_purchase_sales_shipment as t0 
left join (select start_date,end_date,sum(if(is_workday>0,is_workday,0)) as notworkdays from dm_gis_uimp.tmp_purchase_sales_shipment_workday group by start_date,end_date ) as t1 
on t0.f_tthm_datetime_fhtzd1=t1.start_date and t0.fcreatedate1=t1.end_date
;


---- gysfhsx	string comment '供应商发货时效(小时)'   (近6个月创建的收料通知单的) 供应商发货日期 - 发货通知单审核时间
-- 1、收料通知单 dwc_purchase_material_receipt_notice： fcreatedate、f_pyfd_text、f_tthm_date  （取fcreatedate近6个月的记录的f_tthm_date字段）
-- 2、销售出库单 dwd_purchase_sales_outbound_orders： fbillno、f_tthm_dnnumber、f_tthm_datetime_fhtzd
-- f_tthm_dnnumber被包含在f_pyfd_text中
drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber;
create table dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber as 
select fbillno,f_tthm_dnnumber,
f_pyfd_text,f_tthm_date 
from dm_gis_uimp.tmp_purchase_sales_shipment as t0 
left join (
select f_pyfd_text,from_unixtime(unix_timestamp(substr(f_tthm_date,1,19), 'yyyy-MM-dd\'\T\'HH:mm:ss')) as f_tthm_date from dm_gis_uimp.dwc_purchase_material_receipt_notice 
where inc_day>'20221101' and fcreatedate>=add_months(from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd'),-6) 
and f_pyfd_text is not null and trim(f_pyfd_text)<>''
) as t1 
on 1=1 
where trim(f_tthm_dnnumber)<>'' and locate(f_tthm_dnnumber,f_pyfd_text)>0 
;

drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_1;
create table dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_1 as 
select 
fbillno,f_tthm_dnnumber,f_tthm_date 
from (select fbillno,f_tthm_dnnumber,f_tthm_date,
row_number() over(partition by fbillno,f_tthm_dnnumber order by f_tthm_date asc)  as rn 
from dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber
) as t where t.rn=1
;



drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2;
create table dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2 stored as parquet as 
select 
fbillno,f_tthm_dnnumber,f_tthm_date,f_tthm_date1,t1.d_date as lab1,f_tthm_datetime_fhtzd,f_tthm_datetime_fhtzd1,t2.d_date as lab2 
from (
select t0.fbillno,t0.f_tthm_dnnumber,
f_tthm_date,substr(f_tthm_date,1,10) as f_tthm_date1,
f_tthm_datetime_fhtzd,f_tthm_datetime_fhtzd1  
 from dm_gis_uimp.tmp_purchase_sales_shipment  as t0
left join dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_1 as t1 
on t0.fbillno=t1.fbillno and t0.f_tthm_dnnumber=t1.f_tthm_dnnumber 
) as t0 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.f_tthm_date1=t1.d_date 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t2 
on t0.f_tthm_datetime_fhtzd1=t2.d_date 
;


drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2_workday;
create table dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2_workday stored as parquet as 
select start_date,end_date,pos,real_date,is_workday 
from (
select
  start_date,end_date,pos,date_add(start_date, pos) as real_date
FROM
  (
    select f_tthm_datetime_fhtzd1 as start_date,f_tthm_date1 as end_date
    from dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2
    group by f_tthm_datetime_fhtzd1,f_tthm_date1
  ) tmp lateral view posexplode(split(space(datediff(end_date, start_date)), '')) t as pos,val
) as t0 
left join (select d_date,is_workday from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.real_date=t1.d_date 
;

drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2_workday_1;
create table dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2_workday_1 stored as parquet as 
select fbillno,f_tthm_dnnumber,f_tthm_date,f_tthm_date1,lab1,f_tthm_datetime_fhtzd,f_tthm_datetime_fhtzd1,lab2,notworkdays 
from dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2 as t0 
left join (select start_date,end_date,sum(if(is_workday>0,is_workday,0)) as notworkdays from dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2_workday group by start_date,end_date ) as t1 
on t0.f_tthm_datetime_fhtzd1=t1.start_date and t0.f_tthm_date1=t1.end_date
;

drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_gysfhsx;
create table dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_gysfhsx stored as parquet as 
select fbillno,f_tthm_dnnumber,f_tthm_datetime_fhtzd,gysfhsx from (
select 
fbillno,f_tthm_dnnumber,f_tthm_datetime_fhtzd,
case when f_tthm_date>from_unixtime(unix_timestamp('$firstDay','yyyyMMdd'),'yyyy-MM-dd') then null 
when f_tthm_datetime_fhtzd is not null and (lab1 is null and lab2 is null) then (hour(f_tthm_date)-hour(f_tthm_datetime_fhtzd)+(datediff(f_tthm_date, f_tthm_datetime_fhtzd)-notworkdays)*24) 
when f_tthm_datetime_fhtzd is not null and (lab1 is not null and lab2 is null) then (hour(f_tthm_date)-hour(f_tthm_datetime_fhtzd)+(datediff(f_tthm_date, f_tthm_datetime_fhtzd)-notworkdays+1)*24) 
when f_tthm_datetime_fhtzd is not null and (lab1 is null and lab2 is not null) then (hour(f_tthm_date)-hour(f_tthm_datetime_fhtzd)+(datediff(f_tthm_date, f_tthm_datetime_fhtzd)-notworkdays+1)*24) 
when f_tthm_datetime_fhtzd is not null and (lab1 is not null and lab2 is not null and f_tthm_date1=f_tthm_datetime_fhtzd1) then (hour(f_tthm_date)-hour(f_tthm_datetime_fhtzd)+(datediff(f_tthm_date, f_tthm_datetime_fhtzd)-notworkdays+1)*24)
when f_tthm_datetime_fhtzd is not null and (lab1 is not null and lab2 is not null and f_tthm_date1<>f_tthm_datetime_fhtzd1) then (hour(f_tthm_date)-hour(f_tthm_datetime_fhtzd)+(datediff(f_tthm_date, f_tthm_datetime_fhtzd)-notworkdays+2)*24)
else null end as  gysfhsx 
from (
select fbillno,f_tthm_dnnumber,f_tthm_date,f_tthm_date1,lab1,f_tthm_datetime_fhtzd,f_tthm_datetime_fhtzd1,lab2,
if(notworkdays is not null,notworkdays,0) as  notworkdays 
from dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_2_workday_1
) as t 
) as tt 
group by fbillno,f_tthm_dnnumber,f_tthm_datetime_fhtzd,gysfhsx 
;




drop table if exists dm_gis_uimp.tmp_purchase_sales_shipment_res;
create table dm_gis_uimp.tmp_purchase_sales_shipment_res stored as parquet as 
select 
fbillno,
fcreatedate,
fhf_type,
if(ckfhsx<0,0,ckfhsx) as ckfhsx,
if(gysfhsx<0,0,gysfhsx) as gysfhsx  
from (
select 
fbillno,
fcreatedate,
if(f_tthm_pushtoyjdf not in ('false','False','FALSE'),'仓库发货','供应商发货') as fhf_type,
case when f_tthm_datetime_fhtzd is not null and (lab1 is null and lab2 is null) then (hour(fcreatedate)-hour(f_tthm_datetime_fhtzd)+(datediff(fcreatedate, f_tthm_datetime_fhtzd)-notworkdays)*24) 
when f_tthm_datetime_fhtzd is not null and (lab1 is not null and lab2 is null) then (hour(fcreatedate)-hour(f_tthm_datetime_fhtzd)+(datediff(fcreatedate, f_tthm_datetime_fhtzd)-notworkdays+1)*24) 
when f_tthm_datetime_fhtzd is not null and (lab1 is null and lab2 is not null) then (hour(fcreatedate)-hour(f_tthm_datetime_fhtzd)+(datediff(fcreatedate, f_tthm_datetime_fhtzd)-notworkdays+1)*24) 
when f_tthm_datetime_fhtzd is not null and (lab1 is not null and lab2 is not null and fcreatedate1=f_tthm_datetime_fhtzd1) then (hour(fcreatedate)-hour(f_tthm_datetime_fhtzd)+(datediff(fcreatedate, f_tthm_datetime_fhtzd)-notworkdays+1)*24) 
when f_tthm_datetime_fhtzd is not null and (lab1 is not null and lab2 is not null and fcreatedate1<>f_tthm_datetime_fhtzd1) then (hour(fcreatedate)-hour(f_tthm_datetime_fhtzd)+(datediff(fcreatedate, f_tthm_datetime_fhtzd)-notworkdays+2)*24) 
else null end as  ckfhsx,
gysfhsx
from (
select t0.fbillno,t0.fcreatedate,t0.fcreatedate1,t0.lab1,t0.f_tthm_pushtoyjdf,t0.f_tthm_datetime_fhtzd,t0.f_tthm_datetime_fhtzd1,t0.lab2,notworkdays,
t1.gysfhsx  
from (select fbillno,f_tthm_dnnumber,fcreatedate,fcreatedate1,lab1,f_tthm_pushtoyjdf,f_tthm_datetime_fhtzd,f_tthm_datetime_fhtzd1,lab2,
if(notworkdays is not null,notworkdays,0) as  notworkdays 
from dm_gis_uimp.tmp_purchase_sales_shipment_workday_1) as t0 
left join dm_gis_uimp.tmp_purchase_sales_shipment_dnnumber_gysfhsx as t1 
on t0.fbillno=t1.fbillno and t0.f_tthm_dnnumber=t1.f_tthm_dnnumber and t0.f_tthm_datetime_fhtzd=t1.f_tthm_datetime_fhtzd 
) as tt 
) as ttt 
;


insert overwrite table dm_gis_uimp.dws_purchase_sales_shipment partition(inc_day='$firstDay') 
select fbillno,fcreatedate,fhf_type,ckfhsx,gysfhsx from (
select fbillno,fcreatedate,fhf_type,ckfhsx,gysfhsx,row_number() over(partition by fbillno order by fcreatedate desc) as  rn   
from dm_gis_uimp.tmp_purchase_sales_shipment_res 
) as t where t.rn=1
;




-- ②售后运维
CREATE  TABLE dm_gis_uimp.dws_purchase_after_sales_maintenance(
fbillno	string comment '单据编号',
fcreatedate	string comment '创建日期',
fhf_type	string comment '发货方类型',
ckfhsx	string comment '仓库发货时效(小时)' 
)
COMMENT '售后运维'
PARTITIONED BY (`inc_day` string comment '')
stored as parquet 
tblproperties ('parquet.compression'='snappy')
;



drop table if exists dm_gis_uimp.tmp_purchase_after_sales_maintenance;
create table dm_gis_uimp.tmp_purchase_after_sales_maintenance stored as parquet as 
select 
fbillno,fstockid,fcreatedate,fcreatedate1,t1.d_date as lab1,f_tthm_pushtoyjdf,f_tthm_datetime_cksqdtime,f_tthm_datetime_cksqdtime1,t2.d_date as lab2 
from (
select 
fbillno,fstockid,
from_unixtime(unix_timestamp(substr(fcreatedate,1,19), 'yyyy-MM-dd\'\T\'HH:mm:ss')) as fcreatedate,
substr(fcreatedate,1,10) as fcreatedate1,
f_tthm_pushtoyjdf,
from_unixtime(unix_timestamp(substr(f_tthm_datetime_cksqdtime,1,19), 'yyyy-MM-dd\'\T\'HH:mm:ss')) as f_tthm_datetime_cksqdtime,
substr(f_tthm_datetime_cksqdtime,1,10) as f_tthm_datetime_cksqdtime1 
from 
dm_gis_uimp.dwd_purchase_other_delivery_orders where inc_day='$firstDay' and f_tthm_pushtoyjdf in ('TRUE','true','True') ) as t0 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.fcreatedate1=t1.d_date 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t2 
on t0.f_tthm_datetime_cksqdtime1=t2.d_date 
;


drop table if exists dm_gis_uimp.tmp_purchase_after_sales_maintenance_workday;
create table dm_gis_uimp.tmp_purchase_after_sales_maintenance_workday stored as parquet as 
select start_date,end_date,pos,real_date,is_workday 
from (
select
  start_date,end_date,pos,date_add(start_date, pos) as real_date
FROM
  (
    select f_tthm_datetime_cksqdtime1 as start_date,fcreatedate1 as end_date
    from dm_gis_uimp.tmp_purchase_after_sales_maintenance 
    group by f_tthm_datetime_cksqdtime1,fcreatedate1
  ) tmp lateral view posexplode(split(space(datediff(end_date, start_date)), '')) t as pos,val
) as t0 
left join (select d_date,is_workday from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.real_date=t1.d_date 
;


drop table if exists dm_gis_uimp.tmp_purchase_after_sales_maintenance_workday_1;
create table dm_gis_uimp.tmp_purchase_after_sales_maintenance_workday_1 stored as parquet as 
select fbillno,fstockid,fcreatedate,fcreatedate1,lab1,f_tthm_pushtoyjdf,f_tthm_datetime_cksqdtime,f_tthm_datetime_cksqdtime1,lab2,notworkdays 
from dm_gis_uimp.tmp_purchase_after_sales_maintenance as t0 
left join (select start_date,end_date,sum(if(is_workday>0,is_workday,0)) as notworkdays from dm_gis_uimp.tmp_purchase_after_sales_maintenance_workday group by start_date,end_date ) as t1 
on t0.f_tthm_datetime_cksqdtime1=t1.start_date and t0.fcreatedate1=t1.end_date
;




drop table if exists dm_gis_uimp.tmp_purchase_after_sales_maintenance_res;
create table dm_gis_uimp.tmp_purchase_after_sales_maintenance_res stored as parquet as 
select 
fbillno,
fcreatedate,
fhf_type,
if(ckfhsx<0,0,ckfhsx) as ckfhsx  
from (
select 
fbillno,
fcreatedate,
if(fstockid in ('277874','277875'),'武汉发货','深圳发货') as fhf_type,
case when f_tthm_datetime_cksqdtime is not null and (lab1 is null and lab2 is null) then (hour(fcreatedate)-hour(f_tthm_datetime_cksqdtime)+(datediff(fcreatedate, f_tthm_datetime_cksqdtime)-notworkdays)*24) 
when f_tthm_datetime_cksqdtime is not null and (lab1 is not null and lab2 is null) then (hour(fcreatedate)-hour(f_tthm_datetime_cksqdtime)+(datediff(fcreatedate, f_tthm_datetime_cksqdtime)-notworkdays+1)*24) 
when f_tthm_datetime_cksqdtime is not null and (lab1 is null and lab2 is not null) then (hour(fcreatedate)-hour(f_tthm_datetime_cksqdtime)+(datediff(fcreatedate, f_tthm_datetime_cksqdtime)-notworkdays+1)*24) 
when f_tthm_datetime_cksqdtime is not null and (lab1 is not null and lab2 is not null and fcreatedate1=f_tthm_datetime_cksqdtime1) then (hour(fcreatedate)-hour(f_tthm_datetime_cksqdtime)+(datediff(fcreatedate, f_tthm_datetime_cksqdtime)-notworkdays+1)*24) 
when f_tthm_datetime_cksqdtime is not null and (lab1 is not null and lab2 is not null and fcreatedate1<>f_tthm_datetime_cksqdtime1) then (hour(fcreatedate)-hour(f_tthm_datetime_cksqdtime)+(datediff(fcreatedate, f_tthm_datetime_cksqdtime)-notworkdays+2)*24) 
else null end as  ckfhsx
from (select fbillno,fstockid,fcreatedate,fcreatedate1,lab1,f_tthm_pushtoyjdf,f_tthm_datetime_cksqdtime,f_tthm_datetime_cksqdtime1,lab2,
if(notworkdays is not null,notworkdays,0) as  notworkdays 
from dm_gis_uimp.tmp_purchase_after_sales_maintenance_workday_1) as t 
) as tt 
;



insert overwrite table dm_gis_uimp.dws_purchase_after_sales_maintenance partition(inc_day='$firstDay') 
select 
fbillno,fcreatedate,fhf_type,ckfhsx 
from (select fbillno,fcreatedate,fhf_type,ckfhsx,row_number() over(partition by fbillno order by fcreatedate desc) as rn 
from dm_gis_uimp.tmp_purchase_after_sales_maintenance_res ) as t 
where t.rn=1
;