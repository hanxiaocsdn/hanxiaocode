-- 
-- 需求方：林中莉(01423677)
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2023-06-25
-- 任务信息： 
-- 

-- 源表 （剔除涉密字段）
-- dm_ers.dm_ft_ers_form_bill_approvalresult_dtl_di
CREATE  TABLE dm_gis_uimp.ods_dm_ft_ers_form_bill_approvalresult_dtl_di(
  `bill_approval_id` bigint COMMENT '主键ID[主键ID]',
  `lessee_id` bigint COMMENT '租户ID[租户ID]',
  `order_no` string COMMENT '单据编号[单据编号]',
  `approval_status` string COMMENT '当前处理动作之后的单据状态[当前处理动作之后的单据状态]',
  `order_status` string COMMENT '单据最新的状态(10新建21待ERS审批22ERS审批中40待提交ECP流程41提交ECP异常50ECP处理中60待提交FSOP61提交FSOP异常70FSOP处理中80单据已完成90单据已付款)[单据最新的状态(10新建21待ERS审批22ERS审批中40待提交ECP流程41提交ECP异常50ECP处理中60待提交FSOP61提交FSOP异常70FSOP处理中80单据已完成90单据已付款)]',
  `node_name` string COMMENT '节点名称[节点名称]',
  `order_link` string COMMENT '流程环节（新建环节：new_process；打印环节：print_process；业务审批：business_process；财务审批：financial_process）[流程环节（新建环节：new_process；打印环节：print_process；业务审批：business_process；财务审批：financial_process）]',
  `reject_current_node_id` bigint COMMENT '被驳回时所处的节点[被驳回时所处的节点]',
  `status_code` string COMMENT '前端界面显示的状态编码[前端界面显示的状态编码]',
  `status_desc` string COMMENT '前端界面显示的状态描述(关闭、已完成、审批中、被驳回、等待影像、审批结束等)[前端界面显示的状态描述(关闭、已完成、审批中、被驳回、等待影像、审批结束等)]',
  `order_type_base` string COMMENT '表单定义大类[表单定义大类]',
  `currency_amount` decimal(32, 2) COMMENT '报销的总金额[报销的总金额]',
  `approval_user` string COMMENT '审批人工号[审批人工号]',
  `approval_name` string COMMENT '审批人姓名[审批人姓名]',
  `approval_start_time` timestamp COMMENT '开始审批时间[开始审批时间]',
  `approval_end_time` timestamp COMMENT '结束审批时间[结束审批时间]',
  `approval_duration` decimal(32, 2) COMMENT '办理时长（小时）[办理时长（小时）]',
  `approval_result` tinyint COMMENT '审批结果：0驳回；1同意；2转办；3提交；6撤销[审批结果：0驳回；1同意；2转办；3提交；6撤销]',
  `approval_content` string COMMENT '审批内容[审批内容]',
  `reject_method` tinyint COMMENT '驳回方式：1、逐级审批；2、直送至我[驳回方式：1、逐级审批；2、直送至我]',
  `memo` string COMMENT '报销事项说明[报销事项说明]',
  `apply_user` string COMMENT '申请人[申请人]',
  `apply_name` string COMMENT '申请人姓名[申请人姓名]',
  `department_code` string COMMENT '申请人部门编码[申请人部门编码]',
  `department_name` string COMMENT '申请人部门名称[申请人部门名称]',
  `create_user` string COMMENT '创建人工号[创建人工号]',
  `create_name` string COMMENT '创建人姓名[创建人姓名]',
  `create_time` timestamp COMMENT '创建时间[创建时间]',
  `commit_date` timestamp COMMENT '单据的提交日期（触发提交审批按钮）[单据的提交日期（触发提交审批按钮）]',
  `create_date` timestamp COMMENT '单据的创建日期（单据的第一次保存日期）[单据的创建日期（单据的第一次保存日期）]',
  `attr1` string COMMENT '备用字段1(单据驳回原因)[备用字段1]',
  `attr2` string COMMENT '备用字段2[备用字段2]',
  `attr3` string COMMENT '备用字段3[备用字段3]',
  `attr4` string COMMENT '备用字段4[备用字段4]',
  `attr5` string COMMENT '备用字段5[备用字段5]',
  `update_time` timestamp COMMENT '更新时间[更新时间]',
  `doc_err_affect_amount` decimal(32, 2) COMMENT '单据错误影响金额[单据错误影响金额]',
  `recipient_email` string COMMENT '邮件收件人(主送)[邮件收件人(主送)]',
  `cc_email` string COMMENT '邮件抄送人[邮件抄送人]',
  `fssc_task_no` string COMMENT '共享审核任务编码[共享审核任务编码]',
  `fssc_task_type_no` string COMMENT '共享审核任务类型编码[共享审核任务类型编码]'
) COMMENT 'ERS单据审批已办记录（丰图）从业务表' 
PARTITIONED BY (`inc_day` string comment '')
stored as parquet 
tblproperties ('parquet.compression'='snappy')
;


-- 
insert overwrite table dm_gis_uimp.ods_dm_ft_ers_form_bill_approvalresult_dtl_di partition(inc_day='$firstDay') 
select 
bill_approval_id,lessee_id,order_no,approval_status,order_status,node_name,order_link,reject_current_node_id,status_code,status_desc,
order_type_base,currency_amount,approval_user,approval_name,approval_start_time,approval_end_time,approval_duration,approval_result,approval_content,
reject_method,memo,apply_user,apply_name,department_code,department_name,create_user,create_name,create_time,commit_date,create_date,attr1,attr2,attr3,attr4,attr5,
update_time,doc_err_affect_amount,recipient_email,cc_email,fssc_task_no,fssc_task_type_no 
from dm_ers.dm_ft_ers_form_bill_approvalresult_dtl_di  
where inc_day='$firstDay' 
;



-- 每日ERS审批时效
CREATE  TABLE dm_gis_uimp.dwd_ft_ers_approval_time(
create_time string COMMENT '创建时间',
order_no	string COMMENT '单据编号',
order_status	string COMMENT '单据最新的状态(10新建21待ERS审批22ERS审批中40待提交ECP流程41提交ECP异常50ECP处理中60待提交FSOP61提交FSOP异常70FSOP处理中80单据已完成90单据已付款)',
node_name	string COMMENT '节点名称',
order_link	string COMMENT '流程环节（新建环节：new_process；打印环节：print_process；业务审批：business_process；财务审批：financial_process）',
approval_result	string COMMENT '审批结果：0驳回；1同意；2转办；3提交；6撤销',
approval_content	string COMMENT '审批内容',
approval_user	string COMMENT '审批人工号',
approval_name	string COMMENT '审批人姓名',
approval_start_time	string COMMENT '开始审批时间',
approval_end_time	string COMMENT '结束审批时间',
approval_duration	string COMMENT '办理时长（小时）',
approval_duration_t	string COMMENT '剔除节假日的办理时长（小时）',
order_type_base	string COMMENT '表单定义大类',
apply_user	string COMMENT '申请人',
apply_name	string COMMENT '申请人姓名',
bill_approval_id	string COMMENT '主键ID' 
) COMMENT 'ERS审批时效表(日数据增加剔除节假日办理时长)' 
PARTITIONED BY (`inc_day` string comment '')
stored as parquet 
tblproperties ('parquet.compression'='snappy')
;


--
drop table if exists dm_gis_uimp.tmp_dws_ft_ers_approval_time;
create table dm_gis_uimp.tmp_dws_ft_ers_approval_time stored as parquet as 
select 
create_time,order_no,order_status,node_name,order_link,approval_result,approval_content,approval_user,approval_name,
approval_start_time,approval_end_time,
approval_start_date,approval_end_date,
t1.d_date as lab1,t2.d_date as lab2,
approval_duration,order_type_base,apply_user,apply_name,bill_approval_id 
from ( select 
create_time,order_no,order_status,node_name,order_link,approval_result,approval_content,approval_user,approval_name,
substr(approval_start_time,1,19) as approval_start_time,substr(approval_end_time,1,19) as approval_end_time,
substr(approval_start_time,1,10) as approval_start_date,substr(approval_end_time,1,10) as approval_end_date,
approval_duration,order_type_base,apply_user,apply_name,bill_approval_id 
from dm_gis_uimp.ods_dm_ft_ers_form_bill_approvalresult_dtl_di   
where inc_day='$firstDay' ) as t0 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.approval_start_date=t1.d_date 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t2 
on t0.approval_end_date=t2.d_date 
;

drop table if exists dm_gis_uimp.tmp_dws_ft_ers_approval_time_workday;
create table dm_gis_uimp.tmp_dws_ft_ers_approval_time_workday stored as parquet as 
select start_date,end_date,pos,real_date,is_workday 
from (
select
  start_date,end_date,pos,date_add(start_date, pos) as real_date
FROM
  (
    select approval_start_date as start_date,approval_end_date as end_date
    from dm_gis_uimp.tmp_dws_ft_ers_approval_time
    group by approval_start_date,approval_end_date
  ) tmp lateral view posexplode(split(space(datediff(end_date, start_date)), '')) t as pos,val
) as t0 
left join (select d_date,is_workday from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.real_date=t1.d_date 
;

insert overwrite table dm_gis_uimp.dwd_ft_ers_approval_time partition(inc_day='$firstDay') 
select 
create_time,order_no,order_status,node_name,order_link,approval_result,approval_content,approval_user,approval_name,
approval_start_time,approval_end_time,
approval_duration,
if(approval_duration_t<0,0,cast(approval_duration_t as decimal(10,2))) as approval_duration_t,
order_type_base,apply_user,apply_name,bill_approval_id  
from (
select 
create_time,order_no,order_status,node_name,order_link,approval_result,approval_content,approval_user,approval_name,
approval_start_time,approval_end_time,
approval_duration,
case when (lab1 is null and lab2 is null) then ((unix_timestamp(approval_end_time)-unix_timestamp(approval_start_time))/(60*60)-notworkdays*24) 
when (lab1 is not null and lab2 is null) then ((unix_timestamp(approval_end_time)-unix_timestamp(approval_start_time))/(60*60)+(-notworkdays+1)*24) 
when (lab1 is null and lab2 is not null) then ((unix_timestamp(approval_end_time)-unix_timestamp(approval_start_time))/(60*60)+(-notworkdays+1)*24) 
when (lab1 is not null and lab2 is not null and approval_end_date=approval_start_date) then ((unix_timestamp(approval_end_time)-unix_timestamp(approval_start_time))/(60*60)+(-notworkdays+1)*24) 
when (lab1 is not null and lab2 is not null and approval_end_date<>approval_start_date) then ((unix_timestamp(approval_end_time)-unix_timestamp(approval_start_time))/(60*60)+(-notworkdays+2)*24) 
else null end as  approval_duration_t,
order_type_base,apply_user,apply_name,bill_approval_id 
from dm_gis_uimp.tmp_dws_ft_ers_approval_time as t0 
left join (select start_date,end_date,sum(if(is_workday>0,is_workday,0)) as notworkdays from dm_gis_uimp.tmp_dws_ft_ers_approval_time_workday group by start_date,end_date ) as t1 
on t0.approval_start_date=t1.start_date and t0.approval_end_date=t1.end_date 
) as t 
;


-- 支持剔除节假日的“ERS审批时效表” 
-- 非工作日维表 dm_gis_uimp.dim_not_work_day
-- 源表 dm_gis_uimp.ods_dm_ft_ers_form_bill_approvalresult_dtl_di
-- 1.create_time大于等于2022-07-01 
-- 2.node_name不包含“开始审批”
-- 3.每个order_no取inc_day最新的一批数据

-- ERS审批时效表 
CREATE  TABLE dm_gis_uimp.dws_ft_ers_approval_time(
order_no	string COMMENT '单据编号',
order_status	string COMMENT '单据最新的状态(10新建21待ERS审批22ERS审批中40待提交ECP流程41提交ECP异常50ECP处理中60待提交FSOP61提交FSOP异常70FSOP处理中80单据已完成90单据已付款)',
node_name	string COMMENT '节点名称',
order_link	string COMMENT '流程环节（新建环节：new_process；打印环节：print_process；业务审批：business_process；财务审批：financial_process）',
approval_result	string COMMENT '审批结果：0驳回；1同意；2转办；3提交；6撤销',
approval_content	string COMMENT '审批内容',
approval_user	string COMMENT '审批人工号',
approval_name	string COMMENT '审批人姓名',
approval_start_time	string COMMENT '开始审批时间',
approval_end_time	string COMMENT '结束审批时间',
approval_duration	string COMMENT '办理时长（小时）',
approval_duration_t	string COMMENT '剔除节假日的办理时长（小时）',
order_type_base	string COMMENT '表单定义大类',
apply_user	string COMMENT '申请人',
apply_name	string COMMENT '申请人姓名',
bill_approval_id	string COMMENT '主键ID',
inc_date string comment 'inc_day日期'
)
COMMENT 'ERS审批时效表'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
stored as parquet 
tblproperties ('parquet.compression'='snappy')
;

-- 
drop table if exists dm_gis_uimp.tmp_dws_ft_ers_approval_time_maxday;
create table dm_gis_uimp.tmp_dws_ft_ers_approval_time_maxday stored as parquet as 
select order_no,max(inc_day) as inc_day 
from dm_gis_uimp.dwd_ft_ers_approval_time 
where inc_day>='20230601' and inc_day<='$firstDay' and order_no<>'' and create_time>'2022-07-01' and node_name<>'开始审批' 
group by order_no
;

insert overwrite table dm_gis_uimp.dws_ft_ers_approval_time partition(inc_day='$firstDay')
select 
t0.order_no,order_status,node_name,order_link,approval_result,approval_content,approval_user,approval_name,
approval_start_time,approval_end_time,
approval_duration,
approval_duration_t,
order_type_base,apply_user,apply_name,bill_approval_id,
t0.inc_day as inc_date   
from (select 
create_time,order_no,order_status,node_name,order_link,approval_result,approval_content,approval_user,approval_name,
approval_start_time,approval_end_time,
approval_duration,
approval_duration_t,
order_type_base,apply_user,apply_name,bill_approval_id,inc_day  
from dm_gis_uimp.dwd_ft_ers_approval_time 
where inc_day>='20230601' and inc_day<='$firstDay' and create_time>'2022-07-01' and node_name<>'开始审批' ) as t0 
left join dm_gis_uimp.tmp_dws_ft_ers_approval_time_maxday as t1 
on t0.inc_day=t1.inc_day and t0.order_no=t1.order_no  
where t1.inc_day is not null 
;


