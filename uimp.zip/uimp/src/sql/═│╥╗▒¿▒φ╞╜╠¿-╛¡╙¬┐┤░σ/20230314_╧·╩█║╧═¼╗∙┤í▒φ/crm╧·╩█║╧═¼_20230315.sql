-- 
-- 
-- 需求方：林中莉(01423677)
-- 需求： id: 1618602  【经营看板专项】销售合同基础表_V1.1_01416344_张小琼 
-- @author 张小琼 （01416344）
-- Created on 2023-03-15
-- 任务信息： 664713	dwd_crm合同和商机数据
-- 

-- 20230213 【信息化标准服务】表数据同步_V1.4   20230315 销售合同基础表_V1.1
-- CRM合同&商机数据同步需求_V1.0_20230213.xlsx
-- CMR-CON 解析
drop table if exists dm_gis_uimp.dwd_crm_con;
create table dm_gis_uimp.dwd_crm_con(
id string comment '_id',
last_modified_time string comment '最后修改时间',
create_time string comment '创建时间',
name string comment '公司合同编号',
record_type string comment '业务类型',
field_g7ya1__c string comment '是否框架合同',
field_b1cxa__c__r string comment '合同签订甲方',
field_ncq72__c string comment '合同签订乙方',
field_2qzat__c string comment '合同签订丙方',
field_6ohea__c string comment '所属业务中心',
life_status string comment '生命状态',
field_eoks3__c string comment 'ECP合同编号',
field_2mhq1__c__r string comment '商机项目',
field_mk1fa__c string comment '签订日期',
field_z4tcl__c string comment '产品类型',
field_8oa2s__c string comment '业绩归属时间',
field_t1ec2__c string comment '标的数量',
field_5kcpr__c string comment '合同金额(交通货运)（元）',
field_cby7l__c string comment '合同金额（元）',
field_is2a4__c string comment '质保期',
field_d1kft__c string comment '质保金额（元）',
field_y1cnk__c__r string comment '所属营销中心',
field_9necq__c string comment '是否有合格收款权',
field_5modd__c string comment '服务开始期限',
field_khw9g__c string comment '服务截止期限',
field_rw1w5__c string comment '业绩归属公司',
field_iew44__c string comment '合同归档',
field_5832e__c string comment '合同归档日期',
field_l6ncp__c string comment '待回款金额',
field_ua22f__c string comment '回款状态',
field_2zefw__c__r string comment '国家',
field_r8qu9__c__r string comment '省',
field_tfeh7__c__r string comment '市',
field_of9qe__c__r string comment '区',
field_wiw1c__c string comment '合同类型',
field_r0w2v__c string comment '续签合同',
owner_department string comment '负责人主属部门',
field_1i5qf__c string comment '合同标题',
field_r1qli__c__r string comment '最终用户',
field_3lv8r__c string comment '项目方式',
field_iqha2__c string comment '是否新客户',
field_42sl8__c string comment '合同签署路径',
field_st4vh__c string comment '是否分包',
field_kfify__c string comment '是否代理',
field_kg05c__c string comment '实施项目',
field_4w3eu__c string comment '项目毛利率(百分比)',
field_i81wv__c string comment '供应商分项合计（万元）',
field_da57w__c string comment '分项合计（万元）',
field_0mxxl__c string comment '合同大区',
field_j3ro2__c string comment '累计回款比例',
field_y74ak__c string comment '累计回款金额（元）',
field_lxzkx__c string comment '开票金额',
field_0mn82__c string comment '是否背靠背',
field_825cu__c string comment '自有产品占比',
field_knuxe__c string comment '最终合同通过时间',
field_jqrsv__c string comment '产品方向',
field_2w5z5__c string comment '合同标的',
field_9pr77__c string comment '付款/收款方式',
field_e9b8n__c string comment '第一年付款比例',
field_4d17h__c string comment '第二年付款比例',
field_ks47v__c string comment '第三年付款比例',
field_7jr1w__c string comment '第四年付款比例',
owner__r_name string comment '负责人',
field_lzwcy__c__r_name string comment '项目经理',
created_by__r_name string comment '创建人',
field_p83vd__c_r_name string comment '项目实施经理',
field_xvoay__c_filename string comment '双章版合同附件',
field_5z1Wh__c	string comment '财务代码',
field_0EuIa__c	string comment '行业',
field_j7N16__c	string comment '双章版合同最后更新时间',
field_2mHQ1__c  string comment '商机项目ID' 
)
comment 'CMR-CON解析' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期:yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- v1.2  20230815 
alter table dm_gis_uimp.dwd_crm_con add columns (field_2mHQ1__c  string comment '商机项目ID') cascade;

-- v1.3  20231219
alter table dm_gis_uimp.dwd_crm_con add columns (owner	string comment '负责人ID') cascade;
alter table dm_gis_uimp.dwd_crm_con add columns (field_kClKF__c	string comment '签单业绩确认方式') cascade;
alter table dm_gis_uimp.dwd_crm_con add columns (field_K2wb3__c	string comment '业绩金额') cascade;
alter table dm_gis_uimp.dwd_crm_con add columns (field_Wea25__c	string comment '项目经理（数字孪生）') cascade;

-- 
insert overwrite table dm_gis_uimp.dwd_crm_con partition(inc_day='') 
select 
get_json_object(content,'$._id') id,
get_json_object(content,'$.last_modified_time') last_modified_time,
get_json_object(content,'$.create_time') create_time,
get_json_object(content,'$.name') name,
get_json_object(content,'$.record_type') record_type,
get_json_object(content,'$.field_g7Ya1__c') field_g7ya1__c,
get_json_object(content,'$.field_B1cXA__c__r') field_b1cxa__c__r,
get_json_object(content,'$.field_ncq72__c') field_ncq72__c,
get_json_object(content,'$.field_2qZaT__c') field_2qzat__c,
get_json_object(content,'$.field_6OhEa__c') field_6ohea__c,
get_json_object(content,'$.life_status') life_status,
get_json_object(content,'$.field_EOks3__c') field_eoks3__c,
get_json_object(content,'$.field_2mHQ1__c__r') field_2mhq1__c__r,
get_json_object(content,'$.field_mk1fa__c') field_mk1fa__c,
get_json_object(content,'$.field_Z4tcL__c') field_z4tcl__c,
get_json_object(content,'$.field_8OA2s__c') field_8oa2s__c,
get_json_object(content,'$.field_t1ec2__c') field_t1ec2__c,
get_json_object(content,'$.field_5kCPr__c') field_5kcpr__c,
get_json_object(content,'$.field_CBy7L__c') field_cby7l__c,
get_json_object(content,'$.field_is2a4__c') field_is2a4__c,
get_json_object(content,'$.field_D1kFt__c') field_d1kft__c,
get_json_object(content,'$.field_Y1Cnk__c__r') field_y1cnk__c__r,
get_json_object(content,'$.field_9NeCQ__c') field_9necq__c,
get_json_object(content,'$.field_5modd__c') field_5modd__c,
get_json_object(content,'$.field_Khw9G__c') field_khw9g__c,
get_json_object(content,'$.field_Rw1w5__c') field_rw1w5__c,
get_json_object(content,'$.field_iew44__c') field_iew44__c,
get_json_object(content,'$.field_5832e__c') field_5832e__c,
get_json_object(content,'$.field_l6NcP__c') field_l6ncp__c,
get_json_object(content,'$.field_Ua22f__c') field_ua22f__c,
get_json_object(content,'$.field_2ZeFW__c__r') field_2zefw__c__r,
get_json_object(content,'$.field_r8Qu9__c__r') field_r8qu9__c__r,
get_json_object(content,'$.field_tFEh7__c__r') field_tfeh7__c__r,
get_json_object(content,'$.field_oF9qE__c__r') field_of9qe__c__r,
get_json_object(content,'$.field_wiw1c__c') field_wiw1c__c,
get_json_object(content,'$.field_R0W2v__c') field_r0w2v__c,
get_json_object(content,'$.owner_department') owner_department,
get_json_object(content,'$.field_1I5qF__c') field_1i5qf__c,
get_json_object(content,'$.field_r1qLi__c__r') field_r1qli__c__r,
get_json_object(content,'$.field_3lv8r__c') field_3lv8r__c,
get_json_object(content,'$.field_iqHA2__c') field_iqha2__c,
get_json_object(content,'$.field_42sl8__c') field_42sl8__c,
get_json_object(content,'$.field_st4Vh__c') field_st4vh__c,
get_json_object(content,'$.field_KFIfY__c') field_kfify__c,
get_json_object(content,'$.field_Kg05C__c') field_kg05c__c,
get_json_object(content,'$.field_4w3eu__c') field_4w3eu__c,
get_json_object(content,'$.field_i81wV__c') field_i81wv__c,
get_json_object(content,'$.field_da57w__c') field_da57w__c,
get_json_object(content,'$.field_0mXXl__c') field_0mxxl__c,
get_json_object(content,'$.field_J3ro2__c') field_j3ro2__c,
get_json_object(content,'$.field_y74ak__c') field_y74ak__c,
get_json_object(content,'$.field_LxzKX__c') field_lxzkx__c,
get_json_object(content,'$.field_0Mn82__c') field_0mn82__c,
get_json_object(content,'$.field_825cU__c') field_825cu__c,
get_json_object(content,'$.field_kNUXe__c') field_knuxe__c,
get_json_object(content,'$.field_jQrsV__c') field_jqrsv__c,
get_json_object(content,'$.field_2w5z5__c') field_2w5z5__c,
get_json_object(content,'$.field_9pR77__c') field_9pr77__c,
get_json_object(content,'$.field_E9b8N__c') field_e9b8n__c,
get_json_object(content,'$.field_4d17H__c') field_4d17h__c,
get_json_object(content,'$.field_ks47v__c') field_ks47v__c,
get_json_object(content,'$.field_7jR1W__c') field_7jr1w__c,
get_json_object(get_json_object(content,'$.owner__r'),'$.name') owner__r_name,
get_json_object(get_json_object(content,'$.field_lzwcy__c__r'),'$.name') field_lzwcy__c__r_name,
get_json_object(get_json_object(content,'$.created_by__r'),'$.name') created_by__r_name,
get_json_object(get_json_object(content,'$.field_p83vd__c__r'),'$.name') field_p83vd__c_r_name,
get_json_object(get_json_object(content,'$.field_xVOay__c'),'$.[0].filename') field_xvoay__c_filename,
get_json_object(content,'$.field_5z1Wh__c')  field_5z1Wh__c,
get_json_object(content,'$.field_0EuIa__c')  field_0EuIa__c,
get_json_object(content,'$.field_j7N16__c')  field_j7N16__c,
get_json_object(content,'$.field_2mHQ1__c')  field_2mHQ1__c,
get_json_object(content,'$.owner')  owner ,
get_json_object(content,'$.field_kClKF__c')  field_kClKF__c ,
get_json_object(content,'$.field_K2wb3__c')  field_K2wb3__c ,
get_json_object(content,'$.field_Wea25__c')  field_Wea25__c  

from dm_gis_uimp.ods_issp_cmr_con 
where inc_day=''
;


-- _id合并数据， 取最后修改时间最大的那一行
create table dm_gis_uimp.dwd_crm_con_res(
id string comment '_id',
last_modified_time string comment '最后修改时间',
create_time string comment '创建时间',
name string comment '公司合同编号',
record_type string comment '业务类型',
field_g7ya1__c string comment '是否框架合同',
field_b1cxa__c__r string comment '合同签订甲方',
field_ncq72__c string comment '合同签订乙方',
field_2qzat__c string comment '合同签订丙方',
field_6ohea__c string comment '所属业务中心',
life_status string comment '生命状态',
field_eoks3__c string comment 'ECP合同编号',
field_2mhq1__c__r string comment '商机项目',
field_mk1fa__c string comment '签订日期',
field_z4tcl__c string comment '产品类型',
field_8oa2s__c string comment '业绩归属时间',
field_t1ec2__c string comment '标的数量',
field_5kcpr__c string comment '合同金额(交通货运)（元）',
field_cby7l__c string comment '合同金额（元）',
field_is2a4__c string comment '质保期',
field_d1kft__c string comment '质保金额（元）',
field_y1cnk__c__r string comment '所属营销中心',
field_9necq__c string comment '是否有合格收款权',
field_5modd__c string comment '服务开始期限',
field_khw9g__c string comment '服务截止期限',
field_rw1w5__c string comment '业绩归属公司',
field_iew44__c string comment '合同归档',
field_5832e__c string comment '合同归档日期',
field_l6ncp__c string comment '待回款金额',
field_ua22f__c string comment '回款状态',
field_2zefw__c__r string comment '国家',
field_r8qu9__c__r string comment '省',
field_tfeh7__c__r string comment '市',
field_of9qe__c__r string comment '区',
field_wiw1c__c string comment '合同类型',
field_r0w2v__c string comment '续签合同',
owner_department string comment '负责人主属部门',
field_1i5qf__c string comment '合同标题',
field_r1qli__c__r string comment '最终用户',
field_3lv8r__c string comment '项目方式',
field_iqha2__c string comment '是否新客户',
field_42sl8__c string comment '合同签署路径',
field_st4vh__c string comment '是否分包',
field_kfify__c string comment '是否代理',
field_kg05c__c string comment '实施项目',
field_4w3eu__c string comment '项目毛利率(百分比)',
field_i81wv__c string comment '供应商分项合计（万元）',
field_da57w__c string comment '分项合计（万元）',
field_0mxxl__c string comment '合同大区',
field_j3ro2__c string comment '累计回款比例',
field_y74ak__c string comment '累计回款金额（元）',
field_lxzkx__c string comment '开票金额',
field_0mn82__c string comment '是否背靠背',
field_825cu__c string comment '自有产品占比',
field_knuxe__c string comment '最终合同通过时间',
field_jqrsv__c string comment '产品方向',
field_2w5z5__c string comment '合同标的',
field_9pr77__c string comment '付款/收款方式',
field_e9b8n__c string comment '第一年付款比例',
field_4d17h__c string comment '第二年付款比例',
field_ks47v__c string comment '第三年付款比例',
field_7jr1w__c string comment '第四年付款比例',
owner__r_name string comment '负责人',
field_lzwcy__c__r_name string comment '项目经理',
created_by__r_name string comment '创建人',
field_p83vd__c_r_name string comment '项目实施经理',
field_xvoay__c_filename string comment '双章版合同附件',
field_5z1Wh__c	string comment '财务代码',
field_0EuIa__c	string comment '行业',
field_j7N16__c	string comment '双章版合同最后更新时间',
field_2mHQ1__c  string comment '商机项目ID'  
)
comment 'CMR-CON解析' 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- v1.2  20230815 
alter table dm_gis_uimp.dwd_crm_con_res add columns (field_2mHQ1__c  string comment '商机项目ID') ;

-- v1.3  20231219
alter table dm_gis_uimp.dwd_crm_con_res add columns (owner	string comment '负责人ID') ;
alter table dm_gis_uimp.dwd_crm_con_res add columns (field_kClKF__c	string comment '签单业绩确认方式') ;
alter table dm_gis_uimp.dwd_crm_con_res add columns (field_K2wb3__c	string comment '业绩金额') ;
alter table dm_gis_uimp.dwd_crm_con_res add columns (field_Wea25__c	string comment '项目经理（数字孪生）') ;


-- 首次跑历史
insert overwrite table dm_gis_uimp.dwd_crm_con_res 
select 
id,last_modified_time,create_time,name,record_type,field_g7ya1__c,field_b1cxa__c__r,field_ncq72__c,field_2qzat__c,field_6ohea__c,life_status,field_eoks3__c,field_2mhq1__c__r,field_mk1fa__c,field_z4tcl__c,field_8oa2s__c,field_t1ec2__c,field_5kcpr__c,field_cby7l__c,field_is2a4__c,field_d1kft__c,field_y1cnk__c__r,field_9necq__c,
field_5modd__c,field_khw9g__c,field_rw1w5__c,field_iew44__c,field_5832e__c,field_l6ncp__c,field_ua22f__c,field_2zefw__c__r,field_r8qu9__c__r,field_tfeh7__c__r,field_of9qe__c__r,field_wiw1c__c,field_r0w2v__c,owner_department,field_1i5qf__c,field_r1qli__c__r,field_3lv8r__c,field_iqha2__c,field_42sl8__c,field_st4vh__c,field_kfify__c,
field_kg05c__c,field_4w3eu__c,field_i81wv__c,field_da57w__c,field_0mxxl__c,field_j3ro2__c,field_y74ak__c,field_lxzkx__c,field_0mn82__c,field_825cu__c,field_knuxe__c,field_jqrsv__c,field_2w5z5__c,field_9pr77__c,field_e9b8n__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,owner__r_name,field_lzwcy__c__r_name,created_by__r_name,field_p83vd__c_r_name,field_xvoay__c_filename,
field_5z1Wh__c,field_0EuIa__c,field_j7N16__c,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
from (
select 
row_number() over(partition by id order by last_modified_time desc) as rn,
id,last_modified_time,create_time,name,record_type,field_g7ya1__c,field_b1cxa__c__r,field_ncq72__c,field_2qzat__c,field_6ohea__c,life_status,field_eoks3__c,field_2mhq1__c__r,field_mk1fa__c,field_z4tcl__c,field_8oa2s__c,field_t1ec2__c,field_5kcpr__c,field_cby7l__c,field_is2a4__c,field_d1kft__c,field_y1cnk__c__r,field_9necq__c,
field_5modd__c,field_khw9g__c,field_rw1w5__c,field_iew44__c,field_5832e__c,field_l6ncp__c,field_ua22f__c,field_2zefw__c__r,field_r8qu9__c__r,field_tfeh7__c__r,field_of9qe__c__r,field_wiw1c__c,field_r0w2v__c,owner_department,field_1i5qf__c,field_r1qli__c__r,field_3lv8r__c,field_iqha2__c,field_42sl8__c,field_st4vh__c,field_kfify__c,
field_kg05c__c,field_4w3eu__c,field_i81wv__c,field_da57w__c,field_0mxxl__c,field_j3ro2__c,field_y74ak__c,field_lxzkx__c,field_0mn82__c,field_825cu__c,field_knuxe__c,field_jqrsv__c,field_2w5z5__c,field_9pr77__c,field_e9b8n__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,owner__r_name,field_lzwcy__c__r_name,created_by__r_name,field_p83vd__c_r_name,field_xvoay__c_filename,
field_5z1Wh__c,field_0EuIa__c,field_j7N16__c,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
from dm_gis_uimp.dwd_crm_con 
) as t where t.rn=1 and t.life_status!='invalid'
;

-- 每日跑
insert overwrite table dm_gis_uimp.dwd_crm_con_res 
select 
id,last_modified_time,create_time,name,record_type,field_g7ya1__c,field_b1cxa__c__r,field_ncq72__c,field_2qzat__c,field_6ohea__c,life_status,field_eoks3__c,field_2mhq1__c__r,field_mk1fa__c,field_z4tcl__c,field_8oa2s__c,field_t1ec2__c,field_5kcpr__c,field_cby7l__c,field_is2a4__c,field_d1kft__c,field_y1cnk__c__r,field_9necq__c,
field_5modd__c,field_khw9g__c,field_rw1w5__c,field_iew44__c,field_5832e__c,field_l6ncp__c,field_ua22f__c,field_2zefw__c__r,field_r8qu9__c__r,field_tfeh7__c__r,field_of9qe__c__r,field_wiw1c__c,field_r0w2v__c,owner_department,field_1i5qf__c,field_r1qli__c__r,field_3lv8r__c,field_iqha2__c,field_42sl8__c,field_st4vh__c,field_kfify__c,
field_kg05c__c,field_4w3eu__c,field_i81wv__c,field_da57w__c,field_0mxxl__c,field_j3ro2__c,field_y74ak__c,field_lxzkx__c,field_0mn82__c,field_825cu__c,field_knuxe__c,field_jqrsv__c,field_2w5z5__c,field_9pr77__c,field_e9b8n__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,owner__r_name,field_lzwcy__c__r_name,created_by__r_name,field_p83vd__c_r_name,field_xvoay__c_filename,
field_5z1Wh__c,field_0EuIa__c,field_j7N16__c,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c   
from (
select 
row_number() over(partition by id order by last_modified_time desc) as rn,
id,last_modified_time,create_time,name,record_type,field_g7ya1__c,field_b1cxa__c__r,field_ncq72__c,field_2qzat__c,field_6ohea__c,life_status,field_eoks3__c,field_2mhq1__c__r,field_mk1fa__c,field_z4tcl__c,field_8oa2s__c,field_t1ec2__c,field_5kcpr__c,field_cby7l__c,field_is2a4__c,field_d1kft__c,field_y1cnk__c__r,field_9necq__c,
field_5modd__c,field_khw9g__c,field_rw1w5__c,field_iew44__c,field_5832e__c,field_l6ncp__c,field_ua22f__c,field_2zefw__c__r,field_r8qu9__c__r,field_tfeh7__c__r,field_of9qe__c__r,field_wiw1c__c,field_r0w2v__c,owner_department,field_1i5qf__c,field_r1qli__c__r,field_3lv8r__c,field_iqha2__c,field_42sl8__c,field_st4vh__c,field_kfify__c,
field_kg05c__c,field_4w3eu__c,field_i81wv__c,field_da57w__c,field_0mxxl__c,field_j3ro2__c,field_y74ak__c,field_lxzkx__c,field_0mn82__c,field_825cu__c,field_knuxe__c,field_jqrsv__c,field_2w5z5__c,field_9pr77__c,field_e9b8n__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,owner__r_name,field_lzwcy__c__r_name,created_by__r_name,field_p83vd__c_r_name,field_xvoay__c_filename,
field_5z1Wh__c,field_0EuIa__c,field_j7N16__c,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c     
from (select id,last_modified_time,create_time,name,record_type,field_g7ya1__c,field_b1cxa__c__r,field_ncq72__c,field_2qzat__c,field_6ohea__c,life_status,field_eoks3__c,field_2mhq1__c__r,field_mk1fa__c,field_z4tcl__c,field_8oa2s__c,field_t1ec2__c,field_5kcpr__c,field_cby7l__c,field_is2a4__c,field_d1kft__c,field_y1cnk__c__r,field_9necq__c,
field_5modd__c,field_khw9g__c,field_rw1w5__c,field_iew44__c,field_5832e__c,field_l6ncp__c,field_ua22f__c,field_2zefw__c__r,field_r8qu9__c__r,field_tfeh7__c__r,field_of9qe__c__r,field_wiw1c__c,field_r0w2v__c,owner_department,field_1i5qf__c,field_r1qli__c__r,field_3lv8r__c,field_iqha2__c,field_42sl8__c,field_st4vh__c,field_kfify__c,
field_kg05c__c,field_4w3eu__c,field_i81wv__c,field_da57w__c,field_0mxxl__c,field_j3ro2__c,field_y74ak__c,field_lxzkx__c,field_0mn82__c,field_825cu__c,field_knuxe__c,field_jqrsv__c,field_2w5z5__c,field_9pr77__c,field_e9b8n__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,owner__r_name,field_lzwcy__c__r_name,created_by__r_name,field_p83vd__c_r_name,field_xvoay__c_filename,
field_5z1Wh__c,field_0EuIa__c,field_j7N16__c,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
  from dm_gis_uimp.dwd_crm_con where inc_day='$firstDay' 
union all 
select id,last_modified_time,create_time,name,record_type,field_g7ya1__c,field_b1cxa__c__r,field_ncq72__c,field_2qzat__c,field_6ohea__c,life_status,field_eoks3__c,field_2mhq1__c__r,field_mk1fa__c,field_z4tcl__c,field_8oa2s__c,field_t1ec2__c,field_5kcpr__c,field_cby7l__c,field_is2a4__c,field_d1kft__c,field_y1cnk__c__r,field_9necq__c,
field_5modd__c,field_khw9g__c,field_rw1w5__c,field_iew44__c,field_5832e__c,field_l6ncp__c,field_ua22f__c,field_2zefw__c__r,field_r8qu9__c__r,field_tfeh7__c__r,field_of9qe__c__r,field_wiw1c__c,field_r0w2v__c,owner_department,field_1i5qf__c,field_r1qli__c__r,field_3lv8r__c,field_iqha2__c,field_42sl8__c,field_st4vh__c,field_kfify__c,
field_kg05c__c,field_4w3eu__c,field_i81wv__c,field_da57w__c,field_0mxxl__c,field_j3ro2__c,field_y74ak__c,field_lxzkx__c,field_0mn82__c,field_825cu__c,field_knuxe__c,field_jqrsv__c,field_2w5z5__c,field_9pr77__c,field_e9b8n__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,owner__r_name,field_lzwcy__c__r_name,created_by__r_name,field_p83vd__c_r_name,field_xvoay__c_filename,
field_5z1Wh__c,field_0EuIa__c,field_j7N16__c,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
  from dm_gis_uimp.dwd_crm_con_res 
 ) as t0 
) as t where t.rn=1 and t.life_status!='invalid'
;



--------------------------------------
--------------------------------------
-- CMR-OPP 解析
create table dm_gis_uimp.dwd_crm_opp(
id string comment '_id',
last_modified_time string comment '最后修改时间',
contract_date__c string comment '合同实施日期',
close_date string comment '结单日期',
field_g773s__c string comment '纳入预测日期',
preimplement_date__c string comment '售前实施日期',
preinvest_date__c string comment '售前投入日期',
field_uk3cf__c string comment '预计签单时间',
sap_datbis__c string comment 'SAP项目结束时间',
sap_datab__c string comment 'SAP项目开始时间',
create_time string comment '创建时间',
stg_changed_time string comment '阶段变更时间',
field_jgrga__c string comment '预计签单金额（万元)',
field_1ft1d__c string comment '预计签单金额（元）',
field_gw12o__c string comment '预期规模（台）',
field_4fr3e__c string comment '产品方向（交通货运）',
field_wil66__c string comment '成本中心',
owner_department string comment '负责人主属部门',
field_m14t0__c string comment '工号',
field_0n284__c__r string comment '国家',
sales_status string comment '阶段状态',
field_bwv15__c string comment '客户合同签订方',
account_id__r string comment '客户名称',
field_gwafr__c__r string comment '区',
field_kvx2b__c string comment '商机代码',
sales_stage string comment '商机阶段',
name string comment '商机名称',
life_status string comment '生命状态',
field_r5b9e__c__r string comment '省',
field_vnxdv__c__r string comment '市',
field_43dhc__c string comment '是否纳入预测',
field_cz768__c string comment '所属业务中心',
field_bgr8v__c string comment '所属营销中心',
field_qjotp__c string comment '项目运作方式',
record_type string comment '业务类型',
created_by__r_name string comment '创建人',
owner__r_name string comment '负责人',
field_ao14e__c__r_name string comment '解决方案负责人',
field_e5pbb__c__r_name string comment '业务中心负责人',
field_0EuIa__c string comment '行业',
field_0d6eG__c string comment '经营单元（签单）'  
)
comment 'CMR-OPP解析' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 20230822  数字孪生项目管理看板v1.0 需要增加字段
alter table dm_gis_uimp.dwd_crm_opp add columns (field_pA96Q__c  string comment '原因类别（沉默原因字段）') cascade;
alter table dm_gis_uimp.dwd_crm_opp add columns (field_FJobx__c  string comment '沉默前商机阶段') cascade;

-- 20230915 商机明细表_数据侧_V1.2  增加字段
alter table dm_gis_uimp.dwd_crm_opp add columns (field_n2cW1__c  string comment '项目累计提前投入成本（元）') cascade;
alter table dm_gis_uimp.dwd_crm_opp add columns (field_ZWC1d__c  string comment '创建时间(原系统)') cascade;

-- 20231008 商机明细表_数据侧_V1.3  增加字段 field_f1xp2__c
alter table dm_gis_uimp.dwd_crm_opp add columns (field_f1xp2__c  string comment '业务线') cascade;

-- 
insert overwrite table dm_gis_uimp.dwd_crm_opp partition(inc_day='') 
select 
get_json_object(content,'$._id') id ,
get_json_object(content,'$.last_modified_time') last_modified_time ,
get_json_object(content,'$.contract_date__c') contract_date__c ,
get_json_object(content,'$.close_date') close_date ,
get_json_object(content,'$.field_g773s__c') field_g773s__c ,
get_json_object(content,'$.preimplement_date__c') preimplement_date__c ,
get_json_object(content,'$.preinvest_date__c') preinvest_date__c ,
get_json_object(content,'$.field_uk3cF__c') field_uk3cf__c ,
get_json_object(content,'$.sap_datbis__c') sap_datbis__c ,
get_json_object(content,'$.sap_datab__c') sap_datab__c ,
get_json_object(content,'$.create_time') create_time ,
get_json_object(content,'$.stg_changed_time') stg_changed_time ,
get_json_object(content,'$.field_jGRga__c') field_jgrga__c ,
get_json_object(content,'$.field_1Ft1d__c') field_1ft1d__c ,
get_json_object(content,'$.field_gw12O__c') field_gw12o__c ,
get_json_object(content,'$.field_4fR3E__c') field_4fr3e__c ,
get_json_object(content,'$.field_wIl66__c') field_wil66__c ,
get_json_object(content,'$.owner_department') owner_department ,
get_json_object(content,'$.field_m14t0__c') field_m14t0__c ,
get_json_object(content,'$.field_0n284__c__r') field_0n284__c__r ,
get_json_object(content,'$.sales_status') sales_status ,
get_json_object(content,'$.field_bwV15__c') field_bwv15__c ,
get_json_object(content,'$.account_id__r') account_id__r ,
get_json_object(content,'$.field_GWafr__c__r') field_gwafr__c__r ,
get_json_object(content,'$.field_kvx2B__c') field_kvx2b__c ,
get_json_object(content,'$.sales_stage') sales_stage ,
get_json_object(content,'$.name') name ,
get_json_object(content,'$.life_status') life_status ,
get_json_object(content,'$.field_R5B9e__c__r') field_r5b9e__c__r ,
get_json_object(content,'$.field_vNXdv__c__r') field_vnxdv__c__r ,
get_json_object(content,'$.field_43dhc__c') field_43dhc__c ,
get_json_object(content,'$.field_cz768__c') field_cz768__c ,
get_json_object(content,'$.field_bgR8v__c') field_bgr8v__c ,
get_json_object(content,'$.field_Qjotp__c') field_qjotp__c ,
get_json_object(content,'$.record_type') record_type,
get_json_object(get_json_object(content,'$.created_by__r'),'$.name')  created_by__r_name,
get_json_object(get_json_object(content,'$.owner__r'),'$.name') owner__r_name,
get_json_object(get_json_object(content,'$.field_ao14E__c__r'),'$.name') field_ao14e__c__r_name, 
get_json_object(get_json_object(content,'$.field_e5pBB__c__r'),'$.name') field_e5pbb__c__r_name,
get_json_object(content,'$.field_0EuIa__c')  field_0EuIa__c,
get_json_object(content,'$.field_0d6eG__c')  field_0d6eG__c,
get_json_object(content,'$.field_pA96Q__c')  field_pA96Q__c,
get_json_object(content,'$.field_FJobx__c')  field_FJobx__c,
get_json_object(content,'$.field_n2cW1__c')  field_n2cW1__c,
get_json_object(content,'$.field_ZWC1d__c')  field_ZWC1d__c,
get_json_object(content,'$.field_f1xp2__c')  field_f1xp2__c 
from 
dm_gis_uimp.ods_issp_cmr_opp 
where inc_day=''
;



-- _id合并数据，合并完life_status不等于invalid, 取最后修改时间最大的那一行
create table dm_gis_uimp.dwd_crm_opp_res(
id string comment '_id',
last_modified_time string comment '最后修改时间',
contract_date__c string comment '合同实施日期',
close_date string comment '结单日期',
field_g773s__c string comment '纳入预测日期',
preimplement_date__c string comment '售前实施日期',
preinvest_date__c string comment '售前投入日期',
field_uk3cf__c string comment '预计签单时间',
sap_datbis__c string comment 'SAP项目结束时间',
sap_datab__c string comment 'SAP项目开始时间',
create_time string comment '创建时间',
stg_changed_time string comment '阶段变更时间',
field_jgrga__c string comment '预计签单金额（万元)',
field_1ft1d__c string comment '预计签单金额（元）',
field_gw12o__c string comment '预期规模（台）',
field_4fr3e__c string comment '产品方向（交通货运）',
field_wil66__c string comment '成本中心',
owner_department string comment '负责人主属部门',
field_m14t0__c string comment '工号',
field_0n284__c__r string comment '国家',
sales_status string comment '阶段状态',
field_bwv15__c string comment '客户合同签订方式',
account_id__r string comment '客户名称',
field_gwafr__c__r string comment '区',
field_kvx2b__c string comment '商机代码',
sales_stage string comment '商机阶段',
name string comment '商机名称',
life_status string comment '生命状态',
field_r5b9e__c__r string comment '省',
field_vnxdv__c__r string comment '市',
field_43dhc__c string comment '是否纳入预测',
field_cz768__c string comment '所属业务中心',
field_bgr8v__c string comment '所属营销中心',
field_qjotp__c string comment '项目运作方式',
record_type string comment '业务类型',
created_by__r_name string comment '创建人',
owner__r_name string comment '负责人',
field_ao14e__c__r_name string comment '解决方案负责人',
field_e5pbb__c__r_name string comment '业务中心负责人',
field_0EuIa__c string comment '行业',
field_0d6eG__c string comment '经营单元（签单）',
field_pA96Q__c  string comment '原因类别（沉默原因字段）',
field_FJobx__c  string comment '沉默前商机阶段',
field_n2cW1__c  string comment '项目累计提前投入成本（元）' 
)
comment 'CMR-OPP解析结果表' 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 20230822  数字孪生项目管理看板v1.0 需要增加字段
alter table dm_gis_uimp.dwd_crm_opp_res add columns (field_pA96Q__c  string comment '原因类别（沉默原因字段）') ;
alter table dm_gis_uimp.dwd_crm_opp_res add columns (field_FJobx__c  string comment '沉默前商机阶段') ;

-- 20230915 商机明细表_数据侧_V1.2  增加字段
alter table dm_gis_uimp.dwd_crm_opp_res add columns (field_n2cW1__c  string comment '项目累计提前投入成本（元）');



-- 首次跑历史
insert overwrite table dm_gis_uimp.dwd_crm_opp_res 
select 
id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, 
create_time, 
stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, record_type, created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c     
from (
select 
row_number() over(partition by id order by last_modified_time desc) as rn,
id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, 
if(field_ZWC1d__c is not null and field_ZWC1d__c<>'',field_ZWC1d__c,create_time) as create_time,
stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, 
if(field_f1xp2__c is not null and field_f1xp2__c<>'',field_f1xp2__c,record_type) as record_type, 
created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c       
from dm_gis_uimp.dwd_crm_opp 
) as t where t.rn=1 and t.life_status!='invalid'
;


-- 每日跑
insert overwrite table dm_gis_uimp.dwd_crm_opp_res 
select 
id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, create_time, stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, record_type, created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c      
from (
select 
row_number() over(partition by id order by last_modified_time desc) as rn,
id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, create_time, stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, record_type, created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c       
from (select id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, 
if(field_ZWC1d__c is not null and field_ZWC1d__c<>'',field_ZWC1d__c,create_time) as create_time,
stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, 
if(field_f1xp2__c is not null and field_f1xp2__c<>'',field_f1xp2__c,record_type) as record_type, 
created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c      
  from dm_gis_uimp.dwd_crm_opp where inc_day='$firstDay' 
union all 
select id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, 
create_time,
stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, 
record_type, 
created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c      
  from dm_gis_uimp.dwd_crm_opp_res 
 ) as t0 
) as t where t.rn=1  and t.life_status!='invalid'
;


-- 20230810 
-- 商机明细表(每月生成快照)  
create table dm_gis_uimp.dm_dwd_crm_opp_dtl_di(
id string comment '_id',
last_modified_time string comment '最后修改时间',
contract_date__c string comment '合同实施日期',
close_date string comment '结单日期',
field_g773s__c string comment '纳入预测日期',
preimplement_date__c string comment '售前实施日期',
preinvest_date__c string comment '售前投入日期',
field_uk3cf__c string comment '预计签单时间',
sap_datbis__c string comment 'SAP项目结束时间',
sap_datab__c string comment 'SAP项目开始时间',
create_time string comment '创建时间',
stg_changed_time string comment '阶段变更时间',
field_jgrga__c string comment '预计签单金额（万元)',
field_1ft1d__c string comment '预计签单金额（元）',
field_gw12o__c string comment '预期规模（台）',
field_4fr3e__c string comment '产品方向（交通货运）',
field_wil66__c string comment '成本中心',
owner_department string comment '负责人主属部门',
field_m14t0__c string comment '工号',
field_0n284__c__r string comment '国家',
sales_status string comment '阶段状态',
field_bwv15__c string comment '客户合同签订方式',
account_id__r string comment '客户名称',
field_gwafr__c__r string comment '区',
field_kvx2b__c string comment '商机代码',
sales_stage string comment '商机阶段',
name string comment '商机名称',
life_status string comment '生命状态',
field_r5b9e__c__r string comment '省',
field_vnxdv__c__r string comment '市',
field_43dhc__c string comment '是否纳入预测',
field_cz768__c string comment '所属业务中心',
field_bgr8v__c string comment '所属营销中心',
field_qjotp__c string comment '项目运作方式',
record_type string comment '业务类型',
created_by__r_name string comment '创建人',
owner__r_name string comment '负责人',
field_ao14e__c__r_name string comment '解决方案负责人',
field_e5pbb__c__r_name string comment '业务中心负责人',
field_0EuIa__c string comment '行业',
field_0d6eG__c string comment '经营单元（签单）',
field_pA96Q__c  string comment '原因类别（沉默原因字段）',
field_FJobx__c  string comment '沉默前商机阶段',
field_n2cW1__c  string comment '项目累计提前投入成本（元）'  
)
comment '商机明细表(每月生成快照)' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

alter table dm_gis_uimp.dm_dwd_crm_opp_dtl_di add columns (field_pA96Q__c  string comment '原因类别（沉默原因字段）') cascade;
alter table dm_gis_uimp.dm_dwd_crm_opp_dtl_di add columns (field_FJobx__c  string comment '沉默前商机阶段') cascade;

-- 20230915 商机明细表_数据侧_V1.2  增加字段  $[time(yyyyMMdd,-0d)]
alter table dm_gis_uimp.dm_dwd_crm_opp_dtl_di add columns (field_n2cW1__c  string comment '项目累计提前投入成本（元）') cascade;

insert overwrite table dm_gis_uimp.dm_dwd_crm_opp_dtl_di partition(inc_day='$firtDay') 
select 
id, last_modified_time, contract_date__c, close_date, field_g773s__c, preimplement_date__c, preinvest_date__c, field_uk3cf__c, sap_datbis__c, sap_datab__c, create_time, stg_changed_time, field_jgrga__c, field_1ft1d__c, 
field_gw12o__c, field_4fr3e__c, field_wil66__c, owner_department, field_m14t0__c, field_0n284__c__r, sales_status, field_bwv15__c, account_id__r, field_gwafr__c__r, field_kvx2b__c, sales_stage, name, life_status, 
field_r5b9e__c__r, field_vnxdv__c__r, field_43dhc__c, field_cz768__c, field_bgr8v__c, field_qjotp__c, record_type, created_by__r_name, owner__r_name, field_ao14e__c__r_name, field_e5pbb__c__r_name,field_0EuIa__c,field_0d6eG__c,
field_pA96Q__c,field_FJobx__c,field_n2cW1__c      
from dm_gis_uimp.dwd_crm_opp_res 
;




-- CRM销售合同基础表
drop table if exists dm_gis_uimp.dwd_crm_con_base;
create table dm_gis_uimp.dwd_crm_con_base(
id	string comment 'id',
field_eoks3__c	string comment 'ECP合同编号',
field_t1ec2__c	string comment '标的数量',
field_jqrsv__c	string comment '产品方向',
field_z4tcl__c	string comment '产品类型',
created_by__r_name	string comment '创建人',
create_time	string comment '创建时间',
field_l6ncp__c	string comment '待回款金额',
field_4d17h__c	string comment '第二年付款比例',
field_ks47v__c	string comment '第三年付款比例',
field_7jr1w__c	string comment '第四年付款比例',
field_e9b8n__c	string comment '第一年付款比例',
field_da57w__c	string comment '分项合计（万元）',
field_khw9g__c	string comment '服务截止期限',
field_5modd__c	string comment '服务开始期限',
field_9pr77__c	string comment '付款/收款方式',
owner__r_name	string comment '负责人',
owner_department	string comment '负责人主属部门',
name	string comment '公司合同编号',
field_i81wv__c	string comment '供应商分项合计（万元）',
field_2zefw__c__r	string comment '国家',
field_2w5z5__c	string comment '合同标的',
field_1i5qf__c	string comment '合同标题',
field_0mxxl__c	string comment '合同大区',
field_iew44__c	string comment '合同归档',
field_5832e__c	string comment '合同归档日期',
field_5kcpr__c	string comment '合同金额(交通货运)（元）',
field_cby7l__c	string comment '合同金额（万元）',
field_wiw1c__c	string comment '合同类型',
field_2qzat__c	string comment '合同签订丙方',
field_b1cxa__c__r	string comment '合同签订甲方',
field_ncq72__c	string comment '合同签订乙方',
field_42sl8__c	string comment '合同签署路径',
field_ua22f__c	string comment '回款状态',
field_lxzkx__c	string comment '开票金额',
field_j3ro2__c	string comment '累计回款比例',
field_y74ak__c	string comment '累计回款金额（元）',
field_mk1fa__c	string comment '签订日期',
field_of9qe__c__r	string comment '区',
field_2mhq1__c__r	string comment '商机项目',
field_kvx2b__c	string comment '商机代码',
field_5z1Wh__c	string comment '财务代码',
farmout_amount	string comment '合同总分包金额（万元）',
cost_amount	string comment '合同总成本合计（万元）',
field_0EuIa__c	string comment '行业',
life_status	string comment '生命状态',
field_kg05c__c	string comment '实施项目',
field_r8qu9__c__r	string comment '省',
field_tfeh7__c__r	string comment '市',
regional_type	string comment '区域类型',
field_j7N16__c	string comment '双章版合同最后更新时间',
field_0mn82__c	string comment '是否背靠背',
field_kfify__c	string comment '是否代理',
field_st4vh__c	string comment '是否分包',
field_g7ya1__c	string comment '是否框架合同',
field_iqha2__c	string comment '是否新客户',
field_9necq__c	string comment '是否有合格收款权',
field_xvoay__c_filename	string comment '双章版合同附件',
field_6ohea__c	string comment '所属业务中心',
field_y1cnk__c__r	string comment '所属营销中心',
field_2mhq1__c_create_time string comment '商机创建时间',
field_3lv8r__c	string comment '项目方式',
field_lzwcy__c__r_name	string comment '项目经理',
field_4w3eu__c	string comment '项目毛利率(百分比)',
field_p83vd__c_r_name	string comment '项目实施经理',
field_r0w2v__c	string comment '续签合同',
field_rw1w5__c	string comment '业绩归属公司',
field_8oa2s__c	string comment '业绩归属时间',
record_type	string comment '业务类型',
field_d1kft__c	string comment '质保金额（元）',
field_is2a4__c	string comment '质保期',
field_825cu__c	string comment '自有产品占比',
last_modified_time	string comment '最后修改时间',
field_knuxe__c	string comment '最终合同通过时间',
field_r1qli__c__r	string comment '最终用户',
field_2mHQ1__c  string comment '商机项目ID' 
)
comment 'CRM销售合同基础表' 
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- v1.2 增加字段
alter table dm_gis_uimp.dwd_crm_con_base add columns (field_2mhq1__c_create_time string comment '商机创建时间');
alter table dm_gis_uimp.dwd_crm_con_base change field_2mhq1__c_create_time field_2mhq1__c_create_time string after field_y1cnk__c__r; 

-- v1.4 增加字段
alter table dm_gis_uimp.dwd_crm_con_base add columns (field_2mHQ1__c  string comment '商机项目ID'  );

-- v1.3  20231219
alter table dm_gis_uimp.dwd_crm_con_base add columns (owner	string comment '负责人ID') ;
alter table dm_gis_uimp.dwd_crm_con_base add columns (field_kClKF__c	string comment '签单业绩确认方式') ;
alter table dm_gis_uimp.dwd_crm_con_base add columns (field_K2wb3__c	string comment '业绩金额') ;
alter table dm_gis_uimp.dwd_crm_con_base add columns (field_Wea25__c	string comment '项目经理（数字孪生）') ;

-- 
insert overwrite table dm_gis_uimp.dwd_crm_con_base 
select 
id,field_eoks3__c,field_t1ec2__c,field_jqrsv__c,field_z4tcl__c,created_by__r_name,create_time,field_l6ncp__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,field_e9b8n__c,field_da57w__c,field_khw9g__c,field_5modd__c,field_9pr77__c,owner__r_name,
owner_department,name,field_i81wv__c,field_2zefw__c__r,field_2w5z5__c,field_1i5qf__c,field_0mxxl__c,field_iew44__c,field_5832e__c,field_5kcpr__c,
field_cby7l__c/10000 field_cby7l__c,
field_wiw1c__c,field_2qzat__c,field_b1cxa__c__r,field_ncq72__c,field_42sl8__c,field_ua22f__c,
field_lxzkx__c,field_j3ro2__c,field_y74ak__c,field_mk1fa__c,field_of9qe__c__r,field_2mhq1__c__r,
field_kvx2b__c,
field_5z1Wh__c,
sum(farmout_amount)/10000 as farmout_amount,
sum(cost_amount)/10000 as cost_amount,
field_0EuIa__c,
life_status,field_kg05c__c,field_r8qu9__c__r,field_tfeh7__c__r,
regional_type,
field_j7N16__c,
field_0mn82__c,field_kfify__c,field_st4vh__c,field_g7ya1__c,field_iqha2__c,field_9necq__c,field_xvoay__c_filename,
field_6ohea__c,field_y1cnk__c__r,field_2mhq1__c_create_time,
field_3lv8r__c,field_lzwcy__c__r_name,field_4w3eu__c,field_p83vd__c_r_name,field_r0w2v__c,field_rw1w5__c,field_8oa2s__c,
record_type,field_d1kft__c,field_is2a4__c,field_825cu__c,last_modified_time,field_knuxe__c,field_r1qli__c__r,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
from 
(
select
t0.id,field_eoks3__c,field_t1ec2__c,field_jqrsv__c,field_z4tcl__c,created_by__r_name,t0.create_time,field_l6ncp__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,field_e9b8n__c,field_da57w__c,field_khw9g__c,field_5modd__c,field_9pr77__c,owner__r_name,
owner_department,t0.name,field_i81wv__c,field_2zefw__c__r,field_2w5z5__c,field_1i5qf__c,field_0mxxl__c,field_iew44__c,field_5832e__c,field_5kcpr__c,field_cby7l__c,field_wiw1c__c,field_2qzat__c,field_b1cxa__c__r,field_ncq72__c,field_42sl8__c,field_ua22f__c,
field_lxzkx__c,field_j3ro2__c,field_y74ak__c,field_mk1fa__c,field_of9qe__c__r,field_2mhq1__c__r,
t1.field_kvx2b__c,
field_5z1Wh__c,
case when t3.code_e in ('Y002001','C0301') then t3.cost_value else  0 end  as  farmout_amount,
t3.cost_value  cost_amount,
t1.field_0EuIa__c,
life_status,field_kg05c__c,field_r8qu9__c__r,field_tfeh7__c__r,
'' as regional_type,
field_j7N16__c,
field_0mn82__c,field_kfify__c,field_st4vh__c,field_g7ya1__c,field_iqha2__c,field_9necq__c,field_xvoay__c_filename,
field_cz768__c as field_6ohea__c,field_bgr8v__c as field_y1cnk__c__r,t1.create_time as field_2mhq1__c_create_time,
field_3lv8r__c,field_lzwcy__c__r_name,field_4w3eu__c,field_p83vd__c_r_name,field_r0w2v__c,field_rw1w5__c,field_8oa2s__c,
record_type,field_d1kft__c,field_is2a4__c,field_825cu__c,last_modified_time,field_knuxe__c,field_r1qli__c__r,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c     
from (
select 
id,field_eoks3__c,field_t1ec2__c,field_jqrsv__c,field_z4tcl__c,created_by__r_name,create_time,field_l6ncp__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,field_e9b8n__c,field_da57w__c,field_khw9g__c,field_5modd__c,field_9pr77__c,owner__r_name,
owner_department,name,field_i81wv__c,field_2zefw__c__r,field_2w5z5__c,field_1i5qf__c,field_0mxxl__c,field_iew44__c,field_5832e__c,field_5kcpr__c,field_cby7l__c,field_wiw1c__c,field_2qzat__c,field_b1cxa__c__r,field_ncq72__c,field_42sl8__c,field_ua22f__c,
field_lxzkx__c,field_j3ro2__c,field_y74ak__c,field_mk1fa__c,field_of9qe__c__r,field_2mhq1__c__r,field_5z1Wh__c,field_0EuIa__c,life_status,field_kg05c__c,field_r8qu9__c__r,field_tfeh7__c__r,field_j7N16__c,
field_0mn82__c,field_kfify__c,field_st4vh__c,field_g7ya1__c,field_iqha2__c,field_9necq__c,field_xvoay__c_filename,field_6ohea__c,field_y1cnk__c__r,field_3lv8r__c,field_lzwcy__c__r_name,field_4w3eu__c,field_p83vd__c_r_name,field_r0w2v__c,field_rw1w5__c,field_8oa2s__c,
record_type,field_d1kft__c,field_is2a4__c,field_825cu__c,last_modified_time,field_knuxe__c,field_r1qli__c__r,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
from dm_gis_uimp.dwd_crm_con_res 
) as t0 
left join (select id,field_kvx2b__c,field_0EuIa__c,field_cz768__c,field_bgr8v__c,create_time  from dm_gis_uimp.dwd_crm_opp_res ) as t1 
on t0.field_2mHQ1__c=t1.id 
left join (select str60,code from dm_gis_uimp.ods_pms_project ) as t2 
on t1.field_kvx2b__c=t2.str60 
left join (select code_b,code_e,cost_value from dm_gis_uimp.ods_pms_cost ) as t3 
on t2.code=t3.code_b 
) as t 
group by 
id,field_eoks3__c,field_t1ec2__c,field_jqrsv__c,field_z4tcl__c,created_by__r_name,create_time,field_l6ncp__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,field_e9b8n__c,field_da57w__c,field_khw9g__c,field_5modd__c,field_9pr77__c,owner__r_name,
owner_department,name,field_i81wv__c,field_2zefw__c__r,field_2w5z5__c,field_1i5qf__c,field_0mxxl__c,field_iew44__c,field_5832e__c,field_5kcpr__c,field_cby7l__c,field_wiw1c__c,field_2qzat__c,field_b1cxa__c__r,field_ncq72__c,field_42sl8__c,field_ua22f__c,
field_lxzkx__c,field_j3ro2__c,field_y74ak__c,field_mk1fa__c,field_of9qe__c__r,field_2mhq1__c__r,
field_kvx2b__c,
field_5z1Wh__c,
field_0EuIa__c,
life_status,field_kg05c__c,field_r8qu9__c__r,field_tfeh7__c__r,
regional_type,
field_j7N16__c,
field_0mn82__c,field_kfify__c,field_st4vh__c,field_g7ya1__c,field_iqha2__c,field_9necq__c,field_xvoay__c_filename,
field_6ohea__c,field_y1cnk__c__r,field_2mhq1__c_create_time,
field_3lv8r__c,field_lzwcy__c__r_name,field_4w3eu__c,field_p83vd__c_r_name,field_r0w2v__c,field_rw1w5__c,field_8oa2s__c,
record_type,field_d1kft__c,field_is2a4__c,field_825cu__c,last_modified_time,field_knuxe__c,field_r1qli__c__r,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c     
;



-- CRM销售合同基础表 (日分区存)
create table dm_gis_uimp.dwd_crm_con_base_df(
id	string comment 'id',
field_eoks3__c	string comment 'ECP合同编号',
field_t1ec2__c	string comment '标的数量',
field_jqrsv__c	string comment '产品方向',
field_z4tcl__c	string comment '产品类型',
created_by__r_name	string comment '创建人',
create_time	string comment '创建时间',
field_l6ncp__c	string comment '待回款金额',
field_4d17h__c	string comment '第二年付款比例',
field_ks47v__c	string comment '第三年付款比例',
field_7jr1w__c	string comment '第四年付款比例',
field_e9b8n__c	string comment '第一年付款比例',
field_da57w__c	string comment '分项合计（万元）',
field_khw9g__c	string comment '服务截止期限',
field_5modd__c	string comment '服务开始期限',
field_9pr77__c	string comment '付款/收款方式',
owner__r_name	string comment '负责人',
owner_department	string comment '负责人主属部门',
name	string comment '公司合同编号',
field_i81wv__c	string comment '供应商分项合计（万元）',
field_2zefw__c__r	string comment '国家',
field_2w5z5__c	string comment '合同标的',
field_1i5qf__c	string comment '合同标题',
field_0mxxl__c	string comment '合同大区',
field_iew44__c	string comment '合同归档',
field_5832e__c	string comment '合同归档日期',
field_5kcpr__c	string comment '合同金额(交通货运)（元）',
field_cby7l__c	string comment '合同金额（万元）',
field_wiw1c__c	string comment '合同类型',
field_2qzat__c	string comment '合同签订丙方',
field_b1cxa__c__r	string comment '合同签订甲方',
field_ncq72__c	string comment '合同签订乙方',
field_42sl8__c	string comment '合同签署路径',
field_ua22f__c	string comment '回款状态',
field_lxzkx__c	string comment '开票金额',
field_j3ro2__c	string comment '累计回款比例',
field_y74ak__c	string comment '累计回款金额（元）',
field_mk1fa__c	string comment '签订日期',
field_of9qe__c__r	string comment '区',
field_2mhq1__c__r	string comment '商机项目',
field_kvx2b__c	string comment '商机代码',
field_5z1Wh__c	string comment '财务代码',
farmout_amount	string comment '合同总分包金额（万元）',
cost_amount	string comment '合同总成本合计（万元）',
field_0EuIa__c	string comment '行业',
life_status	string comment '生命状态',
field_kg05c__c	string comment '实施项目',
field_r8qu9__c__r	string comment '省',
field_tfeh7__c__r	string comment '市',
regional_type	string comment '区域类型',
field_j7N16__c	string comment '双章版合同最后更新时间',
field_0mn82__c	string comment '是否背靠背',
field_kfify__c	string comment '是否代理',
field_st4vh__c	string comment '是否分包',
field_g7ya1__c	string comment '是否框架合同',
field_iqha2__c	string comment '是否新客户',
field_9necq__c	string comment '是否有合格收款权',
field_xvoay__c_filename	string comment '双章版合同附件',
field_6ohea__c	string comment '所属业务中心',
field_y1cnk__c__r	string comment '所属营销中心',
field_2mhq1__c_create_time string comment '商机创建时间',
field_3lv8r__c	string comment '项目方式',
field_lzwcy__c__r_name	string comment '项目经理',
field_4w3eu__c	string comment '项目毛利率(百分比)',
field_p83vd__c_r_name	string comment '项目实施经理',
field_r0w2v__c	string comment '续签合同',
field_rw1w5__c	string comment '业绩归属公司',
field_8oa2s__c	string comment '业绩归属时间',
record_type	string comment '业务类型',
field_d1kft__c	string comment '质保金额（元）',
field_is2a4__c	string comment '质保期',
field_825cu__c	string comment '自有产品占比',
last_modified_time	string comment '最后修改时间',
field_knuxe__c	string comment '最终合同通过时间',
field_r1qli__c__r	string comment '最终用户',
field_2mHQ1__c  string comment '商机项目ID',
owner string COMMENT '负责人ID',
field_kclkf__c string COMMENT '签单业绩确认方式',
field_k2wb3__c string COMMENT '业绩金额',
field_wea25__c string COMMENT '项目经理（数字孪生）' 
)
comment 'CRM销售合同基础表(日分区存)' 
PARTITIONED BY (inc_day STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 
insert overwrite table dm_gis_uimp.dwd_crm_con_base_df partition(inc_day='')
select 
id,field_eoks3__c,field_t1ec2__c,field_jqrsv__c,field_z4tcl__c,created_by__r_name,create_time,field_l6ncp__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,field_e9b8n__c,field_da57w__c,field_khw9g__c,field_5modd__c,field_9pr77__c,owner__r_name,
owner_department,name,field_i81wv__c,field_2zefw__c__r,field_2w5z5__c,field_1i5qf__c,field_0mxxl__c,field_iew44__c,field_5832e__c,field_5kcpr__c,
field_cby7l__c,
field_wiw1c__c,field_2qzat__c,field_b1cxa__c__r,field_ncq72__c,field_42sl8__c,field_ua22f__c,
field_lxzkx__c,field_j3ro2__c,field_y74ak__c,field_mk1fa__c,field_of9qe__c__r,field_2mhq1__c__r,
field_kvx2b__c,
field_5z1Wh__c,
farmout_amount,
cost_amount,
field_0EuIa__c,
life_status,field_kg05c__c,field_r8qu9__c__r,field_tfeh7__c__r,
regional_type,
field_j7N16__c,
field_0mn82__c,field_kfify__c,field_st4vh__c,field_g7ya1__c,field_iqha2__c,field_9necq__c,field_xvoay__c_filename,
field_6ohea__c,field_y1cnk__c__r,field_2mhq1__c_create_time,
field_3lv8r__c,field_lzwcy__c__r_name,field_4w3eu__c,field_p83vd__c_r_name,field_r0w2v__c,field_rw1w5__c,field_8oa2s__c,
record_type,field_d1kft__c,field_is2a4__c,field_825cu__c,last_modified_time,field_knuxe__c,field_r1qli__c__r,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
from dm_gis_uimp.dwd_crm_con_base
;


-- CRM销售合同基础表 (月分区存)
create table dm_gis_uimp.dwd_crm_con_base_mf(
id	string comment 'id',
field_eoks3__c	string comment 'ECP合同编号',
field_t1ec2__c	string comment '标的数量',
field_jqrsv__c	string comment '产品方向',
field_z4tcl__c	string comment '产品类型',
created_by__r_name	string comment '创建人',
create_time	string comment '创建时间',
field_l6ncp__c	string comment '待回款金额',
field_4d17h__c	string comment '第二年付款比例',
field_ks47v__c	string comment '第三年付款比例',
field_7jr1w__c	string comment '第四年付款比例',
field_e9b8n__c	string comment '第一年付款比例',
field_da57w__c	string comment '分项合计（万元）',
field_khw9g__c	string comment '服务截止期限',
field_5modd__c	string comment '服务开始期限',
field_9pr77__c	string comment '付款/收款方式',
owner__r_name	string comment '负责人',
owner_department	string comment '负责人主属部门',
name	string comment '公司合同编号',
field_i81wv__c	string comment '供应商分项合计（万元）',
field_2zefw__c__r	string comment '国家',
field_2w5z5__c	string comment '合同标的',
field_1i5qf__c	string comment '合同标题',
field_0mxxl__c	string comment '合同大区',
field_iew44__c	string comment '合同归档',
field_5832e__c	string comment '合同归档日期',
field_5kcpr__c	string comment '合同金额(交通货运)（元）',
field_cby7l__c	string comment '合同金额（万元）',
field_wiw1c__c	string comment '合同类型',
field_2qzat__c	string comment '合同签订丙方',
field_b1cxa__c__r	string comment '合同签订甲方',
field_ncq72__c	string comment '合同签订乙方',
field_42sl8__c	string comment '合同签署路径',
field_ua22f__c	string comment '回款状态',
field_lxzkx__c	string comment '开票金额',
field_j3ro2__c	string comment '累计回款比例',
field_y74ak__c	string comment '累计回款金额（元）',
field_mk1fa__c	string comment '签订日期',
field_of9qe__c__r	string comment '区',
field_2mhq1__c__r	string comment '商机项目',
field_kvx2b__c	string comment '商机代码',
field_5z1Wh__c	string comment '财务代码',
farmout_amount	string comment '合同总分包金额（万元）',
cost_amount	string comment '合同总成本合计（万元）',
field_0EuIa__c	string comment '行业',
life_status	string comment '生命状态',
field_kg05c__c	string comment '实施项目',
field_r8qu9__c__r	string comment '省',
field_tfeh7__c__r	string comment '市',
regional_type	string comment '区域类型',
field_j7N16__c	string comment '双章版合同最后更新时间',
field_0mn82__c	string comment '是否背靠背',
field_kfify__c	string comment '是否代理',
field_st4vh__c	string comment '是否分包',
field_g7ya1__c	string comment '是否框架合同',
field_iqha2__c	string comment '是否新客户',
field_9necq__c	string comment '是否有合格收款权',
field_xvoay__c_filename	string comment '双章版合同附件',
field_6ohea__c	string comment '所属业务中心',
field_y1cnk__c__r	string comment '所属营销中心',
field_2mhq1__c_create_time string comment '商机创建时间',
field_3lv8r__c	string comment '项目方式',
field_lzwcy__c__r_name	string comment '项目经理',
field_4w3eu__c	string comment '项目毛利率(百分比)',
field_p83vd__c_r_name	string comment '项目实施经理',
field_r0w2v__c	string comment '续签合同',
field_rw1w5__c	string comment '业绩归属公司',
field_8oa2s__c	string comment '业绩归属时间',
record_type	string comment '业务类型',
field_d1kft__c	string comment '质保金额（元）',
field_is2a4__c	string comment '质保期',
field_825cu__c	string comment '自有产品占比',
last_modified_time	string comment '最后修改时间',
field_knuxe__c	string comment '最终合同通过时间',
field_r1qli__c__r	string comment '最终用户',
field_2mHQ1__c  string comment '商机项目ID',
owner string COMMENT '负责人ID',
field_kclkf__c string COMMENT '签单业绩确认方式',
field_k2wb3__c string COMMENT '业绩金额',
field_wea25__c string COMMENT '项目经理（数字孪生）' 
)
comment 'CRM销售合同基础表(月分区)' 
PARTITIONED BY (inc_month STRING COMMENT "分区日期")
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- firstDay=`date -d "0 day ago" +%Y%m%d`
-- statMonth=`date -d "1 day ago" +%Y%m`
-- echo $firstDay $statMonth
-- 
insert overwrite table dm_gis_uimp.dwd_crm_con_base_mf partition(inc_month='$statMonth')
select 
id,field_eoks3__c,field_t1ec2__c,field_jqrsv__c,field_z4tcl__c,created_by__r_name,create_time,field_l6ncp__c,field_4d17h__c,field_ks47v__c,field_7jr1w__c,field_e9b8n__c,field_da57w__c,field_khw9g__c,field_5modd__c,field_9pr77__c,owner__r_name,
owner_department,name,field_i81wv__c,field_2zefw__c__r,field_2w5z5__c,field_1i5qf__c,field_0mxxl__c,field_iew44__c,field_5832e__c,field_5kcpr__c,
field_cby7l__c,
field_wiw1c__c,field_2qzat__c,field_b1cxa__c__r,field_ncq72__c,field_42sl8__c,field_ua22f__c,
field_lxzkx__c,field_j3ro2__c,field_y74ak__c,field_mk1fa__c,field_of9qe__c__r,field_2mhq1__c__r,
field_kvx2b__c,
field_5z1Wh__c,
farmout_amount,
cost_amount,
field_0EuIa__c,
life_status,field_kg05c__c,field_r8qu9__c__r,field_tfeh7__c__r,
regional_type,
field_j7N16__c,
field_0mn82__c,field_kfify__c,field_st4vh__c,field_g7ya1__c,field_iqha2__c,field_9necq__c,field_xvoay__c_filename,
field_6ohea__c,field_y1cnk__c__r,field_2mhq1__c_create_time,
field_3lv8r__c,field_lzwcy__c__r_name,field_4w3eu__c,field_p83vd__c_r_name,field_r0w2v__c,field_rw1w5__c,field_8oa2s__c,
record_type,field_d1kft__c,field_is2a4__c,field_825cu__c,last_modified_time,field_knuxe__c,field_r1qli__c__r,field_2mHQ1__c,owner,field_kClKF__c,field_K2wb3__c,field_Wea25__c    
from dm_gis_uimp.dwd_crm_con_base_df where inc_day='$firstDay' 
;




--------------------------------------
--------------------------------------
-- 20231023  销售合同补充协议 CRM-CON-SA
drop table if exists dm_gis_uimp.dwd_crm_con_sa;
create table dm_gis_uimp.dwd_crm_con_sa(
id	string comment '_id',
owner_name	string comment '合同补充协议负责人',
field_Meo49__c	string comment '商机项目ID',
field_f2e2X__c__r	string comment '原合同编码',
field_f2e2X__c	string comment '原合同ID',
field_fu718__c	string comment 'ECP合同',
field_7VB14__c	string comment '服务开始期限',
field_2dmBb__c	string comment '服务截止期限',
field_obhs1__c	string comment '补充协议履约义务总金额（元）',
field_36v11__c	string comment '标的数量',
field_ced8W__c	string comment 'SAP客户编码',
field_lO8hy__c	string comment '所属业务中心',
field_Wb00G__c	string comment '原合同已回款金额（元）',
field_6k2yD__c	string comment '第四年付款比例',
field_tteuC__c	string comment '第三年付款比例',
field_w0vbw__c	string comment '质保期',
field_eqd1i__c	string comment '协议类型',
field_82UX0__c	string comment '合同格式',
last_modified_time	string comment '最后修改时间',
life_status	string comment '生命状态',
field_28y51__c	string comment '变更后合同金额（元）',
field_ak4gE__c	string comment '是否涉及收入冲销',
field_11T7n__c	string comment '业务类型（BILL使用）',
field_jM31g__c	string comment '是否有合格收款权',
field_2be93__c	string comment '原合同已收入金额（元）',
field_DbsZU__c	string comment 'ECP合同编号',
owner_department	string comment '负责人主属部门',
field_7hw2R__c	string comment '合同标的',
create_time	string comment '创建时间',
field_15owF__c	string comment '第二年付款比例',
field_4ZwY9__c	string comment 'SAP项目代码',
name	string comment '合同补充协议编码',
field_Gwmlx__c	string comment '业绩金额',
field_12cdO__c	string comment '签单业绩确认方式',
field_PkFyS__c	string comment '回款是否BKB终端客户',
field_99SPb__c	string comment '第一年付款比例',
field_bj3Jt__c	string comment '标的类型',
field_6P3H1__c	string comment '双章版附件首次上传时间',
field_48ca8__c	string comment '付款/收款方式',
record_type	string comment '业务类型',
field_R9q9s__c	string comment '原合同金额',
field_8GNoR__c	string comment '签订客户',
field_082Po__c	string comment '专项客户编码',
field_jaNlM__c	string comment '所属营销中心',
field_R1z8x__c	string comment '是否框架合同'
)
comment '销售合同补充协议 CRM-CON-SA解析' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期:yyyyMMdd')
ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


-- 
insert overwrite table dm_gis_uimp.dwd_crm_con_sa partition(inc_day='') 
select 
get_json_object(content,'$._id')	id,
get_json_object(get_json_object(content,'$.owner__r'),'$.name')  owner_name,
get_json_object(content,'$.field_Meo49__c')	field_Meo49__c,
get_json_object(content,'$.field_f2e2X__c__r')	field_f2e2X__c__r,
get_json_object(content,'$.field_f2e2X__c')	field_f2e2X__c,
get_json_object(content,'$.field_fu718__c')	field_fu718__c,
get_json_object(content,'$.field_7VB14__c')	field_7VB14__c,
get_json_object(content,'$.field_2dmBb__c')	field_2dmBb__c,
get_json_object(content,'$.field_obhs1__c')	field_obhs1__c,
get_json_object(content,'$.field_36v11__c')	field_36v11__c,
get_json_object(content,'$.field_ced8W__c')	field_ced8W__c,
get_json_object(content,'$.field_lO8hy__c')	field_lO8hy__c,
get_json_object(content,'$.field_Wb00G__c')	field_Wb00G__c,
get_json_object(content,'$.field_6k2yD__c')	field_6k2yD__c,
get_json_object(content,'$.field_tteuC__c')	field_tteuC__c,
get_json_object(content,'$.field_w0vbw__c')	field_w0vbw__c,
get_json_object(content,'$.field_eqd1i__c')	field_eqd1i__c,
get_json_object(content,'$.field_82UX0__c')	field_82UX0__c,
get_json_object(content,'$.last_modified_time')	last_modified_time,
get_json_object(content,'$.life_status')	life_status,
get_json_object(content,'$.field_28y51__c')	field_28y51__c,
get_json_object(content,'$.field_ak4gE__c')	field_ak4gE__c,
get_json_object(content,'$.field_11T7n__c')	field_11T7n__c,
get_json_object(content,'$.field_jM31g__c')	field_jM31g__c,
get_json_object(content,'$.field_2be93__c')	field_2be93__c,
get_json_object(content,'$.field_DbsZU__c')	field_DbsZU__c,
get_json_object(content,'$.owner_department')	owner_department,
get_json_object(content,'$.field_7hw2R__c')	field_7hw2R__c,
get_json_object(content,'$.create_time')	create_time,
get_json_object(content,'$.field_15owF__c')	field_15owF__c,
get_json_object(content,'$.field_4ZwY9__c')	field_4ZwY9__c,
get_json_object(content,'$.name')	name,
get_json_object(content,'$.field_Gwmlx__c')	field_Gwmlx__c,
get_json_object(content,'$.field_12cdO__c')	field_12cdO__c,
get_json_object(content,'$.field_PkFyS__c')	field_PkFyS__c,
get_json_object(content,'$.field_99SPb__c')	field_99SPb__c,
get_json_object(content,'$.field_bj3Jt__c')	field_bj3Jt__c,
get_json_object(content,'$.field_6P3H1__c')	field_6P3H1__c,
get_json_object(content,'$.field_48ca8__c')	field_48ca8__c,
get_json_object(content,'$.record_type')	record_type,
get_json_object(content,'$.field_R9q9s__c')	field_R9q9s__c,
get_json_object(content,'$.field_8GNoR__c')	field_8GNoR__c,
get_json_object(content,'$.field_082Po__c')	field_082Po__c,
get_json_object(content,'$.field_jaNlM__c')	field_jaNlM__c,
get_json_object(content,'$.field_R1z8x__c')	field_R1z8x__c 
from dm_gis_uimp.ods_issp_cmr_con_sa 
where inc_day=''
;


-- dm_gis_uimp.dwd_crm_con_sa_res
drop table if exists dm_gis_uimp.dwd_crm_con_sa_res;
create table dm_gis_uimp.dwd_crm_con_sa_res(
id	string comment '_id',
owner_name	string comment '合同补充协议负责人',
field_Meo49__c	string comment '商机项目ID',
field_f2e2X__c__r	string comment '原合同编码',
field_f2e2X__c	string comment '原合同ID',
field_fu718__c	string comment 'ECP合同',
field_7VB14__c	string comment '服务开始期限',
field_2dmBb__c	string comment '服务截止期限',
field_obhs1__c	string comment '补充协议履约义务总金额（元）',
field_36v11__c	string comment '标的数量',
field_ced8W__c	string comment 'SAP客户编码',
field_lO8hy__c	string comment '所属业务中心',
field_Wb00G__c	string comment '原合同已回款金额（元）',
field_6k2yD__c	string comment '第四年付款比例',
field_tteuC__c	string comment '第三年付款比例',
field_w0vbw__c	string comment '质保期',
field_eqd1i__c	string comment '协议类型',
field_82UX0__c	string comment '合同格式',
last_modified_time	string comment '最后修改时间',
life_status	string comment '生命状态',
field_28y51__c	string comment '变更后合同金额（元）',
field_ak4gE__c	string comment '是否涉及收入冲销',
field_11T7n__c	string comment '业务类型（BILL使用）',
field_jM31g__c	string comment '是否有合格收款权',
field_2be93__c	string comment '原合同已收入金额（元）',
field_DbsZU__c	string comment 'ECP合同编号',
owner_department	string comment '负责人主属部门',
field_7hw2R__c	string comment '合同标的',
create_time	string comment '创建时间',
field_15owF__c	string comment '第二年付款比例',
field_4ZwY9__c	string comment 'SAP项目代码',
name	string comment '合同补充协议编码',
field_Gwmlx__c	string comment '业绩金额',
field_12cdO__c	string comment '签单业绩确认方式',
field_PkFyS__c	string comment '回款是否BKB终端客户',
field_99SPb__c	string comment '第一年付款比例',
field_bj3Jt__c	string comment '标的类型',
field_6P3H1__c	string comment '双章版附件首次上传时间',
field_48ca8__c	string comment '付款/收款方式',
record_type	string comment '业务类型',
field_R9q9s__c	string comment '原合同金额',
field_8GNoR__c	string comment '签订客户',
field_082Po__c	string comment '专项客户编码',
field_jaNlM__c	string comment '所属营销中心',
field_R1z8x__c	string comment '是否框架合同'
)
comment '销售合同补充协议 CRM-CON-SA解析res' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

-- 首次跑历史
insert overwrite table dm_gis_uimp.dwd_crm_con_sa_res 
select 
id,owner_name,field_Meo49__c,field_f2e2X__c__r,field_f2e2X__c,field_fu718__c,field_7VB14__c,field_2dmBb__c,field_obhs1__c,field_36v11__c,field_ced8W__c,field_lO8hy__c,field_Wb00G__c,field_6k2yD__c,field_tteuC__c,field_w0vbw__c,
field_eqd1i__c,field_82UX0__c,last_modified_time,life_status,field_28y51__c,field_ak4gE__c,field_11T7n__c,field_jM31g__c,field_2be93__c,field_DbsZU__c,owner_department,field_7hw2R__c,create_time,field_15owF__c,field_4ZwY9__c,name,field_Gwmlx__c,field_12cdO__c,field_PkFyS__c,field_99SPb__c,field_bj3Jt__c,field_6P3H1__c,field_48ca8__c,record_type,field_R9q9s__c,field_8GNoR__c,field_082Po__c,field_jaNlM__c,field_R1z8x__c  
from (
select 
row_number() over(partition by id order by last_modified_time desc) as rn,
id,owner_name,field_Meo49__c,field_f2e2X__c__r,field_f2e2X__c,field_fu718__c,field_7VB14__c,field_2dmBb__c,field_obhs1__c,field_36v11__c,field_ced8W__c,field_lO8hy__c,field_Wb00G__c,field_6k2yD__c,field_tteuC__c,field_w0vbw__c,
field_eqd1i__c,field_82UX0__c,last_modified_time,life_status,field_28y51__c,field_ak4gE__c,field_11T7n__c,field_jM31g__c,field_2be93__c,field_DbsZU__c,owner_department,field_7hw2R__c,create_time,field_15owF__c,field_4ZwY9__c,name,field_Gwmlx__c,field_12cdO__c,field_PkFyS__c,field_99SPb__c,field_bj3Jt__c,field_6P3H1__c,field_48ca8__c,record_type,field_R9q9s__c,field_8GNoR__c,field_082Po__c,field_jaNlM__c,field_R1z8x__c      
from dm_gis_uimp.dwd_crm_con_sa 
) as t where t.rn=1 and t.life_status!='invalid'
;


-- 每日跑
insert overwrite table dm_gis_uimp.dwd_crm_con_sa_res 
select 
id,owner_name,field_Meo49__c,field_f2e2X__c__r,field_f2e2X__c,field_fu718__c,field_7VB14__c,field_2dmBb__c,field_obhs1__c,field_36v11__c,field_ced8W__c,field_lO8hy__c,field_Wb00G__c,field_6k2yD__c,field_tteuC__c,field_w0vbw__c,
field_eqd1i__c,field_82UX0__c,last_modified_time,life_status,field_28y51__c,field_ak4gE__c,field_11T7n__c,field_jM31g__c,field_2be93__c,field_DbsZU__c,owner_department,field_7hw2R__c,create_time,field_15owF__c,field_4ZwY9__c,name,field_Gwmlx__c,field_12cdO__c,field_PkFyS__c,field_99SPb__c,field_bj3Jt__c,field_6P3H1__c,field_48ca8__c,record_type,field_R9q9s__c,field_8GNoR__c,field_082Po__c,field_jaNlM__c,field_R1z8x__c    
from (
select 
row_number() over(partition by id order by last_modified_time desc) as rn,
id,owner_name,field_Meo49__c,field_f2e2X__c__r,field_f2e2X__c,field_fu718__c,field_7VB14__c,field_2dmBb__c,field_obhs1__c,field_36v11__c,field_ced8W__c,field_lO8hy__c,field_Wb00G__c,field_6k2yD__c,field_tteuC__c,field_w0vbw__c,
field_eqd1i__c,field_82UX0__c,last_modified_time,life_status,field_28y51__c,field_ak4gE__c,field_11T7n__c,field_jM31g__c,field_2be93__c,field_DbsZU__c,owner_department,field_7hw2R__c,create_time,field_15owF__c,field_4ZwY9__c,name,field_Gwmlx__c,field_12cdO__c,field_PkFyS__c,field_99SPb__c,field_bj3Jt__c,field_6P3H1__c,field_48ca8__c,record_type,field_R9q9s__c,field_8GNoR__c,field_082Po__c,field_jaNlM__c,field_R1z8x__c    
from (select 
id,owner_name,field_Meo49__c,field_f2e2X__c__r,field_f2e2X__c,field_fu718__c,field_7VB14__c,field_2dmBb__c,field_obhs1__c,field_36v11__c,field_ced8W__c,field_lO8hy__c,field_Wb00G__c,field_6k2yD__c,field_tteuC__c,field_w0vbw__c,
field_eqd1i__c,field_82UX0__c,last_modified_time,life_status,field_28y51__c,field_ak4gE__c,field_11T7n__c,field_jM31g__c,field_2be93__c,field_DbsZU__c,owner_department,field_7hw2R__c,create_time,field_15owF__c,field_4ZwY9__c,name,field_Gwmlx__c,field_12cdO__c,field_PkFyS__c,field_99SPb__c,field_bj3Jt__c,field_6P3H1__c,field_48ca8__c,record_type,field_R9q9s__c,field_8GNoR__c,field_082Po__c,field_jaNlM__c,field_R1z8x__c  
  from dm_gis_uimp.dwd_crm_con_sa where inc_day='$firstDay' 
union all 
select 
id,owner_name,field_Meo49__c,field_f2e2X__c__r,field_f2e2X__c,field_fu718__c,field_7VB14__c,field_2dmBb__c,field_obhs1__c,field_36v11__c,field_ced8W__c,field_lO8hy__c,field_Wb00G__c,field_6k2yD__c,field_tteuC__c,field_w0vbw__c,
field_eqd1i__c,field_82UX0__c,last_modified_time,life_status,field_28y51__c,field_ak4gE__c,field_11T7n__c,field_jM31g__c,field_2be93__c,field_DbsZU__c,owner_department,field_7hw2R__c,create_time,field_15owF__c,field_4ZwY9__c,name,field_Gwmlx__c,field_12cdO__c,field_PkFyS__c,field_99SPb__c,field_bj3Jt__c,field_6P3H1__c,field_48ca8__c,record_type,field_R9q9s__c,field_8GNoR__c,field_082Po__c,field_jaNlM__c,field_R1z8x__c  
  from dm_gis_uimp.dwd_crm_con_sa_res 
 ) as t0 
) as t where t.rn=1  and t.life_status!='invalid'
;