-- 
-- 需求方：林中莉(01423677)
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2023-06-27
-- 任务信息： 
-- 

-- ssp2审批时效
-- dm_gis_uimp.ods_plf_form_life    
    -- 过滤条件
    -- 1.ods_plf_form_life 表的order_no需要存在于ods_plf_form_body表中。
    -- 2.inc_day大于等于2023-01-01。(20230703修改 inc_day>='20220701'  create_time>'2022-07-01')
    -- 3.operate_type包含20、50、70、71、76、77
    -- 4.operate_desc包含文案：%ECP成功归档%、%编辑提交%、%初审通过%、%复审通过%、%初审驳回%、%复审驳回%
-- dm_gis_uimp.ods_plf_form_body  inc_day为最新的数据
-- dm_gis_uimp.ods_issp_emp_data   无
-- 关联方式：
    -- 1.ods_plf_form_life.order_no关联ods_plf_form_body.order_no
    -- 2.ods_plf_form_life.create_user关联ods_issp_emp_data.emp_num
    -- 3.ods_plf_form_body.apply_id关联ods_issp_emp_data.emp_num

-- select order_no,operate_desc,operate_type,operate_result,operate_cue,create_user,create_time,id,inc_day from dm_gis_uimp.ods_plf_form_life 
-- select order_no,order_status,order_type_code from dm_gis_uimp.ods_plf_form_body
-- select emp_num,emp_name from dm_gis_uimp.ods_issp_emp_data

CREATE  TABLE dm_gis_uimp.dwd_ft_ssp2_approval_time(
order_no	string comment'单据编号',
order_status	string comment'单据最新的状态(新建 10;待提交（逐级） 18;待提交（直送） 20;待发送ECP 40;推送ECP失败 41;ECP处理中 50;待推送初审 60;初审中 70;初审通过 79;复审通过 80;过账成功 82;过账失败 81;已付款 90;支付作废 91;支付退票 93;已删除 21)',
node_name	string comment'节点名称',
order_link	string comment'流程环节',
approval_result	string comment'审批结果',
approval_content	string comment'审批内容',
approval_user	string comment'审批人工号',
approval_name	string comment'审批人姓名',
approval_start_time	string comment'开始审批时间',
approval_end_time	string comment'结束审批时间',
approval_duration	string comment'办理时长（小时）',
approval_duration_workday	string comment'剔除节假日的办理时长（小时）',
order_type_base	string comment'表单定义大类',
apply_user	string comment'申请人',
apply_name	string comment'申请人姓名',
bill_approval_id	string comment'主键ID' 
) COMMENT 'ssp2审批时效表' 
PARTITIONED BY (`inc_day` string comment '')
stored as parquet 
tblproperties ('parquet.compression'='snappy')
;



drop table if exists dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time;
create table dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time as 
select 
t0.order_no,operate_desc,operate_type,operate_result,operate_cue,create_user,create_user1,create_time,id,inc_day,
order_status,order_type_code,apply_id,
t2.emp_name as t2_emp_name,
t3.emp_name as t3_emp_name 
from (
select order_no,operate_desc,operate_type,operate_result,operate_cue,create_user,split(create_user,'/')[0] as create_user1,create_time,id,inc_day from dm_gis_uimp.ods_plf_form_life 
where inc_day>='20220701' and operate_type in ('20','50','70','71','76','77') and create_time>'2022-07-01' 
and operate_desc regexp('ECP成功归档|编辑提交|初审通过|复审通过|初审驳回|复审驳回')
) as t0 
left join 
(select order_no,order_status,order_type_code,apply_id  from dm_gis_uimp.ods_plf_form_body where inc_day='$firstDay') as t1 
on t0.order_no=t1.order_no 
left join 
( select emp_num,emp_name from dm_gis_uimp.ods_issp_emp_data ) as t2 
on t0.create_user1=t2.emp_num 
left join 
( select emp_num,emp_name from dm_gis_uimp.ods_issp_emp_data ) as t3 
on t1.apply_id=t3.emp_num 
where t1.order_no is not null 
;

drop table if exists dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_1;
create table dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_1 as 
select t0.order_no,t0.operate_desc,t0.operate_type,t0.operate_result,t0.operate_cue,t0.create_user,t0.create_user1,t0.create_time,t0.id,t0.inc_day,
t0.order_status,t0.order_type_code,t0.apply_id,t0.t2_emp_name,t0.t3_emp_name,
t1.order_no as t1_order_no,t1.operate_desc as t1_operate_desc,
t1.operate_type as t1_operate_type,t1.operate_result as t1_operate_result,
t1.operate_cue as t1_operate_cue,t1.create_user as t1_create_user,
t1.create_user1 as t1_create_user1,t1.create_time as t1_create_time,
t1.id as t1_id,t1.inc_day as t1_inc_day,
t1.order_status as t1_order_status,t1.order_type_code as t1_order_type_code,t1.apply_id as t1_apply_id,
t1.t2_emp_name as t1_t2_emp_name,t1.t3_emp_name as t1_t3_emp_name
from (
select order_no,operate_desc,operate_type,operate_result,operate_cue,create_user,create_user1,create_time,id,inc_day,
order_status,order_type_code,apply_id,t2_emp_name,t3_emp_name 
from dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time 
where operate_desc regexp('ECP成功归档|编辑提交|初审通过|复审通过|初审驳回|复审驳回') ) as t0 
left join (
select order_no,operate_desc,operate_type,operate_result,operate_cue,create_user,create_user1,create_time,id,inc_day,
order_status,order_type_code,apply_id,t2_emp_name,t3_emp_name 
from dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time 
where operate_desc regexp('初审通过|复审通过|初审驳回|复审驳回') ) as t1 
on t0.order_no=t1.order_no
;


drop table if exists dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_2;
create table dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_2 as 
select 
t1_order_no,t1_operate_desc,t1_operate_type,t1_operate_result,t1_operate_cue,t1_create_user,t1_create_time,t1_id,t1_inc_day,
t1_order_status,t1_order_type_code,t1_apply_id,
t1_t2_emp_name,
t1_t3_emp_name,
operate_desc,
create_time,
create_time1,t1_create_time1,
t1.d_date as lab1,t2.d_date as lab2 
from (select 
t1_order_no,t1_operate_desc,t1_operate_type,t1_operate_result,t1_operate_cue,t1_create_user,t1_create_time,t1_id,t1_inc_day,
t1_order_status,t1_order_type_code,t1_apply_id,
t1_t2_emp_name,
t1_t3_emp_name,
operate_desc,
create_time,
substr(create_time,1,10) as create_time1,substr(t1_create_time,1,10) as t1_create_time1 
from dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_1    
where inc_day<=t1_inc_day and create_time<=t1_create_time 
and ((operate_desc regexp('ECP成功归档|编辑提交|复审驳回') and t1_operate_desc  regexp('初审通过|初审驳回') ) or (operate_desc regexp('初审通过') and t1_operate_desc  regexp('复审通过|复审驳回') ))
) as t0 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.create_time1=t1.d_date 
left join (select d_date from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t2 
on t0.t1_create_time1=t2.d_date 
;



drop table if exists dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_2_workday;
create table dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_2_workday stored as parquet as 
select start_date,end_date,pos,real_date,is_workday 
from (
select
  start_date,end_date,pos,date_add(start_date, pos) as real_date
FROM
  (
    select create_time1 as start_date,t1_create_time1 as end_date
    from dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_2 
    group by create_time1,t1_create_time1 
  ) tmp lateral view posexplode(split(space(datediff(end_date, start_date)), '')) t as pos,val
) as t0 
left join (select d_date,is_workday from dm_gis_uimp.dim_not_work_day where is_workday='1.0') as t1 
on t0.real_date=t1.d_date 
;


drop table if exists dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_3;
create table dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_3 stored as parquet as 
select 
t1_order_no as order_no,
t1_order_status as order_status,
t1_operate_desc as node_name,
t1_operate_type as order_link,
t1_operate_result as approval_result,
t1_operate_cue as approval_content,
t1_create_user as approval_user,
t1_t2_emp_name as approval_name,
create_time as approval_start_time,
t1_create_time as approval_end_time,
cast((unix_timestamp(t1_create_time)-unix_timestamp(create_time))/(60*60) as decimal(10,2)) as approval_duration,
if(approval_duration_t<0,0,cast(approval_duration_t as decimal(10,2)) ) as approval_duration_workday,
t1_order_type_code as order_type_base,
t1_apply_id as apply_user,
t1_t3_emp_name as apply_name,
t1_id as bill_approval_id 
from (
select 
t1_order_no,t1_operate_desc,t1_operate_type,t1_operate_result,t1_operate_cue,t1_create_user,t1_create_time,t1_id,t1_inc_day,
t1_order_status,t1_order_type_code,t1_apply_id,
t1_t2_emp_name,
t1_t3_emp_name,
operate_desc,
create_time,
create_time1,t1_create_time1,
case when (lab1 is null and lab2 is null) then ((unix_timestamp(t1_create_time)-unix_timestamp(create_time))/(60*60)+(-notworkdays)*24) 
when (lab1 is not null and lab2 is null) then ((unix_timestamp(t1_create_time)-unix_timestamp(create_time))/(60*60)+(-notworkdays+1)*24) 
when (lab1 is null and lab2 is not null) then ((unix_timestamp(t1_create_time)-unix_timestamp(create_time))/(60*60)+(-notworkdays+1)*24) 
when (lab1 is not null and lab2 is not null and t1_create_time1=create_time1) then ((unix_timestamp(t1_create_time)-unix_timestamp(create_time))/(60*60)+(-notworkdays+1)*24) 
when (lab1 is not null and lab2 is not null and t1_create_time1<>create_time1) then ((unix_timestamp(t1_create_time)-unix_timestamp(create_time))/(60*60)+(-notworkdays+2)*24) 
else null end as  approval_duration_t 
from dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_2 as t0 
left join (select start_date,end_date,sum(if(is_workday>0,is_workday,0)) as notworkdays from dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_2_workday group by start_date,end_date ) as t1 
on t0.create_time1=t1.start_date and t0.t1_create_time1=t1.end_date 
) as t 
;


insert overwrite table dm_gis_uimp.dwd_ft_ssp2_approval_time partition(inc_day='$firstDay') 
select 
order_no,
order_status,
node_name,
order_link,
approval_result,
approval_content,
approval_user,
approval_name,
approval_start_time,
approval_end_time,
approval_duration,
approval_duration_workday,
order_type_base,
apply_user,
apply_name,
bill_approval_id 
from (select 
order_no,
order_status,
node_name,
order_link,
approval_result,
approval_content,
approval_user,
approval_name,
approval_start_time,
approval_end_time,
approval_duration,
approval_duration_workday,
order_type_base,
apply_user,
apply_name,
bill_approval_id,
row_number() over(partition by order_no,node_name,bill_approval_id order by approval_duration asc )  as rn 
from  dm_gis_uimp.tmp_dwd_ft_ssp2_approval_time_3  
) as t where t.rn=1
;