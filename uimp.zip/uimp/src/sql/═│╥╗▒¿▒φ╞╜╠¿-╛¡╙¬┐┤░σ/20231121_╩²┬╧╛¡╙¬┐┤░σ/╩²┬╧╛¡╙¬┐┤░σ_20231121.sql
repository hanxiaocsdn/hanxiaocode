
-- 
-- 需求方：林中莉(01423677)
-- 需求： 
-- @author 张小琼 （01416344）
-- Created on 2023-11-21
-- 任务信息： ID：914299 数字孪生业务线经营管理看板
-- 

-- A表  dm_gis_uimp.dws_collection_performance  回款表  T-1天
-- B表  dm_gis_uimp.dws_income_performance  收入表  T-1天
-- C表  dm_gis_uimp.dws_sign_bill_performance  签单表
-- D表	dm_gis_uimp.dws_personal_travel_receive_detail 个人差旅招待统计表	T-1月		
-- E表	dm_gis_uimp.ods_issp_org_data_df 组织-主表	T-1天	is_valid等于Y（待开发by小琼，取ods_issp_org_data中org_name包含“丰图科技”的数据按天分区，生成df表）
-- F表	dm_gis_uimp.ods_issp_org_data_virtual 组织-虚拟组织子表	T-1天		提供成本中心编码和组织ID的关系 （衡鉴系统暂不涉及此表）
-- G表	dm_gis_uimp.dwd_ft_emp_out_month 丰图外包人员-主表	T-1月		每月1号快照表
-- H表	dm_gis_uimp.dwd_issp_emp_data_month 人员主表-通用字段	T-1月		每月1号快照表（待开发by小琼）
-- I表	ods_ft_ers_form_base_area_data	T-1天	 （衡鉴系统暂不涉及此表）
-- J表  丰图管报明细表
-- K表  预算剩余额度表
-- L表  商机所属营销中心代码组织映射表  1年更新2~3次，数据由产品提供，在衡鉴平台维护此维表
-- M表	各组织成本与人数表	T-1天		（待开发by小琼）组织ID，组织父级ID，组织简称，薪酬成本，差旅招待费用，正编人数，外包人数，销售人数	
-- N表	dm_gis_uimp.dwd_issp_emp_data_ext_month 人员主表-非通用字段	T-1月		每月1号快照表（待开发by小琼）
-- O表	dm_gis_uimp.ods_sap_zbseg SAP凭证表	T-1天		
-- P表	ods_ft_ers_form_expense_area_data	T-1天		
-- Q表	ods_efp_cost	T-1天		kostl为成本中心编码，需去重


-- S1表	组织业绩年度目标  dm_gis_uimp.ods_csv_org_cost_s1
-- S2表	组织ROI目标   dm_gis_uimp.ods_csv_org_cost_s2
-- S3表	销售个人业绩目标  dm_gis_uimp.ods_csv_org_cost_s3
-- S4表	销售个人薪酬   dm_gis_uimp.ods_csv_org_cost_s4
-- S5表	组织分摊比例   dm_gis_uimp.ods_csv_org_cost_s5
-- S6表	机酒行程单   dm_gis_uimp.ods_csv_org_cost_s6
-- S7表	组织成本科目分类表   dm_gis_uimp.ods_csv_org_cost_s7

-- S1表,组织业绩年度目标
create table if not exists  dm_gis_uimp.ods_csv_org_cost_s1(
yearly string comment '年度',
target_type string comment '目标类型',
org_id string comment '组织ID',	
org_name string comment '组织名称',		
target_amount string comment '目标金额_万元' 
)
COMMENT 'S1表,组织业绩年度目标'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;



-- S2表,组织ROI目标
create table if not exists  dm_gis_uimp.ods_csv_org_cost_s2(
yearly string comment '年度',
target_type string comment '目标类型',
org_id string comment '组织ID',	
org_name string comment '组织名称',		
target_amount string comment '目标金额_万元' 
)
COMMENT 'S2表,组织ROI目标'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;


-- S3表,销售个人业绩目标
create table if not exists  dm_gis_uimp.ods_csv_org_cost_s3(
yearly string comment '年度',
target_type string comment '目标类型',
emp_no string comment '员工工号',	
emp_name string comment '员工姓名',	
target_amount string comment '目标金额_万元' 
)
COMMENT 'S3表,销售个人业绩目标'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;


-- S4表,销售个人薪酬
create table if not exists  dm_gis_uimp.ods_csv_org_cost_s4(
yearly string comment '年度',
emp_no string comment '员工工号',	
emp_name string comment '员工姓名',	
target_amount string comment '累计人力薪酬_万元' 
)
COMMENT 'S4表,销售个人薪酬'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;



-- S5表,组织分摊比例
create table if not exists  dm_gis_uimp.ods_csv_org_cost_s5(
year_month string comment '年度月份',
src_org_id string comment '来源组织ID',	
src_org_name string comment '来源组织名称',	
dest_org_id string comment '目标组织ID',	
dest_org_name string comment '目标组织名称',
share_ratio string comment '分摊比例' 
)
COMMENT 'S5表,组织分摊比例'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;


-- S6表,机酒行程单
create table if not exists  dm_gis_uimp.ods_csv_org_cost_s6(
order_no string comment '订单号',
order_time string comment '预订时间',	
order_status string comment '订单状态',	
fly_name string comment '乘机人姓名',	
fly_job_no string comment '乘机人工号',
cost_center string comment '费用成本中心',
order_amount string comment '订单总价'
)
COMMENT 'S6表,机酒行程单'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;


-- S7表,组织成本科目分类表
create table if not exists  dm_gis_uimp.ods_csv_org_cost_s7(
hkont string comment '总账科目',
hkontname string comment '科目名称',
sort string comment '分类',
endday string comment '适用时间' 
)
COMMENT 'S7表,组织成本科目分类表'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;



-- 
LOAD DATA  INPATH '/user/01416344/upload/测试数据_S1组织业绩年度目标.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s1 partition (inc_day='20231121');
LOAD DATA  INPATH '/user/01416344/upload/测试数据_S2_人力薪酬效能目标目标.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s2 partition (inc_day='20231121');
LOAD DATA  INPATH '/user/01416344/upload/测试数据_S3_销售个人业绩目标.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s3 partition (inc_day='20231121');
LOAD DATA  INPATH '/user/01416344/upload/测试数据_S4_销售个人薪酬.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s4 partition (inc_day='20231121');
LOAD DATA  INPATH '/user/01416344/upload/测试数据_S5_组织分摊比例.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s5 partition (inc_day='20231121');
LOAD DATA  INPATH '/user/01416344/upload/测试数据_S6_数字孪生机票和酒店行程单.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s6 partition (inc_day='20231121');

-- 2023.12.5
LOAD DATA  INPATH '/user/01416344/upload/测试数据_S1组织业绩年度目标.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s1 partition (inc_day='20231201');

-- 2023.12.25 
alter table dm_gis_uimp.ods_csv_org_cost_s1 drop partition(inc_day='20231121');
alter table dm_gis_uimp.ods_csv_org_cost_s3 drop partition(inc_day='20231121');
alter table dm_gis_uimp.ods_csv_org_cost_s5 drop partition(inc_day='20231121');
alter table dm_gis_uimp.ods_csv_org_cost_s6 drop partition(inc_day='20231121');
LOAD DATA  INPATH '/user/01416344/upload/生产数据_S1组织年度目标_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s1 partition (inc_day='20231225');
LOAD DATA  INPATH '/user/01416344/upload/生产数据_S3_销售个人业绩目标_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s3 partition (inc_day='20231225');
LOAD DATA  INPATH '/user/01416344/upload/生产数据_S5_组织分摊比例_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s5 partition (inc_day='20231225');
LOAD DATA  INPATH '/user/01416344/upload/生产数据_S6_数字孪生机票和酒店行程单_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s6 partition (inc_day='20231225');

LOAD DATA  INPATH '/user/01416344/upload/S7_组织成本科目分类表.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s7 partition (inc_day='20231225');
-- 2024.01.04
alter table dm_gis_uimp.ods_csv_org_cost_s7 drop partition(inc_day='20231225');
LOAD DATA  INPATH '/user/01416344/upload/数孪经营看板需求文档_数据侧_V1.3_S7.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_org_cost_s7 partition (inc_day='20240104');




-----------------------------------------------------
-- M表	各组织成本与人数表 
create table if not exists  dm_gis_uimp.dwd_org_cost_headcount_df(
action_day string comment '行为发生日期',
org_id string comment '组织ID',
org_id_parent string comment '组织父级ID',
org_name string comment '组织全称',
stext string comment '组织简称',
kostl string comment '组织成本中心编码',

salary_cost string comment '每月组织薪酬成本_万元',
travel_cost string comment '每月的组织差旅招待_万元',
other_cost string comment '每月的组织其他费用_万元',

monthly_travel_ers string comment '当月差旅招待_ERS_万元',
monthly_travel_btrip string comment '当月差旅招待_Btrip_万元',
monthly_travel string comment '当月差旅招待_万元',
formally_cnt string comment '正编人数',
outsourced_cnt string comment '外包人数',
sale_cnt string comment '销售人数' 
)
COMMENT 'M表,各组织成本与人数表'
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;



-- 各组织成本中心
drop table if exists dm_gis_uimp.tmp_org_data_cost;
create table dm_gis_uimp.tmp_org_data_cost  stored as parquet as 
select t0.org_id,org_id_parent,org_name,stext,t2.kostl
from (
select org_id,org_id_parent,org_name,stext,kostl from dm_gis_uimp.ods_issp_org_data where org_name like '%丰图科技%' 
) as t0 
full outer join 
(select org_id,kostl from dm_gis_uimp.ods_issp_org_data_virtual group by org_id,kostl) as t1 
on t0.org_id=t1.org_id 
full outer join 
(select kostl from dm_gis_uimp.ods_efp_cost group by kostl) as t2 
on t1.kostl=t2.kostl 
where t0.org_id is not null or t2.kostl is not null 
group by t0.org_id,org_id_parent,org_name,stext,t2.kostl
;

-- 每月组织薪酬成本_万元	ods_sap_zbseg
-- 	汇总符合条件的ods_sap_zbseg.pswbt/10000：
-- 1、要求ods_csv_org_cost_s7.sort='薪酬成本'，
-- 2、要求ods_csv_org_cost_s7.endday大于等于【行为发生日期】
-- 3、要求ods_sap_zbseg.hkont在ods_csv_org_cost_s7.hkont 的范围内，
-- 4、要求ods_sap_zbseg.cpudt和【行为发生日期】在同一月份
-- 每月的组织差旅招待_万元	ods_sap_zbseg	汇总符合条件的ods_sap_zbseg.pswbt/10000：
-- 1、要求ods_csv_org_cost_s7.sort='差旅招待'，
-- 2、要求ods_csv_org_cost_s7.endday大于等于【行为发生日期】
-- 3、要求ods_sap_zbseg.hkont在ods_csv_org_cost_s7.hkont 的范围内，
-- 要求ods_sap_zbseg.cpudt和【行为发生日期】在同一月份
-- 每月的组织其他费用_万元	ods_sap_zbseg	汇总符合条件的ods_sap_zbseg.pswbt/10000：
-- 4、要求ods_csv_org_cost_s7.sort='其他费用'，
-- 5、要求ods_csv_org_cost_s7.endday大于等于【行为发生日期】
-- 6、要求ods_sap_zbseg.hkont在ods_csv_org_cost_s7.hkont 的范围内，
-- 要求ods_sap_zbseg.cpudt和【行为发生日期】在同一月份

-- select kostl,pswbt/10000 as salary_cost from dm_gis_uimp.ods_sap_zbseg where inc_day='$firstDay' and substr(cpudt,1,6)=substr('$firstDay',1,6)
-- and hkont in (select hkont from dm_gis_uimp.ods_csv_org_cost_s7 where sort='薪酬成本' and endday>='$firstDay' )

-- select kostl,pswbt/10000 as travel_cost from dm_gis_uimp.ods_sap_zbseg where inc_day='$firstDay' and substr(cpudt,1,6)=substr('$firstDay',1,6)
-- and hkont in (select hkont from dm_gis_uimp.ods_csv_org_cost_s7 where sort='差旅招待' and endday>='$firstDay' )

-- select kostl,pswbt/10000 as other_cost from dm_gis_uimp.ods_sap_zbseg where inc_day='$firstDay' and substr(cpudt,1,6)=substr('$firstDay',1,6)
-- and hkont in (select hkont from dm_gis_uimp.ods_csv_org_cost_s7 where sort='其他费用' and endday>='$firstDay' )

-- -------------------------------------------------
-- -------------------------------------------------
-- 2024.01.03 改变   (ods_sap_zbseg 先取最近6个月数据)
-- ods_sap_zbseg和ods_sap_zbkpf(ods_oracle_sap_zbkpf_df)表根据 belnr、bukrs和gjahr字段关联
-- 汇总符合条件的ods_sap_zbseg.pswbt/10000：
-- 1、要求ods_csv_org_cost_s7.sort='薪酬成本'，
-- 2、要求ods_csv_org_cost_s7.endday大于等于【行为发生日期】
-- 3、要求ods_sap_zbseg.hkont在ods_csv_org_cost_s7.hkont 的范围内，
-- 4、要求ods_sap_zbkpf.budat和【行为发生日期】在同一月份
-- ods_sap_zbseg.bschl=50，pswbt*(-1)
-- ods_sap_zbseg.bschl=40，pswbt*(1)
-- 除此之外，留空
-- 汇总符合条件的ods_sap_zbseg.pswbt/10000：
-- 1、要求ods_csv_org_cost_s7.sort='差旅招待'，
-- 2、要求ods_csv_org_cost_s7.endday大于等于【行为发生日期】
-- 3、要求ods_sap_zbseg.hkont在ods_csv_org_cost_s7.hkont 的范围内，
-- 4、要求ods_sap_zbkpf.budat和【行为发生日期】在同一月份
-- 汇总符合条件的ods_sap_zbseg.pswbt/10000：
-- 1、要求ods_csv_org_cost_s7.sort='其他费用'，
-- 2、要求ods_csv_org_cost_s7.endday大于等于【行为发生日期】
-- 3、要求ods_sap_zbseg.hkont在ods_csv_org_cost_s7.hkont 的范围内，
-- 4、要求ods_sap_zbkpf.budat和【行为发生日期】在同一月份
drop table if exists dm_gis_uimp.tmp_sap_salary_cost; 
create table dm_gis_uimp.tmp_sap_salary_cost stored as parquet as 
select 
t0.belnr,t0.bukrs,t0.gjahr,kostl,bschl,pswbt,hkont,budat 
from (select belnr,bukrs,gjahr,kostl,bschl,pswbt,hkont from dm_gis_uimp.ods_sap_zbseg where inc_day>=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-5),'-','') 
and hkont in (select hkont from dm_gis_uimp.ods_csv_org_cost_s7 where sort='薪酬成本' and endday>='$firstDay' ) 
and bukrs in (select bukrs from dm_gis_uimp.ods_mysql_efp_com_code_af)  ) as t0 
left join (select belnr,bukrs,gjahr,budat from dm_gis_uimp.ods_oracle_sap_zbkpf_df where inc_day='$firstDay' and mandt='901' and substr(budat,1,6)=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),1,6)) as t1 
on t0.belnr=t1.belnr and t0.bukrs=t1.bukrs and t0.gjahr=t1.gjahr 
where t1.belnr is not null 
;

drop table if exists dm_gis_uimp.tmp_sap_travel_cost; 
create table dm_gis_uimp.tmp_sap_travel_cost stored as parquet as 
select 
t0.belnr,t0.bukrs,t0.gjahr,kostl,bschl,pswbt,hkont,budat 
from (select belnr,bukrs,gjahr,kostl,bschl,pswbt,hkont from dm_gis_uimp.ods_sap_zbseg where inc_day>=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-5),'-','') 
and hkont in (select hkont from dm_gis_uimp.ods_csv_org_cost_s7 where sort='差旅招待' and endday>='$firstDay' ) 
and bukrs in (select bukrs from dm_gis_uimp.ods_mysql_efp_com_code_af)  ) as t0 
left join (select belnr,bukrs,gjahr,budat from dm_gis_uimp.ods_oracle_sap_zbkpf_df where inc_day='$firstDay' and mandt='901' and substr(budat,1,6)=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),1,6)) as t1 
on t0.belnr=t1.belnr and t0.bukrs=t1.bukrs and t0.gjahr=t1.gjahr 
where t1.belnr is not null 
;

drop table if exists dm_gis_uimp.tmp_sap_other_cost; 
create table dm_gis_uimp.tmp_sap_other_cost stored as parquet as 
select 
t0.belnr,t0.bukrs,t0.gjahr,kostl,bschl,pswbt,hkont,budat 
from (select belnr,bukrs,gjahr,kostl,bschl,pswbt,hkont from dm_gis_uimp.ods_sap_zbseg where inc_day>=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-5),'-','') 
and hkont in (select hkont from dm_gis_uimp.ods_csv_org_cost_s7 where sort='其他费用' and endday>='$firstDay' ) 
and bukrs in (select bukrs from dm_gis_uimp.ods_mysql_efp_com_code_af)  ) as t0 
left join (select belnr,bukrs,gjahr,budat from dm_gis_uimp.ods_oracle_sap_zbkpf_df where inc_day='$firstDay' and mandt='901' and substr(budat,1,6)=substr(replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-1),'-',''),1,6) ) as t1 
on t0.belnr=t1.belnr and t0.bukrs=t1.bukrs and t0.gjahr=t1.gjahr 
where t1.belnr is not null 
;





-- 当月差旅招待_ERS	   P表	根据【组织成本中心编码】关联P表的取表的cost_center字段。
-- 统计表中original_amount/10000。取数条件：
-- business_type in ('FTKJRC04','1000','1007','1004','FTKJRC10')
-- create_time和【行为发生日期】在同一月份
-- 根据P表和i表根据order_no字段关联，要求i表的status_code not in ('newDoc','invalidDoc','rejectDoc','revokeDoc') 
drop table if exists dm_gis_uimp.tmp_org_data_monthly_travel_ers;
create table dm_gis_uimp.tmp_org_data_monthly_travel_ers  stored as parquet as 
select t0.order_no,cost_center,original_amount 
from (
select order_no,cost_center,original_amount/10000 as original_amount from dm_gis_uimp.ods_ft_ers_form_expense_area_data 
where inc_day='$firstDay' 
and (create_time>=add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0) and create_time<add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),+1) ) 
) as t0 
left join (
select order_no from dm_gis_uimp.ods_ft_ers_form_base_area_data 
where inc_day='$firstDay' 
and status_code not in ('invalidDoc','revokeDoc','failPayDoc','finishDoc','paidDoc','payingDoc','refundDoc','refundingDoc','waitPayDoc')  
and business_type in ('FTKJRC04','1000','1007','1004','FTKJRC10') 
group by order_no 
) as t1 
on t0.order_no=t1.order_no
where t1.order_no is not null 
;


-- formally_cnt	正编人数	H表和N表	根据【组织ID】关联H表的org_id字段；
-- 根据H表和N表根据emp_num字段关联；
-- 统计满足以下条件的emp_num数量：
-- 【行为发生日期】和H表、G表的inc_day同月
--  N表中cancel_flag<>'Y'
-- dm_gis_uimp.dwd_ft_emp_out_month 丰图外包人员-主表
-- dm_gis_uimp.dwd_issp_emp_data_month 人员主表-通用字段 (需要开发)
-- dm_gis_uimp.dwd_issp_emp_data_ext_month 人员主表-非通用字段  (需要开发) 
drop table if exists dm_gis_uimp.tmp_org_data_formally_cnt;
create table dm_gis_uimp.tmp_org_data_formally_cnt  stored as parquet as 
select org_id,count(distinct emp_num) as formally_cnt 
from (select 
t0.org_id,t0.emp_num 
from (select org_id,emp_num from dm_gis_uimp.dwd_issp_emp_data_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','') ) as t0 
left join (
select emp_num from dm_gis_uimp.dwd_issp_emp_data_ext_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','')  
and cancel_flag<>'Y' ) as t1 
on t0.emp_num=t1.emp_num 
where t1.emp_num is not null 
) as t 
group by org_id 
;


-- Outsourced_cnt	外包人数	G表	根据【组织ID】关联G表的org_id_in字段。
-- 统计满足以下条件的emp_num数量：
-- 【行为发生日期】和G表的inc_day同月
-- and category='1' 
-- and post_flag<>'f'
drop table if exists dm_gis_uimp.tmp_org_data_outsourced_cnt;
create table dm_gis_uimp.tmp_org_data_outsourced_cnt  stored as parquet as 
select org_id_in,count(distinct emp_num) as outsourced_cnt 
from (select org_id_in,emp_num  
from dm_gis_uimp.dwd_ft_emp_out_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','')  
and category='1' and post_flag<>'f' 
) as t 
group by org_id_in
;


-- Sale_cnt	销售人数	G表和H表	根据【组织ID】关联H表的org_id字段、G表的org_id_in字段。
-- 统计满足以下条件的emp_num数量：
-- ①H表的inc_day和【行为发生日期】同月，position_name包含“销售经理”或“城市经理”文案，并且cancel_flag<>'Y'，
-- 或者②G表的inc_day和【行为发生日期】同月，position_name_cn包含“销售经理”或“城市经理”文案，and category='1' and post_flag<>'f'
drop table if exists dm_gis_uimp.tmp_org_data_sale_cnt;
create table dm_gis_uimp.tmp_org_data_sale_cnt  stored as parquet as 
select org_id,count(distinct emp_num) as sale_cnt
from (select org_id,t0.emp_num
from (select org_id,emp_num from dm_gis_uimp.dwd_issp_emp_data_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','')  
and (position_name like '%销售经理%' or position_name like '%城市经理%' ) ) AS t0 
left join (
select emp_num from dm_gis_uimp.dwd_issp_emp_data_ext_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','')  
and cancel_flag<>'Y' ) as t1 
on t0.emp_num=t1.emp_num 
where t1.emp_num is not null 
union all 
select org_id_in as org_id,emp_num  
from dm_gis_uimp.dwd_ft_emp_out_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','') 
and (position_name_cn like '%销售经理%' or position_name_cn like '%城市经理%' ) and category='1' and post_flag<>'f' 
) as t 
group by org_id
;


-- 汇总,写入结果表
insert overwrite table dm_gis_uimp.dwd_org_cost_headcount_df partition(inc_day='$firstDay')
select '$firstDay' action_day,t0.org_id,org_id_parent,org_name,stext,t0.kostl,
salary_cost,
travel_cost,
other_cost,
original_amount as monthly_travel_ers,
order_amount as monthly_travel_btrip,
if(original_amount is not null or original_amount<>'',original_amount,0) + if(order_amount is not null or order_amount<>'',order_amount,0) as monthly_travel,
formally_cnt,
outsourced_cnt,
sale_cnt 
from dm_gis_uimp.tmp_org_data_cost as t0 
left join 
(select kostl,sum(case bschl when '50' then pswbt*(-1) when '40' then pswbt else 0 end)/10000 as salary_cost from dm_gis_uimp.tmp_sap_salary_cost group by kostl ) as t1a
on t0.kostl=t1a.kostl 
left join 
(select kostl,sum(case bschl when '50' then pswbt*(-1) when '40' then pswbt else 0 end)/10000 as travel_cost from dm_gis_uimp.tmp_sap_travel_cost group by kostl ) as t1b
on t0.kostl=t1b.kostl 
left join 
(select kostl,sum(case bschl when '50' then pswbt*(-1) when '40' then pswbt else 0 end)/10000 as other_cost from dm_gis_uimp.tmp_sap_other_cost group by kostl ) as t1c
on t0.kostl=t1c.kostl 
left join (select cost_center,sum(original_amount) as original_amount from dm_gis_uimp.tmp_org_data_monthly_travel_ers group by cost_center) as t2 
on t0.kostl=t2.cost_center 
left join (select cost_center,sum(order_amount)/10000 as order_amount  from dm_gis_uimp.ods_csv_org_cost_s6 
where unix_timestamp(substr(order_time,0,7),'yyyy-MM')=unix_timestamp(substr('$firstDay',0,6),'yyyyMM') group by cost_center) as t3 
on t0.kostl=t3.cost_center 
left join (select org_id,formally_cnt from dm_gis_uimp.tmp_org_data_formally_cnt) as t4 
on t0.org_id=t4.org_id 
left join (select org_id_in,outsourced_cnt from dm_gis_uimp.tmp_org_data_outsourced_cnt) as t5 
on t0.org_id=t5.org_id_in 
left join (select org_id,sale_cnt from dm_gis_uimp.tmp_org_data_sale_cnt) as t6
on t0.org_id=t6.org_id 
;



-- 2023.12.15 销售人员业绩达成风险等级表
-- 1、任务执行周期：每天更新。按天分区，T-1
create table if not exists  dm_gis_uimp.dwd_sales_perf_achi_risk_level(
yearly	string comment '年度',
emp_num	string comment '销售人员工号',
emp_name	string comment '销售人员姓名',
org_id	string comment '所属组织ID',
org_name	string comment '所属组织全称',
stext	string comment '所属组织简称',
unit_id	string comment '所属经营单元',
line_code	string comment '所属业务线',
sign_target	string comment '签单年度目标_万元',
Income_target	string comment '收入年度目标_万元',
collection_target	string comment '回款年度目标_万元',
sign_cumulative	string comment '当年签单累计实际数_万元',
income_cumulative	string comment '当年收入累计实际数_万元',
collection_cumulative	string comment '当年回款累计实际数_万元',
indi_sign_rate	string comment '个人签单达成率',
indi_income_rate	string comment '个人收入达成率',
indi_collection_rate	string comment '个人回款达成率',
org_id_c1c2 string comment '一级或二级组织id'
)
COMMENT '销售人员业绩达成风险等级表'
PARTITIONED BY (`inc_day` string COMMENT 'yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- emp_num	销售人员工号	取满足以下条件的emp_num：
-- ①dwd_issp_emp_data_month.inc_day和T-1同月，position_name包含“销售经理”或“城市经理”文案，并且dwd_issp_emp_data_ext_month<>'Y'，
-- 或者②dwd_ft_emp_out_month.inc_day和T-1同月，position_name_cn包含“销售经理”或“城市经理”文案，and category='1' and post_flag<>'f'
drop table if exists dm_gis_uimp.tmp_sales_perf_achi_emp_num;
create table dm_gis_uimp.tmp_sales_perf_achi_emp_num  stored as parquet as 
select org_id,emp_num,emp_name,substr('$firstDay',1,4) as yearly 
from (select org_id,t0.emp_num,t0.emp_name 
from (select org_id,emp_num,emp_name from dm_gis_uimp.dwd_issp_emp_data_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','')  
and (position_name like '%销售经理%' or position_name like '%城市经理%' ) ) AS t0 
left join (
select emp_num from dm_gis_uimp.dwd_issp_emp_data_ext_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','')  
and cancel_flag<>'Y' ) as t1 
on t0.emp_num=t1.emp_num 
where t1.emp_num is not null 
union all 
select org_id_in as org_id,emp_num,name as emp_name   
from dm_gis_uimp.dwd_ft_emp_out_month 
where inc_day=replace(add_months(from_unixtime(unix_timestamp(substr('$firstDay',0,6),'yyyyMM'),'yyyy-MM-dd'),-0),'-','') 
and (position_name_cn like '%销售经理%' or position_name_cn like '%城市经理%' ) and category='1' and post_flag<>'f' 
) as t 
group by org_id,emp_num,emp_name 
;


-- 所属组织全称 所属组织简称
-- select org_id,org_name,stext from dm_gis_uimp.ods_issp_org_data_df where inc_day='$firstDay' group by org_id,org_name,stext

-- 所属经营单元 所属业务线
-- select org_id,unit_id,line_code from dm_gis_uimp.ods_issp_org_data_virtual_df where inc_day='$firstDay' group by org_id,unit_id,line_code

-- 签单、收入、回款年度目标
-- select yearly,emp_no,sum(target_amount) as target_amount from dm_gis_uimp.ods_csv_org_cost_s3 where inc_day='20231121' and target_type='签单目标' group by yearly,emp_no 
-- select yearly,emp_no,sum(target_amount) as target_amount from dm_gis_uimp.ods_csv_org_cost_s3 where inc_day='20231121' and target_type='收入目标' group by yearly,emp_no
-- select yearly,emp_no,sum(target_amount) as target_amount from dm_gis_uimp.ods_csv_org_cost_s3 where inc_day='20231121' and target_type='回款目标' group by yearly,emp_no

-- 签单累计
drop table if exists dm_gis_uimp.tmp_sales_perf_achi_sign_cumulative;
create table dm_gis_uimp.tmp_sales_perf_achi_sign_cumulative  stored as parquet as 
select yearly,
owner__r_no,contract_amount,id,inc_day 
from (select yearly,owner__r_no,contract_amount,id,inc_day,row_number() over(partition by id order by inc_day desc) as rn 
from (select substr(if(length(performance_date)=13,FROM_UNIXTIME(cast(performance_date/1000 as int)),replace(performance_date,'-','')),1,4) as yearly,
owner__r_no,contract_amount,id,inc_day 
from dm_gis_uimp.dws_sign_bill_performance where inc_day>='20230101' ) as t
) as tt where tt.rn=1 
;

-- 收入累计
drop table if exists dm_gis_uimp.tmp_sales_perf_achi_income_cumulative;
create table dm_gis_uimp.tmp_sales_perf_achi_income_cumulative  stored as parquet as 
select yearly,owner__r_no,income_excluding_tax_amount,id,inc_day 
from (select yearly,owner__r_no,income_excluding_tax_amount,id,inc_day,row_number() over(partition by id order by inc_day desc) as rn 
from (select substr(if(length(revenue_time)=13,FROM_UNIXTIME(cast(revenue_time/1000 as int)),replace(revenue_time,'-','')),1,4) as yearly,
owner__r_no,income_excluding_tax_amount,id,inc_day  from dm_gis_uimp.dws_income_performance where inc_day>='20230101' ) as t 
) as tt where tt.rn=1 
;

-- 回款累计
drop table if exists dm_gis_uimp.tmp_sales_perf_achi_collection_cumulative;
create table dm_gis_uimp.tmp_sales_perf_achi_collection_cumulative  stored as parquet as 
select yearly,owner__r_no,actual_collection_amount,id,inc_day 
from (select yearly,owner__r_no,actual_collection_amount,id,inc_day,row_number() over(partition by id order by inc_day desc) as rn 
from ( select 
substr(if(length(actual_collection_time)=13,FROM_UNIXTIME(cast(actual_collection_time/1000 as int)),replace(actual_collection_time,'-','')),1,4) as yearly,
owner__r_no,actual_collection_amount,id,inc_day 
from dm_gis_uimp.dws_collection_performance where inc_day>='20230101' ) as t
) as tt where tt.rn=1 
;


-- 销售人员业绩达成风险等级表，汇总结果
insert overwrite table dm_gis_uimp.dwd_sales_perf_achi_risk_level partition(inc_day='$firstDay') 
select t0.yearly,t0.emp_num,t0.emp_name,t0.org_id,
t1.org_name,t1.stext,
t2.unit_id,t2.line_code,
t3.target_amount as sign_target,
t4.target_amount as income_target,
t5.target_amount as collection_target,
t6.sign_cumulative,t7.income_cumulative,t8.collection_cumulative,
t6.sign_cumulative/t3.target_amount as indi_sign_rate,
t7.income_cumulative/t4.target_amount as indi_income_rate,
t8.collection_cumulative/t5.target_amount as indi_collection_rate,
t1.org_id_c1c2   
from dm_gis_uimp.tmp_sales_perf_achi_emp_num as t0 
left join (select org_id,org_name,stext,org_id_c1c2 from dm_gis_uimp.ods_issp_org_data_df where inc_day='$firstDay' group by org_id,org_name,stext,org_id_c1c2) as t1 
on t0.org_id=t1.org_id 
left join (select org_id,unit_id,line_code from dm_gis_uimp.ods_issp_org_data_virtual_df where inc_day='$firstDay' group by org_id,unit_id,line_code) as t2 
on t0.org_id=t2.org_id 
left join (select yearly,emp_no,sum(target_amount) as target_amount from dm_gis_uimp.ods_csv_org_cost_s3 where  target_type='签单目标' group by yearly,emp_no) as t3 
on t0.yearly=t3.yearly and t0.emp_num=t3.emp_no 
left join (select yearly,emp_no,sum(target_amount) as target_amount from dm_gis_uimp.ods_csv_org_cost_s3 where  target_type='收入目标' group by yearly,emp_no) as t4 
on t0.yearly=t4.yearly and t0.emp_num=t4.emp_no 
left join (select yearly,emp_no,sum(target_amount) as target_amount from dm_gis_uimp.ods_csv_org_cost_s3 where  target_type='回款目标' group by yearly,emp_no) as t5 
on t0.yearly=t5.yearly and t0.emp_num=t5.emp_no 
left join (select yearly,owner__r_no,sum(contract_amount) as sign_cumulative from dm_gis_uimp.tmp_sales_perf_achi_sign_cumulative group by yearly,owner__r_no) as t6 
on t0.yearly=t6.yearly and t0.emp_num=t6.owner__r_no 
left join (select yearly,owner__r_no,sum(income_excluding_tax_amount) as income_cumulative  from dm_gis_uimp.tmp_sales_perf_achi_income_cumulative group by yearly,owner__r_no) as t7 
on t0.yearly=t7.yearly and t0.emp_num=t7.owner__r_no 
left join (select yearly,owner__r_no,sum(actual_collection_amount) as collection_cumulative 
from dm_gis_uimp.tmp_sales_perf_achi_collection_cumulative group by yearly,owner__r_no ) as t8 
on t0.yearly=t8.yearly and t0.emp_num=t8.owner__r_no 
;




-- select emp_no,target_amount from dm_gis_uimp.ods_csv_org_cost_s4 where 

-- select job_no,
-- if(entertain_ers_acc_amount is not null and entertain_ers_acc_amount<>'',entertain_ers_acc_amount,0)+
-- if(gifts_act_amount is not null and gifts_act_amount<>'',gifts_act_amount,0)+
-- if(gifts_acc_amount is not null and gifts_acc_amount<>'',gifts_acc_amount,0)+
-- if(outsource_act_amount is not null and outsource_act_amount<>'',outsource_act_amount,0)+
-- if(outsource_acc_amount is not null and outsource_acc_amount<>'',outsource_acc_amount,0)+
-- if(rent_act_amount is not null and rent_act_amount<>'',rent_act_amount,0)+
-- if(travel_ers_act_amount is not null and travel_ers_act_amount<>'',travel_ers_act_amount,0)+
-- if(travel_ers_acc_amount is not null and travel_ers_acc_amount<>'',travel_ers_acc_amount,0)+
-- if(air_hotel_car_act_amount is not null and air_hotel_car_act_amount<>'',air_hotel_car_act_amount,0)+
-- if(air_hotel_car_acc_amount is not null and air_hotel_car_acc_amount<>'',air_hotel_car_acc_amount,0)
-- as 
-- total_amount  from dm_gis_uimp.dws_personal_travel_receive_detail where  inc_day='202310'

-- select emp_no,target_amount from dm_gis_uimp.ods_csv_org_cost_s3

-- select owner__r_no,contract_amount from dm_gis_uimp.dws_sign_bill_performance where inc_day='' and performance_date

-- select owner__r_no,income_excluding_tax_amount from dm_gis_uimp.dws_income_performance where inc_day='' and andrevenue_time

-- select owner__r_no,actual_collection_amount from  dm_gis_uimp.dws_collection_performance where inc_day='' and actual_collection_time


-- 导线下数据 （个人差旅招待统计表202301~202306 ）
CREATE  TABLE `dm_gis_uimp.tmp_csv_dws_personal_travel_receive_detail`(
job_no	string comment '员工工号',
project_code string comment '项目代码',
end_unit	string comment '最终确认的经营单元',
end_line	string comment '最终确认的业务线',
emp_name	string comment '员工姓名',
position_name	string comment '员工职位名称',
org_name	string comment '员工所属组织',
bu_line	string comment '所属业务线',
bu_unit	string comment '所属经营单元',
cost	string comment '员工成本中心',
hire_date	string comment '员工入职日期',
leave_date	string comment '员工离职日期',
emp_type	string comment '员工类型',
entertain_ers_act_amount	string comment '招待费_个人垫付费用_ers_实际数',
entertain_ers_acc_amount	string comment '招待费_个人垫付费用_ers_预提数',
gifts_act_amount	string comment '招待费_礼品_实际数',
gifts_acc_amount	string comment '招待费_礼品_预提数',
outsource_act_amount	string comment '差旅费_外包差旅_实际数',
outsource_acc_amount	string comment '差旅费_外包差旅_预提数',
rent_act_amount	string comment '差旅费_差旅房租_实际数',
travel_ers_act_amount	string comment '差旅费_个人垫付费用_ers_实际数',
travel_ers_acc_amount	string comment '差旅费_个人垫付费用_ers_预提数',
air_hotel_car_act_amount		string comment '差旅费_机票酒店用车_实际数',
air_hotel_car_acc_amount		string comment '差旅费_机票酒店用车_预提数',
is_cost		string comment '本期间是否发生差旅招待费',
project_name	string comment '项目名称',
project_unit	string comment '项目所属经营单元',
project_line	string comment '项目所属业务线',
project_type	string comment '项目类型',
cost_center	string comment '原单据的成本中心',
is_rent  string comment '是否差旅房租',
end_unit_ej  string comment '最终确认的二级经营单元',
inc_day string 
)
COMMENT '临时表_个人差旅招待统计表202301~202306'
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;


LOAD DATA  INPATH '/user/01416344/upload/个人差旅招待统计表202301~202306_数据孪生业务线部分_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.tmp_csv_dws_personal_travel_receive_detail;

set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
insert overwrite table dm_gis_uimp.dws_personal_travel_receive_detail partition(inc_day) 
select 
job_no,
project_code,
end_unit,
end_line,
emp_name,
position_name,
org_name,
bu_line,
bu_unit,
cost,
hire_date,
leave_date,
emp_type,
entertain_ers_act_amount,
entertain_ers_acc_amount,
gifts_act_amount,
gifts_acc_amount,
outsource_act_amount,
outsource_acc_amount,
rent_act_amount,
travel_ers_act_amount,
travel_ers_acc_amount,
air_hotel_car_act_amount,
air_hotel_car_acc_amount,
is_cost,
project_name,
project_unit,
project_line,
project_type,
cost_center,
is_rent,
end_unit_ej,
inc_day
from dm_gis_uimp.tmp_csv_dws_personal_travel_receive_detail
;


