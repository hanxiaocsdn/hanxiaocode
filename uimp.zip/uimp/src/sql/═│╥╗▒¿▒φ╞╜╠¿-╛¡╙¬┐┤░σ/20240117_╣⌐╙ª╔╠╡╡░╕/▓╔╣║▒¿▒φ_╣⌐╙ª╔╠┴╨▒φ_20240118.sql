-- 
-- 需求方：林中莉(01423677)
-- 需求： 供应商基础信息表 
-- @author 张小琼 （01416344）
-- Created on 2024-01-18
-- 任务信息： ID：968080  采购数据_供应商列表(衡鉴每次只要最新的)
-- 

-- 供应商基础信息报表 (线下导入，每月更新1~2次)
create table dm_gis_uimp.ods_csv_supplier_base_info_df(
access_approve_result	string comment '是否通过准入审核',
to_els_account	string comment '供应商账号',
supplier_code	string comment 'SAP编码',
company_name	string comment '企业名称',
alias	string comment '简称',
credit_code	string comment '信用代码',
legal_person_name	string comment ' 法人',
country	string comment ' 国家',
province	string comment ' 省份',
city	string comment ' 市',
reg_location	string comment ' 注册地址',
reg_capital	string comment '注册资金',
fbk31	string comment '服务优势区域',
fbk2	string comment '供应商类型',
fbk1	string comment '引入渠道或场景',
coo_status	string comment '供应商合作状态',
performance_level	string comment '绩效等级',
account_group	string comment '供应商账户组',
service_scope	string comment '可服务范围',
fbk16	string comment '是否丰图竞对',
company_nature	string comment '公司性质',
client	string comment '客户指定',
company_size	string comment '公司规模',
supplier_group	string comment '采购组',
need_coordination	string comment '供应商协同方式',
principal	string comment '采购专员',
project_experience	string comment '同类项目',
key_customers	string comment '主要客户',
payment_object_type	string comment '付款对象类型',
cooperation_status	string comment '供应商分类',
internal_company_code	string comment '内部供应商对应的公司代码',
fbk15	string comment '准入成功时间',
tax_sort	string comment '税分类',
invoice_type	string comment '发票类型',
fbk3	string comment '主营业务品类名称',
business_license	string comment '营业执照',
invoicing_data	string comment '开票资料',
fbk19	string comment '财务报表',
integrity_agreement	string comment '廉洁承诺书',
confidentiality_agreement	string comment '保密承诺书',
intellectual_property_right	string comment '资质证书',
application_date	string comment '申请日期',
admission_strategy	string comment '准入策略',
access_category	string comment '准入品类',
fbk11	string comment '准入品类名称',
fbk18	string comment '首次合作项目',
application_org	string comment '申请组织',
demand_dep	string comment '需求部门',
fbk1_b	string comment '引入渠道或场景',
demand	string comment '目的',
fbk2_b	string comment '供应商类型',
company_size_b	string comment '公司规模',
company_nature_b	string comment '公司性质',
credit_code_b	string comment '统一社会信用代码/身份证ID',
business_scope	string comment '供应商经营范围',
authorized_brand	string comment '商务条件说明',
audit_score	string comment '准入审核评分结果',
supplier_status	string comment '合作状态',
evaluate_results	string comment '采购组织:评估结果',
coo_fund	string comment '预计年合作金',
cooperation_status_b	string comment '供应商分类',
fbk20	string comment '商务能力',
fbk26	string comment '交付能力',
fbk28	string comment '成本能力',
fbk30	string comment '技术能力',
fbk32	string comment '质量能力',
fbk33	string comment '服务能力',
payment_clause	string comment 'ERP付款条件编码',
payment_clause_desc	string comment 'ERP付款条件名称',
fbk24	string comment '竞争对手及竞争的优劣势',
key_achievements	string comment '最近三年营业额',
fbk34	string comment '资源提前储备',
warranty_agreement	string comment ' 质保协议',
project_case	string comment '项目案例/合同',
audit_status	string comment '审批状态',
access_approve_status_dict_text	string comment '准入终审：结果',
contact_position	string comment '职位',
contact_name	string comment '姓名',
contact_phone	string comment '手机号',
contact_email	string comment '邮箱地址',
frozen_function	string comment '冻结功能',
qualification_certificate	string comment '资质类证书',
reg_time	string comment '注册时间'
) 
COMMENT '供应商基础信息报表'
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ("separatorChar"=",")
STORED AS TEXTFILE
;

-- 
-- LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/采购报表_供应商列表_数据侧_V1.0.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_supplier_base_info_df partition(inc_day='20240118');
LOAD DATA  INPATH 'hdfs://sfbdp1/user/01416344/upload/供应商档案卡生产数据-20240116.xlsx.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_csv_supplier_base_info_df partition(inc_day='20240116');


-- 供应商列表 
create table dm_gis_uimp.dwd_supplier_info_df(
access_approve_result	string comment '是否通过准入审核',
to_els_account	string comment '供应商账号',
supplier_code	string comment 'SAP编码',
company_name	string comment '企业名称',
alias	string comment '简称',
credit_code	string comment '信用代码',
legal_person_name	string comment ' 法人',
country	string comment ' 国家',
province	string comment ' 省份',
city	string comment ' 市',
reg_location	string comment ' 注册地址',
reg_capital	string comment '注册资金',
fbk31	string comment '服务优势区域',
fbk2	string comment '供应商类型',
fbk1	string comment '引入渠道或场景',
coo_status	string comment '供应商合作状态',
performance_level	string comment '绩效等级',
account_group	string comment '供应商账户组',
service_scope	string comment '可服务范围',
fbk16	string comment '是否丰图竞对',
company_nature	string comment '公司性质',
client	string comment '客户指定',
company_size	string comment '公司规模',
supplier_group	string comment '采购组',
need_coordination	string comment '供应商协同方式',
principal	string comment '采购专员',
project_experience	string comment '同类项目',
key_customers	string comment '主要客户',
payment_object_type	string comment '付款对象类型',
cooperation_status	string comment '供应商分类',
internal_company_code	string comment '内部供应商对应的公司代码',
fbk15	string comment '准入成功时间',
tax_sort	string comment '税分类',
invoice_type	string comment '发票类型',
fbk3	string comment '主营业务品类名称',
business_license	string comment '营业执照',
invoicing_data	string comment '开票资料',
fbk19	string comment '财务报表',
integrity_agreement	string comment '廉洁承诺书',
confidentiality_agreement	string comment '保密承诺书',
intellectual_property_right	string comment '资质证书',
application_date	string comment '申请日期',
admission_strategy	string comment '准入策略',
access_category	string comment '准入品类',
fbk11	string comment '准入品类名称',
fbk18	string comment '首次合作项目',
application_org	string comment '申请组织',
demand_dep	string comment '需求部门',
fbk1_b	string comment '引入渠道或场景',
demand	string comment '目的',
fbk2_b	string comment '供应商类型',
company_size_b	string comment '公司规模',
company_nature_b	string comment '公司性质',
credit_code_b	string comment '统一社会信用代码/身份证ID',
business_scope	string comment '供应商经营范围',
authorized_brand	string comment '商务条件说明',
audit_score	string comment '准入审核评分结果',
supplier_status	string comment '合作状态',
evaluate_results	string comment '采购组织:评估结果',
coo_fund	string comment '预计年合作金',
cooperation_status_b	string comment '供应商分类',
fbk20	string comment '商务能力',
fbk26	string comment '交付能力',
fbk28	string comment '成本能力',
fbk30	string comment '技术能力',
fbk32	string comment '质量能力',
fbk33	string comment '服务能力',
payment_clause	string comment 'ERP付款条件编码',
payment_clause_desc	string comment 'ERP付款条件名称',
fbk24	string comment '竞争对手及竞争的优劣势',
key_achievements	string comment '最近三年营业额',
fbk34	string comment '资源提前储备',
warranty_agreement	string comment ' 质保协议',
project_case	string comment '项目案例/合同',
audit_status	string comment '审批状态',
access_approve_status_dict_text	string comment '准入终审：结果',
contact_position	string comment '职位',
contact_name	string comment '姓名',
contact_phone	string comment '手机号',
contact_email	string comment '邮箱地址',
frozen_function	string comment '冻结功能',
qualification_certificate	string comment '资质类证书',
reg_time	string comment '注册时间',
joint_project	string comment '与丰图过往合作项目',
joint_project_amount	string comment '与丰图过往合作总金额_万元' 
) 
COMMENT '供应商列表' 
PARTITIONED BY (`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
STORED AS parquet
tblproperties ('parquet.compression'='snappy')
;


-- 一、供应商基础信息报表的字段  
-- 以线下数据源中“供应商账号”为主键，取对应字段，特别的，
-- 1、线下数据源中同一个“供应商账号”会有多行，取任一行即可
-- 2、“采购组”字段在导入时，如果含“采购组”文案，需要去掉这3个字
-- 二、joint_project	与丰图过往合作项目	
-- dws_purchase_contract_ledger_details	根据dws_purchase_contract_ledger_details的“fsupplierid_fnumber”字段关联供应商基础信息报表的“SAP编码”字段。
-- 获取dws_purchase_contract_ledger_details的f_tthm_entryname（项目名称）字段，
-- ①数据需要去重
-- ②去掉这些值：(空白)、-、--、/、\
-- ③使用“；和换行符”拼接取到的值  
-- 三、joint_project_amount	与丰图过往合作总金额_万元	
-- dws_purchase_contract_ledger_details	根据dws_purchase_contract_ledger_details的“fsupplierid_fnumber”字段关联供应商基础信息报表的“SAP编码”字段。
-- 汇总dws_purchase_contract_ledger_details的fallamount/10000
insert overwrite table dm_gis_uimp.dwd_supplier_info_df partition(inc_day='20240118') 
select access_approve_result,to_els_account,supplier_code,company_name,alias,credit_code,legal_person_name,
country,province,city,reg_location,reg_capital,fbk31,fbk2,fbk1,coo_status,performance_level,account_group,service_scope,
fbk16,company_nature,client,company_size,
supplier_group,
need_coordination,principal,project_experience,key_customers,payment_object_type,
cooperation_status,internal_company_code,fbk15,tax_sort,invoice_type,fbk3,business_license,invoicing_data,fbk19,integrity_agreement,
confidentiality_agreement,intellectual_property_right,application_date,admission_strategy,access_category,fbk11,fbk18,application_org,
demand_dep,fbk1_b,demand,fbk2_b,company_size_b,company_nature_b,credit_code_b,business_scope,authorized_brand,audit_score,supplier_status,
evaluate_results,coo_fund,cooperation_status_b,fbk20,fbk26,fbk28,fbk30,fbk32,fbk33,payment_clause,payment_clause_desc,fbk24,key_achievements,
fbk34,warranty_agreement,project_case,audit_status,access_approve_status_dict_text,contact_position,contact_name,contact_phone,contact_email,
frozen_function,qualification_certificate,reg_time,
joint_project,joint_project_amount 
from (
select access_approve_result,to_els_account,supplier_code,company_name,alias,credit_code,legal_person_name,
country,province,city,reg_location,reg_capital,fbk31,fbk2,fbk1,coo_status,performance_level,account_group,service_scope,
fbk16,company_nature,client,company_size,
supplier_group,
need_coordination,principal,project_experience,key_customers,payment_object_type,
cooperation_status,internal_company_code,fbk15,tax_sort,invoice_type,fbk3,business_license,invoicing_data,fbk19,integrity_agreement,
confidentiality_agreement,intellectual_property_right,application_date,admission_strategy,access_category,fbk11,fbk18,application_org,
demand_dep,fbk1_b,demand,fbk2_b,company_size_b,company_nature_b,credit_code_b,business_scope,authorized_brand,audit_score,supplier_status,
evaluate_results,coo_fund,cooperation_status_b,fbk20,fbk26,fbk28,fbk30,fbk32,fbk33,payment_clause,payment_clause_desc,fbk24,key_achievements,
fbk34,warranty_agreement,project_case,audit_status,access_approve_status_dict_text,contact_position,contact_name,contact_phone,contact_email,
frozen_function,qualification_certificate,reg_time 
from (SELECT access_approve_result,to_els_account,supplier_code,company_name,alias,credit_code,legal_person_name,
country,province,city,reg_location,reg_capital,fbk31,fbk2,fbk1,coo_status,performance_level,account_group,service_scope,
fbk16,company_nature,client,company_size,
regexp_replace(supplier_group,'采购组','') as supplier_group,
need_coordination,principal,project_experience,key_customers,payment_object_type,
cooperation_status,internal_company_code,fbk15,tax_sort,invoice_type,fbk3,business_license,invoicing_data,fbk19,integrity_agreement,
confidentiality_agreement,intellectual_property_right,application_date,admission_strategy,access_category,fbk11,fbk18,application_org,
demand_dep,fbk1_b,demand,fbk2_b,company_size_b,company_nature_b,credit_code_b,business_scope,authorized_brand,audit_score,supplier_status,
evaluate_results,coo_fund,cooperation_status_b,fbk20,fbk26,fbk28,fbk30,fbk32,fbk33,payment_clause,payment_clause_desc,fbk24,key_achievements,
fbk34,warranty_agreement,project_case,audit_status,access_approve_status_dict_text,contact_position,contact_name,contact_phone,contact_email,
frozen_function,qualification_certificate,reg_time,
row_number() over(partition by to_els_account order by inc_day desc) as rn 
FROM dm_gis_uimp.ods_csv_supplier_base_info_df ) as t where t.rn=1
) as t0 
left join (
select fsupplierid_fnumber,
concat_ws(';',collect_set(regexp_replace(f_tthm_entryname,' |\-|\/|\\\\',''))) as joint_project,
sum(fallamount)/10000 as joint_project_amount 
from dm_gis_uimp.dws_purchase_contract_ledger_details 
where inc_day='20240118' 
group by fsupplierid_fnumber 
) as t1 
on t0.supplier_code=t1.fsupplierid_fnumber
;


