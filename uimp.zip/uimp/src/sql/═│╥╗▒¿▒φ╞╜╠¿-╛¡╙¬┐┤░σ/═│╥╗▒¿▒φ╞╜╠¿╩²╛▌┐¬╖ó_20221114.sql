-- dm_gis_uimp   库名    统一指标管理平台
-- 有问题可进“问题答疑群”咨询。1、差旅平台: https://btrip.sf-express.com/home.html#/homePage          2、报销平台：http://ers.sf-express.com/module/index.html    

--SSP供应商结算云数据
-- "ods_ssp2.plf_form_business_data_cfg（表单业务源数据表）" 分类主数据表，用来对业务类型、单据类型、业务事项做名称转换 lessee_no="FTFIN"
-- "ods_ssp2.plf_form_body（SSP供应商结算云的表单主体表）"     表单主体表  lessee_no="FTFIN"
-- "ods_ssp2.plf_form_account_detail（SSP供应商结算云的表单明细数据表）"  表单明细表  lessee_no="FTFIN"
--  ods_ssp2.plf_form_apprecial_tax_detail（SSP供应商结算云的增值税专票明细表）
--丰味数据 
--  dm_meal.ft_meal_order_detail 订单明细表
--  dm_meal.ft_meal_order_pay_detail 交易明细表
--  dm_meal.ft_meal_ot_apply_form_dtl 加班申请明细
--丰享数据
--  ods_fx_dwd.dwd_feng_tu_order_detail 丰图的丰享数据同步表


CREATE  TABLE `dm_gis_uimp.ods_plf_form_business_data_cfg`(
`id` int COMMENT 'id',
`data_type` int COMMENT '数据类型 1 所属组织 2 单据类型 3 业务类型 4 业务事项 5 组织细分',
`data_value` string COMMENT '名称',
`data_code` string COMMENT '编码',
`create_user` string COMMENT '创建人',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '更新人',
`update_time` string COMMENT '更新时间',
`is_enabled` int COMMENT '有效状态 1 有效 0 无效',
`lessee_no` string COMMENT '租户编码')
COMMENT '表单业务源数据表'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE  TABLE `dm_gis_uimp.ods_plf_form_body`(
`body_id` bigint COMMENT '主键ID',
`lessee_no` string COMMENT '租户编码',
`organization_code` string COMMENT '所属组织编码',
`fractionize_organization_code` string COMMENT '细分组织编码',
`order_no` string COMMENT '单据编号',
`order_type_code` string COMMENT '单据类型编码',
`business_type_code` string COMMENT '业务类型编码',
`order_name` string COMMENT '单据名称',
`company_code` string COMMENT '公司代码',
`company_name` string COMMENT '公司名称',
`currency_type` string COMMENT '币种',
`currency_rate` decimal(4,2) COMMENT '汇率',
`create_id` string COMMENT '创建人',
`apply_id` string COMMENT '申请人',
`cost_center` string COMMENT '成本中心',
`cost_center_name` string COMMENT '成本中心名称',
`is_prepay` int COMMENT '是否预付，0否，1是',
`is_verifi` int COMMENT '0 核销 1 支付 2 核销并支付',
`is_sterilisation` int COMMENT '是否冲销',
`bankl` string COMMENT '银行代码',
`pay_type` string COMMENT '支付方式：1正常支付，2银行托收，3支票，4总部代付',
`supplier_account` string COMMENT '供应商编码',
`supplier_name` string COMMENT '供应商名称',
`account_name` string COMMENT '收款单位',
`bank_account` string COMMENT '收款账号',
`account_code` string COMMENT '开户行信息',
`matter_desc` string COMMENT '事项说明',
`payment_desc` string COMMENT '付款说明',
`is_total_pay` int COMMENT '是否统付，0否，1是',
`order_status` int COMMENT '单据状态：删除(0) 新建(10) 待提交(20) 等待影像(30) 待提交流程(40) ecp处理中(50) 待提交fsop(60) 提交FSOP异常(61) fsop处理中(70) 财务过账中(80) 过账失败(81) 单据完成(82) 单据冲销中(90)冲销失败(91) 冲销成功(92) 单据已付款(100) 单据付款失败(101)',
`voucher_status` int COMMENT '凭证调用状态（0、未开始:可以改数据 1、调用中:锁数据 2、失败：可以改数据 3、成功：锁数据 4、超时：锁数据 5、处理中：锁数据 6、其他：锁数据）',
`screenage_status` int COMMENT '影像状态, 0、删除，1、已上传，2、业务退单，3、业务补单，4、扫描退单，5、扫描补单',
`screenage_no` string COMMENT '影像号',
`screenage_no_his` string COMMENT '影像号历史',
`payment_no` string COMMENT '付款凭证号',
`voucher_no` string COMMENT 'SAP凭证号',
`verifi_no` string COMMENT '冲销凭证号',
`verifi_order_no` string COMMENT '冲销单据号',
`purchase_no` string COMMENT '采购订单号',
`error_msg` string COMMENT '错误信息',
`reject_type` int COMMENT '驳回类型(1、退单退影像；2、退单补影像；3、仅退影像；4、仅补影像；5、退单不退影像)',
`again_submit_type` int COMMENT '驳回后再次提交类型 (1 直送至我； 2 逐级审批)',
`fsop_reject_method` int COMMENT '共享分单驳回方式(0,非财务驳回 1,财务驳回)',
`totol_foreign_money` decimal(24,2) COMMENT '总的交易货币金额',
`total_cur_pay_money` decimal(24,2) COMMENT '总的本次应付金额',
`is_apprecia_job_byuse` int COMMENT '是否被增值税抽数定时器使用标志',
`benchmark_time` string COMMENT '基准日期',
`posting_time` string COMMENT '过账日期',
`business_depart_person` string COMMENT '地区业务管理部门负责人',
`financial_approver` string COMMENT '财务审批人',
`financial_approver_name` string COMMENT '财务审批人名称',
`suggest_info` string COMMENT '审批建议',
`term_of_payment` string COMMENT '付款条件',
`contract_no` string COMMENT '合同号',
`version_num` string COMMENT '合同版本号',
`bvtyp` string COMMENT '合作银行类型',
`payment_time` string COMMENT '付款日期',
`expect_payment_time` string COMMENT '期望付款日期',
`is_cat_image` int COMMENT '是否收到EIOS的确认消息，0否，1是',
`is_notice_fsop` int COMMENT '是否通知分单系统，0否，1是',
`is_notice_eios` int COMMENT '是否通知eios',
`image_num` int COMMENT '影像数量',
`image_upload_time` string COMMENT '影像上传时间',
`image_scaner_user` string COMMENT '影像扫描人',
`reasons_for_payment` string COMMENT '线下支付原因',
`approval_enter` string COMMENT '审核入口: FSOP审批入口， SSP审核入口',
`data_type` int COMMENT '数据分类，1 外围推送无需审批 2 外围推送需要审批 3 SSP预付表单填写',
`image_source` string COMMENT '影像来源',
`measure_core` string COMMENT '预算编码',
`payment_status` string COMMENT '支付状态',
`bank_call_msg` string COMMENT '银行响应消息',
`front_origin` string COMMENT '外围系统编码',
`detail_sum` int COMMENT '明细数量',
`template_code` string COMMENT '单据模板编码',
`flow_code` string COMMENT '流程编码',
`template_node_id` int COMMENT '当前流程节点(关联流程节点配置表)',
`reject_node_id` int COMMENT '退回节点',
`ecp_run_id` string COMMENT 'ecp_run_id',
`ele_inv_flag` string COMMENT '是否都是电子发票 Y是 N不是',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '修改人',
`update_time` string COMMENT '记录最后一次更新时间戳',
`attr1` string COMMENT '大写金额',
`attr2` string COMMENT '初审描述',
`attr3` string COMMENT '备用字段3',
`attr4` string COMMENT '备用字段4',
`attr5` string COMMENT '备用字段5',
`create_name` string COMMENT '创建人姓名',
`apply_name` string COMMENT '申请人姓名',
`business_depart_person_name` string COMMENT '地区业务管理部门负责人姓名',
`company_merge_flag` string COMMENT '公司账套合并标记',
`swift_code` string COMMENT '国际付款的SWIFT/BIC',
`payment_frozen_status` string COMMENT '付款冻结状态(Y:是 X:推送FPE)',
`country` string COMMENT '国别',
`standard_money` string COMMENT '本位币',
`standard_money_amount` decimal(24,2) COMMENT '本位币金额',
`push_fpe_flag` int COMMENT '是否集成过账(0:自动 1:手动)',
`account_detail_currency_type` string COMMENT '费用明细币种',
`practice_payment_currency_type` string COMMENT '实际付款币种',
`practice_payment_amount` decimal(12,2) COMMENT '实际付款金额',
`is_exist_ele_invoice` string COMMENT '是否存在电子发票',
`is_exist_paper_material` string COMMENT '是否存在纸质材料',
`audit_user_first` string COMMENT '初审人',
`audit_user_second` string COMMENT '复审人',
`audit_finish_time` string COMMENT '复审时间',
`other_business_type` string COMMENT '业务大类',
`other_area` string COMMENT '大区',
`other_bu` string COMMENT 'bu',
`biz_type` string COMMENT '支付云业务类型',
`pay_way` string COMMENT '支付云付款方式',
`total_contract_amount` string COMMENT '总合同金额',
`total_payments_num` string COMMENT '总付款次数',
`current_payments_num` string COMMENT '本次款次数',
`is_project_special` string COMMENT '是否客户项目专属投入',
`attr6` string COMMENT '预留字段',
`attr7` string COMMENT '预留字段',
`attr8` string COMMENT '预留字段',
`attr9` string COMMENT '预留字段',
`attr10` string COMMENT '预留字段',
`attr11` string COMMENT '预留字段',
`attr12` string COMMENT '预留字段')
COMMENT '表单主体表'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE  TABLE `dm_gis_uimp.ods_plf_form_account_detail`(
`detail_id` bigint COMMENT '明细编号',
`lessee_no` string COMMENT '租户编码',
`order_no` string COMMENT '单据编号',
`order_type_code` string COMMENT '单据类型编码',
`business_type_code` string COMMENT '业务类型编码',
`business_item_code` string COMMENT '业务事项编码',
`cost_center` string COMMENT '成本中心',
`cost_center_name` string COMMENT '成本中心名称',
`kostl_no` string COMMENT '反向成本中心',
`kostl_reverse_name` string COMMENT '反向成本中心名称',
`customer_code` string COMMENT '客户代码',
`customer_name` string COMMENT '客户名称',
`project_code` string COMMENT '项目代码',
`project_code_name` string COMMENT '项目代码名称',
`big_customer_code` string COMMENT '大客户项目代码',
`big_customer_name` string COMMENT '大客户项目描述',
`foreign_money` decimal(24,2) COMMENT '交易货币金额',
`pay_type` string COMMENT '支付方式：1正常支付，2银行托收，3支票，4总部代付',
`budget_examine` string COMMENT '预算查看',
`security_deposit_money` string COMMENT '不含税金额',
`security_deposit_money_handler` string COMMENT '手工修改不含税金额',
`bill_type` string COMMENT '票据类型',
`post_attr` string COMMENT '岗位属性',
`employment_mode` string COMMENT '用工模式',
`license_plate_no` string COMMENT '车牌号',
`supplier_account` string COMMENT '供应商编码',
`supplier_name` string COMMENT '供应商名称',
`bvtyp_type` string COMMENT '合作银行类型',
`banks_code` string COMMENT '银行国家代码',
`dtaws_code` string COMMENT '指令码',
`umskz_flag` string COMMENT '特别总账标识',
`zlspr_flag` string COMMENT '付款冻结',
`prctr` string COMMENT '利润中心',
`xref3` string COMMENT '参考码3',
`ihrez_no` string COMMENT '虚拟合同号',
`account_name` string COMMENT '收款单位',
`bank_account` string COMMENT '收款账号',
`account_code` string COMMENT '开户行信息',
`is_monthly_statement` int COMMENT '是否月结',
`is_support_value` int COMMENT '是否保价',
`asset_card_no` string COMMENT '资产卡片号',
`io_order_no` string COMMENT 'IO订单号/采购订单号',
`asset_net_worth` decimal(24,2) COMMENT '资产净值',
`tax_rate` decimal(4,2) COMMENT '税率',
`tax_code` string COMMENT '税码',
`is_enjoy_tax_reliefs` int COMMENT '是否享受减免税',
`invoice_type` string COMMENT '发票类型',
`claim_type` string COMMENT '认领类型',
`quarter_rate` decimal(4,2) COMMENT '季度利率',
`capitalization_money` decimal(24,2) COMMENT '资本化金额',
`sgtxt` string COMMENT '行文本',
`account_voucher_no` string COMMENT '会计凭证号',
`first_purchase_date` string COMMENT '首次购置日期',
`cbe_code` string COMMENT 'CBE编码',
`expense_incurred_during` string COMMENT '费用发生期间',
`quality_retention_money` decimal(24,2) COMMENT '质保金/核销金额',
`account_item_no` string COMMENT '会计凭证行项目号',
`purchase_order_no` string COMMENT '采购订单号',
`purchase_item_no` string COMMENT '采购凭证的项目编号',
`retirement_date` string COMMENT '报废日期',
`cancel_lation_date` string COMMENT '预计核销日期',
`is_amortization` int COMMENT '是否摊销(0代表否，1代表是)',
`trade_partner` string COMMENT '贸易伙伴',
`is_remove_tax` int COMMENT '是否拆税，1是，0是',
`invoice_no` string COMMENT '发票号码',
`claimant_no` string COMMENT '索赔编号',
`exception_traffic_no` string COMMENT '交通事故异常编号',
`bus_contract_no` string COMMENT '业务合同编号',
`io_code` string COMMENT 'IO编码',
`order_number` string COMMENT '订单编号',
`material_group` string COMMENT '物料组',
`line_num` string COMMENT '行号',
`business_date` string COMMENT '业务日期',
`cost_type` string COMMENT '费用类型',
`line_count` int COMMENT '数量',
`line_unit` string COMMENT '单位',
`voucher_no` string COMMENT 'SAP凭证号',
`payment_no` string COMMENT '付款凭证号',
`posting_time` string COMMENT '过账日期',
`payment_time` string COMMENT '付款日期',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '操作人',
`update_time` string COMMENT '记录最后一次更新时间戳',
`attr1` string COMMENT 'Y',
`attr2` string COMMENT '备用字段2',
`attr3` string COMMENT '备用字段3',
`attr4` string COMMENT '备用字段4',
`attr5` string COMMENT '备用字段5',
`attr6` string COMMENT '备用字段6',
`attr7` string COMMENT '备用字段7',
`attr8` string COMMENT '备用字段8',
`attr9` string COMMENT '备用字段9',
`attr10` string COMMENT '备用字段10',
`saknr` string COMMENT '会计科目',
`cost_more_company_flag` string COMMENT '成本中心跨账套使用',
`amortization` string COMMENT '摊销科目',
`invoice_currency` string COMMENT '预付:发票货币/应付:付款货币',
`invoice_tax_amount` decimal(12,2) COMMENT '发票税额',
`invoice_date` string COMMENT '发票日期',
`withholding_tax_rate` decimal(12,4) COMMENT '预付:代扣税税率/应付:预扣税税率',
`withholding_tax_amount` decimal(12,2) COMMENT '预付:代扣税税额/应付:预扣税税额',
`invoice_currency_rate` decimal(9,6) COMMENT '发票货币汇率',
`payment_currency_amount` decimal(12,2) COMMENT '付款货币金额',
`beic_req_id` string COMMENT '支付云Beic请求ID',
`product_code` string COMMENT '产品代码',
`base_date` string COMMENT '基准日',
`due_date` string COMMENT '到期日',
`flight_no` string COMMENT '航班号',
`route_code` string COMMENT '路线编码',
`start_address` string COMMENT '起始地',
`end_address` string COMMENT '目的地',
`fpe_business_item_code` string COMMENT 'fpe业务事项编码',
`transit_dr` string COMMENT '中转科目借方',
`transit_cr` string COMMENT '中转科目贷方')
COMMENT '表单明细数据表'
PARTITIONED BY (
`inc_day` string COMMENT '增量日期')
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;

CREATE  TABLE `dm_gis_uimp.ods_plf_form_apprecial_tax_detail`(
`apprecia_id` bigint COMMENT '明细编号',
`lessee_no` string COMMENT '租户',
`order_no` string COMMENT '单据编号',
`order_type_code` string COMMENT '单据类型编码',
`business_type_code` string COMMENT '业务类型编码',
`invoice_date` string COMMENT '开票日期',
`invoice_no` string COMMENT '发票号码',
`invoice_code` string COMMENT '发票代码',
`tax_rate` string COMMENT '税率',
`mwskz` string COMMENT '税码',
`tax_money` decimal(24,2) COMMENT '税额',
`totol_money` decimal(24,2) COMMENT '总额',
`zc_reason` string COMMENT '进项转出编码，01：员工福利费、业务招待费、不认证或转出 02：多开发票部分转出',
`result_time` string COMMENT '结果集时间戳',
`create_user` string COMMENT '创建人',
`create_time` string COMMENT '创建时间',
`update_user` string COMMENT '操作人',
`update_time` string COMMENT '操作时间',
`attr1` string COMMENT '备用字段1',
`attr2` string COMMENT '备用字段2',
`attr3` string COMMENT '备用字段3',
`attr4` string COMMENT '备用字段4',
`attr5` string COMMENT '备用字段5',
`invoice_source` string COMMENT '发票来源(1:EIOS确认 2:用户录入)',
`invoice_status` string COMMENT '发票状态(0:已删除 1:有效)',
`tax_out_amount` double COMMENT '进项税转出金额',
`check_result` string COMMENT '发票校验结果\;0-未比对，1-一致，2-不一致')
COMMENT '增值税专票明细表'
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE TABLE `dm_gis_uimp.ods_ft_meal_order_detail`(
`sys_code` string COMMENT '系统来源编码',
`sys_name_zh` string COMMENT '系统来源名称(简体)',
`sys_name_en` string COMMENT '系统来源名称(英文)',
`sys_name_tw` string COMMENT '系统来源名称(繁体)',
`order_code` string COMMENT '订单号',
`outer_order_code` string COMMENT '外部订单号',
`order_name_zh` string COMMENT '订单名称(简体)',
`order_name_en` string COMMENT '订单名称(英文)',
`order_name_tw` string COMMENT '订单名称(繁体)',
`order_type_code` string COMMENT '订单类型编码(staffCanteen/takeout/onsiteShop/otMeals/otNightMeal/meetingMeal)',
`order_type_name_zh` string COMMENT '订单类型名称(简体)',
`order_type_name_en` string COMMENT '订单类型名称(英文)',
`order_type_name_tw` string COMMENT '订单类型名称(繁体)',
`ot_apply_no` string COMMENT '加班申请号(订单类型为加班或加班宵夜必填)',
`order_source_code` string COMMENT '订单来源编码(pc/app/wx/oth)',
`order_source_name_zh` string COMMENT '订单来源名称(简体)',
`order_source_name_en` string COMMENT '订单来源名称(英文)',
`order_source_name_tw` string COMMENT '订单来源名称(繁体)',
`order_status_code` string COMMENT '订单状态编码',
`order_status_name_zh` string COMMENT '订单状态名称(简体)',
`order_status_name_en` string COMMENT '订单状态名称(英文)',
`order_status_name_tw` string COMMENT '订单状态名称(繁体)',
`login_user_name` string COMMENT '消费者账号',
`emp_name_zh` string COMMENT '消费者姓名(简体)',
`emp_name_en` string COMMENT '消费者姓名(英文)',
`emp_name_tw` string COMMENT '消费者姓名(繁体)',
`sob_code` string COMMENT '账套编码(公司代码)',
`cc_code` string COMMENT '成本中心编码',
`suppl_code` string COMMENT '供应商编码',
`suppl_name_zh` string COMMENT '供应商名称(简体)',
`suppl_name_en` string COMMENT '供应商名称(英文)',
`suppl_name_tw` string COMMENT '供应商名称(繁体)',
`order_time` timestamp COMMENT '下单时间',
`order_count` int COMMENT '数量',
`order_receiver` string COMMENT '收件人名称',
`receiv_addr` string COMMENT '收件人地址',
`receiv_addr_mask` string COMMENT '收件人地址掩码',
`receiv_addr_encrypt` string COMMENT '收件人地址密文',
`expct_receiv_time` timestamp COMMENT '期望收货时间',
`curr_code` string COMMENT '货币代码',
`curr_sign` string COMMENT '货币符号',
`order_amount` decimal(16,2) COMMENT '订单金额',
`enterprisepay_amount` decimal(16,2) COMMENT '公司结算',
`mealcardpay_amount` decimal(16,2) COMMENT '员工餐卡',
`alipay_amount` decimal(16,2) COMMENT '支付宝',
`wechatpay_amount` decimal(16,2) COMMENT '微信支付',
`unionpay_amount` decimal(16,2) COMMENT '银联支付',
`otherpay_amount` decimal(16,2) COMMENT '其他支付',
`cancel_reason_code` int COMMENT '取消原因编码',
`cancel_reason_name_zh` string COMMENT '取消原因名称(简体)',
`cancel_reason_name_en` string COMMENT '取消原因名称(英文)',
`cancel_reason_name_tw` string COMMENT '取消原因名称(繁体)',
`cancel_reason_msg_zh` string COMMENT '具体取消原因(简体)',
`cancel_reason_msg_en` string COMMENT '具体取消原因(英文)',
`cancel_reason_msg_tw` string COMMENT '具体取消原因(繁体)',
`order_eval_level` int COMMENT '评价等级(1-5)',
`order_remark_zh` string COMMENT '备注说明(简体)',
`order_remark_en` string COMMENT '备注说明(英文)',
`order_remark_tw` string COMMENT '备注说明(繁体)',
`pc_order_url` string COMMENT 'pc订单详情url',
`app_order_url` string COMMENT 'app订单详情url',
`encrypt_mode` string COMMENT '加密模式(sf/local)',
`is_valid` string COMMENT '是否有效（Y/N）',
`data_source` string COMMENT '数据来源(local/bdus等)',
`create_user` string COMMENT '创建者账号',
`create_time` timestamp COMMENT '创建时间',
`update_user` string COMMENT '更新者账号',
`update_time` timestamp COMMENT '更新时间')
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE TABLE `dm_gis_uimp.ods_ft_meal_order_pay_detail`(
`order_id` bigint COMMENT '订单ID',
`order_code` string COMMENT '订单号',
`outer_order_code` string COMMENT '外部订单号',
`pay_id` string COMMENT '交易流水号',
`pay_time` timestamp COMMENT '交易时间',
`pay_mode_code` string COMMENT '支付方式编码(mealcard/alipay/wechatPay/unionPay/enterprisePay/otherPay)',
`pay_mode_name_zh` string COMMENT '支付方式名称(简体)',
`pay_mode_name_en` string COMMENT '支付方式名称(英文)',
`pay_mode_name_tw` string COMMENT '支付方式名称(繁体)',
`curr_code` string COMMENT '货币代码',
`curr_sign` string COMMENT '货币符号',
`pay_amount` decimal(16,2) COMMENT '交易金额',
`pay_account_no` string COMMENT '交易账户编码',
`suppl_code` string COMMENT '供应商编码',
`pay_account_name_zh` string COMMENT '交易账户名称(中文)',
`pay_account_name_en` string COMMENT '交易账户名称(英文)',
`pay_account_name_tw` string COMMENT '交易账户名称(繁体)',
`suppl_name_zh` string COMMENT '供应商名称(中文)',
`suppl_name_en` string COMMENT '供应商名称(英文)',
`suppl_name_tw` string COMMENT '供应商名称(繁体)',
`pay_name_zh` string COMMENT '交易名称(中文)',
`pay_name_tw` string COMMENT '交易名称(繁体)',
`pay_name_en` string COMMENT '交易名称(英文)',
`refund_reason_code` int COMMENT '退款原因编码（数据字典）',
`refund_reason_name_zh` string COMMENT '退款原因名称(简体)',
`refund_reason_name_en` string COMMENT '退款原因名称(英文)',
`refund_reason_name_tw` string COMMENT '退款原因名称(繁体)',
`refund_reason_msg_zh` string COMMENT '退款详细描述(简体)',
`refund_reason_msg_en` string COMMENT '退款详细描述(英文)',
`refund_reason_msg_tw` string COMMENT '退款详细描述(繁体)',
`is_valid` string COMMENT '是否有效（Y/N）',
`data_source` string COMMENT '数据来源(local/bdus等)',
`create_user` string COMMENT '创建者账号',
`create_time` timestamp COMMENT '创建时间',
`update_user` string COMMENT '更新者账号',
`update_time` timestamp COMMENT '更新时间',
`sob_code` string COMMENT '账套编码',
`cc_code` string COMMENT '成本中心编码',
`order_status_code` string COMMENT '订单状态编码',
`order_status_name_zh` string COMMENT '订单状态名称(简体)',
`order_status_name_en` string COMMENT '订单状态名称(英文)',
`order_status_name_tw` string COMMENT '订单状态名称(繁体)',
`check_status_code` string COMMENT '对账状态编码',
`check_status_name_zh` string COMMENT '对账状态名称(简体)',
`check_status_name_en` string COMMENT '对账状态名称(英文)',
`check_status_name_tw` string COMMENT '对账状态名称(繁体)')
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE TABLE `dm_gis_uimp.ods_ft_meal_ot_apply_form_dtl`(
`ot_form_code` string COMMENT '申请单号(OT(2位)+YYMMDDHH24MINSSMS(15位)+6位随机码)',
`ot_form_name_zh` string COMMENT '申请单名称(简体)',
`ot_form_name_en` string COMMENT '申请单名称(英文)',
`ot_form_name_tw` string COMMENT '申请单名称(繁体)',
`ot_apply_code` string COMMENT '加班申请类型编码(otMeals:加班餐\;otNightMeal:加班宵夜)',
`ot_apply_name_zh` string COMMENT '申请类型名称(简体)',
`ot_apply_name_en` string COMMENT '申请类型名称(英文)',
`ot_apply_name_tw` string COMMENT '申请类型名称(繁体)',
`login_channel_code` string COMMENT '渠道来源编码(pc/app/wx/oth)',
`login_channel_name_zh` string COMMENT '渠道来源名称(简体)',
`login_channel_name_en` string COMMENT '渠道来源名称(英文)',
`login_channel_name_tw` string COMMENT '渠道来源名称(繁体)',
`ot_form_status_code` string COMMENT '状态编码(submit/order/del/applied/done/settled)',
`ot_form_status_name_zh` string COMMENT '状态名称(简体)',
`ot_form_status_name_en` string COMMENT '状态名称(英文)',
`ot_form_status_name_tw` string COMMENT '状态名称(繁体)',
`apv_status_code` string COMMENT '审批状态编码(draft/pending/agreed/reject/exempt)',
`apv_status_name_zh` string COMMENT '审批状态名称(简体)',
`apv_status_name_en` string COMMENT '审批状态名称(英文)',
`apv_status_name_tw` string COMMENT '审批状态名称(繁体)',
`apply_user_login_no` string COMMENT '申请人账号',
`apply_user_name_zh` string COMMENT '申请人姓名(简体)',
`apply_user_name_en` string COMMENT '申请人姓名(英文)',
`apply_user_name_tw` string COMMENT '申请人姓名(繁体)',
`org_id` bigint COMMENT '所属组织ID',
`org_name_zh` string COMMENT '所属组织名称(简体)',
`org_name_en` string COMMENT '所属组织名称(英文)',
`org_name_tw` string COMMENT '所属组织名称(繁体)',
`sob_code` string COMMENT '账套编号',
`cc_code` string COMMENT '成本中心编码',
`submit_time` timestamp COMMENT '提交时间',
`apply_date` date COMMENT '申请日期',
`wkday_type_code` string COMMENT '工作日类型编码',
`wkday_type_name_zh` string COMMENT '工作日类型名称(简体)',
`wkday_type_name_en` string COMMENT '工作日类型名称(英文)',
`wkday_type_name_tw` string COMMENT '工作日类型名称(繁体)',
`ot_mls_scene_code` string COMMENT '加班用餐类型编码(breakf/lunch/dinner/supper)',
`ot_mls_scene_name_zh` string COMMENT '加班用餐名称(简体)',
`ot_mls_scene_name_en` string COMMENT '加班用餐名称(英文)',
`ot_mls_scene_name_tw` string COMMENT '加班用餐名称(繁体)',
`submt_start_time` string COMMENT '点餐开始时间(hh24:min)',
`submt_end_time` string COMMENT '点餐截止时间(hh24:min)',
`std_amount` decimal(32,2) COMMENT '标准金额',
`curr_code` string COMMENT '货币代码',
`curr_sign` string COMMENT '货币符号',
`is_project_flag` string COMMENT '是否项目(Y/N)',
`project_code` string COMMENT '项目代码',
`project_name_zh` string COMMENT '项目名称(简体)',
`project_name_en` string COMMENT '项目名称(英文)',
`project_name_tw` string COMMENT '项目名称(繁体)',
`ot_apply_reason_zh` string COMMENT '加班原因(简体)',
`ot_apply_reason_en` string COMMENT '加班原因(英文)',
`ot_apply_reason_tw` string COMMENT '加班原因(繁体)',
`ot_apply_remark_zh` string COMMENT '备注说明(简体)',
`ot_apply_remark_en` string COMMENT '备注说明(英文)',
`ot_apply_remark_tw` string COMMENT '备注说明(繁体)',
`order_code` string COMMENT '订单号',
`outer_order_code` string COMMENT '外部订单号',
`is_valid` string COMMENT '是否有效（Y/N）',
`data_source` string COMMENT '数据来源(local/bdus等)',
`create_user` string COMMENT '创建者账号',
`create_time` timestamp COMMENT '创建时间',
`update_user` string COMMENT '更新者账号',
`update_time` timestamp COMMENT '更新时间',
`ot_form_confmn_status_code` string COMMENT '合规状态编码',
`ot_form_confmn_status_name_zh` string COMMENT '合规状态名称(简体)',
`ot_form_confmn_status_name_en` string COMMENT '合规状态名称(英文)',
`ot_form_confmn_status_name_tw` string COMMENT '合规状态名称(繁体)',
`conformance_text` string COMMENT '合规条件',
`ot_form_pay_status` string COMMENT '支付方式编码',
`ot_form_pay_name_zh` string COMMENT '支付方式名称(简体)',
`ot_form_pay_name_en` string COMMENT '支付方式名称(英文)',
`ot_form_pay_name_tw` string COMMENT '支付方式名称(繁体)',
`apply_month` string COMMENT '申请月份(YYYYMM)',
`consume_amount` decimal(32,2) COMMENT '消费/申请金额')
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;


CREATE EXTERNAL TABLE `dm_gis_uimp.ods_feng_tu_order_detail`(
`pid` bigint COMMENT '行号',
`pay_time` string COMMENT '支付时间',
`job_number` string COMMENT '工号',
`emp_user_name` string COMMENT '姓名',
`product_name` string COMMENT '产品名称',
`product_spec_desc` string COMMENT '商品规格',
`sale_unit_price` decimal(18,2) COMMENT '销售单价',
`quantity` int COMMENT '销量',
`real_freight_total_amount` decimal(18,2) COMMENT '商品实收+运费',
`order_id` bigint COMMENT '订单号',
`order_status_name` string COMMENT '订单状态',
`pay_state` string COMMENT '支付状态',
`pay_type_desc` string COMMENT '支付类型',
`order_type` string COMMENT '订单类型',
`output_tax_rate` int COMMENT '销项税率(单位%)',
`order_item_id` bigint COMMENT '订单明细ID',
`item_refund_amount` decimal(12,2) COMMENT '明细退款金额',
`order_refund_amount` decimal(12,2) COMMENT '订单退款金额')
COMMENT '丰图同步信息表'
PARTITIONED BY (
`inc_day` string)
STORED AS ORC
TBLPROPERTIES ('orc.compression'='SNAPPY')
;




-- 跑数

set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set mapreduce.input.fileinputformat.split.maxsize=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.rack=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.node=268435456;
set mapred.max.split.size=268435456;
set mapred.min.split.size.per.node=268435456;
set mapred.min.split.size.per.rack=268435456;
--设置jvm重用
set mapred.job.reuse.jvm.num.tasks=10;

insert overwrite table dm_gis_uimp.ods_plf_form_business_data_cfg partition(inc_day)
select id, data_type, data_value, data_code, create_user, create_time , update_user , update_time, is_enabled, lessee_no,inc_day
from  ods_ssp2.plf_form_business_data_cfg where lessee_no='FTFIN' and inc_day=
;

insert overwrite table dm_gis_uimp.ods_plf_form_body partition(inc_day)
select 
body_id,lessee_no,organization_code,fractionize_organization_code,order_no,order_type_code,business_type_code,order_name,company_code,company_name,currency_type,currency_rate,create_id,apply_id,cost_center,cost_center_name,is_prepay,is_verifi,is_sterilisation,
bankl,pay_type,supplier_account,supplier_name,account_name,bank_account,account_code,matter_desc,payment_desc,is_total_pay,order_status,voucher_status,screenage_status,screenage_no,screenage_no_his,payment_no,voucher_no,verifi_no,verifi_order_no,purchase_no,
error_msg,reject_type,again_submit_type,fsop_reject_method,totol_foreign_money,total_cur_pay_money,is_apprecia_job_byuse,benchmark_time,posting_time,business_depart_person,financial_approver,financial_approver_name,suggest_info,term_of_payment,contract_no,
version_num,bvtyp,payment_time,expect_payment_time,is_cat_image,is_notice_fsop,is_notice_eios,image_num,image_upload_time,image_scaner_user,reasons_for_payment,approval_enter,data_type,image_source,measure_core,payment_status,bank_call_msg,front_origin,
detail_sum,template_code,flow_code,template_node_id,reject_node_id,ecp_run_id,ele_inv_flag,create_time,update_user,update_time,attr1,attr2,attr3,attr4,attr5,create_name,apply_name,business_depart_person_name,company_merge_flag,swift_code,payment_frozen_status,
country,standard_money,standard_money_amount,push_fpe_flag,account_detail_currency_type,practice_payment_currency_type,practice_payment_amount,is_exist_ele_invoice,is_exist_paper_material,audit_user_first,audit_user_second,audit_finish_time,other_business_type,
other_area,other_bu,biz_type,pay_way,total_contract_amount,total_payments_num,current_payments_num,is_project_special,attr6,attr7,attr8,attr9,attr10,attr11,attr12
,inc_day
from ods_ssp2.plf_form_body where lessee_no='FTFIN' and inc_day=
;

insert overwrite table dm_gis_uimp.ods_plf_form_account_detail partition(inc_day)
select 
detail_id,lessee_no,order_no,order_type_code,business_type_code,business_item_code,cost_center,cost_center_name,kostl_no,kostl_reverse_name,customer_code,customer_name,
project_code,project_code_name,big_customer_code,big_customer_name,foreign_money,pay_type,budget_examine,security_deposit_money,security_deposit_money_handler,bill_type,
post_attr,employment_mode,license_plate_no,supplier_account,supplier_name,bvtyp_type,banks_code,dtaws_code,umskz_flag,zlspr_flag,prctr,xref3,ihrez_no,account_name,
bank_account,account_code,is_monthly_statement,is_support_value,asset_card_no,io_order_no,asset_net_worth,tax_rate,tax_code,is_enjoy_tax_reliefs,invoice_type,claim_type,
quarter_rate,capitalization_money,sgtxt,account_voucher_no,first_purchase_date,cbe_code,expense_incurred_during,quality_retention_money,account_item_no,purchase_order_no,
purchase_item_no,retirement_date,cancel_lation_date,is_amortization,trade_partner,is_remove_tax,invoice_no,claimant_no,exception_traffic_no,bus_contract_no,io_code,
order_number,material_group,line_num,business_date,cost_type,line_count,line_unit,voucher_no,payment_no,posting_time,payment_time,create_time,update_user,update_time,
attr1,attr2,attr3,attr4,attr5,attr6,attr7,attr8,attr9,attr10,saknr,cost_more_company_flag,amortization,invoice_currency,invoice_tax_amount,invoice_date,
withholding_tax_rate,withholding_tax_amount,invoice_currency_rate,payment_currency_amount,beic_req_id,product_code,base_date,due_date,flight_no,route_code,start_address,
end_address,fpe_business_item_code,transit_dr,transit_cr
,inc_day
from ods_ssp2.plf_form_account_detail where lessee_no='FTFIN' and inc_day=
;


insert overwrite table dm_gis_uimp.ods_plf_form_apprecial_tax_detail partition(inc_day)
select 
apprecia_id,lessee_no,order_no,order_type_code,business_type_code,invoice_date,invoice_no,invoice_code,tax_rate,mwskz,tax_money,totol_money,zc_reason,result_time,
create_user,create_time,update_user,update_time,attr1,attr2,attr3,attr4,attr5,invoice_source,invoice_status,tax_out_amount,check_result
,inc_day 
from ods_ssp2.plf_form_apprecial_tax_detail where lessee_no='FTFIN' and inc_day=
;



--丰味
insert overwrite table dm_gis_uimp.ods_ft_meal_order_detail partition(inc_day)
select 
sys_code,sys_name_zh,sys_name_en,sys_name_tw,order_code,outer_order_code,order_name_zh,order_name_en,order_name_tw,order_type_code,
order_type_name_zh,order_type_name_en,order_type_name_tw,ot_apply_no,order_source_code,order_source_name_zh,order_source_name_en,
order_source_name_tw,order_status_code,order_status_name_zh,order_status_name_en,order_status_name_tw,login_user_name,emp_name_zh,
emp_name_en,emp_name_tw,sob_code,cc_code,suppl_code,suppl_name_zh,suppl_name_en,suppl_name_tw,order_time,order_count,order_receiver,
receiv_addr,receiv_addr_mask,receiv_addr_encrypt,expct_receiv_time,curr_code,curr_sign,order_amount,enterprisepay_amount,mealcardpay_amount,
alipay_amount,wechatpay_amount,unionpay_amount,otherpay_amount,cancel_reason_code,cancel_reason_name_zh,cancel_reason_name_en,cancel_reason_name_tw,
cancel_reason_msg_zh,cancel_reason_msg_en,cancel_reason_msg_tw,order_eval_level,order_remark_zh,order_remark_en,order_remark_tw,pc_order_url,app_order_url,
encrypt_mode,is_valid,data_source,create_user,create_time,update_user,update_time
,inc_day 
from dm_meal.ft_meal_order_detail where inc_day=
;

insert overwrite table  dm_gis_uimp.ods_ft_meal_order_pay_detail partition(inc_day) 
select 
order_id,order_code,outer_order_code,pay_id,pay_time,pay_mode_code,pay_mode_name_zh,pay_mode_name_en,pay_mode_name_tw,curr_code,curr_sign,pay_amount,pay_account_no,
suppl_code,pay_account_name_zh,pay_account_name_en,pay_account_name_tw,suppl_name_zh,suppl_name_en,suppl_name_tw,pay_name_zh,pay_name_tw,pay_name_en,refund_reason_code,
refund_reason_name_zh,refund_reason_name_en,refund_reason_name_tw,refund_reason_msg_zh,refund_reason_msg_en,refund_reason_msg_tw,is_valid,data_source,create_user,
create_time,update_user,update_time,sob_code,cc_code,order_status_code,order_status_name_zh,order_status_name_en,order_status_name_tw,check_status_code,check_status_name_zh,
check_status_name_en,check_status_name_tw
,inc_day 
from dm_meal.ft_meal_order_pay_detail where inc_day=
;



insert overwrite table  dm_gis_uimp.ods_ft_meal_ot_apply_form_dtl partition(inc_day) 
select 
ot_form_code,ot_form_name_zh,ot_form_name_en,ot_form_name_tw,ot_apply_code,ot_apply_name_zh,ot_apply_name_en,ot_apply_name_tw,login_channel_code,login_channel_name_zh,
login_channel_name_en,login_channel_name_tw,ot_form_status_code,ot_form_status_name_zh,ot_form_status_name_en,ot_form_status_name_tw,apv_status_code,apv_status_name_zh,
apv_status_name_en,apv_status_name_tw,apply_user_login_no,apply_user_name_zh,apply_user_name_en,apply_user_name_tw,org_id,org_name_zh,org_name_en,org_name_tw,sob_code,cc_code,
submit_time,apply_date,wkday_type_code,wkday_type_name_zh,wkday_type_name_en,wkday_type_name_tw,ot_mls_scene_code,ot_mls_scene_name_zh,ot_mls_scene_name_en,ot_mls_scene_name_tw,
submt_start_time,submt_end_time,std_amount,curr_code,curr_sign,is_project_flag,project_code,project_name_zh,project_name_en,project_name_tw,ot_apply_reason_zh,ot_apply_reason_en,
ot_apply_reason_tw,ot_apply_remark_zh,ot_apply_remark_en,ot_apply_remark_tw,order_code,outer_order_code,is_valid,data_source,create_user,create_time,update_user,update_time,
ot_form_confmn_status_code,ot_form_confmn_status_name_zh,ot_form_confmn_status_name_en,ot_form_confmn_status_name_tw,conformance_text,ot_form_pay_status,ot_form_pay_name_zh,
ot_form_pay_name_en,ot_form_pay_name_tw,apply_month,consume_amount
,inc_day 
from dm_meal.ft_meal_ot_apply_form_dtl where inc_day=
;


--丰享
insert overwrite table  dm_gis_uimp.ods_feng_tu_order_detail  partition(inc_day)  
select 
pid,pay_time,job_number,emp_user_name,product_name,product_spec_desc,sale_unit_price,quantity,real_freight_total_amount,order_id,order_status_name,pay_state,pay_type_desc,
order_type,output_tax_rate,order_item_id,item_refund_amount,order_refund_amount
,inc_day 
from ods_fx_dwd.dwd_feng_tu_order_detail where inc_day=
;



------------------------------------------------
------------------------------------------------
-- url: jdbc:mysql://gisissp-m.db.sfcloud.local:3306/gisissp?serverTimezone=Asia/Shanghai&characterEncoding=utf8&useSSL=false
-- username: gisissp
-- password: Gis@ISSP@GIS
-- 表名：issp_emp_data、issp_emp_data_ext


------------------------------------------------
--1、采购台账报表需求：https://doc.sf-express.com/view/l/t1luugs
--2、历史合同详情获取方案：https://doc.sf-express.com/view/l/tot955q
--

------------------------------------------------
-- kafka生产数据
-- MOM访问地址
-- http://tkafka-a1ytGmq8.kafka.sfcloud.local:1080/mom-mon/monitor/requestService.pub
-- 集群名: gis_issp_core_88tjwx8j
-- 版本: 2.5.1
-- topic: ISSP_DM_BDP
-- 生产者校验码： bJs0kyio
-- 消费组： DM_BDP
-- 消费组检验码：xjdVlife
--

-- 增量CTC合同数据接收
create table if not exists  dm_gis_uimp.ods_issp_kafka_tmp(
msg string comment 'kafka数据' 
)
comment 'issp_kafka' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
stored as textfile 
;

--
select get_json_object(msg,'$.tag'),get_json_object(msg,'$.data') from dm_gis_uimp.ods_issp_kafka_tmp limit 100


-- 历史CTC合同数据
create table if not exists  dm_gis_uimp.ods_ctc_history_tmp(
ht_code string,
msg string  
)
comment 'ctc合同历史' 
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES
("separatorChar"=",")
STORED AS TEXTFILE
tblproperties("skip.header.line.count"="1");

LOAD DATA  INPATH '/user/01416344/upload/ctc_history_detail.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_ctc_history_tmp;



--------------------2022.11.11------------------------
-- kafka数据分别写入不同表
create table if not exists  dm_gis_uimp.ods_issp_ctc(
content string comment '接口返回的json数据'    
)
comment 'CTC' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


set mapreduce.job.queuename=gis_public;
set hive.exec.dynamic.partition.mode=nonstrict;
set hive.optimize.sort.dynamic.partition=true;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set mapreduce.input.fileinputformat.split.maxsize=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.rack=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.node=268435456;
set mapred.max.split.size=268435456;
set mapred.min.split.size.per.node=268435456;
set mapred.min.split.size.per.rack=268435456;
--设置jvm重用
set mapred.job.reuse.jvm.num.tasks=10;

insert overwrite table dm_gis_uimp.ods_issp_ctc partition(inc_day)
select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_issp_kafka_tmp 
where get_json_object(msg,'$.tag')='CTC' 
and inc_day='20221111'
;

--
create table if not exists  dm_gis_uimp.ods_issp_crm_con(
content string comment '接口返回的json数据'    
)
comment 'CRM-CON' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


insert overwrite table dm_gis_uimp.ods_issp_crm_con partition(inc_day)
select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_issp_kafka_tmp 
where get_json_object(msg,'$.tag')='CRM-CON' 
and inc_day='20221111'
;

--
create table if not exists  dm_gis_uimp.ods_issp_crm_opp(
content string comment '接口返回的json数据'    
)
comment 'CRM-OPP' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');

insert overwrite table dm_gis_uimp.ods_issp_crm_opp partition(inc_day)
select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_issp_kafka_tmp 
where get_json_object(msg,'$.tag')='CRM-OPP' 
and inc_day='20221111'
;

--
create table if not exists  dm_gis_uimp.ods_issp_ykb_apply(
content string comment '接口返回的json数据'    
)
comment 'YKB-APPLY' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


insert overwrite table dm_gis_uimp.ods_issp_ykb_apply partition(inc_day)
select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_issp_kafka_tmp 
where get_json_object(msg,'$.tag')='YKB-APPLY' 
and inc_day='20221111'
;

--
create table if not exists  dm_gis_uimp.ods_issp_ykb_emp(
content string comment '接口返回的json数据'    
)
comment 'YKB-EMP' 
PARTITIONED BY (
`inc_day` string COMMENT '行为发生日期：yyyyMMdd')
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY '\t' 
STORED AS parquet
tblproperties ('parquet.compression'='snappy');


insert overwrite table dm_gis_uimp.ods_issp_ykb_emp partition(inc_day)
select 
get_json_object(msg,'$.data') as content,inc_day 
from dm_gis_uimp.ods_issp_kafka_tmp 
where get_json_object(msg,'$.tag')='YKB-EMP' 
and inc_day='20221111'
;


-----------------------------------
-- 一般采购合同台账
-- 1、场景1
-- 数据导入1: 初始化"一般采购合同台账"
-- 字段：签约主体 合同编号 合同状态 供应商名称 供应商编码 BU 大区 合同开始日期 合同结束日期 是否框架合同 销售项目 合同内容 经办人 采购组织 合同金额 税率 付款条件 已开票合同金额
create table dm_gis_uimp.ods_contract_base_input(
qyzt string comment '签约主体',
contract_no string comment '合同编号',
contract_stat string comment '合同状态',
gys_name string comment '供应商名称',
gys_code string comment '供应商编码',
htss_bu string comment 'BU',
htss_dq string comment '大区',
enable_date string comment '合同开始日期',
disable_date string comment '合同结束日期',
htlx string comment '是否框架合同',
htgsxmdm string comment '销售项目',
contract_content string comment '合同内容',
creater_name string comment '经办人',
create_organization string comment '采购组织',
amount string comment '合同金额',
tax_point string comment '税率',
payment_condition string comment '付款条件',
invoiced_amount string comment '已开票合同金额'
) 
comment '初始化一般采购合同台账' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/sample_all_1108.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_base_input partition (inc_day='20221114');

-- 数据导入2: 手工整理的财务数据
-- 字段：合同编号 是否需要预提 已付款已履约_手工 预付账款_手工 其他应收押金/保证金_手工 预付账款_已核销 其他应收押金/保证金_已核销 应付账款_FI 应付暂估 其他应付款_质保金
create table dm_gis_uimp.ods_contract_handwork_input(
contract_no string comment '合同编号',
is_withholding string comment '是否需要预提',
paid string comment '已付款已履约_手工',
ad_payment string comment '预付账款_手工',
earnest string comment '其他应收押金/保证金_手工',
ad_payment_off string comment '预付账款_已核销',
earnest_off string comment '其他应收押金/保证金_已核销',
payable_fi string comment '应付账款_FI',
payable_estimate string comment '应付暂估',
payable_other string comment '其他应付款_质保金'
) 
comment '手工整理的财务数据' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/sample_all_1108.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_handwork_input partition (inc_day='20221114');


-- 数据导入3: 无采购合同台账基础信息
-- 字段：签约主体 合同编号 合同状态 供应商名称 供应商编码 BU 大区 合同开始日期 合同结束日期 是否框架合同 销售项目 合同内容 经办人 采购组织 合同金额 税率 付款条件
create table dm_gis_uimp.ods_contract_wopo_input(
qyzt string comment '签约主体',
contract_no string comment '合同编号',
contract_stat string comment '合同状态',
gys_name string comment '供应商名称',
gys_code string comment '供应商编码',
htss_bu string comment 'BU',
htss_dq string comment '大区',
enable_date string comment '合同开始日期',
disable_date string comment '合同结束日期',
htlx string comment '是否框架合同',
htgsxmdm string comment '销售项目',
contract_content string comment '合同内容',
creater_name string comment '经办人',
create_organization string comment '采购组织',
amount string comment '合同金额',
tax_point string comment '税率',
payment_condition string comment '付款条件'
) 
comment '无采购合同台账基础信息' 
PARTITIONED BY (inc_day string COMMENT '分区日期')
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
tblproperties('skip.header.line.count'='1');

-- load_data
LOAD DATA  INPATH '/user/01416344/upload/sample_all_1108.csv' OVERWRITE INTO TABLE dm_gis_uimp.ods_contract_wopo_input partition (inc_day='20221114');



-- 数据导入4：BU-业务线映射关系
-- 字段：BU 业务线
create table dm_gis_uimp.dim_bu_business_lines(
bu string comment 'BU',
business_lines string comment '业务线'
) 
comment 'BU-业务线映射关系' 
STORED AS TEXTFILE;

insert into  dm_gis_uimp.dim_bu_business_lines values ('保险', '交通货运业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('运营商', '交通货运业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('创新业务', '交通货运业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('交通', '交通货运业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('交警', '交通货运业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('数字政府', '数字孪生业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('图安', '数字孪生业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('产业经济', '数字孪生业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('未来产城', '数字孪生业务线');
insert into  dm_gis_uimp.dim_bu_business_lines values ('智慧社区', '智慧社区业务线');

-- 数据导入5：状态名称-状态ID映射关系
-- 字段：合同状态名称 合同状态id
create table dm_gis_uimp.dim_contract_stat_id(
contract_stat string comment '合同状态名称',
contract_stat_id string comment '合同状态id'
) 
comment '状态名称-状态ID映射关系' 
STORED AS TEXTFILE;

insert into  dm_gis_uimp.dim_contract_stat_id values ('合同状态名称','合同状态id');
insert into  dm_gis_uimp.dim_contract_stat_id values ('草稿','101');
insert into  dm_gis_uimp.dim_contract_stat_id values ('创建异常','199');
insert into  dm_gis_uimp.dim_contract_stat_id values ('待审核','201');
insert into  dm_gis_uimp.dim_contract_stat_id values ('审核中','202');
insert into  dm_gis_uimp.dim_contract_stat_id values ('审批通过','203');
insert into  dm_gis_uimp.dim_contract_stat_id values ('审批驳回','204');
insert into  dm_gis_uimp.dim_contract_stat_id values ('审批撤回','205');
insert into  dm_gis_uimp.dim_contract_stat_id values ('审批流程启动失败','206');
insert into  dm_gis_uimp.dim_contract_stat_id values ('审批流程已发起','207');
insert into  dm_gis_uimp.dim_contract_stat_id values ('审批异常','209');
insert into  dm_gis_uimp.dim_contract_stat_id values ('待签章','301');
insert into  dm_gis_uimp.dim_contract_stat_id values ('已发起签章','302');
insert into  dm_gis_uimp.dim_contract_stat_id values ('签章拒签','305');
insert into  dm_gis_uimp.dim_contract_stat_id values ('签章过期','307');
insert into  dm_gis_uimp.dim_contract_stat_id values ('签章异常','309');
insert into  dm_gis_uimp.dim_contract_stat_id values ('待生效','401');
insert into  dm_gis_uimp.dim_contract_stat_id values ('已生效','403');
insert into  dm_gis_uimp.dim_contract_stat_id values ('已终止','404');
insert into  dm_gis_uimp.dim_contract_stat_id values ('已到期','405');
insert into  dm_gis_uimp.dim_contract_stat_id values ('已失效','406');
insert into  dm_gis_uimp.dim_contract_stat_id values ('生效已变更','407');
insert into  dm_gis_uimp.dim_contract_stat_id values ('发起推送异常','501');
insert into  dm_gis_uimp.dim_contract_stat_id values ('已删除','-1');


-- 2、场景2和场景3
-- 2.1、dm_gis_uimp.ods_issp_ctc  
int_sql="select content from dm_gis_uimp.ods_issp_ctc"
out_table1="dm_gis_oms.dwd_issp_ctc"
main="com.sf.gis.scala.tals.app.UimpCtcApp"

-- 2.2、dm_gis_uimp.ods_plf_form_body
-- contract_no,update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,order_no,totol_foreign_money 


select contract_no,update_time,total_cur_pay_money,order_type_code,business_type_code,order_status,order_no,totol_foreign_money 
from dm_gis_uimp.ods_plf_form_body

-- 2.3、dm_gis_uimp.ods_plf_form_apprecial_tax_detail
-- order_no,totol_money
select order_no,totol_money from dm_gis_uimp.ods_plf_form_apprecial_tax_detail

-- 2.4、数据导入2  数据导入4  数据导入5




---------------------------------------
-- 无采购合同台账
-- 1、数据导入3

-- 2、数据导入2

-- 3、数据导入4



