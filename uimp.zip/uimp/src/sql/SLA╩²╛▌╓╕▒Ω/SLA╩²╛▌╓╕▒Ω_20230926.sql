-- 
-- 
-- 需求方：段嫦慧(01425247)
-- 需求： 用户需求 1582023 【GIS-BIL-CORE】：SLA数据指标需求_V1.0_数据侧 
-- @author 张小琼 （01416344）
-- Created on 2023-09-28
-- 任务信息： 新平台  ID: 668  sla数据指标 ; ID: 678  sla数据指标clickhouse
-- 

-- 输入数据（系统接口清单）
create table sla_input_data(
index string ,
service string,
api string,
response_average string,
response_99 string,
sys_code string,
service_name string 
)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;

LOAD DATA  INPATH '/dolphinscheduler/user/01416344/系统-接口对照表.csv' OVERWRITE INTO TABLE sla_input_data;

create table dm_gis.sla_input_data as 
select * from sla_input_data;

-- 输出
dm_gis.dm_sla_indicators


insert overwrite table dm_gis.dm_sla_indicators partition(month='202309')
select * from dm_gis.dm_sla_indicators where month='202309' and week<>'3'
;


-- SLA补数
create table sla_csv_data(
index string ,
service string,
api string,
response_average string,
response_99 string,
sys_code string,
service_name string 
)
row format serde 'org.apache.hadoop.hive.serde2.OpenCSVSerde' WITH SERDEPROPERTIES ('separatorChar'=',')
STORED AS TEXTFILE
;