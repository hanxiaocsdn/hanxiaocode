#!/usr/bin/python
# -*- coding:utf-8 -*-
# 需求方：林中莉(01423677)
# 需求： 用户需求 2162978  【经营看板专项】回款业绩底表_V1.3_01416344_张小琼
# @author 张小琼 （01416344）
# Created on 2023.12.18
# 任务信息：调接口获取回款数据

from pyspark import SparkContext
from pyspark import SparkConf
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import requests
import json
import pandas as pd
from datetime import datetime, timedelta
import sys


# # 接口url及headers参数
# url = 'http://gis-iis-bill-ui.sit.sf-express.com/bill/api/acceptOrder/amtRet/list'
# print("请求url: "+url)
# headers = {"appSign":"1236666"}
# print("headers: "+str(headers))

url = 'https://ftbill.sf-express.com/bill/api/acceptOrder/amtRet/list'
print("请求url: "+url)
headers = {"appSign":"1236666"}
print("headers: "+str(headers))



# 获取接口数据
def get_api_data(param):
    ''' 调接口获取数据 '''

    res = requests.get(url, headers=headers, params=param)
    # 检查请求是否成功
    if res.status_code == 200:
        # 将返回的数据转换为JSON格式
        res_json = json.loads(res.text)
        if res_json['success'] == True:
            total = res_json['result']['total']
            pageSize = res_json['result']['pageSize']
            pageNo = res_json['result']['pageNo']
            rows = res_json['result']['rows']
            row_lst = []
            for row in rows:
                tmp_lst = [row['id'],row['claimFormNo'],row['supplementaryAgreementCode'],'' if row['orderType'] is None else int(row['orderType']),row['originClaimFormNo'],row['ecpContractCode'],row['unitName'],row['companyContractCode'],row['reviewEmpNo'],row['reviewEmpName']
                        ,row['deReviewEmpNo'],row['deReviewEmpName'],row['deReviewReason'],row['paymentId'],row['amtClaimed'],row['amtToBeClaim'],row['entryAcctPeriod'],row['bukrs'],row['butxt'],row['tradeTime']
                        ,row['objAcctName'],row['amt'],row['customerName'],row['contractAmount'],row['orderCode'],row['amtOrder'],row['status'],'' if row['checkStatus'] is None else int(row['checkStatus']),row['modifyAt'],row['createAt']
                        ,row['claimedAt'],row['empNo'],row['empName'],row['approvedDate']] 
                row_lst.append(tmp_lst)
            rows_df = pd.DataFrame(row_lst, columns=['id','claimFormNo','supplementaryAgreementCode','orderType','originClaimFormNo','ecpContractCode','unitName','companyContractCode','reviewEmpNo','reviewEmpName'
                                            ,'deReviewEmpNo','deReviewEmpName','deReviewReason','paymentId','amtClaimed','amtToBeClaim','entryAcctPeriod','bukrs','butxt','tradeTime'
                                            ,'objAcctName','amt','customerName','contractAmount','orderCode','amtOrder','status','checkStatus','modifyAt','createAt'
                                            ,'claimedAt','empNo','empName','approvedDate'])
            rows_df = rows_df.fillna('')

            return total,pageSize,pageNo,rows_df 
    


# 将Pandas DataFrame转换为PySpark DataFrame
schema = T.StructType([
    T.StructField('id', T.StringType()),
    T.StructField('claimFormNo', T.StringType()),
    T.StructField('supplementaryAgreementCode', T.StringType()),
    T.StructField('orderType', T.StringType()),
    T.StructField('originClaimFormNo', T.StringType()),
    T.StructField('ecpContractCode', T.StringType()),
    T.StructField('unitName', T.StringType()),
    T.StructField('companyContractCode', T.StringType()),
    T.StructField('reviewEmpNo', T.StringType()),
    T.StructField('reviewEmpName', T.StringType()),

    T.StructField('deReviewEmpNo', T.StringType()),
    T.StructField('deReviewEmpName', T.StringType()),
    T.StructField('deReviewReason', T.StringType()),
    T.StructField('paymentId', T.StringType()),
    T.StructField('amtClaimed', T.StringType()),
    T.StructField('amtToBeClaim', T.StringType()),
    T.StructField('entryAcctPeriod', T.StringType()),
    T.StructField('bukrs', T.StringType()),
    T.StructField('butxt', T.StringType()),
    T.StructField('tradeTime', T.StringType()),

    T.StructField('objAcctName', T.StringType()),
    T.StructField('amt', T.StringType()),
    T.StructField('customerName', T.StringType()),
    T.StructField('contractAmount', T.StringType()),
    T.StructField('orderCode', T.StringType()),
    T.StructField('amtOrder', T.StringType()),
    T.StructField('status', T.StringType()),
    T.StructField('checkStatus', T.StringType()),
    T.StructField('modifyAt', T.StringType()),
    T.StructField('createAt', T.StringType()),

    T.StructField('claimedAt', T.StringType()),
    T.StructField('empNo', T.StringType()),
    T.StructField('empName', T.StringType()),
    T.StructField('approvedDate', T.StringType()) 
])


if __name__=='__main__':

    print("==========app start=========")
    spark = SparkSession.builder.enableHiveSupport().getOrCreate() 

    # input_date = '20231130'
    input_date = sys.argv[1]
    print("input_date :" + input_date)

    print("end_date: '{}'".format(input_date))
    # 取日期
    end_date = datetime.strptime(input_date, '%Y%m%d')
    star_date = end_date-timedelta(days=7)
    # star_date = datetime.strptime('20230730', '%Y%m%d')
    print("star_date: '{}'".format(str(star_date)))


    # 调接口获取数据 （第一次） 
    param = {
            # "enterAccountBeginDate":int(1000*star_date.timestamp()),
            # "enterAccountEndDate":int(1000*end_date.timestamp()),
            # "claimedAtBeginDate":str(star_date),
            # "claimedAtEndDate":str(end_date),
            "pageNo":1,
            "pageSize":100}
    
    apires = get_api_data(param)
    if apires!=None and int(apires[0])>0:
        print("总行数：{}".format(apires[0]))
        print("调接口获取数据 （第1次）.")

        rows_df = apires[3]
        print("rows_df : ")
        print(rows_df.head())

        df_spark = spark.createDataFrame(rows_df, schema)
        df_spark.show(10)

        df_spark.createTempView('tmp_ods_bill_amt_ret_claim_form')
        df_res = spark.sql('insert into dm_gis_uimp.ods_bill_amt_ret_claim_form_mid partition(inc_day='+ input_date +') select * from tmp_ods_bill_amt_ret_claim_form')
        df_res.show(10)

    else:
        print("apires无数据。")


    
    # 调接口获取数据 （第i次,i从2开始）
    if apires!=None and int(apires[0])>100:
        N = int(int(apires[0])/apires[1])
        for i in range(1,N+1,1):
            print("调接口获取数据 （第{}次）.".format(str(i+1)))
            param = {
                    # "enterAccountBeginDate":int(1000*star_date.timestamp()),
                    # "enterAccountEndDate":int(1000*end_date.timestamp()),
                    # "claimedAtBeginDate":str(star_date),
                    # "claimedAtEndDate":str(end_date),
                    "pageNo":i+1,
                    "pageSize":100}
            apires = get_api_data(param)
            # print(apires)
            
            if apires!=None:
                df_spark1 = spark.createDataFrame(apires[3], schema)
                df_spark1.createTempView('tmp_ods_bill_amt_ret_claim_form_'+str(i))
                df_res1 = spark.sql('insert into dm_gis_uimp.ods_bill_amt_ret_claim_form_mid partition(inc_day='+ input_date +') select * from tmp_ods_bill_amt_ret_claim_form_'+str(i))
                df_res1.show(10)

    print("==========app stop=========")
    spark.stop()


