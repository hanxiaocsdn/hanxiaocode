#!/usr/bin/python
# -*- coding:utf-8 -*-
# 需求方：林中莉(01423677)
# 需求：用户需求 2162921  经营看板专项】收入业绩底表_V1.3 
# @author 张小琼 （01416344）
# Created on 2023.12.18
# 任务信息：调接口获取收入数据

from pyspark import SparkContext
from pyspark import SparkConf
from pyspark.sql import SparkSession
import pyspark.sql.types as T
import requests
import json
import pandas as pd
from datetime import datetime, timedelta
import sys


# 接口url及headers参数
# url = 'http://gis-iis-bill-ui.sit.sf-express.com/bill/api/acceptOrder/income/list'
# print("请求url: "+url)
# headers = {"appSign":"1236666"}
# print("headers: "+str(headers))

url = 'https://ftbill.sf-express.com/bill/api/acceptOrder/income/list'
print("请求url: "+url)
headers = {"appSign":"1236666"}
print("headers: "+str(headers))

# 获取接口数据
def get_api_data(param):
    ''' 调接口获取数据 '''

    res = requests.get(url, headers=headers, params=param)
    # 检查请求是否成功
    if res.status_code == 200:
        # 将返回的数据转换为JSON格式
        res_json = json.loads(res.text)
        if res_json['success'] == True:
            total = res_json['result']['total']
            pageSize = res_json['result']['pageSize']
            pageNo = res_json['result']['pageNo']
            rows = res_json['result']['rows'] 
            row_lst = []
            for row in rows:
                tmp_lst = [row['id'],row['incomeNumber'],row['businessType'],row['orderDate'],row['enterAccountDate'],row['companyCode'],row['customerName'],row['customerNameVal'],row['orderNumber'],row['companyContractCode']
                           ,'' if row['orderStatus'] is None else int(row['orderStatus']),'' if row['orderType'] is None else int(row['orderType']),row['ecpContractCode'],row['orderCode'],row['cheackStatus'],row['performanceId'],row['performanceType'],row['performanceDetail'],row['taxRate'],row['currentRateAmount']
                           ,row['currentAmount'],row['performanceRateAmount'],row['performanceAmount'],row['incomeNode'],row['adjustNumber'],row['supplementContractCode'],row['chargeOffRateAmount'],row['chargeOffAmount'],row['chargeOffType'],row['incomeRateAmount']
                           ,row['incomeAmount']]
                row_lst.append(tmp_lst)
            rows_df = pd.DataFrame(row_lst, columns=['id','incomeNumber','businessType','orderDate','enterAccountDate','companyCode','customerName','customerNameVal','orderNumber','companyContractCode'
                                                ,'orderStatus','orderType','ecpContractCode','orderCode','cheackStatus','performanceId','performanceType','performanceDetail','taxRate','currentRateAmount'
                                                ,'currentAmount','performanceRateAmount','performanceAmount','incomeNode','adjustNumber','supplementContractCode','chargeOffRateAmount','chargeOffAmount','chargeOffType','incomeRateAmount'
                                                ,'incomeAmount'])
            rows_df = rows_df.fillna('')

            return total,pageSize,pageNo,rows_df 


# 将Pandas DataFrame转换为PySpark DataFrame
schema = T.StructType([
    T.StructField('id', T.StringType()),
    T.StructField('incomeNumber', T.StringType()),
    T.StructField('businessType', T.StringType()),
    T.StructField('orderDate', T.StringType()),
    T.StructField('enterAccountDate', T.StringType()),
    T.StructField('companyCode', T.StringType()),
    T.StructField('customerName', T.StringType()),
    T.StructField('customerNameVal', T.StringType()),
    T.StructField('orderNumber', T.StringType()),
    T.StructField('companyContractCode', T.StringType()),

    T.StructField('orderStatus', T.StringType()),
    T.StructField('orderType', T.StringType()),
    T.StructField('ecpContractCode', T.StringType()),
    T.StructField('orderCode', T.StringType()),
    T.StructField('cheackStatus', T.StringType()),
    T.StructField('performanceId', T.StringType()),
    T.StructField('performanceType', T.StringType()),
    T.StructField('performanceDetail', T.StringType()),
    T.StructField('taxRate', T.StringType()),
    T.StructField('currentRateAmount', T.StringType()),

    T.StructField('currentAmount', T.StringType()),
    T.StructField('performanceRateAmount', T.StringType()),
    T.StructField('performanceAmount', T.StringType()),
    T.StructField('incomeNode', T.StringType()),
    T.StructField('adjustNumber', T.StringType()),
    T.StructField('supplementContractCode', T.StringType()),
    T.StructField('chargeOffRateAmount', T.StringType()),
    T.StructField('chargeOffAmount', T.StringType()),
    T.StructField('chargeOffType', T.StringType()),
    T.StructField('incomeRateAmount', T.StringType()),

    T.StructField('incomeAmount', T.StringType()) 
])



if __name__=='__main__':

    print("==========app start=========")
    spark = SparkSession.builder.enableHiveSupport().getOrCreate() 

    # input_date = '20231130'
    input_date = sys.argv[1]
    print("input_date :" + input_date)

    print("end_date: '{}'".format(input_date))
    # 取日期
    end_date = datetime.strptime(input_date, '%Y%m%d')
    star_date = end_date-timedelta(days=31)
    # star_date = datetime.strptime('20230730', '%Y%m%d')
    print("star_date: '{}'".format(str(star_date)))


    # 调接口获取数据 （第一次） 
    param = {
            "enterAccountBeginDate":int(1000*star_date.timestamp()),
            "enterAccountEndDate":int(1000*end_date.timestamp()),
            "pageNo":1,
            "pageSize":100}
    
    apires = get_api_data(param)
    
    if apires!=None and int(apires[0])>0:
        print("总行数：{}".format(apires[0]))
        print("调接口获取数据 （第1次）.")

        rows_df = apires[3]
        print("rows_df : ")
        print(rows_df.head())
        df_spark = spark.createDataFrame(rows_df, schema)
        df_spark.show(10)

        df_spark.createTempView('tmp_ods_bill_income_comfirm')
        df_res = spark.sql('insert into dm_gis_uimp.ods_bill_income_comfirm_mid partition(inc_day='+ input_date +')  select * from tmp_ods_bill_income_comfirm')
        df_res.show(10)
    
    else:
        print("apires无数据。")


    # 调接口获取数据 （第i次,i从2开始）
    if apires!=None and int(apires[0])>100:
        N = int(int(apires[0])/apires[1])
        for i in range(1,N+1,1):
            print("调接口获取数据 （第{}次）.".format(str(i+1)))
            param = {
                    "enterAccountBeginDate":int(1000*star_date.timestamp()),
                    "enterAccountEndDate":int(1000*end_date.timestamp()),
                    "pageNo":i+1,
                    "pageSize":100}
            apires = get_api_data(param)
            # print(apires)

            if apires!=None:
                df_spark1 = spark.createDataFrame(apires[3], schema)
                df_spark1.createTempView('tmp_ods_bill_income_comfirm_'+str(i))
                df_res1 = spark.sql('insert into dm_gis_uimp.ods_bill_income_comfirm_mid partition(inc_day='+ input_date +')  select * from tmp_ods_bill_income_comfirm_'+str(i))
                df_res1.show(10)

    print("==========app stop=========")
    spark.stop()


