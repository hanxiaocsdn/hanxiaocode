package com.sf.gis.uimp.func;

import org.apache.flink.api.common.functions.RichMapFunction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 预算可用余额实时写入clickhouse  (Flink Drag 任务 Map 函数)
 * 需求方：林中莉 (01423677)
 * @author 张小琼 （01416344）
 * Created on 2023-11-17
 * 任务信息： 实时任务 任务ID： 20002985    ISSP_TO_HIVE
 *
 */
public class ForecastMapFunction extends RichMapFunction<String,String> {
    private static Logger logger = LoggerFactory.getLogger(ForecastMapFunction.class);
    private String mapData(String sourceData) {
        return sourceData;
    }

    @Override
    public String map(String sourceData) {
        if(sourceData==null){
            return null;
        }
        String ret = null;
        ret = mapData(sourceData);
        return ret;
    }


}
