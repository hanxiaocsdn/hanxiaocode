package com.sf.gis.uimp.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.connector.jdbc.JdbcConnectionOptions;
import org.apache.flink.connector.jdbc.JdbcExecutionOptions;
import org.apache.flink.connector.jdbc.JdbcStatementBuilder;
import org.apache.flink.streaming.api.datastream.DataStream;

import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.streaming.util.serialization.SimpleStringSchema;
import org.apache.flink.util.Collector;

import org.apache.flink.connector.jdbc.JdbcSink;

import java.math.BigDecimal;
import java.sql.Driver;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class KafkaTestApp {

    public static void main(String[] args) throws Exception {

        // 初始化 flink 执行环境
        //配置流处理环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        //并发度设为1
        env.setParallelism(1);
        //kafka连接信息
        Properties properties =new Properties();
        properties.put("bootstrap.servers","10.202.218.1:9092");
        properties.put("group.id","zxqtest");


        // Kafka 主题和分区数量
        String topic = "dblab01";
        int numPartitions = 1;

        // 创建 Kafka 消费者
        FlinkKafkaConsumer<String> kafkaSource = new FlinkKafkaConsumer<String>(topic,new SimpleStringSchema(),properties);


        DataStream<String> ds = env.addSource(kafkaSource);

        // FlatMap分拆JsonArray
        DataStream<String> flatRes = ds.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public void flatMap(String sourceData, Collector<String> collector) throws Exception {
                JSONObject resultObj = JSON.parseObject(sourceData);
                if (null != resultObj) {
                    String tag = JSONUtil.getJsonVal(resultObj, "tag", "");
                    String queryTime = JSONUtil.getJsonVal(resultObj, "queryTime", "");

                    if ((null != tag) && ("REMAIN_BUDGET".equals(tag))) {
                        JSONArray dataArr = resultObj.getJSONArray("data");
                        for (int i = 0; i < dataArr.size(); i++) {
                            JSONObject forecast = JSONUtil.parseJSONObject(dataArr.get(i).toString());
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("id", forecast.getString("id"));
                            jsonObject.put("year", forecast.getString("year"));
                            jsonObject.put("buNo", forecast.getString("buNo"));
                            jsonObject.put("buName", forecast.getString("buName"));
                            jsonObject.put("busiTypeCode", forecast.getString("busiTypeCode"));
                            jsonObject.put("busiTypeName", forecast.getString("busiTypeName"));
                            jsonObject.put("projectCode", forecast.getString("projectCode"));
                            jsonObject.put("projectName", forecast.getString("projectName"));
                            jsonObject.put("costCenterCode", forecast.getString("costCenterCode"));
                            jsonObject.put("costCenterName", forecast.getString("costCenterName"));
                            jsonObject.put("businessNumber", forecast.getString("businessNumber"));
                            jsonObject.put("businessName", forecast.getString("businessName"));
                            jsonObject.put("fsFirstCode", forecast.getString("fsFirstCode"));
                            jsonObject.put("fsFirstName", forecast.getString("fsFirstName"));
                            jsonObject.put("fsSecondCode", forecast.getString("fsSecondCode"));
                            jsonObject.put("fsSecondName", forecast.getString("fsSecondName"));
                            jsonObject.put("acount", (null!=forecast.getString("acount")) ? new BigDecimal(forecast.getString("acount").replace(",","")) : null);
                            jsonObject.put("applyAcount", (null!=forecast.getString("applyAcount")) ? new BigDecimal(forecast.getString("applyAcount").replace(",","")): null);
                            jsonObject.put("useAcount", (null!=forecast.getString("useAcount")) ? new BigDecimal(forecast.getString("useAcount").replace(",","")) : null);
                            jsonObject.put("remainAcount", (null!=forecast.getString("remainAcount")) ? new BigDecimal(forecast.getString("remainAcount").replace(",","")) : null);
                            jsonObject.put("deptManagerEmpNo", forecast.getString("deptManagerEmpNo"));
                            jsonObject.put("incDatetime", queryTime);
                            collector.collect(jsonObject.toJSONString());
                        }
                    }
                }
            }
        }) ;


        flatRes.print();

        // Map 字段解析并转换
        SingleOutputStreamOperator<String> res  = flatRes.map(new MapFunction<String, String>() {
            @Override
            public String map(String stringTuple2) throws Exception {
                return stringTuple2;
            }
        });

        res.print();


        //准备向ClickHouse中插入数据的sql
//        String insetIntoCkSql = "insert into default.gis_forecast (id,b_year,bu_no,bu_name,busi_type_code,busi_type_name,project_code,projec_name,\n" +
//                "cost_center_code,cost_center_name,business_number,business_name,fs_first_code,fs_first_name,\n" +
//                "fs_second_code,fs_second_name ) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";


        String insetIntoCkSql = "insert into default.gis_forecast (id,b_year,bu_no,bu_name,busi_type_code,busi_type_name,project_code,projec_name,\n" +
                "cost_center_code,cost_center_name,business_number,business_name,fs_first_code,fs_first_name,\n" +
                "fs_second_code,fs_second_name,acount,apply_acount,use_acount,remain_acount,dept_manager_mp_no,inc_datetime ) " +
                "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

        //JdbcStatementBuilder
        JdbcStatementBuilder<String> ckBuild = new JdbcStatementBuilder<String>() {
            @Override
            public void accept(PreparedStatement preparedStatement, String jsonStr) throws SQLException {
                JSONObject logEvent = JSONUtil.parseJSONObject(jsonStr);
                preparedStatement.setString(1, logEvent.getString("id"));
                preparedStatement.setString(2, logEvent.getString("year"));
                preparedStatement.setString(3, logEvent.getString("buNo"));
                preparedStatement.setString(4, logEvent.getString("buName"));
                preparedStatement.setString(5, logEvent.getString("busiTypeCode"));
                preparedStatement.setString(6, logEvent.getString("busiTypeName"));
                preparedStatement.setString(7, logEvent.getString("projectCode"));
                preparedStatement.setString(8, logEvent.getString("projectName"));
                preparedStatement.setString(9, logEvent.getString("costCenterCode"));
                preparedStatement.setString(10, logEvent.getString("costCenterName"));
                preparedStatement.setString(11, logEvent.getString("businessNumber"));
                preparedStatement.setString(12, logEvent.getString("businessName"));
                preparedStatement.setString(13, logEvent.getString("fsFirstCode"));
                preparedStatement.setString(14, logEvent.getString("fsFirstName"));
                preparedStatement.setString(15, logEvent.getString("fsSecondCode"));
                preparedStatement.setString(16, logEvent.getString("fsSecondName"));
                preparedStatement.setBigDecimal(17, logEvent.getBigDecimal("acount"));
                preparedStatement.setBigDecimal(18, logEvent.getBigDecimal("applyAcount"));
                preparedStatement.setBigDecimal(19, logEvent.getBigDecimal("useAcount"));
                preparedStatement.setBigDecimal(20, logEvent.getBigDecimal("remainAcount"));
                preparedStatement.setString(21, logEvent.getString("deptManagerEmpNo"));
                preparedStatement.setString(22, logEvent.getString("incDatetime"));
            }
        };


//        String insetIntoCkSql = "insert into default.gis_forecast FORMAT JSONEachRow ?\r\n";
//
//        JdbcStatementBuilder<String> ckBuild = new JdbcStatementBuilder<String>() {
//            @Override
//            public void accept(PreparedStatement preparedStatement, String jsonStr) throws SQLException {
//                JSONObject forecast = JSONUtil.parseJSONObject(jsonStr);
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("id", forecast.getString("id"));
//                jsonObject.put("b_year", forecast.getString("year"));
//                jsonObject.put("bu_no", forecast.getString("buNo"));
//                jsonObject.put("bu_name", forecast.getString("buName"));
//                jsonObject.put("busi_type_code", forecast.getString("busiTypeCode"));
//                jsonObject.put("busi_type_name", forecast.getString("busiTypeName"));
//                jsonObject.put("project_code", forecast.getString("projectCode"));
//                jsonObject.put("projec_name", forecast.getString("projectName"));
//                jsonObject.put("cost_center_code", forecast.getString("costCenterCode"));
//                jsonObject.put("cost_center_name", forecast.getString("costCenterName"));
//                jsonObject.put("business_number", forecast.getString("businessNumber"));
//                jsonObject.put("business_name", forecast.getString("businessName"));
//                jsonObject.put("fs_first_code", forecast.getString("fsFirstCode"));
//                jsonObject.put("fs_first_name", forecast.getString("fsFirstName"));
//                jsonObject.put("fs_second_code", forecast.getString("fsSecondCode"));
//                jsonObject.put("fs_second_name", forecast.getString("fsSecondName"));
//                jsonObject.put("acount", forecast.getString("acount"));
//                jsonObject.put("apply_acount", forecast.getString("applyAcount"));
//                jsonObject.put("use_acount", forecast.getString("useAcount"));
//                jsonObject.put("remain_acount", forecast.getString("remainAcount"));
//                jsonObject.put("dept_manager_mp_no", forecast.getString("deptManagerEmpNo"));
//                jsonObject.put("inc_datetime", forecast.getString("incDatetime"));
//                System.out.printf(jsonObject.toJSONString());
//
////                preparedStatement.setString(1,jsonObject.toJSONString(jsonObject, SerializerFeature.WriteMapNullValue));
//                preparedStatement.setString(1,jsonObject.toJSONString());
//            }
//
//        };


        //设置ClickHouse Sink
        SinkFunction<String> sink = JdbcSink.sink(
                //插入数据SQL
                insetIntoCkSql,
                //设置插入ClickHouse数据的参数
                ckBuild,
                //设置批次插入数据
                new JdbcExecutionOptions.Builder()
                        // 批次大小，默认5000
                        .withBatchSize(10000)
                        // 批次间隔时间
                        .withBatchIntervalMs(5000).
                        withMaxRetries(3).build(),
                //设置连接ClickHouse的配置
                new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                        .withDriverName("ru.yandex.clickhouse.ClickHouseDriver")
                        .withUrl("jdbc:clickhouse://10.202.218.1:8123")
                        .withUsername("default")
                        .withPassword("123456")
                        .build()
        );

        //所有数据进入基础库
        res.addSink(sink);
        res.print("基础库clickhouse");


        // execute
        env.execute("sink-clickhouse");


    }


}
