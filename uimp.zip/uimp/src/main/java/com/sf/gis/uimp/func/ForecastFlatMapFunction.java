package com.sf.gis.uimp.func;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.scala.base.util.JSONUtil;
import org.apache.flink.api.common.functions.RichFlatMapFunction;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.math.BigDecimal;

/**
 *  预算可用余额实时写入clickhouse  (Flink Drag 任务 flatMap 函数)
 * 需求方：林中莉 (01423677)
 * @author 张小琼 （01416344）
 * Created on 2023-11-17
 * 任务信息： 实时任务 任务ID： 20002985    ISSP_TO_HIVE
 *
 */
public class ForecastFlatMapFunction extends RichFlatMapFunction<String,String> {
    private static Logger logger = LoggerFactory.getLogger(ForecastFlatMapFunction.class);


    @Override
    public void flatMap(String sourceData, Collector<String> collector) throws Exception {
        JSONObject resultObj = JSON.parseObject(sourceData);
        if (null != resultObj) {
            String tag = JSONUtil.getJsonVal(resultObj, "tag", "");
            String queryTime = JSONUtil.getJsonVal(resultObj, "queryTime", "");

            if ((null != tag) && ("REMAIN_BUDGET".equals(tag))) {
                JSONArray dataArr = resultObj.getJSONArray("data");
                for (int i = 0; i < dataArr.size(); i++) {
                    JSONObject forecast = JSONUtil.parseJSONObject(dataArr.get(i).toString());
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("id", forecast.getString("id"));
                    jsonObject.put("b_year", forecast.getString("year"));
                    jsonObject.put("bu_no", forecast.getString("buNo"));
                    jsonObject.put("bu_name", forecast.getString("buName"));
                    jsonObject.put("busi_type_code", forecast.getString("busiTypeCode"));
                    jsonObject.put("busi_type_name", forecast.getString("busiTypeName"));
                    jsonObject.put("project_code", forecast.getString("projectCode"));
                    jsonObject.put("projec_name", forecast.getString("projectName"));
                    jsonObject.put("cost_center_code", forecast.getString("costCenterCode"));
                    jsonObject.put("cost_center_name", forecast.getString("costCenterName"));
                    jsonObject.put("business_number", forecast.getString("businessNumber"));
                    jsonObject.put("business_name", forecast.getString("businessName"));
                    jsonObject.put("fs_first_code", forecast.getString("fsFirstCode"));
                    jsonObject.put("fs_first_name", forecast.getString("fsFirstName"));
                    jsonObject.put("fs_second_code", forecast.getString("fsSecondCode"));
                    jsonObject.put("fs_second_name", forecast.getString("fsSecondName"));
                    jsonObject.put("acount", (null!=forecast.getString("acount")) ? new BigDecimal(forecast.getString("acount").replace(",","")) : null);
                    jsonObject.put("apply_acount", (null!=forecast.getString("applyAcount")) ? new BigDecimal(forecast.getString("applyAcount").replace(",","")): null);
                    jsonObject.put("use_acount", (null!=forecast.getString("useAcount")) ? new BigDecimal(forecast.getString("useAcount").replace(",","")) : null);
                    jsonObject.put("remain_acount", (null!=forecast.getString("remainAcount")) ? new BigDecimal(forecast.getString("remainAcount").replace(",","")) : null);
                    jsonObject.put("dept_manager_mp_no", forecast.getString("deptManagerEmpNo"));
                    jsonObject.put("inc_datetime", queryTime);
                    collector.collect(jsonObject.toJSONString());
                }
            }
        }

    }
}
