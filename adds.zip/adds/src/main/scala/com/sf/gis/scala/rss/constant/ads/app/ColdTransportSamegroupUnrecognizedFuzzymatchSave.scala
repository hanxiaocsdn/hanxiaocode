package com.sf.gis.scala.rss.constant.ads.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.SparkUtils
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil, Util}
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients
import org.apache.http.message.BasicHeader
import org.apache.http.protocol.HTTP
import org.apache.http.util.EntityUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * 【特殊入仓】冷运同大组用未识别地址配置模糊tag_V1.1
  * 需求：谭雨祯 01425216
  * 任务id：967849
  * 开发：01412406
  */

object ColdTransportSamegroupUnrecognizedFuzzymatchSave {
  @transient lazy val logger: Logger = Logger.getLogger(ColdTransportSamegroupUnrecognizedFuzzymatchSave.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val detailName1 = "dm_gis.dm_specialstorage_lengyun_tagfuzzy_modify_detail_di"
  val tableName1 = "dm_gis.dm_specialstorage_lengyun_tagfuzzy_modify_di"
  val detailName2 = "dm_gis.dm_specialstorage_lengyun_tagfuzzy_modify_req_detail_di"
  val tableName2 = "dm_gis.dm_specialstorage_lengyun_wsbwaybill_inprocess2_di"

  val ptUrl = "http://seg.sf-express.com/erraddress/baseaddressLengyun/updateByWorker"
  val cmsLimit = 100
  val account = "01412406"
  val taskId = ""
  val taskName = "冷运同大组用未识别地址配置模糊tag_ColdTransportSamegroupUnrecognizedFuzzymatchSave"
  val taskDesc = "冷运同大组用未识别地址配置模糊tag_ColdTransportSamegroupUnrecognizedFuzzymatchSave"

  case class result1(
                       address_id:String
                      ,tagfuzzy_combine:String
                   )
  case class result2(
                       receiver_city_number:String
                      ,receiver_province_name:String
                      ,receiver_city_name:String
                      ,receiver_area_name:String
                      ,receiver_company:String
                      ,receiver_name:String
                      ,address:String
                      ,fulladdress_r:String
                      ,groupid_wsb:String
                      ,keyindex_wsb:String
                      ,splitresult_wsb:String
                      ,word_after_keyindex_wsb:String
                      ,address_id_list:String
                      ,maxlevel_zaiku_list:String
                      ,adcode_wsb:String
                      ,termresult_wsb:String
                      ,termresult_wsb_reform:String
                      ,get_tag_fuzzy_list:String
                      ,get_tag_fuzzy_list1:String
                   )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    startSta(startDay: String)
    logger.error("结束所有运行")

  }

  def startSta(incDay: String) = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error("取数据源")
    val finRdd = getBaseDataDf(spark, incDay)
//    logger.error("调平台接口")
//    val reRdd = getRunDate(spark,finRdd)
//    logger.error(s"落表${tableName2}")
//    saveTable(spark, reRdd, incDay)
    logger.error("结束所有运行")

  }






  //入库
  def saveTable(spark: SparkSession, detailRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = detailRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.repartition(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(detailName2)

    //最终入表
//    logger.error("入统计表" )
//    val reDf = detailRdd.map(o => {
//      val receiver_city_number = JSONUtil.getJsonVal(o, "receiver_city_number","")
//      val receiver_province_name = JSONUtil.getJsonVal(o, "receiver_province_name","")
//      val receiver_city_name = JSONUtil.getJsonVal(o, "receiver_city_name","")
//      val receiver_area_name = JSONUtil.getJsonVal(o, "receiver_area_name","")
//      val receiver_company = JSONUtil.getJsonVal(o, "receiver_company","")
//      val receiver_name = JSONUtil.getJsonVal(o, "receiver_name","")
//      val address = JSONUtil.getJsonVal(o, "address","")
//      val fulladdress_r = JSONUtil.getJsonVal(o, "fulladdress_r","")
//      val groupid_wsb = JSONUtil.getJsonVal(o, "groupid_wsb","")
//      val keyindex_wsb = JSONUtil.getJsonVal(o, "keyindex_wsb","")
//      val splitresult_wsb = JSONUtil.getJsonVal(o, "splitresult_wsb","")
//      val word_after_keyindex_wsb = JSONUtil.getJsonVal(o, "word_after_keyindex_wsb","")
//      val address_id_list = JSONUtil.getJsonVal(o, "address_id_list","")
//      val maxlevel_zaiku_list = JSONUtil.getJsonVal(o, "maxlevel_zaiku_list","")
//      val adcode_wsb = JSONUtil.getJsonVal(o, "adcode_wsb","")
//      val termresult_wsb = JSONUtil.getJsonVal(o, "termresult_wsb","")
//      val termresult_wsb_reform = JSONUtil.getJsonVal(o, "termresult_wsb_reform","")
//      val get_tag_fuzzy_list = JSONUtil.getJsonVal(o, "get_tag_fuzzy_list","")
//      val get_tag_fuzzy_list1 = JSONUtil.getJsonVal(o, "get_tag_fuzzy_list1","")
//      result2(
//           receiver_city_number
//          ,receiver_province_name
//          ,receiver_city_name
//          ,receiver_area_name
//          ,receiver_company
//          ,receiver_name
//          ,address
//          ,fulladdress_r
//          ,groupid_wsb
//          ,keyindex_wsb
//          ,splitresult_wsb
//          ,word_after_keyindex_wsb
//          ,address_id_list
//          ,maxlevel_zaiku_list
//          ,adcode_wsb
//          ,termresult_wsb
//          ,termresult_wsb_reform
//          ,get_tag_fuzzy_list
//          ,get_tag_fuzzy_list1
//      )
//    }).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    //汇总表入库
//    logger.error("入统计表数量：" + reDf.count())
//    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName2)
  }




  def getBaseDataDf(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    logger.error("取t-3的数据")
    //任务跑数时间 incDay T-2
    val day3 = DateUtil.getDateStr(incDay, -1, "")
    //基本数据
    val baseSql =
      s"""
         |select
         |addressid,
         |tagfuzzy
         |from (
         |select
         |addressid,
         |tagfuzzy
         |from
         |dm_gis.dm_specialstorage_baseaddress_lengyun_addtagfuzzy_di
         |where par_day = '${day3}' and addressid <>'' and tagfuzzy <> ''
         |group by
         |addressid,
         |tagfuzzy
         |union all
         |select
         |addressid
         |,tagfuzzy
         |from (
         |select
         |address_id as addressid,
         |addr_key_tag_new as tagfuzzy
         |,row_number()over(partition by waybill_no order by address desc) rn
         |from
         |dm_gis.cold_transport_fuzzy_configuration_process_2
         |where inc_day = '${incDay}' and address_id <>'' and addr_key_tag_new <> ''
         |)a
         |where rn =1
         |)a
         |group by
         |addressid,
         |tagfuzzy
      """.stripMargin
    logger.error(baseSql)
    val soureRdd = SparkUtils.getRowToJson(spark, baseSql)
    logger.error("获取到的数据量：" + soureRdd.count())
    soureRdd.take(2).foreach(o => logger.error(o.toJSONString))

    logger.error("按地址汇总数据")
    val rdd = soureRdd.map(o=>{
      o.put("tagfuzzy_combine",JSONUtil.getJsonVal(o,"tagfuzzy",""))
      (JSONUtil.getJsonVal(o,"addressid",""),o)
    }).reduceByKey((o1,o2)=>{
      var tagfuzzy_combine = JSONUtil.getJsonVal(o1,"tagfuzzy_combine","")
      val tagfuzzy2 = JSONUtil.getJsonVal(o1,"tagfuzzy_combine","")
      if(!tagfuzzy_combine.contains(tagfuzzy2)) tagfuzzy_combine = tagfuzzy_combine+s"#${tagfuzzy2}"
      o1.put("tagfuzzy_combine",tagfuzzy_combine)
      o1
    }).map(_._2).repartition(10).persist(StorageLevel.MEMORY_ONLY)
    logger.error("汇总完的数据量："+rdd.count())
    soureRdd.unpersist()

    rdd.take(2).foreach(o=>logger.error(o))

    logger.error("落明细表")
    //明细表入库
    val rowDf = rdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(detailName1)

    //最终入表
    logger.error("入统计表")
    val reDf = rdd.map(o => {
      val address_id = JSONUtil.getJsonVal(o, "addressid", "")
      val tagfuzzy_combine = JSONUtil.getJsonVal(o, "tagfuzzy_combine", "")
      result1(
           address_id
          ,tagfuzzy_combine
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    //汇总表入库
    logger.error("入统计表数量：" + reDf.count())
    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName1)
    rdd
  }



  def getRunDate(spark: SparkSession,dataRdd:RDD[JSONObject])={
    val reNum = dataRdd.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, ptUrl, "991BC6CF4E1EEF3EBBC30AB6D07125D8", reNum, 20)
    val xzRdd = dataRdd.repartition(20).mapPartitions(iter => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        val addressid = JSONUtil.getJsonVal(o, "addressid", "")
        val tagfuzzy_combine = JSONUtil.getJsonVal(o, "tagfuzzy_combine", "")

        if (addressid.nonEmpty && tagfuzzy_combine.nonEmpty ) {
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, 0, cmsLimit, logger)
          val param = new JSONObject()
          param.put("addressId",addressid)
          param.put("tagFuzzy",tagfuzzy_combine)
          param.put("updateUser","01425216")
         val req =  post(ptUrl,param,"utf-8","991BC6CF4E1EEF3EBBC30AB6D07125D8")
          o.put("req", req)
        }
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完平台的数据量：" + xzRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    dataRdd.unpersist()
    xzRdd
  }

  def post(url: String, json: JSON, encoding: String, token: String = ""): String = {
    var body = ""
    try {
      //创建httpclient对象
      val client = HttpClients.createDefault
      try { //创建post方式请求对象
        val httpPost = new HttpPost(url)
        //装填参数
        val s = new StringEntity(json.toString, "utf-8")
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"))
        //设置参数到请求对象中
        httpPost.setEntity(s)
        //System.out.println("请求地址："+url);
        //设置header信息
        //指定报文头【Content-type】、【User-Agent】
        httpPost.setHeader("Content-type", "application/json")
        httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)")
        if (token.nonEmpty) httpPost.setHeader("ak", token)
        //执行请求操作，并拿到结果（同步阻塞）
        val response = client.execute(httpPost)
        //获取结果实体
        val entity = response.getEntity
        if (entity != null) { //按指定编码转换结果实体为String类型
          body = EntityUtils.toString(entity, encoding)
        }
        EntityUtils.consume(entity)
        //释放链接
        response.close()
      } finally if (client != null) client.close()
    }
    body
  }


}
