package com.sf.gis.scala.rss.constant.ads.app

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.SparkUtils
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil, JSONUtil, Util}
import org.apache.log4j.Logger
import org.apache.spark.RangePartitioner
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.util
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
  * 【特殊入仓】冷运同大组用未识别地址配置模糊tag_V1.0
  * 需求：谭雨祯 01425216
  * 任务id：931323
  * 开发：01412406
  */

object ColdTransportSamegroupUnrecognizedFuzzymatch {
  @transient lazy val logger: Logger = Logger.getLogger(ColdTransportSamegroupUnrecognizedFuzzymatch.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  val tableName = "dm_gis.address_unknown_chainwords_detail"

  val detailName1 = "dm_gis.dm_specialstorage_lengyun_wsbwaybill_inprocess1_detail_di"
  val detailName2 = "dm_gis.dm_specialstorage_lengyun_wsbwaybill_inprocess2_detail_di"
  val detailName3 = "dm_gis.dm_specialstorage_baseaddress_lengyun_addtagfuzzy_detail_di"
  val tableName1 = "dm_gis.dm_specialstorage_lengyun_wsbwaybill_inprocess1_di"
  val tableName2 = "dm_gis.dm_specialstorage_lengyun_wsbwaybill_inprocess2_di"
  val tableName3 = "dm_gis.dm_specialstorage_baseaddress_lengyun_addtagfuzzy_di"



  val reTableName = "dm_gis.address_unknown_chainwords"
  val lyUrl = "http://gis-apis.int.sfcloud.local:1080/diff/api/ce?address=%s&citycode=%s&ak=9c1d529c40f54877a9a6372e686fee47&show=1"
  val normUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=e6a874c441cc41eda1b443d420f6632d&opt=%s"
  val xzUrl ="http://gis-int.int.sfdc.com.cn:1080/adcode/api/querybyname?opt=GetADCodeByNameEx&Province=%s&City=%s&ak=3eb300d2e06947f7945cd02530a32fd2"
//  val rcUrl ="http://10.206.28.54:8080/?encode=1&output=json&normtype=0&addressmatch=2&adcode=%s&address=%s"
  val rcUrl ="http://adds-c-green.int.sfcloud.local:1080/?output=json&normtype=0&addressmatch=2&adcode=%s&address=%s&encode=1"
  val cmsLimit = 100

  val account = "01412406"
  val taskId = "931323"
  val taskName = "冷运同大组用未识别地址配置模糊tag_ColdTransportSamegroupUnrecognizedFuzzymatch"
  val taskDesc = "冷运同大组用未识别地址配置模糊tag_ColdTransportSamegroupUnrecognizedFuzzymatch"

  case class result1(
                       address_id:String
                      ,citycode:String
                      ,address_zaiku:String
                      ,tag_fuzzy_org:String
                      ,groupid_zaiku:String
                      ,keyindex_zaiku:String
                      ,splitresult_zaiku:String
                      ,maxlevel_zaiku:String
                   )
  case class result2(
                       receiver_city_number:String
                      ,receiver_province_name:String
                      ,receiver_city_name:String
                      ,receiver_area_name:String
                      ,receiver_company:String
                      ,receiver_name:String
                      ,address:String
                      ,fulladdress_r:String
                      ,groupid_wsb:String
                      ,keyindex_wsb:String
                      ,splitresult_wsb:String
                      ,word_after_keyindex_wsb:String
                      ,address_id_list:String
                      ,maxlevel_zaiku_list:String
                      ,adcode_wsb:String
                      ,termresult_wsb:String
                      ,termresult_wsb_reform:String
                      ,get_tag_fuzzy_list:String
                      ,get_tag_fuzzy_list1:String
                   )

  case class result3(
                        addressid: String
                      , citycode: String
                      , address_zaiku: String
                      , tag_fuzzy_org: String
                      , new_tag_fuzzy: String
                      , tagfuzzy: String
                    )
  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    startSta(startDay: String)
    logger.error("结束所有运行")

  }

  def startSta(incDay: String) = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error("获取最新的特殊入仓基础地址")
    val (joinRdd,finRdd) = getBaseDataDf(spark, incDay)
    logger.error("获取数据源")
    //取数据源
    val  (dataRdd,interfaceUnionRdd) = getDataDf(spark, incDay)
    logger.error("关联基础地址")
    val reRdd = getJoinDate(spark,dataRdd,joinRdd)
    logger.error(s"落中间表${tableName2}")
    saveTable(spark, reRdd, incDay)
    logger.error("关联模糊tag")
   val alljoinRdd =  joinTag(finRdd,reRdd)
    saveJoinTable(spark,alljoinRdd,interfaceUnionRdd,incDay)
    logger.error("结束所有运行")

  }


  def saveJoinTable(spark: SparkSession, detailRdd: RDD[JSONObject], interfaceUnionRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = detailRdd.union(interfaceUnionRdd).map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.repartition(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(detailName3)

    //最终入表
    logger.error("入统计表")
    val reDf = detailRdd.filter(o=>JSONUtil.getJsonVal(o,"new_tag_fuzzy","").nonEmpty).map(o => {
      val address_id = JSONUtil.getJsonVal(o, "address_id", "")
      val citycode = JSONUtil.getJsonVal(o, "citycode", "")
      val address_zaiku = JSONUtil.getJsonVal(o, "address_zaiku", "")
      val tag_fuzzy_org = JSONUtil.getJsonVal(o, "tag_fuzzy_org", "")
      val new_tag_fuzzy = JSONUtil.getJsonVal(o, "new_tag_fuzzy", "")
      val all_tag_fuzzy = JSONUtil.getJsonVal(o, "all_tag_fuzzy", "")
      result3(
          address_id
        , citycode
        , address_zaiku
        , tag_fuzzy_org
        , new_tag_fuzzy
        , all_tag_fuzzy
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    //汇总表入库
    logger.error("入统计表数量：" + reDf.count())
    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName3)
  }


  def joinTag(finRdd: RDD[JSONObject], joinRdd: RDD[JSONObject]) = {

    val joinFinRdd = finRdd.map(o => (JSONUtil.getJsonVal(o, "address_id", ""), o))

    val preJoinRdd = joinRdd.flatMap(o => {
      val list = new ListBuffer[(String, JSONObject)]
      val get_tag_fuzzy_list1 = JSONUtil.getJsonVal(o, "get_tag_fuzzy_list1", "").split(",")
      //        id+"$"+get_tag.mkString("|")
      for (item <- get_tag_fuzzy_list1) yield {
        val k = try {
          item.split("\\$")(0)
        } catch {
          case exception: Exception => ""
        }
        val v = try {
          item.split("\\$")(1)
        } catch {
          case exception: Exception => ""
        }
        (k, v)
      }
    }).filter(o => o._1.nonEmpty && o._2.nonEmpty)

    val finJoinRdd = preJoinRdd.partitionBy(new RangePartitioner(200, preJoinRdd)).reduceByKey((o1, o2) => {
      var v = o1
      if (!v.contains(o2)) v = v + "#" + o2
      v
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("处理完的数据量：" + finJoinRdd.count())

    val allRdd = joinFinRdd.leftOuterJoin(finJoinRdd).map(o => {
      val left = o._2._1
      val right = o._2._2
      val tag_fuzzy_org = JSONUtil.getJsonVal(left, "tag_fuzzy_org", "")
      if (right.nonEmpty) {
        left.put("new_tag_fuzzy", right.get)
        left.put("all_tag_fuzzy", right.get + "#" + tag_fuzzy_org)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联后的数据量：" + allRdd.count())
    allRdd
  }


  //入库
  def saveTable(spark: SparkSession, detailRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = detailRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.repartition(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(detailName2)

    //最终入表
    logger.error("入统计表" )
    val reDf = detailRdd.map(o => {
      val receiver_city_number = JSONUtil.getJsonVal(o, "receiver_city_number","")
      val receiver_province_name = JSONUtil.getJsonVal(o, "receiver_province_name","")
      val receiver_city_name = JSONUtil.getJsonVal(o, "receiver_city_name","")
      val receiver_area_name = JSONUtil.getJsonVal(o, "receiver_area_name","")
      val receiver_company = JSONUtil.getJsonVal(o, "receiver_company","")
      val receiver_name = JSONUtil.getJsonVal(o, "receiver_name","")
      val address = JSONUtil.getJsonVal(o, "address","")
      val fulladdress_r = JSONUtil.getJsonVal(o, "fulladdress_r","")
      val groupid_wsb = JSONUtil.getJsonVal(o, "groupid_wsb","")
      val keyindex_wsb = JSONUtil.getJsonVal(o, "keyindex_wsb","")
      val splitresult_wsb = JSONUtil.getJsonVal(o, "splitresult_wsb","")
      val word_after_keyindex_wsb = JSONUtil.getJsonVal(o, "word_after_keyindex_wsb","")
      val address_id_list = JSONUtil.getJsonVal(o, "address_id_list","")
      val maxlevel_zaiku_list = JSONUtil.getJsonVal(o, "maxlevel_zaiku_list","")
      val adcode_wsb = JSONUtil.getJsonVal(o, "adcode_wsb","")
      val termresult_wsb = JSONUtil.getJsonVal(o, "termresult_wsb","")
      val termresult_wsb_reform = JSONUtil.getJsonVal(o, "termresult_wsb_reform","")
      val get_tag_fuzzy_list = JSONUtil.getJsonVal(o, "get_tag_fuzzy_list","")
      val get_tag_fuzzy_list1 = JSONUtil.getJsonVal(o, "get_tag_fuzzy_list1","")
      result2(
           receiver_city_number
          ,receiver_province_name
          ,receiver_city_name
          ,receiver_area_name
          ,receiver_company
          ,receiver_name
          ,address
          ,fulladdress_r
          ,groupid_wsb
          ,keyindex_wsb
          ,splitresult_wsb
          ,word_after_keyindex_wsb
          ,address_id_list
          ,maxlevel_zaiku_list
          ,adcode_wsb
          ,termresult_wsb
          ,termresult_wsb_reform
          ,get_tag_fuzzy_list
          ,get_tag_fuzzy_list1
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    //汇总表入库
    logger.error("入统计表数量：" + reDf.count())
    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName2)
  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {
    logger.error("每两周在周一(T)获取前30天的特殊入仓运单(取数周期T-31到T-2)")
    //任务跑数时间 incDay T-2
    val day31 = DateUtil.getDateStr(incDay,-29,"")
    //基本数据
    val baseSql =
      s"""
         |select *
         |,concat(nvl(fulladdress,''),nvl(receiver_company,''),nvl(receiver_name,'')) as fulladdress_r
         |from (
         |select *
         |,concat(nvl(receiver_province_name,''),nvl(receiver_city_name,''),nvl(receiver_area_name,''),nvl(address,'')) as fulladdress
         |from (
         |select
         |waybill_no
         |,receiver_city_number
         |,receiver_province_name
         |,receiver_city_name
         |,receiver_area_name
         |,receiver_company
         |,receiver_name
         |,regexp_replace(receiver_detail_address, '[\\r\\n\\t]+', '') as address
         |, row_number()over(partition by waybill_no order by waybill_no desc) rn
         |from dm_gis.t_order_decrypt_di
         |where is_special_warehousing = 'Y'
         |and inc_day between '${day31}' and '${incDay}'
         |)a
         |where rn =1
         |)a
      """.stripMargin

    logger.error(baseSql)

   val soureRdd =  SparkUtils.getRowToJson(spark,baseSql)
    val totalDf = spark.sql(baseSql)
    logger.error("获取到的数据量：" + soureRdd.count())
    soureRdd.take(2).foreach(o=>logger.error(o.toJSONString))


    logger.error("调冷运接口")

    val reNum = soureRdd.count().toInt
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, lyUrl, "9c1d529c40f54877a9a6372e686fee47", reNum, 60)

    val interfaceRddTmp = soureRdd.repartition(20).mapPartitions(iter => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)

      for (o <- iter) yield {
        val address = JSONUtil.getJsonVal(o, "fulladdress_r", "").replaceAll("#","")
        val citycode = JSONUtil.getJsonVal(o, "receiver_city_number", "")

        //matchtype,warehousetype,warehousename,warehouseid,matchAddressUUID   筛选status=1的数据

        if(address.nonEmpty && citycode.nonEmpty){
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, 0, cmsLimit, logger)
          val lyUrls = String.format(lyUrl, URLEncoder.encode(address, "utf-8"), citycode)
          val reqObjLy = HttpClientUtil.getJsonByGet(lyUrls)
          o.put("lyReqObj", reqObjLy.toJSONString)
          if (reqObjLy != null) {
            val status = JSONUtil.getJsonVal(reqObjLy, "status", "")
            if(status.equals("1")){
              val matchtype = JSONUtil.getJsonVal(reqObjLy, "result.cdata.matchtype", "")
              val warehousetype = JSONUtil.getJsonVal(reqObjLy, "result.cdata.warehousetype", "")
              val warehousename = JSONUtil.getJsonVal(reqObjLy, "result.cdata.warehousename", "")
              val warehouseid = JSONUtil.getJsonVal(reqObjLy, "result.cdata.warehouseid", "")
              val matchAddressUUID = JSONUtil.getJsonVal(reqObjLy, "result.cdata.matchAddressUUID", "")
              o.put("matchtype", matchtype)
              o.put("warehouseid", warehouseid)
              o.put("warehousename", warehousename)
              o.put("matchAddressUUID", matchAddressUUID)
              o.put("warehousetype", warehousetype)

            }
            o.put("status", status)
          }
        }
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完冷运接口的数据量：" + interfaceRddTmp.count())
    interfaceRddTmp.take(2).foreach(o=>logger.error(o))
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)

   val interfaceRdd =  interfaceRddTmp.filter(o=> JSONUtil.getJsonVal(o,"status","").equals("1"))
   val interfaceUnionRdd =  interfaceRddTmp.filter(o=> !JSONUtil.getJsonVal(o,"status","").equals("1"))

    logger.error("跑容灾的数据量："+interfaceRdd.count())
    logger.error("不需要判断的数据量:"+interfaceUnionRdd.count())


    soureRdd.unpersist()
    logger.error("容灾派件norm识别获取groupid")
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, normUrl, "e6a874c441cc41eda1b443d420f6632d", reNum, 60)

    val normRdd = interfaceRdd.repartition(20).mapPartitions(iter => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        val address = JSONUtil.getJsonVal(o, "fulladdress_r", "").replaceAll("#", "")
        val citycode = JSONUtil.getJsonVal(o, "receiver_city_number", "")

        //groupid_wsb =  ['result']['tcs'][0]['groupid']
        //keyindex_wsb = ['result']['other']['normresp']['result']['geocoder'][0]['key']
        //splitresult_wsb = ['result']['other']['normresp']['result']['splitResult'].split(';')[0]

        if (address.nonEmpty && citycode.nonEmpty) {
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, 0, cmsLimit, logger)
          val lyUrls = String.format(normUrl, URLEncoder.encode(address, "utf-8"), citycode,"norm")
          val normReq = HttpClientUtil.getJsonByGet(lyUrls)
          if (normReq != null) {
              val groupid_wsb = try{JSONUtil.getJsonArrayMulti(normReq, "result.tcs", new JSONArray()).getJSONObject(0).getString("groupid")}catch {case exception: Exception => ""}
              val keyindex_wsb = try{JSONUtil.getJsonArrayMulti(normReq, "result.other.normresp.result.geocoder", new JSONArray()).getJSONObject(0).getString("key")}catch {case exception: Exception => ""}
              val splitresult_wsb = try{JSONUtil.getJsonVal(normReq, "result.other.normresp.result.splitResult","").split(";")(0) }catch {case exception: Exception => ""}
              o.put("normReq", normReq.toJSONString)
              o.put("groupid_wsb", groupid_wsb)
              o.put("keyindex_wsb", keyindex_wsb)
              o.put("splitresult_wsb", splitresult_wsb)
            //keyindex_wsb中最大的数字为max_keyindex_wsb
            if(keyindex_wsb.nonEmpty){
              val ss = keyindex_wsb.split("\\|")
              var max_keyindex_wsb = 0
              //剔除【splitresult_wsb在max_keyindex_wsb位置后有非613的13级】的wsbdata数据
              var tag13 = true
              //剔除【word_after_keyindex_wsb含有数字或字母】的wsbdata数据
              var tagwsb = true
              ss.foreach(mx=>{
                val mxt = try{mx.toInt}catch {case exception: Exception=>0}
                max_keyindex_wsb = if(mxt>max_keyindex_wsb)  mxt else max_keyindex_wsb
              })
              o.put("max_keyindex_wsb",max_keyindex_wsb+"")
              //拼接splitresult_wsb在max_keyindex_wsb位置后的所有文本为word_after_keyindex_wsb
              val keyList = splitresult_wsb.split(",")
             if(splitresult_wsb.nonEmpty && keyList.size >0 &&  max_keyindex_wsb > 0  && max_keyindex_wsb < keyList.size){
               val newKeyList: Array[String] = util.Arrays.copyOfRange(keyList, max_keyindex_wsb+1, keyList.size)
               var word_after_keyindex_wsb = ""
               newKeyList.map(kv =>{
                val k =  try{kv.split("\\^")(0)}catch {case exception: Exception=>""}
                val v =  try{kv.split("\\^")(1)}catch {case exception: Exception=>""}
                word_after_keyindex_wsb = word_after_keyindex_wsb+k
                 if(v.nonEmpty && !v.equals("613") && v.substring(1).equals("13")) tag13 = false
               })
               o.put("newKeyList",newKeyList.mkString(","))
               o.put("word_after_keyindex_wsb",word_after_keyindex_wsb)
               o.put("tag13",tag13+"")
               if(word_after_keyindex_wsb.replaceAll("_","").replaceAll("\\d|[a-zA-Z]","_").contains("_")) tagwsb = false
               o.put("tagwsb",tagwsb+"")

             }
            }
          }
        }
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完容灾派件norm接口的数据量：" + normRdd.count())
    normRdd.take(2).foreach(o => logger.error(o))
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId2)
    interfaceRdd.unpersist()
    (normRdd,interfaceUnionRdd)
  }


  def getBaseDataDf(spark: SparkSession, incDay: String) = {
    import spark.implicits._
    logger.error("取t-1的数据")
    //任务跑数时间 incDay T-2
    val day = DateUtil.getDateStr(incDay, 1, "")
    //基本数据
    val baseSql =
      s"""
         |select
         |address_id,
         |citycode,
         |norm_address as address_zaiku,
         |tag_fuzzy as tag_fuzzy_org
         |from
         |dm_gis.specialstorage_baseaddress_lengyun
         |where inc_day = '${day}' and del_flag = '0'
      """.stripMargin
    logger.error(baseSql)
    val soureRdd = SparkUtils.getRowToJson(spark, baseSql)
    logger.error("获取到的数据量：" + soureRdd.count())
    soureRdd.take(2).foreach(o => logger.error(o.toJSONString))

    val reNum = soureRdd.count().toInt
    soureRdd.unpersist()
    logger.error("容灾派件norm识别获取groupid")
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, normUrl, "e6a874c441cc41eda1b443d420f6632d", reNum, 60)

    val normRdd = soureRdd.repartition(20).mapPartitions(iter => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        val address = JSONUtil.getJsonVal(o, "address_zaiku", "")
        val citycode = JSONUtil.getJsonVal(o, "citycode", "")



        if (address.nonEmpty && citycode.nonEmpty) {
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, 0, cmsLimit, logger)
          val lyUrls = String.format(normUrl, URLEncoder.encode(address, "utf-8"), citycode,"normdetail")
          val normReq = HttpClientUtil.getJsonByGet(lyUrls)
          if (normReq != null) {
            val  groupid_zaiku = try {JSONUtil.getJsonArrayMulti(normReq, "result.tcs", new JSONArray()).getJSONObject(0).getString("groupid")} catch {case exception: Exception => ""}
            val keyindex_zaiku  = try {JSONUtil.getJsonArrayMulti(normReq, "result.other.normresp.result.geocoder", new JSONArray()).getJSONObject(0).getString("key")} catch {case exception: Exception => ""}
            val splitresult_zaiku = try {JSONUtil.getJsonVal(normReq, "result.other.normresp.result.splitResult", "").split(";")(0)} catch {case exception: Exception => ""}
            o.put("normReq_zaiku", normReq.toJSONString)
            o.put("groupid_zaiku", groupid_zaiku)
            o.put("keyindex_zaiku", keyindex_zaiku)
            o.put("splitresult_zaiku", splitresult_zaiku)
            //keyindex_wsb中最大的数字为max_keyindex_wsb
            if (keyindex_zaiku.nonEmpty) {
              val ss = keyindex_zaiku.split("\\|")
              var max_keyindex_zaiku = 0
              //剔除【splitresult_zaiku在max_keyindex_zaiku位置后有非613的13级】的baseddata数据
              var tag13 = true

              ss.foreach(mx => {
                val mxt = try {
                  mx.toInt
                } catch {
                  case exception: Exception => 0
                }
                max_keyindex_zaiku = if (mxt > max_keyindex_zaiku) mxt else max_keyindex_zaiku
              })
              o.put("max_keyindex_zaiku", max_keyindex_zaiku + "")

              //拼接splitresult_wsb在max_keyindex_wsb位置后的所有文本为word_after_keyindex_wsb
              val keyList = splitresult_zaiku.split(",")
              if (splitresult_zaiku.nonEmpty && keyList.size > 0 && max_keyindex_zaiku > 0 && max_keyindex_zaiku < keyList.size) {
                val newKeyList: Array[String] = util.Arrays.copyOfRange(keyList, max_keyindex_zaiku + 1, keyList.size)

                newKeyList.foreach(kv => {
                  val v = try {kv.split("\\^")(1)} catch {case exception: Exception => ""}
                  if (v.nonEmpty && !v.equals("613") && v.substring(1).equals("13")) tag13 = false
                })
                o.put("newKeyList", newKeyList.mkString(","))
                o.put("tag13", tag13 + "")
              }
            }
          }
        }
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完容灾派件norm接口的数据量：" + normRdd.count())
    normRdd.take(2).foreach(o => logger.error(o))
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId2)


   val unoinRdd =  normRdd.filter(o=>JSONUtil.getJsonVal(o,"tag13","").equals("false")).persist(StorageLevel.MEMORY_AND_DISK)
   val nextRdd =  normRdd.filter(o=>JSONUtil.getJsonVal(o,"tag13","").equals("true")).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("剔除掉的数据：" + unoinRdd.count())
    logger.error("判断最大的数据：" + nextRdd.count())

    normRdd.unpersist()


    val finRdd   = nextRdd.map(o=>{
    val splist =   JSONUtil.getJsonVal(o,"splitresult_zaiku","").split(",")
      var maxlevel_zaiku = 0
      splist.foreach(x=>{
      val v = try{x.split("\\^")(1).substring(1).toInt}catch {case exception: Exception=>0}
        if(v>maxlevel_zaiku && v != 18)maxlevel_zaiku = v
      })

      o.put("maxlevel_zaiku",maxlevel_zaiku+"")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)


    logger.error("处理关联数据")
   val joinRdd =  finRdd.map(o=>{
      val js = new JSONObject()
      js.put("groupid_zaiku",JSONUtil.getJsonVal(o,"groupid_zaiku",""))
      js.put("address_id",JSONUtil.getJsonVal(o,"address_id",""))
      js.put("maxlevel_zaiku",JSONUtil.getJsonVal(o,"maxlevel_zaiku",""))
      (JSONUtil.getJsonVal(o,"groupid_zaiku",""),js)
    }).filter(_._1.nonEmpty).groupByKey().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("处理关联的数据量：" + joinRdd.count())
    joinRdd.take(2).foreach(o => logger.error(o))


    logger.error("落明细表")
    val allRdd = finRdd.union(unoinRdd).persist(StorageLevel.MEMORY_AND_DISK)
    //明细表入库
    val rowDf = allRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.repartition(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(detailName1)

    //最终入表
    logger.error("入统计表")
    val reDf = finRdd.map(o => {
      val address_id = JSONUtil.getJsonVal(o, "address_id", "")
      val citycode = JSONUtil.getJsonVal(o, "citycode", "")
      val address_zaiku = JSONUtil.getJsonVal(o, "address_zaiku", "")
      val tag_fuzzy_org = JSONUtil.getJsonVal(o, "tag_fuzzy_org", "")
      val groupid_zaiku = JSONUtil.getJsonVal(o, "groupid_zaiku", "")
      val keyindex_zaiku = JSONUtil.getJsonVal(o, "keyindex_zaiku", "")
      val splitresult_zaiku = JSONUtil.getJsonVal(o, "splitresult_zaiku", "")
      val maxlevel_zaiku = JSONUtil.getJsonVal(o, "maxlevel_zaiku", "")

      result1(
           address_id
          ,citycode
          ,address_zaiku
          ,tag_fuzzy_org
          ,groupid_zaiku
          ,keyindex_zaiku
          ,splitresult_zaiku
          ,maxlevel_zaiku

      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    //汇总表入库
    logger.error("入统计表数量：" + reDf.count())
    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName1)

    finRdd.unpersist()
    allRdd.unpersist()
    unoinRdd.unpersist()

    (joinRdd,finRdd)
  }






  def getJoinDate(spark: SparkSession,dataRdd:RDD[JSONObject],joinRdd:RDD[(String,Iterable[JSONObject])])={


    val nextRdd = dataRdd.filter(o=>JSONUtil.getJsonVal(o,"tag13","").equals("true") && JSONUtil.getJsonVal(o,"tagwsb","").equals("true")).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd = dataRdd.filter(o=> !(JSONUtil.getJsonVal(o,"tag13","").equals("true") && JSONUtil.getJsonVal(o,"tagwsb","").equals("true"))).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联的数据量："+nextRdd.count())
    logger.error("不用关联的数据量："+unionRdd.count())
    dataRdd.unpersist()

    val  wsbRdd= nextRdd.map(o=>(JSONUtil.getJsonVal(o,"groupid_wsb",""),o)).leftOuterJoin(joinRdd).map(o=>{
      val right = o._2._2
      val left = o._2._1
      if(right.nonEmpty){
        val list = right.get.map(s =>(JSONUtil.getJsonVal(s,"address_id",""),JSONUtil.getJsonVal(s,"maxlevel_zaiku",""))).filter(_._1.nonEmpty)
        left.put("zaiku_info",list.map(o=>o._1+"_"+o._2).mkString(","))
        left.put("address_id_list",list.map(_._1).mkString(","))
        left.put("maxlevel_zaiku_list",list.map(_._2).mkString(","))
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)
   logger.error("关联完的数据量："+wsbRdd.count())


    val nextRdd2 = wsbRdd.filter(o=>JSONUtil.getJsonVal(o,"address_id_list","").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd2 = wsbRdd.filter(o=>JSONUtil.getJsonVal(o,"address_id_list","").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("address_id_list是空的数据量："+unionRdd2.count())
    logger.error("address_id_list非空的数据量："+nextRdd2.count())
    logger.error("处理省份")
    val reNum = nextRdd2.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, xzUrl, "3eb300d2e06947f7945cd02530a32fd2", reNum, 20)
    val xzRdd = nextRdd2.repartition(20).mapPartitions(iter => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        val receiver_province_name = JSONUtil.getJsonVal(o, "receiver_province_name", "")
        val receiver_city_name = JSONUtil.getJsonVal(o, "receiver_city_name", "")
        val receiver_province_name1 = if (Array("北京", "上海", "天津", "重庆").contains(receiver_province_name)) receiver_province_name + "市" else receiver_province_name
        o.put("receiver_province_name1", receiver_province_name1)

        //重庆市特殊处理，接口跑不出数
        if (receiver_province_name1.nonEmpty && receiver_city_name.nonEmpty && !receiver_province_name1.equals("重庆市")) {
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, 0, cmsLimit, logger)
          val url = String.format(xzUrl, URLEncoder.encode(receiver_province_name1, "utf-8"), URLEncoder.encode(receiver_city_name, "utf-8"))
          val xzReq = HttpClientUtil.getJsonByGet(url)
          if (xzReq != null) {
            val adcode_wsb = try {JSONUtil.getJsonArrayMulti(xzReq, "result.data", new JSONArray()).getJSONObject(0).getString("cityLevCode")} catch {case exception: Exception => ""}
            o.put("xzReq", xzReq.toJSONString)
            o.put("adcode_wsb", adcode_wsb)
          }
        }else if(receiver_province_name1.equals("重庆市"))  o.put("adcode_wsb", "500100")
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完省市区查询行政区划接口的数据量：" + xzRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, rcUrl, "", reNum, 20)
    val rcRdd = xzRdd.repartition(20).mapPartitions(iter => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        val adcode_wsb = JSONUtil.getJsonVal(o, "adcode_wsb", "")
        val fulladdress_r = JSONUtil.getJsonVal(o, "fulladdress_r", "").replaceAll("\\#","-")
        val zaiku_info = JSONUtil.getJsonVal(o, "zaiku_info", "")
        var termresult_wsb_reform =""
        if (adcode_wsb.nonEmpty && fulladdress_r.nonEmpty) {
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, 0, cmsLimit, logger)
          val url = String.format(rcUrl, adcode_wsb,URLEncoder.encode(fulladdress_r, "utf-8"))
          val rcReq = HttpClientUtil.getJsonByGet(url)
          if (rcReq != null) {
            val termresult_wsb = JSONUtil.getJsonVal(rcReq, "termResult", "")


            o.put("rcReq", rcReq.toJSONString)
            o.put("termresult_wsb", termresult_wsb)

            //termresult_wsb去掉属性词(第二个^后的数字)得到termresult_wsb_reform(当13级的属性词为6时，保留词级为613)
            termresult_wsb_reform = termresult_wsb.split("\\|").map(s => {
              val k = s.substring(0, s.lastIndexOf("^"))
              val v = s.substring(s.lastIndexOf("^") + 1)
              val ss = if (v.equals("6")) {
                k.substring(0, k.lastIndexOf("^")) + "^6" + k.substring(k.lastIndexOf("^") + 1)
              } else k
              ss
            }).mkString("|")
            o.put("termresult_wsb_reform", termresult_wsb_reform)
          }

          //从termresult_wsb_reform中提取出get_tag_fuzzy：【词级数>4且小于等于maxlevel_zaiku_list中各maxlevel_zaiku】的所有文本+词级（不提取18级，613视为13级来判断词级数大小但提取时为613，get_tag_fuzzy有重复的词级时只留一个);
          //将get_tag_fuzzy和对应的address_id一同存入get_tag_fuzzy_list

          val get_tag_fuzzy_list = new ArrayBuffer[String]()
          val get_tag_fuzzy_list1 = new ArrayBuffer[String]()
          val get_tag = new ArrayBuffer[String]()
          zaiku_info.split(",").filter(_.nonEmpty).foreach(ss=>{
            val id = try{ss.split("_")(0)}catch {case exception: Exception=>""}
            val num = try{ss.split("_")(1).toInt}catch {case exception: Exception=>0}
            if(termresult_wsb_reform.nonEmpty){
              val keyList = termresult_wsb_reform.split("\\|")
              var saveTag = false
              for(i<- 0 until keyList.size){
                val s = keyList(i)
                val v = try { s.split("\\^")(1).toInt} catch { case exception: Exception => 0}
                val key = try { s.split("\\^")(0)} catch { case exception: Exception => ""}
                if (v > 4 && v != 18 && ((v == 613 && 13 <= num) || v <= num)) {
                  get_tag.append(s"${key}^${v}")
                  if (v >= 13) saveTag = true
                  //保留get_tag_fuzzy_list中至少有一个词级数>=13且的最后一个词级文本不以“物流园/产业园/工业园/园区/基地”结尾的get_tag_fuzzy和address_id集合，命名为get_tag_fuzzy_list1
                  //物流园/产业园/工业园/园区/基地
                  if(i == keyList.size -1 && key.matches(".*(物流园|产业园|工业园|园区|基地)"))saveTag = false
                }
              }

              val skey = id+"$"+get_tag.mkString("|")
              get_tag_fuzzy_list.append(skey)
//             val skey =  id+"$"+termresult_wsb_reform.split("\\|").filter(s => {
//                val v = try{s.split("\\^")(1).toInt}catch {case exception: Exception=>0}
//                var tag = false
//                if(v>4 && v != 18 && ( (v == 613 && 13 <= num) || v < num)){
//                  tag = true
//                  if(v>= 13) saveTag = true
//                }
//                tag
//              }).distinct.mkString("|")

//              get_tag_fuzzy_list.append(skey)
              if(saveTag) get_tag_fuzzy_list1.append(skey)
            }
          })

          o.put("get_tag_fuzzy_list",get_tag_fuzzy_list.mkString(","))
          o.put("get_tag_fuzzy_list1",get_tag_fuzzy_list1.mkString(","))
        }
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完入仓接口的数据量：" + rcRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId2)
   val reRdd =  unionRdd2.union(unionRdd).union(rcRdd).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("处理完的数据量："+reRdd.count())
    unionRdd2.unpersist()
    unionRdd.unpersist()
    rcRdd.unpersist()
    reRdd
  }


}
