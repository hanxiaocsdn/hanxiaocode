package com.sf.gis.scala.rss.constant.ads

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.SparkUtils
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil, JSONUtil, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder

/**
  * * 冷运特殊入仓识别报表
  * 需求：01412980 潘宜鹏
  * 任务id：663335
  * 开发：01412406
  */

object ColdTransSpecialWarehous {
  @transient lazy val logger: Logger = Logger.getLogger(ColdTransSpecialWarehous.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 2.0
  println(version)
  val saveTable = "dm_gis.cold_trans_special_warehous"
  val detailTable = "dm_gis.cold_trans_special_warehous_detail"

//  val lyUrl = "http://gis-int.int.sfdc.com.cn:1080/diff/api/ce?address=%s&citycode=%s&ak=9c1d529c40f54877a9a6372e686fee47&show=1"
  val lyUrl = "http://gis-apis.int.sfcloud.local:1080/diff/api/ce?address=%s&citycode=%s&ak=9c1d529c40f54877a9a6372e686fee47&show=1"

  val account = "01412406"
  val taskId = "663335"
  val taskName = "冷运特殊入仓识别报表"
  val taskDesc = "冷运特殊入仓识别报表"
  case class Save(
                    order_no:String
                   ,waybill_no:String
                   ,product_code:String
                   ,product_name:String
                   ,bar_sender_station_code:String
                   ,receiver_province_code:String
                   ,receiver_province_name:String
                   ,receiver_city_code:String
                   ,receiver_city_name:String
                   ,receiver_area_code:String
                   ,receiver_area_name:String
                   ,receiver_city_number:String
                   ,receiver_detail_address:String
                   ,receiver_website_code:String
                   ,deliverer_code:String
                   ,receiver_company:String
                   ,receiver_name:String
                   ,receiver_mobile:String
                   ,receiver_phone:String
                   ,is_special_warehousing:String
                   ,special_address_no:String
                   ,address:String
                   ,matchtype:String
                   ,warehouseid:String
                   ,warehousename:String
                   ,matchAddressUUID:String
                   ,id:String
                   ,inc_day:String

                 )
  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)

    logger.error("起始时间:" + startDay)
    start(startDay)
    logger.error("结束所有运行")

  }


  //  t-2 startDay:2021-08-23
  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error(s"开始计算：${startDay}")
    startSta(spark, startDay)
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error(s"获取数据源:${incDay}")
    //取数据源
    val dataDf = getDataDf(spark, incDay)
    logger.error("调接口加密")
    val reRdd = runInter(dataDf)
    logger.error("入库")
    saveTable(spark,reRdd,incDay)
    }


  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {

    val beforeDay = DateUtil.getDateStr(incDay, -30, "")

    //基本数据
    logger.error("读取aoi_building_lift表的数据")
//    val baseSql =
//      s"""
//         select *
//         |from (
//         |select
//         |order_no
//         |,waybill_no
//         |,product_code
//         |,product_name
//         |,bar_sender_station_code
//         |,receiver_province_code
//         |,receiver_province_name
//         |,receiver_city_code
//         |,receiver_city_name
//         |,receiver_area_code
//         |,receiver_area_name
//         |,receiver_city_number
//         |,receiver_detail_address
//         |,receiver_website_code
//         |,deliverer_code
//         |,receiver_company
//         |,receiver_name
//         |,receiver_mobile
//         |,receiver_phone
//         |,is_special_warehousing
//         |,special_address_no
//         |,row_number()over(partition by waybill_no order by special_address_no desc ) as rn
//         |,inc_day
//         |from ods_scs_oms2order.t_order
//         |where inc_day between '$beforeDay' and '$incDay'  and is_special_warehousing="Y"
//         |)a
//         |where rn = 1
//      """.stripMargin
    val baseSql =
      s"""
         |select
         |order_no
         |,id
         |,waybill_no
         |,product_code
         |,product_name
         |,bar_sender_station_code
         |,receiver_province_code
         |,receiver_province_name
         |,receiver_city_code
         |,receiver_city_name
         |,receiver_area_code
         |,receiver_area_name
         |,receiver_city_number
         |,receiver_detail_address
         |,receiver_website_code
         |,deliverer_code
         |,receiver_company
         |,receiver_name
         |,receiver_mobile
         |,receiver_phone
         |,is_special_warehousing
         |,special_address_no
         |,inc_day
         |--from ods_scs_oms2order.t_order
         |from dm_gis.t_order_decrypt_di
         |where inc_day between '$beforeDay' and '$incDay'  and is_special_warehousing="Y"

      """.stripMargin

    logger.error("info===>" + baseSql)
    val infoDf = SparkUtils.getRowToJson(spark,baseSql)
    logger.error("totalDf的数据量：" + infoDf.count())
    infoDf
  }

  //获取数据
  def runInter(spark: SparkSession,rdd:RDD[JSONObject]) = {
    val reNum = rdd.count()
    logger.error("调地址解密接口")
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, lyUrl, "9c1d529c40f54877a9a6372e686fee47", reNum, 20)
    val  reRdd =  rdd.repartition(6).mapPartitionsWithIndex((index,iter)=>{
       val startTime = new StratTime(System.currentTimeMillis())
       val cnt = new Cnt(0)
        for ( o <- iter ) yield {
          SparkUtils.limitAkUse( startTime,cnt,index,5000/6,logger)
          var dec_address = ""
          val detail_address = JSONUtil.getJsonVal(o,"receiver_detail_address","")
          val receiver_company = JSONUtil.getJsonVal(o,"receiver_company","")
          val receiver_name = JSONUtil.getJsonVal(o,"receiver_name","")
          val receiver_city_number = JSONUtil.getJsonVal(o,"receiver_city_number","")

          val receiver_province_name = JSONUtil.getJsonVal(o,"receiver_province_name","")
          val receiver_city_name = JSONUtil.getJsonVal(o,"receiver_city_name","")
          val receiver_area_name = JSONUtil.getJsonVal(o,"receiver_area_name","")


//          val urls = String.format(url,URLEncoder.encode(detail_address,"utf-8"))
//          val reqObj: JSONObject = HttpClientUtil.getJsonByGet(urls, 3)
//          if(reqObj != null ){
//            dec_address = JSONUtil.getJsonVal(reqObj,"data","")
//            o.put("detailReqObj",reqObj.toJSONString)
//            o.put("dec_address",dec_address)
//          }

//          receiver_province_name + receiver_city_name + receiver_area_name + dec_address
          val address = detail_address+ receiver_company + receiver_name
          o.put("address",address)
          //
          val lyUrls = String.format(lyUrl,URLEncoder.encode(address,"utf-8"),receiver_city_number)
          val reqObjLy = HttpClientUtil.getJsonByGet(lyUrls)
          if(reqObjLy != null ){
            val matchtype = JSONUtil.getJsonVal(reqObjLy,"result.cdata.matchtype","")
            val warehouseid = JSONUtil.getJsonVal(reqObjLy,"result.cdata.warehouseid","")
            val warehousename = JSONUtil.getJsonVal(reqObjLy,"result.cdata.warehousename","")
            val matchAddressUUID = JSONUtil.getJsonVal(reqObjLy,"result.cdata.matchAddressUUID","")
            o.put("lyReqObj",reqObjLy.toJSONString)
            o.put("matchtype",matchtype)
            o.put("warehouseid",warehouseid)
            o.put("warehousename",warehousename)
            o.put("matchAddressUUID",matchAddressUUID)
          }
          o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
logger.error("调完接口的数据量："+reRdd.count())
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    reRdd.take(10).foreach(o=>logger.error(o.toJSONString))
//    rdd.repartition(20).map(o=>{
//      var dec_address = ""
//      val detail_address = JSONUtil.getJsonVal(o,"receiver_detail_address","")
//      val receiver_company = JSONUtil.getJsonVal(o,"receiver_company","")
//      val receiver_name = JSONUtil.getJsonVal(o,"receiver_name","")
//      val receiver_city_number = JSONUtil.getJsonVal(o,"receiver_city_number","")
//      val urls = String.format(url,URLEncoder.encode(detail_address,"utf-8"))
//      val reqObj: JSONObject = HttpClientUtil.getJsonByGet(urls, 3)
//      if(reqObj != null ){
//      dec_address = JSONUtil.getJsonVal(reqObj,"data","")
//      o.put("detailReqObj",reqObj.toJSONString)
//      o.put("dec_address",dec_address)
//      }
//
//      val address = dec_address+receiver_company+receiver_name
//     //
//      val lyUrls = String.format(lyUrl,URLEncoder.encode(address,"utf-8"),receiver_city_number)
//      val reqObjLy = HttpClientUtil.getJsonByGet(lyUrls, 3)
//      if(reqObjLy != null ){
//        val matchtype = JSONUtil.getJsonVal(reqObjLy,"result.cdata.matchtype","")
//        val warehouseid = JSONUtil.getJsonVal(reqObjLy,"result.cdata.warehouseid","")
//        val warehousename = JSONUtil.getJsonVal(reqObjLy,"result.cdata.warehousename","")
//        val matchAddressUUID = JSONUtil.getJsonVal(reqObjLy,"result.cdata.matchAddressUUID","")
//        o.put("lyReqObj",reqObjLy.toJSONString)
//        o.put("matchtype",matchtype)
//        o.put("warehouseid",warehouseid)
//        o.put("warehousename",warehousename)
//        o.put("matchAddressUUID",matchAddressUUID)
//      }
//
//
//
//
//
//
//
//
//
//
//
//
//    })
    reRdd
  }
  def saveTable(spark:SparkSession,rdd:RDD[JSONObject],incDay:String): Unit ={
    import spark.implicits._
    val detailDf = rdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + detailDf.count())
    detailDf.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(detailTable)

    val  rowDf = rdd.map(o=>{
      Save(
         JSONUtil.getJsonVal(o,"order_no","")
        ,JSONUtil.getJsonVal(o,"waybill_no","")
        ,JSONUtil.getJsonVal(o,"product_code","")
        ,JSONUtil.getJsonVal(o,"product_name","")
        ,JSONUtil.getJsonVal(o,"bar_sender_station_code","")
        ,JSONUtil.getJsonVal(o,"receiver_province_code","")
        ,JSONUtil.getJsonVal(o,"receiver_province_name","")
        ,JSONUtil.getJsonVal(o,"receiver_city_code","")
        ,JSONUtil.getJsonVal(o,"receiver_city_name","")
        ,JSONUtil.getJsonVal(o,"receiver_area_code","")
        ,JSONUtil.getJsonVal(o,"receiver_area_name","")
        ,JSONUtil.getJsonVal(o,"receiver_city_number","")
        ,JSONUtil.getJsonVal(o,"receiver_detail_address","")
        ,JSONUtil.getJsonVal(o,"receiver_website_code","")
        ,JSONUtil.getJsonVal(o,"deliverer_code","")
        ,JSONUtil.getJsonVal(o,"receiver_company","")
        ,JSONUtil.getJsonVal(o,"receiver_name","")
        ,JSONUtil.getJsonVal(o,"receiver_mobile","")
        ,JSONUtil.getJsonVal(o,"receiver_phone","")
        ,JSONUtil.getJsonVal(o,"is_special_warehousing","")
        ,JSONUtil.getJsonVal(o,"special_address_no","")
        ,JSONUtil.getJsonVal(o,"address","")
        ,JSONUtil.getJsonVal(o,"matchtype","")
        ,JSONUtil.getJsonVal(o,"warehouseid","")
        ,JSONUtil.getJsonVal(o,"warehousename","")
        ,JSONUtil.getJsonVal(o,"matchAddressUUID","")
        ,JSONUtil.getJsonVal(o,"id","")
        ,JSONUtil.getJsonVal(o,"inc_day","")
      )
    }).toDF()
    rowDf.write.mode(SaveMode.Overwrite).insertInto(saveTable)
  }

}