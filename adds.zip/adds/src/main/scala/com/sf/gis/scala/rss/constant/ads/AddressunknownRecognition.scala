package com.sf.gis.scala.rss.constant.ads

import com.sf.gis.scala.base.util.Util
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

/**
  * * Update by 01412406 on 2022/7/31
  * 时间确定
  */

object AddressunknownRecognition {
  @transient lazy val logger: Logger = Logger.getLogger(AddressunknownRecognition.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200






  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

//  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" +startDay)
    startSta(spark,startDay)
    logger.error("计算结束：" + startDay)
//        }
    logger.error("统计完毕")
  }



  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataDf = getDataDf(spark,incDay)
    dataDf.show(3,false)
    logger.error("开始入库")

    saveTable(spark,dataDf,incDay)

    logger.error("结束所有运行")

  }




//入库
  def saveTable(spark: SparkSession, rowDf: DataFrame, incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    logger.error("入汇总表数量：" + rowDf.count())
    val tableName = "dm_gis.address_unknown_recognition_di" //生产数据表
    rowDf.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

  }

//获取数据
  def getDataDf(spark: SparkSession ,incDay: String) = {

//基本数据
    val baseSql =
      """
        |select
        |get_json_object(get_json_object(log,'$.message'),'$.url.datatype') as datatype
        |,get_json_object(get_json_object(log,'$.message'),'$.url.ak') as ak
        |,get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_level') as detail_level
        |,get_json_object(get_json_object(log,'$.message'),'$.data.result.detail_type') as detail_type
        |,log
        |from dm_gis.bee_logs_gis_ar_collect
        |where get_json_object(get_json_object(log,'$.message'),'$.url.ak') in ('04efda998968e66d7cf3811274cbfa9a','87c31491b45745959439b2758f169a17','f7f1b0eda9841fd5ba7ecd91037b8046')
        |and inc_day = '%s' and get_json_object(get_json_object(log,'$.message'),'$.type')='url_e'
      """.stripMargin


    val bSql = String.format(baseSql,incDay)


    logger.error("tmp====>"+baseSql)
    spark.sql(bSql).repartition(800).createOrReplaceTempView("tmp")

    //获取数据源
    val totalDfSql =
      s"""
        |select
        |a.*
        |,b.unknow_cnt
        |,b.unknown_to_know_cnt
        |from (
        |select
        |datatype
        |,case when ak in ('04efda998968e66d7cf3811274cbfa9a','87c31491b45745959439b2758f169a17') then 'BSP'
        |when ak = 'f7f1b0eda9841fd5ba7ecd91037b8046' then 'CX'
        |else ak end as ak_type
        |,count(*) as total_num
        |,sum(if(detail_level='road',1,0)) as le_road_num
        |,sum(if(detail_level='town',1,0)) as le_town_num
        |,sum(if(detail_level='aoi',1,0))  as le_aoi_num
        |,sum(if(detail_level='other',1,0)) as le_other_num
        |,sum(if(detail_level in ('road','town','aoi','other'),1,0)) as le_all_num
        |,sum(if(detail_type ='NO_MATCH_LEVEL',1,0)) as no_match_level_num
        |from (
        |select
        | datatype
        |,ak
        |,detail_level
        |,detail_type
        |from tmp
        |)a
        |group by datatype
        |,case when ak in ('04efda998968e66d7cf3811274cbfa9a','87c31491b45745959439b2758f169a17') then 'BSP'
        |when ak = 'f7f1b0eda9841fd5ba7ecd91037b8046' then 'CX'
        |else ak end
        |)a
        |left join(
        |select
        |*
        |from
        |dm_gis.unaddress_unknown_to_know_sat
        |where inc_day = '${incDay}'
        |)b
        |on a.datatype = b.from_to_flag
        |and a.ak_type =  b.channel_flag
      """.stripMargin


//    val formatSql = String.format(totalDfSql,incDay)

    logger.error(totalDfSql)
    val totalDf =  spark.sql(totalDfSql)
    logger.error("获取到的数据量："+totalDf.count())
    totalDf
  }






}
