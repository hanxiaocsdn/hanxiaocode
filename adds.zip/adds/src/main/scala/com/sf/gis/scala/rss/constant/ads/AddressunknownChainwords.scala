package com.sf.gis.scala.rss.constant.ads

import java.util.regex.Pattern

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.Util
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.{explode, lit, split}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks

/**
  * * 地址不详连锁词情况跑数据
  * 需求：赵瑜婷
  * 任务id：481901
  * 开发：01412406
  */

object AddressunknownChainwords {
  @transient lazy val logger: Logger = Logger.getLogger(AddressunknownChainwords.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  val tableName = "dm_gis.address_unknown_chainwords_detail"
  val reTableName = "dm_gis.address_unknown_chainwords"


  case class result(
                     city_code:String
                     ,province:String
                     ,city:String
                     ,county:String
                     ,address:String
                     ,city_name:String
                     ,splite_result_iad:String
                     ,adcode:String
                     ,chain:String
                   )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataDf = getDataDf(spark, incDay)
    logger.error("获取citycode和adcode对应关系")
    val (notSignalAdcodeRdd,signalAdcodeRdd,brocastDistrbuAdcode, brocastAdcode) = getLocalDataRdd(spark)
    logger.error("关联数据")
    val reRdd = getJoinDate(dataDf,notSignalAdcodeRdd,signalAdcodeRdd,brocastDistrbuAdcode, brocastAdcode)

    logger.error("开始入库")

    saveTable(spark, reRdd, incDay)

    logger.error("结束所有运行")

  }



















  //入库
  def saveTable(spark: SparkSession, detailRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = detailRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF().persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

    //最终入表
    logger.error("入统计表" )
    val reDf = detailRdd.map(o => {
      val city_code = getJsonVal(o, "city_code","")
      val province = getJsonVal(o, "province","")
      val city = getJsonVal(o, "city","")
      val county = getJsonVal(o, "county","")
      val address = getJsonVal(o, "address","")
      val city_name = getJsonVal(o, "city_name","")
      val splite_result_iad = getJsonVal(o, "splite_result_iad","")
      val adcode = getJsonVal(o, "adcode","")
      val chain = getJsonVal(o, "chain","")

      result(
           city_code
          ,province
          ,city
          ,county
          ,address
          ,city_name
          ,splite_result_iad
          ,adcode
          ,chain
      )
    }).toDF().persist(StorageLevel.MEMORY_AND_DISK)

    //汇总表入库
    logger.error("入统计表数量：" + reDf.count())

    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(reTableName)


  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {

    //基本数据
    val baseSql =
      """
        |select
        |get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'),'$.data'),'$.result'),'$.city_code') as city_code
        |,get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'),'$.province') as province
        |,get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'),'$.city') as city
        |,get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'),'$.county') as county
        |,regexp_replace(get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'),'$.address'),  '[\r\n\0, \s,\t, \.,\,,\"]+', '') as address
        |,get_json_object(get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'),'$.data'),'$.result'),'$.district'),'$.city') as city_name
        |,get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'),'$.data'),'$.result'),'$.splite_result_iad') as splite_result_iad
        |from dm_gis.bee_logs_gis_ar_collect
        |where inc_day = '%s' and get_json_object(get_json_object(get_json_object(log,'$.message'),'$.url'),'$.ak') in ( 'f7f1b0eda9841fd5ba7ecd91037b8046','04efda998968e66d7cf3811274cbfa9a','87c31491b45745959439b2758f169a17')
        |and get_json_object(get_json_object(log,'$.message'),'$.type')='url_e'
        |and (get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'),'$.data'),'$.result'),'$.detail_level') = ''
        |or get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'),'$.data'),'$.result'),'$.detail_level') is null )
      """.stripMargin





    //基本数据
//    val baseSql =
//      """
//        |select
//        |'536'as city_code
//        |,'' as province
//        |,'' as city
//        |,'' as county
//        |,'山东省潍坊市高密市尚品服饰' as address
//        |,'' as city_name
//        |,'山东省^1^1;潍坊市^1^2;高密市^1^3;尚品服饰^2^13' as splite_result_iad
//        |from dm_gis.bee_logs_gis_ar_collect
//        |where inc_day = '%s'
//        |limit 1
//      """.stripMargin



    val totalDfSql = String.format(baseSql, incDay)
    logger.error(totalDfSql)
    val totalDf = spark.sql(totalDfSql)
    val soureRdd = getDfToJson(spark,totalDf).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取到的数据量：" + soureRdd.count())
    soureRdd.take(2).foreach(o=>logger.error(o.toJSONString))
    //get_json_object(get_json_object(get_json_object(get_json_object(log,'$.message'),'$.data'),'$.result'),'$.splite_result_iad') ，只保留分词由1/2/3+13组成的数据

   val fitlerSoureRdd =  soureRdd.filter(o=>{
      val splite_result_iad =  getJsonVal(o,"splite_result_iad","")
      //山东省^1^1;临沂市^1^2;兰陵县^1^3;大仲村镇^1^5;流井村^2^13
      val iadArray = splite_result_iad.split(";").map(o=> o.substring(o.indexOf("^", o.indexOf("^") + 1) + 1)).distinct
     //只保留分词由1/2/3+13组成的数据
      val reArray = iadArray.union(Array("1","2","3","13")).distinct
      iadArray.contains("13") && reArray.size == 4

    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("过滤后的数据量："+fitlerSoureRdd.count())
    fitlerSoureRdd
  }

  def getNumbers(content: String) = {
    val pattern = Pattern.compile("\\d+")
    val matcher = pattern.matcher(content)
    var restr = ""
    if (matcher.find()) {
      restr = matcher.group(0)
    }
    restr
  }

  def getDfToJson(spark: SparkSession, sourDf: DataFrame, parNum: Int = 200) = {
    val colList = sourDf.columns

    val sourRdd = sourDf.rdd.repartition(parNum).map(obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns, obj.getAs[String](columns))
      }
      jsonObj
    })
    //println(s"共获取数据:${sourRdd.count()}")

    //sourDf.unpersist()

    sourRdd
  }

  def getJsonVal(obj: JSONObject, keys: String, defaultValue: String): String = {
    var `val`: String = null
    var tempObj = obj
    //    var tempObj = obj.replaceAll("")
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getString(keyArr(i))
      }
    } catch {
      case _: Exception =>
      //logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if (`val` == null) `val` = defaultValue
    //    `val` = `val`.replaceAll("\\n","")
    //    `val` = `val`.replaceAll("\\r","")
    `val`
  }

  def getLocalDataRdd(spark: SparkSession) = {
    import spark.implicits._

    //获取文件
    val citycAdcodeData: DataFrame = spark.read.option("inferschema", "false")
      .option("header", "true")
      .option("delimiter", ",")
      .option("encoding", "UTF-8")
      .csv("/user/01412406/upload/AddressunknownChainwords/citycode_adcode.csv")
      .toDF("adcode", "name", "citycode")
      .persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s"获取文件数：${citycAdcodeData.count()}:" + citycAdcodeData.show(2, false))

    val citycAdcodeRdd = getDfToJson(spark, citycAdcodeData)

    val formatCityAdcodeRdd = citycAdcodeRdd.map(o => (getJsonVal(o, "citycode", "").trim, o)).groupByKey().flatMap(o => {
      val citycode = o._1
      val jsIter = o._2
      val count = jsIter.size
      val reList = jsIter.map(o => {
        o.put("count", count + "")
        (citycode, o, count)
      })
      reList
    })

    val notSignalAdcodeRdd = formatCityAdcodeRdd.filter(_._3 > 1).map(o=>{
      val name =  getJsonVal(o._2,"name","")
      val citycode =  getJsonVal(o._2,"citycode","")
      ((citycode,name),o._2)
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val signalAdcodeRdd = formatCityAdcodeRdd.filter(_._3 == 1).map(o=>{
      val citycode =  getJsonVal(o._2,"citycode","")
      (citycode,o._2)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("adcode多个的数据量：" + notSignalAdcodeRdd.count())
    logger.error("adcode一个的数据量：" + signalAdcodeRdd.count())

    logger.error("获取ChainStore.cfg对应关系")
    //获取文件
    val chainStoreData: DataFrame = spark.read.option("inferschema", "false")
      .option("header", "true")
      .option("delimiter", ",")
      .option("encoding", "UTF-8")
      .csv("/user/01412406/upload/AddressunknownChainwords/chainStore.csv")
      .toDF("chain", "adcode", "distribution", "identifier")
      //        .withColumn("distribution_new",explode(split('distribution,"\\|")))
      .persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s"获取文件数：${chainStoreData.count()}:" + chainStoreData.show(2, false))






    val chainStoreRdd = getDfToJson(spark, chainStoreData)
    val chainStoreRdd2 = getDfToJson(spark, chainStoreData.withColumn("distribution_new", explode(split('distribution, "\\|"))))

    //获取distribution的匹配数据
    val distrbuAdcodeRdd = chainStoreRdd2.map(o => {
      val distribution_new = getJsonVal(o, "distribution_new", "")
      val identifier = getJsonVal(o, "identifier", "")
      val chain = getJsonVal(o, "chain", "")
      val distrbuAdcode = getNumbers(distribution_new)
      (distrbuAdcode.trim, s"${distribution_new}&&&${identifier}&&&${chain}&&&${distrbuAdcode}")
    }).groupByKey().map(o=>{
      val adcode = o._1
      val chainStr = o._2.mkString("@$@$@$")
      (adcode.trim,chainStr)
    }).filter(_._1.nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取distribution不为空的数据量" + distrbuAdcodeRdd.count())
    distrbuAdcodeRdd.take(2).foreach(logger.error(_))

    val brocastDistrbuAdcode = spark.sparkContext.broadcast(distrbuAdcodeRdd.collectAsMap())



    //获取adcode的匹配数据
    val adcodeRdd = chainStoreRdd.map(o => {
      val adcode = getJsonVal(o, "adcode", "")
      val identifier = getJsonVal(o, "identifier", "")
      val chain = getJsonVal(o, "chain", "")
      (adcode.trim, s"${identifier}&&&${chain}")
    }).groupByKey().map(o=>{
      val adcode = o._1
      val chainStr = o._2.mkString("@$@$@$")
      (adcode.trim,chainStr)
    }).filter(_._1.nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取adcode不为空的数据量" + adcodeRdd.count())
//    adcodeRdd.filter(_._1.equals("371500")).take(2).foreach(logger.error(_))

    val brocastAdcode = spark.sparkContext.broadcast(adcodeRdd.collectAsMap())

    (notSignalAdcodeRdd,signalAdcodeRdd,brocastDistrbuAdcode, brocastAdcode)
  }

   //chain匹配规则：
  def judgeChain(splite_result_iad:String,identifier:String,chain:String) ={
    var reChain = ""
    identifier match {
      case "0" => if(chain.nonEmpty && splite_result_iad.equals(chain)) reChain = chain
      case "1" => if(chain.nonEmpty && splite_result_iad.startsWith(chain)) reChain = chain
      case "2" => if(chain.nonEmpty && splite_result_iad.endsWith(chain)) reChain = chain
      case "3" => if(chain.nonEmpty && splite_result_iad.contains(chain)) reChain = chain
      case _ =>
    }
    reChain
  }


  def getJoinDate(dataDf:RDD[JSONObject],notSignalAdcodeRdd:RDD[((String,String),JSONObject)],signalAdcodeRdd:RDD[(String,JSONObject)],brocastDistrbuAdcode: Broadcast[collection.Map[String, String]],brocastAdcode: Broadcast[collection.Map[String, String]])={

    logger.error("关联前的数据量："+dataDf.count())

    val  signalDataRdd= dataDf.map(o=>(getJsonVal(o,"city_code",""),o)).leftOuterJoin(signalAdcodeRdd).map(o=>{
      val right = o._2._2
      val left = o._2._1
      if(right.nonEmpty) left.put("adcode",getJsonVal(right.get,"adcode",""))
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联单个adcode的数据量："+signalDataRdd.count())

    val notSignalDataRdd = signalDataRdd.map(o=>{
      ((getJsonVal(o,"city_code",""),getJsonVal(o,"city_name","")),o)
    }).leftOuterJoin(notSignalAdcodeRdd).map(o=>{
      val right = o._2._2
      val left = o._2._1
      if(right.nonEmpty) left.put("adcode",getJsonVal(right.get,"adcode",""))
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联多个adcode后的数据量："+notSignalDataRdd.count())






    val  adcodeDataRdd = notSignalDataRdd.map(o=>{

      val adcodeMap = brocastAdcode.value
      val adcode = getJsonVal(o,"adcode","")
        //取到13级别分词对应的数据：山东省^1^1;临沂市^1^2;兰陵县^1^3;大仲村镇^1^5;流井村^2^13
        val spliteResultIadList = getJsonVal(o,"splite_result_iad","").split(";").filter(_.contains("13")).map(o=>{o.substring(0,o.indexOf("^"))})
        val chainListStr =adcodeMap.getOrElse(adcode,"")
        val  chainList = chainListStr.split("@\\$@\\$@\\$")
        var  reChain = ""
        Breaks.breakable {
          chainList.foreach(o1 => {
            val identifier = try{o1.split("&&&")(0)}catch {case exception: Exception =>""}
            val chain = try{o1.split("&&&")(1)}catch {case exception: Exception =>""}

            o.put("chain_right1",chain)
            o.put("identifier1",identifier)
            o.put("splite_result_iad1",spliteResultIadList.mkString(";"))
//            o.put("rightRe1",chainListStr)


            spliteResultIadList.foreach(o2=>{
              reChain = judgeChain(o2, identifier, chain)
              if(reChain.nonEmpty) Breaks.break()
            })

//            if(reChain.nonEmpty) Breaks.break()
          })
        }
        o.put("chain",reChain)
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联distrbuAdcodeRdd后的数据量："+adcodeDataRdd.count())

  val unoinRdd =   adcodeDataRdd.filter(o=>getJsonVal(o,"chain","").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
  val codeRdd =   adcodeDataRdd.filter(o=>getJsonVal(o,"chain","").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("adcode出来的chain有值的数据量："+unoinRdd.count())
    logger.error("adcode出来的chain没值的数据量："+codeRdd.count())

    val  distrbuDataRdd = codeRdd.map(o=>{
      val adcodeMap = brocastDistrbuAdcode.value
      val adcode = getJsonVal(o,"adcode","")
      val chainListStr =adcodeMap.getOrElse(adcode,"")
      val  chainList = chainListStr.split("@\\$@\\$@\\$")
        val spliteResultIadList = getJsonVal(o,"splite_result_iad","").split(";").filter(_.contains("13")).map(o=>{o.substring(0,o.indexOf("^"))})
        //s"${distribution_new}_${identifier}_${chain}"
        var  reChain = ""
        Breaks.breakable {
          chainList.foreach(o1 => {
            val distribution_new = try{o1.split("&&&")(0)}catch {case exception: Exception =>""}
            val identifier = try{o1.split("&&&")(1)}catch {case exception: Exception =>""}
            val chain = try{o1.split("&&&")(2)}catch {case exception: Exception =>""}
            var reg = "(\\d+)#.*"
            var reg2 = "(\\d+).*\\*.*"

            o.put("chain_right2",chain)
            o.put("identifier2",identifier)
            o.put("distribution_new",distribution_new)
            o.put("splite_result_iad2",spliteResultIadList.mkString(";"))
//            o.put("rightRe2",chainListStr)

            if(distribution_new.matches(reg) || distribution_new.matches(reg2) ){
              spliteResultIadList.foreach(o2=>{
                reChain = judgeChain(o2, identifier, chain)
                if(reChain.nonEmpty) Breaks.break()
              })
            }
          })
        }
        o.put("chain",reChain)

      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联distrbuAdcodeRdd后chain有值的数据量："+distrbuDataRdd.filter(o=>getJsonVal(o,"chain","").nonEmpty).count())

    val reRdd =distrbuDataRdd.union(unoinRdd).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("最终的数据量："+reRdd.count())
    reRdd.take(10).foreach(o=>logger.error(o.toString))
    adcodeDataRdd.unpersist()
    notSignalDataRdd.unpersist()
    reRdd

  }


}
