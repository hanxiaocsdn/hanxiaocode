-- 任务id：427688
-- 任务名称：快运派件上楼解密数据
-- 开发：陈祥贵
-- 需求方：陈祥贵
-- 描述：快运派件上楼解密数据


set hive.exec.dynamic.partition.mode=nonstrict;
set hive.exec.compress.output=true;
set mapred.compress.map.output=true;
set mapred.output.compress=true;
set mapred.output.compression=org.apache.hadoop.io.compress.SnappyCodec;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.SnappyCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.SnappyCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFormat;
set mapreduce.input.fileinputformat.split.maxsize=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.rack=268435456;
set mapreduce.input.fileinputformat.split.minsize.per.node=268435456;
set mapred.max.split.size=268435456;
set mapred.min.split.size.per.node=268435456;
set mapred.min.split.size.per.rack=268435456;
--设置jvm重用
set mapred.job.reuse.jvm.num.tasks=10;
-- add jar hdfs://sfbdp1/tmp/udf/01397450/97887/1000/decrypt-1.0.0.jar;
-- add file hdfs://sfbdp1//tmp/udf/sfencode/01374443/sfdencrpt.ini;
-- create temporary function new_decrypt as 'com.sf.udf.decrypt.Decrypt';
add file hdfs://sfbdp1//tmp/udf/sfencode/01374443/sfdencrpt.ini;
add jar hdfs://sfbdp1//tmp/udf/01377105/131623/1002/decrypt-2.0.jar;
create temporary function bdp_decrypt as 'com.sf.udf.decrypt_v2.Decrypt';

insert into dm_gis.ky_pai_upstair partition(inc_day='${end_date}')
select
  waybill_no,
  ---运单号
  quantity,
  ---包裹总件数
  meterage_weight_qty,
  --计费重
  consigned_tm,
  --寄件时间
  signin_tm,
  --签收时间
  source_zone_code,
  --寄件网点
  dest_zone_code,
  --派件网点
  product_code,
  --产品代码
  bdp_decrypt(waybill_no,consignee_addr,false),
  ---收件地址
  consignee_comp_name, ---收件公司
  consignee_phone,
  ---收件电话
  consignee_cont_name,
  ---收件联系人
  dest_dist_code,
  ---收件城市代码
  deliver_emp_code,
  ---派件员
  ackbill_type_code,
  ---回单类型
  transfer_parcel_flag,
  ---是否转寄件
  addressee_aoi_id,
  ---收件方（派件）aoiid
  addressee_aoi_dept_code,
  ---收件方（派件）aoi编码
  addressee_building_id , ---收件方（派件）楼栋ID
  dest_hq_name, ---目的地经营本部名称
  dest_area_name , ---目的地区部名称
  inc_day as partition_day,  --分区
  service_prod_code -- 增值服务代码
from
  bdp.dwd.dwd_waybill_info_dtl_di
where
  inc_day between '${begin_date}'
  and '${end_date}'
  and substr(signin_tm, 1, 10) between '${signin_day}'
  and '${signin_day}'
  and product_code in (
    'SE0141',
    'SE0101',
    'SE0100',
    'SE0088',
    'SE0091',
    'SE010101'
  )
  and nvl(ackbill_type_code, '0') <> '9'
  and consignee_addr <> ''
  and (
    meterage_weight_qty >= 100
    or (meterage_weight_qty / quantity) >= 60
  )