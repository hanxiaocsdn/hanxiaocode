package com.sf.gis.java.nloc.utils;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;

import java.lang.reflect.Field;
import java.util.Arrays;


class AddressLevel {
    public String split_result;
    public String aoi_name;

    public String province;
    public String city;
    public String county;
    public String town;
    public String village;
    public String road;
    public String branch_road;
    public String house_no;
    public String branch_house_no;
    public String aoi;
    public String subAoi;
    public String building;
    public String unit;
    public String floor;
    public String room;
}

/**
 * Created by 01373774 on 2021/3/2.
 */
public class AddressLevelJNA {
    public static Boolean g_init_flag = false;
    public interface CLibrary extends Library {
        CLibrary instance = (CLibrary) Native.loadLibrary("WFAddressLevel", CLibrary.class);
        boolean WFAL_Init(String cfgDir, String library_path, String adcode);

        void WFAL_UnInit();

        boolean WFAL_GetAddrLevel(boolean gbk, String splitResult,
                                  PointerByReference pAoi, IntByReference pAoiSize,
                                  PointerByReference pSubAoi, IntByReference pSubAoiSize,
                                  PointerByReference pBuilding, IntByReference pBuildingSize,
                                  PointerByReference pUnit, IntByReference pUnitSize,
                                  PointerByReference pFloor, IntByReference pFloorSize,
                                  PointerByReference pRoom, IntByReference pRoomSize);

        boolean WFAL_GetAddrLevelBySplit(boolean gbk, String adCode, String addr,
                                         PointerByReference pSplitResult, IntByReference pSplitResultSize,
                                         PointerByReference pAoi_name, IntByReference pAoiNameSize,
                                         PointerByReference pAoi, IntByReference pAoiSize,
                                         PointerByReference pSubAoi, IntByReference pSubAoiSize,
                                         PointerByReference pBuilding, IntByReference pBuildingSize,
                                         PointerByReference pUnit, IntByReference pUnitSize,
                                         PointerByReference pFloor, IntByReference pFloorSize,
                                         PointerByReference pRoom, IntByReference pRoomSize);

        void WFAL_ReleaseString(PointerByReference pStr);
    }

    public static synchronized boolean Init(String absolutePath, String snd_path, String cfgDir, String adcode)
    {
        if (!g_init_flag) {
            String path = absolutePath + ":" + snd_path;
            /*
            if (System.getProperty("jna.library.path") != null)
                path = System.getProperty("jna.library.path") + ":" + path;
            System.out.println("library path 1= " + path);
            */
            System.setProperty("jna.library.path", path);
            g_init_flag = true;
            return CLibrary.instance.WFAL_Init(absolutePath + "/" + cfgDir, absolutePath, adcode);
        } else {
            return true;
        }
    }

    public static void UnInit()
    {
        CLibrary.instance.WFAL_UnInit();
    }

    public static boolean GetAddrLevel(boolean gbk, String adcode, String adr, AddressLevel addrLevel)
    {
        PointerByReference splitResultRef = new PointerByReference();
        IntByReference splitResultSizeRef = new IntByReference();
        PointerByReference aoiNameRef = new PointerByReference();
        IntByReference aoiNameSizeRef = new IntByReference();
        PointerByReference aoiRef = new PointerByReference();
        IntByReference aoiSizeRef = new IntByReference();
        PointerByReference subAoiRef = new PointerByReference();
        IntByReference subAoiSizeRef = new IntByReference();
        PointerByReference buildingRef = new PointerByReference();
        IntByReference buildingSizeRef = new IntByReference();
        PointerByReference unitRef = new PointerByReference();
        IntByReference unitSizeRef = new IntByReference();
        PointerByReference floorRef = new PointerByReference();
        IntByReference floorSizeRef = new IntByReference();
        PointerByReference roomRef = new PointerByReference();
        IntByReference roomSizeRef = new IntByReference();
        boolean res = CLibrary.instance.WFAL_GetAddrLevelBySplit(gbk, adcode, adr, splitResultRef, splitResultSizeRef, aoiNameRef, aoiNameSizeRef,
                aoiRef, aoiSizeRef, subAoiRef, subAoiSizeRef, buildingRef, buildingSizeRef, unitRef, unitSizeRef, floorRef, floorSizeRef, roomRef, roomSizeRef);
        if (!res) {
            System.out.println("fail !!!");
            return res;
        }

        // 初始化
        addrLevel.province = "";
        addrLevel.city = "";
        addrLevel.county = "";
        addrLevel.town = "";
        addrLevel.village = "";
        addrLevel.road = "";
        addrLevel.branch_road = "";
        addrLevel.house_no = "";
        addrLevel.branch_house_no = "";

        // 取出缓存空间
        Pointer p = splitResultRef.getValue();
        byte[] splitResultBuff = p.getByteArray(0, splitResultSizeRef.getValue());
        addrLevel.split_result = new String(splitResultBuff);
        if (!addrLevel.split_result.isEmpty())
        {
            String[] vecSplitResult = addrLevel.split_result.split(";");
            if (2 != vecSplitResult.length) {
                System.out.println("split_result:" + addrLevel.split_result + " format error!");
            }
            else
            {
                String strKeyLevel = vecSplitResult[0];
                String[] vecKeyLevel = strKeyLevel.split(",");
                for (int i = 0; i < vecKeyLevel.length; i++)
                {
                    if (vecKeyLevel[i].isEmpty()) {
                        continue;
                    }

                    String[] vecData = vecKeyLevel[i].split("\\^"); // 需要转义
                    if (2 != vecData.length || vecData[1].length() < 2)
                    {
                        System.out.println("key_level:" + vecKeyLevel[i] + " format error!");
                        continue;
                    }

                    String strName = vecData[0];
                    String strLevel = vecData[1].substring(1); // 忽略nProp
                    int iLevel = Integer.parseInt(strLevel);
                    if (1 == iLevel) {
                        addrLevel.province = strName;
                    }
                    else if (2 == iLevel) {
                        addrLevel.city = strName;
                    }
                    else if (3 == iLevel) {
                        addrLevel.county = strName;
                    }
                    else if (5 == iLevel) {
                        addrLevel.town = strName;
                    }
                    else if (6 == iLevel) {
                        addrLevel.village = strName;
                    }
                    else if (9 == iLevel) {
                        addrLevel.road = strName;
                    }
                    else if (10 == iLevel) {
                        addrLevel.branch_road = strName;
                    }
                    else if (11 == iLevel) {
                        addrLevel.house_no = strName;
                    }
                    else if (12 == iLevel) {
                        addrLevel.branch_house_no = strName;
                    }
                }
            }
        }

        p = aoiNameRef.getValue();
        byte[] aoiNameBuff = p.getByteArray(0, aoiNameSizeRef.getValue());
        addrLevel.aoi_name = new String(aoiNameBuff);

        p = aoiRef.getValue();
        byte[] aoiBuff = p.getByteArray(0, aoiSizeRef.getValue());
        addrLevel.aoi = new String(aoiBuff);
        //System.out.println("aoi:" + addrLevel.aoi + ", aoi_size:" + aoiSizeRef.getValue());

        p = subAoiRef.getValue();
        byte[] subAoiBuff = p.getByteArray(0, subAoiSizeRef.getValue());
        addrLevel.subAoi = new String(subAoiBuff);
        //System.out.println("sub_aoi:" + addrLevel.subAoi + ", sub_aoi_size:" + subAoiSizeRef.getValue());

        p = buildingRef.getValue();
        byte[] buildingBuff = p.getByteArray(0, buildingSizeRef.getValue());
        addrLevel.building = new String(buildingBuff);
        //System.out.println("building:" + addrLevel.building + ", building_size:" + buildingSizeRef.getValue());

        p = unitRef.getValue();
        byte[] unitBuff = p.getByteArray(0, unitSizeRef.getValue());
        addrLevel.unit = new String(unitBuff);
        //System.out.println("unit:" + addrLevel.unit + ", unit_size:" + unitSizeRef.getValue());

        p = floorRef.getValue();
        byte[] floorBuff = p.getByteArray(0, floorSizeRef.getValue());
        addrLevel.floor = new String(floorBuff);
        //System.out.println("floor:" + addrLevel.floor + ", floor_size:" + floorSizeRef.getValue());

        p = roomRef.getValue();
        byte[] roomBuff = p.getByteArray(0, roomSizeRef.getValue());
        addrLevel.room = new String(roomBuff);
        //System.out.println("room:" + addrLevel.room + ", room_size:" + roomSizeRef.getValue());

        CLibrary.instance.WFAL_ReleaseString(splitResultRef);
        CLibrary.instance.WFAL_ReleaseString(aoiNameRef);
        CLibrary.instance.WFAL_ReleaseString(aoiRef);
        CLibrary.instance.WFAL_ReleaseString(subAoiRef);
        CLibrary.instance.WFAL_ReleaseString(buildingRef);
        CLibrary.instance.WFAL_ReleaseString(unitRef);
        CLibrary.instance.WFAL_ReleaseString(floorRef);
        CLibrary.instance.WFAL_ReleaseString(roomRef);
        return true;
    }

    public static void AddLibraryPath(String libraryPath) throws Exception {
        Field userPathsField = ClassLoader.class.getDeclaredField("usr_paths");
        userPathsField.setAccessible(true);
        String[] paths = (String[]) userPathsField.get(null);
        System.out.println("old_user_path:" + Arrays.toString(paths));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < paths.length; i++) {
            if (libraryPath.equals(paths[i])) {
                return;
            }
            sb.append(paths[i]).append(',');
        }
        sb.append(libraryPath);

        String[] newPaths = new String[paths.length + 1];
        System.arraycopy(paths, 0, newPaths, 0, paths.length);
        newPaths[paths.length] = libraryPath;
        userPathsField.set(null, newPaths);
        System.out.println("new_user_path:" + Arrays.toString(newPaths));


//        final Field sysPathsField = ClassLoader.class.getDeclaredField("sys_paths");
//        sysPathsField.setAccessible(true);
//        sysPathsField.set(null, null);

        System.setProperty("java.library.path", sb.toString());
    }

    public static void main(String[] args)
    {
        try {
            if (!Init( "F:\\jnalib", "", "config", "440300"))
            {
                System.out.println("call Init failure!");
                return;
            }

            String adr = "明天花园小区^213,10号楼^214,2单元^215,1101^217;17";
            adr = "西乡街道桃源商务大厦-1座210";
            AddressLevel addrLevel = new AddressLevel();
            if (!GetAddrLevel(false, "440300", adr, addrLevel))
            {
                System.out.println("call GetAddrLevel failure!");
                UnInit();
                return;
            }
            System.out.println("split_result:" + addrLevel.split_result);
            System.out.println("aoi_name:" + addrLevel.aoi_name);
            System.out.println("province:" + addrLevel.province);
            System.out.println("city:" + addrLevel.city);
            System.out.println("county:" + addrLevel.county);
            System.out.println("town:" + addrLevel.town);
            System.out.println("village:" + addrLevel.village);
            System.out.println("road:" + addrLevel.road);
            System.out.println("branch_road:" + addrLevel.branch_road);
            System.out.println("house_no:" + addrLevel.house_no);
            System.out.println("branch_house_no:" + addrLevel.branch_house_no);
            System.out.println("aoi:" + addrLevel.aoi);
            System.out.println("sub_aoi:" + addrLevel.subAoi);
            System.out.println("building:" + addrLevel.building);
            System.out.println("unit:" + addrLevel.unit);
            System.out.println("floor:" + addrLevel.floor);
            System.out.println("room:" + addrLevel.room);
        } catch (Exception e) {
            System.out.println("raise exception:" + e.toString() + "!");
        }

        UnInit();
    }
}