package com.sf.gis.java.nloc.utils;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.util.Arrays;


class AddressLevelNew {
    public String aoi;
    public String subAoi;
    public String building;
    public String unit;
    public String floor;
    public String room;
}

/**
 * Created by 01373774 on 2021/3/2.
 */
public class AddressLevelJNASplit {
    public static Boolean g_init_flag = false;
    public interface CLibrary extends Library {
        CLibrary instance = (CLibrary) Native.loadLibrary("WFAddressLevel", CLibrary.class);
        boolean WFAL_Init(String cfgDir);

        void WFAL_UnInit();

        boolean WFAL_GetAddrLevel(boolean gbk, String splitResult,
                                  PointerByReference pAoi, IntByReference pAoiSize,
                                  PointerByReference pSubAoi, IntByReference pSubAoiSize,
                                  PointerByReference pBuilding, IntByReference pBuildingSize,
                                  PointerByReference pUnit, IntByReference pUnitSize,
                                  PointerByReference pFloor, IntByReference pFloorSize,
                                  PointerByReference pRoom, IntByReference pRoomSize);

        void WFAL_ReleaseString(PointerByReference pStr);
    }

    public static synchronized boolean Init(String absolutePath, String cfgDir)
    {
        if (!g_init_flag) {
            //System.setProperty("jna.library.path", System.getProperty("jna.library.path") + "/;" + absolutePath);
            System.setProperty("jna.library.path", absolutePath);
            g_init_flag = true;
            return CLibrary.instance.WFAL_Init(absolutePath + "/" + cfgDir);
        } else {
            return true;
        }
    }

    public static void UnInit()
    {
        CLibrary.instance.WFAL_UnInit();
    }

    public static String getSplitResultFloor(String splitResult){
        String floor="";
        try {

            String utf8 = new String(splitResult.getBytes(), "utf-8");
            AddressLevelNew addrLevel = new AddressLevelNew();
            if (!GetAddrLevel(false, utf8, addrLevel))
            {
                System.out.println("call GetAddrLevel failure!");
                UnInit();
                return floor;
            }
            floor=addrLevel.floor;
        } catch (Exception e) {
            System.out.println("raise exception:" + e.toString() + "!");
        }
        return floor;
    }

    public static boolean GetAddrLevel(boolean gbk, String splitResult, AddressLevelNew addrLevel)
    {
        PointerByReference aoiRef = new PointerByReference();
        IntByReference aoiSizeRef = new IntByReference();
        PointerByReference subAoiRef = new PointerByReference();
        IntByReference subAoiSizeRef = new IntByReference();
        PointerByReference buildingRef = new PointerByReference();
        IntByReference buildingSizeRef = new IntByReference();
        PointerByReference unitRef = new PointerByReference();
        IntByReference unitSizeRef = new IntByReference();
        PointerByReference floorRef = new PointerByReference();
        IntByReference floorSizeRef = new IntByReference();
        PointerByReference roomRef = new PointerByReference();
        IntByReference roomSizeRef = new IntByReference();
        boolean res = CLibrary.instance.WFAL_GetAddrLevel(gbk, splitResult, aoiRef, aoiSizeRef, subAoiRef, subAoiSizeRef,
                buildingRef, buildingSizeRef, unitRef, unitSizeRef, floorRef, floorSizeRef, roomRef, roomSizeRef);
        if (!res) {
            return res;
        }

        // 取出缓存空间
        Pointer p = aoiRef.getValue();
        byte[] aoiBuff = p.getByteArray(0, aoiSizeRef.getValue());
        addrLevel.aoi = new String(aoiBuff);
        //System.out.println("aoi:" + addrLevel.aoi + ", aoi_size:" + aoiSizeRef.getValue());

        p = subAoiRef.getValue();
        byte[] subAoiBuff = p.getByteArray(0, subAoiSizeRef.getValue());
        addrLevel.subAoi = new String(subAoiBuff);
        //System.out.println("sub_aoi:" + addrLevel.subAoi + ", sub_aoi_size:" + subAoiSizeRef.getValue());

        p = buildingRef.getValue();
        byte[] buildingBuff = p.getByteArray(0, buildingSizeRef.getValue());
        addrLevel.building = new String(buildingBuff);
        //System.out.println("building:" + addrLevel.building + ", building_size:" + buildingSizeRef.getValue());

        p = unitRef.getValue();
        byte[] unitBuff = p.getByteArray(0, unitSizeRef.getValue());
        addrLevel.unit = new String(unitBuff);
        //System.out.println("unit:" + addrLevel.unit + ", unit_size:" + unitSizeRef.getValue());

        p = floorRef.getValue();
        byte[] floorBuff = p.getByteArray(0, floorSizeRef.getValue());
        addrLevel.floor = new String(floorBuff);
        //System.out.println("floor:" + addrLevel.floor + ", floor_size:" + floorSizeRef.getValue());

        p = roomRef.getValue();
        byte[] roomBuff = p.getByteArray(0, roomSizeRef.getValue());
        addrLevel.room = new String(roomBuff);
        //System.out.println("room:" + addrLevel.room + ", room_size:" + roomSizeRef.getValue());

        CLibrary.instance.WFAL_ReleaseString(aoiRef);
        CLibrary.instance.WFAL_ReleaseString(subAoiRef);
        CLibrary.instance.WFAL_ReleaseString(buildingRef);
        CLibrary.instance.WFAL_ReleaseString(unitRef);
        CLibrary.instance.WFAL_ReleaseString(floorRef);
        CLibrary.instance.WFAL_ReleaseString(roomRef);
        return true;
    }

    public static void AddLibraryPath(String libraryPath) throws Exception {
        Field userPathsField = ClassLoader.class.getDeclaredField("usr_paths");
        userPathsField.setAccessible(true);
        String[] paths = (String[]) userPathsField.get(null);
        System.out.println("old_user_path:" + Arrays.toString(paths));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < paths.length; i++) {
            if (libraryPath.equals(paths[i])) {
                return;
            }
            sb.append(paths[i]).append(',');
        }
        sb.append(libraryPath);

        String[] newPaths = new String[paths.length + 1];
        System.arraycopy(paths, 0, newPaths, 0, paths.length);
        newPaths[paths.length] = libraryPath;
        userPathsField.set(null, newPaths);
        System.out.println("new_user_path:" + Arrays.toString(newPaths));


//        final Field sysPathsField = ClassLoader.class.getDeclaredField("sys_paths");
//        sysPathsField.setAccessible(true);
//        sysPathsField.set(null, null);

        System.setProperty("java.library.path", sb.toString());
    }

    public static void main(String[] args)
    {
        try {
            System.out.println("start unzip");
            System.out.println(System.getProperty("user.dir"));
            //Process process = Runtime.getRuntime().exec(new String[]{"unzip", "/data/appdeploy/zengkun/jar_test/wifi-cell-cluster-3.3-jar-with-dependencies.jar", "-d", System.getProperty("user.dir")});
            Process process = Runtime.getRuntime().exec(new String[]{"jar", "-xvf", "/data/appdeploy/zengkun/jar_test/wifi-cell-cluster-3.3-jar-with-dependencies.jar"});
            //Process process = Runtime.getRuntime().exec(new String[]{"ls",  "-al"});
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line = null;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
            // waitFor 阻塞等待 异步进程结束，并返回执行状态，0代表命令执行正常结束。
            System.out.println(process.waitFor());
            //Process process = Runtime.getRuntime().exec( "unzip " + "/data/appdeploy/zengkun/jar/wifi-cell-cluster-3.3-jar-with-dependencies.jar " + " -d " + System.getProperty("user.dir"));
            //process.waitFor();

            //AddLibraryPath("/data/appdeploy/VisualGDB/01375655/WifiFinger/build/WFAddressLevel/lib");
            //System.setProperty("jna.library.path", "/data/appdeploy/VisualGDB/01375655/WifiFinger/build/WFAddressLevel/lib");
            //System.setProperty("jna.library.path", System.getProperty("user.dir"));

            if (!Init( "", "./config"))
            {
                System.out.println("call Init failure!");
                return;
            }

            String splitResult = "明天花园小区^213,10号楼^214,2单元^215,1101^217;17";
            splitResult = "广东省^11,深圳市^12,龙华区^03,福城街道^15,福民社区^16,外经工业园^213,24号^214,101^217,泰衡诺^213,a栋^214,5楼^216;17";
            System.out.println("split_result:" + splitResult);
            String utf8 = new String(splitResult.getBytes(), "utf-8");
            AddressLevelNew addrLevel = new AddressLevelNew();
            if (!GetAddrLevel(false, utf8, addrLevel))
            {
                System.out.println("call GetAddrLevel failure!");
                UnInit();
                return;
            }
            System.out.println("aoi:" + addrLevel.aoi);
            System.out.println("sub_aoi:" + addrLevel.subAoi);
            System.out.println("building:" + addrLevel.building);
            System.out.println("unit:" + addrLevel.unit);
            System.out.println("floor:" + addrLevel.floor);
            System.out.println("room:" + addrLevel.room);
        } catch (Exception e) {
            System.out.println("raise exception:" + e.toString() + "!");
        }

        UnInit();
    }
}