package com.sf.gis.java.nloc.utils;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.ptr.PointerByReference;


public class TypeJudgeJNA {
    public static Boolean g_init_flag = false;
    public interface CLibrary extends Library {
        CLibrary instance1 = (CLibrary) Native.loadLibrary("USTypeJudge", CLibrary.class);
        boolean WFAL_Init(String cfgDir);

        void WFAL_UnInit();

        boolean WFAL_GetType(String name_chn, int name_chn_len, String splitResult, int len, String adcode, int adcode_len,
                                  PointerByReference type, IntByReference type_len);

        void WFAL_ReleaseString(PointerByReference pStr);
    }

    public static synchronized boolean Init(String absolutePath)
    {
        if (!g_init_flag) {
            /*
            String path = absolutePath;
            if (System.getProperty("jna.library.path") != null)
                path = path + ":" + System.getProperty("jna.library.path");
            System.out.println("library path = " + path);
            System.setProperty("jna.library.path", path);
             */
            g_init_flag = true;
            return CLibrary.instance1.WFAL_Init(absolutePath + "/");
        } else {
            return true;
        }
    }

    public static void UnInit()
    {
        CLibrary.instance1.WFAL_UnInit();
    }

    public static String GetAddrType(String name_chn, String split_info, String adcode)
    {
        try {
            name_chn = new String(name_chn.getBytes( "GBK"));
            split_info = new String(split_info.getBytes( "GBK"));
            PointerByReference type_ref = new PointerByReference();
            IntByReference type_len_ref = new IntByReference();
            boolean res = CLibrary.instance1.WFAL_GetType(name_chn, name_chn.getBytes().length, split_info, split_info.getBytes().length, adcode, adcode.length(), type_ref, type_len_ref);
            if (!res) {
                return "";
            }

            // 取出缓存空间
            Pointer p = type_ref.getValue();
            byte[] typeBuff = p.getByteArray(0, type_len_ref.getValue());
            String type_result = new String(typeBuff);

            CLibrary.instance1.WFAL_ReleaseString(type_ref);
            return type_result;
        } catch (Exception e) {
            return "";
        }
    }

    public static void main(String[] args)
    {
        Init("/data/appdeploy/zengkun/VisualGDB/01424113/uniform_search_V2.0/build/Debug");
        String type_result = GetAddrType("广东省深圳市龙华区裕石路8号东方红工业园2栋2楼", "广东省^11,深圳市^12,龙华区^03,裕石路^19,8号^211,东方红工业园^213,2栋^214,2楼^216;16", "440300");
        System.out.println(type_result);
    }
}