package com.sf.gis.scala.nloc.app


import com.alibaba.fastjson.JSONObject

import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

import java.net.URLEncoder
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01404964
 * @Author: 01407499
 * @CreateTime: 2023-06-16 10:39
 * @TaskId:769687
 * @TaskName:派件上楼-数据入库
 * @Description:
 */

class MyThread(spark: SparkSession) extends Thread {

    override def run() {
        while(true){
            EleSaveKYRun.updateToken(spark)
        }
    }
}

object EleSaveKYRun {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    var token_all: String = null
    def main(args: Array[String]): Unit = {
        var date=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
//        new MyThread(sparkSession).start()
//        updateToken(sparkSession)
        runadd(sparkSession,date)


    }

    def updateToken(spark: SparkSession):Unit ={
        val token = getToken()
        if(!StringUtils.isEmpty(token)) {
            logger.error(">>>new token：" + token)
            token_all = token
        }
//        Thread.sleep(600000)
    }

    def getToken(): String ={
        var access_token = ""

        val username = "01368978"
        val password = "8978@Bdp"
        val header = "Authorization"
        val value = "Basic R0lTLUFTUy1BT1MtQkRQLUVMRVY6YW9zQmRwRWxldiMyMDIy"
        val url = "http://orion-gateway.sf-express.com/uac/oauth/token?grant_type=password&username=%s&password=%s".format(username,password)

        breakable(
            for(i<-0.until(5)){
                try {
                    val jsonObject = HttpInvokeUtil.sendPostHeader(url, "", header, value, "UTF-8", "UTF-8")
                    logger.error(">>>访问getToken：url" + i + "=" + url + ", result="+jsonObject)
                    Thread.sleep(2000)
                    if(jsonObject!=null){

                        access_token = JSONUtil.parseJSONObject(jsonObject).getString("access_token")
                        if(!StringUtils.isEmpty(access_token)) break
                        else Thread.sleep(2000)
                    }
                    if(i >= 4) break
                } catch {
                    case e:Exception =>logger.error(">>>访问getToken：url" + i + "=" + url)
                }
            }
        )
        access_token
    }



    def runadd(spark: SparkSession, date:String):Unit ={
        var sql=""
        sql =
            s"""
               |
               |select
               |city_code as citycode
               |,'add' as mode
               |,'group' as target
               |,group_id
               |,`source`
               |,addr
               |,'' as keyword
               |,is_elevator
               |,is_climb
               |,aoi_id
               |from dm_gis.elevator_group_info
               |
               |
       """.stripMargin

        logger.error("sql----> "+sql)
        val (logRdd, columns) = SparkRead.readHiveAsJson(spark, sql)
        logRdd.foreachPartition(itr=>{
            token_all=getToken()
            for(json<-itr){
                if(json!=null){
                    var mode = json.getString("mode")
                    var target = json.getString("target")
                    var citycode = json.getString("citycode")
                    var group_id = json.getString("group_id")
                    var is_elevator = json.getString("is_elevator")
                    var is_climb = json.getString("is_climb")
                    var source = json.getString("source")
                    var keyword = json.getString("keyword")
                    if(StringUtils.isEmpty(mode)) mode = ""
                    if(StringUtils.isEmpty(target)) target = ""
                    if(StringUtils.isEmpty(source)) source = ""
                    if(StringUtils.isEmpty(citycode)) citycode = ""
                    if(StringUtils.isEmpty(group_id)) group_id = ""
                    if(StringUtils.isEmpty(is_elevator)) is_elevator = ""
                    if(StringUtils.isEmpty(is_climb)) is_climb = ""
                    if(StringUtils.isEmpty(keyword)) keyword = ""
                    if("add".equalsIgnoreCase(mode)) {
                        add(target,citycode,group_id,is_elevator,is_climb,source,keyword)
                        add2(target,citycode,group_id,is_elevator,is_climb,source,keyword,token_all)
                    }
                }


            }

        })
//        Thread.sleep(1000000)
        logger.error("数据量----》 "+logRdd.count())

        logRdd.unpersist()
    }

    def add(target:String, citycode:String, group_id:String, is_elevator:String, is_climb:String, source:String, keyword:String): JSONObject ={
        var jsonObject:JSONObject = null
        val url = "http://gis-int.int.sfdc.com.cn:1080/elevator/api/add?ak=379924356e8b444da83f04ebb1703f19&target=%s&cityCode=%s&id=%s&isElevator=%s&isClimb=%s&source=%s&keyword=%s&updateBy=00000006&updateReason=S102-多源校验"
            .format(target,citycode,group_id,is_elevator,is_climb,source,URLEncoder.encode(keyword, "UTF-8"))
        breakable(
            for(i<-0.until(5)){
                try {
                    jsonObject = HttpClientUtil.getJsonByGet(url)
//                    logger.error("result is --->"+jsonObject.toString())
                    Thread.sleep(50)
                    //          if(jsonObject!=null) logger.error(">>>url:"+ url + " >>>result:"+ jsonObject.toJSONString)
                    //          else logger.error(">>>url:"+ url + " >>>result:null")
                    if(jsonObject==null) logger.error(">>>url:"+ url + " >>>result:null")
                    break
                } catch {
                    case e:Exception =>logger.error(">>>访问add异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
                }
            }
        )
        jsonObject
    }

    def add2(target:String, citycode:String, group_id:String, is_elevator:String, is_climb:String, source:String, keyword:String, token:String): JSONObject ={
        var jsonObject:JSONObject = null
        val baseUrl = "https://gis-orion-work.sf-express.com"
        val aoi_url = s"$baseUrl/work/api/aoiElevator/insert"
        val group_url = s"$baseUrl/work/api/groupElevator/insert"
        val keyword_url = s"$baseUrl/work/api/aoiKeywordElevator/insert"
        var url = ""
        if("aoi".equalsIgnoreCase(target)) {
            if("key".equalsIgnoreCase(source)) url = keyword_url
            else url = aoi_url
        }
        else if("group".equalsIgnoreCase(target)) url = group_url
        val header = "Authorization"
        val value = "Bearer " + token
        val params = new JSONObject()
        params.put("cityCode",citycode)
        params.put("updateReason","S102-多源校验")
        if(aoi_url.equals(url) || group_url.equals(url)){
            params.put("isClimb",is_climb)
            params.put("isElevator",is_elevator)
            params.put("source",source)
        }
        else if(keyword_url.equals(url)){
            params.put("climb",is_climb)
            params.put("elevator",is_elevator)
            params.put("keyword",keyword)
        }
        if(group_url.equals(url)){
            params.put("groupId",group_id)
        }
        else {
            params.put("aoiId",group_id)
        }
        breakable(
            for(i<-0.until(5)){
                try {
                    jsonObject = JSONUtil.parseJSONObject(HttpInvokeUtil.sendPostHeader(url, params.toString, header, value, "UTF-8", "UTF-8"))
                    Thread.sleep(50)
                    if(jsonObject!=null){
                        //            logger.error(">>>url:"+ url + " >>>params:"+ params.toString + " >>>result:"+ jsonObject.toJSONString + " >>>token:" + token)
                        val success = jsonObject.getString("success")
//                        logger.error("result---->"+jsonObject.toString())
                        if("true".equalsIgnoreCase(success)) break
                        else Thread.sleep(50)
                    }
                    else logger.error(">>>url:"+ url + " >>>params:"+ params.toString + " >>>result:null")
                    if(i >= 4) break
                } catch {
                    case e:Exception =>logger.error(">>>访问add2异常："+e+",第" + i + "次, url=" + url + ",params="+ params.toString + ", json="+jsonObject + " >>>token:" + token)
                }
            }
        )
        jsonObject
    }


}
