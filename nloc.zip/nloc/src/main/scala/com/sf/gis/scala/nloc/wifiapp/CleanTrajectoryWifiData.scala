package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, GeometryUtil}
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkNetNew, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.gis.scala.nloc.wifiapp.DeliverFilterInvalidWifi.{aoiCoorsDist, getHour}

import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-12-07 14:06
 * @TaskId:942107
 * @TaskName:wifi指纹库-aoi变更-清洗轨迹wifi
 * @Description:
 */

object CleanTrajectoryWifiData {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val poiUrl="http://gis-gw.int.sfdc.com.cn:9080/atpoi/api"
    var saveStandardKey=Array("waybill_id","waybill_no","emp_code","tm","addr","std_address","eventtype","aoi_id","aoi_name","buildingid","buildingname","x","y","aoi_key","bld_key","province","city","county","town","village","floor","room","reserve1","reserve2","split_info","city_code","inc_day")
    val saveKey = Array("waybill_no","city_code","emp_code","tm","addr","eventtype","ewl","lng","lat","doing","aoi_id","aoi_name","buildingid","buildingname","lng_bld","lat_bld","province","city","county","town","village","floor","room","tag","bld_cntr_dist","aoi_interface_data")

    var saveSignStandardKey=Array("waybill_id","waybill_no","emp_code","tm","addr","std_address","eventtype","aoi_id","aoi_name","buildingid","buildingname","x","y","aoi_key","bld_key","province","city","county","town","village","floor","room","reserve1","reserve2","split_info","city_code","modify_type")
    val saveSignKey = Array("waybill_no","city_code","emp_code","tm","addr","eventtype","ewl","lng","lat","doing","aoi_id","aoi_name","buildingid","buildingname","lng_bld","lat_bld","province","city","county","town","village","floor","room","tag","aoi_interface_data","bld_cntr_dist","modify_type")

    def main(args: Array[String]): Unit = {

        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val end_day=args(0)
        val start_day=args(1)
        val end_date=args(2)
        val start_date=args(3)
        val mode=args(4)
        mode match {
            case "sign"=>sign(sparkSession,end_day,start_day,end_date,start_date)
            case "clean"=>clean(sparkSession,end_day,end_date)
            case "modify"=>modify(sparkSession,end_day,start_day,end_date)
        }


    }




    def sign(sparkSession:SparkSession,end_day:String,start_day:String,end_date:String,start_date:String)={
        logger.error("获取aoi名称变更数据")
        val aoiInfoModifyNameMapBroad: Broadcast[Map[String, String]] = getModifyNameAoiInfo(sparkSession, end_day, start_day)

        logger.error("获取aoi删除数据")
        val aoiInfoDeleSetBroad: Broadcast[Set[String]] = getDeleAoiInfo(sparkSession, end_day, start_day)

        logger.error("获取修改边界数据")
        val aoiInfoModifyBoundarySetBroad: Broadcast[Set[String]] = getModifyAoiInfo(sparkSession, end_day, start_day)

        logger.error("标记标准数据")
        val signStandardRdd = signStandardData(sparkSession, end_date, start_date, aoiInfoModifyNameMapBroad, aoiInfoDeleSetBroad)
        SparkWrite.save2HiveStatic(sparkSession, signStandardRdd, saveSignStandardKey, "dm_gis.dm_wifi_finger_waybill_normalization_aoi_change_di",Array(("inc_day", end_date)), 25)
        Spark.clearAllPersist(sparkSession)

        val signTraceWifiRdd = signTraceWifiData(sparkSession, end_date, start_date, aoiInfoModifyNameMapBroad, aoiInfoModifyBoundarySetBroad, aoiInfoDeleSetBroad)
        SparkWrite.save2HiveStatic(sparkSession, signTraceWifiRdd, saveSignKey, "dm_gis.dm_wifi_finger_traj_aoi_change_di",Array(("inc_day", end_date)), 25)



    }

    def clean(sparkSession:SparkSession,end_day:String,end_date:String)={

        val (cleanOverDataRdd,standardDataCleanRdd) = cleanAllTypeStandardData(sparkSession, end_day, end_date)
//        SparkWrite.save2HiveStatic(sparkSession, standardDataCleanRdd, saveSignStandardKey, "dm_gis.dm_wifi_finger_waybill_normalization_aoi_change_di",Array(("inc_day", end_date)), 25)
        Spark.clearPersistWithoutId(sparkSession,cleanOverDataRdd.id)
        val cleanTraceWifiRdd = cleanAllTraceWifi(sparkSession, cleanOverDataRdd, end_date)
        SparkWrite.save2HiveStatic(sparkSession, cleanTraceWifiRdd, saveSignKey, "dm_gis.dm_wifi_finger_traj_aoi_change_di",Array(("inc_day", end_date)), 25)



    }


    def modify(sparkSession:SparkSession,end_day:String,start_day:String,end_date:String)={

        logger.error("获取aoi名称变更数据")
        val aoiInfoModifyNameMapBroad: Broadcast[Map[String, String]] = getModifyNameAoiInfo(sparkSession, end_day, start_day)

        logger.error("获取aoi删除数据")
        val aoiInfoDeleSetBroad: Broadcast[Set[String]] = getDeleAoiInfo(sparkSession, end_day, start_day)

        logger.error("获取修改边界数据")
        val aoiInfoModifyBoundarySetBroad: Broadcast[Set[String]] = getModifyAoiInfo(sparkSession, end_day, start_day)

        logger.error("标准数据修改aoi名称")
        val standardDataRdd = standardDataModifyAoiName(sparkSession, end_date, aoiInfoModifyNameMapBroad)

        logger.error("标准数据清洗aoi删除数据")
        val (cleanOverDataRdd,standardDataCleanRdd) = cleanStandardData(sparkSession, end_day, aoiInfoDeleSetBroad, end_date,standardDataRdd)
        logger.error("存储清洗完成的标准化数据")
        saveStandardDataToHive(sparkSession,standardDataCleanRdd,end_date)
        Spark.clearPersistWithoutId(sparkSession,cleanOverDataRdd.id)

        logger.error("轨迹wifi数据修改aoi名称")
        val traceWifiDataRdd = traceWifiDataModifyAoiName(sparkSession, end_date, aoiInfoModifyNameMapBroad)

        logger.error("轨迹wifi清洗aoi删除数据")
        val cleanOverTraceWifiRdd = cleanTraceWifi(sparkSession, end_date, aoiInfoDeleSetBroad, cleanOverDataRdd,traceWifiDataRdd)

        logger.error("轨迹wifi数据修改aoi边界")
        val resultRdd = modifyWifi(sparkSession, end_date, aoiInfoModifyBoundarySetBroad,cleanOverTraceWifiRdd)
        logger.error("存储轨迹wifi数据")
        SparkWrite.save2HiveStatic(sparkSession, resultRdd, saveKey, "dm_gis.dm_wifi_finger_traj_dtl_di",Array(("inc_day", end_date)), 25)



    }



    def signStandardData(sparkSession:SparkSession,end_date:String,start_date:String,aoiModifyNameInfoMapBroad: Broadcast[Map[String, String]],aoiInfoDeleSetBroad: Broadcast[Set[String]])={

        var sql=
            s"""
               |
               |
               |select * from dm_gis.dm_tt_waybill_normalization_dtl_di where inc_day<='$end_date' and inc_day>='$start_date'
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val df = sparkSession.sql(sql)
        val columns = df.columns
        val dataRdd = df.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getString(i))
            }
            jObj
        })

        val modifyNameRdd = dataRdd.mapPartitions(x => {
            val aoiInfoMap = aoiModifyNameInfoMapBroad.value
            val aoiInfoDeleSet = aoiInfoDeleSetBroad.value
            val listBuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val aoi_id = obj.getString("aoi_id")
                if (aoiInfoMap.contains(aoi_id)) {
                    obj.put("aoi_name", aoiInfoMap.get(aoi_id).get)
                    obj.put("modify_type","modify_name")


                }
                if(aoiInfoDeleSet.contains(aoi_id)){
                    obj.put("modify_type","aoi_delete")

                }
                listBuffer += obj
            }
            listBuffer.iterator

        }).filter(x=>StringUtils.nonEmpty(x.getString("modify_type"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记需要清洗的运单数据-》"+modifyNameRdd.count())
        Spark.clearPersistWithoutId(sparkSession,modifyNameRdd.id)

        modifyNameRdd

    }


    def signTraceWifiData(sparkSession:SparkSession,end_date:String,start_date:String,aoiModifyNameInfoMapBroad: Broadcast[Map[String, String]],aoiInfoModifyBoundarySetBroad: Broadcast[Set[String]],aoiInfoDeleSetBroad: Broadcast[Set[String]])={

        var sql=
            s"""
               |
               |
               |select * from dm_gis.dm_wifi_finger_traj_dtl_di where inc_day<='$end_date' and inc_day>='$start_date'
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val df = sparkSession.sql(sql)
        val columns = df.columns
        val dataRdd = df.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getString(i))
            }
            jObj
        })

        val resultRdd = dataRdd.mapPartitions(x => {
            val aoiInfoMap = aoiModifyNameInfoMapBroad.value
            val aoiInfoModifyBoundarySet = aoiInfoModifyBoundarySetBroad.value
            val aoiInfoDeleSet = aoiInfoDeleSetBroad.value
            val listBuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val aoi_id = obj.getString("aoi_id")
                if (aoiInfoMap.contains(aoi_id)) {
                    obj.put("aoi_name", aoiInfoMap.get(aoi_id).get)
                    obj.put("modify_type","modify_name")
                }
                if(aoiInfoModifyBoundarySet.contains(aoi_id)){
                    obj.put("modify_type","modify_boundary")
                }
                if(aoiInfoDeleSet.contains(aoi_id)){
                    obj.put("modify_type","aoi_delete")
                }
                listBuffer += obj
            }
            listBuffer.iterator

        }).filter(x=>StringUtils.nonEmpty(x.getString("modify_type"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记需要清洗的轨迹wifi数据-》"+resultRdd.count())
        Spark.clearPersistWithoutId(sparkSession,resultRdd.id)
        resultRdd

    }


    def modifyWifi(sparkSession:SparkSession,end_day:String,aoiInfoSetBroad: Broadcast[Set[String]],dataRdd:RDD[JSONObject])={

        val needCleanDataRdd = dataRdd.filter(x => {
            val aoiInfoSet = aoiInfoSetBroad.value
            val aoi_id = x.getString("aoi_id")
            if (aoiInfoSet.contains(aoi_id)) {
                true
            } else {
                false
            }


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("修改边界的数据量---》"+needCleanDataRdd.count())

        val notNeedCleanDataRdd = dataRdd.filter(x => {
            val aoiInfoSet = aoiInfoSetBroad.value
            val aoi_id = x.getString("aoi_id")
            if (aoiInfoSet.contains(aoi_id)) {
                false
            } else {
                true
            }


        })

        val judgeAoiDistRdd = needCleanDataRdd.groupBy(x => x.getString("aoi_id")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataListBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataObj = new JSONObject()

            dataObj.put("aoiId", x._1)
            dataObj.put("type", "side")
            var array = new JSONArray()
            for (obj <- x._2) {
                val tmpObj = new JSONObject()
                val lng = obj.getString("lng")
                val lat = obj.getString("lat")
                if(StringUtils.nonEmpty(lng)&&StringUtils.nonEmpty(lat)){
                    tmpObj.put("lng", lng.toDouble)
                    tmpObj.put("lat", lat.toDouble)
                    array.add(tmpObj)
                    dataListBuffer += obj
                }

                if (array.size >= 200) {
                    dataObj.put("coors", array)
                    listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                    dataListBuffer = ListBuffer()
                    array = new JSONArray()
                    dataObj = new JSONObject()
                    dataObj.put("aoiId", x._1)
                    dataObj.put("type", "side")
                }


            }

            if (array.size >= 0) {
                dataObj.put("coors", array)
                listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                dataListBuffer = ListBuffer()
                array = new JSONArray()
                dataObj = new JSONObject()
                dataObj.put("aoiId", x._1)
                dataObj.put("type", "side")
            }
            listBuffer
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("过滤aoi距离不符后，数据量-----》"+judgeAoiDistRdd.count())
        (judgeAoiDistRdd.union(notNeedCleanDataRdd))

    }

    def saveStandardDataToHive(sparkSession:SparkSession,standardRdd:RDD[JSONObject],end_date:String)={

        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveStandardKey.indices) {
            schemaEle.append(StructField(saveStandardKey.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        val rowRdd = standardRdd.map(obj => {
            val row = new ArrayBuffer[String]
            for (i <- saveStandardKey.indices) {
                var tmpStr = JSONUtil.getJsonValSingle(obj, saveStandardKey.apply(i))
                row.append(tmpStr)
            }
            val ret = Row.fromSeq(row)
            ret
        })

        sparkSession.createDataFrame(rowRdd, schema).createOrReplaceTempView("tmp_result")
        logger.error(s"清除数据，分区---》 $end_date")

        logger.error(String.format("alter table dm_gis.dm_tt_waybill_normalization_dtl_di drop partition(inc_day = '%s')", end_date))
        sparkSession.sql(String.format("alter table dm_gis.dm_tt_waybill_normalization_dtl_di drop partition(inc_day = '%s')", end_date))
        var sql_w=
            s"""
              |
              |insert overwrite table dm_gis.dm_tt_waybill_normalization_dtl_di partition(city_code='755',inc_day='$end_date')
              |select
              |waybill_id
              |,waybill_no
              |,emp_code
              |,tm
              |,addr
              |,std_address
              |,eventtype
              |,aoi_id
              |,aoi_name
              |,buildingid
              |,buildingname
              |,x
              |,y
              |,aoi_key
              |,bld_key
              |,province
              |,city
              |,county
              |,town
              |,village
              |,floor
              |,room
              |,reserve1
              |,reserve2
              |,split_info
              |from tmp_result
              |
              |
              |
              |
              |""".stripMargin

        logger.error("存储标准化数据sql---》"+sql_w)
        sparkSession.sql(sql_w)
        logger.error("存储标准化数据完毕")

    }

    def standardDataModifyAoiName(sparkSession:SparkSession,end_date:String,aoiInfoMapBroad: Broadcast[Map[String, String]])={
        var sql=
            s"""
              |
              |
              |select * from dm_gis.dm_tt_waybill_normalization_dtl_di where inc_day='$end_date'
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val resultRdd = dataRdd.mapPartitions(x => {
            val aoiInfoMap = aoiInfoMapBroad.value
            val listBuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val aoi_id = obj.getString("aoi_id")
                if (aoiInfoMap.contains(aoi_id)) {
                    obj.put("aoi_name", aoiInfoMap.get(aoi_id).get)


                }
                listBuffer += obj
            }
            listBuffer.iterator

        })
        resultRdd


    }

    def traceWifiDataModifyAoiName(sparkSession:SparkSession,end_date:String,aoiInfoMapBroad: Broadcast[Map[String, String]])={
        var sql=
            s"""
               |
               |
               |select * from dm_gis.dm_wifi_finger_traj_dtl_di where inc_day='$end_date'
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val resultRdd = dataRdd.mapPartitions(x => {
            val aoiInfoMap = aoiInfoMapBroad.value
            val listBuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val aoi_id = obj.getString("aoi_id")
                if (aoiInfoMap.contains(aoi_id)) {
                    obj.put("aoi_name", aoiInfoMap.get(aoi_id).get)


                }
                listBuffer += obj
            }
            listBuffer.iterator

        })
        resultRdd


    }

    def getModifyAoiInfo(sparkSession:SparkSession,end_day:String,start_day:String)={

        var sql=
            s"""
              |
              |
              |select aoi_id
              |from dm_gis.cms_aoi_change
              |where inc_day between '$start_day' and '$end_day'
              |and oper_type = 'U'
              |and change_type = '1'
              |and status = '6'
              |group by aoi_id
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val aoiInfoSet = dataRdd.map(x => x.getString("aoi_id")).collect().toSet

        sparkSession.sparkContext.broadcast(aoiInfoSet)


    }

    def getModifyNameAoiInfo(sparkSession:SparkSession,end_day:String,start_day:String)={

        var sql=
            s"""
              |
              |
              |select aoi_id,aoi_name from (
              |select aoi_id,get_json_object(`data`,'$$.newAoi.aoiName') as aoi_name,row_number()over(partition by aoi_id order by update_date desc ) as rnk
              |from dm_gis.cms_aoi_change
              |where inc_day between '$start_day' and '$end_day'
              |and oper_type = 'U'
              |and change_type = '3'
              |and status = '6'
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val aoiInfoMap = dataRdd.map(x => (x.getString("aoi_id"),x.getString("aoi_name"))).collect().toMap

        sparkSession.sparkContext.broadcast(aoiInfoMap)


    }

    def getDeleAoiInfo(sparkSession:SparkSession,end_day:String,start_day:String)={
        var sql=
            s"""
              |
              |
              |select aoi_id
              |from dm_gis.cms_aoi_change
              |where inc_day between '$start_day' and '$end_day'
              |and oper_type = 'D'
              |and status = '6'
              |group by aoi_id
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val aoiInfoSet = dataRdd.map(x => x.getString("aoi_id")).collect().toSet

        val dataSet = new mutable.HashSet[String]()
        sparkSession.sparkContext.broadcast(aoiInfoSet)


    }

    def cleanStandardData(sparkSession:SparkSession,end_day:String,aoiInfoSetBroad: Broadcast[Set[String]],end_date:String,dataRdd:RDD[JSONObject])={

        var sql_aoi_info=
            s"""
              |
              |select aoi_id,aoi_name from dm_gis.cms_aoi where inc_day='$end_day' and del_flag='0'
              |
              |""".stripMargin

        val aoiInfoMapBroad =sparkSession.sparkContext.broadcast(SparkRead.readHiveAsJson(sparkSession, sql_aoi_info)._1.map(x => (x.getString("aoi_id"), x.getString("aoi_name"))).collect().toMap)
        val needCleanDataRdd = dataRdd.filter(x => {
            val aoiInfoSet = aoiInfoSetBroad.value
            val aoi_id = x.getString("aoi_id")
            if (aoiInfoSet.contains(aoi_id)) {
                true
            } else {
                false
            }
        })
        val notNeedCleanDataRdd = dataRdd.filter(x => {
            val aoiInfoSet = aoiInfoSetBroad.value
            val aoi_id = x.getString("aoi_id")
            if (aoiInfoSet.contains(aoi_id)) {
                false
            } else {
                true
            }
        })

        val needCleanTransDataRdd = needCleanDataRdd.map(obj => {
            val address = obj.getString("address")
            val city_code = obj.getString("city_code")
            obj.put("req_address", address)
            obj.put("citycode", city_code)
            obj
        })
        val needCleanShouRdd = needCleanTransDataRdd.filter(x => StringUtils.nonEmpty(x.getString("eventtype")) && x.getString("eventtype").equals("31201")).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("需要清洗的收件数据量----》"+needCleanShouRdd.count())
        val needCleanPaiRdd = needCleanTransDataRdd.filter(x => StringUtils.nonEmpty(x.getString("eventtype")) && x.getString("eventtype").equals("31124")).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("需要清洗的派件数据量----》"+needCleanPaiRdd.count())
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01407499", "942107", "wifi指纹库-aoi变更-清洗轨迹wifi", "", "http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr/", "e3c28dd2467f4a5f95778c991d4b28e3", needCleanShouRdd.count(), 20)

        val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession,needCleanShouRdd, SfNetInteface.atOtherInterface, 40, "e3c28dd2467f4a5f95778c991d4b28e3", 2000).map(obj => {
            val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "atRet.result")
            val tcs: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tcs")
            val aoi_id = JSONUtil.getJsonVal(tcs, "aoiid", "")
            obj.put("aoi_id", aoi_id)
            obj.put("aoi_key", aoi_id)
            obj
        })

        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)

        val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01407499", "942107", "ifi指纹库-aoi变更-清洗轨迹wifi", "", "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api/", "e3c28dd2467f4a5f95778c991d4b28e3", needCleanPaiRdd.count(), 20)


        val rzRdd = SparkNetNew.queryRdsPaiZh(sparkSession,needCleanPaiRdd,"e3c28dd2467f4a5f95778c991d4b28e3",40,2000,"citycode","address").map(obj => {
            val aoi_id = JSONUtil.getJsonVal(obj, "rdsPaiZhAoiid", "")
            obj.put("aoi_id", aoi_id)
            obj.put("aoi_key", aoi_id)

            obj
        })

        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId2)


        val cleanOverDataRdd = returnAtRDD.union(rzRdd).map(obj => {
            val aoiInfoMap = aoiInfoMapBroad.value
            val aoi_id = obj.getString("aoi_id")
            val city_code = obj.getString("city_code")
            val addr = obj.getString("addr")
            val tmpobj = new JSONObject()
            tmpobj.put("cityCode", city_code)
            tmpobj.put("address", addr)
            tmpobj.put("aoiId", aoi_id)
            tmpobj.put("requestId", "1")
            obj.put("aoi_name", aoiInfoMap.getOrElse(aoi_id, ""))
            val (buildingid, buildingname, aoiId, x, y) = getInterfaceData(tmpobj)
            if (StringUtils.nonEmpty(aoi_id) && StringUtils.nonEmpty(aoiId) && aoi_id.equals(aoiId)) {
                obj.put("buildingid", buildingid)
                obj.put("buildingname", buildingname)
                obj.put("bld_key",buildingid)
                obj.put("x", x)
                obj.put("y", y)

            }
            obj

        })
        (cleanOverDataRdd.map(x=>(x.getString("waybill_no"),x)),cleanOverDataRdd.union(notNeedCleanDataRdd))



    }

    def cleanAllTypeStandardData(sparkSession:SparkSession,end_day:String,end_date:String)={

        var sql_aoi_info=
            s"""
               |
               |select aoi_id,aoi_name from dm_gis.cms_aoi where inc_day='$end_day' and del_flag='0'
               |
               |""".stripMargin

        val aoiInfoMapBroad =sparkSession.sparkContext.broadcast(SparkRead.readHiveAsJson(sparkSession, sql_aoi_info)._1.map(x => (x.getString("aoi_id"), x.getString("aoi_name"))).collect().toMap)

        var sql=
            s"""
              |
              |select * from dm_gis.dm_wifi_finger_waybill_normalization_aoi_change_di where inc_day='$end_date'
              |
              |
              |""".stripMargin

        val dataRdd = SparkRead.readHiveAsJson(sparkSession, sql)._1

        val needCleanDataRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("modify_type"))&&x.getString("modify_type").equals("aoi_delete"))
        val notNeedCleanDataRdd = dataRdd.filter(x =>(!(StringUtils.nonEmpty(x.getString("modify_type"))&&x.getString("modify_type").equals("aoi_delete"))) )

        val needCleanTransDataRdd = needCleanDataRdd.map(obj => {
            val address = obj.getString("address")
            val city_code = obj.getString("city_code")
            obj.put("req_address", address)
            obj.put("citycode", city_code)
            obj
        })
        val needCleanShouRdd = needCleanTransDataRdd.filter(x => StringUtils.nonEmpty(x.getString("eventtype")) && x.getString("eventtype").equals("31201")).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("需要清洗的收件数据量----》"+needCleanShouRdd.count())
        val needCleanPaiRdd = needCleanTransDataRdd.filter(x => StringUtils.nonEmpty(x.getString("eventtype")) && x.getString("eventtype").equals("31124")).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("需要清洗的派件数据量----》"+needCleanPaiRdd.count())
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01407499", "942107", "wifi指纹库-aoi变更-清洗轨迹wifi", "", "http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr/", "e3c28dd2467f4a5f95778c991d4b28e3", needCleanShouRdd.count(), 20)

        val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(sparkSession,needCleanShouRdd, SfNetInteface.atOtherInterface, 40, "e3c28dd2467f4a5f95778c991d4b28e3", 2000).map(obj => {
            val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "atRet.result")
            val tcs: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tcs")
            val aoi_id = JSONUtil.getJsonVal(tcs, "aoiid", "")
            obj.put("aoi_id", aoi_id)
            obj.put("aoi_key", aoi_id)
            obj
        })

        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)

        val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(sparkSession, "01407499", "942107", "ifi指纹库-aoi变更-清洗轨迹wifi", "", "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api/", "e3c28dd2467f4a5f95778c991d4b28e3", needCleanPaiRdd.count(), 20)


        val rzRdd = SparkNetNew.queryRdsPaiZh(sparkSession,needCleanPaiRdd,"e3c28dd2467f4a5f95778c991d4b28e3",40,2000,"citycode","address").map(obj => {
            val aoi_id = JSONUtil.getJsonVal(obj, "rdsPaiZhAoiid", "")
            obj.put("aoi_id", aoi_id)
            obj.put("aoi_key", aoi_id)

            obj
        })

        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId2)


        val cleanOverDataRdd = returnAtRDD.union(rzRdd).map(obj => {
            val aoiInfoMap = aoiInfoMapBroad.value
            val aoi_id = obj.getString("aoi_id")
            val city_code = obj.getString("city_code")
            val addr = obj.getString("addr")
            val tmpobj = new JSONObject()
            tmpobj.put("cityCode", city_code)
            tmpobj.put("address", addr)
            tmpobj.put("aoiId", aoi_id)
            tmpobj.put("requestId", "1")
            obj.put("aoi_name", aoiInfoMap.getOrElse(aoi_id, ""))
            val (buildingid, buildingname, aoiId, x, y) = getInterfaceData(tmpobj)
            if (StringUtils.nonEmpty(aoi_id) && StringUtils.nonEmpty(aoiId) && aoi_id.equals(aoiId)) {
                obj.put("buildingid", buildingid)
                obj.put("buildingname", buildingname)
                obj.put("bld_key",buildingid)
                obj.put("x", x)
                obj.put("y", y)

            }
            obj

        })
        (cleanOverDataRdd.map(x=>(x.getString("waybill_no"),x)),cleanOverDataRdd.union(notNeedCleanDataRdd))



    }

    def cleanAllTraceWifi(sparkSession:SparkSession,standardCleanDataRdd:RDD[(String,JSONObject)],end_date:String)={

        //dm_wifi_finger_traj_aoi_change_di
        //dm_wifi_finger_traj_aoi_change_di
        var sql=
            s"""
              |
              |
              |select * from dm_gis.dm_wifi_finger_traj_aoi_change_di where inc_day='$end_date'
              |
              |""".stripMargin

        val dataRdd = SparkRead.readHiveAsJson(sparkSession, sql)._1
        val needCleanDataRdd = dataRdd.filter(x =>StringUtils.nonEmpty(x.getString("modify_type"))&&x.getString("modify_type").equals("aoi_delete")).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("aoi删除的数据量---》"+needCleanDataRdd.count())

        val modifyBoundaryRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("modify_type")) && x.getString("modify_type").equals("modify_boundary"))

        val notNeedCleanDataRdd = dataRdd.filter(x =>StringUtils.nonEmpty(x.getString("modify_type")) && x.getString("modify_type").equals("modify_name") )
        val needCleanDataTransformRdd = needCleanDataRdd.map(x => (x.getString("waybill_no"), x)).leftOuterJoin(standardCleanDataRdd).map(x => {

            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.put("aoi_id", rightOp.get.getString("aoi_id"))
                    leftObj.put("aoi_name", rightOp.get.getString("aoi_name"))
                    leftObj.put("lng_bld", rightOp.get.getString("x"))
                    leftObj.put("lat_bld", rightOp.get.getString("y"))
                    leftObj.put("buildingid", rightOp.get.getString("buildingid"))
                    leftObj.put("buildingname", rightOp.get.getString("buildingname"))


                }

            }

            leftObj

        })


        val judgeDistOver50Rdd = needCleanDataTransformRdd.map(obj => {
            val lng = obj.getString("lng")
            val lat = obj.getString("lat")
            val lng_bld = obj.getString("lng_bld")
            val lat_bld = obj.getString("lat_bld")
            var tag = ""
            var bld_flag = "false"
            if (StringUtils.nonEmpty(lng) && StringUtils.nonEmpty(lat) && StringUtils.nonEmpty(lng_bld) && StringUtils.nonEmpty(lat_bld)) {
                val bld_cntr_dist = GeometryUtil.getDistance(lng, lat, lng_bld, lat_bld)
                if (bld_cntr_dist != null)
                    obj.put("bld_cntr_dist", bld_cntr_dist.toString)
                if (bld_cntr_dist > 50.0) {
                    bld_flag = "true"
                    tag = "无上门行为"
                } else {
                    tag = ""
                }
            }
            obj.put("bld_flag", bld_flag)
            obj.put("tag", tag)
            obj
        })

        val fliterDistOver50Rdd=judgeDistOver50Rdd.union(modifyBoundaryRdd).filter(x=>StringUtils.nonEmpty(x.getString("tag"))&&x.getString("tag").equals("无上门行为"))
        val Distless50Rdd = judgeDistOver50Rdd.filter(x => (!(StringUtils.nonEmpty(x.getString("tag")) && x.getString("tag").equals("无上门行为"))))

        val judgeAoiDistRdd = Distless50Rdd.groupBy(x => x.getString("aoi_id")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataListBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataObj = new JSONObject()

            dataObj.put("aoiId", x._1)
            dataObj.put("type", "side")
            var array = new JSONArray()
            for (obj <- x._2) {
                val tmpObj = new JSONObject()
                val lng = obj.getString("lng")
                val lat = obj.getString("lat")
                if(StringUtils.nonEmpty(lng)&&StringUtils.nonEmpty(lat)){
                    tmpObj.put("lng", lng.toDouble)
                    tmpObj.put("lat", lat.toDouble)
                    array.add(tmpObj)
                    dataListBuffer += obj
                }

                if (array.size >= 200) {
                    dataObj.put("coors", array)
                    listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                    dataListBuffer = ListBuffer()
                    array = new JSONArray()
                    dataObj = new JSONObject()
                    dataObj.put("aoiId", x._1)
                    dataObj.put("type", "side")
                }


            }

            if (array.size >= 0) {
                dataObj.put("coors", array)
                listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                dataListBuffer = ListBuffer()
                array = new JSONArray()
                dataObj = new JSONObject()
                dataObj.put("aoiId", x._1)
                dataObj.put("type", "side")
            }
            listBuffer
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("过滤aoi距离不符后，数据量-----》"+judgeAoiDistRdd.count())

        judgeAoiDistRdd.union(notNeedCleanDataRdd).union(fliterDistOver50Rdd)


    }

    def cleanTraceWifi(sparkSession:SparkSession,end_day:String,aoiInfoSetBroad: Broadcast[Set[String]],standardCleanDataRdd:RDD[(String,JSONObject)],dataRdd:RDD[JSONObject])={


        val needCleanDataRdd = dataRdd.filter(x => {
            val aoiInfoSet = aoiInfoSetBroad.value
            val aoi_id = x.getString("aoi_id")
            if (aoiInfoSet.contains(aoi_id)) {
                true
            } else {
                false
            }


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("aoi删除的数据量---》"+needCleanDataRdd.count())

        val notNeedCleanDataRdd = dataRdd.filter(x => {
            val aoiInfoSet = aoiInfoSetBroad.value
            val aoi_id = x.getString("aoi_id")
            if (aoiInfoSet.contains(aoi_id)) {
                false
            } else {
                true
            }


        })
        val needCleanDataTransformRdd = needCleanDataRdd.map(x => (x.getString("waybill_no"), x)).leftOuterJoin(standardCleanDataRdd).map(x => {

            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.put("aoi_id", rightOp.get.getString("aoi_id"))
                    leftObj.put("aoi_name", rightOp.get.getString("aoi_name"))
                    leftObj.put("lng_bld", rightOp.get.getString("x"))
                    leftObj.put("lat_bld", rightOp.get.getString("y"))
                    leftObj.put("buildingid", rightOp.get.getString("buildingid"))
                    leftObj.put("buildingname", rightOp.get.getString("buildingname"))


                }

            }

            leftObj

        })


        val judgeDistOver50Rdd = needCleanDataTransformRdd.map(obj => {
            val lng = obj.getString("lng")
            val lat = obj.getString("lat")
            val lng_bld = obj.getString("lng_bld")
            val lat_bld = obj.getString("lat_bld")
            var tag = ""
            var bld_flag = "false"
            if (StringUtils.nonEmpty(lng) && StringUtils.nonEmpty(lat) && StringUtils.nonEmpty(lng_bld) && StringUtils.nonEmpty(lat_bld)) {
                val bld_cntr_dist = GeometryUtil.getDistance(lng, lat, lng_bld, lat_bld)
                if (bld_cntr_dist != null)
                    obj.put("bld_cntr_dist", bld_cntr_dist.toString)
                if (bld_cntr_dist > 50.0) {
                    bld_flag = "true"
                    tag = "无上门行为"
                } else {
                    tag = ""
                }
            }
            obj.put("bld_flag", bld_flag)
            obj.put("tag", tag)
            obj
        })

        val fliterDistOver50Rdd=judgeDistOver50Rdd.filter(x=>StringUtils.nonEmpty(x.getString("tag"))&&x.getString("tag").equals("无上门行为"))
        val Distless50Rdd = judgeDistOver50Rdd.filter(x => (!(StringUtils.nonEmpty(x.getString("tag")) && x.getString("tag").equals("无上门行为"))))

        val judgeAoiDistRdd = Distless50Rdd.groupBy(x => x.getString("aoi_id")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataListBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataObj = new JSONObject()

            dataObj.put("aoiId", x._1)
            dataObj.put("type", "side")
            var array = new JSONArray()
            for (obj <- x._2) {
                val tmpObj = new JSONObject()
                val lng = obj.getString("lng")
                val lat = obj.getString("lat")
                if(StringUtils.nonEmpty(lng)&&StringUtils.nonEmpty(lat)){
                    tmpObj.put("lng", lng.toDouble)
                    tmpObj.put("lat", lat.toDouble)
                    array.add(tmpObj)
                    dataListBuffer += obj
                }

                if (array.size >= 200) {
                    dataObj.put("coors", array)
                    listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                    dataListBuffer = ListBuffer()
                    array = new JSONArray()
                    dataObj = new JSONObject()
                    dataObj.put("aoiId", x._1)
                    dataObj.put("type", "side")
                }


            }

            if (array.size >= 0) {
                dataObj.put("coors", array)
                listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                dataListBuffer = ListBuffer()
                array = new JSONArray()
                dataObj = new JSONObject()
                dataObj.put("aoiId", x._1)
                dataObj.put("type", "side")
            }
            listBuffer
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("过滤aoi距离不符后，数据量-----》"+judgeAoiDistRdd.count())

        judgeAoiDistRdd.union(notNeedCleanDataRdd).union(fliterDistOver50Rdd)


    }


    def getInterfaceData(parm:JSONObject)={

        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak","d4c3a0f6ed0044df8c1e4f0cc1dbfe6f")

        var build_err_msg="调用新楼栋服务接口"

        Thread.sleep(20)
        var jSONObject = try {

            JSON.parseObject(HttpUtils.postJson(poiUrl, parm, stringToString))
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+parm.toString())
                build_err_msg=e.toString
                new JSONObject()
            }
        }

        val buildingid = JSONUtil.getJsonVal(jSONObject, "result.data.buildingId", "")
        val buildingname = JSONUtil.getJsonVal(jSONObject, "result.data.buildingName", "")
        val x = JSONUtil.getJsonVal(jSONObject, "result.data.x", "")
        val y = JSONUtil.getJsonVal(jSONObject, "result.data.y", "")
        val aoiId = JSONUtil.getJsonVal(jSONObject, "result.data.aoiId", "")
        if(!jSONObject.isEmpty){
            build_err_msg=jSONObject.toString()
        }

        (buildingid,buildingname,aoiId,x,y)




    }

    def getCoorAoiDist(dataList:ListBuffer[JSONObject],parmObj:JSONObject)={

        var nowHour = getHour()

        if(!(nowHour>=21||(nowHour>=0&&nowHour<9))){
            Thread.sleep(480)
        }else{
            Thread.sleep(240)
        }
        val listBuffer: ListBuffer[JSONObject] = ListBuffer()
        val resultSet=new mutable.HashSet[JSONObject]()
        var jSONObject=new JSONObject()
        jSONObject = try {
            //            Thread.sleep(50)
            HttpUtils.urlConnectionPostJson(aoiCoorsDist,parmObj.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+parmObj.toString())
                val stackTraceElement = e.getStackTrace()(0)
                logger.error("系统出错，错误信息:"+e.toString()+" at "+stackTraceElement.getClassName()+"."+stackTraceElement.getMethodName()+":"+stackTraceElement.getLineNumber())
                null
            }
        }


        if(jSONObject!=null){
            //            logger.error("respone data------->"+jSONObject.toString())
            val dataArr = JSONUtil.getJsonArrayFromObject(jSONObject, "data.coors")
            for(i <- 0 until dataArr.size){
                val nObject = dataArr.getJSONObject(i)
                val lng=nObject.getString("lng")
                val lat=nObject.getString("lat")
                val dist=nObject.getString("dist")
                for(j <- 0 until dataList.size){
                    val dataObj = dataList(j)
                    val dataLng=dataObj.getString("lng")
                    val dataLat=dataObj.getString("lat")
                    if(lng!=null&&dataLng!=null&&lat!=null&&dataLat!=null&&lng.equals(dataLng)&&lat.equals(dataLat)){
                        if(StringUtils.nonEmpty(dist)&&dist.toDouble<=10.0){
                            dataObj.put("aoi_side_dist",dist)
                            dataObj.put("tag","")
                        }else if(StringUtils.nonEmpty(dist)&&dist.toDouble>10.0){
                            dataObj.put("tag","aoi距离超过10m")
                        }
                    }else{
                        dataObj.put("tag","")

                    }
                    dataObj.put("aoi_interface_data",jSONObject)
                    listBuffer+=dataObj
                    //                    dataObj.put("village",jSONObject)
                    //                    listBuffer+=dataObj
                }
            }
        }
        listBuffer
    }

}
