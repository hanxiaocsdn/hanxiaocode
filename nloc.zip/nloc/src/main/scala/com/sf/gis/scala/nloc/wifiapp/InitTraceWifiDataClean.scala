package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-12-25 19:07
 * @TaskId:953453
 * @TaskName:初始化-轨迹wifi-清洗轨迹wifi数据
 * @Description:
 */

object InitTraceWifiDataClean {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveErrorAoiKey=Array("error_wifi","aoi_key")

//    val saveErrorAoiKey=Array("error_wifi","error_finger_aoi","error_finger_bld","error_finger_detail","isWifiAllError")

    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","address")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","buildingname","address")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","buildingid","aoi_id","lng","lat","city_code","province","city","county","town","village","decrypt_wifi")
    val saveDetailKey=Array("key","wifi_list","upper_key","floor","room","level","buildingid","bld_key","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","buildingname","address")
    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("清洗aoi数据")
        val aoiResultRdd = cleanAoiData(sparkSession)
        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, aoiResultRdd, saveAoiKey, "dm_gis.dm_wifi_finger_traj_aoi_dtl",null, 25)
        Spark.clearAllPersist(sparkSession)

        logger.error("清洗detail数据")
        val detailResultRdd = cleanDetailData(sparkSession)
        logger.error("存储 wifi detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, detailResultRdd, saveDetailKey, "dm_gis.dm_wifi_finger_traj_detail_dtl",null, 25)




    }



    def cleanAoiData(spark:SparkSession)={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_traj_aoi_dtl
              |
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val fliterErrorWifiList = dataRdd.map(obj => {

            val dataObj = new JSONObject()
            dataObj.fluentPutAll(obj)
            try {
                val aoi_key = obj.getString("aoi_key")
                val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
                val wifiArr = new JSONArray()
                for (i <- 0 until (wifi_list.size())) {
                    val num = wifi_list.getJSONObject(i).getString("num").toLong
                    if(wifi_list.size()>10000){
                        if (num > 1L) {
                            wifiArr.add(wifi_list.getJSONObject(i))

                        }
                    }else{
                        wifiArr.add(wifi_list.getJSONObject(i))

                    }
                }

                dataObj.put("wifi_list", wifiArr.toString)

            } catch {
                case e: Exception => logger.error(e.toString)
            }

            dataObj

        })



        fliterErrorWifiList

    }




    def cleanDetailData(spark:SparkSession)={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_traj_detail_dtl where upper_key<>''
              |
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val fliterErrorWifiList = dataRdd.map(obj => {

            val dataObj = new JSONObject()
            dataObj.fluentPutAll(obj)
            try {
                val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
                val wifiArr = new JSONArray()
                for (i <- 0 until (wifi_list.size())) {
                    val num = wifi_list.getJSONObject(i).getString("num").toLong
                    if(wifi_list.size()>10000){
                        if (num > 1L) {
                            wifiArr.add(wifi_list.getJSONObject(i))
                        }
                    }else{
                        wifiArr.add(wifi_list.getJSONObject(i))

                    }

                }

                dataObj.put("wifi_list", wifiArr.toString)

            } catch {
                case e: Exception => logger.error(e.toString)
            }

            dataObj

        })
        fliterErrorWifiList

    }
    def getMd5Key(addr:String)={
        var resultMd5Str=""
        if(addr!=null&&addr.nonEmpty){
            val md5addr = MD5Util.getMD5(addr)
            resultMd5Str=md5addr.toLowerCase.substring(8, 24)
        }
        resultMd5Str

    }


}
