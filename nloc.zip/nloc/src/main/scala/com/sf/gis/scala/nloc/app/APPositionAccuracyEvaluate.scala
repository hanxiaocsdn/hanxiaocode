package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DesUtils, GeometryUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.nio.charset.StandardCharsets
import scala.collection.mutable.ListBuffer


/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-12-26 14:40
 * @TaskId:954038
 * @TaskName:AP库精度线上评测
 * @Description:
 */

object APPositionAccuracyEvaluate {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val positionUrl="http://gis-apis.int.sfcloud.local:1080/nloc/locationapi?ak=7b7ed052abe94c4fb6a4d940201956ce&param=%s"
    val saveKey=Array("id","un","tp","zx","zy","ac","ad","sl","tm","cr","dx","dy","ak","bn","xh","time_stamp","ewl","accuracy","validity","longitude","latitude","dis","position_flag")

    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val end_day=args(0)
        val resultRdd = evaluate(sparkSession, end_day)
        logger.error("存储网点wifi中间数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_wifi_finger_ap_gps_combination_di",Array(("inc_day", end_day)), 25)


    }

    def evaluate(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select * from tmp_dm_gis.dm_wifi_finger_ap_gps_combination_di where inc_day='$end_day' and un !='test20170308' and ac<100
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            val desUtil = new DesUtils
            for (obj <- x) {
                try {
                    val ewl = obj.getString("ewl")
                    val zx = obj.getString("zx")
                    val zy = obj.getString("zy")
                    val paramObj = new JSONObject()
                    val wifilist = new JSONArray()
                    val celltowers = new JSONArray()
                    paramObj.put("appCerSha1", "D2:81:52:F9:30:B6:70:D6:67:AA:AC:14:D7:14:1B:10:31:7C:56:81")
                    paramObj.put("appPackageName", "com.sfmap.api.location.demo")
                    paramObj.put("celltowers", celltowers)
                    paramObj.put("gcj02", 1)
                    paramObj.put("netType", 0)
                    paramObj.put("opt", 1)
                    //                    paramObj.put("r", 0)
                    var ewl_num = 0L
                    var position_flag = "-1"

                    val tmp = new JSONObject()
                    tmp.fluentPutAll(obj)
                    if (ewl != null) {
                        val ewlArray = JSON.parseArray(ewl)
                        for (i <- 0 until ewlArray.size()) {
                            val tmpObj = new JSONObject()
                            val ewlObj = ewlArray.getJSONObject(i)
                            val ss = JSONUtil.getJsonVal(ewlObj, "ss", "")
                            if (StringUtils.nonEmpty(ss)) {
                                tmpObj.put("singalstrength", ss.toInt)
                            } else {
                                tmpObj.put("singalstrength", -30)
                            }
                            tmpObj.put("macaddress", JSONUtil.getJsonVal(ewlObj, "mac", ""))

                            tmpObj.put("time", 0)
                            wifilist.add(tmpObj)

                        }
                    }

                    paramObj.put("wifilist", wifilist)
                    ewl_num = 0L
                    val param = desUtil.encrypt(paramObj.toString, StandardCharsets.UTF_8.toString())
                    val (longitude, latitude, accuracy, validity) = positionEvaluate(param, desUtil)


                    if (StringUtils.nonEmpty(zx) && StringUtils.nonEmpty(zy) && StringUtils.nonEmpty(longitude) && StringUtils.nonEmpty(latitude)) {
                        val dis = GeometryUtil.getDistance(zx, zy, longitude, latitude)
                        if (dis <= 20.0 && dis >= 0.0) {
                            position_flag = "1"
                        } else if (dis > 20.0 && dis <= 1000.0) {
                            position_flag = "0"
                        }
                        tmp.put("dis", dis)
                        tmp.put("position_flag", position_flag)

                    }

                    tmp.put("longitude", longitude)
                    tmp.put("latitude", latitude)
                    tmp.put("accuracy", accuracy)
                    tmp.put("validity", validity)
                    listbuffer += tmp

                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                    }
                }


            }


            listbuffer.iterator


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调接口数据量---》"+resultRdd.count())
//        Thread.sleep(1000000)
        resultRdd

    }

    def positionEvaluate(param:String,desUtils:DesUtils)={
        val url=String.format(positionUrl,param)

        var longitude = ""
        var latitude = ""
        var accuracy = ""
        var validity = ""

        //接口访问限制 每分钟50000
        Thread.sleep(40)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error url-----> "+url)
                logger.error("error reason-----> "+e.toString)
                validity=e.toString
                null
            }
        }



        try{
            val resultStr=desUtils.decrypt(JSONUtil.getJsonVal(jSONObject, "result.msg", ""), StandardCharsets.UTF_8.toString())
            val resultObj = JSONUtil.parseJSONObject(resultStr)
            longitude = JSONUtil.getJsonVal(resultObj, "location.longitude", "")
            latitude = JSONUtil.getJsonVal(resultObj, "location.latitude", "")
            accuracy = JSONUtil.getJsonVal(resultObj, "location.accuracy", "")
            validity = JSONUtil.getJsonVal(resultObj, "location.validity", "")
//            accuracy=resultStr

        }catch {case e:Exception=>{
            logger.error(e.toString)
            accuracy=e.toString

        }}

        (longitude,latitude,accuracy,validity)



    }

}
