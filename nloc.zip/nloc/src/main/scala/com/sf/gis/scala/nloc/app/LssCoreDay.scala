package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager:01394382 张萍
 * @Author: 01374443 张想远 (单天赐代码改造)
 * @CreateTime: 2023-03-03 14:06
 * @TaskId:436883,436881
 * @TaskName:LssCellNrDay,LssCellLteDay
 * @Description: 基站类数据统计
 */
object LssCoreDay {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  var partition = 5

  val cell_cdma_table = "dm_gis.gis_lss_core_cell_cdma"
  val cell_gsm_table = "dm_gis.gis_lss_core_cell_gsm"
  val cell_wcdma_table = "dm_gis.gis_lss_core_cell_wcdma"
  val cell_lte_table = "dm_gis.gis_lss_core_cell_lte"
  val cell_nr_table = "dm_gis.gis_lss_core_cell_nr"
  val suffix = "_grouped"

  def main(args: Array[String]): Unit = {
    val mode = args(1)
    if (!StringUtils.isEmpty(mode) && "wifi,cdma,gsm,wcdma,lte,nr".split(",").contains(mode)) {
      logger.error(">>>处理类型：" + mode)

      val date = args(0)
      logger.error(">>>处理日期：" + date)
      val sparkSession = Spark.getSparkSession(appName)
      stat(sparkSession, mode, getTableName(mode), date)
      logger.error(">>>处理完毕---------------")
    }
  }

  def getStructs(mode: String) = {
    mode match {
      case "cdma" => Array("asulevel", "level", "nid", "tp", "dbm", "sid", "mevdosnr", "carriername", "mevdodbm", "mevdoecio", "bid", "mcdmadbm", "mcdmaecio", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "xys", "new_id")
      case "gsm" => Array("mnc", "asulevel", "level", "bsic", "tp", "mcc", "arfcn", "dbm", "lac", "carriername", "cid", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "xys", "new_id")
      case "wcdma" => Array("psc", "mnc", "asulevel", "level", "tp", "mcc", "dbm", "lac", "carriername", "uarfcn", "cid", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "xys", "new_id")
      case "lte" => Array("mnc", "asulevel", "level", "ci", "tp", "mcc", "dbm", "carriername", "tac", "pci", "earfcn", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "xys", "new_id")
      case "nr" => Array("sssinr", "asulevel", "level", "csisinr", "ssrsrp", "tp", "csirsrp", "csirsrq", "dbm", "carriername", "nci", "tac", "pci", "ssrsrq", "nrarfcn", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "mnc", "mcc", "xys", "new_id")
    }
  }

  def getTableName(mode: String) = {
    mode match {
      case "cdma" => cell_cdma_table
      case "gsm" => cell_gsm_table
      case "wcdma" => cell_wcdma_table
      case "lte" => cell_lte_table
      case "nr" => cell_nr_table
    }
  }


  def getId(mode: String, dataJson: JSONObject) = {
    mode match {
      case "cdma" => getCdmaId(dataJson)
      case "gsm" => getGsmId(dataJson)
      case "wcdma" => getWcdmaId(dataJson)
      case "lte" => getLteId(dataJson)
      case "nr" => getNrId(dataJson)
    }
  }

  def stat(sparkSession: SparkSession, mode: String, table: String, date: String): Unit = {
    val month = date.substring(4, 6).toInt
    val (startDate, endDate) = DateUtil.getMonthDate(date.substring(0, 4), month.toString)
    logger.error(">>>开始处理 " + table + ", 日期：" + date + " , 月份：" + month + " , 范围：" + startDate + " - " + endDate)
    val groupedRdd = getData(sparkSession, startDate, endDate, date, table, mode)
    val result_table = table + suffix
    filterRddToHive(sparkSession, groupedRdd, result_table, date, mode)
    groupedRdd.unpersist()
  }


  def getData(sparkSession: SparkSession, startDate: String, endDate: String,
              date: String, table: String, mode: String) = {
    var sql = ""
    sql =
      s"""
         |select * from $table where inc_day='$date' and from_unixtime(bigint(tm/1000),'yyyyMMdd') between '$startDate' and '$endDate'
       """.stripMargin
    val logRdd = getValidJson(sparkSession, sql)
    val groupedRdd = logRdd.map(json => {
      val id = getId(mode, json)
      (id, json)
    }).filter(obj => !StringUtils.isEmpty(obj._1))
      .groupByKey()
      .map(obj => {
        val id = obj._1
        val jsonList = obj._2.toList.sortBy(j => j.getString("timestamp")).reverse
        val firstJson = jsonList.head
        val xys: JSONArray = new JSONArray()
        for (i <- jsonList.indices) {
          val tmpJson = jsonList(i)
          var x = tmpJson.getDouble("x")
          var y = tmpJson.getDouble("y")
          if (x != null && y != null) {
            val tempA = new JSONArray()
            tempA.add(x)
            tempA.add(y)
            xys.add(tempA)
          }
        }
        firstJson.put("new_id", id)
        if (xys.size() > 0) firstJson.put("xys", xys)
        firstJson
      }).persist()

    logger.error(">>>日志量：" + groupedRdd.count())
    logRdd.unpersist()
    groupedRdd
  }

  val array1 = Array("2147483647", "268435455", "65535")
  val array2 = Array("0", "-1")


  def getCdmaId(json: JSONObject): String = {
    var id = ""
    if (json != null) {
      var sid = json.getString("sid")
      var nid = json.getString("nid")
      var bid = json.getString("bid")
      if (StringUtils.isEmpty(sid)) sid = "-"
      if (StringUtils.isEmpty(nid)) nid = "-"
      if (StringUtils.isEmpty(bid)) bid = "-"

      if (array1.contains(sid)) id = ""
      else if (array1.contains(nid)) id = ""
      else if (array1.contains(bid)) id = ""
      else if ("0".equalsIgnoreCase(nid) && array2.contains(bid)) id = ""
      else id = sid + "_" + nid + "_" + bid
    }
    id
  }


  def getGsmId(json: JSONObject): String = {
    var id = ""
    if (json != null) {
      var mcc = json.getString("mcc")
      var mnc = json.getString("mnc")
      var lac = json.getString("lac")
      var cid = json.getString("cid")
      if (StringUtils.isEmpty(mcc)) mcc = "-"
      if (StringUtils.isEmpty(mnc)) mnc = "-"
      if (StringUtils.isEmpty(lac)) lac = "-"
      if (StringUtils.isEmpty(cid)) cid = "-"

      if (array1.contains(mcc)) id = ""
      else if (array1.contains(mnc)) id = ""
      else if (array1.contains(lac)) id = ""
      else if (array1.contains(cid)) id = ""
      else if ("0".equalsIgnoreCase(lac) && array2.contains(cid)) id = ""
      else id = mcc + "_" + mnc + "_" + lac + "_" + cid
    }
    id
  }


  def getWcdmaId(json: JSONObject): String = {
    var id = ""
    if (json != null) {
      var mcc = json.getString("mcc")
      var mnc = json.getString("mnc")
      var lac = json.getString("lac")
      var cid = json.getString("cid")
      if (StringUtils.isEmpty(mcc)) mcc = "-"
      if (StringUtils.isEmpty(mnc)) mnc = "-"
      if (StringUtils.isEmpty(lac)) lac = "-"
      if (StringUtils.isEmpty(cid)) cid = "-"

      if (array1.contains(mcc)) id = ""
      else if (array1.contains(mnc)) id = ""
      else if (array1.contains(lac)) id = ""
      else if (array1.contains(cid)) id = ""
      else if ("0".equalsIgnoreCase(lac) && array2.contains(cid)) id = ""
      else id = mcc + "_" + mnc + "_" + lac + "_" + cid
    }
    id
  }


  def getLteId(json: JSONObject): String = {
    var id = ""
    if (json != null) {
      var mcc = json.getString("mcc")
      var mnc = json.getString("mnc")
      var tac = json.getString("tac")
      var ci = json.getString("ci")
      if (StringUtils.isEmpty(mcc)) mcc = "-"
      if (StringUtils.isEmpty(mnc)) mnc = "-"
      if (StringUtils.isEmpty(tac)) tac = "-"
      if (StringUtils.isEmpty(ci)) ci = "-"

      if (array1.contains(mcc)) id = ""
      else if (array1.contains(mnc)) id = ""
      else if (array1.contains(tac)) id = ""
      else if (array1.contains(ci)) id = ""
      else if ("0".equalsIgnoreCase(tac) && array2.contains(ci)) id = ""
      else id = mcc + "_" + mnc + "_" + tac + "_" + ci
    }
    id
  }


  def getNrId(json: JSONObject): String = {
    var id = ""
    if (json != null) {
      var mcc = json.getString("mcc")
      var mnc = json.getString("mnc")
      var tac = json.getString("tac")
      var nci = json.getString("nci")
      if (StringUtils.isEmpty(mcc)) mcc = "-"
      if (StringUtils.isEmpty(mnc)) mnc = "-"
      if (StringUtils.isEmpty(tac)) tac = "-"
      if (StringUtils.isEmpty(nci)) nci = "-"

      if (array1.contains(mcc)) id = ""
      else if (array1.contains(mnc)) id = ""
      else if (array1.contains(tac)) id = ""
      else if (array1.contains(nci)) id = ""
      else if ("0".equalsIgnoreCase(tac) && array2.contains(nci)) id = ""
      if (!"2147483647".equalsIgnoreCase(tac)) id = mcc + "_" + mnc + "_" + tac + "_" + nci
    }
    id
  }

  def getValidJson(sparkSession: SparkSession, sql: String) = {
    logger.error("sql=" + sql)
    val df = sparkSession.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.get(i))
      }
      json
    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>日志量：" + logRdd.count())
    logRdd
  }

  def getSavePartition(mode: String) = {
    mode match {
      case "cdma" => 5
      case "gsm" => 10
      case "wcdma" => 5
      case "lte" => 40
      case "nr" => 5
    }
  }

  def filterRddToHive(sparkSession: SparkSession, resultRdd: RDD[JSONObject],
                      table: String, date: String, mode: String): Unit = {
    val structs = getStructs(mode)
    logger.error(s"写入表：${table}")
    SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, structs, table,
      Array(("inc_day", date)), getSavePartition(mode))
  }
}
