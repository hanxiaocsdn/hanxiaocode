package com.sf.gis.scala.nloc.utils

import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.{Calendar, Date}

//import com.sf.address.acf.bdp.utils.FileUtil
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

import scala.sys.process._

object GeoUtil {
  var sc: SparkContext = null
  var spark: SparkSession = null
  var defaultPartitionSize = 100

  val COLUMN_FAMILY = "d" //列族
  val ROWKEY_SPLIT = "|"
  val PREFIX_SPLIT = "_"
  val hashMode = 20
  val compl = "0"
  val hiveData = "3rd"


  def defaultSparkConf() = {
    System.setProperty("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    val conf = new SparkConf()

        .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
        .set("spark.port.maxRetries", "100")
        .set("spark.driver.maxResultSize", "12g")
        .set("spark.rpc.io.backLog", "10000")
        .set("spark.cleaner.referenceTracking.blocking", "false")
        .set("spark.streaming.stopGracefullyOnShutdown", "true")
        .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
        .set("spark.driver.allowMultipleContexts", "true")
        .set("spark.sql.tungsten.enabled", "false")
        .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
        .set("quota.consumer.default", (10485760 * 2).toString)
        .set("cache.max.bytes.buffering", (20485760 * 2).toString)
        .set("spark.sql.broadcastTimeout", "36000")
        .set("spark.network.timeout", "30001")
        .set("spark.executor.heartbeatInterval", "30000")
        .set("hive.exec.dynamic.partition", "true")
        .set("hive.exec.dynamic.partition.mode", "nonstrict")
        .set("spark.sql.result.partition.ratio","1")
        .set("spark.executor.extraJavaOptions", "-XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
        .set("spark.driver.extraJavaOptions", "-XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
        .set("hive.vectorized.execution.enabled","false")
        .set("hive.vectorized.execution.reduce.enabled","false")
        .set("spark.hive.mapred.supports.subdirectories","true")
        .set("spark.hadoop.mapreduce.input.fileinputformat.input.dir.recursive","true")


//      .set("dfs.client.read.shortcircuit", "false")
//      .set("spark.speculation", "false")
//      .set("spark.sql.crossJoin.enabled", "true")
//      .set("spark.eventQueue.size", "1000000")
//      .set("spark.event.listener.logEnable", "true")
//      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
//      .set("spark.kryoserializer.buffer.max", "2047m")
//      .set("spark.network.timeout", "600")
//      .set("spark.executor.memoryOverhead", "8192")
//      .set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=12288M")
//      .set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit -XX:PermSize=256M -XX:MaxPermSize=12288M")
//      .set("spark.rpc.askTimeout", "120")
//      .set("spark.port.maxRetries", "999")
//      .set("spark.driver.maxResultSize", "128g")
//      .set("spark.rpc.io.backLog", "10000")
//      .set("spark.cleaner.referenceTracking.blocking", "false")
//      .set("hive.execution.engine", "mr")
//      .set("spark.streaming.stopGracefullyOnShutdown", "true")
//      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
//      .set("spark.driver.allowMultipleContexts", "true")
//      .set("spark.sql.tungsten.enabled", "false")
//      .set("mapreduce.map.log.level", "ERROR")
//      .set("mapreduce.reduce.log.level", "ERROR")
//      .set("yarn.nodemanager.pmem-check-enabled", "false")
//      .set("yarn.nodemanager.vmem-check-enabled", "false")
    //      .set("spark.yarn.executor.memoryOverhead","71680")
    conf
  }

  def initSpark(appName: String = this.getClass.getSimpleName, initConf: SparkConf = null): SparkSession = {
    val conf = if (initConf == null) defaultSparkConf().setAppName(appName) else initConf.setAppName(appName)

    spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    sc = spark.sparkContext
    sc.setLogLevel("ERROR")
    defaultPartitionSize = sc.getConf.get("spark.executor.instances", "16").toInt * sc.getConf.get("spark.executor.cores", "2").toInt * 2
    println("spark.executor.instances is " + sc.getConf.get("spark.executor.instances", "16"))
    println("spark.executor.cores is " + sc.getConf.get("spark.executor.cores", "2"))
//    spark.sql("set dfs.client.read.shortcircuit=false")
//    spark.sql("set spark.sql.thriftserver.scheduler.pool=spark")
//    spark.sql("set mapred.max.split.size=1000000000")
//    spark.sql("set mapred.min.split.size.per.node=1000000000")
//    spark.sql("set mapred.min.split.size.per.rack=1000000000")
//    spark.sql("set hive.fetch.task.conversion=more")
//    spark.sql("set hive.cli.print.header=true")
//    spark.sql("set hive.execution.engine=mr")
//    spark.sql("set hive.exec.mode.local.auto=false")
//    spark.sql("set hive.exec.reducers.max=500")
//    spark.sql("set hive.exec.compress.output=false")
//    spark.sql("set hive.exec.compress.intermediate=true")
//    spark.sql("set hive.exec.dynamic.partition=true")
//    spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
//    spark.sql("set hive.exec.max.dynamic.partitions=100000")
//    spark.sql("set hive.exec.max.dynamic.partitions.pernode=100000")
//    spark.sql("set hive.groupby.skewindata=true")
//    spark.sql("set hive.auto.convert.join=true")
//    spark.sql("set hive.metastore.schema.verification=false")
//    spark.sql("set hive.input.format=org.apache.Hadoop.hive.ql.io.CombineHiveInputFormat")
//    spark.sql("set hive.merge.mapfiles=true")
//    spark.sql("set hive.merge.mapredfiles=true")
//    spark.sql("set hive.merge.size.per.task=1000000000")
//    spark.sql("set hive.merge.smallfiles.avgsize=1000000000")
//    spark.sql("set spark.sql.shuffle.partitions=50")
//    spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
//    spark.sql("set hive.exec.dynamici.partition=true")
    //sc.hadoopConfiguration.set("fs.defaultFS", "hdfs://sfbd")
    scala.sys.addShutdownHook {
      stopSpark()
    }
    spark
  }

  def stopSpark(): Unit = {
    try {
      sc.stop()
      spark.stop()
      //      if(sc!=null && !sc.isStopped ){
      //        sc.stop()
      //        sc = null
      //      }
    } catch {
      case e: Exception => {
        //        e.printStackTrace(System.err)
      }
    }
  }

  def freeMem(keep: RDD[_]*): Unit = {
    GeoUtil.spark.catalog.clearCache()
    var cnt = 0 //Util.spark.sparkContext.getPersistentRDDs.size
    //System.err.println("----------------------------------------【清除缓存RDD开始】------------------------------------------")
    GeoUtil.spark.sparkContext.getPersistentRDDs.foreach(d => {
      //System.err.println("清除缓存RDD："+d._2.toString())
      if (keep.isEmpty || !keep.contains(d._2)) {
        d._2.unpersist()
        cnt += 1
      }
    })
    System.gc()
    //System.err.println("----------------------------------------【清除缓存RDD完成】------------------------------------------")
    System.err.println(s"【清除缓存RDD数量：${cnt}】")
  }

  def unpersistUnuse(rddString: Set[String]) = {
    var persistRdds = GeoUtil.spark.sparkContext.getPersistentRDDs
    persistRdds.foreach(truple => {
      val xx = truple._2.toString()
      val ddd = rddString
      if (!rddString.contains(truple._2.toString())) {
        truple._2.unpersist()
      }
    })
  }


  var t0 = 0l
  var t0Total = 0l

  def memTime() = {
    t0 = new Date().getTime
  }

  def showCost(title: String = "") = {
    //    System.err.println(title)
    val mss = new Date().getTime - t0
    val s = formatTime(mss)
    System.err.println((if (title.indexOf("耗时") == -1) title + "，耗时：" else title) + s)
    GeoUtil.memTime()
    s
  }

  def memTimeTotal() = {
    t0Total = new Date().getTime
  }

  def showCostTotal(title: String = "") = {
    val mss = new Date().getTime - t0Total
    val s = formatTime(mss)
    System.err.println((if (title.indexOf("总耗时") == -1) title + "，总耗时：" else title) + s)
    GeoUtil.memTimeTotal()
    s
  }

  def formatTime(mss: Long) = {
    val days = mss / (1000 * 60 * 60 * 24)
    val hours = (mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
    val minutes = (mss % (1000 * 60 * 60)) / (1000 * 60)
    val seconds = (mss % (1000 * 60)) / 1000
    var s = if (days > 0) days + "天 " else ""
    s = s + (if (hours > 0) hours + "小时 " else "")
    s = s + (if (minutes > 0) minutes + "分钟 " else "")
    s = s + (if (seconds > 0) seconds + "秒" else (mss % (1000 * 60) + "毫秒"))
    s = s + " [" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()) + "]"
    s
  }

  def daysDiff(fromDay: String, endDay: String) = {
    val from = fromDay.replaceAll("-", "")
    val to = endDay.replaceAll("-", "")
    var t = from
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0, 4).toInt, t.substring(4, 6).toInt - 1, t.substring(6, 8).toInt, 0, 0, 0)

    t = to
    val endtm = Calendar.getInstance()
    endtm.set(t.substring(0, 4).toInt, t.substring(4, 6).toInt - 1, t.substring(6, 8).toInt, 0, 0, 0)

    val millis = endtm.getTimeInMillis - begintm.getTimeInMillis
    millis / 24 / 60 / 60 / 1000
  }

  def getWeek(dayid: String) = {
    val t = dayid.replaceAll("-", "")
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0, 4).toInt, t.substring(4, 6).toInt - 1, t.substring(6, 8).toInt, 0, 0, 0)
    begintm.getTime().getDay
  }

  def getYesterdayDate(): String = {
    var nowdate = LocalDate.now()
    nowdate.minusDays(1).toString()
    //    var cal:Calendar=Calendar.getInstance()
    //    cal.add(Calendar.DATE,-0)
    //    new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime())
  }

  def getTodayDate(): String = {
    var cal: Calendar = Calendar.getInstance()
    cal.add(Calendar.DATE, -0)
    new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime())
  }

  def now(): String = {
    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime())
  }

  def addDay(dayid: String, step: Int) = {
    val t = dayid.replaceAll("-", "")
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0, 4).toInt, t.substring(4, 6).toInt - 1, t.substring(6, 8).toInt, 0, 0, 0)
    begintm.add(Calendar.DATE, step)
    new SimpleDateFormat("yyyy-MM-dd").format(begintm.getTime())
  }

  def getMonthEnd(dayid: String = null) = {
    val day = if (dayid == null) GeoUtil.getTodayDayid() else dayid
    var dayend = day.substring(0, 6) + "28"
    while (dayend.substring(0, 6) == GeoUtil.addDay(dayend, 1).replaceAll("-", "").substring(0, 6)) {
      dayend = GeoUtil.addDay(dayend, 1).replaceAll("-", "")
    }
    dayend
  }

  def getToday() = {
    val begintm = Calendar.getInstance()
    new SimpleDateFormat("yyyy-MM-dd").format(begintm.getTime())
  }

  def getTodayDayid() = {
    val begintm = Calendar.getInstance()
    new SimpleDateFormat("yyyyMMdd").format(begintm.getTime())
  }

  def minuteAdd(dayid: String, fromtm: String, step: Int) = {
    val begintm = Calendar.getInstance()
    begintm.set(dayid.substring(0, 4).toInt, dayid.substring(4, 6).toInt - 1, dayid.substring(6, 8).toInt, fromtm.substring(0, 2).toInt, fromtm.substring(2, 4).toInt, 0)
    begintm.add(Calendar.MINUTE, step)
    (new SimpleDateFormat("yyyyMMdd").format(begintm.getTime()), new SimpleDateFormat("HHmm").format(begintm.getTime()))
  }

  def minuteAddConcat(dayid: String, fromtm: String, step: Int) = {
    val t = minuteAdd(dayid, fromtm, step)
    t._1 + t._2
  }
/*
  def runShellCmd(cmd: String, logPath: String, matchStr: String): Boolean = {
    val log = runShellCmd(cmd, logPath)
    log.contains(matchStr)
  }
  */

/*
  def runShellCmdSilent(cmd: String) = {
    val sh = "./_runShellCmd_" + UUID.randomUUID + ".sh"
    FileUtil.save(sh, cmd)
    var result = -1
    try {
      result = "./bash " + sh !;
    } catch {
      case e: Exception => {
        "chmod +x " + sh !;
        sh !;
      }
    }
    if (result == 2) {
      System.err.println("===============================")
      System.err.println(s"【$result】" + cmd)
      System.err.println("===============================")
    }
    new File(sh).deleteOnExit()
    result
  }
  */
/*
  def runShellCmd(cmd: String, logPath: String = null, printCmd: Boolean = true, printResult: Boolean = true): String = {
    //System.err.println
    if (printCmd)
      System.err.println(cmd)
    val sh = "./_runShellCmd_" + UUID.randomUUID + ".sh"
    val tmplog = "./_tmplog_" + UUID.randomUUID + ".txt"
    val logFile = if (logPath != null && logPath.length > 0) logPath else tmplog
    FileUtil.save(sh, cmd + " > " + logFile)
    //"chmod +x "+sh !;
    try {
      "./bash " + sh !;
    } catch {
      case e: Exception => {
        "chmod +x " + sh !;
        sh !;
      }
    }
    new File(sh).deleteOnExit()
    //System.err.println("cat "+logFile)
    //"cat "+logFile !;

    val f = new File(logFile)
    if (f.exists()) {
      val log = FileUtil.readFileByLines(logFile, false)
      if (logPath == null || logPath.length == 0)
        f.delete()
      if (printResult)
        System.err.println(log)
      log
    } else ""
  }

  */

  def sh(cmd: String): Unit = {
    cmd !;
  }


  def main(args: Array[String]): Unit = {

  }

  /*
  def addPartition(db: String, table: String, partitionBy: String, hdfsPath: String) = {
    if (db != null && db.length > 0 && partitionBy != null && partitionBy.length > 0) {
      if (spark != null && !spark.sparkContext.isStopped) {
        val cmd = s"alter table $db." + table + " add if not exists partition (" + partitionBy + ") location '" + hdfsPath + "'"
        spark.sql(cmd)
      } else {
        val sql =
          s"""
use $db;
alter table $table add if not exists partition ($partitionBy) location '$hdfsPath';"""
        Util.runHiveSQL(db, sql)
      }
    }
  }
  */
/*
  def runHiveSQL(db: String, sql: String, logPath: String = null): Unit = {
    var log = ""
    val sh = "./_runhivesql_" + UUID.randomUUID() + ".sh"
    val sqlFile = "./_runhivesql_" + UUID.randomUUID() + ".sql"
    var cmd = ""
    if (logPath != null) {
      log = " > " + logPath
    }

    var useSqlFile = false
    val d = "" //"--hiveconf hive.root.logger=OFF -S"
    if (sql.indexOf(";") != -1 || sql.indexOf("\n") != -1) {
      FileUtil.save(sqlFile, sql)

      cmd = "/app/hive/bin/hive " + d + " --database " + db + " -f " + sqlFile + log
      System.err.println(sql)
      System.err.println(cmd)
      useSqlFile = true
    } else {
      cmd = "/app/hive/bin/hive " + d + " --database " + db + " -e \"" + sql + "\"" + log
      System.err.println(cmd)
    }

    FileUtil.save(sh, cmd)
    try {
      "./bash " + sh !;
    } catch {
      case e: Exception => {
        "chmod +x " + sh !;
        sh !;
      }
    }
    new File(sh).deleteOnExit()
    if (useSqlFile)
      "rm -rf " + sqlFile !;
  }
  */
}
