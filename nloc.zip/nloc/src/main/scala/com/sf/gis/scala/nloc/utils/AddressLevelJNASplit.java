package com.sf.gis.scala.nloc.utils;


class AddressLevelNew {
    public String aoi;
    public String subAoi;
    public String building;
    public String unit;
    public String floor;
    public String room;
}

