package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{GeometryUtil, MD5Util}
import com.sf.gis.java.nloc.utils.MacKeySaltUtils
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.app.InitCollectWifiData.getMd5Key
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiAggData.cleanWifi
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiDailyData.getHmodRowKey
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiData.{className, logger, saveAoiKey}
import com.sf.gis.scala.nloc.wifiapp.InitWifiDataBaseMergeWifi.{logger, splitFingerMap}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01407317
 * @Author: 01407499
 * @CreateTime: 2023-11-29 15:47
 * @TaskId:916656
 * @TaskName:
 * @Description:网点wifi指纹挖掘
 */

object DeptWifiFingerExcavate {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveWifiDeptData=Array("timestamp","ewl","un","zx","zy","dept_code")
    val saveWifiMidDataKey=Array("dept_code","dept_name","division_code","division_name","dept_type_code","dept_type_name","dist_code","city_name","provinct_name","longitude","latitude","belong_county","belong_village","dept_addr","fp_all_plain","fp20_plain","fp50_plain","fp_all","fp20","fp50")
    val saveDeptAoiWifiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","address")
    val saveDeptIndexWifiKey=Array("key","wifi","finger_aoi","finger_bld","finger_detail","floor","city_code","lng","lat")
    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val end_day=args(0)
        val end_date=args(1)
        val start_day=args(2)
        val mode=args(3)
        mode match {
            case "daily" =>joinDeptWifi(sparkSession,end_day)
            case "detail" =>calcDeptWifiDetail(sparkSession,start_day,end_day,end_date)
            case "excavate" =>excavateDeptWifi(sparkSession,end_date)
            case "agg"=>aggDeptWifi(sparkSession,end_day,start_day)
        }





    }


    def joinDeptWifi(spark:SparkSession,end_day:String)={

        logger.error("获取网点小哥排班数据")
        val deptUnMapBroad = getBatchDeptData(spark, end_day)
        logger.error("获取ssid数据")
        val ssidDataRdd = getSsidData(spark, end_day, deptUnMapBroad)
        logger.error("获取wifi数据")
        val wifiDataRdd = getWifiData(spark, end_day, ssidDataRdd)
        logger.error("存储wifi数据")
        SparkWrite.save2HiveStaticNew(spark, wifiDataRdd, saveWifiDeptData, "dm_gis.dm_join_dept_wifi_dtl_di",Array(("inc_day", end_day)), 25)

    }

    def calcDeptWifiDetail(spark:SparkSession,start_day:String,end_day:String,end_date:String): Unit ={

        logger.error("获取关联wifi数据")
        val wifiJoinDataRdd = getWifiDeptData(spark, start_day, end_day)
        logger.error("获取网点信息")
        val(depetInfoMapBroad,deptInfoRdd)=getDeptInfo(spark,end_day)
        logger.error("计算网点wifi中间数据")
        val deptWifiMidDataRdd = calcDeptWifiData(wifiJoinDataRdd, depetInfoMapBroad, deptInfoRdd)
        logger.error("存储网点wifi中间数据")
        SparkWrite.save2HiveStaticNew(spark, deptWifiMidDataRdd, saveWifiMidDataKey, "dm_gis.dm_dept_wifi_info_di",Array(("inc_day", end_date)), 25)


    }

    def excavateDeptWifi(spark:SparkSession,end_date:String)={

        logger.error("挖掘网点wifi")
        val (deptAoiWifiRdd,deptWifiIndexRdd) = calcDeptAoiWifiData(spark, end_date)
        logger.error("存储网点aoiwifi指纹")
        SparkWrite.save2HiveStaticNew(spark, deptAoiWifiRdd, saveDeptAoiWifiKey, "dm_gis.dm_wifi_finger_dept_aoi_dtl_di",Array(("inc_day", end_date)), 25)
        logger.error("存储网点wifi指纹index数据")
        SparkWrite.save2HiveStaticNew(spark, deptWifiIndexRdd, saveDeptIndexWifiKey, "dm_gis.dm_wifi_finger_dept_index_dtl_di",Array(("inc_day", end_date)), 25)




    }

    def aggDeptWifi(spark:SparkSession,end_day:String,start_day:String)={
        logger.error("聚合网点indexwifi数据")
        val indexDeptWifiRdd = mergeIndexWifi(spark, end_day, start_day)
        logger.error("存储网点indexwifi数据")
        SparkWrite.save2HiveStaticNew(spark, indexDeptWifiRdd, saveDeptIndexWifiKey, "dm_gis.dm_wifi_finger_dept_index_nd",null, 25)

        logger.error("聚合网点aoiwifi数据")
        val aoiDeptWifiRdd = mergeAoiWifi(spark, end_day, start_day)
        logger.error("存储网点aoiwifi数据")
        SparkWrite.save2HiveStaticNew(spark, aoiDeptWifiRdd, saveDeptAoiWifiKey, "dm_gis.dm_wifi_finger_dept_aoi_nd",null, 25)

    }

    def mergeIndexWifi(spark:SparkSession,end_day:String,start_day:String)={
        var sql_dept=
            s"""
               |
               |
               |select * from dm_gis.dm_wifi_finger_dept_index_dtl_di where inc_day>='$start_day' and inc_day<='$end_day'
               |
               |""".stripMargin

        val deptRdd =SparkRead.readHiveAsJson(spark, sql_dept)._1.groupBy(x=>x.getString("key")).flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            dataObj.fluentPutAll(x._2.head)
            try{
                val key=getHmodRowKey(x._1, 100, 100, 1, 3)
                val size = x._2.size
                var finger_aoi=""
                val aoiMap = new mutable.HashMap[String,String]()
                var lngAll=0.0
                var latAll=0.0
                for(obj<-x._2){
                    finger_aoi+=obj.getString("finger_aoi")
                    lngAll+=obj.getString("lng").toDouble
                    latAll+=obj.getString("lat").toDouble

                }
                splitFingerMap(finger_aoi,aoiMap)
                var aoi_key=""
                for(key<-aoiMap.keySet){
                    aoi_key=aoi_key+key+aoiMap.get(key).get

                }
                dataObj.put("finger_aoi",aoi_key)
                dataObj.put("lng",lngAll /size)
                dataObj.put("lat",latAll /size)
                dataObj.put("key",key)

            }catch {case e:Exception=>logger.error(e.toString)}

            listBuffer+=dataObj
            listBuffer


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("合并网点index指纹数据---->"+deptRdd.count())

        deptRdd


    }

    def mergeAoiWifi(spark:SparkSession,end_day:String,start_day:String)={
        var sql_dept=
            s"""
              |
              |select * from dm_gis.dm_wifi_finger_dept_aoi_dtl_di where inc_day>='$start_day' and inc_day<='$end_day'
              |
              |""".stripMargin
        val deptAoiRdd =SparkRead.readHiveAsJson(spark, sql_dept)._1.groupBy(x=>x.getString("key")).flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]
            val size = x._2.size
            val dataObj = new JSONObject()
            var key = math.abs(x._1.hashCode) % 10 + "_" + x._1


            try{
                dataObj.fluentPutAll(x._2.head)
                dataObj.put("key",key)
                var wifiArr = new JSONArray()
                var lngall=0.0
                var latall=0.0
                for(obj<-x._2){
                    wifiArr.fluentAddAll(JSON.parseArray(obj.getString("wifi_list")))
                    lngall+=obj.getString("lng").toDouble
                    latall+=obj.getString("lat").toDouble
                }
                val wifiDataArr = cleanWifi(wifiArr, "0001")
                dataObj.put("wifi_list",wifiDataArr.toString)
                dataObj.put("lng",lngall /size)
                dataObj.put("lat",latall /size)

            }catch {case e:Exception=>logger.error(e.toString)}

            listBuffer+=dataObj
            listBuffer


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("合并网点aoi指纹数据----> "+deptAoiRdd.count())

        deptAoiRdd


    }

    def getWifiDeptData(spark:SparkSession,start_day:String,end_day:String)={
        var sql=
            s"""
              |
              |select * from dm_gis.dm_join_dept_wifi_dtl_di where inc_day>='$start_day' and inc_day<='$end_day'
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        dataRdd
    }

    def getBatchDeptData(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select dept_code,
              |    loginid as un
              |from dm_tc_waybillinfo.dwd_labor_middleground_emp_label_time_detail_distinct
              |where inc_day='$end_day'
              |group by dept_code, loginid
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val deptUnMap = dataRdd.map(obj => {
            val dept_code = obj.getString("dept_code")
            val un = obj.getString("un")
            (un, dept_code)
        }).collect().toMap
        spark.sparkContext.broadcast(deptUnMap)
    }

    def getSsidData(spark:SparkSession,end_day:String,deptUnMapBroad:Broadcast[Map[String, String]])={
        var sql=
            s"""
              |
              |select un, timestamp
              |from dm_gis.gis_lss_core_wifi
              |where inc_day='$end_day'
              |    and ssid in ('sfddwrt', 'sf-service')
              |    group by un, timestamp
              |
              |
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val ssidDataRdd = dataRdd.mapPartitions(x => {
            val deptUnMap = deptUnMapBroad.value
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val un = obj.getString("un")
                if (deptUnMap.contains(un)) {
                    obj.put("dept", deptUnMap.get(un).get)

                }
                listbuffer += obj

            }

            listbuffer.iterator

        }).filter(x => StringUtils.nonEmpty(x.getString("dept"))).map(x=>(x.getString("un")+"_"+x.getString("timestamp"),x))

        ssidDataRdd

    }

    def getWifiData(spark:SparkSession,end_day:String,ssidDataRdd:RDD[(String,JSONObject)])={
        var sql=
            s"""
              |
              |select `timestamp`,ewl,un,zx,zy from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day'  and `first`='True' and ewl<>''
              |
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val deptWifiDataRdd = dataRdd.map(x => (x.getString("un") + "_" + x.getString("timestamp"), x)).join(ssidDataRdd).map(x => {

            val dataObj = new JSONObject()
            val leftObj = x._2._1
            val rightObj = x._2._2
            if (!leftObj.isEmpty) {
                dataObj.fluentPutAll(leftObj)
                if (!rightObj.isEmpty) {
                    dataObj.put("dept_code", rightObj.getString("dept"))

                }

            }

            dataObj
        }).filter(x => StringUtils.nonEmpty(x.getString("dept_code"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取wifi数据量---> "+deptWifiDataRdd.count())

        deptWifiDataRdd

    }

    def getDeptInfo(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select dept_code, dept_name, division_code, division_name,  dept_type_code, dept_type_name, dist_code, city_name, provinct_name, longitude, latitude, belong_county, belong_village, dept_addr
              |from dim.dim_dept_info_df
              |where inc_day ='$end_day'
              |	and dept_type_code = 'DB05-DB'
              |	and delete_flg = '0'
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val depetInfoMap = dataRdd.map(obj => {
            val dept_code = obj.getString("dept_code")
            val longitude = obj.getString("longitude")
            val latitude = obj.getString("latitude")
            (dept_code, longitude + "," + latitude)


        }).collect().toMap
        (spark.sparkContext.broadcast(depetInfoMap),dataRdd.map(x=>(x.getString("dept_code"),x)))

    }

    def calcDeptWifiData(wifiDataRdd:RDD[JSONObject],depetInfoMapBroad:Broadcast[Map[String, String]],deptInfoRdd:RDD[(String,JSONObject)])={

        val fliterDistOverLimitDataRdd = wifiDataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            val depetInfoMap = depetInfoMapBroad.value
            for (obj <- x) {
                try {
                    val dept_code = obj.getString("dept_code")
                    val zx = obj.getString("zx")
                    val zy = obj.getString("zy")
                    if (StringUtils.nonEmpty(zx) && StringUtils.nonEmpty(zy)) {
                        if (depetInfoMap.contains(dept_code)) {
                            val lonlatstr = depetInfoMap.get(dept_code).get.split(",")
                            val lon = lonlatstr(0)
                            val lat = lonlatstr(1)
                            if (StringUtils.nonEmpty(lon) && StringUtils.nonEmpty(lat)) {
                                val dept_dist = GeometryUtil.getDistance(lon, lat, zx, zy)
                                obj.put("dept_dist", dept_dist)

                            }
                        }
                    }
                    listbuffer += obj
                } catch {
                    case e: Exception => {
                        logger.error(e.toString)
                    }
                }


            }


            listbuffer.iterator


        }).filter(x => StringUtils.nonEmpty(x.getString("dept_dist")) && x.getString("dept_dist").toDouble < 100.0).distinct()

        val wifiSplitRdd = fliterDistOverLimitDataRdd.map(x => (x.getString("dept_code"), x)).groupByKey().flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            val wifiListNum = x._2.size
            for (obj <- x._2) {
                try {
                    val ewl = obj.getString("ewl")
                    val ewlArr = JSON.parseArray(ewl)
                    if (ewlArr.size() > 0) {
                        for (i <- 0 until ewlArr.size()) {
                            val tempObj = new JSONObject()
                            tempObj.fluentPutAll(obj)
                            val value = ewlArr.getJSONObject(i)
                            var ewl_dis = value.getString("ss")
                            val mac_key = MacKeySaltUtils.getWifiMacKey(value.getString("mac"))
                            tempObj.put("decrypt_wifi", value.getString("mac"))
                            tempObj.put("ewl_dis", ewl_dis)
                            tempObj.put("mac_key", mac_key)
                            tempObj.put("wifiListNum", wifiListNum)
                            listBuffer += tempObj


                        }
                    }

                } catch {
                    case e: Exception => logger.error(e.toString)
                }


            }

            listBuffer


        })

        val deptWifiDataRdd = wifiSplitRdd.groupBy(x => (x.getString("dept_code"), x.getString("mac_key"))).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            val num = x._2.size
            val wifiListNum = x._2.head.getString("wifiListNum").toDouble
            val rate = num / wifiListNum
            var sig_all = 0L
            var timestamp = 9699200570L
            for (obj <- x._2) {
                val ewl_dis = obj.getString("ewl_dis").toLong
                val time = obj.getString("timestamp").toLong
                if (timestamp > time) {
                    timestamp = time
                }
                sig_all += ewl_dis

            }

            dataObj.put("mac", x._1._2)
            dataObj.put("dept_code", x._1._1)
            dataObj.put("decrypt_wifi", x._2.head.getString("decrypt_wifi"))
            dataObj.put("rate", rate)
            dataObj.put("sig", sig_all / num)
            dataObj.put("timestamp", timestamp)
            dataObj.put("num", num)
            listBuffer += dataObj

            listBuffer


        }).groupBy(x => x.getString("dept_code")).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            val dept_code = x._1
            val fp_all_plain = new JSONArray()
            val fp20_plain = new JSONArray()
            val fp50_plain = new JSONArray()

            val fp_all = new JSONArray()
            val fp20 = new JSONArray()
            val fp50 = new JSONArray()

            for (obj <- x._2) {
                try {
                    val tempObj = new JSONObject()
                    val tempObj2 = new JSONObject()
                    val rate = obj.getString("rate").toDouble
                    val decrypt_wifi = obj.getString("decrypt_wifi")
                    val sig = obj.getString("sig").toInt
                    val timestamp = obj.getString("timestamp").toLong
                    val mac = obj.getString("mac")
                    val num = obj.getString("num").toInt
                    tempObj.put("mac", decrypt_wifi)
                    tempObj.put("sig", sig)
                    tempObj.put("time", timestamp)
                    tempObj.put("num", num)
                    tempObj.put("rate", rate)

                    tempObj2.put("mac", mac)
                    tempObj2.put("sig", sig)
                    tempObj2.put("time", timestamp)
                    tempObj2.put("num", num)
                    tempObj2.put("source", "0001")

                    fp_all_plain.add(tempObj)
                    fp_all.add(tempObj2)
                    if (rate >= 0.2) {
                        fp20_plain.add(tempObj)
                        fp20.add(tempObj2)
                    }

                    if (rate >= 0.5) {
                        fp50_plain.add(tempObj)
                        fp50.add(tempObj2)
                    }

                } catch {
                    case e: Exception =>
                }


            }

            dataObj.put("dept_code", dept_code)
            dataObj.put("fp_all_plain", fp_all_plain)
            dataObj.put("fp20_plain", fp20_plain)
            dataObj.put("fp50_plain", fp50_plain)
            dataObj.put("fp_all", fp_all)
            dataObj.put("fp20", fp20)
            dataObj.put("fp50", fp50)
            listBuffer += dataObj

            listBuffer


        }).map(x => (x.getString("dept_code"), x)).leftOuterJoin(deptInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    dataObj.fluentPutAll(leftObj)
                    dataObj.fluentPutAll(rightOp.get)

                }

            }

            dataObj
        }).distinct()

        deptWifiDataRdd

    }

    def calcDeptAoiWifiData(spark:SparkSession,end_date:String)={
        var sql=
            s"""
              |
              |select
              |  dept_code,
              |  fp20_plain,
              |  fp20 as wifi_list,
              |  longitude as lng,
              |  latitude as lat,
              |  dist_code as city_code,
              |  provinct_name as province,
              |  city_name as city,
              |  belong_county as county,
              |  belong_village as village,
              |  dept_name as aoi_name,
              |  concat(dept_addr,dept_name) as address
              |  from dm_gis.dm_dept_wifi_info_di
              |  where inc_day='$end_date'
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val deptAoiWifiRdd = dataRdd.map(obj => {
            val dept_code = obj.getString("dept_code")
            val aoi_id = getMd5AllKey(dept_code)
            val key = getMd5Key(aoi_id)
            obj.put("aoi_id", aoi_id)
            obj.put("aoi_key", aoi_id)
            obj.put("key", key)
            obj

        })

        val deptWifiIndexRdd = deptAoiWifiRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                try {
                    val wifi_list = obj.getString("fp20_plain")
                    val ewlArr = JSON.parseArray(wifi_list)
                    val finger_aoi = obj.getString("key")
                    val lng = obj.getString("lng")
                    val lat = obj.getString("lat")
                    val city_code = obj.getString("city_code")
                    if (ewlArr.size() > 0) {
                        for (i <- 0 until (ewlArr.size())) {
                            val ewlObj = ewlArr.getJSONObject(i)
                            val wifi = ewlObj.getString("mac")
                            val sig = ewlObj.getString("sig")
                            val key = MacKeySaltUtils.getWifiMacKey(wifi)
                            val tmpObj = new JSONObject()
                            tmpObj.put("finger_aoi", finger_aoi)
                            tmpObj.put("lng", lng)
                            tmpObj.put("lat", lat)
                            tmpObj.put("city_code", city_code)
                            tmpObj.put("wifi", wifi)
                            tmpObj.put("key", key)
                            tmpObj.put("sig", sig)
                            listbuffer += tmpObj

                        }

                    }

                } catch {
                    case e: Exception => logger.error(e.toString)
                }


            }


            listbuffer.iterator


        }).groupBy(x => x.getString("key")).flatMap(x => {
            val listbuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            val num = x._2.size
            var city_code = x._2.head.getString("city_code")
            val wifi = x._2.head.getString("wifi")
            val aoiMap = new mutable.HashMap[String, Long]()
            var lngall = 0.0
            var latall = 0.0
            for (obj <- x._2) {
                val lng = obj.getString("lng")
                val lat = obj.getString("lat")
                val finger_aoi = obj.getString("finger_aoi")
                val sig = math.abs(obj.getString("sig").toLong)
                if (aoiMap.contains(finger_aoi)) {

                    aoiMap.put(finger_aoi, (math.round((aoiMap.get(finger_aoi).get + sig.toDouble) / 2)))
                } else {
                    aoiMap.put(finger_aoi, sig)

                }

                latall += lat.toDouble
                lngall += lng.toDouble

            }

            var finger_aoi = ""
            for (aoikey <- aoiMap.keySet) {
                finger_aoi = finger_aoi + aoikey + (aoiMap.get(aoikey).get + 1000).toString.substring(1)

            }
            dataObj.put("wifi", wifi)
            dataObj.put("key", x._1)
            dataObj.put("city_code", city_code)
            dataObj.put("lng", lngall / num)
            dataObj.put("lat", latall / num)
            dataObj.put("finger_aoi", finger_aoi)
            listbuffer += dataObj
            listbuffer


        })

        (deptAoiWifiRdd,deptWifiIndexRdd)


    }

    def getMd5AllKey(str:String)={
        var resultMd5Str=""
        if(str!=null&&str.nonEmpty){
            val md5addr = MD5Util.getMD5(str)
            resultMd5Str=md5addr
        }
        resultMd5Str

    }

}
