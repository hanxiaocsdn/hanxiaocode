package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.nloc.utils.MacKeySaltUtils
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{DateUtil, StringUtils}
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiData.{getHmodRowKey, logger, saveDetailKey, splitFingerList, splitFingerMap}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-12-05 14:25
 * @TaskId:925458,943171,943175
 * @TaskName:聚合wifi数据-最终合并
 * @Description:
 */

object AggregateDailyWifi {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveAggKey=Array("tm","bssid","ssid","x","y","key","row_key")
    val saveDetailKey=Array("key","wifi_list","upper_key","address","level","province","city","county","town","roodline","aoi","building","floor","room","lon","lat","points","ssids")

    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","city_code","address","province","city","county","town","village","aoi_name","lng","lat","points","reliable","inc_day","reserve1","reserve2","ssids")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","city_code","address","province","city","county","town","village","aoi_name","buildingname","lng","lat","points","inc_day","reliable","reserve1","reserve2","ssids")
    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val mode=args(0)
        if(mode.equals("agg")){
            val resultRdd = aggregate(sparkSession)
            logger.error("存储 聚合wifi数据")
            SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveAggKey, "dm_gis.dm_nloc_wifi_data_dtl",null, 25)
        }else if(mode.equals("union")){
            val resultRdd = joinDetailWifiDataNew(sparkSession)
            logger.error("存储 wifi detail数据")
            SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveDetailKey, "dm_gis.dm_wifi_finger_detail_data_dtl",null, 25)
        }else if(mode.equals("aoi")){
            val resultRdd = joinAoiWifiData(sparkSession)
            logger.error("存储 wifi detail数据")
            SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveAoiKey, "dm_gis.dm_wifi_finger_aoi_data_dtl",null, 25)
        }else if(mode.equals("bld")){
            val resultRdd = joinBldWifiData(sparkSession)
            logger.error("存储 wifi detail数据")
            SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveBuildKey, "dm_gis.dm_wifi_finger_bld_data_dtl",null, 25)
        }
    }

    def aggregate(sparkSession:SparkSession)={
        var sql=
            """
              |
              |SELECT bssid,
              |       COALESCE(MAX(ssid), '') AS ssid,
              |       COALESCE(MAX(x), '') AS x,
              |       COALESCE(MAX(y), '') AS y,
              |       COALESCE(MAX(`timestamp`), '') AS `timestamp`
              |FROM dm_gis.dm_nloc_wifi_month_data_dtl_mi
              |GROUP BY bssid
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)

        val resultRdd = dataRdd.map(obj => {
            val bssid = obj.getString("bssid")
            val timestamp = obj.getString("timestamp")
            val key = MacKeySaltUtils.getWifiMacKey(bssid)
            val row_key = getHmodRowKey(key, 100, 100, 1, 3)
            val tm = DateUtil.tranTstampToTime(timestamp).substring(0, 10)
            obj.put("key", key)
            obj.put("row_key", row_key)
            obj.put("tm", tm)
            obj

        }).filter(x=>StringUtils.nonEmpty(x.getString("key"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("wifi数据量---》"+resultRdd.count())

        resultRdd

    }
    //dm_gis.dm_wifi_finger_index_dtl

    def joinDetailWifiDataNew(sparkSession:SparkSession)={
        var sql="select split(`key`,'_')[1] as `key`,finger_detail from dm_gis.dm_wifi_finger_index_dtl where finger_detail<>'' and city_code='755' and finger_bld<>''"
        logger.error("sql---->"+sql)
        val dataRdd =SparkRead.readHiveAsJson(sparkSession, sql)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x.getString("finger_detail")))

        var sql_name=
            """
              |
              |
              |select key,ssid from dm_gis.dm_nloc_wifi_data_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql_name)
        val wifiNameRdd =SparkRead.readHiveAsJson(sparkSession, sql_name)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x))

        val fingerNameRdd=dataRdd.leftOuterJoin(wifiNameRdd).map(x=>{
            val finger_detail = x._2._1
            val dataObj = new JSONObject()
            if(StringUtils.nonEmpty(finger_detail)){
                if(x._2._2.nonEmpty){
                    val fingerdetailSet = new mutable.HashSet[String]()
                    splitFingerList(finger_detail, fingerdetailSet)
                    dataObj.put("finger_detail",finger_detail)
                    dataObj.put("ssid",x._2._2.get.getString("ssid"))
                }

            }
            dataObj

        }).filter(x=>StringUtils.nonEmpty(x.getString("finger_detail"))).mapPartitions(x=>{
            val listbuffer = new ListBuffer[JSONObject]
            for(obj<-x){
                val finger_detail = obj.getString("finger_detail")
                val ssid = obj.getString("ssid")
                val fingerdetailSet = new mutable.HashSet[String]()
                splitFingerList(finger_detail, fingerdetailSet)
                for(key<-fingerdetailSet){
                    val tmpObj = new JSONObject()
                    tmpObj.put("finger_key",key)
                    tmpObj.put("ssid",ssid)
                    listbuffer+=tmpObj

                }

            }

            listbuffer.iterator

        }).filter(x=>StringUtils.nonEmpty(x.getString("finger_key"))).groupBy(x=>(x.getString("finger_key"))).flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]

            val dataObj = new JSONObject()
            dataObj.put("finger_key",x._1)
            val nameSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                val ssid = obj.getString("ssid")
                nameSet.add(ssid)

            }
            if(nameSet.size>0)
            dataObj.put("ssids", "[\"" + nameSet.mkString("\",\"") + "\"]")

            listBuffer += dataObj

            listBuffer
        }).map(x=>(x.getString("finger_key"),x)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联后数据量---》"+fingerNameRdd.count())
        Spark.clearPersistWithoutId(sparkSession,fingerNameRdd.id)
        var sql_detail=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_detail_dtl where city_code='755'
              |
              |""".stripMargin
        logger.error("sql---->"+sql_detail)
        val resultRdd=SparkRead.readHiveAsJson(sparkSession, sql_detail)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key").split("_")(1),x)).leftOuterJoin(fingerNameRdd).map(x=>{
            val leftObj = x._2._1
            if(!leftObj.isEmpty){
                if(x._2._2.nonEmpty){
                    leftObj.put("ssids",x._2._2.get.getString("ssids"))
                    leftObj.put("aoi",leftObj.getString("aoi_name"))
                    leftObj.put("building",leftObj.getString("buildingname"))
                    leftObj.put("lon",leftObj.getString("lng"))
                    leftObj.put("address",leftObj.getString("address").replace("null",""))
                }

            }
            leftObj


        }).filter(x=>StringUtils.nonEmpty(x.getString("ssids")))
        logger.error("关联后有wifi名字的数据量---》"+resultRdd.count())
        resultRdd

    }

    def joinBldWifiData(sparkSession:SparkSession)={
        var sql="select split(`key`,'_')[1] as `key`,finger_bld from dm_gis.dm_wifi_finger_index_dtl where finger_detail<>'' and city_code='755' and finger_bld<>''"
        logger.error("sql---->"+sql)
        val dataRdd =SparkRead.readHiveAsJson(sparkSession, sql)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x.getString("finger_bld")))

        var sql_name=
            """
              |
              |
              |select key,ssid from dm_gis.dm_nloc_wifi_data_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql_name)
        val wifiNameRdd =SparkRead.readHiveAsJson(sparkSession, sql_name)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x))

        val fingerNameRdd=dataRdd.leftOuterJoin(wifiNameRdd).map(x=>{
            val finger_detail = x._2._1
            val dataObj = new JSONObject()
            if(StringUtils.nonEmpty(finger_detail)){
                if(x._2._2.nonEmpty){
                    val fingerdetailSet = new mutable.HashSet[String]()
                    splitFingerList(finger_detail, fingerdetailSet)
                    dataObj.put("finger_bld",finger_detail)
                    dataObj.put("ssid",x._2._2.get.getString("ssid"))
                }

            }
            dataObj

        }).filter(x=>StringUtils.nonEmpty(x.getString("finger_bld"))).mapPartitions(x=>{
            val listbuffer = new ListBuffer[JSONObject]
            for(obj<-x){
                val finger_detail = obj.getString("finger_bld")
                val ssid = obj.getString("ssid")
                val fingerdetailSet = new mutable.HashSet[String]()
                splitFingerList(finger_detail, fingerdetailSet)
                for(key<-fingerdetailSet){
                    val tmpObj = new JSONObject()
                    tmpObj.put("finger_key",key)
                    tmpObj.put("ssid",ssid)
                    listbuffer+=tmpObj

                }

            }

            listbuffer.iterator

        }).filter(x=>StringUtils.nonEmpty(x.getString("finger_key"))).groupBy(x=>(x.getString("finger_key"))).flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]

            val dataObj = new JSONObject()
            dataObj.put("finger_key",x._1)
            val nameSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                val ssid = obj.getString("ssid")
                nameSet.add(ssid)

            }
            if(nameSet.size>0)
                dataObj.put("ssids", "[\"" + nameSet.mkString("\",\"") + "\"]")

            listBuffer += dataObj

            listBuffer
        }).map(x=>(x.getString("finger_key"),x)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联后数据量---》"+fingerNameRdd.count())
        Spark.clearPersistWithoutId(sparkSession,fingerNameRdd.id)
        var sql_detail=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_bld_dtl where city_code='755'
              |
              |""".stripMargin
        logger.error("sql---->"+sql_detail)
        val resultRdd=SparkRead.readHiveAsJson(sparkSession, sql_detail)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key").split("_")(1),x)).leftOuterJoin(fingerNameRdd).map(x=>{
            val leftObj = x._2._1
            if(!leftObj.isEmpty){
                if(x._2._2.nonEmpty){
                    leftObj.put("ssids",x._2._2.get.getString("ssids"))
//                    leftObj.put("aoi",leftObj.getString("aoi_name"))
//                    leftObj.put("building",leftObj.getString("buildingname"))
//                    leftObj.put("lon",leftObj.getString("lng"))
//                    leftObj.put("address",leftObj.getString("address").replace("null",""))
                }

            }
            leftObj


        }).filter(x=>StringUtils.nonEmpty(x.getString("ssids")))
        logger.error("关联后有wifi名字的bld数据量---》"+resultRdd.count())
        resultRdd

    }

    def joinAoiWifiData(sparkSession:SparkSession)={
        var sql="select split(`key`,'_')[1] as `key`,finger_aoi from dm_gis.dm_wifi_finger_index_dtl where finger_detail<>'' and city_code='755' "
        logger.error("sql---->"+sql)
        val dataRdd =SparkRead.readHiveAsJson(sparkSession, sql)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x.getString("finger_aoi")))

        var sql_name=
            """
              |
              |
              |select key,ssid from dm_gis.dm_nloc_wifi_data_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql_name)
        val wifiNameRdd =SparkRead.readHiveAsJson(sparkSession, sql_name)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x))

        val fingerNameRdd=dataRdd.leftOuterJoin(wifiNameRdd).map(x=>{
            val finger_aoi = x._2._1
            val dataObj = new JSONObject()
            if(StringUtils.nonEmpty(finger_aoi)){
                if(x._2._2.nonEmpty){

                    val aoiSet = new mutable.HashMap[String,String]()

                    splitFingerMap(finger_aoi,aoiSet)
                    dataObj.put("finger_aoi",finger_aoi)
                    dataObj.put("ssid",x._2._2.get.getString("ssid"))
                }

            }
            dataObj

        }).filter(x=>StringUtils.nonEmpty(x.getString("finger_aoi"))).mapPartitions(x=>{
            val listbuffer = new ListBuffer[JSONObject]
            for(obj<-x){
                val finger_aoi = obj.getString("finger_aoi")
                val ssid = obj.getString("ssid")
                val aoiSet = new mutable.HashMap[String,String]()

                splitFingerMap(finger_aoi,aoiSet)
                for(key<-aoiSet.keySet){
                    val tmpObj = new JSONObject()
                    tmpObj.put("finger_key",key)
                    tmpObj.put("ssid",ssid)
                    listbuffer+=tmpObj

                }

            }

            listbuffer.iterator

        }).filter(x=>StringUtils.nonEmpty(x.getString("finger_key"))).groupBy(x=>(x.getString("finger_key"))).flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]

            val dataObj = new JSONObject()
            dataObj.put("finger_key",x._1)
            val nameSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                val ssid = obj.getString("ssid")
                nameSet.add(ssid)

            }
            if(nameSet.size>0)
                dataObj.put("ssids", "[\"" + nameSet.mkString("\",\"") + "\"]")

            listBuffer += dataObj

            listBuffer
        }).map(x=>(x.getString("finger_key"),x)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联后数据量---》"+fingerNameRdd.count())
        Spark.clearPersistWithoutId(sparkSession,fingerNameRdd.id)
        var sql_detail=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_aoi_dtl where city_code='755'
              |
              |""".stripMargin
        logger.error("sql---->"+sql_detail)
        val resultRdd=SparkRead.readHiveAsJson(sparkSession, sql_detail)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key").split("_")(1),x)).leftOuterJoin(fingerNameRdd).map(x=>{
            val leftObj = x._2._1
            if(!leftObj.isEmpty){
                if(x._2._2.nonEmpty){
                    leftObj.put("ssids",x._2._2.get.getString("ssids"))
//                    leftObj.put("aoi",leftObj.getString("aoi_name"))
//                    leftObj.put("building",leftObj.getString("buildingname"))
//                    leftObj.put("lon",leftObj.getString("lng"))
//                    leftObj.put("address",leftObj.getString("address").replace("null",""))
                }

            }
            leftObj


        }).filter(x=>StringUtils.nonEmpty(x.getString("ssids")))
        logger.error("关联后有wifi名字的aoi数据量---》"+resultRdd.count())
        resultRdd

    }


    def joinDetailWifiData(sparkSession:SparkSession)={
        var sql_detail=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_traj_detail_dtl where city_code='755'
              |
              |""".stripMargin
        logger.error("sql---->"+sql_detail)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql_detail)

        var sql_name=
            """
              |
              |
              |select key,ssid from dm_gis.dm_nloc_wifi_data_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql_name)
        val wifiNameRdd =SparkRead.readHiveAsJson(sparkSession, sql_name)._1.filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x))

        val detailRdd = dataRdd.mapPartitions(x => {
            val listBuffer = new ListBuffer[JSONObject]

            for (obj <- x) {
                try {
                    val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
                    for (i <- 0 until (wifi_list.size())) {
                        val mac = wifi_list.getJSONObject(i).getString("mac")
                        val tmpObj = new JSONObject()
                        tmpObj.fluentPutAll(obj)
                        tmpObj.put("mac", mac)
                        listBuffer += tmpObj

                    }


                } catch {
                    case e: Exception => logger.error(e.toString)
                }

            }


            listBuffer.iterator
        }).filter(x=>StringUtils.nonEmpty(x.getString("mac"))).map(x=>(x.getString("mac"),x)).leftOuterJoin(wifiNameRdd).map(x=>{
            val leftObj = x._2._1
            val rightObj = x._2._2
            if(!leftObj.isEmpty){
                if(rightObj.nonEmpty){
                    leftObj.put("ssid",rightObj.get.getString("ssid"))

                }

            }

            leftObj
        })

        val resultRdd = detailRdd.groupBy(x => x.getString("key")).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            dataObj.fluentPutAll(x._2.head)
            val nameSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                val ssid = obj.getString("ssid")
                nameSet.add(ssid)

            }
            dataObj.put("ssids", "[\"" + nameSet.mkString("\",\"") + "\"]")

            listBuffer += dataObj

            listBuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联后数据量---》"+resultRdd.count())

        resultRdd

    }

}
