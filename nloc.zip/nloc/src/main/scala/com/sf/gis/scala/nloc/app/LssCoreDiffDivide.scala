package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, row_number}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.util.LongAccumulator

import java.text.SimpleDateFormat
import java.util.Calendar
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.Random

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-06-14 10:11
 * @TaskId:771348
 * @TaskName:
 * @Description:网络定位差分数据分割
 */

object LssCoreDiffDivide {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    type Data1 = (RDD[JSONObject],Long,Long)=>RDD[JSONObject]
    val saveWifiKey=Array("bssid","inc_day")
    val saveCellKey=Array("mcc","mnc","lac","ci","inc_day")
    val wifi_diff_table="dm_gis.crawl_wifi_result_divide"
    val cell_diff_table="dm_gis.crawl_cell_result_divide"

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val wifiNum = getNum(getWifiDataNum(sparkSession, end_day))
        val cellNum = getNum(getCellDataNum(sparkSession, end_day))
        val (listBufferWifi,listBuffercell) = getDateArr(wifiNum, cellNum)
        logger.error("wifi num ----> "+wifiNum+"  cell num ----> "+cellNum)
        logger.error("获取wifi数据")
        getWifiData(sparkSession, end_day,listBufferWifi,wifiNum)
        logger.error("获取cell数据")
        getCellData(sparkSession, end_day,listBuffercell,cellNum)

//        logger.error("获取wifi数据")
//        val wifiRdd = getWifiAllData(sparkSession, end_day)
//        logger.error("获取cell数据")
//        val cellRdd = getCellAllData(sparkSession, end_day)
//        for(i<-0 until wifiNum){
//            var start_index=(i*90000000).toLong
//            var end_index=((i+1)*90000000).toLong
//            stat(sparkSession,end_day,listBufferWifi(i),start_index,end_index,getDivideData,saveWifiKey,wifi_diff_table,wifiRdd)
//
//        }
//        for(i<-0 until cellNum){
//            var start_index=(i*90000000).toLong
//            var end_index=((i+1)*90000000).toLong
//            stat(sparkSession,end_day,listBuffercell(i),start_index,end_index,getDivideData,saveCellKey,cell_diff_table,cellRdd)
//
//        }




    }

    def stat(spark:SparkSession,end_day:String,write_par_date:String,start_index:Long,end_index:Long,getData:Data1,saveKey:Array[String],target_table:String,dataRdd:RDD[JSONObject])={
        logger.error("start write table ---> "+target_table+"  start index---> "+start_index+" end index----> "+end_index)
        val resultRdd = getData(dataRdd, start_index, end_index)
        SparkWrite.save2HiveStaticNew(spark, resultRdd, saveKey, target_table,Array(("inc_day", write_par_date)), 25)

    }

    def getWifiData(spark:SparkSession,end_day:String,listBufferWifi: ListBuffer[String],wifiNum:Int)={
        var end_miss=end_day+"miss"
        var end_error=end_day+"error"
        var sql=
            s"""
               |
               |
               |select bssid from dm_gis.nls_location_wifi_diff where inc_day='$end_miss'
               |
               |
               |
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val dataRdd = originRdd.map(obj => {

            val value = Random.nextInt(10000)
            val index = value % wifiNum
            obj.put("inc_day", listBufferWifi(index))
            obj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        Spark.clearPersistWithoutId(spark,dataRdd.id)
        val frame = rddToDataFrame(spark, dataRdd, saveWifiKey)
        frame.createOrReplaceTempView("tmep_wifi_result")
        var sql_w=
            """
              |
              |insert overwrite table dm_gis.crawl_wifi_result_divide partition(inc_day)
              |select
              |bssid,
              |inc_day
              |from
              |tmep_wifi_result
              |
              |
              |
              |""".stripMargin
              spark.sql(sql_w)
        dataRdd.unpersist()


    }

    def getCellData(spark:SparkSession,end_day:String,listBufferWifi: ListBuffer[String],cellNum:Int)={
        var end_miss=end_day+"miss"
        var end_error=end_day+"error"
        var sql=
            s"""
               |
               |
               |select mcc,mnc,lac,ci from dm_gis.nls_location_cell_diff where (inc_day='$end_miss' or inc_day='$end_error' )
               |
               |
               |
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        Spark.clearPersistWithoutId(spark,originRdd.id)
        val dataRdd = originRdd.map(obj => {
            val value = Random.nextInt(10000)
            val index = value % cellNum
            obj.put("inc_day", listBufferWifi(index))
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+dataRdd.count())
        val frame = rddToDataFrame(spark, dataRdd, saveCellKey)
        frame.createOrReplaceTempView("tmep_cell_result")
        var sql_w=
            """
              |
              |insert overwrite table dm_gis.crawl_cell_result_divide partition(inc_day)
              |select
              |mcc,mnc,lac,ci,inc_day
              |from
              |tmep_cell_result
              |
              |
              |
              |""".stripMargin
        spark.sql(sql_w)


    }
    def rddToDataFrame(spark:SparkSession,dataRdd: RDD[JSONObject], saveKeyName: Array[String])={

        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveKeyName.indices) {
            schemaEle.append(StructField(saveKeyName.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        val rowRdd = dataRdd.map(obj => {
            val row = new ArrayBuffer[String]
            for (i <- saveKeyName.indices) {
                row.append(JSONUtil.getJsonValSingle(obj, saveKeyName.apply(i)).replaceAll("[\\r\\n\\t]", ""))
            }
            val ret = Row.fromSeq(row)
            ret
        })
        spark.createDataFrame(rowRdd, schema)

    }

    def getWifiAllData(spark:SparkSession,end_day:String)={
        var end_miss=end_day+"miss"
        var end_error=end_day+"error"
        var sql=
            s"""
               |
               |
               |select bssid from dm_gis.nls_location_wifi_diff where inc_day='$end_miss'
               |
               |
               |
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val addRnkdf = spark.sql(sql).repartition(2000).withColumn("rnk", row_number().over(Window.orderBy("bssid")).cast(StringType))
        val columns =addRnkdf.columns
        var dataRdd = addRnkdf.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getString(i))
            }
            jObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量----》"+dataRdd.count())

        dataRdd

    }

    def getCellAllData(spark:SparkSession,end_day:String)={
        var end_miss=end_day+"miss"
        var end_error=end_day+"error"
        var sql=
            s"""
               |
               |
               |select mcc,mnc,lac,ci from dm_gis.nls_location_cell_diff where (inc_day='$end_miss' or inc_day='$end_error' )
               |
               |
               |
               |
               |
               |
               |""".stripMargin
        logger.error("sql---->"+sql)
        val addRnkdf = spark.sql(sql).repartition(2000).withColumn("rnk", row_number().over(Window.orderBy("lac")).cast(StringType))
        val columns =addRnkdf.columns
        var dataRdd = addRnkdf.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getString(i))
            }
            jObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量----》"+dataRdd.count())

        dataRdd

    }

    def getDivideData(dataRdd: RDD[JSONObject],start_index:Long,end_index:Long)={
        val resultRdd = dataRdd.filter(obj => {
            val rnk = obj.getString("rnk")
            if (StringUtils.nonEmpty(rnk) && rnk.toLong >= start_index && rnk.toLong < end_index) {
                true
            } else {
                false
            }
        })
        resultRdd

    }



    def getWifiDataNum(spark:SparkSession,end_day:String)={
        var end_miss=end_day+"miss"
        var end_error=end_day+"error"
        var sql=
            s"""
              |
              |select bssid from dm_gis.nls_location_wifi_diff where inc_day='$end_miss' group by bssid
              |
              |
              |""".stripMargin
        spark.sql(sql).count()

    }

    def getCellDataNum(spark:SparkSession,end_day:String)={
        var end_miss=end_day+"miss"
        var end_error=end_day+"error"
        var sql=
            s"""
               |
               |select mcc,mnc,lac,ci from dm_gis.nls_location_cell_diff where (inc_day='$end_miss' or inc_day='$end_error')
               |
               |
               |""".stripMargin
        spark.sql(sql).count()

    }

    def getNum(dataNum:Long,value:Double=10200000.0)={
        var intdata:Double=0.0
        try{
            intdata=(dataNum/value)
        }catch {case e:Exception=>{
            logger.error(e.getMessage)
        }}

        math.ceil(intdata).toInt

    }
    def getDateArr(wifiNum:Int,cellNum:Int)={
        val format = FastDateFormat.getInstance("yyyyMMdd")
        val calendar = Calendar.getInstance()
        val listBufferWifi: ListBuffer[String] = ListBuffer()
        val listBuffercell: ListBuffer[String] = ListBuffer()
        for(i <-0 until wifiNum){
            calendar.add(Calendar.DAY_OF_MONTH, 1)
            listBufferWifi+=format.format(calendar.getTime)

        }
        for(i <-0 until cellNum){
            calendar.add(Calendar.DAY_OF_MONTH, 1)
            listBuffercell+=format.format(calendar.getTime)

        }
        (listBufferWifi,listBuffercell)
    }




}
