package com.sf.gis.scala.nloc.app

import com.sf.gis.java.base.util.{ShellExcutor, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel


/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-09-04 10:59
 * @TaskId:855203
 * @TaskName:
 * @Description:轨迹wifi数据提取
 */
object GisAPWifiDtDownload {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    download(spark, "gis_lss_core_wifi", "755")
    download(spark, "wifi_finger_index_v1", "755")

    spark.stop()
  }

  def download(spark: SparkSession, tableName: String, city_code: String): Unit = {
    val hdfsPath = s"hdfs://sfbd/user/hive/warehouse/dm_gis/${tableName}_${city_code}"
    val file = s"./${tableName}_${city_code}.csv"

    var sql=""
    ShellExcutor.exeCmd(s"hdfs dfs -rm -r $hdfsPath")
    if(tableName.equals("gis_lss_core_wifi")){
      sql=
        """
          |
          |select distinct bssid,ssid,x,y from tmp_dm_gis.gis_lss_core_wifi_755
          |where  ssid!=''
          |and x>=113.60260156256727
          |and y>=22.33121691648796
          |and x<=114.68475488272917
          |and y<=22.977553036997236
          |
          |
          |""".stripMargin


    }else if (tableName.equals("wifi_finger_index_v1")){
      sql=
        """
          |
          |SELECT key,finger_aoi,finger_bld,finger_detail,floor,lon,lat,reserve1,reserve2,update_tag FROM dm_gis.wifi_finger_index_v1
          |where lon>=113.60260156256727
          |and lat>=22.33121691648796
          |and lon<=114.68475488272917
          |and lat<=22.977553036997236
          |
          |
          |""".stripMargin

    }


    println("取数sql为:" + sql)
    println(s"$tableName 表数据开始保存至 $hdfsPath")
    val dataDF = spark.sql(sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dataDF cnt:" + dataDF.count())

    val unit: Unit = dataDF.repartition(40)
      .write
      .format("csv")
      .mode("overwrite")
      .option("header", "true")
      .option("sep", "\t")
      .save(hdfsPath)
    println(s"$tableName 表数据已保存至： $hdfsPath")
    dataDF.unpersist()

    println(s"$tableName 表数据开始合并下载至本地： $file")
    ShellExcutor.exeCmd(s"rm -r $file")
    ShellExcutor.exeCmd(s"hdfs dfs -getmerge $hdfsPath $file")
    println(s"$tableName 表数据下载完成")

    println(s"$tableName 开始压缩数据")
    ShellExcutor.exeCmd(s"rm -r $file.tgz")
    ShellExcutor.exeCmd(s"tar czf $file.tgz $file")
    println(s"$tableName 表数据压缩完成")

    println(s"$tableName 表开始上传")
    ShellExcutor.exeCmd(s"curl -X POST -F 'file=@./$file.tgz' http://10.216.162.97:9000/")
    ShellExcutor.exeCmd(s"rm -r $file")
    ShellExcutor.exeCmd(s"rm -r $file.tgz")
    println(s"$tableName 表数据上传成功")
  }
}
