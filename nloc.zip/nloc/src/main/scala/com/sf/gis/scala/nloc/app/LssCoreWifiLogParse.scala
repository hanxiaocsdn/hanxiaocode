package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import com.sf.gis.scala.nloc.app.InitCollectWifiData.logger
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}
import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-08-28 16:28
 * @TaskId:797920
 * @TaskName:
 * @Description:小哥巴枪WIFI日志数据解析
 */

object LssCoreWifiLogParse {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("id","timestamp","time","ewl","tm","un","zx","zy","ac","bn","gps_tm","lon","lat","rtime","first")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("开始解析小哥巴枪日志")
        val wifiRdd = getWifiLog(sparkSession, end_day)
        logger.error("开始合并小哥巴枪与轨迹数据")
        val resultRdd = mergeTraceData(sparkSession, end_day, wifiRdd)
//        val resultRdd=getWifiLogNew(sparkSession, end_day)
        logger.error("开始存储结果数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_lss_core_wifi_ewl_dtl_di",Array(("inc_day", end_day)), 50)





    }

    def getWifiLog(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |select * from dm_gis.gis_lss_core_wifi_log where inc_day='$end_day'
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val parseRdd = dataRdd.map(x => {
            val log = x.getString("log")
            val dataObj = new JSONObject()
            try {
                val logObj = JSON.parseObject(log)
                val array = new JSONArray()
                val id = JSONUtil.getJsonVal(logObj, "dev.id", "")
                val lon = JSONUtil.getJsonVal(logObj, "gps.x", "")
                val lat = JSONUtil.getJsonVal(logObj, "gps.y", "")
                val tm = JSONUtil.getJsonVal(logObj, "gps.tm", "")
                val rtime = JSONUtil.getJsonVal(logObj, "rtime", "")
                dataObj.put("id", id)
                dataObj.put("lon", lon)
                dataObj.put("lat", lat)
                dataObj.put("gps_tm", tm)
                dataObj.put("rtime", rtime)


                val wifiArr = JSONUtil.getJsonArrayFromObject(logObj, "wifi")
                val wifiSet = new mutable.HashSet[String]
                if (wifiArr.size() > 0) {
                    var time = JSONUtil.getJsonVal(wifiArr.getJSONObject(0), "timeStamp", "")
                    val timestamp = getTimeStamp(time)
                    dataObj.put("time", time)
                    dataObj.put("timestamp", timestamp)
                    dataObj.put("tm", timestamp)
                    for (i <- 0 until wifiArr.size()) {
                        val ewl = wifiArr.getJSONObject(i)
                        val ss = JSONUtil.getJsonVal(ewl, "rssi", "")
                        val mac = JSONUtil.getJsonVal(ewl, "bssid", "")
                        val tmpObj = new JSONObject()
                        if(StringUtils.nonEmpty(ss)&&ss.length<20){
                            if(!wifiSet.contains(mac)){
                                wifiSet.add(mac)
                                tmpObj.put("ss", ss.toLong)
                                tmpObj.put("mac", mac)
                                array.add(tmpObj)
                            }

                        }



                    }

                    dataObj.put("ewl", array.toString())

                }


            } catch {
                case e: Exception => {
                    logger.error(e.getStackTrace)

                }
            }

            dataObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("解析完成，数据量--------》"+parseRdd.count())
        val groupRdd = parseRdd.filter(obj => StringUtils.nonEmpty(obj.getString("ewl")) && StringUtils.nonEmpty(obj.getString("id"))&&(!obj.getString("id").equals("unknow"))).groupBy(x => x.getString("id")).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("解析完成，有wifi和小哥id的数据量--------》"+groupRdd.count())
        val firstRdd = groupRdd.map(x => (x._1, x._2.toList.sortBy(_.getString("timestamp")))).flatMap(x => {
            val wifiSet = new mutable.HashSet[String]()
            for (obj <- x._2) yield {
                val ewl = obj.getString("ewl")
                if (wifiSet.contains(ewl)) {
                    obj.put("first", "False")

                } else {
                    obj.put("first", "True")
                    wifiSet.add(ewl)
                }

                obj

            }
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("过滤完成，数据量----》"+firstRdd.count())
        dataRdd.unpersist()


        firstRdd


    }



    def getWifiLogNew(spark:SparkSession,end_day:String)={
        var sql=
            s"""
               |
               |select * from dm_gis.gis_lss_core_wifi_log where inc_day='$end_day'
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val parseRdd = dataRdd.map(x => {
            val log = x.getString("log")
            val dataObj = new JSONObject()
            try {
                val logObj = JSON.parseObject(log)
                val array = new JSONArray()
                val id = JSONUtil.getJsonVal(logObj, "dev.id", "")
                val tm = JSONUtil.getJsonVal(logObj, "dev.tm", "")
                val un = JSONUtil.getJsonVal(logObj, "dev.un", "")
                val lon = JSONUtil.getJsonVal(logObj, "gps.x", "")
                val lat = JSONUtil.getJsonVal(logObj, "gps.y", "")
                val gps_tm = JSONUtil.getJsonVal(logObj, "gps.tm", "")
                val rtime = JSONUtil.getJsonVal(logObj, "rtime", "")
                dataObj.put("id", id)
//                dataObj.put("tm", tm)
                dataObj.put("un", un)
                dataObj.put("zx", lon)
                dataObj.put("zy", lat)
                dataObj.put("gps_tm", gps_tm)
                dataObj.put("rtime", rtime)


                val wifiSet = new mutable.HashSet[String]
                val wifiArr = JSONUtil.getJsonArrayFromObject(logObj, "wifi")
                if (wifiArr.size() > 0) {
                    var time = JSONUtil.getJsonVal(wifiArr.getJSONObject(0), "timeStamp", "")
                    val timestamp = getTimeStamp(time)
                    dataObj.put("time", time)
                    dataObj.put("timestamp", timestamp)
                    dataObj.put("tm", timestamp)
                    for (i <- 0 until wifiArr.size()) {
                        val ewl = wifiArr.getJSONObject(i)
                        val ss = JSONUtil.getJsonVal(ewl, "rssi", "")
                        val mac = JSONUtil.getJsonVal(ewl, "bssid", "")
                        val tmpObj = new JSONObject()
                        if(StringUtils.nonEmpty(ss)&&ss.length<20){
                            if(!wifiSet.contains(mac)){
                                wifiSet.add(mac)
                                tmpObj.put("ss", ss.toLong)
                                tmpObj.put("mac", mac)
                                array.add(tmpObj)
                            }

                        }



                    }

                    dataObj.put("ewl", array.toString())

                }


            } catch {
                case e: Exception => {
                    logger.error(e.getStackTrace)

                }
            }

            dataObj
        }).filter(obj => StringUtils.nonEmpty(obj.getString("ewl")) && StringUtils.nonEmpty(obj.getString("id"))&&(!obj.getString("id").equals("unknow"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("解析完成，有wifi和小哥id的数据量--------》"+parseRdd.count())
        val groupRdd = parseRdd.groupBy(x => x.getString("id")).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("解析完成，聚合后的数据量--------》"+groupRdd.count())
        val firstRdd = groupRdd.map(x => (x._1, x._2.toList.sortBy(_.getString("timestamp")))).flatMap(x => {
            val wifiSet = new mutable.HashSet[String]()
            for (obj <- x._2) yield {
                val ewl = obj.getString("ewl")
                if (wifiSet.contains(ewl)) {
                    obj.put("first", "False")

                } else {
                    obj.put("first", "True")
                    wifiSet.add(ewl)
                }

                obj

            }
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("过滤完成，数据量----》"+firstRdd.count())
        dataRdd.unpersist()


        firstRdd


    }

    def mergeTraceData(spark:SparkSession,end_day:String,wifiRdd:RDD[JSONObject])={
        var sql=
            s"""
              |
              |select id,un,zx,zy,tm,ac,bn from dm_gis.esg_gis_loc_trajectory where inc_day='$end_day'
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val dataRdd =SparkRead.readHiveAsJson(spark, sql)._1.filter(x=>StringUtils.nonEmpty(x.getString("id"))&&StringUtils.nonEmpty(x.getString("tm"))&&(!x.getString("id").equals("unknow"))).groupBy(x=>x.getString("id"))
        val resultRdd = wifiRdd.filter(x=>StringUtils.nonEmpty(x.getString("id"))&&(!x.getString("id").equals("unknow"))).groupBy(x => x.getString("id")).leftOuterJoin(dataRdd).flatMap(x => {
            val leftItr = x._2._1
            val rightOp = x._2._2
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            if (leftItr.nonEmpty) {
                if (rightOp.nonEmpty) {
                    for (leftObj <- leftItr) {
                        val timestamp = leftObj.getString("timestamp")
                        var mintimediff=60L
                        var mintimediffObj=new JSONObject()
                        for (rightObj <- rightOp.get) {
                            val tm = rightObj.getString("tm")
                            if (StringUtils.nonEmpty(timestamp) && StringUtils.nonEmpty(tm) && Math.abs(tm.toLong - timestamp.toLong) <= 30) {
                                if(mintimediff>Math.abs(tm.toLong - timestamp.toLong)){
                                    mintimediff=Math.abs(tm.toLong - timestamp.toLong)
                                    val tmpObj = new JSONObject()
                                    tmpObj.fluentPutAll(leftObj)
                                    tmpObj.fluentPutAll(rightObj)
                                    mintimediffObj=tmpObj
                                }
                            }
                        }
                        if(!mintimediffObj.isEmpty)
                        listBuffer += mintimediffObj
                    }
                }


            }
            listBuffer.iterator

        }).distinct()

        resultRdd


    }

    def getTimeStamp(inputDateStr:String): String ={
        var dateStr=""
        val dateStrFormat = "yyyy-MM-dd HH:mm:ss"
        val sdf = new SimpleDateFormat(dateStrFormat)
        val inputDate:Date = sdf.parse(inputDateStr)
        val tempDate = Calendar.getInstance
        tempDate.setTime(inputDate)
        dateStr=(inputDate.getTime/1000).toString
        dateStr
    }


}
