package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.java.base.util.GeometryUtil.sliceUpCoordinate
import com.sf.gis.java.nloc.pojo.ClusterWifiData
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.gis.scala.nloc.wifiapp.InitApWifiData.{CoorAoiDist, logger}
import com.sf.gis.scala.nloc.wifiapp.InitApWifiDataSign.calcPoint
import com.sf.gis.scala.nloc.wifiapp.WifiFingerEwl.className
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import java.util.Calendar
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.Random
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01407317
 * @Author: 01407499
 * @CreateTime: 2023-10-27 15:52
 * @TaskId:880662
 * @TaskName:wifi指纹库-过滤不符合规则数据
 * @Description:过滤非法wifi数据
 */

object DeliverFilterInvalidWifi {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val aoiCoorsDist="http://sds-core-datarun.sf-express.com/datarun/aoi/getAoiCoorsDist"
    val saveKey = Array("waybill_no","city_code","emp_code","tm","addr","eventtype","ewl","lng","lat","doing","aoi_id","aoi_name","buildingid","buildingname","lng_bld","lat_bld","province","city","county","town","village","floor","room","tag","bld_cntr_dist","aoi_interface_data")

    def main(args: Array[String]): Unit = {
        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("开始过滤不符合条件的数据")
        val resultRdd = filterInvalidWifi(sparkSession, end_day)
        SparkWrite.save2HiveStatic(sparkSession, resultRdd, saveKey, "dm_gis.dm_wifi_finger_traj_dtl_di",Array(("inc_day", end_day)), 25)



    }

    def filterInvalidWifi(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |
              |select
              |a.waybill_no
              |,a.city_code
              |,a.emp_code
              |,a.tm
              |,a.addr
              |,a.eventtype
              |,a.ewl
              |,a.lng
              |,a.lat
              |,a.doing
              |,b.aoi_id
              |,b.aoi_name
              |,b.buildingid
              |,b.buildingname
              |,b.x lng_bld
              |,b.y lat_bld
              |,b.province
              |,b.city
              |,b.county
              |,b.town
              |,b.village
              |,b.floor
              |,b.room
              |,case when c.waybill_no is not null and c.waybill_no<>'' then '疑似投竞对' when  regexp_replace(floor, '[A-Za-z]', '')>3 and !(doing regexp '3|4') then '无上门行为' end as tag
              |from
              |(select * from dm_gis.dm_waybill_traj_wifi_doing_dtl_di where inc_day='$end_day') a
              |left join
              |(select * from dm_gis.dm_tt_waybill_normalization_dtl_di where inc_day='$end_day') b on a.waybill_no=b.waybill_no and  a.eventtype=b.eventtype
              |left join (select waybill_no,'31124' as eventtype from dm_gis.dm_lbs_tjy_detail_to_operation_di where inc_day='$end_day' group by waybill_no ) c on a.waybill_no=c.waybill_no and a.eventtype=c.eventtype
              |where b.aoi_id<>''
              |
              |
              |""".stripMargin

//        where c.waybill_no is null
//        and !(regexp_replace(floor, '[A-Za-z]', '')>3 and !(doing regexp '3|4'))
//        and b.aoi_id<>''
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val tjyRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("tag")))
        val judgeDistOver50Rdd = dataRdd.filter(x=>(!(StringUtils.nonEmpty(x.getString("tag"))))).map(obj => {
            val lng = obj.getString("lng")
            val lat = obj.getString("lat")
            val lng_bld = obj.getString("lng_bld")
            val lat_bld = obj.getString("lat_bld")
            var tag=""
            var bld_flag = "false"
            if (StringUtils.nonEmpty(lng) && StringUtils.nonEmpty(lat) && StringUtils.nonEmpty(lng_bld) && StringUtils.nonEmpty(lat_bld)) {
                val bld_cntr_dist = GeometryUtil.getDistance(lng, lat, lng_bld, lat_bld)
                if(bld_cntr_dist!=null)
                obj.put("bld_cntr_dist", bld_cntr_dist.toString)
                if (bld_cntr_dist > 50.0) {
                    bld_flag = "true"
                    tag="无上门行为"
                }else{
                    tag=""
                }
            }
            obj.put("bld_flag", bld_flag)
            obj.put("tag", tag)
            obj
        }).distinct()

        val fliterDistOver50Rdd=judgeDistOver50Rdd.filter(x=>StringUtils.nonEmpty(x.getString("tag"))&&x.getString("tag").equals("无上门行为"))
        val Distless50Rdd = judgeDistOver50Rdd.filter(x => (!(StringUtils.nonEmpty(x.getString("tag")) && x.getString("tag").equals("无上门行为"))))
        /*
        对于wifi列表相同，如果相互的妥投距离大于50m，则划分两类，最终保留最大的那个
         */
        val judgeWifiRdd = Distless50Rdd.groupBy(x => x.getString("ewl")).flatMap(x => {
            var listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var tmplistBuffer: ListBuffer[JSONObject] = ListBuffer()
            var key=""
            val map: mutable.HashMap[String, ListBuffer[JSONObject]] = new mutable.HashMap()
            for (obj <- x._2) {
                val lng = obj.getString("lng")
                val lat = obj.getString("lat")
                val key = sliceUpCoordinate(lng, lat, 0.0003)
                var tag="WiFi列表完全一样,且妥距离大于50m"
                obj.put("tag",tag)
                if (map.contains(key)) {
                    val tmpList = map.get(key).get
                    tmpList += obj
                    map.put(key, tmpList)
                } else {
                    val lngkey1 = key.split("-")(0)
                    val latkey1 = key.split("-")(1)
                    var flag = true
                    /*
                    判断新的key和历史的key相差是否小于2，小于则认为两个key是一致的
                     */
                    breakable {
                        for (mapKey <- map.keySet) {
                            val lngkey2 = mapKey.split("-")(0)
                            val latkey2 = mapKey.split("-")(1)
                            if (math.abs(lngkey1.toLong - lngkey2.toLong) <= 2 && math.abs(latkey1.toLong - latkey2.toLong) <= 2) {
                                val tmpList = map.get(mapKey).get
                                tmpList += obj
                                map.put(mapKey, tmpList)
                                flag = false
                                break
                            }
                        }
                    }
                    if (flag) {
                        val tmpList: ListBuffer[JSONObject] = ListBuffer()
                        tmpList += obj
                        map.put(key, tmpList)
                    }
                }
            }
            if (map.size > 0) {
                var maxSize = 0L
                for(dataKey<-map.keySet){
                    val datalist = map.get(dataKey).get
                    if (datalist.size > maxSize) {
                        tmplistBuffer = datalist
                        key=dataKey
                    }
                }
            }
            if(StringUtils.nonEmpty(key)){
                var maxlistBuffer: ListBuffer[JSONObject] = ListBuffer()
                for(dataObj<-tmplistBuffer){
                    dataObj.put("tag","")
                    maxlistBuffer+=dataObj
                }
                map.put(key,maxlistBuffer)

            }
            for(dataList<-map.values){
                listBuffer++=dataList
            }

            listBuffer
        })

        val fliterTuoTouDistOver50Rdd = judgeWifiRdd.filter(x => (!(StringUtils.nonEmpty(x.getString("tag")) && x.getString("tag").equals("WiFi列表完全一样,且妥距离大于50m"))))
        val tuoTouDistOver50Rdd = judgeWifiRdd.filter(x => StringUtils.nonEmpty(x.getString("tag")) && x.getString("tag").equals("WiFi列表完全一样,且妥距离大于50m"))
        val judgeAoiDistRdd = fliterTuoTouDistOver50Rdd.groupBy(x => x.getString("aoi_id")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataListBuffer: ListBuffer[JSONObject] = ListBuffer()
            var dataObj = new JSONObject()

            dataObj.put("aoiId", x._1)
            dataObj.put("type", "side")
            var array = new JSONArray()
            for (obj <- x._2) {
                val tmpObj = new JSONObject()
                val lng = obj.getString("lng")
                val lat = obj.getString("lat")
                if(StringUtils.nonEmpty(lng)&&StringUtils.nonEmpty(lat)){
                    tmpObj.put("lng", lng.toDouble)
                    tmpObj.put("lat", lat.toDouble)
                    array.add(tmpObj)
                    dataListBuffer += obj
                }

                if (array.size >= 200) {
                    dataObj.put("coors", array)
                    listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                    dataListBuffer = ListBuffer()
                    array = new JSONArray()
                    dataObj = new JSONObject()
                    dataObj.put("aoiId", x._1)
                    dataObj.put("type", "side")
                }


            }

            if (array.size >= 0) {
                dataObj.put("coors", array)
                listBuffer ++= getCoorAoiDist(dataListBuffer, dataObj)
                dataListBuffer = ListBuffer()
                array = new JSONArray()
                dataObj = new JSONObject()
                dataObj.put("aoiId", x._1)
                dataObj.put("type", "side")
            }
            listBuffer
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("过滤aoi距离不符后，数据量-----》"+judgeAoiDistRdd.count())
//        Thread.sleep(10000000)
        judgeAoiDistRdd.union(tjyRdd).union(fliterDistOver50Rdd).union(tuoTouDistOver50Rdd).distinct()

    }

    def getCoorAoiDist(dataList:ListBuffer[JSONObject],parmObj:JSONObject)={

        var nowHour = getHour()

        if(!(nowHour>=21||(nowHour>=0&&nowHour<9))){
            Thread.sleep(480)
        }else{
            Thread.sleep(240)
        }
        val listBuffer: ListBuffer[JSONObject] = ListBuffer()
        val resultSet=new mutable.HashSet[JSONObject]()
        var jSONObject=new JSONObject()
        jSONObject = try {
//            Thread.sleep(50)
            HttpUtils.urlConnectionPostJson(aoiCoorsDist,parmObj.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+parmObj.toString())
                val stackTraceElement = e.getStackTrace()(0)
                logger.error("系统出错，错误信息:"+e.toString()+" at "+stackTraceElement.getClassName()+"."+stackTraceElement.getMethodName()+":"+stackTraceElement.getLineNumber())
                null
            }
        }


        if(jSONObject!=null){
//            logger.error("respone data------->"+jSONObject.toString())
            val dataArr = JSONUtil.getJsonArrayFromObject(jSONObject, "data.coors")
            for(i <- 0 until dataArr.size){
                val nObject = dataArr.getJSONObject(i)
                val lng=nObject.getString("lng")
                val lat=nObject.getString("lat")
                val dist=nObject.getString("dist")
                for(j <- 0 until dataList.size){
                    val dataObj = dataList(j)
                    val dataLng=dataObj.getString("lng")
                    val dataLat=dataObj.getString("lat")
                    if(lng!=null&&dataLng!=null&&lat!=null&&dataLat!=null&&lng.equals(dataLng)&&lat.equals(dataLat)){
                        if(StringUtils.nonEmpty(dist)&&dist.toDouble<=10.0){
                            dataObj.put("aoi_side_dist",dist)
                            dataObj.put("tag","")
                        }else if(StringUtils.nonEmpty(dist)&&dist.toDouble>10.0){
                            dataObj.put("tag","aoi距离超过10m")
                        }
                    }else{
                        dataObj.put("tag","")

                    }
                    dataObj.put("aoi_interface_data",jSONObject)
                    listBuffer+=dataObj
//                    dataObj.put("village",jSONObject)
//                    listBuffer+=dataObj
                }
            }
        }
        listBuffer
    }

    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }

}
