package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.nloc.utils.MacKeySaltUtils
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.wifiapp.InitApWifiDataSecond.getMd5Key
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.{ListBuffer, Set}


/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-04-20 18:08
 * @TaskId:726910
 * @TaskName:
 * @Description:ap库wifi数据初始化-统计数据
 */

object InitApWifiDataThird {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","address","province","city","county","town","roodline","aoi","lon","lat","points","reliable","reserve1","reserve2","update_tag")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","bld_id","bld_key","address","province","city","county","town","roodline","aoi","building","lon","lat","points","reliable","reserve1","reserve2","update_tag")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","lon","lat","reserve1","reserve2","update_tag")
    val saveDetailKey=Array("key","wifi_list","upper_key","address","level","province","city","county","town","roodline","aoi","building","floor","room","lon","lat","points","reliable","reserve1","reserve2","update_tag")


    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val end_day=args(0)
        // mode init/merge
        val mode=args(1)
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("获取wifi指纹库中间数据")
        val wifiMidDataRdd = getWifiMidData(sparkSession, end_day)
        logger.error("开始计算wifi aoi数据")
        val apAoiWifiDataRdd = getApAoi(sparkSession, wifiMidDataRdd,mode,aoiWhiteMapBroad)
        logger.error("开始计算wifi build数据")
        val apBuildWifiDataRdd = getApBuild(sparkSession, wifiMidDataRdd,mode,bldWhiteMapBroad)
        logger.error("开始计算wifi index数据")
        val apIndexWifiData = getApIndex(sparkSession, wifiMidDataRdd,mode)
        logger.error("开始计算 wifi detail数据")
        val fingerDetailDataRdd = getFingerDetail(sparkSession,wifiMidDataRdd,mode)
        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apAoiWifiDataRdd, saveAoiKey, "dm_gis.wifi_finger_aoi_v1",null, 25)
        logger.error("存储wifi build数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apBuildWifiDataRdd, saveBuildKey, "dm_gis.wifi_finger_building_v1",null, 25)
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apIndexWifiData, saveIndexKey, "dm_gis.wifi_finger_index_v1",null, 25)
        logger.error("存储 wifi detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, fingerDetailDataRdd, saveDetailKey, "dm_gis.wifi_finger_detail_v1",null, 25)

    }

    def getWifiMidData(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |select operatime_new,eventtype,city_code,waybillno,consignee_addr,src_city_code,deliver_emp_code,id,un,ewl,tm,zx,zy,doing,aoi_key,bld_key,aoi_id,bld_id,province,city,county,town,roodline,aoi,building,floor,room,level,tag,consignee_addr address from dm_gis.wifi_finger_v1_mid where inc_day='$end_day' and aoi_id is not null and bld_id is not null and  aoi_id<>'' and bld_id<>'' and building<>'' and building!='null' and tag='ok'
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val wifiDataRdd = dataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("ewl")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        val ewl_dis = value.getString("ss")
                        val mac_key = MacKeySaltUtils.getWifiMacKey(value.getString("mac"))
                        tempObj.put("ewl_dis", ewl_dis)
                        tempObj.put("mac_key", mac_key)
                        listBuffer += tempObj
                    }
                }
            }
            listBuffer.iterator
        })


        wifiDataRdd


    }

    /**
     *
     * @param spark
     * @param wifiDataRdd
     * @return
     */
    def getApIndex(spark:SparkSession,wifiDataRdd: RDD[JSONObject],mode:String)={
        var sql=""
        if(mode.equals("init")){
            sql=s"""
                   |select
                   |wifi as key
                   |,aoi_key as finger_aoi
                   |,bld_key as finger_bld
                   |,finger_detail
                   |,floor
                   |,lon
                   |,lat
                   |from dm_gis.wifi_finger_ap_index
                   |""".stripMargin

        }else if(mode.equals("merge")){
            sql=
                """
                  |
                  |
                  |select * from dm_gis.wifi_finger_index_v1
                  |
                  |""".stripMargin

        }


        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val APwifiData = dataRdd.map(obj => (obj.getString("key"), obj))
        val resultRdd = wifiDataRdd.map(obj => {
            val mac_key = obj.getString("mac_key")
            val key=getHmodRowKey(mac_key, 100, 100, 1, 3)
            val aoi_key = getMd5Key(obj.getString("aoi_key"))
            val bld_key = getMd5Key(obj.getString("bld_key"))
            val floor = obj.getString("floor")
            val room = obj.getString("room")
            val md5DetaillKey=getMd5Key(obj.getString("bld_key") + floor + room)
            obj.put("aoi_key", aoi_key)
            obj.put("bld_key", bld_key)
            obj.put("finger_key",md5DetaillKey)
            obj.put("key", key)
            (key, obj)

        }).groupByKey().fullOuterJoin(APwifiData).map(x => {
            var dataObj = new JSONObject()
            if(!x._2._2.isEmpty){
                dataObj.fluentPutAll(x._2._2.get)
                var city_code=""
                if(mode.equals("merge")){
//                    dataObj.put("update_tag","0")
                    dataObj.put("update_tag","1")
                }else{
                    dataObj.put("update_tag","1")
                }
                if(!x._2._1.isEmpty){
                    var finger_aoi = x._2._2.get.getString("finger_aoi")
                    var finger_bld = x._2._2.get.getString("finger_bld")
                    var finger_detail = x._2._2.get.getString("finger_detail")
                    city_code=x._2._2.get.getString("city_code")
                    val aoiSet = new mutable.HashSet[String]()
                    val buildSet = new mutable.HashSet[String]()
                    val fingerSet = new mutable.HashSet[String]()
                    splitFingerList(finger_bld,buildSet)
                    splitFingerList(finger_aoi,aoiSet)
                    splitFingerList(finger_detail,fingerSet)
                    for(obj<-x._2._1.get){
                        val aoi_key = obj.getString("aoi_key")
                        val bld_key = obj.getString("bld_key")
                        val finger_key = obj.getString("finger_key")
                        if(!aoiSet.contains(aoi_key)){
                            aoiSet.add(aoi_key)
                        }
                        if(!buildSet.contains(bld_key)){
                            buildSet.add(bld_key)
                        }
                        if(!fingerSet.contains(finger_key)){
                            fingerSet.add(finger_key)
                        }

                    }
                    finger_aoi=aoiSet.mkString("")
                    finger_bld=buildSet.mkString("")
                    finger_detail=fingerSet.mkString("")
                    dataObj.put("update_tag","1")
                    dataObj.put("finger_aoi",finger_aoi)
                    dataObj.put("finger_bld",finger_bld)
                    dataObj.put("reserve1", city_code)
                    dataObj.put("finger_detail",finger_detail)


                }



            }else{


                var aoi_key = ""
                var bld_key = ""
                var finger_detail=""
                val zx = x._2._1.get.head.getString("zx")
                val zy = x._2._1.get.head.getString("zy")
                val key = x._2._1.get.head.getString("key")
                val city_code=x._2._1.get.head.getString("city_code")

                val aoiSet = new mutable.HashSet[String]()
                val buildSet = new mutable.HashSet[String]()
                val fingerSet = new mutable.HashSet[String]()
                for (obj <- x._2._1.get) {
                    aoiSet.add(obj.getString("aoi_key"))
                    buildSet.add(obj.getString("bld_key"))
                    fingerSet.add(obj.getString("finger_key"))
                }
                aoi_key = aoiSet.mkString("")
                bld_key = buildSet.mkString("")
                finger_detail=fingerSet.mkString("")
                dataObj.put("update_tag","1")
                dataObj.put("key", key)
                dataObj.put("finger_aoi", aoi_key)
                dataObj.put("finger_bld", bld_key)
                dataObj.put("lon", zx)
                dataObj.put("lat", zy)
                dataObj.put("reserve1", city_code)
                dataObj.put("finger_detail", finger_detail)
                dataObj.put("floor", "")
            }
            dataObj

        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算结果数据-----》"+resultRdd.count())
        resultRdd



    }

    def getApBuild(spark:SparkSession,wifiDataRdd: RDD[JSONObject],mode:String,bldWhiteMapBroad:Broadcast[Map[String, String]])={
        var sql=""
        if(mode.equals("init")){

            sql= s"""
                    |select
                    |key
                    |,wifi as wifi_list
                    |,upper_key
                    |,finger_list
                    |,bld_id
                    |,bld_key
                    |,address
                    |,province
                    |,city
                    |,county
                    |,town
                    |,aoi
                    |,building
                    |,lon
                    |,lat
                    |,point as points
                    |
                    |from dm_gis.wifi_finger_ap_building
                    |""".stripMargin

        }else if(mode.equals("merge")){

            sql=
                """
                  |
                  |select * from dm_gis.wifi_finger_building_v1
                  |""".stripMargin

        }




        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val ApBuildRdd = dataRdd.map(x => (x.getString("bld_key"), x))
        val resultRdd = wifiDataRdd.map(x => (x.getString("bld_key"), x)).groupByKey()
            .fullOuterJoin(ApBuildRdd).map(x => {
            val bldWhiteMap = bldWhiteMapBroad.value
            val dataObj = new JSONObject()
            dataObj.put("reliable",bldWhiteMap.getOrElse(x._1,"0"))
            if (!x._2._2.isEmpty) {
                if (!x._2._1.isEmpty) {
                    var wifi_num=1L
                    var wifi = x._2._2.get.getString("wifi_list")
                    var city_code=""
                    val wifiArr = try {
                        JSON.parseArray(wifi)
                    } catch {
                        case e: Exception => {
                            logger.error(e.getMessage)
                            new JSONArray()
                        }
                    }
                    var finger_list=x._2._2.get.getString("finger_list")

                    val fingerSet = new mutable.HashSet[String]()
                    splitFingerList(finger_list,fingerSet)
                    for (obj <- x._2._1.get) {
                        city_code=obj.getString("city_code")
                        val bld_key = obj.getString("bld_key")
                        val floor = obj.getString("floor")
                        val room = obj.getString("room")
                        val finger = getMd5Key(bld_key + floor + room)
                        if(StringUtils.nonEmpty(finger)){
                            fingerSet.add(finger)
                        }
                        val mac_key = obj.getString("mac_key")
                        if (!wifi.contains(mac_key)) {
                            wifi = wifi + "," + mac_key
                            val tmpObj = new JSONObject()
                            val ewl_dis = obj.getString("ewl_dis")
                            val tm = obj.getString("tm")
                            tmpObj.put("mac", mac_key)
                            tmpObj.put("sig", ewl_dis)
                            tmpObj.put("num", wifi_num)
                            tmpObj.put("time", tm)
                            tmpObj.put("source", "0110")
                            wifi_num+=1
                            wifiArr.add(tmpObj)
                        }
                    }
                    finger_list=fingerSet.mkString("")
                    dataObj.fluentPutAll(x._2._2.get)
                    dataObj.put("update_tag","1")
                    dataObj.put("reserve1", city_code)
                    dataObj.put("wifi_list", wifiArr.toString())
                    dataObj.put("finger_list", finger_list)

                } else {
                    dataObj.fluentPutAll(x._2._2.get)
                    if(mode.equals("merge")){
//                        dataObj.put("update_tag","0")
                        dataObj.put("update_tag","1")
                    }else{
                        dataObj.put("update_tag","1")
                    }

                }

            } else {
                if (!x._2._1.isEmpty) {
                    var md5BldId=getMd5Key(x._2._1.get.head.getString("bld_id"))
                    var key = math.abs(md5BldId.hashCode)%10+"_"+md5BldId
                    var wifiArr = new JSONArray()
                    var upper_key = getMd5Key(x._2._1.get.head.getString("aoi_id"))
                    var finger_list = ""
                    val fingerSet = new mutable.HashSet[String]()
                    var bld_id = x._2._1.get.head.getString("bld_id")
                    var bld_key = x._2._1.get.head.getString("bld_id")
                    var address = x._2._1.get.head.getString("address")
                    var province = x._2._1.get.head.getString("province")
                    var city = x._2._1.get.head.getString("city")
                    var city_code=x._2._1.get.head.getString("city_code")
                    var county = x._2._1.get.head.getString("county")
                    var town = x._2._1.get.head.getString("town")
                    var aoi = x._2._1.get.head.getString("aoi")
                    var building = x._2._1.get.head.getString("building")
                    var lon = ""
                    var lat = ""
                    var lon_cnt = 0L
                    var lon_all = 0.0
                    var lat_all = 0.0
                    var pointArr = new JSONArray()
                    val macSet = Set[String]()
                    for (obj <- x._2._1.get) {
                        val mac_key = obj.getString("mac_key")
                        val bld_key = obj.getString("bld_key")
                        val floor = obj.getString("floor")
                        val room = obj.getString("room")
                        val finger = getMd5Key(bld_key + floor + room)
                        if(StringUtils.nonEmpty(finger)){
                            fingerSet.add(finger)
                        }
                        if (!macSet.contains(mac_key)) {
                            macSet.add(mac_key)
                            val tmpObj = new JSONObject()
                            val poinObj = new JSONObject()
                            val ewl_dis = obj.getString("ewl_dis")
                            val tm = obj.getString("tm")
                            val zx = obj.getString("zx")
                            val zy = obj.getString("zy")
                            tmpObj.put("mac", mac_key)
                            tmpObj.put("sig", ewl_dis)
                            tmpObj.put("num", 1)
                            tmpObj.put("time", tm)
                            tmpObj.put("source", "0100")
                            wifiArr.add(tmpObj)
                            poinObj.put("x", zx)
                            poinObj.put("y", zy)
                            pointArr.add(poinObj)
                            if (zx != null && zx.nonEmpty && zy != null && zy.nonEmpty) {
                                lon_cnt += 1
                                lon_all += zx.toDouble
                                lat_all += zy.toDouble

                            }
                        }


                    }
                    if (lon_cnt > 0) {
                        lon = (lon_all / lon_cnt).toString
                        lat = (lat_all / lon_cnt).toString

                    }
                    finger_list=fingerSet.mkString("")
                    dataObj.put("key", key)
                    dataObj.put("wifi_list", wifiArr.toString())
                    dataObj.put("upper_key", upper_key)
                    dataObj.put("finger_list", finger_list)
                    dataObj.put("bld_id", bld_id)
                    dataObj.put("bld_key", bld_key)
                    dataObj.put("address", address)
                    dataObj.put("province", province)
                    dataObj.put("city", city)
                    dataObj.put("reserve1", city_code)
                    dataObj.put("county", county)
                    dataObj.put("town", town)
                    dataObj.put("aoi", aoi)
                    dataObj.put("building", building)
                    dataObj.put("lon", lon)
                    dataObj.put("lat", lat)
                    dataObj.put("points", pointArr.toString())

                }


            }
            dataObj

        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算结果数据-----》"+resultRdd.count())
        resultRdd

    }

    def getApAoi(spark:SparkSession,wifiDataRdd: RDD[JSONObject],mode:String,aoiWhiteMapBroad:Broadcast[Map[String, String]])={
        var sql=""
        if(mode.equals("init")){
            sql=
                s"""
                   |select
                   |key
                   |,wifi as wifi_list
                   |,finger_list
                   |,province
                   |,city
                   |,county
                   |,town
                   |,aoi_id
                   |,aoi_key
                   |,address
                   |,aoi
                   |,cast(lon as string) lon
                   |,cast(lat as string) lat
                   |,point as points
                   |from dm_gis.wifi_finger_ap_aoi
                   |""".stripMargin
        }else if(mode.equals("merge")){
            sql=
                """
                  |
                  |select * from dm_gis.wifi_finger_aoi_v1
                  |
                  |""".stripMargin
        }



        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val ApBuildRdd = dataRdd.map(x => (x.getString("aoi_id"), x))
        val resultRdd = wifiDataRdd.map(x => (x.getString("aoi_id"), x)).groupByKey()
            .fullOuterJoin(ApBuildRdd).map(x => {
            val aoiWhiteMap = aoiWhiteMapBroad.value
            val dataObj = new JSONObject()
            dataObj.put("reliable",aoiWhiteMap.getOrElse(x._1,"0"))
            if (!x._2._2.isEmpty) {
                if (!x._2._1.isEmpty) {
                    var finger_list =  x._2._2.get.getString("finger_list")
                    var wifi_num=1L
                    var wifi = x._2._2.get.getString("wifi_list")
                    val fingerSet = new mutable.HashSet[String]()
                    var city_code=""
                    splitFingerList(finger_list,fingerSet)
                    val wifiArr = try {
                        JSON.parseArray(wifi)
                    } catch {
                        case e: Exception => {
                            logger.error(e.getMessage)
                            new JSONArray()
                        }
                    }

                    for (obj <- x._2._1.get) {
                        val mac_key = obj.getString("mac_key")
                        city_code=obj.getString("city_code")
                        if (!wifi.contains(mac_key)) {
                            wifi = wifi + "," + mac_key
                            val tmpObj = new JSONObject()
                            val ewl_dis = obj.getString("ewl_dis")
                            val tm = obj.getString("tm")
                            tmpObj.put("mac", mac_key)
                            tmpObj.put("sig", ewl_dis)
                            tmpObj.put("num", wifi_num)
                            tmpObj.put("time", tm)
                            tmpObj.put("source", "0110")
                            wifi_num+=1
                            wifiArr.add(tmpObj)
                        }
                        fingerSet.add(getMd5Key(obj.getString("bld_id")))
                    }
                    dataObj.fluentPutAll(x._2._2.get)
                    dataObj.put("update_tag","1")
                    finger_list=fingerSet.mkString("")
                    dataObj.put("finger_list", finger_list)
                    dataObj.put("wifi_list", wifiArr.toString())
                    dataObj.put("reserve1", city_code)


                } else {
                    dataObj.fluentPutAll(x._2._2.get)
                    if(mode.equals("merge")){
//                        dataObj.put("update_tag","0")
                        dataObj.put("update_tag","1")

                    }else{
                        dataObj.put("update_tag","1")
                    }


                }

            } else {
                if (!x._2._1.isEmpty) {
                    val md5AoiId = getMd5Key(x._2._1.get.head.getString("aoi_id"))
                    var key = math.abs(md5AoiId.hashCode)%10+"_"+md5AoiId
                    var wifiArr = new JSONArray()
//                    var upper_key = getMd5Key(x._2._1.get.head.getString("aoi_id"))
                    var finger_list = ""

                    var aoi_id = x._2._1.get.head.getString("aoi_id")
                    var city_code = x._2._1.get.head.getString("city_code")
                    var aoi_key = x._2._1.get.head.getString("aoi_id")
                    var address = x._2._1.get.head.getString("address")
                    var province = x._2._1.get.head.getString("province")
                    var city = x._2._1.get.head.getString("city")
                    var county = x._2._1.get.head.getString("county")
                    var town = x._2._1.get.head.getString("town")
                    var aoi = x._2._1.get.head.getString("aoi")
//                    var aoi = x._2._1.get.head.getString("aoi")
//                    var building = x._2._1.get.head.getString("building")
                    var lon = ""
                    var lat = ""
                    var lon_cnt = 0L
                    var lon_all = 0.0
                    var lat_all = 0.0
                    var pointArr = new JSONArray()
                    val fingerSet = new mutable.HashSet[String]()
                    val macSet = Set[String]()
                    for (obj <- x._2._1.get) {
                        val mac_key = obj.getString("mac_key")
                        if (!macSet.contains(mac_key)) {
                            macSet.add(mac_key)
                            val tmpObj = new JSONObject()
                            val poinObj = new JSONObject()
                            val ewl_dis = obj.getString("ewl_dis")
                            val tm = obj.getString("tm")
                            val zx = obj.getString("zx")
                            val zy = obj.getString("zy")
                            tmpObj.put("mac", mac_key)
                            tmpObj.put("sig", ewl_dis)
                            tmpObj.put("num", 1)
                            tmpObj.put("time", tm)
                            tmpObj.put("source", "0100")
                            wifiArr.add(tmpObj)
                            poinObj.put("x", zx)
                            poinObj.put("y", zy)
                            pointArr.add(poinObj)
                            fingerSet.add(getMd5Key(obj.getString("bld_id")))

                            if (zx != null && zx.nonEmpty && zy != null && zy.nonEmpty) {
                                lon_cnt += 1
                                lon_all += zx.toDouble
                                lat_all += zy.toDouble

                            }
                        }


                    }
                    if (lon_cnt > 0) {
                        lon = (lon_all / lon_cnt).toString
                        lat = (lat_all / lon_cnt).toString

                    }

                    dataObj.put("key", key)
                    dataObj.put("update_tag","1")
                    dataObj.put("wifi_list", wifiArr.toString())
                    finger_list=fingerSet.mkString("")
                    dataObj.put("finger_list", finger_list)
                    dataObj.put("address", address)
                    dataObj.put("aoi_id", aoi_id)
                    dataObj.put("aoi_key", aoi_key)
                    dataObj.put("province", province)
                    dataObj.put("city", city)
                    dataObj.put("county", county)
                    dataObj.put("town", town)
                    dataObj.put("aoi", aoi)
                    dataObj.put("lon", lon)
                    dataObj.put("lat", lat)
                    dataObj.put("reserve1", city_code)
                    dataObj.put("points", pointArr.toString())
                }
            }
            dataObj

        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算结果数据-----》"+resultRdd.count())
        resultRdd

    }
    def splitFingerList(fingerList:String,fingerSet:mutable.HashSet[String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/16){
                    fingerSet.add(fingerList.substring(i*16,(i+1)*16))

                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def getFingerDetail(spark:SparkSession,wifiDataRdd: RDD[JSONObject],mode:String)={

        var sql=
            """
              |
              |select * from dm_gis.wifi_finger_detail_v1
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val detailRdd = dataRdd.map(x => (x.getString("key"), x))
        val resultRdd=wifiDataRdd.map(obj => {
            val bld_key = obj.getString("bld_key")
            val floor = obj.getString("floor")
            val room = obj.getString("room")
            if(StringUtils.nonEmpty(floor)||StringUtils.nonEmpty(room)){
                val md5DetaillKey=getMd5Key(bld_key + floor + room)
                val key = math.abs(md5DetaillKey.hashCode)%10+"_"+md5DetaillKey
                obj.put("key", key)
                (key, obj)
            }else{
                ("",null)
            }

        }).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey().fullOuterJoin(detailRdd).map(x=>{
            val dataObj = new JSONObject()
            if(!x._2._2.isEmpty){
                dataObj.fluentPutAll(x._2._2.get)
                var city_code=""
                if(mode.equals("merge")){
                    dataObj.put("update_tag","1")
//                    dataObj.put("update_tag","0")
                }else{
                    dataObj.put("update_tag","1")
                }
                if(!x._2._1.isEmpty){
                    val macSet = Set[String]()
                    var wifi = dataObj.getString("wifi_list")
                    val wifiArr = try {
                        JSON.parseArray(wifi)
                    } catch {
                        case e: Exception => {
                            logger.error(e.getMessage)
                            new JSONArray()
                        }
                    }

                    for (obj <- x._2._1.get) {
                        val mac_key = obj.getString("mac_key")
                        city_code=obj.getString("city_code")
                        if (!wifi.contains(mac_key)) {
                            macSet.add(mac_key)
                            val tmpObj = new JSONObject()
                            val poinObj = new JSONObject()
                            val ewl_dis = obj.getString("ewl_dis")
                            val tm = obj.getString("tm")
                            val zx = obj.getString("zx")
                            val zy = obj.getString("zy")
                            tmpObj.put("mac", mac_key)
                            tmpObj.put("sig", ewl_dis)
                            tmpObj.put("num", 1)
                            tmpObj.put("time", tm)
                            tmpObj.put("source", "0100")
                            wifiArr.add(tmpObj)
                        }


                    }
                    dataObj.put("reserve1", city_code)
                    dataObj.put("wifi_list",wifiArr.toString())
                    dataObj.put("update_tag","1")

                }


            }else{

                var key = x._1
                var wifiArr = new JSONArray()
                var upper_key = getMd5Key(x._2._1.get.head.getString("bld_id"))
                var finger_list = ""
                var level = x._2._1.get.head.getString("level")
                var bld_key = x._2._1.get.head.getString("bld_id")
                var address = x._2._1.get.head.getString("address")
                var province = x._2._1.get.head.getString("province")
                var city = x._2._1.get.head.getString("city")
                var city_code = x._2._1.get.head.getString("city_code")
                var county = x._2._1.get.head.getString("county")
                var town = x._2._1.get.head.getString("town")
                var aoi = x._2._1.get.head.getString("aoi")
                var floor = x._2._1.get.head.getString("floor")
                var room = x._2._1.get.head.getString("room")
                var building = x._2._1.get.head.getString("building")
                var roodline = x._2._1.get.head.getString("roodline")
                var lon = ""
                var lat = ""
                var lon_cnt = 0L
                var lon_all = 0.0
                var lat_all = 0.0
                var pointArr = new JSONArray()
                val macSet = Set[String]()
                for (obj <- x._2._1.get) {
                    val mac_key = obj.getString("mac_key")
                    if (!macSet.contains(mac_key)) {
                        macSet.add(mac_key)
                        val tmpObj = new JSONObject()
                        val poinObj = new JSONObject()
                        val ewl_dis = obj.getString("ewl_dis")
                        val tm = obj.getString("tm")
                        val zx = obj.getString("zx")
                        val zy = obj.getString("zy")
                        tmpObj.put("mac", mac_key)
                        tmpObj.put("sig", ewl_dis)
                        tmpObj.put("num", 1)
                        tmpObj.put("time", tm)
                        tmpObj.put("source", "0100")
                        wifiArr.add(tmpObj)
                        poinObj.put("x", zx)
                        poinObj.put("y", zy)
                        pointArr.add(poinObj)
                        finger_list = finger_list + getMd5Key(obj.getString("bld_id"))
                        if (zx != null && zx.nonEmpty && zy != null && zy.nonEmpty) {
                            lon_cnt += 1
                            lon_all += zx.toDouble
                            lat_all += zy.toDouble

                        }
                    }


                }
                if (lon_cnt > 0) {
                    lon = (lon_all / lon_cnt).toString
                    lat = (lat_all / lon_cnt).toString

                }
                dataObj.put("key", key)
                dataObj.put("wifi_list", wifiArr.toString())
                dataObj.put("finger_list", finger_list)
                dataObj.put("address", address)
                dataObj.put("level", level)
                dataObj.put("upper_key", upper_key)
                dataObj.put("building", building)
                dataObj.put("province", province)
                dataObj.put("city", city)
                dataObj.put("reserve1", city_code)
                dataObj.put("county", county)
                dataObj.put("town", town)
                dataObj.put("aoi", aoi)
                dataObj.put("roodline", roodline)
                dataObj.put("floor", floor)
                dataObj.put("room", room)
                dataObj.put("lon", lon)
                dataObj.put("lat", lat)
                dataObj.put("points", pointArr.toString())
                dataObj.put("update_tag","1")
            }
            dataObj
        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("计算结果数据-----》"+resultRdd.count())
        resultRdd

    }

    def getFingerWhite(spark:SparkSession)={
        var sql=
            """
              |
              |
              |select guid,`level`,in_use from (
              |select guid,`level`,in_use,row_number()over(partition by guid,`level` order by update_date desc ) rnk from dm_gis.gis_wifi_finger_white_list
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("aoi")).map(obj => {
            val guid = obj.getString("guid")
            val in_use = obj.getString("in_use")
            (guid, in_use)
        }).collect().toMap

        val bldWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("bld")).map(obj => {
            val guid = obj.getString("guid")
            val in_use = obj.getString("in_use")
            (guid, in_use)
        }).collect().toMap
        (spark.sparkContext.broadcast(aoiWhiteMap),spark.sparkContext.broadcast(bldWhiteMap))



    }

    /**
     *
     * @param user_id key
     * @param mod 取模，也就是hbase预分region
     * @param covering 由于hbase region 是以固定位数为开头，比如预分region是100 ，则region开头是 00-99，因此这里需要加上100
     * @param start_index 截取的，起始
     * @param end_index 截取的，终止
     * @return
     * 以预分region 100请求示例：
     * val user_id = getHmodRowKey("4e47db3df1aed721", 100, 100, 1, 3)
     *
     * 如果只有10个预分区，那就直接 0-9，可以直接 (Math.abs(user_id.hashCode) % mod)+"_"+user_id
     */
    def getHmodRowKey(user_id:String,mod:Int,covering:Int,start_index:Int,end_index:Int)={
        val prefix = (Math.abs(user_id.hashCode) % mod) + covering
        val rowKey = prefix.toString.substring(start_index, end_index)+"_"+user_id

        rowKey

    }




}
