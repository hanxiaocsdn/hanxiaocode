package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, GeometryUtil}
import com.sf.gis.java.base.util.GeometryUtil.sliceUpCoordinate
import com.sf.gis.java.nloc.pojo.{ClusterWifiData, ClusterWifiDataNew}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.utils.MacKeySaltUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.math.BigInteger
import java.util
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-09-04 10:59
 * @TaskId:807922
 * @TaskName:
 * @Description:轨迹wifi转成ap库
 */

object TraceWifiGenerateAPWifi {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("row_key","date","adcode","lng","validity","src","changefreq","lat","acc","freq","available","incday")

    def main(args: Array[String]): Unit = {
        var start_day=args(0)
        var end_day=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取citycode adcode维表")
        val cityAdMapBroad = getCityAdcodeInfo(sparkSession)
        logger.error("获取ap库数据")
        val apWifiRdd = getApWifi(sparkSession)
        logger.error("获取轨迹wifi数据")
        val traceWifiRdd = getTraceWifi(sparkSession, end_day, start_day)
        logger.error("轨迹wifi数据生成ap库数据")
        val resultRdd = calcWifiData(apWifiRdd, traceWifiRdd, cityAdMapBroad,sparkSession)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_gis_export_wifi_tloc_dtl",null, 25)




    }

    def getTraceWifi(spark:SparkSession,end_day:String,start_day:String)={
        var sql=
            s"""
              |
              |select ewl,zx,zy,city_code from dm_gis.wifi_finger_v1_mid where inc_day<='$end_day' and inc_day>='$start_day'
              |
              |
              |""".stripMargin

        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val traceWifiRdd = originRdd.mapPartitions(itr => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- itr) {
                val ewl = obj.getString("ewl")
                val zx = obj.getString("zx")
                val zy = obj.getString("zy")
                val city_code = obj.getString("city_code")
                try {
                    val ewlArr = JSON.parseArray(ewl)
                    for (i <- 0 until (ewlArr.size())) {
                        val wifiObj = ewlArr.getJSONObject(i)
                        val ss = wifiObj.getString("ss")
                        val mac = MacKeySaltUtils.getWifiMacKey(wifiObj.getString("mac"))
                        val dataObj = new JSONObject()
                        dataObj.put("ss", ss)
                        dataObj.put("key", new BigInteger(wifiObj.getString("mac").replace(":", ""), 16).toString)
                        dataObj.put("mac", mac)
                        dataObj.put("x", zx)
                        dataObj.put("y", zy)
                        dataObj.put("city_code", city_code)
                        listBuffer += dataObj

                    }

                } catch {
                    case e: Exception => logger.error(e.getStackTrace)
                }

            }

            listBuffer.iterator
        }).filter(x => {
            val ss = x.getString("ss")
            if (StringUtils.nonEmpty(x.getString("x"))&&StringUtils.nonEmpty(x.getString("y"))&&StringUtils.nonEmpty(x.getString("mac"))&&StringUtils.nonEmpty(ss) && ss.toLong > (-100)&&ss.toLong<0) {
                true
            } else {
                false
            }

        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("轨迹wifi数据量："+traceWifiRdd.count())
        traceWifiRdd



    }

    def getApWifi(spark:SparkSession)={
        var sql=
            s"""
               |
               |select wifi from dm_gis.wifi_finger_ap_index
               |
               |
               |""".stripMargin

        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val apWifiRdd = originRdd.map(x => (x.getString("wifi").split("_")(1), x))
        apWifiRdd

    }

    def getCityAdcodeInfo(spark:SparkSession)={
        var sql=
            """
              |
              |select  city_code,adcode from tmp_dm_gis.city_adcode_info
              |
              |""".stripMargin

        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val cityAdMap = originRdd.map(x => {
            val city_code = x.getString("city_code")
            val adcode = x.getString("adcode")
            (city_code, adcode)


        }).collect().toMap

        spark.sparkContext.broadcast(cityAdMap)


    }
    def calcWifiData(apWifiRdd:RDD[(String,JSONObject)],traceWifiRdd:RDD[JSONObject],cityAdMapBroad:Broadcast[Map[String, String]],spark:SparkSession)={
        val increaseRdd = traceWifiRdd.map(x => (x.getString("mac"), x)).leftOuterJoin(apWifiRdd).map(x => {
            val leftObj = x._2._1
            val rightOP = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                if (rightOP.isEmpty) {
                    dataObj.fluentPutAll(leftObj)


                }

            }

            dataObj

        }).filter(x => StringUtils.nonEmpty(x.getString("mac"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("需要转换的轨迹wifi数据量："+increaseRdd.count())
        Spark.clearPersistWithoutId(spark,increaseRdd.id)

        val dataRdd = increaseRdd.groupBy(x => x.getString("mac")).flatMap(x => {
            val list = x._2.toList
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var clusterBuffer: ListBuffer[ClusterWifiDataNew] = ListBuffer()
            //将数据聚类
            calcClusterBySliceUpCoordinate(list, clusterBuffer)
            //剔除非法wifi
            clusterBuffer = judgePoint(clusterBuffer)
            for (i <- 0 until (clusterBuffer.size)) {
                val clusterData = clusterBuffer(i)
                val clusterNum = clusterData.getClusterNum
                if (clusterNum > 3) {
                    val dataObj = new JSONObject()
                    var wifi = ""
                    var sig_max = (-100L)
                    var sig_min = (-30L)
                    var lon = ""
                    var lat = ""
                    var validity = ""
                    var acc = ""
                    var lon_sig_min = ""
                    var lat_sig_min = ""
                    val fingerList = clusterData.getFingerList
                    var denominator_total = 0.0
                    var x_numerator_total = 0.0
                    var y_numerator_total = 0.0
                    var citycode=""
                    for (i <- 0 until (fingerList.size())) {
                        val fingerObj = fingerList.get(i)

                        val x = fingerObj.getString("x")
                        val y = fingerObj.getString("y")
                        val ss = fingerObj.getString("ss")
                        val mac = fingerObj.getString("key")
                        citycode=fingerObj.getString("city_code")
                        wifi = mac
                        if (StringUtils.nonEmpty(x) && StringUtils.nonEmpty(y) && StringUtils.nonEmpty(ss)) {
                            val denominator = (100 - Math.abs(ss.toLong)) / 100.0
                            val x_numerator = x.toDouble * denominator
                            val y_numerator = y.toDouble * denominator
                            denominator_total += denominator
                            x_numerator_total += x_numerator
                            y_numerator_total += y_numerator
                            if (ss.toLong > sig_max) {
                                sig_max = ss.toLong
                            }
                            if (ss.toLong < sig_min) {
                                sig_min = ss.toLong
                                lon_sig_min = x
                                lat_sig_min = y
                            }


                        }

                    }
                    lon = (x_numerator_total / denominator_total).toString
                    lat = (y_numerator_total / denominator_total).toString
                    if (sig_max >= (-30)) {
                        validity = "50"

                    } else {
                        validity = (50 * (Math.abs(sig_max) - 30) / 70).toString
                    }
                    if(StringUtils.nonEmpty(lon)&&StringUtils.nonEmpty(lat)&&StringUtils.nonEmpty(lon_sig_min)&&StringUtils.nonEmpty(lat_sig_min)){
                        acc = (GeometryUtil.getDistance(lon, lat, lon_sig_min, lat_sig_min) + Math.abs(sig_min)).toString
                    }



                    dataObj.put("row_key", getHmodRowKey(wifi, 100, 100, 1, 3))
                    dataObj.put("lng", lon)
                    dataObj.put("lat", lat)
                    dataObj.put("validity", validity)
                    dataObj.put("acc", acc)
                    dataObj.put("date", "null")
                    dataObj.put("changefreq", "null")
                    dataObj.put("freq", "null")
                    dataObj.put("src", "1")
                    dataObj.put("available", "1")
                    dataObj.put("city_code", citycode)
                    dataObj.put("sig_max",sig_max)
                    dataObj.put("sig_min",sig_min)
                    dataObj.put("x_numerator_total",x_numerator_total)
                    dataObj.put("y_numerator_total",y_numerator_total)
                    dataObj.put("denominator_total",denominator_total)
                    listBuffer += dataObj

                }


            }


            listBuffer.iterator
        })persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("聚合完的apwifi数据量---》"+dataRdd.count())
        dataRdd.take(100).foreach(println)


        val resultRdd = dataRdd.map(obj => {
            val cityAdMap = cityAdMapBroad.value
            val city_code = obj.getString("city_code")
            if (cityAdMap.contains(city_code)) {
                obj.put("adcode", cityAdMap.get(city_code).get)
            }
            obj.put("incday",DateUtil.getCurrentDate())



            obj
        })

        resultRdd


    }

    def judgePoint(clusterBuffer:ListBuffer[ClusterWifiDataNew])={
        var maxClusterNum=0L
        var clusterNumDiff=0L
        var clusterNumTotal=0L
        var maxClusterData=new ClusterWifiDataNew()
        var clusterBufferNew: ListBuffer[ClusterWifiDataNew] = ListBuffer()
        if(clusterBuffer.size==1){
            clusterBufferNew=clusterBuffer

        }else if(clusterBuffer.size==2){
            clusterNumDiff=clusterBuffer(0).getClusterNum-clusterBuffer(1).getClusterNum
            if(clusterNumDiff>3){
                clusterBufferNew+=clusterBuffer(0)


            }else if(clusterNumDiff<(-3)){
                clusterBufferNew+=clusterBuffer(1)

            }

        }else if(clusterBuffer.size>=3){
            for(i<-0 until clusterBuffer.size){
                if(clusterBuffer(i).getClusterNum>maxClusterNum){
                    maxClusterNum=clusterBuffer(i).getClusterNum
                    maxClusterData=clusterBuffer(i)
                }
            }
            for(i<-0 until clusterBuffer.size){
                if(clusterBuffer(i).getClusterNum!=maxClusterNum){
                    clusterNumTotal=clusterNumTotal+clusterBuffer(i).getClusterNum
                }
            }
            clusterNumDiff=maxClusterNum-clusterNumTotal
            if(clusterNumDiff>=3){
                clusterBufferNew+=maxClusterData

            }


        }

        clusterBufferNew


    }

    def calcClusterBySliceUpCoordinate(wifilist:List[JSONObject],clusterBuffer:ListBuffer[ClusterWifiDataNew])={
        val clusterMap = new mutable.HashMap[String, ClusterWifiDataNew]()
        for(i<-0 until(wifilist.size)){
            val wifiObj = wifilist(i)
            val x = wifiObj.getString("x")
            val y = wifiObj.getString("y")
            val key = sliceUpCoordinate(x, y,0.002)
            if(clusterMap.contains(key)){
                val clusterData=clusterMap.get(key).get
                val points = clusterData.getPoints
                val point=x+","+y
                points.add(point)
                val (lng,lat) = calcPoint(points)
                val list = clusterData.getFingerList
                list.add(wifiObj)
                clusterData.setFingerList(list)
                clusterData.setClusterNum(list.size())
                clusterData.setLng(lng.toString)
                clusterData.setLat(lat.toString)
                clusterData.setPoints(points)

                clusterMap.put(key,clusterData)
            }else{
                val lngkey1 = key.split("-")(0)
                val latkey1 = key.split("-")(1)
                var flag=true
                /*
                判断新的key和历史的key相差是否小于2，小于则认为两个key是一致的
                 */
                breakable{
                    for(mapKey<-clusterMap.keySet){
                        val lngkey2 = mapKey.split("-")(0)
                        val latkey2 = mapKey.split("-")(1)
                        if(math.abs(lngkey1.toLong-lngkey2.toLong)<=2&&math.abs(latkey1.toLong-latkey2.toLong)<=2){
                            val clusterData=clusterMap.get(mapKey).get
                            val points = clusterData.getPoints
                            val point=x+","+y
                            points.add(point)
                            val (lng,lat) = calcPoint(points)
                            val list = clusterData.getFingerList
                            list.add(wifiObj)
                            clusterData.setFingerList(list)
                            clusterData.setClusterNum(list.size())
                            clusterData.setLng(lng.toString)
                            clusterData.setLat(lat.toString)
                            clusterData.setPoints(points)
                            clusterMap.put(mapKey,clusterData)
                            flag=false
                            break
                        }
                    }

                }
                if(flag){
                    val data = new ClusterWifiDataNew
                    val fingerList = new util.ArrayList[JSONObject]()
                    val pointsList = new util.ArrayList[String]()
                    val point=x+","+y
                    pointsList.add(point)
                    fingerList.add(wifiObj)
                    data.setClusterNum(fingerList.size())
                    data.setLng(x)
                    data.setLat(y)
                    data.setPoints(pointsList)
                    data.setFingerList(fingerList)
                    clusterMap.put(key,data)
                }


            }
        }

        if(clusterMap.size>1){
            for(clusterData<-clusterMap.values){
                clusterBuffer+=clusterData
            }

        }


    }
    def calcPoint(points:util.List[String]) ={
        var lngall=0.0
        var latall=0.0
        var lng=0.0
        var lat=0.0
        for(i<- 0 until points.size()){
            lngall=lngall+points.get(i).split(",")(0).toDouble
            latall=latall+points.get(i).split(",")(1).toDouble

        }
        lng=lngall/points.size()
        lat=latall/points.size()
        (lng,lat)

    }

    def getHmodRowKey(user_id:String,mod:Int,covering:Int,start_index:Int,end_index:Int)={
        val prefix = (Math.abs(user_id.hashCode) % mod) + covering
        val rowKey = prefix.toString.substring(start_index, end_index)+"_"+user_id

        rowKey

    }

}
