package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.wifiapp.InitApWifiDataSecond.getMd5Key
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiData.{calcCenterPoint, cleanPoints, splitFingerList}
import com.sf.gis.scala.nloc.wifiapp.WifiAOIInfoDel.splitFingerAoiMap
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-07-31 14:32
 * @TaskId:786233
 * @TaskName:aoi变更之aoi拆分
 * @Description:
 */

object WifiAOIInfoSplit {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","city_code","address","province","city","county","town","village","aoi_name","lng","lat","points","reliable","inc_day","reserve1","reserve2")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","city_code","address","province","city","county","town","village","aoi_name","buildingname","lng","lat","points","inc_day","reliable","reserve1","reserve2")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","city_code","floor","lng","lat")
    val saveDetailKey=Array("key","wifi_list","upper_key","city_code","address","level","province","city","county","town","village","aoi_name","buildingname","floor","room","lng","lat","points","inc_day","reliable","reserve1","reserve2")

    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取aoi拆分数据")
        val delAoiInfoSetBro = getDivideAoiInfo(sparkSession)
        logger.error("标记删除aoi拆分数据")
        val (notDeleAoiRdd,deleteBldMapBro,deleteWifiMapBro)=markDivideAoiWifi(sparkSession,delAoiInfoSetBro)
        logger.error("获取楼栋维表")
        val poiInfoMapBro = getpoiInfo(sparkSession)
        logger.error("更新楼栋数据")
        val (updateBldRdd,updateFingerAoiWifiMapBro)=updateBldWifiData(sparkSession,deleteBldMapBro,poiInfoMapBro)
        logger.error("计算aoi拆分后的wifi指纹aoi数据")
        val wifiAoiRdd = calcWifiAoiData(updateBldRdd, notDeleAoiRdd)
        logger.error("清洗wifi指纹index数据")
        val wifiIndexRdd = updateWifi(sparkSession, updateFingerAoiWifiMapBro, deleteWifiMapBro)
        logger.error("存储wifi指纹楼栋数据")
        SparkWrite.save2HiveStaticNew(sparkSession, updateBldRdd, saveBuildKey, "dm_gis.dm_wifi_finger_bld_dtl",null, 25)
        logger.error("存储wifi指纹aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, wifiAoiRdd, saveAoiKey, "dm_gis.dm_wifi_finger_aoi_dtl",null, 25)
        logger.error("存储wifi指纹index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, wifiIndexRdd, saveIndexKey, "dm_gis.dm_wifi_finger_index_dtl",null, 25)




    }

    def getDivideAoiInfo(spark:SparkSession)={
        var sql="select * from dm_gis.dm_aoi_div_info"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val delAoiInfoSet = dataRdd.map(obj => obj.getString("aoi_id")).collect().toSet
        spark.sparkContext.broadcast(delAoiInfoSet)

    }

    def markDivideAoiWifi(spark:SparkSession,divAoiInfoSetBro:Broadcast[Set[String]])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_aoi_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val markDeleAoiRdd=dataRdd.map(obj=>{
            val divAoiInfoSet = divAoiInfoSetBro.value
            val aoi_id = obj.getString("aoi_id")
            val dataObj = new JSONObject()
            if (divAoiInfoSet.contains(aoi_id)) {
                val key = obj.getString("key").split("_")(1)
                val finger_list = obj.getString("finger_list")
                val wifi_list = obj.getString("wifi_list")
                dataObj.put("key", obj.getString("key"))
                dataObj.put("finger_list", finger_list)
                dataObj.put("wifi_list", wifi_list)
                dataObj.put("isdelete", true)


            } else {
                dataObj.fluentPutAll(obj)

            }
            dataObj


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记删除数据量---》"+markDeleAoiRdd.count())
        val deleteAoiRdd = markDeleAoiRdd.filter(obj => StringUtils.nonEmpty(obj.getString("isdelete")) && obj.getString("isdelete").toBoolean)
        val notDeleAoiRdd = markDeleAoiRdd.filter(obj => (!StringUtils.nonEmpty(obj.getString("isdelete"))))
        val deleteBldMap = deleteAoiRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val fingerMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val key = obj.getString("key").split("_")(1)
                val finger_list = obj.getString("finger_list")
                val fingerSet = new mutable.HashSet[String]()
                splitFingerList(finger_list, fingerSet)
                for (finger_bld <- fingerSet) {
                    if(fingerMap.contains(finger_bld)){
                        fingerMap.put(finger_bld,fingerMap.get(finger_bld).get+key)

                    }else{
                        fingerMap.put(finger_bld,key)

                    }
                }
            }
            for(finger_key<-fingerMap.keySet){
                listBuffer += ((finger_key, fingerMap.get(finger_key).get))

            }

            listBuffer.iterator

        }).collect().toMap

        val deleteWifiMap=deleteAoiRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val wifiMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val key = obj.getString("key").split("_")(1)
                val wifi_list = obj.getString("wifi_list")
                try{
                    val wifiArr = JSON.parseArray(wifi_list)
                    for (i <- 0 until wifiArr.size()) {
                        val wifiObj = wifiArr.getJSONObject(i)
                        val wifiKey = getMd5Key(wifiObj.getString("mac"))
                        if(wifiMap.contains(wifiKey)){
                            wifiMap.put(wifiKey,wifiMap.get(wifiKey).get+key)
                        }else{
                            wifiMap.put(wifiKey,key)

                        }
                    }
                }catch {case e:Exception=>logger.error("")}

            }
            for(wifi_key<-wifiMap.keySet){
                listBuffer += ((wifi_key, wifiMap.get(wifi_key).get))
            }
            listBuffer.iterator
        }).collect().toMap
        ((notDeleAoiRdd,spark.sparkContext.broadcast(deleteBldMap),spark.sparkContext.broadcast(deleteWifiMap)))

    }

    def getpoiInfo(spark:SparkSession)={
        var sql="select guid,aoi_id from dm_gis.poi_info where inc_day='20230730'"
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val poiInfoMap = dataRdd.map(obj => {
            val guid = obj.getString("guid")
            val aoi_id = obj.getString("aoi_id")
            (guid, aoi_id)

        }).collect().toMap
        spark.sparkContext.broadcast(poiInfoMap)

    }

    def updateBldWifiData(spark:SparkSession,deleteBldMapBro:Broadcast[Map[String, String]],poiInfoMapBro:Broadcast[Map[String, String]])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_bld_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val updateBldRdd = dataRdd.map(obj => {
            val deleteBldMap = deleteBldMapBro.value
            val poiInfoMap = poiInfoMapBro.value
            val key = obj.getString("key").split("_")(1)
            val bld_id = obj.getString("buildingid")

            var finger_aoi = ""
            if (deleteBldMap.contains(key)) {
                val upper_key = obj.getString("upper_key")
                val fingerSet = new mutable.HashSet[String]()
                splitFingerList(upper_key, fingerSet)
                val errorAois = deleteBldMap.get(key).get
                val fingerErrorSet = new mutable.HashSet[String]()
                splitFingerList(errorAois, fingerErrorSet)
                for(errorAoi<-fingerErrorSet){
                    if(fingerSet.contains(errorAoi)){
                        fingerSet.remove(errorAoi)
                        if (poiInfoMap.contains(bld_id)) {
                            fingerSet.add(getMd5Key(poiInfoMap.get(bld_id).get))
                            finger_aoi = finger_aoi + getMd5Key(poiInfoMap.get(bld_id).get)
                            obj.put("upper_key", fingerSet.mkString(""))
                            obj.put("isdelete", true)
                            obj.put("aoi_id",poiInfoMap.get(bld_id).get)


                        }
                    }
                }
            }
            obj.put("finger_aoi", finger_aoi)
            obj

        })
        val markRdd = updateBldRdd.filter(obj => StringUtils.nonEmpty(obj.getString("isdelete")) && obj.getString("isdelete").toBoolean)
        val updateFingerAoiWifiMap = markRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val wifiMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val finger_aoi = obj.getString("finger_aoi")
                val wifi_list = obj.getString("wifi_list")
                try {
                    val wifiArr = JSON.parseArray(wifi_list)
                    for (i <- 0 until wifiArr.size()) {
                        val wifiObj = wifiArr.getJSONObject(i)
                        val wifiKey = getMd5Key(wifiObj.getString("mac"))
                        if(wifiMap.contains(wifiKey)){
                            wifiMap.put(wifiKey,wifiMap.get(wifiKey).get+finger_aoi)
                        }else{
                            wifiMap.put(wifiKey,finger_aoi)
                        }
                    }
                } catch {
                    case e: Exception => logger.error("")
                }

            }
            for(wifi_key<-wifiMap.keySet){
                listBuffer += ((wifi_key, wifiMap.get(wifi_key).get))

            }

            listBuffer.iterator

        }).collect().toMap
        ((updateBldRdd,spark.sparkContext.broadcast(updateFingerAoiWifiMap)))

    }

    def calcWifiAoiData(updateBldRdd:RDD[JSONObject],deleteAoiRdd:RDD[JSONObject])={
        val updateAoiRdd = updateBldRdd.filter(obj => StringUtils.nonEmpty(obj.getString("isdelete")) && obj.getString("isdelete").toBoolean).mapPartitions(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- x) {
                val upper_key = obj.getString("upper_key")
                val fingerSet = new mutable.HashSet[String]()
                splitFingerList(upper_key, fingerSet)
                for (aoi_key <- fingerSet) {
                    val tmpObj = new JSONObject()
                    tmpObj.fluentPutAll(obj)
                    tmpObj.put("upper_key", aoi_key)
                    listBuffer += tmpObj
                }
            }
            listBuffer.iterator

        }).groupBy(x => x.getString("upper_key")).flatMap(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var key = math.abs(x._1.hashCode) % 10 + "_" + x._1
            val wifiMap = new mutable.HashMap[String, JSONObject]()
            val fingerSet = new mutable.HashSet[String]()
            val dataObj = new JSONObject()
            var aoi_id = ""
            var aoi_key = ""
            var city_code=""
            var address = ""
            var province = ""
            var city = ""
            var county = ""
            var town = ""
            var village=""
            var roodline = ""
            var aoi = ""
            var reliable = ""
            var reserve1 = ""
            var update_tag = ""
            var inc_day=""
            var pointAllArr = new JSONArray()

            for (obj <- x._2) {
                val wifi_list = obj.getString("wifi_list")
                val finger_list = obj.getString("finger_list")
                val pointstr = obj.getString("points")
                var wifiArr = new JSONArray()
                var pointArr = new JSONArray()
                try {
                    wifiArr = JSON.parseArray(wifi_list)
                    pointArr = JSON.parseArray(pointstr)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                    }
                }

                aoi_id=obj.getString("aoi_id")
                aoi_key=obj.getString("aoi_key")
                province = obj.getString("province")
                city_code = obj.getString("city_code")
                city = obj.getString("city")
                county = obj.getString("county")
                town = obj.getString("town")
                village=obj.getString("village")
                roodline = obj.getString("roodline")
                aoi = obj.getString("aoi_name")
                reserve1 = obj.getString("reserve1")
                update_tag = obj.getString("update_tag")
                inc_day = obj.getString("inc_day")
                reliable = obj.getString("reliable")
                splitFingerList(finger_list, fingerSet)
                for (i <- 0 until wifiArr.size()) {
                    val wifiObj = wifiArr.getJSONObject(i)
                    val mac = wifiObj.getString("mac")
                    if (wifiMap.contains(mac)) {
                        val num = wifiObj.getString("num")
                        val time = wifiObj.getString("time")
                        val source = wifiObj.getString("source")
                        val temObj = wifiMap.get(mac).get
                        var num_t = temObj.getString("num")
                        var time_t = temObj.getString("time")
                        var source_t = temObj.getString("source")
                        if (StringUtils.nonEmpty(num) && StringUtils.nonEmpty(time) && StringUtils.nonEmpty(source) && StringUtils.nonEmpty(num_t) && StringUtils.nonEmpty(time_t) && StringUtils.nonEmpty(source_t)) {
                            num_t = (num_t.toLong + num.toLong).toString
                            if (time.toLong > time_t.toLong) {
                                time_t = time
                            }
                            if (source.toLong > source_t.toLong) {
                                source_t = source
                            }
                            temObj.put("num", num_t)
                            temObj.put("time", time_t)
                            temObj.put("source", source_t)
                        }
                        wifiMap.put(mac, temObj)
                    } else {
                        wifiMap.put(mac, wifiObj)
                    }
                }
                for (i <- 0 until pointArr.size()) {
                    pointAllArr.add(pointArr.getJSONObject(i))
                }
            }
            val pointsAll = cleanPoints(pointAllArr.toString())
            val (lng, y) = calcCenterPoint(pointsAll)
            address = province + city + county + town +village+ roodline + aoi
            val wifiArr = new JSONArray()
            for (wifi <- wifiMap.values) {
                wifiArr.add(wifi)
            }
            dataObj.put("key", key)
            dataObj.put("wifi_list", wifiArr.toString())
            dataObj.put("finger_list", fingerSet.mkString(""))
            dataObj.put("aoi_id", aoi_id)
            dataObj.put("aoi_key", aoi_key)
            dataObj.put("address", address)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("city_code", city_code)
            dataObj.put("inc_day", inc_day)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("village", village)
            dataObj.put("roodline", roodline)
            dataObj.put("aoi_name", aoi)
            dataObj.put("lng", lng)
            dataObj.put("lat", y)
            dataObj.put("points", pointsAll)
            dataObj.put("reliable", reliable)
            dataObj.put("reserve1", reserve1)
            dataObj.put("update_tag", update_tag)
            listBuffer += dataObj
            listBuffer
        })
        deleteAoiRdd.union(updateAoiRdd).distinct()

    }

    def updateWifi(spark:SparkSession,updateFingerAoiWifiMapBro:Broadcast[Map[String, String]],deleteWifiMapBro:Broadcast[Map[String, String]]): RDD[JSONObject] ={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_index_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val wifiRdd = dataRdd.map(obj => {
            val deleteAoiWifiMap = updateFingerAoiWifiMapBro.value
            val deleteWifiMap = deleteWifiMapBro.value
            val key = obj.getString("key").split("_")(1)
            if (deleteAoiWifiMap.contains(key)) {
                val finger_aoi = obj.getString("finger_aoi")
                val fingerSet = new mutable.HashSet[String]()
                val aoiMap = new mutable.HashMap[String,String]()
                splitFingerAoiMap(finger_aoi,aoiMap)
//                splitFingerList(finger_aoi, fingerSet)
                val errorAois = deleteAoiWifiMap.get(key).get
                val fingerErrorSet = new mutable.HashSet[String]()
                splitFingerList(errorAois, fingerErrorSet)
                for(errorAoi<-fingerErrorSet){
//                    fingerSet.remove(errorAoi)
                    aoiMap.remove(errorAoi)
                }

                obj.put("finger_aoi", aoiMap.values.mkString(""))
//                obj.put("finger_aoi", fingerSet.mkString(""))
            }
            if(deleteWifiMap.contains(key)){
                val finger_aoi = obj.getString("finger_aoi")
                val fingerSet = new mutable.HashSet[String]()
                val aoiMap = new mutable.HashMap[String,String]()
                splitFingerAoiMap(finger_aoi,aoiMap)
//                splitFingerList(finger_aoi, fingerSet)
                val errorAois = deleteAoiWifiMap.get(key).get
                val fingerErrorSet = new mutable.HashSet[String]()
                splitFingerList(errorAois, fingerErrorSet)
                for(errorAoi<-fingerErrorSet){
//                    fingerSet.remove(errorAoi)
                    aoiMap.remove(errorAoi)
                }

                obj.put("finger_aoi", aoiMap.values.mkString(""))
//                obj.put("finger_aoi", fingerSet.mkString(""))

            }
            obj
        })

        wifiRdd
    }

}
