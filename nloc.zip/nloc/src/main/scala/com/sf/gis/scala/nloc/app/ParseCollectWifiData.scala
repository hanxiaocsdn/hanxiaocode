package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.gis.scala.nloc.utils.MacKeySaltUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util.Calendar
import scala.util.Random
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-08-10 09:39
 * @TaskId:788849
 * @TaskName:
 * @Description:wifi指纹库-解析采集wifi数据
 */

object ParseCollectWifiData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("timestamp","wifi_list","bt_list","aoi_key","bld_key","aoi_id","bld_id","address","province","city","county","town","roodline","aoi","building","floor","room","level","lon","lat")
    val atdispatchUrl="http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&ak=b148e898efbc4b07a74406d44acf3ab2"
    val buildingUrl ="http://gis-int.int.sfdc.com.cn:1080/building/address/identify?showserver=true&ak=7a04c8f420ec4a67a257d7dfc70135a2&cityCode=%s&address=%s"

    def main(args: Array[String]): Unit = {

        val end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("解析日志")
        val resultRdd = parseLog(sparkSession, end_day)
        logger.error("存储数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_wifi_collect_data_dtl_di",Array(("inc_day", end_day)), 25)




    }

    def parseLog(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |
              |
              |select * from dm_gis.dm_collect_wifi_log_flink_dtl_di where inc_day='$end_day'
              |
              |""".stripMargin

        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val atPaiRdd = originRdd.map(obj => {
            val log = obj.getString("log")
            try {
                val dataObj = JSON.parseObject(log)
                val timestamp = JSONUtil.getJsonVal(dataObj, "timestamp", "")
                val province = JSONUtil.getJsonVal(dataObj, "prov", "")
                val city = JSONUtil.getJsonVal(dataObj, "city", "")
                val citycode = JSONUtil.getJsonVal(dataObj, "citycode", "")
                val county = JSONUtil.getJsonVal(dataObj, "county", "")
                val aoi = JSONUtil.getJsonVal(dataObj, "aoi", "")
                val building = JSONUtil.getJsonVal(dataObj, "building", "")
                val room = JSONUtil.getJsonVal(dataObj, "room", "")
                val wifiJsArr = JSONUtil.getJsonArrayFromObject(dataObj, "wifi")
                val btJsArr = JSONUtil.getJsonArrayFromObject(dataObj, "bt")
                val gnssJsArr = JSONUtil.getJsonArrayFromObject(dataObj, "gnss")
                val btArr = new JSONArray()
                val wifiArr = new JSONArray()
                var address = province + city + county + aoi + building + room
                var lon=0.0
                var lat=0.0
                var loncnt=0L

                for (i <- 0 until wifiJsArr.size()) {
                    val wifiObj = wifiJsArr.getJSONObject(i)
                    val tmpObj = new JSONObject()
                    val sig = JSONUtil.getJsonVal(wifiObj, "level", "")
                    val mac = MacKeySaltUtils.getWifiMacKey(JSONUtil.getJsonVal(wifiObj, "BSSID", ""))
                    tmpObj.put("mac", mac)
                    tmpObj.put("sig", sig)
                    tmpObj.put("time", timestamp)
                    tmpObj.put("num", "1")
                    tmpObj.put("source", "1000")
                    wifiArr.add(tmpObj)

                }
                for (i <- 0 until gnssJsArr.size()) {
                    val gnssObj = gnssJsArr.getJSONObject(i)
                    val lon_ = JSONUtil.getJsonVal(gnssObj, "lon", "")
                    val lat_ = JSONUtil.getJsonVal(gnssObj, "lat", "")
                    if(StringUtils.nonEmpty(lon_)&&StringUtils.nonEmpty(lat_)){
                        lon+=lon_.toDouble
                        lat+=lat_.toDouble
                        loncnt+=1

                    }
                }


                for (i <- 0 until btJsArr.size()) {
                    val btObj = btJsArr.getJSONObject(i)
                    val tmpObj = new JSONObject()
                    val mac = "bt_"+MacKeySaltUtils.getWifiMacKey(JSONUtil.getJsonVal(btObj, "address", ""))
                    tmpObj.put("mac", mac)
                    tmpObj.put("sig", "-50")
                    tmpObj.put("time", timestamp)
                    tmpObj.put("num", "1")
                    tmpObj.put("source", "1000")
                    btArr.add(tmpObj)

                }
                val (aoi_id, aoi_code) = getAtdispatch(address, citycode)
                obj.put("timestamp", timestamp)
                obj.put("province", province)
                obj.put("city", city)
                obj.put("citycode", citycode)
                obj.put("county", county)
                obj.put("aoi", aoi)
                obj.put("building", building)
                obj.put("room", room)
                obj.put("wifi_list", wifiArr.toString())
                obj.put("bt_list", btArr.toString)
                obj.put("address", address)
                obj.put("aoi_id", aoi_id)
                obj.put("aoi_key", aoi_id)
                obj.put("lon", lon/loncnt)
                obj.put("lat", lat/loncnt)
                obj.put("level", "0")


            } catch {
                case e: Exception => logger.error(e.getMessage)
            }

            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取at派数据---》"+atPaiRdd.count())
        val resultRdd = atPaiRdd.map(obj => {
            val address = obj.getString("address")
            val city_code = obj.getString("city_code")
            val aoi_id = obj.getString("aoi_id")

            val (buildingName, lngbuild, latbuild, buildingId, bulidType, build_err_msg) = getBuildingName(address, city_code, aoi_id)
            obj.put("bld_id", buildingId)
            obj.put("bld_key", buildingId)
            obj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取楼栋识别派数据---》"+resultRdd.count())
        resultRdd



    }


    def getAtdispatch(addr:String,city:String)={



        var nowHour = getHour()
                while (!(nowHour>=19||(nowHour>=0&&nowHour<7))){
                    logger.error("当前时间为-----》"+nowHour+"---休眠1min")
                    Thread.sleep(1000*60)
                    nowHour = getHour()

                }

        Thread.sleep(600)
        val url=String.format(atdispatchUrl,addr.replace(" ",""),city)
        val response = HttpInvokeUtil.sendGet(url, "utf-8", 5)
        var aoi_id=""
        var aoi_code=""
        //        logger.error(" at派 服务result is --->"+response)
        if(StringUtils.nonEmpty(response)){
            var jsonObj=try{
                JSON.parseObject(response).getJSONObject("result")
            }catch{
                case e:Exception=>{
                    logger.error("error url ----->"+url+"  error data --->"+response)
                    new JSONObject()
                }
            }
            var resultObject=new JSONObject()
            if(!jsonObj.isEmpty) {
                try{
                    resultObject = jsonObj.getJSONArray("tcs").getJSONObject(0)
                }catch {case e:Exception=>{
                    logger.error("get at pai data erro-->"+e.getMessage)
                }}

            }
            aoi_id=JSONUtil.getJsonVal(resultObject,"aoiid","")
            aoi_code=JSONUtil.getJsonVal(resultObject,"aoicode","")
        }
        (aoi_id,aoi_code)

    }

    def getHour() ={
        val calendar = Calendar.getInstance
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        hour
    }


    def getBuildingName(addr:String,citycode:String,aoi_id:String): (String, String, String, String, String, String) ={

        //楼栋识别只有六个城市数据
        val citycodearr=Array("571","755","411","510","592","022")

        var nowHour = getHour()
        //楼栋识别只有六个城市数据



        val url=String.format(buildingUrl,citycode,addr)
        var buildingName=""
        var lngbuild=""
        var latbuild=""
        var buildingId=""
        var bulidType=""
        var resultObj="接口无返回值"
        var status=""
        var aoiId="null"
        var build_err_msg=""
        if(!citycodearr.contains(citycode)){
            return (buildingName,lngbuild,latbuild,buildingId,bulidType,build_err_msg)
        }

        if(!(nowHour>=19||(nowHour>=0&&nowHour<9))){
            Thread.sleep(500+Random.nextInt(100))
        }else{
            Thread.sleep(300+Random.nextInt(100))
        }
        var jSONObject=new JSONObject()
        breakable {
            for(i<- 0 until 5){
                jSONObject = try {
                    HttpUtils.urlConnectionGetJson(url, 5000)
                }
                catch {
                    case _=>{
                        logger.error("error url-----> "+url)
                        build_err_msg="接口无返回值"
                        null
                    }

                }
                status=JSONUtil.getJsonVal(jSONObject,"status","-1")
                if(status.equals("-1")){
                    logger.error("access faill---->"+jSONObject)



                }else{
                    break
                }
            }

        }

        //        GisUtil.getCoorDist()
        if(jSONObject!=null)
        {
            //                logger.error("error data ------>"+jSONObject)
            //                logger.error("error url-----> "+url)
            resultObj=jSONObject.toString()
            buildingName=try {
                jSONObject.getJSONObject("result").getString("buildingName")
            }catch {case _=>{
                ""
            }}

            lngbuild=try {
                jSONObject.getJSONObject("result").getString("x")
            }catch {case _=>{
                ""
            }}

            latbuild=try {
                jSONObject.getJSONObject("result").getString("y")
            }catch {case _=>{
                ""
            }}

            aoiId=JSONUtil.getJsonVal(jSONObject, "result.aoiId", "")
            bulidType = JSONUtil.getJsonVal(jSONObject, "result.type", "")
            if(bulidType.equals("aoi_one")){
                buildingId=""
            }else{
                buildingId= JSONUtil.getJsonVal(jSONObject, "result.buildingId", "")
                val geocoderArray = JSONUtil.getJsonArrayFromObject(jSONObject, "result.others.geocoder")
                for(i <- 0 until geocoderArray.size()){
                    val obj = geocoderArray.getJSONObject(i)
                    if(buildingId.nonEmpty&&buildingId.equals(JSONUtil.getJsonVal(obj,"id",""))){
                        buildingId= JSONUtil.getJsonVal(obj, "cell1", "").split("\\|")(0)
                    }else{
                        buildingId=""
                    }

                }
            }

            if(status.equals("-1")){
                build_err_msg=jSONObject.toString()
            }

        }
        if(!(aoi_id!=null&&aoi_id.nonEmpty&&aoiId!=null&&aoiId.nonEmpty&&aoi_id.equals(aoiId))){
            buildingId=""
            buildingName=""
        }


        //        (buildingName,url,jSONObject)
        (buildingName,lngbuild,latbuild,buildingId,bulidType,build_err_msg)
    }

}
