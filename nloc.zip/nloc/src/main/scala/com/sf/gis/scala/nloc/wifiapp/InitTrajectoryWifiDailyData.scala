package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.nloc.utils.MacKeySaltUtils
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.app.InitCollectWifiData.getMd5Key
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiData.{splitFingerList, splitFingerMap}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.{ListBuffer, Set}
import scala.util.Random


/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-10-30 18:08
 * @TaskId:726910
 * @TaskName:
 * @Description:轨迹wifi数据计算-新版-天级
 */

object InitTrajectoryWifiDailyData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","address")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","buildingname","address")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","buildingid","aoi_id","lng","lat","city_code","province","city","county","town","village","decrypt_wifi")
    val saveDetailKey=Array("key","wifi_list","upper_key","floor","room","level","buildingid","bld_key","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","buildingname","address")
    val citycodeArr=Array("010","020","021","022","023","024","025","027","028","029","052","053","086","088","310","311","312","313","314","315","316","317","318","319","335","349","350","351","352","353","354","355","356","357","358","359","370","371","372","373","374","375","376","377","378","379","391","392","393","394","395","396","398","411","412","414","415","416","417","418","419","421","427","429","431","432","433","434","435","436","437","438","439","451","452","453","454","455","456","457","458","459","464","467","468","469","470","471","472","473","474","475","476","477","478","479","482","483","510","511","512","513","514","515","516","517","518","519","523","527","530","531","532","533","534","535","536","537","538","539","543","546","550","551","552","553","554","555","556","557","558","559","561","562","563","564","566","570","571","572","573","574","575","576","577","578","579","580","591","592","593","594","595","596","597","598","599","631","632","633","635","660","662","663","668","691","692","701","710","711","712","713","714","715","716","717","718","719","722","724","728","730","734","735","736","737","738","739","743","744","745","746","750","751","752","753","754","755","756","757","758","759","760","762","763","766","768","769","770","771","772","773","774","775","776","777","778","779","790","791","792","793","794","795","796","797","798","799","812","813","816","817","818","825","826","827","830","831","832","833","834","835","836","837","838","839","851","852","853","854","855","856","857","858","859","870","871","872","873","874","875","876","877","878","879","883","886","887","891","892","893","894","895","896","897","898","901","902","903","906","908","909","911","912","913","914","915","916","917","919","930","931","932","933","934","935","936","937","938","939","941","943","951","952","953","954","955","970","971","972","973","974","975","976","977","979","990","991","992","993","994","995","996","997","998","999","7311","7312","7313","8981","8983")

    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val end_day=args(0)
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("获取wifi指纹库中间数据")
        val wifiMidDataRdd = getWifiMidData(sparkSession, end_day)
        logger.error("开始计算wifi aoi数据")
        val apAoiWifiDataRdd = getGjAoi(sparkSession, wifiMidDataRdd,aoiWhiteMapBroad)
        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apAoiWifiDataRdd, saveAoiKey, "dm_gis.dm_wifi_finger_traj_daily_aoi_dtl_di",Array(("inc_day", end_day)), 25)

        Spark.clearPersistWithoutId(sparkSession,wifiMidDataRdd.id)

        logger.error("开始计算wifi build数据")
        val apBuildWifiDataRdd = getGjBuild(sparkSession, wifiMidDataRdd,bldWhiteMapBroad)
        logger.error("存储wifi build数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apBuildWifiDataRdd, saveBuildKey, "dm_gis.dm_wifi_finger_traj_daily_bld_dtl_di",Array(("inc_day", end_day)), 25)

        Spark.clearPersistWithoutId(sparkSession,wifiMidDataRdd.id)
        logger.error("开始计算wifi index数据")
        val apIndexWifiData = getGjIndex(sparkSession, wifiMidDataRdd)
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apIndexWifiData, saveIndexKey, "dm_gis.dm_wifi_finger_traj_daily_index_dtl_di",Array(("inc_day", end_day)), 25)
        Spark.clearPersistWithoutId(sparkSession,wifiMidDataRdd.id)
        logger.error("开始计算 wifi detail数据")
        val fingerDetailDataRdd = getFingerDetail(sparkSession,wifiMidDataRdd)
        logger.error("存储 wifi detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, fingerDetailDataRdd, saveDetailKey, "dm_gis.dm_wifi_finger_traj_daily_detail_dtl_di",Array(("inc_day", end_day)), 25)


    }


    def getWifiMidData(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |select operatime_new,eventtype,city_code,waybillno,consignee_addr,src_city_code,deliver_emp_code,id,un,ewl,tm,zx,zy,doing,aoi_key,bld_key,aoi_id,bld_id,province,city,county,town,roodline,aoi,building,floor,room,level,tag,consignee_addr address from dm_gis.wifi_finger_v1_mid where inc_day='$end_day' and aoi_id is not null and bld_id is not null and  aoi_id<>'' and bld_id<>'' and building<>'' and building!='null' and tag='ok'
              |""".stripMargin

       sql=
           s"""
             |
             |select  city_code,emp_code,tm,addr,ewl,lng,lat,aoi_id,aoi_name,regexp_replace(buildingid,'null','') buildingid,buildingname,lng_bld,lat_bld,province,city,county,town,village,regexp_replace(floor,'null','') floor,regexp_replace(room,'null','') room,tag,cast(unix_timestamp(tm,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp from dm_gis.dm_wifi_finger_traj_dtl_di where inc_day='$end_day' and aoi_id<>'' and aoi_id is not null and tag=''
             |
             |
             |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)



        dataRdd


    }




    /**
     *
     * @param spark
     * @param wifiDataRdd
     * @return
     */
    def getGjIndex(spark:SparkSession,wifiDataRdd: RDD[JSONObject])={
        val traceWifiRdd = wifiDataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("ewl")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        var ewl_dis = value.getString("ss")
                        val mac_key = MacKeySaltUtils.getWifiMacKey(value.getString("mac"))
                        tempObj.put("decrypt_wifi", value.getString("mac"))
                        tempObj.put("ewl_dis", ewl_dis)
                        tempObj.put("mac_key", mac_key)
                        listBuffer += tempObj


                    }
                }
            }
            listBuffer.iterator
        }).filter(x=>StringUtils.nonEmpty(x.getString("mac_key"))&&x.getString("mac_key").length>5).map(obj => {

            var key=""
            try {
                val mac_key = obj.getString("mac_key")
                key=getHmodRowKey(mac_key, 100, 100, 1, 3)+","+Random.nextInt(10000)
                var buildingid = obj.getString("buildingid")
                val aoi_key = getMd5Key(obj.getString("aoi_id"))
                var bld_key = ""
                val floor = obj.getString("floor")
                val room = obj.getString("room")
                if(StringUtils.nonEmpty(buildingid)){
                    buildingid=buildingid.replace("null","")
                    bld_key=getMd5Key(buildingid)
                    if(bld_key.length==16&&(StringUtils.nonEmpty(floor)||StringUtils.nonEmpty(room))){
                        var concatFloor=buildingid
                        if(StringUtils.nonEmpty(floor)){
                            concatFloor+=floor.replace("null","")
                        }
                        if(StringUtils.nonEmpty(room)){
                            concatFloor+=room.replace("null","")
                        }
                        val md5DetaillKey=getMd5Key(concatFloor)
                        if(md5DetaillKey.length==16)
                            obj.put("finger_key",md5DetaillKey)
                    }

                }


                if(aoi_key.length==16) {
                obj.put("aoi_key", aoi_key)
                }
                if(bld_key.length==16)
                obj.put("bld_key", bld_key)

                obj.put("key", key)

            }catch {case e:Exception=>logger.error(e.toString)}

            (key, obj)

        }).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey().flatMap(x=>{

            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            var aoi_key = ""
            var bld_key = ""
            var finger_detail=""
            val zx = x._2.head.getString("lng")
            val zy = x._2.head.getString("lat")
            val key = x._2.head.getString("key")
            val decrypt_wifi=x._2.head.getString("decrypt_wifi")
            val city_code=x._2.head.getString("city_code")
            val aoi_id=x._2.head.getString("aoi_id")
            var buildingid=x._2.head.getString("buildingid")
            val province=x._2.head.getString("province")
            val city=x._2.head.getString("city")
            val county=x._2.head.getString("county")
            val town=x._2.head.getString("town")
            val village=x._2.head.getString("village")
            var floor=x._2.head.getString("floor")



            val aoiSet = new mutable.HashMap[String,String]()
            val buildMap = new mutable.HashMap[String,String]()
            val fingerMap = new mutable.HashMap[String,String]()
            val buildSet = new mutable.HashSet[String]()
            val fingerSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                if(!(StringUtils.nonEmpty(buildingid)&&buildingid.length>6)){
                    buildingid=obj.getString("buildingid")
                }
                val bld_key = obj.getString("bld_key")
                val finger_key = obj.getString("finger_key")
                val ewl_dis = math.abs(obj.getString("ewl_dis").toLong).toString
                aoi_key=obj.getString("aoi_key")
                transFormSigStrength(aoiSet,aoi_key,ewl_dis)
                if(StringUtils.nonEmpty(bld_key)&&bld_key.length==16){
                    buildSet.add(bld_key.replace("null",""))
                    transFormSigStrength(buildMap,bld_key.replace("null",""),ewl_dis)
                    if(StringUtils.nonEmpty(finger_key)&&finger_key.length==16){
                        fingerSet.add(finger_key.replace("null",""))
                        transFormSigStrength(fingerMap,finger_key.replace("null",""),ewl_dis)
                    }
                }
            }

            aoi_key=""
            for(key<-aoiSet.keySet){
                aoi_key=aoi_key+key+(aoiSet.get(key).get.toLong+1000).toString.substring(1)
            }

            /**
             * index 修改成 楼栋和楼层都加上信号强度，原来不带信号强度的先注释
             * bld_key = buildSet.mkString("")
            finger_detail=fingerSet.mkString("")
             *
             */


            for(key<-fingerMap.keySet){
                finger_detail=finger_detail+key+(fingerMap.get(key).get.toLong+1000).toString.substring(1)
            }

            for(key<-buildMap.keySet){
                bld_key=bld_key+key+(buildMap.get(key).get.toLong+1000).toString.substring(1)
            }
            dataObj.put("key", key)
            dataObj.put("decrypt_wifi", decrypt_wifi)
            dataObj.put("finger_aoi", aoi_key)

            dataObj.put("lng", zx)
            dataObj.put("lat", zy)
            dataObj.put("city_code", city_code)
            if(buildSet.size>0){
                dataObj.put("finger_bld", bld_key)
                if(fingerSet.size>0){
                    dataObj.put("finger_detail", finger_detail)
                }

            }


            dataObj.put("floor", "")
            dataObj.put("aoi_id", aoi_id)
            dataObj.put("buildingid", buildingid)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("village", village)

            listBuffer+=dataObj
            listBuffer


        }).map(x=>(x.getString("key").split(",")(0),x)).groupByKey().flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]
            var dataObj = new JSONObject()
            var finger_aoi=""
            var finger_bld=""
            var finger_detail=""
            dataObj.fluentPutAll(x._2.head)
            for(obj<-x._2){
                val finger_aoi_ = obj.getString("finger_aoi")
                val finger_bld_ = obj.getString("finger_bld")
                val finger_detail_ = obj.getString("finger_detail")
                if(StringUtils.nonEmpty(finger_aoi_)&&finger_aoi_.length>=16){
                    finger_aoi+=finger_aoi_.replace("null","")
                }

                if(StringUtils.nonEmpty(finger_bld_)&&finger_bld_.length>=16){
                    finger_bld+=finger_bld_.replace("null","")
                }
                if(StringUtils.nonEmpty(finger_detail_)&&finger_detail_.length>=16){
                    finger_detail+=finger_detail_.replace("null","")
                }




            }
            val aoiSet = new mutable.HashMap[String,String]()
            val buildMap = new mutable.HashMap[String,String]()
            val fingerMap = new mutable.HashMap[String,String]()
            val fingerbldSet = new mutable.HashSet[String]()
            val fingeraoiSet = new mutable.HashSet[String]()
            val fingerdetailSet = new mutable.HashSet[String]()
            splitFingerMap(finger_aoi,aoiSet)
            splitFingerMap(finger_bld,buildMap)
            splitFingerMap(finger_detail,fingerMap)

            splitFingerList(finger_bld, fingerbldSet)
            splitFingerList(finger_detail, fingerdetailSet)
            var aoi_key=""
            for(key<-aoiSet.keySet){
                aoi_key=aoi_key+key+aoiSet.get(key).get

            }
            var bld_key=""
            for(key<-buildMap.keySet){
                bld_key=bld_key+key+buildMap.get(key).get

            }

            var finger_key=""
            for(key<-fingerMap.keySet){
                finger_key=finger_key+key+fingerMap.get(key).get

            }
            dataObj.put("finger_aoi", aoi_key)
            if(fingerbldSet.size>0){
                dataObj.put("finger_bld", fingerbldSet.mkString(""))
                if(fingerdetailSet.size>0){
                    dataObj.put("finger_detail", fingerdetailSet.mkString(""))
                }

            }

            if(StringUtils.nonEmpty(bld_key)&&bld_key.length>16){
                dataObj.put("finger_bld", bld_key)
                if(StringUtils.nonEmpty(finger_key)&&finger_key.length>16){
                    dataObj.put("finger_detail", finger_key)
                }
            }



            dataObj.put("key",x._1)
            listBuffer+=dataObj
            listBuffer.iterator
        })

        traceWifiRdd



    }


    def transFormSigStrength(aoiMap:mutable.HashMap[String,String],aoi_key:String,ewl_dis:String)={
        if(aoi_key.length==16){
            if(!aoiMap.contains(aoi_key)){
                aoiMap.put(aoi_key,ewl_dis)
            }else{
                if(StringUtils.nonEmpty(ewl_dis)){
                    val avg_ss = aoiMap.get(aoi_key).get
                    if(StringUtils.nonEmpty(avg_ss)){
                        aoiMap.put(aoi_key,(math.round((avg_ss.toLong+Math.abs(ewl_dis.toDouble))/2)).toString)
                    }
                }
            }
        }
    }

    def getGjBuild(spark:SparkSession,wifiDataRdd: RDD[JSONObject],bldWhiteMapBroad:Broadcast[Map[String, String]])={
        val resultRdd = wifiDataRdd.filter(obj=>StringUtils.nonEmpty(obj.getString("buildingid"))).map(x => (x.getString("buildingid"), x)).groupByKey()
            .map(x => {
            val bldWhiteMap = bldWhiteMapBroad.value
            val dataObj = new JSONObject()
            dataObj.put("reliable",bldWhiteMap.getOrElse(x._1,"0"))
                var md5BldId=getMd5Key(x._2.head.getString("buildingid"))
                var key = math.abs(md5BldId.hashCode)%10+"_"+md5BldId
                var wifiArr = new JSONArray()
                var upper_key = getMd5Key(x._2.head.getString("aoi_id"))
                var aoi_id = x._2.head.getString("aoi_id")
                var finger_list = ""
                val fingerSet = new mutable.HashSet[String]()
                var bld_id = x._2.head.getString("buildingid")
                var bld_key = md5BldId
                var province = x._2.head.getString("province")
                var city = x._2.head.getString("city")
                var city_code=x._2.head.getString("city_code")
                var county = x._2.head.getString("county")
                var town = x._2.head.getString("town")
                var village = x._2.head.getString("village")
                var aoi = x._2.head.getString("aoi_name")
                var building = x._2.head.getString("buildingname")
                var address = province+city+county+town+village+aoi+building
                var pointArr = new JSONArray()
                for (obj <- x._2) {
                    val bld_key = obj.getString("bld_key")
                    val floor = obj.getString("floor")
                    val room = obj.getString("room")
                    val finger = getMd5Key(bld_key + floor + room)
                    if(StringUtils.nonEmpty(finger)){
                        fingerSet.add(finger)
                    }
                    val ewl = obj.getString("ewl")
                    val data_timestamp = obj.getString("date_time_timestamp")
                    if(!StringUtils.nonEmpty(city_code)){
                        city_code=obj.getString("city_code")
                    }
                    val pointObj = new JSONObject()
                    val lon = obj.getString("lng")
                    val lat = obj.getString("lat")
                    pointObj.put("x",lon)
                    pointObj.put("y",lat)
                    pointArr.add(pointObj)
                    val transFormArr = transformSaltWifiList(ewl, data_timestamp, "0100")
                    //                        wifiArr.addAll(transFormArr)
                    wifiArr.fluentAddAll(transFormArr)

                }
                val wifiDataArr = cleanWifi(wifiArr, "0100")
                val pointsAll = cleanPoints(pointArr.toString())
                val (lng,latall) = calcCenterPoint(pointsAll)

                finger_list=fingerSet.mkString("")
                dataObj.put("key", key)
                dataObj.put("wifi_list", wifiDataArr.toString())
                dataObj.put("upper_key", upper_key)
                dataObj.put("finger_list", finger_list)
                dataObj.put("buildingid", bld_id)
                dataObj.put("bld_key", bld_key)
                dataObj.put("aoi_id", aoi_id)
                dataObj.put("aoi_key", upper_key)
                dataObj.put("address", address.replace("null",""))
                dataObj.put("province", province)
                dataObj.put("city", city)
                dataObj.put("city_code", city_code)
                dataObj.put("county", county)
                dataObj.put("town", town)
                dataObj.put("village", village)
                dataObj.put("aoi_name", aoi)
                dataObj.put("buildingname", building)
                dataObj.put("lng", lng)
                dataObj.put("lat", latall)
                dataObj.put("update_tag","1")
                dataObj.put("points", pointsAll)
            dataObj

        }).filter(x=>StringUtils.nonEmpty(x.getString("key"))).map(x=>(x.getString("key"),x)).groupByKey().flatMap(x=>{
            val listbuffer = new ListBuffer[JSONObject]
            listbuffer+=x._2.head
            listbuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("bld数据量---》"+resultRdd.count())
        resultRdd

    }

    def getGjAoi(spark:SparkSession,wifiDataRdd: RDD[JSONObject],aoiWhiteMapBroad:Broadcast[Map[String, String]])={
        val mergeEwlRdd = wifiDataRdd.groupBy(x => x.getString("aoi_id")).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            val md5AoiId = getMd5Key(x._2.head.getString("aoi_id"))
            var key = math.abs(md5AoiId.hashCode) % 10 + "_" + md5AoiId
            var wifiArr = new JSONArray()
            //                    var upper_key = getMd5Key(x._2._1.get.head.getString("aoi_id"))
            var finger_list = ""

            var aoi_id = x._2.head.getString("aoi_id")
            var city_code = x._2.head.getString("city_code")
            var aoi_key = getMd5Key(x._2.head.getString("aoi_id"))

            var province = x._2.head.getString("province")
            var city = x._2.head.getString("city")
            var county = x._2.head.getString("county")
            var town = x._2.head.getString("town")
            var aoi = x._2.head.getString("aoi_name")
            var village = x._2.head.getString("village")

            var address = province + city + county + town + village + aoi
            //                    var aoi = x._2._1.get.head.getString("aoi")
            //                    var building = x._2._1.get.head.getString("building")
            var pointArr = new JSONArray()
            val fingerSet = new mutable.HashSet[String]()
            val macSet = Set[String]()
            for (obj <- x._2) {
                val ewl = obj.getString("ewl")
                val data_timestamp = obj.getString("date_time_timestamp")
                city_code = obj.getString("city_code")
                val pointObj = new JSONObject()
                val lon = obj.getString("lng")
                val lat = obj.getString("lat")
                pointObj.put("x", lon)
                pointObj.put("y", lat)
                pointArr.add(pointObj)
                val transFormArr = transformSaltWifiList(ewl, data_timestamp, "0100")
                wifiArr.fluentAddAll(transFormArr)
                fingerSet.add(getMd5Key(obj.getString("buildingid")))

            }


            val wifiDataArr = cleanWifi(wifiArr, "0100")
            val pointsAll = cleanPoints(pointArr.toString())
            val (lng, lat) = calcCenterPoint(pointsAll)
            dataObj.put("key", key)
            dataObj.put("update_tag", "1")
            dataObj.put("wifi_list", wifiDataArr.toString())
            finger_list = fingerSet.mkString("")
            dataObj.put("finger_list", finger_list)
            dataObj.put("address", address.replace("null",""))
            dataObj.put("aoi_id", aoi_id)
            dataObj.put("aoi_key", aoi_key)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("village", village)
            dataObj.put("aoi_name", aoi)
            dataObj.put("lng", lng)
            dataObj.put("lat", lat)
            dataObj.put("city_code", city_code)
            dataObj.put("points", pointsAll)
            listBuffer+=dataObj


            listBuffer

        }).filter(x=>StringUtils.nonEmpty(x.getString("aoi_id"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("预聚合aoi数据----》"+mergeEwlRdd.count())


        mergeEwlRdd

    }

    def cleanPoints(points:String): String ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        val pointSet = new mutable.HashSet[String]()
        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                pointSet.add(pointArr.getJSONObject(i).toString())

            }


            "["+pointSet.mkString(",")+"]"
        }else{
             ""
        }
    }

    def  transformSaltWifiList(ewl:String,date_time_timestamp:String,source:String)={

        val dataArr = new JSONArray()
        val ewlArr = try {
            JSON.parseArray(ewl)
        } catch {
            case e: Exception => {
                logger.error(e.getMessage)
                new JSONArray()
            }
        }
        if (ewlArr.size() > 0) {
            for (i <- 0 until ewlArr.size()) {
                val tempObj = new JSONObject()
                val value = ewlArr.getJSONObject(i)
                var ewl_dis = value.getString("ss")
                val mac_key = MacKeySaltUtils.getWifiMacKey(value.getString("mac"))
                tempObj.put("sig", ewl_dis)
                tempObj.put("mac", mac_key)
                tempObj.put("num", 1)
                tempObj.put("time", date_time_timestamp)
                tempObj.put("source", source)
                dataArr.add(tempObj)

            }
        }

        dataArr

    }

    def cleanWifi(wifiArr:JSONArray,source:String) ={
        val dataMap = new mutable.HashMap[String, (Long, Int, Int)]()
        val dataArr = new JSONArray()
        if(wifiArr.size()>0){
            for (i <- 0 until wifiArr.size()) {
                try {
                    val ewlObj = wifiArr.getJSONObject(i)
                    val mac = ewlObj.getString("mac")
                    var time = ewlObj.getString("time").toLong
                    var sig = ewlObj.getString("sig").toInt
                    var num = ewlObj.getString("num").toInt
                    if(dataMap.contains(mac)){
                        val tuple = dataMap.get(mac).get
                        if(time<tuple._1){
                            time=tuple._1
                        }
                        sig=(sig+tuple._2)/2
                        num=num+tuple._3
                        dataMap.put(mac,(time,sig,num))

                    }else{
                        dataMap.put(mac,(time,sig,num))
                    }

                }catch {case e:Exception=>logger.error(e.toString)}

            }
            if(dataMap.size>0){
                for(key<-dataMap.keySet){
                    val tempObj = new JSONObject()
                    val tuple = dataMap.get(key).get
                    tempObj.put("sig", tuple._2)
                    tempObj.put("mac", key)
                    tempObj.put("num", tuple._3)
                    tempObj.put("time", tuple._1)
                    tempObj.put("source", source)
                    dataArr.add(tempObj)
                }
            }
        }
        dataArr

    }

    def cleanEncripeWifi(wifiArr:JSONArray) ={
        val dataMap = new mutable.HashMap[String, Int]()
        val dataArr = new JSONArray()
        if(wifiArr.size()>0){
            for (i <- 0 until wifiArr.size()) {
                try {
                    val ewlObj = wifiArr.getJSONObject(i)
                    val mac = ewlObj.getString("mac")
                    var sig = ewlObj.getString("ss").toInt
                    if(dataMap.contains(mac)){
                        val sigAvg = dataMap.get(mac).get
                        sig=(sig+sigAvg)/2
                        dataMap.put(mac,sig)
                    }else{
                        dataMap.put(mac,sig)
                    }

                }catch {case e:Exception=>logger.error(e.toString)}

            }
            if(dataMap.size>0){
                for(key<-dataMap.keySet){
                    val tempObj = new JSONObject()
                    val sigAvg = dataMap.get(key).get
                    tempObj.put("ss", sigAvg)
                    tempObj.put("mac", key)
                    dataArr.add(tempObj)
                }
            }
        }
        dataArr

    }
    def calcCenterPoint(points:String): (Double, Double) ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        var lngAll=0.0
        var latAll=0.0
        var cnt=0L

        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                val pointObj = pointArr.getJSONObject(i)
                lngAll+=pointObj.getString("x").toDouble
                latAll+=pointObj.getString("y").toDouble
                cnt+=1
            }
        }

        (lngAll/cnt,latAll/cnt)

    }
    def splitFingerList(fingerList:String,fingerSet:mutable.HashSet[String]): Unit ={
        if(StringUtils.nonEmpty(fingerList)&&fingerList.length>=16){
            try {
                if(fingerList.length>0){
                    for(i<- 0 until fingerList.length/16){
                        fingerSet.add(fingerList.substring(i*16,(i+1)*16))

                    }
                }
            }catch {case e:Exception=>{
                logger.error("error finger ---->"+fingerList)
            }}

        }





    }

    def splitFingerMap(fingerList:String,fingerMap:mutable.HashMap[String,String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/19){
                    val finger_aoi = fingerList.substring(i * 19, (i + 1) * 19)
                    if(fingerMap.contains(finger_aoi.substring(0,16))){
                        val avg_ss = fingerMap.get(finger_aoi.substring(0, 16)).get
                        val ewl_dis = finger_aoi.substring(16)

                        fingerMap.put(finger_aoi.substring(0,16),(math.round((math.abs(avg_ss.toLong)+Math.abs(ewl_dis.toDouble))/2)+1000).toString.substring(1))

                    }else{
                        fingerMap.put(finger_aoi.substring(0,16),finger_aoi.substring(16))

                    }
                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def getFingerDetail(spark:SparkSession,wifiDataRdd: RDD[JSONObject])={

        val resultRdd=wifiDataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("ewl")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        var ewl_dis = value.getString("ss")
                        val mac_key = MacKeySaltUtils.getWifiMacKey(value.getString("mac"))
                        tempObj.put("decrypt_wifi", value.getString("mac"))
                        tempObj.put("ewl_dis", ewl_dis)
                        tempObj.put("mac_key", mac_key)
                        if(StringUtils.nonEmpty(tempObj.getString("floor"))&&StringUtils.nonEmpty(tempObj.getString("room"))){
                            val floorObj = new JSONObject()
                            floorObj.fluentPutAll(tempObj)
                            floorObj.put("room","")
                            tempObj.put("floor","")
                            listBuffer+=floorObj
                            listBuffer+=tempObj

                        }else{
                            listBuffer += tempObj
                        }

                    }
                }
            }
            listBuffer.iterator
        }).filter(x=>StringUtils.nonEmpty(x.getString("decrypt_wifi"))).map(obj => {
            val bld_key = obj.getString("buildingid")
            val floor = obj.getString("floor")
            val room = obj.getString("room")
            if(StringUtils.nonEmpty(bld_key)&&(StringUtils.nonEmpty(floor)||StringUtils.nonEmpty(room))){
                val md5DetaillKey=getMd5Key(bld_key + floor + room)
                val key = math.abs(md5DetaillKey.hashCode)%10+"_"+md5DetaillKey
                obj.put("key", key)
                (key, obj)
            }else{
                ("",null)
            }

        }).filter(x=>StringUtils.nonEmpty(x._1)).groupByKey().map(x=>{
            val dataObj = new JSONObject()
            var key = x._1
            var wifiArr = new JSONArray()
            var upper_key = getMd5Key(x._2.head.getString("buildingid"))
            var finger_list = ""
            var level = x._2.head.getString("level")
            var bld_key = x._2.head.getString("buildingid")

            var province = x._2.head.getString("province")
            var city = x._2.head.getString("city")
            var city_code = x._2.head.getString("city_code")
            var county = x._2.head.getString("county")
            var town = x._2.head.getString("town")
            var village = x._2.head.getString("village")
            var aoi = x._2.head.getString("aoi_name")
            var floor = x._2.head.getString("floor")
            var room = x._2.head.getString("room")
            var building = x._2.head.getString("buildingname")
            var roodline = x._2.head.getString("roodline")
            var address = province+city+county+town+village+roodline+aoi+building+floor+room
            var lon = ""
            var lat = ""
            var lon_cnt = 0L
            var lon_all = 0.0
            var lat_all = 0.0
            var pointArr = new JSONArray()
            val macSet = Set[String]()
            for (obj <- x._2) {
                val mac_key = obj.getString("mac_key")
                if (!macSet.contains(mac_key)) {
                    macSet.add(mac_key)
                    val tmpObj = new JSONObject()
                    val poinObj = new JSONObject()
                    val ewl_dis = obj.getString("ewl_dis")
                    val tm = obj.getString("date_time_timestamp")
                    val zx = obj.getString("lng")
                    val zy = obj.getString("lat")
                    tmpObj.put("mac", mac_key)
                    tmpObj.put("sig", ewl_dis.toLong)
                    tmpObj.put("num", 1)
                    tmpObj.put("time", tm)
                    tmpObj.put("source", "0100")
                    wifiArr.add(tmpObj)
                    poinObj.put("x", zx)
                    poinObj.put("y", zy)
                    pointArr.add(poinObj)
                    finger_list = finger_list + getMd5Key(obj.getString("buildingid"))
                    if (zx != null && zx.nonEmpty && zy != null && zy.nonEmpty) {
                        lon_cnt += 1
                        lon_all += zx.toDouble
                        lat_all += zy.toDouble

                    }
                }


            }
            if (lon_cnt > 0) {
                lon = (lon_all / lon_cnt).toString
                lat = (lat_all / lon_cnt).toString

            }
            dataObj.put("key", key)
            dataObj.put("wifi_list", wifiArr.toString())
            dataObj.put("finger_list", finger_list)
            dataObj.put("address", address.replace("null",""))
            dataObj.put("level", level)
            dataObj.put("upper_key", upper_key)
            dataObj.put("buildingname", building)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("city_code", city_code)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("village", village)
            dataObj.put("aoi_name", aoi)
            dataObj.put("roodline", roodline)
            dataObj.put("floor", floor)
            dataObj.put("room", room)
            dataObj.put("lng", lon)
            dataObj.put("lat", lat)
            dataObj.put("points", pointArr.toString())
            dataObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("detail数据量---》"+resultRdd.count())
        resultRdd

    }

    def getFingerWhite(spark:SparkSession)={
        var sql=
            """
              |
              |
              |select guid,`level`,in_use,reserve1 from (
              |select guid,`level`,in_use,reserve1,row_number()over(partition by guid,`level` order by update_date desc ) rnk from dm_gis.gis_wifi_finger_white_list where in_use = '1'
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("aoi")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //aoiWhiteMap.take(10).foreach(println(_))



        val bldWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("bld")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //bldWhiteMap.take(10).foreach(println(_))
        (spark.sparkContext.broadcast(aoiWhiteMap),spark.sparkContext.broadcast(bldWhiteMap))



    }

    /**
     *
     * @param user_id key
     * @param mod 取模，也就是hbase预分region
     * @param covering 由于hbase region 是以固定位数为开头，比如预分region是100 ，则region开头是 00-99，因此这里需要加上100
     * @param start_index 截取的，起始
     * @param end_index 截取的，终止
     * @return
     * 以预分region 100请求示例：
     * val user_id = getHmodRowKey("4e47db3df1aed721", 100, 100, 1, 3)
     *
     * 如果只有10个预分区，那就直接 0-9，可以直接 (Math.abs(user_id.hashCode) % mod)+"_"+user_id
     */
    def getHmodRowKey(user_id:String,mod:Int,covering:Int,start_index:Int,end_index:Int)={
        var rowKey=""

        try{
            val prefix = (Math.abs(user_id.hashCode) % mod) + covering
            rowKey = prefix.toString.substring(start_index, end_index)+"_"+user_id
        }catch {case e:Exception=>logger.error(e.toString)}

        rowKey

    }




}
