package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.HttpUtils
import com.sf.gis.scala.nloc.app.InitWifiDataBaseMergeWifi.{className, saveIndexKey}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder

/**
 * @ProductManager:
 * @Author: 01407499
 * @CreateTime: 2023-10-20 10:37
 * @TaskId:872587
 * @TaskName:测试Ars接口
 * @Description:
 */

object testArsData {

    val saveKey=Array("addr","interface_data")
    val urlGray = "http://gis-int.int.sfdc.com.cn:1080/ar/api?address=%s&ak=af5938935293445084a6b7ba8cd23a4c&showserver=true"
    val urlproduct = "http://gis-int.int.sfdc.com.cn:1080/ar/api?address=%s&ak=e6d2bea8c2e64c5b8b37718eb8ce81cf&showserver=true"

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    def main(args: Array[String]): Unit = {

        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val grayResultRdd = getData(sparkSession, urlGray)
        SparkWrite.save2HiveStaticNew(sparkSession, grayResultRdd, saveKey, "tmp_dm_gis.dwd_wb_frt_cnt_ars_gray_data",null, 25)

        val productResultRdd = getData(sparkSession, urlproduct)
        SparkWrite.save2HiveStaticNew(sparkSession, productResultRdd, saveKey, "tmp_dm_gis.dwd_wb_frt_cnt_ars_product_data",null, 25)




    }

    def getData(spark:SparkSession,url:String)={
        var sql=
            """
              |
              |select addr from (
              |select addr from  dm_gis.dwd_wb_frt_cnt_mi where freight_rmb>=5000 or cnt >= 300 group by addr )
              |limit 1000
              |""".stripMargin

        sql=
            """
              |
              |select * from tmp_dm_gis.dwd_wb_frt_cnt_mi_test_vip_addr where inc_day='20231020'
              |
              |""".stripMargin

        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            try{
                val addr = obj.getString("addr")
                val nObject = runInteface(addr, url)
                obj.put("interface_data", nObject.toString())

            }catch {
                case e:Exception=>logger.error(e.getMessage)
            }
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调接口数据量---》"+resultRdd.count())
        resultRdd


    }

    def runInteface(addr:String,url:String) = {

        val tmpUrl = String.format(url, URLEncoder.encode(addr, "utf-8"))

        var cnt = 0
        var retJson: JSONObject = null;
        while (cnt < 3) {
            try {
                retJson = HttpUtils.urlConnectionGetJson(tmpUrl, 2 * 1000)
                cnt = 3
            } catch {
                case e: Exception => {
                    logger.error(e)
                    Thread.sleep(3000)
                    cnt = cnt + 1
                    if (cnt >= 3) {
                        throw e
                    }
                }
            }
        }

        retJson
    }

}
