package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

import scala.collection.mutable

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-08-08 09:46
 * @TaskId:786033
 * @TaskName:wifi指纹库-合并ap轨迹wifi指纹
 * @Description:
 */

object InitWifiDataBaseMergeWifi {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","address","province","city","county","town","roodline","aoi","lon","lat","points","reliable","reserve1","reserve2","update_tag")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","bld_id","bld_key","address","province","city","county","town","roodline","aoi","building","lon","lat","points","reliable","reserve1","reserve2","update_tag")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","lon","lat","reserve1","reserve2","update_tag")
    val saveDetailKey=Array("key","wifi_list","upper_key","address","level","province","city","county","town","roodline","aoi","building","floor","room","lon","lat","points","reliable","reserve1","reserve2","update_tag")

    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("合并aoi数据")
        val aoiRdd = mergeAoi(sparkSession, aoiWhiteMapBroad)
        logger.error("合并bld数据")
        val bldRdd = mergeBuld(sparkSession, bldWhiteMapBroad)


        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, aoiRdd, saveAoiKey, "dm_gis.wifi_finger_aoi_v1",null, 25)
        logger.error("存储wifi build数据")
        SparkWrite.save2HiveStaticNew(sparkSession, bldRdd, saveBuildKey, "dm_gis.wifi_finger_building_v1",null, 25)

        logger.error("合并detail数据")
        val detailRdd = mergeDetail(sparkSession)
        logger.error("存储 wifi detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, detailRdd, saveDetailKey, "dm_gis.wifi_finger_detail_v1",null, 25)

        logger.error("合并index数据")
        val indexRdd = mergeIndex(sparkSession)
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, indexRdd, saveIndexKey, "dm_gis.wifi_finger_index_v1",null, 25)

    }

    def mergeIndex(spark:SparkSession)={
        var sql=
            """
              |
              |select
              |wifi as key
              |,aoi_key as finger_aoi
              |,bld_key as finger_bld
              |,finger_detail
              |,floor
              |,lon
              |,lat
              |from dm_gis.wifi_finger_ap_index
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val apDataRdd =SparkRead.readHiveAsJson(spark, sql)._1.map(obj=>(obj.getString("key"),obj))
        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_gj_index_dtl
              |
              |
              |
              |""".stripMargin

        val traceDataRdd =SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj=>(obj.getString("key"),obj))
        var resultRdd = apDataRdd.fullOuterJoin(traceDataRdd).map(x => {
            val leftObjOp = x._2._1
            val rightObjOp = x._2._2
            var obj = new JSONObject()
            obj.put("update_tag", "1")

            if (leftObjOp.nonEmpty) {
                if (rightObjOp.nonEmpty) {
                    val leftObj = leftObjOp.get
                    val rightObj = rightObjOp.get
                    val finger_aoi = leftObj.getString("finger_aoi") + rightObj.getString("finger_aoi")
                    val finger_bld = leftObj.getString("finger_bld") + rightObj.getString("finger_bld")
                    val finger_detail = leftObj.getString("finger_bld") + rightObj.getString("finger_bld")
                    val aoiSet = new mutable.HashMap[String,String]()
                    val fingerbldSet = new mutable.HashSet[String]()
                    val fingeraoiSet = new mutable.HashSet[String]()
                    val fingerdetailSet = new mutable.HashSet[String]()
                    splitFingerMap(finger_aoi,aoiSet)
                    splitFingerList(finger_bld, fingerbldSet)
                    splitFingerList(finger_detail, fingerdetailSet)
                    splitFingerList(finger_aoi, fingeraoiSet)
                    var aoi_key=""
                    for(key<-aoiSet.keySet){
                        aoi_key=aoi_key+key+aoiSet.get(key).get

                    }
                    obj.put("lon", leftObj.getString("lon"))
                    obj.put("lat", leftObj.getString("lat"))
                    obj.put("reserve1", rightObj.getString("city_code"))
                    obj.put("update_tag", rightObj.getString("update_tag"))
                    obj.put("finger_aoi", aoi_key)
//                    obj.put("finger_aoi", aoiSet.keySet.mkString(""))
                    obj.put("finger_bld", fingerbldSet.mkString(""))
                    obj.put("finger_detail", fingerdetailSet.mkString(""))
                    obj.put("key", leftObj.getString("key"))
                } else {
                    val finger_aoi = leftObjOp.get.getString("finger_aoi")
                    val aoiSet = new mutable.HashMap[String,String]()
                    splitFingerMap(finger_aoi,aoiSet)
                    obj.fluentPutAll(leftObjOp.get)
//                    obj.put("finger_aoi",aoiSet.keySet.mkString(""))

                }

            } else {
                val finger_aoi = rightObjOp.get.getString("finger_aoi")
                val aoiSet = new mutable.HashMap[String,String]()
                splitFingerMap(finger_aoi,aoiSet)
                obj.fluentPutAll(rightObjOp.get)
                obj.put("reserve1", rightObjOp.get.getString("city_code"))
//                obj.put("finger_aoi",aoiSet.keySet.mkString(""))

            }

            obj
        })

        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_index_dtl
              |
              |
              |""".stripMargin

        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
                obj.put("update_tag", "1")

                if (leftObjOp.nonEmpty) {
                    if (rightObjOp.nonEmpty) {
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        val finger_aoi = leftObj.getString("finger_aoi") + rightObj.getString("finger_aoi")
                        val finger_bld = leftObj.getString("finger_bld") + rightObj.getString("finger_bld")
                        val finger_detail = leftObj.getString("finger_detail") + rightObj.getString("finger_detail")
                        val aoiSet = new mutable.HashMap[String,String]()
                        val fingerbldSet = new mutable.HashSet[String]()
                        val fingeraoiSet = new mutable.HashSet[String]()
                        val fingerdetailSet = new mutable.HashSet[String]()
                        splitFingerMap(finger_aoi,aoiSet)
                        splitFingerList(finger_bld, fingerbldSet)
                        splitFingerList(finger_detail, fingerdetailSet)
                        splitFingerList(finger_aoi, fingeraoiSet)
                        var aoi_key=""
                        for(key<-aoiSet.keySet){
                            aoi_key=aoi_key+key+aoiSet.get(key).get

                        }
                        obj.put("lon", leftObj.getString("lon"))
                        obj.put("lat", leftObj.getString("lat"))
                        obj.put("reserve1", rightObj.getString("city_code"))
                        obj.put("update_tag", rightObj.getString("update_tag"))
                        obj.put("finger_aoi", aoi_key)
                        obj.put("finger_aoi", aoiSet.keySet.mkString(""))
                        obj.put("finger_bld", fingerbldSet.mkString(""))
                        obj.put("finger_detail", fingerdetailSet.mkString(""))
                        obj.put("key", leftObj.getString("key"))
                    } else {

                        val finger_aoi = leftObjOp.get.getString("finger_aoi")
                        val aoiSet = new mutable.HashMap[String,String]()
                        splitFingerMap(finger_aoi,aoiSet)
                        obj.fluentPutAll(leftObjOp.get)
                        obj.put("finger_aoi",aoiSet.keySet.mkString(""))

                    }

                } else {
                    val finger_aoi = rightObjOp.get.getString("finger_aoi")
                    val aoiSet = new mutable.HashMap[String,String]()
                    splitFingerMap(finger_aoi,aoiSet)
                    obj.fluentPutAll(rightObjOp.get)
                    obj.put("reserve1", rightObjOp.get.getString("city_code"))
                    obj.put("finger_aoi",aoiSet.keySet.mkString(""))
                }

                obj


            })

        }




        resultRdd


    }

    def mergeAoi(spark:SparkSession,aoiWhiteMapBroad:Broadcast[Map[String, String]])={

        var sql_aoi_info="select aoi_id,aoi_name from dm_gis.cms_aoi_sch where del_flag='0' "
        logger.error("sql---->"+sql_aoi_info)
        val aoiInfoMapBro = spark.sparkContext.broadcast(SparkRead.readHiveAsJson(spark, sql_aoi_info)._1.map(obj => (obj.getString("aoi_id"), obj.getString("aoi_name"))).collectAsMap())
        var sql=
            """
              |
              |select
              |key
              |,wifi as wifi_list
              |,finger_list
              |,province
              |,city
              |,county
              |,town
              |,aoi_id
              |,aoi_key
              |,address
              |,aoi
              |,cast(lon as string) lon
              |,cast(lat as string) lat
              |,point as points
              |from dm_gis.wifi_finger_ap_aoi
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val apDataRdd =SparkRead.readHiveAsJson(spark, sql)._1.map(obj=>(obj.getString("key"),obj))
        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_gj_aoi_dtl
              |
              |
              |
              |""".stripMargin

        val traceDataRdd =SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj=>(obj.getString("key"),obj))
        var resultRdd = apDataRdd.fullOuterJoin(traceDataRdd).map(x => {
            val aoiWhiteMap = aoiWhiteMapBroad.value
            val leftObjOp = x._2._1
            val rightObjOp = x._2._2
            var obj = new JSONObject()
            val aoiInfoMap = aoiInfoMapBro.value

            if (leftObjOp.nonEmpty) {
                obj.fluentPutAll(leftObjOp.get)
                obj.put("update_tag", "1")
                if (rightObjOp.nonEmpty) {
                    val wifiMap = new mutable.HashMap[String, JSONObject]()
                    val leftObj = leftObjOp.get
                    val rightObj = rightObjOp.get
                    var wifiArr = new JSONArray()
                    var pointArr = new JSONArray()
                    var finger_list = leftObj.getString("finger_list")
                    var wifi = leftObj.getString("wifi_list")
                    var points = leftObj.getString("points")
                    val fingerSet = new mutable.HashSet[String]()
                    splitFingerList(finger_list, fingerSet)

                    var tracewifiArr = new JSONArray()
                    var tracepointArr = new JSONArray()
                    var tracefinger_list = rightObj.getString("finger_list")
                    var tracewifi = rightObj.getString("wifi_list")
                    var tracepoints = rightObj.getString("points")
                    val tracefingerSet = new mutable.HashSet[String]()
                    splitFingerList(tracefinger_list, fingerSet)
                    try {
                        wifiArr = JSON.parseArray(wifi)
                        pointArr = JSON.parseArray(points)
                        tracewifiArr = JSON.parseArray(tracewifi)
                        tracepointArr = JSON.parseArray(tracepoints)

                    } catch {
                        case e: Exception => {
                            logger.error(e.getMessage)

                        }
                    }

                    mergeWifiList(wifiArr, wifiMap, "0010")
                    mergeWifiList(tracewifiArr, wifiMap, "0110")
                    pointArr.fluentAddAll(tracepointArr)
                    val pointsAll = cleanPoints(pointArr.toString())
                    val wifiArrAll = new JSONArray()
                    for (wifi <- wifiMap.values) {
                        wifiArrAll.add(wifi)
                    }
                    obj.put("wifi_list", wifiArrAll.toString())
                    obj.put("finger_list", fingerSet.mkString(""))
                    obj.put("points", pointsAll)
                    obj.put("reserve1", rightObj.getString("city_code"))


                }

            } else {
                obj.fluentPutAll(rightObjOp.get)
                val aoi_id = obj.getString("aoi_id")
                if(aoiInfoMap.contains(aoi_id)){
                    obj.put("aoi",aoiInfoMap.get(aoi_id).get)
                }
                obj.put("reserve1", rightObjOp.get.getString("city_code"))

            }

            obj.put("reliable",aoiWhiteMap.getOrElse(obj.getString("aoi_id"),"0"))
            obj


        })

      /*resultRdd.filter(obj => {
          Array("016848EFC3D54FA0AE8D63E146DD6CB0","01D2F77AF330467B80805BA936C515F7","021D91FC89D1436093F5C418444D5CE5").contains(obj.getString("aoi_id"))
      }).take(3).foreach(println(_))*/

        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_aoi_dtl
              |
              |""".stripMargin
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val aoiWhiteMap = aoiWhiteMapBroad.value
                val aoiInfoMap = aoiInfoMapBro.value
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
                obj.put("update_tag", "1")

                if (leftObjOp.nonEmpty) {
                    obj.fluentPutAll(leftObjOp.get)
                    obj.put("update_tag", "1")
                    if (rightObjOp.nonEmpty) {
                        val wifiMap = new mutable.HashMap[String, JSONObject]()
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        var wifiArr = new JSONArray()
                        var pointArr = new JSONArray()
                        var finger_list = leftObj.getString("finger_list")
                        var wifi = leftObj.getString("wifi_list")
                        var points = leftObj.getString("points")
                        val fingerSet = new mutable.HashSet[String]()
                        splitFingerList(finger_list, fingerSet)

                        var tracewifiArr = new JSONArray()
                        var tracepointArr = new JSONArray()
                        var tracefinger_list = rightObj.getString("finger_list")
                        var tracewifi = rightObj.getString("wifi_list")
                        var tracepoints = rightObj.getString("points")
                        val tracefingerSet = new mutable.HashSet[String]()
                        splitFingerList(tracefinger_list, fingerSet)
                        try {
                            wifiArr = JSON.parseArray(wifi)
                            pointArr = JSON.parseArray(points)
                            tracewifiArr = JSON.parseArray(tracewifi)
                            tracepointArr = JSON.parseArray(tracepoints)

                        } catch {
                            case e: Exception => {
                                logger.error(e.getMessage)

                            }
                        }

                        mergeWifiList(wifiArr, wifiMap, "0110")
                        mergeWifiList(tracewifiArr, wifiMap, "1110")
                        pointArr.fluentAddAll(tracepointArr)
                        val pointsAll = cleanPoints(pointArr.toString())
                        val wifiArrAll = new JSONArray()
                        for (wifi <- wifiMap.values) {
                            wifiArrAll.add(wifi)
                        }
                        obj.put("wifi_list", wifiArrAll.toString())
                        obj.put("finger_list", fingerSet.mkString(""))
                        obj.put("points", pointsAll)



                    }

                } else {
                    obj.fluentPutAll(rightObjOp.get)
                    val aoi_id = obj.getString("aoi_id")
                    if(aoiInfoMap.contains(aoi_id)){
                        obj.put("aoi",aoiInfoMap.get(aoi_id).get)
                    }


                }

                obj.put("reliable",aoiWhiteMap.getOrElse(obj.getString("aoi_id"),"0"))

                obj
            })


        }

        /*resultRdd.filter(obj => {
            Array("016848EFC3D54FA0AE8D63E146DD6CB0","01D2F77AF330467B80805BA936C515F7","021D91FC89D1436093F5C418444D5CE5").contains(obj.getString("aoi_id"))
        }).take(3).foreach(println(_))*/

        resultRdd


    }

    def cleanPoints(points:String): String ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        val pointSet = new mutable.HashSet[String]()
        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                pointSet.add(pointArr.getJSONObject(i).toString())

            }


            "["+pointSet.mkString(",")+"]"
        }else{
            ""
        }
    }
    def mergeWifiList(wifiArr:JSONArray,wifiMap:mutable.HashMap[String, JSONObject],source_num:String)={
        for (i <- 0 until wifiArr.size()) {
            val wifiObj = wifiArr.getJSONObject(i)
            val mac = wifiObj.getString("mac")
            if (wifiMap.contains(mac)) {
                val num = wifiObj.getString("num")
                val time = wifiObj.getString("time")
                val source = wifiObj.getString("source")
                val sig=wifiObj.getString("sig")
                val temObj = wifiMap.get(mac).get
                var num_t = temObj.getString("num")
                var time_t = temObj.getString("time")
                var source_t = temObj.getString("source")
                var sig_t = temObj.getString("sig")
                if (StringUtils.nonEmpty(num) && StringUtils.nonEmpty(time) && StringUtils.nonEmpty(source) && StringUtils.nonEmpty(num_t) && StringUtils.nonEmpty(time_t) && StringUtils.nonEmpty(source_t)&&StringUtils.nonEmpty(sig)&&StringUtils.nonEmpty(sig_t)) {
                    num_t = (num_t.toLong + num.toLong).toString
                    sig_t=((sig.toLong+sig_t.toLong)/2).toString
                    if (time.toLong > time_t.toLong) {
                        time_t = time
                    }

                    temObj.put("num", num_t)
                    temObj.put("time", time_t)
                    temObj.put("source", source_num)
                    temObj.put("sig", sig_t)
                }
                wifiMap.put(mac, temObj)
            } else {
                wifiMap.put(mac, wifiObj)
            }
        }



    }
    def mergeBuld(spark:SparkSession,bldWhiteMapBroad:Broadcast[Map[String, String]])={
        var sql=
            """
              |
              |select
              |key
              |,wifi as wifi_list
              |,upper_key
              |,finger_list
              |,bld_id
              |,bld_key
              |,address
              |,province
              |,city
              |,county
              |,town
              |,aoi
              |,building
              |,lon
              |,lat
              |,point as points
              |
              |from dm_gis.wifi_finger_ap_building
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val apDataRdd =SparkRead.readHiveAsJson(spark, sql)._1.map(obj=>(obj.getString("key"),obj))
        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_gj_building_dtl
              |
              |
              |
              |""".stripMargin

        val traceDataRdd =SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj=>(obj.getString("key"),obj))
        var resultRdd = apDataRdd.fullOuterJoin(traceDataRdd).map(x => {
            val bldWhiteMap = bldWhiteMapBroad.value
            val leftObjOp = x._2._1
            val rightObjOp = x._2._2
            var obj = new JSONObject()
            if (leftObjOp.nonEmpty) {
                obj.fluentPutAll(leftObjOp.get)
                obj.put("update_tag", "1")
                if (rightObjOp.nonEmpty) {

                    val wifiMap = new mutable.HashMap[String, JSONObject]()
                    val leftObj = leftObjOp.get
                    val rightObj = rightObjOp.get
                    var wifiArr = new JSONArray()
                    var pointArr = new JSONArray()
                    var upper_key = leftObj.getString("upper_key")
                    var finger_list = leftObj.getString("finger_list")
                    var wifi = leftObj.getString("wifi_list")
                    var points = leftObj.getString("points")
                    val fingerSet = new mutable.HashSet[String]()
                    val upperSet = new mutable.HashSet[String]()
                    splitFingerList(finger_list, fingerSet)
                    splitFingerList(upper_key, upperSet)

                    var tracewifiArr = new JSONArray()
                    var tracepointArr = new JSONArray()
                    var traceupper_key = rightObj.getString("upper_key")
                    var tracefinger_list = rightObj.getString("finger_list")
                    var tracewifi = rightObj.getString("wifi_list")
                    var tracepoints = rightObj.getString("points")

                    splitFingerList(tracefinger_list, fingerSet)
                    splitFingerList(traceupper_key, upperSet)
                    try {
                        wifiArr = JSON.parseArray(wifi)
                        pointArr = JSON.parseArray(points)
                        tracewifiArr = JSON.parseArray(tracewifi)
                        tracepointArr = JSON.parseArray(tracepoints)

                    } catch {
                        case e: Exception => {
                            logger.error(e.getMessage)

                        }
                    }

                    mergeWifiList(wifiArr, wifiMap, "0010")
                    mergeWifiList(tracewifiArr, wifiMap, "0110")
                    pointArr.fluentAddAll(tracepointArr)
                    val pointsAll = cleanPoints(pointArr.toString())
                    val wifiArrAll = new JSONArray()
                    for (wifi <- wifiMap.values) {
                        wifiArrAll.add(wifi)
                    }
                    obj.put("wifi_list", wifiArrAll.toString())
                    obj.put("upper_key", upperSet.mkString(""))
                    obj.put("finger_list", fingerSet.mkString(""))
                    obj.put("points", pointsAll)
                    obj.put("reserve1", rightObj.getString("city_code"))


                }

            } else {
                obj.fluentPutAll(rightObjOp.get)
                obj.put("reserve1", rightObjOp.get.getString("city_code"))

            }
            obj.put("reliable",bldWhiteMap.getOrElse(obj.getString("bld_id"),"0"))
            obj

        })
      //resultRdd.take(2).foreach(println(_))

        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_building_dtl
              |
              |""".stripMargin
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val bldWhiteMap = bldWhiteMapBroad.value
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
                if (leftObjOp.nonEmpty) {
                    obj.fluentPutAll(leftObjOp.get)
                    obj.put("update_tag", "1")
                    if (rightObjOp.nonEmpty) {

                        val wifiMap = new mutable.HashMap[String, JSONObject]()
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        var wifiArr = new JSONArray()
                        var pointArr = new JSONArray()
                        var upper_key = leftObj.getString("upper_key")
                        var finger_list = leftObj.getString("finger_list")
                        var wifi = leftObj.getString("wifi_list")
                        var points = leftObj.getString("points")
                        val fingerSet = new mutable.HashSet[String]()
                        val upperSet = new mutable.HashSet[String]()
                        splitFingerList(finger_list, fingerSet)
                        splitFingerList(upper_key, upperSet)

                        var tracewifiArr = new JSONArray()
                        var tracepointArr = new JSONArray()
                        var traceupper_key = rightObj.getString("upper_key")
                        var tracefinger_list = rightObj.getString("finger_list")
                        var tracewifi = rightObj.getString("wifi_list")
                        var tracepoints = rightObj.getString("points")

                        splitFingerList(tracefinger_list, fingerSet)
                        splitFingerList(traceupper_key, upperSet)
                        try {
                            wifiArr = JSON.parseArray(wifi)
                            pointArr = JSON.parseArray(points)
                            tracewifiArr = JSON.parseArray(tracewifi)
                            tracepointArr = JSON.parseArray(tracepoints)

                        } catch {
                            case e: Exception => {
                                logger.error(e.getMessage)

                            }
                        }

                        mergeWifiList(wifiArr, wifiMap, "0110")
                        mergeWifiList(tracewifiArr, wifiMap, "1110")
                        pointArr.fluentAddAll(tracepointArr)
                        val pointsAll = cleanPoints(pointArr.toString())
                        val wifiArrAll = new JSONArray()
                        for (wifi <- wifiMap.values) {
                            wifiArrAll.add(wifi)
                        }
                        obj.put("wifi_list", wifiArrAll.toString())
                        obj.put("upper_key", upperSet.mkString(""))
                        obj.put("finger_list", fingerSet.mkString(""))
                        obj.put("points", pointsAll)



                    }

                } else {
                    obj.fluentPutAll(rightObjOp.get)


                }
                obj.put("reliable",bldWhiteMap.getOrElse(obj.getString("bld_id"),"0"))

                obj
            })


        }
      //resultRdd.take(2).foreach(println(_))

        resultRdd


    }

    def mergeDetail(spark:SparkSession)={

        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_gj_detail_dtl
              |
              |
              |
              |""".stripMargin

        var resultRdd = SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj => {
            obj.put("reserve1", obj.getString("city_code"))
            obj


        })
        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_detail_dtl
              |
              |""".stripMargin
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
                obj.put("update_tag", "1")

                if (leftObjOp.nonEmpty) {
                    obj.fluentPutAll(leftObjOp.get)
                    obj.put("update_tag", "1")
                    if (rightObjOp.nonEmpty) {

                        val wifiMap = new mutable.HashMap[String, JSONObject]()
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        var wifiArr = new JSONArray()
                        var pointArr = new JSONArray()
                        var upper_key = leftObj.getString("upper_key")
                        var wifi = leftObj.getString("wifi_list")
                        var points = leftObj.getString("points")
                        val upperSet = new mutable.HashSet[String]()
                        splitFingerList(upper_key, upperSet)

                        var tracewifiArr = new JSONArray()
                        var tracepointArr = new JSONArray()
                        var traceupper_key = rightObj.getString("upper_key")
                        var tracewifi = rightObj.getString("wifi_list")
                        var tracepoints = rightObj.getString("points")

                        splitFingerList(traceupper_key, upperSet)
                        try {
                            wifiArr = JSON.parseArray(wifi)
                            pointArr = JSON.parseArray(points)
                            tracewifiArr = JSON.parseArray(tracewifi)
                            tracepointArr = JSON.parseArray(tracepoints)

                        } catch {
                            case e: Exception => {
                                logger.error(e.getMessage)

                            }
                        }

                        mergeWifiList(wifiArr, wifiMap, "0100")
                        mergeWifiList(tracewifiArr, wifiMap, "1100")
                        pointArr.fluentAddAll(tracepointArr)
                        val pointsAll = cleanPoints(pointArr.toString())
                        val (lng,lat) = calcCenterPoint(pointsAll)
                        val wifiArrAll = new JSONArray()
                        for (wifi <- wifiMap.values) {
                            wifiArrAll.add(wifi)
                        }
                        obj.put("lon",lng)
                        obj.put("lat",lat)
                        obj.put("wifi_list", wifiArrAll.toString())
                        obj.put("upper_key", upperSet.mkString(""))
                        obj.put("points", pointsAll)



                    }

                } else {
                    obj.fluentPutAll(rightObjOp.get)
                }

                obj
            })


        }

        resultRdd



    }

    def calcCenterPoint(points:String): (Double, Double) ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        var lngAll=0.0
        var latAll=0.0
        var cnt=0L

        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                val pointObj = pointArr.getJSONObject(i)
                lngAll+=pointObj.getString("x").toDouble
                latAll+=pointObj.getString("y").toDouble
                cnt+=1
            }
        }

        (lngAll/cnt,latAll/cnt)

    }

    def splitFingerMap(fingerList:String,fingerMap:mutable.HashMap[String,String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/19){
                    val finger_aoi = fingerList.substring(i * 19, (i + 1) * 19)
                    if(fingerMap.contains(finger_aoi.substring(0,16))){
                        val avg_ss = fingerMap.get(finger_aoi.substring(0, 16)).get
                        val ewl_dis = finger_aoi.substring(16)

                        fingerMap.put(finger_aoi.substring(0,16),(math.round((avg_ss.toLong+Math.abs(ewl_dis.toDouble))/2)+1000).toString.substring(1))

                    }else{
                        fingerMap.put(finger_aoi.substring(0,16),finger_aoi.substring(16))

                    }
                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def splitFingerList(fingerList:String,fingerSet:mutable.HashSet[String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/16){
                    fingerSet.add(fingerList.substring(i*16,(i+1)*16))

                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def getFingerWhite(spark:SparkSession)={
        var sql=
            """
              |
              |
              |select guid,`level`,in_use,reserve1 from (
              |select guid,`level`,in_use,reserve1,row_number()over(partition by guid,`level` order by update_date desc ) rnk from dm_gis.gis_wifi_finger_white_list where in_use = '1'
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("aoi")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //aoiWhiteMap.take(10).foreach(println(_))



        val bldWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("bld")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //bldWhiteMap.take(10).foreach(println(_))
        (spark.sparkContext.broadcast(aoiWhiteMap),spark.sparkContext.broadcast(bldWhiteMap))



    }


}
