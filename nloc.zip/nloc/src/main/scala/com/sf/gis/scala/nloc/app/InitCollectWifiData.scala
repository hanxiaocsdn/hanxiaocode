package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.utils.MacKeySaltUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

import scala.collection.mutable
import scala.collection.mutable.{ListBuffer, Set}

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-08-10 15:06
 * @TaskId:788857
 * @TaskName:
 * @Description:wifi指纹库-初始化采集wifi数据
 */

object InitCollectWifiData {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","lon","lat")
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","address","province","city","county","town","roodline","aoi","lon","lat","points")
    val saveBldKey=Array("key","wifi_list","upper_key","finger_list","bld_id","bld_key","address","province","city","county","town","roodline","aoi","building","lon","lat","points")
    val saveDetailKey=Array("key","wifi_list","upper_key","address","level","province","city","county","town","roodline","aoi","building","floor","room","lon","lat","points")
    val saveBtIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","lon","lat")

    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取收集数据")
        val wifiDataRdd = getWifiData(sparkSession)
        logger.error("计算index数据")
        val indexRdd = getCollectIndex(wifiDataRdd)
        logger.error("计算aoi数据")
        val aoiRdd = getCollectAoiData(wifiDataRdd)
        logger.error("计算bld数据")
        val bldRdd = getCollectBldData(wifiDataRdd)
        logger.error("计算detail数据")
        val detailRdd = getCollectDetail(wifiDataRdd)
        logger.error("计算detail数据")
        val btIndexRdd = getBtCollectIndex(wifiDataRdd)
        logger.error("存储index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, indexRdd, saveIndexKey, "dm_gis.dm_wifi_finger_collect_index_dtl",null, 25)
        logger.error("存储aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, aoiRdd, saveAoiKey, "dm_gis.dm_wifi_finger_collect_aoi_dtl",null, 25)
        logger.error("存储bld数据")
        SparkWrite.save2HiveStaticNew(sparkSession, bldRdd, saveBldKey, "dm_gis.dm_wifi_finger_collect_building_dtl",null, 25)
        logger.error("存储detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, detailRdd, saveDetailKey, "dm_gis.dm_wifi_finger_collect_detail_dtl",null, 25)
        logger.error("存储bt index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, btIndexRdd, saveBtIndexKey, "dm_gis.dm_bt_finger_collect_index_dtl",null, 25)





    }

    def getWifiData(spark:SparkSession)={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_collect_data_dtl_di
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val wifiDataRdd = dataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("wifi_list")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        val ewl_dis = value.getString("sig")
                        val mac_key = value.getString("mac")
                        tempObj.put("ewl_dis", ewl_dis)
                        tempObj.put("mac_key", mac_key)
                        if(StringUtils.nonEmpty(tempObj.getString("floor"))&&StringUtils.nonEmpty(tempObj.getString("room"))){
                            val floorObj = new JSONObject()
                            floorObj.fluentPutAll(tempObj)
                            floorObj.put("room","")
                            tempObj.put("floor","")
                            listBuffer+=floorObj
                            listBuffer+=tempObj

                        }else{
                            listBuffer += tempObj
                        }

                    }
                }
            }
            listBuffer.iterator
        })

        wifiDataRdd


    }

    def getCollectIndex(wifiDataRdd: RDD[JSONObject])={
        val resultRdd = wifiDataRdd.map(obj => {
            val mac_key = obj.getString("mac_key")
            val key = getHmodRowKey(mac_key, 100, 100, 1, 3)
            val aoi_key = getMd5Key(obj.getString("aoi_key"))
            val bld_key = getMd5Key(obj.getString("bld_key"))
            val floor = obj.getString("floor")
            val room = obj.getString("room")
            val md5DetaillKey = getMd5Key(obj.getString("bld_key") + floor + room)
            obj.put("aoi_key", aoi_key)
            obj.put("bld_key", bld_key)
            obj.put("finger_key", md5DetaillKey)
            obj.put("key", key)
            (key, obj)

        }).groupByKey().map(x => {

            var dataObj = new JSONObject()
            var aoi_key = ""
            var bld_key = ""
            var finger_detail = ""
            var lon = 0.0
            var lat = 0.0
            var loncnt = 0L
            val key = x._2.head.getString("key")
            val city_code = x._2.head.getString("city_code")

            val aoiSet = new mutable.HashMap[String,String]()
            val buildSet = new mutable.HashSet[String]()
            val fingerSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                val ewl_dis = obj.getString("ewl_dis")
                aoi_key=obj.getString("aoi_key")
                if(!aoiSet.contains(aoi_key)){
                    aoiSet.put(aoi_key,ewl_dis)
                }else{
                    if(StringUtils.nonEmpty(ewl_dis)){
                        val avg_ss = aoiSet.get(aoi_key).get
                        if(StringUtils.nonEmpty(avg_ss)){
                            aoiSet.put(aoi_key,(math.round((avg_ss.toLong+Math.abs(ewl_dis.toDouble))/2)+1000).toString.substring(1))
                        }


                    }

                }
                buildSet.add(obj.getString("bld_key"))
                fingerSet.add(obj.getString("finger_key"))
                val lon_ = obj.getString("lon")
                val lat_ = obj.getString("lat")
                if (StringUtils.nonEmpty(lon_) && StringUtils.nonEmpty(lat_)) {
                    lon += lon_.toDouble
                    lat += lat_.toDouble
                    loncnt += 1

                }
            }
            aoi_key=""
            for(key<-aoiSet.keySet){
                aoi_key=aoi_key+key+aoiSet.get(key).get

            }
            bld_key = buildSet.mkString("")
            finger_detail = fingerSet.mkString("")
            dataObj.put("key", key)
            dataObj.put("finger_aoi", aoi_key)
            dataObj.put("finger_bld", bld_key)
            dataObj.put("lon", lon / loncnt)
            dataObj.put("lat", lat / loncnt)
            dataObj.put("city_code", city_code)
            dataObj.put("finger_detail", finger_detail)
            dataObj.put("floor", "")
            dataObj

        })
        resultRdd


    }

    def splitFingerMap(fingerList:String,fingerMap:mutable.HashMap[String,String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/16){
                    val finger_aoi = fingerList.substring(i * 19, (i + 1) * 19)
                    if(fingerMap.contains(finger_aoi.substring(0,16))){
                        val avg_ss = fingerMap.get(finger_aoi.substring(0, 16)).get
                        val ewl_dis = finger_aoi.substring(16)

                        fingerMap.put(finger_aoi.substring(0,16),(math.round((avg_ss.toLong+Math.abs(ewl_dis.toDouble))/2)+1000).toString.substring(1))

                    }else{
                        fingerMap.put(finger_aoi.substring(0,16),finger_aoi.substring(16))

                    }
                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def getBtCollectIndex(wifiDataRdd: RDD[JSONObject])={
        val btWifiDataRdd = wifiDataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("bt_list")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        val ewl_dis = value.getString("sig")
                        val mac_key = value.getString("mac")
                        tempObj.put("bt_ewl_dis", ewl_dis)
                        tempObj.put("bt_mac_key", mac_key)
                        listBuffer += tempObj
                    }
                }
            }
            listBuffer.iterator
        })

        val resultRdd = btWifiDataRdd.map(obj => {
            val mac_key = obj.getString("bt_mac_key")
            val key = getBtHmodRowKey(mac_key, 100, 100, 1, 3)
            val aoi_key = getMd5Key(obj.getString("aoi_key"))
            val bld_key = getMd5Key(obj.getString("bld_key"))
            val floor = obj.getString("floor")
            val room = obj.getString("room")
            val md5DetaillKey = getMd5Key(obj.getString("bld_key") + floor + room)
            obj.put("aoi_key", aoi_key)
            obj.put("bld_key", bld_key)
            obj.put("finger_key", md5DetaillKey)
            obj.put("key", key)
            (key, obj)

        }).groupByKey().map(x => {

            var dataObj = new JSONObject()
            var aoi_key = ""
            var bld_key = ""
            var finger_detail = ""
            var lon = 0.0
            var lat = 0.0
            var loncnt = 0L
            val key = x._2.head.getString("key")
            val city_code = x._2.head.getString("city_code")

            val aoiSet = new mutable.HashMap[String,String]()
            val buildSet = new mutable.HashSet[String]()
            val fingerSet = new mutable.HashSet[String]()
            for (obj <- x._2) {
                val ewl_dis = obj.getString("bt_ewl_dis")
                if(!aoiSet.contains(aoi_key)){
                    aoiSet.put(aoi_key,ewl_dis)
                }else{
                    if(StringUtils.nonEmpty(ewl_dis)){
                        val avg_ss = aoiSet.get(aoi_key).get
                        if(StringUtils.nonEmpty(avg_ss)){
                            aoiSet.put(aoi_key,(math.round((avg_ss.toLong+Math.abs(ewl_dis.toDouble))/2)+1000).toString.substring(1))
                        }


                    }

                }
                buildSet.add(obj.getString("bld_key"))
                fingerSet.add(obj.getString("finger_key"))
                val lon_ = obj.getString("lon")
                val lat_ = obj.getString("lat")
                if (StringUtils.nonEmpty(lon_) && StringUtils.nonEmpty(lat_)) {
                    lon += lon_.toDouble
                    lat += lat_.toDouble
                    loncnt += 1

                }
            }
            aoi_key=""
            for(key<-aoiSet.keySet){
                aoi_key=aoi_key+key+aoiSet.get(key).get

            }
            bld_key = buildSet.mkString("")
            finger_detail = fingerSet.mkString("")
            dataObj.put("key", key)
            dataObj.put("finger_aoi", aoi_key)
            dataObj.put("finger_bld", bld_key)
            dataObj.put("lon", lon / loncnt)
            dataObj.put("lat", lat / loncnt)
            dataObj.put("city_code", city_code)
            dataObj.put("finger_detail", finger_detail)
            dataObj.put("floor", "")
            dataObj

        })
        resultRdd


    }

    def getCollectAoiData(wifiDataRdd: RDD[JSONObject])={

        val btWifiDataRdd = wifiDataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("bt_list")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        val ewl_dis = value.getString("sig")
                        val mac_key = value.getString("mac")
                        tempObj.put("bt_ewl_dis", ewl_dis)
                        tempObj.put("bt_mac_key", mac_key)
                        listBuffer += tempObj
                    }
                }
            }
            listBuffer.iterator
        })

        val resultRdd = btWifiDataRdd.map(x => (x.getString("aoi_id"), x)).groupByKey().map(x => {
            val dataObj = new JSONObject()
            val md5AoiId = getMd5Key(x._2.head.getString("aoi_id"))
            var key = math.abs(md5AoiId.hashCode) % 10 + "_" + md5AoiId
            var wifiArr = new JSONArray()
            //                    var upper_key = getMd5Key(x._2._1.get.head.getString("aoi_id"))
            var finger_list = ""

            var aoi_id = x._2.head.getString("aoi_id")
            var city_code = x._2.head.getString("city_code")
            var aoi_key = x._2.head.getString("aoi_id")

            var province = x._2.head.getString("province")
            var city = x._2.head.getString("city")
            var county = x._2.head.getString("county")
            var town = x._2.head.getString("town")
            var aoi = x._2.head.getString("aoi")
            var address = province + city + county + town + aoi
            //                    var aoi = x._2._1.get.head.getString("aoi")
            //                    var building = x._2._1.get.head.getString("building")
            var lon = ""
            var lat = ""
            var lon_cnt = 0L
            var lon_all = 0.0
            var lat_all = 0.0
            var pointArr = new JSONArray()
            val fingerSet = new mutable.HashSet[String]()
            val macSet = Set[String]()
            val btmacSet = Set[String]()
            for (obj <- x._2) {
                val mac_key = obj.getString("mac_key")
                val bt_mac_key = obj.getString("bt_mac_key")
                if (!macSet.contains(mac_key)) {
                    macSet.add(mac_key)
                    val tmpObj = new JSONObject()
                    val poinObj = new JSONObject()
                    val ewl_dis = obj.getString("ewl_dis")
                    val tm = obj.getString("timestamp")
                    val zx = obj.getString("lon")
                    val zy = obj.getString("lat")
                    tmpObj.put("mac", mac_key)
                    tmpObj.put("sig", ewl_dis)
                    tmpObj.put("num", 1)
                    tmpObj.put("time", tm)
                    tmpObj.put("source", "1000")
                    wifiArr.add(tmpObj)
                    poinObj.put("x", zx)
                    poinObj.put("y", zy)
                    pointArr.add(poinObj)
                    fingerSet.add(getMd5Key(obj.getString("bld_id")))

                    if (zx != null && zx.nonEmpty && zy != null && zy.nonEmpty) {
                        lon_cnt += 1
                        lon_all += zx.toDouble
                        lat_all += zy.toDouble

                    }
                }

                if (!btmacSet.contains(bt_mac_key)) {
                    btmacSet.add(bt_mac_key)
                    val tmpObj = new JSONObject()
                    val ewl_dis = obj.getString("bt_ewl_dis")
                    val tm = obj.getString("timestamp")
                    tmpObj.put("mac", bt_mac_key)
                    tmpObj.put("sig", ewl_dis)
                    tmpObj.put("num", 1)
                    tmpObj.put("time", tm)
                    tmpObj.put("source", "1000")
                    wifiArr.add(tmpObj)
                }
            }
            if (lon_cnt > 0) {
                lon = (lon_all / lon_cnt).toString
                lat = (lat_all / lon_cnt).toString

            }

            dataObj.put("key", key)
            dataObj.put("wifi_list", wifiArr.toString())
            finger_list = fingerSet.mkString("")
            dataObj.put("finger_list", finger_list)
            dataObj.put("address", address)
            dataObj.put("aoi_id", aoi_id)
            dataObj.put("aoi_key", aoi_key)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("aoi", aoi)
            dataObj.put("lon", lon)
            dataObj.put("lat", lat)
            dataObj.put("city_code", city_code)
            dataObj.put("points", pointArr.toString())

            dataObj

        })

        resultRdd


    }

    def getCollectBldData(wifiDataRdd: RDD[JSONObject])={

        val btWifiDataRdd = wifiDataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("bt_list")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        val ewl_dis = value.getString("sig")
                        val mac_key = value.getString("mac")
                        tempObj.put("bt_ewl_dis", ewl_dis)
                        tempObj.put("bt_mac_key", mac_key)
                        listBuffer += tempObj
                    }
                }
            }
            listBuffer.iterator
        })

        val resultRdd = btWifiDataRdd.map(x => (x.getString("bld_key"), x)).groupByKey().map(x => {
            val dataObj = new JSONObject()
            var md5BldId = getMd5Key(x._2.head.getString("bld_id"))
            var key = math.abs(md5BldId.hashCode) % 10 + "_" + md5BldId
            var wifiArr = new JSONArray()
            var upper_key = getMd5Key(x._2.head.getString("aoi_id"))
            var finger_list = ""
            val fingerSet = new mutable.HashSet[String]()
            var bld_id = x._2.head.getString("bld_id")
            var bld_key = x._2.head.getString("bld_id")

            var province = x._2.head.getString("province")
            var city = x._2.head.getString("city")
            var city_code = x._2.head.getString("city_code")
            var county = x._2.head.getString("county")
            var town = x._2.head.getString("town")
            var aoi = x._2.head.getString("aoi")
            var building = x._2.head.getString("building")
            var address = province + city + county + town + aoi + building
            var lon = ""
            var lat = ""
            var lon_cnt = 0L
            var lon_all = 0.0
            var lat_all = 0.0
            var pointArr = new JSONArray()
            val macSet = Set[String]()
            val btmacSet = Set[String]()
            for (obj <- x._2) {
                val mac_key = obj.getString("mac_key")
                val bt_mac_key = obj.getString("bt_mac_key")
                val bld_key = obj.getString("bld_key")
                val floor = obj.getString("floor")
                val room = obj.getString("room")
                val finger = getMd5Key(bld_key + floor + room)
                if (StringUtils.nonEmpty(finger)) {
                    fingerSet.add(finger)
                }
                if (!macSet.contains(mac_key)) {
                    macSet.add(mac_key)
                    val tmpObj = new JSONObject()
                    val poinObj = new JSONObject()
                    val ewl_dis = obj.getString("ewl_dis")
                    val tm = obj.getString("timestamp")
                    val zx = obj.getString("lon")
                    val zy = obj.getString("lat")
                    tmpObj.put("mac", mac_key)
                    tmpObj.put("sig", ewl_dis)
                    tmpObj.put("num", 1)
                    tmpObj.put("time", tm)
                    tmpObj.put("source", "1000")
                    wifiArr.add(tmpObj)
                    poinObj.put("x", zx)
                    poinObj.put("y", zy)
                    pointArr.add(poinObj)
                    if (zx != null && zx.nonEmpty && zy != null && zy.nonEmpty) {
                        lon_cnt += 1
                        lon_all += zx.toDouble
                        lat_all += zy.toDouble

                    }
                }

                if (!btmacSet.contains(bt_mac_key)) {
                    btmacSet.add(bt_mac_key)
                    val tmpObj = new JSONObject()
                    val ewl_dis = obj.getString("bt_ewl_dis")
                    val tm = obj.getString("timestamp")
                    tmpObj.put("mac", bt_mac_key)
                    tmpObj.put("sig", ewl_dis)
                    tmpObj.put("num", 1)
                    tmpObj.put("time", tm)
                    tmpObj.put("source", "1000")
                    wifiArr.add(tmpObj)
                }


            }
            if (lon_cnt > 0) {
                lon = (lon_all / lon_cnt).toString
                lat = (lat_all / lon_cnt).toString

            }
            finger_list = fingerSet.mkString("")
            dataObj.put("key", key)
            dataObj.put("wifi_list", wifiArr.toString())
            dataObj.put("upper_key", upper_key)
            dataObj.put("finger_list", finger_list)
            dataObj.put("bld_id", bld_id)
            dataObj.put("bld_key", bld_key)
            dataObj.put("address", address)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("city_code", city_code)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("aoi", aoi)
            dataObj.put("building", building)
            dataObj.put("lon", lon)
            dataObj.put("lat", lat)
            dataObj.put("points", pointArr.toString())
            dataObj


        })
        resultRdd

    }

    def getCollectDetail(wifiDataRdd: RDD[JSONObject])={
        val btWifiDataRdd = wifiDataRdd.mapPartitions(iter => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- iter) {
                val ewl = obj.getString("bt_list")
                val ewlArr = try {
                    JSON.parseArray(ewl)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                        new JSONArray()
                    }
                }
                if (ewlArr.size() > 0) {
                    for (i <- 0 until ewlArr.size()) {
                        val tempObj = new JSONObject()
                        tempObj.fluentPutAll(obj)
                        val value = ewlArr.getJSONObject(i)
                        val ewl_dis = value.getString("sig")
                        val mac_key = value.getString("mac")
                        tempObj.put("bt_ewl_dis", ewl_dis)
                        tempObj.put("bt_mac_key", mac_key)
                        listBuffer += tempObj
                    }
                }
            }
            listBuffer.iterator
        })

        val resultRdd = btWifiDataRdd.map(obj => {
            val bld_key = obj.getString("bld_key")
            val floor = obj.getString("floor")
            val room = obj.getString("room")
            if (StringUtils.nonEmpty(floor) || StringUtils.nonEmpty(room)) {
                val md5DetaillKey = getMd5Key(bld_key + floor + room)
                val key = math.abs(md5DetaillKey.hashCode) % 10 + "_" + md5DetaillKey
                obj.put("key", key)
                (key, obj)
            } else {
                ("", null)
            }

        }).filter(x => StringUtils.nonEmpty(x._1)).groupByKey().map(x => {
            val dataObj = new JSONObject()
            var key = x._1
            var wifiArr = new JSONArray()
            var upper_key = getMd5Key(x._2.head.getString("bld_id"))
            var finger_list = ""
            var level = x._2.head.getString("level")
            var bld_key = x._2.head.getString("bld_id")

            var province = x._2.head.getString("province")
            var city = x._2.head.getString("city")
            var city_code = x._2.head.getString("city_code")
            var county = x._2.head.getString("county")
            var town = x._2.head.getString("town")
            var aoi = x._2.head.getString("aoi")
            var floor = x._2.head.getString("floor")
            var room = x._2.head.getString("room")
            var building = x._2.head.getString("building")
            var roodline = x._2.head.getString("roodline")
            var address = province + city + county + town + roodline + aoi + building + floor + room
            var lon = ""
            var lat = ""
            var lon_cnt = 0L
            var lon_all = 0.0
            var lat_all = 0.0
            var pointArr = new JSONArray()
            val macSet = Set[String]()
            val btmacSet = Set[String]()
            for (obj <- x._2) {
                val mac_key = obj.getString("mac_key")
                val bt_mac_key = obj.getString("bt_mac_key")
                if (!macSet.contains(mac_key)) {
                    macSet.add(mac_key)
                    val tmpObj = new JSONObject()
                    val poinObj = new JSONObject()
                    val ewl_dis = obj.getString("ewl_dis")
                    val tm = obj.getString("timestamp")
                    val zx = obj.getString("lon")
                    val zy = obj.getString("lat")
                    tmpObj.put("mac", mac_key)
                    tmpObj.put("sig", ewl_dis)
                    tmpObj.put("num", 1)
                    tmpObj.put("time", tm)
                    tmpObj.put("source", "1000")
                    wifiArr.add(tmpObj)
                    poinObj.put("x", zx)
                    poinObj.put("y", zy)
                    pointArr.add(poinObj)
                    finger_list = finger_list + getMd5Key(obj.getString("bld_id"))
                    if (zx != null && zx.nonEmpty && zy != null && zy.nonEmpty) {
                        lon_cnt += 1
                        lon_all += zx.toDouble
                        lat_all += zy.toDouble

                    }
                }


                if (!btmacSet.contains(bt_mac_key)) {
                    btmacSet.add(bt_mac_key)
                    val tmpObj = new JSONObject()
                    val ewl_dis = obj.getString("bt_ewl_dis")
                    val tm = obj.getString("timestamp")
                    tmpObj.put("mac", bt_mac_key)
                    tmpObj.put("sig", ewl_dis)
                    tmpObj.put("num", 1)
                    tmpObj.put("time", tm)
                    tmpObj.put("source", "1000")
                    wifiArr.add(tmpObj)
                }


            }
            if (lon_cnt > 0) {
                lon = (lon_all / lon_cnt).toString
                lat = (lat_all / lon_cnt).toString

            }
            dataObj.put("key", key)
            dataObj.put("wifi_list", wifiArr.toString())
            dataObj.put("finger_list", finger_list)
            dataObj.put("address", address)
            dataObj.put("level", level)
            dataObj.put("upper_key", upper_key)
            dataObj.put("building", building)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("city_code", city_code)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("aoi", aoi)
            dataObj.put("roodline", roodline)
            dataObj.put("floor", floor)
            dataObj.put("room", room)
            dataObj.put("lon", lon)
            dataObj.put("lat", lat)
            dataObj.put("points", pointArr.toString())
            dataObj.put("update_tag", "1")

            dataObj
        })
        resultRdd


    }

    def getHmodRowKey(user_id:String,mod:Int,covering:Int,start_index:Int,end_index:Int)={
        val prefix = (Math.abs(user_id.hashCode) % mod) + covering
        val rowKey = prefix.toString.substring(start_index, end_index)+"_"+user_id

        rowKey

    }

    def getBtHmodRowKey(user_id:String,mod:Int,covering:Int,start_index:Int,end_index:Int)={
        val prefix = (Math.abs(user_id.split("_")(1).hashCode) % mod) + covering
        val rowKey = prefix.toString.substring(start_index, end_index)+"_"+user_id

        rowKey

    }

    def getMd5Key(addr:String)={
        var resultMd5Str=""
        if(addr!=null&&addr.nonEmpty&&(!addr.equals("null"))){
            val md5addr = MD5Util.getMD5(addr)
            resultMd5Str=md5addr.toLowerCase.substring(8, 24)
        }
        resultMd5Str

    }

}
