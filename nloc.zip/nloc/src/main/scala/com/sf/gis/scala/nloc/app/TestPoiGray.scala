package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

import java.util
import java.util.Map

/**
 * @ProductManager:01425237
 * @Author: 01407499
 * @CreateTime: 2023-08-19 20:16
 * @TaskId:791123
 * @TaskName:
 * @Description:一次性任务，测试atpoi接口
 */

object TestPoiGray {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val poiUrl="http://gis-gw.int.sfdc.com.cn:9080/atpoi/api"
    val saveKey=Array("address","aoi_id","citycode","result_aoiid","result_splitresult","result_buildingid","result_x","result_y","result_bulidingtype","result_floortype","result_bulidingcode","result_floorcode","result_unitid","result_floorid","result_roomid","result_buildingname","result_unitname","result_floorname","result_roomname","result_levelsrc","result_detailsrc","result_nametag","result_roomids","result_roomdetailsrc","result_roomnames","result_floordetailsrc","requestdata")
    def main(args: Array[String]): Unit = {

        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = getPoiData(sparkSession)
        logger.error("开始存储数据")
        SparkWrite.save2HiveStatic(sparkSession, resultRdd, saveKey, "tmp_dm_gis.poi_test_gray_data",null, 25)




    }

    def getPoiData(spark:SparkSession)={
        var sql=
            """
              |
              |select address,aoi_id,citycode from tmp_dm_gis.addr_info_test_poi
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val addr = obj.getString("address")
            val aoi_id = obj.getString("aoi_id")
            val citycode = obj.getString("citycode")
            val tmpobj = new JSONObject()
            tmpobj.put("cityCode", citycode)
            tmpobj.put("address", addr)
            tmpobj.put("aoiId", aoi_id)
            tmpobj.put("requestId", "1")

            //tmpobj.put("ak", "f0647fe825ff4bd3b8a0b469e295f6be ")
            val requestObj = getInterfaceData(tmpobj)

            val result_aoiid = JSONUtil.getJsonVal(requestObj, "result.data.aoiId", "")
            val result_splitresult = JSONUtil.getJsonVal(requestObj, "result.data.splitResult", "")
            val result_buildingid = JSONUtil.getJsonVal(requestObj, "result.data.buildingId", "")
            val result_x = JSONUtil.getJsonVal(requestObj, "result.data.x", "")
            val result_y = JSONUtil.getJsonVal(requestObj, "result.data.y", "")
            val result_bulidingtype = JSONUtil.getJsonVal(requestObj, "result.data.buildingType", "")
            val result_floortype = JSONUtil.getJsonVal(requestObj, "result.data.floorType", "")
            val result_bulidingcode = JSONUtil.getJsonVal(requestObj, "result.data.buildingCode", "")
            val result_floorcode = JSONUtil.getJsonVal(requestObj, "result.data.floorCode", "")
            val result_unitid = JSONUtil.getJsonVal(requestObj, "result.data.unitId", "")
            val result_floorid = JSONUtil.getJsonVal(requestObj, "result.data.floorId", "")
            val result_roomid = JSONUtil.getJsonVal(requestObj, "result.data.roomId", "")
            val result_buildingname = JSONUtil.getJsonVal(requestObj, "result.data.buildingName", "")
            val result_unitname = JSONUtil.getJsonVal(requestObj, "result.data.unitName", "")
            val result_floorname = JSONUtil.getJsonVal(requestObj, "result.data.floorName", "")
            val result_roomname = JSONUtil.getJsonVal(requestObj, "result.data.roomName", "")
            val result_levelsrc = JSONUtil.getJsonVal(requestObj, "result.data.levelSrc", "")
            val result_detailsrc = JSONUtil.getJsonVal(requestObj, "result.data.detailSrc", "")
            val result_nametag = JSONUtil.getJsonVal(requestObj, "result.data.nameTag", "")
            val result_roomids = JSONUtil.getJsonVal(requestObj, "result.data.roomIds", "")
            val result_roomdetailsrc = JSONUtil.getJsonVal(requestObj, "result.data.roomDetailSrc", "")
            val result_roomnames = JSONUtil.getJsonVal(requestObj, "result.data.roomNames", "")
            val result_floordetailsrc = JSONUtil.getJsonVal(requestObj, "result.data.floorDetailSrc", "")
            obj.put("result_aoiid", result_aoiid)
            obj.put("result_splitresult", result_splitresult)
            obj.put("result_buildingid", result_buildingid)
            obj.put("result_x", result_x)
            obj.put("result_y", result_y)
            obj.put("result_bulidingtype", result_bulidingtype)
            obj.put("result_floortype", result_floortype)
            obj.put("result_bulidingcode", result_bulidingcode)
            obj.put("result_floorcode", result_floorcode)
            obj.put("result_unitid", result_unitid)
            obj.put("result_floorid", result_floorid)
            obj.put("result_roomid", result_roomid)
            obj.put("result_buildingname", result_buildingname)
            obj.put("result_unitname", result_unitname)
            obj.put("result_floorname", result_floorname)
            obj.put("result_roomname", result_roomname)
            obj.put("result_levelsrc", result_levelsrc)
            obj.put("result_detailsrc", result_detailsrc)
            obj.put("result_nametag", result_nametag)
            obj.put("result_roomids", result_roomids)
            obj.put("result_roomdetailsrc", result_roomdetailsrc)
            obj.put("result_roomnames", result_roomnames)
            obj.put("result_floordetailsrc", result_floordetailsrc)
            obj.put("requestdata", requestObj)

            obj



        })

        resultRdd




    }

    def getInterfaceData(parm:JSONObject)={

        val stringToString = new util.HashMap[String, String]()
        stringToString.put("ak","f0647fe825ff4bd3b8a0b469e295f6be")
        var jSONObject = try {
            Thread.sleep(250)
            JSON.parseObject(HttpUtils.postJson(poiUrl, parm, stringToString))

        }
        catch {
            case _=>{
                logger.error("error parameter-----> "+parm.toString())
                new JSONObject()
            }
        }

        jSONObject




    }





}
