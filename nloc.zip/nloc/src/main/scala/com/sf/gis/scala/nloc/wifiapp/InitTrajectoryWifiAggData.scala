package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.nloc.utils.MacKeySaltUtils
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.app.InitCollectWifiData.getMd5Key
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiDailyData.splitFingerMap
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.{ListBuffer, Set}
import scala.util.Random


/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-12-12 18:08
 * @TaskId:726910
 * @TaskName:
 * @Description:轨迹wifi数据计算-新版-聚合数据
 */

object InitTrajectoryWifiAggData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","address")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","buildingname","address")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","buildingid","aoi_id","lng","lat","city_code","province","city","county","town","village","decrypt_wifi")
    val saveDetailKey=Array("key","wifi_list","upper_key","floor","room","level","buildingid","bld_key","aoi_id","aoi_key","lng","lat","points","city_code","province","city","county","town","village","aoi_name","buildingname","address")
    val citycodeArr=Array("010","020","021","022","023","024","025","027","028","029","052","053","086","088","310","311","312","313","314","315","316","317","318","319","335","349","350","351","352","353","354","355","356","357","358","359","370","371","372","373","374","375","376","377","378","379","391","392","393","394","395","396","398","411","412","414","415","416","417","418","419","421","427","429","431","432","433","434","435","436","437","438","439","451","452","453","454","455","456","457","458","459","464","467","468","469","470","471","472","473","474","475","476","477","478","479","482","483","510","511","512","513","514","515","516","517","518","519","523","527","530","531","532","533","534","535","536","537","538","539","543","546","550","551","552","553","554","555","556","557","558","559","561","562","563","564","566","570","571","572","573","574","575","576","577","578","579","580","591","592","593","594","595","596","597","598","599","631","632","633","635","660","662","663","668","691","692","701","710","711","712","713","714","715","716","717","718","719","722","724","728","730","734","735","736","737","738","739","743","744","745","746","750","751","752","753","754","755","756","757","758","759","760","762","763","766","768","769","770","771","772","773","774","775","776","777","778","779","790","791","792","793","794","795","796","797","798","799","812","813","816","817","818","825","826","827","830","831","832","833","834","835","836","837","838","839","851","852","853","854","855","856","857","858","859","870","871","872","873","874","875","876","877","878","879","883","886","887","891","892","893","894","895","896","897","898","901","902","903","906","908","909","911","912","913","914","915","916","917","919","930","931","932","933","934","935","936","937","938","939","941","943","951","952","953","954","955","970","971","972","973","974","975","976","977","979","990","991","992","993","994","995","996","997","998","999","7311","7312","7313","8981","8983")

    //wifi_finger_traj_month_index
    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val end_day=args(0)
        val start_day=args(1)
        val mode=args(2)
        mode match {
            case "index"=>calcIndexWifiData(sparkSession,end_day,start_day)
            case "aoi"=>calcAoiWifiData(sparkSession,end_day,start_day)
            case "bld"=>calcBldWifiData(sparkSession,end_day,start_day)
            case "detail"=>calcDetailWifiData(sparkSession,end_day,start_day)
            case "monthindex"=>calcMonthIndexWifiData(sparkSession,end_day,start_day)
        }

    }

    def calcAoiWifiData(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("开始计算wifi aoi数据")
        val apAoiWifiDataRdd = getGjAoi(sparkSession,aoiWhiteMapBroad,end_day,start_day)
        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apAoiWifiDataRdd, saveAoiKey, "dm_gis.dm_wifi_finger_traj_aoi_dtl",null, 25)
        logger.error("广播变量id-----》"+aoiWhiteMapBroad.id)
        Spark.clearAllPersist(sparkSession)



    }

    def calcIndexWifiData(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("开始计算wifi index数据")
        val apIndexWifiData = getGjIndex(sparkSession, end_day,start_day,"dm_gis.dm_wifi_finger_traj_month_index_dtl_di")
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apIndexWifiData, saveIndexKey, "dm_gis.dm_wifi_finger_traj_index_dtl",null, 50)
        apIndexWifiData.unpersist()



    }

    def calcMonthIndexWifiData(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("开始计算wifi index数据")
        val apIndexWifiData = getGjIndex(sparkSession, end_day,start_day,"dm_gis.dm_wifi_finger_traj_daily_index_dtl_di")
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apIndexWifiData, saveIndexKey, "dm_gis.dm_wifi_finger_traj_month_index_dtl_di",Array(("inc_day", end_day)), 50)
        apIndexWifiData.unpersist()



    }


    def calcBldWifiData(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("开始计算wifi build数据")
        val apBuildWifiDataRdd = getGjBuild(sparkSession,bldWhiteMapBroad,end_day,start_day)
        logger.error("存储wifi build数据")
        SparkWrite.save2HiveStaticNew(sparkSession, apBuildWifiDataRdd, saveBuildKey, "dm_gis.dm_wifi_finger_traj_bld_dtl",null, 25)

    }

    def calcDetailWifiData(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("开始计算 wifi detail数据")
        val fingerDetailDataRdd = getFingerDetail(sparkSession,end_day,start_day)
        logger.error("存储 wifi detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, fingerDetailDataRdd, saveDetailKey, "dm_gis.dm_wifi_finger_traj_detail_dtl",null, 25)

    }

    def getWifiMidData(spark:SparkSession,end_day:String)={
        var sql=
            s"""
              |select operatime_new,eventtype,city_code,waybillno,consignee_addr,src_city_code,deliver_emp_code,id,un,ewl,tm,zx,zy,doing,aoi_key,bld_key,aoi_id,bld_id,province,city,county,town,roodline,aoi,building,floor,room,level,tag,consignee_addr address from dm_gis.wifi_finger_v1_mid where inc_day='$end_day' and aoi_id is not null and bld_id is not null and  aoi_id<>'' and bld_id<>'' and building<>'' and building!='null' and tag='ok'
              |""".stripMargin

       sql=
           s"""
             |
             |select city_code,emp_code,tm,addr,ewl,lng,lat,aoi_id,aoi_name,buildingid,buildingname,lng_bld,lat_bld,province,city,county,town,village,floor,room,tag,cast(unix_timestamp(tm,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp from dm_gis.dm_wifi_finger_traj_dtl_di where inc_day='$end_day' and aoi_id<>'' and aoi_id is not null and tag=''
             |
             |
             |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)



        dataRdd


    }



    /**
     *
     * @param spark
     * @param wifiDataRdd
     * @return
     */
    def getGjIndex(spark:SparkSession,end_day:String,start_day:String,from_table:String)={
        var sql=s"select * from dm_gis.dm_wifi_finger_traj_daily_index_dtl_di where inc_day>='$start_day' and inc_day<='$end_day' and length(finger_aoi)<=1900"

        sql=
            s"""
              |
              |
              |select * from $from_table where inc_day>='$start_day' and inc_day<='$end_day' and length(finger_aoi)<=1900
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd=dataRdd.filter(x=>StringUtils.nonEmpty(x.getString("key"))).groupBy(x=>x.getString("key")).flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            dataObj.fluentPutAll(x._2.head)
            var finger_aoi=""
            var finger_bld=""
            var finger_detail=""
            for(obj<-x._2){
                finger_aoi+=obj.getString("finger_aoi")
                finger_bld+=obj.getString("finger_bld")
                finger_detail+=obj.getString("finger_detail")


            }
            val aoiSet = new mutable.HashMap[String,String]()
            val buildMap = new mutable.HashMap[String,String]()
            val fingerMap = new mutable.HashMap[String,String]()
            val fingerbldSet = new mutable.HashSet[String]()
            val fingeraoiSet = new mutable.HashSet[String]()
            val fingerdetailSet = new mutable.HashSet[String]()
            splitFingerMap(finger_aoi,aoiSet)
            splitFingerMap(finger_bld,buildMap)
            splitFingerMap(finger_detail,fingerMap)
            splitFingerList(finger_bld, fingerbldSet)
            splitFingerList(finger_detail, fingerdetailSet)
            var aoi_key=""
            for(key<-aoiSet.keySet){
                aoi_key=aoi_key+key+aoiSet.get(key).get

            }
            var bld_key=""
            for(key<-buildMap.keySet){
                bld_key=bld_key+key+buildMap.get(key).get

            }

            var finger_key=""
            for(key<-fingerMap.keySet){
                finger_key=finger_key+key+fingerMap.get(key).get

            }
            dataObj.put("finger_aoi", aoi_key)
            dataObj.put("aoi_id", "")
            dataObj.put("buildingid", "")
            dataObj.put("finger_bld", fingerbldSet.mkString(""))
            if(fingerbldSet.size>0)
            dataObj.put("finger_detail", fingerdetailSet.mkString(""))

            if(StringUtils.nonEmpty(bld_key)&&bld_key.length>16){
                dataObj.put("finger_bld", bld_key)
                if(StringUtils.nonEmpty(finger_key)&&finger_key.length>16){
                    dataObj.put("finger_detail", finger_key)
                }
            }
            listBuffer+=dataObj
            listBuffer

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("index数据量---》"+resultRdd.count())

        resultRdd



    }



    def getGjBuild(spark:SparkSession,bldWhiteMapBroad:Broadcast[Map[String, String]],end_day:String,start_day:String)={
        var sql=s"select * from dm_gis.dm_wifi_finger_traj_daily_bld_dtl_di where inc_day>='$start_day' and inc_day<='$end_day'"


        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd =dataRdd.groupBy(x=>x.getString("buildingid")).flatMap(x=>{
            val bldWhiteMap = bldWhiteMapBroad.value
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            val wifiArr = new JSONArray()
            val pointArr = new JSONArray()
            val fingerSet = new mutable.HashSet[String]()
            val fingeraoiSet=new mutable.HashSet[String]()
            var finger=""
            var finger_aoi=""
            dataObj.fluentPutAll(x._2.head)
            dataObj.put("update_tag","1")
            dataObj.put("reliable",bldWhiteMap.getOrElse(x._1,"0"))

            for(obj<-x._2){
                try {
                    val points = JSON.parseArray(obj.getString("points"))
                    val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
                    val finger_list = obj.getString("finger_list")
                    val upper_key = obj.getString("upper_key")
                    wifiArr.fluentAddAll(wifi_list)
                    pointArr.fluentAddAll(points)
                    finger+=finger_list
                    finger_aoi+=upper_key


                }catch {case e:Exception=>logger.error(e.toString)}


            }
            val wifiDataArr = cleanWifi(wifiArr, "0100")
            val pointsAll = cleanPoints(pointArr.toString())
            val (lng, lat) = calcCenterPoint(pointsAll)
            splitFingerList(finger,fingerSet)
            splitFingerList(finger_aoi,fingeraoiSet)
            dataObj.put("wifi_list",wifiDataArr.toString())
            dataObj.put("points",pointsAll)
            dataObj.put("finger_list",fingerSet.mkString(""))
            dataObj.put("upper_key",fingeraoiSet.mkString(""))
            listBuffer+=dataObj


            listBuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("bld数据量---》"+resultRdd.count())
        resultRdd

    }

    def getGjAoi(spark:SparkSession,aoiWhiteMapBroad:Broadcast[Map[String, String]],end_day:String,start_day:String)={
        var sql=s"select * from dm_gis.dm_wifi_finger_traj_daily_aoi_dtl_di where inc_day>='$start_day' and inc_day<='$end_day'"

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)


        val resultRdd=dataRdd.groupBy(x=>x.getString("aoi_id")).flatMap(x=>{
            val aoiWhiteMap = aoiWhiteMapBroad.value
            val listbuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            val wifiArr = new JSONArray()
            val pointArr = new JSONArray()
            val fingerSet = new mutable.HashSet[String]()
            var finger=""
            dataObj.fluentPutAll(x._2.head)
            dataObj.put("update_tag","1")
            dataObj.put("reliable",aoiWhiteMap.getOrElse(x._1,"0"))
            for(obj<-x._2){
                try {
                    val points = JSON.parseArray(obj.getString("points"))
                    val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
                    val finger_list = obj.getString("finger_list")
                    wifiArr.fluentAddAll(wifi_list)
                    pointArr.fluentAddAll(points)
                    finger+=finger_list


                }catch {case e:Exception=>logger.error(e.toString)}


            }
            val wifiDataArr = cleanWifi(wifiArr, "0100")
            val pointsAll = cleanPoints(pointArr.toString())
            val (lng, lat) = calcCenterPoint(pointsAll)
            splitFingerList(finger,fingerSet)
            dataObj.put("finger_list", fingerSet.mkString(""))
            dataObj.put("wifi_list", wifiDataArr.toString())
            dataObj.put("lon",lng)
            dataObj.put("lat",lat)
            dataObj.put("points",pointsAll)


            listbuffer+=dataObj


            listbuffer

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("aoi数据量---》"+resultRdd.count())
        resultRdd

    }

    def cleanPoints(points:String): String ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        val pointSet = new mutable.HashSet[String]()
        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                pointSet.add(pointArr.getJSONObject(i).toString())

            }


            "["+pointSet.mkString(",")+"]"
        }else{
             ""
        }
    }

    def  transformSaltWifiList(ewl:String,date_time_timestamp:String,source:String)={

        val dataArr = new JSONArray()
        val ewlArr = try {
            JSON.parseArray(ewl)
        } catch {
            case e: Exception => {
                logger.error(e.getMessage)
                new JSONArray()
            }
        }
        if (ewlArr.size() > 0) {
            for (i <- 0 until ewlArr.size()) {
                val tempObj = new JSONObject()
                val value = ewlArr.getJSONObject(i)
                var ewl_dis = value.getString("ss")
                val mac_key = MacKeySaltUtils.getWifiMacKey(value.getString("mac"))
                tempObj.put("sig", ewl_dis)
                tempObj.put("mac", mac_key)
                tempObj.put("num", 1)
                tempObj.put("time", date_time_timestamp)
                tempObj.put("source", source)
                dataArr.add(tempObj)

            }
        }

        dataArr

    }

    def cleanWifi(wifiArr:JSONArray,source:String) ={
        val dataMap = new mutable.HashMap[String, (Long, Int, Int)]()
        val dataArr = new JSONArray()
        if(wifiArr.size()>0){
            for (i <- 0 until wifiArr.size()) {
                try {
                    val ewlObj = wifiArr.getJSONObject(i)
                    val mac = ewlObj.getString("mac")
                    var time = ewlObj.getString("time").toLong
                    var sig = ewlObj.getString("sig").toInt
                    var num = ewlObj.getString("num").toInt
                    if(dataMap.contains(mac)){
                        val tuple = dataMap.get(mac).get
                        if(time<tuple._1){
                            time=tuple._1
                        }
                        sig=(sig+tuple._2)/2
                        num=num+tuple._3
                        dataMap.put(mac,(time,sig,num))

                    }else{
                        dataMap.put(mac,(time,sig,num))
                    }

                }catch {case e:Exception=>logger.error(e.toString)}

            }
            if(dataMap.size>0){
                for(key<-dataMap.keySet){
                    val tempObj = new JSONObject()
                    val tuple = dataMap.get(key).get
                    tempObj.put("sig", tuple._2)
                    tempObj.put("mac", key)
                    tempObj.put("num", tuple._3)
                    tempObj.put("time", tuple._1)
                    tempObj.put("source", source)
                    dataArr.add(tempObj)
                }
            }
        }
        dataArr

    }

    def cleanEncripeWifi(wifiArr:JSONArray) ={
        val dataMap = new mutable.HashMap[String, Int]()
        val dataArr = new JSONArray()
        if(wifiArr.size()>0){
            for (i <- 0 until wifiArr.size()) {
                try {
                    val ewlObj = wifiArr.getJSONObject(i)
                    val mac = ewlObj.getString("mac")
                    var sig = ewlObj.getString("ss").toInt
                    if(dataMap.contains(mac)){
                        val sigAvg = dataMap.get(mac).get
                        sig=(sig+sigAvg)/2
                        dataMap.put(mac,sig)
                    }else{
                        dataMap.put(mac,sig)
                    }

                }catch {case e:Exception=>logger.error(e.toString)}

            }
            if(dataMap.size>0){
                for(key<-dataMap.keySet){
                    val tempObj = new JSONObject()
                    val sigAvg = dataMap.get(key).get
                    tempObj.put("ss", sigAvg)
                    tempObj.put("mac", key)
                    dataArr.add(tempObj)
                }
            }
        }
        dataArr

    }
    def calcCenterPoint(points:String): (Double, Double) ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        var lngAll=0.0
        var latAll=0.0
        var cnt=0L

        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                val pointObj = pointArr.getJSONObject(i)
                lngAll+=pointObj.getString("x").toDouble
                latAll+=pointObj.getString("y").toDouble
                cnt+=1
            }
        }

        (lngAll/cnt,latAll/cnt)

    }
    def splitFingerList(fingerList:String,fingerSet:mutable.HashSet[String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/16){
                    fingerSet.add(fingerList.substring(i*16,(i+1)*16))

                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def splitFingerMap(fingerList:String,fingerMap:mutable.HashMap[String,String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/19){
                    val finger_aoi = fingerList.substring(i * 19, (i + 1) * 19)
                    if(fingerMap.contains(finger_aoi.substring(0,16))){
                        val avg_ss = fingerMap.get(finger_aoi.substring(0, 16)).get
                        val ewl_dis = finger_aoi.substring(16)

                        fingerMap.put(finger_aoi.substring(0,16),(math.round((math.abs(avg_ss.toLong)+Math.abs(ewl_dis.toDouble))/2)+1000).toString.substring(1))

                    }else{
                        fingerMap.put(finger_aoi.substring(0,16),finger_aoi.substring(16))

                    }
                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def getFingerDetail(spark:SparkSession,end_day:String,start_day:String)={

        var sql=
            s"""
              |
              |select * from dm_gis.dm_wifi_finger_traj_daily_detail_dtl_di where inc_day>='$start_day' and inc_day<='$end_day'
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd =dataRdd.groupBy(x=>x.getString("key")).flatMap(x=>{

            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            val wifiArr = new JSONArray()
            val pointArr = new JSONArray()
            val fingeraoiSet=new mutable.HashSet[String]()
            var finger_aoi=""
            dataObj.fluentPutAll(x._2.head)
            dataObj.put("update_tag","1")
            for(obj<-x._2){
                try {
                    val points = JSON.parseArray(obj.getString("points"))
                    val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
                    val upper_key = obj.getString("upper_key")
                    wifiArr.fluentAddAll(wifi_list)
                    pointArr.fluentAddAll(points)
                    finger_aoi+=upper_key

                }catch {case e:Exception=>logger.error(e.toString)}
            }
            val wifiDataArr = cleanWifi(wifiArr, "0100")
            val pointsAll = cleanPoints(pointArr.toString())
            val (lng, lat) = calcCenterPoint(pointsAll)
            splitFingerList(finger_aoi,fingeraoiSet)
            dataObj.put("wifi_list",wifiDataArr.toString())
            dataObj.put("points",pointsAll)
            dataObj.put("upper_key",fingeraoiSet.mkString(""))
            listBuffer+=dataObj
            listBuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("bld数据量---》"+resultRdd.count())

        resultRdd

    }

    def getFingerWhite(spark:SparkSession)={
        var sql=
            """
              |
              |
              |select guid,`level`,in_use,reserve1 from (
              |select guid,`level`,in_use,reserve1,row_number()over(partition by guid,`level` order by update_date desc ) rnk from dm_gis.gis_wifi_finger_white_list where in_use = '1'
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("aoi")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //aoiWhiteMap.take(10).foreach(println(_))



        val bldWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("bld")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //bldWhiteMap.take(10).foreach(println(_))
        (spark.sparkContext.broadcast(aoiWhiteMap),spark.sparkContext.broadcast(bldWhiteMap))



    }

    /**
     *
     * @param user_id key
     * @param mod 取模，也就是hbase预分region
     * @param covering 由于hbase region 是以固定位数为开头，比如预分region是100 ，则region开头是 00-99，因此这里需要加上100
     * @param start_index 截取的，起始
     * @param end_index 截取的，终止
     * @return
     * 以预分region 100请求示例：
     * val user_id = getHmodRowKey("4e47db3df1aed721", 100, 100, 1, 3)
     *
     * 如果只有10个预分区，那就直接 0-9，可以直接 (Math.abs(user_id.hashCode) % mod)+"_"+user_id
     */
    def getHmodRowKey(user_id:String,mod:Int,covering:Int,start_index:Int,end_index:Int)={
        var rowKey=""

        try{
            val prefix = (Math.abs(user_id.hashCode) % mod) + covering
            rowKey = prefix.toString.substring(start_index, end_index)+"_"+user_id
        }catch {case e:Exception=>logger.error(e.toString)}

        rowKey

    }




}
