package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 * @ProductManager:01394382 张萍
 * @Author: 01374443 张想远 (单天赐代码改造)
 * @CreateTime: 2023-03-03 14:06
 * @TaskId:436877,
 * @TaskName:LssWifiDay
 * @Description: 基站类数据统计 ,
 */
object LssCoreWifiDay {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  var partition = 300

  val wifi_table = "dm_gis.gis_lss_core_wifi"

  def main(args: Array[String]): Unit = {
    val mode = args(1)
    if (!StringUtils.isEmpty(mode) && "wifi".split(",").contains(mode)) {

      logger.error(">>>处理类型：" + mode)
      val date = args(0)
      logger.error(">>>处理日期：" + date)
      val sparkSession = Spark.getSparkSession(appName)
      stat(sparkSession, mode, wifi_table, date)

      logger.error(">>>处理完毕---------------")
    }
  }


  def stat(sparkSession: SparkSession, mode: String, table: String, date: String): Unit = {
    val month = date.substring(4, 6).toInt
    val (startDate, endDate) = DateUtil.getMonthDate(date.substring(0, 4), month.toString)
    logger.error(">>>开始处理 " + table + ", 日期：" + date + " , 月份：" + month + " , 范围：" + startDate + " - " + endDate)
    val groupedRdd = getData(sparkSession, startDate, endDate, date, table)

    groupedRdd.unpersist()
  }


  def getData(sparkSession: SparkSession, startDate: String, endDate: String,
              date: String, tableName: String) = {
    var sql = ""
    sql =
      s"""
         |select * from $tableName where inc_day='$date' and from_unixtime(bigint(timestamp),'yyyyMMdd') between '$startDate' and '$endDate'
       """.stripMargin
    val logRdd = getValidJson(sparkSession, sql)

    val groupedRdd1 = logRdd.map(json => {
      val id = getWifiId(json)
      (id, json)
    }).filter(obj => !StringUtils.isEmpty(obj._1))
      .groupByKey()
      .map(obj => {
        val id = obj._1
        val jsonList = obj._2.toList.sortBy(j => j.getString("timestamp")).reverse
        val firstJson = jsonList.head
        firstJson.put("new_id", id)
        firstJson
      })
    logger.error(">>>日志量：" + groupedRdd1.count())

    var table = tableName + "_grouped_newid"
    var structs = Array("timestamp", "rssi", "bssid", "channel", "connectstate", "band", "ssid", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "os", "v", "id", "m", "rtime", "new_id")
    filterRddToHive(sparkSession, groupedRdd1, table, structs, date)
    groupedRdd1.unpersist()

    val groupedRdd2 = logRdd.map(json => {
      val id = getWifiId(json)
      var x = json.getString("x")
      var y = json.getString("y")
      if (StringUtils.isEmpty(x)) x = ""
      if (StringUtils.isEmpty(y)) y = ""
      val xy = "[" + x + "," + y + "]"
      ((id, xy), 1)
    }).filter(obj => !StringUtils.isEmpty(obj._1._1))
      .reduceByKey((o1, o2) => {
        o1 + o2
      })
      .map(obj => {
        val new_id = obj._1._1
        val xy = obj._1._2
        val count = obj._2
        val newJson = new JSONObject()
        newJson.put("new_id", new_id)
        newJson.put("xy", xy)
        newJson.put("count", count)
        newJson
      })
    logger.error(">>>日志量：" + groupedRdd2.count())

    table = tableName + "_grouped_xy"
    structs = Array("new_id", "xy", "count")
    filterRddToHive(sparkSession, groupedRdd2, table, structs, date)
    groupedRdd2
  }


  val array1 = Array("2147483647", "268435455", "65535")

  def getWifiId(json: JSONObject): String = {
    var id = ""
    if (json != null) {
      val bssid = json.getString("bssid")
      if (StringUtils.isEmpty(bssid)) id = ""
      else if (array1.contains(bssid)) id = ""
      else id = bssid
    }
    id
  }


  def getValidJson(sparkSession: SparkSession, sql: String) = {
    logger.error("sql=" + sql)
    val df = sparkSession.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.get(i))
      }
      json
    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>日志量：" + logRdd.count())
    logRdd
  }


  def filterRddToHive(sparkSession: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], date: String): Unit = {
    logger.error(s"写入表：${table}")
    SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, structs, table,
      Array(("inc_day", date)), partition)
  }
}
