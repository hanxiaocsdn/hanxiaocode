package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.utils.AesEncryptUtil
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiAggData.logger
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiDailyData.saveAoiKey
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-12-12 15:11
 * @TaskId:938862
 * @TaskName:
 * @Description:aoi变更-清洗ap库工作流
 */

object CleanAPWifiData {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("row_key","date","adcode","lng","validity","src","changefreq","lat","acc","freq","available","incday")

    val savemidKey=Array("row_key","wifi","decrypt_wifi","date","adcode","lng","validity","changefreq","lat","acc","city_code","aoi_id","bld_aoi_id","aoi_name","aoi_key","aoi_dist","buildingid","buildingname","bld_key","province","city","county","town","incday")
    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val end_day=args(0)
        val start_day=args(1)
        val mode=args(2)
        mode match {
            case "delete"=>deleAoi(sparkSession,end_day,start_day)
            case "increate"=>increateAoi(sparkSession,end_day,start_day)
            case "modifyboundary"=>modifyBoundaryAoi(sparkSession,end_day,start_day)
            case "modifyname"=>modifyName(sparkSession,end_day,start_day)
        }



    }

    def deleAoi(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取待删除aoi信息")
        val deleteAoiInfoSetBroad: Broadcast[mutable.HashSet[String]] = getDeleAoiInfo(sparkSession, end_day, start_day)
        logger.error("筛选符合条件的wifi")
        val resultRdd = filterApAoi(sparkSession, deleteAoiInfoSetBroad)
        logger.error("存储符合条件的wifi")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_gis_export_wifi_change_dtl_di",Array(("modify_type", "delete")), 25)



    }

    def increateAoi(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取待删除aoi信息")
        val increateAoiInfoSetBroad: Broadcast[mutable.HashSet[String]] = getIncreateAoiInfo(sparkSession, end_day, start_day)
        logger.error("筛选符合条件的wifi")
        val resultRdd = filterApAoi(sparkSession, increateAoiInfoSetBroad)
        logger.error("存储符合条件的wifi")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_gis_export_wifi_change_dtl_di",Array(("modify_type", "increate")), 25)



    }

    def modifyBoundaryAoi(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取待删除aoi信息")
        val modifyBoundaryAoiInfoSetBroad: Broadcast[mutable.HashSet[String]] = getModifyBoundaryAoiInfo(sparkSession, end_day, start_day)
        logger.error("筛选符合条件的wifi")
        val resultRdd = filterApAoi(sparkSession, modifyBoundaryAoiInfoSetBroad)
        logger.error("存储符合条件的wifi")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_gis_export_wifi_change_dtl_di",Array(("modify_type", "modifyboundary")), 25)



    }

    def modifyName(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取待删除aoi信息")
        val modifyNameAoiInfoMapBroad = getModifyNameAoiInfo(sparkSession, end_day, start_day)
        logger.error("修改符合条件的aoi")
        val resultRdd = modifNameApWifi(sparkSession, modifyNameAoiInfoMapBroad)
        logger.error("存储符合条件的aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, savemidKey, "dm_gis.dm_wifi_finger_ap_mid_bld_dtl",null, 50)



    }


    def modifNameApWifi(sparkSession:SparkSession,aoiInfoMapBroad: Broadcast[Map[String, String]])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_ap_mid_bld_dtl
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val df = sparkSession.sql(sql)
        val columns = df.columns
        val dataRdd = df.rdd.map(obj => {
            val jObj = new JSONObject()
            for (i <- columns.indices) {
                jObj.put(columns(i), obj.getString(i))
            }
            jObj
        })
        val resultRdd = dataRdd.map(obj => {
            val aoiInfoMap = aoiInfoMapBroad.value
            val aoi_id = obj.getString("aoi_id")
            if (aoiInfoMap.contains(aoi_id)) {
                obj.put("aoi_name", aoiInfoMap.get(aoi_id).get)
            }
            obj

        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("数据量---》"+resultRdd.count())
        resultRdd

    }

    def filterApAoi(sparkSession:SparkSession,deleteAoiInfoSetBroad: Broadcast[mutable.HashSet[String]])={
        var sql=
            """
              |
              |
              |select * from dm_gis.gis_export_wifi
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val resultRdd = dataRdd.filter(x => {
            val deleteAoiInfoSet = deleteAoiInfoSetBroad.value
            var flag = false
            try {
                val lng = x.getString("lng")
                val lat = x.getString("lng")
                val key = GeometryUtil.sliceUpCoordinate(lng, lat)
                if (deleteAoiInfoSet.contains(key)) {
                    flag = true
                }

            }catch {case e:Exception=>logger.error(e.toString)}


            flag
        })
        resultRdd

    }



    def getDeleAoiInfo(sparkSession:SparkSession,end_day:String,start_day:String)={
        var sql=
            s"""
              |
              |select aoi_id, get_json_object(`data`,'$$.oldAoi.wkt') as wkt from (
              |select aoi_id, `data`,row_number()over(partition by aoi_id order by update_date desc ) rnk
              |from dm_gis.cms_aoi_change
              |where inc_day between '$start_day' and '$end_day'
              |and oper_type = 'D'
              |and status = '6'
              |
              |) t
              |where t.rnk=1
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)

        sparkSession.sparkContext.broadcast(splitWkt(dataRdd))

    }


    def getIncreateAoiInfo(sparkSession:SparkSession,end_day:String,start_day:String)={
        var sql=
            s"""
              |
              |select aoi_id, get_json_object(`data`,'$$.oldAoi.wkt') as wkt from (
              |select aoi_id, `data`,row_number()over(partition by aoi_id order by update_date desc ) rnk
              |from dm_gis.cms_aoi_change
              |where inc_day between '$start_day' and '$end_day'
              |and oper_type = 'I'
              |and status = '6'
              |
              |) t
              |where t.rnk=1
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)

        sparkSession.sparkContext.broadcast(splitWkt(dataRdd))

    }

    def getModifyBoundaryAoiInfo(sparkSession:SparkSession,end_day:String,start_day:String)={
        var sql=
            s"""
              |
              |select aoi_id, get_json_object(`data`,'$$.oldAoi.wkt') as wkt from (
              |select aoi_id, `data`,row_number()over(partition by aoi_id order by update_date desc ) rnk
              |from dm_gis.cms_aoi_change
              |where inc_day between '$start_day' and '$end_day'
              |and oper_type = 'U'
              |and status = '6'
              |and change_type='1'
              |
              |) t
              |where t.rnk=1
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)

        sparkSession.sparkContext.broadcast(splitWkt(dataRdd))

    }

    def getModifyNameAoiInfo(sparkSession:SparkSession,end_day:String,start_day:String)={

        var sql=
            s"""
              |
              |
              |select aoi_id,aoi_name from (
              |select aoi_id,get_json_object(`data`,'$$.newAoi.aoiName') as aoi_name,row_number()over(partition by aoi_id order by update_date desc ) as rnk
              |from dm_gis.cms_aoi_change
              |where inc_day between '$start_day' and '$end_day'
              |and oper_type = 'U'
              |and change_type = '3'
              |and status = '6'
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val aoiInfoMap = dataRdd.map(x => (x.getString("aoi_id"),x.getString("aoi_name"))).collect().toMap

        sparkSession.sparkContext.broadcast(aoiInfoMap)


    }
    def splitWkt(dataRdd:RDD[JSONObject])={
        val dataSet = new mutable.HashSet[String]()
        val wktSet = dataRdd.map(obj => {
            try {
                val wkt = AesEncryptUtil.desEncrypt(obj.getString("wkt")).trim
                obj.put("desWkt", wkt)
            } catch {
                case e: Exception => logger.error(e.toString)
            }
            obj
        }).filter(x => StringUtils.nonEmpty(x.getString("desWkt"))).map(x => x.getString("desWkt")).collect().toSet
        for(desWkt<-wktSet){
            try{
                val keySet: util.Set[String] = GeometryUtil.sliceUpByWkt(desWkt)
                import collection.JavaConverters._
                for(key<-keySet.asScala){
                    dataSet.add(key)
                }
            }catch {case e:Exception=>logger.error(e.toString)}
        }
        dataSet

    }

    def checkPointLocationWkt(pointKey:String,wktSet:mutable.HashSet[String])={
        var flag=false
        if(wktSet.contains(pointKey)){
            flag=true
        }else{
            breakable{
                val lngkey1 = pointKey.split("-")(0)
                val latkey1 = pointKey.split("-")(1)
                for(key<-wktSet){
                    val lngkey2 = key.split("-")(0)
                    val latkey2 = key.split("-")(1)
                    if(math.abs(lngkey1.toLong-lngkey2.toLong)<=2&&math.abs(latkey1.toLong-latkey2.toLong)<=2){
                        flag=true
                        break

                    }

                }

            }
        }
        flag
    }



}
