package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * @ProductManager:01425237
 * @Author: 01407499
 * @CreateTime: 2023-11-17 11:48
 * @TaskId:906840
 * @TaskName:
 * @Description:chk 派/收/query测试灰度
 */

object OmsWaybillGrayEnvTestOneDay {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val omsWaybillUrl="http://gis-int.int.sfdc.com.cn:1080/chkdispatch/tc/omsWaybill"
    val chkQueryUrl="http://gis-int.int.sfdc.com.cn:1080/chkquery/tc/teamCode"
    val chkShouUrl="http://gis-int.int.sfdc.com.cn:1080/chkconsignee/tc/team"

    val saveKey=Array("req_destcitycode","addresseePhone","addresseeMobile","req_addresseeaddr","chk_pai_aoi_id","chk_pai_dept_code","chk_pai_aoi_id_gray","chk_pai_dept_code_gray","chk_query_aoi_id","chk_query_dept_code","chk_query_aoi_id_gray","chk_query_dept_code_gray","chk_shou_aoi_id","chk_shou_dept_code","chk_shou_aoi_id_gray","chk_shou_dept_code_gray","chk_pai_flag","chk_query_flag","chk_shou_flag","chk_pai_response","chk_pai_response_gray","chk_query_response","chk_query_response_gray","chk_shou_response","chk_shou_response_gray","costtime")
    def main(args: Array[String]): Unit = {

        val end_day=args(0)
        val mode=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = getData(sparkSession,mode)
        logger.error("存储数据")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "tmp_dm_gis.test_oms_waybill_interface_data",Array(("inc_day", end_day)), 25)



    }

    def getData(spark:SparkSession,mode:String)={
        var sql=
            """
              |
              |
              |select
              |req_destcitycode
              |,addresseePhone
              |,addresseeMobile
              |,req_addresseeaddr
              | from
              |(
              |select
              |req_destcitycode
              |,get_json_object(req_body,'$.addresseePhone') addresseePhone
              |,get_json_object(req_body,'$.addresseeMobile') addresseeMobile
              |,get_json_object(req_body,'$.addresseeAddr') req_addresseeaddr
              |from
              |dm_gis.gis_rds_omsto where inc_day='20231119' and req_destcitycode='010'
              |)  a
              |group by
              |req_destcitycode
              |,addresseePhone
              |,addresseeMobile
              |,req_addresseeaddr
              |limit 300000
              |
              |""".stripMargin

        sql=
            """
              |
              |
              |select * from tmp_dm_gis.test_data_all
              |
              |""".stripMargin

//        sql=
//            """
//              |
//              |select * from tmp_dm_gis.test_oms_waybill_interface_data where inc_day='20231121' and (chk_pai_aoi_id='' or chk_pai_dept_code='')
//              |
//              |""".stripMargin
        logger.error(sql)
        val (originRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = originRdd.map(obj => {
            val req_destcitycode = obj.getString("req_destcitycode")
            val addresseePhone = obj.getString("addresseePhone")
            val addresseeMobile = obj.getString("addresseeMobile")
            val req_addresseeaddr = obj.getString("req_addresseeaddr")
            var chk_pai_flag=""
            var chk_query_flag=""
            var chk_shou_flag=""

            val startTime = System.currentTimeMillis()

            val (chk_pai_aoi_id, chk_pai_dept_code, chk_pai_response) = getChkPai(req_destcitycode, addresseePhone, addresseeMobile, req_addresseeaddr, "cd0df3b0c3c3372d7a0ad44e0c9678c5",mode)
            val (chk_pai_aoi_id_gray, chk_pai_dept_code_gray, chk_pai_response_gray) = getChkPai(req_destcitycode, addresseePhone, addresseeMobile, req_addresseeaddr, "0376a9aa84724dd2a995f858dd963346",mode)

            val (chk_query_aoi_id, chk_query_dept_code, chk_query_response) = getChkQuery(req_destcitycode, addresseePhone, addresseeMobile, req_addresseeaddr, "cd0df3b0c3c3372d7a0ad44e0c9678c5",mode)
            val (chk_query_aoi_id_gray, chk_query_dept_code_gray, chk_query_response_gray) = getChkQuery(req_destcitycode, addresseePhone, addresseeMobile, req_addresseeaddr, "0376a9aa84724dd2a995f858dd963346",mode)

            val (chk_shou_aoi_id, chk_shou_dept_code, chk_shou_response) = getChkShou(req_destcitycode, addresseePhone, addresseeMobile, req_addresseeaddr, "cd0df3b0c3c3372d7a0ad44e0c9678c5",mode)
            val (chk_shou_aoi_id_gray, chk_shou_dept_code_gray, chk_shou_response_gray) = getChkShou(req_destcitycode, addresseePhone, addresseeMobile, req_addresseeaddr, "0376a9aa84724dd2a995f858dd963346",mode)

            if(StringUtils.nonEmpty(chk_pai_dept_code)&StringUtils.nonEmpty(chk_pai_aoi_id)&&StringUtils.nonEmpty(chk_pai_dept_code_gray)&StringUtils.nonEmpty(chk_pai_aoi_id_gray)){
                if(!chk_pai_dept_code.equals(chk_pai_dept_code_gray)){
                    chk_pai_flag="dept"

                }
                if(!chk_pai_aoi_id.equals(chk_pai_aoi_id_gray)){
                    chk_pai_flag=chk_pai_flag+"|"+"aoi"
                }
            }

            if(StringUtils.nonEmpty(chk_query_dept_code)&StringUtils.nonEmpty(chk_query_aoi_id)&&StringUtils.nonEmpty(chk_query_dept_code_gray)&StringUtils.nonEmpty(chk_query_aoi_id_gray)){
                if(!chk_query_dept_code.equals(chk_query_dept_code_gray)){
                    chk_query_flag="dept"

                }
                if(!chk_query_aoi_id.equals(chk_query_aoi_id_gray)){
                    chk_query_flag=chk_query_flag+"|"+"aoi"
                }
            }


            if(StringUtils.nonEmpty(chk_shou_dept_code)&StringUtils.nonEmpty(chk_shou_aoi_id)&&StringUtils.nonEmpty(chk_shou_dept_code_gray)&StringUtils.nonEmpty(chk_shou_aoi_id_gray)){
                if(!chk_shou_dept_code.equals(chk_shou_dept_code_gray)){
                    chk_shou_flag="dept"

                }
                if(!chk_shou_aoi_id.equals(chk_shou_aoi_id_gray)){
                    chk_shou_flag=chk_shou_flag+"|"+"aoi"
                }
            }


            obj.put("chk_pai_aoi_id", chk_pai_aoi_id)
            obj.put("chk_pai_dept_code", chk_pai_dept_code)
            obj.put("chk_pai_response", chk_pai_response)

            obj.put("chk_pai_aoi_id_gray", chk_pai_aoi_id_gray)
            obj.put("chk_pai_dept_code_gray", chk_pai_dept_code_gray)
            obj.put("chk_pai_response_gray", chk_pai_response_gray)

            obj.put("chk_query_aoi_id", chk_query_aoi_id)
            obj.put("chk_query_dept_code", chk_query_dept_code)
            obj.put("chk_query_response", chk_query_response)

            obj.put("chk_query_aoi_id_gray", chk_query_aoi_id_gray)
            obj.put("chk_query_dept_code_gray", chk_query_dept_code_gray)
            obj.put("chk_query_response_gray", chk_query_response_gray)


            obj.put("chk_shou_aoi_id", chk_shou_aoi_id)
            obj.put("chk_shou_dept_code", chk_shou_dept_code)
            obj.put("chk_shou_response", chk_shou_response)

            obj.put("chk_shou_aoi_id_gray", chk_shou_aoi_id_gray)
            obj.put("chk_shou_dept_code_gray", chk_shou_dept_code_gray)
            obj.put("chk_shou_response_gray", chk_shou_response_gray)

            obj.put("chk_pai_flag",chk_pai_flag)
            obj.put("chk_query_flag",chk_query_flag)
            obj.put("chk_shou_flag",chk_shou_flag)
            val endTime = System.currentTimeMillis()
            obj.put("costtime", (endTime - startTime).toString)
            obj

        })
        resultRdd




    }

    def getChkPai(citycode:String,phone:String,mobile:String,addr:String,ak:String,mode:String): (String, String, String) ={
        val parmStr=
            """
              |
              |{
              |    "waybillNo": "185284257347",
              |    "orderNo": "201811211449",
              |    "sourceCityCode": "755",
              |    "destCityCode": "373",
              |    "consignorAddr": "这是收件地址",
              |    "addresseeAddr": "这是总地址，当无结构化地址时用这个",
              |    "addresseeContacts": "姓名",
              |    "addresseePhone": "DEEQAVToBn0fyGKhFx%2FMoczTtbTbA%3D",
              |    "addresseeMobile": "DEEQAVToBn0fyGKhFx%2FMoczTtbTbA%3D",
              |    "inputEmpCode": "SHIVA-OMS",
              |    "addresseeCompName": "公司",
              |    "receiverProvince": "",
              |    "receiverCity": "",
              |    "receiverArea": "",
              |    "receiverAddr": "河南省新乡市卫滨区南干道佐今明大药房门诊部",
              |    "customerAcctCode":"755CARD00305",
              |    "productCode":"SE0110",
              |    "limitTypeCode":"T4",
              |    "cargoTypeCode":"C930",
              |    "expressTypeCode":"B1",
              |    "chargeWeight":"50",
              |    "consignContent":"3",
              |    "combinationFlag":"4",
              |    "electronicsTag":"5",
              |    "vas":"增值服务",
              |    "ak": "你的ak"
              |  }
              |""".stripMargin

        val parmObj = JSON.parseObject(parmStr)
        parmObj.put("destCityCode",citycode)
        parmObj.put("addresseePhone",phone)
        parmObj.put("addresseeMobile",mobile)
        parmObj.put("receiverAddr",addr)
        parmObj.put("ak",ak)
        val tmpObj = new JSONObject()
        tmpObj.put("ak",ak)
        tmpObj.put("params",parmObj)
        tmpObj.put("showserver",true)
        var chk_pai_dept_code=""
        var chk_pai_aoi_id=""
        var jSONObject=new JSONObject()
        var response=""
        if((StringUtils.nonEmpty(mode)&&mode.equals("all"))){
            return (chk_pai_aoi_id,chk_pai_dept_code,response)
        }
        Thread.sleep(300)
        jSONObject = try {
            //            Thread.sleep(50)
            HttpUtils.urlConnectionPostJson(omsWaybillUrl,tmpObj.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+parmObj.toString())
                val stackTraceElement = e.getStackTrace()(0)
                response=e.toString
                logger.error("系统出错，错误信息:"+e.toString()+" at "+stackTraceElement.getClassName()+"."+stackTraceElement.getMethodName()+":"+stackTraceElement.getLineNumber())
                null
            }
        }

        if(jSONObject!=null){
            response=jSONObject.toString()
            chk_pai_dept_code=JSONUtil.getJsonVal(jSONObject,"result.response.GIS_ASS_CORE_DEPT_TO_OMS.message.addresseeDeptCode","")
            chk_pai_aoi_id=JSONUtil.getJsonVal(jSONObject,"result.response.GIS_ASS_CORE_DEPT_TO_OMS.message.addresseeAoiId","")

        }

        (chk_pai_aoi_id,chk_pai_dept_code,response)


    }


    def getChkQuery(citycode:String,phone:String,mobile:String,addr:String,ak:String,mode:String): (String, String, String) ={
        val parmStr=
            """
              |
              |{
              |"address":"上海市上海市嘉定区南翔镇宝翔路宏立瑞园五号楼903",
              |"cityCode":"021",
              |"addressType":"2",
              |"mobile":"",
              |"phone":"",
              |"sysCode":"SHIVA-OMS",
              |"ak":"0376a9aa84724dd2a995f858dd963346",
              |"type":"1"
              |}
              |
              |""".stripMargin


        val parmObj = JSON.parseObject(parmStr)
        parmObj.put("cityCode",citycode)
        parmObj.put("phone",phone)
        parmObj.put("mobile",mobile)
        parmObj.put("address",addr)
        parmObj.put("ak",ak)
        var chk_query_dept_code=""
        var chk_query_aoi_id=""
        var jSONObject=new JSONObject()
        var response=""
        if(!(StringUtils.nonEmpty(mode)&&mode.equals("all"))){
            return (chk_query_aoi_id,chk_query_dept_code,response)
        }

        Thread.sleep(150)
        jSONObject = try {
            //            Thread.sleep(50)
            HttpUtils.urlConnectionPostJson(chkQueryUrl,parmObj.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+parmObj.toString())
                val stackTraceElement = e.getStackTrace()(0)
                response=e.toString
                logger.error("系统出错，错误信息:"+e.toString()+" at "+stackTraceElement.getClassName()+"."+stackTraceElement.getMethodName()+":"+stackTraceElement.getLineNumber())
                null
            }
        }

        if(jSONObject!=null){
            response=jSONObject.toString()
            chk_query_dept_code=JSONUtil.getJsonVal(jSONObject,"deptCode","")
            chk_query_aoi_id=JSONUtil.getJsonVal(jSONObject,"aoiId","")

        }

        (chk_query_aoi_id,chk_query_dept_code,response)


    }


    def getChkShou(citycode:String,phone:String,mobile:String,addr:String,ak:String,mode:String): (String, String, String) ={
        val parmStr=
            """
              |
              |{"sysCode":"SHIVA-OMS","orderInfo":"{\"orderFromToList\":[{\"orderFrom\":{\"customerId\":\"AAABddrGuoMxwXy6+C5Nm7Mb83RSJcpj\",\"province\":\"\",\"cityCode\":\"020\",\"city\":\"\",\"county\":\"\",\"customerAccount\":\"0225981140\",\"company\":\"\",\"address\":\"广东省广州市白云区白云湖街道\",\"phone\":\"DEEQAVTj4G%2FrNQioVz7tc3gR%2FNC9w%3D\",\"contactsName\":\"\",\"customerAccount\":\"7550633090\"}}],\"orderNo\":\"wacld202112151702\",\"sysOrderNo\":\"00000666666666618152420679\",\"orderType\":\"2\",\"bookingType\":\"1\",\"isNotUnderCall\":\"0\",\"expressTypeCode\":\"B1\",\"limitTypeCode\":\"T4\",\"cargoTypeCode\":\"SP60302\",\"weight\":\"3.0\",\"serviceCodeList\":[\"IN113\"],\"payType\":\"3\",\"sysSource\":\"BSP\",\"clientCode\":\"fcznkdg\"}","ak":"3eb300d2e06947f7945cd02530a32fd2"}
              |
              |""".stripMargin

        val parmObj = JSON.parseObject(parmStr)

        val orderInfo = parmObj.getJSONObject("orderInfo")
        val nObject1 = orderInfo.getJSONArray("orderFromToList").getJSONObject(0)
        val orderFrom = nObject1.getJSONObject("orderFrom")
        val array = new JSONArray()
        orderFrom.put("address",addr)
        orderFrom.put("cityCode",citycode)
        orderFrom.put("phone",phone)
        val tmpObj = new JSONObject()
        tmpObj.put("orderFrom",orderFrom)
        array.add(tmpObj)
        orderInfo.put("orderFromToList",array)
        orderInfo.put("isNotUnderCall","1")
        parmObj.put("orderInfo",orderInfo.toString())
        parmObj.put("ak",ak)
        var chk_query_dept_code=""
        var chk_query_aoi_id=""
        var jSONObject=new JSONObject()
        var response=""

        if(!(StringUtils.nonEmpty(mode)&&mode.equals("all"))){
            return (chk_query_aoi_id,chk_query_dept_code,response)
        }
        jSONObject = try {

            HttpUtils.urlConnectionPostJson(chkShouUrl,parmObj.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+parmObj.toString())
                val stackTraceElement = e.getStackTrace()(0)
                response=e.toString
                logger.error("系统出错，错误信息:"+e.toString()+" at "+stackTraceElement.getClassName()+"."+stackTraceElement.getMethodName()+":"+stackTraceElement.getLineNumber())
                null
            }
        }

        //result.orderFromTo.teamFrom.deptCode
        //result.orderFromTo.teamFrom.aoiId
        if(jSONObject!=null){
            response=jSONObject.toString()
            chk_query_dept_code=JSONUtil.getJsonVal(jSONObject,"result.orderFromTo.teamFrom.deptCode","")
            chk_query_aoi_id=JSONUtil.getJsonVal(jSONObject,"result.orderFromTo.teamFrom.aoiId","")

        }

        (chk_query_aoi_id,chk_query_dept_code,response)


    }

}
