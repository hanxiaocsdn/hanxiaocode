package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.wifiapp.InitApWifiDataSecond.getMd5Key
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiData.{calcCenterPoint, cleanPoints, splitFingerList}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-07-28 10:52
 * @TaskId:786233
 * @TaskName:aoi变更之aoi更新
 * @Description:
 */

object WifiAOIInfoUpdate {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )


    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","city_code","address","province","city","county","town","village","aoi_name","lng","lat","points","reliable","inc_day","reserve1","reserve2")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","city_code","address","province","city","county","town","village","aoi_name","buildingname","lng","lat","points","inc_day","reliable","reserve1","reserve2")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","city_code","floor","lng","lat")
    val saveDetailKey=Array("key","wifi_list","upper_key","city_code","address","level","province","city","county","town","village","aoi_name","buildingname","floor","room","lng","lat","points","inc_day","reliable","reserve1","reserve2")


    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取aoi合并维表数据")
        val mergeAoiInfoMapBro = getAoiMergeInfo(sparkSession)
        logger.error("合并wifi指纹aoi数据")
        val  (cleanAoiRdd,changeAoiMapBro)=aoiMerge(sparkSession,mergeAoiInfoMapBro)
        logger.error("更新wifi指纹楼栋数据")
        val cleanBldRdd = getAoimergeBuild(sparkSession, changeAoiMapBro)
        logger.error("存储wifi指纹aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, cleanAoiRdd, saveAoiKey, "dm_gis.dm_wifi_finger_aoi_dtl",null, 25)
        logger.error("存储wifi指纹楼栋数据")
        SparkWrite.save2HiveStaticNew(sparkSession, cleanBldRdd, saveBuildKey, "dm_gis.wifi_finger_building_v1",null, 25)

    }

    def aoiMerge(spark:SparkSession,mergeAoiInfoMapBro:Broadcast[Map[String, String]])={

        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_aoi_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        var flag=true
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val mergeAoiRdd = dataRdd.map(obj => {
            val mergeAoiInfoMap = mergeAoiInfoMapBro.value
            val aoi_id = obj.getString("aoi_id")
            if (mergeAoiInfoMap.contains(aoi_id)) {

                val new_aoi_id = mergeAoiInfoMap.get(aoi_id).get
                val md5NewAoiId = getMd5Key(new_aoi_id)
                val md5OldAoiId = getMd5Key(aoi_id)
                logger.error("开始替换 old aoiid----》"+aoi_id+" 新aoiid---》"+new_aoi_id)
                var key = math.abs(md5NewAoiId.hashCode) % 10 + "_" + md5NewAoiId
                obj.put("key", key)
                obj.put("aoi_id", new_aoi_id)
                obj.put("new_aoi_key", md5NewAoiId)
                obj.put("old_aoi_key", md5OldAoiId)
                obj.put("aoi_key", md5NewAoiId)
                obj.put("change", "1")
                logger.error("替换完成----》 "+obj.toString())
                if(flag){
                    Thread.sleep(300000)
                    flag=false
                }

            }
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("合并完数据量----》"+mergeAoiRdd.count())

        val changeAoiMap = mergeAoiRdd.filter(obj => StringUtils.nonEmpty(obj.getString("new_aoi_key"))).map(obj => (obj.getString("old_aoi_key"), obj.getString("new_aoi_key"))).collect().toMap
        val cleanAoiRdd = mergeAoiRdd.map(obj => (obj.getString("key"), obj)).groupByKey().flatMap(x => {
            val saveAoiKey = Array("key", "wifi_list", "finger_list", "aoi_id", "aoi_key", "address", "province", "city", "county", "town", "roodline", "aoi", "lon", "lat", "points", "reliable", "reserve1", "reserve2", "update_tag")
            val dataObj = new JSONObject()
            val list = new ListBuffer[JSONObject]


            val key = x._1

            val wifiMap = new mutable.HashMap[String, JSONObject]()
            val fingerSet = new mutable.HashSet[String]()
            var aoi_id = ""
            var aoi_key = ""
            var address = ""
            var province = ""
            var city = ""
            var city_code = ""
            var county = ""
            var town = ""
            var village = ""
            var roodline = ""
            var aoi = ""
            var inc_day=""

            var province_s = ""
            var city_s = ""
            var county_s = ""
            var town_s = ""
            var roodline_s = ""
            var village_s = ""
            var aoi_s = ""

            var lon = ""
            var lat = ""
            var points = ""
            var reliable = ""
            var reserve1 = ""
            var update_tag = ""
            var flag = false
            var pointAllArr = new JSONArray()

            for (obj <- x._2) {
                val wifi_list = obj.getString("wifi_list")
                val finger_list = obj.getString("finger_list")
                val pointstr = obj.getString("points")
                var wifiArr = new JSONArray()
                var pointArr = new JSONArray()
                try {
                    wifiArr = JSON.parseArray(wifi_list)
                    pointArr = JSON.parseArray(pointstr)
                } catch {
                    case e: Exception => {
                        logger.error(e.getMessage)
                    }
                }

                val change = obj.getString("change")
                if (!StringUtils.nonEmpty(change)) {
                    flag = true
                    province = obj.getString("province")
                    city = obj.getString("city")
                    county = obj.getString("county")
                    town = obj.getString("town")
                    roodline = obj.getString("roodline")
                    aoi = obj.getString("aoi_name")
                    village=obj.getString("village")

                } else {
                    province_s = obj.getString("province")
                    city_s = obj.getString("city")
                    county_s = obj.getString("county")
                    town_s = obj.getString("town")
                    roodline_s = obj.getString("roodline")
                    aoi_s = obj.getString("aoi")
                    village_s=obj.getString("village")

                }
                aoi_id=obj.getString("aoi_id")
                aoi_key=obj.getString("aoi_key")
                city_code=obj.getString("city_code")
                reserve1 = obj.getString("reserve1")
                update_tag = obj.getString("update_tag")
                reliable = obj.getString("reliable")
                inc_day=obj.getString("inc_day")
                splitFingerList(finger_list, fingerSet)
                for (i <- 0 until wifiArr.size()) {
                    val wifiObj = wifiArr.getJSONObject(i)
                    val mac = wifiObj.getString("mac")
                    if (wifiMap.contains(mac)) {
                        val num = wifiObj.getString("num")
                        val time = wifiObj.getString("time")
                        val source = wifiObj.getString("source")
                        val temObj = wifiMap.get(mac).get
                        var num_t = temObj.getString("num")
                        var time_t = temObj.getString("time")
                        var source_t = temObj.getString("source")
                        if (StringUtils.nonEmpty(num) && StringUtils.nonEmpty(time) && StringUtils.nonEmpty(source) && StringUtils.nonEmpty(num_t) && StringUtils.nonEmpty(time_t) && StringUtils.nonEmpty(source_t)) {
                            num_t = (num_t.toLong + num.toLong).toString
                            if (time.toLong > time_t.toLong) {
                                time_t = time
                            }
                            if (source.toLong > source_t.toLong) {
                                source_t = source
                            }
                            temObj.put("num", num_t)
                            temObj.put("time", time_t)
                            temObj.put("source", source_t)
                        }
                        wifiMap.put(mac, temObj)
                    } else {
                        wifiMap.put(mac, wifiObj)
                    }
                }
                for (i <- 0 until pointArr.size()) {
                    pointAllArr.add(pointArr.getJSONObject(i))
                }
            }
            val pointsAll = cleanPoints(pointAllArr.toString())
            val (lng, y) = calcCenterPoint(pointsAll)
            if (!flag) {
                province = province_s
                city = city_s
                county = county_s
                town = town_s
                roodline = roodline_s
                aoi = aoi_s
                village=village_s
            }
            address = province + city + county + town+village + roodline + aoi
            val wifiArr = new JSONArray()
            for (wifi <- wifiMap.values) {
                wifiArr.add(wifi)
            }
            dataObj.put("key", key)
            dataObj.put("wifi_list", wifiArr.toString())
            dataObj.put("finger_list", fingerSet.mkString(""))
            dataObj.put("aoi_id", aoi_id)
            dataObj.put("aoi_key", aoi_key)
            dataObj.put("address", address)
            dataObj.put("province", province)
            dataObj.put("city", city)
            dataObj.put("city_code", city_code)
            dataObj.put("county", county)
            dataObj.put("town", town)
            dataObj.put("village", village)
            dataObj.put("roodline", roodline)
            dataObj.put("aoi_name", aoi)
            dataObj.put("lng", lng)
            dataObj.put("lat", y)
            dataObj.put("inc_day", inc_day)
            dataObj.put("points", pointsAll)
            dataObj.put("reliable", reliable)
            dataObj.put("reserve1", reserve1)
            dataObj.put("update_tag", update_tag)
            list += dataObj
            list

        })
        ((cleanAoiRdd,spark.sparkContext.broadcast(changeAoiMap)))



    }

    def getAoimergeBuild(spark:SparkSession,changeAoiMapBro:Broadcast[Map[String, String]])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_bld_dtl
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val buildRdd = dataRdd.map(obj => {
            val changeAoiMap = changeAoiMapBro.value
            val aoiSet = new mutable.HashSet[String]()
            val aoiNewSet = new mutable.HashSet[String]()
            val upper_key = obj.getString("upper_key")
            splitFingerList(upper_key, aoiSet)
            for (aoi_key <- aoiSet) {
                if (changeAoiMap.contains(aoi_key)) {
                    aoiNewSet.add(changeAoiMap.get(aoi_key).get)

                } else {
                    aoiNewSet.add(aoi_key)
                }

            }

            obj.put("upper_key", aoiNewSet.mkString(""))
            obj

        })

        buildRdd

    }

    def getAoiMergeInfo(spark:SparkSession): Broadcast[Map[String, String]] ={
        var sql=
            """
              |
              |select * from dm_gis.dm_aoi_merge_info
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val mergeAoiInfoMap = dataRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            for (obj <- x) {
                val merged_aoi = obj.getString("merged_aoi").split("\\|")
                val new_aoi = obj.getString("new_aoi")
                for (merge_aoi <- merged_aoi) {
                    val dataObj = new JSONObject()
                    dataObj.put("merge_aoi", merge_aoi)
                    dataObj.put("new_aoi", new_aoi)
                    listBuffer += dataObj

                }


            }


            listBuffer.iterator

        }).map(obj => (obj.getString("merge_aoi"), obj.getString("new_aoi"))).collect().toMap

        spark.sparkContext.broadcast(mergeAoiInfoMap)
    }

}
