package com.sf.gis.scala.nloc.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DesUtils, GeometryUtil}
import com.sf.gis.java.nloc.utils.BuildingGeo
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.nio.charset.StandardCharsets
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01412980
 * @Author: 01407499
 * @CreateTime: 2023-11-15 13:50
 * @TaskId:905224
 * @TaskName:
 * @Description:WIFI指纹库在小哥上岗离岗场景下的应用
 */

object OnandOffDutyWifiEvaluate {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val indoorUrl="http://gis-int.int.sfdc.com.cn:1080/nloc/indoor?ak=7b7ed052abe94c4fb6a4d940201956ce&param=%s"
    val indoorPostUrl="http://gis-apis.int.sfcloud.local:1080/nloc/indoor"
    val saveKey=Array("id","timestamp","time","ewl","tm","un","zx","zy","ac","bn","lon","lat","longitude","latitude","dept_addr","wifi_aoi","wifi_aoi_rate","wifi_building","wifi_building_rate","wifi_floor","wifi_floor_rate","wifi_room","zone_dis","judge")

    val aoi_arr=Array("宁海世纪城一期","升悦居","美平豪庭二期")
    val bld_arr=Array("连兴二路2号商铺","龙福路98号商铺","平豪庭清新巷118号商铺")
    val room_arr=Array("顺丰营业网点","101室","103室","104室")
    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = getData(sparkSession, end_day)
        logger.error("开始存储wifi评价结果")
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "dm_gis.dm_wifi_evaluate_on_off_duty_result_dtl_di",Array(("inc_day", end_day)), 25)


    }

    def getData(spark: SparkSession,end_day:String)={
        var sql=
            s"""
               |
               |select
               |a.id
               |,a.`timestamp`
               |,a.`time`
               |,a.ewl
               |,a.tm
               |,a.un
               |,a.zx
               |,a.zy
               |,a.ac
               |,a.bn
               |,a.lon
               |,a.lat
               |,b.longitude
               |,b.latitude
               |,b.dept_addr
               |from
               |(select * from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day' and bn in('756B','750AH','756EC')) a
               |left join
               |(select dept_code,longitude,latitude,dept_addr from dim.dim_dept_info_df where inc_day='$end_day' and longitude<>'' and dept_code<>''  ) b
               |on a.bn=b.dept_code
               |
               |
               |""".stripMargin

        logger.error("爬楼识别aoi"+sql)
        val (originRdd, columns) = SparkRead.readHiveAsJson(spark, sql)
        val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01407499", "765688", "WIFI指纹库在小哥上岗离岗场景下的应用", "", indoorPostUrl, "7b7ed052abe94c4fb6a4d940201956ce", originRdd.count(), 40)

        val wifiEvaluateRdd = originRdd.mapPartitionsWithIndex((index, iter) => {
            val desUtil = new DesUtils
            val listbuffer = new ListBuffer[JSONObject]
            var loggercnt=0L
            for (obj <- iter)  {
                try {
                    val ewl = obj.getString("ewl")
                    val paramObj = new JSONObject()
                    val wifilist = new JSONArray()
                    val celltowers = new JSONArray()
                    paramObj.put("appCerSha1", "D2:81:52:F9:30:B6:70:D6:67:AA:AC:14:D7:14:1B:10:31:7C:56:81")
                    paramObj.put("appPackageName", "com.sfmap.api.location.demo")
                    paramObj.put("celltowers", celltowers)
                    paramObj.put("gcj02", 1)
                    paramObj.put("netType", 0)
                    paramObj.put("opt", 1)
                    var ewl_num=0L
                    if (ewl != null) {
                        val tmp = new JSONObject()
                        tmp.fluentPutAll(obj)
                        breakable{
                            if (ewl != null) {
                                val ewlArray = BuildingGeo.sortJsonArray(JSON.parseArray(ewl))
                                for (i <- 0 until ewlArray.size()) {
                                    val tmpObj = new JSONObject()
                                    ewl_num+=1L
                                    val ewlObj = ewlArray.getJSONObject(i)
                                    tmpObj.put("macaddress", JSONUtil.getJsonVal(ewlObj, "mac", ""))
                                    tmpObj.put("singalstrength", JSONUtil.getJsonVal(ewlObj, "ss", ""))
                                    tmpObj.put("time", 0)
                                    wifilist.add(tmpObj)
                                    if(ewl_num>=50)
                                        break
                                }
                            }
                        }
                        paramObj.put("wifilist", wifilist)
                        ewl_num=0L
                        val param = desUtil.encrypt(paramObj.toString, StandardCharsets.UTF_8.toString())
                        val resultDataObj = postIndoorInfaceData(param, desUtil)
                        val end_time=System.currentTimeMillis()
                        loggercnt+=1L
                        tmp.fluentPutAll(resultDataObj)
                        listbuffer+=tmp
                    }
                } catch {
                    case e: Exception => {
                        logger.error(e.toString)
                    }
                }
            }
            listbuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取wifi评价结果数据量："+wifiEvaluateRdd.count())
//        Thread.sleep(1000000)
        BdpTaskRecordUtil.endNetworkInterface("01407499", httpInvokeId)
        val resultRdd = wifiEvaluateRdd.map(obj => {
            val zx = obj.getString("zx")
            val zy = obj.getString("zy")
            val longitude = obj.getString("longitude")
            val latitude = obj.getString("latitude")
            val wifi_aoi = obj.getString("wifi_aoi")
            val wifi_building = obj.getString("wifi_building")
            val wifi_room = obj.getString("wifi_room")
            var judge = "0"

            if (StringUtils.nonEmpty(zx) && StringUtils.nonEmpty(zy) && StringUtils.nonEmpty(longitude) && StringUtils.nonEmpty(latitude)) {
                val zone_dis = GeometryUtil.getDistance(zx, zy, longitude, latitude)
                obj.put("zone_dis", zone_dis)
                if (zone_dis <= 500.0) {
                    if (aoi_arr.contains(wifi_aoi) && bld_arr.contains(wifi_building) && room_arr.contains(wifi_room)) {
                        judge = "1"
                    }
                }
            }
            obj.put("judge", judge)

            obj

        })
        resultRdd


    }
    def postIndoorInfaceData(param:String,desUtils:DesUtils)={


        var data=new JSONObject()
        val parameter = new JSONObject()
        parameter.put("ak","7b7ed052abe94c4fb6a4d940201956ce")
        parameter.put("param",param)
        parameter.put("r","0")
        Thread.sleep(10)
        val jSONObject = try {
            HttpUtils.urlConnectionPostJson(indoorPostUrl,parameter.toString(),5000)
        }
        catch {
            case e:Exception=>{
                logger.error("error parameter-----> "+param)
                logger.error("error reason------>"+e.getMessage)
                null
            }
        }


         try{
            val resultStr=desUtils.decrypt(JSONUtil.getJsonVal(jSONObject, "result.msg", ""), StandardCharsets.UTF_8.toString())
             data.put("wifi_floor_rate",resultStr)
             val addressListArray = JSONUtil.getJsonArrayFromObject(JSONUtil.parseJSONObject(resultStr), "location.addresslist")
             var address_first =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"address","")
             var aoi_id =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"aoiId","")
             var bld_id =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"buildingId","")
             var reliable =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"reliable","")
             var aoi =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"aoi","")
             var building =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"building","")
             var floor =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floor","")
             var room =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"room","")
             var aoi_rate =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"aoiRate","")
             var aoi_fre =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"aoiFre","")
             var aoi_rate_differ =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"aoiRateDiffer","")
             var bld_rate =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"buildingRate","")
             var bld_fre =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"buildingFre","")
             var bld_sig =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"buildingSig","")
             var bld_rate_differ =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"buildingRateDiffer","")
             var bld_sig_differ =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"buildingSigDiffer","")
             var floor_rate =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floorRate","")
             var floor_coor =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floorCoor","")
             var floor_fre =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floorFre","")
             var floor_sig =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floorSig","")
             var floor_rate_differ =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floorRateDiffer","")
             var floor_coor_differ =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floorCoorDiffer","")
             var floor_sig_differ =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"floorSigDiffer","")
             var address_list =addressListArray.toString
             var longitude =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"lon","")
             var latitude =JSONUtil.getJsonVal(addressListArray.getJSONObject(0),"lat","")


             data.put("wifi_aoi",aoi)
             data.put("wifi_building",building)
             data.put("wifi_floor",floor)
             data.put("wifi_room",room)
             data.put("wifi_aoi_rate",aoi_rate)
             data.put("wifi_building_rate",bld_rate)
//             data.put("wifi_floor_rate",floor_rate)
        }catch {case e:Exception=>{
            ""

        }}
        //        logger.error("data is --->"+resultStr)



        data

    }

}
