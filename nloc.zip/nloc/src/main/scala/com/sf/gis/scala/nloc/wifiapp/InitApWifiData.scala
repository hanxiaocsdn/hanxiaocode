package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.gis.scala.nloc.wifiapp.InitApWifiDataSecond.getMd5Key
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01407317
 * @Author: 01407499
 * @CreateTime: 2023-11-02 15:40
 * @TaskId:878333
 * @TaskName:
 * @Description:AP库wifi数据初始化-bld
 */

object InitApWifiData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val CoorAoiDist="http://sds-core-datarun.sf-express.com/datarun/track/getCoorAoiDist?dist=50"
    var runKey=Array("755,113.60260156256727,22.33121691648796,114.68475488272917,22.977553036997236"
        ,"571,118.37421484399768,29.046533641435406,121.59320898417461,31.052902645582236"
        ,"411,120.7730527344928,38.59760956403838,123.77232031220029,40.29424604545931"
        ,"510,119.60162158212871,31.04907709488197,120.7359599608771,31.94368105784147"
        ,"592,117.79139648441932,24.34544719783711,118.55769287103138,24.917180413990312"
        ,"22,116.64068359382651,38.48349398706402,118.13482421861853,40.321224435200705")
    runKey=Array("10,115.33232617202331,39.40865500468647,117.55156445296441,41.13527040167249")
    val overCity=Array("798","970","799","972","523","976","512","977","513","973","515","974","516","975","517","701","518","790","527","432","511","433","514","434","519","435","310","436","312","437","318","438","319","439","313","711","314","712","315","713","316","714","317","724","335","728","930","456","932","457","593","458","599","901","596","902","597","903","594","906","595","908","530","909","534","990","537","992","538","998","635","892","532","894","535","895","631","896","533","893","536","952","539","953","543","955","546","482","632","473","633","475","7312","476","7313","478","734","479","735","483","736","730","737","744","738","370","739","372","743","374","745","375","746","378","8981","379","52","392","53","394","854","395","857","396","858","398","859","855","550","856","552","770","553","774","554","776","555","778","556","779","557","933","558","934","561","935","562","936","563","937","564","941","88","943","692","598","872","559","874","566","876","24","878","27","879","20","883","21","887","10","993","23","994","891","995","971","996","791","997","25","999","431","813","7311","838","311","911","931","913","591","917","871","352","991","353","28","354","29","355","351","357","531","358","951","359","471","954","451","470","371","472","898","474","851","477")

    val saveKey=Array("row_key","date","adcode","lng","validity","changefreq","lat","acc","city_code","aoi_id","aoi_name","aoi_key","aoi_dist","province","city","county","town","incday")
    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val mode=args(0)
        val runKeyArr = getCityInfos(sparkSession)
        val aoiInfoRdd = getAoiInfo(sparkSession)
        for(i<-0 until runKeyArr.size){
            if(mode.equals("add")){
                statAdd(runKeyArr(i)._1,runKeyArr(i)._2,runKeyArr(i)._3,runKeyArr(i)._4,runKeyArr(i)._5,sparkSession,aoiInfoRdd)
            }else if(mode.equals("complete")){
                stat(runKeyArr(i)._1,runKeyArr(i)._2,runKeyArr(i)._3,runKeyArr(i)._4,runKeyArr(i)._5,sparkSession,aoiInfoRdd)
            }else if(mode.equals("change")){
                statChange(runKeyArr(i)._1,runKeyArr(i)._2,runKeyArr(i)._3,runKeyArr(i)._4,runKeyArr(i)._5,sparkSession,aoiInfoRdd)

            }

        }
    }

    def getCityInfos(spark:SparkSession)={
        var sql=
            """
              |
              |select citycode,points from dm_gis.wifi_city_points_info
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val cityArray = dataRdd.map(obj => {
            val citycode = obj.getString("citycode")
            val points = obj.getString("points")
            var start_lng = ""
            var start_lat = ""
            var end_lng = ""
            var end_lat = ""
            if (StringUtils.nonEmpty(points)) {
                start_lng = points.split(",")(0)
                start_lat = points.split(",")(1)
                end_lng = points.split(",")(2)
                end_lat = points.split(",")(3)
            }


            (citycode, start_lng, start_lat, end_lng, end_lat)

        }).collect()
        cityArray


    }

    def getAoiInfo(spark:SparkSession)={
        var sql=
            """
              |
              |select aoi_id,name_p as province,name_c as city,name_d as county ,`name` as town,city_code from dm_gis.cms_aoi_town where inc_day in ( select inc_day as incday from dm_gis.cms_aoi_town a  where a.inc_day>'20231001' order by incday desc limit 1 )
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiInfoRdd = dataRdd.map(x => (x.getString("aoi_id"), x)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("aoiinfo 数据量------》"+aoiInfoRdd.count())
        aoiInfoRdd

    }

    def statChange(citycode:String,start_lng:String,start_lat:String,end_lng:String,end_lat:String,spark:SparkSession,aoiInfoRdd: RDD[(String,JSONObject)])={
        logger.error("开始计算城市----》 "+citycode)
        logger.error("开始获取aoi信息")
        val resultRdd = getAoiData(start_lng, start_lat, end_lng, end_lat, spark,"dm_gis.dm_gis_export_wifi_change_dtl_di",aoiInfoRdd)
        Spark.clearPersistWithoutIdList(spark,Array(resultRdd.id,aoiInfoRdd.id))
        logger.error("开始存储数据")
        SparkWrite.save2HiveStatic(spark, resultRdd, saveKey, "dm_gis.dm_wifi_finger_ap_mid_aoi_change_dtl_di",Array(("citycode", citycode)), 25)



    }

    def stat(citycode:String,start_lng:String,start_lat:String,end_lng:String,end_lat:String,spark:SparkSession,aoiInfoRdd: RDD[(String,JSONObject)])={
        logger.error("开始计算城市----》 "+citycode)
        logger.error("开始获取aoi信息")
        val resultRdd = getAoiData(start_lng, start_lat, end_lng, end_lat, spark,"dm_gis.gis_export_wifi",aoiInfoRdd)
        Spark.clearPersistWithoutIdList(spark,Array(resultRdd.id,aoiInfoRdd.id))
        logger.error("开始存储数据")
        SparkWrite.save2HiveStatic(spark, resultRdd, saveKey, "dm_gis.dm_wifi_finger_ap_mid_aoi_dtl_di",Array(("citycode", citycode)), 25)



    }

    def statAdd(citycode:String,start_lng:String,start_lat:String,end_lng:String,end_lat:String,spark:SparkSession,aoiInfoRdd: RDD[(String,JSONObject)])={
        logger.error("开始计算城市----》 "+citycode)
        logger.error("开始获取aoi信息")
        val resultRdd = getAoiDataAdd(start_lng, start_lat, end_lng, end_lat, spark,aoiInfoRdd)
        Spark.clearPersistWithoutIdList(spark,Array(resultRdd.id,aoiInfoRdd.id))
        logger.error("开始存储数据")
        SparkWrite.save2HiveStatic(spark, resultRdd, saveKey, "dm_gis.dm_wifi_finger_ap_mid_aoi_dtl_di",Array(("citycode", citycode)), 25)



    }

    def getAoiDataAdd(start_lng:String,start_lat:String,end_lng:String,end_lat:String,spark:SparkSession,aoiInfoRdd: RDD[(String,JSONObject)])={
        //dm_gis.gis_export_wifi
        var sql_old=
            s"""
              |
              |
              |select a.* from
              |(select * from dm_gis.dm_wifi_finger_ap_mid_aoi_dtl_di where lng>=$start_lng and lat>=$start_lat and lng<=$end_lng and lat<=$end_lat ) a
              |left join
              |(select * from dm_gis.gis_export_wifi  where lng>=$start_lng and lat>=$start_lat and lng<=$end_lng and lat<=$end_lat ) b
              |on a.row_key=b.row_key
              |where
              |a.lng=b.lng and a.lat=b.lat
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql_old)
        val (dataOldRdd, columns) =SparkRead.readHiveAsJson(spark, sql_old,400)

        var sql=
            s"""
               |
               |select a.* from
               |(select * from dm_gis.gis_export_wifi where lng>=$start_lng and lat>=$start_lat and lng<=$end_lng and lat<=$end_lat ) a
               |left join
               |(select * from dm_gis.dm_wifi_finger_ap_mid_aoi_dtl_di  where lng>=$start_lng and lat>=$start_lat and lng<=$end_lng and lat<=$end_lat ) b
               |on a.row_key=b.row_key
               |where
               |a.lng!=b.lng or a.lat!=b.lat
               |
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,400)
        Spark.clearPersistWithoutId(spark,dataRdd.id)
        val resultRdd=dataRdd.mapPartitionsWithIndex((index, iter) => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val tmplistBuffer: ListBuffer[JSONObject] = ListBuffer()
            var cnt=0
            for (obj <- iter)  {
                if(cnt==100){
                    listBuffer++=getCoorAoiDist(tmplistBuffer)
                    tmplistBuffer.clear()
                    cnt=0
                }else{
                    tmplistBuffer+=obj
                    cnt+=1
                }
            }
            if(tmplistBuffer.size>0){
                listBuffer++=getCoorAoiDist(tmplistBuffer)
            }
            listBuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取aoi数据量---》"+resultRdd.count())
        val compeleteRdd = resultRdd.map(x => (x.getString("aoi_id"), x)).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                dataObj.fluentPutAll(leftObj)
                dataObj.put("aoi_key", getMd5Key(leftObj.getString("aoi_id")))
                if (rightOp.nonEmpty) {
                    dataObj.fluentPutAll(rightOp.get)

                }

            }
            dataObj

        })
        //        Thread.sleep(100000)

        compeleteRdd.union(dataOldRdd)


    }

    def getAoiData(start_lng:String,start_lat:String,end_lng:String,end_lat:String,spark:SparkSession,from_table:String,aoiInfoRdd: RDD[(String,JSONObject)])={
        //dm_gis.gis_export_wifi
        var sql=
            s"""
              |
              |select * from $from_table  where lng>=$start_lng and lat>=$start_lat and lng<=$end_lng and lat<=$end_lat
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,400)
        Spark.clearPersistWithoutId(spark,dataRdd.id)
        val resultRdd=dataRdd.mapPartitionsWithIndex((index, iter) => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            val tmplistBuffer: ListBuffer[JSONObject] = ListBuffer()
            var cnt=0
            for (obj <- iter)  {
                if(cnt==100){
                    listBuffer++=getCoorAoiDist(tmplistBuffer)
                    tmplistBuffer.clear()
                    cnt=0
                }else{
                    tmplistBuffer+=obj
                    cnt+=1
                }
            }
            if(tmplistBuffer.size>0){
                listBuffer++=getCoorAoiDist(tmplistBuffer)
            }
            listBuffer.iterator
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("获取aoi数据量---》"+resultRdd.count())
        val compeleteRdd = resultRdd.map(x => (x.getString("aoi_id"), x)).leftOuterJoin(aoiInfoRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                dataObj.fluentPutAll(leftObj)
                dataObj.put("aoi_key", getMd5Key(leftObj.getString("aoi_id")))
                if (rightOp.nonEmpty) {
                    dataObj.fluentPutAll(rightOp.get)

                }

            }
            dataObj

        })
//        Thread.sleep(100000)
        compeleteRdd


    }

    def getCoorAoiDist(dataList:ListBuffer[JSONObject])={
        val listBuffer: ListBuffer[JSONObject] = ListBuffer()
        val resultSet=new mutable.HashSet[JSONObject]()
        var jSONObject=new JSONObject()
        val array = new JSONArray()
        if(dataList.size>0){
            for(i <- 0 until dataList.size){
                val data = new JSONObject()
                val obj = dataList(i)
                data.put("lng",obj.getString("lng"))
                data.put("lat",obj.getString("lat"))
                array.add(data)

            }

        }
        jSONObject = try {
            Thread.sleep(50)
            HttpUtils.urlConnectionPostJson(CoorAoiDist,array.toString(),5000)
        }
        catch {
            case _=>{
                logger.error("error parameter-----> "+array.toString())
                null
            }
        }

        if(jSONObject!=null){
//            logger.error("data ----->"+jSONObject.toString())
            val dataArr = JSONUtil.getJsonArrayFromObject(jSONObject, "data")
            for(i <- 0 until dataArr.size){
//                logger.error("调用接口获取的aoi数据量----》"+dataArr.size())
                val nObject = dataArr.getJSONObject(i)
                val lng=nObject.getString("lng")
                val lat=nObject.getString("lat")
                val aoiId=nObject.getString("aoiId")
                val aoiname=nObject.getString("aoiName")
                val dist=nObject.getString("dist")
                for(j <- 0 until dataList.size){
                    val dataObj = dataList(j)
                    val dataLng=dataObj.getString("lng")
                    val dataLat=dataObj.getString("lat")
                    if(lng!=null&&dataLng!=null&&lat!=null&&dataLat!=null&&lng.equals(dataLng)&&lat.equals(dataLat)){
//                        logger.error("相同的坐标经纬度的aoi是-----》"+aoiId)
                        dataObj.put("aoi_id",aoiId)
                        dataObj.put("aoi_name",aoiname)
                        dataObj.put("aoi_dist",dist)
                        listBuffer+=dataObj


                    }

                }

            }

        }
//        logger.error("相同经纬度的数据量---》"+listBuffer.size)
        listBuffer
    }



}
