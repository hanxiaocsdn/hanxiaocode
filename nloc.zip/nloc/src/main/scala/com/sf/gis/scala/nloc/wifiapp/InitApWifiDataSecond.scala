package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.java.nloc.utils.MacKeySaltUtils
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{HttpUtils, JSONUtil, StringUtils}
import com.sf.gis.scala.nloc.wifiapp.DeliverFilterInvalidWifi.getHour
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01407317
 * @Author: 01407499
 * @CreateTime: 2023-11-02 15:40
 * @TaskId:878333
 * @TaskName:
 * @Description:AP库wifi数据初始化-aoi
 */

object InitApWifiDataSecond {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("row_key","wifi","decrypt_wifi","date","adcode","lng","validity","changefreq","lat","acc","city_code","aoi_id","bld_aoi_id","aoi_name","aoi_key","aoi_dist","buildingid","buildingname","bld_key","province","city","county","town","incday")
    val getPoiByPoint="http://sds-core-datarun.sf-express.com/datarun/building/getPoiByPoint?x=%s&y=%s"
    val getPoiByPoints="http://sds-core-datarun.sf-express.com/datarun/building/getPoiByCoors"
    val runKey=Array("755,113.60260156256727,22.33121691648796,114.68475488272917,22.977553036997236"
        ,"571,118.37421484399768,29.046533641435406,121.59320898417461,31.052902645582236"
        ,"411,120.7730527344928,38.59760956403838,123.77232031220029,40.29424604545931"
        ,"510,119.60162158212871,31.04907709488197,120.7359599608771,31.94368105784147"
        ,"592,117.79139648441932,24.34544719783711,118.55769287103138,24.917180413990312"
        ,"22,116.64068359382651,38.48349398706402,118.13482421861853,40.321224435200705")
    def main(args: Array[String]): Unit = {
//        val citycode=args(0)
        val mode=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")

        val runKeyArr = getCityInfos(sparkSession)
        for(i<-0 until runKeyArr.size){
            if(mode.equals("add")){
            }else if(mode.equals("complete")){
                stat(runKeyArr(i)._1,sparkSession)
            }else if(mode.equals("change")){
                statChange(runKeyArr(i)._1,sparkSession)

            }

        }

    }


    def stat(citycode:String,spark:SparkSession)={

        logger.error("开始计算城市----》 "+citycode)
        logger.error("获取楼栋信息")

        val resultRdd = getAoiDataNew(spark,citycode,"dm_gis.dm_wifi_finger_ap_mid_aoi_dtl_di")
        Spark.clearPersistWithoutId(spark,resultRdd.id)
        logger.error("开始存储结果数据")
        SparkWrite.save2HiveStaticNew(spark, resultRdd, saveKey, "dm_gis.dm_wifi_finger_ap_mid_bld_tmp_dtl_di",Array(("citycode", citycode)), 25)


    }

    def statChange(citycode:String,spark:SparkSession)={

        logger.error("开始计算城市----》 "+citycode)
        logger.error("获取楼栋信息")

        val resultRdd = getAoiDataNew(spark,citycode,"dm_gis.dm_wifi_finger_ap_mid_aoi_change_dtl_di")
        Spark.clearPersistWithoutId(spark,resultRdd.id)
        logger.error("开始存储结果数据")
        SparkWrite.save2HiveStaticNew(spark, resultRdd, saveKey, "dm_gis.dm_wifi_finger_ap_mid_bld_change_dtl_di",Array(("citycode", citycode)), 25)


    }
    def getCityInfos(spark:SparkSession)={
        var sql=
            """
              |
              |select citycode,points from dm_gis.wifi_city_points_info
              |
              |""".stripMargin
              //where citycode='438'
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val cityArray = dataRdd.map(obj => {
            val citycode = obj.getString("citycode")
            val points = obj.getString("points")
            var start_lng = ""
            var start_lat = ""
            var end_lng = ""
            var end_lat = ""
            if (StringUtils.nonEmpty(points)) {
                start_lng = points.split(",")(0)
                start_lat = points.split(",")(1)
                end_lng = points.split(",")(2)
                end_lat = points.split(",")(3)
            }


            (citycode, start_lng, start_lat, end_lng, end_lat)

        }).collect()
        cityArray


    }


    def getAoiDataNew(spark:SparkSession, citycode:String,from_table:String)={
        //dm_gis.wifi_finger_ap_mid_aoi
        var sql=
            s"""
               |
               |select
               |c.row_key
               |,c.`date`
               |,c.adcode
               |,c.lng
               |,c.validity
               |,c.changefreq
               |,c.lat
               |,c.acc
               |,b.city_code
               |,b.aoi_id
               |,b.aoi_code
               |,b.aoi_name
               |,b.zno_code
               |,b.fa_type
               |,b.other_name
               |,b.road_name
               |,b.road_number
               |,b.del_flag
               |,b.pick
               |,b.village_type
               |,b.source
               |,b.type_check_source
               |,b.type_check
               |,c.aoi_dis
               |,c.incday
               |,c.citycode as source_citycode
               |from
               |(select * from (select *,row_number()over(partition by aoi_id,lng,lat order by aoi_dis ) rnk from $from_table where aoi_id is not null and aoi_id<>'' and citycode='$citycode' )a
               |where a.rnk=1) c
               |left join dm_gis.cms_aoi_sch b
               |on c.aoi_id=b.aoi_id
               |order by c.lng,c.lat
               |
               |""".stripMargin

        sql=
            s"""
              |
              |
              |select
              |row_key
              |,`date`
              |,adcode
              |,lng
              |,validity
              |,changefreq
              |,lat
              |,acc
              |,city_code
              |,aoi_id
              |,aoi_name
              |,aoi_key
              |,aoi_dist
              |,province
              |,city
              |,county
              |,town
              |,incday
              |from(
              |select *,row_number()over(partition by aoi_id,lng,lat order by aoi_dist ) rnk from $from_table where aoi_id is not null and aoi_id<>'' and citycode='$citycode'
              |) t
              |where t.rnk=1
              |
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,400)
        Spark.clearPersistWithoutId(spark,dataRdd.id)
        val bldRdd =dataRdd.mapPartitionsWithIndex((index, iter) => {
            val listBuffer: ListBuffer[JSONObject] = ListBuffer()
            var tmpBuffer: ListBuffer[JSONObject] = ListBuffer()
            var latArr = new JSONArray()
            for(obj <- iter){
                val tmpObj = new JSONObject()
                val aoi_name = obj.getString("aoi_name")
                val row_key = obj.getString("row_key")
                val lng = obj.getString("lng")
                val lat = obj.getString("lat")
                tmpObj.put("lng",lng)
                tmpObj.put("lat",lat)
                latArr.add(tmpObj)
                var wifi=""
                var decrypt_wifi=""
                if(row_key!=null&&row_key.nonEmpty){
                    wifi = MacKeySaltUtils.getMacKey(row_key.split("_")(1))
                    decrypt_wifi=MacKeySaltUtils.decryptMacKey(row_key.split("_")(1))
                }
                obj.put("wifi",wifi)
                obj.put("decrypt_wifi",decrypt_wifi)
                tmpBuffer+=obj
                if(tmpBuffer.size>=2000){
                    listBuffer++=getBuildInfosFromInterface(latArr,tmpBuffer)
                    tmpBuffer=ListBuffer[JSONObject]()
                    latArr=new JSONArray()

                }
            }
            if(tmpBuffer.size>=0){
                listBuffer++=getBuildInfosFromInterface(latArr,tmpBuffer)
                tmpBuffer=ListBuffer[JSONObject]()
                latArr=new JSONArray()
            }
            listBuffer.iterator
        })

//        val resultRdd=bldRdd.filter(obj=>StringUtils.nonEmpty(obj.getString("aoi_id"))&&StringUtils.nonEmpty(obj.getString("bld_aoi_id"))&&obj.getString("aoi_id").equals(obj.getString("bld_aoi_id"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        val resultRdd=bldRdd
//        logger.error("获取楼栋id数据量----》 "+resultRdd.count())
        resultRdd.take(10).foreach(println)
//        logger.error("获取aoi数据---》"+resultRdd.count())
//        Thread.sleep(10000000)
//        dataRdd.unpersist()
        resultRdd


    }

    def getBuildInfosFromInterface(pointArr:JSONArray,dataList:ListBuffer[JSONObject])={


        var nowHour = getHour()
//        while (!(nowHour>0&&nowHour<6)){
//            logger.error("当前时间为-----》"+nowHour+"---休眠1min")
//            Thread.sleep(1000*60)
//            nowHour = getHour()
//
//        }
        val dataListBuff = new ListBuffer[JSONObject]
        Thread.sleep(1000)
        val jSONObject = try {
            HttpUtils.urlConnectionPostJson(getPoiByPoints,pointArr.toString(),5000)
            //            HttpUtils.urlConnectionGetJson(url, 5000)

        }
        catch {
            case _=>{
                logger.error("error parameter-----> "+pointArr.toString())
                null
            }
        }
//        val dataArr = JSONUtil.getJsonArrayFromObject(jSONObject, "data")
        val responeDataObj = JSONUtil.getJSONObject(jSONObject, "data")
        if(responeDataObj!=null){
            if(dataList!=null&&dataList.length>0){
                for(i <- 0 until dataList.length){
                    val dataObj = dataList(i)
                    dataObj.put("village_type",responeDataObj)
                    val lng = dataObj.getString("lng")
                    val lat = dataObj.getString("lat")
                    val aoi_id = dataObj.getString("aoi_id")
                    val key=lng+","+lat
                    var bld_id=""
                    var bld_name=""
                    var bld_aoi_id=""
                    //                logger.error("key is ------>"+key)
                    val buildInfoObj = responeDataObj.getJSONObject(key)
                    //                logger.error("buildObj---->"+buildInfoObj)
                    if(buildInfoObj!=null){
                        bld_id=JSONUtil.getJsonVal(buildInfoObj,"guid","")
                        bld_name=JSONUtil.getJsonVal(buildInfoObj,"name","")
                        bld_aoi_id=JSONUtil.getJsonVal(buildInfoObj,"aoiId","")
                    }


                    if(StringUtils.nonEmpty(bld_id)&&StringUtils.nonEmpty(aoi_id)&&StringUtils.nonEmpty(bld_aoi_id)&&aoi_id.equals(bld_aoi_id)){
                        dataObj.put("buildingid", bld_id)
                        dataObj.put("buildingname", bld_name)
                        dataObj.put("bld_lon", lng)
                        dataObj.put("bld_lat", lat)
                        dataObj.put("bld_dis", "0")
                        dataObj.put("bld_aoi_id", bld_aoi_id)
                        dataObj.put("source",bld_aoi_id)
                        dataObj.put("bld_key",getMd5Key(bld_id))

                    }

                    dataListBuff+=dataObj

                }


            }


        }

//        logger.error("parameter  ------->"+pointArr.toString())
//        logger.error("build data--->"+jSONObject)
        dataListBuff



    }

    def getBuildInfoFromInterface(x:String,y:String)={
        val url = String.format(getPoiByPoint, x,y)
        Thread.sleep(1000)
        val jSONObject = try {
            HttpUtils.urlConnectionGetJson(url, 5000)
        }
        catch {
            case _=>{
                logger.error("error url-----> "+url)
                null
            }
        }
        logger.error("build data--->"+jSONObject)
        val bld_id=JSONUtil.getJsonVal(jSONObject,"data.guid","")
        val bld_lon=JSONUtil.getJsonVal(jSONObject,"data.lng","")
        val bld_lat=JSONUtil.getJsonVal(jSONObject,"data.lat","")
        (bld_id,bld_lon,bld_lat)


    }



    def getMd5Key(addr:String)={
        var resultMd5Str=""
        if(addr!=null&&addr.nonEmpty){
            val md5addr = MD5Util.getMD5(addr)
            resultMd5Str=md5addr.toLowerCase.substring(8, 24)
        }
        resultMd5Str

    }

    def getGeoData(wkt:String,x:Double,y:Double)={
        import com.sf.gis.uabs.common.util.GeoUtil
        var distance=(-1.0)
        try{
            val geom = GeoUtil.fromWkt(wkt)
            val point = GeoUtil.fromWkt(GeoUtil.buildPointWkt(x, y))
            distance = GeoUtil.getDistM(point.distance(geom))
        }catch {
            case _=>{
                logger.error("wkt------>"+wkt)
                distance=(-1.0)

            }
        }
        distance

    }

}
