package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @ProductManager:01422773
 * @Author: 01407499
 * @CreateTime: 2023-10-27  16:25
 * @TaskId:674932
 * @TaskName:wifi指纹库
 * @Description:wifi指纹库之wifi数据预处理
 */
object WifiFingerEwl {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey = Array( "waybill_no","city_code","emp_code","tm","addr","doing","ewl","lng","lat")

    def main(args: Array[String]): Unit = {
        val eventtype=args(0)
        val end_day=args(1)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        calcEwlData(sparkSession,end_day,eventtype)

    }

    def calcEwlData(spark:SparkSession,end_day:String,eventtype:String)={
        var sql=""

        if(eventtype.equals("31124")){

            sql=
                s"""
                  |
                  |select
                  |a.waybill_no
                  |,a.dist_code as city_code
                  |,emp_code
                  |,tm
                  |,addr
                  |,eventtype
                  |,trajectory_list
                  |,doing
                  |,date_time_timestamp
                  |from
                  |(select *,cast(unix_timestamp(tm,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp from dm_gis.gis_waybill_nloc where inc_day='$end_day' and eventtype='31124' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
                  |left join (select waybill_no,doing from dm_gis.gis_onsite_service_sensor_doing_info where inc_day='$end_day' and waybill_no is not null and waybill_no<>'' ) b on a.waybill_no=b.waybill_no
                  |left join (select un,concat_ws('tttt',collect_set(concat(`timestamp`,'_',ewl,'_',zx,'_',zy))) as trajectory_list  from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day'  and ewl<>'' and ewl is not null and un is not null and un<>'' group by un) c on a.emp_code=c.un
                  |
                  |
                  |
                  |
                  |
                  |""".stripMargin
        }else if(eventtype.equals("31201")){
            sql=
                s"""
                  |
                  |
                  |select
                  |a.waybill_no
                  |,a.dist_code city_code
                  |,emp_code
                  |,tm
                  |,addr
                  |,eventtype
                  |,trajectory_list
                  |,doing
                  |,date_time_timestamp
                  |from
                  |(select *,cast(unix_timestamp(tm,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp from dm_gis.gis_waybill_nloc where inc_day='$end_day' and eventtype='31201' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
                  |left join (select waybill_no,doing from dm_gis.dm_wifi_finger_sensor_doing_dtl_di where inc_day='$end_day' and  waybill_no is not null and waybill_no<>'' and doing<>'' and doing is not null ) b on a.waybill_no=b.waybill_no
                  |left join (select un,concat_ws('tttt',collect_set(concat(timestamp,'_',ewl,'_',zx,'_',zy))) as trajectory_list  from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day'  and ewl<>'' and ewl is not null and un is not null and un<>'' group by un) c on a.emp_code=c.un
                  |
                  |
                  |
                  |
                  |""".stripMargin


        }

        logger.error("sql---->"+sql)
        val allDF = spark.sql(sql)
        allDF.rdd.flatMap(x=>{
            val listBuffer: ListBuffer[Row] = ListBuffer()
            listBuffer
        })
        val dataRow = allDF.rdd.flatMap(x => {

            val listBuffer: ListBuffer[Row] = ListBuffer()

            try {

            } catch {
                case e: Exception => {
                    logger.error(e.getStackTrace)
                }
            }
            val date_time_timestamp = x.getAs[String](fieldName = "date_time_timestamp")
            val trajectory_list = x.getAs[String](fieldName = "trajectory_list")
            val waybill_no = x.getAs[String](fieldName = "waybill_no")
            val city_code = x.getAs[String](fieldName = "city_code")
            val emp_code = x.getAs[String](fieldName = "emp_code")
            val tm = x.getAs[String](fieldName = "tm")
            val addr = x.getAs[String](fieldName = "addr")
            val doing = x.getAs[String](fieldName = "doing")
            var mintimediff=60L
            var mintimedifftrajectory=""
            val trajectorySet = new mutable.HashSet[String]()
            val arr: ArrayBuffer[String] = ArrayBuffer(waybill_no, city_code, emp_code, tm, addr, doing)
            if (date_time_timestamp != null && date_time_timestamp.nonEmpty) {
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split("tttt").length > 0) {
                    for (trajectory <- trajectory_list.split("tttt")) {
                        if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 1) {
                            if (trajectory.split("_")(0).nonEmpty && trajectory.split("_")(0).toLong >= (date_time_timestamp.toLong - 30L) && trajectory.split("_")(0).toLong <= (date_time_timestamp.toLong + 30L)) {
                                if(mintimediff>math.abs(trajectory.split("_")(0).toLong-date_time_timestamp.toLong)){
                                    if (trajectory.split("_")(1) != null && trajectory.split("_")(1).nonEmpty) {
//                                        trajectorySet.add(trajectory)
                                        mintimedifftrajectory=trajectory
                                        mintimediff=math.abs(trajectory.split("_")(0).toLong-date_time_timestamp.toLong)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if(StringUtils.nonEmpty(mintimedifftrajectory)){
                val ewl = mintimedifftrajectory.split("_")(1)
                val lon = mintimedifftrajectory.split("_")(2)
                val lat = mintimedifftrajectory.split("_")(3)
                var row = new ArrayBuffer[String]
                row.appendAll(arr)
                row.append(ewl)
                row.append(lon)
                row.append(lat)
                val ret = Row.fromSeq(row)
                listBuffer += ret

            }

//            for (trajectory <- trajectorySet) {
//                var row = new ArrayBuffer[String]
//                row.appendAll(arr)
//                val ewl = trajectory.split("_")(1)
//                val lon = trajectory.split("_")(2)
//                val lat = trajectory.split("_")(3)
//                row.append(ewl)
//                row.append(lon)
//                row.append(lat)
//                val ret = Row.fromSeq(row)
//                listBuffer += ret
//            }

            listBuffer
        }).filter(x => StringUtils.nonEmpty(x.getString(6)))
        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveKey.indices) {
            schemaEle.append(StructField(saveKey.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        spark.createDataFrame(dataRow,schema).createOrReplaceTempView("tmp_ewl_result")
        var sql_w=
            s"""
              |
              |insert overwrite table dm_gis.dm_waybill_traj_wifi_doing_dtl_di partition(inc_day='$end_day',eventtype='$eventtype')
              |select
              |waybill_no
              |,city_code
              |,emp_code
              |,tm
              |,addr
              |,ewl
              |,lng
              |,lat
              |,doing
              |from tmp_ewl_result
              |
              |
              |
              |
              |
              |
              |""".stripMargin

        spark.sql(sql_w)
        logger.error("保存完成")



    }


    def getTrajectory(spark:SparkSession,start_day:String,end_day:String,citycode:String,tm_diff:String)={

        var sql=
            s"""
              |
              |select
              | waybill_no
              | ,dest_zone_code
              | ,dest_dist_code
              | ,dest_county
              | ,consignee_addr
              | ,emp_code
              | ,date_time
              | ,aoicode
              | ,aoi_id
              | ,cast(unix_timestamp(a.date_time,'yyyy-MM-dd HH:mm:ss') as string) as date_time_timestamp
              | ,trajectory_list
              | from
              | (select * from dm_gis.gis_onsite_service_info_v2 where inc_day='$end_day' and dest_dist_code regexp '$citycode' and waybill_no is not null and waybill_no<>'' and emp_code is not null and emp_code<>'') a
              | left join (select un,concat_ws('tttt',collect_set(concat(tm,'_',ewl))) as trajectory_list  from dm_gis.dm_lss_core_wifi_ewl_dtl_di where inc_day='$end_day'  and ewl<>'' and ewl is not null and un is not null and un<>'' group by un) d on a.emp_code=d.un
              |
              |""".stripMargin


        //and regexp_replace(substring(bn, 0, 3), '[a-zA-Z]*', '') regexp '$citycode'
        //and ac<100
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql,8000)
        val resultRdd=dataRdd.map(obj => {
            val date_time_timestamp = obj.getString("date_time_timestamp")
            val trajectorySet = new mutable.HashSet[String]()
            var trajectory_data=""
            if (date_time_timestamp!=null&&date_time_timestamp.nonEmpty) {
                val trajectory_list = obj.getString("trajectory_list")
                if (trajectory_list != null && trajectory_list.nonEmpty && trajectory_list.split("tttt").length > 0) {
                    for (trajectory <- trajectory_list.split("tttt")) {
                        if (trajectory != null && trajectory.nonEmpty && trajectory.split("_").length >= 1) {
                            if (trajectory.split("_")(0).nonEmpty && trajectory.split("_")(0).toLong >= (date_time_timestamp.toLong - tm_diff.toLong) && trajectory.split("_")(0).toLong <= (date_time_timestamp.toLong + tm_diff.toLong)) {
                                if(trajectory.split("_")(1)!=null&&trajectory.split("_")(1).nonEmpty){
                                    trajectorySet.add(trajectory.split("_")(1))
//                                    try{
//                                        val trajectoryjson = JSON.parseArray(trajectory.split("_")(1))
//                                        for(i <- 0 until trajectoryjson.size() ){
//                                            trajectorySet.add(trajectoryjson.getJSONObject(i).toString())
//                                        }
//                                    }catch {case e:Exception=>logger.error("error reason"+e.getMessage+"erre ewl data--->"+trajectory)}



                                }

                            }
                        }
                    }
                }
            }
            if(trajectorySet.size>0){
                trajectory_data=trajectorySet.mkString("|")
            }
//            trajectory_data="["+trajectory_data+"]"
            obj.put("ewl_data", trajectory_data)
            obj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

        resultRdd

    }






}
