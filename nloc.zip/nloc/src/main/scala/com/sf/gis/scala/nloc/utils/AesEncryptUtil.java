package com.sf.gis.scala.nloc.utils;

/**
 * @author 01374035
 * @create 2020-12-17 15:01
 */
/**
 * AES 128bit 加密解密工具类
 * @author dufy
 */

import com.sf.gis.uabs.common.util.GeoUtil;
import com.vividsolutions.jts.geom.Geometry;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class AesEncryptUtil {

    //使用AES-128-CBC加密模式，key需要为16位,key和iv可以相同！
    private static String KEY = "2345535350123456";
    private static String IV = "2345535350123456";

    /**
     * 加密方法
     * @param data  要加密的数据
     * @param key 加密key
     * @param iv 加密iv
     * @return 加密的结果
     * @throws Exception
     */
    public static String encrypt(String data, String key, String iv) {
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");//"算法/模式/补码方式"NoPadding PkcsPadding
            int blockSize = cipher.getBlockSize();

            byte[] dataBytes = data.getBytes();
            int plaintextLength = dataBytes.length;
            if (plaintextLength % blockSize != 0) {
                plaintextLength = plaintextLength + (blockSize - (plaintextLength % blockSize));
            }
            byte[] plaintext = new byte[plaintextLength];
            System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.length);

            SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());

            cipher.init(Cipher.ENCRYPT_MODE, keyspec, ivspec);
            byte[] encrypted = cipher.doFinal(plaintext);
            return new Base64().encodeToString(encrypted);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 解密方法
     * @param data 要解密的数据
     * @param key  解密key
     * @param iv 解密iv
     * @return 解密的结果
     * @throws Exception
     */
    public static String desEncrypt(String data, String key, String iv) {
        try {
            byte[] encrypted1 = new Base64().decode(data);

            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            SecretKeySpec keyspec = new SecretKeySpec(key.getBytes(), "AES");
            IvParameterSpec ivspec = new IvParameterSpec(iv.getBytes());

            cipher.init(Cipher.DECRYPT_MODE, keyspec, ivspec);

            byte[] original = cipher.doFinal(encrypted1);
            String originalString = new String(original);
            return originalString;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 使用默认的key和iv加密
     * @param data
     * @return
     * @throws Exception
     */
    public static String encrypt(String data)  {
        return encrypt(data, KEY, IV);
    }

    /**
     * 使用默认的key和iv解密
     * @param data
     * @return
     * @throws Exception
     */
    public static String desEncrypt(String data) {
        return desEncrypt(data, KEY, IV);
    }



    /**
     * 测试
     */
    public static void main(String args[]) throws Exception {
     /*   String test1 = "sa";
        //String test = new String(test1.getBytes(), "UTF-8");
        String xdata =
                "pQkuwudHAu/tPWyk4/rlDhvl5yC8TPf6T3Zv+Rdx4EhOJUsQRBpv/3j0DSRz8txSEzJEdMrpe4XXW82zHMrMIOh804/RjwwZ7mOQLYwiDGusXRe8JAQmNNfv3LDzHAa7I1a2SAIakEAAob7D9ln4hCF1zVplyTlcbE4kcY7tGz7xG9GlbrxjVIlOorljJh448bD7glg7L4mMzidx9i3vOCTSV5G4TSf5NfWvvyutuE7qctXMQxU5q+eqgNUV+0DXMxTvX6w4q9VA4OTiN9/EOQ==";
        //String ydata = "lqXnFegRhLw45E3nwa/Jqkvo3nsWtArpsEws4zqZrng=";
        String key = KEY;
        String iv = IV;
        // /g2wzfqvMOeazgtsUVbq1kmJawROa6mcRAzwG1/GeJ4=
        //data = encrypt(test, key, iv);
        //System.out.println("数据：" + test);
        //System.out.println("加密：" + data);
        String x = desEncrypt(xdata, key, iv).trim();
        //String y = desEncrypt(ydata, key, iv).trim();
        System.out.println("解密：x:"+ x);*/
        Geometry aGeom = GeoUtil.fromWkt("POLYGON ((120.0925478339195 30.341354596145365, 120.09352952241895 30.341683301451553, 120.09463459253308 30.339924020760293, 120.09372800588604 30.33952123362768, 120.0925478339195 30.341354596145365))");
        Geometry bgeom = GeoUtil.fromWkt("POLYGON((120.09239101620548 30.34199175102553,120.09484255524511 30.342908413441364,120.09631777020329 30.340843596092014,120.09387695999973 30.339602832878924,120.09239101620548 30.34199175102553))");
        Geometry intersection = bgeom.intersection(aGeom);
       double a =  intersection.getArea() / aGeom.getArea();
       System.out.println(a);
    }
}
