package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.wifiapp.InitApWifiDataSecond.getMd5Key
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiData.splitFingerList
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-07-31 09:44
 * @TaskId:786233
 * @TaskName:wifi指纹库-aoi删除
 * @Description:
 */

object WifiAOIInfoDel {

    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger(className)
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","city_code","address","province","city","county","town","village","aoi_name","lng","lat","points","reliable","inc_day","reserve1","reserve2")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","city_code","address","province","city","county","town","village","aoi_name","buildingname","lng","lat","points","inc_day","reliable","reserve1","reserve2")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","city_code","floor","lng","lat")
    val saveDetailKey=Array("key","wifi_list","upper_key","city_code","address","level","province","city","county","town","village","aoi_name","buildingname","floor","room","lng","lat","points","inc_day","reliable","reserve1","reserve2")


    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取待删除aoi信息")
        val delAoiInfoSetBro = getDelAOIInfo(sparkSession)
        logger.error("删除wifi指纹库-aoi数据")
        val (notDeleAoiRdd, deleteBldMapBro, deleteAoiWifiMap) = delWifiAoi(sparkSession, delAoiInfoSetBro)
        logger.error("删除wifi指纹库-bld数据")
        val (notDeleBldRdd, deleteFloorMapBro, deleteBldWifiMap) = deleteWifiBld(sparkSession, deleteBldMapBro)
        logger.error("删除wifi指纹库-detail数据")
        val (notDeleFloorRdd, deleteFloorWifiMap) = deleteWifiFloor(sparkSession, deleteFloorMapBro)
        logger.error("删除wifi指纹库-index数据")
        val notDeleWifiRdd = deleteWifi(sparkSession, deleteAoiWifiMap, deleteBldWifiMap, deleteFloorWifiMap)
        logger.error("存储wifi指纹aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, notDeleAoiRdd, saveAoiKey, "dm_gis.dm_wifi_finger_aoi_dtl", null, 25)
        logger.error("存储wifi指纹bld数据")
        SparkWrite.save2HiveStaticNew(sparkSession, notDeleBldRdd, saveBuildKey, "dm_gis.dm_wifi_finger_bld_dtl", null, 25)
        logger.error("存储wifi指纹floor数据")
        SparkWrite.save2HiveStaticNew(sparkSession, notDeleFloorRdd, saveDetailKey, "dm_gis.dm_wifi_finger_detail_dtl", null, 25)
        logger.error("存储wifi指纹index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, notDeleWifiRdd, saveIndexKey, "dm_gis.dm_wifi_finger_index_dtl", null, 25)

    }

    def getDelAOIInfo(spark: SparkSession): Broadcast[Set[String]] = {
        var sql = "select * from dm_gis.dm_aoi_del_info"
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val delAoiInfoSet = dataRdd.map(obj => obj.getString("aoi_id")).collect().toSet
        spark.sparkContext.broadcast(delAoiInfoSet)

    }

    def delWifiAoi(spark: SparkSession, delAoiInfoSetBro: Broadcast[Set[String]]): (RDD[JSONObject], Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = {
        var sql =
            """
              |
              |select * from dm_gis.dm_wifi_finger_aoi_dtl
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val markDeleAoiRdd = dataRdd.map(obj => {
            val delAoiInfoSet = delAoiInfoSetBro.value
            val aoi_id = obj.getString("aoi_id")
            val dataObj = new JSONObject()
            if (delAoiInfoSet.contains(aoi_id)) {
                val key = obj.getString("key")
                val finger_list = obj.getString("finger_list")
                val wifi_list = obj.getString("wifi_list")
                dataObj.put("key", key)
                dataObj.put("finger_list", finger_list)
                dataObj.put("wifi_list", wifi_list)
                dataObj.put("isdelete", true)


            } else {
                dataObj.fluentPutAll(obj)

            }
            dataObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记删除数据量---》" + markDeleAoiRdd.count())
        val deleteAoiRdd = markDeleAoiRdd.filter(obj => StringUtils.nonEmpty(obj.getString("isdelete")) && obj.getString("isdelete").toBoolean)
        val notDeleAoiRdd = markDeleAoiRdd.filter(obj => (!StringUtils.nonEmpty(obj.getString("isdelete"))))
        val deleteBldMap = deleteAoiRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val fingerMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val key = obj.getString("key").split("_")(1)
                val finger_list = obj.getString("finger_list")
                val fingerSet = new mutable.HashSet[String]()
                splitFingerList(finger_list, fingerSet)
                for (finger_bld <- fingerSet) {
                    if (fingerMap.contains(finger_bld)) {
                        fingerMap.put(finger_bld, fingerMap.get(finger_bld).get + key)

                    } else {
                        fingerMap.put(finger_bld, key)

                    }

                }


            }
            for (finger_key <- fingerMap.keySet) {
                val tmpKey = fingerMap.get(finger_key).get
                listBuffer += ((finger_key, tmpKey))

            }

            listBuffer.iterator

        }).collect().toMap

        val deleteWifiMap = deleteAoiRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val wifiMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val key = obj.getString("key").split("_")(1)
                val wifi_list = obj.getString("wifi_list")

                try {
                    val wifiArr = JSON.parseArray(wifi_list)
                    for (i <- 0 until wifiArr.size()) {
                        val wifiObj = wifiArr.getJSONObject(i)
                        val wifiKey = getMd5Key(wifiObj.getString("mac"))
                        if (wifiMap.contains(wifiKey)) {
                            wifiMap.put(wifiKey, wifiMap.get(wifiKey).get + key)
                        } else {
                            wifiMap.put(wifiKey, key)

                        }

                    }
                } catch {
                    case e: Exception => logger.error("")
                }

            }
            for (wifi_key <- wifiMap.keySet) {
                val tmpKey = wifiMap.get(wifi_key).get
                listBuffer += ((wifi_key, tmpKey))

            }

            listBuffer.iterator

        }).collect().toMap
        (notDeleAoiRdd, spark.sparkContext.broadcast(deleteBldMap), spark.sparkContext.broadcast(deleteWifiMap))
    }

    def deleteWifiBld(spark: SparkSession, deleteBldMapBro: Broadcast[Map[String, String]]) = {
        var sql =
            """
              |
              |select * from dm_gis.dm_wifi_finger_bld_dtl
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val markDeleBldRdd = dataRdd.map(obj => {
            val deleteBldMap = deleteBldMapBro.value
            val key = obj.getString("key").split("_")(1)
            val dataObj = new JSONObject()

            if (deleteBldMap.contains(key)) {
                val finger_list = obj.getString("finger_list")
                val wifi_list = obj.getString("wifi_list")
                dataObj.put("key", obj.getString("key"))
                dataObj.put("finger_list", finger_list)
                dataObj.put("wifi_list", wifi_list)
                dataObj.put("isdelete", true)

            } else {
                dataObj.fluentPutAll(obj)

            }


            dataObj


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记删除数据量---》" + markDeleBldRdd.count())
        val deleteBldRdd = markDeleBldRdd.filter(obj => StringUtils.nonEmpty(obj.getString("isdelete")) && obj.getString("isdelete").toBoolean)
        val notDeleBldRdd = markDeleBldRdd.filter(obj => (!StringUtils.nonEmpty(obj.getString("isdelete"))))
        val deletefloorMap = deleteBldRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val fingerMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val key = obj.getString("key").split("_")(1)
                val finger_list = obj.getString("finger_list")
                val fingerSet = new mutable.HashSet[String]()
                splitFingerList(finger_list, fingerSet)
                for (finger_bld <- fingerSet) {
                    if (fingerMap.contains(finger_bld)) {
                        fingerMap.put(finger_bld, fingerMap.get(finger_bld).get + key)

                    } else {
                        fingerMap.put(finger_bld, key)

                    }
                }


            }
            for (finger_key <- fingerMap.keySet) {
                val tmpkey: String = fingerMap.get(finger_key).get
                listBuffer += ((finger_key, tmpkey))

            }

            listBuffer.iterator

        }).collect().toMap

        val deleteWifiMap = deleteBldRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val wifiMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val key = obj.getString("key").split("_")(1)
                val wifi_list = obj.getString("wifi_list")
                try {
                    val wifiArr = JSON.parseArray(wifi_list)
                    for (i <- 0 until wifiArr.size()) {
                        val wifiObj = wifiArr.getJSONObject(i)
                        val wifiKey = getMd5Key(wifiObj.getString("mac"))
                        if (wifiMap.contains(wifiKey)) {
                            wifiMap.put(wifiKey, wifiMap.get(wifiKey).get + key)
                        } else {
                            wifiMap.put(wifiKey, key)

                        }
                    }
                } catch {
                    case e: Exception => logger.error("")
                }

            }
            for (wifi_key <- wifiMap.keySet) {
                val tmpkey = wifiMap.get(wifi_key).get
                listBuffer += ((wifi_key, tmpkey))

            }

            listBuffer.iterator

        }).collect().toMap
        (notDeleBldRdd, spark.sparkContext.broadcast(deletefloorMap), spark.sparkContext.broadcast(deleteWifiMap))


    }

    def deleteWifiFloor(spark: SparkSession, deleteFloorMapBro: Broadcast[Map[String, String]]) = {
        var sql =
            """
              |
              |select * from dm_gis.dm_wifi_finger_detail_dtl
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val markDeleFloorRdd = dataRdd.map(obj => {
            val deleteBldMap = deleteFloorMapBro.value
            val key = obj.getString("key").split("_")(1)
            val dataObj = new JSONObject()
            if (deleteBldMap.contains(key)) {
                val wifi_list = obj.getString("wifi_list")
                dataObj.put("key", obj.getString("key"))
                dataObj.put("wifi_list", wifi_list)
                dataObj.put("isdelete", true)

            } else {
                dataObj.fluentPutAll(obj)

            }


            dataObj


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记删除数据量---》" + markDeleFloorRdd.count())
        val deleteFloorRdd = markDeleFloorRdd.filter(obj => StringUtils.nonEmpty(obj.getString("isdelete")) && obj.getString("isdelete").toBoolean)
        val notDeleFloorRdd = markDeleFloorRdd.filter(obj => (!StringUtils.nonEmpty(obj.getString("isdelete"))))

        val deleteWifiMap = deleteFloorRdd.mapPartitions(x => {
            val listBuffer: ListBuffer[(String, String)] = ListBuffer()
            val wifiMap = new mutable.HashMap[String, String]()
            for (obj <- x) {
                val key = obj.getString("key").split("_")(1)
                val wifi_list = obj.getString("wifi_list")

                try {
                    val wifiArr = JSON.parseArray(wifi_list)
                    for (i <- 0 until wifiArr.size()) {
                        val wifiObj = wifiArr.getJSONObject(i)
                        val wifiKey = getMd5Key(wifiObj.getString("mac"))
                        if (wifiMap.contains(wifiKey)) {
                            wifiMap.put(wifiKey, wifiMap.get(wifiKey).get + key)
                        } else {
                            wifiMap.put(wifiKey, key)

                        }
                    }
                } catch {
                    case e: Exception => logger.error("")
                }

            }
            for (wifi_key <- wifiMap.keySet) {
                val tmpkey = wifiMap.get(wifi_key).get
                listBuffer += ((wifi_key, tmpkey))

            }

            listBuffer.iterator

        }).collect().toMap

        ((notDeleFloorRdd, spark.sparkContext.broadcast(deleteWifiMap)))

    }

    def deleteWifi(spark: SparkSession, deleteAoiWifiMapBro: Broadcast[Map[String, String]], deleteBldWifiMapBro: Broadcast[Map[String, String]], deleteFloorWifiMapBro: Broadcast[Map[String, String]]) = {

        var sql =
            """
              |
              |select * from dm_gis.dm_wifi_finger_index_dtl
              |
              |""".stripMargin
        logger.error("sql---->" + sql)
        val (dataRdd, columns1) = SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val deleteAoiWifiMap = deleteAoiWifiMapBro.value
            val deleteBldWifiMap = deleteBldWifiMapBro.value
            val deleteFloorWifiMap = deleteFloorWifiMapBro.value
            val key = obj.getString("key").split("_")(1)
            if (deleteAoiWifiMap.contains(key)) {
                val finger_aoi = obj.getString("finger_aoi")
                val fingerSet = new mutable.HashSet[String]()
                val aoiMap = new mutable.HashMap[String, String]()
                splitFingerAoiMap(finger_aoi, aoiMap)
//                splitFingerList(finger_aoi, fingerSet)
                val errorAois = deleteAoiWifiMap.get(key).get
                val fingerErrorSet = new mutable.HashSet[String]()
                splitFingerList(errorAois, fingerErrorSet)
                for (errorAoi <- fingerErrorSet) {
//                    fingerSet.remove(errorAoi)
                    aoiMap.remove(errorAoi)
                }

                obj.put("finger_aoi", aoiMap.values.mkString(""))
//                obj.put("finger_aoi", fingerSet.mkString(""))
            }
            if (deleteBldWifiMap.contains(key)) {
                val finger_bld = obj.getString("finger_bld")
                val fingerSet = new mutable.HashSet[String]()
                splitFingerList(finger_bld, fingerSet)
                val errorAois = deleteBldWifiMap.get(key).get
                val fingerErrorSet = new mutable.HashSet[String]()
                splitFingerList(errorAois, fingerErrorSet)
                for (errorAoi <- fingerErrorSet) {
                    fingerSet.remove(errorAoi)
                }
                obj.put("finger_bld", fingerSet.mkString(""))

            }

            if (deleteFloorWifiMap.contains(key)) {
                val finger_detail = obj.getString("finger_detail")
                val fingerSet = new mutable.HashSet[String]()
                splitFingerList(finger_detail, fingerSet)
                val errorAois = deleteFloorWifiMap.get(key).get
                val fingerErrorSet = new mutable.HashSet[String]()
                splitFingerList(errorAois, fingerErrorSet)
                for (errorAoi <- fingerErrorSet) {
                    fingerSet.remove(errorAoi)
                }
                obj.put("finger_detail", fingerSet.mkString(""))

            }
            obj

        }).filter(obj => StringUtils.nonEmpty(obj.getString("finger_aoi")))

        resultRdd

    }

    def splitFingerAoiMap(fingerList: String, fingerMap: mutable.HashMap[String, String]): Unit = {
        try {
            if (fingerList.length > 0) {
                for (i <- 0 until fingerList.length / 19) {
                    val finger_aoi = fingerList.substring(i * 19, (i + 1) * 19)
                    if (fingerMap.contains(finger_aoi.substring(0, 16))) {
                        val avg_ss = fingerMap.get(finger_aoi.substring(0, 16)).get.substring(16)
                        val ewl_dis = finger_aoi.substring(16)
                        val sig = (math.round((avg_ss.toLong + Math.abs(ewl_dis.toDouble)) / 2) + 1000).toString.substring(1)
                        fingerMap.put(finger_aoi.substring(0, 16), finger_aoi.substring(0, 16) + sig)
                    } else {
                        fingerMap.put(finger_aoi.substring(0, 16), finger_aoi)

                    }
                }
            }
        } catch {
            case e: Exception => {
                logger.error("error finger ---->" + fingerList)
            }
        }

    }
}