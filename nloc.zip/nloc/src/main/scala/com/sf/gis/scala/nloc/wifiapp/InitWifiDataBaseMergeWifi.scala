package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.app.InitWifiDataBaseMergeWifi.logger
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiAggData.{cleanWifi, splitFingerList, splitFingerMap}
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiDailyData.getHmodRowKey
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.SparkSession

import scala.collection.mutable
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01410433
 * @Author: 01407499
 * @CreateTime: 2023-08-08 09:46
 * @TaskId:892665
 * @TaskName:wifi指纹库-合并ap轨迹wifi指纹
 * @Description:
 */

object InitWifiDataBaseMergeWifi {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","city_code","address","province","city","county","town","village","aoi_name","lng","lat","points","reliable","inc_day","reserve1","reserve2")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","city_code","address","province","city","county","town","village","aoi_name","buildingname","lng","lat","points","inc_day","reliable","reserve1","reserve2")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","city_code","floor","lng","lat","decrypt_wifi")
    val saveDetailKey=Array("key","wifi_list","upper_key","city_code","address","level","province","city","county","town","village","aoi_name","buildingname","floor","room","lng","lat","points","inc_day","reliable","reserve1","reserve2")

    def main(args: Array[String]): Unit = {
        var end_day=args(0)
        var start_day=args(1)
        var mode=args(2)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        mode match {
            case "all" =>calcAll(sparkSession,end_day,start_day)
            case "aoi" =>calcAoi(sparkSession,end_day,start_day)
            case "index"=>calcIndex(sparkSession,end_day,start_day)
            case _=>logger.error("请输入需要计算的mode")
        }
    }

    def calcAll(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("合并aoi数据")
        val aoiRdd = mergeAoi(sparkSession, aoiWhiteMapBroad)
        logger.error("合并bld数据")
        val bldRdd = mergeBuld(sparkSession, bldWhiteMapBroad)


        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, aoiRdd, saveAoiKey, "dm_gis.dm_wifi_finger_aoi_dtl",null, 25)
        logger.error("存储wifi build数据")
        SparkWrite.save2HiveStaticNew(sparkSession, bldRdd, saveBuildKey, "dm_gis.dm_wifi_finger_bld_dtl",null, 25)
        aoiRdd.unpersist()
        logger.error("合并detail数据")
        val detailRdd = mergeDetail(sparkSession)
        logger.error("存储 wifi detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, detailRdd, saveDetailKey, "dm_gis.dm_wifi_finger_detail_dtl",null, 25)
        detailRdd.unpersist()

        logger.error("合并index数据")
        val indexRdd = mergeIndex(sparkSession,end_day,start_day)
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, indexRdd, saveIndexKey, "dm_gis.dm_wifi_finger_index_dtl",null, 25)



    }
    def calcAoi(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("获取白名单数据")
        val (aoiWhiteMapBroad,bldWhiteMapBroad): (Broadcast[Map[String, String]], Broadcast[Map[String, String]]) = getFingerWhite(sparkSession)
        logger.error("合并aoi数据")
        val aoiRdd = mergeAoi(sparkSession, aoiWhiteMapBroad)

        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, aoiRdd, saveAoiKey, "dm_gis.dm_wifi_finger_aoi_dtl",null, 25)
        logger.error("存储wifi build数据")


    }

    def calcIndex(sparkSession:SparkSession,end_day:String,start_day:String)={
        logger.error("合并index数据")
        val indexRdd = mergeIndex(sparkSession,end_day,start_day)
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, indexRdd, saveIndexKey, "dm_gis.dm_wifi_finger_index_dtl",null, 25)

    }
    def mergeIndex(spark:SparkSession,end_day:String,start_day:String)={
        var sql=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_ap_index_sum
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val apDataRdd =SparkRead.readHiveAsJson(spark, sql)._1.map(obj=>(obj.getString("key"),obj))
        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_traj_index_dtl
              |
              |
              |
              |""".stripMargin

        val traceDataRdd =SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj=>(obj.getString("key"),obj))
        var resultRdd = apDataRdd.fullOuterJoin(traceDataRdd).map(x => {
            val leftObjOp = x._2._1
            val rightObjOp = x._2._2
            var obj = new JSONObject()
            obj.put("update_tag", "1")

            if (leftObjOp.nonEmpty) {
                if (rightObjOp.nonEmpty) {
                    val leftObj = leftObjOp.get
                    val rightObj = rightObjOp.get
                    val finger_aoi = leftObj.getString("finger_aoi") + rightObj.getString("finger_aoi")
                    val finger_bld = leftObj.getString("finger_bld") + rightObj.getString("finger_bld")
                    val finger_detail = leftObj.getString("finger_detail") + rightObj.getString("finger_detail")
                    val aoiSet = new mutable.HashMap[String,String]()
                    val buildMap = new mutable.HashMap[String,String]()
                    val fingerMap = new mutable.HashMap[String,String]()
                    val fingerbldSet = new mutable.HashSet[String]()
                    val fingeraoiSet = new mutable.HashSet[String]()
                    val fingerdetailSet = new mutable.HashSet[String]()
                    splitFingerMap(finger_aoi,aoiSet)
                    splitFingerMap(finger_bld,buildMap)
                    splitFingerMap(finger_detail,fingerMap)
                    splitFingerList(finger_bld, fingerbldSet)
                    splitFingerList(finger_detail, fingerdetailSet)
                    var aoi_key=""
                    for(key<-aoiSet.keySet){
                        aoi_key=aoi_key+key+aoiSet.get(key).get

                    }
                    var bld_key=""
                    for(key<-buildMap.keySet){
                        bld_key=bld_key+key+buildMap.get(key).get

                    }

                    var finger_key=""
                    for(key<-fingerMap.keySet){
                        finger_key=finger_key+key+fingerMap.get(key).get

                    }
                    obj.fluentPutAll(leftObj)
                    obj.put("lng", leftObj.getString("lng"))
                    obj.put("lat", leftObj.getString("lat"))
//                    obj.put("reserve1", rightObj.getString("city_code"))
//                    obj.put("update_tag", rightObj.getString("update_tag"))
                    obj.put("finger_aoi", aoi_key)
//                    obj.put("finger_aoi", fingeraoiSet.mkString(""))
                    obj.put("finger_bld", fingerbldSet.mkString(""))
                    obj.put("finger_detail", fingerdetailSet.mkString(""))
                    if(StringUtils.nonEmpty(bld_key)&&bld_key.length>16){
                        obj.put("finger_bld", bld_key)
                        if(StringUtils.nonEmpty(finger_key)&&finger_key.length>16){
                            obj.put("finger_detail", finger_key)
                        }
                    }

                    obj.put("key", leftObj.getString("key"))
                } else {
                    obj.fluentPutAll(leftObjOp.get)

                }

            } else {
                obj.fluentPutAll(rightObjOp.get)
//                obj.put("reserve1", rightObjOp.get.getString("city_code"))

            }

            obj
        })

        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_index_dtl
              |
              |
              |""".stripMargin

        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
//                obj.put("update_tag", "1")

                if (leftObjOp.nonEmpty) {
                    if (rightObjOp.nonEmpty) {
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        val finger_aoi = leftObj.getString("finger_aoi") + rightObj.getString("finger_aoi")
                        val finger_bld = leftObj.getString("finger_bld") + rightObj.getString("finger_bld")
                        val finger_detail = leftObj.getString("finger_detail") + rightObj.getString("finger_detail")
                        val aoiSet = new mutable.HashMap[String,String]()
                        val buildMap = new mutable.HashMap[String,String]()
                        val fingerMap = new mutable.HashMap[String,String]()
                        val fingerbldSet = new mutable.HashSet[String]()
                        val fingeraoiSet = new mutable.HashSet[String]()
                        val fingerdetailSet = new mutable.HashSet[String]()
                        splitFingerMap(finger_aoi,aoiSet)
                        splitFingerMap(finger_bld,buildMap)
                        splitFingerMap(finger_detail,fingerMap)
                        splitFingerList(finger_bld, fingerbldSet)
                        splitFingerList(finger_detail, fingerdetailSet)
                        var aoi_key=""
                        for(key<-aoiSet.keySet){
                            aoi_key=aoi_key+key+aoiSet.get(key).get

                        }
                        var bld_key=""
                        for(key<-buildMap.keySet){
                            bld_key=bld_key+key+buildMap.get(key).get

                        }

                        var finger_key=""
                        for(key<-fingerMap.keySet){
                            finger_key=finger_key+key+fingerMap.get(key).get

                        }
                        obj.fluentPutAll(leftObj)
                        obj.put("lng", leftObj.getString("lng"))
                        obj.put("lat", leftObj.getString("lat"))
//                        obj.put("reserve1", rightObj.getString("city_code"))
//                        obj.put("update_tag", rightObj.getString("update_tag"))
                        obj.put("finger_aoi", aoi_key)
//                        obj.put("finger_aoi", fingeraoiSet.mkString(""))
                        obj.put("finger_bld", fingerbldSet.mkString(""))
                        obj.put("finger_detail", fingerdetailSet.mkString(""))
                        if(StringUtils.nonEmpty(bld_key)&&bld_key.length>16){
                            obj.put("finger_bld", bld_key)
                            if(StringUtils.nonEmpty(finger_key)&&finger_key.length>16){
                                obj.put("finger_detail", finger_key)
                            }
                        }
                        obj.put("key", leftObj.getString("key"))
                    } else {
                        obj.fluentPutAll(leftObjOp.get)

                    }

                } else {
                    obj.fluentPutAll(rightObjOp.get)
                }

                obj


            })





        }

        var sql_dept=
            s"""
               |
               |
               |select * from dm_gis.dm_wifi_finger_dept_index_nd
               |
               |""".stripMargin

        val deptRdd =SparkRead.readHiveAsJson(spark, sql_dept)._1.map(x=>(x.getString("key"),x))
        resultRdd=resultRdd.map(x=>(x.getString("key"),x)).fullOuterJoin(deptRdd).map(x=>{
            val leftObjOp = x._2._1
            val rightObjOp = x._2._2
            var obj = new JSONObject()
            //                obj.put("update_tag", "1")

            if (leftObjOp.nonEmpty) {
                if (rightObjOp.nonEmpty) {
                    val leftObj = leftObjOp.get
                    val rightObj = rightObjOp.get
                    val finger_aoi = leftObj.getString("finger_aoi") + rightObj.getString("finger_aoi")

                    val aoiSet = new mutable.HashMap[String,String]()
                    splitFingerMap(finger_aoi,aoiSet)
                    var aoi_key=""
                    for(key<-aoiSet.keySet){
                        aoi_key=aoi_key+key+aoiSet.get(key).get

                    }
                    obj.fluentPutAll(leftObj)
                    obj.put("lng", leftObj.getString("lng"))
                    obj.put("lat", leftObj.getString("lat"))
                    obj.put("finger_aoi", aoi_key)
                    obj.put("key", leftObj.getString("key"))
                } else {
                    obj.fluentPutAll(leftObjOp.get)

                }

            } else {
                obj.fluentPutAll(rightObjOp.get)
            }

            obj

        })




        resultRdd


    }

    def mergeAoi(spark:SparkSession,aoiWhiteMapBroad:Broadcast[Map[String, String]])={

        var sql=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_ap_aoi_sum
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val apDataRdd =SparkRead.readHiveAsJson(spark, sql)._1.map(obj=>(obj.getString("key"),obj))
        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_traj_aoi_dtl
              |
              |
              |
              |""".stripMargin

        val traceDataRdd =SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj=>(obj.getString("key"),obj))
        var resultRdd = apDataRdd.fullOuterJoin(traceDataRdd).map(x => {
            val aoiWhiteMap = aoiWhiteMapBroad.value
            val leftObjOp = x._2._1
            val rightObjOp = x._2._2
            var obj = new JSONObject()

            if (leftObjOp.nonEmpty) {
                obj.fluentPutAll(leftObjOp.get)
                if (rightObjOp.nonEmpty) {
                    val wifiMap = new mutable.HashMap[String, JSONObject]()
                    val leftObj = leftObjOp.get
                    val rightObj = rightObjOp.get
                    var wifiArr = new JSONArray()
                    var pointArr = new JSONArray()
                    var finger_list = leftObj.getString("finger_list")
                    var wifi = leftObj.getString("wifi_list")
                    var points = leftObj.getString("points")
                    val fingerSet = new mutable.HashSet[String]()
                    splitFingerList(finger_list, fingerSet)

                    var tracewifiArr = new JSONArray()
                    var tracepointArr = new JSONArray()
                    var tracefinger_list = rightObj.getString("finger_list")
                    var tracewifi = rightObj.getString("wifi_list")
                    var tracepoints = rightObj.getString("points")
                    val tracefingerSet = new mutable.HashSet[String]()
                    splitFingerList(tracefinger_list, fingerSet)
                    try {
                        wifiArr = JSON.parseArray(wifi)
                        pointArr = JSON.parseArray(points)
                        tracewifiArr = JSON.parseArray(tracewifi)
                        tracepointArr = JSON.parseArray(tracepoints)

                    } catch {
                        case e: Exception => {
                            logger.error(e.getMessage)

                        }
                    }

                    mergeWifiList(wifiArr, wifiMap, "0010")
                    mergeWifiList(tracewifiArr, wifiMap, "0110")
                    pointArr.fluentAddAll(tracepointArr)
                    val pointsAll = cleanPoints(pointArr.toString())
                    val wifiArrAll = new JSONArray()
                    for (wifi <- wifiMap.values) {
                        wifiArrAll.add(wifi)
                    }
                    obj.put("wifi_list", wifiArrAll.toString())
                    obj.put("finger_list", fingerSet.mkString(""))
                    obj.put("points", pointsAll)
//                    obj.put("reserve1", rightObj.getString("city_code"))


                }

            } else {
                obj.fluentPutAll(rightObjOp.get)
//                obj.put("reserve1", rightObjOp.get.getString("city_code"))

            }

            obj.put("reliable",aoiWhiteMap.getOrElse(obj.getString("aoi_id"),"0"))
            obj


        })


        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_aoi_dtl
              |
              |""".stripMargin
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val aoiWhiteMap = aoiWhiteMapBroad.value
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
                obj.put("update_tag", "1")

                if (leftObjOp.nonEmpty) {
                    obj.fluentPutAll(leftObjOp.get)
                    obj.put("update_tag", "1")
                    if (rightObjOp.nonEmpty) {
                        val wifiMap = new mutable.HashMap[String, JSONObject]()
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        var wifiArr = new JSONArray()
                        var pointArr = new JSONArray()
                        var finger_list = leftObj.getString("finger_list")
                        var wifi = leftObj.getString("wifi_list")
                        var points = leftObj.getString("points")
                        val fingerSet = new mutable.HashSet[String]()
                        splitFingerList(finger_list, fingerSet)

                        var tracewifiArr = new JSONArray()
                        var tracepointArr = new JSONArray()
                        var tracefinger_list = rightObj.getString("finger_list")
                        var tracewifi = rightObj.getString("wifi_list")
                        var tracepoints = rightObj.getString("points")
                        val tracefingerSet = new mutable.HashSet[String]()
                        splitFingerList(tracefinger_list, fingerSet)
                        try {
                            wifiArr = JSON.parseArray(wifi)
                            pointArr = JSON.parseArray(points)
                            tracewifiArr = JSON.parseArray(tracewifi)
                            tracepointArr = JSON.parseArray(tracepoints)

                        } catch {
                            case e: Exception => {
                                logger.error(e.getMessage)

                            }
                        }

                        mergeWifiList(wifiArr, wifiMap, "0110")
                        mergeWifiList(tracewifiArr, wifiMap, "1110")
                        pointArr.fluentAddAll(tracepointArr)
                        val pointsAll = cleanPoints(pointArr.toString())
                        val wifiArrAll = new JSONArray()
                        for (wifi <- wifiMap.values) {
                            wifiArrAll.add(wifi)
                        }
                        obj.put("wifi_list", wifiArrAll.toString())
                        obj.put("finger_list", fingerSet.mkString(""))
                        obj.put("points", pointsAll)



                    }

                } else {
                    obj.fluentPutAll(rightObjOp.get)



                }

                obj.put("reliable",aoiWhiteMap.getOrElse(obj.getString("aoi_id"),"0"))

                obj
            })




        }

        var sql_dept=
            s"""
              |
              |select * from dm_gis.dm_wifi_finger_dept_aoi_nd
              |
              |""".stripMargin
        val deptAoiRdd =SparkRead.readHiveAsJson(spark, sql_dept)._1
        resultRdd=resultRdd.union(deptAoiRdd)
        resultRdd
    }

    def cleanPoints(points:String): String ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        val pointSet = new mutable.HashSet[String]()
        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                pointSet.add(pointArr.getJSONObject(i).toString())

            }


            "["+pointSet.mkString(",")+"]"
        }else{
            ""
        }
    }
    def mergeWifiList(wifiArr:JSONArray,wifiMap:mutable.HashMap[String, JSONObject],source_num:String)={
        for (i <- 0 until wifiArr.size()) {
            val wifiObj = wifiArr.getJSONObject(i)
            val mac = wifiObj.getString("mac")
            if (wifiMap.contains(mac)) {
                val num = wifiObj.getString("num")
                val time = wifiObj.getString("time")
                val source = wifiObj.getString("source")
                val sig=wifiObj.getString("sig")
                val temObj = wifiMap.get(mac).get
                var num_t = temObj.getString("num")
                var time_t = temObj.getString("time")
                var source_t = temObj.getString("source")
                var sig_t = temObj.getString("sig")
                if (StringUtils.nonEmpty(num) && StringUtils.nonEmpty(time) && StringUtils.nonEmpty(source) && StringUtils.nonEmpty(num_t) && StringUtils.nonEmpty(time_t) && StringUtils.nonEmpty(source_t)&&StringUtils.nonEmpty(sig)&&StringUtils.nonEmpty(sig_t)) {
                    num_t = (num_t.toLong + num.toLong).toString
                    sig_t=((sig.toLong+sig_t.toLong)/2).toString
                    if (time.toLong > time_t.toLong) {
                        time_t = time
                    }

                    temObj.put("num", num_t)
                    temObj.put("time", time_t)
                    temObj.put("source", source_num)
                    temObj.put("sig", sig_t.toLong)
                }
                wifiMap.put(mac, temObj)
            } else {
                wifiMap.put(mac, wifiObj)
            }
        }



    }
    def mergeBuld(spark:SparkSession,bldWhiteMapBroad:Broadcast[Map[String, String]])={
        var sql=
            """
              |
              |
              |
              |select * from dm_gis.dm_wifi_finger_ap_building_sum
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val apDataRdd =SparkRead.readHiveAsJson(spark, sql)._1.map(obj=>(obj.getString("key"),obj))
        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_traj_bld_dtl
              |
              |
              |
              |""".stripMargin

        val traceDataRdd =SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj=>(obj.getString("key"),obj))
        var resultRdd = apDataRdd.fullOuterJoin(traceDataRdd).map(x => {
            val bldWhiteMap = bldWhiteMapBroad.value
            val leftObjOp = x._2._1
            val rightObjOp = x._2._2
            var obj = new JSONObject()
            if (leftObjOp.nonEmpty) {
                obj.fluentPutAll(leftObjOp.get)
//                obj.put("update_tag", "1")
                if (rightObjOp.nonEmpty) {

                    val wifiMap = new mutable.HashMap[String, JSONObject]()
                    val leftObj = leftObjOp.get
                    val rightObj = rightObjOp.get
                    var wifiArr = new JSONArray()
                    var pointArr = new JSONArray()
                    var upper_key = leftObj.getString("upper_key")
                    var finger_list = leftObj.getString("finger_list")
                    var wifi = leftObj.getString("wifi_list")
                    var points = leftObj.getString("points")
                    val fingerSet = new mutable.HashSet[String]()
                    val upperSet = new mutable.HashSet[String]()
                    splitFingerList(finger_list, fingerSet)
                    splitFingerList(upper_key, upperSet)

                    var tracewifiArr = new JSONArray()
                    var tracepointArr = new JSONArray()
                    var traceupper_key = rightObj.getString("upper_key")
                    var tracefinger_list = rightObj.getString("finger_list")
                    var tracewifi = rightObj.getString("wifi_list")
                    var tracepoints = rightObj.getString("points")

                    splitFingerList(tracefinger_list, fingerSet)
                    splitFingerList(traceupper_key, upperSet)
                    try {
                        wifiArr = JSON.parseArray(wifi)
                        pointArr = JSON.parseArray(points)
                        tracewifiArr = JSON.parseArray(tracewifi)
                        tracepointArr = JSON.parseArray(tracepoints)

                    } catch {
                        case e: Exception => {
                            logger.error(e.getMessage)

                        }
                    }

                    mergeWifiList(wifiArr, wifiMap, "0010")
                    mergeWifiList(tracewifiArr, wifiMap, "0110")
                    pointArr.fluentAddAll(tracepointArr)
                    val pointsAll = cleanPoints(pointArr.toString())
                    val wifiArrAll = new JSONArray()
                    for (wifi <- wifiMap.values) {
                        wifiArrAll.add(wifi)
                    }
                    obj.put("wifi_list", wifiArrAll.toString())
                    obj.put("upper_key", upperSet.mkString(""))
                    obj.put("finger_list", fingerSet.mkString(""))
                    obj.put("points", pointsAll)
//                    obj.put("reserve1", rightObj.getString("city_code"))


                }

            } else {
                obj.fluentPutAll(rightObjOp.get)
//                obj.put("reserve1", rightObjOp.get.getString("city_code"))

            }
            obj.put("reliable",bldWhiteMap.getOrElse(obj.getString("buildingid"),"0"))
            obj

        })
      //resultRdd.take(2).foreach(println(_))

        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_building_dtl
              |
              |""".stripMargin
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val bldWhiteMap = bldWhiteMapBroad.value
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
                if (leftObjOp.nonEmpty) {
                    obj.fluentPutAll(leftObjOp.get)
//                    obj.put("update_tag", "1")
                    if (rightObjOp.nonEmpty) {

                        val wifiMap = new mutable.HashMap[String, JSONObject]()
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        var wifiArr = new JSONArray()
                        var pointArr = new JSONArray()
                        var upper_key = leftObj.getString("upper_key")
                        var finger_list = leftObj.getString("finger_list")
                        var wifi = leftObj.getString("wifi_list")
                        var points = leftObj.getString("points")
                        val fingerSet = new mutable.HashSet[String]()
                        val upperSet = new mutable.HashSet[String]()
                        splitFingerList(finger_list, fingerSet)
                        splitFingerList(upper_key, upperSet)

                        var tracewifiArr = new JSONArray()
                        var tracepointArr = new JSONArray()
                        var traceupper_key = rightObj.getString("upper_key")
                        var tracefinger_list = rightObj.getString("finger_list")
                        var tracewifi = rightObj.getString("wifi_list")
                        var tracepoints = rightObj.getString("points")

                        splitFingerList(tracefinger_list, fingerSet)
                        splitFingerList(traceupper_key, upperSet)
                        try {
                            wifiArr = JSON.parseArray(wifi)
                            pointArr = JSON.parseArray(points)
                            tracewifiArr = JSON.parseArray(tracewifi)
                            tracepointArr = JSON.parseArray(tracepoints)

                        } catch {
                            case e: Exception => {
                                logger.error(e.getMessage)

                            }
                        }

                        mergeWifiList(wifiArr, wifiMap, "0110")
                        mergeWifiList(tracewifiArr, wifiMap, "1110")
                        pointArr.fluentAddAll(tracepointArr)
                        val pointsAll = cleanPoints(pointArr.toString())
                        val wifiArrAll = new JSONArray()
                        for (wifi <- wifiMap.values) {
                            wifiArrAll.add(wifi)
                        }
                        obj.put("wifi_list", wifiArrAll.toString())
                        obj.put("upper_key", upperSet.mkString(""))
                        obj.put("finger_list", fingerSet.mkString(""))
                        obj.put("points", pointsAll)



                    }

                } else {
                    obj.fluentPutAll(rightObjOp.get)


                }
                obj.put("reliable",bldWhiteMap.getOrElse(obj.getString("buildingid"),"0"))

                obj
            })


        }
      //resultRdd.take(2).foreach(println(_))

        resultRdd


    }

    def mergeDetail(spark:SparkSession)={

        var sql_trace=
            """
              |
              |
              |select * from dm_gis.dm_wifi_finger_traj_detail_dtl
              |
              |
              |
              |""".stripMargin

        var resultRdd = SparkRead.readHiveAsJson(spark, sql_trace)._1.map(obj => {
//            obj.put("reserve1", obj.getString("city_code"))
            obj


        })
        var sql_collect=
            """
              |
              |select * from dm_gis.dm_wifi_finger_collect_detail_dtl
              |
              |""".stripMargin
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql_collect)
        if(dataRdd.count()>1){
            val collectDataRdd =dataRdd.map(obj=>(obj.getString("key"),obj))
            resultRdd = resultRdd.map(obj => (obj.getString("key"), obj)).fullOuterJoin(collectDataRdd).map(x => {
                val leftObjOp = x._2._1
                val rightObjOp = x._2._2
                var obj = new JSONObject()
//                obj.put("update_tag", "1")

                if (leftObjOp.nonEmpty) {
                    obj.fluentPutAll(leftObjOp.get)
//                    obj.put("update_tag", "1")
                    if (rightObjOp.nonEmpty) {

                        val wifiMap = new mutable.HashMap[String, JSONObject]()
                        val leftObj = leftObjOp.get
                        val rightObj = rightObjOp.get
                        var wifiArr = new JSONArray()
                        var pointArr = new JSONArray()
                        var upper_key = leftObj.getString("upper_key")
                        var wifi = leftObj.getString("wifi_list")
                        var points = leftObj.getString("points")
                        val upperSet = new mutable.HashSet[String]()
                        splitFingerList(upper_key, upperSet)

                        var tracewifiArr = new JSONArray()
                        var tracepointArr = new JSONArray()
                        var traceupper_key = rightObj.getString("upper_key")
                        var tracewifi = rightObj.getString("wifi_list")
                        var tracepoints = rightObj.getString("points")

                        splitFingerList(traceupper_key, upperSet)
                        try {
                            wifiArr = JSON.parseArray(wifi)
                            pointArr = JSON.parseArray(points)
                            tracewifiArr = JSON.parseArray(tracewifi)
                            tracepointArr = JSON.parseArray(tracepoints)

                        } catch {
                            case e: Exception => {
                                logger.error(e.getMessage)

                            }
                        }

                        mergeWifiList(wifiArr, wifiMap, "0100")
                        mergeWifiList(tracewifiArr, wifiMap, "1100")
                        pointArr.fluentAddAll(tracepointArr)
                        val pointsAll = cleanPoints(pointArr.toString())
                        val (lng,lat) = calcCenterPoint(pointsAll)
                        val wifiArrAll = new JSONArray()
                        for (wifi <- wifiMap.values) {
                            wifiArrAll.add(wifi)
                        }
                        obj.put("lon",lng)
                        obj.put("lat",lat)
                        obj.put("wifi_list", wifiArrAll.toString())
                        obj.put("upper_key", upperSet.mkString(""))
                        obj.put("points", pointsAll)



                    }

                } else {
                    obj.fluentPutAll(rightObjOp.get)
                }

                obj
            })


        }

        resultRdd



    }

    def calcCenterPoint(points:String): (Double, Double) ={
        var pointArr=try{
            JSON.parseArray(points)
        }catch {case e:Exception=>
            logger.error(e.getMessage)
            new JSONArray()
        }
        var lngAll=0.0
        var latAll=0.0
        var cnt=0L

        if(pointArr.size()>0){
            for(i<-0 until pointArr.size()){
                val pointObj = pointArr.getJSONObject(i)
                lngAll+=pointObj.getString("x").toDouble
                latAll+=pointObj.getString("y").toDouble
                cnt+=1
            }
        }

        (lngAll/cnt,latAll/cnt)

    }

    def splitFingerMap(fingerList:String,fingerMap:mutable.HashMap[String,String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/16){
                    val finger_aoi = fingerList.substring(i * 19, (i + 1) * 19)
                    if(fingerMap.contains(finger_aoi.substring(0,16))){
                        val avg_ss = fingerMap.get(finger_aoi.substring(0, 16)).get
                        val ewl_dis = finger_aoi.substring(16)

                        fingerMap.put(finger_aoi.substring(0,16),(math.round((avg_ss.toLong+Math.abs(ewl_dis.toDouble))/2)+1000).toString.substring(1))

                    }else{
                        fingerMap.put(finger_aoi.substring(0,16),finger_aoi.substring(16))

                    }
                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def splitFingerList(fingerList:String,fingerSet:mutable.HashSet[String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/16){
                    fingerSet.add(fingerList.substring(i*16,(i+1)*16))

                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }

    def getFingerWhite(spark:SparkSession)={
        var sql=
            """
              |
              |
              |select guid,`level`,in_use,reserve1 from (
              |select guid,`level`,in_use,reserve1,row_number()over(partition by guid,`level` order by update_date desc ) rnk from dm_gis.gis_wifi_finger_white_list where in_use = '1'
              |
              |) t
              |where t.rnk=1
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("aoi")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //aoiWhiteMap.take(10).foreach(println(_))



        val bldWhiteMap = dataRdd.filter(obj => StringUtils.nonEmpty(obj.getString("level")) && obj.getString("level").equals("bld")).map(obj => {
            val guid = obj.getString("guid")
            //val in_use = obj.getString("in_use")
            val in_use = obj.getString("reserve1")
            (guid, in_use)
        }).collect().toMap

        //bldWhiteMap.take(10).foreach(println(_))
        (spark.sparkContext.broadcast(aoiWhiteMap),spark.sparkContext.broadcast(bldWhiteMap))



    }


}
