package com.sf.gis.scala.nloc.app

import java.lang.Math.{asin, cos, sin, sqrt}
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01394382 张萍
 * @Author: 01374443 张想远 (单天赐代码改造)
 * @CreateTime: 2023-03-03 14:06
 * @TaskId:436041
 * @TaskName:LssCellWcdmaMonth
 * @Description: 基站类数据统计
 */
object LssCore {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val format = FastDateFormat.getInstance("yyyyMMdd")
  var partition = 3

  val cell_cdma_table = "dm_gis.gis_lss_core_cell_cdma"
  val cell_gsm_table = "dm_gis.gis_lss_core_cell_gsm"
  val cell_wcdma_table = "dm_gis.gis_lss_core_cell_wcdma"
  val cell_lte_table = "dm_gis.gis_lss_core_cell_lte"
  val cell_nr_table = "dm_gis.gis_lss_core_cell_nr"
  val suffix = "_grouped"

  var _Dis: java.lang.Double = 5000.0

  def main(args: Array[String]): Unit = {
    val date = args(0)
    val mode = args(1)
    _Dis = args(2).toDouble
    if (_Dis != null && !StringUtils.isEmpty(mode) && "wifi,cdma,gsm,wcdma,lte,nr".split(",").contains(mode)) {

      val sparkSession = Spark.getSparkSession(appName)
      logger.error(">>>处理类型：" + mode)
      logger.error(">>>距离参数：" + _Dis)
      var year = date.substring(0, 4)
      val calendar = Calendar.getInstance()
      calendar.setTime(format.parse(date))
      calendar.add(Calendar.DAY_OF_MONTH, 1)
      val runDate = format.format(calendar.getTime)
      var month = runDate.substring(4, 6).toInt - 1
      if (month == 0) {
        year = (year.toInt - 1).toString
        month = 12
      }
      statMonth(sparkSession, _Dis, year, month.toString, getTableName(mode), mode)

      //      StatMonths(blockingFactory, dataF, computeF, _Dis, table, structs, keys)
      logger.error(">>>处理完毕---------------")
    }

  }

  def getTableName(mode: String) = {
    mode match {
      case "cdma" => cell_cdma_table
      case "gsm" => cell_gsm_table
      case "wcdma" => cell_wcdma_table
      case "lte" => cell_lte_table
      case "nr" => cell_nr_table
    }
  }

  //  def StatMonths(blockingFactory:BlockingFactory, getData:Data, computeData:compute, Dis:java.lang.Double, table:String, structs:Array[String], keys:Array[String]): Unit = {
  //    val year = "2022"
  //    val start_month = 1
  //    val end_month = 4
  //    for(i<-start_month.until(end_month + 1)){
  //      StatMonth(blockingFactory, getData, computeData, Dis, year, i.toString, table, structs, keys)
  //    }
  //  }


  def statMonth(sparkSession: SparkSession, Dis: java.lang.Double, year: String,
                month: String, table: String, mode: String): Unit = {
    val (startDate, endDate) = getMonthDate(year, month)
    val result_table = table + "_range_month"
    logger.error(">>>开始处理 " + month + " 月的 " + table + " 范围：" + startDate + " - " + endDate)
    val groupedRdd = getData(sparkSession, startDate, endDate, table,mode)
    val resultRdd = computeData(groupedRdd, Dis)
    val structs = getStructs(mode)
    filterRddToHive(sparkSession, resultRdd, result_table, structs, startDate, getSavePartition(mode))
    resultRdd.unpersist()
  }

  def getStructs(mode: String) = {
    mode match {
      case "cdma" => Array("asulevel", "level", "nid", "tp", "dbm", "sid", "mevdosnr", "carriername", "mevdodbm", "mevdoecio", "bid", "mcdmadbm", "mcdmaecio", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "number", "size", "dismax", "dismin")
      case "gsm" => Array("mnc", "asulevel", "level", "bsic", "tp", "mcc", "arfcn", "dbm", "lac", "carriername", "cid", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "number", "size", "dismax", "dismin")
      case "wcdma" => Array("psc", "mnc", "asulevel", "level", "tp", "mcc", "dbm", "lac", "carriername", "uarfcn", "cid", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "number", "size", "dismax", "dismin")
      case "lte" => Array("mnc", "asulevel", "level", "ci", "tp", "mcc", "dbm", "carriername", "tac", "pci", "earfcn", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "number", "size", "dismax", "dismin")
      case "nr" => Array("sssinr", "asulevel", "level", "csisinr", "ssrsrp", "tp", "csirsrp", "csirsrq", "dbm", "carriername", "nci", "tac", "pci", "ssrsrq", "nrarfcn", "timestamp", "register", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "id", "rtime", "mnc", "mcc", "number", "size", "dismax", "dismin")
    }
  }

  val array1 = Array("2147483647", "268435455", "65535")
  val array2 = Array("0", "-1")

  def getData(sparkSession: SparkSession, startDate: String, endDate: String,
              table: String,mode:String) = {
    var sql = ""
    sql =
      s"""
         |select * from $table$suffix where inc_day between '$startDate' and '$endDate'
       """.stripMargin
    val logRdd = getValidJson(sparkSession, sql)
    val groupedRdd = logRdd.map(json => {
      var id = json.getString("new_id")

      mode match {
        case "wifi" =>
          val bssid = json.getString("bssid")
          if (StringUtils.isEmpty(bssid)) id = ""
          else if (array1.contains(bssid)) id = ""
        case "cdma" =>
          var sid = json.getString("sid")
          var nid = json.getString("nid")
          var bid = json.getString("bid")
          if (array1.contains(sid)) id = ""
          else if (array1.contains(nid)) id = ""
          else if (array1.contains(bid)) id = ""
          else if ("0".equalsIgnoreCase(nid) && array2.contains(bid)) id = ""
        case "gsm" =>
          var mcc = json.getString("mcc")
          var mnc = json.getString("mnc")
          var lac = json.getString("lac")
          var cid = json.getString("cid")
          if (array1.contains(mcc)) id = ""
          else if (array1.contains(mnc)) id = ""
          else if (array1.contains(lac)) id = ""
          else if (array1.contains(cid)) id = ""
          else if ("0".equalsIgnoreCase(lac) && array2.contains(cid)) id = ""
        case "wcdma" =>
          var mcc = json.getString("mcc")
          var mnc = json.getString("mnc")
          var lac = json.getString("lac")
          var cid = json.getString("cid")
          if (array1.contains(mcc)) id = ""
          else if (array1.contains(mnc)) id = ""
          else if (array1.contains(lac)) id = ""
          else if (array1.contains(cid)) id = ""
          else if ("0".equalsIgnoreCase(lac) && array2.contains(cid)) id = ""
        case "lte" =>
          var mcc = json.getString("mcc")
          var mnc = json.getString("mnc")
          var tac = json.getString("tac")
          var ci = json.getString("ci")
          if (array1.contains(mcc)) id = ""
          else if (array1.contains(mnc)) id = ""
          else if (array1.contains(tac)) id = ""
          else if (array1.contains(ci)) id = ""
          else if ("0".equalsIgnoreCase(tac) && array2.contains(ci)) id = ""
        case "nr" =>
          var mcc = json.getString("mcc")
          var mnc = json.getString("mnc")
          var tac = json.getString("tac")
          var nci = json.getString("nci")
          if (array1.contains(mcc)) id = ""
          else if (array1.contains(mnc)) id = ""
          else if (array1.contains(tac)) id = ""
          else if (array1.contains(nci)) id = ""
          else if ("0".equalsIgnoreCase(tac) && array2.contains(nci)) id = ""
      }

      (id, json)
    }).filter(obj => !StringUtils.isEmpty(obj._1))
      .groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>日志量：" + groupedRdd.count())
    logRdd.unpersist()
    groupedRdd
  }


  def computeData(groupedRdd: RDD[(String, scala.Iterable[JSONObject])], Dis: java.lang.Double) = {
    val resultRdd = groupedRdd
      .flatMap(obj => {
        var list = new ArrayBuffer[ArrayBuffer[(java.lang.Double, java.lang.Double)]]()

        val jsonArray = obj._2.toList.sortBy(j => j.getString("timestamp")).reverse
        val firstJson = jsonArray.head
        val xys = new ArrayBuffer[(java.lang.Double, java.lang.Double)]()
        if (jsonArray.nonEmpty) {
          for (i <- jsonArray.indices) {
            val json = jsonArray(i)
            if (json != null) {
              val tmpxys = json.getJSONArray("xys")
              if (tmpxys != null && tmpxys.size() > 0) {
                for (m <- 0.until(tmpxys.size())) {
                  val tmpxy = tmpxys.getJSONArray(m)
                  if (tmpxy != null && tmpxy.size() > 1) {
                    val x = tmpxy.getDouble(0)
                    val y = tmpxy.getDouble(1)
                    if (x != null && y != null) {
                      val xy = (x, y)
                      xys += xy
                    }
                  }
                }
              }
            }
          }
        }

        if (xys.nonEmpty) {
          for (i <- xys.indices) {
            val (x, y) = xys(i)
            if (x != null && y != null) {
              var flag = false
              var first_index = -1
              if (list.nonEmpty) {
                for (j <- list.indices) {
                  val temp_list = list(j)
                  if (temp_list.nonEmpty) {
                    breakable(
                      for (m <- temp_list.indices) {
                        val (x0, y0) = temp_list(m)
                        if (x0 != null && y0 != null) {
                          val dis = getDistance(x, y, x0, y0)
                          if (dis != null && dis <= Dis) {
                            if (flag) {
                              for (n <- temp_list.indices) {
                                list(first_index) += temp_list(n)
                              }
                              list(j) = new ArrayBuffer[(java.lang.Double, java.lang.Double)]()
                            }
                            else {
                              flag = true
                              first_index = j
                              val xy = (x, y)
                              temp_list += xy
                            }
                            break
                          }
                        }
                      }
                    )
                  }
                }
              }

              if (!flag) {
                val new_list = new ArrayBuffer[(java.lang.Double, java.lang.Double)]()
                val xy = (x, y)
                new_list += xy
                list += new_list
              }
            }
          }
        }

        val result_list = new ArrayBuffer[JSONObject]()
        list = list.filter(l => l.nonEmpty && l.size > 1)
        val count = list.size
        if (list.nonEmpty) {
          for (q <- list.indices) {
            val temp_list = list(q)
            if (temp_list != null && temp_list.size > 1) {
              val tempJson = new JSONObject()
              tempJson.fluentPutAll(firstJson)
              tempJson.remove("xys")
              var avg_x = ""
              var avg_y = ""
              var number = count.toString + "_" + (q + 1).toString

              var sum_x: java.lang.Double = null
              var sum_y: java.lang.Double = null
              sum_x = temp_list.map(_._1).filter(_ != null).map(_.toDouble).sum
              sum_y = temp_list.map(_._2).filter(_ != null).map(_.toDouble).sum
              if (sum_x != null) avg_x = (sum_x / temp_list.size).toString
              if (sum_y != null) avg_y = (sum_y / temp_list.size).toString

              tempJson.put("x", avg_x)
              tempJson.put("y", avg_y)
              tempJson.put("number", number)
              tempJson.put("size", temp_list.size)
              result_list += tempJson
            }
          }
        }

        if (result_list.nonEmpty) {
          for (p <- result_list.indices) {
            val tempJson = result_list(p)
            if (tempJson != null) {
              var dismax: java.lang.Double = null
              var dismin: java.lang.Double = null
              val x = tempJson.getDouble("x")
              val y = tempJson.getDouble("y")
              if (x != null && y != null) {
                for (q <- result_list.indices) {
                  if (p != q) {
                    val tempJson2 = result_list(q)
                    if (tempJson2 != null) {
                      val x2 = tempJson2.getDouble("x")
                      val y2 = tempJson2.getDouble("y")
                      if (x2 != null && y2 != null) {
                        val dis = getDistance(x, y, x2, y2)
                        if (dis != null) {
                          if (dismax == null || dis > dismax) dismax = dis
                          if (dismin == null || dis < dismin) dismin = dis
                        }
                      }
                    }
                  }
                }
              }
              if (dismax != null) tempJson.put("dismax", dismax)
              if (dismin != null) tempJson.put("dismin", dismin)
            }
          }
        }

        result_list
      }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    groupedRdd.unpersist()
    logger.error(">>>日志量：" + resultRdd.count())
    resultRdd
  }


  def getMonthDate(year: String, i: String): (String, String) = {
    var startDate = ""
    var endDate = ""
    var year_month = ""
    if (i.length == 1) year_month = year + "0" + i
    else year_month = year + i
    startDate = year_month + "01"

    val calendar = Calendar.getInstance()
    calendar.setTime(format.parse(startDate))
    calendar.add(Calendar.MONTH, 1)
    calendar.add(Calendar.DAY_OF_MONTH, -1)
    endDate = format.format(calendar.getTime)

    (startDate, endDate)
  }


  def getValidJson(sparkSession: SparkSession, sql: String) = {
    logger.error("sql=" + sql)
    val df = sparkSession.sql(sql)
    val fields = df.schema.fields
    val header = new Array[String](fields.length)
    for (i <- fields.indices) {
      val name = fields(i).name
      header(i) = name
    }
    val logRdd = df.na.fill("").rdd.map(row => {
      val json = new JSONObject()
      for (i <- fields.indices) {
        json.put(header(i), row.get(i))
      }
      json
    }).filter(_ != null).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error(">>>日志量：" + logRdd.count())
    logRdd
  }


  def filterRddToHive(sparkSession: SparkSession, resultRdd: RDD[JSONObject], table: String,
                      structs: Array[String], date: String, partitionNum: Int): Unit = {
    logger.error(s"写入表：${table}")
    SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, structs, table,
      Array(("inc_day", date)), partitionNum)
  }

  def getSavePartition(mode: String) = {
    mode match {
      case "cdma" => 3
      case "gsm" => 6
      case "wcdma" => 3
      case "lte" => 20
      case "nr" => 3
    }
  }

  def radians(d: Double): Double = d * Math.PI / 180.0


  def getDistanceFrom2LngLat(lng1: Double, lat1: Double, lng2: Double, lat2: Double): Double = { //将角度转化为弧度
    val radLng1 = radians(lng1)
    val radLat1 = radians(lat1)
    val radLng2 = radians(lng2)
    val radLat2 = radians(lat2)
    val a = radLat1 - radLat2
    val b = radLng1 - radLng2
    2 * asin(sqrt(sin(a / 2) * sin(a / 2) + cos(radLat1) * cos(radLat2) * sin(b / 2) * sin(b / 2))) * 6378.137
  }


  def getDistanceByJson(json1: JSONObject, json2: JSONObject): java.lang.Double = {
    var dis: java.lang.Double = null
    try {
      val x1 = json1.getDouble("x")
      val y1 = json1.getDouble("y")
      val x2 = json2.getDouble("x")
      val y2 = json2.getDouble("y")
      if (x1 == null || y1 == null || x2 == null || y2 == null) dis = null
      else dis = getDistanceFrom2LngLat(x1, y1, x2, y2) * 1000
    }
    catch {
      case e =>
    }
    dis
  }


  def getDistance(x1: java.lang.Double, y1: java.lang.Double, x2: java.lang.Double, y2: java.lang.Double): java.lang.Double = {
    var dis: java.lang.Double = null
    try {
      if (x1 == null || y1 == null || x2 == null || y2 == null) dis = null
      else dis = getDistanceFrom2LngLat(x1, y1, x2, y2) * 1000
    }
    catch {
      case e =>
    }
    dis
  }


}
