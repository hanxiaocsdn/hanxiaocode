package com.sf.gis.scala.nloc.app

import java.lang.Math.{asin, cos, sin, sqrt}
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import org.apache.commons.lang3.StringUtils
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}
/**
 * @ProductManager:01394382 张萍
 * @Author: 01374443 张想远 (单天赐代码改造)
 * @CreateTime: 2023-04-04
 * @TaskId:435709
 * @TaskName:LssWifiMonth
 * @Description: 基站类数据统计 wifi
 */
object LssCoreWifiMonth {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  //  val format = FastDateFormat.getInstance("yyyyMMdd")
  var partition = 100

  val wifi_table = "dm_gis.gis_lss_core_wifi"

  var _Dis: java.lang.Double = 100.0

  def main(args: Array[String]): Unit = {
    val date = args(0)
    val mode = args(1)
    _Dis = args(2).toDouble
    if (_Dis != null && !StringUtils.isEmpty(mode) && "wifi".split(",").contains(mode)) {

      //          structs = Array("timestamp","rssi","bssid","channel","connectstate","band","ssid","ac","be","ad","x","y","tm","sl","sp","os","v","id","m","rtime","number","size","dismax","dismin")

      logger.error(">>>处理类型：" + mode)
      logger.error(">>>距离参数：" + _Dis)

      var year = date.substring(0, 4)
      val calendar = Calendar.getInstance()
      val format = FastDateFormat.getInstance("yyyyMMdd")
      calendar.setTime(format.parse(date))
      calendar.add(Calendar.DAY_OF_MONTH, 1)
      val runDate = format.format(calendar.getTime)
      var month = runDate.substring(4, 6).toInt - 1
      if (month == 0) {
        year = (year.toInt - 1).toString
        month = 12
      }
      statMonth(_Dis, year, month.toString)

      logger.error(">>>处理完毕---------------")
    }

  }

  def statMonth(Dis: java.lang.Double, year: String, month: String): Unit = {
    val (startDate, endDate) = getMonthDate(year, month)

    logger.error(">>>开始处理 " + month + " 月的 " + wifi_table + " 范围：" + startDate + " - " + endDate)
    val sparkSession = Spark.getSparkSession(appName)
    val groupedRdd = getData(sparkSession, startDate, startDate, wifi_table)
    val resultRdd = computeData(groupedRdd, Dis)

    filterRddToHive(sparkSession, resultRdd, startDate)
//    resultRdd.unpersist()
  }


  val array1 = Array("2147483647", "268435455", "65535")

  def getData(sparkSession: SparkSession, startDate: String, endDate: String, table: String) = {
    var sql = ""
    sql =
      s"""
         |select t1.new_id,t1.xys,t2.timestamp,t2.rssi,t2.bssid,t2.channel,t2.connectstate,t2.band,t2.ssid,t2.ac,t2.be,t2.ad,t2.x,t2.y,t2.tm,t2.sl,t2.sp,t2.os,t2.v,t2.id,t2.m,t2.rtime from
         |(select a.new_id,a.xys from
         |(select * from dm_gis.gis_lss_core_wifi_grouped_xy_month where inc_day='$startDate') a
         |left join (select distinct(new_id) from dm_gis.gis_lss_core_wifi_newid_blacklist) b on a.new_id=b.new_id where b.new_id is null) t1
         |left join (select * from dm_gis.gis_lss_core_wifi_grouped_newid_month where inc_day='$startDate') t2 on t1.new_id=t2.new_id
       """.stripMargin
    logger.error(sql)
    val df = sparkSession.sql(sql)
    val columns = df.columns
    logger.error("列名:" + columns.mkString(","))
    val logRdd = df.rdd.map(obj => {
      val jObj = new JSONObject()
      for (i <- columns.indices) {
        jObj.put(columns(i), obj.getString(i))
      }
      jObj
    })
//      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val (logRdd, columns) = SparkRead.readHiveAsJson(sparkSession, sql, -1)
    logRdd
  }


  def computeData(groupedRdd: RDD[JSONObject], Dis: java.lang.Double) = {
    val resultRdd = groupedRdd
      .flatMap(json => {
        var list = new ArrayBuffer[ArrayBuffer[(java.lang.Double, java.lang.Double, java.lang.Integer)]]()

        val xys = new ArrayBuffer[(java.lang.Double, java.lang.Double, java.lang.Integer)]()
        val xys_str = json.getString("xys")
        if (!StringUtils.isEmpty(xys_str)) {
          val xy_list = xys_str.split(";")
          if (xy_list != null && xy_list.nonEmpty) {
            for (xyc <- xy_list) {
              if (!StringUtils.isEmpty(xyc)) {
                val xyc_list = xyc.split(":")
                if (xyc_list != null && xyc_list.size > 1) {
                  val xy = xyc_list(0)
                  val count = xyc_list(1)
                  if (!StringUtils.isEmpty(xy)) {
                    val x_y = xy.replaceAll("\\[", "").replaceAll("]", "").split(",")
                    if (x_y != null && x_y.size > 1) {
                      val x = x_y(0)
                      val y = x_y(1)
                      val temp = (java.lang.Double.valueOf(x), java.lang.Double.valueOf(y), java.lang.Integer.valueOf(count))
                      xys += temp
                    }
                  }
                }
              }
            }
          }
        }
        json.remove("xys")
        if (xys.nonEmpty) {
          for (i <- xys.indices) {
            val (x, y, count) = xys(i)
            if (x != null && y != null) {
              var flag = false
              var first_index = -1
              if (list.nonEmpty) {
                for (j <- list.indices) {
                  val temp_list = list(j)
                  if (temp_list.nonEmpty) {
                    breakable(
                      for (m <- temp_list.indices) {
                        val (x0, y0, count0) = temp_list(m)
                        if (x0 != null && y0 != null) {
                          val dis = getDistance(x, y, x0, y0)
                          if (dis != null && dis <= Dis) {
                            if (flag) {
                              for (n <- temp_list.indices) {
                                list(first_index) += temp_list(n)
                              }
                              list(j) = new ArrayBuffer[(java.lang.Double, java.lang.Double, java.lang.Integer)]()
                            }
                            else {
                              flag = true
                              first_index = j
                              val xy = (x, y, count)
                              temp_list += xy
                            }
                            break
                          }
                        }
                      }
                    )
                  }
                }
              }

              if (!flag) {
                val new_list = new ArrayBuffer[(java.lang.Double, java.lang.Double, java.lang.Integer)]()
                val xy = (x, y, count)
                new_list += xy
                list += new_list
              }
            }
          }
        }

        val result_list = new ArrayBuffer[JSONObject]()
        list = list.filter(l => l.nonEmpty && l.size > 1)
        val count = list.size
        if (list.nonEmpty) {
          for (q <- list.indices) {
            val temp_list = list(q)
            if (temp_list != null && temp_list.size > 1) {
              val tempJson = new JSONObject()
              tempJson.fluentPutAll(json)
              var avg_x = ""
              var avg_y = ""
              var number = count.toString + "_" + (q + 1).toString

              var sum_x: java.lang.Double = null
              var sum_y: java.lang.Double = null
              var sum: java.lang.Integer = null
              sum_x = temp_list.map(x => x._1 * x._3).filter(_ != null).map(_.toDouble).sum
              sum_y = temp_list.map(y => y._2 * y._3).filter(_ != null).map(_.toDouble).sum
              sum = temp_list.map(f => f._3).filter(_ != null).map(_.toInt).sum
              if (sum_x != null) avg_x = (sum_x / sum).toString
              if (sum_y != null) avg_y = (sum_y / sum).toString

              tempJson.put("x", avg_x)
              tempJson.put("y", avg_y)
              tempJson.put("number", number)
              tempJson.put("size", temp_list.size)
              result_list += tempJson
            }
          }
        }

        if (result_list.nonEmpty) {
          for (p <- result_list.indices) {
            val tempJson = result_list(p)
            if (tempJson != null) {
              var dismax: java.lang.Double = null
              var dismin: java.lang.Double = null
              val x = tempJson.getDouble("x")
              val y = tempJson.getDouble("y")
              if (x != null && y != null) {
                for (q <- result_list.indices) {
                  if (p != q) {
                    val tempJson2 = result_list(q)
                    if (tempJson2 != null) {
                      val x2 = tempJson2.getDouble("x")
                      val y2 = tempJson2.getDouble("y")
                      if (x2 != null && y2 != null) {
                        val dis = getDistance(x, y, x2, y2)
                        if (dis != null) {
                          if (dismax == null || dis > dismax) dismax = dis
                          if (dismin == null || dis < dismin) dismin = dis
                        }
                      }
                    }
                  }
                }
              }
              if (dismax != null) tempJson.put("dismax", dismax)
              if (dismin != null) tempJson.put("dismin", dismin)
            }
          }
        }
        result_list
      })
//      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error(">>>日志量：" + resultRdd.count())
//    groupedRdd.unpersist()
    resultRdd
  }


  def getMonthDate(year: String, i: String): (String, String) = {
    var startDate = ""
    var endDate = ""
    var year_month = ""
    if (i.length == 1) year_month = year + "0" + i
    else year_month = year + i
    startDate = year_month + "01"

    val calendar = Calendar.getInstance()
    val format = FastDateFormat.getInstance("yyyyMMdd")
    calendar.setTime(format.parse(startDate))
    calendar.add(Calendar.MONTH, 1)
    calendar.add(Calendar.DAY_OF_MONTH, -1)
    endDate = format.format(calendar.getTime)

    (startDate, endDate)
  }

  def filterRddToHive(sparkSession: SparkSession, resultRdd: RDD[JSONObject], date: String): Unit = {
    val structs = Array("timestamp", "rssi", "bssid", "channel", "connectstate", "band", "ssid", "ac", "be", "ad", "x", "y", "tm", "sl", "sp", "os", "v", "id", "m", "rtime", "number", "size", "dismax", "dismin")
    val result_table = wifi_table + "_range_month"
    SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, structs,result_table , Array(("inc_day", date)),900)
  }


  def radians(d: Double): Double = d * Math.PI / 180.0


  def getDistanceFrom2LngLat(lng1: Double, lat1: Double, lng2: Double, lat2: Double): Double = { //将角度转化为弧度
    val radLng1 = radians(lng1)
    val radLat1 = radians(lat1)
    val radLng2 = radians(lng2)
    val radLat2 = radians(lat2)
    val a = radLat1 - radLat2
    val b = radLng1 - radLng2
    2 * asin(sqrt(sin(a / 2) * sin(a / 2) + cos(radLat1) * cos(radLat2) * sin(b / 2) * sin(b / 2))) * 6378.137
  }


  def getDistanceByJson(json1: JSONObject, json2: JSONObject): java.lang.Double = {
    var dis: java.lang.Double = null
    try {
      val x1 = json1.getDouble("x")
      val y1 = json1.getDouble("y")
      val x2 = json2.getDouble("x")
      val y2 = json2.getDouble("y")
      if (x1 == null || y1 == null || x2 == null || y2 == null) dis = null
      else dis = getDistanceFrom2LngLat(x1, y1, x2, y2) * 1000
    }
    catch {
      case e =>
    }
    dis
  }


  def getDistance(x1: java.lang.Double, y1: java.lang.Double, x2: java.lang.Double, y2: java.lang.Double): java.lang.Double = {
    var dis: java.lang.Double = null
    try {
      if (x1 == null || y1 == null || x2 == null || y2 == null) dis = null
      else dis = getDistanceFrom2LngLat(x1, y1, x2, y2) * 1000
    }
    catch {
      case e =>
    }
    dis
  }


}
