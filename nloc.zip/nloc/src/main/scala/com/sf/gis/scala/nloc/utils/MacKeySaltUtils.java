package com.sf.gis.scala.nloc.utils;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;

public class MacKeySaltUtils implements Serializable {

    /**
     * 加密原理：十进制转二进制，右移三位，再转10进制，与9异或，然后转成16进制，最后倒转
     * @param int_value
     * @param k
     * @param byte_num
     * @return
     */
    public static String circularShiftRight(BigInteger int_value, int k, int byte_num) {
        String bit_string = String.format("%0" + (byte_num * 8) + "d", new BigInteger(int_value.toString(2)));
        String bin_value = bit_string.substring(bit_string.length() - k) + bit_string.substring(0, bit_string.length() - k);
        BigInteger bigInteger2 = new BigInteger(bin_value,2);
        BigInteger int_encode = new BigInteger("9");
        BigInteger xor = bigInteger2.xor(int_encode);
        String s1 = xor.toString(16);
        String result=reverseStr(s1,byte_num);
        return result;
    }


    /**
     * 对比传进来数据位数，不符，则前面加0。每两位字符当成1位数，倒转
     * @param s1
     * @param byte_num
     * @return
     */
    private static String reverseStr(String s1,int byte_num) {
        char[] chars = s1.toCharArray();
        final StringBuilder addBuild = new StringBuilder();
        if(chars.length<byte_num*2){
            for(int i=0;i<byte_num*2-chars.length;i++){
                addBuild.append("0");
            }
        }
        addBuild.append(s1);
        chars = addBuild.toString().toCharArray();
        StringBuilder tempStringBuilder = new StringBuilder();
        ArrayList<String> resList = new ArrayList<>();
        for(int i=0;i<byte_num*2;i++){
            if(i%2==0){
                tempStringBuilder.append(chars[i]);
            }else if(i%2==1){
                tempStringBuilder.append(chars[i]);
                resList.add(tempStringBuilder.toString());
                tempStringBuilder=new StringBuilder();
            }
        }
        Collections.reverse(resList);
        StringBuilder resultStringBuilder = new StringBuilder();
        for(String str:resList){
            resultStringBuilder.append(str);
        }
        return resultStringBuilder.toString();
    }

    public static String getMacKey(String mac) {
        String result="";
        try{
            result=circularShiftRight(new BigInteger(mac), 3, 6);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }
        return result;
    }

    public static String getWifiMacKey(String wifi){
        String result="";
        if(wifi!=null&&!wifi.isEmpty()){
            result=circularShiftRight(new BigInteger(wifi.replace(":", ""), 16), 3, 6);
        }
        return result;

    }
}
