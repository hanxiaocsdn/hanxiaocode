package com.sf.gis.scala.nloc.app


import com.sf.gis.java.nloc.utils.{AddressLevelJNA, AoiBuildingGuid, TypeJudgeJNA}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.utils.GeoUtil
import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.SparkFiles
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.col
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import java.util.Calendar
import scala.collection.immutable
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{breakable, _}
/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-06-08 09:49
 * @TaskId:874200
 * @TaskName:wifi指纹数据-运单数据标准化-新版
 * @Description:
 */
class OrderGeoV3(var p_order_no:String, var p_addr:String, var p_un:String,
            var p_date:String, var p_tm:String, var p_weight:Double, var p_event_type:String, var p_others:String,
            var p_at_aoi_id:String) {
    var order_no = p_order_no

    var addr = p_addr
    var un = p_un
    var date = p_date
    var tm = p_tm

    var weight = p_weight

    var zx =""
    var zy =""

    var event_type:String = p_event_type

    var aoi_id = ""
    var bld_id = ""
    var level_13 = ""
    var level_14 = ""
    var building=""
    var aoi_name=""
    var waybill_id=""
    var others = p_others

    var at_aoi_id = p_at_aoi_id
}

object ExportOrderGeoVer3 {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    def main(args: Array[String]): Unit = {
        GeoUtil.memTimeTotal()
        GeoUtil.memTime()

        //.set("spark.speculation", "true")
        val conf = GeoUtil.defaultSparkConf().set("spark.memory.offHeap.enabled", "false")
        GeoUtil.initSpark(this.getClass.getSimpleName, conf)
        GeoUtil.sc.hadoopConfiguration.set("fs.defaultFS", "hdfs://sfbd")
        GeoUtil.spark.sql("set spark.sql.shuffle.partitions=400")
        GeoUtil.showCost(s"【框架初始化完成】")
        GeoUtil.showCost(s"!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
        val dayid = GeoUtil.getTodayDate().replaceAll("-", "")
        System.err.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

        val begin_date = args(0)
        if (begin_date == null || begin_date.length <= 0) {
            System.err.println(s"请输入计算的起始时间！！！！ $begin_date")
            return
        }

        val end_date = args(1)
        if (end_date == null || end_date.length <= 0) {
            System.err.println(s"请输入计算的截止时间！！！！ $end_date")
            return
        }

        var citycode=args(2)
        var min_date = args(3)
        if (min_date == null || min_date.length <= 0) {
            System.err.println(s"请输入最小截止日期！！！！ $min_date")
            return
        }

        var max_date = args(4)
        if (max_date == null || max_date.length <= 0) {
            System.err.println(s"请输入最大截止日期！！！！ $max_date")
            return
        }

        var event_type = args(5)
        if (event_type == null || event_type.length <= 0) {
            System.err.println(s"请输入事件类型！！！！ $event_type")
            return
        }

        var table_name = args(6)
        if (table_name == null || table_name.length <= 0) {
            System.err.println(s"请输入表名！！！！ $table_name")
            return
        }

        var adcode =""
        GeoUtil.spark.sparkContext.addFile("hdfs://sfbdp1/user/01367389/upload/tmp/jnalib", true)
        //        GeoUtil.spark.sparkContext.addFile("hdfs://sfbdp1/user/01407499/upload/tmp/jnalib", true)
        GeoUtil.spark.sparkContext.addFile("hdfs://sfbdp1/user/01367389/upload/tmp/typeJudgeLib", true)
        val citycodes=Array("999|659008","997|652900","996|659006","995|650400","994|652300","993|659001","991|650100","979|632800","971|630100","954|640400","952|640200","951|640100","941|623000","939|621200","938|620500","937|620900","936|620700","935|620600","934|621000","932|621100","931|620100","917|610300","913|610500","911|610600","903|659009","8981|469000","898|469000","883|530900","879|530800","878|532300","877|530400","876|532600","874|530300","872|532900","871|530100","859|522300","858|520200","857|520500","854|522700","851|520100","838|510600","835|511800","834|513400","833|511100","832|511000","831|511500","830|510500","826|511600","825|510900","818|511700","817|511300","816|510700","813|510300","812|510400","799|360300","798|360200","797|360700","796|360800","795|360900","794|361000","793|361100","792|360400","791|360100","779|450500","778|451200","777|450700","776|451000","775|450900","774|451100","773|450300","772|451300","771|451400","770|450600","769|441900","766|445300","763|441800","760|442000","759|440800","758|441200","757|440600","756|440400","755|440300","754|440500","753|441400","752|441300","751|440200","750|440700","746|431100","745|431200","743|433100","739|430500","738|431300","737|430900","736|430700","735|431000","734|430400","7313|430200","7312|430300","7311|430100","730|430600","728|429000","724|420800","722|421300","719|420300","718|422800","717|420500","716|421000","715|421200","714|420200","713|421100","712|420900","711|420700","710|420600","692|533100","668|440900","663|445200","662|441700","660|441500","635|371500","633|371100","632|370400","631|371000","599|350700","597|350800","596|350600","595|350500","594|350300","593|350900","592|350200","591|350100","580|330900","579|330700","578|331100","577|330300","576|331000","575|330600","574|330200","573|330400","572|330500","571|330100","570|330800","564|341500","563|341800","562|340700","561|340600","559|341000","558|341200","557|341300","556|340800","555|340500","554|340400","553|340200","552|340300","551|340100","550|341100","546|370500","543|371600","539|371300","538|370900","537|370800","536|370700","535|370600","534|371400","533|370300","532|370200","531|370100","530|371700","527|321300","523|321200","519|320400","518|320700","517|320800","516|320300","515|320900","514|321000","513|320600","512|320500","511|321100","510|320200","483|152900","478|150800","477|150600","476|150400","475|150500","474|150900","473|150300","472|150200","471|150100","470|150700","469|230500","468|230400","467|230300","464|230900","459|230600","455|231200","454|230800","453|231000","452|230200","451|230100","438|220700","436|220800","435|220500","434|220300","433|222400","432|220200","431|220100","429|211400","427|211100","421|211300","419|211000","418|210900","417|210800","416|210700","415|210600","414|210500","412|210300","411|210200","396|411700","395|411100","394|411600","393|410900","391|410800","379|410300","378|410200","377|411300","376|411500","375|410400","374|411000","373|410700","372|410500","371|410100","370|411400","359|140800","358|141100","357|141000","356|140500","355|140400","354|140700","353|140300","352|140200","351|140100","350|140900","335|130300","319|130500","318|131100","317|130900","316|131000","315|130200","314|130800","313|130700","312|130600","311|130100","310|130400","088|530700","053|520400","052|520300","029|610100","028|510000","027|420100","025|320100","024|210000","023|500100","022|120100","021|310100","020|440100","010|110100")

        for(citys<-citycodes){
            citycode=citys.split("\\|")(0)
            adcode=citys.split("\\|")(1)
            logger.error("begin_date---> "+begin_date+" end_date----> "+end_date+" dst----> "+citycode+" adcode-----> "+adcode)
            exportOrderAssembleInfo(begin_date, end_date, citycode, min_date, max_date, event_type, table_name, adcode)

        }



        GeoUtil.showCostTotal(s"【计算完毕】")
        GeoUtil.stopSpark()
    }

    private def getDateRange(startData: Int, endData: Int): immutable.IndexedSeq[Int] = {
        (startData to endData).filter {
            day =>
                try {
                    val formatter = new SimpleDateFormat("yyyyMMdd")
                    formatter.setLenient(false)
                    formatter.parse(day + "")
                    true
                } catch {
                    case _: Exception => false
                }
        }
    }

    def exportOrderAssembleInfo(begin_date : String, end_date : String, dst : String, min_date : String, max_date : String, evnet_type : String, table_name : String, adcode : String): Unit = {
        val format = FastDateFormat.getInstance("yyyyMMdd")
        val calendar = Calendar.getInstance()
        val int_start_date = begin_date.toInt
        val int_end_date = end_date.toInt
        val date_range = getDateRange(int_start_date, int_end_date)
        breakable {
            for (date_index <- 0 until date_range.length) {
                val date_item = date_range(date_index).toString
                logger.error("开始跑------》 "+date_item)
                var nloc_start_date = ""
                var nloc_end_date = date_item
                try{
                    calendar.setTime(format.parse(date_item))
                    calendar.add(Calendar.DAY_OF_MONTH, -7)
                    nloc_start_date = format.format(calendar.getTime)
                }catch {case e:Exception=>{
                    logger.error(e.getMessage)
                }}

//                if (date_index + 10 >= date_range.length) {
//                    nloc_end_date = max_date
//                } else {
//                    nloc_end_date = date_range(date_index + 10).toString
//                }
                // 存储原始轨迹数据到hdfs
                var sql = ""
                if (evnet_type.equals("31124"))
                {
                    // 派件
                    sql = "select a.address, c.waybill_id, a.waybillno, b.aoiid, b.buildingid, b.others, c.eventtype, c.emp_code, c.tm, d.aoi_id " +
                        "from default.202211_202304_building_req_waybill a inner join default.202211_202304_building_rslt_waybill b on a.requestid = b.requestid " +
                        "inner join dm_gis.gis_waybill_nloc c on a.waybillno = c.waybill_no " +
                        "inner join dm_gis.tt_waybill_hook d on a.waybillno = d.waybill_no " +
                        s"where a.inc_day between '$nloc_start_date' and '$nloc_end_date' and b.inc_day between '$nloc_start_date' and '$nloc_end_date' and c.inc_day = '$date_item' and c.eventtype= '31124' and a.citycode = '$dst' and c.dist_code = '$dst' and length(a.address) > 0 and length(a.waybillno) > 0 " +
                        s"and d.inc_day between '$nloc_start_date' and '$nloc_end_date' and d.dest_dist_code = '$dst' " +
                        "and length(b.aoiid) > 0 and length(b.buildingid) > 0 and length(b.others) > 0 and length(c.eventtype) > 0 and length(c.emp_code) > 0 and length(c.tm) > 0 " +
                        "and length(a.requestid) > 0 and length(b.requestid) > 0 and length(d.aoi_id) > 0"

                    sql=
                        s"""
                          |
                          |select a.waybill_id,
                          |    a.waybill_no,
                          |    a.city_code,
                          |    a.county,
                          |    a.emp_code,
                          |    a.tm,
                          |    a.addr,
                          |    a.eventtype,
                          |    b.aoi_id,
                          |    b.aoi_name,
                          |    c.buildingid,
                          |    c.buildingname,
                          |    c.x,
                          |    c.y
                          |from
                          |(select waybill_id, waybill_no, dist_code as city_code, county, emp_code, tm, addr, eventtype
                          |from dm_gis.gis_waybill_nloc
                          | where inc_day='$nloc_end_date' and eventtype = '31124' and dist_code = '$dst'  group by waybill_id, waybill_no, dist_code, county, emp_code, tm, addr, eventtype) a
                          |inner join
                          |(select  waybill_id, waybill_no, aoi_id, aoi_name
                          |from dm_gis.tt_waybill_hook
                          |where inc_day between '$nloc_start_date' and '$nloc_end_date' and dest_dist_code = '$dst' and length(aoi_id)>0 group by waybill_id, waybill_no, aoi_id, aoi_name) b
                          |on a.waybill_no = b.waybill_no
                          |left join
                          |(select waybillno, buildingid, buildingname,x, y,aoi_id
                          |from dm_gis.bld_recognition_rate_delivery_detail
                          |where  inc_day='$nloc_end_date' and citycode = '$dst' and length(aoi_id)>0 group by waybillno, buildingid, buildingname,x, y,aoi_id ) c
                          |on b.waybill_no = c.waybillno and b.aoi_id = c.aoi_id
                          |union all
                          |
                          |select a.waybill_id,
                          |	a.waybill_no,
                          |	a.city_code,
                          |	a.county,
                          |	a.emp_code,
                          |	a.tm,
                          |	a.addr,
                          |	a.eventtype,
                          |	b.aoi_id,
                          |	b.aoi_name,
                          |	c.buildingid,
                          |	c.buildingname,
                          |	c.x,
                          |	c.y
                          |from
                          |(select waybill_id, waybill_no, dist_code as city_code, county, emp_code, tm, addr, eventtype
                          |from dm_gis.gis_waybill_nloc
                          |where inc_day='$nloc_end_date' and eventtype = '31201' and dist_code = '$dst'  group by waybill_id, waybill_no, dist_code, county, emp_code, tm, addr, eventtype) a
                          |inner join
                          |(select order_id waybill_id, waybill_no, aoi_id, aoi_name
                          |from dm_gis.tt_order_hook
                          |where inc_day between '$nloc_start_date' and '$nloc_end_date' and src_dist_code = '$dst' and length(aoi_id)>0 group by order_id, waybill_no, aoi_id, aoi_name) b
                          |on a.waybill_no = b.waybill_no
                          |left join
                          |(select waybillno, buildingid, buildingname, x, y,aoi_id
                          |from dm_gis.bld_recognition_rate_pickup_detail
                          |where inc_day='$nloc_end_date' and citycode = '$dst' and length(aoi_id)>0 group by waybillno, buildingid, buildingname, x, y,aoi_id ) c
                          |on b.waybill_id = c.waybillno and b.aoi_id = c.aoi_id
                          |
                          |
                          |
                          |
                          |""".stripMargin
                }

                else
                    {

                        // 收件
                        sql = "select a.address, c.waybill_id, c.waybill_no as waybillno, a.aoiid, a.buildingid, a.others, c.eventtype, c.emp_code, c.tm, d.aoi_id " +
                            "from default.202301_202304_building_rslt_order a inner join dm_gis.tt_waybill_info b on a.sysorderno = b.order_id " +
                            "inner join dm_gis.gis_waybill_nloc c on b.waybill_no = c.waybill_no " +
                            "inner join dm_gis.tt_order_hook d on c.waybill_no = d.waybill_no " +
                            s"where a.inc_day between '$nloc_start_date' and '$nloc_end_date' and a.citycode = '$dst' and b.inc_day between '$nloc_start_date' and '$nloc_end_date' and c.inc_day = '$date_item' and c.eventtype= '31201' and b.src_dist_code = '$dst' and c.dist_code = '$dst' " +
                            s"and length(a.address) > 0 and length(c.waybill_no) > 0 " +
                            s"and d.inc_day between '$nloc_start_date' and '$nloc_end_date' and d.src_dist_code = '$dst' " +
                            s"and length(a.aoiid) > 0 and length(a.buildingid) > 0 and length(a.others) > 0 and length(c.emp_code) > 0 and length(c.tm) > 0 and length(d.aoi_id) > 0"

                        sql=
                            s"""
                               |
                               |select a.waybill_id,
                               |	a.waybill_no,
                               |	a.city_code,
                               |	a.county,
                               |	a.emp_code,
                               |	a.tm,
                               |	a.addr,
                               |	a.eventtype,
                               |	b.aoi_id,
                               |	b.aoi_name,
                               |	c.buildingid,
                               |	c.buildingname,
                               |	c.x,
                               |	c.y
                               |from
                               |(select waybill_id, waybill_no, dist_code as city_code, county, emp_code, tm, addr, eventtype
                               |from dm_gis.gis_waybill_nloc
                               |where inc_day='$nloc_end_date' and eventtype = '31201' and dist_code = '$dst'  group by waybill_id, waybill_no, dist_code, county, emp_code, tm, addr, eventtype) a
                               |inner join
                               |(select order_id waybill_id, waybill_no, aoi_id, aoi_name
                               |from dm_gis.tt_order_hook
                               |where inc_day between '$nloc_start_date' and '$nloc_end_date' and src_dist_code = '$dst' and length(aoi_id)>0 group by waybill_id, waybill_no, aoi_id, aoi_name) b
                               |on a.waybill_no = b.waybill_no
                               |left join
                               |(select waybillno, buildingid, buildingname, x, y,aoi_id
                               |from dm_gis.bld_recognition_rate_pickup_detail
                               |where inc_day='$nloc_end_date' and citycode = '$dst' and length(aoi_id)>0 group by waybillno, buildingid, buildingname, x, y,aoi_id ) c
                               |on b.waybill_id = c.waybillno and b.aoi_id = c.aoi_id
                               |
                               |
                               |
                               |""".stripMargin

                    }


                /*
                sql = "select  count(*) from  default.202211_202304_building_req_waybill a  inner join default.202211_202304_building_rslt_waybill b on a.requestid = b.requestid " +
                    "inner join dm_gis.gis_waybill_nloc c on a.waybillno = c.waybill_no " +
                    "inner join dm_gis.tt_waybill_hook d on a.waybillno = d.waybill_no " +
                    //"inner join dm_gis.gis_onsite_service_ewl_info e on c.waybill_no = d.waybill_no " +
                    "where a.inc_day between '20230301'  and '20230420'  and b.inc_day between '20230301' and '20230420' and c.inc_day = '20230309' " +
                    "and c.eventtype = '31124' and a.citycode = '755' and c.dist_code = '755' and length(a.address) > 0  and length(a.waybillno) > 0 " +
                    "and d.inc_day between '20230301' and '20230420'  and d.dest_dist_code = '755'  and length(b.aoiid) > 0  and length(b.buildingid) > 0 " +
                    "and length(b.others) > 0  and length(c.eventtype) > 0  and length(c.emp_code) > 0  and length(c.tm) > 0  and length(a.requestid) > 0 " +
                    //"and length(b.requestid) > 0  and length(d.aoi_id) > 0  and e.inc_day = '20230309'  and e.ewl_data!='[]'  and length(e.ewl_data) > 0 and e.citycode='755'"
                    "and length(b.requestid) > 0  and length(d.aoi_id) > 0 and c.waybill_no in (select waybill_no from dm_gis.gis_onsite_service_ewl_info where inc_day = '20230309' and ewl_data != '[]' and length(ewl_data) > 0 and citycode = '755')"
                Util.showCost(sql)

                var pairRddIterator_cnt = Util.spark.sql(sql).rdd.map(item => item).count()//persist(StorageLevel.MEMORY_AND_DISK)
                Util.showCost(s"match cnt = ${pairRddIterator_cnt}")
                 */

                /*
                if (begin_date.equals("20230309"))
                    sql = "select a.address, c.waybill_id, a.waybillno, b.aoiid, b.buildingid, b.others, c.eventtype, c.emp_code, c.tm, d.aoi_id " +
                        "from default.202211_202304_building_req_waybill a inner join default.202211_202304_building_rslt_waybill b on a.requestid = b.requestid " +
                        "inner join dm_gis.gis_waybill_nloc c on a.waybillno = c.waybill_no " +
                        "inner join dm_gis.tt_waybill_hook d on a.waybillno = d.waybill_no " + "" +
                        "where a.inc_day between '20230301'  and '20230420' and b.inc_day between '20230301' and '20230420'  and c.inc_day = '20230309' and c.eventtype = '31124' " +
                        "and a.citycode = '755'  and c.dist_code = '755'  and length(a.address) > 0  and length(a.waybillno) > 0  and d.inc_day between '20230301'  and '20230420'  and d.dest_dist_code = '755' " +
                        "and length(b.aoiid) > 0 and length(b.buildingid) > 0  and length(b.others) > 0  and length(c.eventtype) > 0  and length(c.emp_code) > 0  and length(c.tm) > 0  and length(a.requestid) > 0 " +
                        "and length(b.requestid) > 0  and length(d.aoi_id) > 0"
                else
                    sql = "select a.address, c.waybill_id, a.waybillno, b.aoiid, b.buildingid, b.others, c.eventtype, c.emp_code, c.tm, d.aoi_id " +
                        "from default.202211_202304_building_req_waybill a inner join default.202211_202304_building_rslt_waybill b on a.requestid = b.requestid " +
                        "inner join dm_gis.gis_waybill_nloc c on a.waybillno = c.waybill_no " +
                        "inner join dm_gis.tt_waybill_hook d on a.waybillno = d.waybill_no " + "" +
                        "where a.inc_day between '20230501'  and '20230601' and b.inc_day between '20230501' and '20230601'  and c.inc_day = '20230508' and c.eventtype = '31124' " +
                        "and a.citycode = '755'  and c.dist_code = '755'  and length(a.address) > 0  and length(a.waybillno) > 0  and d.inc_day between '20230501'  and '20230601'  and d.dest_dist_code = '755' " +
                        "and length(b.aoiid) > 0 and length(b.buildingid) > 0  and length(b.others) > 0  and length(c.eventtype) > 0  and length(c.emp_code) > 0  and length(c.tm) > 0  and length(a.requestid) > 0 " +
                        "and length(b.requestid) > 0  and length(d.aoi_id) > 0"
                   */
                GeoUtil.showCost(sql)
                val spark = GeoUtil.spark

                var pairRddIterator = GeoUtil.spark.sql(sql)
                var it = pairRddIterator.rdd.map(ele => {
                    val waybill_id = ele.getAs[String](fieldName = "waybill_id")
                    val order_no = ele.getAs[String](fieldName = "waybill_no")
                    val aoi_name = ele.getAs[String](fieldName = "aoi_name")
                    val un = ele.getAs[String](fieldName = "emp_code")

                    var addr = ele.getAs[String](fieldName = "addr")
                    if(StringUtils.nonEmpty(addr))
                    addr = addr.replace(",", "")

                    val eventtype = ele.getAs[String](fieldName = "eventtype")
                    val tm = ele.getAs[String](fieldName = "tm")

                    val others = ""
//                    val aoiid = ele.getAs[String](fieldName = "aoiid")
                    val buildingid = ele.getAs[String](fieldName = "buildingid")
                    val buildingname = ele.getAs[String](fieldName = "buildingname")
                    val x = ele.getAs[String](fieldName = "x")
                    val y = ele.getAs[String](fieldName = "y")

                    val at_aoi_id = ele.getAs[String](fieldName = "aoi_id")
                    var p = new OrderGeoV3(order_no, addr, un, "", tm, -1, eventtype, others, at_aoi_id)
                    p.aoi_id = at_aoi_id
                    p.bld_id = buildingid
                    p.building=buildingname
                    p.aoi_name=aoi_name
                    p.waybill_id=waybill_id
                    p.zx=x
                    p.zy=y

                    p
                })

                val res = it.repartition(300).mapPartitions(p => {
                    val absolutePath = SparkFiles.get("jnalib")
                    val type_absolutePath = SparkFiles.get("typeJudgeLib")
                    val resultList = ArrayBuffer[ArrayBuffer[String]]()
                    try {
                        /*
                        val cmd = s"ls -al $absolutePath/config/WordSegmentation"
                        val result_txt = cmd.!!
                        System.out.println(result_txt)
                        */
                        if (AddressLevelJNA.Init(absolutePath, type_absolutePath, "config", adcode)) {
//                            val type_res = TypeJudgeJNA.Init(type_absolutePath)
                            while (p.hasNext) {
                                val item = p.next()
                                val assemble_info = AoiBuildingGuid.getNormalizeSplitInfoNew(item.addr, item.bld_id, adcode)
                                var province = ""
                                var city = ""
                                var county = ""
                                var town = ""
                                var village = ""
                                var road = ""
                                var branch_road = ""
                                var house_no = ""
                                var branch_house_no = ""
                                var aoi = ""
                                var sub_aoi = ""
                                var building = ""
                                var unit = ""
                                var floor = ""
                                var room = ""
                                var reserve1 = ""
                                val reserve2 = assemble_info(23) + "&&" + assemble_info(27)
                                var splitInfo = ""

                                item.aoi_id = if (!assemble_info(21).isEmpty) assemble_info(21) else item.aoi_id
                                //item.bld_id = if (!assemble_info(22).isEmpty) assemble_info(22) else item.bld_id
//                                item.bld_id = assemble_info(22)
//                                if (item.at_aoi_id != item.aoi_id) {
//                                    item.bld_id = ""
//                                    item.aoi_id = item.at_aoi_id
//                                }

                                province = if (assemble_info(1).isEmpty) assemble_info(24) else assemble_info(1)
                                city = if (assemble_info(2).isEmpty) assemble_info(25) else assemble_info(2)
                                county = if (assemble_info(3).isEmpty) assemble_info(26) else assemble_info(3)
                                town = assemble_info(5)
                                village = assemble_info(6)
                                road = assemble_info(9)
                                branch_road = assemble_info(10)
                                house_no = assemble_info(11)
                                branch_house_no = assemble_info(12)
                                aoi = assemble_info(13)
                                sub_aoi = assemble_info(18)
                                building = assemble_info(14)
                                unit = assemble_info(15)
                                floor = assemble_info(16)
                                room = assemble_info(17)
                                var name_chn_type = ""
//                                if (type_res)
//                                    name_chn_type= TypeJudgeJNA.GetAddrType(item.addr, assemble_info(19), adcode)
                                splitInfo = assemble_info(19).replace(",", "#")
                                reserve1 = assemble_info(20)
                                reserve1=""

                                var arrayBuffer = ArrayBuffer[String]()
                                arrayBuffer.append(item.order_no)
                                arrayBuffer.append(item.un)
                                arrayBuffer.append(item.tm)
                                arrayBuffer.append(item.event_type)
                                arrayBuffer.append(item.addr)
                                arrayBuffer.append(item.addr)
                                arrayBuffer.append(item.aoi_id)
                                arrayBuffer.append(item.bld_id)
                                arrayBuffer.append(item.aoi_id)
                                arrayBuffer.append(item.bld_id)
                                arrayBuffer.append(province)
                                arrayBuffer.append(city)
                                arrayBuffer.append(county)
                                arrayBuffer.append(town)
                                arrayBuffer.append(village)
                                arrayBuffer.append(road)
                                arrayBuffer.append(branch_road)
                                arrayBuffer.append(house_no)
                                arrayBuffer.append(branch_house_no)
                                arrayBuffer.append(aoi)
                                arrayBuffer.append(sub_aoi)
                                arrayBuffer.append(item.building)
                                arrayBuffer.append(unit)
                                arrayBuffer.append(floor)
                                arrayBuffer.append(room)
                                arrayBuffer.append(reserve1)
                                arrayBuffer.append(reserve2)
                                arrayBuffer.append(splitInfo)
                                arrayBuffer.append(name_chn_type)
                                arrayBuffer.append("0")
                                arrayBuffer.append("")
                                arrayBuffer.append("")
                                arrayBuffer.append(item.zx)
                                arrayBuffer.append(item.zy)
                                arrayBuffer.append(item.waybill_id)
                                arrayBuffer.append(item.aoi_name)

                                resultList.append(arrayBuffer)
                            }
                            AddressLevelJNA.UnInit()
                        }
                    } catch {
                        case e: Exception =>
                            System.err.println("Some error occured : " + e.toString)
                    }

                    resultList.iterator
                }, true)

                import spark.implicits._
                val output_res = res.toDF().select(
                    col("value")(0) as "waybill_no",
                    col("value")(1) as "em_code",
                    col("value")(2) as "tm",
                    col("value")(3) as "operate_type",
                    col("value")(4) as "address",
                    col("value")(5) as "std_address",
                    col("value")(6) as "aoi_id",
                    col("value")(7) as "bld_id",
                    col("value")(8) as "aoi_key",
                    col("value")(9) as "bld_key",
                    col("value")(10) as "province",
                    col("value")(11) as "city",
                    col("value")(12) as "county",
                    col("value")(13) as "town",
                    col("value")(14) as "village",
                    col("value")(15) as "road",
                    col("value")(16) as "branch_road",
                    col("value")(17) as "house_no",
                    col("value")(18) as "branch_house_no",
                    col("value")(19) as "aoi",
                    col("value")(20) as "sub_aoi",
                    col("value")(21) as "building",
                    col("value")(22) as "unit",
                    col("value")(23) as "floor",
                    col("value")(24) as "room",
                    col("value")(25) as "reserve1",
                    col("value")(26) as "reserve2",
                    col("value")(27) as "split_info",
                    col("value")(28) as "adr_type",
                    col("value")(29) as "state",
                    col("value")(30) as "version",
                    col("value")(31) as "pre_aoi_key",
                    col("value")(32) as "zx",
                    col("value")(33) as "zy",
                    col("value")(34) as "waybill_id",
                    col("value")(35) as "aoi_name"
                )

                var cellRst = output_res.repartition(10).persist(StorageLevel.MEMORY_AND_DISK)
                GeoUtil.showCost(s"cnt = ${cellRst.count()}")
                cellRst.createOrReplaceTempView("tem_result")
                var sql_w=
                    s"""
                      |
                      |insert overwrite table dm_gis.dm_tt_waybill_normalization_dtl_di partition(city_code='$dst',inc_day='$date_item')
                      |select
                      |waybill_id
                      |,waybill_no
                      |,em_code
                      |,tm
                      |,address
                      |,std_address
                      |,operate_type
                      |,aoi_id
                      |,aoi_name
                      |,bld_id
                      |,building
                      |,zx
                      |,zy
                      |,aoi_key
                      |,bld_key
                      |,province
                      |,city
                      |,county
                      |,town
                      |,village
                      |,floor
                      |,room
                      |,'$dst' as reserve1
                      |,reserve2
                      |,split_info
                      |
                      |
                      |from tem_result
                      |""".stripMargin
                spark.sql(sql_w)

                cellRst.show(10, false)
//                cellRst.write.mode(SaveMode.Append).format("csv").save(s"/user/hive/warehouse/ft/DM/dm_gis/$table_name/$dst/$date_item")
                //cellRst.write.mode(SaveMode.Append).format("csv").save(s"/user/01367389/upload/order_zk/$date_item")
                GeoUtil.showCost(s"【保存完成】")
                cellRst.unpersist()
                GeoUtil.freeMem()


            }
        }
    }
}
