package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-06-25 19:07
 * @TaskId:786233
 * @TaskName:wifi数据清洗
 * @Description:
 */

object InitApWifiDataClean {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveErrorAoiKey=Array("error_wifi","aoi_key")

//    val saveErrorAoiKey=Array("error_wifi","error_finger_aoi","error_finger_bld","error_finger_detail","isWifiAllError")

    val saveAoiKey=Array("key","wifi_list","finger_list","aoi_id","aoi_key","city_code","address","province","city","county","town","village","aoi_name","lng","lat","points","reliable","inc_day","reserve1","reserve2")
    val saveBuildKey=Array("key","wifi_list","upper_key","finger_list","buildingid","bld_key","city_code","address","province","city","county","town","village","aoi_name","buildingname","lng","lat","points","inc_day","reliable","reserve1","reserve2")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","city_code","floor","lng","lat","decrypt_wifi")
    val saveDetailKey=Array("key","wifi_list","upper_key","city_code","address","level","province","city","county","town","village","aoi_name","buildingname","floor","room","lng","lat","points","inc_day","reliable","reserve1","reserve2")


    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        logger.error("获取标记数据")
        val signDataRdd = getSignWifi(sparkSession)
        logger.error("清洗aoi数据")
        val aoiResultRdd = cleanAoiData(sparkSession, signDataRdd)
        logger.error("存储wifi aoi数据")
        SparkWrite.save2HiveStaticNew(sparkSession, aoiResultRdd, saveAoiKey, "dm_gis.dm_wifi_finger_aoi_dtl",null, 50)
        Spark.clearPersistWithoutId(sparkSession,signDataRdd.id)
        logger.error("清洗build数据")
        val buildResultRdd = cleanBuildData(sparkSession, signDataRdd)
        logger.error("存储wifi build数据")
        SparkWrite.save2HiveStaticNew(sparkSession, buildResultRdd, saveBuildKey, "dm_gis.dm_wifi_finger_bld_dtl",null, 25)
        Spark.clearPersistWithoutId(sparkSession,signDataRdd.id)
        logger.error("清洗detail数据")
        val detailResultRdd = cleanDetailData(sparkSession, signDataRdd)
        logger.error("存储 wifi detail数据")
        SparkWrite.save2HiveStaticNew(sparkSession, detailResultRdd, saveDetailKey, "dm_gis.dm_wifi_finger_detail_dtl",null, 25)
        Spark.clearPersistWithoutId(sparkSession,signDataRdd.id)
        logger.error("清洗index数据")
        val indexResultRdd = cleanIndexData(sparkSession, signDataRdd)
        logger.error("存储 wifi index数据")
        SparkWrite.save2HiveStaticNew(sparkSession, indexResultRdd, saveIndexKey, "dm_gis.dm_wifi_finger_index_dtl",null, 50)



    }

    def getSignWifi(spark:SparkSession)={
        var sql=
            """
              |
              |select * from default.wifi_finger_sign_data where length(error_finger_aoi)<=800
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        dataRdd

    }

    def cleanIndexData(spark:SparkSession,signDataRdd: RDD[JSONObject])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_index_dtl where length(finger_aoi)<1900 and length(finger_bld)<1600
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val errorWifiRdd = signDataRdd.filter(obj => (StringUtils.nonEmpty(obj.getString("iswifiallerror")) && obj.getString("iswifiallerror").toBoolean))
            .map(obj => (obj.getString("error_wifi"), obj))
        val resultRdd = dataRdd.map(obj => (obj.getString("key"), obj)).leftOuterJoin(errorWifiRdd).map(x => {
            var obj = new JSONObject()
            val leftobj = x._2._1
            if (x._2._2.isEmpty) {
                obj = leftobj
            }else{
                obj.put("key",x._2._1.getString("key"))
            }
            obj

        })

        resultRdd
    }

    def cleanAoiData(spark:SparkSession,signDataRdd: RDD[JSONObject])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_aoi_dtl
              |
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)

        val errorWifiRdd = signDataRdd.mapPartitions(itr => {
            val listbuffer = new ListBuffer[JSONObject]()
            for (obj <- itr) {
                val error_finger_aoi = obj.getString("error_finger_aoi")
                if (error_finger_aoi.length > 0) {
                    for (i <- 0 until error_finger_aoi.length / 16) {
                        val dataObj = new JSONObject()
                        //iswifiallerror
                        dataObj.put("aoi_key", error_finger_aoi.substring(i * 16, (i + 1) * 16))
                        dataObj.put("error_wifi", obj.getString("error_wifi"))
                        dataObj.put("iswifiallerror", obj.getString("iswifiallerror"))
//                        obj.put("aoi_key", error_finger_aoi.substring(i * 16, (i + 1) * 16))
                        listbuffer += dataObj

                    }
                }

            }

            listbuffer.iterator
        })



        /**
         *
         * 暂时注释，如果跑数时出现数据倾斜，可以存储数据，剔除倾斜的key
         *
         */

        //        SparkWrite.save2HiveStaticNew(spark, errorWifiRdd, saveErrorAoiKey, "tmp_dm_gis.dm_wifi_finger_aoi_dtl_error",null, 25)

        val errorWifiGroupRdd = errorWifiRdd.map(obj => (obj.getString("aoi_key"), obj)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("异常aoi炸开后数据量---》"+errorWifiGroupRdd.count())
        val overSizeAoi = errorWifiGroupRdd.flatMap(x => {
            val size = x._2.size
            val listbuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()
            dataObj.put("aoi_key", x._1)
            dataObj.put("aoi_num", size)
            listbuffer += dataObj
            listbuffer
        }).filter(x => StringUtils.nonEmpty(x.getString("num")) && x.getString("num").toLong > 100000L).map(x => x.getString("aoi_key")).collect().toSet
        val overSizeAoiSetBroad = spark.sparkContext.broadcast(overSizeAoi)
        val fliterErrorWifiList = dataRdd.map(obj => {
            val overSizeAoiSet = overSizeAoiSetBroad.value
//        val overSizeAoiSet = new mutable.HashSet[String]()
            val dataObj = new JSONObject()
            dataObj.fluentPutAll(obj)
            try {
                val aoi_key = obj.getString("aoi_key")
                val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
                val wifiArr = new JSONArray()
                for (i <- 0 until (wifi_list.size())) {
                    val num = wifi_list.getJSONObject(i).getString("num").toLong
                    if(overSizeAoiSet.contains(aoi_key)){
                        if (num > 2L) {
                            wifiArr.add(wifi_list.getJSONObject(i))
                        }
                    }else{
                        if(wifi_list.size()>10000){
                            if (num > 1L) {
                                wifiArr.add(wifi_list.getJSONObject(i))

                            }
                        }else{
                            wifiArr.add(wifi_list.getJSONObject(i))

                        }

                    }
                }

                dataObj.put("wifi_list", wifiArr.toString)

            } catch {
                case e: Exception => logger.error(e.toString)
            }

            dataObj

        })

        val resultRdd = dataRdd.map(obj => (obj.getString("key").split("_")(1), obj)).leftOuterJoin(errorWifiGroupRdd).map(x => {
            var dataObj = new JSONObject()
            val leftObj = x._2._1
            val wifi_list = leftObj.getString("wifi_list")
            val wifiArrNew = new JSONArray()
            val wifiArr = try {
                JSON.parseArray(wifi_list)
            } catch {
                case e: Exception => {
                    logger.error(e.getMessage)
                    new JSONArray()
                }
            }
            val errorWifiSet = new mutable.HashSet[String]()

            if (x._2._2.nonEmpty) {
                for (errorWifiObj <- x._2._2.get) {
                    errorWifiSet.add(errorWifiObj.getString("error_wifi").split("_")(1))
                }
                for (i <- 0 until wifiArr.size()) {
                    val wifiKey = getMd5Key(wifiArr.getJSONObject(i).getString("mac"))
                    var errorFlag = false
                    if(!errorWifiSet.contains(wifiKey)){
                        wifiArrNew.add(wifiArr.getJSONObject(i))
                    }
                }
                leftObj.put("wifi_list", wifiArrNew)
                if (wifiArrNew.size() > 0) {
                    dataObj = leftObj
                }else{
                    dataObj.put("key",x._2._1.getString("key"))
                }
            } else {
                dataObj = leftObj
            }


            dataObj
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("清洗后aoi数据量---》"+resultRdd.count())

        resultRdd

    }

    def cleanBuildData(spark:SparkSession,signDataRdd: RDD[JSONObject])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_bld_dtl
              |
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val errorWifiRdd = signDataRdd.mapPartitions(itr => {
            val listbuffer = new ListBuffer[JSONObject]()
            for (obj <- itr) {
                val error_finger_aoi = obj.getString("error_finger_bld")
                if (error_finger_aoi.length > 0) {
                    for (i <- 0 until error_finger_aoi.length / 16) {
                        obj.put("bld_key", error_finger_aoi.substring(i * 16, (i + 1) * 16))
                        listbuffer += obj

                    }
                }

            }

            listbuffer.iterator
        }).map(obj => (obj.getString("bld_key"), obj)).groupByKey()

        val resultRdd = dataRdd.filter(obj=>StringUtils.nonEmpty(obj.getString("key"))&&obj.getString("key").split("_").size>1).map(obj => (obj.getString("key").split("_")(1), obj)).leftOuterJoin(errorWifiRdd).map(x => {
            var dataObj = new JSONObject()
            val leftObj = x._2._1
            val wifi_list = leftObj.getString("wifi_list")
            val wifiArrNew = new JSONArray()

            val wifiArr = try {
                JSON.parseArray(wifi_list)
            } catch {
                case e: Exception => {
                    logger.error(e.getMessage)
                    new JSONArray()
                }
            }

            if (x._2._2.nonEmpty) {
                for (i <- 0 until wifiArr.size()) {
                    val wifiObj = wifiArr.getJSONObject(i)
                    val wifiKey = getMd5Key(wifiObj.getString("mac"))
                    var errorFlag = false
                    breakable {
                        for (errorWifiObj <- x._2._2.get) {
                            if (wifiKey.equals(errorWifiObj.getString("error_wifi").split("_")(1))) {
                                errorFlag = true
                                break
                            }
                        }

                    }

                    if (!errorFlag) {
                        wifiArrNew.add(wifiObj)

                    }


                }

                leftObj.put("wifi_list", wifiArrNew)
                if (wifiArrNew.size() > 0) {
                    dataObj = leftObj

                }else{
                    dataObj.put("key",x._2._1.getString("key"))

                }


            } else {
                dataObj = leftObj

            }

            dataObj
        })

        resultRdd

    }


    def cleanDetailData(spark:SparkSession,signDataRdd: RDD[JSONObject])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_detail_dtl where upper_key<>''
              |
              |
              |""".stripMargin
        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val errorWifiRdd = signDataRdd.filter(x=>StringUtils.nonEmpty(x.getString("error_finger_bld"))).mapPartitions(itr => {
            val listbuffer = new ListBuffer[JSONObject]()
            for (obj <- itr) {
                val error_finger_aoi = obj.getString("error_finger_detail")
                if (error_finger_aoi.length > 0) {
                    for (i <- 0 until error_finger_aoi.length / 19) {
                        val dataObj = new JSONObject()
                        dataObj.put("finger_detail_key", error_finger_aoi.substring(i * 19, (i + 1) * 19).substring(0,16))
                        dataObj.put("error_wifi", obj.getString("error_wifi"))
                        dataObj.put("iswifiallerror", obj.getString("iswifiallerror"))
                        listbuffer += dataObj

                    }
                }

            }

            listbuffer.iterator
        }).filter(x=>StringUtils.nonEmpty(x.getString("finger_detail_key"))).map(obj => (obj.getString("finger_detail_key"), obj)).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("异常detail炸开后数据量---》"+errorWifiRdd.count())

//        val overSizeAoi = errorWifiRdd.flatMap(x => {
//            val size = x._2.size
//            val listbuffer = new ListBuffer[JSONObject]
//            val dataObj = new JSONObject()
//            dataObj.put("finger_detail_key", x._1)
//            dataObj.put("aoi_num", size)
//            listbuffer += dataObj
//            listbuffer
//        }).filter(x => StringUtils.nonEmpty(x.getString("aoi_num")) && x.getString("aoi_num").toLong > 100000L).map(x => x.getString("finger_detail_key")).collect().toSet
//        val overSizeAoiSetBroad = spark.sparkContext.broadcast(overSizeAoi)
//
//
//        val fliterErrorWifiList = dataRdd.map(obj => {
//
//            val dataObj = new JSONObject()
//            dataObj.fluentPutAll(obj)
//            val overSizeAoiSet = overSizeAoiSetBroad.value
//            try {
//                val wifi_list = JSON.parseArray(obj.getString("wifi_list"))
//                val wifiArr = new JSONArray()
//                for (i <- 0 until (wifi_list.size())) {
//                    val num = wifi_list.getJSONObject(i).getString("num").toLong
//                    if(overSizeAoiSet.contains(obj.getString("key").split("_")(1))){
//                        if (num > 3L) {
//                            wifiArr.add(wifi_list.getJSONObject(i))
//                        }
//                    }else{
//                        if(wifi_list.size()>10000){
//                            if (num > 1L) {
//                                wifiArr.add(wifi_list.getJSONObject(i))
//                            }
//                        }else{
//                            wifiArr.add(wifi_list.getJSONObject(i))
//
//                        }
//                    }
//
//                }
//
//                dataObj.put("wifi_list", wifiArr.toString)
//
//            } catch {
//                case e: Exception => logger.error(e.toString)
//            }
//
//            dataObj
//
//        })

        val resultRdd = dataRdd.map(obj => (obj.getString("key").split("_")(1), obj)).leftOuterJoin(errorWifiRdd).map(x => {
            var dataObj = new JSONObject()
            val leftObj = x._2._1
            val wifi_list = leftObj.getString("wifi_list")
            val wifiArrNew = new JSONArray()

            val wifiArr = try {
                JSON.parseArray(wifi_list)
            } catch {
                case e: Exception => {
                    logger.error(e.getMessage)
                    new JSONArray()
                }
            }

            val errorWifiSet = new mutable.HashSet[String]()
            if (x._2._2.nonEmpty) {
                for (errorWifiObj <- x._2._2.get) {
                    errorWifiSet.add(errorWifiObj.getString("error_wifi").split("_")(1))
                }
                for (i <- 0 until wifiArr.size()) {
                    val wifiKey = getMd5Key(wifiArr.getJSONObject(i).getString("mac"))
                    var errorFlag = false
                    if(!errorWifiSet.contains(wifiKey)){
                        wifiArrNew.add(wifiArr.getJSONObject(i))
                    }
                }

                leftObj.put("wifi_list", wifiArrNew)
                if (wifiArrNew.size() > 0) {
                    dataObj = leftObj

                }else{
                    dataObj.put("key",x._2._1.getString("key"))
                }


            } else {
                dataObj = leftObj

            }

            dataObj
        })

        resultRdd

    }
    def getMd5Key(addr:String)={
        var resultMd5Str=""
        if(addr!=null&&addr.nonEmpty){
            val md5addr = MD5Util.getMD5(addr)
            resultMd5Str=md5addr.toLowerCase.substring(8, 24)
        }
        resultMd5Str

    }


}
