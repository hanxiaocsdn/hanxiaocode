package com.sf.gis.scala.nloc.wifiapp

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.GeometryUtil
import com.sf.gis.java.base.util.GeometryUtil.sliceUpCoordinate
import com.sf.gis.java.nloc.pojo.{ClusterWifiData, ClusterWifiDataNew}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.StringUtils
import com.sf.gis.scala.nloc.wifiapp.InitTrajectoryWifiData.logger
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.util
import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @ProductManager:01429009
 * @Author: 01407499
 * @CreateTime: 2023-06-21 15:11
 * @TaskId:786233
 * @TaskName:wifi数据标记删除
 * @Description:
 */

object InitApWifiDataSign {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("error_wifi","error_finger_aoi","error_finger_bld","error_finger_detail","isWifiAllError")
    val saveIndexKey=Array("key","finger_aoi","finger_bld","finger_detail","floor","lon","lat","reserve1","reserve2","update_tag")
    val savebldKey=Array("bld_key","finger_lon","finger_lat","finger_time")



    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val (aoiMapBroad,aoiWifiRdd) = getApAoiWifi(sparkSession)
        val (bldMapBroad,bldWifiRdd) = getApBuildWifi(sparkSession)
        val resultRdd = clusterWifiV3(sparkSession, bldMapBroad, aoiMapBroad,bldWifiRdd,aoiWifiRdd)
//        val resultRdd = clusterWifi(sparkSession, bldMapBroad, aoiMapBroad)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "default.wifi_finger_sign_data",null, 25)

    }

    def getApAoiWifi(spark:SparkSession) ={
        var sql=
            """
              |
              |select substr(`key`,3,16) as aoi_key,lng,lat,wifi_list from dm_gis.dm_wifi_finger_aoi_dtl where lng<>'' and lat<>''
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val aoiMap = dataRdd.map(obj => {
            val aoi_key = obj.getString("aoi_key")
            val lon = obj.getString("lng")
            val lat = obj.getString("lat")
            var point = lon + "," + lat
            (aoi_key, point)

        }).collect().toMap

        val aoiRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                try {
                    val aoi_key = obj.getString("aoi_key")
                    val lon = obj.getString("lng")
                    val lat = obj.getString("lat")
                    val wifi_list = obj.getString("wifi_list")
                    val wifiArr = JSON.parseArray(wifi_list)
                    for (i <- 0 until (wifiArr.size())) {
                        val tmpObj = new JSONObject()
                        val wifiObj = wifiArr.getJSONObject(i)
                        val mac = wifiObj.getString("mac")
                        val mac_time = wifiObj.getString("time")
                        tmpObj.put("aoi_key", aoi_key + "_" + mac)
                        tmpObj.put("finger_lon", lon)
                        tmpObj.put("finger_lat", lat)
                        tmpObj.put("finger_time", mac_time)
                        listbuffer += tmpObj


                    }


                } catch {
                    case e: Exception => e.printStackTrace()
                }


            }


            listbuffer.iterator
        }).map(x => (x.getString("aoi_key"), x))
        (spark.sparkContext.broadcast(aoiMap),aoiRdd)


    }

    def getApBuildWifi(spark:SparkSession) ={
        var sql=
            """
              |
              |select substr(`key`,3,16) as bld_key,lng,lat,wifi_list from dm_gis.dm_wifi_finger_bld_dtl where lng<>'' and lat<>''
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val bldMap = dataRdd.map(obj => {
            val bld_key = obj.getString("bld_key")
            val lon = obj.getString("lng")
            val lat = obj.getString("lat")
            var point = lon + "," + lat
            (bld_key, point)

        }).collect().toMap

        val bldRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                try {
                    val bld_key = obj.getString("bld_key")
                    val lon = obj.getString("lng")
                    val lat = obj.getString("lat")
                    val wifi_list = obj.getString("wifi_list")
                    val wifiArr = JSON.parseArray(wifi_list)
                    if(StringUtils.nonEmpty(bld_key)&&(!bld_key.equals("8f00b204e9800998"))){
                        for (i <- 0 until (wifiArr.size())) {
                            val tmpObj = new JSONObject()
                            val wifiObj = wifiArr.getJSONObject(i)
                            val mac = wifiObj.getString("mac")
                            val mac_time = wifiObj.getString("time")
                            tmpObj.put("bld_key", bld_key + "_" + mac)
                            tmpObj.put("finger_lon", lon)
                            tmpObj.put("finger_lat", lat)
                            tmpObj.put("finger_time", mac_time)
                            listbuffer += tmpObj


                        }


                    }


                } catch {
                    case e: Exception => e.printStackTrace()
                }


            }


            listbuffer.iterator
        }).map(x => (x.getString("bld_key"), x))
        (spark.sparkContext.broadcast(bldMap),bldRdd)


    }

    /**
     * 标记错误wifi，v3版
     * @param spark
     * @param bldMapBroad
     * @param aoiMapBroad
     * @param bldWifiRdd
     * @param aoiWifiRdd
     * @return
     */
    def clusterWifiV3(spark:SparkSession,bldMapBroad:Broadcast[Map[String, String]],aoiMapBroad:Broadcast[Map[String, String]],bldWifiRdd:RDD[(String,JSONObject)],aoiWifiRdd:RDD[(String,JSONObject)])={
        var sql=
            """
              |
              |select * from dm_gis.dm_wifi_finger_index_dtl where length(finger_aoi)<1900 and length(finger_bld)<1600
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val signClusterNumRdd = dataRdd.map(obj => {
            val bldMap = bldMapBroad.value
            val aoiMap = aoiMapBroad.value
            var isBldFinger = "0"
            var clusterBuffer: ListBuffer[ClusterWifiData] = ListBuffer()
            val bldList = new ListBuffer[String]()
            val aoiList = new ListBuffer[String]()
            var finger_bld = obj.getString("finger_bld")
            var key = obj.getString("key")
            var finger_aoi = obj.getString("finger_aoi")
//            splitFingerList(finger_bld, bldList)
            splitFingerAoi(finger_bld, bldList)
            splitFingerAoi(finger_aoi, aoiList)


            /**
             * 初始化第一个指纹坐标为第一个聚合区域中心；
             * 计算第二个指纹坐标与第一个指纹坐标的距离，当距离小于300m时，将第二个指纹与第一个指纹归为一个聚合区域，聚类中心为第一个指纹和第二个指纹的平均坐标位置；否则，第二个指纹作为第二个聚合区域的中心点；
             * 分别计算第三个指纹坐标和之前所有的聚合区域中心点坐标的距离，当小于300m时，归为对应的聚合区域，否则单独作为新的聚合区域中心点；
             */
            if (StringUtils.nonEmpty(finger_bld)) {
                isBldFinger = "1"
                calcClusterBySliceUpCoordinate(bldList, bldMap, clusterBuffer)
            } else {
                calcClusterBySliceUpCoordinate(aoiList, aoiMap, clusterBuffer)
            }
            if(clusterBuffer.size>1){
                obj.put("clusterNumError","true")
            }
            obj


        }).filter(obj => StringUtils.nonEmpty(obj.getString("clusterNumError"))&&obj.getString("clusterNumError").toBoolean).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记聚类数量异常数据量 ----> "+signClusterNumRdd.count())
        signClusterNumRdd.take(10).foreach(println)
        Spark.clearPersistWithoutId(spark,signClusterNumRdd.id)




        val fingerBldNotEmptyRdd = signClusterNumRdd.filter(x => StringUtils.nonEmpty(x.getString("finger_bld")))
        val fingerBldEmptyRdd = signClusterNumRdd.filter(x => !StringUtils.nonEmpty(x.getString("finger_bld")))

        val fingerBldWifiRdd = fingerBldNotEmptyRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val finger_blds = obj.getString("finger_bld")
                val bldList = new ListBuffer[String]()
//                splitFingerList(finger_blds, bldList)
                splitFingerAoi(finger_blds, bldList)
                for (finger_bld <- bldList) {
                    if(StringUtils.nonEmpty(finger_bld)&&(!finger_bld.equals("8f00b204e9800998"))){
                        val tmpObj = new JSONObject()
                        tmpObj.fluentPutAll(obj)
                        tmpObj.put("finger_bld", finger_bld)
                        listbuffer += tmpObj
                    }
                }

            }

            listbuffer.iterator
        }).filter(x => StringUtils.nonEmpty(x.getString("finger_bld"))&&(!x.getString("finger_bld").equals("8f00b204e9800998"))).map(x => (x.getString("finger_bld")+"_"+x.getString("key").split("_")(1), x)).leftOuterJoin(bldWifiRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.fluentPutAll(rightOp.get)

                }

            }

            leftObj


        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联bld指纹数据量"+fingerBldWifiRdd.count())
        fingerBldWifiRdd.take(10).foreach(println)
        val fingerAoiWifiRdd = fingerBldEmptyRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]()
            for (obj <- x) {
                val finger_blds = obj.getString("finger_aoi")
                val bldList = new ListBuffer[String]()
                splitFingerAoi(finger_blds, bldList)
                for (finger_bld <- bldList) {
                    val tmpObj = new JSONObject()
                    tmpObj.fluentPutAll(obj)
                    tmpObj.put("finger_aoi", finger_bld)
                    listbuffer += tmpObj

                }

            }

            listbuffer.iterator
        }).map(x => (x.getString("finger_aoi")+"_"+x.getString("key").split("_")(1), x)).leftOuterJoin(aoiWifiRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.fluentPutAll(rightOp.get)

                }

            }

            leftObj


        }).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联aoi指纹数据量"+fingerAoiWifiRdd.count())
        fingerAoiWifiRdd.take(10).foreach(println)
        Spark.clearPersistWithoutIdList(spark,Array(fingerAoiWifiRdd.id,fingerBldWifiRdd.id))

        val resultRdd = fingerBldWifiRdd.union(fingerAoiWifiRdd).groupBy(x => x.getString("key")).flatMap(x => {
            val listbuffer = new ListBuffer[JSONObject]()
            var key = x._1
            val bldMap = bldMapBroad.value
            val aoiMap = aoiMapBroad.value
            val dataList = x._2.toList
            var clusterBuffer: ListBuffer[ClusterWifiDataNew] = ListBuffer()
            var isBldFinger = "0"
            var error_finger_bld = ""
            var error_finger_aoi = ""
            var finger_detail = dataList.head.getString("finger_detail")
            var error_wifi = ""
            var isWifiAllError = false
            val obj = new JSONObject()
            if (StringUtils.nonEmpty(dataList.head.getString("finger_bld"))) {
                isBldFinger = "1"
            }

            if (isBldFinger.equals("1")) {
                calcClusterBySliceUpCoordinateNew(dataList, bldMap, clusterBuffer, "finger_bld")
                val (clusterBufferNew, errorFinger) = throwOverdueWifiNew(clusterBuffer, key.split("_")(1),"finger_bld")
                error_finger_bld = error_finger_bld + errorFinger
                clusterBuffer = clusterBufferNew
                isWifiAllError = judgeErrorWifiNew(clusterBuffer, "finger_bld")
            } else {
                calcClusterBySliceUpCoordinateNew(dataList, aoiMap, clusterBuffer, "finger_aoi")
                val (clusterBufferNew, errorFinger) = throwOverdueWifiNew(clusterBuffer, key.split("_")(1),"finger_aoi")
                error_finger_aoi = error_finger_aoi + errorFinger
                clusterBuffer = clusterBufferNew
                isWifiAllError = judgeErrorWifiNew(clusterBuffer, "finger_aoi")

            }

            if (isBldFinger.equals("1")) {
                for (i <- 0 until clusterBuffer.size) {
                    if (clusterBuffer(i).getErrorWifi) {
                        error_wifi = key.split("_")(1)
                        error_wifi = key
                        for (j <- 0 until clusterBuffer(i).getFingerList.size()) {
                            error_finger_bld = error_finger_bld + clusterBuffer(i).getFingerList().get(j).getString("finger_bld")
                        }
                    }
                    error_finger_aoi = dataList.head.getString("finger_aoi")

                }

            } else {
                for (i <- 0 until clusterBuffer.size) {
                    if (clusterBuffer(i).getErrorWifi) {
                        error_wifi = key.split("_")(1)
                        error_wifi = key

                        for (j <- 0 until clusterBuffer(i).getFingerList.size()) {
                            error_finger_aoi = error_finger_aoi + clusterBuffer(i).getFingerList().get(j).getString("finger_aoi")
                        }
                    }
                }
            }

            if (StringUtils.nonEmpty(error_finger_aoi) || StringUtils.nonEmpty(error_finger_bld)) {
                error_wifi = key

            }

            obj.put("error_wifi", error_wifi)
            obj.put("error_finger_aoi", error_finger_aoi)
            obj.put("error_finger_bld", error_finger_bld)
            obj.put("error_finger_detail", finger_detail)
            obj.put("isWifiAllError", isWifiAllError)

            listbuffer += obj

            listbuffer
        }).filter(obj=>StringUtils.nonEmpty(obj.getString("error_wifi"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("清洗完成数据量"+resultRdd.count())
        Spark.clearPersistWithoutId(spark,resultRdd.id)
        resultRdd


    }

    /**
     * 有性能问题，故弃用
     * @param spark
     * @param bldMapBroad
     * @param aoiMapBroad
     * @param bldWifiRdd
     * @param aoiWifiRdd
     * @return
     */
    def clusterWifiNew(spark:SparkSession,bldMapBroad:Broadcast[Map[String, String]],aoiMapBroad:Broadcast[Map[String, String]],bldWifiRdd:RDD[(String,JSONObject)],aoiWifiRdd:RDD[(String,JSONObject)])={
        var sql=
            """
              |
              |select * from dm_gis.wifi_finger_index_v1 where length(finger_aoi)<1600 and length(finger_bld)<1600
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val fingerBldNotEmptyRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("finger_bld")))
        val fingerBldEmptyRdd = dataRdd.filter(x => StringUtils.nonEmpty(x.getString("finger_bld")))

        val fingerBldWifiRdd = fingerBldNotEmptyRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {
                val finger_blds = obj.getString("finger_bld")
                val bldList = new ListBuffer[String]()
                splitFingerList(finger_blds, bldList)
                for (finger_bld <- bldList) {
                    if(StringUtils.nonEmpty(finger_bld)&&(!finger_bld.equals("8f00b204e9800998"))){
                        obj.put("finger_bld", finger_bld)
                        listbuffer += obj
                    }
                }

            }

            listbuffer.iterator
        }).filter(x => StringUtils.nonEmpty(x.getString("finger_bld"))&&(!x.getString("finger_bld").equals("8f00b204e9800998"))).map(x => (x.getString("finger_bld")+"_"+x.getString("key").split("_")(1), x)).leftOuterJoin(bldWifiRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.fluentPutAll(rightOp.get)

                }

            }

            leftObj


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联bld指纹数据量"+fingerBldWifiRdd.count())

        val fingerAoiWifiRdd = fingerBldEmptyRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]()
            for (obj <- x) {
                val finger_blds = obj.getString("finger_aoi")
                val bldList = new ListBuffer[String]()
                splitFingerList(finger_blds, bldList)
                for (finger_bld <- bldList) {
                    obj.put("finger_aoi", finger_bld)
                    listbuffer += obj

                }

            }

            listbuffer.iterator
        }).map(x => (x.getString("finger_aoi"), x)).leftOuterJoin(aoiWifiRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                if (rightOp.nonEmpty) {
                    leftObj.fluentPutAll(rightOp.get)

                }

            }

            leftObj


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联aoi指纹数据量"+fingerAoiWifiRdd.count())
        Spark.clearPersistWithoutIdList(spark,Array(fingerAoiWifiRdd.id,fingerBldWifiRdd.id))

        val resultRdd = fingerBldWifiRdd.union(fingerAoiWifiRdd).groupBy(x => x.getString("key")).flatMap(x => {
            val listbuffer = new ListBuffer[JSONObject]()
            var key = x._1
            val bldMap = bldMapBroad.value
            val aoiMap = aoiMapBroad.value
            val dataList = x._2.toList
            var clusterBuffer: ListBuffer[ClusterWifiDataNew] = ListBuffer()
            var isBldFinger = "0"
            var error_finger_bld = ""
            var error_finger_aoi = ""
            var finger_detail = dataList.head.getString("finger_detail")
            var error_wifi = ""
            var isWifiAllError = false
            val obj = new JSONObject()
            if (StringUtils.nonEmpty(dataList.head.getString("finger_bld"))) {
                isBldFinger = "1"
            }

            if (isBldFinger.equals("1")) {
                calcClusterBySliceUpCoordinateNew(dataList, bldMap, clusterBuffer, "finger_bld")
                val (clusterBufferNew, errorFinger) = throwOverdueWifiNew(clusterBuffer, key.split("_")(1),"finger_bld")
                error_finger_bld = error_finger_bld + errorFinger
                clusterBuffer = clusterBufferNew
                isWifiAllError = judgeErrorWifiNew(clusterBuffer, "finger_bld")
            } else {
                calcClusterBySliceUpCoordinateNew(dataList, aoiMap, clusterBuffer, "finger_aoi")
                val (clusterBufferNew, errorFinger) = throwOverdueWifiNew(clusterBuffer, key.split("_")(1),"finger_aoi")
                error_finger_bld = error_finger_bld + errorFinger
                clusterBuffer = clusterBufferNew
                isWifiAllError = judgeErrorWifiNew(clusterBuffer, "finger_aoi")

            }

            if (isBldFinger.equals("1")) {
                for (i <- 0 until clusterBuffer.size) {
                    if (clusterBuffer(i).getErrorWifi) {
                        error_wifi = key.split("_")(1)
                        error_wifi = key
                        for (j <- 0 until clusterBuffer(i).getFingerList.size()) {
                            error_finger_bld = error_finger_bld + clusterBuffer(i).getFingerList().get(j).getString("finger_bld")
                        }
                    }
                    error_finger_aoi = dataList.head.getString("finger_aoi")

                }

            } else {
                for (i <- 0 until clusterBuffer.size) {
                    if (clusterBuffer(i).getErrorWifi) {
                        error_wifi = key.split("_")(1)
                        error_wifi = key
                        error_finger_bld = ""
                        for (j <- 0 until clusterBuffer(i).getFingerList.size()) {
                            error_finger_aoi = error_finger_aoi + clusterBuffer(i).getFingerList().get(j).getString("finger_aoi")
                        }
                    }
                }
            }

            if (StringUtils.nonEmpty(error_finger_aoi) || StringUtils.nonEmpty(error_finger_bld)) {
                error_wifi = key

            }

            obj.put("error_wifi", error_wifi)
            obj.put("error_finger_aoi", error_finger_aoi)
            obj.put("error_finger_bld", error_finger_bld)
            obj.put("error_finger_detail", finger_detail)
            obj.put("isWifiAllError", isWifiAllError)

            listbuffer += obj

            listbuffer
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("清洗完成数据量"+resultRdd.count())
        Spark.clearPersistWithoutId(spark,resultRdd.id)


        resultRdd


    }

    /**
     * 标记错误wifi，最初版
     * @param spark
     * @param bldMapBroad
     * @param aoiMapBroad
     * @return
     */

    def clusterWifi(spark:SparkSession,bldMapBroad:Broadcast[Map[String, String]],aoiMapBroad:Broadcast[Map[String, String]])={
        var sql=
            """
              |
              |select * from dm_gis.wifi_finger_index_v1 where length(finger_aoi)<1600 and length(finger_bld)<1600
              |
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(spark, sql)
        val resultRdd = dataRdd.map(obj => {
            val bldMap = bldMapBroad.value
            val aoiMap = aoiMapBroad.value
            var isBldFinger = "0"
            var clusterBuffer: ListBuffer[ClusterWifiData] = ListBuffer()
            val bldList = new ListBuffer[String]()
            val aoiList = new ListBuffer[String]()
            var finger_bld = obj.getString("finger_bld")
            var key = obj.getString("key")
            var finger_aoi = obj.getString("finger_aoi")
            var finger_detail = obj.getString("finger_detail")
            var error_finger_bld = ""
            var error_finger_aoi = ""
            var error_wifi = ""
            splitFingerList(finger_bld, bldList)
            splitFingerList(finger_aoi, aoiList)
            var isWifiAllError = false

            /**
             * 初始化第一个指纹坐标为第一个聚合区域中心；
             *  计算第二个指纹坐标与第一个指纹坐标的距离，当距离小于300m时，将第二个指纹与第一个指纹归为一个聚合区域，聚类中心为第一个指纹和第二个指纹的平均坐标位置；否则，第二个指纹作为第二个聚合区域的中心点；
             *  分别计算第三个指纹坐标和之前所有的聚合区域中心点坐标的距离，当小于300m时，归为对应的聚合区域，否则单独作为新的聚合区域中心点；
             */
            if (StringUtils.nonEmpty(finger_bld)) {
                isBldFinger = "1"
                calcClusterBySliceUpCoordinate(bldList, bldMap, clusterBuffer)
            } else {
                calcClusterBySliceUpCoordinate(aoiList, aoiMap, clusterBuffer)
            }
            if (isBldFinger.equals("1")) {
                isWifiAllError = judgeErrorWifi(clusterBuffer)
            } else {
                isWifiAllError = judgeErrorWifi(clusterBuffer)

            }

            logger.error("聚类数量----》"+clusterBuffer.size)
            if (isBldFinger.equals("1")) {
                for (i <- 0 until clusterBuffer.size) {
                    if (clusterBuffer(i).getErrorWifi) {
                        error_wifi = key.split("_")(1)
                        error_wifi = key
                        error_finger_aoi = finger_aoi
                        for (j <- 0 until clusterBuffer(i).getFingerList.size()) {
                            error_finger_bld = error_finger_bld + clusterBuffer(i).getFingerList().get(j)
                        }
                    }


                }

            } else {
                for (i <- 0 until clusterBuffer.size) {
                    if (clusterBuffer(i).getErrorWifi) {
                        error_wifi = key.split("_")(1)
                        error_wifi= key
                        error_finger_bld = finger_bld
                        for (j <- 0 until clusterBuffer(i).getFingerList.size()) {
                            error_finger_aoi = error_finger_aoi + clusterBuffer(i).getFingerList().get(j)
                        }
                    }
                }


            }

            if(StringUtils.nonEmpty(error_finger_aoi)||StringUtils.nonEmpty(error_finger_bld)){
                error_wifi= key

            }

            obj.put("error_wifi", error_wifi)
            obj.put("error_finger_aoi", error_finger_aoi)
            obj.put("error_finger_bld", error_finger_bld)
            obj.put("error_finger_detail", finger_detail)
            obj.put("isWifiAllError", isWifiAllError)
            obj


        }).filter(obj=>StringUtils.nonEmpty(obj.getString("error_wifi"))).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("标记后数据量 ----> "+resultRdd.count())

        resultRdd



    }

    def throwOverdueWifiNew(clusterBuffer:ListBuffer[ClusterWifiDataNew],wifiKey:String,keyName:String) ={
        val nowTime = Math.round(System.currentTimeMillis()/1000)
        var clusterBufferNew = new ListBuffer[ClusterWifiDataNew]()
        var errorFinger=""
        if(clusterBuffer.size>=2){
            for(i<-0 until clusterBuffer.size){
                val clusterWifiData = clusterBuffer(i)
                val fingerList = clusterWifiData.getFingerList
                val fingerListNew = new util.ArrayList[JSONObject]()
                for(j<-0 until fingerList.size){
                    val finger_time = fingerList.get(j).getString("finger_time")
                    if(StringUtils.nonEmpty(finger_time)&&(nowTime-finger_time.toLong>2592000)){
                        errorFinger=errorFinger+fingerList.get(j).getString(keyName)
                        logger.error("errorFinger----->"+errorFinger)
//                        Thread.sleep(100000)

                    }else{
                        fingerListNew.add(fingerList.get(j))
                    }
                }

                if(fingerListNew.size()>0){
                    clusterWifiData.setFingerList(fingerListNew)
                    clusterWifiData.setClusterNum(fingerListNew.size().toLong)
                    clusterBufferNew+=clusterWifiData

                }
            }

        }else{
            clusterBufferNew=clusterBuffer
        }
        (clusterBufferNew,errorFinger)

    }

    def throwOverdueWifi(clusterBuffer:ListBuffer[ClusterWifiData],wifiKey:String,bldWifiMap:Map[String,String]) ={
        val nowTime = Math.round(System.currentTimeMillis()/1000)
        var clusterBufferNew = new ListBuffer[ClusterWifiData]()
        var errorFinger=""
        if(clusterBuffer.size>=2){
            for(i<-0 until clusterBuffer.size){
                val clusterWifiData = clusterBuffer(i)
                val fingerList = clusterWifiData.getFingerList
                val fingerListNew = new util.ArrayList[String]()
                for(j<-0 until fingerList.size){
                    if(bldWifiMap.contains(fingerList.get(i))){
                        val wifi_list = bldWifiMap.get(fingerList.get(j)).get
                        try{
                            breakable {
                                val wifiArr = JSON.parseArray(wifi_list)
                                for(k<-0 until wifiArr.size){
                                    val wifi = wifiArr.getJSONObject(k)
                                    val mac = wifi.getString("mac")
                                    val timeStamp = wifi.getString("time")
                                    if(StringUtils.nonEmpty(wifiKey)&&StringUtils.nonEmpty(mac)&&StringUtils.nonEmpty(timeStamp)&&wifiKey.equals(mac)){
                                        if(nowTime-timeStamp.toLong>2592000){
                                            errorFinger=errorFinger+fingerList.get(j)
                                            break()


                                        }else{
                                            fingerListNew.add(fingerList.get(j))
                                            break()

                                        }

                                    }

                                }


                            }

                        }catch {case e:Exception=>logger.error(e.getStackTrace)}


                    }

                }

                if(fingerListNew.size()>0){
                    clusterWifiData.setFingerList(fingerListNew)
                    clusterWifiData.setClusterNum(fingerListNew.size().toLong)
                    clusterBufferNew+=clusterWifiData

                }



            }

        }else{
            clusterBufferNew=clusterBuffer
        }
        (clusterBufferNew,errorFinger)

    }

    def judgeErrorWifiNew(clusterBuffer:ListBuffer[ClusterWifiDataNew],keyName:String) ={
        var maxClusterNum=0L
        var clusterNumDiff=0L
        var clusterNumTotal=0L
        var finger_bld = ""
        var isWifiAllError=false
        if(clusterBuffer.size>2){
            for(i<-0 until clusterBuffer.size){
                if(clusterBuffer(i).getClusterNum>maxClusterNum){
                    maxClusterNum=clusterBuffer(i).getClusterNum
                }
            }
            for(i<-0 until clusterBuffer.size){
                if(clusterBuffer(i).getClusterNum!=maxClusterNum){
                    clusterNumTotal=clusterNumTotal+clusterBuffer(i).getClusterNum
                }
            }
            clusterNumDiff=maxClusterNum-clusterNumTotal
            if(math.abs(clusterNumDiff)<3){
                isWifiAllError=true
            }

            for(i<-0 until clusterBuffer.size){
                if(!(clusterBuffer(i).getClusterNum==maxClusterNum&&clusterNumDiff>=5)){
                    clusterBuffer(i).setErrorWifi(true)
                }else{
                    if(clusterBuffer(i).getClusterNum==maxClusterNum&&clusterNumDiff>=5){
                        for(j<-0 until clusterBuffer(i).getFingerList.size()){
                            finger_bld=finger_bld+clusterBuffer(i).getFingerList().get(j).getString(keyName)
                        }
                    }




                }

            }

        }else if (clusterBuffer.size==2){
            clusterNumDiff=clusterBuffer(0).getClusterNum-clusterBuffer(1).getClusterNum
            if(clusterNumDiff>=3){
                clusterBuffer(1).setErrorWifi(true)
                for(j<-0 until clusterBuffer(0).getFingerList.size()){
                    finger_bld=finger_bld+clusterBuffer(0).getFingerList().get(j).getString(keyName)
                }

            }else if(clusterNumDiff<(-3)){
                clusterBuffer(0).setErrorWifi(true)
                for(j<-0 until clusterBuffer(1).getFingerList.size()){
                    finger_bld=finger_bld+clusterBuffer(1).getFingerList().get(j).getString(keyName)
                }

            }else{
                clusterBuffer(0).setErrorWifi(true)
                clusterBuffer(1).setErrorWifi(true)
                isWifiAllError=true

            }

        }else {
            //            for(j<-0 until clusterBuffer(0).getFingerList.size()){
            //                finger_bld=finger_bld+clusterBuffer(0).getFingerList().get(j)
            //            }

        }
        isWifiAllError

    }

    def judgeErrorWifi(clusterBuffer:ListBuffer[ClusterWifiData]) ={
        var maxClusterNum=0L
        var clusterNumDiff=0L
        var clusterNumTotal=0L
        var finger_bld = ""
        var isWifiAllError=false
        if(clusterBuffer.size>2){
            for(i<-0 until clusterBuffer.size){
                if(clusterBuffer(i).getClusterNum>maxClusterNum){
                    maxClusterNum=clusterBuffer(i).getClusterNum
                }
            }
            for(i<-0 until clusterBuffer.size){
                if(clusterBuffer(i).getClusterNum!=maxClusterNum){
                    clusterNumTotal=clusterNumTotal+clusterBuffer(i).getClusterNum
                }
            }
            clusterNumDiff=maxClusterNum-clusterNumTotal
            if(math.abs(clusterNumDiff)<3){
                isWifiAllError=true
            }

            for(i<-0 until clusterBuffer.size){
                if(!(clusterBuffer(i).getClusterNum==maxClusterNum&&clusterNumDiff>=5)){
                    clusterBuffer(i).setErrorWifi(true)
                }else{
                    if(clusterBuffer(i).getClusterNum==maxClusterNum&&clusterNumDiff>=5){
                        for(j<-0 until clusterBuffer(i).getFingerList.size()){
                            finger_bld=finger_bld+clusterBuffer(i).getFingerList().get(j)
                        }
                    }




                }

            }

        }else if (clusterBuffer.size==2){
            clusterNumDiff=clusterBuffer(0).getClusterNum-clusterBuffer(1).getClusterNum
            if(clusterNumDiff>=3){
                clusterBuffer(1).setErrorWifi(true)
                for(j<-0 until clusterBuffer(0).getFingerList.size()){
                    finger_bld=finger_bld+clusterBuffer(0).getFingerList().get(j)
                }

            }else if(clusterNumDiff<(-3)){
                clusterBuffer(0).setErrorWifi(true)
                for(j<-0 until clusterBuffer(1).getFingerList.size()){
                    finger_bld=finger_bld+clusterBuffer(1).getFingerList().get(j)
                }

            }else{
                clusterBuffer(0).setErrorWifi(true)
                clusterBuffer(1).setErrorWifi(true)
                isWifiAllError=true

            }

        }else {
//            for(j<-0 until clusterBuffer(0).getFingerList.size()){
//                finger_bld=finger_bld+clusterBuffer(0).getFingerList().get(j)
//            }

        }
        isWifiAllError

    }

    def calcClusterBySliceUpCoordinateNew(bldList:List[JSONObject],bldMap:Map[String,String],clusterBuffer:ListBuffer[ClusterWifiDataNew],keyName:String)={

        val clusterMap = new mutable.HashMap[String, ClusterWifiDataNew]()
        for(i<- 0 until bldList.size){
            val fingerObj = bldList(i)
            val fingerKey=fingerObj.getString(keyName)
            if(bldMap.contains(fingerKey)){
                val bldPoint = bldMap.getOrElse(fingerKey, "")
                val key = sliceUpCoordinate(bldPoint.split(",")(0), bldPoint.split(",")(1),0.003)
                if(clusterMap.contains(key)){
                    val clusterData=clusterMap.get(key).get
                    val points = clusterData.getPoints
                    val list = clusterData.getFingerList
                    points.add(bldPoint)
                    list.add(bldList(i))
                    val (lng,lat) = calcPoint(points)
                    clusterData.setClusterNum(clusterData.getClusterNum+1)
                    clusterData.setLng(lng.toString)
                    clusterData.setLat(lat.toString)
                    clusterData.setPoints(points)
                    clusterData.setFingerList(list)
                    clusterMap.put(key,clusterData)

                }else{
                    val lngkey1 = key.split("-")(0)
                    val latkey1 = key.split("-")(1)
                    var flag=true
                    /*
                    判断新的key和历史的key相差是否小于2，小于则认为两个key是一致的
                     */
                    breakable{
                        for(mapKey<-clusterMap.keySet){
                            val lngkey2 = mapKey.split("-")(0)
                            val latkey2 = mapKey.split("-")(1)
                            if(math.abs(lngkey1.toLong-lngkey2.toLong)<=2&&math.abs(latkey1.toLong-latkey2.toLong)<=2){
                                val clusterData=clusterMap.get(mapKey).get
                                val points = clusterData.getPoints
                                val list = clusterData.getFingerList
                                points.add(bldPoint)
                                list.add(bldList(i))
                                val (lng,lat) = calcPoint(points)
                                clusterData.setClusterNum(clusterData.getClusterNum+1)
                                clusterData.setLng(lng.toString)
                                clusterData.setLat(lat.toString)
                                clusterData.setPoints(points)
                                clusterData.setFingerList(list)
                                clusterMap.put(mapKey,clusterData)
                                flag=false
                                break
                            }
                        }

                    }
                    if(flag){
                        val data = new ClusterWifiDataNew
                        val fingerList = new util.ArrayList[JSONObject]()
                        val pointsList = new util.ArrayList[String]()
                        fingerList.add(bldList(i))
                        pointsList.add(bldPoint)
                        data.setClusterNum(1L)
                        data.setLng(bldPoint.split(",")(0))
                        data.setLat(bldPoint.split(",")(1))
                        data.setFingerList(fingerList)
                        data.setPoints(pointsList)
                        clusterMap.put(key,data)
                    }
                }
            }
        }
        if(clusterMap.size>1){
            for(clusterData<-clusterMap.values){
                clusterBuffer+=clusterData
            }

        }





    }

    def calcClusterBySliceUpCoordinate(bldList:ListBuffer[String],bldMap:Map[String,String],clusterBuffer:ListBuffer[ClusterWifiData])={
        val clusterMap = new mutable.HashMap[String, ClusterWifiData]()
        for(i<- 0 until bldList.size){
            if(bldMap.contains(bldList(i))){
                val bldPoint = bldMap.getOrElse(bldList(i), "")
                var key=""
                if(StringUtils.nonEmpty(bldPoint)&&bldPoint.split(",").size>1&&StringUtils.nonEmpty(bldPoint.split(",")(0))&&StringUtils.nonEmpty(bldPoint.split(",")(1))){
                    key = sliceUpCoordinate(bldPoint.split(",")(0), bldPoint.split(",")(1),0.003)
                }
                if(clusterMap.contains(key)){
                    val clusterData=clusterMap.get(key).get
                    val points = clusterData.getPoints
                    val list = clusterData.getFingerList
                    points.add(bldPoint)
                    list.add(bldList(i))
                    val (lng,lat) = calcPoint(points)
                    clusterData.setClusterNum(clusterData.getClusterNum+1)
                    clusterData.setLng(lng.toString)
                    clusterData.setLat(lat.toString)
                    clusterData.setPoints(points)
                    clusterData.setFingerList(list)
                    clusterMap.put(key,clusterData)

                }else{
                    val lngkey1 = key.split("-")(0)
                    val latkey1 = key.split("-")(1)
                    var flag=true
                    /*
                    判断新的key和历史的key相差是否小于2，小于则认为两个key是一致的
                     */
                    breakable{
                        for(mapKey<-clusterMap.keySet){
                            val lngkey2 = mapKey.split("-")(0)
                            val latkey2 = mapKey.split("-")(1)
                            if(math.abs(lngkey1.toLong-lngkey2.toLong)<=2&&math.abs(latkey1.toLong-latkey2.toLong)<=2){
                                val clusterData=clusterMap.get(mapKey).get
                                val points = clusterData.getPoints
                                val list = clusterData.getFingerList
                                points.add(bldPoint)
                                list.add(bldList(i))
                                val (lng,lat) = calcPoint(points)
                                clusterData.setClusterNum(clusterData.getClusterNum+1)
                                clusterData.setLng(lng.toString)
                                clusterData.setLat(lat.toString)
                                clusterData.setPoints(points)
                                clusterData.setFingerList(list)
                                clusterMap.put(mapKey,clusterData)
                                flag=false
                                break
                            }
                        }

                    }
                    if(flag){
                        val data = new ClusterWifiData
                        val fingerList = new util.ArrayList[String]()
                        val pointsList = new util.ArrayList[String]()
                        fingerList.add(bldList(i))
                        pointsList.add(bldPoint)
                        data.setClusterNum(1L)
                        data.setLng(bldPoint.split(",")(0))
                        data.setLat(bldPoint.split(",")(1))
                        data.setFingerList(fingerList)
                        data.setPoints(pointsList)
                        clusterMap.put(key,data)
                    }
                }
            }
        }
        if(clusterMap.size>1){
            for(clusterData<-clusterMap.values){
                clusterBuffer+=clusterData
            }

        }





    }

    def calcCluster(bldList:ListBuffer[String],bldMap:Map[String,String],clusterBuffer:ListBuffer[ClusterWifiData]): Unit ={

        for(i<- 0 until bldList.size){
            if(bldMap.contains(bldList(i))){
                logger.error("包含对应key")
                val bldPoint = bldMap.getOrElse(bldList(i), "")
                if(clusterBuffer.size==0){
                    val data = new ClusterWifiData
                    val fingerList = new util.ArrayList[String]()
                    val pointsList = new util.ArrayList[String]()
                    fingerList.add(bldList(i))
                    pointsList.add(bldPoint)
                    data.setClusterNum(1L)
                    data.setLng(bldPoint.split(",")(0))
                    data.setLat(bldPoint.split(",")(1))
                    data.setFingerList(fingerList)
                    data.setPoints(pointsList)
                    clusterBuffer+=data

                }else{
                    breakable {
                        for(j<-0 until  clusterBuffer.size){
                            val clusterData=clusterBuffer(j)
                            if(StringUtils.nonEmpty(clusterData.getLng)&&StringUtils.nonEmpty(clusterData.getLat)&&StringUtils.nonEmpty(bldPoint.split(",")(0))&&StringUtils.nonEmpty(bldPoint.split(",")(1))){
                                val d = GeometryUtil.getDistance(clusterData.getLng, clusterData.getLat, bldPoint.split(",")(0), bldPoint.split(",")(1))
                                if(d<300.0&&d>=0.0){
                                    val points = clusterData.getPoints
                                    val list = clusterData.getFingerList
                                    points.add(bldPoint)
                                    list.add(bldList(i))
                                    val (lng,lat) = calcPoint(points)
                                    clusterData.setClusterNum(clusterData.getClusterNum+1)
                                    clusterData.setLng(lng.toString)
                                    clusterData.setLat(lat.toString)
                                    clusterData.setPoints(points)
                                    clusterData.setFingerList(list)
                                    break

                                }else if(d>300){
                                    val data = new ClusterWifiData
                                    val fingerList = new util.ArrayList[String]()
                                    val pointsList = new util.ArrayList[String]()
                                    fingerList.add(bldList(i))
                                    pointsList.add(bldPoint)
                                    data.setClusterNum(1L)
                                    data.setLng(bldPoint.split(",")(0))
                                    data.setLat(bldPoint.split(",")(1))
                                    data.setFingerList(fingerList)
                                    data.setPoints(pointsList)
                                    clusterBuffer+=data

                                }
                                else{
                                    if(j==clusterBuffer.size-1){
                                        val data = new ClusterWifiData
                                        val fingerList = new util.ArrayList[String]()
                                        val pointsList = new util.ArrayList[String]()
                                        fingerList.add(bldList(i))
                                        pointsList.add(bldPoint)
                                        data.setClusterNum(1)
                                        data.setLng(bldPoint.split(",")(0))
                                        data.setLat(bldPoint.split(",")(1))
                                        data.setFingerList(fingerList)
                                        data.setPoints(pointsList)
                                        clusterBuffer+=data

                                    }
                                }
                            }
                        }
                    }
                }

            }else{


            }


        }




    }

    def calcPoint(points:util.List[String]) ={
        var lngall=0.0
        var latall=0.0
        var lng=0.0
        var lat=0.0
        for(i<- 0 until points.size()){
            lngall=lngall+points.get(i).split(",")(0).toDouble
            latall=latall+points.get(i).split(",")(1).toDouble

        }
        lng=lngall/points.size()
        lat=latall/points.size()
        (lng,lat)

    }

    def splitFingerList(fingerList:String,fingerSet:mutable.ListBuffer[String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/16){
                    fingerSet+=(fingerList.substring(i*16,(i+1)*16))

                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }


    def splitFingerAoi(fingerList:String,fingerSet:mutable.ListBuffer[String]): Unit ={
        try {
            if(fingerList.length>0){
                for(i<- 0 until fingerList.length/19){
                    val finger_aoi = fingerList.substring(i * 19, (i + 1) * 19)
                    fingerSet+=finger_aoi.substring(0,16)
                }
            }
        }catch {case e:Exception=>{
            logger.error("error finger ---->"+fingerList)
        }}




    }




}
