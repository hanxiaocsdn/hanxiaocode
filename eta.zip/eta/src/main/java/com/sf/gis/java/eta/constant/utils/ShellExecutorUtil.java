package com.sf.gis.java.eta.constant.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Serializable;

public class ShellExecutorUtil implements Serializable{
	private  static Logger logger = LoggerFactory.getLogger(ShellExecutorUtil.class);
	public static void exeCmd(String cmd) throws Exception {
		String os = System.getProperty("os.name");
		String [] shell;
		if(os.toLowerCase().contains("windows")){
			shell =new String[]{"cmd","/C",cmd}; 
		}else if (os.toLowerCase().contains("linux")){
			shell =new String[]{"/bin/sh","-c",cmd}; 
		}else{
			throw new Exception("not support os:"+os); 
		}
		try {
			Runtime runtime = Runtime.getRuntime();
            final Process process = runtime.exec(shell);
            StreamHandlerUtil errorStreamHandlerUtil = new StreamHandlerUtil(process.getErrorStream());
            errorStreamHandlerUtil.start();
            process.waitFor();
		} catch (IOException e1) {
			logger.error("cmd: "+cmd +", exception:"+e1.getMessage());
		}
	}
	
}
