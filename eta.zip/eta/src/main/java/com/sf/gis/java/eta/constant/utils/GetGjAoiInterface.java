package com.sf.gis.java.eta.constant.utils;

import com.alibaba.fastjson.JSONObject;

import java.io.UnsupportedEncodingException;

public class GetGjAoiInterface {

    public static String getContent(String url ,JSONObject json){

        try {
            return HttpClientUtils.httpPostRequest(url,json.toString()).toString();
        } catch (Exception e) {
            System.out.println("调用轨迹纠偏端口出现异常");
            e.printStackTrace();
        }
        return "";
    }

    public static String getContent(String url ,String json){

        try {
            return HttpClientUtils.httpPostRequest(url,json.toString()).toString();
        } catch (Exception e) {
            System.out.println("调用轨迹纠偏端口出现异常");
            e.printStackTrace();
        }
        return "";
    }


}
