package com.sf.gis.java.eta.constant;

/**
 * 常量类
 * @author: 01370539 Created On: May.07 2021
 */
public class EtaConstant {
}
