package com.sf.gis.java.eta.constant.utils;

import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * HTTP get请求,ak传入header中
 */
public class HttpSetHeader {

	private static final Logger logger = LoggerFactory.getLogger(HttpSetHeader.class);

    private static final PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static CloseableHttpClient httpClient = null;
    private static boolean isInitConnection = false;

    static {
        initConnectionManager();
    }

    /**
     * 初始化连接池
     */
    public static void initConnectionManager() {
        try {
            connManager.setMaxTotal(5); // 设置整个连接池最大连接数 根据自己的场景决定
            // 是路由的默认最大连接（该值默认为2），限制数量实际使用DefaultMaxPerRoute并非MaxTotal。设置过小无法支持大并发(ConnectionPoolTimeoutException: Timeout waiting for connection from pool)，路由是对maxTotal的细分。
            connManager.setDefaultMaxPerRoute(5);// （目前只有一个路由，因此让他等于最大值）
            SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setSoTimeout(40000).setTcpNoDelay(true).build();
            connManager.setDefaultSocketConfig(socketConfig);

            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(40000).setConnectTimeout(40000).setSocketTimeout(40000).build();
            httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(connManager).build();
        } catch (Exception e) {
            logger.error("initConnectionManager error. ", e);
        }
    }

    /**
     * 进行get请求
     * @param url 请求路径
     * @param charset 编码格式
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    @SuppressWarnings("BusyWait")
    public static String sendGet(String url, String charset, int maxTryTime){
        String jsonStr = sendGet(url, charset);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(jsonStr) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                if (StringUtils.isNotEmpty(charset)) {
                    jsonStr = sendGet(url, charset);
                } else {
                    jsonStr = sendGet(url, FixedConstant.CHARSET_UTF);
                }
            }
            Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(jsonStr), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                jsonStr = HttpSetHeader.sendGet(url, maxTryTime);
            }
        }catch (Exception e) {

        }
        return jsonStr;
    }

    private static boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet){
        int status = json.getInteger("status");
        if(status != 1){
            return false;
        }
        try{
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e){
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }


    /**
     * 进行get请求
     * @param url 请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static String sendGet(String url, int maxTryTime){
        return sendGet(url, null, maxTryTime);
    }

    private static String sendGet(String url, String charset) {
        logger.debug("start send get, url - {}.", url);
        String jsonStr = "";
        HttpGet get = null;
        CloseableHttpResponse response = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }
            get = new HttpGet(url);
            get.addHeader("ak","54eecb081f514cb6a6b70efceb5d766a");
            response = httpClient.execute(get);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, charset);

        } catch (Exception e) {
            logger.error("execute access http get url err. " + url, e);
            return jsonStr;
        } finally {
            try {
                if (jsonStr != null) {
                    if (get != null) {
                        EntityUtils.consume(entity);
                        get.releaseConnection();
                    }
                    if (response != null) {
                        response.close();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        logger.debug("end get， url - {}.", url);
        return jsonStr;
    }

}
