package com.sf.gis.java.eta.constant.StandardRouteMileage;

import java.io.UnsupportedEncodingException;

public class CalAngleUtils {

    public static double calAngle(double[] o, double[] s, double[] e) {

        double cosfi = 0;
        double fi = 0;
        double norm = 0;
        double dsx = s[0] - o[0];
        double dsy = s[1] - o[1];
        double dex = e[0] - o[0];
        double dey = e[1] - o[1];
        cosfi = dsx * dex + dsy * dey;
        norm = (dsx * dsx + dsy * dsy) * (dex * dex + dey * dey);
        cosfi /= Math.sqrt(norm);
        if (cosfi >= 1.0) return 0;
        if (cosfi <= -1.0) return Math.PI;
        fi = Math.acos(cosfi);

        if (180 * fi / Math.PI < 180) {
            return 180 * fi / Math.PI;
        } else {
            return 360 - 180 * fi / Math.PI;
        }
    }



    public static double calAngle2(double[] o, double[] s, double[] e) {

        double a = Math.sqrt((s[0] - e[0]) * (s[0] - e[0]) + (s[1] - e[1]) * (s[1] - e[1]));
        double b = Math.sqrt((o[0] - e[0]) * (o[0] - e[0]) + (o[1] - e[1]) * (o[1] - e[1]));
        double c = Math.sqrt((o[0] - s[0]) * (o[0] - s[0]) + (o[1] - s[1]) * (o[1] - s[1]));

        double A = Math.toDegrees(Math.acos((a * a - b * b - c * c) / (-2 * b * c)));
        double B = Math.toDegrees(Math.acos((b * b - a * a - c * c) / (-2 * a * c)));
        double C = Math.toDegrees(Math.acos((c * c - a * a - b * b) / (-2 * a * b)));

        return B;
    }

    // https://blog.csdn.net/reborn_lee/article/details/82497577
//     将地理经纬度转换成笛卡尔坐标系
    public static LatLng geo2xyz(double lat, double lng) {
        double thera = (Math.PI * lat) / 180;
        double fie  = (Math.PI * lng) / 180;
        return ball2xyz(thera, fie,6400);
    }
    // lat,lng为弧度表示的经纬度，r为地球半径，因为是算夹角，r是多少不重要
    public static LatLng ball2xyz(double lat, double lng, int r) {
        double x = r * Math.cos(lat) * Math.cos(lng);
        double y = r * Math.cos(lat) * Math.sin(lng);
       // double z = r * Math.sin(lat);
        //x: r * Math.cos(lat) * Math.cos(lng),
//                y: r * Math.cos(lat) * Math.sin(lng),
//                z: r * Math.sin(lat)
        return new LatLng(x,y);
    }


//    function angleOflocation(l1, l2, l3) {





        public static void main(String[] args) throws UnsupportedEncodingException {
//            val doubleA = Array[Double](114.078716040,22.607266111)
//            val doubleB = Array[Double](114.079756737,22.609504498)
//            val doubleC = Array[Double](114.086941034,22.569687221)
//

        double[] a = new double[]{114.078716040,22.607266111};
        double[] b = {114.079756737,22.609504498};
        double[] c = new double[]{114.086941034,22.569687221};
        System.out.println(calAngle2(a, b, c));
    }

}
