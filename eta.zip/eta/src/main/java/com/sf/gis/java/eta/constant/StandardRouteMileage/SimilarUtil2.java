package com.sf.gis.java.eta.constant.StandardRouteMileage;

import com.huaban.analysis.jieba.JiebaSegmenter;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class SimilarUtil2 {


    private static Logger logger = Logger.getLogger(SimilarUtil2.class);

    public static void main(String[] args) {

        Map<String, Float> csvMap = getCsvMap("d:\\user\\01401062\\桌面\\hangzhoumap.csv");



        System.out.println(similarity("bbbbbbbbbbbb区菜鸟驿站","a区菜鸟驿站",csvMap));
//        System.out.println(similarity("白石洲东2坊", "白石洲东1坊"));
//        System.out.println(similarity("西门","南门"));
    }

    public static double similarity(String pre, String aft, Map<String, Float> csvmap) {
        if (StringUtils.isBlank(pre) || StringUtils.isBlank(aft)) {
            return 0L;
        }

        if (pre.equals(aft)) {
            return 1L;
        }


        JiebaSegmenter jieba = new JiebaSegmenter();
        List<String> preList = jieba.sentenceProcess(pre);
        List<String> aftList = jieba.sentenceProcess(aft);
        System.out.println(preList);
        System.out.println(aftList);
        return getSimilarity(preList, aftList,csvmap);

    }

    private static double getSimilarity(List<String> words1, List<String> words2, Map<String, Float> csvmap) {
        double score = getSimilarityImpl(words1, words2,csvmap);

        //(int) (score * 1000000 + 0.5)其实代表保留小数点后六位 ,因为1034234.213强制转换不就是1034234。对于强制转换添加0.5就等于四舍五入
        score = (int) (score * 1000000 + 0.5) / (double) 1000000;

        return score;

    }


    /**
     * 文本相似度计算 判定方式：余弦相似度，通过计算两个向量的夹角余弦值来评估他们的相似度 余弦夹角原理： 向量a=(x1,y1),向量b=(x2,y2) similarity=a.b/|a|*|b| a.b=x1x2+y1y2
     * |a|=根号[(x1)^2+(y1)^2],|b|=根号[(x2)^2+(y2)^2]
     */
    private static double getSimilarityImpl(List<String> words1, List<String> words2, Map<String, Float> csvmap) {


        //获取权重值
        Map<String, Float> weightMap1 = getFastSearchMap(words1,csvmap);
        Map<String, Float> weightMap2 = getFastSearchMap(words2,csvmap);


        //将所有词都装入set容器中
        //Set容器无序 不重复
        Set<String> words = new HashSet<String>();
        words.addAll(words1);
        words.addAll(words2);

        AtomicFloat ab = new AtomicFloat();// a.b
        AtomicFloat aa = new AtomicFloat();// |a|的平方
        AtomicFloat bb = new AtomicFloat();// |b|的平方


        // 第三步：写出词频向量，后进行计算
        words.parallelStream().forEach(word -> {
            //看同一词在a、b两个集合出现的此次
            Float  x1 = weightMap1.get(word);
            Float  x2 = weightMap2.get(word);
            if (x1 != null && x2 != null) {
                //x1x2
                float oneOfTheDimension = x1 * x2;
                //+
                ab.addAndGet(oneOfTheDimension);
            }
            if (x1 != null) {
                //(x1)^2
                float oneOfTheDimension = x1 * x1;
                //+
                aa.addAndGet(oneOfTheDimension);
            }
            if (x2 != null) {
                //(x2)^2
                float oneOfTheDimension = x2 * x2;
                //+
                bb.addAndGet(oneOfTheDimension);
            }
        });
        //|a| 对aa开方
        double aaa = Math.sqrt(aa.doubleValue());
        //|b| 对bb开方
        double bbb = Math.sqrt(bb.doubleValue());

        //使用BigDecimal保证精确计算浮点数
        //double aabb = aaa * bbb;
        BigDecimal aabb = BigDecimal.valueOf(aaa).multiply(BigDecimal.valueOf(bbb));

        //similarity=a.b/|a|*|b|
        //divide参数说明：aabb被除数,9表示小数点后保留9位，最后一个表示用标准的四舍五入法
        double cos = BigDecimal.valueOf(ab.get()).divide(aabb, 3, BigDecimal.ROUND_HALF_UP).doubleValue();
        return cos;


    }

    /**
     * 构造权重快速搜索容器
     */
    protected static Map<String, Float> getFastSearchMap(List<String> words,Map<String, Float> weightMapAll) {
//        if (CollectionUtils.isEmpty(words)) {
//            return Collections.emptyMap();
//        }
//        //使用Map<String, Float>容器
       // Map<String, Float> weightMapAll = getCsvMap("d:\\user\\01401062\\桌面\\hangzhoumap.csv");
        //Map<String, Float> weightMapAll = new ConcurrentHashMap<String, Float>();

//        weightMapAll.put("鼓酷",5.4f);
//        weightMapAll.put("音乐",2f);
//        weightMapAll.put("艺术",2.176f);
//        weightMapAll.put("中心",1.477f);
//        weightMapAll.put("佳艺",5.4f);


        Map<String, Float> weightMap = new ConcurrentHashMap<String, Float>(words.size());

        for(int i = 0;i<words.size();i++){
            String key = words.get(i);
            Float ratio = 1f;
            if(!weightMapAll.getOrDefault(key,1f).isNaN()){
                ratio = weightMapAll.getOrDefault(key,1f);
            }
            weightMap.put(key,ratio);
        }


        return weightMap;
    }





    public static Map<String, Float> getCsvMap(String path){

        Map<String, Float> weightMapAll = new ConcurrentHashMap<String, Float>();
        try {
            //(文件完整路径),编码格式
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"));//GBK
            String line = null;

            while ((line = reader.readLine()) != null) {
                String[] split = line.split(",");//CSV格式文件时候的分割符,我使用的是,号
                String keyword = "";
                float ratio = 1f;

                try {
                    keyword = split[0];
                    ratio = Float.parseFloat(split[1]);

                } catch (Exception e) {
                    e.printStackTrace();
                }
                weightMapAll.put(keyword, ratio);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return weightMapAll;
    }



}
