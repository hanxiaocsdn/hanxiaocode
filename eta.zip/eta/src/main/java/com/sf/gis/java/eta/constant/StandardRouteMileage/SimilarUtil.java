//package com.sf.gis.java.eta.constant.StandardRouteMileage;
//
//import Utils.StringUtil;
//import com.huaban.analysis.jieba.JiebaSegmenter;
//import org.apache.commons.lang.StringUtils;
//import org.apache.log4j.Logger;
//
//import java.io.BufferedReader;
//import java.io.FileInputStream;
//import java.io.InputStreamReader;
//import java.math.BigDecimal;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//import java.util.concurrent.ConcurrentHashMap;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//public class SimilarUtil {
//
//    public static Map<String, Float> csvMap ;
//
//
//    private static Logger logger = Logger.getLogger(SimilarUtil.class);
//
//
//    public static void main(String[] args) {
//        //提供一个方法：初始化，返回一个数据类型，对象集合；；；；处理的时候，每个开方方法都需要传入初始化的返回的集合；
//        // l;;封装一个处理类，构造的时候传入这个数据集合，最好是静态，防止内存泄露
//       // Map<String, Float> csvMap = getCsvMap("d:\\user\\01401062\\桌面\\hangzhoumap.csv");
//
//        init("d:\\user\\01401062\\桌面\\hangzhoumap.csv");
//        Map<String, Double> resMap = new ConcurrentHashMap<String, Double>();
////
////        try {
////            //(文件完整路径),编码格式
////            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("d:\\user\\01401062\\桌面\\lyt2-20210520.csv"), "utf-8"));
////            //CsvReader creader = new CsvReader(reader, ',');
////            String line = null;
////            //while(creader.readRecord()){
////            while ((line = reader.readLine()) != null) {
////                //line = creader.getRawRecord();//读取一行数据
////                String[] split = line.split(",");//CSV格式文件时候的分割符,我使用的是,号
////                String keyword1 = "";
////                String keyword2 = "";
//////                String index = "";
//////                String id ="";
//////                String txt_13_18 = "";
//////                String req_comp_name = "";
//////                String aoiid ="";
//////                String poi_name ="";
////
////                Double ratio = 0d;
////
////
////                try {
////                    keyword1=split[0];
////                    keyword2=split[1];
////
//////                    index = split[0];
//////                    id = split[1];
//////                    txt_13_18 = split[2];
//////                    req_comp_name =split[3];
//////                    aoiid = split[4];
//////                    poi_name = split[5];
////
////
//////                    keyword1 = split[0];
//////                    keyword2 = split[1];
//////                    ratio_cur = split[2];
////                    long startTime = System.currentTimeMillis();    //获取开始时间
////                    ratio = similarity(keyword1,keyword2,csvMap);
////                    long endTime = System.currentTimeMillis();    //获取开始时间
////                    System.out.println("程序运行时间：" + (endTime - startTime) + "ms");    //输出程序运行时间
////                } catch (Exception e) {
////                    e.printStackTrace();
////                }
////                resMap.put(keyword1 + "_" + keyword2, ratio);
////            }
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////
////
////        try {
////            PrintStream ps = new PrintStream("d:\\user\\01401062\\桌面\\lyt2-20210520_out2.csv");
////            for (Map.Entry<String, Double> entry : resMap.entrySet()) {
////                System.setOut(ps);
////                System.out.println(entry.getKey() + "," + entry.getValue());
////
////            }
////        } catch (FileNotFoundException e) {
////            e.printStackTrace();
////        }
//
//        System.out.println(similarity("aaa菜鸟驿站","bbb菜鸟驿站",csvMap));
//
//    }
//
//    public static double similarity(String preString, String aftString, Map<String, Float> csvmap) {
//
//        String pre = fixString(preString);
//        String aft = fixString(aftString);
//
//
//        if (StringUtils.isBlank(pre) || StringUtils.isBlank(aft)) {
//            return 0L;
//        }
//
//        if (pre.equals(aft)) {
//            return 1L;
//        }
//
//
//        JiebaSegmenter jieba = new JiebaSegmenter();
//        List<String> preList = jieba.sentenceProcess(pre);
//        List<String> aftList = jieba.sentenceProcess(aft);
////        System.out.println(preList);
////        System.out.println(aftList);
//        return getSimilarity(preList, aftList,csvmap,pre,aft);
//
//    }
//
//    private static double getSimilarity(List<String> words1, List<String> words2, Map<String, Float> csvmap,String pre,String aft) {
//        double score = getSimilarityImpl(words1, words2,csvmap);
//
//        if(score > 0.5){
//
//            Pattern r = Pattern.compile("(([a-zA-Z0-9]+))");
//            Pattern r2 = Pattern.compile("((东北|东南|西北|西南|东|南|西|北))");
//            Matcher m1 = r.matcher(pre);
//            Matcher m2 = r.matcher(aft);
//            Matcher m21 = r2.matcher(pre);
//            Matcher m22  = r2.matcher(aft);
//
//            while (m1.find() && m2.find()){
//                String str1 = m1.group(1);
//                String str2 = m2.group(1);
//                if(StringUtil.isNotBlank(str1) && StringUtil.isNotBlank(str2) && !str1.equals(str2)){
//                    score = 0;
//                }
//            }
//
//            while (m22.find() && m21.find()){
//                String str21 = m21.group(1);
//                String str22 = m22.group(1);
//                if(StringUtil.isNotBlank(str21) && StringUtil.isNotBlank(str22) && !str21.equals(str22)){
//                    score = 0;
//                }
//            }
//        }
//
//        //(int) (score * 1000000 + 0.5)其实代表保留小数点后六位 ,因为1034234.213强制转换不就是1034234。对于强制转换添加0.5就等于四舍五入
//        score = (int) (score * 1000000 + 0.5) / (double) 1000000;
//
//        return score;
//
//    }
//
//
//    /**
//     * 文本相似度计算 判定方式：余弦相似度，通过计算两个向量的夹角余弦值来评估他们的相似度 余弦夹角原理： 向量a=(x1,y1),向量b=(x2,y2) similarity=a.b/|a|*|b| a.b=x1x2+y1y2
//     * |a|=根号[(x1)^2+(y1)^2],|b|=根号[(x2)^2+(y2)^2]
//     */
//    private static double getSimilarityImpl(List<String> words1, List<String> words2, Map<String, Float> csvmap) {
//
//
//        //获取权重值
//        Map<String, Float> weightMap1 = getFastSearchMap(words1,csvmap);
//        Map<String, Float> weightMap2 = getFastSearchMap(words2,csvmap);
//
//
//        //将所有词都装入set容器中
//        //Set容器无序 不重复
//        Set<String> words = new HashSet<String>();
//        words.addAll(words1);
//        words.addAll(words2);
//
//        AtomicFloat ab = new AtomicFloat();// a.b
//        AtomicFloat aa = new AtomicFloat();// |a|的平方
//        AtomicFloat bb = new AtomicFloat();// |b|的平方
//
//
//        // 第三步：写出词频向量，后进行计算
//        words.parallelStream().forEach(word -> {
//            //看同一词在a、b两个集合出现的此次
//            Float  x1 = weightMap1.get(word);
//            Float  x2 = weightMap2.get(word);
//            if (x1 != null && x2 != null) {
//                //x1x2
//                float oneOfTheDimension = x1 * x2;
//                //+
//                ab.addAndGet(oneOfTheDimension);
//            }
//            if (x1 != null) {
//                //(x1)^2
//                float oneOfTheDimension = x1 * x1;
//                //+
//                aa.addAndGet(oneOfTheDimension);
//            }
//            if (x2 != null) {
//                //(x2)^2
//                float oneOfTheDimension = x2 * x2;
//                //+
//                bb.addAndGet(oneOfTheDimension);
//            }
//        });
//        //|a| 对aa开方
//        double aaa = Math.sqrt(aa.doubleValue());
//        //|b| 对bb开方
//        double bbb = Math.sqrt(bb.doubleValue());
//
//        //使用BigDecimal保证精确计算浮点数
//        //double aabb = aaa * bbb;
//        BigDecimal aabb = BigDecimal.valueOf(aaa).multiply(BigDecimal.valueOf(bbb));
//
//        //similarity=a.b/|a|*|b|
//        //divide参数说明：aabb被除数,9表示小数点后保留9位，最后一个表示用标准的四舍五入法
//        double cos = BigDecimal.valueOf(ab.get()).divide(aabb, 3, BigDecimal.ROUND_HALF_UP).doubleValue();
//        return cos;
//
//
//    }
//
//    /**
//     * 构造权重快速搜索容器
//     */
//    protected static Map<String, Float> getFastSearchMap(List<String> words,Map<String, Float> weightMapAll) {
//
//
//        Map<String, Float> weightMap = new ConcurrentHashMap<String, Float>(words.size());
//
//        for(int i = 0;i<words.size();i++){
//            String key = words.get(i);
//            Float ratio = 1f;
//            if(!weightMapAll.getOrDefault(key,5f).isNaN()){
//                ratio = weightMapAll.getOrDefault(key,5f);
//            }
//            weightMap.put(key,ratio);
//        }
//
//
//        return weightMap;
//    }
//
//
//    public static String fixString(String str){
//
//        //过滤空值和空格
//        String trimStr = str.trim().toLowerCase().replaceAll("\\s*", "");
//
//        //替换快递柜和其它字段
//        //String normalizatiostr = trimStr.replaceAll("(丰巢|蜂巢|快递柜|自提柜|智能柜|自取柜)","丰巢快递柜");
//
//        return trimStr;
//
//    }
//
//
//
//    public static void init(String path){
//
//        Map<String, Float> weightMapAll = new ConcurrentHashMap<String, Float>();
//        try {
//            //(文件完整路径),编码格式
//            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"));//GBK
//            String line = null;
//
//            while ((line = reader.readLine()) != null) {
//                String[] split = line.split(",");//CSV格式文件时候的分割符,我使用的是,号
//                String keyword = "";
//                float ratio = 1f;
//
//                try {
//                    keyword = split[0];
//                    ratio = Float.parseFloat(split[1]);
//
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//                weightMapAll.put(keyword, ratio);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        csvMap = weightMapAll;
//    }
//
//
//
//}
