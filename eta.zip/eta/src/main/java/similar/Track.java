package similar;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/7/5
*/

class Track {

    double x;
    double y;

    public Track() {

    }

    public Track(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

}
