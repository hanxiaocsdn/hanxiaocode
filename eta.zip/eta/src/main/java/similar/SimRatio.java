package similar;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/7/12
*/

public class SimRatio {

    double sim1;
    double sim2;

    public SimRatio(double sim1, double sim2) {
        this.sim1 = sim1;
        this.sim2 = sim2;
    }

    public SimRatio() {

    }


}
