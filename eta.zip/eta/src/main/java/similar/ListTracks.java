package similar;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/7/12
*/

import java.util.List;

public class ListTracks {

    List<Track> list1;

    List<Track> list2;

    public ListTracks(List<Track> list1, List<Track> list2) {
        this.list1 = list1;
        this.list2 = list2;
    }
    public ListTracks() {
    }

    public List<Track> getList1() {
        return list1;
    }

    public void setList1(List<Track> list1) {
        this.list1 = list1;
    }

    public List<Track> getList2() {
        return list2;
    }

    public void setList2(List<Track> list2) {
        this.list2 = list2;
    }
}
