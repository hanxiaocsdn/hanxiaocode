package similar;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/8/10
*/

public class Tuple2<A, B> {
    public final A first;
    public final B second;

    public Tuple2(A a, B b) {
        this.first = a;
        this.second = b;
    }
}