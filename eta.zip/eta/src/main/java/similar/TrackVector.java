package similar;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/7/12
*/

public class TrackVector {
    double x;
    double y;

    public TrackVector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }


    public static TrackVector getVector(Track p0 , Track p1){

        double x = p0.getX() - p1.getX();
        double y = p0.getY() - p1.getY();

        TrackVector vc = new TrackVector(x,y);
        return vc;
    }

    public static double dot(TrackVector va, TrackVector vb){

        return va.getX() * vb.getX() + va.getY() * vb.getY();

    }


    public static double norm2(TrackVector vb){

          return  dot(vb,vb);

    }

    public static double Cross(TrackVector va, TrackVector vb){

        return  va.getX() * vb.getY() - va.getY() * vb.getX();

    }


    public static TrackVector multiVectorDouble(TrackVector c2, double c1){

        return new TrackVector(c1 * c2.getX(), c1 * c2.getY());

    }


    public static TrackVector addVector(Track v1, TrackVector v2){

        return new TrackVector(v1.getX() + v2.getX(),v1.getY() + v2.getY());

    }





}
