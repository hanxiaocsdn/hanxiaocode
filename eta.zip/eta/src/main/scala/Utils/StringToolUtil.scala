package Utils

import java.util.Objects
import java.util.regex.Pattern

object StringToolUtil extends Serializable {

    /**
      * @note   Null转为空字符串
      * @param src
      * */
    def convertString(src:String): String ={
        var str = src
        if(Objects.equals(src,null))
            str = ""
        str.trim
    }

    private[StringToolUtil] val REGEX = "[\ud83c\udc00-\ud83c\udfff]|[\ud83d\udc00-\ud83d\udfff]|[\u2600-\u27ff]"
    private[StringToolUtil] val EMO_JI = Pattern.compile(REGEX, Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE)
    private[StringToolUtil] val replacement = "*"

    /**
      * @note   替换字符串中包含特殊表情包的字符
      * @param src
      * */
    def replacementEmoJi(src: String): String = {
        var replacementSource = src
        if (StringUtils.nonEmpty(src)) {
            val matcher = EMO_JI.matcher(src)
            if (matcher.find) {
                replacementSource = matcher.replaceAll(replacement)
            }
        }
        replacementSource
    }

    private[StringToolUtil] val EXTENDED_REGEX = "\\s*|\t|\r|\n"
    private[StringToolUtil] val EXTENDED_REGEX_PATTERN = Pattern.compile(EXTENDED_REGEX, Pattern.UNICODE_CASE | Pattern.CASE_INSENSITIVE)
    /**
      * @note   替换字符串中包含的 多空格 \r \n \t etc
      * @param src
      * */
    def replacementExtended(src: String): String = {
        var replacementSource = src
        if (StringUtils.nonEmpty(src)) {
            val matcher = EXTENDED_REGEX_PATTERN.matcher(src)
            if (matcher.find) {
                replacementSource = matcher.replaceAll("")
            }
        }
        replacementSource
    }

    def main(args: Array[String]): Unit = {
        val a = "中国兰州拉面\uD83C\uDF5C"
        println(replacementEmoJi(a))

        val b = "何\uD83E\uDD14\uD83E\uDD14\uD83E\uDD14\uD83E\uDD14"
        println(replacementEmoJi(b))
        println(replacementExtended(b))

    }
}
