package Utils.Rarefy;

import java.awt.geom.Line2D;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedDeque;

//import java.util.concurrent.ConcurrentLinkedDeque;
//import org.springframework.stereotype.Service;

//import com.sf.gis.track.common.entity.GeoObj;
//import com.sf.gis.track.entity.GeoObjKafka;

/**
 * 抽稀service
 */

public class RarefyService {



    private static void findSplit(List<Dot> dots, int i, int j, Param res) {
		Line2D lin = new Line2D.Double();

		Dot dot1 = dots.get(i);
		Dot dot2 = dots.get(j);
		lin.setLine(dot1.x, dot1.y, dot2.x, dot2.y);

		for (int ii = i + 1; ii < j; ii++) {
			Dot dot = dots.get(ii);
			double dist = lin.ptLineDist(dot.x, dot.y);
			if (res.dist < dist) {
				res.dist = dist;
				res.index = ii;
			}
		}
	}

	/**
	 * 对坐标数据进行抽稀(道格拉斯—普克(Douglas一Peukcer)算法)
	 * 
	 * @param dots
	 *            需要抽稀的点串数据
	 * @param e
	 *            容差
	 * @return 返回需要保留的dots中的序号
	 */
	public static Set<Integer> douglasPeucker(List<Dot> dots, double e) {

		Set<Integer> retain = new HashSet<Integer>();

		if (dots.size() < 3) {
			for (int i = 0; i < dots.size(); i++) {
				retain.add(i);
			}
			return retain;
		}

		retain.add(0);
		retain.add(dots.size() - 1);

		ConcurrentLinkedDeque<Integer> tempVertex = new ConcurrentLinkedDeque<Integer>();
		double dist = Double.MAX_VALUE;

		int f = 0; // 最大距离的点的序号
		int i = 0;
		int j = dots.size() - 1;
		Param res = null;
		tempVertex.push(j);
		do {
			res = new Param();
			// 循环i和j之间距离直线ij最大的点
			findSplit(dots, i, j, res);

			dist = res.dist;
			f = res.index;

			// 大于阈值
			if (dist > e) {
				retain.add(f);
				// 更新B值
				j = f;
				// 记录最大距离点，放入栈中存储
				tempVertex.push(f);
				continue;
			} else {
				// 判断后一点是否和当前栈顶相等
				int top = tempVertex.getFirst();
				if (!tempVertex.isEmpty() && j != top) {
					i = f;
					j = top;
					continue;
				} else {
					// 判断最后一个点是否和当前线段的B点重合
					if (j != dots.size()) {
						i = j;
						if (!tempVertex.isEmpty()) {
							if (tempVertex.size() > 1) {
								tempVertex.pop();
								j = tempVertex.getFirst();
							} else if (tempVertex.size() == 1) {
								j = tempVertex.getFirst();
								tempVertex.pop();
							}
							continue;
						}
					}
				}
			}
		} while (!tempVertex.isEmpty());

		return retain;
	}

	private static void test() {
//		113.941418	22.524778	
//		113.941412	22.524466	
//		113.941407	22.524079	
//		113.941359	22.523569	
//		113.941332	22.521978
		String str1 = "113.941418,22.524778";
		String str2 = "113.941412,22.524466";
		String str3 = "113.941407,22.524079";
		String str4 = "113.941359,22.523569";
		String str5 = "113.941332,22.521978";
		
		List<String> list = new ArrayList<String>();
		list.add(str1);
		list.add(str2);
		list.add(str3);
		list.add(str4);
		list.add(str5);
		List<String> result =  rarefiesBySList(list,0.0005);
		for (String string : result) {
			System.out.println(string);
		}
	}

	public static List<String> rarefiesBySList(List<String> list,double e) {
		List<Dot> srcDots = new ArrayList<Dot>();
		List<String> result = new ArrayList<String>();
		for (String str : list) {
			String strs[] = str.split(",");
			if (strs.length >= 2) {
				Dot d = new Dot();
				d.x = Double.parseDouble(strs[0])*3600;
				d.y = Double.parseDouble(strs[1])*3600;
				srcDots.add(d);
			}
		}
		Set<Integer> retain = douglasPeucker(srcDots, e);  //e = 0.0005  视觉效果较好，但占用空间大
		//System.out.println("Cal Over");
		int size = srcDots.size();
		for (int ii = 0; ii < size; ii++) {
			if (retain.contains(ii)) {
				String str = list.get(ii);
				result.add(str);
				//System.out.println(String.format("%f %f", dot.x / 3600, dot.y / 3600));
			}
		}
		return result;
	}


//	public String rarefiesByGeoList(String listStr,Double toleranceMeter) {
//		//1m容差0.03333无线循环
//		double tolerance = 0.3333;//默认容差10m
//		if(toleranceMeter != null){
//			tolerance = toleranceMeter*((double)1/(double)30);
//		}
//		List<Dot> srcDots = new ArrayList<Dot>();
//		List<GeoObjKafka> list = JSONArray.parseArray(listStr, GeoObjKafka.class);
//		List<String> result = new ArrayList<String>();
//		for (GeoObjKafka geo : list) {
//			Dot d = new Dot();
//			if ("-1.0".equals(geo.dx)) {
//				d.x = Double.parseDouble(geo.zx)*3600;
//			}else {
//				d.x = Double.parseDouble(geo.dx)*3600;
//			}
//			if ("-1.0".equals(geo.dy)) {
//				d.y = Double.parseDouble(geo.zy)*3600;
//			} else {
//				d.y = Double.parseDouble(geo.dy)*3600;
//			}
//			srcDots.add(d);
//		}
//		Set<Integer> retain = douglasPeucker(srcDots, tolerance);
//		//System.out.println("Cal Over");
//		int size = srcDots.size();
//		for (int ii = 0; ii < size; ii++) {
//			if (retain.contains(ii)) {
//				GeoObjKafka geo = list.get(ii);
//				result.add(JSONObject.toJSONString(geo));
//			}
//		}
//		return result.toString();
//	}
	
	public static void main(String[] args){
		System.out.println("Hello World!");
		RarefyService v = new RarefyService();
		v.test();
		
	}
}

class Param {
    int index;
    double dist = Double.MIN_VALUE;
}
