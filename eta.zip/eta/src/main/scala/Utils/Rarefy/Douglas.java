package Utils.Rarefy;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/7/28
*/


import java.util.ArrayList;
import java.util.List;

//douglas算法实现类
public class Douglas{

    //定义允许点的最大偏差距离
    public static final double max = 0.005f;

    //利用三角形的勾股定理来求两点的距离
    public static double calDistance(Point p1, Point p2){
        double a = Math.round( (p2.getLongitude()-p1.getLongitude() )*100000);//求经度方向的距离差,同一纬度,经度每差一度,距离差大约 110000米
        double b = Math.round( (p2.getLatitude()-p1.getLatitude() )*111320);//求纬度方向的距离差,同一经度,纬度每差一度,距离大约差100000米
        return Math.sqrt(Math.pow(a,2) + Math.pow(b,2) );
    }

    //计算点到直线的距离,将点和线的起点终点来看成为三角形,求点到直线的距离,就是求点到这条线的高, 来利用海伦公式利用三边长来求出面积,在利用面积和底边长来求出高
    public static double calPointToLine(Point start, Point end, Point target){
        //求三边长
        double a = calDistance(target,start);
        double b = calDistance(target,end);
        double c = calDistance(start,end);
        double p = (a + b + c)/2.0;
        //求出三角形面积
        double s = Math.sqrt(Math.abs( p*(p-a)*(p-b)*(p-c) ));
        return s*2.0/c;
    }
    //递归方法实现轨迹点压缩
    public static void compressLine(List<Point> points, int start, int end, List<Point> resList){
        Point startPoint = points.get(start);
        Point endPoint = points.get(end);
        double maxDistance = 0;
        int index = 0;
        //遍历出离线距离最大的点
        for(int i=start;i<=end;i++){
            double currDistance = calPointToLine(startPoint,endPoint,points.get(i));
            if(currDistance>maxDistance){
                maxDistance = currDistance;
                index = i;
            }
        }
//        System.out.println("index:" + index);
        //如果离线最大距离 没有超过了我们设置的最大偏移距离,就再以这个点为界限,分成两段,再分别去递归查询,并且要把这个点添加到存放压缩点的resList
        //添加元素一定要在递归该点之前的路线之后添加,这样可以保证点的相对顺序不会变,否则点会顺序不对,在地图上连线是有问题的
        if(maxDistance>max && index!=0){
//            System.out.println("start:" + start + " end:" + (index -1));
            compressLine(points,start,index-1,resList);
            if(!resList.contains(points.get(index))){
                resList.add(points.get(index));
//                resList.add(points.get(index));
            }
//            System.out.println("start:" + (index+1) + " end:" + end);
            compressLine(points,index+1,end,resList);
        }
    }

    //获取压缩点的结果的方法,要想用道格拉斯算法抽稀点就可以调用此方法,传入点的集合即可.
    public static List<Point> getCompressList(List<Point> list){
        //存放压缩后点的集合
        List<Point> resList = new ArrayList<>();
        if(list.isEmpty()){
            return resList;
        }
        compressLine(list,0,list.size()-1,resList);
        return resList;

    }

    public static void main(String[] args) {


        Point p1 = new Point(113.941418,22.524778);
        Point p2 = new Point(113.941417,22.524666);
        Point p3 = new Point(113.941416,22.524566);
        Point p4 = new Point(113.941415,22.524456);
        Point p5 = new Point(113.941414,22.524466);
        Point p6 = new Point(113.941407,22.524079);
        Point p7 = new Point(113.941359,22.523569);
        Point p8 = new Point(113.941332,22.521978);

        List<Point> list = new ArrayList<Point>();


        list.add(p1);
        list.add(p2);
        list.add(p3);
        list.add(p4);
        list.add(p5);
        list.add(p6);
        list.add(p7);
        list.add(p8);

        List<Point> compressList = getCompressList(list);

        for (Point t : compressList){
            System.out.println(t.toString());
        }

    }

}

