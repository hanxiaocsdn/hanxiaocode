package Utils.Rarefy;

import java.awt.geom.Point2D;

public class Dot extends Point2D.Double {
    private static final long serialVersionUID = 1848772655021521158L;
}