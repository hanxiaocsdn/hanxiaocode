package Utils.Rarefy;//package test.Utils.Rarefy;
//
//import java.awt.geom.Line2D;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Set;
//import java.util.concurrent.ConcurrentLinkedDeque;
//
////import java.util.concurrent.ConcurrentLinkedDeque;
////import org.springframework.stereotype.Service;
//
////import com.sf.gis.track.common.entity.GeoObj;
////import com.sf.gis.track.entity.GeoObjKafka;
//
///**
// * 抽稀service
// */
//
//
//class Point{
//	double x;
//	double y;
//}
//
//public class RarefyService2 {
//
//	/**
//	 * 根据两个点求直线方程 ax+by+c=0
//	 * @return Line2D
//	 */
//	public static Line2D getLineByPoint(List<Dot> dots, int i, int j) {
//		Line2D lin = new Line2D.Double();
//		Dot dot1 = dots.get(i);
//		Dot dot2 = dots.get(j);
//		lin.setLine(dot1.x, dot1.y, dot2.x, dot2.y);
//
//		return lin;
//	}
//
//	/**
//	 * 点到直线距离
//	 * @return Line2D
//	 */
//	public static double getDistanceFromPointToLine(Dot dot, Line2D lin) {
//		double dist = lin.ptLineDist(dot.x, dot.y);
//		return dist;
//	}
//
//
//
//	/**
//	 *
//	 * @param dots
//	 * @param i
//	 * @param j
//	 */
//
//
//    private static void findSplit(List<Dot> dots, int i, int j,Point) {
//		Line2D lin = new Line2D.Double();
//
//		Dot dot1 = dots.get(i);
//		Dot dot2 = dots.get(j);
//		lin.setLine(dot1.x, dot1.y, dot2.x, dot2.y);
//
//		for (int ii = i + 1; ii < j; ii++) {
//			Dot dot = dots.get(ii);
//			double dist = lin.ptLineDist(dot.x, dot.y);
//			if (res.dist < dist) {
//				res.dist = dist;
//				res.index = ii;
//			}
//		}
//	}
//
//	/**
//	 * 对坐标数据进行抽稀(道格拉斯—普克(Douglas一Peukcer)算法)
//	 *
//	 * @param dots
//	 *            需要抽稀的点串数据
//	 * @param e
//	 *            容差
//	 * @return 返回需要保留的dots中的序号
//	 */
//	public static Set<Integer> douglasPeucker(List<Dot> dots, double e, int start ,int end) {
//
//		Set<Integer> retain = new HashSet<Integer>();
//
//		if (dots.size() < 3) {
//			for (int i = 0; i < dots.size(); i++) {
//				retain.add(i);
//			}
//			return retain;
//		}
//
//		retain.add(0);
//		retain.add(dots.size() - 1);
//
//
//		double dotMax  = 0;//记录点到直线的最大距离
//		int split = 0;
//
//		Line2D line = getLineByPoint(dots, start, end);
//
//
//		// TODO: 查找点最大值 ，并连线
//		for (int i = 1; i < dots.size(); i++) {
//			double dist = getDistanceFromPointToLine(dots.get(i), line);
//			if (dist > dotMax) {
//				split = i;
//				dotMax  = dist;
//			}
//		}
//
//		//如果存在点到首位点连成直线的距离大于max的,即需要再次划分
//		if (dotMax > 0) {
//			douglasPeucker(dots,)
//			$child1 = $this->sparePoints(array_slice($points, 0, $split + 1), $max);//按split分成左边一份，递归
//			$child2 = $this->sparePoints(array_slice($points, $split), $max);//按split分成右边一份，递归
//			//因为child1的最后一个点和child2的第一个点,肯定是同一个（即为分割点）,合并的时候,需要注意一下
//			$ret = array_merge($ret, $child1, array_slice($child2, 1));
//			return $ret;
//		} else {//如果不存在点到直线的距离大于阈值的,那么就直接是首尾点了
//			return [$points[0], end($points)];
//		}
//
//		if ()
//
//
//
//		return retain;
//	}
//
//	private static void test() {
////		113.941418	22.524778
////		113.941412	22.524466
////		113.941407	22.524079
////		113.941359	22.523569
////		113.941332	22.521978
//		String str1 = "113.941418,22.524778";
//		String str2 = "113.941412,22.524466";
//		String str3 = "113.941407,22.524079";
//		String str4 = "113.941359,22.523569";
//		String str5 = "113.941332,22.521978";
//
//		List<String> list = new ArrayList<String>();
//		list.add(str1);
//		list.add(str2);
//		list.add(str3);
//		list.add(str4);
//		list.add(str5);
//		List<String> result =  rarefiesBySList(list,0.0005);
//		for (String string : result) {
//			System.out.println(string);
//		}
//	}
//
//	public static List<String> rarefiesBySList(List<String> list,double e) {
//		List<Dot> srcDots = new ArrayList<Dot>();
//		List<String> result = new ArrayList<String>();
//		for (String str : list) {
//			String strs[] = str.split(",");
//			if (strs.length >= 2) {
//				Dot d = new Dot();
//				d.x = Double.parseDouble(strs[0])*3600;
//				d.y = Double.parseDouble(strs[1])*3600;
//				srcDots.add(d);
//			}
//		}
//		Set<Integer> retain = douglasPeucker(srcDots, e);  //e = 0.0005  视觉效果较好，但占用空间大
//		//System.out.println("Cal Over");
//		int size = srcDots.size();
//		for (int ii = 0; ii < size; ii++) {
//			if (retain.contains(ii)) {
//				String str = list.get(ii);
//				result.add(str);
//				//System.out.println(String.format("%f %f", dot.x / 3600, dot.y / 3600));
//			}
//		}
//		return result;
//	}
//
//
//
//	public static void main(String[] args){
//		System.out.println("Hello World!");
//		RarefyService2 v = new RarefyService2();
//		v.test();
//
//	}
//
//
//}
//
//
