package Utils.Rarefy;/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/7/27
*/

import java.util.ArrayList;
import java.util.List;


public class RarefySrviceNew {
    static int iNum;
    public static double LimitDis;


    public static ArrayList<Integer> afterTraj = new ArrayList<Integer>();
    private static int delTotal = 0;

    //删除轨迹点
    protected static void Delpt(List<Point> list, int a, int b) {
        int c=a+1;
        while(c<b){
            list.get(c).setRes('F');
            c++;
        }
    }

    /*
     *道格拉斯-普克算法（Algorithm.DP）算法
     *@param list 源轨迹集合
     *@param p1 起始点
     *@param p2 终止点
     *@return void
     **/
    public static void DPAlgorithm(List<Point> beforeTraj, int start, int end, double LimitDis){
        double maxdis,curdis;
        int i = 0,maxNO = 0;
        Distance distance = new Distance();
        System.out.print("start="+start+"  end="+end);
        Point pa = beforeTraj.get(start);
        Point pb = beforeTraj.get(end);
        if(end-start >= 2){
            maxdis = 0;
            i=start+1;
            while(i < end){
                Point pc = beforeTraj.get(i);
                curdis = distance.getDistance(pa,pb,pc);
                if(maxdis < curdis)   {
                    maxdis = curdis;
                    maxNO = i;
                }
                i++;
            }//end while
            // System.out.println("maxdis="+maxdis+" curList="+maxNO);
            if(maxdis >= LimitDis) {
//                afterTraj.add(beforeTraj.get(maxNO));
                afterTraj.add(maxNO);
//                System.out.println("   添加点："+maxNO);
                DPAlgorithm(beforeTraj,start,maxNO,LimitDis);
                DPAlgorithm(beforeTraj,maxNO,end,LimitDis);
            }
            else {
                Delpt(beforeTraj,start,end);
                delTotal++;
                System.out.println("Delpt: p1="+start+" p2="+end+"  删除"+(end-start)+"个轨迹点");
            }
        }

    }

    public static ArrayList getRarefy(List<Point> beforeTraj, int start, int end, double LimitDis){

        DPAlgorithm(beforeTraj,0,end,0.0005);

        return afterTraj;

    }


    //主函数
    public static void main(String[] args) throws Exception {

        String str1 = "113.941418,22.524778";
		String str2 = "113.941412,22.524466";
		String str3 = "113.941407,22.524079";
		String str4 = "113.941359,22.523569";
		String str5 = "113.941332,22.521978";

		Point p1 = new Point(113.941418,22.524778);
        Point p2 = new Point(113.941417,22.524666);
        Point p3 = new Point(113.941416,22.524566);
        Point p4 = new Point(113.941415,22.524456);
        Point p5 = new Point(113.941414,22.524466);
        Point p6 = new Point(113.941407,22.524079);
        Point p7 = new Point(113.941359,22.523569);
        Point p8 = new Point(113.941332,22.521978);

        List<Point> list = new ArrayList<Point>();


		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
        list.add(p6);
        list.add(p7);
        list.add(p8);

        GetTime getTime = new GetTime();
        getTime.setStartTime(System.currentTimeMillis());
        DPAlgorithm(list,0,list.size()-1,0.00001);
        for (Integer t : afterTraj){
            System.out.println(t);
        }


        getTime.setEndTime(System.currentTimeMillis());



//        ArrayList<Point> beforeTraj = new ArrayList<Point>();
//        ArrayList<Point> points = new ArrayList<>();
//        Estimate estimate = new Estimate();
//        GetDataFromFile getData = new GetDataFromFile();
//        GetTime getTime = new GetTime();
//        LimitDis = (float) 2.9000298;
//        //获取数据
//        String path = "F:\\GeolifeTrajectoriesData\\000\\Trajectory\\15.plt";
//        File file = new File(path);
//        beforeTraj =getData.getDataFromFile(file,"1");
//        getTime.setStartTime(System.currentTimeMillis());
//        DPAlgorithm(beforeTraj,0,beforeTraj.size()-1);
//        getTime.setEndTime(System.currentTimeMillis());
//        System.out.println("压缩前轨迹点数："+beforeTraj.size());
//        System.out.println("压缩后轨迹点数："+afterTraj.size());
//        getTime.showTime();
//        estimate.CompressionRatio(beforeTraj.size(),afterTraj.size());
//        estimate.CompressionError(beforeTraj,afterTraj);
    }


}
