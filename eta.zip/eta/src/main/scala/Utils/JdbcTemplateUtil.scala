package Utils

import java.sql.{Connection, PreparedStatement, SQLException}
import java.util.Properties

import com.alibaba.druid.pool.DruidDataSource

import scala.collection.mutable.ArrayBuffer
object JdbcTemplateUtil extends Serializable {

    /**
      * @note Get DataSource Connection
      * @param propertyName:String
      * @param driver:String
      * @param url:String
      * @param userName:String
      * @param password:String
      */
    def getDataSourceConnection(propertyName:String, driver:String, url:String, userName:String, password:String): Connection = {
        var conn:Connection = null
        try{
            val props = PropertyUtil.getProperties(propertyName)
            val dataSource:DruidDataSource = new DruidDataSource()
            dataSource.setDriverClassName(props.getProperty(driver))
            dataSource.setUrl(props.getProperty(url))
            dataSource.setUsername(props.getProperty(userName))
            dataSource.setPassword(props.getProperty(password))
            dataSource.setMaxActive(30)
            dataSource.setMaxWait(2000)
            dataSource.setRemoveAbandoned(false)
            conn = dataSource.getConnection
        }catch {
            case e: Exception =>println(">>>>>>Get Connect DataSource Druid Exception: " + e)
        }
        conn
    }

    /**
      * @note Get DataSource Connection
      * @param props:Properties
      * @param driver:String
      * @param url:String
      * @param userName:String
      * @param password:String
      */
    def getDataSourceConnection(props:Properties, driver:String, url:String, userName:String, password:String): Connection = {
        var conn:Connection = null
        try{
            val dataSource:DruidDataSource = new DruidDataSource()
            dataSource.setDriverClassName(props.getProperty(driver))
            dataSource.setUrl(props.getProperty(url))
            dataSource.setUsername(props.getProperty(userName))
            dataSource.setPassword(props.getProperty(password))
            dataSource.setMaxActive(20)
            dataSource.setMaxWait(1000)
            dataSource.setRemoveAbandoned(false)
            conn = dataSource.getConnection
        }catch {
            case e: Exception =>println(">>>>>>Get Connect DataSource Druid Exception: " + e)
        }
        conn
    }


    /**
      * @note One Operation
      * @param conn:Connection
      * @param sql
      * @param params
      */
    def executeSql(conn: Connection, sql: String, params: Array[String]): Int = {
        var updateNum = -1
        try {
            val ps = conn.prepareStatement(sql)
            if (params != null) {
                for (i <- params.indices)
                    ps.setString(i + 1, params(i))
            }
            updateNum = ps.executeUpdate()
            ps.close()
        } catch {
            case e: Exception => println(">>>>>>Execute One Sql Exception: " + e.getMessage + "\nAnd UpdateNum = " + updateNum +  " Source Data: " + params.mkString("&&"))
        }
        updateNum
    }

    def executeSqlAnyParams(conn: Connection, sql: String, params: Array[Any]): Int = {
        var updateNum = -1
        try {
            val ps = conn.prepareStatement(sql)
            if (params != null) {
                for (i <- params.indices)
                    ps.setObject(i + 1, params(i))
            }
            updateNum = ps.executeUpdate()
            ps.close()
        } catch {
            case e: Exception => println(">>>>>>Execute One Sql Exception: " + e.getMessage + "\nAnd UpdateNum = " + updateNum +  " Source Data: " + params.mkString("&&"))
        }
        updateNum
    }


    /**
      * 批量操作
      * @param sql
      * @param paramList
      */
    def executeBatchSql(conn: Connection, sql: String, paramList: ArrayBuffer[Array[String]]): Unit = {
        println(">>>>>>paramList== " + paramList.size )
        var batch: Array[Int] = Array[Int]()
        try {
            val ps = conn.prepareStatement(sql)
            conn.setAutoCommit(false)
            for (params: Array[String] <- paramList) {
                if (params != null) {
                    for (i <- params.indices) ps.setString(i + 1, params(i))
                    ps.addBatch()
                }
            }
            batch = ps.executeBatch()
            conn.commit()
            ps.close()
            // conn.close()
        } catch {
            case e: Exception =>  println(">>>>>>Execute Batch Sql Exception..." + e.getMessage + "\t And Batch Nums = " + batch.length)
        }
    }

    def executeBatchSqlAny(conn: Connection, sql: String, paramList: ArrayBuffer[Array[Any]]): Unit = {
        println(">>>>>>paramList== " + paramList.size )
        var batch: Array[Int] = Array[Int]()
        try {
            val ps = conn.prepareStatement(sql)
            conn.setAutoCommit(false)
            for (params: Array[Any] <- paramList) {
                if (params != null) {
                    for (i <- params.indices) ps.setObject(i + 1, params(i))
                    ps.addBatch()
                }
            }
            batch = ps.executeBatch()
            conn.commit()
            ps.close()
            // conn.close()
        } catch {
            case e: Exception =>  println(">>>>>>Execute Batch Sql Exception..." + e.getMessage + "\t And Batch Nums = " + batch.length)
        }
    }
    /**
      * @note   查询语句
      * @param conn
      * @param sql
      * @param params
      * @param columns
      * @return
      */
    def selectColumns(conn: Connection, sql: String, params: Array[String], columns: Array[String]): ArrayBuffer[Array[String]] = {
        var preparedStatement: PreparedStatement= null
        var rows: ArrayBuffer[Array[String]] = new ArrayBuffer[Array[String]]
        try {
            preparedStatement = conn.prepareStatement(sql)
            if(params != null){
                for(i <- params.indices)
                    preparedStatement.setString(i+1, params(i))
            }
            val resultSet = preparedStatement.executeQuery()
            while(resultSet.next()){
                val row: Array[String] = new Array[String](columns.length)
                for(i <- row.indices){
                    val field = resultSet.getObject(columns(i))
                    if(field != null) {
                        row(i) = field.toString
                    }else{
                        row(i) = ""
                    }
                }
                rows += row
            }
        } catch {
            case e: SQLException => println(">>>>>>查询数据库表数据异常Exception: " + e)
        }
        rows
    }

    /**
      * 查询语句
      * @param conn
      * @param sql
      * @param columns
      * @return
      */
    def selectColumns(conn: Connection, sql: String, columns: Array[String]): ArrayBuffer[Array[String]] = {
        selectColumns(conn,sql,null,columns)
    }

}
