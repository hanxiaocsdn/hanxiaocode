package Utils

import com.sf.gis.java.base.util.AesUtil
import org.apache.spark.sql.functions.udf

import java.text.SimpleDateFormat
import java.util.Date

/**
  * Created by 01374443 on 2020/3/25.
  */
object StringUtils {


  def isEmpty(str:String):Boolean={
    str==null || str.isEmpty
  }

  def nonEmpty(str:String):Boolean={
    str!=null && !str.isEmpty
  }
  def nonEmptyEq(str1:String,str2:String):Boolean={
    if(str1==null || str2 == null){
      return false
    }
    str1.equals(str2)
  }

  // 判断 某个字符串是否为空或者null
  def isEmptyOrNull = udf((str: String) => {
    var flag: Boolean = false
    if (str == null) flag = true
    else if (str.isEmpty) flag = true
    flag
  })

  /**
   * 两种不同格式时间字符串相互转换
   * @param time   时间
   * @param format1  原始时间格式
   * @param format2  目标时间格式
   * @return   转换后的时间
   */
  def timeToCustomTime(time: String, format1: String, format2: String) = {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try{
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    }catch {
      case e: Exception => println(">>>日期转换异常"+e)
    }
    newTime
  }

  /**
   * 时间转换为时间戳
   * @param time  时间
   * @param format1  时间格式
   * @return  时间戳
   */
  def tranTimeToLong = udf((time: String,format: String) => {
    var tm = 0L
    if(time != null && time.trim != "" && format != null && format.trim != ""){
      val fm = new SimpleDateFormat(format)
      try{
        tm = fm.parse(time).getTime
      }catch {
        case e: Exception => println(">>>时间转换成时间戳异常："+e)
      }
    }
    tm
  })

  /**
   * 对字段内容进行加密或者解密
   * @param col1  需要加解密字段
   * @param flag  加密或者解密标识  encrypt：加密  decrypt：解密
   * @return
   */
  def AESCode = udf((col1: String,flag: String) => {
    // key的长度必须为16的倍数
    val key = "Maoi@aoi996QQ98aMaoi@aoi996QQ98a"
    var ret = ""
    if(col1 != null && col1.trim != ""){
      if(flag.equals("encrypt")){
        try{
          ret = AesUtil.AESEncode(key,col1);
        }catch {
          case e: Exception => println(">>>加密失败："+e)
        }
      }else if(flag.equals("decrypt")){
        try{
          ret = AesUtil.AESDncode(key,col1);
        }catch {
          case e: Exception => println(">>>解密失败："+e)
        }
      }
    }
    ret
  })

}

