package Utils

import java.io.{BufferedReader, IOException, InputStream, InputStreamReader}
import java.util.{Objects, Properties}

object PropertyUtil extends Serializable {
    private val CHARSET = "UTF-8"
    /**
      * @param propertyName property file name,eg:application.properties
      * @param key          properties context key
      * @return value
      **/
    private def getPropertyValue(propertyName: String, key: String): String = {
        var value: String = null
        val props = new Properties
        var inputStream: InputStream = null
        var inputStreamReader: InputStreamReader = null
        var bufferedReader: BufferedReader = null
        try {
            inputStream = this.getClass.getClassLoader.getResourceAsStream(propertyName)
            inputStreamReader = new InputStreamReader(inputStream, CHARSET)
            bufferedReader = new BufferedReader(inputStreamReader)
            props.load(bufferedReader)
            value = props.getProperty(key)
        } catch {
            case e: Exception => e.printStackTrace()
        } finally {
            try
                if (!Objects.isNull(bufferedReader)) bufferedReader.close()
            catch {
                case e: IOException => e.printStackTrace()
            }
            try
                if (!Objects.isNull(inputStreamReader)) inputStreamReader.close()
            catch {
                case e: IOException => e.printStackTrace()
            }
            try
                if (!Objects.isNull(inputStream)) inputStream.close()
            catch {
                case e: IOException => e.printStackTrace()
            }
        }
        value
    }

    /**
      * @param props Properties
      * @param key  properties context key
      * @return value
      **/
    def getPropertyValue(props: Properties, key: String): String = {
        props.getProperty(key)
    }

    /**
      * @param propertyName property file name,eg:application.properties
      * @return Properties
      **/
    def getProperties(propertyName:String): Properties = {
        val props = new Properties
        var inputStream: InputStream = null
        var inputStreamReader: InputStreamReader = null
        var bufferedReader: BufferedReader = null
        try {
            inputStream = this.getClass.getClassLoader.getResourceAsStream(propertyName)
            inputStreamReader = new InputStreamReader(inputStream, CHARSET)
            bufferedReader = new BufferedReader(inputStreamReader)
            props.load(bufferedReader)
        } catch {
            case e: Exception =>
                e.printStackTrace()
        } finally {
            try
                if (!Objects.isNull(bufferedReader)) bufferedReader.close()
            catch {
                case e: IOException => e.printStackTrace()
            }
            try
                if (!Objects.isNull(inputStreamReader)) inputStreamReader.close()
            catch {
                case e: IOException => e.printStackTrace()
            }
            try
                if (!Objects.isNull(inputStream)) inputStream.close()
            catch {
                case e: IOException => e.printStackTrace()
            }
        }
        props
    }

}
