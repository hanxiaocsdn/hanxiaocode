package Utils

import java.io.{BufferedReader, File, FileInputStream, FileNotFoundException, InputStreamReader}
import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date, Properties, UUID}
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

import sys.process._
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel

import java.sql.Connection
import scala.collection.mutable.ArrayBuffer
import scala.io.Source



object Util {
  var sc:SparkContext = null
  var spark:SparkSession = null
  var defaultPartitionSize = 100
  val properties = new java.util.Properties()
  var defaultAppName = this.getClass.getSimpleName

  def cache(sql:String,tableName:String,partitionSize:Int=0,storageLevel: StorageLevel=StorageLevel.MEMORY_AND_DISK_SER,count:Boolean=true,show:Boolean=false,saveAsTable:Boolean=false) ={
    Util.memTime()
    if(!count)
      System.out.println(s"【$tableName】")
    var cnt = -1l
    System.out.println(sql)
    val partitions = if(partitionSize<=0) Util.defaultPartitionSize else partitionSize
    Util.spark.sql(sql).repartition(partitions).createOrReplaceTempView(tableName)
//    Util.spark.catalog.cacheTable(tableName,storageLevel)
    Util.spark.catalog.cacheTable(tableName)
    if(count){
      val coll = Util.spark.sql("select count(1) as cnt from "+tableName).collect()
      cnt = if(coll.isEmpty) 0 else coll(0).getLong(0)
      Util.showCost(s"【$tableName】记录数：$cnt")
    }
    if(show){
      Util.spark.sql(s"select * from $tableName limit 20").show(false)
    }
    if(saveAsTable){
      val pfx = this.defaultAppName.substring(0,this.defaultAppName.length-1)
      Util.spark.sql(s"drop table if exists dm_gis.tmp_cache_${pfx}_$tableName")
      Util.spark.sql(s"create table if not exists dm_gis.tmp_cache_${pfx}_$tableName as select * from $tableName")
      Util.spark.sql(s"select * from $tableName limit 20").show(false)
    }
    cnt
  }


  def printException(e:Exception): Unit ={
    System.err.println(e.getMessage+"\t"+e.getCause)
    e.printStackTrace(System.err)
  }
  def hdfsRM(path:String):Unit={
    Util.runShellCmdSilent(s"hdfs dfs -rm -r -f $path")
  }
  def hdfsMkdir(path:String)={
    val hadoopConf = spark.sparkContext.hadoopConfiguration
    val hdfs = org.apache.hadoop.fs.FileSystem.get(hadoopConf)
    val p = new Path(path)
    if(!hdfs.exists(p))
      hdfs.mkdirs(p)
  }
  def loadConfigInFile(spark: SparkContext,path:String):Properties = {
    //val properties = new Properties()
    try {
      properties.load(new FileInputStream(path))
      System.err.println(properties)
    } catch {
      case e : FileNotFoundException =>
        System.err.println("new FileInputStream("+path+") => FileNotFoundException, try new FileInputStream((new File("+path+")).getName())")
        properties.load(new FileInputStream((new File(path)).getName()))
      case e : Throwable => throw e
    }
    properties
  }
  def loadConfig():Properties = {
    val confPath = "conf.product.properties"
    Util.loadConfigInJar(confPath)
  }
  def loadConfigInJar(path:String):Properties={
    val url = this.getClass.getClassLoader.getResource(path)//"conf.properties"
    System.err.println("==================="+url)
    val source = Source.fromURL(url)
    val prop = source.getLines().toArray.filter(item=>item.trim.length>0&&item.trim.indexOf("#")!=0).map(item=>item.split("=")).foreach(d=>{
      if(d.length==2){
        //System.err.println(d(0)+"="+d(1))
        properties.put(d(0).trim,d(1).trim)
      }else if(d.length==1){
        //System.err.println(d(0)+"=null")
        properties.put(d(0).trim,"")
      }else if(d.length>2){
        val key = d(0)
        var value = d.toIndexedSeq.slice(1,d.length).mkString("","=","")
        //System.err.println(key+"="+value)
        properties.put(key.trim,value.trim)
      }
    })
    properties
  }

  def defaultSparkConf()={
    System.setProperty("spark.serializer", "org.apache.spark.serializer.KryoSerializer")

    val conf = new SparkConf()
      .set("dfs.client.read.shortcircuit","false")
      .set("spark.speculation","false")
      .set("spark.sql.crossJoin.enabled", "true")
      .set("spark.eventQueue.size","1000000")
      .set("spark.event.listener.logEnable","true")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime","90000")
//      .set("spark.kryoserializer.buffer.max",Util.getProperty("spark.kryoserializer.buffer.max"))
//      .set("spark.network.timeout",Util.getProperty("spark.network.timeout"))
//      .set("spark.executor.memoryOverhead",Util.getProperty("spark.executor.memoryOverhead"))
//      .set("spark.driver.extraJavaOptions",Util.getProperty("spark.driver.extraJavaOptions"))
//      .set("spark.executor.extraJavaOptions",Util.getProperty("spark.executor.extraJavaOptions"))
      .set("spark.rpc.askTimeout","120")
      .set("spark.port.maxRetries","999")
      .set("spark.driver.maxResultSize", "128g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("hive.execution.engine","mr")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec","org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts","true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("mapreduce.map.log.level","ERROR")
      .set("mapreduce.reduce.log.level","ERROR")
      .set("yarn.nodemanager.pmem-check-enabled","false")
      .set("yarn.nodemanager.vmem-check-enabled","false")
    conf
  }


  def initSpark(appName:String=this.getClass.getSimpleName,initConf:SparkConf=null) ={
    val conf = if(initConf == null) defaultSparkConf().setAppName(appName) else initConf.setAppName(appName)

    spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    sc=spark.sparkContext
    sc.setLogLevel("ERROR")
    defaultPartitionSize = sc.getConf.get("spark.executor.instances", "16").toInt * sc.getConf.get("spark.executor.cores", "2").toInt * 2
    spark.sql("set dfs.client.read.shortcircuit=false")
    spark.sql("set spark.sql.thriftserver.scheduler.pool=spark")
    spark.sql("set mapred.max.split.size=1000000000")
    spark.sql("set mapred.min.split.size.per.node=1000000000")
    spark.sql("set mapred.min.split.size.per.rack=1000000000")
    spark.sql("set hive.fetch.task.conversion=more")
    spark.sql("set hive.cli.print.header=true")
    spark.sql("set hive.execution.engine=mr")
    spark.sql("set hive.exec.mode.local.auto=false")
    spark.sql("set hive.exec.reducers.max=500")
    spark.sql("set hive.exec.compress.output=false")
    spark.sql("set hive.exec.compress.intermediate=true")
    spark.sql("set hive.exec.dynamic.partition=true")
    spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
    spark.sql("set hive.exec.max.dynamic.partitions=100000")
    spark.sql("set hive.exec.max.dynamic.partitions.pernode=100000")
    spark.sql("set hive.groupby.skewindata=true")
    spark.sql("set hive.auto.convert.join=true")
    spark.sql("set hive.metastore.schema.verification=false")
    spark.sql("set hive.input.format=org.apache.Hadoop.hive.ql.io.CombineHiveInputFormat")
    spark.sql("set hive.merge.mapfiles=true")
    spark.sql("set hive.merge.mapredfiles=true")
    spark.sql("set hive.merge.size.per.task=1000000000")
    spark.sql("set hive.merge.smallfiles.avgsize=1000000000")
    spark.sql("set spark.sql.shuffle.partitions=50")

    scala.sys.addShutdownHook {
      stopSpark()
    }
    spark
  }
  def stopSpark(): Unit ={
    try{
      sc.stop()
      spark.stop()
      //      if(sc!=null && !sc.isStopped ){
      //        sc.stop()
      //        sc = null
      //      }
    }catch{
      case e:Exception=>{
        //e.printStackTrace(System.err)
      }
    }
  }

  def freeMem(keep:RDD[_]*): Unit ={
    Util.spark.catalog.clearCache()
    var cnt = 0 //Util.spark.sparkContext.getPersistentRDDs.size
    //System.err.println("----------------------------------------【清除缓存RDD开始】------------------------------------------")
    Util.spark.sparkContext.getPersistentRDDs.foreach(d=>{
      //System.err.println("清除缓存RDD："+d._2.toString())
      if(keep.isEmpty || !keep.contains(d._2)){
        d._2.unpersist()
        cnt += 1
      }
    })
    System.gc()
    //System.err.println("----------------------------------------【清除缓存RDD完成】------------------------------------------")
    System.err.println(s"【清除缓存RDD数量：${cnt}】")
  }

  def getProperty(key:String) ={
    val value = properties.getProperty(key)
    if(value==null){
      System.err.println("-------------- WARN Util.getProperty(\""+key+"\") return null --------------")
    }
    value
  }

  var t0 = 0l
  var t0Total = 0l
  def memTime() = {
    t0 = new Date().getTime
  }
  def showCost(title:String="")={
    val mss = new Date().getTime - t0
    val s = formatTime(mss)
    System.err.println((if(title.indexOf("耗时")== -1) title+"，耗时：" else title)+s)
    Util.memTime()
    s
  }
  def memTimeTotal() = {
    t0Total = new Date().getTime
  }
  def showCostTotal(title:String="")={
    val mss = new Date().getTime - t0Total
    val s = formatTime(mss)
    System.err.println((if(title.indexOf("总耗时")== -1) title+"，总耗时：" else title)+s)
    Util.memTimeTotal()
    s
  }
  def formatTime(mss:Long) ={
    val days = mss / (1000 * 60 * 60 * 24)
    val hours = (mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
    val minutes = (mss % (1000 * 60 * 60)) / (1000 * 60)
    val seconds = (mss % (1000 * 60)) / 1000
    var s = if(days>0) days+"天 " else ""
    s = s + (if(hours>0) hours+"小时 " else "")
    s = s + (if(minutes>0) minutes+"分钟 " else "")
    s = s + (if(seconds>0) seconds+"秒" else (mss % (1000 * 60) + "毫秒"))
    s = s + " ["+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime())+"]"
    s
  }

  def daysDiff(fromDay:String,endDay:String) ={
    val from = fromDay.replaceAll("-","")
    val to = endDay.replaceAll("-","")
    var t = from
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)

    t = to
    val endtm = Calendar.getInstance()
    endtm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)

    val millis = endtm.getTimeInMillis - begintm.getTimeInMillis
    millis / 24 / 60 / 60 / 1000
  }

  def getWeek(dayid:String) ={
    val t = dayid.replaceAll("-","")
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)
    begintm.getTime().getDay
  }

  def getYesterdayDate():String={
    //    var nowdate = LocalDate.now()
    //    nowdate.minusDays(1).toString()
    var cal:Calendar=Calendar.getInstance()
    cal.add(Calendar.DATE,-1)
    new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime())
  }

  def now(): String ={
    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime())
  }

  def addDay(dayid:String,step:Int) ={
    val t = dayid.replaceAll("-","")
    val begintm = Calendar.getInstance()
    begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)
    begintm.add(Calendar.DATE,step)
    new SimpleDateFormat("yyyy-MM-dd").format(begintm.getTime())
  }
  def getMonthEnd(dayid:String=null)={
    val day = if(dayid==null) Util.getTodayDayid() else dayid
    var dayend = day.substring(0,6)+"28"
    while(dayend.substring(0,6) == Util.addDay(dayend,1).replaceAll("-","").substring(0,6)){
      dayend = Util.addDay(dayend,1).replaceAll("-","")
    }
    dayend
  }
  def getToday() ={
    val begintm = Calendar.getInstance()
    new SimpleDateFormat("yyyy-MM-dd").format(begintm.getTime())
  }
  def getTodayDayid() ={
    val begintm = Calendar.getInstance()
    new SimpleDateFormat("yyyyMMdd").format(begintm.getTime())
  }
  def getYesterdayDayid()={
    getYesterdayDate().replaceAll("-","")
  }

  def minuteAdd(dayid:String,fromtm:String,step:Int) ={
    val begintm = Calendar.getInstance()
    begintm.set(dayid.substring(0,4).toInt,dayid.substring(4,6).toInt-1,dayid.substring(6,8).toInt,fromtm.substring(0,2).toInt,fromtm.substring(2,4).toInt,0)
    begintm.add(Calendar.MINUTE,step)
    (new SimpleDateFormat("yyyyMMdd").format(begintm.getTime()),new SimpleDateFormat("HHmm").format(begintm.getTime()))
  }
  def minuteAddConcat(dayid:String,fromtm:String,step:Int) ={
    val t = minuteAdd(dayid,fromtm,step)
    t._1+t._2
  }

  def runShellCmd(cmd:String,logPath:String,matchStr:String): Boolean ={
    val log = runShellCmd(cmd,logPath)
    log.contains(matchStr)
  }
  def runShellCmdSilent(cmd:String) = {
    val sh = "./_runShellCmd_"+UUID.randomUUID+".sh"
    FileUtil.save(sh,cmd)
    var result = -1
    try{
      result = "./bash "+sh !;
    }catch {
      case e:Exception=>{
        "chmod +x "+sh !;
        sh !;
      }
    }
    if(result == 2){
      System.err.println("===============================")
      System.err.println(s"【$result】"+cmd)
      System.err.println("===============================")
    }
    new File(sh).deleteOnExit()
    result
  }

  def runShellCmd(cmd:String,logPath:String=null,printCmd:Boolean=true,printResult:Boolean=true): String ={
    //System.err.println
    if(printCmd)
      System.err.println(cmd)
    val sh = "./_runShellCmd_"+UUID.randomUUID+".sh"
    val tmplog = "./_tmplog_"+UUID.randomUUID+".txt"
    val logFile = if(logPath!=null && logPath.length>0) logPath else tmplog
    FileUtil.save(sh,cmd + " > "+logFile)
    //"chmod +x "+sh !;
    try{
      "./bash "+sh !;
    }catch {
      case e:Exception=>{
        "chmod +x "+sh !;
        sh !;
      }
    }
    new File(sh).deleteOnExit()
    //System.err.println("cat "+logFile)
    //"cat "+logFile !;

    val f = new File(logFile)
    if(f.exists()){
      val log = FileUtil.readFileByLines(logFile,false)
      if(logPath==null || logPath.length==0)
        f.delete()
      if(printResult)
        System.err.println(log)
      log
    }else ""
  }
  def sh(cmd:String): Unit ={
    cmd !;
  }

  def readResouceToList(): Unit ={
    val path = System.getProperty("user.dir") + "/xiaogeno_out.csv"
    val buff = new BufferedReader(new InputStreamReader(new FileInputStream(path),"utf-8"))
    while(buff.readLine()!=null){

    }

  }

  /**
   * 配置spark的conf
   * @param appName
   * @return
   */
  def getLocalConf(appName:String): SparkConf = {
    val master = "local[*]"
    val conf = new SparkConf().setAppName(appName)
    if (JavaUtil.EN == 1) conf.setMaster(master)
    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
    conf
  }

  /**
   * 配置spark的conf
   * @param appName
   * @return
   */
  def getSparkConf(appName:String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "100")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
    conf.set("hive.exec.dynamic.partition","true")
    conf.set("hive.exec.dynamic.partition.mode","nonstrict")
    conf.set("spark.network.timeout","3000s")
    //        conf.set("spark.executor.instances","40")

    //    conf.set("spark.executor.cores","4")
    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")

    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    conf
  }

  /**
   * 获得两个字符串日期中所有日期的字符格式集合
   *
   * @param startDateStr
   * @param endDateStr
   * @return
   */
  def getBetweenDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      val startDate:Date = sdf.parse(startDateStr)
      val endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(startDate, endDate)

      for(date <- dateList) dateListStr += sdf.format(date)

    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }

  /**
   * 获得两个字符串日期中所有日期的字符格式集合
   *
   * @param startDateStr
   * @param endDateStr
   * @return
   */
  def getBetweenDatesStr(startDateStr: String, endDateStr: String,separator:String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      val startDate:Date = sdf.parse(startDateStr)
      val endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(startDate, endDate)

      for(date <- dateList) dateListStr += sdf.format(date)

    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }



  /**
   * 获得两个日期之间的所有日期列表
   *
   * @param start
   * @param end
   * @return
   */
  def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
    val result = new ArrayBuffer[Date]
    val tempStart = Calendar.getInstance
    tempStart.setTime(start)

    tempStart.add(Calendar.DAY_OF_YEAR, 1)
    val tempEnd = Calendar.getInstance
    tempEnd.setTime(end)
    while (tempStart.before(tempEnd)) {
      result += tempStart.getTime
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    result
  }

  /**
   * 获取某天日期之后几天的日期字符串
   * @param inputDateStr 日期
   * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
   */
  def getDay(inputDateStr:String, num:Int): String ={
    getDay(inputDateStr,num,"-")
  }



  /**
   * 获取某天日期之后几天的日期字符串
   * @param inputDateStr 日期
   * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
   * @param separator 日期分隔符
   * @return
   */
  def getDay(inputDateStr:String, num:Int,separator:String): String ={
    val dateStrFormat = "yyyy"+separator+"MM"+separator+"dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    val inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

  /*  /**
      * 获取本机日历日期
      *
      * @param delta
      * @return
      */
    def dateDelta(delta: Int): String = {
      val sdf = new SimpleDateFormat("yyyy-MM-dd")
      val cal = Calendar.getInstance()
      cal.add(Calendar.DATE, delta)
      val date = sdf.format(cal.getTime)
      date
    }*/

  /**
   * 获取本机日历日期
   *
   * @param delta
   * @return
   */
  def dateDelta(delta: Int): String = {
    dateDelta(delta,"-")
  }

  /**
   * 获取本机日历日期
   *
   * @param delta
   * @return
   */
  def dateDelta(delta: Int,separator:String): String = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }





  /**
   * 读取csv配置文件，获得城市代码的中文名字
   * @param citycode
   * @return
   */
  def getCityName(citycode:String): String ={



    ""
  }

  /**
   * 读取csv配置文件，获得城市名字的城市代码
   * @param cityname
   * @return
   */
  def getCityCode(cityname:String): String ={

    ""
  }


  /**
   * 单条操作
   *
   * @param sql
   * @param params
   */
  def executeSql(conn:Connection,sql: String, params: Array[String]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      if (params != null) {
        for (i <- params.indices) ps.setString(i + 1, params(i))
      }
      //noinspection ScalaUnusedSymbol
      //      println(sql)
      val update = ps.executeUpdate()
      ps.close()
    } catch {
      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
      case e: Exception => println(">>>数据库操作异常："+e)
    }
  }

  /**
   * 批量操作
   * @param sql
   * @param paramList
   */
  def executeSql1(conn:Connection,sql: String, paramList:ArrayBuffer[Array[String]]): Unit = {
    try {
      val ps = conn.prepareStatement(sql)
      conn.setAutoCommit(false)

      for(params:Array[String] <- paramList){

        if (params != null) {
          for (i <- params.indices) ps.setString(i + 1, params(i))
          ps.addBatch()
        }

      }
      // val update = ps.executeUpdate()
      ps.executeBatch()
      conn.commit()
      ps.close()
      conn.close()
    } catch {
      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
      case e: Exception => println(">>>数据库操作异常："+e)
    }
  }

  /**
   * 时间字符串转换成毫秒值
   * 样例：2018-10-24 09:54:47 236 ==> 1540346087236
   *
   * @param time
   * @return
   */
  @throws[ParseException]
  def timeToLong(time: String, format: String): Long = {
    val sf = new SimpleDateFormat(format)
    sf.parse(time).getTime
  }

  def main(args: Array[String]): Unit = {

  }

  def addPartition(db:String,table:String,partitionBy:String,hdfsPath:String)={
    if(db!=null && db.length>0 && partitionBy!=null && partitionBy.length>0){
      if(spark!=null && !spark.sparkContext.isStopped){
        val cmd = s"alter table $db."+table+" add if not exists partition ("+partitionBy+") location '"+hdfsPath+"'"
        spark.sql(cmd)
      }else{
        val sql = s"""
use $db;
alter table $table add if not exists partition ($partitionBy) location '$hdfsPath';"""
        Util.runHiveSQL(db,sql)
      }
    }
  }

  def runHiveSQL(db:String,sql:String,logPath:String=null): Unit ={
    var log = ""
    val sh = "./_runhivesql_"+UUID.randomUUID()+".sh"
    val sqlFile = "./_runhivesql_"+UUID.randomUUID()+".sql"
    var cmd = ""
    if(logPath!=null){
      log = " > "+logPath
    }

    var useSqlFile = false
    val d = "" //"--hiveconf hive.root.logger=OFF -S"
    if(sql.indexOf(";") != -1 || sql.indexOf("\n") != -1){
      FileUtil.save(sqlFile,sql)

      cmd = "/app/hive/bin/hive "+d+" --database "+db+" -f "+sqlFile + log
      System.err.println(sql)
      System.err.println(cmd)
      useSqlFile = true
    }else{
      cmd = "/app/hive/bin/hive "+d+" --database "+db+" -e \""+sql+"\"" +log
      System.err.println(cmd)
    }

    FileUtil.save(sh,cmd)
    try{
      "./bash "+sh !;
    }catch {
      case e:Exception=>{
        "chmod +x "+sh !;
        sh !;
      }
    }
    new File(sh).deleteOnExit()
    if(useSqlFile)
      "rm -rf "+sqlFile !;
  }

  //电话数据解密
  def bdpDecodePhone(str:String,errmsgPrefix:String="") ={
    null
  }
}
