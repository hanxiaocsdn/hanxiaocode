package Utils

import java.util.regex.Pattern

/**
  * Created by 01368078 on 2018/2/7.
  */
object StringUtil {

  def pickGroup1Str(str: String, regex: String): String = {
    val pattern = Pattern.compile(regex)
    val matcher = pattern.matcher(str)
    if (matcher.find) matcher.group(1)
    else ""
  }

  def isNotBlank(str : String) : Boolean = {
    !isBlank(str)
  }

  def isBlank(str : String) : Boolean = {
    if(str == null || "".equals(str))
      true
    else
      false
  }

}

