package Utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class ShellExcutor {
	private  static Logger logger = LoggerFactory.getLogger(ShellExcutor.class);
	public static void exeCmd(String cmd) throws Exception {
		String os = System.getProperty("os.name");
		String [] shell;
		if(os.toLowerCase().contains("windows")){
			shell =new String[]{"cmd","/C",cmd}; 
		}else if (os.toLowerCase().contains("linux")){
			shell =new String[]{"/bin/sh","-c",cmd}; 
		}else{
			throw new Exception("not support os:"+os); 
		}
		try {
			Runtime runtime = Runtime.getRuntime();
            final Process process = runtime.exec(shell);
            StreamHandler errorStreamHandler = new StreamHandler(process.getErrorStream());
            errorStreamHandler.start();
            process.waitFor();
		} catch (IOException e1) {
			logger.error("cmd: "+cmd +", exception:"+e1.getMessage());
		}
	}
	
//	public static void main(String[] args) throws Exception {
//		exeCmd("cd F:\\项目\\数据平台-20180416\\jar && java -jar EffectTestPlatform.jar 64 01374443 9091 755_0605_deptcode_diff_sql.csv {\\\"ak\\\":\\\"a4fbd3a08ecc4f9e41bc9b06421ef3b5\\\",\\\"city\\\":\\\"755\\\",\\\"opt\\\":\\\"norm\\\"} 755_0605_deptcode_diff_rslt.csv onlyForResult");
//	}
}
