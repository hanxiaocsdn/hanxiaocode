package Utils

import com.alibaba.fastjson.JSONObject
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01374443 on 2020/3/25.
  */
object CityRegion {
  def typeCity(cityMap: Map[String, ArrayBuffer[Array[String]]],
              cityCode:String,addresseeAddr:String):(Boolean,JSONObject)={
    var city_code = cityCode
    if (city_code == null) city_code = "-"
    val jsobj = new JSONObject()
    jsobj.put("region", "")
    jsobj.put("city", "")
    jsobj.put("area","")
    jsobj.put("cityCode", city_code)
    var flag = false
    if (cityMap.contains(city_code)) {
      flag = true
      val cityList: ArrayBuffer[Array[String]] = cityMap.apply(city_code)
      if (cityList.length == 1) {
        //如果只有一个list，一一对应的，直接返回
        jsobj.put("region", cityList(0)(1))
        jsobj.put("city", cityList(0)(2))
        jsobj.put("area", cityList(0)(4))
      } else if (cityList.length > 1) {
        //一个城市代码对应多个城市
        jsobj.put("region", cityList(0)(1))
        jsobj.put("area", cityList(0)(4))
        for (cityObj <- cityList) {
          val city = cityObj(2)
          val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
          if (addresseeAddr!=null && (addresseeAddr.contains(city) || addresseeAddr.contains(city1))) {
            jsobj.put("city", cityObj(2))
          } else {
            if (jsobj.getString("city") == null) {
              jsobj.put("city", "-")
            }
          }
        }
      }
    }
    (flag,jsobj)
  }
  def typeCity(cityMap: Map[String, ArrayBuffer[Array[String]]],
               cityCode:String,cityName:String,addresseeAddr:String):(Boolean,JSONObject)={
    var city_code = cityCode
    if (city_code == null) city_code = "-"
    val jsobj = new JSONObject()
    jsobj.put("region", "")
    jsobj.put("city", "")
    jsobj.put("cityCode", city_code)
    var flag = false
    if (cityMap.contains(city_code)) {
      flag = true
      val cityList: ArrayBuffer[Array[String]] = cityMap.apply(city_code)
      if (cityList.length == 1) {
        //如果只有一个list，一一对应的，直接返回
        jsobj.put("region", cityList(0)(1))
        jsobj.put("city", cityList(0)(2))
      } else if (cityList.length > 1) {
        //一个城市代码对应多个城市
        jsobj.put("region", cityList(0)(1))
        for (cityObj <- cityList) {
          val city = cityObj(2)
          val city1 = city.substring(0, city.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
          if(cityName!=null && (cityName.contains(city) || cityName.contains(city1))){
            jsobj.put("city", cityObj(2))
          }else if (addresseeAddr!=null && (addresseeAddr.contains(city) || addresseeAddr.contains(city1))) {
            jsobj.put("city", cityObj(2))
          } else {
            if (jsobj.getString("city") == null) {
              jsobj.put("city", "-")
            }
          }
        }
      }
    }
    (flag,jsobj)
  }
  val logger: Logger = Logger.getLogger(CityRegion.getClass)
  def getCityReionMap(javaUtil:JavaUtil):Map[String, ArrayBuffer[Array[String]]] ={
    val conn = DbUtils.getConnection(javaUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("province", "region", "city", "citycode","area")
    val regionSelectSql = s"select province,region,city,citycode,area from $regoinCityTable"
    //    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    logger.error("data size :" + regions.size)
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(3).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }
    cityMap
  }
}
