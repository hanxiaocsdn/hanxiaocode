package Utils;


import javax.activation.MimetypesFileTypeMap;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.*;

public class FileUtil implements Serializable {
    public static final int BUFSIZE = 1024 * 8;

    public static String readFileByLines(String fileName, boolean skipEmptyLine) {
        return readFileByLines(fileName, skipEmptyLine, "");
    }

    public static String readFileByLines(String fileName, boolean skipEmptyLine, String appendMsg) {
        File file = new File(fileName);
        if (!file.exists()) return "";
        BufferedReader reader = null;
        StringBuffer sb = new StringBuffer();
        try {
            //System.out.println("以行为单位读取文件内容，一次读一整行：");
            reader = new BufferedReader(new FileReader(file));
            String tempString = null;
            int line = 1;
            // 一次读入一行，直到读入null为文件结束
            while ((tempString = reader.readLine()) != null) {
                tempString = tempString.replaceAll("\r\n", "").replaceAll("\r", "").replaceAll("\n", "").trim();
//                if(skipEmptyLine && tempString.length() < 5){
//                    System.err.println("FileUtil.readFileByLines() => maby empty line:【"+tempString+"】");
//                }
                if (skipEmptyLine && tempString.length() == 0) {
//                    System.err.println("FileUtil.readFileByLines() => skip empty line");
                    continue;
                }
                // System.err.println(fileName+"\t"+tempString);
                sb.append(tempString + appendMsg + "\n");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        return sb.toString();
    }

    public static void appendToFile(String path, String txt) {
        FileWriter fw = null;
        int trys = 0;
        while (fw == null) {
            try {
                File f = new File(path);
                fw = new FileWriter(f, true);
            } catch (IOException e) {
                e.printStackTrace();
                try {
                    trys++;
                    Thread.currentThread().sleep(1000);
                    System.err.println("fw is null, retry: " + trys);
                } catch (Exception ex) {
                }
            }
        }

        PrintWriter pw = new PrintWriter(fw);
        pw.print(txt);
        pw.flush();
        try {
            fw.flush();
            pw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static synchronized File save(String path, String txt) throws Exception {
//        System.err.println("======================================================================================");
//        System.err.println("【write file len("+txt.length()+") to disk】"+path);
//        System.err.println("======================================================================================");
        File f = new File(path);
        try {
            if (!f.getParentFile().exists())
                f.getParentFile().mkdirs();
            Writer writer = new PrintWriter(
                    new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f), "UTF-8")));
            writer.write(txt);
            writer.flush();
            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        long cnt = 0;
        while (cnt < 1800 && (!new File(path).exists()) || new File(path).length() < txt.length()) {
            Thread.sleep(100);
            if (cnt % 200 == 0)
                System.out.println();
            cnt++;
            System.out.print(".");
        }
        if (cnt >= 1800) {
            System.err.println("文件写入磁盘超时【180s】：" + path);
            return save(path, txt);
        } else {
//            System.err.println("======================================================================================");
//            System.err.println("【write file len("+txt.length()+") to disk done】"+path+"\t"+new File(path).length());
//            System.err.println("======================================================================================");
        }
        return f;
    }

    public static void merge(String outFile, String[] files) {
        System.err.println("FileUtil.merge(): " + outFile + "\t" + files.length);
        FileChannel outChannel = null;
        try {
            File of = new File(outFile);
            if (!of.getParentFile().exists())
                of.getParentFile().mkdirs();
            of.delete();
            of = new File(outFile);
            of.createNewFile();
            for (String fb : files) {
                String tmpFileName = "tmp_" + of.getName() + "_" + new Date().getTime() + ".csv";
                //File f = byte2File(fb,".",tmpFileName);
                File f = save("./" + tmpFileName, fb);
                //System.err.println(f.getAbsolutePath()+"\t"+f.length());
                if (f.length() == 0) continue;
                String txt = readFileByLines(tmpFileName, true);
                appendToFile(of.getAbsolutePath(), txt);
                f.delete();
            }
            System.out.println("Merged!! " + of.getAbsolutePath() + "\t Size:" + new File(outFile).length());
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (outChannel != null) {
                    outChannel.close();
                }
            } catch (IOException ignore) {
                ignore.printStackTrace();
            }
        }
    }

    public static void merge(String outFile, byte[][] files) {
        //System.err.println("FileUtil.merge(): "+outFile+"\t"+files.length);
        FileChannel outChannel = null;
        try {
            File of = new File(outFile);
            if (!of.getParentFile().exists())
                of.getParentFile().mkdirs();
            of.delete();
            of = new File(outFile);
            of.createNewFile();
            for (byte[] fb : files) {
                String tmpFileName = "tmp_" + of.getName() + "_" + new Date().getTime() + ".csv";
                File f = byte2File(fb, ".", tmpFileName);
                //System.err.println(f.getAbsolutePath()+"\t"+f.length());
                if (f.length() == 0) continue;
                String txt = readFileByLines(tmpFileName, true);
                appendToFile(of.getAbsolutePath(), txt);
                f.delete();
            }
            System.out.println("Merged!! " + of.getAbsolutePath() + "\t Size:" + new File(outFile).length());
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (outChannel != null) {
                    outChannel.close();
                }
            } catch (IOException ignore) {
                ignore.printStackTrace();
            }
        }
    }

    public static void merge_direct(String outFile, byte[][] files) {
        //System.err.println("FileUtil.merge(): "+outFile+"\t"+files.length);
        FileChannel outChannel = null;
        try {
            File of = new File(outFile);
            if (!of.getParentFile().exists())
                of.getParentFile().mkdirs();
            if (!of.exists())
                of.createNewFile();
            outChannel = new FileOutputStream(outFile).getChannel();
            for (byte[] fb : files) {
                String tmpFileName = "tmp_" + of.getName() + "_" + new Date().getTime() + ".csv";
                File f = byte2File(fb, ".", tmpFileName);
                //System.err.println(f.getAbsolutePath()+"\t"+f.length());
                if (f.length() == 0) continue;
                FileChannel fc = new FileInputStream(f).getChannel();
                fc.transferTo(0, fc.size(), outChannel);
                fc.close();
                outChannel.write(ByteBuffer.wrap("\n".getBytes()));
                f.delete();
            }
            System.out.println("Merged!! " + of.getAbsolutePath() + "\t Size:" + new File(outFile).length());
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (outChannel != null) {
                    outChannel.close();
                }
            } catch (IOException ignore) {
                ignore.printStackTrace();
            }
        }
    }

    public static void merge_with_buffer(String outFile, byte[][] files) {
        //System.err.println("FileUtil.merge(): "+outFile+"\t"+files.length);
        FileChannel outChannel = null;
        try {
            File of = new File(outFile);
            if (!of.getParentFile().exists())
                of.getParentFile().mkdirs();
            if (!of.exists())
                of.createNewFile();
            outChannel = new FileOutputStream(outFile).getChannel();
            for (byte[] fb : files) {
                String tmpFileName = "tmp_" + of.getName() + "_" + new Date().getTime() + ".csv";
                File f = byte2File(fb, ".", tmpFileName);
                //System.err.println(f.getAbsolutePath()+"\t"+f.length());
                if (f.length() == 0) continue;
                FileChannel fc = new FileInputStream(f).getChannel();
                ByteBuffer bb = ByteBuffer.allocate(BUFSIZE);
                while (fc.read(bb) != -1) {
                    bb.flip();
                    outChannel.write(bb);
                    bb.clear();
                }
                fc.close();
                f.delete();
            }
            System.out.println("Merged!! " + of.getAbsolutePath() + "\t Size:" + new File(outFile).length());
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (outChannel != null) {
                    outChannel.close();
                }
            } catch (IOException ignore) {
                ignore.printStackTrace();
            }
        }
    }

    public static void merge(String outFile, File[] files) {
        //System.err.println("FileUtil.merge(): "+outFile+"\t"+files.length);
        FileChannel outChannel = null;
        try {
            File of = new File(outFile);
            if (!of.getParentFile().exists())
                of.getParentFile().mkdirs();
            if (!of.exists())
                of.createNewFile();
            outChannel = new FileOutputStream(outFile, true).getChannel();
            for (File f : files) {
                //System.err.println(f.getName()+"\t"+f.length());
                if (f.length() == 0) continue;
                FileChannel fc = new FileInputStream(f).getChannel();
                ByteBuffer bb = ByteBuffer.allocate(BUFSIZE);
                while (fc.read(bb) != -1) {
                    bb.flip();
                    outChannel.write(bb);
                    bb.clear();
                }
                fc.close();
            }
            System.out.println("Merged!! " + of.getAbsolutePath() + "\t Size:" + new File(outFile).length());

        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (outChannel != null) {
                    outChannel.close();
                }
            } catch (IOException ignore) {
                ignore.printStackTrace();
            }
        }
    }

    public static byte[] toByteArray(String filename) throws IOException {

        FileChannel fc = null;
        try {
            fc = new RandomAccessFile(filename, "r").getChannel();
            MappedByteBuffer byteBuffer = fc.map(FileChannel.MapMode.READ_ONLY, 0,
                    fc.size()).load();
            //System.out.println(byteBuffer.isLoaded());
            byte[] result = new byte[(int) fc.size()];
            if (byteBuffer.remaining() > 0) {
                // System.out.println("remain");
                byteBuffer.get(result, 0, byteBuffer.remaining());
            }
            return result;
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                fc.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    public static byte[] File2byte(String filePath) {
        byte[] buffer = null;
        try {
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] b = new byte[1024];
            int n;
            while ((n = fis.read(b)) != -1) {
                bos.write(b, 0, n);
            }
            fis.close();
            bos.close();
            buffer = bos.toByteArray();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return buffer;
    }


    public static File byte2File(byte[] buf, String filePath, String fileName) {
        BufferedOutputStream bos = null;
        FileOutputStream fos = null;
        File file = null;
        try {
            File dir = new File(filePath);
            if (!dir.exists() && dir.isDirectory()) {
                dir.mkdirs();
            }
            file = new File(filePath + File.separator + fileName);
            fos = new FileOutputStream(file);
            bos = new BufferedOutputStream(fos);
            bos.write(buf);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return file;
    }

    public static void check(String path) {
        File f = new File(path);
        File[] flist = f.listFiles();
        for (int i = 0; i < flist.length; i++) {
            File t = flist[i];
            if (t.isDirectory())
                check(t.getAbsolutePath());
            else {
                String s = FileUtil.readFileByLines(t.getAbsolutePath(), true);
                if (s.indexOf("p_incsgs_taskflow_waybill_addr.") != -1) {
                    //System.err.println("delete: "+t.getAbsolutePath());
                    t.delete();
                }
            }
        }
    }

    public static synchronized String formUpload(String path) {
        HashMap fileMap = new HashMap<String, String>();
        fileMap.put("file", new File(path).getAbsolutePath());
//      FileUtil.formUpload("http://gis-ass-mg.sf-express.com/ScriptTool/pushFile",fileMap)
        return FileUtil.formUpload("http://10.116.187.89:8080/ScriptTool/pushFile", fileMap);
    }

    public static synchronized String formUpload(String urlStr, Map<String, String> fileMap) {
        String res = "";
        HttpURLConnection conn = null;
        String BOUNDARY = "---------------------------123821742118716"; //boundary就是request头和上传文件内容的分隔符
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(30000);
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent",
                    "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/537.36");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);
            conn.connect();

            OutputStream out = new DataOutputStream(conn.getOutputStream());

            if (fileMap != null) {
                Iterator<Map.Entry<String, String>> iter = fileMap.entrySet().iterator();
                while (iter.hasNext()) {
                    Map.Entry<String, String> entry = iter.next();
                    String inputName = (String) entry.getKey();
                    String inputValue = (String) entry.getValue();
                    if (inputValue == null) {
                        continue;
                    }
                    File file = new File(inputValue);
                    String filename = file.getName();
                    String contentType = new MimetypesFileTypeMap().getContentType(inputValue);

                    StringBuffer strBuf = new StringBuffer();
                    strBuf.append("\r\n").append("--").append(BOUNDARY).append("\r\n");
                    strBuf.append("Content-Disposition: form-data; name=\"" + inputName + "\"; filename=\"" + filename + "\"\r\n");
                    strBuf.append("Content-Type:" + contentType + "\r\n\r\n");

                    out.write(strBuf.toString().getBytes());

                    DataInputStream in = new DataInputStream(new FileInputStream(file));
                    int bytes = 0;
                    byte[] bufferOut = new byte[1024];
                    while ((bytes = in.read(bufferOut)) != -1) {
                        out.write(bufferOut, 0, bytes);
                    }
                    in.close();
                }
            }

            byte[] endData = ("\r\n--" + BOUNDARY + "--\r\n").getBytes();
            out.write(endData);
            out.flush();
            out.close();

            // 读取返回数据
            StringBuffer strBuf = new StringBuffer();
            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String line = null;
            while ((line = reader.readLine()) != null) {
                strBuf.append(line).append("\n");
            }
            res = strBuf.toString();
            reader.close();
            reader = null;
        } catch (Exception e) {
            System.err.println("发送POST请求出错。" + urlStr);
            e.printStackTrace();
        } finally {
            if (conn != null) {
                conn.disconnect();
                conn = null;
            }
        }
        return res;
    }

    public static Properties getFileProperties(String configPath) {
        Properties props = new Properties();
        try (InputStream in = FileUtil.class.getClassLoader().getResourceAsStream(configPath);
             InputStreamReader isr = new InputStreamReader(in, "UTF-8"); //解决读取中文出现乱码
             BufferedReader bf = new BufferedReader(isr);
        ) {
            props.load(bf);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return props;
    }
}
