package uitls;



import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Splitter;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.ServiceUnavailableRetryStrategy;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.datanucleus.util.StringUtils;
import java.io.*;
import java.text.ParseException;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UrlUtils {
    public static final Logger logger = LoggerFactory.getLogger(com.sf.gis.java.base.util.UrlUtil.class);
    private static PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    private static CloseableHttpClient httpClient = null;
    private static boolean isInitConnection = false;
    static {
        initConnectionManager();
    }
    public static void initConnectionManager() {
        try {
            connManager.setMaxTotal(5); // 设置整个连接池最大连接数 根据自己的场景决定
            // 是路由的默认最大连接（该值默认为2），限制数量实际使用DefaultMaxPerRoute并非MaxTotal。设置过小无法支持大并发(ConnectionPoolTimeoutException: Timeout waiting for connection from pool)，路由是对maxTotal的细分。
            connManager.setDefaultMaxPerRoute(5);// （目前只有一个路由，因此让他等于最大值）
            SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setSoTimeout(3000).setTcpNoDelay(true).build();
            connManager.setDefaultSocketConfig(socketConfig);

            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(3000).setConnectTimeout(3000).setSocketTimeout(3000).build();
            httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(connManager).build();
        } catch (Exception e) {
            logger.error("initConnectionManager error. ", e);
        }
    }
    public static String sendPost(String req, String param, int maxTryTime) {
        String content = sendPost(req, param);
        int tryTime = 0;
        while (StringUtils.isEmpty(content) && ++tryTime <= maxTryTime) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            logger.error("try time {}: {}", maxTryTime, req);
            content = sendPost(req, param);
        }
        return content;
    }
    public static String sendPost(String url, String param) {
        String jsonStr = null;
        CloseableHttpResponse response = null;
        HttpPost post = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }

            post = new HttpPost(url);
            post.setHeader("Content-Type", "application/json");
            post.setHeader("Connection", "Keep-Alive");

            //修改时长
            RequestConfig config = RequestConfig.custom()
                    .setConnectTimeout(50000) //连接超时时间
                    .setConnectionRequestTimeout(50000) //从连接池中取的连接的最长时间
                    .setSocketTimeout(50000) //数据传输的超时时间
                    .build();
            //设置请求配置时间
            post.setConfig(config);


            HttpEntity re = new StringEntity(param, "UTF-8");
            post.setEntity(re);

            response = httpClient.execute(post);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, "utf-8");
        } catch (Exception e) {
            logger.error("resonse - {}", response);
            logger.error("readContentFromPost err. ", e);
        } finally {
            try {
                if (jsonStr != null) {
                    if (post != null) {
                        EntityUtils.consume(entity);
                        post.releaseConnection();
                    }
                    if (response != null) {
                        response.close();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return jsonStr;
    }

}
