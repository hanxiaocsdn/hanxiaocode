package application

import java.text.SimpleDateFormat
import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * @Description:解析油站推荐接口出参及入参
 * 需求人员：01403789 左佳怡
 * @Author: lixiangzhi 01405644
 * @Date:20240104
 * 任务id:962017
 * 任务名称：解析油站推荐接口返回数据
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object AnalyzeGasRecommendInterfaces {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readSourceData(spark: SparkSession, incDay: String) = {
    val naviQueryHiveSql=
      s"""
        |select data
        |from dm_gis.gis_eta_navi_query_hive
        |where inc_day = '$incDay'
        |and (data like '%grdFuelChargingInfoLog%'
        |or data like '%adjustPathLog%')
        |--limit 10000
        |""".stripMargin
    val naviQueryHiveRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, naviQueryHiveSql).filter(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val subType: String = dataObj.getString("subType")
      subType == "grdFuelChargingInfoLog" || subType == "adjustPathLog"
    })
    val queryProtoHiveSql=
      s"""
        |select data
        |from dm_gis.gis_eta_navi_query_proto_hive
        |where inc_day = '$incDay'
        |and data like '%adjustPathLog%'
        |--limit 10000
        |""".stripMargin
    val queryProtoHiveRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, queryProtoHiveSql).filter(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val subType: String = dataObj.getString("subType")
      subType == "adjustPathLog"
    })
    val sdkNaviParseSql=
      s"""
        |select
        |content
        |from dm_gis.gis_navi_sdk_navi_parse
        |where inc_day = '$incDay'
        |and type = '37'
        |and content!=''
        |and content is not null
        |""".stripMargin
    val sdkNaviParseRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, sdkNaviParseSql)
    (naviQueryHiveRdd,queryProtoHiveRdd,sdkNaviParseRdd)
  }

  def analyzeTable1(spark: SparkSession, tuple3: (RDD[JSONObject], RDD[JSONObject], RDD[JSONObject]), incDay: String) = {
    import spark.implicits._
    val naviQueryHiveRdd: RDD[JSONObject] = tuple3._1
    val value: RDD[JSONObject] = naviQueryHiveRdd.filter(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val subType: String = dataObj.getString("subType")
      subType == "grdFuelChargingInfoLog"
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("value:"+value.count())
    value.take(1).foreach(println(_))
    val grdFuelChargingInfoLogRdd: RDD[(String, JSONObject)] = value.map(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val dataInObj: JSONObject = JSONUtil.getJsonObjectMulti(dataObj, "data")
      val fuelChargingInfoArg: JSONObject = JSONUtil.getJsonObjectMulti(dataInObj, "fuelChargingInfoArg")
      val deptCode: String = fuelChargingInfoArg.getString("deptCode")
      val isChanged: String = fuelChargingInfoArg.getString("isChanged")
      val isFuelPoint: String = fuelChargingInfoArg.getString("isFuelPoint")
      val litersNumber: String = fuelChargingInfoArg.getString("litersNumber")
      val unitPrice: String = fuelChargingInfoArg.getString("unitPrice")
      var taskSerial: String = fuelChargingInfoArg.getString("taskSerial")
      val username: String = fuelChargingInfoArg.getString("username")
      val vehicleCode: String = fuelChargingInfoArg.getString("vehicleCode")
      if (taskSerial == "/") {
        taskSerial = fuelChargingInfoArg.getString("taskId")
      }
      obj.put("deptcode", deptCode)
      obj.put("ischanged", isChanged)
      obj.put("isfuelpoint", isFuelPoint)
      obj.put("litersnumber", litersNumber)
      obj.put("unitprice", unitPrice)
      obj.put("taskserial", taskSerial)
      obj.put("username", username)
      obj.put("vehiclecode", vehicleCode)
      obj.remove("data")
      (taskSerial,obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("grdFuelChargingInfoLogRdd:"+grdFuelChargingInfoLogRdd.count())
    grdFuelChargingInfoLogRdd.take(5).foreach(println(_))
    value.unpersist()
    val value1: RDD[JSONObject] = naviQueryHiveRdd.filter(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val subType: String = dataObj.getString("subType")
      subType == "adjustPathLog"
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("value1:"+value1.count())
    value1.take(1).foreach(println(_))
    val value2: RDD[(String, JSONObject)] = value1.map(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val reqId: String = dataObj.getString("reqId")
      val dataInObj: JSONObject = JSONUtil.getJsonObjectMulti(dataObj, "data")
      val adjustPathArg: JSONObject = JSONUtil.getJsonObjectMulti(dataInObj, "adjustPathArg")
      val taskId: String = adjustPathArg.getString("taskId")
      val requestId: String = dataInObj.getString("requestId")
      val pnsAdjustPathArgs: JSONObject = JSONUtil.getJsonObjectMulti(dataInObj, "pnsAdjustPathArgs")
      val projectNo: String = pnsAdjustPathArgs.getString("projectNo")
      val fuelLeftDistance: String = pnsAdjustPathArgs.getString("fuelLeftDistance")
      val pathList: String = pnsAdjustPathArgs.getString("pathList")
      val reqStartTime: Long = dataInObj.getLongValue("reqStartTime")
      val reqTime: String = DateUtil.longToTime(reqStartTime,"yyyy-MM-dd HH:mm:ss")
      val appVer: String = adjustPathArg.getString("appVer")
      val fuelNo: String = pnsAdjustPathArgs.getString("fuelNo")
      val stdIdList: String = pnsAdjustPathArgs.getString("stdIdList")
      val stdLineRecommend: String = pnsAdjustPathArgs.getString("stdLineRecommend")
      val lineCode: String = adjustPathArg.getString("lineCode")
      val DriverId: String = adjustPathArg.getString("driverId")
      val startFuelSize: String = pnsAdjustPathArgs.getString("startFuelSize")
      val startFuelSizeArti: String = pnsAdjustPathArgs.getString("startFuelSizeArti")
      val taskClassification: String = adjustPathArg.getString("taskClassification")
      var taskSerial: String = adjustPathArg.getString("taskId")
      val fuelSize: String = adjustPathArg.getString("fuelSize")
      if (StringUtils.isNoneEmpty(taskId) && taskId.contains("Y")) {
        if (taskId.split("Y").size>=2){
          taskSerial = taskId.split("Y")(1)
        }
      }
      obj.put("reqid", reqId)
      obj.put("taskid", taskId)
      obj.put("requestid", requestId)
      obj.put("projectno", projectNo)
      obj.put("fuelleftdistance", fuelLeftDistance)
      obj.put("pathlist", pathList)
      obj.put("reqtime", reqTime)
      obj.put("appver", appVer)
      obj.put("fuelno", fuelNo)
      obj.put("stdidlist", stdIdList)
      obj.put("stdlinerecommend", stdLineRecommend)
      obj.put("linecode", lineCode)
      obj.put("driverid", DriverId)
      obj.put("startfuelsize", startFuelSize)
      obj.put("startfuelsizearti", startFuelSizeArti)
      obj.put("taskclassification", taskClassification)
      obj.put("taskserial", taskSerial)
      obj.put("fuelsize", fuelSize)
      obj.remove("data")
      (taskSerial, obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("value2:"+value2.count())
    value2.take(5).foreach(println(_))
    value1.unpersist()
    val analyzeGasRecommendDf: DataFrame = value2.leftOuterJoin(grdFuelChargingInfoLogRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      val reqid: String = leftObj.getString("reqid")
      val taskid: String = leftObj.getString("taskid")
      val requestid: String = leftObj.getString("requestid")
      val taskserial: String = leftObj.getString("taskserial")
      ((reqid, taskid, requestid, taskserial), leftObj)
    }).groupByKey().map(obj => {
      val tmpObj: JSONObject = obj._2.toList.maxBy(json=>{
        JSONUtil.getJsonValSingle(json,"startfuelsize")
      })
      tmpObj
    }).map(obj => {
      CaseHiveLog(
        obj.getString("reqid"),
        obj.getString("deptcode"),
        obj.getString("ischanged"),
        obj.getString("isfuelpoint"),
        obj.getString("litersnumber"),
        obj.getString("unitprice"),
        obj.getString("taskserial"),
        obj.getString("username"),
        obj.getString("vehiclecode"),
        obj.getString("taskid"),
        obj.getString("requestid"),
        obj.getString("projectno"),
        obj.getString("fuelleftdistance"),
        obj.getString("pathlist"),
        obj.getString("reqtime"),
        obj.getString("appver"),
        obj.getString("fuelno"),
        obj.getString("stdidlist"),
        obj.getString("stdlinerecommend"),
        obj.getString("linecode"),
        obj.getString("driverid"),
        obj.getString("startfuelsize"),
        obj.getString("startfuelsizearti"),
        obj.getString("taskclassification"),
        obj.getString("fuelsize")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,analyzeGasRecommendDf,"inc_day",incDay,"dm_gis.dm_eta_hive_log_di")
  }

  def analyzeTable2(spark: SparkSession, tuple3: (RDD[JSONObject], RDD[JSONObject], RDD[JSONObject]), incDay: String) = {
    import spark.implicits._
    //读取dm_eta_hive_log_di表
    val hiveLogSql=
      s"""
        |select * from dm_gis.dm_eta_hive_log_di where inc_day='$incDay'
        |""".stripMargin
    val hiveLogRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, hiveLogSql)
    val queryProtoHiveRdd: RDD[JSONObject] = tuple3._2
    queryProtoHiveRdd.take(5).foreach(println(_))
    val sdkNaviParseRdd: RDD[(String, JSONObject)] = tuple3._3.map(obj=>{
      val content: String = obj.getString("content")
      val contentObj: JSONObject = JSON.parseObject(content)
      val requestId: String = contentObj.getString("requestId")
      (requestId,obj)
    }).filter(obj=>{StringUtils.isNoneEmpty(obj._1)})
    val hiveProtoLogDimRdd: RDD[(String, JSONObject)] = queryProtoHiveRdd.map(obj => {
      val data: String = obj.getString("data")
      val dataObj: JSONObject = JSON.parseObject(data)
      val subType: String = dataObj.getString("subType")
      obj.put("sub_type", subType)
      val info: String = dataObj.getString("info")
      if (info == "Succ") {
        val requestId: String = dataObj.getString("requestId")
        obj.put("requestid", requestId)
      }
      val pathWithPoi: JSONArray = JSONUtil.getJsonArrayMulti(dataObj, "pathWithPoi")
      val poiArray = new util.ArrayList[JSONObject]()
      val pathWithPoiTmpArray = new util.ArrayList[JSONObject]()
      if (info == "Succ" && pathWithPoi.size() != 0) {
        for (i <- 0 until (pathWithPoi.size())) {
          val pathWithPoiTmpObj = new JSONObject()
          val pathWithPoiObj: JSONObject = pathWithPoi.getJSONObject(i)
          val poi: JSONObject = JSONUtil.getJsonObjectMulti(pathWithPoiObj, "poi")
          val displayPos: JSONObject = JSONUtil.getJsonObjectMulti(poi, "displayPos")
          val x: String = (displayPos.getDoubleValue("x") / 3600000).formatted("%.7f")
          val y: String = (displayPos.getDoubleValue("y") / 3600000).formatted("%.7f")
          val oil_point: String = x +","+ y
          val pathResult: JSONObject = JSONUtil.getJsonObjectMulti(pathWithPoiObj, "pathResult")
          val pathes: JSONArray = JSONUtil.getJsonArrayMulti(pathResult, "pathes")
          val distArray = new util.ArrayList[Double]()
          val polylineArray = new util.ArrayList[String]()
          for (j <- 0 until (pathes.size())) {
            val pathesObj: JSONObject = pathes.getJSONObject(j)
            val viaPathes: JSONArray = JSONUtil.getJsonArrayMulti(pathesObj, "viaPathes")
            for (k <- 0 until (viaPathes.size())) {
              val viaPathesObj: JSONObject = viaPathes.getJSONObject(k)
              val distance: Double = viaPathesObj.getDoubleValue("distance")
              distArray.append(distance)
            }
            val polylineX: String = pathesObj.getString("polylineX")
            val polylineY: String = pathesObj.getString("polylineY")
            val polylineXdArrayNew = new util.ArrayList[String]()
            if (StringUtils.isNoneEmpty(polylineX)) {
              val polylineXArray: Array[String] = polylineX.replace("[", "").replace("]", "").split(",")
              val polylineXdArray = new util.ArrayList[Double]()
              for (elem <- polylineXArray) {
                val polylineXd: Double = elem.toDouble
                polylineXdArray.append(polylineXd)
              }
              var polylineXI: Double = polylineXdArray(0)
              for (l <- 0 until(polylineXdArray.size())){
                if (l<polylineXdArray.size()-1){
                  val polylineXJ: Double = polylineXdArray(l+1)
                  polylineXI =  polylineXI + polylineXJ
                  val polylineXdNew: String = (polylineXI / 3600000).formatted("%.7f")
                  polylineXdArrayNew.append(polylineXdNew)
                }
              }
            }
            val polylineYdArrayNew = new util.ArrayList[String]()
            if (StringUtils.isNoneEmpty(polylineY)) {
              val polylineYArray: Array[String] = polylineY.replace("[", "").replace("]", "").split(",")
              val polylineYdArray = new util.ArrayList[Double]()
              for (elem <- polylineYArray) {
                val polylineYd: Double = elem.toDouble
                polylineYdArray.append(polylineYd)
              }
              var polylineYI: Double = polylineYdArray(0)
              for (m <- 0 until(polylineYdArray.size())){
                if (m<polylineYdArray.size()-1){
                  val polylineYJ: Double = polylineYdArray(m+1)
                  polylineYI = polylineYI + polylineYJ
                  val polylineYdNew: String = (polylineYI / 3600000).formatted("%.7f")
                  polylineYdArrayNew.append(polylineYdNew)
                }
              }
            }
            val polylineXYdArrayNew = new util.ArrayList[String]()
            if (polylineXdArrayNew.nonEmpty){
              for (n <- 0 until(polylineXdArrayNew.size())){
                val polylineIn: String = polylineXdArrayNew(n) +","+ polylineYdArrayNew(n)
                polylineXYdArrayNew.append(polylineIn)
              }
            }
            val polyline: String = polylineXYdArrayNew.mkString(";")
            polylineArray.append(polyline)
          }
          var dist: Double = 0.0
          if (distArray.nonEmpty) {
            dist = distArray.sum
          }
          var plan_tracks = ""
          if (polylineArray.nonEmpty) {
            plan_tracks = polylineArray.mkString(";")
          }
          poiArray.append(poi)
          val typePoiOil: String = pathWithPoiObj.getString("typePoiOil")
          val addOil: String = pathWithPoiObj.getString("addOil")
          pathWithPoiTmpObj.put("oil_point",oil_point)
          pathWithPoiTmpObj.put("dist",dist)
          pathWithPoiTmpObj.put("typePoiOil",typePoiOil)
          pathWithPoiTmpObj.put("addOil",addOil)
          pathWithPoiTmpObj.put("plan_tracks",plan_tracks)
          pathWithPoiTmpArray.append(pathWithPoiTmpObj)
        }
      }
      if (pathWithPoiTmpArray.nonEmpty) {
        val oil_point: String = pathWithPoiTmpArray.map(_.getString("oil_point")).mkString("|")
        val dist: Double = pathWithPoiTmpArray.map(_.getDoubleValue("dist")).sum
        val typePoiOil: String = pathWithPoiTmpArray.map(_.getString("typePoiOil")).mkString("|")
        val addOil: String = pathWithPoiTmpArray.map(_.getString("addOil")).mkString("|")
        val plan_tracks: String = pathWithPoiTmpArray.map(_.getString("plan_tracks")).mkString("|")
        obj.put("oil_point", oil_point)
        obj.put("final_dist", dist)
        obj.put("typepoioil", typePoiOil)
        obj.put("addoil", addOil)
        obj.put("plan_tracks", plan_tracks)
      }
      if (poiArray.nonEmpty) {
        val oil_name: String = poiArray.map(_.getString("name")).mkString("|")
        val oil_brand: String = poiArray.map(_.getString("chainCode")).mkString("|")
        val pathId: String = poiArray.map(_.getString("pathId")).mkString("|")
        val poiId: String = poiArray.map(_.getString("poiId")).mkString("|")
        val searchType: String = poiArray.map(_.getString("searchType")).mkString("|")
        val price: String = poiArray.map(_.getString("price")).mkString("|")
        obj.put("oil_name", oil_name)
        obj.put("oil_brand", oil_brand)
        obj.put("pathid", pathId)
        obj.put("poi_id", poiId)
        obj.put("searchtype", searchType)
        obj.put("oil_price", price)
      }
      val extras: JSONObject = JSONUtil.getJsonObjectMulti(dataObj, "extras")
      val oil_msg: String = extras.getString("oilMsg")
      obj.put("oil_msg", oil_msg)
      val recommenedRefuelSize: String = dataObj.getString("recommenedRefuelSize")
      val fuelScene: String = dataObj.getString("fuelScene")
      obj.put("recommenedrefuelsize", recommenedRefuelSize)
      obj.put("fuelscene", fuelScene)
      obj.remove("data")
      (obj.getString("requestid"), obj)
    }).leftOuterJoin(sdkNaviParseRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        val content: String = rightObj.getString("content")
        val contentObj: JSONObject = JSON.parseObject(content)
        val stationTag: String = contentObj.getString("stationTag")
        val stationType: String = contentObj.getString("stationType")
        val isShowed: String = contentObj.getString("isShowed")
        leftObj.put("stationtag", stationTag)
        leftObj.put("stationtype", stationType)
        leftObj.put("isshowed", isShowed)
      }
      (leftObj.getString("requestid"),leftObj)
    })
    val hiveProtoLogDf: DataFrame = hiveLogRdd.map(obj => {
      (obj.getString("requestid"), obj)
    }).leftOuterJoin(hiveProtoLogDimRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    }).map(obj => {
      CaseHiveProtoLog(
        obj.getString("sub_type"),
        obj.getString("requestid"),
        obj.getString("oil_point"),
        obj.getString("final_dist"),
        obj.getString("plan_tracks"),
        obj.getString("oil_name"),
        obj.getString("oil_brand"),
        obj.getString("oil_price"),
        obj.getString("pathid"),
        obj.getString("poi_id"),
        obj.getString("oil_msg"),
        obj.getString("recommenedrefuelsize"),
        obj.getString("fuelscene"),
        obj.getString("searchtype"),
        obj.getString("typepoioil"),
        obj.getString("addoil"),
        obj.getString("stationtag"),
        obj.getString("stationtype"),
        obj.getString("isshowed"),
        obj.getString("reqid"),
        obj.getString("deptcode"),
        obj.getString("ischanged"),
        obj.getString("isfuelpoint"),
        obj.getString("litersnumber"),
        obj.getString("unitprice"),
        obj.getString("taskserial"),
        obj.getString("username"),
        obj.getString("vehiclecode"),
        obj.getString("taskid"),
        obj.getString("projectno"),
        obj.getString("fuelleftdistance"),
        obj.getString("pathlist"),
        obj.getString("reqtime"),
        obj.getString("appver"),
        obj.getString("fuelno"),
        obj.getString("stdidlist"),
        obj.getString("stdlinerecommend"),
        obj.getString("linecode"),
        obj.getString("driverid"),
        obj.getString("startfuelsize"),
        obj.getString("startfuelsizearti"),
        obj.getString("taskclassification"),
        obj.getString("fuelsize")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,hiveProtoLogDf,"inc_day",incDay,"dm_gis.dm_eta_hive_proto_log_di")
  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取表 dm_supplier_roadbridge_fees_dtl
    val tuple3: (RDD[JSONObject], RDD[JSONObject], RDD[JSONObject]) = readSourceData(spark, incDay)
    //处理表1
    analyzeTable1(spark,tuple3,incDay)
    //处理表2
    analyzeTable2(spark,tuple3,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }
  case class CaseHiveLog(
                          reqid:String,
                          deptcode:String,
                          ischanged:String,
                          isfuelpoint:String,
                          litersnumber:String,
                          unitprice:String,
                          taskserial:String,
                          username:String,
                          vehiclecode:String,
                          taskid:String,
                          requestid:String,
                          projectno:String,
                          fuelleftdistance:String,
                          pathlist:String,
                          reqtime:String,
                          appver:String,
                          fuelno:String,
                          stdidlist:String,
                          stdlinerecommend:String,
                          linecode:String,
                          driverid:String,
                          startfuelsize:String,
                          startfuelsizearti:String,
                          taskclassification:String,
                          fuelsize:String
                        )

  case class CaseHiveProtoLog(
                              sub_type:String,
                              requestid:String,
                              oil_point:String,
                              final_dist:String,
                              plan_tracks:String,
                              oil_name:String,
                              oil_brand:String,
                              oil_price:String,
                              pathid:String,
                              poi_id:String,
                              oil_msg:String,
                              recommenedrefuelsize:String,
                              fuelscene:String,
                              searchtype:String,
                              typepoioil:String,
                              addoil:String,
                              stationtag:String,
                              stationtype:String,
                              isshowed:String,
                              reqid:String,
                              deptcode:String,
                              ischanged:String,
                              isfuelpoint:String,
                              litersnumber:String,
                              unitprice:String,
                              taskserial:String,
                              username:String,
                              vehiclecode:String,
                              taskid:String,
                              projectno:String,
                              fuelleftdistance:String,
                              pathlist:String,
                              reqtime:String,
                              appver:String,
                              fuelno:String,
                              stdidlist:String,
                              stdlinerecommend:String,
                              linecode:String,
                              driverid:String,
                              startfuelsize:String,
                              startfuelsizearti:String,
                              taskclassification:String,
                              fuelsize:String
                             )

}
