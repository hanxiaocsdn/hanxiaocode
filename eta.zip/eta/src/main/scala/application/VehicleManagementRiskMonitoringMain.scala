package application

import app.VehicleManagementRiskMonitoring

import java.util.{Calendar, Date, Map}
import com.sf.gis.java.base.util.{DateUtil, HttpConnection}
import com.sf.gis.scala.base.spark.Spark
import entry.vehicleLssEntry.VahicleLss
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}


/**
 * 需求描述 :  车管风险任务监控表
 * 开发负责人: guofangcai
 * 开发日期: 20220208
 * 功能表述： 1. 获取dm_gis.eta_std_line_task_parse最近一天数据,以相同的起始网点和结束网点分组
 *           2. 分组数据校验轨迹信息
 *           3. 轨迹信息校验相似度判断是否是同一个
 *           4. 落地表 dm_gis.eta_vehicle_management_risk_monitoring
 */
object VehicleManagementRiskMonitoringMain {

  val className : String  = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)

  //  case  class  VehicleEntry(id:String,a_track:String,b_track:String ,a_len:BigDecimal, a_similarity:BigDecimal,b_len:BigDecimal, b_similarity:BigDecimal)

  def main(args: Array[String]): Unit = {
    //解析参数
    val (inc_day,logLevel, repartitionNum , threadSleepTime) = parseArgs(args)


    logger.info("任务执行开始")

    //数据获取sql拼接
    val lineTaskParseSql = VehicleManagementRiskMonitoring.getSourceDataSql(inc_day)

    val sparkSession : SparkSession = Spark.getSparkSession(className,null , false, 0)

    //设置日志级别
    sparkSession.sparkContext.setLogLevel(logLevel)

    //引入隐式转换
    import sparkSession.implicits._
    val vehicleManagementDF  = sparkSession.sql(lineTaskParseSql).as[VahicleLss]
    vehicleManagementDF.persist(StorageLevel.MEMORY_AND_DISK)

    logger.info("原始数据量 " + vehicleManagementDF.count())

    //http 获取对应的数据并返回dataframe
    val vehicleLssDF : DataFrame  = vehicleManagementDF.repartition(repartitionNum)
      .mapPartitions(vahicleLsss => VehicleManagementRiskMonitoring.builderVehichleLssByHttp(vahicleLsss,threadSleepTime)).toDF()
    vehicleLssDF.persist(StorageLevel.MEMORY_AND_DISK);

    logger.info("处理后数据量 " + vehicleLssDF.count())

    vehicleManagementDF.unpersist()

    //保存数据select(Column("*"), col.as(colName))
    vehicleLssDF.createOrReplaceTempView("ETA_VEHICLE_MANAGEMENT_RISK_MONITORING_TEMP")

    val sql = String.format("insert overwrite table DEFAULT.ETA_VEHICLE_MANAGEMENT_RISK_MONITORING partition(inc_day) " + "select * from ETA_VEHICLE_MANAGEMENT_RISK_MONITORING_TEMP")
    logger.info(sql)
    sparkSession.sql(sql)

    //释放缓存
    vehicleLssDF.unpersist()

    logger.info("任务执行完成")
    sparkSession.stop()

  }

  /**
   * 日志级别默认是info, 日期默认是当前时间的前一天
   * @param args
   */
  def parseArgs(args : Array[String])={
    var  logLevel = "INFO"
    var  repartitionNum = 100
    var  threadSleepTime = 5000
    //解析传入参数的
    var inc_day: String = args(0)
    logger.info( args(0)  +  inc_day)
    if(inc_day==null || inc_day.length==0){
      logger.warn("传入日期参数为空, 采用默认日期(当前日期-1)")
      inc_day = DateUtil.getDayBefore(new Date ().formatted("yyyy-MM-dd"), "yyyyMMdd", 1)
    }
    if (args.length > 1){
      logLevel = args(1)
    }
    if (args.length > 2){
      repartitionNum = Integer.parseInt(args(2))
    }
    if (args.length > 3){
      threadSleepTime = Integer.parseInt(args(3))
    }
    logger.info((inc_day,logLevel,repartitionNum,threadSleepTime).toString())
    (inc_day,logLevel,repartitionNum,threadSleepTime)
  }

}
