package application

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils}
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * @Description:获取停留点、请求前后轨迹数据
 * 需求人员：01403789 左佳怡
 * @Author: lixiangzhi 01405644
 * @Date:20240116
 * 任务id:966852
 * 任务名称：
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object HoldPointRequestTrajectory {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readSourceData(spark: SparkSession, incDay: String) = {
    val basicDataSql=
      s"""
        |select * from dm_gis.dm_basic_data_di where inc_day = '$incDay'
        |""".stripMargin
    val basicDataRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, basicDataSql)
    val oilPicSql=
      s"""
        |select
        |*
        |from dm_gis.gis_navi_oil_pic_log
        |where inc_day = '$incDay'
        |and data like '%Refuel%'
        |""".stripMargin
    val oilPicRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, oilPicSql).filter(obj => {
      val data: JSONObject = obj.getJSONObject("data")
      val imgType: String = data.getString("imgType")
      imgType == "Refuel"
    }).map(obj => {
      val data: JSONObject = obj.getJSONObject("data")
      val imgType: String = data.getString("imgType")
      val taskId: String = data.getString("taskId")
      val ossTempUrl: String = data.getString("ossTempUrl")
      val coordinate: String = data.getString("coordinate")
      val driverId: String = data.getString("driverId")
      val photoUploadType: String = data.getString("photoUploadType")
      val createTm: String = data.getString("createTm")
      obj.put("imgtype", imgType)
      obj.put("taskid", taskId)
      obj.put("osstempurl", ossTempUrl)
      obj.put("coordinate", coordinate)
      obj.put("driverid", driverId)
      obj.put("photouploadtype", photoUploadType)
      obj.put("createtm", createTm)
      obj.remove("data")
      obj
    })
    val sdkNaviParseSql=
      s"""
        |select task_id,content
        |from dm_gis.gis_navi_sdk_navi_parse
        |where inc_day = '$incDay'
        |and type = '7'
        |and operate = '司机所选油站名称及坐标'
        |and content is not null
        |and content !=''
        |group by task_id,content
        |""".stripMargin
    val sdkNaviParseRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, sdkNaviParseSql).groupBy(_.getString("task_id")).map(obj => {
      val content: String = obj._2.toList.map(_.getString("content")).mkString("|")
      val tmpObj = new JSONObject()
      tmpObj.put("task_id", obj._1)
      tmpObj.put("content", content)
      tmpObj
    })
    (basicDataRdd,oilPicRdd,sdkNaviParseRdd)

  }

  def joinTuple2Interface(spark: SparkSession, tuple3: (RDD[JSONObject], RDD[JSONObject], RDD[JSONObject]), incDay: String) = {
    import spark.implicits._
    val basicDataRdd: RDD[JSONObject] = tuple3._1
    val oilPicRdd: RDD[(String, JSONObject)] = tuple3._2.map(obj=>{
      (obj.getString("taskid"),obj)
    })
    val joinBasicOilRdd: RDD[JSONObject] = basicDataRdd.map(obj => {
      (obj.getString("task_id"), obj)
    }).leftOuterJoin(oilPicRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      var stay_source = "历史轨迹"
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
        stay_source = "司机上传"
      }
      leftObj.put("stay_source", stay_source)

      leftObj

    })
    val historyTrackRdd: RDD[JSONObject] = joinBasicOilRdd
      .filter(_.getString("stay_source") == "历史轨迹")
      .map(obj=>{
        val addfuel_tm: String = JSONUtil.getJsonValSingle(obj, "addfuel_tm")
        if (StringUtils.isNoneEmpty(addfuel_tm)){
          val beginDateTime: String = DateUtil.getMinuteStr(addfuel_tm, -10)
          val endDateTime: String = DateUtil.getMinuteStr(addfuel_tm, 10)
          obj.put("beginDateTime",beginDateTime)
          obj.put("endDateTime",endDateTime)
        }
        obj
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val httpTrackHoldPoint = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "停留点请求轨迹", "调历史轨迹接口寻找停留点", "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail", "ebf48ecaa1fd436fa3d40c4600aa051f", historyTrackRdd.count(), 50)
    val returnTrackHoldPointRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,historyTrackRdd, SfNetInteface.trackHoldPointInterface, 50, "ebf48ecaa1fd436fa3d40c4600aa051f", 2000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpTrackHoldPoint)
    val trackHoldPointRdd: RDD[JSONObject] = returnTrackHoldPointRdd.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "ret.result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(result, "data")
      val stayPoints: JSONArray = JSONUtil.getJsonArrayMulti(data, "stayPoints")
      val num: Int = stayPoints.size()
      val stayPointsArray = new util.ArrayList[JSONObject]()
      if (num != 0) {
        for (i <- 0 until (stayPoints.size())) {
          val tmpObj = new JSONObject()
          val stayPointsObj: JSONObject = stayPoints.getJSONObject(i)
          val startTime: String = stayPointsObj.getString("startTime")
          val endTime: String = stayPointsObj.getString("endTime")
          val duration: String = stayPointsObj.getString("duration")
          val startLon: String = stayPointsObj.getString("startLon")
          val startLat: String = stayPointsObj.getString("startLat")
          val startIndex: String = stayPointsObj.getString("startIndex")
          val stay_time = startTime + "_" + endTime
          val stay_duration = duration
          val stay_point = startLon + "," + startLat
          val roadName: String = stayPointsObj.getString("roadName")
          tmpObj.put("starttime", startTime)
          tmpObj.put("endtime", endTime)
          tmpObj.put("duration", duration)
          tmpObj.put("startlon", startLon)
          tmpObj.put("startlat", startLat)
          tmpObj.put("startindex", startIndex)
          tmpObj.put("stay_time", stay_time)
          tmpObj.put("stay_duration", stay_duration)
          tmpObj.put("stay_point", stay_point)
          tmpObj.put("stay_roadname", roadName)
          stayPointsArray.append(tmpObj)
        }
      }
      val starttime: String = stayPointsArray.map(_.getString("starttime")).mkString("|")
      val endtime: String = stayPointsArray.map(_.getString("endtime")).mkString("|")
      val duration: String = stayPointsArray.map(_.getString("duration")).mkString("|")
      val startlon: String = stayPointsArray.map(_.getString("startlon")).mkString("|")
      val startlat: String = stayPointsArray.map(_.getString("startlat")).mkString("|")
      val startindex: String = stayPointsArray.map(_.getString("startindex")).mkString("|")
      val stay_time: String = stayPointsArray.map(_.getString("stay_time")).mkString("|")
      val stay_duration: String = stayPointsArray.map(_.getString("stay_duration")).mkString("|")
      val stay_point: String = stayPointsArray.map(_.getString("stay_point")).mkString("|")
      val stay_roadname: String = stayPointsArray.map(_.getString("stay_roadname")).mkString("|")
      obj.put("num", num)
      obj.put("starttime", starttime)
      obj.put("endtime", endtime)
      obj.put("duration", duration)
      obj.put("startlon", startlon)
      obj.put("startlat", startlat)
      obj.put("startindex", startindex)
      obj.put("stay_time", stay_time)
      obj.put("stay_duration", stay_duration)
      obj.put("stay_point", stay_point)
      obj.put("stay_roadname", stay_roadname)
      obj.put("nornal_stay", "")
      obj.remove("ret")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val noHoldPointRdd: RDD[JSONObject] = trackHoldPointRdd
      .filter(_.getIntValue("num") == 0)
      .map(obj=>{
        val addfuel_tm: String = JSONUtil.getJsonValSingle(obj, "addfuel_tm")
        if (StringUtils.isNoneEmpty(addfuel_tm)){
          val beginDateTime: String = DateUtil.getMinuteStr(addfuel_tm, -1)
          val endDateTime: String = DateUtil.getMinuteStr(addfuel_tm, 1)
          obj.put("beginDateTime",beginDateTime)
          obj.put("endDateTime",endDateTime)
        }
        obj
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val httpTrackHoldPointNext = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "停留点请求轨迹", "调历史轨迹接口寻找停留点", "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail", "ebf48ecaa1fd436fa3d40c4600aa051f", noHoldPointRdd.count(), 50)
    val returnTrackHoldPointNextRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,noHoldPointRdd, SfNetInteface.trackHoldPointInterface, 50, "ebf48ecaa1fd436fa3d40c4600aa051f", 2000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpTrackHoldPointNext)
    val trackHoldPointNextRdd: RDD[JSONObject] = returnTrackHoldPointNextRdd.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "ret.result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(result, "data")
      val track: JSONArray = JSONUtil.getJsonArrayMulti(data, "track")
      val len_t: Int = track.size()
      var mid_t: Int = len_t / 2
      if (mid_t >= len_t) {
        mid_t = len_t - 1
      }
      if (track.size()!=0){
        val trackObj: JSONObject = track.getJSONObject(mid_t)
        val dx: String = trackObj.getString("dx")
        val dy: String = trackObj.getString("dy")
        val stay_point = dx + "," + dy
        obj.put("dx", dx)
        obj.put("dy", dy)
        obj.put("stay_point", stay_point)
      }
      obj.put("len_t", len_t)
      obj.put("mid_t", mid_t)
      obj.put("stay_time", "")
      obj.put("stay_duration", "")
      obj.put("stay_roadname", "")
      obj.put("nornal_stay", "异常")
      obj
    })
    val basicDataStep31Rdd: RDD[JSONObject] = joinBasicOilRdd.filter(_.getString("stay_source") == "司机上传")
      .union(trackHoldPointRdd.filter(_.getIntValue("num") != 0))
      .union(trackHoldPointNextRdd)
    val reqTimeGreatStartTmRdd: RDD[JSONObject] = basicDataStep31Rdd.filter(obj => {
      val req_time: String = obj.getString("req_time")
      val start_tm: String = obj.getString("start_tm")
      StringUtils.isNoneEmpty(req_time) && StringUtils.isNoneEmpty(start_tm) && req_time >= start_tm
    }).map(obj => {
      val req_time: String = obj.getString("req_time")
      val start_tm: String = obj.getString("start_tm")
      obj.put("beginDateTime", start_tm)
      obj.put("endDateTime", req_time)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val httpTrackHoldPoint32 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "停留点请求轨迹", "调历史轨迹接口寻找停留点", "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail", "ebf48ecaa1fd436fa3d40c4600aa051f", reqTimeGreatStartTmRdd.count(), 50)
    val returnTrackHoldPoint32Rdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,reqTimeGreatStartTmRdd, SfNetInteface.trackHoldPointInterface, 50, "ebf48ecaa1fd436fa3d40c4600aa051f", 2000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpTrackHoldPoint32)
    val trackHoldPoint32Rdd: RDD[JSONObject] = returnTrackHoldPoint32Rdd.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "ret.result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(result, "data")
      val track: JSONArray = JSONUtil.getJsonArrayMulti(data, "track")
      val tracks: Int = track.size()
      val reqTraveledCoordsArray = new util.ArrayList[String]()
      if (tracks != 0) {
        for (i <- 0 until (track.size())) {
          val trackObj: JSONObject = track.getJSONObject(i)
          val dx: String = trackObj.getString("dx")
          val dy: String = trackObj.getString("dy")
          val dxy: String = dx + "," + dy
          reqTraveledCoordsArray.append(dxy)
        }
      }
      val req_traveled_coords: String = reqTraveledCoordsArray.mkString("|")
      val len: Double = data.getDoubleValue("len") / 1000
      obj.put("req_traveled_coords", req_traveled_coords)
      obj.put("req_traveled_dist", len)
      obj
    })
    val basicDataStep32Rdd: RDD[JSONObject] = trackHoldPoint32Rdd.union(reqTimeGreatStartTmRdd.filter(obj => {
      val req_time: String = obj.getString("req_time")
      val start_tm: String = obj.getString("start_tm")
      !(StringUtils.isNoneEmpty(req_time) && StringUtils.isNoneEmpty(start_tm) && req_time >= start_tm)
    })).union(trackHoldPoint32Rdd).map(obj=>{
      val oil_point: String = obj.getString("oil_point")
      val req_traveled_coords: String = obj.getString("req_traveled_coords")
      val distanceArray = new util.ArrayList[Double]()
      var return_start = ""
      if (StringUtils.isNoneEmpty(oil_point) && StringUtils.isNoneEmpty(req_traveled_coords)){
        val coordsArray: Array[String] = req_traveled_coords.split("\\|")
        val oilPointArray: Array[String] = oil_point.split("\\|")
        for (elem1 <- oilPointArray) {
          val pointArray: Array[String] = elem1.split(",")
          for (elem <- coordsArray) {
            val coords: Array[String] = elem.split(",")
            val dx: Double = coords(0).toDouble
            val dy: Double = coords(1).toDouble
            val lng: Double = pointArray(0).toDouble
            val lat: Double = pointArray(1).toDouble
            val dist: Double = DistanceUtils.getDistance(dx, dy, lng, lat)
            distanceArray.append(dist)
          }
        }
        val minDist: Double = distanceArray.min
        if (minDist<100){
          return_start = "是"
        }else{
          return_start = "否"
        }
      }
      obj.put("return_start",return_start)
      obj
    })
    //3.3请求后里程数据
    val reqTimeLessAddfuelTmRdd: RDD[JSONObject] = basicDataStep32Rdd.filter(obj => {
      val req_time: String = obj.getString("req_time")
      val addfuel_tm: String = obj.getString("addfuel_tm")
      StringUtils.isNoneEmpty(req_time) && StringUtils.isNoneEmpty(addfuel_tm) && req_time <= addfuel_tm
    }).map(obj => {
      val req_time: String = obj.getString("req_time")
      val addfuel_tm: String = obj.getString("addfuel_tm")
      obj.put("beginDateTime", req_time)
      obj.put("endDateTime", addfuel_tm)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val httpTrackHoldPoint33 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "停留点请求轨迹", "调历史轨迹接口寻找停留点", "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail", "ebf48ecaa1fd436fa3d40c4600aa051f", reqTimeLessAddfuelTmRdd.count(), 50)
    val returnTrackHoldPoint33Rdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,reqTimeLessAddfuelTmRdd, SfNetInteface.trackHoldPointInterface, 50, "ebf48ecaa1fd436fa3d40c4600aa051f", 2000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpTrackHoldPoint33)
    val trackHoldPoint33Rdd: RDD[JSONObject] = returnTrackHoldPoint33Rdd.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "ret.result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(result, "data")
      val len: Double = data.getDoubleValue("len") / 1000
      obj.put("req_traveled_dist", len)
      obj
    })
    val sdkNaviParseRdd: RDD[(String, JSONObject)] = tuple3._3.map(obj=>{
      (obj.getString("task_id"),obj)
    })
    val basicDataStep3Df: DataFrame = basicDataStep32Rdd.filter(obj => {
      val req_time: String = obj.getString("req_time")
      val addfuel_tm: String = obj.getString("addfuel_tm")
      !(StringUtils.isNoneEmpty(req_time) && StringUtils.isNoneEmpty(addfuel_tm) && req_time <= addfuel_tm)
    }).map(obj => {
      val req_time: String = obj.getString("req_time")
      val addfuel_tm: String = obj.getString("addfuel_tm")
      var req_traveled_dist = ""
      if (StringUtils.isNoneEmpty(req_time) && StringUtils.isNoneEmpty(addfuel_tm) && req_time > addfuel_tm) {
        req_traveled_dist = "异常数据-加油后请求"
      }
      obj.put("req_traveled_dist", req_traveled_dist)
      obj
    }).union(trackHoldPoint33Rdd).map(obj=>{
      (obj.getString("task_id"),obj)
    }).leftOuterJoin(sdkNaviParseRdd).map(obj=>{
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj!=null){
        leftObj.put("click_info",rightObj.getString("content"))
      }
      leftObj
    }).map(obj => {
      CaseBasicDataStep3(
        obj.getString("task_id"),
        obj.getString("navi_id"),
        obj.getString("app_ver"),
        obj.getString("src_deptcode"),
        obj.getString("dest_deptcode"),
        obj.getString("driver_id"),
        obj.getString("vehicle"),
        obj.getString("if_req"),
        obj.getString("if_recom_oil"),
        obj.getString("req_time"),
        obj.getString("fuel_no"),
        obj.getString("poi_id"),
        obj.getString("oil_point"),
        obj.getString("oil_price"),
        obj.getString("oil_name"),
        obj.getString("oil_brand"),
        obj.getString("fuel_left_distance"),
        obj.getString("is_fuel_point"),
        obj.getString("plan_tracks"),
        obj.getString("request_id"),
        obj.getString("req_app_ver"),
        obj.getString("search_type"),
        obj.getString("type_poi_oil"),
        obj.getString("add_oil"),
        obj.getString("std_id_list"),
        obj.getString("std_line_recommend"),
        obj.getString("req_driver_id"),
        obj.getString("line_code"),
        obj.getString("fuel_scene"),
        obj.getString("recommened_refuel_size"),
        obj.getString("start_fuel_size"),
        obj.getString("start_fuel_size_arti"),
        obj.getString("task_classification"),
        obj.getString("station_tag"),
        obj.getString("station_type"),
        obj.getString("is_showed"),
        obj.getString("fuel_qty"),
        obj.getString("fuel_prices"),
        obj.getString("start_miles"),
        obj.getString("end_miles"),
        obj.getString("miles"),
        obj.getString("addfuel_miles"),
        obj.getString("is_add_oil"),
        obj.getString("data_source"),
        obj.getString("total_amount"),
        obj.getString("addfuel_tm"),
        obj.getString("start_tm"),
        obj.getString("end_tm"),
        obj.getString("drive_members"),
        obj.getString("start_place"),
        obj.getString("end_place"),
        obj.getString("task_type"),
        obj.getString("addoil_behavior"),
        obj.getString("actual_if_better"),
        obj.getString("stay_source"),
        obj.getString("stay_time"),
        obj.getString("stay_duration"),
        obj.getString("stay_point"),
        obj.getString("stay_roadname"),
        obj.getString("nornal_stay"),
        obj.getString("osstempurl"),
        obj.getString("req_traveled_dist"),
        obj.getString("req_traveled_coords"),
        obj.getString("return_start"),
        obj.getString("click_info")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,basicDataStep3Df,"inc_day",incDay,"dm_gis.dm_eta_basic_data_step3_di")

  }

  def execute(incDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取表 basic_data
    val tuple3: (RDD[JSONObject], RDD[JSONObject], RDD[JSONObject]) = readSourceData(spark, incDay)
    //关联两张表并调接口
    joinTuple2Interface(spark,tuple3,incDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    execute(incDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseBasicDataStep3(
                                  task_id:String,
                                  navi_id:String,
                                  app_ver:String,
                                  src_deptcode:String,
                                  dest_deptcode:String,
                                  driver_id:String,
                                  vehicle:String,
                                  if_req:String,
                                  if_recom_oil:String,
                                  req_time:String,
                                  fuel_no:String,
                                  poi_id:String,
                                  oil_point:String,
                                  oil_price:String,
                                  oil_name:String,
                                  oil_brand:String,
                                  fuel_left_distance:String,
                                  is_fuel_point:String,
                                  plan_tracks:String,
                                  request_id:String,
                                  req_app_ver:String,
                                  search_type:String,
                                  type_poi_oil:String,
                                  add_oil:String,
                                  std_id_list:String,
                                  std_line_recommend:String,
                                  req_driver_id:String,
                                  line_code:String,
                                  fuel_scene:String,
                                  recommened_refuel_size:String,
                                  start_fuel_size:String,
                                  start_fuel_size_arti:String,
                                  task_classification:String,
                                  station_tag:String,
                                  station_type:String,
                                  is_showed:String,
                                  fuel_qty:String,
                                  fuel_prices:String,
                                  start_miles:String,
                                  end_miles:String,
                                  miles:String,
                                  addfuel_miles:String,
                                  is_add_oil:String,
                                  data_source:String,
                                  total_amount:String,
                                  addfuel_tm:String,
                                  start_tm:String,
                                  end_tm:String,
                                  drive_members:String,
                                  start_place:String,
                                  end_place:String,
                                  task_type:String,
                                  addoil_behavior:String,
                                  actual_if_better:String,
                                  stay_source:String,
                                  stay_time:String,
                                  stay_duration:String,
                                  stay_point:String,
                                  stay_roadname:String,
                                  nornal_stay:String,
                                  osstempurl:String,
                                  req_traveled_dist:String,
                                  req_traveled_coords:String,
                                  return_start:String,
                                  click_info:String
                               )

}
