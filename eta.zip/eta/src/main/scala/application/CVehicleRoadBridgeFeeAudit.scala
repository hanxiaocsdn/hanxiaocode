package application

import java.util

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DistanceUtils}
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._

/**
 * @Description:C端专车路桥费审计
 * 需求人员：ft80006323 杨汶铭
 * @Author: lixiangzhi 01405644
 * @Date:20240116
 * 任务id:
 * 任务名称：C端专车路桥费审计
 * 依赖任务：
 * 数据源：
 * 调用服务地址：
 * 数据结果：
 */
object CVehicleRoadBridgeFeeAudit {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readSourceData(spark: SparkSession, startDay: String,endDay:String) = {
    import spark.implicits._
    val roadbridgeFeesSql=
      s"""
         |select task_id,task_start_time,task_end_time,highway,rate,ctfo_task_fee,discountfee
         |from dm_gis.dm_supplier_roadbridge_fees_dtl
         |where inc_day>='$startDay' and inc_day<='$endDay'
         |""".stripMargin
    val roadbridgeFeesRdd: RDD[(String, JSONObject)] = SparkUtils.getRowToJsonClear(spark, roadbridgeFeesSql,2000).map(obj => {
      (obj.getString("task_id"), obj)
    })

    val specialVehicleSql=
      s"""
         |select *
         |from dm_gis.tmp_special_vehicle_task_df
         |--where plan_depart like '2023-10-01%'
         |""".stripMargin
    val joinRdd: RDD[JSONObject] = SparkUtils.getRowToJsonClear(spark, specialVehicleSql,2000).map(obj => {
      (obj.getString("task_id"), obj)
    }).leftOuterJoin(roadbridgeFeesRdd).map(obj => {
      val leftObj: JSONObject = obj._2._1
      val rightObj: JSONObject = obj._2._2.orNull
      if (rightObj != null) {
        leftObj.fluentPutAll(rightObj)
      }
      leftObj
    })
    val nullTaskFeeRdd: RDD[JSONObject] = joinRdd.filter(obj => {
      StringUtils.isEmpty(obj.getString("ctfo_task_fee"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ctfo_task_fee为空的数据量:"+nullTaskFeeRdd.count())
    val httpTrackRoadBridgeFees = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01405644", "421", "车牌号请求轨迹", "调轨迹接口获取路桥费", "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail", "93ec117f7f1b4226b4e537c4802319e9", nullTaskFeeRdd.count(), 50)
    val returnTrackRoadBridgeFeesRdd: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,nullTaskFeeRdd, SfNetInteface.trackRoadBridgeFeesInterface, 50, "93ec117f7f1b4226b4e537c4802319e9", 3000)
    BdpTaskRecordUtil.endNetworkInterface("01405644", httpTrackRoadBridgeFees)
    returnTrackRoadBridgeFeesRdd.take(10).foreach(println(_))
    val trackRoadBridgeFeesDf: DataFrame = returnTrackRoadBridgeFeesRdd.union(joinRdd.filter(obj => {
      StringUtils.isNoneEmpty(obj.getString("ctfo_task_fee"))
    })).map(obj => {
      CaseCVehicleRoadBridgeFeeAudit(
        obj.getString("task_id"),
        obj.getString("original_amount"),
        obj.getString("appeal_amount"),
        obj.getString("carrier_plate"),
        obj.getString("axles"),
        obj.getString("vehicle_len"),
        obj.getString("plan_depart"),
        obj.getString("task_start_time"),
        obj.getString("task_end_time"),
        obj.getString("highway"),
        obj.getString("rate"),
        obj.getString("ctfo_task_fee"),
        obj.getString("discountfee"),
        obj.getString("etctollCharge"),
        obj.getString("tollCharge")
      )
    }).toDF()
    SparkWrite.writeToHive(spark,trackRoadBridgeFeesDf,"inc_day",endDay,"dm_gis.dm_eta_cvehicle_road_bridge_fee_audit_di",10)
  }


  def execute(startDay: String,endDay: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    //读取表 basic_data
    readSourceData(spark, startDay,endDay)
    spark.stop()

  }

  def main(args: Array[String]): Unit = {
    val startDay: String = args(0)
    val endDay: String = args(1)
    execute(startDay,endDay)
    logger.error("======>>>>>>Execute Ok")
  }

  case class CaseCVehicleRoadBridgeFeeAudit(
                                            task_id:String,
                                            original_amount:String,
                                            appeal_amount:String,
                                            carrier_plate:String,
                                            axles:String,
                                            vehicle_len:String,
                                            plan_depart:String,
                                            task_start_time:String,
                                            task_end_time:String,
                                            highway:String,
                                            rate:String,
                                            ctfo_task_fee:String,
                                            discountfee:String,
                                            etctollCharge:String,
                                            tollCharge:String
                                           )

}
