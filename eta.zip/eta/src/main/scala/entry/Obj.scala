package entry

/**
  * Created by 01375125 on 2018/10/31.
  */
object Obj {

  case class DebangObj(
                        region: String,
                        city: String,
                        cityCode: String,
                        adcode: String,
                        reqCnt: Int,
                        aoiCnt: Int,
                        zcCnt: Int,
                        tcCnt: Int,
                        aoiRdsCnt: Int,
                        zcRdsCnt: Int,
                        tcRdsCnt: Int,
                        aoiChknCnt: Int,
                        zcChknCnt: Int,
                        tcChknCnt: Int
                      )
  case class KyObj(
                        region: String,
                        city: String,
                        cityCode: String,
                        reqCnt: Int,
                        tcCnt: Int
                      )

    // TODO
  case class AreaRcgObj(
                         region: String,
                         city: String,
                         cityCode: String,
                         zoneCode: String,
                         addresseeAoiArea: String,
                         reqCnt: Int,
                         zcCnt: Int,
                         aoiCnt: Int,
                         addressAoiCnt: Int,
                         arssReqCnt: Int,
                         arssReSucCnt: Int,
                         awsmReqCnt: Int,
                         awsmReSucCnt: Int
                       )

  case class AreaEmptyAoiInfoObj(
                                  area: String,
                                  region: String,
                                  city: String,
                                  cityCode: String,
                                  zoneCode: String,
                                  waybillNo: String,
                                  finalZc: String,
                                  barscantm: String,
                                  req_addresseeaddr: String,
                                  couriercode:String,
                                  finalZcSrc: String,
                                  gisAutoZc: String,
                                  gisGid: String,
                                  reBodyGisTime: String,
                                  reBodyArssZc: String,
                                  arssReOp: String,
                                  arssReOpTime: String,
                                  gis_to_sys_src:String,
                                  idList:String
                                //缺失数据添加电话号码和公司名字段
                                  ,req_addresseephone:String,req_addresseemobile:String,req_comp_name:String
                                )
  case class AreaWdAoiInfoObj(
                                  area: String,
                                  region: String,
                                  city: String,
                                  cityCode: String,
                                  zoneCode: String,
                                  waybillNo: String,
                                  barscantm: String,
                                  req_addresseeaddr: String,
                                  distribute_code:String,
                                  delivered_code:String,
                                  finalaoicode:String,
                                  finalaoiSrc: String,
                                  gisAutoAoi: String,
                                  gisGid: String,
                                  reBodyGisTime: String,
                                  reBodyArssAoi: String,
                                  arssReOp: String,
                                  arssReOpTime: String,
                                  awsmAoi: String,
                                  awsmReOp: String,
                                  awsmReOpTime: String,
                                  finalAoiName:String,
                                  req_comp_name:String,
                                  keywords:String,
                                  idList:String,
                                  distributeName:String,
                                  deliveredName:String,
                                  reqAddressEePhone: String,
                                  reqAddressEeMobile: String
                                )

    // TODO
  case class AreaWdRcgObj(
                           region: String,
                           city: String,
                           cityCode: String,
                           zoneCode: String,
                           addresseeAoiArea: String,
                           aoiExePre: Int,
                           aoiWdPre: Int,
                           exeRejectDeptDiff: Int,
                           aoiWdDeptDiff: Int,
                           aoiWdDistibuteError: Int,
                           aoiWdAoiIdDateIn: Int,
                           aoiWdDeliveredCodeDateIn: Int,
                           aoiAft: Int,
                           aoiAftRight: Int,
                           aoiAftWrong: Int,
                           aoiAftAddress: Int,
                           aoiAftAddressRight: Int,
                           aoiAftAddressWrong: Int,
                           aoiAftArss: Int,
                           aoiAftArssRight: Int,
                           aoiAftArssWrong: Int,
                           aoiAftAwsm: Int,
                           aoiAftAwsmRight: Int,
                           aoiAftAwsmWrong: Int
                         )

  case class AreaWdRcgShouObj(
                               region: String,
                               city: String,
                               cityCode: String,
                               zoneCode: String,
                               aoiExePre: Int,
                               aoiWdPre: Int,
                               exeRejectDeptDiff: Int,
                               aoiWdDeptDiff: Int,
                               aoiWdDistibuteError: Int,
                               aoiWdAoiIdDateIn: Int,
                               aoiWdDeliveredCodeDateIn: Int,
                               aoiAft: Int,
                               aoiAftRight: Int,
                               aoiAftWrong: Int,
                               aoiAftAddress: Int,
                               aoiAftAddressRight: Int,
                               aoiAftAddressWrong: Int,
                               aoiAftArss: Int,
                               aoiAftArssRight: Int,
                               aoiAftArssWrong: Int
                             )

  case class AreaRcgShouObj(region: String,
                            city: String,
                            cityCode: String,
                            zoneCode: String,
                            req: Int,
                            aoiCnt: Int,
                            addressAoiCnt: Int,
                            arssAoiCnt: Int
                           )

}


