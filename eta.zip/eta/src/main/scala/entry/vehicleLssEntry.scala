package entry

object vehicleLssEntry {
  case  class  VahicleLss(
                           id : String, //任务Atask_id+"_"+任务Btask_id',
                           start_dept : String,//当前网点',
                           start_dept_site_id : String, // 始发网点网外id
                           end_dept : String,//下一网点',
                           end_dept_site_id : String, // 始发网点网外id
                           a_task_id : String,//任务AID',
                           a_plan_depart_tm : String,//任务A计划发车时间',
                           a_actual_depart_tm : String,//任务A实际发车时间',
                           a_plan_arrive_tm : String,//任务A计划到车时间',
                           a_actual_arrive_tm : String,//任务A实际到车时间',
                           a_vehicle_serial : String,//任务A车牌号',
                           a_driver_id : String,//任务A司机ID',
                           a_driver_name : String,//任务A司机姓名',
                           a_line_distance : String,//任务A规划里程(KM)',
                           a_biz_type : String,//任务A业务类型：0速运，1同城（DDS），2丰驰 3重货 4中港/中澳车 5冷运 6台湾 7香港 8澳门 10区域物流（系统来源：FPD） 9 医药（网点为M开头的） 11、速运区域物流 12、同城区域物流 13、社会订单 14、融通-快运 15、融通-顺心 16、快运 91、收派 92、接驳93、空驶调度 94、空驶任务 95、虚拟任务
                           a_carrier_name : String,//任务A承运商名称(片区)',
                           a_carrier_type : String,//任务A承运商类型(0自营
                           a_is_stop : String,//任务A是否经停(1直发
                           a_lw : String,//任务A当前网点发车重量',
                           a_full_load_weight : String,//任务A满载重量',
                           a_load_ratio : String,//任务A装载率',
                           a_dp : String,//任务A当前网点发车票数',
                           a_contnr_code : String,//任务A车标号',
                           a_len : String,//任务A实际里程(KM)',
                           a_track : String,//任务A轨迹串',
                           a_similarity : String,//任务A相对于B轨迹的相似度',
                           b_task_id : String,//任务BID',
                           b_plan_depart_tm : String,//任务B计划发车时间',
                           b_actual_depart_tm : String,//任务B实际发车时间',
                           b_plan_arrive_tm : String,//任务B计划到车时间',
                           b_actual_arrive_tm : String,//任务B实际到车时间',
                           b_vehicle_serial : String,//任务B车牌号',
                           b_driver_id : String,//任务B司机ID',
                           b_driver_name : String,//任务B司机姓名',
                           b_line_distance : String,//任务B规划里程(KM)',
                           b_biz_type : String,//任务B业务类型：0速运，1同城（DDS），2丰驰 3重货 4中港/中澳车 5冷运 6台湾 7香港 8澳门 10区域物流（系统来源：FPD） 9 医药（网点为M开头的） 11、速运区域物流 12、同城区域物流 13、社会订单 14、融通-快运 15、融通-顺心 16、快运 91、收派 92、接驳93、空驶调度 94、空驶任务 95、虚拟任务
                           b_carrier_name : String,//任务B承运商名称(片区)',
                           b_carrier_type : String,//任务B承运商类型(0自营
                           b_is_stop : String,//任务B是否经停(1直发
                           b_votes_dw : String,//任务B当前网点发车重量',
                           b_full_load_weight : String,//任务B满载重量',
                           b_load_ratio : String,//任务B装载率',
                           b_dp : String,//任务B当前网点发车票数',
                           b_contnr_code : String,//任务B车标号',
                           b_len : String,//任务B实际里程(KM)',
                           b_track : String,//任务B轨迹串',
                           b_similarity : String,//任务B相对于A轨迹的相似度',
                           http_result_status : String,//请求返回状态
                           http_result_msg : String, //请求返回备注信息',
                           etl_time:String,
                           inc_day:String
                         )

}