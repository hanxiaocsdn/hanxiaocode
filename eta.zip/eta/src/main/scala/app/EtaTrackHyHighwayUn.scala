package app

import Utils.CommonTools.row2Json
import Utils.SparkUtils.writeToHive
import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer

/**
 * GIS-RSS-ETA：【时长决策】行业时速车牌需求_V1.0
 * 需求方：薛飞扬（01434058）
 * @author 徐游飞（01417347）
 * 任务ID：942242
 * 任务名称：行业时速对应车牌需求
 */
object EtaTrackHyHighwayUn {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def eta_track_hy_highway_un(spark: SparkSession, inc_day: String) = {

    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore4 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 4)
    val dayBefore6 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 6)
    val dayBefore35 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 35)
    val dayBefore37 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 37)

    import spark.implicits._
    // 获取时速标准全国流向数据，剔除顺丰车辆
    val sql_328_city =
      s"""
         |with t1 as(
         |  select
         |    substr(un, 1, length(un) -2) as un_final,
         |    substr(un, 1, length(un) -2) as vehicle_serial,
         |    direction,
         |    speed_highspeed_tl_2,
         |    highspeed_start_time,
         |    highspeed_end_time,
         |    point_start,
         |    point_end,
         |    highspeed_dist_ratio
         |  from
         |    dm_gis.eta_track_highway_detail_3d_with_328_city
         |  where
         |    regexp_replace(time_highspeed_start_rep, '-', '') >= '$dayBefore35'
         |    and regexp_replace(time_highspeed_start_rep, '-', '') <= '$dayBefore6'
         |    and inc_day >= '$dayBefore37'
         |    and inc_day <= '$dayBefore4'
         |),
         |t2 as (
         |  select
         |    vehicle_serial,
         |    '1' as join_flag
         |  from
         |    dm_gis.eta_task_track_sf_all
         |  where
         |    inc_day >= '$dayBefore35'
         |    and inc_day <= '$dayBefore6'
         |)
         |select
         |  t1.un_final,
         |  t1.direction,
         |  t1.speed_highspeed_tl_2,
         |  t1.highspeed_start_time,
         |  t1.highspeed_end_time,
         |  t1.point_start,
         |  t1.point_end,
         |  t1.highspeed_dist_ratio
         |from
         |  t1 left join t2 on t1.vehicle_serial = t2.vehicle_serial
         |where
         |  join_flag is null
         |""".stripMargin
    println(sql_328_city)
    val df_328_city = spark.sql(sql_328_city)

    // 获取流向时速标准数据
    val sql_direction =
      s"""
         |select
         |  *
         |from(
         |    select
         |      direction,
         |      start_city,
         |      end_city,
         |      hy_highway_5,
         |      hy_highway_10,
         |      hy_highway_15,
         |      hy_highway_20,
         |      hy_highway_25,
         |      hy_highway_30,
         |      hy_highway_35,
         |      hy_highway_40,
         |      hy_highway_45,
         |      hy_highway_50,
         |      hy_highway_55,
         |      hy_highway_60,
         |      hy_highway_65,
         |      hy_highway_70,
         |      hy_highway_75,
         |      hy_highway_80,
         |      hy_highway_85,
         |      hy_highway_90,
         |      hy_highway_95,
         |      row_number() over (partition by direction order by inc_day) as rn
         |    from
         |      dm_gis.eta_line_speed_ac_mix_delay_mining_dtl
         |    where
         |      inc_day = '$dayBefore1'
         |  ) t1
         |where
         |  t1.rn = 1
         |""".stripMargin
    println(sql_direction)
    val df_direction = spark.sql(sql_direction)

    // 匹配经纬度  格式为： 117.442590,26.090996
    val regex = """^(\s*)[-+]?(180(\.0+)?|((1[0-7]\d)|(0?\d?\d))(\.\d+)?),[-+]?([1-8]?\d(\.\d+)?|90(\.0+)?)(\s*)$"""
    val df_ret = df_direction.join(df_328_city,Seq("direction"),"inner")
//      .filter('direction === "广州市-深圳市")
      .rdd.map(row2Json)
      .flatMap(obj=>{ // 按时速级别拆分
        val json_arr = new ArrayBuffer[JSONObject]()
        for (i <- Range.inclusive(5, 95, 5)) {
          val obj_hy_highway = new JSONObject()
          val level = s"top$i"
          var topn_highwayspeed_1 = 0.0
          var topn_highwayspeed_2 = 0.0
          if(i == 5){
            topn_highwayspeed_1 = 300
            topn_highwayspeed_2 = JSONUtil.getJsonDouble(obj, s"hy_highway_$i", 0.0)
          }else{
            val j = i-5
            topn_highwayspeed_1 = JSONUtil.getJsonDouble(obj, s"hy_highway_$j", 0.0)
            topn_highwayspeed_2 = JSONUtil.getJsonDouble(obj, s"hy_highway_$i", 0.0)
          }

          obj_hy_highway.put("data",obj)
          obj_hy_highway.put("level",level)
          obj_hy_highway.put("topn_highwayspeed_1",topn_highwayspeed_1)
          obj_hy_highway.put("topn_highwayspeed_2",topn_highwayspeed_2)

          json_arr.append(obj_hy_highway)
        }

        json_arr.iterator
      }).map(obj=>{
      val level = JSONUtil.getJsonVal(obj, "level", "")
      val topn_highwayspeed_1 = JSONUtil.getJsonDouble(obj, "topn_highwayspeed_1", 0.0)
      val topn_highwayspeed_2 = JSONUtil.getJsonDouble(obj, "topn_highwayspeed_2", 0.0)

      val data = JSONUtil.getJsonObjectMulti(obj, "data")
      val topn_un = JSONUtil.getJsonVal(data, "un_final", "")
      val direction = JSONUtil.getJsonVal(data, "direction", "")
      val start_city = JSONUtil.getJsonVal(data, "start_city", "")
      val end_city = JSONUtil.getJsonVal(data, "end_city", "")
      val speed_highspeed_tl_2 = JSONUtil.getJsonDouble(data, "speed_highspeed_tl_2", 0.0)
      val topn_un_start_time = JSONUtil.getJsonVal(data, "highspeed_start_time", "")
      val topn_un_end_time = JSONUtil.getJsonVal(data, "highspeed_end_time", "")
      val topn_start_coords = JSONUtil.getJsonVal(data, "point_start", "")
      val topn_end_coords = JSONUtil.getJsonVal(data, "point_end", "")
      val highspeed_dist_ratio = JSONUtil.getJsonDouble(data, "highspeed_dist_ratio", 0.0)

      val topn_highwayspeed = topn_highwayspeed_2
      var filter_tag = false
      if(speed_highspeed_tl_2 >= topn_highwayspeed_2 && speed_highspeed_tl_2 < topn_highwayspeed_1) filter_tag = true

      (direction,start_city,end_city,level,topn_un,topn_highwayspeed,topn_un_start_time,topn_un_end_time,topn_start_coords,topn_end_coords,highspeed_dist_ratio,filter_tag)
    }).toDF("direction","start_city","end_city","level","topn_un","topn_highwayspeed","topn_un_start_time","topn_un_end_time","topn_start_coords","topn_end_coords","highspeed_dist_ratio","filter_tag")
      .filter('filter_tag and 'topn_start_coords.rlike(regex) and 'topn_end_coords.rlike(regex))
      .withColumn("test",concat_ws("_",'filter_tag,'topn_start_coords.rlike(regex),'topn_end_coords.rlike(regex)))
      .withColumn("topn_start_lng",split('topn_start_coords,",")(0))
      .withColumn("topn_start_lat",split('topn_start_coords,",")(1))
      .withColumn("topn_end_lng",split('topn_end_coords,",")(0))
      .withColumn("topn_end_lat",split('topn_end_coords,",")(1))
      .withColumn("rn",row_number().over(Window.partitionBy("direction","level").orderBy(desc("highspeed_dist_ratio"),desc("topn_un_start_time"))))
      .filter('rn === 1)
      .withColumn("inc_day",lit(dayBefore1))

    // 结果表保存至hive
    val cols_1 = spark.sql("""select * from dm_gis.eta_track_hy_highway_un limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols_1: _*).coalesce(5),Seq("inc_day"),"dm_gis.eta_track_hy_highway_un")

  }

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"++++ 开始统计行业高速数据  inc_day=$inc_day  ++++")
    eta_track_hy_highway_un(spark,inc_day)
    logger.error("++++++++  任务完成 20240118  ++++")

    spark.stop()
  }

}
