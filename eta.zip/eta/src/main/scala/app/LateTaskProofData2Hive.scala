package app

import Utils.SparkUtils.writeToHive
import app.EtaCarrierLogData2Hive.timeToCustomTime2
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 * 时效晚点记录存入BDP表V2.0
 * 需求内容：将mysql的时效晚点记录数据导入hive
 * 需求方：李非龙（ft220114）
 * @author 徐游飞（01417347）
 * 任务ID：777557
 * 任务名称：时效晚点记录数据月度统计
 */
object LateTaskProofData2Hive {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def lateTaskProofMonth(spark: SparkSession, df_recall1: DataFrame, dayBefore1: String, dayBefore40: String, before_month: String, firstDayOfLastMonth:String) = {
    import spark.implicits._
    val last_record_sql =
      s"""
         |select
         |  task_id,
         |  create_time,
         |  update_time,
         |  exception_type
         |from
         |  dm_gis.task_exception_record
         |where
         |  inc_day >= '$dayBefore40'
         |  and inc_day <= '$dayBefore1'
         |  and	exception_type in ('1','2')
         |  and	del_flag = '0'
         |""".stripMargin
    println(last_record_sql)
    val df_last_record = spark.sql(last_record_sql)
      .withColumn("rn", row_number().over(Window.partitionBy("task_id","exception_type").orderBy(desc("update_time"))))
      .filter('rn === 1)  // 按 task_id 去重
      .select("task_id","create_time","exception_type")

    val late_proof_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.late_task_proof
         |""".stripMargin
    println(late_proof_sql)
    val df_late_proof = spark.sql(late_proof_sql)

    val df_late = df_last_record
      .join(df_recall1,Seq("task_id"),"left")
      .join(df_late_proof,Seq("task_id","exception_type"),"left")
      .withColumn("create_time_yyyyMM",timeToCustomTime2('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMM")))
      .withColumn("audit_time_yyyyMMdd",timeToCustomTime2('audit_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      //.filter('audit_result === "1" and 'create_time_yyyyMM === before_month and 'audit_time_yyyyMMdd >= firstDayOfLastMonth and 'audit_time_yyyyMMdd <= dayBefore1)
      .filter('audit_result === "1" and 'create_time_yyyyMM === before_month)
      .withColumn("rn", row_number().over(Window.partitionBy("task_id","exception_type").orderBy(desc("actual_arrive_tm"))))
      .filter('rn === 1)  // 按 task_id 去重
      .drop("rn")
      .withColumn("create_by",'main_driver_account)
      .withColumn("month",lit(before_month))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("late_task_proof_month 数据量 = "+df_late.count())

    val cols_1 = spark.sql("""select * from dm_gis.late_task_proof_month limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_late.select(cols_1: _*),Seq("month"),"dm_gis.late_task_proof_month")

    df_late.unpersist()
  }

  def lateTaskProofDisapproveMonth(spark: SparkSession, df_recall1: DataFrame, dayBefore1: String, dayBefore40: String, before_month: String, firstDayOfLastMonth:String) = {
    import spark.implicits._
    val last_record_sql =
      s"""
         |select
         |  task_id,
         |  create_time,
         |  update_time,
         |  late_time,
         |  exception_type
         |from
         |  dm_gis.task_exception_record
         |where
         |  inc_day >= '$dayBefore40'
         |  and inc_day <= '$dayBefore1'
         |  and	exception_type in ('1','2')
         |  and	del_flag = '0'
         |""".stripMargin
    println(last_record_sql)
    val df_last_record = spark.sql(last_record_sql)
      .withColumn("rn", row_number().over(Window.partitionBy("task_id","exception_type").orderBy(desc("update_time"))))
      .filter('rn === 1)  // 按 task_id 去重
      .select("task_id","create_time","late_time","exception_type")

    val late_proof_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.late_task_proof
         |""".stripMargin
    println(late_proof_sql)
    val df_late_proof = spark.sql(late_proof_sql)

    val df_late_dis = df_last_record
      .join(df_recall1,Seq("task_id"),"left")
      .join(df_late_proof,Seq("task_id","exception_type"),"left")
      .withColumn("create_time_yyyyMM",timeToCustomTime2('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMM")))
      .withColumn("audit_time_yyyyMMdd",timeToCustomTime2('audit_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("audit_result_type",concat_ws("|",collect_list('audit_result).over(Window.partitionBy("task_id","exception_type"))))
      .filter(!'audit_result_type.contains("1") and 'create_time_yyyyMM === before_month)
      .withColumn("rn", row_number().over(Window.partitionBy("task_id","exception_type").orderBy(desc("actual_arrive_tm"))))
      .filter('rn === 1)  // 按 task_id 去重
      .drop("rn")
      .withColumn("create_by",'main_driver_account)
      .withColumn("month",lit(before_month))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("late_task_proof_disapprove_month 数据量 = "+df_late_dis.count())

    val cols_3 = spark.sql("""select * from dm_gis.late_task_proof_disapprove_month limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_late_dis.select(cols_3: _*),Seq("month"),"dm_gis.late_task_proof_disapprove_month")

    df_late_dis.unpersist()
  }

  def contnrExceptionProofMonth(spark: SparkSession, df_recall1: DataFrame, dayBefore1: String, dayBefore40: String, before_month: String, firstDayOfLastMonth: String) = {
    import spark.implicits._
    val contnr_record_sql =
      s"""
         |select
         |  task_id,
         |  create_time,
         |  update_time
         |from
         |  dm_gis.task_exception_record
         |where
         |  inc_day >= '$dayBefore40'
         |  and inc_day <= '$dayBefore1'
         |  and	exception_type = '3'
         |  and	del_flag = '0'
         |""".stripMargin
    println(contnr_record_sql)
    val df_contnr_record = spark.sql(contnr_record_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("update_time"))))
      .filter('rn === 1)  // 按 task_id 去重
      .select("task_id","create_time")

    val contnr_proof_sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.contnr_exception_proof
         |""".stripMargin
    println(contnr_proof_sql)
    val df_contnr_proof = spark.sql(contnr_proof_sql)

    val df_contnr = df_contnr_record
      .join(df_recall1,Seq("task_id"),"left")
      .join(df_contnr_proof,Seq("task_id"),"left")
      .withColumn("create_time_yyyyMM",timeToCustomTime2('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMM")))
      .withColumn("audit_time_yyyyMMdd",timeToCustomTime2('audit_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("audit_result_type",concat_ws("|",collect_list('audit_result).over(Window.partitionBy("task_id"))))
      .filter(!'audit_result_type.contains("1") and 'create_time_yyyyMM === before_month)
      .withColumn("rn", row_number().over(Window.partitionBy("task_id").orderBy(desc("actual_arrive_tm"))))
      .filter('rn === 1)  //按 task_id 去重
      .drop("rn")
      .withColumn("create_by",'main_driver_account)
      .withColumn("month",lit(before_month))
      .persist(StorageLevel.MEMORY_AND_DISK)

    println("contnr_exception_proof_month 数据量 = "+df_contnr.count())

    val cols_2 = spark.sql("""select * from dm_gis.contnr_exception_proof_month limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_contnr.select(cols_2: _*),Seq("month"),"dm_gis.contnr_exception_proof_month")

    df_contnr.unpersist()
  }

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val dayBefore40 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 40)
    val firstDayOfLastMonth = DateUtil.getFirstDayOfMonth(DateUtil.getMouthBefore(incDay, 1))
    val before_month = firstDayOfLastMonth.substring(0,6)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
    logger.error("+++++++++    任务开始  20231205 !!!    ++++++++")
    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")

    import spark.implicits._
    val recall1_sql =
      s"""
         |select
         |  task_id,
         |  actual_arrive_tm,
         |  main_driver_account,
         |  last_update_tm
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day >= '$dayBefore40'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println(recall1_sql)
    val df_recall1 = spark.sql(recall1_sql)
      .withColumn("actual_arrive_yyyyMM",timeToCustomTime2('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMM")))
      .filter('actual_arrive_yyyyMM === before_month)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("last_update_tm"))))
      .filter('rn === 1)  // 按 task_id 去重
      .select("task_id","actual_arrive_tm","main_driver_account")
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 时效晚点举证月度表
    lateTaskProofMonth(spark,df_recall1,dayBefore1,dayBefore40,before_month,firstDayOfLastMonth)

    // 时效晚点举证(不通过)月度表
    lateTaskProofDisapproveMonth(spark,df_recall1,dayBefore1,dayBefore40,before_month,firstDayOfLastMonth)

    // 车标异常举证月度表
    contnrExceptionProofMonth(spark,df_recall1,dayBefore1,dayBefore40,before_month,firstDayOfLastMonth)

    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
    logger.error("+++++++++    任务结束  20231205 !!!    ++++++++")
    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")

    df_recall1.unpersist()
    spark.stop()
  }


}
