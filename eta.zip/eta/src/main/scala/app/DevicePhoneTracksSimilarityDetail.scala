package app

import Utils.CommonTools.row2Json
import Utils.SparkUtils.writeToHive
import Utils.StringUtils.{nonEmpty, timeToCustomTime}
import app.ZhuJiChangTrack.parseTrackQueryHttpData
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.sf.gis.java.base.pathSimilar
import java.lang

/**
 * GIS-RSS-ETA：【时效专项】轨迹相似度与缺失情况需求说明书_V1.0
 * 需求方：廖静文（01430321）
 * @author 徐游飞（01417347）
 * 任务ID：764432 （已下线）
 * 任务名称：轨迹相似度与缺失情况分析比对
 */
object DevicePhoneTracksSimilarityDetail {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  //val HOST_URL: String = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"
  val HOST_URL: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail" // 新轨迹中台迁移 20230821

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val dayBefore8 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 8)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始  ++++")
    execute(spark,dayBefore2,dayBefore8)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

  /**
   * 调用任务轨迹接口和融合轨迹接口
   * @param spark
   * @param dataDF
   */
  def runTrackQueryByTaskIdInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
    val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")

    // 将时间戳转换成接口需要的格式
    val beginDateTime = timeToCustomTime(actual_depart_tm,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")
    val endDateTime = timeToCustomTime(actual_arrive_tm,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")

    // 任务轨迹接口请求参数(设备轨迹 type=324)
    val param_1 = new JSONObject()
    param_1.put("ak", ak)
    param_1.put("type", "324")
    param_1.put("un", vehicle_serial)
    param_1.put("unType", "0")
    param_1.put("hasRate", true)
    param_1.put("offTime", "120")
    param_1.put("beginDateTime", beginDateTime)
    param_1.put("endDateTime", endDateTime)

    // 任务轨迹接口请求参数(手机轨迹 type=1011)
    val param_2 = new JSONObject()
    param_2.put("ak", ak)
    param_2.put("type", "1011")
    param_2.put("un", vehicle_serial)
    param_2.put("unType", "0")
    param_2.put("hasRate", true)
    param_2.put("offTime", "120")
    param_2.put("beginDateTime", beginDateTime)
    param_2.put("endDateTime", endDateTime)

    var retJSONObject_1 = new JSONObject()
    var retJSONObject_2 = new JSONObject()
    try {
      // 调任务轨迹接口获取设备轨迹完整率
      val retStr_1: String = HttpInvokeUtil.sendPost(HOST_URL,param_1.toJSONString)
      retJSONObject_1 = JSON.parseObject(retStr_1)

      // 调任务轨迹接口获取手机轨迹完整率
      val retStr_2: String = HttpInvokeUtil.sendPost(HOST_URL,param_2.toJSONString)
      retJSONObject_2 = JSON.parseObject(retStr_2)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析任务轨迹接口返回值,获取设备轨迹完整率
    val httpData_dev: (String,String,Double,String,String,String) = parseTrackQueryHttpData(retJSONObject_1)
    //融合轨迹接口返回值,获取手机轨迹完整率
    val httpData_pho: (String,String,Double,String,String,String) = parseTrackQueryHttpData(retJSONObject_2)

    obj.put("dev_halfway_integrate_rate",httpData_dev._3)
    obj.put("dev_task_tracks",httpData_dev._4)
    obj.put("dev_task_tracks_jpq",httpData_dev._5)
    obj.put("dev_task_tm",httpData_dev._6)

    obj.put("pho_halfway_integrate_rate",httpData_pho._3)
    obj.put("pho_task_tracks",httpData_pho._4)
    obj.put("pho_task_tracks_jpq",httpData_pho._5)
    obj.put("pho_task_tm",httpData_pho._6)

    obj
  }

  // 获取hive数据源
  def getDataSource(spark: SparkSession, dayBefore2: String, dayBefore8: String) = {
    import spark.implicits._
    val track_miss_sql =
      s"""
         |select
         |  task_id,
         |  vehicle_serial,
         |  start_dept,
         |  end_dept,
         |  line_code,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  actual_run_time,
         |  carrier_type,
         |  crossflag,
         |  recalculatestarttime,
         |  recalculateendtime,
         |  recalculatecontinuetm,
         |  time_slot,
         |  max_continuetm,
         |  max_time_slot
         |from
         |  dm_gis.gis_vms_gta_track_miss_all
         |where
         |  inc_day = '$dayBefore2'
         |  and actual_run_time > 10
         |""".stripMargin
    println(track_miss_sql)
    val df_track_miss = spark.sql(track_miss_sql)

    val recall1_sql =
      s"""
         |select
         |  task_id,
         |  task_area_code,
         |  plan_depart_tm,
         |  plan_arrive_tm,
         |  is_stop,
         |  if_error,
         |  carrier_name,
         |  accrual_dist,
         |  last_update_tm
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day >= '$dayBefore8'
         |  and inc_day <= '$dayBefore2'
         |  and actual_run_time > 10
         |""".stripMargin
    println(recall1_sql)
    val df_recall1 = spark.sql(recall1_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("last_update_tm"))))
      .filter('rn === 1)
      .drop("rn")

    (df_track_miss,df_recall1)
  }

  // 计算 matching 标签
  def getMatchingType(accrual_dist: Double, sim1: Double, sim5: Double) = {
    var matching = 1
    var matching_type = 0

    if (accrual_dist > 500) {
      if ((sim1 >= 0.9 || sim5 >= 0.9) && (sim1 > 0.85 && sim5 > 0.85)) {
        matching = 0
        matching_type = 5
      }else{
        matching = 1
        matching_type = -5
      }
    } else if (accrual_dist > 100 && accrual_dist <= 500) {
      if ((sim1 >= 0.85 || sim5 >= 0.85) && (sim1 > 0.8 && sim5 > 0.8)) {
        matching =0
        matching_type = 4
      } else{
        matching = 1
        matching_type = -4
      }
    } else if (accrual_dist > 50 && accrual_dist <= 100) {
      if ((sim1 >= 0.8 || sim5 >= 0.8) && (sim1 > 0.75 && sim5 > 0.75)) {
        matching = 0
        matching_type = 3
      }else{
        matching = 1
        matching_type = -3
      }
    } else if (accrual_dist > 10 && accrual_dist <= 50) {
      if ((sim1 >= 0.75 || sim5 >= 0.75) && (sim1 > 0.7 && sim5 > 0.7)) {
        matching = 0
        matching_type = 2
      }else{
        matching = 1
        matching_type = -2
      }
    } else if (accrual_dist > 5 && accrual_dist <= 10) {
      if ((sim1 >= 0.6 || sim5 >= 0.6) && (sim1 > 0.5 && sim5 > 0.5)) {
        matching =0
        matching_type = 1
      }else{
        matching = 1
        matching_type = -1
      }
    }

    (matching,matching_type)
  }

  def execute(spark: SparkSession, dayBefore2: String, dayBefore8: String) = {

    import spark.implicits._
    // 获取hive源数据
    val (df_track_miss,df_recall1) = getDataSource(spark,dayBefore2,dayBefore8)

    // 获取线下终端数据
    val df_terminal: DataFrame = spark.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/user/01417347/upload/data/承运商外部厂商设备轨迹对接记录.csv")

    // 数据关联
    val df_join = df_terminal
      .join(df_track_miss,Seq("vehicle_serial"),"left")
      .join(df_recall1,Seq("task_id"),"left")

    // vin不为空的数据跑轨迹查询接口
    val rdd_join = SparkNet.runInterfaceWithAkLimit(spark,df_join.rdd.map(row2Json),runTrackQueryByTaskIdInteface,20,"26c3efb97871433db3bc70cbf6ae95b5",10000)

    val df_ret = rdd_join.map(obj => {
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val vehicle_color = JSONUtil.getJsonVal(obj, "vehicle_color", "")
      val sim = JSONUtil.getJsonVal(obj, "sim", "")
      val termination_id = JSONUtil.getJsonVal(obj, "termination_id", "")
      val org_name = JSONUtil.getJsonVal(obj, "org_name", "")
      val province = JSONUtil.getJsonVal(obj, "province", "")
      val city = JSONUtil.getJsonVal(obj, "city", "")
      val county = JSONUtil.getJsonVal(obj, "county", "")
      val owner_type = JSONUtil.getJsonVal(obj, "owner_type", "")
      val owner_name = JSONUtil.getJsonVal(obj, "owner_name", "")
      val driver_name = JSONUtil.getJsonVal(obj, "driver_name", "")
      val driver_phone = JSONUtil.getJsonVal(obj, "driver_phone", "")
      val vin = JSONUtil.getJsonVal(obj, "vin", "")
      val transport_industry_type = JSONUtil.getJsonVal(obj, "transport_industry_type", "")
      val terminal_manufacturer = JSONUtil.getJsonVal(obj, "terminal_manufacturer", "")
      val terminal_model = JSONUtil.getJsonVal(obj, "terminal_model", "")
      val actual_carrier_name = JSONUtil.getJsonVal(obj, "actual_carrier_name", "")
      val access_time = JSONUtil.getJsonVal(obj, "access_time", "")
      val equipment_manufacturer = JSONUtil.getJsonVal(obj, "equipment_manufacturer", "")
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
      val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
      val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
      val actual_run_time = JSONUtil.getJsonVal(obj, "actual_run_time", "")
      val carrier_type = JSONUtil.getJsonVal(obj, "carrier_type", "")
      val crossflag = JSONUtil.getJsonVal(obj, "crossflag", "")
      val recalculatestarttime = JSONUtil.getJsonVal(obj, "recalculatestarttime", "")
      val recalculateendtime = JSONUtil.getJsonVal(obj, "recalculateendtime", "")
      val recalculatecontinuetm = JSONUtil.getJsonVal(obj, "recalculatecontinuetm", "")
      val time_slot = JSONUtil.getJsonVal(obj, "time_slot", "")
      val max_continuetm = JSONUtil.getJsonVal(obj, "max_continuetm", "")
      val max_time_slot = JSONUtil.getJsonVal(obj, "max_time_slot", "")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val plan_depart_tm = JSONUtil.getJsonVal(obj, "plan_depart_tm", "")
      val plan_arrive_tm = JSONUtil.getJsonVal(obj, "plan_arrive_tm", "")
      val if_error = JSONUtil.getJsonVal(obj, "if_error", "")
      val is_stop = JSONUtil.getJsonVal(obj, "is_stop", "")
      val carrier_name = JSONUtil.getJsonVal(obj, "carrier_name", "")
      val accrual_dist = JSONUtil.getJsonDouble(obj, "accrual_dist", 0.0) / 1000 // 单位转换成KM

      val dev_halfway_integrate_rate = JSONUtil.getJsonDouble(obj, "dev_halfway_integrate_rate", -1)
      val pho_halfway_integrate_rate = JSONUtil.getJsonDouble(obj, "pho_halfway_integrate_rate", -1)
      val dev_task_tracks = JSONUtil.getJsonVal(obj, "dev_task_tracks", "")
      val pho_task_tracks = JSONUtil.getJsonVal(obj, "pho_task_tracks", "")
      val dev_task_tm = JSONUtil.getJsonVal(obj, "dev_task_tm", "")
      val pho_task_tm = JSONUtil.getJsonVal(obj, "pho_task_tm", "")
      val dev_task_tracks_jpq = JSONUtil.getJsonVal(obj, "dev_task_tracks_jpq", "")
      val pho_task_tracks_jpq = JSONUtil.getJsonVal(obj, "pho_task_tracks_jpq", "")


      // tracks_error 标签
      var tracks_error = "否"
      if (!nonEmpty(dev_task_tracks) && !nonEmpty(pho_task_tracks)) {
        tracks_error = "设备&手机轨迹均为空"
      }else if(!nonEmpty(dev_task_tracks)){
        tracks_error = "设备轨迹为空"
      }else if(!nonEmpty(pho_task_tracks)){
        tracks_error = "手机轨迹为空"
      }

      // 计算轨迹相似度和 matching 标签
      var sim1 = 0.0
      var sim5 = 0.0
      var matching = 1
      var matching_type = 0

      if (tracks_error.equals("否")) {
        // 调用jar包计算相似度
        val task_obj = new JSONObject()
        val host_obj = new JSONObject()
        task_obj.put("rt_coords",dev_task_tracks)
        host_obj.put("rt_coords",pho_task_tracks)
        val simil: pathSimilar.Tuple2[lang.Double, lang.Double] = pathSimilar.PathSimilar.simProcess(task_obj, host_obj)
        sim1 = simil.first
        sim5 = simil.second

        // 计算 matching 标签
        val ret_matching = getMatchingType(accrual_dist,sim1,sim5)
        matching = ret_matching._1
        matching_type = ret_matching._2
      }

      TracksSimilarity(vehicle_serial,vehicle_color,sim,termination_id,org_name,province,city,county,owner_type,owner_name,driver_name,driver_phone,vin,
        transport_industry_type,terminal_manufacturer,terminal_model,actual_carrier_name,access_time,equipment_manufacturer,task_id,start_dept,
        end_dept,line_code,actual_depart_tm,actual_arrive_tm,actual_run_time,carrier_type,crossflag,recalculatestarttime,recalculateendtime,
        recalculatecontinuetm,time_slot,max_continuetm,max_time_slot,task_area_code,plan_depart_tm,plan_arrive_tm,if_error,is_stop,carrier_name,
        accrual_dist,dev_halfway_integrate_rate,pho_halfway_integrate_rate,sim1,sim5,matching,matching_type,dev_task_tracks,pho_task_tracks,
        dev_task_tm,pho_task_tm,dev_task_tracks_jpq,pho_task_tracks_jpq)
    }).toDF()
      .withColumn("dev_tracks_error",when('dev_halfway_integrate_rate < 0.9,1).otherwise(0))
      .withColumn("pho_tracks_error",when('pho_halfway_integrate_rate < 0.9,1).otherwise(0))
      .withColumn("source",when('dev_tracks_error === 0 && 'pho_tracks_error === 0,0)
        .when('dev_tracks_error === 1 && 'pho_tracks_error === 0,1)
        .when('pho_tracks_error === 1 && 'dev_tracks_error === 0,2)
        .when('pho_tracks_error === 1 && 'dev_tracks_error === 1,3)
      )
      .withColumn("inc_day",lit(dayBefore2))

    val cols = spark.sql("""select * from dm_gis.device_phone_tracks_similarity_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols: _*),Seq("inc_day"),"dm_gis.device_phone_tracks_similarity_detail")

  }

  case class TracksSimilarity(
                               vehicle_serial : String,
                               vehicle_color : String,
                               sim : String,
                               termination_id : String,
                               org_name : String,
                               province : String,
                               city : String,
                               county : String,
                               owner_type : String,
                               owner_name : String,
                               driver_name : String,
                               driver_phone : String,
                               vin : String,
                               transport_industry_type : String,
                               terminal_manufacturer : String,
                               terminal_model : String,
                               actual_carrier_name : String,
                               access_time : String,
                               equipment_manufacturer : String,
                               task_id : String,
                               start_dept : String,
                               end_dept : String,
                               line_code : String,
                               actual_depart_tm : String,
                               actual_arrive_tm : String,
                               actual_run_time : String,
                               carrier_type : String,
                               crossflag : String,
                               recalculatestarttime : String,
                               recalculateendtime : String,
                               recalculatecontinuetm : String,
                               time_slot : String,
                               max_continuetm : String,
                               max_time_slot : String,
                               task_area_code : String,
                               plan_depart_tm : String,
                               plan_arrive_tm : String,
                               if_error : String,
                               is_stop : String,
                               carrier_name : String,
                               accrual_dist : Double,
                               dev_halfway_integrate_rate : Double,
                               pho_halfway_integrate_rate : Double,
                               sim1 : Double,
                               sim5 : Double,
                               matching : Int,
                               matching_type : Int,
                               dev_task_tracks : String,
                               pho_task_tracks : String,
                               dev_task_tm : String,
                               pho_task_tm : String,
                               dev_task_tracks_jpq : String,
                               pho_task_tracks_jpq : String
                             )

}
