package app

import Utils.SparkUtils.writeToHive
import app.EtaCarrierLogData2Hive.timeToCustomTime2
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._

/**
 * 需求内容：将时效晚点记录明细数据导入hive,按天分区
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：961843
 * 任务名称：时效晚点记录明细数据导入hive
 */
object TaskExceptionRecord2Hive {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  val url = "jdbc:mysql://plan-s1.db.sfcloud.local:3306/plan?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
  val driver = "com.mysql.jdbc.Driver"
  val username = "plan"
  val password = "plan20210121#"
  // 表名
  val tableName1 = "task_exception_record"

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore5 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 5)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"+++++  任务开始 dayBefore1=$dayBefore1  dayBefore5=$dayBefore5  +++++")

    import spark.implicits._
    // 读取mysql数据
    val connMap1 = Map("url" -> url, "user" -> username,"password" -> password, "dbtable" -> tableName1,"driver" -> driver)
    val df_carrier = spark.read.format("jdbc").options(connMap1).load()
      .withColumn("inc_day",timeToCustomTime2('create_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("del_flag",when('del_flag,1).otherwise(0))
      .filter('inc_day >= dayBefore5 && 'inc_day <= dayBefore1)

    val cols_1 = spark.sql("""select * from dm_gis.task_exception_record limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_carrier.select(cols_1: _*),Seq("inc_day"),"dm_gis.task_exception_record")

    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
    logger.error("+++++++++    任务结束 20240111    ++++++++")
    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
  }
}
