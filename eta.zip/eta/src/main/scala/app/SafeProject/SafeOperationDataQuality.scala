package app.SafeProject

import Utils.{DateTimeUtil, JSONUtils, SparkUtils}
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.eta.constant.StandardRouteMileage.DistanceTool
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2021/12/21
*/


object SafeOperationDataQuality {

  @transient lazy val logger: Logger = Logger.getLogger(SafeOperationDataQuality.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  case class DataQuailty (un:String ,driftCnt:Int ,completMileage:Double ,uncompletMileage:Double ,allMileage:Double,inc_day:String)


  def getSourceData(spark: SparkSession, inc_day: String) = {

    val curTimeStamp = DateTimeUtil.getCurDayTimeStamp(inc_day)

    val sql =
      s"""
         |select
         | un,zx,zy,tm
         |from
         |(
         |select
         |  un,zx,zy,tm,row_number() over (partition by un,tm order by sp) rn
         |from
         |  dm_gis.gis_vms_track_device_track_flatmap
         |where
         |  inc_day ='${inc_day}'
         |and
         |  ak != '300'
         |and
         |  tm >= '${curTimeStamp}'
         |) a
         |where a.rn = 1
       """.stripMargin
    logger.error("输入sql为：" + sql)

    val sourceDf = spark.sql(sql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf,"Memory")

    logger.error("sourceRdd的数据量为:" + sourceRdd.count())
    sourceRdd.take(2).foreach(println(_))
    sourceRdd


  }

  def calProcess(sourceRdd: RDD[JSONObject],inc_day:String) = {

    val calResRdd1 = sourceRdd.map(x => {

        val un = x.getString("un")
        //按照un进行分组
        (un,x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).map(x => {

      val list = x._2.toList
      //在此进行tm升序排序
      val listSort = list.sortBy(obj => {
        val tm = obj.getString("tm")
        tm
      })
      (x._1,listSort)
    }).repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("calResRdd1的数据量为：" + calResRdd1.count())

    val calSecondRdd = calResRdd1.filter(x => {
      val size = x._2.size
      size > 1440
    }).map(x => {
      val un = x._1
      val list = x._2
      val listFilter = new ArrayBuffer[JSONObject]()

      for (i <- (0  until(list.size))){
        if (i % 30 == 0){
          listFilter.append(list(i))
        }
      }
      (un,listFilter.toList)
    })

    val calMintueRdd = calResRdd1.filter(x => {
      val size = x._2.size
      size <= 1440
    })


    val calTotalSourceRdd = calSecondRdd.union(calMintueRdd)

    //计算Mileage
      val calMileageRdd = calTotalSourceRdd.map(x => {
      val listSort = x._2
//      //在此进行tm升序排序
//      val listSort = list.sortBy(obj => {
//        val tm = obj.getString("tm")
//        tm
//      })

      // 对每组内的zx和zy进行判断
      var driftCnt = 0
      var completCnt = 0

      var allMileage = 0.0
      var completMileage = 0.0
      //var uncompletMileage = 0

      if (listSort.length > 3) {

        for (i <- (0 until(listSort.length -2))) {
          val trajPre = listSort(i)

          val preX = JSONUtils.getJsonValueDouble(trajPre,"zx",0)
          val preY = JSONUtils.getJsonValueDouble(trajPre,"zy",0)
          val preTm = JSONUtils.getJsonValueLong(trajPre,"tm",0)

          val trajCur = listSort(i+1)
          val curX = JSONUtils.getJsonValueDouble(trajCur,"zx",0)
          val curY = JSONUtils.getJsonValueDouble(trajCur,"zy",0)
          val curTm = JSONUtils.getJsonValueLong(trajCur,"tm",0)

          val trajAfter = listSort(i+2)
          val afterX = JSONUtils.getJsonValueDouble(trajAfter,"zx",0)
          val afterY = JSONUtils.getJsonValueDouble(trajAfter,"zy",0)
          val afterTm = JSONUtils.getJsonValueLong(trajAfter,"tm",0)


          val distance1 = DistanceTool.getGreatCircleDistance(preX,preY,curX,curY) / 1000
          val distance2 = DistanceTool.getGreatCircleDistance(curX,curY,afterX,afterY) / 1000


          val diffHour1 = (curTm - preTm) / 3600.0
          val diffHour2 = (afterTm - curTm) / 3600.0

          val speed1 = distance1 / diffHour1
          val speed2 = distance2 / diffHour2

          if (speed1 > 160 && speed2 > 160) {
            driftCnt += 1
          }

          allMileage += distance1

          //如果距离小于2 或者 距离大于2 小于10 ，则加入到完整距离中
          if (distance1 <= 2){
            //小于2，调整completCnt
            completCnt = 0
            completMileage += distance1
          } else if (distance1 >0 && distance1 <=10){
            //大于2小于10，completCnt加1
            completCnt +=1
            //如果小于等于5段，大于0 小于10
            if (completCnt <= 5){
              completMileage += distance1
            }
          } else {
            // TODO: 如果5次中有一次大于10km，是否清空completCnt
            completCnt = 0
          }

          //如果循环到最后，需要把下一段距离加到总距离里面
          if (i == listSort.length -3) {
            //如果循环到最后，需要把下一段完整距离加到完整度距离和
            if (completCnt <=5 && distance2 <= 10) {
              completMileage += distance2
            }
            allMileage += distance2
          }
        }
      }

      val uncompletMileage = allMileage - completMileage

      val un = x._1
//        (un,(driftCnt,completMileage,uncompletMileage,allMileage))
      DataQuailty(un,driftCnt,completMileage,uncompletMileage,allMileage,inc_day)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("calResRdd的数据量为;" + calMileageRdd.count())
    calMileageRdd.take(2).foreach(println(_))
    calMileageRdd

//    //计算Duration
//    val calDurationRdd= calResRdd1.map(x => {
//
//      val un = x._1
//      val listSort = x._2.toList
//
////      //在此进行tm升序排序
////      val listSort = list.sortBy(obj => {
////        val tm = obj.getString("tm")
////        tm
////      })
//      var allDurtion = 0L
//      var unDriveDuration = 0L
//      var nightDriveDuration = 0L
//
//
//      //val durationArray = new ArrayBuffer[JSONArray]()
//      val durationArray = new JSONArray()
//      // 设置中断点
//      var startPoint = listSort.length -1
//      var endPoint = 0
//      // 中断间隔为0 则重新开始计算中断 为1则正在计算轨迹终点
//      var intervelTag = 0
//      // 设置驾驶起终点
//      var driveStartPoint = 0
//
//
//        for (i <- (0 until (listSort.length - 1))) {
//
//          val trajPre = listSort(i)
//          val preX = JSONUtils.getJsonValueDouble(trajPre,"zx",0)
//          val preY = JSONUtils.getJsonValueDouble(trajPre,"zy",0)
//          val preTm = JSONUtils.getJsonValueLong(trajPre,"tm",0)
//          val preSpeed = JSONUtils.getJsonValueDouble(trajPre,"sp",0)
//
//          val trajCur = listSort(i+1)
//          val curX = JSONUtils.getJsonValueDouble(trajCur,"zx",0)
//          val curY = JSONUtils.getJsonValueDouble(trajCur,"zy",0)
//          val curTm = JSONUtils.getJsonValueLong(trajCur,"tm",0)
//          val curSpeed = JSONUtils.getJsonValueDouble(trajCur,"sp",0)
//
//          //计算总时长
//          allDurtion  += curTm - preTm
//
//          //开始计算中断驾驶
//          if (preSpeed == 0 && curSpeed == 0 && intervelTag == 0) {
//            startPoint = i
//            intervelTag = 1
//          }
//
//          if (preSpeed == 0 && curSpeed != 0 && intervelTag == 1){
//              val tmpEndPoint = i
//
//              // 如果有终止点则截取非驾驶时长
//              // 判断速度为0是否超过3min
//              // TODO: 或者轨迹点超过10min
//              val startPointJson = listSort(startPoint)
//              val tmpEndPointJson = listSort(tmpEndPoint)
//
//              val startPointTm = JSONUtils.getJsonValueLong(startPointJson,"tm",0)
//              val endPointTm = JSONUtils.getJsonValueLong(tmpEndPointJson,"tm",0)
//
//              val diffTm = endPointTm - startPointTm
//
//              // 当速度为0 超过3min为停驶
//              if (diffTm > 180){
//                //计算非驾驶时长
//                unDriveDuration += diffTm
//                endPoint = i
//
//                // 获取驾驶区间
//                if (startPoint >= 0 ){
//                  val driveStartJson = listSort(driveStartPoint)
//                  // 驾驶区间的终点为中断区间的起点
//                  val driveEndJson = listSort(startPoint)
//
//                  val startPointTm = JSONUtils.getJsonValueLong(driveStartJson,"tm",0)
//                  val endPointTm = JSONUtils.getJsonValueLong(driveEndJson,"tm",0)
//
//                  val jsonArray = new JSONArray()
//                  jsonArray.add(startPointTm)
//                  jsonArray.add(endPointTm)
//
//                  durationArray.add(jsonArray)
//                  //更新驾驶起始点
//                  driveStartPoint = endPoint
//
//                  //计算夜间行车时长
//                  nightDriveDuration += DateTimeUtil.calNightDriveDurationTime2(startPointTm,endPointTm)
//
//                }
//                // 截取完成后，驾驶区间终止点恢复到队尾
//                startPoint = listSort.length -1
//              }else {
//                // 截取完成后，驾驶区间终止点恢复到队尾
//                startPoint = listSort.length -1
//              }
//
//                // 每当下个点不为0时，都需要重置intervel，重新开始计算中断间隔
//                intervelTag = 0
//
//          } else if (i == listSort.length -2 && preSpeed == 0 && curSpeed == 0  && intervelTag == 1){
//            //在最后节点，依然速度为0，并且依然
//            //在判断是否中断，则不用截取驾驶区间，直接更新非驾驶时长
//            endPoint = i + 1
//            //判断速度为0是否超过3min
//            val startPointJson = listSort(startPoint)
//            val endPointJson = listSort(endPoint)
//
//            val startPointTm = JSONUtils.getJsonValueLong(startPointJson,"tm",0)
//            val endPointTm = JSONUtils.getJsonValueLong(endPointJson,"tm",0)
//
//            val diffTm = endPointTm - startPointTm
//            if (diffTm > 180){
//              //计算非驾驶时长
//              unDriveDuration += diffTm
//              if (startPoint >= 0 ){
//                val driveStartJson = listSort(driveStartPoint)
//                // 驾驶区间的终点为中断区间的起点
//                val driveEndJson = listSort(startPoint)
//
//                val startPointTm = JSONUtils.getJsonValueLong(driveStartJson,"tm",0)
//                val endPointTm = JSONUtils.getJsonValueLong(driveEndJson,"tm",0)
//
//                val jsonArray = new JSONArray()
//                jsonArray.add(startPointTm)
//                jsonArray.add(endPointTm)
//
//                durationArray.add(jsonArray)
//                //更新驾驶起始点
//                driveStartPoint = endPoint
//
//                //计算夜间行车时长
//                nightDriveDuration += DateTimeUtil.calNightDriveDurationTime2(startPointTm,endPointTm)
//              }
//            }else {
//              if (startPoint >= 0 ){
//                val driveStartJson = listSort(driveStartPoint)
//                // 驾驶区间的终点为轨迹的终止点
//                val driveEndJson = listSort(i + 1)
//
//                val startPointTm = JSONUtils.getJsonValueLong(driveStartJson,"tm",0)
//                val endPointTm = JSONUtils.getJsonValueLong(driveEndJson,"tm",0)
//
//                val jsonArray = new JSONArray()
//                jsonArray.add(startPointTm)
//                jsonArray.add(endPointTm)
//
//                durationArray.add(jsonArray)
//                //计算夜间行车时长
//                nightDriveDuration += DateTimeUtil.calNightDriveDurationTime2(startPointTm,endPointTm)
//              }
//            }
//           } else if (i == listSort.length -2 && intervelTag == 0){
//
//            // 如果不在判断是否中断，则截取驾驶起点到终点，为驾驶区间
//            val driveStartJson = listSort(driveStartPoint)
//            // 驾驶区间的终点为中断区间的起点
//            val driveEndJson = listSort(startPoint)
//
//            val startPointTm = JSONUtils.getJsonValueLong(driveStartJson,"tm",0)
//            val endPointTm = JSONUtils.getJsonValueLong(driveEndJson,"tm",0)
//
//            val jsonArray = new JSONArray()
//            jsonArray.add(startPointTm)
//            jsonArray.add(endPointTm)
//
//            durationArray.add(jsonArray)
//            nightDriveDuration += DateTimeUtil.calNightDriveDurationTime2(startPointTm,endPointTm)
//          }
//        }
//
//      val driveDuration = allDurtion - unDriveDuration
//
//      (un,(driveDuration,allDurtion,nightDriveDuration,durationArray.toJSONString))
//    })
//
//    logger.error("calDurationRdd的数据量为：" + calDurationRdd.count())
//    calDurationRdd.take(2).foreach(println(_))



//    val DataQuailtyRdd = calMileageRdd.leftOuterJoin(calDurationRdd).map(x => {
//
//      val un = x._1
//      val (driftCnt,completMileage,uncompletMileage,allMileage) = x._2._1
//      var driveDuration = 0L
//      var allDurtion =  0L
//      var nightDriveDuration =  0L
//      var durationArray = ""
//      val rightOp = x._2._2
//      if(rightOp.nonEmpty){
//        driveDuration = rightOp.get._1
//        allDurtion = rightOp.get._2
//        nightDriveDuration = rightOp.get._3
//        durationArray = rightOp.get._4
//      }
//      DataQuailty(un,driftCnt,completMileage,uncompletMileage,allMileage,driveDuration,allDurtion,nightDriveDuration,durationArray,inc_day)
//    })
//
//    logger.error("DataQuailtyRdd的数据量为：" + DataQuailtyRdd.count())
//    DataQuailtyRdd.take(2).foreach(println(_))
//    DataQuailtyRdd
  }




  def saveToHive(spark: SparkSession, inc_day: String, calRdd: RDD[DataQuailty]) = {

    import spark.implicits._
    val insertTable = "dm_gis.safe_operation_data_quality"

    calRdd.toDF().repartition(100).write.mode(SaveMode.Overwrite).insertInto(insertTable)

  }

  def staStat(spark: SparkSession, inc_day: String) = {

      val sourceRdd = getSourceData(spark,inc_day)

      val calRdd = calProcess(sourceRdd,inc_day)

      saveToHive(spark,inc_day,calRdd)

  }


  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    staStat(spark,inc_day)
    logger.error("统计结束")

  }

  def main(args: Array[String]): Unit = {

    val inc_day =args(0)
//    val inc_day =""

    start(inc_day)

  }



}
