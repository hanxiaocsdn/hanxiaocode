package app.SafeProject

import com.alibaba.fastjson.JSONObject
import com.huaban.analysis.jieba.JiebaSegmenter
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object SimilarityCal {
  @transient lazy val logger: Logger = Logger.getLogger(SimilarityCal.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  case class idfTable(keyWord:String,Ratio:Double)

  def getIdfModel(spark: SparkSession,sourceDf: DataFrame) = {

    val preprocessRdd = sourceDf.rdd.filter(x => {StringUtils.nonEmpty(x.getString(0))}).flatMap(x => {
      import scala.collection.JavaConversions._

      import spark.implicits._
      val keyword = x.getString(0)
      val jieba = new JiebaSegmenter()
      val buffer = new ArrayBuffer[String]

      val array = jieba.sentenceProcess(keyword)
        if (array.size()>0 ) {
          array.foreach(x => {
            buffer.append(x)
          })
        }
      buffer
      //arrayNew
    }).filter(_.size >0).map(x => {
      (x, 1)
    }).reduceByKey((x,y) => {x+y}).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val countAll = preprocessRdd.map(_._2).reduce((x,y) => (x+y))

    val countAllBroadcast = spark.sparkContext.broadcast(countAll)

    val idfRdd = preprocessRdd.map(x => {
      val keyWord  = x._1
      val useCnt = x._2.toDouble
      val countAll = countAllBroadcast.value
      val ratio  = Math.log10(countAll/useCnt)
      (keyWord,ratio)
    })
    preprocessRdd.unpersist()

    idfRdd
  }

  def saveToHiveTable(spark: SparkSession,idfRdd: RDD[(String, Double)], idfRatioTable: String): Unit = {
    import  spark.implicits._
    val idfDf = idfRdd.map(x => {
      idfTable(x._1,x._2)
    }).toDF()
    idfDf.repartition(100).write.mode(SaveMode.Overwrite).insertInto("dm_gis." + idfRatioTable)
    logger.error("入库总量为：" + idfDf.count())
  }

  def startSta(spark: SparkSession, inc_day: String): Unit = {
//    val idfRatioTable = "keyword_idf_ratio"
//
//    val inputSql =
//      s"""
//         |select keyword from
//         |
//       """.stripMargin

    import spark.implicits._
//    val sourceDf = spark.sql(inputSql).toDF("keyword").persist(StorageLevel.MEMORY_AND_DISK_SER)
//    val sourceColList = sourceDf.columns
//    val sourceRdd = sourceDf.rdd.map(x => {
//      val jo = new JSONObject()
//      for (columns <- sourceColList) {
//        jo.put(columns,x.getAs[String](columns))
//      }
//      val vehicle_serial = x.getString(20)
//      (vehicle_serial,jo)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("获取sourceRdd数据，数据量为:" + sourceRdd.count())
//    val getKeyWordRdd = getKeyWord()


    //val sourceDf = spark.read.format("csv").option("header", "true").load("d:\\user\\01401062\\桌面\\20210507_hangzhou.csv")
    val sourceDf = spark.read.format("csv").option("header", "true").load("d:\\user\\01401062\\桌面\\20210519_CMP_ALL_PAR.csv")
    sourceDf.take(2).foreach(println(_))

    val sourceDf2 = sourceDf.filter(x => {
      val comp_tag = x.getString(1)
      StringUtils.nonEmpty(comp_tag) && !"personal".equals(comp_tag)
    }).map(x => {
      val name = x.getString(0)
      val nameNew = try{name.replaceAll("企业名称:","").split(";")(0)} catch {case e:Exception => name}
      nameNew
    }).toDF("name")

    val idfRdd = getIdfModel(spark,sourceDf2).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("idfRdd的数据量为" + idfRdd.count())

    //idfRdd.toDF("keyword","ratio").repartition(1).write.mode(SaveMode.Overwrite).csv("d:\\user\\01401062\\桌面\\20210507_hangzhou.map")
    idfRdd.toDF("keyword","ratio").repartition(1).write.mode(SaveMode.Overwrite).csv("d:\\user\\01401062\\桌面\\20210519_hangzhou.map")
    // saveToHiveTable(spark,idfRdd,idfRatioTable)



  }



  def start(inc_day:String): Unit = {

    val spark = SparkSession.builder()
      .appName("SparkDecode")
      .master("local[6]")
      .getOrCreate()


//      .master("yarn")
//      .enableHiveSupport()
//      .config("hive.exec.dynamic.partition",true)
//      .config("hive.exec.dynamic.partition.mode","nonstrict")
//      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    startSta(spark,inc_day)
    logger.error("统计完成")

  }

  def main(args: Array[String]): Unit = {
    val inc_day = "20210412"
    start(inc_day)
  }






}
