package app.insuranceEvaluation

import org.apache.log4j.Logger
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/5/10
*/


object InsuranceCalRes2 {
  @transient lazy val logger: Logger = Logger.getLogger(InsuranceCalRes2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def start(spark: SparkSession): Unit = {

//    val frame1 = spark.read.format("csv").option("header", "true").load("d:\\user\\01401062\\桌面\\21年4月-22年3月货车各月里程特征表_result.csv")
//    frame1.createOrReplaceTempView("res_data_table")
    val frame2 = spark.read.format("csv").option("header", "true").load("d:\\user\\01401062\\桌面\\0517_2.csv")
    frame2.createOrReplaceTempView("res_daily_data_table")
    frame2.take(2).foreach(println(_))



    val sql =
      s"""
         |select
         |  vehicel_no,substring(inc_day,0,6) month,
         |  max(drive_dist) as `行驶里程`,
         |  max(night_dirve_dist) as `夜间行驶里程`,
         |  max(before_dawn_drive_dist) as `凌晨行驶里程`,
         |  max(early_morning_drive_dist) as `清晨行驶里程`,
         |  max(afternoon_drive_dist) as `午后行驶里程`,
         |  max(dusk_drive_dist) as `黄昏行驶里程`,
         |  max(high_speed_dist) as `高速行驶里程`,
         |  max(state_road) as `国道行驶里程`,
         |  max(provincial_road) as `省道行驶里程`
         |from
         |  res_daily_data_table
         |group by
         |  vehicel_no,substring(inc_day,0,6)
       """.stripMargin

    val df = spark.sql(sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("sql的数据量为：" + df.count())
    //    val rdd = SparkUtils.getRowToJson(frame1)
    df.take(2).foreach(println(_))
    df.toDF().repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter","\t").csv("d:\\user\\01401062\\桌面\\20220517_2.csv")





  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("local[6]")
//      .enableHiveSupport()
//      .config("hive.exec.dynamic.partition",true)
//      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")

    start(spark)


  }




}
