package app.insuranceEvaluation

import Utils.{DateTimeUtil, JSONUtils, SparkUtils}
import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.log4j.Logger

import scala.collection.mutable

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/9/19
*/


object InsuranceRiskAlertCal {
  @transient lazy val logger: Logger = Logger.getLogger(InsuranceCalRes2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val requestRoadClassUrl = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/nearestRoad"




  case class geoInfoTable(
                       id:String,imei:String,alarm_id:String,ft_alarm_id:String,car_no:String,zy_type:String,alarm_time:String,alarm_name:String,
                       alarm_name_sta:String,ft_p_type:String,ft_sub_type:String,p_type:String,sub_type:String,p_type_r:String,sub_type_r:String,
                       r_flag:String,tf_flag:String,warn_id:String,create_time:String,speed:String,lng:String,lat:String,lng_i:String,lat_i:String,
                       uid:String,dir:String,distance:String,name:String,road_class:String,adcode:String,inc_day:String
                     )

  case class daily(
                    imei:String,car_no:String,zy_type:String,alarm_name_sta:String,alarm_sum_cnt:String,alarm_night_cnt:String,
                    alarm_before_dawn_cnt:String,alarm_early_morning_cnt:String,alarm_afternoon_cnt:String,alarm_dusk_cnt:String,
                    alarm_high_speed_cnt:String,alarm_state_road_cnt:String,alarm_provincial_cnt:String,alarm_county_speed_cnt:String,
                    alarm_township_cnt:String,med_risk_cnt:String,high_risk_cnt:String,average_speed:String,inc_day:String
                  )



  def parseRoadClass(x: JSONObject, rep: String) = {

//    {"status":0,"pnt":"117.947740,31.552453","pnt_i":"117.947703,31.552443",
    // "uid":7981375237175,"dir":1,"distance":3.702309103953843,
    // "name":"S22天天高速","road_class":0,"adcode":340522}


    val repJo = JSON.parseObject(rep)

    try {

      val pnt_i = JSONUtils.getJsonValue(repJo,"pnt_i","").split(",")
      val lng_i = if (pnt_i.size>1) pnt_i(0) else 0
      val lat_i = if (pnt_i.size>1) pnt_i(1) else 0
      val uid = JSONUtils.getJsonValue(repJo,"uid","")
      val dir = JSONUtils.getJsonValue(repJo,"dir","")
      val distance = JSONUtils.getJsonValue(repJo,"distance","")
      val name = JSONUtils.getJsonValue(repJo,"name","")
      val road_class = JSONUtils.getJsonValue(repJo,"road_class","")
      val adcode = JSONUtils.getJsonValue(repJo,"adcode","")

      x.put("lng_i",lng_i)
      x.put("lat_i",lat_i)
      x.put("uid",uid)
      x.put("dir",dir)
      x.put("distance",distance)
      x.put("name",name)
      x.put("road_class",road_class)
      x.put("adcode",adcode)

    }catch {
      case e:Exception => e.printStackTrace()
    }

    x

  }



  def requestRoadClassInterface(x:JSONObject,json:JSONObject) = {

    val rep = Utils.Utils.retryPost(requestRoadClassUrl,json)

    val repJson =
      try {
        parseRoadClass(x,rep)
      } catch {
        case e: Exception =>
          x.put("road_class_err", e + "接口异常返回为：" + rep)
          x.put("road_class_errInfo",rep)
          x
      }

    repJson

  }




  def calRoadClassInfo(x:JSONObject) = {

    val postJo = new JSONObject()

    val ak = "57de0ed86fcc452a8e92b05c19047f6a"
    val x1 = JSONUtils.getJsonValue(x,"lng","")
    val y1 = JSONUtils.getJsonValue(x,"lat","")

    // 测试
//    val roadAttrLimitToken = "000011112222333344445555666677778888"

    // 线上
    val roadAttrLimitToken = "6134FAA5B6B6ED55E87EA116466734ED"

    val alarm_name = JSONUtils.getJsonValue(x,"alarm_name","-").trim

    val alarm_name_sta = alarm_name match {
      case alarm_name if alarm_name.equals("分心驾驶低头") || alarm_name.equals("分心驾驶抬头")  => "分心驾驶"
      case alarm_name if alarm_name.equals("人脸比对不一致")  => "驾驶员变更"
      case alarm_name if alarm_name.equals("墨镜遮挡") || alarm_name.equals("阻断型墨镜") => "摄像头遮挡"
      case alarm_name if alarm_name.equals("闭眼") || alarm_name.equals("打哈欠") || alarm_name.equals("疲劳") => "生理疲劳"
      case alarm_name if alarm_name.equals("盲区行人报警") => "盲区行人"
      case alarm_name if alarm_name.equals("右侧后方接近报警") => "右侧后方接近"
      case alarm_name if alarm_name.equals("超限速告警")  => "超限速"
      case alarm_name if alarm_name.equals("逆行") || alarm_name.equals("未带头盔") || alarm_name.equals("逆行占道同时发生")
        || alarm_name.equals("闯红灯") || alarm_name.equals("占道") => "其他"
      case alarm_name if alarm_name.equals("云端算法-疲劳（闭眼）") || alarm_name.equals("云端闭眼检测报警")
        || alarm_name.equals("云端算法-打哈欠")  || alarm_name.equals("云端算法-疲劳(闭眼)")  => "其他"
      case alarm_name => alarm_name
    }
    x.put("alarm_name_sta",alarm_name_sta)

    postJo.put("ak",ak)
    postJo.put("x1",x1)
    postJo.put("y1",y1)
    postJo.put("roadAttrLimitToken",roadAttrLimitToken)

    val repJson = requestRoadClassInterface(x,postJo)


    repJson

  }




  def getRoadClassInfo(getSourceRdd: RDD[JSONObject]) = {

    val limitMin = 6000
    val requestRdd = SparkUtils.akLimitMultiThreadRdd(getSourceRdd)(calRoadClassInfo)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)

    requestRdd

  }

  def concatTimestamp(inc_day: String, start_period_pre: String) = {

    val stamp = DateTimeUtil.getIncDayToTimeStamp2(inc_day,start_period_pre,"yyyyMMdd HH:mm:ss")
    stamp

  }


  def calRiskAlertStatic(obj: ((String,String,String,String),List[JSONObject]),inc_day:String) = {

      val timeArr = Array(("21:00:00","23:59:59"),("00:00:00","03:59:59"),("07:00:00","09:59:59"),("13:00:00","15:59:59"),("17:00:00","19:59:59"))
      val roadArr = Array(0,1,2,3,4)

      val resList = obj._2.sortBy(JSONUtils.getJsonValue(_,"alarm_time","2000-01-01 00:00:00"))
      val (imei,car_no,zy_type,alarm_name_sta) = obj._1

      val alertSum = resList.length.toString
      val speedSum = resList.map(JSONUtils.getJsonValueDouble(_,"speed",0)).sum

      var rowList = Array[String](imei,car_no,zy_type,alarm_name_sta,alertSum)

      // TODO: 计算分时段告警总数
      for (i <- 0 until timeArr.length){
        val start_period_pre = timeArr(i)._1
        val end_period_pre = timeArr(i)._2
        val start_period = concatTimestamp(inc_day,start_period_pre)
        val end_period = concatTimestamp(inc_day,end_period_pre)

        val tmpList = resList.filter(json => {
          val tm = DateTimeUtil.timeToLong(JSONUtils.getJsonValue(json,"alarm_time","2000-01-01 00:00:00"),"yyyy-MM-dd HH:mm:ss") / 1000
          tm >= start_period && tm <= end_period
        })
        val periodNumCnt = tmpList.length
        rowList =  rowList :+ periodNumCnt.toString
      }

      // TODO: 计算分道路告警总数
      for (i <- 0 until roadArr.length){
        val tmpList = resList.filter(json => {
          val road_class = JSONUtils.getJsonValueInt(json,"road_class",-1)
          road_class == roadArr(i)
        })
        val roadClassCnt = tmpList.length
        rowList =  rowList :+ roadClassCnt.toString
      }


      //高危/中危：告警按时间排序，取30分钟内>=5/>=3次的次数

      var med_risk_cnt = 0
      var high_risk_cnt = 0

      if (resList.size>= 3){
        //  从索引为2的开始遍历，即第三个数
        for (i <- (2 until(resList.size))) {
          val start_tm_med = resList(i - 2).getString("alarm_time")
          val end_tm_med = resList(i).getString("alarm_time")
          val diffTm = DateTimeUtil.parseFtTime(start_tm_med,end_tm_med,"yyyy-MM-dd HH:mm:ss")
          if (diffTm <= 30) {
            med_risk_cnt += 1
          }

          if (i >= 4){
            val start_tm_high = resList(i - 4).getString("alarm_time")
            val end_tm_high = resList(i).getString("alarm_time")
            val diffTm2 = DateTimeUtil.parseFtTime(start_tm_high,end_tm_high,"yyyy-MM-dd HH:mm:ss")
            if (diffTm2 <= 30) {
              high_risk_cnt += 1
            }
          }
        }
      }


     rowList = rowList :+ med_risk_cnt.toString
     rowList = rowList :+ high_risk_cnt.toString
     rowList = rowList :+ (speedSum / alertSum.toInt).toString


      rowList
  }



  def getRiskStatic(spark:SparkSession,inc_day:String) = {

    val riskSourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.insurance_risk_alert_roadclass_info
         |where
         |  inc_day='${inc_day}'
         |and
         |  alarm_name_sta != '其他'
       """.stripMargin


    val frame = spark.sql(riskSourceSql)
//    frame.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter","\t").csv("/user/01401062/upload/gis/data/20220919.csv")

//    val frame = spark.read.format("csv").option("header", "true").option("delimiter","\t").load("d:\\user\\01401062\\桌面\\20220919.csv")

    val getSourceRdd = SparkUtils.getRowToJson(frame)


    val resAlarmTypeRdd = getSourceRdd.map(x => {

      val imei = JSONUtils.getJsonValue(x,"imei","")
      val car_no = JSONUtils.getJsonValue(x,"car_no","")
      val zy_type = JSONUtils.getJsonValue(x,"zy_type","")
      val alarm_name_sta = JSONUtils.getJsonValue(x,"alarm_name_sta","")

      ((imei,car_no,zy_type,alarm_name_sta),x)
    })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
        .map(obj => {

          val rowList = calRiskAlertStatic(obj,inc_day)

          Row.fromSeq(rowList)

        }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val resAllRdd = getSourceRdd.map(x => {

      val imei = JSONUtils.getJsonValue(x,"imei","")
      val car_no = JSONUtils.getJsonValue(x,"car_no","")
      val zy_type = JSONUtils.getJsonValue(x,"zy_type","")

      ((imei,car_no,zy_type,"all"),x)
    })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(obj => {
        val rowList = calRiskAlertStatic(obj,inc_day)

        Row.fromSeq(rowList)

      }).persist(StorageLevel.MEMORY_AND_DISK_SER)

      val resRdd = resAlarmTypeRdd.union(resAllRdd)

      logger.error("resRdd的数据量为：" + resRdd.count())

      resRdd
  }




  def getSourceData(spark: SparkSession,inc_day:String) = {

    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_arss.dm_alarm_detail_dtl_di
         |where
         |  inc_day='${inc_day}'
       """.stripMargin

    val frame = spark.sql(sql).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val rdd = SparkUtils.getRowToJson(frame,"MEM_DISK").repartition(20)

    frame.unpersist()

    logger.error("rdd的数据量为：" + rdd.count())
    rdd.take(2).foreach(println(_))

    rdd

  }




  def saveToRoadClassTable(spark:SparkSession,roadClassInfoRdd:RDD[JSONObject],inc_day:String)= {

    val saveTable ="dm_gis.insurance_risk_alert_roadclass_info"

    import spark.implicits._


    roadClassInfoRdd.map(x => {

      val id= x.getString("id")
      val imei= x.getString("imei")
      val alarm_id= x.getString("alarm_id")
      val ft_alarm_id= x.getString("ft_alarm_id")
      val car_no= x.getString("car_no")
      val zy_type= x.getString("zy_type")
      val alarm_time= x.getString("alarm_time")
      val alarm_name= x.getString("alarm_name")
      val alarm_name_sta= x.getString("alarm_name_sta")
      val ft_p_type= x.getString("ft_p_type")
      val ft_sub_type= x.getString("ft_sub_type")
      val p_type= x.getString("p_type")
      val sub_type= x.getString("sub_type")
      val p_type_r= x.getString("p_type_r")
      val sub_type_r= x.getString("sub_type_r")
      val r_flag= x.getString("r_flag")
      val tf_flag= x.getString("tf_flag")
      val warn_id= x.getString("warn_id")
      val create_time= x.getString("create_time")
      val speed= x.getString("speed")
      val lng= x.getString("lng")
      val lat= x.getString("lat")


      val lng_i= x.getString("lng_i")
      val lat_i= x.getString("lat_i")
      val uid= x.getString("uid")
      val dir= x.getString("dir")
      val distance= x.getString("distance")
      val name= x.getString("name")
      val road_class= x.getString("road_class")
      val adcode= x.getString("adcode")

      geoInfoTable(id,imei,alarm_id,ft_alarm_id,car_no,zy_type,alarm_time,alarm_name,alarm_name_sta,ft_p_type,ft_sub_type,p_type,
        sub_type,p_type_r,sub_type_r,r_flag,tf_flag,warn_id,create_time,speed,lng,lat,lng_i,lat_i,uid,dir,distance,
        name,road_class,adcode,inc_day)

    }).repartition(100).toDF().write.mode(SaveMode.Overwrite).insertInto(saveTable)



  }

  def saveToDailyTable(spark:SparkSession,inc_day:String,calResRdd:RDD[Row]) = {

    val saveTable ="dm_gis.insurance_risk_alert_daily"

    import spark.implicits._

    calResRdd.map(x => {
      val imei = x.getString(0)
      val car_no = x.getString(1)
      val zy_type = x.getString(2)
      val alarm_name_sta = x.getString(3)
      val alarm_sum_cnt = x.getString(4)
      val alarm_night_cnt = x.getString(5)
      val alarm_before_dawn_cnt = x.getString(6)
      val alarm_early_morning_cnt = x.getString(7)
      val alarm_afternoon_cnt = x.getString(8)
      val alarm_dusk_cnt = x.getString(9)
      val alarm_high_speed_cnt = x.getString(10)
      val alarm_state_road_cnt = x.getString(11)
      val alarm_provincial_cnt = x.getString(12)
      val alarm_county_speed_cnt = x.getString(13)
      val alarm_township_cnt = x.getString(14)
      val med_risk_cnt = x.getString(15)
      val high_risk_cnt = x.getString(16)
      val average_speed = x.getString(17)

      daily(imei,car_no,zy_type,alarm_name_sta,alarm_sum_cnt,alarm_night_cnt,alarm_before_dawn_cnt,
        alarm_early_morning_cnt,alarm_afternoon_cnt,alarm_dusk_cnt,alarm_high_speed_cnt,alarm_state_road_cnt,
        alarm_provincial_cnt,alarm_county_speed_cnt,alarm_township_cnt,med_risk_cnt,high_risk_cnt,average_speed,inc_day)
    })
//        .toDF().repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter","\t").csv("d:\\user\\01401062\\桌面\\20220919_1.csv")
      .repartition(100).toDF().write.mode(SaveMode.Overwrite).insertInto(saveTable)



  }




  def startSta(spark: SparkSession,inc_day:String) = {

    // 获取告警维度数据
    val getSoucreRdd = getSourceData(spark,inc_day)

    // 调用临近道路查询接口信息
    val roadClassInfoRdd = getRoadClassInfo(getSoucreRdd)

    saveToRoadClassTable(spark,roadClassInfoRdd,inc_day)

    // 计算告警风险级别与统计日志
    val calResRdd = getRiskStatic(spark,inc_day)

    // 存储hive
    saveToDailyTable(spark,inc_day,calResRdd)

  }



  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
//    val inc_day = "20220901"

    //    val spark = SparkUtils.getSparkSession(appName,"local[*]")
    val spark = SparkSession
      .builder()
      .appName(appName)
//      .master("local[*]")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()


    spark.sparkContext.setLogLevel("ERROR")


    val dataList = DateTimeUtil.getDateInterval("20220803","20220919","yyyyMMdd","yyyyMMdd").reverse

    for (incDay <- dataList){

        logger.error("当前日期为：" + incDay)

        startSta(spark,incDay)

        logger.error(incDay + " " +  "计算完成")

        spark.sqlContext.clearCache()

        val ds: collection.Map[Int, RDD[_]] = spark.sparkContext.getPersistentRDDs
        ds.foreach(x => {
          x._2.unpersist()
        })

    }


    logger.error("统计结束")

  }




}
