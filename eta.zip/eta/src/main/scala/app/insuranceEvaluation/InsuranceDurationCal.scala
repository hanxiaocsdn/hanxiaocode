package app.insuranceEvaluation

import Utils.{DateTimeUtil, JSONUtils, SparkUtils}
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/5/13
*/


object InsuranceDurationCal {

  @transient lazy val logger: Logger = Logger.getLogger(InsuranceDurationCal.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  case class res(un:String,driveduration:Int,night_duration:Int,before_dawn_duration:Int,early_morning_duration:Int,afternoon_durationt:Int,dusk_duration:Int,overDirveAll:Int,inc_day:String)



  def getSourceData(spark: SparkSession,inc_day:String) = {


    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.safe_operation_data_quality_duration
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val frame = spark.sql(sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
////    frame.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv("/user/01401062/upload/gis/data/20220516.csv")
//    val rdd = SparkUtils.getRowToJson(frame,"MEM_DISK")

//    val frame = spark.read.format("csv").option("header", "true").option("delimiter","\t").load("d:\\user\\01401062\\桌面\\0519_1.csv")
//    val frame = spark.read.format("csv").option("header", "true").option("delimiter","\t").load("d:\\user\\01401062\\桌面\\test0519.csv")

    val rdd = SparkUtils.getRowToJson(frame,"MEM_DISK")
    frame.unpersist()

    logger.error("rdd的数据量为：" + rdd.count())
    rdd.take(2).foreach(println(_))

    rdd

  }

  def concatTimestamp(inc_day: String, start_period: String) = {

    val stamp = DateTimeUtil.getIncDayToTimeStamp(inc_day,start_period)

    stamp

  }

  def getRiskLevel(getSourceRdd: RDD[JSONObject]) = {

    val riskLevelRdd = getSourceRdd.repartition(200)
      .map(x => {
        val un = x.getString("un")
        val inc_day = x.getString("inc_day")
        val driveduration = JSONUtils.getJsonValueInt(x,"driveduration",0)

//        var (night_duration,before_dawn_duration,early_morning_duration,afternoon_durationt,dusk_duration) = (0,0,0,0,0)

        val resMap = new java.util.HashMap[String,Int]()
        resMap.put("night_duration",0)
        resMap.put("before_dawn_duration",0)
        resMap.put("early_morning_duration",0)
        resMap.put("afternoon_durationt",0)
        resMap.put("dusk_duration",0)


        val durtaionString = x.getString("durationarray")
        val durationArray = JSON.parseArray(durtaionString)
        // TODO:
        val timeArray = List(("night_duration",("21:00:00","23:00:00")),("before_dawn_duration",("00:00:00","03:00:00")),
          ("early_morning_duration",("07:00:00","09:00:00")),("afternoon_durationt",("13:00:00","15:00:00")),("dusk_duration",("17:00:00","19:00:00")))

        for (j <- (0 until(timeArray.size))){

          val typeTag = timeArray(j)._1
          val (start_period_pre,end_period_pre) = timeArray(j)._2

          val start_period = concatTimestamp(inc_day,start_period_pre)
          val end_period = concatTimestamp(inc_day,end_period_pre)

          var duration = 0

          for (i <- (0 until(durationArray.size()))){

            val start_duration = durationArray.getJSONArray(i).getIntValue(0)
            val end_duration = durationArray.getJSONArray(i).getIntValue(1)

            if (start_duration >= start_period && start_duration <= end_period) {
              // TODO: 截取相应时间
              if (end_duration <= end_period){
                  duration += (end_duration - start_duration)
              }else{
                  duration += (end_period - start_duration)
              }
            }
          }
          resMap.put(typeTag,resMap.get(typeTag) + duration)
        }


        // TODO: 判断超时驾驶时长
        // ①休息时间<15min，连续驾驶合并②计算夜间时长③根据公式进行计算
        // 判断间隔是否超过15min

        // ①连续驾驶合并
        val mergeDuration = new JSONArray()

        var start_tag = try {durationArray.getJSONArray(0).getIntValue(0)} catch {case e:Exception => 0}
        var end_tag = try {durationArray.getJSONArray(0).getIntValue(1)} catch {case e:Exception => 0}

        for (i <- (0 until(durationArray.size() -1))){

          val end_timstamp_pre = durationArray.getJSONArray(i).getIntValue(1)
          val start_timstamp_cur = durationArray.getJSONArray(i + 1).getIntValue(0)
          val end_timstamp_cur = durationArray.getJSONArray(i + 1).getIntValue(1)

          if (start_timstamp_cur - end_timstamp_pre <= 900) {
            end_tag = end_timstamp_cur
              //边界判断
            if (i == durationArray.size() -2){
              val jsonArray = new JSONArray()
              jsonArray.add(start_tag)
              jsonArray.add(end_tag)
              mergeDuration.add(jsonArray)
            }
          }  else {
            // 将合并后的区间添加到新数组中
            val jsonArray = new JSONArray()
            jsonArray.add(start_tag)
            jsonArray.add(end_tag)
            mergeDuration.add(jsonArray)

            start_tag = start_timstamp_cur
            end_tag = end_timstamp_cur

            //边界判断
            if (i == durationArray.size() -2){
              val jsonArray = new JSONArray()
              jsonArray.add(start_tag)
              jsonArray.add(end_tag)
              mergeDuration.add(jsonArray)
            }
          }
        }

        var overDirveAll = 0

        //②计算夜间时长, 计算合并后每段夜间时长和总驾驶时长
        for (i <- (0 until(mergeDuration.size()))){

          val start_duration = mergeDuration.getJSONArray(i).getIntValue(0)
          val end_duration = mergeDuration.getJSONArray(i).getIntValue(1)
          val all_duration = end_duration - start_duration
          var night_duration_06 = 0

          val start_period = concatTimestamp(inc_day,"00:00:00")
          val end_period = concatTimestamp(inc_day,"06:00:00")


          if (start_duration >= start_period && start_duration <= end_period) {
            // TODO: 截取相应时间
            if (end_duration <= end_period){
              night_duration_06 += (end_duration - start_duration)
            }else{
              night_duration_06 += (end_period - start_duration)
            }
          }
          var over_drive_duration = 0


          //  假设同一段连续驾驶，其在夜间的行驶时长是X，总行驶时长是Y，超时驾驶时长为C
          //  4h = 14400s
          //  1）X ≥4，C = Y-2；
          //  2）2≤ X ＜4，C = max(X-2,Y-4)；
          //  3）X <2，C = Y-4
          //  如果不跨天计算，只用考虑0~6点为夜间

          if (night_duration_06 >= 14400) {
            over_drive_duration = all_duration - 7200
          } else if (night_duration_06 >= 7200 && night_duration_06 < 14400){
            over_drive_duration = Math.max(night_duration_06 -7200 ,all_duration -14400)
          } else if (night_duration_06 <= 7200 && all_duration - 14400 > 0) {
            over_drive_duration = all_duration - 14400
          } else {
            over_drive_duration = 0
          }

          overDirveAll += over_drive_duration

        }


//        var (night_duration,before_dawn_duration,early_morning_duration,afternoon_durationt,dusk_duration) = (0,0,0,0,0)

        val night_duration = resMap.get("night_duration")
        val before_dawn_duration = resMap.get("before_dawn_duration")
        val early_morning_duration = resMap.get("early_morning_duration")
        val afternoon_durationt = resMap.get("afternoon_durationt")
        val dusk_duration = resMap.get("dusk_duration")

        res(un,driveduration,night_duration,before_dawn_duration,early_morning_duration,afternoon_durationt,dusk_duration,overDirveAll,inc_day)

      }).persist(StorageLevel.MEMORY_AND_DISK_SER)

      logger.error("riskLevelRdd的数据量为：" + riskLevelRdd.count())
      riskLevelRdd.take(2).foreach(println(_))
      riskLevelRdd
  }







  def saveToHive(spark: SparkSession, calResRdd: RDD[InsuranceDurationCal.res]) = {

    val saveTableName = "dm_gis.insurance_risk_level_evaluate"

    import spark.implicits._

    calResRdd.repartition(100).toDF().write.mode(SaveMode.Overwrite).insertInto(saveTableName)
//    calResRdd.toDF().repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter","\t").csv("d:\\user\\01401062\\桌面\\test0520.csv")

  }

  def startSta(spark: SparkSession,inc_day:String) = {


    // 获取告警维度数据
    val getSoucreRdd = getSourceData(spark,inc_day)

    // 计算告警风险级别
    val calResRdd = getRiskLevel(getSoucreRdd)

    // 存储hive
    saveToHive(spark,calResRdd)

  }


  def main(args: Array[String]): Unit = {

    val inc_day = args(0)

    val spark = SparkSession
      .builder()
      .appName(appName)
//      .master("local[*]")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    startSta(spark,inc_day)
    logger.error("统计结束")
    spark.stop()
  }






}
