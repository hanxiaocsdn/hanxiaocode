package app.insuranceEvaluation

import Utils.CommonTools.{GetDFCountAndSampleData, df2HiveByOverwrite, getBetweenDates, row2Json}
import com.alibaba.fastjson.JSONObject
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions.collect_list
import org.slf4j.{Logger, LoggerFactory}

object GetCarTrackDetail {

    def main(args: Array[String]): Unit = {
        // 初始化
        val className: String = this.getClass.getSimpleName.stripSuffix("$")
        val logger: Logger = LoggerFactory.getLogger(className)

        if (args.length != 3) {
            logger.error(
                """
                  |需要输入3个参数：
                  |    inc_day、path
                  |""".stripMargin)
            sys.exit(-1)
        }

        // 接收外部传递进来的变量
        val start_time: String = args(0)
        val end_time: String = args(1)
        val path: String = args(2)
        logger.error(s"开始日期：$start_time 结束日期：$end_time")
        logger.error(s"车辆信息路径：$path")

        // 创建spark

        val spark = SparkSession
          .builder()
          .appName(className)
          .master("yarn")
          .enableHiveSupport()
          .config("hive.exec.dynamic.partition",true)
          .config("hive.exec.dynamic.partition.mode","nonstrict")
          .getOrCreate()
        spark.sparkContext.setLogLevel("ERROR")

//        val spark: SparkSession = SparkConfigUtil.initSparkConfig(appName)

        // 获取车辆信息
        val carDF: DataFrame = getCarInfo(logger, spark, path)

        val dateList: List[String] = getBetweenDates(start_time, end_time)
        var i: Int = 1
        for (d <- dateList) {
            val inc_day:String=d.replaceAll("-","")
            logger.error(s"第${i}次循环：inc_day=$inc_day")
            // 获取车辆轨迹明细
            getCarTrackDetail(logger, spark, inc_day, carDF)
            i = i + 1
        }


        logger.error("运行结束！")

        // 程序运行结束,关闭spark
        spark.stop()

    }

    // 获取车牌信息
    def getCarInfo(logger: Logger, spark: SparkSession, path: String): DataFrame = {
        // 获取csv文件数据
        val csvDF: DataFrame = spark
          .read
          .format("csv")
          .option("header", "true")
          .load(path)
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, csvDF, "车牌数据")

        csvDF
    }

    // 获取车辆轨迹明细
    def getCarTrackDetail(logger: Logger, spark: SparkSession, inc_day: String, carDF: DataFrame): Unit = {
        import spark.implicits._

        // 车辆轨迹
        val sql: String =
            s"""
               |select
               |  un,
               |  ak,
               |  zx,
               |  zy,
               |  sp,
               |  tm,
               |  dx,
               |  dy,
               |  state,
               |  xh,
               |  id,
               |  tp,
               |  ac,
               |  ad,
               |  be,
               |  sl,
               |  sc,
               |  cr,
               |  inc_day
               |from
               |  dm_gis.esg_gis_loc_trajectory
               |where
               |  inc_day ='$inc_day'
               |""".stripMargin
        logger.error(sql)

        val trackDF: DataFrame = spark.sql(sql)
          .map(r => {
              val un: String = r.getAs[String]("un")
              val inc_day: String = r.getAs[String]("inc_day")
              val o: JSONObject = row2Json(r)
              if (!o.toJSONString.contains(" ,;{}()\\n\\t=")) (inc_day, un, o.toJSONString) else (inc_day, un, "")
          })
          .toDF("inc_day", "un", "json")

        val carTrackDetailDF: DataFrame = carDF
          .join(trackDF, Seq("un"))
          .groupBy("inc_day", "un")
          .agg(collect_list("json").alias("track_info"))
          .withColumn("incday", $"inc_day")
          .drop("inc_day")
          .withColumnRenamed("incday", "inc_day")
          .persist(StorageLevel.MEMORY_AND_DISK)

        GetDFCountAndSampleData(logger, carTrackDetailDF, "车辆轨迹明细")

//        df2HiveByOverwrite(logger, carTrackDetailDF, "dm_gis.mms_car_track_detail")
        df2HiveByOverwrite(logger, carTrackDetailDF, "dm_gis.mms_car_track_detail_0513")

        carTrackDetailDF.unpersist()
    }

}
