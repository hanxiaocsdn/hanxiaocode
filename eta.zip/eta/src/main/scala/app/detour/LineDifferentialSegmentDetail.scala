package app.detour

import Utils.SparkUtils.writeToHive
import app.detour.RaoXingProcess.runRaoXingProcess
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * GIS-RSS-ETA：【时效专项】 挽救线路指标线上化_V1.0 绕行工艺部分
 * 需求方：左佳怡(01403789)
 * @author 徐游飞（01417347）
 * 任务ID：764226
 * 任务名称：挽救线路绕路指标线上化_绕行工艺部分
 */

object LineDifferentialSegmentDetail {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  // 获取hive源数据
  def getDataSource(spark: SparkSession, dayBefore2: String, data_source: String, type_flag: String,coords_flag: String) = {
    import spark.implicits._

    val info_sql =
      s"""
         |select
         |  concat_ws('_',task_subid,pick_up_tm) as groupby_id,
         |  $coords_flag as coords,
         |  actual_depart_tm as start_tm,
         |  '$data_source' as data_source,
         |  '$type_flag' as type,
         |  inc_day
         |from
         |  dm_gis.xianlu_information
         |where
         |  inc_day = '$dayBefore2'
         |""".stripMargin

    println(info_sql)
    val df_info = spark.sql(info_sql)
      .withColumn("uid",concat_ws("_",'groupby_id,'data_source))
      .withColumn("coords",concat(lit("[["),regexp_replace('coords,"\\|","],["),lit("]]")))
      .persist(StorageLevel.MEMORY_AND_DISK)

    df_info
  }

  def runLineDifferentialSegment(spark: SparkSession, dayBefore2: String) = {
    import spark.implicits._

    // 获取hive源数据
    val df1 = getDataSource(spark, dayBefore2, "ls", "1", "his_coords")
    val df2 = getDataSource(spark, dayBefore2, "gh", "1000", "plan_coords")
    val df3 = getDataSource(spark, dayBefore2, "wj", "1000", "replan_coords")

    // 历史线路和规划线路跑绕行工艺逻辑
    val (first_union_multi_resultDF, first_union_ratio_resultDF) = runRaoXingProcess(spark, df1, df2, "forecast")
    // 历史线路和挽救线路跑绕行工艺逻辑
    val (second_union_multi_resultDF, second_union_ratio_resultDF) = runRaoXingProcess(spark, df1, df3, "save")

    // 预测线路差异段分组表 和 挽救线路差异段分组表 合并
    import spark.implicits._
    val df_line_union = first_union_ratio_resultDF.unionAll(second_union_ratio_resultDF)
      // 自身比较附上默认值
      .withColumn("standard_id", when('data_source === "ls", 'uid).otherwise('standard_id))
      .withColumn("different_num", when('data_source === "ls", 0).otherwise('different_num))
      .withColumn("different_dist", when('data_source === "ls", 0).otherwise('different_dist))
      .withColumn("different_real_dist", when('data_source === "ls", 0).otherwise('different_real_dist))
      .withColumn("different_basic_dist", when('data_source === "ls", 0).otherwise('different_basic_dist))
      .withColumn("different_add_dist", when('data_source === "ls", 0).otherwise('different_add_dist))
      .withColumn("different_dist_ratio", when('data_source === "ls", 1).otherwise('different_dist_ratio))
      .withColumn("different_compare_dist_ratio", when('data_source === "ls", 1).otherwise('different_compare_dist_ratio))
      .withColumn("different_weighted_compare_dist_ratio", when('data_source === "ls", 1).otherwise('different_weighted_compare_dist_ratio))

    // 线路差异段分组表 保存至hive
    val cols_union = spark.sql("""select * from dm_gis.line_union limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_line_union.select(cols_union: _*), Seq("inc_day"), "dm_gis.line_union")

    // 预测线路差异段明细表 和 挽救线路差异段明细表 合并
    val df_line_multi = first_union_multi_resultDF.unionAll(second_union_multi_resultDF)
      .withColumn("different_dist_standard_line", 'different_dist / 'different_compare_dist_ratio)
    // 线路差异段明细表 保存至hive
    val cols_multi = spark.sql("""select * from dm_gis.line_multi limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_line_multi.select(cols_multi: _*), Seq("inc_day"), "dm_gis.line_multi")

    // 计算线路绕路比值
    val df_ratio_bypass = df_line_multi
      .filter('different_compare_dist_ratio =!= "9999999" and 'different_compare_dist_ratio =!= "0")
      .groupBy("uid", "source")
      .agg(
        sum('different_dist_standard_line) as "different_dist_standard_line",
        sum('different_dist) as "different_dist"
      )
      .withColumn("ratio_bypass", 'different_dist / 'different_dist_standard_line)
      .filter('different_dist_standard_line > 2000) // 仅保留 t_基准线路差异段里程 大于2000的数据
      .withColumn("inc_day", lit(dayBefore2))
    // 线路绕路比值表 保存至hive
    val cols_bypass = spark.sql("""select * from dm_gis.ratio_bypass limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_ratio_bypass.select(cols_bypass: _*), Seq("inc_day"), "dm_gis.ratio_bypass")

  }

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，以业务时间为基准前1天和前3天
    val incDay = args(0)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)

    //日期检查
    logger.error("incDay="+incDay)
    logger.error("dayBefore2="+dayBefore2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016  ++++")
    // 2.绕路计算
    runLineDifferentialSegment(spark,dayBefore2)

    logger.error("++++++++  任务结束 20231021 ++++")

    spark.stop()
  }
}

