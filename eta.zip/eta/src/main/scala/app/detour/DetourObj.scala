package app.detour

object DetourObj {
  case class RoudePathInfo(
                            uid: String,
                            groupby_id: String,
                            my_type: String,
                            t_status: String,
                            t_links_union: String,
                            t_distance: Int,
                            t_duration: Double,
                            t_highspeed_distance: Int,
                            t_trafficlight_count: Int,
                            t_coords_xy: String,
                            t_coords_xy_swid: String,
                            t_linkPointInfo: String,
                            t_origin: String,
                            t_destination: String,
                            t_flen: String,
                            t_tlen: String,
                            inc_day: String
                          )

  case class UnionMulti(
                         uid: String,
                         different_route_id: Int,
                         different_num: Int,
                         standard_id: String,
                         different_start_swid: String,
                         different_start_poi: String,
                         different_end_poi: String,
                         different_end_swid: String,
                         different_start_dist: Double,
                         different_end_dist: Double,
                         different_dist: Double,
                         different_basic_dist: Double,
                         different_add_dist: Double,
                         different_real_dist: Double,
                         different_dist_ratio: Double,
                         different_start_line_dist: Double,
                         different_end_line_dist: Double,
                         different_compare_dist_ratio: Double,
                         different_weighted_compare_dist_ratio: Double,
                         stand_road_dist: Double,
                         stand_add_dist: Double,
                         noStandard_t_distance: Double,
                         inc_day: String
                       )

  case class UnionRatio(
                         uid: String,
                         standard_id: String,
                         different_num: Int,
                         different_dist: Double,
                         different_basic_dist: Double,
                         different_add_dist: Double,
                         different_real_dist: Double,
                         different_dist_ratio: Double,
                         different_compare_dist_ratio: Double,
                         different_weighted_compare_dist_ratio: Double
                       )

  case class ReplanLine(
                         uid: String,
                         source: String,
                         route_id: String,
                         replan_route_id: String,
                         jp_swid: String,
                         jp_time: String,
                         jp_coords: String,
                         jp_status: String,
                         sum_dist: String,
                         code_statue2: String,
                         his_tracks: String,
                         roadclass: String,
                         link_length: String,
                         plan_coords: String,
                         his_coords: String,
                         replan_coords: String,
                         his_dist: String,
                         his_time: String,
                         replan_time: String,
                         line_coords: String,
                         replan_line_coords: String,
                         msg: String
                       )

}
