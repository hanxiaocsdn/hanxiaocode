package app.detour

import Utils.CommonTools.row2Json
import Utils.SparkUtils.writeToHive
import Utils.StringUtils
import app.detour.DetourObj.ReplanLine
import app.timeliness.GuiHuaXianLuZhiXingTable10.getDistance2
import app.timeliness.JiuPianFwqTable45.{runIntegrateInteface, runRectifyInteface}
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, SparkUtil}
import com.sf.gis.java.eta.constant.utils.HttpSetHeader
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.text.SimpleDateFormat
import scala.collection.mutable.ArrayBuffer

/**
 * GIS-RSS-ETA：【时效专项】 挽救线路指标线上化_V1.0 线路信息详情表部分
 * 需求方：左佳怡(01403789)
 * @author 徐游飞（01417347）
 * 任务ID：764225
 * 任务名称：挽救线路绕路指标线上化_线路信息详情表
 */

object XianLuInformation {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val Delay_URL: String = "http://gis-gw.int.sfdc.com.cn:9080/etawmp/api/queryLatestDelayInfo?uid=%s"
  val Delay_AK: String = ""

  val Integrate_URL: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
  val Integrate_AK: String = "87a1347bc3944718911a05c21ec888a9"

  val Rectify_URL: String = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val Rectify_AK: String = "87a1347bc3944718911a05c21ec888a9"

  val parallelism = 10
  val akMinuLimit = 1000

  /**
   * 解析RT匹配接口
   * @param ret
   * @return
   */
  def parseDelayData(ret: JSONObject) : (String,JSONObject) = {

    var t_status = "4040"
    val ret_obj = new JSONObject()
    if (ret != null ) {
      //获取接口返回状态
      t_status = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(t_status)) {
        logger.error("获取接口数据失败: " + ret.getJSONObject("result").getString("msg"))
        ret_obj.put("msg",ret.getJSONObject("result").getString("msg"))
        return (t_status,ret_obj)
      } else {

        try {
          val reqId = ret.getString("reqId")
          val result_obj = ret.getJSONObject("result")
          val lineCoords = result_obj.getString("lineCoords")
          val replanLineCoords = result_obj.getString("replanLineCoords")
          val routeId = result_obj.getString("routeId")
          val replanRouteId = result_obj.getString("replanRouteId")
          val replanArriveTime = result_obj.getLong("replanArriveTime")
          val pickUpTm = result_obj.getString("pickUpTm")

          val pick_up_time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(pickUpTm).getTime
          val replanTime = (replanArriveTime - pick_up_time) / 1000

          ret_obj.put("msg","成功")
          ret_obj.put("reqId",reqId)
          ret_obj.put("lineCoords",lineCoords)
          ret_obj.put("replanLineCoords",replanLineCoords)
          ret_obj.put("routeId",routeId)
          ret_obj.put("replanRouteId",replanRouteId)
          ret_obj.put("replanArriveTime",replanArriveTime)
          ret_obj.put("pickUpTm",pickUpTm)
          ret_obj.put("replanTime",replanTime)

        } catch {
          case _ =>
        }

        return (t_status,ret_obj)
      }
    }
    ret_obj.put("msg","接口返回为空")
    (t_status,ret_obj)
  }

  // 查询任务最新晚点信息接口
  def runDelayInteface3(ak:String, obj: JSONObject): JSONObject = {

    // 调查询任务最新晚点信息接口
    val uid = JSONUtil.getJsonVal(obj, "uid", "")
    var retJSONObject_1 = new JSONObject()
    try {
      val urls = String.format(Delay_URL,URLEncoder.encode(uid,"utf-8"))
      val retStr: String = HttpSetHeader.sendGet(urls, "UTF-8", 3)
      retJSONObject_1 = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData =  parseDelayData(retJSONObject_1)
    val delay_obj = httpData._2
    obj.put("delay_obj",delay_obj)
    // 测试用字段
    obj.put("status",httpData._1)

    // 调用调历史轨迹接口和纠偏接口
    val his_tracks_obj = runIntegrateInteface(Integrate_AK, obj)

    his_tracks_obj
  }

  def getUrl(spark: SparkSession,df_replan_id: DataFrame,incDay: String,dayBefore7: String,subType: String) = {
    import spark.implicits._

    var routeId_navi = "''"
    var routeId_eta = "''"
    if(subType.equals("queryLocationEta")){
      routeId_navi = df_replan_id.filter('source === "navi" && 'route_id.isNotNull).select("route_id").distinct()
        .map("'" + _ + "'").collect().mkString(",")
        .replaceAll("\\[|\\]", "")
        .replaceAll(",''",",'")
        .replaceAll(",',",",")
      routeId_eta = df_replan_id.filter('source === "eta" && 'route_id.isNotNull).select("route_id").distinct()
        .map("'" + _ + "'").collect().mkString(",")
        .replaceAll("\\[|\\]", "")
        .replaceAll(",''",",'")
        .replaceAll(",',",",")
    }else if(subType.equals("queryByFuse")){
      routeId_navi = df_replan_id.filter('source === "navi" && 'route_id.isNotNull).select("replan_route_id").distinct()
        .map("'" + _ + "'").collect().mkString(",")
        .replaceAll("\\[|\\]", "")
        .replaceAll(",''",",'")
        .replaceAll(",',",",")
      routeId_eta = df_replan_id.filter('source === "eta" && 'route_id.isNotNull).select("replan_route_id").distinct()
        .map("'" + _ + "'").collect().mkString(",")
        .replaceAll("\\[|\\]", "")
        .replaceAll(",''",",'")
        .replaceAll(",',",",")
    }

    val navi_sql =
      s"""
         |select
         |  t2.routeid as route_id,
         |  if(t1.ft_url is null, t3.ft_url, t1.ft_url) as url
         |from
         |  (
         |    select
         |      routeid,
         |      request_id,
         |      subtype
         |    from
         |      dm_gis.gis_navi_top3_yaw_result_parse
         |    where
         |      inc_day >= '$dayBefore7'
         |      and inc_day <= '$incDay'
         |      and routeid in ($routeId_navi)
         |  ) t2
         |  left join (
         |    select
         |      request_id,
         |      ft_url
         |    from
         |      dm_gis.gis_navi_top3_parse --top3入参表
         |    where
         |      inc_day >= '$dayBefore7'
         |      and inc_day <= '$incDay'
         |  ) t1 on t1.request_id = t2.request_id
         |  left join (
         |    select
         |      request_id,
         |      ft_url
         |    from
         |      dm_gis.gis_navi_yaw_parse --偏航入参表
         |    where
         |      inc_day >= '$dayBefore7'
         |      and inc_day <= '$incDay'
         |  ) t3 on t2.request_id = t3.request_id
         |""".stripMargin

    val eta_sql =
      s"""
         |select
         |  get_json_object(get_json_object(get_json_object(log, '$$.data'), '$$.result'),'$$.routeId') route_id,
         |  get_json_object(get_json_object(get_json_object(log, '$$.data'), '$$.result'),'$$.rpFuseUrl') url
         |from
         |  dm_gis.gis_eta_query_log
         |where
         |  inc_day >= '$dayBefore7'
         |  and inc_day <= '$incDay'
         |  and get_json_object(log, '$$.subType') = '$subType'
         |  and get_json_object(log, '$$.type') = 'etaQuery'
         |  and get_json_object(get_json_object(get_json_object(log, '$$.data'), '$$.result'),'$$.routeId') in ($routeId_eta)
         |""".stripMargin

    val df_url = spark.sql(navi_sql)
      .union(spark.sql(eta_sql))
      .withColumn("rn", row_number().over(Window.partitionBy("route_id","url").orderBy(desc("url"))))
      .filter('rn === 1)
      .drop("rn")

    df_url
  }

  // 循环计算pick_up_point与轨迹串的每一个点的距离，取距离最小的点索引
  def getMinDistanceCoordsIndex(pick_up_point: String, coords: String) = {
    var index = 0
    var x1 = 0.0
    var y1 = 0.0
    var dist_min = Double.MaxValue
    try {
      x1 = pick_up_point.split(",")(0).toDouble
      y1 = pick_up_point.split(",")(1).toDouble
    } catch {
      case e: Exception => logger.error(e)
    }

    val coords_arr = coords.split("\\|")
    // 获取距离最小的点索引 index
    for(i <- 0 until coords_arr.length){
      val coords_i = coords_arr(i)
      var x2 = 0.0
      var y2 = 0.0
      try {
        x2 = coords_i.split(",")(0).toDouble
        y2 = coords_i.split(",")(1).toDouble
      } catch {
        case e: Exception => logger.error(e)
      }
      val dist = getDistance2(x1, y1, x2, y2)
      if(dist_min > dist &&  dist != 0.0) {
        dist_min = dist
        index = i
      }
    }

    // 获取距离最小的点索引 index 之后的所有轨迹点
    val new_coords_arr = new ArrayBuffer[String]()
    for(i <- index until coords_arr.length){
      new_coords_arr.append(coords_arr(i))
    }
    val new_coords = new_coords_arr.mkString("|")

    (index,new_coords)
  }

  def getStdId(spark: SparkSession, df_replan_id: DataFrame, incDay: String, dayBefore2: String) = {
    import spark.implicits._

    var uid_str = "''"
    uid_str = df_replan_id.filter(StringUtils.isEmptyOrNull('route_id)).select("uid").distinct()
        .map("'" + _ + "'").collect().mkString(",")
        .replaceAll("\\[|\\]", "")
        .replaceAll(",''",",'")
        .replaceAll(",',",",")

    val stdId_sql =
      s"""
         |select
         |  get_json_object(log, '$$.reqId') as uid,
         |  get_json_object(get_json_object(get_json_object(log, '$$.data'), '$$.result'),'$$.stdId') as std_id
         |from
         |  dm_gis.gis_eta_query_log
         |where
         |  inc_day >= '$dayBefore2'
         |  and inc_day <= '$incDay'
         |  and get_json_object(log, '$$.subType') = 'queryByFuse'
         |  and get_json_object(log, '$$.type') = 'etaQuery'
         |  and get_json_object(log, '$$.reqId') in ($uid_str)
         |""".stripMargin

    println(stdId_sql)

    val df_std_id = spark.sql(stdId_sql)
      .withColumn("rn", row_number().over(Window.partitionBy("uid","std_id").orderBy(desc("std_id"))))
      .filter('rn === 1)
      .drop("rn")

    df_std_id
  }

  def runXianLuInformation(spark: SparkSession, incDay: String, dayBefore2: String, dayBefore7:String) = {
    import spark.implicits._

    val df_request = spark.sql(
      s"""
         |select
         |  *
         |from
         |  dm_gis.kafka_recall_request_detail
         |where
         |  inc_day = '$dayBefore2'
         |  and `order` = 0
         |  and solution = '重新规划线路'
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK)

    val invokeCnt = df_request.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "764225", "挽救线路绕路指标线上化_线路信息详情表", "查询任务最新晚点信息", Delay_URL, Delay_AK, invokeCnt, parallelism)
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "764225", "挽救线路绕路指标线上化_线路信息详情表", "获取历史轨迹", Integrate_URL, Integrate_AK, invokeCnt, parallelism)
    val httpInvokeId_3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "764225", "挽救线路绕路指标线上化_线路信息详情表", "轨迹纠偏", Rectify_URL, Rectify_AK, invokeCnt, parallelism)
    // 查询任务最新晚点信息接口
    val rdd_replan = SparkNet.runInterfaceWithAkLimit(spark, df_request.rdd.map(row2Json), runDelayInteface3, parallelism, "", akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_3)

    val df_replan_id = rdd_replan.map(obj=>{
      val uid = JSONUtil.getJsonVal(obj, "uid", "")
      val source = JSONUtil.getJsonVal(obj, "source", "")
      val pick_up_point = JSONUtil.getJsonVal(obj, "pick_up_point", "")


      val delay_obj = JSONUtil.getJsonObjectMulti(obj, "delay_obj")
      val route_id = JSONUtil.getJsonVal(delay_obj, "routeId", "")
      val replan_route_id = JSONUtil.getJsonVal(delay_obj, "replanRouteId", "")
      val line_coords = JSONUtil.getJsonVal(delay_obj, "lineCoords", "")
      val replan_line_coords = JSONUtil.getJsonVal(delay_obj, "replanLineCoords", "")
      val replan_time = JSONUtil.getJsonVal(delay_obj, "replanTime", "")

      val msg = JSONUtil.getJsonVal(delay_obj, "msg", "")

      val his_tracks = JSONUtil.getJsonVal(obj, "his_tracks", "")
      val jp_swid = JSONUtil.getJsonVal(obj, "jp_swid", "")
      val jp_time = JSONUtil.getJsonVal(obj, "jp_time", "")
      val jp_coords = JSONUtil.getJsonVal(obj, "jp_coords", "")
      val jp_status = JSONUtil.getJsonVal(obj, "jp_status", "")
      val sum_dist = JSONUtil.getJsonVal(obj, "sum_dist", "")
      val code_statue2 = JSONUtil.getJsonVal(obj, "code_statue2", "")
      val roadclass = JSONUtil.getJsonVal(obj, "roadclass", "")
      val link_length = JSONUtil.getJsonVal(obj, "link_length", "")

      // 循环计算pick_up_point与轨迹串的每一个点的距离，取距离最小的点索引
      val index1_coords = getMinDistanceCoordsIndex(pick_up_point,line_coords)
      val index2_coords = getMinDistanceCoordsIndex(pick_up_point,jp_coords)
      val index3_coords = getMinDistanceCoordsIndex(pick_up_point,replan_line_coords)

      val plan_coords = index1_coords._2
      val his_coords = index2_coords._2
      val replan_coords = index3_coords._2

      val index2 = index2_coords._1
      val sum_dist_arr = sum_dist.split("\\|")
      val jp_time_arr = jp_time.split("\\|")

      var his_dist = ""
      var his_time = ""
      try {
        his_dist = (sum_dist_arr(sum_dist_arr.length - 1).toDouble - sum_dist_arr(index2).toDouble).toString
        his_time = (jp_time_arr(jp_time_arr.length - 1).toDouble - jp_time_arr(index2).toDouble).toString
      } catch {
        case e: Exception => logger.error(e)
      }

      ReplanLine(uid,source,route_id,replan_route_id,jp_swid,jp_time,jp_coords,jp_status,sum_dist,code_statue2,his_tracks,roadclass,link_length,plan_coords,
        his_coords,replan_coords,his_dist,his_time,replan_time,line_coords,replan_line_coords,msg)
    }).toDF()
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 关联获取 url
    val df_url = getUrl(spark,df_replan_id,incDay,dayBefore7,"queryLocationEta")
    // 关联获取 replanUrl
    val df_replanUrl = getUrl(spark,df_replan_id,incDay,dayBefore7,"queryByFuse")
      .withColumnRenamed("route_id","replan_route_id")
      .withColumnRenamed("url","replan_url")
    // 关联获取 std_id
    val df_std_id = getStdId(spark,df_replan_id,incDay,dayBefore2)  // 异常确认： std_id字段全部为空

    // 数据关联
    val df_ret = df_request
      .join(df_replan_id.drop("source"),Seq("uid"),"left")
      .join(df_url,Seq("route_id"),"left")
      .join(df_replanUrl,Seq("replan_route_id"),"left")
      .join(df_std_id,Seq("uid"),"left")
      .withColumn("inc_day",lit(dayBefore2))

    val ret_cols = spark.sql("""select * from dm_gis.xianlu_information limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(ret_cols: _*),Seq("inc_day"),"dm_gis.xianlu_information")

    df_replan_id.unpersist()
    df_request.unpersist()
  }

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，以业务时间为基准前1天和前3天
    val incDay = args(0)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val dayBefore7 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 7)

    //日期检查
    logger.error("incDay="+incDay)
    logger.error("dayBefore2="+dayBefore2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016 ++++")
    // 时效晚点&时效挽救请求明细表--表1
    runXianLuInformation(spark,incDay,dayBefore2,dayBefore7)

    logger.error("++++++++  任务结束 20231016 ++++")

    spark.stop()
  }
}

