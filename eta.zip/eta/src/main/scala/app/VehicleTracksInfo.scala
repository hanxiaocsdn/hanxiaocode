package app

import Utils.CommonTools.row2Json
import Utils.SparkUtils.writeToHive
import Utils.StringUtils.timeToCustomTime
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer

/**
 * 需求内容：根据线下提供车参获取轨迹信息，（根据提供的线下车牌不定时跑数）
 * 需求方：曹倩倩（01425168）
 * @author 徐游飞（01417347）
 * 任务ID：925866
 * 任务名称：eta车辆轨迹获取
 */
object VehicleTracksInfo {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  val trackquery_url: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
  val trackquery_ak: String = "93ec117f7f1b4226b4e537c4802319e9"
  val parallelism = 10
  val akMinuLimit = 2000

  def execute(spark: SparkSession, inc_day: String) = {
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)

    import spark.implicits._
    // 获取线下车牌数据
    val rdd_vehicle = spark.read
      .format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/user/01417347/upload/data/tracks/track_param.csv")
//      .filter('vehicle_serial.contains("宁AL"))
      .rdd.map(row2Json)

    // 调标准线路查询接口
    val invokeCnt = rdd_vehicle.count()
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "925866", "eta车辆轨迹获取", "获取eta车辆轨迹", trackquery_url, trackquery_ak, invokeCnt, parallelism)
    val rdd_tracks = SparkNet.runInterfaceWithAkLimit(spark, rdd_vehicle, runTrackQueryInteface, parallelism, trackquery_ak, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId)

    val df_detail = rdd_tracks.map(obj=>{
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      var actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
      var actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
      val route_points = JSONUtil.getJsonVal(obj, "jy_track2", "")

      // 时间格式转换
      actual_depart_tm = timeToCustomTime(actual_depart_tm,"yyyyMMddHHmmss","yyyy-MM-dd HH:mm:ss")
      actual_arrive_tm = timeToCustomTime(actual_arrive_tm,"yyyyMMddHHmmss","yyyy-MM-dd HH:mm:ss")

      (vehicle_serial,actual_depart_tm,actual_arrive_tm,route_points)
    }).toDF("vehicle_serial","actual_depart_tm","actual_arrive_tm","route_points")
      .withColumn("inc_day",lit(dayBefore1))
      .coalesce(3)

    val cols = spark.sql("""select * from dm_gis.dm_vehicle_tracks_info_dtl_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_detail.select(cols: _*),Seq("inc_day"),"dm_gis.dm_vehicle_tracks_info_dtl_di")

  }

  def runTrackQueryInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
    val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("un", vehicle_serial)
    param.put("beginDateTime", actual_depart_tm)
    param.put("endDateTime", actual_arrive_tm)
    param.put("unType", "0")
    param.put("type", "400")
    param.put("ak", ak)
    param.put("compensate", "true")
    param.put("addpoint", 1)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(trackquery_url,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String) = parseTrackQueryHttpData(retJSONObject)
    val jy_track2 = httpData._3
    val codeStatue_1 = httpData._1
    val msg_1 = httpData._2

    obj.put("jy_track2",jy_track2)
    obj.put("codeStatue_1",codeStatue_1)
    obj.put("msg_1",msg_1)

    obj
  }

  // 解析轨迹查询接口返回值
  def parseTrackQueryHttpData(ret: JSONObject): (String, String, String) = {

    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取轨迹查询接口数据失败: " + msg)
        return (codeStatue, s"请求失败: $msg", null)
      } else {
        var history_path = new JSONArray()
        try{
          history_path = ret.getJSONObject("result").getJSONObject("data").getJSONArray("track")
        }catch {
          case e: Exception => logger.error(e)
        }

        val tracks_arr = new ArrayBuffer[String]()
        // 循环获取轨迹点
        for(i <- 0 until history_path.size()){
          val track = history_path.getJSONObject(i)
          val dx = track.getDouble("dx")
          val dy = track.getDouble("dy")
          val tm = track.getString("tm")

          tracks_arr.append(s"""$dx,$dy,$tm""")
        }
        val task_tracks = tracks_arr.mkString("|")

        return (codeStatue,"成功",task_tracks)
      }
    }
    ("22", "请求失败,接口返回值为空", null)

  }


  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error(s"++++++++  inc_day=$inc_day  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成 20231218  ++++")

    spark.stop()
  }

}
