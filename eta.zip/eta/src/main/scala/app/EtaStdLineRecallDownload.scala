package app

import com.sf.gis.java.base.util.{ShellExcutor, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * GIS-RSS-ETA：【eta导航】训练ETA模型数据导入ftp190
 * 需求方：王祎（01398517）
 * @author 徐游飞（01417347）
 * 任务ID：645447
 * 任务名称：ETA模型数据recall表下载
 */
object EtaStdLineRecallDownload {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    val inc_day = args(0)
    logger.error("inc_day="+ inc_day)

    // 需要下载的hive表
    val tableName2 = "eta_std_line_recall"
    SaveHiveTableAsTextFile2(spark,tableName2,inc_day)

    println("任务结束")
    spark.stop()
  }

  def SaveHiveTableAsTextFile2(spark: SparkSession, tableName: String, inc_day: String) = {

    //将数据保存为TextFile
    val hdfsPath = s"hdfs://sfbd/user/hive/warehouse/dm_gis/${tableName}_${inc_day}"
    val file = s"./${tableName}_${inc_day}.csv"

    ShellExcutor.exeCmd(s"hdfs dfs -rm -r $hdfsPath")
    val sql_seg =
      s"""
         |select
         |    task_area_code
         |    ,task_id
         |    ,sort_num
         |    ,task_subid
         |    ,task_inc_day	--任务日期
         |    ,concat(task_id,'_',start_dept,'_',end_dept) as group_task
         |    ,(unix_timestamp(actual_depart_tm, "yyyy-MM-dd HH:mm:ss") - unix_timestamp(plan_depart_tm, "yyyy-MM-dd HH:mm:ss")) as act_plan_depart_tm_diff --出发时间差
         |    ,cast((unix_timestamp(actual_arrive_tm, "yyyy-MM-dd HH:mm:ss") - unix_timestamp(actual_depart_tm, "yyyy-MM-dd HH:mm:ss"))/600 as INT) as eta_count --应判断次数
         |    ,start_dept	--始发网点
         |    ,end_dept	--目的网点
         |    ,start_type	--始发网点类型
         |    ,end_type	--目的网点类型
         |    ,line_code	--线路编码
         |    ,vehicle_serial	--车牌号码
         |    ,actual_capacity_load	--实际运力载量（指派的车辆吨位）
         |    ,plan_depart_tm	--计划发车时间
         |    ,actual_depart_tm	--实际发车时间
         |    ,plan_arrive_tm	--计划到车时间
         |    ,actual_arrive_tm	--实际到车时间
         |    ,driver_id	--司机ID
         |    ,driver_name	--司机姓名
         |    ,line_time	--计划运行时长(min)
         |    ,line_distance	--规划里程(km)
         |    ,actual_run_time	--实际运行时长(min)
         |    ,start_longitude	--起点经度
         |    ,start_latitude	--起点纬度
         |    ,end_longitude	--终点经度
         |    ,end_latitude	--终点纬度
         |    ,is_stop	--是否经停(1：直发2：经停3：多卸货口)
         |    ,transoport_level	--运输等级(1一级运输，2二级运输，3三级运输，4短驳)
         |    ,carrier_type	--承运商类型
         |    ,plf_flag	--是否平台车主
         |    ,vehicle_type	--车辆类型
         |    ,axls_number	--轴数
         |    ,log_dist	--码表里程
         |    --,rt_coords	--原始轨迹
         |    ,x1	--轨迹实际起点经度
         |    ,y1	--轨迹实际起点纬度
         |    ,x2	--轨迹实际终点经度
         |    ,y2	--轨迹实际终点纬度
         |    ,duration	--停留时长(s)
         |    ,time as act_time --实际行驶时间
         |    ,rt_dist	--任务实际里程(m)
         |    ,highwaymileage	--高速里程(m)
         |    ,toll_charge	--收费
         |    ,start_distance	--轨迹起点与起点网点距离(m)
         |    ,end_distance	--轨迹终点与终点网点距离(m)
         |    ,error_type	--轨迹异常类型
         |    ,pns_dist	--标准线路里程(m)
         |    ,pns_time	--标准线路时效(s)
         |    ,src	--标准线路来源
         |    --,std_coords	--标准线路轨迹点
         |    ,line_distance_std	--配置里程(m)
         |    ,line_time_std	--配置时长(s)
         |    ,sim1	--相似度1
         |    ,sim5	--相似度5
         |    ,diffdist_rt_line	--实际里程与规划里程偏差(m)
         |    ,diffratio_rt_line	--实际里程与规划里程偏差率
         |    ,diffdist_rt_std	--实际里程与标准线路里程偏差(m)
         |    ,diffratio_rt_std	--实际里程与标准线路里程偏差率
         |    ,diffdist_rt_log	--实际里程与码表里程偏差(m)
         |    ,diffratio_rt_log	--实际里程与码表里程偏差率
         |    ,diffdist_line_log	--规划里程与码表里程偏差(m)
         |    ,diffratio_line_log	--规划里程与码表里程偏差率
         |    ,diffdist_line_std	--规划里程与标准线路里程偏差(m)
         |    ,diffratio_line_std	--规划里程与标准线路里程偏差率
         |    ,diffdist_log_std	--码表里程与标准线路里程偏差(m)
         |    ,diffratio_log_std	--码表里程与标准线路里程偏差率
         |    ,conduct_type	--执行情况
         |    ,difftime_line_std	--规划时长与标准线路时长偏差(s)
         |    ,diffratio1_line_std	--规划时长与标准线路时长偏差率
         |    ,difftime_line_std_10min	--规划时长与标准线路时长偏差区间
         |    ,difftime_line_rt	--规划耗时与实际耗时(去停留)偏差
         |    ,diffratio1_line_rt	--规划耗时与实际耗时(去停留)偏差率
         |    ,difftime_rt_gh_10min	--规划耗时与实际耗时偏差区间
         |    ,is_run_ontime_std	--是否准点(去停留)_std
         |    ,is_run_ontime	--是否准点(去停留)
         |    ,if_dist_equal	--接口返回配置里程是否准确
         |    ,if_time_equal	--接口返回配置时长是否准确
         |    ,pns_error	--接口返回异常情况
         |    ,difftime_std_rt	--标准线路时长与实际耗时(去停留)偏差
         |    ,diffratio1_std_rt	--标准线路时长与实际耗时(去停留)偏差率
         |    ,difftime_std_rt_10min	--标准线路时长与实际耗时(去停留)偏差区间
         |    ,tl_time	--实际行驶时间(单位:s,去停留)
         |    ,halfway_integrate_rate	--轨迹完整率
         |    ,std_x1	--标准线路起点经度
         |    ,std_y1	--标准线路起点纬度
         |    ,std_x2	--标准线路终点经度
         |    ,std_y2	--标准线路终点纬度
         |    ,start_distance_std	--标准线路起点和实际起点的距离(m)
         |    ,end_distance_std	--标准线路终点和实际终点的距离(m)
         |    ,std_line_error	--标准线路与实际轨迹起终点匹配是否异常
         |    ,ac_difftime_line_rt	--规划耗时与实际耗时偏差(s)
         |    ,ac_diffratio1_line_rt	--规划耗时与实际耗时偏差率
         |    ,ac_difftime_rt_gh_10min	--规划耗时与实际耗时偏差区间
         |    ,ac_difftime_std_rt	--标准线路时长与实际耗时偏差(s)
         |    ,ac_diffratio1_std_rt	--标准线路时长与实际耗时偏差率
         |    ,ac_difftime_std_rt_10min	--标准线路时长与实际耗时偏差区间(s)
         |    ,ac_is_run_ontime_std	--是否准点_std
         |    ,ac_is_run_ontime	--是否准点
         |    ,if_evaluate_time	--任务是否考核时效
         |    ,carrier_name	--承运商名称
         |    ,stop_over_zone_code	--经停点
         |    ,biz_type	--业务类型
         |    ,require_category	--需求类别
         |    ,to_ground	--过滤条件,'1'
         |    ,std_toll_charge	--标准线路收费
         |    ,std_id	--标准线路id
         |    ,navi_strategy	--（导航）点选策略
         |    ,is_return_std_line	--（导航）是否有返回标准线路（0否 1是）
         |    ,is_navi_at_start	--是否起点导航（0否 1是）
         |    ,is_navi_by_std_line	--是否标准线路开始导航（0否 1是）
         |    ,route_time	--（导航）线路规划时长
         |    ,drive_time	--（导航）行驶时长
         |    ,is_yaw_by_driver	--（导航）是否有司机主动偏航（0否 1是）
         |    ,navi_complete_rate	--导航完成率
         |    ,accrual_dist	--计提里程
         |    ,accrual_dist_type	--计提里程类型
         |    ,last_update_tm	grd --任务数据更新时间戳
         |    ,main_driver_account	--司机工号
         |    ,road_fee	--日志路桥费
         |    ,is_navi --是否全程使用导航 1
         |from dm_gis.$tableName
         |where inc_day = '$inc_day'  --eta_recall_1128_1203.csv
         |and if_evaluate_time = 1
         |""".stripMargin

    println("取数sql为:" + sql_seg)
    println(s"$tableName 表数据开始保存至 $hdfsPath")
    val dataDF = spark.sql(sql_seg)
//      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    println(s" $inc_day 的数据量为："+dataDF.count())

    val unit = dataDF.repartition(1)
      .write
      .format("csv")
      .mode("overwrite")
      .option("header", "true")
      .option("sep","\t")
      .save(hdfsPath)
    println(s"$tableName 表数据已保存至： $hdfsPath")

//    println(s"$tableName 表数据开始合并下载至本地： $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -ls -h $hdfsPath")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -getmerge $hdfsPath $file")
//    println(s"$tableName 表数据下载完成")
//
//    println(s"$tableName 表开始压缩数据")
//    ShellExcutor.exeCmd(s"ls -l $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    ShellExcutor.exeCmd(s"tar czf $file.tgz $file")
//    println(s"$tableName 表数据压缩完成")
//
//    println(s"$tableName 表开始上传至ftp:10.116.49.190")
//    ShellExcutor.exeCmd(s"ls -l $file.tgz")
//    //ShellExcutor.exeCmd(s"curl ftp://devftp:brYsj2.023ftKjdev@ftp://gisftp.sf-express.com/$tableName/ -T $file.tgz")
//    //ShellExcutor.exeCmd(s"curl -u devftp:brYsj2.023ftKjdev -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/$tableName/")
//    ShellExcutor.exeCmd(s"curl -u ywftp:*fTKJ*.123yunwei -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/$tableName/")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    println(s"$tableName 表数据上传成功")
  }


}
