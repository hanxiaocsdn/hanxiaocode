package app.aoi

import Utils._

import java.util
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import entry.Obj.{AreaRcgShouObj, AreaWdRcgShouObj}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01374443 on 2019/3/5.
 * 遗留文件，迁移至sds中
  */
object AreaStaIndexShou {
  @transient lazy val logger: Logger = Logger.getLogger(AreaStaIndexShou.getClass)
  val statDay = 2
  val incDay: String = Util.dateDelta(-statDay, "")
  val incDaySep: String = Util.dateDelta(-statDay, "-")
  val city_code: Array[String] = Array()
  val logDays = 3
  val logDayMin: String = Util.dateDelta(-logDays - statDay + 1, "")
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val isDebug = true
  val javaUtil = new JavaUtil(6)
  var saveStep = 0

  def main(args: Array[String]): Unit = {
    start()
  }

  def filterValidRcgRdd(fvp54Rdd: RDD[(String, JSONObject)], logRdd: RDD[(String, JSONObject)],
                        ttRdd: RDD[(String, JSONObject)], invalidDept: util.HashSet[String]): RDD[JSONObject] = {
    logger.error("关联日志和订单表")
    val logTtRdd = logRdd.union(ttRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).filter(obj => {
      obj._2.containsKey("oms_body") && obj._2.containsKey("tt_body")
    }).map(obj => {
      val waybillno = obj._2.getJSONObject("tt_body").getString("waybill_no")
      (waybillno, obj._2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("关联日志和订单表后数量:" + logTtRdd.count())
    logRdd.unpersist()
    ttRdd.unpersist()
    logger.error("关联fvp54表")
    val joinFvp54Rdd = logTtRdd.leftOuterJoin(fvp54Rdd).map(obj => {
      val leftBody = obj._2._1
      val rightOption = obj._2._2
      if (rightOption.nonEmpty) {
        leftBody.fluentPutAll(rightOption.get)
      }
      (obj._1, leftBody)
    }).values.persist(StorageLevel.DISK_ONLY)
    logger.error("关联fvp54表数量：" + joinFvp54Rdd.count())
    logTtRdd.unpersist()
    logger.error("剔除非法网点")
    val validRdd = joinFvp54Rdd.filter(obj => {
      var flag = true
      val fvpBody = obj.getJSONObject("fvp_54_body")
      if (fvpBody != null) {
        val zoneCode = fvpBody.getString("zoneCode")
        if (StringUtils.nonEmpty(zoneCode) && invalidDept.contains(zoneCode)) {
          flag = false
        }
      }
      flag
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("剔除非法网点后:" + validRdd.count())
    joinFvp54Rdd.unpersist()
    validRdd
  }

  def parseDataRdd(spark: SparkSession): RDD[JSONObject] = {
    logger.error("获取需要剔除的网点")
    val invalidDept = fetchInvalidDept(spark)
    logger.error("获取收件日志表")
    val logRdd = getOmsLogRdd(spark, incDay, incDay)
    logger.error("获取订单宽表")
    val ttRdd = getTtOrderRdd(spark, incDay, incDay)
    logger.error("获取妥投路由表数据")
    val fvp54Rdd = fetchFvp54(spark, incDay, incDay)
    logger.error("关联日志,剔除网点")
    val validDataRdd = filterValidRcgRdd(fvp54Rdd, logRdd, ttRdd, invalidDept)
    logger.error("保存空finalaoicode数据到hive")

    val aoiEmptyDataRdd = validDataRdd.filter(obj => {
      val oms_body = obj.getJSONObject("oms_body")
      //收件AOI未识别数据更改
      StringUtils.isEmpty(oms_body.getString("syncAoiCode")) && StringUtils.isEmpty(oms_body.getString("asyncAoiCode"))
      //!StringUtils.nonEmpty(oms_body.getString("finalAoiCode"))
    })
    save_data_hive(spark, "non", aoiEmptyDataRdd)
    validDataRdd
  }

  def getOmsLogRdd(spark: SparkSession, startDate: String, endDate: String): RDD[(String, JSONObject)] = {
    val omsToArray = Array("sysOrderNo", "cityCode", "city", "address", "finalAoiCode",
      "syncAoiCode", "asyncAoiCode", "arssAoiCode","province","county","phone","mobile",
      "company","deptcode","teamcode")
    val sqlBuilder = new StringBuilder()
    for (i <- omsToArray.indices) {
      sqlBuilder.append(omsToArray(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val conditionSqlBuilder = new StringBuilder()
    conditionSqlBuilder.append(" inc_day between '" + startDate + "' and '" + endDate + "' ")
    if (!city_code.isEmpty) {
      conditionSqlBuilder.append(" and cityCode in ('" + city_code.mkString("','") + "') ")
    }
    val selectOmsSql =
      s"""
         |select ${sqlBuilder.toString()}
         | from dm_gis.gis_rds_omsfrom
         | where ${conditionSqlBuilder.toString()}  and sysOrderNo <> '' and isnotundercall <> '1'
      """.stripMargin

    println("selectOmsSql:" + selectOmsSql)
    val omsRdd = spark.sql(selectOmsSql)
      .repartition(200)
      .rdd
      .map(row => {
        val oms_body = new JSONObject()
        for (i <- omsToArray.indices) oms_body.put(omsToArray(i), row.getString(i))
        val sysOrderNo = oms_body.getString("sysOrderNo")
        val result = new JSONObject()
        result.put("oms_body", oms_body)
        (sysOrderNo, result)
      }).persist(StorageLevel.DISK_ONLY)
    logger.error("日志表数据量：" + omsRdd.count())
    omsRdd
  }

  def getOmsLogRddOrderNo(spark: SparkSession, startDate: String, endDate: String): RDD[(String, JSONObject)] = {
    val omsToArray = Array("cityCode", "city", "address", "errCallResno", "errCallCity",
      "errCallAddrabb", "orderNo", "sysOrderNo", "chkOmsRebody", "isNotUnderCall",
      "asyncReqFlag", "asyncSrc", "asyncAoiCode", "syncReqFlag", "syncSrc",
      "syncAoiCode", "arssReFlag", "arssAoiCode", "finalAoiCode", "deptcode","province","county","phone","mobile",
      "company","teamcode")
    val sqlBuilder = new StringBuilder()
    for (i <- omsToArray.indices) {
      sqlBuilder.append(omsToArray(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val conditionSqlBuilder = new StringBuilder()
    conditionSqlBuilder.append(" inc_day between '" + startDate + "' and '" + endDate + "' ")
    if (!city_code.isEmpty) {
      conditionSqlBuilder.append(" and cityCode in ('" + city_code.mkString("','") + "') ")
    }
    val selectOmsSql =
      s"""
         |select * from
         |	(select ${sqlBuilder.toString()},
         |   row_number() over(partition BY orderNo order by syncReqDateTime desc ) as rank
         |   from dm_gis.gis_rds_omsfrom
         | where ${conditionSqlBuilder.toString()}  and orderNo <> '' )a where a.rank=1
      """.stripMargin
    println("selectOmsSql:" + selectOmsSql)
    val omsRdd = spark.sql(selectOmsSql)
      .repartition(200)
      .rdd
      .map(row => {
        val oms_body = new JSONObject()
        for (i <- omsToArray.indices) oms_body.put(omsToArray(i), row.getString(i))
        val orderNo = oms_body.getString("orderNo")
        val result = new JSONObject()
        result.put("oms_body", oms_body)
        (orderNo, result)
      }).persist(StorageLevel.DISK_ONLY)
    logger.error("日志表数据量：" + omsRdd.count())
    omsRdd
  }

  def getTtOrderRdd(spark: SparkSession, startDate: String, endDate: String): RDD[(String, JSONObject)] = {
    val ttOrderArray = Array("src_order_no", "waybill_no")
    val sqlBuilder = new StringBuilder()
    for (i <- ttOrderArray.indices) {
      if (ttOrderArray(i).equals("waybill_no")) {
        sqlBuilder.append("waybill_no[0]").append(",")
      } else {
        sqlBuilder.append(ttOrderArray(i)).append(",")
      }
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val conditionSqlBuilder = new StringBuilder()
    conditionSqlBuilder.append(" inc_day between '" + startDate + "' and '" + endDate + "' ")
    //    if (!city_code.isEmpty) {
    //      conditionSqlBuilder.append(" and cityCode in ('" + city_code.mkString("','") + "') ")
    //    }
    val selectTtSql =
    s"""select * from (
       |select ${sqlBuilder.toString()},row_number() over (partition by src_order_no order by order_tm desc) as rank
       | from gdl.tt_order_info
       | where ${conditionSqlBuilder.toString()}  and src_order_no <> '') a where a.rank = 1
      """.stripMargin

    println("selectTtSql:" + selectTtSql)
    val ttRdd = spark.sql(selectTtSql)
      .repartition(200)
      .rdd
      .map(row => {
        val tt_body = new JSONObject()
        for (i <- ttOrderArray.indices) {
          tt_body.put(ttOrderArray(i), row.getString(i))
        }
        val sysOrderNo = tt_body.getString("src_order_no").replace("'", "")
        tt_body.remove("src_order_no")
        val result = new JSONObject()
        result.put("tt_body", tt_body)
        (sysOrderNo, result)
      }).persist(StorageLevel.DISK_ONLY)
    logger.error("订单表数据量：" + ttRdd.count())
    ttRdd
  }

  def fetchInvalidDept(spark: SparkSession): util.HashSet[String] = {
    val deptTable = "gdl.zipper_dim_department"
    val deptSql = s"select dept_code from $deptTable where dw_start_date<='$incDay' and dw_end_date>= '$incDay' "  +
      s" and (dept_type_code in ('DB05-XMDB','FB04-WXJ','FB05-CCPSCK','DB05-JPZ','FB04-KYFB','ZZC04-ERJ','ZZC05-KYJS','QB03-KYGS') " +
      s" or (dept_type_code='DB05-SFZ' and (dept_name like '%临时网点%'" +
      " )))"
    val deptList = spark.sql(deptSql).rdd.map(obj => obj.getString(0)).collect()
    val deptSet = new util.HashSet[String]()
    for (dept <- deptList) {
      if (dept != null && !dept.isEmpty) {
        deptSet.add(dept)
      }
    }
    logger.error("识别率流程中剔除网点数量:" + deptSet.size())
    deptSet
  }

  def fetchWdInvalidDept(spark: SparkSession): util.HashSet[String] = {
    val deptTable = "gdl.zipper_dim_department"
    val deptSql = s"select dept_code from $deptTable where dw_start_date<='$incDay' and dw_end_date>= '$incDay' "  +
      s" and (dept_type_code in ('DB05-XMDB','FB04-WXJ','FB04-XMFB','FB05-CCPSCK','FB04-GLX','DB05-JPZ','FB04-KYFB','ZZC04-ERJ','ZZC05-KYJS','QB03-KYGS') " +
      s" or (dept_type_code='DB05-SFZ' and (dept_name like '%临时网点%'" +
      " )))"
    val deptList = spark.sql(deptSql).rdd.map(obj => obj.getString(0)).collect()
    val deptSet = new util.HashSet[String]()
    for (dept <- deptList) {
      if (dept != null && !dept.isEmpty) {
        deptSet.add(dept)
      }
    }
    logger.error("错分流程中剔除网点数量:" + deptSet.size())
    deptSet
  }

  def fetchFvp54(spark: SparkSession, startDate: String, endDate: String): RDD[(String, JSONObject)] = {
    val fvp54Array = Array("mainWaybillno", "zoneCode")
    val sqlBuilder = new StringBuilder()
    for (i <- fvp54Array.indices) {
      sqlBuilder.append(fvp54Array(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectFvp54Sql =
      s"""
         |select * from (
         |select ${sqlBuilder.toString()},
         |	row_number() over (partition by mainWaybillno order by barscantm desc) as rank from ods_kafka_fvp.fvp_core_fact_route_op
         |	where inc_day between '$startDate' and '$endDate' and opcode='54' and mainwaybillno <> '') b where b.rank =1
         |
       """.stripMargin
    println("selectFvp54Sql:" + selectFvp54Sql)
    val fvp54Rdd = spark.sql(selectFvp54Sql)
      .repartition(400)
      .rdd
      .map(row => {
        val fvp_54_body = new JSONObject()
        for (i <- fvp54Array.indices) fvp_54_body.put(fvp54Array(i), row.getString(i))
        var result: JSONObject = null
        var waybillNo: String = null
        result = new JSONObject()
        result.put("fvp_54_body", fvp_54_body)
        waybillNo = fvp_54_body.getString("mainWaybillno")
        fvp_54_body.remove("mainWaybillno")
        (waybillNo, result)
      }).filter(obj => obj._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("妥投54数量：" + fvp54Rdd.count())
    fvp54Rdd
  }

  def checkEmpty(str: String): Int = {
    var cnt = 0
    if (StringUtils.nonEmpty(str)) {
      cnt = 1
    }
    cnt
  }

  def checkArssReq(arssReqBody: JSONObject): Int = {
    var arssReqCnt = 0
    if (arssReqBody != null) {
      val taskType = arssReqBody.getString("taskType")
      if (taskType != null && taskType.equals("2")) {
        arssReqCnt = 1
      }
    }
    arssReqCnt
  }

  def checkArssRe(arssReBody: JSONObject): Int = {
    var arssReCnt = 0
    if (arssReBody != null) {
      val result = arssReBody.getString("result")
      val identRs = arssReBody.getString("identRs")
      val aoiCode = arssReBody.getString("aoiCode")
      if (StringUtils.nonEmptyEq(result, "2") && StringUtils.nonEmpty(identRs)
        && StringUtils.nonEmpty(aoiCode)) {
        arssReCnt = 1
      }
    }
    arssReCnt
  }

  def checkAwsmReq(awsmReq: JSONArray): Int = {
    var awsmReqCnt = 0
    if (awsmReq == null || awsmReq.size() == 0) {
      return awsmReqCnt
    }
    var awsmReqBody: JSONObject = null
    for (i <- 0 until awsmReq.size()) {
      val tmpObj = awsmReq.getJSONObject(i)
      if (awsmReqBody == null) {
        awsmReqBody = tmpObj
      } else {
        val aoiReqTime = tmpObj.getString("aoi_dept_req_time")
        val curReqTime = awsmReqBody.getString("aoi_dept_req_time")
        if (StringUtils.nonEmpty(aoiReqTime) && aoiReqTime.compareTo(curReqTime) > 0) {
          awsmReqBody = tmpObj
        }
      }
    }
    val checkType = awsmReqBody.getString("checkType")
    if (StringUtils.nonEmptyEq(checkType, "1")) {
      awsmReqCnt = 1
    }
    awsmReqCnt
  }

  def checkAwsmRe(awsmRe: JSONArray): Int = {
    var awsmReCnt = 0
    if (awsmRe == null || awsmRe.size() == 0) {
      return awsmReCnt
    }
    var awsmReBody: JSONObject = null
    for (i <- 0 until awsmRe.size()) {
      val tmpObj = awsmRe.getJSONObject(i)
      if (awsmReBody == null) {
        awsmReBody = tmpObj
      } else {
        val aoiReTime = tmpObj.getString("aoi_dept_re_time")
        val curReTime = awsmReBody.getString("aoi_dept_re_time")
        if (StringUtils.nonEmpty(aoiReTime) && aoiReTime.compareTo(curReTime) > 0) {
          awsmReBody = tmpObj
        }
      }
    }
    val dataType = awsmReBody.getString("dataType")
    val aoiCode = awsmReBody.getString("aoiCode")
    if (StringUtils.nonEmptyEq(dataType, "1") && StringUtils.nonEmpty(aoiCode)) {
      awsmReCnt = 1
    }
    awsmReCnt
  }

  def statRcgIndexDetail(fvpBody: JSONObject, omsBody: JSONObject, region: String, city: String, cityCode: String): AreaRcgShouObj = {
    val req = 1
    var fvpCode = ""
    if (fvpBody != null) {
      fvpCode = fvpBody.getString("zoneCode")
    }
    val aoiCnt = checkEmpty(omsBody.getString("finalAoiCode"))
    val addressAoiCnt = checkEmpty(omsBody.getString("syncAoiCode")) | checkEmpty(omsBody.getString("asyncAoiCode"))
    var arssAoiCnt = 0
    if (addressAoiCnt == 0 && checkEmpty(omsBody.getString("arssAoiCode")) == 1) {
      arssAoiCnt = 1
    }
    AreaRcgShouObj(region, city, cityCode, fvpCode, req, aoiCnt,
      addressAoiCnt, arssAoiCnt)
  }

  def mergeRcgIndex(obj1: AreaRcgShouObj, obj2: AreaRcgShouObj): AreaRcgShouObj = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val region = obj1.region
    val city = obj1.city
    val cityCode = obj1.cityCode
    val zoneCode = obj1.zoneCode
    val req = obj1.req + obj2.req
    val aoiCnt = obj1.aoiCnt + obj2.aoiCnt
    val addressAoiCnt = obj1.addressAoiCnt + obj2.addressAoiCnt
    val arssAoiCnt = obj1.arssAoiCnt + obj2.arssAoiCnt
    AreaRcgShouObj(region, city, cityCode, zoneCode, req,
      aoiCnt, addressAoiCnt, arssAoiCnt)
  }

  def statRcgIndex(rcgRdd: RDD[JSONObject], cityMap: Map[String, ArrayBuffer[Array[String]]]): RDD[(String, AreaRcgShouObj)] = {
    val rcgIndexRdd = rcgRdd.map(obj => {
      val fvpBody = obj.getJSONObject("fvp_54_body")
      val omsBody = obj.getJSONObject("oms_body")
      val cityCode = omsBody.getString("cityCode")
      val address = omsBody.getString("address")
      val cityName = omsBody.getString("city")
      val city_info = CityRegion.typeCity(cityMap, cityCode, cityName, address)
      if (city_info._1) {
        val region = city_info._2.getString("region")
        val city = city_info._2.getString("city")
        val cityCode = city_info._2.getString("cityCode")
        val areaRcgObj = statRcgIndexDetail(fvpBody, omsBody, region, city, cityCode)
        (cityCode + "_" + city + "_" + areaRcgObj.zoneCode, areaRcgObj)
      } else {
        (null, null)
      }
    }).filter(obj => obj._1 != null).reduceByKey((obj1, obj2) => {
      mergeRcgIndex(obj1, obj2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("收件识别量指标聚合后数量:" + rcgIndexRdd.count())
    rcgRdd.unpersist()
    rcgIndexRdd
  }


  def getExecuteDataRdd(spark: SparkSession): RDD[(String, JSONObject)] = {
    val executionArray = Array("order_no", "aoi_id", "batch_code", "act_time",
      "distribute_code", "act_code", "dest_dept_code", "real_distribute_time",
      "date", "is_distribute_receipt","waybillno")
    val sqlBuilder = new StringBuilder()
    for (i <- executionArray.indices) {
      if (!executionArray(i).equals("date")) {
        sqlBuilder.append(executionArray(i)).append(",")
      } else {
        sqlBuilder.append("`date`").append(",")
      }
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectSql =
      s"""select * from (
         |select ${sqlBuilder.toString()},
         | row_number() over(partition BY order_no order by
         |   real_distribute_time desc,act_time desc ) as rank
         |   from dm_tc_waybillinfo.execution_detail_shou
         | where inc_day = '$incDay' and order_no <> '' and send_type='下call单' )a where a.rank=1     """.stripMargin
    println("selectExecutionSql:" + selectSql)
    val executionRdd = spark.sql(selectSql)
      .repartition(200)
      .rdd
      .map(row => {
        val exe_body = new JSONObject()
        for (i <- executionArray.indices) {
          if (executionArray(i).equals("aoi_id")) {
            var aoi_id = row.getString(i)
            if (aoi_id == null || !aoi_id.startsWith("=\"")) {
              aoi_id = ""
            }
            aoi_id = aoi_id.replaceAll("=", "").replaceAll("\"", "").trim
            exe_body.put(executionArray(i), aoi_id)
          } else {
            exe_body.put(executionArray(i), row.getString(i).trim)
          }
        }
        var real_distribute_time = exe_body.getString("real_distribute_time")
        var act_time = exe_body.getString("act_time")
        var orderNo = exe_body.getString("order_no")
        if (act_time.isEmpty || act_time.equals("-")) {
          if (!real_distribute_time.replaceAll("-", "").contains(incDay)) {
            orderNo = null
          }
        } else {
          if (!act_time.replaceAll("-", "").contains(incDay)) {
            orderNo = null
          }
        }
        val result = new JSONObject()
        result.put("exe_body", exe_body)
        (orderNo, result)
      }).filter(_._1 != null)
    executionRdd
  }

  def joinFvpOmsDataRdd(logDataRdd: RDD[(String, JSONObject)], executeDataRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val validRdd = logDataRdd.union(executeDataRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).filter(obj => obj._2.containsKey("oms_body") && obj._2.containsKey("exe_body"))
      .map(obj=>{
        (obj._2.getJSONObject("exe_body").getString("waybillno"),obj._2)
      }).persist(StorageLevel.DISK_ONLY)
    logger.error("有效数据量：" + validRdd.count())
    logDataRdd.unpersist()
    executeDataRdd.unpersist()
    validRdd
  }

  def filterValidRdd(spark: SparkSession, joinFvpOmsDataRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    logger.error("剔除finnalAoiCode为空的数据")
    val aoiNonEmptyRdd = joinFvpOmsDataRdd.filter(obj => {
      val oms_body = obj._2.getJSONObject("oms_body")
      val finalAoiCode = oms_body.getString("finalAoiCode")
      if (!StringUtils.nonEmpty(finalAoiCode)) {
        false
      } else {
        true
      }
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("剔除finalAoiCode为空后数据后数据量:" + aoiNonEmptyRdd.count())
    joinFvpOmsDataRdd.unpersist()

    logger.error("关联妥投路由表")
    val fvp54Rdd = fetchFvp54(spark, logDayMin, incDay)
    val joinFvp54Rdd = aoiNonEmptyRdd.union(fvp54Rdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).filter(obj => obj._2.containsKey("oms_body")).persist(StorageLevel.DISK_ONLY)
    logger.error("关联54妥投表后：" + joinFvp54Rdd.count())
    aoiNonEmptyRdd.unpersist()
    fvp54Rdd.unpersist()
    logger.error("过滤非法网点")
    val wdInvalidDept = fetchWdInvalidDept(spark)
    val validRdd = joinFvp54Rdd.filter(obj => {
      val fvp54 = obj._2.getJSONObject("fvp_54_body")
      var flag = true
      if (fvp54 != null) {
        val zoneCode = fvp54.getString("zoneCode")
        if (StringUtils.nonEmpty(zoneCode) && wdInvalidDept.contains(zoneCode)) {
          flag = false
        }
      }
      flag
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("过滤非法网点后：" + validRdd.count())
    joinFvp54Rdd.unpersist()
    validRdd
  }

  def fetchFvpInvaid(spark: SparkSession): RDD[(String, JSONObject)] = {
    val fetchFvpInvalidArray = Array("mainwaybillno")
    val sqlBuilder = new StringBuilder()
    for (i <- fetchFvpInvalidArray.indices) {
      sqlBuilder.append(fetchFvpInvalidArray(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectFvpInvalidSql =
      s"""
         |select ${sqlBuilder.toString()} from ods_kafka_fvp.fvp_core_fact_route_op
         |	where inc_day between '$logDayMin' and '$incDay' and opcode in ('33','125') and mainwaybillno <> ''
       """.stripMargin
    println("selectFvpInvalidSql:" + selectFvpInvalidSql)
    val invalidFvpRdd = spark.sql(selectFvpInvalidSql)
      .repartition(400)
      .rdd
      .map(row => {
        val fvp_invliad_body = new JSONObject()
        for (i <- fetchFvpInvalidArray.indices) fvp_invliad_body.put(fetchFvpInvalidArray(i), row.getString(i))
        val mainwaybillno = fvp_invliad_body.getString("mainwaybillno")
        fvp_invliad_body.remove("mainwaybillno")
        val result = new JSONObject()
        result.put("fvp_invliad_body", fvp_invliad_body)
        (fvp_invliad_body.getString("mainwaybillno"), result)
      }).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("33或者125的数量:" + invalidFvpRdd.count())
    invalidFvpRdd
  }

  def joinRunBatch(validDataRdd: RDD[(String, JSONObject)], runBatchRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val finalBatchRdd = validDataRdd.map(obj => {
      val dest_dept_code = obj._2.getJSONObject("exe_body").getString("dest_dept_code")
      (dest_dept_code, obj._2)
    }).leftOuterJoin(runBatchRdd).map(obj => {
      val runBatchOption = obj._2._2
      val executionBody = obj._2._1.getJSONObject("exe_body")
      val real_distribute_time = executionBody.getString("real_distribute_time")
      val act_time = executionBody.getString("act_time")
      try {
        val distributeTime = Util.timeToLong(real_distribute_time, "yyyy-MM-dd HH:mm:ss")
        val actTime = Util.timeToLong(act_time, "yyyy-MM-dd HH:mm:ss")
        if (runBatchOption.nonEmpty) {
          val runbatch_body = runBatchOption.get.getJSONObject("runbatch_body")
          val planbegintm = runbatch_body.getString("planbegintm")
          val planendtm = runbatch_body.getString("planendtm")
          val day = runbatch_body.getString("date")
          val beginTime = Util.timeToLong(day + " " + planbegintm+"00", "yyyyMMdd HHmmss")
          val endTime = Util.timeToLong(day + " " + planendtm+"59", "yyyyMMdd HHmmss")
          if (distributeTime <= endTime && distributeTime >= beginTime) {
            obj._2._1.put("runBatchBatchCode1", runbatch_body.getString("batchcode"))
          }
          if (actTime <= endTime && actTime >= beginTime) {
            obj._2._1.put("runBatchBatchCode2", runbatch_body.getString("batchcode"))
          }
        }
      } catch {
        case e: Exception => logger.error(">>>时间格式不正确：" + e)
      }
      (executionBody.getString("order_no"), obj._2._1)
    }).reduceByKey((obj1, obj2) => {
      updateBatchCode(obj1, obj2, "runBatchBatchCode1")
      updateBatchCode(obj1, obj2, "runBatchBatchCode2")
      obj1
    }).flatMap(obj => {
      val list = new util.ArrayList[(String, JSONObject)]()
      val executionBody = obj._2.getJSONObject("exe_body")
      val act_code = executionBody.getString("act_code")
      val date = executionBody.getString("date")
      if (checkBatchCode(obj._2.getString("runBatchBatchCode1"))) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj._2)
        tmpObj.put("finalBatchCode1", obj._2.getString("runBatchBatchCode1"))
        list.add((obj._2.getString("runBatchBatchCode1") + "_" + act_code + "_" + date, tmpObj))
      }
      if (checkBatchCode(obj._2.getString("runBatchBatchCode2"))) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj._2)
        tmpObj.put("finalBatchCode2", obj._2.getString("runBatchBatchCode2"))
        list.add((obj._2.getString("runBatchBatchCode2") + "_" + act_code + "_" + date, tmpObj))
      }
      if (!checkBatchCode(obj._2.getString("runBatchBatchCode1"))
        && !checkBatchCode(obj._2.getString("runBatchBatchCode2"))) {
        val tmpObj = new JSONObject()
        tmpObj.fluentPutAll(obj._2)
        tmpObj.put("finalBatchCode", executionBody.getString("batch_code"))
        list.add((executionBody.getString("batch_code") + "_" + act_code + "_" + date, tmpObj))
      }
      list.iterator()
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("匹配到的班次表数量："+finalBatchRdd.filter(obj=>{
      obj._2.containsKey("finalBatchCode2") || obj._2.containsKey("finalBatchCode1")
    }).count())
    finalBatchRdd
  }

  def updateBatchCode(obj1: JSONObject, obj2: JSONObject, key: String): Unit = {
    var runBatchCode = ""
    val runBatchBatchCode1 = obj1.getString(key)
    if (runBatchBatchCode1 != null && !runBatchBatchCode1.isEmpty) {
      runBatchCode = runBatchBatchCode1
    }
    val runBatchBatchCode2 = obj2.getString(key)
    if (runBatchBatchCode2 != null && !runBatchBatchCode2.isEmpty
      && !runBatchBatchCode2.equals(runBatchCode)) {
      if (!runBatchCode.isEmpty) {
        runBatchCode = runBatchCode + ";" + runBatchBatchCode2
      } else {
        runBatchCode = runBatchBatchCode2
      }
    }
    obj1.put(key, runBatchCode)
  }

  def checkBatchCode(runBatchBatchCode: String): Boolean = {
    runBatchBatchCode != null && runBatchBatchCode.endsWith("P") && !runBatchBatchCode.contains(";")
  }

  def checkDeptSame(obj: JSONObject) = {
    val omsBody = obj.getJSONObject("oms_body")
    val finalZc = omsBody.getString("deptcode")
    val fvp54Body = obj.getJSONObject("fvp_54_body")
    var isReject = obj.getInteger("isReject")
    if (fvp54Body != null) {
      val fvpDept = fvp54Body.getString("zoneCode")
      if (isReject == 0 && StringUtils.nonEmpty(fvpDept) && !fvpDept.equals(finalZc)) {
        obj.put("isReject", 1)
        obj.put("deptDiff", 1)
      }
    }

    obj
  }

  def checkDistributeDeliverd(obj: JSONObject): Unit = {
    val isReject = obj.getInteger("isReject")
    if (isReject != 0) {
      return
    }
    val exeBody = obj.getJSONObject("exe_body")
    val isDistributeDelivered = exeBody.getString("is_distribute_receipt")
    if (isDistributeDelivered != null && isDistributeDelivered.equals("是")) {
      obj.put("isReject", 1)
      obj.put("isDistribute", 1)
    }
  }

  def rejectWdDataRdd(wdRdd: RDD[(String, JSONObject)], batchResultAoiIdDateRdd: RDD[(String, JSONObject)],
                      batchResultEmpDateRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    logger.error("回单网点不一致")
    val sameRdd = wdRdd.map(obj => {
      checkDeptSame(obj._2)
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("回单网点和gis网点不一致的数据量:"
      + wdRdd.filter(obj => obj._2.getInteger("deptDiff") == 1).count())
    logger.error("剔除is_distribute_receipt为是的数据")
    wdRdd.unpersist()
    val rejectDistribute = sameRdd.map(obj => {
      checkDistributeDeliverd(obj._2)
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("is_distribute_receipt:"
      + rejectDistribute.filter(obj => obj._2.getInteger("isDistribute") != null
      && obj._2.getInteger("isDistribute") == 1).count())
    sameRdd.unpersist()
    logger.error("根据aoi_id和日期做aoi剔除")
    val joinAoiIdDateRdd = rejectDistribute.map(obj => {
      val exeBody = obj._2.getJSONObject("exe_body")
      val date = exeBody.getString("date")
      val aoi_id = exeBody.getString("aoi_id")
      (date + "_" + aoi_id, obj._2)
    }).leftOuterJoin(batchResultAoiIdDateRdd).map(obj => {
      val leftBody = obj._2._1
      val exeBody = leftBody.getJSONObject("exe_body")
      val act_code = exeBody.getString("act_code")
      val rightOption = obj._2._2
      if (rightOption.nonEmpty) {
        leftBody.put("empnolist", rightOption.get.keySet().mkString(";"))
        if (leftBody.getInteger("isReject") == 0 && StringUtils.nonEmpty(act_code) &&
          rightOption.get.containsKey(act_code)) {
          leftBody.put("isReject", 1)
          leftBody.put("aoiIdDateIn", 1)
        }
      }
      leftBody
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("按aoiid，date聚合后，小哥工号剔除量:"
      + joinAoiIdDateRdd.filter(obj => obj.getInteger("aoiIdDateIn") != null
      && obj.getInteger("aoiIdDateIn") == 1).count())
    rejectDistribute.unpersist()
    logger.error("按delivered_code，date聚合")
    val joinEmpDateRdd = joinAoiIdDateRdd.map(obj => {
      val exeBody = obj.getJSONObject("exe_body")
      val date = exeBody.getString("date")
      val act_code = exeBody.getString("act_code")
      (act_code + "_" + date, obj)
    }).leftOuterJoin(batchResultEmpDateRdd).map(obj => {
      val leftBody = obj._2._1
      val omsBody = leftBody.getJSONObject("oms_body")
      val exeBody = leftBody.getJSONObject("exe_body")
      val aoi_id = exeBody.getString("aoi_id")
      val rightOption = obj._2._2
      if (rightOption.nonEmpty) {
        leftBody.put("allaoilist", rightOption.get.keySet().mkString(";"))
        if (leftBody.getInteger("isReject") == 0 && StringUtils.nonEmpty(aoi_id) &&
          rightOption.get.containsKey(aoi_id)) {
          leftBody.put("isReject", 1)
          leftBody.put("deliveredCodeDateIn", 1)
        }
      }
      (omsBody.getString("orderNo"), leftBody)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("按empNo，date聚合后，aoiid剔除量:"
      + joinEmpDateRdd.filter(obj => obj._2.getInteger("deliveredCodeDateIn") != null
      && obj._2.getInteger("deliveredCodeDateIn") == 1).count())
    joinAoiIdDateRdd.unpersist()
    joinEmpDateRdd
  }

  def calWdAllDataRdd(spark: SparkSession, validDataRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    logger.error(">>>获取班次信息表")
    val runBatchRdd = getRunBatchRdd(spark).persist(StorageLevel.DISK_ONLY)
    logger.error(">>>获取班次表数量:" + runBatchRdd.count())
    logger.error(">>>关联班次表")
    val runBatchValid = joinRunBatch(validDataRdd, runBatchRdd)
    logger.error("关联班次表过后数量:" + runBatchValid.count())
    runBatchRdd.unpersist()
    validDataRdd.unpersist()
    logger.error(">>>获取排班结果表")
    val batchResultRdd = getBatchResultRdd(spark)
    logger.error(">>>关联排班结果表")
    val wdRdd = unionBatchResult(spark, runBatchValid, batchResultRdd._1).persist(StorageLevel.DISK_ONLY)

    logger.error(">>>剔除前错分表数量：" + wdRdd.count())
    val wdRejectRdd = rejectWdDataRdd(wdRdd, batchResultRdd._2, batchResultRdd._3)
    logger.error("保存剔除后错分数据到hive")
    val wdAftRdd = wdRejectRdd.filter(obj => {
      obj._2.getInteger("isReject") == 0
    }).values
    save_data_hive(spark, "wd", wdAftRdd)
    wdRejectRdd
  }

  def unionBatchResult(spark: SparkSession, runBatchValid: RDD[(String, JSONObject)], batchResultRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val batchResultUnion = runBatchValid.leftOuterJoin(batchResultRdd).map(obj => {
      val batchResultOption = obj._2._2
      val exe_body = obj._2._1.getJSONObject("exe_body")
      if (batchResultOption.nonEmpty) {
        val batchResult_body = batchResultOption.get.getJSONObject("batchResult_body")
        if (obj._2._1.containsKey("finalBatchCode")) {
          obj._2._1.put("batchResult_body", batchResult_body)
        } else if (obj._2._1.containsKey("finalBatchCode1")) {
          obj._2._1.put("batchResult_body1", batchResult_body)
        } else if (obj._2._1.containsKey("finalBatchCode2")) {
          obj._2._1.put("batchResult_body2", batchResult_body)
        }
        val orderno = exe_body.getString("order_no")
        (orderno, obj._2._1)
      } else {
        (null, obj._2._1)
      }
    }).filter(obj => obj._1 != null)
      .reduceByKey((obj1, obj2) => {
        if (obj2.containsKey("finalBatchCode")) {
          obj1.put("finalBatchCode", obj2.getString("finalBatchCode"))
          obj1.put("batchResult_body", obj2.getJSONObject("batchResult_body"))
        } else if (obj2.containsKey("finalBatchCode1")) {
          obj1.put("finalBatchCode1", obj2.getString("finalBatchCode1"))
          obj1.put("batchResult_body1", obj2.getJSONObject("batchResult_body1"))
        } else if (obj2.containsKey("finalBatchCode2")) {
          obj1.put("finalBatchCode2", obj2.getString("finalBatchCode2"))
          obj1.put("batchResult_body2", obj2.getJSONObject("batchResult_body2"))
        }
        obj1
      })
      .persist(StorageLevel.DISK_ONLY)
    logger.error(">>>关联排班结果表数量：" + batchResultUnion.count())
    runBatchValid.unpersist()
    batchResultRdd.unpersist()
    val wdRd = batchResultUnion.filter(obj => {

      var aoiId = JSONUtils.getJsonValue(obj._2, "exe_body.aoi_id", "")
      if(aoiId.isEmpty){
        aoiId = JSONUtils.getJsonValue(obj._2, "oms_body.finalAoiCode", "")
      }
      if(aoiId.isEmpty){
        false
      }else{
        !(checkAoiIdContain(aoiId, obj._2.getJSONObject("batchResult_body"))
          || checkAoiIdContain(aoiId, obj._2.getJSONObject("batchResult_body1"))
          || checkAoiIdContain(aoiId, obj._2.getJSONObject("batchResult_body2")))
      }

    }).map(obj => {
      obj._2.put("isWd", 1)
      obj._2.put("isReject", 0)
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("关联表排班结果表后，错call数量:" + batchResultUnion.count())
    batchResultUnion.unpersist()
    wdRd
  }

  def checkAoiIdContain(aoiId: String, obj: JSONObject): Boolean = {
    if (obj != null) {
      val aoiIdList = obj.getString("aoi_id_key")
      aoiIdList.contains(";" + aoiId + ";")
    } else {
      false
    }
  }

  def getBatchResultRdd(spark: SparkSession): (RDD[(String, JSONObject)], RDD[(String, JSONObject)], RDD[(String, JSONObject)]) = {
    val batchResultArray = Array("aoi_id", "emp_no", "batch_date", "batch_code")
    val sqlBuilder = new StringBuilder()
    for (i <- batchResultArray.indices) {
      sqlBuilder.append(batchResultArray(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectOmsSql =
      s"""select ${sqlBuilder.toString()}
         |   from dm_tc_waybillinfo.sds_scheduling_result
         | where inc_day = '$incDay'
      """.stripMargin
    println("selectBatchResultSql:" + selectOmsSql)
    val totalRdd = spark.sql(selectOmsSql)
      .repartition(400)
      .rdd
      .map(row => {
        val batchResult_body = new JSONObject()
        for (i <- batchResultArray.indices) batchResult_body.put(batchResultArray(i), row.getString(i))
        val aoi_id = batchResult_body.getString("aoi_id")
        val emp_no = batchResult_body.getString("emp_no")
        val batch_date = batchResult_body.getString("batch_date")
        val batch_code = batchResult_body.getString("batch_code")
        var key: String = null
        val result = new JSONObject()
        result.put("batchResult_body", batchResult_body)
        if (!aoi_id.isEmpty) {
          try {
            val aoiInfo = JSON.parseObject(aoi_id)
            if (aoiInfo.keySet().size() != 0) {
              batchResult_body.put("aoi_id", aoiInfo)
              batchResult_body.put("aoi_id_key", ";" + aoiInfo.keySet().mkString(";") + ";")
              key = batch_code + "_" + emp_no + "_" + batch_date + "_" + aoi_id
            }
          } catch {
            case e: Exception => logger.error(">>>aoi格式不正确：" + e)
          }
        }
        (key, result)
      }).filter(obj => obj._1 != null).reduceByKey((obj1, obj2) => {
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("排班结果表总数:" + totalRdd.count())
    val batchEmpDateRdd = totalRdd.map(obj => {
      val batchResult_body = obj._2.getJSONObject("batchResult_body")
      val emp_no = batchResult_body.getString("emp_no")
      val batch_date = batchResult_body.getString("batch_date")
      val batch_code = batchResult_body.getString("batch_code")
      val key = batch_code + "_" + emp_no + "_" + batch_date
      (key, obj._2)
    }).reduceByKey((obj1, obj2) => {
      val batchResult_body1 = obj1.getJSONObject("batchResult_body")
      val batchResult_body2 = obj2.getJSONObject("batchResult_body")
      val aoiId1 = batchResult_body1.getJSONObject("aoi_id")
      val aoiId2 = batchResult_body2.getJSONObject("aoi_id")
      aoiId1.fluentPutAll(aoiId2)
      batchResult_body1.put("aoi_id_key", ";" + aoiId1.keySet().mkString(";") + ";")
      obj1
    }).persist(StorageLevel.DISK_ONLY)

    logger.error("按照batch,emp,date聚合数量:" + batchEmpDateRdd.count())
    val aoiIdDateRdd = totalRdd.flatMap(obj => {
      val batchResultBody = obj._2.getJSONObject("batchResult_body")
      val aoi_id = batchResultBody.getJSONObject("aoi_id")
      val batch_date = batchResultBody.getString("batch_date")
      val emp_no = batchResultBody.getString("emp_no")
      val aoiSet = aoi_id.keySet()
      val list = new util.ArrayList[(String, JSONObject)]()
      for (aoiId <- aoiSet) {
        if (StringUtils.nonEmpty(emp_no)) {
          val tmpObj = new JSONObject()
          tmpObj.put(emp_no, "1")
          list.add((batch_date + "_" + aoiId, tmpObj))
        }
      }
      list.iterator()
    }).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("按照aoiId，日期聚合后数据量：" + aoiIdDateRdd.count())
    val empDateRdd = totalRdd.map(obj => {
      val batchResultBody = obj._2.getJSONObject("batchResult_body")
      val aoiId = batchResultBody.getJSONObject("aoi_id")
      val emp_no = batchResultBody.getString("emp_no")
      val batch_date = batchResultBody.getString("batch_date")
      val tmpObj = new JSONObject()
      tmpObj.fluentPutAll(aoiId)
      val key = emp_no + "_" + batch_date
      (key, tmpObj)
    }).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("按照empno，日期聚合后数据量：" + empDateRdd.count())
    //    empDateRdd.take(10).foreach(obj => {
    //      logger.error(obj)
    //    })
    totalRdd.unpersist()
    (batchEmpDateRdd, aoiIdDateRdd, empDateRdd)
  }

  def getRunBatchRdd(spark: SparkSession): RDD[(String, JSONObject)] = {
    val runBatchArray = Array("operatezonecode", "date", "planbegintm", "planendtm",
      "batchcode")
    val sqlBuilder = new StringBuilder()
    for (i <- runBatchArray.indices) {
      if (!runBatchArray(i).equals("date")) {
        sqlBuilder.append(runBatchArray(i)).append(",")
      } else {
        sqlBuilder.append("`date`").append(",")
      }
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectSql =
      s"""select ${sqlBuilder.toString()}
         | from dm_tc_waybillinfo.runs_batch_original
         | where inc_day = '$incDay'  and operatezonecode<>'' and batchcode like "%P"
      """.stripMargin
    println("selectRunBatchSql:" + selectSql)
    val runBatchRdd = spark.sql(selectSql)
      .repartition(200)
      .rdd
      .map(row => {
        val runbatch_body = new JSONObject()
        val tmpSb = new StringBuilder()
        for (i <- runBatchArray.indices) {
          runbatch_body.put(runBatchArray(i), row.getString(i))
          tmpSb.append(row.getString(i) + "_")
        }
        tmpSb.deleteCharAt(tmpSb.length - 1)
        val result = new JSONObject()
        result.put("runbatch_body", runbatch_body)
        (tmpSb.toString(), result)
      }).filter(_._1 != null).reduceByKey((obj1, _) => {
      obj1
    }).map(obj => {
      val operatezonecode = obj._2.getJSONObject("runbatch_body").getString("operatezonecode")
      (operatezonecode, obj._2)
    })
    runBatchRdd
  }

  def standardData(validDataRdd: RDD[(String, JSONObject)], cityMap: Map[String, ArrayBuffer[Array[String]]]): RDD[(String, JSONObject)] = {
    val standardDataRdd = validDataRdd.map(obj => {
      val omsBody = obj._2.getJSONObject("oms_body")
      val cityCode = omsBody.getString("cityCode")
      val address = omsBody.getString("address")
      val cityName = omsBody.getString("city")
      val city_info = CityRegion.typeCity(cityMap, cityCode, cityName, address)
      if (city_info._1) {
        obj._2.fluentPutAll(city_info._2)
        obj
      } else {
        (null, null)
      }
    }).filter(obj => obj._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("standardDataRdd数量:" + standardDataRdd.count())
    validDataRdd.unpersist()
    standardDataRdd
  }

  def joinRcgWd(standardValidData: RDD[(String, JSONObject)], wdAllDataRdd: RDD[(String, JSONObject)]): RDD[(String, JSONObject)] = {
    val rcgWdRdd = standardValidData.union(wdAllDataRdd).reduceByKey((obj1, obj2) => {
      obj1.fluentPutAll(obj2)
      obj1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("识别错分总量数据：" + rcgWdRdd.count())
    standardValidData.unpersist()
    wdAllDataRdd.unpersist()
    rcgWdRdd
  }


  def mergeAreaWdRcg(obj1: AreaWdRcgShouObj, obj2: AreaWdRcgShouObj): AreaWdRcgShouObj = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val region = obj1.region
    val city = obj1.city
    val cityCode = obj1.cityCode
    val zoneCode = obj1.zoneCode
    val aoiExePre = obj1.aoiExePre + obj2.aoiExePre
    val aoiWdPre = obj1.aoiWdPre + obj2.aoiWdPre
    val exeRejectDeptDiff = obj1.exeRejectDeptDiff + obj2.exeRejectDeptDiff
    val aoiWdDeptDiff = obj1.aoiWdDeptDiff + obj2.aoiWdDeptDiff
    val aoiWdDistibuteError = obj1.aoiWdDistibuteError + obj2.aoiWdDistibuteError
    val aoiWdAoiIdDateIn = obj1.aoiWdAoiIdDateIn + obj2.aoiWdAoiIdDateIn
    val aoiWdDeDeliveredCodeDateIn = obj1.aoiWdDeliveredCodeDateIn + obj2.aoiWdDeliveredCodeDateIn
    val aoiAft = obj1.aoiAft + obj2.aoiAft
    val aoiAftRight = obj1.aoiAftRight + obj2.aoiAftRight
    val aoiAftWrong = obj1.aoiAftWrong + obj2.aoiAftWrong
    val aoiAftAddress = obj1.aoiAftAddress + obj2.aoiAftAddress
    val aoiAftAddressRight = obj1.aoiAftAddressRight + obj2.aoiAftAddressRight
    val aoiAftAddressWrong = obj1.aoiAftAddressWrong + obj2.aoiAftAddressWrong
    val aoiAftArss = obj1.aoiAftArss + obj2.aoiAftArss
    val aoiAftArssRight = obj1.aoiAftArssRight + obj2.aoiAftArssRight
    val aoiAftArssWrong = obj1.aoiAftArssWrong + obj2.aoiAftArssWrong
    AreaWdRcgShouObj(region, city, cityCode, zoneCode,
      aoiExePre, aoiWdPre, exeRejectDeptDiff, aoiWdDeptDiff,
      aoiWdDistibuteError, aoiWdAoiIdDateIn, aoiWdDeDeliveredCodeDateIn,
      aoiAft, aoiAftRight, aoiAftWrong, aoiAftAddress, aoiAftAddressRight,
      aoiAftAddressWrong, aoiAftArss, aoiAftArssRight,
      aoiAftArssWrong)
  }

  def staRcgWdIndex(wdAllDataRdd: RDD[(String, JSONObject)]): RDD[(String, AreaWdRcgShouObj)] = {
    val rcgWdIndexRdd = wdAllDataRdd.map(obj => {
      val omsBody = obj._2.getJSONObject("oms_body")
      val finalZc = omsBody.getString("deptcode")
      var fvpZc: String = ""
      val fvp54Body = obj._2.getJSONObject("fvp_54_body")
      if (fvp54Body != null) {
        fvpZc = fvp54Body.getString("zoneCode")
      }
      var isRcgReject = 0
      if (StringUtils.nonEmpty(fvpZc) && StringUtils.nonEmpty(finalZc)
        && !fvpZc.equals(finalZc)) {
        isRcgReject = 1
      }
      var isWd = 0
      if (obj._2.containsKey("isWd")) {
        isWd = obj._2.getInteger("isWd")
      }
      var isWdReject = 0
      if (obj._2.containsKey("isReject")) {
        isWdReject = obj._2.getInteger("isReject")
      }
      var deptWdReject = 0
      if (obj._2.containsKey("deptDiff")) {
        deptWdReject = obj._2.getInteger("deptDiff")
      }
      var distributeWdReject = 0
      if (obj._2.containsKey("isDistribute")) {
        distributeWdReject = obj._2.getInteger("isDistribute")
      }
      var aoiIdDateInWdReject = 0
      if (obj._2.containsKey("aoiIdDateIn")) {
        aoiIdDateInWdReject = obj._2.getInteger("aoiIdDateIn")
      }
      var deliveredCodeDateInWdReject = 0
      if (obj._2.containsKey("deliveredCodeDateIn")) {
        deliveredCodeDateInWdReject = obj._2.getInteger("deliveredCodeDateIn")
      }
      val cityCode = obj._2.getString("cityCode")
      val city = obj._2.getString("city")
      val region = obj._2.getString("region")
      val addressAoiCnt = checkEmpty(omsBody.getString("syncAoiCode")) | checkEmpty(omsBody.getString("asyncAoiCode"))
      var arssAoiCnt = 0
      if (addressAoiCnt == 0 && checkEmpty(omsBody.getString("arssAoiCode")) == 1) {
        arssAoiCnt = 1
      }
      val aoiPre = 1
      var aoiAft = 0
      var aoiAftRight = 0
      var aoiAftWrong = 0
      var aoiAftAddress = 0
      var aoiAftAddressRight = 0
      var aoiAftAddressWrong = 0
      var aoiAftArss = 0
      var aoiAftArssRight = 0
      var aoiAftArssWrong = 0

      if (isRcgReject == 0) {
        aoiAft = 1
        aoiAftAddress = addressAoiCnt
        aoiAftArss = arssAoiCnt

        if (isWd == 1 && isWdReject == 0) {
          aoiAftWrong = 1
          aoiAftAddressWrong = addressAoiCnt
          aoiAftArssWrong = arssAoiCnt
        } else {
          aoiAftRight = 1
          aoiAftAddressRight = addressAoiCnt
          aoiAftArssRight = arssAoiCnt
        }
      }
      (cityCode + "_" + city + "_" + fvpZc, AreaWdRcgShouObj(region, city, cityCode, fvpZc,
        aoiPre, isWd, isRcgReject, deptWdReject, distributeWdReject,
        aoiIdDateInWdReject, deliveredCodeDateInWdReject,
        aoiAft, aoiAftRight, aoiAftWrong, aoiAftAddress, aoiAftAddressRight,
        aoiAftAddressWrong, aoiAftArss, aoiAftArssRight,
        aoiAftArssWrong))
    }).reduceByKey((obj1, obj2) => {
      mergeAreaWdRcg(obj1, obj2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("按照城市网点聚合后数量：" + rcgWdIndexRdd.count())
//    rcgWdIndexRdd.collect().foreach(obj=>{
//      logger.error(obj)
//    })
    wdAllDataRdd.unpersist()
    rcgWdIndexRdd
  }

  def parseWdDataRdd(spark: SparkSession, cityMap: Map[String, ArrayBuffer[Array[String]]]): RDD[(String, JSONObject)] = {
    logger.error("获取执行表数据")
    val executeDataRdd = getExecuteDataRdd(spark)
    logger.error("获取日志表数据")
    val logDataRdd = getOmsLogRddOrderNo(spark, logDayMin, incDay)
    logger.error("关联执行表和日志表")
    val fvpOmsJoinDataRdd = joinFvpOmsDataRdd(logDataRdd, executeDataRdd)
    logger.error("过滤无效数据")
    val validDataRdd = filterValidRdd(spark, fvpOmsJoinDataRdd)
    val standardValidData = standardData(validDataRdd, cityMap)
    logger.error("计算错分数据")
    val wdAllDataRdd = calWdAllDataRdd(spark, standardValidData)
    logger.error("关联识别错分数据")
    val rcgWdTotalRdd = joinRcgWd(standardValidData, wdAllDataRdd)
    rcgWdTotalRdd
  }

  def mergeRcgWdObj(obj1: (String, String, AreaRcgShouObj, AreaWdRcgShouObj), obj2: (String, String, AreaRcgShouObj, AreaWdRcgShouObj)):
  (String, String, AreaRcgShouObj, AreaWdRcgShouObj) = {
    val areaRcgObj = mergeRcgIndex(obj1._3, obj2._3)
    var areaWdRcgObj = mergeAreaWdRcg(obj1._4, obj2._4)
    (obj1._1, obj1._2, areaRcgObj, areaWdRcgObj)
  }

  def joinTotalRcgWd(rcgIndexRdd: RDD[(String, AreaRcgShouObj)], staRcgWdIndexRdd: RDD[(String, AreaWdRcgShouObj)]): RDD[(String, String, AreaRcgShouObj, AreaWdRcgShouObj)] = {
    val rcgIndexRddConvert = rcgIndexRdd.map(obj=>{
      val areaWdRcgObj = AreaWdRcgShouObj(obj._2.region,obj._2.city,
        obj._2.cityCode,obj._2.zoneCode,
        0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
      (obj._1,(obj._2,areaWdRcgObj))
    })
    val staRcgWdIndexRddConvert = staRcgWdIndexRdd.map(obj=>{
      val areaRcgObj = AreaRcgShouObj(obj._2.region,obj._2.city,
        obj._2.cityCode,obj._2.zoneCode,
        0, 0, 0, 0)
      (obj._1,(areaRcgObj,obj._2))
    })

    val zcRdd = rcgIndexRddConvert.union(staRcgWdIndexRddConvert).reduceByKey((obj1,obj2)=>{
      (mergeRcgIndex(obj1._1,obj2._1),mergeAreaWdRcg(obj1._2,obj2._2))
    }).map(obj => {
      val areaRcgObj = obj._2._1
      val areaWdRcgObj = obj._2._2
      val key = Array(incDay, areaRcgObj.region, areaRcgObj.cityCode, areaRcgObj.city, areaRcgObj.zoneCode)
      (key.mkString("_"), ("ZC", areaRcgObj.zoneCode, areaRcgObj, areaWdRcgObj))
    }).persist(StorageLevel.DISK_ONLY)

    val cityRdd = zcRdd.map(obj => {
      val areaRcgObj = obj._2._3
      val areaWdRcgObj = obj._2._4
      val key = Array(incDay, areaRcgObj.region, areaRcgObj.cityCode, areaRcgObj.city, "ALL")
      val areaRcgObjNew = areaRcgObj.copy(zoneCode = "ALL")
      (key.mkString("_"), ("CITY", areaRcgObjNew.city, areaRcgObjNew, areaWdRcgObj))
    }).reduceByKey((obj1, obj2) => {
      mergeRcgWdObj(obj1, obj2)
    }).persist(StorageLevel.DISK_ONLY)

    val regionRdd = cityRdd.map(obj => {
      val areaRcgObj = obj._2._3
      val areaWdRcgObj = obj._2._4
      val key = Array(incDay, areaRcgObj.region, "ALL", "ALL", "ALL")
      val areaRcgObjNew = areaRcgObj.copy(city = "ALL", cityCode = "ALL")
      (key.mkString("_"), ("REGION", areaRcgObjNew.region, areaRcgObjNew, areaWdRcgObj))
    }).reduceByKey((obj1, obj2) => {
      mergeRcgWdObj(obj1, obj2)
    }).persist(StorageLevel.DISK_ONLY)


    val dateRdd = regionRdd.filter(obj=>{
      val region = obj._2._2
      !region.contains("香港") && !region.contains("澳门") && !region.contains("台湾")
    }).map(obj => {
      val areaRcgObj = obj._2._3
      val areaWdRcgObj = obj._2._4
      val key = Array(incDay, "ALL", "ALL", "ALL", "ALL")
      val areaRcgObjNew = areaRcgObj.copy(region = "ALL")
      (key.mkString("_"), ("ALL", "ALL", areaRcgObjNew, areaWdRcgObj))
    }).reduceByKey((obj1, obj2) => {
      mergeRcgWdObj(obj1, obj2)
    }).persist(StorageLevel.DISK_ONLY)
    dateRdd.collect().foreach(obj => {
      logger.error(obj)
    })
    zcRdd.union(regionRdd).union(cityRdd).union(dateRdd).values
  }

  def getJSONValueStr(obj: JSONObject, key: String): String = {
    if (obj == null) {
      return ""
    }
    val value = obj.getString(key)
    if (value == null) {
      return ""
    }
    value
  }

  def getJSONObjSubObjKey(obj: JSONObject, key: String): String = {
    if (obj == null) {
      return ""
    }
    val value = obj.getJSONObject(key)
    if (value == null) {
      return ""
    }
    value.keySet().mkString(";")
  }
  def getJSONObjSubObjStr(obj: JSONObject, key: String): String = {
    if (obj == null) {
      return ""
    }
    val value = obj.getJSONObject(key)
    if (value == null) {
      return ""
    }
    value.toJSONString
  }

  def save_data_hive(spark: SparkSession, dataType: String, dataRdd: RDD[JSONObject]): Unit = {

    val rows = dataRdd.map(obj => {
      var row: Row = null
      try {
        val omsBody = obj.getJSONObject("oms_body")
        val sysOrderNo = omsBody.getString("sysOrderNo")
        val orderNo = omsBody.getString("orderNo")
        val cityCode = omsBody.getString("cityCode")
        val city = omsBody.getString("city")
        val address = omsBody.getString("address")
        val finalAoiCode = omsBody.getString("finalAoiCode")
        val exeBody = obj.getJSONObject("exe_body")
        val executionAoiId = getJSONValueStr(exeBody,"aoi_id")
        val batchCodeExecute = getJSONValueStr(exeBody,"batch_code")
        val actTime = getJSONValueStr(exeBody,"act_time")
        val distributeCode = getJSONValueStr(exeBody,"distribute_code")
        val actCode = getJSONValueStr(exeBody,"act_code")
        val destDeptCode = getJSONValueStr(exeBody,"dest_dept_code")
        val realDistributeTime = getJSONValueStr(exeBody,"real_distribute_time")
        val executionDate = getJSONValueStr(exeBody,"date")
        val isDistributeReceipt = getJSONValueStr(exeBody,"is_distribute_receipt")
        val finalBatchCode = getJSONValueStr(obj, "finalBatchCode")
        val batchResultBody = getJSONObjSubObjStr(obj,"batchResult_body")
        val finalBatchCode1 = getJSONValueStr(obj, "finalBatchCode1")
        val batchResultBody1 = getJSONObjSubObjStr(obj,"batchResult_body1")
        val finalBatchCode2 = getJSONValueStr(obj, "finalBatchCode2")
        val batchResultBody2 = getJSONObjSubObjStr(obj,"batchResult_body2")
        val allaoilist = getJSONValueStr(obj, "allaoilist")
        val empnolist = getJSONValueStr(obj, "empnolist")
        row = RowFactory.create(dataType, sysOrderNo, cityCode, city,
          address, finalAoiCode,orderNo,executionAoiId,batchCodeExecute,
          actTime,distributeCode,actCode,destDeptCode,realDistributeTime,
          executionDate,finalBatchCode,batchResultBody,finalBatchCode1,
          batchResultBody1,finalBatchCode2,batchResultBody2,allaoilist,
          empnolist, isDistributeReceipt,JSONUtils.getJsonValue(omsBody,"province",""),
          JSONUtils.getJsonValue(omsBody,"county",""),JSONUtils.getJsonValue(omsBody,"phone",""),
          JSONUtils.getJsonValue(omsBody,"mobile",""),JSONUtils.getJsonValue(omsBody,"company",""),
          JSONUtils.getJsonValue(omsBody,"deptcode",""),JSONUtils.getJsonValue(omsBody,"teamcode","")
        )
      } catch {
        case e: Exception => logger.error(obj, e)
      }
      row
    }).filter(_ != null).repartition(10)

    val structs = Array("dataType", "sysOrderNo", "cityCode", "city",
      "address", "finalAoiCode","orderNo","execution_aoi_id","batch_code_execute",
    "act_time","distribute_code","act_code","dest_dept_code","real_distribute_time",
    "execution_date","final_batch_code","batchresult_body","final_batch_code1",
    "batchresult_body1","final_batch_code2","batchresult_body2","allaoilist",
      "empnolist", "is_distribute_receipt","province","county","phone","mobile",
      "company","deptcode","teamcode")

    val structFileds = new util.ArrayList[StructField]()
    for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
    val hiveTableName = "aoi_fc_for_area"
    val structType = DataTypes.createStructType(structFileds)
    val df: DataFrame = spark.createDataFrame(rows, structType)
    val tempView = String.format("%s_temp_view", hiveTableName)
    df.createOrReplaceTempView(tempView)
    if (saveStep == 0) {
      val deleteSql = String.format("alter table dm_gis.%s drop if exists partition(inc_day='%s')", hiveTableName, incDay)
      logger.error(">>>删除分区：" + deleteSql)
      spark.sql(deleteSql)
    }
    saveStep = saveStep + 1
    val createPartitionSql = String.format("alter table dm_gis.%s add if not exists partition(inc_day = '%s')", hiveTableName, incDay)
    logger.error(">>>新建分区：" + createPartitionSql)
    spark.sql(createPartitionSql)
    val insertSql = String.format("insert into dm_gis.%s partition(inc_day = '%s') select * from %s", hiveTableName, incDay, tempView)
    logger.error(">>>插入数据：" + insertSql)
    spark.sql(insertSql)
  }

  def saveStaToDb(totalRcgWd: RDD[(String, String, AreaRcgShouObj, AreaWdRcgShouObj)]): Unit = {
    val conn = DbUtils.getConnection(javaUtil)
    val md5Instance = MD5Util.getMD5Instance
    val PU_AOI_FC_FOR_AREA = "PU_AOI_FC_FOR_AREA"
    try {
      val delRcgSql = String.format(s"delete from $PU_AOI_FC_FOR_AREA where stat_date='%s'", incDay)
      logger.error(">>>保存之前，删除rcg一天的数据:" + delRcgSql)
      DbUtils.executeSql(conn, delRcgSql)
      val rcgInsertSql = s"insert into $PU_AOI_FC_FOR_AREA (`ID`," +
        s"`STAT_TYPE`,`STAT_TYPE_CONTENT`,`STAT_DATE`,`REGION`,`CITY`," +
        s"`CITY_CODE`,`ZONECODE`,`REQ`,AOI,AOI_ADDR,AOI_ARSS," +
        s"`AOI_EXE_PRE`,`AOI_WD_PRE`," +
        s"`EXE_REJECT_DEPT_DIFF`,`AOI_WD_DEPT_DIFF`,`AOI_WD_DISTRIBUTE_ERR`," +
        s"`AOI_WD_AOIID`,`AOI_WD_DELIVEREDCODE`,`AOI_AFT`,`AOI_AFT_RIGHT`," +
        s"`AOI_AFT_WRONG`,`AOI_AFT_ADDR`,`AOI_AFT_ADDR_RIGHT`,`AOI_AFT_ADDR_WRONG`," +
        s"`AOI_AFT_ARSS`,`AOI_AFT_ARSS_RIGHT`,`AOI_AFT_ARSS_WRONG`) " +
        s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
      logger.error(">>>rcgInsertSql:" + rcgInsertSql)
      var count = 0
      totalRcgWd.collect().foreach(o => {
        val statType = o._1
        val statContent = o._2
        val areaRcgObj = o._3
        val areaWdRcgObj = o._4
        count = count + 1
        if (count % 1000 == 0) {
          logger.error(">>>count:" + count)
        }
        //计算md5值
        val id = MD5Util.getMD5(md5Instance, Array(incDay, areaRcgObj.region, areaRcgObj.city,areaRcgObj.cityCode, areaRcgObj.zoneCode).mkString("_"))
        val rcgParams = Array(id, statType, statContent, incDay, areaRcgObj.region, areaRcgObj.city, areaRcgObj.cityCode, areaRcgObj.zoneCode,
          areaRcgObj.req, areaRcgObj.aoiCnt, areaRcgObj.addressAoiCnt, areaRcgObj.arssAoiCnt, areaWdRcgObj.aoiExePre, areaWdRcgObj.aoiWdPre,
          areaWdRcgObj.exeRejectDeptDiff, areaWdRcgObj.aoiWdDeptDiff, areaWdRcgObj.aoiWdDistibuteError,
          areaWdRcgObj.aoiWdAoiIdDateIn, areaWdRcgObj.aoiWdDeliveredCodeDateIn, areaWdRcgObj.aoiAft, areaWdRcgObj.aoiAftRight,
          areaWdRcgObj.aoiAftWrong, areaWdRcgObj.aoiAftAddress, areaWdRcgObj.aoiAftAddressRight, areaWdRcgObj.aoiAftAddressWrong,
          areaWdRcgObj.aoiAftArss, areaWdRcgObj.aoiAftArssRight, areaWdRcgObj.aoiAftArssWrong
        )
        //        logger.error(rcgParams)
        DbUtils.execute(conn, rcgInsertSql, rcgParams)
      })
      logger.error(">>>rcg按维度指标入库结束！")
    } catch {
      case e: Exception => logger.error(">>>rcg按维度指标入库失败！" + e)
    }
  }

  def startSta(spark: SparkSession): Unit = {
    logger.error("统计收件识别率")
    logger.error("获取数据信息")
    val rcgRdd = parseDataRdd(spark)
    logger.error("统计识别率指标指标数据")
    val cityRegionMap = CityRegion.getCityReionMap(javaUtil)
    val cityMap = spark.sparkContext.broadcast(cityRegionMap).value
    val rcgIndexRdd = statRcgIndex(rcgRdd, cityMap)
    logger.error("开始错分数据步骤")
    val wdDataRdd = parseWdDataRdd(spark, cityMap)
    logger.error("统计识别错分数据")
    val staRcgWdIndexRdd = staRcgWdIndex(wdDataRdd)
    logger.error("关联识别量和错分数据")
    val totalRcgWd = joinTotalRcgWd(rcgIndexRdd, staRcgWdIndexRdd)
    logger.error("指标数据入库")
    saveStaToDb(totalRcgWd)
  }


  def start(): Unit = {

    val conf = Util.getSparkConf(appName)
    conf.set("spark.executor.memory","25g")
    conf.set("spark.yarn.executor.memoryOverhead","8g")
    conf.set("spark.num.executors","20")
    conf.set("spark.driver.memory","20g")
    val spark = SparkSession.builder().config(conf).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    startSta(spark)
    logger.error("统计完毕")
  }
}
