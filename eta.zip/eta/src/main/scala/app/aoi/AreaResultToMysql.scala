package app.aoi

import Utils.{DateUtil, DbUtils, JSONUtils, Util}

import java.sql.Connection
import java.util
import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01374443 on 2019/3/5.
  */
object AreaResultToMysql {
  @transient lazy val logger: Logger = Logger.getLogger(AreaResultToMysql.getClass)

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val are_db_file="area_db.properties"
  val indexMap = Map("华南"->1,"华东"->2,"华北"->3,"中西"->4,"港澳台"->5)

  def main(args: Array[String]): Unit = {
    var beginDay: String = Util.dateDelta(-2, "")
    var days = 1
    if (args.length >= 2) {
      beginDay = args(0)
      days = args(1).toInt
    }
    logger.error(beginDay + "," + days)
    start(beginDay, days)
  }

  def deleteEmpty(connection:Connection,tableName:String,date:String): Unit ={
    for(i <- 1 to 5){
      val delRcgSql = s"delete from $tableName$i where inc_day='$date'"
      logger.error(">>>保存之前，删除rcg一天的数据:" + delRcgSql)
      DbUtils.executeSql(connection, delRcgSql)
    }
  }
  def deleteWd(connection:Connection,tableName:String,date:String): Unit ={
    for(i <- 1 to 5){
      val delRcgSql = s"delete from $tableName$i where inc_day='$date'"
      logger.error(">>>保存之前，删除rcg一天的数据:" + delRcgSql)
      DbUtils.executeSql(connection, delRcgSql)
    }
  }
  def saveNonAoiToRcgDb(emptyRdd: RDD[(String,JSONObject)],date:String): Unit = {
    val conn = DbUtils.getConnection(are_db_file)
    val DLV_AOI_FOR_AREA_EMPTY_DETAIL = "aoi_wd_for_area_empty_aoi_"
    try {
      deleteEmpty(conn,DLV_AOI_FOR_AREA_EMPTY_DETAIL,date)
      val bodyKeyArray: Array[String] = Array("area","region","city","citycode",
        "zonecode","waybillno","barscantm","req_addresseeaddr",
        "gisautozc","couriercode","finalzc","finalzcsrc",
        "gisgid","rebodygistime","rebodyarsszc","arssreop",
        "arssreoptime","gis_to_sys_src","inc_day"
      )
      val areaSet = indexMap.keySet
      for( area<-areaSet){
        logger.error("area:"+area)
        var count = 0
        val index = indexMap(area)
        val rcgInsertSql = s"insert into $DLV_AOI_FOR_AREA_EMPTY_DETAIL$index (area," +
          s"region,city,citycode,zonecode,waybillno,barscantm,req_addresseeaddr," +
          s"gisautozc,couriercode,finalzc,finalzcsrc,gisgid,rebodygistime," +
          s"rebodyarsszc,arssreop,arssreoptime,gis_to_sys_src,inc_day) " +
          s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        val areaRdd = emptyRdd.filter(obj=> area.equals(obj._1))
        val parmArray = new ArrayBuffer[Array[String]]
        areaRdd.collect().foreach(obj=>{
          count = count + 1
          val body = obj._2
          val dataList = new util.ArrayList[String]()
          for(bodyKey <- bodyKeyArray){
            dataList.add(JSONUtil.getJsonVal(body,bodyKey,""))
          }
          if (count % 1000 == 0) {
            logger.error(">>>count:" + count)
          }


//          logger.error(">>>rcgInsertSql:" + rcgInsertSql)
          val detailArray: Array[String] = Array(dataList.get(0),dataList.get(1),
            dataList.get(2),dataList.get(3),dataList.get(4),dataList.get(5),
            dataList.get(6),dataList.get(7),dataList.get(8),dataList.get(9),
            dataList.get(10),dataList.get(11),dataList.get(12),dataList.get(13),
            dataList.get(14),dataList.get(15),dataList.get(16),dataList.get(17),
            dataList.get(18))
          parmArray.append(detailArray)
          if(count % 10 == 0){
            DbUtils.executeBatchSql(conn, rcgInsertSql, parmArray)
            parmArray.clear()
          }
        })
        if(parmArray.nonEmpty){
          DbUtils.executeBatchSql(conn, rcgInsertSql, parmArray)
          parmArray.clear()
        }
      }
      logger.error(">>>rcg为空的明细入库结束！")
    } catch {
      case e: Exception => logger.error(">>>rcg为空的明细入库失败！" + e)
    }
  }



  def saveWdAoiToRcgDb(wdRdd: RDD[(String,JSONObject)],date:String): Unit = {
    val conn = DbUtils.getConnection(are_db_file)
    val DLV_AOI_FOR_AREA_WD_DETAIL = "aoi_wd_for_area_wrong_aoi_"
    try {
      deleteWd(conn,DLV_AOI_FOR_AREA_WD_DETAIL,date)
      val bodyKeyArray: Array[String] = Array("area","region","city",
        "citycode","zonecode","waybillno","barscantm","req_addresseeaddr",
        "distribute_code","delivered_code","finalaoicode","finalaoisrc",
        "gisautoaoi","gisgid","rebodygistime","rebodyarssaoi","arssreop",
        "arssreoptime","awsmaoi","awsmreop","awsmreoptime","inc_day","finalaoiname",
        "req_comp_name", "keywords", "idlist"
      )
      val areaSet = indexMap.keySet
      for( area<-areaSet){
        logger.error("area:"+area)
        var count = 0
        val index = indexMap(area)
        val rcgInsertSql = s"insert into $DLV_AOI_FOR_AREA_WD_DETAIL$index (area,region,city,citycode,zonecode," +
          s"waybillno,barscantm,req_addresseeaddr,distribute_code,delivered_code," +
          s"finalaoicode,finalaoisrc,gisautoaoi,gisgid,rebodygistime," +
          s"rebodyarssaoi,arssreop,arssreoptime,awsmaoi,awsmreop,awsmreoptime," +
          s"inc_day,finalaoiname, req_comp_name, keywords, idlist) " +
          s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        val areaRdd = wdRdd.filter(obj=> area.equals(obj._1))
        val parmArray = new ArrayBuffer[Array[String]]
        areaRdd.collect().foreach(obj=>{
          count = count + 1
          val body = obj._2
          val dataList = new util.ArrayList[String]()
          for(bodyKey <- bodyKeyArray){
            if(bodyKey.equals("keywords")){
              dataList.add(JSONUtil.getJsonVal(body,bodyKey,"").split("$")(0))
            }else{
              dataList.add(JSONUtil.getJsonVal(body,bodyKey,""))
            }

          }
          if (count % 1000 == 0) {
            logger.error(">>>count:" + count)
          }

//          logger.error(">>>rcgInsertSql:" + rcgInsertSql)
          val detailArray: Array[String] = Array(dataList.get(0),dataList.get(1),
            dataList.get(2),dataList.get(3),dataList.get(4),dataList.get(5),
            dataList.get(6),dataList.get(7),dataList.get(8),dataList.get(9),
            dataList.get(10),dataList.get(11),dataList.get(12),dataList.get(13),
            dataList.get(14),dataList.get(15),dataList.get(16),dataList.get(17),
            dataList.get(18),dataList.get(19),dataList.get(20),dataList.get(21),
            dataList.get(22),dataList.get(23),dataList.get(24),dataList.get(25))
          parmArray.append(detailArray)
          if(count % 10 == 0){
            DbUtils.executeBatchSql(conn, rcgInsertSql, parmArray)
            parmArray.clear()
          }
        })
        if(parmArray.nonEmpty){
          DbUtils.executeBatchSql(conn, rcgInsertSql, parmArray)
          parmArray.clear()
        }
      }
      logger.error(">>>rcg错分的明细入库结束！")
    } catch {
      case e: Exception => logger.error(">>>rcg错分的明细入库失败！" + e)
    }
  }

  def fetchEmptyData(spark: SparkSession, date: String):RDD[(String,JSONObject)] = {
      val emptyColumns = Array("area","region","city",
        "citycode","zonecode","waybillno","barscantm",
        "req_addresseeaddr","gisautozc","couriercode",
        "finalzc","finalzcsrc","gisgid","rebodygistime",
        "rebodyarsszc","arssreop","arssreoptime",
        "gis_to_sys_src","inc_day")
      val emptyTable = "dm_gis.aoi_wd_for_area_empty_aoi"
    val sqlBuilder = new StringBuilder()
    for (i <- emptyColumns.indices) {
        sqlBuilder.append(emptyColumns(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectEmptySql =
      s"""select ${sqlBuilder.toString()} from $emptyTable
         | where inc_day ='$date'
      """.stripMargin
    println("selectEmptySql:" + selectEmptySql)
    val emptySqlRdd = spark.sql(selectEmptySql)
      .repartition(200)
      .rdd
      .map(row => {
        val empty_body = new JSONObject()
        for (i <- emptyColumns.indices) {
          empty_body.put(emptyColumns(i), row.getString(i).trim)
        }
        val area = empty_body.getString("area")
        (area, empty_body)
      }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("缺失表数量：" + emptySqlRdd.count())
    emptySqlRdd
  }

  def fetchWdData(spark: SparkSession, date: String):RDD[(String,JSONObject)] = {
    val wdColumns = Array("area","region","city","citycode","zonecode",
      "waybillno","barscantm","req_addresseeaddr","distribute_code",
      "delivered_code","finalaoicode","finalaoisrc","gisautoaoi",
      "gisgid","rebodygistime","rebodyarssaoi","arssreop","arssreoptime",
      "awsmaoi","awsmreop","awsmreoptime","inc_day","finalaoiname", "req_comp_name",
      "keywords", "idlist")
    val wdTable = "dm_gis.aoi_wd_for_area_wrong_aoi"
    val sqlBuilder = new StringBuilder()
    for (i <- wdColumns.indices) {
      sqlBuilder.append(wdColumns(i)).append(",")
    }
    sqlBuilder.deleteCharAt(sqlBuilder.length - 1)
    val selectWdSql =
      s"""select ${sqlBuilder.toString()} from $wdTable
         | where inc_day ='$date'
      """.stripMargin
    println("selectWdSql:" + selectWdSql)
    val wdSqlRdd = spark.sql(selectWdSql)
      .repartition(200)
      .rdd
      .map(row => {
        val wd_body = new JSONObject()
        for (i <- wdColumns.indices) {
          wd_body.put(wdColumns(i), row.getString(i).trim)
        }
        val area = wd_body.getString("area")
        var idList:JSONObject = null
        try{
          idList = JSONUtils.parseJSONObject(wd_body.getString("idlist"))
        }catch {
          case e:Exception => logger.error(e)
        }
        wd_body.put("gisgid","")
        val finalAoiSrc = JSONUtil.getJsonVal(wd_body,"finalaoisrc","")
        if("norm".equals(finalAoiSrc)){
          wd_body.put("gisgid",JSONUtil.getJsonVal(idList,"normId",""))
        }
        (area, wd_body)
      }).filter(_._1 != null).persist(StorageLevel.DISK_ONLY)
    logger.error("错分表数量：" + wdSqlRdd.count())
    wdSqlRdd
  }

  def startSta(spark: SparkSession, date: String): Unit = {
    logger.error("获取错分数据")
    val wdRdd= fetchWdData(spark,date)
    logger.error("错分数据入库")
    saveWdAoiToRcgDb(wdRdd,date)

    logger.error("获取缺失数据")
    val emptyRdd= fetchEmptyData(spark,date)
    logger.error("缺失数据入库")
    saveNonAoiToRcgDb(emptyRdd,date)

  }


  def start(beginDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    for (i <- 0 until days) {
      val date = DateUtil.getDateStr(beginDay, i)
      logger.error("date:" + date)
      startSta(spark, date)
    }
    logger.error("统计完毕")
  }


}
