package app

import Utils.SparkUtils.writeToHive
import Utils.StringUtils.AESCode
import com.sf.gis.java.base.util.SparkUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import java.util.Date

/**
 * GIS-RSS-SCM:【规划路径专项】承运商平台日志数据同步需求_V1.0
 * 需求内容：将承运商平台日志数据导入hive,承运商注册日志表,用户登录日志表,线路调整记录表 四张表每小时同步一次，按天分区
 * 需求方：张翠霞（01369612）
 * @author 徐游飞（01417347）
 * 任务ID：776622
 * 任务名称：承运商平台日志数据同步
 */
object EtaCarrierLogData2Hive {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  val url = "jdbc:mysql://plan-m.db.sfcloud.local:3306/plan?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
  val driver = "com.mysql.jdbc.Driver"
  val username = "plan"
  val password = "plan20210121#"
  // 表名
  val tableName1 = "plan_user_carrier"
  val tableName2 = "ua_sys_log"
  val tableName3 = "plan_line_operation_detail"
  val tableName4 = "plan_line_feedback"

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    // 休眠90秒，防止有23点59分之后的数据没有获取到
    Thread.sleep(90*1000)
    println("任务开始,当前时间为："+ new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date))

    import spark.implicits._
    // 读取mysql的 承运商注册日志表
    val connMap1 = Map("url" -> url, "user" -> username,"password" -> password, "dbtable" -> tableName1,"driver" -> driver)
    val df_carrier = spark.read.format("jdbc").options(connMap1).load()
      //.filter(timeToCustomTime2('create_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")) === inc_day)
      .withColumn("create_time_yyyyMMdd",timeToCustomTime2('create_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("username",'emp_code)
      .withColumn("emp_code",AESCode('emp_code,lit("encrypt")))   // 加密
      .withColumn("emp_code_1",AESCode('emp_code,lit("decrypt"))) // 解密
      .withColumn("inc_day",lit(inc_day))

    val cols_1 = spark.sql("""select * from dm_gis.plan_user_carrier limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_carrier.filter('create_time_yyyyMMdd === inc_day).select(cols_1: _*),Seq("inc_day"),"dm_gis.plan_user_carrier")

    // 读取mysql的 用户登录日志表
    val connMap2 = Map("url" -> url, "user" -> username,"password" -> password, "dbtable" -> tableName2,"driver" -> driver)
    val df_log = spark.read.format("jdbc").options(connMap2).load()
      .join(df_carrier.select("username","carrier_id"), Seq("username"), "inner")  //关联用户表只保留承运商的登录日志
      .filter(timeToCustomTime2('create_date,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")) === inc_day)
      .withColumn("inc_day",lit(inc_day))

    val cols_2 = spark.sql("""select * from dm_gis.ua_sys_log_user limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_log.select(cols_2: _*),Seq("inc_day"),"dm_gis.ua_sys_log_user")

    // 读取mysql的 线路调整记录表
    val connMap3 = Map("url" -> url, "user" -> username,"password" -> password, "dbtable" -> tableName3,"driver" -> driver)
    val df_operation = spark.read.format("jdbc").options(connMap3).load()
      .filter(timeToCustomTime2('report_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")) === inc_day)
      .withColumn("inc_day",lit(inc_day))

    val cols_3 = spark.sql("""select * from dm_gis.plan_line_operation_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_operation.select(cols_3: _*),Seq("inc_day"),"dm_gis.plan_line_operation_detail")

    // 读取mysql的 规划线路承运商反馈表
    val connMap4 = Map("url" -> url, "user" -> username,"password" -> password, "dbtable" -> tableName4,"driver" -> driver)
    val df_feedback = spark.read.format("jdbc").options(connMap4).load()
      .filter(timeToCustomTime2('create_time,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")) === inc_day)
      .withColumn("inc_day",lit(inc_day))

    val cols_4 = spark.sql("""select * from dm_gis.plan_line_feedback_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_feedback.select(cols_4: _*),Seq("inc_day"),"dm_gis.plan_line_feedback_detail")


    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
    logger.error("+++++++++    任务结束20231128    ++++++++")
    logger.error(s"+++++++++++++++++++++++++++++++++++++++++++")
  }

  /**
   * 两种不同格式时间字符串相互转换
   * @param time
   * @param format
   * @param newFormat
   * @throws
   * @return
   */

  def timeToCustomTime2 = udf((time: String,format1: String,format2: String) => {
    val format = new SimpleDateFormat(format1)
    val newFormat = new SimpleDateFormat(format2)

    var standardTime = new Date()
    var newTime = ""
    try{
      standardTime = format.parse(time)
      newTime = newFormat.format(standardTime)
    }catch {
      case e: Exception => println(">>>日期转换异常"+e)
    }
    newTime
  })


}
