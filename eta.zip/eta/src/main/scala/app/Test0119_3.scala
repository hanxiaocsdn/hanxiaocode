package app

import java.util

import Utils.CommonTools
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.DistanceUtils.getDistance
import com.sf.gis.java.base.util.{HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.immutable.Seq
import scala.collection.JavaConversions._
/**
 * 一次性任务
 */
object Test0119_3 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)
  val GET_LINE: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/getLine"
  val queryByLineRequireId: String = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/queryByLineRequireId"
  val Rectify_URL: String = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val parallelism = 10
  val akMinuLimit = 2000

  def execute(spark: SparkSession, inc_day: String) = {
    val dayBefore1 = "20240123"

    import spark.implicits._
    // 获取线下数据
    val rdd_1 = spark.read
      .format("csv")
      .option("sep", "\t")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("hdfs://sfbdp1/user/01405644/upload/task_20240123.csv")
      .withColumn("ton", 'ton.cast("double"))
      .rdd.map(CommonTools.row2Json)

    val rdd_toll: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, rdd_1, runGetLineInteface, 40, "", 8000)
    val rdd_toll_mid: RDD[JSONObject] = rdd_toll.flatMap(obj => {
      val retJSONObject: JSONObject = JSONUtil.getJsonObjectMulti(obj, "retJSONObject")
      //解析接口返回值
      val httpData: (String, String, util.ArrayList[String], String) = parseGetLine2HttpData(retJSONObject)
      val jy_track2_array = httpData._3
      val codeStatue_1 = httpData._1
      val msg_1 = httpData._2
      val allArray = new util.ArrayList[JSONObject]()
      if(jy_track2_array!=null){
        for (i <- 0 until (jy_track2_array.size())) {
          val tmpObj = new JSONObject()
          val jy_track2: String = jy_track2_array(i)
          tmpObj.fluentPutAll(obj)
          tmpObj.put("jy_track2", jy_track2)
          tmpObj.put("code_statue_1", codeStatue_1)
          tmpObj.put("msg_1", msg_1)
          allArray.append(tmpObj)
        }
      }
      allArray.iterator()
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    rdd_toll_mid.take(10).foreach(println(_))
    val rdd_toll1: RDD[JSONObject] = rdd_toll_mid.filter(obj=>{
      StringUtils.isNoneEmpty(obj.getString("jy_track2")) && obj.getString("jy_track2") != "[]"
    })
    logger.error("调queryByLineRequireId后数据量:"+rdd_toll1.count())
    // 调qm接口获取路桥费
    val rdd_toll2: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, rdd_toll1, runRectifyInteface, 40, "", 2000)
    val df_ret = rdd_toll2.repartition(1200).map(obj => {
        val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
        val ton = JSONUtil.getJsonVal(obj, "ton", "")
        val line_require_id = JSONUtil.getJsonVal(obj, "line_require_id", "")

        val std_id = JSONUtil.getJsonVal(obj, "std_id", "")
        val gh_road_cost = JSONUtil.getJsonVal(obj, "gh_road_cost", "")
        val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
        val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
        val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
        val stop_dept = JSONUtil.getJsonVal(obj, "stop_dept", "")
        val month = JSONUtil.getJsonVal(obj, "month", "")
        val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
        val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
        val road_cost = JSONUtil.getJsonVal(obj, "road_cost", "")

        val jy_track2 = JSONUtil.getJsonVal(obj, "jy_track2", "")
        val toll_charge = JSONUtil.getJsonVal(obj, "tollCharge", "")
        val toll_mileage = JSONUtil.getJsonVal(obj, "tollMileage", "")
        val etc_toll_charge = JSONUtil.getJsonVal(obj, "etcTollCharge", "")

        val code_statue_1 = JSONUtil.getJsonVal(obj, "code_statue_1", "")
        val msg_1 = JSONUtil.getJsonVal(obj, "msg_1", "")
        val code_statue_2 = JSONUtil.getJsonVal(obj, "code_statue_2", "")
        val msg_2 = JSONUtil.getJsonVal(obj, "param", "")


        (task_id,line_require_id, std_id, gh_road_cost, vehicle_serial, line_code, stop_dept, ton, month, start_dept, end_dept, road_cost,
          jy_track2, toll_charge,toll_mileage, etc_toll_charge, code_statue_1, msg_1, code_statue_2, msg_2)
      }).toDF("task_id", "task_subid", "std_id", "gh_road_cost", "vehicle_serial", "line_code", "stop_dept", "ton", "month", "start_dept", "end_dept",
        "road_cost","jy_track2", "toll_charge", "toll_mileage", "etc_toll_charge", "code_statue_1", "msg_1", "code_statue_2", "msg_2")
      .withColumn("inc_day", lit(dayBefore1))

    val cols = spark.sql("""select * from dm_gis.tmp_xyf_20240119_2 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, df_ret.select(cols: _*).coalesce(5), Seq("inc_day"), "dm_gis.tmp_xyf_20240119_2")

  }

  def runGetLineInteface(ak: String, obj: JSONObject): JSONObject = {
    val line_require_id = JSONUtil.getJsonVal(obj, "line_require_id", "")

    //初始化接口请求参数
    val param = new JSONObject()
//    param.put("optUserId", "ft80006323")
//    param.put("stdId", std_id)
//    param.put("containDeleted", "true")
//    param.put("ak", "5e86b3e45f664ecea1d59e6c591aa006")

//    param.put("ak", "5e86b3e45f664ecea1d59e6c591aa006")
//    param.put("optUserId", "ft80006323")
//    param.put("srcDeptcode", start_dept)
//    param.put("destDeptcode", end_dept)
//    param.put("lineCode", line_code)
//    param.put("vehicle", vehicle_type)

    param.put("ak", "5e86b3e45f664ecea1d59e6c591aa006")
    param.put("lineRequireId", line_require_id)


    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(queryByLineRequireId, param.toJSONString, 3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    obj.put("retJSONObject",retJSONObject)
    obj
  }

  def runRectifyInteface(ak: String, obj: JSONObject): JSONObject = {
    val jy_track2 = JSONUtil.getJsonVal(obj, "jy_track2", "")
    val ton = JSONUtil.getJsonDouble(obj, "ton", 0.0)

    var vehicle = 5
    val vehicleInfo = new JSONObject()
    if (ton == 1.0 || ton == 1.5) {
      vehicleInfo.put("load", 3.2)
      vehicleInfo.put("axis", 2)
      vehicleInfo.put("weight", 3.2)
      vehicleInfo.put("length", 3.2)
      vehicle = 5
    } else if (ton == 7.0 || ton == 14.0) {
      vehicleInfo.put("load", 7.2)
      vehicleInfo.put("axis", 2)
      vehicleInfo.put("weight", 7.2)
      vehicleInfo.put("length", 7.2)

      vehicle = 8
    }

    val tracks = new JSONArray()
    val tracks_arr = jy_track2.split("\\|")
    var time = 1693526400L

    for(i <- 0 until(tracks_arr.size)){

      val tmp_obj = new JSONObject()
      try{
        if (i == tracks_arr.size - 1) {
          val x1 = tracks_arr(i).split(",")(0).toDouble
          val y1 = tracks_arr(i).split(",")(1).toDouble
          time = time + 15
          tmp_obj.put("speed", 15.430000305175781)
          tmp_obj.put("time", time)
          tmp_obj.put("type", 1)
          tmp_obj.put("x", x1)
          tmp_obj.put("y", y1)

          tracks.add(tmp_obj)
        } else {
          val x1 = tracks_arr(i).split(",")(0).toDouble
          val y1 = tracks_arr(i).split(",")(1).toDouble

          val x2 = tracks_arr(i + 1).split(",")(0).toDouble
          val y2 = tracks_arr(i + 1).split(",")(1).toDouble

          val dis = getDistance(x1, y1, x2, y2)
          val t = (((dis / 1000) / 60) * 3600).ceil.toInt

          time = time + t
          tmp_obj.put("speed", 60)
          tmp_obj.put("time", time)
          tmp_obj.put("type", 1)
          tmp_obj.put("x", x1)
          tmp_obj.put("y", y1)

          tracks.add(tmp_obj)
        }
      }catch {
        case e: Exception => logger.error(e)
      }

    }

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("ak", "80e8781ff31d48afa5c603468c38c4a4")
    param.put("keeptype", 1)
    param.put("compensate", 1)
    param.put("vehicleInfo", vehicleInfo)
    param.put("tracks", tracks)
    param.put("vehicle", vehicle)
    param.put("retflag", 6)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(Rectify_URL, param.toJSONString, 3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val (codeStatue,msg,tollCharge,tollMileage,etcTollCharge) = parseRectifyHttpData(retJSONObject)
    obj.put("code_statue_2", codeStatue)
    obj.put("msg_2", msg)
    obj.put("param", param.toJSONString)
    obj.put("tollCharge", tollCharge)
    obj.put("tollMileage", tollMileage)
    obj.put("etcTollCharge", etcTollCharge)

    obj
  }

  def parseRectifyHttpData(ret: JSONObject): (String, String, String, String, String) = {
    var tollCharge = ""
    var tollMileage = ""
    var etcTollCharge = ""

    if (ret != null) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue,msg,tollCharge,tollMileage,etcTollCharge)
      } else {
        try {
          val result = ret.getJSONObject("result")
          tollCharge = result.getString("tollCharge")
          tollMileage = result.getString("tollMileage")
          etcTollCharge = result.getString("etcTollCharge")
        } catch {
          case e: Exception => logger.error(e)
        }

        return (codeStatue,"成功",tollCharge,tollMileage,etcTollCharge)
      }
    }
    ("22","接口返回值为空",tollCharge,tollMileage,etcTollCharge)
  }

  def parseGetLine2HttpData(ret: JSONObject): (String, String, util.ArrayList[String], String) = {
    if (ret != null) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null, null)
      } else {
        val coordsArray = new util.ArrayList[JSONArray]()
        try {
          val result: JSONObject = JSONUtil.getJsonObjectMulti(ret, "result")
          val linePassZoneInfoDtos: JSONArray = JSONUtil.getJsonArrayMulti(result, "linePassZoneInfoDtos")
          for (i <- 0 until(linePassZoneInfoDtos.size())){
            val linePassZoneInfoDtosObj: JSONObject = linePassZoneInfoDtos.getJSONObject(i)
            val stdLineData: JSONObject = JSONUtil.getJsonObjectMulti(linePassZoneInfoDtosObj, "stdLineData")
            val coords: JSONArray = JSONUtil.getJsonArrayMulti(stdLineData, "coords")
            coordsArray.append(coords)
          }

        } catch {
          case e: Exception => logger.error(e)
        }
        val jyTrack2Array = new util.ArrayList[String]()
          if (coordsArray.nonEmpty){
          for (i <- 0 until(coordsArray.size())){
            val jy_track2: String = coordsArray(i).toJSONString
              .replace("\"", "")
              .replace("[[", "")
              .replace("]]", "")
              .replace("],[", "|")
            jyTrack2Array.append(jy_track2)
          }
        }

        return (codeStatue, "成功", jyTrack2Array, null)
      }
    }
    ("22", "请求失败", null, null)
  }

  def parseGetLineHttpData(ret: JSONObject): (String, String, String, JSONObject) = {
    if (ret != null) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null, null)
      } else {
        var jy_track2 = ""
        try {
          jy_track2 = ret.getJSONObject("result").getJSONArray("list").getJSONObject(0).getString("jyTrack2")
        } catch {
          case e: Exception => logger.error(e)
        }
        return (codeStatue, "成功", jy_track2, null)
      }
    }
    ("22", "请求失败", null, null)
  }
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
    logger.error(s"$resTableName : 表数据写入完成")
  }

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20240119  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
