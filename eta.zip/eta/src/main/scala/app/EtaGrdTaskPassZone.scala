package app

import Utils.SparkUtils.writeToHive
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.col

import scala.collection.mutable.ArrayBuffer

/**
 * 【GIS-RSS-ETA】任务系统kafka数据落表需求
 * 需求方：马一越（01425432）
 * @author 徐游飞（01417347）
 * 任务ID：659012 (任务已下线)
 * 任务名称：kafka导航任务数据解析
 */
object EtaGrdTaskPassZone {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val dayBefore2 = args(1)
    //日期检查
    logger.error("incDay="+incDay)
    logger.error("dayBefore2="+dayBefore2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    val querySql =
      s"""
         |select
         |  data,
         |  inc_day
         |from
         |  dm_gis.eta_ts_grd_task_passzone
         |where
         |  inc_day >= '$dayBefore2'
         |  and inc_day <= '$incDay'
         |""".stripMargin

    println("获取kafka原始数据 sql语句：")
    println(querySql)

    // 解析data数据
    import spark.implicits._
    var ret_obj = new JSONObject()
    val df_passzone = spark.sql(querySql).rdd.flatMap(x=>{
      val data = x.getString(0)
      val inc_day = x.getString(1)
      try{
        ret_obj = JSON.parseObject(data)  //此处要抛异常
      }catch{
        case e: Exception => null
      }
      val dataArray = new ArrayBuffer[(String,JSONObject)]()
      val task_arr = ret_obj.getJSONArray("groundTaskPassZoneDtos")
      val taskId = JSONUtil.getJsonValSingle(ret_obj, "taskId","")
      for(i <- 0 until task_arr.size()){
        val task = task_arr.getJSONObject(i)
        task.put("inc_day",inc_day)
        dataArray.append((taskId,task))
      }
      dataArray.iterator
    }).map(x=>{
      val taskId = x._1
      val obj = x._2
      val actualDepartTm = JSONUtil.getJsonValSingle(obj, "actualDepartTm","")
      val passZoneCode = JSONUtil.getJsonValSingle(obj, "passZoneCode","")
      val deptSiteId = JSONUtil.getJsonValSingle(obj, "deptSiteId","")
      val passZoneAddr = JSONUtil.getJsonValSingle(obj, "passZoneAddr","")
      val passZoneCoordinate = JSONUtil.getJsonValSingle(obj, "passZoneCoordinate","")
      val actualPassZoneCode = JSONUtil.getJsonValSingle(obj, "actualPassZoneCode","")
      val sortNum = JSONUtil.getJsonValSingle(obj, "sortNum","")
      val trmsInOpTm = JSONUtil.getJsonValSingle(obj, "trmsInOpTm","")
      val trmsOutOpTm = JSONUtil.getJsonValSingle(obj, "trmsOutOpTm","")
      val appDepartTm = JSONUtil.getJsonValSingle(obj, "appDepartTm","")
      val appArriveTm = JSONUtil.getJsonValSingle(obj, "appArriveTm","")
      val appExpTm = JSONUtil.getJsonValSingle(obj, "appExpTm","")
      val firstUnloadOptm = JSONUtil.getJsonValSingle(obj, "firstUnloadOptm","")
      val lastLoadOpTm = JSONUtil.getJsonValSingle(obj, "lastLoadOpTm","")
      val carCloseOptm = JSONUtil.getJsonValSingle(obj, "carCloseOptm","")
      val carOpenOptm = JSONUtil.getJsonValSingle(obj, "carOpenOptm","")
      val gisInTm = JSONUtil.getJsonValSingle(obj, "gisInTm","")
      val gisOutTm = JSONUtil.getJsonValSingle(obj, "gisOutTm","")
      val createTm = JSONUtil.getJsonValSingle(obj, "createTm","")
      val lastUpdateTm = JSONUtil.getJsonValSingle(obj, "lastUpdateTm","")
      val calcDepartTm = JSONUtil.getJsonValSingle(obj, "calcDepartTm","")
      val calcArriveTm = JSONUtil.getJsonValSingle(obj, "calcArriveTm","")
      val appDepartValidity = JSONUtil.getJsonValSingle(obj, "appDepartValidity","")
      val appArriveValidity = JSONUtil.getJsonValSingle(obj, "appArriveValidity","")
      val actualDepTmDataSource = JSONUtil.getJsonValSingle(obj, "actualDepTmDataSource","")
      val actualArrTmDataSource = JSONUtil.getJsonValSingle(obj, "actualArrTmDataSource","")
      val gisOuterInTm = JSONUtil.getJsonValSingle(obj, "gisOuterInTm","")
      val inc_day = JSONUtil.getJsonValSingle(obj, "inc_day","")

      passZone(taskId,passZoneCode,deptSiteId,passZoneAddr,passZoneCoordinate,actualPassZoneCode,sortNum,actualDepartTm,trmsInOpTm,
        trmsOutOpTm,appDepartTm,appArriveTm,appExpTm,firstUnloadOptm,lastLoadOpTm,carCloseOptm,carOpenOptm,gisInTm,gisOutTm,createTm,lastUpdateTm,
        calcDepartTm,calcArriveTm,appDepartValidity,appArriveValidity,actualDepTmDataSource,actualArrTmDataSource,gisOuterInTm,inc_day)
    }).toDF

    // 数据存入hive
    val res_cols = spark.sql(s"""select * from dm_gis.eta_ground_task_pass_zone limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_passzone.select(res_cols: _*),Seq("inc_day"),"dm_gis.eta_ground_task_pass_zone")

  }

  case class passZone(
                       taskId : String,
                       passZoneCode : String,
                       deptSiteId : String,
                       passZoneAddr : String,
                       passZoneCoordinate : String,
                       actualPassZoneCode : String,
                       sortNum : String,
                       actualDepartTm : String,
                       trmsInOpTm : String,
                       trmsOutOpTm : String,
                       appDepartTm : String,
                       appArriveTm : String,
                       appExpTm : String,
                       firstUnloadOptm : String,
                       lastLoadOpTm : String,
                       carCloseOptm : String,
                       carOpenOptm : String,
                       gisInTm : String,
                       gisOutTm : String,
                       createTm : String,
                       lastUpdateTm : String,
                       calcDepartTm : String,
                       calcArriveTm : String,
                       appDepartValidity : String,
                       appArriveValidity : String,
                       actualDepTmDataSource : String,
                       actualArrTmDataSource : String,
                       gisOuterInTm : String,
                       inc_day : String
                     )
}
