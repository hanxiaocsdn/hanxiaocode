package app

import Utils.SparkUtils.writeToHive
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 * 线路画像
 * 需求方：徐千皓（01401062）
 * @author 徐游飞（01417347）
 * 任务ID：912125
 * 任务名称：线路画像大宽表
 */
object EtaStdLinePortrayal {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def execute(spark: SparkSession, dayBefore1: String, dayBefore30: String) = {
    import spark.implicits._

    // 线路画像纠偏数据
    val rectify_sql =
      s"""
         |select
         |  task_id,
         |  task_subid,
         |  total_dist,
         |  adcode_dist_map,
         |  total_links_dist,
         |  night_dirve_dist,
         |  before_dawn_drive_dist,
         |  early_morning_drive_dist,
         |  afternoon_drive_dist,
         |  dusk_drive_dist,
         |  high_speed_dist,
         |  state_road_dist,
         |  provincial_dist,
         |  county_dist,
         |  township_dist,
         |  dangerous_road_dist,
         |  high_accident_road_dist,
         |  school_road_dist,
         |  sharp_turn_road_dist,
         |  village_road_dist,
         |  night_high_speed_dist,
         |  night_state_road_dist,
         |  night_provincial_dist,
         |  night_county_dist,
         |  night_township_dist,
         |  before_dawn_high_speed_dist,
         |  before_dawn_state_road_dist,
         |  before_dawn_provincial_dist,
         |  before_dawn_county_dist,
         |  before_dawn_township_dist,
         |  early_morning_high_speed_dist,
         |  early_morning_state_road_dist,
         |  early_morning_provincial_dist,
         |  early_morning_county_dist,
         |  early_morning_township_dist,
         |  afternoon_high_speed_dist,
         |  afternoon_state_road_dist,
         |  afternoon_provincial_dist,
         |  afternoon_county_dist,
         |  afternoon_township_dist,
         |  dusk_high_speed_dist,
         |  dusk_state_road_dist,
         |  dusk_provincial_dist,
         |  dusk_county_dist,
         |  dusk_township_dist,
         |  drive_duration_array,
         |  total_duration,
         |  drive_duration,
         |  adcode_duration_map,
         |  total_links_duration,
         |  night_dirve_duration,
         |  before_dawn_drive_duration,
         |  early_morning_drive_duration,
         |  afternoon_drive_duration,
         |  dusk_drive_duration,
         |  high_speed_duration,
         |  state_road_duration,
         |  provincial_duration,
         |  county_duration,
         |  township_duration,
         |  dangerous_road_duration,
         |  high_accident_road_duration,
         |  school_road_duration,
         |  sharp_turn_road_duration,
         |  township_road_duration,
         |  over_speed_duration,
         |  over_speed_ser_duration,
         |  high_speed_lowspeed_duration,
         |  over_drive_duration,
         |  night_high_speed_duration,
         |  night_state_road_duration,
         |  night_provincial_duration,
         |  night_county_duration,
         |  night_township_duration,
         |  before_dawn_high_speed_duration,
         |  before_dawn_state_road_duration,
         |  before_dawn_provincial_duration,
         |  before_dawn_county_duration,
         |  before_dawn_township_duration,
         |  early_morning_high_speed_duration,
         |  early_morning_state_road_duration,
         |  early_morning_provincial_duration,
         |  early_morning_county_duration,
         |  early_morning_township_duration,
         |  afternoon_high_speed_duration,
         |  afternoon_state_road_duration,
         |  afternoon_provincial_duration,
         |  afternoon_county_duration,
         |  afternoon_township_duration,
         |  dusk_high_speed_duration,
         |  dusk_state_road_duration,
         |  dusk_provincial_duration,
         |  dusk_county_duration,
         |  dusk_township_duration,
         |  lnk_cnt,
         |  dangerous_road_cnt,
         |  high_accident_road_cnt,
         |  school_road_cnt,
         |  sharp_turn_road_cnt,
         |  township_road_road_cnt,
         |  night_lnk_cnt,
         |  night_dangerous_road_cnt,
         |  night_high_accident_road_cnt,
         |  night_school_road_cnt,
         |  night_sharp_turn_road_cnt,
         |  night_township_road_road_cnt,
         |  before_dawn_lnk_cnt,
         |  before_dawn_dangerous_road_cnt,
         |  before_dawn_high_accident_road_cnt,
         |  before_dawn_school_road_cnt,
         |  before_dawn_sharp_turn_road_cnt,
         |  before_dawn_township_road_road_cnt,
         |  early_morning_lnk_cnt,
         |  early_morning_dangerous_road_cnt,
         |  early_morning_high_accident_road_cnt,
         |  early_morning_school_road_cnt,
         |  early_morning_sharp_turn_road_cnt,
         |  early_morning_township_road_road_cnt,
         |  afternoon_lnk_cnt,
         |  afternoon_dangerous_road_cnt,
         |  afternoon_high_accident_road_cnt,
         |  afternoon_school_road_cnt,
         |  afternoon_sharp_turn_road_cnt,
         |  afternoon_township_road_road_cnt,
         |  dusk_lnk_cnt,
         |  dusk_dangerous_road_cnt,
         |  dusk_high_accident_road_cnt,
         |  dusk_school_road_cnt,
         |  dusk_sharp_turn_road_cnt,
         |  dusk_township_road_road_cnt,
         |  inc_day
         |from
         |  dm_gis.line_profile_rectify_deviation
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println(rectify_sql)
    val df_rectify = spark.sql(rectify_sql)
      .withColumn("type1",lit("画像"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 线路流向数据
    val flow_sql =
      s"""
         |select
         |  task_id,
         |  task_subid,
         |  task_area_code,
         |  sort_num,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  plan_depart_tm,
         |  actual_depart_tm,
         |  plan_arrive_tm,
         |  actual_arrive_tm,
         |  driver_id,
         |  driver_name,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  plf_flag,
         |  vehicle_type,
         |  axls_number,
         |  log_dist,
         |  rt_coords,
         |  x1,
         |  y1,
         |  x2,
         |  y2,
         |  duration,
         |  time,
         |  rt_dist,
         |  highwaymileage,
         |  toll_charge,
         |  start_distance,
         |  end_distance,
         |  error_type,
         |  pns_dist,
         |  pns_time,
         |  src,
         |  std_coords,
         |  line_distance_std,
         |  line_time_std,
         |  sim1,
         |  sim5,
         |  conduct_type,
         |  is_run_ontime_std,
         |  is_run_ontime,
         |  if_dist_equal,
         |  if_time_equal,
         |  pns_error,
         |  task_inc_day,
         |  tl_time,
         |  halfway_integrate_rate,
         |  std_x1,
         |  std_y1,
         |  std_x2,
         |  std_y2,
         |  start_distance_std,
         |  end_distance_std,
         |  ac_is_run_ontime_std,
         |  ac_is_run_ontime,
         |  if_evaluate_time,
         |  carrier_name,
         |  stop_over_zone_code,
         |  biz_type,
         |  require_category,
         |  std_toll_charge,
         |  std_id,
         |  navi_strategy,
         |  is_return_std_line,
         |  is_navi_at_start,
         |  is_navi_by_std_line,
         |  route_time,
         |  drive_time,
         |  is_yaw_by_driver,
         |  navi_complete_rate,
         |  accrual_dist,
         |  accrual_dist_type,
         |  last_update_tm,
         |  main_driver_account,
         |  road_fee,
         |  inc_day
         |from
         |  dm_gis.eta_std_line_recall_line_portrait
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println(flow_sql)
    val df_flow = spark.sql(flow_sql)
      .withColumn("type2",lit("流向"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 线路定责解析数据
    val responsibility_sql =
      s"""
         |select
         |  task_id,
         |  task_subid,
         |  yongdu_gd_len,
         |  yongdu_speed_avg_gd,
         |  yongdu_continue_tm,
         |  yongdu_total_duration,
         |  disu_duration_exp,
         |  events_s,
         |  events_l,
         |  report_description,
         |  is_closure,
         |  closure_contime,
         |  jp_duration_sum,
         |  std_duration_sum,
         |  jp_dr_length_sum,
         |  std_dr_length_sum,
         |  stay_swid_length_total,
         |  stay_swid_gd2,
         |  is_zhuguan,
         |  congestion_time,
         |  responsibility_reason,
         |  conduct_type_final,
         |  conduct_type_final2,
         |  task_conduct_type,
         |  inc_day,
         |  count(1) as cnt
         |from
         |  dm_gis.responsibility_data_analysis
         |where
         |  inc_day = '$dayBefore1'
         |group by
         |  task_id,
         |  task_subid,
         |  yongdu_gd_len,
         |  yongdu_speed_avg_gd,
         |  yongdu_continue_tm,
         |  yongdu_total_duration,
         |  disu_duration_exp,
         |  events_s,
         |  events_l,
         |  report_description,
         |  is_closure,
         |  closure_contime,
         |  jp_duration_sum,
         |  std_duration_sum,
         |  jp_dr_length_sum,
         |  std_dr_length_sum,
         |  stay_swid_length_total,
         |  stay_swid_gd2,
         |  is_zhuguan,
         |  congestion_time,
         |  responsibility_reason,
         |  conduct_type_final,
         |  conduct_type_final2,
         |  task_conduct_type,
         |  inc_day
         |""".stripMargin
    println(responsibility_sql)
    val df_responsibility = spark.sql(responsibility_sql)
      .withColumn("type3",lit("定责"))
      .drop("cnt")
      .persist(StorageLevel.MEMORY_AND_DISK)

    // 时效价值数据
    val mix_delay_sql =
      s"""
         |select
         |  line_code,
         |  start_dept,
         |  end_dept,
         |  direction,
         |  task_period,
         |  votes,
         |  task_num,
         |  actual_highway_speed94_m,
         |  actual_highway_speed98_m,
         |  task_on_num,
         |  on_rate,
         |  task_on_num_kg,
         |  on_rate_kg,
         |  on_rate_4,
         |  highway_dist,
         |  nonhighway_dist,
         |  nonhighway_speed,
         |  total_trips_num,
         |  improve_batch_trips,
         |  improve_batch_days,
         |  improve_cvy_trips,
         |  improve_cvy_days,
         |  improve_cvy_trips_hour,
         |  improve_cvy_days_hour,
         |  sf_total_trips_num,
         |  this_batch_speed,
         |  this_batch_trips,
         |  this_batch_days,
         |  this_batch_trips_hour,
         |  this_batch_days_hour,
         |  task_period_on,
         |  task_date,
         |  task_days,
         |  task_date_on,
         |  task_days_on,
         |  if_always_on,
         |  total_tasks,
         |  total_tasks_on,
         |  total_tasks_on_1,
         |  total_tasks_on_2,
         |  total_tasks_on_3,
         |  total_tasks_on_4,
         |  total_tasks_on_5,
         |  total_tasks_on_6,
         |  total_tasks_on_rate,
         |  total_tasks_on_rate_1,
         |  total_tasks_on_rate_2,
         |  total_tasks_on_rate_3,
         |  total_tasks_on_rate_4,
         |  total_tasks_on_rate_5,
         |  total_tasks_on_rate_6,
         |  tasks_on,
         |  tasks_sub,
         |  tasks_ob,
         |  tasks_sub_ob,
         |  tasks_non,
         |  hy_highway_count,
         |  hy_highway_90,
         |  hy_highway_50,
         |  hy_highway_10,
         |  can_rest_duration,
         |  hy_all_90,
         |  hy_all_50,
         |  hy_all_10,
         |  hy_rate_on_90,
         |  hy_rate_on_50,
         |  hy_rate_on_10,
         |  line_code_label,
         |  line_time_hy_top
         |from
         |  dm_gis.eta_line_speed_ac_mix_delay_mining_dtl
         |where
         |  inc_day in (
         |    select
         |      max(inc_day) inc_day
         |    from
         |      dm_gis.eta_line_speed_ac_mix_delay_mining_dtl
         |    where
         |      inc_day >= '$dayBefore30'
         |      and inc_day <= '$dayBefore1'
         |  )
         |""".stripMargin
    println(mix_delay_sql)
    val df_mix_delay = spark.sql(mix_delay_sql)
      .withColumn("type4",lit("时效"))
      .persist(StorageLevel.MEMORY_AND_DISK)


    val dddd = df_flow
      .join(df_rectify, Seq("task_subid","task_id","inc_day"), "left")

    println("df_flow 数据量："+df_flow.count())
    println("df_rectify 数据量："+df_rectify.count())
    println("df_responsibility 数据量："+df_responsibility.count())
    println("df_mix_delay 数据量："+df_mix_delay.count())
    println("dddd 数据量："+dddd.count())

    val df_all = df_flow
      .join(df_rectify, Seq("task_subid","task_id","inc_day"), "left")
      .join(df_responsibility, Seq("task_subid","task_id","inc_day"), "left")
      .join(df_mix_delay, Seq("line_code","start_dept","end_dept"), "left")
      .persist(StorageLevel.MEMORY_AND_DISK)


    val df_all_cnt = df_all.count()
    val df_type1_cnt = df_all.filter('type1 === "画像").count()
    val df_type2_cnt = df_all.filter('type2 === "流向").count()
    val df_type3_cnt = df_all.filter('type3 === "定责").count()
    val df_type4_cnt = df_all.filter('type4 === "时效").count()
    println("df_all 数据量："+df_all_cnt)
    println("type1 数据量：" + df_type1_cnt + "  占比：" + df_type1_cnt.toDouble / df_all_cnt)
    println("type2 数据量：" + df_type2_cnt + "  占比：" + df_type2_cnt.toDouble / df_all_cnt)
    println("type3 数据量：" + df_type3_cnt + "  占比：" + df_type3_cnt.toDouble / df_all_cnt)
    println("type4 数据量：" + df_type4_cnt + "  占比：" + df_type4_cnt.toDouble / df_all_cnt)
//    df_all.printSchema()

    val cols = spark.sql("""select * from dm_gis.dm_standard_line_portrait_di limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_all.select(cols: _*),Seq("inc_day"),"dm_gis.dm_standard_line_portrait_di")


    val cols1 = spark.sql("""select * from dm_gis.line_portrait_tmp_20231129 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_all.select(cols1: _*),Seq("inc_day"),"dm_gis.line_portrait_tmp_20231129")

    df_rectify.unpersist()
    df_flow.unpersist()
    df_responsibility.unpersist()
    df_all.unpersist()
  }

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore30 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 30)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231124  ++++")
    execute(spark,dayBefore1,dayBefore30)
    logger.error("++++++++  任务完成 20231124 ++++")

    spark.stop()
  }

}
