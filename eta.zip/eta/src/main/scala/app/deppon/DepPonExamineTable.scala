package app.deppon

import java.net.URLEncoder

import Utils.JSONUtils
import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.io.Source

/**
 * 看起来找不到任务了
 */
object DepPonExamineTable {

  @transient lazy val logger: Logger = Logger.getLogger(DepPonExamineTable.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  /** @note   调度精细化接口*/
  private def scheduleCmsInterface(cityCode: String, address: String): String = {
    var explicit=""
    val detailUrl="http://gis-apis.int.sfcloud.local:1080/iad/api?address=%s&citycode=%s&ak=3a191e7427e8470c86271a069411c66b&opt=detail"
    try {
      if (StringUtils.isNotEmpty(cityCode) && StringUtils.isNotEmpty(address)) {
        val url = String.format(detailUrl,URLEncoder.encode(address, "UTF-8"), URLEncoder.encode(cityCode, "UTF-8"))
        val response = Source.fromURL(url,"UTF-8").mkString
        if(StringUtils.isNotEmpty(response)) {
          if (JSONUtils.isValidJSON(response)) {
            val response2 = JSON.parseObject(response)
            val result = response2.getJSONObject("result")
            val data = result.getJSONObject("data")
            val explicitNew = data.getString("explicit")
            explicit = explicitNew
          }
        }
      }
    } catch {
      case e: Exception => println("调度精细化接口时出现异常Exception: " + e.getMessage)
    }
    explicit
  }

  /** @note   调用dbtc接口*/
  private def scheduleDBTcInterface(x: String, y: String): String = {
    var code=""

    val dbTcUrl="http://gis-int.int.sfdc.com.cn:1080/eds/geom/query?ak=3a191e7427e8470c86271a069411c66b&x=%s&y=%s"
    try {
      if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
        val url = String.format(dbTcUrl,x,y)
        val response = Source.fromURL(url,"UTF-8").mkString
        if(StringUtils.isNotEmpty(response)) {
          if (JSONUtils.isValidJSON(response)) {
            val response2 = JSON.parseObject(response)
            val result = response2.getJSONObject("result")
            val data = result.getJSONObject("data")
            val codeNew = data.getString("code")
            code = codeNew
          }
        }
      }
    } catch {
      case e: Exception => println("调度dbtc接口时出现异常Exception: " + e.getMessage)
    }
    code
  }


  /** @note   调度Zc模型接口 获取Zc模型*/
  private def scheduleZcModelInterface(zcUrl: String, cityCode: String, address: String): String = {
    var zcModel=""
    try {
      if (StringUtils.isNotEmpty(cityCode) && StringUtils.isNotEmpty(address)) {
        val url = String.format(zcUrl, URLEncoder.encode(cityCode, "utf-8"), address)
        val response = Source.fromURL(url,"UTF-8").mkString
        if(StringUtils.isNotEmpty(response)) {
          if (JSONUtils.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val data = result.getJSONObject("data")
            val array = data.getJSONArray("code")
            if(array.size() >0){
              val zcM = array.getJSONObject(0)
              zcModel = zcM.getString("zc")
            }
          }
        }
      }
    } catch {
      case e: Exception => println("调度Zc模型接口出现异常Exception: " + e.getMessage)
    }
    zcModel
  }

  /** @note   aoiid获取对应的aoiname接口*/
  private def scheduleDeBangAoiNameInterface(url:String,aoi_id:String): String ={
    var aoi_name =""
    try{
      if (StringUtils.isNotEmpty(aoi_id)) {
        val aoi_url = String.format(url,aoi_id)
        val response = Source.fromURL(aoi_url,"UTF-8").mkString
        if(StringUtils.isNotEmpty(response)){
          if(JSONUtils.isValidJSON(response)){
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val data = result.getJSONArray("data")
            val data1 = data.getJSONObject(0)
            aoi_name = data1.getString("aoi_name")
          }
        }
      }
    }catch {
      case e:Exception => println("根据aoiid获取aoiname接口时出现异常")
    }
    aoi_name
  }



  /** @note   address和adcode获取对应的splitresult接口*/
  private def scheduleSplitResultInterface(url:String,address:String,adcode:String): String ={
    var splitResult =""
    try{
      if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(adcode)) {
        val aoi_url = String.format(url,address,adcode)
        val response = Source.fromURL(aoi_url,"UTF-8").mkString
        if(StringUtils.isNotEmpty(response)){
          if(JSONUtils.isValidJSON(response)){
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val addrSplitInfo = result.getJSONArray("addrSplitInfo")
            val sb = new StringBuilder
            for(i<- 0 until addrSplitInfo.size()){
              val json = addrSplitInfo.getJSONObject(i)
              val name = json.getString("name")
              val prop =json.getString("prop")
              val level =json.getString("level")
              sb.append(name).append("^").append(prop).append(level).append("|")
            }
            splitResult = sb.toString()
          }
        }
      }
    }catch {
      case e:Exception => println("获取分词接口时出现异常")
    }
    splitResult
  }


  /** @note   address和city获取对应的keyword接口*/
  private def scheduleKeyWordInterface(url:String,address:String,city:String): String ={
    var keyWord =""
    try{
      if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(city)) {
        val aoi_url = String.format(url,address,city)
        val response = Source.fromURL(aoi_url,"UTF-8").mkString
        if(StringUtils.isNotEmpty(response)){
          if(JSONUtils.isValidJSON(response)){
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val tcs = result.getJSONArray("tcs")
            if(tcs.size()>0){
              val tcsJson = JSON.parseObject(tcs.getString(0))
              keyWord = tcsJson.getString("keyWord")
            }
          }
        }
      }
    }catch {
      case e:Exception => println("获取主体词接口时出现异常")
    }
    keyWord
  }







  val addrReviewUrl="http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon/his/opt&ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&type=1&zc=%s&tc=%s"

  val keyWordReviewUrl="http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon/his/opt&ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&type=2&zc=%s&tc=%s&adcode=%s"

  val effectUrl="http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-int.int.sfdc.com.cn:1080/eds/opt/effect&ak=3a191e7427e8470c86271a069411c66b&city=%s&showserver=true"

  //获取adcode接口
  //val adcodeUrl= "http://10.202.15.115:30090/gorule?address=%s"

  val adcodeUrl="http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal?address=%s&city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh"

  //获取zc、tc的接口
  val getZcTcUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/geom/query?ak=3a191e7427e8470c86271a069411c66b&x=%s&y=%s&showserver=true"

  //获取zcmode的接口
  val ZcModelUrl ="http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&opt=zc&show=1"

  //获取分词的接口
  val splitWordUrl = "http://gis-int.int.sfdc.com.cn:1080/atroad/api/split?address=%s&ak=3a191e7427e8470c86271a069411c66b&adcode=%s"

  //获取主体词的接口
  val keyWordUrl = "http://gis-int.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&ak=3a191e7427e8470c86271a069411c66b&opt=zh&showserver=true&tel=&mobile=&company=&contact="

  //获取aoiname的接口
  val aoiNameUrl= "http://gis-apis.int.sfcloud.local:1080/dept/zctc/aoiid?ak=e6b53e609c2440c8b20b14552bab4e09&aoi_id=%s"

  //获取地址相似度接口
  val addressSimilarityUrl = "http://10.119.72.209:8080/rds_web/noControl/similar/%s/%s"

  //根据城市对压入的数据生效url
  val cityReviewUrl = "http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-int.int.sfdc.com.cn:1080/eds/opt/effect&ak=3a191e7427e8470c86271a069411c66b&city=%s&showserver=true"


  def main(args: Array[String]): Unit = {

    logger.error("程序开始")

    val begin_day =args(0)
    val inc_day =args(1)


    val key_word = scheduleKeyWordInterface(keyWordUrl,URLEncoder.encode("湖北省宜昌市夷陵区小溪塔街道清江润城44号","utf-8"),"717")

    println(key_word)


    start(begin_day,inc_day)

    logger.error("统计完毕")
  }

  def start(begin_day:String,inc_day:String): Unit ={
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    startSta(spark,begin_day,inc_day)
  }

  case class out(info:String,inc_day:String)




  def startSta(spark: SparkSession, begin_day:String, inc_day: String) = {
    val wdData = getWdData(spark,begin_day,inc_day)
    logger.error("输入数据为：" + wdData.count())
    wdData.take(2).foreach(println(_))

    val outPutRdd1 = wdData.repartition(200).map(x => {
      val address = x.getString("address")
      val citycode = x.getString("city")
      val depponcode = x.getString("citycode")
      val ts_precision =JSONUtils.getJsonValue(x,"ts_precision","")
      val mapa_precision =JSONUtils.getJsonValue(x,"mapa_precision","")
      val depponZc =JSONUtils.getJsonValue(x,"depponZc","")
      val mapa_x =JSONUtils.getJsonValue(x,"mapa_x","")
      val mapa_y =JSONUtils.getJsonValue(x,"mapa_y","")
      val ts_x =JSONUtils.getJsonValue(x,"ts_x","")
      val ts_y =JSONUtils.getJsonValue(x,"ts_y","")

      val explicit = scheduleCmsInterface(citycode,address)
      if (!"1".equals(explicit)){
        x.put("process","noProcess1")
      }else{

        val adcode = getAdcode(address,citycode)
        x.put("adcode",adcode)
        val (mapa_xy_Zc,mapaTc) = getZcTc(mapa_x,mapa_y)
        val (ts_xy_Zc,tsTc) = getZcTc(ts_x,ts_y)
        x.put("mapa_xy_Zc",mapa_xy_Zc)
        x.put("mapaTc",mapaTc)
        x.put("ts_xy_Zc",ts_xy_Zc)
        x.put("tsTc",tsTc)

        if(!StringUtils.isEmpty(ts_precision) && !StringUtils.isEmpty(mapa_precision) &&  !StringUtils.isEmpty(depponZc)
          && "2".equals(ts_precision) && ts_precision.equals(mapa_precision) && ts_xy_Zc.equals(mapa_xy_Zc) &&  depponZc.equals(mapa_xy_Zc)){

          var tc = ""
          if( !StringUtils.isEmpty(mapaTc) && !StringUtils.isEmpty(tsTc) && mapaTc.equals(tsTc)){
            tc = mapaTc
          }
          val zcModel = scheduleZcModelInterface(ZcModelUrl,depponcode,address)
          x.put("zcModel",zcModel)
          x.put("tc",tc)
          x.put("step1","mapaTs")
        }else{
          val zcModel = scheduleZcModelInterface(ZcModelUrl,depponcode,address)
          x.put("zcModel",zcModel)

          var tc = ""
          if(!StringUtils.isEmpty(ts_precision)
            && !StringUtils.isEmpty(ts_xy_Zc)
            && !StringUtils.isEmpty(zcModel)
            && "2".equals(ts_precision)
            && ts_xy_Zc.equals(zcModel)
            && depponZc.equals(zcModel)){

            tc = tsTc
            x.put("tc",tc)

            x.put("step1","Ts")
          }else{
            x.put("step1","mapa")
            if(!StringUtils.isEmpty(mapa_precision)
              && !StringUtils.isEmpty(mapa_xy_Zc)
              && !StringUtils.isEmpty(zcModel)
              && "2".equals(mapa_precision)
              && mapa_xy_Zc.equals(zcModel)
              && depponZc.equals(zcModel)){
              tc = mapaTc
              x.put("tc",tc)
            }else{
              x.put("process","noProcess2")
            }
          }
        }
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("精度和zc判断完毕，开始获取分词,数据量为：" + outPutRdd1.count())
    //outPutRdd1.collect().foreach(println(_))


    val outPutRdd = outPutRdd1.filter(x =>{StringUtils.isEmpty( x.getString("process"))}).repartition(10).map(x => {

      val citycode = x.getString("citycode")
      val address = x.getString("address").replaceAll("\\s","")
      val zcModel = x.getString("zcModel")
      val tc = x.getString("tc")
      val aoiid = x.getString("aoiid")
      val adcode = x.getString("adcode")
      val city = x.getString("city")
      val depponZc = x.getString("depponZc")

      val addrReviewReq = addrReviewUrl.format(city,URLEncoder.encode(address,"utf-8"),depponZc, tc)
      try{
        // 生产 文本入审补
        val addrReviewRes = Source.fromURL(addrReviewReq,"UTF-8").mkString
        //x.put("addrReviewRes",addrReviewRes)
      }catch {
        case e:Exception => x.put("addrReviewRes","err" + "\n" + e)
      }

      val cityReviewRep = cityReviewUrl.format(city)
      x.put("cityReviewReq",cityReviewRep)

      // 生产城市入审补 生效
      val cityReviewRes = Source.fromURL(cityReviewRep,"UTF-8").mkString
      x.put("cityReviewRes",cityReviewRes)

      out(x.toJSONString,inc_day)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("输出结果总量为：" + outPutRdd.count())


    import spark.implicits._
    outPutRdd.toDF.write.mode(SaveMode.Overwrite).insertInto("dm_gis.deppon_examine_table")

  }

  def getAdcode(address: String,city:String):String = {
    val adcodeRep = adcodeUrl.format(address,city)
    var adcode = ""
    try{
      var flag = 0
      for(i<-0 until(3) if flag== 0){
        val adcodeRes = Source.fromURL(adcodeRep,"UTF-8").mkString
        adcode=JSON.parseObject(adcodeRes).getJSONArray("result").getString(1)
        if(!StringUtils.isEmpty(adcodeRes)){
          flag = 1
        }
      }
    } catch {case e:Exception => println("获取adcode时出现异常")}

    adcode
  }


  def getZcTc(x: String, y: String):Tuple2[String,String] = {
    var zc =""
    var tc =""
    try{
      val zcTcRes = getZcTcUrl.format(x,y)
      val zcTcRep = Source.fromURL(zcTcRes,"UTF-8").mkString
      val result = JSON.parseObject(zcTcRep).getJSONObject("result")
      val data = result.getJSONObject("data")
      zc = data.getString("parentCode")
      tc = data.getString("code")
    }catch {
      case e:Exception => println("获取zc、tc时出现异常")
    }
    (zc,tc)
  }



  def getWdData(spark:SparkSession,begin_day:String,inc_day:String) ={


    val inputSql =
      """
        |select
        |  b.sn as sn,
        |  regexp_replace(b.address, '[\\r\\n\\s,]+', '') as address,
        |  b.citycode as citycode,
        |  b.city as city,
        |  b.depponZc as depponZc,
        |  b.zc as zc,
        |  b.aoiid as aoiid,
        |  b.mapa_precision as mapa_precision,
        |  b.mapa_x as mapa_x,
        |  b.mapa_y as mapa_y,
        |  b.mapa_aoi_id as mapa_aoi_id,
        |  b.mapa_aoi_name as mapa_aoi_name,
        |  b.ts_precision as ts_precision,
        |  b.ts_x as ts_x,
        |  b.ts_y as ts_y,
        |  b.ts_aoi_id as ts_aoi_id,
        |  b.ts_aoi_name as ts_aoi_name,
        |  b.dataSrc as dataSrc,
        |  b.src as src,
        |  b.adcode as adcode,
        |  b.groupid as groupid,
        |  b.standardization as standardization,
        |  b.keyWord as keyWord,
        |  b.model_Zc as model_Zc,
        |  b.ts_xy_Zc as ts_xy_Zc,
        |  b.mapa_xy_Zc as mapa_xy_Zc,
        |  b.inc_day as inc_day,
        |  b.mapaAoiZc as mapaAoiZc,
        |  b.tsAoiZc as tsAoiZc
        |from
        |  (
        |    select
        |      get_json_object(data_info, '$.sn') sn,
        |      inc_day
        |    from
        |      dm_gis.t_deppon_sign_index_info_d
        |    where
        |      data_type = 'wd'
        |      and inc_day BETWEEN '%s'
        |      and '%s'
        |  ) a
        |  left outer join (
        |    select
        |      get_json_object(data_info, '$.sn') sn,
        |      get_json_object(data_info, '$.reqBody.address') address,
        |      get_json_object(data_info, '$.depponZc') depponZc,
        |      get_json_object(data_info, '$.mapAXy.x') mapa_x,
        |      get_json_object(data_info, '$.mapAXy.y') mapa_y,
        |      get_json_object(data_info, '$.mapAXy.precision') mapa_precision,
        |      get_json_object(data_info, '$.mapAXy.aoi_id') mapa_aoi_id,
        |      get_json_object(data_info, '$.mapAXy.aoi_name') mapa_aoi_name,
        |      get_json_object(data_info, '$.tsXy.precision') ts_precision,
        |      get_json_object(data_info, '$.tsXy.x') ts_x,
        |      get_json_object(data_info, '$.tsXy.y') ts_y,
        |      get_json_object(data_info, '$.tsXy.aoi_id') ts_aoi_id,
        |      get_json_object(data_info, '$.tsXy.aoi_name') ts_aoi_name,
        |      get_json_object(data_info, '$.reqBody.src') src,
        |      get_json_object(data_info, '$.reqBody.adcode') adcode,
        |      get_json_object(data_info, '$.reqBody.zc') zc,
        |      get_json_object(data_info, '$.reqBody.standardization') standardization,
        |      get_json_object(data_info, '$.reqBody.keyWord') keyWord,
        |      get_json_object(data_info, '$.model_Zc') model_Zc,
        |      get_json_object(data_info, '$.ts_xy_Zc') ts_xy_Zc,
        |      get_json_object(data_info, '$.mapa_xy_Zc') mapa_xy_Zc,
        |      get_json_object(data_info, '$.reqBody.aoiid') aoiid,
        |      get_json_object(data_info, '$.reqBody.dataSrc') dataSrc,
        |      get_json_object(data_info, '$.reqBody.group') groupid,
        |      get_json_object(data_info, '$.reqBody.cityCode') citycode,
        |      get_json_object(data_info, '$.cityCode') city,
        |      get_json_object(data_info, '$.mapaAoiZc') mapaAoiZc,
        |      get_json_object(data_info, '$.tsAoiZc') tsAoiZc,
        |      inc_day
        |    from
        |      dm_gis.t_deppon_sign_index_info_d
        |    where
        |      data_type in ('src', 'zcmodel_buzErrZCModelRight')
        |      and inc_day BETWEEN '%s'
        |      and '%s'
        |  ) b on a.sn = b.sn
      """.stripMargin


    val querySql = String.format(inputSql,begin_day,inc_day,begin_day,inc_day)
    logger.error("输入的sql为：" + querySql)


    val inputRdd = spark.sql(querySql).rdd.map(x => {
      val jo = new JSONObject()
      val names = Array(
        "sn","address","citycode","city","depponZc","zc","aoiid","mapa_precision","mapa_x","mapa_y","mapa_aoi_id"
        ,"mapa_aoi_name","ts_precision","ts_x","ts_y","ts_aoi_id","ts_aoi_name","dataSrc","src","adcode","groupid"
        ,"standardization","keyWord","model_Zc","ts_xy_Zc","mapa_xy_Zc","inc_day","mapaAoiZc","tsAoiZc"
      )
      for (i <- names.indices) jo.put(names(i), x.getString(i))
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    inputRdd.take(2).foreach(println(_))

    logger.error(s"共获取错分任务下发数据:${inputRdd.count}")
    inputRdd
  }






}
