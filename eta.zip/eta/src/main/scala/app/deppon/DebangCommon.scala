package app.deppon

import com.alibaba.fastjson.JSONObject
import com.csvreader.CsvReader
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01374443 on 2020/5/12.
  */
object DebangCommon {
  @transient lazy val logger: Logger = Logger.getLogger(DebangCommon.getClass)

  def main(args: Array[String]): Unit = {
    loadAdcodeCityCodemap()
  }
  def loadAdcodeCityCodemap(): Map[String, String] ={
    val adcodeCityCodeFileName = System.getProperty("user.dir")+"/t_deppon_code_relation_list.csv"
    var adcodeCityMap: Map[String, String] = Map()
//    val adcodeCityCodeFilePath = this.getClass.getClassLoader.getResource(adcodeCityCodeFileName).getPath

    logger.error(System.getProperty("user.dir"))
    val csvReader = new CsvReader(adcodeCityCodeFileName)
    csvReader.setSafetySwitch(false)
    if (csvReader.readRecord()) logger.error("headers:" + csvReader.getValues.mkString(","))
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val adcode = row(0)
      val req_city = row(1)
      if(!adcode.isEmpty)
        adcodeCityMap += (adcode -> req_city)
    }
    logger.error("数量:" + adcodeCityMap.size)
    adcodeCityMap
  }
}
