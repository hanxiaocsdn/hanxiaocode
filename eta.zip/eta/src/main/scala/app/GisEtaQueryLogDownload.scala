package app

import com.sf.gis.java.base.util.{ShellExcutor, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * GIS-RSS-ETA：【eta导航】训练ETA模型数据导入ftp190
 * 需求方：王祎（01398517）
 * @author 徐游飞（01417347）
 * 任务ID：645465
 * 任务名称：ETA模型数据log表下载
 */
object GisEtaQueryLogDownload {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    val inc_day = args(0)
    logger.error("inc_day="+ inc_day)

    //    // 需要下载的hive表
    //    val tableName2 = "eta_std_line_recall"
    //    SaveHiveTableAsTextFile2(spark,tableName2,inc_day)

    // 需要下载的hive表
    val tableName = "gis_eta_query_log"
    SaveHiveTableAsTextFile(spark,tableName,inc_day)

    println("任务结束")
    spark.stop()
  }

  def SaveHiveTableAsTextFile(spark: SparkSession, tableName: String, inc_day: String) = {

    //将数据保存为TextFile
    val hdfsPath = s"hdfs://sfbd/user/hive/warehouse/dm_gis/${tableName}_${inc_day}"
    val file = s"./${tableName}_${inc_day}.csv"

    ShellExcutor.exeCmd(s"hdfs dfs -rm -r $hdfsPath")
    val sql_seg =
      s"""
         |select
         |   inc_day as inc_day
         |  ,reqid as reqId
         |  ,datatime as dataTime
         |  ,group_task as group_task
         |  ,taskid as taskId
         |  ,linecode as lineCode --任务线路
         |  ,srczoneid as srcZoneId --出发场地
         |  ,destzoneid as destZoneId --目的场地
         |  ,eta_srczonecoordinate as eta_srcZoneCoordinate
         |  ,eta_destzonecoordinate as eta_destZoneCoordinate
         |  ,plate as plate --车牌
         |  ,requesttime as requestTime --请求时间
         |  ,validtime as validTime --轨迹有效时间
         |  ,eta_act_point as eta_act_point
         |  ,eta_act_time as eta_act_time--车辆实时轨迹点时间
         |  ,points as points --规划路径
         |  ,index as index --路线开始索引
         |  ,linetype as lineType --线路类型 zh2/std
         |  ,arrivetime as arriveTime -- 预计到达时间
         |  ,eta_time as eta_time --规划时间
         |  ,dist as dist --规划里程
         |  ,tmcetatime as tmcEtaTime --eta规划时间
         |  ,tmcetadist as tmcEtaDist --eta规划里程
         |  ,qmpointtime as qmPointTime --旧eta规划时间
         |  ,qmpointdist as qmPointDist --旧eta规划里程
         |  ,stdid as stdId --标准线路ID
         |  ,linesource as lineSource --是否缓存（log/NaN）
         |  ,uid as uid
         |  ,destzonecoordinate as destZoneCoordinate
         |  ,etamachinefeature as etaMachineFeature
         |from
         |  dm_gis.gis_eta_query_log_detail
         |where
         |  inc_day = '$inc_day'
         |""".stripMargin

    println("取数sql为:" + sql_seg)
    println(s"$tableName 表数据开始保存至 $hdfsPath")
    val dataDF = spark.sql(sql_seg)
    //      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    //    println(s" $inc_day 的数据量为："+dataDF.count())

    val unit = dataDF.repartition(50)
      .write
      .format("csv")
      .mode("overwrite")
      .option("header", "true")
      .option("sep","\t")
      .save(hdfsPath)
    println(s"$tableName 表数据已保存至： $hdfsPath")

//    println(s"$tableName 表数据开始合并下载至本地： $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -ls -h $hdfsPath")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"hdfs dfs -getmerge $hdfsPath $file")
//    println(s"$tableName 表数据下载完成")
//
//    println(s"$tableName 表开始压缩数据")
//    ShellExcutor.exeCmd(s"ls -l $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    ShellExcutor.exeCmd(s"tar czf $file.tgz $file")
//    println(s"$tableName 表数据压缩完成")
//
//    println(s"$tableName 表开始上传至ftp:10.116.49.190")
//    ShellExcutor.exeCmd(s"ls -l $file.tgz")
//    //ShellExcutor.exeCmd(s"curl ftp://devftp:brYsj2.023ftKjdev@ftp://gisftp.sf-express.com/$tableName/ -T $file.tgz")
//    //ShellExcutor.exeCmd(s"curl -u devftp:brYsj2.023ftKjdev -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/$tableName/")
//    ShellExcutor.exeCmd(s"curl -u ywftp:*fTKJ*.123yunwei -T ./$file.tgz  ftp://gisftp.sf-express.com/01417347/$tableName/")
//    ShellExcutor.exeCmd(s"rm -r $file")
//    ShellExcutor.exeCmd(s"rm -r $file.tgz")
//    println(s"$tableName 表数据上传成功")
  }


}
