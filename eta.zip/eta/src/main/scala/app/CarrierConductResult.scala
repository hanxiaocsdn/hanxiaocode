package app

import Utils.SparkUtils.writeToHive
import Utils.StringUtils.isEmptyOrNull
import app.EtaCarrierLogData2Hive.timeToCustomTime2
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 * GIS-RSS-ETA：【时效安全专项】承运商维度执行和定责扣罚情况需求(数据侧)_V1.0
 * 需求内容：统计承运商维度的标准线路执行扣罚情况和定责结果
 * 需求方：廖静文（01430321）
 * @author 徐游飞（01417347）
 * 任务ID：783258
 */
object CarrierConductResult {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def execute(spark: SparkSession, inc_day: String) = {
    val dayBefore1 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 1)
    val dayBefore8 = DateUtil.getDayBefore(inc_day, "yyyyMMdd", 8)

    import spark.implicits._
    val recall_sql =
      s"""
         |select
         |  get_json_object(info, '$$.task_id')  as task_id,
         |  get_json_object(info, '$$.create_time')  as create_time,
         |  get_json_object(info, '$$.start_dept')  as start_dept,
         |  get_json_object(info, '$$.end_dept')  as end_dept,
         |  get_json_object(info, '$$.line_code')  as line_code,
         |  get_json_object(info, '$$.vehicle_serial')  as vehicle_serial,
         |  get_json_object(info, '$$.outer_vehicle_from')  as outer_vehicle_from,
         |  get_json_object(info, '$$.actual_depart_tm')  as actual_depart_tm,
         |  get_json_object(info, '$$.actual_arrive_tm')  as actual_arrive_tm,
         |  get_json_object(info, '$$.driver_name')  as driver_name,
         |  get_json_object(info, '$$.actual_run_time')  as actual_run_time,
         |  get_json_object(info, '$$.is_stop')  as is_stop,
         |  get_json_object(info, '$$.carrier_type')  as carrier_type,
         |  get_json_object(info, '$$.ac_is_run_ontime')  as ac_is_run_ontime,
         |  get_json_object(info, '$$.if_evaluate_time')  as if_evaluate_time,
         |  get_json_object(info, '$$.carrier_id')  as carrier_id,
         |  get_json_object(info, '$$.carrier_code')  as carrier_code,
         |  get_json_object(info, '$$.carrier_name')  as carrier_name,
         |  get_json_object(info, '$$.actual_carrier_name')  as actual_carrier_name,
         |  get_json_object(info, '$$.capacity_reource_type')  as capacity_reource_type,
         |  get_json_object(info, '$$.task_conduct_type')  as task_conduct_type,
         |  get_json_object(info, '$$.is_closure')  as is_closure,
         |  get_json_object(info, '$$.task_label_final2')  as task_label_final2,
         |  inc_day
         |from
         |  dm_gis.eta_std_line_recall_realtime2
         |where
         |  inc_day >= '$dayBefore8'
         |  and inc_day <= '$dayBefore1'
         |  and get_json_object(info, '$$.if_evaluate_time') = 1
         |""".stripMargin
    println(recall_sql)
    val df_recall = spark.sql(recall_sql)
      .filter(!isEmptyOrNull('actual_arrive_tm))  // 过滤实际到车时间为空的数据
      .withColumn("rn", row_number().over(Window.partitionBy('task_id,'inc_day).orderBy(desc("create_time"))))
      .filter('rn === 1)
      .drop("rn")
      .withColumn("task_inc_day",timeToCustomTime2('actual_arrive_tm,lit("yyyy-MM-dd HH:mm:ss"),lit("yyyyMMdd")))
      .withColumn("new_carrier_name",when(!isEmptyOrNull('actual_carrier_name),'actual_carrier_name).otherwise('carrier_name))
      .withColumn("is_closure",lit(0))

    val carrier_sql =
      s"""
         |select
         |  carrier_id
         |  ,create_time as login_create_time
         |  ,update_time as login_update_time
         |  ,inc_day
         |from
         |  dm_gis.plan_user_carrier
         |where
         |  inc_day >= '$dayBefore8'
         |  and inc_day <= '$dayBefore1'
         |  and del_flag = 'false'
         |""".stripMargin
    println(carrier_sql)
    val df_carrier = spark.sql(carrier_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('carrier_id,'inc_day).orderBy(desc("login_create_time"),desc("login_update_time"))))
      .filter('rn === 1)
      .drop("rn")

    val user_sql =
      s"""
         |select
         |  carrier_id,
         |  id,
         |  inc_day
         |from
         |  dm_gis.ua_sys_log_user
         |where
         |  inc_day >= '$dayBefore8'
         |  and inc_day <= '$dayBefore1'
         |  and del_flag = 'false'
         |""".stripMargin
    println(user_sql)
    val df_user = spark.sql(user_sql)
      .groupBy("carrier_id","inc_day")
      .agg(
        countDistinct("id") as "log_in_times"
      )
      .withColumn("is_log_in",when('log_in_times > 0,1).otherwise(0))
      .withColumn("log_in_inc_day",'inc_day)
      .select("carrier_id","inc_day","log_in_times","is_log_in","log_in_inc_day")

    val operation_sql =
      s"""
         |select
         |  carrier_id,
         |  id,
         |  inc_day
         |from
         |  dm_gis.plan_line_operation_detail
         |where
         |  inc_day >= '$dayBefore8'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println(operation_sql)
    val df_operation = spark.sql(operation_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('carrier_id,'inc_day).orderBy(desc("id"))))
      .filter('rn === 1)
      .withColumn("operation_inc_day",'inc_day)
      .select("carrier_id","inc_day","operation_inc_day")

    val manage_sql =
      s"""
         |select
         |  create_tm,
         |  own_dept_code,
         |  concat(own_dept_code, task_id) as task_id,
         |  modify_tm,
         |  complain_type,
         |  handle_node,
         |  handle_status,
         |  handle_result,
         |  audit_remark,
         |  inc_day
         |from
         |  ods_shiva_ground.tt_task_exception_manage
         |where
         |  inc_day >= '$dayBefore8'
         |  and inc_day <= '$dayBefore1'
         |""".stripMargin
    println(manage_sql)
    val df_manage = spark.sql(manage_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id,'inc_day).orderBy(desc("modify_tm"))))
      .filter('rn === 1)
      .drop("rn")

    val df_ret = df_recall
      .join(df_manage,Seq("task_id","inc_day"),"left")
      .join(df_carrier,Seq("carrier_id","inc_day"),"left")
      .join(df_user,Seq("carrier_id","inc_day"),"left")
      .join(df_operation,Seq("carrier_id","inc_day"),"left")
      .withColumn("is_operation",when(!isEmptyOrNull('operation_inc_day),1).otherwise(0))
      .withColumn("is_log_in",when('is_log_in === 1,1).otherwise(0))
      .withColumn("log_in_times",when(!isEmptyOrNull('log_in_times),'log_in_times).otherwise(0))

    val cols = spark.sql("""select * from dm_gis.carrier_conduct_result limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols: _*),Seq("inc_day"),"dm_gis.carrier_conduct_result")

  }

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始  ++++")
    execute(spark,inc_day)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

}
