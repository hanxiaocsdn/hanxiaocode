package app

import com.sf.gis.java.base.util.DistanceUtils.getDistance
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class GisEtaStdlineRetrunDetail extends java.io.Serializable {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    def gis_eta_stdline_retrun(spark: SparkSession, incDay: String, lastDay: String): DataFrame = {
        spark.udf.register("lld", getDistance _)
        val sql =
            s"""
               |with t1 as (
               |    select
               |        from_unixtime(cast(substring(get_json_object(loginfo, '$$.dataTime'), 0, 10) as bigint), 'yyyyMMdd') as loginfoTime,
               |    	get_json_object(loginfo, '$$.subType')                              as subType,
               |    	get_json_object(loginfo, '$$.data.requestId')                       as requestId,
               |    	get_json_object(loginfo, '$$.data.interfaceControl')                as interfaceControl,
               |    	get_json_object(loginfo, '$$.data.taskId')                          as taskId,
               |    	get_json_object(loginfo, '$$.data.reqStartTime')                    as reqStartTime,
               |    	get_json_object(loginfo, '$$.data.reqEndTime')                      as reqEndTime,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.ak')              as ak,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.srcZoneCode')     as srcZoneCode,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.destZoneCode')    as destZoneCode,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.x1')              as x1,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.y1')              as y1,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.x2')              as x2,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.y2')              as y2,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.lineCode')        as lineCode,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.planTime')        as planTime,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.opt')             as opt,
               |    	get_json_object(loginfo, '$$.data.stdLineQueryArg.vehicle')         as vehicle,
               |    	get_json_object(loginfo, '$$.data.mLoad')                           as mLoad,
               |    	get_json_object(loginfo, '$$.data.grdTaskResult.success')           as success,
               |    	get_json_object(loginfo, '$$.data.grdTaskResult.result')            as grdTaskResult,
               |    	get_json_object(loginfo, '$$.data.groundPassZoneMatchIndex')        as groundPassZoneMatchIndex,
               |    	get_json_object(loginfo, '$$.data.groundPassZoneMatchDist')         as groundPassZoneMatchDist,
               |    	get_json_object(loginfo, '$$.data.groundPassZoneSortNum')           as groundPassZoneSortNum,
               |    	get_json_object(loginfo, '$$.data.cachePassZoneMatchIndex')         as cachePassZoneMatchIndex,
               |    	get_json_object(loginfo, '$$.data.cachedPassZoneMatchDist')         as cachedPassZoneMatchDist,
               |    	get_json_object(loginfo, '$$.data.cachePassZoneSortNum')            as cachePassZoneSortNum,
               |    	get_json_object(loginfo, '$$.data.passZoneMatchMsg')                as passZoneMatchMsg,
               |    	get_json_object(loginfo, '$$.data.status')                          as status,
               |    	get_json_object(loginfo, '$$.data.stdId')                           as stdId,
               |    	get_json_object(loginfo, '$$.data.lineRequireId')                   as lineRequireId,
               |    	get_json_object(loginfo, '$$.data.cacheStdId')                      as cacheStdId,
               |    	get_json_object(loginfo, '$$.data.cacheStdBlockRoad')               as cacheStdBlockRoad,
               |    	get_json_object(loginfo, '$$.data.passZoneTableId')                 as passZoneTableId,
               |    	get_json_object(loginfo, '$$.data.newVehicle')                      as newVehicle,
               |    	get_json_object(loginfo, '$$.data.newSrcZoneCode')                  as newSrcZoneCode,
               |    	get_json_object(loginfo, '$$.data.newDestZoneCode')                 as newDestZoneCode,
               |    	split(get_json_object(loginfo, '$$.data.newSrcZoneCoord'), ',')[0]  as newSrcZoneCoordX,
               |    	split(get_json_object(loginfo, '$$.data.newSrcZoneCoord'), ',')[1]  as newSrcZoneCoordY,
               |    	split(get_json_object(loginfo, '$$.data.newDestZoneCoord'), ',')[0] as newDestZoneCoordX,
               |    	split(get_json_object(loginfo, '$$.data.newDestZoneCoord'), ',')[1] as newDestZoneCoordY,
               |    	get_json_object(loginfo, '$$.data.stdMatchType')                    as stdMatchType,
               |    	get_json_object(loginfo, '$$.data.passZoneType')                    as passZoneType,
               |    	get_json_object(loginfo, '$$.data.coords')                          as coords,
               |    	get_json_object(loginfo, '$$.data.etaLinePassZoneInfoList')         as etaLinePassZoneInfoList,
               |    	get_json_object(loginfo, '$$.data.noStdReasonType')                 as noStdReasonType,
               |    	get_json_object(loginfo, '$$.data.noStdReasonDetail')               as noStdReasonDetail,
               |    	get_json_object(loginfo, '$$.data.blockRoadObjectList')             as blockRoadObjectList
               |    from dm_gis.gis_eta_stdline_retrun
               |    where inc_day in ('$incDay', '$lastDay')
               |        and get_json_object(loginfo, '$$.subType') = 'naviStdReq'
               |),
               |t2 as (
               |    select
               |        *,
               |        0 as stdLinetype,
               |        lld(cast(x1 as double), cast(y1 as double), cast(newSrcZoneCoordX as double), cast(newSrcZoneCoordY as double))   as start_dist,
               |        lld(cast(x2 as double), cast(y2 as double), cast(newDestZoneCoordX as double), cast(newDestZoneCoordY as double)) as end_dist
               |    from t1
               |    where loginfoTime = '$incDay'
               |)
               |insert overwrite table dm_gis.gis_eta_stdline_retrun_detail partition(inc_day = '$incDay')
               |select
               |    subType,
               |    requestId,
               |    interfaceControl,
               |    taskId,
               |    reqStartTime,
               |    reqEndTime,
               |    ak,
               |    srcZoneCode,
               |    destZoneCode,
               |    x1,
               |    y1,
               |    x2,
               |    y2,
               |    lineCode,
               |    planTime,
               |    opt,
               |    vehicle,
               |    mLoad,
               |    success,
               |    grdTaskResult,
               |    groundPassZoneMatchIndex,
               |    groundPassZoneMatchDist,
               |    groundPassZoneSortNum,
               |    cachePassZoneMatchIndex,
               |    cachedPassZoneMatchDist,
               |    cachePassZoneSortNum,
               |    passZoneMatchMsg,
               |    status,
               |    stdId,
               |    lineRequireId,
               |    cacheStdId,
               |    cacheStdBlockRoad,
               |    passZoneTableId,
               |    newVehicle,
               |    newSrcZoneCode,
               |    newDestZoneCode,
               |    newSrcZoneCoordX,
               |    newSrcZoneCoordY,
               |    newDestZoneCoordX,
               |    newDestZoneCoordY,
               |    stdMatchType,
               |    passZoneType,
               |    coords,
               |    etaLinePassZoneInfoList,
               |    noStdReasonType,
               |    noStdReasonDetail,
               |    blockRoadObjectList,
               |    stdLinetype,
               |    start_dist,
               |    end_dist,
               |    if(start_dist <= 500, 1, 0),
               |    lld(cast(x1 as double), cast(y1 as double), cast(x2 as double), cast(y2 as double))
               |from t2
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def execute(spark: SparkSession, incDay: String, lastDay: String): Unit = {
        gis_eta_stdline_retrun(spark, incDay, lastDay);
    }
}

object GisEtaStdlineRetrunDetail {
    def main(args: Array[String]): Unit = {
        val task = new GisEtaStdlineRetrunDetail
        if (args == null || args.length == 0 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入日期参数")
            return
        }
        val incDay = args(0)
        val lastDay = DateUtil.getDayBefore(incDay, "yyyyMMdd", -1)
        task.LOGGER.info("###########################################")
        task.LOGGER.info("incDay: [{}]", incDay)
        task.LOGGER.info("lastDay: [{}]", lastDay)
        task.LOGGER.info("###########################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession

        task.execute(spark, incDay, lastDay)
        task.LOGGER.info("任务执行完成")

        spark.stop()
    }
}
