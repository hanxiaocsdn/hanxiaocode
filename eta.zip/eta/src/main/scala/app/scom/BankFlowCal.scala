package app.scom

import Utils.{DateTimeUtil, JSONUtils, MD5Util, SparkUtils, StringUtils}

import java.util
import com.alibaba.fastjson.JSONObject

import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/3/23
*/

object BankFlowCal extends Serializable  {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val funcMap = new util.HashMap[String,String]()


  val ckAddress = "jdbc:clickhouse://10.216.162.10:8123/smart_community"
  val ckUser = "default"
  val ckPassword = "123456"


  val descMysqlUserName = "gis_oms_egov"
  val descMysqlPassWord = "gis_oms_egov@123@"
  val descMysqlUrl = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_egov?characterEncoding=utf-8"



  // 充电桩流水表
//  val chargingPileWaterBillsTable = "dm_gis_oms.charging_pile_waterbills"
  val chargingPileWaterBillsTable = "dm_gis.charging_pile_waterbills"

  val chargingPileWaterBillsCkTable = "charging_pile_waterbills"
  val chargingPileWaterBillsMysqlTable = "CHARGING_PILE_WATERBILLS"

  //设备归属信息流水表
//  val deviceOwnerShipWaterBillsTable = "dm_gis_oms.charging_pile_device_ownership_waterbills"
  val deviceOwnerShipWaterBillsTable = "dm_gis.charging_pile_device_ownership_waterbills"
  val deviceOwnerShipWaterBillsCkTable = "charging_pile_device_ownership_waterbills"
  val deviceOwnerShipWaterBillsMysqlTable = "CHARGING_PILE_DEVICE_OWNERSHIP_WATERBILLS"

  //汇总展示流水表
//  val summaryDisplayWaterBillsTable = "dm_gis_oms.summary_display_waterbills"
  val summaryDisplayWaterBillsTable = "dm_gis.summary_display_waterbills"
  val summaryDisplayWaterBillsCkTable = "charging_pile_summary_display_waterbills"
  val summaryDisplayWaterBillsMysqlTable = "CHARGING_PILE_SUMMARY_DISPLAY_WATERBILLS"

  //用户监控表
//  val userMontiorTable = "dm_gis_oms.scomm_user_monitor2"
  val userMontiorTable = "dm_gis.scomm_user_monitor"

  val userMontiorCkTable = "scomm_user_monitor"

  // mysql存储基表
  val mysqlBaseTable = "SCOMM_CHARGING_DEVICE_BASE"

  // mail日报
  val mailTable = "dm_gis.scomm_waterbills_foxmail"



  case class userMonitor(
                          id:String,
                          province:String,
                          city:String,
                          region:String,
                          street:String,
                          community:String,
                          aoi_name:String,
                          area_belong:String,
                          register_date:String,
                          first_order:String,
                          first_order_days:Int,
                          last_order:String,
                          last_order_days:Int,
                          days_between_charges_min:Int,
                          days_between_charges_max:Int,
                          days_between_charges_avg:Int,
                          days_between_charges_mid:Int,
                          days_between_charges_mode:Int,
                          days_between_charges_mode_fre:Int,
                          total_charging_time_min:Int,
                          total_charging_time_hour:Double,
                          total_charging_electricity:Double,
                          total_mount:Double,
                          total_discount_mount:Double,
                          total_orders:Int,
                          effective_orders:Int,
                          real_pay_orders:Int,
                          register_days:Int,
                          first_day_retained:Int,
                          three_days_retained:Int,
                          six_days_retained:Int,
                          nine_days_retained:Int,
                          twelve_days_retained:Int,
                          fifteen_days_retained:Int,
                          month_retained:Int,
                          quarter_retained:Int,
                          half_year_retained:Int,
                          year_retained:Int,
                          user_status:String,
                          statdate:String
                        )


  val userMontiorSchema = StructType(List(

    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("province", StringType, true),
    StructField("city", StringType, true),
    StructField("region", StringType, true),
    StructField("street", StringType, true),
    StructField("community", StringType, true),
    StructField("aoi_name", StringType, true),
    StructField("area_belong", StringType, true),
    StructField("register_date", StringType, true),
    StructField("first_order", StringType, true),
    StructField("last_order", StringType, true),
    StructField("last_order_days", IntegerType, true),
    StructField("days_between_charges_min", DoubleType, true),
    StructField("days_between_charges_max", DoubleType, true),
    StructField("days_between_charges_avg", DoubleType, true),
    StructField("days_between_charges_mid", DoubleType, true),
    StructField("days_between_charges_mode", DoubleType, true),
    StructField("days_between_charges_mode_fre", IntegerType, true),
    StructField("total_charging_time_min", DoubleType, true),
    StructField("total_charging_time_hour", DoubleType, true),

    StructField("total_charging_electricity", DoubleType, true),
    StructField("total_mount", DoubleType, true),
    StructField("total_discount_mount", DoubleType, true),
    StructField("total_orders", IntegerType, true),
    StructField("effective_orders", IntegerType, true),
    StructField("real_pay_orders", IntegerType, true),
    StructField("register_days", IntegerType, true),

    StructField("first_day_retained", IntegerType, true),
    StructField("three_days_retained", IntegerType, true),
    StructField("six_days_retained", IntegerType, true),
    StructField("nine_days_retained", IntegerType, true),
    StructField("twelve_days_retained", IntegerType, true),
    StructField("fifteen_days_retained", IntegerType, true),
    StructField("month_retained", IntegerType, true),
    StructField("quarter_retained", IntegerType, true),
    StructField("half_year_retained", IntegerType, true),
    StructField("year_retained", IntegerType, true)


  ))


  def init(inc_day: String): SparkSession = {


    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    //p1
    funcMap.put("充电桩流水表","processChargingPileStatistics")
    funcMap.put("充电桩设备归属信息","processDeviceOwnerShipStatistics")
    funcMap.put("流水汇总展示","processSummaryDisplayStatistics")

    spark

  }

  def processChargingPileStatistics( spark:SparkSession,incDay:String):Unit={
    logger.error(">>>开始统计:充电桩流水表<<<")

    val yesterDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-1)
//    val incDayFormat = DateTimeUtil.transformDateFormat(incDay,"yyyyMMdd","yyyy-MM-dd HH:mm:ss")
    val incDayFormat = DateTimeUtil.transformDateFormat(incDay,"yyyyMMdd","yyyy-MM-dd")

    val yesterDayFormat = DateTimeUtil.transformDateFormat(yesterDay,"yyyyMMdd","yyyy-MM-dd")

    val startDayFormat = DateTimeUtil.transformDateFormat(yesterDay,"yyyyMMdd","yyyy-MM-dd HH:mm:ss")
//    val yesterDayFormat = DateTimeUtil.transformDateFormat(yesterDay,"yyyyMMdd","yyyy-MM-dd")

    //从充电桩流水表进行计算
//    val querysql =
//      s"""
//         |select
//         |    a.charge_no charge_no,
//         |    a.coding_no coding_no,
//         |    a.coding_no_cnt coding_no_cnt,
//         |    a.order_no_cnt order_no_cnt,
//         |    sum(b.order_cnt_1) order_cnt_1,
//         |    sum(b.order_cnt_2) order_cnt_2,
//         |    a.ele_cnt ele_cnt,
//         |    a.charge_time_cnt charge_time_cnt,
//         |    a.amount amount,
//         |    a.inc_day inc_day
//         |from
//         |(
//         |select
//         |    charge_no,
//         |    coding_no,
//         |    substring(regexp_replace(charge_start,'-',''),0,8) inc_day,
//         |    count(coding_no) coding_no_cnt,
//         |    count(distinct order_no) order_no_cnt,
//         |    sum(if(order_status in ('1','-1') and  ele > 0,ele,0)) ele_cnt,
//         |    sum(if(order_status in ('1','-1') and  ele > 0,if(charge_time='' or charge_time is null,0,charge_time),0)) / 60 charge_time_cnt,
//         |    sum(mount) / 100 amount
//         |from
//         |    dm_gis_oms.scomm_order_record
//         |where
//         |    (charge_start like '${incDayFormat}%' or charge_start like '${yesterDayFormat}%')
//         |and
//         |    charge_no not in ('8580002077','18580002075','2014300923','600A000002E6')
//         |group by
//         |    charge_no,coding_no,substring(regexp_replace(charge_start,'-',''),0,8)
//         |) a
//         |left outer join
//         |(
//         |select
//         |    substring(regexp_replace(charge_start,'-',''),0,8) inc_day,
//         |    charge_no,
//         |    coding_no,
//         |    order_no,
//         |    sum(if((order_status in ('1','-1') and ele > 0),1,0)) order_cnt_1,
//         |    sum(if(order_status =1 and (if(pre_mount='' or pre_mount is null,0,pre_mount) > 0),1,0)) order_cnt_2
//         |from
//         |    dm_gis_oms.scomm_order_record
//         |where
//         |    (charge_start like '${incDayFormat}%' or charge_start like '${yesterDayFormat}%')
//         |and
//         |    charge_no not in ('8580002077','18580002075','2014300923','600A000002E6')
//         |group by
//         |    substring(regexp_replace(charge_start,'-',''),0,8),charge_no,coding_no,order_no
//         |) b
//         |on
//         |    a.inc_day = b.inc_day
//         |and
//         |    a.charge_no = b.charge_no
//         |and
//         |    a.coding_no = b.coding_no
//         |group by
//         |    a.charge_no,a.coding_no,a.coding_no_cnt,a.order_no_cnt,a.ele_cnt,a.charge_time_cnt,a.amount,a.inc_day
//         |""".stripMargin
//

    val querysql =
      s"""
         |select
         |    a.charge_no charge_no,
         |    a.coding_no coding_no,
         |    a.coding_no_cnt coding_no_cnt,
         |    a.order_no_cnt order_no_cnt,
         |    sum(b.order_cnt_1) order_cnt_1,
         |    sum(b.order_cnt_2) order_cnt_2,
         |    a.ele_cnt ele_cnt,
         |    a.charge_time_cnt charge_time_cnt,
         |    a.amount amount,
         |    a.inc_day
         |from
         |(
         |select
         |    charge_no,
         |    coding_no,
         |    substring(regexp_replace(create_time,'-',''),0,8) inc_day,
         |    count(coding_no) coding_no_cnt,
         |    count(distinct order_no) order_no_cnt,
         |    sum(if(order_status not in ('0','-3') and  ele > 0,ele,0)) / 10000  ele_cnt,
         |    sum(if(order_status not in ('0','-3') and  ele > 0,if(charge_time='' or charge_time is null,0,charge_time),0)) / 60 charge_time_cnt,
         |    sum(mount) / 100 amount
         |from
         |    dm_gis_oms.scomm_order_record
         |where
         |    (create_time like '${incDayFormat}%' or create_time like '${yesterDayFormat}%')
         |and
         |    charge_no not in ('8580002077','18580002075','2014300923','600A000002E6')
         |group by
         |    charge_no,coding_no,substring(regexp_replace(create_time,'-',''),0,8)
         |) a
         |left outer join
         |(
         |select
         |    substring(regexp_replace(create_time,'-',''),0,8) inc_day,
         |    charge_no,
         |    coding_no,
         |    order_no,
         |    sum(if((order_status not in ('0','-3') and ele > 0),1,0)) order_cnt_1,
         |    sum(if(order_status not in ('0','-3') and (if(pay_mount='' or pay_mount is null,0,pay_mount) > 0),1,0)) order_cnt_2
         |from
         |    (
         |    select
         |        *
         |    from
         |        dm_gis_oms.scomm_order_record
         |    where
         |       (create_time like '${incDayFormat}%' or create_time like '${yesterDayFormat}%')
         |    and
         |        charge_no not in ('8580002077','18580002075','2014300923','600A000002E6')
         |    ) record
         |    left outer join
         |    (
         |    select
         |       payment_order_no, pay_mount
         |    from
         |    (
         |    select
         |        order_no payment_order_no,mount pay_mount,row_number() over(partition by order_no order by mount) as rn
         |    from
         |        dm_gis_oms.scomm_order_payment
         |    group by
         |        order_no,mount
         |    ) t1
         |    where
         |        rn = 1
         |    ) payment
         |    on record.order_no = payment.payment_order_no
         |where
         |    (create_time like '${incDayFormat}%' or create_time like '${yesterDayFormat}%')
         |and
         |    charge_no not in ('8580002077','18580002075','2014300923','600A000002E6')
         |group by
         |    substring(regexp_replace(create_time,'-',''),0,8),charge_no,coding_no,order_no
         |) b
         |on
         |    a.inc_day = b.inc_day
         |and
         |    a.charge_no = b.charge_no
         |and
         |    a.coding_no = b.coding_no
         |group by
         |    a.charge_no,a.coding_no,a.coding_no_cnt,a.order_no_cnt,a.ele_cnt,a.charge_time_cnt,a.amount,a.inc_day
       """.stripMargin

    logger.error(querysql)


    val chargingPileDf = spark.sql(querysql).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("chargingPileDf的总数据量为：" + chargingPileDf.count())
    chargingPileDf.take(2).foreach(println(_))
    chargingPileDf.repartition(100).write.mode(SaveMode.Overwrite).insertInto(chargingPileWaterBillsTable)
    chargingPileDf.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/20220414_1.csv")

    val md5FuctionSeq = udf(calMd5Seq _)

    val sourceIdDf = chargingPileDf.select(col("*"),md5FuctionSeq(array(col("charge_no"),col("coding_no"),col("inc_day"),col("coding_no_cnt"),col("order_no_cnt"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)

    val dfToMysqlDf = sourceIdDf.select(col("id") as "id",col("inc_day") as "statdate",col("charge_no") as "charge_no",col("coding_no") as "coding_no",
      col("coding_no_cnt") as "coding_no_cnt",col("order_no_cnt") as "order_no_cnt",col("order_cnt_1") as "order_cnt_1",col("order_cnt_2") as "order_cnt_2",
      col("ele_cnt") as "ele_cnt",col("charge_time_cnt") as "charge_time_cnt",col("amount") as "amount")

    //保存到mysql
    SparkUtils.df2MysqlDf2(spark,dfToMysqlDf,descMysqlUserName,descMysqlPassWord,descMysqlUrl,chargingPileWaterBillsMysqlTable,incDay,yesterDay,logger)

    //resDf.take(2).foreach(println(_))
    //SparkUtils.df2ClickHouse(spark,resDf,ckUser,ckPassword,ckAddress,chargingPileWaterBillsCkTable,incDay,logger)


  }



  def processDeviceOwnerShipStatistics( spark:SparkSession,incDay:String):Unit={

    logger.error(">>>开始统计:充电桩设备归属信息<<<")
    val incDayFormat = DateTimeUtil.transformDateFormat(incDay,"yyyyMMdd","yyyy-MM-dd")
    val startDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-3)

    val querySql =
      s"""
         |
         |select
         |    province_name,city_name,region_name,street,community,village,station_name,device_no,
         |    d_status,total_order_cnt,effective_order_cnt, pay_order_cnt,
         |    ele_cnt,charge_time_cnt,amount,socket_number,total_status,price
         |from
         |(
         |select
         |    device.province_name province_name,city_name,region as region_name,street,community,village,station_name,device_no,
         |    d_status,order_no_cnt total_order_cnt,order_cnt_1 effective_order_cnt,order_cnt_2 pay_order_cnt,
         |    ele_cnt,charge_time_cnt,amount,socket_number,total_status,price
         |from
         |(
         |select
         |    province_name,city_name,region,
         |    street,community,village,regexp_replace(station_name, '[\\r\\n\\s,]+', '') station_name,device_no,
         |    d_status,socket_number
         |from
         |    dm_gis_oms.scomm_charging_device
         |where
         |    substring(regexp_replace(create_time, '-', ''),0,8) <= '${incDay}'
         |and
         |    del_flag=0
         |and device_no not in ('18580002077','18580002075','2014300923','600A000002E6')
         |) device
         |left outer join
         |(
         |select
         |    *
         |from
         |(
         |select
         |    device_no device_no_status,total_status,row_number() over (partition by device_no order by create_time desc) rn
         |from
         |    dm_gis_oms.scomm_flow_device_status
         |where
         |    statistic_date like '${incDayFormat}%'
         |) device_status
         |where
         |    rn = 1
         |) status
         |on
         |    device.device_no = status.device_no_status
         |left outer join
         |(
         |select
         |    charge_no,sum(order_no_cnt) order_no_cnt,sum(order_cnt_1) order_cnt_1,sum(order_cnt_2) order_cnt_2,sum(ele_cnt) ele_cnt,sum(charge_time_cnt) charge_time_cnt,sum(amount) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    charge_no
         |) waterbills
         |on
         |    device.device_no = waterbills.charge_no
         |left outer join
         |(
         |select
         |    province_name,price
         |from
         |    dm_gis_oms.scomm_electrovalence
         |) elect
         |on device.province_name = elect.province_name
         |and (device.station_name != '' or device.station_name is not null)
         |) a
       """.stripMargin

//    val querySql =
//      s"""
//         |select
//         |  *
//         |from
//         |(
//         |select
//         |    device.province_name,city_name,region as region_name,street,community,village,station_name,device_no,
//         |    d_status,order_no_cnt total_order_cnt,order_cnt_1 effective_order_cnt,order_cnt_2 pay_order_cnt,
//         |    ele_cnt,charge_time_cnt,amount,socket_number,total_status,price
//         |from
//         |(
//         |select
//         |    province_name,city_name,region,
//         |    street,community,village,station_name,device_no,
//         |    d_status,socket_number,device_no device_no_new
//         |from
//         |    dm_gis_oms.scomm_charging_device
//         |where
//         |    regexp_replace(create_time,'-','') <= '${incDay}'
//         |and
//         |    del_flag=0
//         |) device
//         |left outer join
//         |(
//         |select
//         |    *
//         |from
//         |(
//         |select
//         |    device_no,total_status,row_number() over (partition by device_no order by create_time desc) rn
//         |from
//         |    dm_gis_oms.scomm_flow_device_status
//         |where
//         |    statistic_date like '${incDayFormat}%'
//         |) device_status
//         |where
//         |    rn = 1
//         |) status
//         |on
//         |    device.device_no = status.device_no
//         |left outer join
//         |(
//         |select
//         |    charge_no,sum(order_no_cnt) order_no_cnt,sum(order_cnt_1) order_cnt_1,sum(order_cnt_2) order_cnt_2,sum(ele_cnt) ele_cnt,sum(charge_time_cnt) charge_time_cnt,sum(amount) amount
//         |from
//         |(
//         |select
//         |    *
//         |from
//         |    dm_gis.charging_pile_waterbills
//         |where
//         |    inc_day = '${incDay}'
//         |) a
//         |group by
//         |    charge_no
//         |) waterbills
//         |on
//         |    device.device_no = waterbills.charge_no
//         |left outer join
//         |(
//         |select
//         |    province_name,price
//         |from
//         |    dm_gis_oms.scomm_electrovalence
//         |) elect
//         |on device.province_name = elect.province_name
//         |and (station_name != '' or station_name is not null)
//         |) a
//       """.stripMargin

    val ownerShipDf = spark.sql(querySql).withColumn("inc_day",lit(incDay)).distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ownerShipDf的总数据量为：" + ownerShipDf.count())
    ownerShipDf.take(2).foreach(println(_))
    ownerShipDf.repartition(20).write.mode(SaveMode.Overwrite).insertInto(deviceOwnerShipWaterBillsTable)

//    ownerShipDf.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/20220414_2.csv")


    val md5FuctionSeq = udf(calMd5Seq _)

    val sourceIdDf = ownerShipDf.select(col("*"),md5FuctionSeq(array(col("province_name"),col("city_name"),col("region_name")
      ,col("street"),col("community"),col("village"),col("station_name"),col("device_no"),col("inc_day"),col("d_status"),col("pay_order_cnt") ,col("ele_cnt") ,col("charge_time_cnt") ,col("amount") ,col("socket_number") ,col("total_status"),col("price"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)

    sourceIdDf.printSchema()

    val dfToMysqlDf = sourceIdDf.select(
      col("id") as "id",lit(incDay) as "statdate",col("province_name") as "province_name",col("city_name") as "city_name",
      col("region_name") as "region_name",col("street") as "street",col("community") as "community",col("village") as "village",
      col("station_name") as "station_name",col("device_no") as "device_no",col("d_status") as "d_status",col("total_order_cnt") as "total_order_cnt",
      col("effective_order_cnt") as "effective_order_cnt",col("pay_order_cnt") as "pay_order_cnt",col("ele_cnt") as "ele_cnt",col("charge_time_cnt") as "charge_time_cnt",
      col("amount") as "amount",col("socket_number") as "socket_number",col("total_status") as "total_status",col("price") as "price").persist(StorageLevel.MEMORY_AND_DISK_SER)

    //保存到mysql
    SparkUtils.df2MysqlDf(spark,dfToMysqlDf,descMysqlUserName,descMysqlPassWord,descMysqlUrl,deviceOwnerShipWaterBillsMysqlTable,incDay,logger)

//    val md5Fuction = udf(calMd5Seq _)
//
//
//    val sourceIdDf = ownerShipDf.select(col("*"),md5Fuction(array(col("province_name"),col("city_name"),col("region_name")
//      ,col("street"),col("community"),col("village"),col("station_name"),col("device_no"),col("inc_day"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    sourceIdDf.take(2).foreach(println(_))
//
//    SparkUtils.df2ClickHouse(spark,sourceIdDf,ckUser,ckPassword,ckAddress,deviceOwnerShipWaterBillsCkTable,incDay,logger)



  }



  def processSummaryDisplayStatistics(spark:SparkSession, incDay:String):Unit={
    logger.error(">>>开始统计:流水汇总展示表<<<")
    val startDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-3)

    val querySql =
      s"""
         |select
         |  *
         |from
         |(
         |select
         |    'country' type,'-' province,'-' city,'-' region,'-' street,'-' community,'-' village, '-' station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    '0' as price,
         |     -- price.price as price,
         |    price.price * ele_cnt as cost,
         |    amount * 100 / (CAST(price.price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  'country' type,
         |  '-' device_no,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |) waterbills
         |
 |left outer join
         |(
         |select
         |   'country' type, sum(total_cost) / sum(ele_cnt) price
         |from
         |(
         |select
         |    province_name,price * ele_cnt total_cost,ele_cnt
         |from
         |(
         |select
         |  province_name,
         |  price,
         |  sum(ele_cnt) ele_cnt
         |from
         |  dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |group by
         |   province_name,price
         |) b
         |) bb
         |) price
         |on
         |waterbills.type = price.type
         |
 |union all
         |-- 省
         |select
         |
 |    'province',province_name province,'-' city,'-' region,'-' street,'-' community,'-' village, '-' station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  price,
         |  '-' device_no,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    province_name,price
         |) waterbills
         |
 |union all
         |-- 市
         |select
         |    'city',province_name province,city_name city,'-' region,'-' street,'-' community,'-' village, '-' station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  price,
         |  city_name,
         |  '-' device_no,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    province_name,city_name,price
         |) waterbills
         |
 |union all
         |-- 区
         |select
         |    'region',province_name province,city_name city,region_name region,'-' street,'-' community,'-' village, '-' station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  city_name,
         |  region_name,
         |  '-' device_no,
         |  price,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    price,province_name,city_name,region_name
         |) waterbills
         |
 |union all
         |-- street
         |-- 街道
         |select
         |    'street',province_name province,city_name city,region_name region,street,'-' community,'-' village, '-' station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  city_name,
         |  region_name,
         |  street,
         |  '-' device_no,
         |  price,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    price,province_name,city_name,region_name,street
         |) waterbills
         |
 |union all
         |-- community社区
         |select
         |    'community',province_name province,city_name city,region_name region,street,community,'-' village, '-' station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  city_name,
         |  region_name,
         |  street,
         |  community,
         |  '-' device_no,
         |  price,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    price,province_name,city_name,region_name,street,community
         |) waterbills
         |
 |union all
         |-- village
         |select
         |    'village',province_name province,city_name city,region_name region,street,community,village, '-' station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  city_name,
         |  region_name,
         |  street,
         |  community,
         |  village,
         |  '-' device_no,
         |  price,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    price,province_name,city_name,region_name,street,community,village
         |) waterbills
         |
 |union all
         |-- station
         |select
         |    'station',province_name province,city_name city,region_name region,street,community,village,station_name station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  city_name,
         |  region_name,
         |  street,
         |  community,
         |  village,
         |  station_name,
         |  '-' device_no,
         |  price,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    price,province_name,city_name,region_name,street,community,village,station_name
         |) waterbills
         |
 |union all
         |-- device
         |select
         |    'device',province_name province,city_name city,region_name region,street,community,village,station_name station,device_no device,
         |    device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,
         |    effective_order_cnt / online_socket_cnt as per_socket_ratio,
         |    amount / pay_order_cnt as per_price,
         |    ele_cnt / effective_order_cnt as per_ele_cnt,
         |    charge_time_cnt / effective_order_cnt as per_charge_time,
         |    price as price,
         |    price * ele_cnt as cost,
         |    amount * 100 / (CAST(price AS double)  * CAST(ele_cnt AS double))  amount_ratio
         |from
         |(
         |select
         |  province_name,
         |  city_name,
         |  region_name,
         |  street,
         |  community,
         |  village,
         |  station_name,
         |  device_no,
         |  price,
         |  sum(if(d_status!= 9,1,0)) device_cnt,
         |  sum(if(d_status!= 9,if(socket_number='',0,socket_number),0)) device_socket_cnt,
         |  sum(if(total_status=1,1,0)) online_device_cnt,
         |  sum(if(total_status=1,if(socket_number='',0,socket_number),0)) online_socket_cnt, -- 口数
         |  sum(if(total_status=1,if(total_order_cnt='',0,total_order_cnt),0)) total_order_cnt,
         |  sum(if(total_status=1,if(effective_order_cnt='',0,effective_order_cnt),0)) effective_order_cnt,
         |  sum(if(total_status=1,if(pay_order_cnt='',0,pay_order_cnt),0)) pay_order_cnt,
         |  sum(if(total_status=1,if(ele_cnt='',0,ele_cnt),0)) ele_cnt,
         |  sum(if(total_status=1,if(charge_time_cnt='',0,charge_time_cnt),0)) charge_time_cnt,
         |  sum(if(total_status=1,if(amount='',0,amount),0)) amount
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis.charging_pile_device_ownership_waterbills
         |where
         |    inc_day = '${incDay}'
         |) a
         |group by
         |    price,province_name,city_name,region_name,street,community,village,station_name,device_no
         |) waterbills
         |) show
         |where show.device_cnt > 0
         |""".stripMargin


//    logger.error("querySql:" + querySql)
    val summaryDispalyDf = spark.sql(querySql).withColumn("inc_day",lit(incDay)).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ownerShipDf的总数据量为：" + summaryDispalyDf.count())
    summaryDispalyDf.take(2).foreach(println(_))
    summaryDispalyDf.repartition(10).write.mode(SaveMode.Overwrite).insertInto(summaryDisplayWaterBillsTable)
//    summaryDispalyDf.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/20220414_3.csv")


    val md5FuctionSeq = udf(calMd5Seq _)

    val sourceIdDf = summaryDispalyDf.select(col("*"),md5FuctionSeq(array(col("type"),col("province"),col("city"),col("region"),col("street"),
      col("community"),col("village"),col("station"),col("device"),col("device_cnt"),col("inc_day"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)

    sourceIdDf.printSchema()

    //    type,province,city,region,street,community,village,station,device,device_cnt,device_socket_cnt,
    // online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,per_socket_ratio,
    // per_price,per_ele_cnt,per_charge_time,price,cost,amount_ratio,inc_day,id

    val dfToMysqlDf = sourceIdDf.select(
      col("id") as "id",col("inc_day") as "statdate",col("type") as "type",col("province") as "province",col("city") as "city",
      col("region") as "region",col("street") as "street",col("community") as "community",col("village") as "village",
      col("station") as "station",col("device") as "device",col("device_cnt") as "device_cnt",col("device_socket_cnt") as "device_socket_cnt",
      col("online_device_cnt") as "online_device_cnt",col("online_socket_cnt") as "online_socket_cnt",col("total_order_cnt") as "total_order_cnt",
      col("effective_order_cnt") as "effective_order_cnt", col("pay_order_cnt") as "pay_order_cnt",col("ele_cnt") as "ele_cnt",col("charge_time_cnt") as "charge_time_cnt",
      col("amount") as "amount",col("per_socket_ratio") as "per_socket_ratio",col("per_price") as "per_price",col("per_ele_cnt") as "per_ele_cnt",
      col("per_charge_time") as "per_charge_time",col("price") as "price",col("cost") as "cost",col("amount_ratio") as "amount_ratio").persist(StorageLevel.MEMORY_AND_DISK_SER)


    //保存到mysql
    SparkUtils.df2MysqlDf(spark,dfToMysqlDf,descMysqlUserName,descMysqlPassWord,descMysqlUrl,summaryDisplayWaterBillsMysqlTable,incDay,logger)




    //    val md5Fuction = udf(calMd5Seq _)
    //
    //    val sourceIdDf = summaryDispalyDf.select(col("*"),md5Fuction(array(col("type"),col("province"),col("city"),col("region"),col("street"),
    //      col("community"),col("village"),col("station"),col("device"),col("inc_day"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)


    //    saveToCkProcess(spark,incDay)


  }



  def getUserMonitorProcess(spark: SparkSession, incDay: String, sourceRdd: RDD[JSONObject]) = {

    val userMonitorRdd = sourceRdd

      .map(x => {

        val id = x.getString("id")
        val full_name = x.getString("full_name")

        var province = ""
        var city = ""
        var region = ""
        var street = ""
        var community = ""
        val aoi_name = x.getString("name")
        try {
          if (full_name != null && full_name != "") {

            val name_array = full_name.split("-")
            province = name_array(1)
            city = name_array(2)
            region = name_array(3)
            street = name_array(4)
            community = name_array(5)
          }
        }catch{
          case e:Exception => e.printStackTrace()
        }

        //用户id 用户所在省 用户所在市 用户所在区 用户所在街道 用户所在社区 用户所在小区 用户所属区代码
        x.put("province",province)
        x.put("city",city)
        x.put("region",region)
        x.put("street",street)
        x.put("community",community)
        x.put("aoi_name",aoi_name)

        (id,x)
      }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .flatMap(x => {
        val id = x._1
        val list = x._2.toList
          .filter(obj => {
            val create_time_order = JSONUtils.getJsonValue(obj, "create_time_order", "2000-01-01 00:00:00")
            val create_time = JSONUtils.getJsonValue(obj, "create_time", "2000-01-01 00:00:00")
            create_time_order > create_time
          })
        //用户所在省 用户所在市 用户所在区 用户所在街道 用户所在社区 用户所在小区 用户所属区代码 注册日期

        val province =try {JSONUtils.getJsonValue(list(0),"province","")}catch {case e:Exception => ""}

        val city =try {JSONUtils.getJsonValue(list(0),"city","")}catch {case e:Exception => ""}
        val region =try {JSONUtils.getJsonValue(list(0),"region","")}catch {case e:Exception => ""}
        val street =try {JSONUtils.getJsonValue(list(0),"street","")}catch {case e:Exception => ""}
        val community =try {JSONUtils.getJsonValue(list(0),"community","")}catch {case e:Exception => ""}
        val aoi_name =try {JSONUtils.getJsonValue(list(0),"aoi_name","")}catch {case e:Exception => ""}
        val area_belong =try {JSONUtils.getJsonValue(list(0),"area_belong","")}catch {case e:Exception => ""}
        val register_date = try {JSONUtils.getJsonValue(list(0),"create_time","2000-01-01 00:00:00")}catch {case e:Exception => "2000-01-01 00:00:00"}

        //charge_start 进行排序
        val sortList = list.filter(y => {
          val order_status = JSONUtils.getJsonValueInt(y, "order_status", -999)
          order_status != -3 && order_status != 0
        }).sortBy(_.getString("charge_start"))

        // 以用户id分组，按照开始充电时间（charge_start）升序排列，取第一单充电订单的日期
        val first_order = if (sortList.size != 0)  JSONUtils.getJsonValue(sortList(0), "charge_start", "2000-01-01 00:00:00") else "2000-01-01 00:00:00"
        val first_order_days = DateTimeUtil.parseFtTimeDay(first_order,incDay,"yyyy-MM-dd HH:mm:ss","yyyyMMdd")

        var last_order = if (sortList.size != 0) JSONUtils.getJsonValue(sortList(sortList.size-1), "charge_start", "2000-01-01 00:00:00") else "2000-01-01 00:00:00"
        val last_order_days = DateTimeUtil.parseFtTimeDay(last_order,incDay,"yyyy-MM-dd HH:mm:ss","yyyyMMdd")


        val between_charges_list = new ArrayBuffer[Int]()
        val between_map = new mutable.HashMap[Int,Int]()

        //充电间隔距离最小时长（h）
        var days_between_charges_min = 0
        //充电间隔距离最大时长（h）
        var days_between_charges_max = 0
        //平均充电间隔时长（h）
        var days_between_charges_avg = 0
        //充电间隔时长中位数（h）
        var days_between_charges_mid = 0
        //充电间隔频次最高天数（众数）
        var days_between_charges_mode = -1
        //充电间隔频次最高天数对应的频次
        var days_between_charges_mode_fre = 0
        //总充电间隔和
        var between_sum = 0

        if (sortList.size > 1) {
          // 分别计算从第二单开始，每一单与下一单间隔时长差值的绝对值
          // TODO: 增加充电间隔频次天数
          for (i <- (0 until(sortList.size -1))){
            val cur_charge_start = JSONUtils.getJsonValue(sortList(i),"charge_start","2000-01-01 00:00:00")
            val next_charge_start = JSONUtils.getJsonValue(sortList(i + 1),"charge_start","2000-01-01 00:00:00")
            val diffHour = DateTimeUtil.parseFtTimeHour(cur_charge_start,next_charge_start,"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm:ss")
            val diffDay = DateTimeUtil.parseFtTimeDay(cur_charge_start,next_charge_start,"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm:ss")

            between_charges_list.append(diffHour)
            between_sum += diffHour
            if (between_map.contains(diffDay)) between_map.put(diffDay,between_map(diffDay) + 1) else between_map.put(diffDay, 1)
          }
          val between_sort_list =  between_charges_list.sortWith(_ < _).toList
          days_between_charges_min = between_sort_list.head
          days_between_charges_max = between_sort_list.last
          days_between_charges_avg = between_sum / between_sort_list.size
          days_between_charges_mid = between_sort_list(between_sort_list.size / 2)

          for ((key,value) <- between_map){
            if (days_between_charges_mode_fre < value){
              days_between_charges_mode_fre = value
              days_between_charges_mode = key
            }
          }
        }

        //总充电时长（min）
        var total_charging_time_min = 0.0
        //总充电时长（h）
        var total_charging_time_hour = 0.0
        //总充电电量（度）
        var total_charging_electricity = 0.0
        //总实际支付金额（元）
        var total_mount = 0.0
        //总优惠金额（元）
        var total_discount_mount = 0.0
        //总充电单数
        var total_orders = 0
        //有效单量
        var effective_orders = 0
        //实付单量
        var real_pay_orders = 0
        //注册天数
        val register_days = try {DateTimeUtil.parseFtTimeDay(JSONUtils.getJsonValue(list(0),"create_time",""),incDay,"yyyy-MM-dd HH:mm:ss","yyyyMMdd") } catch {case e:Exception => -1}

        //计算user_status
        //          var order_status_cnt0 = 0
        //          var order_status_cnt1 = 0

        sortList.map(obj => {
          val charge_end = JSONUtils.getJsonValue(obj,"charge_end","2000-01-01 00:00:00")
          val charge_start = JSONUtils.getJsonValue(obj,"charge_start","2000-01-01 00:00:00")
          val occupancy_time = JSONUtils.getJsonValueInt(obj,"occupancy_time",0)

          val mount = JSONUtils.getJsonValueDouble(obj,"mount",0)
          val discount_type = JSONUtils.getJsonValueDouble(obj,"discount_type",0)
          val order_no = JSONUtils.getJsonValue(obj,"order_no","0")
          val order_status = JSONUtils.getJsonValue(obj,"order_status","-999")
          val ele =  JSONUtils.getJsonValueDouble(obj,"ele",0)
          // 充电时间计算 charge_end-charge_start-occupancy_time
          val charge_time = if(StringUtils.nonEmpty(charge_end)) DateTimeUtil.parseFtTimeMin(charge_start,charge_end,"yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm:ss") - occupancy_time else 0

          total_charging_time_min += charge_time
          total_charging_time_hour += (charge_time / 60.0)
          total_charging_electricity += ele * 0.0001
          total_mount += mount * 0.01
          if (discount_type == 1 || discount_type == 2) total_discount_mount += mount * 0.01
        })

        list.map(obj => {
          val mount = JSONUtils.getJsonValueDouble(obj,"mount",0)
          val order_status = JSONUtils.getJsonValue(obj,"order_status","-999")
          total_orders += 1
          if (!"-3".equals(order_status) && !"0".equals(order_status)) effective_orders += 1
          if (!"-3".equals(order_status) && !"0".equals(order_status) && mount != 0) real_pay_orders += 1
        })

        //user_status
        val user_status = if (effective_orders != 0) {"该用户产生有效订单"}
        else if (total_orders == 0)  {"该用户注册未产生订单"}
        else if (effective_orders == 0) {"该用户注册未产生有效订单"}
        else {""}


        val retentArray = Array((0,1),(1,4),(4,7),(7,10),(10,13),(13,16),(16,31),(31,91),(91,181),(181,366))

        var retentlist = List[Int]()

        val create_time = if (sortList.size > 0) JSONUtils.getJsonValue(sortList(0),"create_time","2000-01-01 00:00:00") else "2000-01-01 00:00:00"
        for ( i <- 0 until retentArray.length) {
          val (day1,day2) = retentArray(i)

          if (sortList.size > 0){
            val retentReslist = sortList.filter(x => {
              val charge_start = JSONUtils.getJsonValue(x, "charge_start", "2000-01-01 00:00:00")
              // TODO: 获取当天数据
              val start_day = DateTimeUtil.getDaysApartDateSetHour(create_time,"yyyy-MM-dd HH:mm:ss",day1)
              // TODO: 获取指定天后0点数据
              val end_day = DateTimeUtil.getDaysApartDateSetHour(create_time,"yyyy-MM-dd HH:mm:ss",day2)
              charge_start >= start_day && charge_start <= end_day
            })
            retentlist = retentlist :+ retentReslist.length
          }else{
            retentlist = retentlist :+ 0
          }
        }

        val userMonRow = Row(id,incDay,province,city,region,street,community,aoi_name,area_belong,register_date,first_order,first_order_days,last_order,
          last_order_days,days_between_charges_min,days_between_charges_max,days_between_charges_avg,days_between_charges_mid,
          days_between_charges_mode,days_between_charges_mode_fre,total_charging_time_min,total_charging_time_hour,
          total_charging_electricity,total_mount,total_discount_mount,total_orders,effective_orders,real_pay_orders,register_days
        )
        var rowList = List[Row]()
        rowList = rowList :+ Row.merge(userMonRow,Row.fromSeq(retentlist),Row(user_status))
        rowList
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("userMonitorRdd的数据量为:" + userMonitorRdd.count())
    userMonitorRdd.take(2).foreach(println(_))
    userMonitorRdd

  }

  def userMonitorSaveToHive(spark: SparkSession, incDay: String, userMonitorrdd: RDD[Row]) = {

    import spark.implicits._
    val userMonitorRdd = userMonitorrdd.map(x => {
      val id= x.getString(0)
      val statdate= x.getString(1)
      val province= x.getString(2)
      val city= x.getString(3)
      val region= x.getString(4)
      val street= x.getString(5)
      val community= x.getString(6)
      val aoi_name= x.getString(7)
      val area_belong= x.getString(8)
      val register_date= x.getString(9)
      val first_order= x.getString(10)
      val first_order_days= x.getInt(11)
      val last_order= x.getString(12)
      val last_order_days= x.getInt(13)
      val days_between_charges_min= x.getInt(14)
      val days_between_charges_max= x.getInt(15)
      val days_between_charges_avg= x.getInt(16)
      val days_between_charges_mid= x.getInt(17)
      val days_between_charges_mode= if (x.getInt(19) != 1) x.getInt(18) else -1
      val days_between_charges_mode_fre= x.getInt(19)
      val total_charging_time_min= x.getDouble(20).toInt
      val total_charging_time_hour= x.getDouble(21).formatted("%.2f").toDouble
      val total_charging_electricity= x.getDouble(22).formatted("%.4f").toDouble
      val total_mount= x.getDouble(23).formatted("%.2f").toDouble
      val total_discount_mount= x.getDouble(24).formatted("%.2f").toDouble
      val total_orders= x.getInt(25)
      val effective_orders= x.getInt(26)
      val real_pay_orders= x.getInt(27)
      val register_days= x.getInt(28)
      val first_day_retained= x.getInt(29)
      val three_days_retained= x.getInt(30)
      val six_days_retained= x.getInt(31)
      val nine_days_retained= x.getInt(32)
      val twelve_days_retained= x.getInt(33)
      val fifteen_days_retained= x.getInt(34)
      val month_retained= x.getInt(35)
      val quarter_retained= x.getInt(36)
      val half_year_retained= x.getInt(37)
      val year_retained= x.getInt(38)
      val user_status = x.getString(39)
      userMonitor(id,province,city,region,street,community,aoi_name,area_belong,register_date,first_order,first_order_days,last_order,
        last_order_days,days_between_charges_min,days_between_charges_max,days_between_charges_avg,days_between_charges_mid,
        days_between_charges_mode,days_between_charges_mode_fre,total_charging_time_min,total_charging_time_hour,
        total_charging_electricity,total_mount,total_discount_mount,total_orders,effective_orders,real_pay_orders,register_days,
        first_day_retained,three_days_retained,six_days_retained,nine_days_retained,twelve_days_retained,fifteen_days_retained,month_retained,
        quarter_retained,half_year_retained,year_retained,user_status,statdate
      )
    })

    val userMonitorDf = userMonitorRdd.toDF()


    userMonitorDf.write.mode(SaveMode.Overwrite).insertInto(userMontiorTable)

//    userMonitorDf.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/test/20220409.csv")


  }

  def userMonitorStatistics(spark:SparkSession, incDay:String) ={

    val sourceSql =
      s"""
         |select
         |  userTable.id,full_name,name,area_belong,userTable.create_time,orderTable.create_time as create_time_order,charge_start,charge_end,occupancy_time,order_no,order_status,mount,ele,charge_time,discount_type
         |from
         |(
         |select
         |  *
         |from
         |  dm_gis_oms.scomm_user
         | ) userTable
         |left outer join
         |(
         |select
         |  *
         |from
         |  dm_gis_oms.scomm_order_record
         |) orderTable
         |on userTable.id = orderTable.`user`
         |left outer join
         | (
         | select
         |  *
         | from
         |  dm_gis_oms.scomm_administrative_area
         | ) area
         | on userTable.area_belong = area.code
       """.stripMargin

      val sourceDf = spark.sql(sourceSql)
//      sourceDf.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/test/20220409_source.csv")

      val sourceRdd = SparkUtils.getRowToJson(sourceDf)
      sourceRdd.take(2).foreach(println(_))

      val userMonitorrdd = getUserMonitorProcess(spark,incDay,sourceRdd)

      userMonitorSaveToHive(spark,incDay,userMonitorrdd)

  }



  def calMd5Seq(seq: Seq[String]):String = {

    val md5Instance = MD5Util.getMD5Instance
    val id = MD5Util.getMD5(md5Instance, seq.mkString("_"))

    id
  }


  def saveToEmil(spark:SparkSession,inc_day:String):Unit = {

    val inc_day_year = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-365)
    val inc_day_month = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

    val week1 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-6)
    val week2 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-13)
    val week3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-20)
    val week4 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-26)

    val sourceSql =
      s"""
         |-- 星期 城市
         |select
         |   weektag,city,device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,effective_order_cnt_all,ele_cnt_all,
         |   amount_all,
         |   amount_all /  effective_order_cnt_all per_price,
         |   ele_cnt_all / effective_order_cnt_all per_ele_cnt,
         |   effective_order_cnt_all / (online_socket_cnt * 7) per_socket_ratio
         |from
         |(
         |select
         |    *,sum(effective_order_cnt) over(partition by weektag,city order by
         |inc_day desc rows between unbounded preceding and unbounded following)  as effective_order_cnt_all
         |    ,sum(ele_cnt) over(partition by weektag,city  order by
         |inc_day desc rows between unbounded preceding and unbounded following) as ele_cnt_all
         |    ,sum(amount) over(partition by weektag,city order by
         |inc_day desc rows between unbounded preceding and unbounded following) as amount_all
         |    ,row_number() over (partition by weektag,city order by inc_day desc) rn
         |from
         |(
         |select
         |    case when inc_day <= '${inc_day}' and inc_day>= '${week1}' then concat('${week1}','-','${inc_day}')
         |        when inc_day < '${week1}' and inc_day >= '${week2}' then concat('${week2}','-','${week1}')
         |        when inc_day < '${week2}' and inc_day >= '${week3}' then concat('${week3}','-','${week2}')
         |        when inc_day < '${week3}' and inc_day >= '${week4}' then concat('${week4}','-','${week3}')
         |        else '-'
         |    end as weektag,*
         |from
         |    dm_gis_oms.summary_display_waterbills
         |where
         |    inc_day>= '${week4}' and inc_day <='${inc_day}'
         |and type = 'city'
         |) a
         |) aa
         |where rn = 1
         |
         |union all
         |
         |-- 星期 全国
         |select
         |   weektag,'全国',device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,effective_order_cnt_all,ele_cnt_all,
         |   amount_all,
         |   amount_all /  effective_order_cnt_all per_price,
         |   ele_cnt_all / effective_order_cnt_all per_ele_cnt,
         |   effective_order_cnt_all / (online_socket_cnt * 7) per_socket_ratio
         |from
         |(
         |select
         |    *,sum(effective_order_cnt) over(partition by weektag order by
         |inc_day desc rows between unbounded preceding and unbounded following)  as effective_order_cnt_all
         |    ,sum(ele_cnt) over(partition by weektag  order by
         |inc_day desc rows between unbounded preceding and unbounded following) as ele_cnt_all
         |    ,sum(amount) over(partition by weektag order by
         |inc_day desc rows between unbounded preceding and unbounded following) as amount_all
         |    ,row_number() over (partition by weektag order by inc_day desc) rn
         |from
         |(
         |select
         |    case when inc_day <= '${inc_day}' and inc_day>= '${week1}' then concat('${week1}','-','${inc_day}')
         |        when inc_day < '${week1}' and inc_day >= '${week2}' then concat('${week2}','-','${week1}')
         |        when inc_day < '${week2}' and inc_day >= '${week3}' then concat('${week3}','-','${week2}')
         |        when inc_day < '${week3}' and inc_day >= '${week4}' then concat('${week4}','-','${week3}')
         |        else '-'
         |    end as weektag,*
         |from
         |    dm_gis_oms.summary_display_waterbills
         |where
         |    inc_day>= '${week4}' and inc_day <='${inc_day}'
         |and type = 'city'
         |) a
         |) aa
         |where rn = 1
         |union all
         |-- 月度 城市
         |select
         |    monthtag,city,device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,effective_order_cnt_all,ele_cnt_all,amount_all,
         |    amount_all /  effective_order_cnt_all per_price,
         |    ele_cnt_all / effective_order_cnt_all per_ele_cnt,
         |    effective_order_cnt_all / (online_socket_cnt * monthdaycnt) per_socket_ratio
         |from
         |(
         |select
         |    *,sum(effective_order_cnt) over(partition by monthtag,city order by
         |inc_day desc rows between unbounded preceding and unbounded following)  as effective_order_cnt_all
         |    ,sum(ele_cnt) over(partition by monthtag,city  order by
         |inc_day desc rows between unbounded preceding and unbounded following) as ele_cnt_all
         |    ,sum(amount) over(partition by monthtag,city order by
         |inc_day desc rows between unbounded preceding and unbounded following) as amount_all
         |    ,row_number() over (partition by monthtag,city order by inc_day desc) rn
         |from
         |(
         |select
         |    substring(inc_day,0,6) as monthtag,*,datediff(last_day(from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")),from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")) +1 as monthdaycnt
         |from
         |    dm_gis_oms.summary_display_waterbills
         |where
         |    inc_day>= '${inc_day_year}' and inc_day <='${inc_day}'
         |and type = 'city'
         |) a
         |) aa
         |where rn = 1
         |union all
         |-- 月度 全国
         |select
         |    monthtag,'全国',device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,effective_order_cnt_all,ele_cnt_all,amount_all,
         |    amount_all /  effective_order_cnt_all per_price,
         |    ele_cnt_all / effective_order_cnt_all per_ele_cnt,
         |    effective_order_cnt_all / (online_socket_cnt * monthdaycnt) per_socket_ratio
         |from
         |(
         |select
         |    *,sum(effective_order_cnt) over(partition by monthtag order by
         |inc_day desc rows between unbounded preceding and unbounded following)  as effective_order_cnt_all
         |    ,sum(ele_cnt) over(partition by monthtag  order by
         |inc_day desc rows between unbounded preceding and unbounded following) as ele_cnt_all
         |    ,sum(amount) over(partition by monthtag order by
         |inc_day desc rows between unbounded preceding and unbounded following) as amount_all
         |    ,row_number() over (partition by monthtag order by inc_day desc) rn
         |from
         |(
         |select
         |    substring(inc_day,0,6) as monthtag,*,datediff(last_day(from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")),from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")) +1 as monthdaycnt
         |from
         |    dm_gis_oms.summary_display_waterbills
         |where
         |    inc_day>= '${inc_day_year}' and inc_day <='${inc_day}'
         |and type = 'city'
         |) a
         |) aa
         |where rn = 1
         |-- 七天 城市
         |union all
         |select
         |    inc_day,city,device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,effective_order_cnt, ele_cnt, amount,
         |    amount /  effective_order_cnt per_price,
         |    ele_cnt / effective_order_cnt per_ele_cnt,
         |    effective_order_cnt / online_socket_cnt  per_socket_ratio
         |from
         |(
         |select
         |    *
         |from
         |    dm_gis_oms.summary_display_waterbills
         |where
         |    inc_day>= '${week1}' and inc_day <='${inc_day}'
         |and type = 'city'
         |) a
         |-- 七天 全国
         |union all
         |select
         |    inc_day,'全国',sum(device_cnt) device_cnt,sum(device_socket_cnt) device_socket_cnt,sum(online_device_cnt) online_device_cnt,sum(online_socket_cnt) online_socket_cnt,
         |    sum(effective_order_cnt) effective_order_cnt,sum(ele_cnt) ele_cnt,sum(amount) amount,sum(amount) /  sum(effective_order_cnt) per_price,sum(ele_cnt) / sum(effective_order_cnt) per_ele_cnt,sum(effective_order_cnt) / sum(online_socket_cnt) per_socket_ratio
         |from
         |    dm_gis_oms.summary_display_waterbills
         |where
         |    inc_day>= '${week1}' and inc_day <='${inc_day}'
         |and type = 'city'
         |group by
         |    inc_day
       """.stripMargin


//    val sourceSql =
//      s"""
//         |-- 月度城市
//         |select
//         |    monthtag,city,device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,effective_order_cnt,ele_cnt,amount,per_price,per_ele_cnt,
//         |effective_order_cnt / (online_socket_cnt * monthdaycnt) per_socket_ratio
//         |from
//         |(
//         |select
//         |    monthtag,city,monthdaycnt,sum(device_cnt) device_cnt,sum(device_socket_cnt) device_socket_cnt,sum(online_device_cnt) online_device_cnt,sum(online_socket_cnt) online_socket_cnt,
//         |    sum(effective_order_cnt) effective_order_cnt,sum(ele_cnt) ele_cnt,sum(amount) amount,sum(amount) /  sum(effective_order_cnt) per_price,sum(ele_cnt) / sum(effective_order_cnt) as per_ele_cnt
//         |from
//         |(
//         |select
//         |    substring(inc_day,0,6) as monthtag,*,datediff(last_day(from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")),from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")) +1 as monthdaycnt
//         |from
//         |    dm_gis_oms.summary_display_waterbills
//         |where
//         |    inc_day>= '${inc_day_year}' and inc_day <='${inc_day}'
//         |and type = 'city'
//         |) a
//         |group by
//         |    monthtag,city,monthdaycnt
//         |) aa
//         |
//         |union all
//         | -- 月度全国
//         |select
//         |    monthtag,'country',device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,effective_order_cnt,ele_cnt,amount,per_price,per_ele_cnt,
//         |effective_order_cnt / (online_socket_cnt *monthdaycnt) per_socket_ratio
//         |from
//         |(
//         |select
//         |    monthtag,monthdaycnt,sum(device_cnt) device_cnt,sum(device_socket_cnt) device_socket_cnt,sum(online_device_cnt) online_device_cnt,sum(online_socket_cnt) online_socket_cnt,
//         |    sum(effective_order_cnt) effective_order_cnt,sum(ele_cnt) ele_cnt,sum(amount) amount,sum(amount) /  sum(effective_order_cnt) per_price,sum(ele_cnt) / sum(effective_order_cnt) as per_ele_cnt
//         |from
//         |(
//         |select
//         |    substring(inc_day,0,6) as monthtag,*,datediff(last_day(from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")),from_unixtime(unix_timestamp(concat(substring(inc_day,0,6),'01'),'yyyyMMdd'),"yyyy-MM-dd")) +1 as monthdaycnt
//         |from
//         |    dm_gis_oms.summary_display_waterbills
//         |where
//         |    inc_day>= '${inc_day_year}' and inc_day <='${inc_day}'
//         |and type = 'city'
//         |) a
//         |group by
//         |    monthtag,monthdaycnt
//         |) aa
//         |union all
//         |
//         | -- 周级城市
//         |select
//         |   weektag,city,sum(device_cnt) device_cnt,sum(device_socket_cnt) device_socket_cnt,sum(online_device_cnt) online_device_cnt,sum(online_socket_cnt) online_socket_cnt,
//         |    sum(effective_order_cnt) effective_order_cnt,sum(ele_cnt) ele_cnt,sum(amount) amount,sum(amount) /  sum(effective_order_cnt) per_price,sum(ele_cnt) / sum(effective_order_cnt) per_ele_cnt,sum(effective_order_cnt) / (sum(online_socket_cnt) * 7) per_socket_ratio
//         |from
//         |(
//         |select
//         |    inc_day,city,
//         |    case when inc_day < '${inc_day}' and inc_day>= '${week1}' then concat('${week1}','-','${inc_day}')
//         |        when inc_day < '${week1}' and inc_day >= '${week2}' then concat('${week2}','-','${week1}')
//         |        when inc_day < '${week2}' and inc_day >= '${week3}' then concat('${week3}','-','${week2}')
//         |        when inc_day < '${week3}' and inc_day >= '${week4}' then concat('${week4}','-','${week3}')
//         |        else '-'
//         |    end as weektag,*
//         |from
//         |    dm_gis_oms.summary_display_waterbills
//         |where
//         |    inc_day>= '${week4}' and inc_day <='${week1}'
//         |and type = 'city'
//         |)
//         |group by
//         |    weektag,city
//         |
//         |union all
//         |
//         | -- 周级全国
//         |select
//         |   weektag,'country',sum(device_cnt) device_cnt,sum(device_socket_cnt) device_socket_cnt,sum(online_device_cnt) online_device_cnt,sum(online_socket_cnt) online_socket_cnt,
//         |    sum(effective_order_cnt) effective_order_cnt,sum(ele_cnt) ele_cnt,sum(amount) amount,sum(amount) /  sum(effective_order_cnt) per_price,sum(ele_cnt) / sum(effective_order_cnt) per_ele_cnt,sum(effective_order_cnt) / (sum(online_socket_cnt) * 7) per_socket_ratio
//         |from
//         |(
//         |select
//         |    inc_day,
//         |    case when inc_day < '${inc_day}' and inc_day>= '${week1}' then concat('${week1}','-','${inc_day}')
//         |        when inc_day < '${week1}' and inc_day >= '${week2}' then concat('${week2}','-','${week1}')
//         |        when inc_day < '${week2}' and inc_day >= '${week3}' then concat('${week3}','-','${week2}')
//         |        when inc_day < '${week3}' and inc_day >= '${week4}' then concat('${week4}','-','${week3}')
//         |        else '-'
//         |    end as weektag,*
//         |from
//         |    dm_gis_oms.summary_display_waterbills
//         |where
//         |    inc_day>= '${week4}' and inc_day <='${week1}'
//         |and type = 'city'
//         |)
//         |group by
//         |    weektag
//         |
//         |union all
//         |
//         | -- 7day城市
//         |
//         |select
//         |    inc_day,city,sum(device_cnt) device_cnt,sum(device_socket_cnt) device_socket_cnt,sum(online_device_cnt) online_device_cnt,sum(online_socket_cnt) online_socket_cnt,
//         |    sum(effective_order_cnt) effective_order_cnt,sum(ele_cnt) ele_cnt,sum(amount) amount,sum(amount) /  sum(effective_order_cnt) per_price,sum(ele_cnt) / sum(effective_order_cnt) per_ele_cnt,sum(effective_order_cnt) / sum(online_socket_cnt) per_socket_ratio
//         |from
//         |    dm_gis_oms.summary_display_waterbills
//         |where
//         |    inc_day>= '${week1}' and inc_day <='${inc_day}'
//         |and type = 'city'
//         |group by
//         |    inc_day,city
//         |union all
//         |
//         | -- 7day全国
//         |
//         |select
//         |    inc_day,'country',sum(device_cnt) device_cnt,sum(device_socket_cnt) device_socket_cnt,sum(online_device_cnt) online_device_cnt,sum(online_socket_cnt) online_socket_cnt,
//         |    sum(effective_order_cnt) effective_order_cnt,sum(ele_cnt) ele_cnt,sum(amount) amount,sum(amount) /  sum(effective_order_cnt) per_price,sum(ele_cnt) / sum(effective_order_cnt) per_ele_cnt,sum(effective_order_cnt) / sum(online_socket_cnt) per_socket_ratio
//         |from
//         |    dm_gis_oms.summary_display_waterbills
//         |where
//         |    inc_day>= '${week1}' and inc_day <='${inc_day}'
//         |and type = 'city'
//         |group by
//         |    inc_day
//       """.stripMargin


      logger.error("邮件sql为：" + sourceSql)
      val mailDf = spark.sql(sourceSql).persist(StorageLevel.MEMORY_AND_DISK)
      logger.error("mailDf的数据量为："+ mailDf.count())
      mailDf.take(2).foreach(println(_))
      mailDf.withColumn("inc_day",lit(inc_day)).repartition(5).write.mode(SaveMode.Overwrite).insertInto(mailTable)

      mailDf.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/mail.csv")
//      val ftp = FtpUtil.connectFtp("10.116.49.190",21,"gis", "L1iwM21xYF")
//      FtpUtil.delete(ftp,"/01401062/mail.csv")
//      ShellExcutor.exeCmd(s"hdfs dfs -getmerge /user/01401062/upload/gis/data/eta/mail.csv ./mail.csv")
//      ShellExcutor.exeCmd(s"cat ./mail.csv | head -n 10")
//
//      ShellExcutor.exeCmd(String.format(s"curl -u gis:L1iwM21xYF -T ./mail.csv ftp://10.116.49.190/01401062/mail.csv"))
//      ShellExcutor.exeCmd(String.format(s"rm -f ./mail.csv"))

  }

  def saveToLocalCkProcess(spark: SparkSession, incDay: String): Unit = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis_oms.summary_display_waterbills
         |where
         |  inc_day = '${incDay}'
         |and (type is not null or type != '' )
         |and (province is not null or province != '' )
         |and (city is not null or city != '' )
         |and (region is not null or region != '' )
         |and (street is not null or street != '' )
         |and (community is not null or community != '' )
         |and (station is not null or station != '' )
         |and (device is not null or device != '' )
       """.stripMargin

    val sourceSql2 =
      s"""
         |select
         |  *
         |from
         |  dm_gis_oms.charging_pile_device_ownership_waterbills
         |where
         |  inc_day = '${incDay}'
         |and (city_name is not null or city_name != '' )
         |and (region_name is not null or region_name != '' )
         |and (street is not null or street != '' )
         |and (community is not null or community != '' )
         |and (village is not null or village != '' )
         |and (device_no is not null or device_no != '' )
         |and (d_status is not null or d_status != '' )
         |and (station_name is not null or station_name != '' )
       """.stripMargin


    val sourceSql3 =
      s"""
         |select
         |  *
         |from
         |  dm_gis_oms.charging_pile_waterbills
         |where
         |  inc_day = '${incDay}'
       """.stripMargin


//    val address = "jdbc:clickhouse://10.216.162.10:8123/smart_community"
//    val user = "default"
//    val password = "123456"
//
//
//    val md5Fuction = udf(calMd5 _)
    val md5FuctionSeq = udf(calMd5Seq _)
//    val md5Fuction3 = udf(calMd5c3 _)
//
//
//    val sourceDf1 = spark.sql(sourceSql)

//    val sourceDf3 = spark.sql(sourceSql3)
//
//    val sourceIdDf3 = sourceDf3.select(col("*"),md5FuctionSeq(array(col("charge_no"),col("coding_no"),col("inc_day"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    sourceIdDf3.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/20220327_test3.csv")
//
//    sourceIdDf3.printSchema()
//
//    val df3ToMysqlDf = sourceIdDf3.select(col("id") as "id",col("inc_day") as "statdate",col("charge_no") as "charge_no",col("coding_no") as "coding_no",
//      col("coding_no_cnt") as "coding_no_cnt",col("order_no_cnt") as "order_no_cnt",col("order_cnt_1") as "order_cnt_1",col("order_cnt_2") as "order_cnt_2",
//      col("ele_cnt") as "ele_cnt",col("charge_time_cnt") as "charge_time_cnt",col("amount") as "amount")
//
    //保存到mysql
//    SparkUtils.df2MysqlDf(spark,df3ToMysqlDf,descMysqlUserName,descMysqlPassWord,descMysqlUrl,chargingPileWaterBillsMysqlTable,incDay,logger)

//    val sourceDf2 = spark.sql(sourceSql2)
//    val md5FuctionSeq = udf(calMd5Seq _)

    //    val sourceIdDf2 = sourceDf2.select(col("*"),md5FuctionSeq(array(col("province_name"),col("city_name"),col("region_name")
//      ,col("street"),col("community"),col("village"),col("station_name"),col("device_no"),col("inc_day"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    sourceIdDf2.printSchema()
//
//    val df2ToMysqlDf = sourceIdDf2.select(
//      col("id") as "id",col("inc_day") as "statdate",col("province_name") as "province_name",col("city_name") as "city_name",
//      col("region_name") as "region_name",col("street") as "street",col("community") as "community",col("village") as "village",
//      col("station_name") as "station_name",col("device_no") as "device_no",col("d_status") as "d_status",col("total_order_cnt") as "total_order_cnt",
//      col("effective_order_cnt") as "effective_order_cnt",col("pay_order_cnt") as "pay_order_cnt",col("ele_cnt") as "ele_cnt",col("charge_time_cnt") as "charge_time_cnt",
//      col("amount") as "amount",col("socket_number") as "socket_number",col("total_status") as "total_status",col("price") as "price").persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    //保存到mysql
//    SparkUtils.df2MysqlDf(spark,df2ToMysqlDf,descMysqlUserName,descMysqlPassWord,descMysqlUrl,deviceOwnerShipWaterBillsMysqlTable,incDay,logger)
//


//    type,province,city,region,street,community,village,station,device,device_cnt,device_socket_cnt,online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,per_socket_ratio,per_price,per_ele_cnt,per_charge_time,price,cost,amount_ratio,inc_day,id

    val sourceDf1 = spark.sql(sourceSql)

//    val md5FuctionSeq = udf(calMd5Seq _)

    val sourceIdDf1 = sourceDf1.select(col("*"),md5FuctionSeq(array(col("type"),col("province"),col("city"),col("region"),col("street"),
      col("community"),col("village"),col("station"),col("device"),col("device_cnt"),col("inc_day"))) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)

    sourceIdDf1.printSchema()

//    type,province,city,region,street,community,village,station,device,device_cnt,device_socket_cnt,
    // online_device_cnt,online_socket_cnt,total_order_cnt,effective_order_cnt,pay_order_cnt,ele_cnt,charge_time_cnt,amount,per_socket_ratio,
    // per_price,per_ele_cnt,per_charge_time,price,cost,amount_ratio,inc_day,id

    val df1ToMysqlDf = sourceIdDf1.select(
      col("id") as "id",col("inc_day") as "statdate",col("type") as "type",col("province") as "province",col("city") as "city",
      col("region") as "region",col("street") as "street",col("community") as "community",col("village") as "village",
      col("station") as "station",col("device") as "device",col("device_cnt") as "device_cnt",col("device_socket_cnt") as "device_socket_cnt",
      col("online_device_cnt") as "online_device_cnt",col("online_socket_cnt") as "online_socket_cnt",col("total_order_cnt") as "total_order_cnt",
      col("effective_order_cnt") as "effective_order_cnt", col("pay_order_cnt") as "pay_order_cnt",col("ele_cnt") as "ele_cnt",col("charge_time_cnt") as "charge_time_cnt",
      col("amount") as "amount",col("per_socket_ratio") as "per_socket_ratio",col("per_price") as "per_price",col("per_ele_cnt") as "per_ele_cnt",
      col("per_charge_time") as "per_charge_time",col("price") as "price",col("cost") as "cost",col("amount_ratio") as "amount_ratio").persist(StorageLevel.MEMORY_AND_DISK_SER)


    //保存到mysql
    SparkUtils.df2MysqlDf(spark,df1ToMysqlDf,descMysqlUserName,descMysqlPassWord,descMysqlUrl,summaryDisplayWaterBillsMysqlTable,incDay,logger)


//    create table `charging_pile_summary_display_waterbills` (
//      `id` varchar(50) not null comment '主键（inc_day的md5值）',
//    `statdate` varchar(20) not null comment '统计日期（yyyymmdd)',
//    `type` varchar(20) not null comment '统计日期（yyyymmdd)',
//    `province` varchar(50) not null comment '省份',
//    `city` varchar(50) not null comment '城市',
//    `region` varchar(50) not null comment '区',
//    `street` varchar(50) not null comment '街道',
//    `community` varchar(50) not null comment '社区',
//    `village` varchar(50) not null comment '小区',
//    `station` varchar(50) not null comment '充电站',
//    `device` varchar(50) not null comment '充电桩',
//    `device_cnt` int(11) not null comment '设备总数',
//    `device_socket_cnt` double default null comment '设备总口数',
//    `online_device_cnt` int(11) not null comment '在线设备数',
//    `online_socket_cnt` double default null comment '在线口数',
//    `total_order_cnt` double default null comment '总订单数',
//    `effective_order_cnt` double default null comment '有效订单数',
//    `pay_order_cnt` double default null comment '支付订单数',
//    `ele_cnt` double default null comment '充电能耗(度)',
//    `charge_time_cnt` double default null comment '充电时长(时)',
//    `amount` double default null comment '支付金额(元)',
//    `per_socket_ratio` double default null comment '单口使用率',
//    `per_price` double default null comment '客单价(元)',
//    `per_ele_cnt` double default null comment '平均单耗电量',
//    `per_charge_time` double default null comment '平均单充电时长',
//    `price` double default null comment '电价(元/度)',
//    `cost` double default null comment '电费成本(元)',
//    `amount_ratio` double default null comment '收益率(%)',
//    `create_time` timestamp null default current_timestamp(),
//    `create_user` varchar(50) default null,
//    `modify_time` timestamp null default current_timestamp() on update current_timestamp(),
//    `modify_user` varchar(50) default null,
//    primary key (`id`),
//    key `province_name_statdate` (`statdate`,`province`,`type`,`city`,`region`,`street`,`community`,`village`,`station`) using btree
//    ) engine=innodb default charset=utf8 comment='设备归属信息流水表';


//    sourceIdDf1.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/20220327_test.csv")


//    val sourceIdDf2 = sourceDf2.select(col("*"),md5Fuction(lit("-"),col("province_name"),col("city_name"),col("region_name")
//      ,col("street"),col("community"),col("village"),col("station_name"),col("device_no"),col("inc_day")) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    sourceIdDf2.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/20220327_test2.csv")
//    sourceIdDf2.take(2).foreach(println(_))
//
//
//
//    val sourceIdDf3 = sourceDf3.select(col("*"),md5Fuction3(col("charge_no"),col("coding_no"),col("inc_day")) as "id").persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    sourceIdDf3.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/20220327_test3.csv")
//    sourceIdDf3.take(2).foreach(println(_))

//    saveToEmil(spark,sourceDf)

  }





    def start(spark: SparkSession,args: Array[String] ): Unit = {

      var incDay = ""
      var yesterday = ""

      if (args.length >1 ){
        incDay = args(0)

        val funcArr = args.drop(1)

        println(incDay)

        //反射调用任意统计方法
        funcArr.foreach(
          index => {
            val funcName = funcMap.get(index)
            println("\n\n\n"+s">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${funcName}开始<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
            this.getClass.getDeclaredMethod(funcName, classOf[SparkSession], classOf[String]).invoke(this, spark, incDay)
            println("\n"+s">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${funcName}结束<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+"\n\n\n")
          }
        )

        logger.error(">>>统计结束!<<<")
      } else {
        logger.error("参数长度异常")
        System.exit(1)
      }

  }

  def saveToMysqlBaseTable(spark: SparkSession, inc_day: String) = {


      val querySql =
        s"""
           |select
           |  province_name,city_name,region,street,community,village,station_name,device_no,count(1) num
           |from
           |  dm_gis_oms.scomm_charging_device
           |where
           |  (province_name is not null or province_name != '' )
           |and (city_name is not null or city_name != '' )
           |and (region is not null or region != '' )
           |and (street is not null or street != '' )
           |and (community is not null or community != '' )
           |and (village is not null or village != '' )
           |and (station_name is not null or station_name != '' )
           |and (device_no is not null or device_no != '' )
           |group by
           |  province_name,city_name,region,street,community,village,station_name,device_no
         """.stripMargin
     val md5FuctionSeq = udf(calMd5Seq _)

     val baseTableDf = spark.sql(querySql).select(md5FuctionSeq(array(col("province_name"),col("city_name"),col("region")
        ,col("street"),col("community"),col("village"),col("station_name"),col("device_no"))) as "id",
        col("province_name") as "province",col("city_name") as "city",col("region") as "region",
        col("street") as "street",col("community") as "community",col("village") as "village",
        col("station_name") as "station_name",col("device_no") as "device_no")

    //保存到mysql
    SparkUtils.df2MysqlNoPartitionDf(spark,baseTableDf,descMysqlUserName,descMysqlPassWord,descMysqlUrl,mysqlBaseTable,logger)

  }

  def main(args: Array[String]): Unit = {

      val inc_day = args(0)

      val spark = init(inc_day)

//      userMonitorStatistics(spark,inc_day)
//
      processChargingPileStatistics(spark,inc_day)
      processDeviceOwnerShipStatistics(spark,inc_day)
      processSummaryDisplayStatistics(spark,inc_day)
//
//      saveToEmil(spark,inc_day)


//        processDeviceOwnerShipStatistics(spark,inc_day)
//      saveToMysqlBaseTable(spark,inc_day)

//      saveToLocalCkProcess(spark,inc_day)

//      start(spark,args)

  }



}
