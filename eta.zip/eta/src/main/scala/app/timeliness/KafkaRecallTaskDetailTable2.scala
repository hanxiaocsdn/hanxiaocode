package app.timeliness

import Utils.SparkUtils.writeToHive
import app.timeliness.Functions.sortField
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

// 全部数据任务明细，表2逻辑
object KafkaRecallTaskDetailTable2 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def runKafkaRecallTaskDetail(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    // 从明细表获取数据
    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.kafka_recall_request_detail
         |where
         |  inc_day = '${dayBefore1}'
         |""".stripMargin
    println(querySql)
    val requestDetailDF = spark.sql(querySql)

    val taskDetailDF = requestDetailDF
      .filter('order === 0)
      .withColumn("group2_order", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm2"))) - 1)
      // 空值处理，方便分组收集后排序操作
      .withColumn("source",when('source.isNull,"null").otherwise('source))
      .withColumn("plan_arrived_tm_state",when('plan_arrived_tm_state.isNull,"null").otherwise('plan_arrived_tm_state))
      .withColumn("latest_arrived_tm_state",when('latest_arrived_tm_state.isNull,"null").otherwise('latest_arrived_tm_state))
      .withColumn("plan_run_tm_state",when('plan_run_tm_state.isNull,"null").otherwise('plan_run_tm_state))
      .withColumn("pick_up_tm",when('pick_up_tm.isNull,"null").otherwise('pick_up_tm))
      .withColumn("remain_time",when('remain_time.isNull,"null").otherwise('remain_time))
      .withColumn("remain_distance",when('remain_distance.isNull,"null").otherwise('remain_distance))
      .withColumn("diff_run_tm",when('diff_run_tm.isNull,"null").otherwise('diff_run_tm))
      .withColumn("diff_plan_tm",when('diff_plan_tm.isNull,"null").otherwise('diff_plan_tm))
      .withColumn("arrival_tm3",when('arrival_tm3.isNull,"null").otherwise('arrival_tm3))
      .withColumn("diff_latest_tm",when('diff_latest_tm.isNull,"null").otherwise('diff_latest_tm))
      .withColumn("solution",when('solution.isNull,"null").otherwise('solution))
      .withColumn("isselectedsaveplan",when('isselectedsaveplan.isNull,"null").otherwise('isselectedsaveplan))
      .withColumn("actual_dep_tm_data_source",when('actual_dep_tm_data_source.isNull,"null").otherwise('actual_dep_tm_data_source))
      .withColumn("start_end_state",when('start_end_state.isNull,"null").otherwise('start_end_state))
      .withColumn("rescue_avg_speed",when('rescue_avg_speed.isNull,"null").otherwise('rescue_avg_speed))
      .withColumn("averagespeed",when('averagespeed.isNull,"null").otherwise('averagespeed))
      .withColumn("linesource2",when('linesource2.isNull,"null").otherwise('linesource2))
      .withColumn("num", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm"))))
      .groupBy("group2")
      .agg(
        // 取分组内第一条数据
        max(when('group2_order === 0,'task_id).otherwise(null)) as "task_id",
        max(when('group2_order === 0,'sort_num).otherwise(null)) as "sort_num",
        max(when('group2_order === 0,'task_subid).otherwise(null)) as "task_subid",
        max(when('group2_order === 0,'start_dept).otherwise(null)) as "start_dept",
        max(when('group2_order === 0,'end_dept).otherwise(null)) as "end_dept",
        max(when('group2_order === 0,'line_code).otherwise(null)) as "line_code",
        max(when('group2_order === 0,'plan_depart_tm).otherwise(null)) as "plan_depart_tm",
        max(when('group2_order === 0,'plan_arrive_tm).otherwise(null)) as "plan_arrive_tm",
        max(when('group2_order === 0,'driver_id).otherwise(null)) as "driver_id",
        max(when('group2_order === 0,'driver_name).otherwise(null)) as "driver_name",
        max(when('group2_order === 0,'actual_run_time).otherwise(null)) as "actual_run_time",
        max(when('group2_order === 0,'transoport_level).otherwise(null)) as "transoport_level",
        max(when('group2_order === 0,'ac_is_run_ontime).otherwise(null)) as "ac_is_run_ontime",
        max(when('group2_order === 0,'if_plan_delay).otherwise(null)) as "if_plan_delay",
        max(when('group2_order === 0,'if_latest_null_delay).otherwise(null)) as "if_latest_null_delay",
        max(when('group2_order === 0,'if_latest_delay).otherwise(null)) as "if_latest_delay",
        max(when('group2_order === 0,'if_actual_delay_plan).otherwise(null)) as "if_actual_delay_plan",
        max(when('group2_order === 0,'origin_run_arrive_tm).otherwise(null)) as "origin_run_arrive_tm",
        max(when('group2_order === 0,'origin_plan_arrive_tm).otherwise(null)) as "origin_plan_arrive_tm",
        max(when('group2_order === 0,'origin_latest_arrive_tm).otherwise(null)) as "origin_latest_arrive_tm",
        max(when('group2_order === 0,'vehicle_serial).otherwise(null)) as "vehicle_serial",
        max(when('group2_order === 0,'actual_depart_tm).otherwise(null)) as "actual_depart_tm",
        max(when('group2_order === 0,'actual_arrive_tm).otherwise(null)) as "actual_arrive_tm",
        // 分组内存在true则取true
        max(when('plan_arrived_tm_state === "true",1).otherwise(0)) as "ifdelay_plan_arrived_tm_state",
        max(when('latest_arrived_tm_state === "true",1).otherwise(0)) as "ifdelay_latest_arrived_tm_state",
        max(when('plan_run_tm_state === "true",1).otherwise(0)) as "ifdelay_plan_run_tm_state",
        // 分组内的字段的全部值用|拼接
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('source)) as "source",
        concat_ws("|",collect_list('plan_arrived_tm_state)) as "plan_arrived_tm_state",
        concat_ws("|",collect_list('latest_arrived_tm_state)) as "latest_arrived_tm_state",
        concat_ws("|",collect_list('plan_run_tm_state)) as "plan_run_tm_state",
        concat_ws("|",collect_list('pick_up_tm))as "pick_up_tm",
        concat_ws("|",collect_list('remain_time)) as "remain_time",
        concat_ws("|",collect_list('remain_distance)) as "remain_distance",
        concat_ws("|",collect_list('diff_run_tm)) as "diff_run_tm",
        concat_ws("|",collect_list('diff_plan_tm)) as "diff_plan_tm",
        concat_ws("|",collect_list('arrival_tm3)) as "arrival_tm3",
        concat_ws("|",collect_list('diff_latest_tm)) as "diff_latest_tm",
        concat_ws("|",collect_list('solution)) as "solution",
        concat_ws("|",collect_list('isselectedsaveplan)) as "isselectedsaveplan",
        concat_ws("|",collect_list('actual_dep_tm_data_source)) as "actual_dep_tm_data_source",
        concat_ws("|",collect_list('start_end_state)) as "start_end_state",
        concat_ws("|",collect_list('rescue_avg_speed)) as "rescue_avg_speed",
        concat_ws("|",collect_list('averagespeed)) as "averagespeed",
        concat_ws("|",collect_list('linesource2)) as "linesource2",
        // 统计分组内满足条件的数据量
        count(when('source === "navi" and 'pick_up_tm =!= "null",'pick_up_tm).otherwise(null)) as "navi_count",
        count(when('source === "eta" and 'pick_up_tm =!= "null",'pick_up_tm).otherwise(null)) as "eta_count",
        count(when('pick_up_tm =!= "null",'pick_up_tm).otherwise(null)) as "total_count",
        count(when('linesource2.contains("标准线路_缓存"),1).otherwise(null)) as "std2_cache",
        count(when('linesource2.contains("标准线路_非缓存"),1).otherwise(null)) as "std2_not_cache",
        count(when('linesource2.contains("路径规划_缓存"),1).otherwise(null)) as "zh2_cache",
        count(when('linesource2.contains("路径规划_非缓存"),1).otherwise(null)) as "zh2_not_cache"
      )
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("source",sortField('num,'source))
      .withColumn("plan_arrived_tm_state",sortField('num,'plan_arrived_tm_state))
      .withColumn("latest_arrived_tm_state",sortField('num,'latest_arrived_tm_state))
      .withColumn("plan_run_tm_state",sortField('num,'plan_run_tm_state))
      .withColumn("pick_up_tm",sortField('num,'pick_up_tm))
      .withColumn("remain_time",sortField('num,'remain_time))
      .withColumn("remain_distance",sortField('num,'remain_distance))
      .withColumn("diff_run_tm",sortField('num,'diff_run_tm))
      .withColumn("diff_plan_tm",sortField('num,'diff_plan_tm))
      .withColumn("arrival_tm3",sortField('num,'arrival_tm3))
      .withColumn("diff_latest_tm",sortField('num,'diff_latest_tm))
      .withColumn("solution",sortField('num,'solution))
      .withColumn("isselectedsaveplan",sortField('num,'isselectedsaveplan))
      .withColumn("actual_dep_tm_data_source",sortField('num,'actual_dep_tm_data_source))
      .withColumn("start_end_state",sortField('num,'start_end_state))
      .withColumn("rescue_avg_speed",sortField('num,'rescue_avg_speed))
      .withColumn("averagespeed",sortField('num,'averagespeed))
      .withColumn("linesource2",sortField('num,'linesource2))
      // 新增字段逻辑
      .withColumn("ifdelay_plan_arrived_tm_state",when('ifdelay_plan_arrived_tm_state === 1,"true").otherwise("flase"))
      .withColumn("ifdelay_latest_arrived_tm_state",when('ifdelay_latest_arrived_tm_state === 1,"true").otherwise("flase"))
      .withColumn("ifdelay_plan_run_tm_state",when('ifdelay_plan_run_tm_state === 1,"true").otherwise("flase"))
      .withColumn("navi_count_ratio",'navi_count / 'total_count)
      .withColumn("eta_count_ratio",'eta_count / 'total_count)
      .withColumn("task_type_eta",when('std2_cache / 'total_count >= 0.7,"标准线路_缓存")
        .when('zh2_cache / 'total_count >= 0.7,"路径规划_缓存")
        .when(('std2_cache + 'zh2_cache) / 'total_count >= 0.7,"缓存")
        .when('std2_not_cache / 'total_count >= 0.7,"标准线路_非缓存")
        .when('zh2_not_cache / 'total_count >= 0.7,"路径规划_非缓存")
        .when(('std2_not_cache + 'zh2_not_cache) / 'total_count >= 0.7,"非缓存")
        .when('eta_count_ratio >= 0.7,"其他"))
      .withColumn("task_type",when('navi_count_ratio >= 0.7,"导航").when('eta_count_ratio >= 0.7,"eta").otherwise("其他"))
      .withColumn("accelarater_or_run",when('solution.contains("加速方案"),"加速").otherwise(""))
      .withColumn("inc_day",lit(dayBefore1))

    // 保存数据
    val res_cols = spark.sql("""select * from dm_gis.kafka_recall_task_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,taskDetailDF.select(res_cols: _*),Seq("inc_day"),"dm_gis.kafka_recall_task_detail")

  }

}