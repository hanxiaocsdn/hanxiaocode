package app.timeliness

import com.alibaba.fastjson.{JSON, JSONArray}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.udf
import java.text.SimpleDateFormat
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * 时效预警&挽救指标体系搭建需求相关函数
 */
object Functions {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  /**
   * 分组收集后的排序函数，保证分组收集的所有字段顺序一一对应
   * @return
   */
  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\|")
      val other_arr = other.split("\\|")
      val new_arr = num_arr.zip(other_arr).sortWith((x, y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })

  /**
   * 获取solution2等字段处理逻辑
   *
   * @return
   */
  def getStateAfterExcludingOutlier = udf((elimate_outlier2: String, accelarater_or_run: String, pick_up_tm: String, state: String, str1: String, str2: String) => {
    val state_arr = state.split("\\|")
    if (elimate_outlier2 != null && elimate_outlier2.trim != "" && accelarater_or_run != null && accelarater_or_run.trim != "") {
      val pick_up_tm_arr = pick_up_tm.split("\\|")
      val elimate_outlier_arr = elimate_outlier2.split("\\|")
      if (!elimate_outlier_arr.isEmpty && accelarater_or_run.equals(str2)) {
        for (i <- 0 until elimate_outlier_arr.length) {
          var elimate_outlier_i = 0L
          try {
            elimate_outlier_i = elimate_outlier_arr(i).toLong
          } catch {
            case e: Exception => null
          }
          for (j <- 0 until pick_up_tm_arr.length) {
            val pick_up_tm_i = pick_up_tm_arr(j)
            var pick_up_stamp = 0L
            try {
              pick_up_stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(pick_up_tm_i).getTime / 1000
            } catch {
              case e: Exception => null
            }
            if (pick_up_stamp.equals(elimate_outlier_i) && elimate_outlier_i != 0) {
              state_arr.update(j, str1)
            }
          }
        }
      }
    }
    state_arr.mkString("|")
  })

  /**
   * 利用路况速度和长度计算15min前后的每个swid的理论通行时长
   *
   * @return
   */
  def getSwidSpeed = udf((lukuang_length: String, lukuang_speed: String) => {

    val lukuang_length_arr = lukuang_length.split("\\|")
    val lukuang_speed_arr = lukuang_speed.split("\\|")

    val each_swid_speed_arr = new ArrayBuffer[Double]()
    for (i <- 0 until lukuang_length_arr.length) {
      var lukuang_length_i = 0.0
      var lukuang_speed_i = 0.0
      try {
        lukuang_length_i = lukuang_length_arr(i).toDouble
        lukuang_speed_i = lukuang_speed_arr(i).toDouble
      } catch {
        case e: Exception => null
      }
      val each_swid_speed = ((lukuang_length_i * 0.001) / lukuang_speed_i) * 60
      each_swid_speed_arr.append(each_swid_speed)
    }
    val each_swid_speed = each_swid_speed_arr.mkString("|")
    each_swid_speed
  })

  /**
   * 计算15min前后的swid通行总时长
   *
   * @return
   */
  def sumSwidSpeed = udf((each_swid_speed: String) => {
    val each_swid_speed_arr = each_swid_speed.split("\\|")
    var total_duration = 0.0
    for (i <- 0 until each_swid_speed_arr.length) {
      var each_swid_speed_i = 0.0
      try {
        each_swid_speed_i = each_swid_speed_arr(i).toDouble
      } catch {
        case e: Exception => null
      }
      if (!each_swid_speed_i.toString.equals("Infinity")) total_duration += each_swid_speed_i
    }
    total_duration
  })

  /**
   * 将分组收集到的数据，剔除null值
   *
   * @return
   */
  def deleteNull = udf((col: String) => {
    val arr = col.split("\\|")
    val res = new ArrayBuffer[String]()
    for (i <- 0 until arr.length) {
      val str = arr(i)
      if (!str.equals("null")) {
        res.append(str)
      }
    }
    res.mkString("|")
  })

  /**
   * 统计分组收集字段，包含某个值的个数
   *
   * @return
   */
  def countField = udf((col: String, match_str: String) => {
    var count = 0
    if (col != null && col.trim != "" && match_str != null && match_str.trim != "") {
      val arr = col.split("\\|")
      for (i <- 0 until arr.length) {
        val str = arr(i)
        if (str.equals(match_str)) {
          count += 1
        }
      }
    }
    count
  })

  /**
   * 统计分组收集字段，是否存在某个值，存在则为true，不存在则为false
   *
   * @return
   */
  def selectField = udf((col1: String, col2: String, match_str1: String, match_str2: String) => {
    var res = "false"
    if (col1 != null && col1.trim != "" && col2 != null && col2.trim != ""
      && match_str1 != null && col2.trim != "" && match_str2 != null && col2.trim != "") {
      val arr1 = col1.split("\\|")
      val arr2 = col2.split("\\|")
      for (i <- 0 until arr1.length) {
        val str1 = arr1(i)
        if (str1.equals(match_str1)) {
          if (arr2(i).equals(match_str2)) {
            res = "true"
          }
        }
      }
    }
    res
  })

  /**
   * 统计分组收集字段，查询col1包含match_str1，col2对应位置的值为match_str2的个数
   *
   * @return
   */
  def selectCountField = udf((col1: String, col2: String, match_str1: String, match_str2: String) => {
    var count = 0
    if (col1 != null && col1.trim != "" && col2 != null && col2.trim != ""
      && match_str1 != null && col2.trim != "" && match_str2 != null && col2.trim != "") {
      val arr1 = col1.split("\\|")
      val arr2 = col2.split("\\|")
      for (i <- 0 until arr1.length) {
        val str1 = arr1(i)
        if (str1.equals(match_str1)) {
          if (arr2(i).equals(match_str2)) {
            count += 1
          }
        }
      }
    }
    count
  })

  /**
   * 将字符串轨迹转换成接口需要的特殊格式
   *
   * @param str
   * @return
   */
  def stdCoordsToPoints2(str: String) = {

    var obj = new JSONArray()
    val arr = new ArrayBuffer[String]()
    try {
      obj = JSON.parseArray(str)
      for (i <- 0 until obj.size()) {
        val x = obj.getJSONObject(i).getString("x")
        val y = obj.getJSONObject(i).getString("y")
        val sss = s"""${x},${y}"""
        arr.append(sss)
      }
    } catch {
      case e: Exception => println(">>>轨迹转换异常" + e)
    }
    val points = arr.mkString("|")
    points
  }

  /**
   * 寻找pick_up_tm中的index，对应到diff_latest_tm的值
   *
   * @param current_point
   * @param pick_up_tm_jiasu
   * @param pick_up_tm
   * @param diff_latest_tm
   * @return
   */
  def getDiffLatestTime = udf((current_point: String, pick_up_tm_jiasu: String, pick_up_tm: String, diff_latest_tm: String, plan_arrived_tm_state: String) => {
    var res = ""
    var flag = true
    if (current_point != null && current_point.trim != "" && pick_up_tm_jiasu != null && pick_up_tm_jiasu.trim != "" && pick_up_tm != null && pick_up_tm.trim != ""
      && diff_latest_tm != null && diff_latest_tm.trim != "" && plan_arrived_tm_state != null && plan_arrived_tm_state.trim != "") {

      val current_point_arr = current_point.split("\\|")
      val pick_up_tm_jiasu_arr = pick_up_tm_jiasu.split("\\|")
      val pick_up_tm_arr = pick_up_tm.split("\\|")
      val diff_latest_tm_arr = diff_latest_tm.split("\\|")
      val plan_arrived_tm_state_arr = plan_arrived_tm_state.split("\\|")

      for (i <- 0 until current_point_arr.length) {
        val current_point_i = current_point_arr(i)
        if (current_point_i.equals("true")) {
          val pick_up_tm_jiasu_i = pick_up_tm_jiasu_arr(i)
          for (j <- 0 until pick_up_tm_arr.length) {
            val pick_up_tm_i = pick_up_tm_arr(j)
            val plan_arrived_tm_state_i = plan_arrived_tm_state_arr(j)
            if (pick_up_tm_i.equals(pick_up_tm_jiasu_i) && plan_arrived_tm_state_i.equals("true") && flag) {
              try {
                res = (diff_latest_tm_arr(j).toDouble * -1).toString
                flag = false
              } catch {
                case e: Exception => println(">>>diff_latest_tm时间转换异常" + e)
              }
            }
          }
        }
      }
    }
    res
  })

  /**
   * 表12 详情4逻辑
   *
   * @return
   */
  def getTimeDutyOb = udf((col1: String, col2: String, col3: String, col4: String, col5: String, col6: String, col7: String, col8: String) => {
    var service_ob_final = 0.0
    var tollstation_ob_final = 0.0
    var epidemic_ob_final = 0.0
    var jyz_total_stay_points_duration = 0.0
    var other_event_final = 0.0
    var no_label_ob_final = 0.0
    var start_ob_final = 0.0
    var end_ob_final = 0.0
    try {
      service_ob_final = col1.toDouble
      tollstation_ob_final = col2.toDouble
      epidemic_ob_final = col3.toDouble
      jyz_total_stay_points_duration = col4.toDouble
      other_event_final = col5.toDouble
      no_label_ob_final = col6.toDouble
      start_ob_final = col7.toDouble
      end_ob_final = col8.toDouble
    } catch {
      case e: Exception => println("数据类型转换异常：" + e.getMessage)
    }
    val time_duty_ob = new ArrayBuffer[String]()
    if (service_ob_final > 0) time_duty_ob.append("服务区拥堵")
    if (tollstation_ob_final > 0) time_duty_ob.append("收费站客观停留/低速")
    if (epidemic_ob_final > 0) time_duty_ob.append("疫情检查")
    if (jyz_total_stay_points_duration > 0) time_duty_ob.append("加油站客观停留/低速")
    if (other_event_final > 0) time_duty_ob.append("其他事件")
    if (no_label_ob_final > 0) time_duty_ob.append("路况拥堵")
    if (start_ob_final > 0) time_duty_ob.append("起点拥堵")
    if (end_ob_final > 0) time_duty_ob.append("终点拥堵")
    time_duty_ob.mkString("|")
  })

  /**
   * 计算两个日期的时间差，单位为天，保留指定位小数
   * date1: 时间字段1
   * date2: 时间字段2
   * dateFormat：时间格式
   * decimal：保留几位小数
   *
   * @return 时间差 单位为天，保留指定位小数
   */
  def getDateDiff = udf((date1: String, date2: String, dateFormat: String, decimal: Int) => {
    var date1_time: Double = 0.0
    var date2_time: Double = 0.0
    var datediff = ""
    try {
      date1_time = new SimpleDateFormat(dateFormat).parse(date1).getTime
      date2_time = new SimpleDateFormat(dateFormat).parse(date2).getTime
    } catch {
      case e: Exception => println("date1时间格式错误：" + e.getMessage)
    }
    if (!date1_time.equals(0.0) && !date2_time.equals(0.0)) {
      datediff = ((date1_time - date2_time) / (1000 * 60 * 60 * 24)).formatted(s"%.${decimal}f")
    }
    datediff
  })

}
