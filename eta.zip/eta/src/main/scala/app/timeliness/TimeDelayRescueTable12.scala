package app.timeliness

import Utils.SparkUtils.writeToHive
import app.timeliness.Functions.{countField, getDiffLatestTime, getTimeDutyOb, selectCountField, selectField, sortField}
import com.sf.gis.java.base.util.DateUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

// 时效晚点&时效挽救基表，表12和表13逻辑
object TimeDelayRescueTable12 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  /**
   * 获取表10数据
   * @param spark
   * @param dayBefore1
   * @param flag
   * @return
   */
  def getGuihuaXianluZhixing(spark: SparkSession, dayBefore1: String, flag: String) = {
    import spark.implicits._
    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  group2,
           |  pick_up_tm,
           |  if_conduct_replanline
           |from
           |  dm_gis.guihua_xianlu_zhixing
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("navi")){
      querySql =
        s"""
           |select
           |  group2,
           |  pick_up_tm,
           |  if_conduct_replanline
           |from
           |  dm_gis.guihua_xianlu_zhixing_navi
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }
    println(querySql)
    val df_xianlu_zhixing = spark.sql(querySql)

    val df_xianlu_zhixing_group = df_xianlu_zhixing
      // 空值处理，方便分组收集后排序操作
      .withColumn("pick_up_tm",when('pick_up_tm.isNull,"null").otherwise('pick_up_tm))
      .withColumn("if_conduct_replanline",when('if_conduct_replanline.isNull,"null").otherwise('if_conduct_replanline))
      .withColumn("num", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm"))))
      .groupBy("group2")
      .agg(
        // 分组内的字段的全部值用|拼接
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('pick_up_tm)) as "pick_up_tm_guihua",
        concat_ws("|",collect_list('if_conduct_replanline)) as "if_conduct_replanline"
      )
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("pick_up_tm_guihua",sortField('num,'pick_up_tm_guihua))
      .withColumn("if_conduct_replanline",sortField('num,'if_conduct_replanline))
      .select("group2","pick_up_tm_guihua","if_conduct_replanline")

    df_xianlu_zhixing_group
  }

  /**
   * 获取table2详情数据
   * @param spark
   * @param dayBefore1
   * @param flag
   * @return
   */
  def getKafkaRecallTaskDetail(spark: SparkSession, dayBefore1: String, flag: String) = {
    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  group2
           |  ,task_id
           |  ,task_subid
           |  ,source
           |  ,sort_num
           |  ,start_dept
           |  ,end_dept
           |  ,line_code
           |  ,plan_depart_tm
           |  ,plan_arrive_tm
           |  ,driver_id
           |  ,driver_name
           |  ,actual_run_time
           |  ,transoport_level
           |  ,ac_is_run_ontime
           |  ,if_actual_delay_plan
           |  ,if_plan_delay
           |  ,if_latest_null_delay
           |  ,if_latest_delay
           |  ,plan_arrived_tm_state
           |  ,latest_arrived_tm_state
           |  ,plan_run_tm_state
           |  ,pick_up_tm
           |  ,solution
           |  ,isselectedsaveplan
           |  ,vehicle_serial
           |  ,actual_depart_tm
           |  ,actual_arrive_tm
           |  ,ifdelay_plan_arrived_tm_state
           |  ,ifdelay_latest_arrived_tm_state
           |  ,ifdelay_plan_run_tm_state
           |  ,task_type
           |  ,accelarater_or_run
           |  ,diff_latest_tm
           |  ,diff_plan_tm
           |from
           |  dm_gis.kafka_recall_task_detail
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("navi")){
      querySql =
        s"""
           |select
           |  group2
           |  ,task_id
           |  ,task_subid
           |  ,source
           |  ,sort_num
           |  ,start_dept
           |  ,end_dept
           |  ,line_code
           |  ,plan_depart_tm
           |  ,plan_arrive_tm
           |  ,driver_id
           |  ,driver_name
           |  ,actual_run_time
           |  ,transoport_level
           |  ,ac_is_run_ontime
           |  ,if_actual_delay_plan
           |  ,if_plan_delay
           |  ,if_latest_null_delay
           |  ,if_latest_delay
           |  ,plan_arrived_tm_state
           |  ,latest_arrived_tm_state
           |  ,plan_run_tm_state
           |  ,pick_up_tm
           |  ,solution
           |  ,isselectedsaveplan
           |  ,vehicle_serial
           |  ,actual_depart_tm
           |  ,actual_arrive_tm
           |  ,ifdelay_plan_arrived_tm_state
           |  ,ifdelay_latest_arrived_tm_state
           |  ,ifdelay_plan_run_tm_state
           |  ,task_type
           |  ,accelarater_or_run
           |  ,diff_latest_tm
           |  ,diff_plan_tm
           |from
           |  dm_gis.kafka_recall_task_detail_navi
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }
    println(querySql)
    val df_task_detail = spark.sql(querySql)
    df_task_detail
  }

  /**
   * 获取表8数据
   * @param spark
   * @param dayBefore1
   * @param flag
   * @return
   */
  def getJiasuTask(spark: SparkSession, dayBefore1: String, flag: String) = {
    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  group2,
           |  solution2,
           |  plan_arrived_tm_state2,
           |  latest_arrived_tm_state2,
           |  plan_run_tm_state2,
           |  accelarater_or_run2,
           |  pick_up_tm_jiasu,
           |  pickup_tm_ycz_jiasu,
           |  if_accelerate,
           |  num_accelerate_remind,
           |  if_accelerate_conduct,
           |  num_accelerate_conduct,
           |  current_point_if_conduct_accelerate
           |from
           |  dm_gis.jiasu_task
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("navi")){
      querySql =
        s"""
           |select
           |  group2,
           |  solution2,
           |  plan_arrived_tm_state2,
           |  latest_arrived_tm_state2,
           |  plan_run_tm_state2,
           |  accelarater_or_run2,
           |  pick_up_tm_jiasu,
           |  pickup_tm_ycz_jiasu,
           |  if_accelerate,
           |  num_accelerate_remind,
           |  if_accelerate_conduct,
           |  num_accelerate_conduct,
           |  current_point_if_conduct_accelerate
           |from
           |  dm_gis.jiasu_task_navi
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }
    println(querySql)
    val df_jiasu_task = spark.sql(querySql)
    df_jiasu_task
  }

  /**
   * 获取详情4表数据
   * @param spark
   * @param dayBefore1
   * @param dayBefore2
   * @return
   */
  def getXiangQing4Data(spark: SparkSession, dayBefore1: String, dayBefore2: String) = {
    import spark.implicits._
    val xiangqing4_querySql =
      s"""
         |select
         |  task_subid,
         |  total_keguan,
         |  service_ob_final,
         |  tollstation_ob_final,
         |  epidemic_ob_final,
         |  jyz_total_stay_points_duration,
         |  other_event_final,
         |  no_label_ob_final,
         |  start_ob_final,
         |  end_ob_final
         |from
         |  dm_gis.eta_task_time_information
         |where
         |  inc_day >= '$dayBefore2'
         |  and inc_day <= '$dayBefore1'
         |  and total_keguan > 0
         |""".stripMargin
    println(xiangqing4_querySql)
    val df_xiangqing4 = spark.sql(xiangqing4_querySql)

    val df_time_duty_ob = df_xiangqing4
      .withColumn("time_duty_ob", getTimeDutyOb('service_ob_final, 'tollstation_ob_final, 'epidemic_ob_final, 'jyz_total_stay_points_duration, 'other_event_final, 'no_label_ob_final, 'start_ob_final, 'end_ob_final))
      .withColumn("time_duty_ob_tm", 'total_keguan)
      .select("task_subid", "time_duty_ob", "time_duty_ob_tm")

    df_time_duty_ob
  }

  /**
   * 获取详情5数据
   * @param spark
   * @param incDay
   * @param dayBefore2
   * @param dayBefore3
   * @param dayAfter2
   * @return
   */
  def getXiangQing5Data(spark: SparkSession, incDay: String, dayBefore2: String, dayBefore3: String, dayAfter2: String) = {
    import spark.implicits._
    val xiangqing5_querySql =
      s"""
         |select
         |  a.task_id as task_id,
         |  b.should_load_bnum as should_load_bnum,
         |  b.actual_load_bnum as actual_load_bnum
         |from
         |  (
         |    (
         |      select
         |        task_id,
         |        line_require_id
         |      from
         |        dm_gis.eta_std_line_recall
         |      where
         |        inc_day >= '$dayBefore2'
         |        and inc_day <= '$incDay'
         |    ) a
         |    left join (
         |      select
         |        line_require_id,
         |        should_load_bnum,
         |        actual_load_bnum
         |      from
         |        dm_ops.pass_forecast_road_convy_monitor_dtl
         |      where
         |        inc_day >= '$dayBefore3'
         |        and inc_day <= '$dayAfter2'
         |    ) b on a.line_require_id = b.line_require_id
         |  )
         |""".stripMargin
    println(xiangqing5_querySql)
    val df_xiangqing5 = spark.sql(xiangqing5_querySql)
      .withColumn("rn",row_number().over(Window.partitionBy("task_id").orderBy(desc("should_load_bnum"))))
      .filter('rn === 1)
      .drop("rn")

    df_xiangqing5
  }

  /**
   * 获取表4的数据，取得code_statue2
   * @param spark
   * @param dayBefore1
   * @param flag
   * @return
   */
  def getCodeStatue2Data(spark: SparkSession, dayBefore1: String, flag: String) = {
    import spark.implicits._
    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  group2,
           |  code_statue2
           |from
           |  dm_gis.jiupian_fwq
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("navi")){
      querySql =
        s"""
           |select
           |  group2,
           |  code_statue2
           |from
           |  dm_gis.jiupian_fwq_navi
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }
    println(querySql)

    val df_code_statue2 = spark.sql(querySql)
      .withColumn("rn",row_number().over(Window.partitionBy("group2").orderBy(desc("code_statue2"))))
      .filter('rn === 1)
      .drop("rn")

    df_code_statue2
  }

  def runTimeDelayRescue(spark: SparkSession, incDay: String,flag: String) = {

    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val dayAfter2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", -2)

    import spark.implicits._
    // 生产环境取数
    val df_task_detail = getKafkaRecallTaskDetail(spark,dayBefore1,flag)
    val df_jiasu_task = getJiasuTask(spark,dayBefore1,flag)
    val df_xianlu_zhixing_group = getGuihuaXianluZhixing(spark,dayBefore1,flag)
    val df_time_duty_ob = getXiangQing4Data(spark,dayBefore1,dayBefore2)
    val df_xiangqing5 = getXiangQing5Data(spark,incDay,dayBefore2,dayBefore3,dayAfter2)
    val df_code_statue2 = getCodeStatue2Data(spark,dayBefore1,flag)

    val df_time_delay_rescue = df_task_detail
      .join(df_jiasu_task,Seq("group2"),"left")
      .join(df_xianlu_zhixing_group,Seq("group2"),"left")
      .withColumn("solution2",when('solution2.isNull,'solution).otherwise('solution2))
      .withColumn("plan_arrived_tm_state2",when('plan_arrived_tm_state2.isNull,'plan_arrived_tm_state).otherwise('plan_arrived_tm_state2))
      .withColumn("latest_arrived_tm_state2",when('latest_arrived_tm_state2.isNull,'latest_arrived_tm_state).otherwise('latest_arrived_tm_state2))
      .withColumn("plan_run_tm_state2",when('plan_run_tm_state2.isNull,'plan_run_tm_state).otherwise('plan_run_tm_state2))
      .withColumn("accelarater_or_run2",when('accelarater_or_run2.isNull,'accelarater_or_run).otherwise('accelarater_or_run2))
      .withColumn("ifdelay_plan_arrived_tm_state2",when('plan_arrived_tm_state2.contains("true"),"true").otherwise("false"))
      .withColumn("ifdelay_latest_arrived_tm_state2",when('latest_arrived_tm_state2.contains("true"),"true").otherwise("false"))
      .withColumn("ifdelay_plan_run_tm_state2",when('plan_run_tm_state2.contains("true"),"true").otherwise("false"))
      .withColumn("if_replanline",when('solution.contains("重新规划线路"),"true").otherwise("false"))
      .withColumn("num_replanline",when('if_replanline === "true",countField('solution,lit("重新规划线路"))).otherwise(""))
      .withColumn("if_replanline_select",when('if_replanline === "true",selectField('solution,'isselectedsaveplan,lit("重新规划线路"),lit("1"))).otherwise(""))
      .withColumn("num_if_replanline_select",when('if_replanline === "true",selectCountField('solution,'isselectedsaveplan,lit("重新规划线路"),lit("1"))).otherwise(0))
      .withColumn("if_replanline_conduct",when('if_replanline === "true",when('if_conduct_replanline.contains("true"),"true").otherwise("false")).otherwise(""))
      .withColumn("num_if_replanline_conduct",when('if_replanline === "true",countField('if_conduct_replanline,lit("true"))).otherwise(""))
      .withColumn("if_rescue_plan",when('if_accelerate === "true" and 'if_replanline === "true","加速方案&重新规划线路方案")
        .when('if_accelerate === "true","加速方案")
        .when('if_replanline === "true","重新规划线路方案")
        .otherwise("没有挽救方案"))
      .withColumn("if_select",when('if_rescue_plan === "加速方案&重新规划线路方案" or 'if_rescue_plan === "加速方案","true")
        .when('if_rescue_plan === "重新规划线路方案",'if_replanline_select)
        .otherwise(""))
      .withColumn("if_accelerate_outlier",when('accelarater_or_run === "加速" and 'solution.contains("加速方案"),"true")
        .otherwise("false"))
      .withColumn("num_accelerate_remind_outlier",when('accelarater_or_run.isNull,"")
        .when('accelarater_or_run === "加速",countField('solution,lit("加速方案")))
        .otherwise(""))
      .withColumn("if_rescue_plan_outlier",when('if_accelerate_outlier === "true" and 'if_replanline === "true","加速方案&重新规划线路方案")
        .when('if_accelerate_outlier === "true","加速方案")
        .when('if_replanline === "true","重新规划线路方案")
        .otherwise("没有挽救方案"))
      .withColumn("if_conduct",when('if_rescue_plan_outlier === "加速方案",'if_accelerate_conduct)
        .when('if_rescue_plan_outlier === "加速方案&重新规划线路方案",when('if_accelerate_conduct === "true" or 'if_replanline_conduct === "true","true").otherwise("false"))
        .when('if_rescue_plan_outlier === "重新规划线路方案",'if_replanline_conduct)
        .otherwise(""))
      .withColumn("if_select_outlier",when('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案","true")
        .when('if_rescue_plan_outlier === "重新规划线路方案",'if_replanline_select)
        .otherwise(""))
      .join(df_time_duty_ob,Seq("task_subid"),"left")
      .withColumn("time_duty_if_ob",when('time_duty_ob.isNull,"否").otherwise("是"))
      .join(df_xiangqing5,Seq("task_id"),"left")
      .join(df_code_statue2,Seq("group2"),"left")
      .withColumn("accelarate_conduct_forecast_delay_time_plan",when('if_accelerate_conduct === "true",getDiffLatestTime('current_point_if_conduct_accelerate,'pick_up_tm_jiasu,'pick_up_tm,'diff_plan_tm,'plan_arrived_tm_state))
        .when('if_replanline_conduct === "true",getDiffLatestTime('if_conduct_replanline,'pick_up_tm_guihua,'pick_up_tm,'diff_plan_tm,'plan_arrived_tm_state))
        .otherwise(""))
      .withColumn("accelarate_conduct_forecast_delay_time_latest",when('if_accelerate_conduct === "true",getDiffLatestTime('current_point_if_conduct_accelerate,'pick_up_tm_jiasu,'pick_up_tm,'diff_latest_tm,'latest_arrived_tm_state))
        .when('if_replanline_conduct === "true",getDiffLatestTime('if_conduct_replanline,'pick_up_tm_guihua,'pick_up_tm,'diff_latest_tm,'latest_arrived_tm_state))
        .otherwise(""))
      .withColumn("ratio_obtm_forecast_delay_plan",when('accelarate_conduct_forecast_delay_time_plan.isNotNull and 'accelarate_conduct_forecast_delay_time_plan =!= "",'time_duty_ob_tm / 'accelarate_conduct_forecast_delay_time_plan)
        .otherwise(""))
      .withColumn("ratio_obtm_forecast_delay_latest",when('accelarate_conduct_forecast_delay_time_latest.isNotNull and 'accelarate_conduct_forecast_delay_time_latest =!= "",'time_duty_ob_tm / 'accelarate_conduct_forecast_delay_time_latest)
      .otherwise(""))
      .withColumn("inc_day",lit(dayBefore1))

    // 保存数据
    if(flag.equals("eta")){
      val res_cols = spark.sql("""select * from dm_gis.time_delay_rescue limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_time_delay_rescue.select(res_cols: _*),Seq("inc_day"),"dm_gis.time_delay_rescue")
    }else if(flag.equals("navi")){
      val res_cols = spark.sql("""select * from dm_gis.time_delay_rescue_navi limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_time_delay_rescue.select(res_cols: _*),Seq("inc_day"),"dm_gis.time_delay_rescue_navi")
    }

  }
}
