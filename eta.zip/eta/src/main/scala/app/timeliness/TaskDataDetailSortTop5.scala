package app.timeliness

import Utils.SparkUtils.writeToHive
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

/**
 * 时效预警&挽救指标体系搭建——任务维度统计指标
 * 需求方：左佳怡（01403789）
 * @author 徐游飞（01417347）
 * 任务ID：630844
 * 任务名称：时效挽救_任务维度数据明细排序表
 */
object TaskDataDetailSortTop5 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(className)

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val end_day = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val start_day = DateUtil.getMouthBefore(end_day, 1)

    //日期检查
    logger.error("start_day=" + start_day)
    logger.error("end_day=" + end_day)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    runTaskDataDetailSortTop5(spark, start_day, end_day)

  }

  def runTaskDataDetailSortTop5(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    // 从表16取数
    val querySql =
      s"""
         |select
         |  *,
         |  inc_day as task_inc_day,
         |  substr('$start_day',0,6) as month,
         |  abs(cast(ratio_obtm_forecast_delay_latest as double)) as ration_latest_abs
         |from
         |  dm_gis.task_data_detail
         |where
         |  inc_day >= '$start_day'
         |  and inc_day < '$end_day'
         |  and transoport_level in ('1','2')
         |  and if_latest_null_delay = '否'
         |  and if_latest_delay = '准点'
         |  and ifdelay_latest_arrived_tm_state = '是'
         |  and if_rescue_plan_outlier <> '没有挽救方案'
         |  and if_conduct = '是'
         |  and time_duty_ob_tm <> ''
         |  and time_duty_ob_tm is not null
         |  and ratio_obtm_forecast_delay_latest <> ''
         |  and ratio_obtm_forecast_delay_latest is not null
         |  and abs(cast(ratio_obtm_forecast_delay_latest as double)) > 0.7
         |  and biz_type in ('0','1','3','16','17')
         |  and require_category in ('0','1','2','18')
         |  and piece_type in ('小件','大件')
         |  and carrier_type in ('个体或企业')
         |""".stripMargin
    println(querySql)

    val df_task_data_detail = spark.sql(querySql)

    val df_sort_top5 = df_task_data_detail
      .withColumn("rank", row_number().over(Window.partitionBy('month).orderBy(desc("ration_latest_abs"))))
      .filter('rank <= 500)
      .withColumn("inc_day",lit(end_day))

    val res_cols = spark.sql("""select * from dm_gis.task_data_detail_sort_top5 limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_sort_top5.select(res_cols: _*),Seq("inc_day"),"dm_gis.task_data_detail_sort_top5")

  }
}