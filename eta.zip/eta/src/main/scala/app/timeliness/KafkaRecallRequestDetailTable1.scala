package app.timeliness

import Utils.SparkUtils.writeToHive
import Utils.StringUtils.timeToCustomTime
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.LongType

// 时效晚点&时效挽救请求明细表，表1逻辑
object KafkaRecallRequestDetailTable1 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  /**
   *  获取数据源
   * @param spark
   * @param dayBefore1
   * @param dayBefore3
   */
  def getRecallAanKafkaSource(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {

    val dayBefore1_2 = timeToCustomTime(dayBefore1,"yyyyMMdd","yyyy-MM-dd")
    val querySql =
      s"""
         |select
         |  task_area_code,
         |  task_id,
         |  sort_num,
         |  task_subid,
         |  start_dept,
         |  end_dept,
         |  start_type,
         |  end_type,
         |  line_code,
         |  vehicle_serial,
         |  actual_capacity_load,
         |  plan_depart_tm,
         |  actual_depart_tm,
         |  actual_depart_date,
         |  plan_arrive_tm,
         |  actual_arrive_tm,
         |  actual_arrive_date,
         |  driver_id,
         |  driver_name,
         |  line_time,
         |  line_distance,
         |  actual_run_time,
         |  start_longitude,
         |  start_latitude,
         |  end_longitude,
         |  end_latitude,
         |  is_stop,
         |  transoport_level,
         |  carrier_type,
         |  plf_flag,
         |  vehicle_type,
         |  axls_number,
         |  log_dist,
         |  x1,
         |  y1,
         |  x2,
         |  y2,
         |  end_point,
         |  duration,
         |  time,
         |  rt_dist,
         |  is_run_ontime,
         |  ac_is_run_ontime,
         |  if_evaluate_time,
         |  biz_type,
         |  require_category,
         |  to_ground,
         |  inc_day,
         |  arrival_tm,
         |  dest_zone_code,
         |  dest_zone_coordinate,
         |  latest_arrived_time,
         |  latest_arrived_tm_state,
         |  line_require_id,
         |  pick_up_lat,
         |  pick_up_lng,
         |  pick_up_tm,
         |  plan_arrived_tm_state,
         |  predict_tm,
         |  remain_distance,
         |  remain_time,
         |  send_tm,
         |  source,
         |  src_zone_code,
         |  src_zone_coordinate,
         |  start_end_state,
         |  status,
         |  task_save_state,
         |  type,
         |  compensateTime,
         |  lineCode,
         |  actualDepartTm,
         |  abnormalLabel,
         |  averageSpeed,
         |  planDelayTime,
         |  rtDelayTime,
         |  planRunTmState,
         |  tag,
         |  replanArriveTime,
         |  replanDistance,
         |  yawCause,
         |  solution,
         |  isSelectedSavePlan,
         |  actualDepTmDataSource as actual_dep_tm_data_source,
         |	rescueAvgSpeed as rescue_avg_speed,
         |  uid,
         |  reqId,
         |  lineType,
         |  lineSource
         |from
         |  (
         |    select
         |      task_area_code,
         |      b.task_id as task_id,
         |      sort_num,
         |      task_subid,
         |      start_dept,
         |      end_dept,
         |      start_type,
         |      end_type,
         |      line_code,
         |      b.vehicle_serial as vehicle_serial,
         |      actual_capacity_load,
         |      b.plan_depart_tm as plan_depart_tm,
         |      actual_depart_tm,
         |      actual_depart_date,
         |      b.plan_arrive_tm as plan_arrive_tm,
         |      actual_arrive_tm,
         |      actual_arrive_date,
         |      b.driver_id as driver_id,
         |      driver_name,
         |      line_time,
         |      line_distance,
         |      actual_run_time,
         |      start_longitude,
         |      start_latitude,
         |      end_longitude,
         |      end_latitude,
         |      is_stop,
         |      transoport_level,
         |      carrier_type,
         |      plf_flag,
         |      vehicle_type,
         |      axls_number,
         |      log_dist,
         |      x1,
         |      y1,
         |      x2,
         |      y2,
         |      end_point,
         |      duration,
         |      time,
         |      rt_dist,
         |      is_run_ontime,
         |      ac_is_run_ontime,
         |      if_evaluate_time,
         |      biz_type,
         |      require_category,
         |      to_ground,
         |      inc_day,
         |      arrival_tm,
         |      dest_zone_code,
         |      dest_zone_coordinate,
         |      latest_arrived_time,
         |      latest_arrived_tm_state,
         |      line_require_id,
         |      pick_up_lat,
         |      pick_up_lng,
         |      pick_up_tm,
         |      plan_arrived_tm_state,
         |      predict_tm,
         |      remain_distance,
         |      remain_time,
         |      send_tm,
         |      source,
         |      src_zone_code,
         |      src_zone_coordinate,
         |      start_end_state,
         |      status,
         |      task_save_state,
         |      type,
         |      compensateTime,
         |      lineCode,
         |      actualDepartTm,
         |      abnormalLabel,
         |      averageSpeed,
         |      planDelayTime,
         |      rtDelayTime,
         |      planRunTmState,
         |      tag,
         |      replanArriveTime,
         |      replanDistance,
         |      yawCause,
         |      solution,
         |      isSelectedSavePlan,
         |      actualDepTmDataSource,
         |	    rescueAvgSpeed,
         |      uid
         |    from
         |      (
         |        select
         |          task_area_code,
         |          task_id,
         |          sort_num,
         |          task_subid,
         |          start_dept,
         |          end_dept,
         |          start_type,
         |          end_type,
         |          line_code,
         |          vehicle_serial,
         |          actual_capacity_load,
         |          plan_depart_tm,
         |          actual_depart_tm,
         |          date_format(actual_depart_tm, 'yyyy-MM-dd') actual_depart_date,
         |          plan_arrive_tm,
         |          actual_arrive_tm,
         |          date_format(actual_arrive_tm, 'yyyy-MM-dd') actual_arrive_date,
         |          driver_id,
         |          driver_name,
         |          line_time,
         |          line_distance,
         |          actual_run_time,
         |          start_longitude,
         |          start_latitude,
         |          end_longitude,
         |          end_latitude,
         |          is_stop,
         |          transoport_level,
         |          carrier_type,
         |          plf_flag,
         |          vehicle_type,
         |          axls_number,
         |          log_dist,
         |          x1,
         |          y1,
         |          x2,
         |          y2,
         |          CONCAT(end_longitude, ',', end_latitude) end_point,
         |          duration,
         |          time,
         |          rt_dist,
         |          is_run_ontime,
         |          ac_is_run_ontime,
         |          if_evaluate_time,
         |          biz_type,
         |          require_category,
         |          to_ground,
         |          inc_day
         |        from
         |          dm_gis.eta_std_line_recall
         |        where
         |          date_format(actual_arrive_tm, 'yyyy-MM-dd') = '${dayBefore1_2}'
         |          and inc_day = '${dayBefore1}'
         |          and if_evaluate_time = '1'
         |          and require_category in ('0', '1', '2', '17', '18')
         |          and to_ground = '1'
         |      ) b
         |      left join (
         |        select
         |          get_json_object(info, '$$.arrivalTm') arrival_tm,
         |          get_json_object(info, '$$.destZoneCode') dest_zone_code,
         |          get_json_object(info, '$$.destZoneCoordinate') dest_zone_coordinate,
         |          get_json_object(info, '$$.driverId') driver_id,
         |          get_json_object(info, '$$.latestArrivedTime') latest_arrived_time,
         |          get_json_object(info, '$$.latestArrivedTmState') latest_arrived_tm_state,
         |          get_json_object(info, '$$.lineRequireId') line_require_id,
         |          get_json_object(info, '$$.pickUpLat') pick_up_lat,
         |          get_json_object(info, '$$.pickUpLng') pick_up_lng,
         |          get_json_object(info, '$$.pickUpTm') pick_up_tm,
         |          get_json_object(info, '$$.planArriveTm') plan_arrive_tm,
         |          get_json_object(info, '$$.planArrivedTmState') plan_arrived_tm_state,
         |          get_json_object(info, '$$.planDepartTm') plan_depart_tm,
         |          get_json_object(info, '$$.predictTm') predict_tm,
         |          get_json_object(info, '$$.remainDistance') remain_distance,
         |          get_json_object(info, '$$.remainTime') remain_time,
         |          get_json_object(info, '$$.sendTm') send_tm,
         |          get_json_object(info, '$$.source') `source`,
         |          get_json_object(info, '$$.srcZoneCode') src_zone_code,
         |          get_json_object(info, '$$.srcZoneCoordinate') src_zone_coordinate,
         |          get_json_object(info, '$$.startEndState') start_end_state,
         |          get_json_object(info, '$$.status') `status`,
         |          get_json_object(info, '$$.taskId') task_id,
         |          get_json_object(info, '$$.taskSaveState') task_save_state,
         |          get_json_object(info, '$$.type') `type`,
         |          get_json_object(info, '$$.vehicleSerial') vehicle_serial,
         |          get_json_object(info, '$$.compensateTime') compensateTime,
         |          get_json_object(info, '$$.lineCode') lineCode,
         |          get_json_object(info, '$$.actualDepartTm') actualDepartTm,
         |          get_json_object(info, '$$.abnormalLabel') abnormalLabel,
         |          get_json_object(info, '$$.averageSpeed') averageSpeed,
         |          get_json_object(info, '$$.planDelayTime') planDelayTime,
         |          get_json_object(info, '$$.rtDelayTime') rtDelayTime,
         |          get_json_object(info, '$$.planRunTmState') planRunTmState,
         |          get_json_object(info, '$$.tag') tag,
         |          get_json_object(info, '$$.replanArriveTime') replanArriveTime,
         |          get_json_object(info, '$$.replanDistance') replanDistance,
         |          get_json_object(info, '$$.yawCause') yawCause,
         |          get_json_object(info, '$$.solution') solution,
         |          get_json_object(info, '$$.isSelectedSavePlan') isSelectedSavePlan,
         |          get_json_object(info, '$$.uid') uid,
         |          get_json_object(info, '$$.actualDepTmDataSource') actualDepTmDataSource,
         |          get_json_object(info, '$$.rescueAvgSpeed') rescueAvgSpeed
         |        from
         |          dm_gis.eta_ts_wmp_info_to_hive
         |        where
         |          inc_day >= '${dayBefore3}'
         |          and inc_day <= '${dayBefore1}'
         |          and get_json_object(info, '$$.arrivalTm') != ''
         |          and get_json_object(info, '$$.arrivalTm') is not null
         |      ) a on a.task_id = b.task_id
         |      and a.src_zone_code = b.start_dept
         |      and a.dest_zone_code = b.end_dept
         |      and a.dest_zone_coordinate = b.end_point
         |  ) c
         |  left join (
         |    select
         |      get_json_object(log, '$$.reqId') reqId,
         |      get_json_object(
         |        get_json_object(get_json_object(log, '$$.data'), '$$.result'),
         |        '$$.lineType'
         |      ) lineType,
         |      get_json_object(
         |        get_json_object(get_json_object(log, '$$.data'), '$$.result'),
         |        '$$.lineSource'
         |      ) lineSource
         |    from
         |      dm_gis.gis_eta_query_log
         |    where
         |      inc_day >= '${dayBefore3}'
         |      and inc_day <= '${dayBefore1}'
         |      and get_json_object(log, '$$.subType') = 'queryLocationEta'
         |      and get_json_object(log, '$$.type') = 'etaQuery'
         |      and get_json_object(
         |        get_json_object(get_json_object(log, '$$.data'), '$$.arg'),
         |        '$$.taskId'
         |      ) != ''
         |  ) d on c.uid = d.reqId
         |where
         |  arrival_tm is not null
         |  and arrival_tm <> ''
         |""".stripMargin

    println(querySql)
    val recallAanKafkaDF = spark.sql(querySql)
    recallAanKafkaDF
  }

  /**
   * 1.时效晚点&时效挽救请求明细表（表1）
   * @param spark
   * @param dayBefore1
   * @param dayBefore3
   */
  def runKafkaRecallRequestDetail(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {

    // 获取数据源
    val recallAanKafkaDF = getRecallAanKafkaSource(spark, dayBefore1, dayBefore3)

    import spark.implicits._
    val kafka_recall_request_detail = recallAanKafkaDF
      .filter(('status =!= 1 and 'status =!= 2 and 'status =!= 3) or 'status.isNull)
      .withColumn("start_point",concat_ws(",",'start_longitude,'start_latitude))
      .withColumn("end_point",concat_ws(",",'end_longitude,'end_latitude))
      .withColumn("diff_depart_tm",unix_timestamp('actual_depart_tm,"yyyy-MM-dd HH:mm:ss") - unix_timestamp('plan_depart_tm,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("if_plan_delay",when(unix_timestamp('plan_arrive_tm,"yyyy-MM-dd HH:mm:ss") > unix_timestamp('actual_arrive_tm,"yyyy-MM-dd HH:mm:ss"),1).otherwise(0))
      .withColumn("if_latest_delay",when(('latest_arrived_time / 1000) > unix_timestamp('actual_arrive_tm,"yyyy-MM-dd HH:mm:ss"),1).otherwise(0))
      .withColumn("if_latest_null_delay",when('latest_arrived_time.isNull,"是").otherwise("否"))
      .withColumn("if_actual_delay_plan",when('diff_depart_tm > 0,"实际发车晚于计划发车").otherwise("实际发车早于计划发车"))
      .withColumn("pick_up_point",concat_ws(",",'pick_up_lng,'pick_up_lat))
      .withColumn("plan_arrive_tm_sjc",unix_timestamp('plan_arrive_tm,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("plan_depart_tm_sjc",unix_timestamp('plan_depart_tm,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("lineType",when('source === "eta",when('lineType === "std2","标准线路").when('lineType === "zh2","路径规划")).when('source === "navi",""))
      .withColumn("lineSource",when('source === "eta",when('lineSource === "cache","缓存").otherwise("非缓存")).when('source === "navi",""))
      .withColumn("lineSource2",concat_ws("_",'lineType,'lineSource))
      .withColumn("group",concat_ws("_",'task_id,'dest_zone_code))
      .withColumn("group2",concat_ws("_",'task_id,'src_zone_code,'dest_zone_code,'dest_zone_coordinate))
      .withColumn("pickup_point",concat_ws(",",'pick_up_lng,'pick_up_lat))
      .withColumn("pick_up_tm2",unix_timestamp('pick_up_tm,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("arrival_tm2",unix_timestamp('arrival_tm,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("plan_arrive_tm2",unix_timestamp('plan_arrive_tm,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("planArriveTm_compare",'plan_arrive_tm2 + 'diff_depart_tm) //对比
      .withColumn("arrival_tm3",('arrival_tm2 - ('compensateTime * 60)).cast(LongType))
      .withColumn("arrival_tm4",from_unixtime('arrival_tm3,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("diff_run_tm",round(('planArriveTm_compare - 'arrival_tm3) / 60,0))
      .withColumn("diff_plan_tm",round(('plan_arrive_tm2 - 'arrival_tm3) / 60,0))
      .withColumn("diff_latest_tm",round(('latest_arrived_time/1000 - 'arrival_tm3) / 60,0))
      .withColumn("origin_run_arrive_tm",from_unixtime('planArriveTm_compare,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("origin_plan_arrive_tm",from_unixtime('plan_arrive_tm2,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("origin_latest_arrive_tm",from_unixtime('latest_arrived_time/1000,"yyyy-MM-dd HH:mm:ss"))
      .withColumn("difftime_plan_actual",round(('plan_arrive_tm2 - unix_timestamp('actual_arrive_tm,"yyyy-MM-dd HH:mm:ss"))/60,0))
      .withColumn("actual_run_arrive_tm",'diff_run_tm - 'difftime_plan_actual)
      .withColumn("actual_plan_arrive_tm",'diff_plan_tm - 'difftime_plan_actual)
      .withColumn("actual_latest_arrive_tm",'diff_latest_tm - 'difftime_plan_actual)
      .withColumn("if_delay_run",when('pick_up_tm2 > ('planArriveTm_compare + 60),"true").otherwise("false"))
      .withColumn("if_delay_plan",when('pick_up_tm2 > ('plan_arrive_tm2 + 60),"true").otherwise("false"))
      .withColumn("if_delay_latest",when('pick_up_tm2 > ('latest_arrived_time / 1000 + 60),"true").otherwise("false"))
      .withColumn("plan_arrived_tm_state",when('plan_arrived_tm_state === 1,"true").otherwise("false"))
      .withColumn("latest_arrived_tm_state",when('latest_arrived_tm_state === 1,"true").otherwise("false"))
      .withColumn("plan_run_tm_state",when('planruntmstate === 1,"true").otherwise("false"))
      .withColumn("order", row_number().over(Window.partitionBy('group2,'pick_up_tm).orderBy(desc("type"))) - 1)
      .withColumn("group2_order", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm2"))) - 1)

    // 保存数据
    val res_cols = spark.sql("""select * from dm_gis.kafka_recall_request_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,kafka_recall_request_detail.select(res_cols: _*),Seq("inc_day"),"dm_gis.kafka_recall_request_detail")

  }
}

