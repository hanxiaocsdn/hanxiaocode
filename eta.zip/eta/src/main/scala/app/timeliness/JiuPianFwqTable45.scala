package app.timeliness

import Utils.SparkUtils.writeToHive
import Utils.StringUtils.timeToCustomTime
import app.timeliness.TimeLinessObj.JiuPianFWQ
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import scala.collection.mutable.ArrayBuffer

// 纠偏任务明细表，表4和表5逻辑
object JiuPianFwqTable45 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  // val Integrate_URL: String = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
  val Integrate_URL: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"  // 新轨迹中台迁移 20230821
  val Integrate_AK: String = "87a1347bc3944718911a05c21ec888a9"
  val Rectify_URL: String = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val Rectify_AK: String = "87a1347bc3944718911a05c21ec888a9"
  val parallelism = 20
  val akMinuLimit = 1000

  /**
   * 解析历史轨迹纠偏接口返回值
   * @param ret
   * @return
   */
  def parseIntegrateHttpData(ret: JSONObject): (String, String, String, String) = {
    var history_path = new JSONArray()
    val his_tracks = new JSONArray()
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, s"请求失败: $msg", null, null)
      } else {
        try{
          history_path = ret.getJSONObject("result").getJSONObject("data").getJSONArray("track")
        }catch {
          case e: Exception => logger.error(e)
        }
        for(i <- 0 until history_path.size()){
          val track = history_path.getJSONObject(i)
          val accuracy = track.getInteger("ac")
          val azimuth = track.getFloat("be")
          val index = i
          val speed = track.getFloat("sp")
          val time = track.getInteger("tm")
          val Type = 1
          val x = track.getFloat("zx")
          val y = track.getFloat("zy")

          val his_tracks_obj = new JSONObject()
          his_tracks_obj.put("accuracy",accuracy)
          his_tracks_obj.put("azimuth",azimuth)
          his_tracks_obj.put("index",index)
          his_tracks_obj.put("speed",speed)
          his_tracks_obj.put("time",time)
          his_tracks_obj.put("type",Type)
          his_tracks_obj.put("x",x)
          his_tracks_obj.put("y",y)

          his_tracks.add(his_tracks_obj)
        }
        return (codeStatue, "成功", null, his_tracks.toJSONString)
      }
    }
    ("22", "请求失败,接口返回值为空", null, null)
  }

  /**
   * 调用调历史轨迹接口
   * @param ak
   * @param obj
   * @return
   */
  def runIntegrateInteface(ak:String, obj: JSONObject): JSONObject = {
    val un = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
    val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
    val beginDateTime = timeToCustomTime(actual_depart_tm,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")
    val endDateTime = timeToCustomTime(actual_arrive_tm,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("un", un)
    param.put("beginDateTime", beginDateTime)
    param.put("endDateTime", endDateTime)
    param.put("type","0")
    param.put("ak", ak)
    param.put("rectify","false")

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(Integrate_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值,获取his_tracks
    val httpData: (String, String, String, String) = parseIntegrateHttpData(retJSONObject)
    obj.put("his_tracks",httpData._4)

    // 调历轨迹纠偏接口
    runRectifyInteface(Rectify_AK,obj)
  }

  /**
   * 解析历轨迹纠偏接口返回值
   * @param ret
   * @return
   */
  def parseRectifyHttpData(ret: JSONObject):(String,String,String,String,String,String,String,String) = {
    var tracks = new JSONArray()
    val SWID_arr = new ArrayBuffer[String]()
    val time_arr = new ArrayBuffer[String]()
    val xy_arr = new ArrayBuffer[String]()
    val status_arr = new ArrayBuffer[String]()
    val sum_dist_arr = new ArrayBuffer[String]()
    val roadclass_arr = new ArrayBuffer[String]()
    val link_length_arr = new ArrayBuffer[String]()

    var jp_swid = ""
    var jp_time = ""
    var jp_coords = ""
    var jp_status = ""
    var sum_dist = ""

    // 20230530 挽救线路绕路指标需求新增获取字段
    var roadclass = ""
    var link_length = ""

    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (jp_swid,jp_time,jp_coords,jp_status,sum_dist,codeStatue,roadclass,link_length)
      } else {
        try{
          tracks = ret.getJSONObject("result").getJSONArray("tracks")
        }catch {
          case e: Exception => logger.error(e)
        }
        for(i <- 0 until tracks.size()){
          val track = tracks.getJSONObject(i)
          val x = track.getString("x")
          val y = track.getString("y")
          val xy = s"$x,$y"
          SWID_arr.append(track.getString("SWID"))
          time_arr.append(track.getString("time"))
          xy_arr.append(xy)
          status_arr.append(track.getString("status"))
          sum_dist_arr.append(track.getString("sum_dist"))
          roadclass_arr.append(track.getString("roadclass"))
          link_length_arr.append(track.getString("link_length"))
        }
        jp_swid = SWID_arr.mkString("|")
        jp_time = time_arr.mkString("|")
        jp_coords = xy_arr.mkString("|")
        jp_status = status_arr.mkString("|")
        sum_dist = sum_dist_arr.mkString("|")
        roadclass = roadclass_arr.mkString("|")
        link_length = link_length_arr.mkString("|")

        return (jp_swid,jp_time,jp_coords,jp_status,sum_dist,codeStatue,roadclass,link_length)
      }
    }
    (jp_swid,jp_time,jp_coords,jp_status,sum_dist,"222",roadclass,link_length)
  }

  /**
   * 调历轨迹纠偏接口
   * @param ak
   * @param obj
   * @return
   */
  def runRectifyInteface(ak:String, obj: JSONObject): JSONObject = {
    val tracks = obj.getJSONArray("his_tracks")
    //初始化接口请求参数
    val process = new JSONObject()
    process.put("stay_time",30)
    process.put("stay_radius",100)
    process.put("stay_join_dist",50)

    val param = new JSONObject()
    param.put("keeptype", 1)
    param.put("roadinfo", 1)
    param.put("retflag", 7)
    param.put("only_primary", 0)
    param.put("ak", ak)
    param.put("process", process)
    param.put("tracks", tracks)
    param.put("addpoint", 1)
    param.put("compensate", 1)
    param.put("compensate_time", 0)
    param.put("compensate_dist", 0)
    param.put("mat_ratio", 1)
    param.put("poiinfo", 1)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(Rectify_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String,String,String,String,String,String,String,String) = parseRectifyHttpData(retJSONObject)
    obj.put("jp_swid",httpData._1)
    obj.put("jp_time",httpData._2)
    obj.put("jp_coords",httpData._3)
    obj.put("jp_status",httpData._4)
    obj.put("sum_dist",httpData._5)
    obj.put("code_statue2",httpData._6)
    obj.put("roadclass",httpData._7)
    obj.put("link_length",httpData._8)
    obj
  }

  /**
   * 从table2取数
   * @param spark
   * @param dayBefore1
   * @return
   */
  def getKafkaRecallTaskDetail(spark: SparkSession, dayBefore1: String) = {
    val table2_querySql =
      s"""
         |select
         |  group2,
         |  task_id,
         |  sort_num,
         |  task_subid,
         |  accelarater_or_run,
         |  vehicle_serial,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  plan_run_tm_state,
         |  plan_arrived_tm_state,
         |  latest_arrived_tm_state,
         |  pick_up_tm,
         |  solution,
         |  0 as navi_type,
         |  task_type,
         |  inc_day
         |from
         |  dm_gis.kafka_recall_task_detail
         |where
         |  inc_day = '$dayBefore1'
         |  and accelarater_or_run <> ''
         |""".stripMargin
    println(table2_querySql)
    val taskDetailDF = spark.sql(table2_querySql)
    taskDetailDF
  }

  /**
   * 从table3取数
   * @param spark
   * @param dayBefore1
   * @return
   */
  def getKafkaRecallTaskDetailNavi(spark: SparkSession, dayBefore1: String) = {
    val table3_querySql =
      s"""
         |select
         |  group2,
         |  task_id,
         |  sort_num,
         |  task_subid,
         |  accelarater_or_run,
         |  vehicle_serial,
         |  actual_depart_tm,
         |  actual_arrive_tm,
         |  plan_run_tm_state,
         |  plan_arrived_tm_state,
         |  latest_arrived_tm_state,
         |  pick_up_tm,
         |  solution,
         |  1 as navi_type,
         |  task_type,
         |  inc_day
         |from
         |  dm_gis.kafka_recall_task_detail_navi
         |where
         |  inc_day = '$dayBefore1'
         |  and accelarater_or_run <> ''
         |""".stripMargin
    println(table3_querySql)
    val taskDetailNaviDF = spark.sql(table3_querySql)
    taskDetailNaviDF
  }

  /**
   * 从eta_task_time_information表取数
   * @param spark
   * @param dayBefore1
   * @param dayBefore2
   * @return
   */
  def getEtaTaskTimeInformation(spark: SparkSession, dayBefore1: String, dayBefore2: String) = {
    import spark.implicits._
    val information_querySql =
      s"""
         |select
         |  task_subid,
         |  disu_periods_final,
         |  disu_label_sub_oj,
         |  task_label_keguan,
         |  task_label_zhuguan
         |from
         |  dm_gis.eta_task_time_information
         |where
         |  inc_day >= '$dayBefore2'
         |  and inc_day <= '$dayBefore1'
         |  and (
         |    task_label_keguan like '%服务区%'
         |    or task_label_zhuguan like '%服务区%'
         |  )
         |""".stripMargin
    println(information_querySql)
    val informationDF = spark.sql(information_querySql)

    // 获取service_disu_label 和 service_disu_periods 字段
    val informationRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark,informationDF)
    val informationDF_new = informationRdd.map(obj=>{
      val task_subid = JSONUtil.getJsonValSingle(obj, "task_subid","")
      val disu_periods_final = JSONUtil.getJsonValSingle(obj, "disu_periods_final","")
      val disu_label_sub_oj = JSONUtil.getJsonValSingle(obj, "disu_label_sub_oj","")

      // 获取service_disu_label 和 service_disu_periods
      val disu_label_arr = disu_label_sub_oj.split("\\|")
      val disu_periods_arr = disu_periods_final.split("\\|")
      val disu_label_buff = new ArrayBuffer[String]()
      val disu_periods_buff = new ArrayBuffer[String]()
      for(i <- 0 until disu_label_arr.length){
        val disu_label = disu_label_arr(i)
        if(disu_label.contains("服务区")){
          disu_label_buff.append(disu_label)
          disu_periods_buff.append(disu_periods_arr(i))
        }
      }
      val service_disu_label = disu_label_buff.mkString("|")
      val service_disu_periods = disu_periods_buff.mkString("|")

      (task_subid,disu_periods_final,disu_label_sub_oj,service_disu_label,service_disu_periods)
    }).toDF("task_subid","disu_periods_final","disu_label_sub_oj","service_disu_label","service_disu_periods")
    informationDF_new
  }

  def runJiuPianFWQ(spark: SparkSession, dayBefore1: String, dayBefore2: String) = {
    import spark.implicits._
    // 生产环境取数
    val taskDetailDF = getKafkaRecallTaskDetail(spark,dayBefore1)
    val taskDetailNaviDF = getKafkaRecallTaskDetailNavi(spark,dayBefore1)
    val informationDF_new = getEtaTaskTimeInformation(spark,dayBefore1,dayBefore2)

    // 调用历史轨迹纠偏接口
    taskDetailDF.union(taskDetailNaviDF).createOrReplaceTempView("result_table")
    var resultRDD: RDD[JSONObject] = SparkUtils.getRowToJson(spark,"select * from result_table")

    val invokeCnt_1 = resultRDD.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "574498", "时效预警And挽救指标体系", "获取历史轨迹", Integrate_URL, Integrate_AK, invokeCnt_1, parallelism)
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "574498", "时效预警And挽救指标体系", "轨迹纠偏", Rectify_URL, Rectify_AK, invokeCnt_1, parallelism)
    // 调历史轨迹接口和轨迹纠偏接口
    resultRDD = SparkNet.runInterfaceWithAkLimit(spark, resultRDD, runIntegrateInteface, parallelism, Integrate_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    val jiupian_fwq_all = resultRDD.repartition(500).map(obj => {
      val group2 = JSONUtil.getJsonVal(obj, "group2", "")
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val sort_num = JSONUtil.getJsonVal(obj, "sort_num", "")
      val task_subid = JSONUtil.getJsonVal(obj, "task_subid", "")
      val accelarater_or_run = JSONUtil.getJsonVal(obj, "accelarater_or_run", "")
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
      val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
      val plan_run_tm_state = JSONUtil.getJsonVal(obj, "plan_run_tm_state", "")
      val plan_arrived_tm_state = JSONUtil.getJsonVal(obj, "plan_arrived_tm_state", "")
      val latest_arrived_tm_state = JSONUtil.getJsonVal(obj, "latest_arrived_tm_state", "")
      val pick_up_tm = JSONUtil.getJsonVal(obj, "pick_up_tm", "")
      val solution = JSONUtil.getJsonVal(obj, "solution", "")
      val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")
      val jp_swid = JSONUtil.getJsonVal(obj, "jp_swid", "")
      val jp_time = JSONUtil.getJsonVal(obj, "jp_time", "")
      val jp_coords = JSONUtil.getJsonVal(obj, "jp_coords", "")
      val jp_status = JSONUtil.getJsonVal(obj, "jp_status", "")
      val sum_dist = JSONUtil.getJsonVal(obj, "sum_dist", "")
      val navi_type = JSONUtil.getJsonVal(obj, "navi_type", "")
      val task_type = JSONUtil.getJsonVal(obj, "task_type", "")
      val code_statue2 = JSONUtil.getJsonVal(obj, "code_statue2", "")

      JiuPianFWQ(group2,task_id,sort_num,task_subid,accelarater_or_run,vehicle_serial,actual_depart_tm,actual_arrive_tm,plan_run_tm_state,
        plan_arrived_tm_state,latest_arrived_tm_state,pick_up_tm,solution,inc_day,jp_swid,jp_time,jp_coords,jp_status,sum_dist,navi_type,task_type,code_statue2)
    }).toDF
      .join(informationDF_new,Seq("task_subid"),"left")
      .coalesce(50)

    // 表4 存入hive
    val jiupian_fwq = jiupian_fwq_all.filter('navi_type === 0)
    val fwq_cols = spark.sql("""select * from dm_gis.jiupian_fwq limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,jiupian_fwq.select(fwq_cols: _*),Seq("inc_day"),"dm_gis.jiupian_fwq")

    // 表5 存入hive
    val jiupian_fwq_navi = jiupian_fwq_all.filter('navi_type === 1)
    val navi_cols = spark.sql("""select * from dm_gis.jiupian_fwq_navi limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,jiupian_fwq_navi.select(navi_cols: _*),Seq("inc_day"),"dm_gis.jiupian_fwq_navi")

  }
}
