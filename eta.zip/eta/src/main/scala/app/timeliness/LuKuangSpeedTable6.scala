package app.timeliness

import Utils.SparkUtils.writeToHive
import app.timeliness.Functions.{getStateAfterExcludingOutlier, getSwidSpeed, sumSwidSpeed}
import app.timeliness.TimeLinessObj.PickExplodeDF
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import java.text.SimpleDateFormat
import scala.collection.mutable.ArrayBuffer

// 路况速度任务明细表，表6和表7逻辑
object LuKuangSpeedTable6 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  val History2_URL: String = "http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/tmc/history2"
  val History2_AK: String = "35a8f1a6a7b344339a91dc15d808293d"
  val QM_Point_URL: String = "http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf?"
  val QM_Point_AK: String = "16c698869fe3452b9f77a302e12b056b"
  val parallelism = 10
  val akMinuLimit = 1000

  /**
   * 根据swid去重，获取对应位置的dist
   * @param min_swid
   * @param min_dist
   * @return
   */
  def get15MinDist2(min_swid: String,min_dist: String) = {
    val min_swid_arr2 = min_swid.split("\\|")
    val min_dist_arr2 = min_dist.split("\\|")
    val link_id_arr2 = new ArrayBuffer[String]()
    val arr_tmp = new ArrayBuffer[String]()
    for(i <- 0 until min_swid_arr2.length){
      val link_id2 = min_swid_arr2(i)
      val dist2 = min_dist_arr2(i)
      if(!link_id_arr2.contains(link_id2)){
        link_id_arr2.append(link_id2)
        arr_tmp.append(dist2)
      }
    }
    var dist0 = 0.0
    var dist1 = 0.0
    try {
      dist0 = arr_tmp(0).toDouble
      dist1 = arr_tmp(arr_tmp.length - 1).toDouble
    } catch {
      case e: Exception => null
    }
    val total_dist2 = dist1 - dist0
    val min_dist2 = arr_tmp.mkString("|")
    (min_dist2,total_dist2)
  }

  /**
   * 根据index 获取每个pick_up_tm前后15分钟所有的swd、距离和时间
   * @param arr
   * @param index1
   * @param index2
   * @return
   */
  def get15MinDist(arr: Array[String], index1: Int, index2: Int) = {
    var res = ""
    val arr_tmp = new ArrayBuffer[String]()
    if(index1 < index2){
      for(i <- index1 until index2){
        val arr_i = arr(i)
        arr_tmp.append(arr_i)
      }
      res = arr_tmp.mkString("|")
    }else{
      for(i <- index2 until index1){
        val arr_i = arr(i)
        arr_tmp.append(arr_i)
      }
      res = arr_tmp.mkString("|")
    }
    res
  }

  /**
   * 详情1逻辑,获取加速点位前后15min相关信息
   * @param obj
   * @return
   */
  def getTheinformationBeforeAndAfter15Min(obj: JSONObject): JSONObject = {
    val pick_up_tm = JSONUtil.getJsonValSingle(obj, "pick_up_tm","")
    val accelarater_or_run = JSONUtil.getJsonValSingle(obj, "accelarater_or_run","")
    val service_disu_periods = JSONUtil.getJsonValSingle(obj, "service_disu_periods","")
    val solution = JSONUtil.getJsonValSingle(obj, "solution","")
    val plan_run_tm_state = JSONUtil.getJsonValSingle(obj, "plan_run_tm_state","")
    val jp_swid = JSONUtil.getJsonValSingle(obj, "jp_swid","")
    val jp_time = JSONUtil.getJsonValSingle(obj, "jp_time","")
    val sum_dist = JSONUtil.getJsonValSingle(obj, "sum_dist","")

    val pick_up_tm_arr = pick_up_tm.split("\\|")
    val solution_arr = solution.split("\\|")
    val plan_run_tm_state_arr = plan_run_tm_state.split("\\|")
    val jp_time_arr = jp_time.split("\\|")
    val sum_dist_arr = sum_dist.split("\\|")
    val jp_swid_arr = jp_swid.split("\\|")

    val pick_up_tm_obj = new JSONObject()
    for(a <- 0 until pick_up_tm_arr.length){
      // filter_flag 字段用来标记是否满足条件，便于后续筛选过滤
      var filter_flag = "false"
      val case_obj = new JSONObject()
      val pick_up_tm_i = pick_up_tm_arr(a)
      val solution_i = solution_arr(a)
      val plan_run_tm_state_i = plan_run_tm_state_arr(a)

      //if((accelarater_or_run == "加速" && solution_i == "加速方案") || (accelarater_or_run == "运行" && plan_run_tm_state_i == "true")){
      if(accelarater_or_run == "加速" && solution_i == "加速方案"){    // v2.0 修改后逻辑
        filter_flag = "true"
        var pick_up_stamp = 0L
        try {
          pick_up_stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(pick_up_tm_i).getTime/1000
        } catch {
          case e: Exception => null
        }

        val shiwu_min_zheng = pick_up_stamp + 15*60
        var shiwu_min_fu = pick_up_stamp - 15*60

        var zheng_min = Long.MaxValue
        var pick_min = Long.MaxValue
        var fu_min = Long.MaxValue
        var index1 = 0
        var index2 = 0
        var index3= 0
        // 当前请求时间pick_up_tm[i]选取与jp_time中最近的时间戳，并获取索引index1、index2、index3
        for(b <- 0 until jp_time_arr.length){
          var jp_time_stamp = 0L
          try {
            jp_time_stamp = jp_time_arr(b).toLong
          } catch {
            case e: Exception => null
          }
          val zheng_abs = Math.abs(shiwu_min_zheng - jp_time_stamp)
          val pick_abs = Math.abs(pick_up_stamp - jp_time_stamp)
          val fu_abs = Math.abs(shiwu_min_fu - jp_time_stamp)
          if(zheng_abs < zheng_min) {
            zheng_min = zheng_abs
            index1 = b
          }
          if(pick_abs < pick_min) {
            pick_min = pick_abs
            index2 = b
          }
          if(fu_abs < fu_min) {
            fu_min = fu_abs
            index3 = b
          }
        }
        var before_15min_moment = 0L
        var before_15min_moment_tm = ""
        try {
          before_15min_moment = jp_time_arr(index3).toLong
          before_15min_moment_tm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(jp_time_arr(index3).toLong * 1000)
        } catch {
          case e: Exception => null
        }
        var before_15min_service_label = ""

        //若存在服务区主客观低速，则刷新shiwu_min_fu，before_15min_moment，index3
        if(service_disu_periods != ""){
          // 获取start和end
          val periods_arr = service_disu_periods.split("\\|")
          for(c <- 0 until periods_arr.length){
            var start = 0L
            var end  = 0L
            try {
              start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(periods_arr(c).split("_")(0)).getTime/1000
              end  =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(periods_arr(c).split("_")(1)).getTime/1000
            } catch {
              case e: Exception => null
            }
            // 按条件给shiwu_min_fu，before_15min_moment，index3重新赋值
            if(start < before_15min_moment && before_15min_moment < end && end < pick_up_stamp){
              val time_diff = end - start
              shiwu_min_fu = pick_up_stamp - time_diff - 15*60
              var fu_min_1 = Long.MaxValue
              for(d <- 0 until jp_time_arr.length){
                var jp_time_stamp = 0L
                try {
                  jp_time_stamp = jp_time_arr(d).toLong
                } catch {
                  case e: Exception => null
                }
                val fu_abs = Math.abs(shiwu_min_fu - jp_time_stamp)
                if(fu_abs < fu_min_1) {
                  fu_min_1 = fu_abs
                  index3 = d
                }
              }
              try {
                before_15min_moment = jp_time_arr(index3).toLong
                before_15min_moment_tm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(jp_time_arr(index3).toLong * 1000)
              } catch {
                case e: Exception => null
              }
              before_15min_service_label = "前15min时间点在低速段，请求时间不在"
            }else if(start < before_15min_moment && before_15min_moment < pick_up_stamp && pick_up_stamp < end){
              val time_diff = pick_up_stamp - start
              shiwu_min_fu = pick_up_stamp - time_diff - 15*60
              var fu_min_2 = Long.MaxValue
              for(e <- 0 until jp_time_arr.length){
                var jp_time_stamp = 0L
                try {
                  jp_time_stamp = jp_time_arr(e).toLong
                } catch {
                  case e: Exception => null
                }
                val fu_abs = Math.abs(shiwu_min_fu - jp_time_stamp)
                if(fu_abs < fu_min_2) {
                  fu_min_2 = fu_abs
                  index3 = e
                }
              }
              try {
                before_15min_moment = jp_time_arr(index3).toLong
                before_15min_moment_tm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(jp_time_arr(index3).toLong * 1000)
              } catch {
                case e: Exception => null
              }
              before_15min_service_label = "前15min时间点在低速段，请求时间在"
            }else if(before_15min_moment < start && start < end && end < pick_up_stamp){
              val time_diff = end - start
              shiwu_min_fu = pick_up_stamp - time_diff - 15*60
              var fu_min_3 = Long.MaxValue
              for(f <- 0 until jp_time_arr.length){
                var jp_time_stamp = 0L
                try {
                  jp_time_stamp = jp_time_arr(f).toLong
                } catch {
                  case e: Exception => null
                }
                val fu_abs = Math.abs(shiwu_min_fu - jp_time_stamp)
                if(fu_abs < fu_min_3) {
                  fu_min_3 = fu_abs
                  index3 = f
                }
              }
              try {
                before_15min_moment = jp_time_arr(index3).toLong
                before_15min_moment_tm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(jp_time_arr(index3).toLong * 1000)
              } catch {
                case e: Exception => null
              }
              before_15min_service_label = "前15min时间点不在低速段，请求时间不在"
            }else if(before_15min_moment < start && start < pick_up_stamp && pick_up_stamp < end){
              val time_diff = pick_up_stamp - start
              shiwu_min_fu = pick_up_stamp - time_diff - 15*60
              var fu_min_4 = Long.MaxValue
              for(g <- 0 until jp_time_arr.length){
                var jp_time_stamp = 0L
                try {
                  jp_time_stamp = jp_time_arr(g).toLong
                } catch {
                  case e: Exception => null
                }
                val fu_abs = Math.abs(shiwu_min_fu - jp_time_stamp)
                if(fu_abs < fu_min_4) {
                  fu_min_4 = fu_abs
                  index3 = g
                }
              }
              try {
                before_15min_moment = jp_time_arr(index3).toLong
                before_15min_moment_tm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(jp_time_arr(index3).toLong * 1000)
              } catch {
                case e: Exception => null
              }
              before_15min_service_label = "前15min时间点不在低速段，请求时间在"
            }else{
              before_15min_service_label = ""
            }
          }
        }

        // 统计每个pick_up_tm前后15分钟所有的swd、距离和时间
        val before_15min_dist = get15MinDist(sum_dist_arr,index2,index3)
        val after_15min_dist = get15MinDist(sum_dist_arr,index1,index2)
        val before_15min_time = get15MinDist(jp_time_arr,index2,index3)
        val after_15min_time = get15MinDist(jp_time_arr,index1,index2)
        val before_15min_swid = get15MinDist(jp_swid_arr,index2,index3)
        val after_15min_swid = get15MinDist(jp_swid_arr,index1,index2)

        // 统计每个pick_up_tm前后15分钟距离和时间差值
        var sum_dist_1 = 0.0
        var sum_dist_2 = 0.0
        var sum_dist_3 = 0.0
        var jp_time_1 = 0L
        var jp_time_3 = 0L
        try {
          sum_dist_1 = sum_dist_arr(index1).toDouble
          sum_dist_2 = sum_dist_arr(index2).toDouble
          sum_dist_3 = sum_dist_arr(index3).toDouble
          jp_time_1 = jp_time_arr(index1).toLong
          jp_time_3 = jp_time_arr(index3).toLong
        } catch {
          case e: Exception => null
        }
        val before_15min_total_dist = sum_dist_2 - sum_dist_3
        val after_15min_total_dist = sum_dist_1 - sum_dist_2
        val before_15min_duration = ((pick_up_stamp.toDouble - jp_time_3.toDouble) / 60).formatted("%.2f").toDouble
        val after_15min_duration = ((jp_time_1.toDouble - pick_up_stamp.toDouble) / 60).formatted("%.2f").toDouble
        val before_15min_speed = (before_15min_total_dist * 0.001) / (before_15min_duration / 60)
        val after_15min_speed = (after_15min_total_dist * 0.001) / (after_15min_duration / 60)

        // 按swid去重后对应的距离和时间
        val before_dist2 = get15MinDist2(before_15min_swid,before_15min_dist)
        val before_15min_dist2 = before_dist2._1
        val before_15min_total_dist2 = before_dist2._2
        val after_dist2 = get15MinDist2(after_15min_swid,after_15min_dist)
        val after_15min_dist2 = after_dist2._1
        val after_15min_total_dist2 = after_dist2._2

        case_obj.put("before_15min_moment",before_15min_moment_tm)
        case_obj.put("before_15min_service_label",before_15min_service_label)
        case_obj.put("pick_up_tm_jiasu",pick_up_tm_i)
        case_obj.put("before_15min_dist",before_15min_dist)
        case_obj.put("after_15min_dist",after_15min_dist)
        case_obj.put("before_15min_total_dist",before_15min_total_dist)
        case_obj.put("after_15min_total_dist",after_15min_total_dist)
        case_obj.put("before_15min_time",before_15min_time)
        case_obj.put("after_15min_time",after_15min_time)
        case_obj.put("before_15min_duration",before_15min_duration)
        case_obj.put("after_15min_duration",after_15min_duration)
        case_obj.put("before_15min_swid",before_15min_swid)
        case_obj.put("after_15min_swid",after_15min_swid)
        case_obj.put("before_15min_speed",before_15min_speed)
        case_obj.put("after_15min_speed",after_15min_speed)
        case_obj.put("filter_flag",filter_flag)
        case_obj.put("before_15min_dist2",before_15min_dist2)
        case_obj.put("before_15min_total_dist2",before_15min_total_dist2)
        case_obj.put("after_15min_dist2",after_15min_dist2)
        case_obj.put("after_15min_total_dist2",after_15min_total_dist2)

        // 按条件输出字段结果
        if(!(before_15min_duration >= 7 && after_15min_duration >= 7)){
          case_obj.put("elimate_outlier",pick_up_stamp)
          case_obj.put("elimate_outlier_tm",pick_up_tm_i)
        }else{
          case_obj.put("elimate_outlier","")
          case_obj.put("elimate_outlier_tm","")
        }
      }
      pick_up_tm_obj.put(pick_up_tm_i,case_obj)
    }
    obj.put("pick_up_tm_obj",pick_up_tm_obj)
    obj
  }

  /**
   * 解析路况接口返回值
   * @param ret
   * @return
   */
  def parseHistoryHttpData(ret: JSONObject): (String, String, String, String) = {
    var tracks = new JSONArray()
    if (ret != null ) {
      var codeStatue = "33"
      //获取返回请求返回状态
      try{
        codeStatue = ret.getString("CODE")
      }catch {
        case e: Exception => logger.error(e)
      }
      //判断获取的数据是否成功
      if (!"1".equalsIgnoreCase(codeStatue)) {
        val msg = JSONUtil.getJsonVal(JSONUtil.getJSONObject(ret, "result"), "msg", "")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null, null)
      } else {
        try{
          tracks = ret.getJSONArray("tracks")
        }catch {
          case e: Exception => logger.error(e)
        }
        val speed_arr_w = new ArrayBuffer[String]()
        val link_id_arr = new ArrayBuffer[String]()
        for(i <- 0 until tracks.size()){
          val track = tracks.getJSONObject(i)
          val link_id = track.getString("link_id")
          val flows = track.getJSONArray("flow")

          val speed_arr = new ArrayBuffer[String]()
          for(j <- 0 until flows.size()){
            val flow = flows.getJSONObject(j)
            val speed = flow.getString("speed")
            speed_arr.append(speed)
          }
          val speeds = speed_arr.mkString("|")
          speed_arr_w.append(speeds)
          link_id_arr.append(link_id)
        }
        val before_15min_lukuang_swid = link_id_arr.mkString("|")
        val before_15min_lukuang_speed = speed_arr_w.mkString("|")
        return (codeStatue, "成功", before_15min_lukuang_swid, before_15min_lukuang_speed)
      }
    }
    ("22", "请求失败，接口返回值为空", null, null)
  }

  /**
   * 解析匹配接口返回值
   * @param ret
   * @return
   */
  def parseQMPointHttpData(ret: JSONObject): (String, String, String) = {
    var paths = new JSONArray()
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getString("info")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null)
      } else {
        try{
          paths = ret.getJSONObject("route").getJSONArray("paths")
        }catch {
          case e: Exception => logger.error(e)
        }
        val dr_length_arr3 = new ArrayBuffer[String]()
        for(i <- 0 until paths.size()){
          val path = paths.getJSONObject(i)
          val steps = path.getJSONArray("steps")

          val dr_length_arr2 = new ArrayBuffer[String]()
          for(j <- 0 until steps.size()){
            val step = steps.getJSONObject(j)
            val links = step.getJSONArray("links")

            val dr_length_arr1 = new ArrayBuffer[String]()
            for(m <- 0 until links.size()){
              val link = links.getJSONObject(m)
              val dr_length = link.getString("dr_length")
              dr_length_arr1.append(dr_length)
            }
            val dr_length_1 = dr_length_arr1.mkString("|")
            dr_length_arr2.append(dr_length_1)
          }
          val dr_length_2 = dr_length_arr2.mkString("|")
          dr_length_arr3.append(dr_length_2)
        }
        val before_15min_lukuang_length = dr_length_arr3.mkString("|")
        return (codeStatue, "请求成功", before_15min_lukuang_length)
      }
    }
    ("22", "请求失败，接口返回值为空", null)
  }

  /**
   * before_15min_swid 调路况接口
   * @param ak
   * @param obj
   * @return
   */
  def runHistory1Inteface(ak:String, obj: JSONObject): JSONObject = {
    val pick_up_tm_i = JSONUtil.getJsonValSingle(obj, "pick_up_tm_i","")
    val pick_up_tm_obj = JSONUtil.getJsonObjectMulti(obj, "pick_up_tm_obj")
    val case_obj = JSONUtil.getJsonObjectMulti(pick_up_tm_obj, pick_up_tm_i)
    val before_15min_swid = JSONUtil.getJsonValSingle(case_obj, "before_15min_swid","")
    val before_15min_time = JSONUtil.getJsonValSingle(case_obj, "before_15min_time","")

    val before_15min_swid_arr = before_15min_swid.split("\\|")
    val before_15min_time_arr = before_15min_time.split("\\|")

    // tracks轨迹按照swid去重
    val tracks = new JSONArray()
    val link_id_arr = new ArrayBuffer[String]()
    for(i <- 0 until before_15min_swid_arr.length){
      val track_obj = new JSONObject()
      val link_id = before_15min_swid_arr(i)
      val timestamp = before_15min_time_arr(i)
      if(!link_id_arr.contains(link_id)){
        link_id_arr.append(link_id)
        track_obj.put("link_id",link_id)
        track_obj.put("timestamp",timestamp)
        tracks.add(track_obj)
      }
    }
    //初始化接口请求参数
    val param = new JSONObject()
    param.put("ak", ak)
    param.put("focus", "flow")
    param.put("tracks", tracks)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost2(History2_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String, String) = parseHistoryHttpData(retJSONObject)
    obj.put("before_15min_lukuang_swid",httpData._3)
    obj.put("before_15min_lukuang_speed",httpData._4)

    // 第二次调路况接口
    val obj2 = runHistory2Inteface(History2_AK, obj)
    // 第一次调qm匹配接口
    val obj3 = runQMPoint1Inteface(QM_Point_AK, obj2)
    // 第二次调qm匹配接口
    val obj4 = runQMPoint2Inteface(QM_Point_AK, obj3)

    obj4
  }

  /**
   * after_15min_swid 调路况接口
   * @param ak
   * @param obj
   * @return
   */
  def runHistory2Inteface(ak:String, obj: JSONObject): JSONObject = {
    val pick_up_tm_i = JSONUtil.getJsonValSingle(obj, "pick_up_tm_i","")
    val pick_up_tm_obj = JSONUtil.getJsonObjectMulti(obj, "pick_up_tm_obj")
    val case_obj = JSONUtil.getJsonObjectMulti(pick_up_tm_obj, pick_up_tm_i)
    val after_15min_swid = JSONUtil.getJsonValSingle(case_obj, "after_15min_swid","")
    val after_15min_time = JSONUtil.getJsonValSingle(case_obj, "after_15min_time","")

    val after_15min_swid_arr = after_15min_swid.split("\\|")
    val after_15min_time_arr = after_15min_time.split("\\|")

    // tracks轨迹按照swid去重
    val tracks = new JSONArray()
    val link_id_arr = new ArrayBuffer[String]()
    for(i <- 0 until after_15min_swid_arr.length){
      val track_obj = new JSONObject()
      val link_id = after_15min_swid_arr(i)
      val timestamp = after_15min_time_arr(i)
      if(!link_id_arr.contains(link_id)){
        link_id_arr.append(link_id)
        track_obj.put("link_id",link_id)
        track_obj.put("timestamp",timestamp)
        tracks.add(track_obj)
      }
    }
    //初始化接口请求参数
    val param = new JSONObject()
    param.put("ak", ak)
    param.put("focus", "flow")
    param.put("tracks", tracks)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost2(History2_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String, String) = parseHistoryHttpData(retJSONObject)
    obj.put("after_15min_lukuang_swid",httpData._3)
    obj.put("after_15min_lukuang_speed",httpData._4)
    obj
  }

  /**
   * before_15min_lukuang_swid 调匹配接口
   * @param ak
   * @param obj
   * @return
   */
  def runQMPoint1Inteface(ak:String, obj: JSONObject): JSONObject = {
    val before_15min_lukuang_swid = JSONUtil.getJsonValSingle(obj, "before_15min_lukuang_swid","")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("strategy","4")
    param.put("opt", "sf4")
    param.put("test", "0")
    param.put("stype", 0)
    param.put("etype", 0)
    param.put("plateColor", 1)
    param.put("emitStand", 0)
    param.put("energy", 1)
    param.put("vehicle", 6)
    param.put("weight", 0)
    param.put("Mload", 0)
    param.put("height", 0)
    param.put("width", 0)
    param.put("Size", 0)
    param.put("axleweight",0)
    param.put("axlenumber",0)
    param.put("passport","100000")
    param.put("date",0)
    param.put("mode",2)
    param.put("speed",1)
    param.put("No",0)
    param.put("Toll",1)
    param.put("ak", ak)
    param.put("swId",before_15min_lukuang_swid)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_Point_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String) = parseQMPointHttpData(retJSONObject)
    obj.put("before_15min_lukuang_length",httpData._3)
    obj
  }

  /**
   * after_15min_lukuang_swid 调匹配接口
   * @param ak
   * @param obj
   * @return
   */
  def runQMPoint2Inteface(ak:String, obj: JSONObject): JSONObject = {
    val after_15min_lukuang_swid = JSONUtil.getJsonValSingle(obj, "after_15min_lukuang_swid","")

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("strategy","4")
    param.put("opt", "sf4")
    param.put("test", "0")
    param.put("stype", 0)
    param.put("etype", 0)
    param.put("plateColor", 1)
    param.put("emitStand", 0)
    param.put("energy", 1)
    param.put("vehicle", 6)
    param.put("weight", 0)
    param.put("Mload", 0)
    param.put("height", 0)
    param.put("width", 0)
    param.put("Size", 0)
    param.put("axleweight",0)
    param.put("axlenumber",0)
    param.put("passport","100000")
    param.put("date",0)
    param.put("mode",2)
    param.put("speed",1)
    param.put("No",0)
    param.put("Toll",1)
    param.put("ak", ak)
    param.put("swId",after_15min_lukuang_swid)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(QM_Point_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String, String, String) = parseQMPointHttpData(retJSONObject)
    obj.put("after_15min_lukuang_length",httpData._3)
    obj
  }

  def runLuKuangSpeed(spark: SparkSession,dayBefore1: String, flag: String) = {

    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  *
           |from
           |  dm_gis.jiupian_fwq
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("navi")){
      querySql =
        s"""
           |select
           |  *
           |from
           |  dm_gis.jiupian_fwq_navi
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }
    println(querySql)
    val df_jiupian_fwq = spark.sql(querySql)

    import spark.implicits._
    // 详情1：获取加速点位前后15min相关信息
    val rdd_jiupian_fwq: RDD[JSONObject] = SparkUtils.getDfToJson(spark,df_jiupian_fwq)
    val rdd_pick_explode = rdd_jiupian_fwq.repartition(200).flatMap(obj=>{
      val pick_up_tm = JSONUtil.getJsonValSingle(obj, "pick_up_tm","")
      val pick_up_tm_arr = pick_up_tm.split("\\|")
      // 获取加速点位前后15min相关信息
      val pick_obj = getTheinformationBeforeAndAfter15Min(obj)

      val dataArray = new ArrayBuffer[(String,JSONObject)]()
      for(i <- 0 until pick_up_tm_arr.length){
        dataArray.append((pick_up_tm_arr(i),pick_obj))
      }
      dataArray.iterator
    })
      //.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    // 获取详情1数据,展开后再过滤掉无效数据
    var rdd_pick_iadd: RDD[JSONObject] = rdd_pick_explode.repartition(200).map(obj => {
      val pick_up_tm_i = obj._1
      val data_obj = obj._2
      val pick_up_tm_obj = JSONUtil.getJsonObjectMulti(data_obj, "pick_up_tm_obj")
      val case_obj = JSONUtil.getJsonObjectMulti(pick_up_tm_obj, pick_up_tm_i)
      val filter_flag = JSONUtil.getJsonValSingle(case_obj, "filter_flag","")
      data_obj.put("pick_up_tm_i", pick_up_tm_i)
      data_obj.put("filter_flag", filter_flag)
      data_obj
    }).filter(obj => {
      val filter_flag = JSONUtil.getJsonValSingle(obj, "filter_flag","")
      filter_flag.equals("true")
    })
    //println("详情1展开后有效的数据总量："+rdd_pick_iadd.count())

    val invokeCnt_1 = rdd_pick_iadd.count() * 2
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "574498", "时效预警And挽救指标体系", "获取路况数据", History2_URL, History2_AK, invokeCnt_1, parallelism)
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "574498", "时效预警And挽救指标体系", "线路匹配", QM_Point_URL, QM_Point_AK, invokeCnt_1, parallelism)
    // 调两次路况，两次匹配接口
    rdd_pick_iadd = SparkNet.runInterfaceWithAkLimit(spark, rdd_pick_iadd, runHistory1Inteface, parallelism, History2_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    val df_pick_explode = rdd_pick_iadd.repartition(200).map(obj=>{
      val pick_up_tm_i = JSONUtil.getJsonValSingle(obj,"pick_up_tm_i","")
      val task_subid = JSONUtil.getJsonValSingle(obj, "task_subid","")
      val group2 = JSONUtil.getJsonValSingle(obj, "group2","")
      val pick_up_tm = JSONUtil.getJsonValSingle(obj, "pick_up_tm","")
      val accelarater_or_run = JSONUtil.getJsonValSingle(obj, "accelarater_or_run","")
      val service_disu_label = JSONUtil.getJsonValSingle(obj, "service_disu_label","")
      val service_disu_periods = JSONUtil.getJsonValSingle(obj, "service_disu_periods","")
      val solution = JSONUtil.getJsonValSingle(obj, "solution","")
      val plan_run_tm_state = JSONUtil.getJsonValSingle(obj, "plan_run_tm_state","")
      val plan_arrived_tm_state = JSONUtil.getJsonValSingle(obj, "plan_arrived_tm_state","")
      val latest_arrived_tm_state = JSONUtil.getJsonValSingle(obj, "latest_arrived_tm_state","")
      val jp_swid = JSONUtil.getJsonValSingle(obj, "jp_swid","")
      val jp_time = JSONUtil.getJsonValSingle(obj, "jp_time","")
      val sum_dist = JSONUtil.getJsonValSingle(obj, "sum_dist","")
      val task_type = JSONUtil.getJsonValSingle(obj, "task_type","")

      // 获取详情1新增字段
      val pick_up_tm_obj = JSONUtil.getJsonObjectMulti(obj, "pick_up_tm_obj")
      val case_obj = JSONUtil.getJsonObjectMulti(pick_up_tm_obj, pick_up_tm_i)
      val before_15min_moment = JSONUtil.getJsonValSingle(case_obj, "before_15min_moment","")
      val before_15min_service_label = JSONUtil.getJsonValSingle(case_obj, "before_15min_service_label","")
      val pick_up_tm_jiasu = JSONUtil.getJsonValSingle(case_obj, "pick_up_tm_jiasu","")
      val elimate_outlier = JSONUtil.getJsonValSingle(case_obj, "elimate_outlier","")
      val elimate_outlier_tm = JSONUtil.getJsonValSingle(case_obj, "elimate_outlier_tm","")
      val before_15min_dist = JSONUtil.getJsonValSingle(case_obj, "before_15min_dist","")
      val after_15min_dist = JSONUtil.getJsonValSingle(case_obj, "after_15min_dist","")
      val before_15min_total_dist = JSONUtil.getJsonValSingle(case_obj, "before_15min_total_dist","")
      val after_15min_total_dist = JSONUtil.getJsonValSingle(case_obj, "after_15min_total_dist","")
      val before_15min_time = JSONUtil.getJsonValSingle(case_obj, "before_15min_time","")
      val after_15min_time = JSONUtil.getJsonValSingle(case_obj, "after_15min_time","")
      val before_15min_duration = JSONUtil.getJsonValSingle(case_obj, "before_15min_duration","")
      val after_15min_duration = JSONUtil.getJsonValSingle(case_obj, "after_15min_duration","")
      val before_15min_swid = JSONUtil.getJsonValSingle(case_obj, "before_15min_swid","")
      val after_15min_swid = JSONUtil.getJsonValSingle(case_obj, "after_15min_swid","")
      val before_15min_speed = JSONUtil.getJsonValSingle(case_obj, "before_15min_speed","")
      val after_15min_speed = JSONUtil.getJsonValSingle(case_obj, "after_15min_speed","")

      // 新增按照swid去重后的dist相关字段
      val before_15min_dist2 = JSONUtil.getJsonValSingle(case_obj, "before_15min_dist2","")
      val before_15min_total_dist2 = JSONUtil.getJsonValSingle(case_obj, "before_15min_total_dist2","")
      val after_15min_dist2 = JSONUtil.getJsonValSingle(case_obj, "after_15min_dist2","")
      val after_15min_total_dist2 = JSONUtil.getJsonValSingle(case_obj, "after_15min_total_dist2","")

      // 获取两次路况接口返回字段
      val before_15min_lukuang_swid = JSONUtil.getJsonValSingle(obj, "before_15min_lukuang_swid","")
      val before_15min_lukuang_speed = JSONUtil.getJsonValSingle(obj, "before_15min_lukuang_speed","")
      val after_15min_lukuang_swid = JSONUtil.getJsonValSingle(obj, "after_15min_lukuang_swid","")
      val after_15min_lukuang_speed = JSONUtil.getJsonValSingle(obj, "after_15min_lukuang_speed","")

      // 获取两次匹配接口返回字段
      val before_15min_lukuang_length = JSONUtil.getJsonValSingle(obj, "before_15min_lukuang_length","")
      val after_15min_lukuang_length = JSONUtil.getJsonValSingle(obj, "after_15min_lukuang_length","")

      PickExplodeDF(pick_up_tm_i,task_subid,group2,pick_up_tm,accelarater_or_run,service_disu_label,service_disu_periods,solution,plan_run_tm_state,
        plan_arrived_tm_state,latest_arrived_tm_state,jp_swid,jp_time,sum_dist,task_type,before_15min_moment,before_15min_service_label,pick_up_tm_jiasu,elimate_outlier,
        elimate_outlier_tm,before_15min_dist,after_15min_dist,before_15min_total_dist,after_15min_total_dist,before_15min_time,after_15min_time,before_15min_duration,
        after_15min_duration,before_15min_swid,after_15min_swid,before_15min_speed,after_15min_speed,before_15min_lukuang_swid,before_15min_lukuang_speed,
        after_15min_lukuang_swid,after_15min_lukuang_speed,before_15min_lukuang_length,after_15min_lukuang_length,before_15min_dist2,before_15min_total_dist2,
        after_15min_dist2,after_15min_total_dist2)
    }).toDF()
      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    // 获取solution2等字段
    val df_solution2 = df_pick_explode
      .withColumn("group2_order", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm_i"))) - 1)
      .groupBy("group2")
      .agg(
        max(when('group2_order === 0,'accelarater_or_run).otherwise(null)) as "accelarater_or_run",
        max(when('group2_order === 0,'pick_up_tm).otherwise(null)) as "pick_up_tm",
        max(when('group2_order === 0,'solution).otherwise(null)) as "solution",
        max(when('group2_order === 0,'plan_arrived_tm_state).otherwise(null)) as "plan_arrived_tm_state",
        max(when('group2_order === 0,'latest_arrived_tm_state).otherwise(null)) as "latest_arrived_tm_state",
        max(when('group2_order === 0,'plan_run_tm_state).otherwise(null)) as "plan_run_tm_state",
        concat_ws("|",collect_list('elimate_outlier)) as "elimate_outlier2"
      )
      .withColumn("solution2",getStateAfterExcludingOutlier('elimate_outlier2,'accelarater_or_run,'pick_up_tm,'solution,lit("null"),lit("加速")))
      .withColumn("plan_arrived_tm_state2",getStateAfterExcludingOutlier('elimate_outlier2,'accelarater_or_run,'pick_up_tm,'plan_arrived_tm_state,lit("false"),lit("加速")))
      .withColumn("latest_arrived_tm_state2",getStateAfterExcludingOutlier('elimate_outlier2,'accelarater_or_run,'pick_up_tm,'latest_arrived_tm_state,lit("false"),lit("加速")))
      .withColumn("plan_run_tm_state2",getStateAfterExcludingOutlier('elimate_outlier2,'accelarater_or_run,'pick_up_tm,'plan_run_tm_state,lit("false"),lit("运行")))
      .select("group2","solution2","plan_arrived_tm_state2","latest_arrived_tm_state2","plan_run_tm_state2","elimate_outlier2")

    // 新增字段或者重新赋值
    val df_lukuang_speed = df_pick_explode
      .join(df_solution2,Seq("group2"),"left")
      .withColumn("pickup_tm_ycz_jiasu",concat_ws("_",'pick_up_tm_jiasu,'elimate_outlier))
      .withColumn("accelarater_or_run2",when('accelarater_or_run === "加速" and !('solution2.contains("加速方案")),"")
        .when('accelarater_or_run === "运行" and !('plan_run_tm_state2.contains("true")),"")
        .otherwise('accelarater_or_run))
      .withColumn("before_15min_each_swid_speed",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .otherwise(getSwidSpeed('before_15min_lukuang_length,'before_15min_lukuang_speed)))
      .withColumn("after_15min_each_swid_speed",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .otherwise(getSwidSpeed('after_15min_lukuang_length,'after_15min_lukuang_speed)))
      .withColumn("before_15min_total_duration",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .otherwise(sumSwidSpeed('before_15min_each_swid_speed)))
      .withColumn("after_15min_total_duration",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .otherwise(sumSwidSpeed('after_15min_each_swid_speed)))
      .withColumn("before_15min_aver_lukuang_speed",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .otherwise(('before_15min_total_dist2 * 0.001) / ('before_15min_total_duration / 60)))
      .withColumn("after_15min_aver_lukuang_speed",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .otherwise(('after_15min_total_dist2 * 0.001) / ('after_15min_total_duration / 60)))
      .withColumn("current_point_if_accelarate",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .when('after_15min_speed > ('before_15min_speed * 1.1),"true")
        .when('after_15min_speed <= ('before_15min_speed * 1.1),"false")
        .otherwise(""))
      .withColumn("current_point_if_lukuang_low",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .when('after_15min_speed > ('after_15min_aver_lukuang_speed * 0.8),"true")
        .when('after_15min_speed <= ('after_15min_aver_lukuang_speed * 0.8),"false")
        .otherwise(""))
      .withColumn("current_point_if_lukuang_change",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .when(('before_15min_aver_lukuang_speed > 'after_15min_aver_lukuang_speed) or (('after_15min_aver_lukuang_speed / 'before_15min_aver_lukuang_speed) >= 1 and ('after_15min_aver_lukuang_speed / 'before_15min_aver_lukuang_speed) <= 1.2),"true")
        .when(!('before_15min_aver_lukuang_speed > 'after_15min_aver_lukuang_speed) or (('after_15min_aver_lukuang_speed / 'before_15min_aver_lukuang_speed) >= 1 and ('after_15min_aver_lukuang_speed / 'before_15min_aver_lukuang_speed) <= 1.2),"false")
        .otherwise(""))
      .withColumn("current_point_if_conduct_accelerate",when('before_15min_swid.isNull or 'before_15min_swid === "","")
        .when('current_point_if_accelarate === "true" and 'current_point_if_lukuang_low === "true" and 'current_point_if_lukuang_change === "true","true")
        .when('current_point_if_accelarate =!= "true" or 'current_point_if_lukuang_low =!= "true" or 'current_point_if_lukuang_change =!= "true","false")
        .otherwise(""))
      .withColumn("elimate_outlier",'elimate_outlier_tm)
//      //20230315取消此处置空逻辑
//      .withColumn("before_15min_lukuang_swid",when('elimate_outlier === "",'before_15min_lukuang_swid).otherwise(""))
//      .withColumn("before_15min_lukuang_speed",when('elimate_outlier === "",'before_15min_lukuang_speed).otherwise(""))
//      .withColumn("after_15min_lukuang_swid",when('elimate_outlier === "",'after_15min_lukuang_swid).otherwise(""))
//      .withColumn("after_15min_lukuang_speed",when('elimate_outlier === "",'after_15min_lukuang_speed).otherwise(""))
      .withColumn("inc_day",lit(dayBefore1))
      .coalesce(50)

    // 保存数据
    if(flag.equals("eta")){
      val res_cols = spark.sql(s"""select * from dm_gis.lukuang_speed limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_lukuang_speed.select(res_cols: _*),Seq("inc_day"),"dm_gis.lukuang_speed")
    }else if(flag.equals("navi")){
      val res_cols = spark.sql(s"""select * from dm_gis.lukuang_speed_navi limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_lukuang_speed.select(res_cols: _*),Seq("inc_day"),"dm_gis.lukuang_speed_navi")
    }

    //rdd_pick_explode.unpersist()
    df_pick_explode.unpersist()
  }
}
