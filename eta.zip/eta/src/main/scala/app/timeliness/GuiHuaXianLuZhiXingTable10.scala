package app.timeliness

import Utils.SparkUtils.writeToHive
import app.timeliness.Functions.{sortField, stdCoordsToPoints2}
import app.timeliness.JiuPianFwqTable45.{runIntegrateInteface, runRectifyInteface}
import app.timeliness.TimeLinessObj.XianLuZhiXingDF
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, DateUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

import java.text.SimpleDateFormat
import scala.collection.mutable.ArrayBuffer

// 挽救重新规划线路方案任务明细表,表10和表11逻辑
object GuiHuaXianLuZhiXingTable10 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
//  val Integrate_URL: String = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
  val Integrate_URL: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"  // 新轨迹中台迁移 20230821
  val Integrate_AK: String = "87a1347bc3944718911a05c21ec888a9"
  val Rectify_URL: String = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
  val Rectify_AK: String = "87a1347bc3944718911a05c21ec888a9"
  val Comparetracks_URL: String = "http://gis-int2.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"
  val Comparetracks_AK: String = "87a1347bc3944718911a05c21ec888a9"
  val parallelism = 20
  val akMinuLimit = 1000

  /**
   * 解析相似度接口返回值
   * @param ret
   * @return
   */
  def parseComparetracksHttpData(ret: JSONObject): (String, String, String, String) = {
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getString("msg")
        logger.error("获取接口数据失败: " + msg)
        return (codeStatue, msg, null, null)
      } else {
        var similarity1 = ""
        var similarity2 = ""
        try{
          similarity1 = ret.getJSONObject("result").getString("similarity1")
          similarity2 = ret.getJSONObject("result").getString("similarity2")
        }catch {
          case e: Exception => logger.error(e)
        }
        return (codeStatue, "成功", similarity1, similarity2)
      }
    }
    ("22", "请求失败,接口返回值为空", null, null)
  }

  /**
   * 调相似度接口
   * @param ak
   * @param obj
   * @return
   */
  def runComparetracksInteface(ak:String, obj: JSONObject): JSONObject = {
    val plan_coords = JSONUtil.getJsonVal(obj, "plan_coords", "")
    val his_coords = JSONUtil.getJsonVal(obj, "his_coords", "")
    val plan_coords_arr = plan_coords.split("\\|")
    val his_coords_arr = his_coords.split("\\|")

    val tracks1 = new JSONArray()
    for(i <- 0 until plan_coords_arr.length){
      var x = 0.0
      var y = 0.0
      try {
        x = plan_coords_arr(i).split(",")(0).toDouble
        y = plan_coords_arr(i).split(",")(1).toDouble
      } catch {
        case e: Exception => logger.error(e)
      }
      val track = new JSONObject()
      track.put("type",1)
      track.put("x",x)
      track.put("y",y)
      tracks1.add(track)
    }

    val tracks2 = new JSONArray()
    for(i <- 0 until his_coords_arr.length){
      var x = 0.0
      var y = 0.0
      try {
        x = his_coords_arr(i).split(",")(0).toDouble
        y = his_coords_arr(i).split(",")(1).toDouble
      } catch {
        case e: Exception => logger.error(e)
      }
      val track = new JSONObject()
      track.put("type",1)
      track.put("x",x)
      track.put("y",y)
      tracks2.add(track)
    }

    //初始化接口请求参数
    val param = new JSONObject()
    param.put("ak", ak)
    param.put("vehicle", 6)
    param.put("retflag", 1)
    param.put("tracktype", 0)
    param.put("tracks1", tracks1)
    param.put("tracks2", tracks2)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = HttpInvokeUtil.sendPost(Comparetracks_URL,param.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析接口返回值
    val httpData: (String,String,String,String) = parseComparetracksHttpData(retJSONObject)
    obj.put("sim_plan",httpData._3)
    obj.put("sim_his",httpData._4)
    obj
  }

  /**
   * 获取两个经纬度之前的直线距离
   * @param longitude1
   * @param latitude1
   * @param longitude2
   * @param latitude2
   * @return s 单位：千米
   */
  def getDistance2(longitude1: Double, latitude1: Double, longitude2: Double, latitude2: Double): Double = {
    //地球半径
    val R = 6371.00
    // 纬度
    val lat1: Double = Math.toRadians(latitude1)
    val lat2: Double = Math.toRadians(latitude2)
    // 经度
    val lng1: Double = Math.toRadians(longitude1)
    val lng2: Double = Math.toRadians(longitude2)
    // 纬度之差
    val a: Double = lat1 - lat2
    // 经度之差
    val b: Double = lng1 - lng2
    // 计算两点距离的公式
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
    // 弧长乘地球半径, 返回单位: 千米
    s = s * R
    s
  }

  /**
   * 从表1 取数
   * @param spark
   * @param dayBefore1
   * @param flag
   * @return
   */
  def getKafkaRecallRequestDetail(spark: SparkSession, dayBefore1: String, flag: String) = {
    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  group2
           |  ,task_id
           |  ,sort_num
           |  ,task_subid
           |  ,actual_depart_tm
           |  ,actual_arrive_tm
           |  ,pick_up_tm
           |  ,pick_up_tm2
           |  ,arrival_tm
           |  ,vehicle_serial
           |  ,dest_zone_code
           |  ,dest_zone_coordinate
           |  ,src_zone_code
           |  ,source
           |  ,concat_ws('_',task_id,dest_zone_code) as group6
           |  ,uid
           |  ,solution
           |  ,type
           |  ,isselectedsaveplan
           |  ,remain_distance
           |  ,remain_time
           |  ,pick_up_point
           |from
           |  dm_gis.kafka_recall_request_detail
           |where
           |  inc_day = '$dayBefore1'
           |  and solution = '重新规划线路'
           |  and type = 3
           |  and isselectedsaveplan = 1
           |""".stripMargin
    }else if(flag.equals("navi")){
      querySql =
        s"""
           |select
           |  group2
           |  ,task_id
           |  ,sort_num
           |  ,task_subid
           |  ,actual_depart_tm
           |  ,actual_arrive_tm
           |  ,pick_up_tm
           |  ,pick_up_tm2
           |  ,arrival_tm
           |  ,vehicle_serial
           |  ,dest_zone_code
           |  ,dest_zone_coordinate
           |  ,src_zone_code
           |  ,source
           |  ,concat_ws('_',task_id,dest_zone_code) as group6
           |  ,uid
           |  ,solution
           |  ,type
           |  ,isselectedsaveplan
           |  ,remain_distance
           |  ,remain_time
           |  ,pick_up_point
           |from
           |  dm_gis.kafka_recall_request_detail
           |where
           |  inc_day = '$dayBefore1'
           |  and solution = '重新规划线路'
           |  and type = 3
           |  and isselectedsaveplan = 1
           |  and source = 'navi'
           |""".stripMargin
    }
    println(querySql)
    val df_request_detail = spark.sql(querySql)
    df_request_detail
  }

  /**
   * 获取eta轨迹数据
   * @param spark
   * @param dayBefore1
   * @param dayBefore3
   * @return
   */
  def getGisEtaQueryLog(spark: SparkSession, dayBefore1: String, dayBefore3: String) = {
    val eta_track_querySql =
      s"""
         |select
         |  get_json_object(get_json_object(get_json_object(log,'$$.data'),'$$.arg'),'$$.taskId') taskId
         |  ,get_json_object(get_json_object(get_json_object(log,'$$.data'),'$$.arg'),'$$.srcZoneId') srcZoneId
         |  ,get_json_object(get_json_object(get_json_object(log,'$$.data'),'$$.arg'),'$$.destZoneId') destZoneId
         |  ,get_json_object(get_json_object(get_json_object(log,'$$.data'),'$$.result'),'$$.points') points
         |  ,get_json_object(log,'$$.reqId') reqId
         |  ,get_json_object(log, '$$.subType') sub_type
         |from
         |  dm_gis.gis_eta_query_log
         |where
         |  inc_day >= '$dayBefore3'
         |  and inc_day <= '$dayBefore1'
         |  and get_json_object(log, '$$.subType') in ('queryByFuse','queryLocationEta')
         |  and get_json_object(log, '$$.type') = 'etaQuery'
         |  and get_json_object(get_json_object(get_json_object(log, '$$.data'), '$$.arg'),'$$.taskId') in
         |  (
         |    select
         |      task_id
         |    from
         |      dm_gis.kafka_recall_request_detail
         |    where
         |      inc_day = '$dayBefore1'
         |      and solution = '重新规划线路'
         |      and type = 3
         |      and isselectedsaveplan = 1
         |      and source = 'eta'
         |    group by
         |      task_id
         |  )
         |""".stripMargin
    println(eta_track_querySql)
    val df_eta_track = spark.sql(eta_track_querySql)
    df_eta_track
  }

  /**
   * 获取导航轨迹数据
   * @param spark
   * @param incDay
   * @param dayBefore1
   * @param dayBefore3
   * @param dayBefore4
   * @return
   */
  def getGisEtaNaviQueryHive(spark: SparkSession, incDay: String, dayBefore1: String, dayBefore3: String, dayBefore4: String) = {
    val navi_track_querySql =
      s"""
         |select
         |  *
         |from
         |  (
         |    select
         |      get_json_object(get_json_object(data,'$$.data'),'$$.taskId') task_id,
         |      get_json_object(get_json_object(data,'$$.data'),'$$.reportTime') reporttime,
         |      get_json_object(get_json_object(get_json_object(get_json_object(data,'$$.data'),'$$.operateInfo'),'$$.content'),'$$.routeId') routeid,
         |      get_json_object(get_json_object(data,'$$.data'),'$$.curStartDept') src_zone_code,
         |      get_json_object(get_json_object(get_json_object(get_json_object(data,'$$.data'),'$$.operateInfo'),'$$.content'),'$$.destDeptCode') dest_zone_code,
         |      get_json_object(get_json_object(get_json_object(get_json_object(data,'$$.data'),'$$.operateInfo'),'$$.content'),'$$.preArriveTime') arrival_tm
         |    from
         |      dm_gis.gis_eta_navi_query_hive
         |    where
         |      inc_day >= '$dayBefore3'
         |      and inc_day <= '$dayBefore1'
         |      and get_json_object(data, '$$.subType') = 'sdkNaviLog'
         |      and get_json_object(get_json_object(data, '$$.data'), '$$.type') = '26'
         |      and get_json_object(get_json_object(data, '$$.data'), '$$.taskId') in (
         |        select
         |          task_id
         |        from
         |          dm_gis.kafka_recall_request_detail
         |        where
         |          inc_day = '$dayBefore1'
         |          and solution = '重新规划线路'
         |          and type = 3
         |          and isselectedsaveplan = 1
         |          and source = 'navi'
         |        group by
         |          task_id
         |      )
         |  ) a
         |  left join (
         |    select
         |      routeid,
         |      polyline
         |    from
         |      dm_gis.gis_navi_top3_yaw_result_parse
         |    where
         |      inc_day >= '$dayBefore4'
         |      and inc_day <= '$incDay'
         |  ) b on a.routeid = b.routeid
         |where
         |  b.routeid != ''
         |""".stripMargin
    println(navi_track_querySql)
    val df_navi_track = spark.sql(navi_track_querySql)
    df_navi_track
  }

  def runGuiHuaXianLuZhiXing(spark: SparkSession, incDay: String, flag: String) = {

    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val dayBefore4 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 4)

    import spark.implicits._
    // 生产环境取数
    val df_request_detail = getKafkaRecallRequestDetail(spark,dayBefore1,flag)
    val df_eta_track = getGisEtaQueryLog(spark,dayBefore1,dayBefore3)
    val df_navi_track = getGisEtaNaviQueryHive(spark,incDay,dayBefore1,dayBefore3,dayBefore4)

    // 将导航轨迹数据按照"task_id","dest_zone_code"分组，并按顺序收集
    val df_navi_track_group = df_navi_track
      .withColumn("num", row_number().over(Window.partitionBy('task_id,'dest_zone_code).orderBy(asc("reporttime"))))
      // 空值处理，方便分组收集后排序操作
      .withColumn("reporttime",when('reporttime.isNull,"null").otherwise('reporttime))
      .withColumn("polyline",when('polyline.isNull,"null").otherwise('polyline))
      .withColumn("arrival_tm_2",when('arrival_tm.isNull,"null").otherwise('arrival_tm))
      .groupBy("task_id","dest_zone_code")
      .agg(
        // 分组内的字段的全部值用|拼接
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('reporttime)) as "reporttime",
        concat_ws("|",collect_list('polyline)) as "polyline",
        concat_ws("|",collect_list('arrival_tm_2)) as "arrival_tm_2"
      )
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("reporttime",sortField('num,'reporttime))
      .withColumn("polyline",sortField('num,'polyline))
      .withColumn("arrival_tm_2",sortField('num,'arrival_tm_2))
      .drop("num")

    // 表1详情数据关联eta和导航数据
    val df_request_detail_join = df_request_detail.alias("df_request_detail")
      .join(df_eta_track.alias("df_eta_track"),expr("df_request_detail.uid = df_eta_track.reqId"),"left")
      .join(df_navi_track_group,Seq("task_id","dest_zone_code"),"left")
      //.persist(StorageLevel.MEMORY_ONLY_SER_2)

    // 获取，每个pick_up_tm2最接近的导航轨迹
    val rdd_request_detail_join: RDD[JSONObject] = SparkUtils.getDfToJson(spark,df_request_detail_join)
    var rdd_pick_nearest = rdd_request_detail_join.repartition(2000).map(obj=>{
      val pick_up_tm2 = JSONUtil.getJsonValInt(obj, "pick_up_tm2",0).toLong
      val reporttime = JSONUtil.getJsonValSingle(obj, "reporttime","")
      val polyline = JSONUtil.getJsonValSingle(obj, "polyline","")
      val arrival_tm_2 = JSONUtil.getJsonValSingle(obj, "arrival_tm_2","")
      val source = JSONUtil.getJsonValSingle(obj, "source","")
      val points = JSONUtil.getJsonValSingle(obj, "points","")

      val reporttime_arr = reporttime.split("\\|")
      val polyline_arr = polyline.split("\\|")
      val arrival_tm_2_arr = arrival_tm_2.split("\\|")

      var diff_min = Int.MaxValue
      var index = 0
      for(i <- 0 until reporttime_arr.length){
        var reporttime_i = 0L
        try {
          reporttime_i = reporttime_arr(i).toLong
        } catch {
          case e: Exception => logger.error(e)
        }
        val diff = ((pick_up_tm2 * 1000) - reporttime_i).abs.toInt
        if(diff_min > diff &&  diff != 0.0) {
          diff_min = diff
          index = i
        }
      }
      val nearest_report_tm_navi = reporttime_arr(index)
      var nearest_report_tm_navi2 = ""
      try {
        nearest_report_tm_navi2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(nearest_report_tm_navi.toLong)
      } catch {
        case e: Exception => logger.error(e)
      }
      val nearest_polyline = stdCoordsToPoints2(polyline_arr(index))
      val nearest_arrival_tm = arrival_tm_2_arr(index)
      var points_merge = ""

      if(source.equals("eta")){
        points_merge = points
      }else if(source.equals("navi")){
        points_merge = nearest_polyline
      }

      obj.put("nearest_report_tm_navi",nearest_report_tm_navi)
      obj.put("nearest_report_tm_navi2",nearest_report_tm_navi2)
      obj.put("nearest_polyline",nearest_polyline)
      obj.put("nearest_arrival_tm",nearest_arrival_tm)
      obj.put("points_merge",points_merge)
      obj
    })
    val invokeCnt_1 = rdd_pick_nearest.count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "574498", "时效预警And挽救指标体系", "获取历史轨迹", Integrate_URL, Integrate_AK, invokeCnt_1, parallelism)
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "574498", "时效预警And挽救指标体系", "轨迹纠偏", Rectify_URL, Rectify_AK, invokeCnt_1, parallelism)
    // 调用调历史轨迹接口和轨迹纠偏接口
    rdd_pick_nearest = SparkNet.runInterfaceWithAkLimit(spark, rdd_pick_nearest, runIntegrateInteface, parallelism, Integrate_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    // 详情3逻辑，获取轨迹
    var rdd_pick_xiangqing3 = rdd_pick_nearest.repartition(2000).map(obj=>{
      val pick_up_point = JSONUtil.getJsonValSingle(obj, "pick_up_point","")
      val points_merge = JSONUtil.getJsonValSingle(obj, "points_merge","")
      val jp_coords = JSONUtil.getJsonValSingle(obj, "jp_coords","")
      val sum_dist = JSONUtil.getJsonValSingle(obj, "sum_dist","")

      var x1 = 0.0
      var y1 = 0.0
      try {
        x1 = pick_up_point.split(",")(0).toDouble
        y1 = pick_up_point.split(",")(1).toDouble
      } catch {
        case e: Exception => logger.error(e)
      }
      val points_merge_arr = points_merge.split("\\|")
      val jp_coords_arr = jp_coords.split("\\|")
      val sum_dist_arr = sum_dist.split("\\|")

      var dist1_min = Double.MaxValue
      var dist2_min = Double.MaxValue
      var index1 = 0
      var index2 = 0
      for(i <- 0 until points_merge_arr.length){
        val points_merge_i = points_merge_arr(i)
        var x2 = 0.0
        var y2 = 0.0
        try {
          x2 = points_merge_i.split(",")(0).toDouble
          y2 = points_merge_i.split(",")(1).toDouble
        } catch {
          case e: Exception => logger.error(e)
        }
        val dist = getDistance2(x1, y1, x2, y2)
        if(dist1_min > dist &&  dist != 0.0) {
          dist1_min = dist
          index1 = i
        }
      }

      for(j <- 0 until jp_coords_arr.length){
        val jp_coords_i = jp_coords_arr(j)
        var x2 = 0.0
        var y2 = 0.0
        try {
          x2 = jp_coords_i.split(",")(0).toDouble
          y2 = jp_coords_i.split(",")(1).toDouble
        } catch {
          case e: Exception => logger.error(e)
        }
        val dist = getDistance2(x1, y1, x2, y2)
        if(dist2_min > dist ) {
          dist2_min = dist
          index2 = j
        }
      }
      val plan_coords_arr = new ArrayBuffer[String]()
      for(i <- index1 until points_merge_arr.length){
        plan_coords_arr.append(points_merge_arr(i))
      }
      val plan_coords = plan_coords_arr.mkString("|")

      val his_coords_arr = new ArrayBuffer[String]()
      for(i <- index2 until jp_coords_arr.length){
        his_coords_arr.append(jp_coords_arr(i))
      }
      val his_coords = his_coords_arr.mkString("|")
      val his_dist =
        try {
          sum_dist_arr(sum_dist_arr.length - 1).toDouble - sum_dist_arr(index2).toDouble
        } catch {
          case e: Exception => logger.error(e)
        }

      obj.put("plan_coords",plan_coords)
      obj.put("his_coords",his_coords)
      obj.put("his_dist",his_dist)
      obj
    })

    val invokeCnt_3 = rdd_pick_xiangqing3.count()
    val httpInvokeId_3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "574498", "时效预警And挽救指标体系", "相似度对比", Comparetracks_URL, Comparetracks_AK, invokeCnt_3, parallelism)
    // 调相似度接口
    rdd_pick_xiangqing3 = SparkNet.runInterfaceWithAkLimit(spark, rdd_pick_xiangqing3, runComparetracksInteface, parallelism, Comparetracks_AK, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_3)

    val df_xianlu_zhixing = rdd_pick_xiangqing3.repartition(2000).map(obj=>{
      val group2 = JSONUtil.getJsonValSingle(obj, "group2","")
      val task_id = JSONUtil.getJsonValSingle(obj, "task_id","")
      val sort_num = JSONUtil.getJsonValSingle(obj, "sort_num","")
      val task_subid = JSONUtil.getJsonValSingle(obj, "task_subid","")
      val actual_depart_tm = JSONUtil.getJsonValSingle(obj, "actual_depart_tm","")
      val actual_arrive_tm = JSONUtil.getJsonValSingle(obj, "actual_arrive_tm","")
      val pick_up_tm = JSONUtil.getJsonValSingle(obj, "pick_up_tm","")
      val pick_up_tm2 = JSONUtil.getJsonValSingle(obj, "pick_up_tm2","")
      val arrival_tm = JSONUtil.getJsonValSingle(obj, "arrival_tm","")
      val vehicle_serial = JSONUtil.getJsonValSingle(obj, "vehicle_serial","")
      val dest_zone_code = JSONUtil.getJsonValSingle(obj, "dest_zone_code","")
      val dest_zone_coordinate = JSONUtil.getJsonValSingle(obj, "dest_zone_coordinate","")
      val src_zone_code = JSONUtil.getJsonValSingle(obj, "src_zone_code","")
      val source = JSONUtil.getJsonValSingle(obj, "source","")
      val group6 = JSONUtil.getJsonValSingle(obj, "group6","")
      val uid = JSONUtil.getJsonValSingle(obj, "uid","")
      val solution = JSONUtil.getJsonValSingle(obj, "solution","")
      val `type` = JSONUtil.getJsonValSingle(obj, "type","")
      val isselectedsaveplan = JSONUtil.getJsonValSingle(obj, "isselectedsaveplan","")
      val remain_distance = JSONUtil.getJsonDouble(obj, "remain_distance",0.0)
      val remain_time  = JSONUtil.getJsonValSingle(obj, "remain_time","")
      val pick_up_point = JSONUtil.getJsonValSingle(obj, "pick_up_point","")
      val reqid = JSONUtil.getJsonValSingle(obj, "reqId","")
      val points = JSONUtil.getJsonValSingle(obj, "points","")
      val nearest_report_tm_navi = JSONUtil.getJsonValSingle(obj, "nearest_report_tm_navi","")
      val nearest_report_tm_navi2 = JSONUtil.getJsonValSingle(obj, "nearest_report_tm_navi2","")
      val nearest_polyline = JSONUtil.getJsonValSingle(obj, "nearest_polyline","")
      val nearest_arrival_tm = JSONUtil.getJsonValSingle(obj, "nearest_arrival_tm","")
      val points_merge = JSONUtil.getJsonValSingle(obj, "points_merge","")
      val jp_coords = JSONUtil.getJsonValSingle(obj, "jp_coords","")
      val sum_dist = JSONUtil.getJsonValSingle(obj, "sum_dist","")
      val plan_coords = JSONUtil.getJsonValSingle(obj, "plan_coords","")
      val his_coords = JSONUtil.getJsonValSingle(obj, "his_coords","")
      val his_dist = JSONUtil.getJsonValSingle(obj, "his_dist","")
      val sim_plan = JSONUtil.getJsonDouble(obj,"sim_plan",0.0)
      val sim_his = JSONUtil.getJsonDouble(obj, "sim_his",0.0)
      val sub_type = JSONUtil.getJsonValSingle(obj, "sub_type","")

      // 详情5,判断是否执行
      var if_conduct_replanline = "false"
      if(remain_distance > 500){
        if((sim_plan >= 0.9 || sim_his >= 0.9) && (sim_plan > 0.85 && sim_his > 0.85)){
          if_conduct_replanline = "true"
        }
      }else if(remain_distance > 100 && remain_distance <= 500){
        if((sim_plan >= 0.85 || sim_his >= 0.85) && (sim_plan > 0.8 && sim_his > 0.8)){
          if_conduct_replanline = "true"
        }
      }else if(remain_distance > 50 && remain_distance <= 100){
        if((sim_plan >= 0.8 || sim_his >= 0.8) && (sim_plan > 0.75 && sim_his > 0.75)){
          if_conduct_replanline = "true"
        }
      }else if(remain_distance > 0 && remain_distance <= 50){
        if((sim_plan >= 0.75 || sim_his >= 0.75) && (sim_plan > 0.7 && sim_his > 0.7)){
          if_conduct_replanline = "true"
        }
      }
      XianLuZhiXingDF(group2,task_id,sort_num,task_subid,actual_depart_tm,actual_arrive_tm,pick_up_tm,pick_up_tm2,arrival_tm,vehicle_serial
        ,dest_zone_code,dest_zone_coordinate,src_zone_code,source,group6,uid,solution,`type`,isselectedsaveplan,remain_distance,remain_time
        ,pick_up_point,reqid,points,nearest_report_tm_navi,nearest_report_tm_navi2,nearest_polyline,nearest_arrival_tm,points_merge,jp_coords
        ,sum_dist,plan_coords,his_coords,his_dist,sim_plan,sim_his,if_conduct_replanline,sub_type)
    }).toDF()
      .withColumn("nearest_report_tm_navi",when('source === "navi",'nearest_report_tm_navi).otherwise(""))
      .withColumn("nearest_report_tm_navi2",when('source === "navi",'nearest_report_tm_navi2).otherwise(""))
      .withColumn("nearest_polyline",when('source === "navi",'nearest_polyline).otherwise(""))
      .withColumn("nearest_arrival_tm",when('source === "navi",'nearest_arrival_tm).otherwise(""))
      .withColumn("inc_day",lit(dayBefore1))
      .coalesce(50)

    // 保存数据
    if(flag.equals("eta")){
      val res_cols = spark.sql("""select * from dm_gis.guihua_xianlu_zhixing limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_xianlu_zhixing.select(res_cols: _*),Seq("inc_day"),"dm_gis.guihua_xianlu_zhixing")
    }else if(flag.equals("navi")){
      val res_cols = spark.sql("""select * from dm_gis.guihua_xianlu_zhixing_navi limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_xianlu_zhixing.select(res_cols: _*),Seq("inc_day"),"dm_gis.guihua_xianlu_zhixing_navi")
    }

//    df_request_detail_join.unpersist()

  }
}
