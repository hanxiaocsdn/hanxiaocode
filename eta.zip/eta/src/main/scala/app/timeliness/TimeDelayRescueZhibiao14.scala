package app.timeliness

import Utils.SparkUtils.writeToHive
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

// 指标监控统计表，表14和表15逻辑
object TimeDelayRescueZhibiao14 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )


  def getEtaAndNaviZhibiao(spark: SparkSession,dayBefore1: String,flag: String) = {
    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("全部")){
      querySql =
        s"""
           |select
           |  *
           |from
           |  dm_gis.time_delay_rescue
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("导航")){
      querySql =
        s"""
           |select
           |  *
           |from
           |  dm_gis.time_delay_rescue_navi
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  *
           |from
           |  dm_gis.time_delay_rescue
           |where
           |  inc_day = '$dayBefore1'
           |  and task_type = 'eta'
           |""".stripMargin
    }

    println(querySql)
    val df_delay_rescue = spark.sql(querySql)

    import spark.implicits._
    val df_delay_rescue_plan = df_delay_rescue
      .withColumn("if_actual_delay",when('if_plan_delay === 1,"准点").otherwise("晚点"))
      .withColumn("type_delay",lit("计划到车晚点"))
      .withColumn("num_transoport_level",count("task_subid")
        .over(Window.partitionBy("transoport_level")))
      .withColumn("num_if_actual_delay",count("task_subid")
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_delay_warn_outlier",count(when('ifdelay_plan_arrived_tm_state === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_outlier",count(when('ifdelay_plan_arrived_tm_state === "true" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案"),"task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_conduct",count(when('ifdelay_plan_arrived_tm_state === "true" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案") and 'if_conduct === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_outlier",count(when('ifdelay_plan_arrived_tm_state === "true" and 'if_rescue_plan_outlier === "重新规划线路方案","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_conduct",count(when('ifdelay_plan_arrived_tm_state === "true" and 'if_rescue_plan_outlier === "重新规划线路方案" and 'if_conduct === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_outlier",count(when('ifdelay_plan_arrived_tm_state === "true" and 'if_rescue_plan_outlier =!= "没有挽救方案","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_conduct_outlier",count(when('ifdelay_plan_arrived_tm_state === "true" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .groupBy("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")
      .agg(count('task_subid) as "tmp")
      .select("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")

    val df_delay_rescue_latest = df_delay_rescue
      .withColumn("if_actual_delay",when('if_latest_delay === 1,"准点").otherwise("晚点"))
      .withColumn("type_delay",lit("最晚到车晚点"))
      .withColumn("num_transoport_level",count("task_subid")
        .over(Window.partitionBy("transoport_level")))
      .withColumn("num_if_actual_delay",count(when('if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_delay_warn_outlier",count(when('ifdelay_latest_arrived_tm_state === "true" and 'if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_outlier",count(when('ifdelay_latest_arrived_tm_state === "true" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案") and 'if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_conduct",count(when('ifdelay_latest_arrived_tm_state === "true" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案") and 'if_conduct === "true" and 'if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_outlier",count(when('ifdelay_latest_arrived_tm_state === "true" and 'if_rescue_plan_outlier === "重新规划线路方案" and 'if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_conduct",count(when('ifdelay_latest_arrived_tm_state === "true" and 'if_rescue_plan_outlier === "重新规划线路方案" and 'if_conduct === "true" and 'if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_outlier",count(when('ifdelay_latest_arrived_tm_state === "true" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_conduct_outlier",count(when('ifdelay_latest_arrived_tm_state === "true" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "true" and 'if_latest_null_delay === "否","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .groupBy("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")
      .agg(count('task_subid) as "tmp")
      .select("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")

    val df_delay_run_latest = df_delay_rescue
      .withColumn("if_actual_delay",when('ac_is_run_ontime === 1,"准点").otherwise("晚点"))
      .withColumn("type_delay",lit("运行时长晚点"))
      .withColumn("num_transoport_level",count("task_subid")
        .over(Window.partitionBy("transoport_level")))
      .withColumn("num_if_actual_delay",count("task_subid")
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_delay_warn_outlier",count(when('ifdelay_plan_run_tm_state === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_outlier",count(when('ifdelay_plan_run_tm_state === "true" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案"),"task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_conduct",count(when('ifdelay_plan_run_tm_state === "true" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案") and 'if_conduct === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_outlier",count(when('ifdelay_plan_run_tm_state === "true" and 'if_rescue_plan_outlier === "重新规划线路方案","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_conduct",count(when('ifdelay_plan_run_tm_state === "true" and 'if_rescue_plan_outlier === "重新规划线路方案" and 'if_conduct === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_outlier",count(when('ifdelay_plan_run_tm_state === "true" and 'if_rescue_plan_outlier =!= "没有挽救方案","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_conduct_outlier",count(when('ifdelay_plan_run_tm_state === "true" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "true","task_subid").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .groupBy("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")
      .agg(count('task_subid) as "tmp")
      .select("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")

    var df_delay_rescue_res = df_delay_rescue_plan
      .union(df_delay_rescue_latest)
      .union(df_delay_run_latest)

//    // 如果是导航数据，则再增加一种晚点类型
//    if(flag.equals("导航")){
//      df_delay_rescue_res = df_delay_rescue_res.union(df_delay_run_latest)
//    }

    val df_quanbu = df_delay_rescue_res
      .groupBy("type_delay", "if_actual_delay")
      .agg(
        sum('num_transoport_level) as "num_transoport_level",
        sum('num_if_actual_delay) as "num_if_actual_delay",
        sum('num_delay_warn_outlier) as "num_delay_warn_outlier",
        sum('num_accelerate_outlier) as "num_accelerate_outlier",
        sum('num_accelerate_conduct) as "num_accelerate_conduct",
        sum('num_replanline_outlier) as "num_replanline_outlier",
        sum('num_replanline_conduct) as "num_replanline_conduct",
        sum('num_save_plan_outlier) as "num_save_plan_outlier",
        sum('num_save_plan_conduct_outlier) as "num_save_plan_conduct_outlier"
      )
      .withColumn("transoport_level", lit("全部"))
      .select("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")

    df_delay_rescue_res = df_delay_rescue_res
      .union(df_quanbu)
      .withColumn("ratio_num_if_actual_delay",'num_if_actual_delay / 'num_transoport_level)
      .withColumn("ratio_num_delay_warn_outlier",'num_delay_warn_outlier / 'num_if_actual_delay)
      .withColumn("ratio_num_accelerate_conduct_outlier",'num_accelerate_conduct / 'num_accelerate_outlier)
      .withColumn("ratio_num_replanline_conduct_outlier",'num_replanline_conduct / 'num_replanline_outlier)
      .withColumn("ratio_num_save_plan_outlier",'num_save_plan_outlier / 'num_delay_warn_outlier)
      .withColumn("ratio_num_save_plan_conduct_outlier",'num_save_plan_conduct_outlier / 'num_save_plan_outlier)
      .withColumn("navi_type",lit(flag))
      .withColumn("inc_day",lit(dayBefore1))

    df_delay_rescue_res
  }

  def runTimeDelayRescueZhibiao(spark: SparkSession, dayBefore1: String) = {

    // 获取统计指标
    val df_zhibiao_qb = getEtaAndNaviZhibiao(spark,dayBefore1,"全部")
    val df_zhibiao_navi = getEtaAndNaviZhibiao(spark,dayBefore1,"导航")
    val df_zhibiao_eta = getEtaAndNaviZhibiao(spark,dayBefore1,"eta")

    // 全部指标和导航指标合并
    val df_delay_rescue_res = df_zhibiao_qb
      .union(df_zhibiao_navi)
      .union(df_zhibiao_eta)

    // 表14数据存入hive
    val res_cols_14 = spark.sql(s"""select * from dm_gis.time_delay_rescue_zhibiao limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_delay_rescue_res.select(res_cols_14: _*),Seq("inc_day"),"dm_gis.time_delay_rescue_zhibiao")

    import spark.implicits._
    val df_tasksub_zhibiao = df_delay_rescue_res
      .groupBy("type_delay","transoport_level","navi_type")
      .agg(
        sum(when('if_actual_delay === "准点",'num_transoport_level).otherwise(0)) as "num_transoport_level",
        sum(when('if_actual_delay === "晚点",'num_if_actual_delay).otherwise(0)) as "num_if_actual_delay",
        sum('num_delay_warn_outlier) as "num_delay_warn",
        sum(when('if_actual_delay === "晚点",'num_delay_warn_outlier).otherwise(0)) as "num_delay_warn_actual_delay",
        sum(when('if_actual_delay === "晚点",'num_save_plan_outlier).otherwise(0)) as "num_delay_warn_actual_delay_save_plan",
        sum('num_save_plan_outlier) as "num_save_plan",
        sum('num_save_plan_conduct_outlier) as "num_save_plan_conduct",
        sum(when('if_actual_delay === "准点",'num_save_plan_conduct_outlier).otherwise(0)) as "num_success"
      )
      .withColumn("inc_day",lit(dayBefore1))

    // 表15数据存入hive
    val res_cols_15 = spark.sql(s"""select * from dm_gis.tasksub_zhibiao limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_tasksub_zhibiao.select(res_cols_15: _*),Seq("inc_day"),"dm_gis.tasksub_zhibiao")

  }
}
