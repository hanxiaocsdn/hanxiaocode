package app.timeliness

import Utils.SparkUtils.writeToHive
import app.timeliness.Functions.sortField
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

// 导航数据任务明细，表3逻辑
object KafkaRecallTaskDetailNaviTable3 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def runKafkaRecallTaskDetailNavi(spark: SparkSession, dayBefore1: String) = {

    // 从明细表获取数据
    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.kafka_recall_request_detail
         |where
         |  inc_day = '${dayBefore1}'
         |""".stripMargin

    println(querySql)
    val requestDetailDF = spark.sql(querySql)

    // 从明细表获取数据
    val table2_querySql =
      s"""
         |select
         |  group2,
         |  total_count,
         |  navi_count_ratio,
         |  task_type
         |from
         |  dm_gis.kafka_recall_task_detail
         |where
         |  inc_day = '${dayBefore1}'
         |  and task_type = '导航'
         |""".stripMargin

    println(table2_querySql)
    val taskDetailDF = spark.sql(table2_querySql)

    import spark.implicits._
    val taskDetailNaviDF = requestDetailDF
      .filter('order === 0 and 'source === "navi")
      .withColumn("group2_order", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm2"))) - 1)
      // 空值处理，方便分组收集后排序操作
      .withColumn("plan_arrived_tm_state",when('plan_arrived_tm_state.isNull,"null").otherwise('plan_arrived_tm_state))
      .withColumn("latest_arrived_tm_state",when('latest_arrived_tm_state.isNull,"null").otherwise('latest_arrived_tm_state))
      .withColumn("plan_run_tm_state",when('plan_run_tm_state.isNull,"null").otherwise('plan_run_tm_state))
      .withColumn("pick_up_tm",when('pick_up_tm.isNull,"null").otherwise('pick_up_tm))
      .withColumn("remain_time",when('remain_time.isNull,"null").otherwise('remain_time))
      .withColumn("remain_distance",when('remain_distance.isNull,"null").otherwise('remain_distance))
      .withColumn("diff_run_tm",when('diff_run_tm.isNull,"null").otherwise('diff_run_tm))
      .withColumn("diff_plan_tm",when('diff_plan_tm.isNull,"null").otherwise('diff_plan_tm))
      .withColumn("arrival_tm3",when('arrival_tm3.isNull,"null").otherwise('arrival_tm3))
      .withColumn("diff_latest_tm",when('diff_latest_tm.isNull,"null").otherwise('diff_latest_tm))
      .withColumn("solution",when('solution.isNull,"null").otherwise('solution))
      .withColumn("isselectedsaveplan",when('isselectedsaveplan.isNull,"null").otherwise('isselectedsaveplan))
      .withColumn("actual_dep_tm_data_source",when('actual_dep_tm_data_source.isNull,"null").otherwise('actual_dep_tm_data_source))
      .withColumn("start_end_state",when('start_end_state.isNull,"null").otherwise('start_end_state))
      .withColumn("rescue_avg_speed",when('rescue_avg_speed.isNull,"null").otherwise('rescue_avg_speed))
      .withColumn("averagespeed",when('averagespeed.isNull,"null").otherwise('averagespeed))
      .withColumn("num", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm"))))
      .groupBy("group2")
      .agg(
        // 取分组内第一条数据
        max(when('group2_order === 0,'task_id).otherwise(null)) as "task_id",
        max(when('group2_order === 0,'sort_num).otherwise(null)) as "sort_num",
        max(when('group2_order === 0,'task_subid).otherwise(null)) as "task_subid",
        max(when('group2_order === 0,'start_dept).otherwise(null)) as "start_dept",
        max(when('group2_order === 0,'end_dept).otherwise(null)) as "end_dept",
        max(when('group2_order === 0,'line_code).otherwise(null)) as "line_code",
        max(when('group2_order === 0,'plan_depart_tm).otherwise(null)) as "plan_depart_tm",
        max(when('group2_order === 0,'plan_arrive_tm).otherwise(null)) as "plan_arrive_tm",
        max(when('group2_order === 0,'driver_id).otherwise(null)) as "driver_id",
        max(when('group2_order === 0,'driver_name).otherwise(null)) as "driver_name",
        max(when('group2_order === 0,'actual_run_time).otherwise(null)) as "actual_run_time",
        max(when('group2_order === 0,'transoport_level).otherwise(null)) as "transoport_level",
        max(when('group2_order === 0,'ac_is_run_ontime).otherwise(null)) as "ac_is_run_ontime",
        max(when('group2_order === 0,'if_plan_delay).otherwise(null)) as "if_plan_delay",
        max(when('group2_order === 0,'if_latest_null_delay).otherwise(null)) as "if_latest_null_delay",
        max(when('group2_order === 0,'if_latest_delay).otherwise(null)) as "if_latest_delay",
        max(when('group2_order === 0,'if_actual_delay_plan).otherwise(null)) as "if_actual_delay_plan",
        max(when('group2_order === 0,'origin_run_arrive_tm).otherwise(null)) as "origin_run_arrive_tm",
        max(when('group2_order === 0,'origin_plan_arrive_tm).otherwise(null)) as "origin_plan_arrive_tm",
        max(when('group2_order === 0,'origin_latest_arrive_tm).otherwise(null)) as "origin_latest_arrive_tm",
        max(when('group2_order === 0,'vehicle_serial).otherwise(null)) as "vehicle_serial",
        max(when('group2_order === 0,'actual_depart_tm).otherwise(null)) as "actual_depart_tm",
        max(when('group2_order === 0,'actual_arrive_tm).otherwise(null)) as "actual_arrive_tm",
        // 分组内存在true则取true
        max(when('plan_arrived_tm_state === "true",1).otherwise(0)) as "ifdelay_plan_arrived_tm_state",
        max(when('latest_arrived_tm_state === "true",1).otherwise(0)) as "ifdelay_latest_arrived_tm_state",
        max(when('plan_run_tm_state === "true",1).otherwise(0)) as "ifdelay_plan_run_tm_state",
        // 分组内的字段的全部值用|拼接
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('plan_arrived_tm_state)) as "plan_arrived_tm_state",
        concat_ws("|",collect_list('latest_arrived_tm_state)) as "latest_arrived_tm_state",
        concat_ws("|",collect_list('plan_run_tm_state)) as "plan_run_tm_state",
        concat_ws("|",collect_list('pick_up_tm)) as "pick_up_tm",
        concat_ws("|",collect_list('remain_time)) as "remain_time",
        concat_ws("|",collect_list('remain_distance)) as "remain_distance",
        concat_ws("|",collect_list('diff_run_tm)) as "diff_run_tm",
        concat_ws("|",collect_list('diff_plan_tm)) as "diff_plan_tm",
        concat_ws("|",collect_list('arrival_tm3)) as "arrival_tm3",
        concat_ws("|",collect_list('diff_latest_tm)) as "diff_latest_tm",
        concat_ws("|",collect_list('solution)) as "solution",
        concat_ws("|",collect_list('isselectedsaveplan)) as "isselectedsaveplan",
        concat_ws("|",collect_list('actual_dep_tm_data_source)) as "actual_dep_tm_data_source",
        concat_ws("|",collect_list('start_end_state)) as "start_end_state",
        concat_ws("|",collect_list('rescue_avg_speed)) as "rescue_avg_speed",
        concat_ws("|",collect_list('averagespeed)) as "averagespeed",
        // 统计分组内满足条件的数据量
        count(when('source === "navi" and 'pick_up_tm =!= "null",'pick_up_tm).otherwise(null)) as "navi_count"
      )
      .join(taskDetailDF,Seq("group2"),"inner")
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("plan_arrived_tm_state",sortField('num,'plan_arrived_tm_state))
      .withColumn("latest_arrived_tm_state",sortField('num,'latest_arrived_tm_state))
      .withColumn("plan_run_tm_state",sortField('num,'plan_run_tm_state))
      .withColumn("pick_up_tm",sortField('num,'pick_up_tm))
      .withColumn("remain_time",sortField('num,'remain_time))
      .withColumn("remain_distance",sortField('num,'remain_distance))
      .withColumn("diff_run_tm",sortField('num,'diff_run_tm))
      .withColumn("diff_plan_tm",sortField('num,'diff_plan_tm))
      .withColumn("arrival_tm3",sortField('num,'arrival_tm3))
      .withColumn("diff_latest_tm",sortField('num,'diff_latest_tm))
      .withColumn("solution",sortField('num,'solution))
      .withColumn("isselectedsaveplan",sortField('num,'isselectedsaveplan))
      .withColumn("actual_dep_tm_data_source",sortField('num,'actual_dep_tm_data_source))
      .withColumn("start_end_state",sortField('num,'start_end_state))
      .withColumn("rescue_avg_speed",sortField('num,'rescue_avg_speed))
      .withColumn("averagespeed",sortField('num,'averagespeed))
      // 新增字段逻辑
      .withColumn("source",lit("navi"))
      .withColumn("ifdelay_plan_arrived_tm_state",when('ifdelay_plan_arrived_tm_state === 1,"true").otherwise("flase"))
      .withColumn("ifdelay_latest_arrived_tm_state",when('ifdelay_latest_arrived_tm_state === 1,"true").otherwise("flase"))
      .withColumn("ifdelay_plan_run_tm_state",when('ifdelay_plan_run_tm_state === 1,"true").otherwise("flase"))
      .withColumn("accelarater_or_run",when('solution.contains("加速方案"),"加速").otherwise(""))
      .withColumn("inc_day",lit(dayBefore1))
      .filter('task_type === "导航")

    // 保存数据
    val res_cols = spark.sql("""select * from dm_gis.kafka_recall_task_detail_navi limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,taskDetailNaviDF.select(res_cols: _*),Seq("inc_day"),"dm_gis.kafka_recall_task_detail_navi")

  }
}
