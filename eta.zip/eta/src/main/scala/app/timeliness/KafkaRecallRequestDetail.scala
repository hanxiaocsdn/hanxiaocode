package app.timeliness

import app.timeliness.GuiHuaXianLuZhiXingTable10.runGuiHuaXianLuZhiXing
import app.timeliness.JiaSuTaskTable8.runJiaSuTask
import app.timeliness.JiuPianFwqTable45.runJiuPianFWQ
import app.timeliness.KafkaRecallRequestDetailTable1.runKafkaRecallRequestDetail
import app.timeliness.KafkaRecallTaskDetailNaviTable3.runKafkaRecallTaskDetailNavi
import app.timeliness.KafkaRecallTaskDetailTable2.runKafkaRecallTaskDetail
import app.timeliness.LuKuangSpeedTable6.runLuKuangSpeed
import app.timeliness.TimeDelayRescueTable12.runTimeDelayRescue
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger

/**
 * 时效预警&挽救指标体系搭建
 * 需求方：左佳怡（01403789）
 * @author 徐游飞（01417347）
 * 任务ID：574498
 * 任务名称：时效预警And挽救指标体系
 */
object KafkaRecallRequestDetail {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    // incDay为业务时间，以业务时间为基准前1天和前3天
    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)
    val dayBefore2 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 2)
    val dayBefore3 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 3)
    val dayBefore4 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 4)

    //日期检查
    logger.error("incDay="+incDay)
    logger.error("dayBefore1="+dayBefore1)
    logger.error("dayBefore2="+dayBefore2)
    logger.error("dayBefore3="+dayBefore3)
    logger.error("dayBefore4="+dayBefore4)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016 ++++")
    // 时效晚点&时效挽救请求明细表--表1
    runKafkaRecallRequestDetail(spark,dayBefore1,dayBefore3)
    // 全部数据任务明细--表2
    runKafkaRecallTaskDetail(spark,dayBefore1)
    // 导航数据任务明细--表3
    runKafkaRecallTaskDetailNavi(spark,dayBefore1)
    // 全部--表4和表5
    runJiuPianFWQ(spark,dayBefore1,dayBefore2)
    // 全部--表6
    runLuKuangSpeed(spark,dayBefore1,"eta")
    // 全部--表8
    runJiaSuTask(spark,dayBefore1,"eta")
    // 全部--表10
    runGuiHuaXianLuZhiXing(spark,incDay,"eta")
    // 全部--表12
    runTimeDelayRescue(spark,incDay,"eta")
    logger.error("++++++++  任务结束  ++++")

    spark.stop()
  }
}

