package app.timeliness

import Utils.SparkUtils.writeToHive
import app.timeliness.Functions.{countField, deleteNull, sortField}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._

// 加速方案任务明细表，表8和表9逻辑
object JiaSuTaskTable8 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def runJiaSuTask(spark: SparkSession, dayBefore1: String, flag: String) = {

    // 根据入参选择对应的取数sql
    var querySql = ""
    if(flag.equals("eta")){
      querySql =
        s"""
           |select
           |  *
           |from
           |  dm_gis.lukuang_speed
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }else if(flag.equals("navi")){
      querySql =
        s"""
           |select
           |  *
           |from
           |  dm_gis.lukuang_speed_navi
           |where
           |  inc_day = '$dayBefore1'
           |""".stripMargin
    }
    println(querySql)
    val df_lukuang_speed = spark.sql(querySql)

    import spark.implicits._
    val df_jiasu_task = df_lukuang_speed
      // 空值处理，方便分组收集后排序操作
      .withColumn("group2_order", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm_jiasu"))) - 1)
      .withColumn("num", row_number().over(Window.partitionBy('group2).orderBy(asc("pick_up_tm"))))
      .withColumn("pick_up_tm_jiasu",when('pick_up_tm_jiasu.isNull or 'pick_up_tm_jiasu === "","null").otherwise('pick_up_tm_jiasu))
      .withColumn("elimate_outlier",when('elimate_outlier.isNull or 'elimate_outlier === "","null").otherwise('elimate_outlier))
      .withColumn("pickup_tm_ycz_jiasu",when('pickup_tm_ycz_jiasu.isNull or 'pickup_tm_ycz_jiasu === "","null").otherwise('pickup_tm_ycz_jiasu))
      .withColumn("before_15min_speed",when('before_15min_speed.isNull or 'before_15min_speed === "","null").otherwise('before_15min_speed))
      .withColumn("after_15min_speed",when('after_15min_speed.isNull or 'after_15min_speed === "","null").otherwise('after_15min_speed))
      .withColumn("before_15min_aver_lukuang_speed",when('before_15min_aver_lukuang_speed.isNull or 'before_15min_aver_lukuang_speed === "","null").otherwise('before_15min_aver_lukuang_speed))
      .withColumn("after_15min_aver_lukuang_speed",when('after_15min_aver_lukuang_speed.isNull or 'after_15min_aver_lukuang_speed === "","null").otherwise('after_15min_aver_lukuang_speed))
      .withColumn("current_point_if_accelarate",when('current_point_if_accelarate.isNull or 'current_point_if_accelarate === "","null").otherwise('current_point_if_accelarate))
      .withColumn("current_point_if_lukuang_low",when('current_point_if_lukuang_low.isNull or 'current_point_if_lukuang_low === "","null").otherwise('current_point_if_lukuang_low))
      .withColumn("current_point_if_lukuang_change",when('current_point_if_lukuang_change.isNull or 'current_point_if_lukuang_change === "","null").otherwise('current_point_if_lukuang_change))
      .withColumn("current_point_if_conduct_accelerate",when('current_point_if_conduct_accelerate.isNull or 'current_point_if_conduct_accelerate === "","null").otherwise('current_point_if_conduct_accelerate))
      .groupBy("group2")
      .agg(
        // 取分组内第一条数据
        max(when('group2_order === 0,'task_subid).otherwise(null)) as "task_subid",
        max(when('group2_order === 0,'pick_up_tm).otherwise(null)) as "pick_up_tm",
        max(when('group2_order === 0,'task_type).otherwise(null)) as "task_type",
        max(when('group2_order === 0,'solution).otherwise(null)) as "solution",
        max(when('group2_order === 0,'plan_arrived_tm_state).otherwise(null)) as "plan_arrived_tm_state",
        max(when('group2_order === 0,'latest_arrived_tm_state).otherwise(null)) as "latest_arrived_tm_state",
        max(when('group2_order === 0,'plan_run_tm_state).otherwise(null)) as "plan_run_tm_state",
        max(when('group2_order === 0,'accelarater_or_run).otherwise(null)) as "accelarater_or_run",
        max(when('group2_order === 0,'solution2).otherwise(null)) as "solution2",
        max(when('group2_order === 0,'plan_arrived_tm_state2).otherwise(null)) as "plan_arrived_tm_state2",
        max(when('group2_order === 0,'latest_arrived_tm_state2).otherwise(null)) as "latest_arrived_tm_state2",
        max(when('group2_order === 0,'plan_run_tm_state2).otherwise(null)) as "plan_run_tm_state2",
        max(when('group2_order === 0,'accelarater_or_run2).otherwise(null)) as "accelarater_or_run2",
        // 分组内的字段的全部值用|拼接
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('pick_up_tm_jiasu)) as "pick_up_tm_jiasu",
        concat_ws("|",collect_list('elimate_outlier)) as "elimate_outlier",
        concat_ws("|",collect_list('pickup_tm_ycz_jiasu)) as "pickup_tm_ycz_jiasu",
        concat_ws("|",collect_list('before_15min_speed)) as "before_15min_speed",
        concat_ws("|",collect_list('after_15min_speed)) as "after_15min_speed",
        concat_ws("|",collect_list('before_15min_aver_lukuang_speed)) as "before_15min_aver_lukuang_speed",
        concat_ws("|",collect_list('after_15min_aver_lukuang_speed)) as "after_15min_aver_lukuang_speed",
        concat_ws("|",collect_list('current_point_if_accelarate)) as "current_point_if_accelarate",
        concat_ws("|",collect_list('current_point_if_lukuang_low)) as "current_point_if_lukuang_low",
        concat_ws("|",collect_list('current_point_if_lukuang_change)) as "current_point_if_lukuang_change",
        concat_ws("|",collect_list('current_point_if_conduct_accelerate)) as "current_point_if_conduct_accelerate"
      )
      // 分组内的字段拼接值按照num顺序重新排序后再过滤掉null值
      .withColumn("pick_up_tm_jiasu",deleteNull(sortField('num,'pick_up_tm_jiasu)))
      .withColumn("elimate_outlier",deleteNull(sortField('num,'elimate_outlier)))
      .withColumn("pickup_tm_ycz_jiasu",deleteNull(sortField('num,'pickup_tm_ycz_jiasu)))
      .withColumn("before_15min_speed",deleteNull(sortField('num,'before_15min_speed)))
      .withColumn("after_15min_speed",deleteNull(sortField('num,'after_15min_speed)))
      .withColumn("before_15min_aver_lukuang_speed",deleteNull(sortField('num,'before_15min_aver_lukuang_speed)))
      .withColumn("after_15min_aver_lukuang_speed",deleteNull(sortField('num,'after_15min_aver_lukuang_speed)))
      .withColumn("current_point_if_accelarate", deleteNull(sortField('num,'current_point_if_accelarate)))
      .withColumn("current_point_if_lukuang_low", deleteNull(sortField('num,'current_point_if_lukuang_low)))
      .withColumn("current_point_if_lukuang_change", deleteNull(sortField('num,'current_point_if_lukuang_change)))
      .withColumn("current_point_if_conduct_accelerate", deleteNull(sortField('num,'current_point_if_conduct_accelerate)))
      // 新增字段逻辑
      .withColumn("num_accelerate_remind",when('accelarater_or_run === "运行",countField('plan_run_tm_state,lit("true")))
        .when('accelarater_or_run === "加速",countField('solution,lit("加速方案")))
        .otherwise(""))
      .withColumn("if_accelerate_conduct", when('current_point_if_conduct_accelerate.contains("true"),"true")
        .otherwise("false"))
      .withColumn("num_accelerate_conduct",countField('current_point_if_conduct_accelerate,lit("true")))
      .withColumn("num_accelerate_conduct",when('num_accelerate_conduct === 0,"").otherwise('num_accelerate_conduct))
      .withColumn("if_accelerate",lit("true"))
      .withColumn("inc_day",lit(dayBefore1))

    // 保存数据
    if(flag.equals("eta")){
      val res_cols = spark.sql(s"""select * from dm_gis.jiasu_task limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_jiasu_task.select(res_cols: _*),Seq("inc_day"),"dm_gis.jiasu_task")
    }else if(flag.equals("navi")){
      val res_cols = spark.sql(s"""select * from dm_gis.jiasu_task_navi limit 0""").schema.map(_.name).map(col)
      writeToHive(spark,df_jiasu_task.select(res_cols: _*),Seq("inc_day"),"dm_gis.jiasu_task_navi")
    }

  }
}
