package app.timeliness

import Utils.SparkUtils.writeToHive
import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import java.text.SimpleDateFormat
import scala.collection.mutable.ListBuffer

/**
 * 时效预警&挽救指标体系搭建——任务维度统计指标
 * 需求方：左佳怡（01403789）
 * @author 徐游飞（01417347）
 * 任务ID：617815
 * 任务名称：时效挽救_任务维度数据指标
 */
object TaskDataDetailTable16 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val dayBefore1 = DateUtil.getDayBefore(incDay, "yyyyMMdd", 1)

    //日期检查,incDay为业务时间
    logger.error("incDay="+incDay)
    logger.error("dayBefore1="+dayBefore1)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始  ++++")

    // v1.6需求的三张结果表
    // 任务维度数据明细表--表16
    runTaskDataDetail(spark, dayBefore1)
    // 任务维度指标统计表--表17
    runTaskDataDetailZhibiaoTask(spark,dayBefore1)
    // 任务维度指标结果表--表18
    runTaskZhibiao(spark,dayBefore1)

    logger.error("++++++++  任务结束  ++++")
    spark.stop()

  }

  def getDataSouse(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._

    // 从表12取数
    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.time_delay_rescue
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println(querySql)
    val df_delay_rescue = spark.sql(querySql)

    val recall1_querySql =
      s"""
         |select
         |  task_id,
         |  carrier_name
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println(recall1_querySql)
    val df_recall1 = spark.sql(recall1_querySql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("task_id"))))
      .filter('rn === 1)
      .drop("rn")

    val biz_sql =
      s"""
         |select
         |  task_id,
         |  biz_type,
         |  require_category
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println(biz_sql)
    val df_biz = spark.sql(biz_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("task_id"))))
      .filter('rn === 1)
      .drop("rn")

    val piece_sql =
      s"""
         |select
         |  task_id,
         |  piece_type,
         |  carrier_type
         |from
         |  dm_tdsp.rpt_grd_task_monitor_re_dtl_di
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println(piece_sql)
    val df_piece = spark.sql(piece_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("task_id"))))
      .filter('rn === 1)
      .drop("rn")

    (df_delay_rescue,df_recall1,df_biz,df_piece)

  }

  /**
   * 任务维度指标结果表 表16
   *
   * @param spark
   * @param dayBefore1
   */
  def runTaskDataDetail(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._

    // 获取hive数据
    val dataSouse = getDataSouse(spark, dayBefore1)
    val df_delay_rescue = dataSouse._1
    val df_recall1 = dataSouse._2
    val df_biz = dataSouse._3
    val df_piece = dataSouse._4

    val df_task_data_detail_1 = df_delay_rescue
      .withColumn("num", row_number().over(Window.partitionBy('task_id).orderBy(asc("sort_num"))))
      // 空值处理，方便分组收集后排序操作
      .withColumn("group2",when('group2.isNull,"null").otherwise('group2))
      .withColumn("task_subid",when('task_subid.isNull,"null").otherwise('task_subid))
      .withColumn("sort_num",when('sort_num.isNull,"null").otherwise('sort_num))
      .withColumn("start_dept",when('start_dept.isNull,"null").otherwise('start_dept))
      .withColumn("end_dept",when('end_dept.isNull,"null").otherwise('end_dept))
      .withColumn("line_code",when('line_code.isNull,"null").otherwise('line_code))
      .withColumn("plan_depart_tm",when('plan_depart_tm.isNull,"null").otherwise('plan_depart_tm))
      .withColumn("plan_arrive_tm",when('plan_arrive_tm.isNull,"null").otherwise('plan_arrive_tm))
      .withColumn("driver_id",when('driver_id.isNull,"null").otherwise('driver_id))
      .withColumn("driver_name",when('driver_name.isNull,"null").otherwise('driver_name))
      .withColumn("vehicle_serial",when('vehicle_serial.isNull,"null").otherwise('vehicle_serial))
      .withColumn("actual_depart_tm",when('actual_depart_tm.isNull,"null").otherwise('actual_depart_tm))
      .withColumn("actual_arrive_tm",when('actual_arrive_tm.isNull,"null").otherwise('actual_arrive_tm))
      .withColumn("task_type",when('task_type.isNull,"null").otherwise('task_type))
      //.withColumn("time_duty_ob",when('time_duty_ob.isNull,"null").otherwise('time_duty_ob))
      .withColumn("inc_day",when('inc_day.isNull,"null").otherwise('inc_day))
      .groupBy("task_id")
      .agg(
        // 分组内的字段的全部值用|拼接
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('group2)) as "group2",
        concat_ws("|",collect_list('task_subid)) as "task_subid",
        concat_ws("|",collect_list('sort_num)) as "sort_num",
        concat_ws("|",collect_list('start_dept)) as "start_dept",
        concat_ws("|",collect_list('end_dept)) as "end_dept",
        concat_ws("|",collect_list('line_code))as "line_code",
        concat_ws("|",collect_list('plan_depart_tm)) as "plan_depart_tm",
        concat_ws("|",collect_list('plan_arrive_tm)) as "plan_arrive_tm",
        concat_ws("|",collect_list('driver_id)) as "driver_id",
        concat_ws("|",collect_list('driver_name)) as "driver_name",
        concat_ws("|",collect_list('vehicle_serial)) as "vehicle_serial",
        concat_ws("|",collect_list('actual_depart_tm)) as "actual_depart_tm",
        concat_ws("|",collect_list('actual_arrive_tm)) as "actual_arrive_tm",
        concat_ws("|",collect_list('task_type)) as "task_type",
        concat_ws("|",collect_list(when('time_duty_ob.isNotNull or 'time_duty_ob =!= "",'time_duty_ob).otherwise(null))) as "time_duty_ob",
        concat_ws("|",collect_list('inc_day)) as "inc_day_sub",
        // 后面需要重新判断赋值
        concat_ws("|",collect_list('ac_is_run_ontime)) as "ac_is_run_ontime",
        concat_ws("|",collect_list('if_actual_delay_plan)) as "if_actual_delay_plan",
        concat_ws("|",collect_list('if_plan_delay)) as "if_plan_delay",
        concat_ws("|",collect_list('if_latest_null_delay)) as "if_latest_null_delay",
        concat_ws("|",collect_list('if_latest_delay)) as "if_latest_delay",
        concat_ws("|",collect_list('ifdelay_plan_arrived_tm_state)) as "ifdelay_plan_arrived_tm_state",
        concat_ws("|",collect_list('ifdelay_latest_arrived_tm_state)) as "ifdelay_latest_arrived_tm_state",
        concat_ws("|",collect_list('ifdelay_plan_run_tm_state)) as "ifdelay_plan_run_tm_state",
        concat_ws("|",collect_list('if_rescue_plan_outlier)) as "if_rescue_plan_outlier",
        concat_ws("|",collect_list('if_select_outlier)) as "if_select_outlier",
        concat_ws("|",collect_list('if_conduct)) as "if_conduct",
        concat_ws("|",collect_list('time_duty_if_ob)) as "time_duty_if_ob",
        // 分组内求和
        sum('actual_run_time.cast("double")) as "actual_run_time",
        sum('num_accelerate_remind_outlier.cast("int")) as "num_remind_outlier",
        sum('num_accelerate_conduct.cast("int")) as "num_conduct",
        sum('num_replanline.cast("int")) as "num_replanline",
        sum('num_if_replanline_select.cast("int")) as "num_if_select",
        sum('num_if_replanline_conduct.cast("int")) as "num_if_conduct",
        sum('time_duty_ob_tm.cast("double")) as "time_duty_ob_tm",
        sum(abs('accelarate_conduct_forecast_delay_time_plan.cast("double"))) as "accelarate_conduct_forecast_delay_time_plan",
        sum(abs('accelarate_conduct_forecast_delay_time_latest.cast("double"))) as "accelarate_conduct_forecast_delay_time_latest",
        // 取分组内第一条数据
        max(when('num === 1,'transoport_level).otherwise(null)) as "transoport_level",
        max(when('num === 1,'should_load_bnum).otherwise(null)) as "should_load_bnum",
        max(when('num === 1,'actual_load_bnum).otherwise(null)) as "actual_load_bnum"
      )
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("group2",sortField('num,'group2))
      .withColumn("task_subid",sortField('num,'task_subid))
      .withColumn("sort_num",sortField('num,'sort_num))
      .withColumn("start_dept",sortField('num,'start_dept))
      .withColumn("end_dept",sortField('num,'end_dept))
      .withColumn("line_code",sortField('num,'line_code))
      .withColumn("plan_depart_tm",sortField('num,'plan_depart_tm))
      .withColumn("plan_arrive_tm",sortField('num,'plan_arrive_tm))
      .withColumn("driver_id",sortField('num,'driver_id))
      .withColumn("driver_name",sortField('num,'driver_name))
      .withColumn("vehicle_serial",sortField('num,'vehicle_serial))
      .withColumn("actual_depart_tm",sortField('num,'actual_depart_tm))
      .withColumn("actual_arrive_tm",sortField('num,'actual_arrive_tm))
      .withColumn("task_type",sortField('num,'task_type))
      //.withColumn("time_duty_ob",sortField('num,'time_duty_ob))
      .withColumn("inc_day_sub",sortField('num,'inc_day_sub))
      // 重新判断赋值
      .withColumn("ac_is_run_ontime",selectField2('ac_is_run_ontime,lit("1.0"),lit("准点"),lit("晚点"),lit("last")))
      .withColumn("if_actual_delay_plan",selectField2('if_actual_delay_plan,lit("实际发车早于计划发车"),lit("实际发车早于计划发车"),lit("实际发车晚于计划发车"),lit("first")))
      .withColumn("if_plan_delay",selectField2('if_plan_delay,lit("1"),lit("准点"),lit("晚点"),lit("last")))
      .withColumn("if_latest_null_delay",selectField2('if_latest_null_delay,lit("是"),lit("是"),lit("否"),lit("contains")))
      .withColumn("if_latest_delay",selectField2('if_latest_delay,lit("1"),lit("准点"),lit("晚点"),lit("last")))
      .withColumn("ifdelay_plan_arrived_tm_state",selectField2('ifdelay_plan_arrived_tm_state,lit("true"),lit("是"),lit("否"),lit("contains")))
      .withColumn("ifdelay_latest_arrived_tm_state",selectField2('ifdelay_latest_arrived_tm_state,lit("true"),lit("是"),lit("否"),lit("contains")))
      .withColumn("ifdelay_plan_run_tm_state",selectField2('ifdelay_plan_run_tm_state,lit("true"),lit("是"),lit("否"),lit("contains")))
      .withColumn("if_rescue_plan_outlier",selectField3('if_rescue_plan_outlier))
      .withColumn("if_select_outlier",selectField2('if_select_outlier,lit("true"),lit("是"),lit("否"),lit("contains")))
      .withColumn("if_conduct",selectField2('if_conduct,lit("true"),lit("是"),lit("否"),lit("contains")))
      .withColumn("time_duty_if_ob",selectField2('time_duty_if_ob,lit("是"),lit("是"),lit("否"),lit("contains")))
      .withColumn("ratio_obtm_forecast_delay_plan",'time_duty_ob_tm / 'accelarate_conduct_forecast_delay_time_plan)
      .withColumn("ratio_obtm_forecast_delay_latest",'time_duty_ob_tm / 'accelarate_conduct_forecast_delay_time_latest)
      .withColumn("plan_run_time",sumField('plan_arrive_tm,'plan_depart_tm))
      .withColumn("section_ratio_obtm_delay_plan",when('ratio_obtm_forecast_delay_plan.isNotNull, percentField(abs('ratio_obtm_forecast_delay_plan))).otherwise("其他-无客观时长"))
      .withColumn("section_ratio_obtm_delay_latest",when('ratio_obtm_forecast_delay_latest.isNotNull, percentField(abs('ratio_obtm_forecast_delay_latest))).otherwise("其他-无客观时长"))
      .withColumn("inc_day",lit(dayBefore1))

    val df_task_data_detail = df_task_data_detail_1
      .join(df_recall1,Seq("task_id"),"left")
      .join(df_biz,Seq("task_id"),"left")
      .join(df_piece,Seq("task_id"),"left")

    // 保存数据
    val res_cols = spark.sql("""select * from dm_gis.task_data_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_task_data_detail.select(res_cols: _*),Seq("inc_day"),"dm_gis.task_data_detail")

  }

  /**
   * 任务维度指标统计表--表17 和 任务维度指标结果表--表18
   * @param spark
   * @param dayBefore1
   */
  def runTaskDataDetailZhibiaoTask(spark: SparkSession, dayBefore1: String) = {
    // 从表16取数
    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.task_data_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println(querySql)
    val df_data_detail = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    import spark.implicits._
    val df_plan = df_data_detail
      .withColumn("if_actual_delay",'if_plan_delay)
      .withColumn("type_delay",lit("计划到车晚点"))
      .withColumn("num_transoport_level",count("task_id")
        .over(Window.partitionBy("transoport_level")))
      .withColumn("num_if_actual_delay",count("task_id")
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_delay_warn_outlier",count(when('ifdelay_plan_arrived_tm_state === "是","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_outlier",count(when('ifdelay_plan_arrived_tm_state === "是" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案"),"task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_conduct",count(when('ifdelay_plan_arrived_tm_state === "是" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案") and 'if_conduct === "是","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_outlier",count(when('ifdelay_plan_arrived_tm_state === "是" and 'if_rescue_plan_outlier === "重新规划线路方案","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_conduct",count(when('ifdelay_plan_arrived_tm_state === "是" and 'if_rescue_plan_outlier === "重新规划线路方案" and 'if_conduct === "是","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_outlier",count(when('ifdelay_plan_arrived_tm_state === "是" and 'if_rescue_plan_outlier =!= "没有挽救方案","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_conduct_outlier",count(when('ifdelay_plan_arrived_tm_state === "是" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .groupBy("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")
      .agg(count('task_id) as "tmp")
      .select("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")

    val df_latest = df_data_detail
      .withColumn("if_actual_delay",'if_latest_delay)
      .withColumn("type_delay",lit("最晚到车晚点"))
      .withColumn("num_transoport_level",count("task_id")
        .over(Window.partitionBy("transoport_level")))
      .withColumn("num_if_actual_delay",count(when('if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_delay_warn_outlier",count(when('ifdelay_latest_arrived_tm_state === "是" and 'if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_outlier",count(when('ifdelay_latest_arrived_tm_state === "是" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案") and 'if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_accelerate_conduct",count(when('ifdelay_latest_arrived_tm_state === "是" and ('if_rescue_plan_outlier === "加速方案&重新规划线路方案" or 'if_rescue_plan_outlier === "加速方案") and 'if_conduct === "是" and 'if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_outlier",count(when('ifdelay_latest_arrived_tm_state === "是" and 'if_rescue_plan_outlier === "重新规划线路方案" and 'if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_replanline_conduct",count(when('ifdelay_latest_arrived_tm_state === "是" and 'if_rescue_plan_outlier === "重新规划线路方案" and 'if_conduct === "是" and 'if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_outlier",count(when('ifdelay_latest_arrived_tm_state === "是" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .withColumn("num_save_plan_conduct_outlier",count(when('ifdelay_latest_arrived_tm_state === "是" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是" and 'if_latest_null_delay === "否","task_id").otherwise(null))
        .over(Window.partitionBy("if_actual_delay","transoport_level")))
      .groupBy("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")
      .agg(count('task_id) as "tmp")
      .select("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")

    val df_zhibiao_task = df_plan.union(df_latest)
      //.persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    val df_quanbu = df_zhibiao_task
      .groupBy("type_delay", "if_actual_delay")
      .agg(
        sum('num_transoport_level) as "num_transoport_level",
        sum('num_if_actual_delay) as "num_if_actual_delay",
        sum('num_delay_warn_outlier) as "num_delay_warn_outlier",
        sum('num_accelerate_outlier) as "num_accelerate_outlier",
        sum('num_accelerate_conduct) as "num_accelerate_conduct",
        sum('num_replanline_outlier) as "num_replanline_outlier",
        sum('num_replanline_conduct) as "num_replanline_conduct",
        sum('num_save_plan_outlier) as "num_save_plan_outlier",
        sum('num_save_plan_conduct_outlier) as "num_save_plan_conduct_outlier"
      )
      .withColumn("transoport_level", lit("全部"))
      .select("type_delay","transoport_level","if_actual_delay","num_transoport_level","num_if_actual_delay","num_delay_warn_outlier","num_accelerate_outlier","num_accelerate_conduct",
        "num_replanline_outlier","num_replanline_conduct","num_save_plan_outlier","num_save_plan_conduct_outlier")

    val df_table_17 = df_zhibiao_task
      .union(df_quanbu)
      .withColumn("ratio_num_if_actual_delay",'num_if_actual_delay / 'num_transoport_level)
      .withColumn("ratio_num_delay_warn_outlier",'num_delay_warn_outlier / 'num_if_actual_delay)
      .withColumn("ratio_num_accelerate_conduct_outlier",'num_accelerate_conduct / 'num_accelerate_outlier)
      .withColumn("ratio_num_replanline_conduct_outlier",'num_replanline_conduct / 'num_replanline_outlier)
      .withColumn("ratio_num_save_plan_outlier",'num_save_plan_outlier / 'num_delay_warn_outlier)
      .withColumn("ratio_num_save_plan_conduct_outlier",'num_save_plan_conduct_outlier / 'num_save_plan_outlier)
      .withColumn("inc_day",lit(dayBefore1))

    // 任务维度指标统计表--表17
    val res_cols_17 = spark.sql(s"""select * from dm_gis.task_data_detail_zhibiao_task limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_table_17.select(res_cols_17: _*),Seq("inc_day"),"dm_gis.task_data_detail_zhibiao_task")
  }

  /**
   * 任务维度指标结果表--表18
   * @param spark
   * @param dayBefore1
   */
  def runTaskZhibiao(spark: SparkSession, dayBefore1: String) = {
    // 从表16取数
    val querySql_16 =
      s"""
         |select
         |  *
         |from
         |  dm_gis.task_data_detail
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println(querySql_16)
    val df_data_detail = spark.sql(querySql_16).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    // 从表17取数
    val querySql_17 =
      s"""
         |select
         |  *
         |from
         |  dm_gis.task_data_detail_zhibiao_task
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin

    println(querySql_17)
    val df_zhibiao_task = spark.sql(querySql_17)

    // 任务维度指标结果表--表18
    import spark.implicits._
    val df_task_zhibiao_1 = df_zhibiao_task
      .groupBy("type_delay","transoport_level")
      .agg(
        sum(when('if_actual_delay === "准点",'num_transoport_level).otherwise(0)) as "num_transoport_level",
        sum(when('if_actual_delay === "晚点",'num_if_actual_delay).otherwise(0)) as "num_if_actual_delay",
        sum('num_delay_warn_outlier) as "num_delay_warn",
        sum(when('if_actual_delay === "晚点",'num_delay_warn_outlier).otherwise(0)) as "num_delay_warn_actual_delay",
        sum(when('if_actual_delay === "晚点",'num_save_plan_outlier).otherwise(0)) as "num_delay_warn_actual_delay_save_plan",
        sum('num_save_plan_outlier) as "num_save_plan",
        sum('num_save_plan_conduct_outlier) as "num_save_plan_conduct",
        sum(when('if_actual_delay === "准点",'num_save_plan_conduct_outlier).otherwise(0)) as "num_success"
      )
      .withColumn("inc_day",lit(dayBefore1))

    val df_task_zhibiao_plan = df_data_detail
      .withColumn("type_delay",lit("计划到车晚点"))
      .groupBy("type_delay","transoport_level")
      .agg(
        count(when(('section_ratio_obtm_delay_plan === "0-10%" or 'section_ratio_obtm_delay_plan === "其他-无客观时长") and 'if_plan_delay === "准点"
          and 'ifdelay_plan_arrived_tm_state === "是" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_0_10",
        count(when('section_ratio_obtm_delay_plan === "10%-20%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_10_20",
        count(when('section_ratio_obtm_delay_plan === "20%-30%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_20_30",
        count(when('section_ratio_obtm_delay_plan === "30%-40%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_30_40",
        count(when('section_ratio_obtm_delay_plan === "40%-50%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_40_50",
        count(when('section_ratio_obtm_delay_plan === "50%-60%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_50_60",
        count(when('section_ratio_obtm_delay_plan === "60%-70%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_60_70",
        count(when('section_ratio_obtm_delay_plan === "70%-80%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_70_80",
        count(when('section_ratio_obtm_delay_plan === "80%-90%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_80_90",
        count(when('section_ratio_obtm_delay_plan === "90%-100%" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_90_100",
        count(when('section_ratio_obtm_delay_plan === "100%以上" and 'if_plan_delay === "准点" and 'ifdelay_plan_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_100",
        count(when('if_plan_delay =!= "准点" or 'ifdelay_plan_arrived_tm_state =!= "是" or 'if_rescue_plan_outlier === "没有挽救方案" or 'if_conduct =!= "是",1)
          .otherwise(null)) as "percent_other"
      )

    val df_task_zhibiao_latest = df_data_detail
      .withColumn("type_delay",lit("最晚到车晚点"))
      .groupBy("type_delay","transoport_level")
      .agg(
        count(when(('section_ratio_obtm_delay_latest === "0-10%" or 'section_ratio_obtm_delay_latest === "其他-无客观时长") and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点"
          and 'ifdelay_latest_arrived_tm_state === "是" and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_0_10",
        count(when('section_ratio_obtm_delay_latest === "10%-20%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_10_20",
        count(when('section_ratio_obtm_delay_latest === "20%-30%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_20_30",
        count(when('section_ratio_obtm_delay_latest === "30%-40%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_30_40",
        count(when('section_ratio_obtm_delay_latest === "40%-50%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_40_50",
        count(when('section_ratio_obtm_delay_latest === "50%-60%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_50_60",
        count(when('section_ratio_obtm_delay_latest === "60%-70%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_60_70",
        count(when('section_ratio_obtm_delay_latest === "70%-80%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_70_80",
        count(when('section_ratio_obtm_delay_latest === "80%-90%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_80_90",
        count(when('section_ratio_obtm_delay_latest === "90%-100%" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_90_100",
        count(when('section_ratio_obtm_delay_latest === "100%以上" and 'if_latest_null_delay === "否" and 'if_latest_delay === "准点" and 'ifdelay_latest_arrived_tm_state === "是"
          and 'if_rescue_plan_outlier =!= "没有挽救方案" and 'if_conduct === "是",1).otherwise(null)) as "percent_100",
        count(when('if_latest_null_delay =!= "否" or 'if_latest_delay =!= "准点" or 'ifdelay_latest_arrived_tm_state =!= "是" or 'if_rescue_plan_outlier === "没有挽救方案" or 'if_conduct =!= "是",1)
          .otherwise(null)) as "percent_other"
      )

    val df_task_zhibiao_2 = df_task_zhibiao_plan.union(df_task_zhibiao_latest)

    val df_task_zhibiao_quanbu = df_task_zhibiao_2
      .withColumn("transoport_level", lit("全部"))
      .groupBy("type_delay","transoport_level")
      .agg(
        sum('percent_0_10) as "percent_0_10",
        sum('percent_10_20) as "percent_10_20",
        sum('percent_20_30) as "percent_20_30",
        sum('percent_30_40) as "percent_30_40",
        sum('percent_40_50) as "percent_40_50",
        sum('percent_50_60) as "percent_50_60",
        sum('percent_60_70) as "percent_60_70",
        sum('percent_70_80) as "percent_70_80",
        sum('percent_80_90) as "percent_80_90",
        sum('percent_90_100) as "percent_90_100",
        sum('percent_100) as "percent_100",
        sum('percent_other) as "percent_other"
      )

    val df_task_zhibiao = df_task_zhibiao_2.union(df_task_zhibiao_quanbu)
      .join(df_task_zhibiao_1, Seq("type_delay", "transoport_level"), "right")

    // 任务维度指标结果表--表18
    val res_cols_18 = spark.sql(s"""select * from dm_gis.task_zhibiao limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_task_zhibiao.select(res_cols_18: _*),Seq("inc_day"),"dm_gis.task_zhibiao")
  }

  /**
   * 分组收集后的排序函数，保证分组收集的所有字段顺序一一对应
   * @return
   */
  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\|")
      val other_arr = other.split("\\|")
      val new_arr = num_arr.zip(other_arr).sortWith((x,y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })

  /**
   * 分组收集字段
   * @return
   */
  def sumField = udf((col1: String,col2: String) => {
    var res = 0.0
    if(col1 != null && col1.trim != "" && col2 != null && col2.trim != ""){
      val arr1 = col1.split("\\|")
      val arr2 = col2.split("\\|")
      for(i <- 0 until arr1.length){
        var start = 0L
        var end = 0L
        try{
          start = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(arr1(i)).getTime/1000
        }catch{
          case e: Exception => logger.error("plan_arrive_tm转时间戳失败")
        }
        try{
          end = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(arr2(i)).getTime/1000
        }catch{
          case e: Exception => logger.error("plan_arrive_tm转时间戳失败")
        }
        val diff = start - end
        res = res + diff
      }
    }
    res/60
  })

  /**
   * 分组收集字段
   * @return
   */
  def percentField = udf((col1: Double) => {
    var res = "其他"
    //if(col1 != null){
     if(0 <= col1 && col1 <= 0.1) res = "0-10%"
     else if(0.1 < col1 && col1 <= 0.2) res = "10%-20%"
     else if(0.2 < col1 && col1 <= 0.3) res = "20%-30%"
     else if(0.3 < col1 && col1 <= 0.4) res = "30%-40%"
     else if(0.4 < col1 && col1 <= 0.5) res = "40%-50%"
     else if(0.5 < col1 && col1 <= 0.6) res = "50%-60%"
     else if(0.6 < col1 && col1 <= 0.7) res = "60%-70%"
     else if(0.7 < col1 && col1 <= 0.8) res = "70%-80%"
     else if(0.8 < col1 && col1 <= 0.9) res = "80%-90%"
     else if(0.9 < col1 && col1 <= 1) res = "90%-100%"
     else if(col1 > 1) res = "100%以上"
     else res = "其他-无客观时长"
    //}
    //else res = "其他-无客观时长"
    res
  })

  /**
   * 判断分组收集字段的最后一个或者第一个值是否等于某个值
   * @return
   */
  def selectField2 = udf((col1: String,col2: String,col3: String,col4: String,col5: String) => {
    var res = ""
    if(col1 != null && col1.trim != ""){
      val arr1 = col1.split("\\|")
      //判断收集字段第一个值
      if(col5.equals("first")){
        if(arr1(0).equals(col2)) res = col3 else res = col4
        //判断收集字段最后一个值
      }else if(col5.equals("last")){
        if(arr1(arr1.length-1).equals(col2)) res = col3 else res = col4
        //判断收集字段是否包含
      }else if(col5.equals("contains")){
        if(arr1.contains(col2)) res = col3 else res = col4
      }
    }
    res
  })

  /**
   * 判断分组收集字段逻辑
   * @return
   */
  def selectField3 = udf((col1: String) => {
    var res = "没有挽救方案"
    if(col1 != null && col1.trim != ""){
      val arr = col1.split("\\|")
      if(arr.contains("加速方案")) res = "加速方案"
      else if(arr.contains("加速方案&重新规划线路方案")) res = "加速方案&重新规划线路方案"
      else if(arr.contains("重新规划线路方案")) res = "重新规划线路方案"
    }
    res
  })


}
