package app

import Utils.CommonTools.row2Json
import Utils.SparkUtils.writeToHive
import Utils.StringUtils.{timeToCustomTime, tranTimeToLong}
import app.timeliness.Functions.sortField
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil}
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import com.sf.gis.java.base.pathSimilar
import java.lang

import scala.collection.mutable.ArrayBuffer

/**
 * 主机厂轨迹质量监控_V1.0
 * 需求方：杨汶铭（ft80006323）
 * @author 徐游飞（01417347）
 * 任务ID：753067
 * 任务名称：主机厂轨迹和任务轨迹比对
 */
object ZhuJiChangTrack {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
//  val TASKID_URL: String = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/queryByTaskid"
  val TASKID_URL: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/queryByTaskid"  // 新轨迹中台迁移 20230821
//  val HOST_URL: String = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"
  val HOST_URL: String = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"  // 新轨迹中台迁移 20230821
  val TarckAk: String = "93ec117f7f1b4226b4e537c4802319e9"
  val parallelism = 10
  val akMinuLimit = 4000

  def main(args: Array[String]): Unit = {

    val dayBefore1 = args(0)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    logger.error("++++++++  任务开始 20231016  ++++")
    execute(spark,dayBefore1)
    logger.error("++++++++  任务完成  ++++")

    spark.stop()
  }

  // 解析轨迹查询接口返回值
  def parseTrackQueryHttpData(ret: JSONObject): (String, String, Double, String,String,String) = {
    var history_path = new JSONArray()
    val tracks_arr = new ArrayBuffer[String]()
    val jpq_tracks_arr = new ArrayBuffer[String]()
    val tm_arr = new ArrayBuffer[String]()
    var offTime = -1.0
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        val msg = ret.getJSONObject("result").getString("msg")
        logger.error("获取轨迹查询接口数据失败: " + msg)
        return (codeStatue, s"请求失败: $msg", 0.0, null,null,null)
      } else {
        try{
          history_path = ret.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          offTime = ret.getJSONObject("result").getJSONObject("data").getJSONObject("rate").getDouble("offTime")
        }catch {
          case e: Exception => logger.error(e)
        }
        // 循环获取轨迹点
        for(i <- 0 until history_path.size()){
          val track = history_path.getJSONObject(i)
          val dx = track.getDouble("dx")
          val dy = track.getDouble("dy")
          val tm = track.getString("tm")
          val zx = track.getDouble("zx")
          val zy = track.getDouble("zy")

          tracks_arr.append(s"""[$dx,$dy]""")
          jpq_tracks_arr.append(s"""[$zx,$zy]""")
          tm_arr.append(tm)
        }
        val task_tracks_tmp = tracks_arr.mkString(",")
        val task_tracks = s"""[$task_tracks_tmp]"""

        val task_tracks_tmp_jpq = jpq_tracks_arr.mkString(",")
        val task_tracks_jpq = s"""[$task_tracks_tmp_jpq]"""

        val task_tm = tm_arr.mkString(",")

        return (codeStatue,"成功",offTime,task_tracks,task_tracks_jpq,task_tm)
      }
    }
    ("22", "请求失败,接口返回值为空", 0.0, null,null,null)

  }

  /**
   * 调用任务轨迹接口和融合轨迹接口
   * @param spark
   * @param dataDF
   */
  def runTrackQueryByTaskIdInteface(ak:String, obj: JSONObject): JSONObject = {
    val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
    val vin = JSONUtil.getJsonVal(obj, "vin", "")
    val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
    val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
    val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")

    // 将时间戳转换成接口需要的格式
    val beginDateTime = timeToCustomTime(actual_depart_tm,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")
    val endDateTime = timeToCustomTime(actual_arrive_tm,"yyyy-MM-dd HH:mm:ss","yyyyMMddHHmmss")

    // 任务轨迹接口请求参数
    val param_1 = new JSONObject()
    param_1.put("un", vehicle_serial)
    param_1.put("taskId", task_id)
    param_1.put("beginDateTime", beginDateTime)
    param_1.put("endDateTime", endDateTime)
    param_1.put("rectify", "true")
    param_1.put("type", "0")
    param_1.put("ak", ak)

    // 融合轨迹接口请求参数
    val param_2 = new JSONObject()
    param_2.put("un", vin)
    param_2.put("beginDateTime", beginDateTime)
    param_2.put("endDateTime", endDateTime)
    param_2.put("hasRate", "true")
    param_2.put("offTime", "120")
    param_2.put("type", "381")
    param_2.put("unType", "1")
    param_2.put("ak", ak)

    var retJSONObject_1 = new JSONObject()
    var retJSONObject_2 = new JSONObject()
    try {
      // 调任务轨迹接口获取任务轨迹
      val retStr_1: String = HttpInvokeUtil.sendPost(TASKID_URL,param_1.toJSONString)
      retJSONObject_1 = JSON.parseObject(retStr_1)

      // 调融合轨迹接口获取主机厂轨迹
      val retStr_2: String = HttpInvokeUtil.sendPost(HOST_URL,param_2.toJSONString)
      retJSONObject_2 = JSON.parseObject(retStr_2)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析任务轨迹接口返回值,获取任务轨迹
    val httpData_task: (String,String,Double,String,String,String) = parseTrackQueryHttpData(retJSONObject_1)
    //融合轨迹接口返回值,获取主机厂轨迹
    val httpData_integrate: (String,String,Double,String,String,String) = parseTrackQueryHttpData(retJSONObject_2)

    obj.put("task_tracks",httpData_task._4)
    obj.put("host_tracks",httpData_integrate._4)
    obj.put("halfway_integrate_rate",httpData_integrate._3)

    // 辅助字段
    val url_1 = s"""${TASKID_URL}:${param_1.toJSONString}"""
    val url_2 = s"""${HOST_URL}:${param_2.toJSONString}"""
    obj.put("codeStatue_1",httpData_task._1)
    obj.put("msg_1",httpData_task._2)
    obj.put("url_1",url_1)
    obj.put("codeStatue_2",httpData_integrate._1)
    obj.put("msg_2",httpData_integrate._2)
    obj.put("url_2",url_2)

    obj
  }

  def getDataSource(spark: SparkSession, dayBefore1: String) = {
    import spark.implicits._
    val vms_sql =
      s"""
         |select
         |  vehicle_code as vehicle_serial,
         |  brand_model,
         |  vin,
         |  model,
         |  dept_id
         |from
         |  ods_vms.tm_vms_vehicle
         |where
         |  inc_day = '$dayBefore1'
         |""".stripMargin
    println(vms_sql)
    val df_vms = spark.sql(vms_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('vehicle_serial).orderBy(desc("vin"))))
      .filter('rn === 1)
      .drop("rn")

    val dept_sql =
      s"""
         |select
         |  dept_id,
         |  dept_code
         |from
         |  dm_tc_waybillinfo.tm_department
         |""".stripMargin
    println(dept_sql)
    val df_dept = spark.sql(dept_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('dept_id).orderBy(desc("dept_code"))))
      .filter('rn === 1)
      .drop("rn")

    val vehicle_sql =
      s"""
         |select
         |  vehicle_code as vehicle_serial,
         |  used_kind
         |from
         |  ods_grd.tm_my_vehicle
         |where
         |  inc_day = '$dayBefore1'
         |  and used_kind in (1,2)
         |""".stripMargin
    println(vehicle_sql)
    val df_vehicle = spark.sql(vehicle_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('vehicle_serial).orderBy(desc("used_kind"))))
      .filter('rn === 1)
      .drop("rn")

    val recall1_sql =
      s"""
         |select
         |  task_id
         |  ,task_area_code
         |  ,start_dept
         |  ,end_dept
         |  ,line_code
         |  ,vehicle_serial
         |  ,plan_depart_tm
         |  ,actual_depart_tm
         |  ,plan_arrive_tm
         |  ,actual_arrive_tm
         |  ,carrier_type
         |  ,is_stop
         |  ,if_error
         |  ,carrier_name
         |  ,accrual_dist
         |  ,actual_run_time
         |  ,last_update_tm
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day = '$dayBefore1'
         |  and actual_run_time > 10
         |""".stripMargin
    println(recall1_sql)
    val df_recall1 = spark.sql(recall1_sql)
      .withColumn("rn", row_number().over(Window.partitionBy('task_id).orderBy(desc("last_update_tm"))))
      .filter('rn === 1)
      .drop("rn")

    (df_vms,df_dept,df_vehicle,df_recall1)
  }

  def getHistoryCoords(spark: SparkSession) = {
    import spark.implicits._
    // 获取线下车辆时间数据
    val df_vehicle_time: DataFrame = spark.read
      .format("csv")
      .option("sep", ",")
      .option("header", "true")
      .option("inferSchema", "true")
      .load("/user/01417347/upload/data/vehicle_time.csv")

    val track_3y_sql =
      s"""
         |select
         |  un as vehicle_serial,
         |  cast(tm as bigint) * 1000 as tm,
         |  zx,
         |  zy
         |from
         |  dm_gis.freight_nw_track_3y
         |where
         |  inc_day >= '20210401'
         |  and inc_day <= '20210801'
         |""".stripMargin
    println(track_3y_sql)
    val df_track_3y = spark.sql(track_3y_sql)

    val df_history = df_vehicle_time.join(df_track_3y,Seq("vehicle_serial"),"left")
      .withColumn("arrive_tm",tranTimeToLong('arrive_tm,lit("yyyy-MM-dd HH:mm:ss")))
      .withColumn("depart_tm",tranTimeToLong('depart_tm,lit("yyyy-MM-dd HH:mm:ss")))
      .filter('tm > 'depart_tm && 'tm < 'arrive_tm)
      .withColumn("rn", row_number().over(Window.partitionBy("vehicle_serial","tm","zx","zy").orderBy(desc("tm"))))
      .filter('rn === 1) //去重
      .withColumn("num", row_number().over(Window.partitionBy('vehicle_serial).orderBy(asc("tm"))))
      .withColumn("coords",concat_ws(",",'zx,'zy))
      .groupBy("vehicle_serial","depart_tm","arrive_tm")
      .agg(
        min("tm") as "actual_depart_tm",
        max("tm") as "actual_arrive_tm",
        // 分组内的字段的全部值用|拼接
        concat_ws("|",collect_list('num)) as "num",
        concat_ws("|",collect_list('coords)) as "coords"
      )
      // 分组内的字段拼接值按照num顺序重新排序
      .withColumn("coords",sortField('num,'coords))

    df_history
  }

  def execute(spark: SparkSession, dayBefore1: String) = {

    import spark.implicits._
    val dataSource = getDataSource(spark,dayBefore1)
    val df_vms = dataSource._1
    val df_dept = dataSource._2
    val df_vehicle = dataSource._3
    val df_recall1 = dataSource._4

//    val df_history = getHistoryCoords(spark)

    val df_join = df_recall1
      .join(df_vms,Seq("vehicle_serial"),"left")
      .join(df_vehicle,Seq("vehicle_serial"),"left")
      .join(df_dept,Seq("dept_id"),"left")
      .withColumn("vehicle_type",when('vin.isNotNull,"自营").when('used_kind.isNotNull,"共建").otherwise(""))
      .withColumn("filter_flag",when('vin.isNotNull,0).otherwise(1))
      .withColumn("inc_day",lit(dayBefore1))
      .persist(StorageLevel.MEMORY_AND_DISK)

    // vin为空的数据直接赋默认值
    val df_join_null = df_join.filter('filter_flag === 1)
      .withColumn("halfway_integrate_rate",lit(0.0))
      .withColumn("tracks_error",lit("是"))
      .withColumn("source",when('if_error =!= "0","任务&主机厂轨迹均异常").otherwise("主机厂轨迹异常"))
      .withColumn("reason",when('if_error =!= "0",concat_ws("|",'if_error,lit("无轨迹上传"),lit("未获取到车架号")))
        .otherwise(concat_ws("|",lit("无轨迹上传"),lit("未获取到车架号"))))
      .withColumn("matching",lit("不匹配"))
      .withColumn("sim1",lit(0.0))
      .withColumn("sim5",lit(0.0))
      .select("task_id","task_area_code","start_dept","end_dept","line_code","vehicle_serial","accrual_dist","plan_depart_tm","actual_depart_tm",
        "plan_arrive_tm","actual_arrive_tm","carrier_type","is_stop","if_error","carrier_name","vin","dept_code","brand_model","model","vehicle_type",
        "halfway_integrate_rate","tracks_error","source","reason","matching","sim1","sim5","inc_day")

    val invokeCnt = df_join.filter('filter_flag === 0).count()
    val httpInvokeId_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "753067", "主机厂轨迹和任务轨迹比对", "轨迹上传质量对比", TASKID_URL, TarckAk, invokeCnt, parallelism)
    val httpInvokeId_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417347", "753067", "主机厂轨迹和任务轨迹比对", "轨迹上传质量对比", HOST_URL, TarckAk, invokeCnt, parallelism)
    // vin不为空的数据跑轨迹查询接口
    val rdd_join = SparkNet.runInterfaceWithAkLimit(spark, df_join.filter('filter_flag === 0).rdd.map(row2Json), runTrackQueryByTaskIdInteface, parallelism, TarckAk, akMinuLimit)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_1)
    BdpTaskRecordUtil.endNetworkInterface("01417347", httpInvokeId_2)

    val df_ret = rdd_join.map(obj => {
      val if_error = JSONUtil.getJsonVal(obj, "if_error", "")
      val halfway_integrate_rate = JSONUtil.getJsonDouble(obj, "halfway_integrate_rate", 0.0)
      val task_tracks = JSONUtil.getJsonVal(obj, "task_tracks", "")
      val host_tracks = JSONUtil.getJsonVal(obj, "host_tracks", "")
      val accrual_dist = JSONUtil.getJsonDouble(obj, "accrual_dist", 0.0) / 1000 // 单位转换成KM
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val task_area_code = JSONUtil.getJsonVal(obj, "task_area_code", "")
      val start_dept = JSONUtil.getJsonVal(obj, "start_dept", "")
      val end_dept = JSONUtil.getJsonVal(obj, "end_dept", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val vehicle_serial = JSONUtil.getJsonVal(obj, "vehicle_serial", "")
      val plan_depart_tm = JSONUtil.getJsonVal(obj, "plan_depart_tm", "")
      val actual_depart_tm = JSONUtil.getJsonVal(obj, "actual_depart_tm", "")
      val plan_arrive_tm = JSONUtil.getJsonVal(obj, "plan_arrive_tm", "")
      val actual_arrive_tm = JSONUtil.getJsonVal(obj, "actual_arrive_tm", "")
      val carrier_type = JSONUtil.getJsonVal(obj, "carrier_type", "")
      val is_stop = JSONUtil.getJsonVal(obj, "is_stop", "")
      val carrier_name = JSONUtil.getJsonVal(obj, "carrier_name", "")
      val vin = JSONUtil.getJsonVal(obj, "vin", "")
      val brand_model = JSONUtil.getJsonVal(obj, "brand_model", "")
      val model = JSONUtil.getJsonVal(obj, "model", "")
      val inc_day = JSONUtil.getJsonVal(obj, "inc_day", "")
      val dept_code = JSONUtil.getJsonVal(obj, "dept_code", "")
      val vehicle_type = JSONUtil.getJsonVal(obj, "vehicle_type", "")

      // tracks_error 标签
      var tracks_error = "否"
      if (!if_error.equals("0") || halfway_integrate_rate < 0.9) {
        tracks_error = "是"
      }

      // source 和 reason 标签
      var source = ""
      val error_type_arr = new ArrayBuffer[String]()
      if (!if_error.equals("0") && halfway_integrate_rate < 0.9) {
        source = "任务&主机厂轨迹均异常"
        error_type_arr.append(if_error)
        error_type_arr.append("8")
      } else if (!if_error.equals("0")) {
        source = "任务轨迹异常"
        error_type_arr.append(if_error)
      } else if (halfway_integrate_rate < 0.9) {
        source = "主机厂轨迹异常"
        error_type_arr.append("8")
      }
      val reason = error_type_arr.mkString("|")

      // 计算轨迹相似度和 matching 标签
      var sim1 = 0.0
      var sim5 = 0.0
      var matching = "不匹配"
      if (tracks_error.equals("否")) {
        // 调用jar包计算相似度
        val task_obj = new JSONObject()
        val host_obj = new JSONObject()
        task_obj.put("rt_coords",task_tracks)
        host_obj.put("rt_coords",host_tracks)
        val simil: pathSimilar.Tuple2[lang.Double, lang.Double] = pathSimilar.PathSimilar.simProcess(task_obj, host_obj)
        sim1 = simil.first
        sim5 = simil.second

        if (accrual_dist > 500) {
          if ((sim1 >= 0.9 || sim5 >= 0.9) && (sim1 > 0.85 && sim5 > 0.85)) {
            matching = "匹配"
          }
        } else if (accrual_dist > 100 && accrual_dist <= 500) {
          if ((sim1 >= 0.85 || sim5 >= 0.85) && (sim1 > 0.8 && sim5 > 0.8)) {
            matching = "匹配"
          }
        } else if (accrual_dist > 50 && accrual_dist <= 100) {
          if ((sim1 >= 0.8 || sim5 >= 0.8) && (sim1 > 0.75 && sim5 > 0.75)) {
            matching = "匹配"
          }
        } else if (accrual_dist > 10 && accrual_dist <= 50) {
          if ((sim1 >= 0.75 || sim5 >= 0.75) && (sim1 > 0.7 && sim5 > 0.7)) {
            matching = "匹配"
          }
        } else if (accrual_dist > 5 && accrual_dist <= 10) {
          if ((sim1 >= 0.6 || sim5 >= 0.6) && (sim1 > 0.5 && sim5 > 0.5)) {
            matching = "匹配"
          }
        }
      }

      HostTrack(task_id,task_area_code,start_dept,end_dept,line_code,vehicle_serial,accrual_dist,plan_depart_tm,actual_depart_tm,plan_arrive_tm,
        actual_arrive_tm,carrier_type,is_stop,if_error,carrier_name,vin,dept_code,brand_model,model,vehicle_type,halfway_integrate_rate,tracks_error,
        source,reason,matching,sim1,sim5,inc_day)
    }).toDF()
      .select("task_id","task_area_code","start_dept","end_dept","line_code","vehicle_serial","accrual_dist","plan_depart_tm","actual_depart_tm",
        "plan_arrive_tm","actual_arrive_tm","carrier_type","is_stop","if_error","carrier_name","vin","dept_code","brand_model","model","vehicle_type",
        "halfway_integrate_rate","tracks_error","source","reason","matching","sim1","sim5","inc_day")
      .union(df_join_null)  // 与车架号为空的数据合并
      .withColumn("depart_tm",lit(""))
      .withColumn("arrive_tm",lit(""))
      .withColumn("actual_depart_tm2",lit(""))
      .withColumn("actual_arrive_tm2",lit(""))
      .withColumn("coords",lit(""))

    val cols = spark.sql("""select * from dm_gis.zhujichang_track limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_ret.select(cols: _*),Seq("inc_day"),"dm_gis.zhujichang_track")

  }

  case class HostTrack(
                        task_id : String,
                        task_area_code : String,
                        start_dept : String,
                        end_dept : String,
                        line_code : String,
                        vehicle_serial : String,
                        accrual_dist : Double,
                        plan_depart_tm : String,
                        actual_depart_tm : String,
                        plan_arrive_tm : String,
                        actual_arrive_tm : String,
                        carrier_type : String,
                        is_stop : String,
                        if_error : String,
                        carrier_name : String,
                        vin : String,
                        dept_code : String,
                        brand_model : String,
                        model : String,
                        vehicle_type : String,
                        halfway_integrate_rate : Double,
                        tracks_error : String,
                        source : String,
                        reason : String,
                        matching : String,
                        sim1 : Double,
                        sim5 : Double,
                        inc_day : String
                      )

}
