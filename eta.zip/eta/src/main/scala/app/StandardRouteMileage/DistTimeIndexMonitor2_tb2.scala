package app.StandardRouteMileage

import Utils.SparkUtils
import app.StandardRouteMileage.DistTimeIndexMonitor2.{ getRes1table, processGjRectify, saveTable2}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 **需求名称：标准线路指标监控需求tb2
 **任务id：840831
 **需求方：01369612张翠霞
 **研发：01401062徐千皓，迭代：01390943周勇
 **需求背景：标准线路指标监控需求，外包承运商执行判断优化。
 **/

object DistTimeIndexMonitor2_tb2 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {
    //接收日期参数
    val inc_day =args(0)
    //开始执行
    start(inc_day)
  }

  //执行函数列表
  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("DistTimeMonitor2_tb2")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    //写入结果表2：dm_gis.eta_std_line_rectify
    val getRes1Rdd= getRes1table(spark,inc_day)
    val getGjTable = processGjRectify(spark,getRes1Rdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    getGjTable.take(2).foreach(println(_))
    saveTable2(spark,inc_day,getGjTable)

    logger.error("统计结束")
    spark.close()
  }

}
