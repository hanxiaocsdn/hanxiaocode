package app.StandardRouteMileage

import Utils._
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.eta.constant.StandardRouteMileage.DistanceTool
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2022/1/12
*/

object Distance500DataProcess {
  @transient lazy val logger: Logger = Logger.getLogger(Distance500DataProcess.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")


  val getDeptCodeUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/getDept"

  val getSchemaRouteUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&cc=1&opt=sf2&type=0&strategy=0&vehicle=%s&ak=8bb09e5e110845f39a000391668e3e80&x1=%s&y1=%s&x2=%s&y2=%s"


  case class res (
                   stdid:String,src_deptcode:String,dest_deptcode:String,line_code:String,plan_time:String,vehicle:String,
                   is_econ:String,route_index:String,track_start_x:String,track_start_y:String,track_end_x:String,track_end_y:String,
                   rt_distance:String,src_dept_x:String,src_dept_y:String,dest_dept_x:String,dest_dept_y:String,start_distance:String,end_distance:String,
                   start_rt_distance:String,end_rt_distance:String,start_track:String,end_track:String,inc_day:String
                 )




  def main(args: Array[String]): Unit = {
    val inc_day = args(0)
//    val url = String.format(getSchemaRouteUrl.toString, 6.toString, track_start_x.toString, track_start_y.toString, dest_dept_x.toString, dest_dept_y.toString)
//    val resp = Utils.retryGet(url)
//    val (end_track_new,end_rt_distance_new) = parseTrack(resp)


//    val url = String.format(getSchemaRouteUrl, 7.toString, 113.1392189934283.toString, 22.514730789347227.toString, 113.23329522633844.toString,22.510829116983945.toString)
//    val resp = Utils.retryGet(url)
//    val (start_track,start_rt_distance) = parseTrack(resp)
//    println(resp)
//    println(start_track)
//    println(start_rt_distance)

    start(inc_day)

  }
  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    startSta(spark,inc_day)
    logger.error("统计结束")


  }

  def getSourceRdd(spark: SparkSession, inc_day: String) = {

//    val sourceSql =
//      s"""
//         |select
//         |  std_id,src_deptcode,dest_deptcode,line_code,plan_time,vehicle,is_econ,route_index,
//         |  track_start_x,track_start_y,track_end_x,track_end_y,rt_distance
//         |from
//         |  dm_gis.eta_std_line_conf
//         |where
//         |  delete_flag = 0
//       """.stripMargin

    val sourceSql =
      s"""
         |select
         |  stdid std_id,src_deptcode,dest_deptcode,line_code,plan_time,vehicle,is_econ,route_index,
         |  track_start_x,track_start_y,track_end_x,track_end_y,rt_distance
         |from
         |  dm_gis.eta_route_distance_over500_cal
         |where
         |  inc_day = '20220110'
         |and
         |  src_dept_x != 0.0
         |and
         |  dest_dept_x = 0.0
       """.stripMargin

    val sourceRdd = SparkUtils.getRowToJson(spark.sql(sourceSql),"MEM")

    sourceRdd

  }

  def parseXY(response: String):(Double,Double) = {

    try {
      val resp = JSON.parseObject(response)
      val result = resp.getJSONObject("result")
      val x = result.getDouble("lon")
      val y = result.getDouble("lat")
      (x,y)
    } catch {
      case e:Exception => (0.0,0.0)
    }



  }

  def parseTrack(resp: String) = {

    var returnBuffer = ""
    var returnDist = ""

    try {
      if (StringUtils.nonEmpty(resp)) {
        if (JSONUtils.isValidJSON(resp)) {
          val response = JSON.parseObject(resp)
          val rt_status = response.getInteger("status")
          val result = response.getJSONObject("result")

          val dist = result.getString("dist")
          returnDist = dist
          val rt_coords = result.getJSONArray("coords")

          val arrayBuffer = new ArrayBuffer[String]()



          for (i <- (0 until rt_coords.size())) {

            val array = rt_coords.getJSONArray(i)
            val x = array.getString(0)
            val y = array.getString(1)


            arrayBuffer.append(x)
            arrayBuffer.append(",")
            arrayBuffer.append(y)
            arrayBuffer.append("|")
          }


          returnBuffer = arrayBuffer.mkString("")
        }
      }
    }catch {
      case e: Exception => returnBuffer = e.getMessage  + "response为：" + resp
    }

    (returnBuffer,returnDist)
  }

  def calProcessDistance(sourceRdd: RDD[JSONObject]) = {
//    val resRdd = SparkUtils.akLimitMultiThreadRdd(sourceRdd)(x => x)(10000,100)

    val calRdd = sourceRdd.repartition(5).map(x => {

      val src_deptcode = x.getString("src_deptcode")
      val dest_deptcode = x.getString("dest_deptcode")

      val track_start_x = JSONUtils.getJsonValueDouble(x,"track_start_x",0)
      val track_start_y = JSONUtils.getJsonValueDouble(x,"track_start_y",0)

      val track_end_x = JSONUtils.getJsonValueDouble(x,"track_end_x",0)
      val track_end_y = JSONUtils.getJsonValueDouble(x,"track_end_y",0)

      val is_econ = JSONUtils.getJsonValueInt(x,"is_econ",0)
      val vehicle = x.getString("vehicle")


      var start_track = ""
      var end_track = ""
      var start_rt_distance = ""
      var end_rt_distance = ""


      val srcJson = new JSONObject()
      srcJson.put("ak","8bb09e5e110845f39a000391668e3e80")
      srcJson.put("deptCode",src_deptcode)

      val destJson = new JSONObject()
      destJson.put("ak","8bb09e5e110845f39a000391668e3e80")
      destJson.put("deptCode",dest_deptcode)

      val response1 = Utils.retryPost(getDeptCodeUrl,srcJson,logger)
      val response2 = Utils.retryPost(getDeptCodeUrl,destJson,logger)

      val (src_dept_x,src_dept_y) = parseXY(response1)
      val (dest_dept_x,dest_dept_y) = parseXY(response2)




      val start_distance = DistanceTool.getGreatCircleDistance(track_start_x,track_start_y,src_dept_x,src_dept_y)
      val end_distance = DistanceTool.getGreatCircleDistance(track_end_x,track_end_y,dest_dept_x,dest_dept_y)


      if (start_distance > 500 && is_econ == 3){
//        &vehicle=%s&ak=8bb09e5e110845f39a000391668e3e80&x1=%s&y1=%s&x2=%s&y2=%s
        val url = String.format(getSchemaRouteUrl, vehicle, src_dept_x.toString, src_dept_y.toString,track_start_x.toString, track_start_y.toString)
        val resp = Utils.retryGet(url)
        val (start_track_new,start_rt_distance_new) = parseTrack(resp)
        start_track = start_track_new
        start_rt_distance = start_rt_distance_new
      }

      if (end_distance > 500 && is_econ == 3){
        //        &vehicle=%s&ak=8bb09e5e110845f39a000391668e3e80&x1=%s&y1=%s&x2=%s&y2=%s
        val url = String.format(getSchemaRouteUrl.toString, vehicle, track_end_x.toString, track_end_y.toString, dest_dept_x.toString, dest_dept_y.toString)
        val resp = Utils.retryGet(url)
        val (end_track_new,end_rt_distance_new) = parseTrack(resp)
        end_track = end_track_new
        end_rt_distance = end_rt_distance_new
      }


      x.put("src_dept_x",src_dept_x)
      x.put("src_dept_y",src_dept_y)
      x.put("dest_dept_x",dest_dept_x)
      x.put("dest_dept_y",dest_dept_y)

      x.put("start_distance",start_distance)
      x.put("end_distance",end_distance)
      x.put("start_rt_distance",start_rt_distance)
      x.put("end_rt_distance",end_rt_distance)
      x.put("start_track",start_track)
      x.put("end_track",end_track)

      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    calRdd


  }


  def saveToHive(spark: SparkSession, inc_day: String, calRdd: RDD[JSONObject]) = {

    val resRdd = calRdd.map(x => {

      val stdid= x.getString("std_id")
      val src_deptcode= x.getString("src_deptcode")
      val dest_deptcode= x.getString("dest_deptcode")
      val line_code= x.getString("line_code")
      val plan_time= x.getString("plan_time")
      val vehicle= x.getString("vehicle")
      val is_econ= x.getString("is_econ")
      val route_index= x.getString("route_index")
      val track_start_x= x.getString("track_start_x")
      val track_start_y= x.getString("track_start_y")
      val track_end_x= x.getString("track_end_x")
      val track_end_y= x.getString("track_end_y")
      val rt_distance= x.getString("rt_distance")
      val src_dept_x= x.getString("src_dept_x")
      val src_dept_y= x.getString("src_dept_y")
      val dest_dept_x= x.getString("dest_dept_x")
      val dest_dept_y= x.getString("dest_dept_y")
      val start_distance= x.getString("start_distance")
      val end_distance= x.getString("end_distance")
      val start_rt_distance= x.getString("start_rt_distance")
      val end_rt_distance= x.getString("end_rt_distance")
      val start_track= x.getString("start_track")
      val end_track= x.getString("end_track")


      res(stdid,src_deptcode,dest_deptcode,line_code,plan_time,vehicle,is_econ,route_index,
        track_start_x,track_start_y,track_end_x,track_end_y,rt_distance,src_dept_x,src_dept_y,
        dest_dept_x,dest_dept_y,start_distance,end_distance,start_rt_distance,end_rt_distance
        ,start_track,end_track,inc_day)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("结果数据量为：" + resRdd.count())
    resRdd.take(2).foreach(println(_))

    import spark.implicits._
    resRdd.toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_route_distance_over500_cal")


  }

  def startSta(spark: SparkSession, inc_day: String) = {

    val sourceRdd = getSourceRdd(spark,inc_day)

    val calRdd = calProcessDistance(sourceRdd)

    val saveRdd = saveToHive(spark,inc_day,calRdd)

  }


}
