package app.StandardRouteMileage

import Utils.SparkUtils
import app.StandardRouteMileage.DistTimeIndexMonitor2.{addFilterProcess, calRecallRateStat, getJoin1to5, getJoinDriverInfo, getSourceRecall,  saveTable6, saveTableRecall2}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

/**
 **需求名称：标准线路指标监控需求tbrecal
 **任务id：
 **需求方：01369612张翠霞
 **研发：01401062徐千皓，迭代：01390943周勇
 **需求背景：标准线路指标监控需求，外包承运商执行判断优化。
 **/

object DistTimeIndexMonitor2_recall {

  @transient lazy val logger: Logger = Logger.getLogger(DistTimeIndexMonitor2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //  val logger: Logger = Logger.getLogger(appName)

  val descMysqlUserName = "gis_oms_pns"
  val descMysqlPassWord = "gis_oms_pns@123@"
  val descMysqlUrl = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?characterEncoding=utf-8"

  def main(args: Array[String]): Unit = {
    //接收日期参数
    val inc_day =args(0)
    //开始执行
    start(inc_day)
  }

  //执行函数列表
  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("DistTimeMonitor2_recall")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    // 生成recall表
    val getJoin1to5Rdd = getJoin1to5(spark,inc_day)
    // 20220808新增关联司机信息表
    val joinDriverInfoRdd = getJoinDriverInfo(spark,inc_day,getJoin1to5Rdd)
    //    val joinDriverInfoRdd =getJoin1to5Rdd
    // 扯线异常修复
    val addFilterProcessRdd = addFilterProcess(spark,joinDriverInfoRdd)
    //写入结果表6：dm_gis.eta_std_line_recall
    saveTable6(spark,inc_day,addFilterProcessRdd)

    // 回溯表
    //写入表：dm_gis.eta_std_line_recall1
    val recallSourceRdd = getSourceRecall(spark,inc_day)
    val recallRdd = calRecallRateStat(recallSourceRdd,inc_day)
    saveTableRecall2(spark,inc_day,recallRdd,logger)

    logger.error("统计结束")
    spark.close()
  }

}
