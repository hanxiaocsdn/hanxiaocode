package StandardRouteMileage

import Utils.{JSONUtils, StringUtils}
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer



object ExperienceRoute2 {
  @transient lazy val logger: Logger = Logger.getLogger(ExperienceRoute2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  def main(args: Array[String]): Unit = {
    //val inc_day =args(0)
    start()
  }

  def start(): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("local[4]")
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")
    startSta(spark)
    logger.error("统计完毕")
  }


  case class output(linecode:String,
                    vehicle_type:String,
                    src_deptcode:String,
                    dest_deptcode:String,
                    grp1:String,
                    routeid:String,
                    routeid_group:String,
                    grp2_grp3:String
                   )

  class SecondarySortByKey(val first:Int, val second:Int) extends Ordered[SecondarySortByKey] with Serializable{
    override def compare(that: SecondarySortByKey): Int = {
      if(this.first-that.first != 0){
        -(this.first - that.first)
      } else {
        -(this.second - that.second)
      }
    }
  }





  def startSta(spark:SparkSession): Unit ={

   val experience = spark.read.format("csv").option("header", "true").option("delimiter", "\t").load("/d:\\user\\01401062\\桌面\\生成配置\\020Y2_442_info_grp_match_econ2.csv").persist(StorageLevel.MEMORY_AND_DISK_SER)
   //val experience = spark.read.format("csv").option("header", "true").option("delimiter", "\t").load("/d:\\user\\01401062\\桌面\\experienceTest.csv").persist(StorageLevel.MEMORY_AND_DISK_SER)

    val colList = experience.columns

    val input = experience.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns,x.getAs[String](columns))
      }

      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    //input.take(2).foreach(println(_))

    val grp2_1  = input.filter(x => {
      x.getString("grp2_cnt").toInt >= 3
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val grp2_2  = input.filter(x => {
      x.getString("grp2_cnt").toInt == 2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val grp2_3  = input.filter(x => {
      x.getString("grp2_cnt").toInt == 1
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    val grp2_1_1 =  grp2_1.map(x => {
      val grp1 = x.getString("grp1")
      (grp1,x)
    }).groupByKey().map(x => {
        val routeid_group = new ArrayBuffer[((Int,Int),String,String)]()
        val grp1 = x._1
        val jsonArray = new JSONArray()
        val jsonArray2 = new JSONArray()
        val list = x._2.toList.groupBy(_.getString("grp2")).map(x => {
          val grp2 = x._1
          val list2 = x._2.toList
          val list3 = list2.sortBy(_.getIntValue("trk3_cnt")).reverse
          val jy_distance = JSONUtils.getJsonValueInt(list3(0),"jy_distance",0).toInt
          val trk3_cnt = JSONUtils.getJsonValueInt(list3(0),"trk3_cnt",0).toInt
          val jy_route_id = list3(0).getString("jy_route_id")
          val grp3 = list3(0).getString("grp3")

          val tuple3 = ((trk3_cnt,jy_distance),jy_route_id,grp3)
          routeid_group.add(tuple3)
        })

      val routid3 = routeid_group.filter(x => {!"".equals(x._2)}).sortBy(x => new SecondarySortByKey(x._1._1,x._1._2)).take(3).map(x => {
      if(StringUtils.nonEmpty(x._2)){
        if(!jsonArray.contains(x._2)) {
          jsonArray.add(x._2)
          jsonArray2.add(x._3)
        }
      }
      x})

      (grp1,jsonArray.toString(),jsonArray2.toString())

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    grp2_1_1.take(2).foreach(println(_))



    val grp2_2_1 =  grp2_2.map(x => {
      val grp1 = x.getString("grp1")
      (grp1,x)
    }).groupByKey().map(x =>{
      val grp1 = x._1
      val src = x._2.toIndexedSeq.groupBy(_.getString("grp2")).toArray
      val routeid_group = new ArrayBuffer[((Int,Int),String,String)]()
      val jsonArray = new JSONArray()
      val jsonArray2 = new JSONArray()

      var (grp,str,str2) = (x._1,"","")

      if (src.size> 1){
        val array1 = src(0)._2
        val array2 = src(1)._2

        //val aa = array1.sortBy(d=>d.getString("grp3_cnt")).reverse.map(_.getString("jy_route_id")).toArray
        val aa = array1.sortBy(d=>d.getIntValue("trk3_cnt")).reverse.map(x => {
          (x.getString("jy_route_id"),x.getString("grp3"),JSONUtils.getJsonValueInt(x,"trk3_cnt",0).toInt,JSONUtils.getJsonValueInt(x,"jy_distance",0).toInt)
        }).toArray
        val maxa = aa(0)._1
        val maxaGrp3 = aa(0)._2
       // println(aa.mkString(""))

        val bb = array2.sortBy(d=>d.getIntValue("trk3_cnt")).reverse.map(x => {
          (x.getString("jy_route_id"),x.getString("grp3"),JSONUtils.getJsonValueInt(x,"trk3_cnt",0).toInt,JSONUtils.getJsonValueInt(x,"jy_distance",0).toInt)
        }).toArray
        val maxb = bb(0)._1
        val maxbGrp3 = bb(0)._2
       // println(bb.mkString(""))


        val cc = array1.union(array2).filter(d=>{
          val id = d.getString("jy_route_id")
          id!=maxa && id != maxb
        }).sortBy(d=>d.getIntValue("trk3_cnt")).reverse.take(1).map(x => {
          (x.getString("jy_route_id"),x.getString("grp3"),JSONUtils.getJsonValueInt(x,"trk3_cnt",0).toInt,JSONUtils.getJsonValueInt(x,"jy_distance",0).toInt)
        }).toArray


        if (cc.length != 0){
          val maxc = cc(0)._1
          val maxcGrp3 = cc(0)._2
          if(StringUtils.nonEmpty(maxc)){
            routeid_group.append(((cc(0)._3,cc(0)._4),maxc,maxcGrp3))
          }
        }
        if(StringUtils.nonEmpty(maxa)){
          routeid_group.append(((aa(0)._3,aa(0)._4),maxa,maxaGrp3))
        }
        if(StringUtils.nonEmpty(maxb)){
          routeid_group.append(((bb(0)._3,bb(0)._4),maxb,maxbGrp3))
        }
      }
      val routid3 = routeid_group.filter(x => {!"".equals(x._2)}).sortBy(x => new SecondarySortByKey(x._1._1,x._1._2)).take(3).map(x => {
        if(StringUtils.nonEmpty(x._2)){
          if(!jsonArray.contains(x._2)) {
            jsonArray.add(x._2)
            jsonArray2.add(x._3)
          }
        }
        x})

      (grp1,jsonArray.toString(),jsonArray2.toString())

    }).filter(x => {StringUtils.nonEmpty(x._2)}).persist(StorageLevel.MEMORY_AND_DISK_SER)

    grp2_2_1.take(2).foreach(println(_))

//    val grp2_2_1 =  grp2_2.map(x => {
//      val grp1 = x.getString("grp1")
//      (grp1,x)
//    }).groupByKey().map(x =>{
//     val grp1 = x._1
//      val src = x._2.toIndexedSeq.groupBy(_.getString("grp2")).toArray
//      var (grp,str,str2) = (x._1,"","")
//
//      if (src.size> 1){
//
//        val array1 = src(0)._2
//        val array2 = src(1)._2
//
//        //val aa = array1.sortBy(d=>d.getString("grp3_cnt")).reverse.map(_.getString("jy_route_id")).toArray
//        val aa = array1.sortBy(d=>d.getString("grp3_cnt")).reverse.map(x => {
//          (x.getString("jy_route_id"),x.getString("grp3"))
//        }).toArray
//        val maxa = aa(0)._1
//        val maxaGrp3 = aa(0)._2
//        //val bb = array2.sortBy(d=>d.getString("grp3_cnt")).reverse.map(_.getString("jy_route_id")).toArray
//        val bb = array2.sortBy(d=>d.getString("grp3_cnt")).reverse.map(x => {
//          (x.getString("jy_route_id"),x.getString("grp3"))
//        }).toArray
//        val maxb = bb(0)._1
//        val maxbGrp3 = bb(0)._2
//
//        val jSONArray = new JSONArray()
//        val jSONArray2 = new JSONArray()
//        val cc = array1.union(array2).filter(d=>{
//          val id = d.getString("jy_route_id")
//          id!=maxa && id != maxb
//        }).sortBy(d=>d.getString("grp3_cnt")).reverse.take(1).map(x => {
//          (x.getString("jy_route_id"),x.getString("grp3"))
//        }).toArray
//
////        val cc = array1.union(array2).filter(d=>{
////          val id = d.getString("jy_route_id")
////          id!=maxa && id != maxb
////        }).sortBy(d=>d.getString("grp3_cnt")).reverse.take(1).map(_.getString("jy_route_id")).toArray
//        if (cc.length != 0){
//          val maxc = cc(0)._1
//          val maxcGrp3 = cc(0)._2
//          if(StringUtils.nonEmpty(maxc)){
//            jSONArray.add(maxc)
//            jSONArray2.add(maxcGrp3)
//          }
//        }
//        if(StringUtils.nonEmpty(maxa)){
//          jSONArray.add(maxa)
//          jSONArray2.add(maxaGrp3)
//        }
//        if(StringUtils.nonEmpty(maxb)){
//          jSONArray.add(maxb)
//          jSONArray2.add(maxbGrp3)
//        }
//        str=jSONArray.toString()
//        str2=jSONArray2.toString()
//        (grp1,jSONArray.toString(),jSONArray2.toString())
//      }
//      (grp,str,str2)
//    }).filter(x => {StringUtils.nonEmpty(x._2)}).persist(StorageLevel.MEMORY_AND_DISK_SER)




    val grp2_3_1 =  grp2_3.map(x => {
      val grp1 = x.getString("grp1")
      (grp1,x)
    }).groupByKey().map(x => {
      val routeid_group = new ArrayBuffer[((Int,Int),String,String)]()
      val grp1 = x._1
      val jsonArray = new JSONArray()
      val jsonArray2 = new JSONArray()
      val list = x._2.toList.groupBy(_.getString("grp2")).map(x => {
        val grp2 = x._1
        val list2 = x._2.toList
        val list3 = list2.sortBy(_.getIntValue("trk3_cnt")).reverse.take(3)
        list3.map(x => {
          val jy_distance = JSONUtils.getJsonValueInt(x,"jy_distance",0).toInt
          val trk3_cnt = JSONUtils.getJsonValueInt(x,"trk3_cnt",0).toInt
          val jy_route_id = x.getString("jy_route_id")
          val grp3 = x.getString("grp3")
          val tuple3 = ((trk3_cnt,jy_distance),jy_route_id,grp3)
          routeid_group.add(tuple3)
        })

      })
      val routid3 = routeid_group.filter(x => {!"".equals(x._2)}).sortBy(x => new SecondarySortByKey(x._1._1,x._1._2)).take(3).map(x => {
        if(StringUtils.nonEmpty(x._2)){
          if(!jsonArray.contains(x._2)){
            jsonArray.add(x._2)
            jsonArray2.add(x._3)
          }
        }
        x})
      (grp1,jsonArray.toString(),jsonArray2.toString())
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    grp2_3_1.take(2).foreach(println(_))



    val grp1_out = input.map(x => {(x.getString("grp1"),x)}).groupByKey()
      .flatMap(x => {
        val list = x._2.toList
        val list2 = x._2.toList.take(1)
        val josnArray = new JSONArray()
        list.map(x => {
          val grp2 = x.getString("grp2")
          val grp3 = x.getString("grp3")
          val grp2_3 = grp2 + "|" + grp3
          josnArray.add(grp2_3)
        })
        list2.map(x =>{
          x.put("grp2_3", josnArray)
        })
        list2
    }).map(x => {
      val grp1 = x.getString("grp1")
      (grp1,x)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
   // grp1_out.take(2).foreach(println(_))



//    val grp2_3_1 =  grp2_3.map(x => {
//      val grp3 = x.getString("grp3")
//      (grp3,x)
//    }).groupByKey().flatMap(x =>{
//      val grp3 = x._1
//      val list = x._2.toList.sortBy(_.getString("trk3_cnt")).reverse.take(1)
//      list
//    }).map(
//      x => {
//        val grp1 = x.getString("grp1")
//        (grp1, x)
//      }).groupByKey().flatMap(x => {
//      val grp1 = x._1
//      val list = x._2
//      val list2 = list.map(_.getString("jy_route_id")).mkString("")
//      val jSONArray = new JSONArray()
//      val jSONArray2 = new JSONArray()
//
//      list.map(x => {
//        (x.getString("jy_route_id"),x.getString("grp3"))
//      }).map(x =>
//        if(StringUtils.nonEmpty(x._1)){
//          jSONArray.add(x._1)
//          jSONArray2.add(x._2)
//        })
//      list.map(x => {
//        x.put("routeid_group",jSONArray)
//        x.put("grp3_group",jSONArray2)
//      })
//      list
//    }).map(x =>{(x.getString("grp1"),x.getString("routeid_group"),x.getString("grp3_group"))}).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    grp2_3_1.take(2).foreach(println(_))
//
//
//    val grp1_out = input.map(x => {(x.getString("grp1"),x)}).groupByKey()
//      .flatMap(x => {
//        val list = x._2.toList
//        val list2 = x._2.toList.take(1)
//        val josnArray = new JSONArray()
//        list.map(x => {
//          val grp2 = x.getString("grp2")
//          val grp3 = x.getString("grp3")
//          val grp2_3 = grp2 + "|" + grp3
//          josnArray.add(grp2_3)
//        })
//        list2.map(x =>{
//          x.put("grp2_3", josnArray)
//        })
//        list2
//      }).map(x => {
//      val grp1 = x.getString("grp1")
//      (grp1,x)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    grp1_out.take(2).foreach(println(_))
//




    val grp_all = grp2_1_1.union(grp2_2_1).union(grp2_3_1).map(x => {
      (x._1,(x._2,x._3))
    }).distinct()

    val out = grp1_out.leftOuterJoin(grp_all).map(x => {
      val left = x._2._1
      val rightOption = x._2._2

      if (!rightOption.isEmpty){
        val value = rightOption.get
        val array = JSON.parseArray(value._1)
        var routeidNew = ""
        if (array.size()>=1){
          routeidNew = array.getString(0)
          left.put("routidNew",routeidNew)
        }else{
          left.put("routidNew",left.getString("routid"))
        }
      }
      val routeid_group = rightOption.get._1
      val grp3_group = rightOption.get._2
//      val grp3_group = rightOption.getOrElse("[]")
      left.put("routeid_group",routeid_group)
      left.put("grp3_group",grp3_group)
      left
    }).map(x => {
      val linecode =  x.getString("line_code")
      val vehicle_type =  x.getString("vehicle_type")
      val src_zone_code =  x.getString("src_zone_code")
      val dest_zone_code =  x.getString("dest_zone_code")
      val grp1 =  x.getString("grp1")
      val routeid =  x.getString("routidNew")
      val routeid_group =  x.getString("routeid_group")
      val grp3 =  x.getString("grp3_group")

      output(linecode,vehicle_type,src_zone_code,dest_zone_code,grp1,routeid,routeid_group,grp3)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    import spark.implicits._
    out.repartition(1).toDF().write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter", "\t").csv("/d:\\user\\01401062\\桌面\\生成配置\\020Y2_442_info_grp_match_econ2_new2.csv")
    //out.repartition(1).toDF().write.mode(SaveMode.Overwrite).option("header", "true").option("delimiter", "\t").csv("/d:\\user\\01401062\\桌面\\生成配置\\res1.csv")


  }
}
