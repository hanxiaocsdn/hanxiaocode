package app.StandardRouteMileage


import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import Utils.{DateTimeUtil, JSONUtils, MD5Util, SparkUtils, StringUtils,Utils}

/**
 **需求名称：标准线路指标监控需求
 **任务id：774310
 **需求方：01369612张翠霞
 **研发：01401062徐千皓，迭代：01390943周勇
 **需求背景：标准线路指标监控需求，外包承运商执行判断优化。
 **/

object DistTimeIndexMonitor2Index {

  @transient lazy val logger: Logger = Logger.getLogger(DistTimeIndexMonitor2Index.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //  val logger: Logger = Logger.getLogger(appName)

  val descMysqlUserName = "gis_oms_pns"
  val descMysqlPassWord = "gis_oms_pns@123@"
  val descMysqlUrl = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?characterEncoding=utf-8"

  def main(args: Array[String]): Unit = {

    val inc_day =args(0)

    start(inc_day)

  }

  def startIndexStat(spark: SparkSession, inc_day: String) = {

    // TODO: 任务监控指标--执行率
    val exacutiveRateStatRdd = getSourceExacutive(spark,inc_day)
    val exacRateStatResRdd = calExacutiveRateStat(exacutiveRateStatRdd,inc_day)
    saveTableExac(spark,inc_day,exacRateStatResRdd,logger)

    // TODO: 任务监控指标--准点率
    val onTimeRateStatRdd = getSourceOnTime(spark,inc_day)
    val onTimeRateStatResRdd = calOnTimeRateStat(onTimeRateStatRdd,inc_day)
    saveTableOnTime(spark,inc_day,onTimeRateStatResRdd,logger)

    // TODO: 任务监控指标--里程差异率
    val diffRateStatRdd = getSourceDiff(spark,inc_day)
    val diffRateStatResRdd = calDiffRateStat(diffRateStatRdd,inc_day)
    saveTableDiff(spark,inc_day,diffRateStatResRdd,logger)

    // TODO: 完整任务统计
    val totalTaskSourceRdd = getSourceTotal(spark,inc_day)
    val totalTaskRdd = calTotalTaskStat(totalTaskSourceRdd,inc_day)
    saveTableTotalTask(spark,inc_day,totalTaskRdd,logger)

  }

  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("DistTimeIndexMonitor2Index_01401062")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    startIndexStat(spark,inc_day)

    logger.error("统计结束")
  }


  def getSourceExacutive(spark: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day='${inc_day}'
         |and
         |  error_type = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type = 0
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf,"MEMORY")

    sourceRdd

  }

  /***
   * 计算执行率
   * @param exacutiveRateStatRdd
   */

  def calExacutiveRateStat(exacutiveRateStatRdd: RDD[JSONObject],inc_day:String) = {

    logger.error("开始执行率计算")

    val exacuResRdd = exacutiveRateStatRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    }).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {
      val task_area_code = x.getString("task_area_code")
      val carrier_name = JSONUtils.getJsonValue(x,"carrier_name","-")
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val task_inc_day = JSONUtils.getJsonValue(x,"task_inc_day","-")
      val src = x.getString("src")

      ((task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src),x)
    }).groupByKey().map(x => {
      val(task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src) = x._1
      val list = x._2.toList
      //任务总量
      val task_count = list.size
      val exe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).size

      val noexe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).size

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src).mkString("_"))

      Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,task_count,exe_count,noexe_count)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("exacuResRdd的数据量为：" + exacuResRdd.count())
    //    exacuResRdd.take(2).foreach(println(_))
    exacuResRdd
  }

  def saveTableExac(spark: SparkSession, inc_day: String, exacRateStatResRdd: RDD[Row],logger:Logger) = {

    val exacRateStatResSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("start_dept", StringType, true),
      StructField("end_dept", StringType, true),
      StructField("src", StringType, true),
      StructField("task_count", IntegerType, true),
      StructField("exe_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true)
    ))

    val exacRateStatResTable = "ETA_STD_LINE_EXECUTE_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,exacRateStatResRdd,exacRateStatResSchema,"append","dm_gis." + exacRateStatResTable,"statdate",inc_day,logger)

    //    // TODO: 保存到mysql
    //    SparkUtils.df2Mysql(spark,exacRateStatResRdd,exacRateStatResSchema,descMysqlUserName,descMysqlPassWord,
    //      "append",descMysqlUrl,exacRateStatResTable,inc_day,logger)



  }

  def getSourceOnTime(spark: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day = '${inc_day}'
         |and
         |  error_type = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type = 0
         |and
         |  if_evaluate_time = 1
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)
    sourceRdd

  }

  def calOnTimeRateStat(onTimeRateStatRdd: RDD[JSONObject],inc_day:String) = {
    logger.error("开始准点计算")

    val onTimeResRdd = onTimeRateStatRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    }).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {
      val task_area_code = x.getString("task_area_code")
      val carrier_name = JSONUtils.getJsonValue(x,"carrier_name","-")
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val task_inc_day = x.getString("task_inc_day")
      val src = x.getString("src")

      ((task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src),x)
    }).groupByKey().map(x => {
      val(task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src) = x._1
      val list = x._2.toList
      //任务总量
      val task_count = list.size
      val exe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).size
      val noexe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).size

      // TODO: 准点率新增字段
      val db_count = list.filter(x => {
        val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"ac_is_run_ontime",0)
        1 == ac_is_run_ontime
      }).size
      val exe_db_count = list.filter(x => {
        val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"ac_is_run_ontime",0)
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type) &&  1 == ac_is_run_ontime
      }).size

      val noexe_db_count = list.filter(x => {
        val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"ac_is_run_ontime",0)
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)  &&  1 == ac_is_run_ontime
      }).size

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src).mkString("_"))

      Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,task_count,exe_count,noexe_count,db_count,exe_db_count,noexe_db_count)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("onTimeResRdd的数据量为：" + onTimeResRdd.count())
    //    onTimeResRdd.take(2).foreach(println(_))

    onTimeResRdd


  }

  def saveTableOnTime(spark: SparkSession, inc_day: String, onTimeRateStatRdd: RDD[Row], logger: Logger) = {

    //Row(id,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,task_count,exe_count,noexe_count,db_count,exe_db_count,noexe_db_count,)

    val onTimeRateStatSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("start_dept", StringType, true),
      StructField("end_dept", StringType, true),
      StructField("src", StringType, true),
      StructField("task_count", IntegerType, true),
      StructField("exe_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true),
      StructField("db_count", IntegerType, true),
      StructField("exe_db_count", IntegerType, true),
      StructField("noexe_db_count", IntegerType, true)
    ))

    val onTimeRateStatTable = "ETA_STD_LINE_DB_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,onTimeRateStatRdd,onTimeRateStatSchema,"append","dm_gis." + onTimeRateStatTable,"statdate",inc_day,logger)

    //    // TODO: 保存到mysql
    //    SparkUtils.df2Mysql(spark,onTimeRateStatRdd,onTimeRateStatSchema,descMysqlUserName,descMysqlPassWord,
    //      "append",descMysqlUrl,onTimeRateStatTable,inc_day,logger)


  }

  def getSourceDiff(spark: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day = '${inc_day}'
         |and
         |  error_type = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type = 0
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)
    sourceRdd


  }

  def calDiffRateStat(exacutiveRateStatRdd: RDD[JSONObject],inc_day:String) = {

    logger.error("开始里程差异率计算")

    val exacutiveResRdd = exacutiveRateStatRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    }).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {
      val task_area_code = x.getString("task_area_code")
      val carrier_name = JSONUtils.getJsonValue(x,"carrier_name","-")
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val task_inc_day = JSONUtils.getJsonValue(x,"task_inc_day","-")
      val src = x.getString("src")

      ((task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src),x)
    }).groupByKey().map(x => {
      val(task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src) = x._1
      val list = x._2.toList
      //任务总量
      val task_count = list.size
      val exe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).size
      val noexe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).size

      // TODO: 里程差异率新增字段

      // TODO: 总标准线路里程total_pns_dist：pns_dist求和
      val total_pns_dist = list.map(x => {
        val pns_dist = JSONUtils.getJsonValueDouble(x,"pns_dist",0)
        pns_dist
      }).sum.toInt

      // TODO: 总任务实际里程total_rt_dist：rt_dist求和
      val total_rt_dist = list.map(x => {
        val rt_dist = JSONUtils.getJsonValueDouble(x,"rt_dist",0)
        rt_dist
      }).sum.toInt

      // TODO: 执行总标准线路里程exe_pns_dist：conduct_type=1的pns_dist求和
      val exe_pns_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).map(x => {
        val pns_dist = JSONUtils.getJsonValueDouble(x,"pns_dist",0)
        pns_dist
      }).sum.toInt

      // TODO: 执行总任务实际里程exe_rt_dist：conduct_type=1的rt_dist求和
      val exe_rt_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).map(x => {
        val rt_dist = JSONUtils.getJsonValueDouble(x,"rt_dist",0)
        rt_dist
      }).sum.toInt

      // TODO: 未执行总任务实际里程noexe_rt_dist：conduct_type=3的rt_dist求和
      val noexe_pns_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).map(x => {
        val pns_dist = JSONUtils.getJsonValueDouble(x,"pns_dist",0)
        pns_dist
      }).sum.toInt

      // TODO: 未执行总任务实际里程noexe_rt_dist：conduct_type=3的rt_dist求和
      val noexe_rt_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).map(x => {
        val rt_dist = JSONUtils.getJsonValueDouble(x,"rt_dist",0)
        rt_dist
      }).sum.toInt


      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src).mkString("_"))

      Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,
        task_count,exe_count,noexe_count,total_pns_dist,total_rt_dist,exe_pns_dist,exe_rt_dist,noexe_pns_dist,noexe_rt_dist)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("exacutiveResRdd的数据量为：" + exacutiveResRdd.count())
    //    exacutiveResRdd.take(2).foreach(println(_))

    exacutiveResRdd


  }

  def saveTableDiff(spark: SparkSession, inc_day: String, exacRateStatResRdd: RDD[Row], logger: Logger) = {

    val exacRateStatResSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("start_dept", StringType, true),
      StructField("end_dept", StringType, true),
      StructField("src", StringType, true),
      StructField("task_count", IntegerType, true),
      StructField("exe_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true),
      StructField("total_pns_dist", IntegerType, true),
      StructField("total_rt_dist", IntegerType, true),
      StructField("exe_pns_dist", IntegerType, true),
      StructField("exe_rt_dist", IntegerType, true),
      StructField("noexe_pns_dist", IntegerType, true),
      StructField("noexe_rt_dist", IntegerType, true)
    ))

    val diffRateStatTable = "ETA_STD_LINE_DIFF_DIST_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,exacRateStatResRdd,exacRateStatResSchema,"append","dm_gis." + diffRateStatTable,"statdate",inc_day,logger)

    //    // TODO: 保存到mysql
    //    SparkUtils.df2Mysql(spark,exacRateStatResRdd,exacRateStatResSchema,descMysqlUserName,descMysqlPassWord,
    //      "append",descMysqlUrl,diffRateStatTable,inc_day,logger)

  }


  def getSourceTotal(spark: SparkSession, inc_day: String) = {

    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day='${inc_day}'
         |and
         |  if_error = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type=0
       """.stripMargin

    val sourceDf = spark.sql(querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)

    sourceRdd

  }

  def calTotalTaskStat(totalTaskSourceRdd: RDD[JSONObject], inc_day: String) = {

    val totalTaskRdd = totalTaskSourceRdd
      .map(x => {
        val task_id = x.getString("task_id")

        (task_id,x)
      })
      .reduceByKey((obj1,obj2) => obj1)
      .map(_._2)
      .map(x => {

        val task_area_code = x.getString("task_area_code")
        val carrier_name = x.getString("carrier_name")
        val line_code = x.getString("line_code")
        val stop_over_zone_code = x.getString("stop_over_zone_code")
        val task_inc_day = x.getString("task_inc_day")

        ((task_area_code,carrier_name,line_code,stop_over_zone_code,task_inc_day),x)

      }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map( x => {

        val (task_area_code,carrier_name,line_code,stop_over_zone_code,task_inc_day) = x._1
        val list = x._2

        // TODO:  总任务量
        val total_task_count = list.size

        val total_evaluate_count_list = list.filter(y => {
          val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
          if_evaluate_time == 1
        })

        // TODO:  总考核任务量
        val total_evaluate_count = total_evaluate_count_list.size
        // TODO:  总准点量
        val total_db_count = total_evaluate_count_list.filter(y => {
          val ac_is_run_ontime = JSONUtils.getJsonValueInt(y,"ac_is_run_ontime",0)
          ac_is_run_ontime == 1
        }).size

        val exe_task_count_list = list.filter(y => {
          val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
          conduct_type == 1
        })

        // TODO:  执行任务量
        val exe_task_count = exe_task_count_list.size

        // TODO:  执行考核任务量
        val exe_evaluate_count = exe_task_count_list.filter(y => {
          val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
          val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
          conduct_type == 1 && if_evaluate_time == 1
        }).size

        // TODO:  执行准点任务量
        val exe_db_count = list.filter(y => {
          val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
          val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
          val ac_is_run_ontime = JSONUtils.getJsonValueInt(y,"ac_is_run_ontime",0)
          conduct_type == 1 && if_evaluate_time == 1 && ac_is_run_ontime == 1
        }).size

        // TODO:  未执行任务量
        val noexe_count = list.filter(y => {
          val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
          conduct_type == 3
        }).size

        // TODO:  未执行考核任务量
        val noexe_evaluate_count = list.filter(y => {
          val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
          val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
          conduct_type == 3 && if_evaluate_time == 1
        }).size

        // TODO:  未执行准点量
        val noexe_db_count = list.filter(y => {
          val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
          val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
          val ac_is_run_ontime = JSONUtils.getJsonValueInt(y,"ac_is_run_ontime",0)
          conduct_type == 3 && if_evaluate_time == 1 && ac_is_run_ontime == 1
        }).size

        // TODO:  总实际路桥费用、100%按规划线路执行的总路桥费用、总实际轨迹里程(km)、100%按规划线路行驶的总里程
        var total_toll_charge = 0.0
        var total_toll_charge_std = 0.0
        var total_rt_dist = 0.0
        var total_pns_dist = 0.0

        list.map(a => {
          total_toll_charge += JSONUtils.getJsonValueDouble(a,"total_toll_charge",0)
          total_toll_charge_std += JSONUtils.getJsonValueDouble(a,"std_toll_charge",0)
          total_rt_dist += JSONUtils.getJsonValueDouble(a,"rt_dist",0)
          total_pns_dist += JSONUtils.getJsonValueDouble(a,"pns_dist",0)
        })

        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,stop_over_zone_code).mkString("_"))

        Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,stop_over_zone_code,total_task_count,
          total_evaluate_count,total_db_count,exe_task_count,exe_evaluate_count,exe_db_count,
          noexe_count,noexe_evaluate_count,noexe_db_count,total_toll_charge,total_toll_charge_std,total_rt_dist,total_pns_dist)
      })

    totalTaskRdd
  }

  def saveTableTotalTask(spark: SparkSession, inc_day: String, totalTaskRdd: RDD[Row], logger: Logger) = {


    val totalTaskSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("stop_over_zone_code", StringType, true),
      StructField("total_task_count", IntegerType, true),
      StructField("total_evaluate_count", IntegerType, true),
      StructField("total_db_count", IntegerType, true),
      StructField("exe_task_count", IntegerType, true),
      StructField("exe_evaluate_count", IntegerType, true),
      StructField("exe_db_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true),
      StructField("noexe_evaluate_count", IntegerType, true),
      StructField("noexe_db_count", IntegerType, true),
      StructField("total_toll_charge", DoubleType, true),
      StructField("total_toll_charge_std", DoubleType, true),
      StructField("total_rt_dist", DoubleType, true),
      StructField("total_pns_dist", DoubleType, true)

    ))

    val totalTaskStatTable = "ETA_STD_LINE_WHOLE_TASK_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,totalTaskRdd,totalTaskSchema,"append","dm_gis." + totalTaskStatTable,"statdate",inc_day,logger)

    //    // TODO: 保存到mysql
    //    SparkUtils.df2Mysql(spark,totalTaskRdd,totalTaskSchema,descMysqlUserName,descMysqlPassWord,
    //      "append",descMysqlUrl,totalTaskStatTable,inc_day,logger)

  }

}
