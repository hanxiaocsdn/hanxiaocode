package app.StandardRouteMileage

import java.util.{Calendar, Date}
import java.util.concurrent.atomic.AtomicInteger
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import Utils.{DateTimeUtil, JSONUtils, MD5Util, SparkUtils, StringUtils}
import Utils.SparkUtils.writeToHive

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import Utils.Utils
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import uitls.UrlUtils
import com.sf.gis.java.eta.constant.StandardRouteMileage.DistanceTool
import com.sf.gis.scala.base.spark.{Spark, SparkNet}
import org.apache.spark.sql.expressions.Window

import java.text.SimpleDateFormat


/**
 **需求名称：标准线路指标监控需求
 **任务id：371318
 **需求方：01369612张翠霞
 **研发：01401062徐千皓，迭代：01390943周勇
 **需求背景：标准线路指标监控需求，外包承运商执行判断优化。
 **/

object DistTimeIndexMonitor2 {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {
    //接收日期参数
    val inc_day =args(0)

    //开始执行
    start(inc_day)
  }

  //执行函数列表
  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("DistTimeMonitor_01401062")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    //startIndexStat(spark,inc_day)

    // 生成recall表
    val getJoin1to5Rdd = getJoin1to5(spark,inc_day)
    // 20220808新增关联司机信息表
    val joinDriverInfoRdd = getJoinDriverInfo(spark,inc_day,getJoin1to5Rdd)
    //    val joinDriverInfoRdd =getJoin1to5Rdd
    // 扯线异常修复
    val addFilterProcessRdd = addFilterProcess(spark,joinDriverInfoRdd)
    //写入结果表6：dm_gis.eta_std_line_recall
    saveTable6(spark,inc_day,addFilterProcessRdd)

    // 回溯表
    //写入表：dm_gis.eta_std_line_recall1
    val recallSourceRdd = getSourceRecall(spark,inc_day)
    val recallRdd = calRecallRateStat(recallSourceRdd,inc_day)
    saveTableRecall2(spark,inc_day,recallRdd,logger)

    logger.error("统计结束")
  }

  //计算各项指标
  def startIndexStat(spark: SparkSession, inc_day: String) = {

        // kafka日志解析 结果表8
        //写入结果表8：dm_gis.eta_std_line_task_parse
        val groundKafkaSourceRdd = getKafkaData(spark,inc_day)
        val parseKafkaLogRdd = getParseKafkaLog(groundKafkaSourceRdd,inc_day)
        saveTable8(spark,inc_day,parseKafkaLogRdd,logger)

        //写入结果表1：dm_gis.eta_std_line_task
        val (midTable1Rdd,sourceTable1Rdd) = getSourceTable1(spark,inc_day)
        saveTable1(spark,inc_day,sourceTable1Rdd)

        //写入结果表3：dm_gis.eta_std_line_route
        val distinctMidTableRdd = distinctMidTable1(spark,inc_day)
        val standardLineRdd = getStandardLine(distinctMidTableRdd)
        saveTable3(spark,inc_day,standardLineRdd)

        //写入结果表2：dm_gis.eta_std_line_rectify
        val getRes1Rdd= getRes1table(spark,inc_day)
        val getGjTable = processGjRectify(spark,getRes1Rdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
        //    getGjTable.take(2).foreach(println(_))
        saveTable2(spark,inc_day,getGjTable)

        //清理全部待释放rdd
        SparkUtils.unpersistAllUnuse(spark.sparkContext)

        //写入结果表4：dm_gis.eta_std_line_similarity
        val (sourceSimilarRdd1,sourceSimilarRdd2) = getSourceSim(spark,inc_day)
        val getSimRdd = getSimProcess(sourceSimilarRdd1,sourceSimilarRdd2)
        saveTable4(spark,inc_day,getSimRdd)

        //写入结果表5：dm_gis.eta_std_line_compute
        val getComputeRdd = getComputeSource(spark,inc_day)
        val accrualDistRdd = getAccrualDistRdd(spark,inc_day,getComputeRdd)
        saveTable5(spark,inc_day,accrualDistRdd)

        // 生成recall表
        val getJoin1to5Rdd = getJoin1to5(spark,inc_day)
        // 20220808新增关联司机信息表
        val joinDriverInfoRdd = getJoinDriverInfo(spark,inc_day,getJoin1to5Rdd)
        //    val joinDriverInfoRdd =getJoin1to5Rdd
        // 扯线异常修复
        val addFilterProcessRdd = addFilterProcess(spark,joinDriverInfoRdd)
        //写入结果表6：dm_gis.eta_std_line_recall
        saveTable6(spark,inc_day,addFilterProcessRdd)

        // 回溯表
        //写入表：dm_gis.eta_std_line_recall1
        val recallSourceRdd = getSourceRecall(spark,inc_day)
        val recallRdd = calRecallRateStat(recallSourceRdd,inc_day)
        saveTableRecall2(spark,inc_day,recallRdd,logger)

  }


  /** @note   调用历史轨迹接口*/
  private def parseTrajRectify(json:JSONObject,rep:String):JSONObject = {
    val repJo = JSON.parseObject(rep)
    val result = repJo.getJSONObject("result")
    val data = result.getJSONObject("data")
    val rt_coords = data.getJSONArray("track")

    val rt_dist = data.getDouble("len")
    val time = data.getIntValue("roadTime")

    val highwaymileage = JSONUtils.getJsonValueInt(data.getJSONObject("rc_distance"),"0",0)
    val toll_charge = data.getDouble("tollCharge")

    val maxLen = rt_coords.size()-1

    var startCnt = 0
    var endCnt = 0
    var startStatePoint = 0
    var endStatePoint = rt_coords.size() - 1
    var i = 0
    var j = rt_coords.size() - 1


    while(i < j){
      if (rt_coords.getJSONObject(i).getIntValue("state") != 1100){
        startCnt += 1
        if (startCnt == 2){
          startStatePoint = i
        }
      }

      if (rt_coords.getJSONObject(j).getIntValue("state") != 1100){
        endCnt += 1
        if (endCnt == 2){
          endStatePoint = j
        }
      }

      i += 1
      j -= 1
    }

    var res_rt_start_index = startStatePoint
    var res_rt_end_index = endStatePoint

    var dist_a = 0.0
    var dist_b = 0.0
    var dist_c = 0.0

    println("startStatePoint:" + startStatePoint)
    println("endStatePoint:" + endStatePoint)

    var rt_dist_new = 0.0


    dist_a = try { rt_coords.getJSONObject(startStatePoint).getDoubleValue("sumDist") - rt_coords.getJSONObject(0).getDoubleValue("sumDist")} catch {case e:Exception => 0}

    dist_c = try {rt_coords.getJSONObject(rt_coords.size() -1).getDoubleValue("sumDist") - rt_coords.getJSONObject(endStatePoint).getDoubleValue("sumDist")} catch {case e:Exception => 0}

    dist_b = try {rt_coords.getJSONObject(endStatePoint).getDoubleValue("sumDist") - rt_coords.getJSONObject(startStatePoint).getDoubleValue("sumDist")} catch {case e:Exception => 0}

    if (dist_a <= 3000 && dist_b != 0 && dist_a / dist_b <= 0.1){
      res_rt_start_index = 0
      rt_dist_new = dist_a + dist_b
    }else {
      rt_dist_new = dist_b
    }

    if (dist_c <= 3000 && dist_b != 0 && dist_c / dist_b <= 0.1) {
      res_rt_end_index = maxLen
      rt_dist_new = rt_dist_new + dist_c
    }

    var res_rt_coords = try {rt_coords.subList(res_rt_start_index,res_rt_end_index).asInstanceOf[JSONArray]}catch {case e:Exception => rt_coords}

    val stayPoints = data.getJSONArray("stayPoints")

    var duration = 0.0

    for (i <- (0 until(stayPoints.size()))){
      duration += JSONUtils.getJsonValueDouble(stayPoints.getJSONObject(i),"duration",0)
    }

    val tl_time = time - duration

    val start_latitude = JSONUtils.getJsonValueDouble(json,"start_latitude",0)
    val start_longitude = JSONUtils.getJsonValueDouble(json,"start_longitude",0)
    val end_latitude = JSONUtils.getJsonValueDouble(json,"end_latitude",0)
    val end_longitude = JSONUtils.getJsonValueDouble(json,"end_longitude",0)

    val x1 = res_rt_coords.getJSONObject(0).getDoubleValue("dx")
    val y1 = res_rt_coords.getJSONObject(0).getDoubleValue("dy")

    val x2 = res_rt_coords.getJSONObject(res_rt_coords.size()-1).getDoubleValue("dx")
    val y2 = res_rt_coords.getJSONObject(res_rt_coords.size()-1).getDoubleValue("dy")

    val start_distance = DistanceTool.getGreatCircleDistance(x1,y1,start_longitude,start_latitude)
    val end_distance = DistanceTool.getGreatCircleDistance(x2,y2,end_longitude,end_latitude)

    //    println("计算start_distance" + (x1,y1,start_longitude,start_latitude))
    //    println("计算end_distance" + (x2,y2,end_longitude,end_longitude))

    val jo = new JSONObject()

    // TODO: 新增只有两个有效点情况判段
    if (startCnt < 2 || endCnt <2 ){
      jo.put("rt_coords","")
      jo.put("x1",x1)
      jo.put("y1",y1)
      jo.put("x2",x2)
      jo.put("y2",y2)
      jo.put("duration",duration)
      jo.put("time",time)
      jo.put("tl_time",tl_time)
      jo.put("rt_dist",0)
      jo.put("highwaymileage",highwaymileage)
      jo.put("toll_charge",toll_charge)
      jo.put("start_distance",0)
      jo.put("end_distance",0)
      jo.put("stay_list",stayPoints)

      // TODO: 新增dist abc判断
      jo.put("dist_a",0)
      jo.put("dist_b",dist_b)
      jo.put("dist_c",0)

    }else {
      jo.put("rt_coords",res_rt_coords)
      jo.put("x1",x1)
      jo.put("y1",y1)
      jo.put("x2",x2)
      jo.put("y2",y2)
      jo.put("duration",duration)
      jo.put("time",time)
      jo.put("tl_time",tl_time)
      jo.put("rt_dist",rt_dist_new)
      jo.put("highwaymileage",highwaymileage)
      jo.put("toll_charge",toll_charge)
      jo.put("start_distance",start_distance)
      jo.put("end_distance",end_distance)
      jo.put("stay_list",stayPoints)

      // TODO: 新增dist abc判断
      jo.put("dist_a",dist_a)
      jo.put("dist_b",dist_b)
      jo.put("dist_c",dist_c)
    }

    //    jo.put("rt_coords",rt_coords)

    //    jo.put("error_type",error_type)
    jo.fluentPutAll(json)

    println(jo.toJSONString)

    jo
  }

  def getSourceTable1(spark: SparkSession, inc_day: String) = {

    val begin_day_before3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-2)
    val begin_day_before7 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-7)

    val begin_day_before4 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

    val hisTaskSql =
      s"""
         |select
         |  *
         |from
         |  (
         |    select
         |      row_number() over (
         |        partition by task_subid
         |        order by
         |          last_update_tm desc
         |      ) as rn,
         |      task_subid,
         |      task_id,
         |      driver_id,
         |      driver_name,
         |      if(
         |        actual_capacity_load = '0.0',
         |        capacity_load,
         |        actual_capacity_load
         |      ) as actual_capacity_load,
         |      start_dept,
         |      end_dept,
         |      regexp_replace(substring(plan_depart_tm, 12, 5), ':', '') as start_time,
         |      start_type,
         |      end_type,
         |      actual_depart_tm,
         |      actual_arrive_tm,
         |      actual_run_time,
         |      line_time,
         |      line_distance,
         |      sort_num,
         |      start_longitude,
         |      start_latitude,
         |      end_longitude,
         |      end_latitude,
         |      line_code,
         |      task_area_code,
         |      vehicle_serial,
         |      transoport_level,
         |      regexp_replace(substring(plan_depart_tm, 1, 10), '-', '') as task_inc_day,
         |      is_stop,
         |      carrier_type,
         |      plf_flag,
         |      plan_depart_tm,
         |      plan_arrive_tm,
         |      '0' is_run_ontime,
         |      carrier_name,
         |      stop_over_zone_code,
         |      biz_type,
         |      require_category,
         |      to_ground,
         |      last_update_tm,
         |      scm_plan_recall main_driver_account,
         |      line_require_id,
         |      start_outer_add_code,
         |      end_outer_add_code,
         |      start_sortnum,
         |      end_sortnum,
         |      type type_info,
         |      carrier_code,
         |      carrier_id,
         |      src_city_name,
         |      dest_city_name,
         |      sf_outer_vehicle_from,
         |      child_carrier_name,
         |      child_carrier_id,
         |      child_carrier_code,
         |      deputy_driver_account,
         |      deputy_driver_name
         |    FROM
         |      dm_gis.scm_plan_recall
         |    where
         |      inc_day ='${inc_day}'
         |    and biz_type <90
         |  ) t1
         |where
         |  t1.rn = 1
       """.stripMargin

    val carInfoSql =
      s"""
         |select
         |  *
         |from
         |  (
         |    SELECT
         |      row_number() over(
         |        partition by regexp_replace(vehicle, '[\r\n\0,\\\\s,\\\\.*。、,]+', '')
         |        order by
         |          source,case
         |            when vehicle_type = 4 then 1
         |            when vehicle_type = 8 then 2
         |            when vehicle_type = 7 then 3
         |            when vehicle_type = 6 then 4
         |            when vehicle_type = 5 then 5
         |            else 6
         |          end,
         |	      inc_day,
         |          vehicle_length + 0 desc
         |      ) num,
         |      regexp_replace(vehicle, '[\r\n\0,\\\\s, \\\\.*。、,]+', '') vehicle_serial,
         |      hko_vehicle_code,
         |      trailer_vehicle_code,
         |      source,
         |      if (vehicle_type = "" or vehicle_type is null,"6",vehicle_type) vehicle_type,
         |      length,
         |      vehicle_length,
         |      vehicle_full_load_weight,
         |      outer_length,
         |      outer_width,
         |      outer_height,
         |      inner_length,
         |      inner_width,
         |      inner_height,
         |      if (axis = "" or axis is null,"2",axis) axls_number,
         |      weight,
         |      load_weight,
         |      full_load_weight,
         |      color,
         |      energy,
         |      license,
         |      emission,
         |      is_trailer,
         |      vehicle_type_ground,
         |      exception_axis,
         |      exception_weight,
         |      exception_length,
         |      exception_width,
         |      exception_height,
         |      inc_day
         |    FROM
         |      dm_gis.gis_tm_vehicle
         |    WHERE
         |      inc_day >= '${begin_day_before7}'
         |  ) t
         |where
         |  t.num = 1
       """.stripMargin

    val timeInfoSql =
      s"""
         |select
         |    log_dist,task_id,'0' road_fee
         |from
         |(
         |select
         |   log_dist,task_id,
         |   row_number() over(partition by task_id order by log_dist desc) rn
         |from
         |(
         |select
         |  actual_miles as log_dist,
         |  concat(dept_code, task_id) as task_id
         |from
         |  ods_shiva_ground.tt_drivinglog_data
         |where
         |  inc_day >= '${begin_day_before4}'
         |  and inc_day <= '${inc_day}'
         |  and task_id != '0'
         |  and actual_miles is not null
         |  and actual_miles != 0
         |) a
         |) aa
         |where aa.rn = 1
       """.stripMargin


    logger.error("hisTaskSql为：" + hisTaskSql)
    val hisTaskInfoDf = spark.sql(hisTaskSql)
    val midTable1Rdd = SparkUtils.getRowToJson(hisTaskInfoDf,"DISK_ONLY")
    logger.error("midTable1Rdd的数据量为：" + midTable1Rdd.count())
    //    midTable1Rdd.take(2).foreach(println(_))

    val carInfoSqlDf = spark.sql(carInfoSql)
    val midTable2Rdd = SparkUtils.getRowToJson(carInfoSqlDf,"DISK_ONLY")
    logger.error("midTable2Rdd的数据量为：" + midTable2Rdd.count())
    //    midTable2Rdd.take(2).foreach(println(_))

    val timeInfoSqlDf = spark.sql(timeInfoSql)
    val midTable3Rdd = SparkUtils.getRowToJson(timeInfoSqlDf,"DISK_ONLY")

    logger.error("midTable3Rdd的数据量为：" + midTable3Rdd.count())
    //    midTable3Rdd.take(2).foreach(println(_))

    val midTable2RddJoin = midTable2Rdd.map(x => {
      val vehicle_serial = x.getString("vehicle_serial")
      (vehicle_serial,x)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    midTable2Rdd.unpersist()

    val midTable3RddJoin = midTable3Rdd.map(obj => {
      val task_id = obj.getString("task_id")
      (task_id, obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    midTable3Rdd.unpersist()

    val joinRdd1 = midTable1Rdd.map(x => {
      val vehicle_serial = x.getString("vehicle_serial")
      (vehicle_serial,x)
    }).leftOuterJoin(midTable2RddJoin).map(x => {

      val left = x._2._1
      val rightOption = x._2._2

      if(rightOption.nonEmpty){
        val vehicle_type = rightOption.get.getString("vehicle_type")
        val axls_number = rightOption.get.getString("axls_number")
        left.put("vehicle_type",vehicle_type)
        left.put("axls_number",axls_number)
      }
      left
    })

    val joinRdd2 = joinRdd1.map(x => {
      val task_id = x.getString("task_id")
      (task_id,x)
    }).leftOuterJoin(midTable3RddJoin).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      if(rightOption.nonEmpty){
        val log_dist = rightOption.get.getString("log_dist")
        val road_fee = JSONUtils.getJsonValue(rightOption.get,"road_fee","")
        left.put("log_dist",log_dist)
        left.put("road_fee",road_fee)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    midTable2RddJoin.unpersist()
    midTable3RddJoin.unpersist()

    (midTable1Rdd,joinRdd2)

  }

  def getVehicleTypeProcess(actual_capacity_load_new: Double) = {

    val vehicle_type = actual_capacity_load_new match {
      case actual_capacity_load_new if (actual_capacity_load_new == 0) => 6
      case actual_capacity_load_new if (actual_capacity_load_new <= 1) => 5
      case actual_capacity_load_new if (actual_capacity_load_new > 1 && actual_capacity_load_new <= 3) => 6
      case actual_capacity_load_new if (actual_capacity_load_new > 3 && actual_capacity_load_new < 7) => 7
      case actual_capacity_load_new if (actual_capacity_load_new >= 7) => 8
    }

    vehicle_type

  }

  //写入结果表1
  def saveTable1(spark: SparkSession, inc_day: String, sourceTable1Rdd: RDD[JSONObject]) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_task"
    //测试表dm_gis.eta_std_line_task_aaa
    //    val saveTableName = "dm_gis.eta_std_line_task_test"
    logger.error("当前inc_day为：" + inc_day)
    logger.error("获取司机画像数据：" + inc_day)

    val driver_score=spark.sql(
      s"""
        |select driver_code as main_driver_account,driver_month_statistics as driver_score,inc_month
        |from dm_gis_scm.dm_driver_label_month
        |where inc_month='202310' and  driver_month_statistics is not null
        |and driver_code  is not null and driver_code !=''
        |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("main_driver_account").orderBy(desc("inc_month"))))
      .filter($"rank"===1)
      .drop("rank","inc_month")

    logger.error("正在写入结果表1")

    val res =  sourceTable1Rdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")

      val task_subid = task_id + sort_num

      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val start_type= x.getString("start_type")
      val end_type= x.getString("end_type")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val plan_depart_tm= x.getString("plan_depart_tm")
      val actual_depart_tm= x.getString("actual_depart_tm")
      val plan_arrive_tm= x.getString("plan_arrive_tm")
      val actual_arrive_tm= x.getString("actual_arrive_tm")
      val driver_id= x.getString("driver_id")
      val driver_name= x.getString("driver_name")
      val line_time= x.getString("line_time")
      val line_distance= x.getString("line_distance")

      val actual_run_time = try {TimeDiffMinit(actual_depart_tm,actual_arrive_tm)} catch {case e:Exception => 0}
      val start_longitude= x.getString("start_longitude")
      val start_latitude= x.getString("start_latitude")
      val end_longitude= x.getString("end_longitude")
      val end_latitude= x.getString("end_latitude")
      val is_stop= x.getString("is_stop")
      val transoport_level= x.getString("transoport_level")
      val carrier_type= x.getString("carrier_type")
      val plf_flag= x.getString("plf_flag")
      //val vehicle_type= x.getString("vehicle_type")
      val actual_capacity_load_new = JSONUtils.getJsonValueDouble(x,"actual_capacity_load",0)
      val vehicle_type = getVehicleTypeProcess(actual_capacity_load_new).toString
      val axls_number= x.getString("axls_number")

      //      val log_dist=  if (line_code.dropRight(4) != (start_dept + end_dept))  ""  else x.getString("log_dist")
      val log_dist = x.getString("log_dist")
      val task_inc_day = x.getString("task_inc_day")
      val start_time = x.getString("start_time")

      //20211011新增if_evaluate_time
      val is_run_ontime = JSONUtils.getJsonValueInt(x,"is_run_ontime",0)

      val biz_type = x.getString("biz_type")
      val require_category = x.getString("require_category")
      val to_ground = x.getString("to_ground")

      val filterList = List("13","93","91","92","94","95")
      val filterList2 = List("0","1","2","17","18")

      val if_evaluate_time = if (!filterList.contains(biz_type) && filterList2.contains(require_category) &&
        "1".equals(to_ground)
      ) "1" else "0"

      //
      //      20211104判断规则改为：若同时满足
      //      ①biz_type not in ('13','93','91','92','94','95')
      //      ②require_category in (0,1,2,17,18)
      //      ③to_ground=1
      //      则if_evaluate_time = 1
      //      否则为0
      //      注：判断条件里的字段均为本次需求新增字段

      val carrier_name = x.getString("carrier_name")
      val stop_over_zone_code = x.getString("stop_over_zone_code")

      //20220421
      val last_update_tm = x.getString("last_update_tm")

      val main_driver_account = x.getString("main_driver_account")

      //20220707
      val road_fee = x.getString("road_fee")

      val line_require_id = x.getString("line_require_id")

      //20220823
      val start_outer_add_code = x.getString("start_outer_add_code")
      val end_outer_add_code = x.getString("end_outer_add_code")
      val start_sortnum = x.getString("start_sortnum")
      val end_sortnum = x.getString("end_sortnum")

      //20221129
      val type_info = x.getString("type_info")

      //20230517
      val carrier_id = x.getString("carrier_id")
      val carrier_code = x.getString("carrier_code")

      //20230613
      val src_city_name = x.getString("src_city_name")
      val dest_city_name = x.getString("dest_city_name")
      val sf_outer_vehicle_from = x.getString("sf_outer_vehicle_from")

      //20230620
      val child_carrier_name = x.getString("child_carrier_name")
      val child_carrier_id = x.getString("child_carrier_id")
      val child_carrier_code = x.getString("child_carrier_code")
      val deputy_driver_account = x.getString("deputy_driver_account")
      val deputy_driver_name = x.getString("deputy_driver_name")

      res_table1(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,start_type,end_type,
        line_code,vehicle_serial,actual_capacity_load,plan_depart_tm,actual_depart_tm,
        plan_arrive_tm,actual_arrive_tm,driver_id,driver_name,line_time,line_distance,
        actual_run_time.toString,start_longitude,start_latitude,end_longitude,end_latitude,is_stop,
        transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,log_dist,task_inc_day,start_time,if_evaluate_time,is_run_ontime.toString,
        carrier_name,stop_over_zone_code,biz_type,require_category,to_ground,last_update_tm,main_driver_account,road_fee,line_require_id,
        start_outer_add_code,end_outer_add_code,start_sortnum,end_sortnum,type_info,carrier_id,carrier_code,src_city_name,dest_city_name,sf_outer_vehicle_from,
        child_carrier_name,child_carrier_id,child_carrier_code,deputy_driver_account,deputy_driver_name)
    })
      .repartition(100).toDF()
      .withColumn("inc_day",lit(inc_day))
      .join(driver_score,Seq("main_driver_account"),"left")
      .withColumn("type",$"type_info")

    val table_cols = spark.sql(s"""select * from $saveTableName limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, res.select(table_cols: _*), Seq("inc_day"), saveTableName)
     // .write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表1写入完成")

  }

  // 组内取实际发车时间早的一条记录
  def getMaxDepartTm(obj1: JSONObject, obj2: JSONObject): JSONObject = {

    val actual_depart_tm1 = JSONUtils.getJsonValue(obj1,"actual_depart_tm","0")
    val actual_depart_tm2 = JSONUtils.getJsonValue(obj2,"actual_depart_tm","0")

    if (StringUtils.nonEmpty(actual_depart_tm1) && StringUtils.nonEmpty(actual_depart_tm1) && actual_depart_tm1 > actual_depart_tm2){
      obj1
    } else {
      obj2
    }
  }

  def distinctMidTable1(spark:SparkSession,inc_day:String) = {

    val hisTaskSql =
      s"""
         |select
         |  *
         |from
         |  (
         |    select
         |      row_number() over (
         |        partition by task_subid
         |        order by
         |          last_update_tm desc
         |      ) as rn,
         |      task_subid,
         |      task_id,
         |      driver_id,
         |      driver_name,
         |      if(
         |        actual_capacity_load = '0.0',
         |        capacity_load,
         |        actual_capacity_load
         |      ) as actual_capacity_load,
         |      start_dept,
         |      end_dept,
         |      regexp_replace(substring(plan_depart_tm, 12, 5), ':', '') as start_time,
         |      start_type,
         |      end_type,
         |      actual_depart_tm,
         |      actual_arrive_tm,
         |      actual_run_time,
         |      line_time,
         |      line_distance,
         |      sort_num,
         |      start_longitude,
         |      start_latitude,
         |      end_longitude,
         |      end_latitude,
         |      line_code,
         |      task_area_code,
         |      vehicle_serial,
         |      transoport_level,
         |      regexp_replace(substring(plan_depart_tm, 1, 10), '-', '') as task_inc_day,
         |      is_stop,
         |      carrier_type,
         |      plf_flag,
         |      plan_depart_tm,
         |      plan_arrive_tm,
         |      '0' is_run_ontime,
         |      carrier_name,
         |      stop_over_zone_code,
         |      biz_type,
         |      require_category,
         |      to_ground,
         |      last_update_tm,
         |      scm_plan_recall main_driver_account,
         |      line_require_id,
         |      start_outer_add_code,
         |      end_outer_add_code,
         |      start_sortnum,
         |      end_sortnum,
         |      type
         |    FROM
         |      dm_gis.scm_plan_recall
         |    where
         |      inc_day ='${inc_day}'
         |    and biz_type <90
         |  ) t1
         |where
         |  t1.rn = 1
       """.stripMargin


    //    logger.error("hisTaskSql为：" + hisTaskSql)
    val hisTaskInfoDf = spark.sql(hisTaskSql)
    val midTable1Rdd = SparkUtils.getRowToJson(hisTaskInfoDf,"DISK_ONLY")
    logger.error("midTable1Rdd的数据量为：" + midTable1Rdd.count())
    //    midTable1Rdd.take(2).foreach(println(_))


    val distinctMidTable = midTable1Rdd.map(x => {

      val line_require_id = JSONUtils.getJsonValue(x,"line_require_id","")
      val end_sortnum = JSONUtils.getJsonValue(x,"end_sortnum","")

      val actual_depart_tm = JSONUtils.getJsonValue(x,"actual_depart_tm","")

      ((line_require_id,end_sortnum),x)
    }).filter(_._2 != null).reduceByKey((obj1,obj2) => getMaxDepartTm(obj1,obj2)).map(_._2).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("distinctMidTable的数据量为：" + distinctMidTable.count())

    distinctMidTable

  }

  def parseStaLineRep(sourceJson:JSONObject,response: String)= {

    val jo = new JSONObject()

    val task_area_code = sourceJson.getString("task_area_code")
    val line_code = sourceJson.getString("line_code")
    val start_dept = sourceJson.getString("start_dept")
    val end_dept = sourceJson.getString("end_dept")
    val start_time = sourceJson.getString("start_time")
    val actual_capacity_load = sourceJson.getString("actual_capacity_load").replaceAll("T","")
    val vehicle_serial = sourceJson.getString("vehicle_serial")
    val vehicle_type = sourceJson.getString("vehicle_type")
    val task_inc_day = sourceJson.getString("task_inc_day")

    jo.fluentPutAll(sourceJson)
    jo.put("task_area_code",task_area_code)
    jo.put("line_code",line_code)
    jo.put("start_dept",start_dept)
    jo.put("end_dept",end_dept)
    jo.put("start_time",start_time)
    jo.put("actual_capacity_load",actual_capacity_load)
    jo.put("vehicle_serial",vehicle_serial)
    jo.put("vehicle_type",vehicle_type)
    jo.put("task_inc_day",task_inc_day)

    try{
      val resp = JSON.parseObject(response)
      val result = resp.getJSONObject("result")
      val linePassZoneInfoDtos = try {result.getJSONArray("linePassZoneInfoDtos").getJSONObject(0)} catch {case e:Exception => new JSONObject()}
      val stdLineData = try {linePassZoneInfoDtos.getJSONObject("stdLineData")} catch {case e:Exception => new JSONObject()}
      val pns_dist = stdLineData.getString("pnsDist")
      val pns_time = stdLineData.getString("pnsTime")
      val src = stdLineData.getString("src")
      val std_coords = stdLineData.getString("coords")
      val line_distance_std = stdLineData.getString("dist")
      val line_time_std = stdLineData.getString("time")

      //20211011增加统计字段
      val std_id = linePassZoneInfoDtos.getString("stdId")
      val coords = stdLineData.getJSONArray("coords")
      val std_x1 = coords.getJSONArray(0).getDouble(0)
      val std_y1 = coords.getJSONArray(0).getDouble(1)
      val isEcon = stdLineData.getString("isEcon")

      val maxIndex = if (coords.size() != 0) ( coords.size() -1 ) else 0

      val std_x2 = coords.getJSONArray(maxIndex).getDouble(0)
      val std_y2 = coords.getJSONArray(maxIndex).getDouble(1)

      //20211118增加统计字段std_toll_charge
      val std_toll_charge = stdLineData.getString("tolls")

      jo.put("pns_dist",pns_dist)
      jo.put("pns_time",pns_time)
      jo.put("src",isEcon)
      jo.put("std_coords",std_coords)
      jo.put("line_distance_std",line_distance_std)
      jo.put("line_time_std",line_time_std)

      jo.put("std_id",std_id)
      jo.put("std_x1",std_x1)
      jo.put("std_y1",std_y1)
      jo.put("std_x2",std_x2)
      jo.put("std_y2",std_y2)
      jo.put("std_toll_charge",std_toll_charge)

    } catch {
      case e:Exception =>
        if (e.toString.contains("轨迹点为空")){
          jo.put("err","轨迹点为空")
        }else {
          jo.put("err", e.toString + "++++" + response)
        }
    }
    jo
  }

  def schedulerStaInterface(x: JSONObject) = {

    //        val url = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/query"
    val url = "http://gis-apis.int.sfcloud.local:1080/etaStdLine/queryByLineRequireId"

    val jo = new JSONObject()

    val start_dept = x.getString("start_dept")
    val end_dept = x.getString("end_dept")
    val line_code = x.getString("line_code")
    val start_time = x.getString("start_time")

    //        //20220316新增
    //        val x1 = x.getString("start_longitude")
    //        val y1 = x.getString("start_latitude")
    val x2 = JSONUtils.getJsonValueDouble(x,"end_longitude",0.0).toString
    val y2 = JSONUtils.getJsonValueDouble(x,"end_latitude",0.0).toString


    //20220823
    val start_outer_add_code = x.getString("start_outer_add_code")
    val end_outer_add_code = x.getString("end_outer_add_code")
    val start_sortnum = x.getString("start_sortnum")
    val end_sortnum = x.getString("end_sortnum")


    val line_require_id = x.getString("line_require_id")

    val actual_capacity_load = try {
      x.getString("actual_capacity_load").replaceAll("T", "")
    } catch {
      case e: Exception => ""
    }

    jo.put("ak", "4dc00a88a1f34bffa49a153103458efc")
    jo.put("lineRequireId",line_require_id)

    val linePassZoneInfoDtos = new JSONArray()
    val lineDtoJo = new JSONObject()
    lineDtoJo.put("sortNum",end_sortnum)
    if (StringUtils.nonEmpty(end_outer_add_code)) lineDtoJo.put("passZoneCode",end_outer_add_code) else lineDtoJo.put("passZoneCode",end_dept)
    if (StringUtils.nonEmpty(end_outer_add_code)) lineDtoJo.put("passAddrCode",end_outer_add_code)

    //  增加 passCoordinate字段
    lineDtoJo.put("passCoordinate",x2 + "," + y2)

    linePassZoneInfoDtos.add(lineDtoJo)

    jo.put("linePassZoneInfoDtos",linePassZoneInfoDtos)

    //        jo.put("opt", "std2")
    //        jo.put("compensateTime", 1)
    //        jo.put("srcZoneCode", start_dept)
    //        jo.put("destZoneCode", end_dept)
    //        jo.put("lineCode", line_code)
    //        jo.put("planTime", start_time)
    //        jo.put("mLoad", actual_capacity_load)
    //        jo.put("x1",x1)
    //        jo.put("y1",y1)
    //        jo.put("x2",x2)
    //        jo.put("y2",y2)
    //val response = Utils.post(url, jo, "utf-8")
    val response = Utils.retryPost(url, jo)

    var repJson = new JSONObject()

    repJson = try {
      parseStaLineRep(x, response)
    } catch {
      case e: Exception =>
        if (e.toString.contains("轨迹点为空")){
          x.put("err","轨迹点为空")
        }else {
          x.put("err", "Exception")
        }
        x
    }
    repJson

  }

  def getStandardLine(distinctMidTableRdd: RDD[JSONObject]) = {

    val limitMin = 10000

    val processStandardRdd = distinctMidTableRdd.repartition(10).mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 10
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }

        schedulerStaInterface(x)
        //val url = "http://gis-int.int.sfdc.com.cn:1080/etaStdLine/query"

      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("processStandardRdd的数据量为：" + processStandardRdd.count())
    processStandardRdd

  }

  //写入结果表2
  def saveTable2(spark: SparkSession, inc_day: String, standardLineRdd: RDD[JSONObject]) = {

    import spark.implicits._
    val saveTableName = "dm_gis.eta_std_line_rectify"
    //测试表dm_gis.eta_std_line_rectify_aaa
    //    val saveTableName = "dm_gis.eta_std_line_rectify_test"
    logger.error("当前inc_day为：" + inc_day)
    logger.error("正在写入结果表2")
    //    /**
    //      * 删除结果表2，60天前数据
    //      */
    //    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-60)
    //    val dropSql =
    //      s"""
    //         |alter table ${saveTableName} drop if exists partition (inc_day='${dropDate}')
    //       """.stripMargin
    //    logger.error("删除中间表1的45天前数据" + dropSql)
    //    spark.sql(dropSql)


    val res = standardLineRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")
      val task_subid= x.getString("task_subid")
      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val vehicle_type= x.getString("vehicle_type")
      val start_longitude= x.getString("start_longitude")
      val start_latitude= x.getString("start_latitude")
      val end_longitude= x.getString("end_longitude")
      val end_latitude= x.getString("end_latitude")
      val rt_coords= x.getString("rt_coords")
      val x1= x.getString("x1")
      val y1= x.getString("y1")
      val x2= x.getString("x2")
      val y2= x.getString("y2")
      val duration= x.getString("duration")
      val time= x.getString("time")
      val tl_time= x.getString("tl_time")
      val rt_dist= x.getString("rt_dist")
      val highwaymileage= x.getString("highwaymileage")
      val toll_charge= x.getString("toll_charge")
      val start_distance= JSONUtils.getJsonValueDouble(x,"start_distance",0).formatted("%.6f")
      val end_distance= JSONUtils.getJsonValueDouble(x,"end_distance",0).formatted("%.6f")
      val error_type= x.getString("error_type")
      val err_log = x.getString("err")
      val task_inc_day = x.getString("task_inc_day")
      val start_time = x.getString("start_time")

      //20211011新增halfway_integrate_rate
      val halfway_integrate_rate = x.getString("halfway_integrate_rate")


      //20220823
      val line_require_id = x.getString("line_require_id")
      val start_sortnum = x.getString("start_sortnum")
      val end_sortnum = x.getString("end_sortnum")

      val dist_a = x.getString("dist_a")
      val dist_b = x.getString("dist_b")
      val dist_c = x.getString("dist_c")

      res_table2(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,line_code,vehicle_serial,actual_capacity_load,
        vehicle_type,start_longitude,start_latitude,end_longitude,end_latitude,rt_coords,x1,y1,x2,y2,
        duration,time,tl_time,rt_dist,highwaymileage,toll_charge,start_distance,end_distance,error_type,err_log,task_inc_day,
        start_time,halfway_integrate_rate,line_require_id,start_sortnum,end_sortnum,dist_a,dist_b,dist_c)
    })
      //      .repartition(100)
      .toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)
    logger.error("结果表2写入完成")
  }

  //写入结果表3
  def saveTable3(spark: SparkSession, inc_day: String, standardLineRdd: RDD[JSONObject]) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_route"
    //测试表dm_gis.eta_std_line_route_aaa
    //    val saveTableName = "dm_gis.eta_std_line_route_test"

    logger.error("当前inc_day为：" + inc_day)
    logger.error("正在写入结果表3")
    //    /**
    //      * 删除中间表1，60天前数据
    //      */
    //    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-60)
    //    val dropSql =
    //      s"""
    //         |alter table ${saveTableName} drop if exists partition (inc_day='${dropDate}')
    //       """.stripMargin
    //    logger.error("删除结果表3的45天前数据" + dropSql)
    //    spark.sql(dropSql)


    val res = standardLineRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val line_code= x.getString("line_code")
      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val start_time= x.getString("start_time")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val pns_dist= x.getString("pns_dist")
      val pns_time= x.getString("pns_time")
      val src= x.getString("src")
      val std_coords= x.getString("std_coords")
      val line_distance_std= x.getString("line_distanc" +
        "e_std")
      val line_time_std= x.getString("line_time_std")
      val err_log = x.getString("err")
      val task_subid = x.getString("task_subid")

      //20211011新增字段

      val std_id = x.getString("std_id")
      val std_x1 = x.getString("std_x1")
      val std_y1 = x.getString("std_y1")
      val std_x2 = x.getString("std_x2")
      val std_y2 = x.getString("std_y2")

      val std_toll_charge = x.getString("std_toll_charge")

      val line_require_id = x.getString("line_require_id")

      //20220823
      val start_outer_add_code = x.getString("start_outer_add_code")
      val end_outer_add_code = x.getString("end_outer_add_code")
      val start_sortnum = x.getString("start_sortnum")
      val end_sortnum = x.getString("end_sortnum")



      res_table3(task_area_code,line_code,start_dept,end_dept,start_time,actual_capacity_load,
        pns_dist,pns_time,src,std_coords,line_distance_std,line_time_std,err_log,task_subid,std_id,std_x1,std_y1,std_x2,std_y2,
        std_toll_charge,line_require_id,start_outer_add_code,end_outer_add_code,start_sortnum,end_sortnum,inc_day)
    })
      .repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)
    logger.error("结果表3写入完成")
  }

  def getRes1table(spark: SparkSession, inc_day: String) = {

    val sourceSql  =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_task
         |where
         | inc_day='${inc_day}'
       """.stripMargin

    val df = spark.sql(sourceSql)
    val res1Rdd = SparkUtils.getRowToJson(df,"MemoryAndDisk")
    //    res1Rdd.take(2).foreach(println(_))

    res1Rdd

  }

  def getParseTrackRate(response: String) = {

    val res = JSON.parseObject(response)
    val result = res.getJSONObject("result")
    val data = result.getJSONObject("data")
    val stopData = data.getJSONArray("stopData").getJSONObject(0)

    val realDis = JSONUtils.getJsonValueDouble(stopData,"realDis",0)
    val virDis = JSONUtils.getJsonValueDouble(stopData,"virDis",0)
    val halfway_integrate_rate = if (virDis != 0) realDis / virDis  else 0
    halfway_integrate_rate
  }

  def schedulerTrackRateInterface(x: JSONObject, jo:JSONObject) = {

    val json = new JSONObject()
    val stopListJson = new JSONObject()
    val stopList = new JSONArray()

    val task_id = x.getString("task_id")
    val vehicle_serial = x.getString("vehicle_serial")

    val actual_depart_tm = x.getString("actual_depart_tm")
    val beginDateTime = jo.getString("beginDateTime")
    val endDateTime = jo.getString("endDateTime")
    val start_dept = x.getString("start_dept")
    val end_dept = x.getString("end_dept")
    val x1 = x.getString("x1")
    val y1 = x.getString("y1")
    val x2 = x.getString("x2")
    val y2 = x.getString("y2")

    stopListJson.put("actual_depart_tm",actual_depart_tm)
    stopListJson.put("beginDateTime",beginDateTime)
    stopListJson.put("endDateTime",endDateTime)
    stopListJson.put("beginDeptCode",start_dept)
    stopListJson.put("endDeptCode",end_dept)
    stopListJson.put("beginLon",x1)
    stopListJson.put("beginLat",y1)
    stopListJson.put("endLon",x2)
    stopListJson.put("endLat",y2)
    stopListJson.put("index",1)

    stopList.add(stopListJson)

    json.put("ak","e640de2b47394b19862ee134d817bbc7")
    json.put("taskId",task_id)
    json.put("un",vehicle_serial)
    json.put("type",0)
    json.put("timeThreshold",300)
    json.put("disThreshold",5000)
    json.put("stopList",stopList)

    //    val url = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/rate/trackRate"
    //20230822切换新的url
    //val url = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/rate/trackRate"
    val url = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/rate/trackRate"
    var halfway_integrate_rate = 0.0
    var retryCnt = 0

    val response = Utils.retryPost(url,json)
    //
    //    logger.error("+++++++++++++++++++++++++++++")
    //    println("轨迹完整率返回为：" + response)
    //    logger.error("+++++++++++++++++++++++++++++")

    //    halfway_integrate_rate = try{getParseTrackRate(response)} catch {case e:Exception => 0}


    //    while (halfway_integrate_rate == 0 && retryCnt < 3){
    //      val response = Utils.post(url,json,"utf-8")
    //      halfway_integrate_rate = try{getParseTrackRate(response)} catch {case e:Exception => 0}
    //      retryCnt += 1
    //    }
    halfway_integrate_rate = try{getParseTrackRate(response)} catch {case e:Exception => 0}

    halfway_integrate_rate

  }

  def schedulerHisTrackInterface(x: JSONObject, jo: JSONObject) = {

    //    val url = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
    //20230822切换新的url
    //val url = "http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"
    val url="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
    var rt_coords = ""

    //val repJson = new JSONObject()
    val rep = Utils.retryPost(url, jo)
    //    logger.error("+++++++++++++++++++++++++++++")
    //    println("历史轨迹返回为：" + rep)
    //    logger.error("+++++++++++++++++++++++++++++")

    val repJson =
      try {
        parseTrajRectify(x, rep)
      } catch {
        case e: Exception =>
          val errJo = new JSONObject()
          errJo.put("err", e + "接口异常返回为：" + rep)
          errJo.put("errInfo",rep)
          errJo
      }
    //    var repJson = new JSONObject()
    //    var retryCnt = 0
    //
    //    while (StringUtils.isEmpty(rt_coords)  && retryCnt < 3){
    //      val rep = Utils.post(url, jo, "utf-8")
    //       try {
    //         repJson = parseTrajRectify(x, rep)
    //      } catch {
    //        case e: Exception =>
    //          val errJo = new JSONObject()
    //          errJo.put("err", e)
    //          errJo
    //      }
    //      rt_coords =  repJson.getString("rt_coords")
    //      retryCnt += 1
    //    }

    repJson

  }

  def getErrorType(x: JSONObject) = {

    val rt_coords = try {x.getJSONArray("rt_coords")}catch {case e:Exception => new JSONArray()}
    val start_distance = JSONUtils.getJsonValueDouble(x,"start_distance",0)
    val end_distance = JSONUtils.getJsonValueDouble(x,"end_distance",0)
    val halfway_integrate_rate = JSONUtils.getJsonValueDouble(x,"halfway_integrate_rate",0)

    val err = x.getString("err")


    //  轨迹异常标记字段【error_type】：
    //    符合多个条件时，组合标识，中间用“|”分隔，条件如下：
    //    ①纠偏轨迹点 rt_coords为空时：	error_type = 1
    //    ②轨迹起点与任务起点距离start_distance>500m：  error_type = 2
    //    ③轨迹终点与任务终点距离end_distance>500m:   error_type = 3
    //    均不符合时，error_type = 0

    val error_type = new StringBuilder

    //    if ( rt_coords == null || rt_coords .size() == 0){
    //      if(error_type.isEmpty){
    //        error_type.append("1")
    //      }else{
    //        error_type.append("|").append("1")
    //      }
    //    }

    if (start_distance > 500){
      if(error_type.isEmpty){
        error_type.append("2")
      }else{
        error_type.append("|").append("2")
      }
    }

    if (end_distance > 500){
      if(error_type.isEmpty){
        error_type.append("3")
      }else{
        error_type.append("|").append("3")
      }
    }


    if (halfway_integrate_rate < 0.9) {
      if(error_type.isEmpty){
        error_type.append("4")
      } else {
        error_type.append("|").append("4")
      }
    }


    //    20220608新增
    //    ⑤ 轨迹缺失：轨迹查询接口返回的msg为”轨迹点为空”时，error_type=5
    //    ⑥ 接口异常返回：轨迹查询接口没有返回值时，error_type=6

    //    val errInfo = x.getString("errInfo")
    //    if (StringUtils.nonEmpty(err)){
    //
    //      val req = JSON.parseObject(errInfo)
    //      val result = req.getJSONObject("result")
    //      val msg = result.getString("msg")
    //      if (StringUtils.nonEmpty(msg) && msg.contains("轨迹点为空")){
    //        if(error_type.isEmpty){
    //          error_type.append("5")
    //        } else {
    //          error_type.append("|").append("5")
    //        }
    //      }
    //    }

    if (StringUtils.nonEmpty(err)){
      if (err.contains("轨迹点为空")){
        if(error_type.isEmpty){
          error_type.append("5")
        } else {
          error_type.append("|").append("5")
        }
      }
    }

    if (rt_coords == null || rt_coords.size() == 0){
      if(error_type.isEmpty){
        error_type.append("5")
      } else if (!error_type.toString().contains("5")) {
        error_type.append("|").append("5")
      }
    }

    if (StringUtils.nonEmpty(err)){
      if(error_type.isEmpty){
        error_type.append("6")
      } else if(!(error_type.toString().contains("5"))){
        error_type.append("|").append("6")
      }
    }

    if (error_type.isEmpty) error_type.append("0")

    error_type.toString()

  }


  def processGjRectify(spark:SparkSession,getRes1Rdd: RDD[JSONObject]):RDD[JSONObject]= {

    val limitMin =5500
    //调用开始上报
    val httpUrl="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
    val httpAk="e640de2b47394b19862ee134d817bbc7"
    val dataCnt=getRes1Rdd.count()
    val invokeThreadCnt=getRes1Rdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "371318", "标准线路指标监控需求",
      "标准线路指标监控需求，外包承运商执行判断优化。",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val gjRectifyRdd = SparkUtils.akLimitMultiThreadRdd(getRes1Rdd)(calGjRectify)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    logger.error("并发数量为:" + gjRectifyRdd.count())


    //    gjRectifyRdd.take(2).foreach(println(_))
    // 计算需要重跑的rdd
    val errTypeRdd = gjRectifyRdd
      .filter(x => {
        val error_type = JSONUtils.getJsonValue(x,"error_type","0")
        error_type.equals("2") || error_type.equals("3")
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("需要重跑的数据量为：" + errTypeRdd.count())

    // 不需要重跑的rdd
    val correctTypeRdd = gjRectifyRdd.filter(x => {
      val error_type = JSONUtils.getJsonValue(x,"error_type","0")
      !error_type.equals("2") && !error_type.equals("3")
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("不需要重跑的数据量为：" + correctTypeRdd.count())

    // 更新起始时间
    val findActualRdd = errTypeRdd.map(x => {findActualTm(x)}).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("更新起终数据量为：" + findActualRdd.count())


    // 重跑接口
    //调用开始上报
    val httpUrl2="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/rate/trackRate"
    val httpAk2="e640de2b47394b19862ee134d817bbc7"
    val dataCnt2=findActualRdd.count()
    val invokeThreadCnt2=findActualRdd.getNumPartitions
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "371318", "标准线路指标监控需求",
      "标准线路指标监控需求，外包承运商执行判断优化。",
      httpUrl2, httpAk2, dataCnt2, invokeThreadCnt2)

    val errTypeReProcessRdd = SparkUtils.akLimitMultiThreadRdd(findActualRdd)(calGjRectify)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)

    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId2)
    logger.error("并发数量为:" + gjRectifyRdd.count())

    val getUnionRdd = correctTypeRdd.union(errTypeReProcessRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("getUnionRdd的数据量为：" + getUnionRdd.count())

    getUnionRdd
  }


  def findActualTm(x:JSONObject):JSONObject = {

    // 实际起始时间
    val actual_depart_tm = JSONUtils.getJsonValue(x,"actual_depart_tm","2000-01-01 00:00:00")
    val actual_depart_tm_stamp = DateTimeUtil.timeToLong(actual_depart_tm,"yyyy-MM-dd HH:mm:ss")
    //实际到达时间
    val actual_arrive_tm = JSONUtils.getJsonValue(x,"actual_arrive_tm","2000-01-01 00:00:00")
    val actual_arrive_tm_stamp = DateTimeUtil.timeToLong(actual_arrive_tm,"yyyy-MM-dd HH:mm:ss")

    val stay_list = JSONUtils.getJsonValue(x,"stay_list","[]")
    val stayList = JSON.parseArray(stay_list)

    // 计算离stayList里面坐标点最近的起始点和终止点
    // 条件1 时间离起始点startTimeStamp最近
    // 条件2 开始停留位置&结束停留位置与终点网点的距离((startLon,startLat)、(endLon,endLat)与(end_longitude,end_latitude)计算距离)，若至少有一个距离<500m

    // 获取原起始点时间戳
    val beginDateTime = JSONUtils.getJsonValue(x,"beginDateTime","20000101000000")
    val beginDateTimeStamp = DateTimeUtil.timeToLong(beginDateTime,"yyyyMMddHHmmss")
    //获取原终止点时间戳
    val endDateTime = JSONUtils.getJsonValue(x,"endDateTime","20000101000000")
    val endDateTimeStamp = DateTimeUtil.timeToLong(endDateTime,"yyyyMMddHHmmss")

    var startTimeMax = beginDateTimeStamp
    var endTimeMin = endDateTimeStamp

    // 获取原起始点坐标
    val start_longitude = JSONUtils.getJsonValueDouble(x,"start_longitude",0.0)
    val start_latitude = JSONUtils.getJsonValueDouble(x,"start_latitude",0.0)
    // 获取终止点坐标
    val end_longitude = JSONUtils.getJsonValueDouble(x,"end_longitude",0.0)
    val end_latitude = JSONUtils.getJsonValueDouble(x,"end_latitude",0.0)


    if (!stayList.isEmpty()){
      for (i <- (0 until(stayList.size()))){

        val curPoint = stayList.getJSONObject(i)
        val startLon = JSONUtils.getJsonValueDouble(curPoint,"startLon",0.0)
        val startLat = JSONUtils.getJsonValueDouble(curPoint,"startLat",0.0)
        val endLon = JSONUtils.getJsonValueDouble(curPoint,"endLon",0.0)
        val endLat = JSONUtils.getJsonValueDouble(curPoint,"endLat",0.0)
        val startTimeStamp = JSONUtils.getJsonValueLong(curPoint,"startTime",0L) * 1000
        val endTimeStamp = JSONUtils.getJsonValueLong(curPoint,"endTime",0L) * 1000

        // 比较与实际坐标点距离
        val start_start_Dist = DistanceTool.getGreatCircleDistance(startLon,startLat,start_longitude,start_latitude)
        val start_end_Dist = DistanceTool.getGreatCircleDistance(endLon,endLat,start_longitude,start_latitude)

        val end_start_Dist = DistanceTool.getGreatCircleDistance(startLon,startLat,end_longitude,end_latitude)
        val end_end_Dist = DistanceTool.getGreatCircleDistance(endLon,endLat,end_longitude,end_latitude)

        if (startTimeStamp < actual_depart_tm_stamp  && startTimeStamp > startTimeMax && (start_start_Dist <500 || start_end_Dist < 500)){
          startTimeMax = startTimeStamp
        }

        if (endTimeStamp > actual_arrive_tm_stamp && endTimeStamp < endTimeMin && (end_start_Dist <500 || end_end_Dist < 500)){
          endTimeMin = endTimeStamp
        }
      }

      x.put("beginDateTime",DateTimeUtil.timestampConvertDate2(startTimeMax,"yyyyMMddHHmmss"))
      x.put("endDateTime",DateTimeUtil.timestampConvertDate2(endTimeMin,"yyyyMMddHHmmss"))
    }


    x

  }


  /**
   * 计算历史轨迹与轨迹完整率
   * @param x
   * @return
   */

  def  calGjRectify(x:JSONObject):JSONObject = {
    val vehicle_serial = x.getString("vehicle_serial")
    val error_type = JSONUtils.getJsonValue(x,"error_type","0")

    val actual_depart_tm = x.getString("actual_depart_tm")

    val beginDateTimeNew = if (!error_type.equals("2") && !error_type.equals("3")) {
      try {
        DateTimeUtil.transformDateFormat(actual_depart_tm, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
      } catch {
        case e: Exception => "20000101000000"
      }
    } else {
      JSONUtils.getJsonValue(x,"beginDateTime","20000101000001")
    }


    //    actual_depart_tm 往前取5min，转成yyyyMMddhhmmss格式
    //    val beginDateTime = try {
    //      DateTimeUtil.getMinBeforeAfter(actual_depart_tm, "yyyy-MM-dd HH:mm:ss", -5)
    //    } catch {
    //      case e: Exception => "2000-01-01 00:00:00"
    //    }
    //    val beginDateTimeNew = if (!error_type.equals("2") && !error_type.equals("3")) {
    //      try {
    //        DateTimeUtil.transformDateFormat(beginDateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
    //      } catch {
    //        case e: Exception => "20000101000000"
    //      }
    //    } else {
    //      JSONUtils.getJsonValue(x,"beginDateTime","20000101000001")
    //    }


    // 中间表1的actual_arrive_tm 往后取5min，转成yyyyMMddhhmmss格式
    val actual_arrive_tm = x.getString("actual_arrive_tm")

    val endDateTimeNew = if (!error_type.equals("2") && !error_type.equals("3")) {
      try {
        DateTimeUtil.transformDateFormat(actual_arrive_tm, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
      } catch {
        case e: Exception => "20000101000000"
      }
    } else {
      JSONUtils.getJsonValue(x,"actual_arrive_tm","20000101000002")
    }

    val jo = new JSONObject()
    jo.put("un", vehicle_serial)
    jo.put("type", 0)
    jo.put("beginDateTime", beginDateTimeNew)
    jo.put("endDateTime", endDateTimeNew)
    jo.put("ak", "e640de2b47394b19862ee134d817bbc7")
    jo.put("stayDuration", 30)
    jo.put("stayRadius", 50)
    jo.put("addpoint", 1)
    jo.put("compensate",1)


    val start_longitude = x.getString("start_longitude")
    val start_latitude = x.getString("start_latitude")
    val end_longitude = x.getString("end_longitude")
    val end_latitude = x.getString("end_latitude")

    // 20220817新增
    jo.put("beginAnachorX",start_longitude)
    jo.put("beginAnachorY",start_latitude)
    jo.put("endAnachorX",end_longitude)
    jo.put("endAnachorY",end_latitude)
    jo.put("anchor",2)


    // 20220513增加输入字段
    val vehicle = JSONUtils.getJsonValue(x,"vehicle_type","6")
    val actual_capacity_load = JSONUtils.getJsonValue(x,"actual_capacity_load","")
    jo.put("vehicle",vehicle)
    val vehicleInfo = new JSONObject()
    vehicleInfo.put("load",actual_capacity_load)
    jo.put("vehicleInfo",vehicleInfo)

    //    logger.error("+++++++++++++++++++++++++++++")
    //    println("历史轨迹输入为：" + jo.toJSONString)
    //    logger.error("+++++++++++++++++++++++++++++")

    val repJson = schedulerHisTrackInterface(x, jo)
    //    logger.error("+++++++++++++++++++++++++++++")
    //    println("解析返回为：" + repJson.toJSONString)

    //20211011新增halfway_integrate_rate统计
    val halfway_integrate_rate = schedulerTrackRateInterface(repJson, jo).formatted("%.2f")
    x.put("halfway_integrate_rate", halfway_integrate_rate)
    x.fluentPutAll(repJson)

    //计算err_type
    val errType = try {getErrorType(x) } catch {case e :Exception => "0"}

    x.put("error_type",errType)
    x.put("beginDateTime",beginDateTimeNew)
    x.put("endDateTime",endDateTimeNew)

    x
  }



  def getSourceSim(spark: SparkSession, inc_day: String) = {

    val inc_day_pre3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

    //    val rectifySql =
    //      s"""
    //         |select
    //         |  *
    //         |from
    //         |  dm_gis.eta_std_line_rectify
    //         |where
    //         |  inc_day = '${inc_day}'
    //       """.stripMargin
    //
    //    val routeSql =
    //      s"""
    //         |select
    //         |  *
    //         |from
    //         |  dm_gis.eta_std_line_route
    //         |where
    //         |  inc_day >= '${inc_day_pre3}'
    //         |and
    //         |  inc_day <= '${inc_day}'
    //       """.stripMargin
    //    val df1 = spark.sql(rectifySql)
    //    val rectifyRdd = SparkUtils.getRowToJson(df1,"MEMORY_AND_DISK").map(x => {
    //      val task_inc_day = x.getString("task_inc_day")
    //      val start_dept = x.getString("start_dept")
    //      val end_dept = x.getString("end_dept")
    //      val line_code = x.getString("line_code")
    //      val actual_capacity_load = x.getString("actual_capacity_load")
    //      ((task_inc_day,start_dept,end_dept,line_code,actual_capacity_load),x)
    //    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //
    //
    //
    //    val df2 = spark.sql(routeSql)
    //    val routeRdd = SparkUtils.getRowToJson(df2,"MEMORY_AND_DISK").map(x => {
    //      val inc_day = x.getString("inc_day")
    //      val start_dept = x.getString("start_dept")
    //      val end_dept = x.getString("end_dept")
    //      val line_code = x.getString("line_code")
    //      val actual_capacity_load = x.getString("actual_capacity_load")
    //      ((inc_day,start_dept,end_dept,line_code,actual_capacity_load),x)
    //    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //
    //
    //    rectifyRdd.leftOuterJoin(routeRdd).map(x => {
    //
    //      val left = x._2._1
    //      val rightOption = x._2._2
    //
    //    })

    val source1Sql =
      s"""
         |select
         |    a.task_id,a.sort_num,a.task_subid,a.start_dept,a.end_dept,a.line_code,a.vehicle_serial,
         |    a.actual_capacity_load,a.vehicle_type,a.rt_coords,b.std_coords,a.start_time start_time,
         |    if(b.pns_dist ='' or b.pns_dist is null,1,0) flag,a.task_inc_day task_inc_day,pns_dist,pns_time,src,
         |    line_distance_std,std_x1,std_y1,std_x2,std_y2,line_time_std,std_id,start_longitude,start_latitude,end_longitude,end_latitude
         |from
         |(
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_rectify
         |where
         |  inc_day = '${inc_day}'
         | -- and
         | -- line_code='028AAQ028R1600'
         |) a
         |left outer join
         |(
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_route
         |where
         |  inc_day >= '${inc_day_pre3}'
         |and
         |  inc_day <= '${inc_day}'
         |) b
         |on
         |    a.line_require_id = b.line_require_id
         |and
         |    a.end_sortnum = b.end_sortnum
         |and
         |    a.end_dept = b.end_dept
       """.stripMargin


    val df = spark.sql(source1Sql)
    val sourceRdd = SparkUtils.getRowToJson(df,"MEMORYANDDISK")

    //没有关联到标准线路的任务结果表3，先调标准线路接口获取线路
    val sourceRdd1 = sourceRdd.filter(_.getIntValue("flag") == 1)
    logger.error("未关联到结果表3的数据为：" + sourceRdd1.count())

    //调接口计算相似度
    val sourceRdd2 = sourceRdd.filter(_.getIntValue("flag") == 0)
    logger.error("关联到结果表3的数据为：" + sourceRdd2.count())

    (sourceRdd2,sourceRdd1)

  }




  def getSimProcess(sourceSimilarRdd1: RDD[JSONObject], sourceSimilarRdd2: RDD[JSONObject]) = {

    // 连接上调接口计算相似度
    val limitMin = 5500

    val partionNum = sourceSimilarRdd1.getNumPartitions
    val sim1Rdd = sourceSimilarRdd1.mapPartitionsWithIndex((index, iter) => {
      val partitionLimitMinu = limitMin * 0.9 / partionNum
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }
        val rt_coords = x.getString("rt_coords")
        val std_coords = x.getString("std_coords")
        val vehicle_type = x.getString("vehicle_type")

        if (StringUtils.nonEmpty(rt_coords) && StringUtils.nonEmpty(std_coords)) {

          val joArray1 = new JSONArray()
          val array1 = try { JSON.parseArray(rt_coords)} catch {case e:Exception => new JSONArray()}

          for (i <- 0 until (array1.size())) {
            val json = array1.getJSONObject(i)
            val x = json.getDouble("dx")
            val y = json.getDouble("dy")
            val arrayNew = new JSONArray()
            arrayNew.add(x)
            arrayNew.add(y)
            joArray1.add(arrayNew)
          }

          val jo1 = new JSONObject()
          val jo2 = new JSONObject()

          jo1.put("rt_coords", joArray1)
          jo1.put("vehicle_type", vehicle_type)
          jo2.put("rt_coords", std_coords)

          var errLog = ""

          var (sim1, sim5) = try{getSimilarInterface2.getSimilar2(jo1, jo2)} catch {case e:Exception =>
            x.put("errLog",e)
            (0,0)
          }

          x.put("jo1", jo1)
          x.put("jo2", jo2)
          x.put("sim1", sim1)
          x.put("sim5", sim5)

        }
        x
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("sim1Rdd的数据量为：" + sim1Rdd.count())



    val sim2RddPre = sourceSimilarRdd2.repartition(20)
      .mapPartitionsWithIndex((index, iter) => {

        val partitionLimitMinu = limitMin * 0.9 / 20
        val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
        val timeInt = new AtomicInteger(0)
        val partitionsCount = new AtomicInteger(0)

        iter.map(x => {
          if (partitionsCount.incrementAndGet() % 10000 == 0) {
            logger.error(partitionsCount)
          }
          val second = Calendar.getInstance().get(Calendar.SECOND)
          val cur = Calendar.getInstance().get(Calendar.MINUTE)
          if (cur == lastMin.get()) {
            if (timeInt.incrementAndGet() >= partitionLimitMinu) {
              logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
              Thread.sleep((60 - second) * 1000)
            }
          } else {
            //不能精细控制，set存在并发问题
            timeInt.set(1)
            lastMin.set(cur)
          }
          //未连接上，调标准线路接口获取线路（调一遍标准线路接口），再调相似度接口
          val resJson = try {schedulerStaInterface(x) } catch {case e:Exception => new JSONObject()}
          resJson
        })
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("sim2RddPre的数据量为：" + sim2RddPre.count())


    //调接口计算相似度
    val sim2Rdd = sim2RddPre.
      repartition(20).mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 20
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }

        val rt_coords = x.getString("rt_coords")
        val std_coords = x.getString("std_coords")
        val vehicle_type = x.getString("vehicle_type")

        if (StringUtils.nonEmpty(rt_coords) && StringUtils.nonEmpty(std_coords)) {
          val joArray1 = new JSONArray()
          val array1 = try { JSON.parseArray(rt_coords) } catch {case e:Exception => new JSONArray()}
          for (i <- 0 until (array1.size())) {
            val json = array1.getJSONObject(i)
            val x = json.getDouble("dx")
            val y = json.getDouble("dy")
            val arrayNew = new JSONArray()
            arrayNew.add(x)
            arrayNew.add(y)
            joArray1.add(arrayNew)
          }

          val jo1 = new JSONObject()
          val jo2 = new JSONObject()
          jo1.put("rt_coords", joArray1)
          jo1.put("vehicle_type", vehicle_type)
          jo2.put("rt_coords", std_coords)
          var (sim1, sim5) =  try{getSimilarInterface2.getSimilar2(jo1, jo2)} catch {case e:Exception => (0,0)}

          val task_id = JSONUtils.getJsonValue(x,"task_id","")
          System.err.println(task_id)

          x.put("sim1", sim1)
          x.put("sim5", sim5)
          x.put("jo1", jo1)
          x.put("jo2", jo2)

        }
        x
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("sim2Rdd的数据量为：" + sim2Rdd.count())
    //    sim2Rdd.take(2).foreach(println(_))

    val simRdd = sim1Rdd.union(sim2Rdd)

    simRdd

  }

  def saveTable4(spark: SparkSession, inc_day: String, getSimRdd: RDD[JSONObject]) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_similarity"
    //测试表dm_gis.eta_std_line_similarity_aaa
    //val saveTableName = "dm_gis.eta_std_line_similarity_test"

    logger.error("正在写入结果表4")
    val res = getSimRdd.map(x => {
      val task_id = JSONUtils.getJsonValue(x,"task_id","")
      val sort_num = JSONUtils.getJsonValue(x,"sort_num","")
      val task_subid = JSONUtils.getJsonValue(x,"task_subid","")
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept= JSONUtils.getJsonValue(x,"end_dept","")
      val line_code= JSONUtils.getJsonValue(x,"line_code","")
      val vehicle_serial= JSONUtils.getJsonValue(x,"vehicle_serial","")
      val actual_capacity_load= JSONUtils.getJsonValue(x,"actual_capacity_load","")
      val vehicle_type= JSONUtils.getJsonValue(x,"vehicle_type","")
      val sim1= JSONUtils.getJsonValue(x,"sim1","")
      val sim5= JSONUtils.getJsonValue(x,"sim5","")
      val task_inc_day = JSONUtils.getJsonValue(x,"task_inc_day","")

      //20211011新增字段
      val route_source = JSONUtils.getJsonValue(x,"flag","")
      val pns_dist =  JSONUtils.getJsonValue(x,"pns_dist","")
      val pns_time = JSONUtils.getJsonValue(x,"pns_time","")
      val src = JSONUtils.getJsonValue(x,"src","")
      val std_coords = JSONUtils.getJsonValue(x,"std_coords","")
      val line_distance_std = JSONUtils.getJsonValue(x,"line_distance_std","")
      val line_time_std = JSONUtils.getJsonValue(x,"line_time_std","")
      val std_x1 = JSONUtils.getJsonValue(x,"std_x1","")
      val std_y1 = JSONUtils.getJsonValue(x,"std_y1","")
      val std_x2 = JSONUtils.getJsonValue(x,"std_x2","")
      val std_y2 = JSONUtils.getJsonValue(x,"std_y2","")

      val std_toll_charge = JSONUtils.getJsonValue(x,"std_toll_charge","")
      val std_id = JSONUtils.getJsonValue(x,"std_id","")

      res_table4(task_id,sort_num,task_subid,start_dept,end_dept,line_code,vehicle_serial,actual_capacity_load,vehicle_type,sim1,sim5,task_inc_day,
        route_source,pns_dist,pns_time,src,std_coords,line_distance_std,line_time_std,std_x1,std_y1,std_x2,std_y2,std_toll_charge,std_id)
    }).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表4写入完成")
  }

  def getComputeSource(spark: SparkSession, inc_day: String) = {

    val inc_day_pre3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)
    val inc_day_pre4 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-4)
    val inc_day_pre7 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-7)

    val sourceSql =
      s"""
         |  select
         |  a.task_area_code,a.task_id,a.sort_num,a.task_subid,a.start_dept,a.end_dept,
         |  a.line_code,sim1,sim5,rt_dist,b.tl_time,pns_dist,pns_time,a.actual_capacity_load,
         |  a.task_inc_day,a.log_dist,a.line_distance,a.line_time,x1,y1,x2,y2,std_x1,std_y1,std_x2,std_y2,actual_run_time,error_type err_type,
         |  -- navi_strategy,is_return_std_line,is_navi_at_start,is_navi_by_std_line,route_time,drive_time,is_yaw_by_driver,drive_time / actual_run_time as navi_complete_rate,
         |  '' as navi_strategy,'' as is_return_std_line,'' as is_navi_at_start,'' as is_navi_by_std_line,'' as route_time,'' as drive_time,'' as is_yaw_by_driver,'' as navi_complete_rate,'' as accrual_dist,'' as accrual_dist_type,
         |  navi_starttime,navi_endtime,navi_time,navi_distance,is_navi,navi_count,type,rt_coords,a.start_outer_add_code,a.end_outer_add_code,carrier_type,vehicle_type,start_type,end_type,a.carrierid
         |from
         |  (
         |    select
         |      task_area_code,
         |      task_id,
         |      sort_num,
         |      task_subid,
         |      start_dept,
         |      end_dept,
         |      line_code,
         |      line_distance,
         |      log_dist,
         |      line_time,
         |      task_inc_day,
         |      actual_capacity_load,
         |      actual_run_time,
         |      start_time,
         |      nvl(start_outer_add_code,'-') start_outer_add_code,
         |      nvl(end_outer_add_code,'-') end_outer_add_code,
         |      type,
         |      carrier_type,vehicle_type,start_type,end_type,
         |      case when child_carrier_id is not null and trim(child_carrier_id) !='' then child_carrier_id
         |      when carrier_id is not null and trim(carrier_id) !='' then carrier_id else '' end carrierid
         |    from
         |      dm_gis.eta_std_line_task
         |    where
         |      inc_day = '${inc_day}'
         |  ) a
         |  left outer join (
         |    select
         |      rt_dist,
         |      tl_time,
         |      task_subid,
         |      x1,y1,x2,y2,error_type,rt_coords
         |    from
         |      dm_gis.eta_std_line_rectify
         |    where
         |      inc_day = '${inc_day}'
         |  ) b on a.task_subid = b.task_subid
         |  left outer join (
         |    select
         |      -- pns_dist,
         |      -- pns_time,
         |      inc_day,
         |      start_dept,
         |      end_dept,
         |      line_code,
         |      actual_capacity_load,
         |      start_time
         |    from
         |      dm_gis.eta_std_line_route
         |    where
         |      inc_day >= '${inc_day_pre3}'
         |      and inc_day <= '${inc_day}'
         |  ) c on a.task_inc_day = c.inc_day
         |  and a.start_dept = c.start_dept
         |  and a.end_dept = c.end_dept
         |  and a.line_code = c.line_code
         |  and a.actual_capacity_load = c.actual_capacity_load
         |  and a.start_time = c.start_time
         |  left outer join (
         |    select
         |      sim1,
         |      sim5,
         |      task_subid,
         |      std_x1,std_y1,std_x2,std_y2,pns_time,pns_dist
         |    from
         |      dm_gis.eta_std_line_similarity
         |    where
         |      inc_day = '${inc_day}'
         |  ) d on a.task_subid = d.task_subid
         |  left outer join (
         |    select
         |    *
         |    from
         |    (
         |    select
         |        task_id
         |        ,start_dept
         |        ,end_dept
         |        ,nvl(start_outer_add_code,'-') start_outer_add_code
         |        ,nvl(end_outer_add_code,'-') end_outer_add_code
         |        ,navi_starttime
         |        ,navi_endtime
         |        ,navi_time
         |        ,navi_distance
         |        ,is_navi
         |        ,navi_count
         |        ,row_number() over(partition by task_id,start_dept,end_dept,start_outer_add_code,end_outer_add_code order by inc_day desc) rn
         |    from
         |        dm_gis.gis_std_line_task_navi_result
         |    where
         |        inc_day >= '${inc_day_pre7}'
         |     and
         |        inc_day <= '${inc_day}'
         |    ) t1
         |where
         |  t1.rn =1
         |  ) e
         |on a.task_id = e.task_id
         |and a.start_dept = e.start_dept
         |and a.end_dept = e.end_dept
         |and a.start_outer_add_code = e.start_outer_add_code
         |and a.end_outer_add_code = e.end_outer_add_code
                           """.stripMargin

    logger.error("结果表5的取数sql为：" + sourceSql)

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf,"MEMORY_AND_DISK",400)
    logger.error("结果表5输入数据量为：" + sourceRdd.count())
    //    sourceRdd.take(2).foreach(println(_))

    sourceRdd

  }

  /**
   * 计算10分钟分割区间值
   * @param input
   */

  def calApart10Min(input: Double) = {
    var diff_time_10min = 0
    var addDiffTime = 0

    if (input > 0){
      val addDiffTimeCal = (input / 10).toInt
      val addDiffTimeCaladd = input - addDiffTimeCal * 10
      if (addDiffTimeCaladd > 0){
        addDiffTime = 10
      } else{
        addDiffTime = 0
      }
      diff_time_10min = addDiffTimeCal * 10 + addDiffTime
    }else{
      val addDiffTimeRtCal = (input / 10).toInt
      val addDiffTimeRtCaladd = input - addDiffTimeRtCal * 10
      if (addDiffTimeRtCaladd < 0){
        addDiffTime = -10
      } else{
        addDiffTime = 0
      }
      diff_time_10min = addDiffTimeRtCal * 10 + addDiffTime
    }

    diff_time_10min
  }

  def saveTable5(spark: SparkSession, inc_day: String, getComputeRdd: RDD[JSONObject]) = {

    import spark.implicits._
    val saveTableName = "dm_gis.eta_std_line_compute"
    //测试表dm_gis.eta_std_line_compute_aaa
    //    val saveTableName = "dm_gis.eta_std_line_compute_test"
    logger.error("正在写入结果表5")
    //   logger.error("getComputeRdd数据量："+getComputeRdd.count())
    val computeResRdd = getComputeRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")
      val task_subid= x.getString("task_subid")
      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val line_code= x.getString("line_code")
      val sim1 = JSONUtils.getJsonValueDouble(x,"sim1",0)
      val sim5 = JSONUtils.getJsonValueDouble(x,"sim5",0)
      val rt_dist= JSONUtils.getJsonValueDouble(x,"rt_dist",0)
      val line_distance= JSONUtils.getJsonValueDouble(x,"line_distance",0)
      val log_dist= JSONUtils.getJsonValueDouble(x,"log_dist",0)
      val pns_dist= JSONUtils.getJsonValueDouble(x,"pns_dist",0)

      // TODO: 接口返回配置里程是否准确
      val if_dist_equal = if (Math.abs(line_distance - (pns_dist / 1000)) <= 1) 1 else 0
      // TODO: 实际里程与规划里程偏差(m)
      val diffdist_rt_line = rt_dist - (line_distance * 1000)
      // TODO: 实际里程与规划里程偏差率
      val diffratio_rt_line = if(line_distance != 0) diffdist_rt_line / (line_distance * 1000) else 0
      // TODO: 实际里程与标准线路里程偏差(m)
      val diffdist_rt_std = rt_dist - pns_dist
      // TODO: 实际里程与标准线路里程偏差率
      val diffratio_rt_std = if(pns_dist !=0) diffdist_rt_std / pns_dist else 0
      // TODO: 实际里程与码表里程偏差(m)
      val diffdist_rt_log = if (log_dist != 0) (rt_dist - log_dist) else 0
      // TODO: 实际里程与码表里程偏差率
      val diffratio_rt_log = if (log_dist != 0) diffdist_rt_log / log_dist else 0
      // TODO: 规划里程与码表里程偏差(m)
      val diffdist_line_log = if (log_dist != 0) line_distance - log_dist else 0
      // TODO: 规划里程与码表里程偏差率
      val diffratio_line_log = if (log_dist != 0) diffdist_line_log / log_dist else 0
      // TODO: 规划里程与标准线路里程偏差(m)
      val diffdist_line_std = line_distance - pns_dist
      // TODO: 规划里程与标准线路里程偏差率
      val diffratio_line_std = if (pns_dist != 0) diffdist_line_std / pns_dist else 0
      // TODO: 码表里程与标准线路里程偏差(m)
      val diffdist_log_std = if (log_dist != 0) log_dist - pns_dist else 0
      // TODO: 码表里程与标准线路里程偏差率
      val diffratio_log_std = if (log_dist != 0) diffdist_log_std / pns_dist else 0

      //      val conduct_type = line_distance match {
      //        case line_distance if (line_distance > 0 && line_distance <= 50 && Math.max(sim1,sim5) > 0.75 && Math.min(sim1,sim5) >= 0.7) => 1
      //        case line_distance if (line_distance > 50 && line_distance <= 100 && Math.max(sim1,sim5) > 0.8 && Math.min(sim1,sim5) >= 0.75) => 1
      //        case line_distance if (line_distance > 100 && line_distance <= 500 && Math.max(sim1,sim5) > 0.85 && Math.min(sim1,sim5) >= 0.8) => 1
      //        case line_distance if (line_distance > 500  && Math.max(sim1,sim5) > 0.9 && Math.min(sim1,sim5) >= 0.85) => 1
      //        case _ => 3
      //      }
      val conduct_type = JSONUtils.getJsonValueInt(x,"conduct_type",0)
      val line_time = JSONUtils.getJsonValueDouble(x,"line_time",0)
      val pns_time = JSONUtils.getJsonValueDouble(x,"pns_time",0)
      val tl_time = JSONUtils.getJsonValueDouble(x,"tl_time",0)

      // TODO: 接口返回配置时长是否准确
      val if_time_equal = if (Math.abs(line_time - pns_time/60) <=1) 1 else 0
      // TODO: 规划时长与标准线路时长偏差(s)
      val difftime_line_std = line_time * 60 - pns_time
      // TODO: 规划时长与标准线路时长偏差率
      val diffratio1_line_std = if(pns_time != 0) difftime_line_std / pns_time else 0
      // TODO: 规划时长与标准线路时长偏差区间
      val difftime_line_std_10min = calApart10Min(difftime_line_std/60)
      // TODO: 规划耗时与实际耗时(去停留)偏差
      val difftime_line_rt = line_time*60 - tl_time
      // TODO: 规划耗时与实际耗时(去停留)偏差率
      val diffratio1_line_rt = if (tl_time != 0) difftime_line_rt / tl_time else 0
      // TODO: 规划耗时与实际耗时偏差区间
      val difftime_rt_gh_10min = calApart10Min(difftime_line_rt/60)
      // TODO:  标准线路时长与实际耗时(去停留)偏差
      val difftime_std_rt = pns_time - tl_time
      // TODO:  标准线路时长与实际耗时(去停留)偏差率
      val diffratio1_std_rt = if(tl_time != 0 ) difftime_std_rt / tl_time else 0
      // TODO: 标准线路时长与实际耗时(去停留)偏差区间
      val difftime_std_rt_10min = calApart10Min(difftime_std_rt/60)
      // TODO: 是否准点(去停留)_std
      val is_run_ontime_std = if ( pns_time != 0 && ((tl_time/60 -1) < pns_time)) 1 else 0
      // TODO: 是否准点(去停留)
      val is_run_ontime = if (line_time != 0 && ((tl_time/60-1) < line_time)) 1 else 0
      // TODO: 接口返回异常情况
      val pns_error = if(if_dist_equal==0 && if_time_equal == 0) 0 else 1

      //20211011新增字段
      val x1 = JSONUtils.getJsonValueDouble(x,"x1",0)
      val y1 = JSONUtils.getJsonValueDouble(x,"y1",0)
      val x2 = JSONUtils.getJsonValueDouble(x,"x2",0)
      val y2 = JSONUtils.getJsonValueDouble(x,"y2",0)

      val std_x1 = JSONUtils.getJsonValueDouble(x,"std_x1",0)
      val std_y1 = JSONUtils.getJsonValueDouble(x,"std_y1",0)
      val std_x2 = JSONUtils.getJsonValueDouble(x,"std_x2",0)
      val std_y2 = JSONUtils.getJsonValueDouble(x,"std_y2",0)

      val start_distance_std = DistanceTool.getGreatCircleDistance(x1,y1,std_x1,std_y1)
      val end_distance_std = DistanceTool.getGreatCircleDistance(x2,y2,std_x2,std_y2)
      val std_line_error = if (start_distance_std > 500 || end_distance_std > 500) 1 else 0

      val actual_run_time = JSONUtils.getJsonValueDouble(x,"actual_run_time",0)

      val ac_difftime_line_rt = (line_time - actual_run_time) * 60
      val ac_diffratio1_line_rt = line_time / (actual_run_time * 60)
      val ac_difftime_rt_gh_10min = calApart10Min(difftime_line_rt / 60)
      val ac_difftime_std_rt = pns_time - actual_run_time * 60
      val ac_diffratio1_std_rt = difftime_std_rt / (actual_run_time * 60)
      val ac_difftime_std_rt_10min = calApart10Min(difftime_std_rt/60)
      val ac_is_run_ontime_std = if (actual_run_time -1 <= pns_time ) 1 else 0
      val ac_is_run_ontime = if (actual_run_time-1 <= line_time ) 1 else 0
      //conduct_type

      //20220407增加navi_strategy、is_return_std_line、is_navi_at_start、is_navi_by_std_line、route_time、drive_time、
      // is_yaw_by_driver、navi_complete_rate、accrual_dist、accrual_dist_type
      //      navi_strategy,is_return_std_line,is_navi_at_start,is_navi_by_std_line,route_time,drive_time,is_yaw_by_driver
      val navi_strategy =JSONUtils.getJsonValue(x,"navi_strategy","")
      val is_return_std_line = JSONUtils.getJsonValueInt(x,"is_return_std_line",0)
      val is_navi_at_start = JSONUtils.getJsonValueInt(x,"is_navi_at_start",0)
      val is_navi_by_std_line = JSONUtils.getJsonValueInt(x,"is_navi_by_std_line",0)
      val route_time = JSONUtils.getJsonValue(x,"route_time","")
      val drive_time = JSONUtils.getJsonValue(x,"drive_time","")
      val is_yaw_by_driver = JSONUtils.getJsonValueInt(x,"is_yaw_by_driver",0)
      val navi_complete_rate = JSONUtils.getJsonValueDouble(x,"navi_complete_rate",0).formatted("%.2f").toDouble
      val accrual_dist = JSONUtils.getJsonValueDouble(x,"accrual_dist",0).formatted("%.2f").toDouble
      val accrual_dist_type =JSONUtils.getJsonValueInt(x,"accrual_dist_type",0)

      val task_inc_day = JSONUtils.getJsonValue(x,"task_inc_day","")

      val navi_starttime = JSONUtils.getJsonValue(x,"navi_starttime","")
      val navi_endtime = JSONUtils.getJsonValue(x,"navi_endtime","")
      val navi_time = JSONUtils.getJsonValue(x,"navi_time","")
      val navi_distance = JSONUtils.getJsonValue(x,"navi_distance","")
      val is_navi = JSONUtils.getJsonValue(x,"is_navi","")
      val navi_count = JSONUtils.getJsonValue(x,"navi_count","")

      val type_info = JSONUtils.getJsonValue(x,"type","")

      //       x.put("oil_consumption",oil_consumption)
      //      x.put("oil_cost",oil_cost)
      //      x.put("total_cost",total_cost)
      val oil_consumption = JSONUtils.getJsonValue(x,"oil_consumption","")
      val oil_cost = JSONUtils.getJsonValue(x,"oil_cost","")
      val total_cost = JSONUtils.getJsonValue(x,"total_cost","")
      val std_id = JSONUtils.getJsonValue(x, "std_id", "")
      val std_coords = JSONUtils.getJsonValue(x, "std_coords", "")

      val conduct_order = JSONUtils.getJsonValueInt(x, "conduct_order", 1)

      //20230620
      val child_carrier_name = x.getString("child_carrier_name")
      val child_carrier_id = x.getString("child_carrier_id")
      val child_carrier_code = x.getString("child_carrier_code")
      val deputy_driver_account = x.getString("deputy_driver_account")
      val deputy_driver_name = x.getString("deputy_driver_name")

      res_table5(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,line_code,sim1.toString,sim5.toString,rt_dist.toString,
        line_distance.toString,log_dist.toString,pns_dist.toString,if_dist_equal.toString,diffdist_rt_line.toString,diffratio_rt_line.toString,
        diffdist_rt_std.toString,diffratio_rt_std.toString,diffdist_rt_log.toString,diffratio_rt_log.toString,diffdist_line_log.toString,
        diffratio_line_log.toString,diffdist_line_std.toString,diffratio_line_std.toString,diffdist_log_std.toString,diffratio_log_std.toString,
        conduct_type.toString,line_time.toString,pns_time.toString,tl_time.toString,if_time_equal.toString,difftime_line_std.toString,
        diffratio1_line_std.toString,difftime_line_std_10min.toString,difftime_line_rt.toString,diffratio1_line_rt.toString,
        difftime_rt_gh_10min.toString,difftime_std_rt.toString,diffratio1_std_rt.toString,difftime_std_rt_10min.toString,
        is_run_ontime_std.toString,is_run_ontime.toString,pns_error.toString,task_inc_day,
        actual_run_time,x1,y1,x2,y2,std_x1,std_y1,std_x2,std_y2,start_distance_std,end_distance_std,std_line_error,
        ac_difftime_line_rt,ac_diffratio1_line_rt,ac_difftime_rt_gh_10min,ac_difftime_std_rt,ac_diffratio1_std_rt,ac_difftime_std_rt_10min,ac_is_run_ontime_std,ac_is_run_ontime,
        navi_strategy,is_return_std_line,is_navi_at_start,is_navi_by_std_line,route_time,drive_time,is_yaw_by_driver,navi_complete_rate,accrual_dist,accrual_dist_type,
        navi_starttime,navi_endtime,navi_time,navi_distance,is_navi,navi_count,type_info,oil_consumption,oil_cost,total_cost,std_id,std_coords,conduct_order.toString,
        child_carrier_name,child_carrier_id,child_carrier_code,deputy_driver_account,deputy_driver_name
      )
    })
      .repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)
    logger.error("结果表5写入完成")
  }

  def getJoin1to5(spark: SparkSession, inc_day: String) = {

    import  spark.implicits._
    val inc_day_pre3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

    val joinSql =
      s"""
         |select
         |  *
         |from
         |  (
         |    select
         |      task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,line_code,vehicle_serial,actual_capacity_load,plan_depart_tm,
         |      actual_depart_tm,plan_arrive_tm,actual_arrive_tm,driver_id,driver_name,line_time,line_distance,actual_run_time,start_longitude,
         |      start_latitude,end_longitude,end_latitude,is_stop,transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,
         |      log_dist,task_inc_day,start_type,end_type,if_evaluate_time,carrier_name,stop_over_zone_code,biz_type,require_category,
         |      to_ground,start_time,last_update_tm,main_driver_account,road_fee,line_require_id,start_outer_add_code,end_outer_add_code,start_sortnum,end_sortnum,
         |      carrier_code,carrier_id,src_city_name,dest_city_name,sf_outer_vehicle_from,child_carrier_name,child_carrier_id,child_carrier_code,
         |      deputy_driver_account,deputy_driver_name,driver_score,task_area_code as task_area_code_new
         |    from
         |      dm_gis.eta_std_line_task
         |    where
         |      inc_day = '${inc_day}'
         |  ) a
         |  left outer join (
         |    select
         |      x1,y1,x2,y2,duration,time,rt_dist,highwaymileage,toll_charge,start_distance,end_distance,error_type,task_subid,rt_coords,halfway_integrate_rate,tl_time
         |    from
         |      dm_gis.eta_std_line_rectify
         |    where
         |      inc_day = '${inc_day}'
         |  ) b on a.task_subid = b.task_subid
         |  left outer join
         |    (
         |    select
         |        inc_day inc_day_t3,start_dept start_dept_t3,end_dept end_dept_t3,line_code line_code_t3,actual_capacity_load actual_capacity_load_t3,start_time
         |    from
         |        dm_gis.eta_std_line_route
         |    where
         |        inc_day >='${inc_day_pre3}'
         |    and
         |        inc_day <= '${inc_day}'
         |    ) c
         |on  a.task_inc_day = c.inc_day_t3
         |and a.start_dept = c.start_dept_t3
         |and a.end_dept = c.end_dept_t3
         |and a.line_code = c.line_code_t3
         |and a.actual_capacity_load = c.actual_capacity_load_t3
         |and a.start_time = c.start_time
         |left outer join
         |    (
         |    select
         |        task_subid,line_distance_std,line_time_std,src,
         |        std_id as std_id_tmp,pns_dist as pns_dist_tmp,pns_time as pns_time_tmp,
         |        std_coords as std_coords_tmp,std_x1 as std_x1_tmp,std_y1 as std_y1_tmp,
         |        std_x2 as std_x2_tmp,std_y2 as std_y2_tmp,sim1 as sim1_tmp,sim5 as sim5_tmp
         |    from
         |        dm_gis.eta_std_line_similarity
         |    where
         |        inc_day='${inc_day}'
         |    ) d
         |on a.task_subid = d.task_subid
         |left outer join
         |    (
         |    select
         |        diffdist_rt_line,diffratio_rt_line,diffdist_rt_std,diffratio_rt_std,diffdist_rt_log,diffratio_rt_log,
         |        diffdist_line_log,diffratio_line_log,diffdist_line_std,diffratio_line_std,diffdist_log_std,diffratio_log_std,
         |        difftime_line_std,diffratio1_line_std,difftime_line_std_10min,difftime_line_rt,diffratio1_line_rt,difftime_rt_gh_10min,is_run_ontime_std,is_run_ontime,
         |        if_dist_equal,if_time_equal,pns_error,task_subid,difftime_std_rt,diffratio1_std_rt,difftime_std_rt_10min,
         |        start_distance_std,end_distance_std,std_line_error,ac_difftime_line_rt,ac_diffratio1_line_rt,ac_difftime_rt_gh_10min,ac_difftime_std_rt,ac_diffratio1_std_rt,
         |        ac_difftime_std_rt_10min,ac_is_run_ontime_std,ac_is_run_ontime,navi_strategy,is_return_std_line,is_navi_at_start,is_navi_by_std_line,
         |        route_time,drive_time,is_yaw_by_driver,navi_complete_rate,accrual_dist,accrual_dist_type,is_navi,std_coords std_coords_t5,std_id std_id_t5,
         |        total_oil_consumption,oil_cost,total_cost,
         |		    std_id,conduct_type,conduct_order,pns_dist,pns_time,std_coords,std_x1,std_y1,std_x2,std_y2,sim1,sim5
         |    from
         |        dm_gis.eta_std_line_compute
         |    where
         |        inc_day ='${inc_day}'
         |    ) e
         |on a.task_subid = e.task_subid
         |
         """.stripMargin

    val joinDf = spark.sql(joinSql)
      .withColumn("std_id",when($"std_id".isNotNull && trim($"std_id")=!="",$"std_id_tmp").otherwise($"std_id_tmp"))
      .withColumn("pns_dist",when($"pns_dist".isNotNull && trim($"pns_dist")=!="",$"pns_dist").otherwise($"pns_dist_tmp"))
      .withColumn("pns_time",when($"pns_time".isNotNull && trim($"pns_time")=!="",$"pns_time").otherwise($"pns_time_tmp"))
      .withColumn("std_coords",when($"std_coords".isNotNull && trim($"std_coords")=!="",$"std_coords").otherwise($"std_coords_tmp"))
      .withColumn("std_x1",when($"std_x1".isNotNull && trim($"std_x1")=!="",$"std_x1").otherwise($"std_x1_tmp"))
      .withColumn("std_y1",when($"std_y1".isNotNull && trim($"std_y1")=!="",$"std_y1").otherwise($"std_y1_tmp"))
      .withColumn("std_x2",when($"std_x2".isNotNull && trim($"std_x2")=!="",$"std_x2").otherwise($"std_x2_tmp"))
      .withColumn("std_y2",when($"std_y2".isNotNull && trim($"std_y2")=!="",$"std_y2").otherwise($"std_y2_tmp"))
      .withColumn("sim1",when($"sim1".isNotNull && trim($"sim1")=!="",$"sim1").otherwise($"sim1_tmp"))
      .withColumn("sim5",when($"sim5".isNotNull && trim($"sim5")=!="",$"sim5").otherwise($"sim5_tmp"))

    //      val joinDf =spark.read.format("csv").option("header", "true").option("delimiter","\t").csv("d:\\user\\01401062\\桌面\\20220819.csv")

    val joinRdd = SparkUtils.getRowToJson(joinDf,"MEMORY_AND_DISK",400)

    val joinRddNew = joinRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    })
      .reduceByKey((obj1,obj2) => mergeLastUpdateConduct(obj1,obj2))
      .map(_._2)
    logger.error("结果表6输入数据量为：" + joinRddNew.count())

    joinRddNew

  }

  def parseTable6Coords(rt_coords: String) = {
    val joArray1 = new JSONArray()

    if (StringUtils.nonEmpty(rt_coords)) {
      val array1 = JSON.parseArray(rt_coords)
      for (i <- 0 until (array1.size())) {
        val json = array1.getJSONObject(i)
        val x = json.getDouble("dx")
        val y = json.getDouble("dy")
        val arrayNew = new JSONArray()
        arrayNew.add(x)
        arrayNew.add(y)
        joArray1.add(arrayNew)
      }
    }
    joArray1

  }

  def parseTable6Tm(rt_coords: String) = {
    val joArray1 = new JSONArray()

    if (StringUtils.nonEmpty(rt_coords)) {
      val array1 = JSON.parseArray(rt_coords)
      for (i <- 0 until (array1.size())) {
        val json = array1.getJSONObject(i)
        val tm = json.getString("tm")
        joArray1.add(tm)
      }
    }
    joArray1

  }

  def saveTable6(spark: SparkSession, inc_day: String, getJoin1to5Rdd: RDD[JSONObject]) = {

    import spark.implicits._
    val saveTableName = "dm_gis.eta_std_line_recall"
    //测试表dm_gis.eta_std_line_recall_aaa
    //    val saveTableName = "dm_gis.eta_std_line_recall_test"

    logger.error("正在写入结果表6")

    val res6Rdd = getJoin1to5Rdd.map(x => {

      val area_code = x.getString("area_code")
      val task_area_code= if (StringUtils.nonEmpty(area_code)) area_code else x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")
      val task_subid= x.getString("task_subid")
      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val start_type= x.getString("start_type")
      val end_type= x.getString("end_type")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val plan_depart_tm= x.getString("plan_depart_tm")
      val actual_depart_tm= x.getString("actual_depart_tm")
      val plan_arrive_tm= x.getString("plan_arrive_tm")
      val actual_arrive_tm= x.getString("actual_arrive_tm")
      val driver_id= x.getString("driver_id")
      val driver_name= x.getString("driver_name")
      val line_time= x.getString("line_time")
      val line_distance= x.getString("line_distance")
      val actual_run_time= x.getString("actual_run_time")
      val start_longitude= x.getString("start_longitude")
      val start_latitude= x.getString("start_latitude")
      val end_longitude= x.getString("end_longitude")
      val end_latitude= x.getString("end_latitude")
      val is_stop= x.getString("is_stop")
      val transoport_level= x.getString("transoport_level")
      val carrier_type= x.getString("carrier_type")
      val plf_flag= x.getString("plf_flag")
      val vehicle_type= x.getString("vehicle_type")
      val axls_number= x.getString("axls_number")
      val log_dist= x.getString("log_dist")
      val rt_coords= parseTable6Coords(x.getString("rt_coords"))
      val x1= x.getString("x1")
      val y1= x.getString("y1")
      val x2= x.getString("x2")
      val y2= x.getString("y2")
      val duration= x.getString("duration")
      val time= x.getString("time")
      val rt_dist= x.getString("rt_dist")
      val highwaymileage= x.getString("highwaymileage")
      val toll_charge= x.getString("toll_charge")
      val start_distance= x.getString("start_distance")
      val end_distance= x.getString("end_distance")
      val error_type= x.getString("error_type")

      val pns_dist= x.getString("pns_dist")
      val pns_dist_old= x.getString("pns_dist")

      val pns_time= x.getString("pns_time")
      val pns_time_old= x.getString("pns_time")

      val src= x.getString("src")
      val src_old= x.getString("src")

      val std_coords= if(StringUtils.nonEmpty(x.getString("std_coords_t5"))) x.getString("std_coords_t5") else  x.getString("std_coords")
      val std_coords_old=""

      val line_distance_std= x.getString("line_distance_std")
      val line_distance_std_old= x.getString("line_distance_std")

      val line_time_std= x.getString("line_time_std")
      val line_time_std_old= x.getString("line_time_std")

      val sim1= x.getString("sim1")
      val sim1_old= x.getString("sim1")

      val sim5= x.getString("sim5")
      val sim5_old= x.getString("sim5")

      val diffdist_rt_line= x.getString("diffdist_rt_line")
      val diffratio_rt_line= x.getString("diffratio_rt_line")
      val diffdist_rt_std= x.getString("diffdist_rt_std")
      val diffratio_rt_std= x.getString("diffratio_rt_std")
      val diffdist_rt_log= x.getString("diffdist_rt_log")
      val diffratio_rt_log= x.getString("diffratio_rt_log")
      val diffdist_line_log= x.getString("diffdist_line_log")
      val diffratio_line_log= x.getString("diffratio_line_log")
      val diffdist_line_std= x.getString("diffdist_line_std")
      val diffratio_line_std= x.getString("diffratio_line_std")
      val diffdist_log_std= x.getString("diffdist_log_std")
      val diffratio_log_std= x.getString("diffratio_log_std")

      val conduct_type= x.getString("conduct_type")
      val conduct_type_old= x.getString("conduct_type")

      val difftime_line_std= x.getString("difftime_line_std")
      val diffratio1_line_std= x.getString("diffratio1_line_std")
      val difftime_line_std_10min= x.getString("difftime_line_std_10min")
      val difftime_line_rt= x.getString("difftime_line_rt")
      val diffratio1_line_rt= x.getString("diffratio1_line_rt")
      val difftime_rt_gh_10min= x.getString("difftime_rt_gh_10min")
      val is_run_ontime_std= x.getString("is_run_ontime_std")
      val is_run_ontime= x.getString("is_run_ontime")
      val if_dist_equal= x.getString("if_dist_equal")
      val if_time_equal= x.getString("if_time_equal")
      val pns_error= x.getString("pns_error")
      val task_inc_day = x.getString("task_inc_day")
      //difftime_std_rt,diffratio1_std_rt,difftime_std_rt_10min
      val difftime_std_rt = x.getString("difftime_std_rt")
      val diffratio1_std_rt = x.getString("diffratio1_std_rt")
      val difftime_std_rt_10min = x.getString("difftime_std_rt_10min")

      //20211012增加字段
      val tl_time = x.getString("tl_time")
      val halfway_integrate_rate= x.getString("halfway_integrate_rate")

      val std_x1= x.getString("std_x1")
      val std_x1_old= x.getString("std_x1")

      val std_y1= x.getString("std_y1")
      val std_y1_old= x.getString("std_y1")

      val std_x2= x.getString("std_x2")
      val std_x2_old= x.getString("std_x2")

      val std_y2= x.getString("std_y2")
      val std_y2_old= x.getString("std_y2")

      val start_distance_std= x.getString("start_distance_std")
      val end_distance_std= x.getString("end_distance_std")
      val std_line_error= x.getString("std_line_error")
      val ac_difftime_line_rt= x.getString("ac_difftime_line_rt")
      val ac_diffratio1_line_rt= x.getString("ac_diffratio1_line_rt")
      val ac_difftime_rt_gh_10min= x.getString("ac_difftime_rt_gh_10min")
      val ac_difftime_std_rt= x.getString("ac_difftime_std_rt")
      val ac_diffratio1_std_rt= x.getString("ac_diffratio1_std_rt")
      val ac_difftime_std_rt_10min= x.getString("ac_difftime_std_rt_10min")
      val ac_is_run_ontime_std= x.getString("ac_is_run_ontime_std")
      val ac_is_run_ontime= x.getString("ac_is_run_ontime")
      val if_evaluate_time= x.getString("if_evaluate_time")

      //20211101增加字段carrier_name,stop_over_zone_code
      val motorcade_name = x.getString("motorcade_name")
      val carrier_name = if (StringUtils.nonEmpty(motorcade_name)) motorcade_name else x.getString("carrier_name")
      val stop_over_zone_code = x.getString("stop_over_zone_code")

      //20211118增加字段biz_type,require_category,to_ground
      val biz_type = x.getString("biz_type")
      val require_category = x.getString("require_category")
      val to_ground = x.getString("to_ground")

      val std_toll_charge = x.getString("std_toll_charge")

      val std_id= if(StringUtils.nonEmpty(x.getString("std_id_t5"))) x.getString("std_id_t5") else  x.getString("std_id")
      val std_id_old= if(StringUtils.nonEmpty(x.getString("std_id_t5"))) x.getString("std_id_t5") else  x.getString("std_id")

      //20220408新增字段
      val navi_strategy = x.getString("navi_strategy")
      val is_return_std_line = x.getString("is_return_std_line")
      val is_navi_at_start = x.getString("is_navi_at_start")
      val is_navi_by_std_line = x.getString("is_navi_by_std_line")
      val route_time = x.getString("route_time")
      val drive_time = x.getString("drive_time")
      val is_yaw_by_driver = x.getString("is_yaw_by_driver")
      val navi_complete_rate = x.getString("navi_complete_rate")
      val accrual_dist = x.getString("accrual_dist")
      val accrual_dist_type = x.getString("accrual_dist_type")

      //20220421
      val last_update_tm = x.getString("last_update_tm")

      //20220608
      val main_driver_account = x.getString("main_driver_account")

      //20220707
      val road_fee = x.getString("road_fee")

      //20220816
      val line_require_id = x.getString("line_require_id")

      //20220823
      val start_outer_add_code = x.getString("start_outer_add_code")
      val end_outer_add_code = x.getString("end_outer_add_code")
      val start_sortnum = x.getString("start_sortnum")
      val end_sortnum = x.getString("end_sortnum")

      //20220921
      val is_navi = x.getString("is_navi")
      val is_navi_old = x.getString("is_navi")

      //20230517
      val carrier_id = x.getString("carrier_id")
      val carrier_code = x.getString("carrier_code")

      //20230526
      val total_oil_consumption = x.getString("total_oil_consumption")
      val oil_cost = x.getString("oil_cost")
      val total_cost = x.getString("total_cost")

      //20230605
      val conduct_order = x.getString("conduct_order")
      val conduct_order_old = x.getString("conduct_order")

      //20230613
      val src_city_name = x.getString("src_city_name")
      val dest_city_name = x.getString("dest_city_name")
      val sf_outer_vehicle_from = x.getString("sf_outer_vehicle_from")

      //20230620
      val child_carrier_name = x.getString("child_carrier_name")
      val child_carrier_id = x.getString("child_carrier_id")
      val child_carrier_code = x.getString("child_carrier_code")
      val deputy_driver_account = x.getString("deputy_driver_account")
      val deputy_driver_name = x.getString("deputy_driver_name")

      //20231031
      val rt_tm= parseTable6Tm(x.getString("rt_coords"))
      val driver_score= x.getString("driver_score")

      //20231127
      val task_area_code_new= x.getString("task_area_code_new")

      res_table6(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,start_type,end_type,line_code,
        vehicle_serial,actual_capacity_load,plan_depart_tm,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,
        driver_id,driver_name,line_time,line_distance,actual_run_time,start_longitude,start_latitude,end_longitude,
        end_latitude,is_stop,transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,log_dist,rt_coords.toJSONString,
        x1,y1,x2,y2,duration,time,rt_dist,highwaymileage,toll_charge,start_distance,end_distance,error_type,pns_dist,
        pns_time,src,std_coords,line_distance_std,line_time_std,sim1,sim5,diffdist_rt_line,diffratio_rt_line,
        diffdist_rt_std,diffratio_rt_std,diffdist_rt_log,diffratio_rt_log,diffdist_line_log,diffratio_line_log,
        diffdist_line_std,diffratio_line_std,diffdist_log_std,diffratio_log_std,conduct_type,difftime_line_std,
        diffratio1_line_std,difftime_line_std_10min,difftime_line_rt,diffratio1_line_rt,difftime_rt_gh_10min,is_run_ontime_std,
        is_run_ontime,if_dist_equal,if_time_equal,pns_error,task_inc_day,difftime_std_rt,diffratio1_std_rt,difftime_std_rt_10min,
        tl_time,halfway_integrate_rate,std_x1,std_y1,std_x2,std_y2,start_distance_std,end_distance_std,std_line_error,ac_difftime_line_rt,
        ac_diffratio1_line_rt,ac_difftime_rt_gh_10min,ac_difftime_std_rt,ac_diffratio1_std_rt,ac_difftime_std_rt_10min,ac_is_run_ontime_std,
        ac_is_run_ontime,if_evaluate_time,carrier_name,stop_over_zone_code,biz_type,require_category,to_ground,std_toll_charge,std_id,
        navi_strategy,is_return_std_line,is_navi_at_start,is_navi_by_std_line,route_time,drive_time,is_yaw_by_driver,
        navi_complete_rate,accrual_dist,accrual_dist_type,last_update_tm,main_driver_account,road_fee,line_require_id,
        start_outer_add_code,end_outer_add_code,start_sortnum,end_sortnum,is_navi,carrier_id,carrier_code,total_oil_consumption,oil_cost,total_cost,conduct_order,
        src_city_name,dest_city_name,sf_outer_vehicle_from,child_carrier_name,child_carrier_id,child_carrier_code,deputy_driver_account,deputy_driver_name,
        conduct_type_old,std_id_old,sim1_old,sim5_old,conduct_order_old,pns_dist_old,
        pns_time_old,src_old,std_coords_old,line_distance_std_old,line_time_std_old,
        std_x1_old ,std_y1_old,std_x2_old,std_y2_old,is_navi_old,rt_tm.toJSONString,driver_score,task_area_code_new
      )
    }).repartition(100).toDF()
    //}).repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    //获取实时计算的数据,计算最近3天的实时数据
    val day3=getdaysBeforeOrAfter(inc_day,-2)
    val day1=getdaysBeforeOrAfter(inc_day,1)
    logger.error("变量day3："+day3)
    logger.error("变量day1："+day1)
    val realtime_data=spark.sql(
      s"""
         |select task_subid,inc_day,conduct_type as conduct_type_overstop,
         |std_id as std_id_overstop,sim1 as sim1_overstop,sim5 as sim5_overstop,
         | conduct_order as conduct_order_overstop, is_navi as is_navi_overstop
         | from dm_gis.eta_std_line_recall_realtime2_overstop
         |where inc_day>='$day3' and inc_day<='$day1'
         |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("task_subid").orderBy(desc("inc_day"))))
      .filter($"rank"==="1")
      .withColumn("real_flag",lit("1"))
      .select("task_subid","real_flag","conduct_type_overstop","std_id_overstop","sim1_overstop","sim5_overstop","conduct_order_overstop","is_navi_overstop")

    val res6Rdd2 =res6Rdd.join(realtime_data,Seq("task_subid"),"left")
      .withColumn("conduct_type_src",when($"carrier_type"==="0" ,"recall").
        when($"real_flag"==="1","realtime").
        otherwise("recall"))
      //一部分字段是取自实时计算的数据
      .withColumn("conduct_type",when($"conduct_type_src"==="realtime",$"conduct_type_overstop").otherwise($"conduct_type"))
      .withColumn("std_id",when($"conduct_type_src"==="realtime",$"std_id_overstop").otherwise($"std_id"))
      .withColumn("sim1",when($"conduct_type_src"==="realtime",$"sim1_overstop").otherwise($"sim1"))
      .withColumn("sim5",when($"conduct_type_src"==="realtime",$"sim5_overstop").otherwise($"sim5"))
      .withColumn("conduct_order",when($"conduct_type_src"==="realtime",$"conduct_order_overstop").otherwise($"conduct_order"))
      .withColumn("is_navi",when($"conduct_type_src"==="realtime",$"is_navi_overstop").otherwise($"is_navi"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("调取getline接口计算实时的部分指标")
    //选取实时计算的这部分获取getline接口
    val res6Rdd3=res6Rdd2.filter($"conduct_type_src"==="realtime")
      .select("task_subid","std_id")

    //转换rdd，并发调取接口
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3
    //转化rdd
    import com.sf.gis.scala.base.spark.SparkUtils
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, res6Rdd3, calPartitions)
    //并发获取数据结果
    val mult_result=Multi_getline_url(spark,sql_Rdd,calPartitions)
    //字段解析
    val mult_result_df=mult_result.map(obj=>{
      val ret=obj.getString("ret")
      val task_subid=obj.getString("task_subid")
      var pns_dist_getline=""
      var pns_time_getline=""
      var src_getline=""
      var std_coords_getline=""
      var line_distance_std_getline=""
      var line_time_std_getline=""
      var std_x1_getline=""
      var std_y1_getline=""
      var std_x2_getline=""
      var std_y2_getline=""

      if(ret !=null && ret.trim !=""){
        try{
          val ret_result=JSON.parseObject(ret).getJSONObject("result")
          var ret_status="1"
          try{
            ret_status=JSON.parseObject(ret).getString("status")
          }
          catch{
            case e: Exception => logger.error(e)
          }

          if(ret_status=="0" || ret_status==0){
            val ret_list=ret_result.getJSONArray("list")
            if(ret_list !=null &&  ret_list.size>0){
              //经过与张翠霞沟通，原则上只有一条数据，这里默认只取第一条
              pns_dist_getline=ret_list.getJSONObject(0).getString("rtDistance")
              pns_time_getline=ret_list.getJSONObject(0).getString("rtTime")
              src_getline=ret_list.getJSONObject(0).getString("isEcon")
              std_coords_getline=ret_list.getJSONObject(0).getString("jyTrack2")
              line_distance_std_getline=ret_list.getJSONObject(0).getString("lineDistance")
              line_time_std_getline=ret_list.getJSONObject(0).getString("lineTime")
              std_x1_getline=ret_list.getJSONObject(0).getString("trackStartX")
              std_y1_getline=ret_list.getJSONObject(0).getString("trackStartY")
              std_x2_getline=ret_list.getJSONObject(0).getString("trackEndX")
              std_y2_getline=ret_list.getJSONObject(0).getString("trackEndY")
            }
          }
        }
        catch{
          case e: Exception => logger.error(e)
        }
      }


      (task_subid,pns_dist_getline,pns_time_getline,src_getline,std_coords_getline,line_distance_std_getline,line_time_std_getline,
        std_x1_getline,std_y1_getline,std_x2_getline,std_y2_getline,ret)
    }).toDF("task_subid","pns_dist_getline","pns_time_getline","src_getline","std_coords_getline","line_distance_std_getline",
      "line_time_std_getline","std_x1_getline","std_y1_getline","std_x2_getline","std_y2_getline","ret")


    // spark.sql("drop table if exists tmp_dm_gis.mult_result_df")
    //mult_result_df.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.mult_result_df")

    val res6_final =res6Rdd2.join(mult_result_df,Seq("task_subid"),"left")
      .withColumn("pns_dist",when($"conduct_type_src"==="realtime",$"pns_dist_getline").otherwise($"pns_dist"))
      .withColumn("pns_time",when($"conduct_type_src"==="realtime",$"pns_time_getline").otherwise($"pns_time"))
      .withColumn("src",when($"conduct_type_src"==="realtime",$"src_getline").otherwise($"src"))
      .withColumn("std_coords",when($"conduct_type_src"==="realtime",$"std_coords_getline").otherwise($"std_coords"))
      .withColumn("line_distance_std",when($"conduct_type_src"==="realtime",$"line_distance_std_getline").otherwise($"line_distance_std"))
      .withColumn("line_time_std",when($"conduct_type_src"==="realtime",$"line_time_std_getline").otherwise($"line_time_std"))
      .withColumn("std_x1",when($"conduct_type_src"==="realtime",$"std_x1_getline").otherwise($"std_x1"))
      .withColumn("std_y1",when($"conduct_type_src"==="realtime",$"std_y1_getline").otherwise($"std_y1"))
      .withColumn("std_x2",when($"conduct_type_src"==="realtime",$"std_x2_getline").otherwise($"std_x2"))
      .withColumn("std_y2",when($"conduct_type_src"==="realtime",$"std_y2_getline").otherwise($"std_y2"))
      .withColumn("inc_day",lit(inc_day))

    val table_cols = spark.sql(s"""select * from $saveTableName limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, res6_final.select(table_cols: _*), Seq("inc_day"), saveTableName)
    logger.error("结果表6写入完成")
  }

  def getSourceRecall(spark: SparkSession, inc_day: String) = {

    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day='${inc_day}'
       """.stripMargin

    val sourceDf = spark.sql(querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf,400)

    sourceRdd

  }

  def calRecallRateStat(recallSourceRdd: RDD[JSONObject], inc_day: String) = {

    val recallRdd = recallSourceRdd.map(x => {
      val task_id = x.getString("task_id")
      (task_id,x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(obj => {

        val task_id = obj._1
        val list = obj._2

        val minSortNum = list.minBy(x => {JSONUtils.getJsonValueDouble(x,"sort_num",0.0)})
        val maxSortNum = list.maxBy(x => {JSONUtils.getJsonValueDouble(x,"sort_num",0.0)})

        var line_time,line_distance,actual_run_time,duration,time,rt_dist,highwaymileage,toll_charge,pns_dist,pns_time,std_toll_charge,accrual_dist = 0.0
        val srcSet = new mutable.HashSet[Int]()
        val typeSet = new mutable.HashSet[Int]()

        var err_flag = 0
        var conduct_type_flag = 0

        var line_distance_core = 0.0

        var is_navi_flag = 0
        var is_navi_core = 0.0

        list.map(x => {
          line_time += JSONUtils.getJsonValueDouble(x,"line_time",0)
          line_distance += JSONUtils.getJsonValueDouble(x,"line_distance",0.0)
          actual_run_time += JSONUtils.getJsonValueInt(x,"actual_run_time",0)
          duration += JSONUtils.getJsonValueDouble(x,"duration",0.0)
          time += JSONUtils.getJsonValueDouble(x,"time",0)
          rt_dist += JSONUtils.getJsonValueDouble(x,"rt_dist",0.0)
          highwaymileage += JSONUtils.getJsonValueDouble(x,"highwaymileage",0.0)
          toll_charge += JSONUtils.getJsonValueDouble(x,"toll_charge",0.0)
          pns_dist += JSONUtils.getJsonValueDouble(x,"pns_dist",0)
          pns_time += JSONUtils.getJsonValueDouble(x,"pns_time",0)
          std_toll_charge += JSONUtils.getJsonValueDouble(x,"std_toll_charge",0.0)

          // TODO: 按task_id分组，分组下所有数据的error_type=0时赋值0，否则为1
          val err_type = JSONUtils.getJsonValueInt(x,"error_type",1)
          if (err_type != 0) err_flag = 1
          val src = JSONUtils.getJsonValueInt(x,"src",0)
          // TODO: 按task_id分组，取分组下所有数据的src用|分隔组合在一个字段，格式：2|3
          srcSet.add(src)
          // TODO: 按task_id分组，分组下所有数据的conduct_type=1时赋值1，否则为3
          // TODO:

          val conduct_type = JSONUtils.getJsonValueInt(x,"conduct_type",1)
          val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"actual_run_time",0)

          // TODO: 增加accrual_dist统计
          accrual_dist += JSONUtils.getJsonValueDouble(x,"accrual_dist",0.0)
          // TODO: 增加按task_id分组，取分组下所有数据的accrual_dist_type用|分隔组合在一个字段，格式：2|3
          val accrual_dist_type = JSONUtils.getJsonValueInt(x,"accrual_dist_type",0)
          typeSet.add(accrual_dist_type)
        })

        // 增加分段权重占比
        list.map(x => {
          val part_line_distance = JSONUtils.getJsonValueDouble(x,"line_distance",0.0)
          val conduct_type = JSONUtils.getJsonValueInt(x,"conduct_type",1)
          val is_navi = JSONUtils.getJsonValueInt(x,"is_navi",0)

          val core = if (conduct_type == 1) 1 else 0
          val part_core =  (part_line_distance / line_distance) * core
          line_distance_core += part_core

          val navi_core = if (is_navi == 1) 1 else 0
          val part_core_navi =  (part_line_distance / line_distance) * core
          is_navi_core += part_core_navi

        })
        // 判断总得分是否大于0.85
        if (line_distance_core >= 0.85) conduct_type_flag = 1 else conduct_type_flag = 3
        if (is_navi_core >= 0.85) is_navi_flag = 1 else is_navi_flag = 3

        val end_dept = maxSortNum.getString("end_dept")
        val end_type = maxSortNum.getString("end_type")
        val plan_arrive_tm = maxSortNum.getString("plan_arrive_tm")
        val actual_arrive_tm = maxSortNum.getString("actual_arrive_tm")

        val carrier_id = maxSortNum.getString("carrier_id")
        val carrier_code = maxSortNum.getString("carrier_code")


        val src_city_name = maxSortNum.getString("src_city_name")
        val dest_city_name = maxSortNum.getString("dest_city_name")
        val sf_outer_vehicle_from = maxSortNum.getString("sf_outer_vehicle_from")


        val total_oil_consumption = maxSortNum.getString("total_oil_consumption")
        val oil_cost = maxSortNum.getString("oil_cost")
        val total_cost = maxSortNum.getString("total_cost")


        minSortNum.put("line_time",line_time)
        minSortNum.put("line_distance",line_distance)
        minSortNum.put("actual_run_time",actual_run_time.toInt)
        minSortNum.put("duration",duration)
        minSortNum.put("time",time.toInt)
        minSortNum.put("rt_dist",rt_dist)
        minSortNum.put("highwaymileage",highwaymileage)
        minSortNum.put("toll_charge",toll_charge)
        minSortNum.put("pns_dist",pns_dist.toInt)
        minSortNum.put("pns_time",pns_time.toInt)
        minSortNum.put("std_toll_charge",std_toll_charge)
        minSortNum.put("if_error",err_flag)
        minSortNum.put("src",srcSet.mkString("|"))
        minSortNum.put("conduct_type",conduct_type_flag)
        //20220408新增
        minSortNum.put("accrual_dist",accrual_dist)
        minSortNum.put("accrual_dist_type",typeSet.mkString("|"))

        //按task_id分组取sort_num最大那条
        minSortNum.put("end_dept",end_dept)
        minSortNum.put("end_type",end_type)
        minSortNum.put("plan_arrive_tm",plan_arrive_tm)
        minSortNum.put("actual_arrive_tm",actual_arrive_tm)

        //20220919新增
        minSortNum.put("is_navi",is_navi_flag)

        //20230517新增
        minSortNum.put("carrier_id",carrier_id)
        minSortNum.put("carrier_code",carrier_code)

        //20230613新增
        minSortNum.put("src_city_name",src_city_name)
        minSortNum.put("dest_city_name",dest_city_name)
        minSortNum.put("sf_outer_vehicle_from",sf_outer_vehicle_from)


        val log_dist = JSONUtils.getJsonValueInt(minSortNum,"log_dist",0)

        val ac_is_run_ontime = if ( actual_run_time - 1 <= line_time) 1 else 0
        val diffdist_log_rt = if ( log_dist != 0 ) log_dist * 1000 - rt_dist else 0
        val diffratio_log_rt = if ( rt_dist != 0 ) diffdist_log_rt / rt_dist else 0

        //20220421
        val last_update_tm = JSONUtils.getJsonValue(maxSortNum,"last_update_tm","")


        minSortNum.put("ac_is_run_ontime",ac_is_run_ontime)
        minSortNum.put("diffdist_log_rt",diffdist_log_rt.formatted("%.2f"))
        minSortNum.put("diffratio_log_rt",diffratio_log_rt.formatted("%.2f"))

        minSortNum.put("last_update_tm",last_update_tm)


        minSortNum.put("total_oil_consumption",total_oil_consumption)
        minSortNum.put("oil_cost",oil_cost)
        minSortNum.put("total_cost",total_cost)

        minSortNum

      }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("recallRdd的数据量为：" + recallRdd.count())
    recallRdd.take(2).foreach(println(_))

    recallRdd

  }

  def saveTableRecall2(spark: SparkSession, inc_day: String, recallRdd: RDD[JSONObject], logger: Logger) = {

    import spark.implicits._
    val saveTableName = "dm_gis.eta_std_line_recall1"
    //测试表dm_gis.eta_std_line_recall1_aaa
    logger.error("正在写入结果表7")

    val res6Rdd = recallRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val carrier_name= x.getString("carrier_name")
      val task_inc_day= x.getString("task_inc_day")
      val start_dept= x.getString("start_dept")
      val start_type= x.getString("start_type")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val plan_depart_tm= x.getString("plan_depart_tm")
      val actual_depart_tm= x.getString("actual_depart_tm")
      val driver_id= x.getString("driver_id")
      val driver_name= x.getString("driver_name")
      val is_stop= x.getString("is_stop")
      val transoport_level= x.getString("transoport_level")
      val carrier_type= x.getString("carrier_type")
      val plf_flag= x.getString("plf_flag")
      val vehicle_type= x.getString("vehicle_type")
      val axls_number= x.getString("axls_number")
      val log_dist= x.getString("log_dist")
      val if_evaluate_time= x.getString("if_evaluate_time")
      val stop_over_zone_code= x.getString("stop_over_zone_code")
      val end_dept= x.getString("end_dept")
      val end_type= x.getString("end_type")
      val plan_arrive_tm= x.getString("plan_arrive_tm")
      val actual_arrive_tm= x.getString("actual_arrive_tm")
      val line_time= x.getString("line_time")
      val line_distance= x.getString("line_distance")
      val actual_run_time= x.getString("actual_run_time")
      val duration= x.getString("duration")
      val time= x.getString("time")
      val rt_dist= x.getString("rt_dist")
      val highwaymileage= x.getString("highwaymileage")
      val toll_charge= x.getString("toll_charge")
      val pns_dist= x.getString("pns_dist")
      val pns_time= x.getString("pns_time")
      val std_toll_charge= x.getString("std_toll_charge")
      val if_error= x.getString("if_error")
      val src= x.getString("src")
      val conduct_type= x.getString("conduct_type")
      val ac_is_run_ontime= x.getString("ac_is_run_ontime")
      val diffdist_log_rt= x.getString("diffdist_log_rt")
      val diffratio_log_rt= x.getString("diffratio_log_rt")

      val accrual_dist = x.getString("accrual_dist")
      val accrual_dist_type= x.getString("accrual_dist_type")
      val last_update_tm= x.getString("last_update_tm")

      //20220608
      val main_driver_account = x.getString("main_driver_account")

      //20220707
      val road_fee = x.getString("road_fee")

      //20220816
      val line_require_id = x.getString("line_require_id")
      //2020920
      val is_navi = x.getString("is_navi")

      //20230517
      val carrier_id = x.getString("carrier_id")
      val carrier_code = x.getString("carrier_code")

      //20230526
      val total_oil_consumption = x.getString("total_oil_consumption")
      val oil_cost = x.getString("oil_cost")
      val total_cost = x.getString("total_cost")

      //20230613
      val src_city_name = x.getString("src_city_name")
      val dest_city_name = x.getString("dest_city_name")
      val sf_outer_vehicle_from = x.getString("sf_outer_vehicle_from")


      //20230620
      val child_carrier_name = x.getString("child_carrier_name")
      val child_carrier_id = x.getString("child_carrier_id")
      val child_carrier_code = x.getString("child_carrier_code")
      val deputy_driver_account = x.getString("deputy_driver_account")
      val deputy_driver_name = x.getString("deputy_driver_name")

      //20231127
      val task_area_code_new = x.getString("task_area_code_new")
      res_table7(
        task_area_code,task_id,carrier_name,task_inc_day,start_dept,start_type,line_code,vehicle_serial,actual_capacity_load,
        plan_depart_tm,actual_depart_tm,driver_id,driver_name,is_stop,transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,log_dist,
        if_evaluate_time,stop_over_zone_code,end_dept,end_type,plan_arrive_tm,actual_arrive_tm,line_time,line_distance,actual_run_time,
        duration,time,rt_dist,highwaymileage,toll_charge,pns_dist,pns_time,std_toll_charge,if_error,src,conduct_type,
        ac_is_run_ontime,diffdist_log_rt,diffratio_log_rt,accrual_dist,accrual_dist_type,last_update_tm,main_driver_account,road_fee,line_require_id,is_navi,
        carrier_id,carrier_code,total_oil_consumption,oil_cost,total_cost,src_city_name,dest_city_name,sf_outer_vehicle_from,
        child_carrier_name,child_carrier_id,child_carrier_code,deputy_driver_account,deputy_driver_name,task_area_code_new
      )

    }).repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表7写入完成")


  }


  def getKafkaData(spark: SparkSession, inc_day: String) = {

    val getSourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.omcs_ground_task_calc_hive
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val soucreDf = spark.sql(getSourceSql)
    val sourceRdd = SparkUtils.getRowToJson(soucreDf)

    logger.error("共获取kafka数据:" + sourceRdd.count())
    sourceRdd.take(2).foreach(println(_))

    sourceRdd

  }

  def getParseKafkaLog(groundKafkaSourceRdd: RDD[JSONObject], inc_day: String) = {

    val parseRdd = groundKafkaSourceRdd.flatMap(x => {

      val log = x.getString("log")
      val json = JSON.parseObject(log)
      val groundTaskPassZoneDtosList = json.getJSONArray("groundTaskPassZoneDtos")
      val task_id = json.getString("taskId")
      val task_area_code = json.getString("taskAreaCode")
      val line_code = json.getString("lineCode")
      val require_category = json.getString("requireCategory")
      val stop_over_zone_code = json.getString("stopOverZoneCode")
      val vehicle_serial = json.getString("vehicleSerial")
      val driver_id = json.getString("driverId")
      val driver_name = json.getString("driverName")
      val actual_capacity_load = json.getString("actualCapacityLoad")
      val capacity_load = json.getString("capacityLoad")
      val transoport_level = json.getString("transoportLevel")
      val to_ground = json.getString("toGround")
      val biz_type = json.getString("bizType")
      val carrier_name = json.getString("carrierName")
      val is_stop = json.getString("isStop")
      val carrier_type = json.getString("carrierType")
      val state = json.getString("state")
      val last_update_tm = json.getString("lastUpdateTm")

      val full_load_weight = json.getString("fullLoadWeight")
      val contnr_code = json.getString("contnrCode")


      val buffer = new ArrayBuffer[JSONObject]()

      for (i <- (0 until(groundTaskPassZoneDtosList.size() -1))){
        val jo = new JSONObject()
        val curJson = groundTaskPassZoneDtosList.getJSONObject(i)
        val nextJson = groundTaskPassZoneDtosList.getJSONObject(i + 1)

        val sort_num = i
        val start_dept = curJson.getString("passZoneCode")
        val start_dept_site_id = curJson.getString("deptSiteId")
        val end_dept = nextJson.getString("passZoneCode")
        val end_dept_site_id = nextJson.getString("deptSiteId")
        val start_type = if (StringUtils.nonEmpty(start_dept) && StringUtils.nonEmpty(start_dept) && start_dept.equals(start_dept_site_id)) 2 else 1
        val end_type = if (StringUtils.nonEmpty(end_dept) && StringUtils.nonEmpty(end_dept_site_id) && end_dept.equals(end_dept_site_id)) 2 else 1
        val plan_depart_tm = DateTimeUtil.timestampConvertDate2(curJson.getLongValue("planDepartTm"),"yyyy-MM-dd HH:mm:ss")
        val actual_depart_tm = DateTimeUtil.timestampConvertDate2(curJson.getLongValue("actualDepartTm"),"yyyy-MM-dd HH:mm:ss")
        val plan_arrive_tm = DateTimeUtil.timestampConvertDate2(nextJson.getLongValue("planArriveTm"),"yyyy-MM-dd HH:mm:ss")
        val actual_arrive_tm = DateTimeUtil.timestampConvertDate2(nextJson.getLongValue("actualArriveTm"),"yyyy-MM-dd HH:mm:ss")
        val line_time = curJson.getLongValue("planRunTime")
        val line_distance = curJson.getLongValue("lineDistance")
        val actual_run_time = curJson.getString("actualRunTime")
        val start_longitude = try {curJson.getString("passZoneCoordinate").split(",")(0) } catch {case e:Exception => ""}
        val start_latitude = try {curJson.getString("passZoneCoordinate").split(",")(1) } catch {case e:Exception => ""}
        val end_longitude = try {nextJson.getString("passZoneCoordinate").split(",")(0) } catch {case e:Exception => ""}
        val end_latitude = try {nextJson.getString("passZoneCoordinate").split(",")(1) } catch {case e:Exception => ""}

        val votes_cur = try {curJson.getJSONObject("votes")} catch {case e:Exception => new JSONObject()}
        val votes_l =  try { votes_cur.getString("l")} catch {case e:Exception => ""}
        val votes_lw = try { votes_cur.getString("lw")} catch {case e:Exception => ""}

        val votes_next = try {nextJson.getJSONObject("votes")} catch {case e:Exception => new JSONObject()}
        val votes_s = try { votes_next.getString("s")} catch {case e:Exception => ""}
        val votes_n = try { votes_next.getString("n")} catch {case e:Exception => ""}
        val votes_d = try { votes_next.getString("d")} catch {case e:Exception => ""}
        val votes_w = try { votes_next.getString("w")} catch {case e:Exception => ""}
        val votes_sp = try { votes_next.getString("sp")} catch {case e:Exception => ""}
        val votes_dp = try { votes_next.getString("dp")} catch {case e:Exception => ""}
        val votes_pw = try { votes_next.getString("pw")} catch {case e:Exception => ""}

        jo.put("task_id",task_id)
        jo.put("sort_num",sort_num)
        jo.put("task_area_code",task_area_code)
        jo.put("line_code",line_code)
        jo.put("start_dept",start_dept)
        jo.put("start_dept_site_id",start_dept_site_id)
        jo.put("end_dept",end_dept)
        jo.put("end_dept_site_id",end_dept_site_id)
        jo.put("start_type",start_type)
        jo.put("end_type",end_type)
        jo.put("plan_depart_tm",plan_depart_tm)
        jo.put("actual_depart_tm",actual_depart_tm)
        jo.put("plan_arrive_tm",plan_arrive_tm)
        jo.put("actual_arrive_tm",actual_arrive_tm)
        jo.put("line_time",line_time)
        jo.put("line_distance",line_distance)
        jo.put("actual_run_time",actual_run_time)
        jo.put("start_longitude",start_longitude)
        jo.put("start_latitude",start_latitude)
        jo.put("end_longitude",end_longitude)
        jo.put("end_latitude",end_latitude)
        jo.put("require_category",require_category)
        jo.put("stop_over_zone_code",stop_over_zone_code)
        jo.put("vehicle_serial",vehicle_serial)
        jo.put("driver_id",driver_id)
        jo.put("driver_name",driver_name)
        jo.put("actual_capacity_load",actual_capacity_load)
        jo.put("capacity_load",capacity_load)
        jo.put("transoport_level",transoport_level)
        jo.put("to_ground",to_ground)
        jo.put("biz_type",biz_type)
        jo.put("carrier_name",to_ground)
        jo.put("is_stop",is_stop)
        jo.put("carrier_type",carrier_type)
        jo.put("state",state)
        jo.put("last_update_tm",last_update_tm)

        jo.put("full_load_weight",full_load_weight)
        jo.put("votes_l",votes_l)
        jo.put("votes_lw",votes_lw)
        jo.put("votes_s",votes_s)
        jo.put("votes_n",votes_n)
        jo.put("votes_d",votes_d)
        jo.put("votes_w",votes_w)
        jo.put("votes_sp",votes_sp)
        jo.put("votes_dp",votes_dp)
        jo.put("votes_pw",votes_pw)
        jo.put("contnr_code",contnr_code)
        buffer.append(jo)
      }

      buffer
    })
      .map(x => {
        val task_id = x.getString("task_id")
        val sort_num = x.getString("sort_num")
        ((task_id,sort_num),x)
      })
      .reduceByKey((obj1,obj2) => mergeLastUpdate(obj1,obj2))
      .map(_._2)
      // 不写入start_dept或end_dept为null的数据
      .filter(x => {
        val start_dept = x.getString("start_dept")
        val end_dept = x.getString("end_dept")
        StringUtils.nonEmpty(start_dept) && StringUtils.nonEmpty(end_dept)
      })
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("parseRdd的数据量为:" + parseRdd.count())
    //    parseRdd.take(2).foreach(println(_))

    parseRdd

  }

  /**
   * 根据task_id和sort_num去重，保留last_update_tm最大的一条
   * @param obj1
   * @param obj2
   * @return
   */

  def mergeLastUpdate(obj1: JSONObject, obj2: JSONObject):JSONObject = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val last_update_tm_1 = JSONUtils.getJsonValue(obj1,"last_update_tm","0")
    val last_update_tm_2 = JSONUtils.getJsonValue(obj2,"last_update_tm","0")

    //取last_update_tm最大的
    if(last_update_tm_1 < last_update_tm_2){
      return obj2
    }else{
      return obj1
    }
  }


  /**
   * 根据task_id和sort_num去重，保留last_update_tm最大的一条
   * @param obj1
   * @param obj2
   * @return
   */

  def mergeLastUpdateConduct(obj1: JSONObject, obj2: JSONObject):JSONObject = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val conduct_type_1 = JSONUtils.getJsonValue(obj1,"conduct_type","0")
    val conduct_type_2 = JSONUtils.getJsonValue(obj2,"conduct_type","0")

    //取conduct_type_2最小的
    if(conduct_type_1 > conduct_type_2){
      return obj2
    }else{
      return obj1
    }
  }

  //写入结果表8
  def saveTable8(spark: SparkSession, inc_day: String, parseKafkaLogRdd: RDD[JSONObject], logger: Logger) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_task_parse"
    // eta_std_line_task_parse_aaa为测试数据

    logger.error("正在写入结果表8")
    val res = parseKafkaLogRdd.map(x => {

      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")
      val task_area_code= x.getString("task_area_code")
      val line_code= x.getString("line_code")
      val start_dept= x.getString("start_dept")
      val start_dept_site_id= x.getString("start_dept_site_id")
      val end_dept= x.getString("end_dept")
      val end_dept_site_id= x.getString("end_dept_site_id")
      val start_type= x.getString("start_type")
      val end_type= x.getString("end_type")
      val plan_depart_tm= x.getString("plan_depart_tm")
      val actual_depart_tm= x.getString("actual_depart_tm")
      val plan_arrive_tm= x.getString("plan_arrive_tm")
      val actual_arrive_tm= x.getString("actual_arrive_tm")
      val line_time= x.getString("line_time")
      val line_distance= x.getString("line_distance")
      val actual_run_time= x.getString("actual_run_time")
      val start_longitude= x.getString("start_longitude")
      val start_latitude= x.getString("start_latitude")
      val end_longitude= x.getString("end_longitude")
      val end_latitude= x.getString("end_latitude")
      val require_category= x.getString("require_category")
      val stop_over_zone_code= x.getString("stop_over_zone_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val driver_id= x.getString("driver_id")
      val driver_name= x.getString("driver_name")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val capacity_load= x.getString("capacity_load")
      val transoport_level= x.getString("transoport_level")
      val to_ground= x.getString("to_ground")
      val biz_type= x.getString("biz_type")
      val carrier_name= x.getString("carrier_name")
      val is_stop= x.getString("is_stop")
      val carrier_type= x.getString("carrier_type")
      val plf_flag= ""
      val state= x.getString("state")
      val last_update_tm = x.getString("last_update_tm")
      val full_load_weight = x.getString("full_load_weight")
      val votes_l = x.getString("votes_l")
      val votes_lw = x.getString("votes_lw")
      val votes_s = x.getString("votes_s")
      val votes_n = x.getString("votes_n")
      val votes_d = x.getString("votes_d")
      val votes_w = x.getString("votes_w")
      val votes_sp = x.getString("votes_sp")
      val votes_dp = x.getString("votes_dp")
      val votes_pw = x.getString("votes_pw")
      val contnr_code = x.getString("contnr_code")

      res_table8(task_id,sort_num,task_area_code,line_code,start_dept,start_dept_site_id,end_dept,end_dept_site_id,start_type,
        end_type,plan_depart_tm,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,line_time,line_distance,actual_run_time,
        start_longitude,start_latitude,end_longitude,end_latitude,require_category,stop_over_zone_code,vehicle_serial,
        driver_id,driver_name,actual_capacity_load,capacity_load,transoport_level,to_ground,biz_type,carrier_name,is_stop,
        carrier_type,plf_flag,state,last_update_tm,full_load_weight,votes_l,votes_lw,votes_s,votes_n,votes_d,votes_w,votes_sp,votes_dp,votes_pw,contnr_code)
    })
      //val frame = spark.createDataFrame(res)
      .toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表8写入完成")

  }


  def calRetryRddStd(retryRdd: RDD[JSONObject]) = {

    val retryRdd2 = retryRdd.map(x => {

      val start_type = JSONUtils.getJsonValue(x, "start_type", "0").toInt
      val start_outer_add_code = JSONUtils.getJsonValue(x, "start_outer_add_code", "0")
      val end_type = JSONUtils.getJsonValue(x, "end_type", "0").toInt
      val end_outer_add_code = JSONUtils.getJsonValue(x, "end_outer_add_code", "0")
      val start_dept = JSONUtils.getJsonValue(x, "start_dept", "0")
      val end_dept = JSONUtils.getJsonValue(x, "end_dept", "0")

      val line_code = JSONUtils.getJsonValue(x, "line_code", "")
      val vehicle_type = JSONUtils.getJsonValue(x, "vehicle_type", "5").toInt // TODO change default 0-> 5

      val srcDeptcode = if (start_type.equals(2)) start_dept else if (start_type.equals(1)) start_outer_add_code else start_dept
      val destDeptcode = if (end_type.equals(2)) end_dept else if (end_type.equals(1)) end_outer_add_code else end_dept

      val start_longitude = JSONUtils.getJsonValue(x, "x1", "0").toDouble //todo change start_longitude to x1 toDouble
      val start_latitude = JSONUtils.getJsonValue(x, "y1", "0").toDouble //todo 同上
      val end_longitude = JSONUtils.getJsonValue(x, "x2", "0").toDouble //todo 同上
      val end_latitude = JSONUtils.getJsonValue(x, "y2", "0").toDouble //todo 同上
      //20230712新增
      val carrierid0 = JSONUtils.getJsonValue(x, "carrierid", "")
      val carrierid=if(carrierid0==null || carrierid0.trim==""){null} else{carrierid0.toLong}

      val jo = new JSONObject()
      jo.put("ak", "4dc00a88a1f34bffa49a153103458efc")
      jo.put("optUserId", "bdp")
      jo.put("srcDeptcode", srcDeptcode)
      jo.put("destDeptcode", destDeptcode)
      jo.put("lineCode", line_code)
      jo.put("vehicle", vehicle_type)
      jo.put("containDeleted", false)
      jo.put("returnCoord", true)
      jo.put("returnLabel", false)
      jo.put("sortType", 1)
      jo.put("deptCoordFilter", true)
      jo.put("carrierId", carrierid)
      jo.put("x1", start_longitude)
      jo.put("y1", start_latitude)
      jo.put("x2", end_longitude)
      jo.put("y2", end_latitude)

      x.put("getJo", jo.toJSONString) //todo fixme
      x

    })

    retryRdd2

  }

  def recalSim(list: JSONArray, x: JSONObject) = {

    val rt_coords = x.getString("rt_coords")
    val pns_dist = JSONUtils.getJsonValueInt(x, "pns_dist", 0)
    val vehicle_type = JSONUtils.getJsonValueInt(x, "vehicle_type", 5)
    val is_navi = JSONUtils.getJsonValueInt(x, "is_navi", 0)
    val rt_dist = JSONUtils.getJsonValueDouble(x, "rt_dist", 0)

    var stopFlag = 0

    val size = if (list.size() >= 3) 3 else list.size()

    for (i <- (0 until (size)) if stopFlag == 0) {

      val jo = list.getJSONObject(i)
      val std_coords = jo.getString("jyTrack2")
      val line_distance = JSONUtils.getJsonValueDouble(jo, "lineDistance", 0) / 1000
      val pns_dist = JSONUtils.getJsonValueDouble(jo, "rtDistance", 0)


      if (StringUtils.nonEmpty(std_coords) && StringUtils.nonEmpty(rt_coords)) {

        val joArray1 = new JSONArray()
        val array1 = std_coords.split("\\|")

        for (pos <- array1) {
          val dx = try {
            pos.split(",")(0)
          } catch {
            case e: Exception => "0"
          }
          val dy = try {
            pos.split(",")(1)
          } catch {
            case e: Exception => "0"
          }
          val arrayNew = new JSONArray()
          arrayNew.add(dx)
          arrayNew.add(dy)
          joArray1.add(arrayNew)
        }


        val joArray2 = new JSONArray()
        val array2 = try {
          JSON.parseArray(rt_coords)
        } catch {
          case e: Exception => new JSONArray()
        }

        for (i <- 0 until (array2.size())) {
          val json = array2.getJSONObject(i)
          val x = json.getDouble("dx")
          val y = json.getDouble("dy")
          val arrayNew = new JSONArray()
          arrayNew.add(x)
          arrayNew.add(y)
          joArray2.add(arrayNew)
        }


        val jo1 = new JSONObject()
        val jo2 = new JSONObject()

        jo1.put("rt_coords", joArray1) //TODO
        jo1.put("vehicle_type", vehicle_type)
        jo2.put("rt_coords", joArray2) //TODO


        val (sim1Pre, sim5Pre) = try {
          getSimilarInterface2.getSimilar2(jo1, jo2)
        } catch {
          case e: Exception => (0, 0)
        }

        val sim1 = try {
          sim1Pre.asInstanceOf[Double]
        } catch {
          case e: Exception => 0.0
        }
        val sim5 = try {
          sim5Pre.asInstanceOf[Double]
        } catch {
          case e: Exception => 0.0
        }
        logger.error("sim1新:"+sim1)
        logger.error("sim5新:"+sim5)
        //line_distance=61
        val conduct_type = (line_distance, is_navi) match {
          case (line_distance, is_navi) if (line_distance <= 5 && ((pns_dist <= 5000 && rt_dist <= 5000) || Math.abs(rt_dist - pns_dist) <= 2000 || (pns_dist <= 10000 && Math.max(sim1, sim5) > 0.5 && Math.min(sim1, sim5) >= 0.4) || (pns_dist > 10000 && Math.max(sim1, sim5) > 0.6 && Math.min(sim1, sim5) >= 0.5) || pns_dist <= 1000 || Math.max(sim1, sim5) >= 0.9)) => 1
          case (line_distance, is_navi) if (line_distance > 5 && line_distance <= 10 && ((Math.max(sim1, sim5) >= 0.6 && Math.min(sim1, sim5) >= 0.5) || Math.max(sim1, sim5) >= 0.9)) => 1
          case (line_distance, is_navi) if (line_distance > 10 && line_distance <= 50 && Math.max(sim1, sim5) > 0.75 && Math.min(sim1, sim5) >= 0.7) => 1
          case (line_distance, is_navi) if (line_distance > 50 && line_distance <= 100 && Math.max(sim1, sim5) > 0.8 && Math.min(sim1, sim5) >= 0.75) => 1
          case (line_distance, is_navi) if (line_distance > 100 && line_distance <= 500 && Math.max(sim1, sim5) > 0.85 && Math.min(sim1, sim5) >= 0.8) => 1
          case (line_distance, is_navi) if (line_distance > 500 && Math.max(sim1, sim5) > 0.9 && Math.min(sim1, sim5) >= 0.85) => 1
          case (line_distance, is_navi) if ((pns_dist <= 5000 && rt_dist <= 5000 && rt_dist != 0) || pns_dist == 0 || (pns_dist <= 10000 && Math.abs(rt_dist - pns_dist) <= 2000 && rt_dist != 0) ||
            ((rt_dist != 0 && Math.abs(rt_dist - pns_dist) <= 5000 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000)))
              || (rt_dist != 0 && Math.abs(rt_dist - pns_dist) / rt_dist <= 0.05 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000))))) => 1
          case (line_distance, is_navi) if (is_navi == 1) => 2
          case _ => 3
        }
        if (conduct_type != 3) {
          //            line_code,sim1,sim5,rt_dist,line_distance,line_time,x1,y1,x2,y2
          val line_distance_std = JSONUtils.getJsonValueInt(jo, "lineDistance", 0)
          val line_time = JSONUtils.getJsonValueInt(jo, "lineTime", 0)
          val std_x1 = JSONUtils.getJsonValueDouble(jo, "trackStartX", 0)
          val std_y1 = JSONUtils.getJsonValueDouble(jo, "trackStartY", 0)
          val std_x2 = JSONUtils.getJsonValueDouble(jo, "trackEndX", 0)
          val std_y2 = JSONUtils.getJsonValueDouble(jo, "trackEndY", 0)
          val pns_time = JSONUtils.getJsonValueInt(jo, "rtTime", 0)
          val src = JSONUtils.getJsonValueInt(jo, "isEcon", 0)
          val line_time_std = JSONUtils.getJsonValue(jo, "lineTime", "")
          val std_id = JSONUtils.getJsonValue(jo, "stdId", "")

          val std_coords_arr = std_coords.split("\\|")
          val new_arr = new ArrayBuffer[String]()
          for (i <- 0 until std_coords_arr.size) {
            val x = std_coords_arr(i).split(",")(0)
            val y = std_coords_arr(i).split(",")(1)
            new_arr += "[\"" + x + "\",\"" + y + "\"]"
          }
          if (conduct_type == 1) x.put("std_id", std_id)
          x.put("conduct_type", conduct_type)
          x.put("conduct_order", i + 1)

          x.put("pns_dist", pns_dist)
          x.put("pns_time", pns_time)

          x.put("src", src)
          x.put("std_coords", "[" + new_arr.mkString(",") + "]")
          x.put("std_id", std_id)
          //          x.put("line_distance_std", line_distance_std)
          //          x.put("line_time_std", line_time_std)
          x.put("std_x1", std_x1)
          x.put("std_y1", std_y1)
          x.put("std_x2", std_x2)
          x.put("std_y2", std_y2)

          //20230712新增
          x.put("sim1", sim1)
          x.put("sim5", sim5)
          x.put("sim1_new", sim1)
          x.put("sim5_new", sim5)
          stopFlag = 1
        }
      }

    }
    x
  }

  def parseGetLineResult(fixResponse: JSONObject, x: JSONObject) = {
    val result = fixResponse.getJSONObject("result")
    val cnt = result.getIntValue("cnt")
    val list = result.getJSONArray("list")

    val jo =
      if (cnt == 1) x else {
        var simJo = x
        if (list != null) { //todo exeception
          simJo = recalSim(list, x)
        }
        simJo
      }
    jo
  }

  /**
   * 分时间段接口返回解析
   *
   * @return
   */

  case  class x_str(x_a:String)

  //定义获取url数据
  def getline_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新接口
    val url="http://gis-apis.int.sfcloud.local:1080/etaStdLine/operate/getLine"
    try {
      val task_subid=obj.getString("task_subid")
      val stdid=obj.getString("std_id")
      val parm_str=
        s"""
           |{
           |"optUserId":"bdp",
           |"stdId":"$stdid",
           |"containDeleted":"true",
           |"ak":"4dc00a88a1f34bffa49a153103458efc"
           |}
           |""".stripMargin

      val retStr: String = UrlUtils.sendPost(url,parm_str,20)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
      logger.error("返回正确数据，task_subid:"+task_subid)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret",tmp)
        obj.put("errmsg",e.getMessage)
        logger.error("错误信息："+e.getMessage)
    }
    obj
  }

  //调取接口并发请求
  def Multi_getline_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl="http://gis-apis.int.sfcloud.local:1080/etaStdLine/operate/getLine"
    val httpAk="4dc00a88a1f34bffa49a153103458efc"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "371318", "标准线路指标监控需求",
      "标准线路指标监控需求，外包承运商执行判断优化。",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, getline_url, 20, "4dc00a88a1f34bffa49a153103458efc", 5500)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    logger.error("并发数量为:" + dataCnt)
    returnAtRDD
  }

  def getUrlCal(x: JSONObject): JSONObject = {

    val getJo = x.getJSONObject("getJo")
    val url = "http://gis-apis.int.sfcloud.local:1080/etaStdLine/operate/getLine"
    //    x.remove("getJo")//todo fix save
    val fixResponse = SparkUtils.doPost(url, getJo, logger)
    val fixResponseParse = try {
      JSON.parseObject(fixResponse)
    } catch {
      case e: Exception => new JSONObject()
    }
    val jo = parseGetLineResult(fixResponseParse, x)
    jo

  }

  def getUrlRetryRdd(spark:SparkSession,calRetryStdRdd: RDD[JSONObject]) = {
    val limitMin = 5500
    //调用开始上报
    val httpUrl= "http://gis-apis.int.sfcloud.local:1080/etaStdLine/operate/getLine"
    val httpAk="4dc00a88a1f34bffa49a153103458efc"
    val dataCnt=calRetryStdRdd.count()
    val invokeThreadCnt=calRetryStdRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "371318", "标准线路指标监控需求",
      "标准线路指标监控需求，外包承运商执行判断优化。",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)

    val gjRectifyRdd = SparkUtils.akLimitMultiThreadRdd(calRetryStdRdd)(getUrlCal)(limitMin).persist(StorageLevel.MEMORY_AND_DISK_SER)

    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    logger.error("并发数量为:" + dataCnt)

    gjRectifyRdd

  }

  def getAccrualDistRdd(spark: SparkSession, inc_day: String, getComputeRdd: RDD[JSONObject]) = {

    val accrualDistRdd = getComputeRdd.map(x => {

      val navi_complete_rate = JSONUtils.getJsonValueDouble(x,"navi_complete_rate",0)
      val line_distance= JSONUtils.getJsonValueDouble(x,"line_distance",0)
      val sim1 = JSONUtils.getJsonValueDouble(x,"sim1",0)
      val sim5 = JSONUtils.getJsonValueDouble(x,"sim5",0)
      val pns_dist= JSONUtils.getJsonValueDouble(x,"pns_dist",0)
      val rt_dist= JSONUtils.getJsonValueDouble(x,"rt_dist",0)
      val is_yaw_by_driver= JSONUtils.getJsonValueDouble(x,"is_yaw_by_driver",0)
      val is_navi = JSONUtils.getJsonValueInt(x,"is_navi",0)

      val vehicle_type = JSONUtils.getJsonValueInt(x,"vehicle_type",5)
      val toll_charge= JSONUtils.getJsonValueDouble(x,"toll_charge",0)


      val oil_type = vehicle_type match {
        case line_distance if (vehicle_type == 5)  => 12
        case line_distance if (vehicle_type == 6)  => 12
        case line_distance if (vehicle_type == 7)  => 15.3
        case line_distance if (vehicle_type == 8)  => 21.6
      }


      val oil_consumption = ( rt_dist / 1000 / 100 ) * oil_type
      val oil_cost = oil_consumption * 7.31
      val total_cost = toll_charge + oil_cost


      //      val conduct_type = line_distance match {
      //        case line_distance if (line_distance <= 5 && ((pns_dist <= 5000 && rt_dist <= 5000) || Math.abs(rt_dist - pns_dist) <= 2000 || (pns_dist <= 10000 && Math.max(sim1,sim5) >0.5 && Math.min(sim1,sim5) >=0.4) || (pns_dist > 10000 && Math.max(sim1,sim5) >0.6 && Math.min(sim1,sim5) >=0.5) || pns_dist <= 1000 || Math.max(sim1,sim5) >= 0.9)) => 1
      //        case line_distance if (line_distance > 5 && line_distance <= 10 && ((Math.max(sim1,sim5) >=0.6 && Math.min(sim1,sim5) >= 0.5) || Math.max(sim1,sim5) >=0.9)) => 1
      //        case line_distance if (line_distance > 10 && line_distance <= 50 && Math.max(sim1,sim5) > 0.75 && Math.min(sim1,sim5) >= 0.7) => 1
      //        case line_distance if (line_distance > 50 && line_distance <= 100 && Math.max(sim1,sim5) > 0.8 && Math.min(sim1,sim5) >= 0.75) => 1
      //        case line_distance if (line_distance > 100 && line_distance <= 500 && Math.max(sim1,sim5) > 0.85 && Math.min(sim1,sim5) >= 0.8) => 1
      //        case line_distance if (line_distance > 500  && Math.max(sim1,sim5) > 0.9 && Math.min(sim1,sim5) >= 0.85) => 1
      //        case line_distance if (( pns_dist <= 5000 && rt_dist <= 5000 && rt_dist!=0) || (pns_dist <= 10000 && Math.abs(rt_dist - pns_dist) <= 2000 && rt_dist!=0) ||
      //          ((rt_dist != 0 && Math.abs(rt_dist - pns_dist) <= 5000 && (Math.max(sim1,sim5) >= 0.75 || (Math.max(sim1,sim5) >0.7 && pns_dist <=20000) ))
      //            || (rt_dist != 0 && Math.abs(rt_dist - pns_dist) / rt_dist <= 0.05 && (Math.max(sim1,sim5) >= 0.75 || (Math.max(sim1,sim5) >0.7 && pns_dist <=20000))))) => 1
      //        case _ => 3
      //      }

      // TODO: 20220926新增
      val conduct_type = (line_distance,is_navi) match {
        case (line_distance,is_navi) if (line_distance <= 5 && ((pns_dist <= 5000 && rt_dist <= 5000) || Math.abs(rt_dist - pns_dist) <= 2000 || (pns_dist <= 10000 && Math.max(sim1,sim5) >0.5 && Math.min(sim1,sim5) >=0.4) || (pns_dist > 10000 && Math.max(sim1,sim5) >0.6 && Math.min(sim1,sim5) >=0.5) || pns_dist <= 1000 || Math.max(sim1,sim5) >= 0.9)) => 1
        case (line_distance,is_navi) if (line_distance > 5 && line_distance <= 10 && ((Math.max(sim1,sim5) >=0.6 && Math.min(sim1,sim5) >= 0.5) || Math.max(sim1,sim5) >=0.9)) => 1
        case (line_distance,is_navi) if (line_distance > 10 && line_distance <= 50 && Math.max(sim1,sim5) > 0.75 && Math.min(sim1,sim5) >= 0.7) => 1
        case (line_distance,is_navi) if (line_distance > 50 && line_distance <= 100 && Math.max(sim1,sim5) > 0.8 && Math.min(sim1,sim5) >= 0.75) => 1
        case (line_distance,is_navi) if (line_distance > 100 && line_distance <= 500 && Math.max(sim1,sim5) > 0.85 && Math.min(sim1,sim5) >= 0.8) => 1
        case (line_distance,is_navi) if (line_distance > 500  && Math.max(sim1,sim5) > 0.9 && Math.min(sim1,sim5) >= 0.85) => 1
        case (line_distance,is_navi) if (( pns_dist <= 5000 && rt_dist <= 5000 && rt_dist!=0) || pns_dist == 0 || (pns_dist <= 10000 && Math.abs(rt_dist - pns_dist) <= 2000 && rt_dist!=0) ||
          ((rt_dist != 0 && Math.abs(rt_dist - pns_dist) <= 5000 && (Math.max(sim1,sim5) >= 0.75 || (Math.max(sim1,sim5) >0.7 && pns_dist <=20000) ))
            || (rt_dist != 0 && Math.abs(rt_dist - pns_dist) / rt_dist <= 0.05 && (Math.max(sim1,sim5) >= 0.75 || (Math.max(sim1,sim5) >0.7 && pns_dist <=20000))))) => 1
        case (line_distance,is_navi) if (is_navi==1) => 2
        case _ => 3
      }
      var accrual_dist = 0.0
      var accrual_dist_type = 0

      val err_type = JSONUtils.getJsonValue(x,"err_type","-")
      val err_type_list = List("0","2","3","2|3","3|2")

      val x1 = JSONUtils.getJsonValueDouble(x,"x1",0)
      val y1 = JSONUtils.getJsonValueDouble(x,"y1",0)
      val x2 = JSONUtils.getJsonValueDouble(x,"x2",0)
      val y2 = JSONUtils.getJsonValueDouble(x,"y2",0)

      val std_x1 = JSONUtils.getJsonValueDouble(x,"std_x1",0)
      val std_y1 = JSONUtils.getJsonValueDouble(x,"std_y1",0)
      val std_x2 = JSONUtils.getJsonValueDouble(x,"std_x2",0)
      val std_y2 = JSONUtils.getJsonValueDouble(x,"std_y2",0)

      val start_distance_std = DistanceTool.getGreatCircleDistance(x1,y1,std_x1,std_y1)
      val end_distance_std = DistanceTool.getGreatCircleDistance(x2,y2,std_x2,std_y2)


      if(pns_dist != 0) {
        if (navi_complete_rate > 0.75) {
          if (conduct_type == 1){
            if (pns_dist > rt_dist){
              accrual_dist = pns_dist
              accrual_dist_type = 2
            } else {
              accrual_dist = rt_dist
              accrual_dist_type = 1
            }
          } else {
            if (is_yaw_by_driver == 1){
              accrual_dist = rt_dist
              accrual_dist_type = 1
            }else{
              accrual_dist = pns_dist
              accrual_dist_type = 2
            }
          }
        }else{
          if (err_type_list.contains(err_type) && start_distance_std < 3000 && end_distance_std < 3000){
            //          if (err_type.contains("0")){
            if (conduct_type == 1){
              if (pns_dist > rt_dist){
                accrual_dist = pns_dist
                accrual_dist_type = 2
              } else {
                accrual_dist = rt_dist
                accrual_dist_type = 1
              }
            }else{
              if(pns_dist > rt_dist){
                accrual_dist = rt_dist
                accrual_dist_type = 1
              }else{
                accrual_dist = pns_dist
                accrual_dist_type = 2
              }
            }
          }else{
            accrual_dist = pns_dist
            accrual_dist_type = 2
          }
        }
      } else {
        accrual_dist = rt_dist
        accrual_dist_type = 1
      }


      if (accrual_dist < 500) accrual_dist = 1000

      x.put("conduct_type",conduct_type)
      x.put("accrual_dist",accrual_dist)
      x.put("accrual_dist_type",accrual_dist_type)

      x.put("oil_consumption",oil_consumption)
      x.put("oil_cost",oil_cost)
      x.put("total_cost",total_cost)


      x
    })
      .map(x => {
        val task_subid = x.getString("task_subid")
        (task_subid,x)
      })
      .reduceByKey((obj1,obj2) => mergeLastUpdateConduct(obj1,obj2))
      .map(_._2)
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("accrualDistRdd的数据量为：" + accrualDistRdd.count())

    // TODO: 需要重算的rdd
    val retryRdd = accrualDistRdd.filter(x => {
      val carrier_type = JSONUtils.getJsonValueInt(x, "carrier_type", 3)
      val conduct_type = JSONUtils.getJsonValueInt(x, "conduct_type", 3)

      carrier_type != 0 && conduct_type == 3
    })

    logger.error("retryRdd的数据量为：" + retryRdd.count())

    // TODO: 重算逻辑
    val calRetryStdRdd = calRetryRddStd(retryRdd)
    val calRetryRdd = getUrlRetryRdd(spark,calRetryStdRdd)


    logger.error("calRetryRdd的数据量为：" + calRetryRdd.count())

    import spark.implicits._

    //    logger.error("calRetryRdd的数据量为test_bbb1" )
    //    Multi_retry_url(spark,calRetryStdRdd,300)
    //      .map(
    //        x=>{
    //          val x_a=x.toString()
    //          (x_a)
    //        }
    //      ) .toDF("jsondetail").write.mode(SaveMode.Overwrite).insertInto("dm_gis.test_aaa")
    //    logger.error("calRetryRdd的数据量为test_bbb2" )

    //    logger.error("calRetryRdd的数据量为test_bbb2" )
    //    calRetryRdd
    //      .map(
    //        x=>{
    //          val x_a=x.toString()
    //          (x_a)
    //        }
    //      ) .toDF("jsondetail").write.mode(SaveMode.Overwrite).insertInto("dm_gis.test_aaa")
    //    logger.error("calRetryRdd的数据量为test_aaa2" )

    //将获取接口的数据保存
    //    logger.error("calRetryRdd的数据量为test_bbb1" )
    //
    //    getComputeRdd.map(
    //      x=>{
    //        val x_a=x.toString()
    //        x_str(x_a)
    //      }
    //    ) .repartition(10).toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.test_bbb")
    //    logger.error("calRetryRdd的数据量为test_bbb2" )

    // 不需要重算的rdd
    val unRetryRdd = accrualDistRdd.filter(x => {
      val carrier_type = JSONUtils.getJsonValueInt(x, "carrier_type", 3)
      val conduct_type = JSONUtils.getJsonValueInt(x, "conduct_type", 3)

      !(carrier_type != 0 && conduct_type == 3)
    })

    logger.error("unRetryRdd的数据量为：" + unRetryRdd.count())

    val unionRdd = calRetryRdd.union(unRetryRdd).distinct()

    unionRdd

  }


  def addFilterProcess(spark: SparkSession, getJoin1to5Rdd: RDD[JSONObject]) = {

    // 筛选执行数据
    val union0Rdd = getJoin1to5Rdd.filter(x => {
      val conduct_type= JSONUtils.getJsonValueInt(x,"conduct_type",1)
      conduct_type != 3
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("union0Rdd的数据量为：" + union0Rdd.count())


    // 过滤执行数据(最后汇集)
    val union0Rdd1 = union0Rdd.filter(x => {
      val pns_dist= JSONUtils.getJsonValueDouble(x,"pns_dist",1)
      val rt_dist= JSONUtils.getJsonValueDouble(x,"rt_dist",1)

      Math.abs(pns_dist - rt_dist) < 2000 || Math.abs(pns_dist - rt_dist) / pns_dist < 0.05
    })
    logger.error("union0Rdd1的数据量为：" + union0Rdd1.count())


    // 未被过滤的执行数据（后续计算）
    val union0Rdd2 = union0Rdd.filter(x => {
      val pns_dist= JSONUtils.getJsonValueDouble(x,"pns_dist",1)
      val rt_dist= JSONUtils.getJsonValueDouble(x,"rt_dist",1)
      Math.abs(pns_dist - rt_dist) >= 2000 && Math.abs(pns_dist - rt_dist) / pns_dist >= 0.05
    })
    logger.error("union0Rdd2的数据量为：" + union0Rdd2.count())


    // 未执行数据
    val union1Rdd = getJoin1to5Rdd.filter(x => {
      val conduct_type= JSONUtils.getJsonValueInt(x,"conduct_type",1)
      conduct_type == 3
    })
    logger.error("union1Rdd的数据量为：" + union1Rdd.count())

    val unionRdd = union0Rdd2.union(union1Rdd)

    // 针对未被过滤的执行数据
    val union0RddNew = unionRdd.map(x => {
      val rt_coords= parseTable6Coords(x.getString("rt_coords"))
      val pns_dist= JSONUtils.getJsonValueDouble(x,"pns_dist",0)
      val rt_dist= JSONUtils.getJsonValueDouble(x,"rt_dist",0)
      val accrual_dist = JSONUtils.getJsonValueDouble(x,"accrual_dist",1000)
      val conduct_type= x.getString("conduct_type")

      var error = 0

      if (rt_coords != null && rt_coords.size()>1){

        for (i <- (0 until(rt_coords.size() -1))){

          val curArray = rt_coords.getJSONArray(i)
          val nextArray = rt_coords.getJSONArray(i + 1)
          val curX = curArray.getDouble(0)
          val curY = curArray.getDouble(1)
          val nextX = nextArray.getDouble(0)
          val nextY = nextArray.getDouble(1)
          val distance = DistanceTool.getGreatCircleDistance(curX,curY,nextX,nextY)

          if (distance > 5000) error = 1

        }

        if (error == 1){

          if (pns_dist > 500 ){
            val accrual_dist_new = pns_dist
            x.put("accrual_dist",accrual_dist_new)
          }

          val err_type = JSONUtils.getJsonValue(x,"error_type","")

          var errBuilder = new mutable.StringBuilder(err_type)

          if (errBuilder.isEmpty){
            errBuilder.append("7")
          } else {
            if (errBuilder.toString().equals("0")){
              errBuilder = new mutable.StringBuilder("7")
            }else{
              errBuilder.append("|").append("7")
            }

          }
          x.put("error_type",errBuilder.toString())
        }
      }
      x
    })


    // 将过滤调的数据恢复
    val unionAllRdd = union0RddNew.union(union0Rdd1)


    // 20220831 增加去重逻辑
    val unionAllRddNew = unionAllRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    })
      .reduceByKey((obj1,obj2) => mergeLastUpdate(obj1,obj2))
      .map(_._2)

    logger.error("unionAllRddNew的数据量为：" + unionAllRddNew.count())
    //    unionAllRddNew.take(2).foreach(println(_))

    unionAllRddNew

  }


  def getJoinDriverInfo(spark: SparkSession,inc_day:String, getJoin1to5Rdd: RDD[JSONObject]) = {

    val inc_day_pre3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-36)

    val sourceSql =
      s"""
         |select
         |  emp_code,motorcade_name,area_code
         |from
         |(
         |select
         |  row_number() over(partition by emp_code order by inc_day desc) as rn,
         |  emp_code,
         |  motorcade_name,
         |  area_code,
         |  inc_day
         |from
         |   dwd_o.dwd_tp_grd_driver_dtl_df
         |where
         |   inc_day >='${inc_day_pre3}'
         |and
         |   inc_day <= '${inc_day}'
         |) t
         |where
         | rn = 1
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)

    val driverInfoRdd = SparkUtils.getRowToJson(sourceDf).map(obj => {
      val emp_code = try {obj.getString("emp_code").replaceAll("^(0+)", "")} catch {case e:Exception => ""}
      (emp_code,obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("driverInfoRdd的数据量为：" + driverInfoRdd.count())


    val joinDriverInfoRdd = getJoin1to5Rdd.map(x => {
      val main_driver_account = if (StringUtils.nonEmpty(x.getString("main_driver_account"))) x.getString("main_driver_account").replaceAll("^(0+)", "") else "-"
      (main_driver_account,x)
    }).leftOuterJoin(driverInfoRdd).map(x => {

      val left = x._2._1
      val rightOption = x._2._2

      if(rightOption.nonEmpty){
        left.fluentPutAll(rightOption.get)
      }
      left

    })
    logger.error("joinDriverInfoRdd的数据量为：" + joinDriverInfoRdd.count())

    joinDriverInfoRdd

  }

  //往前推n天，例如20230725，2就是20230727
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

  //计算时间差：分钟
  def TimeDiffMinit(str1: String, str2: String): Long = {
    var datedf: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    //转换时间戳：毫秒
    val x1 = datedf.parse(str1).getTime
    val x2 = datedf.parse(str2).getTime
    //除以1000就是秒为单位
    val x3 = (x2 - x1) / 60000
    return x3
  }

  case class res_table1(
                         task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,
                         start_type:String,end_type:String,line_code:String,vehicle_serial:String,actual_capacity_load:String,plan_depart_tm:String,
                         actual_depart_tm:String,plan_arrive_tm:String,actual_arrive_tm:String,driver_id:String,driver_name:String,line_time:String,
                         line_distance:String,actual_run_time:String,start_longitude:String,start_latitude:String,end_longitude:String,
                         end_latitude:String,is_stop:String,transoport_level:String,carrier_type:String,plf_flag:String,vehicle_type:String,
                         axls_number:String,log_dist:String,task_inc_day:String,start_time:String,if_evaluate_time:String,is_run_ontime:String,
                         carrier_name:String,stop_over_zone_code:String,biz_type:String,require_category:String,to_ground:String,last_update_tm:String,
                         main_driver_account:String,road_fee:String,line_require_id:String,start_outer_add_code:String,end_outer_add_code:String,start_sortnum:String,
                         end_sortnum:String,type_info:String,carrier_id:String,carrier_code:String,src_city_name:String,dest_city_name:String,sf_outer_vehicle_from:String,
                         child_carrier_name:String,child_carrier_id:String,child_carrier_code:String,deputy_driver_account:String,deputy_driver_name:String
                       )

  case class res_table2(
                         task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,line_code:String,
                         vehicle_serial:String,actual_capacity_load:String,vehicle_type:String,start_longitude:String,start_latitude:String,end_longitude:String,
                         end_latitude:String,rt_coords:String,x1:String,y1:String,x2:String,y2:String,duration:String,time:String,tl_time:String,rt_dist:String,
                         highwaymileage:String,toll_charge:String,start_distance:String,end_distance:String,error_type:String,err_log:String,task_inc_day:String,
                         start_time:String,halfway_integrate_rate:String,line_require_id:String,start_sortnum:String,end_sortnum:String,
                         dist_a:String,dist_b:String,dist_c:String
                       )


  case class res_table3(
                         task_area_code:String,line_code:String,start_dept:String,end_dept:String,start_time:String,actual_capacity_load:String,
                         pns_dist:String,pns_time:String,src:String,std_coords:String,line_distance_std:String,line_time_std:String,err_log:String,task_subid:String,
                         std_id:String,std_x1:String,std_y1:String,std_x2:String,std_y2:String,std_toll_charge:String,line_require_id:String,
                         start_outer_add_code:String,end_outer_add_code:String,start_sortnum:String,end_sortnum:String,inc_day:String
                       )


  case class res_table4(
                         task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,line_code:String,
                         vehicle_serial:String,actual_capacity_load:String,vehicle_type:String,sim1:String,sim5:String,task_inc_day:String,
                         route_source:String,pns_dist:String,pns_time:String,src:String,std_coords:String,line_distance_std:String,line_time_std:String,
                         std_x1:String,std_y1:String,std_x2:String,std_y2:String,std_toll_charge:String,std_id:String
                       )

  case class res_table4New(
                            task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,line_code:String,
                            vehicle_serial:String,actual_capacity_load:String,vehicle_type:String,sim1:String,sim5:String,task_inc_day:String,
                            route_source:String,pns_dist:String,pns_time:String,src:String,std_coords:String,line_distance_std:String,line_time_std:String,
                            std_x1:String,std_y1:String,std_x2:String,std_y2:String,std_toll_charge:String,std_id:String,response:String,request:String
                          )

  case class res_table5(
                         task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,line_code:String,
                         sim1:String,sim5:String,rt_dist:String,line_distance:String,log_dist:String,pns_dist:String,if_dist_equal:String,diffdist_rt_line:String,
                         diffratio_rt_line:String,diffdist_rt_std:String,diffratio_rt_std:String,diffdist_rt_log:String,diffratio_rt_log:String,
                         diffdist_line_log:String,diffratio_line_log:String,diffdist_line_std:String,diffratio_line_std:String,diffdist_log_std:String,
                         diffratio_log_std:String,conduct_type:String,line_time:String,pns_time:String,tl_time:String,if_time_equal:String,difftime_line_std:String,
                         diffratio1_line_std:String,difftime_line_std_10min:String,difftime_line_rt:String,diffratio1_line_rt:String,difftime_rt_gh_10min:String,
                         difftime_std_rt:String,diffratio1_std_rt:String,difftime_std_rt_10min:String,is_run_ontime_std:String,
                         is_run_ontime:String,pns_error:String,task_inc_day:String,
                         actual_run_time:Double,x1:Double,y1:Double,x2:Double,y2:Double,std_x1:Double,std_y1:Double,std_x2:Double,std_y2:Double,start_distance_std:Double,end_distance_std:Double,std_line_error:Int,
                         ac_difftime_line_rt:Double,ac_diffratio1_line_rt:Double,ac_difftime_rt_gh_10min:Double,ac_difftime_std_rt:Double,ac_diffratio1_std_rt:Double,ac_difftime_std_rt_10min:Double,ac_is_run_ontime_std:Double,ac_is_run_ontime:Double,
                         navi_strategy:String,is_return_std_line:Int,is_navi_at_start:Int,is_navi_by_std_line:Int,route_time:String,drive_time:String,is_yaw_by_driver:Int,
                         navi_complete_rate:Double,accrual_dist:Double,accrual_dist_type:Int,
                         navi_starttime:String,navi_endtime:String,navi_time:String,navi_distance:String,is_navi:String,navi_count:String,type_info:String,
                         oil_consumption:String,oil_cost:String,total_cost:String,std_id: String,std_coords: String,conduct_order:String,
                         child_carrier_name:String,child_carrier_id:String,child_carrier_code:String,deputy_driver_account:String,deputy_driver_name:String
                       )

  case class res_table6(
                         task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,start_type:String,end_type:String,
                         line_code:String,vehicle_serial:String,actual_capacity_load:String,plan_depart_tm:String,actual_depart_tm:String,plan_arrive_tm:String,
                         actual_arrive_tm:String,driver_id:String,driver_name:String,line_time:String,line_distance:String,actual_run_time:String,start_longitude:String,
                         start_latitude:String,end_longitude:String,end_latitude:String,is_stop:String,transoport_level:String,carrier_type:String,plf_flag:String,
                         vehicle_type:String,axls_number:String,log_dist:String,rt_coords:String,x1:String,y1:String,x2:String,y2:String,duration:String,time:String,
                         rt_dist:String,highwaymileage:String,toll_charge:String,start_distance:String,end_distance:String,error_type:String,pns_dist:String,pns_time:String,
                         src:String,std_coords:String,line_distance_std:String,line_time_std:String,sim1:String,sim5:String,diffdist_rt_line:String,diffratio_rt_line:String,
                         diffdist_rt_std:String,diffratio_rt_std:String,diffdist_rt_log:String,diffratio_rt_log:String,diffdist_line_log:String,diffratio_line_log:String,
                         diffdist_line_std:String,diffratio_line_std:String,diffdist_log_std:String,diffratio_log_std:String,conduct_type:String,difftime_line_std:String,
                         diffratio1_line_std:String,difftime_line_std_10min:String,difftime_line_rt:String,diffratio1_line_rt:String,difftime_rt_gh_10min:String,
                         is_run_ontime_std:String,is_run_ontime:String,if_dist_equal:String,if_time_equal:String,pns_error:String,task_inc_day:String,difftime_std_rt:String,diffratio1_std_rt:String,difftime_std_rt_10min:String,
                         tl_time:String,halfway_integrate_rate:String,std_x1:String,std_y1:String,std_x2:String,std_y2:String,start_distance_std:String,end_distance_std:String,
                         std_line_error:String,ac_difftime_line_rt:String,ac_diffratio1_line_rt:String,ac_difftime_rt_gh_10min:String,ac_difftime_std_rt:String,
                         ac_diffratio1_std_rt:String,ac_difftime_std_rt_10min:String,ac_is_run_ontime_std:String,ac_is_run_ontime:String,if_evaluate_time:String,
                         carrier_name:String,stop_over_zone_code:String,biz_type:String,require_category:String,to_ground:String,std_toll_charge:String,std_id:String,
                         navi_strategy:String,is_return_std_line:String,is_navi_at_start:String,is_navi_by_std_line:String,route_time:String,drive_time:String,
                         is_yaw_by_driver:String,navi_complete_rate:String,accrual_dist:String,accrual_dist_type:String,last_update_tm:String,main_driver_account:String,
                         road_fee:String,line_require_id:String,start_outer_add_code:String,end_outer_add_code:String,start_sortnum:String,end_sortnum:String,
                         is_navi:String,carrier_id:String,carrier_code:String,total_oil_consumption:String,oil_cost:String,total_cost:String,conduct_order:String,
                         src_city_name:String,dest_city_name:String,sf_outer_vehicle_from:String,
                         child_carrier_name:String,child_carrier_id:String,child_carrier_code:String,deputy_driver_account:String,deputy_driver_name:String,
                         conduct_type_old:String,std_id_old:String,sim1_old:String,sim5_old:String,conduct_order_old:String,pns_dist_old:String,
                         pns_time_old:String,src_old:String,std_coords_old:String,line_distance_std_old:String,line_time_std_old:String,
                         std_x1_old:String ,std_y1_old:String,std_x2_old:String,std_y2_old:String,is_navi_old:String,rt_tm:String,driver_score:String,task_area_code_new:String
                       )


  case class res_table7(
                         task_area_code:String,task_id:String,carrier_name:String,task_inc_day:String,start_dept:String,start_type:String,line_code:String,
                         vehicle_serial:String,actual_capacity_load:String,plan_depart_tm:String,actual_depart_tm:String,driver_id:String,driver_name:String,
                         is_stop:String,transoport_level:String,carrier_type:String,plf_flag:String,vehicle_type:String,axls_number:String,log_dist:String,
                         if_evaluate_time:String,stop_over_zone_code:String,end_dept:String,end_type:String,plan_arrive_tm:String,actual_arrive_tm:String,
                         line_time:String,line_distance:String,actual_run_time:String,duration:String,time:String,rt_dist:String,highwaymileage:String,
                         toll_charge:String,pns_dist:String,pns_time:String,std_toll_charge:String,if_error:String,src:String,conduct_type:String,
                         ac_is_run_ontime:String,diffdist_log_rt:String,diffratio_log_rt:String,accrual_dist:String,accrual_dist_type:String,last_update_tm:String,
                         main_driver_account:String,road_fee:String,line_require_id:String,is_navi:String,carrier_id:String,carrier_code:String,
                         total_oil_consumption:String,oil_cost:String,total_cost:String,src_city_name:String,dest_city_name:String,sf_outer_vehicle_from:String,
                         child_carrier_name:String,child_carrier_id:String,child_carrier_code:String,deputy_driver_account:String,deputy_driver_name:String,
                         task_area_code_new:String
                       )

  case class res_table8(
                         task_id:String,sort_num:String,task_area_code:String,line_code:String,start_dept:String,start_dept_site_id:String,
                         end_dept:String,end_dept_site_id:String,start_type:String,end_type:String,plan_depart_tm:String,actual_depart_tm:String,
                         plan_arrive_tm:String,actual_arrive_tm:String,line_time:String,line_distance:String,actual_run_time:String,start_longitude:String,
                         start_latitude:String,end_longitude:String,end_latitude:String,require_category:String,stop_over_zone_code:String,vehicle_serial:String,
                         driver_id:String,driver_name:String,actual_capacity_load:String,capacity_load:String,transoport_level:String,to_ground:String,
                         biz_type:String,carrier_name:String,is_stop:String,carrier_type:String,plf_flag:String,state:String,last_update_tm:String,
                         full_load_weight:String,votes_l:String,votes_lw:String,votes_s:String,votes_n:String,votes_d:String,votes_w:String,votes_sp:String,
                         votes_dp:String,votes_pw:String,contnr_code:String
                       )




}
