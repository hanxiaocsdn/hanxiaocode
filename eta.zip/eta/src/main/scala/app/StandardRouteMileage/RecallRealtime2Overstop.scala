package app.StandardRouteMileage

import Utils.SparkUtils.writeToHive
import com.sf.gis.java.base.util.SparkUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 *需求名称：解析实时判断表
 *需求描述：将实时表recall2的数据拆分另存一张表。
 *需求方：01369612张翠霞
 *开发: 周勇(01390943)
 *任务创建时间：20230725
 *任务id：781666
 **/

object RecallRealtime2Overstop {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._
    val dayvar = args(0)
    logger.error("接收输入变量dayvar:" + dayvar)

    val realtime_data=spark.sql(
      s"""
        |select info,inc_day from dm_gis.eta_std_line_recall_realtime2
        |where inc_day='$dayvar'
        |""".stripMargin)
      .repartition(100)
      .withColumn("task_area_code",get_json_object($"info","$.task_area_code"))
      .withColumn("task_id",get_json_object($"info","$.task_id"))
      .withColumn("carrier_type",get_json_object($"info","$.carrier_type"))
      .withColumn("task_label_final",get_json_object($"info","$.task_label_final"))
      .withColumn("is_stop",get_json_object($"info","$.is_stop"))
      .withColumn("task_subid",get_json_object($"info","$.task_subid"))
      .withColumn("tmp_col",when($"task_subid".isNull || trim($"task_subid")==="","").
        otherwise(clearnull_2_udf($"task_subid")))

      .withColumn("sort_num",get_json_object($"info","$.sort_num"))
      .withColumn("sort_num",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"sort_num".isNull || trim($"sort_num")==="",clearnull_1_udf($"task_subid")).
        otherwise(clearnull_3_udf($"task_subid",$"sort_num")))

      .withColumn("conduct_type_final2",get_json_object($"info","$.conduct_type_final2"))
      .withColumn("conduct_type_final2",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"conduct_type_final2".isNull || trim($"conduct_type_final2")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"conduct_type_final2")))

      .withColumn("std_id_kafka",get_json_object($"info","$.std_id_kafka"))
      .withColumn("std_id_kafka",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"std_id_kafka".isNull || trim($"std_id_kafka")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"std_id_kafka")))

      .withColumn("std_id",get_json_object($"info","$.std_id"))
      .withColumn("std_id",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"std_id".isNull || trim($"std_id")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"std_id")))

      .withColumn("conduct_type1",get_json_object($"info","$.conduct_type1"))
      .withColumn("conduct_type1",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"conduct_type1".isNull || trim($"conduct_type1")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"conduct_type1")))

      .withColumn("sim1_1",get_json_object($"info","$.sim1_1"))
      .withColumn("sim1_1",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"sim1_1".isNull || trim($"sim1_1")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"sim1_1")))

      .withColumn("sim5_1",get_json_object($"info","$.sim5_1"))
      .withColumn("sim5_1",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"sim5_1".isNull || trim($"sim5_1")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"sim5_1")))

      .withColumn("pns_dist",get_json_object($"info","$.pns_dist"))
      .withColumn("pns_dist",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"pns_dist".isNull || trim($"pns_dist")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"pns_dist")))

      .withColumn("pns_time",get_json_object($"info","$.pns_time"))
      .withColumn("pns_time",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"pns_time".isNull || trim($"pns_time")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"pns_time")))

      .withColumn("line_distance_std",get_json_object($"info","$.line_distance_std"))
      .withColumn("line_distance_std",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"line_distance_std".isNull || trim($"line_distance_std")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"line_distance_std")))

      .withColumn("line_time_std",get_json_object($"info","$.line_time_std"))
      .withColumn("line_time_std",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"line_time_std".isNull || trim($"line_time_std")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"line_time_std")))

      .withColumn("std_id2",get_json_object($"info","$.std_id2"))
      .withColumn("std_id2",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"std_id2".isNull || trim($"std_id2")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"std_id2")))

      .withColumn("conduct_type2",get_json_object($"info","$.conduct_type2"))
      .withColumn("conduct_type2",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"conduct_type2".isNull || trim($"conduct_type2")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"conduct_type2")))

      .withColumn("sim1_2",get_json_object($"info","$.sim1_2"))
      .withColumn("sim1_2",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"sim1_2".isNull || trim($"sim1_2")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"sim1_2")))

      .withColumn("sim5_2",get_json_object($"info","$.sim5_2"))
      .withColumn("sim5_2",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"sim5_2".isNull || trim($"sim5_2")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"sim5_2")))

      .withColumn("conduct_order",get_json_object($"info","$.conduct_order"))
      .withColumn("conduct_order",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"conduct_order".isNull || trim($"conduct_order")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"conduct_order")))

      //待开发
      .withColumn("navi_stdid",get_json_object($"info","$.navi_stdid"))
      .withColumn("navi_stdid",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"navi_stdid".isNull || trim($"navi_stdid")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"navi_stdid")))
      //待开发
      .withColumn("conduct_type_final",get_json_object($"info","$.conduct_type_final"))
      .withColumn("conduct_type_final",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"conduct_type_final".isNull || trim($"conduct_type_final")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"conduct_type_final")))
      //待开发
      .withColumn("sim1_navi",get_json_object($"info","$.sim1_navi"))
      .withColumn("sim1_navi",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"sim1_navi".isNull || trim($"sim1_navi")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"sim1_navi")))
      //待开发
      .withColumn("sim5_navi",get_json_object($"info","$.sim5_navi"))
      .withColumn("sim5_navi",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"sim5_navi".isNull || trim($"sim5_navi")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"sim5_navi")))
      //待开发
      .withColumn("is_navi",get_json_object($"info","$.is_navi"))
      .withColumn("is_navi",when($"task_subid".isNull || trim($"task_subid")==="","").
        when($"is_navi".isNull || trim($"is_navi")==="",$"tmp_col").
        otherwise(clearnull_4_udf($"task_subid",$"is_navi")))

      //20231221 V4.6新增字段
      .withColumn("line_id", get_json_object($"info", "$.line_id"))
      .withColumn("line_id", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_id".isNull || trim($"line_id") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_id")))
      .withColumn("line_id", regexp_replace($"line_id", "&", ","))
      //20231221 V4.6新增字段
      .withColumn("line_order", get_json_object($"info", "$.line_order"))
      .withColumn("line_order", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_order".isNull || trim($"line_order") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_order")))
      //20231221 V4.6新增字段
      .withColumn("line_type", get_json_object($"info", "$.line_type"))
      .withColumn("line_type", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_type".isNull || trim($"line_type") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_type")))
      .withColumn("line_type", regexp_replace($"line_type", "&", ","))
      //20231221 V4.6新增字段
      .withColumn("subtask_navi_yaw", get_json_object($"info", "$.subtask_navi_yaw"))
      .withColumn("subtask_navi_yaw", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"subtask_navi_yaw".isNull || trim($"subtask_navi_yaw") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"subtask_navi_yaw")))

      //20240221 V5.0 新增字段
      .withColumn("line_sim1_1", get_json_object($"info", "$.line_sim1_1"))
      .withColumn("line_sim1_1", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_sim1_1".isNull || trim($"line_sim1_1") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_sim1_1")))
      //20240221 V5.0 新增字段
      .withColumn("line_sim5_1", get_json_object($"info", "$.line_sim5_1"))
      .withColumn("line_sim5_1", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_sim5_1".isNull || trim($"line_sim5_1") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_sim5_1")))
      //20240221 V5.0 新增字段
      .withColumn("line_sim1_2", get_json_object($"info", "$.line_sim1_2"))
      .withColumn("line_sim1_2", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_sim1_2".isNull || trim($"line_sim1_2") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_sim1_2")))
      //20240221 V5.0 新增字段
      .withColumn("line_sim5_2", get_json_object($"info", "$.line_sim5_2"))
      .withColumn("line_sim5_2", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_sim5_2".isNull || trim($"line_sim5_2") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_sim5_2")))
      //20240221 V5.0 新增字段
      .withColumn("line_cond", get_json_object($"info", "$.line_cond"))
      .withColumn("line_cond", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_cond".isNull || trim($"line_cond") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_cond")))
      //20240221 V5.0 新增字段
      .withColumn("line_cond2", get_json_object($"info", "$.line_cond2"))
      .withColumn("line_cond2", when($"task_subid".isNull || trim($"task_subid") === "", "").
        when($"line_cond2".isNull || trim($"line_cond2") === "", $"tmp_col").
        otherwise(clearnull_4_udf($"task_subid", $"line_cond2")))

      .withColumn("create_time",get_json_object($"info","$.create_time"))
      //.drop("info")
      .withColumn("rank",row_number().over(Window.partitionBy("task_id").orderBy(desc("create_time"))))
      .filter($"rank"==="1")
      .drop("rank")

     //spark.sql("drop table if exists tmp_dm_gis.realtime_data")
    //realtime_data.write.mode("overwrite").format("parquet").saveAsTable("tmp_dm_gis.realtime_data")
    realtime_data.createOrReplaceTempView("realtime_data_tb")

    val result_data1 = spark.sql(
        """
          |select
          |task_area_code,task_id,carrier_type,is_stop,task_label_final
          |,task_subid
          |,sort_num
          |,conduct_type_final2
          |,std_id_kafka
          |,std_id
          |,conduct_type1
          |,sim1_1
          |,sim5_1
          |,pns_dist
          |,pns_time
          |,line_distance_std
          |,line_time_std
          |,std_id2
          |,conduct_type2
          |,sim1_2
          |,sim5_2
          |,conduct_order
          |,navi_stdid
          |,conduct_type_final
          |,sim1_navi
          |,sim5_navi
          |,is_navi
          |,line_id
          |,line_order
          |,line_type
          |,subtask_navi_yaw
          |,line_sim1_1
          |,line_sim5_1
          |,line_sim1_2
          |,line_sim5_2
          |,line_cond
          |,line_cond2

          |from (
          |select
          |task_area_code,task_id,carrier_type,is_stop,task_label_final,
          |split(task_subid,'\\|') as list0,
          |split(sort_num,'\\|') as list1,
          |split(conduct_type_final2,';') as list2,
          |split(std_id_kafka,';') as list3,
          |split(std_id,';') as list4,
          |split(conduct_type1,';') as list5,
          |split(sim1_1,';') as list6,
          |split(sim5_1,';') as list7,
          |split(pns_dist,';') as list8,
          |split(pns_time,';') as list9,
          |split(line_distance_std,';') as list10,
          |split(line_time_std,';') as list11,
          |split(std_id2,';') as list12,
          |split(conduct_type2,';') as list13,
          |split(sim1_2,';') as list14,
          |split(sim5_2,';') as list15,
          |split(conduct_order,';') as list16,
          |split(navi_stdid,';') as list17,
          |split(conduct_type_final,';') as list18,
          |split(sim1_navi,';') as list19,
          |split(sim5_navi,';') as list20,
          |split(is_navi,';') as list21,
          |split(line_id,';') as list22,
          |split(line_order,';') as list23,
          |split(line_type,';') as list24,
          |split(subtask_navi_yaw,';') as list25,
          |split(line_sim1_1,';') as list26,
          |split(line_sim5_1,';') as list27,
          |split(line_sim1_2,';') as list28,
          |split(line_sim5_2,';') as list29,
          |split(line_cond,';') as list30,
          |split(line_cond2,';') as list31

          |from realtime_data_tb
          |) a
          |lateral VIEW posexplode(list0) list0a AS rk0,task_subid
          |lateral VIEW posexplode(list1) list1a AS rk1,sort_num
          |lateral VIEW posexplode(list2) list2a AS rk2,conduct_type_final2
          |lateral VIEW posexplode(list3) list3a AS rk3,std_id_kafka
          |lateral VIEW posexplode(list4) list4a AS rk4,std_id
          |lateral VIEW posexplode(list5) list5a AS rk5,conduct_type1
          |lateral VIEW posexplode(list6) list6a AS rk6,sim1_1
          |lateral VIEW posexplode(list7) list7a AS rk7,sim5_1
          |lateral VIEW posexplode(list8) list8a AS rk8,pns_dist
          |lateral VIEW posexplode(list9) list9a AS rk9,pns_time
          |lateral VIEW posexplode(list10) list10a AS rk10,line_distance_std
          |lateral VIEW posexplode(list11) list11a AS rk11,line_time_std
          |lateral VIEW posexplode(list12) list12a AS rk12,std_id2
          |lateral VIEW posexplode(list13) list13a AS rk13,conduct_type2
          |lateral VIEW posexplode(list14) list14a AS rk14,sim1_2
          |lateral VIEW posexplode(list15) list15a AS rk15,sim5_2
          |lateral VIEW posexplode(list16) list16a AS rk16,conduct_order
          |lateral VIEW posexplode(list17) list17a AS rk17,navi_stdid
          |lateral VIEW posexplode(list18) list18a AS rk18,conduct_type_final
          |lateral VIEW posexplode(list19) list19a AS rk19,sim1_navi
          |lateral VIEW posexplode(list20) list20a AS rk20,sim5_navi
          |lateral VIEW posexplode(list21) list21a AS rk21,is_navi
          |lateral VIEW posexplode(list22) list22a AS rk22,line_id
          |lateral VIEW posexplode(list23) list23a AS rk23,line_order
          |lateral VIEW posexplode(list24) list24a AS rk24,line_type
          |lateral VIEW posexplode(list25) list25a AS rk25,subtask_navi_yaw
          |lateral VIEW posexplode(list26) list26a AS rk26,line_sim1_1
          |lateral VIEW posexplode(list27) list27a AS rk27,line_sim5_1
          |lateral VIEW posexplode(list28) list28a AS rk28,line_sim1_2
          |lateral VIEW posexplode(list29) list29a AS rk29,line_sim5_2
          |lateral VIEW posexplode(list30) list30a AS rk30,line_cond
          |lateral VIEW posexplode(list31) list31a AS rk31,line_cond2

          | where rk0=rk1
          | and rk0=rk2
          |and rk0=rk3
          |and rk0=rk4
          |and rk0=rk5
          |and rk0=rk6
          |and rk0=rk7
          |and rk0=rk8
          |and rk0=rk9
          |and rk0=rk10
          |and rk0=rk11
          |and rk0=rk12
          |and rk0=rk13
          |and rk0=rk14
          |and rk0=rk15
          |and rk0=rk16
          |and rk0=rk17
          |and rk0=rk18
          |and rk0=rk19
          |and rk0=rk20
          |and rk0=rk21
          |and rk0=rk22
          |and rk0=rk23
          |and rk0=rk24
          |and rk0=rk25
          |and rk0=rk26
          |and rk0=rk27
          |and rk0=rk28
          |and rk0=rk29
          |and rk0=rk30
          |and rk0=rk31

          |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK)
      .withColumn("std_id1",$"std_id")
      //空值填-1
      .withColumn("conduct_type_final2",when($"conduct_type_final2".isNull || $"conduct_type_final2"==="-","-1").otherwise($"conduct_type_final2"))
      //空值填-
      .withColumn("navi_stdid",when($"navi_stdid".isNull || $"navi_stdid"==="-","-").otherwise($"navi_stdid"))
      //空值填-1
      .withColumn("conduct_type_final",when($"conduct_type_final".isNull || $"conduct_type_final"==="-","-1").otherwise($"conduct_type_final"))
      //空值填-1
      .withColumn("sim1_navi",when($"sim1_navi".isNull || $"sim1_navi"==="-","-1").otherwise($"sim1_navi"))
      //空值填-1
      .withColumn("sim5_navi",when($"sim5_navi".isNull || $"sim5_navi"==="-","-1").otherwise($"sim5_navi"))
      //空值填-1
      .withColumn("is_navi",when($"is_navi".isNull || $"is_navi"==="-","-1").otherwise($"is_navi"))

//      val result_data2=result_data1.select("task_subid","std_id2","std_id","sort_num")
//        .withColumn("std_id_tmp",$"std_id2")
//        .withColumn("conduct_order2",$"sort_num")
//        .select("task_subid","conduct_order2","std_id_tmp")

    val result_data3=result_data1
      .withColumn("conduct_order2",when(trim($"conduct_order")==="-","-1").otherwise($"conduct_order"))
      // .join(result_data2,Seq("task_subid","conduct_order2"),"left")
      .withColumn("navi_stdid",when($"navi_stdid".isNull || trim($"navi_stdid")==="","-").otherwise($"navi_stdid"))
      .withColumn("conduct_type_final",when($"conduct_type_final".isNull || trim($"conduct_type_final")==="","-1").otherwise($"conduct_type_final"))
      .withColumn("sim1_navi",when($"sim1_navi".isNull || trim($"sim1_navi")==="","-1").otherwise($"sim1_navi"))
      .withColumn("sim5_navi",when($"sim5_navi".isNull || trim($"sim5_navi")==="","-1").otherwise($"sim5_navi"))
      .withColumn("is_navi",when($"is_navi".isNull || trim($"is_navi")==="","-1").otherwise($"is_navi"))
      //20231221 V4.6 修改 conduct_type conduct_order std_id 计算逻辑
      .withColumn("conduct_type", when($"subtask_navi_yaw" === "1" && $"conduct_type1" =!= "1" && $"conduct_type2" =!= "1", "2").
        when($"conduct_type1" === "1" || $"conduct_type2" === "1", "1").
        otherwise("3"))
      .withColumn("conduct_order", when($"conduct_type1" === "1", get_conduct_order_udf($"line_type", $"line_order")).
        when($"conduct_type2" === "1", $"conduct_order2").
        otherwise("1"))
      .withColumn("line_id_tmp", get_std_id_udf($"line_id"))  //辅助字段
      .withColumn("std_id2_tmp", get_std_id_udf($"std_id2"))  //辅助字段
      .withColumn("std_id", when($"conduct_type1" === "1", $"std_id1").
        when($"conduct_type2" === "1", split($"std_id2", ",")($"conduct_order2".cast("int") - 1)).
        otherwise(when($"line_id_tmp" =!= "-", $"line_id_tmp").
          when($"std_id2_tmp" =!= "-", $"std_id2_tmp").
          otherwise("-")))

      //20240221 V5.0 修改 sim1_1和sim5_1和sim1_2和 sim5_2 赋值逻辑
      .withColumn("sim1_1", get_line_sim_udf($"line_sim1_1", $"line_order", $"conduct_type1"))
      .withColumn("sim5_1", get_line_sim_udf($"line_sim5_1", $"line_order", $"conduct_type1"))
      .withColumn("sim1_2", get_line_sim_udf($"line_sim1_2", $"line_order", $"conduct_type2"))
      .withColumn("sim5_2", get_line_sim_udf($"line_sim5_2", $"line_order", $"conduct_type2"))

      .withColumn("sim1",when($"conduct_type1"==="1",$"sim1_1").
        when($"conduct_type1"=!="1" && $"conduct_type2"==="1",$"sim1_2").
        when($"sim1_1" === "-",$"sim1_2").
        otherwise($"sim1_1"))
      .withColumn("sim5",when($"conduct_type1"==="1",$"sim5_1").
        when($"conduct_type1"=!="1" && $"conduct_type2"==="1",$"sim5_2").
        when($"sim5_1" === "-", $"sim5_2").
        otherwise($"sim5_1"))

      .withColumn("inc_day",lit(dayvar))

    //存储dm表,每天增量存储
    val table_cols = spark.sql("""select * from dm_gis.eta_std_line_recall_realtime2_overstop limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, result_data3.select(table_cols: _*) , Seq("inc_day"), "dm_gis.eta_std_line_recall_realtime2_overstop")

    spark.close()
  }

  //获取sim1_1 sim5_1 sim1_2 sim5_2
  def get_line_sim(line_sim: String,line_order: String,conduct_type: String): String = {
    var ret = "-"
    try {
      val line_order_idx = line_order.toInt
      val line_sim_arr = line_sim.split("&")

      if (conduct_type.equals("1") && line_sim_arr.length >= line_order_idx) {
        ret = line_sim_arr(line_order_idx - 1)
      }else if (conduct_type.equals("3")) {
        for (i <- 0 until line_sim_arr.length) {
          val line_sim_tmp = line_sim_arr(i)
          if (!"-".equals(line_sim_tmp)) {
            ret = line_sim_tmp
            return ret
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }
  val get_line_sim_udf = udf(get_line_sim _)

  //获取std_id
  def get_std_id(line_id: String): String = {
    var ret = "-"
    val line_id_arr = line_id.split(",")
    for (i <- 0 until line_id_arr.size) {
      val line_id_tmp = line_id_arr(i)
      if (!"-".equals(line_id_tmp)) {
        ret = line_id_tmp
        return ret
      }
    }
    ret
  }
  val get_std_id_udf = udf(get_std_id _)

  //获取conduct_order
  def get_conduct_order(line_type: String, line_order: String): String = {
    var ret = "1"
    val line_type_arr = line_type.split(",")
    try {
      val order_num = line_order.toInt - 1
      if (line_type_arr.size > order_num && order_num >= 0) {
        var idx = 0
        for (i <- 0 until line_type_arr.size) {
          val `type` = line_type_arr(i)
          val order_type = line_type_arr(order_num)

          if ("carrierStdLineDataList".equals(`type`)) {
            idx += 1
            if ("carrierStdLineDataList".equals(order_type) && order_num == i) {
              ret = idx.toString
              return ret
            }
          }
        }
      }
    } catch {
      case e: Exception => logger.error(">>>line_order类型转换异常")
    }
    ret
  }
  val get_conduct_order_udf = udf(get_conduct_order _)

  //x为有逗号隔开的std_id，y为序号
  def strsplit_std_id(x:String,y:Int): String ={
   val xarr=x.split(",")
    if(y-1<0){
      xarr(0)
    }
    else {
      xarr(y-1)
    }
  }

  val strsplit_std_id_udf=udf(strsplit_std_id _)

  //定义清洗字段：用|分割
  def clearnull_1(x:String): String ={
    val x_arr=x.split("\\|")
    val s=x_arr.size
    val strarr=new ArrayBuffer[String]()
    for (i<-0 until s){
      val x_i="-"
      strarr.append(x_i)
    }
    strarr.mkString("|")
  }

  val clearnull_1_udf=udf(clearnull_1 _)

  //定义清洗字段：用;分割
  def clearnull_2(x:String): String ={
    val x_arr=x.split("\\|")
    val s=x_arr.size
    val strarr=new ArrayBuffer[String]()
    for (i<-0 until s){
      val x_i="-"
      strarr.append(x_i)
    }
    strarr.mkString(";")
  }

  val clearnull_2_udf=udf(clearnull_2 _)

  //定义清洗字段：用|分割
  def clearnull_3(x:String,y:String): String ={
    //计算task_subid长度，用于比较长度和填充空值
    val x_arr=x.split("\\|")
    val s=x_arr.size
    val strarr=new ArrayBuffer[String]()
    for (i<-0 until s){
      val x_i="-"
      strarr.append(x_i)
    }
    //判断目前字段
    val y_arr=y.split("\\|")
    val s_y=y_arr.size

    if(s==s_y){
      return y
    }
    else{
      strarr.mkString("|")
    }
  }

  val clearnull_3_udf=udf(clearnull_3 _)

  //定义清洗字段：用；分割
  def clearnull_4(x:String,y:String): String ={
    //计算task_subid长度，用于比较长度和填充空值
    val x_arr=x.split("\\|")
    val s=x_arr.size
    val strarr=new ArrayBuffer[String]()
    for (i<-0 until s){
      val x_i="-"
      strarr.append(x_i)
    }
    //判断目前字段
    val y_arr=y.split(";")
    val s_y=y_arr.size

    if(s==s_y){
      return y
    }
    else{
      strarr.mkString(";")
    }
  }

  val clearnull_4_udf=udf(clearnull_4 _)

}
