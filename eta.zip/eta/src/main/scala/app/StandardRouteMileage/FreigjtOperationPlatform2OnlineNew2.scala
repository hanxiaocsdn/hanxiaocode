package app.StandardRouteMileage

import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger

import Utils._
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.eta.constant.utils.HttpClientUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import com.sf.gis.java.eta.constant.utils
object FreigjtOperationPlatform2OnlineNew2 {

  @transient lazy val logger: Logger = Logger.getLogger(FreigjtOperationPlatform2OnlineNew2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    val inc_day = "20211030"
    //val inc_day = "20210901"
    //logger.error("20210803")
    start(inc_day)

  }


  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("local[6]")
//      .enableHiveSupport()
//      .config("hive.exec.dynamic.partition", true)
//      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    startSta(spark, inc_day)
    logger.error("统计结束")
  }


  def getFtDistTime(spark: SparkSession, inc_day: String) = {

    val ftDistTimeTabel = "eta_route_plan_res2"

    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.${ftDistTimeTabel}
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val ftDistTimeDF = spark.sql(sql)
    val colList = ftDistTimeDF.columns
    val ftDistTimeRdd = ftDistTimeDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns, x.getAs[String](columns))
      }
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    ftDistTimeRdd
  }

  def saveTableHistoryOntimeDept(spark: SparkSession, inc_day: String, ontimeRateRdd: RDD[JSONObject]) = {

    import spark.implicits._

    val ontimeDf = ontimeRateRdd.map(x => {
      //val line_code = JSONUtils.getJsonValue(x,"line_code","")
      val start_time = JSONUtils.getJsonValue(x, "start_time", "")
      val start_dept = JSONUtils.getJsonValue(x, "start_dept", "")
      val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
      val vehicle_type = JSONUtils.getJsonValue(x, "vehicle_type", "")
      val time_p8 = JSONUtils.getJsonValue(x, "time_p8", "")
      val time_p9 = JSONUtils.getJsonValue(x, "time_p9", "")
      val his_ontime_rate = JSONUtils.getJsonValue(x, "his_ontime_rate", "")
      val ontime80Ratio = JSONUtils.getJsonValue(x, "ontime80Ratio", "")
      val ontime90Ratio = JSONUtils.getJsonValue(x, "ontime90Ratio", "")
      val groupCnt = JSONUtils.getJsonValue(x, "groupCnt", "")
      val dist_p8 = JSONUtils.getJsonValue(x, "dist_p8", "")
      val dist_p9 = JSONUtils.getJsonValue(x, "dist_p9", "")
      val inc_day_new = inc_day
      HistoryOntimeDept(start_time, start_dept, end_dept, vehicle_type, time_p8, time_p9, his_ontime_rate.toString, ontime80Ratio, ontime90Ratio, groupCnt, dist_p8, dist_p9, inc_day_new)

    }).toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_history_dist_time_8090")


  }

  def saveTableSchemeRoute(spark: SparkSession, inc_day: String, schemeRouteRdd: RDD[JSONObject]) = {
    import spark.implicits._
    schemeRouteRdd.map(x => {

      //line_code
      val plan_date = x.getString("plan_date")
      val start_time = x.getString("start_time")
      val line_code = x.getString("line_code")
      val src_dept = x.getString("src_dept")
      val dest_dept = x.getString("dest_dept")
      val vehicle = x.getString("vehicle")
      val height = x.getString("height")
      val axle_weight = x.getString("axle_weight")
      val axle_number = x.getString("axle_number")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")

      val vehicle_color = x.getString("vehicle_color")
      val energy = x.getString("energy")
      val width = x.getString("width")
      val length = x.getString("length")
      val passport = x.getString("passport")
      val emitStand = ""
      val rt_status = x.getString("rt_status")
      val rt_dist = x.getString("rt_dist")
      val rt_time = JSONUtils.getJsonValueInt(x, "rt_time", 0)
      val rt_tolls = x.getString("rt_tolls")
      val rt_coords = x.getString("rt_coords")
      val rt_src = x.getString("rt_src")
      val rt_flen = x.getString("rt_flen")
      val rt_tlen = x.getString("rt_tlen")
      val rt_plan_order = x.getString("rt_plan_order")
      val data_source = x.getString("data_source")
      val rt_url = x.getString("rt_url")
      //2.25日新增
      val task_area_code = x.getString("task_area_code")
      val rt_highway = x.getString("rt_highway")
      val rt_traLightCount = x.getString("rt_traLightCount")
      val line_distance = x.getString("line_distance")
      val line_time = x.getString("line_time")
      val rt_tollsDistance = try {
        JSONUtils.getJsonValueInt(x, "rt_tollsDistance", 0) / 1000
      } catch {
        case e: Exception => 0
      }

      val gdErrLog = x.getString("gdErrLog")
      val jyErrLog = x.getString("jyErrLog")
      val ctErrLog = x.getString("ctErrLog")

      res2(line_code, start_dept, end_dept, vehicle_type, height, axle_weight, axle_number, vehicle, vehicle_color, energy,
        width, length, passport, emitStand, plan_date, rt_status, rt_dist, rt_time.toString, rt_highway, rt_traLightCount, rt_tolls,
        rt_tollsDistance.toString, rt_src, rt_url, rt_flen, rt_tlen, rt_coords, rt_plan_order, data_source, task_area_code, start_time, gdErrLog, jyErrLog, ctErrLog, inc_day)

    }).toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_route_plan_middle2")
  }

  def saveTableIntersect(spark: SparkSession, inc_day: String, trajIntersectRddPre: RDD[JSONObject]) = {

    import spark.implicits._

    val trajIntersectRdd = trajIntersectRddPre.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = JSONUtils.getJsonValueInt(x, "vehicle_type", 6).toString
      val axle_number = JSONUtils.getJsonValueInt(x, "axle_number", 2).toString
      val order_source = x.getString("order_source")
      val task_area_code = x.getString("task_area_code")
      val rt_dist = x.getString("rt_dist")
      val tolls = JSONUtils.getJsonValue(x, "rt_tolls", x.getString("tolls"))
      val rt_coords = x.getString("rt_coords")
      val data_source = x.getString("data_source")
      val rt_url = x.getString("rt_url")
      val rt_time = x.getString("rt_time")
      val sim_group = x.getString("sim_group")
      val month_freq = x.getString("month_freq")
      val rt_src = x.getString("rt_src")
      res3(start_time, start_dept, end_dept, vehicle_type, axle_number, order_source, rt_dist, tolls, rt_coords, data_source,
        rt_url, rt_time, sim_group, month_freq, task_area_code, rt_src, inc_day)
    })

    val trajInterDf = trajIntersectRdd.toDF().persist()
    //trajInterDf.show(false)
    trajInterDf.write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_traj_intersect_new")

  }

  def groupFormat(groupSimRdd: RDD[JSONObject]) = {

    val unVerifyRdd = groupSimRdd.map(x => {

      var vehicle_type_new = 6
      var axle_number = 2
      if (!StringUtils.nonEmpty(x.getString("vehicle_type"))) {
        val vehicle_type = JSONUtils.getJsonValueDouble(x, "vehicle_type", 0.0)

        vehicle_type_new = vehicle_type match {
          case vehicle_type if (vehicle_type <= 1.0) => 5
          case vehicle_type if (vehicle_type > 1.0 && vehicle_type < 3.0) => 6
          case vehicle_type if (vehicle_type >= 3.0 && vehicle_type < 7.0) => 7
          case vehicle_type if (vehicle_type >= 7.0) => 8
        }

        axle_number = vehicle_type match {
          case vehicle_type if (vehicle_type >= 0 && vehicle_type <= 9.5) => 2
          case vehicle_type if (vehicle_type > 9.5 && vehicle_type <= 14) => 3
          case vehicle_type if (vehicle_type > 14 && vehicle_type <= 20) => 4
          case vehicle_type if (vehicle_type > 20 && vehicle_type <= 25) => 5
          case vehicle_type if (vehicle_type >= 25) => 6
        }
        x.put("vehicle_type", vehicle_type)
        x.put("axle_number", axle_number)
      } else {
        val car_type = x.getString("car_type")
        if ("厢式运输车".equals(car_type)) {
          vehicle_type_new = 8
          axle_number = 4
        }
      }
      x.put("vehicle_type", vehicle_type_new)
      x.put("axle_number", axle_number)

      x
    })
    unVerifyRdd

  }


  def getGroupSimNew(spark: SparkSession, inc_day: String, groupSimRdd: RDD[JSONObject], markUnVerifyRdd: RDD[JSONObject]) = {
    val leftRdd = groupSimRdd.map(x => {
      //(start_dept,end_dept,start_time
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val start_time = x.getString("start_time")

      ((start_dept, end_dept, start_time), x)
    })

    val rightRdd = markUnVerifyRdd.map(x => {
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val start_time = x.getString("start_time")
      val vehicle_type = x.getString("vehicle_type")

      ((start_dept, end_dept, start_time), x)
    }).reduceByKey((obj1, obj2) => obj1)

    val returnRdd = leftRdd.leftOuterJoin(rightRdd).map(x => {

      val left = x._2._1
      val rightOption = x._2._2

      if (!rightOption.isEmpty) {
        val vehicle_type = rightOption.get.getString("vehicle_type")
        val axle_number = rightOption.get.getString("axle_number")
        left.put("vehicle_type", vehicle_type)
        left.put("axle_number", axle_number)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    returnRdd

  }

  def getlabelTable(spark: SparkSession, inc_day: String): RDD[JSONObject] = {

    val sql =
      s"""
         |select info
         |from
         |  dm_gis.eta_routeplan_labeldata_info
         |where
         |  inc_day='${inc_day}'
       """.stripMargin

    val frame = spark.sql(sql).rdd.map(x => {
      val json = JSON.parseObject(x.mkString(""))
      json
    })

    val frameTest = frame.filter(x => {
      val line_code = x.getString("line_code")
      line_code == "371WB371FP1200"
    })

    frameTest
    //    frame
  }


  def filterLable(spark: SparkSession, inc_day: String, labelData: RDD[JSONObject]) = {

    // TODO:  过滤发车时间范围7天的数据

    //    DateTimeUtil.transformDateFormat(inc_day,"yyyyMMdd","yyyy-MM-dd")

    val inc_day = "20211101"
    val start_day = "2021-11-03"
    val end_day = "2021-11-09"
    val sourceSql =
      s"""
         |
         |select
         |  *,
         |  regexp_replace(substring(plan_depart_tm, 12, 5), ':', '') as start_time
         |from
         |  (
         |    select
         |      lag(aa.dept_code, 1) over(
         |        PARTITION BY aa.id
         |        order by
         |          aa.docking_sequence
         |      ) start_dept,
         |      dept_code end_dept,
         |      distance as line_distance,
         |      times as line_time,
         |      line_code,
         |      cvy_name,
         |      line_belongs_code as task_area_code,
         |      id,
         |      docking_sequence as sort_num,
         |      arrive_tm as plan_arrive_tm,
         |      arrive_batch plan_arrive_batch,
         |      lag(aa.send_batch, 1) over(
         |        PARTITION BY aa.id
         |        order by
         |          aa.docking_sequence
         |      ) send_batch,
         |      lag(aa.send_tm, 1) over(
         |        PARTITION BY aa.id
         |        order by
         |          aa.docking_sequence
         |      ) plan_depart_tm,
         |      lag(aa.latest_arrival_tm, 1) over(
         |        PARTITION BY aa.id
         |        order by
         |          aa.docking_sequence
         |      ) last_arrive_tm,
         |      job_type
         |    from
         |      (
         |        select
         |          a.id,
         |          a.line_code,
         |          a.cvy_name,
         |          a.line_belongs_code,
         |          b.dept_code,
         |          b.docking_sequence,
         |          b.latest_arrival_tm,
         |          b.arrive_tm,
         |          b.arrive_batch,
         |          b.send_tm,
         |          b.send_batch,
         |          b.distance,
         |          b.times,
         |          b.job_type
         |        from
         |          (
         |            select
         |              id,
         |              omcs_line_code as line_code,
         |              cvy_name,
         |              line_belongs_code
         |            from
         |              dm_pass_rss.scha_tt_plan_main_pro
         |            where
         |              inc_day = '${inc_day}'   --inc_day
         |              and oper_type in (1, 2)
         |              and status != 3
         |              and plan_run_dt >= '${start_day}'   --date1
         |              and plan_run_dt <= '${end_day}'   --date2
         |          ) a
         |          inner join (
         |            select
         |              plan_main_id,
         |              dept_code,
         |              docking_sequence,
         |              latest_arrival_tm,
         |              arrive_tm,
         |              arrive_batch,
         |              send_tm,
         |              send_batch,
         |              distance,
         |              times,
         |              job_type,
         |              point_type
         |            from
         |              dm_pass_rss.scha_tt_plan_point_pro
         |            where
         |              inc_day = '${inc_day}'    --inc_day
         |              and plan_run_dt >= '${start_day}'  --date1
         |              and plan_run_dt <= '${end_day}'  --date2
         |          ) b on a.id = b.plan_main_id
         |        order by
         |          id,
         |          docking_sequence
         |      ) aa
         |  ) bb
         |where
         |  bb.start_dept is not null
       """.stripMargin


    val sourceDf = spark.sql(sourceSql)

    val sourceRdd= SparkUtils.getRowToJson(sourceDf)



    val filterRdd = SparkUtils.getRowToJson(sourceDf).map(x => {
      //去重
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val line_code = JSONUtils.getJsonValue(x,"line_code","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")
      val line_time = JSONUtils.getJsonValue(x,"line_time","")
      val plan_depart_tm = JSONUtils.getJsonValue(x,"plan_depart_tm","")

      ((start_dept,end_dept,line_code,start_time,line_time,plan_depart_tm),x)

    }).reduceByKey((obj1,obj2) => obj1).map(_._2)
      .map(x => {
        // 始发网点+目的网点+线路编码+发车时间

        val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
        val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
        val line_code = JSONUtils.getJsonValue(x,"line_code","")
        val start_time = JSONUtils.getJsonValue(x,"start_time","")

        ((start_dept,end_dept,line_code,start_time),x)
      })

    val labelFilterRdd = labelData.map(x => {


      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val line_code = JSONUtils.getJsonValue(x,"line_code","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")

      ((start_dept,end_dept,line_code,start_time),x)
    }).join(filterRdd).map(x => {

      val left = x._2._1
      val right = x._2._2
      val task_area_code = JSONUtils.getJsonValue(right,"task_area_code","")
      val plan_arrive_tm = JSONUtils.getJsonValue(right,"plan_arrive_tm","")
      val plan_depart_tm = JSONUtils.getJsonValue(right,"plan_depart_tm","")
      val plan_arrive_batch = JSONUtils.getJsonValue(right,"plan_arrive_batch","")
      val line_distance = JSONUtils.getJsonValue(right,"line_distance","")
      val line_time = JSONUtils.getJsonValue(right,"line_time","")

      val work_day = try {DateTimeUtil.judgeWeekDay(plan_arrive_tm,"yyyy-MM-dd HH:mm:ss")} catch {case e:Exception => 1}

      left.put("task_area_code",task_area_code)
      left.put("plan_arrive_tm",plan_arrive_tm)
      left.put("work_day",work_day)
      left.put("plan_depart_tm",plan_depart_tm)
      left.put("plan_arrive_batch",plan_arrive_batch)
      left.put("line_distance",line_distance)
      left.put("line_time",line_time)

      left

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("关联之后的数据量为：" + labelFilterRdd.count())


    labelFilterRdd


  }

  def startSta(spark: SparkSession, inc_day: String): Unit = {

    //    logger.error("获取日志")
    //    val groupSimRdd = getGroupSim(spark, inc_day)
    //    logger.error("groupSimRdd数据量为：" + groupSimRdd.count())
    //    groupSimRdd.take(2).foreach(println(_))
    //    val groupSimFormatRdd = groupFormat(groupSimRdd)
    //
    //
    //    //获取待验证数据和规划准备数据
    //    val (getUndefineRdd, middle0DF, middle1DF) = getUndefineData(spark, inc_day)
    //    logger.error("待验证数据量为：" + getUndefineRdd.count())
    //
    //    logger.error("标记待验证数据")
    //    val markUnVerifyRdd = markUnVerify(getUndefineRdd)
    //    logger.error("待验证数据量为：" + markUnVerifyRdd.count())
    //    markUnVerifyRdd.take(2).foreach(println(_))
    //
    //
    //    //根据待验证数据，将vehicle_type挂接回groupsim
    //    val grouSimNewRdd = getGroupSimNew(spark, inc_day, groupSimRdd, markUnVerifyRdd)
    //
    //    //计算时效、准点率
    //    logger.error("开始计算准点率")
    //    val ontimeRateRdd = calOntimeRate(middle0DF, middle1DF, inc_day)
    //
    //    logger.error("时效准点率数据量为：" + ontimeRateRdd.count())
    //    ontimeRateRdd.take(2).foreach(println(_))
    //    saveTableHistoryOntimeDept(spark, inc_day, ontimeRateRdd)
    //    //
    //    //            logger.error("开始计算准点率")
    //    //            val ontimeRateRdd = getOnTimeRateRdd(spark,inc_day)
    //    //            logger.error("准点率数据量为" + ontimeRateRdd.count())
    //    //规划线路 高德 经验
    //    logger.error("开始规划线路 高德 经验 传统")
    //    val schemeRouteRdd = schemaRoute(spark, inc_day, markUnVerifyRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("规划线路数据量为：" + schemeRouteRdd.count())
    //    schemeRouteRdd.take(2).foreach(println(_))
    //    saveTableSchemeRoute(spark, inc_day, schemeRouteRdd)
    //
    //    //    val schemeRouteRdd = getSchemeRoute(spark,inc_day)
    //    //    logger.error("获取规划轨迹路线数量为：" + schemeRouteRdd.count())
    //
    //    //计算轨迹交集
    //    logger.error("开始计算轨迹交集")
    //    val trajIntersectRddPre = calTrajIntersect(grouSimNewRdd, schemeRouteRdd)
    //    logger.error("轨迹交集的数据量为：" + trajIntersectRddPre.count())
    //    trajIntersectRddPre.take(2).foreach(println(_))
    //
    //    saveTableIntersect(spark, inc_day, trajIntersectRddPre)
    //    schemeRouteRdd.unpersist()
    //
    //    logger.error("获取轨迹交集")
    //    val trajIntersectRddNew = getTrajIntersect(spark, inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("trajIntersectRdd轨迹交集的数据量为：" + trajIntersectRddNew.count())
    //    trajIntersectRddNew.take(2).foreach(println(_))
    //
    //    //各车型时效里程
    //    logger.error("开始各车型时效里程计算")
    //    val ftDistTimeRdd = calFtDistTime(trajIntersectRddNew).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("时效里程数据量为：" + ftDistTimeRdd.count())
    //    ftDistTimeRdd.take(2).foreach(println(_))
    //    saveTableToRes2(spark, inc_day, ftDistTimeRdd)
    //    trajIntersectRddNew.unpersist()
    //
    //    //获取时效里程
    //    //    val ftDistTimeRdd = getFtDistTime(spark,inc_day)
    //    //    logger.error("ftDistTimeRdd数据量为" + ftDistTimeRdd.count())
    //
    //    //获取标准里程，标准时效
    //    val standardTimeEffect = getTimeEffect(spark, inc_day, ontimeRateRdd, markUnVerifyRdd)
    //    logger.error("标准时效数据量为：" + standardTimeEffect.count())
    //    standardTimeEffect.take(2).foreach(println(_))
    //
    //    val standardDistEffect = getDistEffect(spark, inc_day, ftDistTimeRdd, standardTimeEffect)
    //    logger.error("标准里程数据量为：" + standardDistEffect.count())
    //    standardDistEffect.take(2).foreach(println(_))
    //
    //    //标记数据
    //    logger.error("开始标记数据")
    //    val labelData = getLabelData(standardDistEffect)
    //    logger.error("标记数据量为：" + labelData.count())
    //    labelData.take(2).foreach(println(_))
    //
    //    import spark.implicits._
    //    import org.apache.spark.sql.functions._
    //    logger.error("存入labelData明细表")
    //    labelData.map(x => {
    //      x.toJSONString
    //    }).repartition(100).toDF().withColumn("inc_day", lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_routeplan_labeldata_info")

//    val labelData = getlabelTable(spark,inc_day)
//    logger.error("标记数据量为：" + labelData.count())
//    labelData.take(2).foreach(println(_))

//    val labelDataStr = "{\"ft_time\":80.0,\"vehicle_color\":\"\",\"dist_flag\":\"里程配置偏少超5%\",\"trans_car\":\"外包\",\"rt_coords\":\"[]\",\"sim_group\":\"0\",\"plan_arrive_batch\":\"371FP03D\",\"tolls\":\"30.0\",\"car_type\":\"厢式运输车\",\"ontime80Ratio\":0.9545454545454546,\"full_loadweight\":\"\",\"pass_zone_code\":\"371FP\",\"line_distance\":\"45.32\",\"to_ground\":\"是\",\"dest_zone_name\":\"茂花路速运营业点\",\"is_stop_over\":\"直发\",\"height\":\"\",\"energy\":\"\",\"scoreAll\":90,\"group_dist_min\":40.076,\"dist_p9\":42.922,\"line_require_type\":\"计划\",\"dist_p8\":41.922,\"gdTag\":0,\"ref_speed\":56.83,\"axle_weight\":\"\",\"data_source\":\"ct\",\"his_ontime_rate\":0.9545454545454546,\"start_time\":\"1200\",\"line_code\":\"371WB371FP1200\",\"res_abnormal\":\"2|\",\"ontime90Ratio\":1.0,\"start_dept\":\"371WB\",\"time_flag\":\"时效不足超5分钟\",\"x1\":\"113.839994\",\"x2\":\"113.678012192\",\"src_zone_name\":\"郑州港区中转场\",\"own_dept_code\":\"371Y\",\"month_freq\":\"0\",\"job_type\":2,\"ctTag\":90,\"pass_id\":\"\",\"rt_time\":\"80\",\"flag\":\"\",\"groupCnt\":22,\"line_time\":70,\"plan_date\":\"20211108120000\",\"vehicle\":\"\",\"end_dept_out\":\"371FP\",\"actual_arrive_tm\":\"2021-10-23 13:11:23\",\"ft_coords\":\"[]\",\"time_p9\":80,\"time_p8\":75,\"y1\":\"34.579041\",\"cvy_name\":\"郑港茂花路1200（常规-直分）\",\"y2\":\"34.80185421\",\"ft_tolls\":\"30.0\",\"start_dept_out\":\"371WB\",\"plan_send_batch\":\"371WB0830\",\"line_require_id\":\"211023157074149\",\"ft_dist\":\"75.776\",\"rt_dist\":\"75.776\",\"is_match\":\"1\",\"full_load_weight\":\"3.0\",\"ft_url\":\"http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=2&cc=1&merge=4&etype=2&opt=sf2&rarefy=0&frequency=1&axleNumber=2&x1=113.839994&y1=34.579041&x2=113.678012192&y2=34.80185421&vehicle=7&planDate=20211108120000&passport=100000&tolls=1\",\"src_area_code\":\"999Y\",\"task_area_code\":\"999Y\",\"length\":\"\",\"actual_depart_tm\":\"2021-10-23 12:02:28\",\"vehicle_type\":\"7\",\"rt_url\":\"http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=2&cc=1&merge=4&etype=2&opt=sf2&rarefy=0&frequency=1&axleNumber=2&x1=113.839994&y1=34.579041&x2=113.678012192&y2=34.80185421&vehicle=7&planDate=20211108120000&passport=100000&tolls=1\",\"axle_number\":\"2\",\"gjTag\":0,\"last_update_tm\":\"2021-10-30 17:51:08\",\"transoport_level\":\"3\",\"plan_arrive_tm\":\"2021-10-23 13:10:00\",\"work_day\":\"1234567\",\"sort_num\":2,\"width\":\"\",\"order_source\":\"ct\",\"inc_day\":\"20211030\",\"end_dept\":\"371FP\",\"require_category\":\"常规线路\",\"plan_depart_tm\":\"2021-10-23 12:00:00\",\"dest_area_code\":\"371Y\",\"rt_src\":\"rp-my\",\"dataSourceIndex\":3}"
//    val json = JSON.parseObject(labelDataStr)
//    val labelData = spark.sparkContext.parallelize(List(json))
//    labelData.take(2).foreach(println(_))
//
//
//    //    val labelDataNew = filterLable(spark,inc_day,labelData)
//
//    val addBatchTag = addBatch(spark, labelData, inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("增加跨班次统计数据量为：" + addBatchTag.count())
//    addBatchTag.take(2).foreach(println(_))

    val batchAllTb = getbatchAllTb(spark, inc_day)


    //saveTableToMiddle3(spark, addBatchTag, inc_day)

  }


  def saveTableToMiddle3(spark: SparkSession, addBatchTag: RDD[JSONObject], inc_day: String): Unit = {

    import spark.implicits._

    logger.error("存表输入的addBatchTag数据量为：" + addBatchTag.count())
    addBatchTag.take(2).foreach(println(_))

    val inc_day = "20211101"

    //    val (start_day, end_day) =
    //      if (inc_day.endsWith("8")) {
    //        DateTimeUtil.getMonthBeginEnd(inc_day, "yyyyMMdd")
    //      } else {
    //        DateTimeUtil.getMonthMidBeginEnd(inc_day, "yyyyMMdd")
    //      }

    val (start_day, end_day) = ("20211101", "20211109")


    val addBatchRdd = addBatchTag.repartition(100).map(x => {

      val data_source = x.getString("data_source")
      val order_source = x.getString("order_source")
      val axle_number = x.getString("axle_number")
      val vehicle_type = x.getString("vehicle_type")
      val ft_time = x.getString("time_p9")
      val ft_dist = x.getString("ft_dist")
      val ft_coords = x.getString("rt_coords")
      val ft_url = x.getString("rt_url")
      val ft_tolls = x.getString("tolls")
      val time_p8 = x.getString("time_p8")
      //val p8_ontime_rate = x.getString("p8_ontime_rate")
      val p8_ontime_rate = x.getString("ontime80Ratio")
      val time_p9 = x.getString("time_p9")
      //val p9_ontime_rate = x.getString("p9_ontime_rate")
      val p9_ontime_rate = x.getString("ontime90Ratio")
      val his_ontime_rate = x.getString("his_ontime_rate")
      val dist_flag = x.getString("dist_flag")
      val time_flag = if (StringUtils.isEmpty(time_p9)) "" else x.getString("time_flag")
      val ref_speed = x.getString("ref_speed")
      val res_abnormal = x.getString("res_abnormal")
      val flag = x.getString("flag")
      val task_area_code = x.getString("task_area_code")
      val line_time = x.getString("line_time")

      val line_require_id = x.getString("line_require_id")
      val sort_num = x.getString("sort_num")
      val line_code = x.getString("line_code")
      val require_category = x.getString("require_category")
      val line_require_type = x.getString("line_require_type")
      val transoport_level = x.getString("transoport_level")
      val cvy_name = x.getString("cvy_name")
      val line_distance = x.getString("line_distance")
      val is_stop_over = x.getString("is_stop_over")
      val own_dept_code = x.getString("own_dept_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val start_dept_out = x.getString("start_dept_out")
      val end_dept_out = x.getString("end_dept_out")
      val full_load_weight = x.getString("full_load_weight")
      val car_type = x.getString("car_type")
      val src_dept_out = x.getString("src_dept_out")
      val dest_dept_out = x.getString("dest_dept_out")
      val plan_depart_tm = x.getString("plan_depart_tm")
      val plan_arrive_tm = x.getString("plan_arrive_tm")
      val start_time = x.getString("start_time")
      val plan_send_batch = x.getString("plan_send_batch")
      val plan_arrive_batch = x.getString("plan_arrive_batch")
      val actual_depart_tm = x.getString("actual_depart_tm")
      val actual_arrive_tm = x.getString("actual_arrive_tm")
      val last_update_tm = x.getString("last_update_tm")
      val to_ground = x.getString("to_ground")
      val pass_zone_code = x.getString("pass_zone_code")
      val last_arrive_tm = x.getString("last_arrive_tm")

      //增加跨班次统计
      val plan_arrive_time_last = if (x.getString("plan_arrive_time_last").compareTo("2021-01-01 08:00:00") > 0 && x.getString("plan_arrive_time_last").compareTo("9999-01-01 09:00:00") < 0) x.getString("plan_arrive_time_last") else ""
      val ft_arrive_time = x.getString("ft_arrive_time")
      val ft_arrive_time_last = if (x.getString("ft_arrive_time_last").compareTo("2021-01-01 08:00:00") > 0 && x.getString("ft_arrive_time_last").compareTo("9999-01-01 09:00:00") < 0) x.getString("ft_arrive_time_last") else ""
      val last_batch_code = x.getString("last_batch_code")
      val last_batch_last_tm = x.getString("last_batch_last_tm")
      val batch_st = x.getString("batch_st")

      val group_dist_min = x.getString("group_dist_min")

      //20210618添加
      val batch_type = x.getString("batch_type")
      val pass_id = x.getString("pass_id")
      val work_day = x.getString("work_day")
      val trans_car = x.getString("trans_car")
      val x1 = x.getString("x1")
      val y1 = x.getString("y1")
      val x2 = x.getString("x2")
      val y2 = x.getString("y2")

      var flagNew = ""
      if (StringUtils.nonEmpty(flag)) {
        val strings = flag.replaceAll(";", "·").split("·")
        val set = new mutable.HashSet[String]()
        for (i <- (0 until (strings.size))) {
          if (strings(i).nonEmpty) {
            set.add(strings(i))
          }
        }
        flagNew = set.mkString(";")
      }

      val rt_src = x.getString("rt_src")
      val is_match = x.getString("is_match")

      val job_type = x.getString("job_type")
      val src_area_code = x.getString("src_area_code")
      val dest_area_code = x.getString("dest_area_code")


      //20210810添加fetch_data_tm
      val fetch_data_tm = try {
        DateTimeUtil.transformDateFormat(end_day + " " + "08:00:00", "yyyyMMdd HH:mm:ss", "yyyy-MM-dd HH:mm:ss")
      }
      catch {
        case e: Exception => "9999-12-31 23:59:59"
      }

      // TODO: 20211109增加字段

      val plan_arrive_line_code = x.getString("plan_arrive_line_code")
      val plan_cvy_name = x.getString("plan_cvy_name")
      val ft_arrive_line_code = x.getString("ft_arrive_line_code")
      val ft_cvy_name = x.getString("ft_cvy_name")
      val plan_batch_code = x.getString("plan_batch_code")
      val ft_batch_code = x.getString("ft_batch_code")
      val add_time_max = x.getString("add_time_max")

      middleTable3(data_source, order_source, axle_number, vehicle_type, ft_time, ft_dist, ft_coords, ft_url, ft_tolls,
        time_p8, p8_ontime_rate, time_p9, p9_ontime_rate, his_ontime_rate, dist_flag, time_flag, ref_speed, res_abnormal,
        flagNew, task_area_code, line_time, line_require_id, sort_num, line_code, require_category, line_require_type, transoport_level,
        cvy_name, line_distance, is_stop_over, own_dept_code, start_dept, end_dept, start_dept_out, end_dept_out, full_load_weight,
        car_type, src_dept_out, dest_dept_out, plan_depart_tm, plan_arrive_tm, start_time, plan_send_batch, plan_arrive_batch, actual_depart_tm,
        actual_arrive_tm, last_update_tm, to_ground, pass_zone_code, last_arrive_tm, plan_arrive_time_last, ft_arrive_time, ft_arrive_time_last,
        last_batch_code, last_batch_last_tm, batch_st, group_dist_min, batch_type, pass_id, work_day, trans_car, x1, y1, x2, y2, rt_src,
        is_match, job_type, src_area_code, dest_area_code, fetch_data_tm,
        plan_arrive_line_code,plan_cvy_name,ft_arrive_line_code,ft_cvy_name,plan_batch_code,ft_batch_code,add_time_max,inc_day)
    })
    addBatchRdd.toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_route_plan_res3")
  }


  def getOnTimeRateRdd(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
    val intersectTabel = "dm_gis.eta_history_dist_time_8090"

    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_history_dist_time_8090
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val ontimeRateDF = spark.sql(sql)
    val colList = ontimeRateDF.columns
    val ontimeRateRdd = ontimeRateDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns, x.getAs[String](columns))
      }
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    ontimeRateRdd
  }


  def getTrajIntersect(spark: SparkSession, inc_day: String): RDD[JSONObject] = {
    val intersectTabel = "dm_gis.eta_traj_intersect"

    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_traj_intersect_new
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val intersectDF = spark.sql(sql)
    val colList = intersectDF.columns
    val intersectRdd = intersectDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns, x.getAs[String](columns))
      }
      jo
    })
    intersectRdd
  }


  def getSchemeRoute(spark: SparkSession, inc_day: String): RDD[JSONObject] = {

    val beginDay = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -30)
    val endDay = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 2)


    val sql =
      s"""
         |select
         |  *
         |from
         |dm_gis.eta_route_plan_middle2
         |where
         | inc_day >='${beginDay}'
         |and
         |  inc_day <='${inc_day}'
       """.stripMargin
    val routeDF = spark.sql(sql)
    val colList = routeDF.columns
    val routeRDD = routeDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns, x.getAs[String](columns))
      }
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    routeRDD
  }


  case class resTable2(start_dept: String, end_dept: String, axle_number: String, start_time: String,
                       vehicle_type: String, order_source: String, data_source: String, ft_dist: String,
                       ft_time: String, ft_coords: String, ft_tolls: String, ft_url: String, task_area_code: String, group_dist_min: String
                       , rt_src: String, score: String, originList: String, inc_day: String)


  case class res3(
                   start_time: String, start_dept: String, end_dept: String, vehicle_type: String, axle_number: String, order_source: String,
                   rt_dist: String, tolls: String, rt_coords: String, data_source: String, rt_url: String, rt_time: String,
                   sim_group: String, month_freq: String, task_area_code: String, rt_src: String, inc_day: String
                 )

  case class res4(
                   start_time: String, start_dept: String, end_dept: String, vehicle_type: String, axle_number: String, order_source: String,
                   data_source: String, ft_dist: String, ft_time: String, ft_coords: String, ft_url: String
                 )

  case class batch(
                    latest_arrival_tm: String, dept_code: String, batch_code: String, send_tm: String, inc_day: String, data_type: String,line_code:String,cvy_name:String
                  )


  case class middleTable3(
                           data_source: String, order_source: String, axle_number: String, vehicle_type: String, ft_time: String, ft_dist: String,
                           ft_coords: String, ft_url: String, ft_tolls: String, time_p8: String, p8_ontime_rate: String, time_p9: String, p9_ontime_rate: String,
                           his_ontime_rate: String, dist_flag: String, time_flag: String, ref_speed: String, res_abnormal: String, flag: String, task_area_code: String,
                           line_time: String, line_require_id: String, sort_num: String, line_code: String, require_category: String, line_require_type: String,
                           transoport_level: String, cvy_name: String, line_distance: String, is_stop_over: String, own_dept_code: String, start_dept: String,
                           end_dept: String, start_dept_out: String, end_dept_out: String, full_load_weight: String, car_type: String, src_dept_out: String,
                           dest_dept_out: String, plan_depart_tm: String, plan_arrive_tm: String, start_time: String, plan_send_batch: String, plan_arrive_batch: String,
                           actual_depart_tm: String, actual_arrive_tm: String, last_update_tm: String, to_ground: String, pass_zone_code: String, last_arrive_tm: String,
                           plan_arrive_time_last: String, ft_arrive_time: String, ft_arrive_time_last: String, last_batch_code: String, last_batch_last_tm: String,
                           batch_st: String, group_dist_min: String, batch_type: String, pass_id: String, work_day: String, trans_car: String, x1: String, y1: String, x2: String, y2: String,
                           rt_src: String, is_match: String, job_type: String, src_area_code: String, dest_area_code: String, fetch_data_tm: String,
                           plan_arrive_line_code:String,plan_cvy_name:String,ft_arrive_line_code:String,ft_cvy_name:String,plan_batch_code:String,ft_batch_code:String,add_time_max:String, inc_day: String
                         )

  case class res2(line_code: String, start_dept: String, end_dept: String, vehicle_type: String, height: String,
                  axle_weight: String, axle_number: String, vehicle: String, vehicle_color: String, energy: String,
                  width: String, length: String, passport: String, emitStand: String, plan_date: String, rt_status: String,
                  rt_dist: String, rt_time: String, rt_highway: String, rt_traLightCount: String, rt_tolls: String, rt_tollsDistance: String,
                  rt_src: String, rt_url: String, rt_flen: String, rt_tlen: String, rt_coords: String, rt_plan_order: String, data_source: String,
                  task_area_code: String, start_time: String, gdErrLog: String, jyErrLog: String, ctErrLog: String, inc_day: String)


  /** @note 调用GD轨迹接口 */
  private def scheduleGdTraj(axle_number: Int, x1: Double, y1: Double, x2: Double, y2: Double, vehicle_type: Int, planDate: String): (JSONObject, String) = {

    //val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&axleNumber=%s&fencedist=50&type=0&y1=22.912458&strategy=0&fixedroute=2&test=0&stype=0&planDate=202101171200&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&y2=23.216337&opt=gd3&vehicle=6&frequency=1&x2=113.108947&x1=113.95822&passport=100000&tolls=1"

    //val historyTrajUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=1&cc=1&merge=4&etype=2&opt=gd3&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val historyTrajUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=1&cc=1&merge=4&etype=2&opt=gd3&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val jo = new JSONObject()
    val url = String.format(historyTrajUrl.toString, axle_number.toString, x1.toString, y1.toString, x2.toString, y2.toString, vehicle_type.toString, planDate.toString)
    val response = Utils.retryGet(url)

    var err_log = ""
    try {

      // val response = Source.fromURL(url,"UTF-8").mkString
      if (StringUtils.nonEmpty(response)) {
        if (JSONUtils.isValidJSON(response)) {
          val response2 = JSON.parseObject(response)
          val rt_status = response2.getInteger("status")
          val result = response2.getJSONObject("result")

          val rt_dist = result.getInteger("dist").toDouble / 1000
          val rt_time = result.getInteger("time")
          val rt_tolls = JSONUtils.getJsonValueDouble(result, "tolls", 0.0)
          val rt_coords = result.getJSONArray("coords").toJSONString
          val rt_src = result.getString("src")
          val rt_flen = result.getInteger("flen")
          val rt_tlen = result.getInteger("tlen")
          val rt_tollsDistance = result.getInteger("tollsDistance")

          jo.put("rt_status", rt_status)
          jo.put("rt_dist", rt_dist)
          jo.put("rt_time", rt_time)
          jo.put("rt_tolls", rt_tolls)
          jo.put("rt_coords", rt_coords)
          jo.put("rt_src", rt_src)
          jo.put("rt_flen", rt_flen)
          jo.put("rt_tlen", rt_tlen)
          jo.put("rt_plan_order", 0)
          jo.put("data_source", "gd")
          jo.put("rt_url", url)
          jo.put("rt_tollsDistance", rt_tollsDistance)
        }
      }
    } catch {
      case e: Exception => err_log = e.getMessage + "请求url为：" + url + "response为：" + response
    }
    (jo, err_log)
  }

  /** @note 调用JY轨迹接口 */
  private def scheduleJYTraj(axle_number: Int, x1: Double, y1: Double, x2: Double, y2: Double, vehicle_type: Int, planDate: String): (JSONArray, String) = {

    //val historyTrajUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=6&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&opt=jy2&frequency=0&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val historyTrajUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=6&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&opt=jy2&frequency=0&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"


    val joArray = new JSONArray()
    val url = String.format(historyTrajUrl.toString, axle_number.toString, x1.toString, y1.toString, x2.toString, y2.toString, vehicle_type.toString, planDate.toString)
    val response = Utils.retryGet(url)

    var errLog = ""
    try {
      //val response = Source.fromURL(url,"UTF-8").mkString
      if (StringUtils.nonEmpty(response)) {
        if (JSONUtils.isValidJSON(response)) {
          val response2 = JSON.parseObject(response)
          val rt_status = response2.getString("status")
          val resultList = response2.getJSONObject("result")
          val list = resultList.getJSONArray("list")

          for (i <- (0 until list.size())) {
            val jo = new JSONObject()
            val result = list.getJSONObject(i)
            val rt_dist = result.getInteger("dist").toDouble / 1000
            val rt_time = result.getInteger("time")
            val rt_tolls = JSONUtils.getJsonValueDouble(result, "tolls", 0.0)
            val rt_coords = result.getJSONArray("coords").toJSONString
            val rt_src = result.getString("src")
            val rt_flen = result.getInteger("flen")
            val rt_tlen = result.getInteger("tlen")
            val rt_tollsDistance = result.getInteger("tollsDistance")
            val rt_highway = result.getInteger("highway")
            val rt_traLightCount = result.getInteger("traLightCount")

            jo.put("rt_status", rt_status)
            jo.put("rt_dist", rt_dist)
            jo.put("rt_time", rt_time)
            jo.put("rt_tolls", rt_tolls)
            jo.put("rt_coords", rt_coords)
            jo.put("rt_src", rt_src)
            jo.put("rt_flen", rt_flen)
            jo.put("rt_tlen", rt_tlen)
            jo.put("rt_plan_order", i)
            jo.put("data_source", "jy")
            jo.put("rt_url", url)
            jo.put("rt_tollsDistance", rt_tollsDistance)

            joArray.add(jo)
          }
        }
      }
    } catch {
      case e: Exception => errLog = e.getMessage + "请求url为：" + url + "response为：" + response
    }

    (joArray, errLog)

  }

  /** @note 调用CT轨迹接口 */
  private def scheduleCTTraj(axle_number: Int, x1: Double, y1: Double, x2: Double, y2: Double, vehicle_type: Int, planDate: String): (JSONArray, String) = {

    // val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=0&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&opt=sf2&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    //val historyTrajUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=2&cc=1&merge=4&etype=2&opt=sf2&rarefy=0&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val historyTrajUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=2&cc=1&merge=4&etype=2&opt=sf2&rarefy=0&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"

    val joArray = new JSONArray()
    val url = String.format(historyTrajUrl.toString, axle_number.toString, x1.toString, y1.toString, x2.toString, y2.toString, vehicle_type.toString, planDate.toString)
    val response = Utils.retryGet(url)

    var errLog = ""
    try {
      //val response = Source.fromURL(url,"UTF-8").mkString
      if (StringUtils.nonEmpty(response)) {
        if (JSONUtils.isValidJSON(response)) {
          val response2 = JSON.parseObject(response)
          val rt_status = response2.getString("status")
          val resultList = response2.getJSONObject("result")
          val list = resultList.getJSONArray("list")

          for (i <- (0 until list.size())) {
            val jo = new JSONObject()
            val result = list.getJSONObject(i)
            val rt_dist = result.getInteger("dist").toDouble / 1000
            val rt_time = result.getInteger("time")
            val rt_tolls = JSONUtils.getJsonValueDouble(result, "tolls", 0.0)
            val rt_coords = result.getJSONArray("coords").toJSONString
            val rt_src = result.getString("src")
            val rt_flen = result.getInteger("flen")
            val rt_tlen = result.getInteger("tlen")
            val rt_tollsDistance = result.getInteger("tollsDistance")
            val rt_highway = result.getInteger("highway")
            val rt_traLightCount = result.getInteger("traLightCount")

            jo.put("rt_status", rt_status)
            jo.put("rt_dist", rt_dist)
            jo.put("rt_time", rt_time)
            jo.put("rt_tolls", rt_tolls)
            jo.put("rt_coords", rt_coords)
            jo.put("rt_src", rt_src)
            jo.put("rt_flen", rt_flen)
            jo.put("rt_tlen", rt_tlen)
            jo.put("rt_plan_order", i)
            jo.put("data_source", "ct")
            jo.put("rt_url", url)
            jo.put("rt_tollsDistance", rt_tollsDistance)

            joArray.add(jo)
          }
        }
      }
    } catch {
      case e: Exception => errLog = errLog + e.getMessage + "请求的url为" + url + "response为：" + response
    }
    (joArray, errLog)

  }


  val fixUrl = "http://10.202.116.143:38081/drectify"

  case class Ontime8090(start_time: String, start_dept: String, end_dept: String, vehicle_type: Int, time_p8: Int
                        , time_p9: Int, his_ontime_rate: Double, ontime80Ratio: Double, ontime90Ratio: Double, groupCnt: Int)

  case class HistoryOntimeDept(
                                start_time: String,
                                start_dept: String,
                                end_dept: String,
                                vehicle_type: String,
                                time_p8: String,
                                time_p9: String,
                                his_ontime_rate: String,
                                p8_ontime_rate: String,
                                p9_ontime_rate: String,
                                group_count: String,
                                dist_p8: String,
                                dist_p9: String,
                                inc_day: String)


  def getLabelData(standardDistEffect: RDD[JSONObject]): RDD[JSONObject] = {

    val unLabelRdd = standardDistEffect.map(x => {
      val line_distance = JSONUtils.getJsonValueDouble(x, "line_distance", 1.0)
      val ft_dist = JSONUtils.getJsonValueDouble(x, "ft_dist", 0.0)
      val line_time = JSONUtils.getJsonValueDouble(x, "line_time", 0.0)
      val time_p9 = JSONUtils.getJsonValueDouble(x, "time_p9", 0.0)

      val transoport_level = JSONUtils.getJsonValueInt(x, "transoport_level", 1)

      val group_dist_min = JSONUtils.getJsonValueDouble(x, "group_dist_min", 0.0)

      val order_source = JSONUtils.getJsonValue(x, "order_source", "")


      val dist_flag = (ft_dist, line_distance) match {
        case (ft_dist, line_distance) if (ft_dist - line_distance) / line_distance > 0.05 => "里程配置偏少超5%"
        case (ft_dist, line_distance) if (ft_dist - line_distance) / line_distance < -0.05 => "里程配置偏多超5%"
        case (ft_dist, line_distance) if (ft_dist - line_distance) / line_distance <= 0.05 && (ft_dist - line_distance) / line_distance >= 0 => "里程配置偏少5%以内"
        case (ft_dist, line_distance) if (ft_dist - line_distance) / line_distance < 0 && (ft_dist - line_distance) / line_distance >= -0.05 => "里程配置偏多5%以内"
      }

      val time_flag = (transoport_level, time_p9, line_time) match {
        case (transoport_level, time_p9, line_time) if (transoport_level == 1 && (time_p9 - line_time) > 10) => "时效不足超10分钟"
        case (transoport_level, time_p9, line_time) if (transoport_level == 1 && (time_p9 - line_time) < -10) => "时效过多超10分钟"
        case (transoport_level, time_p9, line_time) if (transoport_level == 1 && (time_p9 - line_time) >= 0 && (time_p9 - line_time) <= 10) => "时效不足10分钟内"
        case (transoport_level, time_p9, line_time) if (transoport_level == 1 && (time_p9 - line_time) >= -10 && (time_p9 - line_time) < 0) => "时效过多10分钟内"

        case (transoport_level, time_p9, line_time) if (transoport_level != 1 && (time_p9 - line_time) > 5) => "时效不足超5分钟"
        case (transoport_level, time_p9, line_time) if (transoport_level != 1 && (time_p9 - line_time) < -5) => "时效过多超5分钟"
        case (transoport_level, time_p9, line_time) if (transoport_level != 1 && (time_p9 - line_time) >= 0 && (time_p9 - line_time) <= 5) => "时效不足超5分钟"
        case (transoport_level, time_p9, line_time) if (transoport_level != 1 && (time_p9 - line_time) >= -5 && (time_p9 - line_time) < 0) => "时效不足超5分钟"

        case _ => "其它"

      }


      val builder = new mutable.StringBuilder()


      if ((transoport_level == 1 || transoport_level == 2)) {

        if ((ft_dist - line_distance) / line_distance <= -0.05 || (ft_dist - line_distance) <= -50) {
          builder.append("·").append("压缩里程")
        } else {
          if ((ft_dist - line_distance) / line_distance >= 0.05 || (ft_dist - line_distance) >= 50) {
            if ((group_dist_min - line_distance) / line_distance >= 0.04 || group_dist_min - line_distance >= 40) {
              if (!order_source.equals("gd") && !order_source.equals("ct") && !order_source.equals("tracks") && !order_source.equals("jy") && !order_source.equals("jy|tracks") && !order_source.equals("tracks|jy")) {
                builder.append("·").append("延长里程")
              }
            }
          }
        }
      } else if (transoport_level == 3) {
        if ((ft_dist - line_distance) / line_distance <= -0.05) {
          builder.append("·").append("压缩里程")
        } else {
          if ((ft_dist - line_distance) / line_distance >= 0.05) {
            if ((group_dist_min - line_distance) / line_distance >= 0.04 || group_dist_min - line_distance >= 40) {
              if (!order_source.equals("gd") && !order_source.equals("ct") && !order_source.equals("tracks") && !order_source.equals("jy") && !order_source.equals("jy|tracks") && !order_source.equals("tracks|jy")) {
                builder.append("·").append("延长里程")
              }
            }
          }
        }
      }


      //计算参考车速 （结果保留2位小数）
      var ref_speed = (ft_dist * 60 / time_p9).formatted("%.2f").toDouble


      var res_abnormal = ""

      if ((ft_dist / line_distance) < 0.5) {
        res_abnormal = res_abnormal + "1" + "|"
      }

      if ((ft_dist / line_distance) > 1.5) {
        res_abnormal = res_abnormal + "2" + "|"
      }

      if (ref_speed > 80.0) {
        res_abnormal = res_abnormal + "3" + "|"
      }

      if (ref_speed < 15.0) {
        res_abnormal = res_abnormal + "4" + "|"
      }

      //time_p9>60 min 且 time_p9/line_time<0.5
      if (time_p9 > 60 && time_p9 / line_time < 0.5) {
        res_abnormal = res_abnormal + "5" + "|"
      }

      if (time_p9 > 60 && time_p9 / line_time > 1.5) {
        res_abnormal = res_abnormal + "6" + "|"
      }

      x.put("dist_flag", dist_flag)
      x.put("time_flag", time_flag)
      if (ref_speed.isInfinity) {
        x.put("ref_speed", "")
      } else {
        x.put("ref_speed", ref_speed)
      }
      x.put("ft_time", time_p9)
      x.put("res_abnormal", res_abnormal)
      x.put("flag", builder.toString())
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    unLabelRdd
  }


  def getDistEffect(spark: SparkSession, inc_day: String, ftDistTimeRdd: RDD[JSONObject], standardTimeEffect: RDD[JSONObject]): RDD[JSONObject] = {

    //待去重
    val distEffect = ftDistTimeRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = x.getString("axle_number")
      ((start_time, start_dept, end_dept, vehicle_type, axle_number), x)
    }).reduceByKey((obj1, obj2) => obj1).map(x => {
      val ftDistRdd = x._2
      val (start_time, start_dept, end_dept, vehicle_type, axle_number) = x._1
      ((start_time, start_dept, end_dept, vehicle_type, axle_number), ftDistRdd)
    })

    logger.error("getDistEffect的数据量为：" + distEffect.count())

    val timeEffect = standardTimeEffect.map(x => {
      //line_code、start_dept、end_dept、vehicle_type
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = x.getString("axle_number")
      ((start_time, start_dept, end_dept, vehicle_type, axle_number), x)
    })
    logger.error("timeEffect的数据量为：" + timeEffect.count())

    /**
      * 以步骤7.2.1关联后结果为左表，根据start_time、start_dept、end_dept、vehicle_type关联，
      * 获取标准里程（ft_dist）、路桥费（ft_tolls）、轨迹（ft_coords）、数据来源（data_source）、交集情况（order_source）、请求链接（ft_url）
      */

    val distEffectRdd = timeEffect.leftOuterJoin(distEffect).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      val is_match = left.getString("is_match")

      if (!rightOption.isEmpty) {
        val ontime = rightOption.get

        val ft_dist = ontime.getString("rt_dist")
        val ft_time = ontime.getString("rt_time")
        val ft_coords = ontime.getString("rt_coords")
        val ft_tolls = ontime.getString("tolls")
        val ft_url = ontime.getString("rt_url")
        val task_area_code = ontime.getString("task_area_code")

        left.put("ft_dist", ft_dist)
        left.put("ft_time", ft_time)
        left.put("ft_coords", ft_coords)
        left.put("ft_tolls", ft_tolls)
        left.put("ft_url", ft_url)
        left.put("task_area_code", task_area_code)

        left.fluentPutAll(ontime)
      }

      left.put("is_match", is_match)
      left
    })
    logger.error("distEffectRdd的数据量为：" + distEffectRdd.count())

    distEffectRdd
  }


  /**
    * 根据已有车型，判断对应缺失车型
    *
    * @param hashMap
    * @param value
    * @return
    */
  def valueGetKey(hashMap: mutable.HashMap[Int, Int], value: Int): ArrayBuffer[Int] = {
    val buffer = new ArrayBuffer[Int]()
    val list = hashMap.keySet

    list.map(x => {
      if (hashMap.get(x).get.equals(value)) {
        buffer.append(x)
      }
    })
    buffer
  }

  def getTimeEffect(spark: SparkSession, inc_day: String, ontimeRateRdd: RDD[JSONObject], markUnVerifyRdd: RDD[JSONObject]): RDD[JSONObject] = {

    val ontimeRateRddJoin = ontimeRateRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      ((start_time, start_dept, end_dept, vehicle_type), x)
      //((start_time,start_dept,end_dept),x)
    }).reduceByKey((obj1, obj2) => {
      obj1
    }).map(x => {
      val ontimeRdd = x._2
      val (start_time, start_dept, end_dept, vehicle_type) = x._1
      ((start_time, start_dept, end_dept), ontimeRdd)

    }).groupByKey().flatMap(x => {
      val list = x._2.toBuffer
      val listNew = new ArrayBuffer[JSONObject]()

      val setAll = Set(5, 6, 7, 8)

      val setPre = mutable.Set[Int]()
      //val seq = Seq[Int]()
      val hashMap = new mutable.HashMap[Int, Int]()

      if (list.size > 0) {
        val listSort = list.sortBy(_.getIntValue("vehicle_type"))
        listSort.map(x => {
          val vehicle_type = x.getIntValue("vehicle_type")
          setPre.add(vehicle_type)
        })
        //获取缺失的vehicle_type
        val setData = setPre.toSeq.sortBy(x => x).toSet
        val lackSet = setAll.diff(setData)

        for (i <- lackSet if lackSet.size > 0) {
          var flag = 0
          for (j <- setData if flag == 0) {
            if (i < j) {
              hashMap.put(i, j)
            }
          }
          if (flag == 0) {
            hashMap.put(i, try {
              setData.max
            } catch {
              case e: Exception => 8
            })
          }
        }

        //遍历添加缺失的vehicle_type
        for (i <- 0 until (list.size)) {
          listNew.append(list(i))
          val vehicle_type = list(i).getIntValue("vehicle_type")
          if (hashMap.values.mkString.contains(vehicle_type.toString)) {
            val buffer = valueGetKey(hashMap, vehicle_type)
            buffer.map(x => {
              val jo = new JSONObject()
              jo.fluentPutAll(list(i))
              jo.put("vehicle_type", x)
              listNew.append(jo)
            })
          }
        }
      }
      listNew
    }).map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      ((start_time, start_dept, end_dept, vehicle_type), x)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("ontimeRateRddJoin的数据量为：" + ontimeRateRddJoin.count())
    ontimeRateRddJoin.take(2).foreach(println(_))


    val joinRdd = markUnVerifyRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = JSONUtils.getJsonValueInt(x, "vehicle_type", 6).toString

      ((start_time, start_dept, end_dept, vehicle_type), x)

    }).leftOuterJoin(ontimeRateRddJoin).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      if (!rightOption.isEmpty) {
        val ontime = rightOption.get
        left.fluentPutAll(ontime)
      }
      left
    })
    joinRdd
  }


  def getUndefineData(spark: SparkSession, inc_day: String) = {

    //    val beginDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -30)
    //    val endDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 2)
    val beginDay = "20211001"
    val endDay = "20211030"
    //val inc_day = "20211030"
    val undefineSql =
      s"""
         |select * from (
         |    SELECT
         |  row_number() over(
         |            PARTITION by start_time,start_dept,end_dept,vehicle_type
         |            ORDER by last_update_tm desc) as rn_new,
         |          *
         |from (
         |select
         |  a.line_require_id,
         |  bb.sort_num,
         |  a.line_code,
         |  bb.job_type,
         |  a.require_category,
         |  a.line_require_type,
         |  case when a.transoport_level='一级运输' then '1'
         |  when a.transoport_level='二级运输' then '2'
         |  when a.transoport_level='三级运输' then '3'
         |  when a.transoport_level='四级运输' then '4'
         |  else '0'
         |  end as transoport_level,
         |  a.cvy_name,
         |  nvl(bb.line_distance, a.line_distance) as line_distance,-- 配 置 里 程 km
         |  bb.cost_time as line_time,-- 配 置 时 长
         |  a.is_stop_over,-- 是 否 经 停
         |  a.owndeptcode own_dept_code,-- 车 辆 所 属 地 区
         |  nvl(bb.start_dept, a.src_zone_code) as start_dept,
         |  nvl(bb.end_dept, a.dest_zone_code) as end_dept,
         |  bb.start_dept as start_dept_out,-- 始 发 网 外
         |  bb.end_dept as end_dept_out,-- 始 发 网 外
         |  a.capacityload vehicle_type,
         |  a.capacityload as full_load_weight,
         |  a.vehicle as car_type,
         |  bb.src_dept_out,-- 起 点 网 外 地 址
         |  bb.dest_dept_out,-- 终 点 网 外 地 址
         |  a.src_area_code,
         |  a.dest_area_code,
         |  nvl(bb.plan_depart_tm, a.plan_depart_tm) as plan_depart_tm,-- 计 划 发 车 时 间
         |  nvl(bb.plan_arrive_tm, a.plan_arrive_tm) as plan_arrive_tm,-- 计 划 到 达 时 间
         |  regexp_replace(
         |    substring(nvl(bb.plan_depart_tm, a.plan_depart_tm), 12, 5),':',''
         |  ) as start_time,-- 发 车 时 间 string
         |  bb.plan_send_batch,-- 计 划 发 车 班 次
         |  bb.plan_arrive_batch,-- 计 划 到 达 班 次
         |  a.actual_depart_tm,
         |  a.actual_arrive_tm,
         |  bb.last_update_tm,
         |  a.to_ground,-- 是 否 交 互
         |  bb.pass_zone_code,-- 经 过 网 点 代 码
         |  bb.last_arrive_tm -- 最 晚 到 达 时 间
         |FROM
         |    dm_ops.pass_forecast_road_convy_monitor_dtl  a
         |  left join (
         |    select
         |      lag(b.dept_site_id, 1) over(
         |        PARTITION BY b.line_require_id
         |        order by
         |          b.sort_num asc
         |      ) as start_dept,
         |      b.job_type,
         |      b.dept_site_id as end_dept,
         |      lag(b.plan_send_batch, 1) over(
         |        PARTITION BY b.line_require_id
         |        order by
         |          b.sort_num asc
         |      ) as plan_send_batch,-- 计 划 发 车 班 次
         |      b.plan_arrive_batch,-- 计 划 到 达 班 次
         |      lag(b.pass_zone_addr, 1) over(
         |        PARTITION BY b.line_require_id
         |        order by
         |          b.sort_num asc
         |      ) as src_dept_out,-- 起 点 网 外 地 址
         |      b.pass_zone_addr as dest_dept_out,-- 终 点 网 外 地 址
         |      lag(b.plan_depart_tm, 1) over(
         |        PARTITION BY b.line_require_id
         |        order by
         |          b.sort_num asc
         |      ) as plan_depart_tm,-- 计 划 发 车 时 间
         |      b.plan_arrive_tm,-- 计 划 到 达 时 间
         |      lag(b.line_distance, 1) over(
         |        PARTITION BY b.line_require_id
         |        order by
         |          b.sort_num asc
         |      ) as line_distance,-- 分 段 里 程
         |      lag(b.cost_time, 1) over(
         |        PARTITION BY b.line_require_id
         |        order by
         |          b.sort_num asc
         |      ) as cost_time,-- 分 段 时 间
         |      line_require_id,
         |      pass_zone_code,
         |      sort_num,
         |      last_update_tm,
         |      lag(b.actual_depart_tm, 1) over(
         |        PARTITION BY b.line_require_id
         |        order by
         |          b.sort_num asc
         |      ) as actual_depart_tm,-- 实 际 发 车 时 间
         |      b.actual_arrive_tm,-- 实 际 到 达 时 间
         |      b.last_arrive_tm -- 最 晚 到 达 时 间
         |    from
         |      (
         |        SELECT
         |          row_number() over(
         |            PARTITION by line_require_id,dept_site_id
         |            ORDER by
         |              last_update_tm desc
         |          ) as rn,
         |          *
         |        from
         |          ods_russ.tt_rs_vehicle_task_pass_zone_monitor
         |        where
         |          inc_day >= '${beginDay}'
         |          AND inc_day <= '${endDay}'
         |          and actual_pass_zone_code is not null
         |      ) b
         |    where
         |      b.rn = 1
         |  ) bb
         |  on a.line_require_id = bb.line_require_id
         |WHERE
         |  inc_day >= '${beginDay}'
         |  AND inc_day <= '${endDay}'
         |  and a.car_status = '已完成'
         |  -- and a.transoport_level in ('一级运输','二级运输') -- 暂 时 不 取 支 线
         |  -- and a.require_category in ('常规线路',  '区域发运', '零担线路')
         |  and substr(a.src_zone_code, 1, 1) not in ('P', 'M') -- 剔 除 冷 运 和 医 药 20190404
         |  and a.src_zone_code not in ('852', '853', '886') -- 剔 除 港 澳 台 20190619
         |  and a.dest_zone_code not in ('852', '853', '886')
         |  and bb.start_dept != ''
         |  AND bb.end_dept != ''
         |  and a.src_zone_code != a.dest_zone_code
         |  -- and a.owndeptcode in ('999Y','595Y')
         |  -- and a.line_code in ('793VA510WF0010')
         |  -- and a.line_code in ('027AM027WH1830','027AM027WH2030','027AM027WH2100','027AM027WH2130','027AM027WH2200','027AM027WH2359','550VA550BBL0630','550BBL550VA1720','395W395JAE0650','395W395JAE1430','395JAE395W2100','527BD527WA2029','527D527WA1800','527N527WA2100','527WA527BN0930','527WA527U0930','527WA527T0930','527WA527Q1300','527WA527N0930','527WA527D0930','527WA527CG1300','527BL527WA1750','527D527WA2040','527Q527WA2050','527WA527D1300','527WA527D1500','527WA527JEA0700','527WA527JEA1200','527WA527JEA1500','527WA527N1300','527BH527WA1100','527L527WA1800','527WA527Q0930','527WA527BQ1500','527T527WA2040','527Q527WA2130','527Q527WA2000','527Q527WA1759','527N527WA1100','527CB527WA1800','518FB518W1230','551UL551WH2100','557VA557UA0640','021WG021WJ0230','021WG021WJ0329','021WG021WJ0330','021WG021WJ0331','021WG021WJ0549','021WG021WJ0550','021WG021WJ0759','021WG021WJ0800','021WG021WJ1348','021WG021WJ1349','021WG021WJ1559','021WG021WJ1808','021WG021WJ1809','021WJ021WG0330','021WJ021WG0550','021WJ021WG0800','021WJ021WG1350','021WJ021WG1630','021WJ021WF0400','021WJ021WF0620','021WJ021WF0800','021WJ021WF1400','021WJ021WF1630','021WJ021WF2300','021WF021WJ0400','021WF021WJ0610','021WF021WJ0800','021WF021WJ1359','021WF021WJ1400','021WF021WJ1829','021WF021WJ2100','021WF021WJ2300','021WG021WF0239','021WG021WF0349','021WG021WF0350','021WG021WF0351','021WG021WF0549','021WG021WF0550','021WG021WF0759','021WG021WF0800','021WG021WF1358','021WG021WF1359','021WG021WF1550','021WF021WG0350','021WF021WG0610','021WF021WG0800','021WF021WG1400','938VA938EB0630','938VA938EB1330','938EB938VA1930','353VA351W2330','353VA351W2330','716VA716U0600','716U716VA1900','716VA716BF1330','716VA716U0708','716VA716U1628','716BF716VA1910','716VA716T0710','716T716VA1320','716VA716D0708','716VA716D0710','021JAE021WW2210','021JAE021WW2230','021WW021DN0530','021MC021VV2235','021MC021VV2250','021MV021VV2220','021UV021VV2210','021WJ021MT0800','021WJ021MT1130','021WJ021MT1600','021WJ021MD1400','021WJ021MD0500','021WJ021MD0400','021MD021WJ1930','021UV021WW1950','021WW021DN1530','021WJ021MP0800','021WJ021MP1400','021WJ021MP1600','021WJ021MP1130','021WJ021ME0800','021WJ021ME1600','021MU021WA1310','021MG021WA1330','021WJ021MA0550','021WJ021ME0550','021WJ021MG0550','021WJ021MP0550','021VV021MB0500','021ME021WJ0115','021MG021WA1030','021ME021WJ2000','021MG021WJ2225','021MA021WJ1941','021MA021WJ1940','021WJ021MA1130','021WJ021MA0800','021MG021WJ1330','021WJ021SN0400','021WJ021SN1130','021WJ021SN1600','021WJ021SN0500','021WJ021SN0800','021WJ021SN0550','021WJ021PU1400','021WJ021PU0800','021WJ021PU1130','021PU021WJ2130','021PU021WJ1300','021WJ021SQA1130','021WJ021SQA1600','021WJ021SQA1400','021WJ021SQA0800','021SQA021WA1305','021WJ021TE1400','021TE512W1730','021TE021WJ1820','021WJ021TE0800','021WJ021SA1130','021WJ021SA1600','021SA021WA1335','021WJ021SS1130','021SS021WJ2140','991W906VA1600')
         |) e  ) f
         |where f.rn_new=1
         |and start_dept!=end_dept
         |order by line_require_id,sort_num asc
       """.stripMargin

    val middle0Sql =
      s"""
         |select
         |  *,axis_number axle_number
         |from
         |dm_gis.eta_grd_middle0
         |where
         |  inc_day >='${beginDay}'
         |and
         |  inc_day <= '${endDay}'
         |and
         |  start_dept != end_dept
         | -- and
         | -- task_area_code in ('999Y','595Y')
         | -- and line_code in ('793VA510WF0010')
         | -- line_code in ('027AM027WH1830','027AM027WH2030','027AM027WH2100','027AM027WH2130','027AM027WH2200','027AM027WH2359','550VA550BBL0630','550BBL550VA1720','395W395JAE0650','395W395JAE1430','395JAE395W2100','527BD527WA2029','527D527WA1800','527N527WA2100','527WA527BN0930','527WA527U0930','527WA527T0930','527WA527Q1300','527WA527N0930','527WA527D0930','527WA527CG1300','527BL527WA1750','527D527WA2040','527Q527WA2050','527WA527D1300','527WA527D1500','527WA527JEA0700','527WA527JEA1200','527WA527JEA1500','527WA527N1300','527BH527WA1100','527L527WA1800','527WA527Q0930','527WA527BQ1500','527T527WA2040','527Q527WA2130','527Q527WA2000','527Q527WA1759','527N527WA1100','527CB527WA1800','518FB518W1230','551UL551WH2100','557VA557UA0640','021WG021WJ0230','021WG021WJ0329','021WG021WJ0330','021WG021WJ0331','021WG021WJ0549','021WG021WJ0550','021WG021WJ0759','021WG021WJ0800','021WG021WJ1348','021WG021WJ1349','021WG021WJ1559','021WG021WJ1808','021WG021WJ1809','021WJ021WG0330','021WJ021WG0550','021WJ021WG0800','021WJ021WG1350','021WJ021WG1630','021WJ021WF0400','021WJ021WF0620','021WJ021WF0800','021WJ021WF1400','021WJ021WF1630','021WJ021WF2300','021WF021WJ0400','021WF021WJ0610','021WF021WJ0800','021WF021WJ1359','021WF021WJ1400','021WF021WJ1829','021WF021WJ2100','021WF021WJ2300','021WG021WF0239','021WG021WF0349','021WG021WF0350','021WG021WF0351','021WG021WF0549','021WG021WF0550','021WG021WF0759','021WG021WF0800','021WG021WF1358','021WG021WF1359','021WG021WF1550','021WF021WG0350','021WF021WG0610','021WF021WG0800','021WF021WG1400','938VA938EB0630','938VA938EB1330','938EB938VA1930','353VA351W2330','353VA351W2330','716VA716U0600','716U716VA1900','716VA716BF1330','716VA716U0708','716VA716U1628','716BF716VA1910','716VA716T0710','716T716VA1320','716VA716D0708','716VA716D0710','021JAE021WW2210','021JAE021WW2230','021WW021DN0530','021MC021VV2235','021MC021VV2250','021MV021VV2220','021UV021VV2210','021WJ021MT0800','021WJ021MT1130','021WJ021MT1600','021WJ021MD1400','021WJ021MD0500','021WJ021MD0400','021MD021WJ1930','021UV021WW1950','021WW021DN1530','021WJ021MP0800','021WJ021MP1400','021WJ021MP1600','021WJ021MP1130','021WJ021ME0800','021WJ021ME1600','021MU021WA1310','021MG021WA1330','021WJ021MA0550','021WJ021ME0550','021WJ021MG0550','021WJ021MP0550','021VV021MB0500','021ME021WJ0115','021MG021WA1030','021ME021WJ2000','021MG021WJ2225','021MA021WJ1941','021MA021WJ1940','021WJ021MA1130','021WJ021MA0800','021MG021WJ1330','021WJ021SN0400','021WJ021SN1130','021WJ021SN1600','021WJ021SN0500','021WJ021SN0800','021WJ021SN0550','021WJ021PU1400','021WJ021PU0800','021WJ021PU1130','021PU021WJ2130','021PU021WJ1300','021WJ021SQA1130','021WJ021SQA1600','021WJ021SQA1400','021WJ021SQA0800','021SQA021WA1305','021WJ021TE1400','021TE512W1730','021TE021WJ1820','021WJ021TE0800','021WJ021SA1130','021WJ021SA1600','021SA021WA1335','021WJ021SS1130','021SS021WJ2140','991W906VA1600')
       """.stripMargin

    val middle1Sql =
      s"""
         |select
         | start_time,start_dept,end_dept,inc_day,vehicle_type,rt_dist
         |from
         |  dm_gis.eta_traj_simgroup_info
         |where
         |  inc_day >='${beginDay}'
         |and
         |  inc_day <= '${endDay}'
         | -- and
         | -- task_area_code in ('999Y','595Y')
         | -- and
         | -- line_code in ('793VA510WF0010')
         | -- and
         | -- line_code in ('027AM027WH1830','027AM027WH2030','027AM027WH2100','027AM027WH2130','027AM027WH2200','027AM027WH2359','550VA550BBL0630','550BBL550VA1720','395W395JAE0650','395W395JAE1430','395JAE395W2100','527BD527WA2029','527D527WA1800','527N527WA2100','527WA527BN0930','527WA527U0930','527WA527T0930','527WA527Q1300','527WA527N0930','527WA527D0930','527WA527CG1300','527BL527WA1750','527D527WA2040','527Q527WA2050','527WA527D1300','527WA527D1500','527WA527JEA0700','527WA527JEA1200','527WA527JEA1500','527WA527N1300','527BH527WA1100','527L527WA1800','527WA527Q0930','527WA527BQ1500','527T527WA2040','527Q527WA2130','527Q527WA2000','527Q527WA1759','527N527WA1100','527CB527WA1800','518FB518W1230','551UL551WH2100','557VA557UA0640','021WG021WJ0230','021WG021WJ0329','021WG021WJ0330','021WG021WJ0331','021WG021WJ0549','021WG021WJ0550','021WG021WJ0759','021WG021WJ0800','021WG021WJ1348','021WG021WJ1349','021WG021WJ1559','021WG021WJ1808','021WG021WJ1809','021WJ021WG0330','021WJ021WG0550','021WJ021WG0800','021WJ021WG1350','021WJ021WG1630','021WJ021WF0400','021WJ021WF0620','021WJ021WF0800','021WJ021WF1400','021WJ021WF1630','021WJ021WF2300','021WF021WJ0400','021WF021WJ0610','021WF021WJ0800','021WF021WJ1359','021WF021WJ1400','021WF021WJ1829','021WF021WJ2100','021WF021WJ2300','021WG021WF0239','021WG021WF0349','021WG021WF0350','021WG021WF0351','021WG021WF0549','021WG021WF0550','021WG021WF0759','021WG021WF0800','021WG021WF1358','021WG021WF1359','021WG021WF1550','021WF021WG0350','021WF021WG0610','021WF021WG0800','021WF021WG1400','938VA938EB0630','938VA938EB1330','938EB938VA1930','353VA351W2330','353VA351W2330','716VA716U0600','716U716VA1900','716VA716BF1330','716VA716U0708','716VA716U1628','716BF716VA1910','716VA716T0710','716T716VA1320','716VA716D0708','716VA716D0710','021JAE021WW2210','021JAE021WW2230','021WW021DN0530','021MC021VV2235','021MC021VV2250','021MV021VV2220','021UV021VV2210','021WJ021MT0800','021WJ021MT1130','021WJ021MT1600','021WJ021MD1400','021WJ021MD0500','021WJ021MD0400','021MD021WJ1930','021UV021WW1950','021WW021DN1530','021WJ021MP0800','021WJ021MP1400','021WJ021MP1600','021WJ021MP1130','021WJ021ME0800','021WJ021ME1600','021MU021WA1310','021MG021WA1330','021WJ021MA0550','021WJ021ME0550','021WJ021MG0550','021WJ021MP0550','021VV021MB0500','021ME021WJ0115','021MG021WA1030','021ME021WJ2000','021MG021WJ2225','021MA021WJ1941','021MA021WJ1940','021WJ021MA1130','021WJ021MA0800','021MG021WJ1330','021WJ021SN0400','021WJ021SN1130','021WJ021SN1600','021WJ021SN0500','021WJ021SN0800','021WJ021SN0550','021WJ021PU1400','021WJ021PU0800','021WJ021PU1130','021PU021WJ2130','021PU021WJ1300','021WJ021SQA1130','021WJ021SQA1600','021WJ021SQA1400','021WJ021SQA0800','021SQA021WA1305','021WJ021TE1400','021TE512W1730','021TE021WJ1820','021WJ021TE0800','021WJ021SA1130','021WJ021SA1600','021SA021WA1335','021WJ021SS1130','021SS021WJ2140','991W906VA1600')
         """.stripMargin

    val transCarSql =
      s"""
         |select
         |  line_code,
         |  if(carrier_type=0 or plf_flag=1,'自营','外包') trans_car
         |from
         |  dm_grd.grd_new_task_detail
         |where
         |  inc_day >= '${beginDay}'
         |  and inc_day <= '${endDay}'
         |  and state = 6
         |  and substr(src_zone_code, 1, 1) not in ('P', 'M')
         |  and src_zone_code not in ('852', '853', '886')
         |  and dest_zone_code not in ('852', '853', '886')
         |group by
         |  line_code,
         |  trans_car
       """.stripMargin


    val unDefineDF = spark.sql(undefineSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("unDefineDF的数据量为：" + unDefineDF.count())
    unDefineDF.take(2).foreach(println(_))
    unDefineDF.createOrReplaceTempView("linecode_info_table")
    //    val joinWorkDaySql =
    //      s"""
    //         |select
    //         |   a.*,b.pass_id pass_id,b.work_day work_day,b.revise_distance,b.revise_run_tm,'1' is_match
    //         |from
    //         |unDefineTable a
    //       """.stripMargin
    //
    //    val unDefineDF2 = spark.sql(joinWorkDaySql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("unDefineDF2的数据量为：" + unDefineDF2.count())
    //    unDefineDF2.take(2).foreach(println(_))
    //    unDefineDF2.createOrReplaceTempView("linecode_info_table0")


    val middle0DF = spark.sql(middle0Sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("middle0DF历史轨迹数据量为:" + middle0DF.count())
    middle0DF.take(2).foreach(println(_))

    val middle1DF = spark.sql(middle1Sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("middle1DF数据量为:" + middle1DF.count())
    middle1DF.take(2).foreach(println(_))

    middle0DF.createOrReplaceTempView("temp_gj_history")


    val transCarDF = spark.sql(transCarSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("transCarDF的数据量为：" + transCarDF.count())


    val inc_day_next = DateTimeUtil.getLastTwoWeekMS(inc_day, "yyyyMMdd")

    val monday = inc_day_next._1
    val sunday = inc_day_next._2


    logger.error("打印关联轨迹")


    //    val undefinedData =
    //      s"""
    //         |select
    //         |    *
    //         |from
    //         |(
    //         |select *,if(work_day in ('6','7','67'),1,0) work_day_tag
    //         |from
    //         |linecode_info_table0
    //         |where
    //         |    line_distance >5
    //         |) a
    //       """.stripMargin
    //    val pretreatmentUndefinedDF = spark.sql(undefinedData).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("pretreatmentUndefinedDF的数据量为：" + pretreatmentUndefinedDF.count())
    //    pretreatmentUndefinedDF.take(2).foreach(println(_))
    //
    //    pretreatmentUndefinedDF.createOrReplaceTempView("linecode_info_table")


    val joinSql =
      s"""
         |select
         |  x1,y1,x2,y2,line_code,vehicle_type,'' height,'' axle_weight,'' axle_number,'' vehicle,'' vehicle_color,'' energy,'' width,'' length,
         |  concat(${monday},start_time,"00") plan_date,
         |  start_dept,end_dept,task_area_code,start_time,'' full_loadweight,line_distance,line_time,transoport_level,
         |  line_require_id,sort_num,require_category,line_require_type,cvy_name,is_stop_over,own_dept_code,start_dept_out,
         |  end_dept_out,full_load_weight,car_type,src_dept_out,dest_dept_out,plan_depart_tm,plan_arrive_tm,plan_send_batch,
         |  plan_arrive_batch,actual_depart_tm,actual_arrive_tm,last_update_tm,to_ground,pass_zone_code,last_arrive_tm,'' pass_id,job_type,'1234567' work_day,src_area_code,dest_area_code,src_zone_name,dest_zone_name,'1' is_match
         |from
         |  (
         |    select
         |      aa.*,bb.x2 x2,bb.y2 y2,bb.dest_zone_name dest_zone_name
         |    from
         |      (
         |        select
         |          a.*,
         |          longitude x1,
         |          latitude y1,
         |          task_area_code,
         |          src_zone_name
         |        from
         |          linecode_info_table a
         |          left outer join (
         |            select
         |              dept_code,
         |              longitude,
         |              latitude,
         |              area_code task_area_code,
         |              dept_name src_zone_name
         |            from
         |              dim.dim_department
         |            where
         |              delete_flg != 1
         |              and area_code is not null
         |              and longitude is not null
         |          ) c on a.start_dept = c.dept_code
         |      ) aa
         |      left outer join (
         |          select
         |            dept_code,
         |            longitude x2,
         |            latitude y2,
         |            area_code task_area_code,
         |            dept_name dest_zone_name
         |          from
         |            dim.dim_department
         |          where
         |            delete_flg != 1
         |            and area_code is not null
         |            and longitude is not null
         |      ) bb  on aa.end_dept = bb.dept_code
         |  ) aaa
         |    -- where
         |    -- transoport_level != 3
         |    -- or (transoport_level = 3 and task_area_code not in ('111Y','222Y','300Y','333Y','555Y','666Y','700Y','777Y','888Y','999Y'))
       """.stripMargin


    val rep = spark.sql(joinSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("rep的数据量为：" + rep.count())
    rep.take(2).foreach(println(_))
    val colList = rep.columns

    val undefineDataRdd = rep.rdd.repartition(200).map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns, x.getAs[String](columns))
      }
      jo
    }).map(x => {
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      ((line_code, start_dept, end_dept), x)
    }).groupByKey().map(x => {

      val (line_code, start_dept, end_dept) = x._1
      val list = x._2.toList
      val maxVehicleType = list.maxBy(obj => {
        JSONUtils.getJsonValueInt(obj, "vehicle_type", 6)
      })
      maxVehicleType
    }).filter(x => {
      StringUtils.nonEmpty(x.getString("x1")) && StringUtils.nonEmpty(x.getString("y1")) && StringUtils.nonEmpty(x.getString("x2")) && StringUtils.nonEmpty(x.getString("y2"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("undefineDataRdd数据量为：" + undefineDataRdd.count())
    undefineDataRdd.take(2).foreach(println(_))
    rep.unpersist()

    // val transCarList = transCarDF.columns
    val transCarRdd = transCarDF.rdd.repartition(200).map(x => {
      val line_code = x.getString(0)
      val trans_car = x.getString(1)

      (line_code, trans_car)
    }).groupByKey().map(x => {
      val line_code = x._1
      val list = x._2.toList
      var trans_car = "未知"
      if (list.size > 1) {
        trans_car = "自营|外包"
      } else {
        trans_car = list(0)
      }
      (line_code, trans_car)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("transCarRdd数据量为：" + transCarRdd.count())

    val undefineDataRdd2 = undefineDataRdd.map(x => {
      val line_code = x.getString("line_code")
      (line_code, x)
    }).leftOuterJoin(transCarRdd).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      if (!rightOption.isEmpty) {
        val trans_car = rightOption.get
        left.put("trans_car", trans_car)
      } else {
        left.put("trans_car", "未知")
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("undefineDataRdd2的数据量为：" + undefineDataRdd2.count())


    (undefineDataRdd2, middle0DF, middle1DF)
  }


  def markUnVerify(getUndefineRdd: RDD[JSONObject]): RDD[JSONObject] = {

    val unVerifyRdd = getUndefineRdd.map(x => {

      var vehicle_type = 6
      var axle_number = 2
      if (StringUtils.nonEmpty(x.getString("full_load_weight"))) {
        val full_load_weight = JSONUtils.getJsonValueDouble(x, "full_load_weight", 0.0)

        vehicle_type = full_load_weight match {
          case full_load_weight if (full_load_weight <= 1.0) => 5
          case full_load_weight if (full_load_weight > 1.0 && full_load_weight < 3.0) => 6
          case full_load_weight if (full_load_weight >= 3.0 && full_load_weight < 7.0) => 7
          case full_load_weight if (full_load_weight >= 7.0) => 8
        }

        axle_number = full_load_weight match {
          case full_load_weight if (full_load_weight >= 0 && full_load_weight <= 9.5) => 2
          case full_load_weight if (full_load_weight > 9.5 && full_load_weight <= 14) => 3
          case full_load_weight if (full_load_weight > 14 && full_load_weight <= 20) => 4
          case full_load_weight if (full_load_weight > 20 && full_load_weight <= 25) => 5
          case full_load_weight if (full_load_weight >= 25) => 6
        }
        x.put("vehicle_type", vehicle_type)
        x.put("axle_number", axle_number)
      } else {
        val car_type = x.getString("car_type")
        if ("厢式运输车".equals(car_type)) {
          vehicle_type = 8
          axle_number = 4
        }
      }
      x.put("vehicle_type", vehicle_type)
      x.put("axle_number", axle_number)

      x
    })
    unVerifyRdd
  }


  def calFtDistTime(trajIntersectRdd: RDD[JSONObject]): RDD[JSONObject] = {

    val totalFtDist = trajIntersectRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = JSONUtils.getJsonValueInt(x, "axle_number", 2)
      ((start_time, start_dept, end_dept, vehicle_type, axle_number), x)
    }).groupByKey().map(x => {
      val list = x._2.toList

      val listNew = list.toStream.map(obj => {
        val order_source = obj.getString("order_source")
        val month_freq = JSONUtils.getJsonValueInt(obj, "month_freq", 0)
        var gjTag = 0
        var gdTag = 0
        var ctTag = 0

        if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && order_source.contains("jy")) {
          obj.put("gjTag", 100)
          gjTag = 100
        } else if (StringUtils.nonEmpty(order_source) && !order_source.contains("tracks") && order_source.contains("jy")) {
          obj.put("gjTag", 80)
          gjTag = 80
        } else if (StringUtils.nonEmpty(order_source) && !order_source.contains("jy") && order_source.contains("tracks") && month_freq >= 10) {
          obj.put("gjTag", 85)
          gjTag = 85
        } else if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && !order_source.contains("jy") && month_freq < 10 && month_freq >= 5) {
          obj.put("gjTag", 80)
          gjTag = 80
        } else if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && !order_source.contains("jy") && month_freq < 5 && month_freq >= 3) {
          obj.put("gjTag", 70)
          gjTag = 70
        } else if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && !order_source.contains("jy") && month_freq < 3) {
          obj.put("gjTag", 50)
          gjTag = 50
        } else if (StringUtils.nonEmpty(order_source) && !order_source.contains("tracks") && !order_source.contains("jy")) {
          obj.put("gjTag", 0)
          gjTag = 0
        }

        if (StringUtils.nonEmpty(order_source) && order_source.contains("gd")) {
          obj.put("gdTag", 95)
          gdTag = 95
        } else {
          obj.put("gdTag", 0)
          gdTag = 0
        }
        if (StringUtils.nonEmpty(order_source) && order_source.contains("ct")) {
          obj.put("ctTag", 90)
          ctTag = 90
        } else {
          obj.put("ctTag", 0)
          ctTag = 0
        }

        val data_source = obj.getString("data_source")
        if (StringUtils.nonEmpty(data_source)) {
          val dataSourceIndex = data_source match {

            case data_source if data_source.equals("gd") => 4
            case data_source if data_source.equals("ct") => 3
            case data_source if data_source.equals("jy") => 2
            case data_source if data_source.equals("tracks") => 1
          }
          obj.put("dataSourceIndex", dataSourceIndex)
        }

        val cornAll = gjTag + gdTag + ctTag
        obj.put("scoreAll", cornAll)
        obj
      })


      val ft_time_pre = listNew.maxBy(x => {
        JSONUtils.getJsonValueInt(x, "rt_time", 0)
      })
      val ft_time = JSONUtils.getJsonValueInt(ft_time_pre, "rt_time", 0)

      val group_dist_min = try {
        listNew.minBy(x => {
          JSONUtils.getJsonValueDouble(x, "rt_dist", 0.0)
        }).getDoubleValue("rt_dist")
      } catch {
        case e: Exception => 0.0
      }

      //      val head = listNew.sortBy(x => new SecondarySortByKey(JSONUtils.getJsonValueInt(x, "scoreAll", 0), JSONUtils.getJsonValueInt(x, "dataSourceIndex", 0))).head
      // 20210811增加三级排序
      val head = listNew.sortBy(x => new ThirdSortByKey(JSONUtils.getJsonValueInt(x, "scoreAll", 0), JSONUtils.getJsonValueInt(x, "dataSourceIndex", 0), JSONUtils.getJsonValueInt(x, "month_freq", 0))).head

      val ft_dist = head.getString("rt_dist")
      head.put("ft_dist", ft_dist)
      head.put("ft_time", ft_time)
      head.put("group_dist_min", group_dist_min)

      try {
        if (JSONUtils.getJsonValue(head, "data_source", "").equals("gd")) {
          val (tolls, originList) = scheduleGdTolls(head)
          head.put("tolls", tolls)
          head.put("originList", originList)
        }
      } catch {
        case e: Exception => println("调用路桥费请求错误")
      }

      head
    })

    logger.error("totalFtDist的数据量为：" + totalFtDist.count())

    totalFtDist
  }


  def scheduleGdTolls(ft_dist: JSONObject): (Int, String) = {
    val axle_number = ft_dist.getString("axle_number")
    val vehicle = JSONUtils.getJsonValue(ft_dist, "vehicle_type", "6")
    val speed = JSONUtils.getJsonValueInt(ft_dist, "speed", 1)
    val Toll = JSONUtils.getJsonValueInt(ft_dist, "Tolls", 1)
    val rt_coords_pre = ft_dist.getString("rt_coords")
    val rt_coords = JSON.parseArray(rt_coords_pre)

    val points = new ArrayBuffer[String]()
    for (i <- 0 until (rt_coords.size())) {
      val array = JSON.parseArray(rt_coords.getString(i))
      if (array.size() > 0) {
        val x = array.getString(0)
        val y = array.getString(1)
        points.append(x)
        points.append(",")
        points.append(y)
        points.append("|")
      }
    }

    //println(points.mkString("").dropRight(1))
    //vehicle=8&axlenumber=0&passport=100000&output=json&mode=2&strategy=0&toll=1&speed=1&stype=0&etype=0&test=1&fencedist=300
    val jo = new mutable.StringBuilder()
    jo.append("vehicle=").append(vehicle).append("&axlenumber=").append(axle_number).append("&passport=100000").append("&output=json&mode=2&strategy=0&toll=1&speed=1&stype=0&etype=0&test=1&fencedist=300&points=")
    jo.append(points.mkString(""))

//    val ft_dist_new = com.sf.gis.java.eta.constant.utils.HttpClientUtil.httpPostXmlRequest("http://10.216.162.68:7173/qm_point", jo.mkString)
    val ft_dist_new = HttpClientUtils.httpPostXmlRequest("http://10.216.162.68:7173/qm_point", jo.mkString)

    val response = JSON.parseObject(ft_dist_new)
    val route = response.getJSONObject("route")
    val paths = route.getJSONArray("paths")
    var totalTolls = 0

    val originBuffer = new ArrayBuffer[JSONArray]()

    if (paths.size() > 0) {
      for (i <- 0 until (paths.size())) {
        val pathJson = paths.getJSONObject(i)

        val jsonArray = new JSONArray()
        //增加多起点统计
        val origin = pathJson.getString("origin")
        jsonArray.add(origin)
        originBuffer.append(jsonArray)

        val tolls = pathJson.getIntValue("tolls")
        totalTolls += tolls
      }
    }
    (totalTolls, originBuffer.mkString(""))
  }


  def saveTableToRes2(spark: SparkSession, inc_day: String, ftDistTimeRdd: RDD[JSONObject]) = {

    import spark.implicits._
    val labelDataRdd = ftDistTimeRdd.map(x => {

      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val axle_number = x.getString("axle_number")
      val start_time = x.getString("start_time")
      val vehicle_type = x.getString("vehicle_type")
      val order_source = x.getString("order_source")
      val data_source = x.getString("data_source")
      val ft_dist = x.getString("rt_dist")
      val ft_time = x.getString("rt_time")
      val ft_coords = x.getString("rt_coords")
      val ft_tolls = x.getString("tolls")
      val ft_url = x.getString("rt_url")
      val task_area_code = x.getString("task_area_code")
      val group_dist_min = x.getString("group_dist_min")
      //20210618添加
      val rt_src = x.getString("rt_src")
      val score = x.getString("scoreAll")
      val originList = x.getString("originList")

      resTable2(start_dept, end_dept, axle_number, start_time, vehicle_type, order_source, data_source, ft_dist,
        ft_time, ft_coords, ft_tolls, ft_url, task_area_code, group_dist_min, rt_src, score, originList, inc_day)
    })
    labelDataRdd.toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_route_plan_res2")


  }


  def calTrajIntersect(groupSimRdd: RDD[JSONObject], schemeRouteRdd: RDD[JSONObject]): RDD[JSONObject] = {

    val groupSimRddNew = groupSimRdd.map(x => {

      val start_dept = JSONUtils.getJsonValue(x, "start_dept", "")
      val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
      val start_time = JSONUtils.getJsonValue(x, "start_time", "")
      val vehicle_type = JSONUtils.getJsonValue(x, "vehicle_type", "6")
      val axle_number = JSONUtils.getJsonValue(x, "axle_number", "2")
      val sim_group = JSONUtils.getJsonValue(x, "sim_group", "")
      x.put("axle_number", axle_number)

      ((start_dept, end_dept, start_time, vehicle_type, axle_number, sim_group), x)
    })
      .filter(obj => {
        val (start_dept, end_dept, start_time, vehicle_type, axle_number, sim_group) = obj._1
        StringUtils.nonEmpty(start_dept) || StringUtils.nonEmpty(end_dept) || StringUtils.nonEmpty(start_dept) || StringUtils.nonEmpty(sim_group)
      })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).flatMap(x => {
      val list = x._2.toList
      var month_freq = 0

      //month_freq 求和
      val listNew = list.map(obj => {
        val daily_freq = JSONUtils.getJsonValueInt(obj, "daily_freq", 0)
        month_freq += daily_freq
        obj
      }).map(obj => {
        obj.put("month_freq", month_freq)
        obj
      })
      listNew
    }).map(x => {
      val start_dept = JSONUtils.getJsonValue(x, "start_dept", "")
      val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
      val start_time = JSONUtils.getJsonValue(x, "start_time", "")
      val vehicle_type = JSONUtils.getJsonValue(x, "vehicle_type", "6")
      val axle_number = JSONUtils.getJsonValue(x, "axle_number", "2")
      val sim_group = JSONUtils.getJsonValue(x, "sim_group", "")
      ((start_dept, end_dept, start_time, vehicle_type, axle_number, sim_group), x)
    }).reduceByKey((obj1, obj2) => {
      mergeMonthFreq(obj1, obj2)
    }).map(_._2).filter(x => {
      StringUtils.nonEmpty(x.getString("rt_dist")) && (x.getDouble("rt_dist") > 1) && (x.getString("rt_coords").length > 8)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("groupSimRddNew数据量为：" + groupSimRddNew.count())
    groupSimRddNew.take(2).foreach(println(_))

    //合并数据
    val trajAllRddPre = groupSimRddNew.map(x => {
      x.put("data_source", "tracks")
      x
    }).union(schemeRouteRdd.map(x => {
      x.put("sim_group", 0)
      x.put("month_freq", 0)
      x
    })).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("trajAllRddPre数据量为：" + trajAllRddPre.count())
    trajAllRddPre.take(2).foreach(println(_))


    val trajAllRdd = trajAllRddPre.repartition(200).filter(x => {
      StringUtils.nonEmpty(x.getString("rt_dist")) && (x.getDouble("rt_dist") > 1) && (x.getString("rt_coords").length > 8)
    })

    logger.error("trajAllRdd数据量为：" + trajAllRdd.count())
    trajAllRdd.take(2).foreach(println(_))

    val calTrajRddPre = trajAllRdd.repartition(200).map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = x.getString("axle_number")

      ((start_time, start_dept, end_dept, vehicle_type, axle_number), x)
    }).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("calTrajRddPre数据量为：" + calTrajRddPre.count())
    calTrajRddPre.take(2).foreach(println(_))


    //    val calTrajRdd = calTrajRddPre.flatMap(x => {
    //      val list = x._2.toList.sortBy(_.getString("data_source")).map(x => {
    //        x.put("order_source", x.getString("data_source"))
    //        x
    //      })
    //      if (list.length > 0) {
    //        for (i <- (0 until (list.length))) {
    //          for (j <- (0 until (list.length))) {
    //            if (i != j && StringUtils.nonEmpty(list(i).getString("data_source"))
    //              && StringUtils.nonEmpty(list(j).getString("data_source"))
    //              && StringUtils.nonEmpty(list(i).getString("order_source"))
    //              && StringUtils.nonEmpty(list(j).getString("order_source"))
    //              && !list(i).getString("data_source").equals(list(j).getString("data_source"))
    //              && (!list(i).getString("order_source").contains(list(j).getString("data_source")) || list(j).getString("data_source").equals("tracks"))) {
    //              val addDataSourcej = list(j).getString("data_source")
    //              val addDataSourcei = list(i).getString("data_source")
    //
    //              //val similar = getSimilarInterface.getSimilar(list(i),list(j))
    //              val (minSimilar, maxSimilar) = getSimilarInterface.getSimilar2(list(i), list(j))
    //              print("*")
    //              //if(similar> 0.8){
    //              if (minSimilar >= 0.75 && maxSimilar >= 0.8) {
    //                //更新 month_freq
    //                if (addDataSourcej.equals("tracks") && !addDataSourcei.equals("tracks")) {
    //                  val month_freq_j = JSONUtils.getJsonValueInt(list(j), "month_freq", 0)
    //                  val month_freq_i = JSONUtils.getJsonValueInt(list(i), "month_freq", 0)
    //                  if (month_freq_j >= month_freq_i) {
    //                    list(i).put("month_freq", month_freq_j)
    //                  } else {
    //                    list(j).put("month_freq", month_freq_i)
    //                  }
    //                }
    //                print("+")
    //                val order_source1 = list(i).getString("order_source")
    //                val order_source2 = list(j).getString("order_source")
    //
    //                val concatNew1 = order_source1.concat("|").concat(addDataSourcej)
    //                val concatNew2 = order_source2.concat("|").concat(addDataSourcei)
    //
    ////                if ((!StringUtils.nonEmpty(order_source1) || !order_source1.contains(addDataSourcej)) && !list(i).getString("data_source").equals("tracks")) {
    //                if ((!StringUtils.nonEmpty(order_source1) || !order_source1.contains(addDataSourcej))) {
    //                  list(i).put("order_source", concatNew1)
    //                }
    //                //if ((!StringUtils.nonEmpty(order_source2) || !order_source2.contains(addDataSourcei)) && !list(j).getString("data_source").equals("tracks")) {
    //                if ((!StringUtils.nonEmpty(order_source2) || !order_source2.contains(addDataSourcei))) {
    //                  list(j).put("order_source", concatNew2)
    //                }
    //              }
    //            }
    //          }
    //        }
    //      }
    //      list
    //    }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    val calTrajRdd = calTrajRddPre.mapPartitionsWithIndex((index, iter) => {
      val limitMin = 20000
      val partitionLimitMinu = limitMin * 0.9 / 90
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }
        val list = x._2.toList.sortBy(_.getString("data_source")).map(x => {
          x.put("order_source", x.getString("data_source"))
          x
        })
        if (list.length > 0) {
          for (i <- (0 until (list.length))) {
            for (j <- (0 until (list.length))) {
              if (i != j && StringUtils.nonEmpty(list(i).getString("data_source"))
                && StringUtils.nonEmpty(list(j).getString("data_source"))
                && StringUtils.nonEmpty(list(i).getString("order_source"))
                && StringUtils.nonEmpty(list(j).getString("order_source"))
                && !list(i).getString("data_source").equals(list(j).getString("data_source"))
                && ((!list(i).getString("order_source").contains(list(j).getString("data_source"))) || list(j).getString("data_source").equals("tracks"))) {
                val addDataSourcej = list(j).getString("data_source")
                val addDataSourcei = list(i).getString("data_source")

                //val similar = getSimilarInterface.getSimilar(list(i),list(j))
                val (minSimilar, maxSimilar) = getSimilarInterface.getSimilar2(list(i), list(j))
                print("*")
                //if(similar> 0.8){
                if (minSimilar >= 0.75 && maxSimilar >= 0.8) {
                  //更新 month_freq
                  if (addDataSourcej.equals("tracks") && !addDataSourcei.equals("tracks")) {
                    val month_freq_j = JSONUtils.getJsonValueInt(list(j), "month_freq", 0)
                    val month_freq_i = JSONUtils.getJsonValueInt(list(i), "month_freq", 0)
                    if (month_freq_j >= month_freq_i) {
                      list(i).put("month_freq", month_freq_j)
                    } else {
                      list(j).put("month_freq", month_freq_i)
                    }
                  }
                  print("+")
                  val order_source1 = list(i).getString("order_source")
                  val order_source2 = list(j).getString("order_source")

                  val concatNew1 = order_source1.concat("|").concat(addDataSourcej)
                  val concatNew2 = order_source2.concat("|").concat(addDataSourcei)

                  //                if ((!StringUtils.nonEmpty(order_source1) || !order_source1.contains(addDataSourcej)) && !list(i).getString("data_source").equals("tracks")) {
                  if ((!StringUtils.nonEmpty(order_source1)) || (!order_source1.contains(addDataSourcej))) {
                    list(i).put("order_source", concatNew1)
                  }
                  //if ((!StringUtils.nonEmpty(order_source2) || !order_source2.contains(addDataSourcei)) && !list(j).getString("data_source").equals("tracks")) {
                  if ((!StringUtils.nonEmpty(order_source2)) || (!order_source2.contains(addDataSourcei))) {
                    list(j).put("order_source", concatNew2)
                  }
                }
              }
            }
          }
        }
        list
      }).flatten
    })


    calTrajRdd
  }


  def schemaRoute(spark: SparkSession, inc_day: String, markUnVerifyRdd: RDD[JSONObject]): RDD[JSONObject] = {

    val inc_day_next = DateTimeUtil.getLastMonthMonday(inc_day, "yyyyMMdd")


    val schemRouteRdd = getRouteInterface(markUnVerifyRdd).filter(x => {
      StringUtils.nonEmpty(x.getString("rt_coords"))
    }).map(x => {
      //20210622增加rt_time转换逻辑
      val rt_time = JSONUtils.getJsonValueInt(x, "rt_time", 0) / 60
      x.put("rt_time", rt_time)
      x
    })
    schemRouteRdd
  }


  def getRouteInterface(repRdd: RDD[JSONObject]): RDD[JSONObject] = {
    logger.error("开始调用gd，jy，ct接口")

    val limitMin = 10000
    val resRdd = repRdd.repartition(200).mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 100
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }

        val axle_number = x.getIntValue("axle_number")
        val x1 = x.getDouble("x1")
        val y1 = x.getDouble("y1")
        val x2 = x.getDouble("x2")
        val y2 = x.getDouble("y2")
        val vehicle_type = x.getIntValue("vehicle_type")
        val start_dept = JSONUtils.getJsonValue(x, "start_dept", "")
        val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
        val task_area_code = JSONUtils.getJsonValue(x, "task_area_code", "")

        val plan_date = x.getString("plan_date")
        val line_code = x.getString("line_code")
        val height = JSONUtils.getJsonValue(x, "height", "")
        val axle_weight = JSONUtils.getJsonValue(x, "axle_weight", "")
        val vehicle = JSONUtils.getJsonValue(x, "vehicle", "")
        val vehicle_color = JSONUtils.getJsonValue(x, "vehicle_color", "")
        val energy = JSONUtils.getJsonValueInt(x, "energy", 0)
        val width = JSONUtils.getJsonValueDouble(x, "width", 0.0)
        val length = JSONUtils.getJsonValueDouble(x, "length", 0.0)
        val passport = JSONUtils.getJsonValue(x, "passport", "100000")
        val emitStand = JSONUtils.getJsonValue(x, "emitStand", "")
        val start_time = JSONUtils.getJsonValue(x, "start_time", "0000")

        //传入plan_date  传入length
        val (gdJson, gdErrLog) = scheduleGdTraj(axle_number, x1, y1, x2, y2, vehicle_type, plan_date)
        val (jyJson, jyErrLog) = scheduleJYTraj(axle_number, x1, y1, x2, y2, vehicle_type, plan_date)
        val (ctJson, ctErrLog) = scheduleCTTraj(axle_number, x1, y1, x2, y2, vehicle_type, plan_date)
        println("*******")
        val buffer = new ArrayBuffer[JSONObject]()
        buffer.append(gdJson)

        for (i <- (0 until (jyJson.size())) if StringUtils.nonEmpty(jyJson.toString())) {
          buffer.append(jyJson.getJSONObject(i))
        }
        for (i <- (0 until (ctJson.size())) if StringUtils.nonEmpty(ctJson.toString())) {
          buffer.append(ctJson.getJSONObject(i))
        }
        buffer.map(obj => {
          //          val trajJson = parseScheduleTrajJson(obj)
          val trajJson = new JSONObject()
          trajJson.fluentPutAll(obj)
          trajJson.put("plan_date", plan_date)
          trajJson.put("line_code", line_code)
          trajJson.put("start_dept", start_dept)
          trajJson.put("end_dept", end_dept)
          trajJson.put("vehicle_type", vehicle_type)
          trajJson.put("height", height)
          trajJson.put("axle_weight", axle_weight)
          trajJson.put("vehicle_color", vehicle_color)
          trajJson.put("energy", energy)
          trajJson.put("width", width)
          trajJson.put("length", length)
          trajJson.put("passport", passport)
          trajJson.put("emitStand", emitStand)
          trajJson.put("axle_number", axle_number)
          trajJson.put("start_time", start_time)
          trajJson.put("task_area_code", task_area_code)
          trajJson.put("gdErrLog", gdErrLog)
          trajJson.put("jyErrLog", jyErrLog)
          trajJson.put("ctErrLog", ctErrLog)
          trajJson
        })
      })
    }).flatMap(x => x).filter(x => {
      val rt_src = x.getString("rt_src")
      !("rp-jy".equals(rt_src) || "rp-jy_geo".equals(rt_src) || "rp-jy-join".equals(rt_src))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调用轨迹规划的数据量为：" + resRdd.count())
    resRdd.take(2).foreach(println(_))

    resRdd

  }


  def calOntimeRate(middle0DF: DataFrame, middle1DF: DataFrame, inc_day: String) = {
    val columns1 = middle0DF.columns
    val middle0Rdd = middle0DF.rdd.map(x => {
      val json = new JSONObject()
      for (column <- columns1) {
        json.put(column, x.getAs[String](column))
      }
      json
    })

    val columns2 = middle1DF.columns
    val middle1Rdd = middle1DF.rdd.map(x => {
      val json = new JSONObject()
      for (column <- columns2) {
        json.put(column, x.getAs[String](column))
      }
      json
    })

    val ontime8090Rdd1 = middle0Rdd.repartition(240).map(x => {
      // line_code、start_time、start_dept、end_dept、actual_run_time、plan_run_time、inc_day、vehicle_type
      val jo = new JSONObject()

      val line_code = x.getString("line_code")
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val actual_run_time = x.getInteger("actual_run_time")
      val plan_run_time = x.getInteger("plan_run_time")
      val inc_day = x.getString("inc_day")
      val vehicle_type = if (x.getIntValue("vehicle_type") == 0) 6 else x.getIntValue("vehicle_type")
      jo.put("line_code", line_code)
      jo.put("start_time", start_time)
      jo.put("start_dept", start_dept)
      jo.put("end_dept", end_dept)
      jo.put("actual_run_time", actual_run_time)
      jo.put("plan_run_time", plan_run_time)
      jo.put("inc_day", inc_day)
      jo.put("vehicle_type", vehicle_type)

      //以start_time、start_dept、end_dept、vehicle_type分组
      ((start_time, start_dept, end_dept, vehicle_type), jo)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("ontime8090Rdd1的数据量为：" + ontime8090Rdd1.count())
    ontime8090Rdd1.take(2).foreach(println(_))

    val ontime8090Rdd2 = ontime8090Rdd1.groupByKey().repartition(240).map(x => {
      val list = x._2.toList

      //判断组内时效中位数 mid_time
      val midList = list.toStream.sortBy(obj => {
        JSONUtils.getJsonValueInt(obj, "actual_run_time", 0)
      })
      val mid_time_index = Math.floor(list.size / 2).toInt

      val mid_time = JSONUtils.getJsonValueInt(midList(mid_time_index), "actual_run_time", 0)


      val list2 = list.map(obj => {
        val plan_run_time = JSONUtils.getJsonValueInt(obj, "plan_run_time", 0)
        val actual_run_time = JSONUtils.getJsonValueInt(obj, "actual_run_time", 0)
        //过滤异常值
        if (actual_run_time > 0.5 * mid_time && actual_run_time < 1.5 * mid_time) {
          obj.put("errTag", "0")
        } else {
          obj.put("errTag", "1")
        }

        //计算历史准点率
        if (plan_run_time >= actual_run_time - 1) {
          obj.put("ontimeTag", "1")
        } else {
          obj.put("ontimeTag", "0")
        }
        obj
      })


      val list3 = list2.filter(x => {
        !"1".equals(JSONUtils.getJsonValue(x, "errTag", ""))
      })
      val historyOntimeCnt = list3.filter(x => {
        "1".equals(JSONUtils.getJsonValue(x, "ontimeTag", ""))
      }).size

      val historyOntimeRatio = historyOntimeCnt.toDouble / list3.size

      //20210622计算逻辑更改，取最大值和最小值的差，等分为100份，再取80分位值 90分位值
      //val p8Index = Math.floor(list3.size * 0.8).toInt
      //val p9Index = Math.floor(list3.size * 0.94).toInt

      var time_p8 = 0
      var time_p9 = 0

      if (list3.size > 0 && list3 != null) {
        val listNew = list3.sortBy(x => {
          JSONUtils.getJsonValueInt(x, "actual_run_time", 0)
        })

        //20210622计算逻辑更改，取最大值和最小值的差，等分为100份，再取80分位值 90分位值
        val maxActualRunTime = list3.maxBy(x => {
          JSONUtils.getJsonValueInt(x, "actual_run_time", 0)
        }).getIntValue("actual_run_time")
        val minActualRuntime = list3.minBy(x => {
          JSONUtils.getJsonValueInt(x, "actual_run_time", 0)
        }).getIntValue("actual_run_time")
        val diffTime = maxActualRunTime - minActualRuntime

        val time_p8_pre = minActualRuntime + Math.floor((0.8 * diffTime)).toInt
        val time_p9_pre = minActualRuntime + Math.floor((0.95 * diffTime)).toInt
        //val time_p8_pre = JSONUtils.getJsonValueInt(listNew(p8Index),"actual_run_time",0)
        //val time_p9_pre = JSONUtils.getJsonValueInt(listNew(p9Index),"actual_run_time",0)

        val numberP8 = (time_p8_pre % 10)
        var numberP8New = numberP8 match {
          case numberP8 if (numberP8 == 0 || numberP8 == 1 || numberP8 == 2) => 0
          case numberP8 if (3 to 7 contains numberP8) => 5
          case numberP8 if (numberP8 == 8 || numberP8 == 9) => 10
        }


        val numberP9 = (time_p9_pre % 10)
        var numberP9New = numberP9 match {
          case numberP8 if (numberP8 == 0 || numberP8 == 1 || numberP8 == 2) => 0
          case numberP8 if (3 to 7 contains numberP8) => 5
          case numberP8 if (numberP8 == 8 || numberP8 == 9) => 10
        }

        //如果小于20分钟，只进，不退
        if (time_p8_pre < 20) {
          val numberP8 = (time_p8_pre % 10)
          numberP8New = numberP8 match {
            case numberP8 if (numberP8 == 0) => 0
            case numberP8 if (1 to 5 contains numberP8) => 5
            case numberP8 if (6 to 10 contains numberP8) => 10
          }
        }

        //如果小于20分钟，只进，不退
        if (time_p8_pre < 20) {
          val numberP9 = (time_p9_pre % 10)
          numberP9New = numberP9 match {
            case numberP9 if (numberP9 == 0) => 0
            case numberP9 if (1 to 5 contains numberP9) => 5
            case numberP9 if (6 to 10 contains numberP9) => 10
          }
        }

        time_p8 = time_p8_pre - numberP8 + numberP8New
        time_p9 = time_p9_pre - numberP9 + numberP9New

      }

      (x._1, list3, time_p8, time_p9, historyOntimeRatio)
      //过滤组内记录数小于3的记录 .filter(_._2.size > 3)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("ontime8090Rdd2的数据量为：" + ontime8090Rdd2.count())
    ontime8090Rdd2.take(2).foreach(println(_))

    val ontime8090Rdd3 = ontime8090Rdd2.repartition(240).map(x => {

      //计算80时效、90时效可达准点率

      val (key, list, time_p8, time_p9, his_ontime_rate) = x

      val list2 = list.map(obj => {
        val plan_run_time = JSONUtils.getJsonValueInt(obj, "plan_run_time", 0)
        val actual_run_time = JSONUtils.getJsonValueInt(obj, "actual_run_time", 0)
        if (actual_run_time - 1 <= time_p8) {
          obj.put("ontime80", 1)
        } else {
          obj.put("ontime80", 0)
        }
        if (actual_run_time - 1 <= time_p9) {
          obj.put("ontime90", 1)
        } else {
          obj.put("ontime90", 0)
        }
        obj
      })
      val ontime80 = list2.filter(x => {
        "1".equals(JSONUtils.getJsonValue(x, "ontime80", ""))
      }).size
      val ontime90 = list2.filter(x => {
        "1".equals(JSONUtils.getJsonValue(x, "ontime90", ""))
      }).size

      var groupCnt = 1
      if (list2.size > 3) {
        groupCnt = list2.size
      }
      val ontime80Ratio = ontime80.toDouble / groupCnt
      val ontime90Ratio = ontime90.toDouble / groupCnt


      val (start_time, start_dept, end_dept, vehicle_type) = x._1


      val jo = new JSONObject()
      jo.put("start_time", start_time)
      jo.put("start_dept", start_dept)
      jo.put("end_dept", end_dept)
      jo.put("vehicle_type", vehicle_type)

      jo.put("time_p8", time_p8)
      jo.put("time_p9", time_p9)
      jo.put("his_ontime_rate", his_ontime_rate)
      jo.put("ontime80Ratio", ontime80Ratio)
      jo.put("ontime90Ratio", ontime90Ratio)
      jo.put("groupCnt", groupCnt)

      ((start_time, start_dept, end_dept, vehicle_type), jo)
    }).filter(x => {
      JSONUtils.getJsonValueInt(x._2, "groupCnt", 0) > 3
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ontime8090Rdd3的数据量为：" + ontime8090Rdd3.count())

    val dept8090Rdd = middle1Rdd.filter(x => {
      StringUtils.nonEmpty(x.getString("rt_dist")) && !StringUtils.nonEmpty(x.getString("abnormal"))
    }).repartition(240).map(x => {
      //start_time、start_dept、end_dept、inc_day、vehicle_type、rt_dist
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val inc_day = x.getString("inc_day")
      val vehicle_type = if (x.getIntValue("vehicle_type") == 0) 6 else x.getIntValue("vehicle_type")
      val rt_dist = x.getDouble("rt_dist")

      ((start_time, start_dept, end_dept, vehicle_type), x)
    }).groupByKey().map(x => {
      val list = x._2.toList.sortBy(obj => {
        JSONUtils.getJsonValueDouble(obj, "rt_dist", 0.0)
      })
      val size = list.size
      val maxRtDist = list.maxBy(obj => {
        JSONUtils.getJsonValueDouble(obj, "rt_dist", 0.0)
      }).getDouble("rt_dist")
      val minRtDist = list.minBy(obj => {
        JSONUtils.getJsonValueDouble(obj, "rt_dist", 0.0)
      }).getDouble("rt_dist")
      val diffDist = maxRtDist - minRtDist
      val dist_p8 = minRtDist + Math.floor(diffDist * 0.8)
      val dist_p9 = minRtDist + Math.floor(diffDist * 0.9)

      //      val size80 = Math.floor(size * 0.8).toInt
      //      val size90 = Math.floor(size * 0.9).toInt
      //      val dist_p8 = JSONUtils.getJsonValueDouble(list(size80),"rt_dist",0)
      //      val dist_p9 = JSONUtils.getJsonValueDouble(list(size90),"rt_dist",0)

      (x._1, (dist_p8, dist_p9))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dept8090Rdd的数据量为：" + dept8090Rdd.count())
    dept8090Rdd.take(2).foreach(println(_))


    val historyOntimeDept = ontime8090Rdd3.leftOuterJoin(dept8090Rdd).repartition(240).map(x => {
      val (start_time, start_dept, end_dept, vehicle_type) = x._1
      val leftBody = x._2._1

      val time_p8 = JSONUtils.getJsonValueInt(leftBody, "time_p8", 0)
      val time_p9 = JSONUtils.getJsonValueInt(leftBody, "time_p9", 0)
      val his_ontime_rate = JSONUtils.getJsonValueDouble(leftBody, "his_ontime_rate", 0.0)
      val ontime80Ratio = JSONUtils.getJsonValue(leftBody, "ontime80Ratio", "")
      val ontime90Ratio = JSONUtils.getJsonValue(leftBody, "ontime90Ratio", "")
      val groupCnt = JSONUtils.getJsonValueInt(leftBody, "groupCnt", 0)

      var (dist_p8, dist_p9) = (0.0, 0.0)
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        val tuple89 = rightOption.get
        dist_p8 = tuple89._1
        dist_p9 = tuple89._2
        leftBody.put("dist_p8", dist_p8)
        leftBody.put("dist_p9", dist_p9)
      }

      leftBody

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    historyOntimeDept
  }

  def getGroupSim(spark: SparkSession, inc_day: String): RDD[JSONObject] = {

    //待修改获取上个月
    //    val beginDay = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -30)
    //    val endDay = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 2)
    val beginDay = "20210929"
    val endDay = "20211101"

    //    val simSql =
    //      s"""
    //         |select
    //         |  *
    //         |from
    //         | dm_gis.eta_traj_simgroup_info
    //         |where
    //         |  inc_day >='${beginDay}'
    //         |and
    //         |  inc_day <= '${inc_day}'
    //         |and
    //         |(group_day_min	!='' or group_day_min is not null)
    //       """.stripMargin
    val simSql =
    s"""
       |select
       |  *
       |from
       | dm_gis.eta_traj_simgroup_info
       |where
       |  inc_day >= '${beginDay}'
       |and
       |  inc_day <= '${endDay}'
       |and
       |  typical_tag = '1'
       |and
       |  (abnormal is null or abnormal ='')
       | -- and
       | -- task_area_code in ('999Y','595Y')
       | -- and
       | -- line_code in ('793VA510WF0010')
       | -- and line_code in ('872D019872B1800','372D008372G1700','769MF769VM2135','757EE757NLD2200','023JJ023R1930','911BA911VA1815','021KH021WB2040','021LA021R1905')             """.stripMargin

    val groupSimRddInput = spark.sql(simSql)
    val colList = groupSimRddInput.columns
    val groupSimRdd = groupSimRddInput.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns, x.getAs[String](columns))
      }
      jo
    })
    groupSimRdd
  }


  def getJoinRdd(taskInfoRdd: RDD[(String, JSONObject)], carInfoRdd: RDD[(String, JSONObject)]): RDD[JSONObject] = {

    val joinRdd = taskInfoRdd.leftOuterJoin(carInfoRdd).map(x => {
      val left = x._2._1
      val rightOp = x._2._2

      if (rightOp.nonEmpty) {
        left.fluentPutAll(rightOp.get)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    joinRdd
  }

  def getMaxIncDayRow(obj1: JSONObject, obj2: JSONObject): _root_.com.alibaba.fastjson.JSONObject = {
    val obj1IncDay = obj1.getString("inc_day")
    val obj2IncDay = obj2.getString("inc_day")

    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }

    if (StringUtils.nonEmpty(obj1IncDay) && StringUtils.nonEmpty(obj2IncDay) && obj1IncDay >= obj2IncDay) {
      obj1
    } else {
      obj2
    }

  }


  def getbatchAllTb(spark: SparkSession, inc_day: String) = {
    val inc_day_pre_month = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -30)

    //    val (start_Day, end_day) =
    //      if (inc_day.endsWith("8")) {
    //        DateTimeUtil.getMonthBeginEnd(inc_day, "yyyyMMdd")
    //      } else {
    //        DateTimeUtil.getMonthMidBeginEnd(inc_day, "yyyyMMdd")
    //      }
    val start_day = "2021-11-03"
    val end_day = "2021-11-09"


    val departureTimeStart = DateTimeUtil.getDaysApartDate("yyyy-MM-dd", start_day, -3)
    val departureTimeEnd = DateTimeUtil.getDaysApartDate("yyyy-MM-dd", end_day, 3)

    val un_effective_tm = departureTimeStart


    val schaPlanSql =
      s"""
         |select
         |  latest_arrival_tm,dept_code,batch_code,send_tm,inc_day,2 data_type,line_code,cvy_name
         |from
         |  (
         |    select
         |      row_number() over(
         |        PARTITION by dept_code,
         |        send_batch,
         |        latest_arrival_tm,
         |        send_tm
         |        ORDER by
         |          inc_day desc
         |      ) as rn,
         |      latest_arrival_tm,
         |      dept_code,
         |      send_batch as batch_code,
         |      send_tm,
         |      omcs_line_code as line_code, --1108新增获取字段
         |      cvy_name, --1108新增获取字段
         |      inc_day
         |    from
         |      (
         |        select
         |          *
         |        from
         |          dm_pass_rss.scha_tt_plan_point_pro t
         |        where
         |          inc_day='${inc_day}'
         |          and plan_run_dt >= '${departureTimeStart}'
         |          and plan_run_dt <= '${departureTimeEnd}'
         |          and latest_arrival_tm is not null
         |          and send_batch is not null
         |          and send_batch != ''
         |          and job_type in ('1', '2', '3')
         |          and point_mean != 3
         |          and point_type = 1
         |      ) a
         |      inner join (
         |        SELECT
         |          distinct(id) as id,cvy_name,omcs_line_code
         |        from
         |          dm_pass_rss.scha_tt_plan_main_pro
         |        where
         |          inc_day = '${inc_day}'
         |          and oper_type in (1, 2)
         |      ) b on a.plan_main_id = b.id
         |  ) a
         |where
         |  rn = 1
           """.stripMargin

    val airControlSql =
      s"""
         |select
         |  latest_arrival_tm,dept_code,batch_code,send_tm,inc_day,2 data_type,line_code,cvy_name
         |from
         |  (
         |    select
         |      row_number() over(
         |        PARTITION by src_dept_code,
         |        src_send_batch,
         |        lastest_arrive_tm,
         |        src_send_tm
         |        ORDER by
         |          inc_day desc
         |      ) as rn,
         |      lastest_arrive_tm as latest_arrival_tm,
         |      src_dept_code as dept_code,
         |      src_send_batch as batch_code,
         |      src_send_tm as send_tm,  --新增字段:发车时间
         |      line_code, --新增字段:运力
         |      cvy_name, --新增字段:运力名称
         |      inc_day
         |    from
         |      dm_pass_rss.aira_tm_air_transport_batch_pro t
         |    where
         |      send_date >= '${departureTimeStart}'
         |      and send_date <= '${departureTimeEnd}'
         |      and inc_day ='${inc_day}'
         |      and practical_cvy_type = 1
         |      and lastest_arrive_tm != ''
         |      and lastest_arrive_tm is not null
         |  ) a
         |where
         |  a.rn = 1
           """.stripMargin


    //    val receiveSql =
    //      s"""
    //         |select
    //         |  latest_arrival_tm,dept_code,batch_code,workday work_day,
    //         |  un_effective_tm,
    //         |  effective_tm,
    //         |  inc_day,
    //         |  0 data_type
    //         |from
    //         |  (
    //         |    select
    //         |      row_number() over(
    //         |        PARTITION by batch_code,
    //         |        workday,
    //         |        last_indepot_tm
    //         |        ORDER by
    //         |          inc_day desc
    //         |      ) as rn,
    //         |      substr(concat(last_indepot_tm,':00'), 2, 8) latest_arrival_tm,
    //         |      operate_zone_code  as dept_code,
    //         |      batch_code,
    //         |      workday,
    //         |      un_effective_tm,  --新增字段  失效日期
    //         |      effective_tm,  --新增字段  生效日期
    //         |      inc_day
    //         |    from
    //         |      dm_pass_rss.sbsa_tm_pickup_depot_pro
    //         |    where
    //         |      inc_day = '${inc_day}'
    //         |      and data_state = 1
    //         |      and delete_flg = 0
    //         |      and un_effective_tm >= '${departureTimeStart}'
    //         |  ) a
    //         |where
    //         |  rn= 1
    //           """.stripMargin

    val dispatchSql =
      s"""
         |select
         |  latest_arrival_tm,dept_code,batch_code,workday work_day,
         |  un_effective_tm,
         |  effective_tm,
         |  inc_day,
         |  1 data_type,
         |  '' line_code, '' cvy_name
         |from
         |  (
         |    select
         |      row_number() over(
         |        PARTITION by batch_code,
         |        workday,
         |        last_arrive_tm
         |        ORDER by
         |          inc_day desc
         |      ) as rn,
         |      substr(concat(last_arrive_tm,':00'), 2, 8) latest_arrival_tm,
         |      operate_zone_code  as dept_code,
         |      batch_code,
         |      workday,
         |      un_effective_tm,  --新增字段  失效日期
         |      effective_tm,  --新增字段  生效日期
         |      inc_day
         |    from
         |      dm_pass_rss.sbsa_tm_deliver_depot_pro
         |    where
         |      inc_day = '${inc_day}'
         |      -- and data_state = 1
         |      and delete_flg = 0
         |      and un_effective_tm >= '${departureTimeStart}'
         |  ) a
         |where
         |  rn= 1
           """.stripMargin

    //    val receiveDF = spark.sql(receiveSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("receiveDF的数据量为：" + receiveDF.count())
    //    logger.error("receiveSql为：" + receiveSql)
//    val airControlRdd = spark.sql(airControlSql).persist(StorageLevel.MEMORY_AND_DISK_SER)



//    val dispatchDF = spark.sql(dispatchSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("dispatchDF的数据量为：" + dispatchDF.count())
//    logger.error("dispatchSql为：" + dispatchSql)

//    val schaPlanRdd = spark.sql(schaPlanSql).persist(StorageLevel.MEMORY_AND_DISK_SER)

//    val dispatch_receive_Col = dispatchDF.columns
//    val dispatch_receive_Rdd1 = dispatchDF
//      //.union(receiveDF)
//      .rdd.repartition(100).map(x => {
//      val jo = new JSONObject()
//      for (columns <- dispatch_receive_Col) {
//        jo.put(columns, x.getAs[String](columns))
//      }
//      jo
//    })


        val dispatch_receive_Rdd = spark.read.format("csv").option("header", "false").option("delimiter", "\t").load("d:\\user\\01401062\\桌面\\etatest1.csv").rdd.repartition(6).map(x => {
          val json = JSON.parseObject(x.mkString(""))
          json
        })



    //    val dispatch_receive_str = "{\"dept_code\":\"027EB\",\"line_code\":\"\",\"work_day\":\"1234567\",\"inc_day\":\"20211030\",\"data_type\":1,\"cvy_name\":\"\",\"un_effective_tm\":253402185600000,\"effective_tm\":1613577600000,\"latest_arrival_tm\":\"08:00:00\",\"batch_code\":\"027EB01D\"}\n{\"dept_code\":\"027EB\",\"line_code\":\"\",\"work_day\":\"1234567\",\"inc_day\":\"20211030\",\"data_type\":1,\"cvy_name\":\"\",\"un_effective_tm\":253402185600000,\"effective_tm\":1622908800000,\"latest_arrival_tm\":\"09:25:00\",\"batch_code\":\"027EB02D\"}\n{\"dept_code\":\"027EB\",\"line_code\":\"\",\"work_day\":\"1234567\",\"inc_day\":\"20211030\",\"data_type\":1,\"cvy_name\":\"\",\"un_effective_tm\":253375747200000,\"effective_tm\":1613664000000,\"latest_arrival_tm\":\"12:50:00\",\"batch_code\":\"027EB03D\"}\n{\"dept_code\":\"027EB\",\"line_code\":\"\",\"work_day\":\"1234567\",\"inc_day\":\"20211030\",\"data_type\":1,\"cvy_name\":\"\",\"un_effective_tm\":253402185600000,\"effective_tm\":1613664000000,\"latest_arrival_tm\":\"15:00:00\",\"batch_code\":\"027EB04D\"}\n{\"dept_code\":\"027EB\",\"line_code\":\"\",\"work_day\":\"1234567\",\"inc_day\":\"20211030\",\"data_type\":1,\"cvy_name\":\"\",\"un_effective_tm\":253402185600000,\"effective_tm\":1630771200000,\"latest_arrival_tm\":\"16:50:00\",\"batch_code\":\"027EB05D\"}\n{\"dept_code\":\"027EB\",\"line_code\":\"\",\"work_day\":\"12345\",\"inc_day\":\"20211030\",\"data_type\":1,\"cvy_name\":\"\",\"un_effective_tm\":253402185600000,\"effective_tm\":1613923200000,\"latest_arrival_tm\":\"19:30:00\",\"batch_code\":\"027EB06D\"}"
//    val json = JSON.parseObject(dispatch_receive_str)
//    val dispatch_receive_Rdd = spark.sparkContext.parallelize(List(json))
    dispatch_receive_Rdd.take(10).foreach(println(_))

    val buffer = DateTimeUtil.getDateInterval(departureTimeStart, departureTimeEnd, "yyyy-MM-dd", "yyyy-MM-dd")
    println(buffer.mkString("|"))


    val dispatch_receive_Rdd1 =dispatch_receive_Rdd

      .flatMap(x => {
      val list = new ArrayBuffer[JSONObject]()
      val buffer = DateTimeUtil.getDateInterval(departureTimeStart, departureTimeEnd, "yyyy-MM-dd", "yyyy-MM-dd")
      val latest_arrival_tm = x.getString("latest_arrival_tm")
      val dept_code = x.getString("dept_code")
      val batch_code = x.getString("batch_code")
      val inc_day = x.getString("inc_day")
      val work_day = JSONUtils.getJsonValue(x, "work_day", "1234567")
      val un_effective_tm = JSONUtils.getJsonValue(x, "un_effective_tm", "9999-12-31")
      val effective_tm = JSONUtils.getJsonValue(x, "effective_tm", "2000-01-01")
      val data_type = x.getString("data_type")

      buffer.map(obj => {
        val jo = new JSONObject()
        val latest_arrival_tm_new = obj + " " + latest_arrival_tm
        jo.put("latest_arrival_tm", latest_arrival_tm_new)
        jo.put("dept_code", dept_code)
        jo.put("batch_code", batch_code)
        jo.put("data_type", data_type)
        jo.put("inc_day", inc_day)

        val currentWeekDay = DateTimeUtil.judgeWeekDay(obj, "yyyy-MM-dd").toString

        if (StringUtils.nonEmpty(work_day) && work_day.contains(currentWeekDay)) {
          if (obj >= effective_tm && obj <= un_effective_tm) {
            list.append(jo)
          }
        }
      })
      list
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dispatch_receive_Rdd1的数据量为：" + dispatch_receive_Rdd1.count())
    dispatch_receive_Rdd1.take(100).foreach(println(_))



//    import spark.implicits._
//
//
//    val dispatch_receive_Rdd = dispatch_receive_Rdd1.map(x => {
//      val latest_arrival_tm = x.getString("latest_arrival_tm")
//      val dept_code = x.getString("dept_code")
//      val batch_code = x.getString("batch_code")
//      val inc_day = x.getString("inc_day")
//      val send_tm = ""
//      val data_type = x.getString("data_type")
//
//      batch(latest_arrival_tm, dept_code, batch_code, send_tm, inc_day, data_type,"","")
//
//    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("dispatch_receive_Rdd的数据量为：" + dispatch_receive_Rdd.count())
//    dispatch_receive_Rdd.take(2).foreach(println(_))
//
//    val batchAllDF = dispatch_receive_Rdd.union(airControlRdd).union(schaPlanRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("batchAllDF数据量为：" + batchAllDF.count())
//    batchAllDF.take(2).foreach(println(_))
//
//    //    receiveDF.unpersist()
//    airControlRdd.unpersist()
//    dispatchDF.unpersist()
//    schaPlanRdd.unpersist()
//    batchAllDF.unpersist()
//    dispatch_receive_Rdd1.unpersist()
//
//    val batchAllColums = batchAllDF.columns
//
//    val batchAllRdd = batchAllDF.rdd.repartition(100).map(x => {
//      val jo = new JSONObject()
//      for (columns <- batchAllColums) {
//        jo.put(columns, x.getAs[String](columns))
//      }
//      jo
//    }).map(x => {
//      val dept_code = x.getString("dept_code")
//      val latest_arrival_tm = x.getString("latest_arrival_tm")
//      val batch_code = x.getString("batch_code")
//      val send_tm = x.getString("send_tm")
//      val data_type = x.getString("data_type")
//
//      ((dept_code, latest_arrival_tm, batch_code, send_tm, data_type), x)
//    })
//      //# 去重 根据dept_code, latest_arrival_tm, batch_code,send_tm,去重,取inc_day最大的一条
//      .reduceByKey((obj1, obj2) => getMaxIncDayRow(obj1, obj2))
//
//      // # 分类 0代表收仓班次，1代表派仓班次，2代表中转班次
//      .map(x => {
//      val (dept_code, latest_arrival_tm, batch_code, send_tm, data_type) = x._1
//
//      ((dept_code, data_type), x._2)
//    })
//
//    logger.error("batchAllRdd的数据量为" + batchAllRdd.count())
//
//
//    // # 排序 根据dept_code, data_type, send_tm, latest_arrival_tm增序排序 获取每个班次的上一班次最晚到车时间last_batch_last_tm 上一班次的班次编码last_batch_code
//    val batchAllRdd2 = batchAllRdd.groupByKey().flatMap(x => {
//
//      val (dept_code, data_type) = x._1
//
//      //增加对send_time的排序,对latest_arrival_tm进行二次排序
//
//      val list = if (!"2".equals(data_type)) {
//        x._2.toList.sortBy(x => JSONUtils.getJsonValue(x, "latest_arrival_tm", "00:00"))
//      } else {
//        x._2.toList.sortBy(x => new SecondarySortByKeyString(JSONUtils.getJsonValue(x, "send_tm", "00:00"), JSONUtils.getJsonValue(x, "latest_arrival_tm", departureTimeStart + "00:00:00")))
//      }
//
//      if (list.size > 1) {
//        for (i <- Range(0, list.size)) {
//          if (i == 0) {
//            list(0).put("last_batch_last_tm", "")
//            list(0).put("last_batch_code", "")
//          } else {
//            val last_batch_last_tm = list(i - 1).getString("latest_arrival_tm")
//            val last_batch_code = list(i - 1).getString("batch_code")
//
//            list(i).put("last_batch_last_tm", last_batch_last_tm)
//            list(i).put("last_batch_code", last_batch_code)
//          }
//        }
//      }
//      list
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    logger.error("batchAllRdd2的数据量为：" + batchAllRdd2.count())
//
//    val batchAllTb = batchAllRdd2.map(x => {
//      val dept_code = x.getString("dept_code")
//      val latest_arrival_tm = x.getString("latest_arrival_tm")
//      val batch_code = JSONUtils.getJsonValue(x, "batch_code", "")
//      val last_batch_last_tm = x.getString("last_batch_last_tm")
//      val last_batch_code = x.getString("last_batch_code")
//      val send_tm = x.getString("send_tm")
//      val data_type = x.getString("data_type")
//
//      // TODO: 20211109新增取数字段
//      val line_code = JSONUtils.getJsonValue(x, "line_code", "")
//      val cvy_name = JSONUtils.getJsonValue(x, "cvy_name", "")
//
//      val batch_type = batch_code match {
//        case batch_code if StringUtils.isEmpty(batch_code) => 2
//        case batch_code if batch_code.endsWith("P") => 0
//        case batch_code if batch_code.endsWith("D") => 1
//        case _ => 2
//      }
//
//      val batch_type_last = last_batch_code match {
//        case last_batch_code if StringUtils.isEmpty(last_batch_code) => 2
//        case last_batch_code if last_batch_code.endsWith("P") => 0
//        case last_batch_code if last_batch_code.endsWith("D") => 1
//        case _ => 2
//      }
//
//      var filterTag = 0
//
//      if (batch_type == 0 && batch_type_last == 1) {
//        filterTag = 1
//      } else if (batch_type == 1 && batch_type_last == 0) {
//        filterTag = 1
//      }
//
//      (batch_code, dept_code, latest_arrival_tm, last_batch_last_tm, last_batch_code, send_tm, data_type, batch_type.toString, filterTag.toString,line_code,cvy_name)
//    })
//      .filter(x => {
//        val (batch_code, dept_code, latest_arrival_tm, last_batch_last_tm, last_batch_code, send_tm, data_type, batch_type, filterTag,line_code,cvy_name) = x
//        StringUtils.nonEmpty(last_batch_last_tm) && StringUtils.nonEmpty(last_batch_code) &&
//          StringUtils.nonEmpty(latest_arrival_tm) && latest_arrival_tm.length == 19 && last_batch_last_tm.length == 19 &&
//          "0".equals(filterTag)
//      }).map(x => {
//      val (batch_code, dept_code, latest_arrival_tm, last_batch_last_tm, last_batch_code, send_tm, data_type, batch_type, filterTag,line_code,cvy_name) = x
//      (batch_code, dept_code, latest_arrival_tm, last_batch_last_tm, last_batch_code, send_tm, data_type, batch_type,line_code,cvy_name)
//    })
//      .collect()
//
//    logger.error("batchAllTb的数据量为：" + batchAllTb.size)
//    batchAllTb.take(2).foreach(println(_))
//
//    import spark.implicits._
//    spark.sparkContext.parallelize(batchAllTb).toDF().repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv(s"/user/01401062/upload/gis/data/eta/${inc_day}.csv")
//    batchAllTb
  }

  def addBatch(spark: SparkSession, labelData: RDD[JSONObject], inc_day: String): RDD[JSONObject] = {

        val batchAllTb = getbatchAllTb(spark, inc_day)

    val batchAllTb2 = spark.read.format("csv").option("header", "true").load("d:\\user\\01401062\\桌面\\20211030.csv").rdd.repartition(6).map(x => {
      val batch_code = x.getString(0)
      val dept_code = x.getString(1)
      val latest_arrival_tm = x.getString(2)
      val last_batch_last_tm = x.getString(3)
      val last_batch_code = x.getString(4)
      val send_tm = x.getString(5)
      val data_type = x.getString(6)
      val batch_type = x.getString(7)
      val line_code = x.getString(8)
      val cvy_name = x.getString(9)

      (batch_code, dept_code, latest_arrival_tm, last_batch_last_tm, last_batch_code, send_tm, data_type,batch_type,line_code,cvy_name)
    }).collect()


    val batchBroadcast = spark.sparkContext.broadcast(batchAllTb2)

    val joinBatchRdd = getJoinBatch(labelData, batchBroadcast).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("joinBatchRdd的数据量为：" + joinBatchRdd.count())
    joinBatchRdd.take(2).foreach(println(_))


    val updateFlagRdd = updateFlag(joinBatchRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("updateFlagRdd的数据量为：" + updateFlagRdd.count())
    updateFlagRdd.take(2).foreach(println(_))
//
    updateFlagRdd
  }

  def updateFlag(joinBatchRdd: RDD[JSONObject]) = {

    /**
      * 区分分拨区网点
      */
    val distributionList = List("111Y", "222Y", "300Y", "333Y", "555Y", "666Y", "700Y", "777Y", "888Y", "999Y")

    val distributionRdd = joinBatchRdd.filter(x => {
      val task_area_code = x.getString("task_area_code")
      StringUtils.nonEmpty(task_area_code) && distributionList.contains(task_area_code)
    }).map(x => {
      val transoport_level = JSONUtils.getJsonValueInt(x, "transoport_level", 0)

      val ft_time = JSONUtils.getJsonValueDouble(x, "ft_time", 0)
      val batch_st = JSONUtils.getJsonValue(x, "batch_st", "")
      val flag = JSONUtils.getJsonValue(x, "flag", "")
      val line_time = JSONUtils.getJsonValueInt(x, "line_time", 0)
      val p9_ontime_rate = JSONUtils.getJsonValueDouble(x, "ontime90Ratio", 0.0)
      //val p9_ontime_rate = JSONUtils.getJsonValueDouble(x,"p9_ontime_rate",0.0)
      val his_ontime_rate = JSONUtils.getJsonValueDouble(x, "his_ontime_rate", 0.0)

      val flagBuilder = new mutable.StringBuilder(flag)
      var threshold = 20
      if (transoport_level == 3) threshold = 10

      flagBuilder.append(flag)
      if (line_time - ft_time >= threshold && p9_ontime_rate >= 0.95 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (StringUtils.nonEmpty(batch_st) && (batch_st.equals("跨小段") || batch_st.equals("跨大段"))
        && p9_ontime_rate >= 0.95 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (ft_time - line_time >= threshold && p9_ontime_rate <= 0.95 && p9_ontime_rate >= his_ontime_rate) {
        //20210906更改
        //        && ((StringUtils.nonEmpty(batch_st) && !batch_st.equals("延长班次")) || StringUtils.isEmpty(batch_st))) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("延长时长")
        } else {
          flagBuilder.append("延长时长")
        }
      }
      x.put("flag", flagBuilder.toString())

      if (ft_time == 0) {
        x.put("batch_st", "")
        x.put("ft_arrive_time", "")
        x.put("ft_arrive_time_last", "")
      }

      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("distributionRdd的数据量为：" + distributionRdd.count())

    val notDistributionRdd = joinBatchRdd.filter(x => {
      val task_area_code = x.getString("task_area_code")
      StringUtils.isEmpty(task_area_code) || !(distributionList.contains(task_area_code))
    }).map(x => {
      val transoport_level = JSONUtils.getJsonValueInt(x, "transoport_level", 0)
      val ft_time = JSONUtils.getJsonValueDouble(x, "ft_time", 0)
      val batch_st = JSONUtils.getJsonValue(x, "batch_st", "")
      val flag = JSONUtils.getJsonValue(x, "flag", "")
      val line_time = JSONUtils.getJsonValueInt(x, "line_time", 0)
      val p9_ontime_rate = JSONUtils.getJsonValueDouble(x, "ontime90Ratio", 0.0)
      val his_ontime_rate = JSONUtils.getJsonValueDouble(x, "his_ontime_rate", 0.0)

      val flagBuilder = new mutable.StringBuilder(flag)
      var threshold = 20
      if (transoport_level == 3) threshold = 10

      flagBuilder.append(flag)
      if (line_time - ft_time >= threshold && (line_time - ft_time) / line_time < 0.2 && p9_ontime_rate >= 0.95 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (StringUtils.nonEmpty(batch_st) && (batch_st.equals("跨小段") || batch_st.equals("跨大段"))
        && (line_time - ft_time) / line_time < 0.2
        && p9_ontime_rate >= 0.95 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (ft_time - line_time >= threshold && p9_ontime_rate <= 0.95 && p9_ontime_rate >= his_ontime_rate) {
        //&&((StringUtils.nonEmpty(batch_st) && !batch_st.equals("延长班次")) || StringUtils.isEmpty(batch_st))) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("延长时长")
        } else {
          flagBuilder.append("延长时长")
        }
      }
      x.put("flag", flagBuilder.toString())

      if (ft_time == 0) {
        x.put("batch_st", "")
        x.put("ft_arrive_time", "")
        x.put("ft_arrive_time_last", "")
      }

      x
    })
    logger.error("notDistributionRdd的数据量为：" + notDistributionRdd.count())


    val updateRdd = distributionRdd.union(notDistributionRdd)
    updateRdd
  }


  /**
    * 收派班次，计算最晚到车时间
    *
    * @param x
    * @param batchBroadcastSourceRdd
    * @return
    */

  def getBatchShouPai(x: JSONObject, batchBroadcastSourceRdd: Array[(String, String, String, String, String, String, String, String,String,String)]) = {

    val plan_arrive_batch = JSONUtils.getJsonValue(x, "plan_arrive_batch", "")
    val ft_time = JSONUtils.getJsonValueInt(x, "ft_time", 0)
    val plan_depart_tm = JSONUtils.getJsonValue(x, "plan_depart_tm", "")
    val plan_arrive_tm = x.getString("plan_arrive_tm")
    val transoport_level = JSONUtils.getJsonValue(x, "transoport_level", "")
    val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
    val line_code = JSONUtils.getJsonValue(x, "line_code", "")
    val job_type = JSONUtils.getJsonValue(x, "job_type", "-")
    val last_arrive_tm = JSONUtils.getJsonValue(x, "last_arrive_tm", "")

    val ft_arrive_time = JSONUtils.getJsonValue(x, "ft_arrive_time", "")
    val batch_type = JSONUtils.getJsonValue(x, "batch_type", "1")

    val batchBroadcastRdd = batchBroadcastSourceRdd.filter(x => {
      val data_type = x._7
      data_type.equals(batch_type)
    })

    var plan_arrive_time_last = "9999-12-31 00:00:00"
    var last_batch_last_tm = ""
    var last_batch_code = ""
    var ft_arrive_time_last = "9999-12-31 00:00:00"

    val end_dept_size = end_dept.size
    val isLastDeptPre = try {
      line_code.substring(0, line_code.size - 4).takeRight(end_dept_size)
    } catch {
      case e: Exception => "-"
    }
    val isLastDept = if (isLastDeptPre.equals(end_dept)) "1" else "0"

    var plan_batch_code = ""
    var ft_batch_code = ""

    //(batch_code,dept_code,latest_arrival_tm,batch_type,last_batch_last_tm,last_batch_code)
    if (StringUtils.isEmpty(plan_arrive_batch)) {
      batchBroadcastRdd.map(obj => {
        val batch_code = obj._1
        val dept_code = obj._2
        val latest_arrival_tm_new = obj._3
        val last_batch_last_tm_new = obj._4
        val last_batch_code_new = obj._5
        val send_tm = obj._6
        val batch_type_new = obj._7

        if (dept_code.equals(end_dept)) {
          if (plan_arrive_tm <= latest_arrival_tm_new) {
            if (plan_arrive_time_last >= latest_arrival_tm_new) {
              plan_arrive_time_last = latest_arrival_tm_new
              last_batch_last_tm = last_batch_last_tm_new
              last_batch_code = last_batch_code_new
              plan_batch_code = batch_code
            }
          }

          if (ft_arrive_time <= latest_arrival_tm_new) {
            if (latest_arrival_tm_new < ft_arrive_time_last) {
              ft_arrive_time_last = latest_arrival_tm_new
              ft_batch_code = batch_code
            }
          }
        }
      })
    } else if (StringUtils.nonEmpty(transoport_level) && StringUtils.nonEmpty(isLastDept)
      && "3".equals(transoport_level) && "0".equals(isLastDept) && !"2".equals(job_type)) {
      batchBroadcastRdd.map(obj => {
        val batch_code = obj._1
        val dept_code = obj._2
        val latest_arrival_tm_new = obj._3
        val last_batch_last_tm_new = obj._4
        val last_batch_code_new = obj._5
        val send_tm = obj._6
        val batch_type_new = obj._7

        if (dept_code.equals(end_dept)) {
          if (last_arrive_tm <= latest_arrival_tm_new) {
            if (plan_arrive_time_last > latest_arrival_tm_new) {
              plan_arrive_time_last = latest_arrival_tm_new
              last_batch_last_tm = last_batch_last_tm_new
              last_batch_code = last_batch_code_new
              plan_batch_code = batch_code
            }
          }

          if (ft_arrive_time <= latest_arrival_tm_new) {
            if (latest_arrival_tm_new < ft_arrive_time_last) {
              ft_arrive_time_last = latest_arrival_tm_new
              ft_batch_code = batch_code
            }
          }
        }
      })
    } else if ("3".equals(transoport_level) && StringUtils.nonEmpty(isLastDept)
      && "0".equals(isLastDept) && "2".equals(job_type)) {
      plan_arrive_time_last = ""
      last_batch_last_tm = ""
      last_batch_code = ""
      ft_arrive_time_last = ""
    } else {
      batchBroadcastRdd.map(obj => {
        val batch_code = obj._1
        val dept_code = obj._2
        val latest_arrival_tm_new = obj._3
        val last_batch_last_tm_new = obj._4
        val last_batch_code_new = obj._5
        val send_tm = obj._6
        val batch_type_new = obj._7

        if (dept_code.equals(end_dept)) {
          if (plan_arrive_tm <= latest_arrival_tm_new) {
            if (plan_arrive_time_last > latest_arrival_tm_new) {
              plan_arrive_time_last = latest_arrival_tm_new
              last_batch_last_tm = last_batch_last_tm_new
              last_batch_code = last_batch_code_new
              plan_batch_code = batch_code
            }
          }

          if (ft_arrive_time <= latest_arrival_tm_new) {
            if (latest_arrival_tm_new < ft_arrive_time_last) {
              ft_arrive_time_last = latest_arrival_tm_new
              ft_batch_code = batch_code
            }
          }
        }
      })
    }


    var batch_st = ""
    // TODO: 20211109增加字段
    var add_time_max = 0

    if (ft_arrive_time < plan_arrive_tm && plan_arrive_batch.equals(last_batch_code)
      && ft_arrive_time_last < plan_arrive_time_last) {
      batch_st = "跨小段"
    } else if (ft_arrive_time_last < plan_arrive_time_last && !plan_arrive_batch.equals(last_batch_code)
      && ft_arrive_time < plan_arrive_tm) {
      batch_st = "跨大段"
    } else if (ft_arrive_time > plan_arrive_time_last && ft_arrive_time > plan_arrive_tm) {
      batch_st = "延长班次"
      add_time_max = try {if (plan_arrive_time_last != "9999-12-31 00:00:00") DateTimeUtil.parseFtTime(plan_arrive_tm,plan_arrive_time_last,"yyyy-MM-dd HH:mm:ss") else 0 } catch {case e:Exception => 0}
    }


    x.put("plan_arrive_time_last", plan_arrive_time_last)
    x.put("last_batch_last_tm", last_batch_last_tm)
    x.put("last_batch_code", last_batch_code)
    x.put("ft_arrive_time_last", ft_arrive_time_last)
    x.put("batch_st", batch_st)
    x.put("plan_batch_code", plan_batch_code)
    x.put("ft_batch_code", ft_batch_code)
    x.put("add_time_max", add_time_max)

    x
  }


  /**
    * 中转班次，计算最晚到车时间
    *
    * @param x
    * @param batchBroadcastRddInput
    * @return
    */
  def getBatchTransfer(x: JSONObject, batchBroadcastRddInput: Array[(String, String, String, String, String, String, String, String,String,String)],shouPaiJson:JSONObject):JSONObject = {

    val plan_arrive_batch = JSONUtils.getJsonValue(x, "plan_arrive_batch", "")
    val ft_time = JSONUtils.getJsonValueInt(x, "ft_time", 0)
    val plan_depart_tm = JSONUtils.getJsonValue(x, "plan_depart_tm", "")
    val plan_arrive_tm = x.getString("plan_arrive_tm")
    val transoport_level = JSONUtils.getJsonValue(x, "transoport_level", "")
    val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
    val line_code = JSONUtils.getJsonValue(x, "line_code", "")
    val job_type = JSONUtils.getJsonValue(x, "job_type", "-")
    val last_arrive_tm = JSONUtils.getJsonValue(x, "last_arrive_tm", "")


    val ft_arrive_time = JSONUtils.getJsonValue(x, "ft_arrive_time", "")
    val batch_type = x.getString("batch_type")

    var send_tm_min = "9999-12-31 00:00:00"
    var send_tm_min_ft = "9999-12-31 00:00:00"
    var plan_arrive_time_last = "9999-12-31 00:00:00"
    var last_batch_last_tm = ""
    var last_batch_code = ""
    var ft_arrive_time_last = "9999-12-31 00:00:00"

    val end_dept_size = end_dept.size
    val isLastDeptPre = try {
      line_code.substring(0, line_code.size - 4).takeRight(end_dept_size)
    } catch {
      case e: Exception => "-"
    }
    val isLastDept = if (isLastDeptPre.equals(end_dept)) "1" else "0"

    // TODO: 20211109新增字段
    var plan_arrive_line_code = ""
    var plan_cvy_name = ""
    var ft_arrive_line_code = ""
    var ft_cvy_name = ""
    var plan_batch_code = ""
    var ft_batch_code = ""


    val batchBroadcastRdd = batchBroadcastRddInput.filter(x => {
      val data_type = x._7
      data_type.equals("2")
    }).filter(obj => {
      val batch_type_new = obj._8
      batch_type_new.equals(batch_type) || batch_type_new.equals("2")
    })


    // (batch_code, dept_code, latest_arrival_tm, last_batch_last_tm, last_batch_code, send_tm, data_type, batch_type,line_code,cvy_name)
    if (StringUtils.isEmpty(plan_arrive_batch)) {
      batchBroadcastRdd.map(obj => {
        val batch_code = obj._1
        val dept_code = obj._2
        val latest_arrival_tm_new = obj._3
        val last_batch_last_tm_new = obj._4
        val last_batch_code_new = obj._5
        val send_tm = obj._6
        val batch_type_new = obj._7

        val line_code_batch = obj._9
        val cvy_name_batch = obj._10

        // 判断计划到达时间对应的最晚到车时间、上一班次的最晚到车时间.
        if (dept_code.equals(end_dept)) {
          if (plan_arrive_tm <= latest_arrival_tm_new) {
            if (plan_arrive_time_last >= latest_arrival_tm_new && send_tm_min > send_tm) {
              plan_arrive_time_last = latest_arrival_tm_new
              last_batch_last_tm = last_batch_last_tm_new
              last_batch_code = last_batch_code_new
              send_tm_min = send_tm

              plan_batch_code = batch_code
              plan_arrive_line_code = line_code_batch
              plan_cvy_name = cvy_name_batch
            }
          }
          // 计算丰图到达时间对应的最晚到车时间ft_arrive_time_last
          if (ft_arrive_time < latest_arrival_tm_new && send_tm_min_ft > send_tm) {
            ft_arrive_time_last = latest_arrival_tm_new
            send_tm_min_ft = send_tm
            ft_batch_code = batch_code
            ft_arrive_line_code = line_code_batch
            ft_cvy_name = cvy_name_batch
          }
        }
      })
    } else if (StringUtils.nonEmpty(transoport_level) && StringUtils.nonEmpty(isLastDept)
      && "3".equals(transoport_level) && "0".equals(isLastDept) && !"2".equals(job_type)) {
      batchBroadcastRdd.map(obj => {

        //last_arrive_tm字段作为本班次最晚到车时间，根据最晚车时间last_arrive_tm找上一班次的最晚到车时间及上一班次的班次编码
        val batch_code = obj._1
        val dept_code = obj._2
        val latest_arrival_tm_new = obj._3
        val last_batch_last_tm_new = obj._4
        val last_batch_code_new = obj._5
        val send_tm = obj._6
        val batch_type_new = obj._7

        val line_code_batch = obj._9
        val cvy_name_batch = obj._10
        plan_arrive_time_last = last_arrive_tm

        if (dept_code.equals(end_dept)) {
          if (last_arrive_tm <= latest_arrival_tm_new) {
            if (send_tm_min > send_tm) {
              last_batch_last_tm = last_batch_last_tm_new
              last_batch_code = last_batch_code_new
              send_tm_min = send_tm

              plan_batch_code = batch_code
              plan_arrive_line_code = line_code_batch
              plan_cvy_name = cvy_name_batch
            }
          }

          if (StringUtils.nonEmpty(batch_type_new) && StringUtils.nonEmpty(batch_type) && batch_type_new.equals(batch_type)) {
            if (ft_arrive_time < latest_arrival_tm_new && send_tm_min_ft > send_tm) {
              ft_arrive_time_last = latest_arrival_tm_new
              send_tm_min_ft = send_tm
              ft_batch_code = batch_code
              ft_arrive_line_code = line_code_batch
              ft_cvy_name = cvy_name_batch
            }
          }
        }
      })
    } else if ("3".equals(transoport_level) && StringUtils.nonEmpty(isLastDept)
      && "0".equals(isLastDept) && "2".equals(job_type)) {
      plan_arrive_time_last = ""
      last_batch_last_tm = ""
      last_batch_code = ""
      ft_arrive_time_last = ""
    } else {
      batchBroadcastRdd.map(obj => {
        val batch_code = obj._1
        val dept_code = obj._2
        val latest_arrival_tm_new = obj._3
        val last_batch_last_tm_new = obj._4
        val last_batch_code_new = obj._5
        val send_tm = obj._6
        val batch_type_new = obj._7

        val line_code_batch = obj._9
        val cvy_name_batch = obj._10

        if (dept_code.equals(end_dept)) {
          if (plan_arrive_tm <= latest_arrival_tm_new) {
            if (send_tm_min > send_tm) {
              plan_arrive_time_last = latest_arrival_tm_new
              last_batch_last_tm = last_batch_last_tm_new
              last_batch_code = last_batch_code_new
              send_tm_min = send_tm

              plan_batch_code = batch_code
              plan_arrive_line_code = line_code_batch
              plan_cvy_name = cvy_name_batch
            }
          }

          if (ft_arrive_time < latest_arrival_tm_new && send_tm_min_ft > send_tm) {
            ft_arrive_time_last = latest_arrival_tm_new
            send_tm_min_ft = send_tm
            ft_batch_code = batch_code
            ft_arrive_line_code = line_code_batch
            ft_cvy_name = cvy_name_batch
          }
        }
      })
    }


    var batch_st = ""
    var add_time_max = 0

    if (ft_arrive_time < plan_arrive_tm && plan_arrive_batch.equals(last_batch_code)
      && ft_arrive_time_last < plan_arrive_time_last) {
      batch_st = "跨小段"
    } else if (ft_arrive_time_last < plan_arrive_time_last && !plan_arrive_batch.equals(last_batch_code)
      && ft_arrive_time < plan_arrive_tm) {
      batch_st = "跨大段"
    } else if (ft_arrive_time > plan_arrive_time_last && ft_arrive_time > plan_arrive_tm) {
      batch_st = "延长班次"
      // TODO: 20211109增加字段
      add_time_max = try {if (plan_arrive_time_last != "9999-12-31 00:00:00") DateTimeUtil.parseFtTime(plan_arrive_tm,plan_arrive_time_last,"yyyy-MM-dd HH:mm:ss") else 0 } catch {case e:Exception => 0}
    }



    x.put("plan_arrive_time_last", plan_arrive_time_last)
    x.put("last_batch_last_tm", last_batch_last_tm)
    x.put("last_batch_code", last_batch_code)
    x.put("ft_arrive_time_last", ft_arrive_time_last)
    x.put("batch_st", batch_st)

    // TODO: 20211109增加字段
    x.put("plan_arrive_line_code", plan_arrive_line_code)
    x.put("plan_cvy_name", plan_cvy_name)
    x.put("ft_arrive_line_code", ft_arrive_line_code)
    x.put("ft_cvy_name", ft_cvy_name)
    x.put("plan_batch_code", plan_batch_code)
    x.put("ft_batch_code", ft_batch_code)
    x.put("add_time_max",add_time_max)


    //shouPaiJson.put("other",x.toJSONString)
    val resJson = if ((!shouPaiJson.isEmpty) && (StringUtils.isEmpty(last_batch_code) ||  last_batch_code.endsWith("P"))) x.fluentPutAll(shouPaiJson) else x
    //val resJson = shouPaiJson


    resJson

  }

  def getShouPaiJson(shouPaiJo: JSONObject) = {

    val plan_arrive_time_last = shouPaiJo.getString("plan_arrive_time_last")
    val last_batch_last_tm = shouPaiJo.getString("last_batch_last_tm")
    val last_batch_code = shouPaiJo.getString("last_batch_code")
    val ft_arrive_time_last = shouPaiJo.getString("ft_arrive_time_last")
    val batch_st = shouPaiJo.getString("batch_st")
    val plan_batch_code = shouPaiJo.getString("plan_batch_code")
    val ft_batch_code = shouPaiJo.getString("ft_batch_code")
    val add_time_max = shouPaiJo.getString("add_time_max")


    val jo = new JSONObject()
    jo.put("plan_arrive_time_last", plan_arrive_time_last)
    jo.put("last_batch_last_tm", last_batch_last_tm)
    jo.put("last_batch_code", last_batch_code)
    jo.put("ft_arrive_time_last", ft_arrive_time_last)
    jo.put("batch_st", batch_st)
    jo.put("plan_batch_code", plan_batch_code)
    jo.put("ft_batch_code", ft_batch_code)
    jo.put("add_time_max", add_time_max)

    jo


  }

  def getJoinBatch(labelData: RDD[JSONObject], batchBroadcast: Broadcast[Array[(String, String, String, String, String, String, String, String,String,String)]]) = {

    val joinBatchRdd = labelData.map(x => {

      val plan_arrive_batch = JSONUtils.getJsonValue(x, "plan_arrive_batch", "")
      val ft_time = JSONUtils.getJsonValueInt(x, "ft_time", 0)
      val plan_depart_tm = JSONUtils.getJsonValue(x, "plan_depart_tm", "")
      val plan_arrive_tm = x.getString("plan_arrive_tm")
      val transoport_level = JSONUtils.getJsonValue(x, "transoport_level", "")
      val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
      val line_code = JSONUtils.getJsonValue(x, "line_code", "")
      val job_type = JSONUtils.getJsonValue(x, "job_type", "-")


      /**
        * 班次类型batch_type
        */
      val batch_type = plan_arrive_batch match {
        case plan_arrive_batch if StringUtils.isEmpty(plan_arrive_batch) => "2"
        case plan_arrive_batch if plan_arrive_batch.endsWith("P") => "2"
        case plan_arrive_batch if plan_arrive_batch.endsWith("D") => "1"
        case _ => "2"
      }
      x.put("batch_type", batch_type)
      /**
        * 丰图到达时间 ft_arrive_time
        * plan_depart_tm（计划发车时间，来源为sql取数） +  ft_time
        */

      val ft_arrive_time = DateTimeUtil.getMinBeforeAfter(plan_depart_tm, "yyyy-MM-dd HH:mm:ss", ft_time)

      x.put("ft_arrive_time", ft_arrive_time)

      /**
        * plan_arrive_time_last,last_batch_last_tm,last_batch_code计算
        */


      /**
        * 过滤对应type的数据
        */
      val batchBroadcastRdd = batchBroadcast.value

      val shouPaiJo = getBatchShouPai(x, batchBroadcastRdd)

      val spJson = getShouPaiJson(shouPaiJo)


      val jo = if (!"2".equals(batch_type)) {
        /**
          * 若结果不为延长班次或提升班次，则到中转班次中找最晚到车时间
          */
        if (StringUtils.isEmpty(shouPaiJo.getString("batch_st")) ||
          ((!"延长班次".equals(shouPaiJo.getString("batch_st"))) && (!"跨大段".equals(shouPaiJo.getString("batch_st"))) &&
            (!"跨小段".equals(shouPaiJo.getString("batch_st"))))) {
          val transferJo = getBatchTransfer(x,batchBroadcastRdd,spJson)
          transferJo

          //          val transferJo = try {
          //            getBatchTransfer(x, batchBroadcastRdd,shouPaiJo)
          //          } catch {
          //            case e: Exception => {
          //              val json = new JSONObject()
          //              json.put("err", e)
          //              json
          //            }
          //          }
          //          transferJo
          //shouPaiJo
        } else {
          shouPaiJo
        }
      } else {
        try {
          getBatchTransfer(x, batchBroadcastRdd,new JSONObject())
        } catch {
          case e: Exception => {
            val json = new JSONObject()
            json.put("err", e)
            json
          }
        }
      }

      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("joinBatchRdd的数据量为：" + joinBatchRdd.count())
    joinBatchRdd.take(2).foreach(println(_))

    joinBatchRdd

  }


  def mergeMonthFreq(obj1: JSONObject, obj2: JSONObject): JSONObject = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val inc_day_1 = JSONUtils.getJsonValueInt(obj1, "inc_day", 0)
    val inc_day_2 = JSONUtils.getJsonValueInt(obj2, "inc_day", 0)

    //取inc_day日期最大的
    if (inc_day_1 < inc_day_2) {
      return obj2
    } else {
      return obj1
    }
  }

  class SecondarySortByKey(val first: Int, val second: Int) extends Ordered[SecondarySortByKey] with Serializable {
    override def compare(that: SecondarySortByKey): Int = {
      if (this.first - that.first != 0) {
        -(this.first - that.first)
      } else {
        -(this.second - that.second)
      }
    }
  }

  class ThirdSortByKey(val first: Int, val second: Int, val third: Int) extends Ordered[ThirdSortByKey] with Serializable {
    override def compare(that: ThirdSortByKey): Int = {
      if (this.first - that.first != 0) {
        -(this.first - that.first)
      } else if (this.second - that.second != 0) {
        -(this.second - that.second)
      } else {
        -(this.third - that.third)
      }
    }
  }

  class SecondarySortByKeyString(val first: String, val second: String) extends Ordered[SecondarySortByKeyString] with Serializable {
    override def compare(that: SecondarySortByKeyString): Int = {
      if (!this.first.equals(that.first)) {
        this.first.compareTo(that.first)
      } else {
        this.second.compareTo(that.second)
      }
    }
  }


}
