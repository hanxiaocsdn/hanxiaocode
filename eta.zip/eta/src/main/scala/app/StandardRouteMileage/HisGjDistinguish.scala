package app.StandardRouteMileage

import Utils._
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.eta.constant.StandardRouteMileage.{CalAngleUtils, DistanceTool}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

object HisGjDistinguish {
  @transient lazy val logger: Logger = Logger.getLogger(HisGjDistinguish.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    //val inc_day =args(0)
    val inc_day =args(0)
    start(inc_day)

  }

  case class traj_ab_info(task_id:String,start_dept:String,end_dept:String,
                           his_coords:String,his_len:String,rt_dist:String,
                           ab_angle_cnt:String,ab_angle_arr:String,
                           his_abnormal:String,inc_day:String)

  def getTrajInfo(spark: SparkSession, inc_day: String) = {

    val dlr = "$"

    val trajInfoSql =
      s"""
         |select
         |  get_json_object(info,'${dlr}.task_id') task_id,
         |  get_json_object(info,'${dlr}.start_dept') start_dept,
         |  get_json_object(info,'${dlr}.end_dept') end_dept,
         |  get_json_object(info,'${dlr}.his_coords') his_coords,
         |  get_json_object(info,'${dlr}.rt_dist') rt_dist,
         |  inc_day
         |from
         |  dm_gis.eta_traj_info
         |where
         |  inc_day = '${inc_day}'
         |and
         |  get_json_object(info,'${dlr}.his_coords') != ''
         |and
         |  get_json_object(info,'${dlr}.his_coords') is not null
       """.stripMargin

    logger.error("trajInfoSql为：" + trajInfoSql)

    val trajInfoDF = spark.sql(trajInfoSql)
    val trajInfoRdd = SparkUtils.getRowToJson(trajInfoDF)

    trajInfoRdd

  }

  def calErrTypeProcess(getTarjInfoRdd: RDD[JSONObject]) = {

    //当his_len>1.5*rt_dist(纠偏后的轨迹长度），则his_abnormal = -1，不再做其他异常识别
    val errDistJudgeRdd = getTarjInfoRdd.map(x => {
      val his_coords = x.getString("his_coords")
      val array = JSON.parseArray(his_coords)
      val rt_dist = JSONUtils.getJsonValueDouble(x,"rt_dist",0.0)
      var his_len = 0.0
      if (array.size() > 2) {
        for (i <- (0 until(array.size()) -1)){
          val trajPre = array.getJSONObject(i)
          val preX = trajPre.getDouble("zx")
          val preY = trajPre.getDouble("zy")
          val trajCur = array.getJSONObject(i+1)
          val curX = trajCur.getDouble("zx")
          val curY = trajCur.getDouble("zy")
          val distance = DistanceTool.getGreatCircleDistance(preX,preY,curX,curY)

          his_len = his_len + distance

        }
      }

      if (his_len > 1.5 * rt_dist * 1000){
        x.put("his_abnormal",-1)
      }
      x.put("array",array)
      x.put("his_len",his_len)
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val trajInfoAbnormalRdd = errDistJudgeRdd.filter(x => {
      //过滤his_abnormal等于-1的数据
      StringUtils.nonEmpty(x.getString("his_abnormal")) && "-1".equals(x.getString("his_abnormal"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("trajInfoAbnormalRdd的数据量为：" + trajInfoAbnormalRdd.count())
    trajInfoAbnormalRdd.take(2).foreach(println(_))


    val trajInfoRdd = errDistJudgeRdd.filter(x => {
      //过滤his_abnormal不等于-1
      StringUtils.isEmpty(x.getString("his_abnormal")) || !"-1".equals(x.getString("his_abnormal"))

    }).map(x => {

      val task_id = x.getString("task_id")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val his_coords = x.getString("his_coords")
      val rt_dist = x.getDouble("rt_dist")
      val array = JSON.parseArray(his_coords)

      var his_abnormal = 0
      var ab_angle_cnt = 0
      val angle_arr = new ArrayBuffer[String]()

      if (array.size() > 3){
        for (i <- (0 until(array.size()) -2)){

          val jo = new JSONObject()
          val trajPre = array.getJSONObject(i)
          val preX = trajPre.getDouble("zx")
          val preY = trajPre.getDouble("zy")

          val trajCur = array.getJSONObject(i+1)
          val curX = trajCur.getDouble("zx")
          val curY = trajCur.getDouble("zy")

          val tarjAfter = array.getJSONObject(i+2)
          val afterX = tarjAfter.getDouble("zx")
          val afterY = tarjAfter.getDouble("zy")
          val doubleA = Array[Double](preX,preY)
          val doubleB = Array[Double](curX,curY)
          val doubleC = Array[Double](afterX,afterY)
          //.toList.asJava

          val distance1 = DistanceTool.getGreatCircleDistance(preX,preY,curX,curY)
          val distance2 = DistanceTool.getGreatCircleDistance(curX,curY,afterX,afterY)

          val angle = CalAngleUtils.calAngle2(doubleA,doubleB,doubleC)

         if ( angle > 1 && angle <= 70){
            if ( distance1 > 100 && distance2 > 100 && (distance1 > 500 || distance2 > 500)){
              ab_angle_cnt += 1
              his_abnormal = 1

              angle_arr.append(doubleA.mkString(","))
              angle_arr.append(";")
              angle_arr.append(doubleB.mkString(","))
              angle_arr.append(";")
              angle_arr.append(doubleC.mkString(","))
              angle_arr.append("|")
            }
          }
        }

      }
      x.put("his_abnormal",his_abnormal)
      x.put("ab_angle_arr",angle_arr.mkString(""))
      x.put("ab_angle_cnt",ab_angle_cnt)
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("trajInfoRdd的数据量为：" + trajInfoRdd.count())
    trajInfoRdd.take(2).foreach(println(_))

    val trajInfoResRdd  = trajInfoRdd.union(trajInfoAbnormalRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("trajInfoResRdd的数据量为：" + trajInfoResRdd.count())
    trajInfoResRdd.take(2).foreach(println(_))

    trajInfoResRdd
  }

  def saveDfToTable(spark: SparkSession, inc_day: String, calErrRdd: RDD[JSONObject]) = {

    val calErrDF = calErrRdd.map(x => {

      val task_id = x.getString("task_id")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val his_coords = x.getString("his_coords")
      val his_len =  JSONUtils.getJsonValueDouble(x,"his_len",0.0) / 1000
      val rt_dist = x.getString("rt_dist")
      val ab_angle_cnt = x.getString("ab_angle_cnt")
      val ab_angle_arr = x.getString("ab_angle_arr")
      val his_abnormal = x.getString("his_abnormal")

      traj_ab_info(task_id,start_dept,end_dept,his_coords,his_len.toString,rt_dist,ab_angle_cnt,ab_angle_arr,his_abnormal,inc_day)

    })
    val insertTable = "dm_gis.eta_his_traj_ab_info"

    import spark.implicits._

    val dropSql =
      s"""
         |alter table  ${insertTable} drop if exists partition (inc_day='${inc_day}')
       """.stripMargin
    logger.error("删除表分区数据" + dropSql)
    spark.sql(dropSql)
    calErrDF.repartition(100).toDF().write.mode(SaveMode.Overwrite).insertInto(insertTable)

  }

  def staStat(spark: SparkSession, inc_day: String) = {

    val getTarjInfoRdd = getTrajInfo(spark,inc_day)

    val calErrRdd = calErrTypeProcess(getTarjInfoRdd)

    saveDfToTable(spark,inc_day,calErrRdd)


  }

  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    staStat(spark,inc_day)
    logger.error("统计结束")
  }

}
