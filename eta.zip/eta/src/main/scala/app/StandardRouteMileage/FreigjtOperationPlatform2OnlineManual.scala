package app.StandardRouteMileage

import Utils.{DateTimeUtil, JSONUtils, SparkUtils, StringUtils}
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.eta.constant.utils.HttpClientUtil
import com.sf.gis.java.eta.constant.utils.HttpClientUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object FreigjtOperationPlatform2OnlineManual {

  @transient lazy val logger: Logger = Logger.getLogger(FreigjtOperationPlatform2OnlineManual.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    val inc_day = args(0)
    val begin_day = args(1)
    val end_day = args(2)
    start(inc_day,begin_day,end_day)

  }


  def start(inc_day: String,begin_day:String,end_day:String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    startSta(spark,inc_day,begin_day,end_day)
    logger.error("统计结束")
  }


  def getFtDistTime(spark: SparkSession, inc_day: String) = {

    val ftDistTimeTabel = "eta_route_plan_res2"

    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.${ftDistTimeTabel}
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val ftDistTimeDF = spark.sql(sql)
    val colList = ftDistTimeDF.columns
    val ftDistTimeRdd = ftDistTimeDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    ftDistTimeRdd
  }

  def saveTableHistoryOntimeDept(spark: SparkSession, inc_day:String, ontimeRateRdd: RDD[JSONObject]) = {

    import spark.implicits._

    val ontimeDf = ontimeRateRdd.map(x => {
      val line_code = JSONUtils.getJsonValue(x,"line_code","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","")
      val time_p8 = JSONUtils.getJsonValue(x,"time_p8","")
      val time_p9 = JSONUtils.getJsonValue(x,"time_p9","")
      val his_ontime_rate = JSONUtils.getJsonValue(x,"his_ontime_rate","")
      val ontime80Ratio = JSONUtils.getJsonValue(x,"ontime80Ratio","")
      val ontime90Ratio = JSONUtils.getJsonValue(x,"ontime90Ratio","")
      val groupCnt = JSONUtils.getJsonValue(x,"groupCnt","")
      val dist_p8 = JSONUtils.getJsonValue(x,"dist_p8","")
      val dist_p9 = JSONUtils.getJsonValue(x,"dist_p9","")
      //val manual_report_id = JSONUtils.getJsonValue(x,"manual_report_id","")
      val inc_day_new = inc_day
      HistoryOntimeDept(line_code,start_time,start_dept,end_dept,vehicle_type,time_p8,time_p9,his_ontime_rate.toString,ontime80Ratio,ontime90Ratio,groupCnt,dist_p8,dist_p9,inc_day_new)

    }).toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_history_dist_time_8090_manual")


  }

  def saveTableSchemeRoute(spark: SparkSession, inc_day: String, schemeRouteRdd: RDD[JSONObject]) = {
    import spark.implicits._
    schemeRouteRdd.map(x => {

      //line_code
      val plan_date= x.getString("plan_date")
      val start_time= x.getString("start_time")
      val line_code= x.getString("line_code")
      val src_dept= x.getString("src_dept")
      val dest_dept= x.getString("dest_dept")
      val vehicle= x.getString("vehicle")
      val height= x.getString("height")
      val axle_weight= x.getString("axle_weight")
      val axle_number = x.getString("axle_number")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")

      val vehicle_color= x.getString("vehicle_color")
      val energy= x.getString("energy")
      val width= x.getString("width")
      val length= x.getString("length")
      val passport= x.getString("passport")
      val emitStand= ""
      val rt_status= x.getString("rt_status")
      val rt_dist= x.getString("rt_dist")
      val rt_time = JSONUtils.getJsonValueInt(x,"rt_time",0)
      val rt_tolls= x.getString("rt_tolls")
      val rt_coords= x.getString("rt_coords")
      val rt_src= x.getString("rt_src")
      val rt_flen= x.getString("rt_flen")
      val rt_tlen= x.getString("rt_tlen")
      val rt_plan_order= x.getString("rt_plan_order")
      val data_source= x.getString("data_source")
      val rt_url= x.getString("rt_url")
      //2.25日新增
      val task_area_code= x.getString("task_area_code")
      val rt_highway= x.getString("rt_highway")
      val rt_traLightCount= x.getString("rt_traLightCount")
      val line_distance= x.getString("line_distance")
      val line_time= x.getString("line_time")
      val src_dept_out= x.getString("src_dept_out")
      val dest_dept_out= x.getString("dest_dept_out")
      //val rt_tollsDistance = x.getString("rt_tollsDistance")
      val rt_tollsDistance = try{ JSONUtils.getJsonValueInt(x,"rt_tollsDistance",0)/1000} catch {case e:Exception => 0}

      val manual_report_id = x.getString("manual_report_id")
      val is_match = x.getString("is_match")

      val gdErrLog = x.getString("gdErrLog")
      val jyErrLog = x.getString("jyErrLog")
      val ctErrLog = x.getString("ctErrLog")


      res2(line_code,start_dept,end_dept,vehicle_type,height,axle_weight,axle_number,vehicle,vehicle_color,energy,
        width,length,passport,emitStand,plan_date,rt_status,rt_dist,rt_time.toString,rt_highway,rt_traLightCount,rt_tolls,
        rt_tollsDistance.toString,rt_src,rt_url,rt_flen,rt_tlen,rt_coords,rt_plan_order,data_source,task_area_code,
        start_time,manual_report_id,is_match,gdErrLog,jyErrLog,ctErrLog,inc_day)

      //res2(plan_date,start_time,axle_number,start_dept,end_dept,vehicle_type,line_code,src_dept,dest_dept,vehicle,height,axle_weight,vehicle_color,energy,width,length,passport,emitStand,rt_status,rt_dist,rt_time,rt_tolls,rt_coords,rt_src,rt_flen,rt_tlen,rt_plan_order,data_source,rt_url,task_area_code,rt_highway,rt_traLightCount,line_distance,line_time,src_dept_out,dest_dept_out,rt_tollsDistance,inc_day)
    }).toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_route_plan_middle2_manual")
  }

  def saveTableIntersect(spark: SparkSession, inc_day: String, trajIntersectRddPre: RDD[JSONObject]) = {

    import spark.implicits._

    val trajIntersectRdd = trajIntersectRddPre.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = JSONUtils.getJsonValueInt(x,"vehicle_type",6).toString
      val axle_number = JSONUtils.getJsonValueInt(x,"axle_number",2).toString
      val order_source = x.getString("order_source")
      val task_area_code =x.getString("task_area_code")
      val rt_dist =x.getString("rt_dist")
      val tolls = JSONUtils.getJsonValue(x,"rt_tolls",x.getString("tolls"))
      val rt_coords =x.getString("rt_coords")
      val data_source =x.getString("data_source")
      val rt_url =x.getString("rt_url")
      val rt_time =x.getString("rt_time")
      val sim_group = x.getString("sim_group")
      val month_freq = x.getString("month_freq")
      val rt_src = x.getString("rt_src")
      val manual_report_id = x.getString("manual_report_id")
      val is_match = x.getString("is_match")


      res3(start_time,start_dept,end_dept,vehicle_type,axle_number,order_source,rt_dist,tolls,rt_coords,data_source,rt_url,
        rt_time,sim_group,month_freq,task_area_code,rt_src,manual_report_id,is_match,inc_day)
    })

    val trajInterDf = trajIntersectRdd.toDF().persist()
    //trajInterDf.show(false)
    trajInterDf.write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_traj_intersect_manual")

  }

  def groupFormat(groupSimRdd: RDD[JSONObject]) = {

    val unVerifyRdd = groupSimRdd.map(x => {

      var vehicle_type_new =6
      var axle_number =2
      if(!StringUtils.nonEmpty(x.getString("vehicle_type"))){
        val vehicle_type = JSONUtils.getJsonValueDouble(x,"vehicle_type",0.0)

        vehicle_type_new = vehicle_type match {
          case vehicle_type if(vehicle_type<=1.0) => 5
          case vehicle_type if(vehicle_type>1.0 && vehicle_type<3.0) => 6
          case vehicle_type if(vehicle_type>=3.0 && vehicle_type<7.0) => 7
          case vehicle_type if(vehicle_type >= 7.0) => 8
        }

        axle_number = vehicle_type match {
          case vehicle_type if(vehicle_type>=0 && vehicle_type <=9.5) => 2
          case vehicle_type if(vehicle_type>9.5 && vehicle_type<=14) => 3
          case vehicle_type if(vehicle_type>14 && vehicle_type<=20) => 4
          case vehicle_type if(vehicle_type>20 && vehicle_type<=25) => 5
          case vehicle_type if(vehicle_type >= 25) => 6
        }
        x.put("vehicle_type",vehicle_type)
        x.put("axle_number",axle_number)
      }else{
        val car_type = x.getString("car_type")
        if("厢式运输车".equals(car_type)){
          vehicle_type_new = 8
          axle_number = 4
        }
      }
      x.put("vehicle_type",vehicle_type_new)
      x.put("axle_number",axle_number)

      x
    })
    unVerifyRdd

  }


  def getGroupSimNew(spark: SparkSession, inc_day: String, groupSimRdd: RDD[JSONObject], markUnVerifyRdd: RDD[JSONObject]) = {
    val leftRdd = groupSimRdd.map(x => {
      //(start_dept,end_dept,start_time
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val start_time = x.getString("start_time")

      ((start_dept,end_dept,start_time),x)
    })

    val rightRdd = markUnVerifyRdd.map(x =>{
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val start_time = x.getString("start_time")
      val vehicle_type = x.getString("vehicle_type")

      ((start_dept,end_dept,start_time),x)
    }).reduceByKey((obj1,obj2) => obj1)

    val returnRdd = leftRdd.leftOuterJoin(rightRdd).map(x =>{

      val left =x._2._1
      val rightOption = x._2._2

      if(!rightOption.isEmpty){
        val vehicle_type = rightOption.get.getString("vehicle_type")
        left.put("vehicle_type",vehicle_type)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    returnRdd

  }

  def startSta(spark: SparkSession, inc_day: String,begin_day:String,end_day:String): Unit ={

      logger.error("获取日志")
      val groupSimRdd = getGroupSim(spark,inc_day,begin_day,end_day)
      logger.error("groupSimRdd数据量为：" + groupSimRdd.count())
      groupSimRdd.take(2).foreach(println(_))
      //val groupSimFormatRdd = groupFormat(groupSimRdd)


      //获取待验证数据和规划准备数据
      val (getUndefineRdd,middle0DF,middle1DF) = getUndefineData(spark,inc_day,begin_day,end_day)
      logger.error("待验证数据量为：" + getUndefineRdd.count())

      logger.error("标记待验证数据")
      val markUnVerifyRdd = markUnVerify(getUndefineRdd)
      logger.error("待验证数据量为：" + markUnVerifyRdd.count())
      markUnVerifyRdd.take(2).foreach(println(_))


      //根据待验证数据，将vehicle_type挂接回groupsim
      val grouSimNewRdd = getGroupSimNew(spark,inc_day,groupSimRdd,markUnVerifyRdd)

      //计算时效、准点率
      logger.error("开始计算准点率")
      val ontimeRateRdd = calOntimeRate(middle0DF,middle1DF,inc_day)

      logger.error("时效准点率数据量为：" + ontimeRateRdd.count())
      ontimeRateRdd.take(2).foreach(println(_))

      saveTableHistoryOntimeDept(spark,inc_day,ontimeRateRdd)

      //        logger.error("开始计算准点率")
      //        val ontimeRateRdd = getOnTimeRateRdd(spark,inc_day)
      //        logger.error("准点率数据量为" + ontimeRateRdd.count())
      //规划线路 高德 经验
      logger.error("开始规划线路 高德 经验 传统")
      val schemeRouteRdd = schemaRoute(spark,inc_day,markUnVerifyRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("规划线路数据量为：" + schemeRouteRdd.count())
      schemeRouteRdd.take(2).foreach(println(_))
      saveTableSchemeRoute(spark,inc_day,schemeRouteRdd)

//          val schemeRouteRdd = getSchemeRoute(spark,inc_day)
//          logger.error("获取规划轨迹路线数量为：" + schemeRouteRdd.count())

      //计算轨迹交集
      logger.error("开始计算轨迹交集")
      val trajIntersectRddPre = calTrajIntersect(grouSimNewRdd,schemeRouteRdd)
      logger.error("轨迹交集的数据量为：" + trajIntersectRddPre.count())
      trajIntersectRddPre.take(2).foreach(println(_))

      saveTableIntersect(spark,inc_day,trajIntersectRddPre)
      schemeRouteRdd.unpersist()

      logger.error("获取轨迹交集")
      val trajIntersectRddNew = getTrajIntersect(spark,inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("trajIntersectRdd轨迹交集的数据量为：" + trajIntersectRddNew.count())
      trajIntersectRddNew.take(2).foreach(println(_))

      //各车型时效里程
      logger.error("开始各车型时效里程计算")
      val ftDistTimeRdd = calFtDistTime(trajIntersectRddNew).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("时效里程数据量为：" + ftDistTimeRdd.count())
      ftDistTimeRdd.take(2).foreach(println(_))
      saveTableToRes2(spark,inc_day,ftDistTimeRdd)
//      trajIntersectRddPre.unpersist()

      //获取时效里程
      //    val ftDistTimeRdd = getFtDistTime(spark,inc_day)
      //    logger.error("ftDistTimeRdd数据量为" + ftDistTimeRdd.count())

      //获取标准里程，标准时效
      val standardTimeEffect = getTimeEffect(spark,inc_day,ontimeRateRdd,markUnVerifyRdd)
      logger.error("标准时效数据量为：" + standardTimeEffect.count())
      standardTimeEffect.take(2).foreach(println(_))

      val standardDistEffect  = getDistEffect(spark,inc_day,ftDistTimeRdd,standardTimeEffect)
      logger.error("标准里程数据量为：" + standardDistEffect.count())
      standardDistEffect.take(2).foreach(println(_))

      //标记数据
      logger.error("开始标记数据")
      val labelData = getLabelData(standardDistEffect)
      logger.error("标记数据量为：" + labelData.count())
      labelData.take(2).foreach(println(_))
      //    labelData.map(x => {x.toJSONString
      //          }).repartition(1).toDF().write.mode(SaveMode.Overwrite).option("header", "true").csv("/user/01401062/upload/gis/data/eta/labelData0525.csv")

      //    val labelData = spark.read.format("csv").option("header", "true").load("/user/01401062/upload/gis/data/eta/labelData0530.csv").rdd.repartition(200).map(x => {
      //            val json = JSON.parseObject(x.mkString(""))
      //            json
      //    })
      //    logger.error("标记数据量为：" + labelData.count())
      //    labelData.take(2).foreach(println(_))

      val addBatchTag = addBatch(spark,labelData,inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("增加跨班次统计数据量为：" + addBatchTag.count())
      addBatchTag.take(2).foreach(println(_))

      saveTableToMiddle3(spark,addBatchTag,inc_day)

  }




  def saveTableToMiddle3(spark: SparkSession, addBatchTag: RDD[JSONObject],inc_day:String): Unit = {

    import spark.implicits._

    logger.error("存表输入的addBatchTag数据量为：" + addBatchTag.count())
    addBatchTag.take(2).foreach(println(_))

    val addBatchRdd = addBatchTag.map(x => {

      val data_source = x.getString("data_source")
      val order_source = x.getString("order_source")
      val axle_number = x.getString("axle_number")
      val vehicle_type = x.getString("vehicle_type")
      val ft_time = x.getString("ft_time")
      val ft_dist = x.getString("ft_dist")
      val ft_coords = x.getString("rt_coords")
      val ft_url = x.getString("rt_url")
      val ft_tolls = x.getString("tolls")
      val time_p8 = x.getString("time_p8")
      val p8_ontime_rate = x.getString("ontime80Ratio")
      val time_p9 = x.getString("time_p9")
      val p9_ontime_rate = x.getString("ontime90Ratio")
      val his_ontime_rate = x.getString("his_ontime_rate")
      val dist_flag = x.getString("dist_flag")
      val time_flag = if(StringUtils.isEmpty(time_p9)) "" else x.getString("time_flag")
      val ref_speed = x.getString("ref_speed")
      val res_abnormal = x.getString("res_abnormal")
      val flag = x.getString("flag")
      val task_area_code = x.getString("task_area_code")
      val line_time = x.getString("line_time")

      val line_require_id =  x.getString("line_require_id")
      val sort_num    =  x.getString("sort_num")
      val line_code   = x.getString("line_code")
      val require_category    = x.getString("require_category")
      val line_require_type   =x.getString("line_require_type")
      val transoport_level    = x.getString("transoport_level")
      val cvy_name    =x.getString("cvy_name")
      val line_distance   = x.getString("line_distance")
      val is_stop_over    =x.getString("is_stop_over")
      val own_dept_code   = x.getString("own_dept_code")
      val start_dept  = x.getString("start_dept")
      val end_dept    =x.getString("end_dept")
      val start_dept_out  = x.getString("start_dept_out")
      val end_dept_out    = x.getString("end_dept_out")
      val full_load_weight    = x.getString("full_load_weight")
      val car_type    = x.getString("car_type")
      val src_dept_out    = x.getString("src_dept_out")
      val dest_dept_out   = x.getString("dest_dept_out")
      val plan_depart_tm  = x.getString("plan_depart_tm")
      val plan_arrive_tm  =  x.getString("plan_arrive_tm")
      val start_time  =  x.getString("start_time")
      val plan_send_batch =  x.getString("plan_send_batch")
      val plan_arrive_batch   = x.getString("plan_arrive_batch")
      val actual_depart_tm    = x.getString("actual_depart_tm")
      val actual_arrive_tm    = x.getString("actual_arrive_tm")
      val last_update_tm  = x.getString("last_update_tm")
      val to_ground   = x.getString("to_ground")
      val pass_zone_code  = x.getString("pass_zone_code")
      val last_arrive_tm  =  x.getString("last_arrive_tm")

      //增加跨班次统计

      val plan_arrive_time_last =""
      //val plan_arrive_time_last = if(x.getString("plan_arrive_time_last").compareTo("2021-01-01 08:00:00")>0 && x.getString("plan_arrive_time_last").compareTo("9999-01-01 09:00:00")<0) x.getString("plan_arrive_time_last") else ""
      val ft_arrive_time = x.getString("ft_arrive_time")
      val ft_arrive_time_last =""
      //val ft_arrive_time_last = if(x.getString("ft_arrive_time_last").compareTo("2021-01-01 08:00:00")>0 && x.getString("ft_arrive_time_last").compareTo("9999-01-01 09:00:00")<0) x.getString("ft_arrive_time_last") else ""
      val last_batch_code = x.getString("last_batch_code")
      val last_batch_last_tm = x.getString("last_batch_last_tm")
      val batch_st = x.getString("batch_st")

      val group_dist_min = x.getString("group_dist_min")

      //20210618添加
      val batch_type = x.getString("batch_type")
      val pass_id = x.getString("pass_id")
      val work_day = x.getString("work_day")
      val trans_car = x.getString("trans_car")
      val x1 = x.getString("x1")
      val y1 = x.getString("y1")
      val x2 = x.getString("x2")
      val y2 = x.getString("y2")

      val manual_report_id = x.getString("manual_report_id")

      var flagNew = ""
      if(StringUtils.nonEmpty(flag)){
        val strings = flag.replaceAll(";","·").split("·")
        val set = new mutable.HashSet[String]()
        for(i <- (0 until(strings.size))){
          if(strings(i).nonEmpty){
            set.add(strings(i))
          }
        }
        flagNew= set.mkString(";")
      }

      val rt_src = x.getString("rt_src")
      val is_match = x.getString("is_match")


      middleTable3(data_source,order_source,axle_number,vehicle_type,ft_time,ft_dist,ft_coords,ft_url,ft_tolls,
        time_p8,p8_ontime_rate,time_p9,p9_ontime_rate,his_ontime_rate,dist_flag,time_flag,ref_speed,res_abnormal,
        flagNew,task_area_code,line_time,line_require_id,sort_num,line_code,require_category,line_require_type,transoport_level,
        cvy_name,line_distance,is_stop_over,own_dept_code,start_dept,end_dept,start_dept_out,end_dept_out,full_load_weight,
        car_type,src_dept_out,dest_dept_out,plan_depart_tm,plan_arrive_tm,start_time,plan_send_batch,plan_arrive_batch,actual_depart_tm,
        actual_arrive_tm,last_update_tm,to_ground,pass_zone_code,last_arrive_tm,plan_arrive_time_last,ft_arrive_time,ft_arrive_time_last,
        last_batch_code,last_batch_last_tm,batch_st,group_dist_min,batch_type,pass_id,work_day,trans_car,x1,y1,x2,y2,manual_report_id,rt_src,is_match,inc_day)
    })
    addBatchRdd.toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_route_plan_res3_manual")
  }



  def getOnTimeRateRdd(spark: SparkSession, inc_day: String):RDD[JSONObject] = {
    val intersectTabel = "dm_gis.eta_history_dist_time_8090"

    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_history_dist_time_8090
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val ontimeRateDF = spark.sql(sql)
    val colList = ontimeRateDF.columns
    val ontimeRateRdd = ontimeRateDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    ontimeRateRdd
  }





  def getTrajIntersect(spark: SparkSession, inc_day: String):RDD[JSONObject] = {
    val intersectTabel = "dm_gis.eta_traj_intersect"

    val sql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_traj_intersect_manual
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val intersectDF = spark.sql(sql)
    val colList = intersectDF.columns
    val intersectRdd = intersectDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    })
    intersectRdd
  }



  def getSchemeRoute(spark: SparkSession, inc_day: String):RDD[JSONObject] = {

    val beginDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -30)
    val endDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 2)


    val sql =
      s"""
         |select
         |  *
         |from
         |dm_gis.eta_route_plan_middle2
         |where
         | inc_day >='${beginDay}'
         |and
         |  inc_day <='${inc_day}'
       """.stripMargin
    val routeDF = spark.sql(sql)
    val colList = routeDF.columns
    val routeRDD = routeDF.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    routeRDD
  }


  case class resTable2(start_dept:String ,end_dept :String,axle_number:String,start_time:String,
                       vehicle_type:String,order_source:String,data_source:String,ft_dist:String,
                       ft_time:String,ft_coords:String ,ft_tolls:String,ft_url:String,task_area_code:String,group_dist_min:String
                       ,rt_src:String,score:String,manual_report_id:String,is_match:String,inc_day:String)


  case class res3(
                   start_time:String,start_dept:String,end_dept:String,vehicle_type:String,axle_number:String,order_source:String,
                   rt_dist:String,tolls:String,rt_coords:String,data_source:String,rt_url:String,rt_time:String,
                   sim_group:String,month_freq:String,task_area_code:String,rt_src:String,manual_report_id:String,is_match:String,inc_day:String
                 )

  case class res4(
                   start_time:String,start_dept:String,end_dept:String,vehicle_type:String,axle_number:String,order_source:String,
                   data_source:String,ft_dist:String,ft_time:String,ft_coords:String,ft_url:String,manual_report_id:String
                 )

  //  case class middleTable3(
  //                           data_source :String,order_source  :String,axle_number:String,vehicle_type:String,ft_time  :String,ft_dist:String
  //                           ,ft_coords  :String,ft_url  :String,ft_tolls  :String,time_p8  :String,p8_ontime_rate  :String,time_p9 :String
  //                           ,p9_ontime_rate :String,his_ontime_rate  :String,dist_flag :String,time_flag  :String,ref_speed :String,res_abnormal :String
  //                           ,flag :String,task_area_code :String,line_time :String,line_require_id :String,sort_num :String,line_code :String,require_category :String
  //                           ,line_require_type :String,transoport_level :String,cvy_name :String,line_distance :String,is_stop_over :String,own_dept_code :String
  //                           ,start_dept :String,end_dept :String,start_dept_out :String,end_dept_out :String,full_load_weight :String,car_type :String
  //                           ,src_dept_out :String,dest_dept_out :String,plan_depart_tm :String,plan_arrive_tm :String,start_time :String,plan_send_batch :String
  //                           ,plan_arrive_batch :String,actual_depart_tm :String,actual_arrive_tm :String,last_update_tm :String,to_ground :String,pass_zone_code :String
  //                           ,last_arrive_tm :String
  //                           ,plan_last_arrive_tm:String,plan_arrive_time_last:String,ft_arrive_time:String,ft_arrive_tm:String,last_batch:String,last_batch_tm_last:String
  //                           ,last_batch_time_last:String,if_advance:String,if_delay:String,group_dist_min:String,inc_day:String
  //                         )

  case class middleTable3(
                           data_source : String,order_source : String,axle_number : String,vehicle_type : String,ft_time : String,ft_dist : String,
                           ft_coords : String,ft_url : String,ft_tolls : String,time_p8 : String,p8_ontime_rate : String,time_p9 : String,p9_ontime_rate : String,
                           his_ontime_rate : String,dist_flag : String,time_flag : String,ref_speed : String,res_abnormal : String,flag : String,task_area_code : String,
                           line_time : String,line_require_id : String,sort_num : String,line_code : String,require_category : String,line_require_type : String,
                           transoport_level : String,cvy_name : String,line_distance : String,is_stop_over : String,own_dept_code : String,start_dept : String,
                           end_dept : String,start_dept_out : String,end_dept_out : String,full_load_weight : String,car_type : String,src_dept_out : String,
                           dest_dept_out : String,plan_depart_tm : String,plan_arrive_tm : String,start_time : String,plan_send_batch : String,plan_arrive_batch : String,
                           actual_depart_tm : String,actual_arrive_tm : String,last_update_tm : String,to_ground : String,pass_zone_code : String,last_arrive_tm : String,
                           plan_arrive_time_last : String,ft_arrive_time : String,ft_arrive_time_last : String,last_batch_code : String,last_batch_last_tm : String,
                           batch_st : String,group_dist_min:String,batch_type:String,pass_id:String,work_day:String,trans_car:String,x1:String,y1:String,x2:String,y2:String,manual_report_id:String,rt_src:String,is_match:String,inc_day:String
                         )



  //  case class res2(
  //                   plan_date:String
  //                   ,start_time:String
  //                   ,axle_number:String
  //                   ,start_dept:String
  //                   ,end_dept:String
  //                   ,vehicle_type:String
  //                   ,line_code:String
  //                   ,src_dept:String
  //                   ,dest_dept:String
  //                   ,vehicle:String
  //                   ,height:String
  //                   ,axle_weight:String
  //                   ,vehicle_color:String
  //                   ,energy:String
  //                   ,width:String
  //                   ,length:String
  //                   ,passport:String
  //                   ,emitStand:String
  //                   ,rt_status:String
  //                   ,rt_dist:String
  //                   ,rt_time:String
  //                   ,rt_tolls:String
  //                   ,rt_coords:String
  //                   ,rt_src:String
  //                   ,rt_flen:String
  //                   ,rt_tlen:String
  //                   ,rt_plan_order:String
  //                   ,data_source:String
  //                   ,rt_url:String
  //                   ,task_area_code:String
  //                   ,rt_highway:String
  //                   ,rt_traLightCount:String
  //                   ,line_distance:String
  //                   ,line_time:String
  //                   ,src_dept_out:String
  //                   ,dest_dept_out:String
  //                   ,rt_tollsDistance:String
  //                   ,inc_day:String
  //                 )


  case class res2(line_code:String,start_dept:String,end_dept:String,vehicle_type:String,height:String,
                  axle_weight:String,axle_number:String,vehicle:String,vehicle_color:String,energy:String,width:String,
                  length:String,passport:String,emitStand:String,plan_date:String,rt_status:String,rt_dist:String,rt_time:String,
                  rt_highway:String,rt_traLightCount:String,rt_tolls:String,rt_tollsDistance:String,rt_src:String,rt_url:String,
                  rt_flen:String,rt_tlen:String,rt_coords:String,rt_plan_order:String,data_source:String,task_area_code:String,
                  start_time:String,manual_report_id:String,is_match:String,gdErrLog:String,jyErrLog:String,ctErrLog:String,inc_day:String)


  /** @note   调用GD轨迹接口*/
  private def scheduleGdTraj(axle_number:Int,x1:Double,y1:Double,x2:Double,y2:Double,vehicle_type:Int,planDate:String): (JSONObject,String) = {

    //val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&axleNumber=%s&fencedist=50&type=0&y1=22.912458&strategy=0&fixedroute=2&test=0&stype=0&planDate=202101171200&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&y2=23.216337&opt=gd3&vehicle=6&frequency=1&x2=113.108947&x1=113.95822&passport=100000&tolls=1"

    val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=1&cc=1&merge=4&etype=2&opt=gd3&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val jo = new JSONObject()
    val url = String.format(historyTrajUrl.toString,axle_number.toString,x1.toString,y1.toString,x2.toString,y2.toString,vehicle_type.toString,planDate.toString)
    val response = Utils.Utils.retryGet(url)

    var err_log = ""
    try {

      // val response = Source.fromURL(url,"UTF-8").mkString
      if(StringUtils.nonEmpty(response)) {
        if (JSONUtils.isValidJSON(response)) {
          val response2 = JSON.parseObject(response)
          val rt_status = response2.getInteger("status")
          val result = response2.getJSONObject("result")

          val rt_dist = result.getInteger("dist").toDouble / 1000
          val rt_time = result.getInteger("time")
          val rt_tolls = JSONUtils.getJsonValueDouble(result,"tolls",0.0)
          val rt_coords= result.getJSONArray("coords").toJSONString
          val rt_src = result.getString("src")
          val rt_flen = result.getInteger("flen")
          val rt_tlen = result.getInteger("tlen")
          val rt_tollsDistance= result.getInteger("tollsDistance")

          jo.put("rt_status",rt_status)
          jo.put("rt_dist",rt_dist)
          jo.put("rt_time",rt_time)
          jo.put("rt_tolls",rt_tolls)
          jo.put("rt_coords",rt_coords)
          jo.put("rt_src",rt_src)
          jo.put("rt_flen",rt_flen)
          jo.put("rt_tlen",rt_tlen)
          jo.put("rt_plan_order",0)
          jo.put("data_source","gd")
          jo.put("rt_url",url)
          jo.put("rt_tollsDistance",rt_tollsDistance)
        }
      }
    } catch {
      case e: Exception => err_log = e.getMessage + "请求url为："+ url + "response为：" + response
    }
    (jo,err_log)
  }

  /** @note   调用JY轨迹接口*/
  private def scheduleJYTraj(axle_number:Int,x1:Double,y1:Double,x2:Double,y2:Double,vehicle_type:Int,planDate:String): (JSONArray,String) = {

    val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=6&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&opt=jy2&frequency=0&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val joArray = new JSONArray()
    val url = String.format(historyTrajUrl.toString,axle_number.toString,x1.toString,y1.toString,x2.toString,y2.toString,vehicle_type.toString,planDate.toString)
    val response = Utils.Utils.retryGet(url)

    var errLog=""
    try {
      //val response = Source.fromURL(url,"UTF-8").mkString
      if(StringUtils.nonEmpty(response)) {
        if (JSONUtils.isValidJSON(response)) {
          val response2 = JSON.parseObject(response)
          val rt_status = response2.getString("status")
          val resultList  = response2.getJSONObject("result")
          val list = resultList.getJSONArray("list")

          for(i<- (0 until list.size())){
            val jo = new JSONObject()
            val result = list.getJSONObject(i)
            val rt_dist = result.getInteger("dist").toDouble / 1000
            val rt_time = result.getInteger("time")
            val rt_tolls = JSONUtils.getJsonValueDouble(result,"tolls",0.0)
            val rt_coords= result.getJSONArray("coords").toJSONString
            val rt_src = result.getString("src")
            val rt_flen = result.getInteger("flen")
            val rt_tlen = result.getInteger("tlen")
            val rt_tollsDistance= result.getInteger("tollsDistance")
            val rt_highway= result.getInteger("highway")
            val rt_traLightCount= result.getInteger("traLightCount")

            jo.put("rt_status",rt_status)
            jo.put("rt_dist",rt_dist)
            jo.put("rt_time",rt_time)
            jo.put("rt_tolls",rt_tolls)
            jo.put("rt_coords",rt_coords)
            jo.put("rt_src",rt_src)
            jo.put("rt_flen",rt_flen)
            jo.put("rt_tlen",rt_tlen)
            jo.put("rt_plan_order",i)
            jo.put("data_source","jy")
            jo.put("rt_url",url)
            jo.put("rt_tollsDistance",rt_tollsDistance)

            joArray.add(jo)
          }
        }
      }
    } catch {
      case e: Exception => errLog = e.getMessage + "请求url为："+ url + "response为：" + response
    }

    (joArray,errLog)

  }

  /** @note   调用CT轨迹接口*/
  private def scheduleCTTraj(axle_number:Int,x1:Double,y1:Double,x2:Double,y2:Double,vehicle_type:Int,planDate:String): (JSONArray,String) = {

    // val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=0&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&opt=sf2&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val historyTrajUrl = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&fencedist=50&type=0&strategy=3&fixedroute=2&test=0&stype=0&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=2&cc=1&merge=4&etype=2&opt=sf2&rarefy=0&frequency=1&axleNumber=%s&x1=%s&y1=%s&x2=%s&y2=%s&vehicle=%s&planDate=%s&passport=100000&tolls=1"
    val joArray = new JSONArray()
    val url = String.format(historyTrajUrl.toString,axle_number.toString,x1.toString,y1.toString,x2.toString,y2.toString,vehicle_type.toString,planDate.toString)
    val response = Utils.Utils.retryGet(url)

    var errLog =""
    try {
      //val response = Source.fromURL(url,"UTF-8").mkString
      if(StringUtils.nonEmpty(response)) {
        if (JSONUtils.isValidJSON(response)) {
          val response2 = JSON.parseObject(response)
          val rt_status = response2.getString("status")
          val resultList  = response2.getJSONObject("result")
          val list = resultList.getJSONArray("list")

          for(i<- (0 until list.size())){
            val jo = new JSONObject()
            val result = list.getJSONObject(i)
            val rt_dist = result.getInteger("dist").toDouble / 1000
            val rt_time = result.getInteger("time")
            val rt_tolls = JSONUtils.getJsonValueDouble(result,"tolls",0.0)
            val rt_coords= result.getJSONArray("coords").toJSONString
            val rt_src = result.getString("src")
            val rt_flen = result.getInteger("flen")
            val rt_tlen = result.getInteger("tlen")
            val rt_tollsDistance= result.getInteger("tollsDistance")
            val rt_highway= result.getInteger("highway")
            val rt_traLightCount= result.getInteger("traLightCount")

            jo.put("rt_status",rt_status)
            jo.put("rt_dist",rt_dist)
            jo.put("rt_time",rt_time)
            jo.put("rt_tolls",rt_tolls)
            jo.put("rt_coords",rt_coords)
            jo.put("rt_src",rt_src)
            jo.put("rt_flen",rt_flen)
            jo.put("rt_tlen",rt_tlen)
            jo.put("rt_plan_order",i)
            jo.put("data_source","ct")
            jo.put("rt_url",url)
            jo.put("rt_tollsDistance",rt_tollsDistance)

            joArray.add(jo)
          }
        }
      }
    } catch {
      case e: Exception => errLog = errLog + e.getMessage + "请求的url为" + url + "response为：" + response
    }
    (joArray,errLog)

  }



  val fixUrl = "http://10.202.116.143:38081/drectify"

  case class Ontime8090(start_time:String,start_dept:String,end_dept:String,vehicle_type:Int,time_p8:Int
                        ,time_p9:Int,his_ontime_rate:Double,ontime80Ratio:Double,ontime90Ratio:Double,groupCnt:Int)

  case class HistoryOntimeDept(
                                line_code:String,
                                start_time: String,
                                start_dept: String,
                                end_dept: String,
                                vehicle_type: String,
                                time_p8: String,
                                time_p9: String,
                                his_ontime_rate: String,
                                p8_ontime_rate: String,
                                p9_ontime_rate: String,
                                group_count: String,
                                dist_p8: String,
                                dist_p9: String,
                                inc_day: String)



  def getLabelData(standardDistEffect: RDD[JSONObject]):RDD[JSONObject] = {

    val unLabelRdd = standardDistEffect.map(x => {
      val line_distance = JSONUtils.getJsonValueDouble(x,"line_distance",1.0)
      val ft_dist = JSONUtils.getJsonValueDouble(x,"ft_dist",0.0)
      val line_time =JSONUtils.getJsonValueDouble(x,"line_time",0.0)
      val time_p9 =JSONUtils.getJsonValueDouble(x,"time_p9",0.0)

      val transoport_level =JSONUtils.getJsonValueInt(x,"transoport_level",1)

      val group_dist_min = JSONUtils.getJsonValueDouble(x,"group_dist_min",0.0)

      val order_source = JSONUtils.getJsonValue(x,"order_source","")


      val dist_flag = (ft_dist,line_distance) match
      {
        case (ft_dist,line_distance)  if  (ft_dist - line_distance) / line_distance > 0.05 => "里程配置偏少超5%"
        case (ft_dist,line_distance)  if  (ft_dist - line_distance) / line_distance < -0.05 => "里程配置偏多超5%"
        case (ft_dist,line_distance)  if  (ft_dist - line_distance) / line_distance <= 0.05 && (ft_dist - line_distance) / line_distance>=0 => "里程配置偏少5%以内"
        case (ft_dist,line_distance)  if  (ft_dist - line_distance) / line_distance < 0  && (ft_dist - line_distance) / line_distance >= -0.05 => "里程配置偏多5%以内"
        case  _ => "其它"
      }

      val time_flag = (transoport_level,time_p9,line_time) match
      {
        case (transoport_level,time_p9,line_time) if ( transoport_level== 1 && (time_p9 - line_time) > 10 ) => "时效不足超10分钟"
        case (transoport_level,time_p9,line_time) if ( transoport_level== 1 && (time_p9 - line_time) < -10 ) => "时效过多超10分钟"
        case (transoport_level,time_p9,line_time) if ( transoport_level== 1 && (time_p9 - line_time) >= 0 && (time_p9 - line_time) <= 10 ) => "时效不足10分钟内"
        case (transoport_level,time_p9,line_time) if ( transoport_level== 1 && (time_p9 - line_time) >= -10 && (time_p9 - line_time) <0 ) => "时效过多10分钟内"

        case (transoport_level,time_p9,line_time) if (transoport_level != 1 && (time_p9 - line_time) >5 ) => "时效不足超5分钟"
        case (transoport_level,time_p9,line_time) if (transoport_level != 1 && (time_p9 - line_time) < -5 ) => "时效过多超5分钟"
        case (transoport_level,time_p9,line_time) if (transoport_level != 1 && (time_p9 - line_time) >= 0 &&  (time_p9 - line_time) <= 5 ) => "时效不足超5分钟"
        case (transoport_level,time_p9,line_time) if (transoport_level != 1 && (time_p9 - line_time) >= -5 && (time_p9 - line_time) < 0 ) => "时效不足超5分钟"

        case _ => "其它"

      }


      val builder = new mutable.StringBuilder()


      if ((transoport_level == 1 || transoport_level == 2)) {

        if ((ft_dist - line_distance) / line_distance <= -0.05 || (ft_dist - line_distance) <= -50) {
          builder.append("·").append("压缩里程")
        } else {
          if ((ft_dist - line_distance) / line_distance >= 0.05 || (ft_dist - line_distance) >= 50) {
            if ((group_dist_min - line_distance) / line_distance >= 0.04 || group_dist_min - line_distance >= 40) {
              if (!order_source.equals("gd") && !order_source.equals("ct") && !order_source.equals("tracks") && !order_source.equals("jy") && !order_source.equals("jy|tracks") && !order_source.equals("tracks|jy")) {
                builder.append("·").append("延长里程")
              }
            }
          }
        }
      } else if (transoport_level == 3) {
        if ((ft_dist - line_distance) / line_distance <= -0.05) {
          builder.append("·").append("压缩里程")
        } else {
          if ((ft_dist - line_distance) / line_distance >= 0.05) {
            if ((group_dist_min - line_distance) / line_distance >= 0.04 || group_dist_min - line_distance >= 40) {
              if (!order_source.equals("gd") && !order_source.equals("ct") && !order_source.equals("tracks") && !order_source.equals("jy") && !order_source.equals("jy|tracks") && !order_source.equals("tracks|jy")) {
                builder.append("·").append("延长里程")
              }
            }
          }
        }
      }


      //计算参考车速 （结果保留2位小数）
      val ref_speed =  (ft_dist * 60 / time_p9).formatted("%.2f").toDouble
      var res_abnormal = ""

      if((ft_dist/line_distance) < 0.5){
        res_abnormal = res_abnormal + "1" + "|"
      }

      if((ft_dist/line_distance) > 1.5){
        res_abnormal = res_abnormal + "2" + "|"
      }

      if(ref_speed > 80.0){
        res_abnormal = res_abnormal + "3" + "|"
      }

      if(ref_speed < 15.0){
        res_abnormal = res_abnormal + "4" + "|"
      }

      //time_p9>60 min 且 time_p9/line_time<0.5
      if(time_p9>60 && time_p9/line_time < 0.5){
        res_abnormal = res_abnormal + "5" + "|"
      }

      if(time_p9>60 && time_p9/line_time > 1.5){
        res_abnormal = res_abnormal + "6" + "|"
      }

      x.put("dist_flag",dist_flag)
      x.put("time_flag",time_flag)
      if(ref_speed.isInfinity){
        x.put("ref_speed","")
      }else{
        x.put("ref_speed",ref_speed)
      }

      x.put("ft_time",time_p9)
      x.put("res_abnormal",res_abnormal)
      x.put("flag",builder.toString())
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    unLabelRdd
  }




  def getDistEffect(spark: SparkSession, inc_day: String, ftDistTimeRdd: RDD[JSONObject], standardTimeEffect: RDD[JSONObject]):RDD[JSONObject] = {

    //待去重
    val distEffect = ftDistTimeRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = x.getString("axle_number")
      ((start_time, start_dept, end_dept, vehicle_type ,axle_number), x)
    }).reduceByKey((obj1, obj2) => obj1).map(x => {
      val ftDistRdd = x._2
      val (start_time, start_dept, end_dept, vehicle_type,axle_number) = x._1
      ((start_time, start_dept, end_dept, vehicle_type,axle_number), ftDistRdd)
    })

    logger.error("getDistEffect的数据量为：" + distEffect.count())

    val timeEffect = standardTimeEffect.map(x => {
      //line_code、start_dept、end_dept、vehicle_type
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = x.getString("axle_number")
      ((start_time, start_dept, end_dept, vehicle_type,axle_number), x)
    })
    logger.error("timeEffect的数据量为：" + timeEffect.count())

    /**
      * 以步骤7.2.1关联后结果为左表，根据start_time、start_dept、end_dept、vehicle_type关联，
      * 获取标准里程（ft_dist）、路桥费（ft_tolls）、轨迹（ft_coords）、数据来源（data_source）、交集情况（order_source）、请求链接（ft_url）
      */

    val distEffectRdd = timeEffect.leftOuterJoin(distEffect).map(x => {
      val left= x._2._1
      val rightOption = x._2._2
      val manual_report_id = left.getString("manual_report_id")
      val is_match = left.getString("is_match")

      if(!rightOption.isEmpty){
        val ontime = rightOption.get

        val ft_dist = ontime.getString("rt_dist")
        val ft_time = ontime.getString("rt_time")
        val ft_coords = ontime.getString("rt_coords")
        val ft_tolls = ontime.getString("tolls")
        val ft_url = ontime.getString("rt_url")
        val task_area_code = ontime.getString("task_area_code")

        left.put("ft_dist",ft_dist)
        left.put("ft_time",ft_time)
        left.put("ft_coords",ft_coords)
        left.put("ft_tolls",ft_tolls)
        left.put("ft_url",ft_url)
        left.put("task_area_code",task_area_code)

        left.fluentPutAll(ontime)
        left.put("manual_report_id",manual_report_id)
        left.put("is_match",is_match)
      }

      left
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("distEffectRdd的数据量为：" + distEffectRdd.count())
    distEffectRdd.take(2).foreach(println(_))

    distEffectRdd
  }


  /**
    * 根据已有车型，判断对应缺失车型
    * @param hashMap
    * @param value
    * @return
    */
  def valueGetKey(hashMap: mutable.HashMap[Int, Int], value: Int ):ArrayBuffer[Int] = {
    val buffer = new ArrayBuffer[Int]()
    val list = hashMap.keySet

    list.map( x => {
      if(hashMap.get(x).get.equals(value)){
        buffer.append(x)
      }
    })
    buffer
  }

  def getTimeEffect(spark: SparkSession, inc_day: String, ontimeRateRdd: RDD[JSONObject], markUnVerifyRdd: RDD[JSONObject]):RDD[JSONObject] = {

    val ontimeRateRddJoin = ontimeRateRdd.map(x =>{
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")

      ((start_time,start_dept,end_dept,vehicle_type),x)
      //((start_time,start_dept,end_dept),x)
    }).reduceByKey((obj1,obj2) => {obj1}).map(x => {
      val ontimeRdd = x._2
      val (start_time,start_dept,end_dept,vehicle_type) = x._1
      ((start_time,start_dept,end_dept),ontimeRdd)

    }).groupByKey().flatMap(x => {
      val list = x._2.toBuffer
      val listNew = new ArrayBuffer[JSONObject]()

      val setAll = Set(5,6,7,8)

      val setPre = mutable.Set[Int]()
      //val seq = Seq[Int]()
      val hashMap = new mutable.HashMap[Int,Int]()

      if(list.size>0){
        val listSort = list.sortBy(_.getIntValue("vehicle_type"))
        listSort.map(x => {
          val vehicle_type = x.getIntValue("vehicle_type")
          setPre.add(vehicle_type)
        })
        //获取缺失的vehicle_type
        val setData = setPre.toSeq.sortBy(x => x).toSet
        val lackSet = setAll.diff(setData)

        for(i <- lackSet if lackSet.size > 0){
          var flag =0
          for(j <- setData if flag==0){
            if(i<j){
              hashMap.put(i,j)
            }
          }
          if(flag==0){
            hashMap.put(i,try{setData.max} catch {case e:Exception => 8})
          }
        }

        //遍历添加缺失的vehicle_type
        for (i<- 0 until(list.size)){
          listNew.append(list(i))
          val vehicle_type = list(i).getIntValue("vehicle_type")
          if(hashMap.values.mkString.contains(vehicle_type.toString)){
            val buffer = valueGetKey(hashMap,vehicle_type)
            buffer.map(x => {
              val jo = new JSONObject()
              jo.fluentPutAll(list(i))
              jo.put("vehicle_type", x)
              listNew.append(jo)
            })
          }
        }
      }
      listNew
    }).map(x =>{
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      ((start_time,start_dept,end_dept,vehicle_type),x)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("ontimeRateRddJoin的数据量为：" + ontimeRateRddJoin.count())
    ontimeRateRddJoin.take(2).foreach(println(_))


    val joinRdd = markUnVerifyRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = JSONUtils.getJsonValueInt(x,"vehicle_type",6).toString

      ((start_time,start_dept,end_dept,vehicle_type),x)

    }).leftOuterJoin(ontimeRateRddJoin).map( x =>{
      val left= x._2._1
      val rightOption = x._2._2
      if(!rightOption.isEmpty){
        val ontime = rightOption.get
        left.fluentPutAll(ontime)
      }
      left
    })
    joinRdd
  }


  def getVehicle(undefineDataRdd: RDD[JSONObject]) = {
    val unVerifyRdd = undefineDataRdd.map(x => {

      var vehicle_type =6
      var axle_number =2
      if(!StringUtils.nonEmpty(x.getString("full_load_weight"))){
        val full_load_weight = try{x.getString("full_load_weight").replaceAll("T","").asInstanceOf[Double]}catch {case e:Exception => 0.0}
        //val full_load_weight = JSONUtils.getJsonValueDouble(x,"full_load_weight",0.0)

        vehicle_type = full_load_weight match {
          case full_load_weight if(full_load_weight<=1.0) => 5
          case full_load_weight if(full_load_weight>1.0 && full_load_weight<3.0) => 6
          case full_load_weight if(full_load_weight>=3.0 && full_load_weight<7.0) => 7
          case full_load_weight if(full_load_weight >= 7.0) => 8
        }

        axle_number = full_load_weight match {
          case full_load_weight if(full_load_weight>=0 && full_load_weight <=9.5) => 2
          case full_load_weight if(full_load_weight>9.5 && full_load_weight<=14) => 3
          case full_load_weight if(full_load_weight>14 && full_load_weight<=20) => 4
          case full_load_weight if(full_load_weight>20 && full_load_weight<=25) => 5
          case full_load_weight if(full_load_weight >= 25) => 6
        }
        x.put("vehicle_type",vehicle_type)
        x.put("axle_number",axle_number)
      }else{
        val car_type = x.getString("car_type")
        if("厢式运输车".equals(car_type)){
          vehicle_type = 8
          axle_number = 4
        }
      }
      x.put("vehicle_type",vehicle_type)
      x.put("axle_number",axle_number)

      x
    })
    unVerifyRdd
  }

  def getUndefineData(spark: SparkSession, inc_day:String, beginDay:String,endDay:String) = {

    //    val beginDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -30)
    //    val endDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 2)
//    val beginDay= "20210701"
//    val endDay ="20210720"


//    val undefineSql =
//      s"""
//         |select
//         |  substr(plan_depart_tm,0,4) start_time,'1.5T' full_load_weight,*,'1' is_manual_report,id manual_report_id
//         |from
//         |  dm_gis.exception_report_line
//         | where
//         |  inc_day >='20210730'
//         | and
//         |  inc_day <='20210805'
//         |  -- and
//         |  -- line_code in ('020JG020W1505','757AC757WA1745','020LE020WM2010','020AF020W1050')
//         |
//       """.stripMargin
    val beginDay2= DateTimeUtil.getDaysApartDate("yyyyMMdd", beginDay, -7)
    val endDay2= DateTimeUtil.getDaysApartDate("yyyyMMdd", endDay, 2)

    val undefineSql =
      s"""
         |select
         |  substr(plan_depart_tm,0,4) start_time,'1.5T' full_load_weight,*,'1' is_manual_report,id manual_report_id
         |from
         |  dm_gis.exception_report_line
         | where
         |  inc_day >='${beginDay}'
         | and
         |  inc_day <='${endDay}'
       """.stripMargin



    val middle0Sql =
      s"""
         |select
         |  *,axis_number axle_number
         |from
         |dm_gis.eta_grd_middle0
         |where
         |  inc_day >='${beginDay2}'
         |and
         |  inc_day <= '${endDay2}'
         |and
         |  start_dept != end_dept
         | -- and
         | -- line_code in ('020JG020W1505','757AC757WA1745','020LE020WM2010','020AF020W1050')
         | --  line_code in ('752WK752WH0659','752WK752WH0700','791WH760WH0800','028WH029WH0600','028WH371WH0600','991WH998R2359','551VJ757WL0359','551VJ757WL0359','551VJ028WH0359','551VJ028WH0359','579WH351WK0500','576WH022WH0301','576WH024WH0600','576WH531WK0301','576WH028WH0600','576WH029WH0300','558WH769WK0300','558WH769WK0300','571XF575WK0700','571XF575WK0200','571AAG7311WH0300','576WH595WH0300','573XF791WH0700','573XF791WH0700','571AAG022WH0300','574WG551WH0130','573XF024WH0700','551WH029WH0628','551WH028WH0558','551WH028WH0558','551WH311WK0600','573XF517WH2200','573XF517WH2200','573XF517WH2200','574WG577WH2100','574WG577WH2100','571R571BB1400','571CGG571W2030','575EAA575W1910','575EG575EA0940','575EC575EG1720','575EJ575W2001','571CGG571WJ2100','575W575JTD0620','351W353VA1700','359U359W1930','359W359U1400','359U359W1100','359W359U0640','359T359W2030','359T359W1740','359W359T1400','359T359W1140','359W359T0640','359TH359W2030','359TH359W1800','359W359TH1400','359TH359W1150','359W359TH0920','359AA359W1940','359W359AA1400','359AA359W1110','359W359AA0700','359W359BF0640','359BQ359W2020','359BQ359W1730','359W359BQ1400','359BQ359W1130','359W359BQ0700','359W359BA1400','359BA359W1145','359W359BA0700','359W359N1400','359N359W1140','359W359N0700','355VA355JCJ0630','355VA355JCJ1320','355JCJ355VA1930','053VA859AA0300','053VA859AG0300','053VA859SA0300','053VA859AC0300','053VA859AF0330','053VA859AH0500','053VA859SA0900','053VA859AA0900','053VA859AC0900','053VA859AF1000','053VA859TH1000','859AA053VA1235','859SA053VA1310','859TH053VA1400','859AG053VA1815','859AF053VA1840','859AA053VA1845','859SA053VA1900','859AH053VA1930','021WJ021DJF0550','021EB021WW2120','021EU021WW2110','021TBBF021WF2355','021TBBF021WF1330','021TH021WF1340','021TH021WF2150','021TH021WF2355','021TH021WF1445','021WF021TB0541','021WF021TB0550','021WF021TB0800','021WF021TB0450','021TB021WF2130','518FB518W1230','518BN518W1430','518W518BN1210','518CN518W1900','518CF518W2130','577L577WH2130','577WB577DA0600')
         """.stripMargin

    val middle1Sql =
      s"""
         |select
         | start_time,start_dept,end_dept,inc_day,vehicle_type,rt_dist
         |from
         |  dm_gis.eta_traj_simgroup_info
         |where
         |  inc_day >='${beginDay2}'
         |and
         |  inc_day <= '${endDay2}'
         | --  and
         | -- line_code in ('020JG020W1505','757AC757WA1745','020LE020WM2010','020AF020W1050')
         | -- and
         | -- line_code in ('752WK752WH0659','752WK752WH0700','791WH760WH0800','028WH029WH0600','028WH371WH0600','991WH998R2359','551VJ757WL0359','551VJ757WL0359','551VJ028WH0359','551VJ028WH0359','579WH351WK0500','576WH022WH0301','576WH024WH0600','576WH531WK0301','576WH028WH0600','576WH029WH0300','558WH769WK0300','558WH769WK0300','571XF575WK0700','571XF575WK0200','571AAG7311WH0300','576WH595WH0300','573XF791WH0700','573XF791WH0700','571AAG022WH0300','574WG551WH0130','573XF024WH0700','551WH029WH0628','551WH028WH0558','551WH028WH0558','551WH311WK0600','573XF517WH2200','573XF517WH2200','573XF517WH2200','574WG577WH2100','574WG577WH2100','571R571BB1400','571CGG571W2030','575EAA575W1910','575EG575EA0940','575EC575EG1720','575EJ575W2001','571CGG571WJ2100','575W575JTD0620','351W353VA1700','359U359W1930','359W359U1400','359U359W1100','359W359U0640','359T359W2030','359T359W1740','359W359T1400','359T359W1140','359W359T0640','359TH359W2030','359TH359W1800','359W359TH1400','359TH359W1150','359W359TH0920','359AA359W1940','359W359AA1400','359AA359W1110','359W359AA0700','359W359BF0640','359BQ359W2020','359BQ359W1730','359W359BQ1400','359BQ359W1130','359W359BQ0700','359W359BA1400','359BA359W1145','359W359BA0700','359W359N1400','359N359W1140','359W359N0700','355VA355JCJ0630','355VA355JCJ1320','355JCJ355VA1930','053VA859AA0300','053VA859AG0300','053VA859SA0300','053VA859AC0300','053VA859AF0330','053VA859AH0500','053VA859SA0900','053VA859AA0900','053VA859AC0900','053VA859AF1000','053VA859TH1000','859AA053VA1235','859SA053VA1310','859TH053VA1400','859AG053VA1815','859AF053VA1840','859AA053VA1845','859SA053VA1900','859AH053VA1930','021WJ021DJF0550','021EB021WW2120','021EU021WW2110','021TBBF021WF2355','021TBBF021WF1330','021TH021WF1340','021TH021WF2150','021TH021WF2355','021TH021WF1445','021WF021TB0541','021WF021TB0550','021WF021TB0800','021WF021TB0450','021TB021WF2130','518FB518W1230','518BN518W1430','518W518BN1210','518CN518W1900','518CF518W2130','577L577WH2130','577WB577DA0600')
         """.stripMargin



    val unDefineDF = spark.sql(undefineSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("unDefineDF的数据量为：" + unDefineDF.count())
    unDefineDF.take(2).foreach(println(_))
    unDefineDF.createOrReplaceTempView("unDefineTable")


    val inc_day2 = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -1)
//    val joinWorkDaySql =
//      s"""
//         |select
//         |  *
//         |from
//         |(
//         |select
//         |  *,row_number() over(
//         |    PARTITION by id
//         |    order by
//         |      is_match
//         |    ) rn_new
//         |from
//         |(
//         |select
//         |   a.*,b.pass_id pass_id,b.work_day work_day,b.revise_distance,b.revise_run_tm,if(b.line_code ='' or b.line_code is null,1,0) is_match
//         |from
//         |unDefineTable a
//         |left outer join
//         |(
//         |select
//         |  *,
//         |  split(pass.plan_depart_tm_new, '-') [0] as join_tm1,
//         |  split(pass.plan_depart_tm_new, '-') [1] as join_tm2
//         |from
//         |  (
//         |    select
//         |      row_number() over(
//         |        PARTITION by line_code,
//         |        load_zone_code,
//         |        dest_zone_code,
//         |        plan_depart_tm
//         |        ORDER by
//         |          inc_day desc
//         |      ) as rn,
//         |      id pass_id,
//         |      work_days work_day,
//         |      if(
//         |        plan_depart_tm = ''
//         |        or plan_depart_tm is null,
//         |        '0000-0000',
//         |        plan_depart_tm
//         |      ) plan_depart_tm_new,
//         |      *
//         |    from
//         |      dm_pass_rss.rmsa_tm_distance_times_pro
//         |    where
//         |      inc_day='${inc_day2}'
//         |    and
//         |      oper_type != 3
//         |  ) pass
//         |    where
//         |      pass.rn =1
//         |) b
//         |on a.start_dept = b.load_zone_code
//         |and a.end_dept = b.dest_zone_code
//         |and (a.line_code = b.line_code or (a.start_time >=join_tm1 and a.start_time <=join_tm2 and (b.line_code is null or b.line_code ="") ))
//         |) aa
//         |) aaa
//         |where
//         |  aaa.rn_new=1
//       """.stripMargin

    val joinWorkDaySql =
      s"""
         |select
         |  *
         |from
         |(
         |select
         |   a.*,'' as pass_id,'1234567' work_day,0 as revise_distance,0 as revise_run_tm,'0' as is_match
         |from
         |unDefineTable a
         |) aa
       """.stripMargin

    val unDefineDF2 = spark.sql(joinWorkDaySql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("unDefineDF2的数据量为：" + unDefineDF2.count())
    unDefineDF2.take(2).foreach(println(_))
    unDefineDF2.createOrReplaceTempView("linecode_info_table")


    val middle0DF = spark.sql(middle0Sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("middle0DF历史轨迹数据量为:" + middle0DF.count())
    middle0DF.take(2).foreach(println(_))

    val middle1DF = spark.sql(middle1Sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("middle1DF数据量为:" + middle1DF.count())
    middle1DF.take(2).foreach(println(_))

    middle0DF.createOrReplaceTempView("temp_gj_history")




    val inc_day_next = DateTimeUtil.getLastTwoWeekMS(inc_day,"yyyyMMdd")

    val monday = inc_day_next._1
    val sunday = inc_day_next._2


    logger.error("打印关联轨迹")


//    val undefinedData =
//      s"""
//         |select
//         |    *
//         |from
//         |(
//         |select *,if(work_day in ('6','7','67'),1,0) work_day_tag
//         |from
//         |linecode_info_table0
//         |) a
//       """.stripMargin
//    val pretreatmentUndefinedDF = spark.sql(undefinedData).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("pretreatmentUndefinedDF的数据量为：" + pretreatmentUndefinedDF.count())
//    pretreatmentUndefinedDF.take(2).foreach(println(_))
//
//    pretreatmentUndefinedDF.createOrReplaceTempView("linecode_info_table")



//    val joinSql =
//      s"""
//         |select
//         |  x1,y1,x2,y2,line_code,'' height,'' axle_weight,'' axle_number,'' vehicle,'' vehicle_color,'' energy,'' width,'' length,
//         |  if(work_day_tag=1,concat(${sunday},start_time,"00"),concat(${monday},start_time,"00")) plan_date,
//         |  start_dept,end_dept,full_load_weight,start_time,pass_id,work_day,revise_distance,revise_run_tm,id manual_report_id,
//         |  task_area_code,fixed_run_time,fixed_mileage,update_start_date,data_type,operation_type,operation_reason,
//         |  adapt_day,user_code,batch_id,is_match
//         |from
//         |  (
//         |    select
//         |      aa.*,x2,y2
//         |    from
//         |      (
//         |        select
//         |          a.*,
//         |          longitude x1,
//         |          latitude y1
//         |        from
//         |          linecode_info_table a
//         |          left outer join (
//         |            select
//         |              dept_code,
//         |              longitude,
//         |              latitude
//         |            from
//         |              dim.dim_department
//         |            where
//         |              delete_flg != 1
//         |              and area_code is not null
//         |              and longitude is not null
//         |          ) c on a.start_dept = c.dept_code
//         |      ) aa
//         |      left outer join (
//         |            select
//         |              dept_code,
//         |              longitude x2,
//         |              latitude y2
//         |            from
//         |              dim.dim_department
//         |            where
//         |              delete_flg != 1
//         |              and area_code is not null
//         |              and longitude is not null
//         |      ) bb on aa.end_dept = bb.dept_code
//         |  ) aaa
//       """.stripMargin

//    val joinSql =
//      s"""
//         |select
//         |  x1,y1,x2,y2,line_code,'' height,'' axle_weight,'' axle_number,'' vehicle,'' vehicle_color,'' energy,'' width,'' length,
//         |  if(work_day_tag=1,concat(${sunday},start_time,"00"),concat(${monday},start_time,"00")) plan_date,
//         |  start_dept,end_dept,full_load_weight,start_time,pass_id,work_day,revise_distance,revise_run_tm,id manual_report_id,
//         |  task_area_code,fixed_run_time,fixed_mileage,inc_day update_start_date,'' data_type,'' operation_type,''operation_reason,
//         |  '' adapt_day,'' user_code,'' batch_id,is_match
//         |from
//         |  (
//         |    select
//         |      aa.*,x2,y2
//         |    from
//         |      (
//         |        select
//         |          a.*,
//         |          longitude x1,
//         |          latitude y1
//         |        from
//         |          linecode_info_table a
//         |          left outer join (
//         |            select
//         |              dept_code,
//         |              longitude,
//         |              latitude
//         |            from
//         |              (
//         |                select
//         |                  row_number() over(
//         |                    PARTITION by dept_code
//         |                    ORDER by
//         |                      delete_flg asc
//         |                  ) as rn,
//         |                  dept_code,
//         |                  longitude,
//         |                  latitude
//         |                from
//         |                  dim.dim_department t
//         |                where
//         |                  longitude != ''
//         |                  and latitude != ''
//         |              ) dim
//         |            where
//         |              dim.rn = 1
//         |          ) c on a.start_dept = c.dept_code
//         |      ) aa
//         |      left outer join (
//         |            select
//         |              dept_code,
//         |              longitude x2,
//         |              latitude y2
//         |            from
//         |              (
//         |                select
//         |                  row_number() over(
//         |                    PARTITION by dept_code
//         |                    ORDER by
//         |                      delete_flg asc
//         |                  ) as rn,
//         |                  dept_code,
//         |                  longitude,
//         |                  latitude
//         |                from
//         |                  dim.dim_department t
//         |                where
//         |                  longitude != ''
//         |                  and latitude != ''
//         |              ) dim
//         |            where
//         |              dim.rn = 1
//         |      ) bb on aa.end_dept = bb.dept_code
//         |  ) aaa
//       """.stripMargin

    val joinSql =
      s"""
         |select
         |  x1,y1,x2,y2,line_code,'' height,'' axle_weight,'' axle_number,'' vehicle,'' vehicle_color,'' energy,'' width,'' length,
         |  concat(${monday},start_time,"00") plan_date,
         |  start_dept,end_dept,full_load_weight,start_time,pass_id,work_day,revise_distance,revise_run_tm,id manual_report_id,
         |  task_area_code,fixed_run_time,fixed_mileage,inc_day update_start_date,'' data_type,'' operation_type,''operation_reason,
         |  '' adapt_day,'' user_code,'' batch_id,'1' is_match
         |from
         |  (
         |    select
         |      aa.*,x2,y2
         |    from
         |      (
         |        select
         |          a.*,
         |          longitude x1,
         |          latitude y1
         |        from
         |          linecode_info_table a
         |          left outer join (
         |            select
         |              dept_code,
         |              longitude,
         |              latitude
         |            from
         |              (
         |                select
         |                  row_number() over(
         |                    PARTITION by dept_code
         |                    ORDER by
         |                      delete_flg asc
         |                  ) as rn,
         |                  dept_code,
         |                  longitude,
         |                  latitude
         |                from
         |                  dim.dim_department t
         |                where
         |                  longitude != ''
         |                  and latitude != ''
         |              ) dim
         |            where
         |              dim.rn = 1
         |          ) c on a.start_dept = c.dept_code
         |      ) aa
         |      left outer join (
         |            select
         |              dept_code,
         |              longitude x2,
         |              latitude y2
         |            from
         |              (
         |                select
         |                  row_number() over(
         |                    PARTITION by dept_code
         |                    ORDER by
         |                      delete_flg asc
         |                  ) as rn,
         |                  dept_code,
         |                  longitude,
         |                  latitude
         |                from
         |                  dim.dim_department t
         |                where
         |                  longitude != ''
         |                  and latitude != ''
         |              ) dim
         |            where
         |              dim.rn = 1
         |      ) bb on aa.end_dept = bb.dept_code
         |  ) aaa
       """.stripMargin

    val rep = spark.sql(joinSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("rep的数据量为：" + rep.count())
    rep.take(2).foreach(println(_))
    val colList = rep.columns

    val undefineDataRdd = rep.rdd.repartition(200).map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).map(x => {
      val pass_id = x.getString("pass_id")
      (pass_id,x)
    })
//      .groupByKey().map(x => {
//
//      val pass_id = x._1
//      val list = x._2.toList
//      val maxVehicleType = list.maxBy(obj => {JSONUtils.getJsonValueInt(obj,"vehicle_type",6)})
//      maxVehicleType
//    })
      .filter(x => {
        StringUtils.nonEmpty(x._2.getString("x1")) && StringUtils.nonEmpty(x._2.getString("y1")) && StringUtils.nonEmpty(x._2.getString("x2")) && StringUtils.nonEmpty(x._2.getString("y2"))
        //StringUtils.nonEmpty(x.getString("x1")) && StringUtils.nonEmpty(x.getString("y1")) && StringUtils.nonEmpty(x.getString("x2")) && StringUtils.nonEmpty(x.getString("y2"))
    }).map(_._2).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("undefineDataRdd数据量为：" + undefineDataRdd.count())
    undefineDataRdd.take(2).foreach(println(_))
    rep.unpersist()

    val vehicleRdd  = getVehicle(undefineDataRdd)


    val fixManualRdd  = vehicleRdd.map(x => {

      val full_load_weight = x.getString("full_load_weight").replaceAll("T","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","0000")
      val update_start_date = x.getString("update_start_date")
      val revise_distance = JSONUtils.getJsonValueDouble(x,"revise_distance",0.0)
      val revise_run_time = JSONUtils.getJsonValueInt(x,"revise_run_tm",0)

      val line_distance = revise_distance/1000
      val line_time = revise_run_time/60

      val plan_depart_tm_pre = update_start_date +" "+ start_time + "00"
      val plan_depart_tm_pre2 = update_start_date + " " + "000000"
      val plan_depart_tm = try {DateTimeUtil.getConvertFormatDate(plan_depart_tm_pre,"yyyyMMdd HHmmss","yyyy-MM-dd HH:mm:ss")} catch {case e:Exception => DateTimeUtil.getConvertFormatDate(plan_depart_tm_pre2,"yyyyMMdd HHmmss","yyyy-MM-dd HH:mm:ss")}
      val plan_arrive_tm = DateTimeUtil.getMinBeforeAfter(plan_depart_tm,"yyyy-MM-dd HH:mm:ss",line_time)


      //val plan_arrive_tm = plan_depart_tm + line_time

      x.put("transoport_level","2")
      x.put("trans_car","自营")
      x.put("line_distance",line_distance)
      x.put("line_time",line_time)
      x.put("full_load_weight",full_load_weight)
      x.put("plan_depart_tm",plan_depart_tm)
      x.put("plan_arrive_tm",plan_arrive_tm)

      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("fixManualRdd的数据量为:" +fixManualRdd.count())
    fixManualRdd.take(2).foreach(println(_))


    (fixManualRdd,middle0DF,middle1DF)
  }



  def markUnVerify(getUndefineRdd:RDD[JSONObject]):RDD[JSONObject]= {

    val unVerifyRdd = getUndefineRdd.map(x => {

      var vehicle_type =6
      var axle_number =2
      if(!StringUtils.nonEmpty(x.getString("full_load_weight"))){
        val full_load_weight = JSONUtils.getJsonValueDouble(x,"full_load_weight",0.0)

        vehicle_type = full_load_weight match {
          case full_load_weight if(full_load_weight<=1.0) => 5
          case full_load_weight if(full_load_weight>1.0 && full_load_weight<3.0) => 6
          case full_load_weight if(full_load_weight>=3.0 && full_load_weight<7.0) => 7
          case full_load_weight if(full_load_weight >= 7.0) => 8
        }

        axle_number = full_load_weight match {
          case full_load_weight if(full_load_weight>=0 && full_load_weight <=9.5) => 2
          case full_load_weight if(full_load_weight>9.5 && full_load_weight<=14) => 3
          case full_load_weight if(full_load_weight>14 && full_load_weight<=20) => 4
          case full_load_weight if(full_load_weight>20 && full_load_weight<=25) => 5
          case full_load_weight if(full_load_weight >= 25) => 6
        }
        x.put("vehicle_type",vehicle_type)
        x.put("axle_number",axle_number)
      }else{
        val car_type = x.getString("car_type")
        if("厢式运输车".equals(car_type)){
          vehicle_type = 8
          axle_number = 4
        }
      }
      x.put("vehicle_type",vehicle_type)
      x.put("axle_number",axle_number)

      x
    })
    unVerifyRdd
  }


  def calFtDistTime(trajIntersectRdd: RDD[JSONObject]):RDD[JSONObject] = {

    val totalFtDist = trajIntersectRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = JSONUtils.getJsonValueInt(x,"axle_number",2)
      ((start_time,start_dept,end_dept,vehicle_type,axle_number),x)
    }).groupByKey().map(x => {
      val list = x._2.toList

      val listNew = list.toStream.map(obj => {
        val order_source = obj.getString("order_source")
        val month_freq = JSONUtils.getJsonValueInt(obj, "month_freq", 0)
        var gjTag = 0
        var gdTag = 0
        var ctTag = 0

        if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && order_source.contains("jy")) {
          obj.put("gjTag", 100)
          gjTag = 100
        } else if (StringUtils.nonEmpty(order_source) && !order_source.contains("tracks") && order_source.contains("jy")) {
          obj.put("gjTag", 80)
          gjTag = 80
        } else if (StringUtils.nonEmpty(order_source) && !order_source.contains("jy") && order_source.contains("tracks") && month_freq >= 10) {
          obj.put("gjTag", 85)
          gjTag = 85
        } else if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && !order_source.contains("jy") && month_freq < 10 && month_freq >= 5) {
          obj.put("gjTag", 80)
          gjTag = 80
        } else if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && !order_source.contains("jy") && month_freq < 5 && month_freq >= 3) {
          obj.put("gjTag", 70)
          gjTag = 70
        } else if (StringUtils.nonEmpty(order_source) && order_source.contains("tracks") && !order_source.contains("jy") && month_freq < 3) {
          obj.put("gjTag", 50)
          gjTag = 50
        } else if (StringUtils.nonEmpty(order_source) && !order_source.contains("tracks") && !order_source.contains("jy")) {
          obj.put("gjTag", 0)
          gjTag = 0
        }

        if (StringUtils.nonEmpty(order_source) && order_source.contains("gd")) {
          obj.put("gdTag", 95)
          gdTag = 95
        } else {
          obj.put("gdTag", 0)
          gdTag = 0
        }
        if (StringUtils.nonEmpty(order_source) && order_source.contains("ct")) {
          obj.put("ctTag", 90)
          ctTag = 90
        } else {
          obj.put("ctTag", 0)
          ctTag = 0
        }

        val data_source = obj.getString("data_source")
        if (StringUtils.nonEmpty(data_source)) {
          val dataSourceIndex = data_source match {

            case data_source if data_source.equals("gd") => 4
            case data_source if data_source.equals("ct") => 3
            case data_source if data_source.equals("jy") => 2
            case data_source if data_source.equals("tracks") => 1
          }
          obj.put("dataSourceIndex", dataSourceIndex)
        }

        val cornAll = gjTag + gdTag + ctTag
        obj.put("scoreAll", cornAll)
        obj
      })


      val ft_time_pre = listNew.maxBy(x => {JSONUtils.getJsonValueInt(x,"rt_time",0)})
      val ft_time  = JSONUtils.getJsonValueInt(ft_time_pre,"rt_time",0)

      val group_dist_min = try{listNew.minBy(x => {JSONUtils.getJsonValueDouble(x,"rt_dist",0.0)}).getDoubleValue("rt_dist")} catch {case e:Exception => 0.0}

      val head = listNew.sortBy(x => new SecondarySortByKey(JSONUtils.getJsonValueInt(x,"scoreAll",0),JSONUtils.getJsonValueInt(x,"dataSourceIndex",0))).head

      val ft_dist = head.getString("rt_dist")
      head.put("ft_dist",ft_dist)
      head.put("ft_time",ft_time)
      head.put("group_dist_min",group_dist_min)

      try{
        if (JSONUtils.getJsonValue(head,"data_source","").equals("gd")) {
          val tolls = scheduleGdTolls(head)
          head.put("tolls",tolls)
        }
      }catch {
        case e:Exception => println("调用路桥费请求错误")
      }

      head
    })

    logger.error("totalFtDist的数据量为：" + totalFtDist.count())
    totalFtDist.take(2).foreach(println(_))

    totalFtDist
  }

  def scheduleGdTolls(ft_dist:JSONObject):Double = {
    val axle_number = ft_dist.getString("axle_number")
    val vehicle = JSONUtils.getJsonValue(ft_dist,"vehicle_type","6")
    val speed = JSONUtils.getJsonValueInt(ft_dist,"speed",1)
    val Toll = JSONUtils.getJsonValueInt(ft_dist,"Tolls",1)
    val rt_coords_pre = ft_dist.getString("rt_coords")
    val rt_coords = JSON.parseArray(rt_coords_pre)

    val points = new ArrayBuffer[String]()
    for (i<- 0 until(rt_coords.size())){
      val array = JSON.parseArray(rt_coords.getString(i))
      if(array.size()>0){
        val x = array.getString(0)
        val y = array.getString(1)
        points.append(x)
        points.append(",")
        points.append(y)
        points.append("|")
      }
    }

    //println(points.mkString("").dropRight(1))
    //vehicle=8&axlenumber=0&passport=100000&output=json&mode=2&strategy=0&toll=1&speed=1&stype=0&etype=0&test=1&fencedist=300
    val jo = new mutable.StringBuilder()
    jo.append("vehicle=").append(vehicle).append("&axlenumber=").append(axle_number).append("&passport=100000").append("&output=json&mode=2&strategy=0&toll=1&speed=1&stype=0&etype=0&test=1&fencedist=300&points=")
    jo.append(points.mkString(""))

    val ft_dist_new = HttpClientUtils.httpPostXmlRequest("http://10.216.162.68:7173/qm_point",jo.mkString)

    val response = JSON.parseObject(ft_dist_new)
    val route = response.getJSONObject("route")
    val paths = route.getJSONArray("paths")
    var totalTolls = 0.0

    if(paths.size()>0){
      for(i <- 0 until(paths.size())){
        val pathJson = paths.getJSONObject(i)
        val tolls = JSONUtils.getJsonValueDouble(pathJson,"tolls",0.0)
        totalTolls += tolls
      }
    }
    totalTolls
  }


  def saveTableToRes2(spark: SparkSession, inc_day: String, ftDistTimeRdd: RDD[JSONObject]) = {

    import spark.implicits._
    val labelDataRdd = ftDistTimeRdd.map(x => {

      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val axle_number = x.getString("axle_number")
      val start_time = x.getString("start_time")
      val vehicle_type = x.getString("vehicle_type")
      val order_source = x.getString("order_source")
      val data_source = x.getString("data_source")
      val ft_dist = x.getString("rt_dist")
      val ft_time = x.getString("rt_time")
      val ft_coords = x.getString("rt_coords")
      val ft_tolls = x.getString("tolls")
      val ft_url = x.getString("rt_url")
      val task_area_code = x.getString("task_area_code")
      val group_dist_min = x.getString("group_dist_min")
      //20210618添加
      val rt_src = x.getString("rt_src")
      val score = x.getString("scoreAll")

      val manual_report_id = x.getString("manual_report_id")
      val is_match = x.getString("is_match")

      resTable2(start_dept,end_dept,axle_number,start_time,vehicle_type,order_source,data_source,ft_dist,ft_time,ft_coords,ft_tolls,ft_url ,task_area_code,group_dist_min,rt_src,score,manual_report_id,is_match,inc_day)
    })
    labelDataRdd.toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_route_plan_res2_manual")


  }





  def calTrajIntersect(groupSimRdd: RDD[JSONObject], schemeRouteRdd: RDD[JSONObject]):RDD[JSONObject] = {

    val groupSimRddNewPre = groupSimRdd.map(x => {

      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")
      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
      val axle_number = JSONUtils.getJsonValue(x,"axle_number","2")
      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
      x.put("axle_number",axle_number)

      ((start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group),x)
    }).filter(obj => {
     val (start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group) = obj._1
      StringUtils.nonEmpty(start_dept) || StringUtils.nonEmpty(end_dept) || StringUtils.nonEmpty(start_dept) || StringUtils.nonEmpty(sim_group)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

//    groupSimRddNewPre.countByKey()
//      .toArray.sortBy(-_._2).take(10).foreach(obj=>{
//      println(obj._1+":"+obj._2)
//    })

    val groupSimRddNew =  groupSimRddNewPre.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).flatMap(x => {
      val list = x._2.toList
      var month_freq = 0

      //month_freq 求和
      val listNew = list.map(obj => {
        val daily_freq = JSONUtils.getJsonValueInt(obj,"daily_freq",0)
        month_freq += daily_freq
        obj
      }).map(obj => {
        obj.put("month_freq",month_freq)
        obj
      })
      listNew
    }).map(x => {
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")
      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
      val axle_number = JSONUtils.getJsonValue(x,"axle_number","2")
      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
      ((start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group),x)
    }).reduceByKey((obj1,obj2) => {
      mergeMonthFreq(obj1,obj2)
    }).map(_._2).filter(x => {
      StringUtils.nonEmpty(x.getString("rt_dist")) && (x.getDouble("rt_dist")> 1) && (x.getString("rt_coords").length > 8)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("groupSimRddNew数据量为：" + groupSimRddNew.count())
    groupSimRddNew.take(10).foreach(println(_))

    //合并数据
    val trajAllRddPre = groupSimRddNew.map(x =>{
      x.put("data_source","tracks")
      x
    }).union(schemeRouteRdd.map(x => {
      x.put("sim_group",0)
      x.put("month_freq",0)
      x
    })).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("trajAllRddPre数据量为：" + trajAllRddPre.count())
    trajAllRddPre.take(10).foreach(println(_))


    val trajAllRdd = trajAllRddPre.repartition(200).filter(x => {
      StringUtils.nonEmpty(x.getString("rt_dist")) && (x.getDouble("rt_dist")> 1) && (x.getString("rt_coords").length > 8)
    })

    val calTrajRddPre = trajAllRdd.repartition(200).map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axle_number = x.getString("axle_number")

      ((start_time,start_dept,end_dept,vehicle_type,axle_number),x)
    }).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("calTrajRddPre数据量为：" + calTrajRddPre.count())
    calTrajRddPre.take(10).foreach(println(_))


    val calTrajRdd = calTrajRddPre.flatMap(x => {
      val list = x._2.toList.sortBy(_.getString("data_source")).map(x => {
        x.put("order_source",x.getString("data_source"))
        x
      })
      if(list.length>0){
        for(i <- (0 until(list.length))){
          for(j <- (0 until(list.length))){
            if(i != j  && StringUtils.nonEmpty(list(i).getString("data_source"))
              && StringUtils.nonEmpty(list(j).getString("data_source"))
              && StringUtils.nonEmpty(list(i).getString("order_source"))
              && StringUtils.nonEmpty(list(j).getString("order_source"))
              && !list(i).getString("data_source").equals(list(j).getString("data_source"))
              && (!list(i).getString("order_source").contains(list(j).getString("data_source")) || list(j).getString("data_source").equals("tracks"))){
              val addDataSourcej = list(j).getString("data_source")
              val addDataSourcei = list(i).getString("data_source")

              //val similar = getSimilarInterface.getSimilar(list(i),list(j))
              val (minSimilar,maxSimilar) = getSimilarInterface.getSimilar2(list(i),list(j))
              print("*")
              //if(similar> 0.8){
              if(minSimilar>=0.75 && maxSimilar>=0.8){
                //更新 month_freq
                if(addDataSourcej.equals("tracks") && !addDataSourcei.equals("tracks")){
                  val month_freq_j = JSONUtils.getJsonValueInt(list(j),"month_freq",0)
                  val month_freq_i = JSONUtils.getJsonValueInt(list(i),"month_freq",0)
                  if(month_freq_j >= month_freq_i){
                    list(i).put("month_freq",month_freq_j)
                  }else{
                    list(j).put("month_freq",month_freq_i)
                  }
                }
                print("+")
                val order_source1 = list(i).getString("order_source")
                val order_source2 = list(j).getString("order_source")

                val concatNew1 =order_source1.concat("|").concat(addDataSourcej)
                val concatNew2 =order_source2.concat("|").concat(addDataSourcei)

                if((!StringUtils.nonEmpty(order_source1) || !order_source1.contains(addDataSourcej)) && !list(i).getString("data_source").equals("tracks")){
                  list(i).put("order_source",concatNew1)
                }

                if((!StringUtils.nonEmpty(order_source2) || !order_source2.contains(addDataSourcei)) && !list(j).getString("data_source").equals("tracks")){
                  list(j).put("order_source",concatNew2)
                }
              }
            }
          }
        }
      }
      list
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    calTrajRdd
  }




  def schemaRoute(spark:SparkSession,inc_day:String,markUnVerifyRdd:RDD[JSONObject]):RDD[JSONObject] = {

    val inc_day_next = DateTimeUtil.getLastMonthMonday(inc_day,"yyyyMMdd")


    val schemRouteRdd = getRouteInterface(markUnVerifyRdd).filter(x => {StringUtils.nonEmpty(x.getString("rt_coords"))}).map(x => {
      //20210622增加rt_time转换逻辑
      val rt_time= JSONUtils.getJsonValueInt(x,"rt_time",0) / 60
      x.put("rt_time",rt_time)
      x
    })

    schemRouteRdd
  }


  def getRouteInterface(repRdd:RDD[JSONObject]):RDD[JSONObject] ={
    logger.error("开始调用gd，jy，ct接口")
    val resRdd= repRdd.repartition(24).map(x => {
      //start_longitude x1,start_latitude y1,end_longitude x2,end_latitude y2,line_code,vehicle_type,height,axle_weight,axle_number,vehicle,vehicle_color,energy,width,length,emitStand,
      //concat(line_code_tb.inc_day,start_time,"00") plan_date start_dept end_dept
      // http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/rp/v2/api&axleNumber=2&fencedist=50&type=0&y1=22.912458&strategy=0&fixedroute=2&test=0&stype=0&planDate=202101171200&ak=ebf48ecaa1fd436fa3d40c4600aa051f&pathCount=3&cc=1&merge=4&etype=2&y2=23.216337&opt=gd3&vehicle=6&frequency=1&x2=113.108947&x1=113.95822&passport=100000&tolls=1

      val axle_number = x.getIntValue("axle_number")
      val x1 = x.getDouble("x1")
      val y1 = x.getDouble("y1")
      val x2 = x.getDouble("x2")
      val y2 = x.getDouble("y2")
      val vehicle_type = x.getIntValue("vehicle_type")
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val task_area_code = JSONUtils.getJsonValue(x,"task_area_code","")

      val plan_date = x.getString("plan_date")
      val line_code = x.getString("line_code")
      val height = JSONUtils.getJsonValue(x,"height","")
      val axle_weight = JSONUtils.getJsonValue(x,"axle_weight","")
      val vehicle = JSONUtils.getJsonValue(x,"vehicle","")
      val vehicle_color = JSONUtils.getJsonValue(x,"vehicle_color","")
      val energy = JSONUtils.getJsonValueInt(x,"energy",0)
      val width = JSONUtils.getJsonValueDouble(x,"width",0.0)
      val length = JSONUtils.getJsonValueDouble(x,"length",0.0)
      val passport = JSONUtils.getJsonValue(x,"passport","100000")
      val emitStand = JSONUtils.getJsonValue(x,"emitStand","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","0000")

      //传入plan_date  传入length
      val (gdJson,gdErrLog) = scheduleGdTraj(axle_number, x1, y1, x2, y2, vehicle_type, plan_date)
      val (jyJson,jyErrLog) = scheduleJYTraj(axle_number, x1, y1, x2, y2, vehicle_type, plan_date)
      val (ctJson,ctErrLog) = scheduleCTTraj(axle_number, x1, y1, x2, y2, vehicle_type, plan_date)
      println("*******")
      val buffer = new ArrayBuffer[JSONObject]()
      buffer.append(gdJson)

      for (i <- (0 until (jyJson.size())) if StringUtils.nonEmpty(jyJson.toString())) {
        buffer.append(jyJson.getJSONObject(i))
      }
      for (i <- (0 until (ctJson.size()))  if  StringUtils.nonEmpty(ctJson.toString())){
        buffer.append(ctJson.getJSONObject(i))
      }
      buffer.map(obj => {
        //          val trajJson = parseScheduleTrajJson(obj)
        val trajJson = new JSONObject()
        trajJson.fluentPutAll(obj)
        trajJson.put("plan_date",plan_date)
        trajJson.put("line_code",line_code)
        trajJson.put("start_dept",start_dept)
        trajJson.put("end_dept",end_dept)
        trajJson.put("vehicle_type",vehicle_type)
        trajJson.put("height",height)
        trajJson.put("axle_weight",axle_weight)
        trajJson.put("vehicle_color",vehicle_color)
        trajJson.put("energy",energy)
        trajJson.put("width",width)
        trajJson.put("length",length)
        trajJson.put("passport",passport)
        trajJson.put("emitStand",emitStand)
        trajJson.put("axle_number",axle_number)
        trajJson.put("start_time",start_time)
        trajJson.put("task_area_code",task_area_code)
        trajJson.put("gdErrLog",gdErrLog)
        trajJson.put("jyErrLog",jyErrLog)
        trajJson.put("ctErrLog",ctErrLog)
        trajJson
      })
    }).flatMap(x => x).filter(x => {
      val rt_src = x.getString("rt_src")
      !("rp-jy".equals(rt_src) || "rp-jy_geo".equals(rt_src) || "rp-jy-join".equals(rt_src))
    })
    resRdd

  }


  def calOntimeRate(middle0DF: DataFrame,middle1DF: DataFrame,inc_day:String) = {
    val columns1 = middle0DF.columns
    val middle0Rdd = middle0DF.rdd.map(x => {
      val json = new JSONObject()
      for(column <- columns1){
        json.put(column,x.getAs[String](column))
      }
      json
    })

    val columns2 = middle1DF.columns
    val middle1Rdd = middle1DF.rdd.map(x => {
      val json = new JSONObject()
      for(column <- columns2){
        json.put(column,x.getAs[String](column))
      }
      json
    })

    val ontime8090Rdd1 =middle0Rdd.repartition(240).map(x => {
      // line_code、start_time、start_dept、end_dept、actual_run_time、plan_run_time、inc_day、vehicle_type
      val jo  = new JSONObject()

      val line_code = x.getString("line_code")
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val actual_run_time = x.getInteger("actual_run_time")
      val plan_run_time = x.getInteger("plan_run_time")
      val inc_day = x.getString("inc_day")
      val vehicle_type = if(x.getIntValue("vehicle_type")==0) 6 else x.getIntValue("vehicle_type")
      jo.put("line_code",line_code)
      jo.put("start_time",start_time)
      jo.put("start_dept",start_dept)
      jo.put("end_dept",end_dept)
      jo.put("actual_run_time",actual_run_time)
      jo.put("plan_run_time",plan_run_time)
      jo.put("inc_day",inc_day)
      jo.put("vehicle_type",vehicle_type)

      //以start_time、start_dept、end_dept、vehicle_type分组
      ((start_time,start_dept,end_dept,vehicle_type),jo)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("ontime8090Rdd1的数据量为：" + ontime8090Rdd1.count())
    ontime8090Rdd1.take(2).foreach(println(_))

    val ontime8090Rdd2 = ontime8090Rdd1.groupByKey().repartition(240).map(x => {
      val list = x._2.toList

      //判断组内时效中位数 mid_time
      val midList = list.toStream.sortBy(obj => {JSONUtils.getJsonValueInt(obj,"actual_run_time",0)})
      val mid_time_index = Math.floor(list.size / 2).toInt

      val mid_time = JSONUtils.getJsonValueInt(midList(mid_time_index),"actual_run_time",0)


      val list2 = list.map(obj => {
        val plan_run_time = JSONUtils.getJsonValueInt(obj,"plan_run_time",0)
        val actual_run_time = JSONUtils.getJsonValueInt(obj,"actual_run_time",0)
        //过滤异常值
        if(actual_run_time > 0.5 * mid_time && actual_run_time < 1.5 * mid_time){
          obj.put("errTag","0")
        }else{
          obj.put("errTag","1")
        }

        //计算历史准点率
        if(plan_run_time >= actual_run_time-1){
          obj.put("ontimeTag","1")
        }else{
          obj.put("ontimeTag","0")
        }
        obj
      })


      val list3 = list2.filter(x => {
        !"1".equals(JSONUtils.getJsonValue(x,"errTag",""))
      })
      val historyOntimeCnt = list3.filter(x => {
        "1".equals(JSONUtils.getJsonValue(x,"ontimeTag",""))
      }).size

      val historyOntimeRatio = historyOntimeCnt.toDouble / list3.size

      //20210622计算逻辑更改，取最大值和最小值的差，等分为100份，再取80分位值 90分位值
      //val p8Index = Math.floor(list3.size * 0.8).toInt
      //val p9Index = Math.floor(list3.size * 0.94).toInt

      var time_p8 =0
      var time_p9 =0

      if(list3.size > 0 && list3 != null){
        val listNew = list3.sortBy(x => {JSONUtils.getJsonValueInt(x,"actual_run_time",0)})

        //20210622计算逻辑更改，取最大值和最小值的差，等分为100份，再取80分位值 90分位值
        val maxActualRunTime = list3.maxBy(x => {JSONUtils.getJsonValueInt(x,"actual_run_time",0)}).getIntValue("actual_run_time")
        val minActualRuntime = list3.minBy(x => {JSONUtils.getJsonValueInt(x,"actual_run_time",0)}).getIntValue("actual_run_time")
        val diffTime = maxActualRunTime - minActualRuntime

        val time_p8_pre = minActualRuntime + Math.floor((0.8 * diffTime)).toInt
        val time_p9_pre = minActualRuntime + Math.floor((0.94 * diffTime)).toInt
        //val time_p8_pre = JSONUtils.getJsonValueInt(listNew(p8Index),"actual_run_time",0)
        //val time_p9_pre = JSONUtils.getJsonValueInt(listNew(p9Index),"actual_run_time",0)

        val numberP8 = (time_p8_pre % 10)
        var numberP8New = numberP8 match {
          case numberP8 if(numberP8==0 ||numberP8==1 || numberP8==2) => 0
          case numberP8 if(3 to 7 contains numberP8) => 5
          case numberP8 if(numberP8==8 || numberP8==9 ) => 10
        }


        val numberP9 = (time_p9_pre % 10)
        var numberP9New = numberP9 match {
          case numberP8 if(numberP8==0 ||numberP8==1 || numberP8==2) => 0
          case numberP8 if(3 to 7 contains numberP8) => 5
          case numberP8 if(numberP8==8 || numberP8==9 ) => 10
        }

        //如果小于20分钟，只进，不退
        if(time_p8_pre < 20){
          val numberP8 = (time_p8_pre % 10)
          numberP8New = numberP8 match {
            case numberP8 if(numberP8==0) => 0
            case numberP8 if(1 to 5 contains numberP8) => 5
            case numberP8 if(6 to 10 contains numberP8) => 10
          }
        }

        //如果小于20分钟，只进，不退
        if(time_p8_pre < 20){
          val numberP9 = (time_p9_pre % 10)
          numberP9New = numberP9 match {
            case numberP9 if(numberP9==0) => 0
            case numberP9 if(1 to 5 contains numberP9) => 5
            case numberP9 if(6 to 10 contains numberP9) => 10
          }
        }

        time_p8 = time_p8_pre - numberP8 + numberP8New
        time_p9 = time_p9_pre - numberP9 + numberP9New

      }

      (x._1,list3,time_p8,time_p9,historyOntimeRatio)
      //过滤组内记录数小于3的记录 .filter(_._2.size > 3)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("ontime8090Rdd2的数据量为：" + ontime8090Rdd2.count())
    ontime8090Rdd2.take(2).foreach(println(_))

    val ontime8090Rdd3 = ontime8090Rdd2.repartition(240).map(x => {

      //计算80时效、90时效可达准点率

      val (key,list,time_p8,time_p9,his_ontime_rate) = x

      val list2 = list.map(obj => {
        val plan_run_time =  JSONUtils.getJsonValueInt(obj,"plan_run_time",0)
        val actual_run_time = JSONUtils.getJsonValueInt(obj,"actual_run_time",0)
        if(actual_run_time-1 <= time_p8){
          obj.put("ontime80",1)
        }else{
          obj.put("ontime80",0)
        }
        if(actual_run_time-1 <= time_p9){
          obj.put("ontime90",1)
        }else{
          obj.put("ontime90",0)
        }
        obj
      })
      val ontime80 = list2.filter(x => {"1".equals(JSONUtils.getJsonValue(x,"ontime80",""))}).size
      val ontime90 = list2.filter(x => {"1".equals(JSONUtils.getJsonValue(x,"ontime90",""))}).size

      var groupCnt = 1
      if( list2.size>3){
        groupCnt = list2.size
      }
      val ontime80Ratio = ontime80.toDouble / groupCnt
      val ontime90Ratio = ontime90.toDouble / groupCnt


      val (start_time,start_dept,end_dept,vehicle_type) = x._1



      val jo = new JSONObject()
      jo.put("start_time",start_time)
      jo.put("start_dept",start_dept)
      jo.put("end_dept",end_dept)
      jo.put("vehicle_type",vehicle_type)

      jo.put("time_p8",time_p8)
      jo.put("time_p9",time_p9)
      jo.put("his_ontime_rate",his_ontime_rate)

      if (ontime80Ratio > 1){
        jo.put("ontime80Ratio","")
      } else{
        jo.put("ontime80Ratio",ontime80Ratio)
      }

      if (ontime90Ratio > 1){
        jo.put("ontime90Ratio","")
      } else{
        jo.put("ontime90Ratio",ontime90Ratio)
      }
//      jo.put("ontime80Ratio",ontime80Ratio)
//      jo.put("ontime90Ratio",ontime90Ratio)
      jo.put("groupCnt",groupCnt)

      ((start_time,start_dept,end_dept,vehicle_type),jo)
    })
      //.filter(x => {JSONUtils.getJsonValueInt(x._2,"groupCnt",0) > 3})
    .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ontime8090Rdd3的数据量为：" + ontime8090Rdd3.count())

    val dept8090Rdd = middle1Rdd.filter(x => {
      StringUtils.nonEmpty(x.getString("rt_dist")) &&  !StringUtils.nonEmpty(x.getString("abnormal"))
    }).repartition(240).map(x => {
      //start_time、start_dept、end_dept、inc_day、vehicle_type、rt_dist
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val inc_day = x.getString("inc_day")
      val vehicle_type = if(x.getIntValue("vehicle_type")==0) 6 else x.getIntValue("vehicle_type")
      val rt_dist = x.getDouble("rt_dist")

      ((start_time,start_dept,end_dept,vehicle_type),x)
    }).groupByKey().map(x => {
      val list = x._2.toList.sortBy(obj => {JSONUtils.getJsonValueDouble(obj,"rt_dist",0) })
      val size = list.size
      val size80 = Math.floor(size * 0.8).toInt
      val size90 = Math.floor(size * 0.9).toInt
      val dist_p8 = JSONUtils.getJsonValueDouble(list(size80),"rt_dist",0)
      val dist_p9 = JSONUtils.getJsonValueDouble(list(size90),"rt_dist",0)

      (x._1,(dist_p8,dist_p9))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("dept8090Rdd的数据量为：" + dept8090Rdd.count())
    dept8090Rdd.take(2).foreach(println(_))


    val historyOntimeDept = ontime8090Rdd3.leftOuterJoin(dept8090Rdd).repartition(240).map(x => {
      val (start_time,start_dept,end_dept,vehicle_type) = x._1
      val leftBody = x._2._1

      val time_p8 = JSONUtils.getJsonValueInt(leftBody,"time_p8",0)
      val time_p9 = JSONUtils.getJsonValueInt(leftBody,"time_p9",0)
      val his_ontime_rate = JSONUtils.getJsonValueDouble(leftBody,"his_ontime_rate",0.0)
      val ontime80Ratio = JSONUtils.getJsonValue(leftBody,"ontime80Ratio","")
      val ontime90Ratio = JSONUtils.getJsonValue(leftBody,"ontime90Ratio","")
      val groupCnt = JSONUtils.getJsonValueInt(leftBody,"groupCnt",0)

      var (dist_p8,dist_p9) =(0.0,0.0)
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        val tuple89 = rightOption.get
        dist_p8 =tuple89._1
        dist_p9 =tuple89._2
        leftBody.put("dist_p8",dist_p8)
        leftBody.put("dist_p9",dist_p9)
      }

      leftBody

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    historyOntimeDept
  }

  def getGroupSim(spark: SparkSession, inc_day: String,begin_day:String,end_day:String):RDD[JSONObject] = {

    //待修改获取上个月
    val beginDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", begin_day, -7)
    val endDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", end_day, 2)

//    val simSql =
//    s"""
//       |select
//       |  *
//       |from
//       | dm_gis.eta_traj_simgroup_info
//       |where
//       |  inc_day >='20210720'
//       |and
//       |  inc_day <= '20210806'
//       | -- and
//       | --  line_code in ('020JG020W1505','757AC757WA1745','020LE020WM2010','020AF020W1050')
//       |-- and
//       |--   line_code in ('752WK752WH0659','752WK752WH0700','791WH760WH0800','028WH029WH0600','028WH371WH0600','991WH998R2359','551VJ757WL0359','551VJ757WL0359','551VJ028WH0359','551VJ028WH0359','579WH351WK0500','576WH022WH0301','576WH024WH0600','576WH531WK0301','576WH028WH0600','576WH029WH0300','558WH769WK0300','558WH769WK0300','571XF575WK0700','571XF575WK0200','571AAG7311WH0300','576WH595WH0300','573XF791WH0700','573XF791WH0700','571AAG022WH0300','574WG551WH0130','573XF024WH0700','551WH029WH0628','551WH028WH0558','551WH028WH0558','551WH311WK0600','573XF517WH2200','573XF517WH2200','573XF517WH2200','574WG577WH2100','574WG577WH2100','571R571BB1400','571CGG571W2030','575EAA575W1910','575EG575EA0940','575EC575EG1720','575EJ575W2001','571CGG571WJ2100','575W575JTD0620','351W353VA1700','359U359W1930','359W359U1400','359U359W1100','359W359U0640','359T359W2030','359T359W1740','359W359T1400','359T359W1140','359W359T0640','359TH359W2030','359TH359W1800','359W359TH1400','359TH359W1150','359W359TH0920','359AA359W1940','359W359AA1400','359AA359W1110','359W359AA0700','359W359BF0640','359BQ359W2020','359BQ359W1730','359W359BQ1400','359BQ359W1130','359W359BQ0700','359W359BA1400','359BA359W1145','359W359BA0700','359W359N1400','359N359W1140','359W359N0700','355VA355JCJ0630','355VA355JCJ1320','355JCJ355VA1930','053VA859AA0300','053VA859AG0300','053VA859SA0300','053VA859AC0300','053VA859AF0330','053VA859AH0500','053VA859SA0900','053VA859AA0900','053VA859AC0900','053VA859AF1000','053VA859TH1000','859AA053VA1235','859SA053VA1310','859TH053VA1400','859AG053VA1815','859AF053VA1840','859AA053VA1845','859SA053VA1900','859AH053VA1930','021WJ021DJF0550','021EB021WW2120','021EU021WW2110','021TBBF021WF2355','021TBBF021WF1330','021TH021WF1340','021TH021WF2150','021TH021WF2355','021TH021WF1445','021WF021TB0541','021WF021TB0550','021WF021TB0800','021WF021TB0450','021TB021WF2130','518FB518W1230','518BN518W1430','518W518BN1210','518CN518W1900','518CF518W2130','577L577WH2130','577WB577DA0600')
//       """.stripMargin

    val simSql =
      s"""
         |select
         |  *
         |from
         | dm_gis.eta_traj_simgroup_info
         |where
         |  inc_day >='${beginDay}'
         |and
         |  inc_day <= '${endDay}'
         |and
         |  typical_tag = '1'
       """.stripMargin


    val groupSimRddInput = spark.sql(simSql)
    val colList = groupSimRddInput.columns
    val groupSimRdd = groupSimRddInput.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- colList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    })
    groupSimRdd
  }



  def getJoinRdd(taskInfoRdd: RDD[(String, JSONObject)], carInfoRdd: RDD[(String, JSONObject)]):RDD[JSONObject] = {

    val joinRdd = taskInfoRdd.leftOuterJoin(carInfoRdd).map(x => {
      val left = x._2._1
      val rightOp = x._2._2

      if(rightOp.nonEmpty){
        left.fluentPutAll(rightOp.get)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    joinRdd
  }

  def getMaxIncDayRow(obj1: JSONObject, obj2: JSONObject): _root_.com.alibaba.fastjson.JSONObject = {
    val obj1IncDay = obj1.getString("inc_day")
    val obj2IncDay = obj2.getString("inc_day")

    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }

    if(StringUtils.nonEmpty(obj1IncDay) && StringUtils.nonEmpty(obj2IncDay) &&  obj1IncDay >= obj2IncDay){
      obj1
    }else{
      obj2
    }

  }



  def addBatch(spark: SparkSession, labelData: RDD[JSONObject], inc_day: String):RDD[JSONObject] = {

//    val inc_day_pre_month = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -30)
//
//    val schaPlanSql =
//      s"""
//         |select
//         |  latest_arrival_tm,dept_code,batch_code,inc_day
//         |from
//         |  (
//         |    select
//         |      row_number() over(
//         |        PARTITION by dept_code,
//         |        send_batch,
//         |        latest_arrival_tm
//         |        ORDER by
//         |          inc_day desc
//         |      ) as rn,
//         |      latest_arrival_tm,
//         |      dept_code,
//         |      send_batch as batch_code,
//         |      inc_day
//         |    from
//         |      (
//         |        select
//         |          *
//         |        from
//         |          dm_pass_rss.scha_tt_plan_point_pro t
//         |        where
//         |          inc_day='20210710'
//         |          and plan_run_dt >= '2021-06-20'
//         |          and plan_run_dt <= '2021-06-20'
//         |          and latest_arrival_tm is not null
//         |          and send_batch is not null
//         |          and send_batch != ''
//         |          and job_type in ('1', '2', '3')
//         |          and point_mean != 3
//         |          and point_type = 1
//         |      ) a
//         |      inner join (
//         |        SELECT
//         |          distinct(id) as id
//         |        from
//         |          dm_pass_rss.scha_tt_plan_main_pro
//         |        where
//         |          inc_day = '20210710'
//         |          and oper_type in (1, 2)
//         |      ) b on a.plan_main_id = b.id
//         |  ) a
//         |where
//         |  rn = 1
//       """.stripMargin
//
//    val airControlSql =
//      s"""
//         |select
//         |  latest_arrival_tm,dept_code,batch_code,inc_day
//         |from
//         |  (
//         |    select
//         |      row_number() over(
//         |        PARTITION by src_dept_code,
//         |        src_send_batch,
//         |        lastest_arrive_tm
//         |        ORDER by
//         |          inc_day desc
//         |      ) as rn,
//         |      lastest_arrive_tm as latest_arrival_tm,
//         |      src_dept_code as dept_code,
//         |      src_send_batch as batch_code,
//         |      inc_day
//         |    from
//         |      dm_pass_rss.aira_tm_air_transport_batch_pro t
//         |    where
//         |      send_date >= '2021-06-20'
//         |      and send_date <= '2021-06-20'
//         |      and inc_day ='20210710'
//         |      and practical_cvy_type = 1
//         |  ) a
//         |where
//         |  a.rn = 1
//         |limit 10
//       """.stripMargin
//
//
//    val receiveSql =
//      s"""
//         |select
//         |  latest_arrival_tm,dept_code,batch_code,inc_day
//         |from
//         |  (
//         |    select
//         |      row_number() over(
//         |        PARTITION by batch_code,
//         |        workday,
//         |        last_indepot_tm
//         |        ORDER by
//         |          inc_day desc
//         |      ) as rn,
//         |      substring(last_indepot_tm, 2, 5) latest_arrival_tm,
//         |      operate_zone_code  as dept_code,
//         |      batch_code,
//         |      inc_day
//         |    from
//         |      dm_pass_rss.sbsa_tm_pickup_depot_pro
//         |    where
//         |      inc_day = '20210710'
//         |      and data_state = 1
//         |      and delete_flg = 0
//         |      and un_effective_tm >= '2021-06-20'
//         |  ) a
//         |where
//         |  rn= 1
//         |limit 10
//       """.stripMargin
//
//    val dispatchSql =
//      s"""
//         |select
//         |  latest_arrival_tm,dept_code,batch_code,inc_day
//         |from
//         |  (
//         |    select
//         |      row_number() over(
//         |        PARTITION by batch_code,
//         |        workday,
//         |        last_arrive_tm
//         |        ORDER by
//         |          inc_day desc
//         |      ) as rn,
//         |      substring(last_arrive_tm, 2, 5) latest_arrival_tm,
//         |      operate_zone_code  as dept_code,
//         |      batch_code,
//         |      inc_day
//         |    from
//         |      dm_pass_rss.sbsa_tm_deliver_depot_pro
//         |    where
//         |      inc_day = '20210710'
//         |      and data_state = 1
//         |      and delete_flg = 0
//         |      and un_effective_tm >= '2021-06-20'
//         |  ) a
//         |where
//         |  rn= 1
//         |limit 10
//       """.stripMargin
//
//        val receiveRdd = spark.sql(receiveSql)
//        val airControlRdd = spark.sql(airControlSql)
//        val dispatchRdd = spark.sql(dispatchSql)
//        val schaPlanRdd = spark.sql(schaPlanSql)
//
//        val batchAllDF = receiveRdd.union(airControlRdd).union(dispatchRdd).union(schaPlanRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
//        logger.error("batchAllDF数据量为：" + batchAllDF.count())
//        batchAllDF.take(2).foreach(println(_))
//    batchAllDF.repartition(1).write.mode(SaveMode.Overwrite).option("header", "true").csv("/user/01401062/upload/gis/data/eta/batchAllData3.csv")

//    val batchAllDF = spark.read.format("csv").option("header", "true").load("/user/01401062/upload/gis/data/eta/batchAllData3.csv")
//
//    val batchAllColums = batchAllDF.columns
//
//    val batchAllRdd = batchAllDF.rdd.repartition(200).map(x => {
//      val jo = new JSONObject()
//      for (columns <- batchAllColums) {
//        jo.put(columns,x.getAs[String](columns))
//      }
//      jo
//    }).map(x => {
//      val dept_code = x.getString("dept_code")
//      val latest_arrival_tm = x.getString("latest_arrival_tm")
//      val batch_code = x.getString("batch_code")
//      ((dept_code,latest_arrival_tm,batch_code),x)
//    }).filter(x => {
//      StringUtils.nonEmpty(x._1._2)
//    })
//      //# 去重 根据dept_code, latest_arrival_tm, batch_code,去重,取inc_day最大的一条
//      .reduceByKey((obj1,obj2) => getMaxIncDayRow(obj1,obj2))
//      // # 分类 0代表收仓班次，1代表派仓班次，2代表中转班次
//      .map(x => {
//      val (dept_code,latest_arrival_tm,batch_code) = x._1
//
//      val batch_type = batch_code match {
//        case batch_code if StringUtils.isEmpty(batch_code) => "2"
//        case batch_code if batch_code.endsWith("P") => "0"
//        case batch_code if batch_code.endsWith("D") => "1"
//        case batch_code  => "2"
//      }
//
//      x._2.put("batch_type",batch_type)
//      ((dept_code,batch_type),x._2)
//    })
//
//    logger.error("batchAllRdd的数据量为" + batchAllRdd.count())
//
//    // # 排序 根据dept_code, batch_type, latest_arrival_tm增序排序 获取每个班次的上一班次最晚到车时间last_batch_last_tm 上一班次的班次编码last_batch_code
//    val batchAllRdd2 = batchAllRdd.groupByKey().flatMap(x => {
//
//      val (dept_code,batch_type) =x._1
//      val list = x._2.toList.sortBy(x => JSONUtils.getJsonValue(x,"latest_arrival_tm","00:00"))
//
//      if(list.size > 1) {
//        for (i <- Range(0, list.size)) {
//          if (i == 0) {
//            list(0).put("last_batch_last_tm", "")
//            list(0).put("last_batch_code", "")
//          } else {
//            val last_batch_last_tm = list(i - 1).getString("latest_arrival_tm")
//            val last_batch_code = list(i - 1).getString("batch_code")
//
//            list(i).put("last_batch_last_tm", last_batch_last_tm)
//            list(i).put("last_batch_code", last_batch_code)
//          }
//        }
//      }
//      list
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    logger.error("batchAllRdd2的数据量为：" + batchAllRdd2.count())
//
//    import spark.implicits._
//
//    val batchAllTb =batchAllRdd2.map(x => {
//      val dept_code = x.getString("dept_code")
//      val latest_arrival_tm = x.getString("latest_arrival_tm")
//      val batch_code = x.getString("batch_code")
//      val batch_type = x.getString("batch_type")
//      val last_batch_last_tm = x.getString("last_batch_last_tm")
//      val last_batch_code = x.getString("last_batch_code")
//
//      (batch_code,dept_code,latest_arrival_tm,batch_type,last_batch_last_tm,last_batch_code)
//    }).filter(x => {
//      val (batch_code,dept_code,latest_arrival_tm,batch_type,last_batch_last_tm,last_batch_code) = x
//      StringUtils.nonEmpty(last_batch_last_tm) && StringUtils.nonEmpty(last_batch_code) &&
//        StringUtils.nonEmpty(latest_arrival_tm) && latest_arrival_tm.length == 19 && last_batch_last_tm.length == 19
//    }).collect()
//
//    logger.error("batchAllTb的数据量为：" + batchAllTb.size)
//    batchAllTb.take(2).foreach(println(_))
//
//
//    val batchBroadcast = spark.sparkContext.broadcast(batchAllTb)
//
//    val joinBatchRdd = getJoinBatch(labelData,batchBroadcast).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    logger.error("joinBatchRdd的数据量为：" + joinBatchRdd.count())
//    joinBatchRdd.take(2).foreach(println(_))
//    val updateFlagRdd = updateFlag(joinBatchRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val updateFlagRdd = updateFlag(labelData).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("updateFlagRdd的数据量为：" + updateFlagRdd.count())
    updateFlagRdd.take(2).foreach(println(_))

    updateFlagRdd
  }

  def updateFlag(joinBatchRdd: RDD[JSONObject]) = {

      // val updateRdd = joinBatchRdd.map(x => {
      //      val transoport_level = JSONUtils.getJsonValueInt(x, "transoport_level", 0)
      //      val ft_time = JSONUtils.getJsonValueDouble(x, "ft_time", 0)
      //      val batch_st = JSONUtils.getJsonValue(x, "batch_st", "")
      //      val flag = JSONUtils.getJsonValue(x,"flag","")
      //      val line_time =JSONUtils.getJsonValueInt(x,"line_time",0)
      //      val p9_ontime_rate =JSONUtils.getJsonValueDouble(x,"ontime90Ratio",0.0)
      //      //val p9_ontime_rate = JSONUtils.getJsonValueDouble(x,"p9_ontime_rate",0.0)
      //      val his_ontime_rate = JSONUtils.getJsonValueDouble(x,"his_ontime_rate",0.0)
      //
      //      val flagBuilder = new mutable.StringBuilder(flag)
      //      var threshold = 20
      //      if(transoport_level == 3) threshold =10
      //
      //      flagBuilder.append(flag)
      //      if(line_time - ft_time >= threshold && (line_time - ft_time)/line_time<0.2 && p9_ontime_rate >= 0.94 && p9_ontime_rate<=his_ontime_rate){
      //        if(StringUtils.nonEmpty(flag)){
      //          flagBuilder.append(";").append("压缩时长")
      //        }else{
      //          flagBuilder.append("压缩时长")
      //        }
      //      }else if ( StringUtils.nonEmpty(batch_st) && (batch_st.equals("跨小段") || batch_st.equals("跨大段"))
      //        && (line_time - ft_time)/line_time<0.2
      //        && p9_ontime_rate >= 0.94 && p9_ontime_rate<=his_ontime_rate ){
      //        if(StringUtils.nonEmpty(flag)){
      //          flagBuilder.append(";").append("压缩时长")
      //        }else{
      //          flagBuilder.append("压缩时长")
      //        }
      //      }else if(ft_time - line_time >= threshold && p9_ontime_rate <= 0.94 && p9_ontime_rate>=his_ontime_rate &&
      //        ((StringUtils.nonEmpty(batch_st) && !batch_st.equals("延长班次")) || StringUtils.isEmpty(batch_st))){
      //        if(StringUtils.nonEmpty(flag)){
      //          flagBuilder.append(";").append("延长时长")
      //        }else{
      //          flagBuilder.append("延长时长")
      //        }
      //      }
      //
      //      if(ft_time==0){
      //        x.put("batch_st","")
      //        x.put("ft_arrive_time","")
      //        x.put("ft_arrive_time_last","")
      //      }
      //
      //      x.put("flag",flagBuilder.toString())
      //      x
      //    })
      //    updateRdd

    /**
      * 区分分拨区网点
      */
    val distributionList = List("111Y","222Y","300Y","333Y","555Y","666Y","700Y","777Y","888Y","999Y")

    val distributionRdd = joinBatchRdd.filter(x => {
      val task_area_code = x.getString("task_area_code")
      StringUtils.nonEmpty(task_area_code) && distributionList.contains(task_area_code)
    }).map(x => {
      val transoport_level = JSONUtils.getJsonValueInt(x, "transoport_level", 0)

      val ft_time = JSONUtils.getJsonValueDouble(x, "ft_time", 0)
      val batch_st = JSONUtils.getJsonValue(x, "batch_st", "")
      val flag = JSONUtils.getJsonValue(x, "flag", "")
      val line_time = JSONUtils.getJsonValueInt(x, "line_time", 0)
      val p9_ontime_rate = JSONUtils.getJsonValueDouble(x, "ontime90Ratio", 0.0)
      //val p9_ontime_rate = JSONUtils.getJsonValueDouble(x,"p9_ontime_rate",0.0)
      val his_ontime_rate = JSONUtils.getJsonValueDouble(x, "his_ontime_rate", 0.0)

      val flagBuilder = new mutable.StringBuilder(flag)
      var threshold = 20
      if (transoport_level == 3) threshold = 10

      flagBuilder.append(flag)
      if (line_time - ft_time >= threshold && p9_ontime_rate >= 0.94 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (StringUtils.nonEmpty(batch_st) && (batch_st.equals("跨小段") || batch_st.equals("跨大段"))
        && p9_ontime_rate >= 0.94 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (ft_time - line_time >= threshold && p9_ontime_rate <= 0.94 && p9_ontime_rate >= his_ontime_rate &&
        ((StringUtils.nonEmpty(batch_st) && !batch_st.equals("延长班次")) || StringUtils.isEmpty(batch_st))) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("延长时长")
        } else {
          flagBuilder.append("延长时长")
        }
      }
      x.put("flag", flagBuilder.toString())

      if (ft_time == 0) {
        x.put("batch_st", "")
        x.put("ft_arrive_time", "")
        x.put("ft_arrive_time_last", "")
      }

      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("distributionRdd的数据量为：" + distributionRdd.count())

    val notDistributionRdd = joinBatchRdd.filter(x => {
      val task_area_code = x.getString("task_area_code")
      StringUtils.isEmpty(task_area_code) ||  !(distributionList.contains(task_area_code))
    }).map(x => {
      val transoport_level = JSONUtils.getJsonValueInt(x, "transoport_level", 0)
      val ft_time = JSONUtils.getJsonValueDouble(x, "ft_time", 0)
      val batch_st = JSONUtils.getJsonValue(x, "batch_st", "")
      val flag = JSONUtils.getJsonValue(x, "flag", "")
      val line_time = JSONUtils.getJsonValueInt(x, "line_time", 0)
      val p9_ontime_rate = JSONUtils.getJsonValueDouble(x, "ontime90Ratio", 0.0)
      val his_ontime_rate = JSONUtils.getJsonValueDouble(x, "his_ontime_rate", 0.0)

      val flagBuilder = new mutable.StringBuilder(flag)
      var threshold = 20
      if (transoport_level == 3) threshold = 10

      flagBuilder.append(flag)
      if (line_time - ft_time >= threshold && (line_time - ft_time) / line_time < 0.2 && p9_ontime_rate >= 0.94 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (StringUtils.nonEmpty(batch_st) && (batch_st.equals("跨小段") || batch_st.equals("跨大段"))
        && (line_time - ft_time) / line_time < 0.2
        && p9_ontime_rate >= 0.94 && p9_ontime_rate <= his_ontime_rate) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("压缩时长")
        } else {
          flagBuilder.append("压缩时长")
        }
      } else if (ft_time - line_time >= threshold && p9_ontime_rate <= 0.94 && p9_ontime_rate >= his_ontime_rate &&
        ((StringUtils.nonEmpty(batch_st) && !batch_st.equals("延长班次")) || StringUtils.isEmpty(batch_st))) {
        if (StringUtils.nonEmpty(flag)) {
          flagBuilder.append(";").append("延长时长")
        } else {
          flagBuilder.append("延长时长")
        }
      }
      x.put("flag", flagBuilder.toString())

      if (ft_time == 0) {
        x.put("batch_st", "")
        x.put("ft_arrive_time", "")
        x.put("ft_arrive_time_last", "")
      }

      x
    })
    logger.error("notDistributionRdd的数据量为：" + notDistributionRdd.count())


    val updateRdd = distributionRdd.union(notDistributionRdd)
    updateRdd

  }




  def getJoinBatch(labelData: RDD[JSONObject], batchBroadcast: Broadcast[Array[(String, String, String, String, String, String)]]) = {

    val joinBatchRdd = labelData.map(x => {

      val plan_arrive_batch = JSONUtils.getJsonValue(x, "plan_arrive_batch", "")
      val ft_time = JSONUtils.getJsonValueInt(x, "ft_time", 0)
      val plan_depart_tm = JSONUtils.getJsonValue(x, "plan_depart_tm", "")
      val plan_arrive_tm = x.getString("plan_arrive_tm")
      val plan_arrive_tm_stamp = try{DateTimeUtil.timeToLong(plan_arrive_tm, "yyyy-MM-dd HH:mm:ss")}catch {case e:Exception => DateTimeUtil.timeToLong("2000-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss")}
      val transoport_level = JSONUtils.getJsonValue(x, "transoport_level", "")
      val end_dept = JSONUtils.getJsonValue(x, "end_dept", "")
      val line_code = JSONUtils.getJsonValue(x, "line_code", "")
      val job_type = JSONUtils.getJsonValue(x, "job_type", "-")


      /**
        * 班次类型batch_type
        */
      val batch_type = plan_arrive_batch match {
        case plan_arrive_batch if plan_arrive_batch.isEmpty => "2"
        case plan_arrive_batch if plan_arrive_batch.endsWith("P") => "0"
        case plan_arrive_batch if plan_arrive_batch.endsWith("D") => "1"
        case plan_arrive_batch => "2"
      }
      x.put("batch_type", batch_type)
      /**
        * 丰图到达时间 ft_arrive_time
        * plan_depart_tm（计划发车时间，来源为sql取数） +  ft_time
        */

      val ft_arrive_time = DateTimeUtil.getMinBeforeAfter(plan_depart_tm, "yyyy-MM-dd HH:mm:ss", ft_time)
      val ft_arrive_time_stamp = DateTimeUtil.timeToLong(ft_arrive_time, "yyyy-MM-dd HH:mm:ss")

      x.put("ft_arrive_time", ft_arrive_time)

      /**
        * plan_arrive_time_last,last_batch_last_tm,last_batch_code计算
        */

      val batchBroadcastRdd = batchBroadcast.value

      //var plan_arrive_time_last ="2000-01-01 00:00:00"
      var plan_arrive_time_last_stamp = 253392422400000L
      var last_batch_last_tm = ""
      var last_batch_code = ""
      var ft_arrive_time_last_stamp = 253392422400000L

      val end_dept_size = end_dept.size
      val isLastDeptPre = try {
        line_code.substring(0, line_code.size - 4).takeRight(end_dept_size)
      } catch {
        case e: Exception => "-"
      }
      val isLastDept = if (isLastDeptPre.equals(end_dept)) "1" else "0"

      //(batch_code,dept_code,latest_arrival_tm,batch_type,last_batch_last_tm,last_batch_code)
      if (StringUtils.isEmpty(plan_arrive_batch)) {
        batchBroadcastRdd.map(obj => {
          val batch_code = obj._1
          val dept_code = obj._2
          val latest_arrival_tm_new = obj._3
          val latest_arrival_tm_stamp_new = try{DateTimeUtil.timeToLong(latest_arrival_tm_new, "yyyy-MM-dd HH:mm:ss")} catch {case e:Exception => DateTimeUtil.timeToLong("2000-01-01 00:00:00", "yyyy-MM-dd HH:mm:ss")}

          val batch_type_new = obj._4
          val last_batch_last_tm_new = obj._5
          val last_batch_code_new = obj._6
          if (dept_code.equals(end_dept)) {
            if (plan_arrive_tm_stamp <= latest_arrival_tm_stamp_new) {
              if (plan_arrive_time_last_stamp >= latest_arrival_tm_stamp_new) {
                plan_arrive_time_last_stamp = latest_arrival_tm_stamp_new
                last_batch_last_tm = last_batch_last_tm_new
                last_batch_code = last_batch_code_new
              }
            }
          }
          if (dept_code.equals(end_dept) && StringUtils.nonEmpty(batch_type_new) && StringUtils.nonEmpty(batch_type) && batch_type_new.equals(batch_type)) {
            if (ft_arrive_time_stamp < latest_arrival_tm_stamp_new) {
              if (latest_arrival_tm_stamp_new < ft_arrive_time_last_stamp) {
                ft_arrive_time_last_stamp = latest_arrival_tm_stamp_new
              }
            }
          }
        })
      } else if (StringUtils.nonEmpty(transoport_level) && StringUtils.nonEmpty(isLastDept)
        && "3".equals(transoport_level) && "0".equals(isLastDept) && !"2".equals(job_type)) {
        batchBroadcastRdd.map(obj => {
          val batch_code = obj._1
          val dept_code = obj._2
          val latest_arrival_tm_new = obj._3
          val latest_arrival_tm_stamp_new = DateTimeUtil.timeToLong(latest_arrival_tm_new, "yyyy-MM-dd HH:mm:ss")

          val batch_type_new = obj._4
          val last_batch_last_tm_new = obj._5
          val last_batch_code_new = obj._6
          if (plan_arrive_tm.equals(latest_arrival_tm_new)) {
            plan_arrive_time_last_stamp = latest_arrival_tm_stamp_new
            last_batch_last_tm = last_batch_last_tm_new
            last_batch_code = last_batch_code_new
          }
          if (dept_code.equals(end_dept) && StringUtils.nonEmpty(batch_type_new) && StringUtils.nonEmpty(batch_type) && batch_type_new.equals(batch_type)) {
            if (ft_arrive_time_stamp < latest_arrival_tm_stamp_new) {
              if (latest_arrival_tm_stamp_new < ft_arrive_time_last_stamp) {
                ft_arrive_time_last_stamp = latest_arrival_tm_stamp_new
              }
            }
          }
        })
      } else if ("3".equals(transoport_level) && StringUtils.nonEmpty(isLastDept)
        && "0".equals(isLastDept) && "2".equals(job_type)) {
        plan_arrive_time_last_stamp = 0L
        last_batch_last_tm = ""
        last_batch_code = ""
        ft_arrive_time_last_stamp = 0L
      } else {
        batchBroadcastRdd.map(obj => {
          val batch_code = obj._1
          val dept_code = obj._2
          val latest_arrival_tm_new = obj._3
          val latest_arrival_tm_stamp_new = DateTimeUtil.timeToLong(latest_arrival_tm_new, "yyyy-MM-dd HH:mm:ss")

          val batch_type_new = obj._4
          val last_batch_last_tm_new = obj._5
          val last_batch_code_new = obj._6
          if (StringUtils.nonEmpty(plan_arrive_batch) && StringUtils.nonEmpty(batch_code) && batch_code.equals(plan_arrive_batch)) {
            if (plan_arrive_tm_stamp <= latest_arrival_tm_stamp_new) {
              if (plan_arrive_time_last_stamp > latest_arrival_tm_stamp_new) {
                plan_arrive_time_last_stamp = latest_arrival_tm_stamp_new
                last_batch_last_tm = last_batch_last_tm_new
                last_batch_code = last_batch_code_new
              }
            }
          }
          if (dept_code.equals(end_dept) && StringUtils.nonEmpty(batch_type_new) && StringUtils.nonEmpty(batch_type) && batch_type_new.equals(batch_type)) {
            if (ft_arrive_time_stamp < latest_arrival_tm_stamp_new) {
              if (latest_arrival_tm_stamp_new < ft_arrive_time_last_stamp) {
                ft_arrive_time_last_stamp = latest_arrival_tm_stamp_new
              }
            }
          }
        })
      }


      val plan_arrive_time_last = if (plan_arrive_time_last_stamp == 0L) {
        ""
      } else {
        try {
          DateTimeUtil.longToTime(plan_arrive_time_last_stamp, "yyyy-MM-dd HH:mm:ss")
        } catch {
          case e: Exception => ""
        }
      }
      val ft_arrive_time_last =
        if (plan_arrive_time_last_stamp == 0L) {
          ""
        } else {
          try {DateTimeUtil.longToTime(ft_arrive_time_last_stamp, "yyyy-MM-dd HH:mm:ss")} catch {case e: Exception => ""}
        }

      val last_batch_last_tm_stamp = try {DateTimeUtil.timeToLong(last_batch_last_tm, "yyyy-MM-dd HH:mm:ss")} catch {case e: Exception => 0L}
      var batch_st =""

      if (ft_arrive_time_stamp <= last_batch_last_tm_stamp && plan_arrive_batch.equals(last_batch_code)
        && ft_arrive_time_stamp < plan_arrive_time_last_stamp) {
        batch_st = "跨小段"
      } else if (ft_arrive_time_stamp <= last_batch_last_tm_stamp && !plan_arrive_batch.equals(last_batch_code)
        && ft_arrive_time_stamp < plan_arrive_time_last_stamp) {
        batch_st = "跨大段"
      } else if (ft_arrive_time_stamp > plan_arrive_time_last_stamp && ft_arrive_time_stamp > plan_arrive_tm_stamp) {
        batch_st = "延长班次"
      }

      x.put("plan_arrive_time_last", plan_arrive_time_last)
      x.put("last_batch_last_tm", last_batch_last_tm)
      x.put("last_batch_code", last_batch_code)
      x.put("ft_arrive_time_last", ft_arrive_time_last)
      x.put("batch_st",batch_st)

      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("joinBatchRdd的数据量为：" + joinBatchRdd.count())
    joinBatchRdd.take(2).foreach(println(_))

    joinBatchRdd

  }



  def mergeMonthFreq(obj1: JSONObject, obj2: JSONObject):JSONObject = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val inc_day_1 = JSONUtils.getJsonValueInt(obj1,"inc_day",0)
    val inc_day_2 = JSONUtils.getJsonValueInt(obj2,"inc_day",0)

    //取inc_day日期最大的
    if(inc_day_1 < inc_day_2){
      return obj2
    }else{
      return obj1
    }
  }

  class SecondarySortByKey(val first:Int, val second:Int) extends Ordered[SecondarySortByKey] with Serializable{
    override def compare(that: SecondarySortByKey): Int = {
      if(this.first-that.first != 0){
        -(this.first - that.first)
      } else {
        -(this.second - that.second)
      }
    }
  }
}
