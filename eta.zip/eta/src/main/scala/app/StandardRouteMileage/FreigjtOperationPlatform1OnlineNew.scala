package app.StandardRouteMileage

import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger

import Utils._
import com.alibaba.fastjson._
import com.sf.gis.java.eta.constant.StandardRouteMileage.DistanceTool
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

object FreigjtOperationPlatform1OnlineNew {

  @transient lazy val logger: Logger = Logger.getLogger(FreigjtOperationPlatform1OnlineNew.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {

    val inc_day =args(0)
    logger.error("当前日期为：" + inc_day)


    start(inc_day)

    logger.error("统计结束")

  }

  case class tracksInfo(
                         task_id:String,
                         start_dept:String,
                         end_dept:String,
                         start_type:String,
                         end_type:String,
                         start_tm:String,
                         end_tm:String,
                         actual_run_time:String,
                         plan_run_time:String,
                         rt_time:String,
                         sort_num:String,
                         start_longitude:String,
                         end_longitude:String,
                         start_latitude:String,
                         end_latitude:String,
                         start_address:String,
                         end_address:String,
                         line_code:String,
                         line_id:String,
                         task_area_code:String,
                         vehicle_serial:String,
                         conveyance_type:String,
                         transoport_level:String,
                         id:String,
                         inc_day_carInfo:String,
                         is_stop:String,
                         ground_task_id:String,
                         vehicle_type:String,
                         axIs_number:String,
                         rt_dist:String,
                         rt_highway :String,
                         tolls:String,
                         rt_tollsDistance:String,
                         rt_coords:String,
                         compDistRatio:String,
                         compTimeRatio:String,
                         start_distance:String,
                         end_distance:String,
                         abnormal:String,
                         start_time:String,
                         sim_group:String,
                         typical_tag:String,
                         data_source:String,
                         daily_freq:String,
                         group_day_min:String,
                         group_day_max:String,
                         log_dist:String,
                         driver_name:String,
                         trans_car:String,
                         carrier_name:String,
                         cvy_name:String,
                         line_distance:String,
                         match_order_st:String
                       )


  class SecondarySortByKey(val first:Int, val second:Int) extends Ordered[SecondarySortByKey] with Serializable{
    override def compare(that: SecondarySortByKey): Int = {
      if(this.first-that.first != 0){
        -(this.first - that.first)
      } else {
        this.second - that.second
      }
    }
  }

  case class monthTable(start_dept:String,end_dept:String,start_time:String,vehicle_type:String,axle_number:String,sim_group:String,month_freq:String,inc_day:String)

  case class halfYearTable(start_dept:String,end_dept:String,start_time:String,vehicle_type:String,axle_number:String,sim_group:String,half_year_freq:String,inc_day:String)


  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    startSta(spark,inc_day)
  }

  /** @note   调用历史轨迹接口*/
  private def scheduleHistoryTrajInterface(usrNum:String ,startDate: String, endDate: String): JSONArray = {

    //val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/lsssearch/api/poshisPeriod&ak=cfe3bf126cf649ff8de8be49e9bded27&appCode=8e296a067a37563370ded05f5a3bf3ec&usrNum=%s&startDate=%s&endDate=%s"

    val historyTrajUrl ="http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrate"

    var array= new JSONArray()

    val json = new JSONObject()
    json.put("un",usrNum)
    json.put("beginDateTime",startDate)
    json.put("endDateTime",endDate)
    json.put("type","0")
    json.put("ak","ebf48ecaa1fd436fa3d40c4600aa051f")
    json.put("rectify","false")
    val response = try{Utils.post(historyTrajUrl,json,"utf-8")}catch {case e:Exception => e.printStackTrace().toString}
    var falg = 0
    if (response.size > 8 && response.contains("un") && response.contains("track")) {
      if(StringUtils.nonEmpty(response)) {
        if (JSONUtils.isValidJSON(response)) {
          //println("正确的url为"+ url)
          val response2 = JSON.parseObject(response)
          val result = response2.getJSONObject("result")
          val data = result.getJSONObject("data")
          val track = data.getJSONArray("track")
          array = track
        }
      }
      falg = 1
    }
    array
  }

  //测试
  //val fixUrl = "http://10.202.116.143:38081/drectify"
  //生产
  val fixUrl = "http://tlocrectify-gis-lss-tloc.dcn-gis1.k8s.sf-express.com/lssrectify/api/rectify"



  case class Ontime8090(start_time:String,start_dept:String,end_dept:String,vehicle_type:Int,time_p8:Int
                        ,time_p9:Int,his_ontime_rate:Double,ontime80Ratio:Double,ontime90Ratio:Double,groupCnt:Int)

  case class HistoryOntimeDept(
                                Start_time: String,
                                start_dept: String,
                                end_dept: String,
                                vehicle_type: Int,
                                time_p8: Int,
                                time_p9: Int,
                                his_ontime_rate: String,
                                p8_ontime_rate: String,
                                p9_ontime_rate: String,
                                group_count: Int,
                                dist_p8: Double,
                                dist_p9: Double,
                                inc_day: String)

  case class HisTrajInfo(task_id: String,start_dept: String,end_dept: String,his_coords: String,inc_day: String)




  def startSta(spark: SparkSession, inc_day: String): Unit = {
    logger.error("获取日志" + inc_day)
    val getinputRdd = getTaskAndCarInfo(spark,inc_day)
    getinputRdd.take(2).foreach(println(_))

    logger.error("获取轨迹返回")
    val getGjFix = getGjFixMethod(getinputRdd)
    logger.error("轨迹返回数量为：" + getGjFix.count())
    getGjFix.take(2).foreach(println(_))

    saveGjTable(spark,getGjFix,inc_day)

    val getGjFixNew = getGjFixTable(spark,inc_day)
    logger.error("读取轨迹表的数据量为：" + getGjFixNew.count())
    getGjFixNew.take(3).foreach(println(_))
    // 添加异常标识
    logger.error("添加异常标识")
    val addAbnormalRDD = addAbnormal(getGjFixNew)
    logger.error("异常标记数据量为：" + addAbnormalRDD.count())
    addAbnormalRDD.take(3).foreach(println(_))

    //分组计算相似度
    logger.error("开始计算相似度")
    val groupSimRdd = groupSim(spark,addAbnormalRDD,inc_day)
    val groupSimAddFreqRdd = addDailyFreq(groupSimRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)

    saveMiddle1Table(spark,groupSimAddFreqRdd,inc_day)

    val monthHalfYearFreqRdd = getMonthHalfYearFreq(spark,inc_day)


  }


  def dropTable45Day (spark: SparkSession,tableName:String, inc_day: String): Unit ={

    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-45)

    val sourceSql =
      s"""
         |select
         |  task_id,start_dept,end_dept,start_type,end_type,start_tm,end_tm,actual_run_time,plan_run_time,
         |  rt_time,sort_num,start_longitude,end_longitude,start_latitude,end_latitude,start_address,end_address,
         |  line_code,line_id,task_area_code,vehicle_serial,conveyance_type,transoport_level,id,inc_day_carinfo,is_stop,
         |  ground_task_id,vehicle_type,axis_number,rt_dist,rt_highway,tolls,rt_tollsdistance,'' rt_coords,
         |  compdistratio,comptimeratio,start_distance,end_distance,abnormal,start_time,sim_group,typical_tag,
         |  data_source,daily_freq,group_day_min,group_day_max,log_dist,driver_name,trans_car,carrier_name,cvy_name,
         |  line_distance,match_order_st,inc_day
         |from
         |  ${tableName}
         |where
         |  inc_day='${dropDate}'
       """.stripMargin

    val df = spark.sql(sourceSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    df.repartition(100).write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_traj_simgroup_info")


  }



  def saveMiddle1Table(spark: SparkSession, groupSimRdd: RDD[JSONObject], inc_day: String): Unit = {

    logger.error("当前inc_day为：" + inc_day)
    /**
      * 删除中间表1，60天前数据
      */
    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-60)
    val dropSql =
      s"""
         |alter table  dm_gis.eta_traj_simgroup_info drop if exists partition (inc_day='${dropDate}')
       """.stripMargin
    logger.error("删除中间表1的45天前数据" + dropSql)
    spark.sql(dropSql)

    val saveTableName = "dm_gis.eta_traj_simgroup_info"

    logger.error("清除45天前的rt_coords字段")
    dropTable45Day(spark,saveTableName,inc_day)

    import spark.implicits._
    val gr1 = groupSimRdd.map(x => {

      val axIs_number = x.getString("axIs_number")
      val end_longitude = x.getString("end_longitude")
      val ground_task_id = x.getString("ground_task_id")
      val num = x.getString("num")
      val load_weight = x.getString("load_weight")
      val start_tm = x.getString("start_tm")
      val rt_coords = x.getString("rt_coords")
      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
      val source = x.getString("source")
      val trailer_vehicle_code = x.getString("trailer_vehicle_code")
      val hko_vehicle_code = x.getString("hko_vehicle_code")
      val tolls = x.getString("tolls")
      val emission = x.getString("emission")
      val vehicle_serial = x.getString("vehicle_serial")
      val exception_length = x.getString("exception_length")
      val min_route_y = x.getString("min_route_y")
      val id = x.getString("id")
      val inner_length = x.getString("inner_length")
      val min_route_x = x.getString("min_route_x")
      val tag = x.getString("tag")
      val energy = x.getString("energy")
      val rt_tollsDistance = x.getString("rt_tollsDistance")
      val vehicle_length = x.getString("vehicle_length")
      val weight = x.getString("weight")
      val outer_height = x.getString("outer_height")
      val inner_height = x.getString("inner_height")
      val start_time = x.getString("start_time")
      val license = x.getString("license")
      val line_code = x.getString("line_code")
      val abnormal = x.getString("abnormal")
      val start_dept = x.getString("start_dept")
      val actual_run_time = x.getString("actual_run_time")
      val start_distance = x.getString("start_distance").replaceAll("(\0|\\s*|\r|\n|\t)", "")
      val end_address = x.getString("end_address").replaceAll("(\0|\\s*|\r|\n|\t)", "")
      val outer_length = x.getString("outer_length")
      val rt_time = x.getString("rt_time")
      val end_type = x.getString("end_type")
      val color = x.getString("color")
      val max_route_y = x.getString("max_route_y")
      val rt_highway = x.getString("rt_highway")
      val max_route_x = x.getString("max_route_x")
      val task_id = x.getString("task_id")
      val end_tm = x.getString("end_tm")
      val start_type = x.getString("start_type")
      val end_latitude = x.getString("end_latitude")
      val exception_width = x.getString("exception_width")
      val line_id = x.getString("line_id")
      val is_trailer = x.getString("is_trailer")
      val plan_run_time = x.getString("plan_run_time")
      val start_latitude = x.getString("start_latitude")
      val exception_axis = x.getString("exception_axis")
      val vehicle_type_ground = x.getString("vehicle_type_ground")
      val rt_dist = x.getString("rt_dist")
      val full_load_weight = x.getString("full_load_weight")
      val conveyance_type = x.getString("conveyance_type")
      val inner_width = x.getString("inner_width")
      val task_area_code = x.getString("task_area_code")
      val length = x.getString("length")
      val vehicle_type = x.getString("vehicle_type")
      val attr7 = x.getString("attr7")
      val is_stop = x.getString("is_stop")
      val exception_weight = x.getString("exception_weight")
      val start_longitude = x.getString("start_longitude")
      val transoport_level = x.getString("transoport_level")
      val inc_day_carInfo = x.getString("inc_day_carInfo")
      val outer_width = x.getString("outer_width")
      val sort_num = x.getString("sort_num")
      val start_address = x.getString("start_address")
      val inc_day = x.getString("inc_day")
      val end_distance = x.getString("end_distance")
      val compDistRatio = x.getString("compDistRatio")
      val compTimeRatio = x.getString("compTimeRatio")
      val typical_tag = JSONUtils.getJsonValue(x,"typical_tag","")
      val end_dept = x.getString("end_dept")
      val exception_height = x.getString("exception_height")
      val vehicle_full_load_weight = x.getString("vehicle_full_load_weight")
      val data_source = "tracks"

      val daily_freq = x.getString("daily_freq")
      val group_day_min =x.getString("group_day_min")
      val group_day_max = x.getString("group_day_max")
      val log_dist = x.getString("log_dist")

      //20210629新增字段
      val driver_name = x.getString("driver_name")
      val trans_car = x.getString("trans_car")
      val carrier_name = x.getString("carrier_name")
      val cvy_name = x.getString("cvy_name")
      val line_distance = x.getString("line_distance")

      //20210708新增字段
      val match_order_st= x.getString("match_order_st")


      tracksInfo(task_id,start_dept,end_dept,start_type,end_type,start_tm,end_tm,actual_run_time
        ,plan_run_time,rt_time,sort_num,start_longitude,end_longitude,start_latitude,end_latitude
        ,start_address,end_address,line_code,line_id,task_area_code,vehicle_serial,conveyance_type
        ,transoport_level,id,inc_day_carInfo,is_stop,ground_task_id,vehicle_type,axIs_number,rt_dist
        ,rt_highway ,tolls,rt_tollsDistance,rt_coords,compDistRatio,compTimeRatio,start_distance
        ,end_distance,abnormal,start_time,sim_group,typical_tag,data_source,daily_freq,group_day_min,group_day_max,log_dist
        ,driver_name,trans_car,carrier_name,cvy_name,line_distance,match_order_st)

    }).repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_traj_simgroup_info")

  }


  def getMonthHalfYearFreq(spark: SparkSession, inc_day: String) = {

    import spark.implicits._

    val monthDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-30)
    //val halfYearDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-180)
    val monthHiveTable ="dm_gis.eta_dist_time_month_freq"
    //val halfYearHiveTable ="dm_gis.eta_dist_time_half_year_freq"

    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-45)
    val dropSql1 =
      s"""
         |alter table  dm_gis.eta_dist_time_month_freq drop if exists partition (inc_day='${dropDate}')
       """.stripMargin
    logger.error("删除月级明细表45天前数据" + dropSql1)
    spark.sql(dropSql1)

//    val dropSql2 =
//      s"""
//         |alter table  dm_gis.eta_dist_time_half_year_freq drop if exists partition (inc_day='${dropDate}')
//       """.stripMargin
//    logger.error("删除半年级明细表45天前数据" + dropSql2)
//    spark.sql(dropSql2)


//    val sourceSql =
//      s"""
//         |select
//         |  *
//         |from
//         |  dm_gis.eta_traj_simgroup_info
//         |where
//         |  inc_day >='${halfYearDay}'
//       """.stripMargin

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_traj_simgroup_info
         |where
         |  inc_day >='${monthDay}'
       """.stripMargin


    logger.error("存入半年频次表的sql为：" + sourceSql)
    val halfYearDf = spark.sql(sourceSql)
    logger.error("半年内数据量为：" + halfYearDf.count())
    val halfYearCol = halfYearDf.columns

    val halfYearRdd = halfYearDf.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- halfYearCol) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val monthRdd = halfYearRdd.filter(_.getString("inc_day") >= monthDay).map(x =>{
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")
      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
      val axle_number = JSONUtils.getJsonValue(x,"axis_number","2")
      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
      x.put("axle_number",axle_number)
      ((start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group),x)
    }).groupByKey().flatMap(x => {
      val list = x._2.toList
      var month_freq = 0

      //month_freq 求和
      val listNew = list.map(obj => {
        val daily_freq = JSONUtils.getJsonValueInt(obj,"daily_freq",0)
        month_freq += daily_freq
        obj
      }).map(obj => {
        obj.put("month_freq",month_freq)
        obj
      })
      listNew
    }).map(x => {
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")
      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
      val axle_number = JSONUtils.getJsonValue(x,"axle_number","2")
      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
      ((start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group),x)
    }).reduceByKey((obj1,obj2) => {
      mergeMonthFreq(obj1,obj2)
    }).map(_._2).map(x => {
      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
      val start_time = JSONUtils.getJsonValue(x,"start_time","")
      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
      val axle_number = JSONUtils.getJsonValue(x,"axle_number","2")
      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
      val month_freq = JSONUtils.getJsonValue(x,"month_freq","")

      monthTable(start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group,month_freq,inc_day)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("monthRdd的数据量为：" + monthRdd.count())
    monthRdd.toDF().write.mode(SaveMode.Overwrite).insertInto(monthHiveTable)

//    val halfYearFreqRdd = halfYearRdd.map(x =>{
//      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
//      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
//      val start_time = JSONUtils.getJsonValue(x,"start_time","")
//      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
//      val axle_number = JSONUtils.getJsonValue(x,"axis_number","2")
//      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
//      x.put("axle_number",axle_number)
//      ((start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group),x)
//    }).groupByKey().flatMap(x => {
//      val list = x._2.toList
//      var half_year_freq = 0
//
//      //month_freq 求和
//      val listNew = list.map(obj => {
//        val daily_freq = JSONUtils.getJsonValueInt(obj,"daily_freq",0)
//        half_year_freq += daily_freq
//        obj
//      }).map(obj => {
//        obj.put("half_year_freq",half_year_freq)
//        obj
//      })
//      listNew
//    }).map(x => {
//      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
//      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
//      val start_time = JSONUtils.getJsonValue(x,"start_time","")
//      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
//      val axle_number = JSONUtils.getJsonValue(x,"axle_number","2")
//      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
//      ((start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group),x)
//    }).reduceByKey((obj1,obj2) => {
//      mergeMonthFreq(obj1,obj2)
//    }).map(_._2).map(x => {
//      val start_dept = JSONUtils.getJsonValue(x,"start_dept","")
//      val end_dept = JSONUtils.getJsonValue(x,"end_dept","")
//      val start_time = JSONUtils.getJsonValue(x,"start_time","")
//      val vehicle_type = JSONUtils.getJsonValue(x,"vehicle_type","6")
//      val axle_number = JSONUtils.getJsonValue(x,"axle_number","2")
//      val sim_group = JSONUtils.getJsonValue(x,"sim_group","")
//      val half_year_freq = JSONUtils.getJsonValue(x,"half_year_freq","")
//
//      halfYearTable(start_dept,end_dept,start_time,vehicle_type,axle_number,sim_group,half_year_freq,inc_day)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

//    logger.error("halfYearFreqRdd的数据量为：" + halfYearFreqRdd.count())
//    halfYearFreqRdd.toDF().write.mode(SaveMode.Overwrite).insertInto(halfYearHiveTable)

  }

  def mergeMonthFreq(obj1: JSONObject, obj2: JSONObject):JSONObject = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val inc_day_1 = JSONUtils.getJsonValueInt(obj1,"inc_day",0)
    val inc_day_2 = JSONUtils.getJsonValueInt(obj2,"inc_day",0)

    //取inc_day日期最大的
    if(inc_day_1 < inc_day_2){
      return obj2
    }else{
      return obj1
    }
  }




  def saveGjTable(spark:SparkSession,getGjFix: RDD[JSONObject],inc_day:String) = {

    /**
      * 删除轨迹明细表45天前数据
      */

    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-45)
    val dropSql =
      s"""
         |alter table  dm_gis.eta_traj_info drop if exists partition (inc_day='${dropDate}')
       """.stripMargin
    logger.error("删除轨迹明细表45天前数据" + dropSql)
    spark.sql(dropSql)

    import spark.implicits._

//    val dropHisTrajSql =
//      s"""
//         |alter table  dm_gis.eta_his_traj_info drop if exists partition (inc_day='${dropDate}')
//       """.stripMargin
//    logger.error("删除历史车辆轨迹明细表45天前数据" + dropSql)
//    spark.sql(dropHisTrajSql)
//
//    logger.error("存入历史车辆轨迹明细表" + inc_day)
//    val hisTrajInfo = getGjFix.map(x => {
//      //task_id, inc_day, start_dept, end_dept
//
//      val task_id = x.getString("task_id")
//      val start_dept = x.getString("start_dept")
//      val end_dept = x.getString("end_dept")
//      val his_coords = x.getString("his_coords")
//
//      HisTrajInfo(task_id,start_dept,end_dept,his_coords,inc_day)
//    })
//    hisTrajInfo.repartition(50).toDF().write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_his_traj_info")

    logger.error("存入车辆轨迹明细表")
    getGjFix.map(x => {x.toJSONString}).repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_traj_info")
  }

  def getGjFixTable(spark: SparkSession, inc_day: String):RDD[JSONObject] = {
    val sql =
      s"""
         |select info
         |from
         |  dm_gis.eta_traj_info
         |where
         |  inc_day='${inc_day}'
         |and
         |  length(info)>8
       """.stripMargin

    val frame = spark.sql(sql).rdd.map(x => {
      val json = JSON.parseObject(x.mkString(""))
      json
    }).map( x =>{
      x.remove("his_coords")

      //20210918新增jp_swid、status，移除历史轨迹表后续逻辑
      x.remove("jp_swid")
      x.remove("status")

      x
    })

    frame
  }




  def calOntimeRate(groupSimRdd: RDD[JSONObject],inc_day:String) = {
    val ontime8090Rdd =groupSimRdd.map(x => {
      // line_code、start_time、start_dept、end_dept、actual_run_time、plan_run_time、inc_day、vehicle_type
      val jo  = new JSONObject()

      val line_code = x.getString("line_code")
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val actual_run_time = x.getInteger("actual_run_time")
      val plan_run_time = x.getInteger("plan_run_time")
      val inc_day = x.getString("inc_day")
      val vehicle_type = x.getString("vehicle_type")

      val names = Array("line_code","start_time","start_dept","end_dept","actual_run_time","plan_run_time","inc_day","vehicle_type")

      for(i <- names.indices) jo.put(names(i),names(i))

      //以start_time、start_dept、end_dept、vehicle_type分组
      ((start_time,start_dept,end_dept,vehicle_type),jo)

    }).groupByKey().map(x => {
      val list = x._2.toList
      val list2 = list.map(obj => {
        val plan_run_time = obj.getInteger("plan_run_time")
        val actual_run_time = obj.getInteger("actual_run_time")

        //过滤异常值
        if(plan_run_time > 60 && list.size > 1){
          if(actual_run_time < plan_run_time *0.2 ||  actual_run_time > plan_run_time*1.8){
            obj.put("errTag","1")
          }
        }
        //计算历史准点率
        if(plan_run_time >= actual_run_time-1){
          obj.put("ontimeTag","1")
        }
        obj
      })
      val list3 = list2.filter(x => {
        !"1".equals(x.getString("errTag"))
      })
      val historyOntimeCnt = list3.filter(x => {
        "1".equals(x.getString("ontimeTag"))
      }).size

      val historyOntimeRatio = historyOntimeCnt.toDouble / list3.size


      val p8Index = Math.floor(list2.size * 0.8).toInt
      val p9Index = Math.floor(list2.size * 0.9).toInt


      val listNew = list3.sortBy(_.getInteger("actual_run_time")).toList
      val time_p8_pre = listNew(p8Index).getInteger("actual_run_time")
      val time_p9_pre = listNew(p9Index).getInteger("actual_run_time")

      val numberP8 = (time_p8_pre.toInt % 10)
      val numberP8New = numberP8 match {
        case numberP8 if(numberP8==0 ||numberP8==1 || numberP8==2) => 0
        case numberP8 if(3 to 7 contains numberP8) => 5
        case numberP8 if(numberP8==8 || numberP8==9 ) => 10
      }

      val numberP9 = (time_p9_pre.toInt % 10)
      val numberP9New = numberP9 match {
        case numberP9 if(numberP9==0 ||numberP9==1 || numberP9==2) => 0
        case numberP9 if(3 to 7 contains numberP9) => 5
        case numberP9 if(numberP9==8 || numberP9==9 ) => 10
      }

      val time_p8 = time_p8_pre - numberP8 + numberP8New
      val time_p9 = time_p9_pre - numberP9 + numberP9New

      (x._1,list3,time_p8,time_p9,historyOntimeRatio)

    }).map(x => {

      val (key,list,time_p8,time_p9,his_ontime_rate) = x

      val list2 = list.map(obj => {
        val plan_run_time = obj.getInteger("plan_run_time")
        val actual_run_time = obj.getInteger("actual_run_time")
        if(actual_run_time-1 <= time_p8){
          obj.put("ontime80",1)
        }
        if(actual_run_time-1 <= time_p9){
          obj.put("ontime90",1)
        }
      })
      val ontime80 = list2.filter(x => {"1".equals("ontime80")}).size
      val ontime90 = list2.filter(x => {"1".equals("ontime90")}).size

      val groupCnt = list2.size
      val ontime80Ratio = ontime80.toDouble / groupCnt
      val ontime90Ratio = ontime90.toDouble / groupCnt


      val (start_time,start_dept,end_dept,vehicle_type) = x._1

      val jo = new JSONObject()
      jo.put("start_time",start_time)
      jo.put("start_dept",start_dept)
      jo.put("end_dept",end_dept)
      jo.put("vehicle_type",vehicle_type.toInt)
      jo.put("time_p8",time_p8)
      jo.put("time_p9",time_p9)
      jo.put("his_ontime_rate",his_ontime_rate)
      jo.put("ontime80Ratio",ontime80Ratio)
      jo.put("ontime90Ratio",ontime90Ratio)
      jo.put("groupCnt",groupCnt)

      ((start_time,start_dept,end_dept,vehicle_type.toInt),jo)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    val dept8090Rdd = groupSimRdd.filter(x => {
      StringUtils.nonEmpty(x.getString("rt_dist")) &&  !StringUtils.nonEmpty(x.getString("abnormal"))
    }).map(x => {
      //start_time、start_dept、end_dept、inc_day、vehicle_type、rt_dist
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val inc_day = x.getString("inc_day")
      val vehicle_type = x.getInteger("vehicle_type")
      val rt_dist = x.getDouble("rt_dist")

      ((start_time,start_dept,end_dept,vehicle_type.toInt),(inc_day,rt_dist))
    }).groupByKey().map(x => {

      val list = x._2.toList.sortBy(_._2)
      val size = list.size
      val size80 = Math.floor(size * 0.8).toInt
      val size90 = Math.floor(size * 0.9).toInt
      val dist_p8 =  list(size80)._2
      val dist_p9 = list(size90)._2

      (x._1,(dist_p8,dist_p9))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    val historyOntimeDept = ontime8090Rdd.leftOuterJoin(dept8090Rdd).map(x => {
      val (start_time,start_dept,end_dept,vehicle_type) = x._1
      val leftBody = x._2._1

      val time_p8 = leftBody.getInteger("time_p8")
      val time_p9 = leftBody.getInteger("time_p9")
      val his_ontime_rate = leftBody.getDouble("his_ontime_rate")
      val ontime80Ratio = leftBody.getString("ontime80Ratio")
      val ontime90Ratio = leftBody.getString("ontime90Ratio")
      val groupCnt = leftBody.getInteger("groupCnt")

      var (dist_p8,dist_p9) =(0.0,0.0)
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        val tuple89 = rightOption.get
        dist_p8 =tuple89._1
        dist_p9 =tuple89._2
      }

      HistoryOntimeDept(start_time,start_dept,end_dept,vehicle_type,time_p8.toInt,time_p9.toInt,his_ontime_rate.toString,ontime80Ratio,ontime90Ratio,groupCnt,dist_p8,dist_p9,inc_day)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

  }




  def groupSim(spark: SparkSession,addAbnormalRDD: RDD[JSONObject],inc_day:String):RDD[JSONObject] = {

    val beginDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-30)
    val end = inc_day

//    val hisGroupSql =
//      s"""
//         |select
//         |  start_dept,end_dept,start_time,line_code,inc_day,vehicle_type,axis_number,tolls,rt_coords,sim_group,rt_dist
//         |from
//         |  dm_gis.eta_traj_simgroup_info
//         |where
//         |  inc_day >= '${beginDay}'
//         |and
//         |  inc_day <= '${inc_day}'
//         |and
//         |  typical_tag =1
//         |and
//         |  sim_group != ''
//         |and
//         |  sim_group is not null
//         |and
//         |  length(rt_coords) > 8
//       """.stripMargin

    val hisGroupSql =
      s"""
         |select
         |   start_dept,end_dept,start_time,line_code,inc_day,vehicle_type,axis_number,tolls,rt_coords,sim_group,rt_dist
         |from
         |(
         |select
         |  start_dept,end_dept,start_time,line_code,inc_day,vehicle_type,axis_number,tolls,rt_coords,sim_group,rt_dist,row_number() over (partition by start_dept,end_dept,start_time,vehicle_type,axis_number,sim_group order by inc_day desc) as rn
         |from
         |  dm_gis.eta_traj_simgroup_info
         |where
         |  inc_day >= '${beginDay}'
         |and
         |  inc_day <= '${inc_day}'
         |and
         |  typical_tag =1
         |and
         |  sim_group != ''
         |and
         |  sim_group is not null
         |and
         |  length(rt_coords) > 8
         |) a
         |where
         |    a.rn = 1
       """.stripMargin
    val hisGroupInput = spark.sql(hisGroupSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取历史轨迹分组数据")
    val hisGroupRdd = SparkUtils.getRowToJson(hisGroupInput).map(x => {
      val axIs_number = x.getString("axis_number")
      x.put("axIs_number",axIs_number)
      x.put("history","1")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("历史轨迹分组数据量为"+ hisGroupRdd.count())

//    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-45)
//    val dropSql =
//      s"""
//         |alter table  dm_gis.eta_traj_simgroup_info drop if exists partition (inc_day='${dropDate}')
//       """.stripMargin
//    logger.error("删除45天前数据" + dropSql)
//    spark.sql(dropSql)


    val group1Sim = addAbnormalRDD.union(hisGroupRdd).filter(x => {x.getString("rt_coords").length>8}).map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axIs_number = x.getString("axIs_number")

      ((start_time, start_dept, end_dept, vehicle_type, axIs_number), x)

    }).filter(x => {
      val tuple = x._1
      StringUtils.nonEmpty(tuple._1) && StringUtils.nonEmpty(tuple._2) && StringUtils.nonEmpty(tuple._3) && StringUtils.nonEmpty(tuple._4)&& StringUtils.nonEmpty(tuple._5)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("group1Sim的数据量为：" + group1Sim.count())
    group1Sim.take(1).foreach(println(_))

    val group1SimNew =  group1Sim.groupByKey().repartition(200).map(x => {
      //compareBuffer存储历史分组数据
      val compareBuffer = new ArrayBuffer[JSONObject]()
      val list = x._2.toList
      for (i <- 0 until(list.size)){
        if (StringUtils.nonEmpty(list(i).getIntValue("sim_group").toString)){
          compareBuffer.append(list(i))
        }
      }
      (x,compareBuffer)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("group1SimNew的数据量为：" + group1SimNew.count())


//    val group1Sim2Pre = group1SimNew.flatMap(x => {
//      val list = x._2.toList
//      val compareBuffer = x._2
//
//      //判断是否有历史的数据
//      if (compareBuffer.size == 0) {
//        var index = 0
//        for (i <- 0 until (list.size)) {
//          if (i == 0) {
//            list(0).put("sim_group", index)
//            list(0).put("typical_tag", "1")
//            //0519新增group_day_min、group_day_max字段
//            list(0).put("group_day_min",inc_day)
//            list(0).put("group_day_max",inc_day)
//
//            compareBuffer.append(list(0))
//          } else {
//            var falg1 = 0
//            for (j <- 0 until (compareBuffer.size) if falg1 == 0) {
//              //Thread.sleep(2)
//              //新增里程比统计
//              val rt_dist_i = JSONUtils.getJsonValueDouble(list(i),"rt_dist",0.0)
//              val rt_dist_j = JSONUtils.getJsonValueDouble(compareBuffer(j),"rt_dist",0.0)
//              val ratio = rt_dist_i / rt_dist_j
//              //先判断里程比是否相似，再调用相似度接口
//              if((ratio >0.8 && ratio < 1.2)){
//                val similar = try{getSimilarInterface.getSimilar(list(i), compareBuffer(j))} catch {case e:Exception => 0.0}
//                if (similar > 0.9) {
//                  list(i).put("sim_group", compareBuffer(j).getString("sim_group"))
//                  //0519新增group_day_min、group_day_max字段
//                  val group_day_min  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_min",inc_day)
//                  //val group_day_max  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_max",inc_day)
//                  list(i).put("group_day_min",group_day_min)
//                  list(i).put("group_day_max",inc_day)
//
//                  falg1 = 1
//                }
//              }
//            }
//            if (falg1 == 0) {
//              index += 1
//              list(i).put("sim_group", index)
//              list(i).put("typical_tag", 1)
//              //0519新增group_day_min、group_day_max字段
//              list(i).put("group_day_min",inc_day)
//              list(i).put("group_day_max",inc_day)
//
//              compareBuffer.append(list(i))
//            }
//          }
//        }
//      } else {
//        val maxSim = list.toStream.maxBy(JSONUtils.getJsonValueInt(_,"sim_group", 0))
//        var index = JSONUtils.getJsonValueInt(maxSim, "sim_group", 0)
//
//        for (i <- 0 until (list.size)) {
//          var falg2 = 0
//          for (j <- 0 until (compareBuffer.size) if falg2 == 0) {
//
//            //新增里程比统计
//            val rt_dist_i = JSONUtils.getJsonValueDouble(list(i),"rt_dist",0.0)
//            val rt_dist_j =JSONUtils.getJsonValueDouble(compareBuffer(j),"rt_dist",0.0)
//            val ratio = rt_dist_i / rt_dist_j
//
//            if(ratio >0.8 && ratio < 1.2){
//              val similar = try{getSimilarInterface.getSimilar(list(i), compareBuffer(j))} catch {case e:Exception => 0.0}
//              if (similar > 0.9) {
//                list(i).put("sim_group", compareBuffer(j).getIntValue("sim_group"))
//                //0519新增group_day_min、group_day_max字段
//                val group_day_min  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_min",inc_day)
//                //val group_day_max  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_max",inc_day)
//                list(i).put("group_day_min",group_day_min)
//                list(i).put("group_day_max",inc_day)
//
//                falg2 = 1
//              }
//            }
//          }
//          if (falg2 == 0) {
//            index += 1
//            list(i).put("sim_group", index)
//            list(i).put("typical_tag", 1)
//            //0519新增group_day_min、group_day_max字段
//            list(i).put("group_day_min",inc_day)
//            list(i).put("group_day_max",inc_day)
//
//            compareBuffer.append(list(i))
//          }
//        }
//      }
//      list
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val limitMin =  10000

    val group1Sim2Pre = group1SimNew.mapPartitionsWithIndex((index, iter) => {
      val partitionLimitMinu = limitMin * 0.9 / 90
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }
        val list = x._2.toList
        val compareBuffer = x._2

        //判断是否有历史的数据
        if (compareBuffer.size == 0) {
          var index = 0
          for (i <- 0 until (list.size)) {
            if (i == 0) {
              list(0).put("sim_group", index)
              list(0).put("typical_tag", "1")
              //0519新增group_day_min、group_day_max字段
              list(0).put("group_day_min",inc_day)
              list(0).put("group_day_max",inc_day)

              compareBuffer.append(list(0))
            } else {
              var falg1 = 0
              for (j <- 0 until (compareBuffer.size) if falg1 == 0) {
                //Thread.sleep(2)
                //新增里程比统计
                val rt_dist_i = JSONUtils.getJsonValueDouble(list(i),"rt_dist",0.0)
                val rt_dist_j = JSONUtils.getJsonValueDouble(compareBuffer(j),"rt_dist",0.0)
                val ratio = rt_dist_i / rt_dist_j
                //先判断里程比是否相似，再调用相似度接口
                if((ratio >0.8 && ratio < 1.2)){
                  //val similar = try{getSimilarInterface.getSimilar(list(i), compareBuffer(j))} catch {case e:Exception => 0.0}
                  val similar = 1
                  if (similar > 0.9) {
                    list(i).put("sim_group", compareBuffer(j).getString("sim_group"))
                    //0519新增group_day_min、group_day_max字段
                    val group_day_min  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_min",inc_day)
                    //val group_day_max  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_max",inc_day)
                    list(i).put("group_day_min",group_day_min)
                    list(i).put("group_day_max",inc_day)

                    falg1 = 1
                  }
                }
              }
              if (falg1 == 0) {
                index += 1
                list(i).put("sim_group", index)
                list(i).put("typical_tag", 1)
                //0519新增group_day_min、group_day_max字段
                list(i).put("group_day_min",inc_day)
                list(i).put("group_day_max",inc_day)

                compareBuffer.append(list(i))
              }
            }
          }
        } else {
          val maxSim = list.toStream.maxBy(JSONUtils.getJsonValueInt(_,"sim_group", 0))
          var index = JSONUtils.getJsonValueInt(maxSim, "sim_group", 0)

          for (i <- 0 until (list.size)) {
            var falg2 = 0
            for (j <- 0 until (compareBuffer.size) if falg2 == 0) {

              //新增里程比统计
              val rt_dist_i = JSONUtils.getJsonValueDouble(list(i),"rt_dist",0.0)
              val rt_dist_j =JSONUtils.getJsonValueDouble(compareBuffer(j),"rt_dist",0.0)
              val ratio = rt_dist_i / rt_dist_j

              if(ratio >0.8 && ratio < 1.2){
//                val similar = try{getSimilarInterface.getSimilar(list(i), compareBuffer(j))} catch {case e:Exception => 0.0}
                val similar = 1
                if (similar > 0.9) {
                  list(i).put("sim_group", compareBuffer(j).getIntValue("sim_group"))
                  //0519新增group_day_min、group_day_max字段
                  val group_day_min  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_min",inc_day)
                  //val group_day_max  = JSONUtils.getJsonValue(compareBuffer(j),"group_day_max",inc_day)
                  list(i).put("group_day_min",group_day_min)
                  list(i).put("group_day_max",inc_day)

                  falg2 = 1
                }
              }
            }
            if (falg2 == 0) {
              index += 1
              list(i).put("sim_group", index)
              list(i).put("typical_tag", 1)
              //0519新增group_day_min、group_day_max字段
              list(i).put("group_day_min",inc_day)
              list(i).put("group_day_max",inc_day)

              compareBuffer.append(list(i))
            }
          }
        }
        list
      }).flatten
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("group1Sim2Pre的数据量为：" + group1Sim2Pre.count())
    group1Sim2Pre.take(2).foreach(println(_))
    group1Sim.unpersist()
    group1SimNew.unpersist()


    group1Sim2Pre.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axIs_number = x.getString("axIs_number")
      val sim_group = x.getString("sim_group")
      ((start_time,start_dept,end_dept,vehicle_type,axIs_number,sim_group), x)
    }).countByKey().toArray.sortBy(-_._2).take(10).foreach(obj=>{
      println(obj._1+":"+obj._2)
    })


    val group1Sim2 = group1Sim2Pre.filter(x => {
      !StringUtils.nonEmpty(x.getString("history"))
    }).map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val vehicle_type = x.getString("vehicle_type")
      val axIs_number = x.getString("axIs_number")
      val sim_group = x.getString("sim_group")
      x.put("typical_tag", 0)
      ((start_time, start_dept, end_dept, vehicle_type, axIs_number, sim_group), x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .flatMap(x => {
        val list = x._2.toList.sortBy(x => {
          JSONUtils.getJsonValueDouble(x, "rt_dist", 0.0)
        })
        val index = scala.math.floor(list.size / 2).toInt
        list(index).put("typical_tag", 1)
        list
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    group1SimNew.unpersist()
    logger.error("group1Sim2的数据量为：" + group1Sim2.count())
    group1Sim2Pre.unpersist()
    group1Sim2
  }



  def addAbnormal(getGjFix: RDD[JSONObject]): RDD[JSONObject] = {

    val abNormal = getGjFix.repartition(200).filter(x => StringUtils.nonEmpty(x.getString("rt_coords"))).repartition(400).map(x => {

      val start_distance = JSONUtils.getJsonValueInt(x,"start_distance",0)
      val end_distance = JSONUtils.getJsonValueInt(x,"end_distance",0)
      val compDistRatio = JSONUtils.getJsonValueDouble(x,"compDistRatio",0.0)
      val compTimeRatio = JSONUtils.getJsonValueDouble(x,"compTimeRatio",0.0)
      val tracks = x.getJSONArray("rt_coords")
      var abnormal = ""

      if(start_distance> 500){
        abnormal = abnormal + "1" + "|"
      }
      if(end_distance> 500){
        abnormal = abnormal + "2" + "|"
      }
      if(compDistRatio> 0.1){
        abnormal = abnormal + "4" + "|"
      }
      if(compTimeRatio> 0.1){
        abnormal = abnormal + "5" + "|"
      }
      for (i <- 0 until (tracks.size()-1) if tracks.size()>2) {
        val array0 = tracks.getJSONArray(i)
        val array1 = tracks.getJSONArray(i+1)
        val x1 = array0.getDouble(0)
        val y1 = array0.getDouble(1)
        val x2 = array1.getDouble(0)
        val y2 = array1.getDouble(1)

        val distance = DistanceTool.getGreatCircleDistance(x1,y1,x2,y2)
        if(distance > 2000 && !abnormal.contains("6")){
          abnormal = abnormal + "6" + "|"
        }
      }

      x.put("abnormal",abnormal)
      x.put("sim_group","")
      x.put("typical_tag","")
      x
    })

    abNormal
  }.persist(StorageLevel.MEMORY_AND_DISK_SER)




  def getGjFixMethod(getinputRdd:RDD[JSONObject]):RDD[JSONObject] = {
    logger.error("getinputRdd"+getinputRdd.count() )
    val gjFix =  getinputRdd.repartition(6).filter(x => {StringUtils.nonEmpty(x.getString("start_tm")) && StringUtils.nonEmpty(x.getString("end_tm"))}).map(x => {
      val vehicle_serial = x.getString("vehicle_serial")
      val start_tm = x.getString("start_tm")
      val end_tm = x.getString("end_tm")

      val start_tm_Extract = DateTimeUtil.getConvertFormatDate(start_tm, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
      val end_tm_Extract = DateTimeUtil.getConvertFormatDate(end_tm, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")

      val start_tm_new = DateTimeUtil.getMinBeforeAfter(start_tm_Extract,"yyyyMMddHHmmss",-5)
      val end_tm_Extract_new = DateTimeUtil.getMinBeforeAfter(end_tm_Extract,"yyyyMMddHHmmss",5)

      val vehicle_type = JSONUtils.getJsonValueInt(x,"vehicle_type",6)
      x.put("vehicle_type",vehicle_type)
      val loadweight = JSONUtils.getJsonValueDouble(x,"loadweight",0.0)

      val axIs_number = JSONUtils.getJsonValueInt(x,"axIs_number",2)
      x.put("axIs_number",axIs_number)

      val weight = JSONUtils.getJsonValueDouble(x,"weight",0.0)
      val length = JSONUtils.getJsonValueDouble(x,"length",0.0)

      val historyTraj = scheduleHistoryTrajInterface(vehicle_serial,start_tm_new,end_tm_Extract_new).toJSONString
      //val historyTraj = scheduleHistoryTrajInterface(vehicle_serial,start_tm_Extract,end_tm_Extract).toJSONString

      val joPost = new JSONObject()
      var fixResponse =""
      var fixJson =new JSONObject()


      if(StringUtils.nonEmpty(historyTraj) && historyTraj.length >2 ){
        val array = JSON.parseArray(historyTraj)
        val group_tm = array.toArray.map(x => {
          val json = x.asInstanceOf[JSONObject]
          val tm = json.getString("tm")
          (tm,json)
        }).toStream.sortBy(_._1)

        val tracks = new JSONArray()

        group_tm.zipWithIndex.toArray.map(x => {
          val joTracks = new JSONObject()
          val trajJson = x._1._2.asInstanceOf[JSONObject]
          val index = x._2.asInstanceOf[Int]
          val ac = trajJson.getInteger("ac")
          val be = trajJson.getString("be")
          val sp = trajJson.getDouble("sp")
          val tm = trajJson.getInteger("tm")
          val zx = trajJson.getDouble("zx")
          val zy = trajJson.getDouble("zy")

          joTracks.put("accuracy",ac)
          joTracks.put("azimuth",be)
          joTracks.put("index",index)
          joTracks.put("speed",sp)
          joTracks.put("time",tm)
          joTracks.put("type",1)
          joTracks.put("x",zx)
          joTracks.put("y",zy)
          tracks.add(joTracks)
        })

        joPost.put("keeptype",1)
        joPost.put("ak","4dc00a88a1f34bffa49a153103458efc")
        joPost.put("vehicle",vehicle_type)
        joPost.put("roadinfo",1)
        joPost.put("retflag",7)
        joPost.put("addpoint",1)
        joPost.put("only_primary",1)
        joPost.put("compensate",1)
        joPost.put("compensate_time",0)
        joPost.put("compensate_dist",0)
        joPost.put("mat_ratio",1)
        joPost.put("poiinfo",1)


        val vehicleInfo = new JSONObject()
        //vehicleInfo.put("load",loadweight.asInstanceOf[Double])
        vehicleInfo.put("load",loadweight)
        vehicleInfo.put("axis",axIs_number)
        vehicleInfo.put("weight",0)
        vehicleInfo.put("length",0)
        joPost.put("vehicleInfo",vehicleInfo)
        joPost.put("tracks",tracks)

        fixResponse = Utils.post(fixUrl,joPost,"utf-8")
        //fixJson.put("joPost",joPost)
        if(fixResponse != null && !fixResponse.isEmpty && fixResponse.contains("tracks") && fixResponse.contains("result")){
          try{
            val  fixResponse2=JSON.parseObject(fixResponse)
              fixJson =  try{parsefixResponse(x,fixResponse2)} catch {case e:Exception => {
              fixJson.put("err",e)
              fixJson
            }}
          } catch {case e:Exception =>
            logger.error("json error:"+fixResponse)
            fixJson.put("err",e)
          }
        }else{
          fixJson.put("err",fixResponse)
        }
      }
      fixJson.put("joPost",joPost)
      fixJson.put("his_coords",historyTraj)
      fixJson
    }).filter(x => !StringUtils.nonEmpty(x.getString("err")))
    gjFix
  }.persist(StorageLevel.MEMORY_AND_DISK_SER)

  //获取纠偏接口返回
  def parsefixResponse(allJson:JSONObject,fixRes:JSONObject): JSONObject ={

    val jo = new JSONObject()

    val result = fixRes.getJSONObject("result")
    val rt_dist =JSONUtils.getJsonValueDouble(result,"len",0.0) / 1000
    //val rt_dist = result.getIntValue("len") / 1000
    val rt_highway = JSONUtils.getJsonValueInt(result,"highwaymileage",0) /1000
    val tolls = JSONUtils.getJsonValueDouble(result,"tollCharge",0.0)
    val rt_tollsDistance = JSONUtils.getJsonValueInt(result,"tollMileage",0) /1000
    val tracks = result.getJSONArray("tracks")

    val tracksNew = tracks.toArray.map(x => {
      val jo = x.asInstanceOf[JSONObject]
      val array = new JSONArray()
      val x1 = jo.getDouble("x")
      val y1 = jo.getDouble("y")
      array.add(x1)
      array.add(y1)
      array
    })


    //20210918新增status、swid字段
    val tracksStatus = tracks.toArray.map(x => {
      val jo = x.asInstanceOf[JSONObject]
      val status = jo.getString("status")
      status
    })

    val tracksSwid = tracks.toArray.map(x => {
      val jo = x.asInstanceOf[JSONObject]
      val swid = jo.getString("SWID")
      swid
    })


    val compDistRatio = result.getDouble("compDistRatio")
    if (!StringUtils.nonEmpty(compDistRatio.toString)){
      val compDistRatio = 0.0
    }
    val compTimeRatio = result.getDouble("compTimeRatio")
    if (!StringUtils.nonEmpty(compTimeRatio.toString)){
      val compTimeRatio = 0.0
    }
    //修改版本0.1
    //    val min_route_x = allJson.getDouble("min_route_x")
    //    val min_route_y = allJson.getDouble("min_route_y")
    //    val max_route_x = allJson.getDouble("max_route_x")
    //    val max_route_y = allJson.getDouble("max_route_y")

    //修改后
    val min_route_x = allJson.getDouble("start_longitude")
    val min_route_y = allJson.getDouble("start_latitude")
    val max_route_x = allJson.getDouble("end_longitude")
    val max_route_y = allJson.getDouble("end_latitude")


    val tracksArray =tracks.toArray

    var start_distance = 0.0
    var end_distance = 0.0

    if (tracksArray.size > 0){
      val firstTrack = tracksArray.head.asInstanceOf[JSONObject]
      val lastTrack = tracksArray(tracksArray.size-1).asInstanceOf[JSONObject]

      val first_x = firstTrack.getDouble("x")
      val first_y = firstTrack.getDouble("y")
      val last_x = lastTrack.getDouble("x")
      val last_y = lastTrack.getDouble("y")

      start_distance = DistanceTool.getGreatCircleDistance(min_route_x,min_route_y,first_x,first_y)
      end_distance = DistanceTool.getGreatCircleDistance(max_route_x,max_route_y,last_x,last_y)

    }


    val sort_array = tracksArray.map(x => {
      val jo = x.asInstanceOf[JSONObject]
      val time = jo.getString("time").toInt
      (time,jo)
    }).sortBy(_._1)

    val mintime = sort_array.minBy(_._1)._1.asInstanceOf[Int]
    val maxtime = sort_array.maxBy(_._1)._1.asInstanceOf[Int]

    val rt_time = Math.ceil((maxtime - mintime) / 60).toInt

    //    val maxMatchOrderJson = sort_array.maxBy(_._1)._2

    //    val maxMatchOrder = JSONUtils.getJsonValueInt(maxMatchOrderJson,"matchOrder",0)

    //    //判断数组是否连续
    //    if(maxMatchOrder== sort_array.length -1){
    //      match_order_st = 0
    //    }

    //判断数组是否连续
    var match_order_st = 1
    var matchOrder = 0


    sort_array.map(x => {
      val matchOrderNew = JSONUtils.getJsonValueInt(x._2,"matchOrder",0)
      if(matchOrder > matchOrderNew){
        match_order_st = 0
      }
      matchOrder = matchOrderNew

    })



    allJson.put("rt_dist",rt_dist)
    allJson.put("rt_highway",rt_highway)
    allJson.put("tolls",tolls)
    allJson.put("rt_tollsDistance",rt_tollsDistance)
    allJson.put("rt_coords",tracksNew)
    allJson.put("compDistRatio",compDistRatio)
    allJson.put("compTimeRatio",compTimeRatio)
    allJson.put("start_distance",start_distance)
    allJson.put("end_distance",end_distance)
    allJson.put("rt_time",rt_time)
    allJson.put("match_order_st",match_order_st)

    //20210918新增jp_swid、status
    allJson.put("jp_swid","[" + tracksSwid.mkString("|") + "]")
    allJson.put("status","[" + tracksStatus.mkString("|") + "]")



    allJson
  }


  def getAxisVehicle(obj1: JSONObject, obj2: JSONObject): JSONObject = {

    val vehicle_type1 = obj1.getString("vehicle_type")
    val vehicle_type2 = obj2.getString("vehicle_type")


    if(StringUtils.nonEmpty(vehicle_type1)){
      return obj1
    }else{
      return obj2
    }

  }

  def getTimerJoin(getJoinData: RDD[(String, JSONObject)], timerInfoRdd: RDD[(String, JSONObject)]) = {

    val joinRdd = getJoinData.leftOuterJoin(timerInfoRdd).map(x => {
      val left = x._2._1
      val rightOp = x._2._2
      var log_dist=""
      val start_dept = left.getString("start_dept")
      val end_dept = left.getString("end_dept")
      val start_time = left.getString("start_time")
      val line_code = left.getString("line_code")
      val concat = start_dept+end_dept+start_time

      if(line_code.equals(concat) && rightOp.nonEmpty){
        log_dist = rightOp.get.getString("log_dist")
        left.put("log_dist",log_dist)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)



    joinRdd

  }

  /**note
    *
    * 获取历史任务数据和车辆信息数据
    *
    * @param spark
    * @param inc_day
    * @return 关联后的数据
    */
  def getTaskAndCarInfo(spark: SparkSession, inc_day: String):RDD[JSONObject] = {
    //获取数据
    val beginDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -2)
    val endDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 2)

    val beginDayBefore = DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -3)
    val endDayAfter= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 3)


    val taskSql =
    s"""
         |SELECT bb.* FROM
         | (select
         |      aa.task_id,
         |      aa.carrier_type,
         |      aa.plf_flag,
         |      aa.driver_name,
         |	  aa.cvy_name,
         |	  aa.carrier_name,
         |	  case
         |		when (aa.carrier_type='0' or aa.plf_flag='1') then '自营'
         |		else '外包'
         |	   end
         |	   as trans_car,
         |      lag(aa.actual_pass_zone_code, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_dept,
         |      aa.actual_pass_zone_code as end_dept,
         |    lag(aa.start_time, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_time,
         |      lag(aa.field_bak08, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_type,
         |    aa.field_bak08 as end_type,
         |    lag(aa.actual_depart_tm, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_tm,
         |      aa.actual_arrive_tm end_tm,
         |      lag(aa.actual_run_time, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) actual_run_time,
         |      lag(aa.plan_run_time, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) plan_run_time,
         |      lag(aa.sort_num, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as sort_num,
         |      lag(aa.longitude, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_longitude,
         |      aa.longitude end_longitude,
         |      lag(aa.latitude, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_latitude,
         |      aa.latitude end_latitude,
         |      lag(aa.address, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_address,
         |      aa.address end_address,
         |      lag(aa.line_code, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) line_code,
         |      lag(aa.line_id, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) line_id,
         |      lag(aa.task_area_code, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) task_area_code,
         |      lag(regexp_replace(vehicle_serial, '[\\r\\n\\0, \\s, \\.*。、,]+', ''), 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) vehicle_serial,
         |      lag(aa.conveyance_type, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) conveyance_type,
         |      lag(aa.transoport_level, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) transoport_level,
         |      lag(aa.attr7, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) attr7,
         |    lag(aa.id, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) id,
         |    lag(aa.inc_day, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) inc_day,
         |    lag(aa.is_stop, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) is_stop,
         |    lag(aa.ground_task_id, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) ground_task_id,
         |    lag(aa.line_distance, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) line_distance
         |    from
         |      (
         |        SELECT
         |          a.task_id,
         |          a.carrier_type,
         |          a.plf_flag,
         |          a.driver_name,
         |          b.actual_pass_zone_code,
         |          b.actual_depart_tm,
         |          b.actual_arrive_tm,
         |          regexp_replace(substring(b.plan_depart_tm,12,5),':','') as start_time,
         |          b.actual_run_time,
         |          b.plan_run_time,
         |          b.sort_num,
         |          c.longitude,
         |          c.latitude,
         |          c.address,
         |          c.field_bak08,
         |          a.ground_task_id,
         |          a.line_code,
         |          a.line_id,
         |          a.task_area_code,
         |          a.vehicle_serial,
         |          a.conveyance_type,
         |          a.transoport_level,
         |          a.attr7,
         |          a.id,
         |          a.inc_day,
         |          a.is_stop,
         |		  a.cvy_name,
         |		  a.carrier_name,
         |		  c.line_distance
         |        from
         |          (
         |            select
         |              *
         |            from
         |              dm_grd.grd_new_task_detail
         |            where
         |              inc_day = '${inc_day}'
         |              and state = 6
         |              and src_zone_code not in ('852', '853', '886') -- 剔 除 港 澳 台 20190619
         |              and dest_zone_code not in ('852', '853', '886')
         |              and conveyance_type = 5
         |          ) a
         |          INNER join (
         |            SELECT
         |              row_number() over(
         |                PARTITION by task_id,
         |                dept_site_id
         |                ORDER by
         |                  last_update_tm desc
         |              ) as rn,
         |              *
         |            from
         |              ods_russtask.tt_vehicle_task_pass_zone_monitor
         |            where
         |              inc_day >= '${beginDay}'
         |              AND inc_day <= '${inc_day}'
         |          ) b on a.task_id = b.task_id
         |          and b.rn = 1
         | left outer join (
         |            select
         |              *
         |            from
         |              ods_shiva_ground.tt_driver_task_detail
         |            where
         |               inc_day >= '${beginDay}'
         |              AND inc_day <= '${inc_day}'
         |          ) c on a.ground_task_id = c.driver_task_id
         |          AND a.task_area_code = c.own_dept_code
         |          and b.actual_pass_zone_code = c.dept_code
         |          and b.sort_num = c.thru_seq_code
         |        order by
         |          a.task_id,
         |          b.sort_num
         |      ) aa)bb
         |      WHERE bb.start_dept != '' AND bb.end_dept  != ''  and bb.start_dept != bb.end_dept
         |    and bb.start_type!=1 and bb.end_type!=1
           """.stripMargin

    val carBeginDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, -7)

    val carSql =
      s"""
         |select
         |  *
         |from
         |  (
         |    SELECT
         |      row_number() over(
         |        partition by regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '')
         |        order by
         |          source,inc_day,case
         |            when vehicle_type = 4 then 1
         |            when vehicle_type = 8 then 2
         |            when vehicle_type = 7 then 3
         |            when vehicle_type = 6 then 4
         |            when vehicle_type = 5 then 5
         |            else 6
         |          end,
         |          vehicle_length + 0 desc
         |      ) num,
         |      regexp_replace(vehicle, '[\\r\\n\\0, \\s, \\.*。、,]+', '') vehicle_serial,
         |      hko_vehicle_code,
         |      trailer_vehicle_code,
         |      source,
         |      if(vehicle_type='' or vehicle_type is null,6,vehicle_type) vehicle_type,
         |      length,
         |      vehicle_length,
         |      vehicle_full_load_weight,
         |      outer_length,
         |      outer_width,
         |      outer_height,
         |      inner_length,
         |      inner_width,
         |      inner_height,
         |      if(axis='' or axis is null,2,axis) axIs_number,
         |      weight,
         |      load_weight,
         |      full_load_weight,
         |      color,
         |      energy,
         |      license,
         |      emission,
         |      is_trailer,
         |      vehicle_type_ground,
         |      exception_axis,
         |      exception_weight,
         |      exception_length,
         |      exception_width,
         |      exception_height
         |    FROM
         |      dm_gis.gis_tm_vehicle
         |    WHERE
         |      inc_day >= '${carBeginDay}'
         |      and inc_day <= '${inc_day}'
         |  ) t
         |where
         |  t.num = 1
       """.stripMargin
    val timerEndDay= DateTimeUtil.getDaysApartDate("yyyyMMdd", inc_day, 3)
    val timerSql =
      s"""
         |select
         |  actual_miles as log_dist,
         |  concat(dept_code, task_id) as task_id
         |from
         |  ods_shiva_ground.tt_drivinglog_data
         |where
         |  inc_day >= '${beginDayBefore}'
         |  and inc_day <= '${endDayAfter}'
         |  and task_id != '0'
         |  and actual_miles is not null
         |  and actual_miles != 0
       """.stripMargin



    val task_info = spark.sql(taskSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val car_info = spark.sql(carSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val timer_info = spark.sql(timerSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val taskColList = task_info.columns
    val carColList = car_info.columns
    val timerList = timer_info.columns
    val taskInfoRdd = task_info.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- taskColList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).map(x => {
      val vehicle_serial = x.getString("vehicle_serial")
      (vehicle_serial,x)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取taskInfo数据，数据量为:" + taskInfoRdd.count())
    taskInfoRdd.take(2).foreach(println(_))

    //获取车辆信息数据
    val carInfoRdd = car_info.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- carColList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).map(x => {
      val vehicle_serial = x.getString("vehicle_serial")
      (vehicle_serial,x)
    })
      //数据去重
      .reduceByKey((obj1,obj2)=>{
      getAxisVehicle(obj1,obj2)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取carInfoRdd数据，数据量为:" + carInfoRdd.count())
    carInfoRdd.take(2).foreach(println(_))

    //获取码表数据
    val timerInfoRdd = timer_info.rdd.map(x => {
      val jo = new JSONObject()
      for (columns <- timerList) {
        jo.put(columns,x.getAs[String](columns))
      }
      jo
    }).map(x => {
      val task_id = x.getString("task_id")
      (task_id,x)
    }).reduceByKey((obj1,obj2)=>obj1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取timerInfoRdd数据，数据量为:" + timerInfoRdd.count())
    timerInfoRdd.take(2).foreach(println(_))


    //数据表连接
    val getJoinData = getJoinRdd(taskInfoRdd,carInfoRdd)
    logger.error("输出总数据量：" + getJoinData.count())
    val getTimerJoinData = getTimerJoin(getJoinData.map(x => {
      val task_id = x.getString("task_id")
      (task_id,x)
    }),timerInfoRdd)
    logger.error("获取getTimerJoinData数据，数据量为:" + getTimerJoinData.count())
    getTimerJoinData.take(2).foreach(println(_))

//    val log_dist_rdd = getTimerJoinData.filter(x => {
//      val log_dist = x.getString("log_dist")
//      StringUtils.nonEmpty(log_dist)
//    })
//    logger.error("log_dist_rdd的数据量为：" + log_dist_rdd.count())

    logger.error("存储中间表0")
    saveMiddleTable0(spark,getTimerJoinData,inc_day)

    getTimerJoinData

  }

  case class middleTable0(
                           task_id:String,
                           start_dept:String,
                           end_dept:String,
                           start_type:String,
                           end_type:String,
                           start_tm:String,
                           end_tm:String,
                           actual_run_time:String,
                           plan_run_time:String,
                           sort_num:String,
                           start_longitude:String,
                           end_longitude:String,
                           start_latitude:String,
                           end_latitude:String,
                           start_address:String,
                           end_address:String,
                           line_code:String,
                           line_id:String,
                           task_area_code:String,
                           vehicle_serial:String,
                           conveyance_type:String,
                           transoport_level:String,
                           id:String,
                           inc_day_carInfo:String,
                           is_stop:String,
                           ground_task_id:String,
                           vehicle_type:String,
                           axIs_number:String,
                           start_time:String,
                           typical_tag:String,
                           carrier_type:String,
                           plf_flag:String,
                           log_dist:String,
                           driver_name:String,
                           trans_car:String,
                           carrier_name:String,
                           cvy_name:String,
                           line_distance:String
                         )
  def saveMiddleTable0(spark: SparkSession, getTimerJoinData: RDD[JSONObject],inc_day:String) = {

    val table0Rdd =getTimerJoinData.map(x => {
      val axIs_number = JSONUtils.getJsonValueInt(x,"axIs_number",2).toString
      val end_longitude = x.getString("end_longitude")
      val ground_task_id = x.getString("ground_task_id")
      val num = x.getString("num")
      val load_weight = x.getString("load_weight")
      val start_tm = x.getString("start_tm")
      val source = x.getString("source")
      val trailer_vehicle_code = x.getString("trailer_vehicle_code")
      val hko_vehicle_code = x.getString("hko_vehicle_code")
      val tolls = x.getString("tolls")
      val emission = x.getString("emission")
      val vehicle_serial = x.getString("vehicle_serial")
      val exception_length = x.getString("exception_length")
      val min_route_y = x.getString("min_route_y")
      val id = x.getString("id")
      val inner_length = x.getString("inner_length")
      val min_route_x = x.getString("min_route_x")
      val tag = x.getString("tag")
      val energy = x.getString("energy")
      val vehicle_length = x.getString("vehicle_length")
      val weight = x.getString("weight")
      val outer_height = x.getString("outer_height")
      val inner_height = x.getString("inner_height")
      val start_time = x.getString("start_time")
      val license = x.getString("license")
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val actual_run_time = x.getString("actual_run_time")
      val end_address = x.getString("end_address").replaceAll("(\0|\\s*|\r|\n|\t)", "")
      val outer_length = x.getString("outer_length")
      val end_type = x.getString("end_type")
      val color = x.getString("color")
      val max_route_y = x.getString("max_route_y")
      val max_route_x = x.getString("max_route_x")
      val task_id = x.getString("task_id")
      val end_tm = x.getString("end_tm")
      val start_type = x.getString("start_type")
      val end_latitude = x.getString("end_latitude")
      val exception_width = x.getString("exception_width")
      val line_id = x.getString("line_id")
      val is_trailer = x.getString("is_trailer")
      val plan_run_time = x.getString("plan_run_time")
      val start_latitude = x.getString("start_latitude")
      val exception_axis = x.getString("exception_axis")
      val vehicle_type_ground = x.getString("vehicle_type_ground")
      val full_load_weight = x.getString("full_load_weight")
      val conveyance_type = x.getString("conveyance_type")
      val inner_width = x.getString("inner_width")
      val task_area_code = x.getString("task_area_code")
      val length = x.getString("length")
      val vehicle_type = JSONUtils.getJsonValueInt(x,"vehicle_type",6).toString
      val attr7 = x.getString("attr7")
      val is_stop = x.getString("is_stop")
      val exception_weight = x.getString("exception_weight")
      val start_longitude = x.getString("start_longitude")
      val transoport_level = x.getString("transoport_level")
      val inc_day_carInfo = x.getString("inc_day_carInfo")
      val outer_width = x.getString("outer_width")
      val sort_num = x.getString("sort_num")
      val start_address = x.getString("start_address").replaceAll("(\0|\\s*|\r|\n|\t)", "")
      val inc_day = x.getString("inc_day")
      val typical_tag = JSONUtils.getJsonValue(x,"typical_tag","")
      val end_dept = x.getString("end_dept")
      val exception_height = x.getString("exception_height")
      val vehicle_full_load_weight = x.getString("vehicle_full_load_weight")
      val carrier_type = x.getString("carrier_type")
      val plf_flag = x.getString("plf_flag")
      val log_dist = x.getString("log_dist")

      //20210629新增字段
      val driver_name = x.getString("driver_name")
      val trans_car = x.getString("trans_car")
      val carrier_name = x.getString("carrier_name")
      val cvy_name = x.getString("cvy_name")
      val line_distance = x.getString("line_distance")


      middleTable0(task_id,start_dept,end_dept,start_type,end_type,start_tm,end_tm,actual_run_time,plan_run_time,
        sort_num,start_longitude,end_longitude,start_latitude,end_latitude,start_address,end_address,line_code,line_id,
        task_area_code,vehicle_serial,conveyance_type,transoport_level,id,inc_day_carInfo,is_stop,ground_task_id,vehicle_type,
        axIs_number,start_time,typical_tag,carrier_type,plf_flag,log_dist,driver_name,trans_car,carrier_name,cvy_name,line_distance)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    import spark.implicits._
    table0Rdd.toDF().withColumn("inc_day",lit(inc_day)).repartition(200).write.mode(SaveMode.Overwrite).insertInto("dm_gis.eta_grd_middle0")
    logger.error("输入中间表0 dm_gis.eta_grd_middle0的数据量为：" + table0Rdd.count())
  }



  def getJoinRdd(taskInfoRdd: RDD[(String, JSONObject)], carInfoRdd: RDD[(String, JSONObject)]):RDD[JSONObject] = {

    val joinRdd = taskInfoRdd.leftOuterJoin(carInfoRdd).map(x => {
      val left = x._2._1
      val rightOp = x._2._2

      if(rightOp.nonEmpty){
        left.fluentPutAll(rightOp.get)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    joinRdd
  }

  def addDailyFreq(groupSimRdd: RDD[JSONObject]) = {
   val histroyTrajRdd = groupSimRdd.map(x => {
      val start_time = x.getString("start_time")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val sim_group = x.getString("sim_group")
      val vehicle_type = x.getString("vehicle_type")
      val axIs_number = x.getString("axIs_number")
      ((start_time,start_dept,end_dept,sim_group,vehicle_type,axIs_number),x)
    }).groupByKey().flatMap(x => {
      val list = x._2.toList
      val daily_freq = list.size
      val listNew = list.toStream.map(x => {
        x.put("daily_freq",daily_freq)
        x
      })
     listNew
    })
    histroyTrajRdd
  }

}
