package app.StandardRouteMileage

import java.util.Calendar
import java.util.concurrent.atomic.AtomicInteger

import Utils._
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.eta.constant.StandardRouteMileage.DistanceTool
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

object DistTimeIndexMonitor {

  @transient lazy val logger: Logger = Logger.getLogger(DistTimeIndexMonitor.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  val logger: Logger = Logger.getLogger(appName)


  val descMysqlUserName = "gis_oms_pns"
  val descMysqlPassWord = "gis_oms_pns@123@"
  val descMysqlUrl = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?characterEncoding=utf-8"


  case class res_table1(
                          task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,
                          start_type:String,end_type:String,line_code:String,vehicle_serial:String,actual_capacity_load:String,plan_depart_tm:String,
                          actual_depart_tm:String,plan_arrive_tm:String,actual_arrive_tm:String,driver_id:String,driver_name:String,line_time:String,
                          line_distance:String,actual_run_time:String,start_longitude:String,start_latitude:String,end_longitude:String,
                          end_latitude:String,is_stop:String,transoport_level:String,carrier_type:String,plf_flag:String,vehicle_type:String,
                          axls_number:String,log_dist:String,task_inc_day:String,start_time:String,if_evaluate_time:String,is_run_ontime:String,
                          carrier_name:String,stop_over_zone_code:String,biz_type:String,require_category:String,to_ground:String
                         )

  case class res_table2(
                         task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,line_code:String,
                         vehicle_serial:String,actual_capacity_load:String,vehicle_type:String,start_longitude:String,start_latitude:String,end_longitude:String,
                         end_latitude:String,rt_coords:String,x1:String,y1:String,x2:String,y2:String,duration:String,time:String,tl_time:String,rt_dist:String,
                         highwaymileage:String,toll_charge:String,start_distance:String,end_distance:String,error_type:String,err_log:String,task_inc_day:String,
                         start_time:String,halfway_integrate_rate:String
                       )


  case class res_table3(
                         task_area_code:String,line_code:String,start_dept:String,end_dept:String,start_time:String,actual_capacity_load:String,
                         pns_dist:String,pns_time:String,src:String,std_coords:String,line_distance_std:String,line_time_std:String,err_log:String,task_subid:String,
                         std_id:String,std_x1:String,std_y1:String,std_x2:String,std_y2:String,std_toll_charge:String,inc_day:String
                       )


  case class res_table4(
                         task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,line_code:String,
                         vehicle_serial:String,actual_capacity_load:String,vehicle_type:String,sim1:String,sim5:String,task_inc_day:String,
                         route_source:String,pns_dist:String,pns_time:String,src:String,std_coords:String,line_distance_std:String,line_time_std:String,
                         std_x1:String,std_y1:String,std_x2:String,std_y2:String,std_toll_charge:String,std_id:String
                       )


  case class res_table5(
                        task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,line_code:String,
                        sim1:String,sim5:String,rt_dist:String,line_distance:String,log_dist:String,pns_dist:String,if_dist_equal:String,diffdist_rt_line:String,
                        diffratio_rt_line:String,diffdist_rt_std:String,diffratio_rt_std:String,diffdist_rt_log:String,diffratio_rt_log:String,
                        diffdist_line_log:String,diffratio_line_log:String,diffdist_line_std:String,diffratio_line_std:String,diffdist_log_std:String,
                        diffratio_log_std:String,conduct_type:String,line_time:String,pns_time:String,tl_time:String,if_time_equal:String,difftime_line_std:String,
                        diffratio1_line_std:String,difftime_line_std_10min:String,difftime_line_rt:String,diffratio1_line_rt:String,difftime_rt_gh_10min:String,
                        difftime_std_rt:String,diffratio1_std_rt:String,difftime_std_rt_10min:String,is_run_ontime_std:String,
                        is_run_ontime:String,pns_error:String,task_inc_day:String,
                        actual_run_time:Double,x1:Double,y1:Double,x2:Double,y2:Double,std_x1:Double,std_y1:Double,std_x2:Double,std_y2:Double,start_distance_std:Double,end_distance_std:Double,std_line_error:Int,
                        ac_difftime_line_rt:Double,ac_diffratio1_line_rt:Double,ac_difftime_rt_gh_10min:Double,ac_difftime_std_rt:Double,ac_diffratio1_std_rt:Double,ac_difftime_std_rt_10min:Double,ac_is_run_ontime_std:Double,ac_is_run_ontime:Double

                       )

  case class res_table6(
                       task_area_code:String,task_id:String,sort_num:String,task_subid:String,start_dept:String,end_dept:String,start_type:String,end_type:String,
                       line_code:String,vehicle_serial:String,actual_capacity_load:String,plan_depart_tm:String,actual_depart_tm:String,plan_arrive_tm:String,
                       actual_arrive_tm:String,driver_id:String,driver_name:String,line_time:String,line_distance:String,actual_run_time:String,start_longitude:String,
                       start_latitude:String,end_longitude:String,end_latitude:String,is_stop:String,transoport_level:String,carrier_type:String,plf_flag:String,
                       vehicle_type:String,axls_number:String,log_dist:String,rt_coords:String,x1:String,y1:String,x2:String,y2:String,duration:String,time:String,
                       rt_dist:String,highwaymileage:String,toll_charge:String,start_distance:String,end_distance:String,error_type:String,pns_dist:String,pns_time:String,
                       src:String,std_coords:String,line_distance_std:String,line_time_std:String,sim1:String,sim5:String,diffdist_rt_line:String,diffratio_rt_line:String,
                       diffdist_rt_std:String,diffratio_rt_std:String,diffdist_rt_log:String,diffratio_rt_log:String,diffdist_line_log:String,diffratio_line_log:String,
                       diffdist_line_std:String,diffratio_line_std:String,diffdist_log_std:String,diffratio_log_std:String,conduct_type:String,difftime_line_std:String,
                       diffratio1_line_std:String,difftime_line_std_10min:String,difftime_line_rt:String,diffratio1_line_rt:String,difftime_rt_gh_10min:String,
                       is_run_ontime_std:String,is_run_ontime:String,if_dist_equal:String,if_time_equal:String,pns_error:String,task_inc_day:String,difftime_std_rt:String,diffratio1_std_rt:String,difftime_std_rt_10min:String,
                       tl_time:String,halfway_integrate_rate:String,std_x1:String,std_y1:String,std_x2:String,std_y2:String,start_distance_std:String,end_distance_std:String,
                       std_line_error:String,ac_difftime_line_rt:String,ac_diffratio1_line_rt:String,ac_difftime_rt_gh_10min:String,ac_difftime_std_rt:String,
                       ac_diffratio1_std_rt:String,ac_difftime_std_rt_10min:String,ac_is_run_ontime_std:String,ac_is_run_ontime:String,if_evaluate_time:String,
                       carrier_name:String,stop_over_zone_code:String,biz_type:String,require_category:String,to_ground:String,std_toll_charge:String,std_id:String
                     )


  case class res_table7(
                         task_area_code:String,task_id:String,carrier_name:String,task_inc_day:String,start_dept:String,start_type:String,line_code:String,
                         vehicle_serial:String,actual_capacity_load:String,plan_depart_tm:String,actual_depart_tm:String,driver_id:String,driver_name:String,
                         is_stop:String,transoport_level:String,carrier_type:String,plf_flag:String,vehicle_type:String,axls_number:String,log_dist:String,
                         if_evaluate_time:String,stop_over_zone_code:String,end_dept:String,end_type:String,plan_arrive_tm:String,actual_arrive_tm:String,
                         line_time:String,line_distance:String,actual_run_time:String,duration:String,time:String,rt_dist:String,highwaymileage:String,
                         toll_charge:String,pns_dist:String,pns_time:String,std_toll_charge:String,if_error:String,src:String,conduct_type:String,
                         ac_is_run_ontime:String,diffdist_log_rt:String,diffratio_log_rt:String
                       )

  case class res_table8(
                         task_id:String,sort_num:String,task_area_code:String,line_code:String,start_dept:String,start_dept_site_id:String,
                         end_dept:String,end_dept_site_id:String,start_type:String,end_type:String,plan_depart_tm:String,actual_depart_tm:String,
                         plan_arrive_tm:String,actual_arrive_tm:String,line_time:String,line_distance:String,actual_run_time:String,start_longitude:String,
                         start_latitude:String,end_longitude:String,end_latitude:String,require_category:String,stop_over_zone_code:String,vehicle_serial:String,
                         driver_id:String,driver_name:String,actual_capacity_load:String,capacity_load:String,transoport_level:String,to_ground:String,
                         biz_type:String,carrier_name:String,is_stop:String,carrier_type:String,plf_flag:String,state:String,last_update_tm:String,
                         full_load_weight:String,votes_l:String,votes_lw:String,votes_s:String,votes_n:String,votes_d:String,votes_w:String,votes_sp:String,
                         votes_dp:String,votes_pw:String,contnr_code:String
                       )

  def main(args: Array[String]): Unit = {

    //val inc_day =args(0)
    val inc_day =args(0)


//    val jo3 = new JSONObject()
//    jo3.put("start_dept","020DE")
//    jo3.put("end_dept","769XG")
//    jo3.put("start_time","1620")
//    jo3.put("line_code","028AAQ028R1600")
//    jo3.put("actual_capacity_load","1.5")

//    val json = schedulerStaInterface(jo3)
//    println(json)
//    val jo1 = new JSONObject()
//    jo1.put("vehicle_serial","浙BX2672")
//    jo1.put("actual_depart_tm","2021-11-19 12:37:00")
//    jo1.put("actual_arrive_tm","2021-11-19 12:49:00")
//
//
//    val vehicle_serial = jo1.getString("vehicle_serial")
//
//    // TODO: actual_depart_tm 往前取5min，转成yyyyMMddhhmmss格式
//    val actual_depart_tm = jo1.getString("actual_depart_tm")
//    val beginDateTime = try {
//      DateTimeUtil.getMinBeforeAfter(actual_depart_tm, "yyyy-MM-dd HH:mm:ss", -5)
//    } catch {
//      case e: Exception => "2000-01-01 00:00:00"
//    }
//    val beginDateTimeNew = try {
//      DateTimeUtil.transformDateFormat(beginDateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
//    } catch {
//      case e: Exception => "20000101000000"
//    }
//
//
//    // TODO:中间表1的actual_arrive_tm 往后取5min，转成yyyyMMddhhmmss格式
//    val actual_arrive_tm = jo1.getString("actual_arrive_tm")
//    val endDateTime = try {
//      DateTimeUtil.getMinBeforeAfter(actual_arrive_tm, "yyyy-MM-dd HH:mm:ss", 5)
//    } catch {
//      case e: Exception => "2000-01-01 00:00:00"
//    }
//    val endDateTimeNew = try {
//      DateTimeUtil.transformDateFormat(endDateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
//    } catch {
//      case e: Exception => "20000101000000"
//    }
//
//
//    val jo = new JSONObject()
//    jo.put("un", "浙BX2672")
//    jo.put("type", 0)
//    jo.put("beginDateTime", beginDateTimeNew)
//    jo.put("endDateTime", endDateTimeNew)
//    jo.put("ak", "e640de2b47394b19862ee134d817bbc7")
//    jo.put("stayDuration", 180)
//    jo.put("stayRadius", 500)
//    jo.put("addpoint", 1)
//
//
//    println(jo.toJSONString)
//    val repJson = schedulerHisTrackInterface(jo1, jo)
//    println(repJson.toJSONString)


    start(inc_day)

  }


  /** @note   调用历史轨迹接口*/
  private def parseTrajRectify(json:JSONObject,rep:String):JSONObject = {

    //val historyTrajUrl ="http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int.int.sfdc.com.cn:1080/lsssearch/api/poshisPeriod&ak=cfe3bf126cf649ff8de8be49e9bded27&appCode=8e296a067a37563370ded05f5a3bf3ec&usrNum=%s&startDate=%s&endDate=%s"

    val repJo = JSON.parseObject(rep)
    val result = repJo.getJSONObject("result")
    val data = result.getJSONObject("data")
    val rt_coords = data.getJSONArray("track")
    val rt_dist = data.getDouble("len")
    val time = data.getIntValue("roadTime")

    val highwaymileage = JSONUtils.getJsonValueInt(data.getJSONObject("rc_distance"),"0",0)
    val toll_charge = data.getDouble("tollCharge")

    val maxLen = rt_coords.size()-1

    val x1 = rt_coords.getJSONObject(0).getDoubleValue("zx")
    val y1 = rt_coords.getJSONObject(0).getDoubleValue("zy")

    val x2 = rt_coords.getJSONObject(maxLen).getDoubleValue("zx")
    val y2 = rt_coords.getJSONObject(maxLen).getDoubleValue("zy")

    val stayPoints = data.getJSONArray("stayPoints")
    var duration = 0.0

    for (i <- (0 until(stayPoints.size()))){
       duration += JSONUtils.getJsonValueDouble(stayPoints.getJSONObject(i),"duration",0)
    }

    val tl_time = time - duration

    val start_latitude = JSONUtils.getJsonValueDouble(json,"start_latitude",0)
    val start_longitude = JSONUtils.getJsonValueDouble(json,"start_longitude",0)
    val end_latitude = JSONUtils.getJsonValueDouble(json,"end_latitude",0)
    val end_longitude = JSONUtils.getJsonValueDouble(json,"end_longitude",0)


    val start_distance = DistanceTool.getGreatCircleDistance(x1,y1,start_longitude,start_latitude)
    val end_distance = DistanceTool.getGreatCircleDistance(x2,y2,end_longitude,end_latitude)


    val jo = new JSONObject()
    jo.put("rt_coords",rt_coords)
    jo.put("x1",x1)
    jo.put("y1",y1)
    jo.put("x2",x2)
    jo.put("y2",y2)
    jo.put("duration",duration)
    jo.put("time",time)
    jo.put("tl_time",tl_time)
    jo.put("rt_dist",rt_dist)
    jo.put("highwaymileage",highwaymileage)
    jo.put("toll_charge",toll_charge)
    jo.put("start_distance",start_distance)
    jo.put("end_distance",end_distance)
//    jo.put("error_type",error_type)
    jo.fluentPutAll(json)
    jo
  }


  def getSourceTable1(spark: SparkSession, inc_day: String) = {

    val begin_day_before3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-2)
    val begin_day_before7 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-7)

    val begin_day_before4 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

    val hisTaskSql =
      s"""
         |SELECT
         |  bb.*,concat(bb.task_id,bb.sort_num) task_subid
         |from
         |  (
         |    select
         |      aa.task_id, -- 任务id,
         |      aa.driver_id, -- 司机id,
         |      aa.driver_name, -- 司机姓名,
         |      aa.actual_capacity_load, -- 实际运力载量（指派的车辆吨位）,
         |      lag(aa.actual_pass_zone_code, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_dept,  -- 始发网点,
         |      aa.actual_pass_zone_code as end_dept, -- 目的网点,
         |      lag(aa.start_time, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_time, -- 计划发车时间hhmm,
         |      lag(aa.field_bak08, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_type, -- 始发网点类型,
         |      aa.field_bak08 as end_type, -- 目的网点类型,
         |      lag(aa.actual_depart_tm, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as actual_depart_tm, -- 实际发车时间,
         |      aa.actual_arrive_tm actual_arrive_tm, -- 实际到车时间,
         |      lag(aa.actual_run_time, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) actual_run_time, -- 实际运行时长,
         |      lag(aa.plan_run_time, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) line_time, -- 规划时长,
         |      lag(aa.line_distance, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) line_distance, -- 规划里程,
         |      lag(aa.sort_num, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as sort_num, -- 线路顺序,
         |      lag(aa.longitude, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_longitude, -- 起点经度,
         |      aa.longitude end_longitude, -- 终点经度,
         |      lag(aa.latitude, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) as start_latitude, -- 起点纬度,
         |      aa.latitude end_latitude, -- 终点纬度,
         |      lag(aa.line_code, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) line_code, -- 线路编码,
         |      lag(aa.task_area_code, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) task_area_code, -- 大区编码,
         |      lag(aa.vehicle_serial, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) vehicle_serial, -- 车牌,
         |      lag(aa.transoport_level, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) transoport_level, -- 运输等级,
         |      lag(aa.inc_day, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) task_inc_day, -- 任务日期,
         |      lag(aa.is_stop, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) is_stop, -- 是否经停,
         |      lag(aa.carrier_type, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) carrier_type, -- 承运商类型,
         |      lag(aa.plf_flag, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) plf_flag, -- 是否平台车主,
         |      lag(aa.plan_depart_tm, 1) over(
         |        PARTITION BY aa.task_id
         |        order by
         |          aa.sort_num
         |      ) plan_depart_tm, -- 计划发车时间,
         |      aa.plan_arrive_tm,
         |      aa.is_run_ontime,
         |      aa.carrier_name,
         |      aa.stop_over_zone_code,
         |      aa.biz_type,
         |      aa.require_category,
         |      aa.to_ground
         |    from
         |      (
         |        SELECT
         |          a.task_id,
         |          -- a.actual_capacity_load,
         |          if(a.actual_capacity_load='0.0',a.capacity_load,a.actual_capacity_load) as actual_capacity_load,
         |          b.actual_pass_zone_code,
         |          b.actual_depart_tm,
         |          b.actual_arrive_tm,
         |          regexp_replace(substring(b.plan_depart_tm, 12, 5), ':', '') as start_time,
         |          b.plan_depart_tm,
         |          b.plan_arrive_tm,
         |          b.actual_run_time,
         |          b.plan_run_time,
         |          b.line_distance,
         |          b.sort_num,
         |          c.longitude,
         |          c.latitude,
         |          c.field_bak08,
         |          a.ground_task_id,
         |          a.line_code,
         |          a.task_area_code,
         |          a.vehicle_serial,
         |          a.conveyance_type,
         |          a.transoport_level,
         |          a.id,
         |          a.inc_day,
         |          a.is_stop,
         |          a.carrier_type,
         |          a.plf_flag,
         |          a.driver_id,
         |          a.driver_name,
         |          a.is_run_ontime,
         |          a.carrier_name,
         |          a.stop_over_zone_code,
         |          a.biz_type,
         |          a.require_category,
         |          a.to_ground
         |        from
         |          (
         |            select
         |              *
         |            from
         |              dm_grd.grd_new_task_detail
         |            where
         |              inc_day >= '${begin_day_before3}'
         |              and inc_day <= '${inc_day}'
         |              and conveyance_type = 5
         |              and state = 6
         |              -- and task_area_code in ('020Y','755Y','021Y','025Y','531Y','311Y','316Y','351Y','411Y','028Y','010Y')
         |              and task_area_code is not null
         |              -- and carrier_type = 0
         |              and substr(task_area_code, 1, 1) in ('0','1','2','3','4','5','6','7','8','9','K')
         |              and task_area_code not in ('852Y', '853Y', '886Y')
         |          ) a
         |          INNER join (
         |            SELECT
         |              row_number() over(
         |                PARTITION by task_id,dept_site_id
         |                ORDER by
         |                  last_update_tm desc
         |              ) as rn,
         |              *
         |            from
         |              ods_russtask.tt_vehicle_task_pass_zone_monitor
         |            where
         |              inc_day >= '${begin_day_before3}'
         |            and
         |              inc_day <= '${inc_day}'
         |          ) b on a.task_id = b.task_id
         |          and b.rn = 1
         |          left outer join (
         |            select
         |              *
         |            from
         |              ods_shiva_ground.tt_driver_task_detail
         |            where
         |              inc_day >= '${begin_day_before3}'
         |          ) c on a.ground_task_id = c.driver_task_id
         |          AND a.task_area_code = c.own_dept_code
         |          and b.actual_pass_zone_code = c.dept_code
         |          and b.sort_num = c.thru_seq_code
         |        order by
         |          a.task_id,
         |          b.sort_num
         |      ) aa
         |  ) bb
         |WHERE
         |  bb.start_dept != ''
         |  AND bb.end_dept != ''
         |  and bb.start_dept != bb.end_dept
       """.stripMargin

//    val hisTaskSql =
//      s"""
//         |SELECT
//         |  task_id,
//         |  sort_num,
//         |  task_area_code,
//         |  line_code,
//         |  start_dept,
//         |  start_dept_site_id,
//         |  end_dept,
//         |  end_dept_site_id,
//         |  start_type,
//         |  end_type,
//         |  plan_depart_tm,
//         |  actual_depart_tm,
//         |  plan_arrive_tm,
//         |  actual_arrive_tm,
//         |  line_time,
//         |  line_distance,
//         |  actual_run_time,
//         |  start_longitude,
//         |  start_latitude,
//         |  end_longitude,
//         |  end_latitude,
//         |  require_category,
//         |  stop_over_zone_code,
//         |  vehicle_serial,
//         |  driver_id,
//         |  driver_name,
//         |  if(actual_capacity_load='0.0',capacity_load,actual_capacity_load) as actual_capacity_load,
//         |  transoport_level,
//         |  to_ground,
//         |  biz_type,
//         |  carrier_name,
//         |  is_stop,
//         |  carrier_type,
//         |  plf_flag,
//         |  regexp_replace(substring(plan_depart_tm, 12, 5), ':', '') as start_time,
//         |  regexp_replace(substring(plan_depart_tm, 1, 11), '-', '') as task_inc_day
//         |FROM
//         |  dm_gis.eta_std_line_task_parse
//         |where inc_day = '${inc_day}'
//         |and state = '6'
//         |and substr(task_area_code, 1, 1) in ('0','1','2','3','4','5','6','7','8','9','K')
//         |and task_area_code  not in ('852Y', '853Y', '886Y')
//       """.stripMargin


    val carInfoSql =
      s"""
         |select
         |  *
         |from
         |  (
         |    SELECT
         |      row_number() over(
         |        partition by regexp_replace(vehicle, '[\r\n\0,\\\\s,\\\\.*。、,]+', '')
         |        order by
         |          source,case
         |            when vehicle_type = 4 then 1
         |            when vehicle_type = 8 then 2
         |            when vehicle_type = 7 then 3
         |            when vehicle_type = 6 then 4
         |            when vehicle_type = 5 then 5
         |            else 6
         |          end,
         |	      inc_day,
         |          vehicle_length + 0 desc
         |      ) num,
         |      regexp_replace(vehicle, '[\r\n\0,\\\\s, \\\\.*。、,]+', '') vehicle_serial,
         |      hko_vehicle_code,
         |      trailer_vehicle_code,
         |      source,
         |      if (vehicle_type = "" or vehicle_type is null,"6",vehicle_type) vehicle_type,
         |      length,
         |      vehicle_length,
         |      vehicle_full_load_weight,
         |      outer_length,
         |      outer_width,
         |      outer_height,
         |      inner_length,
         |      inner_width,
         |      inner_height,
         |      if (axis = "" or axis is null,"2",axis) axls_number,
         |      weight,
         |      load_weight,
         |      full_load_weight,
         |      color,
         |      energy,
         |      license,
         |      emission,
         |      is_trailer,
         |      vehicle_type_ground,
         |      exception_axis,
         |      exception_weight,
         |      exception_length,
         |      exception_width,
         |      exception_height,
         |      inc_day
         |    FROM
         |      dm_gis.gis_tm_vehicle
         |    WHERE
         |      inc_day >= '${begin_day_before7}'
         |  ) t
         |where
         |  t.num = 1
       """.stripMargin



    val timeInfoSql =
      s"""
         |select
         |    log_dist,task_id
         |from
         |(
         |select
         |   log_dist,task_id,
         |   row_number() over(partition by task_id order by log_dist desc) rn
         |from
         |(
         |select
         |  actual_miles as log_dist,
         |  concat(dept_code, task_id) as task_id
         |from
         |  ods_shiva_ground.tt_drivinglog_data
         |where
         |  inc_day >= '${begin_day_before4}'
         |  and inc_day <= '${inc_day}'
         |  and task_id != '0'
         |  and actual_miles is not null
         |  and actual_miles != 0
         |) a
         |) aa
         |where aa.rn = 1
       """.stripMargin

    val hisTaskInfoDf = spark.sql(hisTaskSql)
    val midTable1Rdd = SparkUtils.getRowToJson(hisTaskInfoDf,"DISK_ONLY")
    logger.error("midTable1Rdd的数据量为：" + midTable1Rdd.count())
    midTable1Rdd.take(2).foreach(println(_))

    val carInfoSqlDf = spark.sql(carInfoSql)
    val midTable2Rdd = SparkUtils.getRowToJson(carInfoSqlDf,"DISK_ONLY")
    logger.error("midTable2Rdd的数据量为：" + midTable2Rdd.count())
    midTable2Rdd.take(2).foreach(println(_))

    val timeInfoSqlDf = spark.sql(timeInfoSql)
    val midTable3Rdd = SparkUtils.getRowToJson(timeInfoSqlDf,"DISK_ONLY")

    logger.error("midTable3Rdd的数据量为：" + midTable3Rdd.count())
    midTable3Rdd.take(2).foreach(println(_))

    val midTable2RddJoin = midTable2Rdd.map(x => {
      val vehicle_serial = x.getString("vehicle_serial")
      (vehicle_serial,x)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    midTable2Rdd.unpersist()

    val midTable3RddJoin = midTable3Rdd.map(obj => {
      val task_id = obj.getString("task_id")
      (task_id, obj)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    midTable3Rdd.unpersist()

    val joinRdd1 = midTable1Rdd.map(x => {
      val vehicle_serial = x.getString("vehicle_serial")
      (vehicle_serial,x)
    }).leftOuterJoin(midTable2RddJoin).map(x => {

      val left = x._2._1
      val rightOption = x._2._2

      if(rightOption.nonEmpty){
        val vehicle_type = rightOption.get.getString("vehicle_type")
        val axls_number = rightOption.get.getString("axls_number")
        left.put("vehicle_type",vehicle_type)
        left.put("axls_number",axls_number)
      }
      left
    })

    val joinRdd2 = joinRdd1.map(x => {
      val task_id = x.getString("task_id")
      (task_id,x)
    }).leftOuterJoin(midTable3RddJoin).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      if(rightOption.nonEmpty){
        val log_dist = rightOption.get.getString("log_dist")
        left.put("log_dist",log_dist)
      }
      left
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    midTable2RddJoin.unpersist()
    midTable3RddJoin.unpersist()

    (midTable1Rdd,joinRdd2)

  }


  def getVehicleTypeProcess(actual_capacity_load_new: Double) = {

    val vehicle_type = actual_capacity_load_new match {
      case actual_capacity_load_new if (actual_capacity_load_new == 0) => 6
      case actual_capacity_load_new if (actual_capacity_load_new <= 1) => 5
      case actual_capacity_load_new if (actual_capacity_load_new > 1 && actual_capacity_load_new <= 3) => 6
      case actual_capacity_load_new if (actual_capacity_load_new > 3 && actual_capacity_load_new < 7) => 7
      case actual_capacity_load_new if (actual_capacity_load_new >= 7) => 8
    }

    vehicle_type

  }

  def saveTable1(spark: SparkSession, inc_day: String, sourceTable1Rdd: RDD[JSONObject]) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_task"
    logger.error("当前inc_day为：" + inc_day)
    logger.error("正在写入结果表1")

//    /**
//      * 删除中间表1，60天前数据
//      */
//    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-60)
//    val dropSql =
//      s"""
//         |alter table ${saveTableName} drop if exists partition (inc_day='${dropDate}')
//       """.stripMargin
//    logger.error("删除中间表1的45天前数据" + dropSql)
//    spark.sql(dropSql)



    val res =  sourceTable1Rdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")

      val task_subid = task_id + sort_num

      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val start_type= x.getString("start_type")
      val end_type= x.getString("end_type")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val plan_depart_tm= x.getString("plan_depart_tm")
      val actual_depart_tm= x.getString("actual_depart_tm")
      val plan_arrive_tm= x.getString("plan_arrive_tm")
      val actual_arrive_tm= x.getString("actual_arrive_tm")
      val driver_id= x.getString("driver_id")
      val driver_name= x.getString("driver_name")
      val line_time= x.getString("line_time")
      val line_distance= x.getString("line_distance")

      val actual_run_time = try {DateTimeUtil.parseFtTime(actual_depart_tm,actual_arrive_tm,"yyyy-MM-dd HH:mm:ss")} catch {case e:Exception => 0}
      val start_longitude= x.getString("start_longitude")
      val start_latitude= x.getString("start_latitude")
      val end_longitude= x.getString("end_longitude")
      val end_latitude= x.getString("end_latitude")
      val is_stop= x.getString("is_stop")
      val transoport_level= x.getString("transoport_level")
      val carrier_type= x.getString("carrier_type")
      val plf_flag= x.getString("plf_flag")
      //val vehicle_type= x.getString("vehicle_type")
      val actual_capacity_load_new = JSONUtils.getJsonValueDouble(x,"actual_capacity_load",0)
      val vehicle_type = getVehicleTypeProcess(actual_capacity_load_new).toString
      val axls_number= x.getString("axls_number")

      val log_dist=  if (line_code.dropRight(4) != (start_dept + end_dept))  ""  else x.getString("log_dist")
      val task_inc_day = x.getString("task_inc_day")
      val start_time = x.getString("start_time")

      //20211011新增if_evaluate_time
      val is_run_ontime = JSONUtils.getJsonValueInt(x,"is_run_ontime",0)
      val if_evaluate_time = if (is_run_ontime == -1) "0" else "1"

      val carrier_name = x.getString("carrier_name")
      val stop_over_zone_code = x.getString("stop_over_zone_code")

      val biz_type = x.getString("biz_type")
      val require_category = x.getString("require_category")
      val to_ground = x.getString("to_ground")


      res_table1(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,start_type,end_type,
        line_code,vehicle_serial,actual_capacity_load,plan_depart_tm,actual_depart_tm,
        plan_arrive_tm,actual_arrive_tm,driver_id,driver_name,line_time,line_distance,
        actual_run_time.toString,start_longitude,start_latitude,end_longitude,end_latitude,is_stop,
        transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,log_dist,task_inc_day,start_time,if_evaluate_time,is_run_ontime.toString,
        carrier_name,stop_over_zone_code,biz_type,require_category,to_ground)
    })
      .repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表1写入完成")

  }

  // TODO: 组内取实际发车时间早的一条记录
  def getMaxDepartTm(obj1: JSONObject, obj2: JSONObject): _root_.com.alibaba.fastjson.JSONObject = {

    val actual_depart_tm1 = obj1.getString("actual_depart_tm")
    val actual_depart_tm2 = obj2.getString("actual_depart_tm")

    if (StringUtils.nonEmpty(actual_depart_tm1) && StringUtils.nonEmpty(actual_depart_tm1) && actual_depart_tm1 > actual_depart_tm2){
      obj1
    } else {
      obj2
    }
  }

  def distinctMidTable1(midTable1Rdd:RDD[JSONObject],inc_day:String) = {

//    val getSourceSql =
//      s"""
//         |select
//         |  *
//         |from
//         |  dm_gis.eta_std_line_rectify
//         |where
//         |  inc_day = '${inc_day}'
//       """.stripMargin
//
//    val sourceDf = spark.sql(getSourceSql)
//    val midTable1Rdd = SparkUtils.getRowToJson(sourceDf,"MEMORY_AND_DISK")
//    logger.error("读取结果表1的数据量为：" + midTable1Rdd.count())

    // TODO: 将中间表1按始发网点、目的网点、线路编码、发车时间、实际运力载量去重，组内取实际发车时间早的一条。然后查询标准线路。
    val distinctMidTable =  midTable1Rdd.filter(x => {
      val task_inc_day = x.getString("task_inc_day")
      task_inc_day.equals(inc_day)
    }).map(x => {
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val line_code = x.getString("line_code")
      val start_time = x.getString("start_time")
      val actual_capacity_load = x.getString("actual_capacity_load")

      val actual_depart_tm = x.getString("actual_depart_tm")

      ((start_dept,end_dept,line_code,start_time,actual_capacity_load),x)
    }).reduceByKey((obj1,obj2) => getMaxDepartTm(obj1,obj2)).map(_._2)

    distinctMidTable

  }

  def parseStaLineRep(sourceJson:JSONObject,response: String)= {

    val jo = new JSONObject()

    val task_area_code = sourceJson.getString("task_area_code")
    val line_code = sourceJson.getString("line_code")
    val start_dept = sourceJson.getString("start_dept")
    val end_dept = sourceJson.getString("end_dept")
    val start_time = sourceJson.getString("start_time")
    val actual_capacity_load = sourceJson.getString("actual_capacity_load").replaceAll("T","")
    val vehicle_serial = sourceJson.getString("vehicle_serial")
    val vehicle_type = sourceJson.getString("vehicle_type")
    val task_inc_day = sourceJson.getString("task_inc_day")

    jo.fluentPutAll(sourceJson)
    jo.put("task_area_code",task_area_code)
    jo.put("line_code",line_code)
    jo.put("start_dept",start_dept)
    jo.put("end_dept",end_dept)
    jo.put("start_time",start_time)
    jo.put("actual_capacity_load",actual_capacity_load)
    jo.put("vehicle_serial",vehicle_serial)
    jo.put("vehicle_type",vehicle_type)
    jo.put("task_inc_day",task_inc_day)

    try{
        val resp = JSON.parseObject(response)
        val result = resp.getJSONObject("result")
        val pns_dist = result.getString("pnsDist")
        val pns_time = result.getString("pnsTime")
        val src = result.getString("src")
        val std_coords = result.getString("coords")
        val line_distance_std = result.getString("dist")
        val line_time_std = result.getString("time")

        //20211011增加统计字段
        val std_id = result.getString("stdId")
        val coords = result.getJSONArray("coords")
        val std_x1 = coords.getJSONArray(0).getDouble(0)
        val std_y1 = coords.getJSONArray(0).getDouble(1)

        val maxIndex = if (coords.size() != 0) ( coords.size() -1 ) else 0

        val std_x2 = coords.getJSONArray(maxIndex).getDouble(0)
        val std_y2 = coords.getJSONArray(maxIndex).getDouble(1)

        //20211118增加统计字段std_toll_charge
        val std_toll_charge = result.getString("tolls")

        jo.put("pns_dist",pns_dist)
        jo.put("pns_time",pns_time)
        jo.put("src",src)
        jo.put("std_coords",std_coords)
        jo.put("line_distance_std",line_distance_std)
        jo.put("line_time_std",line_time_std)

        jo.put("std_id",std_id)
        jo.put("std_x1",std_x1)
        jo.put("std_y1",std_y1)
        jo.put("std_x2",std_x2)
        jo.put("std_y2",std_y2)
        jo.put("std_toll_charge",std_toll_charge)

    } catch {
      case e:Exception => jo.put("err",e)
    }
    jo
  }

  def schedulerStaInterface(x: JSONObject) = {

        val url = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/query"
        val jo = new JSONObject()

        val start_dept = x.getString("start_dept")
        val end_dept = x.getString("end_dept")
        val line_code = x.getString("line_code")
        val start_time = x.getString("start_time")

        val actual_capacity_load = try {
          x.getString("actual_capacity_load").replaceAll("T", "")
        } catch {
          case e: Exception => ""
        }

        jo.put("ak", "4dc00a88a1f34bffa49a153103458efc")
        jo.put("opt", "std2")
        jo.put("compensateTime", 1)
        jo.put("srcZoneCode", start_dept)
        jo.put("destZoneCode", end_dept)
        jo.put("lineCode", line_code)
        jo.put("planTime", start_time)
        jo.put("mLoad", actual_capacity_load)

        //val response = Utils.post(url, jo, "utf-8")
        val response = Utils.retryPost(url, jo)

        var repJson = new JSONObject()

        repJson = try {
          parseStaLineRep(x, response)
        } catch {
          case e: Exception =>
            x.put("err", e)
            x
        }
        repJson

  }

  def getStandardLine(distinctMidTableRdd: RDD[JSONObject]) = {

    val limitMin = 4000

    val processStandardRdd = distinctMidTableRdd.mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 100
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }

        schedulerStaInterface(x)
        //val url = "http://gis-int.int.sfdc.com.cn:1080/etaStdLine/query"

      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    processStandardRdd

  }

  def saveTable2(spark: SparkSession, inc_day: String, standardLineRdd: RDD[JSONObject]) = {

    import spark.implicits._
    val saveTableName = "dm_gis.eta_std_line_rectify"
    logger.error("当前inc_day为：" + inc_day)
    logger.error("正在写入结果表2")
//    /**
//      * 删除结果表2，60天前数据
//      */
//    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-60)
//    val dropSql =
//      s"""
//         |alter table ${saveTableName} drop if exists partition (inc_day='${dropDate}')
//       """.stripMargin
//    logger.error("删除中间表1的45天前数据" + dropSql)
//    spark.sql(dropSql)


    val res = standardLineRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")
      val task_subid= x.getString("task_subid")
      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val vehicle_type= x.getString("vehicle_type")
      val start_longitude= x.getString("start_longitude")
      val start_latitude= x.getString("start_latitude")
      val end_longitude= x.getString("end_longitude")
      val end_latitude= x.getString("end_latitude")
      val rt_coords= x.getString("rt_coords")
      val x1= x.getString("x1")
      val y1= x.getString("y1")
      val x2= x.getString("x2")
      val y2= x.getString("y2")
      val duration= x.getString("duration")
      val time= x.getString("time")
      val tl_time= x.getString("tl_time")
      val rt_dist= x.getString("rt_dist")
      val highwaymileage= x.getString("highwaymileage")
      val toll_charge= x.getString("toll_charge")
      val start_distance= x.getString("start_distance")
      val end_distance= x.getString("end_distance")
      val error_type= x.getString("error_type")
      val err_log = x.getString("err")
      val task_inc_day = x.getString("task_inc_day")
      val start_time = x.getString("start_time")

      //20211011新增halfway_integrate_rate
      val halfway_integrate_rate = x.getString("halfway_integrate_rate")

      res_table2(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,line_code,vehicle_serial,actual_capacity_load,
        vehicle_type,start_longitude,start_latitude,end_longitude,end_latitude,rt_coords,x1,y1,x2,y2,
        duration,time,tl_time,rt_dist,highwaymileage,toll_charge,start_distance,end_distance,error_type,err_log,task_inc_day,start_time,halfway_integrate_rate)
    })
      .repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)
    logger.error("结果表2写入完成")
  }



  def saveTable3(spark: SparkSession, inc_day: String, standardLineRdd: RDD[JSONObject]) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_route"
    logger.error("当前inc_day为：" + inc_day)
    logger.error("正在写入结果表3")
//    /**
//      * 删除中间表1，60天前数据
//      */
//    val dropDate = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-60)
//    val dropSql =
//      s"""
//         |alter table ${saveTableName} drop if exists partition (inc_day='${dropDate}')
//       """.stripMargin
//    logger.error("删除结果表3的45天前数据" + dropSql)
//    spark.sql(dropSql)


    val res = standardLineRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val line_code= x.getString("line_code")
      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val start_time= x.getString("start_time")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val pns_dist= x.getString("pns_dist")
      val pns_time= x.getString("pns_time")
      val src= x.getString("src")
      val std_coords= x.getString("std_coords")
      val line_distance_std= x.getString("line_distance_std")
      val line_time_std= x.getString("line_time_std")
      val err_log = x.getString("err")
      val task_subid = x.getString("task_subid")

      //20211011新增字段

      val std_id = x.getString("std_id")
      val std_x1 = x.getString("std_x1")
      val std_y1 = x.getString("std_y1")
      val std_x2 = x.getString("std_x2")
      val std_y2 = x.getString("std_y2")

      val std_toll_charge = x.getString("std_toll_charge")

      res_table3(task_area_code,line_code,start_dept,end_dept,start_time,actual_capacity_load,
        pns_dist,pns_time,src,std_coords,line_distance_std,line_time_std,err_log,task_subid,std_id,std_x1,std_y1,std_x2,std_y2,std_toll_charge,inc_day)
    })
      .repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)
    logger.error("结果表3写入完成")
  }

  def getRes1table(spark: SparkSession, inc_day: String) = {

    val sourceSql  =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_task
         |where
         |  inc_day='${inc_day}'
         |--  and
         |--  task_id in ('222Y11936937','511W022X2350')
       """.stripMargin

    val df = spark.sql(sourceSql)
    val res1Rdd = SparkUtils.getRowToJson(df,"MemoryAndDisk")
    res1Rdd.take(2).foreach(println(_))

    res1Rdd

  }

  def getParseTrackRate(response: String) = {

    val res = JSON.parseObject(response)
    val result = res.getJSONObject("result")
    val data = result.getJSONObject("data")
    val stopData = data.getJSONArray("stopData").getJSONObject(0)

    val realDis = JSONUtils.getJsonValueDouble(stopData,"realDis",0)
    val virDis = JSONUtils.getJsonValueDouble(stopData,"virDis",0)
    val halfway_integrate_rate = if (virDis != 0) realDis / virDis  else 0
    halfway_integrate_rate
  }

  def schedulerTrackRateInterface(x: JSONObject, jo:JSONObject) = {

    val json = new JSONObject()
    val stopListJson = new JSONObject()
    val stopList = new JSONArray()

    val task_id = x.getString("task_id")
    val vehicle_serial = x.getString("vehicle_serial")

    val actual_depart_tm = x.getString("actual_depart_tm")
    val beginDateTime = jo.getString("beginDateTime")
    val endDateTime = jo.getString("endDateTime")
    val start_dept = x.getString("start_dept")
    val end_dept = x.getString("end_dept")
    val x1 = x.getString("x1")
    val y1 = x.getString("y1")
    val x2 = x.getString("x2")
    val y2 = x.getString("y2")

    stopListJson.put("actual_depart_tm",actual_depart_tm)
    stopListJson.put("beginDateTime",beginDateTime)
    stopListJson.put("endDateTime",endDateTime)
    stopListJson.put("beginDeptCode",start_dept)
    stopListJson.put("endDeptCode",end_dept)
    stopListJson.put("beginLon",x1)
    stopListJson.put("beginLat",y1)
    stopListJson.put("endLon",x2)
    stopListJson.put("endLat",y2)
    stopListJson.put("index",1)

    stopList.add(stopListJson)

    json.put("ak","e640de2b47394b19862ee134d817bbc7")
    json.put("taskId",task_id)
    json.put("un",vehicle_serial)
    json.put("type",0)
    json.put("timeThreshold",300)
    json.put("disThreshold",5000)
    json.put("stopList",stopList)

    //val url = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/query/rate/trackRate"
    val url = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/rate/trackRate"
    var halfway_integrate_rate = 0.0
    var retryCnt = 0

    val response = Utils.retryPost(url,json)
//    halfway_integrate_rate = try{getParseTrackRate(response)} catch {case e:Exception => 0}


//    while (halfway_integrate_rate == 0 && retryCnt < 3){
//      val response = Utils.post(url,json,"utf-8")
//      halfway_integrate_rate = try{getParseTrackRate(response)} catch {case e:Exception => 0}
//      retryCnt += 1
//    }
    halfway_integrate_rate = try{getParseTrackRate(response)} catch {case e:Exception => 0}

    halfway_integrate_rate

  }

  def schedulerHisTrackInterface(x: JSONObject, jo: JSONObject) = {

    val url = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com//trackquery/api/integrateDetail"

    var rt_coords = ""

    //val repJson = new JSONObject()
    val rep = Utils.retryPost(url, jo)

    val repJson =
      try {
        parseTrajRectify(x, rep)
      } catch {
        case e: Exception =>
          val errJo = new JSONObject()
          errJo.put("err", e + "接口异常返回为：" + rep)
          errJo
      }
    //    var repJson = new JSONObject()
    //    var retryCnt = 0
    //
    //    while (StringUtils.isEmpty(rt_coords)  && retryCnt < 3){
    //      val rep = Utils.post(url, jo, "utf-8")
    //       try {
    //         repJson = parseTrajRectify(x, rep)
    //      } catch {
    //        case e: Exception =>
    //          val errJo = new JSONObject()
    //          errJo.put("err", e)
    //          errJo
    //      }
    //      rt_coords =  repJson.getString("rt_coords")
    //      retryCnt += 1
    //    }

    repJson

  }

  def getErrorType(x: JSONObject) = {

    val rt_coords = x.getJSONArray("rt_coords")
    val start_distance = JSONUtils.getJsonValueDouble(x,"start_distance",0)
    val end_distance = JSONUtils.getJsonValueDouble(x,"end_distance",0)
    val halfway_integrate_rate = JSONUtils.getJsonValueDouble(x,"halfway_integrate_rate",0)

    //  轨迹异常标记字段【error_type】：
    //    符合多个条件时，组合标识，中间用“|”分隔，条件如下：
    //    ①纠偏轨迹点 rt_coords为空时：	error_type = 1
    //    ②轨迹起点与任务起点距离start_distance>500m：  error_type = 2
    //    ③轨迹终点与任务终点距离end_distance>500m:   error_type = 3
    //    均不符合时，error_type = 0

    val error_type = new StringBuilder

    if ( rt_coords.isEmpty || rt_coords.size() == 0 ){
      if(error_type.isEmpty){
        error_type.append("1")
      }else{
        error_type.append("|").append("1")
      }
    }

    if (start_distance > 500){
      if(error_type.isEmpty){
        error_type.append("2")
      }else{
        error_type.append("|").append("2")
      }
    }

    if (end_distance > 500){
      if(error_type.isEmpty){
        error_type.append("3")
      }else{
        error_type.append("|").append("3")
      }
    }


    if (halfway_integrate_rate < 0.9) {
      if(error_type.isEmpty){
        error_type.append("4")
      } else {
        error_type.append("|").append("4")
      }
    }


    if (error_type.isEmpty) error_type.append("0")

    error_type.toString()

  }

  def processGjRectify(getRes1Rdd: RDD[JSONObject]) = {

    val limitMin = 2000

    val gjRectifyRdd = getRes1Rdd.mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 100
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }

        val vehicle_serial = x.getString("vehicle_serial")

        // TODO: actual_depart_tm 往前取5min，转成yyyyMMddhhmmss格式
        val actual_depart_tm = x.getString("actual_depart_tm")
        val beginDateTime = try {
          DateTimeUtil.getMinBeforeAfter(actual_depart_tm, "yyyy-MM-dd HH:mm:ss", -5)
        } catch {
          case e: Exception => "2000-01-01 00:00:00"
        }
        val beginDateTimeNew = try {
          DateTimeUtil.transformDateFormat(beginDateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
        } catch {
          case e: Exception => "20000101000000"
        }


        // TODO:中间表1的actual_arrive_tm 往后取5min，转成yyyyMMddhhmmss格式
        val actual_arrive_tm = x.getString("actual_arrive_tm")
        val endDateTime = try {
          DateTimeUtil.getMinBeforeAfter(actual_arrive_tm, "yyyy-MM-dd HH:mm:ss", 5)
        } catch {
          case e: Exception => "2000-01-01 00:00:00"
        }
        val endDateTimeNew = try {
          DateTimeUtil.transformDateFormat(endDateTime, "yyyy-MM-dd HH:mm:ss", "yyyyMMddHHmmss")
        } catch {
          case e: Exception => "20000101000000"
        }


        val jo = new JSONObject()
        jo.put("un", vehicle_serial)
        jo.put("type", 0)
        jo.put("beginDateTime", beginDateTimeNew)
        jo.put("endDateTime", endDateTimeNew)
        jo.put("ak", "e640de2b47394b19862ee134d817bbc7")
//        jo.put("stayDuration", 180)
//        jo.put("stayRadius", 500)
        jo.put("addpoint", 1)

        val repJson = schedulerHisTrackInterface(x, jo)

        //20211011新增halfway_integrate_rate统计
        val halfway_integrate_rate = schedulerTrackRateInterface(repJson, jo).formatted("%.2f")
        x.put("halfway_integrate_rate", halfway_integrate_rate)
        x.fluentPutAll(repJson)

        //计算err_type
        val errType = try {getErrorType(x) } catch {case e :Exception => "0"}
        x.put("error_type",errType)

        x
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("gjRectifyRdd的数据量为：" + gjRectifyRdd.count())
    gjRectifyRdd.take(2).foreach(println(_))

    gjRectifyRdd

  }


  def getSourceSim(spark: SparkSession, inc_day: String) = {

    val inc_day_pre3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

//    val rectifySql =
//      s"""
//         |select
//         |  *
//         |from
//         |  dm_gis.eta_std_line_rectify
//         |where
//         |  inc_day = '${inc_day}'
//       """.stripMargin
//
//    val routeSql =
//      s"""
//         |select
//         |  *
//         |from
//         |  dm_gis.eta_std_line_route
//         |where
//         |  inc_day >= '${inc_day_pre3}'
//         |and
//         |  inc_day <= '${inc_day}'
//       """.stripMargin
//    val df1 = spark.sql(rectifySql)
//    val rectifyRdd = SparkUtils.getRowToJson(df1,"MEMORY_AND_DISK").map(x => {
//      val task_inc_day = x.getString("task_inc_day")
//      val start_dept = x.getString("start_dept")
//      val end_dept = x.getString("end_dept")
//      val line_code = x.getString("line_code")
//      val actual_capacity_load = x.getString("actual_capacity_load")
//      ((task_inc_day,start_dept,end_dept,line_code,actual_capacity_load),x)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//
//
//    val df2 = spark.sql(routeSql)
//    val routeRdd = SparkUtils.getRowToJson(df2,"MEMORY_AND_DISK").map(x => {
//      val inc_day = x.getString("inc_day")
//      val start_dept = x.getString("start_dept")
//      val end_dept = x.getString("end_dept")
//      val line_code = x.getString("line_code")
//      val actual_capacity_load = x.getString("actual_capacity_load")
//      ((inc_day,start_dept,end_dept,line_code,actual_capacity_load),x)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//
//    rectifyRdd.leftOuterJoin(routeRdd).map(x => {
//
//      val left = x._2._1
//      val rightOption = x._2._2
//
//    })

    val source1Sql =
      s"""
         |select
         |    a.task_id,a.sort_num,a.task_subid,a.start_dept,a.end_dept,a.line_code,a.vehicle_serial,
         |    a.actual_capacity_load,a.vehicle_type,a.rt_coords,b.std_coords,a.start_time start_time,
         |    if(b.pns_dist ='' or b.pns_dist is null,1,0) flag,a.task_inc_day task_inc_day,pns_dist,pns_time,src,line_distance_std,std_x1,std_y1,std_x2,std_y2,line_time_std,std_id
         |from
         |(
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_rectify
         |where
         |  inc_day = '${inc_day}'
         | -- and
         | -- line_code='028AAQ028R1600'
         |) a
         |left outer join
         |(
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_route
         |where
         |  inc_day >= '${inc_day_pre3}'
         |and
         |  inc_day <= '${inc_day}'
         | -- and
         |  -- line_code ='028AAQ028R1600'
         |) b
         |on a.task_inc_day = b.inc_day
         |and
         |    a.start_dept = b.start_dept
         |and
         |    a.end_dept = b.end_dept
         |and
         |    a.line_code = b.line_code
         |and
         |    a.actual_capacity_load= b.actual_capacity_load
         |and
         |    a.start_time = b.start_time
       """.stripMargin


    val df = spark.sql(source1Sql)
    val sourceRdd = SparkUtils.getRowToJson(df,"MEMORYANDDISK")

    //没有关联到标准线路的任务结果表3，先调标准线路接口获取线路
    val sourceRdd1 = sourceRdd.filter(_.getIntValue("flag") == 1)
    logger.error("未关联到结果表3的数据为：" + sourceRdd1.count())

    //调接口计算相似度
    val sourceRdd2 = sourceRdd.filter(_.getIntValue("flag") == 0)
    logger.error("关联到结果表3的数据为：" + sourceRdd2.count())

    (sourceRdd2,sourceRdd1)

  }

  def getSimProcess(sourceSimilarRdd1: RDD[JSONObject], sourceSimilarRdd2: RDD[JSONObject]) = {

    // 连接上调接口计算相似度
    val limitMin = 6000
    val sim1Rdd = sourceSimilarRdd1.mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 100
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }
        val rt_coords = x.getString("rt_coords")
        val std_coords = x.getString("std_coords")
        val vehicle_type = x.getString("vehicle_type")

        if (StringUtils.nonEmpty(rt_coords) && StringUtils.nonEmpty(std_coords)) {

          val joArray1 = new JSONArray()
          val array1 = JSON.parseArray(rt_coords)

          for (i <- 0 until (array1.size())) {
            val json = array1.getJSONObject(i)
            val x = json.getDouble("dx")
            val y = json.getDouble("dy")
            val arrayNew = new JSONArray()
            arrayNew.add(x)
            arrayNew.add(y)
            joArray1.add(arrayNew)
          }

          val jo1 = new JSONObject()
          val jo2 = new JSONObject()

          jo1.put("rt_coords", joArray1)
          jo1.put("vehicle_type", vehicle_type)
          jo2.put("rt_coords", std_coords)

          val (sim1, sim5) = getSimilarInterface2.getSimilar2(jo1, jo2)
          x.put("jo1", jo1)
          x.put("jo2", jo2)
          x.put("sim1", sim1)
          x.put("sim5", sim5)
        }
        x
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    //    //调接口计算相似度
    //    val sim1Rdd = sourceSimilarRdd1.map(x => {
    //
    //      val rt_coords = x.getString("rt_coords")
    //      val std_coords = x.getString("std_coords")
    //      val vehicle_type = x.getString("vehicle_type")
    //
    //      if (StringUtils.nonEmpty(rt_coords) && StringUtils.nonEmpty(std_coords)){
    //
    //        val joArray1 = new JSONArray()
    //        val array1 = JSON.parseArray(rt_coords)
    //
    //        for(i <- 0 until(array1.size())){
    //          val json = array1.getJSONObject(i)
    //          val x = json.getDouble("dx")
    //          val y = json.getDouble("dy")
    //          val arrayNew = new JSONArray()
    //          arrayNew.add(x)
    //          arrayNew.add(y)
    //          joArray1.add(arrayNew)
    //        }
    //
    //        val jo1 = new JSONObject()
    //        val jo2 = new JSONObject()
    //
    //        jo1.put("rt_coords",joArray1)
    //        jo1.put("vehicle_type",vehicle_type)
    //        jo2.put("rt_coords",std_coords)
    //
    //        val (sim1,sim5) = getSimilarInterface2.getSimilar2(jo1,jo2)
    //        x.put("jo1",jo1)
    //        x.put("jo2",jo2)
    //        x.put("sim1",sim1)
    //        x.put("sim5",sim5)
    //      }
    //
    //      x
    //    })


    val sim2RddPre = sourceSimilarRdd2.mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 100
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }

        //未连接上，调标准线路接口获取线路（调一遍标准线路接口），再调相似度接口
        val resJson = schedulerStaInterface(x)
        resJson
      })
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("sim2RddPre的数据量为：" + sim2RddPre.count())


//    val sim2RddPre = sourceSimilarRdd2.map(x => {
//      val resJson = schedulerStaInterface(x)
//      resJson
//    })
//    logger.error("sim2RddPre的数据量为：" + sim2RddPre.count())
//    sim2RddPre.take(2).foreach(println(_))

    //调接口计算相似度
    val sim2Rdd = sim2RddPre.mapPartitionsWithIndex((index, iter) => {

      val partitionLimitMinu = limitMin * 0.9 / 100
      val lastMin = new AtomicInteger(Calendar.getInstance().get(Calendar.MINUTE))
      val timeInt = new AtomicInteger(0)
      val partitionsCount = new AtomicInteger(0)

      iter.map(x => {
        if (partitionsCount.incrementAndGet() % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin.get()) {
          if (timeInt.incrementAndGet() >= partitionLimitMinu) {
            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount.get())
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          //不能精细控制，set存在并发问题
          timeInt.set(1)
          lastMin.set(cur)
        }

        val rt_coords = x.getString("rt_coords")
        val std_coords = x.getString("std_coords")
        val vehicle_type = x.getString("vehicle_type")


        if (StringUtils.nonEmpty(rt_coords) && StringUtils.nonEmpty(std_coords)) {
          val joArray1 = new JSONArray()
          val array1 = JSON.parseArray(rt_coords)
          for (i <- 0 until (array1.size())) {
            val json = array1.getJSONObject(i)
            val x = json.getDouble("dx")
            val y = json.getDouble("dy")
            val arrayNew = new JSONArray()
            arrayNew.add(x)
            arrayNew.add(y)
            joArray1.add(arrayNew)
          }

          val jo1 = new JSONObject()
          val jo2 = new JSONObject()
          jo1.put("rt_coords", joArray1)
          jo1.put("vehicle_type", vehicle_type)
          jo2.put("rt_coords", std_coords)
          val (sim1, sim5) = getSimilarInterface2.getSimilar2(jo1, jo2)
          x.put("sim1", sim1)
          x.put("sim5", sim5)
          x.put("jo1", jo1)
          x.put("jo2", jo2)

        }
        x
      })
    })

    //sim2RddPre.take(2).foreach(println(_))
    //    logger.error("sim2RddPre的数据量为：" + sim2RddPre.count())
    //    sim2RddPre.take(2).foreach(println(_))

    //    val sim2Rdd = sim2RddPre.map(x => {
    //      val rt_coords = x.getString("rt_coords")
    //      val std_coords = x.getString("std_coords")
    //      val vehicle_type = x.getString("vehicle_type")
    //
    //
    //      if (StringUtils.nonEmpty(rt_coords) && StringUtils.nonEmpty(std_coords)) {
    //        val joArray1 = new JSONArray()
    //        val array1 = JSON.parseArray(rt_coords)
    //        for (i <- 0 until (array1.size())) {
    //          val json = array1.getJSONObject(i)
    //          val x = json.getDouble("dx")
    //          val y = json.getDouble("dy")
    //          val arrayNew = new JSONArray()
    //          arrayNew.add(x)
    //          arrayNew.add(y)
    //          joArray1.add(arrayNew)
    //        }
    //
    //        val jo1 = new JSONObject()
    //        val jo2 = new JSONObject()
    //        jo1.put("rt_coords", joArray1)
    //        jo1.put("vehicle_type",vehicle_type)
    //        jo2.put("rt_coords", std_coords)
    //        val (sim1, sim5) = getSimilarInterface2.getSimilar2(jo1, jo2)
    //        x.put("sim1", sim1)
    //        x.put("sim5", sim5)
    //        x.put("jo1",jo1)
    //        x.put("jo2",jo2)
    //
    //      }
    //      x
    //    })

    val simRdd = sim1Rdd.union(sim2Rdd)

    simRdd
  }

  def saveTable4(spark: SparkSession, inc_day: String, getSimRdd: RDD[JSONObject]) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_similarity"
    logger.error("正在写入结果表4")
    val res = getSimRdd.map(x => {

      val task_id = x.getString("task_id")
      val sort_num = x.getString("sort_num")
      val task_subid = x.getString("task_subid")
      val start_dept = x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val vehicle_type= x.getString("vehicle_type")
      val sim1= x.getString("sim1")
      val sim5= x.getString("sim5")
      val task_inc_day = x.getString("task_inc_day")

      //20211011新增字段
      val route_source = x.getString("flag")
      val pns_dist = x.getString("pns_dist")
      val pns_time = x.getString("pns_time")
      val src = x.getString("src")
      val std_coords = x.getString("std_coords")
      val line_distance_std = x.getString("line_distance_std")
      val line_time_std = x.getString("line_time_std")
      val std_x1 = x.getString("std_x1")
      val std_y1 = x.getString("std_y1")
      val std_x2 = x.getString("std_x2")
      val std_y2 = x.getString("std_y2")

      val std_toll_charge = x.getString("std_toll_charge")
      val std_id = x.getString("std_id")

      res_table4(task_id,sort_num,task_subid,start_dept,end_dept,line_code,vehicle_serial,actual_capacity_load,vehicle_type,sim1,sim5,task_inc_day,
        route_source,pns_dist,pns_time,src,std_coords,line_distance_std,line_time_std,std_x1,std_y1,std_x2,std_y2,std_toll_charge,std_id)
    })
    //val frame = spark.createDataFrame(res)
      .toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表4写入完成")
  }

  def getComputeSource(spark: SparkSession, inc_day: String) = {

    val inc_day_pre3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

    val sourceSql =
      s"""
         |
         |select
         |  a.task_area_code,a.task_id,a.sort_num,a.task_subid,a.start_dept,a.end_dept,
         |  a.line_code,sim1,sim5,rt_dist,b.tl_time,pns_dist,pns_time,a.actual_capacity_load,
         |  a.task_inc_day,a.log_dist,a.line_distance,a.line_time,x1,y1,x2,y2,std_x1,std_y1,std_x2,std_y2,actual_run_time
         |from
         |  (
         |    select
         |      task_area_code,
         |      task_id,
         |      sort_num,
         |      task_subid,
         |      start_dept,
         |      end_dept,
         |      line_code,
         |      line_distance,
         |      log_dist,
         |      line_time,
         |      task_inc_day,
         |      actual_capacity_load,
         |      actual_run_time,
         |      start_time
         |    from
         |      dm_gis.eta_std_line_task
         |    where
         |      inc_day = '${inc_day}'
         |  ) a
         |  left outer join (
         |    select
         |      rt_dist,
         |      tl_time,
         |      task_subid,
         |      x1,y1,x2,y2
         |    from
         |      dm_gis.eta_std_line_rectify
         |    where
         |      inc_day = '${inc_day}'
         |  ) b on a.task_subid = b.task_subid
         |  left outer join (
         |    select
         |      pns_dist,
         |      -- pns_time,
         |      inc_day,
         |      start_dept,
         |      end_dept,
         |      line_code,
         |      actual_capacity_load,
         |      start_time
         |    from
         |      dm_gis.eta_std_line_route
         |    where
         |      inc_day >= '${inc_day_pre3}'
         |      and inc_day <= '${inc_day}'
         |  ) c on a.task_inc_day = c.inc_day
         |  and a.start_dept = c.start_dept
         |  and a.end_dept = c.end_dept
         |  and a.line_code = c.line_code
         |  and a.actual_capacity_load = c.actual_capacity_load
         |  and a.start_time = c.start_time
         |  left outer join (
         |    select
         |      sim1,
         |      sim5,
         |      task_subid,
         |      std_x1,std_y1,std_x2,std_y2,pns_time
         |    from
         |      dm_gis.eta_std_line_similarity
         |    where
         |      inc_day = '${inc_day}'
         |  ) d on a.task_subid = d.task_subid
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf,"MEMORY_AND_DISK")
    logger.error("结果表5输入数据量为：" + sourceRdd.count())
    sourceRdd.take(2).foreach(println(_))

    sourceRdd

  }

  /**
    * 计算10分钟分割区间值
    * @param input
    */

  def calApart10Min(input: Double) = {
    var diff_time_10min = 0
    var addDiffTime = 0

    if (input > 0){
      val addDiffTimeCal = (input / 10).toInt
      val addDiffTimeCaladd = input - addDiffTimeCal * 10
      if (addDiffTimeCaladd > 0){
        addDiffTime = 10
      } else{
        addDiffTime = 0
      }
      diff_time_10min = addDiffTimeCal * 10 + addDiffTime
    }else{
      val addDiffTimeRtCal = (input / 10).toInt
      val addDiffTimeRtCaladd = input - addDiffTimeRtCal * 10
      if (addDiffTimeRtCaladd < 0){
        addDiffTime = -10
      } else{
        addDiffTime = 0
      }
      diff_time_10min = addDiffTimeRtCal * 10 + addDiffTime
    }

    diff_time_10min
  }

  def saveTable5(spark: SparkSession, inc_day: String, getComputeRdd: RDD[JSONObject]) = {

    import spark.implicits._
    val saveTableName = "dm_gis.eta_std_line_compute"
    logger.error("正在写入结果表5")
    val computeResRdd = getComputeRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")
      val task_subid= x.getString("task_subid")
      val start_dept= x.getString("start_dept")
      val end_dept= x.getString("end_dept")
      val line_code= x.getString("line_code")
      val sim1 = JSONUtils.getJsonValueDouble(x,"sim1",0)
      val sim5 = JSONUtils.getJsonValueDouble(x,"sim5",0)
      val rt_dist= JSONUtils.getJsonValueDouble(x,"rt_dist",0)
      val line_distance= JSONUtils.getJsonValueDouble(x,"line_distance",0)
      val log_dist= JSONUtils.getJsonValueDouble(x,"log_dist",0)
      val pns_dist= JSONUtils.getJsonValueDouble(x,"pns_dist",0)

      // TODO: 接口返回配置里程是否准确
      val if_dist_equal = if (Math.abs(line_distance - (pns_dist / 1000)) <= 1) 1 else 0
      // TODO: 实际里程与规划里程偏差(m)
      val diffdist_rt_line = rt_dist - (line_distance * 1000)
      // TODO: 实际里程与规划里程偏差率
      val diffratio_rt_line = if(line_distance != 0) diffdist_rt_line / (line_distance * 1000) else 0
      // TODO: 实际里程与标准线路里程偏差(m)
      val diffdist_rt_std = rt_dist - pns_dist
      // TODO: 实际里程与标准线路里程偏差率
      val diffratio_rt_std = if(pns_dist !=0) diffdist_rt_std / pns_dist else 0
      // TODO: 实际里程与码表里程偏差(m)
      val diffdist_rt_log = if (log_dist != 0) (rt_dist - log_dist) else 0
      // TODO: 实际里程与码表里程偏差率
      val diffratio_rt_log = if (log_dist != 0) diffdist_rt_log / log_dist else 0
      // TODO: 规划里程与码表里程偏差(m)
      val diffdist_line_log = if (log_dist != 0) line_distance - log_dist else 0
      // TODO: 规划里程与码表里程偏差率
      val diffratio_line_log = if (log_dist != 0) diffdist_line_log / log_dist else 0
      // TODO: 规划里程与标准线路里程偏差(m)
      val diffdist_line_std = line_distance - pns_dist
      // TODO: 规划里程与标准线路里程偏差率
      val diffratio_line_std = if (pns_dist != 0) diffdist_line_std / pns_dist else 0
      // TODO: 码表里程与标准线路里程偏差(m)
      val diffdist_log_std = if (log_dist != 0) log_dist - pns_dist else 0
      // TODO: 码表里程与标准线路里程偏差率
      val diffratio_log_std = if (log_dist != 0) diffdist_log_std / pns_dist else 0

      val conduct_type = line_distance match {
        case line_distance if (line_distance > 0 && line_distance <= 50 && Math.max(sim1,sim5) > 0.75 && Math.min(sim1,sim5) >= 0.7) => 1
        case line_distance if (line_distance > 50 && line_distance <= 100 && Math.max(sim1,sim5) > 0.8 && Math.min(sim1,sim5) >= 0.75) => 1
        case line_distance if (line_distance > 100 && line_distance <= 500 && Math.max(sim1,sim5) > 0.85 && Math.min(sim1,sim5) >= 0.8) => 1
        case line_distance if (line_distance > 500  && Math.max(sim1,sim5) > 0.9 && Math.min(sim1,sim5) >= 0.85) => 1
        case _ => 3
      }

      val line_time = JSONUtils.getJsonValueDouble(x,"line_time",0)
      val pns_time = JSONUtils.getJsonValueDouble(x,"pns_time",0)
      val tl_time = JSONUtils.getJsonValueDouble(x,"tl_time",0)

      // TODO: 接口返回配置时长是否准确
      val if_time_equal = if (Math.abs(line_time - pns_time/60) <=1) 1 else 0
      // TODO: 规划时长与标准线路时长偏差(s)
      val difftime_line_std = line_time * 60 - pns_time
      // TODO: 规划时长与标准线路时长偏差率
      val diffratio1_line_std = if(pns_time != 0) difftime_line_std / pns_time else 0
      // TODO: 规划时长与标准线路时长偏差区间
      val difftime_line_std_10min = calApart10Min(difftime_line_std/60)
      // TODO: 规划耗时与实际耗时(去停留)偏差
      val difftime_line_rt = line_time*60 - tl_time
      // TODO: 规划耗时与实际耗时(去停留)偏差率
      val diffratio1_line_rt = if (tl_time != 0) difftime_line_rt / tl_time else 0
      // TODO: 规划耗时与实际耗时偏差区间
      val difftime_rt_gh_10min = calApart10Min(difftime_line_rt/60)
      // TODO:  标准线路时长与实际耗时(去停留)偏差
      val difftime_std_rt = pns_time - tl_time
      // TODO:  标准线路时长与实际耗时(去停留)偏差率
      val diffratio1_std_rt = if(tl_time != 0 ) difftime_std_rt / tl_time else 0
      // TODO: 标准线路时长与实际耗时(去停留)偏差区间
      val difftime_std_rt_10min = calApart10Min(difftime_std_rt/60)
      // TODO: 是否准点(去停留)_std
      val is_run_ontime_std = if ( pns_time != 0 && ((tl_time/60 -1) < pns_time)) 1 else 0
      // TODO: 是否准点(去停留)
      val is_run_ontime = if (line_time != 0 && ((tl_time/60-1) < line_time)) 1 else 0
      // TODO: 接口返回异常情况
      val pns_error = if(if_dist_equal==0 && if_time_equal == 0) 0 else 1

      //20211011新增字段
      val x1 = JSONUtils.getJsonValueDouble(x,"x1",0)
      val y1 = JSONUtils.getJsonValueDouble(x,"y1",0)
      val x2 = JSONUtils.getJsonValueDouble(x,"x2",0)
      val y2 = JSONUtils.getJsonValueDouble(x,"y2",0)

      val std_x1 = JSONUtils.getJsonValueDouble(x,"std_x1",0)
      val std_y1 = JSONUtils.getJsonValueDouble(x,"std_y1",0)
      val std_x2 = JSONUtils.getJsonValueDouble(x,"std_x2",0)
      val std_y2 = JSONUtils.getJsonValueDouble(x,"std_y2",0)

      val start_distance_std = DistanceTool.getGreatCircleDistance(x1,y1,std_x1,std_y1)
      val end_distance_std = DistanceTool.getGreatCircleDistance(x2,y2,std_x2,std_y2)
      val std_line_error = if (start_distance_std > 500 || end_distance_std > 500) 1 else 0

      val actual_run_time = JSONUtils.getJsonValueDouble(x,"actual_run_time",0)

      val ac_difftime_line_rt = (line_time - actual_run_time) * 60
      val ac_diffratio1_line_rt = line_time / (actual_run_time * 60)
      val ac_difftime_rt_gh_10min = calApart10Min(difftime_line_rt / 60)
      val ac_difftime_std_rt = pns_time - actual_run_time * 60
      val ac_diffratio1_std_rt = difftime_std_rt / (actual_run_time * 60)
      val ac_difftime_std_rt_10min = calApart10Min(difftime_std_rt/60)
      val ac_is_run_ontime_std = if (actual_run_time -1 < pns_time ) 1 else 0
      val ac_is_run_ontime = if (actual_run_time-1<line_time ) 1 else 0
      //conduct_type

      val task_inc_day = x.getString("task_inc_day")

      res_table5(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,line_code,sim1.toString,sim5.toString,rt_dist.toString,
        line_distance.toString,log_dist.toString,pns_dist.toString,if_dist_equal.toString,diffdist_rt_line.toString,diffratio_rt_line.toString,
        diffdist_rt_std.toString,diffratio_rt_std.toString,diffdist_rt_log.toString,diffratio_rt_log.toString,diffdist_line_log.toString,
        diffratio_line_log.toString,diffdist_line_std.toString,diffratio_line_std.toString,diffdist_log_std.toString,diffratio_log_std.toString,
        conduct_type.toString,line_time.toString,pns_time.toString,tl_time.toString,if_time_equal.toString,difftime_line_std.toString,
        diffratio1_line_std.toString,difftime_line_std_10min.toString,difftime_line_rt.toString,diffratio1_line_rt.toString,
        difftime_rt_gh_10min.toString,difftime_std_rt.toString,diffratio1_std_rt.toString,difftime_std_rt_10min.toString,
        is_run_ontime_std.toString,is_run_ontime.toString,pns_error.toString,task_inc_day,
        actual_run_time,x1,y1,x2,y2,std_x1,std_y1,std_x2,std_y2,start_distance_std,end_distance_std,std_line_error,
        ac_difftime_line_rt,ac_diffratio1_line_rt,ac_difftime_rt_gh_10min,ac_difftime_std_rt,ac_diffratio1_std_rt,ac_difftime_std_rt_10min,ac_is_run_ontime_std,ac_is_run_ontime
      )
    })
      .repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)
    logger.error("结果表5写入完成")
  }

  def getJoin1to5(spark: SparkSession, inc_day: String) = {

    val inc_day_pre3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",inc_day,-3)

      val joinSql =
        s"""
           |
           |select
           |  *
           |from
           |  (
           |    select
           |      task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,line_code,vehicle_serial,actual_capacity_load,plan_depart_tm,
           |      actual_depart_tm,plan_arrive_tm,actual_arrive_tm,driver_id,driver_name,line_time,line_distance,actual_run_time,start_longitude,
           |      start_latitude,end_longitude,end_latitude,is_stop,transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,
           |      log_dist,task_inc_day,start_type,end_type,if_evaluate_time,carrier_name,stop_over_zone_code,biz_type,require_category,to_ground,start_time
           |    from
           |      dm_gis.eta_std_line_task
           |    where
           |      inc_day = '${inc_day}'
           |  ) a
           |  left outer join (
           |    select
           |      x1,y1,x2,y2,duration,time,rt_dist,highwaymileage,toll_charge,start_distance,end_distance,error_type,task_subid,rt_coords,halfway_integrate_rate,tl_time
           |    from
           |      dm_gis.eta_std_line_rectify
           |    where
           |      inc_day = '${inc_day}'
           |  ) b on a.task_subid = b.task_subid
           |  left outer join
           |    (
           |    select
           |        inc_day inc_day_t3,start_dept start_dept_t3,end_dept end_dept_t3,line_code line_code_t3,actual_capacity_load actual_capacity_load_t3,start_time
           |    from
           |        dm_gis.eta_std_line_route
           |    where
           |        inc_day >='${inc_day_pre3}'
           |    and
           |        inc_day <= '${inc_day}'
           |    ) c
           |on  a.task_inc_day = c.inc_day_t3
           |and a.start_dept = c.start_dept_t3
           |and a.end_dept = c.end_dept_t3
           |and a.line_code = c.line_code_t3
           |and a.actual_capacity_load = c.actual_capacity_load_t3
           |and a.start_time = c.start_time
           |left outer join
           |    (
           |    select
           |        sim1,sim5,task_subid,std_x1,std_y1,std_x2,std_y2,line_distance_std,line_time_std,src,std_coords,pns_dist,pns_time,std_id
           |    from
           |        dm_gis.eta_std_line_similarity
           |    where
           |        inc_day='${inc_day}'
           |    ) d
           |on a.task_subid = d.task_subid
           |left outer join
           |    (
           |    select
           |        diffdist_rt_line,diffratio_rt_line,diffdist_rt_std,diffratio_rt_std,diffdist_rt_log,diffratio_rt_log,
           |        diffdist_line_log,diffratio_line_log,diffdist_line_std,diffratio_line_std,diffdist_log_std,diffratio_log_std,conduct_type,
           |        difftime_line_std,diffratio1_line_std,difftime_line_std_10min,difftime_line_rt,diffratio1_line_rt,difftime_rt_gh_10min,is_run_ontime_std,is_run_ontime,
           |        if_dist_equal,if_time_equal,pns_error,task_subid,difftime_std_rt,diffratio1_std_rt,difftime_std_rt_10min,
           |        start_distance_std,end_distance_std,std_line_error,ac_difftime_line_rt,ac_diffratio1_line_rt,ac_difftime_rt_gh_10min,ac_difftime_std_rt,ac_diffratio1_std_rt,
           |        ac_difftime_std_rt_10min,ac_is_run_ontime_std,ac_is_run_ontime
           |    from
           |        dm_gis.eta_std_line_compute
           |    where
           |        inc_day ='${inc_day}'
           |    ) e
           |on a.task_subid = e.task_subid
           |
         """.stripMargin

      val joinDf = spark.sql(joinSql)
      val joinRdd = SparkUtils.getRowToJson(joinDf,"MEMORY_AND_DISK")

      logger.error("结果表6输入数据量为：" + joinRdd.count())

      joinRdd


  }

  def parseTable6Coords(rt_coords: String) = {
    val joArray1 = new JSONArray()

    if (StringUtils.nonEmpty(rt_coords)) {
      val array1 = JSON.parseArray(rt_coords)
      for (i <- 0 until (array1.size())) {
        val json = array1.getJSONObject(i)
        val x = json.getDouble("dx")
        val y = json.getDouble("dy")
        val arrayNew = new JSONArray()
        arrayNew.add(x)
        arrayNew.add(y)
        joArray1.add(arrayNew)
      }
    }
    joArray1

  }
  def saveTable6(spark: SparkSession, inc_day: String, getJoin1to5Rdd: RDD[JSONObject]) = {


      import spark.implicits._
      val saveTableName = "dm_gis.eta_std_line_recall"

      logger.error("正在写入结果表6")

      val res6Rdd = getJoin1to5Rdd.map(x => {

        val task_area_code= x.getString("task_area_code")
        val task_id= x.getString("task_id")
        val sort_num= x.getString("sort_num")
        val task_subid= x.getString("task_subid")
        val start_dept= x.getString("start_dept")
        val end_dept= x.getString("end_dept")
        val start_type= x.getString("start_type")
        val end_type= x.getString("end_type")
        val line_code= x.getString("line_code")
        val vehicle_serial= x.getString("vehicle_serial")
        val actual_capacity_load= x.getString("actual_capacity_load")
        val plan_depart_tm= x.getString("plan_depart_tm")
        val actual_depart_tm= x.getString("actual_depart_tm")
        val plan_arrive_tm= x.getString("plan_arrive_tm")
        val actual_arrive_tm= x.getString("actual_arrive_tm")
        val driver_id= x.getString("driver_id")
        val driver_name= x.getString("driver_name")
        val line_time= x.getString("line_time")
        val line_distance= x.getString("line_distance")
        val actual_run_time= x.getString("actual_run_time")
        val start_longitude= x.getString("start_longitude")
        val start_latitude= x.getString("start_latitude")
        val end_longitude= x.getString("end_longitude")
        val end_latitude= x.getString("end_latitude")
        val is_stop= x.getString("is_stop")
        val transoport_level= x.getString("transoport_level")
        val carrier_type= x.getString("carrier_type")
        val plf_flag= x.getString("plf_flag")
        val vehicle_type= x.getString("vehicle_type")
        val axls_number= x.getString("axls_number")
        val log_dist= x.getString("log_dist")
        val rt_coords= parseTable6Coords(x.getString("rt_coords"))
        val x1= x.getString("x1")
        val y1= x.getString("y1")
        val x2= x.getString("x2")
        val y2= x.getString("y2")
        val duration= x.getString("duration")
        val time= x.getString("time")
        val rt_dist= x.getString("rt_dist")
        val highwaymileage= x.getString("highwaymileage")
        val toll_charge= x.getString("toll_charge")
        val start_distance= x.getString("start_distance")
        val end_distance= x.getString("end_distance")
        val error_type= x.getString("error_type")
        val pns_dist= x.getString("pns_dist")
        val pns_time= x.getString("pns_time")
        val src= x.getString("src")
        val std_coords= x.getString("std_coords")
        val line_distance_std= x.getString("line_distance_std")
        val line_time_std= x.getString("line_time_std")
        val sim1= x.getString("sim1")
        val sim5= x.getString("sim5")
        val diffdist_rt_line= x.getString("diffdist_rt_line")
        val diffratio_rt_line= x.getString("diffratio_rt_line")
        val diffdist_rt_std= x.getString("diffdist_rt_std")
        val diffratio_rt_std= x.getString("diffratio_rt_std")
        val diffdist_rt_log= x.getString("diffdist_rt_log")
        val diffratio_rt_log= x.getString("diffratio_rt_log")
        val diffdist_line_log= x.getString("diffdist_line_log")
        val diffratio_line_log= x.getString("diffratio_line_log")
        val diffdist_line_std= x.getString("diffdist_line_std")
        val diffratio_line_std= x.getString("diffratio_line_std")
        val diffdist_log_std= x.getString("diffdist_log_std")
        val diffratio_log_std= x.getString("diffratio_log_std")
        val conduct_type= x.getString("conduct_type")
        val difftime_line_std= x.getString("difftime_line_std")
        val diffratio1_line_std= x.getString("diffratio1_line_std")
        val difftime_line_std_10min= x.getString("difftime_line_std_10min")
        val difftime_line_rt= x.getString("difftime_line_rt")
        val diffratio1_line_rt= x.getString("diffratio1_line_rt")
        val difftime_rt_gh_10min= x.getString("difftime_rt_gh_10min")
        val is_run_ontime_std= x.getString("is_run_ontime_std")
        val is_run_ontime= x.getString("is_run_ontime")
        val if_dist_equal= x.getString("if_dist_equal")
        val if_time_equal= x.getString("if_time_equal")
        val pns_error= x.getString("pns_error")
        val task_inc_day = x.getString("task_inc_day")
        //difftime_std_rt,diffratio1_std_rt,difftime_std_rt_10min
        val difftime_std_rt = x.getString("difftime_std_rt")
        val diffratio1_std_rt = x.getString("diffratio1_std_rt")
        val difftime_std_rt_10min = x.getString("difftime_std_rt_10min")


        //20211012增加字段
        val tl_time = x.getString("tl_time")
        val halfway_integrate_rate= x.getString("halfway_integrate_rate")
        val std_x1= x.getString("std_x1")
        val std_y1= x.getString("std_y1")
        val std_x2= x.getString("std_x2")
        val std_y2= x.getString("std_y2")
        val start_distance_std= x.getString("start_distance_std")
        val end_distance_std= x.getString("end_distance_std")
        val std_line_error= x.getString("std_line_error")
        val ac_difftime_line_rt= x.getString("ac_difftime_line_rt")
        val ac_diffratio1_line_rt= x.getString("ac_diffratio1_line_rt")
        val ac_difftime_rt_gh_10min= x.getString("ac_difftime_rt_gh_10min")
        val ac_difftime_std_rt= x.getString("ac_difftime_std_rt")
        val ac_diffratio1_std_rt= x.getString("ac_diffratio1_std_rt")
        val ac_difftime_std_rt_10min= x.getString("ac_difftime_std_rt_10min")
        val ac_is_run_ontime_std= x.getString("ac_is_run_ontime_std")
        val ac_is_run_ontime= x.getString("ac_is_run_ontime")
        val if_evaluate_time= x.getString("if_evaluate_time")

        //20211101增加字段carrier_name,stop_over_zone_code
        val carrier_name = x.getString("carrier_name")
        val stop_over_zone_code = x.getString("stop_over_zone_code")

        //20211118增加字段biz_type,require_category,to_ground
        val biz_type = x.getString("biz_type")
        val require_category = x.getString("require_category")
        val to_ground = x.getString("to_ground")

        val std_toll_charge = x.getString("std_toll_charge")
        val std_id = x.getString("std_id")

        res_table6(task_area_code,task_id,sort_num,task_subid,start_dept,end_dept,start_type,end_type,line_code,
          vehicle_serial,actual_capacity_load,plan_depart_tm,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,
          driver_id,driver_name,line_time,line_distance,actual_run_time,start_longitude,start_latitude,end_longitude,
          end_latitude,is_stop,transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,log_dist,rt_coords.toJSONString,
          x1,y1,x2,y2,duration,time,rt_dist,highwaymileage,toll_charge,start_distance,end_distance,error_type,pns_dist,
          pns_time,src,std_coords,line_distance_std,line_time_std,sim1,sim5,diffdist_rt_line,diffratio_rt_line,
          diffdist_rt_std,diffratio_rt_std,diffdist_rt_log,diffratio_rt_log,diffdist_line_log,diffratio_line_log,
          diffdist_line_std,diffratio_line_std,diffdist_log_std,diffratio_log_std,conduct_type,difftime_line_std,
          diffratio1_line_std,difftime_line_std_10min,difftime_line_rt,diffratio1_line_rt,difftime_rt_gh_10min,is_run_ontime_std,
          is_run_ontime,if_dist_equal,if_time_equal,pns_error,task_inc_day,difftime_std_rt,diffratio1_std_rt,difftime_std_rt_10min,
          tl_time,halfway_integrate_rate,std_x1,std_y1,std_x2,std_y2,start_distance_std,end_distance_std,std_line_error,ac_difftime_line_rt,
          ac_diffratio1_line_rt,ac_difftime_rt_gh_10min,ac_difftime_std_rt,ac_diffratio1_std_rt,ac_difftime_std_rt_10min,ac_is_run_ontime_std,
          ac_is_run_ontime,if_evaluate_time,carrier_name,stop_over_zone_code,biz_type,require_category,to_ground,std_toll_charge,std_id
        )

      }).repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

      logger.error("结果表6写入完成")
  }

  def getSourceExacutive(spark: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day='${inc_day}'
         |and
         |  error_type = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type = 0
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf,"MEMORY")

    sourceRdd

  }

  /***
    * 计算执行率
    * @param exacutiveRateStatRdd
    */

  def calExacutiveRateStat(exacutiveRateStatRdd: RDD[JSONObject],inc_day:String) = {

    logger.error("开始执行率计算")

    val exacuResRdd = exacutiveRateStatRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    }).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {
      val task_area_code = x.getString("task_area_code")
      val carrier_name = JSONUtils.getJsonValue(x,"carrier_name","-")
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val task_inc_day = x.getString("task_inc_day")
      val src = x.getString("src")

      ((task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src),x)
    }).groupByKey().map(x => {
      val(task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src) = x._1
      val list = x._2.toList
      //任务总量
      val task_count = list.size
      val exe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).size

      val noexe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).size

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src).mkString("_"))

      Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,task_count,exe_count,noexe_count)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("exacuResRdd的数据量为：" + exacuResRdd.count())
    exacuResRdd.take(2).foreach(println(_))
    exacuResRdd
  }

  def saveTableExac(spark: SparkSession, inc_day: String, exacRateStatResRdd: RDD[Row],logger:Logger) = {

    val exacRateStatResSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("start_dept", StringType, true),
      StructField("end_dept", StringType, true),
      StructField("src", StringType, true),
      StructField("task_count", IntegerType, true),
      StructField("exe_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true)
    ))

    val exacRateStatResTable = "ETA_STD_LINE_EXECUTE_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,exacRateStatResRdd,exacRateStatResSchema,"append","dm_gis." + exacRateStatResTable,"statdate",inc_day,logger)

    // TODO: 保存到mysql
    SparkUtils.df2Mysql(spark,exacRateStatResRdd,exacRateStatResSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,exacRateStatResTable,inc_day,logger)



  }

  def getSourceOnTime(spark: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day = '${inc_day}'
         |and
         |  error_type = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type = 0
         |and
         |  if_evaluate_time = 1
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)
    sourceRdd

  }

  def calOnTimeRateStat(onTimeRateStatRdd: RDD[JSONObject],inc_day:String) = {
    logger.error("开始准点计算")

    val onTimeResRdd = onTimeRateStatRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    }).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {
      val task_area_code = x.getString("task_area_code")
      val carrier_name = JSONUtils.getJsonValue(x,"carrier_name","-")
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val task_inc_day = x.getString("task_inc_day")
      val src = x.getString("src")

      ((task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src),x)
    }).groupByKey().map(x => {
      val(task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src) = x._1
      val list = x._2.toList
      //任务总量
      val task_count = list.size
      val exe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).size
      val noexe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).size

      // TODO: 准点率新增字段
      val db_count = list.filter(x => {
        val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"ac_is_run_ontime",0)
        1 == ac_is_run_ontime
      }).size
      val exe_db_count = list.filter(x => {
        val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"ac_is_run_ontime",0)
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type) &&  1 == ac_is_run_ontime
      }).size

      val noexe_db_count = list.filter(x => {
        val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"ac_is_run_ontime",0)
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)  &&  1 == ac_is_run_ontime
      }).size

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src).mkString("_"))

      Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,task_count,exe_count,noexe_count,db_count,exe_db_count,noexe_db_count)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("onTimeResRdd的数据量为：" + onTimeResRdd.count())
    onTimeResRdd.take(2).foreach(println(_))

    onTimeResRdd


  }

  def saveTableOnTime(spark: SparkSession, inc_day: String, onTimeRateStatRdd: RDD[Row], logger: Logger) = {

    //Row(id,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,task_count,exe_count,noexe_count,db_count,exe_db_count,noexe_db_count,)

    val onTimeRateStatSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("start_dept", StringType, true),
      StructField("end_dept", StringType, true),
      StructField("src", StringType, true),
      StructField("task_count", IntegerType, true),
      StructField("exe_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true),
      StructField("db_count", IntegerType, true),
      StructField("exe_db_count", IntegerType, true),
      StructField("noexe_db_count", IntegerType, true)
    ))

    val onTimeRateStatTable = "ETA_STD_LINE_DB_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,onTimeRateStatRdd,onTimeRateStatSchema,"append","dm_gis." + onTimeRateStatTable,"statdate",inc_day,logger)

//    // TODO: 保存到mysql
//    SparkUtils.df2Mysql(spark,onTimeRateStatRdd,onTimeRateStatSchema,descMysqlUserName,descMysqlPassWord,
//      "append",descMysqlUrl,onTimeRateStatTable,inc_day,logger)


  }

  def getSourceDiff(spark: SparkSession, inc_day: String) = {

    val sourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day = '${inc_day}'
         |and
         |  error_type = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type = 0
       """.stripMargin

    val sourceDf = spark.sql(sourceSql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)
    sourceRdd


  }

  def calDiffRateStat(exacutiveRateStatRdd: RDD[JSONObject],inc_day:String) = {

    logger.error("开始里程差异率计算")

    val exacutiveResRdd = exacutiveRateStatRdd.map(x => {
      val task_subid = x.getString("task_subid")
      (task_subid,x)
    }).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {
      val task_area_code = x.getString("task_area_code")
      val carrier_name = JSONUtils.getJsonValue(x,"carrier_name","-")
      val line_code = x.getString("line_code")
      val start_dept = x.getString("start_dept")
      val end_dept = x.getString("end_dept")
      val task_inc_day = x.getString("task_inc_day")
      val src = x.getString("src")

      ((task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src),x)
    }).groupByKey().map(x => {
      val(task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src) = x._1
      val list = x._2.toList
      //任务总量
      val task_count = list.size
      val exe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).size
      val noexe_count = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).size

      // TODO: 里程差异率新增字段

      // TODO: 总标准线路里程total_pns_dist：pns_dist求和
      val total_pns_dist = list.map(x => {
        val pns_dist = JSONUtils.getJsonValueDouble(x,"pns_dist",0)
        pns_dist
      }).sum.toInt

      // TODO: 总任务实际里程total_rt_dist：rt_dist求和
      val total_rt_dist = list.map(x => {
        val rt_dist = JSONUtils.getJsonValueDouble(x,"rt_dist",0)
        rt_dist
      }).sum.toInt

      // TODO: 执行总标准线路里程exe_pns_dist：conduct_type=1的pns_dist求和
      val exe_pns_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).map(x => {
        val pns_dist = JSONUtils.getJsonValueDouble(x,"pns_dist",0)
        pns_dist
      }).sum.toInt

      // TODO: 执行总任务实际里程exe_rt_dist：conduct_type=1的rt_dist求和
      val exe_rt_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "1".equals(conduct_type)
      }).map(x => {
        val rt_dist = JSONUtils.getJsonValueDouble(x,"rt_dist",0)
        rt_dist
      }).sum.toInt

      // TODO: 未执行总任务实际里程noexe_rt_dist：conduct_type=3的rt_dist求和
      val noexe_pns_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).map(x => {
        val pns_dist = JSONUtils.getJsonValueDouble(x,"pns_dist",0)
        pns_dist
      }).sum.toInt

      // TODO: 未执行总任务实际里程noexe_rt_dist：conduct_type=3的rt_dist求和
      val noexe_rt_dist = list.filter(x => {
        val conduct_type = x.getString("conduct_type")
        StringUtils.nonEmpty(conduct_type) && "3".equals(conduct_type)
      }).map(x => {
        val rt_dist = JSONUtils.getJsonValueDouble(x,"rt_dist",0)
        rt_dist
      }).sum.toInt


      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src).mkString("_"))

      Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,start_dept,end_dept,src,
        task_count,exe_count,noexe_count,total_pns_dist,total_rt_dist,exe_pns_dist,exe_rt_dist,noexe_pns_dist,noexe_rt_dist)

    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("exacutiveResRdd的数据量为：" + exacutiveResRdd.count())
    exacutiveResRdd.take(2).foreach(println(_))

    exacutiveResRdd


  }

  def saveTableDiff(spark: SparkSession, inc_day: String, exacRateStatResRdd: RDD[Row], logger: Logger) = {

    val exacRateStatResSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("start_dept", StringType, true),
      StructField("end_dept", StringType, true),
      StructField("src", StringType, true),
      StructField("task_count", IntegerType, true),
      StructField("exe_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true),
      StructField("total_pns_dist", IntegerType, true),
      StructField("total_rt_dist", IntegerType, true),
      StructField("exe_pns_dist", IntegerType, true),
      StructField("exe_rt_dist", IntegerType, true),
      StructField("noexe_pns_dist", IntegerType, true),
      StructField("noexe_rt_dist", IntegerType, true)
    ))

    val diffRateStatTable = "ETA_STD_LINE_DIFF_DIST_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,exacRateStatResRdd,exacRateStatResSchema,"append","dm_gis." + diffRateStatTable,"statdate",inc_day,logger)

    // TODO: 保存到mysql
    SparkUtils.df2Mysql(spark,exacRateStatResRdd,exacRateStatResSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,diffRateStatTable,inc_day,logger)



  }

  def getSourceRecall(spark: SparkSession, inc_day: String) = {

    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall
         |where
         |  inc_day='${inc_day}'
       """.stripMargin

    val sourceDf = spark.sql(querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)

    sourceRdd

  }

  def calRecallRateStat(recallSourceRdd: RDD[JSONObject], inc_day: String) = {

    val recallRdd = recallSourceRdd.map(x => {
      val task_id = x.getString("task_id")
      (task_id,x)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(obj => {

        val task_id = obj._1
        val list = obj._2

        val minSortNum = list.minBy(x => {JSONUtils.getJsonValueDouble(x,"sort_num",0.0)})
        val maxSortNum = list.maxBy(x => {JSONUtils.getJsonValueDouble(x,"sort_num",0.0)})

        var line_time,line_distance,actual_run_time,duration,time,rt_dist,highwaymileage,toll_charge,pns_dist,pns_time,std_toll_charge = 0.0
        val srcSet = new mutable.HashSet[Int]()

        var err_flag = 0
        var conduct_type_flag = 1

        list.map(x => {
          line_time += JSONUtils.getJsonValueDouble(x,"line_time",0)
          line_distance += JSONUtils.getJsonValueDouble(x,"line_distance",0.0)
          actual_run_time += JSONUtils.getJsonValueInt(x,"actual_run_time",0)
          duration += JSONUtils.getJsonValueDouble(x,"duration",0.0)
          time += JSONUtils.getJsonValueDouble(x,"time",0)
          rt_dist += JSONUtils.getJsonValueDouble(x,"rt_dist",0.0)
          highwaymileage += JSONUtils.getJsonValueDouble(x,"highwaymileage",0.0)
          toll_charge += JSONUtils.getJsonValueDouble(x,"toll_charge",0.0)
          pns_dist += JSONUtils.getJsonValueDouble(x,"pns_dist",0)
          pns_time += JSONUtils.getJsonValueDouble(x,"pns_time",0)
          std_toll_charge += JSONUtils.getJsonValueDouble(x,"std_toll_charge",0.0)

          // TODO: 按task_id分组，分组下所有数据的error_type=0时赋值0，否则为1
          val err_type = JSONUtils.getJsonValueInt(x,"err_type",0)
          if (err_type != 0) err_flag = 1
          val src = JSONUtils.getJsonValueInt(x,"src",0)
          // TODO: 按task_id分组，取分组下所有数据的src用|分隔组合在一个字段，格式：2|3
          srcSet.add(src)
          // TODO:  按task_id分组，分组下所有数据的conduct_type=1时赋值1，否则为3
          val conduct_type = JSONUtils.getJsonValueInt(x,"conduct_type",1)
          if (conduct_type != 1) conduct_type_flag = 3

          val ac_is_run_ontime = JSONUtils.getJsonValueInt(x,"actual_run_time",0)

        })

        val end_dept = maxSortNum.getString("end_dept")
        val end_type = maxSortNum.getString("end_type")
        val plan_arrive_tm = maxSortNum.getString("plan_arrive_tm")
        val actual_arrive_tm = maxSortNum.getString("actual_arrive_tm")

        minSortNum.put("line_time",line_time)
        minSortNum.put("line_distance",line_distance)
        minSortNum.put("actual_run_time",actual_run_time.toInt)
        minSortNum.put("duration",duration)
        minSortNum.put("time",time.toInt)
        minSortNum.put("rt_dist",rt_dist)
        minSortNum.put("highwaymileage",highwaymileage)
        minSortNum.put("toll_charge",toll_charge)
        minSortNum.put("pns_dist",pns_dist.toInt)
        minSortNum.put("pns_time",pns_time.toInt)
        minSortNum.put("std_toll_charge",std_toll_charge)
        minSortNum.put("if_error",err_flag)
        minSortNum.put("src",srcSet.mkString("|"))
        minSortNum.put("conduct_type",conduct_type_flag)

        //按task_id分组取sort_num最大那条
        minSortNum.put("end_dept",end_dept)
        minSortNum.put("end_type",end_type)
        minSortNum.put("plan_arrive_tm",plan_arrive_tm)
        minSortNum.put("actual_arrive_tm",actual_arrive_tm)


        val log_dist = JSONUtils.getJsonValueInt(minSortNum,"log_dist",0)

        val ac_is_run_ontime = if ( actual_run_time - 1 < line_time) 1 else 0
        val diffdist_log_rt = if ( log_dist != 0 ) log_dist * 1000 - rt_dist else 0
        val diffratio_log_rt = if ( rt_dist != 0 ) diffdist_log_rt / rt_dist else 0

        minSortNum.put("ac_is_run_ontime",ac_is_run_ontime)
        minSortNum.put("diffdist_log_rt",diffdist_log_rt)
        minSortNum.put("diffratio_log_rt",diffratio_log_rt)

        minSortNum

      }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("recallRdd的数据量为：" + recallRdd.count())
    recallRdd.take(2).foreach(println(_))

    recallRdd

  }

  def saveTableRecall2(spark: SparkSession, inc_day: String, recallRdd: RDD[JSONObject], logger: Logger) = {

    import spark.implicits._
    val saveTableName = "dm_gis.eta_std_line_recall1"

    logger.error("正在写入结果表6")

    val res6Rdd = recallRdd.map(x => {

      val task_area_code= x.getString("task_area_code")
      val task_id= x.getString("task_id")
      val carrier_name= x.getString("carrier_name")
      val task_inc_day= x.getString("task_inc_day")
      val start_dept= x.getString("start_dept")
      val start_type= x.getString("start_type")
      val line_code= x.getString("line_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val plan_depart_tm= x.getString("plan_depart_tm")
      val actual_depart_tm= x.getString("actual_depart_tm")
      val driver_id= x.getString("driver_id")
      val driver_name= x.getString("driver_name")
      val is_stop= x.getString("is_stop")
      val transoport_level= x.getString("transoport_level")
      val carrier_type= x.getString("carrier_type")
      val plf_flag= x.getString("plf_flag")
      val vehicle_type= x.getString("vehicle_type")
      val axls_number= x.getString("axls_number")
      val log_dist= x.getString("log_dist")
      val if_evaluate_time= x.getString("if_evaluate_time")
      val stop_over_zone_code= x.getString("stop_over_zone_code")
      val end_dept= x.getString("end_dept")
      val end_type= x.getString("end_type")
      val plan_arrive_tm= x.getString("plan_arrive_tm")
      val actual_arrive_tm= x.getString("actual_arrive_tm")
      val line_time= x.getString("line_time")
      val line_distance= x.getString("line_distance")
      val actual_run_time= x.getString("actual_run_time")
      val duration= x.getString("duration")
      val time= x.getString("time")
      val rt_dist= x.getString("rt_dist")
      val highwaymileage= x.getString("highwaymileage")
      val toll_charge= x.getString("toll_charge")
      val pns_dist= x.getString("pns_dist")
      val pns_time= x.getString("pns_time")
      val std_toll_charge= x.getString("std_toll_charge")
      val if_error= x.getString("if_error")
      val src= x.getString("src")
      val conduct_type= x.getString("conduct_type")
      val ac_is_run_ontime= x.getString("ac_is_run_ontime")
      val diffdist_log_rt= x.getString("diffdist_log_rt")
      val diffratio_log_rt= x.getString("diffratio_log_rt")

      res_table7(
        task_area_code,task_id,carrier_name,task_inc_day,start_dept,start_type,line_code,vehicle_serial,actual_capacity_load,
        plan_depart_tm,actual_depart_tm,driver_id,driver_name,is_stop,transoport_level,carrier_type,plf_flag,vehicle_type,axls_number,log_dist,
        if_evaluate_time,stop_over_zone_code,end_dept,end_type,plan_arrive_tm,actual_arrive_tm,line_time,line_distance,actual_run_time,
        duration,time,rt_dist,highwaymileage,toll_charge,pns_dist,pns_time,std_toll_charge,if_error,src,conduct_type,
        ac_is_run_ontime,diffdist_log_rt,diffratio_log_rt
      )

    }).repartition(100).toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表6写入完成")




  }

  def getSourceTotal(spark: SparkSession, inc_day: String) = {

    val querySql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.eta_std_line_recall1
         |where
         |  inc_day='${inc_day}'
         |and
         |  if_error = 0
         |and
         |  pns_dist is not null
         |and
         |  carrier_type=0
       """.stripMargin

    val sourceDf = spark.sql(querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)

    sourceRdd

  }

  def calTotalTaskStat(totalTaskSourceRdd: RDD[JSONObject], inc_day: String) = {

      val totalTaskRdd = totalTaskSourceRdd
          .map(x => {
            val task_id = x.getString("task_id")

            (task_id,x)
          })
          .reduceByKey((obj1,obj2) => obj1)
          .map(_._2)
        .map(x => {

        val task_area_code = x.getString("task_area_code")
        val carrier_name = x.getString("carrier_name")
        val line_code = x.getString("line_code")
        val stop_over_zone_code = x.getString("stop_over_zone_code")
        val task_inc_day = x.getString("task_inc_day")

        ((task_area_code,carrier_name,line_code,stop_over_zone_code,task_inc_day),x)

      }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
        .map( x => {

          val (task_area_code,carrier_name,line_code,stop_over_zone_code,task_inc_day) = x._1
          val list = x._2

          // TODO:  总任务量
          val total_task_count = list.size

          val total_evaluate_count_list = list.filter(y => {
            val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
            if_evaluate_time == 1
          })

          // TODO:  总考核任务量
          val total_evaluate_count = total_evaluate_count_list.size
          // TODO:  总准点量
          val total_db_count = total_evaluate_count_list.filter(y => {
            val ac_is_run_ontime = JSONUtils.getJsonValueInt(y,"ac_is_run_ontime",0)
            ac_is_run_ontime == 1
          }).size

          val exe_task_count_list = list.filter(y => {
            val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
            conduct_type == 1
          })

          // TODO:  执行任务量
          val exe_task_count = exe_task_count_list.size

          // TODO:  执行考核任务量
          val exe_evaluate_count = exe_task_count_list.filter(y => {
            val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
            val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
            conduct_type == 1 && if_evaluate_time == 1
          }).size

          // TODO:  执行准点任务量
          val exe_db_count = list.filter(y => {
            val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
            val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
            val ac_is_run_ontime = JSONUtils.getJsonValueInt(y,"ac_is_run_ontime",0)
            conduct_type == 1 && if_evaluate_time == 1 && ac_is_run_ontime == 1
          }).size

          // TODO:  未执行任务量
          val noexe_count = list.filter(y => {
            val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
            conduct_type == 3
          }).size

          // TODO:  未执行考核任务量
          val noexe_evaluate_count = list.filter(y => {
            val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
            val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
            conduct_type == 3 && if_evaluate_time == 1
          }).size

          // TODO:  未执行准点量
          val noexe_db_count = list.filter(y => {
            val conduct_type = JSONUtils.getJsonValueInt(y,"conduct_type",0)
            val if_evaluate_time = JSONUtils.getJsonValueInt(y,"if_evaluate_time",0)
            val ac_is_run_ontime = JSONUtils.getJsonValueInt(y,"ac_is_run_ontime",0)
            conduct_type == 3 && if_evaluate_time == 1 && ac_is_run_ontime == 1
          }).size

          // TODO:  总实际路桥费用、100%按规划线路执行的总路桥费用、总实际轨迹里程(km)、100%按规划线路行驶的总里程
          var total_toll_charge = 0.0
          var total_toll_charge_std = 0.0
          var total_rt_dist = 0.0
          var total_pns_dist = 0.0

          list.map(a => {
            total_toll_charge += JSONUtils.getJsonValueDouble(a,"total_toll_charge",0)
            total_toll_charge_std += JSONUtils.getJsonValueDouble(a,"std_toll_charge",0)
            total_rt_dist += JSONUtils.getJsonValueDouble(a,"rt_dist",0)
            total_pns_dist += JSONUtils.getJsonValueDouble(a,"pns_dist",0)
          })

          val md5Instance = MD5Util.getMD5Instance
          val id = MD5Util.getMD5(md5Instance, Array(inc_day,task_inc_day,task_area_code,carrier_name,line_code,stop_over_zone_code).mkString("_"))

          Row(id,inc_day,task_inc_day,task_area_code,carrier_name,line_code,stop_over_zone_code,total_task_count,
            total_evaluate_count,total_db_count,exe_task_count,exe_evaluate_count,exe_db_count,
            noexe_count,noexe_evaluate_count,noexe_db_count,total_toll_charge,total_toll_charge_std,total_rt_dist,total_pns_dist)
        })

      totalTaskRdd
  }

  def saveTableTotalTask(spark: SparkSession, inc_day: String, totalTaskRdd: RDD[Row], logger: Logger) = {


    val totalTaskSchema =  StructType(List(
      StructField("id", StringType, true),
      StructField("statdate", StringType, true),
      StructField("task_inc_day", StringType, true),
      StructField("task_area_code", StringType, true),
      StructField("carrier_name", StringType, true),
      StructField("line_code", StringType, true),
      StructField("stop_over_zone_code", StringType, true),
      StructField("total_task_count", IntegerType, true),
      StructField("total_evaluate_count", IntegerType, true),
      StructField("total_db_count", IntegerType, true),
      StructField("exe_task_count", IntegerType, true),
      StructField("exe_evaluate_count", IntegerType, true),
      StructField("exe_db_count", IntegerType, true),
      StructField("noexe_count", IntegerType, true),
      StructField("noexe_evaluate_count", IntegerType, true),
      StructField("noexe_db_count", IntegerType, true),
      StructField("total_toll_charge", DoubleType, true),
      StructField("total_toll_charge_std", DoubleType, true),
      StructField("total_rt_dist", DoubleType, true),
      StructField("total_pns_dist", DoubleType, true)

    ))

    val totalTaskStatTable = "ETA_STD_LINE_WHOLE_TASK_STAT"

    //保存到hive
    SparkUtils.df2Hive(spark,totalTaskRdd,totalTaskSchema,"append","dm_gis." + totalTaskStatTable,"statdate",inc_day,logger)

//    // TODO: 保存到mysql
//    SparkUtils.df2Mysql(spark,totalTaskRdd,totalTaskSchema,descMysqlUserName,descMysqlPassWord,
//      "append",descMysqlUrl,totalTaskStatTable,inc_day,logger)



  }

  def getKafkaData(spark: SparkSession, inc_day: String) = {

    val getSourceSql =
      s"""
         |select
         |  *
         |from
         |  dm_gis.omcs_ground_task_calc_hive
         |where
         |  inc_day = '${inc_day}'
       """.stripMargin

    val soucreDf = spark.sql(getSourceSql)
    val sourceRdd = SparkUtils.getRowToJson(soucreDf)

    logger.error("共获取kafka数据:" + sourceRdd.count())
    sourceRdd.take(2).foreach(println(_))

    sourceRdd

  }

  def getParseKafkaLog(groundKafkaSourceRdd: RDD[JSONObject], inc_day: String) = {

    val parseRdd = groundKafkaSourceRdd.flatMap(x => {

      val log = x.getString("log")
      val json = JSON.parseObject(log)
      val groundTaskPassZoneDtosList = json.getJSONArray("groundTaskPassZoneDtos")
      val task_id = json.getString("taskId")
      val task_area_code = json.getString("taskAreaCode")
      val line_code = json.getString("lineCode")
      val require_category = json.getString("requireCategory")
      val stop_over_zone_code = json.getString("stopOverZoneCode")
      val vehicle_serial = json.getString("vehicleSerial")
      val driver_id = json.getString("driverId")
      val driver_name = json.getString("driverName")
      val actual_capacity_load = json.getString("actualCapacityLoad")
      val capacity_load = json.getString("capacityLoad")
      val transoport_level = json.getString("transoportLevel")
      val to_ground = json.getString("toGround")
      val biz_type = json.getString("bizType")
      val carrier_name = json.getString("carrierName")
      val is_stop = json.getString("isStop")
      val carrier_type = json.getString("carrierType")
      val state = json.getString("state")
      val last_update_tm = json.getString("lastUpdateTm")

      val full_load_weight = json.getString("fullLoadWeight")
      val contnr_code = json.getString("contnrCode")


      val buffer = new ArrayBuffer[JSONObject]()

      for (i <- (0 until(groundTaskPassZoneDtosList.size() -1))){
        val jo = new JSONObject()
        val curJson = groundTaskPassZoneDtosList.getJSONObject(i)
        val nextJson = groundTaskPassZoneDtosList.getJSONObject(i + 1)

        val sort_num = i
        val start_dept = curJson.getString("passZoneCode")
        val start_dept_site_id = curJson.getString("deptSiteId")
        val end_dept = nextJson.getString("passZoneCode")
        val end_dept_site_id = nextJson.getString("deptSiteId")
        val start_type = if (StringUtils.nonEmpty(start_dept) && StringUtils.nonEmpty(start_dept) && start_dept.equals(start_dept_site_id)) 2 else 1
        val end_type = if (StringUtils.nonEmpty(end_dept) && StringUtils.nonEmpty(end_dept_site_id) && end_dept.equals(end_dept_site_id)) 2 else 1
        val plan_depart_tm = DateTimeUtil.timestampConvertDate2(curJson.getLongValue("planDepartTm"),"yyyy-MM-dd HH:mm:ss")
        val actual_depart_tm = DateTimeUtil.timestampConvertDate2(curJson.getLongValue("actualDepartTm"),"yyyy-MM-dd HH:mm:ss")
        val plan_arrive_tm = DateTimeUtil.timestampConvertDate2(nextJson.getLongValue("planArriveTm"),"yyyy-MM-dd HH:mm:ss")
        val actual_arrive_tm = DateTimeUtil.timestampConvertDate2(nextJson.getLongValue("actualArriveTm"),"yyyy-MM-dd HH:mm:ss")
        val line_time = curJson.getLongValue("planRunTime")
        val line_distance = curJson.getLongValue("lineDistance")
        val actual_run_time = curJson.getString("actualRunTime")
        val start_longitude = try {curJson.getString("passZoneCoordinate").split(",")(0) } catch {case e:Exception => ""}
        val start_latitude = try {curJson.getString("passZoneCoordinate").split(",")(1) } catch {case e:Exception => ""}
        val end_longitude = try {nextJson.getString("passZoneCoordinate").split(",")(0) } catch {case e:Exception => ""}
        val end_latitude = try {nextJson.getString("passZoneCoordinate").split(",")(1) } catch {case e:Exception => ""}

        val votes_cur = try {curJson.getJSONObject("votes")} catch {case e:Exception => new JSONObject()}
        val votes_l =  try { votes_cur.getString("l")} catch {case e:Exception => ""}
        val votes_lw = try { votes_cur.getString("lw")} catch {case e:Exception => ""}

        val votes_next = try {nextJson.getJSONObject("votes")} catch {case e:Exception => new JSONObject()}
        val votes_s = try { votes_next.getString("s")} catch {case e:Exception => ""}
        val votes_n = try { votes_next.getString("n")} catch {case e:Exception => ""}
        val votes_d = try { votes_next.getString("d")} catch {case e:Exception => ""}
        val votes_w = try { votes_next.getString("w")} catch {case e:Exception => ""}
        val votes_sp = try { votes_next.getString("sp")} catch {case e:Exception => ""}
        val votes_dp = try { votes_next.getString("dp")} catch {case e:Exception => ""}
        val votes_pw = try { votes_next.getString("pw")} catch {case e:Exception => ""}

        jo.put("task_id",task_id)
        jo.put("sort_num",sort_num)
        jo.put("task_area_code",task_area_code)
        jo.put("line_code",line_code)
        jo.put("start_dept",start_dept)
        jo.put("start_dept_site_id",start_dept_site_id)
        jo.put("end_dept",end_dept)
        jo.put("end_dept_site_id",end_dept_site_id)
        jo.put("start_type",start_type)
        jo.put("end_type",end_type)
        jo.put("plan_depart_tm",plan_depart_tm)
        jo.put("actual_depart_tm",actual_depart_tm)
        jo.put("plan_arrive_tm",plan_arrive_tm)
        jo.put("actual_arrive_tm",actual_arrive_tm)
        jo.put("line_time",line_time)
        jo.put("line_distance",line_distance)
        jo.put("actual_run_time",actual_run_time)
        jo.put("start_longitude",start_longitude)
        jo.put("start_latitude",start_latitude)
        jo.put("end_longitude",end_longitude)
        jo.put("end_latitude",end_latitude)
        jo.put("require_category",require_category)
        jo.put("stop_over_zone_code",stop_over_zone_code)
        jo.put("vehicle_serial",vehicle_serial)
        jo.put("driver_id",driver_id)
        jo.put("driver_name",driver_name)
        jo.put("actual_capacity_load",actual_capacity_load)
        jo.put("capacity_load",capacity_load)
        jo.put("transoport_level",transoport_level)
        jo.put("to_ground",to_ground)
        jo.put("biz_type",biz_type)
        jo.put("carrier_name",to_ground)
        jo.put("is_stop",is_stop)
        jo.put("carrier_type",carrier_type)
        jo.put("state",state)
        jo.put("last_update_tm",last_update_tm)

        jo.put("full_load_weight",full_load_weight)
        jo.put("votes_l",votes_l)
        jo.put("votes_lw",votes_lw)
        jo.put("votes_s",votes_s)
        jo.put("votes_n",votes_n)
        jo.put("votes_d",votes_d)
        jo.put("votes_w",votes_w)
        jo.put("votes_sp",votes_sp)
        jo.put("votes_dp",votes_dp)
        jo.put("votes_pw",votes_pw)
        jo.put("contnr_code",contnr_code)
        buffer.append(jo)
      }

      buffer
    })
      .map(x => {
      val task_id = x.getString("task_id")
      val sort_num = x.getString("sort_num")
      ((task_id,sort_num),x)
      })
      .reduceByKey((obj1,obj2) => mergeLastUpdate(obj1,obj2))
      .map(_._2)
      // 不写入start_dept或end_dept为null的数据
      .filter(x => {
          val start_dept = x.getString("start_dept")
          val end_dept = x.getString("end_dept")
          StringUtils.nonEmpty(start_dept) && StringUtils.nonEmpty(end_dept)
        })
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("parseRdd的数据量为:" + parseRdd.count())
    parseRdd.take(2).foreach(println(_))

    parseRdd

  }

  /**
    * 根据task_id和sort_num去重，保留last_update_tm最大的一条
    * @param obj1
    * @param obj2
    * @return
    */

  def mergeLastUpdate(obj1: JSONObject, obj2: JSONObject):JSONObject = {
    if (obj1 == null) {
      return obj2
    }
    if (obj2 == null) {
      return obj1
    }
    val last_update_tm_1 = JSONUtils.getJsonValue(obj1,"last_update_tm","0")
    val last_update_tm_2 = JSONUtils.getJsonValue(obj2,"last_update_tm","0")

    //取last_update_tm最大的
    if(last_update_tm_1 < last_update_tm_2){
      return obj2
    }else{
      return obj1
    }
  }

  def saveTable8(spark: SparkSession, inc_day: String, parseKafkaLogRdd: RDD[JSONObject], logger: Logger) = {

    import spark.implicits._

    val saveTableName = "dm_gis.eta_std_line_task_parse"
    logger.error("正在写入结果表8")
    val res = parseKafkaLogRdd.map(x => {

      val task_id= x.getString("task_id")
      val sort_num= x.getString("sort_num")
      val task_area_code= x.getString("task_area_code")
      val line_code= x.getString("line_code")
      val start_dept= x.getString("start_dept")
      val start_dept_site_id= x.getString("start_dept_site_id")
      val end_dept= x.getString("end_dept")
      val end_dept_site_id= x.getString("end_dept_site_id")
      val start_type= x.getString("start_type")
      val end_type= x.getString("end_type")
      val plan_depart_tm= x.getString("plan_depart_tm")
      val actual_depart_tm= x.getString("actual_depart_tm")
      val plan_arrive_tm= x.getString("plan_arrive_tm")
      val actual_arrive_tm= x.getString("actual_arrive_tm")
      val line_time= x.getString("line_time")
      val line_distance= x.getString("line_distance")
      val actual_run_time= x.getString("actual_run_time")
      val start_longitude= x.getString("start_longitude")
      val start_latitude= x.getString("start_latitude")
      val end_longitude= x.getString("end_longitude")
      val end_latitude= x.getString("end_latitude")
      val require_category= x.getString("require_category")
      val stop_over_zone_code= x.getString("stop_over_zone_code")
      val vehicle_serial= x.getString("vehicle_serial")
      val driver_id= x.getString("driver_id")
      val driver_name= x.getString("driver_name")
      val actual_capacity_load= x.getString("actual_capacity_load")
      val capacity_load= x.getString("capacity_load")
      val transoport_level= x.getString("transoport_level")
      val to_ground= x.getString("to_ground")
      val biz_type= x.getString("biz_type")
      val carrier_name= x.getString("carrier_name")
      val is_stop= x.getString("is_stop")
      val carrier_type= x.getString("carrier_type")
      val plf_flag= ""
      val state= x.getString("state")
      val last_update_tm = x.getString("last_update_tm")


      val full_load_weight = x.getString("full_load_weight")
      val votes_l = x.getString("votes_l")
      val votes_lw = x.getString("votes_lw")
      val votes_s = x.getString("votes_s")
      val votes_n = x.getString("votes_n")
      val votes_d = x.getString("votes_d")
      val votes_w = x.getString("votes_w")
      val votes_sp = x.getString("votes_sp")
      val votes_dp = x.getString("votes_dp")
      val votes_pw = x.getString("votes_pw")
      val contnr_code = x.getString("contnr_code")


      res_table8(task_id,sort_num,task_area_code,line_code,start_dept,start_dept_site_id,end_dept,end_dept_site_id,start_type,
        end_type,plan_depart_tm,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,line_time,line_distance,actual_run_time,
        start_longitude,start_latitude,end_longitude,end_latitude,require_category,stop_over_zone_code,vehicle_serial,
        driver_id,driver_name,actual_capacity_load,capacity_load,transoport_level,to_ground,biz_type,carrier_name,is_stop,
        carrier_type,plf_flag,state,last_update_tm,full_load_weight,votes_l,votes_lw,votes_s,votes_n,votes_d,votes_w,votes_sp,votes_dp,votes_pw,contnr_code)
    })
      //val frame = spark.createDataFrame(res)
      .toDF().withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    logger.error("结果表8写入完成")



  }

  def startIndexStat(spark: SparkSession, inc_day: String) = {

//     TODO: kafka日志解析 结果表8
    val groundKafkaSourceRdd = getKafkaData(spark,inc_day)
    val parseKafkaLogRdd = getParseKafkaLog(groundKafkaSourceRdd,inc_day)
    saveTable8(spark,inc_day,parseKafkaLogRdd,logger)


    val (midTable1Rdd,sourceTable1Rdd) = getSourceTable1(spark,inc_day)
    saveTable1(spark,inc_day,sourceTable1Rdd)


    val distinctMidTableRdd = distinctMidTable1(midTable1Rdd,inc_day)
    val standardLineRdd = getStandardLine(distinctMidTableRdd)
    saveTable3(spark,inc_day,standardLineRdd)


    val getRes1Rdd= getRes1table(spark,inc_day)
    val getGjTable = processGjRectify(getRes1Rdd)
    saveTable2(spark,inc_day,getGjTable)


    val (sourceSimilarRdd1,sourceSimilarRdd2) = getSourceSim(spark,inc_day)
    val getSimRdd = getSimProcess(sourceSimilarRdd1,sourceSimilarRdd2)
    saveTable4(spark,inc_day,getSimRdd)


    val getComputeRdd = getComputeSource(spark,inc_day)
    saveTable5(spark,inc_day,getComputeRdd)

    val getJoin1to5Rdd = getJoin1to5(spark,inc_day)
    saveTable6(spark,inc_day,getJoin1to5Rdd)

    // TODO: 任务监控指标--执行率
    val exacutiveRateStatRdd = getSourceExacutive(spark,inc_day)
    val exacRateStatResRdd = calExacutiveRateStat(exacutiveRateStatRdd,inc_day)
    saveTableExac(spark,inc_day,exacRateStatResRdd,logger)

    // TODO: 任务监控指标--准点率
    val onTimeRateStatRdd = getSourceOnTime(spark,inc_day)
    val onTimeRateStatResRdd = calOnTimeRateStat(onTimeRateStatRdd,inc_day)
    saveTableOnTime(spark,inc_day,onTimeRateStatResRdd,logger)

    // TODO: 任务监控指标--里程差异率
    val diffRateStatRdd = getSourceDiff(spark,inc_day)
    val diffRateStatResRdd = calDiffRateStat(diffRateStatRdd,inc_day)
    saveTableDiff(spark,inc_day,diffRateStatResRdd,logger)

    // TODO: 回溯表
    val recallSourceRdd = getSourceRecall(spark,inc_day)
    val recallRdd = calRecallRateStat(recallSourceRdd,inc_day)
    saveTableRecall2(spark,inc_day,recallRdd,logger)

    // TODO: 完整任务统计
    val totalTaskSourceRdd = getSourceTotal(spark,inc_day)
    val totalTaskRdd = calTotalTaskStat(totalTaskSourceRdd,inc_day)
    saveTableTotalTask(spark,inc_day,totalTaskRdd,logger)

  }

  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    startIndexStat(spark,inc_day)
    logger.error("统计结束")
  }



}
