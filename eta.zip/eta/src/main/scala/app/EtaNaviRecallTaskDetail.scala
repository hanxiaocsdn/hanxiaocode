package app

import Utils.SparkUtils.writeToHive
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.SparkUtil
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.col

import scala.collection.mutable.ArrayBuffer

/**
 * 【GIS-RSS-ETA】
 * 需求方：曹倩倩（01425168）
 * @author 徐游飞（01417347）
 * 任务ID：776166
 * 任务名称：ETA请求日志解析
 */
object EtaNaviRecallTaskDetail {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    val incDay = args(0)
    val dayBefore2 = args(1)
    //日期检查
    logger.error("incDay="+incDay)
    logger.error("dayBefore2="+dayBefore2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    val querySql =
      s"""
         |select
         |  log,
         |  inc_day
         |from
         |  dm_gis.merge_kafka_log_flink13
         |where
         |  inc_day >= '$dayBefore2'
         |  and inc_day <= '$incDay'
         |  and get_json_object(log, '$$.topic') = 'GIS_RSS_ETA_WMP_LOG'
         |""".stripMargin

    println("获取kafka原始数据 sql语句：")
    println(querySql)

    // 解析data数据
    import spark.implicits._
    val df_wmp_log= spark.sql(querySql).rdd.map(x=>{
      var log = new JSONObject()
      try {
        log = JSON.parseObject(x.getString(0))
      } catch {
        case e: Exception => logger.error(e)
      }
      val data = JSONUtil.getJsonObjectMulti(log,"data")
      val gd_latest_arrived_tm_state = JSONUtil.getJsonValSingle(data, "gdLatestArrivedTmState","")
      val gd_remain_time = JSONUtil.getJsonValSingle(data, "gdRemainTime","")
      val gd_plan_run_tm_state = JSONUtil.getJsonValSingle(data, "gdPlanRunTmState","")
      val ft_arrival_tm = JSONUtil.getJsonValSingle(data, "ftArrivalTm","")
      val ft_remain_time = JSONUtil.getJsonValSingle(data, "ftRemainTime","")
      val ft_remain_distance = JSONUtil.getJsonValSingle(data, "ftRemainDistance","")
      val gd_arrival_tm = JSONUtil.getJsonValSingle(data, "gdArrivalTm","")
      val uid = JSONUtil.getJsonValSingle(data, "uid","")
      val plan_run_tm_flag = JSONUtil.getJsonValSingle(data, "planRunTmFlag","")
      val dest_dept_code = JSONUtil.getJsonValSingle(data, "destDeptCode","")
      val ft_plan_run_tm_state = JSONUtil.getJsonValSingle(data, "ftPlanRunTmState","")
      val route_id = JSONUtil.getJsonValSingle(data, "routeId","")
      val ft_plan_arrived_tm_state = JSONUtil.getJsonValSingle(data, "ftPlanArrivedTmState","")
      val src_dept_code = JSONUtil.getJsonValSingle(data, "srcDeptCode","")
      val ft_latest_arrived_tm_state = JSONUtil.getJsonValSingle(data, "ftLatestArrivedTmState","")
      val gd_plan_arrived_tm_state = JSONUtil.getJsonValSingle(data, "gdPlanArrivedTmState","")
      val task_id = JSONUtil.getJsonValSingle(data, "taskId","")
      val gd_remain_distance = JSONUtil.getJsonValSingle(data, "gdRemainDistance","")

      val data_time = JSONUtil.getJsonValSingle(log, "dataTime","")
      val sub_type = JSONUtil.getJsonValSingle(log, "subType","")
      val `type` = JSONUtil.getJsonValSingle(log, "type","")
      val node_id = JSONUtil.getJsonValSingle(log, "nodeId","")
      val req_id = JSONUtil.getJsonValSingle(log, "reqId","")
      val inc_day = x.getString(1)


      WMPLog(gd_latest_arrived_tm_state,gd_remain_time,gd_plan_run_tm_state,ft_arrival_tm,ft_remain_time,ft_remain_distance,gd_arrival_tm,
        uid,plan_run_tm_flag,dest_dept_code,ft_plan_run_tm_state,route_id,ft_plan_arrived_tm_state,src_dept_code,ft_latest_arrived_tm_state,
        gd_plan_arrived_tm_state,task_id,gd_remain_distance,data_time,sub_type,`type`,node_id,req_id,inc_day)
    }).toDF.coalesce(3)

    // 数据存入hive
    val res_cols = spark.sql(s"""select * from dm_gis.eta_navi_recall_task_detail limit 0""").schema.map(_.name).map(col)
    writeToHive(spark,df_wmp_log.select(res_cols: _*),Seq("inc_day"),"dm_gis.eta_navi_recall_task_detail")

  }

  case class WMPLog(
                     gd_latest_arrived_tm_state : String,
                     gd_remain_time : String,
                     gd_plan_run_tm_state : String,
                     ft_arrival_tm : String,
                     ft_remain_time : String,
                     ft_remain_distance : String,
                     gd_arrival_tm : String,
                     uid : String,
                     plan_run_tm_flag : String,
                     dest_dept_code : String,
                     ft_plan_run_tm_state : String,
                     route_id : String,
                     ft_plan_arrived_tm_state : String,
                     src_dept_code : String,
                     ft_latest_arrived_tm_state : String,
                     gd_plan_arrived_tm_state : String,
                     task_id : String,
                     gd_remain_distance : String,
                     data_time : String,
                     sub_type : String,
                     `type` : String,
                     node_id : String,
                     req_id : String,
                     inc_day : String
                   )
}
