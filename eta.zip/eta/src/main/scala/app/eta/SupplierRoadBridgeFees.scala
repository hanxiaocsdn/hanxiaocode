package app.eta

import Utils.SparkUtils.writeToHive
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil, UrlUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.functions.{col, concat, count, desc, lit, row_number, trim, when}
import org.apache.spark.storage.StorageLevel
import uitls.UrlUtils.sendPost

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

/**
 *需求名称：供应商路桥费接入计算V1.0
 *需求描述：包天包月任务结算时存在人工审核效率低，路桥费举证金额存疑等问题；由gis提供任务路桥费查询接口，避免人工审核提高审核效率以及使用国家路网中心结算路桥费数据确保任务路桥费准确性。
 *需求方：杨汶铭(ft80006323)
 *开发: 周勇(01390943)
 *任务创建时间：20230804
 *任务id：784750
 **/

object SupplierRoadBridgeFees {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._
    val dayvar = args(0)
    val dayvar3 = getdaysBeforeOrAfter(dayvar, -3)
    logger.error("接收输入变量dayvar:" + dayvar)
    logger.error("接收输入变量dayvar3:" + dayvar3)

    //获取任务收费记录表
    val tolls_record=spark.sql(
      s"""
        |select task_id,
        |waybill_id,
        |plate,
        |plate_color,
        |task_add_time,
        |plan_depart_time,
        |task_start_time,
        |task_end_time,
        |task_status,
        |tolls_status,
        |task_result,
        |ctfo_task_fee,
        |ft_task_fee,
        |task_err_msg,
        |ft_highway,
        |src_dept,
        |dest_dept,
        |mload,
        |tolls_result_time,
        |plate_color_src,stop_dept,ctfo_result_code,line_code,push_status,task_type,task_type1_src_id,task_type1_update_tm,vehicle_type
        |from dm_gis.dm_eta_task_tolls_record_dtl_di
        |where inc_day='$dayvar'
        |group by
        |task_id,
        |waybill_id,
        |plate,
        |plate_color,
        |task_add_time,
        |plan_depart_time,
        |task_start_time,
        |task_end_time,
        |task_status,
        |tolls_status,
        |task_result,
        |ctfo_task_fee,
        |ft_task_fee,
        |task_err_msg,
        |ft_highway,
        |src_dept,
        |dest_dept,
        |mload,
        |tolls_result_time,
        |plate_color_src,stop_dept,ctfo_result_code,line_code,push_status,task_type,task_type1_src_id,task_type1_update_tm,vehicle_type
        |""".stripMargin).repartition(20)

    //获取千方运单明细表
    val ctfo_record=spark.sql(
      s"""
         |select waybill_id,
         |ctfo_start_time,
         |ctfo_end_time,
         |ctfo_add_time,
         |ctfo_result_time,
         |ctfo_status,
         |ctfo_result,
         |vehicle_type,
         |ctfo_err_msg,
         |src
         |from dm_gis.dm_eta_ctfo_record_dtl_di
         |where inc_day>='$dayvar3' and inc_day<='$dayvar'
         |group by
         |waybill_id,
         |ctfo_start_time,
         |ctfo_end_time,
         |ctfo_add_time,
         |ctfo_result_time,
         |ctfo_status,
         |ctfo_result,
         |vehicle_type,
         |ctfo_err_msg,
         |src
         |""".stripMargin)

    val ctfo_record2=ctfo_record.select("waybill_id","ctfo_result")

    val toll_vehicle=spark.sql(
      """
        |select plate,vehicle_type as vehicle_type_new from dm_gis.eta_std_line_toll_vehicle
        |""".stripMargin)
      .withColumn("rank",row_number().over(Window.partitionBy("plate").orderBy(desc("vehicle_type_new")) ))
      .filter($"rank"===1)
      .drop("rank")

    val result_data0=tolls_record.join(ctfo_record2,Seq("waybill_id"),"left")
      .join(toll_vehicle,Seq("plate"),"left")
      .withColumn("vehicle_type",when($"vehicle_type".isNotNull && trim($"vehicle_type") =!="",$"vehicle_type").
        when($"vehicle_type_new".isNotNull && trim($"vehicle_type_new") =!="",$"vehicle_type_new").otherwise("11"))
      .withColumn("load",when($"vehicle_type"==="11",3.6).
        when($"vehicle_type"==="12",9.6).
        when($"vehicle_type"==="13",9.6).
        when($"vehicle_type"==="14",9.6).
        when($"vehicle_type"==="15",9.6).
        when($"vehicle_type"==="16",9.6).
        otherwise(3.6))
      .withColumn("axis",when($"vehicle_type"==="11",2).
        when($"vehicle_type"==="12",2).
        when($"vehicle_type"==="13",3).
        when($"vehicle_type"==="14",4).
        when($"vehicle_type"==="15",5).
        when($"vehicle_type"==="16",6).
        otherwise(2))
      .withColumn("length",when($"vehicle_type"==="11",5.4).
        when($"vehicle_type"==="12",7.2).
        when($"vehicle_type"==="13",7.2).
        when($"vehicle_type"==="14",7.2).
        when($"vehicle_type"==="15",7.2).
        when($"vehicle_type"==="16",7.2).
        otherwise(5.4))
      .withColumn("weight",when($"vehicle_type"==="11",3.6).
        when($"vehicle_type"==="12",9.6).
        when($"vehicle_type"==="13",9.6).
        when($"vehicle_type"==="14",9.6).
        when($"vehicle_type"==="15",9.6).
        when($"vehicle_type"==="16",9.6).
        otherwise(3.6))

    //清洗task_result和获取接口
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3

    //转化rdd
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, result_data0, calPartitions)

    //并发获取数据结果
    val multi_result=Multi_track_url(spark,sql_Rdd,calPartitions)

    //解析结果
    val multi_result2=multi_result.map(obj=>{
      val task_id =obj.getString("task_id")
      val waybill_id =obj.getString("waybill_id")
      val plate =obj.getString("plate")
      val plate_color =obj.getString("plate_color")
      val task_add_time =obj.getString("task_add_time")
      val plan_depart_time =obj.getString("plan_depart_time")
      val task_start_time =obj.getString("task_start_time")
      val task_end_time =obj.getString("task_end_time")
      val task_status =obj.getString("task_status")
      val tolls_status =obj.getString("tolls_status")
      val task_result =obj.getString("task_result")
      val ctfo_task_fee =obj.getString("ctfo_task_fee")
      val ft_task_fee =obj.getString("ft_task_fee")
      val task_err_msg =obj.getString("task_err_msg")
      val ft_highway =obj.getString("ft_highway")
      val src_dept =obj.getString("src_dept")
      val dest_dept =obj.getString("dest_dept")
      val mload =obj.getString("mload")
      val tolls_result_time =obj.getString("tolls_result_time")
      val plate_color_src =obj.getString("plate_color_src")
      val ctfo_result =obj.getString("ctfo_result")

      val stop_dept =obj.getString("stop_dept")
      val ctfo_result_code =obj.getString("ctfo_result_code")
      val line_code =obj.getString("line_code")
      val push_status =obj.getString("push_status")
      val task_type =obj.getString("task_type")
      val task_type1_src_id =obj.getString("task_type1_src_id")
      val task_type1_update_tm =obj.getString("task_type1_update_tm")

      //计算优惠路桥费
      var discountfee=0.0
      var fee=0.0
      var etc_fee=0.0
      if(ctfo_result !="" && ctfo_result !=null){
        val task_result_json= JSON.parseObject(ctfo_result)
        val body_json= task_result_json.getJSONArray("body")
        val s=body_json.size()
        if(s>0){
          for(i<-0 until(s)){
            val en_time=body_json.getJSONObject(i).getString("enDateTime")
            val ex_time=body_json.getJSONObject(i).getString("exDateTime")
            try{
            if(en_time>=task_start_time && ex_time<=task_end_time){
              val discountfee_i=body_json.getJSONObject(i).getIntValue("discountFee")
              discountfee=discountfee+discountfee_i
//              val fee_i=body_json.getJSONObject(i).getIntValue("fee")
//              fee=fee+fee_i
            }
            }
            catch {
              case e:Exception=>logger.error(e.getMessage)
            }
          }
        }
      }

      //解析接口结果
      val ret = obj.getString( "ret")
      val ret_json= JSON.parseObject(ret)
      var status="1"
      var rate=""
      var highway=""

      try{
        status = ret_json.getString("status")
      }catch {
        case e:Exception =>
          logger.error("接口数据缺失")
      }
      if (status == "0" || status==0) {
         rate = ret_json.getJSONObject("result").getJSONObject("data").getJSONObject("rate").getString("offTime")
         highway = ret_json.getJSONObject("result").getJSONObject("data").getJSONObject("rc_distance").getString("0")
         fee = ret_json.getJSONObject("result").getJSONObject("data").getDouble("tollCharge")
        etc_fee = ret_json.getJSONObject("result").getJSONObject("data").getDouble("etctollCharge")
      }
      tb1(task_id,waybill_id,plate,plate_color,task_add_time,plan_depart_time,task_start_time,
        task_end_time,task_status,tolls_status,task_result,ctfo_task_fee,ft_task_fee,task_err_msg,
        ft_highway,src_dept,dest_dept,mload,tolls_result_time,plate_color_src,rate,highway,discountfee,fee,
        stop_dept,ctfo_result_code,line_code,push_status,task_type,task_type1_src_id,task_type1_update_tm,etc_fee)
    }).toDF()

   val result_data=multi_result2.join(ctfo_record,Seq("waybill_id"),"left")
     .withColumn("inc_day",lit(dayvar))
    //空值处理highway
     .withColumn("highway",when($"highway".isNull || trim($"highway")==="",0).otherwise($"highway"))
     //清洗颜色字段
     .withColumn("plate_color",when($"plate_color"==="0","蓝色").when($"plate_color"==="1","黄色").
       when($"plate_color"==="2","黑色").when($"plate_color"==="3","白色").when($"plate_color"==="4","渐变绿色").
       when($"plate_color"==="5","黄绿双拼色").when($"plate_color"==="6","蓝白渐变色").when($"plate_color"==="7","临时牌照").
       when($"plate_color"==="11","绿色").when($"plate_color"==="12","红色").otherwise($"plate_color"))

    //存储结果表
    val table_cols = spark.sql("""select * from dm_gis.dm_supplier_roadbridge_fees_dtl limit 0""").schema.map(_.name).map(col)
    //存储dm表,每天全量存储
    writeToHive(spark, result_data.select(table_cols: _*) .coalesce(5), Seq("inc_day"), "dm_gis.dm_supplier_roadbridge_fees_dtl")

  }

  //定义样例类
  case class tb1(
                  task_id:String,waybill_id:String,plate:String,plate_color:String,task_add_time:String,plan_depart_time:String,task_start_time:String,
                  task_end_time:String,task_status:String,tolls_status:String,task_result:String,ctfo_task_fee:String,ft_task_fee:String,task_err_msg:String,
                  ft_highway:String,src_dept:String,dest_dept:String,mload:String,tolls_result_time:String,plate_color_src:String,rate:String,highway:String,
                  discountfee:Double, fee:Double,stop_dept:String,ctfo_result_code:String,line_code:String,push_status:String,
                  task_type:String,task_type1_src_id:String,task_type1_update_tm:String,etc_fee:Double
                )

  //定义获取url数据
  def track_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新接口
//    val url="http://gis-vms-core-apis.int.sfcloud.local:8000/trackquery/api/integrateDetail"
    val url="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
    try {

      val un=obj.getString("plate").trim
      val begindatetime=obj.getString("task_start_time").replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")
      val enddatetime=obj.getString("task_end_time").replaceAll("-","")
        .replaceAll(" ","").replaceAll(":","")

      val load=obj.getString("load")
      val axis=obj.getString("axis")
      val weight=obj.getString("weight")
      val length=obj.getString("length")

      val parm_str=s"""{
                      |"ak": "93ec117f7f1b4226b4e537c4802319e9",
                      |"type": "0",
                      |"un": "$un",
                      |"unType": "0",
                      |"hasRate": "true",
                      |"offTime": "120",
                      |"beginDateTime": $begindatetime,
                      |"endDateTime": $enddatetime,
                      |"vehicleInfo":{
                      |"load":$load,
                      |"axis":$axis,
                      |"weight":$weight,
                      |"length":$length
                      |}
                      |}
                      |""".stripMargin

      val retStr: String = sendPost(url,parm_str,20)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
      //logger.info("返回parm_str："+parm_str)
      logger.error("返回正确数据，车牌号："+un)
      //Thread.sleep(100)
    } catch {
      case e: Exception => logger.error(e)
        val tmp = new JSONObject()
        tmp.put("myException",e.getMessage)
        obj.put("ret",tmp)
        obj.put("errmsg",e.getMessage)
        val un=obj.getString("un")
        logger.error("返回错误数据，车牌号："+un)
        logger.error("错误信息："+e.getMessage)
    }
    obj
  }

  //调取接口并发请求
  def Multi_track_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl="http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"
    val httpAk="93ec117f7f1b4226b4e537c4802319e9"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "784750", "供应商路桥费接入",
      "包天包月任务结算时存在人工审核效率低，路桥费举证金额存疑等问题；由gis提供任务路桥费查询接口，避免人工审核提高审核效率以及使用国家路网中心结算路桥费数据确保任务路桥费准确性",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, track_url, 4, "93ec117f7f1b4226b4e537c4802319e9", 2800)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    returnAtRDD
  }

  //往前推n天
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime)
  }

}
