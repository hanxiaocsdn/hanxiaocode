package app.eta

import Utils.SparkUtils.writeToHive
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, SparkUtil, UrlUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel

/**
 *需求名称：竞品流向需求V1.0
 *需求描述：竞品流向，用于制定时速标准，通过车辆停留点的POI和顺丰网点信息，为车辆打上所属公司标签。
 *需求方：廖静文(01430321)
 *开发: 周勇(01390943)
 *任务创建时间：20230518
 *任务id：756490
 **/

object CompetitorFlowMonitor {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._
    val dayvar = args(0)
    logger.error("接收输入变量dayvar:" + dayvar)

    //获取数据源，执行函数将数据拆分存入临时表
    get_data(spark,dayvar)
    //从临时表获取数据
    val splitdata=spark.sql("""select * from dm_gis.dm_highspeed_tmp""")
      .withColumn("x00",split(split($"pp_tl_points_1",",")(0),"[.]")(0))
      .withColumn("x01",split(split($"pp_tl_points_1",",")(0),"[.]")(1))
      .withColumn("y00",split(split($"pp_tl_points_1",",")(1),"[.]")(0))
      .withColumn("y01",split(split($"pp_tl_points_1",",")(1),"[.]")(1))
      .withColumn("x01_tmp",substring($"x01",0,3))
      .withColumn("x01_tmp2",when(length($"x01_tmp")===0,"000")
        .when(length($"x01_tmp")===1,concat($"x01_tmp",lit("00")))
        .when(length($"x01_tmp")===2,concat($"x01_tmp",lit("0"))).otherwise($"x01_tmp"))
      .withColumn("y01_tmp",substring($"y01",0,3))
      .withColumn("y01_tmp2",when(length($"y01_tmp")===0,"000")
        .when(length($"y01_tmp")===1,concat($"y01_tmp",lit("00")))
        .when(length($"y01_tmp")===2,concat($"y01_tmp",lit("0"))).otherwise($"y01_tmp"))
      .withColumn("pp_tl_points_1_flag",concat($"x00",lit("."),$"x01_tmp2",lit(","),$"y00",lit("."),$"y01_tmp2"))
      .repartition(600)
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("splitdata数据量："+splitdata.count())

    //文档4.1计算结果，根据pp_tl_link_1和pp_tl_points_1小数点后3位去重
    val  splitdata2=splitdata.select("pp_tl_roadclass_1","pp_tl_link_1","pp_tl_points_1","pp_tl_roadname_1","inc_day","pp_tl_points_1_flag")
      //删除tl_roadclass_1= 0
      .withColumn("is_del1",when($"pp_tl_roadclass_1"==="0",1).otherwise(0))
      .filter($"is_del1"===0 && $"pp_tl_link_1".isNotNull && trim($"pp_tl_link_1")=!="" && trim($"pp_tl_link_1")=!="~"
        && $"pp_tl_points_1".isNotNull && trim($"pp_tl_points_1")=!="" && trim($"pp_tl_points_1")=!="~" )
      .drop("is_del1")
      .select("pp_tl_roadclass_1","pp_tl_link_1","pp_tl_points_1","pp_tl_roadname_1","inc_day","pp_tl_points_1_flag")
      //根据tl_link_1和pp_tl_points_1小数点后3位去重，随意去重
      .withColumn("rank", row_number().over(Window.partitionBy("pp_tl_link_1","pp_tl_points_1_flag")
        .orderBy(desc("inc_day"))))
      .filter($"rank"===1)
      .drop("rank")
      .repartition(600)

    logger.error("splitdata2数据量："+splitdata2.count())

    //获取顺丰网点数据
    val dpet_data=spark.sql(
      s"""
         |select dept_code,dept_name,concat(longitude,',',latitude) dept_point,concat_ws(':',dept_code,dept_name) dept_code_name,
         |inc_day from dim.dim_dept_info_df
         |where inc_day='${dayvar}' and delete_flg='0'
         |""".stripMargin)

    logger.error("dpet_data数据量："+dpet_data.count())

    //关联计算网点数据
    val dpet_data_str=splitdata2.join(dpet_data,Seq("inc_day"),"left")
      .withColumn("dept_distance",when($"pp_tl_points_1".isNotNull && trim($"pp_tl_points_1") =!="" && $"dept_point".isNotNull && trim($"dept_point") =!=""
        && $"pp_tl_points_1".like("%,%") && $"dept_point".like("%,%"), ceil(getDistance_udf($"pp_tl_points_1",$"dept_point"))).otherwise(99999))
      .filter($"dept_distance"<1000)
      .withColumn("dis_rank", row_number().over(Window.partitionBy("pp_tl_link_1")
        .orderBy(asc("dept_distance"))))
      .withColumn("dis_rank2",concat(lit("index"),lpad($"dis_rank",12,"0")))
      .withColumn("hebing1",concat($"dis_rank2",lit("__"),$"dept_code_name"))
      .withColumn("hebing2",concat($"dis_rank2",lit("__"),$"dept_distance"))
      .groupBy("pp_tl_link_1","pp_tl_points_1_flag")
      .agg(concat_ws("_",sort_array(collect_list($"hebing1"))) as "sf_dept_code_name_tmp",
        concat_ws("_",sort_array(collect_list($"hebing2"))) as "sf_dept_distance_tmp"
      )
      .select(col("*"), expr("regexp_replace(sf_dept_code_name_tmp, 'index([0-9]{12})__', '')").as("sf_dept_code_name"),
        expr("regexp_replace(sf_dept_distance_tmp, 'index([0-9]{12})__', '')").as("sf_dept_distance")
      )
      .drop("sf_dept_code_name_tmp","sf_dept_distance_tmp")
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("dpet_data_str数据量："+dpet_data_str.count())

    //筛选哪些数据要重新调用接口
    val old_data=spark.sql(s"select * from dm_gis.dm_competitorflow_monitor_mid where inc_day<'$dayvar'")
      .withColumn("pp_tl_link_1",$"tl_link_1")
      .withColumn("old_inc_day",$"inc_day")
      .select("pp_tl_link_1","pp_tl_points_1_flag","old_inc_day")

    //    val old_data=spark.sql(s"select * from dm_gis.dm_competitorflow_monitor_mid ")
    //      .withColumn("pp_tl_link_1",$"tl_link_1")
    //      .withColumn("old_inc_day",$"inc_day")
    //      .select("pp_tl_link_1","pp_tl_points_1_flag","old_inc_day")

    logger.error("old_data数据量："+old_data.count())

    val splitdata2_a=splitdata2.join(old_data,Seq("pp_tl_link_1","pp_tl_points_1_flag"),"left")
      .filter($"old_inc_day".isNull)
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("splitdata2_a数据量："+splitdata2_a.count())

    //取出需要访问接口的数据
    val splitdata3=splitdata2_a.select("pp_tl_link_1","pp_tl_points_1","pp_tl_points_1_flag")
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3

    //转化rdd
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, splitdata3, calPartitions)

    //并发获取数据结果
    val mult_result=Multi_point(spark,sql_Rdd,calPartitions)

    //字段解析
    val mult_result_df_0=mult_result.map(obj=>{
      val pp_tl_link_1=obj.getString("pp_tl_link_1")
      val pois_list=obj.getString("pois_list")
      val err_msg=obj.getString("err_msg")
      val pp_tl_points_1=obj.getString("pp_tl_points_1")
      val pp_tl_points_1_flag=obj.getString("pp_tl_points_1_flag")
      (pp_tl_link_1,pois_list,err_msg,pp_tl_points_1,pp_tl_points_1_flag)
    }).toDF("pp_tl_link_1","pois_list","err_msg","pp_tl_points_1","pp_tl_points_1_flag")
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("mult_result_df_0数据量："+mult_result_df_0.count())
    //将接口数据落库表
    writeToHive(spark, mult_result_df_0.withColumn("inc_day",lit(dayvar)) , Seq("inc_day"), "dm_gis.dm_highspeed_poi_dtl")

    logger.error("将接口数据落库表：dm_highspeed_poi_dtl")

    val mult_result_df=mult_result_df_0
      .withColumn("pois_list",
        when($"pois_list".isNull || trim($"pois_list")==="","").otherwise(regexp_replace(regexp_replace($"pois_list","\\[|\\]",""),"\\},\\{","\\}\\|\\{")))
      .withColumn("pois_detail",explode(split($"pois_list","[|]")))
      .drop("pois_list")
      .withColumn("poi_name",get_json_object($"pois_detail","$.name"))
      .withColumn("poi_distance",when(get_json_object($"pois_detail","$.distance").isNotNull
        && trim(get_json_object($"pois_detail","$.distance"))=!="",ceil(get_json_object($"pois_detail","$.distance").cast("double"))
      ).otherwise("-"))
      .drop("pois_detail")
      .withColumn("poi_company",when($"poi_name".like("%京东%") || $"poi_name".like("%德邦%"),"jd&db").
        when($"poi_name".like("%菜鸟%") || $"poi_name".like("%百世%"),"alibaba").
        when($"poi_name".like("%申通%") || $"poi_name".like("%中通%") || $"poi_name".like("%圆通%") || $"poi_name".like("%韵达%"),"3t1d").
        when($"poi_name".like("%普洛斯%"),"pls").
        when($"poi_name".like("%极兔%") || $"poi_name".like("%天天快递%") || $"poi_name".like("%顺心捷达%"),"qt").
        when($"poi_name".like("%物流%") || $"poi_name".like("%快递%") || $"poi_name".like("%电商%") || $"poi_name".like("%运输%"),"kd&wl&ds&ys").
        otherwise("-")
      )
      .withColumn("jp_poi_name_company",concat($"poi_name",lit(":"),$"poi_company"))
      .withColumn("poi_distance",when($"poi_company"==="-","-").otherwise($"poi_distance"))
      .withColumn("poi_distance_tmp",when($"poi_distance"==="-",99999).otherwise($"poi_distance"))
      .withColumn("dis_rank2",concat(lit("index"),lpad($"poi_distance_tmp",12,"0")))
      .withColumn("hebing1",concat($"dis_rank2",lit("__"),$"jp_poi_name_company"))
      .withColumn("hebing2",concat($"dis_rank2",lit("__"),$"poi_distance"))

    logger.error("mult_result_df数据量："+mult_result_df.count())

    //poi聚合汇总
    val mult_result_df2=mult_result_df
      .groupBy("pp_tl_link_1","pp_tl_points_1_flag")
      .agg(concat_ws("_",sort_array(collect_list($"hebing1"))) as "jp_poi_name_company_tmp",
        concat_ws("_",sort_array(collect_list($"hebing2"))) as "poi_distance_tmp"
      )
      .select(col("*"), expr("regexp_replace(jp_poi_name_company_tmp, 'index([0-9]{12})__', '')").as("jp_poi_name_company"),
        expr("regexp_replace(poi_distance_tmp, 'index([0-9]{12})__', '')").as("jp_poi_distance")
      )
      .drop("jp_poi_name_company_tmp","poi_distance_tmp")

    logger.error("mult_result_df2数据量："+mult_result_df2.count())

    //合并顺丰网点和POI信息
    val data_hebing=splitdata2.select("pp_tl_link_1","pp_tl_points_1_flag").join(dpet_data_str,Seq("pp_tl_link_1","pp_tl_points_1_flag"),"left")
      .join(mult_result_df2,Seq("pp_tl_link_1","pp_tl_points_1_flag"),"left")
      .na.fill("-",Seq("sf_dept_code_name","jp_poi_name_company","sf_dept_distance","jp_poi_distance"))
      .withColumn("company_name_list",concat_ws("|",$"sf_dept_code_name",$"jp_poi_name_company"))
      .withColumn("company_distance_list",concat_ws("|",$"sf_dept_distance",$"jp_poi_distance"))

      .withColumn("sf_min_distance",split($"sf_dept_distance","_")(0))
      .na.fill("-",Seq("sf_min_distance"))
      .withColumn("sf_min_name",split($"sf_dept_code_name","_")(0))
      .withColumn("sf_min_distance",when($"sf_min_distance"==="-" || $"sf_min_distance".cast("double")>500,"-").otherwise($"sf_min_distance"))
      .withColumn("sf_min_name",when($"sf_min_distance"==="-" || $"sf_min_distance".cast("double")>500,"-").otherwise($"sf_min_name"))

      .withColumn("jp_min_distance",split($"jp_poi_distance","_")(0))
      .na.fill("-",Seq("jp_min_distance"))
      .withColumn("jp_min_name",split($"jp_poi_name_company","_")(0))
      .withColumn("jp_min_distance",when($"jp_min_distance"==="-" || $"jp_min_distance".cast("double")>500,"-").otherwise($"jp_min_distance"))
      .withColumn("jp_min_name",when($"jp_min_distance"==="-" || $"jp_min_distance".cast("double")>500,"-").otherwise($"jp_min_name"))

      .withColumn("company_name",when($"sf_min_distance"==="-" && $"jp_min_distance"==="-","-").
        when($"sf_min_distance"=!="-" && $"jp_min_distance"==="-",$"sf_min_name").
        when($"sf_min_distance"==="-" && $"jp_min_distance"=!="-",$"jp_min_name").
        when($"sf_min_distance".cast("double")>$"jp_min_distance".cast("double"),$"jp_min_name").otherwise($"sf_min_name"))

      .withColumn("company_distance",when($"sf_min_distance"==="-" && $"jp_min_distance"==="-","-").
        when($"sf_min_distance"=!="-" && $"jp_min_distance"==="-",$"sf_min_distance").
        when($"sf_min_distance"==="-" && $"jp_min_distance"=!="-",$"jp_min_distance").
        when($"sf_min_distance".cast("double")>$"jp_min_distance".cast("double"),$"jp_min_distance").otherwise($"sf_min_distance"))

      .withColumn("company_label",when($"sf_min_distance"==="-" && $"jp_min_distance"==="-","-").
        when($"sf_min_distance"=!="-" && $"jp_min_distance"==="-","sf").
        when($"sf_min_distance"==="-" && $"jp_min_distance"=!="-","jp").
        when($"sf_min_distance".cast("double")>$"jp_min_distance".cast("double"),"jp").otherwise("sf"))

    logger.error("data_hebing数据量："+data_hebing.count())

    //存储中间表
    val table_cols1 = spark.sql("""select * from dm_gis.dm_competitorflow_monitor_mid limit 0""").schema.map(_.name).map(col)

    val mid_data=splitdata2_a.join(data_hebing,Seq("pp_tl_link_1","pp_tl_points_1_flag"),"left")
      .withColumn("tl_link_1",$"pp_tl_link_1")
      .withColumn("tl_roadclass_1",$"pp_tl_roadclass_1")
      .withColumn("tl_points_1",$"pp_tl_points_1")
      .withColumn("tl_roadname_1",$"pp_tl_roadname_1")
      .withColumn("company_name",when($"company_name".isNull || trim($"company_name")==="","-").otherwise($"company_name"))
      .withColumn("company_label",when($"company_label".isNull || trim($"company_label")==="","-").otherwise($"company_label"))
      .withColumn("company_distance",when($"company_distance".isNull || trim($"company_distance")==="","-").otherwise($"company_distance"))
      .coalesce(1)
      .select(table_cols1: _*)

    logger.error("mid_data数据量："+mid_data.count())
    //存储dm表,每天增量存储
    writeToHive(spark, mid_data , Seq("inc_day"), "dm_gis.dm_competitorflow_monitor_mid")

    //释放内存
    splitdata2_a.unpersist()

    logger.error("存储dm表：dm_competitorflow_monitor_mid")

    //全量存一个表
    val mid_all=spark.sql(
      s"""select * from dm_gis.dm_competitorflow_monitor_mid
         |where inc_day<='$dayvar'
         |""".stripMargin)
      .withColumn("inc_day",lit(dayvar))
    //存储dm表,每天全量存储
    writeToHive(spark, mid_all.select(table_cols1: _*) , Seq("inc_day"), "dm_gis.eta_track_highway_detail_3d_with_328_city_poi")

    logger.error("mid_data数据量："+mid_all.count())

    //获取全量表
    val all_links=spark.sql(
      s"""select * from dm_gis.eta_track_highway_detail_3d_with_328_city_poi
         |where inc_day='$dayvar'
         |""".stripMargin)
      .drop("inc_day")

    logger.error("all_links数据量："+all_links.count())

    //拼接全量数据
    val resdata= splitdata.withColumn("tl_link_1",$"pp_tl_link_1")
      .join(all_links,Seq("tl_link_1","pp_tl_points_1_flag"),"left")
      .na.fill("-",Seq("company_name","company_label","company_distance"))
      .withColumn("dis_rank2",concat(lit("index"),lpad($"rk1",12,"0")))
      .withColumn("hebing1",concat($"dis_rank2",lit("__"),$"company_name"))
      .withColumn("hebing2",concat($"dis_rank2",lit("__"),$"company_label"))
      .withColumn("hebing3",concat($"dis_rank2",lit("__"),$"company_distance"))

    logger.error("resdata数据量："+resdata.count())

    val resdata2=resdata
      .groupBy("un","highspeed_start_time","highspeed_end_time","inc_day")
      .agg(concat_ws("|",sort_array(collect_list($"hebing1"))) as "un_company_name_tmp",
        concat_ws("|",sort_array(collect_list($"hebing2"))) as "un_company_label_tmp",
        concat_ws("|",sort_array(collect_list($"hebing3"))) as "un_company_distance_tmp"
      )

    logger.error("resdata2数据量："+resdata2.count())

    val resdata3=resdata2
      .select(col("*"), expr("regexp_replace(un_company_name_tmp, 'index([0-9]{12})__', '')").as("un_company_name"),
        expr("regexp_replace(un_company_label_tmp, 'index([0-9]{12})__', '')").as("un_company_label"),
        expr("regexp_replace(un_company_distance_tmp, 'index([0-9]{12})__', '')").as("un_company_distance"))
      .drop("un_company_name_tmp","un_company_label_tmp","un_company_distance_tmp")
      .withColumn("final_company",when($"un_company_label".isNull || trim($"un_company_label")==="","-").otherwise(countsfjp_udf($"un_company_label")))
      .coalesce(10)
      .select("un"	,"highspeed_start_time"	,"highspeed_end_time",	"un_company_name",	"un_company_label",	"un_company_distance"	,"final_company","inc_day")

    logger.error("resdata3数据量："+resdata3.count())

    //存储dm表
    writeToHive(spark, resdata3 , Seq("inc_day"), "dm_gis.dm_competitorflow_monitor_dtl")

    logger.error("执行完毕！")

    spark.close()
  }

  //获取数据源
  def get_data(spark:SparkSession,dayvar:String): Unit ={
    import spark.implicits._
    //时速标准全国流向数据
    val track_highway_sql=
      s"""
         |select un,highspeed_start_time,highspeed_end_time,
         |tl_roadclass_1, tl_link_1,tl_points_1,tl_roadname_1,inc_day
         |from dm_gis.eta_track_highway_detail_3d_with_328_city
         |where inc_day='${dayvar}'
         |""".stripMargin

    //测试的5000条数据
    //    val track_highway_sql=
    //      s"""
    //         |select un,highspeed_start_time,highspeed_end_time,
    //         |tl_roadclass_1, tl_link_1,tl_points_1,tl_roadname_1,inc_day
    //         |from dm_gis.dm_competitorflow_x1
    //         |""".stripMargin

    val track_highway=spark.sql(track_highway_sql)
      .withColumn("tl_roadclass_1",when($"tl_roadclass_1".isNull || trim($"tl_roadclass_1")==="","~").otherwise($"tl_roadclass_1"))
      .withColumn("tl_link_1",when($"tl_link_1".isNull || trim($"tl_link_1")==="","~").otherwise($"tl_link_1"))
      .withColumn("tl_points_1",when($"tl_points_1".isNull || trim($"tl_points_1")==="","~").otherwise($"tl_points_1"))
      .withColumn("tl_roadname_1",when($"tl_roadname_1".isNull || trim($"tl_roadname_1")==="","~").otherwise($"tl_roadname_1"))
      .persist(StorageLevel.MEMORY_AND_DISK)

    track_highway.createOrReplaceTempView("track_highway_tb")

    //列转行，数据拆分
    spark.sql(
      """
        |insert overwrite table dm_gis.dm_highspeed_tmp
        | select un,highspeed_start_time,highspeed_end_time,inc_day,rk1,
        |pp_tl_roadclass_1,pp_tl_link_1,pp_tl_points_1,pp_tl_roadname_1
        |from (
        |select un,highspeed_start_time,highspeed_end_time,inc_day,
        |split(tl_roadclass_1,'\\|') as pp_list1,
        |split(tl_link_1,'\\|') as pp_list2,
        |split(tl_points_1,'\\|') as pp_list3,
        |split(tl_roadname_1,'\\|') as pp_list4
        |from  track_highway_tb
        |) a
        | lateral VIEW posexplode(pp_list1) list_tab1 AS rk1,pp_tl_roadclass_1
        |  lateral VIEW posexplode(pp_list2) list_tab2 AS rk2,pp_tl_link_1
        |   lateral VIEW posexplode(pp_list3) list_tab3 AS rk3,pp_tl_points_1
        |   lateral VIEW posexplode(pp_list4) list_tab4 AS rk4,pp_tl_roadname_1
        | where rk1=rk2 and rk1=rk3 and rk1=rk4
        |""".stripMargin)

    //释放内存
    track_highway.unpersist()
  }

  //计算sf和jp的数量
  def countsfjp(sxtr:String): String ={
    val sxtr_ar=sxtr.split("[|]")
    val l=sxtr_ar.size
    var i=0
    var j=0
    for(k<-0 until l){
      if(sxtr_ar(k)=="sf"){i=i+1}
      else if(sxtr_ar(k)=="jp"){j=j+1}
      else{
        i=i
        j=j}
    }
    if(i>=j && i !=0){return "sf"}
    else if (i<j && j !=0){return "jp"}
    else {return "_"}
  }

  val countsfjp_udf=udf(countsfjp _)

  //定义获取url数据
  def Point_url(ak:String,obj:JSONObject): JSONObject = {
    try {
      //获取json的时间，进行转化
      val pp_tl_points_1: String = obj.getString("pp_tl_points_1")
      //设置入参
      val point_0=pp_tl_points_1.split(",")(0).trim
      val point_1=pp_tl_points_1.split(",")(1).trim
      val ak="6ee0d6b978714edab5d099c70a3121a0"
      val url=s"http://gis-int.int.sfdc.com.cn:1080/rgeo/api?opt=sf1&ak=$ak&x=$point_0&y=$point_1"
      val retStr: String = HttpInvokeUtil.sendGet(url,"UTF-8",10)
      val ret: JSONObject = JSON.parseObject(retStr)
      obj.put("ret",ret)
      //解析pois
      val result_data=ret.getString("result")
      val status=ret.getString("status")
      logger.error("获取接口成功")
      try{
        val result_data_js: JSONObject = JSON.parseObject(result_data)
        val pois_list=result_data_js.getJSONArray("pois")
        obj.put("pois_list",pois_list)
      }catch{
        case e: Exception => logger.error(e)
          obj.put("err_msg2",e.getMessage)
      }

      //存入错误信息
      if(status=="1" || status==1){obj.put("err_msg",ret)}

      //Thread.sleep(1*1000)
    } catch {
      case e: Exception => logger.error(e)
        logger.error("获取接口失败："+e.getMessage)
        obj.put("err_msg3",e.getMessage)
    }
    obj
  }


  //调取接口并发请求
  def Multi_point(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {

    //调用开始上报
    val httpUrl="http://gis-int.int.sfdc.com.cn:1080/rgeo/api?opt=sf1"
    val httpAk="6ee0d6b978714edab5d099c70a3121a0"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "756490", "竞品流向需求",
      "竞品流向，用于制定时速标准，通过车辆停留点的POI和顺丰网点信息，为车辆打上所属公司标签。",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, Point_url, 8, "6ee0d6b978714edab5d099c70a3121a0", 2900)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    returnAtRDD
  }

  //计算地图距离:m
  def rad(d: Double): Double = d * Math.PI / 180.0
  def getDistance(x:String,y:String): Double = {
    val lat1=x.split(",")(1).toDouble
    val lng1=x.split(",")(0).toDouble
    val lat2=y.split(",")(1).toDouble
    val lng2=y.split(",")(0).toDouble

    val EARTH_RADIUS: Double = 6378.137
    val radLat1: Double = rad(lat1)
    val radLat2: Double = rad(lat2)
    val a: Double = radLat1 - radLat2
    val b: Double = rad(lng1) - rad(lng2)
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(b / 2), 2)))
    s = s * EARTH_RADIUS
    s = s * 10000d.round / 10000d
    s = s * 1000
    s
  }
  val getDistance_udf=udf(getDistance _)

}
