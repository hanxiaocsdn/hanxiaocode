package app.eta

import Utils.{DateTimeUtil, JSONUtils, MD5Util, SparkUtils, StringUtil}

import java.text.SimpleDateFormat
import java.util
import java.util.Date
import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.eta.constant.StandardRouteMileage.DistanceTool
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/*
* 导航SDK-ETA指标监控需求(陈晨)
*/
object NaviSdkEtaIndexMonitor2 extends Serializable {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val funcMap = new util.HashMap[String,String]()

  val descMysqlUserName = "gis_oms_pns"
  val descMysqlPassWord = "gis_oms_pns@123@"
  val descMysqlUrl = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?characterEncoding=utf-8"

  /*p1*/
  //点选率
  val clickRateStatisticsSourTable1 = "dm_gis.gis_navi_eta_result1"
  val clickRateStatisticsSourTable2 = "dm_gis.gis_navi_top3_click_route"

  val clickRateStatisticsDescTable = "ETA_INDEX_CLICK_RATE_STATISTICS2"
  val clickRateStatisticsDescMysqlTable = "ETA_INDEX_CLICK_RATE_STAT2"


  //一致率
  val consistentSourTable1 = "gis_navi_eta_result_tmp"
  val reqAccStatisticsDescTable = "ETA_INDEX_CONSISTENT_REQACC_STATISTICS2"
  val reqAccStatisticsDescMysqlTable = "ETA_INDEX_CONSISTENT_REQACC_STAT2"

  //导航用户量
  val reqUserStatisticsDescTable = "ETA_INDEX_USER_STATISTICS"
  val reqUserStatisticsMysqlTable = "ETA_INDEX_USER_STATISTICS"

  //导航新增用户量
  val reqNewUserAddStatisticsDescTable = "ETA_INDEX_NEW_USER_ADD_STATISTICS"
  val reqNewUserAddStatisticsMysqlTable = "ETA_INDEX_NEW_USER_ADD_STATISTICS"

  //活跃率
  val reqActiveTable = "GIS_NAVI_ETA_ACTIVE_RESULT"

  //任务漏斗统计
  val reqFunnelTable = "GIS_NAVI_ETA_FUNNEL_RESULT"
  val reqFunnelTable2 = "GIS_NAVI_ETA_DURATION_DISTRIBUTE"

  //consistentRdd,coincidenceRdd
  val top3ConsistentTable = "ETA_INDEX_TOP3_CONSISTENT"
  val top3CoincidenceTable = "ETA_INDEX_TOP3_COINCIDENCE"

  val top1ConsistentTable = "ETA_INDEX_TOP1_CONSISTENT"
  val top1CoincidenceTable = "ETA_INDEX_TOP1_COINCIDENCE"

  //留存率统计
  val rententRateTable = "GIS_NAVI_ETA_INDEX_RENTENT_RATE"
  val rententRateTable2 = "GIS_NAVI_ETA_INDEX_RENTENT_RATE_MONTH"

  val rententRateMysqlTable = "GIS_NAVI_ETA_INDEX_RENTENT_RATE"
  val rententRateMysqlTable2 = "GIS_NAVI_ETA_INDEX_RENTENT_RATE_MONTH"


  def init ( incDay:String )={
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    //p1
    funcMap.put("点击率","processClickRateStatistics")
    funcMap.put("一致率","processConsistentStatistics")
    funcMap.put("活跃率","processActiveStatistics")
    funcMap.put("任务漏斗统计","processFunnelStatistics")
    funcMap.put("top3一致率","processTop3ConsistentStatistics")
    funcMap.put("top1一致率","processTop1ConsistentStatistics")
    funcMap.put("留存率","processRetentionRateStatistics")
    funcMap.put("导航用户量统计","processUserCountStatistics")
    funcMap.put("导航新增用户量统计","processNewAddUserCountStatistics")

    logger.error("合并导航结果表")

    val querySql =
      s"""
         |select
         |    src_province,
         |    src_citycode,
         |    src_deptcode,
         |    dest_province,
         |    dest_citycode,
         |    dest_deptcode,
         |    ft_right,
         |    tl_ft_right,
         |    src,
         |    duration,
         |    plan_date,
         |    t1.routeid as routeId,
         |    req_order,
         |    similarity1,
         |    similarity5,
         |    navi_endstatus,
         |    t1.req_type,
         |    diff_time,
         |    navi_time,
         |    t1.request_id,
         |    t1.req_time,
         |    t1.navi_endtime,
         |    t1.inc_day,
         |    req_status,
         |    distance,
         |    route_order,
         |    req_order,
         |    t1.navi_id,
         |    t1.task_id
         |from (
         |    select * from dm_gis.gis_navi_eta_result1 where inc_day='$incDay'
         |) t1
         |inner join (
         |    select * from dm_gis.gis_navi_eta_result2 where inc_day='$incDay'
         |) t2
         |on t1.id = t2.id
         |""".stripMargin

    logger.error(querySql)

    spark.sql(querySql).createOrReplaceTempView("gis_navi_eta_result_tmp")

    spark
  }

  def main(args: Array[String]): Unit = {
    val spark = init( args(0) )

    start(spark,args)

    spark.close()
  }

  /*
  *p1
  */

  //点选率映射
  val clickRateSchema = StructType(List(

    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("province", StringType, true),
    StructField("citycode", StringType, true),
    StructField("navi_amount", IntegerType, true),
    StructField("tradition_amount", IntegerType, true),
    StructField("experience_amount", IntegerType, true),
    StructField("gd_amount", IntegerType, true),
    StructField("save_amount", IntegerType, true),
    StructField("top3_amount", IntegerType, true),
    StructField("yaw_amount", IntegerType, true),

    StructField("recommend_amount", IntegerType, true),
    StructField("time_priority_amount", IntegerType, true),
    StructField("cost_priority_amount", IntegerType, true),
    StructField("distance_priority_amount", IntegerType, true),
    StructField("highway_priority_amount", IntegerType, true),
    StructField("avoidance_priority_amount", IntegerType, true),

    StructField("own_driver_amount", IntegerType, true),
    StructField("other_driver_amount", IntegerType, true),

    StructField("firstway_amount", IntegerType, true),
    StructField("secondway_amount", IntegerType, true),
    StructField("thirdway_amount", IntegerType, true),
    StructField("other_amount", IntegerType, true)
  ))



  //一致率统计映射
  //sim1And5Rowid,incDay,dest_province,dest_citycode,srcMap,req_type,gap_sum,"sim1And5",reqAmount,sim1And5NullReqAmount
//  val reqAccSchema = StructType(List(
//    StructField("id", StringType, true),
//    StructField("statdate", StringType, true),
//    StructField("province", StringType, true),
//    StructField("citycode", StringType, true),
//    StructField("src", StringType, true),
//    StructField("req_type", StringType, true),
//    StructField("gap_sum", StringType, true),
//    StructField("simtype", StringType, true),
//    StructField("req_amount", IntegerType, true),
//    StructField("SIM1AND5_NULL_REQAMOUNT", IntegerType, true),
//    StructField("PERCENT100_REQ_AMOUNT", IntegerType, true),
//    StructField("PERCENT80_REQ_AMOUNT", IntegerType, true)
//  ))


  val reqAccSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("province", StringType, true),
    StructField("citycode", StringType, true),
    StructField("src", StringType, true),
    StructField("totalcnt", IntegerType, true),
    StructField("gapsum5", IntegerType, true),
    StructField("gapsum10", IntegerType, true),
    StructField("gapsum15", IntegerType, true),
    StructField("gapsum20", IntegerType, true),
    StructField("gapsum25", IntegerType, true),
    StructField("gapsum30", IntegerType, true),
    StructField("gapsumother", IntegerType, true),
    StructField("sim1", IntegerType, true),
    StructField("sim5", IntegerType, true),
    StructField("sim15", IntegerType, true)
  ))

  val reqUserSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("drivertype", StringType, true),
    StructField("serviceid", StringType, true),
    StructField("sumcnt", IntegerType, true)
  ))


  val reqWaySimSchema =  StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("province", StringType, true),
    StructField("citycode", StringType, true),
    StructField("sitecode", StringType, true),
    StructField("compensate", StringType, true),
    StructField("index_type", StringType, true),
    StructField("src", StringType, true),
    StructField("simtype", StringType, true),
    StructField("reqamount", IntegerType, true),
    StructField("correctamount", IntegerType, true),
    StructField("halfhour_reqamount", IntegerType, true),
    StructField("halfhour_correctamount", IntegerType, true),
    StructField("onehour_reqamount", IntegerType, true),
    StructField("onehour_correctamount", IntegerType, true),
    StructField("req1_amount", IntegerType, true),
    StructField("req2_amount", IntegerType, true),
    StructField("req3_amount", IntegerType, true),
    StructField("req4_amount", IntegerType, true),
    StructField("req5_amount", IntegerType, true),
    StructField("req6_amount", IntegerType, true),
    StructField("req7_amount", IntegerType, true),
    StructField("req8_amount", IntegerType, true),
    StructField("req9_amount", IntegerType, true),
    StructField("req10_amount", IntegerType, true),
    StructField("req11_amount", IntegerType, true),
    StructField("req12_amount", IntegerType, true),
    StructField("req13_amount", IntegerType, true),
    StructField("req14_amount", IntegerType, true),
    StructField("req15_amount", IntegerType, true),
    StructField("req16_amount", IntegerType, true),
    StructField("req17_amount", IntegerType, true),
    StructField("req18_amount", IntegerType, true),
    StructField("req19_amount", IntegerType, true),
    StructField("req20_amount", IntegerType, true),
    StructField("req21_amount", IntegerType, true),
    StructField("req22_amount", IntegerType, true),
    StructField("req23_amount", IntegerType, true),
    StructField("req24_amount", IntegerType, true),
    StructField("correct1_amount", IntegerType, true),
    StructField("correct2_amount", IntegerType, true),
    StructField("correct3_amount", IntegerType, true),
    StructField("correct4_amount", IntegerType, true),
    StructField("correct5_amount", IntegerType, true),
    StructField("correct6_amount", IntegerType, true),
    StructField("correct7_amount", IntegerType, true),
    StructField("correct8_amount", IntegerType, true),
    StructField("correct9_amount", IntegerType, true),
    StructField("correct10_amount", IntegerType, true),
    StructField("correct11_amount", IntegerType, true),
    StructField("correct12_amount", IntegerType, true),
    StructField("correct13_amount", IntegerType, true),
    StructField("correct14_amount", IntegerType, true),
    StructField("correct15_amount", IntegerType, true),
    StructField("correct16_amount", IntegerType, true),
    StructField("correct17_amount", IntegerType, true),
    StructField("correct18_amount", IntegerType, true),
    StructField("correct19_amount", IntegerType, true),
    StructField("correct20_amount", IntegerType, true),
    StructField("correct21_amount", IntegerType, true),
    StructField("correct22_amount", IntegerType, true),
    StructField("correct23_amount", IntegerType, true),
    StructField("correct24_amount", IntegerType, true)
  ))

  // TODO: 活跃率统计
  val reqActiveSchema =  StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("curDayActiveCnt",IntegerType , true),
    StructField("curMonthSumCnt", IntegerType, true),
    StructField("allSumCnt", IntegerType, true),
    StructField("allUserNum", IntegerType, true)
  ))


  // TODO: 任务漏斗统计

  //nv_type,slCnt,sdkCnt,halfwayCnt,ontimeCnt,staCnt,sfCnt,inc_day
  val reqFunnelSchema =  StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("nv_type", StringType, true),
    StructField("slCnt", IntegerType, true),
    StructField("sdkCnt", IntegerType, true),
    StructField("halfWayCnt", IntegerType, true),
    StructField("ontimeCnt", IntegerType, true),
    StructField("staCnt", IntegerType, true),
    StructField("sfCnt", IntegerType, true)
  ))


  //ratioCluster,slCnt,halfwayCnt,ontimeCnt,incDay
  val reqFunnelSchema2 =  StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("ratioCluster", StringType, true),
    StructField("slCnt", IntegerType, true),
    StructField("halfWayCnt", IntegerType, true),
    StructField("ontimeCnt", IntegerType, true)
  ))

  // TODO: top3一致率统计

  //src, totalCnt, sim1Cnt, sim5Cnt, sim1AndSim5Cnt
  val reqTop3AccSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("src", StringType, true),
    StructField("totalCnt", IntegerType, true),
    StructField("sim1Cnt", IntegerType, true),
    StructField("sim5Cnt", IntegerType, true),
    StructField("sim1AndSim5Cnt", IntegerType, true)
  ))
  // TODO: top3吻合率统计

  val reqTop3coincidenceSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("src", StringType, true),
    StructField("totalCnt", IntegerType, true),
    StructField("gapSum5Cnt", IntegerType, true),
    StructField("gapSum10Cnt", IntegerType, true),
    StructField("gapSum15Cnt", IntegerType, true),
    StructField("gapSum20Cnt", IntegerType, true),
    StructField("gapSum25Cnt", IntegerType, true),
    StructField("gapSum30Cnt", IntegerType, true),
    StructField("gapSumOtherCnt", IntegerType, true)
  ))


  // TODO: top1一致率统计

  //src, totalCnt, sim1Cnt, sim5Cnt, sim1AndSim5Cnt
  val reqTop1AccSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("src", StringType, true),
    StructField("routeIndex", StringType, true),
    StructField("totalCnt", IntegerType, true),
    StructField("sim1Cnt", IntegerType, true),
    StructField("sim5Cnt", IntegerType, true),
    StructField("sim1AndSim5Cnt", IntegerType, true)
  ))
  // TODO: top1吻合率统计

  val reqTop1coincidenceSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("src", StringType, true),
    StructField("routeIndex", StringType, true),
    StructField("totalCnt", IntegerType, true),
    StructField("gapSum5Cnt", IntegerType, true),
    StructField("gapSum10Cnt", IntegerType, true),
    StructField("gapSum15Cnt", IntegerType, true),
    StructField("gapSum20Cnt", IntegerType, true),
    StructField("gapSum25Cnt", IntegerType, true),
    StructField("gapSum30Cnt", IntegerType, true),
    StructField("gapSumOtherCnt", IntegerType, true)
  ))



  // TODO: 留存率统计
  //id,inc_day,nextDayRetent,nextMonRetent,newNextDayRetent,newNextMonRetent
  val rententRateSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("nextDayRetent", DoubleType, true),
    StructField("newNextDayRetent", DoubleType, true)
  ))

  val rententRateSchema2 = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("nextMonthRetent", DoubleType, true),
    StructField("newNextMonthRetent", DoubleType, true)
  ))


  val getSrcMap = (json:JSONObject) => json.getString("src") match {
    case "rp-my" => "传统"
    case "sf" => "传统"
    case "rp-jy-full" => "经验"
    case "rp-jy" => "经验"
    case "rp-jy-art" => "经验"
    case "rp-jy-fixed" => "经验"
    case "jy" => "经验"
    case "gd" => "高德"
    case "rp-gd" => "高德"
    case "isEcon" => "省钱|省里程路线"
    case _ => ""
  }


  /*process*/
  /*p0*/
  def processClickRateStatistics( spark:SparkSession,incDay:String,yesterday:String ):Unit={
    logger.error(">>>开始统计:ETA指标-点击率<<<")

    //从Top3点选线路的ETA结果表读取数据
    val querysql =
      s"""
         |select
         | b.dest_province,
         | b.dest_citycode,
         | a.navi_id,
         | a.route_index,
         | a.req_type,
         | a.src,
         | a.strategy,
         | a.driver_type,
         | a.route_index
         |from
         |    (
         |    select
         |        *
         |    from
         |        ${clickRateStatisticsSourTable1}
         |    where
         |        inc_day  ='${incDay}'
         |    ) a
         |inner join
         |    (
         |    select
         |        dest_province,dest_citycode,navi_id
         |    from
         |        ${clickRateStatisticsSourTable2}
         |    where
         |        inc_day = '${incDay}'
         |    and
         |      dest_province != ''
         |    and
         |      dest_citycode != ''
         |    ) b
         |on a.navi_id = b.navi_id
         |""".stripMargin

    logger.error(querysql)

    val sourRdd = SparkUtils.getRowToJson(spark.sql(querysql)).map(
      obj => {
        val dest_province = if (StringUtil.isBlank(obj.getString("dest_province"))) "other" else obj.getString("dest_province")
        val dest_citycode = if (StringUtil.isBlank(obj.getString("dest_citycode"))) "other" else obj.getString("dest_citycode")
        ((dest_province,dest_citycode),obj)
      }
    ).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共获取从Top3点选线路的ETA数据共:${sourRdd.count()}")

    //统计点选指标
    val clickRateRdd = doClickRateStatistics(sourRdd,incDay)

    //保存到hive
    SparkUtils.df2Hive(spark,clickRateRdd,clickRateSchema,"append","dm_gis."+clickRateStatisticsDescTable,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,clickRateRdd,clickRateSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,clickRateStatisticsDescMysqlTable,incDay,logger)

    clickRateRdd.unpersist()
  }


  def getFilterDistance(sourRdd1: RDD[JSONObject],dataType: String) = {

    // TODO: 增加异常路线剔除逻辑：轨迹起点、终点/路线起点、终点距离大于1km ；“max（路线距离、导航距离）/mix（路线距离、导航距离）”>3的样本
   val sourRdd2 = sourRdd1.map(obj => {

      var filterTag = 0
      val x1 = JSONUtils.getJsonValueDouble(obj,"x1",0)
      val y1 = JSONUtils.getJsonValueDouble(obj,"y1",0)
      val x2 = JSONUtils.getJsonValueDouble(obj,"x2",0)
      val y2 = JSONUtils.getJsonValueDouble(obj,"y2",0)

      val starts_x = JSONUtils.getJsonValueDouble(obj,"starts_x",0)
      val starts_y = JSONUtils.getJsonValueDouble(obj,"starts_y",0)
      val ends_x = JSONUtils.getJsonValueDouble(obj,"ends_x",0)
      val ends_y = JSONUtils.getJsonValueDouble(obj,"ends_y",0)

      val distance = JSONUtils.getJsonValueDouble(obj,"distance",0)
      val navi_distance = JSONUtils.getJsonValueDouble(obj,"navi_distance",0)

      val maxDist = Math.max(distance,navi_distance)
      val minDist = Math.min(distance,navi_distance)

      if (DistanceTool.getGreatCircleDistance(x1, y1, starts_x, starts_y) > 1000 || DistanceTool.getGreatCircleDistance(x2, y2, ends_x, ends_y) > 1000) {
        filterTag = 1
      } else if ((maxDist / minDist) > 3) {
        filterTag = 1
      }
      obj.put("filterTag",filterTag)

      obj
    })
      .filter(obj => {
        0 == obj.getIntValue("filterTag")
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(dataType + " " + "sourRdd2的数据量为：" + sourRdd2.count())
    sourRdd2.take(2).foreach(println(_))

    val sourRdd = sourRdd2
      .map(obj => {
        val dest_province = obj.getString("dest_province")
        val dest_citycode = obj.getString("dest_citycode")
        val src = obj.getString("src")
        val srcMap = getSrcMap(obj)

        // TODO: 增加req_type的统计和gap_sum的统计
        (Seq(dest_province,dest_citycode,srcMap),obj)
      }).persist(StorageLevel.DISK_ONLY)
    logger.error(dataType + " " + s"按请求获取汇总结果:${sourRdd.count()}")

    sourRdd

  }


  def getFilterDistanceTop3(sourRdd1: RDD[JSONObject],dataType: String) = {

    // TODO: 增加异常路线剔除逻辑：轨迹起点、终点/路线起点、终点距离大于1km ；“max（路线距离、导航距离）/mix（路线距离、导航距离）”>3的样本
    val sourRdd2 = sourRdd1
      // TODO: 过滤sim1_5_order为1的数据
      .filter(obj => {
        val sim1_5_order = JSONUtils.getJsonValue(obj,"sim1_5_order","")
        StringUtils.isNotEmpty(sim1_5_order) && "1".equals(sim1_5_order)
      })
      .map(obj => {
      var filterTag = 0
      val x1 = JSONUtils.getJsonValueDouble(obj,"x1",0)
      val y1 = JSONUtils.getJsonValueDouble(obj,"y1",0)
      val x2 = JSONUtils.getJsonValueDouble(obj,"x2",0)
      val y2 = JSONUtils.getJsonValueDouble(obj,"y2",0)

      val starts_x = JSONUtils.getJsonValueDouble(obj,"starts_x",0)
      val starts_y = JSONUtils.getJsonValueDouble(obj,"starts_y",0)
      val ends_x = JSONUtils.getJsonValueDouble(obj,"ends_x",0)
      val ends_y = JSONUtils.getJsonValueDouble(obj,"ends_y",0)

      val distance = JSONUtils.getJsonValueDouble(obj,"distance",0)
      val navi_distance = JSONUtils.getJsonValueDouble(obj,"navi_distance",0)

      val maxDist = Math.max(distance,navi_distance)
      val minDist = Math.min(distance,navi_distance)

      if (DistanceTool.getGreatCircleDistance(x1, y1, starts_x, starts_y) > 1000 || DistanceTool.getGreatCircleDistance(x2, y2, ends_x, ends_y) > 1000) {
        filterTag = 1
      } else if ((maxDist / minDist) > 3) {
        filterTag = 1
      }
      obj.put("filterTag",filterTag)

      obj
    })
      .filter(obj => {
        0 == obj.getIntValue("filterTag")
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(dataType + " " + "sourRdd2的数据量为：" + sourRdd2.count())
    sourRdd2.take(2).foreach(println(_))

    val sourRdd = sourRdd2
      .map(obj => {
        val src = obj.getString("src")
        val srcMap = getSrcMap(obj)
        (srcMap,obj)
      }).persist(StorageLevel.DISK_ONLY)
    logger.error(dataType + " " + s"按请求获取汇总结果:${sourRdd.count()}")

    sourRdd

  }

//  def processConsistentStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit = {
//    logger.error(">>>开始统计:ETA指标-一致率统计<<<")
//
//    //读取ETA结果汇总表
//    val querySql =
//      s"""
//         |select
//         |    d.navi_id,
//         |    sdk_ver,
//         |    distance,
//         |    navi_distance,
//         |    similarity1,
//         |    similarity5,
//         |    split(starts,',')[0] starts_x,
//         |    split(starts,',')[1] starts_y,
//         |    starts,
//         |    split(ends,',')[0] ends_x,
//         |    split(ends,',')[1] ends_y,
//         |    ends,
//         |    x1,y1,x2,y2,src,
//         |    req_type,
//         |    dest_province,
//         |    dest_citycode,
//         |    dest_deptcode,
//         |    duration,
//         |    routeId,
//         |    req_order,
//         |    round(distance_gap, 2) as distance_gap,
//         |    (
//         |      CASE
//         |        WHEN distance_gap < 0.05 THEN '小于5%'
//         |        WHEN distance_gap >= 0.05
//         |        AND distance_gap < 0.10 THEN '5%至10%'
//         |        WHEN distance_gap >= 0.10
//         |        AND distance_gap < 0.15 THEN '10%至15%'
//         |          WHEN distance_gap >= 0.15
//         |        AND distance_gap < 0.20 THEN '15%至20%'
//         |          WHEN distance_gap >= 0.20
//         |        AND distance_gap < 0.25 THEN '20%至25%'
//         |         WHEN distance_gap >= 0.25
//         |        AND distance_gap < 0.30 THEN '25%至30%'
//         |        ELSE '严重差异'
//         |      END
//         |    ) AS gap_sum
//         |from
//         |  (
//         |    select
//         |      sdk_ver,
//         |      a.navi_id,
//         |      a.distance,
//         |      starts,
//         |      ends,
//         |      similarity1,
//         |      similarity5,
//         |      x1,y1,x2,y2,src,
//         |      req_type,
//         |      b.navi_distance,
//         |      dest_province,
//         |      dest_citycode,
//         |      dest_deptcode,
//         |      duration,
//         |      routeId,
//         |      req_order,
//         |      ABS((distance - navi_distance) / distance) as distance_gap
//         |    from
//         |      (
//         |        select
//         |          id,
//         |          navi_id,
//         |          distance,x1,y1,x2,y2,src,
//         |          duration,
//         |          routeId,
//         |          req_order,
//         |          req_type
//         |        from
//         |          dm_gis.gis_navi_eta_result1
//         |        where
//         |          inc_day ='${incDay}'
//         |          and distance >= 1000
//         |      ) a
//         |    inner JOIN (
//         |        select
//         |          id,
//         |          similarity1,
//         |          similarity5,
//         |          navi_distance,
//         |          dest_province,
//         |          dest_citycode,
//         |          dest_deptcode,
//         |          regexp_replace(
//         |            regexp_extract(tracks2, '\\\\[\\\\[[^\\\\]]+', 0),
//         |            '\\\\[\\\\[',
//         |            ''
//         |          ) as starts,
//         |          regexp_replace(
//         |            regexp_extract(tracks2, '[^\\\\[]+\\\\]\\\\]', 0),
//         |            '\\\\]\\\\]',
//         |            ''
//         |          ) as ends
//         |        from
//         |          dm_gis.gis_navi_eta_result2
//         |        where
//         |          inc_day ='${incDay}'
//         |          and navi_distance >= 1000
//         |      ) b on a.id = b.id
//         |      left join (
//         |        select
//         |          navi_id,
//         |          sdk_ver
//         |        from
//         |          dm_gis.gis_navi_sdk_navi_parse
//         |        where
//         |         inc_day ='${incDay}'
//         |          and type = '1'
//         |      ) c on a.navi_id = c.navi_id
//         |  ) d
//         """.stripMargin
//    logger.error("querySql1为:" + querySql)
//
//    val querySql2 =
//      s"""
//         |select
//         |  navi_id,
//         |  distance,
//         |  navi_distance,
//         |  similarity1,
//         |  similarity5,
//         |  split(starts, ',') [0] starts_x,
//         |  split(starts, ',') [1] starts_y,
//         |  starts,
//         |  split(ends, ',') [0] ends_x,
//         |  split(ends, ',') [1] ends_y,
//         |  ends,
//         |  x1,
//         |  y1,
//         |  x2,
//         |  y2,
//         |  src,
//         |  req_type,
//         |  dest_province,
//         |  dest_citycode,
//         |  dest_deptcode,
//         |  duration,
//         |  routeId,
//         |  req_order,
//         |  round(distance_gap, 2) as distance_gap,
//         |  (
//         |    CASE
//         |      WHEN distance_gap < 0.05 THEN '小于5%'
//         |      WHEN distance_gap >= 0.05
//         |      AND distance_gap < 0.10 THEN '5%至10%'
//         |      WHEN distance_gap >= 0.10
//         |      AND distance_gap < 0.15 THEN '10%至15%'
//         |      WHEN distance_gap >= 0.15
//         |      AND distance_gap < 0.20 THEN '15%至20%'
//         |      WHEN distance_gap >= 0.20
//         |      AND distance_gap < 0.25 THEN '20%至25%'
//         |      WHEN distance_gap >= 0.25
//         |      AND distance_gap < 0.30 THEN '25%至30%'
//         |      ELSE '严重差异'
//         |    END
//         |  ) AS gap_sum
//         |from
//         |  (
//         |    select
//         |      a.request_id as request_id1,
//         |      a.distance as distance,
//         |      a.similarity1 as similarity1,
//         |      a.similarity5 as similarity5,
//         |      regexp_replace(
//         |        regexp_extract(a.tracks2, '\\\\[\\\\[[^\\\\]]+', 0),
//         |        '\\\\[\\\\[',
//         |        ''
//         |      ) as starts,
//         |      regexp_replace(
//         |        regexp_extract(a.tracks2, '[^\\\\[]+\\\\]\\\\]', 0),
//         |        '\\\\]\\\\]',
//         |        ''
//         |      ) as ends,
//         |      b.request_id as request_id,
//         |      b.id as id1,
//         |      b.navi_id as navi_id,
//         |      b.x1 as x1,
//         |      b.y1 as y1,
//         |      b.x2 as x2,
//         |      b.y2 as y2,
//         |      b.src as src,
//         |      b.duration as duration,
//         |      b.routeId as routeId,
//         |      b.req_order as req_order,
//         |      b.req_type as req_type,
//         |      c.id as id2,
//         |      c.navi_distance as navi_distance,
//         |      c.dest_province as dest_province,
//         |      c.dest_citycode as dest_citycode,
//         |      c.dest_deptcode as dest_deptcode,
//         |      ABS((a.distance - c.navi_distance) / a.distance) as distance_gap
//         |    from
//         |      (
//         |        select
//         |          *
//         |        from
//         |            dm_gis.gis_navi_bft_route_similarity
//         |        where
//         |           inc_day ='${incDay}'
//         |        and
//         |          distance >= 1000
//         |      ) a
//         |    inner join
//         |      (
//         |        select
//         |          *
//         |        from
//         |          dm_gis.gis_navi_eta_result1
//         |        where
//         |          inc_day ='${incDay}'
//         |      ) b
//         |      on a.request_id = b.request_id
//         |
//         |    inner join
//         |      (
//         |        select
//         |          *
//         |        from
//         |          dm_gis.gis_navi_eta_result2
//         |        where
//         |          inc_day ='${incDay}'
//         |      ) c
//         |    on b.id = c.id
//         |  ) d
//       """.stripMargin
//
//    logger.error("querySql2为：" + querySql2)
//
//
//
//    logger.error(">>>开始统计相似度不同区间的请求量和准确量<<<")
//    val sourDf = spark.sql(querySql)
//    val sourDf2 = spark.sql(querySql2)
//    val sourceRdd1 = SparkUtils.getRowToJson(sourDf)
//    logger.error("sourRdd1的数据量为：" + sourceRdd1.count())
//    sourceRdd1.take(2).foreach(println(_))
//
//    val sourceRdd2 = SparkUtils.getRowToJson(sourDf2)
//    logger.error("sourceRdd2的数据量为：" + sourceRdd2.count())
//    sourceRdd2.take(2).foreach(println(_))
//
//
//    val sourRddProcess = getFilterDistance(sourceRdd1,"other")
//    // TODO: 增加 备选路线（传统）统计
//    val sourRdd2Process = getFilterDistance(sourceRdd2,"sf").map(x => {
//
//      val jo = x._2
//      val dest_province = jo.getString("dest_province")
//      val dest_citycode = jo.getString("dest_citycode")
//      val req_type = jo.getString("req_type")
//      val gap_sum = jo.getString("gap_sum")
//
//      jo.put("src","sf")
//      (Seq(dest_province,dest_citycode,"sf",req_type,gap_sum),jo)
//    })
//
//    val sourRddAll = sourRddProcess.union(sourRdd2Process)
//
//    //按请求统计请求量和准确量
//    val reqRdd = doReqAccStatistics(sourRddAll,incDay,"ReqAccIndex","开始按请求统计请求量和准确率")
//    logger.error(s"共统计请求和访问:${reqRdd.count()}")
//    reqRdd.take(2).foreach(obj=>println(obj.mkString("")))
//
//    // 保存到hive
//    SparkUtils.df2Hive(spark,reqRdd,reqAccSchema,"append","dm_gis."+reqAccStatisticsDescTable,"statdate",incDay,logger)
//
//    //保存到mysql
//    SparkUtils.df2Mysql(spark,reqRdd,reqAccSchema,descMysqlUserName,descMysqlPassWord,
//      "append",descMysqlUrl,reqAccStatisticsDescMysqlTable,incDay,logger)
//
//    reqRdd.unpersist()
//    sourceRdd1.unpersist()
//    sourceRdd2.unpersist()
//    reqRdd.unpersist()
//  }

  def processConsistentStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit = {
    logger.error(">>>开始统计:ETA指标-一致率统计<<<")

    //读取ETA结果汇总表
    val querySql =
      s"""
         |select
         |  src,src_province,src_citycode,
         |  count(distinct id) totalCnt,
         |  count(distinct CASE WHEN distance_gap < 0.05 THEN id else null end) as gapSum5,
         |  count(distinct CASE WHEN distance_gap >= 0.05 AND distance_gap < 0.10 THEN id else null end) as gapSum10,
         |  count(distinct CASE WHEN distance_gap >= 0.10 AND distance_gap < 0.15 THEN id else null end) as gapSum15,
         |  count(distinct CASE WHEN distance_gap >= 0.15 AND distance_gap < 0.20 THEN id else null end) as gapSum20,
         |  count(distinct CASE WHEN distance_gap >= 0.20 AND distance_gap < 0.25 THEN id else null end ) as gapSum25,
         |  count(distinct CASE WHEN distance_gap >= 0.25 AND distance_gap < 0.30 THEN id  else null end ) as gapSum30,
         |  count(distinct CASE WHEN distance_gap > 0.30  THEN id  else null end ) as gapSumOther,
         |  count(distinct case when sim1 > 0.8 THEN id ELSE null END ) AS sim1,
         |  count(distinct case when sim5 > 0.8 THEN id ELSE null END ) AS sim5,
         |  count(distinct case when sim1_5 > 0.8 THEN id ELSE null END ) AS sim15
         |from
         |  (
         |    select
         |      t2.id,
         |      src,src_province,src_citycode,
         |      driver_type,
         |      similarity1 as sim1,
         |      similarity5 as sim5,
         |      sim1_5,
         |      navi_distance,
         |      distance,
         |      ABS((distance - navi_distance) / distance) as distance_gap
         |    FROM
         |      (
         |        select
         |          id,
         |          src,
         |          driver_type,
         |          distance
         |        from
         |          dm_gis.gis_navi_eta_result1
         |        where
         |          inc_day = '${incDay}'
         |      ) t1
         |      join(
         |        select
         |          id,src_province,src_citycode,
         |          similarity1,
         |          similarity5,
         |          navi_distance,
         |          if(
         |            similarity1 < similarity5,
         |            similarity5,
         |            similarity1
         |          ) as sim1_5
         |        from
         |          dm_gis.gis_navi_eta_result2
         |        where
         |          inc_day ='${incDay}'
         |          and navi_distance >= 1000
         |           and trackstart_distance < 1000
         |          and trackend_distance < 1000
         |      ) t2 on t1.id = t2.id
         |  ) d
         |where  3*navi_distance >= distance or 3*distance >= navi_distance
         |group by
         |  Src,src_province,src_citycode
         """.stripMargin
    logger.error("querySql1为:" + querySql)


    logger.error(">>>开始统计相似度不同区间的请求量和准确量<<<")
    val sourDf = spark.sql(querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourDf)
    logger.error("sourRdd1的数据量为：" + sourceRdd.count())
    sourceRdd.take(2).foreach(println(_))


   val reqRdd = sourceRdd.map(x => {
     val srcMap = getSrcMap(x)
     val src_province = JSONUtils.getJsonValue(x,"src_province","")
     val src_citycode = JSONUtils.getJsonValue(x,"src_citycode","")

     val totalCnt = JSONUtils.getJsonValueInt(x,"totalCnt",0)
     val gapSum5 = JSONUtils.getJsonValueInt(x,"gapSum5",0)
     val gapSum10 = JSONUtils.getJsonValueInt(x,"gapSum10",0)
     val gapSum15 = JSONUtils.getJsonValueInt(x,"gapSum15",0)
     val gapSum20 = JSONUtils.getJsonValueInt(x,"gapSum20",0)
     val gapSum25 = JSONUtils.getJsonValueInt(x,"gapSum25",0)
     val gapSum30 = JSONUtils.getJsonValueInt(x,"gapSum30",0)
     val gapSumOther = JSONUtils.getJsonValueInt(x,"gapSumOther",0)
     val sim1 = JSONUtils.getJsonValueInt(x,"sim1",0)
     val sim5 = JSONUtils.getJsonValueInt(x,"sim5",0)
     val sim15 = JSONUtils.getJsonValueInt(x,"sim15",0)


     val md5Instance = MD5Util.getMD5Instance
     val id = MD5Util.getMD5(md5Instance, Array(incDay,src_province,src_citycode,srcMap).mkString("_"))


     Row(id,incDay,src_province,src_citycode,srcMap,totalCnt,gapSum5,gapSum10,gapSum15,gapSum20,gapSum25,gapSum30,gapSumOther,sim1,sim5,sim15)

    })

    // 保存到hive
    SparkUtils.df2Hive(spark,reqRdd,reqAccSchema,"append","dm_gis."+reqAccStatisticsDescTable,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,reqRdd,reqAccSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,reqAccStatisticsDescMysqlTable,incDay,logger)

    reqRdd.unpersist()
    sourceRdd.unpersist()
    reqRdd.unpersist()
  }

  def doUserCountStatistics(sourceRdd: RDD[JSONObject], incDay: String) = {
     val userCntRdd1 = sourceRdd.map(x => {
       val driver_id = x.getString("driver_id")
       (driver_id,x)
     }).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {

       val inc_day = x.getString("inc_day")
       val driver_type = JSONUtils.getJsonValueInt(x,"driver_type",1)
       val service_id = JSONUtils.getJsonValue(x,"service_id","other")

       val driver_type_new = driver_type match {
         case driver_type if driver_type == 0 => "自营"
         case driver_type if driver_type == 1 => "外包"
       }

       val service_id_new = service_id match {
         case service_id if "KY".equals(service_id) => "快运"
         case service_id if (StringUtils.isEmpty(service_id) || "other".equals(service_id) || "sl".equals(service_id)) => "顺陆"
         case _ => service_id
       }

       ((inc_day,driver_type_new,service_id_new),x)

     }).persist(StorageLevel.MEMORY_AND_DISK_SER)
      logger.error("userCntRdd1的数据量为：" + userCntRdd1.count())
      userCntRdd1.take(10).foreach(println(_))


    val userCntRdd = userCntRdd1
       .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(x => {
        val (inc_day,driver_type_new,service_id_new) = x._1
        val list = x._2.toList
        val cnt = list.size

        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(inc_day,driver_type_new,service_id_new).mkString("_"))

        Row(id,inc_day,driver_type_new,service_id_new,cnt)
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
      userCntRdd.take(2).foreach(println(_))
    userCntRdd


  }




  def processUserCountStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit = {
    logger.error(">>>开始统计:ETA指标-导航用户量统计新<<<")

    val inc_day1 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-1)
    val inc_day60 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-60)


    //读取ETA结果汇总表
    val querySql =
      s"""
         |select
         |   inc_day,
         |   driver_id,
         |   service_id,
         |   driver_type
         |from
         |   dm_gis.gis_navi_top3_parse
         |where
         |    inc_day = '${incDay}'
         |And driver_type is not null
         """.stripMargin
    logger.error("querySql1为:" + querySql)


    logger.error(">>>开始统计相似度不同区间的请求量和准确量<<<")
    val sourDf = spark.sql(querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourDf)
    logger.error("sourRdd1的数据量为：" + sourceRdd.count())
    sourceRdd.take(2).foreach(println(_))

    // TODO: 增加 备选路线（传统）统计

    //按请求统计请求量和准确量
        val reqRdd = doUserCountStatistics(sourceRdd,incDay)
        logger.error(s"共统计请求和访问:${reqRdd.count()}")
        reqRdd.take(2).foreach(obj=>println(obj.mkString("")))

    // 保存到hive
    SparkUtils.df2Hive(spark,reqRdd,reqUserSchema,"append","dm_gis." + reqUserStatisticsDescTable,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,reqRdd,reqUserSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,reqUserStatisticsMysqlTable,incDay,logger)

    reqRdd.unpersist()
    sourceRdd.unpersist()
    reqRdd.unpersist()
  }


  def processNewAddUserCountStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit = {
    logger.error(">>>开始统计:ETA指标-导航新增用户量统计<<<")

    val inc_day1 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-1)
    val inc_day60 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-60)


    //读取ETA结果汇总表
    val querySql =
      s"""
         |select
         |inc_day,
         |service_id,
         |driver_type,
         |service_id,
         |t2.driver_id
         |from
         |  (
         |    select
         |      driver_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day >='${inc_day60}'
         |      And  inc_day <= '${inc_day1}'
         |  ) t1
         |  right join (
         |    select
         |      inc_day,
         |      driver_id,
         |      service_id,
         |      driver_type
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day = '${incDay}'
         |And driver_type is not null
         |  ) t2 on t1.driver_id = t2.driver_id
         |  where
         |  t1.driver_id is null
         """.stripMargin
    logger.error("querySql1为:" + querySql)


    logger.error(">>>开始统计相似度不同区间的请求量和准确量<<<")
    val sourDf = spark.sql(querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourDf)
    logger.error("sourRdd1的数据量为：" + sourceRdd.count())
    sourceRdd.take(2).foreach(println(_))

    // TODO: 增加 备选路线（传统）统计

    //按请求统计请求量和准确量
    val reqRdd = doUserCountStatistics(sourceRdd,incDay)
    logger.error(s"共统计请求和访问:${reqRdd.count()}")
    reqRdd.take(2).foreach(obj=>println(obj.mkString("")))

    // 保存到hive
    SparkUtils.df2Hive(spark,reqRdd,reqUserSchema,"append","dm_gis."+reqNewUserAddStatisticsDescTable,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,reqRdd,reqUserSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,reqNewUserAddStatisticsMysqlTable,incDay,logger)

    reqRdd.unpersist()
    sourceRdd.unpersist()
    reqRdd.unpersist()
  }



  /*do anything*/
  /*p1*/
  def doClickRateStatistics( sourRdd: RDD[((String, String), JSONObject)],incDay: String) = {


    //按照省份（dest_province）、城市（dest_citycode）、场地（dest_deptcode）、日期(inc_day)聚合
    val clickRateDf =
      sourRdd.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
        .map(obj => {
          val (dest_province,dest_citycode) = obj._1
          val resList = obj._2


          val md5Instance = MD5Util.getMD5Instance
          //val id = Base64.getEncoder().encodeToString(Array(incDay,dest_province,dest_citycode,dest_deptcode).mkString("_").getBytes("utf-8"))

          val id = MD5Util.getMD5(md5Instance, Array(incDay,dest_province,dest_citycode).mkString("_"))

          //总导航量
          val naviAmount = resList.length

          //传统/经验统计
          val srcTypeMap = resList.map(json => {
            val src = getSrcMap(json)

            json.put("src",src)
            json
          }).groupBy(_.getString("src"))
          val traditionTypeAmount = srcTypeMap.getOrElse("传统",List()).length
          val experienceTypeAmount = srcTypeMap.getOrElse("经验",List()).length
          val gdTypeAmount = srcTypeMap.getOrElse("高德",List()).length
          val saveTypeAmount = srcTypeMap.getOrElse("省钱|省里程路线",List()).length

          //路线类型统计 top3|yaw

          val reqTypeMap = resList.groupBy(_.getString("req_type"))
          val top3Amount = reqTypeMap.getOrElse("top3",List()).length
          val yawAmount = reqTypeMap.getOrElse("yaw",List()).length

          //策略统计
          val strategyMap = resList.map(x => {
           val strategy = if (StringUtils.isEmpty(x.getString("strategy"))) "empty" else x.getString("strategy")
            x.put("strategy",strategy)
            x
          }).groupBy(_.getString("strategy"))
          val recommendAmount = strategyMap.getOrElse("empty",List()).length
          val timePriorityAmount = strategyMap.getOrElse("6",List()).union(strategyMap.getOrElse("0",List())).length
          val costPriorityAmount = strategyMap.getOrElse("1",List()).length
          val distancePriorityAmount = strategyMap.getOrElse("2",List()).length
          val highWayPriorityAmount = strategyMap.getOrElse("3",List()).length
          val avoidancePriorityAmount = strategyMap.getOrElse("4",List()).length

          //自营司机外包司机统计
          val driverTypeMap = resList.groupBy(_.getString("driver_type"))
          val ownDriverAmount = driverTypeMap.getOrElse("0",List()).length
          val otherDriverTypeAmount = driverTypeMap.getOrElse("1",List()).length

          val indexArray = List("0","1","2")

          //点选路线分布,选择了第几条线路统计
          val routeindexMap = resList.map(x => {
            val route = x.getString("route_index")
            val routeNew = if ((StringUtil.isBlank(route) || (!indexArray.contains(route)))) "other" else route
            x.put("route_index",routeNew)
            x
          }).groupBy(_.getString("route_index"))
          val firstWayAmount = routeindexMap.getOrElse("0",List()).length
          val secondWayAmount = routeindexMap.getOrElse("1",List()).length
          val thirdWayAmount = routeindexMap.getOrElse("2",List()).length
          val otherWayAmount = routeindexMap.getOrElse("other",List()).length
            //.filter(_._1.equals("other")).map(_._2.size).toList.take(1)(0)


          Row(id,incDay,dest_province,dest_citycode,naviAmount,traditionTypeAmount,experienceTypeAmount,gdTypeAmount,saveTypeAmount,top3Amount,yawAmount,
            recommendAmount,timePriorityAmount,costPriorityAmount,distancePriorityAmount,highWayPriorityAmount,avoidancePriorityAmount,
            ownDriverAmount,otherDriverTypeAmount,firstWayAmount,secondWayAmount,thirdWayAmount,otherWayAmount)
        }).persist(StorageLevel.DISK_ONLY)

    sourRdd.unpersist()
    logger.error(s"共统计点选率指标:${clickRateDf.count()}")

    clickRateDf
  }



  def doReqAccStatistics(sourRdd: RDD[(Seq[String], JSONObject)],incDay:String,indexString:String,reqString:String) = {
    logger.error(s"$reqString")
    val perArray = Array(1,0.8,0)
    // >= 0.8 < 0.8
    //val perArray = Array(1,0.99,0.98,0.95,0.9,0.85,0.8,0.6,0)

    val reqRdd = sourRdd.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).flatMap(obj => {
      val (dest_province,dest_citycode,srcMap,req_type,gap_sum) = (obj._1(0),obj._1(1),obj._1(2),obj._1(3),obj._1(4))
//      val (dest_province,dest_citycode,dest_deptcode,srcMap) = (obj._1(0),obj._1(1),obj._1(2),obj._1(3))
      val resList = obj._2
      val md5Instance = MD5Util.getMD5Instance
      val sim1id = MD5Util.getMD5(md5Instance, Array(incDay,dest_province,dest_citycode,srcMap,req_type,gap_sum,"sim1").mkString("_"))
      val sim5id = MD5Util.getMD5(md5Instance, Array(incDay,dest_province,dest_citycode,srcMap,req_type,gap_sum,"sim5").mkString("_"))
      val sim1And5Rowid = MD5Util.getMD5(md5Instance, Array(incDay,dest_province,dest_citycode,srcMap,req_type,gap_sum,"sim1And5").mkString("_"))

      //总请求量
      val reqAmount = resList.length
      //空值请求量
      val sim1NullReqAmount = resList.filter( json => { StringUtils.isBlank(json.getString("similarity1"))} ).length
      val sim5NullReqAmount = resList.filter( json => { StringUtils.isBlank(json.getString("similarity5"))} ).length
      val sim1And5NullReqAmount = resList.filter( json => { StringUtils.isBlank(json.getString("similarity1")) &&  StringUtils.isBlank(json.getString("similarity5")) } ).length
      //[1-0]空值请求量
      val sim1Row = Row(sim1id,incDay,dest_province,dest_citycode,srcMap,req_type,gap_sum,"sim1",reqAmount,sim1NullReqAmount)
      val sim5Row = Row(sim5id,incDay,dest_province,dest_citycode,srcMap,req_type,gap_sum,"sim5",reqAmount,sim5NullReqAmount)
      val sim1And5Row = Row(sim1And5Rowid,incDay,dest_province,dest_citycode,srcMap,req_type,gap_sum,"sim1And5",reqAmount,sim1And5NullReqAmount)

      var sim1PerList = List[Int]()
      var sim5PerList = List[Int]()
      var sim1And5PerList = List[Int]()

      for ( i <- 0 until perArray.length-1) {
        //sim1请求量
        val sim1ReqList = resList.filter(json => { json.getDouble("similarity1") <  perArray(i) && json.getDouble("similarity1") >=  perArray(i+1) })
        sim1PerList = sim1PerList :+ sim1ReqList.length
        //sim5请求量
        val sim5ReqList = resList.filter( json => { json.getDouble("similarity5") <  perArray(i) && json.getDouble("similarity5") >=  perArray(i+1) })
        sim5PerList = sim5PerList :+ sim5ReqList.length
        //sim1And5请求量
        val sim1And5ReqList =  resList.filter(
          json => {
            // TODO: 取sim1和sim5的较大值
            if (json.getDouble("similarity1") >= json.getDouble("similarity5")){
              json.getDouble("similarity1") <  perArray(i) && json.getDouble("similarity1") >=  perArray(i+1)
            } else {
              json.getDouble("similarity5") <  perArray(i) && json.getDouble("similarity5") >=  perArray(i+1)
            }
          })
        sim1And5PerList = sim1And5PerList :+ sim1And5ReqList.length
      }

      var rowList = List[Row]()
      rowList = rowList :+ Row.merge(sim1Row,Row.fromSeq(sim1PerList))
      rowList = rowList :+ Row.merge(sim5Row,Row.fromSeq(sim5PerList))
      rowList = rowList :+ Row.merge(sim1And5Row,Row.fromSeq(sim1And5PerList))

      rowList
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共统计指标${reqRdd.count()}")

    sourRdd.unpersist()
    reqRdd
  }

  def getActiveProcess(sourceRdd: RDD[JSONObject],incDay:String) = {

    // TODO: 30 日滚动月活
    val beginDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-30)
    // TODO: 当月累计月活
    val curMonthFirstDay = DateTimeUtil.getCurMonthFirstDay(incDay,"yyyyMMdd")
    // TODO: 滚动月活7日
    val curWeekDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-7)


    //当日活跃数
    val curDayActiveCnt = sourceRdd.filter(x => {incDay.equals(x.getString("inc_day"))}).count()

    //当月累计活跃数
    val curMonthSumCnt = sourceRdd.filter(x => {
      JSONUtils.getJsonValue(x,"inc_day","") >= curMonthFirstDay
    }).count()

    //30日滚动活跃数
    val allSumCnt = sourceRdd.count()

    //总注册用户数

    List((incDay,curDayActiveCnt,curMonthSumCnt,allSumCnt))

  }

  def processActiveStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit={

    logger.error("开始活跃率统计")

    // TODO: 30 日滚动月活
    val beginDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-30)
    // TODO: 当月累计月活
    val curMonthFirstDay = DateTimeUtil.getCurMonthFirstDay(incDay,"yyyyMMdd")
    // TODO: 滚动月活7日
    val curWeekDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-7)


    val querySql =
      s"""
         |select
         |  distinct driver_id,inc_day
         |from
         |  dm_gis.gis_navi_top3_parse
         |where
         |  inc_day >= '${beginDay}'
       """.stripMargin

    val querySql2 =
      s"""
         |select
         |    count(1) num
         |from
         |(
         |select
         |    driver_id
         |from
         |    dm_gis.gis_navi_top3_parse
         |group by
         |    driver_id
         |) t1
       """.stripMargin


    val source1Df = spark.sql(querySql)
    val source2Df = spark.sql(querySql2)

    val allUserNumArray = source2Df.rdd.take(1).map(x => {
      val num = x.getLong(0)
      num
    })
    val allUserNum = allUserNumArray(0)


    val sourceRdd1 = SparkUtils.getRowToJson(source1Df)
    logger.error("活跃率输入数据量为：" + sourceRdd1.count())

    val processRdd1 = getActiveProcess(sourceRdd1,incDay)

    import spark.implicits._


    val resultRdd = spark.sparkContext.parallelize(processRdd1).map(x => {

      val md5Instance = MD5Util.getMD5Instance

      val (statdate,curDayActiveCnt,curMonthSumCnt,allSumCnt) = x
      val id = MD5Util.getMD5(md5Instance,Array(statdate).mkString(""))
      Row(id,statdate,curDayActiveCnt.toInt,curMonthSumCnt.toInt,allSumCnt.toInt,allUserNum.toInt)
    })

    logger.error("活跃率统计结果为：")
    resultRdd.take(2).foreach(println(_))
    //保存到hive
    SparkUtils.df2Hive(spark,resultRdd,reqActiveSchema,"append","dm_gis." + reqActiveTable,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,resultRdd,reqActiveSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,reqActiveTable,incDay,logger)
  }


  def calFunnel(usageRdd: RDD[JSONObject],nv_type:String,inc_day:String) = {

    //(task_sl,task_sdk,task_sta,navi_type,is_run_ontime,is_halfway_integrate)

    //顺陆当日任务数
    val slRdd= usageRdd.map(x => {
      val task_sl = x.getString("task_sl")
      (task_sl,x)}).reduceByKey((obj1,obj2) => obj1).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)

    val slCnt = slRdd.count()
    //进入导航sdk数
    val sdkCnt = slRdd.filter( x => {StringUtils.isNotEmpty(x.getString("task_sdk"))}).map(x => {
      val task_sdk = x.getString("task_sdk")
      (task_sdk,x)
    }).reduceByKey((obj1,obj2) => obj1).count()

    //开始导航任务数
    val staRdd = slRdd.filter(x => {
      val task_sta = x.getString("task_sta")
      StringUtils.isNotEmpty(task_sta)
    }).map(x => {
      val task_sta = x.getString("task_sta")
      (task_sta, x)
    }).reduceByKey((obj1, obj2) => obj1).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val staCnt = staRdd.count()

    //SF导航使用数
    val sfCnt = staRdd
      .map(_._2)
      .filter(x => {
        val navi_type = x.getString("navi_type")
        StringUtils.isNotEmpty(navi_type) && "sf".equals(navi_type)
      }).count()

    //准点任务数
    val ontimeCnt = slRdd.filter(x => {
      val is_run_ontime = x.getString("is_run_ontime")
      StringUtils.isNotEmpty(is_run_ontime) && "1".equals(is_run_ontime)
    }).count()

    //任务轨迹有效数
    val halfwayCnt = slRdd.filter(x => {
      val is_halfway_integrate = x.getString("is_halfway_integrate")
      StringUtils.isNotEmpty(is_halfway_integrate) && "有效".equals(is_halfway_integrate)
    }).count()


    val md5Instance = MD5Util.getMD5Instance
    val id = MD5Util.getMD5(md5Instance, Array(inc_day,nv_type).mkString("_"))

    Row(id,inc_day,nv_type,slCnt.toInt,sdkCnt.toInt,halfwayCnt.toInt,ontimeCnt.toInt,staCnt.toInt,sfCnt.toInt)
  }

  def getFunnelProcess(sourceRdd: RDD[JSONObject], incDay: String, dateType:String) = {

//    t1.inc_day as inc_day,
//    t1.task_id as task_sl,
//    t1.is_run_ontime as is_run_ontime,
//    t1.actual_run_time as actual_run_time,
//    t2.is_halfway_integrate as is_halfway_integrate,
//    t3.task_id as task_sdk,
//    t4.task_id as task_sta,
//    t4.navi_type as navi_type,
//    t5.navi_time

    val funnelProcessRdd = sourceRdd.distinct().persist(StorageLevel.MEMORY_AND_DISK_SER)

    val usageSFRdd = funnelProcessRdd.filter(x => {
      "sf".equals(x.getString("navi_type"))
    })

    val usageGdRdd = funnelProcessRdd.filter(x => {
      "gd".equals(x.getString("navi_type"))
    })

    val usageSfAndGdRdd = funnelProcessRdd.filter(x => {
      "sf".equals(x.getString("navi_type")) || "gd".equals(x.getString("navi_type"))
    })

    var rowList = List[Row]()
    //slCnt,sdkCnt,halfwayCnt,ontimeCnt,staRdd,sfCnt
    val sfFunnelRdd = calFunnel(usageSFRdd,"sf",incDay)
    val gdFunnelRdd = calFunnel(usageGdRdd,"gd",incDay)
    val sfAndGdFunnelRdd = calFunnel(usageSfAndGdRdd,"sf&gd",incDay)

    rowList = rowList :+ sfFunnelRdd
    rowList = rowList :+ gdFunnelRdd
    rowList = rowList :+ sfAndGdFunnelRdd

    rowList

  }

  def getDurationDistribute(sourceRdd: RDD[JSONObject], incDay: String, dateType: String) = {

    val calDistributeRdd = sourceRdd.map(x => {
      val task_sl = x.getString("task_sl")
      (task_sl,x)}).reduceByKey((obj1,obj2) => obj1).map(_._2).map(x => {

      val actual_run_time = JSONUtils.getJsonValueDouble(x,"actual_run_time",0)
      val navi_time = JSONUtils.getJsonValueDouble(x,"navi_time",0) / 60

      val ratio = if (actual_run_time != 0) navi_time / actual_run_time else 0

      val ratioCluster = ratio match {
        case ratio if (ratio <=0.25) => "(0,25%]"
        case ratio if (ratio > 0.25 && ratio <=0.5) => "(25%,50%]"
        case ratio if (ratio > 0.5 && ratio <=0.75) => "(50%,75%]"
        case ratio if (ratio > 0.75) => "(75%.100%]"
      }

      (ratioCluster,x)
    })

    val res2Rdd = calDistributeRdd.groupByKey().map(x => {

      val ratioCluster = x._1
      val list = x._2.toList

      //顺陆当日任务数
      val slCnt = list.size
      val halfwayCnt = list.filter(x => {
        val is_halfway_integrate = x.getString("is_halfway_integrate")
        StringUtils.isNotEmpty(is_halfway_integrate) && "有效".equals(is_halfway_integrate)
      }).size

      val ontimeCnt  = list.filter(x => {
        val is_run_ontime = x.getString("is_run_ontime")
        StringUtils.isNotEmpty(is_run_ontime) && "1".equals(is_run_ontime)
      }).size

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(incDay,ratioCluster).mkString("_"))


      Row(id,incDay,ratioCluster,slCnt,halfwayCnt,ontimeCnt)
    })

    res2Rdd
  }


  def calRetentionDayRdd(soureRdd1:Array[JSONObject],soureRdd2:Array[JSONObject],inc_day:String) = {
    val obj1 = try {soureRdd1(0) } catch {case e:Exception => new JSONObject()}
    val obj2 = try {soureRdd2(0) } catch {case e:Exception => new JSONObject()}

    //val inc_day = obj1.getString("inc_day")
    val D11 = JSONUtils.getJsonValueDouble(obj1,"D1",0)
    val D12 = JSONUtils.getJsonValueDouble(obj1,"D2",0)
    //次日留存
    val nextDayRetent = if (D11 != 0) D12 / D11 else 0

    val D21 = JSONUtils.getJsonValueDouble(obj2,"D1",0)
    val D22 = JSONUtils.getJsonValueDouble(obj2,"D2",0)

    //新增用户次日
    val newNextDayRetent = if (D21 != 0) D22 / D21 else 0
    //新增用户月留存
    //val newNextMonRetent = D23 / D21


    val md5Instance = MD5Util.getMD5Instance
    val id = MD5Util.getMD5(md5Instance, Array(inc_day).mkString("_"))

    List(Row(id,inc_day,nextDayRetent,newNextDayRetent))
  }


  def calRetentionMonthRdd(soureRdd1:Array[JSONObject],soureRdd2:Array[JSONObject],inc_day:String) = {
    val obj1 = try {soureRdd1(0) } catch {case e:Exception => new JSONObject()}
    val obj2 = try {soureRdd2(0) } catch {case e:Exception => new JSONObject()}

    //val inc_day = obj1.getString("inc_day")
    val D11 = JSONUtils.getJsonValueDouble(obj1,"D1",0)
    val D12 = JSONUtils.getJsonValueDouble(obj1,"D2",0)
    //次月留存
    val nextMonthRetent =  if (D11 != 0) D12 / D11 else 0

    val D21 = obj2.getDouble("D1")
    val D22 = obj2.getDouble("D2")

    //新增用户月留存
    val newNextMonRetent =  if (D21 != 0) D22 / D21 else 0


    val md5Instance = MD5Util.getMD5Instance
    val id = MD5Util.getMD5(md5Instance, Array(inc_day).mkString("_"))
    List(Row(id,inc_day,nextMonthRetent,newNextMonRetent))
  }

  def processRetentionRateStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit={
    logger.error(">>>开始统计:留存率<<<")


    val inc_day1 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-1)
    val inc_day2 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-2)
    val inc_day3 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-3)
    val inc_day28 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,28)

    val inc_day31 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-31)
    val inc_day32 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-32)

    val inc_day62 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-62)
    val inc_day91 = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-91)

    //从Top3点选线路的ETA结果表读取数据
    val querysql1 =
      s"""
         |select
         |  t1.inc_day,
         |  count(distinct t1.driver_id) D1,
         |  count(distinct t2.driver_id) D2
         |from
         |      (
         |        select
         |          inc_day,
         |          driver_id
         |        from
         |          dm_gis.gis_navi_top3_parse
         |        where
         |          inc_day = '${inc_day2}'
         |      ) t1
         |      left join (
         |        select
         |          inc_day,
         |          driver_id
         |        from
         |          dm_gis.gis_navi_top3_parse
         |        where
         |          inc_day = '${inc_day1}'
         |      ) t2 on
         |      t1.driver_id = t2.driver_id
         |group by
         |    t1.inc_day
         |""".stripMargin

    val querysql2 =
      s"""
         |select
         |  t2.inc_day,
         |  count(distinct t2.driver_id) D1,
         |  count(distinct t3.driver_id) D2
         |from
         |  (
         |    select
         |      driver_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day >= '${inc_day62}'
         |      And  inc_day <= '${inc_day3}'
         |  ) t1
         |  right join (
         |    select
         |      inc_day,
         |      driver_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day = '${inc_day2}'
         |  ) t2 on t1.driver_id = t2.driver_id
         |  left join (
         |    select
         |      driver_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day = '${inc_day1}'
         |  ) t3 on t2.driver_id = t3.driver_id
         |  where
         |  t1.driver_id is null
         |group by
         |  t2.inc_day
         |""".stripMargin

    val querysql3 =
      s"""
         |select
         |  t1.inc_day,
         |  count(distinct t1.driver_id) D1,
         |  count(distinct t2.driver_id) D2
         |from
         |      (
         |        select
         |          inc_day,
         |          driver_id
         |        from
         |          dm_gis.gis_navi_top3_parse
         |        where
         |          inc_day = '${inc_day31}'
         |      ) t1
         |      left join (
         |        select
         |          inc_day,
         |          driver_id
         |        from
         |          dm_gis.gis_navi_top3_parse
         |        where
         |          inc_day = '${inc_day1}'
         |      ) t2 on t1.driver_id = t2.driver_id
         |group by t1.inc_day
       """.stripMargin

    val querysql4 =
      s"""
         |select
         |  t2.inc_day,
         |  count(distinct t2.driver_id) D1,
         |  count(distinct t3.driver_id) D2
         |from
         |  (
         |    select
         |      driver_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day >= '${inc_day91}'
         |      And inc_day <= '${inc_day32}'
         |  ) t1
         |  right join (
         |    select
         |      inc_day,
         |      driver_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day = '${inc_day31}'
         |  ) t2 on t1.driver_id = t2.driver_id
         |  left join (
         |    select
         |      driver_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day = '${inc_day1}'
         |  ) t3 on t2.driver_id = t3.driver_id
         |  where
         |  t1.driver_id is null
         |group by
         |  t2.inc_day
       """.stripMargin



    logger.error(querysql1)

    val soureRdd1 = SparkUtils.getRowToJson(spark.sql(querysql1)).take(1)
    logger.error("soureRdd1:" + soureRdd1.mkString(""))
    val soureRdd2 = SparkUtils.getRowToJson(spark.sql(querysql2)).take(1)
    logger.error("soureRdd2:" + soureRdd2.mkString(""))


    val soureRdd3 = SparkUtils.getRowToJson(spark.sql(querysql3)).take(1)
    logger.error("soureRdd3:" + soureRdd3.mkString(""))
    val soureRdd4 = SparkUtils.getRowToJson(spark.sql(querysql4)).take(1)
    logger.error("soureRdd4:" + soureRdd4.mkString(""))

    val retentionList = calRetentionDayRdd(soureRdd1,soureRdd2,inc_day1)
    val retentionList2 = calRetentionMonthRdd(soureRdd3,soureRdd4,inc_day31)

    val retentionRdd = spark.sparkContext.parallelize(retentionList)
    logger.error("retentionRdd的数据量为：" + retentionRdd.count())
    retentionRdd.take(2).foreach(println(_))

    val retentionRdd2 = spark.sparkContext.parallelize(retentionList2)
    logger.error("retentionRdd2的数据量为：" + retentionRdd.count())
    retentionRdd2.take(2).foreach(println(_))

    //保存到hive
    SparkUtils.df2Hive(spark,retentionRdd,rententRateSchema,"append","dm_gis."+ rententRateTable,"statdate",inc_day1,logger)
    SparkUtils.df2Hive(spark,retentionRdd2,rententRateSchema2,"append","dm_gis."+ rententRateTable2,"statdate",inc_day31,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,retentionRdd,rententRateSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,rententRateMysqlTable,inc_day1,logger)

    SparkUtils.df2Mysql(spark,retentionRdd2,rententRateSchema2,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,rententRateMysqlTable2,inc_day31,logger)


     retentionRdd.unpersist()
     retentionRdd2.unpersist()

  }


  def processFunnelStatistics(spark:SparkSession, incDay:String, yesterday:String ) = {

    logger.error("开始任务漏斗统计")

    // TODO: 当月累计月活
    //val curMonthFirstDay = DateTimeUtil.getCurMonthFirstDay(incDay,"yyyyMMdd")
    val curMonthFirstDay = incDay
    // TODO: 滚动月活7日
    val curWeekDay = DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-7)

    val querySql =
      s"""
         |select
         |  t1.inc_day as inc_day,
         |  t1.task_id as task_sl,
         |  t1.is_run_ontime as is_run_ontime,
         |  t1.actual_run_time as actual_run_time,
         |  t2.is_halfway_integrate as is_halfway_integrate,
         |  t3.task_id as task_sdk,
         |  t4.task_id as task_sta,
         |  t4.navi_type as navi_type,
         |  t5.navi_time
         |from
         |  (
         |    select
         |      task_id,
         |      is_run_ontime,
         |      actual_run_time,
         |      inc_day
         |    from
         |      dm_grd.grd_new_task_detail
         |    where
         |      state = '6'
         |      and inc_day >= '${curMonthFirstDay}'
         |  ) t1
         |  left join (
         |    select
         |      task_id,
         |      is_halfway_integrate
         |    from
         |      dm_tdsp.rpt_grd_task_monitor_re_dtl_di
         |      -- tmp_dm_tdsp.rpt_grd_task_monitor_re
         |    where
         |      inc_day >= '${curMonthFirstDay}'
         |  ) t2 on t1.task_id = t2.task_id
         |  left join (
         |    select
         |      distinct task_id
         |    from
         |      dm_gis.gis_navi_top3_parse
         |    where
         |      inc_day >= '${curMonthFirstDay}'
         |  ) t3 on t1.task_id = t3.task_id
         |  left join (
         |    select
         |      task_id,
         |      navi_type
         |    from
         |      dm_gis.gis_navi_sdk_navi_parse
         |    where
         |      inc_day >= '${curMonthFirstDay}'
         |  ) t4 on t1.task_id = t4.task_id
         |  left join (
         |    select
         |      task_id,
         |      navi_time
         |    from
         |      dm_gis.gis_navi_eta_result1
         |    where
         |      inc_day >= '${curMonthFirstDay}'
         |  ) t5 on t1.task_id = t5.task_id
       """.stripMargin

    val sourceDf = spark.sql(querySql)
    logger.error("漏斗统计sql为：" + querySql)
    val sourceRdd = SparkUtils.getRowToJson(sourceDf)
    logger.error("漏斗统计sql为输入数据量为：" + sourceRdd.count())

    val curDayRdd = sourceRdd.filter(x => {
      incDay.equals(x.getString("inc_day"))
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("漏斗统计当日输入数据量为：" + curDayRdd.count())
    curDayRdd.take(2).foreach(println(_))
//    val curWeekRdd = sourceRdd.filter(x => {
//      x.getString("inc_day") >= curWeekDay
//    }).persist(StorageLevel.DISK_ONLY)
//    logger.error("漏斗统计当日输入数据量为：" + curDayRdd.count())

    val dayFunnelProcessList = getFunnelProcess(curDayRdd,incDay,"curDay")

    val dayFunnelProcessRdd = spark.sparkContext.parallelize(dayFunnelProcessList)

    //计算按时长分布比表
    val durationDistributeRdd = getDurationDistribute(curDayRdd,incDay,"curDay")
    logger.error("durationDistributeRdd的数据量为：" +durationDistributeRdd.count())
    durationDistributeRdd.take(2).foreach(println(_))

    //保存到hive
    SparkUtils.df2Hive(spark,dayFunnelProcessRdd,reqFunnelSchema,"append","dm_gis." + reqFunnelTable,"statdate",incDay,logger)

    SparkUtils.df2Hive(spark,durationDistributeRdd,reqFunnelSchema2,"append","dm_gis." + reqFunnelTable2,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,dayFunnelProcessRdd,reqFunnelSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,reqFunnelTable,incDay,logger)

    SparkUtils.df2Mysql(spark,durationDistributeRdd,reqFunnelSchema2,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,reqFunnelTable2,incDay,logger)

  }

  def getTop1Process(sourRddProcess: RDD[((String,String), JSONObject)], incDay: String) = {

    val res1Rdd = sourRddProcess.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).map(x => {

      val (src,route_index) = x._1
      val list = x._2.toList

      val totalCnt = list.size

      val sim1Cnt = list.filter(obj => {
        val sim1 = JSONUtils.getJsonValueDouble(obj, "sim1", 0)
        sim1 > 0.8
      }).size
      val sim5Cnt = list.filter(obj => {
        val sim1 = JSONUtils.getJsonValueDouble(obj, "sim5", 0)
        sim1 > 0.8
      }).size
      val sim1AndSim5Cnt = list.filter(obj => {
        val sim1_5 = JSONUtils.getJsonValueDouble(obj, "sim1_5", 0)
        sim1_5 > 0.8
      }).size

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(incDay,src,route_index).mkString("_"))

      Row(id, incDay, src ,route_index, totalCnt, sim1Cnt, sim5Cnt, sim1AndSim5Cnt)

    })


    val res2Rdd = sourRddProcess.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).map(x => {

      val (src,route_index) = x._1
      val resList = x._2

      val gapArray = Array("小于5%", "5%至10%", "10%至15%", "15%至20%", "20%至25%", "25%至30%", "大于30%")
      val totalCnt = resList.size

      var simList = List[Int]()

      for (i <- 0 until gapArray.length) {
        val simReqList = resList.filter(obj => {
          val gap_sum = JSONUtils.getJsonValue(obj, "gap_sum", "")
          StringUtils.isNotEmpty(gap_sum) && gapArray(i).equals(gap_sum)
        })
        simList = simList :+ simReqList.length
      }

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(incDay,src,route_index).mkString("_"))

      val row1 = Row(id, incDay, src ,route_index, totalCnt)
      val rowList = Row.merge(row1,Row.fromSeq(simList))
      rowList

      //Row(src, totalCnt, Row.fromSeq(simList),incDay)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("res2Rdd的数据量为：" + res2Rdd.count())
    res2Rdd.take(3).foreach(println(_))

    (res1Rdd, res2Rdd)
  }

  def getTop3Process(sourRddProcess: RDD[(String, JSONObject)], incDay: String) = {

    val res1Rdd = sourRddProcess.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).map(x => {

      val src = x._1
      val list = x._2.toList

      val totalCnt = list.size

      val sim1Cnt = list.filter(obj => {
        val sim1 = JSONUtils.getJsonValueDouble(obj, "sim1", 0)
        sim1 > 0.8
      }).size
      val sim5Cnt = list.filter(obj => {
        val sim1 = JSONUtils.getJsonValueDouble(obj, "sim5", 0)
        sim1 > 0.8
      }).size
      val sim1AndSim5Cnt = list.filter(obj => {
        val sim1_5 = JSONUtils.getJsonValueDouble(obj, "sim1_5", 0)
        sim1_5 > 0.8
      }).size

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(incDay,src).mkString("_"))

      Row(id, incDay, src, totalCnt, sim1Cnt, sim5Cnt, sim1AndSim5Cnt)

    })


    val res2Rdd = sourRddProcess.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).map(x => {

      val src = x._1
      val resList = x._2

      val gapArray = Array("小于5%", "5%至10%", "10%至15%", "15%至20%", "20%至25%", "25%至30%", "大于30%")
      val totalCnt = resList.size

      var simList = List[Int]()

      for (i <- 0 until gapArray.length) {
        val simReqList = resList.filter(obj => {
          val gap_sum = JSONUtils.getJsonValue(obj, "gap_sum", "")
          StringUtils.isNotEmpty(gap_sum) && gapArray(i).equals(gap_sum)
        })
        simList = simList :+ simReqList.length
      }

      val md5Instance = MD5Util.getMD5Instance
      val id = MD5Util.getMD5(md5Instance, Array(incDay,src).mkString("_"))

      val row1 = Row(id, incDay, src, totalCnt)
      val rowList = Row.merge(row1,Row.fromSeq(simList))
      rowList

      //Row(src, totalCnt, Row.fromSeq(simList),incDay)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("res2Rdd的数据量为：" + res2Rdd.count())
    res2Rdd.take(3).foreach(println(_))

    (res1Rdd, res2Rdd)
  }

  def processTop3ConsistentStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit = {

    logger.error("开始top3一致率统计")

    val querySql =
      s"""
         |select
         |  split(starts,',')[0] starts_x,
         |  split(starts,',')[1] starts_y,
         |  request_id,
         |  navi_id,
         |  x1,
         |  y1,
         |  x2,
         |  y2,
         |  src,
         |  sim1,
         |  sim5,
         |  sim1_5,
         |  distance,
         |  navi_distance,
         |  split(ends,',')[0] ends_x,
         |  split(ends,',')[1] ends_y,
         |  distance_gap,
         |  gap_sum,
         |  sim1_5_order
         |from
         |(
         |select
         |  request_id,
         |  navi_id,
         |  x1,
         |  y1,
         |  x2,
         |  y2,
         |  src,
         |  similarity1 as sim1,
         |  similarity5 as sim5,
         |  sim1_5,
         |  distance,
         |  navi_distance,
         |  starts,
         |  ends,
         |  round(distance_gap, 2) as distance_gap,
         |  (
         |    CASE
         |      WHEN distance_gap < 0.05 THEN '小于5%'
         |      WHEN distance_gap >= 0.05
         |      AND distance_gap < 0.10 THEN '5%至10%'
         |      WHEN distance_gap >= 0.10
         |      AND distance_gap < 0.15 THEN '10%至15%'
         |      WHEN distance_gap >= 0.15
         |      AND distance_gap < 0.20 THEN '15%至20%'
         |      WHEN distance_gap >= 0.20
         |      AND distance_gap < 0.25 THEN '20%至25%'
         |      WHEN distance_gap >= 0.25
         |      AND distance_gap < 0.30 THEN '25%至30%'
         |      ELSE '大于30%'
         |    END
         |  ) AS gap_sum,
         |  row_number() OVER (
         |    PARTITION BY request_id
         |    ORDER BY
         |      sim1_5  desc
         |  ) as sim1_5_order
         |from
         |  (
         |    select
         |      request_id,
         |      navi_id,
         |      x1,
         |      y1,
         |      x2,
         |      y2,
         |      src,
         |      similarity1,
         |      similarity5,
         |      distance,
         |      navi_distance,
         |      regexp_replace(
         |        regexp_extract(tracks2, '\\\\[\\\\[[^\\\\]]+', 0),
         |        '\\\\[\\\\[',
         |        ''
         |      ) as starts,
         |      regexp_replace(
         |        regexp_extract(tracks2, '[^\\\\[]+\\\\]\\\\]', 0),
         |        '\\\\]\\\\]',
         |        ''
         |      ) as ends,
         |      ABS((distance - navi_distance) / distance) as distance_gap,
         |      (
         |        case
         |          when similarity1 < similarity5 then similarity5
         |          else similarity1
         |        end
         |      ) as sim1_5
         |    from
         |      dm_gis.gis_navi_top3_route_similarity
         |    where
         |      inc_day ='${incDay}'
         |      and navi_distance >= 1000
         |  ) a
         | ) aa
       """.stripMargin

    val source1Df = spark.sql(querySql)


    val sourceRdd1 = SparkUtils.getRowToJson(source1Df)
    logger.error("一致率输入数据量为：" + sourceRdd1.count())

    val sourRddProcess = getFilterDistanceTop3(sourceRdd1,"other")

    val (consistentRdd,coincidenceRdd) = getTop3Process(sourRddProcess,incDay)

    import spark.implicits._

    logger.error("top3一致率指标统计量为：" + consistentRdd.count())

    //保存到hive
    SparkUtils.df2Hive(spark,consistentRdd,reqTop3AccSchema,"append","dm_gis." + top3ConsistentTable,"statdate",incDay,logger)

    SparkUtils.df2Hive(spark,coincidenceRdd,reqTop3coincidenceSchema,"append","dm_gis." + top3CoincidenceTable,"statdate",incDay,logger)


    //保存到mysql
    SparkUtils.df2Mysql(spark,consistentRdd,reqTop3AccSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,top3ConsistentTable,incDay,logger)

    SparkUtils.df2Mysql(spark,coincidenceRdd,reqTop3coincidenceSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,top3CoincidenceTable,incDay,logger)


  }


  def processTop1ConsistentStatistics(spark:SparkSession, incDay:String, yesterday:String ):Unit = {

    logger.error("开始top1一致率统计")

    val querySql =
      s"""
         |select
         |  req_type,
         |  d.navi_id,
         |  sim1,
         |  sim5,
         |  sim15 sim1_5,
         |  src,
         |  route_index,
         |  (
         |    CASE
         |      WHEN distance_gap < 0.05 THEN '小于5%'
         |      WHEN distance_gap >= 0.05
         |      AND distance_gap < 0.10 THEN '5%至10%'
         |      WHEN distance_gap >= 0.10
         |      AND distance_gap < 0.15 THEN '10%至15%'
         |      WHEN distance_gap >= 0.15
         |      AND distance_gap < 0.20 THEN '15%至20%'
         |      WHEN distance_gap >= 0.20
         |      AND distance_gap < 0.25 THEN '20%至25%'
         |      WHEN distance_gap >= 0.25
         |      AND distance_gap < 0.30 THEN '25%至30%'
         |      ELSE '大于30%'
         |    END
         |  ) AS gap_sum
         |from
         |  (
         |    select
         |      req_type,
         |      a.navi_id,
         |      similarity1,
         |      similarity5,
         |      src,
         |      ABS((distance - navi_distance) / distance) as distance_gap,
         |      b.sim1,
         |      b.sim5,
         |      route_index,
         |      (
         |        CASE
         |          WHEN similarity15 > 0.8 THEN '1'
         |          ELSE '0'
         |        END
         |      ) AS sim15,
         |      (
         |        CASE
         |          WHEN distance > navi_distance THEN distance
         |          ELSE navi_distance
         |        END
         |      ) AS da,
         |      (
         |        CASE
         |          WHEN distance < navi_distance THEN distance
         |          ELSE navi_distance
         |        END
         |      ) AS xiao
         |    from
         |      (
         |        select
         |          id,
         |          req_type,
         |          navi_id,
         |          distance,
         |          src,
         |          route_index
         |        from
         |          dm_gis.gis_navi_eta_result1
         |        where
         |          inc_day ='${incDay}'
         |          and distance >= 1000
         |
         |      ) a
         |      JOIN (
         |        select
         |          id,
         |          similarity1,
         |          similarity5,
         |          navi_distance,
         |          (
         |            CASE
         |              WHEN similarity1 > 0.8 THEN '1'
         |              ELSE '0'
         |            END
         |          ) AS sim1,
         |          (
         |            CASE
         |              WHEN similarity5 > 0.8 THEN '1'
         |              ELSE '0'
         |            END
         |          ) AS sim5,
         |          (
         |            CASE
         |              WHEN similarity1 > similarity5 THEN similarity1
         |              ELSE similarity5
         |            END
         |          ) AS similarity15
         |        from
         |          dm_gis.gis_navi_eta_result2
         |        where
         |          inc_day ='${incDay}'
         |          and navi_distance >= 1000
         |          and trackstart_distance < 1000
         |          and trackend_distance < 1000
         |      ) b on a.id = b.id
         |  ) d
       """.stripMargin

    val source1Df = spark.sql(querySql)

    val sourceRdd1 = SparkUtils.getRowToJson(source1Df)
    logger.error("一致率输入数据量为：" + sourceRdd1.count())

    val sourRddProcess = sourceRdd1
      .map(obj => {
        val src = obj.getString("src")
        val srcMap = getSrcMap(obj)
        val route_index = obj.getString("route_index")

        ((srcMap,route_index),obj)
      })

    val (consistentRdd,coincidenceRdd) = getTop1Process(sourRddProcess,incDay)

    import spark.implicits._

    logger.error("top1一致率指标统计量为：" + consistentRdd.count())

    //保存到hive
    SparkUtils.df2Hive(spark,consistentRdd,reqTop1AccSchema,"append","dm_gis." + top1ConsistentTable,"statdate",incDay,logger)

    SparkUtils.df2Hive(spark,coincidenceRdd,reqTop1coincidenceSchema,"append","dm_gis." + top1CoincidenceTable,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,consistentRdd,reqTop1AccSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,top1ConsistentTable,incDay,logger)

    SparkUtils.df2Mysql(spark,coincidenceRdd,reqTop1coincidenceSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,top1CoincidenceTable,incDay,logger)

  }

  def start(spark: SparkSession,args: Array[String] ): Unit = {

    var incDay = ""
    var yesterday = ""

    if (args.length >2 ){
      incDay = args(0)
      yesterday = args(1)

      val funcArr = args.drop(2)

      println(incDay,yesterday)

      //反射调用任意统计方法
      funcArr.foreach(
        index => {
          val funcName = funcMap.get(index)
          println("\n\n\n"+s">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${funcName}开始<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
          this.getClass.getDeclaredMethod(funcName, classOf[SparkSession], classOf[String],classOf[String]).invoke(this, spark, incDay,yesterday)
          println("\n"+s">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${funcName}结束<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<"+"\n\n\n")
        }
      )

      logger.error(">>>统计结束!<<<")
    } else {
      logger.error("参数长度异常")
      System.exit(1)
    }


  }
}
