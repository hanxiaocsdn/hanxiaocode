package app.eta

import Utils.SparkUtils.writeToHive
import com.sf.gis.java.base.util.{SparkUtil, UrlUtil}
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, collect_list, concat, concat_ws, count, desc, expr, lit, lpad, round, row_number, sort_array, sum, trim, when}
import org.apache.spark.storage.StorageLevel


/**
 *需求名称：供应商路桥费异常监控
 *需求描述：包天包月任务结算时存在人工审核效率低，路桥费举证金额存疑等问题；由gis提供任务路桥费查询接口，避免人工审核提高审核效率以及使用国家路网中心结算路桥费数据确保任务路桥费准确性。
 *需求方：杨汶铭(ft80006323)
 *开发: 周勇(01390943)
 *任务创建时间：20230912
 *任务id：816668
 **/

object SupplierRoadBridgeFeesMonitor {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._
    val dayvar = args(0)
    logger.error("接收输入变量dayvar:" + dayvar)

    //计算监控数据
    val roadbridge_fees=spark.sql(
      s"""
         |select * from dm_gis.dm_supplier_roadbridge_fees_dtl
         |where inc_day>='20230829' and inc_day<='$dayvar'
         |and ctfo_task_fee>0 and task_type='0'
         |""".stripMargin)
      .withColumn("grp_flag",concat($"stop_dept",lit("_"),$"vehicle_type",lit("_"),$"line_code"))
      .withColumn("rate_temp",when($"rate".isNull || trim($"rate")==="",0.0).otherwise($"rate".cast("double")))
      .withColumn("fee",when($"fee".isNull || trim($"fee")==="",0.0).otherwise($"fee".cast("double")))
      .withColumn("rank",row_number().over(Window.partitionBy("grp_flag").orderBy(desc("rate_temp"))))
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("roadbridge_fees数据量："+roadbridge_fees.count())

    //分组计数，过滤小于4的
    val grp_ct=roadbridge_fees.groupBy("grp_flag")
      .agg(
        count($"inc_day") as "flag_ct"
      )
      .filter($"flag_ct">=4)

    logger.error("grp_ct数据量："+grp_ct.count())

    //增加里程分组，取最大的rate分组
    val highway_type_df=roadbridge_fees.filter($"rank"==="1")
      .withColumn("high_temp",when($"highway".isNull || trim($"highway")==="",0.0).otherwise($"highway".cast("double")) )
      .withColumn("highway_type",when($"high_temp">=0 && $"high_temp"<100000.0,"0-100km").
        when($"high_temp">=100000.0 && $"high_temp"<500000.0,"100-500km").
        when($"high_temp">=500000.0,"500km+")
        .otherwise(""))
      .select("stop_dept","vehicle_type","line_code","grp_flag","highway_type")

    logger.error("highway_type_df数据量："+highway_type_df.count())

    //计算组内众数
    val most_df=roadbridge_fees.groupBy("grp_flag","fee")
      .agg(
        count($"grp_flag") as "fee_ct"
      )
      .withColumn("rank2",row_number().over(Window.partitionBy("grp_flag").orderBy(desc("fee_ct"))))
      .filter($"rank2"===1)
      .withColumnRenamed("fee","fee_most")
      .select("grp_flag","fee_most")

    logger.error("most_df数据量："+most_df.count())

    //计算平均数
    val fee_avg=roadbridge_fees
      .join(most_df,Seq("grp_flag"),"left")
      .withColumn("tmp_fee1",$"fee_most"-500.0)
      .withColumn("tmp_fee2",$"fee_most"+500.0)
      .filter($"fee">=$"tmp_fee1" && $"fee"<=$"tmp_fee2")
      .withColumn("temp_rank",concat(lit("index"),lpad($"rank",12,"0")))
      .withColumn("hebing1",concat($"temp_rank",lit("__"),$"task_id"))
      .withColumn("hebing2",concat($"temp_rank",lit("__"),$"ctfo_task_fee"))
      .groupBy("grp_flag")
      .agg(sum($"fee") as "fee_sm",
        count($"fee") as "fee_ct",
        concat_ws("|",sort_array(collect_list($"hebing1"))) as "tmp1",
        concat_ws("|",sort_array(collect_list($"hebing2"))) as "tmp2",
        count($"hebing1") as "hb_ct"
      )
      .select(col("*"), expr("regexp_replace(tmp1, 'index([0-9]{12})__', '')").as("task_list"),
        expr("regexp_replace(tmp2, 'index([0-9]{12})__', '')").as("fee_list")
      )
      .withColumn("fee_most_avg",round($"fee_sm"/$"fee_ct",4))
      .filter($"hb_ct">=3)

    logger.error("fee_avg数据量："+fee_avg.count())

    //结果汇总,inner join过滤小于4的,过滤hb_ct小于3的
    val res_data=highway_type_df
      .join(grp_ct,Seq("grp_flag"))
      .join(most_df,Seq("grp_flag"),"left")
      .join(fee_avg,Seq("grp_flag"))
      .withColumn("inc_day",lit(dayvar))

    logger.error("res_data数据量："+res_data.count())

    //存储结果表
    val table_cols = spark.sql("""select * from dm_gis.dm_supplier_roadbridge_monitor_dtl limit 0""").schema.map(_.name).map(col)
    //存储dm表,每天全量存储
    writeToHive(spark, res_data.select(table_cols: _*) .coalesce(10) , Seq("inc_day"), "dm_gis.dm_supplier_roadbridge_monitor_dtl")
  }


}
