package app.eta

import Utils.SparkUtils.writeToHive
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, SparkUtil, UrlUtil}
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SparkSession, functions}
import org.apache.spark.sql.functions.{col, concat, count, desc, lit, row_number, trim, when}
import org.apache.spark.storage.StorageLevel
import uitls.UrlUtils.sendPost
import scala.collection.mutable.ArrayBuffer

/**
 *需求名称：潮汐线路道路等级分析
 *需求描述：潮汐线路将上线，上线前需要对数据进行摸底
 *需求方：杨汶铭(ft80006323)
 *开发: 周勇(01390943)
 *任务创建时间：20231020
 *任务id：872691
 **/

object TidalRouteRoadGrade {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )

  def main(args: Array[String]): Unit = {

    logger.error("初始化spark")
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession
    import spark.implicits._
    val dayvar = args(0)

    logger.error("接收输入变量dayvar:" + dayvar)

    //获取任务收费记录表
    val input_data=spark.sql(
      s"""
         |select *
         |from dm_gis.tide_event
         |where inc_day='$dayvar'
         |""".stripMargin)


    val (excutors, cores) = Spark.getExcutorInfo(spark)
    //计算并行数
    val calPartitions = excutors * cores * 3

    //转化rdd
    val sql_Rdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, input_data, calPartitions)

    //并发获取数据结果
    val multi_result=Multi_track_url(spark,sql_Rdd,calPartitions)

    //解析结果
    val multi_result2=multi_result.map(obj=>{
      val id=obj.getString("id")
      val event_name=obj.getString("event_name")
      val event_reason_code=obj.getString("event_reason_code")
      val event_or_code=obj.getString("event_or_code")
      val event_linkid=obj.getString("event_linkid")
      val event_start_time=obj.getString("event_start_time")
      val event_end_time=obj.getString("event_end_time")
      val event_duration=obj.getString("event_duration")
      val event_road_name=obj.getString("event_road_name")
      val event_pos=obj.getString("event_pos")
      val event_content=obj.getString("event_content")
      val confirm_status=obj.getString("confirm_status")
      val confirm_by=obj.getString("confirm_by")
      val confirm_time=obj.getString("confirm_time")
      val line_count=obj.getString("line_count")
      val exist_flag=obj.getString("exist_flag")
      val create_time=obj.getString("create_time")
      val update_time=obj.getString("update_time")
      val proadcode=obj.getString("proadcode")
      val level=obj.getString("level")

      tb1(id	,
        event_name	,
        event_reason_code	,
        event_or_code	,
        event_linkid	,
        event_start_time	,
        event_end_time	,
        event_duration	,
        event_road_name	,
        event_pos	,
        event_content	,
        confirm_status	,
        confirm_by	,
        confirm_time	,
        line_count	,
        exist_flag	,
        create_time	,
        update_time	,
        proadcode	,
        level)
    }).toDF()

    val tb_cols = spark.sql("""select * from dm_gis.tide_event_tmp limit 0""").schema.map(_.name).map(col)
    writeToHive(spark, multi_result2 .select(tb_cols:_*).coalesce(5), Seq("inc_day"), "dm_gis.tide_event_tmp")

    spark.close()
  }

  //定义样例类
  case class tb1(
                  id	:String,
                  event_name	:String,
                  event_reason_code	:String,
                  event_or_code	:String,
                  event_linkid	:String,
                  event_start_time	:String,
                  event_end_time	:String,
                  event_duration	:String,
                  event_road_name	:String,
                  event_pos	:String,
                  event_content	:String,
                  confirm_status	:String,
                  confirm_by	:String,
                  confirm_time	:String,
                  line_count	:String,
                  exist_flag	:String,
                  create_time	:String,
                  update_time	:String,
                  proadcode	:String,
                  level	:String
                )

  //定义获取url数据
  def track_url(ak:String,obj:JSONObject): JSONObject = {
    //使用新接口
    val url="http://gis-apis.int.sfcloud.local:1080/rp/navi/query/clusterLink"
    try {

      val id=obj.getString("id")
      val event_linkid=obj.getString("event_linkid")

      val parm_str=s"""{
                      |"ak": "0355667f460a4627b3dfb95c82d4175e",
                      |"gzip": "0",
                      |"output": "json",
                      |"swid": $event_linkid
                      |}
                      |""".stripMargin

      val retStr: String = sendPost(url,parm_str,3)
      val ret: JSONObject = JSON.parseObject(retStr)

      var iclass=""
      val iclassarr=new ArrayBuffer[String]()
      val clusters= ret.getJSONArray("clusters")
      val s=clusters.size()
      if(s>0){
        for(i<-0 until(s)){
          iclass=clusters.getJSONObject(i).getJSONArray("relLinks").getJSONObject(0).getString("iclass")
        }
        iclassarr.append(iclass)
      }

      obj.put("level",iclassarr.mkString("|"))

      logger.error("返回正确数据，车牌号："+id)
      Thread.sleep(200)
    } catch {
      case e: Exception =>
        val id=obj.getString("id")
        logger.error("返回错误数据，id："+id+"，错误信息："+e.getMessage)
    }
    obj
  }


  //调取接口并发请求
  def Multi_track_url(spark: SparkSession,DataRdd: RDD[JSONObject], calPartitions: Int) = {
    //调用开始上报
    val httpUrl="http://gis-apis.int.sfcloud.local:1080/rp/navi/query/clusterLink"
    val httpAk="0355667f460a4627b3dfb95c82d4175e"
    val dataCnt=DataRdd.count()
    val invokeThreadCnt=DataRdd.getNumPartitions
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01390943", "872691", "潮汐线路道路等级分析",
      "潮汐线路将上线，上线前需要对数据进行摸底",
      httpUrl, httpAk, dataCnt, invokeThreadCnt)
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,DataRdd, track_url, 1, "0355667f460a4627b3dfb95c82d4175e", 1000)
    //调用完成上报
    BdpTaskRecordUtil.endNetworkInterface("01390943", httpInvokeId)
    returnAtRDD
  }

}
