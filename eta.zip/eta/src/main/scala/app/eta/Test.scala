package app.eta

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION}
 @create 2024/2/19
*/ object Test {

}
