package app

import com.sf.gis.java.base.util.{DateUtil, SparkUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

class EtaStdLineRecallVms {

    private final val CLASS_NAME = this.getClass.getSimpleName.replace("$", "")
    @transient private final val LOGGER = LoggerFactory.getLogger(CLASS_NAME)

    /**
     * VMS日志表
     * @param spark SparkSession
     * @param curMonth 跑数日期当月
     * @param prevMonth 跑数日期上月
     * @return
     */
    def tt_vms_driving_log_item(spark: SparkSession, curMonth: String, prevMonth: String): DataFrame = {
        val sql =
            s"""
               |select
               |    task_id,
               |    miles as log_dist,
               |    road_fee
               |from
               |(
               |    select
               |		task_id,
               |		miles,
               |		road_fee,
               |		row_number() over(PARTITION by task_id ORDER by created_tm desc) as rn
               |	from ods_vms.tt_vms_driving_log_item
               |	where inc_month in ('$curMonth', '$prevMonth') and task_id is not null and length(task_id) < 15
               |) t
               |where rn = 1
               |""".stripMargin
        LOGGER.info(sql);
        spark.sql(sql);
    }

    def eta_std_line_recall(spark: SparkSession, incDay: String, beforeIncDay: String): DataFrame = {
        val sql =
            s"""
               |select
               |	*
               |from
               |(
               |	select
               |		*,
               |		row_number() over(partition by task_subid order by inc_day desc) rn
               |	from dm_gis.eta_std_line_recall
               |	where inc_day >= '$beforeIncDay' and inc_day <= '$incDay'
               |) t
               |where rn = 1
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def eta_std_line_recall1(spark: SparkSession, incDay: String, beforeIncDay: String): DataFrame = {
        val sql =
            s"""
               |select
               |	*
               |from
               |(
               |	select
               |		*,
               |		row_number() over(partition by task_id order by inc_day desc) rn
               |	from dm_gis.eta_std_line_recall1
               |	where inc_day >= '$beforeIncDay' and inc_day <= '$incDay'
               |) t
               |where rn = 1
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    /**
     * eta_std_line_recall_vms插入数据
     * @param spark SparkSession
     */
    def eta_std_line_recall_vms(spark: SparkSession): Unit = {
        val sql =
            s"""
               |insert overwrite table dm_gis.eta_std_line_recall_vms partition (inc_day)
               |select
               |	t1.task_area_code,
               |	t1.task_id,
               |	t1.sort_num,
               |	t1.task_subid,
               |	t1.start_dept,
               |	t1.end_dept,
               |	t1.start_type,
               |	t1.end_type,
               |	t1.line_code,
               |	t1.vehicle_serial,
               |	t1.actual_capacity_load,
               |	t1.plan_depart_tm,
               |	t1.actual_depart_tm,
               |	t1.plan_arrive_tm,
               |	t1.actual_arrive_tm,
               |	t1.driver_id,
               |	t1.driver_name,
               |	t1.line_time,
               |	t1.line_distance,
               |	t1.actual_run_time,
               |	t1.start_longitude,
               |	t1.start_latitude,
               |	t1.end_longitude,
               |	t1.end_latitude,
               |	t1.is_stop,
               |	t1.transoport_level,
               |	t1.carrier_type,
               |	t1.plf_flag,
               |	t1.vehicle_type,
               |	t1.axls_number,
               |	if(t3.log_dist is not null, t3.log_dist, t1.log_dist),
               |	t1.x1,
               |	t1.y1,
               |	t1.x2,
               |	t1.y2,
               |	t1.duration,
               |	t1.time,
               |	t1.rt_dist,
               |	t1.highwaymileage,
               |	t1.toll_charge,
               |	t1.start_distance,
               |	t1.end_distance,
               |	t1.error_type,
               |	t1.pns_dist,
               |	t1.pns_time,
               |	t1.src,
               |	t1.line_distance_std,
               |	t1.line_time_std,
               |	t1.sim1,
               |	t1.sim5,
               |	t1.diffdist_rt_line,
               |	t1.diffratio_rt_line,
               |	t1.diffdist_rt_std,
               |	t1.diffratio_rt_std,
               |	t1.diffdist_rt_log,
               |	t1.diffratio_rt_log,
               |	t1.diffdist_line_log,
               |	t1.diffratio_line_log,
               |	t1.diffdist_line_std,
               |	t1.diffratio_line_std,
               |	t1.diffdist_log_std,
               |	t1.diffratio_log_std,
               |	t1.conduct_type,
               |	t1.difftime_line_std,
               |	t1.diffratio1_line_std,
               |	t1.difftime_line_std_10min,
               |	t1.difftime_line_rt,
               |	t1.diffratio1_line_rt,
               |	t1.difftime_rt_gh_10min,
               |	t1.is_run_ontime_std,
               |	t1.is_run_ontime,
               |	t1.if_dist_equal,
               |	t1.if_time_equal,
               |	t1.pns_error,
               |	t1.task_inc_day,
               |	t1.difftime_std_rt,
               |	t1.diffratio1_std_rt,
               |	t1.difftime_std_rt_10min,
               |	t1.tl_time,
               |	t1.halfway_integrate_rate,
               |	t1.std_x1,
               |	t1.std_y1,
               |	t1.std_x2,
               |	t1.std_y2,
               |	t1.start_distance_std,
               |	t1.end_distance_std,
               |	t1.std_line_error,
               |	t1.ac_difftime_line_rt,
               |	t1.ac_diffratio1_line_rt,
               |	t1.ac_difftime_rt_gh_10min,
               |	t1.ac_difftime_std_rt,
               |	t1.ac_diffratio1_std_rt,
               |	t1.ac_difftime_std_rt_10min,
               |	t1.ac_is_run_ontime_std,
               |	t1.ac_is_run_ontime,
               |	t1.if_evaluate_time,
               |	t1.carrier_name,
               |	t1.stop_over_zone_code,
               |	t1.biz_type,
               |	t1.require_category,
               |	t1.to_ground,
               |	t1.std_toll_charge,
               |	t1.std_id,
               |	t1.navi_strategy,
               |	t1.is_return_std_line,
               |	t1.is_navi_at_start,
               |	t1.is_navi_by_std_line,
               |	t1.route_time,
               |	t1.drive_time,
               |	t1.is_yaw_by_driver,
               |	t1.navi_complete_rate,
               |	t1.accrual_dist,
               |	t1.accrual_dist_type,
               |	t1.last_update_tm,
               |	t1.main_driver_account,
               |	if(t3.road_fee is not null, t3.road_fee, t1.road_fee),
               |	null,
               |    t1.inc_day
               |from t1
               |left join t3
               |on t1.task_id = t3.task_id
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def eta_std_line_recall1_vms(spark: SparkSession): Unit = {
        val sql =
            s"""
               |insert overwrite table dm_gis.eta_std_line_recall1_vms partition (inc_day)
               |select
               |	t2.task_area_code,
               |	t2.task_id,
               |	t2.carrier_name,
               |	t2.task_inc_day,
               |	t2.start_dept,
               |	t2.start_type,
               |	t2.line_code,
               |	t2.vehicle_serial,
               |	t2.actual_capacity_load,
               |	t2.plan_depart_tm,
               |	t2.actual_depart_tm,
               |	t2.driver_id,
               |	t2.driver_name,
               |	t2.is_stop,
               |	t2.transoport_level,
               |	t2.carrier_type,
               |	t2.plf_flag,
               |	t2.vehicle_type,
               |	t2.axls_number,
               |	if(t3.log_dist is not null, t3.log_dist, t2.log_dist),
               |	t2.if_evaluate_time,
               |	t2.stop_over_zone_code,
               |	t2.end_dept,
               |	t2.end_type,
               |	t2.plan_arrive_tm,
               |	t2.actual_arrive_tm,
               |	t2.line_time,
               |	t2.line_distance,
               |	t2.actual_run_time,
               |	t2.duration,
               |	t2.time,
               |	t2.rt_dist,
               |	t2.highwaymileage,
               |	t2.toll_charge,
               |	t2.pns_dist,
               |	t2.pns_time,
               |	t2.std_toll_charge,
               |	t2.if_error,
               |	t2.src,
               |	t2.conduct_type,
               |	t2.ac_is_run_ontime,
               |	t2.diffdist_log_rt,
               |	t2.diffratio_log_rt,
               |	t2.accrual_dist,
               |	t2.accrual_dist_type,
               |	t2.last_update_tm,
               |	t2.main_driver_account,
               |	if(t3.road_fee is not null, t3.road_fee, t2.road_fee),
               |	null,
               |    t2.inc_day
               |from t2
               |left join t3
               |on t2.task_id = t3.task_id
               |""".stripMargin
        LOGGER.info(sql)
        spark.sql(sql)
    }

    def execute(spark: SparkSession, incDay: String, beforeIncDay: String, curMonth: String, prevMonth: String): Unit = {
        val table1 = eta_std_line_recall(spark, incDay, beforeIncDay)
        table1.createOrReplaceTempView("t1")
        val table2 = eta_std_line_recall1(spark, incDay, beforeIncDay)
        table2.createOrReplaceTempView("t2")
        val table3 = tt_vms_driving_log_item(spark, curMonth, prevMonth)
        table3.createOrReplaceTempView("t3")

        eta_std_line_recall_vms(spark)
        LOGGER.info("eta_std_line_recall_vms数据插入成功")
        eta_std_line_recall1_vms(spark)
        LOGGER.info("eta_std_line_recall1_vms数据插入成功")
    }
}

object EtaStdLineRecallVms {
    def main(args: Array[String]): Unit = {
        val task = new EtaStdLineRecallVms
        if (args == null || args.length != 1 || StringUtils.isEmpty(args(0))) {
            task.LOGGER.error("请传入参数")
            return
        }
        val incDay = args(0)
//        val beforeIncDay = DateUtil.getBeforeNDay(incDay, -30)
//        val curDay = DateUtil.getBeforeNDay(incDay, 1)
//        val curMonth = DateUtil.getBeforeNMonth(curDay, 0)
//        val prevMonth = DateUtil.getBeforeNMonth(curDay, -1)

        val beforeIncDay = DateUtil.getDayBefore(incDay, "yyyyMMdd", 30)
        val curDay = DateUtil.getDayBefore(incDay, "yyyyMMdd", -1)
        val curMonth = DateUtil.getMonthBefore(curDay, "yyyyMMdd",0).substring(0,6)
        val prevMonth = DateUtil.getMonthBefore(curDay, "yyyyMMdd",1).substring(0,6)
        task.LOGGER.info("#########################################")
        task.LOGGER.info("incDay: [{}]", incDay)
        task.LOGGER.info("beforeIncDay: [{}]", beforeIncDay)
        task.LOGGER.info("curMonth: [{}]", curMonth)
        task.LOGGER.info("prevMonth: [{}]", prevMonth)
        task.LOGGER.info("#########################################")

        val SparkInfo = SparkUtil.getSpark(task.CLASS_NAME)
        val spark = SparkInfo.getSession
        task.execute(spark, incDay, beforeIncDay, curMonth, prevMonth)
        task.LOGGER.info("任务执行完成")

        spark.stop()
    }
}
