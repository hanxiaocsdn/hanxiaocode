package app

import java.text.SimpleDateFormat
import java.util
import java.util.{Calendar, Date, Map}
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{DateUtil, HttpConnection}
import com.sf.gis.scala.base.spark.Spark
import entry.vehicleLssEntry.VahicleLss
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * 需求描述 :  车管风险任务监控表
 * 开发负责人: guofangcai
 * 开发日期: 20220208
 * 功能表述： 1. 获取dm_gis.eta_std_line_task_parse最近一天数据,以相同的起始网点和结束网点分组
 *           2. 分组数据校验轨迹信息
 *           3. 轨迹信息校验相似度判断是否是同一个
 *           4. 落地表 dm_gis.eta_vehicle_management_risk_monitoring
 */
object VehicleManagementRiskMonitoring {

  val TRACK_QUERY_URL: String = "http://query-gis-vms-core.dcn-gis1.k8s.sf-express.com/trackquery/api/integrateDetail"
  val LSS_RECTIFY_URL: String = "http://tlocrectify-gis-lss-tloc.dcn-gis1.k8s.sf-express.com/lssrectify/api/comparetracks"

  val className : String  = this.getClass.getSimpleName.stripSuffix("$")
  val logger: Logger = LoggerFactory.getLogger(className)


  //  case  class  VehicleEntry(id:String,a_track:String,b_track:String ,a_len:BigDecimal, a_similarity:BigDecimal,b_len:BigDecimal, b_similarity:BigDecimal)

  def getSourceDataSql(inc_day: String) : String  = {
    //数据获取sql拼接
    val lineTaskParseSql : String =
      s"""
       -- 源表获取初始化数据
      with eta_std_line_task_parse_double as (
      select  start_dept
        ,start_dept_site_id
        ,end_dept
        ,end_dept_site_id
        ,task_id
        ,plan_depart_tm
        ,actual_depart_tm
        ,plan_arrive_tm
        ,actual_arrive_tm
        ,vehicle_serial
        ,driver_id
        ,driver_name
        ,line_distance
        ,biz_type
        ,carrier_name
        ,carrier_type
        ,is_stop
        ,full_load_weight
        ,contnr_code
        --,inc_day
      from (select start_dept
          ,start_dept_site_id
          ,end_dept
          ,end_dept_site_id
          ,task_id
          ,plan_depart_tm
          ,actual_depart_tm
          ,plan_arrive_tm
          ,actual_arrive_tm
          ,vehicle_serial
          ,driver_id
          ,driver_name
          ,line_distance
          ,biz_type
          ,carrier_name
          ,carrier_type
          ,is_stop
          --,'' as lw
          ,full_load_weight
          --,'' as load_ratio
          --,'' as dp
          ,contnr_code
          --,'' as len
          --,'' as track
          -- ,'' as similarity
          --,inc_day
          ,count(1) over(partition by start_dept,start_dept_site_id,end_dept,end_dept_site_id) as rownum
      from dm_gis.eta_std_line_task_parse
      where inc_day = '$inc_day'
      and state =6 and biz_type < 90) t0  where  rownum >1
      )
      --获取组内两两数据, 并计算出实际出发时间和倒车时间差
      ,eta_std_line_task_parse_join as (
      select  concat(t0.task_id,"_",t1.task_id) as id
        ,t0.start_dept as start_dept
        ,t0.start_dept_site_id as start_dept_site_id
        ,t0.end_dept as end_dept
        ,t0.end_dept_site_id as end_dept_site_id
        ,t0.task_id as a_task_id
        ,t0.plan_depart_tm as a_plan_depart_tm
        ,t0.actual_depart_tm as a_actual_depart_tm
        ,t0.plan_arrive_tm as a_plan_arrive_tm
        ,t0.actual_arrive_tm as a_actual_arrive_tm
        ,t0.vehicle_serial as a_vehicle_serial
        ,t0.driver_id as a_driver_id
        ,t0.driver_name as a_driver_name
        ,t0.line_distance as a_line_distance
        ,t0.biz_type as a_biz_type
        ,t0.carrier_name as a_carrier_name
        ,t0.carrier_type as a_carrier_type
        ,t0.is_stop as a_is_stop
        ,t0.full_load_weight as a_full_load_weight
        ,t0.contnr_code  as a_contnr_code
        ,t1.start_dept as b_start_dept
        ,t1.end_dept as b_end_dept
        ,t1.task_id as b_task_id
        ,t1.plan_depart_tm as b_plan_depart_tm
        ,t1.actual_depart_tm as b_actual_depart_tm
        ,t1.plan_arrive_tm as b_plan_arrive_tm
        ,t1.actual_arrive_tm as b_actual_arrive_tm
        ,t1.vehicle_serial as b_vehicle_serial
        ,t1.driver_id as b_driver_id
        ,t1.driver_name as b_driver_name
        ,t1.line_distance as b_line_distance
        ,t1.biz_type as b_biz_type
        ,t1.carrier_name as b_carrier_name
        ,t1.carrier_type as b_carrier_type
        ,t1.is_stop as b_is_stop
        ,t1.full_load_weight as b_full_load_weight
        ,t1.contnr_code  as b_contnr_code
        ,COALESCE(unix_timestamp(t0.actual_depart_tm),0) - COALESCE(unix_timestamp(t1.actual_depart_tm),0) as diftime_depart
        ,COALESCE(unix_timestamp(t0.actual_arrive_tm),0) - COALESCE(unix_timestamp(t1.actual_arrive_tm),0) as diftime_arrive
        --,inc_day
      from eta_std_line_task_parse_double t0
      inner join  eta_std_line_task_parse_double t1
      on t0.start_dept=t1.start_dept
      and t0.end_dept=t1.end_dept
      and t0.start_dept_site_id = t1.start_dept_site_id
      and t0.end_dept_site_id = t1.end_dept_site_id
      where t1.task_id <> t0.task_id
      )
      --过滤实际出发时间和实际到达时间都在5分钟内的数据
      select
        id
        ,start_dept
        ,start_dept_site_id
        ,end_dept
        ,end_dept_site_id
        ,a_task_id
        ,a_plan_depart_tm
        ,a_actual_depart_tm
        ,a_plan_arrive_tm
        ,a_actual_arrive_tm
        ,a_vehicle_serial
        ,a_driver_id
        ,a_driver_name
        ,a_line_distance
        ,a_biz_type
        ,a_carrier_name
        ,a_carrier_type
        ,a_is_stop
        ,'' as a_lw
        ,a_full_load_weight
        ,'' as a_load_ratio
        ,'' as a_dp
        ,a_contnr_code
        ,'' as a_len
        ,'' as a_track
        ,'' as a_similarity
        ,b_task_id
        ,b_plan_depart_tm
        ,b_actual_depart_tm
        ,b_plan_arrive_tm
        ,b_actual_arrive_tm
        ,b_vehicle_serial
        ,b_driver_id
        ,b_driver_name
        ,b_line_distance
        ,b_biz_type
        ,b_carrier_name
        ,b_carrier_type
        ,b_is_stop
        ,'' as b_votes_dw
        ,b_full_load_weight
        ,'' as b_load_ratio
        ,b_contnr_code
        ,'' as b_dp
        ,'' as b_len
        ,'' as b_track
        ,'' as b_similarity
        ,'' as http_result_status
        ,'' as http_result_msg
        , unix_timestamp() as etl_time
        , '$inc_day' as inc_day
      from
      (
      select
        *
        ,row_number() over(partition by concatid order by id) as rn
      from
      (
        select
          *,if(split('id','_')[0] < split('id','_')[1],concat(split('id','_')[0],split('id','_')[1]),concat(split('id','_')[1],split('id','_')[0]))  as concatid
        from
          eta_std_line_task_parse_join
      ) a
      where  abs(cast(diftime_depart/60 as bigint))<5
      and abs(cast(diftime_arrive/60 as bigint))<5
      ) aa
      where aa.rn = 1
      """
    lineTaskParseSql
  }


  /**
   * map 函数，  分区遍历对应的数据发起http 请求
   * @param vahicleLsss
   * @return
   */
  def builderVehichleLssByHttp(vahicleLsss: Iterator[VahicleLss], threadSleepTime : Int): Iterator[VahicleLss] ={
    {
      // 获取
      var dfBuffer = new ArrayBuffer[VahicleLss]()
      while(vahicleLsss.hasNext) {
        //初始化
        val vahicleLss = vahicleLsss.next()

        val a_vehicle_serial = vahicleLss.a_vehicle_serial
        val a_actual_depart_tm = vahicleLss.a_actual_depart_tm
        val a_actual_arrive_tm = vahicleLss.a_actual_arrive_tm
        val b_vehicle_serial = vahicleLss.b_vehicle_serial
        val b_actual_depart_tm =vahicleLss.b_actual_depart_tm
        val b_actual_arrive_tm = vahicleLss.b_actual_arrive_tm


        val  vahicleLssJson: JSONObject = new  JSONObject()
        vahicleLssJson.put("a_len","")
        vahicleLssJson.put("a_similarity","")
        vahicleLssJson.put("a_track","")
        vahicleLssJson.put("b_len","")
        vahicleLssJson.put("b_similarity","")
        vahicleLssJson.put("b_track","")
        vahicleLssJson.put("http_result_status","")
        vahicleLssJson.put("http_result_mgs","")

        var http_result_status = ""
        var http_result_mgs = ""
        breakable{
          val (resultCode_a, resultMsg_a, track_a) = builderTracksByHttp(a_vehicle_serial, a_actual_depart_tm, a_actual_arrive_tm)

          if (!"0".equalsIgnoreCase(resultCode_a)) {
            http_result_status = "A"
            http_result_mgs = resultMsg_a
            vahicleLssJson.put("http_result_status", http_result_status)
            vahicleLssJson.put("http_result_mgs", http_result_mgs)
            dfBuffer += builderVehicleLssEntntry(vahicleLss, vahicleLssJson)
            break
          }

          if("0".equalsIgnoreCase(resultCode_a) && track_a==null){
            http_result_status = "A"
            http_result_mgs = "A轨迹串为空"
            vahicleLssJson.put("http_result_status",http_result_status)
            vahicleLssJson.put("http_result_mgs",http_result_mgs)
            dfBuffer +=  builderVehicleLssEntntry(vahicleLss,vahicleLssJson)
            break
          }
          vahicleLssJson.put("a_track",track_a)

          val (resultCode_b, resultMsg_b, track_b) = builderTracksByHttp(b_vehicle_serial, b_actual_depart_tm, b_actual_arrive_tm)
          if (!"0".equalsIgnoreCase(resultCode_b)) {
            http_result_status = "B"
            http_result_mgs = resultMsg_b
            vahicleLssJson.put("http_result_status",http_result_status)
            vahicleLssJson.put("http_result_mgs",http_result_mgs)
            dfBuffer +=  builderVehicleLssEntntry(vahicleLss,vahicleLssJson)
            break
          }
          if("0".equalsIgnoreCase(resultCode_b) && track_b==null){
            http_result_status = "B"
            http_result_mgs = "B轨迹串为空"
            vahicleLssJson.put("http_result_status",http_result_status)
            vahicleLssJson.put("http_result_mgs",http_result_mgs)
            dfBuffer +=  builderVehicleLssEntntry(vahicleLss,vahicleLssJson)
            break
          }
          vahicleLssJson.put("b_track",track_b)

          var a_len: BigDecimal = 0.00 // 需要转换成km
          var a_similarity: BigDecimal = 0.00
          var b_len: BigDecimal = 0.00 // 需要转换成km
          var b_similarity: BigDecimal = 0.00


          //轨迹校验,只要有一个轨迹不为空的时候都需要获取对应的校验数据
          val (lssResultCode,lssResultMsg,resultData) = builderLssrectifyByHttp(renameJsonKey(track_a), renameJsonKey(track_b))

          if (!"0".equalsIgnoreCase(lssResultCode)) {
            http_result_status = "2"
            http_result_mgs = lssResultMsg
            vahicleLssJson.put("http_result_status",http_result_status)
            vahicleLssJson.put("http_result_mgs",http_result_mgs)
            dfBuffer +=  builderVehicleLssEntntry(vahicleLss,vahicleLssJson)
            break
          }

          vahicleLssJson.put("http_result_status","0")
          vahicleLssJson.put("http_result_mgs","成功")

          //        把轨迹信息和轨迹校验信息合并
          a_len = try{ resultData.getBigDecimal("len1")}catch {case _=> 0.00}// 需要转换成km
          a_len = a_len/1000
          vahicleLssJson.put("a_len",a_len.toString())

          a_similarity = try{ resultData.getBigDecimal("similarity1")}catch {case _=> 0.00}
          vahicleLssJson.put("a_similarity",a_similarity.toString())

          b_len = try{ resultData.getBigDecimal("len2")}catch {case _=> 0.00}  //需要转换成km
          b_len = b_len/1000
          vahicleLssJson.put("b_len",b_len.toString())
          println( b_len.toString())
          b_similarity = try{ resultData.getBigDecimal("similarity2")}catch {case _=> 0.00}
          vahicleLssJson.put("b_similarity",b_similarity.toString())
          dfBuffer += builderVehicleLssEntntry(vahicleLss,vahicleLssJson)
        }
        Thread.sleep(threadSleepTime)
      }
      dfBuffer.iterator
    }
  }



  /**
   * 构建返回实体
   * @param vahicleLss
   * @param json
   * @return
   */
  def builderVehicleLssEntntry(vahicleLss : VahicleLss,  json: JSONObject): VahicleLss={
    VahicleLss(vahicleLss.id
      ,vahicleLss.start_dept
      ,vahicleLss.start_dept_site_id
      ,vahicleLss.end_dept
      ,vahicleLss.end_dept_site_id
      ,vahicleLss.a_task_id
      ,vahicleLss.a_plan_depart_tm
      ,vahicleLss.a_actual_depart_tm
      ,vahicleLss.a_plan_arrive_tm
      ,vahicleLss.a_actual_arrive_tm
      ,vahicleLss.a_vehicle_serial
      ,vahicleLss.a_driver_id
      ,vahicleLss.a_driver_name
      ,vahicleLss.a_line_distance
      ,vahicleLss.a_biz_type
      ,vahicleLss.a_carrier_name
      ,vahicleLss.a_carrier_type
      ,vahicleLss.a_is_stop
      ,vahicleLss.a_lw
      ,vahicleLss.a_full_load_weight
      ,vahicleLss.a_load_ratio
      ,vahicleLss.a_dp
      ,vahicleLss.a_contnr_code
      ,json.getString("a_len")
      ,json.getString("a_track")
      ,json.getString("a_similarity")
      ,vahicleLss.b_task_id
      ,vahicleLss.b_plan_depart_tm
      ,vahicleLss.b_actual_depart_tm
      ,vahicleLss.b_plan_arrive_tm
      ,vahicleLss.b_actual_arrive_tm
      ,vahicleLss.b_vehicle_serial
      ,vahicleLss.b_driver_id
      ,vahicleLss.b_driver_name
      ,vahicleLss.b_line_distance
      ,vahicleLss.b_biz_type
      ,vahicleLss.b_carrier_name
      ,vahicleLss.b_carrier_type
      ,vahicleLss.b_is_stop
      ,vahicleLss.b_votes_dw
      ,vahicleLss.b_full_load_weight
      ,vahicleLss.b_load_ratio
      ,vahicleLss.b_dp
      ,vahicleLss.b_contnr_code
      ,json.getString("b_len")
      ,json.getString("b_track")
      ,json.getString("b_similarity")
      ,json.getString("http_result_status")
      ,json.getString("http_result_mgs")
      ,vahicleLss.etl_time
      ,vahicleLss.inc_day
    )
  }

  /**
   * 日志级别默认是info, 日期默认是当前时间的前一天
   * @param args
   */
  def parseArgs(args : Array[String])={
    var  logLevel = "INFO"
    //解析传入参数的
    var inc_day: String = args(0)
    logger.info( args(0)  +  inc_day)
    if(inc_day==null || inc_day.length==0){
      logger.warn("传入日期参数为空, 采用默认日期(当前日期-1)")
      inc_day = DateUtil.getDayBefore(new Date ().formatted("yyyy-MM-dd"), "yyyyMMdd", 1)
    }
    if (args.length > 1){
      logLevel = args(1)
    }
    (inc_day,logLevel)
  }


  /**
   * 正式发送请求，并且设置重试机制; 重试 1次默认
   * @param url
   * @param param
   * @return
   */
  def requestSend (url:String, param: JSONObject, isTrack: Boolean , retryCount: Int = 1): Map[String, AnyRef] ={

    //获取track数据并解析
    var httpData: util.Map[String, AnyRef] = null
    httpData =  HttpConnection.sendPost(url, param.toJSONString)
    var count = 0
    //重试
    while (!httpData.getOrDefault("code","").equals("1") && count < retryCount){
      count=count+1
      val second = Calendar.getInstance().get(Calendar.SECOND)
      Thread.sleep(60 - second)
      httpData =  HttpConnection.sendPost(url, param.toJSONString)
    }
    httpData
  }

  /**
   * 解析轨迹串
   * @param httpData
   * @return
   */
  def parseTrackHttpData(httpData:Map[String, AnyRef]) : (String,String,JSONArray) ={
    var reqJsonObject : JSONArray = null
    // 0  1 , 2
    if (httpData.get("content") != null ) {
      val req = JSON.parseObject(httpData.get("content").toString)

      //获取返回请求返回状态
      val codeStatue = req.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        logger.error("获取track数据失败: " + req.getJSONObject("result").toJSONString)
        return (codeStatue, req.getJSONObject("result").getString("msg"), null)
      } else {
        reqJsonObject =
          try {
            req.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          } catch {
            case _ => null
          }
        return (codeStatue, "成功", reqJsonObject)
      }
    }
    ("2", "请求失败",null)
  }


  /**
   * 解析相似度校验
   * @param httpData
   * @return
   */
  def parseLssrectifyHttpData(httpData:Map[String, AnyRef]) :  (String,String,JSONObject) ={
    var reqJsonObject : JSONObject = null
    if (httpData.get("content") != null ) {
      val req = JSON.parseObject(httpData.get("content").toString)

      //判断获取的数据是否成功
      val codeStatue =  req.getString("status")
      if(!"0".equalsIgnoreCase(codeStatue)) {
        logger.error("获取track数据失败: " + req.getJSONObject("result").toJSONString)
        return (codeStatue,req.getJSONObject("result").getString("msg"),null)
      }

      reqJsonObject =
        try {
          req.getJSONObject("result")
        } catch  {
          case _ => null
        }
      return (codeStatue, "成功",reqJsonObject)
    }
    ("2", "请求失败",null)
  }

  /**
   * 调用 url 接口获取对应的,当没有
   * @param vehicle_serial
   * @param actual_depart_tm
   * @param actual_arrive_tm
   * @return
   */
  def builderTracksByHttp (vehicle_serial:String, actual_depart_tm:String, actual_arrive_tm:String ) : (String,String,JSONArray) = {

    //初始化参数
    val param = new JSONObject()
    param.put("type","0")
    param.put("un",vehicle_serial)
    param.put("ak","ee4e9708c797414a8bdfbe695b201dcf")

    val spToDate  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val spToString = new SimpleDateFormat("yyyyMMddHHmmss")
    println(spToString.format(spToDate.parse(actual_depart_tm)))

    param.put("beginDateTime",spToString.format(spToDate.parse(actual_depart_tm)))
    param.put("endDateTime",spToString.format(spToDate.parse(actual_arrive_tm)))
    //    param.put("endDateTime","")

    val httpData =  requestSend(TRACK_QUERY_URL,param,true,3)


    var (codeStatu,resultMsg,result): (String,String,JSONArray)  = parseTrackHttpData(httpData)

    if (null ==result || result.size()==0){
      codeStatu = "1"
      result = null
      logger.warn("车牌号: "+vehicle_serial + " 实际发车时间 : " + actual_depart_tm  + "  实际到车时间 : " + actual_arrive_tm + " 没有对应轨迹信息")
    }else {
      logger.info("车牌号: "+vehicle_serial + " 实际发车时间 : " + actual_depart_tm  + "  实际到车时间 : " + actual_arrive_tm + " 轨迹信息: " +result.toJSONString)
    }
    (codeStatu,resultMsg,result)
  }

  /**
   * 轨迹数据校验
   * @param track_a
   * @paam track_b
   * @return
   */
  def builderLssrectifyByHttp(track_a: JSONArray, track_b : JSONArray ): (String,String,JSONObject) ={

    //初始化参数
    val param = new JSONObject()
    param.put("ak","ee4e9708c797414a8bdfbe695b201dcf")
    param.put("vehicle",5)
    param.put("retflag",3)
    param.put("tracktype","2")
    param.put("tracks1",track_a)
    param.put("tracks2",track_b)


    val httpData =  requestSend(LSS_RECTIFY_URL,param,false,3)
    val (codeStatu,resultMsg,result): (String,String,JSONObject)  = parseLssrectifyHttpData(httpData)

    if (null ==result || result.size()==0){
      logger.warn("轨迹信息: "+track_a + " 与轨迹信息 : " + track_b  + "  没有对应轨迹校验信息")
      return  ("2","轨迹校验信息为空",result)
    }
    logger.info("轨迹信息: "+track_a + " 与轨迹信息 : " + track_b  + "  对应轨迹校验信息" +result.toJSONString)
    (codeStatu,"成功",result)
  }

  /**
   * 修改json key 值
   * @param trackJsonArray
   * @return
   */
  def renameJsonKey(trackJsonArray : JSONArray ): JSONArray ={
    import scala.collection.JavaConversions._

    val trackJsonArray_new : JSONArray = new JSONArray()

    for( i <- 0 to trackJsonArray.size()-1){

      val jsonTrack  =  trackJsonArray.getJSONObject(i)

      //替换key
      val  track_new : JSONObject  = new JSONObject()
      for (entry <- jsonTrack.entrySet()){
        val key  = entry.getKey
        val value  = entry.getValue
        if ("zx".equals(key)){
          track_new.put("x",value )
        }else if("zy".equals(key)){
          track_new.put("y",value )
        }else if("tm".equals(key)){
          track_new.put("time",value )
        }else if("sp".equals(key)){
          track_new.put("speed",value )
        }
      }
      trackJsonArray_new.add(track_new)
    }
    trackJsonArray_new
  }
}
