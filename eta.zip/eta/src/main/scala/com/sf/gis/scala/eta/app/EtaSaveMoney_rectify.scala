//package com.sf.gis.scala.eta.app
//
//import com.alibaba.fastjson.{JSONArray, JSONObject}
//import com.sf.gis.scala.base.spark.Spark
//import com.sf.gis.scala.base.util.DateUtil
//import org.apache.commons.lang3.StringUtils
//import org.apache.log4j.Logger
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.SparkSession
//
//import scala.collection.mutable.ArrayBuffer
//
//
//object EtaSaveMoney_rectify {
//  val appName:String = this.getClass.getSimpleName.replace("$","")
//  val logger:Logger = Logger.getLogger(appName)
//
//  val rectify_url = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"
//
//  val need_keys = Array("index","sum_dist","matchOrder","formway","light","gas","SWID","roadclass","time","x","y")
//
//  def main(args: Array[String]): Unit = {
//
//    var date = DateUtil.getYesterday
//    val sparkSession = Spark.getSparkSession(appName)
//    if (args.length == 0) {
//      //代码内部传入日期参数
//      startLog(sparkSession,date)
//    } else if (args.length == 1) {
//      //传入参数，单天任务
//      startLog(sparkSession,args(0))
//    } else if (args.length == 2) {
//      //传入参数，多天任务 [左闭右开)
//      batchTask(sparkSession,args(0), args(1))
//    }
//
//    logger.error(">>>处理完毕---------------")
//  }
//
//
//  def batchTask(sparkSession :SparkSession,startDate: String, endDate: String): Unit = {
//    var dateList = DateUtil.getTwoDatesStr(startDate, endDate)
//    logger.error(">>>处理" + dateList.size + "天任务：" + dateList.mkString(","))
//    for (date <- dateList) {
//      startLog(sparkSession,date)
//    }
//  }
//
//
//  def startLog(sparkSession :SparkSession,date:String): Unit = {
//
//
//    var computeRddF:(SinkUnbound[JSONObject]) => SinkUnbound[JSONObject] = null
//    var table = ""
//    var structs:Array[String] = null
//    var keys:Array[String] = null
//    var saveHiveRddF:(BlockingFactory,SinkUnbound[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit = mutiDayRddToHive
//    var dateList:ArrayBuffer[String] = new ArrayBuffer[String]()
//
//    dateList += DateUtil.getDateStr(date, -2)
//    dateList += DateUtil.getDateStr(date, -1)
//    dateList += date
//
//
//    computeRddF = computeRectify
//    table = "gis_eta_save_money_rectify"
//    structs = Array("id","task_id","line_code","plate","is_push_line","tracks2","duration","time","len","highwaymileage","toll_mileage","overlap","toll_charge","etc_toll_charge","rec_dic","track_status","is_stop","transoport_level")
//    keys = structs
//
//    logger.error("开始处理" + date)
//    logger.error(">>>处理"+dateList.mkString(",")+"号的所有日志")
//    parseSaveLog(sparkSession,computeRddF,table,structs,keys,saveHiveRddF,dateList)
//
//  }
//
//
//  def parseSaveLog(sparkSession: SparkSession,
//                    computeRddF:(SinkUnbound[JSONObject]) => SinkUnbound[JSONObject], table: String, structs:Array[String], keys:Array[String], saveHiveRddF:(BlockingFactory,SinkUnbound[JSONObject],String,Array[String],Array[String],ArrayBuffer[String]) => Unit, dateList:ArrayBuffer[String]): Unit ={
//    val etaComputeRdd = getRectify(sparkSession,dateList)
//    if(etaComputeRdd!=null){
//      if(computeRddF!=null){
//        val resultRdd = computeRddF(etaComputeRdd)
//        etaComputeRdd.unpersist()
//        saveHiveRddF(blockFactory,resultRdd,table,structs,keys,dateList)
//        resultRdd.unpersist()
//      }
//      else{
//        saveHiveRddF(blockFactory,etaComputeRdd,table,structs,keys,dateList)
//        etaComputeRdd.unpersist()
//      }
//    }
//  }
//
//
//  def mutiDayRddToHive(blockFactory:BlockingFactory, resultRdd:SinkUnbound[JSONObject], table: String, structs:Array[String], keys:Array[String], dateList:ArrayBuffer[String]): Unit ={
//    for(date<-dateList){
//      val resultRdd2 = filterRdd(resultRdd,date)
//      EtaLogParse.filterRddToHive(blockFactory,resultRdd2,table,structs,keys,date)
//    }
//    resultRdd.unpersist()
//  }
//
//
//  def filterRdd(resultRdd:SinkUnbound[JSONObject], date:String): SinkUnbound[JSONObject] ={
//    val dateRdd = resultRdd.filter(json=>{
//      val inc_date = json.getString("inc_date")
//      inc_date!=null && inc_date.equals(date)
//    }).persist()
//
//    dateRdd
//  }
//
//
//  def getRectify(sparkSession:SparkSession, dateList:ArrayBuffer[String]) ={
//    var sql=""
//    if(dateList.size == 1){
//      val date = dateList(0)
//      sql =
//        s"""
//           |select a.id,a.task_id,a.line_code,a.plate,a.is_push_line,a.mload,a.axle_number,a.weight,a.size,a.is_stop,a.transoport_level,b.tracks1_origin,a.inc_date from
//           |(select id,task_id,line_code,plate,is_push_line,mload,axle_number,weight,size,is_stop,transoport_level,inc_day as inc_date from dm_gis.gis_eta_save_money_finish where inc_day='$date' and is_push_line='1') a
//           |left join (select id,tracks1_origin from dm_gis.gis_eta_save_money_track where inc_day='$date') b on a.id=b.id
//       """.stripMargin
//    }
//    else{
//      val startDate = dateList(0)
//      val endDate = dateList(dateList.size - 1)
//      sql =
//        s"""
//           |select a.id,a.task_id,a.line_code,a.plate,a.is_push_line,a.mload,a.axle_number,a.weight,a.size,a.is_stop,a.transoport_level,b.tracks1_origin,a.inc_date from
//           |(select id,task_id,line_code,plate,is_push_line,mload,axle_number,weight,size,is_stop,transoport_level,inc_day as inc_date from dm_gis.gis_eta_save_money_finish where inc_day between '$startDate' and '$endDate' and is_push_line='1') a
//           |left join (select id,tracks1_origin from dm_gis.gis_eta_save_money_track where inc_day between '$startDate' and '$endDate') b on a.id=b.id
//       """.stripMargin
//    }
//    var logRdd = getValidJson(sparkSession, sql)
//    logRdd
//  }
//
//
//  def computeRectify(inputRdd: SinkUnbound[JSONObject]): SinkUnbound[JSONObject] ={
//    logger.error(">>>跑轨迹纠偏")
//    val fieldRdd = inputRdd
//      .map(json=>{
//        if(json!=null){
////          val stay_list = new JSONArray()
//          var tracks2_origin:JSONArray = null
//          var tracks2:JSONArray = new JSONArray()
////          val rec_dict = new JSONObject()
//          //轨迹纠偏
//          val tracks = new JSONArray()
//          var tracks1 = json.getJSONArray("tracks1_origin")
//          if(tracks1!=null && tracks1.size() > 0){
//            for(i<-0.until(tracks1.size())){
//              val json = tracks1.getJSONObject(i)
//              val newJson = new JSONObject()
//              if(json!=null){
//                val tp = json.getInteger("tp")
//                val zx = json.getDouble("zx")
//                val zy = json.getDouble("zy")
//                val ac = json.getInteger("ac")
//                val sp = json.getDouble("sp")
//                val be = json.getDouble("be")
//                val tm = json.getInteger("tm")
//
//                if(tp!=null) newJson.put("type",tp)
//                if(zx!=null) newJson.put("x",zx)
//                if(zy!=null) newJson.put("y",zy)
//                if(ac!=null) newJson.put("accuracy",ac)
//                if(sp!=null) newJson.put("speed",sp)
//                if(be!=null) newJson.put("azimuth",be)
//                if(tm!=null) newJson.put("time",tm)
//              }
//
//              newJson.put("index",i)
//              tracks.add(newJson)
//            }
//          }
//          json.remove("tracks1_origin")
//
//          val httpObject = accessRectifyUrl(json,tracks)
//          if(httpObject!=null){
//            val resultObject = httpObject.getJSONObject("result")
//            if(resultObject!=null){
//              tracks2_origin = resultObject.getJSONArray("tracks")
//              if(tracks2_origin!=null && tracks2_origin.size() > 0){
//                val __tracks2 = new JSONArray()
//                for(j<-0.until(tracks2_origin.size())){
//                  val track = tracks2_origin.getJSONObject(j)
//                  if(track!=null){
//                    val trackNew = new JSONObject()
//                    for(key<-need_keys){
//                      var value = track.getString(key)
//                      if(!StringUtils.isEmpty(value)) trackNew.put(key,value)
//                    }
//                    __tracks2.add(trackNew)
//
//                    val tmp = new JSONArray()
//                    val x = track.getDouble("x")
//                    val y = track.getDouble("y")
//                    if(x!=null && y!=null){
//                      tmp.add(x)
//                      tmp.add(y)
//                      tracks2.add(tmp)
//                    }
//                  }
//                }
//                tracks2_origin = __tracks2
//              }
//
//              val stay_points = resultObject.getJSONArray("stay_points")
//              if(stay_points!=null && stay_points.size()>0){
//                var duration:java.lang.Integer = 0
//                for(i<-0.until(stay_points.size())){
//                  val stay_point = stay_points.getJSONObject(i)
//                  if(stay_point!=null){
//                    val _duration = stay_point.getInteger("duration")
//                    if(_duration!=null) duration = duration + _duration
//                  }
//                }
//                json.put("duration",duration)
//              }
//
//              if(tracks2_origin!=null && tracks2_origin.size()>0){
//                val track0 = tracks2_origin.getJSONObject(0)
//                val trackn = tracks2_origin.getJSONObject(tracks2_origin.size() - 1)
//                if(track0!=null && trackn!=null){
//                  val time0 = track0.getLong("time")
//                  val timen = trackn.getLong("time")
//                  if(time0!=null && timen!=null){
//                    val time = timen - time0
//                    json.put("time",time)
//                  }
//                }
//              }
//
//              val len = resultObject.getString("len")
//              if(len!=null) json.put("len",len)
//              val highwaymileage = resultObject.getString("highwaymileage")
//              if(highwaymileage!=null) json.put("highwaymileage",highwaymileage)
//              val tollMileage = resultObject.getString("tollMileage")
//              if(tollMileage!=null) json.put("toll_mileage",tollMileage)
//              val overlap = resultObject.getString("overlap")
//              if(overlap!=null) json.put("overlap",overlap)
//              val tollCharge = resultObject.getString("tollCharge")
//              if(tollCharge!=null) json.put("toll_charge",tollCharge)
//              val etcTollCharge = resultObject.getString("etcTollCharge")
//              if(etcTollCharge!=null) json.put("etc_toll_charge",etcTollCharge)
//            }
//          }
//
//
////          if(stay_list!=null && stay_list.size()>0) json.put("stay_list", stay_list)
//          if(tracks2_origin!=null && tracks2_origin.size()>0) {
//            if("1".equalsIgnoreCase(json.getString("is_push_line"))) json.put("rec_dic", tracks2_origin)
//            json.put("track_status", 0)
//          }
//          else json.put("track_status", 1)
//          if(tracks2!=null && tracks2.size()>0) json.put("tracks2", tracks2)
//
//
//        }
//        json
//      })
//      .repartition(10).persist()
//    logger.error(">>>跑轨迹纠偏后的数据量："+fieldRdd.count())
//    inputRdd.unpersist()
//
//    fieldRdd
//  }
//
//
//  def accessRectifyUrl(json:JSONObject, tracks:JSONArray): JSONObject ={
//    var http_result:JSONObject = null
//    //    try {
//    var vehicle = 6
//    if (json.getInteger("vehicle")!=null) vehicle = json.getInteger("vehicle")
//    val param = new JSONObject()
//    param.put("ak", "e640de2b47394b19862ee134d817bbc7")
//    param.put("vehicle", vehicle)
//    param.put("retflag", 7)
//    param.put("addpoint", 1)
//    param.put("roadinfo", 1)
//    param.put("poiinfo", 1)
//    param.put("tracks", tracks)
//
//    val vehicleInfo = new JSONObject()
//    val mload = json.getString("mload")
//    if(!StringUtils.isEmpty(mload)) vehicleInfo.put("load",mload)
//    val axle_number = json.getString("axle_number")
//    if(!StringUtils.isEmpty(axle_number)) vehicleInfo.put("axis",axle_number)
//    val weight = json.getDouble("weight")
//    if(weight!=null) vehicleInfo.put("weight",weight)
//    val size = json.getDouble("size")
//    if(size!=null) vehicleInfo.put("length",size)
//
//    param.put("vehicleInfo", vehicleInfo)
//    param.put("mat_ratio", 1)
//
//    val process = new JSONObject()
//    process.put("stay_time",180)
//    process.put("poi_range",500)
//
//    param.put("process", process)
//
//    println("参数："+param.toString)
//    http_result = HttpClientUtil.getJsonByPostJson(rectify_url, param.toString)
//    //println("返回："+http_result.toString)
//    Thread.sleep(2000)
//    //      println("轨迹对比结果："+http_result)
//    //    } catch {
//    //      case e:Exception =>logger.error(">>>访问比较轨迹接口异常："+e+",json="+json)
//    //    }
//    http_result
//  }
//
//
//  def getValidJson(sparkSession: SparkSession, sql: String)={
//    logger.error("sql="+sql)
//    val df = sparkSession.sql(sql)
//    val fields = df.schema.fields
//    val header = new Array[String](fields.length)
//    for (i <- fields.indices) {
//      val name = fields(i).name
//      header(i) = name
//    }
//    val logRdd = df.na.fill("").rdd.repartition(6400).map(row=>{
//      val json = new JSONObject()
//      for(i<-fields.indices){
//        json.put(header(i),row.getString(i))
//      }
//      json
//    }).filter(_!=null).repartition(6400).persist()
//    logger.error(">>>日志量："+logRdd.count())
//    logRdd
//  }
//
//
//}
