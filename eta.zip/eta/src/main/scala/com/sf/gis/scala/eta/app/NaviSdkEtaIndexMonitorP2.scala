package com.sf.gis.scala.eta.app

import java.text.SimpleDateFormat
import java.util

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.{DateUtil, MD5Util}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.eta.util.SparkUtils
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{IntegerType, StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

object NaviSdkEtaIndexMonitorP2 {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  val funcMap = new util.HashMap[String, String]()

  val descMysqlUserName = "gis_oms_pns"
  val descMysqlPassWord = "gis_oms_pns"
  val descMysqlUrl = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?characterEncoding=utf-8"

  //任务量
  val taskAmountStatSourTable = "dm_gis.gis_navi_eta_result"
  val taskAmountStatDescTable = "ETA_INDEX_TASK_AMOUNT_STATISTICS"

  //服务指标-响应时间
  var serviceCostTimeRdd = null:RDD[((String, String), JSONObject)]
  val serviceResponseDescTable = "ETA_INDEX_SERVICE_RESPONSE_TIME_STATISTICS"

  //服务指标-性能统计
  val servicePerformanceDescTable = "ETA_INDEX_SERVICE_PERFORMANCE_TIME_STATISTICS"

  //复用率
  val reuseStatSourTable = "dm_gis.gis_navi_result_union"
  val reuseStatDestTable = "ETA_INDEX_REUSE_RATE_STATISTICS"

  //问卷调查正确率
  var questionnaireRdd = null:RDD[((String, String), JSONObject)]
  val questionnaireAccDestTable = "ETA_INDEX_QUESTIONNAIRE_ACC_RATE_STATISTICS"

  //问卷调查司机错误占比
  val questionnaireErrDestTable = "ETA_INDEX_QUESTIONNAIRE_ERR_RATE_STATISTICS"

  def init() = {
    val spark = Spark.getSparkSession(appName)

    funcMap.put("任务量", "processTaskAmountStatistics")
    funcMap.put("复用率", "processReuseRateStatistics")
    funcMap.put("问卷调查正确率", "processQuestionnaireAccRateStatistics")
    funcMap.put("问卷调查司机错误占比", "processQuestionnaireDriverErrPerStatistics")
    funcMap.put("服务指标-响应时间", "processServiceResponseStatistics")
    funcMap.put("服务指标-性能统计", "processServicePerformanceStatistics")

    spark
  }

  def main(args: Array[String]): Unit = {
    val spark = init()

    //val invokeFuncArr = Array("问卷调查司机错误占比")
    val invokeFuncArr = Array("任务量","复用率","问卷调查正确率","问卷调查司机错误占比")

    start(invokeFuncArr,spark,args)

    spark.close()
  }

  //任务量统计映射
  val taskSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("province", StringType, true),
    StructField("citycode", StringType, true),
    StructField("sitecode", StringType, true),
    StructField("req_status", StringType, true),
    StructField("task_amount", IntegerType, true),
    StructField("navi_amount", IntegerType, true),
    StructField("dist_0", IntegerType, true),
    StructField("dist_50", IntegerType, true),
    StructField("dist_200", IntegerType, true),
    StructField("dist_500", IntegerType, true),
    StructField("city_interior", IntegerType, true),
    StructField("province_interior", IntegerType, true),
    StructField("interprovincial", IntegerType, true)
  ))

  //复用率统计映射
  val reuseSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("province", StringType, true),
    StructField("citycode", StringType, true),
    StructField("sitecode", StringType, true),
    StructField("sdkversion", StringType, true),
    StructField("system", StringType, true),
    StructField("driver_amount", IntegerType, true),
    StructField("reuse_0", IntegerType, true),
    StructField("reuse_1", IntegerType, true),
    StructField("reuse_2", IntegerType, true),
    StructField("reuse_5", IntegerType, true),
    StructField("reuse_10", IntegerType, true),
    StructField("last_navitask_amount", IntegerType, true),
    StructField("driver_loss_amount", IntegerType, true),
    StructField("driver_keep_amount", IntegerType, true),
    StructField("last_no_navitask_amount", IntegerType, true),
    StructField("driver_add_amount", IntegerType, true)
  ))

  //问卷调查准确率映射
  val qAccSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("app_version", StringType, true),
    StructField("sysytem", StringType, true),
    StructField("questionnaire_amount", IntegerType, true),
    StructField("driver_amount", IntegerType, true),
    StructField("q1_amount", IntegerType, true),
    StructField("q1_acc_amount", IntegerType, true),
    StructField("q2_amount", IntegerType, true),
    StructField("q2_acc_amount", IntegerType, true),
    StructField("q3_amount", IntegerType, true),
    StructField("q3_acc_amount", IntegerType, true),
    StructField("q4_amount", IntegerType, true),
    StructField("q4_acc_amount", IntegerType, true),
    StructField("q5_amount", IntegerType, true),
    StructField("q5_acc_amount", IntegerType, true),
    StructField("q6_amount", IntegerType, true),
    StructField("q6_acc_amount", IntegerType, true),
    StructField("q7_amount", IntegerType, true),
    StructField("q7_acc_amount", IntegerType, true),
    StructField("q8_amount", IntegerType, true),
    StructField("q8_acc_amount", IntegerType, true),
    StructField("q9_amount", IntegerType, true),
    StructField("q9_acc_amount", IntegerType, true)
  ))

  //问卷调查错误占比映射
  val qErrSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("app_version", StringType, true),
    StructField("sysytem", StringType, true),
    StructField("questionnaire_amount", IntegerType, true),
    StructField("driver_amount", IntegerType, true),
    StructField("q1_err_amount", IntegerType, true),
    StructField("q1_max_driver_amount", IntegerType, true),
    StructField("q1_max_driverId", StringType, true),
    StructField("q2_err_amount", IntegerType, true),
    StructField("q2_max_driver_amount", IntegerType, true),
    StructField("q2_max_driverId", StringType, true),
    StructField("q3_err_amount", IntegerType, true),
    StructField("q3_max_driver_amount", IntegerType, true),
    StructField("q3_max_driverid", StringType, true),
    StructField("q3_max_err_type", StringType, true),
    StructField("q3_max_err_type_amount", IntegerType, true),
    StructField("q4_err_amount", IntegerType, true),
    StructField("q4_max_driver_amount", IntegerType, true),
    StructField("q4_max_driverId", StringType, true),
    StructField("q5_err_amount", IntegerType, true),
    StructField("q5_max_driver_amount", IntegerType, true),
    StructField("q5_max_driverId", StringType, true),
    StructField("q6_err_amount", IntegerType, true),
    StructField("q6_max_driver_amount", IntegerType, true),
    StructField("q6_max_driverId", StringType, true),
    StructField("q7_err_amount", IntegerType, true),
    StructField("q7_max_driver_amount", IntegerType, true),
    StructField("q7_max_driverId", StringType, true),
    StructField("q8_err_amount", IntegerType, true),
    StructField("q8_max_driver_amount", IntegerType, true),
    StructField("q8_max_driverid", StringType, true),
    StructField("q8_max_err_type", StringType, true),
    StructField("q8_max_err_type_amount", IntegerType, true),
    StructField("q9_err_amount", IntegerType, true),
    StructField("q9_max_driver_amount", IntegerType, true),
    StructField("q9_max_driverId", StringType, true)
  ))

  //服务指标-响应时间映射
  val respTimeSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("module", StringType, true),
    StructField("service", StringType, true),
    StructField("resp_0_200", IntegerType, true),
    StructField("resp_200_500", IntegerType, true),
    StructField("resp_500_1000", IntegerType, true),
    StructField("resp_1000_1500", IntegerType, true),
    StructField("resp_1500_2000", StringType, true),
    StructField("resp_2000_3000", IntegerType, true),
    StructField("res_3000", IntegerType, true)
  ))

  //服务指标-性能统计映射
  val performanceSchema = StructType(List(
    StructField("id", StringType, true),
    StructField("statdate", StringType, true),
    StructField("module", StringType, true),
    StructField("service", StringType, true),
    StructField("minute", StringType, true),
    StructField("req_peak", IntegerType, true),
    StructField("minu_req_amount", IntegerType, true),
    StructField("avg_cost_time", IntegerType, true),
    StructField("minu_avg_cost_time", IntegerType, true),
    StructField("per99_cost_time", StringType, true),
    StructField("minu_per99_cost_time", IntegerType, true)
  ))

  def processTaskAmountStatistics( spark:SparkSession,incDay:String,yesterday:String ): Unit ={
    logger.error("开始统计任务量")

    val querySql =
      s"""
         |select
         |  src_province,
         |  src_citycode,
         |  src_deptcode,
         |	dest_province,
         |	dest_citycode,
         |	dest_deptcode,
         |	navi_endStatus,
         |	distance,
         |	navi_id,
         |  task_id
         |from (
         |	select
         |      src_province,
         |      src_citycode,
         |      src_deptcode,
         |      dest_province,
         |      dest_citycode,
         |      dest_deptcode,
         |      navi_endStatus,
         |      distance,
         |      navi_id,
         |      task_id,
         |      row_number() over(partition by navi_id order by route_order asc,req_order asc) num
         |    from ${taskAmountStatSourTable}
         |    where inc_day = '$incDay' and navi_endStatus <> ''
         |) t
         |where num = 1
         |""".stripMargin

    logger.error(querySql)

    val sourRdd = spark.sql(querySql).rdd.repartition(100).map( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("src_province",obj.getString(0))
      jsonObj.put("src_citycode",obj.getString(1))
      jsonObj.put("src_deptcode",obj.getString(2))
      jsonObj.put("dest_province",obj.getString(3))
      jsonObj.put("dest_citycode",obj.getString(4))
      jsonObj.put("dest_deptcode",obj.getString(5))
      jsonObj.put("distance",obj.getString(7))
      jsonObj.put("navi_id",obj.getString(8))
      jsonObj.put("task_id",obj.getString(9))

      val status= obj.getString(6)
      val naviEndStatus = status match {
        case status if (status.toInt == 0) => 0
        case status if (status.toInt >= 1 && status.toInt <= 9) => 1
        case status if(status.toInt >= 10) => 2
      }

      ((obj.getString(3),obj.getString(4),obj.getString(5),naviEndStatus.toString),jsonObj)
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"获取导航任务数据共:${sourRdd.count()}")

    //进行指标统计
    val taskAmountDf = doTaskAmountStatistics(sourRdd,incDay)

    //存入hive
    SparkUtils.df2Hive(spark,taskAmountDf,taskSchema,"append","dm_gis."+taskAmountStatDescTable,"statdate",incDay,logger)

    //保存到mysql
    SparkUtils.df2Mysql(spark,taskAmountDf,taskSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,taskAmountStatDescTable,incDay,logger)

    taskAmountDf.unpersist()
  }

  def processReuseRateStatistics ( spark:SparkSession,incDay:String,yesterday:String ): Unit = {
    logger.error("开始统计复用率")

    //关联查询历史司机复用和当天复用情况
    val queryHisReuseSql =
      s"""
         |select
         |  	  nvl(t1.dest_province,t2.province) as province,
         |      nvl(t1.dest_citycode,t2.citycode) as citycode,
         |      nvl(t1.dest_deptcode,t2.sitecode) as sitecode,
         |      nvl(t1.sdk_version,t2.sdkversion) as sdkversion,
         |      nvl(t1.system,t2.system) as system,
         |      nvl(t1.driver_id,t2.driver_id) as driver_id,
         |      nvl(t1.use_amount,0) + nvl(t2.his_use_amount,0) as his_use_amount,
         |      '$incDay' as statdate
         |from (
         |    select
         |    	  dest_province,
         |        dest_citycode,
         |        dest_deptcode,
         |        sdk_version,
         |        system,
         |        driver_id,
         |        count(1) as use_amount
         |    from ${reuseStatSourTable}
         |    where inc_day='$incDay'
         |    group by dest_province,dest_citycode,dest_deptcode,sdk_version,system,driver_id
         |) t1
         |FULL JOIN
         |(
         |	SELECT
         |      province,
         |      citycode,
         |      sitecode,
         |      sdkversion,
         |      system,
         |      driver_id,
         |      his_use_amount
         |    from dm_gis.eta_index_reuse_his_i
         |    where statdate='$yesterday'
         |) t2
         |on t1.dest_province = t2.province
         |   and t1.dest_citycode = t2.citycode
         |   and t1.dest_deptcode = t2.sitecode
         |   and t1.sdk_version = t2.sdkversion
         |   and t1.system = t2.system
         |   and t1.driver_id = t2.driver_id
         |""".stripMargin

    logger.error(queryHisReuseSql)

    val hisReuseDf = spark.sql(queryHisReuseSql).repartition(100).persist(StorageLevel.DISK_ONLY)

    logger.error(s"获取历史复用数据共${hisReuseDf.count()}")

    logger.error("保存复用情况到hive历史复用情况中")
    SparkUtils.df2Hive( spark,hisReuseDf,"append","dm_gis.eta_index_reuse_his_i","statdate",incDay,logger )

    //统计司机复用情况
    val driverReuseRdd = doDriverReuseStatistics(hisReuseDf)

    //统计司机变更情况
    val driverChangeRdd = doDriverChangeStatistics(spark,incDay,yesterday)

    //关联司机复用和司机变更
    val driverReuseChangeDf = joinDriverReuseChange(driverChangeRdd,driverReuseRdd,incDay)

    //存入hive
    SparkUtils.df2Hive(spark,driverReuseChangeDf,reuseSchema,"append","dm_gis."+reuseStatDestTable,"statdate",incDay,logger)

    //存入mysql
    SparkUtils.df2Mysql(spark,driverReuseChangeDf,reuseSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,reuseStatDestTable,incDay,logger)

    driverReuseChangeDf.unpersist()
  }

  def processQuestionnaireAccRateStatistics( spark:SparkSession,incDay:String,yesterday:String ): Unit = {
    logger.error("开始统计问卷调查率")

    //获取问卷调查数据
    val questionnaireDataRdd = Option(questionnaireRdd).getOrElse( getQuestionnaireData(spark,incDay,yesterday) )

    //问卷调查正确率
    val questionnaireAccRateDf = doQuestionnaireAccRateStatistics(questionnaireDataRdd,incDay,yesterday)

    //存入hive
    SparkUtils.df2Hive(spark,questionnaireAccRateDf,qAccSchema,"append","dm_gis."+questionnaireAccDestTable,
      "statdate",incDay,logger)

    //存入mysql
    SparkUtils.df2Mysql(spark,questionnaireAccRateDf,qAccSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,questionnaireAccDestTable,incDay,logger)

    questionnaireAccRateDf.unpersist()
  }

  def processQuestionnaireDriverErrPerStatistics( spark:SparkSession,incDay:String,yesterday:String ): Unit = {
    logger.error("开始统计问卷调查司机错误占比")

    val questionnaireDataRdd = Option(questionnaireRdd).getOrElse( getQuestionnaireData(spark,incDay,yesterday) )

    //统计问卷调查司机错误占比
    val questionnaireErrRateDf = doQuestionnaireErrRateStatistics(questionnaireDataRdd,incDay,yesterday)

    //存入hive
    SparkUtils.df2Hive(spark,questionnaireErrRateDf,qErrSchema,"append","dm_gis."+questionnaireErrDestTable,
      "statdate",incDay,logger)

    //存入mysql
    SparkUtils.df2Mysql(spark,questionnaireErrRateDf,qErrSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,questionnaireErrDestTable,incDay,logger)

    questionnaireErrRateDf.unpersist()
  }

  def processServiceResponseStatistics( spark:SparkSession,incDay:String,yesterday:String ): Unit ={
    logger.error("开始统计服务指标-响应时间")
    val serviceCostTimeDataRdd = Option(serviceCostTimeRdd).getOrElse( getServiceCostTimeData(spark,incDay,yesterday))

    //统计服务指标-响应时间
    val serviceCostTimeDf = doServiceResponseStatistics(serviceCostTimeDataRdd,incDay)

    //存入hive
    SparkUtils.df2Hive(spark,serviceCostTimeDf,respTimeSchema,"append","dm_gis."+serviceResponseDescTable,
      "statdate",incDay,logger)

    //存入mysql
    SparkUtils.df2Mysql(spark,serviceCostTimeDf,respTimeSchema,descMysqlUserName,descMysqlPassWord,
      "append",descMysqlUrl,serviceResponseDescTable,incDay,logger)

    serviceCostTimeDf.unpersist()
  }

//  def processServicePerformanceStatistics( spark:SparkSession,incDay:String,yesterday:String ): Unit ={
//    logger.error("开始统计服务指标-性能统计")
//    val df = new SimpleDateFormat("yyyyMMdd HH:mm:ss")
//    val tm1 = df.parse(incDay + " 00:00:00").getTime
//
//    //获取请求时间戳所属的分钟
//    val serviceCostTimeDataRdd = Option(serviceCostTimeRdd).getOrElse( getServiceCostTimeData(spark,incDay,yesterday))
//      .filter(json => StringUtils.isNotBlank(json._2.getString("req_time")))
//      .map(obj => {
//        val (module,service) = obj._1
//        val minute = DateUtil.getCurrentMinDiff(tm1,obj._2.getLong("req_time"))
//        ((module,service,minute),obj._2)
//      })
//
//    //统计服务指标-性能统计
//    val serviceCostTimeDf = doServicePerformanceStatistics(serviceCostTimeDataRdd,incDay)
//
//    //存入hive
//    SparkUtils.df2Hive(spark,serviceCostTimeDf,performanceSchema,"append","dm_gis."+servicePerformanceDescTable,
//      "statdate",incDay,logger)
//
//    //存入mysql
//    SparkUtils.df2Mysql(spark,serviceCostTimeDf,performanceSchema,descMysqlUserName,descMysqlPassWord,
//      "append",descMysqlUrl,servicePerformanceDescTable,incDay,logger)
//  }

  def doTaskAmountStatistics( sourRdd: RDD[((String, String, String, String), JSONObject)],incDay:String )={
    val taskAmountDf = sourRdd.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp).map(
      obj => {
        val resList = obj._2
        val (src_province,src_citycode,src_deptcode,src_status) = obj._1
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(incDay,src_province,src_citycode,src_deptcode,src_status).mkString("_"))

        //任务量
        val taskAmount = resList.map(_.getString("task_id")).distinct.length
        //导航次数
        val naviAmount =  resList.length
        //导航距离分组统计
        val naviDistGroup = resList.filter(json => StringUtils.isNotBlank(json.getString("distance")))
          .map(json => {
          val distStr = json.getString("distance").replaceAll("(\\..*$)","")
          val dist = if(StringUtils.isNotBlank(distStr)) distStr.toLong / 1000 else 0

          val distGroup= dist match {
            case dist if dist >=0 && dist < 50 => "dist_0"
            case dist if dist >=50 && dist < 200 => "dist_50"
            case dist if dist >=200 && dist < 500 => "dist_200"
            case _ => "dist_500"
          }

          (distGroup,"")
        }).groupBy(_._1)

        //省际、省内、市内统计
        val areaGroup = resList.map(json => {
          val ag = json match {
            case json if StringUtils.isNotBlank(json.getString("src_citycode"))
              && json.getString("src_citycode").equals(json.getString("dest_citycode")) => "市内"
            case json if StringUtils.isNotBlank( json.getString("src_province"))
              && StringUtils.isNotBlank(json.getString("src_citycode"))
              && json.getString("src_province").equals(json.getString("dest_province")) => "省内"
            case json if StringUtils.isNotBlank( json.getString("src_province"))
              && StringUtils.isNotBlank(json.getString("src_citycode")) => "省际"
            case _ => "null"
          }

          (ag,"")
        }).groupBy(_._1)

        Row(id,incDay,src_province,src_citycode,src_deptcode,src_status,taskAmount,naviAmount,naviDistGroup.getOrElse("dist_0",List()).length,
          naviDistGroup.getOrElse("dist_50",List()).length,naviDistGroup.getOrElse("dist_200",List()).length,naviDistGroup.getOrElse("dist_500",List()).length
          ,areaGroup.getOrElse("市内",List()).length,areaGroup.getOrElse("省内",List()).length,areaGroup.getOrElse("省际",List()).length)
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共统计指标:${taskAmountDf.count()}")

    sourRdd.unpersist()
    taskAmountDf
  }

  def doDriverReuseStatistics( hisReuseDf:DataFrame ) ={
    val driverReuseRdd = hisReuseDf.rdd.map( obj => {
      val jsonObj = new JSONObject()
      jsonObj.put("driver_id",obj.getString(5))
      jsonObj.put("his_use_amount",obj.getLong(6))

      ((obj.getString(0),obj.getString(1),obj.getString(2),obj.getString(3),obj.getString(4)),jsonObj)
    }).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map( obj => {
        val resList = obj._2
        //司机总量
        val driverAmount = resList.map(_.getString("driver_id")).distinct.length
        //无复用司机占比
        val reuse_0 = resList.count(_.getLong("his_use_amount") == 1)
        //司机复用一次占比
        val reuse_1 = resList.count(_.getLong("his_use_amount") == 2)
        //司机复用2次占比
        val reuse_2 = resList.count(_.getLong("his_use_amount") == 3)
        //司机复用5次占比
        val reuse_5 = resList.count(json => json.getLong("his_use_amount") >= 6 && json.getLong("his_use_amount") < 11)
        //司机复用10次占比
        val reuse_10 = resList.count(json => json.getLong("his_use_amount") >= 11 )

        val jsonObj = new JSONObject()
        jsonObj.put("driver_amount",driverAmount)
        jsonObj.put("reuse_0",reuse_0)
        jsonObj.put("reuse_1",reuse_1)
        jsonObj.put("reuse_2",reuse_2)
        jsonObj.put("reuse_5",reuse_5)
        jsonObj.put("reuse_10",reuse_10)

        (obj._1,jsonObj)
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"获取司机复用数据共:${driverReuseRdd.count()}")

    hisReuseDf.unpersist()
    driverReuseRdd
  }

  def doDriverChangeStatistics( spark:SparkSession,incDay:String,yesterday:String)={
    logger.error("开始统计司机变更情况")

    val taskNaviSql =
      s"""
         |select
         |       t2.dest_province as dest_province,
         |       t2.dest_citycode as dest_citycode,
         |       t2.dest_deptcode as dest_deptcode,
         |       t2.sdk_version,
         |       t2.system,
         |       t1.main_driver_account,
         |       if(t2.driver_id is null,false,true) as isNavi
         |    from (
         |       select
         |        *
         |       from (
         |          select
         |            dest_province,
         |            dest_city_code,
         |            dest_zone_code,
         |            main_driver_account,
         |            row_number() over( partition by main_driver_account order by actual_depart_tm asc ) num
         |          from dm_grd.grd_new_task_detail
         |          where inc_day ='%s'
         |          and actual_depart_tm is not null and actual_depart_tm <> '' and actual_depart_tm <> 'null'
         |          and actual_arrive_tm is not null and actual_arrive_tm <> '' and actual_arrive_tm <> 'null'
         |          and main_driver_account is not null and main_driver_account <> '' and main_driver_account <> 'null'
         |          and driver_source = 0
         |       ) tmp where num = 1
         |    ) t1
         |    LEFT JOIN
         |    (
         |      select
         |        *
         |      from (
         |        SELECT
         |         dest_province,
         |         dest_citycode,
         |         dest_deptcode,
         |         sdk_version,
         |         system,
         |         driver_id,
         |         row_number() over( partition by driver_id order by navi_starttime asc ) num
         |        from ${reuseStatSourTable}
         |        where inc_day ='%s'
         |          and dest_province is not null and dest_province <> ''
         |          and dest_citycode is not null and dest_citycode <> ''
         |          and dest_deptcode is not null and dest_deptcode <> ''
         |          and sdk_version is not null and sdk_version <> ''
         |          and system is not null and system <> ''
         |      ) tmp where num = 1
         |    ) t2
         |    on t1.main_driver_account = t2.driver_id
         |""".stripMargin

    //查询司机前一天的任务和导航情况
    val lastTaskNaviSql = taskNaviSql.format(yesterday,yesterday)
    logger.error(lastTaskNaviSql)
    val lastTaskNaviDF = spark.sql(lastTaskNaviSql).repartition(100).persist(StorageLevel.DISK_ONLY)
    logger.error(s"共获取查询司机前一天的任务和导航数据:${lastTaskNaviDF.count()}")

    //查询司机当天的任务和导航情况
    val currentTaskNaviSql = taskNaviSql.format(incDay,incDay)
    logger.error(currentTaskNaviSql)
    val currentTaskNaviDF = spark.sql(currentTaskNaviSql).repartition(100).persist(StorageLevel.DISK_ONLY)
    logger.error(s"共获取查询司机当天的任务和导航数据:${currentTaskNaviDF.count()}")

    //统计司机流失率,司机新增率,司机存留率
    lastTaskNaviDF.registerTempTable("lastTaskNavi");
    currentTaskNaviDF.registerTempTable("currentTaskNavi");

    val driverChangeRdd = spark.sql("""
                                      |select
                                      |  nvl(t1.dest_province,"") dest_province_t1,
                                      |  nvl(t2.dest_province,"") dest_province_t2,
                                      |  nvl(t1.dest_citycode,"") dest_citycode_t1,
                                      |  nvl(t2.dest_citycode,"") dest_citycode_t2,
                                      |  nvl(t1.dest_deptcode,"") dest_deptcode_t1,
                                      |  nvl(t2.dest_deptcode,"") dest_deptcode_t2,
                                      |  nvl(t1.sdk_version,"") sdk_version_t1,
                                      |  nvl(t2.sdk_version,"") sdk_version_t2,
                                      |  nvl(t1.system,"") system_t1,
                                      |  nvl(t2.system,"") system_t2,
                                      |  t1.isNavi as isLastNavi,
                                      |  t2.isNavi as isCurrentNavi
                                      |from lastTaskNavi t1
                                      |join currentTaskNavi t2
                                      |on t1.main_driver_account = t2.main_driver_account
                                      |""".stripMargin )
      .rdd.map( obj =>{
      val jsonObj = new JSONObject()
      jsonObj.put("isLastNavi",obj.getBoolean(10))
      jsonObj.put("isCurrentNavi",obj.getBoolean(11))

      var key = ("","","","","")
      if( obj.getBoolean(10) )
        key = (obj.getString(0),obj.getString(2),obj.getString(4),obj.getString(6),obj.getString(8))
      else
        key =  (obj.getString(1),obj.getString(3),obj.getString(5),obj.getString(7),obj.getString(9))

      (key,jsonObj)
    })
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map( obj => {
        val resList = obj._2

        //司机流失率
        val lastNaviTaskList = resList.filter( _.getBoolean("isLastNavi") )
        val lastNaviTaskAmount = lastNaviTaskList.length
        val driverLossAmount = lastNaviTaskList.count( !_.getBoolean("isCurrentNavi") )
        //司机存留率
        val driverKeepAmount = lastNaviTaskList.count( _.getBoolean("isCurrentNavi") )
        //司机新增率
        val lastNoNaviTaskList =  resList.filter( ! _.getBoolean("isLastNavi") )
        val lastNoNaviTaskAmount = lastNoNaviTaskList.length
        val driverAddAmount = lastNoNaviTaskList.count( _.getBoolean("isCurrentNavi") )

        val jsonObj = new JSONObject()
        jsonObj.put("lastNaviTaskAmount",lastNaviTaskAmount)
        jsonObj.put("driverLossAmount",driverLossAmount)
        jsonObj.put("driverKeepAmount",driverKeepAmount)
        jsonObj.put("lastNoNaviTaskAmount",lastNoNaviTaskAmount)
        jsonObj.put("driverAddAmount",driverAddAmount)

        (obj._1,jsonObj)
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"统计司机变更指标共:${driverChangeRdd.count()}")

    lastTaskNaviDF.unpersist()
    currentTaskNaviDF.unpersist()

    driverChangeRdd
  }

  def joinDriverReuseChange( driverChangeRdd: RDD[((String, String, String, String, String), JSONObject)],
                             driverReuseRdd: RDD[((String, String, String, String, String), JSONObject)],incDay:String) ={
    val driverReuseChangeDf =
      driverReuseRdd./*leftOuterJoin*/fullOuterJoin(driverChangeRdd).map( obj => {
        /*val leftBody = obj._2._1
        val rightBody = obj._2._2*/
        var leftBody = new JSONObject()
        var rightBody = new JSONObject()
        val (dest_province,dest_citycode,dest_deptcode,sdk_version,system) = obj._1
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(incDay,dest_province,dest_citycode,dest_deptcode,sdk_version,system).mkString("_"))

        /*if ( rightBody.nonEmpty )
          leftBody.fluentPutAll(rightBody.get)*/

        if ( obj._2._1.nonEmpty && obj._2._2.nonEmpty)
          leftBody = obj._2._1.get.fluentPutAll(obj._2._2.get)
        else if(obj._2._1.isEmpty && obj._2._2.nonEmpty)
          leftBody = obj._2._2.get
        else
          leftBody = obj._2._1.get

        Row(id,incDay,dest_province,dest_citycode,dest_deptcode,sdk_version,system,leftBody.getInteger("driver_amount"),leftBody.getInteger("reuse_0"),
          leftBody.getInteger("reuse_1"),leftBody.getInteger("reuse_2"),leftBody.getInteger("reuse_5"),leftBody.getInteger("reuse_10"),
          leftBody.getInteger("lastNaviTaskAmount"),leftBody.getInteger("driverLossAmount"),leftBody.getInteger("driverKeepAmount"),
          leftBody.getInteger("lastNoNaviTaskAmount"),leftBody.getInteger("driverAddAmount"))
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共关联司机重用和变更情况共${driverReuseChangeDf.count()}")

    driverChangeRdd.unpersist()
    driverReuseRdd.unpersist()

    driverReuseChangeDf
  }

  def getQuestionnaireData( spark:SparkSession,incDay:String,yesterday:String ) = {
    logger.error("开始获取问卷调查数据")

    val querySql =
      s"""
         |select
         |	rel_id,question_seq,answer_txt,template_id,id,account,file_name,device_type,create_time,app_version
         |from (
         |	select
         |      a.rel_id,
         |      a.question_seq,
         |      a.answer_txt,
         |      a.template_id,
         |      b.id,
         |      b.account,
         |      b.file_name,
         |      nvl(b.device_type,'') device_type,
         |      b.create_time,
         |      nvl(b.app_version,'') app_version,
         |      b.inc_day,
         |      row_number() over( PARTITION by  a.rel_id,a.question_seq,b.file_name,b.account order by a.rel_id desc,a.question_seq desc) num
         |    from
         |      (
         |        select
         |          *
         |        from
         |          dm_gis.record_tt_cm_question_answer
         |        where
         |          inc_day >= '$incDay'
         |      ) a
         |      left JOIN (
         |        select
         |          *
         |        from
         |          dm_gis.record_tt_cm_question
         |        where
         |          inc_day >= '$incDay'
         |      ) b
         |    on a.rel_id = b.id
         |) tmp
         |where num = 1 and question_seq < 10
         |""".stripMargin

    logger.error(querySql)

     questionnaireRdd = spark.sql(querySql).repartition(100).rdd.map( obj =>{
      val jsonObj = new JSONObject()
      jsonObj.put("rel_id",obj.getString(0))
      jsonObj.put("question_seq",obj.getString(1))
      jsonObj.put("answer_txt",obj.getString(2))
      jsonObj.put("template_id",obj.getString(3))
      jsonObj.put("id",obj.getString(4))
      jsonObj.put("account",obj.getString(5))
      jsonObj.put("file_name",obj.getString(6))
      jsonObj.put("create_time",obj.getString(8))

      ((obj.getString(9),obj.getString(7)),jsonObj)
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"获取问卷调查数据共:${questionnaireRdd.count()}")

    questionnaireRdd
  }

  def doQuestionnaireAccRateStatistics( questionnaireDataRdd: RDD[((String, String), JSONObject)],incDay:String,yesterday:String ) ={
    val questionnaireAccRateDf = questionnaireDataRdd.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map( obj => {
        val (app_version,device_type) = obj._1
        val resList = obj._2
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(incDay,app_version,device_type).mkString("_"))

        val getAcc = (qSeq:String,qtype:String) => {
          val qList = resList.filter(json => qSeq.equals(json.getString("question_seq")))
          val qAmount = qList.length
          val qAccAmount = qList.count( json => qtype.equals(json.getString("answer_txt")) )

          (qAmount,qAccAmount)
        }

        //问卷数量
        val questionnaireAmount = resList.map(_.getString("rel_id")).distinct.length
        //司机数量
        val driverAmount = resList.map(_.getString("account")).distinct.length
        //问题1正确率
        val (q1Amount,q1AccAmount) = getAcc("1","B")
        //问题2正确率
        val (q2Amount,q2AccAmount) = getAcc("2","B")
        //问题3正确率
        val (q3Amount,q3AccAmount) = getAcc("3","A")
        //问题4正确率
        val q4List = resList.filter(json => "4".equals(json.getString("question_seq")))
        val q4Amount = q4List.count(json =>  ! "C".equals(json.getString("answer_txt")))
        val q4AccAmount = q4List.count(json => "A".equals(json.getString("answer_txt")))
        //问题5正确率
        val (q5Amount,q5AccAmount) = getAcc("5","A")
        //问题6正确率
        val (q6Amount,q6AccAmount) = getAcc("6","A")
        //问题7正确率
        val (q7Amount,q7AccAmount) = getAcc("7","A")
        //问题8正确率
        val (q8Amount,q8AccAmount) = getAcc("8","A")
        //问题9正确率
        val (q9Amount,q9AccAmount) = getAcc("9","A")

        Row(id,incDay,app_version,device_type,questionnaireAmount,driverAmount,q1Amount,q1AccAmount,q2Amount,q2AccAmount,q3Amount,q3AccAmount,
          q4Amount,q4AccAmount, q5Amount,q5AccAmount,q6Amount,q6AccAmount,q7Amount,q7AccAmount,q8Amount,q8AccAmount,q9Amount,q9AccAmount)
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"统计问卷调查准确率指标共:${questionnaireAccRateDf.count()}")

    questionnaireDataRdd.unpersist()
    questionnaireAccRateDf
  }

  def doQuestionnaireErrRateStatistics( questionnaireDataRdd: RDD[((String, String), JSONObject)],incDay:String,yesterday:String ) = {
    val questionnaireErrRateDf = questionnaireDataRdd.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map( obj => {
        val (app_version,device_type) = obj._1
        val resList = obj._2
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(incDay,app_version,device_type).mkString("_"))

        val gerErrDriver = ( qList: List[JSONObject]) => {
          val qErrAmount = qList.length
          val (maxDriverId,maxList) = if (qList.isEmpty) ("",List()) else qList.groupBy(_.getString("account")).maxBy(_._2.length)
          (qErrAmount,maxList.length,maxDriverId)
        }

        val getErr1 = (qSeq:String) => {
          val qList = resList.filter( json => qSeq.equals(json.getString("question_seq")) && "B".equals( json.getString("answer_txt")) )
          val  (qErrAmount,maxDriverAmount,maxDriverId) = gerErrDriver( qList )
          (qErrAmount,maxDriverAmount,maxDriverId)
        }

        val getErr3 = (qSeq:String) => {
          val qList = resList.filter( json => qSeq.equals(json.getString("question_seq")) && ! "A".equals(json.getString("answer_txt")) )
          val  (qErrAmount,maxDriverAmount,maxDriverId) = gerErrDriver( qList )
          val (maxErrType,maxErrTypeList) = if (qList.isEmpty) ("",List()) else qList.groupBy(_.getString("answer_txt")).maxBy(_._2.length)
          (qErrAmount,maxDriverAmount,maxDriverId,maxErrType,maxErrTypeList.length)
        }

        //问卷数量
        val questionnaireAmount = resList.map(_.getString("rel_id")).distinct.length
        //司机数量
        val driverAmount = resList.map(_.getString("account")).distinct.length
        //问题1错误量
        val (q1ErrAmount,q1MaxDriverAmount,q1MaxDriverId) = getErr1("1")
        //问题2错误量
        val (q2ErrAmount,q2MaxDriverAmount,q2MaxDriverId) = getErr1("2")
        //问题3错误量
        val (q3ErrAmount,maxQ3DriverAmount,maxQ3DriverId,maxQ3ErrType,maxQ3ErrTypeAmount) =getErr3("3")
        //问题4错误量
        val (q4ErrAmount,q4MaxDriverAmount,q4MaxDriverId) = getErr1("4")
        //问题5错误量
        val (q5ErrAmount,q5MaxDriverAmount,q5MaxDriverId) = getErr1("5")
        //问题6错误量
        val (q6ErrAmount,q6MaxDriverAmount,q6MaxDriverId) = getErr1("6")
        //问题7错误量
        val (q7ErrAmount,q7MaxDriverAmount,q7MaxDriverId) = getErr1("7")
        //问题8错误量
        val (q8ErrAmount,maxQ8DriverAmount,maxQ8DriverId,maxQ8ErrType,maxQ8ErrTypeAmount) =getErr3("8")
        //问题9错误量
        val (q9ErrAmount,q9MaxDriverAmount,q9MaxDriverId) = getErr1("9")

        Row(id,incDay,app_version,device_type,questionnaireAmount,driverAmount,q1ErrAmount,q1MaxDriverAmount,q1MaxDriverId,q2ErrAmount,q2MaxDriverAmount,q2MaxDriverId,
          q3ErrAmount,maxQ3DriverAmount,maxQ3DriverId,maxQ3ErrType,maxQ3ErrTypeAmount,q4ErrAmount,q4MaxDriverAmount,q4MaxDriverId,q5ErrAmount,q5MaxDriverAmount,q5MaxDriverId,
          q6ErrAmount,q6MaxDriverAmount,q6MaxDriverId,q7ErrAmount,q7MaxDriverAmount,q7MaxDriverId,q8ErrAmount,maxQ8DriverAmount,maxQ8DriverId,maxQ8ErrType,maxQ8ErrTypeAmount,
          q9ErrAmount,q9MaxDriverAmount,q9MaxDriverId)
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"统计问卷调查错误占比指标共:${questionnaireErrRateDf.count()}")

    questionnaireDataRdd.unpersist()
    questionnaireErrRateDf
  }

  def getServiceCostTimeData(spark:SparkSession,incDay:String,yesterday:String )={
    logger.error("开始查询服务响应时间")

    val querySql =
      s"""
         |--top3-eta
         |select
         |    "top3" as `module`,
         |    "top3-eta" as `service`,
         |    reqCostTime as `cost_time`,
         |    reqStartTime as `req_time`
         |from dm_gis.gis_navi_top3_parse
         |where inc_day='$incDay'
         |    and reqCostTime is not null and reqCostTime <> '' and reqCostTime <> 'null'
         |union all
         |--Top3-pns
         |select
         |    "top3" as `module`,
         |    "top3-pns" as `service`,
         |    pnsTop3ConstTime as `cost_time`,
         |    pnsTop3StartTime as `req_time`
         |from dm_gis.gis_navi_top3_parse
         |where inc_day='$incDay'
         |    and pnsTop3ConstTime is not null and pnsTop3ConstTime <> '' and pnsTop3ConstTime <> 'null'
         |union all
         |--noYaw-eta
         |select
         |    "noYaw" as `module`,
         |    "noYaw-eta" as `service`,
         |    reqCostTime as `cost_time`,
         |    reqStartTime as `req_time`
         |from dm_gis.gis_navi_no_yaw_parse
         |where inc_day='$incDay'
         |   and reqCostTime is not null and reqCostTime <> '' and reqCostTime <> 'null'
         |union all
         |--noYaw-pns
         |select
         |    "noYaw" as `module`,
         |    "noYaw-pns" as `service`,
         |    qmPointCostTime as `cost_time`,
         |    pnsTop3StartTime as `req_time`
         |from dm_gis.gis_navi_no_yaw_parse
         |where inc_day='$incDay'
         |    and qmPointCostTime is not null and qmPointCostTime <> '' and qmPointCostTime <> 'null'
         |union all
         |--Yaw-eta
         |select
         |    "Yaw" as `module`,
         |    "Yaw-eta" as `service`,
         |    reqCostTime as `cost_time`,
         |    reqStartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and reqCostTime is not null and reqCostTime <> '' and reqCostTime <> 'null'
         |union all
         |--Yaw-eta-sf
         |select
         |    "Yaw" as `module`,
         |    "Yaw-eta-sf" as `service`,
         |    reqCostTime as `cost_time`,
         |    reqStartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and reqCostTime is not null and reqCostTime <> '' and reqCostTime <> 'null'
         |    and sfPnsTop3ConstTime is not null and sfPnsTop3ConstTime <> '' and sfPnsTop3ConstTime <> 'null'
         |    and (jyPnsTop3ConstTime is null or jyPnsTop3ConstTime = '' or jyPnsTop3ConstTime = 'null')
         |union all
         |--Yaw-eta-jy
         |select
         |    "Yaw" as `module`,
         |    "Yaw-eta-jy" as `service`,
         |    reqCostTime as `cost_time`,
         |    reqStartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and reqCostTime is not null and reqCostTime <> '' and reqCostTime <> 'null'
         |    and jyPnsTop3ConstTime is not null and jyPnsTop3ConstTime <> '' and jyPnsTop3ConstTime <> 'null'
         |    and (sfPnsTop3ConstTime is null or sfPnsTop3ConstTime = '' or sfPnsTop3ConstTime = 'null')
         |union all
         |--Yaw-eta-jy-sf
         |select
         |    "Yaw" as `module`,
         |    "Yaw-eta-jy-sf" as `service`,
         |    reqCostTime as `cost_time`,
         |    reqStartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and reqCostTime is not null and reqCostTime <> '' and reqCostTime <> 'null'
         |    and sfPnsTop3ConstTime is not null and sfPnsTop3ConstTime <> '' and sfPnsTop3ConstTime <> 'null'
         |    and jyPnsTop3ConstTime is not null and jyPnsTop3ConstTime <> '' and jyPnsTop3ConstTime <> 'null'
         |union all
         |--Yaw-pns-1
         |select
         |    "Yaw" as `module`,
         |    "Yaw-pns" as `service`,
         |    sfPnsTop3ConstTime as `cost_time`,
         |    sfPnsTop3StartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and sfPnsTop3ConstTime is not null and sfPnsTop3ConstTime <> '' and sfPnsTop3ConstTime <> 'null'
         |-- Yaw-pns-2
         |select
         |    "Yaw" as `module`,
         |    "Yaw-pns" as `service`,
         |    jyPnsTop3ConstTime as `cost_time`,
         |    jyPnsTop3StartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and jyPnsTop3ConstTime is not null and jyPnsTop3ConstTime <> '' and jyPnsTop3ConstTime <> 'null'
         |union all
         |--Yaw-pns-sf
         |select
         |    "Yaw" as `module`,
         |    "Yaw-pns-sf" as `service`,
         |    sfPnsTop3ConstTime as `cost_time`,
         |    sfPnsTop3StartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and sfPnsTop3ConstTime is not null and sfPnsTop3ConstTime <> '' and sfPnsTop3ConstTime <> 'null'
         |union all
         |--Yaw-pns-jy
         |select
         |    "Yaw" as `module`,
         |    "Yaw-pns-jy" as `service`,
         |    jyPnsTop3ConstTime as `cost_time`,
         |    jyPnsTop3StartTime as `req_time`
         |from dm_gis.gis_navi_yaw_parse
         |where inc_day='$incDay'
         |    and jyPnsTop3ConstTime is not null and jyPnsTop3ConstTime <> '' and jyPnsTop3ConstTime <> 'null'
         |""".stripMargin

    logger.error(querySql)

    serviceCostTimeRdd = spark.sql(querySql).repartition(100).rdd.map( obj =>{
      val jsonObj = new JSONObject()
      jsonObj.put("module",obj.getString(0))
      jsonObj.put("service",obj.getString(1))
      jsonObj.put("cost_time",obj.getString(2))

      ((obj.getString(0),obj.getString(1)),jsonObj)
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"获取问卷调查数据共:${serviceCostTimeRdd.count()}")

    serviceCostTimeRdd
  }

  def doServiceResponseStatistics( serviceCostTimeRdd: RDD[((String, String), JSONObject)],incDay:String) ={
    logger.error("开始执行统计服务指标-响应时间")

    val serviceCostTimeDf = serviceCostTimeRdd.aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map( obj => {
        val (module,service) = obj._1
        val resList = obj._2
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(incDay,module,service).mkString("_"))

        val segMap = resList.map(json => {
          json match {
            case json if (json.getLong("cost_time") < 200) => json.put("seg_time","resp_0_200")
            case json if (json.getLong("cost_time") >= 200 && json.getLong("cost_time") < 500) => json.put("seg_time","resp_200_500")
            case json if (json.getLong("cost_time") >= 500 && json.getLong("cost_time") < 1000) => json.put("seg_time","resp_500_1000")
            case json if (json.getLong("cost_time") >= 1000 && json.getLong("cost_time") < 1500) => json.put("seg_time","resp_1000_1500")
            case json if (json.getLong("cost_time") >= 1500 && json.getLong("cost_time") < 2000) => json.put("seg_time","resp_1500_2000")
            case json if (json.getLong("cost_time") >= 2000 && json.getLong("cost_time") < 3000) => json.put("seg_time","resp_2000_3000")
            case json if (json.getLong("cost_time") >= 3000) => json.put("seg_time","res_3000")
          }

          json
        }).groupBy(_.getString("seg_time"))

        Row(id,incDay,module,service,segMap.getOrElse("resp_0_200",List()).length,segMap.getOrElse("resp_200_500",List()).length,
          segMap.getOrElse("resp_500_1000",List()).length,segMap.getOrElse("resp_1000_1500",List()).length,
          segMap.getOrElse("resp_1500_2000",List()).length, segMap.getOrElse("resp_2000_3000",List()).length,
          segMap.getOrElse("res_3000",List()).length
        )
      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"统计服务指标-响应时间共:${serviceCostTimeDf.count}")

    serviceCostTimeDf
  }

  def doServicePerformanceStatistics( serviceCostTimeDataRdd:RDD[((String, String, Long),JSONObject)],incDay:String):RDD[Row] = {
    logger.error("开始执行统计服务性能-指标统计")

    val serviceCostTimeDf = serviceCostTimeDataRdd
      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .map(
        obj => {
          val (module,service,minute) = obj._1
          val resList = obj._2
          //每分钟访问量
          val minuReqAmount = resList.length
          //每分钟平均响应时间
          val minAvgCostTime = resList.map(_.getInteger("cost_time").toInt).sum / minuReqAmount
          //每分钟99%响应时间
          resList.sortBy(_.getLong("cost_time"))
          val minPer99CostTime = resList (Math.round((resList.length - 1 ) * 0.99).toInt)

          val jsonObj= new JSONObject()

          jsonObj.put("minute",minute)
          jsonObj.put("minuReqAmount",minuReqAmount)
          jsonObj.put("minAvgCostTime",minAvgCostTime)
          jsonObj.put("minPer99CostTime",minPer99CostTime)

          ((module,service),jsonObj)
        }
    ).aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
      .flatMap(obj => {
        val (module,service) = obj._1
        val resList = obj._2
        val md5Instance = MD5Util.getMD5Instance
        val id = MD5Util.getMD5(md5Instance, Array(incDay,module,service).mkString("_"))

        //请求峰值
        val reqPeak = resList.maxBy(_.getInteger("minuReqAmount")).getInteger("minuReqAmount")
        //平均响应时间
        val avgCostTime = resList.map(_.getInteger("cost_time").toInt).sum / resList.length
        //99%响应时间
        resList.sortBy(_.getLong("cost_time"))
        val per99CostTime = resList (Math.round((resList.length - 1 ) * 0.99).toInt)

        for ( jsonObj <- resList ) yield {
          Row(id,incDay,module,service,jsonObj.getString("minute"),reqPeak
            ,jsonObj.getInteger("minuReqAmount"),avgCostTime
            ,jsonObj.getInteger("minAvgCostTime"),per99CostTime
            ,jsonObj.getInteger("minPer99CostTime")
          )
        }

      }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"统计服务指标-响应时间共:${serviceCostTimeDf.count}")

    serviceCostTimeDf
  }

  def start(invokeFuncArr: Array[String], spark: SparkSession,args: Array[String] ): Unit = {

    val totalDays = 1
    //val totalDays = 10
    for (i <- 1 to totalDays) {

      val logDays: Int = -i
      //val incDay: String = com.sf.gis.utils.Util.dateDelta(logDays, "")
      var incDay = "20200909"
      var yesterday = "20200908"

      if (args.length ==2 ){
        incDay = args(0)
        yesterday = args(1)
      }

      println(incDay,yesterday)

      //反射调用任意统计方法
      invokeFuncArr.foreach(
        index => {
          val funcName = funcMap.get(index)
          logger.error("\n\n\n" + s">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${funcName}开始<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<")
          this.getClass.getDeclaredMethod(funcName, classOf[SparkSession], classOf[String], classOf[String]).invoke(this, spark, incDay, yesterday)
          logger.error(s">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>${funcName}结束<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<" + "\n\n\n")
        }
      )
    }

    logger.error(">>>统计结束!<<<")
  }
}
