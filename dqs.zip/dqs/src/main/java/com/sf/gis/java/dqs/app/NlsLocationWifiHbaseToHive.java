package com.sf.gis.java.dqs.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class NlsLocationWifiHbaseToHive {
    public static Logger logger = LoggerFactory.getLogger(NlsLocationWifiHbaseToHive.class);

    public static void main(String[] args) {
        new NlsLocationWifiHbaseToHiveController().process("fwhive2hbase.properties");
        logger.error("process end");
    }
}
