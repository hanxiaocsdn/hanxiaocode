package com.sf.gis.java.dqs.constant;

/**
 * 常量类：通过config文件初始化
 * @author 01370539 Created On: May.07 2021
 */
public class ConfConstant {
}
