package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{HttpConnection, HttpInvokeUtil}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import com.alibaba.fastjson.JSONArray


/**
 * Created by 01417629 on 2021/11/04.
 * 代码弃用
 */
//noinspection DuplicatedCode
object FullTimeVoteXiaoGeTimeAnalyze {
  @transient lazy val logger: Logger = Logger.getLogger(FullTimeVoteXiaoGeTimeAnalyze.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val url = "http://sds-core-datarun.sf-express.com/datarun/track/getTrackAois?showAoiCode=1"

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println("############################"+parDay_1)
    //取数
    val empCodeInfo = getEmpCodeInfo(spark,parDay_1)
    empCodeInfo.take(2).foreach(println(_))
    //轨迹去跑接口，去计算轨迹落入的AOI区域
    val aoiArea = getAOIArea(empCodeInfo)
    aoiArea.take(2).foreach(println(_))
    //
    saveResult(spark,aoiArea,parDay_1)
    aoiArea.unpersist()
  }

  def getAOIArea(empCodeInfo: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val empAreaCode = empCodeInfo.map(obj => {
      val lng = JSONUtil.getJsonVal(obj,"zx","")
      val lat = JSONUtil.getJsonVal(obj,"zy","")
      val arr = new JSONArray()
      val jsonobject = new JSONObject()
      jsonobject.put("lng",lng)
      jsonobject.put("lat",lat)
      arr.add(jsonobject)
      val json = postEmpAreaCode(url,arr.toJSONString)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取小哥的aoi区域编码 ${empAreaCode.count()} 条s<<<")
    empCodeInfo.unpersist()
    empAreaCode
  }







  def postEmpAreaCode(url: String,params: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!params.isEmpty) {
        val httpData = HttpConnection.sendPost(url,params)
        if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {
          val content = httpData.get("content").toString
          val xyObj = JSON.parseObject(content)
          ret.put("xyObj",xyObj)
          if (xyObj != null) {
            val data = xyObj.getJSONArray("data")
            if(data != null && data.size() != 0){
              val jsonObject = data.getJSONObject(0)
              val aoiCode = JSONUtil.getJsonVal(jsonObject,"aoiCode","")
              ret.put("aoiCode",aoiCode)
            }else{
              ret.put("data",null)
            }
          }else{
            ret.put("xyObj",null)
          }
        }else{
          ret.put("code",httpData.get("code"))
        }
      }else{
        ret.put("params",null)
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }





  /**
   * 取数
   * @param spark
   * @return
   */
  def getEmpCodeInfo(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	t1.emp_code as emp_code
         |	,t1.dept_code as dept_code
         |	,t2.longitude as longitude
         |	,t2.latitude as latitude
         |	,t3.zx as zx
         |	,t3.zy as zy
         |	,t3.tm as tm
         |	,t4.start_time as start_time
         |	,t4.end_time as end_time
         |	,t4.aoi_area_id as aoi_area_id
         |from
         |(select emp_code,dept_code from default.emp_code_dept_code) as t1
         |
         |left join
         |
         |(select dept_code,longitude,latitude from default.dept_xy) as t2
         |
         |on t1.dept_code = t2.dept_code
         |
         |left join
         |
         |(
         |SELECT un,zx,zy,tm FROM dm_gis.esg_gis_loc_trajectory where inc_day = '20220516' and ak = '1'
         |) as t3
         |
         |on t1.emp_code = t3.un
         |
         |left join
         |
         |(
         |SELECT loginid,start_time,end_time,aoi_area_id FROM dm_tc_waybillinfo.schedule_width_data
         |where inc_day = '20220516' and batch_code like '%01D%'
         |) as t4
         |
         |on t1.emp_code = t4.loginid
         |where t3.tm >= t4.start_time and t3.tm <= t4.end_time
         |order by t1.emp_code,t3.tm
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val empCodeInfo = Util.getRowToJson(spark,sql,100)
    logger.error(s">>>取数 ${empCodeInfo.count()} 条s<<<")
    empCodeInfo
  }



  /**
   *
   * @param
   * @param
   */
  def saveResult(spark : SparkSession,aoiArea : RDD[(JSONObject,JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "default"
    val descTableName = "emp_code_area_code_info"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |  *
         |from emp_code_area_code_info_tmp
         |""".stripMargin

    try{
      val schemaString = "emp_code,dept_code,longitude,latitude,zx,zy" +
        ",tm,start_time,end_time,aoi_area_id,aoi_area_id_interf"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
      val schema = StructType(fields)
      val rdd = aoiArea.map(obj => {
        val row = obj._1
        val json = obj._2
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(row,"emp_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dept_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"longitude","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"latitude","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"zx","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"zy","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"tm","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"start_time","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"end_time","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"aoi_area_id","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"aoi_area_id_interf","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6),attr(7)
        ,attr(8),attr(9),attr(10)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("emp_code_area_code_info_tmp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
