package com.sf.gis.scala.dqs.app

import java.util.Properties

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.ConfigUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.HBaseConfiguration
import org.apache.hadoop.hbase.mapreduce.TableInputFormat
import org.apache.hadoop.hbase.util.Bytes
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * Created by 01417629 on 2021/11/04.
 * 任务id: 429176
 */
//noinspection DuplicatedCode
object NlsLocationWifiHbaseToHiveAll {
  @transient lazy val logger: Logger = Logger.getLogger(NlsLocationWifiHbaseToHiveAll.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val zkUrl = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
  //val hbase_table = "nls_location_wifi"
  //val hive_table = "dm_gis.gis_export_wifi_test"
  val fileName = "nlswifihbase2hive.properties"
  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    // 加载配置信息
    val confInfo = ConfigUtil.loadPropertiesConfiguration(fileName)
    logger.error("confInfo:"+confInfo.toString())
    val tableName = confInfo.getProperty("hbase.gis.wifi.table")
    val hbaseConf = getHbaseConf(confInfo)
    hbaseConf.set(TableInputFormat.INPUT_TABLE,tableName)
    // HBase数据转成RDD
    val hBaseRDD = spark.sparkContext.newAPIHadoopRDD(hbaseConf,classOf[TableInputFormat],
      classOf[org.apache.hadoop.hbase.io.ImmutableBytesWritable],
      classOf[org.apache.hadoop.hbase.client.Result]).repartition(1200).persist(StorageLevel.DISK_ONLY)

    // RDD数据操作
    val data = hBaseRDD.map(x => {
      val result = x._2
      val key = Bytes.toString(result.getRow)
      //(key,value)
      (key,result)
    }).map(obj => {
      val json = new JSONObject()
      val key = obj._1
      val result = obj._2
      val date = Bytes.toString(result.getValue("d".getBytes,"date".getBytes))
      val adcode = Bytes.toString(result.getValue("d".getBytes,"adcode".getBytes))
      val lng = Bytes.toString(result.getValue("d".getBytes,"lng".getBytes))
      val validity = Bytes.toString(result.getValue("d".getBytes,"validity".getBytes))
      val src = Bytes.toString(result.getValue("d".getBytes,"src".getBytes))
      val changefreq = Bytes.toString(result.getValue("d".getBytes,"changefreq".getBytes))
      val lat = Bytes.toString(result.getValue("d".getBytes,"lat".getBytes))
      val acc = Bytes.toString(result.getValue("d".getBytes,"acc".getBytes))
      val freq = Bytes.toString(result.getValue("d".getBytes,"freq".getBytes))
      val available = Bytes.toString(result.getValue("d".getBytes,"available".getBytes))
      val incday = Bytes.toString(result.getValue("d".getBytes,"incday".getBytes))
      json.put("date",date)
      json.put("adcode",adcode)
      json.put("lng",lng)
      json.put("validity",validity)
      json.put("src",src)
      json.put("changefreq",changefreq)
      json.put("lat",lat)
      json.put("acc",acc)
      json.put("freq",freq)
      json.put("available",available)
      json.put("incday",incday)
      (key,json)
    }).persist(StorageLevel.DISK_ONLY)
    data.take(2).foreach(println)
    //logger.error("**************************data:"+data.count())
    hBaseRDD.unpersist()
    saveResult(spark,data)
    data.unpersist()
    spark.close()
  }

  /**
   * 获取hbase配置
   *
   * @return
   */
  def getHbaseConf(properties: Properties): Configuration = {
    var hbaseConf: Configuration = null
    try {
      //获取hbase的conf
      hbaseConf = HBaseConfiguration.create()
      //设置写入的表
      hbaseConf.set("zookeeper.znode.parent", properties.getProperty("zookeeper.znode.parent"))
      hbaseConf.set("hbase.zookeeper.quorum", properties.getProperty("hbase.zookeeper.quorum"))
      hbaseConf.set("hbase.zookeeper.property.clientPort", properties.getProperty("hbase.zookeeper.property.clientPort"))
    } catch {
      case e: Exception => logger.error(">>>连接hbase失败:," + e)
    }
    hbaseConf
  }

  /**
   *
   * @param spark
   * @param
   */
  def saveResult(spark : SparkSession,result : RDD[(String,JSONObject)]): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "gis_export_wifi"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName
         |select
         |	 *
         |from gis_export_wifi_tmp
         |""".stripMargin

    val schemaString = "row_key,date,adcode,lng,validity,src,changefreq,lat,acc,freq,available,incday"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
    )
    val schema = StructType(fields)
    val rdd = result.map(obj => {
      val key = obj._1
      val row = obj._2
      val sb = new StringBuilder()
      sb.append(key).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"date","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"adcode","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"lng","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"validity","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"src","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"changefreq","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"lat","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"acc","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"freq","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"available","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"incday","null")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5)
      ,attr(6),attr(7),attr(8),attr(9),attr(10),attr(11)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("gis_export_wifi_tmp")
    //删除已有分区数据，然后插入最新数据
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }
}
