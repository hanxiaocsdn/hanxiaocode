package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.text.DecimalFormat
import java.util
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.java.dqs.utils.JavaUtil
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil, StringUtils}
import com.sf.gis.scala.dqs.util.{EDEUtil, EncryptAesUtil, HttpClientUtils, HttpConnection, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{ArrayType, StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel



/**
 * Created by 01417629 on 2021/11/04.
 * 代码弃用
 */
//noinspection DuplicatedCode
object FtFirmDataObtain {
  @transient lazy val logger: Logger = Logger.getLogger(FtFirmDataObtain.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val mapa_url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?address=%s&ak=84acfaddae824b54a4ef73ddbf48219c&opt=ma1"

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    val province = args(1)
    run(spark,parDay_1,province)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String,province : String): Unit ={
    println("############################"+parDay_1)
    println("****************************"+province)
    //获取省对应的拼音，作为结果表的分区
    val provincPinYin = getProvincePinYin(province)
    println("****************************"+provincPinYin)
    //按照省名称从fty_company_wide_incre_update（丰拓企业增量表）获取丰拓企业信息
    val ftFirmData = getFtFirmData(spark,province)
    ftFirmData.take(2).foreach(println(_))
    //分别使用注册地址reg_addr和经营地址source_addrs_encode调用GEO，获取坐标和省市区
    val ftFirmDataXy = getFtFirmDataXy(ftFirmData)
    //写入Hive表
    saveResult(spark,ftFirmDataXy,parDay_1,provincPinYin)
    ftFirmDataXy.unpersist()
    /*val javaUtil = new JavaUtil()
    val list = javaUtil.forDate("20220902","20221106")
    val iter = list.iterator()
    while (iter.hasNext){
      val it = iter.next()
      println(it)
      saveResultNew(spark,it)
    }*/
  }

  /**
   *
   * @param
   * @param
   */
  def saveResultNew(spark : SparkSession,day01 : String): Unit ={
    val dr = "$"
    val sql_1 =
      s"""
         |drop table if exists dm_gis.sa_aoi_rec_index_tmp_20220512
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>sql_1: "+sql_1)
    spark.sql(sql_1)

    val sql_2 =
      s"""
         |create table dm_gis.sa_aoi_rec_index_tmp_20220512
         |as SELECT
         |	 t1.city_code as city_code
         |	,t2.city as city_name_zh
         |	,t3.area as area_name
         |	,t3.region as region
         |	,t1.s_rec as s_rec
         |	,t1.s_all as s_all
         |	,t1.p_rec as p_rec
         |	,t1.p_all as p_all
         |FROM
         |(
         |	SELECT
         |		 case when sj_rec_city is not null and sj_rec_city <> '' then sj_rec_city else pj_rec_city end as city_code
         |		,s_rec
         |		,s_all
         |		,p_rec
         |		,p_all
         |	FROM dm_gis.sa_aoi_rec_index where inc_day = '$day01'
         |) as t1
         |
         |left join
         |--关联城市名称
         |(
         |	select dist_code as citycode,dist_name as city from dim.dim_city_info_df where inc_day = '$day01' and dist_code regexp '^\\\\d{3,4}$dr'
         |) as t2
         |
         |on t1.city_code = t2.citycode
         |
         |left join
         |--关联地区、大区
         |(
         |	SELECT area_name_1 as area,region_name_1 as region,city_code_1 as citycode FROM dm_gis.city_area_code_20220425 group by area_name_1,region_name_1,city_code_1
         |) as t3
         |
         |on t2.citycode = t3.citycode
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>sql_2: "+sql_2)
    spark.sql(sql_2)
    logger.error(">>>>>>>>>>入hive库结束1")

    val sql_3 =
      s"""
         |insert overwrite table dm_gis.sa_aoi_rec_index_res partition (inc_day = '$day01')
         |select
         |	'CITY'
         |	,city_name_zh as city
         |	,'$day01'
         |	,city_name_zh
         |	,city_code
         |	,area_name
         |	,region
         |	,sum(s_rec)
         |	,sum(s_all)
         |	,sum(p_rec)
         |	,sum(p_all)
         |from dm_gis.sa_aoi_rec_index_tmp_20220512
         |group by
         |	city_name_zh
         |	,city_code
         |	,region
         |	,area_name
         |
         |union all
         |
         |select
         |	'REGION'
         |	,region as region_name
         |	,'$day01'
         |	,'ALL'
         |	,'ALL'
         |	,area_name
         |	,region
         |	,sum(s_rec)
         |	,sum(s_all)
         |	,sum(p_rec)
         |	,sum(p_all)
         |from dm_gis.sa_aoi_rec_index_tmp_20220512
         |group by
         |	region
         |	,area_name
         |
         |union all
         |
         |select
         |	'AREA'
         |	,area_name as area
         |	,'$day01'
         |	,'ALL'
         |	,'ALL'
         |	,area_name
         |	,'ALL'
         |	,sum(s_rec)
         |	,sum(s_all)
         |	,sum(p_rec)
         |	,sum(p_all)
         |from dm_gis.sa_aoi_rec_index_tmp_20220512
         |group by
         |	 area_name
         |
         |union all
         |
         |select
         |	 'ALL'
         |	,'ALL'
         |	,'$day01'
         |	,'ALL'
         |	,'ALL'
         |	,'ALL'
         |	,'ALL'
         |	,sum(s_rec)
         |	,sum(s_all)
         |	,sum(p_rec)
         |	,sum(p_all)
         |from dm_gis.sa_aoi_rec_index_tmp_20220512
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>sql_3: "+sql_3)
    spark.sql(sql_3)
    logger.error(">>>>>>>>>>入hive库结束2")
  }

  /**
   *
   * @param province
   * @return
   */
  def getProvincePinYin(province: String): String ={
    val json = new JSONObject()
    json.put("新疆维吾尔自治区","xinjiang")
    json.put("北京市","beijing")
    json.put("重庆市","chongqin")
    json.put("辽宁省","liaoning")
    json.put("福建省","fujian")
    json.put("海南省","hainan")
    json.put("山西省","shanxi")
    json.put("湖北省","hubei")
    json.put("浙江省","zhejiang")
    json.put("吉林省","jilin")
    json.put("台湾省","taiwan")
    json.put("贵州省","guizhou")
    json.put("河南省","henan")
    json.put("甘肃省","gansu")
    json.put("黑龙江省","heilongjiang")
    json.put("四川省","sichuan")
    json.put("安徽省","anhui")
    json.put("西藏自治区","xizang")
    json.put("内蒙古自治区","neimenggu")
    json.put("陕西省","shanxisheng")
    json.put("山东省","shandong")
    json.put("河北省","hebei")
    json.put("香港特别行政区","xianggang")
    json.put("广西壮族自治区","guangxi")
    json.put("江西省","jiangxi")
    json.put("江苏省","jiangsu")
    json.put("天津市","tianjin")
    json.put("澳门特别行政区","aomen")
    json.put("云南省","yunnan")
    json.put("青海省","qinghai")
    json.put("湖南省","hunan")
    json.put("宁夏回族自治区","ningxia")
    json.put("上海市","shanghai")
    json.put("广东省","guangdong")
    val provincPinYin = JSONUtil.getJsonVal(json,province,"")
    provincPinYin
  }

  /**
   * 获取丰拓企业信息
   * @param spark
   * @return
   */
  def getFtFirmData(spark: SparkSession,province : String): RDD[JSONObject] ={
    val sql =
      s"""
         |SELECT
         |	 fec_id
         |	,ty_id
         |	,company_name
         |	,reg_status
         |	,reg_capital
         |	,indu_one
         |	,indu_two
         |	,indu_three
         |	,estiblish_time
         |	,reg_addr
         |	,source_addrs
         |	,province
         |	,cityname
         |	,district
         |	,company_org_type
         |	,legal_person_name
         |	,city_code
         |	,quality_type
         |	,source_addrs_encode
         |FROM
         |(
         |    SELECT
         |		*
         |		,row_number() over(partition by ty_id order by submitted_time desc) as rn
         |    FROM dm_fec.fty_company_wide_incre_update
         |	where deleted <> '1'
         |	and quality_type <> 'L'
         |	AND company_org_type <> '其他'
         |	AND ((reg_addr <> '' AND reg_addr <> 'null' AND reg_addr is not null) or (source_addrs_encode <> '' AND source_addrs_encode <> 'null' AND source_addrs_encode is not null))
         |	AND (reg_status <> '注销' AND reg_status <> '吊销' AND reg_status <> '其他')
         |	AND province = '$province'
         |) as t1
         |where t1.rn = 1
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val ftFirmDataRDD = Util.getRowToJson(spark,sql,100)
    logger.error(s">>>获取丰拓企业信息共 ${ftFirmDataRDD.count()} 条s<<<")
    ftFirmDataRDD
  }


  /**
   *
   * @param ftFirmData
   * @return
   */
  def getFtFirmDataXy(ftFirmData: RDD[JSONObject]): RDD[(JSONObject,JSONObject,JSONObject)] ={
    val ftFirmDataXy = ftFirmData.map(obj => {
      val reg_addr = JSONUtil.getJsonVal(obj,"reg_addr","")
      val source_addrs_encode = JSONUtil.getJsonVal(obj,"source_addrs_encode","")
      val source_addrs_decode = EncryptAesUtil.aesDecrypt(source_addrs_encode)
      var json : JSONObject = new JSONObject()
      json = getRunMapXyInteface(mapa_url,reg_addr,"reg_addr")
      var json1 : JSONObject = new JSONObject()
      json1 = getRunMapXyInteface(mapa_url,source_addrs_decode,"source_addrs_decode")
      (obj,json,json1)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取坐标和省市区共 ${ftFirmDataXy.count()} 条s<<<")
    ftFirmData.unpersist()
    ftFirmDataXy
  }

  /**
   *
   * @param mapUrl
   * @param address
   * @param addrSource
   * @return
   */
  def getRunMapXyInteface(mapUrl: String,address: String,addrSource : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    val df1 = new DecimalFormat("#.000000")
    val df2 = new DecimalFormat("#.000")
    try {
      if (!address.isEmpty) {
        val urls = String.format(mapUrl,URLEncoder.encode(address,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response.toString)
        ret.put("addrSource",addrSource)
        if(response == null){
          logger.error("getRunMapXyInteface resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val xcoord = result.getDouble("xcoord")
                val ycoord = result.getDouble("ycoord")
                val regcode = JSONUtil.getJsonVal(result,"regcode","")
                ret.put("regcode",regcode)
                val adname = JSONUtil.getJsonVal(result,"adname","")
                if(adname != "" && adname != null && adname.contains(",")){
                  val str = adname.substring(1,adname.length - 1)
                  val arr = str.split(",")
                  val province = arr(0)
                  val city = arr(1)
                  val district = arr(2)
                  if(province.length > 2){
                    ret.put("province", province.substring(1,province.length - 1))
                  }
                  if(city.length > 2){
                    ret.put("city", city.substring(1,city.length - 1))
                  }
                  if(district.length > 2){
                    ret.put("district", district.substring(1,district.length - 1))
                  }
                }
                if (xcoord != null){
                  val x = EDEUtil.enAndDeSimple(df1.format(xcoord))
                  val x1 = EDEUtil.enAndDeSimple(df2.format(xcoord))
                  ret.put("x",x)
                  ret.put("x1",x1)
                }
                if (ycoord != null){
                  val y = EDEUtil.enAndDeSimple(df1.format(ycoord))
                  val y1 = EDEUtil.enAndDeSimple(df2.format(ycoord))
                  ret.put("y",y)
                  ret.put("y1",y1)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getRunMapXyInteface status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("address",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param spark
   * @param ftFirmDataXy
   */
  def saveResult(spark : SparkSession,ftFirmDataXy : RDD[(JSONObject,JSONObject,JSONObject)],parDay_1 : String,provincPinYin : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "fty_company_info_new"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1',inc_province = '$provincPinYin')
         |SELECT
         |	 *
         |FROM fty_company_info_new_temp
         |""".stripMargin

    try{
      val schemaString = "fec_id,ty_id,company_name,reg_status,reg_capital,indu_one,indu_two" +
        ",indu_three,estiblish_time,reg_addr,source_addrs,longtitude_6,latitude_6,longtitude_3" +
        ",latitude_3,location_source,city_code,province,cityname,district,company_org_type" +
        ",legal_person_name,quality_type,geo_province,geo_city,geo_district,source_addrs_encode" +
        ",source_addrs_longtitude6,source_addrs_latitude6,source_addrs_longtitude3,source_addrs_latitude3" +
        ",source_addrs_citycode,geo_source_addrs_privince,geo_source_addrs_city,geo_source_addrs_district,location_source_addrs"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = ftFirmDataXy.map(obj => {
        val row = obj._1
        val json = obj._2
        val json1 = obj._3
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(row,"fec_id","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"ty_id","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"company_name","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"reg_status","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"reg_capital","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"indu_one","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"indu_two","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"indu_three","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"estiblish_time","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"reg_addr","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"source_addrs","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"x","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"y","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"x1","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"y1","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"addrSource","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"regcode","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"province","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"cityname","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"district","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"company_org_type","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"legal_person_name","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"quality_type","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"province","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"city","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"district","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"source_addrs_encode","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"x","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"y","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"x1","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"y1","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"regcode","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"province","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"city","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"district","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"addrSource","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
        ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15)
        ,attr(16),attr(17),attr(18),attr(19),attr(20),attr(21),attr(22),attr(23),attr(24),attr(25),attr(26)
        ,attr(27),attr(28),attr(29),attr(30),attr(31),attr(32),attr(33),attr(34),attr(35)))
      import spark.implicits._
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("fty_company_info_new_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
