package com.sf.gis.scala.dqs.util

import java.io.{BufferedReader, FileInputStream, InputStreamReader}
import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date}

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.methods.{CloseableHttpResponse, HttpPost}
import org.apache.http.entity.{ContentType, StringEntity}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01375125 on 2018/7/7.
  */
object Util {

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  def main(args: Array[String]): Unit = {

  }











  def readResouceToList(): Unit ={
    val path = System.getProperty("user.dir") + "/xiaogeno_out.csv"
    val buff = new BufferedReader(new InputStreamReader(new FileInputStream(path),"utf-8"))
    while(buff.readLine()!=null){

    }

  }

  /**
    * 配置spark的conf
    * @param appName
    * @return
    */
  def getLocalConf(appName:String): SparkConf = {
    val master = "local[*]"
    val conf = new SparkConf().setAppName(appName)
    if (JavaUtil.EN == 1) conf.setMaster(master)
    conf.set("spark.port.maxRetries", "100") //端口重试默认次数，超过则放弃
    conf.set("spark.driver.allowMultipleContexts", "true") //在SparkContext构造函数最开始处获取是否允许存在多个SparkContext实例
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true") //该参数决定是否需要以Gracefully方式来关闭Streaming程序
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
    conf
  }

  /**
   * 配置spark的conf
   * @param appName
   * @return
   */
  def getSparkConf(appName:String): SparkConf = {
    val conf = new SparkConf().setAppName(appName)
    conf.set("spark.port.maxRetries", "999")
    conf.set("spark.driver.allowMultipleContexts", "true")
    conf.set("spark.streaming.stopGracefullyOnShutdown", "true")//长期存在于NodeManager进程中的一个辅助服务。通过该服务来抓取shuffle数据，减少了Executor的压力，在Executor GC的时候也不会影响其他Executor的任务运行
    conf.set("spark.shuffle.service.enabled", "true")
    conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    conf.set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
    conf.set("spark.kryoserializer.buffer.max", "128m")
    conf.set("spark.network.timeout", "3000s")
    conf.set("spark.executor.memoryOverhead", "16G")
    conf.set("spark.yarn.executor.memoryOverhead", "8G")
    conf.set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
    conf.set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
    conf.set("spark.rpc.askTimeout", "600s")
    conf.set("spark.shuffle.compress", "true")
    conf.set("spark.sql.hive.mergeFiles", "true")
    conf.set("spark.sql.adaptive.enabled", "true")
    conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
    conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic") //开启动态分区
    conf.set("hive.orc.splits.include.file.footer", "true") //是否将元数据保存在orc文件中
    conf.set("hive.exec.orc.default.stripe.size", "268435456") //默认256M
    conf.set("hive.exec.orc.split.strategy", "BI")//参数控制在读取ORC表时生成split的策略。BI策略以文件为粒度进行split划分；ETL策略会将文件进行切分，多个stripe组成一个split；HYBRID策略为：当文件的平均大小大于hadoop最大split值（默认256 * 1024 * 1024）时使用ETL策略，否则使用BI策略。
    conf.set("spark.sql.hive.convertMetastoreOrc", "true") //开启矢量化
    conf.set("spark.sql.orc.enableVectorizedReader", "true") //开启矢量化 ,矢量化需要100列内,并且字段是基本字段,非null arrays等
    conf.set("spark.sql.crossJoin.enabled", "true") //开启笛卡尔积
    conf.set("spark.sql.orc.filterPushdown", "true") //谓词下推
    conf.set("spark.sql.broadcastTimeout", "1200") //增加获取广播变量超时时间
    conf.set("hive.exec.dynamic.partition", "true")
    conf.set("hive.exec.dynamic.partition.mode", "nonstrict")
    conf.set("hive.exec.max.dynamic.partitions", "10000")
    conf.set("hive.exec.max.dynamic.partitions.pernode", " 10000")
    conf.set("hive.exec.max.created.files", " 1000000")
    conf.set("hive.merge.mapredfiles", "true")
    conf.set("hive.merge.mapfiles", "true")
    conf.set("hive.merge.size.per.task", "134217728")
    conf.set("hive.merge.smallfiles.avgsize", "134217728")
    conf.set("mapreduce.input.fileinputformat.split.maxsize", "134217728")
    conf.set("mapreduce.input.fileinputformat.split.minsize.per.rack", "134217728")
    conf.set("mapreduce.input.fileinputformat.split.minsize.per.node", "134217728")
    conf.set("hive.merge.sparkfiles", "true")
    conf.set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
    conf.set("quota.consumer.default", (10485760 * 2).toString)
    conf.set("cache.max.bytes.buffering", (10485760 * 2).toString)

    //        conf.set("spark.executor.instances","40")

    //    conf.set("spark.executor.cores","4")
    conf.set("spark.executor.extraJavaOptions", " -XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")

    //    conf.set("spark.executor.extraJavaOptions","-verbose:gc -XX:+UseCompressedOops -XX:-UseGCOverheadLimit -XX:+UseG1GC -XX:G1HeapRegionSize=32M")
    conf
  }

  /**
    * 获得两个字符串日期中所有日期的字符格式集合
    *
    * @param startDateStr
    * @param endDateStr
    * @return
    */
  def getBetweenDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      val startDate:Date = sdf.parse(startDateStr)
      val endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(startDate, endDate)

      for(date <- dateList) dateListStr += sdf.format(date)

    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }

  /**
    * 获得两个字符串日期中所有日期的字符格式集合
    *
    * @param startDateStr
    * @param endDateStr
    * @return
    */
  def getBetweenDatesStr(startDateStr: String, endDateStr: String,separator:String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      val startDate:Date = sdf.parse(startDateStr)
      val endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(startDate, endDate)

      for(date <- dateList) dateListStr += sdf.format(date)

    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }



  /**
    * 获得两个日期之间的所有日期列表
    *
    * @param start
    * @param end
    * @return
    */
  def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
    val result = new ArrayBuffer[Date]
    val tempStart = Calendar.getInstance
    tempStart.setTime(start)

    tempStart.add(Calendar.DAY_OF_YEAR, 1)
    val tempEnd = Calendar.getInstance
    tempEnd.setTime(end)
    while (tempStart.before(tempEnd)) {
      result += tempStart.getTime
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    result
  }

  /**
    * 获取某天日期之后几天的日期字符串
    * @param inputDateStr 日期
    * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
    */
  def getDay(inputDateStr:String, num:Int): String ={
    getDay(inputDateStr,num,"-")
  }



  /**
    * 获取某天日期之后几天的日期字符串
    * @param inputDateStr 日期
    * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
    * @param separator 日期分隔符
    * @return
    */
  def getDay(inputDateStr:String, num:Int,separator:String): String ={
    val dateStrFormat = "yyyy"+separator+"MM"+separator+"dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    val inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

/*  /**
    * 获取本机日历日期
    *
    * @param delta
    * @return
    */
  def dateDelta(delta: Int): String = {
    val sdf = new SimpleDateFormat("yyyy-MM-dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }*/

  /**
    * 获取本机日历日期
    *
    * @param delta
    * @return
    */
  def dateDelta(delta: Int): String = {
    dateDelta(delta,"-")
  }

  /**
    * 获取本机日历日期
    *
    * @param delta
    * @return
    */
  def dateDelta(delta: Int,separator:String): String = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, delta)
    val date = sdf.format(cal.getTime)
    date
  }





  /**
    * 读取csv配置文件，获得城市代码的中文名字
    * @param citycode
    * @return
    */
  def getCityName(citycode:String): String ={



    ""
  }

  /**
    * 读取csv配置文件，获得城市名字的城市代码
    * @param cityname
    * @return
    */
  def getCityCode(cityname:String): String ={

    ""
  }


//  /**
//    * 单条操作
//    *
//    * @param sql
//    * @param params
//    */
//  def executeSql(conn:Connection,sql: String, params: Array[String]): Unit = {
//    try {
//      val ps = conn.prepareStatement(sql)
//      if (params != null) {
//        for (i <- params.indices) ps.setString(i + 1, params(i))
//      }
//      //noinspection ScalaUnusedSymbol
//      //      println(sql)
//      val update = ps.executeUpdate()
//      ps.close()
//    } catch {
//      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
//      case e: Exception => println(">>>数据库操作异常："+e)
//    }
//  }
//
//  /**
//    * 批量操作
//    * @param sql
//    * @param paramList
//    */
//  def executeSql1(conn:Connection,sql: String, paramList:ArrayBuffer[Array[String]]): Unit = {
//    try {
//      val ps = conn.prepareStatement(sql)
//      conn.setAutoCommit(false)
//
//      for(params:Array[String] <- paramList){
//
//        if (params != null) {
//          for (i <- params.indices) ps.setString(i + 1, params(i))
//          ps.addBatch()
//        }
//
//      }
//      // val update = ps.executeUpdate()
//      ps.executeBatch()
//      conn.commit()
//      ps.close()
//      conn.close()
//    } catch {
//      //      case e: Exception => logger.error(String.format(e + ">>>数据操作异常: %s", ele))
//      case e: Exception => println(">>>数据库操作异常："+e)
//    }
//  }

  /**
    * 时间字符串转换成毫秒值
    * 样例：2018-10-24 09:54:47 236 ==> 1540346087236
    *
    * @param time
    * @return
    */
  @throws[ParseException]
  def timeToLong(time: String, format: String): Long = {
    val sf = new SimpleDateFormat(format)
    sf.parse(time).getTime
  }


  /**
   *
   * @param spark
   * @param querySql
   * @param parNum
   * @return
   */
  def getRowToJson( spark:SparkSession,querySql:String,parNum:Int=50 ) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.DISK_ONLY)
    val colList = sourDf.columns
    val sourRdd = sourDf.rdd.repartition(parNum).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    }).persist(StorageLevel.DISK_ONLY)
    println(s"共获取数据:${sourRdd.count()}")
    sourDf.unpersist()
    sourRdd
  }

  def getRowToJsonNew_1( spark:SparkSession,querySql:String,num : Int) ={
    val sourDf = spark.sql(querySql).persist(StorageLevel.MEMORY_AND_DISK)
    val colList = sourDf.columns
    val sourRdd = sourDf.rdd.repartition(num).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    println(s"共获取数据:${sourRdd.count()}")
    sourDf.unpersist()
    sourRdd
  }


  def getWeekend() : JSONObject = {
    val cal = Calendar.getInstance()
    val date = new Date()
    val df = new SimpleDateFormat("yyyyMMdd")
    val json = new JSONObject()
    cal.setTime(date)

    var w = cal.get(Calendar.DAY_OF_WEEK) - 1
    if (w < 0)
    w = 0

    cal.add(Calendar.DAY_OF_WEEK,-w)
    json.put("date01",df.format(cal.getTime()))

    cal.add(Calendar.DAY_OF_WEEK,- 7)
    json.put("date02",df.format(cal.getTime()))


    cal.add(Calendar.DAY_OF_WEEK,- 7)
    json.put("date03",df.format(cal.getTime()))

    cal.add(Calendar.DAY_OF_WEEK,- 7)
    json.put("date04",df.format(cal.getTime()))

    json
  }

  def getJsonByPostJsonAddHeader(url: String, json: String, header: String, value: String): JSONObject = {
    // 创建Httpclient对象
    val httpClient = HttpClients.createDefault
    var httpResponse:CloseableHttpResponse  = null
    var jsonObj:JSONObject = null
    try { // 创建Http Post请求
      val httpPost = new HttpPost(url)
      val requestConfig = RequestConfig.custom().setConnectTimeout(20000).setConnectionRequestTimeout(20000).setSocketTimeout(20000).build()
      httpPost.setConfig(requestConfig)
      httpPost.setHeader(header, value)
      // 创建请求内容
      val entity = new StringEntity(json, ContentType.APPLICATION_JSON)
      httpPost.setEntity(entity)
      // 执行http请求
      httpResponse = httpClient.execute(httpPost)
      val stringEntity = EntityUtils.toString(httpResponse.getEntity, "utf-8")
      try {
        jsonObj = JSON.parseObject(stringEntity)
      } catch {
        case e:Exception =>logger.error(">>>结果转换json独享异常："+e)
      }
    } catch {
      case e: Exception =>logger.error(">>>解析异常："+e)
    }
    if(httpResponse!=null)
      httpResponse.close()
    if(httpClient!=null)
      httpClient.close()
    jsonObj
  }







}
