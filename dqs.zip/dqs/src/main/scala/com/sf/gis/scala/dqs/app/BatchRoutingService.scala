package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * Created by 01417629 on 2021/11/04.
 * 代码弃用
 */
//noinspection DuplicatedCode
object BatchRoutingService {
  @transient lazy val logger: Logger = Logger.getLogger(BatchRoutingService.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val xy_url_aoi_code = "http://gis-int.int.sfdc.com.cn:1080/dept2/zctc/aoicode?aoi_code=%s&ak=f1dd5b1b03824caaab3382542bb7bc05&opt=area"
  val xy_url_dept = "http://gis-int.int.sfdc.com.cn:1080/dept/bycode?ak=f1dd5b1b03824caaab3382542bb7bc05&code=%s"
  val distance_time_url = "http://gis-int.int.sfdc.com.cn:1080/rp/v2/api?x1=%s&y1=%s&x2=%s&y2=%s&vehicle=1&planDate=202202231000&ak=f1dd5b1b03824caaab3382542bb7bc05"

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println("############################"+parDay_1)
    //dm_gis.code_data表关联dm_tc_waybillinfo.aoi_area_aoi和dm_gis.aoi_area_polygon，获取aoi区域编码和其对应坐标
    val aoiCodeXy = getBatchRoutingServiceData(spark,parDay_1)
    aoiCodeXy.take(2).foreach(println)
    //获取网点dept
    val deptData = getDeptData(spark)
    deptData.take(2).foreach(println)
    //通过网点dept获取坐标
    val deptXy = getDeptXy(deptData)
    deptXy.take(2).foreach(println)
    //aoi区域编码坐标和网点dept坐标数据自关联
    val aoiCodeXyJoin = getAoiCodeXyJoin(spark,aoiCodeXy,deptXy)
    //saveResult_1(spark,aoiCodeXyJoin,parDay_1)
    aoiCodeXyJoin.take(2).foreach(println)
    //获取aoi区域编码坐标和网点dept坐标数据自关联
    //val aoiCodeXyJoin = getAoiCodeXyJoinHive(spark,parDay_1)
    //aoiCodeXyJoin.take(2).foreach(println(_))
    //通过aoi区域编码坐标和网点dept坐标，获取距离和时间
    val distanceAndTime = getDistanceAndTime(aoiCodeXyJoin)
    distanceAndTime.take(2).foreach(println(_))
    //val distanceAndTime1 = getDistanceAndTime_1(aoiCodeXy,deptXy)
    //distanceAndTime1.take(2).foreach(println(_))
    //将最终结果存入hive表
    saveResult(spark,distanceAndTime,parDay_1)
    distanceAndTime.unpersist()

    //val distanceAndTime2 = getDistanceAndTime_2(aoiCodeXy,deptXy)
    //distanceAndTime2.take(2).foreach(println(_))
    //将最终结果存入hive表
    //saveResult_3(spark,distanceAndTime2,parDay_1)
    //distanceAndTime2.unpersist()
    aoiCodeXyJoin.unpersist()
    deptXy.unpersist()
    deptData.unpersist()
    aoiCodeXy.unpersist()

  }

  def getAoiCodeXyJoinHive(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	 *
         |from
         |dm_gis.aoi_code_xy_join
         |where inc_day = '$parDay_1'
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val aoiCodeXyJoin = Util.getRowToJson(spark,sql,400)
    logger.error(s">>>获取aoi区域编码坐标和网点dept坐标数据自关联 ${aoiCodeXyJoin.count()} 条s<<<")
    aoiCodeXyJoin
  }

  /**
   * dm_gis.code_data表关联dm_tc_waybillinfo.aoi_area_aoi和dm_gis.aoi_area_polygon，获取aoi区域编码和其对应坐标
   * @param spark
   * @return
   */
  def getBatchRoutingServiceData(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	 t2.aoi_area_code
         |	,t3.lng
         |	,t3.lat
         |from
         |(
         |	select
         |		 code
         |		,types
         |	from default.code_data where types like 'aoi%'
         |) as t1
         |
         |left join
         |
         |(
         |	select aoi_area_code,aoi_id from dm_tc_waybillinfo.aoi_area_aoi where status = 1
         |) as t2
         |
         |on t1.code = t2.aoi_id
         |
         |left join
         |
         |(
         |	select code,lng,lat from dm_gis.aoi_area_polygon where inc_day = '$parDay_1' and del_flag = 0
         |) as t3
         |
         |on t2.aoi_area_code = t3.code
         |where t2.aoi_area_code is not null and t2.aoi_area_code <> ''
         |group by t2.aoi_area_code,t3.lng,t3.lat
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val batchRoutingServiceData = Util.getRowToJson(spark,sql,20)
    logger.error(s">>>获取aoi区域编码和其对应坐标 ${batchRoutingServiceData.count()} 条s<<<")
    batchRoutingServiceData
  }

  /**
   * 获取网点dept
   * @param spark
   * @return
   */
  def getDeptData(spark: SparkSession): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |  code
         |  ,types
         |from default.code_data where types not like 'aoi%'
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val deptData = Util.getRowToJson(spark,sql,10)
    logger.error(s">>>获取网点dept ${deptData.count()} 条s<<<")
    deptData
  }

  /**
   * 通过网点dept获取坐标
   * @param
   * @return
   */
  def getDeptXy(deptData: RDD[JSONObject]): RDD[JSONObject] ={
    val deptXy = deptData.map(obj => {
      val res = new JSONObject()
      val code = JSONUtil.getJsonVal(obj,"code","")
      val json = getDeptXyInteface(xy_url_dept,code)
      val lng = JSONUtil.getJsonVal(json,"lng","")
      val lat = JSONUtil.getJsonVal(json,"lat","")
      res.put("aoi_area_code",code)
      res.put("lng",lng)
      res.put("lat",lat)
      res
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>通过网点dept获取坐标 ${deptXy.count()} 条s<<<")
    deptData.unpersist()
    deptXy
  }

  /**
   *
   * @param
   * @param
   * @param
   * @return
   */
  def getDeptXyInteface(url: String,code: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!code.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(code,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response)
        if(response == null){
          logger.error("getDeptXyInteface resp null. url: " + urls)
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val data = result.getJSONArray("data")
                if(data != null){
                  val json = JSON.parseObject(result.getJSONArray("data").get(0).toString)
                  val point = JSONUtil.getJsonVal(json,"point","")
                  if(!point.isEmpty && point.contains("(") && point.contains(")")){
                    val lng = point.split(" ")(0).split("\\(")(1)
                    val lat = point.split(" ")(1).split("\\)")(0)
                    ret.put("lng",lng)
                    ret.put("lat",lat)
                  }
                }else{
                  ret.put("data","null")
                }
              }else{
                ret.put("result","null")
              }
            }else {
              logger.error("getDeptXyInteface status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("code","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  def getAoiCodeXyJoin(spark : SparkSession,aoiCodeXy : RDD[JSONObject],deptXy : RDD[JSONObject]): RDD[JSONObject] ={
    //插入目标表SQL
    val sql =
      s"""
         |select
         |	t1.aoi_area_code as aoi_area_code_start
         |	,t1.lng as lng_start
         |	,t1.lat as lat_start
         |	,t2.aoi_area_code as aoi_area_code_end
         |	,t2.lng as lng_end
         |	,t2.lat as lat_end
         |from aoi_code_dept_xy as t1
         |CROSS JOIN
         |aoi_code_dept_xy as t2
         |""".stripMargin

    val aoiDeptXy = aoiCodeXy.union(deptXy).persist(StorageLevel.DISK_ONLY)
    val schemaString = "aoi_area_code,lng,lat"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
    val schema = StructType(fields)
    val rdd = aoiDeptXy.map(obj => {
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(obj,"aoi_area_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"lng","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"lat","null")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("aoi_code_dept_xy")
    df.printSchema()
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val aoiCodeXyJoin = Util.getRowToJson(spark,sql,100)
    logger.error(s">>>aoi区域编码坐标和网点dept坐标数据自关联 ${aoiCodeXyJoin.count()} 条s<<<")
    aoiCodeXyJoin
  }

  def getDistanceAndTime(aoiCodeXyJoin: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val distanceAndTime = aoiCodeXyJoin.map(obj => {
      val lng_start = JSONUtil.getJsonVal(obj,"lng_start","")
      val lat_start = JSONUtil.getJsonVal(obj,"lat_start","")
      val lng_end = JSONUtil.getJsonVal(obj,"lng_end","")
      val lat_end = JSONUtil.getJsonVal(obj,"lat_end","")
      val json = getDistanceAndTimeInteface(distance_time_url,lng_start,lat_start,lng_end,lat_end)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>通过aoi区域编码坐标和网点dept坐标，获取距离和时间 ${distanceAndTime.count()} 条s<<<")
    distanceAndTime
  }

  def getDistanceAndTime_1(aoiCodeXy: RDD[JSONObject],deptXy : RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val aoiDeptXy = aoiCodeXy.union(deptXy).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>aoiDeptXy ${aoiDeptXy.count()} 条s<<<")
    val distanceAndTime = aoiDeptXy.map(obj => {
      val lng_start = "114.094809"
      val lat_start = "22.708244"
      val lng_end = JSONUtil.getJsonVal(obj,"lng","")
      val lat_end = JSONUtil.getJsonVal(obj,"lat","")
      val json = getDistanceAndTimeInteface(distance_time_url,lng_start,lat_start,lng_end,lat_end)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>通过755WM坐标和aoi区域编码坐标、网点dept坐标，获取距离和时间 ${distanceAndTime.count()} 条s<<<")
    distanceAndTime
  }

  def getDistanceAndTime_2(aoiCodeXy: RDD[JSONObject],deptXy : RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val aoiDeptXy = aoiCodeXy.union(deptXy).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>aoiDeptXy ${aoiDeptXy.count()} 条s<<<")
    val distanceAndTime = aoiDeptXy.map(obj => {
      val lng_start = JSONUtil.getJsonVal(obj,"lng","")
      val lat_start = JSONUtil.getJsonVal(obj,"lat","")
      val lng_end = "114.094809"
      val lat_end = "22.708244"
      val json = getDistanceAndTimeInteface(distance_time_url,lng_start,lat_start,lng_end,lat_end)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>通过755WM坐标和aoi区域编码坐标、网点dept坐标，获取距离和时间 ${distanceAndTime.count()} 条s<<<")
    distanceAndTime
  }

  /**
   *
   * @param
   * @param
   * @param
   * @return
   */
  def getDistanceAndTimeInteface(url: String,lng_start: String,lat_start : String,lng_end: String,lat_end : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!lng_start.isEmpty && !lat_start.isEmpty && !lng_end.isEmpty && !lat_end.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(lng_start,"utf-8")
          ,URLEncoder.encode(lat_start,"utf-8")
          ,URLEncoder.encode(lng_end,"utf-8")
          ,URLEncoder.encode(lat_end,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response)
        if(response == null){
          logger.error("getDistanceAndTimeInteface resp null. url: " + urls)
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if(result != null){
                val dist = JSONUtil.getJsonVal(result,"dist","")
                val time = JSONUtil.getJsonVal(result,"time","")
                ret.put("dist",dist)
                if(!time.isEmpty){
                  ret.put("time",time.toInt/60)
                }
              }
              ret.put("result",result)
            }else {
              logger.error("getDistanceAndTimeInteface status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("xy","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param
   * @param
   */
  def saveResult(spark : SparkSession,distanceAndTime : RDD[(JSONObject,JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    //val descTableName = "batch_routing_service_data"
    val descTableName = "batch_routing_service_data_inc_1"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	 *
         |from batch_routing_service_data_tmp
         |""".stripMargin

    try{
      val schemaString = "aoi_area_code_start,aoi_area_code_end,distance,time"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
      val schema = StructType(fields)
      val rdd = distanceAndTime.map(obj => {
        val row = obj._1
        val json = obj._2
        val sb = new StringBuilder()
        //sb.append(JSONUtil.getJsonVal(row,"aoi_area_code_start","null")).append("\t\t\t")
        sb.append("755WM").append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"aoi_area_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"dist","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"time","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("batch_routing_service_data_tmp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  def saveResult_3(spark : SparkSession,distanceAndTime : RDD[(JSONObject,JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    //val descTableName = "batch_routing_service_data"
    val descTableName = "batch_routing_service_data_inc_2"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	 *
         |from batch_routing_service_data_tmp
         |""".stripMargin

    try{
      val schemaString = "aoi_area_code_start,aoi_area_code_end,distance,time"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
      val schema = StructType(fields)
      val rdd = distanceAndTime.map(obj => {
        val row = obj._1
        val json = obj._2
        val sb = new StringBuilder()
        //sb.append(JSONUtil.getJsonVal(row,"aoi_area_code_start","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"aoi_area_code","null")).append("\t\t\t")
        sb.append("755WM").append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"dist","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"time","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("batch_routing_service_data_tmp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  /**
   *
   * @param
   * @param
   */
  def saveResult_1(spark : SparkSession,aoiCodeXyJoin : RDD[JSONObject],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "aoi_code_xy_join"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	 *
         |from aoi_code_xy_join_tmp
         |""".stripMargin

    try{
      val schemaString = "aoi_area_code_start,lng_start,lat_start,aoi_area_code_end,lng_end,lat_end"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
      val schema = StructType(fields)
      val rdd = aoiCodeXyJoin.map(obj => {
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(obj,"aoi_area_code_start","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"lng_start","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"lat_start","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_area_code_end","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"lng_end","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"lat_end","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("aoi_code_xy_join_tmp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }





}
