package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 电梯年检爬虫数据处理
 * Created by 01417629 on 2021/11/04.
 * 代码弃用-20231025
 */
//noinspection DuplicatedCode
object AnnualInspectionElevatorDataHandle {
  @transient lazy val logger: Logger = Logger.getLogger(AnnualInspectionElevatorDataHandle.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val url_splitResult = "http://gis-int.int.sfdc.com.cn:1080/atroad/api/split?address=%s&ak=3a191e7427e8470c86271a069411c66b&adcode=%s"
  val url_key_word = "http://gis-int.int.sfdc.com.cn:1080/iad/api/keyword?ak=3eb300d2e06947f7945cd02530a32fd2&address=%s&addrType=0"
  val url_std_splitResult = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh&showserver=true&tel=&mobile=&company=&contact=&jpStation="

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    /*val list = getAdcode(spark,parDay_1)
    //val list = List("420100")
    val iter = list.iterator
    while(iter.hasNext){
      val adcode = iter.next().toString
      println("adcode: "+adcode)
      //线下文件，数据处理：使用地址删除,DT,(A-Z)DT,X(A-Z)DT,及后面全部字符，另存为Address
      val elevatorSpyinfo = getElevatorAddrSpyinfo(spark,parDay_1,adcode)
      elevatorSpyinfo.take(2).foreach(println)
      //address跑分词接口，拼接分词结果(split_rslt)
      val splitResult = getSplitResult(elevatorSpyinfo)
      splitResult.take(2).foreach(println)
      //地址跑关键词接口，获取关键词（key_word）
      val keyWord = getKeyWord(splitResult)
      keyWord.take(2).foreach(println)
      //数据打标
      val tagData = getTagData(keyWord)
      tagData.take(2).foreach(println)
      //微服务派件网点单元区域,跑分词，拼接分词结果（std_split）
      val stdSplit = getStaSplitResult(tagData)
      stdSplit.take(2).foreach(println)
      //写入Hive表dm_gis.elevator_addr_spyinfo
      saveResult_2(spark,stdSplit,parDay_1)
      stdSplit.unpersist()
    }*/

    //线下文件，数据处理：使用地址删除,DT,(A-Z)DT,X(A-Z)DT,及后面全部字符，另存为Address
    val elevatorSpyinfo = getElevatorAddrSpyinfo(spark,parDay_1)
    elevatorSpyinfo.take(2).foreach(println)
    //address跑分词接口，拼接分词结果(split_rslt)
    val splitResult = getSplitResult(elevatorSpyinfo)
    splitResult.take(2).foreach(println)
    //地址跑关键词接口，获取关键词（key_word）
    val keyWord = getKeyWord(splitResult)
    keyWord.take(2).foreach(println)
    //数据打标
    val tagData = getTagData(keyWord)
    tagData.take(2).foreach(println)
    //微服务派件网点单元区域,跑分词，拼接分词结果（std_split）
    val stdSplit = getStaSplitResult(tagData)
    stdSplit.take(2).foreach(println)
    //写入Hive表dm_gis.elevator_addr_spyinfo
    saveResult_2(spark,stdSplit,parDay_1)
    stdSplit.unpersist()
  }

  def getAdcode(spark: SparkSession,parDay_1 : String): List[String] ={
    /*val sql =
      s"""
         |select
         |	t1.adcode as adcode
         |from
         |(
         |	SELECT
         |		adcode
         |	FROM default.elevator_addr_spyinfo_online_ljx
         |	where update_day = '$parDay_1'
         |	and adcode is not null and adcode <> ''
         |	group by adcode
         |) as t1
         |
         |left join
         |
         |(
         |	select adcode from dm_gis.elevator_addr_spyinfo_new where inc_day = '$parDay_1'
         |) as t2
         |
         |on t1.adcode = t2.adcode
         |
         |where t2.adcode is null
         |""".stripMargin*/
    val sql =
      s"""
         |select
         |	t1.adcode as adcode
         |from
         |(
         |	SELECT
         |		adcode
         |	FROM dm_gis.elevator_addr_spyinfo
         |	where adcode is not null and adcode <> ''
         |	group by adcode
         |) as t1
         |
         |left join
         |
         |(
         |	select adcode from dm_gis.elevator_addr_spyinfo_new where inc_day = '$parDay_1'
         |) as t2
         |
         |on t1.adcode = t2.adcode
         |
         |where t2.adcode is null
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val adcode = Util.getRowToJson(spark,sql,2400)
    logger.error(s">>>获取adcode共 ${adcode.count()} 条s<<<")
    val list = adcode.collect().map(_.getString("adcode")).toList
    list
  }


  /**
   * 线下文件，数据处理：使用地址删除,DT,(A-Z)DT,X(A-Z)DT,及后面全部字符，另存为Address
   * @param spark
   * @return
   */
  def getElevatorAddrSpyinfo(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    /*val sql =
      s"""
         |SELECT
         |	ecode
         |	,'$city_code' as city_code
         |	,adcode
         |	,subdistrict
         |	,org_address
         |	,case when org_address regexp 'X[A-Z]DT' then split(org_address,'X[A-Z]DT')[0]
         |		when org_address regexp '[A-Z]DT' then split(org_address,'[A-Z]DT')[0]
         |		when org_address regexp 'DT' then split(org_address,'DT')[0]
         |		else org_address end as address
         |	,long
         |	,lat
         |	,level
         |	,station
         |FROM dm_gis.elevator_addr_spyinfo_online
         |where adcode = '$adcode'
         |""".stripMargin*/
    /*val sql =
      s"""
         |SELECT
         |	ecode
         |	,city_code
         |	,adcode
         |	,subdistrict
         |	,org_address
         |	,case when address like '%#楼%' then regexp_replace(address,'#','号') else address end as address
         |	,long as lng
         |	,lat
         |	,level
         |	,station
         |FROM dm_gis.elevator_addr_spyinfo
         |where adcode = '$adcode'
         |""".stripMargin*/
    val sql =
    s"""
       |SELECT
       |	ecode
       |	,citycode as city_code
       |	,adcode
       |	,subdistrict
       |	,org_address
       |	,case when org_address regexp 'X[A-Z]DT' then split(org_address,'X[A-Z]DT')[0]
       |		when org_address regexp '[A-Z]DT' then split(org_address,'[A-Z]DT')[0]
       |		when org_address regexp 'DT' then split(org_address,'DT')[0]
       |    when org_address like '%#楼%' then regexp_replace(org_address,'#','号')
       |		else org_address end as address
       |	,lng
       |	,lat
       |	,level
       |	,station
       |FROM default.elevator_addr_spyinfo_online_ljx
       |where update_day = '$parDay_1'
       |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val elevatorSpyinfo = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>获取处理后的线下数据共 ${elevatorSpyinfo.count()} 条s<<<")
    elevatorSpyinfo
  }

  /**
   * address跑分词接口，拼接分词结果(split_rslt)
   * @param elevatorSpyinfo
   * @return
   */
  def getSplitResult(elevatorSpyinfo: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val splitResult = elevatorSpyinfo.map(obj => {
      val address = JSONUtil.getJsonVal(obj,"address","")
      //val city_code = JSONUtil.getJsonVal(obj,"city_code","")
      val adcode = JSONUtil.getJsonVal(obj,"adcode","")
      var json : JSONObject = null
      //json = getAddressSegmentation(url_splitResult,address,city_code)
      json = getAddressSegmentation(url_splitResult,address,adcode)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取拼接分词结果(split_rslt)共 ${splitResult.count()} 条s<<<")
    elevatorSpyinfo.unpersist()
    splitResult
  }

  /**
   * 地址跑关键词接口，获取关键词（key_word）
   * @param
   * @return
   */
  def getKeyWord(splitResult: RDD[(JSONObject,JSONObject)]): RDD[((JSONObject,JSONObject),JSONObject)] ={
    val keyWord = splitResult.map(obj => {
      val row = obj._1
      val address = JSONUtil.getJsonVal(row,"address","")
      var json : JSONObject = null
      json = getKeyWordInfo(url_key_word,address)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取关键词（key_word）共 ${keyWord.count()} 条s<<<")
    splitResult.unpersist()
    keyWord
  }

  /**
   * 数据打标
   * @param
   * @return
   */
  def getTagData(keyWord: RDD[((JSONObject,JSONObject),JSONObject)]): RDD[((JSONObject,JSONObject),JSONObject)] ={
    val tagData = keyWord.map(obj => {
      val row = obj._1._1
      val json1 = obj._1._2
      val json2 = obj._2
      val address = JSONUtil.getJsonVal(row,"address","")
      val splitResult = JSONUtil.getJsonVal(json1,"splitResult","")
      if (!address.contains("项目"))
      {
        if ((splitResult.contains("^114")) || (splitResult.contains("^214")))
        {
          json2.put("tag", "14级")
        }
        else if (splitResult.contains("大厦"))
        {
          json2.put("tag", "大厦")
        }
        else if (splitResult.contains("大楼"))
        {
          json2.put("tag", "大楼")
        }
        else if (splitResult.contains("综合楼"))
        {
          json2.put("tag", "综合楼")
        }
        else if (splitResult.contains("宾馆"))
        {
          json2.put("tag", "宾馆")
        }
        else if (splitResult.contains("酒店"))
        {
          json2.put("tag", "酒店")
        }
        else if ((splitResult.contains("村")) && (splitResult.contains("号")))
        {
          json2.put("tag", "村号")
        }
        else if ((splitResult.contains("弄")) && (splitResult.contains("号")))
        {
          json2.put("tag", "弄号")
        }
      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>数据打标共 ${tagData.count()} 条s<<<")
    keyWord.unpersist()
    tagData
  }

  /**
   *
   * @param url
   * @param address
   * @param city
   * @return
   */
  def getAddressSegmentation(url: String,address: String,city : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty && !city.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"),URLEncoder.encode(city,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getAddressSegmentation resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                //val addSplitInfo = result.getJSONArray("addSplitInfo")
                val addSplitInfo = result.getJSONArray("addrSplitInfo")
                if(addSplitInfo != null && addSplitInfo.size() > 0){
                  val sb = new StringBuilder
                  for(i<- 0 until addSplitInfo.size()){
                    val json = addSplitInfo.getJSONObject(i)
                    val name = json.getString("name")
                    val prop =json.getString("prop")
                    val level =json.getString("level")
                    if(i == (addSplitInfo.size() - 1)){
                      sb.append(name).append("^").append(prop).append(level)
                    }else{
                      sb.append(name).append("^").append(prop).append(level).append(",")
                    }
                  }
                  ret.put("splitResult",sb.toString())
                }else{
                  ret.put("addSplitInfo",null)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getAddressSegmentation status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("address_or_city",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param url
   * @param address
   * @param
   * @return
   */
  def getKeyWordInfo(url: String,address: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getKeyWordInfo resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val keyInfo = result.getJSONObject("keyInfo")
                if(keyInfo != null){
                  val key_word = JSONUtil.getJsonVal(keyInfo,"key_word","")
                  ret.put("key_word",key_word)
                }else{
                  ret.put("keyInfo",null)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getKeyWordInfo status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("address",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   * 微服务派件网点单元区域,跑分词，拼接分词结果（std_split）
   * @param
   * @return
   */
  def getStaSplitResult(tagData: RDD[((JSONObject,JSONObject),JSONObject)]): RDD[((((JSONObject,JSONObject),JSONObject),JSONObject),JSONObject)] ={
    val stdSplit = tagData.map(obj => {
      val row = obj._1._1
      val address = JSONUtil.getJsonVal(row,"address","")
      val city_code = JSONUtil.getJsonVal(row,"city_code","")
      var json : JSONObject = null
      json = getStdAddr(url_std_splitResult,address,city_code)
      (obj,json)
    }).map(obj => {
      val t1 = obj._1
      val json1 = t1._1._1
      val json2 = obj._2
      //val city_code = JSONUtil.getJsonVal(json1,"city_code","")
      val adcode = JSONUtil.getJsonVal(json1,"adcode","")
      val standardization = JSONUtil.getJsonVal(json2,"standardization","")
      var json : JSONObject = null
      //json = getAddressSegmentation(url_splitResult,standardization,city_code)
      json = getAddressSegmentation(url_splitResult,standardization,adcode)
      (obj,json)
    }).map(obj => {
      val json2 = obj._2
      val splitResult = JSONUtil.getJsonVal(json2,"splitResult","")
      if ((splitResult.contains("^114")) || (splitResult.contains("^214")))
      {
        json2.put("std_tag", "14级")
      }
      else if (splitResult.contains("大厦"))
      {
        json2.put("std_tag", "大厦")
      }
      else if (splitResult.contains("大楼"))
      {
        json2.put("std_tag", "大楼")
      }
      else if (splitResult.contains("综合楼"))
      {
        json2.put("std_tag", "综合楼")
      }
      else if (splitResult.contains("宾馆"))
      {
        json2.put("std_tag", "宾馆")
      }
      else if (splitResult.contains("酒店"))
      {
        json2.put("std_tag", "酒店")
      }
      else if ((splitResult.contains("村")) && (splitResult.contains("号")))
      {
        json2.put("std_tag", "村号")
      }
      else if ((splitResult.contains("弄")) && (splitResult.contains("号")))
      {
        json2.put("std_tag", "弄号")
      }
      obj
    }).distinct().persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取stdSplit共 ${stdSplit.count()} 条s<<<")
    tagData.unpersist()
    stdSplit
  }

  /**
   *
   * @param url
   * @param address
   * @param city
   * @return
   */
  def getStdAddr(url: String,address: String,city : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty && !city.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"),URLEncoder.encode(city,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getStdAddr resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val tcs = result.getJSONArray("tcs")
                if(tcs != null & tcs.size() > 0){
                  val tcs_1 = JSON.parseObject(tcs.get(0).toString)
                  val groupid = JSONUtil.getJsonVal(tcs_1,"groupid","")
                  val aoiid = JSONUtil.getJsonVal(tcs_1,"aoiid","")
                  ret.put("groupid",groupid)
                  ret.put("aoiid",aoiid)
                }else{
                  ret.put("tcs",null)
                }
                val other = result.getJSONObject("other")
                if(other != null){
                  val normresp = other.getJSONObject("normresp")
                  if(normresp != null){
                    val result_1 = normresp.getJSONObject("result")
                    if(result_1 != null){
                      val addrSplitInfo = JSONUtil.getJsonVal(result_1,"addrSplitInfo","")
                      ret.put("addrSplitInfo",addrSplitInfo)
                      val splitResult = JSONUtil.getJsonVal(result_1,"splitResult","")
                      ret.put("splitResult",splitResult)
                      val geocoder = result_1.getJSONArray("geocoder")
                      if(geocoder != null & geocoder.size() > 0){
                        val geocoder_1 = JSON.parseObject(geocoder.get(0).toString)
                        val standardization = JSONUtil.getJsonVal(geocoder_1,"standardization","")
                        ret.put("standardization",standardization)
                      }else{
                        ret.put("geocoder",null)
                      }
                    }else{
                      ret.put("result_1",null)
                    }
                  }else{
                    ret.put("normresp",null)
                  }
                }else{
                  ret.put("other",null)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getStdAddr status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("address_or_city",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param spark
   * @param stdSplit
   */
  def saveResult_2(spark : SparkSession,stdSplit : RDD[((((JSONObject,JSONObject),JSONObject),JSONObject),JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "elevator_addr_spyinfo_new"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1',adcode)
         |SELECT
         |	 ecode,city_code,subdistrict,org_address,address,lng,lat,level,station,tag,split_rslt,key_word,std_addr,aoiid,groupid,std_split,std_tag,adcode
         |FROM elevator_addr_spyinfo_temp
         |group by ecode,city_code,subdistrict,org_address,address,lng,lat,level,station,tag,split_rslt,key_word,std_addr,aoiid,groupid,std_split,std_tag,adcode
         |""".stripMargin

    try{
      val schemaString = "ecode,city_code,subdistrict,org_address,address,lng,lat,level,station,split_rslt,key_word,std_addr,aoiid,groupid,std_split,std_tag,tag,adcode"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = stdSplit.map(obj => {
        val row = obj._1._1._1._1
        val json1 = obj._1._1._2
        val json2 = obj._1._1._1._2
        val json4 = obj._1._2
        val json5 = obj._2
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(row,"ecode","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"city_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"subdistrict","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"org_address","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"address","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"lng","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"long","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"lat","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"level","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"station","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json2,"splitResult","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"key_word","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json4,"standardization","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json4,"aoiid","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json4,"groupid","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json5,"splitResult","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json5,"std_tag","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"tag","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"adcode","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5)
        ,attr(6),attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("elevator_addr_spyinfo_temp")
      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
