package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.{HttpConnection, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 收件判错压审补
 * 2022-03-14 CREATE BY 01417629
 * 代码弃用
 */
//noinspection DuplicatedCode
object ReceivingWrongJudgment {
  @transient lazy val logger: Logger = Logger.getLogger(ReceivingWrongJudgment.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val url_xy_gd2 = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=87106f6380af4df0845a693eee58843c&opt=gd2&address=%s&city=%s"
  val url_xy_ma1 = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=87106f6380af4df0845a693eee58843c&opt=ma1&address=%s&city=%s"
  //val url_aoi = "http://gis-int.int.sfdc.com.cn:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=87106f6380af4df0845a693eee58843c"
  val url_aoi = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=87106f6380af4df0845a693eee58843c"
  //val url_push_judgment = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd?citycode=%s&address=%s&znoCode=%s&aoiId=%s&src=0&operSource=consignee_wrong&operUserName=01417629"
  val url_push_judgment = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd"

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)//t-2分区
    run(spark,parDay_1)
    spark.close()
  }

  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println(parDay_1)
    //表dm_gis.aoi_accuracy_four_ts_check_ret中取判错数据
    val checkRet = GetCheckRet(spark,parDay_1)
    //跑mapa和高德服务获取对应x,y
    val xyData = getXyData(checkRet)
    //跑mapa和高德服务获取对应aoiiid
    val aoiid = getAoiid(xyData)
    //压入审补库-1
    saveResult_1(spark,aoiid,parDay_1,"push01")
    val res1 = pushJudgmentOne(aoiid)
    res1.take(2).foreach(println(_))
    res1.unpersist()
    //压入审补库-2
    saveResult_2(spark,checkRet,parDay_1,"push02")
    val res2 = pushJudgmentTwo(checkRet)
    res2.take(2).foreach(println(_))
    res2.unpersist()
  }

  /**
   * 表dm_gis.aoi_accuracy_four_ts_check_ret中取判错数据
   * @param spark
   * @param parDay_1
   * @return
   */
  def GetCheckRet(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	 req_citycode
         |	,req_address
         |	,tag1
         |	,tag2
         |	,finalaoiid
         |	,mapa_aoiid
         |	,gd_aoiid
         |	,54_aoi_id
         |	,54_aoi_code
         |from dm_gis.aoi_accuracy_four_ts_check_ret
         |where inc_day ='$parDay_1'
         |and tag1 = 'wrong'
         |and tag2 in ('wrong_f','info_notin_gis','mapa_gd_gj_54','mapa_gd_54')
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val checkRet = Util.getRowToJson(spark,sql,100)
    logger.error(s">>>取checkRet数据共 ${checkRet.count()} 条s<<<")
    checkRet
  }

  /**
   * 跑mapa和高德服务获取对应x,y
   * @param
   * @return
   */
  def getXyData(checkRet : RDD[JSONObject]): RDD[(JSONObject,JSONObject,JSONObject)] ={
    val xyData = checkRet.filter(obj => {
      var flag = false
      val tag2 = JSONUtil.getJsonVal(obj,"tag2","")
      val aoi_id_54 = JSONUtil.getJsonVal(obj,"54_aoi_id","")
      if((tag2 == "wrong_f" || tag2 == "info_notin_gis") && (aoi_id_54 != "" && aoi_id_54 != null)){
        flag = true
      }
      flag
    }).map(obj => {
      val req_address = JSONUtil.getJsonVal(obj,"req_address","")
      val req_citycode = JSONUtil.getJsonVal(obj,"req_citycode","")
      val jsonGd2 : JSONObject = getXy(url_xy_gd2,req_address,req_citycode)
      val jsonMa1 : JSONObject = getXy(url_xy_ma1,req_address,req_citycode)
      (obj,jsonGd2,jsonMa1)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>xyData共 ${xyData.count()} 条s<<<")
    xyData
  }

  /**
   * 跑mapa和高德服务获取对应aoiiid
   * @param
   * @return
   */
  def getAoiid(xyData : RDD[(JSONObject,JSONObject,JSONObject)]): RDD[((JSONObject,JSONObject,JSONObject),JSONObject,JSONObject)] ={
    val aoiidData = xyData.filter(obj => {
      var flag = false
      val jsonGd2 = obj._2
      val jsonMa1 = obj._3
      val precisionGd2 = JSONUtil.getJsonVal(jsonGd2,"precision","")
      val precisionMa1 = JSONUtil.getJsonVal(jsonMa1,"precision","")
      if(precisionGd2 == "2" && precisionMa1 == "2"){
        flag = true
      }
      flag
    }).map(obj => {
      val jsonGd2 = obj._2
      val jsonMa1 = obj._3
      val xcoordGd2 = JSONUtil.getJsonVal(jsonGd2,"xcoord","")
      val ycoordGd2 = JSONUtil.getJsonVal(jsonGd2,"ycoord","")
      val xcoordMa1 = JSONUtil.getJsonVal(jsonMa1,"xcoord","")
      val ycoordMa1 = JSONUtil.getJsonVal(jsonMa1,"ycoord","")
      val aoiGd2 : JSONObject = getSrcAOI(url_aoi,xcoordGd2,ycoordGd2)
      val aoiMa1 : JSONObject = getSrcAOI(url_aoi,xcoordMa1,ycoordMa1)
      (obj,aoiGd2,aoiMa1)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>aoiidData共 ${aoiidData.count()} 条s<<<")
    aoiidData
  }


  /**
   *
   * @param url
   * @param address
   * @param city
   * @return
   */
  def getXy(url: String,address: String,city : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty && !city.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"),URLEncoder.encode(city,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getXy resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val precision = JSONUtil.getJsonVal(result,"precision","")
                val xcoord = JSONUtil.getJsonVal(result,"xcoord","")
                val ycoord = JSONUtil.getJsonVal(result,"ycoord","")
                ret.put("precision",precision)
                ret.put("xcoord",xcoord)
                ret.put("ycoord",ycoord)
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getXy status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",rsJson)
          }
        }
      }else{
        ret.put("address_or_city",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e)
    }
    ret
  }

  /**
   *
   * @param url
   * @param x
   * @param y
   * @return
   */
  def getSrcAOI(url: String, x: String, y : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!x.isEmpty && !y.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(x,"utf-8"),URLEncoder.encode(y,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getSrcAOI resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val aoi_data = result.getJSONArray("aoi_data")
                if(aoi_data != null && aoi_data.size() > 0){
                  val data = JSON.parseObject(aoi_data.get(0).toString)
                  val aoi_id = JSONUtil.getJsonVal(data,"aoi_id","")
                  ret.put("aoi_id",aoi_id)
                }else{
                  ret.put("aoi_data",null)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getSrcAOI status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("x_or_y",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e)
    }
    ret
  }

  /**
   * 压入审补库-1
   * @param
   * @return
   */
  def pushJudgmentOne(aoiid : RDD[((JSONObject,JSONObject,JSONObject),JSONObject,JSONObject)]): RDD[(JSONObject,JSONObject)] ={
    val res = aoiid.filter(obj => {
      var flag = false
      val json1 = obj._1._1
      val aoiGd2 = obj._2
      val aoiMa1 = obj._3
      val aoi_id_54 = JSONUtil.getJsonVal(json1,"54_aoi_id","")
      val aoi_id_Gd2 = JSONUtil.getJsonVal(aoiGd2,"aoi_id","")
      val aoi_id_Ma1 = JSONUtil.getJsonVal(aoiMa1,"aoi_id","")
      if((aoi_id_54 == aoi_id_Gd2 && aoi_id_54 == aoi_id_Ma1) && ((aoi_id_Gd2 != "" && aoi_id_Gd2 != null)) && ((aoi_id_Ma1 != "" && aoi_id_Ma1 != null))){
        flag = true
      }
      flag
    }).distinct().map(obj => {
      val json1 = obj._1._1
      val req_citycode = JSONUtil.getJsonVal(json1,"req_citycode","")
      val req_address = JSONUtil.getJsonVal(json1,"req_address","")
      val aoi_code_54 = JSONUtil.getJsonVal(json1,"54_aoi_code","")
      val znoCode = aoi_code_54.substring(0,aoi_code_54.length - 6)
      val aoi_id_54 = JSONUtil.getJsonVal(json1,"54_aoi_id","")
      val params = new JSONObject()
      val addressSave = new JSONObject()
      addressSave.put("cityCode",req_citycode)
      addressSave.put("address",req_address)
      addressSave.put("znoCode",znoCode)
      addressSave.put("aoiId",aoi_id_54)
      addressSave.put("type","1")
      addressSave.put("src","1")
      addressSave.put("zcCheck","1")
      params.put("ak","7577390e76cc40b6ad6542640edd9d84")
      params.put("operSource","consignee_wrong")
      params.put("operUserName","01400731")
      params.put("addressSave",addressSave)
      val json : JSONObject = getPushJudgment(url_push_judgment,params.toJSONString)
      addressSave.put("type","2")
      params.put("addressSave",addressSave)
      val json2 : JSONObject = getPushJudgment(url_push_judgment,params.toJSONString)
      (json,json2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>res共 ${res.count()} 条s<<<")
    aoiid.unpersist()
    res
  }

  /**
   * 压入审补库-2
   * @param
   * @return
   */
  def pushJudgmentTwo(checkRet : RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val res = checkRet.filter(obj => {
      var flag = false
      val tag2 = JSONUtil.getJsonVal(obj,"tag2","")
      if(tag2 == "mapa_gd_gj_54" || tag2 == "mapa_gd_54"){
        flag = true
      }
      flag
    }).distinct().map(obj => {
      val req_citycode = JSONUtil.getJsonVal(obj,"req_citycode","")
      val req_address = JSONUtil.getJsonVal(obj,"req_address","")
      val aoi_code_54 = JSONUtil.getJsonVal(obj,"54_aoi_code","")
      val znoCode = aoi_code_54.substring(0,aoi_code_54.length - 6)
      val aoi_id_54 = JSONUtil.getJsonVal(obj,"54_aoi_id","")
      val params = new JSONObject()
      val addressSave = new JSONObject()
      addressSave.put("cityCode",req_citycode)
      addressSave.put("address",req_address)
      addressSave.put("znoCode",znoCode)
      addressSave.put("aoiId",aoi_id_54)
      addressSave.put("type","1")
      addressSave.put("src","1")
      addressSave.put("zcCheck","1")
      params.put("ak","7577390e76cc40b6ad6542640edd9d84")
      params.put("operSource","consignee_wrong")
      params.put("operUserName","01400731")
      params.put("addressSave",addressSave)
      val json : JSONObject = getPushJudgment(url_push_judgment,params.toJSONString)
      addressSave.put("type","2")
      params.put("addressSave",addressSave)
      val json2 : JSONObject = getPushJudgment(url_push_judgment,params.toJSONString)
      (json,json2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>res共 ${res.count()} 条s<<<")
    checkRet.unpersist()
    res
  }

  /**
   *
   * @param url
   * @param
   * @param
   * @return
   */
  def getPushJudgment(url: String,params : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!params.isEmpty) {
        val httpData = HttpConnection.sendPost(url,params)
        ret.put("httpData",httpData.toString)
        if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {
          val content = httpData.get("content").toString
          val xyObj = JSON.parseObject(content)
          if (xyObj != null && xyObj.getJSONObject("result") != null) {
            if (xyObj.getJSONObject("result").getInteger("err") == 109) {
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep(60 - second)
              return getPushJudgment(url,params)
            }
            val result = xyObj.getJSONObject("result")
            val success = JSONUtil.getJsonVal(result,"success","")
            ret.put("success",success)
          }
        }else{
          ret.put("code",httpData.get("code"))
        }
      }else{
        ret.put("params","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param spark
   * @param aoiid
   */
  def saveResult_1(spark : SparkSession,aoiid : RDD[((JSONObject,JSONObject,JSONObject),JSONObject,JSONObject)],parDay_1 : String,flag : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "push_judgment_check"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1',flag = '$flag')
         |SELECT
         |	 req_citycode,req_address,znoCode,aoi_id_54
         |FROM push_judgment_check_temp
         |""".stripMargin

    try{
      val schemaString = "req_citycode,req_address,znoCode,aoi_id_54"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = aoiid.filter(obj => {
        var flag = false
        val json1 = obj._1._1
        val aoiGd2 = obj._2
        val aoiMa1 = obj._3
        val aoi_id_54 = JSONUtil.getJsonVal(json1,"54_aoi_id","")
        val aoi_id_Gd2 = JSONUtil.getJsonVal(aoiGd2,"aoi_id","")
        val aoi_id_Ma1 = JSONUtil.getJsonVal(aoiMa1,"aoi_id","")
        if((aoi_id_54 == aoi_id_Gd2 && aoi_id_54 == aoi_id_Ma1) && ((aoi_id_Gd2 != "" && aoi_id_Gd2 != null)) && ((aoi_id_Ma1 != "" && aoi_id_Ma1 != null))){
          flag = true
        }
        flag
      }).distinct().map(obj => {
        val json1 = obj._1._1
        val req_citycode = JSONUtil.getJsonVal(json1,"req_citycode","")
        val req_address = JSONUtil.getJsonVal(json1,"req_address","")
        val aoi_code_54 = JSONUtil.getJsonVal(json1,"54_aoi_code","")
        val znoCode = aoi_code_54.substring(0,aoi_code_54.length - 6)
        val aoi_id_54 = JSONUtil.getJsonVal(json1,"54_aoi_id","")
        val sb = new StringBuilder()
        sb.append(req_citycode).append("\t\t\t")
        sb.append(req_address).append("\t\t\t")
        sb.append(znoCode).append("\t\t\t")
        sb.append(aoi_id_54).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("push_judgment_check_temp")
      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  /**
   *
   * @param spark
   * @param
   */
  def saveResult_2(spark : SparkSession,checkRet : RDD[JSONObject],parDay_1 : String,flag : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "push_judgment_check"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1',flag = '$flag')
         |SELECT
         |	 req_citycode,req_address,znoCode,aoi_id_54
         |FROM push_judgment_check_temp
         |""".stripMargin

    try{
      val schemaString = "req_citycode,req_address,znoCode,aoi_id_54"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = checkRet.filter(obj => {
        var flag = false
        val tag2 = JSONUtil.getJsonVal(obj,"tag2","")
        if(tag2 == "mapa_gd_gj_54" || tag2 == "mapa_gd_54"){
          flag = true
        }
        flag
      }).distinct().map(obj => {
        val req_citycode = JSONUtil.getJsonVal(obj,"req_citycode","")
        val req_address = JSONUtil.getJsonVal(obj,"req_address","")
        val aoi_code_54 = JSONUtil.getJsonVal(obj,"54_aoi_code","")
        val znoCode = aoi_code_54.substring(0,aoi_code_54.length - 6)
        val aoi_id_54 = JSONUtil.getJsonVal(obj,"54_aoi_id","")
        val sb = new StringBuilder()
        sb.append(req_citycode).append("\t\t\t")
        sb.append(req_address).append("\t\t\t")
        sb.append(znoCode).append("\t\t\t")
        sb.append(aoi_id_54).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("push_judgment_check_temp")
      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
