package com.sf.gis.scala.dqs.util;


import com.sf.gis.scala.base.util.HttpClientUtil;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;

/**
 * HTTP工具类
 * 单例模式
 *
 */
public class HttpClientUtils {
    private static Logger log = Logger.getLogger(HttpClientUtil.class);
    private static PoolingHttpClientConnectionManager cm;
    private static String EMPTY_STR = null;
    private static String UTF_8 = "utf-8";

    private static void init() {
        if (cm == null) {
            cm = new PoolingHttpClientConnectionManager();
            cm.setMaxTotal(1000);// 整个连接池最大连接数
            cm.setDefaultMaxPerRoute(500);// 每路由最大连接数
        }
    }

    /**
     * 通过连接池获取HttpClient
     * @return
     */
    private static CloseableHttpClient getHttpClient() {
        init();
        return HttpClients.custom().setConnectionManager(cm).build();
    }

    /**
     * Get请求 不带参数
     * @param url
     * @return
     */
    public static String httpGetRequest(String url) {
        HttpGet httpGet = new HttpGet(url);
        httpGet.setConfig(setTimedOut());
        return getResult(httpGet);
    }

    /**
     * Get请求 带参数
     * @param url
     * @param params map
     * @return
     * @throws URISyntaxException
     */
    public static String httpGetRequest(String url, Map<String, Object> params) throws URISyntaxException {
        URIBuilder ub = new URIBuilder();
        ub.setPath(url);

        ArrayList<NameValuePair> pairs = covertParams2NVPS(params);
        ub.setParameters(pairs);

        HttpGet httpGet = new HttpGet(ub.build());
        httpGet.setConfig(setTimedOut());
        return getResult(httpGet);
    }

    /**
     * Get请求 带头域与带参数
     * @param url
     * @param headers 页面头域
     * @param params map
     * @return
     * @throws URISyntaxException
     */
    public static String httpGetRequest(String url, Map<String, Object> headers, Map<String, Object> params)
            throws URISyntaxException {
        URIBuilder ub = new URIBuilder();
        ub.setPath(url);

        ArrayList<NameValuePair> pairs = covertParams2NVPS(params);
        ub.setParameters(pairs);

        HttpGet httpGet = new HttpGet(ub.build());
        httpGet.setConfig(setTimedOut());
        for (Map.Entry<String, Object> param : headers.entrySet()) {
            httpGet.addHeader(param.getKey(), String.valueOf(param.getValue()));
        }
        return getResult(httpGet);
    }

    /**
     * Post请求 不带参数
     * @param url
     * @return
     */
    public static String httpPostRequest(String url) {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(setTimedOut());
        return getResult(httpPost);
    }

    /**
     * Post请求 带参数
     * @param url
     * @param params map
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String httpPostRequest(String url, Map<String, Object> params) throws UnsupportedEncodingException {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(setTimedOut());

        ArrayList<NameValuePair> pairs = covertParams2NVPS(params);
        httpPost.setEntity(new UrlEncodedFormEntity(pairs, UTF_8));
        return getResult(httpPost);
    }

    /**
     * Post请求 带头域与带参数
     * @param url
     * @param headers 头域
     * @param params map
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String httpPostRequest(String url, Map<String, Object> headers, Map<String, Object> params)
            throws UnsupportedEncodingException {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(setTimedOut());

        for (Map.Entry<String, Object> param : headers.entrySet()) {
            httpPost.addHeader(param.getKey(), String.valueOf(param.getValue()));
        }

        ArrayList<NameValuePair> pairs = covertParams2NVPS(params);
        httpPost.setEntity(new UrlEncodedFormEntity(pairs, UTF_8));

        return getResult(httpPost);
    }

    /**
     * map 处理方法
     * @param params
     * @return
     */
    private static ArrayList<NameValuePair> covertParams2NVPS(Map<String, Object> params) {
        ArrayList<NameValuePair> pairs = new ArrayList<NameValuePair>();
        for (Map.Entry<String, Object> param : params.entrySet()) {
            pairs.add(new BasicNameValuePair(param.getKey(), String.valueOf(param.getValue())));
        }
        return pairs;
    }

    /**
     * POST请求 带json格式的字符串参数
     * @param url
     * json json格式的字符串
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String httpPostRequest(String url,String josnString) throws UnsupportedEncodingException{
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(setTimedOut());
        StringEntity s = new StringEntity(josnString);
        s.setContentEncoding(UTF_8);
        s.setContentType("application/json");//发送json数据需要设置contentType
        httpPost.setEntity(s);
        return getResult(httpPost);
    }

    /**
     * POST请求 带json格式的字符串参数
     * @param url
     * json json格式的字符串
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String httpPostRequest4Urlencoded(String url,String urlencoded) throws UnsupportedEncodingException{
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(setTimedOut());
        StringEntity s = new StringEntity(urlencoded);
        s.setContentEncoding(UTF_8);
        s.setContentType("application/x-www-form-urlencoded");
        httpPost.setEntity(s);
        return getResult(httpPost);
    }


    /**
     * 使用POSt方式通过Xml发送HTTP请求
     * @param url
     *            请求的URL地址
     * Xml
     *            请求的Xml内容
     * @return 请求返回的内容体
     * @throws UnsupportedEncodingException
     */
    public static String httpPostXmlRequest(String url, String xmlBody) throws UnsupportedEncodingException {
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(setTimedOut());
        httpPost.addHeader("content-type", "application/xml");

        StringEntity s = new StringEntity(xmlBody);
        s.setContentEncoding(UTF_8);
        s.setContentType("application/xml");//设置contentType
        httpPost.setEntity(s);
        return getResult(httpPost);
    }

    /**
     * 使用PUT方式通过Xml发送HTTP请求
     * @param url
     *            请求的URL地址
     * Xml
     *            请求的Xml内容
     * @return 请求返回的内容体
     * @throws UnsupportedEncodingException
     */
    public static String httpPutXmlRequest(String url, String xmlBody) throws UnsupportedEncodingException {
        HttpPut httpPut = new HttpPut(url);
        httpPut.setConfig(setTimedOut());
        //httpPut.setHeader("Content-Type", "application/xml");
        //httpPut.addHeader("content-type", "application/xml");
        httpPut.setHeader("Content-Type", "application/xml;charset=UTF-8");

        StringEntity s = new StringEntity(xmlBody,Charset.forName("UTF-8"));
        s.setContentEncoding(UTF_8);
        s.setContentType("application/xml");//设置contentType
        httpPut.setEntity(s);
        return getResult(httpPut);
    }


    /**
     * 设置Http连接超时间 单位毫秒
     * setConnectTimeout：设置连接超时时间，单位毫秒
     * setConnectionRequestTimeout：设置从connect Manager获取Connection 超时时间，单位毫秒
     * setSocketTimeout：请求获取数据的超时时间，单位毫秒
     * @return
     */
    public static RequestConfig setTimedOut() {
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(50000).setConnectionRequestTimeout(20000)
                .setSocketTimeout(50000).build();
        return requestConfig;
    }

    /**
     * 红包充值新增
     * POST请求 带json格式的字符串参数
     * @param url
     * json json格式的字符串
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String httpPostRequestByRb(String url,String josnString) throws UnsupportedEncodingException{
        HttpPost httpPost = new HttpPost(url);
        httpPost.setConfig(setTimedOut());
        httpPost.setHeader("Content-Type", "application/json;charset=UTF-8");
        httpPost.setHeader("Date", new Date()+"");
        httpPost.setHeader("Accept", "application/json");
        httpPost.setHeader("Cache-Control", "no-store");

        StringEntity s = new StringEntity(josnString);
        s.setContentEncoding(UTF_8);
        s.setContentType("application/json");//发送json数据需要设置contentType
        httpPost.setEntity(s);
        return getResult(httpPost);
    }

    /**
     * 处理Http请求
     *
     * @param request
     * @return
     * @throws Exception
     */
    private static String getResult(HttpRequestBase request){
        CloseableHttpClient httpClient = getHttpClient();
        CloseableHttpResponse response = null;
        int code = 0;//状态码
        try {
            response = httpClient.execute(request);
            code = response.getStatusLine().getStatusCode();
            if (code != 200) {
                return EMPTY_STR;
            }
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, "utf-8");
            }
        } catch (Exception e) {
            log.error("调用接口异常: "+request, e);
            log.error("状态码" + code,e);
        } finally {
            try {
                response.close();
            } catch (IOException e1) {
                log.error("response关闭异常", e1);
            }
//            log.info("状态码["+code+"]调用接口：" + request);
            log.info("状态码["+code+"]调用接口：" + request);
        }
        return EMPTY_STR;
    }



}

