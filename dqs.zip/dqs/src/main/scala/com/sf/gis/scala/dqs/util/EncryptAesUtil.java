package com.sf.gis.scala.dqs.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import sun.misc.BASE64Decoder;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

/**
 * @Description :
 * @Author : 01376507
 * @Date: 2022-05-06
 */
public class EncryptAesUtil {

    private static final String KEY = "fec_fav4f_ames23";

    private static final String ALGORITHMS = "AES/ECB/PKCS5Padding";

    private static final String AES = "AES";

    public static void main(String[] args) {
        System.out.println("加密密钥和解密密钥:"+KEY);

        String content = "广东省深圳市南山区创智天地大厦B座26楼12";
        System.out.println("加密前:"+content);

        String encrypt = aesEncrypt(content);
        System.out.println("加密后:"+encrypt);

        String decrypt = aesDecrypt(encrypt);
        System.out.println("解密后:"+decrypt);
    }

    /**
     * 将字符串【AES加密】为base 64 code
     *
     * @param content 待加密的内容
     * @return 加密后的base 64 code
     */
    public static String aesEncrypt(String content) {
        try {
            KeyGenerator kgen = KeyGenerator.getInstance("AES");
            kgen.init(128);
            Cipher cipher = Cipher.getInstance(ALGORITHMS);
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(EncryptAesUtil.KEY.getBytes(), EncryptAesUtil.AES));

            byte[] bytes = cipher.doFinal(content.getBytes(StandardCharsets.UTF_8));
            return Base64.encodeBase64String(bytes);
        } catch (Exception e) {
           // log.error(e.getMessage() + e);
        }
        return null;
    }

    /**
     * 将base 64 code 【AES解密】为字符串
     *
     * @param encryptStr 待解密的base 64 code
     * @return 解密后的String
     */
    public static String aesDecrypt(String encryptStr) {
        try {
            if (StringUtils.isEmpty(encryptStr)) {
                return null;
            }
            // 将字符串转为byte，返回解码后的byte[]
            byte[] encryptBytes = new BASE64Decoder().decodeBuffer(encryptStr);

            KeyGenerator kgen = KeyGenerator.getInstance(EncryptAesUtil.AES);
            kgen.init(128);
            Cipher cipher = Cipher.getInstance(ALGORITHMS);
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(EncryptAesUtil.KEY.getBytes(), EncryptAesUtil.AES));
            byte[] decryptBytes = cipher.doFinal(encryptBytes);
            return new String(decryptBytes);
        } catch (Exception e) {
           // log.error(e.getMessage() + e);
        }
        return null;
    }
}
