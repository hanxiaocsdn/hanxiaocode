package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 新增针对AOI变更刷新历史3个月运单的收派件AOI_V1.0(写入结果表)
 * 2022-06-17 CREATE BY 01417629
 * 代码弃用
 */
//noinspection DuplicatedCode
object WaybillHookDataUpdate {
  @transient lazy val logger: Logger = Logger.getLogger(WaybillHookDataUpdate.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    run(spark)
    spark.close()
  }

  def run(spark: SparkSession): Unit ={
    //保存数据到dm_gis.tt_order_aoi_info_update
    saveResult_1(spark)
    //保存数据到dm_gis.tt_waybill_aoi_info_update
    saveResult_2(spark)
  }

  /**
   * 保存数据到dm_gis.tt_order_aoi_info_update
   * @param
   * @param
   */
  def saveResult_1(spark: SparkSession): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tt_order_aoi_info_update"
    //清空目标表SQL
    val deleteSQL =
      s"""
         |truncate table $descDBName.$descTableName
         |""".stripMargin
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day)
         |select waybill_id,waybill_no,source_zone_code,src_dist_code,src_city_code,src_county,src_division_code,src_area_code,src_hq_code,src_type_code,src_lgt,src_lat,meterage_weight_qty,real_weight_qty,consignee_emp_code,consigned_tm,cargo_type_code,limit_type_code,express_type_code,ackbill_type_code,waybill_type,order_no,contacts_id,consignor_comp_name,'null',consignor_phone,consignor_cont_name,consignor_mobile,consignor_addr_native,freight_monthly_acct_code,freight_payment_type_code,freight_payment_dept_code,cod_monthly_acct_code,all_fee,all_fee_rmb,freight,freight_rmb,consignor_post_code,service_prod_code,is_value_insured,cons_name,cvs_code,signed_back_waybill_no,source_waybill_no,goods_deal_type,inner_parcel_flag,self_send_flag,self_pickup_flag,transfer_parcel_flag,order_id,order_type,order_tm,source_unit_code,recv_bar_tm,consign_lgt,consign_lat,load_tm,pay_cust_type,consignor_cust_type,recv_bar_dept_code,waybill_source_type,real_monthly_acct_code,real_product_code,real_all_fee,real_cod_fee_rmb,cons_category,src_province,aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y,aoi_code,hook_src,aoi_type_code,aoi_type_name,aoi_zc,order_type_code,call_needflg,src_sys_type,is_sch_order,call_needflg_gis,aoi_parent,date_exec_task,dept_new,aoicode_new,aoiid_new,inc_day
         |from
         |(
         |	select
         |		*,row_number() over(partition by inc_day,waybill_id,waybill_no,source_zone_code,src_dist_code,src_city_code,src_county,src_division_code,src_area_code,src_hq_code,src_type_code,src_lgt,src_lat,meterage_weight_qty,real_weight_qty,consignee_emp_code,consigned_tm,cargo_type_code,limit_type_code,express_type_code,ackbill_type_code,waybill_type,order_no,contacts_id,consignor_comp_name,consignor_addr,consignor_phone,consignor_cont_name,consignor_mobile,consignor_addr_native,freight_monthly_acct_code,freight_payment_type_code,freight_payment_dept_code,cod_monthly_acct_code,all_fee,all_fee_rmb,freight,freight_rmb,consignor_post_code,service_prod_code,is_value_insured,cons_name,cvs_code,signed_back_waybill_no,source_waybill_no,goods_deal_type,inner_parcel_flag,self_send_flag,self_pickup_flag,transfer_parcel_flag,order_id,order_type,order_tm,source_unit_code,recv_bar_tm,consign_lgt,consign_lat,load_tm,pay_cust_type,consignor_cust_type,recv_bar_dept_code,waybill_source_type,real_monthly_acct_code,real_product_code,real_all_fee,real_cod_fee_rmb,cons_category,src_province,aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y,aoi_code,hook_src,aoi_type_code,aoi_type_name,aoi_zc,order_type_code,call_needflg,src_sys_type,is_sch_order,call_needflg_gis,aoi_parent order by date_exec_task desc) as rn
         |	from dm_gis.tt_order_aoi_info_add_info_new
         |) as t1
         |where t1.rn = 1
         |""".stripMargin

    try{
      logger.error(">>>>>>>>>>清空hive表开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>清空hive: "+deleteSQL)
      spark.sql(deleteSQL)
      logger.error(">>>>>>>>>>清空hive表结束")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  /**
   * 保存数据到dm_gis.tt_waybill_aoi_info_update
   * @param
   * @param
   */
  def saveResult_2(spark: SparkSession): Unit = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tt_waybill_aoi_info_update"
    //清空目标表SQL
    val deleteSQL =
      s"""
         |truncate table $descDBName.$descTableName
         |""".stripMargin
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day)
         |select waybill_id,waybill_no,dest_zone_code,dest_dist_code,dest_city_code,dest_county,dest_division_code,dest_area_code,dest_hq_code,dest_type_code,dest_lgt,dest_lat,meterage_weight_qty,real_weight_qty,deliver_emp_code,signer_name,signin_tm,cargo_type_code,limit_type_code,express_type_code,ackbill_type_code,waybill_type,order_no,consignee_comp_name,'null',consignee_phone,consignee_cont_name,consignee_mobile,consignee_addr_native,freight_monthly_acct_code,freight_payment_type_code,freight_payment_dept_code,cod_monthly_acct_code,all_fee,all_fee_rmb,freight,freight_rmb,consignee_post_code,service_prod_code,is_value_insured,cons_name,receipt_cvs_code,signed_back_waybill_no,source_waybill_no,goods_deal_type,inner_parcel_flag,self_send_flag,self_pickup_flag,transfer_parcel_flag,order_id,dest_unit_code,change_addr_flag,delivery_lgt,delivery_lat,waybill_status,load_tm,pay_cust_type,send_bar_dept_code,first_loading_dept_code,last_unloading_dept_code,waybill_source_type,real_monthly_acct_code,real_product_code,real_all_fee,real_cod_fee_rmb,cons_category,dest_province,aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y,hook_src,aoi_type_code,aoi_type_name,aoi_code,aoi_zc,aoi_parent,date_exec_task,dept_new,aoicode_new,aoiid_new,inc_day
         |from
         |(
         |	select
         |		*,row_number() over(partition by inc_day,waybill_id,waybill_no,dest_zone_code,dest_dist_code,dest_city_code,dest_county,dest_division_code,dest_area_code,dest_hq_code,dest_type_code,dest_lgt,dest_lat,meterage_weight_qty,real_weight_qty,deliver_emp_code,signer_name,signin_tm,cargo_type_code,limit_type_code,express_type_code,ackbill_type_code,waybill_type,order_no,consignee_comp_name,consignee_addr,consignee_phone,consignee_cont_name,consignee_mobile,consignee_addr_native,freight_monthly_acct_code,freight_payment_type_code,freight_payment_dept_code,cod_monthly_acct_code,all_fee,all_fee_rmb,freight,freight_rmb,consignee_post_code,service_prod_code,is_value_insured,cons_name,receipt_cvs_code,signed_back_waybill_no,source_waybill_no,goods_deal_type,inner_parcel_flag,self_send_flag,self_pickup_flag,transfer_parcel_flag,order_id,dest_unit_code,change_addr_flag,delivery_lgt,delivery_lat,waybill_status,load_tm,pay_cust_type,send_bar_dept_code,first_loading_dept_code,last_unloading_dept_code,waybill_source_type,real_monthly_acct_code,real_product_code,real_all_fee,real_cod_fee_rmb,cons_category,dest_province,aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y,hook_src,aoi_type_code,aoi_type_name,aoi_code,aoi_zc,tt_fee_all_fee,tt_fee_cod_fee,tt_fee_tean_fee,tt_fee_rebate_amt,tt_fee_baojia_fee,tt_fee_zh_all_fee,tt_fee_freight_rmb,tt_fee_baozhuang_fee,tt_fee_property_value,tt_fee_zh_freight_rmb,tt_fee_all_service_fee,tt_fee_other_service_fee,tt_fee_zh_all_service_fee,hook_source,aoi_parent,delivery_ac,delivery_xy_dept,delivery_xy_aoiid order by date_exec_task desc) as rn
         |	from dm_gis.tt_waybill_hook_add_info_new
         |) as t1
         |where t1.rn = 1
         |""".stripMargin

    try{
      logger.error(">>>>>>>>>>清空hive表开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>清空hive: "+deleteSQL)
      spark.sql(deleteSQL)
      logger.error(">>>>>>>>>>清空hive表结束")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
