package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.text.DecimalFormat

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.{EDEUtil, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer


/**
 * Created by 01417629 on 2021/11/04.
 * 任务id：769557
 */
//noinspection DuplicatedCode
object DqNewInterfaceSiteAddressDataProcessNew {
  @transient lazy val logger: Logger = Logger.getLogger(DqNewInterfaceSiteAddressDataProcessNew.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val mapa_url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?address=%s&ak=e672ed6ca3ae46409b43eacf4bc7ba60&opt="
  //val seg_url = "https://gis.sf-express.com:45001/seg/api/split?address=%s&ak=e672ed6ca3ae46409b43eacf4bc7ba60&showcode=1"
  val seg_url = "http://gis-int.int.sfdc.com.cn:1080/seg/api/split?address=%s&ak=950fddc87bc5420690681a31500ba61a&showcode=1"
  val limitMin = 5000 / 10

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println(parDay_1)
    //获取场地地址明细表：dm_pms.dm_pms_site_composite_address_df
    val ftFirmData = getFtFirmData(spark,parDay_1)
    ftFirmData.take(2).foreach(println(_))
    //跑seg和geo接口
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "769557", "DQ新接口场地地址数据处理需求(new)", "DQ新接口场地地址数据", "http://gis-int.int.sfdc.com.cn:1080/geo/api", "e672ed6ca3ae46409b43eacf4bc7ba60", ftFirmData.count(), 50)
    val httpInvokeId1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "721264", "DQ新接口场地地址数据处理需求", "DQ新接口场地地址数据", "http://gis-int.int.sfdc.com.cn:1080/seg/api/split", "950fddc87bc5420690681a31500ba61a", ftFirmData.count(), 50)
    val ftFirmDataXy = getFtFirmDataXy(ftFirmData)
    ftFirmDataXy.take(2).foreach(println(_))
    ftFirmData.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId1)
    //写入Hive表
    saveResult(spark,ftFirmDataXy,parDay_1)
    ftFirmDataXy.unpersist()
  }

  /**
   * @param spark
   * @return
   */
  def getFtFirmData(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    spark.sql("add file hdfs://sfbdp1//tmp/udf/sfencode/01417629/sfdencrpt.ini")
    spark.sql("add jar hdfs://sfbdp1//tmp/udf/01377105/131623/1002/decrypt-2.0.jar")
    spark.sql("create temporary function bdp_decrypt as 'com.sf.udf.decrypt_v2.Decrypt'")
    val sql =
      s"""
         |select
         |  detail_address,bdp_decrypt(detail_address,detail_address,false) as detail_address_decrypt
         |FROM
         |(
         |  select detail_address from dm_pms.dm_pms_site_composite_address_df where inc_day = '$parDay_1' group by detail_address
         |) a
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val ftFirmDataRDD = Util.getRowToJson(spark,sql,100)
    logger.error(s">>>获取丰拓企业信息共 ${ftFirmDataRDD.count()} 条s<<<")
    ftFirmDataRDD
  }


  /**
   *
   * @param ftFirmData
   * @return
   */
  def getFtFirmDataXy(ftFirmData: RDD[JSONObject]): RDD[(JSONObject)] ={
    val ftFirmDataXy = ftFirmData.mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", 50000, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val it = obj.next()
        val detail_address_decrypt = JSONUtil.getJsonVal(it, "detail_address_decrypt", "")
        val json1: JSONObject = getGeoInteface(mapa_url,detail_address_decrypt)
        val x = JSONUtil.getJsonVal(json1, "x", "")
        val x1 = JSONUtil.getJsonVal(json1, "x1", "")
        val y = JSONUtil.getJsonVal(json1, "y", "")
        val y1 = JSONUtil.getJsonVal(json1, "y1", "")
        it.put("x",x)
        it.put("x1",x1)
        it.put("y",y)
        it.put("y1",y1)
        val json2: JSONObject = getSegInterface(seg_url,detail_address_decrypt)
        val province = JSONUtil.getJsonVal(json2, "province", "")
        val city = JSONUtil.getJsonVal(json2, "city", "")
        val county = JSONUtil.getJsonVal(json2, "county", "")
        val citycode = JSONUtil.getJsonVal(json2, "citycode", "")
        val town = JSONUtil.getJsonVal(json2, "town", "")
        it.put("province",province)
        it.put("city",city)
        it.put("county",county)
        it.put("citycode",citycode)
        it.put("town",town)
        arrayBuffer.append(it)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取坐标和省市区共 ${ftFirmDataXy.count()} 条s<<<")
    ftFirmDataXy
  }

  /**
   *
   * @param mapUrl
   * @param address
   * @return
   */
  def getGeoInteface(mapUrl: String,address: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    val df1 = new DecimalFormat("#.000000")
    val df2 = new DecimalFormat("#.000")
    try {
      if (!address.isEmpty) {
        val urls = String.format(mapUrl,URLEncoder.encode(address,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val xcoord = result.getDouble("xcoord")
                val ycoord = result.getDouble("ycoord")
                if (xcoord != null){
                  val x = df1.format(xcoord)
                  val x1 = EDEUtil.enAndDeSimple(df2.format(xcoord))
                  ret.put("x",x)
                  ret.put("x1",x1)
                }
                if (ycoord != null){
                  val y = df1.format(ycoord)
                  val y1 = EDEUtil.enAndDeSimple(df2.format(ycoord))
                  ret.put("y",y)
                  ret.put("y1",y1)
                }
              }else{
                ret.put("result","null")
              }
            }else {
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("address","null")
      }
    } catch {
      case e: Exception => ""
    }
    ret
  }

  def getSegInterface(url: String,address: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && status == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val data = result.getJSONObject("data")
                if(data != null){
                  val province = JSONUtil.getJsonVal(data,"province","")
                  val city = JSONUtil.getJsonVal(data,"city","")
                  val county = JSONUtil.getJsonVal(data,"county","")
                  val citycode = JSONUtil.getJsonVal(data,"citycode","")
                  val town = JSONUtil.getJsonVal(data,"town","")
                  ret.put("province",province)
                  ret.put("city",city)
                  ret.put("county",county)
                  ret.put("citycode",citycode)
                  ret.put("town",town)
                }else{
                  ret.put("data","null")
                }
              }else{
                ret.put("result","null")
              }
            }else {
              ret.put("status","!0")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("address","null")
      }
    } catch {
      case e: Exception => ""
    }
    ret
  }

  /**
   *
   * @param spark
   * @param ftFirmDataXy
   */
  def saveResult(spark : SparkSession,ftFirmDataXy : RDD[(JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "dq_new_interface_site_address_data_process_new_1"
    val descTableName1 = "dq_new_interface_site_address_data_process_new_2"
    //插入目标表SQL
    val insertSQL1 =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |SELECT
         |	 detail_address,'' as detail_address_decrypt,province,city,county,citycode,x,y,town
         |FROM dq_new_interface_site_address_data_process_temp
         |""".stripMargin
    val insertSQL2 =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName1 PARTITION(inc_day = '$parDay_1')
         |SELECT
         |	 talk_id,task_id,contract_id,research_id,contract_code,version_number
         |  ,date_day,date_flag,review_passed,property_code,unit_area,property_type_first
         |  ,property_type_second,property_type_three,city_code,t1.detail_address,'' as detail_address_decrypt
         |  ,province,city,county,citycode,x1,y1,town
         |FROM
         |(
         |  select
         |    talk_id,task_id,contract_id,research_id,contract_code,version_number
         |    ,'' as date_day,date_flag,review_passed,property_code,unit_area,property_type_first
         |    ,property_type_second,property_type_three,'' as city_code,detail_address
         |  from dm_pms.dm_pms_site_composite_address_df where inc_day = '$parDay_1'
         |) t1
         |
         |left join
         |
         |(
         |  select
         |    detail_address,province,city,county,citycode,x1,y1,town
         |    from dq_new_interface_site_address_data_process_temp
         |) t2
         |
         |on t1.detail_address = t2.detail_address
         |
         |""".stripMargin

    val schemaString = "detail_address,detail_address_decrypt,x,x1,y,y1,province,city,county,citycode,town"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
    )
    val schema = StructType(fields)
    val rdd = ftFirmDataXy.repartition(5).map(obj => {
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(obj,"detail_address","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"detail_address_decrypt","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"x","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"x1","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"y","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"y1","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"province","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"city","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"county","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"citycode","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"town","null")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
      ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("dq_new_interface_site_address_data_process_temp")
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL1)
    spark.sql(insertSQL1)
    logger.error(">>>>>>>>>>入hive库结束")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL2)
    spark.sql(insertSQL2)
    logger.error(">>>>>>>>>>入hive库结束")
  }
}
