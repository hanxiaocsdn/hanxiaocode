package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.text.DecimalFormat

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.{EDEUtil, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * Created by 01417629 on 2021/11/04.
 * 代码弃用
 */
//noinspection DuplicatedCode
object SpecialWarehousingTelLogic {
  @transient lazy val logger: Logger = Logger.getLogger(SpecialWarehousingTelLogic.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val diff_url = "http://gis-int2.int.sfdc.com.cn:1080/diff/api/vas?address=%s&citycode=%s&opt=sw&ak=9c1d529c40f54877a9a6372e686fee47"
  val diff_url = "http://gis-apis.int.sfcloud.local:1080/diff/api/vas?address=%s&citycode=%s&opt=sw&ak=9c1d529c40f54877a9a6372e686fee47"
  val addrDecrypt_url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/addrDecrypt?address=%s"
  val similar_url = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getSimilar?ak=9c1d529c40f54877a9a6372e686fee47&beforeAddress=&afterAddress="

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    //val parDay_2 = args(1)
    //val parDay_3 = args(2)
    //run(spark,parDay_1,parDay_2,parDay_3)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println("############################"+parDay_1)
    //println("############################"+parDay_2)
    //println("############################"+parDay_3)
    //基于2021年7月-2022年1月,从BDP平台dwd.dwd_waybill_info_dtl_di表取数
    val waybillInfo = getWaybillInfo(spark,parDay_1)
    waybillInfo.take(2).foreach(println)
    //加密地址解密
    val addrDecryptApi = getaddrDecryptApi(waybillInfo)
    addrDecryptApi.take(2).foreach(println)
    //跑diff特殊入仓接口
    val diffApi = getDiffApi(addrDecryptApi)
    diffApi.take(2).foreach(println)
    //写入Hive表
    saveResult(spark,diffApi,parDay_1)
    diffApi.unpersist()
    //从BDP平台dwd.dwd_waybill_info_dtl_di表取数（t-1）
    //val waybillInfoIncDay = getWaybillInfoIncDay(spark,parDay_1)
    //waybillInfoIncDay跑diff特殊入仓接口
    //val diffApiIncDay = getDiffApi(waybillInfoIncDay)
    //识别完成，增加字段source，source=normal。增加字段Matchtype，matchtype=1
    //val diffApiIncDayNormal = getDiffApiIncDayNormal(diffApiIncDay)
    //此条数据不在电话库
    //val diffApiIncDayUnLibrary = getDiffApiIncDayUnLibrary(diffApiIncDay)
    //基于相同的城市代码，相同的电话信息，进行地址相似度评估
  }

  def getDiffApiIncDayUnLibrary(diffApiIncDay: RDD[(JSONObject,JSONObject)]): RDD[(JSONObject,JSONObject)] ={
    val diffApiIncDayUnLibrary = diffApiIncDay.filter(obj => {
      val row = obj._1
      val json = obj._2
      val matchtype = JSONUtil.getJsonVal(json,"matchtype","")
      val addressee_dept_code_tel = JSONUtil.getJsonVal(row,"addressee_dept_code_tel","")
      val dest_city_code_tel = JSONUtil.getJsonVal(row,"dest_city_code_tel","")
      val consignee_addr_tel = JSONUtil.getJsonVal(row,"consignee_addr_tel","")
      val consignee_phone_tel = JSONUtil.getJsonVal(row,"consignee_phone_tel","")
      matchtype != 1 && addressee_dept_code_tel.isEmpty && dest_city_code_tel.isEmpty && consignee_addr_tel.isEmpty && consignee_phone_tel.isEmpty
    }).map(obj => {
      val json = obj._2
      json.put("source","null")
      json.put("matchtype","null")
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>此条数据不在电话库 ${diffApiIncDayUnLibrary.count()} 条s<<<")
    diffApiIncDayUnLibrary
  }

  /**
   * 识别完成，增加字段source，source=normal。增加字段Matchtype，matchtype=1
   * @param
   * @return
   */
  def getDiffApiIncDayNormal(diffApiIncDay: RDD[(JSONObject,JSONObject)]): RDD[(JSONObject,JSONObject)] ={
    val diffApiIncDayNormal = diffApiIncDay.filter(obj => {
      val json = obj._2
      val matchtype = JSONUtil.getJsonVal(json,"matchtype","")
      matchtype == 1
    }).map(obj => {
      val json = obj._2
      json.put("source","normal")
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>识别完成，增加字段source，source=normal ${diffApiIncDayNormal.count()} 条s<<<")
    diffApiIncDayNormal
  }

  /**
   * 基于2021年7月-2022年1月,从BDP平台dwd.dwd_waybill_info_dtl_di表取数
   * @param spark
   * @return
   */
  def getWaybillInfo(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |SELECT
         |	 *
         |FROM dwd.dwd_waybill_info_dtl_di
         |WHERE inc_day = '$parDay_1'
         |and array_contains(service_prod_code,'IN102')
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val waybillInfo = Util.getRowToJson(spark,sql,400)
    logger.error(s">>>dwd_waybill_info_dtl_di表取数 ${waybillInfo.count()} 条s<<<")
    waybillInfo
  }

  /**
   * 从BDP平台dwd.dwd_waybill_info_dtl_di表取数（t-1）
   * @param spark
   * @return
   */
  def getWaybillInfoIncDay(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	 t1.*
         |	,t2.addressee_dept_code as addressee_dept_code_tel
         |	,t2.dest_city_code as dest_city_code_tel
         |	,t2.consignee_addr as consignee_addr_tel
         |	,t2.consignee_phone as consignee_phone_tel
         |from
         |(
         |SELECT
         |	 waybill_no
         |	,dest_zone_code
         |	,addressee_dept_code
         |	,dest_division_code
         |	,dest_area_code
         |	,dest_dist_code
         |	,dest_city_code
         |	,dest_county
         |	,meterage_weight_qty
         |	,real_weight_qty
         |	,consigned_tm
         |	,limit_type_code
         |	,consignee_addr
         |	,consignee_phone
         |	,service_prod_code
         |	,cons_name
         |FROM dwd.dwd_waybill_info_dtl_di
         |WHERE inc_day = '$parDay_1'
         |and array_contains(service_prod_code,'IN102')
         |) as t1
         |left join
         |(
         |SELECT
         |	 addressee_dept_code
         |	 ,dest_city_code
         |	 ,consignee_addr
         |	 ,consignee_phone
         |FROM dm_gis.tel_library_unrecognized
         |WHERE inc_day = '$parDay_1'
         |) as t2
         |on t1.addressee_dept_code = t2.addressee_dept_code
         |and t1.dest_city_code = t2.dest_city_code
         |and t1.consignee_addr = t2.consignee_addr
         |and t1.consignee_phone = t2.consignee_phone
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val waybillInfoIncDay = Util.getRowToJson(spark,sql,200)
    logger.error(s">>>dwd_waybill_info_dtl_di表取数（t-1） ${waybillInfoIncDay.count()} 条s<<<")
    waybillInfoIncDay
  }

  /**
   * 跑diff特殊入仓接口
   * @param
   * @return
   */
  def getDiffApi(addrDecryptApi: RDD[(JSONObject,JSONObject)]): RDD[((JSONObject,JSONObject),JSONObject)] ={
    val diffApi = addrDecryptApi.map(obj => {
      val row = obj._1
      val json = obj._2
      val address = JSONUtil.getJsonVal(json,"data","")
      val dest_dist_code = JSONUtil.getJsonVal(row,"dest_dist_code","")
      val json1 = getdiffApiInteface(diff_url,address,dest_dist_code)
      (obj,json1)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>跑diff特殊入仓接口共 ${diffApi.count()} 条s<<<")
    addrDecryptApi.unpersist()
    diffApi
  }

  def getaddrDecryptApi(waybillInfo: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val addrDecryptApi = waybillInfo.map(obj => {
      val consignee_addr = obj.getString("consignee_addr")
      val json = getaddrDecryptInteface(addrDecrypt_url,consignee_addr)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>加密地址解密 ${addrDecryptApi.count()} 条s<<<")
    waybillInfo.unpersist()
    addrDecryptApi
  }

  def getaddrDecryptInteface(url: String,consignee_addr: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!consignee_addr.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(consignee_addr,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response)
        if(response == null){
          logger.error("getaddrDecryptInteface resp null. url: " + urls)
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val code = rsJson.getInteger("code")
            if(code != null && rsJson.getInteger("code") == 200){
              val data = JSONUtil.getJsonVal(rsJson,"data","")
              ret.put("data",data)
            }else {
              ret.put("code","!200")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("address","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param
   * @param
   * @param
   * @return
   */
  def getdiffApiInteface(url: String,consignee_addr: String,dest_city_code : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!consignee_addr.isEmpty && !dest_city_code.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(consignee_addr,"utf-8"),URLEncoder.encode(dest_city_code,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response)
        if(response == null){
          logger.error("getdiffApiInteface resp null. url: " + urls)
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val sdata = result.getJSONObject("sdata")
                if(sdata != null){
                  val matchtype = JSONUtil.getJsonVal(sdata,"matchtype","")
                  ret.put("matchtype",matchtype)
                }else{
                  ret.put("sdata","null")
                }
              }else{
                ret.put("result","null")
              }
            }else {
              logger.error("getdiffApiInteface status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("address","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param spark
   * @param
   */
  def saveResult(spark : SparkSession,diffApi : RDD[((JSONObject,JSONObject),JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tel_library_unrecognized"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |SELECT
         |	 addressee_dept_code
         |  ,dest_dist_code
         |	,dest_city_code
         |	,decrypt_addr
         |	,consignee_phone
         |  ,decrypt_addr_response
         |  ,matchtype_response
         |  ,matchtype
         |FROM tel_library_unrecognized_temp
         |where consignee_phone is not null
         |and consignee_phone <> ''
         |and consignee_phone <> 'null'
         |""".stripMargin

    try{
      val schemaString = "addressee_dept_code,dest_dist_code,dest_city_code,decrypt_addr,consignee_phone,decrypt_addr_response,matchtype_response,matchtype"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = diffApi.filter(obj => {
        var flag = false
        val json = obj._2
        val matchtype = JSONUtil.getJsonVal(json,"matchtype","")
        if(matchtype != "1"){
          flag = true
        }
        flag
      }).map(obj => {
        val row = obj._1._1
        val json1 = obj._1._2
        val json2 = obj._2
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(row,"addressee_dept_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_dist_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_city_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"data","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"consignee_phone","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json1,"response","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json2,"response","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json2,"matchtype","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6),attr(7)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("tel_library_unrecognized_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
