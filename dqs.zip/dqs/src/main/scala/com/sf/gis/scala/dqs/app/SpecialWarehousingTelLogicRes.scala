package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * Created by 01417629 on 2021/11/04.
 * 代码弃用
 */
//noinspection DuplicatedCode
object SpecialWarehousingTelLogicRes {
  @transient lazy val logger: Logger = Logger.getLogger(SpecialWarehousingTelLogicRes.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println("############################"+parDay_1)
    saveResult(spark,parDay_1)
  }

  /**
   *
   * @param spark
   * @param
   */
  def saveResult(spark : SparkSession,parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tel_library_unrecognized_res"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	 tmp.addressee_dept_code
         |	,tmp.dest_dist_code
         |	,tmp.dest_city_code
         |	,tmp.decrypt_addr
         |	,tmp.consignee_phone
         |    ,tmp.consignee_phone_cnt
         |    ,tmp.decrypt_addr_cnt
         |from
         |(
         |	SELECT
         |		 addressee_dept_code
         |		,dest_dist_code
         |		,dest_city_code
         |		,decrypt_addr
         |		,consignee_phone
         |		,cast(count(1) over(partition by consignee_phone) as int) as consignee_phone_cnt
         |		,cast(count(1) over(partition by decrypt_addr) as int) as decrypt_addr_cnt
         |	FROM dm_gis.tel_library_unrecognized
         |	where inc_day between '20220101' and '20220630'
         |  and consignee_phone is not null
         |	and consignee_phone <> ''
         |	and consignee_phone <> 'null'
         |) as tmp
         |where tmp.consignee_phone_cnt > 100 and tmp.decrypt_addr_cnt > 20
         |group by
         |  tmp.addressee_dept_code
         |	,tmp.dest_dist_code
         |	,tmp.dest_city_code
         |	,tmp.decrypt_addr
         |	,tmp.consignee_phone
         |    ,tmp.consignee_phone_cnt
         |    ,tmp.decrypt_addr_cnt
         |order by tmp.consignee_phone_cnt,tmp.decrypt_addr_cnt desc
         |""".stripMargin

    try{
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
