package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.{FixedConstant, InfConstant}
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.spark.SparkNet
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer



/**
 * 新增针对AOI变更刷新历史3个月运单的收派件AOI_V1.0(收件)
 * 2022-06-17 CREATE BY 01417629
 * 代码弃用
 */
//noinspection DuplicatedCode
object WaybillHookDataUpdateReciver {
  @transient lazy val logger: Logger = Logger.getLogger(WaybillHookDataUpdateReciver.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val url_reciver = "http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&city=%s&ak=a6ea0857a7714867b5a268b8baf4d6eb&opt=zh&isNotUnderCall=1&needAoiArea=1&callDispatch=1"
  val limitMin = 10000 / 20
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    //跑数日期：每个月的10号前完成跑数。
    //假设6月需要输出结果，则最近3个月运单则为3.1-5.31之间的运单。用5月涉及变更的AOI列表来筛选运单，进行数据还原。
    val parDay_1 = args(0)//变更aoi表上个月月初日期（6月跑数，parDay_1=20220501）
    val parDay_2 = args(1)//变更aoi表上个月月末（6月跑数，parDay_1=20220531）
    val parDay_3 = args(2)//运单表分区日期（6月跑数，从3.1开始到5.31（包含）的日期）
    val parDay_4 = args(3)//任务执行日期
    run(spark,parDay_1,parDay_2,parDay_3,parDay_4)
    spark.close()
  }

  def run(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String,parDay_4 : String): Unit ={
    println(parDay_1)
    println(parDay_2)
    println(parDay_3)
    println(parDay_4)
    //获取上一个月的AOI变更信息，只获取涉及AOI新增、删除和多边形修改的变更的信息，然后关联一天的收件运单数据，拿到aoi变更的运单数据
    val orderChangeAoiInfo = GetOrderChangeAoiInfo(spark,parDay_1,parDay_2,parDay_3)
    orderChangeAoiInfo.take(2).foreach(println(_))
    //跑AT收接口，获取新的网点和AOIID、AOICODE
    val aoiInfoNew = getAOIInfoNew(spark,orderChangeAoiInfo)
    aoiInfoNew.take(2).foreach(println(_))
    orderChangeAoiInfo.unpersist()
    //保存数据
    saveResult(spark,aoiInfoNew,parDay_3,parDay_4)
    aoiInfoNew.unpersist()
  }

  /**
   * 获取上一个月的每一天的AOI变更信息，只获取涉及AOI新增、删除和多边形修改的变更的信息，然后关联一天的收件运单数据，拿到aoi变更的运单数据
   * @param spark
   * @param parDay_1
   * @return
   */
  def GetOrderChangeAoiInfo(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	t2.*
         |from
         |(
         |  select
         |	  a.aoi_id as aoi_id
         |	  ,a.inc_day as inc_day
         |  from
         |  (
         |	  select
         |		  aoi_id,inc_day,row_number() over(partition by aoi_id order by inc_day desc) as rn
         |	  from dm_gis.cms_aoi_change
         |	  where inc_day between '$parDay_1' and '$parDay_2'
         |	  and (oper_type in ('I','D') or (oper_type='U' and change_type='1'))
         |    and status = '6'
         |  ) as a
         |  where a.rn = 1
         |) as t1
         |
         |join
         |
         |(
         |	SELECT waybill_id,waybill_no,source_zone_code,src_dist_code,src_city_code,src_county,src_division_code,src_area_code,src_hq_code,src_type_code,src_lgt,src_lat,meterage_weight_qty,real_weight_qty,consignee_emp_code,consigned_tm,cargo_type_code,limit_type_code,express_type_code,ackbill_type_code,waybill_type,order_no,contacts_id,consignor_comp_name,consignor_addr,consignor_phone,consignor_cont_name,consignor_mobile,consignor_addr_native,freight_monthly_acct_code,freight_payment_type_code,freight_payment_dept_code,cod_monthly_acct_code,all_fee,all_fee_rmb,freight,freight_rmb,consignor_post_code,service_prod_code,is_value_insured,cons_name,cvs_code,signed_back_waybill_no,source_waybill_no,goods_deal_type,inner_parcel_flag,self_send_flag,self_pickup_flag,transfer_parcel_flag,order_id,order_type,order_tm,source_unit_code,recv_bar_tm,consign_lgt,consign_lat,load_tm,pay_cust_type,consignor_cust_type,recv_bar_dept_code,waybill_source_type,real_monthly_acct_code,real_product_code,real_all_fee,real_cod_fee_rmb,cons_category,src_province,aoi_id,aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y,aoi_code,hook_src,aoi_type_code,aoi_type_name,aoi_zc,order_type_code,call_needflg,src_sys_type,is_sch_order,call_needflg_gis,aoi_parent,inc_day FROM dm_gis.tt_order_hook
         |	where inc_day = '$parDay_3'
         |) as t2
         |
         |on t1.aoi_id = t2.aoi_id
         |where t1.inc_day >= t2.inc_day
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val orderChangeAoiInfo = Util.getRowToJson(spark,sql,1000)
    logger.error(s">>>orderChangeAoiInfo数据共 ${orderChangeAoiInfo.count()} 条s<<<")
    orderChangeAoiInfo
  }

  /**
   * 跑AT收接口，获取新的网点和AOIID、AOICODE
   * @param orderChangeAoiInfo
   * @return
   */
  /*def getAOIInfoNew(spark: SparkSession,orderChangeAoiInfo : RDD[JSONObject]): RDD[JSONObject] ={
    val aoiInfoNew = runInterfaceWithAkLimit(spark,orderChangeAoiInfo,getAOIInfoNewInterface,100,"a6ea0857a7714867b5a268b8baf4d6eb",5000)
    aoiInfoNew
  }*/
  def getAOIInfoNew(spark: SparkSession,orderChangeAoiInfo : RDD[JSONObject]): RDD[JSONObject] ={
    val aoiInfoNew = orderChangeAoiInfo.mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val it = obj.next()
        val json : JSONObject = getAOIInfoNewInterface(it)
        val dept = JSONUtil.getJsonVal(json,"dept","")
        val aoicode = JSONUtil.getJsonVal(json,"aoicode","")
        val aoiid = JSONUtil.getJsonVal(json,"aoiid","")
        val response = JSONUtil.getJsonVal(json,"response","")
        it.put("dept",dept)
        it.put("aoicode",aoicode)
        it.put("aoiid",aoiid)
        it.put("response",response)
        arrayBuffer.append(it)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>aoiInfoNew共 ${aoiInfoNew.count()} 条s<<<")
    aoiInfoNew
  }

  /**
   * 跑限制了带ak分钟最大量的接口
   *
   * @param dataRdd     数据主体，包含了需要跑接口的数据
   * @param parallelism 指定接口并发度
   * @param akMinuLimit ak分钟最大使用量
   */
  def runInterfaceWithAkLimit(sparkSession: SparkSession,dataRdd: RDD[JSONObject], fun: (String, JSONObject) => JSONObject, parallelism: Int, ak: String, akMinuLimit: Int): RDD[JSONObject] = {
    var cores = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.cores", "0"))
    var excutors = Integer.valueOf(sparkSession.sparkContext.getConf.get("spark.executor.instances", "0"));
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    val localMaster: String = sparkSession.sparkContext.getConf.get("spark.master", "")
    logger.error(localMaster)
    /*if (!localMaster.isEmpty) {
      logger.error("本地调用")
      excutors = localMaster.takeRight(2).dropRight(1).toInt;
      cores = 1
    }*/
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)
    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    var maxParallelism = parallelism
    if (parallelism > excutors) {
      maxParallelism = excutors;
    }
    logger.error("最大分区数：" + maxParallelism)
    var runRdd: RDD[JSONObject] = dataRdd
    var maxMinueOfPartition = akMinuLimit / maxParallelism
    if (parallelism > maxParallelism) {
      maxMinueOfPartition = akMinuLimit / maxParallelism;
    }
    logger.error("单分区ak最大分钟限制：" + maxMinueOfPartition)
    val retRdd = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu = maxMinueOfPartition
      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      //实际单为并行跑数
      partitions.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount)
        }
        val second = Calendar.getInstance().get(Calendar.SECOND)
        val cur = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
        fun(ak, obj)
      })
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("接口运行完毕:" + retRdd.count())
    retRdd
  }

  /**
   *
   * @param
   * @param obj
   * @return
   */
  def getAOIInfoNewInterface(obj:JSONObject): JSONObject = {
    val url="http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&city=%s&ak=a6ea0857a7714867b5a268b8baf4d6eb&opt=zh&isNotUnderCall=1&needAoiArea=1&callDispatch=1"
    try {
      val address = JSONUtil.getJsonVal(obj,"consignor_addr","")
      val city_code = JSONUtil.getJsonVal(obj,"src_dist_code","")
      if (!address.isEmpty && !city_code.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"),URLEncoder.encode(city_code,"utf-8"))
        val response = HttpInvokeUtil.sendGetNew(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          obj.put("response","null")
        }else{
          obj.put("response",response)
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val tcs = result.getJSONArray("tcs")
                if(tcs != null && tcs.size() > 0){
                  val jSONObject = tcs.getJSONObject(0)
                  val dept = JSONUtil.getJsonVal(jSONObject,"dept","")
                  val aoicode = JSONUtil.getJsonVal(jSONObject,"aoicode","")
                  val aoiid = JSONUtil.getJsonVal(jSONObject,"aoiid","")
                  obj.put("dept",dept)
                  obj.put("aoicode",aoicode)
                  obj.put("aoiid",aoiid)
                }else{
                  obj.put("tcs","null")
                }
              }else{
                obj.put("result","null")
              }
            }else {
              logger.error("getAOIInfoNewInterface status = 1. url - {}, resp - {}", urls, response)
              obj.put("status","1")
            }
          }else{
            obj.put("rsJson","null")
          }
        }
      }else{
        obj.put("address_city_code","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        obj.put("Exception",e)
    }
    obj
  }

  /**
   *
   * @param
   * @param
   */
  def saveResult(spark: SparkSession,ret : RDD[JSONObject],parDay_3 : String,parDay_4 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "tt_order_aoi_info_add_info_new"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_3',date_exec_task = '$parDay_4')
         |select
         |	*
         |from tt_order_aoi_info_add_info_new_tmp
         |""".stripMargin

    try{
      val schemaString = "waybill_id,waybill_no,source_zone_code,src_dist_code,src_city_code,src_county,src_division_code" +
        ",src_area_code,src_hq_code,src_type_code,src_lgt,src_lat,meterage_weight_qty,real_weight_qty,consignee_emp_code" +
        ",consigned_tm,cargo_type_code,limit_type_code,express_type_code,ackbill_type_code,waybill_type,order_no,contacts_id" +
        ",consignor_comp_name,consignor_addr,consignor_phone,consignor_cont_name,consignor_mobile,consignor_addr_native" +
        ",freight_monthly_acct_code,freight_payment_type_code,freight_payment_dept_code,cod_monthly_acct_code,all_fee,all_fee_rmb" +
        ",freight,freight_rmb,consignor_post_code,service_prod_code,is_value_insured,cons_name,cvs_code,signed_back_waybill_no" +
        ",source_waybill_no,goods_deal_type,inner_parcel_flag,self_send_flag,self_pickup_flag,transfer_parcel_flag,order_id,order_type" +
        ",order_tm,source_unit_code,recv_bar_tm,consign_lgt,consign_lat,load_tm,pay_cust_type,consignor_cust_type,recv_bar_dept_code" +
        ",waybill_source_type,real_monthly_acct_code,real_product_code,real_all_fee,real_cod_fee_rmb,cons_category,src_province,aoi_id" +
        ",aoi_name,aoi_alias,aoi_address,aoi_x,aoi_y,aoi_code,hook_src,aoi_type_code,aoi_type_name,aoi_zc,order_type_code,call_needflg" +
        ",src_sys_type,is_sch_order,call_needflg_gis,aoi_parent,dept_new,aoicode_new,aoiid_new,response"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = ret.map(obj => {
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(obj,"waybill_id","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"waybill_no","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"source_zone_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_dist_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_city_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_county","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_division_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_area_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_hq_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_lgt","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_lat","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"meterage_weight_qty","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"real_weight_qty","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignee_emp_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consigned_tm","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"cargo_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"limit_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"express_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"ackbill_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"waybill_type","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"order_no","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"contacts_id","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_comp_name","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_addr","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_phone","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_cont_name","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_mobile","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_addr_native","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"freight_monthly_acct_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"freight_payment_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"freight_payment_dept_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"cod_monthly_acct_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"all_fee","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"all_fee_rmb","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"freight","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"freight_rmb","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_post_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"service_prod_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"is_value_insured","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"cons_name","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"cvs_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"signed_back_waybill_no","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"source_waybill_no","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"goods_deal_type","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"inner_parcel_flag","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"self_send_flag","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"self_pickup_flag","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"transfer_parcel_flag","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"order_id","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"order_type","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"order_tm","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"source_unit_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"recv_bar_tm","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consign_lgt","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consign_lat","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"load_tm","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"pay_cust_type","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"consignor_cust_type","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"recv_bar_dept_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"waybill_source_type","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"real_monthly_acct_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"real_product_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"real_all_fee","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"real_cod_fee_rmb","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"cons_category","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_province","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_id","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_name","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_alias","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_address","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_x","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_y","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"hook_src","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_type_name","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_zc","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"order_type_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"call_needflg","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_sys_type","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"is_sch_order","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"call_needflg_gis","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_parent","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"dept","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoicode","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoiid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"response","")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6)
        ,attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17),attr(18),attr(19),attr(20)
        ,attr(21),attr(22),attr(23),attr(24),attr(25),attr(26),attr(27),attr(28),attr(29),attr(30),attr(31),attr(32),attr(33),attr(34)
        ,attr(35),attr(36),attr(37),attr(38),attr(39),attr(40),attr(41),attr(42),attr(43),attr(44),attr(45),attr(46),attr(47),attr(48)
        ,attr(49),attr(50),attr(51),attr(52),attr(53),attr(54),attr(55),attr(56),attr(57),attr(58),attr(59),attr(60)
        ,attr(61),attr(62),attr(63),attr(64),attr(65),attr(66),attr(67),attr(68),attr(69),attr(70)
        ,attr(71),attr(72),attr(73),attr(74),attr(75),attr(76),attr(77),attr(78),attr(79),attr(80)
        ,attr(81),attr(82),attr(83),attr(84),attr(85),attr(86),attr(87)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("tt_order_aoi_info_add_info_new_tmp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
