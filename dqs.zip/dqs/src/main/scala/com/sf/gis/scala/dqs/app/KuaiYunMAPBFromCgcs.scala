package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.text.DecimalFormat
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.dqs.util.{EDEUtil, HttpConnection, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 *结果数据已不见，先注释待删除 01374443 20231025
 */
object KuaiYunMAPBFromCgcs {
//  @transient lazy val logger: Logger = Logger.getLogger(KuaiYunMAPBFromCgcs.getClass)
//
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//
//  val url = "http://gis-int.intsit.sfdc.com.cn:1080/geo/api?"
//
//  def main(args: Array[String]): Unit = {
//    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
//    spark.sparkContext.setLogLevel("ERROR")
//
//    val parDay_1 = args(0)
//    val parDay_2 = args(1)
//    val parDay_3 = args(2)
//
//    //run(spark,parDay_1,parDay_2,parDay_3)
//    spark.close()
//  }
//
//  /**
//   *
//   * @param spark
//   */
//  def run(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String): Unit ={
//    println(parDay_1 + "------>" + parDay_2)
//
//    //sxky_result_from_cgcs关联sxky_task_to_cgcs
//    val sxkyResult = getsxkyResult(spark,parDay_1,parDay_2)
//
//    //获取对应字段【check_aoi_id】，调获取AOI中心点坐标接口获取对应坐标【x】,【y】
//    val sxkyResultXY = getsxkyResultXYNew(sxkyResult)
//
//    //
//
//    sxkyResultXY.unpersist()
//  }
//
//
//  /**
//   * 获取MAPB错柯记录
//   * @param spark
//   * @param parDay_2
//   * @return
//   */
//  def getsxkyResult(spark: SparkSession,parDay_1 : String,parDay_2 : String): RDD[JSONObject] ={
//    val joinSQL =
//      s"""
//         |SELECT
//         |	 city_code
//         |	,t1_address
//         |	,check_aoi_id
//         |FROM
//         |(
//         |SELECT
//         |	 t1.city_code		AS city_code
//         |	,t1.address	    	AS t1_address
//         |	,t1.check_aoi_id	AS check_aoi_id
//         |	,t2.address	    	AS t2_address
//         |FROM (SELECT city_code,address,check_aoi_id FROM dm_gis.sxky_result_from_cgcs WHERE inc_day = '$parDay_1') t1
//         |LEFT JOIN
//         |(SELECT address FROM dm_gis.sxky_task_to_cgcs WHERE inc_day = '$parDay_2' GROUP BY address) t2
//         |on t1.address = t2.address
//         |) t
//         |WHERE t.t2_address IS NOT NULL
//         |""".stripMargin
//
//    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>sxky_result_from_cgcs: "+joinSQL)
//
//    val sxkyResult = Util.getRowToJson(spark,joinSQL,100)
//
//    logger.error(s">>>获取错柯记录 ${sxkyResult.count()} 条s<<<")
//
//    sxkyResult
//  }
//
//  /**
//   * 跑at派接口，获取对应大组【id】和网点【zno_code】
//   * @param sxkyResult
//   * @return
//   */
//  def getsxkyResultXYNew(sxkyResult: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
//    val sxkyResultXY = sxkyResult.map(obj => {
//      val check_aoi_id = obj.getString("check_aoi_id")
//      var json : JSONObject = null
//

//      val mapb_url = "http://gis-apis.int.sfcloud.local:1080/dept2/zctc/aoiid&aoi_id=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=area"
//
//      json = getsxkyXYINterface(mapb_url,check_aoi_id)
//
//      (obj,json)
//    }).persist(StorageLevel.DISK_ONLY)
//    logger.error(s">>>获取丰拓企业信息坐标信息共 ${sxkyResultXY.count()} 条s<<<")
//
//    sxkyResult.unpersist()
//
//    sxkyResultXY
//  }
//
//
//  /**
//   *
//   * @param mapb_url
//   * @param check_aoi_id
//   * @return
//   */
//  def getsxkyXYINterface(mapb_url: String,check_aoi_id: String): JSONObject = {
//    var ret: JSONObject = null
//    try {
//      if (!check_aoi_id.isEmpty) {
//        val url = String.format(mapb_url,URLEncoder.encode(check_aoi_id,"utf-8"))
//        val idCode = HttpClientUtil.getJsonByGet(url)
//        if (idCode != null && idCode.getJSONObject("result") != null) {
//          if (idCode.getJSONObject("result").getInteger("err") == 109) {
//            val second = Calendar.getInstance().get(Calendar.SECOND)
//            Thread.sleep(60 - second)
//            return getsxkyXYINterface(mapb_url,check_aoi_id)
//          }
//          ret = new JSONObject()
//          var x,y = ""
//          val result = idCode.getJSONObject("result")
//          if (result != null) {
//            if (result.getJSONArray("data") != null){
//              val central_coord = JSON.parseObject(result.getJSONArray("data").get(0).toString).getJSONObject("central_coord")
//
//              if (central_coord != null){
//                x = central_coord.getString("x")
//                y = central_coord.getString("y")
//              }
//
//            }
//          }
//          ret.put("x", x)
//          ret.put("y", y)
//        }
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//    }
//    ret
//  }
//
//
//
//  /**
//   *
//   * @param spark
//   * @param ftFirmDataXy
//   */
//  def saveResult(spark : SparkSession,ftFirmDataXy : RDD[(JSONObject,JSONObject)],parDay_1 : String): Unit ={
//    //目标库表名称
//    val descDBName = "dm_gis"
//    val descTableName = "fty_company_info"
//
//    //插入目标表SQL
//    val insertSQL =
//      s"""
//         |INSERT INTO TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
//         |SELECT
//         |	 fec_id
//         |	,ty_id
//         |	,company_name
//         |	,reg_status
//         |	,reg_capital
//         |	,indu_one
//         |	,indu_two
//         |	,indu_three
//         |	,estiblish_time
//         |	,reg_addr
//         |	,source_addrs
//         |	,longtitude_6
//         |	,latitude_6
//         |	,longtitude_3
//         |	,latitude_3
//         |	,location_source
//         |	,province
//         |	,cityname
//         |	,district
//         |	,company_org_type
//         |	,legal_person_name
//         |	,city_code
//         |FROM fty_company_info_temp
//         |""".stripMargin
//
//    try{
//      val schemaString = "fec_id,ty_id,company_name,reg_status,reg_capital,indu_one,indu_two" +
//        ",indu_three,estiblish_time,reg_addr,source_addrs,longtitude_6,latitude_6,longtitude_3" +
//        ",latitude_3,location_source,city_code,province,cityname,district,company_org_type,legal_person_name"
//      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
//      )
//      val schema = StructType(fields)
//
//      val rdd = ftFirmDataXy.map(obj => {
//        val row = obj._1
//        val json = obj._2
//
//        val sb = new StringBuilder()
//        sb.append(row.getString("fec_id")).append("\t\t\t")
//        sb.append(row.getString("ty_id")).append("\t\t\t")
//        sb.append(row.getString("company_name")).append("\t\t\t")
//        sb.append(row.getString("reg_status")).append("\t\t\t")
//        sb.append(row.getString("reg_capital")).append("\t\t\t")
//        sb.append(row.getString("indu_one")).append("\t\t\t")
//        sb.append(row.getString("indu_two")).append("\t\t\t")
//        sb.append(row.getString("indu_three")).append("\t\t\t")
//        sb.append(row.getString("estiblish_time")).append("\t\t\t")
//        sb.append(row.getString("reg_addr")).append("\t\t\t")
//        sb.append(row.getString("source_addrs")).append("\t\t\t")
//        if(json != null){
//          sb.append(json.getString("x")).append("\t\t\t")
//          sb.append(json.getString("y")).append("\t\t\t")
//          sb.append(json.getString("x1")).append("\t\t\t")
//          sb.append(json.getString("y1")).append("\t\t\t")
//          sb.append(json.getString("addrSource")).append("\t\t\t")
//          sb.append(json.getString("regcode")).append("\t\t\t")
//        }else{
//          sb.append("null").append("\t\t\t")
//          sb.append("null").append("\t\t\t")
//          sb.append("null").append("\t\t\t")
//          sb.append("null").append("\t\t\t")
//          sb.append("null").append("\t\t\t")
//          sb.append("null").append("\t\t\t")
//        }
//        sb.append(row.getString("province")).append("\t\t\t")
//        sb.append(row.getString("cityname")).append("\t\t\t")
//        sb.append(row.getString("district")).append("\t\t\t")
//        sb.append(row.getString("company_org_type")).append("\t\t\t")
//        sb.append(row.getString("legal_person_name")).append("\t\t\t")
//
//        sb.toString()
//      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
//        ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15)
//        ,attr(16),attr(17),attr(18),attr(19),attr(20),attr(21)))
//
//      val df = spark.createDataFrame(rdd,schema)
//      df.printSchema()
//      df.show(5)
//      df.createOrReplaceTempView("fty_company_info_temp")
//
//      //删除已有分区数据，然后插入最新数据
//      logger.error(">>>>>>>>>>入hive库开始")
//      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
//      spark.sql(insertSQL)
//      logger.error(">>>>>>>>>>入hive库结束")
//    } catch {
//      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
//    }
//
//  }

}
