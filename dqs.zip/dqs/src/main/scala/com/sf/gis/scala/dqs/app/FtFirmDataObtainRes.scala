package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.text.DecimalFormat

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.{EDEUtil, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * Created by 01417629 on 2021/11/04.
 */
//noinspection DuplicatedCode
object FtFirmDataObtainRes {
  @transient lazy val logger: Logger = Logger.getLogger(FtFirmDataObtainRes.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println("############################"+parDay_1)

    val ftyCompanyInfo = getFtyCompanyInfo(spark,parDay_1)
    ftyCompanyInfo.take(2).foreach(println)

    val ftyCompanyInfoXy = getFtyCompanyInfoXy(ftyCompanyInfo)
    ftyCompanyInfoXy.take(2).foreach(println)

    saveResult(spark,ftyCompanyInfoXy,parDay_1)
    ftyCompanyInfoXy.unpersist()
  }

  /**
   *
   * @param spark
   * @return
   */
  def getFtyCompanyInfo(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         SELECT
         |  fec_id
         |  ,ty_id
         |  ,company_name
         |  ,reg_status
         |  ,reg_capital
         |  ,indu_one
         |  ,indu_two
         |  ,indu_three
         |  ,estiblish_time
         |  ,reg_addr
         |  ,source_addrs
         |  ,longtitude_6
         |  ,latitude_6
         |  ,longtitude_3
         |  ,latitude_3
         |  ,location_source
         |  ,province
         |  ,cityname
         |  ,district
         |  ,company_org_type
         |  ,legal_person_name
         |  ,city_code
         |  ,quality_type
         |  ,geo_province
         |  ,geo_city
         |  ,geo_district
         |  ,response
         |FROM dm_gis.fty_company_info_new
         |WHERE inc_day = '$parDay_1'
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val ftyCompanyInfo = Util.getRowToJson(spark,sql,400)
    logger.error(s">>>获取丰拓企业中间表信息共 ${ftyCompanyInfo.count()} 条s<<<")
    ftyCompanyInfo
  }

  /**
   *
   * @param
   * @return
   */
  def getFtyCompanyInfoXy(ftyCompanyInfo: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val ftyCompanyInfoXy = ftyCompanyInfo.map(obj => {
      val response = JSONUtil.getJsonVal(obj,"response","")
      val json = getRunMapXy(response)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取丰拓企业信息坐标信息共 ${ftyCompanyInfoXy.count()} 条s<<<")
    ftyCompanyInfo.unpersist()
    ftyCompanyInfoXy
  }

  /**
   *
   * @param spark
   * @param
   */
  def saveResult(spark : SparkSession,ftyCompanyInfo : RDD[(JSONObject,JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "fty_company_info_whole"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |SELECT
         |	 fec_id
         |	,ty_id
         |	,company_name
         |	,reg_status
         |	,reg_capital
         |	,indu_one
         |	,indu_two
         |	,indu_three
         |	,estiblish_time
         |	,reg_addr
         |	,source_addrs
         |	,longtitude_6
         |	,latitude_6
         |	,longtitude_3
         |	,latitude_3
         |	,location_source
         |	,province
         |	,cityname
         |	,district
         |	,company_org_type
         |	,legal_person_name
         |	,city_code
         |  ,quality_type
         |  ,geo_province
         |  ,geo_city
         |  ,geo_district
         |FROM fty_company_info_whole_temp
         |""".stripMargin

    try{
      val schemaString = "fec_id,ty_id,company_name,reg_status,reg_capital,indu_one,indu_two" +
        ",indu_three,estiblish_time,reg_addr,source_addrs,longtitude_6,latitude_6,longtitude_3" +
        ",latitude_3,location_source,city_code,province,cityname,district,company_org_type" +
        ",legal_person_name,quality_type,geo_province,geo_city,geo_district"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = ftyCompanyInfo.map(obj => {
        val row = obj._1
        val json = obj._2
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(row,"fec_id","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"ty_id","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"company_name","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"reg_status","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"reg_capital","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"indu_one","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"indu_two","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"indu_three","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"estiblish_time","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"reg_addr","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"source_addrs","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"x","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"y","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"x1","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"y1","null")).append("\t\t\t")
        sb.append("reg_addr").append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"regcode","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"province","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"cityname","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"district","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"company_org_type","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"legal_person_name","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"quality_type","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"province","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"city","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"district","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
        ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15)
        ,attr(16),attr(17),attr(18),attr(19),attr(20),attr(21),attr(22),attr(23),attr(24),attr(25)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("fty_company_info_whole_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  /**
   *
   * @param
   * @param
   * @param
   * @return
   */
  def getRunMapXy(response: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    val df1 = new DecimalFormat("#.000000")
    val df2 = new DecimalFormat("#.000")
    try {
      if (!response.isEmpty) {
        val rsJson = JSON.parseObject(response)
        if(rsJson != null){
          val status = rsJson.getInteger("status")
          if(status != null && rsJson.getInteger("status") == 0){
            val result = rsJson.getJSONObject("result")
            if (result != null) {
              val xcoord = result.getDouble("xcoord")
              val ycoord = result.getDouble("ycoord")
              val regcode = JSONUtil.getJsonVal(result,"regcode","")
              ret.put("regcode",regcode)
              val adname = JSONUtil.getJsonVal(result,"adname","")
              if(adname != "" && adname != null && adname.contains(",")){
                val str = adname.substring(1,adname.length - 1)
                val arr = str.split(",")
                val province = arr(0)
                val city = arr(1)
                val district = arr(2)
                if(province.length > 2){
                  ret.put("province", province.substring(1,province.length - 1))
                }
                if(city.length > 2){
                  ret.put("city", city.substring(1,city.length - 1))
                }
                if(district.length > 2){
                  ret.put("district", district.substring(1,province.length - 1))
                }
              }
              if (xcoord != null){
                val x = EDEUtil.enAndDeSimple(df1.format(xcoord))
                val x1 = EDEUtil.enAndDeSimple(df2.format(xcoord))
                ret.put("x",x)
                ret.put("x1",x1)
              }
              if (ycoord != null){
                val y = EDEUtil.enAndDeSimple(df1.format(ycoord))
                val y1 = EDEUtil.enAndDeSimple(df2.format(ycoord))
                ret.put("y",y)
                ret.put("y1",y1)
              }
            }else{
              ret.put("result",null)
            }
          }else {
            ret.put("status","1")
          }
        }else{
          ret.put("rsJson",null)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }
}
