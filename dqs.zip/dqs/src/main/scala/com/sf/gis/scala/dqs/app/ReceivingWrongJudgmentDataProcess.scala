package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 智域收件判错数据审补来源数据处理
 * 2022-06-08 CREATE BY 01417629
 * 任务id：441062
 */
//noinspection DuplicatedCode
object ReceivingWrongJudgmentDataProcess {
  @transient lazy val logger: Logger = Logger.getLogger(ReceivingWrongJudgmentDataProcess.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val url_issue_data = "http://gis-aos-cgcs.sf-express.com/audit/api/task/importTaskData?address=%s&deptCode=%s&batchNo=%s"
  val url_issue_data = "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushErrorAddressTask?znoCode=%s&address=%s&batchNo=%s&ak=15F6437FF8A2EDFE0C22EA37B12D421A&waybillNo=%s"
  val limitMin = 2000 / 20

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val parDay_1 = args(0)//t-2分区
    val parDay_2 = args(1)//t分区
    val parDay_3 = args(2)//t-32分区
    val parDay_4 = args(3)//t-7分区
    val parDay_5 = args(4)//t-14分区
    run(spark,parDay_1,parDay_2,parDay_3,parDay_4,parDay_5)
    spark.close()
  }

  def run(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String,parDay_4 : String,parDay_5 : String): Unit ={
    println(parDay_1)
    println(parDay_2)
    println(parDay_3)
    println(parDay_4)
    println(parDay_5)
    //获取遗留错误数据,增加gj_aoiids等字段,根据req_address,finalzc排重后按照freq从高到低排序,每个finalzc最多50条
    val checkRet = GetCheckRet(spark,parDay_1,parDay_2,parDay_3,parDay_4,parDay_5)
    checkRet.take(2).foreach(println(_))
    //下发数据,获取返回结果
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "441062", "智域收件判错数据审补来源数据处理", "智域收件判错数据审补来源数据处理", "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushErrorAddressTask", "15F6437FF8A2EDFE0C22EA37B12D421A", checkRet.count(), 20)
    val issueRes = issueData(checkRet,parDay_2)
    checkRet.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    /*//获取遗留错误数据,增加gj_aoiids等字段,根据req_address,finalzc排重后按照freq从高到低排序,每个finalzc大于50条的数据
    val checkRet_2 = GetCheckRet_2(spark,parDay_1,parDay_2,parDay_3,parDay_4,parDay_5)
    checkRet_2.take(2).foreach(println(_))
    val ret = issueRes.union(checkRet_2).persist(StorageLevel.DISK_ONLY)
    //val ret = issueRes
    ret.take(2).foreach(println(_))
    issueRes.unpersist()
    checkRet_2.unpersist()*/
    //保存下发和非下发数据
    //保存下发
    saveResult(spark,issueRes,parDay_2)
    issueRes.unpersist()
  }

  /**
   * 获取遗留错误数据,增加gj_aoiids等字段,根据req_address,finalzc排重后按照freq从高到低排序,每个finalzc最多50条
   * @param spark
   * @param parDay_1
   * @return
   */
  def GetCheckRet(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String,parDay_4 : String,parDay_5 : String): RDD[JSONObject] ={
    val dr = "$"
    val sql =
      s"""
         |select
         |	tmp7.*
         |	,tmp8.src_order_no
         |from
         |(
         |	select
         |	tmp6.*
         |from
         |(
         |	select
         |		tmp5.*
         |		--,row_number() over(partition by finalzc order by freq desc) as rn2
         |	from
         |	(
         |		select
         |			tmp1.*
         |			,tmp2.gj_aoiids
         |			,tmp3.aoiids_54
         |			,tmp4.gj_aoiids_p
         |			,row_number() over(partition by finalzc,req_address order by finalzc,req_address) as rn1
         |		from
         |		(
         |			select
         |				t1.*
         |			from
         |			(
         |				select
         |					a.*
         |				from
         |				(
         |					SELECT req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname,bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord,gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right,result_flag,groupid,freq FROM dm_gis.aoi_accuracy_compute_result where inc_day = '$parDay_2'
         |				) as a
         |
         |				left join
         |
         |				(
         |					--select finalzc,req_address from dm_gis.legacy_error_data_tmp where inc_day between '$parDay_5' and '$parDay_4' and tag_aoiid = 'issued' group by finalzc,req_address
         |					select req_address from dm_gis.legacy_error_data_tmp where inc_day between '$parDay_5' and '$parDay_4' and tag_aoiid = 'issued' group by req_address
         |				) as b
         |
         |				--on a.finalzc = b.finalzc and a.req_address = b.req_address
         |				on a.req_address = b.req_address
         |
         |        left join
         |
         |        (
         |          select address from dm_gis.cgcss_misclassification_data_shunt where inc_day between '$parDay_4' and '$parDay_2' group by address
         |        ) as c
         |
         |        on a.req_address = c.address
         |
         |				where b.req_address is null and c.address is null
         |
         |			) as t1
         |
         |			inner join
         |
         |			(
         |			select
         |				b.groupid as groupid
         |			from
         |			(
         |				select
         |					a.groupid as groupid
         |					,sum(is_aoiright_flag) as cnt
         |				from
         |				(
         |					SELECT
         |						groupid
         |						,case when is_aoiright <> '1' then 0 else 1 end as is_aoiright_flag
         |					FROM dm_gis.aoi_accuracy_compute_result
         |					where inc_day = '$parDay_2'
         |				) as a
         |				group by a.groupid
         |			) as b
         |			where b.cnt < 1
         |			) as t2
         |
         |			on t1.groupid = t2.groupid
         |		) as tmp1
         |
         |		left join
         |
         |		(
         |			select
         |				c.groupid as groupid
         |				,concat_ws(',',collect_set(c.gj_aoiid_t_cnt)) as gj_aoiids
         |			from
         |			(
         |				select
         |					a.groupid as groupid
         |					,a.gj_aoiid_t as gj_aoiid_t
         |					,count(1) as cnt
         |					,concat(a.gj_aoiid_t, ':', count(1)) as gj_aoiid_t_cnt
         |
         |				from
         |				(
         |					SELECT
         |						groupid
         |						,gj_aoiid_t
         |					FROM dm_gis.aoi_accuracy_54_aoiname_ret_bsp where (inc_day between '$parDay_3' and '$parDay_1') and get_json_object(extra,'$dr.aoisrc') in ('chk','dispatch-chkn')
         |					and (groupid is not null and groupid <> '') and (gj_aoiid_t is not null and gj_aoiid_t <> '')
         |				) as a
         |
         |				inner join
         |
         |				(
         |					select aoi_id from dm_gis.cms_aoi_sch where source = 'sz' and del_flag != '1' group by aoi_id
         |				) as b
         |
         |				on a.gj_aoiid_t = b.aoi_id
         |				group by a.groupid,a.gj_aoiid_t
         |			) as c
         |			group by c.groupid
         |		) as tmp2
         |
         |		on tmp1.groupid = tmp2.groupid
         |
         |		left join
         |
         |		(
         |			select
         |				c.groupid as groupid
         |				,concat_ws(',',collect_set(c.54_aoi_id_cnt)) as aoiids_54
         |			from
         |			(
         |				select
         |					a.groupid as groupid
         |					,a.54_aoi_id as 54_aoi_id
         |					,count(1) as cnt
         |					,concat(a.54_aoi_id, ':', count(1)) as 54_aoi_id_cnt
         |				from
         |				(
         |					SELECT
         |						groupid
         |						,54_aoi_id
         |					FROM dm_gis.aoi_accuracy_54_aoiname_ret_bsp where (inc_day between '$parDay_3' and '$parDay_1') and get_json_object(extra,'$dr.aoisrc') in ('chk','dispatch-chkn')
         |					and (groupid is not null and groupid <> '') and (54_aoi_id is not null and 54_aoi_id <> '')
         |				) as a
         |
         |				inner join
         |
         |				(
         |					select aoi_id from dm_gis.cms_aoi_sch where source = 'sz' and del_flag != '1' group by aoi_id
         |				) as b
         |
         |				on a.54_aoi_id = b.aoi_id
         |				group by a.groupid,a.54_aoi_id
         |			) as c
         |			group by c.groupid
         |		) as tmp3
         |
         |		on tmp1.groupid = tmp3.groupid
         |
         |		left join
         |
         |		(
         |			select
         |				c.gis_to_sys_groupid as gis_to_sys_groupid
         |				,concat_ws(',',collect_set(c.gj_aoiid_t_cnt)) as gj_aoiids_p
         |			from
         |			(
         |				select
         |					a.gis_to_sys_groupid as gis_to_sys_groupid
         |					,a.gj_aoiid_t as gj_aoiid_t
         |					,count(1) as cnt
         |					,concat(a.gj_aoiid_t, ':', count(1)) as gj_aoiid_t_cnt
         |				from
         |				(
         |					SELECT
         |						gis_to_sys_groupid
         |						,gj_aoiid_t
         |					FROM dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected where (inc_day between '$parDay_3' and '$parDay_1') and gisaoisrc = 'chkn'
         |					and (gis_to_sys_groupid is not null and gis_to_sys_groupid <> '') and (gj_aoiid_t is not null and gj_aoiid_t <> '')
         |				) as a
         |
         |				inner join
         |
         |				(
         |					select aoi_id from dm_gis.cms_aoi_sch where source = 'sz' and del_flag != '1' group by aoi_id
         |				) as b
         |
         |				on a.gj_aoiid_t = b.aoi_id
         |				group by a.gis_to_sys_groupid,a.gj_aoiid_t
         |			) as c
         |			group by c.gis_to_sys_groupid
         |		) as tmp4
         |
         |		on tmp1.groupid = tmp4.gis_to_sys_groupid
         |	) as tmp5
         |	where tmp5.rn1 = 1
         |) as tmp6
         |--where tmp6.rn2 <= 50
         |) as tmp7
         |
         |left join
         |
         |(
         |	select
         |		req_address
         |		,src_order_no
         |	from
         |	(
         |	SELECT
         |		req_address
         |		,src_order_no
         |		,row_number() over(partition by req_address order by src_order_no desc) as rn
         |	FROM dm_gis.aoi_accuracy_54_aoiname_ret_bsp where inc_day between '$parDay_5' and '$parDay_4' and get_json_object(extra,'$dr.aoisrc') in ('chk','dispatch-chkn')
         |	and (req_address is not null and req_address <> '') and (src_order_no is not null and src_order_no <> '')
         |	) as d
         |	where rn = 1
         |) as tmp8
         |
         |on tmp7.req_address = tmp8.req_address
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val checkRet = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>取checkRet数据共 ${checkRet.count()} 条s<<<")
    checkRet
  }

  /**
   *
   * @param
   * @param
   */
  def saveResult(spark: SparkSession,ret : RDD[JSONObject],parDay_2 : String): Unit ={
    val dr = "$"
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "legacy_error_data_tmp"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_2')
         |select
         |	*
         |from legacy_error_data_temp
         |""".stripMargin

    val schemaString = "req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t" +
      ",aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname" +
      ",bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord" +
      ",gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right" +
      ",result_flag,groupid,freq,gj_aoiids,aoiids_54,gj_aoiids_p,tag_aoiid"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
    )
    val schema = StructType(fields)
    val rdd = ret.repartition(10).map(obj => {
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(obj,"req_address","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"citycode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalzc","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoisrc","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalaoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalaoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag1","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag2","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"r_aoi","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiid_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoicode_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiname_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_id_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_code_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_name_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"key_word","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_chkn","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_chkn","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_norm","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_norm","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois1","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois2","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raoiss","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois3","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"is_aoiright","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"src_rightaoi","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_right","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_right","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"result_flag","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"groupid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"freq","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiids_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids_p","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag_aoiid","")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6)
      ,attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17),attr(18),attr(19),attr(20)
      ,attr(21),attr(22),attr(23),attr(24),attr(25),attr(26),attr(27),attr(28),attr(29),attr(30),attr(31),attr(32),attr(33),attr(34)
      ,attr(35),attr(36),attr(37),attr(38),attr(39),attr(40),attr(41),attr(42),attr(43),attr(44),attr(45),attr(46),attr(47),attr(48)
      ,attr(49),attr(50),attr(51),attr(52)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("legacy_error_data_temp")
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }

  /**
   * 下发数据,获取返回结果
   * @param
   * @return
   */
//  def issueData(checkRet : RDD[JSONObject], parDay_2 : String): RDD[JSONObject] ={
//    val issueRes = checkRet.mapPartitions(obj => {
//      var cnt = 0
//      var startTime = System.currentTimeMillis()
//      obj.foreach(o => {
//        cnt = cnt + 1
//        if (cnt == limitMin) {
//          val endTime = System.currentTimeMillis() - startTime
//          if (endTime < 60000) {
//            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
//            Thread.sleep(60000 - endTime)
//          }
//          startTime = System.currentTimeMillis()
//          cnt = 0
//         }
//          val req_address = JSONUtil.getJsonVal(o,"req_address","")
//          val deptCode = JSONUtil.getJsonVal(o,"finalzc","")
//          val batchNo = "cuofen_cgcs_shou_ch_" + parDay_2
//          val json : JSONObject = getissueData(url_issue_data,req_address,deptCode,batchNo)
//          if(json != null){
//            val success = JSONUtil.getJsonVal(json,"success","")
//            if(success == "true"){
//              o.put("tag_aoiid","issued")
//            }else{
//              o.put("tag_aoiid","not_issued")
//            }
//          }else{
//            o.put("tag_aoiid","not_issued")
//          }
//          o
//      })
//      obj
//    }).persist(StorageLevel.DISK_ONLY)
//    logger.error(s">>>issueRes共 ${issueRes.count()} 条s<<<")
//    issueRes
//  }

  def issueData(checkRet : RDD[JSONObject], parDay_2 : String): RDD[JSONObject] ={
    val issueRes = checkRet.map(obj => {
      val req_address = JSONUtil.getJsonVal(obj,"req_address","")
      val deptCode = JSONUtil.getJsonVal(obj,"finalzc","")
      val src_order_no = JSONUtil.getJsonVal(obj,"src_order_no","")
      val batchNo = "cuofen_cgcs_" + parDay_2
      val json : JSONObject = getissueData(url_issue_data,deptCode,req_address,batchNo,src_order_no)
      if(json != null){
        val success = JSONUtil.getJsonVal(json,"success","")
        if(success == "true"){
          obj.put("tag_aoiid","issued")
        }else{
          obj.put("tag_aoiid","not_issued")
        }
      }else{
        obj.put("tag_aoiid","not_issued")
      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>issueRes共 ${issueRes.count()} 条s<<<")
    issueRes
  }

  /**
   *
   * @param url
   * @param req_address
   * @param deptCode
   * @param batchNo
   * @return
   */
  def getissueData(url: String,req_address: String,deptCode : String,batchNo : String,src_order_no : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!req_address.isEmpty && !deptCode.isEmpty && !batchNo.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(req_address,"utf-8"),URLEncoder.encode(deptCode,"utf-8"),URLEncoder.encode(batchNo,"utf-8"),URLEncoder.encode(src_order_no,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val success = JSONUtil.getJsonVal(rsJson,"success","")
            ret.put("success",success)
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("req_address_deptCode_batchNo","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e)
    }
    ret
  }

  /**
   * 获取遗留错误数据,增加gj_aoiids等字段,根据req_address,finalzc排重后按照freq从高到低排序,每个finalzc大于50条的数据
   * @param spark
   * @param parDay_1
   * @return
   */
  def GetCheckRet_2(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String,parDay_4 : String,parDay_5 : String): RDD[JSONObject] ={
    val dr = "$"
    val sql =
      s"""
         |select
         |	tmp6.*
         | ,'greater_than_50' as tag_aoiid
         |from
         |(
         |	select
         |		tmp5.*
         |		,row_number() over(partition by finalzc order by freq desc) as rn2
         |	from
         |	(
         |		select
         |			tmp1.*
         |			,tmp2.gj_aoiids
         |			,tmp3.aoiids_54
         |			,tmp4.gj_aoiids_p
         |			,row_number() over(partition by finalzc,req_address order by finalzc,req_address) as rn1
         |		from
         |		(
         |			select
         |				t1.*
         |			from
         |			(
         |				select
         |					a.*
         |				from
         |				(
         |					SELECT req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname,bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord,gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right,result_flag,groupid,freq FROM dm_gis.aoi_accuracy_compute_result where inc_day = '$parDay_2'
         |				) as a
         |
         |				left join
         |
         |				(
         |					select finalzc,req_address from dm_gis.legacy_error_data_tmp where inc_day between '$parDay_4' and '$parDay_5' and tag_aoiid = 'issued' group by finalzc,req_address
         |				) as b
         |
         |				on a.finalzc = b.finalzc and a.req_address = b.req_address
         |				where b.finalzc is null and b.req_address is null
         |
         |			) as t1
         |
         |			inner join
         |
         |			(
         |			select
         |				b.groupid as groupid
         |			from
         |			(
         |				select
         |					a.groupid as groupid
         |					,sum(is_aoiright_flag) as cnt
         |				from
         |				(
         |					SELECT
         |						groupid
         |						,case when is_aoiright <> '1' then 0 else 1 end as is_aoiright_flag
         |					FROM dm_gis.aoi_accuracy_compute_result
         |					where inc_day = '$parDay_2'
         |				) as a
         |				group by a.groupid
         |			) as b
         |			where b.cnt < 1
         |			) as t2
         |
         |			on t1.groupid = t2.groupid
         |		) as tmp1
         |
         |		left join
         |
         |		(
         |			select
         |				c.groupid as groupid
         |				,concat_ws(',',collect_set(c.gj_aoiid_t_cnt)) as gj_aoiids
         |			from
         |			(
         |				select
         |					a.groupid as groupid
         |					,a.gj_aoiid_t as gj_aoiid_t
         |					,count(1) as cnt
         |					,concat(a.gj_aoiid_t, ':', count(1)) as gj_aoiid_t_cnt
         |
         |				from
         |				(
         |					SELECT
         |						groupid
         |						,gj_aoiid_t
         |					FROM dm_gis.aoi_accuracy_54_aoiname_ret_bsp where (inc_day between '$parDay_3' and '$parDay_1') and get_json_object(extra,'$dr.aoisrc') in ('chk','dispatch-chkn')
         |					and (groupid is not null and groupid <> '') and (gj_aoiid_t is not null and gj_aoiid_t <> '')
         |				) as a
         |
         |				inner join
         |
         |				(
         |					select aoi_id from dm_gis.cms_aoi_sch where source = 'sz' and del_flag != '1' group by aoi_id
         |				) as b
         |
         |				on a.gj_aoiid_t = b.aoi_id
         |				group by a.groupid,a.gj_aoiid_t
         |			) as c
         |			group by c.groupid
         |		) as tmp2
         |
         |		on tmp1.groupid = tmp2.groupid
         |
         |		left join
         |
         |		(
         |			select
         |				c.groupid as groupid
         |				,concat_ws(',',collect_set(c.54_aoi_id_cnt)) as aoiids_54
         |			from
         |			(
         |				select
         |					a.groupid as groupid
         |					,a.54_aoi_id as 54_aoi_id
         |					,count(1) as cnt
         |					,concat(a.54_aoi_id, ':', count(1)) as 54_aoi_id_cnt
         |				from
         |				(
         |					SELECT
         |						groupid
         |						,54_aoi_id
         |					FROM dm_gis.aoi_accuracy_54_aoiname_ret_bsp where (inc_day between '$parDay_3' and '$parDay_1') and get_json_object(extra,'$dr.aoisrc') in ('chk','dispatch-chkn')
         |					and (groupid is not null and groupid <> '') and (54_aoi_id is not null and 54_aoi_id <> '')
         |				) as a
         |
         |				inner join
         |
         |				(
         |					select aoi_id from dm_gis.cms_aoi_sch where source = 'sz' and del_flag != '1' group by aoi_id
         |				) as b
         |
         |				on a.54_aoi_id = b.aoi_id
         |				group by a.groupid,a.54_aoi_id
         |			) as c
         |			group by c.groupid
         |		) as tmp3
         |
         |		on tmp1.groupid = tmp3.groupid
         |
         |		left join
         |
         |		(
         |			select
         |				c.gis_to_sys_groupid as gis_to_sys_groupid
         |				,concat_ws(',',collect_set(c.gj_aoiid_t_cnt)) as gj_aoiids_p
         |			from
         |			(
         |				select
         |					a.gis_to_sys_groupid as gis_to_sys_groupid
         |					,a.gj_aoiid_t as gj_aoiid_t
         |					,count(1) as cnt
         |					,concat(a.gj_aoiid_t, ':', count(1)) as gj_aoiid_t_cnt
         |				from
         |				(
         |					SELECT
         |						gis_to_sys_groupid
         |						,gj_aoiid_t
         |					FROM dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected where (inc_day between '$parDay_3' and '$parDay_1') and gisaoisrc = 'chkn'
         |					and (gis_to_sys_groupid is not null and gis_to_sys_groupid <> '') and (gj_aoiid_t is not null and gj_aoiid_t <> '')
         |				) as a
         |
         |				inner join
         |
         |				(
         |					select aoi_id from dm_gis.cms_aoi_sch where source = 'sz' and del_flag != '1' group by aoi_id
         |				) as b
         |
         |				on a.gj_aoiid_t = b.aoi_id
         |				group by a.gis_to_sys_groupid,a.gj_aoiid_t
         |			) as c
         |			group by c.gis_to_sys_groupid
         |		) as tmp4
         |
         |		on tmp1.groupid = tmp4.gis_to_sys_groupid
         |	) as tmp5
         |	where tmp5.rn1 = 1
         |) as tmp6
         |where tmp6.rn2 > 50
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val checkRet_2 = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>取checkRet_2数据共 ${checkRet_2.count()} 条s<<<")
    checkRet_2
  }
}
