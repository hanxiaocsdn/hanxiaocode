package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.dqs.util.{HttpConnection, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * MAPB错柯运营工艺_V1.0(临时跑数)
 * 任务id：394375
 */
//noinspection DuplicatedCode
object ExpressMAPBDisLocation {
  @transient lazy val logger: Logger = Logger.getLogger(ExpressMAPBDisLocation.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val parDay_1 = args(0) //t-1
    val parDay_2 = args(1) //t-2
    val parDay_3 = args(2) //t-30
    val parDay_4 = args(3) //t
    run(spark, parDay_1, parDay_2, parDay_3, parDay_4)
    spark.close()
  }

  def run(spark: SparkSession, parDay_1: String, parDay_2: String, parDay_3: String, parDay_4: String): Unit = {
    logger.error(parDay_1 + ">>>>>>>>>>" + parDay_2 + ">>>>>>>>>>" + parDay_3 + ">>>>>>>>>>" + parDay_4)

    logger.error(">>>>>>>>>>>>>>>>>>>>>开始执行逻辑代码")
    val mapDisLocationRDD = getMAPBDisLocation(spark, parDay_2)

    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "394375", "MAPB错柯运营工艺_V1.0", "MAPB错柯运营工艺", "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api", "3eb300d2e06947f7945cd02530a32fd2", mapDisLocationRDD.count(), 10000)
    val mapDisLocationIdCode = getMAPBDisLocationIdCode(mapDisLocationRDD)
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    logger.error("httpInvokeId = " + httpInvokeId)

    val misClassification = getMisClassification(spark)

    val disLocJoinClassification = getDisLocationJoin(spark, mapDisLocationIdCode, misClassification)

    conditionJudge(spark, disLocJoinClassification, parDay_4)

    //val cuokeJoinCghsResult = conditionJudgeAOIID(spark,disLocJoinClassification,parDay_1,parDay_3)

    //val aoiID = getAOIid(cuokeJoinCghsResult)
    //按城市输出文件input.csv,放在指定服务器和路径
    //saveResult2CSV(spark,aoiID,parDay_4)
    // 调批量坐标更新任务
    //val result = xyUpdate(aoiID)
  }


  /**
   * 获取MAPB错柯记录
   *
   * @param spark
   * @param parDay_2
   * @return
   */
  def getMAPBDisLocation(spark: SparkSession, parDay_2: String): RDD[JSONObject] = {
    val querySql =
      s"""
         |SELECT
         |	 detail
         |FROM dm_gis.test_kuaiyun_detail_di
         |WHERE inc_day = '$parDay_2'
         |""".stripMargin
    val sql =
      s"""
         |SELECT
         |	 city_code
         |	,address
         |FROM tmp
         |WHERE src = 'MAPB'
         |AND tag = 'recognition'
         |AND wr_tag = 'rec_wr'
         |""".stripMargin
    logger.error(querySql)
    import spark.implicits._
    logger.error(">>>>>>>>>>>>>>>>>解析detail")
    val queryDF = spark.sql(querySql).rdd.map(obj => {
      val detail = obj.toString()
      var message = ("", "", "", "", "")
      val msg = try {
        JSON.parseObject(JSON.parseArray(detail).get(0).toString)
      } catch {
        case e: Exception => null
      }
      if (msg == null) {
        logger.error(">>>>>>>>>>>>>>>>>>msg is null<<<<<<<<<<<<<<<<")
      } else {
        var city_code = ""
        var address = ""
        var src = ""
        var tag = ""
        var wr_tag = ""
        try {
          city_code = msg.getString("city_code")
        } catch {
          case e: Exception => ""
        }
        try {
          address = msg.getString("address")
        } catch {
          case e: Exception => ""
        }
        try {
          src = msg.getString("src")
        } catch {
          case e: Exception => ""
        }
        try {
          tag = msg.getString("tag")
        } catch {
          case e: Exception => ""
        }
        try {
          wr_tag = msg.getString("wr_tag")
        } catch {
          case e: Exception => ""
        }
        message = (city_code, address, src, tag, wr_tag)
      }
      message
    }).map(msg => Logs(msg._1, msg._2, msg._3, msg._4, msg._5))
      .toDF().persist(StorageLevel.DISK_ONLY)
    queryDF.createOrReplaceTempView("tmp")
    queryDF.printSchema()
    queryDF.show(5)
    logger.error(s">>>获取test_kuaiyun_detail_di记录 ${queryDF.count()} 条s<<<")
    logger.error(sql)
    val mapDisLocationRDD = Util.getRowToJson(spark, sql, 100)
    logger.error(s">>>获取错柯记录 ${mapDisLocationRDD.count()} 条s<<<")
    mapDisLocationRDD
  }


  /**
   * 跑at派接口，获取对应大组id和网点zno_code
   *
   * @param mapDisLocationRDD
   * @return
   */
  def getMAPBDisLocationIdCode(mapDisLocationRDD: RDD[JSONObject]): RDD[(JSONObject, JSONObject)] = {
    val mapDisLocationIdCode = mapDisLocationRDD.map(obj => {
      val city_code = obj.getString("city_code")
      val address = obj.getString("address")
      var json: JSONObject = null
      val url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?city=%s&address=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh"
      json = getRunMapIdCode(url, city_code, address)
      (obj, json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取获取对应大组id和网点zno_code信息共 ${mapDisLocationIdCode.count()} 条s<<<")
    mapDisLocationRDD.unpersist()
    mapDisLocationIdCode
  }


  /**
   *
   * @param url
   * @param address
   * @param city_code
   * @return
   */
  def getRunMapIdCode(url: String, city_code: String, address: String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!city_code.isEmpty && !address.isEmpty) {
        val urls = String.format(url, URLEncoder.encode(city_code, "utf-8"), URLEncoder.encode(address, "utf-8"))
        val idCode = HttpClientUtil.getJsonByGet(urls)
        if (idCode != null && idCode.getJSONObject("result") != null) {
          if (idCode.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return getRunMapIdCode(url, city_code, address)
          }
          ret = new JSONObject()
          var groupId, dept = ""
          val result = idCode.getJSONObject("result")
          if (result != null) {
            if (result.getJSONArray("tcs") != null) {
              groupId = try {
                JSON.parseObject(result.getJSONArray("tcs").get(0).toString).getString("groupid")
              } catch {
                case e: Exception => ""
              }
              dept = try {
                JSON.parseObject(result.getJSONArray("tcs").get(0).toString).getString("dept")
              } catch {
                case e: Exception => ""
              }
            }
          }
          ret.put("id", groupId)
          ret.put("zno_code", dept)
          ret.put("result", result.getJSONArray("tcs").toJSONString)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  /**
   * 下发数据地址去重
   *
   * @param spark
   * @param
   */
  def getMisClassification(spark: SparkSession): RDD[JSONObject] = {
    val json = Util.getWeekend()
    val date01 = json.getString("date01")
    val date02 = json.getString("date02")
    val date03 = json.getString("date03")
    val date04 = json.getString("date04")
    logger.error(date01 + ">>>>" + date02 + ">>>>" + date03 + ">>>>" + date04)
    val sql =
      s"""
         |SELECT
         |	address
         |FROM dm_gis.cgcss_misclassification_data_shunt
         |WHERE operate_date = '$date01'
         |OR operate_date = '$date02'
         |OR operate_date = '$date03'
         |OR operate_date = '$date04'
         |GROUP BY address
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>getMisClassification: " + sql)
    val misClassification = Util.getRowToJson(spark, sql, 100)
    logger.error(s">>>下发数据地址排重 ${misClassification.count()} 条s<<<")
    misClassification
  }


  /**
   * mapbCuokeIDCode与misClassification进行关联
   *
   * @param mapDisLocationIdCode
   * @param misClassification
   */
  def getDisLocationJoin(spark: SparkSession, mapDisLocationIdCode: RDD[(JSONObject, JSONObject)], misClassification: RDD[JSONObject]): RDD[JSONObject] = {
    val joinSQL =
      s"""
         |SELECT
         |	 t1.city_code	AS city_code
         |	,t1.address	    AS t1_address
         |	,t1.id	        AS id
         |	,t1.zno_code	AS zno_code
         | ,t1.result     AS result
         |	,t2.address	    AS t2_address
         |FROM test_kuaiyun_detail_di_temp t1
         |LEFT JOIN
         |(SELECT * FROM cgcss_mis_data_shunt_temp WHERE address <> '' AND address != null) t2
         |on t1.address = t2.address
         |""".stripMargin
    val schemaString1 = "city_code,address,id,zno_code,result"
    val schemaString2 = "address,other"
    val fields1 = schemaString1.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))
    val fields2 = schemaString2.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))
    val schema1 = StructType(fields1)
    val schema2 = StructType(fields2)
    val rdd1 = mapDisLocationIdCode.map(obj => {
      val row = obj._1
      val json = obj._2
      val sb = new StringBuilder()
      sb.append(row.getString("city_code")).append("\t\t\t")
      sb.append(row.getString("address")).append("\t\t\t")
      if (json != null) {
        sb.append(json.getString("id")).append("\t\t\t")
        sb.append(json.getString("zno_code")).append("\t\t\t")
        sb.append(json.getString("result")).append("\t\t\t")
      } else {
        sb.append("").append("\t\t\t")
        sb.append("").append("\t\t\t")
        sb.append("").append("\t\t\t")
      }
      sb.toString()
    }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4)))
    val df1 = spark.createDataFrame(rdd1, schema1)
    df1.createOrReplaceTempView("test_kuaiyun_detail_di_temp")
    df1.printSchema()
    df1.show(5)
    val rdd2 = misClassification.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("address")).append("\t\t\t")
      sb.append("other").append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1)))
    val df2 = spark.createDataFrame(rdd2, schema2)
    df2.createOrReplaceTempView("cgcss_mis_data_shunt_temp")
    df2.printSchema()
    df2.show(5)
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>关联: " + joinSQL)
    val disLocJoinClassification = Util.getRowToJson(spark, joinSQL, 100)
    mapDisLocationIdCode.unpersist()
    misClassification.unpersist()
    spark.sql("drop table if exists test_kuaiyun_detail_di_temp")
    spark.sql("drop table if exists cgcss_mis_data_shunt_temp")
    disLocJoinClassification
  }


  /**
   * 将conditionJudgeResult中关联不上，并且address不包含快运的数据写入dm_gis.sxky_task_to_cgcs
   *
   * @param disLocJoinClassification
   */
  def conditionJudge(spark: SparkSession, disLocJoinClassification: RDD[JSONObject], parDay_4: String) = {
    val descDBName = "default"
    val descTableName = "sxky_task_to_cgcs_tmp"
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_4')
         |SELECT
         |	 city_code
         |	,zno_code
         |	,t1_address
         |  ,result
         |FROM join_cghs_result_data_tmp
         |WHERE (t2_address = '' OR t2_address = 'null' OR t2_address IS NULL)
         |AND t1_address NOT LIKE '%快运%'
         |""".stripMargin
    try {
      val schemaString = "city_code,t1_address,id,zno_code,result,t2_address"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))
      val schema = StructType(fields)
      val rdd = disLocJoinClassification.map(obj => {
        val sb = new StringBuilder()
        sb.append(obj.getString("city_code")).append("\t\t\t")
        sb.append(obj.getString("t1_address")).append("\t\t\t")
        sb.append(obj.getString("id")).append("\t\t\t")
        sb.append(obj.getString("zno_code")).append("\t\t\t")
        sb.append(obj.getString("result")).append("\t\t\t")
        sb.append(obj.getString("t2_address")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4), attr(5)))
      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("join_cghs_result_data_tmp")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive表: " + insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>入库成功")
      spark.sql("drop table if exists join_cghs_result_data_tmp")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }


  /**
   * 根据关联结果做不同处理
   *
   * @param cuokeJoinClassification
   */
  def conditionJudgeAOIID(spark: SparkSession, cuokeJoinClassification: RDD[JSONObject], parDay_1: String, parDay_3: String): RDD[JSONObject] = {
    val joinSQL =
      s"""
         |SELECT
         |	 city_code
         |    ,t1_address
         |    ,id
         |    ,zno_code
         |	,t2_address
         |	,check_aoi_id
         |FROM
         |(
         |	SELECT
         |		 t1.city_code	 AS city_code
         |		,t1.t1_address	 AS t1_address
         |		,t1.id	         AS id
         |		,t1.zno_code	 AS zno_code
         |		,t2.address	     AS t2_address
         |		,t2.check_aoi_id AS check_aoi_id
         |	FROM (SELECT * FROM join_cghs_result_data_tmp WHERE t2_address != '' AND t2_address != 'null' AND t2_address IS NOT NULL) t1
         |	LEFT JOIN
         |	(
         |  SELECT
         |	   address
         |	  ,check_aoi_id
         |  FROM
         |  (
         |    SELECT
         |	    address
         |	   ,check_aoi_id
         |	   ,row_number() over(order by address desc) as rn
         |    FROM dm_gis.cghs_result_data
         |    WHERE inc_day >= '$parDay_3'
         |    AND inc_day <= '$parDay_1'
         |   ) t
         |  WHERE t.rn = 1
         | ) t2
         |	ON t1.address = t2.address
         |) t
         |WHERE t.t2_address IS NOT NULL
         |""".stripMargin

    val schemaString = "city_code,t1_address,id,zno_code,t2_address"

    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))

    val schema = StructType(fields)

    val rdd = cuokeJoinClassification.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("city_code")).append("\t\t\t")
      sb.append(obj.getString("t1_address")).append("\t\t\t")
      sb.append(obj.getString("id")).append("\t\t\t")
      sb.append(obj.getString("zno_code")).append("\t\t\t")
      sb.append(obj.getString("t2_address")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4)))

    val df = spark.createDataFrame(rdd, schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("join_cghs_result_data_tmp")

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>关联: " + joinSQL)
    val cuokeJoinCghsResult = Util.getRowToJson(spark, joinSQL, 100)

    cuokeJoinCghsResult
  }


  /**
   *
   * @param mapb_url
   * @param check_aoi_id
   * @return
   */
  def getAOIidInterface(mapb_url: String, check_aoi_id: String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!check_aoi_id.isEmpty) {
        val url = String.format(mapb_url, URLEncoder.encode(check_aoi_id, "utf-8"))
        val idCode = HttpClientUtil.getJsonByGet(url)
        if (idCode != null && idCode.getJSONObject("result") != null) {
          if (idCode.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return getAOIidInterface(mapb_url, check_aoi_id)
          }
          ret = new JSONObject()
          var x, y = ""
          val result = idCode.getJSONObject("result")
          if (result != null) {
            if (result.getJSONArray("data") != null) {
              val central_coord = JSON.parseObject(result.getJSONArray("data").get(0).toString).getJSONObject("central_coord")

              if (central_coord != null) {
                x = central_coord.getString("x")
                y = central_coord.getString("y")
              }

            }
          }
          ret.put("x", x)
          ret.put("y", y)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  /**
   *
   * @param mapUrl
   * @param address
   * @param param
   * @param addrSource
   * @return
   */
  def PostRunMapXyInteface(mapUrl: String, address: String, param: JSONObject, addrSource: String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!address.isEmpty) {
        val httpData = HttpConnection.sendPost(mapUrl, param.toJSONString)

        if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {

          val content = httpData.get("content").toString
          val xyObj = JSON.parseObject(content)

          if (xyObj != null && xyObj.getJSONObject("result") != null) {

            if (xyObj.getJSONObject("result").getInteger("err") == 109) {
              val second = Calendar.getInstance().get(Calendar.SECOND)
              Thread.sleep(60 - second)
              return PostRunMapXyInteface(mapUrl, address, param, addrSource)
            }
            ret = new JSONObject()
            var status, x, y, x1, y1, precision = ""
            var temp: Double = 0.0
            val result = xyObj.getJSONObject("result")
            if (result != null) {
              if (result.getDouble("xcoord") != null) {
                temp = result.getDouble("xcoord")

              }
              if (result.getDouble("ycoord") != null) {
                temp = result.getDouble("ycoord")
              }
            }
            ret.put("x", x)
            ret.put("y", y)
            ret.put("x1", x1)
            ret.put("y1", y1)
            ret.put("addrSource", addrSource)
          }
        }

      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  /**
   * 调获取AOI中心点坐标接口获取对应坐标x,y
   *
   * @param cuokeJoinCghsResult
   * @return
   */
  def getAOIid(cuokeJoinCghsResult: RDD[JSONObject]): RDD[(JSONObject, JSONObject)] = {
    val AOIid = cuokeJoinCghsResult.map(obj => {
      val check_aoi_id = obj.getString("check_aoi_id")
      var json: JSONObject = null

      val mapb_url = "http://gis-apis.int.sfcloud.local:1080/dept2/zctc/aoiid&aoi_id=$s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=area"

      json = getAOIidInterface(mapb_url, check_aoi_id)

      (obj, json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取丰拓企业信息坐标信息共 ${AOIid.count()} 条s<<<")

    cuokeJoinCghsResult.unpersist()

    AOIid
  }


  /**
   * 按城市输出文件input.csv,放在指定服务器和路径
   *
   * @param spark
   * @param aoiID
   * @param parDay_4
   */
  def saveResult2CSV(spark: SparkSession, aoiID: RDD[(JSONObject, JSONObject)], parDay_4: String): Unit = {
    try {
      val schemaString = "id,x,y,city_code"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
      )
      val schema = StructType(fields)

      val rdd = aoiID.map(obj => {
        val row = obj._1
        val json = obj._2
        val sb = new StringBuilder()
        sb.append(row.getString("id")).append("\t\t\t")
        sb.append(row.getString("city_code") + "_" + parDay_4).append("\t\t\t")
        if (json != null) {
          sb.append(json.getString("x")).append("\t\t\t")
          sb.append(json.getString("y")).append("\t\t\t")
        } else {
          sb.append("null").append("\t\t\t")
          sb.append("null").append("\t\t\t")
        }
        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3)))

      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.show(5)

      df.write.mode("overwrite").partitionBy("city_code").format("com.databricks.spark.csv")
        .option("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")
        .option("header", "true")
      //.csv(outputPath)

    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }


  }

  /**
   *
   * @param spark
   * @param ftFirmDataXy
   */
  def saveResult(spark: SparkSession, ftFirmDataXy: RDD[(JSONObject, JSONObject)], parDay_1: String): Unit = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "fty_company_info"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT INTO TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |SELECT
         |	 fec_id
         |	,ty_id
         |	,company_name
         |	,reg_status
         |	,reg_capital
         |	,indu_one
         |	,indu_two
         |	,indu_three
         |	,estiblish_time
         |	,reg_addr
         |	,source_addrs
         |	,longtitude_6
         |	,latitude_6
         |	,longtitude_3
         |	,latitude_3
         |	,location_source
         |	,province
         |	,cityname
         |	,district
         |	,company_org_type
         |	,legal_person_name
         |	,city_code
         |FROM fty_company_info_temp
         |""".stripMargin

    try {
      val schemaString = "fec_id,ty_id,company_name,reg_status,reg_capital,indu_one,indu_two" +
        ",indu_three,estiblish_time,reg_addr,source_addrs,longtitude_6,latitude_6,longtitude_3" +
        ",latitude_3,location_source,city_code,province,cityname,district,company_org_type,legal_person_name"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
      )
      val schema = StructType(fields)

      val rdd = ftFirmDataXy.map(obj => {
        val row = obj._1
        val json = obj._2

        val sb = new StringBuilder()
        sb.append(row.getString("fec_id")).append("\t\t\t")
        sb.append(row.getString("ty_id")).append("\t\t\t")
        sb.append(row.getString("company_name")).append("\t\t\t")
        sb.append(row.getString("reg_status")).append("\t\t\t")
        sb.append(row.getString("reg_capital")).append("\t\t\t")
        sb.append(row.getString("indu_one")).append("\t\t\t")
        sb.append(row.getString("indu_two")).append("\t\t\t")
        sb.append(row.getString("indu_three")).append("\t\t\t")
        sb.append(row.getString("estiblish_time")).append("\t\t\t")
        sb.append(row.getString("reg_addr")).append("\t\t\t")
        sb.append(row.getString("source_addrs")).append("\t\t\t")
        if (json != null) {
          sb.append(json.getString("x")).append("\t\t\t")
          sb.append(json.getString("y")).append("\t\t\t")
          sb.append(json.getString("x1")).append("\t\t\t")
          sb.append(json.getString("y1")).append("\t\t\t")
          sb.append(json.getString("addrSource")).append("\t\t\t")
          sb.append(json.getString("regcode")).append("\t\t\t")
        } else {
          sb.append("null").append("\t\t\t")
          sb.append("null").append("\t\t\t")
          sb.append("null").append("\t\t\t")
          sb.append("null").append("\t\t\t")
          sb.append("null").append("\t\t\t")
          sb.append("null").append("\t\t\t")
        }
        sb.append(row.getString("province")).append("\t\t\t")
        sb.append(row.getString("cityname")).append("\t\t\t")
        sb.append(row.getString("district")).append("\t\t\t")
        sb.append(row.getString("company_org_type")).append("\t\t\t")
        sb.append(row.getString("legal_person_name")).append("\t\t\t")

        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4)
        , attr(5), attr(6), attr(7), attr(8), attr(9), attr(10), attr(11), attr(12), attr(13), attr(14), attr(15)
        , attr(16), attr(17), attr(18), attr(19), attr(20), attr(21)))

      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("fty_company_info_temp")

      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: " + insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }

  case class Logs(city_code: String, address: String, src: String, tag: String, wr_tag: String)

}
