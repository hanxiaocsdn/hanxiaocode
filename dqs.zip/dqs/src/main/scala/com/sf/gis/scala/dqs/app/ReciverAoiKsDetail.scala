package com.sf.gis.scala.dqs.app

import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * 收件识别量统计报表
 * 任务id: 383757
 */

object ReciverAoiKsDetail {
  @transient lazy val logger: Logger = Logger.getLogger(ReciverAoiKsDetail.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val incDay = args(0)
    val tmp = spark.sql(
      s"""
         |select a.*,
         |  b.region region,
         |  b.area area
         |from dm_gis.gis_rds_omsfrom a
         |left join
         |(
         |select
         |	 region
         |	,area
         |	,citycode
         |from
         |dm_gis.address_info_map_di
         |group by
         |	 region
         |	,area
         |	,citycode
         |) b
         |on a.citycode = b.citycode
         |where a.inc_day = $incDay
      """.stripMargin).persist(StorageLevel.DISK_ONLY)
    tmp.createOrReplaceTempView("gis_rds_omsfrom_tmp")
    tmp.show(5)

    val dr = "$"
    //按日期统计
    val allDetailDF = spark.sql(
      """
        |select
        |  'ALL' stat_type,
        |  'ALL' stat_type_content,
        |  'ALL' area,
        |  'ALL' region,
        |  'ALL' city,
        |  'ALL' city_code,
        |  'ALL' dept_code,
        |  t2.req_count req_count,
        |  t2.amount amount,
        |  if(t2.isNotUnderCall='1','NO','YES') isNotUnderCall,
        |  max(case when t2.ks_aoi_src = 'company' then t2.c2 else 0 end) company,
        |  max(case when t2.ks_aoi_src = 'standard' then t2.c2 else 0 end) standard,
        |  max(case when t2.ks_aoi_src = 'N1' then t2.c2 else 0 end) N1,
        |  max(case when t2.ks_aoi_src = 'N2' then t2.c2 else 0 end) N2,
        |  max(case when t2.ks_aoi_src = 'N3' then t2.c2 else 0 end) N3,
        |  max(case when t2.ks_aoi_src = 'N4' then t2.c2 else 0 end) N4,
        |  max(case when t2.ks_aoi_src = 'N5' then t2.c2 else 0 end) N5,
        |  max(case when t2.ks_aoi_src = 'Y1' then t2.c2 else 0 end) Y1,
        |  max(case when t2.ks_aoi_src = 'Y2' then t2.c2 else 0 end) Y2,
        |  max(case when t2.ks_aoi_src = 'Y3' then t2.c2 else 0 end) Y3,
        |  max(case when t2.ks_aoi_src = 'Y4' then t2.c2 else 0 end) Y4,
        |  max(case when t2.ks_aoi_src = 'Y5' then t2.c2 else 0 end) Y5,
        |  max(case when t2.ks_aoi_src = 'Vil_WH' then t2.c2 else 0 end) Vil_WH,
        |  max(case when t2.ks_aoi_src = 'tcModel' then t2.c2 else 0 end) tcModel,
        |  max(case when t2.ks_aoi_src = 'tel_His' then t2.c2 else 0 end) tel_His,
        |  max(case when t2.ks_aoi_src = 'gd_poi' then t2.c2 else 0 end) gd_poi,
        |  max(case when t2.ks_aoi_src = 'aoi_name' then t2.c2 else 0 end) aoi_name,
        |  max(case when t2.ks_aoi_src = 'aoi_80_recent' then t2.c2 else 0 end) aoi_80_recent,
        |  max(case when t2.ks_aoi_src = 'aoi_80_similar_rate' then t2.c2 else 0 end) aoi_80_similar_rate,
        |  max(case when t2.ks_aoi_src is null then t2.c2 else 0 end) Other,
        |  max(case when t2.ks_aoi_src = 'aoi_80_similar_unique' then t2.c2 else 0 end) aoi_80_similar_unique,
        |  max(case when t2.ks_aoi_src = 'vil_s1wh' then t2.c2 else 0 end) vil_s1wh,
        |  max(case when t2.ks_aoi_src = 'vil_s1sz' then t2.c2 else 0 end) vil_s1sz,
        |  max(case when t2.ks_aoi_src = '80_address_y' then t2.c2 else 0 end) 80_address_y,
        |  max(case when t2.ks_aoi_src = 'vil_s2wh' then t2.c2 else 0 end) vil_s2wh,
        |  max(case when t2.ks_aoi_src = 'ks12_telrecent_gd' then t2.c2 else 0 end) ks12_telrecent_gd,
        |  max(case when t2.ks_aoi_src = 'ks12_telsimilar_gd' then t2.c2 else 0 end) ks12_telsimilar_gd,
        |  max(case when t2.ks_aoi_src = '80_address_n' then t2.c2 else 0 end) 80_address_n,
        |  t2.month_acc_cnt month_acc_cnt,
        |  t2.zc_model_cnt zc_model_cnt,
        |  max(case when t2.ks_aoi_src = 'translate' then t2.c2 else 0 end) as translates
        |from (
        |  select
        |  t1.inc_day inc_day,
        |  t1.isNotUnderCall isNotUnderCall,
        |  t1.ks_aoi_src ks_aoi_src,
        |  t1.c1 c2,
        |  sum(t1.c1) over(partition by inc_day,isNotUnderCall) amount,
        |  t1.req_count req_count,
        |  t1.month_acc_cnt month_acc_cnt,
        |  t1.zc_model_cnt zc_model_cnt
        |  from (
        |    select
        |	    t0.inc_day inc_day,
        |	    t0.isNotUnderCall isNotUnderCall,
        |	    get_json_object(t0.chkksrebody, '$.result.aoiTag') ks_aoi_src,
        |      count(1) c1,
        |      t0.req_count req_count,
        |      t0.month_acc_cnt month_acc_cnt,
        |	  t0.zc_model_cnt zc_model_cnt
        |    from(
        |	  select
        |	    a.inc_day,
        |	    a.isNotUnderCall,
        |	    a.chkksrebody,
        |	    a.chkomsaoi,
        |		b.cnt req_count,
        |  c.month_acc_cnt month_acc_cnt,
        |  d.zc_model_cnt zc_model_cnt
        |	  from
        |	   gis_rds_omsfrom_tmp a
        |	   left join
        |	   (
        |		select
        |			count(distinct sysorderno) as cnt
        |			,isNotUnderCall
        |		from gis_rds_omsfrom_tmp
        |		group by isNotUnderCall
        |	   ) b
        |	   on a.isNotUnderCall = b.isNotUnderCall
        |    left join
        |	   (
        |		select
        |			count(1) as month_acc_cnt
        |			,isNotUnderCall
        |		from gis_rds_omsfrom_tmp where aoisrc='monthAcc'
        |		group by isNotUnderCall
        |	   ) c
        |	   on a.isNotUnderCall = c.isNotUnderCall
        |    left join
        |	   (
        |		select
        |			count(1) as zc_model_cnt
        |			,isNotUnderCall
        |		from gis_rds_omsfrom_tmp
        |		where chkomsaoi != ''
        |		and get_json_object(chkksrebody, "$.result.zcTag") = 'zcModel'
        |		and get_json_object(chkksrebody, "$.result.aoiTag") != ''
        |		group by isNotUnderCall
        |	   ) d
        |	   on a.isNotUnderCall = d.isNotUnderCall
        |	   ) t0
        |    where t0.chkomsaoi != '' and get_json_object(t0.chkksrebody, "$.result.zcTag") != 'zcModel'
        |    group by t0.inc_day,t0.isNotUnderCall,get_json_object(t0.chkksrebody, '$.result.aoiTag'),req_count,month_acc_cnt,zc_model_cnt
        |    ) t1
        |  ) t2
        |group by inc_day,req_count,amount,month_acc_cnt,zc_model_cnt,if(t2.isNotUnderCall='1','NO','YES')
      """.stripMargin).persist(StorageLevel.DISK_ONLY)
    allDetailDF.show(2)

    //按地区维度统计
    val areaDetailDF = spark.sql(
      s"""
         |select
         |  'AREA' stat_type,
         |  t2.area stat_type_content,
         |  t2.area area,
         |  'ALL' region,
         |  'ALL' city,
         |  'ALL' city_code,
         |  'ALL' dept_code,
         |  t2.req_count req_count,
         |  t2.amount amount,
         |  if(t2.isNotUnderCall='1','NO','YES') isNotUnderCall,
         |  max(case when t2.ks_aoi_src = 'company' then t2.c2 else 0 end) company,
         |  max(case when t2.ks_aoi_src = 'standard' then t2.c2 else 0 end) standard,
         |  max(case when t2.ks_aoi_src = 'N1' then t2.c2 else 0 end) N1,
         |  max(case when t2.ks_aoi_src = 'N2' then t2.c2 else 0 end) N2,
         |  max(case when t2.ks_aoi_src = 'N3' then t2.c2 else 0 end) N3,
         |  max(case when t2.ks_aoi_src = 'N4' then t2.c2 else 0 end) N4,
         |  max(case when t2.ks_aoi_src = 'N5' then t2.c2 else 0 end) N5,
         |  max(case when t2.ks_aoi_src = 'Y1' then t2.c2 else 0 end) Y1,
         |  max(case when t2.ks_aoi_src = 'Y2' then t2.c2 else 0 end) Y2,
         |  max(case when t2.ks_aoi_src = 'Y3' then t2.c2 else 0 end) Y3,
         |  max(case when t2.ks_aoi_src = 'Y4' then t2.c2 else 0 end) Y4,
         |  max(case when t2.ks_aoi_src = 'Y5' then t2.c2 else 0 end) Y5,
         |  max(case when t2.ks_aoi_src = 'Vil_WH' then t2.c2 else 0 end) Vil_WH,
         |  max(case when t2.ks_aoi_src = 'tcModel' then t2.c2 else 0 end) tcModel,
         |  max(case when t2.ks_aoi_src = 'tel_His' then t2.c2 else 0 end) tel_His,
         |  max(case when t2.ks_aoi_src = 'gd_poi' then t2.c2 else 0 end) gd_poi,
         |  max(case when t2.ks_aoi_src = 'aoi_name' then t2.c2 else 0 end) aoi_name,
         |  max(case when t2.ks_aoi_src = 'aoi_80_recent' then t2.c2 else 0 end) aoi_80_recent,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_rate' then t2.c2 else 0 end) aoi_80_similar_rate,
         |  max(case when t2.ks_aoi_src is null then t2.c2 else 0 end) Other,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_unique' then t2.c2 else 0 end) aoi_80_similar_unique,
         |  max(case when t2.ks_aoi_src = 'vil_s1wh' then t2.c2 else 0 end) vil_s1wh,
         |  max(case when t2.ks_aoi_src = 'vil_s1sz' then t2.c2 else 0 end) vil_s1sz,
         |  max(case when t2.ks_aoi_src = '80_address_y' then t2.c2 else 0 end) 80_address_y,
         |  max(case when t2.ks_aoi_src = 'vil_s2wh' then t2.c2 else 0 end) vil_s2wh,
         |  max(case when t2.ks_aoi_src = 'ks12_telrecent_gd' then t2.c2 else 0 end) ks12_telrecent_gd,
         |  max(case when t2.ks_aoi_src = 'ks12_telsimilar_gd' then t2.c2 else 0 end) ks12_telsimilar_gd,
         |  max(case when t2.ks_aoi_src = '80_address_n' then t2.c2 else 0 end) 80_address_n,
         |  t2.month_acc_cnt month_acc_cnt,
         |  t2.zc_model_cnt zc_model_cnt,
         |  max(case when t2.ks_aoi_src = 'translate' then t2.c2 else 0 end) as translates
         |from (
         |  select
         |  t1.inc_day inc_day,
         |  t1.area area,
         |  t1.isNotUnderCall isNotUnderCall,
         |  t1.ks_aoi_src ks_aoi_src,
         |  t1.c1 c2,
         |  sum(t1.c1) over(partition by isNotUnderCall,area) amount,
         |  t1.req_count req_count,
         |  t1.month_acc_cnt month_acc_cnt,
         |  t1.zc_model_cnt zc_model_cnt
         |  from (
         |    select
         |	  t0.inc_day inc_day,
         |	  t0.area area,
         |	  t0.isNotUnderCall isNotUnderCall,
         |	  get_json_object(t0.chkksrebody, '$dr.result.aoiTag') ks_aoi_src,
         |      t0.req_count req_count,
         |	  count(1)  c1,
         |   t0.month_acc_cnt month_acc_cnt,
         |   t0.zc_model_cnt zc_model_cnt
         |   from(
         |	  select
         |	    a.inc_day ,
         |		a.area,
         |	    a.isNotUnderCall,
         |		a.chkksrebody,
         |	    a.chkomsaoi,
         |	    b.cnt req_count,
         |     c.month_acc_cnt month_acc_cnt,
         |     d.zc_model_cnt zc_model_cnt
         |	  from gis_rds_omsfrom_tmp a
         |	  left join
         |	  (
         |		select
         |			count(distinct sysorderno) as cnt
         |			,isNotUnderCall
         |			,area
         |		from gis_rds_omsfrom_tmp
         |		group by isNotUnderCall,area
         |	   ) b
         |	   on a.isNotUnderCall = b.isNotUnderCall and a.area = b.area
         |    left join
         |	   (
         |		select
         |			count(1) as month_acc_cnt
         |			,isNotUnderCall
         |   ,area
         |		from gis_rds_omsfrom_tmp where aoisrc='monthAcc'
         |		group by isNotUnderCall,area
         |	   ) c
         |	   on a.isNotUnderCall = c.isNotUnderCall and a.area = c.area
         |    left join
         |	   (
         |		select
         |			count(1) as zc_model_cnt
         |			,isNotUnderCall
         |   ,area
         |		from gis_rds_omsfrom_tmp
         |		where chkomsaoi != ''
         |		and get_json_object(chkksrebody, "$dr.result.zcTag") = 'zcModel'
         |		and get_json_object(chkksrebody, "$dr.result.aoiTag") != ''
         |		group by isNotUnderCall,area
         |	   ) d
         |	   on a.isNotUnderCall = d.isNotUnderCall and a.area = d.area
         |) t0
         |    where t0.chkomsaoi != '' and get_json_object(t0.chkksrebody, "$dr.result.zcTag") != 'zcModel'
         |    group by t0.inc_day,t0.area,t0.isNotUnderCall,get_json_object(t0.chkksrebody, '$dr.result.aoiTag'),t0.req_count,month_acc_cnt,zc_model_cnt
         |    ) t1
         |  ) t2
         |group by t2.area,t2.req_count,t2.amount,month_acc_cnt,zc_model_cnt,if(t2.isNotUnderCall='1','NO','YES')
      """.stripMargin).persist(StorageLevel.DISK_ONLY)
    areaDetailDF.show(5)

    //按大区维度统计
    val regionDetailDF = spark.sql(
      s"""
         |select
         |  'REGION' stat_type,
         |  t2.region stat_type_content,
         |  t2.area area,
         |  t2.region region,
         |  'ALL' city,
         |  'ALL' city_code,
         |  'ALL' dept_code,
         |  t2.req_count req_count,
         |  t2.amount amount,
         |  if(t2.isNotUnderCall='1','NO','YES') isNotUnderCall,
         |  max(case when t2.ks_aoi_src = 'company' then t2.c2 else 0 end) company,
         |  max(case when t2.ks_aoi_src = 'standard' then t2.c2 else 0 end) standard,
         |  max(case when t2.ks_aoi_src = 'N1' then t2.c2 else 0 end) N1,
         |  max(case when t2.ks_aoi_src = 'N2' then t2.c2 else 0 end) N2,
         |  max(case when t2.ks_aoi_src = 'N3' then t2.c2 else 0 end) N3,
         |  max(case when t2.ks_aoi_src = 'N4' then t2.c2 else 0 end) N4,
         |  max(case when t2.ks_aoi_src = 'N5' then t2.c2 else 0 end) N5,
         |  max(case when t2.ks_aoi_src = 'Y1' then t2.c2 else 0 end) Y1,
         |  max(case when t2.ks_aoi_src = 'Y2' then t2.c2 else 0 end) Y2,
         |  max(case when t2.ks_aoi_src = 'Y3' then t2.c2 else 0 end) Y3,
         |  max(case when t2.ks_aoi_src = 'Y4' then t2.c2 else 0 end) Y4,
         |  max(case when t2.ks_aoi_src = 'Y5' then t2.c2 else 0 end) Y5,
         |  max(case when t2.ks_aoi_src = 'Vil_WH' then t2.c2 else 0 end) Vil_WH,
         |  max(case when t2.ks_aoi_src = 'tcModel' then t2.c2 else 0 end) tcModel,
         |  max(case when t2.ks_aoi_src = 'tel_His' then t2.c2 else 0 end) tel_His,
         |  max(case when t2.ks_aoi_src = 'gd_poi' then t2.c2 else 0 end) gd_poi,
         |  max(case when t2.ks_aoi_src = 'aoi_name' then t2.c2 else 0 end) aoi_name,
         |  max(case when t2.ks_aoi_src = 'aoi_80_recent' then t2.c2 else 0 end) aoi_80_recent,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_rate' then t2.c2 else 0 end) aoi_80_similar_rate,
         |  max(case when t2.ks_aoi_src is null then t2.c2 else 0 end) Other,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_unique' then t2.c2 else 0 end) aoi_80_similar_unique,
         |  max(case when t2.ks_aoi_src = 'vil_s1wh' then t2.c2 else 0 end) vil_s1wh,
         |  max(case when t2.ks_aoi_src = 'vil_s1sz' then t2.c2 else 0 end) vil_s1sz,
         |  max(case when t2.ks_aoi_src = '80_address_y' then t2.c2 else 0 end) 80_address_y,
         |  max(case when t2.ks_aoi_src = 'vil_s2wh' then t2.c2 else 0 end) vil_s2wh,
         |  max(case when t2.ks_aoi_src = 'ks12_telrecent_gd' then t2.c2 else 0 end) ks12_telrecent_gd,
         |  max(case when t2.ks_aoi_src = 'ks12_telsimilar_gd' then t2.c2 else 0 end) ks12_telsimilar_gd,
         |  max(case when t2.ks_aoi_src = '80_address_n' then t2.c2 else 0 end) 80_address_n,
         |  t2.month_acc_cnt month_acc_cnt,
         |  t2.zc_model_cnt zc_model_cnt,
         |  max(case when t2.ks_aoi_src = 'translate' then t2.c2 else 0 end) as translates
         |from (
         |  select
         |  t1.inc_day inc_day,
         |  t1.area area,
         |  t1.region region,
         |  t1.isNotUnderCall isNotUnderCall,
         |  t1.ks_aoi_src ks_aoi_src,
         |  t1.c1 c2,
         |  sum(t1.c1) over(partition by isNotUnderCall,region) amount,
         |  t1.req_count req_count,
         |  t1.month_acc_cnt month_acc_cnt,
         |  t1.zc_model_cnt zc_model_cnt
         |  from (
         |    select
         |	  t0.inc_day inc_day,
         |	  t0.area area,
         |	  t0.region region,
         |	  t0.isNotUnderCall isNotUnderCall,
         |	  get_json_object(t0.chkksrebody, '$dr.result.aoiTag') ks_aoi_src,
         |      t0.req_count req_count,
         |	  count(1)  c1,
         |   t0.month_acc_cnt month_acc_cnt,
         |	  t0.zc_model_cnt zc_model_cnt
         |    from(
         |	  select
         |	    a.inc_day,
         |		a.region,
         |		a.area,
         |	    a.isNotUnderCall,
         |		a.chkksrebody,
         |	    a.chkomsaoi,
         |	    b.cnt req_count,
         |     c.month_acc_cnt month_acc_cnt,
         |  d.zc_model_cnt zc_model_cnt
         |	  from
         |	   gis_rds_omsfrom_tmp a
         |	  left join
         |	  (
         |		select
         |			count(distinct sysorderno) as cnt
         |			,isNotUnderCall
         |			,region
         |		from gis_rds_omsfrom_tmp
         |		group by isNotUnderCall,region
         |	   ) b
         |	   on a.isNotUnderCall = b.isNotUnderCall and a.region = b.region
         |    left join
         |	   (
         |		select
         |			count(1) as month_acc_cnt
         |			,isNotUnderCall
         |   ,region
         |		from gis_rds_omsfrom_tmp where aoisrc='monthAcc'
         |		group by isNotUnderCall,region
         |	   ) c
         |	   on a.isNotUnderCall = c.isNotUnderCall and a.region = c.region
         |    left join
         |	   (
         |		select
         |			count(1) as zc_model_cnt
         |			,isNotUnderCall
         |   ,region
         |		from gis_rds_omsfrom_tmp
         |		where chkomsaoi != ''
         |		and get_json_object(chkksrebody, "$dr.result.zcTag") = 'zcModel'
         |		and get_json_object(chkksrebody, "$dr.result.aoiTag") != ''
         |		group by isNotUnderCall,region
         |	   ) d
         |	   on a.isNotUnderCall = d.isNotUnderCall and a.region = d.region
         |	   ) t0
         |    where t0.chkomsaoi != '' and get_json_object(t0.chkksrebody, "$dr.result.zcTag") != 'zcModel'
         |    group by t0.inc_day,t0.area,t0.region,t0.isNotUnderCall,get_json_object(t0.chkksrebody, '$dr.result.aoiTag'),t0.req_count,month_acc_cnt,zc_model_cnt
         |    ) t1
         |  ) t2
         |group by t2.area,t2.region,t2.req_count,t2.amount,month_acc_cnt,zc_model_cnt,if(t2.isNotUnderCall='1','NO','YES')
      """.stripMargin).persist(StorageLevel.DISK_ONLY)
    regionDetailDF.show(5)

    //按城市维度统计
    val cityDetailDF = spark.sql(
      s"""
         |select
         |  'CITY' stat_type,
         |  t2.city stat_type_content,
         |  t2.area area,
         |  t2.region region,
         |  t2.city city,
         |  t2.citycode city_code,
         |  'ALL' dept_code,
         |  t2.req_count req_count,
         |  t2.amount amount,
         |  if(t2.isNotUnderCall='1','NO','YES') isNotUnderCall,
         |  max(case when t2.ks_aoi_src = 'company' then t2.c2 else 0 end) company,
         |  max(case when t2.ks_aoi_src = 'standard' then t2.c2 else 0 end) standard,
         |  max(case when t2.ks_aoi_src = 'N1' then t2.c2 else 0 end) N1,
         |  max(case when t2.ks_aoi_src = 'N2' then t2.c2 else 0 end) N2,
         |  max(case when t2.ks_aoi_src = 'N3' then t2.c2 else 0 end) N3,
         |  max(case when t2.ks_aoi_src = 'N4' then t2.c2 else 0 end) N4,
         |  max(case when t2.ks_aoi_src = 'N5' then t2.c2 else 0 end) N5,
         |  max(case when t2.ks_aoi_src = 'Y1' then t2.c2 else 0 end) Y1,
         |  max(case when t2.ks_aoi_src = 'Y2' then t2.c2 else 0 end) Y2,
         |  max(case when t2.ks_aoi_src = 'Y3' then t2.c2 else 0 end) Y3,
         |  max(case when t2.ks_aoi_src = 'Y4' then t2.c2 else 0 end) Y4,
         |  max(case when t2.ks_aoi_src = 'Y5' then t2.c2 else 0 end) Y5,
         |  max(case when t2.ks_aoi_src = 'Vil_WH' then t2.c2 else 0 end) Vil_WH,
         |  max(case when t2.ks_aoi_src = 'tcModel' then t2.c2 else 0 end) tcModel,
         |  max(case when t2.ks_aoi_src = 'tel_His' then t2.c2 else 0 end) tel_His,
         |  max(case when t2.ks_aoi_src = 'gd_poi' then t2.c2 else 0 end) gd_poi,
         |  max(case when t2.ks_aoi_src = 'aoi_name' then t2.c2 else 0 end) aoi_name,
         |  max(case when t2.ks_aoi_src = 'aoi_80_recent' then t2.c2 else 0 end) aoi_80_recent,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_rate' then t2.c2 else 0 end) aoi_80_similar_rate,
         |  max(case when t2.ks_aoi_src is null then t2.c2 else 0 end) Other,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_unique' then t2.c2 else 0 end) aoi_80_similar_unique,
         |  max(case when t2.ks_aoi_src = 'vil_s1wh' then t2.c2 else 0 end) vil_s1wh,
         |  max(case when t2.ks_aoi_src = 'vil_s1sz' then t2.c2 else 0 end) vil_s1sz,
         |  max(case when t2.ks_aoi_src = '80_address_y' then t2.c2 else 0 end) 80_address_y,
         |  max(case when t2.ks_aoi_src = 'vil_s2wh' then t2.c2 else 0 end) vil_s2wh,
         |  max(case when t2.ks_aoi_src = 'ks12_telrecent_gd' then t2.c2 else 0 end) ks12_telrecent_gd,
         |  max(case when t2.ks_aoi_src = 'ks12_telsimilar_gd' then t2.c2 else 0 end) ks12_telsimilar_gd,
         |  max(case when t2.ks_aoi_src = '80_address_n' then t2.c2 else 0 end) 80_address_n,
         |  t2.month_acc_cnt month_acc_cnt,
         |  t2.zc_model_cnt zc_model_cnt,
         |  max(case when t2.ks_aoi_src = 'translate' then t2.c2 else 0 end) as translates
         |from (
         |  select
         |  t1.inc_day inc_day,
         |  t1.area area,
         |  t1.region region,
         |  t1.city city,
         |  t1.citycode citycode,
         |  t1.isNotUnderCall isNotUnderCall,
         |  t1.ks_aoi_src ks_aoi_src,
         |  t1.c1 c2,
         |  sum(t1.c1) over(partition by isNotUnderCall,city) amount,
         |  t1.req_count req_count,
         |  t1.month_acc_cnt month_acc_cnt,
         |  t1.zc_model_cnt zc_model_cnt
         |  from (
         |    select
         |	    t0.inc_day inc_day,
         |	    t0.area area,
         |	    t0.region region,
         |	    t0.city city,
         |		t0.citycode citycode,
         |	    t0.isNotUnderCall isNotUnderCall,
         |	    get_json_object(t0.chkksrebody, '$dr.result.aoiTag') ks_aoi_src,
         |     t0.req_count req_count,
         |	    count(1) c1,
         |     t0.month_acc_cnt month_acc_cnt,
         |	  t0.zc_model_cnt zc_model_cnt
         |   from(select
         |	    a.inc_day,
         |		a.region,
         |		a.area,
         |		a.city,
         |    a.citycode,
         |	    a.isNotUnderCall,
         |		a.chkksrebody,
         |	    a.chkomsaoi,
         |	    b.cnt req_count,
         |     c.month_acc_cnt month_acc_cnt,
         |  d.zc_model_cnt zc_model_cnt
         |	  from
         |	   gis_rds_omsfrom_tmp a
         |	  left join
         |	  (
         |		select
         |			count(distinct sysorderno) as cnt
         |			,isNotUnderCall
         |			,city
         |		from gis_rds_omsfrom_tmp
         |		group by isNotUnderCall,city
         |	   ) b
         |	   on a.isNotUnderCall = b.isNotUnderCall and a.city = b.city
         |    left join
         |	   (
         |		select
         |			count(1) as month_acc_cnt
         |			,isNotUnderCall
         |   ,city
         |		from gis_rds_omsfrom_tmp where aoisrc='monthAcc'
         |		group by isNotUnderCall,city
         |	   ) c
         |	   on a.isNotUnderCall = c.isNotUnderCall and a.city = c.city
         |    left join
         |	   (
         |		select
         |			count(1) as zc_model_cnt
         |			,isNotUnderCall
         |   ,city
         |		from gis_rds_omsfrom_tmp
         |		where chkomsaoi != ''
         |		and get_json_object(chkksrebody, "$dr.result.zcTag") = 'zcModel'
         |		and get_json_object(chkksrebody, "$dr.result.aoiTag") != ''
         |		group by isNotUnderCall,city
         |	   ) d
         |	   on a.isNotUnderCall = d.isNotUnderCall and a.city = d.city
         |    ) t0
         |    where t0.chkomsaoi != '' and get_json_object(t0.chkksrebody, "$dr.result.zcTag") != 'zcModel'
         |    group by t0.inc_day,t0.area,t0.region,t0.city,t0.citycode,t0.isNotUnderCall,get_json_object(t0.chkksrebody, '$dr.result.aoiTag'),t0.req_count,month_acc_cnt,zc_model_cnt
         |    ) t1
         |  ) t2
         |group by t2.area,t2.region,t2.city,t2.citycode,t2.req_count,t2.amount,month_acc_cnt,zc_model_cnt,if(t2.isNotUnderCall='1','NO','YES')
      """.stripMargin).persist(StorageLevel.DISK_ONLY)
    cityDetailDF.show(5)

    //按网点维度统计
    val deptDetailDF = spark.sql(
      s"""
         |select
         |  'ZC' stat_type,
         |  t2.deptcode stat_type_content,
         |  t2.area area,
         |  t2.region region,
         |  t2.city city,
         |  t2.citycode city_code,
         |  t2.deptcode dept_code,
         |  t2.req_count req_count,
         |  t2.amount amount,
         |  if(t2.isNotUnderCall='1','NO','YES') isNotUnderCall,
         |  max(case when t2.ks_aoi_src = 'company' then t2.c2 else 0 end) company,
         |  max(case when t2.ks_aoi_src = 'standard' then t2.c2 else 0 end) standard,
         |  max(case when t2.ks_aoi_src = 'N1' then t2.c2 else 0 end) N1,
         |  max(case when t2.ks_aoi_src = 'N2' then t2.c2 else 0 end) N2,
         |  max(case when t2.ks_aoi_src = 'N3' then t2.c2 else 0 end) N3,
         |  max(case when t2.ks_aoi_src = 'N4' then t2.c2 else 0 end) N4,
         |  max(case when t2.ks_aoi_src = 'N5' then t2.c2 else 0 end) N5,
         |  max(case when t2.ks_aoi_src = 'Y1' then t2.c2 else 0 end) Y1,
         |  max(case when t2.ks_aoi_src = 'Y2' then t2.c2 else 0 end) Y2,
         |  max(case when t2.ks_aoi_src = 'Y3' then t2.c2 else 0 end) Y3,
         |  max(case when t2.ks_aoi_src = 'Y4' then t2.c2 else 0 end) Y4,
         |  max(case when t2.ks_aoi_src = 'Y5' then t2.c2 else 0 end) Y5,
         |  max(case when t2.ks_aoi_src = 'Vil_WH' then t2.c2 else 0 end) Vil_WH,
         |  max(case when t2.ks_aoi_src = 'tcModel' then t2.c2 else 0 end) tcModel,
         |  max(case when t2.ks_aoi_src = 'tel_His' then t2.c2 else 0 end) tel_His,
         |  max(case when t2.ks_aoi_src = 'gd_poi' then t2.c2 else 0 end) gd_poi,
         |  max(case when t2.ks_aoi_src = 'aoi_name' then t2.c2 else 0 end) aoi_name,
         |  max(case when t2.ks_aoi_src = 'aoi_80_recent' then t2.c2 else 0 end) aoi_80_recent,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_rate' then t2.c2 else 0 end) aoi_80_similar_rate,
         |  max(case when t2.ks_aoi_src is null then t2.c2 else 0 end) Other,
         |  max(case when t2.ks_aoi_src = 'aoi_80_similar_unique' then t2.c2 else 0 end) aoi_80_similar_unique,
         |  max(case when t2.ks_aoi_src = 'vil_s1wh' then t2.c2 else 0 end) vil_s1wh,
         |  max(case when t2.ks_aoi_src = 'vil_s1sz' then t2.c2 else 0 end) vil_s1sz,
         |  max(case when t2.ks_aoi_src = '80_address_y' then t2.c2 else 0 end) 80_address_y,
         |  max(case when t2.ks_aoi_src = 'vil_s2wh' then t2.c2 else 0 end) vil_s2wh,
         |  max(case when t2.ks_aoi_src = 'ks12_telrecent_gd' then t2.c2 else 0 end) ks12_telrecent_gd,
         |  max(case when t2.ks_aoi_src = 'ks12_telsimilar_gd' then t2.c2 else 0 end) ks12_telsimilar_gd,
         |  max(case when t2.ks_aoi_src = '80_address_n' then t2.c2 else 0 end) 80_address_n,
         |  t2.month_acc_cnt month_acc_cnt,
         |  t2.zc_model_cnt zc_model_cnt,
         |  max(case when t2.ks_aoi_src = 'translate' then t2.c2 else 0 end) as translates
         |from (
         |  select
         |  t1.inc_day inc_day,
         |  t1.area area,
         |  t1.region region,
         |  t1.city city,
         |  t1.citycode citycode,
         |  t1.deptcode deptcode,
         |  t1.isNotUnderCall isNotUnderCall,
         |  t1.ks_aoi_src ks_aoi_src,
         |  t1.c1 c2,
         |  sum(t1.c1) over(partition by isNotUnderCall,deptcode) amount,
         |  t1.req_count req_count,
         |  t1.month_acc_cnt month_acc_cnt,
         |  t1.zc_model_cnt zc_model_cnt
         |  from (
         |    select
         |	    t0.inc_day inc_day,
         |	    t0.area area,
         |	    t0.region region,
         |	    t0.city city,
         |     t0.citycode citycode,
         |		t0.deptcode deptcode,
         |	    t0.isNotUnderCall isNotUnderCall,
         |	    get_json_object(t0.chkksrebody, '$dr.result.aoiTag') ks_aoi_src,
         |     t0.req_count req_count,
         |	    count(1) c1,
         |     t0.month_acc_cnt month_acc_cnt,
         |	  t0.zc_model_cnt zc_model_cnt
         |   from(
         |	    select
         |	      a.inc_day,
         |		  a.region,
         |		  a.area,
         |		  a.city,
         |		a.citycode,
         |		get_json_object(a.chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode') deptcode,
         |	      a.isNotUnderCall,
         |		  a.chkksrebody,
         |	      a.chkomsaoi,
         |	      b.cnt req_count,
         |       c.month_acc_cnt month_acc_cnt,
         |  d.zc_model_cnt zc_model_cnt
         |	    from
         |	      gis_rds_omsfrom_tmp a
         |	    left join
         |	  (
         |		select
         |			count(distinct sysorderno) as cnt
         |			,isNotUnderCall
         |			,get_json_object(chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode') as deptcode
         |		from gis_rds_omsfrom_tmp
         |		group by isNotUnderCall,get_json_object(chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode')
         |	   ) b
         |	   on a.isNotUnderCall = b.isNotUnderCall and get_json_object(a.chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode') = b.deptcode
         |    left join
         |	   (
         |		select
         |			count(1) as month_acc_cnt
         |			,isNotUnderCall
         |   ,get_json_object(chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode') as deptcode
         |		from gis_rds_omsfrom_tmp where aoisrc='monthAcc'
         |		group by isNotUnderCall,get_json_object(chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode')
         |	   ) c
         |	   on a.isNotUnderCall = c.isNotUnderCall and get_json_object(a.chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode') = c.deptcode
         |    left join
         |	   (
         |		select
         |			count(1) as zc_model_cnt
         |			,isNotUnderCall
         |   ,get_json_object(chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode') as deptcode
         |		from gis_rds_omsfrom_tmp
         |		where chkomsaoi != ''
         |		and get_json_object(chkksrebody, "$dr.result.zcTag") = 'zcModel'
         |		and get_json_object(chkksrebody, "$dr.result.aoiTag") != ''
         |		group by isNotUnderCall,get_json_object(chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode')
         |	   ) d
         |	   on a.isNotUnderCall = d.isNotUnderCall and get_json_object(a.chkksreqbody, '$dr.prodOmsInfo.orderFrom.deptCode') = d.deptcode
         |		) t0
         |    where t0.chkomsaoi != '' and get_json_object(t0.chkksrebody, "$dr.result.zcTag") != 'zcModel'
         |    group by t0.inc_day,t0.area,t0.region,t0.city,t0.citycode,t0.deptcode,t0.isNotUnderCall,get_json_object(t0.chkksrebody, '$dr.result.aoiTag'),t0.req_count,month_acc_cnt,zc_model_cnt
         |    ) t1
         |  ) t2
         |group by t2.area,t2.region,t2.city,t2.citycode,t2.deptcode,t2.req_count,t2.amount,month_acc_cnt,zc_model_cnt,if(t2.isNotUnderCall='1','NO','YES')
      """.stripMargin).persist(StorageLevel.DISK_ONLY)
    deptDetailDF.show(5)
    //聚合数据
    val allResult: DataFrame = allDetailDF.union(areaDetailDF).union(regionDetailDF).union(cityDetailDF).union(deptDetailDF).toDF().persist(StorageLevel.DISK_ONLY)
    //写入hive表
    val hiveTableName = "aoi_ks_detail_reciver_isnotUnderCall_new"
    allResult.createOrReplaceTempView("result_tmp_view")
    allResult.show(5)
    val insert2hive = s"insert overwrite table $hiveTableName " +
          s"partition(inc_day='${incDay}') " +
          s"select * from result_tmp_view"
        spark.sql(insert2hive)
    //写入MySQL
//    saveMysql(allResult,incDay)
    spark.stop()
  }
}
