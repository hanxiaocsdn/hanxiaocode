package com.sf.gis.scala.dqs.util

/**
  * Created by 01375125 on 2018/6/21.
  */
object DataCase {


  /**
    *
    * @param date 日期
    * @param datetime 时间
    * @param wayBillNo 运单号
    * @param cityCode 城市代码
    * @param deptcode 网点代码
    * @param teamcode 单元区域代码
    * @param groupId 大组id
    * @param sss_zc sss返回的网点代码
    * @param sss_zc_single sss返回的网点代码是否为单网点
    * @param req_cnt 请求量
    * @param gis_sss_dept_match gis和sss网点匹配量
    * @param dept_arss 网点进审补量
    * @param dept_suc_arss 网点成功审补量
    * @param gis_dept_match gis网点识别量
    * @param sss_dept_match sss网点识别量
    * @param gis_tc_match gis单元区域识别量
    * @param tc_arss_match
    * @param tc_suc_arss
    * @param gis_final_dept_diff
    * @param gis_sss_dept_diff
    * @param gis_arss_tc_diff
    * @param sss_dept_src
    * @param gis_dept_src
    * @param dept_same
    * @param sss_arss_dept
    * @param awsm_arss_dept
    * @param awsm_no_dept
    * @param gis_tc_src
    * @param awsm_tc_src
    * @param awsm_no_tc
    * @param dept_norm_src
    * @param dept_chkn_src
    * @param dept_chke_src
    * @param dept_ts_src
    * @param tc_norm_src
    * @param tc_chkn_src
    * @param tc_chke_src
    * @param tc_ts_src
    * @param final_diff_dept_norm
    * @param final_diff_dept_chkn
    * @param final_diff_dept_chke
    * @param final_diff_dept_ts
    * @param final_diff_tc_norm
    * @param final_diff_tc_chkn
    * @param final_diff_tc_chke
    * @param final_diff_tc_ts
    * @param gis_match_dept
    * @param gis_dept_norm
    * @param gis_dept_chkn
    * @param gis_dept_chke
    * @param gis_dept_ts
    * @param gis_tc_norm
    * @param gis_tc_chkn
    * @param gis_tc_chke
    * @param gis_tc_ts
    * @param gis_diff_dept
    * @param gis_diff_dept_norm
    * @param gis_diff_dept_chkn
    * @param gis_diff_dept_chke
    * @param gis_diff_dept_ts
    * @param gis_diff_tc
    * @param gis_diff_tc_same_dept
    * @param gis_diff_tc_norm
    * @param gis_diff_tc_chkn
    * @param gis_diff_tc_chke
    * @param gis_diff_tc_ts
    * @param gis_diff_tc_norm_same_dept
    * @param gis_diff_tc_chkn_same_dept
    * @param gis_diff_tc_chke_same_dept
    * @param gis_diff_tc_ts_same_dept
    * @param dept_arss_ret
    * @param tc_arss_ret
    * @param gis_match_tc
    * @param sss_final_dept_diff
    * @param sss_arss_dept_diff
    * @param dept_auto_src
    * @param dept_phone_src
    * @param final_diff_dept_auto
    * @param final_diff_dept_phone
    * @param final_diff_tc_phone
    * @param gis_dept_auto
    * @param gis_dept_phone
    * @param gis_tc_phone
    * @param gis_diff_dept_auto
    * @param gis_diff_dept_phone
    * @param gis_diff_tc_phone
    * @param gis_diff_tc_phone_same_dept
    * @param gis_sss_dept_diff_norm
    * @param gis_sss_dept_diff_chkn
    * @param gis_sss_dept_diff_chke
    * @param gis_sss_dept_diff_auto
    * @param gis_sss_dept_diff_phone
    * @param gis_sss_dept_diff_ts
    * @param address_unknown
    * @param add_xy_cnt
    * @param add_xy_dept_match
    * @param add_xy_tc_match
    * @param gis_sss_dept_match_add
    * @param gis_tc_match_add
    */
  case class DataNum1(
                      date: String,
                      datetime: String,
                      wayBillNo: String,
                      cityCode: String,
                      deptcode: String,
                      teamcode: String,
                      groupId: String,
                      sss_zc: String,
                      sss_zc_single: String,

                      req_cnt: Int,
                      gis_sss_dept_match: Int,
                      dept_arss: Int,
                      dept_suc_arss: Int,
                      gis_dept_match: Int,
                      sss_dept_match: Int,
                      gis_tc_match: Int,
                      tc_arss_match: Int,
                      tc_suc_arss: Int,
                      gis_final_dept_diff: Int,
                      gis_sss_dept_diff: Int,
                      gis_arss_tc_diff: Int,
                      sss_dept_src: Int,
                      gis_dept_src: Int,
                      dept_same: Int,
                      sss_arss_dept: Int,
                      awsm_arss_dept: Int,
                      awsm_no_dept: Int,
                      gis_tc_src: Int,
                      awsm_tc_src: Int,
                      awsm_no_tc: Int,
                      dept_norm_src: Int,
                      dept_chkn_src: Int,
                      dept_chke_src: Int,
                      dept_ts_src: Int,
                      tc_norm_src: Int,
                      tc_chkn_src: Int,
                      tc_chke_src: Int,
                      tc_ts_src: Int,
                      final_diff_dept_norm: Int,
                      final_diff_dept_chkn: Int,
                      final_diff_dept_chke: Int,
                      final_diff_dept_ts: Int,
                      final_diff_tc_norm: Int,
                      final_diff_tc_chkn: Int,
                      final_diff_tc_chke: Int,
                      final_diff_tc_ts: Int,
                      gis_match_dept: Int,
                      gis_dept_norm: Int,
                      gis_dept_chkn: Int,
                      gis_dept_chke: Int,
                      gis_dept_ts: Int,
                      gis_tc_norm: Int,
                      gis_tc_chkn: Int,
                      gis_tc_chke: Int,
                      gis_tc_ts: Int,
                      gis_diff_dept: Int,
                      gis_diff_dept_norm: Int,
                      gis_diff_dept_chkn: Int,
                      gis_diff_dept_chke: Int,
                      gis_diff_dept_ts: Int,
                      gis_diff_tc: Int,
                      gis_diff_tc_same_dept: Int,
                      gis_diff_tc_norm: Int,
                      gis_diff_tc_chkn: Int,
                      gis_diff_tc_chke: Int,
                      gis_diff_tc_ts: Int,
                      gis_diff_tc_norm_same_dept: Int,
                      gis_diff_tc_chkn_same_dept: Int,
                      gis_diff_tc_chke_same_dept: Int,
                      gis_diff_tc_ts_same_dept: Int,
                      dept_arss_ret: Int,
                      tc_arss_ret: Int,
                      gis_match_tc: Int,
                      sss_final_dept_diff: Int,
                      sss_arss_dept_diff: Int,
                      dept_auto_src: Int,
                      dept_phone_src: Int,
                      final_diff_dept_auto: Int,
                      final_diff_dept_phone: Int,
                      final_diff_tc_phone: Int,
                      gis_dept_auto: Int,
                      gis_dept_phone: Int,
                      gis_tc_phone: Int,
                      gis_diff_dept_auto: Int,
                      gis_diff_dept_phone: Int,
                      gis_diff_tc_phone: Int,
                      gis_diff_tc_phone_same_dept: Int,
                      gis_sss_dept_diff_norm:Int,
                      gis_sss_dept_diff_chkn:Int,
                      gis_sss_dept_diff_chke:Int,
                      gis_sss_dept_diff_auto:Int,
                      gis_sss_dept_diff_phone:Int,
                      gis_sss_dept_diff_ts:Int,
                      address_unknown:Int,
                      add_xy_cnt:Int,
                      add_xy_dept_match:Int,
                      add_xy_tc_match:Int,
                      gis_sss_dept_match_add:Int,
                      gis_tc_match_add:Int
                    )



  //date,datetime,wayBillNo,cityCode,deptcode,teamcode,groupId,sss_zc,sss_zc_single,req_cnt,gis_sss_dept_match,dept_arss,dept_arss_ret,dept_suc_arss,gis_dept_match,sss_dept_match,gis_tc_match,tc_arss_match,tc_arss_ret,tc_suc_arss,gis_final_dept_diff,sss_final_dept_diff,sss_arss_dept_diff,gis_sss_dept_diff,gis_arss_tc_diff,address_unknown,add_xy_cnt,add_xy_dept_match,add_xy_tc_match,gis_sss_dept_match_add,gis_tc_match_add,sss_dept_src,gis_dept_src,dept_same,sss_arss_dept,awsm_arss_dept,awsm_no_dept,gis_tc_src,awsm_tc_src,awsm_no_tc,dept_norm_src,dept_chkn_src,dept_chke_src,dept_ts_src,dept_auto_src,dept_phone_src,dept_road_src,tc_norm_src,tc_chkn_src,tc_chke_src,tc_ts_src,tc_auto_src,tc_phone_src,tc_road_src,final_diff_dept_norm,final_diff_dept_chkn,final_diff_dept_chke,final_diff_dept_ts,final_diff_dept_auto,final_diff_dept_phone,final_diff_dept_road,final_diff_tc_norm,final_diff_tc_chkn,final_diff_tc_chke,final_diff_tc_ts,final_diff_tc_auto,final_diff_tc_phone,final_diff_tc_road,gis_match_dept,gis_match_tc,gis_dept_norm,gis_dept_chkn,gis_dept_chke,gis_dept_ts,gis_dept_auto,gis_dept_phone,gis_dept_road,gis_tc_norm,gis_tc_chkn,gis_tc_chke,gis_tc_ts,gis_tc_auto,gis_tc_phone,gis_tc_road,gis_diff_dept,gis_diff_dept_norm,gis_diff_dept_chkn,gis_diff_dept_chke,gis_diff_dept_ts,gis_diff_dept_auto,gis_diff_dept_phone,gis_diff_dept_road,gis_diff_tc,gis_diff_tc_same_dept,gis_diff_tc_norm,gis_diff_tc_chkn,gis_diff_tc_chke,gis_diff_tc_ts,gis_diff_tc_auto,gis_diff_tc_phone,gis_diff_tc_road,gis_diff_tc_norm_same_dept,gis_diff_tc_chkn_same_dept,gis_diff_tc_chke_same_dept,gis_diff_tc_ts_same_dept,gis_diff_tc_auto_same_dept,gis_diff_tc_phone_same_dept,gis_diff_tc_road_same_dept,gis_sss_dept_diff_norm,gis_sss_dept_diff_chkn,gis_sss_dept_diff_chke,gis_sss_dept_diff_auto,gis_sss_dept_diff_phone,gis_sss_dept_diff_ts
  case class DataNum(
                      date: String,
                      datetime: String,
                      wayBillNo: String,
                      cityCode: String,
                      deptcode: String,
                      teamcode: String,
                      groupId: String,
                      sss_zc: String,
                      sss_zc_single: String,

                     //最终结果，gis_sss服务-总指标情况
                      req_cnt: Int,
                      gis_sss_dept_match: Int,
                      dept_arss: Int,
                      dept_arss_ret: Int,
                      dept_suc_arss: Int,
                      gis_dept_match: Int,
                      sss_dept_match: Int,
                      gis_tc_match: Int,
                      tc_arss_match: Int,
                      tc_arss_ret: Int,
                      tc_suc_arss: Int,
                      gis_final_dept_diff: Int,
                      sss_final_dept_diff: Int,
                      sss_arss_dept_diff: Int,
                      gis_sss_dept_diff: Int,
                      gis_arss_tc_diff: Int,
                      //地址不详量
                      address_unknown:Int,
                      add_xy_cnt:Int,
                      add_xy_dept_match:Int,
                      add_xy_tc_match:Int,
                      gis_sss_dept_match_add:Int,
                      gis_tc_match_add:Int,

                     //最终结果，gis_sss服务-返回情况
                      sss_dept_src: Int,
                      gis_dept_src: Int,
                      dept_same: Int,
                      sss_arss_dept: Int,
                      awsm_arss_dept: Int,
                      awsm_no_dept: Int,
                      gis_tc_src: Int,
                      awsm_tc_src: Int,
                      awsm_no_tc: Int,

                     //最终返回,来源于GIS服务-识别量
                      dept_norm_src: Int,
                      dept_chkn_src: Int,
                      dept_chke_src: Int,
                      dept_ts_src: Int,
                      dept_auto_src: Int,
                      dept_phone_src: Int,
                      dept_road_src: Int,
                      tc_norm_src: Int,
                      tc_chkn_src: Int,
                      tc_chke_src: Int,
                      tc_ts_src: Int,
                      tc_auto_src: Int,
                      tc_phone_src: Int,
                      tc_road_src: Int,

                     //最终结果与GIS返回结果-不一致量
                      final_diff_dept_norm: Int,
                      final_diff_dept_chkn: Int,
                      final_diff_dept_chke: Int,
                      final_diff_dept_ts: Int,
                      final_diff_dept_auto: Int,
                      final_diff_dept_phone: Int,
                      final_diff_dept_road: Int,
                      final_diff_tc_norm: Int,
                      final_diff_tc_chkn: Int,
                      final_diff_tc_chke: Int,
                      final_diff_tc_ts: Int,
                      final_diff_tc_auto: Int,
                      final_diff_tc_phone: Int,
                      final_diff_tc_road: Int,

                     //GIS服务-识别量
                      gis_match_dept: Int,
                      gis_match_tc: Int,
                      gis_dept_norm: Int,
                      gis_dept_chkn: Int,
                      gis_dept_chke: Int,
                      gis_dept_ts: Int,
                      gis_dept_auto: Int,
                      gis_dept_phone: Int,
                      gis_dept_road: Int,
                      gis_tc_norm: Int,
                      gis_tc_chkn: Int,
                      gis_tc_chke: Int,
                      gis_tc_ts: Int,
                      gis_tc_auto: Int,
                      gis_tc_phone: Int,
                      gis_tc_road: Int,

                     //GIS返回结果与最终结果-不一致量
                      gis_diff_dept: Int,
                      gis_diff_dept_norm: Int,
                      gis_diff_dept_chkn: Int,
                      gis_diff_dept_chke: Int,
                      gis_diff_dept_ts: Int,
                      gis_diff_dept_auto: Int,
                      gis_diff_dept_phone: Int,
                      gis_diff_dept_road: Int,

                      gis_diff_tc: Int,
                      gis_diff_tc_same_dept: Int,
                      gis_diff_tc_norm: Int,
                      gis_diff_tc_chkn: Int,
                      gis_diff_tc_chke: Int,
                      gis_diff_tc_ts: Int,
                      gis_diff_tc_auto: Int,
                      gis_diff_tc_phone: Int,
                      gis_diff_tc_road: Int,

                      gis_diff_tc_norm_same_dept: Int,
                      gis_diff_tc_chkn_same_dept: Int,
                      gis_diff_tc_chke_same_dept: Int,
                      gis_diff_tc_ts_same_dept: Int,
                      gis_diff_tc_auto_same_dept: Int,
                      gis_diff_tc_phone_same_dept: Int,
                      gis_diff_tc_road_same_dept: Int,

                     //gis服务 GIS和SSS返回结果，网点不一致
                      gis_sss_dept_diff_norm:Int,
                      gis_sss_dept_diff_chkn:Int,
                      gis_sss_dept_diff_chke:Int,
                      gis_sss_dept_diff_ts:Int,
                      gis_sss_dept_diff_auto:Int,
                      gis_sss_dept_diff_phone:Int,
                      gis_sss_dept_diff_road:Int
                    )


}
