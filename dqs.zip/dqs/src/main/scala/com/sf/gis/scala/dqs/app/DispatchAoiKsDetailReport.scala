package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{HttpInvokeUtil, MD5Util}
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import com.sf.gis.scala.dqs.util.{CityInfoUtils, DbUtils, JavaUtil, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * 派件识别量报表统计
 * 需求方：郭本婕（01394694）
 *
 * @author 韩笑（01417629）
 *         Created on Mar.06 2022
 *         任务信息：（任务id:447934,派件识别量报表统计，每天15点0分执行、2022年3月7日--）
 */
//noinspection DuplicatedCode
object DispatchAoiKsDetailReport {
  @transient lazy val logger: Logger = Logger.getLogger(DispatchAoiKsDetailReport.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val ftcsllPath = "城市和地区对应关系.csv"
  val unMatchArray = Array[String]("9","22","4","5","6","7","8","10","12","14","15","16")
  val aoiTagArray = Array[String]("company","N1","standard","N2","N3","N4","N5","Y1","Y2","Y3","Y4","Y5","Vil_S1SZ"
    ,"Vil_S1WH","Vil_S2WH","Vil_WH","tcModel","KS6","tel_His","gd_poi","aoi_name","aoi_80_recent","aoi_80_similar_rate"
    ,"aoi_80_similar_unique","MAP_AB","OTHER","translate"
    ,"ks12_gd_tc2","ks12_telSimilar_tc2","ks12_telSimilar_gd","ks12_telRecent_gd_tc2","ks12_telSimilar_gd_tc2"
    ,"ks12_telRecent_gd","ks0","80_address_N","80_address_Y","ks12_telRecent_tc2")
  val calPartition = 100
  //val calPartition = 200
  val savePatition = 20

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    //val incDay = args(0)
    val incDay = args(0)

    run(spark,incDay)
    spark.close()
  }

  def run(spark:SparkSession,parDay:String): Unit ={
    print(parDay)
    //获取ai派件数据
    val (omstoRDD,waybillnoList) = getOmstoRDD(spark,parDay)
    omstoRDD.take(2).foreach(println(_))
    waybillnoList.take(2).foreach(println(_))
    //获取工单地址维度unmatch_type
    val omstoUnmatchAddMap = getOmstoUnmatchADDMap(spark,parDay,waybillnoList)
    omstoUnmatchAddMap.take(2).foreach(println(_))
    //获取网点维度dept_code(网点代码)、dept_name(网点名称)、type_code(网点类型)
    val omstoUnmatchDeptMap = getOmstoUnmatchDeptMap(spark,parDay)
    omstoUnmatchDeptMap.take(2).foreach(println(_))
    //获取城市对应对应的地址大区
    val cityMap = getCityMap()

    //关联地址维度，网点维度，地址大区映射等
    val multiRDD = doMultiMapJoin(omstoRDD,cityMap,omstoUnmatchAddMap,omstoUnmatchDeptMap)
    multiRDD.take(2).foreach(println(_))
    //按地区-大区-城市-网点维度聚合剔除前、剔除网点和剔除网点及地址不详(T+1)指标聚合指标并压平
    val aggrRDD = getAggrRdd(multiRDD)
    // aggrRDD.collect().foreach(logger.error)
    aggrRDD.take(2).foreach(println(_))
    //按日期聚合
    val aggrAllRDD = getAggrAllRDD(aggrRDD)
    // aggrAllRDD.collect().foreach(logger.error)
    aggrAllRDD.take(2).foreach(println(_))
    //地区聚合
    val aggrAreaRDD = getAggrAreaRDD(aggrRDD)
    //aggrAreaRDD.collect().foreach(logger.error)
    aggrAreaRDD.take(2).foreach(println(_))
    //按大区聚合
    val aggrRegionRDD = getAggrRegionRDD(aggrRDD)
    //aggrRegionRDD.collect().foreach(logger.error)
    aggrRegionRDD.take(2).foreach(println(_))
    //按城市聚合
    val aggrCityRDD = getAggrCityRDD(aggrRDD)
    //aggrCityRDD.collect().foreach(logger.error)
    aggrCityRDD.take(2).foreach(println(_))
    //合并所有统计结果
    val saveRDD = aggrRDD.union(aggrAllRDD).union(aggrAreaRDD).union(aggrRegionRDD).union(aggrCityRDD).persist(StorageLevel.DISK_ONLY)
    saveRDD.take(2).foreach(println(_))
    aggrRDD.unpersist()
    aggrAllRDD.unpersist()
    aggrAreaRDD.unpersist()
    aggrRegionRDD.unpersist()
    aggrCityRDD.unpersist()

    logger.error(s">>>共统计指标:${saveRDD.count()}<<<")

    //saveRDD.collect().foreach(logger.error)

    //存入mysql中
    saveMysql(saveRDD,parDay)

    //存入到hive中
    //Util.saveResult(logger,spark,saveRDD,saveAggr,"aoi_ks_detail_report",parDay,"hdfs://sfbd")
    saveResult(logger,spark,saveRDD,parDay)

    saveRDD.unpersist()
  }

  def saveMysql (aggrRDD: RDD[JSONObject],parDay:String): Any ={
    val descTableName = "AOI_KS_DETAIL_REPORT"
    //val descTableName = "AOI_KS_DETAIL_REPORT_TEMP"

    val javaUtil = new JavaUtil()
    javaUtil.setFlag(6)
    val conn = DbUtils.getConnection(javaUtil)

    val md5Instance = MD5Util.getMD5Instance

    try {
      logger.error(">>>>>>>>>开始插入数据库<<<<<<<<<<")

      //存入hive
      val delSql = String.format(s"delete from $descTableName where stat_date='%s'", parDay)
      logger.error(">>>保存之前，删除当天的数据:" + delSql)
      DbUtils.executeSql(conn, delSql)


      val insertSql = s"insert into $descTableName (`id`,`stat_type`,`stat_type_content`,`stat_date`,`area`,`region`,`city`,`city_code`,`zonecode`," +
        s" `types`,`company`,`n1`,`standard`,`n2`,`n3`,`n4`,`n5`,`y1`,`y2`,`y3`,`y4`,`y5`,`vil_s1sz`,`vil_s1wh`,`vil_s2wh`,`vil_wh`,`tcmodel`,`ks6`," +
        s"`tel_His`,`gd_poi`,`aoi_name`,`aoi_80_recent`,`aoi_80_similar_rate`,`aoi_80_similar_unique`,`other`,`amount`,`translate`" +
        s",`zcModelAmount`,`ks12_gd_tc2`,`ks12_telSimilar_tc2`,`ks12_telSimilar_gd`,`ks12_telRecent_gd_tc2`,`ks12_telSimilar_gd_tc2`" +
        s",`ks12_telRecent_gd`,`ks0`,`80_address_N`,`80_address_Y`,`ks12_telRecent_tc2`) " +
        s"values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
      var insertParams: Array[Any] = null

      //存入mysql
      aggrRDD.collect().foreach( obj => {
        val id = MD5Util.getMD5(md5Instance, Array(parDay,obj.getString("STAT_TYPE"),obj.getString("STAT_TYPE_CONTENT")
          ,obj.getString("city"),obj.getString("area"),obj.getString("region"),obj.getString("ZONECODE")
          ,obj.getString("types")).mkString("_"))

        insertParams = Array(id,obj.getString("STAT_TYPE"),obj.getString("STAT_TYPE_CONTENT"),parDay
          ,obj.getString("area"),obj.getString("region"),obj.getString("city"),obj.getString("CITY_CODE")
          ,obj.getString("ZONECODE"),obj.getString("types"),obj.getString("company"),obj.getString("N1")
          ,obj.getString("standard"),obj.getString("N2"),obj.getString("N3"),obj.getString("N4")
          ,obj.getString("N5"),obj.getString("Y1"),obj.getString("Y2"),obj.getString("Y3")
          ,obj.getString("Y4"),obj.getString("Y5"),obj.getString("Vil_S1SZ"),obj.getString("Vil_S1WH")
          ,obj.getString("Vil_S2WH"),obj.getString("Vil_WH"),obj.getString("tcModel"),obj.getString("KS6")
          ,obj.getString("tel_His"),obj.getString("gd_poi"),obj.getString("aoi_name")
          ,obj.getString("aoi_80_recent"),obj.getString("aoi_80_similar_rate"),obj.getString("aoi_80_similar_unique")
          ,obj.getString("OTHER"),obj.getString("amount"),obj.getString("translate")
          ,obj.getString("zcModelAmount"),obj.getString("ks12_gd_tc2"),obj.getString("ks12_telSimilar_tc2")
        ,obj.getString("ks12_telSimilar_gd"),obj.getString("ks12_telRecent_gd_tc2"),obj.getString("ks12_telSimilar_gd_tc2")
        ,obj.getString("ks12_telRecent_gd"),obj.getString("ks0"),obj.getString("80_address_N")
        ,obj.getString("80_address_Y"),obj.getString("ks12_telRecent_tc2"))
        DbUtils.execute( conn, insertSql, insertParams )
      })

      logger.error(">>>ks明细指标入库结束！")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  def saveResult(logger: Logger, spark: SparkSession, saveRDD: RDD[JSONObject],parDay: String):Any = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "aoi_ks_detail_report_new"

    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay')
         |SELECT
         | *
         |FROM AOI_KS_DETAIL_REPORT_NEW_TEMP_VIEW
         |""".stripMargin

    try{
      val schemaString = "STAT_TYPE,STAT_TYPE_CONTENT" +
        ",area,region,city,CITY_CODE,ZONECODE,types" +
        ",company,N1,standard,N2,N3,N4,N5,Y1,Y2,Y3" +
        ",Y4,Y5,Vil_S1SZ,Vil_S1WH,Vil_S2WH,Vil_WH" +
        ",tcModel,KS6,MAP_AB,OTHER,amount,tel_His" +
        ",gd_poi,aoi_name,aoi_80_recent" +
        ",aoi_80_similar_rate,aoi_80_similar_unique,translate,zcModelAmount" +
        ",ks12_gd_tc2,ks12_telSimilar_tc2,ks12_telSimilar_gd,ks12_telRecent_gd_tc2" +
        ",ks12_telSimilar_gd_tc2,ks12_telRecent_gd,ks0,80_address_N,80_address_Y,ks12_telRecent_tc2"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
      val schema = StructType(fields)

      val rdd = saveRDD.map(obj => {
        val sb = new StringBuilder()
        sb.append(obj.getString("STAT_TYPE")).append("\t")
        sb.append(obj.getString("STAT_TYPE_CONTENT")).append("\t")
        sb.append(obj.getString("area")).append("\t")
        sb.append(obj.getString("region")).append("\t")
        sb.append(obj.getString("city")).append("\t")
        sb.append(obj.getString("CITY_CODE")).append("\t")
        sb.append(obj.getString("ZONECODE")).append("\t")
        sb.append(obj.getString("types")).append("\t")
        sb.append(obj.getString("company")).append("\t")
        sb.append(obj.getString("N1")).append("\t")
        sb.append(obj.getString("standard")).append("\t")
        sb.append(obj.getString("N2")).append("\t")
        sb.append(obj.getString("N3")).append("\t")
        sb.append(obj.getString("N4")).append("\t")
        sb.append(obj.getString("N5")).append("\t")
        sb.append(obj.getString("Y1")).append("\t")
        sb.append(obj.getString("Y2")).append("\t")
        sb.append(obj.getString("Y3")).append("\t")
        sb.append(obj.getString("Y4")).append("\t")
        sb.append(obj.getString("Y5")).append("\t")
        sb.append(obj.getString("Vil_S1SZ")).append("\t")
        sb.append(obj.getString("Vil_S1WH")).append("\t")
        sb.append(obj.getString("Vil_S2WH")).append("\t")
        sb.append(obj.getString("Vil_WH")).append("\t")
        sb.append(obj.getString("tcModel")).append("\t")
        sb.append(obj.getString("KS6")).append("\t")
        sb.append(obj.getString("MAP_AB")).append("\t")
        sb.append(obj.getString("OTHER")).append("\t")
        sb.append(obj.getString("amount")).append("\t")
        sb.append(obj.getString("tel_His")).append("\t")
        sb.append(obj.getString("gd_poi")).append("\t")
        sb.append(obj.getString("aoi_name")).append("\t")
        sb.append(obj.getString("aoi_80_recent")).append("\t")
        sb.append(obj.getString("aoi_80_similar_rate")).append("\t")
        sb.append(obj.getString("aoi_80_similar_unique")).append("\t")
        sb.append(obj.getString("translate")).append("\t")
        sb.append(obj.getString("zcModelAmount")).append("\t")
        sb.append(obj.getString("ks12_gd_tc2")).append("\t")
        sb.append(obj.getString("ks12_telSimilar_tc2")).append("\t")
        sb.append(obj.getString("ks12_telSimilar_gd")).append("\t")
        sb.append(obj.getString("ks12_telRecent_gd_tc2")).append("\t")
        sb.append(obj.getString("ks12_telSimilar_gd_tc2")).append("\t")
        sb.append(obj.getString("ks12_telRecent_gd")).append("\t")
        sb.append(obj.getString("ks0")).append("\t")
        sb.append(obj.getString("80_address_N")).append("\t")
        sb.append(obj.getString("80_address_Y")).append("\t")
        sb.append(obj.getString("ks12_telRecent_tc2")).append("\t")
        sb.toString()
      }).map(_.split("\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4)
        ,attr(5),attr(6),attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15)
        ,attr(16),attr(17),attr(18),attr(19),attr(20),attr(21),attr(22),attr(23),attr(24),attr(25)
        ,attr(26),attr(27),attr(28),attr(29),attr(30),attr(31),attr(32),attr(33),attr(34),attr(35)
        ,attr(36),attr(37),attr(38),attr(39),attr(40),attr(41),attr(42),attr(43),attr(44),attr(45),attr(46)))
      import spark.implicits._

      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.createOrReplaceTempView("AOI_KS_DETAIL_REPORT_NEW_TEMP_VIEW")

      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>KS明细指标入hive库开始")
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>KS明细指标入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }

  }

  val saveAggr = (saveRDD:RDD[JSONObject],path:String) => {
    saveRDD.map(obj => {
      val sb = new StringBuilder()
      sb.append(obj.getString("STAT_TYPE")).append("\t")
      sb.append(obj.getString("STAT_TYPE_CONTENT")).append("\t")
      sb.append(obj.getString("area")).append("\t")
      sb.append(obj.getString("region")).append("\t")
      sb.append(obj.getString("city")).append("\t")
      sb.append(obj.getString("CITY_CODE")).append("\t")
      sb.append(obj.getString("ZONECODE")).append("\t")
      sb.append(obj.getString("types")).append("\t")
      sb.append(obj.getString("company")).append("\t")
      sb.append(obj.getString("N1")).append("\t")
      sb.append(obj.getString("standard")).append("\t")
      sb.append(obj.getString("N2")).append("\t")
      sb.append(obj.getString("N3")).append("\t")
      sb.append(obj.getString("N4")).append("\t")
      sb.append(obj.getString("N5")).append("\t")
      sb.append(obj.getString("Y1")).append("\t")
      sb.append(obj.getString("Y2")).append("\t")
      sb.append(obj.getString("Y3")).append("\t")
      sb.append(obj.getString("Y4")).append("\t")
      sb.append(obj.getString("Y5")).append("\t")
      sb.append(obj.getString("Vil_S1SZ")).append("\t")
      sb.append(obj.getString("Vil_S1WH")).append("\t")
      sb.append(obj.getString("Vil_S2WH")).append("\t")
      sb.append(obj.getString("Vil_WH")).append("\t")
      sb.append(obj.getString("tcModel")).append("\t")
      sb.append(obj.getString("KS6")).append("\t")
      sb.append(obj.getString("MAP_AB")).append("\t")
      sb.append(obj.getString("OTHER")).append("\t")
      sb.append(obj.getString("amount")).append("\t")
      sb.append(obj.getString("tel_His")).append("\t")
      sb.append(obj.getString("gd_poi")).append("\t")
      sb.append(obj.getString("aoi_name")).append("\t")
      sb.append(obj.getString("aoi_80_recent")).append("\t")
      sb.append(obj.getString("aoi_80_similar_rate")).append("\t")
      sb.append(obj.getString("aoi_80_similar_unique")).append("\t")
      sb.append(obj.getString("translate")).append("\t")
      sb.toString()
    }).saveAsTextFile(path)
  }

  val seqOp = (a: (Int, List[JSONObject]), b: JSONObject) => a match {
    case (0, List()) => (1, List(b))
    case _ => (a._1 + 1, b::a._2)
  }

  val combOp = (a: (Int, List[JSONObject]), b: (Int, List[JSONObject])) => {
    (a._1 + b._1, a._2 ::: b._2)
  }

  val doReduce = (obj:Iterable[JSONObject],args:Array[String]) =>{
    val json = new JSONObject()
    json.put("STAT_TYPE",args(0))
    json.put("STAT_TYPE_CONTENT",args(1))
    json.put("ZONECODE",args(2))
    json.put("city",args(3))
    json.put("CITY_CODE",args(4))
    json.put("region",args(5))
    json.put("area",args(6))
    json.put("types",args(7))

    json.put("amount",0)
    json.put("zcModelAmount",0)
    aoiTagArray.foreach(elem => {json.put(elem,0)})

    obj.foreach(one => {
      aoiTagArray.foreach(elem => {json.put(elem,json.getInteger(elem) + one.getInteger(elem))})
      json.put("amount",json.getInteger("amount") + one.getInteger("amount"))
      json.put("zcModelAmount",json.getInteger("zcModelAmount") + one.getInteger("zcModelAmount"))
    })

    json
  }

  def getAggrAllRDD( aggrRDD: RDD[JSONObject]) ={

    val aggrAllRDD = aggrRDD.map(obj => {
      (obj.getString("types"),obj)
    }).groupByKey().map(obj => {
      doReduce(obj._2,Array("ALL","ALL","ALL","ALL","ALL","ALL","ALL",obj._1))
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>按日期聚合sss:${aggrAllRDD.count()}<<<")

    aggrAllRDD
  }

  def getAggrAreaRDD(aggrRDD: RDD[JSONObject])= {

    val aggrAreaRDD = aggrRDD.map(obj => {
      ((obj.getString("types"),obj.getString("area")),obj)
    }).groupByKey().map(obj => {
      doReduce(obj._2,Array("AREA",obj._1._2,"ALL","ALL","ALL","ALL",obj._1._2,obj._1._1))
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>按地区聚合:${aggrAreaRDD.count()}<<<")

    aggrAreaRDD
  }

  def getAggrRegionRDD(aggrRDD: RDD[JSONObject])={
    val aggrRegionRDD = aggrRDD.map(obj => {
      ((obj.getString("types"),obj.getString("area"),obj.getString("region")),obj)
    }).groupByKey().map(obj => {
      doReduce(obj._2,Array("REGION",obj._1._3,"ALL","ALL","ALL",obj._1._3,obj._1._2,obj._1._1))
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>按大区聚合:${aggrRegionRDD.count()}<<<")

    aggrRegionRDD
  }

  def getAggrCityRDD(aggrRDD: RDD[JSONObject])={
    val aggrCityRDD = aggrRDD.map(obj => {
      ((obj.getString("types"),obj.getString("area"),obj.getString("region"),obj.getString("CITY_CODE"),obj.getString("city")),obj)
    }).groupByKey().map(obj => {
      doReduce(obj._2,Array("CITY",obj._1._4,"ALL",obj._1._5,obj._1._4,obj._1._3,obj._1._2,obj._1._1))
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s">>>按城市聚合:${aggrCityRDD.count()}<<<")
    aggrCityRDD
  }


  def getAggrRdd(multiRDD:  RDD[((String, String, String, String, String), JSONObject)])={

    val aggrRDD = multiRDD.aggregateByKey((0,List[JSONObject]()))(seqOp,combOp).map(obj =>{
      val list = obj._2._2

      //剔除前
      val aoiTagMap = scala.collection.mutable.Map[String,Int]()
      //剔除网点
      val aoiTagDeptMap = scala.collection.mutable.Map[String,Int]()
      //剔除网点和地址不详
      val aoiTagDeptAddMap = scala.collection.mutable.Map[String,Int]()

      aoiTagArray.foreach(elem => {
        aoiTagMap.put(elem,0)
        aoiTagDeptMap.put(elem,0)
        aoiTagDeptAddMap.put(elem,0)
      })

      try {
        list.foreach(jsonObj => {
          val isMatchDept = jsonObj.getBoolean("isMatchDept")
          val isMatchAdd = jsonObj.getBoolean("isMatchAdd")
          val aoiTag = jsonObj.getString("aoiTag")
          val gisaoicode = jsonObj.getString("gisaoicode")
          val ksaoicode = jsonObj.getString("ksaoicode")
          val zcTag = JSONUtil.getJsonVal(jsonObj,"zcTag","")
          val key = if (aoiTagArray.contains(aoiTag)) aoiTag else "OTHER"

          if (gisaoicode.isEmpty && !ksaoicode.isEmpty && zcTag != "zcModel"){
            //所有指标
            aoiTagMap.put(key,aoiTagMap.get(key).get + 1)
            //剔除网点后指标
            if ( isMatchDept ){
              aoiTagDeptMap.put(key,aoiTagDeptMap.get(key).get + 1)
              //剔除网点和地址不详指标
              if( isMatchAdd)
                aoiTagDeptAddMap.put(key,aoiTagDeptAddMap.get(key).get + 1)
            }
          }
        })}catch {
        case e:Exception => logger.error(e + list.mkString)
      }


      //统计各个tag指标
      //剔除前请求量
      val reqAmount = list.map(elem => elem.getString("reqWaybillno")).distinct.size
      //剔除网点请求量
      val delDeptList = list.filter(elem => elem.getBoolean("isMatchDept") )
      val delDeptReqAmount = delDeptList.map(elem =>  elem.getString("reqWaybillno") ).distinct.size
      //剔除网点及地址不详
      val delDeptAddReqAmount = delDeptList.filter(elem => elem.getBoolean("isMatchAdd")).map(elem => elem.getString("reqWaybillno")).distinct.size

      //zcModelAmount剔除前请求量
      val zcModelAmount = list.filter(obj => {
        val aoiTag = JSONUtil.getJsonVal(obj,"aoiTag","")
        val gis_to_sys_gisdeptcodeto = JSONUtil.getJsonVal(obj,"gis_to_sys_gisdeptcodeto","")
        val gis_to_sys_sssdeptcodeto = JSONUtil.getJsonVal(obj,"gis_to_sys_sssdeptcodeto","")
        val zcTag = JSONUtil.getJsonVal(obj,"zcTag","")
        gis_to_sys_gisdeptcodeto.isEmpty && gis_to_sys_sssdeptcodeto.isEmpty && !aoiTag.isEmpty && zcTag == "zcModel"
      }).map(elem => elem.getString("reqWaybillno")).size
      //zcModelAmount剔除网点请求量
      val zcModelDelDeptList = list.filter(elem => elem.getBoolean("isMatchDept") ).filter(obj => {
        val aoiTag = JSONUtil.getJsonVal(obj,"aoiTag","")
        val gis_to_sys_gisdeptcodeto = JSONUtil.getJsonVal(obj,"gis_to_sys_gisdeptcodeto","")
        val gis_to_sys_sssdeptcodeto = JSONUtil.getJsonVal(obj,"gis_to_sys_sssdeptcodeto","")
        val zcTag = JSONUtil.getJsonVal(obj,"zcTag","")
        gis_to_sys_gisdeptcodeto.isEmpty && gis_to_sys_sssdeptcodeto.isEmpty && !aoiTag.isEmpty && zcTag == "zcModel"
      })
      val zcModelDelDeptReqAmount = zcModelDelDeptList.map(elem =>  elem.getString("reqWaybillno") ).size
      //zcModelAmount剔除网点及地址不详
      val zcModelDelDeptAddReqAmount = zcModelDelDeptList.filter(elem => elem.getBoolean("isMatchAdd"))
        .map(elem => elem.getString("reqWaybillno")).size

      val json = new JSONObject()
      json.put("STAT_TYPE","ZC")
      json.put("STAT_TYPE_CONTENT",obj._1._4)
      json.put("area",obj._1._1)
      json.put("region",obj._1._2)
      json.put("city",obj._1._5)
      json.put("CITY_CODE",obj._1._3)
      json.put("ZONECODE",obj._1._4)

      val arr = Array[(String,scala.collection.mutable.Map[String,Int],Int,Int)](
        ("PRE",aoiTagMap,reqAmount,zcModelAmount),
        ("REJECT_DEPT",aoiTagDeptMap,delDeptReqAmount,zcModelDelDeptReqAmount),
        ("REJECT_DEPT_ADDR",aoiTagDeptAddMap,delDeptAddReqAmount,zcModelDelDeptAddReqAmount))

      (json,arr)
    }).flatMap(obj =>{
      val jsonObj = obj._1
      for( i <- 0 until obj._2.size) yield {
        val json = new JSONObject()
        json.fluentPutAll(jsonObj)
        val elem = obj._2(i)
        json.put("types",elem._1)
        json.put("size",obj._2.size)
        json.put("amount",elem._3)
        json.put("zcModelAmount",elem._4)

        elem._2.keySet.foreach(one => json.put(one,elem._2.get(one).get))

        json
      }
    }).repartition(savePatition).persist(StorageLevel.DISK_ONLY)

    multiRDD.unpersist()

    logger.error(s">>>共统计zc指标:${aggrRDD.count()}<<<")

    aggrRDD
  }

  def doMultiMapJoin(omstoRDD:RDD[Row], cityMap:Map[String, (String, String, String)], omstoUnmatchMap: Map[String, String], omstoUnmatchDeptMap:Map[String, (String, String)]) ={
    val multiRDD = omstoRDD.map(obj =>{
      val reqWaybillno = obj.getString(0)
      val ksReBody = obj.getString(1)
      val reqDestcitycode = obj.get(2).toString
      val finalzc = obj.getString(3)
      val gis_to_sys_gisdeptcodeto = obj.getString(4)
      val gis_to_sys_sssdeptcodeto = obj.getString(5)
      val gisaoicode = obj.getString(6)
      val ksaoicode = obj.getString(7)

      val aoiTag = try { JSON.parseObject(ksReBody).getJSONObject("result").getString("aoiTag") } catch { case e:Exception => "" }
      val zcTag = try { JSON.parseObject(ksReBody).getJSONObject("result").getString("zcTag") } catch { case e:Exception => "" }
      //(大区，地区，城市，网点)
      var key = ("","","","","")
      val jsonObject = new JSONObject()

      jsonObject.put("aoiTag",aoiTag)
      jsonObject.put("reqWaybillno",reqWaybillno)
      jsonObject.put("reqDestcitycode",reqDestcitycode)
      jsonObject.put("gis_to_sys_gisdeptcodeto",gis_to_sys_gisdeptcodeto)
      jsonObject.put("gis_to_sys_sssdeptcodeto",gis_to_sys_sssdeptcodeto)
      jsonObject.put("gisaoicode",gisaoicode)
      jsonObject.put("ksaoicode",ksaoicode)
      jsonObject.put("zcTag",zcTag)

      /*try{*/
      val city = cityMap.getOrElse(reqDestcitycode,("","",""))

      key = (city._1,city._2,reqDestcitycode,finalzc,city._3)

      jsonObject.put("key",key.toString)

      jsonObject.put("city",city._3)

      //地址维度剔除
      //false为需要剔除,true为不需要剔除，未获取到默认不剔除
      val unMatchType = omstoUnmatchMap.getOrElse(reqWaybillno,"")
      jsonObject.put("isMatchAdd",if (unMatchArray.contains(unMatchType)) false else true)

      //网点维度剔除
      //(detp_name,type_code)
      val nameType = omstoUnmatchDeptMap.getOrElse(finalzc,("",""))

      jsonObject.put("nameType",nameType)

      //除type_code字段值为DB05-XMDB/FB04-WXJ/FB05-CCPSCK和type_code字段值为DB05-SFZ且dept_name(网点名称)字段值包含临时网点/服务中心的地址
      //false为需要剔除,true为不需要剔除，未获取到默认不剔除
      val isMatchDept = if( Array("DB05-XMDB","FB04-WXJ","FB05-CCPSCK").contains(nameType._2) ) false else {
        if ( "DB05-SFZ".equals(nameType._2) && StringUtils.isNotBlank(nameType._1) )
          if (nameType._1.contains("临时网点") || nameType._1.contains("服务中心") ) false else true
        else true
      }

      jsonObject.put("isMatchDept",isMatchDept)
      jsonObject.put("unMatchAddDept",nameType+unMatchType)

      /*}catch {
        case e:Exception =>logger.error(e+"获取aoiTag失败："+ksReBody)
      }*/

      (key,jsonObject)
    })/*.filter(obj => StringUtils.isNotBlank(obj._2.getString("aoiTag")))*/.persist(StorageLevel.DISK_ONLY)


    logger.error(s">>>多维度关联后：${multiRDD.count()}<<<")

    multiRDD
  }

  def getCityMap()={
    /*val in = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream(ftcsllPath))
    val records = CSVFormat.DEFAULT.withHeader().withSkipHeaderRecord().parse(in).iterator()
    var csvMap: Map[String, (String,String)] = Map()

    while (records.hasNext){
      val elem = records.next()
      csvMap += (elem.get("城市代码") -> (elem.get("地区"),elem.get("大区")) )
      //sourList = (elem.get("便利店编码"),elem.get("经度"),elem.get("纬度")) :: sourList
    }

    logger.error(s">>>获取地址大区映射共：${csvMap.size}<<<")*/

    val javaUtil = new JavaUtil()
    javaUtil.setFlag(6)

    val cityMap = CityInfoUtils.getCityMap(javaUtil)
      .map(obj => {
        if (obj._2.length == 0) (obj._1,("","",""))
        else (obj._1,(obj._2(0)(4),obj._2(0)(0),obj._2(0)(1)))
      })

    logger.error(s">>>获取地址大区映射共：${cityMap.size}<<<")
    cityMap
  }

  def getOmstoUnmatchDeptMap(spark:SparkSession,parDay:String):Map[String,(String,String)]={
    val querySql =
      s"""
         |select
         |  dept_code,
         | nvl(dept_name,'null'),
         | nvl(dept_type_code,'null')
         |from gdl.zipper_dim_department
         |where dept_code <>''
         | and dw_start_date <= '$parDay'
         | and dw_end_date >= '$parDay'
         |""".stripMargin

    logger.error(querySql)

    val omstoUnmatchDeptRDD = spark.sql(querySql).rdd

    var omstoUnmatchDeptMap: Map[String,(String,String)] = Map()

    omstoUnmatchDeptRDD.collect().foreach( obj => omstoUnmatchDeptMap += (obj.getString(0) -> (obj.get(1).toString,obj.get(2).toString)) )

    logger.error(s">>>获取网点维度共：${omstoUnmatchDeptMap.size}<<<")

    omstoUnmatchDeptMap
  }

  def getOmstoUnmatchADDMap(spark:SparkSession,parDay:String,waybillnoList:List[String]):Map[String,String]={
    /*val path = ClassLoader.getSystemClassLoader().getResource("gis_rds_omsto_gis_unmatch_aoi.csv").getPath()
    val querySourceDF =
      spark.read.option("header", true).option("delimiter", "\t").option("inferSchema", true).csv(path)
    querySourceDF.createOrReplaceTempView("gis_rds_omsto_gis_unmatch_aoi")*/

    val querySql =
      s"""select
         |req_waybillno,
         |unmatch_type
         |from dm_gis.gis_rds_omsto_gis_unmatch_aoi
         |where req_waybillno <> '' and inc_day='$parDay'""".stripMargin

    //and req_waybillno in ('${waybillnoList.mkString("','")}')

    logger.error(querySql)

    val omstoUnmatchRDD = spark.sql(querySql).rdd

    var omstoUnmatchMap: Map[String, String] = Map()

    omstoUnmatchRDD.collect().foreach(obj => omstoUnmatchMap += (obj.getString(0) -> obj.get(1).toString))

    logger.error(s">>>获取地址维度共：${omstoUnmatchMap.size}<<<")
    omstoUnmatchMap
  }

  def getOmstoRDD(spark:SparkSession,parDay:String)={
    /*val path = ClassLoader.getSystemClassLoader().getResource("gis_rds_omsto.csv").getPath()
    val querySourceDF =
      spark.read.option("header", true).option("delimiter", "\t").option("inferSchema", true).csv(path)
    querySourceDF.createOrReplaceTempView("gis_rds_omsto")*/

    val querySql =
      s"""
         |select * from
         |    ( select
         |      req_waybillno,
         |      ks_re_body,
         |      req_destcitycode,
         |      finalzc,
         |      gis_to_sys_gisdeptcodeto,
         |      gis_to_sys_sssdeptcodeto,
         |      gisaoicode,
         |      ksaoicode,
         |      row_number() over(partition BY req_waybillno order by req_time desc ) as rank
         |   from dm_gis.gis_rds_omsto
         | where finalzc <> '' and finalzc is not null and finalzc <>'null'
         |       and req_waybillno <> ''
         |       and inc_day = '$parDay'
         |) a where a.rank=1
       """.stripMargin

    // and ks_re_body <> '' and ks_re_body is not null and ks_re_body <>'null' and req_destcitycode in ('010')

    logger.error(querySql)

    val omstoRDD = spark.sql(querySql).rdd.repartition(calPartition).persist(StorageLevel.DISK_ONLY)

    //val waybillnoList= omstoRDD.map(_.getString(0)).collect().toList.distinct
    val waybillnoList= Array("1","2").toList.distinct

    logger.error(s">>>获取派件订单共 ${omstoRDD.count()} 条s<<<")

    (omstoRDD,waybillnoList)
  }
}
