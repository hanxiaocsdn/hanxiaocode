package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.util
import java.util.regex.Pattern

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.{FixedConstant, HttpConstant}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, ConfigUtil, HttpInvokeUtil, JdbcUtil}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.dqs.util.{DateUtils, Util}
import org.apache.commons.lang3.StringUtils
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}


/**
 * 智域收件判错数据审补来源数据后续处理
 * 2022-06-08 CREATE BY 01417629
 * 任务id:447050
 */
//noinspection DuplicatedCode
object ReceivingWrongJudgmentDataProcess_2 {
  @transient lazy val logger: Logger = Logger.getLogger(ReceivingWrongJudgmentDataProcess_2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val update_address_aoiid = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId"
  val update_address_md5aoicheck = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrMd5AoiCheck"
  //val poiUrl = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/queryPoi?keywords=%s"
  val poiUrl = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/v5/queryPoi?keywords=%s"
  val fileName = "sharding-db.properties"

  val limitMin_1 = 1000 / 20

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val parDay_1 = args(0)//t-1分区
    val parDay_2 = DateUtils.getDateStr(DateUtils.lastMonday())//上周日分区
    val parDay_3 = DateUtils.getDateStr(DateUtils.lastLastMonday())//上上周日分区
    run(spark,parDay_1,parDay_2,parDay_3)
    spark.close()
  }

  def run(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String): Unit ={
    println(parDay_1)
    println(parDay_2)
    println(parDay_3)
    //dm_gis.legacy_error_data_tmp通过batch_no，address关联dm_gis.cgcs_error_address_result（t-1）
    val checkRet = GetCheckRet(spark,parDay_1,parDay_2,parDay_3)
    checkRet.take(2).foreach(println(_))
    //check_aoi_id_tag打标
    val checkAoiTag = getCheckAoiTag(checkRet)
    checkAoiTag.take(2).foreach(println(_))
    saveResult_checkAoiTag(spark,checkAoiTag,parDay_1)
    checkRet.unpersist()
    //check_aoi_id_tag=right,check_aoi_id_tag更新
    val checkRet_2 = GetCheckRet_2(checkAoiTag)
    checkRet_2.take(2).foreach(println(_))
    //保存过滤后的数据
    saveResult(spark,checkRet_2,parDay_1)
    //更新address的aoiid更新address的aoiid,新增结果字段：updateaoiid_result
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "447050", "智域收件判错数据审补来源数据处理_2", "智域收件判错数据审补来源数据处理_2", "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId", "", checkRet_2.count(), 20)

    val checkRet_3_1 = updateAddressAoiid(checkRet_2)
    checkRet_3_1.take(2).foreach(println(_))
    checkRet_2.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)

    val httpInvokeId1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "447050", "智域收件判错数据审补来源数据处理_2", "智域收件判错数据审补来源数据处理_2", "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId", "", checkAoiTag.count(), 20)

    val checkRet_3_2 = updateAddressAoiid_1(checkAoiTag)
    checkRet_3_2.take(2).foreach(println(_))
    checkAoiTag.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId1)
    val checkRet_3 = checkRet_3_1.union(checkRet_3_2).persist(StorageLevel.DISK_ONLY)
    //更新address的adcode,新增结果字段：updateAddrAoiCheck_result
    val httpInvokeId2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "447050", "智域收件判错数据审补来源数据处理_2", "智域收件判错数据审补来源数据处理_2", "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrMd5AoiCheck", "", checkRet_3.count(), 20)

    val checkRet_4 = updateAddressAdcode(checkRet_3)
    checkRet_4.take(2).foreach(println(_))
    checkRet_3.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId2)
    //保存post返回结果数据
    saveResult_1(spark,checkRet_4,parDay_1)
    checkRet_4.unpersist()
    /*val checkRet_3_1 = updateAddressAoiidTest(spark)
    checkRet_3_1.take(10).foreach(println(_))*/
  }

  /**
   * dm_gis.legacy_error_data_tmp通过batch_no(即t-6分区日期)，address关联dm_gis.dm_cgcs_check_info_df（t-1）
   * @param spark
   * @param parDay_1
   * @return
   */
  def GetCheckRet(spark: SparkSession,parDay_1 : String,parDay_2 : String,parDay_3 : String): RDD[JSONObject] ={
    val properties = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties")
    /*val sql =
      s"""
         |select
         |	t1.*
         |	,t2.check_aoi_id
         |	,t2.check_aoi_code
         |	,t2.check_aoi_name
         |	,t2.check_by
         |from
         |(
         |	SELECT
         |    req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname,bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord,gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right,result_flag,groupid,freq,gj_aoiids,aoiids_54,gj_aoiids_p,tag_aoiid,inc_day
         |    FROM dm_gis.legacy_error_data_tmp
         |    where inc_day = '$parDay_2'
         |) as t1
         |
         |left join
         |
         |(
         |	SELECT
         |    city_code,zno_code,address,create_date,state,check_by,check_date,check_dept_code,check_sch_code,check_aoi_id,check_aoi_code,check_aoi_name,check_x,check_y,check_data_type,waybill_no,source,batch_no
         |    FROM dm_gis.dm_cgcs_check_info_df
         |    where (inc_day between '$parDay_3' and '$parDay_1') and batch_no = concat('cuofen_cgcs_shou_ch_','$parDay_2')
         |) as t2
         |
         |on t1.inc_day = split(t2.batch_no,'_')[4] and t1.req_address = t2.address
         |""".stripMargin*/
    val sql =
      s"""
         |select
         |	t1.*
         |	,t2.check_aoi_id
         |	,t2.check_aoi_code
         |	,t2.check_aoi_name
         |	,t2.check_by
         |from
         |(
         |	SELECT
         |    req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t,aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname,bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord,gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right,result_flag,groupid,freq,gj_aoiids,aoiids_54,gj_aoiids_p,tag_aoiid,inc_day
         |    FROM dm_gis.legacy_error_data_tmp
         |    where inc_day in ('$parDay_2','$parDay_3')
         |) as t1
         |
         |left join
         |
         |(
         |	SELECT city_code,zno_code,address,batch_no,order_id,month_acc,create_date,create_by,check_by,check_date,check_x,check_y,check_dept_code,check_aoi_id,check_aoi_name,check_aoi_code,check_result
         | FROM dm_gis.cgcs_error_address_result --修改3-表名更改
         |    where inc_day = '$parDay_1'
         |    and check_aoi_id <> ''
         |    and check_aoi_id is not null
         |    and batch_no in (concat('cuofen_cgcs_','$parDay_2'),concat('cuofen_cgcs_','$parDay_3'))
         |) as t2
         |
         |on t1.inc_day = split(t2.batch_no,'_')[2] and t1.req_address = t2.address
         |
         |--where t1.citycode = '537' and t1.groupid = '4614909C2C75458E187A421AA9D2EBB8' and t2.check_aoi_id = 'BED63100BCA24BF6AA7C1D7AA1C33D1C'
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val checkRet = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>取checkRet数据共 ${checkRet.count()} 条s<<<")
    //修改4-增加挂接关系判断修改
    val checkRes = checkRet.mapPartitions(obj => {
      val conn = JdbcUtil.getMysqlConnection("mysql_wchka_s1.properties")
      val stmt = conn.createStatement()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      try {
        while (obj.hasNext) {
          val it = obj.next()
          val citycode = JSONUtil.getJsonVal(it,"citycode","")
          val groupid = JSONUtil.getJsonVal(it,"groupid","")
          if (StringUtils.isNotEmpty(citycode) && StringUtils.isNotEmpty(groupid)) {
            val sql = String.format("select adcode,aoi_id from cms_address_%s where city_code='%s' and address_md5 = '%s'", properties.getProperty(citycode), citycode, groupid)
            if (StringUtils.isNotEmpty(sql)) {
              val rs = stmt.executeQuery(sql)
              while (rs.next()) {
                val adcode = rs.getString("adcode")
                val aoi_id = rs.getString("aoi_id")
                it.put("flag",adcode)
                it.put("aoi_id_mysql",aoi_id)
              }
            }
          }
          arrayBuffer.append(it)
        }
      } catch {
        case e: Exception => logger.error(e)
      } finally {
        stmt.close()
        conn.close()
      }
      arrayBuffer.iterator
    }).filter(obj => {
      val flag = JSONUtil.getJsonVal(obj,"flag","")
      !Array("4","5","6","7","8","9","11","10","12").contains(flag)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>取checkRes数据共 ${checkRes.count()} 条s<<<")
    checkRes
  }

  def getTableName(cityCode: String): String = {
    var prefix = ""
    val citydef =
      s"""010=1
         |020=2
         |021=3
         |755=4
         |022,023,024,025,027,028,029,052,053,086,088,310,311,312,313,314,315,316,317,318=5
         |319,335,349,350,351,352,353,354,355,356,357,358,359,370,371,372,373,374,375,376=6
         |377,378,379,391,392,393,394,395,396,398,411,412,414,415,416,417,418,419,421,427=7
         |429,431,432,433,434,435,436,437,438,439,451,452,453,454,455,456,457,458,459,464=8
         |467,468,469,470,471,472,473,474,475,476,477,478,479,482,483,510,511,512,513,514=9
         |515,516,517,518,519,523,527,530,531,532,533,534,535,536,537,538,539,543,546,550=10
         |551,552,553,554,555,556,557,558,559,561,562,563,564,566,570,571,572,573,574,575=11
         |576,577,578,579,580,591,592,593,594,595,596,597,598,599,631,632,633,634,635,660=12
         |662,663,668,691,692,701,710,711,712,713,714,715,716,717,718,719,722,724,728,730=13
         |7311,7312,7313,734,735,736,737,738,739,743,744,745,746,750,751,752,753,754,756,757=14
         |758,759,760,762,763,766,768,769,770,771,772,773,774,775,776,777,778,779,790,791=15
         |792,793,794,795,796,797,798,799,812,813,816,817,818,825,826,827,830,831,832,833=16
         |834,835,836,837,838,839,851,852,853,854,855,856,857,858,859,870,871,872,873,874=17
         |875,876,877,878,879,883,886,887,891,892,893,894,895,896,897,898,8981,8982,8983,901=18
         |902,903,906,908,909,911,912,913,914,915,916,917,919,930,931,932,933,934,935,936=19
         |937,938,939,941,943,951,952,953,954,955,970,971,972,973,974,975,976,977,979,990,991,992,993,994,995,996,997,998,999=20""".stripMargin
        .split("\n").filter(_.length > 0).map(d => {

        val t = d.split("=")
        if (t.size > 1) {
          val v = t(1)
          t(0).split(",").map(cityCode => {
            (cityCode, v)
          })
        } else {
          logger.error("parse error:" + d)
          null
        }
      }).filter(_ != null).flatMap(d => d).toMap
    logger.error("----------------------------------------------------------------------------------------------")

    prefix = citydef.getOrElse(cityCode, "0")
    prefix
  }



  /**
   * 1、check_aoi_code = r_aoi
   * 2、raoiss值唯一，等于check_aoi_code
   * 3、gj_aoiid_t或54_aoi_id有值，且等于check_aoi_id
   * 4、gd_aoiid,mapa_aoiid,tc_aoiid,bd_aoiid有2个以上有值且等于check_aoi_id
   * 5、check_aoi_id存在于gjaoiids的aoiid中，且不存在“当gd_aoiid,mapa_aoiid,tc_aoiid,bd_aoiid中有值等于gjaoiids的数量最多（不去重）的aoiid，这个aoiid不等于check_aoi_id”的情况
   * 6、check_aoi_id存在于54_aoiids的aoiid中，且不存在“当gd_aoiid,mapa_aoiid,tc_aoiid,bd_aoiid中有值等于54_aoiids的数量最多（不去重）的aoiid，这个aoiid不等于check_aoi_id”的情况
   * 7、check_aoi_id存在于gj_aoiids_p的aoiid中，且不存在“当gd_aoiid,mapa_aoiid,tc_aoiid,bd_aoiid中有值等于gjaoiids或54_aoiids或gj_aoiids_p的aoiid，这个aoiid不等于check_aoi_id”和“当gd_aoicode,mapa_aoicode,tc_aoicode,bd_aoicode中有值存在于raoiss中，这个值不等于check_aoi_code”的情况
   *
   * 新增字段check_aoi_id_tag
   * check_aoi_id，check_aoi_code满足1或2或3或4或5或6或7，则check_aoi_id_tag值为right
   *
   * @param
   * @return
   */
//  def issueData(checkRet : RDD[JSONObject], parDay_2 : String): RDD[JSONObject] ={
//    val issueRes = checkRet.mapPartitions(obj => {
//      var cnt = 0
//      var startTime = System.currentTimeMillis()
//      obj.foreach(o => {
//        cnt = cnt + 1
//        if (cnt == limitMin) {
//          val endTime = System.currentTimeMillis() - startTime
//          if (endTime < 60000) {
//            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
//            Thread.sleep(60000 - endTime)
//          }
//          startTime = System.currentTimeMillis()
//          cnt = 0
//         }
//          val req_address = JSONUtil.getJsonVal(o,"req_address","")
//          val deptCode = JSONUtil.getJsonVal(o,"finalzc","")
//          val batchNo = "cuofen_cgcs_shou_ch_" + parDay_2
//          val json : JSONObject = getissueData(url_issue_data,req_address,deptCode,batchNo)
//          if(json != null){
//            val success = JSONUtil.getJsonVal(json,"success","")
//            if(success == "true"){
//              o.put("tag_aoiid","issued")
//            }else{
//              o.put("tag_aoiid","not_issued")
//            }
//          }else{
//            o.put("tag_aoiid","not_issued")
//          }
//          o
//      })
//      obj
//    }).persist(StorageLevel.DISK_ONLY)
//    logger.error(s">>>issueRes共 ${issueRes.count()} 条s<<<")
//    issueRes
//  }

  /**
   * check_aoi_id_tag打标
   * @param checkRet
   * @return
   */
  def getCheckAoiTag(checkRet : RDD[JSONObject]): RDD[JSONObject] ={
    val checkAoiTag = checkRet.map(obj => {
      val check_aoi_code = JSONUtil.getJsonVal(obj,"check_aoi_code","")
      val r_aoi = JSONUtil.getJsonVal(obj,"r_aoi","")
      val raoiss = JSONUtil.getJsonVal(obj,"raoiss","")
      val gj_aoiid_t = JSONUtil.getJsonVal(obj,"gj_aoiid_t","")
      val aoi_id_54 = JSONUtil.getJsonVal(obj,"aoi_id_54","")
      val gd_aoiid = JSONUtil.getJsonVal(obj,"gd_aoiid","")
      val mapa_aoiid = JSONUtil.getJsonVal(obj,"mapa_aoiid","")
      val tc_aoiid = JSONUtil.getJsonVal(obj,"tc_aoiid","")
      val bd_aoiid = JSONUtil.getJsonVal(obj,"bd_aoiid","")
      val check_aoi_id = JSONUtil.getJsonVal(obj,"check_aoi_id","")
      val gj_aoiids = JSONUtil.getJsonVal(obj,"gj_aoiids","")
      val aoiids_54 = JSONUtil.getJsonVal(obj,"aoiids_54","")
      val gj_aoiids_p = JSONUtil.getJsonVal(obj,"gj_aoiids_p","")
      val gd_aoicode = JSONUtil.getJsonVal(obj,"gd_aoicode","")
      val mapa_aoicode = JSONUtil.getJsonVal(obj,"mapa_aoicode","")
      val tc_aoicode = JSONUtil.getJsonVal(obj,"tc_aoicode","")
      val bd_aoicode = JSONUtil.getJsonVal(obj,"bd_aoicode","")
      var counts = 0
      if(!check_aoi_code.isEmpty && check_aoi_code == r_aoi){
        counts += 1
      }
      if(!check_aoi_code.isEmpty && raoiss.length > 4 && !raoiss.contains(",") && check_aoi_code == raoiss.split("\"")(1)){
        counts += 1
      }
      if(!check_aoi_id.isEmpty && check_aoi_id == gj_aoiid_t){
        counts += 1
      }
      if(!check_aoi_id.isEmpty && check_aoi_id == aoi_id_54){
        counts += 1
      }
      if(!check_aoi_id.isEmpty){
        val iter = Array(gd_aoiid,mapa_aoiid,tc_aoiid,bd_aoiid).iterator
        val list = new util.ArrayList[String]()
        var cnt = 0
        while (iter.hasNext){
          val it = iter.next()
          if(!it.isEmpty){
            list.add(it)
            cnt += 1
          }
        }
        if(cnt >= 2){
          val value = list.iterator()
          var cnt1 = 0
          while (value.hasNext){
            val str = value.next()
            if(str == check_aoi_id){
              cnt1 += 1
            }
          }
          if(cnt1 >= 2){
            counts += 1
          }
        }
      }
      if(!check_aoi_id.isEmpty && !gj_aoiids.isEmpty && gj_aoiids.contains(check_aoi_id)){
        var aoiid = ""
        if(gj_aoiids.contains(":")){
          if(gj_aoiids.contains(",")){
            aoiid = gj_aoiids.split(",").map(o => (o.split(":")(1).toInt,o.split(":")(0))).sorted.last._2
          }else{
            aoiid = gj_aoiids.split(":")(0)
          }
        }
        if(!gd_aoiid.isEmpty || !mapa_aoiid.isEmpty || !tc_aoiid.isEmpty || !bd_aoiid.isEmpty){
          if(!aoiid.isEmpty){
            if((aoiid == gd_aoiid || aoiid == mapa_aoiid || aoiid == tc_aoiid || aoiid == bd_aoiid) && (aoiid != check_aoi_id)){
              obj.put("check_aoi_id_tag","wrong")
            }else{
              counts += 1
            }
          }
        }else{
          counts += 1
        }
      }
      if(!check_aoi_id.isEmpty && !aoiids_54.isEmpty && aoiids_54.contains(check_aoi_id)){
        var aoiid = ""
        if(aoiids_54.contains(":")){
          if(aoiids_54.contains(",")){
            aoiid = aoiids_54.split(",").map(o => (o.split(":")(1).toInt,o.split(":")(0))).sorted.last._2
          }else{
            aoiid = aoiids_54.split(":")(0)
          }
        }
        if(!gd_aoiid.isEmpty || !mapa_aoiid.isEmpty || !tc_aoiid.isEmpty || !bd_aoiid.isEmpty){
          if(!aoiid.isEmpty){
            if((aoiid == gd_aoiid || aoiid == mapa_aoiid || aoiid == tc_aoiid || aoiid == bd_aoiid) && (aoiid != check_aoi_id)){
              obj.put("check_aoi_id_tag","wrong")
            }else{
              counts += 1
            }
          }
        }else{
          counts += 1
        }
      }
      if(!check_aoi_id.isEmpty && !gj_aoiids_p.isEmpty && gj_aoiids_p.contains(check_aoi_id)){
        var flag1 = "right"
        var flag2 = "right"
        if(!gd_aoiid.isEmpty || !mapa_aoiid.isEmpty || !tc_aoiid.isEmpty || !bd_aoiid.isEmpty){
          if(!gj_aoiids.isEmpty || !aoiids_54.isEmpty || !gj_aoiids_p.isEmpty ){
            val aoiids = gj_aoiids + "," + aoiids_54 + "," + gj_aoiids_p
            if(aoiids.contains(",")){
              val arr = aoiids.split(",")
              val iter = arr.iterator
              val list = new util.ArrayList[String]()
              while(iter.hasNext){
                val it = iter.next()
                if(!it.isEmpty){
                  if(it.contains(":")){
                    val id = it.split(":")(0)
                    if(id == gd_aoiid || id == mapa_aoiid || id == tc_aoiid || id == bd_aoiid){
                      list.add(id)
                    }
                  }
                }
              }
              var cnt = 0
              val iter_2 = list.iterator()
              while (iter_2.hasNext){
                val it = iter_2.next()
                if(it == check_aoi_id){
                  cnt += 1
                }
              }
              if(list != null &&  list.size() != cnt ){
                flag1 = "wrong"
              }
            }else{
              if(gj_aoiids.contains(":")){
                val aoiid = gj_aoiids.split(":")(0)
                if((aoiid == gd_aoiid || aoiid == mapa_aoiid || aoiid == tc_aoiid || aoiid == bd_aoiid) && (aoiid != check_aoi_id)){
                  flag1 = "wrong"
                }
              }
            }
          }
        }
        if(!gd_aoicode.isEmpty || !mapa_aoicode.isEmpty || !tc_aoicode.isEmpty || !bd_aoicode.isEmpty){
          if(!check_aoi_code.isEmpty && raoiss.length > 4){
            if(raoiss.contains(",")){
              val arr = raoiss.split(",")
              val iter = arr.iterator
              val list = new util.ArrayList[String]()
              while(iter.hasNext){
                val it = iter.next()
                if(it == gd_aoicode || it == mapa_aoicode || it == tc_aoicode || it == bd_aoicode){
                  list.add(it)
                }
              }
              var cnt = 0
              val iter_2 = list.iterator()
              while (iter_2.hasNext){
                val it = iter_2.next()
                if(it == check_aoi_code){
                  cnt += 1
                }
              }
              if(list != null &&  list.size() != cnt ){
                flag2 = "wrong"
              }
            }else{
              val aoiid = raoiss.split("\"")(1)
              if((aoiid == gd_aoicode || aoiid == mapa_aoicode || aoiid == tc_aoicode || aoiid == bd_aoicode) && (aoiid != check_aoi_code)){
                flag2 = "wrong"
              }
            }
          }
        }
        if(flag1 == "wrong" || flag2 == "wrong"){
          obj.put("check_aoi_id_tag","wrong")
        }else{
          counts += 1
        }
      }
      if(counts > 0) {
        obj.put("check_aoi_id_tag","right")
      }else{
        obj.put("check_aoi_id_tag","wrong")
      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>checkAoiTag共 ${checkAoiTag.count()} 条s<<<")
  checkAoiTag
  }

  /**
   * 保存打标后过滤前的数据
   * @param
   * @param
   */
  def saveResult_checkAoiTag(spark: SparkSession,checkAoiTag : RDD[JSONObject],parDay_1 : String): Unit ={
    val dr = "$"
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "legacy_error_pre_filter_data_tmp"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	*
         |from legacy_error_pre_filter_data_temp
         |""".stripMargin

    try{
      val schemaString = "req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t" +
        ",aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname" +
        ",bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord" +
        ",gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right" +
        ",result_flag,groupid,freq,gj_aoiids,aoiids_54,gj_aoiids_p,tag_aoiid,check_aoi_id,check_aoi_code,check_aoi_name,check_by,check_aoi_id_tag,flag"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = checkAoiTag.repartition(1).map(obj => {
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(obj,"req_address","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"citycode","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"finalzc","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoisrc","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"finalaoiid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"finalaoicode","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tag1","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tag2","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"r_aoi","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gj_aoiid_t","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gj_aoicode_t","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gj_aoiname_t","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_id_54","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_code_54","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoi_name_54","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gd_aoiid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gd_aoicode","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gd_aoiname","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"mapa_aoicode","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiname","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tc_aoiid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tc_aoicode","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tc_aoiname","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"bd_aoiid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"bd_aoicode","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"bd_aoiname","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"key_word","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_chkn","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_chkn","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_norm","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_norm","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gd_xcoord","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gd_ycoord","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tc_xcoord","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tc_ycoord","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"bd_xcoord","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"bd_ycoord","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"raois1","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"raois2","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"raoiss","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"raois3","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"is_aoiright","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"src_rightaoi","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoiid_right","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoicode_right","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"result_flag","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"groupid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"freq","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"aoiids_54","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids_p","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"tag_aoiid","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"check_aoi_id","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"check_aoi_code","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"check_aoi_name","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"check_by","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"check_aoi_id_tag","")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj,"flag","")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6)
        ,attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17),attr(18),attr(19),attr(20)
        ,attr(21),attr(22),attr(23),attr(24),attr(25),attr(26),attr(27),attr(28),attr(29),attr(30),attr(31),attr(32),attr(33),attr(34)
        ,attr(35),attr(36),attr(37),attr(38),attr(39),attr(40),attr(41),attr(42),attr(43),attr(44),attr(45),attr(46),attr(47),attr(48)
        ,attr(49),attr(50),attr(51),attr(52),attr(53),attr(54),attr(55),attr(56),attr(57),attr(58)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("legacy_error_pre_filter_data_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  /**
   * 过滤数据
   * check_aoi_id_tag=right
   * 1、keyword的最后一个字符存在于check_aoi_name中，check_aoi_name的keyword的最后一个字符’后面的字符中存在数字、字母、东、西、南、北
   * 2、keyword最后一个字符之前的字符至少有2个存在于check_aoi_name
   * 3、keyword不是xx路xx号，这种类型，，例如联裕路6号
   * keyword,check_aoi_name满足1和2和3，则check_aoi_id_tag值为multi
   * @return
   */
  def GetCheckRet_2(checkAoiTag : RDD[JSONObject]): RDD[JSONObject] ={
    val checkRet_2 = checkAoiTag.filter(obj => {
      val check_aoi_id_tag = JSONUtil.getJsonVal(obj,"check_aoi_id_tag","")
      check_aoi_id_tag == "right"
    }).map(obj => {
      val key_word = JSONUtil.getJsonVal(obj,"key_word","")
      val check_aoi_name = JSONUtil.getJsonVal(obj,"check_aoi_name","")
      if(key_word.length > 0){
        val last_char = key_word.substring(key_word.length - 1)
        if(check_aoi_name.contains(last_char)){
          val i = check_aoi_name.indexOf(last_char)
          if(i == check_aoi_name.length -1){
            obj.put("check_aoi_id_tag","right")
          }else{
            val str = check_aoi_name.substring(i+1)
            val regex = "[0-9a-z-A-Z东西南北一二三四]"
            val pattern = Pattern.compile(regex)
            if(pattern.matcher(str).lookingAt()){
              val str1 = key_word.substring(0,key_word.length - 1)
              val iter = str1.iterator
              var cnt = 0
              while (iter.hasNext){
                val it = iter.next()
                if (check_aoi_name.contains(it)){
                  cnt += 1
                }
              }
              if(cnt >=  2){
                if(!key_word.contains("路") && !key_word.contains("号")){
                  obj.put("check_aoi_id_tag","multi")
                }
              }
            }
          }
        }

      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>checkRet_2共 ${checkRet_2.count()} 条s<<<")
    checkRet_2
  }

  /**
   * 保存过滤后的数据
   * @param
   * @param
   */
  def saveResult(spark: SparkSession,ret : RDD[JSONObject],parDay_1 : String): Unit ={
    val dr = "$"
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "legacy_error_filter_data_tmp"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	*
         |from legacy_error_filter_data_temp
         |""".stripMargin

    val schemaString = "req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t" +
      ",aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname" +
      ",bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord" +
      ",gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right" +
      ",result_flag,groupid,freq,gj_aoiids,aoiids_54,gj_aoiids_p,tag_aoiid,check_aoi_id,check_aoi_code,check_aoi_name,check_by,check_aoi_id_tag"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
    )
    val schema = StructType(fields)
    val rdd = ret.repartition(1).map(obj => {
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(obj,"req_address","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"citycode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalzc","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoisrc","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalaoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalaoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag1","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag2","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"r_aoi","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiid_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoicode_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiname_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_id_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_code_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_name_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"key_word","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_chkn","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_chkn","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_norm","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_norm","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois1","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois2","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raoiss","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois3","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"is_aoiright","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"src_rightaoi","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_right","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_right","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"result_flag","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"groupid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"freq","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiids_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids_p","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_id","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_code","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_name","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_by","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_id_tag","")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6)
      ,attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17),attr(18),attr(19),attr(20)
      ,attr(21),attr(22),attr(23),attr(24),attr(25),attr(26),attr(27),attr(28),attr(29),attr(30),attr(31),attr(32),attr(33),attr(34)
      ,attr(35),attr(36),attr(37),attr(38),attr(39),attr(40),attr(41),attr(42),attr(43),attr(44),attr(45),attr(46),attr(47),attr(48)
      ,attr(49),attr(50),attr(51),attr(52),attr(53),attr(54),attr(55),attr(56),attr(57)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("legacy_error_filter_data_temp")
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }

  /**
   * 更新address的aoiid更新address的aoiid,新增结果字段：updateaoiid_result
   */
  def updateAddressAoiid(checkRet_2 : RDD[JSONObject]): RDD[JSONObject] ={
    val checkRet_3_1 = checkRet_2.filter(obj => {
      val check_aoi_id_tag = JSONUtil.getJsonVal(obj,"check_aoi_id_tag","")
      check_aoi_id_tag == "right"
    }).map(obj => {
      val cityCode = JSONUtil.getJsonVal(obj,"citycode","")
      val addressMd5 = JSONUtil.getJsonVal(obj,"groupid","")
      val aoiId = JSONUtil.getJsonVal(obj,"check_aoi_id","")
      val operSource = "SHOU_WRONG_SHENBU"
      val operUserName = JSONUtil.getJsonVal(obj,"check_by","")
      val lockCheck = 0
      val jsonObject = new JSONObject()
      jsonObject.put("cityCode", cityCode)
      jsonObject.put("addressMd5", addressMd5)
      jsonObject.put("aoiId", aoiId)
      jsonObject.put("operSource", operSource)
      jsonObject.put("operUserName", operUserName)
      jsonObject.put("aoiSource", "S93")
      jsonObject.put("lockCheck", lockCheck)
      val toJSONString = jsonObject.toJSONString
      val json : JSONObject = toUpdateAddressAoiid(update_address_aoiid,toJSONString)
      if(json != null){
        val success = JSONUtil.getJsonVal(json,"success","")
        val message = JSONUtil.getJsonVal(json,"message","")
        if(success == "true" || success == "True"){
          obj.put("updateaoiid_result","True")
        }else if (success == "false" || success == "False"){
          obj.put("updateaoiid_result",message)
        }else{
          obj.put("updateaoiid_result",json.toJSONString)
        }
      }else{
        obj.put("updateaoiid_result","null")
      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>checkRet_3_1共 ${checkRet_3_1.count()} 条s<<<")
    checkRet_3_1
  }

  /*def updateAddressAoiidTest(spark: SparkSession): RDD[JSONObject] ={
    val checkRet_3_1 = spark.sparkContext.parallelize(Array("1")).map(obj => {
      val json1 = new JSONObject()
      json1.put("obj",obj)
      val cityCode = "537"
      val addressMd5 = "4614909C2C75458E187A421AA9D2EBB8"
      val aoiId = "BED63100BCA24BF6AA7C1D7AA1C33D1C"
      val operSource = "SHOU_WRONG_SHENBU"
      val operUserName = "624376"
      val lockCheck = 0
      val jsonObject = new JSONObject()
      jsonObject.put("cityCode", cityCode)
      jsonObject.put("addressMd5", addressMd5)
      jsonObject.put("aoiId", aoiId)
      jsonObject.put("operSource", operSource)
      jsonObject.put("operUserName", operUserName)
      jsonObject.put("aoiSource", "S93")
      jsonObject.put("lockCheck", lockCheck)
      val toJSONString = jsonObject.toJSONString
      val json : JSONObject = toUpdateAddressAoiid(update_address_aoiid,toJSONString)
      if(json != null){
        val success = JSONUtil.getJsonVal(json,"success","")
        val message = JSONUtil.getJsonVal(json,"message","")
        if(success == "true" || success == "True"){
          json1.put("updateaoiid_result","True")
        }else if (success == "false" || success == "False"){
          json1.put("updateaoiid_result",message)
        }else{
          json1.put("updateaoiid_result",json.toJSONString)
        }
      }else{
        json1.put("updateaoiid_result","null")
      }
      json1
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>checkRet_3_1共 ${checkRet_3_1.count()} 条s<<<")
    checkRet_3_1
  }*/

  def updateAddressAoiid_1(checkAoiTag : RDD[JSONObject]): RDD[JSONObject] ={
    val checkRet_3_2 = checkAoiTag.filter(obj => {
      val check_aoi_id_tag = JSONUtil.getJsonVal(obj,"check_aoi_id_tag","")
      check_aoi_id_tag != "right"
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin_1) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val key_word = JSONUtil.getJsonVal(o,"key_word","")
        val json : JSONObject = getPoiXys(key_word)
        if(json != null){
          val x = JSONUtil.getJsonVal(json,"x","")
          val y = JSONUtil.getJsonVal(json,"y","")
          if(!x.isEmpty && !y.isEmpty){
            val resultObject_gd_dept = dept2(x,y)
            if(resultObject_gd_dept!=null){
              val resultObject_gd_dept2 = resultObject_gd_dept.getJSONObject("result")
              if(resultObject_gd_dept2!=null){
                val aoi_data = resultObject_gd_dept2.getJSONArray("aoi_data")
                if(aoi_data!=null && aoi_data.size()>0){
                  val aoi_data0 = aoi_data.getJSONObject(0)
                  if(aoi_data0!=null){
                    val gd_aoiid = aoi_data0.getString("aoi_id")
                    val gd_aoicode = aoi_data0.getString("aoi_code")
                    val gd_aoiname = aoi_data0.getString("aoi_name")
                    o.put("gdps_aoiid",gd_aoiid)
                    o.put("gdps_aoicode",gd_aoicode)
                    o.put("gdps_aoiname",gd_aoiname)
                  }
                }
              }
            }
          }
        }else{
          o.put("getPoiXys_result","null")
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).map(obj => {
      val check_aoi_id = JSONUtil.getJsonVal(obj,"check_aoi_id","")
      val gd_aoiid = JSONUtil.getJsonVal(obj,"gd_aoiid","")
      val mapa_aoiid = JSONUtil.getJsonVal(obj,"mapa_aoiid","")
      val tc_aoiid = JSONUtil.getJsonVal(obj,"tc_aoiid","")
      val bd_aoiid = JSONUtil.getJsonVal(obj,"bd_aoiid","")
      val aoi_id_mysql = JSONUtil.getJsonVal(obj,"aoi_id_mysql","")
      val arr = Array(gd_aoiid,mapa_aoiid,tc_aoiid,bd_aoiid)
      if(check_aoi_id.equals(gd_aoiid)){
        obj.put("updateAddressAoiid","right")
      }else if((!check_aoi_id.isEmpty && (gd_aoiid.isEmpty && mapa_aoiid.isEmpty && tc_aoiid.isEmpty && bd_aoiid.isEmpty)) || (!check_aoi_id.isEmpty && (arr.contains(check_aoi_id)))){
        obj.put("updateAddressAoiid","right")
      }else if(check_aoi_id.equals(aoi_id_mysql)){
        obj.put("updateAddressAoiid","right")
      }else{
        obj.put("updateAddressAoiid","wrong")
      }
      obj
    }).filter(obj => {
      val updateAddressAoiid = JSONUtil.getJsonVal(obj,"updateAddressAoiid","")
      updateAddressAoiid.equals("right")
    }).map(obj => {
      val cityCode = JSONUtil.getJsonVal(obj,"citycode","")
      val addressMd5 = JSONUtil.getJsonVal(obj,"groupid","")
      val aoiId = JSONUtil.getJsonVal(obj,"check_aoi_id","")
      val operSource = "SHOU_WRONG_SHENBU"
      val operUserName = JSONUtil.getJsonVal(obj,"check_by","")
      val lockCheck = 0
      val jsonObject = new JSONObject()
      jsonObject.put("cityCode", cityCode)
      jsonObject.put("addressMd5", addressMd5)
      jsonObject.put("aoiId", aoiId)
      jsonObject.put("operSource", operSource)
      jsonObject.put("operUserName", operUserName)
      jsonObject.put("aoiSource", "S95")
      jsonObject.put("lockCheck", lockCheck)
      val toJSONString = jsonObject.toJSONString
      val json : JSONObject = toUpdateAddressAoiid(update_address_aoiid,toJSONString)
      if(json != null){
        val success = JSONUtil.getJsonVal(json,"success","")
        val message = JSONUtil.getJsonVal(json,"message","")
        if(success == "true" || success == "True"){
          obj.put("updateaoiid_result","True")
        }else if (success == "false" || success == "False"){
          obj.put("updateaoiid_result",message)
        }else{
          obj.put("updateaoiid_result",json.toJSONString)
        }
      }else{
        obj.put("updateaoiid_result","null")
      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>checkRet_3_2共 ${checkRet_3_2.count()} 条s<<<")
    checkRet_3_2
  }

  def dept2(x:String, y:String): JSONObject ={
    var jsonObject:JSONObject = null
    /*val url = "http://gis-int.int.sfdc.com.cn:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=c2ee00ecb0164098b58569b5bdffe60d"
      .format(x, y)*/
    val url = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=c2ee00ecb0164098b58569b5bdffe60d"
      .format(x, y)
    breakable(
      for(i<-0.until(5)){
        try {
          jsonObject = HttpClientUtil.getJsonByGet(url)
          logger.error(">>>访问dept2：url=" + url + ", json="+jsonObject)
          Thread.sleep(350)
          if(jsonObject!=null){
            val status = jsonObject.getString("status")
            if("0".equalsIgnoreCase(status)) break
            else Thread.sleep(350)
          }
          if(i >= 4) break
        } catch {
          case e:Exception =>logger.error(">>>访问dept2异常："+e+",第" + i + "次, url=" + url + ", json="+jsonObject)
        }
      }
    )
    jsonObject
  }

  def getPoiXys(key_word: String) : JSONObject = {
    val reqObejct = new JSONObject()
    if (key_word.nonEmpty) {
      val res = getJsonByGet(String.format(poiUrl, URLEncoder.encode(key_word, "utf-8")))
      if (res != null) {
        val reqArray = JSONUtil.getJsonArrayMulti(res, "result.pois")
        if (reqArray != null && reqArray.size() > 0){
          val nObject = reqArray.getJSONObject(0)
          val xy = JSONUtil.getJsonVal(nObject, "location", "")
          val x = try {
            xy.split(",")(0)
          } catch {
            case exception: Exception => "0"
          }
          val y = try {
            xy.split(",")(1)
          } catch {
            case exception: Exception => "0"
          }
          reqObejct.put("x", x)
          reqObejct.put("y", y)
        }
      } else {
        reqObejct.put("getPoiXys_res","null")
      }
    }
    reqObejct
  }

  def getJsonByGet(url: String): JSONObject = {
    val httpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = null
    try {
      var httpResponse: CloseableHttpResponse = null
      val httpGet = new HttpGet(url)
      httpGet.addHeader("ak", "860aafa74c7846a3b4519f552851a5aa")
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity: HttpEntity = httpResponse.getEntity

        try {
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          try {
            jsonObj = JSON.parseObject(stringEntity)
          } catch {
            case e: Exception => logger.error(">>>结果转换json独享异常：" + e)
          }
        }
        catch {
          case e: Exception => logger.error(">>>获取stringEntity异常：" + e)
        }
      }
      httpResponse.close()
    } catch {
      case e: Exception => logger.error(">>>获取httpResponse异常：" + e)
    }
    httpClient.close()
    jsonObj
  }

  /**
   * 更新address的aoiid
   * @param url
   * @param toJSONString
   * @return
   */
  def toUpdateAddressAoiid(url: String,toJSONString: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!toJSONString.isEmpty) {
        val response = HttpInvokeUtil.sendPost(url, toJSONString, FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val success = JSONUtil.getJsonVal(rsJson,"success","")
            val message = JSONUtil.getJsonVal(rsJson,"message","")
            ret.put("success",success)
            ret.put("message",message)
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("toJSONString","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e)
    }
    ret
  }

  /**
   *
   * @param checkRet_3
   * @return
   */

  def updateAddressAdcode(checkRet_3 : RDD[JSONObject]): RDD[JSONObject] ={
    val checkRet_4 = checkRet_3.filter(obj => {
      val updateaoiid_result = JSONUtil.getJsonVal(obj,"updateaoiid_result","")
      updateaoiid_result == "True"
    }).map(obj => {
      val cityCode = JSONUtil.getJsonVal(obj,"citycode","")
      val groupid = JSONUtil.getJsonVal(obj,"groupid","")
      val list = new util.ArrayList[String]()
      list.add(groupid)
      //val aoiCheckTag = 4
      val aoiCheckTag = 6
      val jsonObject = new JSONObject()
      jsonObject.put("cityCode", cityCode)
      jsonObject.put("addressMd5s", list)
      jsonObject.put("aoiCheckTag", aoiCheckTag)
      val toJSONString = jsonObject.toJSONString
      val json : JSONObject = toUpdateAddressAdcode(update_address_md5aoicheck,toJSONString)
      if(json != null){
        val success = JSONUtil.getJsonVal(json,"success","")
        val message = JSONUtil.getJsonVal(json,"message","")
        if(success == "true" || success == "True"){
          obj.put("updateAddrAoiCheck_result","True")
        }else if(success == "false" || success == "False"){
          obj.put("updateAddrAoiCheck_result",message)
        }else{
          obj.put("updateAddrAoiCheck_result",json.toJSONString)
        }
      }else{
        obj.put("updateAddrAoiCheck_result","null")
      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>checkRet_4共 ${checkRet_4.count()} 条s<<<")
    checkRet_4
  }

  /**
   *
   * @param url
   * @param toJSONString
   * @return
   */
  def toUpdateAddressAdcode(url: String,toJSONString: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!toJSONString.isEmpty) {
        val response = HttpInvokeUtil.sendPost(url, toJSONString, FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val success = JSONUtil.getJsonVal(rsJson,"success","")
            val message = JSONUtil.getJsonVal(rsJson,"message","")
            ret.put("success",success)
            ret.put("message",message)
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("toJSONString","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e)
    }
    ret
  }

  def saveResult_1(spark: SparkSession,ret : RDD[JSONObject],parDay_1 : String): Unit ={
    val dr = "$"
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "legacy_error_result_data"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	*
         |from legacy_error_result_data_temp
         |""".stripMargin

    val schemaString = "req_address,citycode,finalzc,aoisrc,finalaoiid,finalaoicode,tag1,tag2,r_aoi,gj_aoiid_t,gj_aoicode_t,gj_aoiname_t" +
      ",aoi_id_54,aoi_code_54,aoi_name_54,gd_aoiid,gd_aoicode,gd_aoiname,mapa_aoiid,mapa_aoicode,mapa_aoiname,tc_aoiid,tc_aoicode,tc_aoiname" +
      ",bd_aoiid,bd_aoicode,bd_aoiname,key_word,aoiid_dispatch_chkn,aoicode_dispatch_chkn,aoiid_dispatch_norm,aoicode_dispatch_norm,gd_xcoord" +
      ",gd_ycoord,tc_xcoord,tc_ycoord,bd_xcoord,bd_ycoord,raois1,raois2,raoiss,raois3,is_aoiright,src_rightaoi,aoiid_right,aoicode_right" +
      ",result_flag,groupid,freq,gj_aoiids,aoiids_54,gj_aoiids_p,tag_aoiid,check_aoi_id,check_aoi_code,check_aoi_name,check_by,check_aoi_id_tag" +
      ",updateaoiid_result,updateaddraoicheck_result,gdps_aoiid,gdps_aoicode,gdps_aoiname"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
    )
    val schema = StructType(fields)
    val rdd = ret.repartition(1).map(obj => {
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(obj,"req_address","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"citycode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalzc","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoisrc","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalaoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"finalaoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag1","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag2","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"r_aoi","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiid_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoicode_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiname_t","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_id_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_code_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoi_name_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"mapa_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_aoiname","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"key_word","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_chkn","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_chkn","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_dispatch_norm","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_dispatch_norm","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gd_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tc_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_xcoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"bd_ycoord","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois1","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois2","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raoiss","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"raois3","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"is_aoiright","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"src_rightaoi","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiid_right","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoicode_right","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"result_flag","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"groupid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"freq","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"aoiids_54","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gj_aoiids_p","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"tag_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_id","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_code","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_name","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_by","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"check_aoi_id_tag","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"updateaoiid_result","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"updateAddrAoiCheck_result","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gdps_aoiid","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gdps_aoicode","")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj,"gdps_aoiname","")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6)
      ,attr(7),attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17),attr(18),attr(19),attr(20)
      ,attr(21),attr(22),attr(23),attr(24),attr(25),attr(26),attr(27),attr(28),attr(29),attr(30),attr(31),attr(32),attr(33),attr(34)
      ,attr(35),attr(36),attr(37),attr(38),attr(39),attr(40),attr(41),attr(42),attr(43),attr(44),attr(45),attr(46),attr(47),attr(48)
      ,attr(49),attr(50),attr(51),attr(52),attr(53),attr(54),attr(55),attr(56),attr(57),attr(58),attr(59),attr(60),attr(61),attr(62)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("legacy_error_result_data_temp")
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }
}
