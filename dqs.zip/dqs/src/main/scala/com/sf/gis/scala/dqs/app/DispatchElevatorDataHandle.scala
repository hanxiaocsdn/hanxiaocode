package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.text.DecimalFormat
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil, StringUtils}
import com.sf.gis.scala.dqs.util.{EDEUtil, HttpConnection, Util}
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients
import org.apache.http.message.BasicHeader
import org.apache.http.protocol.HTTP
import org.apache.http.util.EntityUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.util.control.Breaks.{break, breakable}


/**
 * Created by 01417629 on 2021/11/04.
 * 代码弃用-20220621
 */
//noinspection DuplicatedCode
object DispatchElevatorDataHandle {
  @transient lazy val logger: Logger = Logger.getLogger(DispatchElevatorDataHandle.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val url_splitResult = "http://gis-int.int.sfdc.com.cn:1080/atroad/api/split?address=%s&ak=3a191e7427e8470c86271a069411c66b&adcode=%s"
  val url_key_word = "http://gis-int.int.sfdc.com.cn:1080/iad/api/keyword?ak=3eb300d2e06947f7945cd02530a32fd2&address=%s&addrType=0"
  val url_std_splitResult = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh&showserver=true&tel=&mobile=&company=&contact=&jpStation="
  val url1 = "http://gis-int.int.sfdc.com.cn:1080/elevator/api/add?ak=379924356e8b444da83f04ebb1703f19&target=group&cityCode=%s&id=%s&isElevator=%s&isClimb=0&source=6&updateBy=01412989&updateReason=S100-外包核实"
  val url2 = "http://orion-gateway.sf-express.com/uac/oauth/token?grant_type=password&username=01412989&password=2989@Bdp"
  val url3 = "http://gis-int.int.sfdc.com.cn:1080/elevator/api/add?ak=379924356e8b444da83f04ebb1703f19&cityCode=%s&target=aoi&id=%s&isElevator=1&source=key&isClimb=0&keyword=%s&updateBy=01412989&updateReason=S100-外包核实"
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    /*//val list = getAdcode(spark,parDay_1)
    val list = List("四川省","安徽省","西藏自治区","内蒙古自治区","陕西省","山东省","河北省","广西壮族自治区","江西省","江苏省","天津市","云南省","青海省","湖南省","宁夏回族自治区","上海市","广东省")
    val iter = list.iterator
    while(iter.hasNext){
      val adcode = ""
      val province = iter.next()
      println("province: "+province)
      //线下文件，数据处理：使用地址删除,DT,(A-Z)DT,X(A-Z)DT,及后面全部字符，另存为Address
      val elevatorSpyinfo = getElevatorAddrSpyinfo(spark,parDay_1,adcode,province)
      elevatorSpyinfo.take(2).foreach(println)
      //address跑分词接口，拼接分词结果(split_rslt)
      val splitResult = getSplitResult(elevatorSpyinfo)
      splitResult.take(2).foreach(println)
      elevatorSpyinfo.unpersist()
      //地址跑关键词接口，获取关键词（key_word）
      val keyWord = getKeyWord(splitResult)
      keyWord.take(2).foreach(println)
      splitResult.unpersist()
      //数据打标
      val tagData = getTagData(keyWord)
      tagData.take(2).foreach(println)
      keyWord.unpersist()
      //微服务派件网点单元区域,跑分词，拼接分词结果（std_split）
      val stdSplit = getStaSplitResult(tagData)
      stdSplit.take(2).foreach(println)


      val stdSplitRes = getStaSplit(stdSplit)
      stdSplitRes.take(2).foreach(println)
      //写入Hive表dm_gis.elespy_group
      saveResult_1(spark,stdSplitRes,parDay_1)
      //调接口1和2
      val res = getInterfaceInfo1(spark,parDay_1,adcode,province)
      res.take(2).foreach(println)
      stdSplitRes.unpersist()

      //关键词入库
      val stdSplitRes1 = getStaSplit1(stdSplit)
      stdSplitRes1.take(2).foreach(println)
    }*/

    //线下文件，数据处理：使用地址删除,DT,(A-Z)DT,X(A-Z)DT,及后面全部字符，另存为Address
    val elevatorSpyinfo = getElevatorAddrSpyinfo(spark,parDay_1)
    elevatorSpyinfo.take(2).foreach(println)
    //address跑分词接口，拼接分词结果(split_rslt)
    val splitResult = getSplitResult(elevatorSpyinfo)
    splitResult.take(2).foreach(println)
    elevatorSpyinfo.unpersist()
    //地址跑关键词接口，获取关键词（key_word）
    val keyWord = getKeyWord(splitResult)
    keyWord.take(2).foreach(println)
    splitResult.unpersist()
    //数据打标
    val tagData = getTagData(keyWord)
    tagData.take(2).foreach(println)
    keyWord.unpersist()
    //微服务派件网点单元区域,跑分词，拼接分词结果（std_split）
    val stdSplit = getStaSplitResult(tagData)
    stdSplit.take(2).foreach(println)


    val stdSplitRes = getStaSplit(stdSplit)
    stdSplitRes.take(2).foreach(println)
    //写入Hive表dm_gis.elespy_group
    saveResult_1(spark,stdSplitRes,parDay_1)
    //调接口1和2
    val res = getInterfaceInfo1(spark,parDay_1)
    res.take(2).foreach(println)
    stdSplitRes.unpersist()

    //关键词入库
    val stdSplitRes1 = getStaSplit1(stdSplit)
    stdSplitRes1.take(2).foreach(println)
  }

  def getAdcode(spark: SparkSession,parDay_1 : String): List[String] ={
//    val sql =
//      s"""
//         |select
//         |	t1.adcode as adcode
//         |from
//         |(
//         |	SELECT
//         |		adcode
//         |	FROM default.elevator_addr_spyinfo_online_ljx
//         |	where update_day = '$parDay_1'
//         |	and adcode is not null and adcode <> ''
//         |	group by adcode
//         |) as t1
//         |
//         |left join
//         |
//         |(
//         |	select adcode from dm_gis.elespy_group where inc_day = '$parDay_1'
//         |) as t2
//         |
//         |on t1.adcode = t2.adcode
//         |
//         |where t2.adcode is null
//         |""".stripMargin
val sql =
s"""
   |select
   |	t1.adcode as adcode
   |from
   |(
   |	SELECT
   |		adcode
   |	FROM dm_gis.elevator_addr_spyinfo
   |	where adcode is not null and adcode <> ''
   |	group by adcode
   |) as t1
   |
   |left join
   |
   |(
   |	select adcode from dm_gis.elespy_group_new where inc_day = '$parDay_1' group by adcode
   |) as t2
   |
   |on t1.adcode = t2.adcode
   |
   |where t2.adcode is null
   |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val adcode = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>获取adcode共 ${adcode.count()} 条s<<<")
    val list = adcode.collect().map(_.getString("adcode")).toList
    list
  }

  def saveSourceData(spark: SparkSession): Unit ={
    val df = spark.read.option("header", "true").csv("hdfs://sfbdp1/user/01417629/upload/upload_file/beijing.csv")
    df.show(5)
    df.write.mode("overwrite").insertInto("dm_gis.elevator_addr_spyinfo_online_beijing")
  }

  /**
   * 线下文件，数据处理：使用地址删除,DT,(A-Z)DT,X(A-Z)DT,及后面全部字符，另存为Address
   * @param spark
   * @return
   */
  def getElevatorAddrSpyinfo(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |SELECT
         |	ecode
         |	,citycode as city_code
         |	,adcode
         |	,subdistrict
         |	,org_address
         |	,case when org_address regexp 'X[A-Z]DT' then split(org_address,'X[A-Z]DT')[0]
         |		when org_address regexp '[A-Z]DT' then split(org_address,'[A-Z]DT')[0]
         |		when org_address regexp 'DT' then split(org_address,'DT')[0]
         |    when org_address like '%#楼%' then regexp_replace(org_address,'#','号')
         |		else org_address end as address
         |	,lng
         |	,lat
         |	,level
         |	,station
         |FROM default.elevator_addr_spyinfo_online_ljx
         |where update_day = '$parDay_1'
         |""".stripMargin

    /*val sql =
      s"""
         |SELECT
         |	ecode
         |	,city_code
         |	,t1.adcode as adcode
         |	,subdistrict
         |	,org_address
         |	,case when address like '%#楼%' then regexp_replace(address,'#','号') else address end as address
         |	,long as lng
         |	,lat
         |	,level
         |	,station
         |FROM dm_gis.elevator_addr_spyinfo t1
         |
         |left join
         |
         |(
         |	select adcode from dm_gis.elespy_group_new group by adcode
         |) as t2
         |
         |on t1.adcode = t2.adcode
         |
         |left join
         |
         |(
         |  select
         |    dist_code,
         |    prov_name
         |  from
         |    dm_gis.dim_city_info_df
         |  where
         |    inc_day = '20230107'
         |) t3
         |
         |on t1.city_code = t3.dist_code
         |
         |where t2.adcode is null
         |and t3.prov_name = '$province'
         |""".stripMargin*/

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val elevatorSpyinfo = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>获取处理后的线下数据共 ${elevatorSpyinfo.count()} 条s<<<")
    elevatorSpyinfo
  }

  /**
   * address跑分词接口，拼接分词结果(split_rslt)
   * @param elevatorSpyinfo
   * @return
   */
  def getSplitResult(elevatorSpyinfo: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val splitResult = elevatorSpyinfo.map(obj => {
      val address = JSONUtil.getJsonVal(obj,"address","")
      //val city_code = JSONUtil.getJsonVal(obj,"city_code","")
      val adcode = JSONUtil.getJsonVal(obj,"adcode","")
      var json : JSONObject = null
      //json = getAddressSegmentation(url_splitResult,address,city_code)
      json = getAddressSegmentation(url_splitResult,address,adcode)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取拼接分词结果(split_rslt)共 ${splitResult.count()} 条s<<<")
    elevatorSpyinfo.unpersist()
    splitResult
  }

  /**
   * 地址跑关键词接口，获取关键词（key_word）
   * @param
   * @return
   */
  def getKeyWord(splitResult: RDD[(JSONObject,JSONObject)]): RDD[((JSONObject,JSONObject),JSONObject)] ={
    val keyWord = splitResult.map(obj => {
      val row = obj._1
      val address = JSONUtil.getJsonVal(row,"address","")
      var json : JSONObject = null
      json = getKeyWordInfo(url_key_word,address)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取关键词（key_word）共 ${keyWord.count()} 条s<<<")
    splitResult.unpersist()
    keyWord
  }

  /**
   * 数据打标
   * @param
   * @return
   */
  def getTagData(keyWord: RDD[((JSONObject,JSONObject),JSONObject)]): RDD[((JSONObject,JSONObject),JSONObject)] ={
    val tagData = keyWord.filter(obj => {
      var flag = false
      val row = obj._1._1
      val json1 = obj._1._2
      val json2 = obj._2
      val address = JSONUtil.getJsonVal(row,"address","")
      val splitResult = JSONUtil.getJsonVal(json1,"splitResult","")
      if (!address.contains("项目"))
      {
        if ((splitResult.contains("^114")) || (splitResult.contains("^214")))
        {
          json2.put("tag", "14级")
          flag = true
        }
        else if (splitResult.contains("大厦"))
        {
          json2.put("tag", "大厦")
          flag = true
        }
        else if (splitResult.contains("大楼"))
        {
          json2.put("tag", "大楼")
          flag = true
        }
        else if (splitResult.contains("综合楼"))
        {
          json2.put("tag", "综合楼")
          flag = true
        }
        else if (splitResult.contains("宾馆"))
        {
          json2.put("tag", "宾馆")
          flag = true
        }
        else if (splitResult.contains("酒店"))
        {
          json2.put("tag", "酒店")
          flag = true
        }
        else if ((splitResult.contains("村")) && (splitResult.contains("号")))
        {
          json2.put("tag", "村号")
          flag = true
        }
        else if ((splitResult.contains("弄")) && (splitResult.contains("号")))
        {
          json2.put("tag", "弄号")
          flag = true
        }
      }
      flag
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>数据打标共 ${tagData.count()} 条s<<<")
    keyWord.unpersist()
    tagData
  }

  /**
   *
   * @param url
   * @param address
   * @param city
   * @return
   */
  def getAddressSegmentation(url: String,address: String,city : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty && !city.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"),URLEncoder.encode(city,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getAddressSegmentation resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                //val addSplitInfo = result.getJSONArray("addSplitInfo")
                val addSplitInfo = result.getJSONArray("addrSplitInfo")
                if(addSplitInfo != null && addSplitInfo.size() > 0){
                  val sb = new StringBuilder
                  for(i<- 0 until addSplitInfo.size()){
                    val json = addSplitInfo.getJSONObject(i)
                    val name = json.getString("name")
                    val prop =json.getString("prop")
                    val level =json.getString("level")
                    if(i == (addSplitInfo.size() - 1)){
                      sb.append(name).append("^").append(prop).append(level)
                    }else{
                      sb.append(name).append("^").append(prop).append(level).append(",")
                    }
                  }
                  ret.put("splitResult",sb.toString())
                }else{
                  ret.put("addSplitInfo",null)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getAddressSegmentation status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("address_or_city",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param url
   * @param address
   * @param
   * @return
   */
  def getKeyWordInfo(url: String,address: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getKeyWordInfo resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val keyInfo = result.getJSONObject("keyInfo")
                if(keyInfo != null){
                  val key_word = JSONUtil.getJsonVal(keyInfo,"key_word","")
                  ret.put("key_word",key_word)
                }else{
                  ret.put("keyInfo",null)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getKeyWordInfo status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("address",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   * 微服务派件网点单元区域,跑分词，拼接分词结果（std_split）
   * @param
   * @return
   */
  def getStaSplitResult(tagData: RDD[((JSONObject,JSONObject),JSONObject)]): RDD[((((JSONObject,JSONObject),JSONObject),JSONObject),JSONObject)] ={
    val stdSplit = tagData.map(obj => {
      val row = obj._1._1
      val address = JSONUtil.getJsonVal(row,"address","")
      val city_code = JSONUtil.getJsonVal(row,"city_code","")
      var json : JSONObject = null
      json = getStdAddr(url_std_splitResult,address,city_code)
      (obj,json)
    }).map(obj => {
      val t1 = obj._1
      val json1 = t1._1._1
      val json2 = obj._2
      //val city_code = JSONUtil.getJsonVal(json1,"city_code","")
      val adcode = JSONUtil.getJsonVal(json1,"adcode","")
      val standardization = JSONUtil.getJsonVal(json2,"standardization","")
      var json : JSONObject = null
      //json = getAddressSegmentation(url_splitResult,standardization,city_code)
      json = getAddressSegmentation(url_splitResult,standardization,adcode)
      (obj,json)
    }).map(obj => {
      val json2 = obj._2
      val splitResult = JSONUtil.getJsonVal(json2,"splitResult","")
      if ((splitResult.contains("^114")) || (splitResult.contains("^214")))
      {
        json2.put("std_tag", "14级")
      }
      else if (splitResult.contains("大厦"))
      {
        json2.put("std_tag", "大厦")
      }
      else if (splitResult.contains("大楼"))
      {
        json2.put("std_tag", "大楼")
      }
      else if (splitResult.contains("综合楼"))
      {
        json2.put("std_tag", "综合楼")
      }
      else if (splitResult.contains("宾馆"))
      {
        json2.put("std_tag", "宾馆")
      }
      else if (splitResult.contains("酒店"))
      {
        json2.put("std_tag", "酒店")
      }
      else if ((splitResult.contains("村")) && (splitResult.contains("号")))
      {
        json2.put("std_tag", "村号")
      }
      else if ((splitResult.contains("弄")) && (splitResult.contains("号")))
      {
        json2.put("std_tag", "弄号")
      }
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取stdSplit共 ${stdSplit.count()} 条s<<<")
    tagData.unpersist()
    stdSplit
  }

  def getStaSplit(stdSplit: RDD[((((JSONObject,JSONObject),JSONObject),JSONObject),JSONObject)]): RDD[((((JSONObject,JSONObject),JSONObject),JSONObject),JSONObject)] ={
    val stdSplitRes = stdSplit.filter(obj => {
      var flag = false
      val json1 = obj._2
      val json2 = obj._1._1._2
      val std_tag = JSONUtil.getJsonVal(json1,"std_tag","")
      val std_splitResult = JSONUtil.getJsonVal(json1,"splitResult","")
      val tag = JSONUtil.getJsonVal(json2,"tag","")
      if(StringUtils.isNotBlank(std_tag)){
        flag = true
      }
      if((tag.contains("大厦") || tag.contains("大楼") || tag.contains("综合楼")) &&
        ((std_splitResult.contains("^19") && std_splitResult.contains("^111")) ||
          (std_splitResult.contains("^19") && std_splitResult.contains("^211")) ||
          (std_splitResult.contains("^29") && std_splitResult.contains("^111")) ||
          (std_splitResult.contains("^29") && std_splitResult.contains("^211")))){
        flag = true
      }
      flag
    }).distinct().persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取stdSplitRes共 ${stdSplitRes.count()} 条s<<<")
    stdSplit.unpersist()
    stdSplitRes
  }

  def getStaSplit1(stdSplit: RDD[((((JSONObject,JSONObject),JSONObject),JSONObject),JSONObject)]): RDD[(JSONObject,JSONObject,JSONObject,JSONObject)] ={
    val stdSplitRes1 = stdSplit.filter(obj => {
      var flag = false
      val json2 = obj._1._1._2
      val json3 = obj._1._2
      val tag = JSONUtil.getJsonVal(json2,"tag","")
      val aoiid = JSONUtil.getJsonVal(json3,"aoiid","")
      if(StringUtils.isNotBlank(tag) && StringUtils.isNotBlank(aoiid)){
        flag = true
      }
      flag
    }).distinct().map(row => {
      val city_code_json = row._1._1._1._1
      val key_word_json = row._1._1._2
      val groupid_json = row._1._2
      val city_code = JSONUtil.getJsonVal(city_code_json,"city_code","")
      val key_word = JSONUtil.getJsonVal(key_word_json,"key_word","")
      val key_word_new = key_word.replaceAll("\\|","")
      val aoiid = JSONUtil.getJsonVal(groupid_json,"aoiid","")
      var json : JSONObject = null
      json = getInterface2(url3,city_code,aoiid,key_word_new)
      val str = post(url2,new JSONObject(),"UTF-8","Basic R0lTLUFTUy1BT1MtQkRQLUVMRVY6YW9zQmRwRWxldiMyMDIy")
      var json1 = new JSONObject()
      var access_token = ""
      if(StringUtils.isNotBlank(str)){
        json1 = JSON.parseObject(str)
        access_token = JSONUtil.getJsonVal(json1,"access_token","")
      }
      val json2 = add2("aoi",city_code,aoiid,"1","0","key",key_word_new,access_token)
      (key_word_json,json,json1,json2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取stdSplitRes1共 ${stdSplitRes1.count()} 条s<<<")
    stdSplit.unpersist()
    stdSplitRes1
  }

  /**
   *
   * @param url
   * @param address
   * @param city
   * @return
   */
  def getStdAddr(url: String,address: String,city : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!address.isEmpty && !city.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(address,"utf-8"),URLEncoder.encode(city,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          logger.error("getStdAddr resp null. url: " + urls)
          ret.put("response",null)
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val tcs = result.getJSONArray("tcs")
                if(tcs != null & tcs.size() > 0){
                  val tcs_1 = JSON.parseObject(tcs.get(0).toString)
                  val groupid = JSONUtil.getJsonVal(tcs_1,"groupid","")
                  val aoiid = JSONUtil.getJsonVal(tcs_1,"aoiid","")
                  ret.put("groupid",groupid)
                  ret.put("aoiid",aoiid)
                }else{
                  ret.put("tcs",null)
                }
                val other = result.getJSONObject("other")
                if(other != null){
                  val normresp = other.getJSONObject("normresp")
                  if(normresp != null){
                    val result_1 = normresp.getJSONObject("result")
                    if(result_1 != null){
                      val addrSplitInfo = JSONUtil.getJsonVal(result_1,"addrSplitInfo","")
                      ret.put("addrSplitInfo",addrSplitInfo)
                      val splitResult = JSONUtil.getJsonVal(result_1,"splitResult","")
                      ret.put("splitResult",splitResult)
                      val geocoder = result_1.getJSONArray("geocoder")
                      if(geocoder != null & geocoder.size() > 0){
                        val geocoder_1 = JSON.parseObject(geocoder.get(0).toString)
                        val standardization = JSONUtil.getJsonVal(geocoder_1,"standardization","")
                        ret.put("standardization",standardization)
                      }else{
                        ret.put("geocoder",null)
                      }
                    }else{
                      ret.put("result_1",null)
                    }
                  }else{
                    ret.put("normresp",null)
                  }
                }else{
                  ret.put("other",null)
                }
              }else{
                ret.put("result",null)
              }
            }else {
              logger.error("getStdAddr status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson",null)
          }
        }
      }else{
        ret.put("address_or_city",null)
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param spark
   * @param stdSplit
   */
  def saveResult_1(spark : SparkSession,stdSplit : RDD[((((JSONObject,JSONObject),JSONObject),JSONObject),JSONObject)],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "elespy_group_new"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1',adcode)
         |select
         |	 t.groupid
         |	,t.ele
         |	,t.city_code
         |	,t.source
         |	,t.norm_address
         |	,t.aoiid
         | ,t.adcode
         |from
         |(
         |SELECT
         |	 groupid,ele,city_code,source,norm_address,aoiid,adcode,row_number() over(partition by groupid order by groupid) as rn
         |FROM elespy_group_temp
         |) as t
         |where t.rn = 1
         |""".stripMargin

    try{
      val schemaString = "groupid,ele,city_code,source,norm_address,aoiid,adcode"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true)
      )
      val schema = StructType(fields)
      val rdd = stdSplit.map(obj => {
        val row = obj._1._2
        val json = obj._1._1._1._1
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(row,"groupid","null")).append("\t\t\t")
        sb.append("1").append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"city_code","null")).append("\t\t\t")
        sb.append("std").append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"standardization","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"aoiid","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(json,"adcode","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("elespy_group_temp")
      //删除已有分区数据，然后插入最新数据
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  def getInterfaceInfo1(spark: SparkSession,parDay_1 : String): RDD[(JSONObject,JSONObject,JSONObject,JSONObject)] ={
    val sql =
      s"""
         |SELECT
         |	groupid,ele,city_code,source,norm_address,aoiid
         |FROM dm_gis.elespy_group_new
         |where inc_day = '$parDay_1'
         |""".stripMargin
/*val sql =
s"""
   |SELECT
   |	groupid,ele,city_code,source,norm_address,aoiid
   |FROM dm_gis.elespy_group_new t1
   |
   |left join
   |
   |(
   |  select
   |    dist_code,
   |    prov_name
   |  from
   |    dm_gis.dim_city_info_df
   |  where
   |    inc_day = '20230107'
   |) t2
   |
   |on t1.city_code = t2.dist_code
   |
   |where t1.inc_day = '$parDay_1' and t2.prov_name = '$province'
   |""".stripMargin*/
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val res = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>获取数据共 ${res.count()} 条s<<<")
    val res1 = res.map(row => {
      val city_code = JSONUtil.getJsonVal(row,"city_code","")
      val groupid = JSONUtil.getJsonVal(row,"groupid","")
      val ele = JSONUtil.getJsonVal(row,"ele","")
      var json : JSONObject = null
      json = getInterface1(url1,city_code,groupid,ele)
      val str = post(url2,new JSONObject(),"UTF-8","Basic R0lTLUFTUy1BT1MtQkRQLUVMRVY6YW9zQmRwRWxldiMyMDIy")
      val json1 = JSON.parseObject(str)
      val access_token = JSONUtil.getJsonVal(json1,"access_token","")
      val json2 = add2("group",city_code,groupid,"1","0","6","",access_token)
      (row,json,json1,json2)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>获取数据共 ${res1.count()} 条s<<<")
    res.unpersist()
    res1
  }

  /**
   *
   * @param url
   * @param
   * @param
   * @return
   */
  def getInterface1(url: String,city_code: String,groupid: String,ele: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!city_code.isEmpty && !groupid.isEmpty && !ele.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(city_code,"utf-8"),URLEncoder.encode(groupid,"utf-8"),URLEncoder.encode(ele,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response",null)
        }else{
          ret.put("response",response)
        }
      }else{
        ret.put("address || groupid || ele","")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  def getInterface2(url: String,city_code: String,groupid: String,keyWord: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!city_code.isEmpty && !groupid.isEmpty && !keyWord.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(city_code,"utf-8"),URLEncoder.encode(groupid,"utf-8"),URLEncoder.encode(keyWord,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response",null)
        }else{
          ret.put("response",response)
        }
      }else{
        ret.put("address || groupid || keyWord","")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  def post(url: String, json: JSON, encoding: String, token: String = ""): String = {
    var body = ""
    try {
      //创建httpclient对象
      val client = HttpClients.createDefault
      try { //创建post方式请求对象
        val httpPost = new HttpPost(url)
        //装填参数
        val s = new StringEntity(json.toString, "utf-8")
        s.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"))
        //设置参数到请求对象中
        httpPost.setEntity(s)
        //System.out.println("请求地址："+url);
        //设置header信息
        //指定报文头【Content-type】、【User-Agent】
        httpPost.setHeader("Content-type", "application/json")
        httpPost.setHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)")
        if (token.nonEmpty) httpPost.setHeader("Authorization", token)
        //执行请求操作，并拿到结果（同步阻塞）
        val response = client.execute(httpPost)
        //获取结果实体
        val entity = response.getEntity
        if (entity != null) { //按指定编码转换结果实体为String类型
          body = EntityUtils.toString(entity, encoding)
        }
        EntityUtils.consume(entity)
        //释放链接
        response.close()
      } finally if (client != null) client.close()
    }
    body
  }

  def add2(target:String, citycode:String, group_id:String, is_elevator:String, is_climb:String, source:String, keyword:String, token:String): JSONObject ={
    var jsonObject:JSONObject = null
    val baseUrl = "https://gis-orion-work.sf-express.com"
    val aoi_url = s"$baseUrl/work/api/aoiElevator/insert"
    val group_url = s"$baseUrl/work/api/groupElevator/insert"
    val keyword_url = s"$baseUrl/work/api/aoiKeywordElevator/insert"
    var url = ""
    if("aoi".equalsIgnoreCase(target)) {
      if("key".equalsIgnoreCase(source)) url = keyword_url
      else url = aoi_url
    }
    else if("group".equalsIgnoreCase(target)) url = group_url
    val header = "Authorization"
    val value = "Bearer " + token
    val params = new JSONObject()
    params.put("cityCode",citycode)
    params.put("updateReason","S100-外包核实")
    if(aoi_url.equals(url) || group_url.equals(url)){
      params.put("isClimb",is_climb)
      params.put("isElevator",is_elevator)
      params.put("source",source)
    }
    else if(keyword_url.equals(url)){
      params.put("climb",is_climb)
      params.put("elevator",is_elevator)
      params.put("keyword",keyword)
    }
    if(group_url.equals(url)){
      params.put("groupId",group_id)
    }
    else {
      params.put("aoiId",group_id)
    }
    breakable(
      for(i<-0.until(5)){
        try {
          jsonObject = Util.getJsonByPostJsonAddHeader(url, params.toString, header, value)
          Thread.sleep(100)
          if(jsonObject!=null){
            //            logger.error(">>>url:"+ url + " >>>params:"+ params.toString + " >>>result:"+ jsonObject.toJSONString + " >>>token:" + token)
            val success = jsonObject.getString("success")
            if("true".equalsIgnoreCase(success)) break
            else Thread.sleep(100)
          }
          else logger.error(">>>url:"+ url + " >>>params:"+ params.toString + " >>>result:null")
          if(i >= 4) break
        } catch {
          case e:Exception =>logger.error(">>>访问add2异常："+e+",第" + i + "次, url=" + url + ",params="+ params.toString + ", json="+jsonObject + " >>>token:" + token)
        }
      }
    )
    jsonObject
  }
}
