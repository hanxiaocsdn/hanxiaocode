package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.dqs.util.Util
import org.apache.commons.lang3.StringUtils
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet}
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}


/**
 * GIS-SDS-CORE：【壹竿-SD】54坐标外扩与高德一致修正地址aoi_V1.0
 * 需求方：郭本婕（01394694）
 *
 * @author 韩笑（01417629）
 *         Created on Mar.06 2023
 *         任务信息：（任务id:673188,54坐标外扩与高德一致修正地址aoi，每天6点0分执行、2023年3月7日--）
 *         代码弃用
 */
//noinspection DuplicatedCode
object CoordinateExtensionCorrectsAddressWithGDTest {
  @transient lazy val logger: Logger = Logger.getLogger(CoordinateExtensionCorrectsAddressWithGDTest.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val atconsignee_url = "http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&city=%s&mobile=%s&company=%s&ak=87106f6380af4df0845a693eee58843c&opt=zh&callDispatch=1&isNotUnderCall=1&needAoiArea=1&customerAccount=%s"
  val cms_norm_url = "http://gisasscmsbgintface-gis-ass-cms.dcn2.k8s.sfcloud.local:1080/cms/api/address/getAddrByCityCodeAndAddr?&addressId=%s&cityCode=%s"
  val cms_chk_url = "http://gisasscmsbgintface-gis-ass-cms.dcn2.k8s.sfcloud.local:1080/cms/api/address/getAddrByCityCodeAndAddr?&addressMd5=%s&cityCode=%s"
  val poiUrl = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/queryPoi?keywords=%s"
  val aoiUrl_54 = "http://gis-int.int.sfdc.com.cn:1080/dept2/info/aoi/radius?x=%s&y=%s&radius=5&ak=87106f6380af4df0845a693eee58843c"
  val aoiname_url = "http://gis-int2.int.sfdc.com.cn:1080/dept2/zctc/aoiid?&aoi_id=%s&ak=87106f6380af4df0845a693eee58843c"
  val reviewUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd"
  val updateRgsbAddrTcZc_url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/updateRgsbAddrTcZc"//
  val updateAddrAoiCheck_url = "http://gisasscmsbgintface-gis-ass-cms.dcn2.k8s.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck"
  val updateAddrMd5AoiCheck_url = "http://gisasscmsbgintface-gis-ass-cms.dcn2.k8s.sfcloud.local:1080/cms/api/address/updateAddrMd5AoiCheck"

  val limitMin = 50000 / 10
  val limitMin_1 = 1000 / 10
  val limitMin_2 = 10000 / 10

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0) //t-3分区
    val parDay_2 = args(1) //t-1分区
    val parDay_3 = args(2) //t-30分区
    run(spark, parDay_1, parDay_2, parDay_3)
    spark.close()
  }

  def get54Aoiid(checkRet: RDD[JSONObject]) = {
    val aoi_id_54 = checkRet.mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin_2) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val pick_lgt = JSONUtil.getJsonVal(o, "pick_lgt", "")
        val pick_lat = JSONUtil.getJsonVal(o, "pick_lat", "")
        val json: JSONObject = getAoiidInterface(aoiUrl_54, pick_lgt, pick_lat)
        //o.put("aoiUrl_54_resp",json)
        if (json != null) {
          val aoiid_54 = JSONUtil.getJsonVal(json, "54_aoiid", "")
          o.put("54_aoiid", aoiid_54)
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).filter(obj => {
      val aoiid = JSONUtil.getJsonVal(obj, "54_aoiid", "")
      aoiid.nonEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>aoi_id_54共 ${aoi_id_54.count()} 条s<<<")
    aoi_id_54
  }

  def run(spark: SparkSession, parDay_1: String, parDay_2: String, parDay_3: String): Unit = {
    println(parDay_1)
    println(parDay_2)
    println(parDay_3)
    //获取表【dm_gis.aoi_accuracy_address_clean_ts】前一周的数据（T-10到T-4）,且flag=2的groupid1,记作groupid2
    val groupidBc = getResTableGroupid(spark, parDay_2, parDay_3)
    //dm_gis.aoi_accuracy_54_aoiname_ret_bsp每T日凌晨6点跑数,取数条件：inc_day=T-3，tag1=wrong，按req_address去重。
    val checkRet = getCheckRet(spark, parDay_1)
    checkRet.take(2).foreach(println(_))
    //pick_lgt, pick_lat调坐标落AOI接口，外扩5米去获取第一个AOI，记为54_aoiid,54_aoiid不为空
    val aoiid_54 = get54Aoiid(checkRet)
    aoiid_54.take(2).foreach(println(_))
    checkRet.unpersist()
    //跑at收服务获取生产aoi_id和aoi_code和aoi_src和deptcode和groupid1
    val atConsigneeRes = getAtConsignee(aoiid_54)
    atConsigneeRes.take(2).foreach(println(_))
    aoiid_54.unpersist()
    //groupid1不为空
    val checkRet_2 = getCheckRet_2(atConsigneeRes, groupidBc)
    checkRet_2.take(2).foreach(println(_))
    //groupid1为空
    val checkRet_3 = getCheckRet_3(atConsigneeRes)
    checkRet_3.take(2).foreach(println(_))
    aoiid_54.unpersist()
    //groupid1不为空合并groupid1为空
    val checkRet_2_3 = checkRet_2.union(checkRet_3).persist(StorageLevel.MEMORY_AND_DISK)
    checkRet_2.unpersist()
    checkRet_3.unpersist()
    checkRet_2_3.take(2).foreach(println(_))
    //saveResult01(spark, checkRet_2_3, parDay_1)
    checkRet_2_3.unpersist()
  }

  def getResTableGroupid(spark: SparkSession, parDay_2: String, parDay_3: String): Broadcast[List[String]] = {
    val sql =
      s"""
         |select
         |  '' as groupid2
         |from dm_gis.aoi_accuracy_address_clean_ts
         |limit 10
         |""".stripMargin
    logger.error(sql)
    val ret = Util.getRowToJsonNew_1(spark, sql, 10)
    val list = ret.map(obj => obj.getString("groupid2")).collect().toList
    val groupidBc = spark.sparkContext.broadcast(list)
    groupidBc
  }

  def getCheckRet(spark: SparkSession, parDay_1: String): RDD[JSONObject] = {
    val dr = "$"
    val sql =
      s"""
         |select
         |	b.*
         |from
         |(
         |	select
         |		a.*,
         |		count(waybillno) over(partition by req_address) as freq,
         |		row_number() over(partition by req_address order by waybillno desc) as rank2
         |	from
         |	(
         |		select
         |			waybillno,
         |			src_order_no,
         |			isnotundercall,
         |			syssource,
         |			req_citycode,
         |			get_json_object(extra,'$dr.citycode') citycode,
         |			req_address,
         |			req_comp_name,
         |			case when get_json_object(extra, '$dr.phone') is not null and get_json_object(extra, '$dr.phone') <> '' then get_json_object(extra, '$dr.phone')
         |			     when get_json_object(extra, '$dr.mobile') is not null and get_json_object(extra, '$dr.mobile') <> '' then get_json_object(extra, '$dr.mobile')
         |			     end as phone,
         |			get_json_object(extra, '$dr.customeraccount') customeraccount,
         |			finalaoiid,
         |			finalaoicode,
         |			get_json_object(extra,'$dr.aoisrc') aoisrc,
         |			finalzc,
         |			groupid,
         |			pick_lgt,
         |			pick_lat
         |			--row_number() over(partition by src_order_no order by get_json_object(extra,'$dr.req_time') desc) as rank1
         |		from
         |		dm_gis.aoi_accuracy_54_aoiname_ret_bsp
         |		--where inc_day = '$parDay_1' and tag1 = 'wrong' and get_json_object(extra,'$dr.citycode') not in ('852', '853', '886')
         |		where inc_day = '$parDay_1' and tag1 in ('wrong','no') and get_json_object(extra,'$dr.citycode') not in ('852', '853', '886')
         |		and (pick_lgt <> '' and pick_lgt is not null)
         |  and src_order_no = 'CX2633652440809531'
         |	) a
         | --where a.rank1 = 1
         |) b where b.rank2 = 1
         |--limit 200
         |""".stripMargin
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: " + sql)
    val checkRet = Util.getRowToJsonNew_1(spark, sql, 1200)
    checkRet
  }

  def getAtConsignee(aoiid_54: RDD[JSONObject]): RDD[JSONObject] = {
    val atConsigneeRes = aoiid_54.mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val req_address = JSONUtil.getJsonVal(o, "req_address", "")
        val req_citycode = JSONUtil.getJsonVal(o, "req_citycode", "")
        val mobile = JSONUtil.getJsonVal(o, "phone", "")
        val req_comp_name = JSONUtil.getJsonVal(o, "req_comp_name", "")
        val customeraccount = JSONUtil.getJsonVal(o, "customeraccount", "")
        val urls = String.format(atconsignee_url, URLEncoder.encode(req_address, "utf-8")
          , URLEncoder.encode(req_citycode, "utf-8")
          , URLEncoder.encode(mobile, "utf-8")
          , URLEncoder.encode(req_comp_name, "utf-8")
          , URLEncoder.encode(customeraccount, "utf-8"))
        val json: JSONObject = HttpClientUtil.getJsonByGet(urls)
        if (json != null) {
          //o.put("atconsignee_url_response",json.toJSONString)
          val tcsObj = try {
            JSONUtil.getJsonArrayMulti(json, "result.tcs").getJSONObject(0)
          } catch {
            case exception: Exception => new JSONObject()
          }
          val aoiid = JSONUtil.getJsonVal(tcsObj, "aoiid", "")
          val aoicode = JSONUtil.getJsonVal(tcsObj, "aoicode", "")
          val atAoiSrc = JSONUtil.getJsonVal(tcsObj, "atAoiSrc", "")
          val dept = JSONUtil.getJsonVal(tcsObj, "dept", "")
          val groupid = JSONUtil.getJsonVal(tcsObj, "groupid", "")
          val chkId = JSONUtil.getJsonVal(json, "result.chkId", "")
          val atDisResult = JSONUtil.getJsonVal(json, "result.atDisResult", "")
          val disResultObj = try {
            JSON.parseObject(atDisResult)
          } catch {
            case exception: Exception => new JSONObject()
          }
          val disChkId = JSONUtil.getJsonVal(disResultObj, "chkId", "")
          if (atAoiSrc.equals("chk")) o.put("groupid1", chkId)
          else if (atAoiSrc.equals("dispatch-chkn")) o.put("groupid1", disChkId)
          else o.put("groupid1", groupid)
          o.put("deptcode", dept)
          o.put("aoi_id", aoiid)
          o.put("aoi_code", aoicode)
          o.put("aoi_src", atAoiSrc)
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>getAtConsignee共 ${atConsigneeRes.count()} 条s<<<")
    atConsigneeRes
  }

  def getCheckRet_2(atConsigneeRes: RDD[JSONObject], groupidBc: Broadcast[List[String]]): RDD[JSONObject] = {
    val checkRet2 = atConsigneeRes.filter(obj => {
      val groupid1 = JSONUtil.getJsonVal(obj, "groupid1", "")
      !groupid1.isEmpty
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val aoi_src = JSONUtil.getJsonVal(o, "aoi_src", "")
        val city_code = JSONUtil.getJsonVal(o, "req_citycode", "")
        val groupid1 = JSONUtil.getJsonVal(o, "groupid1", "")
        if (aoi_src.equals("norm") || aoi_src.equals("dispatch-norm") || aoi_src.equals("dispatch-normcompany") || aoi_src.equals("dispatch-normhp")) {
          val json: JSONObject = getCmsRetInterface(cms_norm_url, groupid1, city_code)
          if (json != null) {
            //o.put("cms_norm_url_resp",json)
            val std_address = JSONUtil.getJsonVal(json, "std_address", "")
            val adcode = JSONUtil.getJsonVal(json, "adcode", "")
            val znoCode = JSONUtil.getJsonVal(json, "znoCode", "")
            o.put("std_address", std_address)
            o.put("adcode", adcode)
            o.put("znoCode", znoCode)
          }
        }
        if (aoi_src.equals("chk") || aoi_src.equals("dispatch-chkn")) {
          val json: JSONObject = getCmsRetInterface(cms_chk_url, groupid1, city_code)
          if (json != null) {
            //o.put("cms_chk_url_resp",json)
            val std_address = JSONUtil.getJsonVal(json, "std_address", "")
            val adcode = JSONUtil.getJsonVal(json, "adcode", "")
            val znoCode = JSONUtil.getJsonVal(json, "znoCode", "")
            o.put("std_address", std_address)
            o.put("adcode", adcode)
            o.put("znoCode", znoCode)
          }
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).filter(obj => {
      val adcode = JSONUtil.getJsonVal(obj, "adcode", "")
      val aoi_id = JSONUtil.getJsonVal(obj, "aoi_id", "")
      val aoi_src = JSONUtil.getJsonVal(obj, "aoi_src", "")
      val arr = Array("4", "5", "6", "7", "8")
      !arr.contains(adcode) && !aoi_id.isEmpty && !aoi_src.equals("monthAcc")
    }).filter(obj => {
      val groupidList = groupidBc.value
      val groupid1 = JSONUtil.getJsonVal(obj, "groupid1", "")
      !groupidList.contains(groupid1)
    }).filter(obj => {
      val aoi_src = JSONUtil.getJsonVal(obj, "aoi_src", "")
      val arr = Array("chk", "dispatch-chkn", "dispatch-norm", "dispatch-normcompany", "dispatch-normhp")
      arr.contains(aoi_src)
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin_1) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val key_word = JSONUtil.getJsonVal(o, "std_address", "")
        val json: JSONObject = getPoiXys(key_word)
        if (json != null) {
          o.put("getPoiXys", json.toJSONString)
          val x = JSONUtil.getJsonVal(json, "x", "")
          val y = JSONUtil.getJsonVal(json, "y", "")
          if (!x.isEmpty && !y.isEmpty) {
            val resultObject_gd_dept = dept2(x, y)
            if (resultObject_gd_dept != null) {
              o.put("dept2", resultObject_gd_dept.toJSONString)
              val resultObject_gd_dept2 = resultObject_gd_dept.getJSONObject("result")
              if (resultObject_gd_dept2 != null) {
                val aoi_data = resultObject_gd_dept2.getJSONArray("aoi_data")
                if (aoi_data != null && aoi_data.size() > 0) {
                  val aoi_data0 = aoi_data.getJSONObject(0)
                  if (aoi_data0 != null) {
                    val gd_aoiid = aoi_data0.getString("aoi_id")
                    o.put("gd_aoiid", gd_aoiid)
                  }
                }
              }
            }
          }
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>getCheckRet_2共 ${checkRet2.count()} 条s<<<")
    checkRet2
  }

  def getCheckRet_3(checkAoi: RDD[JSONObject]): RDD[JSONObject] = {
    val checkRet3 = checkAoi.filter(obj => {
      val groupid1 = JSONUtil.getJsonVal(obj, "groupid1", "")
      groupid1.isEmpty
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin_1) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        //val key_word = JSONUtil.getJsonVal(o, "std_address", "")
        val key_word = JSONUtil.getJsonVal(o, "req_address", "")
        val json: JSONObject = getPoiXys(key_word)
        if (json != null) {
          o.put("getPoiXys", json.toJSONString)
          val x = JSONUtil.getJsonVal(json, "x", "")
          val y = JSONUtil.getJsonVal(json, "y", "")
          if (!x.isEmpty && !y.isEmpty) {
            val resultObject_gd_dept = dept2(x, y)
            if (resultObject_gd_dept != null) {
              o.put("dept2", resultObject_gd_dept.toJSONString)
              val resultObject_gd_dept2 = resultObject_gd_dept.getJSONObject("result")
              if (resultObject_gd_dept2 != null) {
                val aoi_data = resultObject_gd_dept2.getJSONArray("aoi_data")
                if (aoi_data != null && aoi_data.size() > 0) {
                  val aoi_data0 = aoi_data.getJSONObject(0)
                  if (aoi_data0 != null) {
                    val gd_aoiid = aoi_data0.getString("aoi_id")
                    o.put("gd_aoiid", gd_aoiid)
                  }
                }
              }
            }
          }
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>getCheckRet_3共 ${checkRet3.count()} 条s<<<")
    checkRet3
  }

  def getRet1(checkRet_2_3: RDD[JSONObject]): RDD[JSONObject] = {
    val ret1 = checkRet_2_3.filter(obj => {
      val gd_aoiid = JSONUtil.getJsonVal(obj, "gd_aoiid", "")
      gd_aoiid.isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>getRet1共 ${ret1.count()} 条s<<<")
    ret1
  }

  def getCheckRet_4(spark : SparkSession,parDay_1 : String): RDD[JSONObject] = {
    val sql =
      s"""
         |select * from dm_gis.aoi_accuracy_address_clean_ts_zhongjian where inc_day = '$parDay_1'
         |""".stripMargin
    val ret = Util.getRowToJsonNew_1(spark,sql,1200)
    val checkRet_4 = ret.filter(obj => {
      val gd_aoiid = JSONUtil.getJsonVal(obj, "gd_aoi", "")
      !gd_aoiid.isEmpty
    }).map(obj => {
      val gd_aoiid = JSONUtil.getJsonVal(obj, "gd_aoi", "")
      val aoiid_54 = JSONUtil.getJsonVal(obj, "aoiid_54", "")
      if (gd_aoiid.equals(aoiid_54)) {
        obj.put("gd_54_aoiid", gd_aoiid)
      }
      obj
    }).filter(obj => {
      val gd_54_aoiid = JSONUtil.getJsonVal(obj, "gd_54_aoiid", "")
      !gd_54_aoiid.isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>getCheckRet_4共 ${checkRet_4.count()} 条s<<<")
    checkRet_4
  }

  def gdEqualAoiidRes(ret: RDD[JSONObject]): RDD[JSONObject] = {
    val res = ret.filter(obj => {
      val gd_54_aoiid = JSONUtil.getJsonVal(obj, "gd_54_aoiid", "")
      val aoi_id = JSONUtil.getJsonVal(obj, "aoi_id", "")
      gd_54_aoiid.equals(aoi_id)
    }).map(obj => {
      obj.put("flag", "1")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>gdEqualAoiidRes共 ${res.count()} 条s<<<")
    res
  }

  def gdNoEqualAoiidRes(ret: RDD[JSONObject]): RDD[JSONObject] = {
    val res = ret.filter(obj => {
      val gd_54_aoiid = JSONUtil.getJsonVal(obj, "gd_54_aoiid", "")
      val aoi_id = JSONUtil.getJsonVal(obj, "aoi_id", "")
      !gd_54_aoiid.equals(aoi_id)
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val aoi_id = JSONUtil.getJsonVal(o, "aoi_id", "")
        val gd_54_aoiid = JSONUtil.getJsonVal(o, "gd_54_aoiid", "")
        val resultObject_aoiid1 = aoiid(aoi_id)
        //o.put("resultObject_aoiid1",resultObject_aoiid1)
        if (resultObject_aoiid1 != null) {
          val resultObject2 = resultObject_aoiid1.getJSONObject("result")
          if (resultObject2 != null) {
            val dataArray = resultObject2.getJSONArray("data")
            if (dataArray != null && dataArray.size() > 0) {
              val data0 = dataArray.getJSONObject(0)
              if (data0 != null) {
                val aoiname1 = data0.getString("aoi_name")
                o.put("aoiname1", aoiname1)
              }
            }
          }
        }
        val resultObject_aoiid2 = aoiid(gd_54_aoiid)
        //o.put("resultObject_aoiid2",resultObject_aoiid2)
        if (resultObject_aoiid2 != null) {
          val resultObject2 = resultObject_aoiid2.getJSONObject("result")
          if (resultObject2 != null) {
            val dataArray = resultObject2.getJSONArray("data")
            if (dataArray != null && dataArray.size() > 0) {
              val data0 = dataArray.getJSONObject(0)
              if (data0 != null) {
                val zc = data0.getString("zno_code")
                val aoiname1 = data0.getString("aoi_name")
                o.put("zc", zc)
                o.put("aoiname2", aoiname1)
              }
            }
          }
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).filter(obj => {
      val aoiname1 = JSONUtil.getJsonVal(obj, "aoiname1", "")
      val aoiname2 = JSONUtil.getJsonVal(obj, "aoiname2", "")
      val zc = JSONUtil.getJsonVal(obj, "zc", "")
      val deptcode = JSONUtil.getJsonVal(obj, "deptcode", "")
      val znoCode = JSONUtil.getJsonVal(obj, "znocode", "")
      !aoiname1.equals(aoiname2) && (zc.equals(deptcode) || zc.equals(znoCode))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>gdNoEqualAoiidRes共 ${res.count()} 条s<<<")
    res
  }

  def pushRgsbAdd(ret: RDD[JSONObject]): RDD[JSONObject] = {
    val res = ret.filter(obj => {
      val groupid1 = JSONUtil.getJsonVal(obj, "groupid1", "")
      groupid1.isEmpty
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        o.put("flag", "3")
        val req_citycode = JSONUtil.getJsonVal(o, "req_citycode", "")
        val zc = JSONUtil.getJsonVal(o, "zc", "")
        val gd_54_aoiid = JSONUtil.getJsonVal(o, "gd_54_aoiid", "")
        val req_address = JSONUtil.getJsonVal(o, "req_address", "")
        val (resp1, resp2) = doReviewDetail(req_citycode, req_address, zc, gd_54_aoiid)
        //o.put("resp2",resp2)
        if (resp2.nonEmpty) {
          val nObject = JSONUtil.parseStr2Json(resp2)
          val success = JSONUtil.getJsonVal(nObject, "success", "")
          val message = JSONUtil.getJsonVal(nObject, "message", "")
          val data = nObject.getJSONObject("data")
          if (data != null) {
            val addressMd5 = JSONUtil.getJsonVal(data, "addressMd5", "")
            o.put("groupid1", addressMd5)
          }
          if (success == "true" || success == "True") {
            o.put("updateaoiid_result", "True")
          } else if (success == "false" || success == "False") {
            o.put("updateaoiid_result", message)
          } else {
            o.put("updateaoiid_result", resp2)
          }
        } else {
          o.put("updateaoiid_result", "null")
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>pushRgsbAdd ${res.count()} 条s<<<")
    res
  }

  def pushRgsbAddrTcZc(ret: RDD[JSONObject]): RDD[JSONObject] = {
    val res = ret.filter(obj => {
      val groupid1 = JSONUtil.getJsonVal(obj, "groupid1", "")
      !groupid1.isEmpty
    }).map(obj => {
      obj.put("flag", "2")
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>pushRgsbAddrTcZc ${res.count()} 条s<<<")
    res
  }

  def doReviewDetail(cityCode: String, address: String, znoCode: String, aoiId: String): (String, String) = {
    val postParm = new JSONObject()
    postParm.put("ak", "7577390e76cc40b6ad6542640edd9d84")
    postParm.put("operSource", "54_gdps")
    postParm.put("operUserName", "01394694")
    val addressSave = new JSONObject()
    addressSave.put("cityCode", cityCode)
    addressSave.put("address", address)
    addressSave.put("znoCode", znoCode)
    addressSave.put("aoiId", aoiId)
    addressSave.put("type", 2)
    addressSave.put("src", 1)
    addressSave.put("aoiSource", "S99")
    postParm.put("addressSave", addressSave)
    var resp = ""
    try {
      resp = com.sf.gis.java.dqs.utils.Utils.post(reviewUrl, postParm, "utf-8")
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
    (postParm.toJSONString, resp)
  }

  def getPoiXys(key_word: String): JSONObject = {
    val reqObejct = new JSONObject()
    if (key_word.nonEmpty) {
      val res = getJsonByGet(String.format(poiUrl, URLEncoder.encode(key_word, "utf-8")))
      if (res != null) {
        val reqArray = JSONUtil.getJsonArrayMulti(res, "result.pois")
        if (reqArray != null && reqArray.size() > 0) {
          val nObject = reqArray.getJSONObject(0)
          val xy = JSONUtil.getJsonVal(nObject, "location", "")
          val x = try {
            xy.split(",")(0)
          } catch {
            case exception: Exception => "0"
          }
          val y = try {
            xy.split(",")(1)
          } catch {
            case exception: Exception => "0"
          }
          reqObejct.put("x", x)
          reqObejct.put("y", y)
        }
      } else {
        reqObejct.put("getPoiXys_res", "null")
      }
    }
    reqObejct
  }

  def dept2(x: String, y: String): JSONObject = {
    var jsonObject: JSONObject = null
    val url = "http://gis-int.int.sfdc.com.cn:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=87106f6380af4df0845a693eee58843c&geom=0"
      .format(x, y)
    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = HttpClientUtil.getJsonByGet(url)
          //logger.error(">>>访问dept2：url=" + url + ", json=" + jsonObject)
          Thread.sleep(350)
          if (jsonObject != null) {
            val status = jsonObject.getString("status")
            if ("0".equalsIgnoreCase(status)) break
            else Thread.sleep(350)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => //logger.error(">>>访问dept2异常：" + e + ",第" + i + "次, url=" + url + ", json=" + jsonObject)
        }
      }
    )
    jsonObject
  }

  def updateAddress(spark: SparkSession, ret: RDD[JSONObject]): RDD[JSONObject] = {
    val sql =
      s"""
         |select
         |  waybillno,src_order_no,isnotundercall,syssource,req_citycode,citycode,req_address,req_comp_name,phone,customeraccount
         |  ,finalaoiid,finalaoicode,aoisrc,finalzc,groupid,pick_lgt,pick_lat,freq,rank2,groupid1,deptcode,aoi_id,aoi_code,aoi_src,std_address
         |  ,adcode,znoCode,gd_aoiid,gd_54_aoiid,flag,aoiname1,zc,aoiname2,updateaoiid_result
         |from
         |(
         |	select *,row_number() over(partition by groupid1 order by groupid1) as rn from aoi_accuracy_address_clean_ts_temp where flag = '1'
         |) as t1
         |where t1.rn = 1
         |
         |union all
         |
         |select
         |  waybillno,src_order_no,isnotundercall,syssource,req_citycode,citycode,req_address,req_comp_name,phone,customeraccount,finalaoiid
         |  ,finalaoicode,aoisrc,finalzc,groupid,pick_lgt,pick_lat,freq,rank2,groupid1,deptcode,aoi_id,aoi_code,aoi_src,std_address,adcode,znoCode,gd_aoiid
         |  ,gd_54_aoiid,flag,aoiname1,zc,aoiname2,updateaoiid_result
         |from
         |(
         |	select *,row_number() over(partition by groupid1 order by groupid1) as rn from aoi_accuracy_address_clean_ts_temp where flag = '2'
         |) as t2
         |where t2.rn = 1
         |
         |union all
         |
         |select
         |  waybillno,src_order_no,isnotundercall,syssource,req_citycode,citycode,req_address,req_comp_name,phone,customeraccount,finalaoiid
         |  ,finalaoicode,aoisrc,finalzc,groupid,pick_lgt,pick_lat,freq,rank2,groupid1,deptcode,aoi_id,aoi_code,aoi_src,std_address,adcode,znoCode,gd_aoiid
         |  ,gd_54_aoiid,flag,aoiname1,zc,aoiname2,updateaoiid_result
         |from aoi_accuracy_address_clean_ts_temp where flag = '3'
       """.stripMargin
    val schemaString = "waybillno,src_order_no,isnotundercall,syssource,req_citycode,citycode,req_address,req_comp_name,phone,customeraccount,finalaoiid,finalaoicode" +
      ",aoisrc,finalzc,groupid,pick_lgt,pick_lat,freq,rank2,groupid1,deptcode,aoi_id,aoi_code,aoi_src,std_address,adcode" +
      ",znoCode,gd_aoiid,gd_54_aoiid,flag,aoiname1,zc,aoiname2,updateaoiid_result"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
    )
    val schema = StructType(fields)
    val rdd = ret.map(obj => {
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(obj, "waybillno", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "src_order_no", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "isnotundercall", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "syssource", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "req_citycode", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "citycode", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "req_address", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "req_comp_name", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "phone", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "customeraccount", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "finalaoiid", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "finalaoicode", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "aoisrc", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "finalzc", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "groupid", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "pick_lgt", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "pick_lat", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "freq", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "rank2", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "groupid1", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "deptcode", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "aoi_id", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "aoi_code", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "aoi_src", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "std_address", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "adcode", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "znocode", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "gd_aoi", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "gd_54_aoiid", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "flag", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "aoiname1", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "zc", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "aoiname2", "")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(obj, "updateaoiid_result", "")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4), attr(5), attr(6)
      , attr(7), attr(8), attr(9), attr(10), attr(11), attr(12), attr(13), attr(14), attr(15), attr(16), attr(17), attr(18), attr(19), attr(20)
      , attr(21), attr(22), attr(23), attr(24), attr(25), attr(26), attr(27), attr(28), attr(29), attr(30), attr(31), attr(32), attr(33)))
    val df = spark.createDataFrame(rdd, schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("aoi_accuracy_address_clean_ts_temp")
    val logRdd = Util.getRowToJsonNew_1(spark, sql, 10)
    val rdd1 = logRdd.mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val city_code = JSONUtil.getJsonVal(o, "req_citycode", "")
        val zc = JSONUtil.getJsonVal(o, "zc", "")
        val aoisrc = JSONUtil.getJsonVal(o, "aoi_src", "")
        val groupid1 = JSONUtil.getJsonVal(o, "groupid1", "")
        val gd_54_aoiid = JSONUtil.getJsonVal(o, "gd_54_aoiid", "")
        val req_address = JSONUtil.getJsonVal(o, "req_address", "")
        val flag = JSONUtil.getJsonVal(o, "flag", "")
        val jsonObject = new JSONObject()
        if (flag.equals("1")) {
          if (aoisrc.equals("norm") || aoisrc.equals("dispatch-norm") || aoisrc.equals("dispatch-normcompany") || aoisrc.equals("dispatch-normhp")) {
            jsonObject.put("cityCode", city_code)
            jsonObject.put("aoiCheckTag", 7)
            jsonObject.put("addressIds", Array(groupid1))
            val toJSONString = jsonObject.toJSONString
            val json: JSONObject = updateAoiCheck(updateAddrAoiCheck_url, toJSONString)
            //o.put("updateAddrAoiCheck_url_flag_1",json.toJSONString)
            if (json != null) {
              val success = JSONUtil.getJsonVal(json, "success", "")
              val message = JSONUtil.getJsonVal(json, "message", "")
              if (success == "true" || success == "True") {
                o.put("updateaoicheck_result", "True")
              } else if (success == "false" || success == "False") {
                o.put("updateaoicheck_result", message)
              } else {
                o.put("updateaoicheck_result", json.toJSONString)
              }
            } else {
              o.put("updateaoicheck_result", "null")
            }
          }
          if (aoisrc.equals("chk") || aoisrc.equals("dispatch-chkn") || flag.equals("3")) {
            jsonObject.put("cityCode", city_code)
            jsonObject.put("aoiCheckTag", 7)
            jsonObject.put("addressMd5s", Array(groupid1))
            val toJSONString = jsonObject.toJSONString
            val json: JSONObject = updateAoiCheck(updateAddrMd5AoiCheck_url, toJSONString)
            //o.put("updateAddrMd5AoiCheck_url_flag_1",json.toJSONString)
            if (json != null) {
              val success = JSONUtil.getJsonVal(json, "success", "")
              val message = JSONUtil.getJsonVal(json, "message", "")
              if (success == "true" || success == "True") {
                o.put("updateaoicheck_result", "True")
              } else if (success == "false" || success == "False") {
                o.put("updateaoicheck_result", message)
              } else {
                o.put("updateaoicheck_result", json.toJSONString)
              }
            } else {
              o.put("updateaoicheck_result", "null")
            }
          }

        }
        if (flag.equals("2")) {
          if (aoisrc.equals("norm") || aoisrc.equals("dispatch-norm") || aoisrc.equals("dispatch-normcompany") || aoisrc.equals("dispatch-normhp")) {
            val resultObject = updateNormAddrTcZc(city_code, groupid1, zc, gd_54_aoiid)
            //o.put("resultObject",resultObject.toJSONString)
            if (resultObject != null) {
              val success = JSONUtil.getJsonVal(resultObject, "success", "")
              val message = JSONUtil.getJsonVal(resultObject, "message", "")
              if (success == "true" || success == "True") {
                o.put("updateaoiid_result", "True")
              } else if (success == "false" || success == "False") {
                o.put("updateaoiid_result", message)
              } else {
                o.put("updateaoiid_result", resultObject.toJSONString)
              }
            } else {
              o.put("updateaoiid_result", "null")
            }
          }
          if (aoisrc.equals("chk") || aoisrc.equals("dispatch-chkn")) {
            val resultObject1 = updateRgsbAddrTcZc1(city_code, groupid1, zc, gd_54_aoiid)
            //o.put("resultObject1",resultObject1.toJSONString)
            if (resultObject1 != null) {
              val success = JSONUtil.getJsonVal(resultObject1, "success", "")
              val message = JSONUtil.getJsonVal(resultObject1, "message", "")
              if (success == "true" || success == "True") {
                o.put("updateaoiid_result", "True")
              } else if (success == "false" || success == "False") {
                o.put("updateaoiid_result", message)
              } else {
                o.put("updateaoiid_result", resultObject1.toJSONString)
              }
            } else {
              o.put("updateaoiid_result", "null")
            }
          }
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      val arrayBuffer = new ArrayBuffer[JSONObject]()
      while (obj.hasNext) {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            //logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val o = obj.next()
        val city_code = JSONUtil.getJsonVal(o, "req_citycode", "")
        val zc = JSONUtil.getJsonVal(o, "zc", "")
        val aoisrc = JSONUtil.getJsonVal(o, "aoi_src", "")
        val groupid1 = JSONUtil.getJsonVal(o, "groupid1", "")
        val gd_54_aoiid = JSONUtil.getJsonVal(o, "gd_54_aoiid", "")
        val req_address = JSONUtil.getJsonVal(o, "req_address", "")
        val flag = JSONUtil.getJsonVal(o, "flag", "")
        val updateaoiid_result = JSONUtil.getJsonVal(o, "updateaoiid_result", "")
        val jsonObject = new JSONObject()
        if (updateaoiid_result.equals("True")) {
          if (aoisrc.equals("norm") || aoisrc.equals("dispatch-norm") || aoisrc.equals("dispatch-normcompany") || aoisrc.equals("dispatch-normhp")) {
            jsonObject.put("cityCode", city_code)
            jsonObject.put("aoiCheckTag", 7)
            jsonObject.put("addressIds", Array(groupid1))
            val toJSONString = jsonObject.toJSONString
            val json: JSONObject = updateAoiCheck(updateAddrAoiCheck_url, toJSONString)
            //o.put("updateAddrAoiCheck_url_flag_3",json.toJSONString)
            if (json != null) {
              val success = JSONUtil.getJsonVal(json, "success", "")
              val message = JSONUtil.getJsonVal(json, "message", "")
              if (success == "true" || success == "True") {
                o.put("updateaoicheck_result", "True")
              } else if (success == "false" || success == "False") {
                o.put("updateaoicheck_result", message)
              } else {
                o.put("updateaoicheck_result", json.toJSONString)
              }
            } else {
              o.put("updateaoicheck_result", "null")
            }
          }
          if (aoisrc.equals("chk") || aoisrc.equals("dispatch-chkn") || flag.equals("3")) {
            jsonObject.put("cityCode", city_code)
            jsonObject.put("aoiCheckTag", 7)
            jsonObject.put("addressMd5s", Array(groupid1))
            val toJSONString = jsonObject.toJSONString
            val json: JSONObject = updateAoiCheck(updateAddrMd5AoiCheck_url, toJSONString)
            //o.put("updateAddrMd5AoiCheck_url_flag_3",json.toJSONString)
            if (json != null) {
              val success = JSONUtil.getJsonVal(json, "success", "")
              val message = JSONUtil.getJsonVal(json, "message", "")
              if (success == "true" || success == "True") {
                o.put("updateaoicheck_result", "True")
              } else if (success == "false" || success == "False") {
                o.put("updateaoicheck_result", message)
              } else {
                o.put("updateaoicheck_result", json.toJSONString)
              }
            } else {
              o.put("updateaoicheck_result", "null")
            }
          }
        }
        arrayBuffer.append(o)
      }
      arrayBuffer.iterator
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>rdd1 ${rdd1.count()} 条s<<<")
    rdd1
  }

  def updateNormAddrTcZc(cityCode: String, groupid1: String, zc: String, gd_54_aoiid: String): JSONObject = {
    var jsonObject: JSONObject = null
    val url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/updateNormAddrTcZc"
    val json = new JSONObject()
    json.put("ak", "3eb300d2e06947f7945cd02530a32fd2")
    json.put("operSource", "gd_aoi")
    json.put("operUserName", "01394694")
    val addressUpdate = new JSONObject()
    addressUpdate.put("cityCode", cityCode)
    addressUpdate.put("addressId", groupid1)
    addressUpdate.put("znoCode", zc)
    addressUpdate.put("aoiId", gd_54_aoiid)
    json.put("addressUpdate", addressUpdate)

    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = com.sf.gis.scala.dqs.util.HttpClientUtil.getJsonByPostJson(url, json.toJSONString)
          Thread.sleep(100)
          if (jsonObject != null) {
            val code = jsonObject.getString("success")
            if ("true".equalsIgnoreCase(code)) break
            else Thread.sleep(100)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => //logger.error(">>>访问updateNormAddrTcZc：url" + i + "=" + url + ", json=" + json + ", result=" + jsonObject)
        }
      }
    )
    jsonObject
  }

  def updateRgsbAddrTcZc1(cityCode: String, groupid1: String, zc: String, gd_54_aoiid: String): JSONObject = {
    var jsonObject: JSONObject = null
    val url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/updateRgsbAddrTcZc"
    val json = new JSONObject()
    json.put("ak", "3eb300d2e06947f7945cd02530a32fd2")
    json.put("operSource", "gd_aoi")
    json.put("operUserName", "01394694")
    val addressUpdate = new JSONObject()
    addressUpdate.put("cityCode", cityCode)
    addressUpdate.put("addressMd5", groupid1)
    addressUpdate.put("znoCode", zc)
    addressUpdate.put("aoiId", gd_54_aoiid)
    json.put("addressUpdate", addressUpdate)

    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = com.sf.gis.scala.dqs.util.HttpClientUtil.getJsonByPostJson(url, json.toJSONString)
          Thread.sleep(100)
          if (jsonObject != null) {
            val code = jsonObject.getString("success")
            if ("true".equalsIgnoreCase(code)) break
            else Thread.sleep(100)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => //logger.error(">>>访问updateRgsbAddrTcZc1：url" + i + "=" + url + ", json=" + json + ", result=" + jsonObject)
        }
      }
    )
    jsonObject
  }

  def updateAoiCheckRes1(ret: RDD[JSONObject]): RDD[JSONObject] = {
    val res = ret.filter(obj => {
      val gd_54_aoiid = JSONUtil.getJsonVal(obj, "gd_54_aoiid", "")
      val aoi_id = JSONUtil.getJsonVal(obj, "aoi_id", "")
      !gd_54_aoiid.equals(aoi_id)
    }).mapPartitions(obj => {
      var cnt = 0
      var startTime = System.currentTimeMillis()
      obj.foreach(o => {
        cnt = cnt + 1
        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if (endTime < 60000) {
            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime)
            Thread.sleep(60000 - endTime)
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }
        val aoi_id = JSONUtil.getJsonVal(o, "aoi_id", "")
        val gd_54_aoiid = JSONUtil.getJsonVal(o, "gd_54_aoiid", "")
        val resultObject_aoiid1 = aoiid(aoi_id)
        if (resultObject_aoiid1 != null) {
          o.put("aoiid_result", resultObject_aoiid1.toJSONString)
          val resultObject2 = resultObject_aoiid1.getJSONObject("result")
          if (resultObject2 != null) {
            val dataArray = resultObject2.getJSONArray("data")
            if (dataArray != null && dataArray.size() > 0) {
              val data0 = dataArray.getJSONObject(0)
              if (data0 != null) {
                val zc = data0.getString("zno_code")
                val aoiname1 = data0.getString("aoi_name")
                o.put("aoiname1", aoiname1)
              }
            }
          }
        }
        val resultObject_aoiid2 = aoiid(gd_54_aoiid)
        if (resultObject_aoiid2 != null) {
          o.put("aoiid_result", resultObject_aoiid2.toJSONString)
          val resultObject2 = resultObject_aoiid2.getJSONObject("result")
          if (resultObject2 != null) {
            val dataArray = resultObject2.getJSONArray("data")
            if (dataArray != null && dataArray.size() > 0) {
              val data0 = dataArray.getJSONObject(0)
              if (data0 != null) {
                val zc = data0.getString("zno_code")
                val aoiname1 = data0.getString("aoi_name")
                o.put("zc", zc)
                o.put("aoiname2", aoiname1)
              }
            }
          }
        }
      })
      obj
    }).filter(obj => {
      val aoiname1 = JSONUtil.getJsonVal(obj, "aoiname1", "")
      val aoiname2 = JSONUtil.getJsonVal(obj, "aoiname2", "")
      val zc = JSONUtil.getJsonVal(obj, "zc", "")
      val deptcode = JSONUtil.getJsonVal(obj, "deptcode", "")
      val znoCode = JSONUtil.getJsonVal(obj, "znoCode", "")
      !aoiname1.equals(aoiname2) && (zc.equals(deptcode) || zc.equals(znoCode))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s">>>res ${res.count()} 条s<<<")
    ret.unpersist()
    res
  }

  def aoiid(aoiid: String): JSONObject = {
    if (StringUtils.isEmpty(aoiid)) return null
    var jsonObject: JSONObject = null
    val url = "http://gis-int2.int.sfdc.com.cn:1080/dept2/zctc/aoiid?aoi_id=%s&ak=87106f6380af4df0845a693eee58843c"
      .format(aoiid)
    breakable(
      for (i <- 0.until(5)) {
        try {
          jsonObject = HttpClientUtil.getJsonByGet(url)
          //logger.error(">>>访问aoiid：url=" + url + ", json=" + jsonObject)
          Thread.sleep(450)
          if (jsonObject != null) {
            val code = jsonObject.getString("status")
            if ("0".equalsIgnoreCase(code)) break
            else Thread.sleep(450)
          }
          if (i >= 4) break
        } catch {
          case e: Exception => //logger.error(">>>访问aoiid异常：" + e + ",第" + i + "次, url=" + url + ", json=" + jsonObject)
        }
      }
    )
    jsonObject
  }

  def updateAoiCheck(url: String, toJSONString: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!toJSONString.isEmpty) {
        val response = HttpInvokeUtil.sendPost(url, toJSONString, FixedConstant.MAX_TRY_TIME_ONCE)
        if (response != null) {
          ret = JSONUtil.parseStr2Json(response)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }

  def getCmsRetInterface(url: String, groupid: String, city_code: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!groupid.isEmpty && !city_code.isEmpty) {
        val urls = String.format(url, URLEncoder.encode(groupid, "utf-8"), URLEncoder.encode(city_code, "utf-8"))
        val response = HttpClientUtil.getJsonByGet(urls)
        if (response == null) {
          ret.put("response", "null")
        } else {
          val code = response.getInteger("code")
          if (code != null && code == 200) {
            val data = response.getJSONObject("data")
            if (data != null) {
              val address = JSONUtil.getJsonVal(data, "address", "")
              val adcode = JSONUtil.getJsonVal(data, "adcode", "")
              val znoCode = JSONUtil.getJsonVal(data, "znoCode", "")
              ret.put("std_address", address)
              ret.put("adcode", adcode)
              ret.put("znoCode", znoCode)
            }
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception", e)
    }
    ret
  }

  def getAoiidInterface(url: String, x: String, y: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!x.isEmpty && !y.isEmpty) {
        val urls = String.format(url, URLEncoder.encode(x, "utf-8"), URLEncoder.encode(y, "utf-8"))
        val response = HttpClientUtil.getJsonByGet(urls)
        if (response == null) {
          ret.put("response", "null")
        } else {
          val status = response.getInteger("status")
          if (status == 0) {
            val result = response.getJSONObject("result")
            if (result != null) {
              val data = result.getJSONObject("data")
              if (data != null) {
                val aois = data.getJSONArray("aois")
                if (aois != null && aois.size() > 0) {
                  val aoi_json = aois.getJSONObject(0)
                  val aoi_id = JSONUtil.getJsonVal(aoi_json, "aoi_id", "")
                  ret.put("54_aoiid", aoi_id)
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => //logger.error(e)
    }
    ret
  }

  def saveResult(spark: SparkSession, ret: RDD[JSONObject], parDay_1: String): Unit = {
    val dr = "$"
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "aoi_accuracy_address_clean_ts"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	*
         |from aoi_accuracy_address_clean_ts_temp
         |""".stripMargin

    try {
      val schemaString = "waybillno,src_order_no,isnotundercall,syssource,req_citycode,citycode,req_address,req_comp_name,phone,customeraccount,finalaoiid" +
        ",finalaoicode" +
        ",aoisrc,finalzc,groupid,pick_lgt,pick_lat,freq,rank2,groupid1,deptcode,aoi_id,aoi_code,aoi_src,std_address,adcode" +
        ",znoCode,gd_aoiid,gd_54_aoiid,flag,aoiname1,zc,aoiname2,updateaoiid_result,updateaoicheck_result"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
      )
      val schema = StructType(fields)
      val rdd = ret.repartition(1).map(obj => {
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(obj, "waybillno", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "src_order_no", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "isnotundercall", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "syssource", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "req_citycode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "citycode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "req_address", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "req_comp_name", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "phone", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "customeraccount", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "finalaoiid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "finalaoicode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoisrc", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "finalzc", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "groupid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "pick_lgt", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "pick_lat", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "freq", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "rank2", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "groupid1", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "deptcode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoi_id", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoi_code", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoi_src", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "std_address", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "adcode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "znoCode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "gd_aoiid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "gd_54_aoiid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "flag", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoiname1", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "zc", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoiname2", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "updateaoiid_result", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "updateaoicheck_result", "")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4), attr(5), attr(6)
        , attr(7), attr(8), attr(9), attr(10), attr(11), attr(12), attr(13), attr(14), attr(15), attr(16), attr(17), attr(18), attr(19), attr(20)
        , attr(21), attr(22), attr(23), attr(24), attr(25), attr(26), attr(27), attr(28), attr(29), attr(30), attr(31), attr(32), attr(33), attr(34)))
      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("aoi_accuracy_address_clean_ts_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: " + insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  def saveResult01(spark: SparkSession, ret: RDD[JSONObject], parDay_1: String): Unit = {
    val dr = "$"
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "aoi_accuracy_address_clean_ts_zhongjian"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	*
         |from aoi_accuracy_address_clean_ts_temp
         |""".stripMargin

    try {
      val schemaString = "waybillno,src_order_no,isnotundercall,syssource,req_citycode,citycode,req_address,req_comp_name,phone,customeraccount,finalaoiid" +
        ",finalaoicode" +
        ",aoisrc,finalzc,groupid,pick_lgt,pick_lat,freq,rank2,groupid1,deptcode,aoi_id,aoi_code,aoi_src,std_address,adcode" +
        ",znoCode,gd_aoiid,gd_54_aoiid,query_poi_result,byxy_result"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true)
      )
      val schema = StructType(fields)
      val rdd = ret.repartition(1).map(obj => {
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(obj, "waybillno", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "src_order_no", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "isnotundercall", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "syssource", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "req_citycode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "citycode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "req_address", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "req_comp_name", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "phone", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "customeraccount", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "finalaoiid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "finalaoicode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoisrc", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "finalzc", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "groupid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "pick_lgt", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "pick_lat", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "freq", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "rank2", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "groupid1", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "deptcode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoi_id", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoi_code", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "aoi_src", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "std_address", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "adcode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "znoCode", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "gd_aoiid", "")).append("\t\t\t")
        //sb.append(JSONUtil.getJsonVal(obj, "gd_54_aoiid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "54_aoiid", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "getPoiXys", "")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(obj, "dept2", "")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4), attr(5), attr(6)
        , attr(7), attr(8), attr(9), attr(10), attr(11), attr(12), attr(13), attr(14), attr(15), attr(16), attr(17), attr(18), attr(19), attr(20)
        , attr(21), attr(22), attr(23), attr(24), attr(25), attr(26), attr(27), attr(28), attr(29), attr(30)))
      val df = spark.createDataFrame(rdd, schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("aoi_accuracy_address_clean_ts_temp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: " + insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }

  def getJsonByGet(url: String): JSONObject = {
    val httpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = null
    try {
      var httpResponse: CloseableHttpResponse = null
      val httpGet = new HttpGet(url)
      httpGet.addHeader("ak", "860aafa74c7846a3b4519f552851a5aa")
      httpResponse = httpClient.execute(httpGet)
      if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
        val httpEntity: HttpEntity = httpResponse.getEntity

        try {
          val stringEntity = EntityUtils.toString(httpEntity, "UTF-8")
          try {
            jsonObj = JSON.parseObject(stringEntity)
          } catch {
            case e: Exception => logger.error(">>>结果转换json独享异常：" + e)
          }
        }
        catch {
          case e: Exception => logger.error(">>>获取stringEntity异常：" + e)
        }
      }
      httpResponse.close()
    } catch {
      case e: Exception => logger.error(">>>获取httpResponse异常：" + e)
    }
    httpClient.close()
    jsonObj
  }

}
