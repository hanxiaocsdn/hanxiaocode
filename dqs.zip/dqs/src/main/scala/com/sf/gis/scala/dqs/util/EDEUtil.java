package com.sf.gis.scala.dqs.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 加解密工具类
 * @author 01370539 created on Aug.19 2021
 */
public class EDEUtil {
    private static final Logger logger = LoggerFactory.getLogger(EDEUtil.class);

	public static void main(String[] args) throws Exception{
        //System.out.println(DigestUtils.md5Hex("广东省深圳市龙岗区南湾街道上李郎村第二工业区F栋五楼海威讯电子有限公司"));
		System.out.println(EDEUtil.enAndDeSimple("123.456789"));
	}

	/**
	 * 简单加密解密算法 执行一次加密，两次解密
	 */
	public static String enAndDeSimple(String inStr) {

		char[] a = inStr.toCharArray();
		for (int i = 0; i < a.length; i++) {
			a[i] = (char) (a[i] ^ 'e');
		}
		return  new String(a);
	}

}
