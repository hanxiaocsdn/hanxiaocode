package com.sf.gis.scala.dqs.app

import java.net.URLEncoder
import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * Created by 01417629 on 2021/11/04.
 * 代码弃用
 */
//noinspection DuplicatedCode
object NonRecipientAddressStatisticsReport {
  @transient lazy val logger: Logger = Logger.getLogger(NonRecipientAddressStatisticsReport.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val url = "http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?x=%s&y=%s&aoiId=%s&type=side"

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)//t-1
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println("############################"+parDay_1)
    //lbs_no_receiver_address_80_info关联esg_gis_loc_trajectory，获取坐标
    val lbsNoReceiverAddress = getLbsNoReceiverAddress(spark,parDay_1)
    lbsNoReceiverAddress.take(2).foreach(println(_))
    //获取小哥 pop_time正负3分钟的轨迹点
    val lbsNoReceiverTracks = getLbsNoReceiverAddressTracks(lbsNoReceiverAddress)
    lbsNoReceiverTracks.take(2).foreach(println(_))
    lbsNoReceiverAddress.unpersist()
    //每一个轨迹点距离收方AOI的最小直线距离
    val minDistance = getLbsNoReceiverTracksMinDistance(lbsNoReceiverTracks)
    minDistance.take(2).foreach(println(_))
    lbsNoReceiverTracks.unpersist()
    saveResult(spark,minDistance,parDay_1)
    minDistance.unpersist()
  }

  /**
   * lbs_no_receiver_address_80_info关联esg_gis_loc_trajectory，获取坐标
   * @param spark
   * @return
   */
  def getLbsNoReceiverAddress(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	t1.*
         |	,t2.xy_tm_list
         |from
         |(
         |	SELECT waybill_no,hq_code,hq_name,area_code,area_name,dept_code,dept_name,dept_type,pop_time,emp_aoi,emp_aoi_name,aoi_id,aoi_name,distance,employee_id,tracks_x,tracks_y,is_aoi_side,is_aoi_side_200,is_area_check_new,new_dir1,new_dir2,new_dir3,account_code,customer_business_type,dialogcontent,unix_timestamp(pop_time) - 180 as pop_time_3,unix_timestamp(pop_time) + 180 as pop_time_add_3
         |	FROM dm_gis.lbs_no_receiver_address_80_info where inc_day='$parDay_1'
         |) as t1
         |
         |left join
         |(
         |	select
         |		un,cast(collect_list(x_y_tm) as string) as xy_tm_list
         |	from
         |	(
         |	SELECT un,zx,zy,tm,concat_ws(':',zx,zy,tm) as x_y_tm FROM dm_gis.esg_gis_loc_trajectory where inc_day='$parDay_1' and ak = '1'
         |	) as a group by un
         |) as t2
         |
         |on t1.employee_id = t2.un
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val lbsNoReceiverAddress = Util.getRowToJson(spark,sql,1200)
    logger.error(s">>>lbs_no_receiver_address_80_info关联esg_gis_loc_trajectory，获取坐标 ${lbsNoReceiverAddress.count()} 条s<<<")
    lbsNoReceiverAddress
  }

  /**
   * 获取小哥 pop_time正负3分钟的轨迹点
   * @param lbsNoReceiverAddress
   * @return
   */
  def getLbsNoReceiverAddressTracks(lbsNoReceiverAddress : RDD[JSONObject]) : RDD[JSONObject] = {
    val lbsNoReceiverAddressTracks = lbsNoReceiverAddress.map(obj => {
      val pop_time_3 = JSONUtil.getJsonVal(obj,"pop_time_3","").toLong
      val pop_time_add_3 = JSONUtil.getJsonVal(obj,"pop_time_add_3","").toLong
      val xy_tm_list = JSONUtil.getJsonVal(obj,"xy_tm_list","")
      val list = new util.ArrayList[String]()
      if(xy_tm_list.length > 2){
        val iter = xy_tm_list.substring(1,xy_tm_list.length - 1).split(",").iterator
        while (iter.hasNext){
          val it = iter.next()
          val arr = it.split(":")
          if(arr.length > 2){
            val tm = arr(2).toLong
            if(tm > pop_time_3 && tm < pop_time_add_3){
              //pop_time正负3分钟的轨迹点
              list.add(it)
            }
          }
        }
      }
      obj.put("tracks_list",list.toString)
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>lbsNoReceiverAddressTracks共 ${lbsNoReceiverAddressTracks.count()} 条s<<<")
    lbsNoReceiverAddressTracks
  }

  /**
   * 每一个轨迹点距离收方AOI的最小直线距离
   * @param lbsNoReceiverTracks
   * @return
   */
  def getLbsNoReceiverTracksMinDistance(lbsNoReceiverTracks : RDD[JSONObject]) : RDD[JSONObject] = {
    val minDistance = lbsNoReceiverTracks.map(obj => {
      val aoi_id = JSONUtil.getJsonVal(obj,"aoi_id","")
      val tracks_list = JSONUtil.getJsonVal(obj,"tracks_list","")
      val list = new util.ArrayList[Double]()
      if(tracks_list.length > 2){
        val iter = tracks_list.substring(1,tracks_list.length - 1).split(",").iterator
        while (iter.hasNext){
          val it = iter.next()
          val arr = it.split(":")
          if(arr.length > 2){
            val x = arr(0)
            val y = arr(1)
            val json = getTracksMinDistance(url,x,y,aoi_id)
            val data = JSONUtil.getJsonVal(json,"data","")
            if(!data.isEmpty){
              list.add(data.toDouble)
            }
          }
        }
      }
      val iters = list.iterator()
      var temp = 10000000.0
      while (iters.hasNext){
        val it = iters.next()
        if(it < temp){
          temp = it
        }
      }
      obj.put("min_distance",temp)
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>minDistance共 ${minDistance.count()} 条s<<<")
    minDistance
  }

  def getTracksMinDistance(url: String,x: String,y : String,aoi_id : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!x.isEmpty && !y.isEmpty && !aoi_id.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(x,"utf-8"),URLEncoder.encode(y,"utf-8"),URLEncoder.encode(aoi_id,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        if(response == null){
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val code = rsJson.getInteger("code")
            if(code != null && rsJson.getInteger("code") == 200){
              val data = JSONUtil.getJsonVal(rsJson,"data","")
              ret.put("data",data)
            }else {
              ret.put("code","!=200")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("x_y_aoi_id","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param
   * @param
   */
  def saveResult(spark : SparkSession,minDistance : RDD[JSONObject],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "lbs_no_receiver_address_80_info"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |  *
         |from lbs_no_receiver_address_80_info_tmp
         |""".stripMargin

    val schemaString = "waybill_no,hq_code,hq_name,area_code,area_name,dept_code,dept_name,dept_type,pop_time,emp_aoi" +
      ",emp_aoi_name,aoi_id,aoi_name,distance,employee_id,tracks_x,tracks_y,is_aoi_side,is_aoi_side_200,is_area_check_new" +
      ",new_dir1,new_dir2,new_dir3,account_code,customer_business_type,dialogcontent,min_distance"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
    val schema = StructType(fields)
    val rdd = minDistance.repartition(10).map(obj => {
      val row = obj
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(row,"waybill_no","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"hq_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"hq_name","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"area_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"area_name","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dept_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dept_name","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dept_type","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"pop_time","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"emp_aoi","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"emp_aoi_name","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"aoi_id","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"aoi_name","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"min_distance","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"employee_id","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"tracks_x","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"tracks_y","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"is_aoi_side","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"is_aoi_side_200","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"is_area_check_new","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"new_dir1","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"new_dir2","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"new_dir3","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"account_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"customer_business_type","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dialogcontent","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"distance","null")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6),attr(7)
      ,attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17),attr(18),attr(19),attr(20)
      ,attr(21),attr(22),attr(23),attr(24),attr(25),attr(26)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("lbs_no_receiver_address_80_info_tmp")
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }
}
