package com.sf.gis.scala.dqs.app

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.HttpInvokeUtil
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.dqs.util.Util
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 特殊入仓识别-特殊入仓识别报表需求
 * Created by 01417629 on 2021/11/04.
 * 任务id: 426860
 * 代码弃用
 */
//noinspection DuplicatedCode
object SpecialWarehousingReportCraft {
  @transient lazy val logger: Logger = Logger.getLogger(SpecialWarehousingReportCraft.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //val diff_url = "http://gis-int2.int.sfdc.com.cn:1080/diff/api/vas?address=%s&citycode=%s&opt=sw&ak=9c1d529c40f54877a9a6372e686fee47"
  val diff_url = "http://gis-apis.int.sfcloud.local:1080/diff/api/vas?address=%s&citycode=%s&opt=sw&ak=9c1d529c40f54877a9a6372e686fee47"
  val addrDecrypt_url = "http://gisasscmsbg-gis-ass-cms.dcn2.k8s.sf-express.com/cms/api/address/addrDecrypt?address=%s"
  val similar_url = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getSimilar?ak=9c1d529c40f54877a9a6372e686fee47&beforeAddress=%s&afterAddress=%s"

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    val parDay_1 = args(0)
    run(spark,parDay_1)
    spark.close()
  }

  /**
   *
   * @param spark
   */
  def run(spark: SparkSession,parDay_1 : String): Unit ={
    println("############################"+parDay_1)
    //从BDP平台dwd.dwd_waybill_info_dtl_di表取数（t-1）
    val waybillInfoIncDay = getWaybillInfoIncDay(spark,parDay_1)
    waybillInfoIncDay.take(2).foreach(println(_))
    //加密地址解密
    val addrDecryptApi = getaddrDecryptApi(waybillInfoIncDay)
    addrDecryptApi.take(2).foreach(println(_))
    //waybillInfoIncDay跑diff特殊入仓接口
    val diffApiIncDay = getDiffApi(addrDecryptApi)
    diffApiIncDay.take(2).foreach(println(_))
    //dwd.dwd_waybill_info_dtl_di关联dm_gis.tel_library_unrecognized_res
    val diffApiIncDayJoin = getDiffApiJoin(spark,diffApiIncDay,parDay_1)
    diffApiIncDayJoin.take(2).foreach(println(_))
    //识别完成，增加字段source，source=normal。增加字段Matchtype，matchtype=1
    val diffApiIncDayNormal = getDiffApiIncDayNormal(diffApiIncDayJoin)
    diffApiIncDayNormal.take(2).foreach(println(_))
    //基于相同的区域代码，进行地址相似度评估
    val diffApiIncDaySimilar = getDiffApiIncDaySimilar(diffApiIncDayJoin)
    diffApiIncDaySimilar.take(2).foreach(println(_))
    //matchtype != "1"且 没关联到area_code的数据
    val diffApiIncDayNone = getDiffApiIncDayNone(diffApiIncDayJoin)
    diffApiIncDayNone.take(2).foreach(println(_))
    //将最终结果存入hive表
    val diffApiIncDayRes = diffApiIncDayNormal.union(diffApiIncDaySimilar).union(diffApiIncDayNone).persist(StorageLevel.DISK_ONLY)
    diffApiIncDayRes.take(2).foreach(println(_))
    saveResult(spark,diffApiIncDayRes,parDay_1)
    diffApiIncDayRes.unpersist()
    diffApiIncDaySimilar.unpersist()
    diffApiIncDayJoin.unpersist()
    diffApiIncDay.unpersist()
  }

  def getaddrDecryptApi(waybillInfo: RDD[JSONObject]): RDD[(JSONObject,JSONObject)] ={
    val addrDecryptApi = waybillInfo.map(obj => {
      val consignee_addr = obj.getString("consignee_addr")
      val json = getaddrDecryptInteface(addrDecrypt_url,consignee_addr)
      (obj,json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>加密地址解密 ${addrDecryptApi.count()} 条s<<<")
    waybillInfo.unpersist()
    addrDecryptApi
  }

  def getDiffApiJoin(spark : SparkSession,diffApiIncDay: RDD[((JSONObject,JSONObject),JSONObject)],parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |select
         |	 t1.*
         |	,t2.area_code as area_code_tel
         |	,t2.norm_address as norm_address_tel
         |from
         |(
         |SELECT
         |	 waybill_no
         |	,dest_zone_code
         |	,addressee_dept_code
         |	,dest_division_code
         |	,dest_area_code
         |	,dest_dist_code
         |	,dest_city_code
         |	,dest_county
         |	,meterage_weight_qty
         |	,real_weight_qty
         |	,consigned_tm
         |	,limit_type_code
         |	,consignee_addr
         |	,consignee_phone
         |	,service_prod_code
         |	,cons_name
         |   ,data as decrypt_addr
         |	,matchtype
         |FROM dwd_waybill_info_dtl_di_tmp
         |) as t1
         |left join
         |(
         |SELECT
         |	  area_code
         |     ,norm_address
         |FROM dm_gis.specialstorage_baseaddress_suyun
         |WHERE inc_day = '$parDay_1'
         |group by
         |  area_code
         |     ,norm_address
         |) as t2
         |on t1.dest_zone_code = t2.area_code
         |""".stripMargin
    val schemaString = "waybill_no,dest_zone_code,addressee_dept_code,dest_division_code,dest_area_code,dest_dist_code" +
      ",dest_city_code,dest_county,meterage_weight_qty,real_weight_qty,consigned_tm,limit_type_code,consignee_addr" +
      ",consignee_phone,service_prod_code,cons_name,data,matchtype"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
    val schema = StructType(fields)
    val rdd = diffApiIncDay.map(obj => {
      val row = obj._1._1
      val json1 = obj._1._2
      val json2 = obj._2
      val sb = new StringBuilder()
      sb.append(JSONUtil.getJsonVal(row,"waybill_no","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dest_zone_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"addressee_dept_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dest_division_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dest_area_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dest_dist_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dest_city_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"dest_county","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"meterage_weight_qty","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"real_weight_qty","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"consigned_tm","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"limit_type_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"consignee_addr","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"consignee_phone","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"service_prod_code","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(row,"cons_name","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(json1,"data","null")).append("\t\t\t")
      sb.append(JSONUtil.getJsonVal(json2,"matchtype","null")).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6),attr(7)
      ,attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17)))
    val df = spark.createDataFrame(rdd,schema)
    df.printSchema()
    df.show(5)
    df.createOrReplaceTempView("dwd_waybill_info_dtl_di_tmp")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>关联sql: "+sql)
    val diffApiIncDayJoin = Util.getRowToJson(spark,sql,10)
    diffApiIncDayJoin
  }

  def getaddrDecryptInteface(url: String,consignee_addr: String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!consignee_addr.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(consignee_addr,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response)
        if(response == null){
          logger.error("getaddrDecryptInteface resp null. url: " + urls)
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val code = rsJson.getInteger("code")
            if(code != null && rsJson.getInteger("code") == 200){
              val data = JSONUtil.getJsonVal(rsJson,"data","")
              ret.put("data",data)
            }else {
              ret.put("code","!200")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("address","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  def getDiffApiIncDaySimilar(diffApiIncDay: RDD[JSONObject]): RDD[(JSONObject)] ={
    val diffApiIncDaySimilar = diffApiIncDay.filter(obj => {
      val matchtype = JSONUtil.getJsonVal(obj,"matchtype","")
      val area_code_tel = JSONUtil.getJsonVal(obj,"area_code_tel","")
      matchtype != "1" && !area_code_tel.isEmpty
    }).map(obj => {
      val afterAddress = JSONUtil.getJsonVal(obj,"decrypt_addr","")
      val beforeAddress = JSONUtil.getJsonVal(obj,"norm_address_tel","")
      val json = getSimilarInteface(similar_url,beforeAddress,afterAddress)
      (obj,json)
    }).map(obj => {
      val row = obj._1
      val json = obj._2
      val similar = JSONUtil.getJsonVal(json,"result","")
      val matchtype = JSONUtil.getJsonVal(row,"matchtype","")
      row.put("source","similarity")
      row.put("matchtype_2",matchtype)
      row.put("similar_first",similar)
      row
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>基于相同的区域代码，进行地址相似度评估 ${diffApiIncDaySimilar.count()} 条s<<<")
    diffApiIncDaySimilar
  }

  def getDiffApiIncDayNone(diffApiIncDayJoin: RDD[JSONObject]): RDD[JSONObject] ={
    val diffApiIncDayNone = diffApiIncDayJoin.filter(obj => {
      val matchtype = JSONUtil.getJsonVal(obj,"matchtype","")
      val area_code_tel = JSONUtil.getJsonVal(obj,"area_code_tel","")
      matchtype != "1" && area_code_tel.isEmpty
    }).map(obj => {
      obj.put("source","none")
      obj.put("matchtype_2","0")
      obj.put("similar","null")
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>识别完成，增加字段source，source=none ${diffApiIncDayNone.count()} 条s<<<")
    diffApiIncDayNone
  }

  /**
   * 识别完成，增加字段source，source=normal。增加字段Matchtype，matchtype=1
   * @param
   * @return
   */
  def getDiffApiIncDayNormal(diffApiIncDayJoin: RDD[JSONObject]): RDD[JSONObject] ={
    val diffApiIncDayNormal = diffApiIncDayJoin.filter(obj => {
      val matchtype = JSONUtil.getJsonVal(obj,"matchtype","")
      matchtype == "1"
    }).map(obj => {
      obj.put("source","normal")
      obj.put("matchtype_2","1")
      obj.put("similar","null")
      obj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>识别完成，增加字段source，source=normal ${diffApiIncDayNormal.count()} 条s<<<")
    diffApiIncDayNormal
  }

  /**
   * 从BDP平台dwd.dwd_waybill_info_dtl_di表取数（t-1）
   * @param spark
   * @return
   */
  def getWaybillInfoIncDay(spark: SparkSession,parDay_1 : String): RDD[JSONObject] ={
    val sql =
      s"""
         |SELECT
         |	 waybill_no
         |	,dest_zone_code
         |	,addressee_dept_code
         |	,dest_division_code
         |	,dest_area_code
         |	,dest_dist_code
         |	,dest_city_code
         |	,dest_county
         |	,meterage_weight_qty
         |	,real_weight_qty
         |	,consigned_tm
         |	,limit_type_code
         |	,consignee_addr
         |	,consignee_phone
         |	,service_prod_code
         |	,cons_name
         |FROM dwd.dwd_waybill_info_dtl_di
         |WHERE inc_day = '$parDay_1'
         |and array_contains(service_prod_code,'IN102')
         |""".stripMargin

    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>数据源取数sql: "+sql)
    val waybillInfoIncDay = Util.getRowToJson(spark,sql,10)
    logger.error(s">>>dwd_waybill_info_dtl_di表取数（t-1） ${waybillInfoIncDay.count()} 条s<<<")
    waybillInfoIncDay
  }

  /**
   * 跑diff特殊入仓接口
   * @param
   * @return
   */
  def getDiffApi(addrDecryptApi: RDD[(JSONObject,JSONObject)]): RDD[((JSONObject,JSONObject),JSONObject)] ={
    val diffApi = addrDecryptApi.map(obj => {
      val row = obj._1
      val json = obj._2
      val address = JSONUtil.getJsonVal(json,"data","")
      val dest_dist_code = JSONUtil.getJsonVal(row,"dest_dist_code","")
      val json1 = getdiffApiInteface(diff_url,address,dest_dist_code)
      (obj,json1)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s">>>跑diff特殊入仓接口共 ${diffApi.count()} 条s<<<")
    addrDecryptApi.unpersist()
    diffApi
  }

  /**
   *
   * @param
   * @param
   * @param
   * @return
   */
  def getdiffApiInteface(url: String,consignee_addr: String,dest_city_code : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!consignee_addr.isEmpty && !dest_city_code.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(consignee_addr,"utf-8"),URLEncoder.encode(dest_city_code,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response)
        if(response == null){
          logger.error("getdiffApiInteface resp null. url: " + urls)
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = rsJson.getJSONObject("result")
              if (result != null) {
                val sdata = result.getJSONObject("sdata")
                if(sdata != null){
                  val matchtype = JSONUtil.getJsonVal(sdata,"matchtype","")
                  ret.put("matchtype",matchtype)
                }else{
                  ret.put("sdata","null")
                }
              }else{
                ret.put("result","null")
              }
            }else {
              logger.error("getdiffApiInteface status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("address","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param
   * @param
   * @param
   * @return
   */
  def getSimilarInteface(url: String,beforeAddress: String,afterAddress : String): JSONObject = {
    val ret: JSONObject = new JSONObject()
    try {
      if (!beforeAddress.isEmpty && !afterAddress.isEmpty) {
        val urls = String.format(url,URLEncoder.encode(beforeAddress,"utf-8"),URLEncoder.encode(afterAddress,"utf-8"))
        val response = HttpInvokeUtil.sendGet(urls, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE)
        ret.put("response",response)
        if(response == null){
          logger.error("getSimilarInteface resp null. url: " + urls)
          ret.put("response","null")
        }else{
          val rsJson = JSON.parseObject(response)
          if(rsJson != null){
            val status = rsJson.getInteger("status")
            if(status != null && rsJson.getInteger("status") == 0){
              val result = JSONUtil.getJsonVal(rsJson,"result","")
              ret.put("result",result)
            }else {
              logger.error("getSimilarInteface status = 1. url - {}, resp - {}", urls, response)
              ret.put("status","1")
            }
          }else{
            ret.put("rsJson","null")
          }
        }
      }else{
        ret.put("address","null")
      }
    } catch {
      case e: Exception => logger.error(e)
        ret.put("Exception",e.toString)
    }
    ret
  }

  /**
   *
   * @param
   * @param
   */
  def saveResult(spark : SparkSession,diffApiIncDayRes : RDD[JSONObject],parDay_1 : String): Unit ={
    //目标库表名称
    val descDBName = "dm_gis"
    //val descTableName = "tel_library_unrecognized_res_day"
    val descTableName = "tel_library_report_craft_res_day"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION(inc_day = '$parDay_1')
         |select
         |	 waybill_no
         |	,dest_zone_code
         |	,addressee_dept_code
         |	,dest_division_code
         |	,dest_area_code
         |	,dest_dist_code
         |	,dest_city_code
         |	,dest_county
         |	,meterage_weight_qty
         |	,real_weight_qty
         |	,consigned_tm
         |	,limit_type_code
         |	,consignee_addr
         |	,consignee_phone
         |	,service_prod_code
         |	,cons_name
         |	,source
         |	,matchtype
         |	,'null'
         |	,'null'
         |from
         |(
         |	select
         |		 waybill_no
         |		,dest_zone_code
         |		,addressee_dept_code
         |		,dest_division_code
         |		,dest_area_code
         |		,dest_dist_code
         |		,dest_city_code
         |		,dest_county
         |		,meterage_weight_qty
         |		,real_weight_qty
         |		,consigned_tm
         |		,limit_type_code
         |		,consignee_addr
         |		,consignee_phone
         |		,service_prod_code
         |		,cons_name
         |		,source
         |		,matchtype
         |		,row_number() over(partition by waybill_no order by source_flag,matchtype_flag desc) as rn
         |	from
         |	(
         |		select
         |			 waybill_no
         |			,dest_zone_code
         |			,addressee_dept_code
         |			,dest_division_code
         |			,dest_area_code
         |			,dest_dist_code
         |			,dest_city_code
         |			,dest_county
         |			,meterage_weight_qty
         |			,real_weight_qty
         |			,consigned_tm
         |			,limit_type_code
         |			,consignee_addr
         |			,consignee_phone
         |			,service_prod_code
         |			,cons_name
         |			,source
         |			,matchtype
         |			,case when source is not null and source <> '' then 1 else 0 end as source_flag
         |			,case when matchtype is not null and matchtype <> '' then 1 else 0 end as matchtype_flag
         |		from tel_library_report_craft_res_day_tmp
         |		where source = 'normal'
         |	) as t1
         |) as t2
         |where t2.rn = 1
         |
         |union all
         |
         |select
         |	waybill_no
         |	,dest_zone_code
         |	,addressee_dept_code
         |	,dest_division_code
         |	,dest_area_code
         |	,dest_dist_code
         |	,dest_city_code
         |	,dest_county
         |	,meterage_weight_qty
         |	,real_weight_qty
         |	,consigned_tm
         |	,limit_type_code
         |	,consignee_addr
         |	,consignee_phone
         |	,service_prod_code
         |	,cons_name
         |	,source
         |	,matchtype
         |	,norm_address_tel as similar_addr_first
         |	,similar
         |from
         |(
         |		select
         |			*
         |			,row_number() over(partition by dest_area_code,waybill_no order by similar desc) as rn
         |		from
         |		(
         |			select
         |				waybill_no
         |				,dest_zone_code
         |				,addressee_dept_code
         |				,dest_division_code
         |				,dest_area_code
         |				,dest_dist_code
         |				,dest_city_code
         |				,dest_county
         |				,meterage_weight_qty
         |				,real_weight_qty
         |				,consigned_tm
         |				,limit_type_code
         |				,consignee_addr
         |				,consignee_phone
         |				,service_prod_code
         |				,cons_name
         |				,source
         |				,matchtype
         |				,case when similar = 'null' or similar = '' then 0.00 else cast(similar as double) end as similar
         |				,norm_address_tel
         |			from tel_library_report_craft_res_day_tmp
         |			where source = 'similarity'
         |		) as tmp
         |) as a
         |where rn = 1
         |
         |union all
         |
         |select
         |	 waybill_no
         |	,dest_zone_code
         |	,addressee_dept_code
         |	,dest_division_code
         |	,dest_area_code
         |	,dest_dist_code
         |	,dest_city_code
         |	,dest_county
         |	,meterage_weight_qty
         |	,real_weight_qty
         |	,consigned_tm
         |	,limit_type_code
         |	,consignee_addr
         |	,consignee_phone
         |	,service_prod_code
         |	,cons_name
         |	,source
         |	,matchtype
         |	,'null'
         |	,'null'
         |from
         |(
         |	select
         |		 waybill_no
         |		,dest_zone_code
         |		,addressee_dept_code
         |		,dest_division_code
         |		,dest_area_code
         |		,dest_dist_code
         |		,dest_city_code
         |		,dest_county
         |		,meterage_weight_qty
         |		,real_weight_qty
         |		,consigned_tm
         |		,limit_type_code
         |		,consignee_addr
         |		,consignee_phone
         |		,service_prod_code
         |		,cons_name
         |		,source
         |		,matchtype
         |		,row_number() over(partition by waybill_no order by source_flag,matchtype_flag desc) as rn
         |	from
         |	(
         |		select
         |			 waybill_no
         |			,dest_zone_code
         |			,addressee_dept_code
         |			,dest_division_code
         |			,dest_area_code
         |			,dest_dist_code
         |			,dest_city_code
         |			,dest_county
         |			,meterage_weight_qty
         |			,real_weight_qty
         |			,consigned_tm
         |			,limit_type_code
         |			,consignee_addr
         |			,consignee_phone
         |			,service_prod_code
         |			,cons_name
         |			,source
         |			,matchtype
         |			,case when source is not null and source <> '' then 1 else 0 end as source_flag
         |			,case when matchtype is not null and matchtype <> '' then 1 else 0 end as matchtype_flag
         |		from tel_library_report_craft_res_day_tmp
         |		where source = 'none'
         |	) as t1
         |) as t2
         |where t2.rn = 1
         |""".stripMargin

    try{
      val schemaString = "waybill_no,dest_zone_code,addressee_dept_code,dest_division_code,dest_area_code,dest_dist_code" +
        ",dest_city_code,dest_county,meterage_weight_qty,real_weight_qty,consigned_tm,limit_type_code,consignee_addr" +
        ",consignee_phone,service_prod_code,cons_name,source,matchtype,similar,norm_address_tel"
      val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName,StringType,nullable = true))
      val schema = StructType(fields)
      val rdd = diffApiIncDayRes.repartition(1).map(obj => {
        val row = obj
        val sb = new StringBuilder()
        sb.append(JSONUtil.getJsonVal(row,"waybill_no","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_zone_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"addressee_dept_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_division_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_area_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_dist_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_city_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"dest_county","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"meterage_weight_qty","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"real_weight_qty","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"consigned_tm","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"limit_type_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"decrypt_addr","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"consignee_phone","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"service_prod_code","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"cons_name","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"source","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"matchtype_2","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"similar_first","null")).append("\t\t\t")
        sb.append(JSONUtil.getJsonVal(row,"norm_address_tel","null")).append("\t\t\t")
        sb.toString()
      }).map(_.split("\t\t\t",-1)).map(attr => Row(attr(0),attr(1),attr(2),attr(3),attr(4),attr(5),attr(6),attr(7)
        ,attr(8),attr(9),attr(10),attr(11),attr(12),attr(13),attr(14),attr(15),attr(16),attr(17),attr(18),attr(19)))
      val df = spark.createDataFrame(rdd,schema)
      df.printSchema()
      df.show(5)
      df.createOrReplaceTempView("tel_library_report_craft_res_day_tmp")
      logger.error(">>>>>>>>>>入hive库开始")
      logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: "+insertSQL)
      spark.sql(insertSQL)
      logger.error(">>>>>>>>>>入hive库结束")
    } catch {
      case e: Exception => logger.error(">>>入库失败!<<<！\n" + e)
    }
  }
}
