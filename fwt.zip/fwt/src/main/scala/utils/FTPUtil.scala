package utils

import org.apache.commons.net.ftp.{FTP, FTPClient, FTPFile, FTPReply}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import org.apache.log4j.Logger

import java.io.{File, FileOutputStream, InputStream}
import scala.collection.mutable.ArrayBuffer

/**
 * @description: ftp 连接 上传 下载
 * @author 01418539 caojia
 * @date 2022/4/21 18:33
 */
object FTPUtil {

  val logger: Logger = Logger.getLogger(this.getClass)
  val fileSepartor: String = System.getProperty("file.separator")

  /**
   * 获取 FTPClient 连接信息
   *
   * @param host
   * @param port
   * @param username
   * @param password
   * @param charset
   * @return
   */
  def getFtpClient(host: String, port: Int, username: String, password: String, charset: String): FTPClient = {
    var ftpClient: FTPClient = null
    try {
      ftpClient = new FTPClient()
      val encoder = if (StringUtils.isEmpty(charset)) "UTF-8" else charset
      ftpClient.setControlEncoding(encoder)
      ftpClient.connect(host, port) // 连接FTP服务器

      if (FTPReply.isPositiveCompletion(ftpClient.getReplyCode))
        if (ftpClient.login(username, password)) {
          ftpClient.enterLocalPassiveMode
          ftpClient.setFileType(FTP.BINARY_FILE_TYPE)
          logger.error("FTP连接成功.")
        }
        else {
          logger.error("FTP登录失败. username - {}, password - {}", username, password)
          ftpClient.disconnect()
        }
      else {
        logger.error("FTP连接失败. host - {}, port - {}", host, port)
        ftpClient.disconnect()
      }
    } catch {
      case e: Exception => e.printStackTrace
        logger.error("FTP的IP地址可能错误，请正确配置。")
    }
    ftpClient
  }

  /**
   * 将 ftp 上的文件拉取到 hdfs 上
   *
   * @param ftpClient
   * @param ftpPath
   * @param hdfsPath
   * @param fileName
   * @param conf
   * @return
   */
  def downloadFromFtpToHdfs(ftpClient: FTPClient, ftpPath: String, hdfsPath: String, fileName: String, conf: Configuration): Boolean = {
    var inputStream: InputStream = null
    var outputStream: FSDataOutputStream = null
    var flag = true
    try {
      val reply = ftpClient.getReplyCode
      if (!FTPReply.isPositiveCompletion(reply)) ftpClient.disconnect

      val files = ftpClient.listFiles(ftpPath)
      val hdfsFile: FileSystem = FileSystem.get(conf)
      for (file <- files) {
        if (file.getName.equals(fileName)) {
          inputStream = ftpClient.retrieveFileStream(ftpPath + file.getName)
          outputStream = hdfsFile.create(new Path(hdfsPath + file.getName))
          IOUtils.copyBytes(inputStream, outputStream, conf, false)
          if (inputStream != null) {
            inputStream.close();
            ftpClient.completePendingCommand()
          }
        }
      }
      ftpClient.disconnect()
    } catch {
      case e: Exception => flag = false
        e.printStackTrace()
    }
    if (flag) logger.error("FTP上的文件,已成功拉取到hdfs上！")
    flag
  }

  def downloadFromFtpTolocal(ftpClient: FTPClient, ftpPath: String, localPath: String, keyword: String): Unit = {
    ftpClient.changeWorkingDirectory(ftpPath)
    val ftpFiles = ftpClient.listFiles()
    logger.error(">>>该目录下总文件数量：" + ftpFiles.size)
    val unhookFtpFile = new ArrayBuffer[FTPFile]()
    for (file <- ftpFiles) {
      if (file.getName.indexOf(keyword) != -1) {
        unhookFtpFile += file
      }
    }
    logger.error(">>>需要下载的文件数量：" + unhookFtpFile.size)
    print(">>>正在下载文件:")
    for (ftpFile <- unhookFtpFile) {
      val filename = ftpFile.getName
      print(filename + ",")
      val localfile = new File(localPath + fileSepartor + filename)
      val fos = new FileOutputStream(localfile)
      ftpClient.retrieveFile(filename, fos)
      fos.close()
    }
    ftpClient.logout()
    logger.error(">>>下载结束！")
  }

}
