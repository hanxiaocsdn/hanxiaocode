package utils

import org.apache.commons.lang3.time.FastDateFormat
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

import java.text.{ParseException, SimpleDateFormat}
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.{Calendar, Date}
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * @author 01418539
 * @date 2021年12月10日 17:18
 */
object DateUtil {
  val logger = LoggerFactory.getLogger(this.getClass)
  val sdf = FastDateFormat.getInstance("yyyyMMdd HH:mm:ss")
  val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")
  val sdf2 = FastDateFormat.getInstance("yyyy/MM/dd HH:mm:ss")
  val sdf3 = FastDateFormat.getInstance("yyyyMMddHHmmss")
  val sdf_inc = FastDateFormat.getInstance("yyyyMMdd")

  lazy val DEFAULT_DATE_FORMAT = "yyyy-MM-dd"
  val MS_PERDAY = 1000 * 60 * 60 * 24

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * eg:20210101 11:11:11
   * res:1609470671
   */

  def timeToTimestamp = udf((colValue: String) => {
    val dt = sdf.parse(colValue)
    //时间戳毫秒转秒
    (dt.getTime / 1000).toString
  }
  )

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * eg:2021-01-01 11:11:11
   * res:1609470671
   */

  def timeToTimestamp_ = udf((colValue: String) => {
    var time: Long = 0
    try {
      val dt = sdf1.parse(colValue)
      //时间戳毫秒转秒
      time = dt.getTime / 1000
    } catch {
      case e: Exception => logger.error("getCurrentDate execute exception, exception info: ", e)
    }
    time
  }
  )

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * eg:2021-01-01 11:11:11 or yyyyMMdd or yyyyMMdd HH:mm:ss
   * res:1609470671
   */

  def timeToTimestampUDF(format: String) = udf((colValue: String) => {
    var time: Long = 0
    val sdf = FastDateFormat.getInstance(format)
    try {
      val dt = sdf.parse(colValue)
      //时间戳毫秒转秒
      time = dt.getTime / 1000
    } catch {
      case e: Exception => logger.error("getCurrentDate execute exception, exception info: ", e)
    }
    time
  }
  )

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * 2021-01-01 11:11:11("yyyy-MM-dd HH:mm:ss")
   *
   * @return 1609470671
   */
  def timeToTimestampFormat(format: String, colValue: String): Long = {
    var ts = 0l
    try {
      val fdf = FastDateFormat.getInstance(format)
      val dt = fdf.parse(colValue)
      //时间戳毫秒转秒
      ts = dt.getTime / 1000
    } catch {
      case e: Exception => logger.error("时间>>>时间戳" + e.getMessage)
    }
    ts
  }

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * 2021-01-01 11:11:11
   *
   * @return 1609470671
   */
  def timeToTimestamp1 = udf((colValue: String) => {
    var ts: String = "0"
    try {
      val dt = sdf1.parse(colValue)
      //时间戳毫秒转秒
      ts = (dt.getTime / 1000).toString
    } catch {
      case e: Exception => logger.error("日期字段格式有异常" + e.getMessage)
    }
    ts
  }
  )

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * 2021/01/01 11:11:11
   *
   * @return 1609470671
   */
  def timeToTimestamp2 = udf((colValue: String) => {
    var ts: String = "0"
    try {
      val dt = sdf2.parse(colValue)
      //时间戳--秒
      ts = (dt.getTime / 1000).toString
    } catch {
      case e: Exception => logger.error("日期字段格式有异常" + e.getMessage)
    }
    ts
  }
  )

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * 20210101111111
   *
   * @return 1609470671
   */
  def timeToTimestamp3 = udf((colValue: String) => {
    val dt = sdf3.parse(colValue)
    //时间戳---秒
    (dt.getTime / 1000).toString
  }
  )

  /**
   * 将给定格式的日期转为 另一格式日期数据
   * param  : 20210101111111
   *
   * @return 2021-01-01 11:11:11
   */
  def formatDiffTime = udf((colValue: String) => {
    var time = ""
    try {
      time = sdf1.format(new Date(sdf3.parse(colValue).getTime))
    } catch {
      case e: Exception => logger.error("日期字段格式有异常" + e.getMessage)
    }
    time
  })

  /**
   * 将指定格式的 时间戳 转 日期，单位为：秒
   * eg:1609470671
   * res:20210101111111
   */

  def tranTstampToTime(colValue: String): String = {
    var time = "0"
    try {
      time = sdf3.format(new Date(colValue.toLong * 1000))
    } catch {
      case e: Exception => logger.error("日期字段格式有异常" + e.getMessage)
    }
    time
  }

  /**
   * 将指定格式的 时间戳 转 日期，单位为：秒
   * eg:1609470671
   * res:2021-01-01 11:11:11 or 2021/01/01 11:11:11
   */

  def tranTstampToTime(sdf: FastDateFormat, colValue: String): String = {
    var time = ""
    try {
      time = sdf.format(new Date(colValue.toLong * 1000))
    } catch {
      case e: Exception => logger.error("时间戳>>>时间" + e.getMessage)
    }
    time
  }

  /**
   * 将指定格式的 时间戳 转 日期，单位为：秒
   * eg:1609470671
   * res:2021-01-01 11:11:11 or 2021/01/01 11:11:11
   */

  def tranTstampToTimeUDF(sdf: FastDateFormat) = udf((colValue: String) => {
    var time = ""
    try {
      time = sdf.format(new Date(colValue.toLong * 1000))
    } catch {
      case e: Exception => logger.error("日期字段格式有异常" + e.getMessage)
    }
    time
  }
  )

  /**
   * @param 根据传入的日期类型 ，进行转换成当天日期
   */
  def getCurrentDate(format: String): String = {
    var cur_Date = ""
    val date: SimpleDateFormat = new SimpleDateFormat(format)
    try {
      cur_Date = date.format(new Date())
    } catch {
      case e: Exception => logger.error("getCurrentDate execute exception, exception info: ", e)
    }
    cur_Date
  }

  /**
   * 获取指定日期的前10天日期
   *
   * @param inc_day
   * @return 返回 yyyyMMdd
   */
  def get10daysBefore(inc_day: String): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, -10)
    dateFormat.format(cal.getTime())
  }

  /**
   * 获取指定日期的后10天日期
   *
   * @param inc_day
   * @return 返回 yyyyMMdd
   */
  def get10daysAfter(inc_day: String): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, 10)
    dateFormat.format(cal.getTime())
  }

  /**
   * 获取指定日期的前1天日期
   *
   * @param inc_day
   * @return yyyymmdd
   */
  def getOnedaysBefore(inc_day: String): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, -1)
    dateFormat.format(cal.getTime())
  }

  /**
   * 指定日期 12个月 前的日期 20210422---20220421
   * 按照月份 month 增减
   *
   * @param inc_day
   * @return yyyymmdd
   */
  def getMonthsBeforeOrAfter(inc_day: String, num: Int): String = {
    val inc_day_tmp = getdaysBeforeOrAfter(inc_day, 1)
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day_tmp)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat.format(cal.getTime())
  }

  /**
   * 指定日期 1年前的日期的  月底日期   输入：20220421
   * 按照月份 month 增减
   *
   * @param inc_day
   * @return yyyymmdd  20210420
   */
  def getLastDayofMonthBeforeOrAfter(inc_day: String, num: Int): String = {
    val tmp_1 = inc_day.substring(0, 6) + "01"
    val tmp_2 = getdaysBeforeOrAfter(tmp_1, -1)
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_2)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE))
    dateFormat.format(cal.getTime())
  }

  /**
   * 指定日期 11个月前的日期的 月初日期 输入： 20220421
   *
   * @param inc_day
   * @return yyyymmdd 20210501
   */
  def getFirstDayofMonthBeforeOrAfter(inc_day: String, num: Int): String = {
    val tmp_1 = inc_day.substring(0, 6) + "01"
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_1)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat.format(cal.getTime())
  }

  /**
   * 日期月度操作 20220521
   *
   * @param yyyymmdd inc_day
   * @return 20220422
   */
  def getFixedDayOfMonth(inc_day: String, fixedDay: String, subDate: Int): String = {
    val tmp = inc_day.substring(0, 6) + fixedDay
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, subDate)
    dateFormat.format(cal.getTime())
  }


  /**
   * UDF 指定日期 11个月前的日期的 月初日期 输入： 20220421
   *
   * @param inc_day
   * @return yyyymmdd 20210501
   */
  def getFirstDayofMonthBeforeOrAfterUDF(num: Int) = udf((inc_day: String) => {
    val tmp_1 = inc_day.substring(0, 6) + "01"
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_1)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat.format(cal.getTime())
  })


  /**
   * 获取指定日期的前后 n 天日期
   *
   * @param inc_day
   * @return yyyymmdd
   */
  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime())
  }

  /**
   * UDF 获取指定日期的前后 n 天日期
   *
   * @param inc_day
   * @return yyyymmdd
   */
  def getdaysBeforeOrAfterUDF(num: Int) = udf((inc_day: String) => {
    var res = ""
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    try {
      val cal: Calendar = Calendar.getInstance()
      val time_dt: Date = dateFormat.parse(inc_day)
      cal.setTime(time_dt)
      cal.add(Calendar.DATE, num)
      res = dateFormat.format(cal.getTime())
    } catch {
      case e: Exception => ""
    }
    res
  })

  /**
   * 获取指定日期的前后 n 天日期
   *
   * @param inc_day
   * @return yyyy-mm-dd
   */
  def getdaysBefore(inc_day: String, num: Int, format: String): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat(format)
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime())
  }


  /**
   *
   * @param timestamp 1634546190 单位：秒(2021-10-18 16:36:30)
   * @return time      2021-10-18 16:36:50
   */

  def tranTimestampToDate = udf((timestamp: String) => {
    val date: Date = new Date(timestamp.toLong * 1000)
    val str: String = sdf2.format(date)
    str
  })


  /**
   * @param 列字段求和
   * @return
   */
  def multiColumnSum = udf((cnt1: Int, cnt2: Int, cnt3: Int, cnt4: Int) => {
    cnt1 + cnt2 + cnt3 + cnt4
  })

  /**
   * @param 添加前缀
   * @return
   */
  def randomPrefix = udf((colName: String) => {
    Random.nextInt(9).toString + "_" + colName
  })

  /**
   * @param 去前缀
   * @return
   */
  def removePrefix = udf((colName: String) => {
    colName.split("_")(1)
  })

  /**
   * @param 两个列字段 String类型
   * @return
   */
  def colValueFun = udf((col1: String, col2: String) => {
    col1.replaceAll("\\s+", "")
      .replaceAll("\\{", "")
      .replaceAll("\\}", "")
      .replaceAll(":", "")
      .replaceAll("\"", "")
      .replaceAll(col2, "")
  })

  /**
   * @param 字符串类型的 日期 ‘20220210’ 返回：4（星期四）
   * @return 返回对应当天星期日 一 二 三 四 五 六
   */
  def getWeek(date: String) = {
    val sdf = new SimpleDateFormat("yyyyMMdd")
    var inputDate: Date = sdf.parse(date)
    val weeks = Array("7", "1", "2", "3", "4", "5", "6")
    val cal = Calendar.getInstance()
    cal.setTime(inputDate)
    var week_index = cal.get(Calendar.DAY_OF_WEEK) - 1
    if (week_index < 0) {
      week_index = 0
    }
    weeks(week_index)
  }

  /**
   * @param 添加前缀
   * @return
   */
  def startEndContains = udf((colName: String, start: String, end: String) => {
    var str1 = ""
    var str2 = ""
    try {
      if (!colName.isEmpty) {
        if (!start.isEmpty && start.trim != "") {
          str1 = colName.split(start)(1)
        }
        if (end != null && end.trim != "") {
          str2 = str1.split(end)(0)
        }
      }
    } catch {
      case e: Exception =>
        logger.error("异常：" + e.getMessage)
    }
    start + str2
  })

  /**
   * 返回两日期之间的所有日期, 闭区间
   *
   * @param start_day 20220101
   * @param end_day   20200105
   * @param dateFormat
   * @return 返回两日期之间的所有日期, 闭区间[20220101,20220102,20220103]
   */
  def getInterDateList(start_day: String, end_day: String, dateFormat: String): String = {
    val start_day_new = start_day.substring(0, 4) + "-" + start_day.substring(4, 6) + "-" + start_day.substring(6, 8)
    val end_day_new = end_day.substring(0, 4) + "-" + end_day.substring(4, 6) + "-" + end_day.substring(6, 8)
    val dateList = new ArrayBuffer[String]()
    try {
      val standFormat = DateTimeFormatter.ofPattern(dateFormat)
      var start = LocalDate.parse(start_day_new, standFormat)
      val end = LocalDate.parse(end_day_new, standFormat)
      dateList.append(start.format(standFormat))
      while (end.isAfter(start)) {
        start = start.plusDays(1)
        dateList.append(start.format(standFormat))
      }
    } catch {
      case e: Exception => logger.error("检查传入日期格式" + e.getMessage)
    }
    dateList.mkString(",")
  }

  /**
   * 返回两日期之间的所有日期, 闭区间  分隔符：sep
   *
   * @param start_day 20220101
   * @param end_day   20200105
   * @param dateFormat
   * @return 返回两日期之间的所有日期, 闭区间[20220101,20220102,20220103]
   */
  def getInterDateListWithSep(start_day: String, end_day: String, dateFormat: String, sep: String): String = {
    val start_day_new = start_day.substring(0, 4) + sep + start_day.substring(4, 6) + sep + start_day.substring(6, 8)
    val end_day_new = end_day.substring(0, 4) + sep + end_day.substring(4, 6) + sep + end_day.substring(6, 8)
    val dateList = new ArrayBuffer[String]()
    try {
      val standFormat = DateTimeFormatter.ofPattern(dateFormat)
      var start = LocalDate.parse(start_day_new, standFormat)
      val end = LocalDate.parse(end_day_new, standFormat)
      dateList.append(start.format(standFormat))
      while (end.isAfter(start)) {
        start = start.plusDays(1)
        dateList.append(start.format(standFormat))
      }
    } catch {
      case e: Exception => logger.error("检查传入日期" + e.getMessage)
    }
    dateList.mkString(",")
  }

  /**
   * 顺丰：每个保单对应两个统计周期：
   * 若更新日期<11.16：前年11.16-去年11.15  周期为去年11.16-今年11.15，
   * 若更新日期>=11.16：去年11.16-今年11.15 周期为今年11.16-明年11.15，
   * 根据传入日期返回保单统计区间
   *
   * @return 前年11.16-去年11.15  或 去年11.16-今年11.15
   */
  def getYearOrBefore = udf((day: String, flag: Int, inter: Int) => {

    val one_year_before = day.substring(0, 4).toInt - flag - 1 + inter
    val now_year = day.substring(0, 4).toInt - flag + inter

    val start = one_year_before + "1116"
    val end = now_year + "1115"
    (start, end)
  })

  /**
   * 给定时间区间计算天数差
   *
   * @return
   */
  def interDayStartToEnd = udf((start_day: String, end_day: String) => {
    var day: Long = 0
    try {
      val start = sdf_inc.parse(start_day)
      val end = sdf_inc.parse(end_day)
      day = (end.getTime - start.getTime) / MS_PERDAY + 1 //20220101-20220116  一起16天
    } catch {
      case e: Exception => logger.error("检查传入日期格式" + e.getMessage)
    }
    day
  })

  /**
   *
   * @param start_day
   * @param end_day
   * @return
   */
  def daysBetweenDate(start_day: String, end_day: String): Int = {
    var day: Int = 0
    try {
      val start = sdf_inc.parse(start_day)
      val end = sdf_inc.parse(end_day)
      day = if (end.getTime - start.getTime >= 0) ((end.getTime - start.getTime) / MS_PERDAY).toInt else ((start.getTime - end.getTime) / MS_PERDAY).toInt //20220101-20220116  一起16天
    } catch {
      case e: Exception => logger.error("检查传入日期格式" + e.getMessage)
    }
    day
  }

  /**
   * 给定时间区间 计算区间之间相差天数【20220101，20220301】--【20220201，20220401】
   *
   * @return 天数差：29（天）
   */
  def interSectionDays = udf((statistics_start_tm: String, statistics_end_tm: String, start_tm: String, end_tm: String) => {
    var day_diff: Long = 0
    try {
      if (statistics_end_tm.toLong < start_tm.toLong || end_tm.toLong < statistics_start_tm.toLong) {
        day_diff = 0
      } else if (statistics_start_tm.toLong <= start_tm.toLong && end_tm.toLong <= statistics_end_tm.toLong) {
        day_diff = (sdf_inc.parse(end_tm).getTime - sdf_inc.parse(start_tm).getTime) / MS_PERDAY + 1
      } else if (start_tm.toLong <= statistics_start_tm.toLong && statistics_end_tm.toLong <= end_tm.toLong) {
        day_diff = (sdf_inc.parse(statistics_end_tm).getTime - sdf_inc.parse(statistics_start_tm).getTime) / MS_PERDAY + 1
      } else if (start_tm.toLong <= statistics_end_tm.toLong && start_tm.toLong >= statistics_start_tm.toLong && statistics_end_tm.toLong <= end_tm.toLong) {
        day_diff = (sdf_inc.parse(statistics_end_tm).getTime - sdf_inc.parse(start_tm).getTime) / MS_PERDAY + 1
      } else if (statistics_start_tm.toLong <= end_tm.toLong && statistics_start_tm.toLong >= start_tm.toLong && end_tm.toLong <= statistics_end_tm.toLong) {
        day_diff = (sdf_inc.parse(end_tm).getTime - sdf_inc.parse(statistics_start_tm).getTime) / MS_PERDAY + 1
      } else {
        day_diff = 0
      }
    } catch {
      case e: Exception => logger.error("计算日期之间的差值有异常" + e.getMessage)
    }
    day_diff
  })

  /**
   * @note 获取距离指定日期相隔days天的的日期：
   * @param inputDateStr 指定日期
   * @param days         相隔天数 正数表示在之后n天，负数表示在之前n天
   * @param dateFormat   日期格式(eg：yyyy-MM-dd, yyyy/MM/dd)
   * @return
   * */
  def getDaysApartDate(dateFormat: String, inputDateStr: String, days: Integer): String = {
    val simpleDateFormat = new SimpleDateFormat(dateFormat)
    val inputDate: Date = simpleDateFormat.parse(inputDateStr)
    val calendar = Calendar.getInstance
    calendar.setTime(inputDate)
    calendar.add(Calendar.DAY_OF_YEAR, days)
    val date = calendar.getTime
    val dateStr = simpleDateFormat.format(date).trim
    dateStr
  }


  /**
   * @note 获取距离指定日期相隔days天的的日期：
   * @param inputDateStr 指定日期
   * @param days         相隔天数 正数表示在之后n天，负数表示在之前n天
   * @param dateFormat   日期格式(eg：yyyy-MM-dd, yyyy/MM/dd)
   * @return
   * */
  def getDaysApartDateSetHour(inputDateStr: String, dateFormat: String, days: Integer): String = {

    val cal = Calendar.getInstance()
    val sdf = new SimpleDateFormat(dateFormat)

    val parseDateFormat = sdf.parse(inputDateStr)

    parseDateFormat.setHours(0)
    parseDateFormat.setMinutes(0)
    parseDateFormat.setSeconds(0)

    val calendar = Calendar.getInstance
    calendar.setTime(parseDateFormat)
    calendar.add(Calendar.DAY_OF_YEAR, days)

    val date = calendar.getTime
    val dateStr = sdf.format(date).trim
    dateStr
  }

  /**
   * 获取某天日期之后几天的日期字符串
   *
   * @param inputDateStr 日期
   * @param num          相隔天数 正数表示在之后n天，负数表示在之前n天
   */
  def getDateStr(inputDateStr: String, num: Int): String = {
    getDateStr(inputDateStr, num, "")
  }

  /**
   * 获取某天字符日期之前、后几天的日期字符串
   *
   * @param inputDateStr 日期
   * @param num          相隔天数 正数表示在之后n天，负数表示在之前n天
   * @param separator    日期分隔符
   * @return
   */
  def getDateStr(inputDateStr: String, num: Int, separator: String): String = {
    val dateStrFormat = "yyyy" + separator + "MM" + separator + "dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    var inputDate: Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

  /**
   * 获得两个字符串日期中所有日期的字符格式集合(左闭右开)
   *
   * @param startDateStr
   * @param endDateStr
   * @return
   */
  def getTwoDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
    getTwoDatesStr(startDateStr, endDateStr, "")
  }

  /**
   * 获得两个字符串日期中所有日期的字符格式集合(左闭右开)
   *
   * @param startDateStr
   * @param endDateStr
   * @return
   */
  def getTwoDatesStr(startDateStr: String, endDateStr: String, separator: String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy" + separator + "MM" + separator + "dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      var startDate: Date = sdf.parse(startDateStr)
      var endDate: Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(getDateNum(startDate, -1), endDate)
      for (date <- dateList) dateListStr += (sdf.format(date))
    } catch {
      case e: ParseException => println(">>>日期转换异常" + e)
    }
    dateListStr
  }

  /**
   * 获得两个Date格式日期之间的所有日期列表(左右开区间)
   *
   * @param start
   * @param end
   * @return
   */
  def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
    val result = new ArrayBuffer[Date]
    val tempStart = Calendar.getInstance
    tempStart.setTime(start)
    tempStart.add(Calendar.DAY_OF_YEAR, 1)
    val tempEnd = Calendar.getInstance
    tempEnd.setTime(end)
    while (tempStart.before(tempEnd)) {
      result += (tempStart.getTime)
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    result
  }

  /**
   * 获取Date格式的相距天数为size的Date结果
   *
   * @param inputDate
   * @param size
   * @return
   */
  def getDateNum(inputDate: Date, size: Int): Date = {
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, size)
    val outPutDate = tempDate.getTime
    outPutDate
  }
  //  def main(args: Array[String]): Unit = {
  //    // println(tranTimeToStamp("20211208 01:12:21"))
  //    //     println(tranTimeToStamp("1638901560000"))
  //    //   println(get10daysBefore("20211218"))
  //    //   println(tranTimestampToDate("1634546190"))
  //    //          val week = getWeek("20220210")
  //    //          println("======>" + week)
  //  }

}
