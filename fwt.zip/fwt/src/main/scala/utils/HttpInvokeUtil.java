package utils;

import com.alibaba.fastjson.JSONObject;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.SocketConfig;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author 01418539
 * @date 2022年01月17日 10:08
 */
public class HttpInvokeUtil {
    static final Logger logger = LoggerFactory.getLogger(HttpInvokeUtil.class);

    static final PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager();
    static CloseableHttpClient httpClient = null;
    static boolean isInitConnection = false;

    /**
     * 初始化连接池
     */
    public static void initConnectionManager() {

        try {
            connManager.setMaxTotal(5); // 设置整个连接池最大连接数 根据自己的场景决定
            // 是路由的默认最大连接（该值默认为2），限制数量实际使用DefaultMaxPerRoute并非MaxTotal。设置过小无法支持大并发(ConnectionPoolTimeoutException: Timeout waiting for connection from pool)，路由是对maxTotal的细分。
            connManager.setDefaultMaxPerRoute(5);// （目前只有一个路由，因此让他等于最大值）
            SocketConfig socketConfig = SocketConfig.custom().setSoKeepAlive(true).setSoTimeout(30000).setTcpNoDelay(true).build();
            connManager.setDefaultSocketConfig(socketConfig);

            RequestConfig requestConfig = RequestConfig.custom().setConnectionRequestTimeout(30000).setConnectTimeout(30000).setSocketTimeout(30000).build();
            httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).setConnectionManager(connManager).build();
        } catch (Exception e) {
            logger.error("initConnectionManager error. ", e);
        }
    }

    /**
     * 进行post请求
     *
     * @param url        请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static String sendPost(String url, String param, int maxTryTime, int tryCount) {
        String jsonStr = sendPost(url, tryCount, param);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(jsonStr) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                jsonStr = sendPost(url, tryCount, param);
            }
            Set<Integer> acLimitCodeSet;
            acLimitCodeSet = Arrays.stream("1005,109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(jsonStr), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                jsonStr = HttpInvokeUtil.sendPost(url, tryCount, param);
            }
        } catch (Exception e) {

        }
        return jsonStr;
    }

    /**
     * 进行post请求 带请求头Header
     *
     * @param url        请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static String sendPostH(String url, String param, int maxTryTime, int tryCount, String ak, String trace_batch) {
        String jsonStr = sendPostH(url, tryCount, param, ak, trace_batch);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(jsonStr) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                jsonStr = sendPostH(url, tryCount, param, ak, trace_batch);
            }
            Set<Integer> acLimitCodeSet;
            acLimitCodeSet = Arrays.stream("1005,109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(jsonStr), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                jsonStr = HttpInvokeUtil.sendPostH(url, tryCount, param, ak, trace_batch);
            }
        } catch (Exception e) {

        }
        return jsonStr;
    }


    /**
     * 进行post请求 txt格式
     *
     * @param url        请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static String sendPostText(String url, String param, int maxTryTime, int tryCount) {
        String jsonStr = sendPostText(url, tryCount, param);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(jsonStr) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                jsonStr = sendPostText(url, tryCount, param);
            }
            Set<Integer> acLimitCodeSet;
            acLimitCodeSet = Arrays.stream("1005,109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(jsonStr), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                jsonStr = HttpInvokeUtil.sendPostText(url, tryCount, param);
            }
        } catch (Exception e) {

        }
        return jsonStr;
    }

    /**
     * post请求 header传参
     *
     * @param url
     * @param
     * @return
     */
    public static String sendPostText(String url, int tryCount, String param) {
        int count = tryCount;
        while (count-- > 0) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.setEntity(new StringEntity(param, Charset.forName("UTF-8")));
            //post请求 单独设置超时时间
            RequestConfig defaultRequestConfig = RequestConfig.custom()
                    .setConnectionRequestTimeout(10000)//指从连接池获取连接的timeout
                    .setConnectTimeout(10000)//指客户端和服务器建立连接的timeout，就是http请求的三个阶段，一：建立连接；二：数据传送；三，断开连接。超时后会ConnectionTimeOutException
                    .setSocketTimeout(10000)//指客户端从服务器读取数据的timeout，超出后会抛出SocketTimeOutException
                    .setStaleConnectionCheckEnabled(true)
                    .build();

            try (CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(defaultRequestConfig).build();
                 CloseableHttpResponse response = httpClient.execute(httpPost);) {

                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    return result;
                }
            } catch (Exception e) {
                logger.error("异常信息为：" + e.getMessage());
                try {
                    if (count == 0) {
                        logger.error(url + "," + e.getMessage());
                    } else if (count == 1) {
                        Thread.sleep(500);
                    } else if (count == 2) {
                        Thread.sleep(250);
                    } else if (count == 3) {
                        Thread.sleep(125);
                    }
                } catch (InterruptedException e1) {
                }
                continue;
            } finally {
                httpPost.releaseConnection();
            }
        }
        return null;
    }

    /**
     * post请求
     *
     * @param url
     * @param
     * @return
     */
    public static String sendPost(String url, int tryCount, String param) {
        int count = tryCount;
        while (count-- > 0) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-type", "application/json; charset=utf-8");
            httpPost.setHeader("Accept", "application/json");
            httpPost.setEntity(new StringEntity(param, Charset.forName("UTF-8")));
            //post请求 单独设置超时时间
            RequestConfig defaultRequestConfig = RequestConfig.custom()
                    .setConnectionRequestTimeout(10000)//指从连接池获取连接的timeout
                    .setConnectTimeout(10000)//指客户端和服务器建立连接的timeout，就是http请求的三个阶段，一：建立连接；二：数据传送；三，断开连接。超时后会ConnectionTimeOutException
                    .setSocketTimeout(10000)//指客户端从服务器读取数据的timeout，超出后会抛出SocketTimeOutException
                    .setStaleConnectionCheckEnabled(true)
                    .build();

            try (CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(defaultRequestConfig).build();
                 CloseableHttpResponse response = httpClient.execute(httpPost);) {

                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    return result;
                }
            } catch (Exception e) {
                logger.error("异常信息为：" + e.getMessage());
                try {
                    if (count == 0) {
                        logger.error(url + "," + e.getMessage());
                    } else if (count == 1) {
                        Thread.sleep(500);
                    } else if (count == 2) {
                        Thread.sleep(250);
                    } else if (count == 3) {
                        Thread.sleep(125);
                    }
                } catch (InterruptedException e1) {
                }
                continue;
            } finally {
                httpPost.releaseConnection();
            }
        }
        return null;
    }

    /**
     * post请求 header传参
     *
     * @param url
     * @param
     * @return
     */
    public static String sendPostH(String url, int tryCount, String param, String ak, String trace_batch) {
        int count = tryCount;
        while (count-- > 0) {
            HttpPost httpPost = new HttpPost(url);
            httpPost.addHeader("Content-type", "application/json");
            httpPost.addHeader("ak", ak);
            httpPost.addHeader("requestName", trace_batch);
            httpPost.setHeader("Accept", "application/json");
            httpPost.setEntity(new StringEntity(param, Charset.forName("UTF-8")));
            //post请求 单独设置超时时间
            RequestConfig defaultRequestConfig = RequestConfig.custom()
                    .setConnectionRequestTimeout(10000)//指从连接池获取连接的timeout
                    .setConnectTimeout(10000)//指客户端和服务器建立连接的timeout，就是http请求的三个阶段，一：建立连接；二：数据传送；三，断开连接。超时后会ConnectionTimeOutException
                    .setSocketTimeout(10000)//指客户端从服务器读取数据的timeout，超出后会抛出SocketTimeOutException
                    .setStaleConnectionCheckEnabled(true)
                    .build();

            try (CloseableHttpClient httpClient = HttpClients.custom().setDefaultRequestConfig(defaultRequestConfig).build();
                 CloseableHttpResponse response = httpClient.execute(httpPost);) {

                if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                    String result = EntityUtils.toString(response.getEntity(), "utf-8");
                    return result;
                }
            } catch (Exception e) {
                logger.error("异常信息为：" + e.getMessage());
                try {
                    if (count == 0) {
                        logger.error(url + "," + e.getMessage());
                    } else if (count == 1) {
                        Thread.sleep(500);
                    } else if (count == 2) {
                        Thread.sleep(250);
                    } else if (count == 3) {
                        Thread.sleep(125);
                    }
                } catch (InterruptedException e1) {
                }
                continue;
            } finally {
                httpPost.releaseConnection();
            }
        }
        return null;
    }

    /**
     * 进行get请求
     *
     * @param url        请求路径
     * @param charset    编码格式
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    @SuppressWarnings("BusyWait")
    public static String sendGet(String url, String charset, int maxTryTime) {
        String jsonStr = sendGet(url, charset);
        int tryTime = 0;
        try {
            while (StringUtils.isEmpty(jsonStr) && ++tryTime <= maxTryTime) {
                Thread.sleep(1000);
                logger.error("try time {}: {}", maxTryTime, url);
                if (StringUtils.isNotEmpty(charset)) {
                    jsonStr = sendGet(url, charset);
                } else {
                    jsonStr = sendGet(url, "UTF-8");
                }
            }
            Set<Integer> acLimitCodeSet;
            acLimitCodeSet = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
            while (isAcTime(JSONObject.parseObject(jsonStr), acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                jsonStr = HttpInvokeUtil.sendGet(url, maxTryTime);
            }
        } catch (Exception e) {

        }
        return jsonStr;
    }

    public static boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快") || msg.contains("访问限制,访问量已超过")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    /**
     * 进行get请求
     *
     * @param url        请求路径
     * @param maxTryTime 最大尝试次数
     * @return get请求返回的结果
     */
    public static String sendGet(String url, int maxTryTime) {
        return sendGet(url, null, maxTryTime);
    }

    public static String sendGet(String url, String charset) {
        logger.debug("start send get, url - {}.", url);
        String jsonStr = "";
        HttpGet get = null;
        CloseableHttpResponse response = null;
        HttpEntity entity = null;
        try {
            if (!isInitConnection) {
                initConnectionManager();
                isInitConnection = true;
            }
            get = new HttpGet(url);
            response = httpClient.execute(get);
            entity = response.getEntity();
            jsonStr = EntityUtils.toString(entity, charset);

        } catch (Exception e) {
            logger.error("execute access http get url err. " + url, e);
            return jsonStr;
        } finally {
            try {
                if (jsonStr != null) {
                    if (get != null) {
                        EntityUtils.consume(entity);
                        get.releaseConnection();
                    }
                    if (response != null) {
                        response.close();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        logger.debug("end get， url - {}.", url);
        return jsonStr;
    }

}
