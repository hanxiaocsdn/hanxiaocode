package utils

import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

/**
 * @author 01418539
 * @date 2021年12月10日 14:41
 */
object SparkBuilder {
  val Logger = LoggerFactory.getLogger(this.getClass)
  var spark: SparkSession = _

  def initSpark(appName: String): SparkSession = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.cores.max", "4")
      .set("spark.port.maxRetries", "999")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      //长期存在于NodeManager进程中的一个辅助服务。通过该服务来抓取shuffle数据，减少了Executor的压力，在Executor GC的时候也不会影响其他Executor的任务运行
      .set("spark.shuffle.service.enabled", "true")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.kryoserializer.buffer.max", "128m")
      .set("spark.network.timeout", "600s")
      .set("spark.executor.memoryOverhead", "16G")
      .set("spark.yarn.executor.memoryOverhead", "8G")
      .set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
      .set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
      .set("spark.rpc.askTimeout", "600s")
      .set("spark.shuffle.compress", "true")
      .set("spark.sql.hive.mergeFiles", "true")
      .set("spark.sql.adaptive.enabled", "true")
      .set("spark.sql.adaptive.coalescePartitions.enabled", "true")
      .set("hive.exec.dynamici.partition", "true") //开启动态分区
      .set("hive.exec.dynamic.partition.mode", "nonstrict") //开启动态分区
      .set("spark.sql.sources.partitionOverwriteMode", "dynamic") //开启动态分区
      .set("hive.orc.splits.include.file.footer", "true") //是否将元数据保存在orc文件中
      .set("hive.exec.orc.default.stripe.size", "268435456") //默认256M
      .set("hive.exec.orc.split.strategy", "BI") //参数控制在读取ORC表时生成split的策略。BI策略以文件为粒度进行split划分；ETL策略会将文件进行切分，多个stripe组成一个split；HYBRID策略为：当文件的平均大小大于hadoop最大split值（默认256 * 1024 * 1024）时使用ETL策略，否则使用BI策略。
      .set("spark.sql.hive.convertMetastoreOrc", "true") //开启矢量化
      .set("spark.sql.orc.enableVectorizedReader", "true") //开启矢量化 ,矢量化需要100列内,并且字段是基本字段,非null arrays等
      .set("spark.sql.crossJoin.enabled", "true") //开启笛卡尔积
      .set("spark.sql.orc.filterPushdown", "true") //谓词下推
      .set("spark.sql.broadcastTimeout", "1200") //增加获取广播变量超时时间
      .set("hive.exec.dynamic.partition", "true")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("hive.exec.max.dynamic.partitions", "10000")
      .set("hive.exec.max.dynamic.partitions.pernode", " 10000")
      .set("hive.exec.max.created.files", " 1000000")
      .set("hive.merge.mapredfiles", "true")
      .set("hive.merge.mapfiles", "true")
      .set("hive.merge.size.per.task", "134217728")
      .set("hive.merge.smallfiles.avgsize", "134217728")
      .set("mapreduce.input.fileinputformat.split.maxsize", "134217728")
      .set("mapreduce.input.fileinputformat.split.minsize.per.rack", "134217728")
      .set("mapreduce.input.fileinputformat.split.minsize.per.node", "134217728")
      .set("hive.merge.sparkfiles", "true")
    spark = SparkSession.builder.config(conf).enableHiveSupport.getOrCreate
    //设置日志级别
    spark.sparkContext.setLogLevel("ERROR")//ERROR  INFO
    spark
  }

  def initSparkNew(appName: String): SparkSession = {
    val conf = new SparkConf().setAppName(appName)
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.scheduler.maxRegisteredResourcesWaitingTime", "90000")
      .set("spark.port.maxRetries", "100")
      .set("spark.driver.maxResultSize", "12g")
      .set("spark.rpc.io.backLog", "10000")
      .set("spark.cleaner.referenceTracking.blocking", "false")
      .set("spark.streaming.stopGracefullyOnShutdown", "true")
      .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
      .set("spark.driver.allowMultipleContexts", "true")
      .set("spark.sql.tungsten.enabled", "false")
      .set("quota.producer.default", (10485760 * 2).toString) // default is 10485760
      .set("quota.consumer.default", (10485760 * 2).toString)
      .set("cache.max.bytes.buffering", (20485760 * 2).toString)
      .set("spark.sql.broadcastTimeout", "36000")
      .set("spark.network.timeout", "30001")
      .set("spark.executor.heartbeatInterval", "30000")
      .set("hive.exec.dynamic.partition", "true")
      .set("hive.exec.dynamic.partition.mode", "nonstrict")
      .set("spark.sql.result.partition.ratio","1")
      .set("spark.executor.extraJavaOptions", "-XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
      .set("spark.driver.extraJavaOptions", "-XX:+PrintFlagsFinal -XX:+PrintReferenceGC -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCTimeStamps -XX:+PrintAdaptiveSizePolicy -XX:+UnlockDiagnosticVMOptions -XX:+G1SummarizeConcMark")
      .set("hive.vectorized.execution.enabled","false")
      .set("hive.vectorized.execution.reduce.enabled","false")
    spark = SparkSession.builder.config(conf).enableHiveSupport.getOrCreate
    //设置日志级别
    spark.sparkContext.setLogLevel("ERROR")//ERROR  INFO
    spark
  }

  def localInitSpark(appName: String): SparkSession = {
    val conf = new SparkConf().setMaster("local[*]").setAppName(appName)
      .set("spark.testing.memory", "2147480000")
    //2.实例化环境
    spark = SparkSession.builder().config(conf).getOrCreate()
    spark.sparkContext.setLogLevel("INFO")
    spark
  }
}
