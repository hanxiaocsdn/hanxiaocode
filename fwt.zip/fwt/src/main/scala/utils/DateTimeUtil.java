package utils;/*
 @author 01401062
 @DESCRIPTION 
 @create 2023/4/6
*/

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class DateTimeUtil {


    /**
     * 日期转时间戳
     */
    public static Long dateToTimestamp(String dateStr, String format) throws Exception {

        Long timestamp = 9999999999999L;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            Date date = sdf.parse(dateStr);
            timestamp = date.getTime() / 1000;
            return timestamp;
        } catch (ParseException e) {
            return timestamp;
        }

    }



    /**
     * 获取距离指定日期相隔days天的的日期：
     * @param inputDateStr 指定日期
     * @param days          相隔天数 正数表示在之后n天，负数表示在之前n天
     * @param dateFormat   日期格式(eg：yyyy-MM-dd, yyyy/MM/dd)
     * @return
     */

    public static String getSpecifiedDayAfter(String inputDateStr, int days, String dateFormat) throws Exception {

        try {
            SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
            Date inputDate = sdf.parse(inputDateStr);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(inputDate);
            calendar.add(Calendar.DAY_OF_YEAR, days);
            Date date = calendar.getTime();
            String dateStr = sdf.format(date).trim();
            return dateStr;
        } catch (ParseException e) {
            throw new Exception("日期格式转换异常");
        }

    }



    /**
     * 转换日期格式
     */

    public static String transformDateFormat(String srcDate,String srcDateFormat,String targetDateFormat) throws Exception {

        try {
            SimpleDateFormat sdf = new SimpleDateFormat(srcDateFormat);
            SimpleDateFormat sdfNew = new SimpleDateFormat(targetDateFormat);

            Date inputDate = sdf.parse(srcDate);
            return sdfNew.format(inputDate);
        } catch (ParseException e) {
            throw new Exception("日期格式转换异常");
        }

    }


    public static String timestampConvertDate(Long timeStamp, String format){

        String tm = new SimpleDateFormat(format).format(timeStamp);
//        System.out.println(tm);
        return tm;
    }


    public static String timestampConvertDate(int timeStamp, String format){

        String tm = new SimpleDateFormat(format).format(timeStamp);
//        System.out.println(tm);
        return tm;
    }



    public static String timestampConvertDateMin(Long timeStamp, String format){

        String tm = new SimpleDateFormat(format).format(timeStamp * 1000);
//        System.out.println(tm);
        return tm;
    }



    public static Boolean compareDate(String time1, String time2){
      try{
          DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
          Date parse1 = dateFormat.parse(time1);
          System.out.println(parse1);
          Date parse2 = dateFormat.parse(time2);
          System.out.println(parse2);
          boolean before = parse1.before(parse2);
          return before;
      } catch (Exception e){
          return true;
      }
    }


    public static String longToTime(Long timestamp,String format){

        Long duration =0L;
        String datetime = "";
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
            datetime = simpleDateFormat.format(new Date(timestamp + duration));
        } catch (Exception e){
            System.out.println(">>>>>>时间戳解析异常Exception: " + e );
        }
        return datetime;
    }


    /**
     * Translate date which is String format like param "format" to Date format
     *
     * @param str    日期字符串
     * @param format 日期字符串的格式
     * @return 日期类型的数据
     */
    public static Date getDateFromStr(String str, String format) {
        if (!StringUtils.nonEmpty(str)) {
            return null;
        }
        Date dateValue;

        try {
            dateValue = new SimpleDateFormat(format).parse(str);
        } catch (Exception e) {
            System.err.println("getDateFromStr execute exception, exception info: " + e);
            return null;
        }

        return dateValue;
    }


    /**
     * Translate date which is String format "yyyy-MM-dd HH:mm:ss" to Date format
     *
     * @param str 日期字符串
     * @return 日期类型的数据
     */
    public static Date getDateFromStr(String str) {
        if (!StringUtils.nonEmpty(str)) {
            return null;
        }
        Date dateValue;

        try {
            dateValue = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);

        } catch (Exception e) {
            System.err.println("getDateFromStr execute exception, exception info: " + e);
            return null;
        }

        return dateValue;
    }


    /**
     * 字符串日期比较大小
     * @param dateString1
     * @param dateString2
     * @param formatPattern
     * @return
     */

    public static int compareDates(String dateString1, String dateString2, String formatPattern) {
        DateFormat dateFormat = new SimpleDateFormat(formatPattern);

        try {
            Date date1 = dateFormat.parse(dateString1);
            Date date2 = dateFormat.parse(dateString2);

            return date1.compareTo(date2);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return 0; // 默认返回0，表示日期格式解析失败
    }

    public static int compareDates(Long dateString1, String string2, String formatPattern) {
        DateFormat dateFormat = new SimpleDateFormat(formatPattern);

        try {
            String string1 = timestampConvertDate(dateString1 * 1000, "yyyy-MM-dd HH:mm:ss");

            Date date1 = dateFormat.parse(string1);
            Date date2 = dateFormat.parse(string2);

            return date1.compareTo(date2);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return 0; // 默认返回0，表示日期格式解析失败
    }



    public static void main(String[] args) throws ParseException {

//        Boolean aBoolean = compareDate("2023-04-10 15:00:05", "2023-04-10 15:00:10");
//        System.out.println(aBoolean);


//        int i = compareDates(1687134581L, "2023-06-18 22:21:05", "yyyy-MM-dd HH:mm:ss");

//        System.out.println(i);
//        System.out.println(timestampConvertDateMin(Long.valueOf("1681027497"),"yyyyMMddHHmmss"));


    }



}
