package utils

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat_ws, row_number}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory

import java.sql.{Connection, DriverManager, PreparedStatement}
import scala.collection.mutable.ListBuffer

/**
 * @author 01418539
 * @date 2022年01月20日 19:51
 */
object JDBCUtils {
  val logger = LoggerFactory.getLogger(this.getClass)

  var connection: Connection = null

  /**
   * 获取数据库连接gis_oms_lip_pns
   */
  def getDevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_pns?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "gis_oms_pns"
    //密码
    val password = "gis_oms_pns@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 智慧社区--bdp平台上的mysql库 获取数据库gis_oms_lip_egov连接
   */
  def getDevEGOVMysqlConnect(): Connection = {

    val url = "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_egov?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "gis_oms_egov"
    //密码
    val password = "gis_oms_egov@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 智慧社区项目--获取dev mysql数据库连接
   */
  def getSmartDeMysqlConnect(): Connection = {

    val url = "jdbc:mysql://etraffic-m.db.sfcloud.local:3306/smart_community?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "statUser"
    //密码
    val password = "statUser@ft123"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 价值路线数据mysql连接库
   *
   * @return
   */
  def getPnsDevMysqlConnect(): Connection = {
    val url = "jdbc:mysql://rsspnsrt-m.db.sfcloud.local:3306/rsspnsrt?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "rsspnsrt"
    //密码
    val password = "T6TzIua9dI"
    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 智慧社区项目--获取dev CK数据库连接
   */
  def getSmartDevCKConnect(): Connection = {

    val url = "jdbc:clickhouse://10.216.162.10:8123/default"
    //驱动名称
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    //用户名
    val username = "default"
    //密码
    val password = "123456"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接clickhouse数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 自搭生产环境--获取dev CK数据库连接
   */
  def getOwnerDevCKConnect(): Connection = {

    val url = "jdbc:clickhouse://10.119.82.211:8123/dm_ck_scm"
    //驱动名称
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    //用户名
    val username = "dm_ck_scm"
    //密码
    val password = "dm_ck_scm@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接clickhouse数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 衡鉴平台业务 ck 导航 clickhouse 连接信息 与原mysql库 账号密码信息一致
   */
  def getSmartNaviCKConnect(): Connection = {
    val url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_pns"
    //驱动名称
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    //用户名
    val username = "gis_oms_pns"
    //密码
    val password = "gis_oms_pns@123@"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接clickhouse数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 导航 clickhouse 连接信息 与原mysql库 账号密码信息一致
   */
  def getSFCompressCKConnect(): Connection = {
    val url = "jdbc:clickhouse://ch-gis.sf-express.com:80/graph_cell"
    //驱动名称
    val driver = "ru.yandex.clickhouse.ClickHouseDriver"
    //用户名
    val username = "gis"
    //密码
    val password = "Bzb1qcU5"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接clickhouse数据库时出现错误", ex)
        throw ex
    }
  }


  /**
   * GIS-RSS-ETA：油耗数据--获取dev mysql数据库连接
   */
  def getETADevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://rosopr-m.db.sfcloud.local:3306/rosopreta?useUnicode=true&characterEncoding=utf-8"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "rosopreta"
    //密码
    val password = "steve@1234"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接ETA的mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 【丰景台mysql库】导航大宽表：mysql数据库连接
   * todo mysql版本8.0.22
   * 【备注】
   */
  def getNaviDevMysqlConnect(): Connection = {
    val url = "jdbc:mysql://naviqueryindex-m.db.sfcloud.local:3306/navi_index?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
    //驱动名称
    //    val driver = "com.mysql.jdbc.Driver"
    val driver = "com.mysql.cj.jdbc.Driver"
    //用户名
    val username = "navi_index"
    //密码
    val password = "sjHu_86tt9" //new pw 20231026
    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接NAVI的mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 【丰景台替换版本mysql库】导航大宽表：mysql数据库连接
   * todo mysql版本8.0.22
   */
  def getFJTDevMysqlConnect(): Connection = {
    val url = "jdbc:mysql://10.242.5.15:3306/bdp?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
    //驱动名称
    val driver = "com.mysql.cj.jdbc.Driver"
    //用户名
    val username = "bdp"
    //密码
    val password = "FT#lyxbj0829"
    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接bdp的mysql数据库时出现错误", ex)
        throw ex
    }
  }


  /**
   * 燃油消耗：mysql数据库连接 vmscore
   */
  def getFlameDevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://vmscore-s1.db.sfcloud.local:3306/vmscore?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "vmscore"
    //密码
    val password = "vmscore123!@#"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接FLAME的mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 时效晚点项目需要用到该表的网点电子围栏打卡半径 omcs
   */
  def getOMCSDevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://OMCS-M.db.sfdc.com.cn:3306/omcs?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "gisetl"
    //密码
    val password = "GisBdp@0719"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接 OMCS 的mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 实时薪酬scm --- 监控任务表 db:plan
   */
  def getSCMDevMysqlConnect(): Connection = {

    val url = "jdbc:mysql://plan-m.db.sfcloud.local:3306/plan?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai"
    //驱动名称
    val driver = "com.mysql.jdbc.Driver"
    //用户名
    val username = "plan"
    //密码
    val password = "plan20210121#"

    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接 实时薪酬 的mysql数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 获取数据库连接,公共方法
   *
   * @param url    连接信息
   * @param driver 驱动--mysql不同版本
   * @param username
   * @param password
   * @return
   */
  def getDatabaseConnect(url: String, driver: String, username: String, password: String): Connection = {
    try {
      //注册Driver
      Class.forName(driver)
      //得到连接
      connection = DriverManager.getConnection(url, username, password)
      connection
    } catch {
      case ex: Exception => logger.error("连接数据库时出现错误", ex)
        throw ex
    }
  }

  /**
   * 向mysql导数前 建表操作
   *
   * @param tableName mysql库中的表名
   * @param sql       建表语句，map映射获取
   * @param conn      mysql库的JDBC建立连接
   */
  def processBDPMysqlCreateTable(tableName: String, sql: String, conn: Connection): Unit = {
    try {
      //删除
      val delSql = s"DROP table IF EXISTS $tableName"
      val delState: PreparedStatement = conn.prepareStatement(delSql)
      delState.execute()
    } catch {
      case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
    }
    //建表
    try {
      val createSQl: PreparedStatement = conn.prepareStatement(sql)
      createSQl.execute()
      logger.error(s"表：$tableName 的建表语句为：" + sql)
      logger.error(s"在bdp的mysql库中建表 $tableName 成功！！！！！")
    } catch {
      case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
    }

  }

  /**
   * 读取bdp数据导入 数据库中
   * 适用场景：需要添加随机主键ID 的情况，且日期字段 inc_day 重命名为 STATDATE
   *
   * @param bdp_df
   * @param db_name
   * @param tableName
   * @param start_day
   * @param end_day
   */
  def upsertToDevMysqlwithAddID(connect: Connection, bdp_df: DataFrame, db_name: String, tableName: String, start_day: String, end_day: String): Unit = {
    val o_dataDf = bdp_df
      .withColumn("random_id", row_number().over(Window.partitionBy("inc_day").orderBy("inc_day")))
      .withColumn("id", concat_ws("_", col("random_id"), col("inc_day"))).drop("random_id")
      .na.fill("")
      .na.fill(0)
      .na.fill(0.0)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>>>加载的数据总量为>>>>>>>>>" + o_dataDf.count())
    //将mysql中原表数据分区删除 支持重跑
    try {
      val querySql = s"select * from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = connect.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val del: PreparedStatement = connect.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 $db_name.$tableName 中$start_day 至 $end_day 数据时出现错误", ex, ex.printStackTrace())
        throw ex
    }

    //优化设置为批量写入
    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")

    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        logger.error("listRows.size:" + listRows.size)
        upsertBatch(connect, tableName, fields, blank_places, listRows) //执行批量插入数据
      }
    })
    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = connect.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 $db_name.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 $db_name.$tableName 中$start_day 至 $end_day 数据时出现错误", ex, ex.printStackTrace())
        throw ex
    }
  }

  /**
   * 【丰景台原始navi_index库替换】读取【bdp】数据导入 数据库中
   * 适用场景：需要添加随机主键ID 的情况，且日期字段 inc_day 重命名为 STATDATE
   *
   * @param bdp_df
   * @param db_name
   * @param tableName
   * @param start_day
   * @param end_day
   */
  def upsertToFJTDevMysqlwithAddID(connect: Connection, bdp_df: DataFrame, db_name: String, tableName: String, start_day: String, end_day: String): Unit = {
    val o_dataDf = bdp_df
      .withColumn("random_id", row_number().over(Window.partitionBy("inc_day").orderBy("inc_day")))
      .withColumn("id", concat_ws("_", col("random_id"), col("inc_day"))).drop("random_id")
      .na.fill("")
      .na.fill(0)
      .na.fill(0.0)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>>>加载的数据总量为>>>>>>>>>" + o_dataDf.count())
    //将mysql中原表数据分区删除 支持重跑
    try {
      val querySql = s"select * from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = connect.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val del: PreparedStatement = connect.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 $db_name.$tableName 中$start_day 至 $end_day 数据时出现错误", ex, ex.printStackTrace())
        throw ex
    }

    //优化设置为批量写入
    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")

    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        logger.error("listRows.size:" + listRows.size)
        upsertBatch(getFJTDevMysqlConnect(), tableName, fields, blank_places, listRows) //执行批量插入数据
      }
    })
    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = connect.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 $db_name.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 $db_name.$tableName 中$start_day 至 $end_day 数据时出现错误", ex, ex.printStackTrace())
        throw ex
    }
  }


  /**
   * 适用场景：自带主键ID 的情况，日期字段 inc_day
   *
   * @param bdp_df
   * @param db_name
   * @param tableName
   * @param start_day
   * @param end_day
   */
  def upsertToDevMysqlIncday(connect: Connection, bdp_df: DataFrame, db_name: String, tableName: String, start_day: String, end_day: String): Unit = {
    val o_dataDf = bdp_df.na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>>>加载的数据总量为>>>>>>>>>" + o_dataDf.count())
    //将mysql中原表数据分区删除 支持重跑
    try {
      val querySql = s"select * from $tableName where SUBSTRING(inc_day,1,8) >= '$start_day' and SUBSTRING(inc_day,1,8) <= '$end_day'"
      val query: PreparedStatement = connect.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from $tableName where SUBSTRING(inc_day,1,8) >= '$start_day' and SUBSTRING(inc_day,1,8) <= '$end_day'"
        val del: PreparedStatement = connect.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 $db_name.$tableName 中$start_day 至 $end_day 数据时出现错误", ex, ex.printStackTrace())
        throw ex
    }

    //优化设置为批量写入
    val colNames = o_dataDf.schema.toList
    val fields = colNames.map("`" + _.name + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")

    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        logger.error("listRows.size:" + listRows.size)
        upsertBatch(getSCMDevMysqlConnect(), tableName, fields, blank_places, listRows) //执行批量插入数据
      }
    })
    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from $tableName where SUBSTRING(inc_day,1,8) >= '$start_day' and SUBSTRING(inc_day,1,8) <= '$end_day'"
      val query: PreparedStatement = connect.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 $db_name.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 $db_name.$tableName 中$start_day 至 $end_day 数据时出现错误", ex, ex.printStackTrace())
        throw ex
    }
  }


  /**
   * 查询指定数据库中的表信息
   *
   * @param conn    数据库连接信息
   * @param mysqlTN mysql中对应的表名
   */
  def queryTablesInMysql(conn: Connection, dbN: String, mysqlTN: String): Unit = {
    val arr = mysqlTN.replaceAll("'", "").split(",")
    //查看建表语句
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      try {
        val cs = s"show create table $tableName"
        val cs_create: PreparedStatement = conn.prepareStatement(cs)
        val cs_res = cs_create.executeQuery()
        while (cs_res.next()) {
          val Table = cs_res.getString("Table")
          val Create = cs_res.getString("Create Table")
          logger.error("表：" + Table + "的建表语句为：" + Create)
        }
      } catch {
        case ex: Exception =>
          val cs = s"show tables"
          val cs_create: PreparedStatement = conn.prepareStatement(cs)
          val cs_res = cs_create.executeQuery()
          while (cs_res.next()) {
            val tables = cs_res.getString("Tables_in_" + dbN)
            logger.error("库中所有表为：" + tables)
          }
          logger.error(s"查看 $tableName 的建表语句时出现错误，请核对输入的表名在mysql中是否存在", ex)
          throw ex
      }
    }
    //查看表中数据总量cnt
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      try {
        val cnts = s"select count(1) as cnt from $tableName limit 10"
        val cnts_count: PreparedStatement = conn.prepareStatement(cnts)
        val cnts_res = cnts_count.executeQuery()
        while (cnts_res.next()) {
          val cnt = cnts_res.getString("cnt")
          logger.error("表：" + tableName + " 的数据总量为>" + cnt)
        }
      } catch {
        case ex: Exception => logger.error(s"查询表 $tableName 中 数据总量时出现错误", ex)
          throw ex
      }
    }
  }

  /**
   * 读取mysql表中的数据写入hive表中
   *
   * @param spark
   * @param mysqlTable
   * @param hiveTable
   */
  def loadMysqlTableToHive(spark: SparkSession, params: Map[String, String], dbName: String, mysqlTable: String, hiveTable: String, pflag: Boolean, partitionCol: Seq[String] = Seq("")): Unit = {
    val hive_table_struct: String = spark.sql(s"select * from $dbName.$hiveTable limit 1").schema.toList.map(_.name).mkString(",")
    val query_state = s"(select $hive_table_struct from $mysqlTable) as t"

    try {
      val df = spark.read.format("jdbc").options(params).option("dbtable", query_state).load()
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        df.createOrReplaceTempView("tmpTableName") //临时表
        spark.sql(s"use $dbName")
        //是否分区表标识
        if (pflag) {
          val parCols = partitionCol.mkString(",")
          spark.sql(s"insert overwrite table $hiveTable partition($parCols) select * from tmpTableName")
        }
        spark.sql(s"truncate table $dbName.$hiveTable")
        //非分区表 数据全量插入
        spark.sql(s"insert into $hiveTable select * from tmpTableName")
      } else {
        throw new Exception(s"mysql的 $hiveTable 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $hiveTable 中 插入数据时出现错误", ex)
        throw ex
    }
  }

  /**
   * 数据批量插入MySQL
   *
   * @param connect
   * @param mysqlT
   * @param fields
   * @param blank_places
   * @param list
   */
  def upsertBatch(connect: Connection, mysqlT: String, fields: String, blank_places: String, list: ListBuffer[Row]): Unit = {
    var upsert: PreparedStatement = null
    try {
      connect.setAutoCommit(false) // 禁用主动提交
      val upsertsql = s"insert into $mysqlT($fields) values($blank_places)"
      upsert = connect.prepareStatement(upsertsql)
      var batchIndex = 0
      for (row <- list) {
        try {
          for (i <- 0 until fields.split(",").length) {
            upsert.setString(i + 1, row.get(i).toString)
          }
        } catch {
          case ex: Exception => logger.error(s"往表 $mysqlT 中插入数据时出现错误", ex)
            throw ex
        }
        // 退出批次
        upsert.addBatch()
        batchIndex += 1
        // 管制提交的数量,MySQL的批量写入尽量限度提交批次的数据量
        if (batchIndex % 1000 == 0 && batchIndex != 0) {
          upsert.executeBatch()
          upsert.clearBatch()
        }
      }
      // 提交批次
      upsert.executeBatch()
      connect.commit()
    } catch {
      case e: Exception => println(e.printStackTrace())
    }
  }
}