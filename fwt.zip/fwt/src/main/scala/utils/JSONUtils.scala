package com.sf.gis.utils

import com.alibaba.fastjson.{JSON, JSONObject}
import utils.StringUtils

object JSONUtils extends Serializable {

  def isValidJSON(jsonStr: String): Boolean = {
    var boolean: Boolean = true
    try {
      JSON.parseObject(jsonStr)
    } catch {
      case e: Exception => boolean = false
    }
    boolean
  }


  /**
   * 替换异常引号json字符串
   */

  def replaceErrJsonStr(str: String): String = {
    val strRturn = str.replaceAll("\\{\"", "{'")
      .replaceAll("\":\"", "':'")
      .replaceAll("\",\"", "','")
      .replaceAll("\":", "':")
      .replaceAll(",\"", ",'")
      .replaceAll("\"\\}", "'}")
      .replaceAll("\"", "")
      .replaceAll("'", "\"")
      .replaceAll("", "")
      .replaceAll("\\\\", "?")

    strRturn
  }


  /** @note 解析JSON数据获取指定的KEY-Value值 */
  def getJsonValue(obj: JSONObject, keys: String, defaultValue: String): String = {
    var value: String = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- keyArr.indices) {
        if (i < (keyArr.length - 1))
          tempObj = tempObj.getJSONObject(keyArr(i))
        else
          value = tempObj.getString(keyArr(i))
      }
    } catch {
      case e: Exception => println(">>>>>>解析JSON数据项出现异常Exception: " + e + "，\n其中JSON示例数据为: " + obj + "\n查询的key为:" + keys)
    }
    if (value == null) value = defaultValue
    value
  }


  /** @note 解析JSON数据获取指定的KEY-Value值 */
  def getJsonValueInt(obj: JSONObject, keys: String, defaultValue: Integer): Integer = {
    //var value : Int = null
    val tempObj = obj
    var res = 0
    try {
      if (StringUtils.nonEmpty(tempObj.getString(keys))) {
        res = tempObj.getIntValue(keys)
      } else {
        res = defaultValue
      }
    } catch {
      case e: Exception => println("获取整形json时出现异常")
    }

    res

  }


  /** @note 解析JSON数据获取指定的KEY-Value值 */
  def getJsonValueDouble(obj: JSONObject, keys: String, defaultValue: Double): Double = {
    var tempObj = obj
    var res = 0.0
    try {
      if (StringUtils.nonEmpty(tempObj.getString(keys))) {
        res = tempObj.getDouble(keys)
      } else {
        res = defaultValue
      }
    } catch {
      case e: Exception => println("获取double json时出现异常")
    }

    res

  }


  /** @note 解析JSON数据获取指定的KEY-Value值 */
  def getJsonValueLong(obj: JSONObject, keys: String, defaultValue: Long): Long = {
    //var value : Int = null
    val tempObj = obj
    var res = 0L
    try {
      if (StringUtils.nonEmpty(tempObj.getString(keys))) {
        res = tempObj.getLongValue(keys)
      } else {
        res = defaultValue
      }
    } catch {
      case e: Exception => println("获取整形json时出现异常")
    }

    res

  }

}
