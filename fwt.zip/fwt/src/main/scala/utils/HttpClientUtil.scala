package utils

import com.alibaba.fastjson.{JSON, JSONObject}
import org.apache.http.client.methods.{CloseableHttpResponse, HttpGet, HttpPost}
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.{CloseableHttpClient, HttpClients}
import org.apache.http.util.EntityUtils
import org.apache.http.{HttpEntity, HttpStatus}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import java.util.Calendar

/**
 * @author 01418539
 * @date 2021年12月10日 18:54
 */
object HttpClientUtil {
  val logger: Logger = Logger.getLogger(this.getClass.getSimpleName.stripSuffix("$"))


  /**
   * http发送get请求：根据传入的参数进行http请求补齐，并获取get请求返回值
   *
   * @param urlPattern
   * @param param1
   * @param param2
   * @param param3
   * @return
   */
  def getJsonParam(urlPattern: String, param1: String, param2: String, param3: String = ""): String = {
    val url = String.format(urlPattern, param1, param2, param3)
    url
  }

  /**
   * http发送get请求：根据传入的参数进行http请求补齐，并获取get请求返回值
   *
   * @param urlPattern
   * @param param1
   * @param param2
   * @param param3
   * @return
   */
  def getJsonByUrl(urlPattern: String, param1: String, param2: String, param3: String = ""): JSONObject = {
    val url = String.format(urlPattern, param1, param2, param3)
    val jsonData: JSONObject = getJsonByGet(url, 2, "UTF-8")
    jsonData
  }

  /**
   * 访问http请求，返回JSON结果
   *
   * @param url 请求的地址
   * @return
   */
  def getJsonByGet(url: String, tryCnt: Int, charSet: String): JSONObject = {
    val httpClient: CloseableHttpClient = HttpClients.createDefault()
    var jsonObj: JSONObject = null
    var count = 0
    while (count < tryCnt) {
      count = count + 1
      try {
        var httpResponse: CloseableHttpResponse = null
        val httpGet = new HttpGet(url)
        httpResponse = httpClient.execute(httpGet)
        if (httpResponse.getStatusLine.getStatusCode.equals(HttpStatus.SC_OK)) {
          val httpEntity: HttpEntity = httpResponse.getEntity
          val stringEntity: String = EntityUtils.toString(httpEntity, charSet)
          jsonObj = JSON.parseObject(stringEntity)
          count = tryCnt
        }
        httpResponse.close()
      }
      catch {
        case e: Exception => logger.error(">>>获取httpResponse异常：" + e)
          Thread.sleep(1000)
      }

    }
    httpClient.close()
    jsonObj
  }

  def postResponse(url: String, params: String = null, header: String = null): String = {
    val httpClient = HttpClients.createDefault() // 创建 client 实例
    val post = new HttpPost(url) // 创建 post 实例

    // 设置 header
    if (header != null) {
      val json = JSON.parseObject(header)
      json.keySet().toArray.map(_.toString).foreach(key => post.setHeader(key, json.getString(key)))
    }

    if (params != null) {
      post.setEntity(new StringEntity(params, "UTF-8"))
    }

    val response = httpClient.execute(post) // 创建 client 实例
    EntityUtils.toString(response.getEntity, "UTF-8") // 获取返回结果
  }

  /**
   * 通过调整并发控制接口访问速度
   * @param fun
   * @param parallelism
   * @param ak
   * @param akMinuLimit
   * @return
   */
  def runInterfaceWithAkLimit(logger: Logger, spark: SparkSession, dataRdd: RDD[JSONObject], fun: (String, JSONObject) => JSONObject, parallelism: Int, ak: String, akMinuLimit: Int): RDD[JSONObject] = {
    val cores: Integer = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.cores", "0"))
    val excutors: Integer = Integer.valueOf(spark.sparkContext.getConf.get("spark.executor.instances", "0"))
    logger.error("excutor 数量:" + excutors + ",cores数量:" + cores)

    //为了精确控制并发，task数量和并行度需要小于excutors数量，否则并行度和ak单位分钟限制无法精确控制
    var maxParallelism: Int = parallelism
    if (parallelism > excutors) maxParallelism = excutors

    logger.error("最大分区数：" + maxParallelism)
    val curPartition: Int = dataRdd.getNumPartitions
    var runRdd: RDD[JSONObject] = null
    if (curPartition != maxParallelism) {
      runRdd = dataRdd.repartition(maxParallelism)
      logger.error("重分区：" + maxParallelism)
    } else runRdd = dataRdd

    var maxMinueOfPartition: Int = akMinuLimit / maxParallelism
    if (parallelism > maxParallelism) maxMinueOfPartition = akMinuLimit / maxParallelism

    logger.error(s"单分区ak最大分钟限制：$maxMinueOfPartition 次")
    val retRdd: RDD[JSONObject] = runRdd.mapPartitions(partitions => {
      val partitionLimitMinu: Int = maxMinueOfPartition
      var lastMin: Int = Calendar.getInstance().get(Calendar.MINUTE)
      var timeInt = 0
      var partitionsCount = 0
      //实际单为并行跑数
      partitions.map(obj => {
        partitionsCount = partitionsCount + 1
        if (partitionsCount % 10000 == 0) {
          logger.error(partitionsCount.toString)
        }
        val second: Int = Calendar.getInstance().get(Calendar.SECOND)
        val cur: Int = Calendar.getInstance().get(Calendar.MINUTE)
        if (cur == lastMin) {
          timeInt = timeInt + 1
          if (timeInt >= partitionLimitMinu) {
            logger.error("秒数:" + second + ",次数：" + timeInt + ",总数：" + partitionsCount)
            Thread.sleep((60 - second) * 1000)
          }
        } else {
          timeInt = 1
          lastMin = cur
        }
        fun(ak, obj)
      })
    })

    retRdd
  }

}
