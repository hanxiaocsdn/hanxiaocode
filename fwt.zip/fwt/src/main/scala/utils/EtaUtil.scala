package utils

import com.alibaba.fastjson.{JSON, JSONObject}
import constant.HttpConstant.{HTTP_ETA_STDLINE_P, HTTP_XY_COORDS_P}
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.ColumnUtil.strNotNull

import scala.collection.JavaConversions.asScalaIterator
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.Sorting

/**
 * @task_id:
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2023/6/6 18:46
 */
object EtaUtil {
  val logger = Logger.getLogger(EtaUtil.getClass)

  /**
   * 解析json日志 无值时 赋空值
   *
   * @param obj
   * @param keys
   * @param defaultValue
   * @return
   */
  def getJsonValue(obj: JSONObject, keys: String, defaultValue: String): String = {
    var result: String = null
    var tempObj = obj
    try {
      val keyArr: Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        } else {
          result = tempObj.getString(keyArr(i))
        }
      }
    } catch {
      case e: Exception => logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if (result == null) result = defaultValue
    result
  }

  /**
   * 根据出发时间，映射出发时间段
   *
   * @return
   */
  def getDepartTmBlockUDF = udf((plan_depart_tm: String) => {
    var depart_tm_block = ""
    if (strNotNull(plan_depart_tm)) {
      try {
        plan_depart_tm.split("\\s+")(1).split(":")(0).toInt match {
          case x if x >= 0 && x < 6 => depart_tm_block = "[0-6)"
          case x if x >= 6 && x < 9 => depart_tm_block = "[6-9)"
          case x if x >= 9 && x < 17 => depart_tm_block = "[9-17)"
          case x if x >= 17 && x < 20 => depart_tm_block = "[17-20)"
          case x if x >= 20 && x <= 24 => depart_tm_block = "[20-24]"
          case _ => depart_tm_block = ""
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    depart_tm_block
  })

  /**
   * 提取起终网点编号 3位或者4位 按照条件保留关联
   *
   * @return
   */
  def extractCodeUDF = udf((dept: String) => {
    var res = ""
    try {
      res = dept.replaceAll("([a-zA-Z]+)", "-").split("-")(0)
    } catch {
      case e: Exception => "" + e
    }
    res
  })


  /**
   * 提取line_code 3位或者4位 (第1个编码或者第2个编码)
   *
   * @return
   */
  def extractLinecodeRlikeUDF(position: Int) = udf((line_code: String) => {
    var res = ""
    val regex = """^([0-9]*)([a-zA-Z]*)(\d+)([a-zA-Z]*)([0-9]*)$""".r
    try {
      line_code match {
        case regex(num1, str1, num2, str2, num3) =>
          if (position == 1) {
            if (num1 == "391") res = num1 + str1 else res = num1
          } else {
            if (num2 == "391") res = num2 + str2 else res = num2
          }
        case _ => res = ""
      }
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  /**
   * 提取起终网点编号 3位或者4位 按照条件保留关联
   *
   * @return
   */
  def extractCodeRlikeUDF = udf((dept: String) => {
    var res = ""
    val regex = """^([a-zA-Z]*)(\d+)([a-zA-Z0-9]*)$""".r
    try {
      dept match {
        case regex(_, num, _) => if (num == "391") res = dept else res = num
        case _ => res = ""
      }
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  /**
   * 32进制字符串转10进制
   *
   * @param base32Number
   * @return
   */
  def base32ToDecimal(base32Number: String): Long = {
    var res = 0l
    val base32Digits = "0123456789ABCDEFGHIJKLMNOPQRSTUV" // 32进制的符号集
    try {
      res = base32Number.toUpperCase.foldLeft(0L)((result, digit) => result * 32 + base32Digits.indexOf(digit))
    } catch {
      case e: Exception => "" + e
    }
    res
  }

  //对返回的5类数据切分
  def splitFun(sep: String) = udf((ds_tl_infos: String) => {
    var res: Array[String] = Array()
    try {
      if (strNotNull(ds_tl_infos)) {
        res = ds_tl_infos.split(sep, -1)
        //        res = strHandle(ds_tl_infos, sep)
      }
    } catch {
      case e: Exception => ""
    }
    res
  })


  def strHandle(str: String, sep: String, flag: Boolean = true): Array[String] = {
    var res: Array[String] = Array()
    try {
      if (flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep)
      //是否需要排序
      if (!flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep).sortWith(_.compareTo(_) < 0)
    } catch {
      case e: NullPointerException => ""
      case e: ArrayIndexOutOfBoundsException => ""
    }
    res
  }

  /**
   * 外部读取csv文件，获取城市编码 和 城市名称 映射信息
   *
   * @param spark
   * @return
   */
  def getCsvCityCodeDF(spark: SparkSession): DataFrame = {
    val o_whole_city_df = spark.sql("""select city_name,city_code from dm_gis.dm_adcode_map_city_dtl group by city_name,city_code""") //获取城市映射表
    //    val inputPath = "/user/01418539/upload/file/eta/adcode.csv"
    //    val o_whole_city_df = spark.read
    //      .option("header", "false")
    //      .option("delimiter", "\\t")
    //      .option("encoding", "utf-8") //utf-8 gbk
    //      .option("inferSchema", true.toString)
    //      .csv(inputPath)
    //      .toDF("area_name", "city_name", "adcode", "city_code", "descrip")
    //      .groupBy("city_name", "city_code").agg(lit(true))
    //      .select("city_name", "city_code")
    o_whole_city_df
  }


  /**
   * 外部读取csv文件，获取全国城市流向信息
   *
   * @param spark
   * @return
   */
  def getCsv2DF(spark: SparkSession): (Seq[String], mutable.HashMap[String, String], DataFrame) = {
    val city_adcode_map = new mutable.HashMap[String, String]()
    //    val inputPath = "/user/01418539/upload/file/eta/adcode.csv"
    //    val o_whole_city_df = spark.read
    //      .option("header", "false")
    //      .option("delimiter", "\\t")
    //      .option("encoding", "utf-8") //utf-8 gbk
    //      .option("inferSchema", true.toString)
    //      .csv(inputPath)
    //      .toDF("area_name", "city_name", "adcode", "city_code", "descrip")
    //      .groupBy("city_name", "adcode").agg(lit(true))
    //      .select("city_name", "adcode")
    //      .persist()
    val o_whole_city_df = spark.sql("""select city_name,adcode from dm_gis.dm_adcode_map_city_dtl group by city_name,adcode""") //获取城市映射表
    o_whole_city_df.toLocalIterator.foreach(row => {
      val city_name = row.getAs[String]("city_name")
      val adcode = row.getAs[String]("adcode")
      city_adcode_map.put(adcode, city_name)
    })
    val city_map_info = o_whole_city_df.select("adcode").collect().map(_.getString(0)).toSet.toSeq
    (city_map_info, city_adcode_map, o_whole_city_df)
  }

  /**
   * 调用接口拼接经纬度
   *
   * @param lineCode
   * @param plan_time
   * @param src_zone_code
   * @param dest_zone_code
   * @return
   */
  def postTrackqueryIntegrate(lineCode: String, plan_time: String, src_zone_code: String, dest_zone_code: String): String = {
    val points_ab = new ArrayBuffer[String]()

    val params = s"""{"interfaceControl":0,"planTime":"$plan_time","ak":"70b8ef2d67a946ff8f2493389f77028f","lineCode":"$lineCode","opt":"std2","srcZoneCode":"$src_zone_code","vehicle":8,"destZoneCode":"$dest_zone_code"}""".stripMargin
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_ETA_STDLINE_P, params, 3, 2)
      logger.error("接口正常调用中,传入参数为>>" + params)
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val coords = result.getJSONArray("coords")
        for (i <- 0 until coords.size()) {
          points_ab += coords.getJSONArray(i).toJSONString.replaceAll("\\[|\\]|\"", "")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    points_ab.mkString("|")
  }

  /**
   * 调用接口拼接经纬度 + x1 y1 x2 y2
   *
   * @param lineCode
   * @param plan_time
   * @param src_zone_code
   * @param dest_zone_code
   * @param x1
   * @param y1
   * @param x2
   * @param y2
   * @return
   */
  def postTrackqueryIntegrateWithLongLat(lineCode: String, plan_time: String, src_zone_code: String, dest_zone_code: String, x1: Double, y1: Double, x2: Double, y2: Double): String = {
    val points_ab = new ArrayBuffer[String]()

    val params = s"""{"interfaceControl":0,"planTime":"$plan_time","ak":"70b8ef2d67a946ff8f2493389f77028f","lineCode":"$lineCode","opt":"std2","srcZoneCode":"$src_zone_code","vehicle":8,"destZoneCode":"$dest_zone_code","x1":$x1,"y1":$y1,"x2":$x2,"y2":$y2}""".stripMargin
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_ETA_STDLINE_P, params, 3, 2)
      logger.error("接口正常调用中,传入参数为>>" + params)
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val coords = result.getJSONArray("coords")
        for (i <- 0 until coords.size()) {
          points_ab += coords.getJSONArray(i).toJSONString.replaceAll("\\[|\\]|\"", "")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    points_ab.mkString("|")
  }

  /**
   * 获取得到下道里程的接口
   *
   * @param points
   * @param date
   * @return
   */
  def getByroadInfo(points: String, date: String): (String, String, String, String) = {
    val params = //ak的并发 100/S
      s"""{
         |    "ak": "2e4b2a16ef2a4427917f366fb22febb5",
         |    "simple_distance": 0,
         |    "useEstimateTime": 1,
         |    "test": 1,
         |    "stype": 0,
         |    "etype": 2,
         |    "passport": "100000",
         |    "mode": 2,
         |    "speed": 1,
         |    "rtic":0,
         |    "rtic_dur":0,
         |    "output":"json",
         |    "Toll": 1,
         |    "point_src" : 1,
         |    "points":"$points",
         |    "date": "$date"}
         |""".stripMargin
    logger.error("接口正常调用中,传入参数为>>" + params)
    val dynSpeed_arr = Seq("2", "3", "4", "5", "6", "7", "8", "9")
    val dr_len_ab = new ArrayBuffer[String]()
    val speed_ab = new ArrayBuffer[String]()
    var byroad_distance, highway_distance, sum_len, prop_cnt: Double = 0.0
    var part_cnt, all_cnt: Int = 0
    var byroad_speed = "35.0"
    try {
      val hw_str = HttpInvokeUtil.sendPostH(HTTP_XY_COORDS_P, params, 3, 2, "2e4b2a16ef2a4427917f366fb22febb5", "")
      logger.error(">>>>>获取轨迹点信息接口 接口正常调用中>>>>>")
      val hw_str_json = JSON.parseObject(hw_str)
      val route = hw_str_json.getJSONObject("route")
      if (route != null) {
        val paths_arr = route.getJSONArray("paths")
        if (paths_arr != null && paths_arr.size() > 0) {
          for (i <- 0 until paths_arr.size()) {
            val outinfo = paths_arr.getJSONObject(i).getJSONObject("outinfo")
            if (outinfo != null) {
              val links_arr = outinfo.getJSONArray("links")
              if (links_arr != null && links_arr.size() > 0) {
                for (k <- 0 until links_arr.size()) {
                  val roadclass = if (strNotNull(links_arr.getJSONObject(k).getString("roadclass"))) links_arr.getJSONObject(k).getString("roadclass") else "-"
                  val dr_len = if (strNotNull(links_arr.getJSONObject(k).getString("dr_len"))) links_arr.getJSONObject(k).getString("dr_len") else "-"
                  val speed = if (strNotNull(links_arr.getJSONObject(k).getString("speed"))) links_arr.getJSONObject(k).getString("speed") else "-"
                  val dynSpeed = if (strNotNull(links_arr.getJSONObject(k).getString("dynSpeed"))) links_arr.getJSONObject(k).getString("dynSpeed") else "-"
                  sum_len += (try {
                    dr_len.toDouble
                  } catch {
                    case e: Exception => 0.0
                  })
                  if (roadclass == "0") {
                    highway_distance += (try {
                      dr_len.toDouble
                    } catch {
                      case e: Exception => 0.0
                    })
                  } else {
                    all_cnt += 1
                    if (dynSpeed_arr.contains(dynSpeed)) {
                      part_cnt += 1
                    }
                    byroad_distance += (try {
                      dr_len.toDouble
                    } catch {
                      case e: Exception => 0.0
                    })
                    dr_len_ab += dr_len
                    speed_ab += speed
                  }
                }
              }
            }
          }
          prop_cnt = if (all_cnt.toDouble > 0.0) part_cnt.toDouble / all_cnt.toDouble else 0.0
          var tm = 0.0
          if (prop_cnt >= 0.8) {
            for (i <- 0 until dr_len_ab.size) {
              tm += (try {
                dr_len_ab(i).toDouble / 1000 / speed_ab(i).toDouble
              } catch {
                case e: Exception => 0.0
              })
              logger.error(">>>>>>>>>" + tm)
            }
            byroad_speed = if (tm > 0) ((byroad_distance / 1000.0 / tm) * 0.9).formatted("%.2f") else "-"
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    ((byroad_distance / 1000).formatted("%.2f"), (highway_distance / 1000).formatted("%.2f"), byroad_speed, prop_cnt.formatted("%.2f"))
  }

  def getDisHighspeedStand = udf((dis_highspeed: String) => {
    val dis_db = try {
      dis_highspeed.toDouble.abs
    } catch {
      case e: Exception => 0.0
    }
    val dis_highspeed_block = dis_db match {
      case x if x >= 0 && x < 30 => "[0,30)"
      case x if x >= 30 && x < 60 => "[30,60)"
      case x if x >= 60 && x < 65 => "[60,65)"
      case x if x >= 65 && x < 70 => "[65,70)"
      case x if x >= 70 && x < 75 => "[70,75)"
      case x if x >= 75 && x < 80 => "[75,80)"
      case x if x >= 80 && x < 85 => "[80,85)"
      case x if x >= 85 && x < 90 => "[85,90)"
      case x if x >= 90 && x <= 100 => "[90,100]"
      case x if x > 100 => "(100,100+)"
    }
    dis_highspeed_block
  })

  def mergeStartAndEndUDF = udf((start: String, end: String) => {
    val merge_start_end_ab = new ListBuffer[String]
    if (strNotNull(start) && strNotNull(end)) {
      try {
        val start_arr = start.split("\\|", -1)
        val end_arr = end.split("\\|", -1)
        for (i <- 0 until start_arr.size) {
          merge_start_end_ab += start_arr(i) + "-" + end_arr(i)
        }
      } catch {
        case e: Exception => ""
      }
    }
    merge_start_end_ab.mkString("|")

  })

  /**
   * 不同间隔分位数求取python版本
   *
   * @return
   */
  def calMultiQuantilePythonUDF = udf((sort_field: String) => {
    var res_fd = ""
    if (strNotNull(sort_field)) {
      val sort_field_arr = sort_field.split("\\|").filter(strNotNull(_) == true).map(_.toDouble)
      //底层归并排序
      Sorting.stableSort(sort_field_arr)
      val quant = Array(0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95)
      res_fd = calQuantilePython(sort_field_arr, quant)
    }
    res_fd
  })

  /**
   * python中percentile函数求分位数的替代方法
   *
   * @param data  有序数组
   * @param quant 求取的 分位数
   * @return
   */
  def calQuantilePython(data: Array[Double], quant: Array[Double]): String = {
    quant.map(x => {
      var quant_value = 0.0
      val k_deci = (data.size - 1) * x
      val k_int = k_deci.toInt
      if (k_int + 1 < data.size) {
        quant_value = (k_deci - k_int) * data(k_int + 1) + (k_int + 1 - k_deci) * data(k_int)
      } else {
        quant_value = (k_deci - k_int) * data(data.size - 1) + (k_int + 1 - k_deci) * data(k_int)
      }
      quant_value.formatted("%.6f")
    }).mkString("&")
  }

  /**
   * 不同间隔分位数求取
   *
   * @return
   */
  def calMultiQuantileUDF = udf((sort_field: String) => {
    var res_fd = ""
    var hy_highway_95, hy_highway_90, hy_highway_85, hy_highway_80, hy_highway_75, hy_highway_70, hy_highway_65, hy_highway_60, hy_highway_55, hy_highway_50, hy_highway_45, hy_highway_40, hy_highway_35, hy_highway_30, hy_highway_25, hy_highway_20, hy_highway_15, hy_highway_10, hy_highway_5: Double = 0.0
    if (strNotNull(sort_field)) {
      val sort_field_arr = sort_field.split("\\|").filter(strNotNull(_) == true).map(_.toDouble)
      //底层归并排序
      Sorting.stableSort(sort_field_arr)
      val len = sort_field_arr.length
      // array(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.75,0.80,0.85,0.9,0.95)
      // cond1 计算下四分位数 中位数 上四分位数
      //
      hy_highway_95 = sort_field_arr((len * 0.05).toInt)
      hy_highway_90 = sort_field_arr((len * 0.1).toInt)
      hy_highway_85 = sort_field_arr((len * 0.15).toInt)
      hy_highway_80 = sort_field_arr((len * 0.2).toInt)
      hy_highway_75 = sort_field_arr((len * 0.25).toInt)
      hy_highway_70 = sort_field_arr((len * 0.3).toInt)
      hy_highway_65 = sort_field_arr((len * 0.35).toInt)
      hy_highway_60 = sort_field_arr((len * 0.4).toInt)
      hy_highway_55 = sort_field_arr((len * 0.45).toInt)
      hy_highway_50 = sort_field_arr((len * 0.5).toInt)
      hy_highway_45 = sort_field_arr((len * 0.55).toInt)
      hy_highway_40 = sort_field_arr((len * 0.6).toInt)
      hy_highway_35 = sort_field_arr((len * 0.65).toInt)
      hy_highway_30 = sort_field_arr((len * 0.7).toInt)
      hy_highway_25 = sort_field_arr((len * 0.75).toInt)
      hy_highway_20 = sort_field_arr((len * 0.8).toInt)
      hy_highway_15 = sort_field_arr((len * 0.85).toInt)
      hy_highway_10 = sort_field_arr((len * 0.9).toInt)
      hy_highway_5 = sort_field_arr((len * 0.95).toInt)
      res_fd = hy_highway_95.formatted("%.2f") + "&" + hy_highway_90.formatted("%.2f") + "&" + hy_highway_85.formatted("%.2f") + "&" + hy_highway_80.formatted("%.2f") + "&" + hy_highway_75.formatted("%.2f") + "&" + hy_highway_70.formatted("%.2f") + "&" + hy_highway_65.formatted("%.2f") + "&" + hy_highway_60.formatted("%.2f") + "&" + hy_highway_55.formatted("%.2f") + "&" + hy_highway_50.formatted("%.2f") + "&" + hy_highway_45.formatted("%.2f") + "&" + hy_highway_40.formatted("%.2f") + "&" + hy_highway_35.formatted("%.2f") + "&" + hy_highway_30.formatted("%.2f") + "&" + hy_highway_25.formatted("%.2f") + "&" + hy_highway_20.formatted("%.2f") + "&" + hy_highway_15.formatted("%.2f") + "&" + hy_highway_10.formatted("%.2f") + "&" + hy_highway_5.formatted("%.2f")
    }
    res_fd
  })

  /**
   * 针对时效专项项目中 “济源市和焦作市”的city_code均为391的问题导致的数据放大，引入dim.dim_dept_info_df 新表处理
   *
   * @param spark
   * @param inc_day
   * @return
   */

  def getCityMapDF(spark: SparkSession, inc_day: String): DataFrame = {
    //获取城市映射表
    val dm_adcode_df = spark.sql("""select city_name,city_code from dm_gis.dm_adcode_map_city_dtl group by city_name,city_code""") //获取城市映射表
    val dim_dept_df = spark.sql(s"""select belong_county city_name,dept_code city_code from dim.dim_dept_info_df where inc_day ='$inc_day' and dept_code like '%391%' and belong_county in ('济源市','焦作市')  group by dept_code,belong_county""")
    val city_map_df = dm_adcode_df.filter("city_code!='391'").union(dim_dept_df).persist()
    city_map_df
  }
}
