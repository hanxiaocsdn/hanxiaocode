package utils

import org.apache.spark.SparkConf
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions._
import utils.SparkBuilder.spark

/**
 * @author 01418539
 * @date 2021年12月21日 15:34
 */
object Similarity {
  //深房传麒山（6-12栋）-东区
  def main(args: Array[String]): Unit = {
    //    val v1: Vector[Char] = "深房传麒山（6-12栋）-东区".toVector
    //    val v2: Vector[Char] = "深房传麒山（6-12栋）-东区".toVector
    //    println(euclidean(v1, v2))


    val name = "bbb"
    val user = "bbb" //设定目标对象
    //迭代进行计算
//    println(name + " 相对于的相似性分数是：" + getCollaborateSource(name, user))

    //    println(euclidean2(v1, v2))
    a1
  }


  //  def euclidean2(v1: Vector[Double], v2: Vector[Double]): Double = {
  //    require(v1.size == v2.size, s"SimilarityAlgorithms:Vector dimensions do not match: Dim(v1)=${v1.size} and Dim(v2)" +
  //      s"=${v2.size}.")
  //
  //    val x = v1.toArray
  //    val y = v2.toArray
  //
  //    euclidean(x, y)
  //  }

  def euclidean(x: Vector[Char], y: Vector[Char]): Double = {
    require(x.length == y.length, s"SimilarityAlgorithms:Array length do not match: Len(x)=${x.length} and Len(y)" +
      s"=${y.length}.")

    val member = x.zip(y).map(d => d._1 * d._2).reduce(_ + _).toDouble

    val tmp1 = math.sqrt(x.map(num => {
      math.pow(num, 2)
    }).reduce(_ + _))


    val tmp2 = math.sqrt(y.map(num => {
      math.pow(num, 2)
    }).reduce(_ + _))

    val denomonitor = tmp1 * tmp2
    member / denomonitor
  }

  //  def euclidean(v1: Vector[Double], v2: Vector[Double]): Double = {
  //    val sqdist = Vectors.sqdist(v1, v2)
  //    math.sqrt(sqdist)
  //  }


  def getCollaborateSource(user1: String, user2: String): Double = {
    val user1FilmSource = "传麒山（6-12栋-东区".toVector //获得第1个用户的评分
    val user2FilmSource = "深房传麒山（6-12栋）--东区".toVector //获得第2个用户的评分
    val member = user1FilmSource.zip(user2FilmSource).map(d => d._1 * d._2).reduce(_ + _).toDouble //对公式分子部分进行计算
    println("member:" + member)
    val temp1 = math.sqrt(user1FilmSource.map(num => { //求出分母第1个变量值
      math.pow(num, 2) //数学计算
    }).reduce(_ + _))
    println("temp1:" + temp1)

    //进行叠加
    val temp2 = math.sqrt(user2FilmSource.map(num => { ////求出分母第2个变量值
      math.pow(num, 2) //数学计算
    }).reduce(_ + _)) //进行叠加
    println("temp2:" + temp2)
    val denominator = temp1 * temp2 //求出分母
    temp1 / temp2 //进行计算
  }

  def a1: Unit = {
    val conf = new SparkConf().setAppName("appName")
      .set("spark.master", "local[*]")
      .set("spark.testing.memory", "2147480000")
    val spark = SparkSession.builder.config(conf).getOrCreate
    import spark.implicits._
    val df = spark.createDataset(Seq(
      (1, "ab", "abc"),
      (2, "bc", "abc"),
      (3, "ab1", "ab2"),
      (4, "kitten", "sitting"),
      (5, "中国山东服务区", "山东中国服务区"),//0.4285714285714286
      (5, "反倒是规范合法规范合格", "中国规范两节课过分的话dhd"),//0.0714285714285714
      (5, "fsafadgasd", "fhsafaagaga"),//0.6363636363636364
      (6, "", "abc"),
      (7,"深房传麒山6-12","深房传麒山（6-12栋）--东区")
    )).toDF("id", "s1", "s2")
    df.show

//    df.withColumn(
//      "d",
//      lit(1) -
//        levenshtein(col("s1"), col("s2")) /
//          greatest(length(col("s1")), length(col("s2")))).show

    df.withColumn(
      "d",
      similarity(col("s1"), col("s2"))).show

  }


  def similarity(col1: Column, col2: Column): Column = {
    val res_col = round(lit(1) -
      levenshtein(col1, col2) / greatest(length(col1), length(col2)), 2)
    res_col

  }

}
