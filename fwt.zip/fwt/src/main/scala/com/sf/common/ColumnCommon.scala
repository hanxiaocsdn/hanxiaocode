package com.sf.common

import org.apache.spark.sql.Column
import org.apache.spark.sql.functions.{greatest, length, levenshtein, lit, trim, udf}
import com.google.common.base.{Charsets, Strings}
import com.google.common.hash.Hashing
import utils.DateUtil.logger

import scala.collection.mutable.ArrayBuffer

/**
 * @author 01418539
 * @date 2022年01月19日 12:29
 */
object ColumnCommon {


  def notNullDef(col: Column): Column = {
    col.isNotNull && trim(col) =!= ""
  }

  /**
   * column列计算2个字符串相似度
   * 传参：str1 str2
   */
  def similarity(col1: Column, col2: Column): Column = {
    val res_col = lit(1) - levenshtein(col1, col2) / greatest(length(col1), length(col2))
    res_col
  }

  def md5EncryptUDF = udf((col1: String, col2: String, col3: String, col4: String) => {
    val inputStr = col1 + col2 + col3 + col4
    Hashing.md5().newHasher().putString(inputStr, Charsets.UTF_8).hash().toString()
  })
}

