package com.sf.common

import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.functions._
import java.sql.{Connection, PreparedStatement}
import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * 统一数据源操作
 */
trait DataSourceCommon {

  lazy val logger: Logger = Logger.getLogger(this.getClass)

  /**
   * 查询指定数据库中的表信息
   *
   * @param conn   连接信息
   * @param dbName 数据库名称
   * @param tName  表名
   */
  def queryTable(conn: Connection, dbName: String, tName: String): Unit = {
    val arr = tName.replaceAll("'", "").split(",")
    //建表语句
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      try {
        val cs = s"show create table $tableName"
        val cs_create: PreparedStatement = conn.prepareStatement(cs)
        val cs_res = cs_create.executeQuery()
        while (cs_res.next()) {
          val Table = cs_res.getString("Table")
          val Create = cs_res.getString("Create Table")
          logger.error("表：" + Table + "的建表语句为：" + Create)
        }
      } catch {
        case ex: Exception =>
          val cs = s"show tables"
          val cs_create: PreparedStatement = conn.prepareStatement(cs)
          val cs_res = cs_create.executeQuery()
          while (cs_res.next()) {
            val tables = cs_res.getString(s"Tables_in_$dbName")
            logger.error(s"库：$dbName 中所有表为：" + tables)
          }
          logger.error(s"查看 $tableName 的建表语句时出现错误，请核对输入的表名在mysql中是否存在", ex)
          throw ex
      }
    }
    //cnt
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      try {
        val cnts = s"select count(1) as cnt from $tableName limit 100"
        val cnts_count: PreparedStatement = conn.prepareStatement(cnts)
        val cnts_res = cnts_count.executeQuery()
        while (cnts_res.next()) {
          val cnt = cnts_res.getString("cnt")
          logger.error("表：" + tableName + " 的数据总量为>" + cnt)
        }
      } catch {
        case ex: Exception => logger.error(s"查询表 $tableName 中 数据总量时出现错误", ex)
          throw ex
      }
    }
  }

  /**
   * df版本 加随机值打散join（用于关联的主键key字段提前去空‘’、null处理）
   *
   * @param spark
   * @param left
   * @param right
   * @param key     关联主键，如果多个字段，需先拼接为1个字段
   * @param hashNum 扩容倍数
   * @param topLean 需扩容的数据量
   * @return
   */
  def leftOuterJoinOfLeftLeanElemDF(spark: SparkSession, left: DataFrame, right: DataFrame, key: String, hashNum: Int = 3, topLean: Int = 10): DataFrame = {
    val keyCounts = left.groupBy(key).count().orderBy(desc("count")).limit(topLean)

    val keys = keyCounts.select(key).rdd.map(row => row.getString(0)).collect()
    val counts = keyCounts.select("count").rdd.map(row => row.getLong(0)).reduce(_ + _)

    // 打印单独处理的 keys 和总数量
    println(s"需要单独处理的key总量信息")
    keyCounts.show(false)
    println(s"单独处理的总数量: $counts")

    // 使用 DataFrame 的过滤操作
    val leftHashKeyData = left.filter(col(key).isin(keys: _*))
    val leftOtherData = left.filter(!col(key).isin(keys: _*))
    val rightHashKeyData = right.filter(col(key).isin(keys: _*))
    val rightOtherData = right.filter(!col(key).isin(keys: _*))

    // 进行其他关联操作
    val otherJoin = leftOtherData.join(rightOtherData, Seq(key), "left_outer")
    //新key信息
    val new_key = "new_" + key

    // 扩展单独处理的数据
    val leftHashKeyDataExpand = leftHashKeyData
      .withColumn(new_key, randomPreAdd(col(key), lit(hashNum)))

    val rightHashKeyDataExpand = rightHashKeyData
      .crossJoin(spark.range(0, hashNum).withColumnRenamed("id", "random_expand")) //扩展数据1条->多条,添加随机数
      .withColumn(new_key, concat_ws("_", col("random_expand"), col(key)))
      .drop("random_expand", key)

    // 进行关联操作
    val hashKeyJoin = leftHashKeyDataExpand.join(rightHashKeyDataExpand, Seq(new_key), "left_outer").drop(new_key)

    // 合并结果
    hashKeyJoin.union(otherJoin)
  }

  def randomPreAdd = udf((col: String, hashNum: Int) => {
    Random.nextInt(hashNum) + "_" + col
  })

  /**
   * 左关联，左表存在少部分key倾斜，采用单独处理部分key的方式
   *
   * @param left    左表
   * @param right   右表
   * @param hashNum 散列系数，扩容倍数
   * @param topLean 需要单独处理的倾斜数据量
   */
  def leftOuterJoinOfLeftLeanElem(left: RDD[(String, Row)], right: RDD[(String, Row)], hashNum: Int, topLean: Int = 10): RDD[(String, (Row, Row))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys: Array[String] = keyCounts.map(obj => obj._1)

    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    //    val otherJoin: RDD[(String, (Row, Option[Row]))] = leftOtherData.leftOuterJoin(rightOtherData)//leftOuterJoin
    val otherJoin: RDD[(String, (Row, Row))] = leftOtherData.join(rightOtherData) //leftOuterJoin
    //扩展单独处理的数据
    val leftHashKeyDataExpand: RDD[((Int, String), Row)] = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      ((hashPrefix, obj._1), obj._2)
    })

    //    val rightHashKeyDataExpand: RDD[((Int, String), Row)] = rightHashKeyData.flatMap(obj => {
    val rightHashKeyDataExpand: RDD[((Int, String), Row)] = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((Int, String), Row)]()
      for (i <- 0 until hashNum) {
        dataArray.append(((i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin: RDD[(String, (Row, Row))] = leftHashKeyDataExpand.join(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))

    hashKeyJoin.union(otherJoin)
  }

  /**
   * 左关联，左表存在少部分key倾斜，采用单独处理部分key的方式
   *
   * @param left    左表
   * @param right   右表
   * @param hashNum 散列系数，扩容倍数
   * @param topLean 需要单独处理的倾斜数据量
   */

  def leftOuterJoinKey(left: RDD[(String, Row)], right: RDD[(String, Row)], hashNum: Int, topLean: Int = 10): RDD[(String, (Row, Option[Row]))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys: Array[String] = keyCounts.map(obj => obj._1)

    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    //    val otherJoin: RDD[(String, (Row, Option[Row]))] = leftOtherData.leftOuterJoin(rightOtherData)//leftOuterJoin
    val otherJoin: RDD[(String, (Row, Option[Row]))] = leftOtherData.leftOuterJoin(rightOtherData) //leftOuterJoin
    //扩展单独处理的数据
    val leftHashKeyDataExpand: RDD[((Int, String), Row)] = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      ((hashPrefix, obj._1), obj._2)
    })

    val rightHashKeyDataExpand: RDD[((Int, String), Row)] = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((Int, String), Row)]()
      for (i <- 0 until hashNum) {
        dataArray.append(((i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin: RDD[(String, (Row, Option[Row]))] = leftHashKeyDataExpand.leftOuterJoin(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))

    hashKeyJoin.union(otherJoin)
  }

  /**
   * 读取parquet 文件
   *
   * @param spark
   * @param filePath 文件路径
   * @param inc_day  文件日期
   * @return
   */
  def getDSByParquet(spark: SparkSession, filePath: String, partitionBy: String): Dataset[_] = {
    val ds = spark.read
      .format("parquet")
      .option("inferSchema", "true")
      .load(filePath)
      .filter(col("inc_day") === partitionBy)
    ds
  }

  /**
   * 将数据保存为csv格式在hdfs上
   *
   * @param spark
   * @param ds
   * @param saveMode
   * @param partitionCol
   * @param options
   * @param file_path
   * @param tableName hive表名称
   * @flag 是否需要映射到对应的hive表中
   */
  def writeToCsv(spark: SparkSession, ds: Dataset[_], saveMode: SaveMode, partitionCol: String, options: Map[String, String] = Map.empty[String, String], file_path: String, flag: Boolean, tableName: String = ""): Unit = {
    //1 将文件写入csv
    ds.write.options(options).mode(saveMode).format("csv").save(file_path)
    logger.info(s"写入csv文件:path:$file_path 成功")
    //2 将csv文件load到hive表中--外部表
    if (flag) {
      val sql_file = s"load data inpath '$file_path' overwrite into table $tableName partition(inc_day='$partitionCol')"
      spark.sqlContext.sql(sql_file)
      logger.info(s"映射hive表成功")
    }
  }

  /**
   * 将数据写入hive表中【OVERWRITE】
   *
   * @param spark
   * @param dataframe
   * @param partitionCol
   * @param resTableName
   */
  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  /**
   * 将数据写入hive表中  追加【APPEND】
   *
   * @param spark
   * @param dataframe
   * @param partitionCol
   * @param resTableName
   */
  def appendToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert into %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  /**
   * 将数据写入hive表,指定库dm_gis中【不分区】
   *
   * @param spark
   * @param dataframe
   * @param partitionCol
   * @param resTableName
   */
  def writeToHiveNoP(spark: SparkSession, dataframe: DataFrame, resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert into %s select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql("use dm_gis")
    spark.sql(s"truncate table dm_gis.$resTableName")
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  /**
   * 读取mysql表中的数据写入hive表中
   *
   * @param spark
   * @param mysqlTable
   * @param hiveTable
   */
  def loadMysqlToHive(spark: SparkSession, mysqlTable: String, hiveTable: String, flag: String, inc_day: String): Unit = {
    //    val conf = ConfigFactory.load("conf/smartMysql.properties")
    val hive_table_struct: String = spark.sql(s"select * from dm_gis_oms.$hiveTable limit 1").schema.toList.map(_.name).mkString(",")
    var query_state = ""

    if ("scomm_flow_device_status".equals(mysqlTable) && "i".equals(flag)) {
      query_state = s"(select id,device_no,statistic_date,d_status,custom_status,total_status," +
        s"del_flag,create_time,update_time,replace(substring(statistic_date,1,10),'-','') as inc_day from $mysqlTable where replace(substring(statistic_date,1,10),'-','') ='$inc_day') as t"
    } else if ("scomm_flow_device_status".equals(mysqlTable) && "f".equals(flag)) {
      query_state = s"(select id,device_no,statistic_date,d_status,custom_status,total_status," +
        s"del_flag,create_time,update_time,replace(substring(statistic_date,1,10),'-','') as inc_day from $mysqlTable) as t"
    } else {
      query_state = s"(select $hive_table_struct from $mysqlTable) as t"
    }

    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://etraffic-m.db.sfcloud.local:3306/smart_community?useUnicode=true&characterEncoding=utf-8",
      "user" -> "statUser",
      "password" -> "statUser@ft123",
      "dbtable" -> query_state
    )

    try {
      val df = spark.read.format("jdbc").options(params).load()
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        df.createOrReplaceTempView("tmpTableName") //临时表
        spark.sql("use dm_gis_oms")
        if ("scomm_flow_device_status".equals(mysqlTable)) {
          spark.sql(s"insert overwrite table $hiveTable partition(inc_day) select * from tmpTableName")
        } else {
          spark.sql(s"truncate table dm_gis_oms.$hiveTable")
          spark.sql(s"insert into $hiveTable select * from tmpTableName")
        }

      } else {
        throw new Exception(s"mysql的 $hiveTable 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $hiveTable 中 插入数据时出现错误", ex)
        throw ex
    }
  }
}
