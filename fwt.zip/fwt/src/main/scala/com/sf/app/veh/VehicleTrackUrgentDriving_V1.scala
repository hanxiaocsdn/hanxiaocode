//package com.sf.app.veh
//
//import com.mobo.drivingbehavior.{BehaviorDetectorV1, GpsPos, IBehaviorDetector, Logger}
//import com.sf.common.DataSourceCommon
//import org.apache.spark.sql.expressions.Window
//import org.apache.spark.sql.functions._
//import org.apache.spark.sql.{DataFrame, SparkSession}
//import org.apache.spark.storage.StorageLevel
//import utils.DateUtil._
//import utils.SparkBuilder
//
//import java.util
//import java.util.{Collections, Comparator}
//
///**
// * @description: 三急识别数据  三类轨迹数据union  提前过滤后 一天 约12min 442186
// * @author 01418539 caojia
// * @date 2022/5/26 11:21
// */
//case class EmergencyDriving(x1: String, x2: String, x3: String, x4: String, x5: String, x6: String, x7: String, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String, x17: String, x18: String, x19: String, x20: String, x21: String, x22: String, x23: String, x24: String, x25: String)
//
//object VehicleTrackUrgentDriving_V1 extends DataSourceCommon {
//  def main(args: Array[String]): Unit = {
//    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Start Calculation>>>>>")
//    val start_day = args(0)
//    val end_day = args(1)
//    processTrack(spark, start_day, end_day)
//    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
//  }
//
//  def processTrack(spark: SparkSession, start_day: String, end_day: String): Unit = {
//    import spark.implicits._
//    val o_flame_out = spark.sql(
//      s"""
//         |select vehicle_serial,task_id,app_recive_task_tm,actual_reach_tm,actual_depart_tm,actual_arrive_tm,first_unload_op_tm,begindatetime,enddatetime,
//         |       driver_id,main_driver_account,driver_name,deputy_driver_account,deputy_driver_name,vehicletask_status,serial,motorcade_code,motorcade_name,dept_code,area_code,area_name,fuel_type,inc_day
//         |from dm_gis.dwd_vehicle_fuel_consum_flame_out_dtl
//         |where inc_day >= '$start_day' and inc_day <='$end_day'
//         |      and vehicle_serial is not null and trim(vehicle_serial) != ''
//         |      and app_recive_task_tm is not null and trim(app_recive_task_tm) != ''
//         |      and actual_arrive_tm is not null and trim(actual_arrive_tm) != ''
//         |group by vehicle_serial,task_id,app_recive_task_tm,actual_reach_tm,actual_depart_tm,actual_arrive_tm,first_unload_op_tm,begindatetime,enddatetime,
//         |      driver_id,main_driver_account,driver_name,deputy_driver_account,deputy_driver_name,vehicletask_status,serial,motorcade_code,motorcade_name,dept_code,area_code,area_name,fuel_type,inc_day
//         |""".stripMargin)
//      .withColumn("depart_tm", timeToTimestamp1('begindatetime))
//      .withColumn("arrive_tm", timeToTimestamp1('enddatetime))
//      .persist(StorageLevel.MEMORY_AND_DISK_SER)
//
//    //获取车牌 和 设备映射关系表
//    val o_vehicle = o_flame_out.select("vehicle_serial").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''",",'")
//
//    val o_card_device = verhicleMapUn(spark, o_vehicle)
//
//    val o_device_id = o_card_device.select("device_id").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''",",'")
//
//    //t2 day: 7913万6914 45G tEXT 全国车行路径规划GPS轨迹原始数据表 特征抽取纠偏数据源
//    val o_navi_track = spark.sql(
//      s"""
//         |select carno un,tm,x zx,y zy,sp,be,'2' flag,inc_day
//         |from dm_gis.gis_rss_eta_navi_track_flatmap
//         |where inc_day >= '$start_day' and inc_day <='$end_day'
//         |      and carno in ($o_vehicle)
//         |      and ak = '305'
//         |      and tm is not null and trim(tm) != ''
//         |      and x is not null and trim(x) != ''
//         |      and y is not null and trim(y) != ''
//         |      and sp is not null and trim(sp) != ''
//         |      and cast(sp as double) <= 110
//         |      and be is not null and trim(be) != ''
//         |""".stripMargin)
//      .withColumn("num", row_number().over(Window.partitionBy("un", "tm", "inc_day").orderBy("un")))
//      .filter('num === 1).drop("num", "inc_day")
//
//    //t3  10亿5453万4499 40G TEXT 全国硬件采集设备+外部第三方轨迹源
//    val device_track = spark.sql(
//      s"""
//         |select un device_id,tm,zx,zy,sp,be,'1' flag,inc_day
//         |from dm_gis.gis_vms_track_device_track_flatmap
//         |where inc_day >= '$start_day' and inc_day <='$end_day'
//         |      and un in ($o_device_id)
//         |      and tm is not null and trim(tm) != ''
//         |      and zx is not null and trim(zx) != ''
//         |      and zy is not null and trim(zy) != ''
//         |      and sp is not null and trim(sp) != ''
//         |      and cast(sp as double) <= 110
//         |      and be is not null and trim(be) != ''
//         |""".stripMargin)
//      .withColumn("num", row_number().over(Window.partitionBy("device_id", "tm", "inc_day").orderBy("device_id")))
//      .filter('num === 1).drop("num", "inc_day")
//
//    val o_device_track = device_track.join(broadcast(o_card_device), Seq("device_id"))
//      .withColumnRenamed("vehicle_serial", "un")
//      .select("un", "tm", "zx", "zy", "sp", "be", "flag")
//
//    //t4 10亿5883万8578 136g parquet全国车行骑行GPS轨迹数据表 with wifi mac
//    val o_gps_track = spark.sql(
//      s"""
//         |select un,tm,zx,zy,sp,be,'3' flag,inc_day
//         |from dm_gis.esg_gis_loc_trajectory_ewl
//         |where inc_day >= '$start_day' and inc_day <='$end_day'
//         |      and un in ($o_vehicle)
//         |      and tm is not null and trim(tm) != ''
//         |      and zx is not null and trim(zx) != ''
//         |      and zy is not null and trim(zy) != ''
//         |      and sp is not null and trim(sp) != ''
//         |      and cast(sp as double) <= 110
//         |      and be is not null and trim(be) != ''
//         |""".stripMargin)
//      .withColumn("num", row_number().over(Window.partitionBy("un", "tm", "inc_day").orderBy("un")))
//      .filter('num === 1).drop("num", "inc_day")
//
//    val step1_track = o_navi_track.union(o_device_track).union(o_gps_track)
//      .persist(StorageLevel.MEMORY_AND_DISK_SER)
//    val step2_track = step1_track.select("un", "flag")
//      .groupBy("un").agg(min('flag) as "flag")
//
//    val total_tracks = step1_track.join(step2_track, Seq("un", "flag"))
//
//    //过滤数据 范围关联
//    val order_col = split(col("track_info"), ",")(0).cast("long").asc
//    val join_cond = expr("vehicle_serial = un and tm >= depart_tm and tm <= arrive_tm")
//    val multi_tracks = total_tracks.join(broadcast(o_flame_out), join_cond)
//      .withColumn("tm", trim('tm))
//      .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "tm").orderBy("vehicle_serial")))
//      .filter('num === 1)
//      .withColumn("track_info", concat_ws("&", 'tm, 'zx, 'zy, 'sp, 'be, 'flag))
//      .repartition(1200)
//      .groupBy(randomPrefix('vehicle_serial) as "vehicle_serial", 'begindatetime, 'enddatetime, 'inc_day)
//      .agg(
//        first("task_id") as "task_id",
//        first("app_recive_task_tm") as "app_recive_task_tm",
//        first("actual_reach_tm") as "actual_reach_tm",
//        first("actual_depart_tm") as "actual_depart_tm",
//        first("actual_arrive_tm") as "actual_arrive_tm",
//        first("first_unload_op_tm") as "first_unload_op_tm",
//        first("driver_id") as "driver_id",
//        first("main_driver_account") as "main_driver_account",
//        first("driver_name") as "driver_name",
//        first("deputy_driver_account") as "deputy_driver_account",
//        first("deputy_driver_name") as "deputy_driver_name",
//        first("vehicletask_status") as "vehicletask_status",
//        first("serial") as "serial",
//        first("motorcade_code") as "motorcade_code",
//        first("motorcade_name") as "motorcade_name",
//        first("dept_code") as "dept_code",
//        first("area_code") as "area_code",
//        first("area_name") as "area_name",
//        first("fuel_type") as "fuel_type",
//        first("flag") as "flag",
//        concat_ws(",", collect_set("track_info")) as "track_info"
//      )
//      .groupBy(removePrefix('vehicle_serial) as "vehicle_serial", 'begindatetime, 'enddatetime, 'actual_arrive_tm, 'inc_day)
//      .agg(
//        first("task_id") as "task_id",
//        first("app_recive_task_tm") as "app_recive_task_tm",
//        first("actual_reach_tm") as "actual_reach_tm",
//        first("actual_depart_tm") as "actual_depart_tm",
//        first("actual_arrive_tm") as "actual_arrive_tm",
//        first("first_unload_op_tm") as "first_unload_op_tm",
//        first("driver_id") as "driver_id",
//        first("main_driver_account") as "main_driver_account",
//        first("driver_name") as "driver_name",
//        first("deputy_driver_account") as "deputy_driver_account",
//        first("deputy_driver_name") as "deputy_driver_name",
//        first("vehicletask_status") as "vehicletask_status",
//        first("serial") as "serial",
//        first("motorcade_code") as "motorcade_code",
//        first("motorcade_name") as "motorcade_name",
//        first("dept_code") as "dept_code",
//        first("area_code") as "area_code",
//        first("area_name") as "area_name",
//        first("fuel_type") as "fuel_type",
//        first("flag") as "flag",
//        concat_ws(",", collect_set("track_info")) as "track_info"
//      ).repartition(1200, col("vehicle_serial")).sort(col("vehicle_serial"),order_col)
//      .map(row => {
//        val vehicle_serial = row.getAs[String]("vehicle_serial")
//        val task_id = row.getAs[String]("task_id")
//        val app_recive_task_tm = row.getAs[String]("app_recive_task_tm")
//        val actual_reach_tm = row.getAs[String]("actual_reach_tm")
//        val actual_depart_tm = row.getAs[String]("actual_depart_tm")
//        val actual_arrive_tm = row.getAs[String]("actual_arrive_tm")
//        val first_unload_op_tm = row.getAs[String]("first_unload_op_tm")
//        val begindatetime = row.getAs[String]("begindatetime")
//        val enddatetime = row.getAs[String]("enddatetime")
//        val driver_id = row.getAs[String]("driver_id")
//        val main_driver_account = row.getAs[String]("main_driver_account")
//        val driver_name = row.getAs[String]("driver_name")
//        val deputy_driver_account = row.getAs[String]("deputy_driver_account")
//        val deputy_driver_name = row.getAs[String]("deputy_driver_name")
//        val vehicletask_status = row.getAs[String]("vehicletask_status")
//        val flag = row.getAs[String]("flag")
//        val vehicle_tracks = row.getAs[String]("track_info")
//        val serial = row.getAs[String]("serial")
//        val motorcade_code = row.getAs[String]("motorcade_code")
//        val motorcade_name = row.getAs[String]("motorcade_name")
//        val dept_code = row.getAs[String]("dept_code")
//        val area_code = row.getAs[String]("area_code")
//        val area_name = row.getAs[String]("area_name")
//        val fuel_type = row.getAs[String]("fuel_type")
//        val inc_day = row.getAs[String]("inc_day")
//
//        val multi_vehicle_tracks: Array[String] = vehicle_tracks.split(",")
//
//        //初始化并开启监听器
//        val behaviorDetector = new BehaviorDetectorV1
//        Logger.init()
//        behaviorDetector.setAccLevel(BehaviorDetectorV1.LEVEL_MID)
//        behaviorDetector.setDecLevel(BehaviorDetectorV1.LEVEL_MID)
//        behaviorDetector.setAngleLevel(BehaviorDetectorV1.LEVEL_MID)
//        behaviorDetector.setIgnoreTime(IBehaviorDetector.DRV_EVENT_RAPID_TURN, 30) //即报完三急事件后30s内不再进行三急事件识别
//        behaviorDetector.setIgnoreTime(IBehaviorDetector.DRV_EVENT_RAPID_ACCELERATION, 30) //即报完三急事件后30s内不再进行三急事件识别
//        behaviorDetector.setIgnoreTime(IBehaviorDetector.DRV_EVENT_RAPID_DECELERATION, 30) //即报完三急事件后30s内不再进行三急事件识别
//        //接受返回结果值
//        var info = ""
//        behaviorDetector.setBehaviorListener(new IBehaviorDetector.BehaviorListener() {
//          override def onDrvEvent(drvEvent: Int, pos: GpsPos, acc: Float): Unit = {
//            if (drvEvent == IBehaviorDetector.DRV_EVENT_RAPID_TURN) {
//              info = "3" //3 急转弯
//            }
//            else if (drvEvent == IBehaviorDetector.DRV_EVENT_RAPID_ACCELERATION) {
//              info = "1" //1 急加速
//            }
//            else if (drvEvent == IBehaviorDetector.DRV_EVENT_RAPID_DECELERATION) {
//              info = "2" //2 急减速
//            }
//            else {
//              info = "0" //0 无事件
//            }
//          }
//        })
//
//        val gpsPosList: util.List[GpsPos] = new util.ArrayList[GpsPos]
//
//        for (i <- 0 until multi_vehicle_tracks.length) {
//          val time = multi_vehicle_tracks(i).split("&")(0)
//          val zx = multi_vehicle_tracks(i).split("&")(1)
//          val zy = multi_vehicle_tracks(i).split("&")(2)
//          val sp = multi_vehicle_tracks(i).split("&")(3)
//          val be = multi_vehicle_tracks(i).split("&")(4)
//
//          val pos = new GpsPos
//          pos.time = time.toLong
//          pos.lng = zx.toFloat
//          pos.lat = zy.toFloat
//          pos.speed = sp.toFloat
//          pos.angle = be.toFloat
//          gpsPosList.add(pos)
//        }
//
//        Collections.sort(gpsPosList, new Comparator[GpsPos]() {
//          def compare(o1: GpsPos, o2: GpsPos): Int = (o1.time - o2.time).asInstanceOf[Int]
//        })
//
//        val ugent_info = new Array[String](gpsPosList.size())
//        for (i <- 0 until gpsPosList.size()) {
//          behaviorDetector.detectPos(gpsPosList.get(i))
//          ugent_info(i) = info
//        }
//        val res_tracks = (multi_vehicle_tracks zip ugent_info).map(x => x._1 + "&" + x._2).mkString(",")
//        EmergencyDriving(vehicle_serial, task_id, app_recive_task_tm, actual_reach_tm, actual_depart_tm, actual_arrive_tm, first_unload_op_tm, begindatetime, enddatetime, driver_id, main_driver_account,
//          driver_name, deputy_driver_account, deputy_driver_name, vehicletask_status, res_tracks, flag, serial, motorcade_code, motorcade_name, dept_code, area_code, area_name, fuel_type, inc_day)
//      }).toDF("vehicle_serial", "task_id", "app_recive_task_tm", "actual_reach_tm", "actual_depart_tm", "actual_arrive_tm", "first_unload_op_tm", "begindatetime", "enddatetime", "driver_id", "main_driver_account", "driver_name",
//      "deputy_driver_account", "deputy_driver_name", "vehicletask_status", "res_tracks", "flag", "serial", "motorcade_code", "motorcade_name", "dept_code", "area_code", "area_name", "fuel_type", "inc_day")
//      .withColumn("all_tracks", explode(split('res_tracks, ",")))
//      .withColumn("risk_d_tm", split('all_tracks, "&")(0))
//      .withColumn("risk_d_x", split('all_tracks, "&")(1))
//      .withColumn("risk_d_y", split('all_tracks, "&")(2))
//      .withColumn("risk_d_sp", split('all_tracks, "&")(3))
//      .withColumn("risk_d_event", split('all_tracks, "&")(6))
//      .withColumn("risk_d_tm", tranTstampToTimeUDF(sdf1)('risk_d_tm))
//      .na.fill("")
//      .select("vehicle_serial", "task_id", "app_recive_task_tm", "actual_reach_tm", "actual_depart_tm", "actual_arrive_tm", "first_unload_op_tm", "begindatetime", "enddatetime", "driver_id", "main_driver_account", "driver_name",
//        "deputy_driver_account", "deputy_driver_name", "vehicletask_status", "risk_d_tm", "risk_d_x", "risk_d_y", "risk_d_sp", "risk_d_event", "flag", "serial", "motorcade_code", "motorcade_name", "dept_code", "area_code", "area_name", "fuel_type", "inc_day")
//    writeToHive(spark, multi_tracks, Seq("inc_day"), "dm_gis.dwd_vehicle_fuel_consump_urgent_event_dtl")
//    o_flame_out.unpersist()
//    step1_track.unpersist()
//    o_card_device.unpersist()
//  }
//
//  def verhicleMapUn(spark: SparkSession, o_vehicle: String): DataFrame = {
//    import spark.implicits._
//    spark.sql(
//      s"""
//         |select car_id vehicle_serial,
//         |       device_id,
//         |       bind_time
//         |from dm_gis.tt_device_relation
//         |where car_id in ($o_vehicle)
//         |      and device_id is not null and trim(device_id) != ''
//         |""".stripMargin)
//      .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial").orderBy(desc("bind_time"))))
//      .filter('num === 1)
//      .select("vehicle_serial", "device_id")
//      .persist(StorageLevel.MEMORY_AND_DISK_SER)
//  }
//
//}
