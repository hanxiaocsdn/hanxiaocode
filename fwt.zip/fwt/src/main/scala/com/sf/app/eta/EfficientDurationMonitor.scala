package com.sf.app.eta

import com.sf.app.eta.EfficientLowerSpeedMerge.{splitFun, strNotNull}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil._
import utils.SparkBuilder

import java.util.Collections
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @task_id: 495114
 * @description: 时效时长监控 eta_time_change_daily
 * @demander: 01408890 邵一馨
 * @author 01418539 caojia
 * @date 2022/10/9 9:50
 */
object EfficientDurationMonitor extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val (o_task_df, o_eta_change_df) = getOriginData(spark, inc_day)
    processMonitor(spark, o_task_df, o_eta_change_df, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processMonitor(spark: SparkSession, o_task_df: DataFrame, o_eta_change_df: DataFrame, inc_day: String): Unit = {
    import spark.implicits._
    //是否有配置
    val is_config = when('expiration_date.isNull || trim('expiration_date) === "", "否") //expiration_date 2022-04-29 task_inc_day  20220429
      .when(regexp_replace('expiration_date, "-", "") >= 'task_inc_day, "是").otherwise("失效")
    //区域代码映射关系数据
    val area_map_df = spark.sql("""select * from dm_gis.dim_area_code_name_mapping""")
    //step1 关联带出is_config字段
    val p1_task_df = o_task_df.join(broadcast(o_eta_change_df.select("group1", "expiration_date", "order").filter('order === 1)), Seq("group1"), "left")
      .join(broadcast(area_map_df), Seq("task_area_code"), "left")
      .withColumn("is_config", is_config)
      .withColumn("num", row_number().over(Window.partitionBy('group, 'group1, 'line_code, 'start_dept, 'end_dept).orderBy(regexp_replace('task_inc_day, "([^0-9]+)", ""))))
      .repartition(600, 'group, 'group1, 'line_code, 'start_dept, 'end_dept)
      .sort('group, 'group1, 'line_code, 'start_dept, 'end_dept, regexp_replace('task_inc_day, "([^0-9]+)", "").cast("int"))
      .groupBy("group", "group1", "line_code", "start_dept", "end_dept")
      .agg(
        concat_ws("|", collect_list("num")) as "num",
        concat_ws("|", collect_set("transoport_level")) as "transoport_level",
        concat_ws("|", collect_set("task_area_code")) as "task_area_code",
        concat_ws("|", collect_set("task_area_name")) as "task_area_name",
        concat_ws("|", collect_list("task_inc_day")) as "task_inc_day",
        concat_ws("|", collect_list("line_time")) as "line_time",
        concat_ws("|", collect_list("is_config")) as "is_config",
        concat_ws("|", collect_list("ac_is_run_ontime")) as "ac_is_run_ontime",
        concat_ws("|", collect_list("actual_depart_tm")) as "actual_depart_tm", //2022-04-29 19:00:29
        concat_ws("|", collect_list("task_subid")) as "task_subid",
        concat_ws("|", collect_list("actual_run_time")) as "actual_run_time"
      )
      .withColumn("task_inc_day", sortField('num, 'task_inc_day))
      .withColumn("line_time", sortField('num, 'line_time))
      .withColumn("is_config", sortField('num, 'is_config))
      .withColumn("ac_is_run_ontime", sortField('num, 'ac_is_run_ontime))
      .withColumn("actual_depart_tm", sortField('num, 'actual_depart_tm))
      .withColumn("task_subid", sortField('num, 'task_subid))
      .withColumn("actual_run_time", sortField('num, 'actual_run_time))
      .drop("num")
      .repartition(600, 'group1)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val p1_eta_change_df = o_eta_change_df
      .repartition(600, 'group1)
      .withColumn("num", row_number().over(Window.partitionBy('group1).orderBy('modified_tm)))
      .sort("group1", "modified_tm")
      .groupBy("group1")
      .agg(
        concat_ws("|", collect_list("num")) as "num",
        concat_ws("|", collect_list("revise_run_tm")) as "revise_run_tm", //时长 min
        concat_ws("|", collect_list("work_days")) as "work_days",
        concat_ws("|", collect_list("remark")) as "remark",
        concat_ws("|", collect_list("modifier")) as "modifier",
        concat_ws("|", collect_list("modified_tm")) as "modified_tm", //2022-04-29 19:00:29
        concat_ws("|", collect_list("effective_range")) as "effective_range" //2022-04-29 19:00:29_2022-04-29 19:00:29
      )
      .withColumn("revise_run_tm", sortField('num, 'revise_run_tm))
      .withColumn("work_days", sortField('num, 'work_days))
      .withColumn("remark", sortField('num, 'remark))
      .withColumn("modifier", sortField('num, 'modifier))
      .withColumn("modified_tm", sortField('num, 'modified_tm))
      .withColumn("effective_range", sortField('num, 'effective_range))
      .drop("num")
      .repartition(600, 'group1)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val config_status = when(!'is_config.contains("否") && !'is_config.contains("失效") && 'is_config.contains("是"), "全有配置")
      .when(!'is_config.contains("是") && !'is_config.contains("失效") && 'is_config.contains("否"), "无配置")
      .when(!'is_config.contains("是") && !'is_config.contains("否") && 'is_config.contains("无效"), "配置均失效")
      .when('is_config.contains("是") && 'is_config.contains("失效"), "两种状态")
      .otherwise("其他")
    //打标不同时间段的任务数
    val multi_infos = splitFun("&&")('p1_multi_infos)
    val date_infos = splitFun("&&")('p2_multi_infos)
    val mark_infos = splitFun("&&")('p3_multi_infos)
    val d3_infos = splitFun("&&")('d3_infos)
    val d7_infos = splitFun("&&")('d7_infos)
    val d14_infos = splitFun("&&")('d14_infos)

    val step1_merge_df = p1_task_df.join(p1_eta_change_df, Seq("group1"), "left").repartition(600)
      .withColumn("today3", lit(getdaysBeforeOrAfter(inc_day, -3)))
      .withColumn("today7", lit(getdaysBeforeOrAfter(inc_day, -7)))
      .withColumn("today14", lit(getdaysBeforeOrAfter(inc_day, -14)))
      .withColumn("today21", lit(getdaysBeforeOrAfter(inc_day, -21)))
      .withColumn("today30", lit(getdaysBeforeOrAfter(inc_day, -30)))
      .withColumn("config_status", config_status)
      .withColumn("p1_multi_infos", splitLineCodeUDF('line_time, 'task_inc_day, 'ac_is_run_ontime, 'today7, 'today14, 'today21, 'today30))
      .withColumn("task7", multi_infos(0))
      .withColumn("ontime_task7", multi_infos(1))
      .withColumn("notontime_task7", multi_infos(2))
      .withColumn("task14", multi_infos(3))
      .withColumn("ontime_task14", multi_infos(4))
      .withColumn("notontime_task14", multi_infos(5))
      .withColumn("task21", multi_infos(6))
      .withColumn("ontime_task21", multi_infos(7))
      .withColumn("notontime_task21", multi_infos(8))
      .withColumn("task30", multi_infos(9))
      .withColumn("ontime_task30", multi_infos(10))
      .withColumn("notontime_task30", multi_infos(11))
      .withColumn("line_time_change", multi_infos(12))
      .withColumn("change_date", multi_infos(13))
      .withColumn("change_date2", multi_infos(14))
      .withColumn("ontime_ratio7", when('task7 =!= 0, 'ontime_task7 / 'task7).otherwise("-"))
      .withColumn("ontime_ratio14", when('task14 =!= 0, 'ontime_task14 / 'task14).otherwise("-"))
      .withColumn("ontime_ratio21", when('task21 =!= 0, 'ontime_task21 / 'task21).otherwise("-"))
      .withColumn("ontime_ratio30", when('task30 =!= 0, 'ontime_task30 / 'task30).otherwise("-"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val step2_merge_df = step1_merge_df.repartition(600)
      .withColumn("p2_multi_infos", getDate2CntUDF('change_date2, 'line_time_change, 'today7, 'today14, 'today21, 'today30))
      .withColumn("change_cnt7", date_infos(0))
      .withColumn("change_cnt14", date_infos(1))
      .withColumn("change_cnt21", date_infos(2))
      .withColumn("change_cnt30", date_infos(3))
      .withColumn("change_date_diff", date_infos(4))
      .withColumn("last_change_date", date_infos(5))
      .withColumn("last_change_time", date_infos(6))
      .withColumn("last_change_time2", date_infos(7))
      .withColumn("last2_change_date", date_infos(8))
      .withColumn("last2_change_time", date_infos(9))
      .withColumn("last2_change_time2", date_infos(10))
      .withColumn("last_change_date3bef", date_infos(11))
      .withColumn("last_change_date3aft", date_infos(12))
      .withColumn("last_change_date7bef", date_infos(13))
      .withColumn("last_change_date7aft", date_infos(14))
      .withColumn("last_change_date14bef", date_infos(15))
      .withColumn("last_change_date14aft", date_infos(16))
      .withColumn("p3_multi_infos", etaMarkUDF('change_cnt30, 'last_change_date, 'last_change_time2, 'modified_tm, 'modifier, 'revise_run_tm, 'effective_range, 'remark))
      .withColumn("last_modified_tm", mark_infos(0))
      .withColumn("last_modifier", mark_infos(1))
      .withColumn("last_revise_run_tm", mark_infos(2))
      .withColumn("last_effective_range", mark_infos(3))
      .withColumn("last_remark", mark_infos(4))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //拼装结果字段
    val res_cols = spark.sql("""select * from dm_gis.eta_time_change_daily limit 0""").schema.map(_.name).map(col)
    //3d info
    val step3_merge_df = step2_merge_df.repartition(1200)
      .withColumn("d3_infos", lastDaysUDF('last_change_date3aft, 'last_change_date3bef, 'last_change_date, 'today30, 'today3, 'change_date_diff, 'line_time, 'task_inc_day, 'ac_is_run_ontime))
      .withColumn("task_change_before3", d3_infos(0))
      .withColumn("task_change_ontimebefore3", d3_infos(1))
      .withColumn("task_change_notontimebefore3", d3_infos(2))
      .withColumn("task_change_after3", d3_infos(3))
      .withColumn("task_change_ontimeafter3", d3_infos(4))
      .withColumn("task_change_notontimeafter3", d3_infos(5))
      //7d info
      .withColumn("d7_infos", lastDaysUDF('last_change_date7aft, 'last_change_date7bef, 'last_change_date, 'today30, 'today7, 'change_date_diff, 'line_time, 'task_inc_day, 'ac_is_run_ontime))
      .withColumn("task_change_before7", d7_infos(0))
      .withColumn("task_change_ontimebefore7", d7_infos(1))
      .withColumn("task_change_notontimebefore7", d7_infos(2))
      .withColumn("task_change_after7", d7_infos(3))
      .withColumn("task_change_ontimeafter7", d7_infos(4))
      .withColumn("task_change_notontimeafter7", d7_infos(5))
      //14d info
      .withColumn("d14_infos", lastDaysUDF('last_change_date14aft, 'last_change_date14bef, 'last_change_date, 'today30, 'today14, 'change_date_diff, 'line_time, 'task_inc_day, 'ac_is_run_ontime))
      .withColumn("task_change_before14", d14_infos(0))
      .withColumn("task_change_ontimebefore14", d14_infos(1))
      .withColumn("task_change_notontimebefore14", d14_infos(2))
      .withColumn("task_change_after14", d14_infos(3))
      .withColumn("task_change_ontimeafter14", d14_infos(4))
      .withColumn("task_change_notontimeafter14", d14_infos(5))
      .withColumn("ontime_change_ratio3bef", when('task_change_before3 =!= 0, 'task_change_ontimebefore3 / 'task_change_before3).otherwise("-"))
      .withColumn("ontime_change_ratio3aft", when('task_change_after3 =!= 0, 'task_change_ontimeafter3 / 'task_change_after3).otherwise("-"))
      .withColumn("ontime_change_ratio7bef", when('task_change_before7 =!= 0, 'task_change_ontimebefore7 / 'task_change_before7).otherwise("-"))
      .withColumn("ontime_change_ratio7aft", when('task_change_after7 =!= 0, 'task_change_ontimeafter7 / 'task_change_after7).otherwise("-"))
      .withColumn("ontime_change_ratio14bef", when('task_change_before14 =!= 0, 'task_change_ontimebefore14 / 'task_change_before14).otherwise("-"))
      .withColumn("ontime_change_ratio14aft", when('task_change_after14 =!= 0, 'task_change_ontimeafter14 / 'task_change_after14).otherwise("-"))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)

    writeToHive(spark, step3_merge_df.coalesce(2), Seq("inc_day"), "dm_gis.eta_time_change_daily")
    o_eta_change_df.unpersist()
    step1_merge_df.unpersist()
    step2_merge_df.unpersist()
  }

  def sortField = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("\\|")
      val other_arr = other.split("\\|")
      val new_arr = num_arr.zip(other_arr).sortWith((x,y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })

  def lastDaysUDF = udf((last_change_date3aft: String, last_change_date3bef: String, last_change_date: String, today30: String, today3: String, change_date_diff: String, line_time: String, task_inc_day: String, ac_is_run_ontime: String) => {
    var task_change_before3, task_change_ontimebefore3, task_change_notontimebefore3, task_change_after3, task_change_ontimeafter3, task_change_notontimeafter3: Int = 0
    if (strNotNull(line_time)) {
      val line_time_arr = line_time.split("\\|")
      val tid_arr = task_inc_day.split("\\|")
      val ac_arr = ac_is_run_ontime.split("\\|")
      if (last_change_date > today30 && last_change_date < today3 && change_date_diff.toInt >= 3) {
        try {
          for (i <- 0 until line_time_arr.size) {
            if (tid_arr(i) < last_change_date && tid_arr(i) >= last_change_date3bef) task_change_before3 += 1
            if (tid_arr(i) < last_change_date && tid_arr(i) >= last_change_date3bef && ac_arr(i) == "1.0") task_change_ontimebefore3 += 1
            if (tid_arr(i) < last_change_date && tid_arr(i) >= last_change_date3bef && ac_arr(i) == "0.0") task_change_notontimebefore3 += 1
            if (tid_arr(i) >= last_change_date && tid_arr(i) < last_change_date3aft) task_change_after3 += 1
            if (tid_arr(i) >= last_change_date && tid_arr(i) < last_change_date3aft && ac_arr(i) == "1.0") task_change_ontimeafter3 += 1
            if (tid_arr(i) >= last_change_date && tid_arr(i) < last_change_date3aft && ac_arr(i) == "0.0") task_change_notontimeafter3 += 1
          }
        } catch {
          case e: Exception => logger.error("异常1001：" + e.getMessage)
        }
      }
    }
    task_change_before3 + "&&" + task_change_ontimebefore3 + "&&" + task_change_notontimebefore3 + "&&" + task_change_after3 + "&&" + task_change_ontimeafter3 + "&&" + task_change_notontimeafter3
  })

  def etaMarkUDF = udf((change_cnt30: String, last_change_date: String, last_change_time2: String, modified_tm: String, modifier: String, revise_run_tm: String, effective_range: String, remark: String) => {
    var last_modified_tm, last_modifier, last_revise_run_tm, last_effective_range, last_remark = "-"
    if (strNotNull(revise_run_tm) && change_cnt30.toInt > 0) {
      val run_tm_arr = revise_run_tm.split("\\|")
      val effective_range_arr = effective_range.split("\\|")
      val modified_tm_arr = modified_tm.split("\\|")
      val modifier_arr = modifier.split("\\|")
      val remark_arr = remark.split("\\|")
      try {
        for (i <- 0 until run_tm_arr.size) {
          val rang_end_tm = effective_range_arr(i).split("_")(0).replaceAll("-", "")
          val days_inter = daysBetweenDate(last_change_date, rang_end_tm)
          if (run_tm_arr(i).toDouble == last_change_time2.toDouble && days_inter >= 0 && days_inter <= 3) {
            last_modified_tm = modified_tm_arr(i)
            last_modifier = modifier_arr(i)
            last_revise_run_tm = run_tm_arr(i)
            last_effective_range = effective_range_arr(i)
            last_remark = remark_arr(i)
          }
        }
      } catch {
        case e: Exception => logger.error("异常1002：" + e.getMessage)
      }
    }
    last_modified_tm + "&&" + last_modifier + "&&" + last_revise_run_tm + "&&" + last_effective_range + "&&" + last_remark
  })

  def getDate2CntUDF = udf((change_date2: String, line_time_change: String, today7: String, today14: String, today21: String, today30: String) => {
    var change_cnt7, change_cnt14, change_cnt21, change_cnt30, change_date_diff: Int = 0
    var last_change_date, last_change_time, last_change_time2, last2_change_date, last2_change_time, last2_change_time2 = "-"
    var last_change_date3bef, last_change_date3aft, last_change_date7bef, last_change_date7aft, last_change_date14bef, last_change_date14aft = "-"
    if (change_date2 != "-") {
      val date2_arr = change_date2.split(",")
      val ltc_arr = line_time_change.split(",")
      try {
        for (i <- 0 until date2_arr.size) {
          if (date2_arr(i) > today7) change_cnt7 += 1
          if (date2_arr(i) > today14) change_cnt14 += 1
          if (date2_arr(i) > today21) change_cnt21 += 1
          if (date2_arr(i) > today30) change_cnt30 += 1
        }
      } catch {
        case e: Exception => logger.error("异常1003：" + e.getMessage)
      }
      try {
        if (change_cnt30 > 0) {
          last_change_date = date2_arr(date2_arr.size - 1)
          last_change_time = ltc_arr(ltc_arr.size - 1)
          last_change_time2 = ltc_arr(ltc_arr.size - 1).split("->")(1)
        }
        if (change_cnt30 > 1) {
          last2_change_date = date2_arr(date2_arr.size - 2)
          last2_change_time = ltc_arr(ltc_arr.size - 2)
          last2_change_time2 = ltc_arr(ltc_arr.size - 2).split("->")(1)
        }
      } catch {
        case e: Exception => logger.error("异常1004：" + e.getMessage)
      }
    }
    if (last_change_date != "-") {
      last_change_date3bef = getDaysApartDate("yyyyMMdd", last_change_date, -3)
      last_change_date3aft = getDaysApartDate("yyyyMMdd", last_change_date, 3)
      last_change_date7bef = getDaysApartDate("yyyyMMdd", last_change_date, -7)
      last_change_date7aft = getDaysApartDate("yyyyMMdd", last_change_date, 7)
      last_change_date14bef = getDaysApartDate("yyyyMMdd", last_change_date, -14)
      last_change_date14aft = getDaysApartDate("yyyyMMdd", last_change_date, 14)
    }
    if (change_cnt30 > 1 && last2_change_date != "-" && last_change_date != "-") {
      change_date_diff = daysBetweenDate(last2_change_date, last_change_date)
    } else if (change_cnt30 > 0) {
      change_date_diff = 40
    }
    change_cnt7 + "&&" + change_cnt14 + "&&" + change_cnt21 + "&&" + change_cnt30 + "&&" + change_date_diff + "&&" +
      last_change_date + "&&" + last_change_time + "&&" + last_change_time2 + "&&" + last2_change_date + "&&" + last2_change_time + "&&" + last2_change_time2 + "&&" +
      last_change_date3bef + "&&" + last_change_date3aft + "&&" + last_change_date7bef + "&&" + last_change_date7aft + "&&" + last_change_date14bef + "&&" + last_change_date14aft
  })

  def splitLineCodeUDF = udf((line_time: String, task_inc_day: String, ac_is_run_ontime: String, today7: String, today14: String, today21: String, today30: String) => {
    var task7, ontime_task7, notontime_task7, task14, ontime_task14, notontime_task14, task21, ontime_task21, notontime_task21, task30, ontime_task30, notontime_task30 = 0
    val line_time_change, change_date, change_date2 = new ArrayBuffer[String]()
    if (line_time != "" && !line_time.isEmpty) {
      val tm_arr = line_time.split("\\|")
      val tid_arr = task_inc_day.split("\\|")
      val ac_arr = ac_is_run_ontime.split("\\|")
      try {
        for (i <- 0 until tm_arr.size) {
          if (tid_arr(i) > today7) task7 += 1
          if (tid_arr(i) > today7 && ac_arr(i) == "1.0") ontime_task7 += 1
          if (tid_arr(i) > today7 && ac_arr(i) == "0.0") notontime_task7 += 1
          if (tid_arr(i) > today14) task14 += 1
          if (tid_arr(i) > today14 && ac_arr(i) == "1.0") ontime_task14 += 1
          if (tid_arr(i) > today14 && ac_arr(i) == "0.0") notontime_task14 += 1
          if (tid_arr(i) > today21) task21 += 1
          if (tid_arr(i) > today21 && ac_arr(i) == "1.0") ontime_task21 += 1
          if (tid_arr(i) > today21 && ac_arr(i) == "0.0") notontime_task21 += 1
          if (tid_arr(i) > today30) task30 += 1
          if (tid_arr(i) > today30 && ac_arr(i) == "1.0") ontime_task30 += 1
          if (tid_arr(i) > today30 && ac_arr(i) == "0.0") notontime_task30 += 1
          if (i > 0 && tm_arr(i) != tm_arr(i - 1)) {
            line_time_change += tm_arr(i - 1) + "->" + tm_arr(i)
            change_date += tid_arr(i - 1) + "->" + tid_arr(i)
            change_date2 += tid_arr(i)
          }
        }
      } catch {
        case e: Exception => logger.error("字段数量是否一致" + e.getMessage)
      }
    }
    if (line_time_change.size < 1) line_time_change += "-"
    if (change_date.size < 1) change_date += "-"
    if (change_date2.size < 1) change_date2 += "-"
    task7 + "&&" + ontime_task7 + "&&" + notontime_task7 + "&&" + task14 + "&&" + ontime_task14 + "&&" + notontime_task14 + "&&" +
      task21 + "&&" + ontime_task21 + "&&" + notontime_task21 + "&&" + task30 + "&&" + ontime_task30 + "&&" + notontime_task30 + "&&" +
      line_time_change.mkString(",") + "&&" + change_date.mkString(",") + "&&" + change_date2.mkString(",")
  })

  def getOriginData(spark: SparkSession, inc_day: String): (DataFrame, DataFrame) = {
    val days_45_ago = getdaysBeforeOrAfter(inc_day, -45)
    //1 任务表格
    val o_task_df = spark.sql(
      s"""
         |select task_subid,line_code,line_time,start_dept,end_dept,start_type,end_type,start_outer_add_code,end_outer_add_code,
         |        actual_run_time,ac_is_run_ontime,actual_depart_tm,transoport_level,task_area_code,task_inc_day,inc_day,
         |        concat_ws('_',line_code,start_dept,end_dept,start_type,end_type,start_outer_add_code,end_outer_add_code) `group`,
         |        concat_ws('_',line_code,start_dept,end_dept) group1
         |from (select task_subid,regexp_replace(line_code,' ','') line_code,line_time,start_dept,end_dept,start_type,end_type,start_outer_add_code,end_outer_add_code,
         |         actual_run_time,ac_is_run_ontime,actual_depart_tm,transoport_level,task_area_code,task_inc_day,inc_day,
         |         row_number() over(PARTITION by task_subid ORDER by inc_day desc) as rn
         |      from dm_gis.eta_std_line_recall where inc_day>='$days_45_ago' and inc_day<='$inc_day' and task_inc_day>='$days_45_ago' and task_inc_day<='$inc_day' and if_evaluate_time='1') a
         |where rn=1
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //2 业务时效调整表格
    val o_eta_change_df = spark.sql(
      s"""select regexp_replace(line_code,' ','') line_code,
         |      if(work_days is null or trim(work_days) ='','-',work_days) work_days,
         |      if(remark is null or trim(remark) ='','-',remark) remark,
         |      if(modifier is null or trim(modifier) ='','-',modifier) modifier,
         |      if(modified_tm is null or trim(modified_tm) ='','-',modified_tm) modified_tm,
         |      if(expiration_date is null or trim(expiration_date) ='','-',expiration_date) expiration_date,
         |      concat_ws('_',regexp_replace(line_code,' ',''),load_zone_code,dest_zone_code) group1,
         |      revise_run_tm/60 revise_run_tm,
         |      cast(revise_distance as double)/60 revise_distance,
         |      concat_ws('_',effective_date,expiration_date) effective_range
         | from dm_pass_rss.rmsa_tm_distance_times_pro where inc_day='$inc_day'and status=1""".stripMargin)
      .withColumn("order", row_number().over(Window.partitionBy("group1").orderBy(desc("expiration_date"))))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    (o_task_df, o_eta_change_df)
  }
}
