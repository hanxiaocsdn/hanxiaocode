package com.sf.app.navi

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import utils.SparkBuilder

/**
 * @description: 将hdfs上的csv文件压缩后 上传至ftp
 * @author 01418539 caojia
 * @date 2022/7/18 下午4:34
 */
object LoadFlatmapTrackToCSV extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processExtractFun(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processExtractFun(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    //3天数据量  gz压缩完后 45.2 G
    val o_track = spark.sql(
      """
        |select un, tp, zx, zy, ac, ad, be, sp, tm,'' bn, inc_day
        | from dm_gis.gis_vms_track_device_track_flatmap
        |where inc_day>='20220713' and inc_day <= '20220715'
        |      and ak in ('314','324')
        |""".stripMargin)
      .repartition(300, 'un)
      .withColumn("num",row_number().over(Window.partitionBy("un").orderBy("tm")))
      .drop("num")

    //csv的属性信息
    val path = "/user/01418539/upload/file/part_tracks_info"
    val options = Map(
      "header" -> "true",
      "delimiter" -> "\t",
      "compression"-> "gzip",
      "inferSchema" -> true.toString
    )
    writeToCsv(spark, o_track, SaveMode.Overwrite, inc_day,options,path,false)
    //writeToHive(spark,o_track,Seq("inc_day"),"dm_gis.gis_vms_device_tracks_info")
  }
}
