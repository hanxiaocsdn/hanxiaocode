package com.sf.app.scm

import com.sf.app.eta.EfficientLowerSpeedMerge.splitFun
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

/**
 * @task_id: 614219
 * @description:实时薪酬里程合理情况每日统计表 gis_eta_realtime_dist_result_daily
 * @demander: 01423372 马晶玲
 * @author 01418539 caojia
 * @date 2022/12/15 17:03
 */
object RealtimeSalaryMonitoringIndicate extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processRTMon(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processRTMon(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val days_7_ago = getdaysBeforeOrAfter(inc_day, -6)
    val pub_over_cols = row_number().over(Window.partitionBy("task_subid").orderBy(desc("inc_day")))
    val tf_over_cols = row_number().over(Window.partitionBy("task_id", "start_dept", "end_dept").orderBy(desc("report_time")))
    //ta task info 	2311c
    val oa_acc_p1_df = spark.sql(s"""select task_id,source_type,inc_day from dm_gis.gis_eta_ts_accural_parse1 where inc_day between '$days_7_ago' and '$inc_day' and source_type in ('1','0') and task_id is not null and trim(task_id) !=''""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("task_id").orderBy(desc("inc_day")))).filter('num === 1).select("task_id", "source_type")
    //tb 	 轨迹完整率 2500c
    val ob_acc_p2_df = spark.sql(s"""select inc_day,task_area_code,task_id,task_subid,start_dept,end_dept,start_outer_addr_code,end_outer_addr_code,line_code,vehicle_serial,actual_capacity_load,plan_depart_tm,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,driver_name,start_longitude,start_latitude,end_longitude,end_latitude,vehicle_type,carrier_name,stop_over_zone_code,main_driver_account,deputy_driver_account,inc_day,std_id,line_distance,task_inc_day,error_type,conduct_type,pns_dist,rt_dist from dm_gis.gis_eta_ts_accural_parse2 where inc_day between '$days_7_ago' and '$inc_day'  and task_inc_day = '$inc_day' and task_subid is not null and trim(task_subid) !=''""".stripMargin)
      .withColumn("num", pub_over_cols).filter('num === 1).drop("num", "inc_day")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //用于轨迹数据提前筛选子任务ID
    val ob_task_subid = ob_acc_p2_df.select("task_subid").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")

    //tc 标准路由监控回溯表 经纬度 提前筛选 task_subid
    val oc_recall_df = spark.sql(s"""select task_subid,inc_day,actual_depart_tm recall_actual_depart_tm,actual_arrive_tm recall_actual_arrive_tm,std_id recall_std_id,accrual_dist recall_accrual_dist,rt_dist recall_rt_dist,pns_dist recall_pns_dist,conduct_type recall_conduct_type,error_type recall_error_type from dm_gis.eta_std_line_recall where inc_day between '$days_7_ago' and '$inc_day' and task_inc_day = '$inc_day' and carrier_type = '0' and task_subid in ($ob_task_subid)""".stripMargin)
      .withColumn("num", pub_over_cols).filter('num === 1).drop("num", "inc_day")
    //td eta标准线路 经纬度
    val od_rectify_df = spark.sql(s"""select task_subid,inc_day,dist_a,dist_b,dist_c from dm_gis.eta_std_line_rectify where inc_day between '$days_7_ago' and '$inc_day' and task_inc_day = '$inc_day' and task_subid in ($ob_task_subid)""".stripMargin)
      .withColumn("num", pub_over_cols).filter('num === 1).drop("num", "inc_day")
    //te 导航计提里程表 单天200c~
    val oe_acc_dist_df = spark.sql(s"""select task_id,startdept start_dept,enddept end_dept,activeyawcount,appver from dm_gis.gis_eta_navi_accrualdist where inc_day between '$days_7_ago' and '$inc_day' and task_id is not null and trim(task_id) !=''""".stripMargin)
      .groupBy("task_id", "start_dept", "end_dept")
      .agg(
        last("activeyawcount") as "activeyawcount",
        last("appver") as "appver"
      )
    //tf navi之sdkNaviLog解析表-SDK导航反馈日志信息表
    val of_navi_parse_df = spark.sql(s"""select task_id,curstartdept start_dept,curenddept end_dept,end_type,endx,endy,cc,report_time from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$days_7_ago' and '$inc_day' and type='3' and task_id is not null and trim(task_id) !=''""".stripMargin)
      .withColumn("num", tf_over_cols).filter('num === 1).drop("num", "report_time")

    val combine_cond = splitFun("&&")('combine_cond)
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_realtime_dist_result_daily limit 0""").schema.map(_.name).map(col)
    val res_df = ob_acc_p2_df.join(oa_acc_p1_df, Seq("task_id"), "left")
      .join(oc_recall_df, Seq("task_subid"), "left")
      .join(od_rectify_df, Seq("task_subid"), "left")
      .join(of_navi_parse_df, Seq("task_id", "start_dept", "end_dept"), "left")
      .join(broadcast(oe_acc_dist_df), Seq("task_id", "start_dept", "end_dept"), "left")
      .na.fill("", Seq("pns_dist", "rt_dist", "error_type", "conduct_type", "recall_error_type", "conduct_type", "recall_conduct_type", "recall_rt_dist", "std_id", "recall_std_id"))
      .withColumn("accual_dist", accDistUDF('pns_dist, 'rt_dist, 'error_type, 'conduct_type))
      .withColumn("dist_diff", ('recall_accrual_dist - 'accual_dist) / 1000)
      .withColumn("comp_sum", 'dist_a.cast("double") + 'dist_c.cast("double"))
      .na.fill(0.0, Seq("dist_diff", "comp_sum"))
      .withColumn("combine_cond", logtypeUDF('recall_error_type, 'error_type, 'dist_diff, 'comp_sum, 'conduct_type, 'recall_conduct_type, 'rt_dist, 'recall_rt_dist, 'std_id, 'recall_std_id))
      .withColumn("if_logical", combine_cond(0))
      .withColumn("tag", combine_cond(1))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(2), Seq("inc_day"), "dm_gis.gis_eta_realtime_dist_result_daily")
    ob_acc_p2_df.unpersist()
  }

  def logtypeUDF = udf((recall_error_type: String, error_type: String, dist_diff: Double, comp_sum: Double, conduct_type: String, recall_conduct_type: String, rt_dist: String, recall_rt_dist: String, std_id: String, recall_std_id: String) => {
    var combin_cond: (String, String) = ("1", "9")
    val pub_cond1 = Seq("0", "2", "3", "2|3").contains(recall_error_type) && Seq("0", "2", "3", "2|3").contains(error_type)
    var recall_rt_dist_new,rt_dist_new = 0.0
    try {
      recall_rt_dist_new = recall_rt_dist.toDouble
    } catch {
      case e: Exception => logger.error("空值" + e.getMessage)
    }
    try {
      rt_dist_new = rt_dist.toDouble
    } catch {
      case e: Exception => logger.error("空值" + e.getMessage)
    }
    val pub_cond2 = ((recall_rt_dist_new - comp_sum - rt_dist_new) / 1000).abs <= 1
    if (!Seq("0", "2", "3", "2|3").contains(recall_error_type)) {
      combin_cond = ("2", "0")
    } else if (!Seq("0", "2", "3", "2|3").contains(error_type)) {
      combin_cond = ("0", "1")
    } else if (pub_cond1 && dist_diff.abs <= 1) {
      combin_cond = ("0", "2")
    } else if (pub_cond1 && conduct_type == "1" && (dist_diff >= -10 && dist_diff <= 1)) {
      combin_cond = ("0", "3")
    } else if (pub_cond1 && pub_cond2 && recall_conduct_type == conduct_type) {
      combin_cond = ("0", "4")
    } else if (pub_cond1 && pub_cond2 && recall_std_id != std_id) {
      combin_cond = ("0", "5")
    }
    combin_cond._1 + "&&" + combin_cond._2
  })

  def accDistUDF = udf((pns_dist: String, rt_dist: String, error_type: String, conduct_type: String) => {
    var accual_dist = rt_dist
    if (!pns_dist.isEmpty && pns_dist.trim != "") {
      if (rt_dist.isEmpty || rt_dist.trim == "" || rt_dist == 0) {
        accual_dist = pns_dist
      } else {
        try { //Seq("0", "2", "3", "2|3").contains(error_type) error_type == "0" || error_type == "2" || error_type == "3" || error_type == "2|3"
          if (Seq("0", "2", "3", "2|3").contains(error_type)) {
            if (conduct_type == "1") {
              accual_dist = Seq(pns_dist, rt_dist).map(_.toDouble).max.toString
            } else {
              accual_dist = Seq(pns_dist, rt_dist).map(_.toDouble).min.toString
            }
          } else {
            accual_dist = pns_dist
          }
        } catch {
          case e: Exception => logger.error("里程数据有异常" + e.getMessage)
        }
      }
    }
    accual_dist
  })
}
