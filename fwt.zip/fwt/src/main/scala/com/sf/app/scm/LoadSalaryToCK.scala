package com.sf.app.scm

import com.sf.app.scm.StandLineMileageMonitor.logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat_ws, lit, row_number}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import utils.JDBCUtils.getSmartNaviCKConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}
import java.util.Properties

/**
 * @task_id: 628126
 * @description: 导表至ck中 gis_eta_realtime_dist_result_daily
 * @demander: 01423372 马晶玲
 * @author 01418539 caojia
 * @date 2022/12/28 19:41
 */
object LoadSalaryToCK {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    upsertToClickhouseSalary(spark, "dm_gis", "gis_oms_uimp_pns", "GIS_ETA_REALTIME_DIST_RESULT_DAILY", "gis_eta_realtime_dist_result_daily", start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }


  def upsertToClickhouseSalary(spark: SparkSession, hivedbName: String, ckdbName: String, cktableName: String, hivetableName: String, start_day: String, end_day: String): Unit = {
    val conn: Connection = getSmartNaviCKConnect()
    try {
      val querySql = s"select * from $ckdbName.$cktableName where SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING(STATDATE,1,10) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"ALTER TABLE $ckdbName.$cktableName DELETE WHERE SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING(STATDATE,1,10) <= '$end_day'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 $ckdbName.$cktableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
    val ck_url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_pns"
    val ckProp = new Properties()
    //写入/out读出参数
    val ck_params = Map[String, String](
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "gis_oms_pns",
      "password" -> "gis_oms_pns@123@"
    )

    //加载 hive 中的表数据
    spark.sql(
      s"""
         |select *
         |from $hivedbName.$hivetableName
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .withColumn("statdate", col("inc_day"))
      .withColumn("random_id", row_number().over(Window.partitionBy("inc_day").orderBy("inc_day")))
      .withColumn("id", concat_ws("_", col("random_id"), col("inc_day"))).drop("random_id")
      .withColumn("create_time", lit(new java.sql.Timestamp(new java.util.Date().getTime())))
      .withColumn("create_user", lit(""))
      .withColumn("modify_time", lit(new java.sql.Timestamp(new java.util.Date().getTime())))
      .withColumn("modify_user", lit(""))
      .select("id", "statdate", "task_area_code", "task_id", "task_subid", "start_dept", "end_dept", "start_outer_addr_code", "end_outer_addr_code", "line_code", "vehicle_serial", "actual_capacity_load", "plan_depart_tm", "actual_depart_tm", "plan_arrive_tm", "actual_arrive_tm", "driver_name", "start_longitude", "start_latitude", "end_longitude", "end_latitude", "vehicle_type", "carrier_name", "stop_over_zone_code", "main_driver_account", "deputy_driver_account", "std_id", "line_distance", "task_inc_day", "source_type", "error_type", "conduct_type", "pns_dist", "rt_dist", "accual_dist", "recall_actual_depart_tm", "recall_actual_arrive_tm", "recall_std_id", "recall_accrual_dist", "recall_rt_dist", "recall_pns_dist", "recall_conduct_type", "recall_error_type", "dist_diff",
        "if_logical", "tag", "dist_a", "dist_b", "dist_c", "comp_sum", "activeyawcount", "appver", "end_type", "endx", "endy", "cc", "create_time", "create_user", "modify_time", "modify_user")
      .write.mode(SaveMode.Append).options(ck_params).jdbc(ck_url, s"$ckdbName.$cktableName", ckProp)

    //读出数据，检查是否写成功
    val querySQL = s"(SELECT *  FROM $ckdbName.$cktableName where SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING( STATDATE,1,10) <= '$end_day') as tmp"

    val partData: DataFrame = spark.read
      .format("jdbc")
      .option("url", ck_url)
      .options(ck_params)
      .option("dbtable", querySQL)
      .load()
    partData.limit(20).collect().foreach(println(_))
    logger.error(s"insert into table $ckdbName.$cktableName,the count bettween $start_day to $end_day is:" + partData.count())
  }

}
