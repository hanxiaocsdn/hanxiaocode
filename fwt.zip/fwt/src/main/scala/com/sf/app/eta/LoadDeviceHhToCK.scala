package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import utils.JDBCUtils.getOwnerDevCKConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}
import java.util.Properties

/**
 * @task_id: 733683
 * @description:时效定责实时化需求-数据推送到ck
 * @demander: 邵一馨  01408890
 * @author 01418539 caojia
 * @date 2023/4/25 16:32
 */
object LoadDeviceHhToCK extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    upsertvehicleToClickhouse(spark, "dm_device_hh_dtl_di", start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def upsertvehicleToClickhouse(spark: SparkSession, tableName: String, start_day: String, end_day: String): Unit = {
    val ck_url = "jdbc:clickhouse://10.119.82.211:8123/dm_ck_scm"
    val ckProp = new Properties()
    //写入/out读出参数
    val ck_params = Map[String, String](
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "dm_ck_scm",
      "password" -> "dm_ck_scm@123@"
    )
    //加载 hive 中的表数据  day 7w
    spark.sql(
      s"""
         |select
         | *
         |from dm_arss.$tableName
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .write.mode(SaveMode.Append).options(ck_params).jdbc(ck_url, s"dm_ck_scm.$tableName", ckProp)

    //读出数据，检查是否写成功
    val querySQL = s"(SELECT *  FROM dm_ck_scm.$tableName where SUBSTRING( inc_day,1,10) >= '$start_day' and SUBSTRING( inc_day,1,10) <= '$end_day') as tmp"

    val partData: DataFrame = spark.read
      .format("jdbc")
      .option("url", ck_url)
      .options(ck_params)
      .option("dbtable", querySQL)
      .load()
    partData.limit(20).collect().foreach(println(_))
    logger.error(s"insert into table dm_ck_scm.$tableName,the count bettween $start_day to $end_day is:" + partData.count())

    val conn: Connection = getOwnerDevCKConnect()
    try {
      val querySql = s"select inc_day from dm_ck_scm.$tableName where SUBSTRING(inc_day,1,10) < '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      logger.error(s"查询表 dm_ck_scm.$tableName 中$start_day 至 $end_day 数据是否存在>>>>>>>" + queryRes.next())
      if (queryRes.next()) {
        val delSql = s"ALTER TABLE dm_ck_scm.$tableName DELETE WHERE SUBSTRING(inc_day,1,10) < '$end_day'"
        logger.error("执行的删除语句>>>>" + delSql)
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 dm_ck_scm.$tableName 中$start_day 至 $end_day 数据时出现错误" + ex.getMessage)
    } finally {
      conn.close()
    }
  }
}
