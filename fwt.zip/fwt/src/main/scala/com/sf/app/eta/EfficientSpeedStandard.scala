package com.sf.app.eta

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.app.eta.Efficient320w_500WRoadTrackAnalysis.{getHourUDF, getRoadSpeed, gettlDuraionSingleUdf}
import com.sf.app.eta.EfficientSwidAccleration.{getDisHighspeedBlock, getDuration_1_2, getRoadclass_tl, getSwid_tl}
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.{HTTP_LSS_RECTIFY_P, HTTP_TRACK_INTEGRATION_REP_P, HTTP_XY_COORDS_P}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil._
import utils.DateUtil.{sdf1, timeToTimestampFormat, tranTstampToTime}
import utils.EtaUtil.{extractCodeRlikeUDF, getCityMapDF, mergeStartAndEndUDF}
import utils.{ColumnUtil, HttpInvokeUtil, SparkBuilder}

import scala.collection.JavaConversions.asScalaIterator
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 693174
 * @description: 【时速标准】高速路段截取 顺丰内部数据，单天14w~  7664c42850b74da6b880a6ecf0ef2077 6000/分 1000W/天
 * @demander:舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/4/4 13:55
 */
object EfficientSpeedStandard extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val run_flag = args(1)
    val city_map_info = getCsv2DF(spark)._2
    val city_map_df = getCityMapDF(spark, inc_day)
    processStandSpeed(spark, city_map_df, inc_day)
    val sort_eta_df = spark.sql(s"""select * from dm_gis.eta_task_track_sf_tmp where inc_day ='$inc_day'""")
    calHighWaySpeed(spark, sort_eta_df, city_map_df, inc_day)
    val o_eta_df = spark.sql(s"""select * from dm_gis.eta_task_track_sf_inter where inc_day ='$inc_day'""").persist()
    val p3_df = procPostVehicleTime(spark, o_eta_df)
    procRoadInfo(spark, p3_df, city_map_info)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  /**
   * part 1 获取原始数据
   *
   * @param spark
   * @param inc_day
   * @return
   */
  def processStandSpeed(spark: SparkSession, city_map_df: DataFrame, inc_day: String): DataFrame = {
    import spark.implicits._
    val eta_sql =
      s"""select * from
         |(select task_subid,task_id,actual_depart_tm,actual_arrive_tm,plan_arrive_tm,plan_depart_tm,actual_run_time,ac_is_run_ontime,
         |carrier_name,carrier_type,vehicle_serial,vehicle_type,driver_name,start_dept,end_dept,line_code,line_time,line_distance,
         |split(sum_dist,'\\\\|')[size(split(sum_dist,'\\\\|'))-1] as sum_dist_last,
         |jp_swid,jp_time,t_links_union,regexp_replace(tl_time_periods,'\\\\[|\\\\]','') tl_time_periods,tl_link,tl_road,tl_roadclass,transoport_level,
         |rank() over (partition by task_subid order by inc_day desc) as ranking,inc_day
         |from dm_gis.eta_time_monitor
         |where inc_day='$inc_day'
         |--and jp_swid is not null and trim(jp_swid)!=''
         |--and jp_time is not null and trim(jp_time)!=''
         |--and t_links_union is not null and trim(t_links_union)!=''
         |) a where ranking=1
         |""".stripMargin
    logger.error("输入的取数sql >>> " + eta_sql)

    val res_cols = spark.sql("""select * from dm_gis.eta_task_track_sf_tmp limit 0""").schema.map(_.name).map(x => if (Seq("task_id", "inc_day").contains(x)) x else x + "_n").map(col)

    val part_cols_str = Seq("start_city", "end_city", "task_subid", "actual_depart_tm", "actual_arrive_tm", "actual_run_time", "plan_arrive_tm", "plan_depart_tm", "ac_is_run_ontime", "carrier_name", "carrier_type", "vehicle_serial", "vehicle_type", "driver_name", "start_dept", "end_dept", "line_code", "line_time", "line_distance", "sum_dist_last", "jp_swid", "jp_time", "t_links_union", "tl_time_periods", "tl_link", "tl_road", "tl_roadclass", "transoport_level")

    val part_agg_cols = aggSequenceCols(part_cols_str)
    val reSort_agg_cols = resortColsFun(spark, part_cols_str)
    val o_eta_df = spark.sql(eta_sql) //todo 新增2个字段
      .withColumn("start_city_code", extractCodeRlikeUDF('start_dept))
      .withColumn("end_city_code", extractCodeRlikeUDF('end_dept))
      .join(broadcast(city_map_df.selectExpr("city_code as start_city_code", "city_name start_city")), Seq("start_city_code"), "left")
      .join(broadcast(city_map_df.selectExpr("city_code as end_city_code", "city_name end_city")), Seq("end_city_code"), "left")
      .withColumn("start_city", when('start_city_code.like("%391%") && ('start_city.isNull || trim('start_city) === ""), "焦作市").otherwise('start_city))
      .withColumn("end_city", when('end_city_code.like("%391%") && ('end_city.isNull || trim('end_city) === ""), "焦作市").otherwise('end_city))
      .withColumn("num", row_number().over(Window.partitionBy("task_id").orderBy("task_subid")))
      .groupBy("task_id", "inc_day")
      .agg(part_agg_cols.head, part_agg_cols.tail: _*).persist()

    val sort_eta_df = o_eta_df.select(o_eta_df.schema.map(_.name).map(col) ++ reSort_agg_cols: _*)
      .na.fill("", part_cols_str.map(_ + "_n"))
      .drop(part_cols_str: _*)
      .withColumn("sub_dept_n", mergeStartAndEndUDF('start_dept_n, 'end_dept_n))
      .withColumn("sub_dept_city_n", mergeStartAndEndUDF('start_city_n, 'end_city_n))
      .select(res_cols: _*).persist()
    logger.error("排序完成的数据总量为：>>>" + sort_eta_df.count())
    writeToHive(spark, sort_eta_df, Seq("inc_day"), "dm_gis.eta_task_track_sf_tmp")
    sort_eta_df
  }

  /**
   * part 2 逻辑加工
   *
   * @param spark
   * @param sort_eta_df
   * @return
   */
  def calHighWaySpeed(spark: SparkSession, sort_eta_df: DataFrame, city_map_df: DataFrame, inc_day: String): Unit = {
    import spark.implicits._
    val union_infos_str = splitFun("&")('union_infos)
    val swid_tl_infos_str = splitFun("&")('swid_tl_infos)
    val roadclass_name_infos_str = splitFun("&")('roadclass_name_infos)
    val duration_infos_str = splitFun("&")('duration_infos)
    val res_cols = spark.sql("""select * from dm_gis.eta_task_track_sf_inter limit 0""").schema.map(_.name).map(col)
    val p1_df = sort_eta_df.repartition(400, col("task_id"), col("actual_depart_tm"))
      .withColumn("tl_road", gettlRoad('tl_road))
      .withColumn("actual_depart_tm", getFirstOrLastOrSumUDF("first")('actual_depart_tm))
      .withColumn("actual_arrive_tm", getFirstOrLastOrSumUDF("last")('actual_arrive_tm))
      .withColumn("actual_run_time", getFirstOrLastOrSumUDF("sum")('actual_run_time))
      .withColumn("plan_arrive_tm", getFirstOrLastOrSumUDF("first")('plan_arrive_tm))
      .withColumn("plan_depart_tm", getFirstOrLastOrSumUDF("last")('plan_depart_tm))
      .withColumn("carrier_name", diffUdf('carrier_name))
      .withColumn("carrier_type", diffUdf('carrier_type))
      .withColumn("vehicle_serial", diffUdf('vehicle_serial))
      .withColumn("vehicle_type", diffUdf('vehicle_type))
      .withColumn("driver_name", diffUdf('driver_name))
      .withColumn("line_code", diffUdf('line_code))
      .withColumn("line_time", getFirstOrLastOrSumUDF("sum")('line_time))
      .withColumn("ac_ontime", when('actual_run_time.cast("double") - 'line_time.cast("double") <= 1, "1").otherwise("0"))
      .withColumn("line_distance", getFirstOrLastOrSumUDF("sum")('line_distance))
      .withColumn("sum_dist_last", getFirstOrLastOrSumUDF("sum")('sum_dist_last))
      .withColumn("transoport_level", diffUdf('transoport_level))
      .withColumn("start_dept", getFirstOrLastOrSumUDF("first")('start_dept))
      .withColumn("end_dept", getFirstOrLastOrSumUDF("last")('end_dept))
      .withColumn("start_dept_code", extractCodeUDF('start_dept))
      .withColumn("end_dept_code", extractCodeUDF('end_dept))
      .join(broadcast(city_map_df.selectExpr("city_code as start_dept_code", "city_name start_city")), Seq("start_dept_code"), "left")
      .join(broadcast(city_map_df.selectExpr("city_code as end_dept_code", "city_name end_city")), Seq("end_dept_code"), "left")
      .withColumn("start_city", when('start_dept_code.like("%391%") && ('start_city.isNull || trim('start_city) === ""), "焦作市").otherwise('start_city))
      .withColumn("end_city", when('end_dept_code.like("%391%") && ('end_city.isNull || trim('end_city) === ""), "焦作市").otherwise('end_city))
      .withColumn("direction", concat_ws("-", 'start_city, 'end_city))
      .persist()
    logger.error(">>第1部分数据总量>>>>" + p1_df.count())

    val p2_df = p1_df.repartition(400, col("task_id"), col("actual_depart_tm"))
      .withColumn("union_infos", splitUnion('t_links_union))
      .withColumn("qm_swid", union_infos_str(0))
      .withColumn("qm_name", union_infos_str(1))
      .withColumn("qm_roadclass", union_infos_str(2))
      .withColumn("qm_len", union_infos_str(3))
      .withColumn("index1", getIndex("first")('qm_roadclass, lit("0")))
      .withColumn("index2", getIndex("last")('qm_roadclass, lit("0")))
      .withColumn("highway_start_name", getWithIndex("name")('qm_name, 'index1))
      .withColumn("highway_end_name", getWithIndex("name")('qm_name, 'index2))
      .withColumn("highway", gethighway('qm_name, 'index1, 'index2))
      .withColumn("highway_start_swid", getWithIndex("swid")('qm_swid, 'index1))
      .withColumn("highway_end_swid", getWithIndex("swid")('qm_swid, 'index2))
      .withColumn("index3", getIndex("first")('jp_swid, 'highway_start_swid))
      .withColumn("index4", getIndex("last")('jp_swid, 'highway_end_swid))
      .withColumn("highway_start_time", getWithIndex("time")('jp_time, 'index3))
      .withColumn("highway_end_time", getWithIndex("time")('jp_time, 'index4))
      .withColumn("highway_dist", getHighwayDist('qm_len, 'index1, 'index2))
      .withColumn("highway_ac_dist", getHighway_ac_dist('qm_roadclass, 'qm_len))
      .withColumn("highway_pt", when('highway_dist.cast("double") > 0, round('highway_ac_dist / 'highway_dist, 3)).otherwise(0))
      .withColumn("dist", round(getFirstOrLastOrSumUDF("sum")('sum_dist_last) / lit(1000), 2))
      .persist()
    logger.error(">>第2部分数据总量>>>>" + p2_df.count())
    val p3_df = p2_df.repartition(400, col("task_id"), col("actual_depart_tm"))
      .withColumn("highway_all_pt", when('dist.cast("double") > 0, round('highway_ac_dist / 'dist, 3)).otherwise(0))
      .withColumn("highway_duration", getHighwayDuration('highway_start_time, 'highway_end_time))
      .withColumn("highway_speed", round(lit(60) * 'highway_dist.cast("double") / 'highway_duration.cast("double"), 2))
      .withColumn("highway_start_date", getDateOrHourUDF("date")('highway_start_time))
      .withColumn("highway_start_hour", getDateOrHourUDF("hour")('highway_start_time))
      .withColumn("highway_dist_block", getDisHighspeedBlock('highway_dist))
      .withColumn("tl_duration_1", getTimeIntersection111UDF('tl_time_periods, 'highway_start_time, 'highway_end_time))
      .withColumn("tl_duration_2", getTimeIntersection222UDF('tl_road, 'tl_roadclass, 'tl_time_periods, 'highway_start_time, 'highway_end_time))
      .withColumn("tl_duration_1_pt", when('highway_duration.cast("double") > 0, round('tl_duration_1 / 'highway_duration, 3)).otherwise(0))
      .withColumn("tl_duration_2_pt", when('highway_duration.cast("double") > 0, round('tl_duration_2 / 'highway_duration, 3)).otherwise(0))
      .withColumn("highway_speed_tl_1", round(lit(60) * 'highway_dist.cast("double") / ('highway_duration - 'tl_duration_1), 2))
      .withColumn("highway_speed_tl_2", round(lit(60) * 'highway_dist.cast("double") / ('highway_duration - 'tl_duration_2), 2))
      .na.fill("0.0", Seq("highway_speed"))
      .withColumn("highway_speed_block", getDisHighspeedStand('highway_speed))
      .withColumn("highway_speed_tl_1_block", getDisHighspeedStand('highway_speed_tl_1))
      .withColumn("highway_speed_tl_2_block", getDisHighspeedStand('highway_speed_tl_2))
      .withColumn("swid_tl_infos", getSwid_tl('jp_swid, 'jp_time, 'index3, 'index4))
      .withColumn("tl_swid_2", swid_tl_infos_str(0))
      .withColumn("tl_periods_2", swid_tl_infos_str(1))
      .withColumn("tl_duration_pre", swid_tl_infos_str(2))
      .withColumn("roadclass_name_infos", getRoadclass_tl('tl_swid_2, 'qm_swid, 'qm_roadclass, 'qm_name))
      .withColumn("tl_roadclass_2", roadclass_name_infos_str(0))
      .withColumn("tl_roadname_2", roadclass_name_infos_str(1))
      .na.fill("", Seq("tl_duration_pre", "tl_roadname_2", "tl_roadclass_2"))
      .withColumn("duration_infos", getDuration_1_2('tl_duration_pre, 'tl_roadname_2, 'tl_roadclass_2))
      .withColumn("tl_duration_3", duration_infos_str(0))
      .withColumn("tl_duration_4", duration_infos_str(1))
      .withColumn("tl_duration_3_pt", round('tl_duration_3 / 'highway_duration, 3))
      .withColumn("tl_duration_4_pt", round('tl_duration_4 / 'highway_duration, 3))
      .withColumn("highway_speed_tl_3", round(lit(60) * 'highway_dist / ('highway_duration - 'tl_duration_3), 2))
      .withColumn("highway_speed_tl_4", round(lit(60) * 'highway_dist / ('highway_duration - 'tl_duration_4), 2))
      .withColumn("highway_speed_tl_3_block", getDisHighspeedStand('highway_speed_tl_3))
      .withColumn("highway_speed_tl_4_block", getDisHighspeedStand('highway_speed_tl_4))
      .select(res_cols: _*)
      .persist()
    logger.error("得到最终数据结果总量>>>>>>" + p3_df.count())
    writeToHive(spark, p3_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_task_track_sf_inter")
    p1_df.unpersist()
    p2_df.unpersist()
  }

  /**
   * part 3 新增接口字段
   *
   * @param spark
   * @param eta_df
   */
  def procPostVehicleTime(spark: SparkSession, eta_df: DataFrame): DataFrame = {
    import spark.implicits._

    val o_p_eta = eta_df.select("vehicle_serial", "qm_swid", "actual_depart_tm", "actual_arrive_tm", "inc_day").repartition(20)
    logger.error(">>接口调用前数据总量>>>" + o_p_eta.count())
    val httpInvoke_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "693174", "【时效速度】EfficientSpeedStandard", "纠偏获取停留信息", HTTP_LSS_RECTIFY_P, "7664c42850b74da6b880a6ecf0ef2077", o_p_eta.count(), 20)
    val httpInvoke_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "693174", "【时效速度】EfficientSpeedStandard", "融合历史轨迹接口", HTTP_TRACK_INTEGRATION_REP_P, "7664c42850b74da6b880a6ecf0ef2077", o_p_eta.count(), 20)
    val httpInvoke_3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "693174", "【时效速度】EfficientSpeedStandard", "根据swid 获取 轨迹点信息接口", HTTP_XY_COORDS_P, "2e4b2a16ef2a4427917f366fb22febb5", o_p_eta.count(), 20)

    val inter_eta = o_p_eta.map(row => {
      val vehicle_serial = row.getAs[String]("vehicle_serial")
      val qm_swid = row.getAs[String]("qm_swid")
      val actual_depart_tm = row.getAs[String]("actual_depart_tm")
      val actual_arrive_tm = row.getAs[String]("actual_arrive_tm")
      val inc_day = row.getAs[String]("inc_day")

      var his_tracks, tl_time_periods_10, tl_link_10, tl_road_10, tl_roadclass_10, qm_adcode = ""
      if (actual_depart_tm != null && actual_depart_tm.trim != "" && actual_arrive_tm != null && actual_arrive_tm.trim != "") {
        val begindatetime_post = actual_depart_tm.replaceAll("-|:| ", "")
        val enddatetime_post = actual_arrive_tm.replaceAll("-|:| ", "")
        his_tracks = postTrackqueryIntegrate(vehicle_serial, begindatetime_post, enddatetime_post)
        if (qm_swid != null && qm_swid.trim != "") {
          qm_adcode = postPointInter(qm_swid, begindatetime_post)
        }
      }
      if (his_tracks != "") {
        val res_track = postLssRectify(his_tracks)
        tl_time_periods_10 = res_track._1
        tl_link_10 = res_track._2
        tl_road_10 = res_track._3
        tl_roadclass_10 = res_track._4
      }

      (vehicle_serial, actual_depart_tm, actual_arrive_tm, tl_time_periods_10, tl_link_10, tl_road_10, tl_roadclass_10, qm_swid, qm_adcode, inc_day)
    }).toDF("vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "tl_time_periods_10", "tl_link_10", "tl_road_10", "tl_roadclass_10", "qm_swid", "qm_adcode", "inc_day")
      .persist()
    logger.error(">>接口调用完后数据总量>>>" + inter_eta.count())
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_1)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_2)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_3)

    val p3_df = eta_df.join(inter_eta, Seq("vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "qm_swid", "inc_day"))
      .withColumn("tl_duration_10_1", getTimeIntersection111UDF('tl_time_periods_10, 'highway_start_time, 'highway_end_time))
      .withColumn("tl_duration_10_2", getTimeIntersection222UDF('tl_road_10, 'tl_roadclass_10, 'tl_time_periods_10, 'highway_start_time, 'highway_end_time))
      .withColumn("highway_speed_tl_10_1", round(lit(60) * 'highway_dist / ('highway_duration - 'tl_duration_10_1), 2))
      .withColumn("highway_speed_tl_10_2", round(lit(60) * 'highway_dist / ('highway_duration - 'tl_duration_10_2), 2))
      .withColumn("highway_speed_tl_10_1_block", getDisHighspeedStand('highway_speed_tl_10_1))
      .withColumn("highway_speed_tl_10_2_block", getDisHighspeedStand('highway_speed_tl_10_2))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>关联完后的数据总量>>>" + p3_df.count())
    p3_df
  }

  /**
   * part 4 新增路段road信息字段
   *
   * @param spark
   * @param eta_df
   */
  def procRoadInfo(spark: SparkSession, p3_df: DataFrame, city_map_info: mutable.HashMap[String, String]): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.eta_task_track_sf limit 0""").schema.map(_.name).map(col)
    val road_name_infos_str = splitFun("&")('road_name_infos)
    val road_other_infos_str = splitFun("&")('road_other_infos)
    val jp_infos_str = splitFun("&")('jp_infos)
    logger.error(">>>第4part获取的数据总量>>>>" + p3_df.count())
    val res_df = p3_df.na.fill("", Seq("index1", "index2", "qm_name", "qm_roadclass", "qm_adcode", "qm_swid", "jp_time", "jp_swid"))
      .withColumn("road_name_infos", getRadNameUdf('index1, 'index2, 'qm_name, 'qm_roadclass))
      .withColumn("road_name_dir", road_name_infos_str(0))
      .withColumn("road_if_highspeed_dir", road_name_infos_str(1))
      .withColumn("road_name_index", road_name_infos_str(2))
      .withColumn("road_cnt", road_name_infos_str(3))
      .withColumn("road_rank", road_name_infos_str(4))
      .na.fill("", Seq("road_name_index"))
      .withColumn("road_other_infos", getRoadSwidUdf(city_map_info)('qm_swid, 'qm_adcode, 'qm_len, 'road_name_index))
      .withColumn("road_swid_dir", road_other_infos_str(0))
      .withColumn("road_adcode_dir", road_other_infos_str(1))
      .withColumn("road_city_dir", road_other_infos_str(2))
      .withColumn("road_dist_dir", road_other_infos_str(3))
      .na.fill("", Seq("road_swid_dir", "road_adcode_dir", "road_city_dir", "road_dist_dir"))
      .withColumn("jp_infos", getJPtimeUdf('road_swid_dir, 'jp_swid, 'jp_time))
      .withColumn("road_time_dir", jp_infos_str(0))
      .withColumn("road_duration_dir", jp_infos_str(1))
      .na.fill("", Seq("road_dist_dir", "road_duration_dir"))
      .withColumn("road_speed_dir", getRoadSpeed('road_dist_dir, 'road_duration_dir))
      .withColumn("road_duration_tl", gettlDuraionSingleUdf('tl_time_periods_10, 'tl_road_10, 'tl_roadclass_10, 'road_time_dir, 'road_duration_dir))
      .na.fill("", Seq("road_duration_tl", "road_time_dir"))
      .withColumn("road_speed_tl", getRoadSpeed('road_dist_dir, 'road_duration_tl))
      .withColumn("road_start_hour", getHourUDF("hour")('road_time_dir))
      .select(res_cols: _*)
    writeToHive(spark, res_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_task_track_sf") //单天15w条数据
  }

  def getJPtimeUdf = udf((road_swid_dir: String, jp_swid: String, jp_time: String) => {
    val road_time_ab = new ArrayBuffer[String]()
    val road_duration_ab = new ArrayBuffer[String]()
    if (strNotNull(road_swid_dir) && strNotNull(jp_swid) && strNotNull(jp_time)) {
      val road_swid_arr = road_swid_dir.split("\\|")
      val jp_swid_arr = jp_swid.split("\\|")
      val jp_time_arr = jp_time.split("\\|")
      for (i <- 0 until road_swid_arr.length) {
        var start_tm, end_tm = "-"
        var start_tm_lo, end_tm_lo = 0l
        try {
          val s_swid = road_swid_arr(i).split("_")(0)
          val e_swid = road_swid_arr(i).split("_")(1)
          if (s_swid != "-") {
            breakable {
              for (j <- 0 until jp_swid_arr.length) {
                if (jp_swid_arr(j) == s_swid) {
                  start_tm_lo = jp_time_arr(j).toLong
                  start_tm = tranTstampToTime(sdf1, jp_time_arr(j))
                  break()
                }
              }
            }
          } else {
            start_tm = "-"
          }
          if (s_swid != "-") {
            breakable {
              for (k <- (0 until jp_swid_arr.length).reverse) {
                if (jp_swid_arr(k) == e_swid) {
                  end_tm_lo = jp_time_arr(k).toLong
                  end_tm = tranTstampToTime(sdf1, jp_time_arr(k))
                  break()
                }
              }
            }
          } else {
            end_tm = "-"
          }
        } catch {
          case e: Exception => "" + e
        }
        road_time_ab += start_tm + "_" + end_tm
        if (start_tm == "-" || end_tm == "-") {
          road_duration_ab += "-"
        } else {
          road_duration_ab += ((end_tm_lo - start_tm_lo) / 60.0).formatted("%.2f")
        }
      }
    }
    road_time_ab.mkString("|") + "&" + road_duration_ab.mkString("|")
  })

  def getRoadSwidUdf(city_map_info: mutable.HashMap[String, String]) = udf((qm_swid: String, qm_adcode: String, qm_len: String, road_name_index: String) => {
    val road_swid_ab = new ArrayBuffer[String]()
    val road_adcode_ab = new ArrayBuffer[String]()
    val road_city_ab = new ArrayBuffer[String]()
    val road_dist_ab = new ArrayBuffer[String]()
    if (strNotNull(qm_swid) && strNotNull(road_name_index)) {
      try {
        val qm_swid_arr = qm_swid.split("\\|")
        val qm_adcode_arr = qm_adcode.split("\\|")
        val qm_len_arr = qm_len.split("\\|")
        val road_name_index_arr = road_name_index.split("\\|")
        for (i <- 0 until road_name_index_arr.length) {
          val start_index = road_name_index_arr(i).split("_")(0)
          val end_index = road_name_index_arr(i).split("_")(1)
          road_swid_ab += qm_swid_arr(start_index.toInt) + "_" + qm_swid_arr(end_index.toInt)
          road_adcode_ab += (try {
            qm_adcode_arr(start_index.toInt)
          } catch {
            case e: Exception => "-"
          }) + "_" + (try {
            qm_adcode_arr(end_index.toInt)
          } catch {
            case e: Exception => "-"
          })

          road_city_ab += (try {
            getcityFromAdcode(qm_adcode_arr(start_index.toInt), city_map_info)
          } catch {
            case e: Exception => "-"
          }) + "_" + (try {
            getcityFromAdcode(qm_adcode_arr(end_index.toInt), city_map_info)
          } catch {
            case e: Exception => "-"
          })
          var dist = 0.0
          for (j <- start_index.toInt to end_index.toInt) {
            dist += (try {
              qm_len_arr(j).toDouble
            } catch {
              case e: Exception => 0.0
            })
          }
          road_dist_ab += (dist / 1000).formatted("%.2f")
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    if (road_swid_ab == null && road_swid_ab.size == 0) road_swid_ab += ""
    if (road_adcode_ab == null && road_adcode_ab.size == 0) road_adcode_ab += ""
    if (road_city_ab == null && road_city_ab.size == 0) road_city_ab += ""
    if (road_dist_ab == null && road_dist_ab.size == 0) road_dist_ab += ""
    road_swid_ab.mkString("|") + "&" + road_adcode_ab.mkString("|") + "&" + road_city_ab.mkString("|") + "&" + road_dist_ab.mkString("|")
  })

  def getcityFromAdcode(adcode: String, city_map_info: mutable.HashMap[String, String]): String = {
    var road_city = ""
    val four_sp = Seq("81", "31", "11", "50", "12")
    val six_sp = Seq("429004", "659001", "654003", "632801")
    //获取城市信息
    try {
      if (adcode.trim != "") {
        val one_adcode_2 = adcode.substring(0, 2)
        val one_adcode_4 = adcode.substring(0, 4)
        var adcode_n = ""
        if (four_sp.contains(one_adcode_2)) {
          adcode_n += (one_adcode_2 + "" + "0000")
        } else if (six_sp.contains(adcode)) {
          adcode_n += adcode
        } else {
          adcode_n += (one_adcode_4 + "" + "00")
        }
        road_city = city_map_info.getOrElse(adcode_n, "-")
      }
    } catch {
      case e: Exception => "" + e
    }
    road_city
  }

  def getRadNameUdf = udf((start_index: String, end_index: String, qm_name: String, qm_roadclass: String) => {
    val road_name_merge_ab = new ArrayBuffer[String]()
    val road_class_ab = new ArrayBuffer[String]()
    val road_index_ab = new ArrayBuffer[String]()
    val road_rank_ab = new ArrayBuffer[String]()
    if (strNotNull(start_index) && strNotNull(end_index) && strNotNull(qm_name) && strNotNull(qm_roadclass)) {
      try {
        val qm_name_arr = qm_name.split("\\|")
        val qm_roadclass_arr = qm_roadclass.split("\\|")
        val si = start_index.toInt
        val ei = end_index.toInt
        var cnt = si
        for (i <- cnt to ei if i == cnt) {
          val roadcs_pre = qm_roadclass_arr(i)
          if (roadcs_pre != "0") { //非高速
            val roadname_ab_no_hy = new ArrayBuffer[String]()
            val roadindex_ab_no_hy = new ArrayBuffer[String]()
            roadname_ab_no_hy += qm_name_arr(i)
            roadindex_ab_no_hy += i.toString
            breakable {
              for (j <- cnt + 1 to ei) {
                val roadcs_next = qm_roadclass_arr(j)
                if (roadcs_pre == roadcs_next) {
                  if (qm_name_arr(j) != qm_name_arr(j - 1)) {
                    roadname_ab_no_hy += qm_name_arr(j)
                  }
                } else {
                  cnt = j
                  roadindex_ab_no_hy += (j - 1).toString
                  break()
                }
                if (j == ei) {
                  roadindex_ab_no_hy += j.toString
                }
              }
            }
            if (i == ei) {
              roadindex_ab_no_hy += i.toString
            }
            road_name_merge_ab += roadname_ab_no_hy.mkString("_")
            road_class_ab += "0"
            road_index_ab += roadindex_ab_no_hy.mkString("_")
          }
          if (roadcs_pre == "0") { //高速
            val roadindex_ab_hy = new ArrayBuffer[String]()
            val roadname_ab_hy = qm_name_arr(i)
            roadindex_ab_hy += i.toString
            breakable {
              for (j <- cnt + 1 to ei) {
                val roadcs_next = qm_roadclass_arr(j)
                if (roadcs_pre == roadcs_next) {
                  if (qm_name_arr(j) != qm_name_arr(j - 1)) {
                    cnt = j
                    roadindex_ab_hy += (j - 1).toString
                    break()
                  }
                } else {
                  cnt = j
                  roadindex_ab_hy += (j - 1).toString
                  break()
                }
                if (j == ei) {
                  roadindex_ab_hy += j.toString
                }
              }
            }
            if (i == ei) {
              roadindex_ab_hy += i.toString
            }
            road_class_ab += "1"
            road_name_merge_ab += roadname_ab_hy
            road_index_ab += roadindex_ab_hy.mkString("_")
          }
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    if (road_name_merge_ab != null && road_name_merge_ab.size > 0) {
      for (i <- 0 until road_name_merge_ab.length) {
        road_rank_ab += i.toString
      }
    }
    road_name_merge_ab.mkString("|") + "&" + road_class_ab.mkString("|") + "&" + road_index_ab.mkString("|") + "&" + road_name_merge_ab.length.toString + "&" + road_rank_ab.mkString("|")
  })


  /**
   * 接口获取adcode信息
   *
   * @param swid_diff
   * @param date
   * @return
   */
  def postPointInter(swid_diff: String, date: String): String = {
    val qm_adcode_ab = new ArrayBuffer[String]()
    val params = s"""{"ak": "2e4b2a16ef2a4427917f366fb22febb5","useEstimateTime": 1,"opt":"sf4","simple_distance":0,"test": 0,"stype": 0,"etype": 2,"passport": "100000","mode": 2,"speed": 1,"rtic":0,"rtic_dur":0,"output":"json","Toll": 1,"point_src" : 1,"swid":"$swid_diff","date": "$date"}""".stripMargin //②那个qm_point接口的入参， "test": 1 改为 "test": 0 ，可以降低调接口的失败率；
    try {
      //      val hw_str = HttpInvokeUtil.sendPost(HTTP_XY_COORDS_P, params, 3, 2)
      val hw_str = HttpInvokeUtil.sendPostH(HTTP_XY_COORDS_P, params, 3, 2, "2e4b2a16ef2a4427917f366fb22febb5", "")
      logger.error("》》》》》》》》》》》接口正常调用中》》》》》》》》")
      val hw_str_json = JSON.parseObject(hw_str)
      val route = hw_str_json.getJSONObject("route")
      if (route != null) {
        val paths_arr = route.getJSONArray("paths")
        if (paths_arr != null && paths_arr.size() > 0) {
          for (i <- 0 until paths_arr.size()) {
            val steps_arr = paths_arr.getJSONObject(i).getJSONArray("steps")
            if (steps_arr != null && steps_arr.size() > 0) {
              for (j <- 0 until steps_arr.size()) {
                val links_arr = steps_arr.getJSONObject(j).getJSONArray("links")
                if (links_arr != null && links_arr.size() > 0) {
                  for (k <- 0 until links_arr.size()) {
                    val adcode = links_arr.getJSONObject(k).getString("adcode")
                    qm_adcode_ab += (if (adcode != null && adcode.trim != "") adcode else "-")
                  }
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    qm_adcode_ab.mkString("|")
  }


  def postLssRectify(his_tracks: String): (String, String, String, String) = {
    val time_ab = new ArrayBuffer[String]()
    val swid_ab = new ArrayBuffer[String]()
    val roadname_ab = new ArrayBuffer[String]()
    val roadclass_ab = new ArrayBuffer[String]()

    val params = s"""{"keeptype": 1, "roadinfo": 1, "retflag": 7, "addpoint": 1, "only_primary": 0, "compensate": 1, "compensate_time": 0, "mat_ratio": 1, "poiinfo": 1, "ak": "7664c42850b74da6b880a6ecf0ef2077", "process": {"stay_time": 30, "stay_radius": 100},"tracks":$his_tracks}""".stripMargin
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_LSS_RECTIFY_P, params, 3, 2)
      logger.error("接口正常调用中,传入参数为>>" + params)
      logger.error("纠偏接口返回的结果>>" + hw_str)
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val tracks = result.getJSONArray("tracks")
        val stay_points = result.getJSONArray("stay_points")
        val index_ab = new ArrayBuffer[Integer]()
        if (stay_points != null && stay_points.size() > 0) {
          for (i <- 0 until stay_points.size()) {
            val start_index = stay_points.getJSONObject(i).getInteger("start_index")
            val end_index = stay_points.getJSONObject(i).getInteger("end_index")
            index_ab += start_index
            index_ab += end_index
          }
        }

        if (tracks != null && tracks.size() > 0) {
          for (j <- 0 until index_ab.size if j % 2 == 0) {
            val start_tm = tracks.getJSONObject(index_ab(j)).getString("time")
            val end_tm = tracks.getJSONObject(index_ab(j + 1)).getString("time")
            if (end_tm.toLong - start_tm.toLong >= 600) {
              time_ab += tranTstampToTime(sdf1, start_tm) + "_" + tranTstampToTime(sdf1, end_tm)
              val swid = tracks.getJSONObject(index_ab(j)).getString("SWID") match {
                case x if x != null && x.trim != "" => tracks.getJSONObject(index_ab(j)).getString("SWID")
                case _ => "-"
              }
              val roadname = tracks.getJSONObject(index_ab(j)).getString("roadname") match {
                case x if x != null && x.trim != "" => tracks.getJSONObject(index_ab(j)).getString("roadname")
                case _ => "-"
              }
              val roadclass = tracks.getJSONObject(index_ab(j)).getString("roadclass") match {
                case x if x != null && x.trim != "" => tracks.getJSONObject(index_ab(j)).getString("roadclass")
                case _ => "999"
              }
              swid_ab += swid
              roadname_ab += roadname
              roadclass_ab += roadclass
            }
          }
        }
      }
    } catch {
      case e: Exception => " " + e
    }
    (time_ab.mkString("|"), swid_ab.mkString("|"), roadname_ab.mkString("|"), roadclass_ab.mkString("|"))
  }

  def postTrackqueryIntegrate(un: String, begindatetime_post: String, enddatetime_post: String): String = {
    val track_list = new ArrayBuffer[JSONObject]()
    val params = s"""{"un":"$un", "beginDateTime":"$begindatetime_post","endDateTime":"$enddatetime_post","type":"0","ak":"7664c42850b74da6b880a6ecf0ef2077","rectify":"false"}""".stripMargin
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_TRACK_INTEGRATION_REP_P, params, 3, 2)
      logger.error("接口正常调用中,传入参数为>>" + params)
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val data = result.getJSONObject("data")
        if (data != null) {
          val track = data.getJSONArray("track")
          if (track != null && track.size() > 0) {
            for (i <- 0 until track.size()) {
              val tracks_json = new JSONObject()
              val ac = track.getJSONObject(i).getString("ac") match {
                case x if x != null => x.toInt
                case _ => 0
              }
              val be = track.getJSONObject(i).getString("be") match {
                case x if x != null => x.toDouble
                case _ => ""
              }
              val sp = track.getJSONObject(i).getString("sp") match {
                case x if x != null => x.toDouble
                case _ => 0.0
              }
              val tm = track.getJSONObject(i).getString("tm") match {
                case x if x != null => x.toInt
                case _ => 0
              }
              val zx = track.getJSONObject(i).getString("zx") match {
                case x if x != null => x.toDouble
                case _ => 0.0
              }
              val zy = track.getJSONObject(i).getString("zy") match {
                case x if x != null => x.toDouble
                case _ => 0.0
              }
              tracks_json.put("accuracy", ac)
              tracks_json.put("azimuth", be)
              tracks_json.put("index", i)
              tracks_json.put("speed", sp)
              tracks_json.put("time", tm)
              tracks_json.put("type", 1)
              tracks_json.put("x", zx)
              tracks_json.put("y", zy)
              track_list += tracks_json
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    "[" + track_list.mkString(",") + "]"
  }


  def gettlRoad = udf((tl_road: String) => {
    val res = new ArrayBuffer[String]()
    val tl_road_arr = tl_road.split("\\|", -1)

    for (i <- 0 until tl_road_arr.size) {
      if (tl_road_arr(i).trim == "") res += "-"
      if (tl_road_arr(i).trim != "") res += tl_road_arr(i).trim
    }
    res.mkString("|")
  })

  def getHighwayDuration = udf((highway_start_time: String, highway_end_time: String) => {
    val tl_end = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highway_end_time)
    val tl_start = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highway_start_time)

    ((tl_end - tl_start) / 60.0).formatted("%.2f")
  })

  def extractCodeUDF = udf((dept: String) => {
    var res = ""
    try {
      res = dept.replaceAll("([a-zA-Z]+)", "-").split("-")(0)
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  def getDisHighspeedStand = udf((dis_highspeed: String) => {
    val dis_db = try {
      dis_highspeed.toDouble.abs
    } catch {
      case e: Exception => 0.0
    }
    val dis_highspeed_block = dis_db match {
      case x if x >= 0 && x < 30 => "[0,30)"
      case x if x >= 30 && x < 60 => "[30,60)"
      case x if x >= 60 && x < 65 => "[60,65)"
      case x if x >= 65 && x < 70 => "[65,70)"
      case x if x >= 70 && x < 75 => "[70,75)"
      case x if x >= 75 && x < 80 => "[75,80)"
      case x if x >= 80 && x < 85 => "[80,85)"
      case x if x >= 85 && x < 90 => "[85,90)"
      case x if x >= 90 && x <= 100 => "[90,100]"
      case x if x > 100 => "(100,100+)"
    }
    dis_highspeed_block
  })


  def getTimeIntersection222UDF = udf((tl_road: String, tl_roadclass: String, tl_time_periods: String, highway_start_time: String, highway_end_time: String) => {
    var tm: Long = 0l
    try {
      val highway_stm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highway_start_time)
      val highway_etm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highway_end_time)
      val tl_road_arr = tl_road.split("\\|")
      val tl_roadclass_arr = tl_roadclass.split("\\|")
      val tl_time_periods_arr = tl_time_periods.split("\\|")
      for (i <- 0 until tl_road_arr.size) {
        if (tl_road_arr(i).contains("服务区") || tl_road_arr(i).contains("停车区") || tl_roadclass_arr(i).toInt != 0) {
          if (tl_time_periods_arr(i) != "-") {
            val multi_per_arr = tl_time_periods_arr(i).split(",")
            for (j <- 0 until multi_per_arr.size) {
              val start_tm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", multi_per_arr(j).split("_")(0))
              val end_tm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", multi_per_arr(j).split("_")(1))
              tm += twoGroupinterLong(highway_stm, highway_etm, start_tm, end_tm)
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (tm / 60.0).formatted("%.2f")
  })

  def getTimeIntersection111UDF = udf((tl_time_periods: String, highway_start_time: String, highway_end_time: String) => {
    var tm: Long = 0l
    try {
      val highway_stm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highway_start_time)
      val highway_etm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highway_end_time)
      val periods_arr = tl_time_periods.split("\\|") //2022-11-01 09:22:23_2022-11-01 09:51:20|2022-11-01 10:22:23_2022-11-01 10:51:20
      for (i <- 0 until periods_arr.size) {
        if (periods_arr(i) != "-") {
          val multi_per_arr = periods_arr(i).split(",")
          for (j <- 0 until multi_per_arr.size) {
            val start_tm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", multi_per_arr(j).split("_")(0))
            val end_tm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", multi_per_arr(j).split("_")(1))
            tm += twoGroupinterLong(highway_stm, highway_etm, start_tm, end_tm)
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (tm / 60.0).formatted("%.2f")
  })


  def getHighway_ac_dist = udf((qm_roadclass: String, qm_len: String) => {
    var len: Double = 0.0
    try {
      val qm_roadclass_arr = qm_roadclass.split("\\|")
      val qm_len_arr = qm_len.split("\\|")
      for (i <- 0 until qm_roadclass_arr.length) {
        if (qm_roadclass_arr(i) == "0") {
          len += (try {
            qm_len_arr(i).toDouble
          } catch {
            case e: Exception => 0.0
          })
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (len / 1000).formatted("%.2f")
  })

  def getHighwayDist = udf((qm_len: String, index3: String, index4: String) => {
    var len: Double = 0.0
    try {
      val qm_len_arr = qm_len.split("\\|")
      for (i <- 0 until (qm_len_arr.size) if i >= index3.toInt && i <= index4.toInt) {
        len += (try {
          qm_len_arr(i).toDouble
        } catch {
          case e: Exception => 0.0
        })
      }
    } catch {
      case e: Exception => "" + e
    }
    (len / 1000).formatted("%.2f")
  })

  def getWithIndex(flag: String) = udf((qm_swid: String, index: String) => {
    var res = ""
    try {
      val qm_swid_arr = qm_swid.split("\\|")
      if (flag == "swid" || flag == "name") res = qm_swid_arr(index.toInt)
      if (flag == "time") res = tranTstampToTime(sdf1, qm_swid_arr(index.toInt))
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  def gethighway = udf((qm_name: String, index1: String, index2: String) => {
    val highway_ab = new ArrayBuffer[String]()
    try {
      val qm_name_arr = qm_name.split("\\|")
      for (i <- 0 until qm_name_arr.size if i >= index1.toInt && i <= index2.toInt) {
        if (!highway_ab.contains(qm_name_arr(i)) && qm_name_arr(i) != "-") highway_ab += qm_name_arr(i)
      }
    } catch {
      case e: Exception => "" + e
    }
    highway_ab.mkString("|")
  })

  def getIndex(flag: String) = udf((qm_roadclass: String, other_col: String) => {
    var index = ""
    try {
      val qm_roadclass_arr = qm_roadclass.split("\\|")
      if (flag == "first") {
        breakable {
          for (i <- 0 until qm_roadclass_arr.length) {
            if (qm_roadclass_arr(i) == other_col) {
              index = i.toString
              break()
            }
          }
        }
      }
      if (flag == "last") {
        breakable {
          for (i <- (0 until qm_roadclass_arr.length).reverse) {
            if (qm_roadclass_arr(i) == other_col) {
              index = i.toString
              break()
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    index
  })

  def splitUnion = udf((t_links_union: String) => {
    val qm_swid_ab = new ArrayBuffer[String]()
    val qm_name_ab = new ArrayBuffer[String]()
    val qm_roadclass_ab = new ArrayBuffer[String]()
    val qm_len_ab = new ArrayBuffer[String]()
    try {
      val t_links_arr = t_links_union.split("\\|")
      for (i <- 0 until t_links_arr.length) {
        val single = t_links_arr(i).split(",")
        for (j <- 0 until single.length if Seq(0, 2, 4, 7).contains(j)) {
          val independ = if (single(j).trim == "") "-" else single(j)
          if (j == 0) qm_swid_ab += independ
          if (j == 2) qm_name_ab += independ
          if (j == 4) qm_roadclass_ab += independ
          if (j == 7) qm_len_ab += independ
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    qm_swid_ab.mkString("|") + "&" + qm_name_ab.mkString("|") + "&" + qm_roadclass_ab.mkString("|") + "&" + qm_len_ab.mkString("|")
  })

  /**
   * 去重
   *
   * @return
   */
  def diffUdf = udf((diff_str: String) => {
    val diff_str_arr = diff_str.split("\\|").filter(_ != "").toSet
    diff_str_arr.mkString("|")
  })

  def getFirstOrLastOrSumUDF(flag: String) = udf((choose_str: String) => {
    var res_str = ""
    try {
      val choose_str_arr = choose_str.split("\\|")
      if (flag == "first") res_str = choose_str_arr(0)
      if (flag == "last") res_str = choose_str_arr(choose_str_arr.size - 1)
      if (flag == "sum") {
        res_str = choose_str_arr.map(x => {
          try {
            x.toDouble
          } catch {
            case e: Exception => 0.0
          }
        }).sum.toString
      }
    } catch {
      case e: Exception => "" + e
    }
    res_str
  })

  def resortColsFun(spark: SparkSession, part_cols_str: Seq[String]): Seq[Column] = {
    import spark.implicits._
    val agg_cols_str = part_cols_str.map(_ + "_n")
    val agg_cols = part_cols_str.map(col)
    val resort_back_cols = agg_cols.map(x => sortFieldwithSpec("&")('num, x))
    ColumnUtil.renameColumn(resort_back_cols, agg_cols_str)
  }

  def aggSequenceCols(part_cols_str: Seq[String]): Seq[Column] = {
    val agg_cols_str = part_cols_str :+ "num"
    val agg_cols = (part_cols_str :+ "num").map(col)
    val no_seq_cols = agg_cols.map(x => when(x.isNotNull && trim(x) =!= "", x).otherwise(lit("-"))).map(x => concat_ws("&", collect_list(x)))
    ColumnUtil.renameColumn(no_seq_cols, agg_cols_str)
  }

  /**
   * 外部读取csv文件，获取全国城市流向信息
   *
   * @param spark
   * @return
   */
  def getCsv2DF(spark: SparkSession): (Seq[String], mutable.HashMap[String, String], DataFrame) = {
    val city_adcode_map = new mutable.HashMap[String, String]()
    val inputPath = "/user/01418539/upload/file/eta/adcode.csv"
    val o_whole_city_df = spark.read
      .option("header", "false")
      .option("delimiter", "\\t")
      .option("encoding", "utf-8") //utf-8 gbk
      .option("inferSchema", true.toString)
      .csv(inputPath)
      .toDF("area_name", "city_name", "adcode", "city_code", "descrip")
      .groupBy("city_name", "adcode").agg(lit(true))
      .select("city_name", "adcode")
      .persist()

    o_whole_city_df.toLocalIterator.foreach(row => {
      val city_name = row.getAs[String]("city_name")
      val adcode = row.getAs[String]("adcode")
      city_adcode_map.put(adcode, city_name)
    })
    val city_map_info = o_whole_city_df.select("adcode").collect().map(_.getString(0)).toSet.toSeq
    (city_map_info, city_adcode_map, o_whole_city_df)
  }

}
