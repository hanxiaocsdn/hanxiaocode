package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder

/**
 * @task_id: 576303
 * @description: 告警数据--日结表 dm_gis.insurance_risk_alert_daily_fix
 * @demander: 01402323 罗祯
 * @author 01418539 caojia
 * @date 2022/11/21 10:47
 */
object VehicleRiskAlertDayExcepFix extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processDayExcep(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processDayExcep(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    //DMS告警数--- ADAS告警量
    val dms_cnt_cond = when('alarm_name_sta.isin("打电话", "分心驾驶", "分心驾驶", "分心驾驶", "驾驶员变更", "驾驶员变更", "驾驶员异常", "摄像头遮挡", "摄像头遮挡", "摄像头遮挡", "生理疲劳", "生理疲劳", "生理疲劳"), 1).otherwise(0)
    val adas_cnt_cond = when('alarm_name_sta.isin("车道偏离", "车距过近", "行人碰撞", "前车碰撞"), 1).otherwise(0)
    val exe_two_cnt_cond = when('alarm_name_sta.isin("摄像头遮挡", "驾驶员异常"), 1).otherwise(0)
    val abn_alarm_cond = when('dms_cnt > 0 && 'exe_two_cnt.cast("double") / 'dms_cnt >= 0.95 && 'exe_two_cnt >= 5, "1").when('dms_cnt === 0 && 'adas_cnt === 0, "2")
    val susp_abn_alarm_cond = when('total_links_dist.cast("double") > 200000 && 'dms_cnt === 0 && 'adas_cnt > 0, "1")
      .when('total_links_dist.cast("double") > 50000 && 'dms_cnt > 0 && 'adas_cnt === 0, "2")
    //4.疑似ADAS告警异常：日行驶里程>50km,DMS告警量>0和ADAS告警量=0
    val org_risk_mile_df = getMileageData(spark, start_day, end_day)
      .withColumn("dms_cnt", dms_cnt_cond)
      .withColumn("adas_cnt", adas_cnt_cond)
      .withColumn("exe_two_cnt", exe_two_cnt_cond)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val org_cols = org_risk_mile_df.schema.map(x => col(x.name))

    val s1_1_df = org_risk_mile_df.select("imei","car_no", "zy_type", "alarm_name_sta", "dms_cnt", "adas_cnt", "exe_two_cnt", "total_links_dist", "inc_day").filter('alarm_name_sta =!= "all")
      .groupBy("car_no", "inc_day")
      .agg(
        last("zy_type") as "zy_type",
        last("imei") as "imei",
        sum("dms_cnt") as "dms_cnt",
        sum("adas_cnt") as "adas_cnt",
        sum("exe_two_cnt") as "exe_two_cnt",
        first("total_links_dist") as "total_links_dist"
      )
      .withColumn("abn_alarm", abn_alarm_cond)
      .withColumn("susp_abn_alarm", susp_abn_alarm_cond)
      .select("car_no","zy_type","abn_alarm","susp_abn_alarm","inc_day")

    val s1_2_df = org_risk_mile_df.filter('alarm_name_sta =!= "all").select("zy_type", "alarm_name_sta","alarm_sum_cnt", "inc_day")
      .withColumn("num_cnt", lit(1))
      .groupBy("zy_type", "alarm_name_sta", "inc_day")
      .agg(stddev_pop("alarm_sum_cnt") as "stddev_alarm",
        sum("alarm_name_sta") as "alarm_name_sta_cnt",
        sum("num_cnt") as "num_cnt")
      .withColumn("avg_alarm_cnt", 'alarm_name_sta_cnt.cast("double") / 'num_cnt)
      .withColumn("max_ceiling", 'avg_alarm_cnt + lit(3) * 'stddev_alarm)
      .select("zy_type", "alarm_name_sta", "max_ceiling", "inc_day")

    val s2_1_df = org_risk_mile_df.filter('alarm_name_sta =!= "all")
      .join(s1_2_df, Seq("zy_type", "alarm_name_sta", "inc_day"), "left")
      .withColumn("alarm_sum_cnt", when('alarm_sum_cnt <= 'alarm_name_sta, 'alarm_sum_cnt).otherwise('alarm_name_sta))
      .select(org_cols: _*)

    val s2_2_df = org_risk_mile_df.filter('alarm_name_sta === "all").select(org_cols: _*)
    val res_df_cols = spark.sql("""select * from dm_gis.insurance_risk_alert_daily_fix limit 0""").schema.map(x => col(x.name))

    val res_df = s2_1_df.union(s2_2_df).drop("zy_type")
      .join(s1_1_df, Seq("car_no", "inc_day"), "left")
      .select(res_df_cols: _*)

    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.insurance_risk_alert_daily_fix")
    org_risk_mile_df.unpersist()
  }

  def getMileageData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    val o_risk_df = spark.sql(s"""select * from dm_gis.insurance_risk_alert_daily where inc_day between '$start_day' and '$end_day' and car_no is not null and trim(car_no) !=''""")
    val o_dfist_df = spark.sql(s"""select lpn car_no,total_links_dist,inc_day from dm_gis.insurance_model_duration_dist_daily_fix where inc_day between '$start_day' and '$end_day' and lpn is not null and trim(lpn) !='' group by lpn,total_links_dist,inc_day""")
    o_risk_df.join(o_dfist_df, Seq("car_no", "inc_day"), "left")
  }
}
