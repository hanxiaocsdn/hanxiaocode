package com.sf.app.eta

import com.sf.app.navi.CreateMysqlTable
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.{getFJTDevMysqlConnect, processBDPMysqlCreateTable, upsertToFJTDevMysqlwithAddID}
import utils.SparkBuilder

import java.sql.Connection

/**
 * @task_id: 902188 (前置加工主类入口：EfficientEscortConvoy)
 * @description:同步护航2张表至mysql: shixiao_huhang_ribao_chixushichang shixiao_huhang_ribao_wandianshichang
 * @demander: 左佳怡 01403789
 * @author 01418539 caojia
 * @date 2023/11/14 13:57
 */
object LoadEtaHuhangHive2Mysql extends DataSourceCommon {
  var conn: Connection = null

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val tableName = args(0)
    val start_day = args(1)
    val end_day = args(2)
    val flag = args(3).toInt
    val tables: Array[String] = tableName.replaceAll("'", "").split(",")
    createOrInsert(spark, tables, start_day, end_day, flag)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def createOrInsert(spark: SparkSession, tables: Array[String], start_day: String, end_day: String, flag: Int): Unit = {
    val mysql_tables = CreateMysqlTable.getMysqlcreateTable(tables)
    conn = getFJTDevMysqlConnect()
    var createSql = ""
    for (table <- tables) {
      if (flag == 0) {
        createSql = mysql_tables.get(table)
        processBDPMysqlCreateTable(table, createSql, conn)
      } else {
        val bdp_df = spark.sql(s"""select * from dm_gis.$table where inc_day between '$start_day' and '$end_day'""".stripMargin)
        upsertToFJTDevMysqlwithAddID(conn, bdp_df, "bdp", table.toUpperCase, start_day, end_day)
      }
    }
  }

}
