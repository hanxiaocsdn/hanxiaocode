package com.sf.app.eta.realtime

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.utils.JSONUtils

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION} 时效定则-护航模块
 @create 2023/4/10
*/


object ParseVmsScala {

  /**
   * 调用历史轨迹
   *
   * @param hisRes
   * @param x
   * @return
   */

  def parseHisResponse(hisRes: JSONObject) = {
    val status = hisRes.getString("status")
    val his_tracks = new JSONArray()

    val result = hisRes.getJSONObject("result")
    val data = result.getJSONObject("data")
    val tracks = data.getJSONArray("track")

    for (i <- (0 until tracks.size()) if tracks.size() > 0) {
      val jo = new JSONObject()
      val track = tracks.getJSONObject(i)
      val ac = JSONUtils.getJsonValueInt(track, "ac", 0)
      val be = JSONUtils.getJsonValueDouble(track, "be", 0)
      val index = i
      val sp = JSONUtils.getJsonValueDouble(track, "sp", 0)
      val time = JSONUtils.getJsonValueLong(track, "tm", 0)
      val zx = JSONUtils.getJsonValueDouble(track, "zx", 0)
      val zy = JSONUtils.getJsonValueDouble(track, "zy", 0)

      jo.put("accuracy", ac)
      jo.put("azimuth", be)
      jo.put("index", index)
      jo.put("speed", sp)
      jo.put("time", time)
      jo.put("type", 1)
      jo.put("x", zx)
      jo.put("y", zy)

      his_tracks.add(jo)

    }

    his_tracks
  }


  /**
   * 拼接外源轨迹与调用纠偏接口
   *
   * @param x
   * @return
   */

  def calFixInterface2(tracks: JSONArray, continueTm2: String, fixUrl: String): JSONObject = {

    val joPost = new JSONObject()

    joPost.put("ak", "ef789d00926d46cdae8fc721608557ad")
    joPost.put("keeptype", "1")
    joPost.put("vehicle", 5)
    joPost.put("retflag", 7)
    joPost.put("addpoint", 1)
    joPost.put("roadinfo", 1)
    joPost.put("poiinfo", 1)
    joPost.put("only_primary", 0)
    joPost.put("tracks", tracks)
    joPost.put("slowinfo", 1)

    val process = new JSONObject()
    process.put("stay_time", 300)
    process.put("stay_radius", 50)
    joPost.put("process", process)

    //    val fixResponse = HttpUtils.doPost(fixUrl, joPost)
    val fixResponse = ""

    val fixResponseParse = try {
      JSON.parseObject(fixResponse)
    } catch {
      case e: Exception => new JSONObject()
    }
    val json = try {
      parseFixResponse(continueTm2, fixResponseParse)
    } catch {
      case e: Exception => new JSONObject()
    }

    json
  }


  def calFixInterface2Test(tracks: JSONArray, continueTm2: String, fixUrl: String): JSONObject = {

    val joPost = new JSONObject()

    joPost.put("ak", "ef789d00926d46cdae8fc721608557ad")
    joPost.put("keeptype", "1")
    joPost.put("vehicle", 5)
    joPost.put("retflag", 7)
    joPost.put("addpoint", 1)
    joPost.put("roadinfo", 1)
    joPost.put("poiinfo", 1)
    joPost.put("only_primary", 0)
    joPost.put("tracks", tracks)
    joPost.put("slowinfo", 1)


    val process = new JSONObject()
    process.put("stay_time", 300)
    process.put("stay_radius", 50)
    joPost.put("process", process)

    //    val fixResponse = HttpUtils.doPost(fixUrl, joPost)
    val fixResponse = ""


    val fixResponseParse = try {
      JSON.parseObject(fixResponse)
    } catch {
      case e: Exception => new JSONObject()
    }
    val json = try {
      parseFixResponse(continueTm2, fixResponseParse)
    } catch {
      case e: Exception => new JSONObject()
    }

    json
  }


  /**
   * 拼接外源轨迹与调用纠偏接口
   *
   * @param x
   * @return
   */

  def calExpInterface(jo: JSONObject, concatTime: String, fixUrl: String) = {


    val joPost = new JSONObject()
    val jp_swid = jo.getString("jp_swid").split("\\|").distinct.mkString(",")

    joPost.put("ak", "dc894b4a3c7444b4a3505315d00b87ad")
    joPost.put("swId", 1)
    joPost.put("links", jp_swid)
    joPost.put("type", 1)
    joPost.put("time", concatTime)
    joPost.put("output", "json")
    joPost.put("gzip", 0)
    joPost.put("roadAttrToken", "6134FAA5B6B6ED55E87EA116466734ED")

    //    val fixResponse = HttpUtils.doPost(fixUrl, joPost)
    val fixResponse = ""

    //    val fixResponseParse = try {JSON.parseObject(fixResponse)} catch {case e:Exception => new JSONObject()}
    //    val json = try {parseFixResponse(fixResponseParse)} catch {case e:Exception => new JSONObject()}

    (jp_swid, fixResponse)
  }


  /**
   * 拼接外源轨迹与调用纠偏接口
   *
   * @param x
   * @return
   */

  def calExpInterfaceTest(jo: JSONObject, concatTime: String, fixUrl: String) = {


    val joPost = new JSONObject()
    val jp_swid = jo.getString("jp_swid").split("\\|").distinct.mkString(",")

    //    val jp_swid2 = jo.getString("jp_swid")
    //    val jp_time = jo.getString("jp_time")
    //    val swidList = jp_swid2.split("\\|")
    //    val timeList = jp_time.split("\\|")
    //    val pairs = swidList.zip(timeList)
    //    val indexedDistinctPairs = pairs.zipWithIndex.map{ case ((swid, time), index) => (swid, time,index) }.sortBy(_._3).filter(x => {!"0".equals(x._1)})
    //    val sortTuple = indexedDistinctPairs.groupBy(_._1).map(x => x._2.take(1)).flatten.toList.sortBy(_._3)
    //    val swidArray = sortTuple.map(_._1).mkString("|")
    //    val timeArray = sortTuple.map(_._2).mkString("|")


    joPost.put("ak", "12fe501477bc44e49cbbe61a6c1d8866")
    joPost.put("swId", 1)
    joPost.put("links", jp_swid)
    joPost.put("type", 1)
    joPost.put("time", concatTime)
    joPost.put("output", "json")
    joPost.put("gzip", 0)
    joPost.put("roadAttrToken", "000011112222333344445555666677778888")

    //    val fixResponse = HttpUtils.doPost(fixUrl, joPost)
    val fixResponse = ""

    //    val fixResponseParse = try {JSON.parseObject(fixResponse)} catch {case e:Exception => new JSONObject()}
    //    val json = try {parseFixResponse(fixResponseParse)} catch {case e:Exception => new JSONObject()}

    (jp_swid, fixResponse)
  }

  implicit class StringExtensions(str: String) {
    def toIntOrElse(default: Int): Int = {
      try {
        str.toInt
      } catch {
        case _: NumberFormatException => default
      }
    }
  }

  /**
   * 解析tmc接口返回结果
   *
   * @param fixResponseParse
   */

  def parseTmcResponse(x: JSONObject, gd_str: String, event_map: mutable.Map[String, (String, String)]): JSONObject = {
    val swid_len_arr, swid_gd_len_arr, swid_gd_len_arr2, swid_gd_arr, swid_gd_arr2, status_gd_arr, speed_gd_arr, events_code_arr, events_s, events_l, event_swid_arr, event_id_arr, event_content_arr = new ListBuffer[String]()
    var swid_len, swid_gd_len, swid_gd, status_gd, speed_gd = ""
    var limit_c, limit_t, reason_c, reason_t, link_id, event_id, event_content = ""
    var speed_avg_gd, gd_len: Double = 0.0

    try {
      val gd_info_json = JSON.parseObject(gd_str)
      val gd_tracks = gd_info_json.getJSONArray("tracks")

      for (i <- 0 until gd_tracks.size()) {
        val flow = gd_tracks.getJSONObject(i).getJSONArray("flow")
        val events = gd_tracks.getJSONObject(i).getJSONArray("events")
        if (flow != null && flow.size() > 0 && flow.toJSONString.replaceAll(" ", "") != "[]") {
          val link_id = gd_tracks.getJSONObject(i).getString("link_id")
          swid_gd_arr += link_id
          status_gd_arr += flow.getJSONObject(0).getString("status") //todo 需要确认flow中 只有单组还是多组
          speed_gd_arr += flow.getJSONObject(0).getString("speed")
          val jp_swid = x.getString("jp_swid")
          val jp_length = x.getString("jp_length")
          val link_id_cnt = getSwidAndCount(jp_swid, jp_length, link_id)
          if (link_id_cnt.trim != "") swid_gd_len_arr += link_id_cnt else swid_gd_len_arr += "0"
        }
        if (events != null && events.size() > 0) {
          for (k <- 0 until events.size()) {
            limit_c = events.getJSONObject(k).getString("limit_c")
            limit_t = events.getJSONObject(k).getString("limit_t")
            reason_c = events.getJSONObject(k).getString("reason_c")
            reason_t = events.getJSONObject(k).getString("reason_t")

            val link_id_tmp = events.getJSONObject(k).getString("link_id")
            val event_id_tmp = events.getJSONObject(k).getString("event_id")
            val event_content_tmp = events.getJSONObject(k).getString("content")

            link_id = if (strNotNull(link_id_tmp)) link_id_tmp else ""
            event_id = if (strNotNull(event_id_tmp)) event_id_tmp else ""
            event_content = if (strNotNull(event_content_tmp)) event_content_tmp.replaceAll("\\n|\\r|\\t", "") else ""

            val event_info = limit_c + "," + limit_t + "," + reason_c + "," + reason_t
            if (!event_id_arr.contains(event_id)) { //todo fix 20230926 去重字段 为event_id
              events_code_arr += event_info
              events_s += event_map.getOrElse(event_info, ("", ""))._1
              events_l += event_map.getOrElse(event_info, ("", ""))._2
              event_swid_arr += link_id
              event_id_arr += event_id
              event_content_arr += event_content
            }
          }
        }
      }
    }
    catch {
      case e: Exception => ""
    }

    swid_len = swid_len_arr.mkString("|")
    swid_gd = swid_gd_arr.mkString("|")
    status_gd = status_gd_arr.mkString("|")
    speed_gd = speed_gd_arr.mkString("|")


    val swidList = swid_gd.split("\\|")
    val speedList = speed_gd.split("\\|")
    val pairs = swidList.zip(speedList)
    val indexedDistinctPairs = pairs.zipWithIndex.map { case ((swid, speed), index) => (swid, speed, index) }.sortBy(_._3)
    val sortTuple = indexedDistinctPairs.groupBy(_._1).map(x => x._2.minBy(_._2.toIntOrElse(9999))).toList.sortBy(_._3)

    val swid_gd2 = sortTuple.map(_._1)
    val speed_gd2 = sortTuple.map(_._2)


    for (i <- 0 until swid_gd2.length) {
      val link_id = swid_gd2(i)
      val jp_swid = x.getString("jp_swid")
      val jp_length = x.getString("jp_length")
      val link_id_cnt = getSwidAndCount(jp_swid, jp_length, link_id)
      if (link_id_cnt.trim != "") swid_gd_len_arr2 += link_id_cnt else swid_gd_len_arr2 += "0"
    }


    swid_gd_len = swid_gd_len_arr2.mkString("|")

    //计算平均速度 速度*距离/时间
    var dist_sum: Double = 0.0
    var tm_sum: Double = 0.0

    for (i <- 0 until speed_gd2.length) {
      try {
        if (speed_gd2(i).toDouble != 0.0) {
          dist_sum += swid_gd_len_arr2(i).toDouble
          tm_sum += swid_gd_len_arr2(i).toDouble / speed_gd2(i).toDouble
        }
      } catch {
        case e: Exception => "" + e
      }
    }


    //    for (i <- 0 until speed_gd_arr.length) {
    //      try {
    //        if (speed_gd_arr(i).toDouble != 0.0) {
    //          dist_sum += swid_gd_len_arr(i).toDouble
    //          tm_sum += swid_gd_len_arr(i).toDouble / speed_gd_arr(i).toDouble
    //        }
    //      } catch {
    //        case e: Exception => "" + e
    //      }
    //    }


    // 修改为按照swid_gd2计算

    speed_avg_gd = if (tm_sum > 0) dist_sum / tm_sum else 0.0
    //单独计算gd_len
    gd_len = try {
      swid_gd_len.split("\\|").map(x => x.toDouble).sum
    } catch {
      case e: Exception => 0.0
    }

    x.put("swid_gd", swid_gd)
    x.put("status_gd", status_gd)
    x.put("speed_gd", speed_gd)
    x.put("swid_gd_len", swid_gd_len)
    x.put("events_code", events_code_arr.mkString("|"))
    x.put("events_s", events_s.mkString("|"))
    x.put("events_l", events_l.mkString("|"))
    x.put("speed_avg_gd", speed_avg_gd.toString)
    x.put("gd_len", gd_len.toString)

    x.put("swid_gd2", swid_gd2.mkString("|"))
    x.put("speed_gd2", speed_gd2.mkString("|"))
    //todo add 20230926
    x.put("event_swid", event_swid_arr.mkString("|"))
    x.put("event_id", event_id_arr.mkString("|"))
    x.put("event_content", event_content_arr.mkString("|"))

    x
  }

  def strNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case _ => !str.toString.isEmpty && str.toString.replace("-", "").trim != ""
    }
  }

  /**
   * 调用tmc接口
   *
   * @param x
   * @return
   */

  def calTmcInterface(jo: JSONObject, tmcUrl: String) = {

    val joPost = new JSONObject()
    val jp_swid = jo.getString("jp_swid")
    val jp_time = jo.getString("jp_time")
    val swidList = jp_swid.split("\\|")
    val timeList = jp_time.split("\\|")
    val pairs = swidList.zip(timeList)
    val indexedDistinctPairs = pairs.zipWithIndex.map { case ((swid, time), index) => (swid, time, index) }.sortBy(_._3).filter(x => {
      !"0".equals(x._1)
    })
    //    val sortTuple = indexedDistinctPairs.groupBy(_._1).map(x => x._2.take(1)).flatten.toList.sortBy(_._3)
    // 0526修改为Jp_swid不去重，只去除为0的数据
    val sortTuple = indexedDistinctPairs.toList.sortBy(_._3)
    val swidArray = sortTuple.map(_._1)
    val timeArray = sortTuple.map(_._2)

    val tracksArray = new JSONArray()

    for (index <- (0 until (swidArray.length))) {
      val swid = swidArray(index)
      val time = timeArray(index)
      val track = new JSONObject()
      track.put("link_id", swid)
      track.put("timestamp", time)
      tracksArray.add(track)
    }

    joPost.put("ak", "ef789d00926d46cdae8fc721608557ad")
    joPost.put("tracks", tracksArray)
    joPost.put("focus", "flow,warn,event")

    //    val fixResponse = HttpUtils.doPost(tmcUrl, joPost)
    val fixResponse = ""

    val eventMap = getEventMap()

    val json = try {
      parseTmcResponse(jo, fixResponse, eventMap)
    } catch {
      case e: Exception => jo
    }
    json
  }


  def parseExpInterface(response: String, jpResponse: JSONObject, gpsTime: String, continueTm2: String) = {
    //    task_swid_map: mutable.HashMap[String, String]

    val jp_swid = jpResponse.getString("jp_swid")
    val jp_length = jpResponse.getString("jp_length")

    val task_swid_map = getSwidAndCount(jp_swid, jp_length)
    val responseJo = JSON.parseObject(response)
    val jy_tracks = responseJo.getJSONArray("linkCostArray")
    var swid_exp, swid_len_exp, speed_exp = ""
    var disu_duration_sub = "0"
    val swid_exp_arr, swid_len_exp_arr, speed_exp_arr = new ListBuffer[String]()
    var disu_duration_exp = 0.0

    try {
      for (i <- 0 until jy_tracks.size()) {
        val linkID = jy_tracks.getJSONObject(i).getString("linkID")
        //linkID拼接
        swid_exp_arr += linkID
        //获取swid返回的长度
        val swid_len = task_swid_map.getOrElse(linkID, "")
        if (swid_len.trim != "") swid_len_exp_arr += swid_len else swid_len_exp_arr += "0"
        //低速速度拼接 km/h
        val costArray = jy_tracks.getJSONObject(i).getJSONArray("costArray")

        var diff = 235959
        var speed_exp_t = "0"
        for (j <- 0 until costArray.size()) {
          val startTime = costArray.getJSONObject(j).getString("startTime")
          val speed = costArray.getJSONObject(j).getString("speed")
          val cur_diff = Math.abs(gpsTime.toInt - startTime.toInt * 100) //start_time = 235523
          if (cur_diff <= diff) {
            diff = cur_diff
            speed_exp_t = speed
          }
        }

        //        val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
        //        disu_duration_exp += sd_tmp
        //        val staticSpeed = jy_tracks.getJSONObject(i).getString("staticSpeed")
        //        // 20230418增加当speed_exp_t为0时，取staticSpeed
        //        if (!speed_exp_t.equals("0")) speed_exp_arr += speed_exp_t else speed_exp_arr += staticSpeed

        val staticSpeed = jy_tracks.getJSONObject(i).getString("staticSpeed")
        if (speed_exp_t.equals("0")) speed_exp_t = staticSpeed
        val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
        disu_duration_exp += sd_tmp
        // 20230418增加当speed_exp_t为0时，取staticSpeed
        if (!speed_exp_t.equals("0")) speed_exp_arr += speed_exp_t else speed_exp_arr += staticSpeed
      }
    } catch {
      case e: Exception => ""
    }

    swid_exp = swid_exp_arr.mkString("|")
    swid_len_exp = swid_len_exp_arr.mkString("|")
    speed_exp = speed_exp_arr.mkString("|")


    disu_duration_sub = try {
      (continueTm2.toDouble - disu_duration_exp).toString
    } catch {
      case e: Exception => "0"
    }
    if (disu_duration_sub.toDouble < 0) disu_duration_sub = "0"


    val expr = new ExprCost()
    expr.swid_exp = swid_exp
    expr.swid_len_exp = swid_len_exp
    expr.speed_exp = speed_exp
    expr.disu_duration_exp = disu_duration_exp.toString
    expr.disu_duration_subob = disu_duration_sub


    expr

  }


  def getSwidAndCount(jp_swid: String, jp_length: String): mutable.HashMap[String, String] = {
    val task_swid_map = new mutable.HashMap[String, String]()
    val task_swid_arr = try {
      jp_swid.split("\\|")
    } catch {
      case e: Exception => Array()
    }

    val task_length_arr = try {
      jp_length.split("\\|")
    } catch {
      case e: Exception => Array()
    }

    try {
      for (i <- 0 until task_swid_arr.length) {
        val swid = task_swid_arr(i)
        val dist = task_length_arr(i)
        task_swid_map.put(swid, dist)
      }
    } catch {
      case e: Exception => ""
    }
    task_swid_map
  }


  def calQmPointInterface(jo: JSONObject, qmUrl: String, date: String) = {

    val joPost = new JSONObject()
    val jp_coords = jo.getString("jp_coords")

    joPost.put("ak", "dc894b4a3c7444b4a3505315d00b87ad")

    joPost.put("test", "1")
    joPost.put("stype", "0")
    joPost.put("etype", "0")
    joPost.put("date", date)
    joPost.put("mode", 2)
    joPost.put("output", "json")
    joPost.put("points", jp_coords)
    joPost.put("opt", "sf4")


    //    val fixResponse = HttpUtils.doPost(qmUrl, joPost)
    val fixResponse = ""
    val json = try {
      parseQMJsonStr(jo, fixResponse)
    } catch {
      case e: Exception => jo
    }

    json

  }


  // 解析融合轨迹接口返回的json
  def parseQMJsonStr(x: JSONObject, jsonStr: String): JSONObject = {
    val t_distanceBuff = new ArrayBuffer[Long]()
    val toll_stationBuff = new ArrayBuffer[String]()
    val serviceBuff = new ArrayBuffer[String]()
    val toll_station_linkpointinfoBuff = new ArrayBuffer[String]()
    val service_station_linkpointinfoBuff = new ArrayBuffer[String]()
    val roadclass_ab = new ArrayBuffer[String]()
    val roadname_ab = new ArrayBuffer[String]()

    try {
      val o2: JSONObject = JSON.parseObject(jsonStr)
      val status: String = o2.getString("status")
      if (status == "0") {
        val route: JSONObject = o2.getJSONObject("route")
        val paths: JSONArray = route.getJSONArray("paths")

        for (i <- 0 until paths.size()) {
          val path: JSONObject = paths.getJSONObject(i)
          t_distanceBuff.append(path.getLongValue("distance"))
          val polylineArr: Array[String] = path.getString("polyline").split(";")
          val steps: JSONArray = path.getJSONArray("steps")
          if (!steps.isEmpty) {
            for (j <- 0 until steps.size()) {
              val step: JSONObject = steps.getJSONObject(j)
              val links: JSONArray = step.getJSONArray("links")
              if (!links.isEmpty) {
                for (k <- 0 until links.size()) {
                  val link: JSONObject = links.getJSONObject(k)
                  val lnk_type: String = link.getString("lnk_type")
                  val formway: String = link.getString("formway")
                  val coorindex: Int = link.getIntValue("coorindex")
                  val pointnum: Int = link.getIntValue("pointnum")
                  val name: String = link.getString("name")
                  val roadclass: String = link.getString("roadclass")
                  roadclass_ab.append(roadclass)
                  roadname_ab.append(name)

                  val start2EndPoint: String = polylineArr(coorindex) + ";" + polylineArr(coorindex + pointnum - 1)

                  val swid: String = link.getString("sw_id")
                  if (lnk_type == "2") {
                    toll_stationBuff.append(swid)
                    toll_station_linkpointinfoBuff.append(start2EndPoint)
                  }
                  if (formway == "5") {
                    serviceBuff.append(swid)
                    service_station_linkpointinfoBuff.append(start2EndPoint)
                  }
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => ""
      //        System.err.println("匹配接口接口调用失败:" + e.getMessage)
    }
    x.put("t_distance", t_distanceBuff.sum)
    x.put("toll_station", toll_stationBuff.mkString("|"))
    x.put("service", serviceBuff.mkString("|"))
    x.put("toll_station_linkpointinfo", toll_station_linkpointinfoBuff.mkString("|"))
    x.put("service_station_linkpointinfo", service_station_linkpointinfoBuff.mkString("|"))
    x.put("roadclass", roadclass_ab.mkString("|"))
    x.put("roadname", roadname_ab.mkString("|"))
    x
  }

  def getSwidAndCount(jp_swid: String, jp_length: String, link_id: String): String = {
    var dist = "0"
    val jp_swid_arr = try {
      jp_swid.split("\\|")
    } catch {
      case e: Exception => Array()
    }
    val jp_length_arr = try {
      jp_length.split("\\|")
    } catch {
      case e: Exception => Array()
    }
    breakable {
      for (i <- 0 until jp_swid_arr.length) {
        val swid = jp_swid_arr(i)
        if (swid == link_id) {
          dist = jp_length_arr(i)
          break
        }
      }
    }
    dist
  }


  def getEventMap(): mutable.Map[String, (String, String)] = {
    val event_info = Seq(("未知", "1", "0,0,18,1", "0", "无限制", "0", "无", "18", "流量", "1", "未知"),
      ("畅通", "2", "0,0,18,2", "0", "无限制", "0", "无", "18", "流量", "2", "畅通"),
      ("缓行", "3", "0,0,18,3", "0", "无限制", "0", "无", "18", "流量", "3", "缓慢"),
      ("拥堵", "4", "0,0,18,4", "0", "无限制", "0", "无", "18", "流量", "4", "拥堵"),
      ("堵塞", "5", "0,0,18,5", "0", "无限制", "0", "无", "18", "流量", "5", "堵塞"),
      ("无交通流", "6", "0,0,18,6", "0", "无限制", "0", "无", "18", "流量", "6", "无交通流"),
      ("一般交通事故", "101", "0,0,100,101", "0", "无限制", "0", "无", "100", "交通事故", "101", "一般交通事故"),
      ("严重交通事故", "102", "0,0,100,102", "0", "无限制", "0", "无", "100", "交通事故", "102", "严重交通事故"),
      ("故障车", "103", "0,0,100,103", "0", "无限制", "0", "无", "100", "交通事故", "103", "故障车"),
      ("疑似事故", "104", "0,0,100,104", "0", "无限制", "0", "无", "100", "交通事故", "104", "疑似事故"),
      ("道路施工", "201", "0,0,200,201", "0", "无限制", "0", "无", "200", "道路施工", "201", "道路施工"),
      ("施工影响出行", "202", "0,0,200,202", "0", "无限制", "0", "无", "200", "道路施工", "202", "施工影响出行"),
      ("施工不建议穿行", "203", "0,0,200,203", "0", "无限制", "0", "无", "200", "道路施工", "203", "施工不建议穿行"),
      ("施工在建", "201399", "1,1,200,399", "1", "通行限制", "1", "封路", "200", "道路施工", "399", "道路建设中"),
      ("交通管制", "301", "0,0,300,301", "0", "无限制", "0", "无", "300", "交通管制", "301", "不明确"),
      ("道路关闭", "302", "1,1,300,302", "1", "通行限制", "1", "封路", "300", "交通管制", "302", "道路关闭"),
      ("出口匝道关闭", "303", "5,1,300,303", "5", "出口匝道限制", "1", "出口匝道关闭", "300", "交通管制", "303", "出口匝道关闭"),
      ("入口匝道关闭", "304", "4,1,300,304", "4", "入口匝道限制", "1", "入口匝道关闭", "300", "交通管制", "304", "入口匝道关闭"),
      ("1条车道关闭", "305", "1,0,300,305", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "305", "1条车道关闭"),
      ("2条车道关闭", "306", "1,0,300,306", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "306", "2条车道关闭"),
      ("3条车道关闭", "307", "1,0,300,307", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "307", "3条车道关闭"),
      ("4条车道关闭", "308", "1,0,300,308", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "308", "4条车道关闭"),
      ("禁止左转", "309", "1,2,300,309", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "309", "禁止左转"),
      ("禁止右转", "310", "1,2,300,310", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "310", "禁止右转"),
      ("禁止左右转", "311", "1,2,300,311", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "311", "禁止左右转"),
      ("禁止直行", "312", "1,2,300,312", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "312", "禁止直行"),
      ("禁止掉头", "313", "1,2,300,313", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "313", "禁止掉头"),
      ("道路限高|限重|限宽", "314", "1,3,300,314", "1", "通行限制", "3", "车辆限制", "300", "交通管制", "314", "道路限高|限重|限宽"),
      ("其他车辆限行", "315", "1,3,300,315", "1", "通行限制", "3", "车辆限制", "300", "交通管制", "315", "其他车辆限行"),
      ("禁止停车", "316", "1,3,300,316", "1", "通行限制", "3", "车辆限制", "300", "交通管制", "316", "禁止停车"),
      ("道路建设中", "399", "1,1,300,399", "1", "通行限制", "1", "封路", "300", "交通管制", "399", "道路建设中"),
      ("大风", "401", "0,0,400,401", "0", "无限制", "0", "无", "400", "天气", "401", "大风"),
      ("飓风", "402", "0,0,400,402", "0", "无限制", "0", "无", "400", "天气", "402", "飓风"),
      ("雾", "403", "0,0,400,403", "0", "无限制", "0", "无", "400", "天气", "403", "雾"),
      ("大雾", "404", "0,0,400,404", "0", "无限制", "0", "无", "400", "天气", "404", "大雾"),
      ("雨", "405", "0,0,400,405", "0", "无限制", "0", "无", "400", "天气", "405", "雨"),
      ("大雨", "406", "0,0,400,406", "0", "无限制", "0", "无", "400", "天气", "406", "大雨"),
      ("雨夹雪", "407", "0,0,400,407", "0", "无限制", "0", "无", "400", "天气", "407", "雨夹雪"),
      ("雪", "408", "0,0,400,408", "0", "无限制", "0", "无", "400", "天气", "408", "雪"),
      ("大雪", "409", "0,0,400,409", "0", "无限制", "0", "无", "400", "天气", "409", "大雪"),
      ("冰雹", "410", "0,0,400,410", "0", "无限制", "0", "无", "400", "天气", "410", "冰雹"),
      ("破坏性冰雹", "411", "0,0,400,411", "0", "无限制", "0", "无", "400", "天气", "411", "破坏性冰雹"),
      ("寒潮", "412", "0,0,400,412", "0", "无限制", "0", "无", "400", "天气", "412", "寒潮"),
      ("沙尘暴", "413", "0,0,400,413", "0", "无限制", "0", "无", "400", "天气", "413", "沙尘暴"),
      ("高温", "414", "0,0,400,414", "0", "无限制", "0", "无", "400", "天气", "414", "高温"),
      ("干旱", "415", "0,0,400,415", "0", "无限制", "0", "无", "400", "天气", "415", "干旱"),
      ("雷电", "416", "0,0,400,416", "0", "无限制", "0", "无", "400", "天气", "416", "雷电"),
      ("霜冻", "417", "0,0,400,417", "0", "无限制", "0", "无", "400", "天气", "417", "霜冻"),
      ("霾", "418", "0,0,400,418", "0", "无限制", "0", "无", "400", "天气", "418", "霾"),
      ("台风", "419", "0,0,400,419", "0", "无限制", "0", "无", "400", "天气", "419", "台风"),
      ("雷雨大风", "420", "0,0,400,420", "0", "无限制", "0", "无", "400", "天气", "420", "雷雨大风"),
      ("森林火灾", "421", "0,0,400,421", "0", "无限制", "0", "无", "400", "天气", "421", "森林火灾"),
      ("烈风", "422", "0,0,400,422", "0", "无限制", "0", "无", "400", "天气", "422", "烈风"),
      ("风暴", "423", "0,0,400,423", "0", "无限制", "0", "无", "400", "天气", "423", "风暴"),
      ("狂爆风", "424", "0,0,400,424", "0", "无限制", "0", "无", "400", "天气", "424", "狂爆风"),
      ("龙卷风", "425", "0,0,400,425", "0", "无限制", "0", "无", "400", "天气", "425", "龙卷风"),
      ("热带风暴", "426", "0,0,400,426", "0", "无限制", "0", "无", "400", "天气", "426", "热带风暴"),
      ("强雷阵雨", "427", "0,0,400,427", "0", "无限制", "0", "无", "400", "天气", "427", "强雷阵雨"),
      ("雷阵雨伴有冰雹", "428", "0,0,400,428", "0", "无限制", "0", "无", "400", "天气", "428", "雷阵雨伴有冰雹"),
      ("极端降雨", "429", "0,0,400,429", "0", "无限制", "0", "无", "400", "天气", "429", "极端降雨"),
      ("暴雨", "430", "0,0,400,430", "0", "无限制", "0", "无", "400", "天气", "430", "暴雨"),
      ("大暴雨", "431", "0,0,400,431", "0", "无限制", "0", "无", "400", "天气", "431", "大暴雨"),
      ("特大暴雨", "432", "0,0,400,432", "0", "无限制", "0", "无", "400", "天气", "432", "特大暴雨"),
      ("冻雨", "433", "0,0,400,433", "0", "无限制", "0", "无", "400", "天气", "433", "冻雨"),
      ("中雪", "434", "0,0,400,434", "0", "无限制", "0", "无", "400", "天气", "434", "中雪"),
      ("暴雪", "435", "0,0,400,435", "0", "无限制", "0", "无", "400", "天气", "435", "暴雪"),
      ("雨雪天气", "436", "0,0,400,436", "0", "无限制", "0", "无", "400", "天气", "436", "雨雪天气"),
      ("阵雨夹雪", "437", "0,0,400,437", "0", "无限制", "0", "无", "400", "天气", "437", "阵雨夹雪"),
      ("阵雪", "438", "0,0,400,438", "0", "无限制", "0", "无", "400", "天气", "438", "阵雪"),
      ("强沙尘暴", "439", "0,0,400,439", "0", "无限制", "0", "无", "400", "天气", "439", "强沙尘暴"),
      ("雷暴", "440", "0,0,400,440", "0", "无限制", "0", "无", "400", "天气", "440", "雷暴"),
      ("路面积水", "501", "0,0,500,501", "0", "无限制", "0", "无", "500", "路面", "501", "路面积水"),
      ("路面积雪", "502", "0,0,500,502", "0", "无限制", "0", "无", "500", "路面", "502", "路面积雪"),
      ("路面薄冰", "503", "0,0,500,503", "0", "无限制", "0", "无", "500", "路面", "503", "路面薄冰"),
      ("路面沉陷", "504", "0,0,500,504", "0", "无限制", "0", "无", "500", "路面", "504", "路面沉陷"),
      ("路面有障碍物", "505", "0,0,500,505", "0", "无限制", "0", "无", "500", "路面", "505", "路面有障碍物"),
      ("路面火灾", "506", "0,0,500,506", "0", "无限制", "0", "无", "500", "路面", "506", "路面火灾"),
      ("路滑", "507", "0,0,500,507", "0", "无限制", "0", "无", "500", "路面", "507", "路滑"),
      ("路面有油", "508", "0,0,500,508", "0", "无限制", "0", "无", "500", "路面", "508", "路面有油"),
      ("路面有汽油", "509", "0,0,500,509", "0", "无限制", "0", "无", "500", "路面", "509", "路面有汽油"),
      ("路面状况较差", "510", "0,0,500,510", "0", "无限制", "0", "无", "500", "路面", "510", "路面状况较差"),
      ("危险的行驶条件", "511", "0,0,500,511", "0", "无限制", "0", "无", "500", "路面", "511", "危险的行驶条件"),
      ("极端危险的行驶条件", "512", "0,0,500,512", "0", "无限制", "0", "无", "500", "路面", "512", "极端危险的行驶条件"),
      ("连续弯路", "531", "0,0,500,531", "0", "无限制", "0", "无", "500", "路面", "531", "连续弯路"),
      ("事故高发", "532", "0,0,500,532", "0", "无限制", "0", "无", "500", "路面", "532", "事故高发"),
      ("货车多", "534", "0,0,500,534", "0", "无限制", "0", "无", "500", "路面", "534", "货车多"),
      ("异常急减速", "535", "0,0,500,535", "0", "无限制", "0", "无", "500", "路面", "535", "异常急减速"),
      ("博览会", "601", "0,0,600,601", "0", "无限制", "0", "无", "600", "活动", "601", "博览会"),
      ("国家重大活动", "602", "0,0,600,602", "0", "无限制", "0", "无", "600", "活动", "602", "国家重大活动"),
      ("集会", "603", "0,0,600,603", "0", "无限制", "0", "无", "600", "活动", "603", "集会"),
      ("大型会议", "604", "0,0,600,604", "0", "无限制", "0", "无", "600", "活动", "604", "大型会议"),
      ("体育活动", "605", "0,0,600,605", "0", "无限制", "0", "无", "600", "活动", "605", "体育活动"),
      ("文艺活动", "606", "0,0,600,606", "0", "无限制", "0", "无", "600", "活动", "606", "文艺活动"),
      ("节假日", "607", "0,0,600,607", "0", "无限制", "0", "无", "600", "活动", "607", "节假日"),
      ("洪水", "701", "0,0,700,701", "0", "无限制", "0", "无", "700", "灾害", "701", "洪水"),
      ("地震", "702", "0,0,700,702", "0", "无限制", "0", "无", "700", "灾害", "702", "地震"),
      ("岩崩", "703", "0,0,700,703", "0", "无限制", "0", "无", "700", "灾害", "703", "岩崩"),
      ("坍坡", "704", "0,0,700,704", "0", "无限制", "0", "无", "700", "灾害", "704", "坍坡"),
      ("泥石流", "705", "0,0,700,705", "0", "无限制", "0", "无", "700", "灾害", "705", "泥石流"),
      ("公告", "901", "0,0,800,901", "0", "无限制", "0", "无", "800", "公告", "901", "公告"),
      ("通车", "902", "0,0,900,902", "0", "无限制", "0", "无", "900", "其他", "902", "通车"),
      ("完成改建", "903", "0,0,900,903", "0", "无限制", "0", "无", "900", "其他", "903", "完成改建"),
      ("实景路况", "904", "0,0,900,904", "0", "无限制", "0", "无", "900", "其他", "904", "实景路况"),
      ("紧急事件", "905", "0,0,900,905", "0", "无限制", "0", "无", "900", "其他", "905", "紧急事件"),
      ("地铁事件", "906", "0,0,900,906", "0", "无限制", "0", "无", "900", "其他", "906", "地铁事件"),
      ("疫情播报", "907", "0,0,900,907", "0", "无限制", "0", "无", "900", "其他", "907", "疫情播报"),
      ("疑似事件", "908", "0,0,900,908", "0", "无限制", "0", "无", "900", "其他", "908", "疑似事件"),
      ("定制播报", "910", "0,0,900,910", "0", "无限制", "0", "无", "900", "其他", "910", "定制播报"),
      ("慢速车", "911", "0,0,900,911", "0", "无限制", "0", "无", "900", "其他", "911", "慢速车"),
      ("一般交通事故&道路关闭", "101302", "1,1,100,101", "1", "通行限制", "1", "封路", "100", "交通事故", "101", "一般交通事故"),
      ("严重交通事故&道路关闭", "102302", "1,1,100,102", "1", "通行限制", "1", "封路", "100", "交通事故", "102", "严重交通事故"),
      ("道路施工&道路关闭", "201302", "1,1,200,201", "1", "通行限制", "1", "封路", "200", "道路施工", "201", "道路施工"),
      ("大雾&道路关闭", "404302", "1,1,400,404", "1", "通行限制", "1", "封路", "400", "天气", "404", "大雾"),
      ("大雨&道路关闭", "406302", "1,1,400,406", "1", "通行限制", "1", "封路", "400", "天气", "406", "大雨"),
      ("大雪&道路关闭", "409302", "1,1,400,409", "1", "通行限制", "1", "封路", "400", "天气", "409", "大雪"),
      ("冰雹&道路关闭", "410302", "1,1,400,410", "1", "通行限制", "1", "封路", "400", "天气", "410", "冰雹"),
      ("路面积水&道路关闭", "501302", "1,1,500,501", "1", "通行限制", "1", "封路", "500", "路面", "501", "路面积水"),
      ("路面积雪&道路关闭", "502302", "1,1,500,502", "1", "通行限制", "1", "封路", "500", "路面", "502", "路面积雪"),
      ("路面薄冰&道路关闭", "503302", "1,1,500,503", "1", "通行限制", "1", "封路", "500", "路面", "503", "路面薄冰"),
      ("路面沉陷&道路关闭", "504302", "1,1,500,504", "1", "通行限制", "1", "封路", "500", "路面", "504", "路面沉陷"),
      ("路面有障碍物&道路关闭", "505302", "1,1,500,505", "1", "通行限制", "1", "封路", "500", "路面", "505", "路面有障碍物"),
      ("严重火灾&道路关闭", "506302", "1,1,500,506", "1", "通行限制", "1", "封路", "500", "路面", "506", "路面火灾"),
      ("博览会&道路关闭", "601302", "1,1,600,601", "1", "通行限制", "1", "封路", "600", "活动", "601", "博览会"),
      ("国家重大活动&道路关闭", "602302", "1,1,600,602", "1", "通行限制", "1", "封路", "600", "活动", "602", "国家重大活动"),
      ("集会&道路关闭", "603302", "1,1,600,603", "1", "通行限制", "1", "封路", "600", "活动", "603", "集会"),
      ("大型会议&道路关闭", "604302", "1,1,600,604", "1", "通行限制", "1", "封路", "600", "活动", "604", "大型会议"),
      ("体育活动&道路关闭", "605302", "1,1,600,605", "1", "通行限制", "1", "封路", "600", "活动", "605", "体育活动"),
      ("文艺活动&道路关闭", "606302", "1,1,600,606", "1", "通行限制", "1", "封路", "600", "活动", "606", "文艺活动"),
      ("节假日&道路关闭", "607302", "1,1,600,607", "1", "通行限制", "1", "封路", "600", "活动", "607", "节假日"),
      ("洪水&道路关闭", "701302", "1,1,700,701", "1", "通行限制", "1", "封路", "700", "灾害", "701", "洪水"),
      ("地震&道路关闭", "702302", "1,1,700,702", "1", "通行限制", "1", "封路", "700", "灾害", "702", "地震"),
      ("岩崩&道路关闭", "703302", "1,1,700,703", "1", "通行限制", "1", "封路", "700", "灾害", "703", "岩崩"),
      ("坍坡&道路关闭", "704302", "1,1,700,704", "1", "通行限制", "1", "封路", "700", "灾害", "704", "坍坡"),
      ("泥石流&道路关闭", "705302", "1,1,700,705", "1", "通行限制", "1", "封路", "700", "灾害", "705", "泥石流"),
      ("疫情&道路关闭", "", "1,1,6,16", "1", "通行限制", "1", "封路", "6", "疫情", "16", "疫情管制"),
      ("防疫检查站", "", "0,0,6,16", "0", "无限制", "0", "无", "6", "疫情", "16", "疫情管制"),
      ("未来事件&道路关闭", "", "1,1,19,201", "1", "通行限制", "1", "封路", "19", "未来事件", "201", "道路施工"),
      ("未来事件&道路关闭", "", "1,1,19,302", "1", "通行限制", "1", "封路", "19", "未来事件", "302", "道路关闭"),
      ("新增道路关闭", "***302", "1,1,0,255", "1", "通行限制", "1", "封路", "0", "无原因现象", "255", "不明确"))
    val event_map = mutable.Map[String, (String, String)]()
    for (i <- 0 until event_info.size) {
      event_map.put(event_info(i)._3, (event_info(i)._1, event_info(i)._9))
    }
    event_map
  }


  def parseFixResponse(continueTm: String, x: JSONObject) = {

    val jo = new JSONObject()
    val result = x.getJSONObject("result")
    val tracks = result.getJSONArray("tracks")
    val jp_swidBuff = new ArrayBuffer[String]()
    val jp_timeBuff = new ArrayBuffer[Long]()
    val jp_coordsBuff = new ArrayBuffer[String]()
    val jp_statusBuff = new ArrayBuffer[String]()
    val sum_distBuff = new ArrayBuffer[String]()
    val link_lengthBuff = new ArrayBuffer[String]()


    val stay_points = result.getJSONArray("stay_points")

    val speedBuff = new ArrayBuffer[String]()

    val stayDurationBuffer = new ArrayBuffer[String]()
    val stayStartBuffer = new ArrayBuffer[String]()
    val stayEndBuffer = new ArrayBuffer[String]()
    var stayTotalDuration = 0


    for (i <- 0 until tracks.size()) {
      val t: JSONObject = tracks.getJSONObject(i)
      jp_swidBuff.append(t.getString("SWID"))
      jp_timeBuff.append(t.getLongValue("time"))
      val x: String = t.getString("x")
      val y: String = t.getString("y")
      jp_coordsBuff.append(x + "," + y)
      jp_statusBuff.append(t.getString("status"))
      sum_distBuff.append(t.getString("sum_dist"))
      link_lengthBuff.append(t.getString("link_length"))
      speedBuff.append(t.getString("speed"))
    }

    val dist = try {
      sum_distBuff.last.toDouble
    } catch {
      case e: Exception => 0
    }
    val avg_speed = try {
      (dist / 1000) / (continueTm.toDouble / 3600)
    } catch {
      case e: Exception => 0
    }


    for (i <- 0 until stay_points.size()) {
      val stayJo = stay_points.getJSONObject(i)
      val stayDuration = JSONUtils.getJsonValueInt(stayJo, "duration", 0)
      val stayStartIndex = JSONUtils.getJsonValueInt(stayJo, "start_index", 0)
      val stayEndIndex = JSONUtils.getJsonValueInt(stayJo, "end_index", 0)

      stayDurationBuffer.append(stayDuration.toString)

      val stayStartJo = try {
        tracks.getJSONObject(stayStartIndex)
      } catch {
        case e: Exception => new JSONObject()
      }
      val x1: String = stayStartJo.getString("x")
      val y1: String = stayStartJo.getString("y")
      stayStartBuffer.append(x1 + "," + y1)

      val stayEndJo = try {
        tracks.getJSONObject(stayEndIndex)
      } catch {
        case e: Exception => new JSONObject()
      }
      val x2: String = stayEndJo.getString("x")
      val y2: String = stayEndJo.getString("y")
      stayEndBuffer.append(x2 + "," + y2)

      stayTotalDuration += stayDuration

    }


    jo.put("jp_swid", jp_swidBuff.mkString("|"))
    jo.put("jp_time", jp_timeBuff.mkString("|"))
    jo.put("jp_coords", jp_coordsBuff.mkString("|"))
    jo.put("jp_status", jp_statusBuff.mkString("|"))
    jo.put("jp_length", link_lengthBuff.mkString("|"))
    jo.put("dist", dist)
    jo.put("sum_dist", sum_distBuff.mkString("|"))
    jo.put("avg_speed", avg_speed)
    jo.put("speed", speedBuff.mkString("|"))

    jo.put("stay_duration", stayDurationBuffer.mkString("|"))
    jo.put("stay_start_point", stayStartBuffer.mkString("|"))
    jo.put("stay_end_point", stayEndBuffer.mkString("|"))
    jo.put("stay_total_duration", stayTotalDuration / 60)

    jo
  }


}
