package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter}
import utils.{ColumnUtil, SparkBuilder}

import scala.collection.JavaConversions.asScalaIterator
import scala.collection.mutable

/**
 * @description: 车辆风险 月度汇总表 448854  一次性任务ID 452384
 * @author 01418539 caojia
 * @date 2022/6/13 15:33
 */
case class CityProvMapCols(lpn: String,
                           adcode_city_1: String, adcode_city_cnt_m1: String, adcode_city_2: String, adcode_city_cnt_m2: String, adcode_city_3: String, adcode_city_cnt_m3: String,
                           adcode_prov_1: String, adcode_prov_cnt_m1: String, adcode_prov_2: String, adcode_prov_cnt_m2: String, adcode_prov_3: String, adcode_prov_cnt_m3: String,
                           adcode_city_map: String, adcode_prov_map: String,
                           adcode_dist_city_1: String, adcode_dist_city_dist_m1: String, adcode_dist_city_2: String, adcode_dist_city_dist_m2: String, adcode_dist_city_3: String, adcode_dist_city_dist_m3: String,
                           adcode_dist_prov_1: String, adcode_dist_prov_dist_m1: String, adcode_dist_prov_2: String, adcode_dist_prov_dist_m2: String, adcode_dist_prov_3: String, adcode_dist_prov_dist_m3: String,
                           adcode_dist_city_map: String, adcode_dist_prov_map: String,
                           adcode_dura_city_1: String, adcode_dura_city_duration_m1: String, adcode_dura_city_2: String, adcode_dura_city_duration_m2: String, adcode_dura_city_3: String, adcode_dura_city_duration_m3: String,
                           adcode_dura_prov_1: String, adcode_dura_prov_duration_m1: String, adcode_dura_prov_2: String, adcode_dura_prov_duration_m2: String, adcode_dura_prov_3: String, adcode_dura_prov_duration_m3: String,
                           adcode_dura_city_map: String, adcode_dura_prov_map: String)

object VehicleInsuranceRiskEvalMonth extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val o_table = args(1)
    val e_table = args(2)
    processLabel(spark, o_table, e_table, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processLabel(spark: SparkSession, o_table: String, e_table: String, inc_day: String): Unit = {
    import spark.implicits._
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天

    val o_day_dt = spark.sql(
      s"""select *
         |from $o_table
         |where inc_day>='$month_first_day' and inc_day <= '$month_last_day'
         |      and lpn is not null and trim(lpn) != ''
         |""".stripMargin)
      .withColumn("total_links_duration", when('total_links_duration.isNull || trim('total_links_duration) === "", 'total_duration).otherwise('total_links_duration))
      .withColumn("total_links_dist", when('total_links_dist.isNull || trim('total_links_dist) === "", 'total_dist).otherwise('total_links_dist))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val n_day_cols: Seq[String] = o_day_dt.schema.map(_.name)

    //part 1  mt 42 + mm 16 里程dist字段
    val o_mt_dist_cols_str = n_day_cols.filter(_.endsWith("_dist")).filter(_ != "drive_dist")

    val o_mm_dist_cols_str: Seq[String] = Seq(
      "total_links_dist", "night_dirve_dist", "before_dawn_drive_dist", "early_morning_drive_dist", "afternoon_drive_dist", "dusk_drive_dist",
      "high_speed_dist", "state_road_dist", "provincial_dist", "county_dist", "township_dist", "dangerous_road_dist", "high_accident_road_dist", "school_road_dist",
      "sharp_turn_road_dist", "village_road_dist")
    //part 2  mt 45 + mm 14 时长duration字段
    //20220808 新增的一个高速字段 high_speed_lowspeed_duration
    val o_mt_dura_cols_str = n_day_cols.filter(_.endsWith("_duration")).filter(_ != "drive_duration")

    val o_mm_dura_cols_str: Seq[String] = Seq(
      "total_links_duration", "night_dirve_duration", "before_dawn_drive_duration", "early_morning_drive_duration",
      "afternoon_drive_duration", "dusk_drive_duration", "dangerous_road_duration", "high_accident_road_duration", "school_road_duration",
      "sharp_turn_road_duration", "township_road_duration", "over_speed_duration", "over_speed_ser_duration", "over_drive_duration")
    //part 3 mt 39 + mm 8 次数cnt字段
    val o_mt_road_cols_str = n_day_cols.filter(_.endsWith("_cnt"))

    val o_mm_road_cols_str: Seq[String] = Seq(
      "lnk_cnt", "dangerous_road_cnt", "high_accident_road_cnt", "school_road_cnt", "sharp_turn_road_cnt", "township_road_road_cnt", "operation_cnt", "operation_same_city_cnt"
    )

    val init_mt_cols_str = o_mt_dist_cols_str ++ o_mt_dura_cols_str ++ o_mt_road_cols_str
    val init_mm_cols_str = o_mm_dist_cols_str ++ o_mm_dura_cols_str ++ o_mm_road_cols_str

    //里程 月度 汇总 month total
    val dist_mt_cols_str = init_mt_cols_str.map(_ + "_mt")
    val mt_cols = ColumnUtil.renameColumn(init_mt_cols_str.map(sum(_)), dist_mt_cols_str)
    //里程 月度 最大值 month max
    val dist_mm_cols_str = init_mm_cols_str.map(_ + "_mm")
    val mm_cols = ColumnUtil.renameColumn(init_mm_cols_str.map(max(_)), dist_mm_cols_str)

    val ot_cols = Seq(
      max("first_track_eff_day").alias("first_track_eff_day"),
      sum("track_eff_days").alias("track_eff_days")
    )
    val t_cols = mt_cols ++ mm_cols ++ ot_cols

    val dist_dura_df = o_day_dt
      .withColumn("track_eff_days", when('total_links_dist.cast("double") >= 5 * 1000, 1).otherwise(0)) //有效行驶天数	本月内，当天行驶里程≥5km的天数
      .withColumn("num", row_number().over(Window.partitionBy("lpn").orderBy("inc_day")))
      .withColumn("first_track_eff_day", when('num === 1, 'inc_day).otherwise(""))
      .groupBy("lpn") //本月总计
      .agg(t_cols.head, t_cols.tail: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val dist_dura_df_cols = dist_dura_df.schema.map(_.name).map(col)

    //step1
    val dist_avg_mt_cols = o_mm_dist_cols_str.map(_ + "_mt").map(col).map(_ / 'track_eff_days)
    val dist_avg_prop_cols = o_mm_dist_cols_str.map(_ + "_mt").filter(_ != "total_dist_mt").map(col).map(_ / 'total_dist_mt)

    val add_dist_avg_cols = ColumnUtil.renameColumn(dist_avg_mt_cols, o_mm_dist_cols_str.map(_ + "_ma"))
    val add_dist_prop_cols = ColumnUtil.renameColumn(dist_avg_prop_cols, o_mm_dist_cols_str.filter(_ != "total_dist").map(_ + "_mp"))
    //step2
    val dura_avg_mt_cols = o_mm_dura_cols_str.map(_ + "_mt").map(col).map(_ / 'track_eff_days)
    val dura_avg_prop_cols = o_mm_dura_cols_str.map(_ + "_mt").filter(_ != "total_duration_mt").map(col).map(_ / 'total_duration_mt)

    val add_dura_avg_cols = ColumnUtil.renameColumn(dura_avg_mt_cols, o_mm_dura_cols_str.map(_ + "_ma"))
    val add_dura_prop_cols = ColumnUtil.renameColumn(dura_avg_prop_cols, o_mm_dura_cols_str.filter(_ != "total_duration").map(_ + "_mp"))

    val add_avg_prop_cols = add_dist_avg_cols ++ add_dist_prop_cols ++ add_dura_avg_cols ++ add_dura_prop_cols

    val first_part_df = dist_dura_df.select(dist_dura_df_cols ++ add_avg_prop_cols: _*)

    //最后map拆分完的字段
    val map_cols = Seq("lpn", "adcode_city_1", "adcode_city_cnt_m1", "adcode_city_2", "adcode_city_cnt_m2", "adcode_city_3", "adcode_city_cnt_m3",
      "adcode_prov_1", "adcode_prov_cnt_m1", "adcode_prov_2", "adcode_prov_cnt_m2", "adcode_prov_3", "adcode_prov_cnt_m3", "adcode_city_map", "adcode_prov_map",
      "adcode_dist_city_1", "adcode_dist_city_dist_m1", "adcode_dist_city_2", "adcode_dist_city_dist_m2", "adcode_dist_city_3", "adcode_dist_city_dist_m3",
      "adcode_dist_prov_1", "adcode_dist_prov_dist_m1", "adcode_dist_prov_2", "adcode_dist_prov_dist_m2", "adcode_dist_prov_3", "adcode_dist_prov_dist_m3", "adcode_dist_city_map", "adcode_dist_prov_map",
      "adcode_dura_city_1", "adcode_dura_city_duration_m1", "adcode_dura_city_2", "adcode_dura_city_duration_m2", "adcode_dura_city_3", "adcode_dura_city_duration_m3",
      "adcode_dura_prov_1", "adcode_dura_prov_duration_m1", "adcode_dura_prov_2", "adcode_dura_prov_duration_m2", "adcode_dura_prov_3", "adcode_dura_prov_duration_m3", "adcode_dura_city_map", "adcode_dura_prov_map")

    //adcode编码映射关系表加载
    val city_dist_map = loadAdcodeMap(spark)
    val second_part_df = o_day_dt.select("lpn", "adcode_map", "adcode_dist_map", "adcode_duration_map")
      .withColumn("adcode_map", regexp_replace('adcode_map, "\\{|\\}| ", ""))
      .withColumn("adcode_dist_map", regexp_replace('adcode_dist_map, "\\{|\\}| ", ""))
      .withColumn("adcode_duration_map", regexp_replace('adcode_duration_map, "\\{|\\}| ", ""))
      .groupBy("lpn")
      .agg(
        concat_ws(",", collect_list("adcode_map")) as "adcode_map",
        concat_ws(",", collect_list("adcode_dist_map")) as "adcode_dist_map",
        concat_ws(",", collect_list("adcode_duration_map")) as "adcode_duration_map"
      )
      .map(row => {
        val lpn = row.getAs[String]("lpn")
        val adcode_map = row.getAs[String]("adcode_map")
        val adcode_dist_map = row.getAs[String]("adcode_dist_map")
        val adcode_duration_map = row.getAs[String]("adcode_duration_map")
        val x = getTopAndPolymer(adcode_map, city_dist_map, 1)
        val y = getTopAndPolymer(adcode_dist_map, city_dist_map, 1.1)
        val z = getTopAndPolymer(adcode_duration_map, city_dist_map, 1)
        CityProvMapCols(lpn, x._1._1, x._1._2, x._2._1, x._2._2, x._3._1, x._3._2, x._4._1, x._4._2, x._5._1, x._5._2, x._6._1, x._6._2, x._7, x._8, y._1._1, y._1._2, y._2._1, y._2._2, y._3._1, y._3._2, y._4._1, y._4._2, y._5._1, y._5._2, y._6._1, y._6._2, y._7, y._8, z._1._1, z._1._2, z._2._1, z._2._2, z._3._1, z._3._2, z._4._1, z._4._2, z._5._1, z._5._2, z._6._1, z._6._2, z._7, z._8)
      }).toDF(map_cols: _*)

    //按已有表结构拼装字段
    val o_month = spark.sql(s"""select * from $e_table limit 1""")
    val month_cols = o_month.schema.map(_.name).map(col)

    val res = first_part_df.join(second_part_df, Seq("lpn"))
      //total_links_dist_mm； total_links_duration_mm 改为 total_dist_mm ； total_duration_mm
      .withColumnRenamed("total_links_dist_mm", "total_dist_mm")
      .withColumnRenamed("total_links_duration_mm", "total_duration_mm")
      .withColumn("inc_day", lit(month_last_day))
      .select(month_cols: _*)

    writeToHive(spark, res, Seq("inc_day"), e_table)

    o_day_dt.unpersist()
    dist_dura_df.unpersist()
  }

  def loadAdcodeMap(spark: SparkSession): mutable.HashMap[String, String] = {
    val city_dist_map = new mutable.HashMap[String, String]()
    spark.sql("""select city_code,dist_code from dm_gis.adcode_prov_city_map""")
      .toLocalIterator.foreach(row => {
      val dist_code = row.getAs[String]("dist_code")
      val city_code = row.getAs[String]("city_code")
      city_dist_map.put(dist_code, city_code)
    })
    city_dist_map
  }

  /**
   * 获取 省、市 维度数据top3 * 2 及 2类顺序组合---共8个字段
   *
   * @param adcode_str
   * @param flag int or double 类型数据标识
   * @return
   */
  def getTopAndPolymer(adcode_str: String, city_dist_map: mutable.HashMap[String, String], flag: Double): ((String, String), (String, String), (String, String), (String, String), (String, String), (String, String), String, String) = {
    val adcode_arr = adcode_str.split(",")

    val adcode_hm_city = new mutable.HashMap[String, Double]()
    val adcode_hm_prov = new mutable.HashMap[String, Double]()

    for (i <- 0 until adcode_arr.length) {
      val kv_arr = adcode_arr(i).split("=")
      var key_city = "0"
      var key_prov = "0"
      if (kv_arr(0).length == 6) {
        key_city = city_dist_map.getOrElse(kv_arr(0),"0")
        key_prov = kv_arr(0).substring(0, 2) + "0000"
      }
      var value = 0.0
      try {
        value = kv_arr(1).toDouble
      } catch {
        case e: Exception => logger.error("检查原数据中，字段是否是map形式" + e.getMessage)
      }
      if (adcode_hm_city.contains(key_city)) adcode_hm_city.put(key_city, adcode_hm_city.getOrElse(key_city, 0.0) + value) else adcode_hm_city.put(key_city, value)
      if (adcode_hm_prov.contains(key_prov)) adcode_hm_prov.put(key_prov, adcode_hm_prov.getOrElse(key_prov, 0.0) + value) else adcode_hm_prov.put(key_prov, value)
    }

    var adcode_city_map = ""
    var adcode_prov_map = ""

    if (flag == 1.1) {
      adcode_city_map = "{" + filterSort(adcode_hm_city, Ordering.Double).map(l => {
        l._1 + "=" + l._2
      }).mkString(",") + "}"
      adcode_prov_map = "{" + filterSort(adcode_hm_prov, Ordering.Double).map(l => {
        l._1 + "=" + l._2
      }).mkString(",") + "}"
    } else {
      adcode_city_map = "{" + filterSort(adcode_hm_city, Ordering.Double).map(l => {
        l._1 + "=" + l._2.toInt
      }).mkString(",") + "}"
      adcode_prov_map = "{" + filterSort(adcode_hm_prov, Ordering.Double).map(l => {
        l._1 + "=" + l._2.toInt
      }).mkString(",") + "}"
    }

    val adcode_city_tup: Array[(String, Double)] = filterSort(adcode_hm_city)
    val adcode_prov_tup: Array[(String, Double)] = filterSort(adcode_hm_prov)

    val top_city: ((String, String), (String, String), (String, String)) = topMatch(adcode_city_tup)
    val adcode_city_1 = top_city._1
    val adcode_city_2 = top_city._2
    val adcode_city_3 = top_city._3
    val top_prov: ((String, String), (String, String), (String, String)) = topMatch(adcode_prov_tup)
    val adcode_prov_1 = top_prov._1
    val adcode_prov_2 = top_prov._2
    val adcode_prov_3 = top_prov._3

    (adcode_city_1, adcode_city_2, adcode_city_3, adcode_prov_1, adcode_prov_2, adcode_prov_3, adcode_city_map, adcode_prov_map)
  }

  /**
   * 自定义排序：map指定排序字段及顺序
   *
   * @param hm
   * @param order1
   * @param order2
   * @return
   */
  def filterSort(hm: mutable.HashMap[String, Double], order1: Ordering[Double] = Ordering.Double.reverse, order2: Ordering[String] = Ordering.String): Array[(String, Double)] = {
    hm.filter(!_._1.equals("0")).toArray
      .sortBy(x => (x._2, x._1))(Ordering.Tuple2(order1, order2))
  }

  /**
   * 根据传入的arr 获取 top3
   *
   * @param adcode_tup
   * @return
   */
  def topMatch(adcode_tup: Array[(String, Double)]): ((String, String), (String, String), (String, String)) = {
    val top1 = ""
    val top2 = ""
    val top3 = ""
    val zero = "0"
    try {
      adcode_tup.length match {
        case 0 => ((top1, zero), (top2, zero), (top3, zero))
        case 1 => ((adcode_tup(0)._1, adcode_tup(0)._2.toString), (top2, zero), (top3, zero))
        case 2 => ((adcode_tup(0)._1, adcode_tup(0)._2.toString), (adcode_tup(1)._1, adcode_tup(1)._2.toString), (top3, zero))
        case _ => ((adcode_tup(0)._1, adcode_tup(0)._2.toString), (adcode_tup(1)._1, adcode_tup(1)._2.toString), (adcode_tup(2)._1, adcode_tup(2)._2.toString))
      }
    } catch {
      case e: Exception => logger.error(s"NullPointException 请检查原始数据 $adcode_tup" + e)
        ((top1, zero), (top2, zero), (top3, zero))
    }
  }

}
