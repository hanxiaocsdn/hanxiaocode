package com.sf.app.eta

import com.sf.app.etastd.LoadEtaMonitorHiveToMysql.createOrInsert
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import utils.ColumnUtil.strNotNull
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter, getdaysBeforeOrAfter}
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: 764082
 * @description: 500w全网分里程段时速标准监控
 * @demander:舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/6/2 10:24
 */
object Efficient320w_500WRoadNameWholeNetwork extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val avg_TN = "dm_gis.avg_speed_detail_to_500"
    val inc_day = args(0)
    val flag = args(1).toInt
    procesWholeNetwork(spark, avg_TN, inc_day)
    if (inc_day.substring(6, 8) == "01" || inc_day.substring(6, 8) == "15" || inc_day == getLastDayofMonthBeforeOrAfter(inc_day, 1)) {
      procProp(spark, inc_day)
      val tables: Array[String] = Array("speed_compare_sf_hy","speed_compare_sf_hy_2")
      createOrInsert(spark, tables, inc_day, inc_day, flag)
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def procesWholeNetwork(spark: SparkSession, avg_TN: String, inc_day: String): Unit = {
    import spark.implicits._
    val day_2_bef = getdaysBeforeOrAfter(inc_day, -2)
    val day_2_aft = getdaysBeforeOrAfter(inc_day, 2)
    val avg_cols = spark.sql(s"""select * from $avg_TN limit 0""").schema.map(_.name).map(col)

    val sql_qg =
      s"""
         |select * from
         |(select row_number() over (partition by key_id order by time_highspeed_start_rep desc) as rank_num,*
         |from
         |(select concat(un,'_',highspeed_start_time,'_',highspeed_end_time)as key_id,un,highspeed_start_time,highspeed_end_time,day_diff_this,highspeed_dist,highspeed_ac_dist,highspeed_dist_ratio,direction,highspeed_duration,
         |tl_duration_2,speed_highspped,speed_highspeed_tl_2,time_highspeed_start_rep,highspeed_start_hour,
         |regexp_replace(time_highspeed_start_rep,'-','') inc_day
         |from dm_gis.eta_track_highway_detail_3d_with_328_city
         |where inc_day between '$day_2_bef' and '$day_2_aft'     --根据time_highspeed_start_rep往前往后取2天
         |and cast(highspeed_dist_ratio as double)>=0.8
         |and cast(speed_highspeed_tl_2 as double)>=50 and cast(speed_highspeed_tl_2 as double)<=120
         |and cast(highspeed_dist as double)>=50
         |and regexp_replace(time_highspeed_start_rep,'-','') = '$inc_day') a ) b  --高速的开始时间
         |where rank_num=1
         |""".stripMargin
    logger.error(">>全国数据标准加载的sql>>>>" + sql_qg)

    val dir_qg_df = spark.sql(sql_qg).na.fill("")
      .withColumn("non_highspeed_dist", getNonDistUdf('highspeed_dist))
      .withColumn("all_dist", 'highspeed_dist.cast("double") + 'non_highspeed_dist.cast("double"))
      .withColumn("all_duration", getAllDurationUdf('non_highspeed_dist, 'highspeed_duration, 'tl_duration_2))
      .withColumn("avg_speed", round('all_dist * lit(60) / 'all_duration, 2))
      .withColumn("dist_block", getDisBlockUdf('all_dist))
      .select(avg_cols: _*)
    writeToHive(spark, dir_qg_df.coalesce(10), Seq("inc_day"), avg_TN)
  }

  def procProp(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    var start_day, end_day = ""
    if (inc_day.substring(6, 8) == "01") {
      start_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
      end_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    } else if (inc_day.substring(6, 8) == "15") {
      start_day = getFirstDayofMonthBeforeOrAfter(inc_day, 0) //本月第一天
      end_day = inc_day
    }
    if (inc_day == getLastDayofMonthBeforeOrAfter(inc_day, 1)) {
      start_day = inc_day.substring(0, 6) + "16"
      end_day = inc_day
    }

    val o_sf_sql = //标准路由监控回溯表 单天24w~
      s"""
         |select *
         |from
         |(select row_number() over (partition by task_subid order by inc_day desc) as rank_num,*
         |from
         |(select task_subid,line_distance,actual_run_time,inc_day, line_distance/actual_run_time*60 as avg_speed,concat(line_code,'_',start_dept,'_',end_dept) as category,
         |   (
         |     case when line_distance  <= 100 then '50-100'
         |            when line_distance  <= 200 then '100-200'
         |            when line_distance  <= 500 then  '200-500'
         |            when line_distance  <= 1000 then '500-1000'
         |            else '1000+' end
         |    ) as dist_block, ---------里程区间
         |    (
         |     case when line_distance  <= 100 then '55-60'
         |            when line_distance  <= 200 then '60-70'
         |            when line_distance  <= 500 then  '60-75'
         |            when line_distance  <= 1000 then '65-75'
         |            when line_distance  > 1000 then '65-80'
         |            else '0' end
         |    ) as speed_std_sf
         |from dm_gis.eta_std_line_recall
         |where inc_day between '$start_day' and '$end_day'
         |and line_distance>=50
         |and line_distance/actual_run_time*60>0 and line_distance/actual_run_time*60<= 110
         |) a ) b   --取1个月
         |where rank_num=1
         |""".stripMargin

    val o_avg_sql =
      s"""
         |select *
         |from
         |(select row_number() over (partition by key_id order by inc_day desc) as rank_num,*
         |from
         |(select key_id,dist_block,avg_speed,inc_day
         |from dm_gis.avg_speed_detail_to_500
         |where inc_day between '$start_day' and '$end_day'
         |and avg_speed >=50 and avg_speed <=110
         |) a ) b   --取1个月
         |where rank_num=1
         |""".stripMargin
    logger.error(">>>>顺丰内部车辆24W~信息数据>>>>>" + o_sf_sql)
    logger.error(">>>>全国重货500w~信息数据>>>>>" + o_avg_sql)

    val add_sf_cols = getQuantile("_sf")
    val agg_sf_cols = aggQuantile("task_subid", "_sf")
    val o_sf_df = spark.sql(o_sf_sql)
      .withColumn("asc_flag", row_number().over(Window.partitionBy("category").orderBy('actual_run_time.cast("double").asc)))
      .withColumn("desc_flag", row_number().over(Window.partitionBy("category").orderBy('actual_run_time.cast("double").desc)))
      .filter('asc_flag > 2 && 'desc_flag > 2)
      .withColumn("num", row_number().over(Window.partitionBy("dist_block").orderBy('avg_speed.cast("double").asc)))
      .withColumn("max_num", max("num").over(Window.partitionBy("dist_block").orderBy(desc("num"))))
      .withColumn("quantile", 'num / 'max_num)

    val o_sf_cols = o_sf_df.schema.map(_.name).map(col)

    val res_sf_df = o_sf_df.select(o_sf_cols ++ add_sf_cols: _*)
      .groupBy("dist_block", "speed_std_sf")
      .agg(agg_sf_cols.head, agg_sf_cols.tail: _ *)

    //全国数据指标求算
    val add_hy_cols = getQuantile("_hy")
    val agg_hy_cols = aggQuantile("key_id", "_hy")
    val o_hy_df = spark.sql(o_avg_sql)
      .withColumn("num", row_number().over(Window.partitionBy("dist_block").orderBy('avg_speed.cast("double").asc)))
      .withColumn("max_num", max("num").over(Window.partitionBy("dist_block").orderBy(desc("num"))))
      .withColumn("quantile", 'num / 'max_num)

    val o_hy_cols = o_hy_df.schema.map(_.name).map(col)
    val res_hy_df = o_hy_df.select(o_hy_cols ++ add_hy_cols: _*)
      .groupBy("dist_block")
      .agg(agg_hy_cols.head, agg_hy_cols.tail: _ *)
    val res_cols = spark.sql(s"""select * from dm_gis.speed_compare_sf_hy limit 0""").schema.map(_.name).map(col)
    val res_df = res_sf_df.join(res_hy_df, Seq("dist_block"), "left")
      .withColumn("time_period", lit(start_day + "-" + end_day))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*).persist()
    writeToHive(spark, res_df.coalesce(1), Seq("inc_day"), "dm_gis.speed_compare_sf_hy")
    //拆分后入库
    takeApart(spark, res_df)
  }

  def takeApart(spark: SparkSession, df: DataFrame): Unit = {
    val res_cols = spark.sql(s"""select * from dm_gis.speed_compare_sf_hy_2 limit 0""").schema.map(_.name).map(col)
    val df1 = df
      .withColumn("source", lit("顺丰"))
      .selectExpr("dist_block", "source",
        "speed_std_sf speed_std",
        "num_sf	num",
        "act_speed_sf	act_speed",
        "top_90_sf	top_90",
        "top_80_sf	top_80",
        "top_70_sf	top_70",
        "top_60_sf	top_60",
        "top_50_sf	top_50",
        "top_40_sf	top_40",
        "top_30_sf	top_30",
        "top_20_sf	top_20",
        "top_15_sf	top_15",
        "top_10_sf	top_10",
        "top_5_sf	top_5",
        "time_period", "inc_day"
      ).select(res_cols: _*)
    val df2 = df
      .withColumn("source", lit("行业"))
      .withColumn("speed_std", lit("/"))
      .selectExpr("dist_block", "source", "speed_std",
        "num_hy	num",
        "act_speed_hy	act_speed",
        "top_90_hy	top_90",
        "top_80_hy	top_80",
        "top_70_hy	top_70",
        "top_60_hy	top_60",
        "top_50_hy	top_50",
        "top_40_hy	top_40",
        "top_30_hy	top_30",
        "top_20_hy	top_20",
        "top_15_hy	top_15",
        "top_10_hy	top_10",
        "top_5_hy	top_5",
        "time_period", "inc_day"
      ).select(res_cols: _*)
    val res_df = df1.union(df2)
    writeToHive(spark, res_df.coalesce(1), Seq("inc_day"), "dm_gis.speed_compare_sf_hy_2")

  }


  def aggQuantile(count_cols: String, suffix: String): Seq[Column] = {
    val agg_cols_str = Seq(count_cols, "avg_speed") ++ Seq("top_90", "top_80", "top_70", "top_60", "top_50", "top_40", "top_30", "top_20", "top_15", "top_10", "top_5").map(_ + suffix)
    val new_cols_str = Seq("num", "act_speed", "top_90", "top_80", "top_70", "top_60", "top_50", "top_40", "top_30", "top_20", "top_15", "top_10", "top_5").map(_ + suffix)
    val new_agg_cols_str = agg_cols_str.map(x => {
      if (x == count_cols) {
        count(x)
      } else if (x == "avg_speed") {
        avg(x).cast("int")
      } else {
        max(x).cast("int")
      }
    })
    ColumnUtil.renameColumn(new_agg_cols_str, new_cols_str)
  }

  def getQuantile(suffix: String): Seq[Column] = {
    val res_cols_str = Seq("top_90", "top_80", "top_70", "top_60", "top_50", "top_40", "top_30", "top_20", "top_15", "top_10", "top_5").map(_ + suffix)
    val value = Seq(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.85, 0.90, 0.95).map(_ * 100)
    val v_cols = value.map(x => when(floor(col("quantile").cast("Double") * 100) === x, col("avg_speed")).otherwise(0))
    ColumnUtil.renameColumn(v_cols, res_cols_str)
  }

  def getDisBlockUdf = udf((all_dist: String) => {
    val dis_db = try {
      all_dist.toDouble.abs
    } catch {
      case e: Exception => 0.0
    }
    val dis_highspeed_block = dis_db match {
      case x if x >= 50 && x < 100 => "50-100"
      case x if x >= 100 && x < 200 => "100-200"
      case x if x >= 200 && x < 500 => "200-500"
      case x if x >= 500 && x < 1000 => "500-1000"
      case x if x >= 1000 => "1000+"
    }
    dis_highspeed_block
  })

  def getAllDurationUdf = udf((non_highspeed_dist: String, highspeed_duration: String, tl_duration_2: String) => {
    val non_hy_tm = try { //h
      non_highspeed_dist.toDouble / 35.0
    } catch {
      case e: Exception => 0.0
    }
    val hy_tm = try { //h
      (highspeed_duration.toDouble - tl_duration_2.toDouble) / 60.0
    } catch {
      case e: Exception => 0.0
    }
    val relax_inter = ((non_hy_tm + hy_tm) / 4.0).toInt
    val all_duration = non_hy_tm * 60 + hy_tm * 60 + relax_inter * 20
    all_duration.formatted("%.2f")
  })

  def getNonDistUdf = udf((highspeed_dist: String) => {
    var non_highspeed_dist: Double = 0.0
    if (strNotNull(highspeed_dist)) {
      val highspeed_dist_db = try {
        highspeed_dist.toDouble
      } catch {
        case e: Exception => 0.0
      }
      try {
        non_highspeed_dist = highspeed_dist_db match {
          case x if x >= 50 && x < 100 => x * 0.35
          case x if x >= 100 && x < 200 => x * 0.14
          case x if x >= 200 && x < 500 => x * 0.07
          case x if x >= 500 && x < 1000 => x * 0.03
          case x if x >= 1000 => x * 0.015
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    non_highspeed_dist.formatted("%.2f")
  })

}
