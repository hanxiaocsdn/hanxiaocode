package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.getETADevMysqlConnect
import utils.SparkBuilder

/**
 * @description: GIS-RSS-ETA：油耗数据同步到bdp_V1.0
 * @author 01418539 caojia
 * @date 2022/5/18 10:28
 */
object LoadVehicleMysqlToHive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val dbName = "rosopreta"
    val bdpDBName ="dm_gis"
    val tName = "tb_iot_driving_data,tb_iot_driving_behavior_data,tb_iot_daily_report_data"

    //查询表结构 及 总数量
    queryTable(dbName, tName)
    //向hive中导数 数据库表和bdp平台表名需一致
    processLoad(spark,tName,bdpDBName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def queryTable(dbName: String, tName: String): Unit = {
    val conn = getETADevMysqlConnect()
    queryTable(conn, dbName, tName)
  }

  def processLoad(spark: SparkSession, tName: String, bdpDBName: String): Unit = {
    val arr = tName.replaceAll("'", "").split(",")
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      updateHive(spark, tableName, bdpDBName)
    }
  }

  def updateHive(spark: SparkSession, tName: String, bdpDBName: String): Unit = {
    val bdpTSchema: String = spark.sql(s"select * from $bdpDBName.$tName limit 1").schema.toList.map(_.name).filter(x => !x.contains("inc_day")).mkString(",")
    val query_state = s"(select $bdpTSchema,replace(substring(create_time,1,7),'-','') as inc_day from $tName) as t"

    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://rosopr-m.db.sfcloud.local:3306/rosopreta?useUnicode=true&characterEncoding=utf-8",
      "user" -> "rosopreta",
      "password" -> "steve@1234",
      "dbtable" -> query_state
    )
    try {
      val df = spark.read.format("jdbc").options(params).load()
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        df.createOrReplaceTempView("tmpTableName") //临时表
        spark.sql(s"use $bdpDBName")
        spark.sql(String.format(s"insert overwrite table $tName partition(inc_day) select * from %s", "tmpTableName"))
      } else {
        throw new Exception(s"mysql的 $tName 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向bdp平台的 hive表 $tName 中 插入数据时出现错误", ex)
        throw ex
    }
  }
}
