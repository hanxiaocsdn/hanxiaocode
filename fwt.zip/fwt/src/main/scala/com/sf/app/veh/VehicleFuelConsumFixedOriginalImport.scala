package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, concat_ws}
import utils.SparkBuilder

/**
 * @task_id: 临时
 * @description: 原点油站推荐配置表 dm_gis.oil_station_conf_info  excel格式数据导入
 * @demander:01412994 韩杰
 * @author 01418539 caojia
 * @date 2023/2/20 12:38
 */
object VehicleFuelConsumFixedOriginalImport extends DataSourceCommon{
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val file_name = args(0)
    processLoadExcel(spark,file_name)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processLoadExcel(spark: SparkSession,file_name:String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql(s"""select * from dm_gis.oil_station_conf_info limit 0""").schema.map(_.name).map(col)

    val chat_df = spark.read.format("com.crealytics.spark.excel")
      .option("useHeader", "true") //是否首行为元数据
      .load("/user/01418539/upload/file/oil/"+file_name)
      .select(res_cols: _*)

    writeToHive(spark, chat_df.coalesce(2), Seq("inc_day"), "dm_gis.oil_station_conf_info")

  }

}
