package com.sf.app.track

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.vividsolutions.jts.io.WKTReader
import org.apache.commons.net.ftp.{FTPFile, FTPFileFilter}
import org.apache.hadoop.fs.Path
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{SparkConf, SparkContext}
//import org.geotools.data.shapefile.ShapefileDataStore
import org.geotools.data.simple.SimpleFeatureIterator
import org.geotools.data.{DataStore, DataStoreFinder}
import org.geotools.factory.CommonFactoryFinder
import org.geotools.geometry.jts.JTSFactoryFinder
import java.io.{ File, FileInputStream, FileNotFoundException}
import java.net.URLDecoder
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.concurrent.{Callable, Executors, TimeUnit}
import java.util.{Calendar, Date, Properties, UUID}
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.io.Source
import scala.sys.process._


/**
 * Created by 01366807 on 2017/5/8.
 */
object Util {
    val properties = new java.util.Properties()
    var sc:SparkContext = null
    var spark:SparkSession = null
    var defaultPartitionSize = 100
    var defaultAppName = this.getClass.getSimpleName

    //  var bashLock = false
    var bashInited = false


    def defaultSparkConf()={
        System.setProperty("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
        val conf = new SparkConf().setAppName("appName")
          .set("spark.cores.max", "4")
          .set("spark.port.maxRetries", "999")
          .set("spark.driver.allowMultipleContexts", "true")
          .set("spark.streaming.stopGracefullyOnShutdown", "true")
          //长期存在于NodeManager进程中的一个辅助服务。通过该服务来抓取shuffle数据，减少了Executor的压力，在Executor GC的时候也不会影响其他Executor的任务运行
          .set("spark.shuffle.service.enabled", "true")
          .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
          .set("spark.io.compression.codec", "org.apache.spark.io.SnappyCompressionCodec")
          .set("spark.kryoserializer.buffer.max", "128m")
          .set("spark.network.timeout", "600s")
          .set("spark.executor.memoryOverhead", "16G")
          .set("spark.yarn.executor.memoryOverhead", "8G")
          .set("spark.driver.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
          .set("spark.executor.extraJavaOptions", "-XX:-DisableExplicitGC -XX:-UseGCOverheadLimit -XX:PermSize=2048M -XX:MaxPermSize=14000M")
          .set("spark.rpc.askTimeout", "600s")
          .set("spark.shuffle.compress", "true")
          .set("spark.sql.hive.mergeFiles", "true")
          .set("spark.sql.adaptive.enabled", "true")
          .set("spark.sql.adaptive.coalescePartitions.enabled", "true")
          .set("hive.exec.dynamici.partition", "true") //开启动态分区
          .set("hive.exec.dynamic.partition.mode", "nonstrict") //开启动态分区
          .set("spark.sql.sources.partitionOverwriteMode", "dynamic") //开启动态分区
          .set("hive.orc.splits.include.file.footer", "true") //是否将元数据保存在orc文件中
          .set("hive.exec.orc.default.stripe.size", "268435456") //默认256M
          .set("hive.exec.orc.split.strategy", "BI") //参数控制在读取ORC表时生成split的策略。BI策略以文件为粒度进行split划分；ETL策略会将文件进行切分，多个stripe组成一个split；HYBRID策略为：当文件的平均大小大于hadoop最大split值（默认256 * 1024 * 1024）时使用ETL策略，否则使用BI策略。
          .set("spark.sql.hive.convertMetastoreOrc", "true") //开启矢量化
          .set("spark.sql.orc.enableVectorizedReader", "true") //开启矢量化 ,矢量化需要100列内,并且字段是基本字段,非null arrays等
          .set("spark.sql.crossJoin.enabled", "true") //开启笛卡尔积
          .set("spark.sql.orc.filterPushdown", "true") //谓词下推
          .set("spark.sql.broadcastTimeout", "1200") //增加获取广播变量超时时间
          .set("hive.exec.dynamic.partition", "true")
          .set("hive.exec.dynamic.partition.mode", "nonstrict")
          .set("hive.exec.max.dynamic.partitions", "10000")
          .set("hive.exec.max.dynamic.partitions.pernode", " 10000")
          .set("hive.exec.max.created.files", " 1000000")
          .set("hive.merge.mapredfiles", "true")
          .set("hive.merge.mapfiles", "true")
          .set("hive.merge.size.per.task", "134217728")
          .set("hive.merge.smallfiles.avgsize", "134217728")
          .set("mapreduce.input.fileinputformat.split.maxsize", "134217728")
          .set("mapreduce.input.fileinputformat.split.minsize.per.rack", "134217728")
          .set("mapreduce.input.fileinputformat.split.minsize.per.node", "134217728")
          .set("hive.merge.sparkfiles", "true")

        conf
    }
    def initSpark(appName:String=this.getClass.getSimpleName,initConf:SparkConf=null,cleanEnv:Boolean=true) ={
        if(Util.spark == null || Util.spark.sparkContext==null || Util.spark.sparkContext.isStopped){
            Util.memTime()
            defaultAppName = appName//MD5Util.getMD5(appName)
            val conf = if(initConf == null) defaultSparkConf().setAppName(defaultAppName) else initConf.setAppName(defaultAppName)

            spark = SparkSession.builder.config(conf).enableHiveSupport.getOrCreate

            sc=spark.sparkContext
            sc.setLogLevel("ERROR")
            defaultPartitionSize = sc.getConf.get("spark.executor.instances", "16").toInt * sc.getConf.get("spark.executor.cores", "2").toInt * 2


            spark.sql("set dfs.client.read.shortcircuit=false")
            spark.sql("set spark.sql.thriftserver.scheduler.pool=spark")
            spark.sql("set mapred.max.split.size=1000000000")
            spark.sql("set mapred.min.split.size.per.node=1000000000")
            spark.sql("set mapred.min.split.size.per.rack=1000000000")
            spark.sql("set hive.fetch.task.conversion=more")
            spark.sql("set hive.cli.print.header=true")
            spark.sql("set hive.execution.engine=mr")
            spark.sql("set hive.exec.mode.local.auto=false")
            spark.sql("set hive.exec.reducers.max=500")
            spark.sql("set hive.exec.compress.output=false")
            spark.sql("set hive.exec.compress.intermediate=true")
            spark.sql("set hive.exec.dynamic.partition=true")
            spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")
            spark.sql("set hive.exec.max.dynamic.partitions=100000")
            spark.sql("set hive.exec.max.dynamic.partitions.pernode=100000")
            spark.sql("set hive.groupby.skewindata=true")
            spark.sql("set hive.auto.convert.join=true")
            spark.sql("set hive.metastore.schema.verification=false")
            spark.sql("set hive.input.format=org.apache.Hadoop.hive.ql.io.CombineHiveInputFormat")
            spark.sql("set hive.merge.mapfiles=true")
            spark.sql("set hive.merge.mapredfiles=true")
            spark.sql("set hive.merge.size.per.task=1000000000")
            spark.sql("set hive.merge.smallfiles.avgsize=1000000000")
            spark.sql("set spark.sql.shuffle.partitions=50")
            spark.sql("set parquet.block.size=268435456") //256m


            spark.conf.getAll.foreach(d=>{
                println(s"${d._1}: ${d._2}")
            })
            println("--------------------------------------------------------------------")
            println("今日星期："+Util.getWeek(Util.getTodayDayid()))
        }

        spark
    }
    def stopSpark(cleanEnv:Boolean=true): Unit ={
        if(spark!=null && !spark.sparkContext.isStopped){
            try{
                spark.sparkContext.stop()
                spark = null
            }catch {
                case e:Exception =>{
                    Util.printException(e)
                }
            }
        }
    }

    def reInitSpark(): Unit ={
        stopSpark()
        initSpark(appName = defaultAppName)
    }

    def freeMem(keep:RDD[_]*): Unit ={
        clearGroupByQueryCache()

        Util.spark.catalog.clearCache()
        var cnt = 0 //Util.spark.sparkContext.getPersistentRDDs.size
        //System.err.println("----------------------------------------【清除缓存RDD开始】------------------------------------------")
        Util.spark.sparkContext.getPersistentRDDs.foreach(d=>{
            //System.err.println("清除缓存RDD："+d._2.toString())
            if(keep.isEmpty || !keep.contains(d._2)){
                d._2.unpersist()
                cnt += 1
            }
        })
        //System.gc()
        //System.err.println("----------------------------------------【清除缓存RDD完成】------------------------------------------")
        System.err.println(s"【清除缓存RDD数量：${cnt}】")
    }

    def hdfsFile2ftp(hdfsPath:String,fileName:String,ftpPath:String): Unit ={
        Util.runShellCmd(s"hdfs dfs -getmerge $hdfsPath ./$fileName")
        Util.runShellCmd(s"tar czf ./$fileName.tgz $fileName")
        Util.ftpUpload(new File(s"./$fileName.tgz").getAbsolutePath,ftpPath)
        Util.runShellCmd(s"./rm -rf ./$fileName*")
    }

    def hdfsPath2ftp(hdfsPath:String,ftpPath:String): Unit ={
        val treadCount = 10
        val executorService = Executors.newFixedThreadPool(treadCount)
        val list = new java.util.ArrayList[Callable[Void]]()

        Util.runShellCmd(s"hdfs dfs -ls $hdfsPath").split("\n").filter(_.contains("/")).foreach(d=>{
            list.add(new Callable[Void] {
                val head = if(d.indexOf("hdfs://") != -1) "hdfs://" else "/user/hive/warehouse"
                val hdfs = d.substring(d.indexOf(head))
                val fn = d.substring(d.lastIndexOf("/")+1)
                override def call(): Void = {
                    Util.runShellCmd(s"./rm -rf $fn")
                    Util.runShellCmd(s"hdfs dfs -get $hdfs .")
                    Util.ftpUpload(new File(s"./$fn").getAbsolutePath,ftpPath,sync=false)
                    Util.runShellCmd(s"./rm -rf $fn")
                    null
                }
            })
        })

        executorService.invokeAll(list)
        executorService.shutdown()
        executorService.awaitTermination(365,TimeUnit.DAYS)
    }

    def getConf(key:String,default:String=""): String ={
        //Util.spark.conf.getAll.toArray.sortBy(_._1).foreach(d=>println(d._1+" = "+d._2))
        try{
            val t = Util.spark.conf.get(key)
            if(t == null){
                println(s"[WARN] 未指定参数值 $key，返回默认值 $default")
                default
            }else t
        }catch{
            case e:Exception=>{
                println(s"[WARN] 未指定参数值 $key，返回默认值 $default")
                default
            }
        }

    }

    def sql2ftp(spark: SparkSession,sql:String,header:String,fileName:String,ftpPath:String,delimiter:String=",",tgz:Boolean=false,unpersist:Boolean=true,printSchema:Boolean=false,partitionSize:Int=100) = {
        //Util.runShellCmd("./rm -rf ./sql2ftp*")
        //Util.runShellCmd("./rm -rf ./*.csv")
        val sb = new mutable.StringBuilder()
        val df = spark.sql(sql).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
        if(printSchema)
            df.printSchema()
        val columns = df.columns.mkString(delimiter)
        if(header!=null && header!="") {
            if (header != "none")
                sb.append(header + "\n")
        }
        else
            sb.append(columns+"\n")

        FileUtil.save("./"+fileName+".title",sb.toString())

//        df.rdd.map(_.mkString(delimiter)+"\n").collect().foreach(sb.append(_))
//        FileUtil.save("./"+fileName,sb.toString())
        val expfile = "sql2ftp_"+UUID.randomUUID()
        val hdfspath = s"/user/hive/warehouse/tmp_dm_gis.db/$expfile"
        df.rdd.repartition(partitionSize).map(_.mkString(delimiter)+"\n").saveAsTextFile(hdfspath)
        if(header=="none")
            Util.runShellCmd(s"hdfs dfs -getmerge $hdfspath ./$fileName")
        else {
            Util.runShellCmd(s"hdfs dfs -getmerge $hdfspath ./$expfile")
            Util.runShellCmd(s"ls -l ./$expfile")
            //Util.runShellCmd(s"cat $fileName.title $expfile > $fileName")
            try{
                FileUtil.save(s"./$fileName",sb.toString()+FileUtil.readFileByLines(s"$expfile",true))
            }catch {
                case e:Exception=>{
                    Util.runShellCmd(s"rm -rf ./$fileName")
                    Util.runShellCmd(s"mv $expfile $fileName")
                    println("【WARN】header 添加失败："+columns)
                }
            }
        }

        //FileUtil.appendToFile("./"+fileName,FileUtil.readFileByLines(s"./$expfile",true))

        Util.runShellCmd(s"ls -l ./$fileName")
        if(tgz){
            Util.runShellCmd(s"tar czf $fileName.tgz $fileName")
            Util.runShellCmd(s"ls -l ./$fileName.tgz")
            Util.ftpUpload(new File("./"+fileName+".tgz").getAbsolutePath,ftpPath)
            Util.runShellCmd("./rm -rf ./"+fileName+".tgz")
        }else{
            Util.ftpUpload(new File("./"+fileName).getAbsolutePath,ftpPath)
        }

        Util.runShellCmd("./rm -rf ./"+fileName)
        Util.runShellCmd("./rm -rf ./"+expfile)
        Util.runShellCmd(s"hdfs dfs -rm -r -f $hdfspath")
        if(unpersist)
            df.unpersist()
        df
    }

    def broadcast(sql: String, title: String, storageLevel: StorageLevel=null,minBatchSize:Int=0) = {
        println(sql)
        var df = Util.spark.sql(sql).repartition(Util.defaultPartitionSize*2)
        if(storageLevel!=null) df.persist(storageLevel) else df.persist(StorageLevel.MEMORY_AND_DISK_SER)
        df.createOrReplaceTempView("b_df")
        spark.catalog.cacheTable("b_df")
        var bcnt = df.count
        var bSize = Math.ceil(bcnt.toDouble / (2097152 / 4).toDouble).toInt
        if(minBatchSize>0)
            bSize = Math.max(bSize,minBatchSize)
        Util.showCost(s"【$title】待广播记录数：${bcnt}，批量：$bSize")

        var bc = 0l
        val ret:mutable.HashMap[String,Broadcast[scala.collection.Map[String,String]]] = new mutable.HashMap[String,Broadcast[scala.collection.Map[String,String]]]()
        //单线程模式
        //    (0 to bSize-1).foreach(i=>{
        //      val t = df.rdd.filter(d=>{
        //        var t = d.getString(0).hashCode % bSize
        //        if(t<0) t += bSize
        //        t == i
        //      }).map(d=>(d.getString(0),d.getString(1))).collectAsMap()
        //      val b = try{
        //        Util.spark.sparkContext.broadcast(t)
        //      }catch{
        //        case e:Exception=>{
        //          Util.spark.sparkContext.broadcast(t)
        //        }
        //      }
        //      bc += t.size
        //      Util.showCost(s"【$title 批次：$i 广播完毕】，记录数：${t.size} / ${bc} / ${bcnt}")
        //      ret.put(i.toString,b)
        //    })

        //多线程模式
        val executorService = Executors.newFixedThreadPool(20)
        val list = new java.util.ArrayList[Callable[Void]]()
        (0 to bSize-1).foreach(i=>{
            val idx = i+0

            list.add(new Callable[Void] {
                override def call(): Void = {
                    this.synchronized{
                        try{
                            val id = idx
                            val bsize = bSize

                            val t = spark.sql("select * from b_df").rdd.filter(d=>{
                                var t = d.getString(0).hashCode % bsize
                                if(t<0) t += bsize
                                t == id
                            }).map(d=>(d.getString(0),d.getString(1))).collectAsMap()
                            val b = try{
                                Util.spark.sparkContext.broadcast(t)
                            }catch{
                                case e:Exception=>{
                                    Util.spark.sparkContext.broadcast(t)
                                }
                            }
                            bc += t.size
                            Util.showCost(s"【$title 批次：${id+1} / $bsize 广播完毕】，记录数：${t.size} / ${bc} / ${bcnt}")
                            ret.put(id.toString,b)
                        }catch{
                            case e:Exception=>{
                                System.err.println(e.getMessage+"\t"+e.getCause)
                                e.printStackTrace(System.err)
                            }
                        }
                    }
                    null
                }
            })
        })

        executorService.invokeAll(list)
        executorService.shutdown()
        spark.catalog.uncacheTable("b_df")

        Util.showCost(s"【$title 广播完毕】")
        if(storageLevel==null)
            df.unpersist()
        (ret,if(storageLevel!=null)df else null)
    }

    def unbroadcast(bc:mutable.HashMap[String,Broadcast[collection.Map[String,String]]]): Unit ={
        bc.keys.foreach(k=>{
            val v = bc.getOrElse(k,null)
            if(v!=null){
                v.unpersist(blocking = true)
                v.destroy()
            }
        })
        bc.clear()
    }

    def tryPost(url:String,para:String,tryTimes:Int,currentTrys:Int=0,msgLength:Int= -1):String = {
        // --jars httpclient-4.5.3.jar
        var result:String = null
        try{
            result = HttpRequest.sendPost(url,para)
        }catch{
            case e:Exception=>{
                if(msgLength== -1)
                    System.err.println("++++++++++++++++++++++++++++++++\n"+para)
                else if(msgLength>0){
                    System.err.println("--------------------------------"+(para.substring(0,Math.min(para.length,msgLength))))
                }
                Util.printException(e)
                if(currentTrys<tryTimes){
                    val wait = (currentTrys+1) * 2
                    //System.err.println("retry waiting seconds: "+ wait)
                    Thread.sleep(wait * 500)
                    result = tryPost(url,para,tryTimes,currentTrys+1,msgLength)
                }
            }
        }
        result
    }

    case class PostDebug(result:String,err:String)
    def tryPostDebug(url:String,para:String,tryTimes:Int,currentTrys:Int=0,msgLength:Int= -1,throwExecption:Boolean=false):PostDebug = {
        // --jars httpclient-4.5.3.jar
        var err:String = null
        var result:String = null
        try{
            result = HttpRequest.sendPost(url,para)
        }catch{
            case e:Exception=>{
                if(e.getMessage!=null)
                    err = e.getMessage
                if(e.getCause!=null){
                    if(err == null)
                        err = e.getCause.toString
                    else
                        err += "\t"+e.getCause.toString
                }
                //err = "tryPostDebug: "+e.getMessage+"\n"+e.getCause
                if(msgLength== -1)
                    System.err.println("++++++++++++++++++++++++++++++++\n"+para)
                else if(msgLength>0){
                    System.err.println("--------------------------------"+(para.substring(0,Math.min(para.length,msgLength))))
                }
                if(currentTrys<tryTimes){
                    //System.err.println("retry waiting seconds: "+(currentTrys+1))
                    Thread.sleep((currentTrys+1)*500)
                    result = tryPost(url,para,tryTimes,currentTrys+1,msgLength)
                }else if(throwExecption)
                    throw e
            }
        }
        PostDebug(result,err)
    }

    def tryPostWithDetail(url:String,para:String,tryTimes:Int,currentTrys:Int=0,msgLength:Int= -1):(String,String,String,String) = {
        // --jars httpclient-4.5.3.jar
        var result:(String,String,String,String) = null
        var ret:String = null
        var err:String = null
        try{
            ret = HttpRequest.sendPost(url,para)
            (url,para,ret,err)
        }catch{
            case e:Exception=>{
                if(msgLength== -1)
                    System.err.println("++++++++++++++++++++++++++++++++\n"+para)
                else if(msgLength>0){
                    System.err.println("--------------------------------"+(para.substring(0,Math.min(para.length,msgLength))))
                }
                err = "e.getMessage:\n"+e.getMessage+"\n"
                System.err.println("--------------------------------")
                System.err.println(err)
                System.err.println("--------------------------------")
                e.printStackTrace()
                if(currentTrys<tryTimes){
                    //System.err.println("retry waiting seconds: "+(currentTrys+1))
                    Thread.sleep((currentTrys+1)*500)
                    result = tryPostWithDetail(url,para,tryTimes,currentTrys+1,msgLength)
                }else{
                    result = (url,para,ret,err)
                }
                result
            }
        }
    }

    def tryGet(url:String,tryTimes:Int,currentTrys:Int=0,responseEncode:String="utf-8"):String = {
        // --jars httpclient-4.5.3.jar

        var result:String = null
        try{
            //result = HttpRequest.sendGet(url)
            result = HttpRequest.sendGetEncode(url,responseEncode)
        }catch{
            case e:Exception=>{
                if(currentTrys == tryTimes-1) {
                    System.err.println("【REQ】"+url)
                    System.err.println("【RST】"+result)
                }

                if(currentTrys<tryTimes){
                    //System.err.println("retry waiting seconds: "+(currentTrys+1))
                    Thread.sleep((currentTrys+1)*1000)
                    result = tryGet(url,tryTimes,currentTrys+1,responseEncode)
                }
            }
        }
        result
    }

    def ftpUpload(srcFilePath:String,ftpPath:String,sync:Boolean=true): Unit ={
        if(sync){
            this.synchronized{
                val ftpUtil = new FTPUtil("gisftp.sf-express.com", Integer.parseInt("21"), "devftp", "brYsj2.023ftKjdev");
                ftpUtil.ftpLogin()
                ftpUtil.uploadFile(new File(srcFilePath),ftpPath)
                ftpUtil.ftpLogOut()
            }
        }else{
            val ftpUtil = new FTPUtil("gisftp.sf-express.com", Integer.parseInt("21"), "devftp", "brYsj2.023ftKjdev");
            ftpUtil.ftpLogin()
            ftpUtil.uploadFile(new File(srcFilePath),ftpPath)
            ftpUtil.ftpLogOut()
        }
    }

    def ftpDeleteFile(ftpPath:String): Unit ={
        this.synchronized{
            val ftpUtil = new FTPUtil("gisftp.sf-express.com", Integer.parseInt("21"), "devftp", "brYsj2.023ftKjdev");
            ftpUtil.ftpLogin()
            ftpUtil.ftpClient.deleteFile(ftpPath)
            ftpUtil.ftpLogOut()
        }
    }

    def ftpDownloadFile(fname:String,path:String,remotePath:String): Unit ={
        this.synchronized{
            val ftpUtil = new FTPUtil("gisftp.sf-express.com", Integer.parseInt("21"), "devftp", "brYsj2.023ftKjdev");
            ftpUtil.ftpLogin()
            ftpUtil.downloadFile(fname,path,remotePath)
            ftpUtil.ftpLogOut()
        }
    }

    def ftpList(matchStr:String,remotePath:String,like:Boolean=true)={
        this.synchronized{
            val ftpUtil = Util.ftpUtil()
            val ftpFiles = ftpUtil.ftpClient.listFiles(remotePath,new FTPFileFilter {
                override def accept(ftpFile: FTPFile): Boolean = {
                    if(like)
                        ftpFile.getName.contains(matchStr)
                    else
                        ftpFile.getName==matchStr
                }
            })
            ftpUtil.ftpLogOut()
            ftpFiles
        }
    }

    def ftpUtil()={
        val ftpUtil = new FTPUtil("gisftp.sf-express.com", Integer.parseInt("21"), "devftp", "brYsj2.023ftKjdev");
        ftpUtil.ftpLogin()
        ftpUtil
    }

    var t0 = 0l
    var t0Total = 0l
    def memTime() = {
        t0 = new Date().getTime
    }
    def showCost(title:String="",enter:Boolean=true)={
        val mss = new Date().getTime - t0
        val s = formatTime(mss)
        System.err.println((if(title.indexOf("耗时")== -1) title+"，耗时：" else title)+s + (if(enter)"\n" else ""))
        Util.memTime()
        s
    }
    def memTimeTotal() = {
        t0Total = new Date().getTime
        memTime()
    }
    def showCostTotal(title:String="")={
        val mss = new Date().getTime - t0Total
        val s = formatTime(mss)
        System.err.println((if(title.indexOf("总耗时")== -1) title+"，总耗时：" else title)+s+"\n")
        Util.memTimeTotal()
        s
    }
    def formatTime(mss:Long,showCurrentTime:Boolean = true) ={
        val days = mss / (1000 * 60 * 60 * 24)
        val hours = (mss % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
        val minutes = (mss % (1000 * 60 * 60)) / (1000 * 60)
        val seconds = (mss % (1000 * 60)) / 1000
        var s = if(days>0) days+"天 " else ""
        s = s + (if(hours>0) hours+"小时 " else "")
        s = s + (if(minutes>0) minutes+"分钟 " else "")
        s = s + (if(seconds>0) seconds+"秒" else (mss % (1000 * 60) + "毫秒"))
        if(showCurrentTime)
            s = s + " ["+new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime())+"]"
        s
    }

    def formatFileSize(size:Long):String = {
        if(size > 1024 * 1024 * 1024){
            (Math.round(size.toDouble / 1024.0 / 1024.0 / 1024.0 * 10.0) / 10.0) +"G"
        }else if(size > 1024 * 1024){
            (Math.round(size.toDouble / 1024.0 / 1024.0 * 10.0) / 10.0) + "M"
        }else if(size > 1024){
            (Math.round(size.toDouble / 1024.0 * 10.0) / 10.0).toString + "K"
        }else{
            size + "B"
        }
    }
    def randomPassword(length:Int,chars:String="abcdefghijkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#$%^&*"): String ={
        var randomChars = ""
        (1 to length).foreach(x=>{
            var i = Math.floor(Math.random() * chars.length).toInt
            randomChars = randomChars + chars.charAt(i)
        })
        randomChars
    }

    def monthDiff(month_from: String, month_to: String) = {
        var diff = 0
        var m = month_from
        while(m < month_to){
            diff += 1
            m = Util.addMonth(month_from+"01",diff).replaceAll("-","").substring(0,6)
            //println(diff+"\t"+m)
        }
        diff
    }

    def daysDiff(fromDay:String,endDay:String) ={
        val from = fromDay.replaceAll("-","")
        val to = endDay.replaceAll("-","")
        var t = from
        val begintm = Calendar.getInstance()
        begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)

        t = to
        val endtm = Calendar.getInstance()
        endtm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)

        val millis = endtm.getTimeInMillis - begintm.getTimeInMillis
        millis / 24 / 60 / 60 / 1000
    }

    def getWeek(dayid:String) ={
        val t = dayid.replaceAll("-","")
        val begintm = Calendar.getInstance()
        begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)
        begintm.getTime().getDay
    }

    def getYesterdayDate():String={
        //    var nowdate = LocalDate.now()
        //    nowdate.minusDays(1).toString()
        var cal:Calendar=Calendar.getInstance()
        cal.add(Calendar.DATE,-1)
        new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime())
    }

    def getYesterdayDayid()={
        getYesterdayDate().replaceAll("-","")
    }

    def getDayid(dx:Int=0):String={
        val cal:Calendar=Calendar.getInstance()
        cal.add(Calendar.DATE,dx)
        new SimpleDateFormat("yyyyMMdd").format(cal.getTime())
    }

    def getHour() ={
        now().split(" ")(1).split(":")(0)
    }

    def now(): String ={
        new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(Calendar.getInstance().getTime())
    }

    def addDay(dayid:String,step:Int) ={
        val t = dayid.replaceAll("-","")
        val begintm = Calendar.getInstance()
        begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)
        begintm.add(Calendar.DATE,step)
        new SimpleDateFormat("yyyy-MM-dd").format(begintm.getTime())
    }

    def addMonth(dayid:String,step:Int) ={
        val t = dayid.replaceAll("-","")
        val begintm = Calendar.getInstance()
        begintm.set(t.substring(0,4).toInt,t.substring(4,6).toInt-1,t.substring(6,8).toInt,0,0,0)
        begintm.add(Calendar.MONTH,step)
        new SimpleDateFormat("yyyy-MM-dd").format(begintm.getTime())
    }

    def getMonthEnd(dayid:String=null)={
        val day = if(dayid==null) Util.getTodayDayid() else dayid
        var dayend = day.substring(0,6)+"28"
        while(dayend.substring(0,6) == Util.addDay(dayend,1).replaceAll("-","").substring(0,6)){
            dayend = Util.addDay(dayend,1).replaceAll("-","")
        }
        dayend
    }
    def getToday() ={
        val begintm = Calendar.getInstance()
        new SimpleDateFormat("yyyy-MM-dd").format(begintm.getTime())
    }
    def getTodayDayid() ={
        val begintm = Calendar.getInstance()
        new SimpleDateFormat("yyyyMMdd").format(begintm.getTime())
    }

    def minuteAdd(dayid:String,fromtm:String,step:Int) ={
        val begintm = Calendar.getInstance()
        begintm.set(dayid.substring(0,4).toInt,dayid.substring(4,6).toInt-1,dayid.substring(6,8).toInt,fromtm.substring(0,2).toInt,fromtm.substring(2,4).toInt,0)
        begintm.add(Calendar.MINUTE,step)
        (new SimpleDateFormat("yyyyMMdd").format(begintm.getTime()),new SimpleDateFormat("HHmm").format(begintm.getTime()))
    }
    def minuteAddConcat(dayid:String,fromtm:String,step:Int) ={
        val t = minuteAdd(dayid,fromtm,step)
        t._1+t._2
    }

    def loadConfigInFile(spark: SparkContext,path:String):Properties = {
        //val properties = new Properties()
        try {
            properties.load(new FileInputStream(path))
            System.err.println(properties)
        } catch {
            case e : FileNotFoundException =>
                System.err.println("new FileInputStream("+path+") => FileNotFoundException, try new FileInputStream((new File("+path+")).getName())")
                properties.load(new FileInputStream((new File(path)).getName()))
            case e : Throwable => throw e
        }
        properties
    }

    def loadConfigInJar(path:String):Properties={
        val url = this.getClass.getClassLoader.getResource(path)//"conf.properties"
        System.err.println("==================="+url)
        val source = Source.fromURL(url)
        val prop = source.getLines().toArray.filter(item=>item.trim.length>0&&item.trim.indexOf("#")!=0).map(item=>item.split("=")).foreach(d=>{
            if(d.length==2){
                //System.err.println(d(0)+"="+d(1))
                properties.put(d(0).trim,d(1).trim)
            }else if(d.length==1){
                //System.err.println(d(0)+"=null")
                properties.put(d(0).trim,"")
            }else if(d.length>2){
                val key = d(0)
                var value = d.toIndexedSeq.slice(1,d.length).mkString("","=","")
                //System.err.println(key+"="+value)
                properties.put(key.trim,value.trim)
            }
        })
        properties
    }


    def getProperty(key:String) ={
        val value = properties.getProperty(key)
        if(value==null){
            System.err.println("-------------- WARN Util.getProperty(\""+key+"\") return null --------------")
        }
        value
    }
    def unionProperties(p: Properties): Unit ={
//        properties.putAll(p)
    }
//
//    def shpIdentify(): Unit ={
//        val connectionParameters = new java.util.HashMap[String,java.net.URL]
//        val reader = new WKTReader(JTSFactoryFinder.getGeometryFactory(null))
//        val ff = CommonFactoryFinder.getFilterFactory2(null)
//        connectionParameters.put("url", new File("d:/industry-market-info.shp").toURI.toURL)
//        val geometry = reader.read("POINT(113.2386 22.71447)")
//        val filter = ff.intersects(ff.property("the_geom"), ff.literal(geometry))
//        var features:SimpleFeatureIterator = null
//        val dataStore:DataStore = DataStoreFinder.getDataStore(connectionParameters)
//        (dataStore.asInstanceOf[ShapefileDataStore]).setCharset(Charset.forName("UTF-8"))
//
//        val featureTypes: Array[String] = dataStore.getTypeNames
//        if (featureTypes.length != 1) {
//            System.err.println("featureTypes.length != 1")
//            throw new Exception
//        }
//        features = dataStore.getFeatureSource(featureTypes(0)).getFeatures.subCollection(filter).features()
//        val market = if(features.hasNext){
//            val scname = features.next().getAttribute("scname").toString
//            try{
//                features.close()
//                dataStore.dispose()
//            }catch {
//                case ex:Exception=>{}
//            }
//            scname
//        }else{
//            try{
//                features.close()
//                dataStore.dispose()
//            }catch {
//                case ex:Exception=>{}
//            }
//            ""
//        }
//        System.err.println("============================================================")
//        System.err.println(market)
//    }

    def runHiveSQL(db:String,sql:String,logPath:String=null): Unit ={
        var log = ""
        val sh = "./_runhivesql_"+UUID.randomUUID()+".sh"
        val sqlFile = "./_runhivesql_"+UUID.randomUUID()+".sql"
        var cmd = ""
        if(logPath!=null){
            log = " > "+logPath
        }

        var useSqlFile = false
        val d = "" //"--hiveconf hive.root.logger=OFF -S"
        if(sql.indexOf(";") != -1 || sql.indexOf("\n") != -1){
            FileUtil.save(sqlFile,sql)

            cmd = "/app/hive/bin/hive "+d+" --database "+db+" -f "+sqlFile + log
            System.err.println(sql)
            System.err.println(cmd)
            useSqlFile = true
        }else{
            cmd = "/app/hive/bin/hive "+d+" --database "+db+" -e \""+sql+"\"" +log
            System.err.println(cmd)
        }

        FileUtil.save(sh,cmd)
        //    "chmod +x "+sh !;
        //    sh !;
        //    "./rm -rf "+sh !;
        initBash
        try{
            "./bash "+sh !;
        }catch {
            case e:Exception=>{
                "chmod +x "+sh !;
                sh !;
            }
        }
        new File(sh).deleteOnExit()
        if(useSqlFile)
            try{
                "./rm -rf "+sqlFile !;
            }catch{
                case e:Exception=>{
                    "rm -rf "+sqlFile !;
                }
            }

    }

    def runShellCmd(cmd:String,logPath:String,matchStr:String): Boolean ={
        val log = runShellCmd(cmd,logPath)
        log.contains(matchStr)
    }
    def runShellCmdMatch(cmd:String,logPath:String,matchStr:String,printCmd:Boolean=true,printResult:Boolean=true): Boolean ={
        val log = runShellCmd(cmd,logPath,printCmd,printResult)
        log.contains(matchStr)
    }
    def runShellCmdSilent(cmd:String) = {
        val sh = "./_runShellCmd_"+UUID.randomUUID+".sh"
        FileUtil.save(sh,cmd)
        initBash
        var result = -1
        try{
            result = "./bash "+sh !;
        }catch {
            case e:Exception=>{
                "chmod +x "+sh !;
                sh !;
            }
        }
        if(result == 2){
            System.err.println("===============================")
            System.err.println(s"【$result】"+cmd)
            System.err.println("===============================")
        }
        new File(sh).deleteOnExit()
        result
    }

    def runShellCmd(cmd:String,logPath:String=null,printCmd:Boolean=true,printResult:Boolean=true): String ={
        initBash
        if(printCmd)
            System.err.println(cmd)
        val sh = "./_runShellCmd_"+UUID.randomUUID+".sh"
        val tmplog = "./_tmplog_"+UUID.randomUUID+".txt"
        val logFile = if(logPath!=null && logPath.length>0) logPath else tmplog
        FileUtil.save(sh,cmd + " &>"+logFile)
        //"chmod +x "+sh !;
        try{
            "./bash "+sh !;
        }catch {
            case e:Exception=>{
                "chmod +x "+sh !;
                sh !;
            }
        }
        new File(sh).deleteOnExit()
        //System.err.println("cat "+logFile)
        //"cat "+logFile !;

        val f = new File(logFile)
        if(f.exists()){
            val log = FileUtil.readFileByLines(logFile,false)
            if(logPath==null || logPath.length==0)
                f.delete()
            if(printResult)
                System.err.println(log)
            log
        }else ""
    }
    def sh(cmd:String): Unit ={
        cmd !;
    }

    def getPara(src:String,pre:String,sub:String=null,extSub:String="") ={
        if(src.contains(pre)){
            if(sub==null){
                val finalSub = ",&"+extSub
                var ak = src.substring(src.indexOf(pre)+pre.length)
                //        ak = if(ak.contains(",")) ak.substring(0,ak.indexOf(",")) else ak
                //        ak = if(ak.contains("&")) ak.substring(0,ak.indexOf("&")) else ak
                finalSub.toCharArray.foreach(c=>{
                    ak = if(ak.contains(c.toString)) ak.substring(0,ak.indexOf(c.toString)) else ak
                })
                ak
            }else{
                var ak = src.substring(src.indexOf(pre)+pre.length)
                ak = if(ak.contains(sub)) ak.substring(0,ak.indexOf(sub)) else ak
                ak
            }
        }else{
            ""
        }
    }

    def getDecodePara(src:String,pre:String,sub:String=null) ={
        var s = getPara(src,pre,sub).trim
        if(s == "%") s = "%25"
        s = s.replaceAll("[%]{2}","%25%")
        try{
            URLDecoder.decode(s,"utf8").replaceAll("[\"\t\r\n]*","")
        }catch{
            case e:Exception =>{
                s
            }
        }
    }

    def mysql2hive(driver:String,url:String,uid:String,pwd:String,table:String,sql:String,hdfsPath:String,hiveDB:String,hiveTable:String,partitionBy:String)={
        mysql2hdfs(driver,url,uid,pwd,table,sql,hdfsPath)
        addPartition(hiveDB,hiveTable,partitionBy,hdfsPath)
    }

    def mysql2hdfs(driver:String,url:String,uid:String,pwd:String,table:String,sql:String,hdfsPath:String)={
        if(spark==null) Util.initSpark()
        val reader = spark.read.format("jdbc")
                .option("driver", driver)
                .option("url", url)
                .option("user", uid)
                .option("password", pwd)
                .option("dbtable", table)
        val df = reader.load()
        //df.show()

        val tmpTable = "_tmp_"+table
        df.createOrReplaceTempView(tmpTable)
        val rst = df.sparkSession.sql(sql.replace("${table}",tmpTable)).rdd

        if(!rst.isEmpty()){
            val fn = table+".csv"
            val path = "./"+fn
            val txt = if(rst.isEmpty())"" else rst.map(_.mkString(",")+"\n").reduce(_+_)
            FileUtil.save(path,txt)
            Util.runShellCmd("hdfs dfs -mkdir -p "+hdfsPath)
            Util.runShellCmd("hdfs dfs -rm -r -f "+hdfsPath+"/"+fn)
            Util.runShellCmd("hdfs dfs -put "+path+" "+hdfsPath)
            Util.runShellCmd("hdfs dfs -ls "+hdfsPath)
            Util.runShellCmd("./rm -rf "+path)
        }
        df
    }

    def initBeeLogsTable(tableName:String,dayFrom:String,dayTo:String): Unit ={
        val sql =
            s"""
               |use dm_gis;
               |drop table if exists $tableName;
               |create external table if not exists $tableName(log string) partitioned by (inc_day string) row format delimited fields terminated by '\\t' lines terminated by '\\n' location '/user/mario/warehouse/$tableName';
       """.stripMargin
        val sql2 = (0 to Util.daysDiff(dayFrom,dayTo).toInt).map(i=>{
            val dayid = Util.addDay(dayFrom,i).replaceAll("-","")
            s"""alter table $tableName add if not exists partition (inc_day=$dayid) location '/user/mario/warehouse/$tableName/$dayid/';
       """.stripMargin
        }).reduce(_+_)
        Util.runHiveSQL("dm_gis",sql+sql2)
    }

    def addPartition(db:String,table:String,partitionBy:String,hdfsPath:String)={
        if(db!=null && db.length>0 && partitionBy!=null && partitionBy.length>0){
            if(spark!=null && !spark.sparkContext.isStopped){
                val cmd = s"alter table $db."+table+" add if not exists partition ("+partitionBy+") location '"+hdfsPath+"'"
                spark.sql(cmd)
            }else{
                val sql = s"""
use $db;
alter table $table add if not exists partition ($partitionBy) location '$hdfsPath';"""
                Util.runHiveSQL(db,sql)
            }
        }
    }

    def dropPartition(db:String,table:String,partitionBy:String,hdfsPath:String)={
        val sql = s"""alter table $db.$table drop if exists partition ($partitionBy)"""
        Util.spark.sql(sql)
        Util.hdfsRM(hdfsPath)
        Util.runShellCmd(s"hdfs dfs -ls $hdfsPath")
    }

    def makeEdge(v:String)={
        var t = v.split(",")
        val t2 = t.map(d=>{
            val r = t.map(from=>{
                //System.err.println(from+"----"+d)
                var s = ""
                if(!d.equals(from))
                    s = from+"-"+d
                else
                    s = null
                //System.err.println(s)
                s
            }).filter(_!=null).mkString(",")
            r
        }).mkString(",")
        t2
    }

    //System.err.println("up link:"+makeEdge("1u,2u,3u,4u"))

    //  val routes = new ArrayBuffer[String]()
    //  routes.append(makeEdge("1u,2u,3u,4u"))
    //  routes.append(makeEdge("1d,7d,6d"))
    //  routes.append(makeEdge("4d,5d,6u"))
    //  routes.append(makeEdge("2d,3d,5u,7u"))
    //  routes.append("1d-1u,2d-2u,3d-3u,4d-4u,5d-5u,6d-6u,7d-7u,1u-1d,2u-2d,3u-3d,4u-4d,5u-5d,6u-6d,7u-7d")
    //val route = routes.mkString(",")


    def sevenBridge(): Unit ={
        //构造路径
        //    val path = new java.util.ArrayList[(String,String)]()
        //    path.add(("1u","1d"))
        //    path.add(("2u","2d"))
        //    path.add(("3u","3d"))
        //    path.add(("4u","4d"))
        //    path.add(("5u","5d"))
        //    path.add(("6u","6d"))
        //    path.add(("7u","7d"))
        //    path.add(("1u","2u"))
        //    path.add(("1u","3u"))
        //    path.add(("1u","4u"))
        //    path.add(("1d","6d"))
        //    path.add(("1d","7d"))
        //    path.add(("2u","1u"))
        //    path.add(("2u","3u"))
        //    path.add(("2u","4u"))
        //    path.add(("2d","3d"))
        //    path.add(("2d","5u"))
        //    path.add(("2d","7u"))
        //    path.add(("3u","1u"))
        //    path.add(("3u","2u"))
        //    path.add(("3u","4u"))
        //    path.add(("3d","2d"))
        //    path.add(("3d","5u"))
        //    path.add(("3d","7u"))
        //    path.add(("4u","1u"))
        //    path.add(("4u","2u"))
        //    path.add(("4u","3u"))
        //    path.add(("4d","5d"))
        //    path.add(("4d","6u"))
        //    path.add(("5u","2d"))
        //    path.add(("5u","3d"))
        //    path.add(("5u","7u"))
        //    path.add(("5d","4d"))
        //    path.add(("5d","6u"))
        //    path.add(("6u","4d"))
        //    path.add(("6u","5d"))
        //    path.add(("6d","7d"))
        //    path.add(("6d","1d"))
        //    path.add(("7u","2d"))
        //    path.add(("7u","3d"))
        //    path.add(("7u","5u"))
        //    path.add(("7d","1d"))
        //    path.add(("7d","6d"))

        val route = "1d-1u,2d-2u,3d-3u,4d-4u,5d-5u,6d-6u,7d-7u,1u-1d,2u-2d,3u-3d,4u-4d,5u-5d,6u-6d,7u-7d,1u-2u,1u-3u,1u-4u,1d-6d,1d-7d,2u-1u,2u-3u,2u-4u,2d-3d,2d-5u,2d-7u,3u-1u,3u-2u,3u-4u,3d-2d,3d-5u,3d-7u,4u-1u,4u-2u,4u-3u,4d-5d,4d-6u,5u-2d,5u-3d,5u-7u,5d-4d,5d-6u,6u-4d,6u-5d,6d-7d,6d-1d,7u-2d,7u-3d,7u-5u,7d-1d,7d-6d"


        val path = route.split(",").map(_.split("-"))
        val startPoint = path.map(d=>d(0)).distinct
        val searchedPath = new ArrayBuffer[String]

        def addPath(ref:ArrayBuffer[String],from:String):ArrayBuffer[String] ={
            var ret = ref
            path.filter(d=>d(0)==from).foreach(d=>{
                val nexts = path.filter(d=>d(0)==from)
                nexts.foreach(n=>{
                    val to = n(1)
                    //          if(from=="5u" && (to=="2d"||to=="3d")){
                    //            System.err.println(from+"---------------"+to)
                    //            System.err.println(ref)
                    //          }
                    if(!ref.contains(to)){
                        val clone = ref.clone()
                        clone.append(to)
                        ret = addPath(clone.clone(),to)
                        System.err.println(clone.mkString(","))
                    }
                })
            })
            ret
        }
        startPoint.foreach(d=>{
            val currentPath = new ArrayBuffer[String]
            currentPath.append(d)
            addPath(currentPath,d)
            searchedPath.append(currentPath.mkString(","))
        })
        searchedPath.filter(d=>{d.split(",").size == 14}).map(d=>{
            var fack = false
            val link = d.split(",")
            for(i<- 1 to link.size-1){
                if(route.indexOf(link(i-1)+"-"+link(i)) == -1)
                    fack = true
            }
            (d,fack)
        }).filter(!_._2).foreach(d=>{
            System.err.println(d._1)
        })
    }

    val hm_makeGroupByQuery = new mutable.HashMap[String,Boolean]()
    def clearGroupByQueryCache(): Unit ={
        hm_makeGroupByQuery.keys.foreach(k=>{
            Util.spark.catalog.uncacheTable(k)
        })
        hm_makeGroupByQuery.clear()
    }

    def checkEncode(str:String):String = {
        val code = "gbk,gb2312,iso8859-1,utf-8".split(",")
        var r = ""
        code.foreach(c=>{
            if(str.equals(new String(str.getBytes(c),c)))
                r = c
        })
        return r
    }

    def fixAddress(str:String) ={
        if(str == null) null else{
            str.replaceAll(s"""[\\\\,\t\r\n'\" (null)(NULL)]""","")
        }
    }

    def fixJsonStr(s:String): String ={
        s.replaceAll(s"""[\r\n\t]""","")
    }

    def getCityCodeFromOrgCode(bn:String)={
        var t:String = try {
            val c = if(bn.length>3) bn.substring(0, 4) else null
            Integer.parseInt(c)
            c
        } catch {case e: Exception => { null }}
        if(t==null) t = try {
            val c = if(bn.length>2) bn.substring(0, 3) else null
            Integer.parseInt(c)
            c
        } catch {case e: Exception => { null }}
        if(t==null) t=""
        t
    }

    var bdpEncodeConfigInited = false

    def ct(sql:String,tableName:String)={
        Util.spark.sql(sql).createOrReplaceTempView(tableName)
    }

    def saveCSV(sql:String,path:String,terminated:String=",",partitionSize:Int=200)={
        val rdd = Util.spark.sql(sql).repartition(partitionSize).rdd.persist(StorageLevel.MEMORY_AND_DISK_SER)
        if(!rdd.isEmpty()){
            val csv = rdd.map(_.mkString(terminated)+"\n").reduce(_+_)
            FileUtil.save(path,csv)
        }else{
            System.err.println("-------------------------------------------------------------------------")
            System.err.println("【WARN】 Util.saveCSV found empty result")
            System.err.println(sql)
            System.err.println("-------------------------------------------------------------------------")
        }
        rdd.unpersist()
    }

    def hdfsRM(path:String):Unit={
        val log = Util.runShellCmd(s"hdfs dfs -rm -r -f $path")
        if(log!=null && log.contains("无法删除受保护目录")){
            val hadoopConf = spark.sparkContext.hadoopConfiguration
            val hdfs = org.apache.hadoop.fs.FileSystem.get(hadoopConf)
            val p = new Path(path)
            if(hdfs.exists(p))
              hdfs.delete(p,true)
        }
    }
    def hdfsMkdir(path:String)={
        val hadoopConf = spark.sparkContext.hadoopConfiguration
        val hdfs = org.apache.hadoop.fs.FileSystem.get(hadoopConf)
        val p = new Path(path)
        if(!hdfs.exists(p))
            hdfs.mkdirs(p)
        if(!hdfs.exists(new Path(path))){
            s"hdfs dfs -mkdir -p $path"!;
        }
    }
    def hdfsRename(pathFrom:String,pathTo:String):Unit={
        val hadoopConf = spark.sparkContext.hadoopConfiguration
        val hdfs = org.apache.hadoop.fs.FileSystem.get(hadoopConf)
        hdfs.rename(new Path(pathFrom),new Path(pathTo))
    }

    def initBash(): Unit ={
        this.synchronized {
            var hasException = false
            while((!hasException) && (!new File("./rm").exists() || !new File("./sed").exists() || !new File("./bash").exists())){
                try{
                    "rm -rf ./bash.zip"!;
                    "rm -rf ./rm"!;
                    "rm -rf ./sed"!;
                    "rm -rf ./bash"!;
                    "hdfs dfs -get /user/01366807/upload/bash.zip ."!;
                    "unzip -o ./bash.zip"!;
                    "chmod +x ./bash"!;
                    "chmod +x ./rm"!;
                    "chmod +x ./sed"!;
                }catch {
                    case e:Exception=>{
                        System.err.println("----------------------------------------------------------------------")
                        System.err.println("bash download faild")
                        System.err.println("----------------------------------------------------------------------")
                        hasException = true
                    }
                }

                var c = 0
                while(c<600 && new File("./bash").length() != 951096){
                    System.err.print(".")
                    if((c+1) % 100 == 0)
                        System.err.println()
                    Thread.sleep(100)
                    c += 1
                }

                System.err.println("""【bash size】 """+new File("./bash").length())
                if(c>=600){
                    System.err.println("----------------------------------------------------------------------")
                    System.err.println("bash size faild")
                    System.err.println("----------------------------------------------------------------------")
                    hasException = true
                }else{
                    System.err.println("========================================================================")
                    "./bash --version"!;
                    System.err.println("========================================================================")
                }
            }
            bashInited = true
        }
    }

    def printException(e:Exception): Unit ={
        System.err.println(e.getMessage+"\t"+e.getCause)
        e.printStackTrace(System.err)
    }

    def fixnull(ak:String,defaultVal:String = "")={
        if(ak==null||ak.trim==""||ak.trim.toLowerCase()=="null") defaultVal else ak
    }

    def debug(key:String,v:Any): Unit ={
        System.err.println(s"【$key】=$v")
    }

    def copyTableStruct(srcTable:String,partitionBy:String="",where:String="",destTable:String,comment:String,location:String,newColumnsDDL:String,checkDestTableExists:Boolean=true): Unit ={
        if(checkDestTableExists){
            var testDestSql = ""
            val t = destTable.split(s"\\.",2)
            if(t.size==2) {
                testDestSql = s"show tables in ${t(0)} like '${t(1)}'"
            }

            val cnt = Util.spark.sql(testDestSql).count
            if(cnt>0){
                println(s"【ERROR】目标表已存在：$destTable")
                return
            }
        }

        //Util.spark.sql("drop table if exists dm_gis.parquet_test")
        //Util.runShellCmdSilent("hdfs dfs -rm -r -f hdfs://sfbd/user/hive/warehouse/dm_gis.db/parquet_test")

        Util.spark.catalog.refreshTable(srcTable)
        Util.spark.sql(s"refresh table $srcTable")

        val coldef = Util.spark.sql(s"desc $srcTable").collect().map(d=>{
            val col_name = d.getString(0)
            val data_type = d.getString(1)
            val comment = Util.fixnull(d.getString(2))
            (col_name,(data_type,comment))
        }).toMap

        var dfff = Util.spark.sql(s"select * from $srcTable ${if(where=="") "" else s"where $where"}").limit(1)

        if(partitionBy!=""){
            partitionBy.split(",").foreach(d=>{
                val col = d.split(" ")(0).replaceAll("`","")
                dfff = dfff.drop(col)
            })
        }

        println("记录数："+dfff.count)
        dfff.show(false)

        val cols = dfff.columns.map(c=>{
            val colddl = coldef.getOrElse(c,("string",""))
            s"`$c` ${colddl._1} comment '${colddl._2.replaceAll("'","")}'"
        }).mkString(",\n")

        Util.spark.sql(
            s"""
               |CREATE TABLE $destTable (
               |$cols,
               |$newColumnsDDL
               |)
               |COMMENT '$comment'
               |${if(partitionBy!="") s"PARTITIONED BY ($partitionBy)" else ""}
               |STORED AS PARQUET TBLPROPERTIES('parquet.compression'='snappy')
               |location '$location'
               |""".stripMargin)

    }
    def waitSqlData(sql:String): Unit ={
        var df = Util.spark.sql(sql)
        var cnt = df.count()
        var lastCnt = 0l
        while(cnt == 0 || lastCnt!=cnt){

            if(cnt>lastCnt){
                Util.showCost(s"【$sql】数据初始化重试校验，记录数：$cnt / $lastCnt，等待1分钟后重试")
            }else{
                Util.showCost(s"【$sql】数据初始化异常，记录数：$cnt / $lastCnt，等待1分钟后重试")
            }
            lastCnt = cnt

            Thread.sleep(1 * 60 * 1000)
            df = Util.spark.sql(sql)
            cnt = df.count()
        }
    }

    def getLastWeekDayid(week:Int=0): String ={
        var w = Util.getWeek(Util.getTodayDayid())
        if(w == 0) w = 7
        val dayid = Util.addDay(Util.getTodayDayid(),week-w).replaceAll("-","")
        dayid
    }

    /**
     * 向量的模长
     * @param vec
     */
    def module(vec:Vector[Double]): Double ={
        // math.sqrt( vec.map(x=>x*x).sum )
        math.sqrt(vec.map(math.pow(_,2)).sum)
    }

    /**
     * 求两个向量的内积
     * @param v1
     * @param v2
     */
    def innerProduct(v1:Vector[Double],v2:Vector[Double]): Double ={
        val listBuffer=ListBuffer[Double]()
        for(i<- 0 until v1.length; j<- 0 until v2.length;if i==j){
            if(i==j){
                listBuffer.append( v1(i)*v2(j) )
            }
        }
        listBuffer.sum
    }

    /**
     * 求两个向量的余弦值
     * @param v1
     * @param v2
     */
    def cosvec(v1:Vector[Double],v2:Vector[Double]):Double ={
        val cos=innerProduct(v1,v2) / (module(v1)* module(v2))
        if (cos <= 1) cos else 1.0
    }

    def textCosine(str1:String,str2:String):Double={
        val set=mutable.Set[Char]() //统计两句话所有的字
        str1.foreach(set +=_)
        str2.foreach(set +=_)
        val setord = set.toList.sorted
        println(setord)
        val ints1: Vector[Double] = setord.map(ch => {
            str1.count(s => s == ch).toDouble
        }).toVector
        println("===ints1: "+ints1)
        val ints2: Vector[Double] = setord.map(ch => {
            str2.count(s => s == ch).toDouble
        }).toVector
        println("===ints2: "+ints2)
        cosvec(ints1,ints2)
    }

    def save2partition(df: DataFrame, size: Int, db: String, tb: String, partitionBy: String, hdfsPath: String,unPersist:Boolean=true) = {
        val cnt = df.count
        if(cnt>0){
            val psize = if(cnt == 0) 1 else Math.ceil(cnt.toDouble / size.toDouble).toInt
            Util.runShellCmd(s"hdfs dfs -rm -r -f $hdfsPath")
            df.repartition(psize).write.parquet(hdfsPath)
            Util.addPartition(db,tb,partitionBy,hdfsPath)
            Util.runShellCmd(s"hdfs dfs -ls $hdfsPath | head -n 5")
            Util.showCost(s"【$partitionBy】${db}.$tb 初始化完毕，记录数：$cnt，分区数(前/后)：${df.rdd.getNumPartitions} / $psize")
        }else{
            Util.showCost(s"【$partitionBy】${db}.$tb 初始化失败，记录数：$cnt !!!!!!!!!!!!!!!!!!!!!!")
        }
        if(unPersist)
            df.unpersist()
    }
}
