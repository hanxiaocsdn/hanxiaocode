package com.sf.app.veh

import com.sf.app.veh.InsurancePolicyDriver.currEarnedPremiums
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter}
import utils.SparkBuilder

/**
 * @task_id: 660098 (ftp线下数据路径：/01424465) 目前未发版 预计每月不定期执行一次
 * @description:线上与线下数据融合合并 线上：insurance_policy_underwriting_claims 线下--insurance_policy_underwriting_claims_2 得到 insurance_policy_underwriting_claims_vehicle_dtl_mix
 * @demander: 01424465 张雪莹
 * @author 01418539 caojia
 * @date 2023/2/1 16:06
 */
object InsurancePolicyDriverMix extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val file_name = args(1)
    processMix(spark, inc_day, file_name)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processMix(spark: SparkSession, inc_day: String, file_name: String): Unit = {
    import spark.implicits._
    val months_3_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -3) //3月前的月初日期
    val months_6_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -6)
    val months_12_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -12)
    val last_month_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月底最后一天
    val tmp_12_months_df = processClaimsMix(spark, last_month_day, file_name)
    processQuotaOpti(spark, tmp_12_months_df.filter('inc_day === last_month_day && 'months_flag === "3"), months_3_ago)
    processQuotaOpti(spark, tmp_12_months_df.filter('inc_day === last_month_day && 'months_flag === "6"), months_6_ago)
    processQuotaOpti(spark, tmp_12_months_df.filter('inc_day === last_month_day && 'months_flag === "12"), months_12_ago)
  }

  def processClaimsMix(spark: SparkSession, last_month_day: String, file_name: String): DataFrame = {
    import spark.implicits._
    //p1/3 加载online理赔中间表 近12个月数据
    val o_online_df = spark.sql(s"""select * from dm_gis.insurance_policy_underwriting_claims where inc_day = '$last_month_day'""")
      .withColumn("flag", lit("1"))

    //p2/3 加载offline理赔中间表
    val offline_cols_str = Seq("id", "datacode", "update_tm", "vendor_id", "policy_no", "state", "policy_holder", "insurant", "vehicle_id", "vehicle_code", "vim_code", "engine_code", "vehicle_type", "premium", "start_dt", "end_dt", "statistics_start_tm", "statistics_end_tm", "is_new_status", "created_tm", "type", "claim_folder_no", "report_case_no", "reporter_name", "reporter_mobile", "report_dt", "open_dt", "closing_dt_lp", "closing_dt_ba", "diver", "case_description", "is_wounded", "wounded_type", "case_category", "responsibility", "survey_descrip", "loss_event_place", "loss_event_dt", "case_status_lp", "case_status_ba", "claim_detail_status", "underwriting_amount", "estimated_loss_amount", "pending_amount", "accomm_expenses", "whole_expenses", "glass_no_premium", "cnt_compensation", "remarks", "modified_tm", "inc_day", "months_flag")
    //    val inputPath = "/user/01418539/upload/file/insurance/补充中间表数据_20230131.csv"
    val inputPath = "/user/01418539/upload/file/insurance/" + file_name
    val online_cols = spark.sql("""select * from dm_gis.insurance_policy_underwriting_claims_2 limit 0""").schema.map(_.name).map(col)

    val o_offline_claims_df = spark.read
      .option("header", "false")
      .option("delimiter", ",") //\\t
      .option("encoding", "utf-8")
      .option("inferSchema", true.toString)
      .csv(inputPath)
      .toDF(offline_cols_str: _*)
      .filter('inc_day === last_month_day)
      .withColumn("reporter_mobile", lit(""))
      .select(online_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("理赔线下表中数据总量 >>>>>>>" + o_offline_claims_df.count())
    writeToHive(spark, o_offline_claims_df, Seq("inc_day", "months_flag"), "dm_gis.insurance_policy_underwriting_claims_2")

    val o_offline_df = o_offline_claims_df
      .withColumn("num", row_number().over(Window.partitionBy("policy_no", "claim_folder_no").orderBy(desc("modified_tm"))))
      .filter('num === 1).drop("num")
      .withColumn("flag", lit("2"))
    //p3/3 offline 与 online数据合并
    val res_cols = spark.sql("""select * from dm_gis.insurance_policy_underwriting_claims_mix limit 0""").schema.map(_.name).map(col)
    val mix_claims_df = o_online_df.union(o_offline_df)
      .withColumn("num", row_number().over(Window.partitionBy("inc_day", "months_flag", "policy_no", "claim_folder_no").orderBy(asc("flag"))))
      .filter('num === 1)
      .withColumn("reporter_mobile", lit(""))
      .select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    writeToHive(spark, mix_claims_df.coalesce(2), Seq("inc_day", "months_flag"), "dm_gis.insurance_policy_underwriting_claims_mix")
    mix_claims_df
  }

  def processQuotaOpti(spark: SparkSession, org_df: DataFrame, start_month_day: String): Unit = {
    import spark.implicits._
    val months_df = org_df
      .withColumn("num", row_number().over(Window.partitionBy('vehicle_id, 'vehicle_code, 'vehicle_type, 'premium, 'start_dt, 'end_dt, 'type).orderBy(desc("modified_tm"))))
      .filter('num === 1)
      .withColumn("statis_start_day", lit(start_month_day))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val s1_df = months_df.select("vehicle_code", "start_dt", "end_dt", "statis_start_day", "inc_day")
      .groupBy("vehicle_code", "statis_start_day", "inc_day")
      .agg(
        min("start_dt") as "start_dt",
        max("end_dt") as "end_dt"
      )
      .withColumn("curr_risk_exposure", currEarnedPremiums('start_dt, 'end_dt, 'statis_start_day, 'inc_day))
      .select("vehicle_code", "curr_risk_exposure")

    val enf_cond = 'type_arr.contains("交强") || 'type_arr.contains("强制")
    val conbine_type = when(enf_cond && 'type_arr.contains("商业"), "交商共保")
      .when(enf_cond && !'type_arr.contains("商业"), "单交强")
      .when(!enf_cond && 'type_arr.contains("商业"), "单商业")

    //loss_event_dt	2019-12-21 00:00:00
    val loss_event_dt_col = regexp_replace(substring('loss_event_dt, 1, 10), "-", "")
    val s2_1_df = months_df
      .withColumn("curr_earned_premiums", 'premium * currEarnedPremiums('start_dt, 'end_dt, 'statis_start_day, 'inc_day))
      .withColumn("curr_underwriting_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'underwriting_amount).otherwise(0))
      .withColumn("curr_estimated_loss_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'estimated_loss_amount).otherwise(0))
      .groupBy("vehicle_code", "vim_code", "statis_start_day", "inc_day", "months_flag") //todo vehicle_type 车牌号从聚合字段中剔除
      .agg(
        first('vehicle_id) as "vehicle_id",
        sum('curr_earned_premiums.cast("double")) as "curr_earned_premiums",
        concat_ws("|", collect_set('vehicle_type)) as "vehicle_type",
        concat_ws("|", collect_set('vendor_id)) as "vendor_id",
        concat_ws("|", collect_set('type)) as "type_arr"
      )
      .withColumn("conbine_type", conbine_type)

    val s2_2_df = org_df
      .withColumn("statis_start_day", lit(start_month_day))
      .withColumn("curr_underwriting_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'underwriting_amount).otherwise(0))
      .withColumn("curr_estimated_loss_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'estimated_loss_amount).otherwise(0))
      .groupBy("vehicle_code")
      .agg(
        sum('curr_underwriting_amount.cast("double")) as "curr_underwriting_amount",
        sum('curr_estimated_loss_amount.cast("double")) as "curr_estimated_loss_amount"
      )
      .withColumn("curr_pending_amount", when('curr_estimated_loss_amount.cast("double") - 'curr_underwriting_amount.cast("double") >= 0, 'curr_estimated_loss_amount.cast("double") - 'curr_underwriting_amount.cast("double")).otherwise(0))
      .select("vehicle_code", "curr_underwriting_amount", "curr_estimated_loss_amount", "curr_pending_amount")

    val accident_cols: Seq[Column] = Seq('vehicle_code, 'report_case_no, 'vim_code, 'start_dt, 'end_dt, 'loss_event_dt, 'case_status_lp, 'underwriting_amount, 'type, 'inc_day)
    val accident_df = org_df
      .select(accident_cols: _*).groupBy(accident_cols: _*).agg(lit("1") as "cos")
      .withColumn("statis_start_day", lit(start_month_day))
      .withColumn("curr_accidents_cnt", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day && 'case_status_lp.isin("拒赔", "注销"), 0)
        .when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day && !'case_status_lp.isin("拒赔", "注销"), 1)
        .otherwise(0)) //去除：零结案定义为 case_status_lp 为结案/已结案&已决金额为0
      .groupBy("vehicle_code", "report_case_no")
      .agg(max('curr_accidents_cnt) as "curr_accidents_cnt")
      .groupBy("vehicle_code").agg(sum("curr_accidents_cnt") as "curr_accidents_cnt")

    val res_df_cols = spark.sql("""select * from dm_gis.insurance_policy_underwriting_claims_vehicle_dtl_mix limit 0""").schema.map(x => col(x.name))
    val res_df = s2_1_df.join(s2_2_df, Seq("vehicle_code"), "left")
      .join(s1_df, Seq("vehicle_code"), "left")
      .join(broadcast(accident_df), Seq("vehicle_code"), "left")
      .withColumn("curr_comp_amount", 'curr_underwriting_amount.cast("double") + 'curr_pending_amount.cast("double"))
      .withColumn("occurr_freq", when('curr_risk_exposure > 0, 'curr_accidents_cnt / 'curr_risk_exposure).otherwise(0.0))
      .withColumn("ppcf_comp_amount", when('curr_accidents_cnt > 0, 'curr_comp_amount / 'curr_accidents_cnt).otherwise(0.0))
      .withColumn("claim_loss_ratio", when('curr_earned_premiums > 0, 'curr_comp_amount / 'curr_earned_premiums).otherwise(0.0))
      .select(res_df_cols: _*)

    writeToHive(spark, res_df, Seq("inc_day", "months_flag"), "dm_gis.insurance_policy_underwriting_claims_vehicle_dtl_mix")
    months_df.unpersist()
    org_df.unpersist()
  }
}
