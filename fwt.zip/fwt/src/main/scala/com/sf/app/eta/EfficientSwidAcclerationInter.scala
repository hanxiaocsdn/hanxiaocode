package com.sf.app.eta

import com.sf.app.eta.EfficientSwidAccleration.{dealAfterInterWithPart, getCityMapAdcode60, getLinksInfo}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder

/**
 * @task_id:
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2023/3/24 18:17
 */
case class EfficientSwidInfoWithNum(un: String, swid_gj: String, adcode_gj: String, time_gj: String, speed_gj: String, adcode_first_gj: String, adcode_end_gj: String, time_first_gj: String, time_end_gj: String, time_taken_gj: String, swid_qm: String, roadclass_qm: String, dr_length_qm: String, formway_qm: String, swid_name_qm: String, dist_gj: String, num: String)

object EfficientSwidAcclerationInter extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val start_num = args(1)
    val inter_num = args(2)
    val end_num = args(3)
    val source_tableN = "dm_gis.eta_experience_speed_track_fix_to320_direction_60"
    getInterBack(spark, inc_day, start_num, inter_num, end_num, source_tableN)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def getInterBack(spark: SparkSession, inc_day: String, start_num: String, inter_num: String, end_num: String, source_tableN: String): Unit = {
    import spark.implicits._
    val start_n = start_num.toInt
    val end_n = end_num.toInt

    val sql = s"""select * from $source_tableN where inc_day= '$inc_day' and cast(num as int) between $start_n and $end_n"""
    logger.error("输入的sql语句：" + sql)
    val o_20_index_df = spark.sql(sql).repartition(75).persist() //110 60 降为 15  500/s 200/s 降为50/s
    logger.error("全量数据总数>>>>>>>" + o_20_index_df.count())

    var start_num_cnt = start_num.toInt
    val inter_num_cnt = inter_num.toInt
    var batch_num_cnt = start_num_cnt + inter_num_cnt
    val end_num_cnt = end_num.toInt

    for (i <- start_num_cnt until 1000 if i >= start_num_cnt && i <= end_num_cnt) {
      logger.error("首发批次：" + i + " >>执行的批次num范围:" + start_num_cnt + "结束批次>>>" + batch_num_cnt)
      val inter_back_df = o_20_index_df.filter('num.cast("int") >= start_num_cnt && 'num.cast("int") <= batch_num_cnt)
        .map(row => {
          val un = row.getAs[String]("un")
          val swid_gj = row.getAs[String]("swid_gj")
          val adcode_gj = row.getAs[String]("adcode_gj")
          val time_gj = row.getAs[String]("time_gj")
          val speed_gj = row.getAs[String]("speed_gj")
          val adcode_first_gj = row.getAs[String]("adcode_first_gj")
          val adcode_end_gj = row.getAs[String]("adcode_end_gj")
          val time_first_gj = row.getAs[String]("time_first_gj")
          val time_end_gj = row.getAs[String]("time_end_gj")
          val time_taken_gj = row.getAs[String]("time_taken_gj")
          val num = row.getAs[String]("num")

          val swid_diff = row.getAs[String]("swid_diff")
          val date = time_first_gj.replaceAll("-|:|\\s+", "") //2022-11-05 10:44:28
          var links_info: (String, String, String, String, String, String) = null
          var swid_qm, roadclass_qm, dr_length_qm, formway_qm, swid_name_qm, dist_gj = ""
          if (date != "" && swid_diff != "") {
            links_info = getLinksInfo(swid_diff, date)
            swid_qm = links_info._1
            roadclass_qm = links_info._2
            dr_length_qm = links_info._3
            formway_qm = links_info._4
            swid_name_qm = links_info._5
            dist_gj = links_info._6
          }
          EfficientSwidInfoWithNum(un, swid_gj, adcode_gj, time_gj, speed_gj, adcode_first_gj, adcode_end_gj, time_first_gj, time_end_gj, time_taken_gj, swid_qm, roadclass_qm, dr_length_qm, formway_qm, swid_name_qm, dist_gj, num)
        }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
      inter_back_df.show(3)
      logger.error(">>最终数据总量：>>>>>" + inter_back_df.count())
//      val city_map_df = getCityMapAdcode(spark)
//      dealAfterInterWithPart60(spark, inter_back_df, inc_day,city_map_df,"dm_gis.eta_experience_speed_track_fix_to320_road_detail_12")
      val city_map_df = getCityMapAdcode60(spark)//todo 切成60个城市
      dealAfterInterWithPart(spark, inter_back_df, inc_day,city_map_df,"dm_gis.eta_experience_speed_track_fix_to320_road_detail_60")
      start_num_cnt = batch_num_cnt + 1
      batch_num_cnt = start_num_cnt + inter_num_cnt
    }

  }
}
