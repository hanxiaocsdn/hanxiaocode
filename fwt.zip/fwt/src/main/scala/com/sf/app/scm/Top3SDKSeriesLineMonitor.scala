package com.sf.app.scm

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.primaryKeyEncrypt
import utils.SparkBuilder

/**
 * @task_id: 671508
 * @description: 串联线路规划成功率&导航线路还原成功率监控  gis_navi_series_line_planning_cnt
 * @demander: lifeilong  ft220114
 * @author 01418539 caojia
 * @date 2023/3/3 14:42
 */
object Top3SDKSeriesLineMonitor extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processSerials(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processSerials(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val o_top3 = spark.sql(
      s"""select task_id,plantype,inc_day,1 top3_require_num from dm_gis.gis_navi_top3_parse
         |where inc_day between '$start_day' and '$end_day' and task_id is not null and trim(task_id) !=''""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val o_sdk_navi = spark.sql(s"""select task_id,type,content,inc_day from dm_gis.gis_navi_sdk_navi_parse where inc_day between '$start_day' and '$end_day' and task_id is not null and trim(task_id) !=''""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val o_recall = spark.sql(s"""select task_area_code,task_id,carrier_type,inc_day from dm_gis.eta_std_line_recall_result2 where inc_day between '$start_day' and '$end_day' and task_id is not null and trim(task_id) !=''""")
    val o_area_name = spark.sql("""select * from dm_gis.dim_area_code_name_mapping""")

    val top3_df = o_top3
      .withColumn("sl_serplan_num", when('plantype === "slSerPlan", 1).otherwise(0))
      .groupBy("task_id", "inc_day")
      .agg(
        sum("top3_require_num") as "top3_require_num",
        sum("sl_serplan_num") as "sl_serplan_num"
      ).select("task_id", "top3_require_num", "sl_serplan_num", "inc_day")

    val sdk_navi = o_sdk_navi
      .withColumn("top3_require_failed_num", when('type === "23", 1).otherwise(0))
      .withColumn("sl_serplan_failed_num", when('type === "23" && 'content.contains("slSerPlan"), 1).otherwise(0))
      .withColumn("restore_num", when('type === "24", 1).otherwise(0))
      .withColumn("restore_failed_num", when('type === "24" && 'content.contains("失败"), 1).otherwise(0))
      .groupBy("task_id", "inc_day")
      .agg(
        sum("top3_require_failed_num") as "top3_require_failed_num",
        sum("sl_serplan_failed_num") as "sl_serplan_failed_num",
        sum("restore_num") as "restore_num",
        sum("restore_failed_num") as "restore_failed_num"
      )

    val top3_sdk_df = o_sdk_navi.filter('type === "24")
      .withColumn("num", row_number().over(Window.partitionBy("task_id", "inc_day").orderBy(desc("type")))).filter('num === 1)
      .join(broadcast(o_top3.filter('plantype === "slSerPlan").select("task_id", "inc_day")), Seq("task_id", "inc_day"))
      .withColumn("sl_serplan_restore_num", lit(1))
      .withColumn("sl_serplan_restore_failed_num", when('content.contains("失败"), 1).otherwise(0))
      .groupBy("task_id", "inc_day")
      .agg(
        sum("sl_serplan_restore_num") as "sl_serplan_restore_num",
        sum("sl_serplan_restore_failed_num") as "sl_serplan_restore_failed_num"
      )

    val res_cols = spark.sql("""select * from dm_gis.gis_navi_series_line_planning_cnt limit 0""").schema.map(_.name).map(col)
    val res_df = o_recall.join(broadcast(top3_df), Seq("task_id", "inc_day"), "left")
      .join(broadcast(sdk_navi), Seq("task_id", "inc_day"), "left")
      .join(broadcast(top3_sdk_df), Seq("task_id", "inc_day"), "left")
      .join(o_area_name, Seq("task_area_code"), "left")
      .na.fill(0, Seq("sl_serplan_num", "sl_serplan_failed_num", "restore_num", "restore_failed_num", "top3_require_num", "top3_require_failed_num", "sl_serplan_restore_num", "sl_serplan_restore_failed_num"))
      .groupBy("task_area_code", "task_area_name", "carrier_type", "inc_day")
      .agg(
        sum("top3_require_num") as "top3_require_num",
        sum("top3_require_failed_num") as "top3_require_failed_num",
        sum("sl_serplan_restore_num") as "sl_serplan_restore_num",
        sum("sl_serplan_restore_failed_num") as "sl_serplan_restore_failed_num",
        sum("sl_serplan_num") as "sl_serplan_num",
        sum("sl_serplan_failed_num") as "sl_serplan_failed_num",
        sum("restore_num") as "restore_num",
        sum("restore_failed_num") as "restore_failed_num"
      )
      .withColumn("sl_serplan_success_num", 'sl_serplan_num - 'sl_serplan_failed_num)
      .withColumn("restore_success_num", 'restore_num - 'restore_failed_num)
      .withColumn("top3_require_success_num", 'top3_require_num - 'top3_require_failed_num)
      .withColumn("sl_serplan_restore_success_num", 'sl_serplan_restore_num - 'sl_serplan_restore_failed_num)
      .withColumn("id", primaryKeyEncrypt('task_area_code, 'task_area_name, 'carrier_type, 'inc_day, lit(""), lit(""), lit("")))
      .select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(3), Seq("inc_day"), "dm_gis.gis_navi_series_line_planning_cnt")
    o_top3.unpersist()
    o_sdk_navi.unpersist()
  }
}
