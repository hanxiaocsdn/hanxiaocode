package com.sf.app.track

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.sql.functions._
import utils.ColumnUtil.sortFieldwithSpec
import utils.SparkBuilder

/**
 * @task_id: 临时执行
 * @description: 工号 125711 的小哥 日期 20220901-20230430 轨迹数据拼接查询 esg_gis_loc_trajectory un dx dy tm inc_day
 * @demander: 01430258  丁汀
 * @author 01418539 caojia
 * @date 2023/10/25 17:46
 */
object TrackMissing extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    run(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val sql =
      s"""select un,cast(dx as double) dx,cast(dy as double) dy,cast(tm as bigint) tm,inc_day from dm_gis.esg_gis_loc_trajectory where
         |inc_day>= '$start_day' and inc_day <= '$end_day' and un = '125711'
         |order by inc_day,tm
         |""".stripMargin
    logger.error(">>加载的数据sql为>>" + sql)
    val res_df = spark.sql(sql)
      .withColumn("xy", to_json(struct("dx", "dy")))
      .withColumn("num", row_number().over(Window.partitionBy('inc_day).orderBy(col("tm").cast("int").asc)))
      .groupBy("inc_day")
      .agg(
        concat_ws("&", collect_list(col("num"))) as "num",
        concat_ws("&", collect_list("xy")) as "track"
      )
      .withColumn("track", regexp_replace(sortFieldwithSpec("&")('num, 'track), "\\|", ","))
      .withColumn("track", concat(lit("["), col("track"), lit("]")))
      .select("inc_day", "track")

    //    res_df.select("track").take(3).foreach(println(_))
    //    res_df.show(2)

    val path = "/user/01418539/upload/file/track"
    val options = Map(
      "header" -> "true",
      "delimiter" -> "\\t",
      "compression" -> "gzip",
      "inferSchema" -> true.toString
    )
    writeToCsv(spark, res_df.coalesce(1), SaveMode.Overwrite, "20231025", options, path, false)

//    res_df.collect().foreach { row: Row =>
//      val inc_day = row.getAs[Integer]("inc_day")
//      val track = row.getAs[String]("track")
//
//      val outputFilePath = s"$path/$inc_day.json" // 输出文件路径
//      //将一行数据写入小文件
//      //spark.sparkContext.parallelize(Seq(track)).coalesce(1).saveAsTextFile(outputFilePath)
//      //一行数据一份文件，无嵌套
//      import java.io.PrintWriter
//      new PrintWriter(outputFilePath) {
//        write(track);
//        close()
//      }
//    }
  }
}
