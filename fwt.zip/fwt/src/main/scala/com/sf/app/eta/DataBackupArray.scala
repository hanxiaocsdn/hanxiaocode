package com.sf.app.eta


import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import utils.ColumnUtil.colTrimNotNull
import utils.SparkBuilder

/**
 * @task_id: 临时执行
 * @description: 流向表拆分出新的分区字段
 * @demander: 舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/4/19 16:14
 */
case class BackTrack(un: String, tp: String, zx: String, zy: String, ac: String, ad: String, be: String, sl: String, sp: String, tm: String, sc: String, bt: String, ak: String, dx: String, dy: String, state: String, pc: String, ewl: String, bk: String, bk2: String, bk3: String)

object DataBackupArray extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    //    val start_day = args(0)
    //    val end_day = args(1)
    //    val fromTN = "dm_gis.eta_track_highway_detail_to500_with_121_city"
    //    val toTN = "dm_gis.eta_experience_speed_track_fix_to500_road_detail_121_rep_hstime"
    //    procFill(spark, start_day, end_day)
    //    procRepartition(spark, start_day, end_day, fromTN, toTN)
    //    procTrackMap(spark, inc_day)
    //    diff(spark, start_day, end_day)
    //    val inc_day = args(0)
    //    fixDevNavi(spark, inc_day)
    //    backJson(spark)
    cityInfo(spark)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }


  def cityInfo(spark: SparkSession): Unit = {
    val inputPath = "/user/01418539/upload/file/eta/adcode.csv"
    val o_whole_city_df = spark.read
      .option("header", "false")
      .option("delimiter", "\\t")
      .option("encoding", "utf-8") //utf-8 gbk
      .option("inferSchema", true.toString)
      .csv(inputPath)
      .toDF("area_name", "city_name", "adcode", "city_code", "descrip")
      .filter("area_name !='区'")
    writeToHiveNoP(spark, o_whole_city_df, "dm_adcode_map_city_dtl")
  }

  def backJson(spark: SparkSession): Unit = {
    val tmp_tb = "dm_gis.eta_line_speed_ac_mix_delay_mining_dtl_tmp"
    val res_tb = "dm_gis.eta_line_speed_ac_mix_delay_mining_dtl"

    //删除 (change_type='压缩' and time_press=0) 或 (change_type='延长' and time_extend=0)
    val filter_cond = (col("change_type") === "压缩" && col("time_press").cast("double") === 0.0) || (col("change_type") === "延长" && col("time_extend").cast("double") === 0.0)
    val res_cols = spark.sql(s"""select * from $res_tb limit 0""").schema.map(_.name).map(col)
    val tmp_df = spark.sql(s"""select * from $tmp_tb where inc_day='20230729'""")
      .filter(!filter_cond)
      .select(res_cols: _*)
    writeToHive(spark, tmp_df.coalesce(2), Seq("inc_day"), res_tb)
  }

  def fixDevNavi(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val res_df_cols = spark.sql("""select * from dm_gis.gis_eta_navi_fuel_charging_info limit 0""").schema.map(x => col(x.name))
    var res_df: DataFrame = null
    if (inc_day == "20230702") {
      res_df = spark.sql("""select * from dm_gis.gis_eta_navi_fuel_charging_info where inc_day='20230702'""")
        .withColumn("litersnumber", when('vehiclecode === "京AJF901", lit("111.48")).otherwise('litersnumber))
        .withColumn("totalamount", when('vehiclecode === "京AJF901", lit("807.11")).otherwise('totalamount))
        .select(res_df_cols: _*)
    }
    if (inc_day == "20230704") {
      res_df = spark.sql("""select * from dm_gis.gis_eta_navi_fuel_charging_info where inc_day='20230704'""")
        .withColumn("litersnumber", when('vehiclecode === "津CC6991", lit("524.36")).otherwise('litersnumber))
        .withColumn("totalamount", when('vehiclecode === "津CC6991", lit("3775.39")).otherwise('totalamount))
        .select(res_df_cols: _*)
    }
    writeToHive(spark, res_df.coalesce(1), Seq("inc_day"), "dm_gis.gis_eta_navi_fuel_charging_info")
  }

  def diff(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val tableN = "dm_gis.eta_track_highway_detail_3d_with_328_city"
    val res_cols = spark.sql(s"""select * from $tableN limit 0""").schema.map(_.name).map(col)
    val o_df = spark.sql(s"""select * from $tableN where inc_day between '$start_day' and '$end_day'""")
      .withColumn("num", row_number().over(Window.partitionBy("un", "highspeed_start_time", "highspeed_end_time", "inc_day").orderBy("inc_day")))
      .filter('num === 1)
      .select(res_cols: _*)
    writeToHive(spark, o_df.coalesce(200), Seq("inc_day"), tableN)
  }

  def procTrackMap(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val sourceSql = s"""select * from dm_gis.gis_vms_track_device_track where inc_day='$inc_day'"""
    val res_cols = spark.sql("""select * from dm_gis.gis_vms_track_device_track_flatmap_tmp limit 0""").schema.map(_.name).map(col)
    val res_df = spark.sql(sourceSql).rdd.repartition(64000).map(x => {
      JSON.parseArray(x.getString(0)).toArray()
        .map(d => {
          val json = d.asInstanceOf[JSONObject]
          val un = json.getString("un")
          val tp = json.getString("tp")
          val zx = json.getString("zx")
          val zy = json.getString("zy")
          val ac = json.getString("ac")
          val ad = json.getString("ad")
          val be = json.getString("be")
          val sl = json.getString("sl")
          val sp = json.getString("sp")
          val tm = json.getString("tm")
          val sc = getJsonValue(json, "sc", "")
          val bt = json.getString("bt")
          val ak = json.getString("ak")
          val dx = json.getString("dx")
          val dy = json.getString("dy")
          val state = json.getString("state")
          val pc = json.getString("pc")
          val ewl = json.getString("ewl")
          val bk = json.getString("bk")
          val bk2 = json.getString("bk2")
          val bk3 = json.getString("bk3")
          BackTrack(un, tp, zx, zy, ac, ad, be, sl, sp, tm, sc, bt, ak, dx, dy, state, pc, ewl, bk, bk2, bk3)
        })
    }).filter(_ != null).flatMap(d => d)
      .toDF("un", "tp", "zx", "zy", "ac", "ad", "be", "sl", "sp", "tm", "sc", "bt", "ak", "dx", "dy", "state", "pc", "ewl", "bk", "bk2", "bk3")
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
    res_df.coalesce(7000).write.mode(SaveMode.Overwrite).insertInto("dm_gis.gis_vms_track_device_track_flatmap_tmp")
  }

  def getJsonValue(obj: JSONObject, keys: String, defaultValue: String): String = {
    var result: String = null
    var tempObj = obj
    try {
      var keyArr: Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          result = tempObj.getString(keyArr(i))
      }
    } catch {
      case e: Exception => logger.info("获取json数据项" + keys + "出错:" + obj, e)
    }
    if (result == null) result = defaultValue
    result
  }

  def procRepartition(spark: SparkSession, start_day: String, end_day: String, fromTN: String, toTN: String): Unit = {
    val res_df_cols = spark.sql(s"""select * from $toTN limit 0""").schema.map(x => col(x.name))
    val o_eta = spark.sql(
      s"""
         |select * from $fromTN where inc_day between '$start_day' and '$end_day'
         |""".stripMargin)
      .select(res_df_cols: _*)
      .repartition(64000)

    writeToHive(spark, o_eta.coalesce(7000), Seq("inc_day", "time_highspeed_start_rep"), toTN)

  }

  def procFill(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.eta_track_highway_detail_to500_with_121_city limit 0""").schema.map(_.name).map(col)

    val df = spark.sql(s"""select * from dm_gis.eta_track_highway_detail_to500_with_121_city where inc_day between '$start_day' and '$end_day'""")
      .repartition(6000)
      .withColumn("city_start", when(colTrimNotNull($"city_start"), 'city_start).otherwise("上海市"))
      .withColumn("city_end", when(colTrimNotNull($"city_end"), 'city_end).otherwise("上海市"))
      .withColumn("direction", concat_ws("-", 'city_start, 'city_end))
      .select(res_cols: _*).persist()
    logger.error(">>>>>>>>>>>" + df.count())
    writeToHive(spark, df.coalesce(50), Seq("inc_day"), "dm_gis.eta_track_highway_detail_to500_with_121_city")
    df.unpersist()
  }
}
