package com.sf.app.eta.realtime

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import utils.{StringUtils}

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.util.DistanceTool
import org.apache.commons.lang3.time.FastDateFormat
import com.sf.app.eta.realtime.ParseRecallScala.diffYongduAndWarningTime

import java.util.Date
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}


/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION} 时效定则-任务维度 客观数据补充2
 @create 2023/6/1
*/

object ParseRecallScala2 {

  val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")


  def processTrafficCongestion(org_json: JSONObject, url: String): JSONObject = {
    //1 原始字段
    val status_gd = org_json.getString("status_gd")
    val swid_gd = org_json.getString("swid_gd")
    val speed_gd = org_json.getString("speed_gd")
    val jp_swid = org_json.getString("jp_swid")
    val jp_coords = org_json.getString("jp_coords")
    val jp_time = org_json.getString("jp_time")
    val jp_length = org_json.getString("jp_length")
    val sub_actual_depart_tm = org_json.getString("sub_actual_depart_tm")
    val sub_actual_arrive_tm = org_json.getString("sub_actual_arrive_tm")
    val warning_time = org_json.getString("warning_time") //todo add
    //部分原始字段空值处理
    val duation_periods_tmp = org_json.getString("duation_periods")
    val events_swid_tmp = org_json.getString("events_swid")
    val events_code_tmp = org_json.getString("events_code")
    val events_S_tmp = org_json.getString("events_S")
    val events_L_tmp = org_json.getString("events_L")
    val duation_periods = if (strNotNull(duation_periods_tmp)) duation_periods_tmp else ""
    val events_swid = if (strNotNull(events_swid_tmp)) events_swid_tmp else ""
    val events_code = if (strNotNull(events_code_tmp)) events_code_tmp else ""
    val events_S = if (strNotNull(events_S_tmp)) events_S_tmp else ""
    val events_L = if (strNotNull(events_L_tmp)) events_L_tmp else ""
    //2 计算逻辑
    val event_map = getEventMap(events_swid, events_code, events_S, events_L)
    val swid_speed_map = getSwidSpeedMap(swid_gd, speed_gd)
    val swid_length_map = getSwidLengthMap(jp_swid, jp_length)
    val xh_yd = getXuhaoAndYongdu(status_gd, swid_gd)
    val xuhao = xh_yd._1
    val yongdu_swid_tmp = xh_yd._2
    val yongdu_status = xh_yd._3
    val yt_m = getYongdutime(yongdu_swid_tmp, jp_swid, jp_time)
    val yongdu_time = yt_m._1
    val yongdu_time_tms = yt_m._2
    val fix_tm = mergeAndFixTm(xuhao, sub_actual_depart_tm, sub_actual_arrive_tm, yongdu_time_tms, jp_time, jp_swid, warning_time) //todo add warning_time
    val yongdu_time2 = fix_tm._1
    val xuhao2 = fix_tm._2
    val merge_index = fix_tm._3
    val yongdu_status2 = mergeYongduStatus(xuhao2, status_gd)
    val if_stay = durationIntersection(yongdu_time2, duation_periods)
    //jp 信息
    val coordsSwidTime = getSumDistCoordsSwid(merge_index, jp_coords, jp_swid, jp_time)
    val yongdu_coords = coordsSwidTime._1
    val yongdu_swid = coordsSwidTime._2
    val yongdu_continue_tm = coordsSwidTime._3
    val yongdu_total_duration = coordsSwidTime._4
    //事件 信息
    val event_info = getEventInfo(yongdu_swid, event_map)
    val yongdu_events_swid = event_info._1
    val yongdu_events_code = event_info._2
    val yogndu_events_s = event_info._3
    val yongdu_events_l = event_info._4
    val yd_swid_speed = getYongduSwidAndSpeed(xuhao2, swid_gd, speed_gd, swid_speed_map)
    val yongdu_swid_gd = yd_swid_speed._1
    val yongdu_speed_gd = yd_swid_speed._2
    val yongdu_swid_gd2 = yd_swid_speed._3
    val yongdu_speed_gd2 = yd_swid_speed._4
    val yongdu_swid_gd_len = getLength(yongdu_swid_gd2, swid_length_map)
    val speed_len_info = getSpeedAvg(yongdu_speed_gd2, yongdu_swid_gd_len)
    val yongdu_speed_avg_gd = speed_len_info._1
    val yongdu_gd_len = speed_len_info._2

    //3 结果字段添加
    val yongduJo = new JSONObject()
    yongduJo.put("xuhao", xuhao)
    yongduJo.put("yongdu_time", yongdu_time)
    yongduJo.put("yongdu_status", yongdu_status)
    yongduJo.put("yongdu_time2", yongdu_time2)
    yongduJo.put("xuhao2", xuhao2)
    yongduJo.put("yongdu_status2", yongdu_status2)
    yongduJo.put("if_stay", if_stay)
    yongduJo.put("yongdu_coords", yongdu_coords)
    yongduJo.put("yongdu_swid", yongdu_swid)
    yongduJo.put("yongdu_continue_tm", yongdu_continue_tm)
    yongduJo.put("yongdu_total_duration", yongdu_total_duration)
    yongduJo.put("yongdu_events_swid", yongdu_events_swid)
    yongduJo.put("yongdu_events_code", yongdu_events_code)
    yongduJo.put("yogndu_events_s", yogndu_events_s)
    yongduJo.put("yongdu_events_l", yongdu_events_l)
    yongduJo.put("yongdu_swid_gd", yongdu_swid_gd)
    yongduJo.put("yongdu_speed_gd", yongdu_speed_gd)
    yongduJo.put("yongdu_swid_gd2", yongdu_swid_gd2)
    yongduJo.put("yongdu_speed_gd2", yongdu_speed_gd2)
    yongduJo.put("yongdu_swid_gd_len", yongdu_swid_gd_len)
    yongduJo.put("yongdu_speed_avg_gd", yongdu_speed_avg_gd)
    yongduJo.put("yongdu_gd_len", yongdu_gd_len)
    //2-2 4.4部分
    //调用经验速度接口
    val post_jam = postJamRequest(yongdu_swid, yongdu_time2, jp_swid, jp_length, url)
    val swid_exp = post_jam._1
    val speed_exp = post_jam._2
    val swid_len_exp = post_jam._3
    val disu_duration_exp = post_jam._4
    val sum_swid_len_exp = post_jam._5
    val disu_duration_subob = getDisuDurationSubob(yongdu_continue_tm, disu_duration_exp)
    val speed_siji = speedSiji(sum_swid_len_exp, yongdu_continue_tm)
    val is_keguan = getIsKeguan(yongdu_time2, disu_duration_subob, if_stay, yongdu_speed_avg_gd, speed_siji)
    yongduJo.put("swid_exp", swid_exp)
    yongduJo.put("swid_len_exp", swid_len_exp)
    yongduJo.put("speed_exp", speed_exp)
    yongduJo.put("disu_duration_exp", disu_duration_exp)
    yongduJo.put("disu_duration_subob", disu_duration_subob)
    yongduJo.put("speed_siji", speed_siji)
    yongduJo.put("is_keguan", is_keguan)

    yongduJo
  }

  def speedSiji(sum_swid_len_exp: String, yongdu_continue_tm: String): String = {
    val speed_siji_ab = new ListBuffer[String]()
    if (strNotNull(sum_swid_len_exp)) {
      try {
        val sum_len_arr = sum_swid_len_exp.split(";")
        val yd_tm_arr = yongdu_continue_tm.split(";")
        for (i <- 0 until sum_len_arr.size) {
          val tmp = if (yd_tm_arr(i).toDouble > 0) {
            (sum_len_arr(i).toDouble * 3.6 / yd_tm_arr(i).toDouble).formatted("%.2f")
          } else "-"
          speed_siji_ab += tmp
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    speed_siji_ab.mkString(";")
  }

  def getDisuDurationSubob(yongdu_continue_tm: String, disu_duration_exp: String): String = {
    val disu_duration_subob = new ListBuffer[String]()
    if (strNotNull(yongdu_continue_tm)) {
      try {
        val ct_tm_arr = yongdu_continue_tm.split(";")
        val ex_tm_arr = disu_duration_exp.split(";")
        for (i <- 0 until ct_tm_arr.size) {
          val tmp = if (ct_tm_arr(i).toDouble < ex_tm_arr(i).toDouble) "0" else (ct_tm_arr(i).toDouble - ex_tm_arr(i).toDouble).toString
          disu_duration_subob += tmp

        }
      } catch {
        case e: Exception => "" + e
      }
    }
    disu_duration_subob.mkString(";")
  }

  def getIsKeguan(yongdu_time2: String, disu_duration_subob: String, if_stay: String, yongdu_speed_avg_gd: String, speed_siji: String): String = {
    var is_keguan = new ListBuffer[String]()
    if (strNotNull(disu_duration_subob)) {
      try {
        val yd_tm_arr = yongdu_time2.split(";")
        val dt_ob_arr = disu_duration_subob.split(";")
        val if_stay_arr = if_stay.split(";")
        val avg_gd_arr = yongdu_speed_avg_gd.split(";")
        val speed_arr = speed_siji.split(";")
        for (i <- 0 until dt_ob_arr.size) {
          val start_tm = yd_tm_arr(i).split("_")(0)
          val end_tm = yd_tm_arr(i).split("_")(1)
          if (start_tm > end_tm) {
            is_keguan += "无多余时长"
          } else if (dt_ob_arr(i).toDouble < 60.0) {
            is_keguan += "无多余时长"
          } else if (if_stay_arr(i) == "true" && avg_gd_arr(i).toDouble - speed_arr(i).toDouble <= 15.0) {
            is_keguan += "停留客观"
          } else if (if_stay_arr(i) == "true") {
            is_keguan += "停留"
          } else if (if_stay_arr(i) == "false" && avg_gd_arr(i).toDouble - speed_arr(i).toDouble <= 30.0) {
            is_keguan += "低速客观"
          } else if (if_stay_arr(i) == "false") {
            is_keguan += "低速"
          }
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    is_keguan.mkString(";")
  }

  def postJamRequest(yongdu_swid: String, yongdu_time2: String, jp_swid: String, jp_length: String, url: String): (String, String, String, String, String) = {
    val out_swid_exp_arr, out_speed_exp_arr, out_swid_len_exp_arr, out_disu_duration_exp, out_sum_swid_len_exp = new ListBuffer[String]()
    val task_swid_map = getSwidLengthMap(jp_swid, jp_length)
    //    val url = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/getExprCost"
    //    val url = "http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/getExprCost"

    //    val url = HttpConstantTest.HTTP_GIS_EXP_COST;
    //    val url = HttpConstant.HTTP_GIS_EXP_COST;

    if (strNotNull(yongdu_swid)) {
      val yongdu_swid_arr = yongdu_swid.split(";")
      val yongdu_time2_arr = yongdu_time2.split(";")
      for (i <- 0 until (yongdu_swid_arr.length)) {
        val swid_exp_arr, speed_exp_arr, swid_len_exp_arr = new ListBuffer[String]()
        var disu_duration_exp, sum_swid_len_exp = 0.0
        val links = yongdu_swid_arr(i).replaceAll("\\|", ",")
        //去重后调接口
        val diff_links = diffSwid(links)
        val time = yongdu_time2_arr(i).split("_")(0).replaceAll("\\s+", "T").replaceAll("-|:", "")
        val start_time = yongdu_time2_arr(i).split("_")(0).split("\\s+")(1).replaceAll(":", "")
        // 生产
        val params = s"""{"ak": "dc894b4a3c7444b4a3505315d00b87ad","swId": 1,"links": "$diff_links","type": 1,"time": "$time","output": "json","gzip": "0","roadAttrToken": "6134FAA5B6B6ED55E87EA116466734ED"}""".stripMargin

        //测试
        //        val params = s"""{"ak": "12fe501477bc44e49cbbe61a6c1d8866","swId": 1,"links": "$diff_links","type": 1,"time": "$time","output": "json","gzip": "0","roadAttrToken": "000011112222333344445555666677778888"}""".stripMargin

        var jy_tracks: JSONArray = null
        try {
          //          val jam_str = HttpUtils.doPost(url,JSON.parseObject(params))
          val jam_str = ""
          //          System.err.println(">>>>>>>>>>接口正常调用中>>>>>>>" + params)
          val jam_str_json = JSON.parseObject(jam_str)
          jy_tracks = jam_str_json.getJSONArray("linkCostArray")
        } catch {
          case e: Exception => ""
        }
        if (jy_tracks != null && jy_tracks.size() > 0) {
          for (i <- 0 until jy_tracks.size()) {
            val linkID = jy_tracks.getJSONObject(i).getString("linkID")
            swid_exp_arr += linkID
            //获取swid返回的长度
            val swid_len = task_swid_map.getOrElse(linkID, "")
            if (swid_len.trim != "") {
              swid_len_exp_arr += swid_len
            } else {
              swid_len_exp_arr += "0"
            }
            //低速速度拼接 km/h
            val costArray = jy_tracks.getJSONObject(i).getJSONArray("costArray")
            var diff = 235959
            var speed_exp_t = "0"
            if (costArray != null && costArray.size() > 0) {
              for (j <- 0 until costArray.size()) {
                val startTime = costArray.getJSONObject(j).getString("startTime")
                val speed = costArray.getJSONObject(j).getString("speed")
                val cur_diff = Math.abs(start_time.toDouble.toInt - startTime.toInt * 100) //start_time = 235523
                if (cur_diff <= diff) {
                  diff = cur_diff
                  speed_exp_t = speed
                }
              }
              val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
              disu_duration_exp += sd_tmp
              speed_exp_arr += speed_exp_t
            } else {
              val staticspeed = jy_tracks.getJSONObject(i).getString("staticSpeed")
              if (staticspeed != null) {
                speed_exp_t = staticspeed
                val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
                speed_exp_arr += staticspeed
                disu_duration_exp += sd_tmp
              } else {
                speed_exp_arr += "-"
              }
            }
          }
        }
        if (swid_len_exp_arr.size > 0) sum_swid_len_exp = swid_len_exp_arr.map(_.toDouble).sum
        if (swid_exp_arr.size == 0) swid_exp_arr += "-"
        if (speed_exp_arr.size == 0) speed_exp_arr += "-"
        if (swid_len_exp_arr.size == 0) swid_len_exp_arr += "-"
        out_swid_exp_arr += swid_exp_arr.mkString("|")
        out_speed_exp_arr += speed_exp_arr.mkString("|")
        out_swid_len_exp_arr += swid_len_exp_arr.mkString("|")
        out_disu_duration_exp += disu_duration_exp.formatted("%.2f")
        out_sum_swid_len_exp += sum_swid_len_exp.formatted("%.2f")
      }
    }
    (out_swid_exp_arr.mkString(";"), out_speed_exp_arr.mkString(";"), out_swid_len_exp_arr.mkString(";"), out_disu_duration_exp.mkString(";"), out_sum_swid_len_exp.mkString(";"))
  }


  def diffSwid(swid: String) = {
    var new_swid: Array[String] = null
    try {
      val swid_arr = swid.split(",")
      new_swid = new Array[String](swid_arr.size)
      for (i <- 0 until swid_arr.size) {
        if (swid_arr(i) != "0") {
          if (i < 1) new_swid(i) = swid_arr(i)
          if (i >= 1 && swid_arr(i) != swid_arr(i - 1)) new_swid(i) = swid_arr(i)
        }
      }
    } catch {
      case e: Exception => e + ""
    }
    new_swid.filter(_ != null).mkString(",")
  }

  def getSpeedAvg(yongdu_speed_gd2: String, yongdu_swid_gd_len: String): (String, String) = {
    val total_len, yongdu_speed_avg_gd = new ListBuffer[String]()
    if (strNotNull(yongdu_speed_gd2) && strNotNull(yongdu_swid_gd_len)) {
      val speed_arr = yongdu_speed_gd2.split(";", -1)
      val len_arr = yongdu_swid_gd_len.split(";", -1)
      for (i <- 0 until speed_arr.size) {
        val in_len_arr = len_arr(i).split("\\|", -1)
        val in_speed_arr = speed_arr(i).split("\\|", -1)
        var in_len, in_tm, in_total_len: Double = 0.0
        for (j <- 0 until in_speed_arr.size) {
          in_total_len += (try {
            in_len_arr(j).toDouble
          } catch {
            case e: NumberFormatException => 0.0
          })
          if (strNotNull(in_speed_arr(j)) && in_speed_arr(j) != "") {
            in_len += (try {
              in_len_arr(j).toDouble
            } catch {
              case e: NumberFormatException => 0.0
            })
            in_tm += (try {
              in_len_arr(j).toDouble
            } catch {
              case e: NumberFormatException => 0.0
            }) / 1000.0 / in_speed_arr(j).toDouble
          }
        }
        yongdu_speed_avg_gd += (in_len / 1000.0 / in_tm).formatted("%.2f")
        total_len += in_total_len.toString
      }

    }
    (yongdu_speed_avg_gd.mkString(";"), total_len.mkString(";"))
  }

  def getLength(yongdu_swid_gd2: String, swid_length_map: collection.mutable.Map[String, String]): String = {
    val yd_len_ab = new ListBuffer[String]()
    if (strNotNull(yongdu_swid_gd2)) {
      val yongdu_swid_gd2_arr = yongdu_swid_gd2.split(";")
      for (i <- 0 until yongdu_swid_gd2_arr.length) {
        val one = yongdu_swid_gd2_arr(i).split("\\|")
        val len_ab = new ListBuffer[String]()
        for (j <- 0 until one.size) {
          val len = swid_length_map.getOrElse(one(j), "-")
          len_ab += len
        }
        yd_len_ab += len_ab.mkString("|")
      }
    }
    yd_len_ab.mkString(";")
  }

  def getYongduSwidAndSpeed(xuhao2: String, swid_gd: String, speed_gd: String, swid_speed_map: collection.mutable.Map[String, String]): (String, String, String, String) = {
    val yd_swid_ab, yd_speed_ab, yd_swid_diff_ab, yd_speed_diff_ab = new ArrayBuffer[String]()
    if (strNotNull(xuhao2) && strNotNull(swid_gd) && strNotNull(speed_gd)) {
      val xuhao2_arr = xuhao2.split(";")
      val swid_gd_arr = swid_gd.split("\\|")
      val speed_gd_arr = speed_gd.split("\\|")
      for (i <- 0 until xuhao2_arr.size) {
        val start_index = xuhao2_arr(i).split("_")(0).toInt
        val end_index = xuhao2_arr(i).split("_")(1).toInt
        val swid_ab, speed_ab, swid_diff_ab, speed_diff_ab = new ArrayBuffer[String]()
        for (j <- start_index to end_index) {
          swid_ab += swid_gd_arr(j)
          speed_ab += speed_gd_arr(j)
          if (!swid_diff_ab.contains(swid_gd_arr(j))) {
            val speed = swid_speed_map.getOrElse(swid_gd_arr(j), "0")
            swid_diff_ab += swid_gd_arr(j)
            speed_diff_ab += speed
          }
        }
        yd_swid_ab += swid_ab.mkString("|")
        yd_speed_ab += speed_ab.mkString("|")
        yd_swid_diff_ab += swid_diff_ab.mkString("|")
        yd_speed_diff_ab += speed_diff_ab.mkString("|")
      }
    }
    (yd_swid_ab.mkString(";"), yd_speed_ab.mkString(";"), yd_swid_diff_ab.mkString(";"), yd_speed_diff_ab.mkString(";"))
  }

  def getEventInfo(yongdu_swid: String, event_map: collection.mutable.Map[String, ListBuffer[(String, String, String)]]): (String, String, String, String) = {
    val yongdu_events_swid, yongdu_events_code, yogndu_events_S, yongdu_events_L = new ListBuffer[String]()
    if (strNotNull(yongdu_swid)) {
      val yongdu_swid_arr = yongdu_swid.split(";")
      for (i <- 0 until yongdu_swid_arr.size) {
        val one_swid = yongdu_swid_arr(i).split("\\|")

        val in_yongdu_events_swid, in_yongdu_events_code, in_yogndu_events_S, in_yongdu_events_L = new ListBuffer[String]()
        val diff_swid = new mutable.HashSet[String]()
        var cnt_flag: Int = 0
        for (j <- 0 until one_swid.size) {
          if (event_map.contains(one_swid(j))) {
            val default_lb = new ListBuffer[(String, String, String)]()
            val map_back = event_map.getOrElse(one_swid(j), default_lb)

            if (!diff_swid.contains(one_swid(j))) {
              cnt_flag = 0
              in_yongdu_events_swid += one_swid(j)
              in_yongdu_events_code += map_back(cnt_flag)._1
              in_yogndu_events_S += map_back(cnt_flag)._2
              in_yongdu_events_L += map_back(cnt_flag)._3
              diff_swid.add(one_swid(j))
              cnt_flag += 1
            } else {
              if (cnt_flag <= map_back.size - 1) {
                in_yongdu_events_swid += one_swid(j)
                in_yongdu_events_code += map_back(cnt_flag)._1
                in_yogndu_events_S += map_back(cnt_flag)._2
                in_yongdu_events_L += map_back(cnt_flag)._3
                cnt_flag += 1
              }
            }
          }
        }
        if (in_yongdu_events_swid.size == 0) in_yongdu_events_swid += "-"
        if (in_yongdu_events_code.size == 0) in_yongdu_events_code += "-"
        if (in_yogndu_events_S.size == 0) in_yogndu_events_S += "-"
        if (in_yongdu_events_L.size == 0) in_yongdu_events_L += "-"
        yongdu_events_swid += in_yongdu_events_swid.mkString("|")
        yongdu_events_code += in_yongdu_events_code.mkString("|")
        yogndu_events_S += in_yogndu_events_S.mkString("|")
        yongdu_events_L += in_yongdu_events_L.mkString("|")
      }
    }
    (yongdu_events_swid.mkString(";"), yongdu_events_code.mkString(";"), yogndu_events_S.mkString(";"), yongdu_events_L.mkString(";"))
  }

  def getSwidLengthMap(jp_swid: String, jp_length: String): collection.mutable.Map[String, String] = {
    val swid_length_map = collection.mutable.Map[String, String]()
    if (strNotNull(jp_swid) && strNotNull(jp_length)) {
      val jp_swid_arr = jp_swid.split("\\|")
      val jp_length_arr = jp_length.split("\\|")
      for (i <- 0 until jp_swid_arr.size) {
        swid_length_map.put(jp_swid_arr(i), jp_length_arr(i))
      }
    }
    swid_length_map
  }

  def getSwidSpeedMap(swid_gd: String, speed_gd: String): collection.mutable.Map[String, String] = {
    val swid_speed_map = collection.mutable.Map[String, String]()
    if (strNotNull(swid_gd) && strNotNull(speed_gd)) {
      val swid_gd_arr = swid_gd.split("\\|")
      val speed_gd_arr = speed_gd.split("\\|")
      for (i <- 0 until swid_gd_arr.size) {
        if (swid_speed_map.contains(swid_gd_arr(i))) {
          val speed = swid_speed_map.getOrElse(swid_gd_arr(i), "0")
          if (speed_gd_arr(i).toDouble < speed.toDouble) {
            swid_speed_map.put(swid_gd_arr(i), speed_gd_arr(i))
          }
        } else {
          swid_speed_map.put(swid_gd_arr(i), speed_gd_arr(i))
        }
      }
    }
    swid_speed_map
  }


  def getEventMap(events_swid: String, events_code: String, events_S: String, events_L: String): collection.mutable.Map[String, ListBuffer[(String, String, String)]] = {
    val event_map = collection.mutable.Map[String, ListBuffer[(String, String, String)]]()
    if (strNotNull(events_swid) && strNotNull(events_code) && strNotNull(events_S) && strNotNull(events_L)) {
      val events_swid_arr = events_swid.split("\\|", -1)
      val events_code_arr = events_code.split("\\|", -1)
      val events_S_arr = events_S.split("\\|", -1)
      val events_L_arr = events_L.split("\\|", -1)
      for (i <- 0 until events_swid_arr.size) {
        if (strNotNull(events_swid_arr(i))) {
          if (!event_map.contains(events_swid_arr(i))) {
            val new_ab = new ListBuffer[(String, String, String)]()
            new_ab += Tuple3(events_code_arr(i), events_S_arr(i), events_L_arr(i))
            event_map.put(events_swid_arr(i), new_ab)
          } else {
            val add_ab = event_map.getOrElse(events_swid_arr(i), ListBuffer())
            add_ab += Tuple3(events_code_arr(i), events_S_arr(i), events_L_arr(i))
            event_map.put(events_swid_arr(i), add_ab)
          }
        }
      }
    }
    event_map
  }

  def getSumDistCoordsSwid(merge_index: String, jp_coords: String, jp_swid: String, jp_time: String): (String, String, String, Long) = {
    val jp_coords_p, jp_swid_p, time_p = new ListBuffer[String]()
    var yongdu_total_duration: Long = 0l
    try {
      if (strNotNull(merge_index) && strNotNull(jp_coords) && strNotNull(jp_swid)) {
        val indexs: Array[String] = strHandle(merge_index, ";")
        val jp_coords_arr: Array[String] = strHandle(jp_coords, "\\|")
        val jp_swid_arr: Array[String] = strHandle(jp_swid, "\\|")
        val jp_time_arr: Array[String] = strHandle(jp_time, "\\|")
        for (index <- indexs) {
          val start_index = index.split("_")(0).toInt
          val end_index = index.split("_")(1).toInt
          val tm_inter = jp_time_arr(end_index).toLong - jp_time_arr(start_index).toLong
          time_p += tm_inter.toString
          yongdu_total_duration += tm_inter
          if (end_index + 1 < jp_coords_arr.length - 1) {
            jp_coords_p += jp_coords_arr.slice(start_index, end_index + 1).mkString("|") //同个停留时段内的 经纬度集合用;分割  不应用自带的 | 分割
            jp_swid_p += jp_swid_arr.slice(start_index, end_index + 1).mkString("|")
          } else {
            jp_coords_p += jp_coords_arr.slice(start_index, jp_coords_arr.length - 1).mkString("|") //同个停留时段内的 经纬度集合用;分割  不应用自带的 | 分割
            jp_swid_p += jp_swid_arr.slice(start_index, jp_swid_arr.length - 1).mkString("|")
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    //结果包含3部分信息： jp_coords截取部分拼接 & jp_swid 截取部分拼接 & 时间time 截取部分拼接
    (jp_coords_p.mkString(";"), jp_swid_p.mkString(";"), time_p.mkString(";"), yongdu_total_duration)
  }


  def strHandle(str: String, sep: String, flag: Boolean = true): Array[String] = {
    var res: Array[String] = Array()
    try {
      if (flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep)
      //是否需要排序
      if (!flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep).sortWith(_.compareTo(_) < 0)
    } catch {
      case e: ArrayIndexOutOfBoundsException => ""
    }
    res
  }

  def durationIntersection(yongdu_time2: String, duation_periods: String): String = {
    val if_stay = new ListBuffer[String]
    if (strNotNull(yongdu_time2)) {
      val yongdu_time2_arr = yongdu_time2.split(";")
      for (i <- 0 until yongdu_time2_arr.size) {
        val start_tm = yongdu_time2_arr(i).split("_")(0)
        val end_tm = yongdu_time2_arr(i).split("_")(1)
        val start_stm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm)
        val end_etm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm)
        if (duation_periods == null || duation_periods.isEmpty || duation_periods.trim == "") {
          if_stay += "false"
        }
        var flag_stay = "false"
        if (strNotNull(duation_periods)) {
          val periods_arr = duation_periods.split("\\|")
          breakable {
            for (j <- 0 until periods_arr.size) {
              val start_tm_pd = periods_arr(j).split("~")(0)
              val end_tm_pd = periods_arr(j).split("~")(1)
              val start_stm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm_pd)
              val end_etm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm_pd)
              if (twoGroupinterLong(start_stm, end_etm, start_stm_pd, end_etm_pd) > 0l) {
                flag_stay = "true"
                break()
              }
            }
          }
          if_stay += flag_stay
        }
      }
    }
    if_stay.mkString(";")
  }


  /**
   * 给定时间区间 long值【0，30】--【3，10】
   *
   * @return 7（l）
   */
  def twoGroupinterLong(statistics_start_tm: Long, statistics_end_tm: Long, start_tm: Long, end_tm: Long) = {
    var diff: Long = 0
    try {
      if (statistics_end_tm < start_tm || end_tm < statistics_start_tm) {
        diff = 0
      } else if (statistics_start_tm <= start_tm && end_tm <= statistics_end_tm) {
        diff = end_tm - start_tm // 60
      } else if (start_tm <= statistics_start_tm && statistics_end_tm <= end_tm) {
        diff = statistics_end_tm - statistics_start_tm // 60
      } else if (start_tm <= statistics_end_tm && start_tm >= statistics_start_tm && statistics_end_tm <= end_tm) {
        diff = statistics_end_tm - start_tm // 60
      } else if (statistics_start_tm <= end_tm && statistics_start_tm >= start_tm && end_tm <= statistics_end_tm) {
        diff = end_tm - statistics_start_tm // 60
      } else {
        diff = 0
      }
    } catch {
      case e: Exception => ""
    }
    diff
  }

  def mergeYongduStatus(Xuhao2: String, status_gd: String): String = {
    val yongdu_status2_ab = new ListBuffer[String]()
    if (strNotNull(Xuhao2) && strNotNull(status_gd)) {
      val Xuhao2_arr = Xuhao2.split(";")
      val status_gd_arr = status_gd.split("\\|") //原始数据切割符
      for (i <- 0 until Xuhao2_arr.size) {
        val start_index = Xuhao2_arr(i).split("_")(0).toInt
        val end_index = Xuhao2_arr(i).split("_")(1).toInt
        val status_hs = new mutable.HashSet[String]()
        for (j <- start_index to end_index) {
          if (Seq("2", "3", "4").contains(status_gd_arr(j))) {
            status_hs.add(status_gd_arr(j))
          }
        }
        yongdu_status2_ab += status_hs.mkString(",")
      }
    }
    yongdu_status2_ab.mkString(";")
  }

  def getYongdutime(swid_gd: String, jp_swid: String, jp_time: String): (String, String) = {
    val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")
    val road_time_tms_ab, road_time_ab = new ArrayBuffer[String]()
    if (strNotNull(swid_gd) && strNotNull(jp_swid) && strNotNull(jp_time)) {
      val swid_gd_arr = swid_gd.split(";")
      val jp_swid_arr = jp_swid.split("\\|")
      val jp_time_arr = jp_time.split("\\|")
      for (i <- 0 until swid_gd_arr.length) {
        var start_tm, end_tm = "-"
        var start_tm_lo, end_tm_lo = 0l
        try {
          val s_swid = swid_gd_arr(i).split("_")(0)
          val e_swid = swid_gd_arr(i).split("_")(1)
          if (s_swid != "-") {
            breakable {
              for (j <- 0 until jp_swid_arr.length) {
                if (jp_swid_arr(j) == s_swid) {
                  start_tm_lo = jp_time_arr(j).toLong
                  start_tm = tranTstampToTime(sdf1, jp_time_arr(j))
                  break()
                }
              }
            }
          } else {
            start_tm = "-"
          }
          if (s_swid != "-") {
            breakable {
              for (k <- (0 until jp_swid_arr.length).reverse) {
                if (jp_swid_arr(k) == e_swid) {
                  end_tm_lo = jp_time_arr(k).toLong
                  end_tm = tranTstampToTime(sdf1, jp_time_arr(k))
                  break()
                }
              }
            }
          } else {
            end_tm = "-"
          }
        } catch {
          case e: Exception => "" + e
        }
        road_time_tms_ab += start_tm_lo + "_" + end_tm_lo
        road_time_ab += start_tm + "_" + end_tm
      }
    }
    (road_time_ab.mkString(";"), road_time_tms_ab.mkString(";"))
  }


  //todo fix 时间乱序的问题
  def mergeAndFixTm(xuhao: String, sub_actual_depart_tm: String, sub_actual_arrive_tm: String, road_time_tms: String, jp_time: String, jp_swid: String, warning_time: String): (String, String, String) = {
    //判断时间间隔 并进行合并
    val merge_tm, fix_merge_tm, merge_xuhao = new ListBuffer[String]()
    try {
      val xuhao_arr = xuhao.split(";")
      val road_time_tms_ab = road_time_tms.split(";")
      var cnt = 0
      for (i <- 0 until road_time_tms_ab.size if i == cnt) {
        val s_tm = road_time_tms_ab(i).split("_")(0).toLong
        val e_tm = road_time_tms_ab(i).split("_")(1).toLong
        //xuhao
        val s_xuhao = xuhao_arr(i).split("_")(0)
        val e_xuhao = xuhao_arr(i).split("_")(1)
        breakable {
          for (j <- i + 1 until road_time_tms_ab.size if i + 1 <= road_time_tms_ab.size - 1) {
            val s_tm_p = road_time_tms_ab(j - 1).split("_")(0).toLong
            val e_tm_p = road_time_tms_ab(j - 1).split("_")(1).toLong
            val s_tm_pp = road_time_tms_ab(j).split("_")(0).toLong
            val e_tm_pp = road_time_tms_ab(j).split("_")(1).toLong
            //xuhao
            val s_xuhao_p = xuhao_arr(j - 1).split("_")(0)
            val e_xuhao_p = xuhao_arr(j - 1).split("_")(1)
            val s_xuhao_pp = xuhao_arr(j).split("_")(0)
            val e_xuhao_pp = xuhao_arr(j).split("_")(1)
            if (s_tm_p <= s_tm_pp) {
              if (j == i + 1) {
                if (s_tm_pp - e_tm > 5 * 60) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao
                  cnt = j
                  break()
                }
                if (j == road_time_tms_ab.size - 1) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_pp + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_pp
                }
              } else {
                if (s_tm_pp - e_tm_p > 5 * 60) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_p + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_p
                  cnt = j
                  break()
                }
                if (j == road_time_tms_ab.size - 1) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_pp + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_pp
                }
              }
            } else {
              if (j + 1 <= road_time_tms_ab.size - 1) {
                cnt = j + 1
                break()
              }
            }
          }
        }
        if (i == road_time_tms_ab.size - 1) {
          merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm + 2 * 60).toString)
          merge_xuhao += s_xuhao + "_" + e_xuhao
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    //计算开始和结束拥堵路段的信息
    //"sub_plan_arrive_tm":"2023-06-12 18:20:00|2023-06-12 19:15:00"
    if (merge_tm.size == 1) {
      val f1_start_tm = merge_tm(0).split("_")(0)
      val f1_end_tm = merge_tm(0).split("_")(1)
      var new_sttm = f1_start_tm
      var new_endm = f1_end_tm
      if (f1_start_tm < sub_actual_depart_tm) new_sttm = sub_actual_depart_tm
      if (f1_end_tm > sub_actual_arrive_tm) new_endm = sub_actual_arrive_tm
      fix_merge_tm += new_sttm + "_" + new_endm
    } else {
      for (k <- 0 until merge_tm.size) {
        val f1_start_tm = merge_tm(k).split("_")(0)
        val f1_end_tm = merge_tm(k).split("_")(1)
        if (k == 0) {
          if (f1_start_tm < sub_actual_depart_tm) {
            fix_merge_tm += sub_actual_depart_tm + "_" + f1_end_tm
          } else {
            fix_merge_tm += f1_start_tm + "_" + f1_end_tm
          }
        } else if (k == merge_tm.size - 1) {
          if (f1_end_tm > sub_actual_arrive_tm) {
            fix_merge_tm += f1_start_tm + "_" + sub_actual_arrive_tm
          } else {
            fix_merge_tm += f1_start_tm + "_" + f1_end_tm
          }
        } else {
          fix_merge_tm += f1_start_tm + "_" + f1_end_tm
        }
      }
    }
    //todo add
    val yd_warning = diffYongduAndWarningTime(fix_merge_tm, merge_xuhao, warning_time)
    val fix_yd_time = yd_warning._1
    val fix_xuhao = yd_warning._2
    val jp_time_arr = jp_time.split("\\|")
    val jp_swid_arr = jp_swid.split("\\|")
    //传入合并后的起始结束时间 纠偏时间集合
    val jp_index = getStartEndIndexFromJPTimeWithTimeBack(fix_yd_time, jp_time_arr, jp_swid_arr, timeToTimestampFormat)
    val start_index_arr = jp_index._1
    val end_index_arr = jp_index._2
    val start_end_index_arr = start_index_arr.zip(end_index_arr) map { x => x._1 + "_" + x._2 }

    (fix_yd_time.mkString(";"), fix_xuhao.mkString(";"), start_end_index_arr.mkString(";"))
  }


  /**
   * 合并后的低速时段 在jp_time中找到时间最近的起始 和 结束 时间的index
   *
   * @param ds_start_to_end
   * @param jp_time_arr
   * @param fun
   * @return
   */
  def getStartEndIndexFromJPTimeWithTimeBack(ds_start_to_end: ListBuffer[String], jp_time_arr: Array[String], jp_swid_arr: Array[String], fun: (String, String) => Long): (ListBuffer[Int], ListBuffer[Int], ListBuffer[String], ListBuffer[String]) = {
    val ds_times = ds_start_to_end.flatMap(_.split("_")).map(fun("yyyy-MM-dd HH:mm:ss", _)).sortWith(_.compareTo(_) < 0)
    val start_index_arr, end_index_arr = new ListBuffer[Int]()
    val fix_tm_arr = new Array[String](ds_times.length)
    //停留时间在JP时间里的fix起始和结束时间
    val start_end_tm_arr = new ListBuffer[String]()
    //获取stay_swid，并去重
    val jp_swid_p = new ListBuffer[String]()
    try {
      if (ds_start_to_end.length > 0 && jp_time_arr.length > 0) {
        for (i <- 0 until ds_times.length) {
          if (i % 2 == 0) {
            breakable {
              for (j <- 0 until jp_time_arr.length) {
                if (ds_times(i) <= jp_time_arr(0).toLong) {
                  start_index_arr += 0
                  fix_tm_arr(i) = jp_time_arr(0)
                  break
                } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                  start_index_arr += jp_time_arr.length - 1
                  fix_tm_arr(i) = jp_time_arr(jp_time_arr.length - 1)
                  break
                } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                  if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                    start_index_arr += j
                    fix_tm_arr(i) = jp_time_arr(j)
                  } else {
                    start_index_arr += j + 1
                    fix_tm_arr(i) = jp_time_arr(j + 1)
                  }
                  break
                }
              }
            }
          }
          if (i % 2 == 1) {
            breakable {
              for (j <- 0 until jp_time_arr.length) {
                if (ds_times(i) <= jp_time_arr(0).toLong) {
                  end_index_arr += 0
                  fix_tm_arr(i) = jp_time_arr(0)
                  break
                } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                  end_index_arr += jp_time_arr.length - 1
                  fix_tm_arr(i) = jp_time_arr(jp_time_arr.length - 1)
                  break
                } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                  if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                    end_index_arr += j
                    fix_tm_arr(i) = jp_time_arr(j)
                  } else {
                    end_index_arr += j + 1
                    fix_tm_arr(i) = jp_time_arr(j + 1)
                  }
                  break
                }
              }
            }
          }
        }
      }

      for (k <- 0 until fix_tm_arr.length if k % 2 == 0) {
        start_end_tm_arr += tranTstampToTime(sdf1, fix_tm_arr(k)) + "_" + tranTstampToTime(sdf1, fix_tm_arr(k + 1))
      }

      val indexs = start_index_arr.zip(end_index_arr) map { x => x._1 + "_" + x._2 }
      for (index <- indexs) {
        val start_index = index.split("_")(0).toInt
        val end_index = index.split("_")(1).toInt
        if (end_index + 1 < jp_swid_arr.length - 1) {
          val pt_swid_arr = jp_swid_arr.slice(start_index, end_index + 1)
          val new_pt_swid_arr = new Array[String](pt_swid_arr.length)
          for (i <- 0 until pt_swid_arr.length) {
            if (!new_pt_swid_arr.contains(pt_swid_arr(i))) new_pt_swid_arr(i) = pt_swid_arr(i)
          }
          jp_swid_p += new_pt_swid_arr.filter(_ != null).mkString("|")
        } else {
          val pt_swid_arr = jp_swid_arr.slice(start_index, jp_swid_arr.length - 1)
          val new_pt_swid_arr = new Array[String](pt_swid_arr.length)
          for (i <- 0 until pt_swid_arr.length) {
            if (!new_pt_swid_arr.contains(pt_swid_arr(i))) new_pt_swid_arr(i) = pt_swid_arr(i)
          }
          jp_swid_p += new_pt_swid_arr.filter(_ != null).mkString("|")
        }
      }
    } catch {
      case e: Exception =>
    }
    (start_index_arr, end_index_arr, start_end_tm_arr, jp_swid_p)
  }


  /**
   * 处理停留信息数据
   *
   * @param org_json
   * @return
   */
  def stayInfo(org_json: JSONObject): JSONObject = {
    val status_gd = org_json.getString("status_gd")
    val swid_gd = org_json.getString("swid_gd")
    val speed_gd = org_json.getString("speed_gd")
    val duation_periods_tmp = org_json.getString("duation_periods")
    val duation_periods = if (strNotNull(duation_periods_tmp)) duation_periods_tmp else ""
    val sub_actual_depart_tm = org_json.getString("sub_actual_depart_tm")
    val sub_actual_arrive_tm = org_json.getString("sub_actual_arrive_tm")
    val jp_swid = org_json.getString("jp_swid")
    val jp_time = org_json.getString("jp_time")
    val jp_length = org_json.getString("jp_length")
    val swid_length_map = getSwidLengthMap(jp_swid, jp_length)
    val swid_speed_map = getSwidSpeedMap(swid_gd, speed_gd)
    //todo add 停留stay的信息 新增6个字段
    val stay_start_point_tmp = org_json.getString("stay_start_point")
    val stay_end_point_tmp = org_json.getString("stay_end_point")
    val sub_start_dept_coordinate_tmp = org_json.getString("sub_start_dept_coordinate")
    val sub_end_dept_coordinate_tmp = org_json.getString("sub_end_dept_coordinate")
    val stay_linktype_tmp = org_json.getString("stay_linktype")
    val stay_formway_tmp = org_json.getString("stay_formway")
    val stay_start_point = if (strNotNull(stay_start_point_tmp)) stay_start_point_tmp else ""
    val stay_end_point = if (strNotNull(stay_end_point_tmp)) stay_end_point_tmp else ""
    val sub_start_dept_coordinate = if (strNotNull(sub_start_dept_coordinate_tmp)) sub_start_dept_coordinate_tmp else ""
    val sub_end_dept_coordinate = if (strNotNull(sub_end_dept_coordinate_tmp)) sub_end_dept_coordinate_tmp else ""
    val stay_linktype = if (strNotNull(stay_linktype_tmp)) stay_linktype_tmp else ""
    val stay_formway = if (strNotNull(stay_formway_tmp)) stay_formway_tmp else ""

    val stay_info_1 = getPeriods2WithIndexWithSwid(duation_periods, sub_actual_depart_tm, sub_actual_arrive_tm, jp_time, jp_swid)
    //    val stay_info_1 = try {getPeriods2WithIndexWithSwid(duation_periods, sub_actual_depart_tm, sub_actual_arrive_tm, jp_time, jp_swid)} catch {case e: Exception => (null, null, null, null)}
    val duation_periods2 = stay_info_1._1
    val stay_index1 = stay_info_1._2
    val stay_index2 = stay_info_1._3
    val stay_swid = stay_info_1._4
    val stay_swid_length = getLength(stay_swid, swid_length_map)
    val len_speed = getlengthAndSpeed(stay_swid_length, duation_periods2)
    val stay_swid_length_total = len_speed._1
    val stay_speed_siji = len_speed._2
    val stay_index = getStayGDSwidIndex(stay_swid, swid_gd)
    val status_speed_info = getStaySwidAndSpeed(duation_periods2, stay_index, swid_gd, speed_gd, status_gd, swid_speed_map) //todo fix 占位符添加
    val stay_gd_swid = status_speed_info._1
    val stay_gd_speed = status_speed_info._2
    val stay_gd_status = status_speed_info._3
    val stay_swid_gd2 = status_speed_info._4
    val stay_speed_gd2 = status_speed_info._5
    val stay_swid_gd_len = getLength(stay_swid_gd2, swid_length_map)
    val stay_speed_avg_gd = getStaySpeedAvg(stay_speed_gd2, stay_swid_gd_len)
    val dist_info = getStayDist(stay_start_point, stay_end_point, sub_start_dept_coordinate, sub_end_dept_coordinate)
    val stay_start_dis = dist_info._1
    val stay_end_dis = dist_info._2
    val is_zhuguan = getZhuguan(stay_speed_avg_gd, stay_speed_siji, stay_linktype, stay_gd_status, stay_formway, stay_end_dis)

    val stayJo = new JSONObject()

    import scala.collection.JavaConversions._
    if (strNotNull(duation_periods2)) {
      val javaMap: java.util.Map[String, Any] = Map("duation_periods2" -> duation_periods2, "stay_index1" -> stay_index1, "stay_index2" -> stay_index2, "stay_swid" -> stay_swid, "stay_swid_length" -> stay_swid_length, "stay_swid_length_total" -> stay_swid_length_total, "stay_speed_siji" -> stay_speed_siji, "stay_gd_swid" -> stay_gd_swid, "stay_gd_speed" -> stay_gd_speed, "stay_gd_status" -> stay_gd_status, "stay_swid_gd2" -> stay_swid_gd2, "stay_speed_gd2" -> stay_speed_gd2, "stay_swid_gd_len" -> stay_swid_gd_len, "stay_speed_avg_gd" -> stay_speed_avg_gd, "stay_start_dis" -> stay_start_dis, "stay_end_dis" -> stay_end_dis, "is_zhuguan" -> is_zhuguan)
      stayJo.putAll(javaMap)
    }
    stayJo
  }


  def getZhuguan(stay_speed_avg_gd: String, stay_speed_siji: String, stay_linktype: String, stay_gd_status: String, stay_formway: String, stay_end_dis: String): String = {
    val is_zhuguan_arr = new ListBuffer[String]()
    try {
      if (strNotNull(stay_speed_siji)) {
        val avg_sp_arr = stay_speed_avg_gd.split("\\|")
        val siji_sp_arr = stay_speed_siji.split("\\|")
        val linktype_arr = stay_linktype.split("\\|")
        val status_arr = stay_gd_status.split(";") //todo 分隔符 需注意
        val formway_arr = stay_formway.split("\\|")
        val end_dis_arr = stay_end_dis.split("\\|")
        for (i <- 0 until siji_sp_arr.length) {
          var is_zhuguan = "未识别"
          val status_all = status_arr(i).split("\\|")
          val status_cond = status_all.contains("2") || status_all.contains("3") || status_all.contains("4")
          if (siji_sp_arr(i).toDouble > 50.0 || linktype_arr(i).split(",").contains("2")) {
            is_zhuguan = "异常数据"
          } else if (status_cond) {
            is_zhuguan = "路况拥堵"
          } else if (end_dis_arr(i).toDouble < 1500) {
            is_zhuguan = "终点"
          } else if (formway_arr(i).split(",").contains("5") && (avg_sp_arr(i).toDouble - siji_sp_arr(i).toDouble) > 15.0) {
            is_zhuguan = "服务区"
          } else if ((avg_sp_arr(i).toDouble - siji_sp_arr(i).toDouble) > 15.0) {
            is_zhuguan = "停留主观"
          }
          is_zhuguan_arr += is_zhuguan
        }
      }
    } catch {
      case e: Exception => ""
    }
    is_zhuguan_arr.mkString("|")
  }


  import scala.util.Try

  def getStayDist(stay_start_point: String, stay_end_point: String, sub_start_dept_coordinate: String, sub_end_dept_coordinate: String): (String, String) = {
    val stay_start_dis_arr, stay_end_dis_arr = new ListBuffer[String]()
    try {
      if (strNotNull(stay_end_point) && strNotNull(stay_end_point)) {
        val start_p_arr = stay_start_point.split("\\|")
        val end_p_arr = stay_end_point.split("\\|")
        val sub_s_lng = Try(sub_start_dept_coordinate.split(",")(0).toDouble).getOrElse(0.0)
        val sub_s_lat = Try(sub_start_dept_coordinate.split(",")(1).toDouble).getOrElse(0.0)
        val sub_e_lng = Try(sub_end_dept_coordinate.split(",")(0).toDouble).getOrElse(0.0)
        val sub_e_lat = Try(sub_end_dept_coordinate.split(",")(1).toDouble).getOrElse(0.0)
        for (i <- 0 until start_p_arr.length) {
          val s_lng = Try(start_p_arr(i).split(",")(0).toDouble).getOrElse(0.0)
          val s_lat = Try(start_p_arr(i).split(",")(1).toDouble).getOrElse(0.0)
          val e_lng = Try(end_p_arr(i).split(",")(0).toDouble).getOrElse(0.0)
          val e_lat = Try(end_p_arr(i).split(",")(1).toDouble).getOrElse(0.0)
          stay_start_dis_arr += DistanceTool.getGreatCircleDistance(s_lng, s_lat, sub_s_lng, sub_s_lat).formatted("%.2f")
          stay_end_dis_arr += DistanceTool.getGreatCircleDistance(e_lng, e_lat, sub_e_lng, sub_e_lat).formatted("%.2f")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (stay_start_dis_arr.mkString("|"), stay_end_dis_arr.mkString("|"))
  }


  def getStaySpeedAvg(stay_speed_gd2: String, stay_swid_gd_len: String): String = {
    val stay_speed_avg_gd = new ListBuffer[String]()
    try {
      if (strNotNull(stay_speed_gd2) && strNotNull(stay_swid_gd_len)) {
        val speed_arr = stay_speed_gd2.split(";", -1)
        val len_arr = stay_swid_gd_len.split(";", -1)
        for (i <- 0 until speed_arr.size) {
          val in_len_arr = len_arr(i).split("\\|", -1)
          val in_speed_arr = speed_arr(i).split("\\|", -1)
          var in_len, in_tm, Double = 0.0
          for (j <- 0 until in_speed_arr.size) {
            if (strNotNull(in_speed_arr(j)) && in_speed_arr(j) != "0" && in_speed_arr(j) != "-") {
              in_len += (try {
                in_len_arr(j).toDouble
              } catch {
                case e: NumberFormatException => 0.0
              })
              in_tm += (try {
                in_len_arr(j).toDouble
              } catch {
                case e: NumberFormatException => 0.0
              }) / 1000.0 / in_speed_arr(j).toDouble
            }
          }
          stay_speed_avg_gd += (in_len / 1000.0 / in_tm).formatted("%.2f")
        }
      }
    } catch {
      case e: Exception => ""
    }
    stay_speed_avg_gd.mkString("|")
  }

  def getStaySwidAndSpeed(duation_periods2: String, index: String, swid_gd: String, speed_gd: String, status_gd: String, swid_speed_map: collection.mutable.Map[String, String]): (String, String, String, String, String) = {
    val stay_swid_ab, stay_speed_ab, stay_status_ab, stay_swid_diff_ab, stay_speed_diff_ab = new ArrayBuffer[String]()
    if (strNotNull(index) && strNotNull(swid_gd) && strNotNull(speed_gd) && strNotNull(status_gd)) {
      val index_arr = index.split("\\|")
      val swid_gd_arr = swid_gd.split("\\|")
      val speed_gd_arr = speed_gd.split("\\|")
      val status_gd_arr = status_gd.split("\\|")
      for (i <- 0 until index_arr.size) {
        val swid_ab, speed_ab, status_ab, swid_diff_ab, speed_diff_ab = new ArrayBuffer[String]()
        try {
          val start_index = index_arr(i).split("_")(0).toInt
          val end_index = index_arr(i).split("_")(1).toInt
          for (j <- start_index to end_index) {
            swid_ab += swid_gd_arr(j)
            speed_ab += speed_gd_arr(j)
            status_ab += status_gd_arr(j)
            if (!swid_diff_ab.contains(swid_gd_arr(j))) {
              val speed = swid_speed_map.getOrElse(swid_gd_arr(j), "0")
              swid_diff_ab += swid_gd_arr(j)
              speed_diff_ab += speed
            }
          }
        } catch {
          case e: Exception => "" + e
        }
        stay_swid_ab += (if (swid_ab.size > 0) swid_ab.mkString("|") else "-")
        stay_speed_ab += (if (speed_ab.size > 0) speed_ab.mkString("|") else "-")
        stay_status_ab += (if (status_ab.size > 0) status_ab.mkString("|") else "-")
        stay_swid_diff_ab += (if (swid_diff_ab.size > 0) swid_diff_ab.mkString("|") else "-")
        stay_speed_diff_ab += (if (speed_diff_ab.size > 0) speed_diff_ab.mkString("|") else "-")
      }
    } else {
      if (strNotNull(duation_periods2)) {
        val dura_pd = duation_periods2.split("\\|")
        for (i <- 0 until dura_pd.size) {
          stay_swid_ab += "-"
          stay_speed_ab += "-"
          stay_status_ab += "-"
          stay_swid_diff_ab += "-"
          stay_speed_diff_ab += "-"
        }
      }
    }
    (stay_swid_ab.mkString(";"), stay_speed_ab.mkString(";"), stay_status_ab.mkString(";"), stay_swid_diff_ab.mkString(";"), stay_speed_diff_ab.mkString(";"))
  }

  def getStayGDSwidIndex(stay_swid: String, swid_gd: String): String = {
    val index = new ListBuffer[String]()
    if (strNotNull(stay_swid) && strNotNull(swid_gd)) {
      val swid_arr = stay_swid.split(";")
      val swid_gd_arr = swid_gd.split("\\|")
      try {
        for (i <- 0 until swid_arr.length) {
          val one_swid_arr = swid_arr(i).split("\\|")
          var ac_flag, ne_flag = true
          var start_index, end_index: Int = 999999999
          for (m <- 0 until one_swid_arr.length if ac_flag) {
            if (one_swid_arr(m) != "0") {
              ac_flag = false
              breakable {
                for (x <- 0 until swid_gd_arr.length) {
                  if (one_swid_arr(m) == swid_gd_arr(x)) {
                    start_index = x
                    break()
                  }
                }
              }
            }
          }
          for (n <- (0 until one_swid_arr.length).reverse if ne_flag) {
            if (one_swid_arr(n) != "0") {
              ne_flag = false
              breakable {
                for (y <- (0 until swid_gd_arr.length).reverse) {
                  if (one_swid_arr(n) == swid_gd_arr(y)) {
                    end_index = y
                    break()
                  }
                }
              }
            }
          }
          index += (if (start_index == 999999999) "-" else start_index) + "_" + (if (end_index == 999999999) "-" else end_index)
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    index.mkString("|")
  }


  def getlengthAndSpeed(stay_swid_length: String, duation_periods2: String): (String, String) = {
    val stay_swid_length_total_arr, stay_speed_siji_arr = new ListBuffer[String]()
    try {
      if (strNotNull(stay_swid_length) && strNotNull(duation_periods2)) {
        val len_arr = stay_swid_length.split(";", -1)
        val dura_arr = duation_periods2.split("\\|", -1)
        for (i <- 0 until len_arr.length) {
          val start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_arr(i).split("_")(0))
          val end_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_arr(i).split("_")(1))
          val swid_len_arr = len_arr(i).split("\\|", -1)
          var sum_len = 0.0
          for (j <- 0 until swid_len_arr.size) {
            sum_len += (try {
              swid_len_arr(j).toDouble
            } catch {
              case e: NumberFormatException => 0.0
            })
          }
          stay_swid_length_total_arr += sum_len.formatted("%.2f")
          stay_speed_siji_arr += (sum_len * 3.6 / (end_tm - start_tm)).formatted("%.2f")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (stay_swid_length_total_arr.mkString("|"), stay_speed_siji_arr.mkString("|"))
  }

  /**
   * 停留时段为子任务 task_subid,子任务内部 | 分割，子任务之间 ；分割
   *
   * @param duation_periods
   * @param sub_actual_depart_tm
   * @param sub_actual_arrive_tm
   * @param jp_time
   * @param jp_swid
   * @return
   */
  def getPeriods2WithIndexWithSwid(duation_periods: String, sub_actual_depart_tm: String, sub_actual_arrive_tm: String, jp_time: String, jp_swid: String): (String, String, String, String) = {
    var duation_periods2, stay_index1, stay_index2, stay_swid, dura_arr = new ListBuffer[String]()
    val sub_depart: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_depart_tm)
    val sub_arrive: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_arrive_tm)
    val jp_time_arr = try {
      jp_time.split("\\|")
    } catch {
      case e: Exception => Array[String]()
    }
    val jp_swid_arr = try {
      jp_swid.split("\\|")
    } catch {
      case e: Exception => Array[String]()
    }
    if (strNotNull(duation_periods)) {
      val periods_arr = try {
        duation_periods.split("\\|")
      } catch {
        case e: Exception => Array[String]()
      }
      for (j <- 0 until periods_arr.size) {
        var fix_start_tm, fix_end_tm = ""
        val start_tm_pd = periods_arr(j).split("~")(0)
        val end_tm_pd = periods_arr(j).split("~")(1)
        val start_stm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm_pd)
        val end_etm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm_pd)
        if (start_stm_pd - 60 < sub_depart) {
          fix_start_tm = sub_actual_depart_tm
        } else {
          fix_start_tm = tranTstampToTime(sdf1, (start_stm_pd - 60).toString)
        }
        if (end_etm_pd + 60 > sub_arrive) {
          fix_end_tm = sub_actual_arrive_tm
        } else {
          fix_end_tm = tranTstampToTime(sdf1, (end_etm_pd + 60).toString)
        }
        dura_arr += fix_start_tm + "_" + fix_end_tm
      }
      val jp_time_swid = getStartEndIndexFromJPTimeWithTimeBack(dura_arr, jp_time_arr, jp_swid_arr, timeToTimestampFormat)
      stay_index1 = jp_time_swid._1.map(_.toString)
      stay_index2 = jp_time_swid._2.map(_.toString)
      duation_periods2 = jp_time_swid._3
      stay_swid = jp_time_swid._4
    }
    (duation_periods2.mkString("|"), stay_index1.mkString("|"), stay_index2.mkString("|"), stay_swid.mkString(";"))
  }


  /**
   * 合并后的低速时段 在jp_time中找到时间最近的起始 和 结束 时间的index
   *
   * @param ds_start_to_end
   * @param jp_time_arr
   * @param fun
   * @return
   */
  def getStartEndIndexFromJPTime(ds_start_to_end: ListBuffer[String], jp_time_arr: Array[String], fun: (String, String) => Long): (ArrayBuffer[Int], ArrayBuffer[Int]) = {
    val ds_times = ds_start_to_end.flatMap(_.split("_")).map(fun("yyyy-MM-dd HH:mm:ss", _)).sortWith(_.compareTo(_) < 0)
    val start_index_arr, end_index_arr = new ArrayBuffer[Int]()

    if (ds_start_to_end.length > 0 && jp_time_arr.length > 0) {
      for (i <- 0 until ds_times.length) {
        if (i % 2 == 0) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                start_index_arr += 0
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                start_index_arr += jp_time_arr.length - 1
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  start_index_arr += j
                } else {
                  start_index_arr += j + 1
                }
                break
              }
            }
          }
        }
        if (i % 2 == 1) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                end_index_arr += 0
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                end_index_arr += jp_time_arr.length - 1
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  end_index_arr += j
                } else {
                  end_index_arr += j + 1
                }
                break
              }
            }
          }
        }
      }
    }
    (start_index_arr, end_index_arr)
  }

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * 2021-01-01 11:11:11("yyyy-MM-dd HH:mm:ss")
   *
   * @return 1609470671
   */
  def timeToTimestampFormat(format: String, colValue: String): Long = {
    var ts = 0l
    try {
      val fdf = FastDateFormat.getInstance(format)
      val dt = fdf.parse(colValue)
      //时间戳毫秒转秒
      ts = dt.getTime / 1000
    } catch {
      case e: Exception => ""
    }
    ts
  }

  /**
   * 将指定格式的 时间戳 转 日期，单位为：秒
   * eg:1609470671
   * res:2021-01-01 11:11:11 or 2021/01/01 11:11:11
   */

  def tranTstampToTime(sdf: FastDateFormat, colValue: String): String = {
    var time = ""
    try {
      time = sdf.format(new Date(colValue.toLong * 1000))
    } catch {
      case e: Exception => ""
    }
    time
  }

  def strNotNull(str: String): Boolean = {
    StringUtils.nonEmpty(str) && str.trim != ""
  }


  def getXuhaoAndYongdu(status_gd: String, swid_gd: String): (String, String, String) = {
    val index_arr, yongdu_swid_arr, yongdu_status_arr = new ListBuffer[String]()
    val conStatus = Seq("2", "3", "4")
    if (strNotNull(status_gd)) {
      val status_gd_arr = status_gd.split("\\|")
      val swid_gd_arr = swid_gd.split("\\|")
      var cnt = 0
      for (i <- 0 until status_gd_arr.size if i == cnt) {
        var yongdu_status_hs: mutable.HashSet[String] = null
        if (conStatus.contains(status_gd_arr(i))) {
          yongdu_status_hs = new mutable.HashSet[String]()
          yongdu_status_hs.add(status_gd_arr(i))
          val start_index = i
          breakable {
            for (j <- i + 1 until status_gd_arr.size if i + 1 <= status_gd_arr.size - 1) {
              if (!conStatus.contains(status_gd_arr(j))) {
                val end_index = j - 1
                index_arr += start_index + "_" + end_index
                yongdu_swid_arr += swid_gd_arr(start_index) + "_" + swid_gd_arr(end_index)
                cnt = j
                break()
              } else if (j == status_gd_arr.size - 1 && conStatus.contains(status_gd_arr(j))) {
                val end_index = j
                index_arr += start_index + "_" + end_index
                yongdu_status_hs.add(status_gd_arr(j))
                yongdu_swid_arr += swid_gd_arr(start_index) + "_" + swid_gd_arr(end_index)
              } else {
                yongdu_status_hs.add(status_gd_arr(j))
              }
            }
          }
          if (yongdu_status_hs != null) yongdu_status_arr += yongdu_status_hs.mkString(",")
        } else {
          cnt += 1
        }
      }
    }
    (index_arr.mkString(";"), yongdu_swid_arr.mkString(";"), yongdu_status_arr.mkString(";"))
  }


}
