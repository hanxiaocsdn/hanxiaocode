package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{SaveMode, SparkSession}
import utils.SparkBuilder

/**
 * @task_id:
 * @description: 增加起终城市流向名称---根据城市流向分区
 * @demander:
 * @author 01418539 caojia
 * @date 2023/3/27 14:12
 */
object EfficientSwidAcclerationSaveTocsv extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val start_num = args(1)
    val end_num = args(2)
//    saveTocsv(spark, inc_day, start_num, end_num)
    saveTocsv0419(spark, inc_day, start_num, end_num)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }


  def saveTocsv0419(spark: SparkSession, inc_day: String, start_num: String, end_num: String): Unit = {
    val start = start_num.toInt
    val end = end_num.toInt
    val sql =
      s"""select un,swid_gj,adcode_gj,time_gj,adcode_first_gj,adcode_end_gj,time_first_gj,time_end_gj,swid_qm,roadclass_qm,dr_length_qm,swid_name_qm,time_taken_gj,dist_gj,avg_speed_gj,swid_highspeed_start,swid_highspeed_end,name_highspeed_start,name_highspeed_end,dis_highspeed,dis_ac_highspeed,highspeed_ration,highspeed_all_ration,time_highspeed_start, time_highspeed_end,duration_highspeed,avg_speed_highspeed,dis_highspeed_block,swid_tl,time_tl, duration_tl,roadclass_tl,roadname_tl,total_duration_tl_1,total_duration_tl_2,avg_speed_highspeed_tl_1,avg_speed_highspeed_tl_2,duration_ratio_1,duration_ratio_2,city_start,city_end,date_start_gj,hour_start_gj,date_start_highspeed,hour_start_highspeed,time_highspeed_start_rep, concat(city_start,'-',city_end) as direction
         |from dm_gis.eta_experience_speed_track_fix_to320_road_detail_60
         |where inc_day='20221201' and cast(num as int) between 1 and 1000
         |and time_highspeed_start_rep between '2022-11-01' and '2022-11-07'
         |and cast(highspeed_ration as double)>=0.8
         |and cast(avg_speed_highspeed_tl_2 as double)>=30 and cast(avg_speed_highspeed_tl_2 as double)<=120
         |and cast(dis_highspeed as double)>=100
         |and  concat(city_start,'-',city_end) in ('广州市-重庆市','东莞市-上海市','沈阳市-杭州市','佛山市-武汉市','苏州市-北京市','上海市-成都市','天津市-重庆市','郑州市-中山市','深圳市-长春市','广州市-西安市','宁波市-重庆市','北京市-武汉市','广州市-济南市','广州市-成都市','厦门市-重庆市','温州市-重庆市','深圳市-乌鲁木齐市','广州市-兰州市','厦门市-西安市','佛山市-沈阳市')""".stripMargin
    logger.error("输入的sql:" + sql)
    val o_eta = spark.sql(sql)//.repartition(1200)
      .sort(col("time_highspeed_start_rep"),col("direction"))
      .persist()

    logger.error(">>>>>>>>>>>>>>" + o_eta.count())
    //csv的属性信息
    val path = "/user/01418539/upload/file/eta"
    val options = Map(
      "header" -> "true",
      "delimiter" -> "\\t",
      "compression" -> "gzip",
      "inferSchema" -> true.toString
    )
    writeToCsv(spark, o_eta.coalesce(10), SaveMode.Overwrite, inc_day, options, path, false)
  }

  def saveTocsv(spark: SparkSession, inc_day: String, start_num: String, end_num: String): Unit = {
    val start = start_num.toInt
    val end = end_num.toInt
    val sql =
      s"""select un,adcode_first_gj,adcode_end_gj,time_first_gj,time_end_gj,time_taken_gj,dist_gj,avg_speed_gj,swid_highspeed_start,swid_highspeed_end,name_highspeed_start,name_highspeed_end,dis_highspeed,dis_ac_highspeed,highspeed_ration,highspeed_all_ration,time_highspeed_start, time_highspeed_end,duration_highspeed,avg_speed_highspeed,dis_highspeed_block,swid_tl,time_tl, duration_tl,roadclass_tl,roadname_tl,total_duration_tl_1,total_duration_tl_2,avg_speed_highspeed_tl_1,avg_speed_highspeed_tl_2,duration_ratio_1,duration_ratio_2,city_start,city_end,date_start_gj,date_end_gj,hour_start_gj,hour_end_gj,date_start_highspeed,date_end_highspeed,
         |hour_start_highspeed,hour_end_highspeed,time_highspeed_start_rep,concat_ws('-',city_start,city_end) direction
         |from dm_gis.eta_experience_speed_track_fix_to320_road_detail_60
         |where inc_day='$inc_day' and cast(num as int) between $start and $end
         |and cast(highspeed_ration as double)>=0.8 and cast(avg_speed_highspeed_tl_2 as double)>=30
         |and time_highspeed_start_rep between '2022-11-01' and '2022-11-15'""".stripMargin
    logger.error("输入的sql:" + sql)
    val o_eta = spark.sql(sql)//.repartition(1200)
      .sort(col("time_highspeed_start_rep"),col("direction"))
      .persist()

    logger.error(">>>>>>>>>>>>>>" + o_eta.count())
    //csv的属性信息
    val path = "/user/01418539/upload/file/eta"
    val options = Map(
      "header" -> "true",
      "delimiter" -> "\\t",
      "compression" -> "gzip",
      "inferSchema" -> true.toString
    )
    writeToCsv(spark, o_eta.coalesce(40), SaveMode.Overwrite, inc_day, options, path, false)
  }
}
