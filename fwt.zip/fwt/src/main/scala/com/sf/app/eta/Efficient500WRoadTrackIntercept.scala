package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.ColumnUtil.splitFun
import utils.EtaUtil.base32ToDecimal
import utils.SparkBuilder

import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 临时exe
 * @description: 500w数据 压缩下载ftp--bdp hive
 * @demander:舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/4/11 14:35
 */
object Efficient500WRoadTrackIntercept extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    //    val start_day = args(0)
    //    val end_day = args(1)
    val file_str = args(0)
    //    val toTN = "dm_gis.eta_500w_track_daily_t3"
    val toTN = "dm_gis.eta_track_daily"
    val file_arr = file_str.split(",")
    for (file <- file_arr) {
      //      mapDailyToHiveT3(spark, file, toTN)
      mapDailyToHiveOffline(spark, file, toTN) //320 2min
    }
    //getDataFromBDP(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")

  }

  def getDataFromBDP(spark: SparkSession, start_day: String, end_day: String): Unit = {
    val res_cols = spark.sql("""select * from dm_gis.eta_500w_track_daily limit 0""").schema.map(_.name).map(col)
    val res_df = spark.sql(s"""SELECT un,road_rank `rank`,road_id_start road_start_swid,road_id_end road_end_swid,if_highspeed,road_start_time,road_end_time,road_dist,road_start_adcode,road_end_adcode,tl_periods,tl_roadname tl_road,tl_link,tl_roadclass,inc_day FROM dm_gis.insurance_model_duration_dist_daily_qgzh where inc_day between '$start_day' and '$end_day'""".stripMargin)
      .select(res_cols: _*)
    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.eta_500w_track_daily")
  }

  def mapDailyToHive(spark: SparkSession, fileN: String): Unit = {
    val res_cols = spark.sql("""select * from dm_gis.eta_500w_track_daily limit 0""").schema.map(_.name).map(col)
    val inputPath = "/user/01418539/upload/file/eta/" + fileN
    val res_cols_str = Seq("un", "total_dist", "total_duration", "drive_dist", "night_dirve_dist", "before_dawn_drive_dist", "early_morning_drive_dist", "afternoon_drive_dist", "dusk_drive_dist", "high_speed_dist", "state_road_dist", "provincial_dist", "county_dist", "township_dist", "dangerous_road_dist", "high_accident_road_dist", "school_road_dist", "sharp_turn_road_dist", "village_road_dist", "drive_duration", "drive_duration_array", "night_dirve_duration", "before_dawn_drive_duration", "early_morning_drive_duration", "afternoon_drive_duration", "dusk_drive_duration", "dangerous_road_duration", "high_accident_road_duration", "school_road_duration", "sharp_turn_road_duration", "township_road_duration", "over_speed_duration", "over_speed_ser_duration", "lnk_cnt", "dangerous_road_cnt", "high_accident_road_cnt", "school_road_cnt", "sharp_turn_road_cnt", "township_road_road_cnt", "operation_cnt", "operation_same_city_cnt", "adcode_map", "adcode_duration_map", "adcode_dist_map", "over_drive_duration", "night_high_speed_duration", "night_state_road_duration", "night_provincial_duration", "night_county_duration", "night_township_duration", "night_high_speed_dist", "night_state_road_dist", "night_provincial_dist", "night_county_dist", "night_township_dist", "night_dangerous_road_cnt", "night_high_accident_road_cnt", "night_school_road_cnt", "night_sharp_turn_road_cnt", "night_township_road_cnt", "night_lnk_cnt", "before_dawn_high_speed_duration", "before_dawn_state_road_duration", "before_dawn_provincial_duration", "before_dawn_county_duration", "before_dawn_township_duration", "before_dawn_high_speed_dist", "before_dawn_road_dist", "before_dawn_provincial_dist", "before_dawn_county_dist", "before_dawn_township_dist", "before_dawn_dangerous_road_cnt", "before_dawn_high_accident_road_cnt", "before_dawn_school_road_cnt", "before_dawn_sharp_turn_road_cnt", "before_dawn_township_road_cnt", "before_dawn_lnk_cnt", "early_morning_high_speed_duration", "early_morning_state_road_duration", "early_morning_provincial_duration", "early_morning_county_duration", "early_morning_township_duration", "early_morning_high_speed_dist", "early_morning_road_dist", "early_morning_provincial_dist", "early_morning_county_dist", "early_morning_township_dist", "early_morning_dangerous_road_cnt", "early_morning_high_accident_road_cnt", "early_morning_school_road_cnt", "early_morning_sharp_turn_road_cnt", "early_morning_township_road_cnt", "early_morning_lnk_cnt", "afternoon_high_speed_duration", "afternoon_state_road_duration", "afternoon_provincial_duration", "afternoon_county_duration", "afternoon_township_duration", "afternoon_high_speed_dist", "afternoon_road_dist", "afternoon_provincial_dist", "afternoon_county_dist", "afternoon_township_dist", "afternoon_dangerous_road_cnt", "afternoon_high_accident_road_cnt", "afternoon_school_road_cnt", "afternoon_sharp_turn_road_cnt", "afternoon_township_road_cnt", "afternoon_lnk_type_cnt", "dusk_high_speed_duration", "dusk_state_road_duration", "dusk_provincial_duration", "dusk_county_duration", "dusk_township_duration", "dusk_high_speed_dist", "dusk_road_dist", "dusk_provincial_dist", "dusk_county_dist", "dusk_township_dist", "dusk_dangerous_road_cnt", "dusk_high_accident_road_cnt", "dusk_school_road_cnt", "dusk_sharp_turn_road_cnt", "dusk_township_road_cnt", "dusk_lnk_type_cnt", "total_links_dist", "total_links_duration", "operation_same_prov_cnt", "sc_table", "lpn", "high_speed_duration", "state_road_duration", "provincial_duration", "county_duration", "township_duration", "high_speed_lowspeed_duration", "inc_day", "ak", "road_rank", "road_id_start", "road_id_end", "if_highspeed", "road_start_time", "road_end_time", "road_start_adcode", "road_end_adcode", "road_dist", "tl_periods", "tl_roadname", "tl_link", "tl_roadclass", "track_point_count", "track_interval", "track_repeat_count", "track_continuos_rate", "track_drift_count", "blank")
    val o_daily_df = spark.read
      .option("header", "false")
      .option("delimiter", "\\t")
      .option("encoding", "utf-8")
      .option("inferSchema", true.toString)
      .csv(inputPath)
      .toDF(res_cols_str: _*)

    val res_df = o_daily_df.selectExpr("un", "road_rank as rank", "road_id_start as road_start_swid", "road_id_end as road_end_swid", "if_highspeed", "road_start_time", "road_end_time", "road_dist", "road_start_adcode", "road_end_adcode", "tl_periods", "tl_roadname as tl_road", "tl_link", "tl_roadclass", "inc_day")
      .select(res_cols: _*)
    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.eta_500w_track_daily")

  }

  def mapDailyToHiveT3(spark: SparkSession, fileN: String, toTN: String): Unit = {
    val res_cols = spark.sql(s"""select * from $toTN limit 0""").schema.map(_.name).map(col)
    val inputPath = "/user/01418539/upload/file/eta/" + fileN
    val o_daily_df = spark.read
      .option("header", "true")
      .option("delimiter", "\\t")
      .option("encoding", "utf-8")
      .option("inferSchema", true.toString)
      .csv(inputPath)
      .toDF()

    val res_df = o_daily_df.selectExpr("un", "road_rank as rank", "road_id_start as road_start_swid", "road_id_end as road_end_swid", "if_highspeed", "road_start_time", "road_end_time", "road_dist", "road_start_adcode", "road_end_adcode", "tl_periods", "tl_roadname as tl_road", "tl_link", "tl_roadclass", "roadname as road_name", "tl_points", "inc_day")
      .withColumn("inc_day", substring(regexp_replace(col("inc_day"), "([^0-9]+)", ""), 0, 8))
      .select(res_cols: _*)
    writeToHive(spark, res_df, Seq("inc_day"), toTN)

  }

  /**
   * 北京线下320w数据 20230301--20230331
   *
   * @param spark
   * @param fileN
   * @param toTN
   */
  def mapDailyToHiveOffline(spark: SparkSession, fileN: String, toTN: String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql(s"""select * from $toTN limit 0""").schema.map(_.name).map(col)
    val road_id_infos_str = splitFun("&")('road_id_infos)
    val inputPath = "/user/01418539/upload/file/eta/" + fileN
    val o_daily_df = spark.read
      .option("header", false)
      .option("delimiter", "\\t")
      .option("encoding", "utf-8")
      .option("inferSchema", true.toString)
      .csv(inputPath)
      .toDF("un", "inc_day", "rank", "if_highspeed", "road_id", "road_start_time", "road_end_time", "road_start_adcode", "road_end_adcode", "road_dist", "tl_periods", "tl_link_org", "tl_roadclass", "road_name", "tl_road", "tl_points", "blank")
      .na.fill("", Seq("road_id", "tl_link"))
      .withColumn("road_id_infos", getroadSwidUdf(col("road_id")))
      .withColumn("road_start_swid", road_id_infos_str(0))
      .withColumn("road_end_swid", road_id_infos_str(1))
      .withColumn("road_id", road_id_infos_str(2))
      .withColumn("tl_link", gettlLinkUdf('tl_link_org))
      .withColumn("inc_day", substring(regexp_replace(col("inc_day"), "([^0-9]+)", ""), 0, 8))
      .select(res_cols: _*)
    writeToHive(spark, o_daily_df.coalesce(5), Seq("inc_day"), toTN)

  }


  def gettlLinkUdf = udf((tl_link: String) => {
    val start_ab = new ArrayBuffer[String]()
    try {
      if (tl_link.trim != "") {
        val tl_link_arr = tl_link.split("\\|")
        for (i <- 0 until tl_link_arr.length) {
          start_ab += base32ToDecimal(tl_link_arr(i)).toString
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    start_ab.mkString("|")
  })


  def getroadSwidUdf = udf((road_id: String) => {
    val start_ab = new ArrayBuffer[String]()
    val end_ab = new ArrayBuffer[String]()
    val road_id_ab = new ArrayBuffer[String]()

    if (road_id.trim != "") {
      val road_id_arr = road_id.split("\\|")
      for (i <- 0 until road_id_arr.length) {
        val in_ab = new ArrayBuffer[String]()
        try {
          val s1 = road_id_arr(i).split("_")
          start_ab += base32ToDecimal(s1(0)).toString
          end_ab += base32ToDecimal(s1(s1.length - 1)).toString
          for (j <- 0 until s1.length) {
            in_ab += base32ToDecimal(s1(j)).toString
          }
        } catch {
          case e: Exception => "" + e
        }
        road_id_ab += in_ab.mkString("_")
      }
    }
    start_ab.mkString("|") + "&" + end_ab.mkString("|") + "&" + road_id_ab.mkString("|")
  })


}
