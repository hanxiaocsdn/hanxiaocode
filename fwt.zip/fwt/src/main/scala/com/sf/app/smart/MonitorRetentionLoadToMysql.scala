package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.getDevEGOVMysqlConnect
import utils.SparkBuilder
import java.sql.{Connection, PreparedStatement}
import scala.collection.JavaConversions.asScalaIterator

/**
 * @description: 天周月的留存率推入mysql
 * @author 01418539 caojia
 * @date 2022/5/10 16:49
 */
object MonitorRetentionLoadToMysql extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processRetentionToMysql(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processRetentionToMysql(spark: SparkSession, start_day: String, end_day: String): Unit = {
    //加载数据
    val o_days = spark.sql(s"""select * from dm_gis.scomm_user_day_retained where inc_day >='$start_day' and inc_day <='$end_day'""")
    val o_weeks = spark.sql(s"""select * from dm_gis.scomm_user_week_retained where inc_day >='$start_day' and inc_day <='$end_day'""")
    val o_months = spark.sql(s"""select * from dm_gis.scomm_user_month_retained where inc_day >='$start_day' and inc_day <='$end_day'""")

    val tables = Array("SCOMM_USER_DAY_RETAINED", "SCOMM_USER_WEEK_RETAINED", "SCOMM_USER_MONTH_RETAINED")

    //数据重跑推入
    for (tableName <- tables) {
      val conn: Connection = getDevEGOVMysqlConnect()
      try {
        val querySql = s"select * from gis_oms_lip_egov.$tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val query: PreparedStatement = conn.prepareStatement(querySql)
        val queryRes = query.executeQuery()
        if (queryRes.next()) {
          val delSql = s"delete from gis_oms_lip_egov.$tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
          val del: PreparedStatement = conn.prepareStatement(delSql)
          del.execute()
        }
      } catch {
        case ex: Exception => logger.error(s"删除表 gis_oms_lip_egov.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
          throw ex
      }

      if ("SCOMM_USER_DAY_RETAINED".equals(tableName)) {
        o_days.toLocalIterator.foreach(row => {
          try {
            val insertSql = s"insert into gis_oms_lip_egov.$tableName values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" //45
            val insert: PreparedStatement = conn.prepareStatement(insertSql)
            insert.setNull(1, 1)
            insert.setString(2, row.getAs[String]("inc_day"))
            insert.setString(3, row.getAs[String]("province"))
            insert.setString(4, row.getAs[String]("city"))
            insert.setString(5, row.getAs[String]("region"))
            insert.setString(6, row.getAs[String]("street"))
            insert.setString(7, row.getAs[String]("community"))
            insert.setString(8, row.getAs[String]("aoi_name"))
            insert.setString(9, row.getAs[String]("effective_users"))
            insert.setString(10, row.getAs[String]("first_day_effective_users"))
            insert.setString(11, row.getAs[String]("first_day_effective_users_ratio"))
            insert.setString(12, row.getAs[String]("after_first_day_effective_users"))
            insert.setString(13, row.getAs[String]("three_day_effective_users"))
            insert.setString(14, row.getAs[String]("three_day_effective_users_ratio"))
            insert.setString(15, row.getAs[String]("after_three_day_effective_users"))
            insert.setString(16, row.getAs[String]("six_day_effective_users"))
            insert.setString(17, row.getAs[String]("six_day_effective_users_ratio"))
            insert.setString(18, row.getAs[String]("after_six_day_effective_users"))
            insert.setString(19, row.getAs[String]("nine_day_effective_users"))
            insert.setString(20, row.getAs[String]("nine_day_effective_users_ratio"))
            insert.setString(21, row.getAs[String]("after_nine_day_effective_users"))
            insert.setString(22, row.getAs[String]("twelve_day_effective_users"))
            insert.setString(23, row.getAs[String]("twelve_day_effective_users_ratio"))
            insert.setString(24, row.getAs[String]("after_twelve_day_effective_users"))
            insert.setString(25, row.getAs[String]("fifteen_day_effective_users"))
            insert.setString(26, row.getAs[String]("fifteen_day_effective_users_ratio"))
            insert.setString(27, row.getAs[String]("after_fifteen_day_effective_users"))
            insert.setString(28, row.getAs[String]("eighteen_day_effective_users"))
            insert.setString(29, row.getAs[String]("eighteen_day_effective_users_ratio"))
            insert.setString(30, row.getAs[String]("after_eighteen_day_effective_users"))
            insert.setString(31, row.getAs[String]("twenty_one_day_effective_users"))
            insert.setString(32, row.getAs[String]("twenty_one_day_effective_users_ratio"))
            insert.setString(33, row.getAs[String]("after_twenty_one_day_effective_users"))
            insert.setString(34, row.getAs[String]("twenty_four_day_effective_users"))
            insert.setString(35, row.getAs[String]("twenty_four_day_effective_users_ratio"))
            insert.setString(36, row.getAs[String]("after_twenty_four_day_effective_users"))
            insert.setString(37, row.getAs[String]("twenty_seven_day_effective_users"))
            insert.setString(38, row.getAs[String]("twenty_seven_day_effective_users_ratio"))
            insert.setString(39, row.getAs[String]("after_twenty_seven_day_effective_users"))
            insert.setString(40, row.getAs[String]("thirty_day_effective_users"))
            insert.setString(41, row.getAs[String]("thirty_day_effective_users_ratio"))
            insert.setTimestamp(42, new java.sql.Timestamp(new java.util.Date().getTime()))
            insert.setNull(43, 0)
            insert.setTimestamp(44, new java.sql.Timestamp(new java.util.Date().getTime()))
            insert.setNull(45, 0)
            insert.execute()
          } catch {
            case ex: Exception => logger.error(s"往表 gis_oms_lip_egov.$tableName  中插入$start_day 至 $end_day 数据时出现错误", ex)
              throw ex
          }
        })
      } else if ("SCOMM_USER_WEEK_RETAINED".equals(tableName)) {
        o_weeks.toLocalIterator.foreach(row => {
          try {
            val insertSql = s"insert into gis_oms_lip_egov.$tableName values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" //36
            val insert: PreparedStatement = conn.prepareStatement(insertSql)
            insert.setNull(1, 1)
            val cols = Array("inc_day", "province", "city", "region", "street", "community", "aoi_name",
              "effective_users", "first_week_effective_users", "first_week_effective_users_ratio",
              "after_first_week_effective_users", "second_week_effective_users", "second_week_effective_users_ratio",
              "after_second_week_effective_users", "third_week_effective_users", "third_week_effective_users_ratio",
              "after_third_week_effective_users", "fourth_week_effective_users", "fourth_week_effective_users_ratio",
              "after_fourth_week_effective_users", "fifth_week_effective_users", "fifth_week_effective_users_ratio",
              "after_fifth_week_effective_users", "sixth_week_effective_users", "sixth_week_effective_users_ratio",
              "after_sixth_week_effective_users", "seventh_week_effective_users", "seventh_week_effective_users_ratio",
              "after_seventh_week_effective_users", "eighth_week_effective_users", "eighth_week_effective_users_ratio")
            for (i <- 0 until cols.length) {
              insert.setString(i + 2, row.getAs[String](cols(i)))
            }
            insert.setTimestamp(33, new java.sql.Timestamp(new java.util.Date().getTime()))
            insert.setNull(34, 0)
            insert.setTimestamp(35, new java.sql.Timestamp(new java.util.Date().getTime()))
            insert.setNull(36, 0)
            insert.execute()
          } catch {
            case ex: Exception => logger.error(s"往表 gis_oms_lip_egov.$tableName  中插入$start_day 至 $end_day 数据时出现错误", ex)
              throw ex
          }
        })
      } else {
        o_months.toLocalIterator.foreach(row => {
          try {
            val insertSql = s"insert into gis_oms_lip_egov.$tableName values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" //48
            val insert: PreparedStatement = conn.prepareStatement(insertSql)
            insert.setNull(1, 1)
            val cols = Array("inc_day", "province", "city", "region", "street", "community", "aoi_name",
              "effective_users", "first_month_effective_users", "first_month_effective_users_ratio",
              "after_first_month_effective_users", "second_month_effective_users", "second_month_effective_users_ratio",
              "after_second_month_effective_users", "third_month_effective_users", "third_month_effective_users_ratio",
              "after_third_month_effective_users", "fourth_month_effective_users", "fourth_month_effective_users_ratio",
              "after_fourth_month_effective_users", "fifth_month_effective_users", "fifth_month_effective_users_ratio",
              "after_fifth_month_effective_users", "sixth_month_effective_users", "sixth_month_effective_users_ratio",
              "after_sixth_month_effective_users", "seventh_month_effective_users", "seventh_month_effective_users_ratio",
              "after_seventh_month_effective_users", "eighth_month_effective_users", "eighth_month_effective_users_ratio",
              "after_eighth_month_effective_users", "ninth_month_effective_users", "ninth_month_effective_users_ratio",
              "after_ninth_month_effective_users", "tenth_month_effective_users", "tenth_month_effective_users_ratio",
              "after_tenth_month_effective_users", "eleventh_month_effective_users", "eleventh_month_effective_users_ratio",
              "after_eleventh_month_effective_users", "twelfth_month_effective_users", "twelfth_month_effective_users_ratio")
            for (i <- 0 until cols.length) {
              insert.setString(i + 2, row.getAs[String](cols(i)))
            }
            insert.setTimestamp(45, new java.sql.Timestamp(new java.util.Date().getTime()))
            insert.setNull(46, 0)
            insert.setTimestamp(47, new java.sql.Timestamp(new java.util.Date().getTime()))
            insert.setNull(48, 0)
            insert.execute()
          } catch {
            case ex: Exception => logger.error(s"往表 gis_oms_lip_egov.$tableName  中插入$start_day 至 $end_day 数据时出现错误", ex)
              throw ex
          }
        })
      }
      //统计写入mysql中的数据总量
      try {
        val querySql = s"select count(1) as cnt from gis_oms_lip_egov.$tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val query: PreparedStatement = conn.prepareStatement(querySql)
        val queryRes = query.executeQuery()
        if (queryRes.next()) {
          logger.error(s"表gis_oms_lip_egov.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
        }
      } catch {
        case ex: Exception => logger.error(s"统计 gis_oms_lip_egov.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
          throw ex
      }
    }
  }
}
