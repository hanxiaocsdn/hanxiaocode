package com.sf.app.scm

import com.sf.common.ColumnCommon.notNullDef
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter, getdaysBeforeOrAfter}
import utils.SparkBuilder

/**
 * @task_id: 668105
 * @description:实时薪酬申诉情况监控_数据侧_v1.0 gis_eta_ts_appeal_confirmed
 * @demander:01423372 马晶玲
 * @author 01418539 caojia
 * @date 2023/2/22 15:34
 */
object RealtimeSalaryAppealConfirmed extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val run_flag = args(1)
    var task_df: DataFrame = null
    if (run_flag == "Y") task_df = processAppealConform(spark, inc_day)
    if (run_flag == "N") task_df = spark.sql(s"select * from dm_gis.gis_eta_ts_appeal_confirmed where inc_day ='$inc_day'").persist(StorageLevel.MEMORY_AND_DISK_SER)
    aggTaskProc(spark, task_df, inc_day)

    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processAppealConform(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._

    val days_35_ago = getdaysBeforeOrAfter(inc_day, -35) //36天
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_ts_appeal_confirmed limit 0""").schema.map(_.name).map(col)
    val o_accural_parse1 = spark.sql(
      s"""select task_area_code,carrier_name,task_id,if(length(task_id) <= 20,'0','1') task_type,accrual_dist,source_type,task_inc_day,row_number() over(partition by task_id order by inc_day desc) cnt
         |from dm_gis.gis_eta_ts_accural_parse1
         |where inc_day between '$days_35_ago' and '$inc_day' and task_id is not null and trim(task_id)!=''""".stripMargin)
      .filter('cnt === 1).drop("cnt")

    val o_dist_appeal = spark.sql(s"""select task_id,`state`,audit_result,new_accrual_dist from dm_gis.accrual_dist_appeal where inc_day='$inc_day' and task_id is not null and trim(task_id)!=''""".stripMargin)
      .withColumn("new_accrual_dist", when('new_accrual_dist.isNotNull && trim('new_accrual_dist) =!= "", 'new_accrual_dist).otherwise("0.0"))
      .withColumn("num", row_number().over(Window.partitionBy("task_id").orderBy(col("new_accrual_dist").cast("double").desc)))
      .filter('num === 1).drop("num")

    val o_line_nostop = spark.sql(s"""select task_id,max(confirmed) confirmed,max(confirm_login_name) confirm_login_name from dm_gis.eta_std_line_nostop where inc_day='$inc_day' and task_id is not null and trim(task_id)!='' group by task_id""".stripMargin)

    val res = o_accural_parse1
      .join(broadcast(o_dist_appeal), Seq("task_id"), "left")
      .join(broadcast(o_line_nostop), Seq("task_id"), "left")
      .na.fill("0.0", Seq("accrual_dist", "new_accrual_dist"))
      .na.fill("", Seq("task_area_code", "carrier_name", "accrual_dist", "source_type", "task_type", "task_inc_day", "state", "audit_result", "new_accrual_dist", "confirmed", "confirm_login_name"))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)

    writeToHive(spark, res.coalesce(2), Seq("inc_day"), "dm_gis.gis_eta_ts_appeal_confirmed")
    res
  }

  def aggTaskProc(spark: SparkSession, task_df: DataFrame, inc_day: String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_ts_appeal_confirmed_result limit 0""").schema.map(_.name).map(col)
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val yes_day = getdaysBeforeOrAfter(inc_day, -1) //昨天
    val yes_day_df = spark.sql(s"""select * from dm_gis.gis_eta_ts_appeal_confirmed_result where inc_day ='$yes_day'""").persist(StorageLevel.MEMORY_AND_DISK_SER)
    var res_df: DataFrame = null
    logger.error("当天日期：" + inc_day + "上个自然月的数据是否固化：" + (inc_day.substring(6, 8).toInt >= 6).toString)

    if (inc_day.substring(6, 8).toInt >= 6) {
      val filter_cond = 'task_inc_day >= inc_day.substring(0, 6) + "01"

      val add_task_df = task_df.join(yes_day_df, Seq("task_area_code", "task_inc_day", "task_type"), "left_anti")
      val same_task_df = task_df.join(yes_day_df.select("task_area_code", "task_inc_day", "task_type"), Seq("task_area_code", "task_inc_day", "task_type"))
        .filter(filter_cond)

      res_df = updateSolidification(spark, add_task_df.union(same_task_df), res_cols, inc_day).union(yes_day_df)
        .withColumn("num", row_number().over(Window.partitionBy("task_area_code", "task_inc_day", "task_type").orderBy(desc("last_update_time"))))
        .filter('num === 1)
        .withColumn("inc_day", lit(inc_day))
        .select(res_cols: _*)
    }
    if (inc_day.substring(6, 8).toInt < 6) {
      res_df = updateSolidification(spark, task_df.filter('task_inc_day >= month_first_day && 'task_inc_day <= month_last_day), res_cols, inc_day).union(yes_day_df)
        .withColumn("num", row_number().over(Window.partitionBy("task_area_code", "task_inc_day", "task_type").orderBy(desc("last_update_time"))))
        .filter('num === 1)
        .withColumn("inc_day", lit(inc_day))
        .select(res_cols: _*)
    }

    writeToHive(spark, res_df.coalesce(3), Seq("inc_day"), "dm_gis.gis_eta_ts_appeal_confirmed_result")
    yes_day_df.unpersist()
  }

  def updateSolidification(spark: SparkSession, task_df: DataFrame, res_cols: Seq[Column], inc_day: String): DataFrame = {
    import spark.implicits._

    task_df
      .withColumn("task_sum", lit(1))
      .withColumn("appeal_num", when(notNullDef('state), 1).otherwise(0))
      .withColumn("appass_num", when('audit_result === "1", 1).otherwise(0))
      .withColumn("check_num", when('confirmed === "1", 1).otherwise(0))
      .withColumn("selfcheck_num", when('confirm_login_name =!= "gis system" && 'confirmed === "1", 1).otherwise(0))
      .groupBy("task_area_code", "task_inc_day", "task_type", "inc_day")
      .agg(
        sum("task_sum") as "task_sum",
        sum("appeal_num") as "appeal_num",
        sum("appass_num") as "appass_num",
        sum("check_num") as "check_num",
        sum("selfcheck_num") as "selfcheck_num"
      ).withColumn("last_update_time", lit(inc_day))
      .select(res_cols: _*)
  }
}
