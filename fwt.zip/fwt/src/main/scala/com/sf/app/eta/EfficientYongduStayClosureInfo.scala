package com.sf.app.eta

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.DateUtil.{getdaysBeforeOrAfter, timeToTimestampFormat}
import utils.EtaUtil.getJsonValue
import utils.SparkBuilder
import utils.ColumnUtil.{colTrimNotNull, splitFun, strNotNull}

import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 779429
 * @description: 时效定责子任务统计需求  实时任务取代历史离线任务 40w条/天 3min
 * @demander: 01408890 邵一馨
 * @author 01418539 caojia
 * @date 2023/7/26 14:56
 */
case class RecallRealTime(task_id: String, task_area_code: String, line_code: String, task_subid: String, start_dept: String, end_dept: String, start_outer_add_code: String, end_outer_add_code: String, start_dept_coordinate: String, end_dept_coordinate: String, vehicle_type: String, plan_depart_tm: String, plan_arrive_tm: String, actual_depart_tm: String, actual_arrive_tm: String, line_time: String, line_distance: String, rt_dist: String, actual_run_time: String, vehicle_serial: String, driver_id: String, driver_name: String, carrier_type: String, carrier_name: String, line_require_id: String, transoport_level: String, biz_type: String, require_category: String, to_ground: String, if_evaluate_time: String, difftime_plan_actual: String, ac_is_run_ontime: String, conduct_type: String, normal_stay_time: String, other_keguan_total: String, service_tm: Double, other_tm: Double, closure_time: String)

object EfficientYongduStayClosureInfo extends DataSourceCommon {
  val start_rt_tb = "dm_gis.eta_std_line_recall_realtime2"
  val start_gj_tb = "dm_gis.vms_gta_ground_trackwarning_info"
  val end_tb = "dm_gis.eta_std_line_recall_realtime_sub"

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    run(spark, start_rt_tb, start_gj_tb, end_tb, inc_day)
    //    procRecallDFTest(spark, start_rt_tb, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, start_rt_tb: String, start_gj_tb: String, end_tb: String, inc_day: String): Unit = {
    import spark.implicits._
    val org_realtime_df = procRecallDF(spark, start_rt_tb, inc_day)
    val org_warning_df = procWarningDF(spark, start_gj_tb, inc_day)

    val res_cols = spark.sql(s"""select * from $end_tb limit 0""").schema.map(_.name).map(col)

    val res_df = org_realtime_df.join(org_warning_df, Seq("task_subid"), "left")
      .withColumn("sevice_tm_vms", when('sevice_tm_vms.isNotNull && trim('sevice_tm_vms) =!= "", 'sevice_tm_vms.cast("double")).otherwise(0.0))
      .withColumn("zhuguan_vms", when('zhuguan_vms.isNotNull && trim('zhuguan_vms) =!= "", 'zhuguan_vms.cast("double")).otherwise(0.0))
      .withColumn("service_total_stay_time", 'sevice_tm_vms + 'service_tm)
      .withColumn("other_abnormal_stay_time", 'zhuguan_vms + 'other_tm)
      .na.fill("0.0", Seq("service_total_stay_time", "normal_stay_time"))
      .withColumn("abnormal_stay_time", getAbnormalStayTime('service_total_stay_time, 'normal_stay_time))
      .withColumn("abnormal_stay_time", when('abnormal_stay_time.isNotNull && trim('abnormal_stay_time) =!= "", 'abnormal_stay_time.cast("double")).otherwise(0))
      .withColumn("other_ob_stay_time", when('other_ob_stay_time.isNotNull && trim('other_ob_stay_time) =!= "", 'other_ob_stay_time.cast("double")).otherwise(0))
      .withColumn("other_abnormal_stay_time", when('other_abnormal_stay_time.isNotNull && trim('other_abnormal_stay_time) =!= "", 'other_abnormal_stay_time.cast("double")).otherwise(0))
      .withColumn("other_keguan_total", when('other_keguan_total.isNotNull && trim('other_keguan_total) =!= "", 'other_keguan_total.cast("double")).otherwise(0))
      .withColumn("closure_time", when('closure_time.isNotNull && trim('closure_time) =!= "", 'closure_time.cast("double")).otherwise(0))
      .withColumn("total_sub_tm", 'abnormal_stay_time + 'other_abnormal_stay_time)
      .withColumn("total_ob_tm", 'other_ob_stay_time + 'other_keguan_total + 'closure_time)
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
    writeToHive(spark, res_df, Seq("inc_day"), end_tb)
  }

  def procRecallDF(spark: SparkSession, start_rt_tb: String, inc_day: String): DataFrame = {
    import spark.implicits._
    val org_realtime_sql = s"""select * from $start_rt_tb where inc_day='$inc_day'"""
    val org_realtime_df = spark.sql(org_realtime_sql).rdd.repartition(400).map(x => {
      val list = new ArrayBuffer[RecallRealTime]()
      val y = JSON.parseObject(x.getString(0))
      val youngduInfo = y.getJSONArray("youngduInfo")
      val stayInfo = y.getJSONArray("stayInfo")
      val roadClosure = y.getJSONArray("roadClosure")


      val task_id = getJsonValue(y, "task_id", "")
      val task_area_code = getJsonValue(y, "task_area_code", "")
      val line_code = getJsonValue(y, "line_code", "")
      val task_subid_arr = getJsonValue(y, "task_subid", "").split("\\|", -1)
      val sub_start_dept_arr = getJsonValue(y, "sub_start_dept", "").split("\\|", -1)
      val sub_end_dept_arr = getJsonValue(y, "sub_end_dept", "").split("\\|", -1)
      val sub_start_outer_add_code_arr = getJsonValue(y, "sub_start_outer_add_code", "").split("\\|", -1)
      val sub_end_outer_add_code_arr = getJsonValue(y, "sub_end_outer_add_code", "").split("\\|", -1)
      val sub_start_dept_coordinate_arr = getJsonValue(y, "sub_start_dept_coordinate", "").split("\\|", -1)
      val sub_end_dept_coordinate_arr = getJsonValue(y, "sub_end_dept_coordinate", "").split("\\|", -1)
      val vehicle_type = getJsonValue(y, "vehicle_type", "")
      val sub_plan_depart_tm_arr = getJsonValue(y, "sub_plan_depart_tm", "").split("\\|", -1).map(x => {
        x.split("\\.")(0).replaceAll("T", " ")
      })
      val sub_plan_arrive_tm_arr = getJsonValue(y, "sub_plan_arrive_tm", "").split("\\|", -1).map(x => {
        x.split("\\.")(0).replaceAll("T", " ")
      })
      val sub_actual_depart_tm_arr = getJsonValue(y, "sub_actual_depart_tm", "").split("\\|", -1)
      val sub_actual_arrive_tm_arr = getJsonValue(y, "sub_actual_arrive_tm", "").split("\\|", -1)
      val task_subid_line_distance_arr = getJsonValue(y, "task_subid_line_distance", "").split("\\|", -1)
      val rt_dist_arr = getJsonValue(y, "rt_dist", "").split(";", -1) //todo fix ; 分割
      val vehicle_serial = getJsonValue(y, "vehicle_serial", "")
      val driver_id = getJsonValue(y, "driver_id", "")
      val driver_name = getJsonValue(y, "driver_name", "")
      val carrier_type = getJsonValue(y, "carrier_type", "")
      val carrier_name = getJsonValue(y, "carrier_name", "")
      val line_require_id = getJsonValue(y, "line_require_id", "")
      val transoport_level = getJsonValue(y, "transoport_level", "")
      val biz_type = getJsonValue(y, "biz_type", "")
      val require_category = getJsonValue(y, "require_category", "")
      val to_ground = getJsonValue(y, "to_ground", "")
      val conduct_type2_arr = getJsonValue(y, "conduct_type_final2", "").split(";", -1) //todo fix ; 分割
      val stay_duration_arr = getJsonValue(y, "stay_duration", "").split(";", -1) //todo fix ; 分割
      val if_evaluate_time = getEvaluateTime(biz_type, require_category, to_ground)


      for (i <- 0 until task_subid_arr.length) {
        val task_subid = try {
          task_subid_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val start_dept = try {
          sub_start_dept_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val end_dept = try {
          sub_end_dept_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val start_outer_add_code = try {
          sub_start_outer_add_code_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val end_outer_add_code = try {
          sub_end_outer_add_code_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val start_dept_coordinate = try {
          sub_start_dept_coordinate_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val end_dept_coordinate = try {
          sub_end_dept_coordinate_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val plan_depart_tm = try {
          sub_plan_depart_tm_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "0.0"
        }
        val plan_arrive_tm = try {
          sub_plan_arrive_tm_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "0.0"
        }
        val actual_depart_tm = try {
          sub_actual_depart_tm_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "0.0"
        }
        val actual_arrive_tm = try {
          sub_actual_arrive_tm_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "0.0"
        }
        val line_distance = try {
          task_subid_line_distance_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val rt_dist = try {
          rt_dist_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val conduct_type = try {
          conduct_type2_arr(i)
        } catch {
          case e: ArrayIndexOutOfBoundsException => "-"
        }
        val line_time = ((timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", plan_arrive_tm) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", plan_depart_tm)) / 60.0).toInt
        val actual_run_time = ((timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", actual_arrive_tm) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", actual_depart_tm)) / 60).toInt
        val difftime_plan_actual = line_time - actual_run_time
        val ac_is_run_ontime = if (actual_run_time - 1.0 <= line_time) "1" else "0"
        val normal_stay_time = (line_time / 240.0).toInt * 1200 //4小时休息20分钟 转 秒

        var other_keguan_total = 0.0
        if (youngduInfo != null && youngduInfo.size() > 0) {
          try {
            val is_keguan_arr = youngduInfo.getJSONObject(i).getString("is_keguan").split(";", -1)
            val disu_duration_subob_arr = youngduInfo.getJSONObject(i).getString("disu_duration_subob").split(";", -1)
            for (j <- 0 until is_keguan_arr.length) {
              if (Seq("停留客观", "低速客观").contains(is_keguan_arr(j))) {
                val disu_dura_tm = if (strNotNull(disu_duration_subob_arr(j))) disu_duration_subob_arr(j).toDouble else 0.0
                other_keguan_total += disu_dura_tm
              }
            }
          } catch {
            case e: Exception => "" + e
          }
        }
        //计算停留时长信息
        var service_tm, other_tm = 0.0
        if (stayInfo != null && stayInfo.size() > 0) {
          var tmp1:JSONObject = null
          try {
            tmp1 = stayInfo.getJSONObject(i)
          } catch {
            case e: IndexOutOfBoundsException => ""
          }
          if (tmp1 != null) {
            if (stayInfo.getJSONObject(i).getString("is_zhuguan") != null) {
              val is_zhuguan_arr = stayInfo.getJSONObject(i).getString("is_zhuguan").split("\\|")
              for (z <- 0 until is_zhuguan_arr.length) {
                if (is_zhuguan_arr(z).trim == "服务区") {
                  service_tm += (try {
                    stay_duration_arr(i).split("\\|", -1)(z).toDouble
                  } catch {
                    case e: IndexOutOfBoundsException => 0.0
                  })
                }
                if (is_zhuguan_arr(z).trim == "停留主观") {
                  other_tm += (try {
                    stay_duration_arr(i).split("\\|", -1)(z).toDouble
                  } catch {
                    case e: IndexOutOfBoundsException => 0.0
                  })
                }
              }
            }
          }
        }
        //解析roadClosure
        var closure_contime = "0"
        var tmp2:JSONObject = null
        try {
          tmp2 = roadClosure.getJSONObject(i)
        } catch {
          case e:Exception => ""
        }
        if (roadClosure != null && tmp2 != null) {
          closure_contime = roadClosure.getJSONObject(i).getString("closure_contime")
        }
        list += RecallRealTime(task_id, task_area_code, line_code, task_subid, start_dept, end_dept, start_outer_add_code, end_outer_add_code, start_dept_coordinate, end_dept_coordinate, vehicle_type, plan_depart_tm, plan_arrive_tm, actual_depart_tm, actual_arrive_tm, line_time.toString, line_distance, rt_dist, actual_run_time.toString, vehicle_serial, driver_id, driver_name, carrier_type, carrier_name, line_require_id, transoport_level, biz_type, require_category, to_ground, if_evaluate_time, difftime_plan_actual.toString, ac_is_run_ontime, conduct_type, normal_stay_time.toString, other_keguan_total.formatted("%.2f"), service_tm, other_tm, closure_contime)
      }
      list
    }).flatMap(z => z).toDF()
    org_realtime_df
  }

  def procWarningDF(spark: SparkSession, start_gj_tb: String, inc_day: String): DataFrame = {
    import spark.implicits._
    val day_5_ago = getdaysBeforeOrAfter(inc_day, -5)
    val org_warning_sql = s"""select * from $start_gj_tb where inc_day between '$day_5_ago' and '$inc_day'"""
    val org_warning_df = spark.sql(org_warning_sql).rdd.repartition(400).map(x => {
      val y = JSON.parseObject(x.getString(0))
      val task_subid = getJsonValue(y, "task_subid", "")
      val final_label = getJsonValue(y, "final_label", "")
      val disu_duration_subob = getJsonValue(y, "disu_duration_subob", "0.0")
      (task_subid, final_label, disu_duration_subob)
    }).toDF("task_subid", "final_label", "disu_duration_subob")
      .withColumn("disu_duration_subob", when('disu_duration_subob.isNotNull && trim('disu_duration_subob) =!= "", 'disu_duration_subob.cast("double")).otherwise(0.0))
      .withColumn("sevice_tm", when(trim('final_label) === "服务区", 'disu_duration_subob).otherwise(0.0))
      .withColumn("zg_tm", when(trim('final_label) === "主观", 'disu_duration_subob).otherwise(0.0))
      .withColumn("kg_tm", when(trim('final_label) === "客观", 'disu_duration_subob).otherwise(0.0))
      .groupBy("task_subid").agg(sum('sevice_tm).as("sevice_tm_vms"), sum('zg_tm).as("zhuguan_vms"), sum('kg_tm).as("other_ob_stay_time"))
      .select("task_subid", "sevice_tm_vms", "zhuguan_vms", "other_ob_stay_time")
    org_warning_df
  }

  def getAbnormalStayTime = udf((service_total_stay_time: String, normal_stay_time: String) => {
    var abnormal_stay_time = "0.0"
    val diff_tm =
      (try {
        service_total_stay_time.toDouble
      } catch {
        case e: Exception => 0.0
      }) - (try {
        normal_stay_time.toDouble
      } catch {
        case e: Exception => 0.0
      })
    if (diff_tm > 0) abnormal_stay_time = diff_tm.formatted("%.2f")
    abnormal_stay_time
  })

  def getEvaluateTime(biz_type: String, require_category: String, to_ground: String): String = {
    var if_evaluate_time = "0"
    if (!Seq("13", "93", "91", "92", "94", "95").contains(biz_type) && Seq("0", "1", "2", "17", "18").contains(require_category) && to_ground == "1") {
      if_evaluate_time = "1"
    }
    if_evaluate_time
  }
}
