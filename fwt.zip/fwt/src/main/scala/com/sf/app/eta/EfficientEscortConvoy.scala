package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

/**
 * @task_id: 906026
 * @description:时效护航价值指标线上化【shixiao_huhang_ribao_chixushichang shixiao_huhang_ribao_wandianshichang】
 * 来源表指标监控 dm_tdsp_dw.grd_new_task_detail/ods_russtask.tt_vehicle_monitor_warning_summary
 * @demander: 左佳怡 01403789
 * @author 01418539 caojia
 * @date 2023/10/31 10:58
 */
object EfficientEscortConvoy extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    runWarningDuration(spark, inc_day)
    runDelayDuration(spark, inc_day)
    runOntimePerformance(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def runDelayDuration(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.shixiao_huhang_ribao_wandianshichang limit 0""").schema.map(_.name).map(col)
    val warn_dura_df = getDelayDurationData(spark, inc_day)
      .groupBy("plan_depart_date")
      .agg(
        count("task_id") as "all_total_num",
        countDistinct("task_id") as "total_num",
        sum("delay_cnt") as "delay_cnt",
        sum("delay_batch_tm2") as "delay_batch_tm2_sum",
        countDistinct("num_0_2h") as "num_0_2h",
        countDistinct("num_2_4h") as "num_2_4h",
        countDistinct("num_4_6h") as "num_4_6h",
        countDistinct("num_6_8h") as "num_6_8h",
        countDistinct("num_8h") as "num_8h",
        sum("tm_0_2h") as "continue_tm_0_2h_sum",
        sum("tm_2_4h") as "continue_tm_2_4h_sum",
        sum("tm_4_6h") as "continue_tm_4_6h_sum",
        sum("tm_6_8h") as "continue_tm_6_8h_sum",
        sum("tm_8h") as "continue_tm_8h_sum",
        sum("cnt_0_2h") as "cnt_0_2h_sum",
        sum("cnt_2_4h") as "cnt_2_4h_sum",
        sum("cnt_4_6h") as "cnt_4_6h_sum",
        sum("cnt_6_8h") as "cnt_6_8h_sum",
        sum("cnt_8h") as "cnt_8h_sum",
        countDistinct("ontime_num") as "ontime_num",
        avg("ontime_continue_tm") as "ontime_continue_tm"
      )
      .withColumn("continue_tm_0_2h", when('cnt_0_2h_sum > 0, 'continue_tm_0_2h_sum / 'cnt_0_2h_sum))
      .withColumn("continue_tm_2_4h", when('cnt_0_2h_sum > 0, 'continue_tm_2_4h_sum / 'cnt_2_4h_sum))
      .withColumn("continue_tm_4_6h", when('cnt_0_2h_sum > 0, 'continue_tm_4_6h_sum / 'cnt_4_6h_sum))
      .withColumn("continue_tm_6_8h", when('cnt_0_2h_sum > 0, 'continue_tm_6_8h_sum / 'cnt_6_8h_sum))
      .withColumn("continue_tm_8h", when('cnt_0_2h_sum > 0, 'continue_tm_8h_sum / 'cnt_8h_sum))
      .withColumn("total_continue_tm", when('delay_cnt > 0, 'delay_batch_tm2_sum / 'delay_cnt))
      .withColumn("ratio_num_0_2h", when('total_num > 0, concat(round(lit(100) * 'num_0_2h / 'total_num, 4), lit("%"))))
      .withColumn("ratio_num_2_4h", when('total_num > 0, concat(round(lit(100) * 'num_2_4h / 'total_num, 4), lit("%"))))
      .withColumn("ratio_num_4_6h", when('total_num > 0, concat(round(lit(100) * 'num_4_6h / 'total_num, 4), lit("%"))))
      .withColumn("ratio_num_6_8h", when('total_num > 0, concat(round(lit(100) * 'num_6_8h / 'total_num, 4), lit("%"))))
      .withColumn("ratio_num_8h", when('total_num > 0, concat(round(lit(100) * 'num_8h / 'total_num, 4), lit("%"))))
      .withColumn("ontime_ratio_num", when('total_num > 0, concat(round(lit(100) * 'ontime_num / 'total_num, 4), lit("%"))))
      .withColumn("inc_day", lit(inc_day)).select(res_cols: _*)
    writeToHive(spark, warn_dura_df, Seq("inc_day"), "dm_gis.shixiao_huhang_ribao_wandianshichang")
  }

  def runWarningDuration(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.shixiao_huhang_ribao_chixushichang limit 0""").schema.map(_.name).map(col)
    val warn_dura_df = getWarningDurationData(spark, inc_day)
      .groupBy("task_plan_depart_date")
      .agg(
        count("id") as "all_total_num",
        countDistinct("id") as "total_num",
        avg("abnormal_tm") as "total_continue_tm",
        countDistinct("num_0_30") as "num_0_30",
        countDistinct("num_30_60") as "num_30_60",
        countDistinct("num_60_120") as "num_60_120",
        countDistinct("num_120") as "num_120",
        sum("tm_0_30") as "continue_tm_0_30_sum",
        sum("tm_30_60") as "continue_tm_30_60_sum",
        sum("tm_60_120") as "continue_tm_60_120_sum",
        sum("tm_120") as "continue_tm_120_sum",
        sum("cnt_0_30") as "cnt_0_30_sum",
        sum("cnt_30_60") as "cnt_30_60_sum",
        sum("cnt_60_120") as "cnt_60_120_sum",
        sum("cnt_120") as "cnt_120_sum"
      )
      .withColumn("continue_tm_0_30", when('cnt_0_30_sum > 0, 'continue_tm_0_30_sum / 'cnt_0_30_sum))
      .withColumn("continue_tm_30_60", when('cnt_30_60_sum > 0, 'continue_tm_30_60_sum / 'cnt_30_60_sum))
      .withColumn("continue_tm_60_120", when('cnt_60_120_sum > 0, 'continue_tm_60_120_sum / 'cnt_60_120_sum))
      .withColumn("continue_tm_120", when('cnt_120_sum > 0, 'continue_tm_120_sum / 'cnt_120_sum))
      .withColumn("ratio_num_0_30", when('total_num > 0, concat(round(lit(100) * 'num_0_30 / 'total_num, 4), lit("%"))))
      .withColumn("ratio_num_30_60", when('total_num > 0, concat(round(lit(100) * 'num_30_60 / 'total_num, 4), lit("%"))))
      .withColumn("ratio_num_60_120", when('total_num > 0, concat(round(lit(100) * 'num_60_120 / 'total_num, 4), lit("%"))))
      .withColumn("ratio_num_120", when('total_num > 0, concat(round(lit(100) * 'num_120 / 'total_num, 4), lit("%"))))
      .withColumn("inc_day", lit(inc_day)).select(res_cols: _*)
    writeToHive(spark, warn_dura_df, Seq("inc_day"), "dm_gis.shixiao_huhang_ribao_chixushichang")
  }

  //1.3
  def runOntimePerformance(spark: SparkSession, inc_day: String): Unit = {
    val days_1_bef = getdaysBeforeOrAfter(inc_day, -1)
    val days_7_aft = getdaysBeforeOrAfter(inc_day, 7)
    val sql =
      s"""
         |Select
         |  date_format(plan_depart_tm, 'yyyy-MM-dd') as plan_depart_date,
         |  count(distinct task_id) as task_num,
         |  sum(if(is_run_ontime = '1', 1, 0)) as task_ontime_num,
         |  sum(if(is_run_ontime = '1', 1, 0)) / count(distinct task_id) as ratio_ontime_task
         |from
         |  dm_tdsp_dw.grd_new_task_detail
         |where
         |  inc_day >= '$days_1_bef' and inc_day <= '$days_7_aft'
         |  and is_timeliness_appraise in ('1')
         |  and piece_type in ('大件', '小件')
         |  and (actual_arrive_tm is not null or actual_arrive_tm != '' )
         |  and regexp_replace(date_format(plan_depart_tm, 'yyyy-MM-dd'),'-','') ='$inc_day'
         |Group by date_format(plan_depart_tm, 'yyyy-MM-dd')
         |""".stripMargin
    val res_cols = spark.sql("""select * from dm_gis.dapan_zhundianlv limit 0""").schema.map(_.name).map(col)
    val ontime_df = spark.sql(sql).withColumn("inc_day", lit(inc_day)).select(res_cols: _*)

    writeToHive(spark, ontime_df, Seq("inc_day"), "dm_gis.dapan_zhundianlv")
  }

  //1.2
  def getDelayDurationData(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    val days_1_bef = getdaysBeforeOrAfter(inc_day, -1)
    val days_7_aft = getdaysBeforeOrAfter(inc_day, 7)

    val sql =
      s"""
         |select
         |  a.*,
         |  case
         |    when a.delay_batch_tm > 0
         |    and delay_batch_tm <= 120 then '(0,2h]'
         |    when a.delay_batch_tm > 120
         |    and delay_batch_tm <= 240 then '(2h,4h]'
         |    when a.delay_batch_tm > 240
         |    and delay_batch_tm <= 360 then '(4h,6h]'
         |    when a.delay_batch_tm > 360
         |    and delay_batch_tm <= 480 then '(6h,8h]'
         |    when a.delay_batch_tm > 480 then '(8h,+∞]'
         |    else '准点'
         |  end as batch_delay_tm_part,
         |  if(a.delay_batch_tm < 0, 0, a.delay_batch_tm) as delay_batch_tm2
         |from
         |  (
         |    select
         |      date_format(plan_depart_tm, 'yyyy-MM-dd') as plan_depart_date,
         |      task_id,
         |      if(actual_arrive_tm > batch_last_arrive_tm,'是','否') as if_batch_delay,
         |      (unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(batch_last_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) / 60 AS delay_batch_tm,
         |      if(actual_run_time > plan_run_time + 1, '是', '否') as if_run_delay,
         |      (actual_run_time - plan_run_time - 1) as delay_run_tm
         |    from
         |      dm_tdsp_dw.grd_new_task_detail
         |    where
         |      inc_day >= '$days_1_bef' and inc_day <= '$days_7_aft'
         |      and is_timeliness_appraise in ('1')
         |      and piece_type in ('大件', '小件')
         |      and (actual_arrive_tm is not null or actual_arrive_tm != '')
         |      and regexp_replace(date_format(plan_depart_tm, 'yyyy-MM-dd'),'-','') ='$inc_day'
         |      and task_id in (
         |        SELECT
         |          distinct task_id
         |        FROM
         |          ods_russtask.tt_vehicle_monitor_warning_summary
         |        where
         |          inc_day >= '$days_1_bef' and inc_day <= '$days_7_aft'
         |          and regexp_replace(task_plan_depart_date,'-','') ='$inc_day'
         |          and msg_type in ('5', '7', '8')
         |          and biz_type in ('0', '16')
         |          and warn_level in ('3')
         |          and (attr33 is not null or attr33 != '' )
         |          and (attr34 is not null or attr34 != '' )
         |      )
         |  ) a
         |where
         |  ( a.delay_batch_tm is not null or a.delay_batch_tm != '' )
         |""".stripMargin

    val df = spark.sql(sql)
      .withColumn("delay_cnt", when('if_batch_delay === "是", 1).otherwise(0))
      .withColumn("num_0_2h", when('batch_delay_tm_part === "(0,2h]", 'task_id))
      .withColumn("num_2_4h", when('batch_delay_tm_part === "(2h,4h]", 'task_id))
      .withColumn("num_4_6h", when('batch_delay_tm_part === "(4h,6h]", 'task_id))
      .withColumn("num_6_8h", when('batch_delay_tm_part === "(6h,8h]", 'task_id))
      .withColumn("num_8h", when('batch_delay_tm_part === "(8h,+∞]", 'task_id))
      .withColumn("tm_0_2h", when('batch_delay_tm_part === "(0,2h]", 'delay_batch_tm2).otherwise(0))
      .withColumn("tm_2_4h", when('batch_delay_tm_part === "(2h,4h]", 'delay_batch_tm2).otherwise(0))
      .withColumn("tm_4_6h", when('batch_delay_tm_part === "(4h,6h]", 'delay_batch_tm2).otherwise(0))
      .withColumn("tm_6_8h", when('batch_delay_tm_part === "(6h,8h]", 'delay_batch_tm2).otherwise(0))
      .withColumn("tm_8h", when('batch_delay_tm_part === "(8h,+∞]", 'delay_batch_tm2).otherwise(0))
      .withColumn("cnt_0_2h", when('batch_delay_tm_part === "(0,2h]", 1).otherwise(0))
      .withColumn("cnt_2_4h", when('batch_delay_tm_part === "(2h,4h]", 1).otherwise(0))
      .withColumn("cnt_4_6h", when('batch_delay_tm_part === "(4h,6h]", 1).otherwise(0))
      .withColumn("cnt_6_8h", when('batch_delay_tm_part === "(6h,8h]", 1).otherwise(0))
      .withColumn("cnt_8h", when('batch_delay_tm_part === "(8h,+∞]", 1).otherwise(0))
      .withColumn("ontime_num", when('batch_delay_tm_part === "准点", 'task_id))
      .withColumn("ontime_continue_tm", when('batch_delay_tm_part === "准点", 'delay_batch_tm2).otherwise(0))
    df
  }

  //1.1
  def getWarningDurationData(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    val days_1_bef = getdaysBeforeOrAfter(inc_day, -1)
    val days_7_aft = getdaysBeforeOrAfter(inc_day, 7)
    val detail_sql =
      s"""select task_id from dm_tdsp_dw.grd_new_task_detail
         | where
         |   inc_day >= '$days_1_bef' and inc_day <= '$days_7_aft'
         |   and is_timeliness_appraise in ('1')
         |   and piece_type in ('大件', '小件')
         |   and actual_arrive_tm is not null and actual_arrive_tm != ''
         |   and task_id is not null and task_id != ''
         |   and regexp_replace(date_format(plan_depart_tm, 'yyyy-MM-dd'),'-','') ='$inc_day'
         | group by task_id
         |   """.stripMargin
    logger.error(">>>>加载的sql>>>>>>" + detail_sql)
    val task_id_arr = spark.sql(detail_sql).map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    //加载 告警明细表
    val summary_sql =
      s"""
         |SELECT id,task_plan_depart_date,task_id,attr33,attr34,
         |  (attr34 / 1000 - attr33 / 1000) / 60 as abnormal_tm,
         |  inc_day,
         |  row_number() over(partition by concat(task_id, '_', attr39) order by inc_day DESC ) as num
         |FROM
         |  ods_russtask.tt_vehicle_monitor_warning_summary
         |where
         |  inc_day >= '$days_1_bef' and inc_day <= '$days_7_aft'
         |  and regexp_replace(task_plan_depart_date,'-','') ='$inc_day'
         |  and msg_type in ('5', '7', '8')
         |  and biz_type in ('0', '16')
         |  and warn_level in ('3')
         |  and attr33 is not null and attr33 != ''
         |  and attr34 is not null and attr34 != ''
         |  and task_id in($task_id_arr)
         |""".stripMargin
    val summary_df = spark.sql(summary_sql).filter("num = 1")
      .na.fill(0.0, Seq("abnormal_tm"))
      .withColumn("num_0_30", when('abnormal_tm > 0 && 'abnormal_tm <= 30, 'id))
      .withColumn("num_30_60", when('abnormal_tm > 30 && 'abnormal_tm <= 60, 'id))
      .withColumn("num_60_120", when('abnormal_tm > 60 && 'abnormal_tm <= 120, 'id))
      .withColumn("num_120", when('abnormal_tm > 120, 'id))
      .withColumn("tm_0_30", when('abnormal_tm > 0 && 'abnormal_tm <= 30, 'abnormal_tm).otherwise(0))
      .withColumn("tm_30_60", when('abnormal_tm > 30 && 'abnormal_tm <= 60, 'abnormal_tm).otherwise(0))
      .withColumn("tm_60_120", when('abnormal_tm > 60 && 'abnormal_tm <= 120, 'abnormal_tm).otherwise(0))
      .withColumn("tm_120", when('abnormal_tm > 120, 'abnormal_tm).otherwise(0))
      .withColumn("cnt_0_30", when('abnormal_tm > 0 && 'abnormal_tm <= 30, 1).otherwise(0))
      .withColumn("cnt_30_60", when('abnormal_tm > 30 && 'abnormal_tm <= 60, 1).otherwise(0))
      .withColumn("cnt_60_120", when('abnormal_tm > 60 && 'abnormal_tm <= 120, 1).otherwise(0))
      .withColumn("cnt_120", when('abnormal_tm > 120, 1).otherwise(0))
    summary_df
  }
}
