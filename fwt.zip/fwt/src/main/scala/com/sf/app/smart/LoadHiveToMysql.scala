package com.sf.app.smart

import com.sf.app.smart.SmartAppContext.getMysqlcreateTable
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.getDevEGOVMysqlConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}
import java.util.concurrent.ConcurrentHashMap
import scala.collection.JavaConversions.asScalaIterator

/**
 * @description:（已下线20230710）424539
 * @author 01418539 caojia
 * @date 2022/3/30 11:34
 */
object LoadHiveToMysql extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")

    val table_arr = Array(
      "scomm_device_coding_status_dtl",
      "scomm_device_order_on_cnt",
      "scomm_device_company_agent_dtl",
      "scomm_device_order_summary_provice",
      "scomm_device_order_summary_city",
      "scomm_device_order_summary_region",
      "scomm_device_order_summary_street",
      "scomm_device_order_summary_community",
      "scomm_device_order_summary_village")

    val start_day = args(0)
    val end_day = args(1)
    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |     start_day:格式20220101均为8位数
          |     end_day:格式20220101均为8位数
          |""".stripMargin)
      sys.exit(2)
    }
    logger.error(s"2个参数- 1：向hive表中插入数据格式为20220101--param2为起始时间:$start_day,param3为结束时间:$end_day")

    upsertToDevMysql(spark, table_arr, start_day, end_day)

    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")


  }

  def upsertToDevMysql(spark: SparkSession, tableNames: Array[String], start_day: String, end_day: String): Unit = {

    for (i <- 0 until tableNames.length) {

      val hiveTableName = tableNames(i)
      val tableName = tableNames(i).toUpperCase
      //加载数据
      val dataDf = spark.sql(
        s"""
           |select
           |*
           |from dm_gis_oms.$hiveTableName
           |where inc_day>='$start_day' and inc_day <= '$end_day'
           |""".stripMargin)
      dataDf.show(10)
      //将mysql中原表数据分区删除 支持重跑
      val conn: Connection = getDevEGOVMysqlConnect()
      try {
        val querySql = s"select * from gis_oms_lip_egov.$tableName where SUBSTRING( STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
        val query: PreparedStatement = conn.prepareStatement(querySql)
        val queryRes = query.executeQuery()
        if (queryRes.next()) {
          val delSql = s"delete from gis_oms_lip_egov.$tableName where SUBSTRING( STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
          val del: PreparedStatement = conn.prepareStatement(delSql)
          del.execute()
        }
      } catch {
        case ex: Exception => logger.error(s"删除表 gis_oms_lip_egov.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
          throw ex
      }

      //将数据重新写入mysql中
      if (tableName.equals("SCOMM_DEVICE_CODING_STATUS_DTL")) {
        //循环遍历数据写入
        dataDf.toLocalIterator.foreach(row => {
          try {
            val insertSql = s"insert into gis_oms_lip_egov.$tableName values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            val insert: PreparedStatement = conn.prepareStatement(insertSql)
            insert.setString(1, row.getAs[String]("id"))
            insert.setString(2, row.getAs[String]("inc_day"))
            insert.setString(3, row.getAs[String]("province_name"))
            insert.setString(4, row.getAs[String]("city_name"))
            insert.setString(5, row.getAs[String]("region"))
            insert.setString(6, row.getAs[String]("street"))
            insert.setString(7, row.getAs[String]("community"))
            insert.setString(8, row.getAs[String]("village"))
            insert.setString(9, row.getAs[String]("station_name"))
            insert.setString(10, row.getAs[String]("device_location"))
            insert.setString(11, row.getAs[String]("device_no"))
            insert.setInt(12, row.getAs[Int]("total_coding"))
            insert.setString(13, row.getAs[String]("online_time"))
            insert.setString(14, row.getAs[String]("coding_no"))
            insert.setInt(15, row.getAs[Int]("order_cnt"))
            insert.setInt(16, row.getAs[Int]("on_order_cnt"))
            insert.setString(17, row.getAs[String]("coding_status"))
            insert.setTimestamp(18,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(18, row.getAs[String]("inc_day"))
            insert.setNull(19, 0)
            insert.setTimestamp(20,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(20, row.getAs[String]("inc_day"))
            insert.setNull(21, 0)
            insert.execute()
          } catch {
            case ex: Exception => logger.error(s"往表 gis_oms_lip_egov.$tableName  中插入$start_day 至 $end_day 数据时出现错误", ex)
              throw ex
          }
        })
      } else if (tableName.equals("SCOMM_DEVICE_ORDER_ON_CNT")) {
        //循环遍历数据写入
        dataDf.toLocalIterator.foreach(row => {
          try {
            val insertSql = s"insert into gis_oms_lip_egov.$tableName values(?,?,?,?,?,?,?,?,?,?,?,?)"
            val insert: PreparedStatement = conn.prepareStatement(insertSql)
            insert.setString(1, row.getAs[String]("id"))
            insert.setString(2, row.getAs[String]("inc_day"))
            insert.setString(3, row.getAs[String]("charge_no"))
            insert.setString(4, row.getAs[String]("coding_no"))
            insert.setString(5, row.getAs[String]("order_start_date"))
            insert.setString(6, row.getAs[String]("order_end_date"))
            insert.setInt(7, row.getAs[Int]("order_cnt"))
            insert.setInt(8, row.getAs[Int]("on_order_cnt"))
            insert.setTimestamp(9,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(9, row.getAs[String]("inc_day"))
            insert.setNull(10, 0)
            insert.setTimestamp(11,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(11, row.getAs[String]("inc_day"))
            insert.setNull(12, 0)
            insert.execute()
          } catch {
            case ex: Exception => logger.error(s"往表 gis_oms_lip_egov.$tableName  中插入$start_day 至 $end_day 数据时出现错误", ex)
              throw ex
          }
        })
      } else if (tableName.equals("SCOMM_DEVICE_COMPANY_AGENT_DTL")) {
        //循环遍历数据写入
        dataDf.toLocalIterator.foreach(row => {
          try {
            val insertSql = s"insert into gis_oms_lip_egov.$tableName values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            val insert: PreparedStatement = conn.prepareStatement(insertSql)
            insert.setString(1, row.getAs[String]("id"))
            insert.setString(2, row.getAs[String]("inc_day"))
            insert.setString(3, row.getAs[String]("province_name"))
            insert.setString(4, row.getAs[String]("city_name"))
            insert.setString(5, row.getAs[String]("region"))
            insert.setString(6, row.getAs[String]("street"))
            insert.setString(7, row.getAs[String]("community"))
            insert.setString(8, row.getAs[String]("village"))
            insert.setString(9, row.getAs[String]("station_name"))
            insert.setString(10, row.getAs[String]("device_location"))
            insert.setString(11, row.getAs[String]("longitude"))
            insert.setString(12, row.getAs[String]("latitude"))
            insert.setString(13, row.getAs[String]("device_no"))
            insert.setString(14, row.getAs[String]("device_type"))
            insert.setString(15, row.getAs[String]("online_time"))
            insert.setString(16, row.getAs[String]("rule_details"))
            insert.setInt(17, row.getAs[Int]("socket_number"))
            insert.setString(18, row.getAs[String]("brand"))
            insert.setString(19, row.getAs[String]("building_supplier"))
            insert.setString(20, row.getAs[String]("supply_responsible"))
            insert.setString(21, row.getAs[String]("supply_responsible_phone"))
            insert.setString(22, row.getAs[String]("company"))
            insert.setString(23, row.getAs[String]("agent"))
            insert.setString(24, row.getAs[String]("custom_status"))
            insert.setString(25, row.getAs[String]("d_status"))
            insert.setDouble(26, row.getAs[Double]("total_status_yes"))
            insert.setDouble(27, row.getAs[Double]("total_status_be"))
            insert.setTimestamp(28,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(25, row.getAs[String]("inc_day"))
            insert.setNull(29, 0)
            insert.setTimestamp(30,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(27, row.getAs[String]("inc_day"))
            insert.setNull(31, 0)
            insert.execute()
          } catch {
            case ex: Exception => logger.error(s"往表 gis_oms_lip_egov.$tableName 中插入$start_day 至 $end_day 数据时出现错误", ex)
              throw ex
          }
        })
      } else if (tableName.endsWith("_PROVICE") || tableName.endsWith("_CITY")
        || tableName.endsWith("_REGION") || tableName.endsWith("_STREET")
        || tableName.endsWith("_COMMUNITY") || tableName.endsWith("_VILLAGE")) {
        //循环遍历数据写入
        dataDf.toLocalIterator.foreach(row => {
          try {
            val insertSql = s"insert into gis_oms_lip_egov.$tableName values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            val insert: PreparedStatement = conn.prepareStatement(insertSql)
            insert.setString(1, row.getAs[String]("id"))
            insert.setString(2, row.getAs[String]("inc_day"))
            insert.setString(3, row.getAs[String]("province_name"))
            insert.setString(4, row.getAs[String]("city_name"))
            insert.setString(5, row.getAs[String]("region"))
            insert.setString(6, row.getAs[String]("street"))
            insert.setString(7, row.getAs[String]("community"))
            insert.setString(8, row.getAs[String]("village"))
            insert.setInt(9, row.getAs[Int]("station_cnt"))
            insert.setInt(10, row.getAs[Int]("device_cnt"))
            insert.setInt(11, row.getAs[Int]("socket_cnt"))
            insert.setInt(12, row.getAs[Int]("on_device_cnt"))
            insert.setInt(13, row.getAs[Int]("on_socket_cnt"))
            insert.setDouble(14, row.getAs[Double]("week_socket_rate"))
            insert.setDouble(15, row.getAs[Double]("week_avg_price"))
            insert.setDouble(16, row.getAs[Double]("week_avg_ele"))
            insert.setTimestamp(17,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(17, row.getAs[String]("inc_day"))
            insert.setNull(18, 0)
            insert.setTimestamp(19,new java.sql.Timestamp(new java.util.Date().getTime()))
//            insert.setString(19, row.getAs[String]("inc_day"))
            insert.setNull(20, 0)
            insert.execute()
          } catch {
            case ex: Exception => logger.error(s"往表 gis_oms_lip_egov.$tableName  中插入$start_day 至 $end_day 数据时出现错误", ex)
              throw ex
          }
        })
      }
      //统计写入mysql中的数据总量
      try {
        val querySql = s"select count(1) as cnt from gis_oms_lip_egov.$tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
        val query: PreparedStatement = conn.prepareStatement(querySql)
        val queryRes = query.executeQuery()
        if (queryRes.next()) {
          logger.error(s"表gis_oms_lip_egov.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
        }
      } catch {
        case ex: Exception => logger.error(s"统计 gis_oms_lip_egov.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
          throw ex
      }

    }
  }

  def processBDPMysqlCreateTable(tns: Array[String]): Unit = {
    var conn: Connection = null
    var sql = ""
    val createSQL: ConcurrentHashMap[String, String] = getMysqlcreateTable()

    for (i <- 0 until tns.length) {
      sql = createSQL.get(tns(i))
      val tableName = tns(i)
      conn = getDevEGOVMysqlConnect()
      try {
        //删除
        val delSql = s"DROP table IF EXISTS gis_oms_lip_egov.$tableName"
        val delState: PreparedStatement = conn.prepareStatement(delSql)
        delState.execute()
      } catch {
        case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
      }
      //建表
      try {
        val createSQl: PreparedStatement = conn.prepareStatement(sql)
        createSQl.execute()
        logger.error(s"表：$tableName 的建表语句为：" + sql)
        logger.error(s"在bdp的mysql库中建表 $tableName 成功！！！！！")
      } catch {
        case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
      }

    }
  }

}
