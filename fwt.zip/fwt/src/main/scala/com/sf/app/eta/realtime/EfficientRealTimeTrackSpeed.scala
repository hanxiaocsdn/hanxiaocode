package com.sf.app.eta.realtime

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.common.DataSourceCommon

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 融合到实时任务中
 * @description: 实时中时效定则 第 1 and 4 部分 标签加工 【异常：低速和停留任务 抽取分析】
 * @demander: 01408890 邵一馨
 * @author 01418539 caojia
 * @date 2023/4/26 15:11
 */
object EfficientRealTimeTrackSpeed extends DataSourceCommon {

  // 解析融合轨迹接口返回的json
  def parseQMJsonStr(o: JSONObject, jsonStr: String): JSONObject = {
    val t_distanceBuff = new ArrayBuffer[Long]()
    val t_durationBuff = new ArrayBuffer[Double]()
    val toll_stationBuff = new ArrayBuffer[String]()
    val serviceBuff = new ArrayBuffer[String]()
    val toll_station_linkpointinfoBuff = new ArrayBuffer[String]()
    val service_station_linkpointinfoBuff = new ArrayBuffer[String]()
    val roadclass_ab = new ArrayBuffer[String]()
    val roadname_ab = new ArrayBuffer[String]()

    try {
      val o2: JSONObject = JSON.parseObject(jsonStr)
      val status: String = o2.getString("status")
      if (status == "0") {
        logger.error("调用匹配接口成功,进行业务逻辑处理中……")
        val route: JSONObject = o2.getJSONObject("route")
        val paths: JSONArray = route.getJSONArray("paths")

        for (i <- 0 until paths.size()) {
          val path: JSONObject = paths.getJSONObject(i)
          t_distanceBuff.append(path.getLongValue("distance"))
          t_durationBuff.append(path.getDoubleValue("duration"))
          val polylineArr: Array[String] = path.getString("polyline").split(";")
          val steps: JSONArray = path.getJSONArray("steps")
          if (!steps.isEmpty) {
            for (j <- 0 until steps.size()) {
              val step: JSONObject = steps.getJSONObject(j)
              val links: JSONArray = step.getJSONArray("links")
              if (!links.isEmpty) {
                for (k <- 0 until links.size()) {
                  val link: JSONObject = links.getJSONObject(k)
                  val lnk_type: String = link.getString("lnk_type")
                  val formway: String = link.getString("formway")
                  val coorindex: Int = link.getIntValue("coorindex")
                  val pointnum: Int = link.getIntValue("pointnum")
                  val name: String = link.getString("name")
                  val roadclass: String = link.getString("roadclass")
                  roadclass_ab.append(roadclass)
                  roadname_ab.append(name)

                  val start2EndPoint: String = polylineArr(coorindex) + ";" + polylineArr(coorindex + pointnum - 1)

                  val swid: String = link.getString("sw_id")
                  if (lnk_type == "2") {
                    toll_stationBuff.append(swid)
                    toll_station_linkpointinfoBuff.append(start2EndPoint)
                  }
                  if (formway == "5") {
                    serviceBuff.append(swid)
                    service_station_linkpointinfoBuff.append(start2EndPoint)
                  }
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => logger.error("匹配接口接口调用失败:" + e.getMessage)
    }
    o.put("t_distance", t_distanceBuff.sum)
    o.put("t_duration", t_durationBuff.sum)
    o.put("toll_station", toll_stationBuff.mkString("|"))
    o.put("service", serviceBuff.mkString("|"))
    o.put("toll_station_linkpointinfo", toll_station_linkpointinfoBuff.mkString("|"))
    o.put("service_station_linkpointinfo", service_station_linkpointinfoBuff.mkString("|"))
    o.put("roadclass", roadclass_ab.mkString("|"))
    o.put("roadname", roadname_ab.mkString("|"))
    o
  }

  /**
   * 高德路况接口返回的结果解析
   *
   * @param o
   * @param gd_str
   * @param event_map
   * @return
   */
  def getHistoryInterParse(o: JSONObject, gd_str: String, event_map: mutable.Map[String, (String, String)]): JSONObject = {
    val swid_len_arr, swid_gd_len_arr, swid_gd_arr, status_gd_arr, speed_gd_arr, events_code_arr, events_s, events_l = new ListBuffer[String]()
    var swid_len, swid_gd_len, swid_gd, status_gd, speed_gd = ""
    var limit_c, limit_t, reason_c, reason_t = ""
    var speed_avg_gd, gd_len: Double = 0.0

    try {
      val gd_info_json = JSON.parseObject(gd_str)
      val gd_tracks = gd_info_json.getJSONArray("tracks")

      for (i <- 0 until gd_tracks.size()) {
        val flow = gd_tracks.getJSONObject(i).getJSONArray("flow")
        val events = gd_tracks.getJSONObject(i).getJSONArray("events")
        if (flow != null && flow.size() > 0 && flow.toJSONString.replaceAll(" ", "") != "[]") {
          val link_id = gd_tracks.getJSONObject(i).getString("link_id")
          swid_gd_arr += link_id
          status_gd_arr += flow.getJSONObject(0).getString("status") //todo 需要确认flow中 只有单组还是多组
          speed_gd_arr += flow.getJSONObject(0).getString("speed")
          val jp_swid = o.getString("jp_swid")
          val jp_length = o.getString("jp_length")
          val link_id_cnt = getSwidAndCount(jp_swid, jp_length, link_id)
          if (link_id_cnt.trim != "") swid_gd_len_arr += link_id_cnt else swid_gd_len_arr += "0"
        }
        if (events != null && events.size() > 0) {
          for (k <- 0 until events.size()) {
            limit_c = events.getJSONObject(k).getString("limit_c")
            limit_t = events.getJSONObject(k).getString("limit_t")
            reason_c = events.getJSONObject(k).getString("reason_c")
            reason_t = events.getJSONObject(k).getString("reason_t")
            val event_info = limit_c + "," + limit_t + "," + reason_c + "," + reason_t
            if (!events_code_arr.contains(event_info)) {
              events_code_arr += event_info
              events_s += event_map.getOrElse(event_info, ("", ""))._1
              events_l += event_map.getOrElse(event_info, ("", ""))._2
            }
          }
        }
      }
    }
    catch {
      case e: Exception => ""
    }
    swid_len = swid_len_arr.mkString("|")
    swid_gd_len = swid_gd_len_arr.mkString("|")
    swid_gd = swid_gd_arr.mkString("|")
    status_gd = status_gd_arr.mkString("|")
    speed_gd = speed_gd_arr.mkString("|")

    //计算平均速度 速度*距离/时间
    var dist_sum: Double = 0.0
    var tm_sum: Double = 0.0

    for (i <- 0 until speed_gd_arr.length) {
      try {
        if (speed_gd_arr(i).toDouble != 0.0) {
          dist_sum += swid_gd_len_arr(i).toDouble
          tm_sum += swid_gd_len_arr(i).toDouble / speed_gd_arr(i).toDouble
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    speed_avg_gd = if (tm_sum > 0) dist_sum / tm_sum else 0.0
    //单独计算gd_len
    gd_len = swid_gd_len.map(l => try {
      l.toDouble
    } catch {
      case e: Exception => 0.0
    }).sum
    o.put("swid_gd", swid_gd)
    o.put("status_gd", status_gd)
    o.put("speed_gd", speed_gd)
    o.put("swid_gd_len", swid_gd_len)
    o.put("events_code", events_code_arr.mkString("|"))
    o.put("events_s", events_s.mkString("|"))
    o.put("events_l", events_l.mkString("|"))
    o.put("speed_avg_gd", speed_avg_gd.toString)
    o.put("gd_len", gd_len.toString)
    o
  }

  def getSwidAndCount(jp_swid: String, jp_length: String, link_id: String): String = {
    var dist = "0"
    val jp_swid_arr = try {
      jp_swid.split("\\|")
    } catch {
      case e: Exception => Array()
    }
    val jp_length_arr = try {
      jp_length.split("\\|")
    } catch {
      case e: Exception => Array()
    }
    breakable {
      for (i <- 0 until jp_swid_arr.length) {
        val swid = jp_swid_arr(i)
        if (swid == link_id) {
          dist = jp_length_arr(i)
          break
        }
      }
    }
    dist
  }

}
