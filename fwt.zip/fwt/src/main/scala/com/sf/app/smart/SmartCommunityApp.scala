package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK_SER
import utils.ColumnUtil.primaryKeyEncrypt
import utils.DateUtil.getdaysBefore
import utils.SparkBuilder

/**
 * @task_id:（已下线20230710）422291
 * @description: 智慧社区项目设备报表需求
 * @author 01418539 caojia
 * @date 2022/3/23 9:39
 */
object SmartCommunityApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")

    //todo start_day 2022-01-01均为10位数
    val start_day = args(0)
    val end_days = args(1).replaceAll("'", "").split(",")
    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |     start_day:起始时间
          |     end_days:结束时间  最近3天时间
          |""".stripMargin)
      sys.exit(2)
    }
    logger.error(s"2个参数-格式为2022-01-01--param1为起始时间:$start_day,param2为结束时间:$end_days")
    for (end_day <- end_days) {
      dataProcessSmart(spark, start_day, end_day)
      logger.error(s"当天$end_day 的数据已完成更新!")
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")

  }

  def dataProcessSmart(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val inc_day = end_day.replaceAll("-", "")
    val week_ago = getdaysBefore(end_day, -6, "yyyy-MM-dd") //2022-03-16  2022-03-22

    val o_charging_device = spark.sql(
      s"""
         |select
         |    province_name,
         |    city_name,
         |    region,
         |    street,
         |    community,
         |    village,
         |    device_no,
         |    station_code,
         |    socket_number,
         |    create_time,
         |    regexp_replace(regexp_replace(regexp_replace(station_name,'\\\\n|\\\\r|\\\\r\\\\n|\\\\t| ',''),'（','('),'）',')') station_name,--cond2中需要以下字段
         |	  regexp_replace(regexp_replace(regexp_replace(device_location,'\\\\n|\\\\r|\\\\r\\\\n|\\\\t| ',''),'（','('),'）',')') device_location,
         |	  online_time,--上线时间 缺少该字段
         |	  brand,
         |	  building_supplier,
         |	  supply_responsible,
         |	  supply_responsible_phone,
         |	  custom_status,
         |	  d_status,
         |    rule_no,
         |    longitude,
         |    latitude,
         |    device_type
         |from dm_gis_oms.scomm_charging_device
         |where substr(create_time,0,10) <= '$end_day'
         |      and device_no is not null and trim(device_no) != ''
         |      and del_flag = 0
         |""".stripMargin)
      .persist()

    val o_device_status = spark.sql(
      s"""
         |select
         |     device_no,
         |     total_status,
         |     substr(statistic_date,0,10) as statistic_date_tm,
         |     statistic_date
         |from dm_gis_oms.scomm_flow_device_status
         |where substr(statistic_date,0,10) >= '$week_ago' and substr(statistic_date,0,10)<='$end_day'
         |      and device_no is not null and trim(device_no) != ''
         |""".stripMargin)
      .persist()

    val o_order_record = spark.sql(
      s"""
         |select
         |     charge_no,
         |     coding_no,
         |     charge_start,
         |     create_time,
         |     substr(charge_start,0,10) as charge_start_tm,
         |     substr(create_time,0,10) as create_time_tm,
         |     order_status,
         |     ele,
         |     order_no,
         |     pre_mount
         |from dm_gis_oms.scomm_order_record
         |where substr(create_time,0,10) <= '$end_day'
         |      and charge_no is not null and trim(charge_no) != ''
         |""".stripMargin)
      .persist()

    val o_order_payment = spark.sql(
      """
        |select
        |     mount,
        |     order_no
        |from dm_gis_oms.scomm_order_payment
        |""".stripMargin)

    val device_ft = !o_charging_device.col("device_no").isin("18580002077", "18580002075", "2014300923", "600A000002E6")
    val status_ft = 'total_status === 1 && !o_device_status.col("device_no").isin("18580002077", "18580002075", "2014300923", "600A000002E6")

    val device_status_dtl = o_charging_device.alias("o_charging_device")
      .join(o_device_status.filter(status_ft).alias("o_device_status"), expr("o_charging_device.device_no = o_device_status.device_no"), "left")
      .withColumn("station_cnt", when('station_code.isNotNull && trim('station_code) =!= "", 1).otherwise(0))
      .withColumn("device_cnt", when(device_ft && 'custom_status === 1, 1).otherwise(0))
      .withColumn("socket_cnt", when(device_ft && 'custom_status === 1, 'socket_number).otherwise(0))
      .withColumn("on_device_cnt", when('statistic_date_tm === end_day && o_device_status.col("device_no").isNotNull, 1).otherwise(0))
      .withColumn("on_socket_cnt", when('statistic_date_tm === end_day && o_device_status.col("device_no").isNotNull, 'socket_number).otherwise(0))
      .withColumn("on_week_socket_cnt", when(o_device_status.col("device_no").isNotNull, 'socket_number).otherwise(0))
      .withColumn("num", row_number().over(Window.partitionBy(o_charging_device.col("device_no"), col("statistic_date_tm")).orderBy(desc("on_week_socket_cnt"))))
      .filter('num === 1)
      .groupBy(col("province_name"), col("city_name"), col("region"), col("street"), col("community"), col("village"), o_charging_device.col("device_no"))
      .agg(
        max("station_cnt") as "station_cnt", //站点数量
        max("device_cnt") as "device_cnt", //设备总数
        max("socket_cnt") as "socket_cnt", //设备总口数
        max("on_device_cnt") as "on_device_cnt", //昨天在线设备数
        max("on_socket_cnt") as "on_socket_cnt", //昨天在线口数
        sum("on_week_socket_cnt") as "on_week_socket_cnt" //单个设备一周时间内的在线口数
      )

    val order_ele_ft = !'order_status.isin(0, -3)

    val order_week_cnt = o_order_record.filter('create_time_tm >= week_ago && !'charge_no.isin("18580002077", "18580002075", "2014300923", "600A000002E6"))
      .join(o_order_payment, Seq("order_no"), "left")
      .groupBy("charge_no", "order_no")
      .agg(
        first("order_status") as "order_status",
        first("ele") as "ele",
        sum("mount") as "week_mount_total"
      )
      .withColumn("week_order_mount", when('week_mount_total > 0, 'week_mount_total).otherwise(0))
      .withColumn("week_order_mount_cnt", when('week_mount_total > 0, 1).otherwise(0))
      .withColumn("week_order_ele", when(order_ele_ft, 'ele).otherwise(0))
      .withColumn("week_order_cnt", when(order_ele_ft, 1).otherwise(0))
      .groupBy("charge_no")
      .agg(
        sum("week_order_mount") as "week_order_mount",
        sum("week_order_mount_cnt") as "week_order_mount_cnt",
        sum("week_order_ele") as "week_order_ele",
        sum("week_order_cnt") as "week_order_cnt"
      )

    val devive_no_dim = device_status_dtl
      .join(order_week_cnt.withColumnRenamed("charge_no", "device_no"), Seq("device_no"), "left")
      .na.fill(0, Seq("week_order_mount", "week_order_mount_cnt", "week_order_ele", "week_order_cnt"))
      .select(
        "province_name",
        "city_name",
        "region",
        "street",
        "community",
        "village",
        "device_no",
        "station_cnt",
        "device_cnt",
        "socket_cnt",
        "on_device_cnt",
        "on_socket_cnt", //在线口数
        "on_week_socket_cnt",
        "week_order_mount",
        "week_order_mount_cnt",
        "week_order_ele",
        "week_order_cnt"
      )
      .persist(MEMORY_AND_DISK_SER)

    //    logger.error(">>>>>>2222>>>>>devive_no_dim>>>>>>>>>>>>>>>>>>>>>>")
    //    devive_no_dim.limit(100).collect().foreach(println(_))
    //    logger.error(s">>>>>>222>>>>>devive_no_dim 数据总量为>>>>>>>>>>>${devive_no_dim.count()}>>>>>>>>>>>")

    val col_pub = Seq(col("id"), col("province_name"), col("city_name"), col("region"), col("street"), col("community"), col("village"),
      col("station_cnt"), col("device_cnt"), col("socket_cnt"), col("on_device_cnt"), col("on_socket_cnt"),
      col("week_socket_freq"), col("week_avg_price"), col("week_avg_ele"), col("inc_day"))

    val step_provice = devive_no_dim
      .groupBy("province_name")
      .agg(
        lit("/") as "city_name",
        lit("/") as "region",
        lit("/") as "street",
        lit("/") as "community",
        lit("/") as "village",
        sum("station_cnt") as "station_cnt", //站点数量
        sum("device_cnt") as "device_cnt", //设备总数
        sum("socket_cnt") as "socket_cnt", //设备总口数
        sum("on_device_cnt") as "on_device_cnt", //在线设备数
        sum("on_socket_cnt") as "on_socket_cnt", //在线口数
        sum("on_week_socket_cnt") as "on_week_socket_cnt", //近一周在线平均使用总数
        sum("week_order_mount") as "week_order_mount",
        sum("week_order_mount_cnt") as "week_order_mount_cnt",
        sum("week_order_ele") as "week_order_ele",
        sum("week_order_cnt") as "week_order_cnt"
      )
      .withColumn("week_socket_freq", when('on_week_socket_cnt =!= 0, round('week_order_cnt / 'on_week_socket_cnt, 4)).otherwise(0.0))
      .withColumn("week_avg_price", when('week_order_mount_cnt =!= 0, round(('week_order_mount / 'week_order_mount_cnt) / 100, 4)).otherwise(0.0))
      .withColumn("week_avg_ele", when('week_order_ele =!= 0, round(('week_order_ele / 'week_order_cnt) / 10000, 4)).otherwise(0.0))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('province_name, lit(""), lit(""), lit(""), lit(""), lit(""), 'inc_day))
      .select(col_pub: _*)

    val step_city = devive_no_dim
      .groupBy("province_name", "city_name")
      .agg(
        lit("/") as "region",
        lit("/") as "street",
        lit("/") as "community",
        lit("/") as "village",
        sum("station_cnt") as "station_cnt", //站点数量
        sum("device_cnt") as "device_cnt", //设备总数
        sum("socket_cnt") as "socket_cnt", //设备总口数
        sum("on_device_cnt") as "on_device_cnt", //在线设备数
        sum("on_socket_cnt") as "on_socket_cnt", //在线口数
        sum("on_week_socket_cnt") as "on_week_socket_cnt", //近一周平均使用总数
        sum("week_order_mount") as "week_order_mount",
        sum("week_order_mount_cnt") as "week_order_mount_cnt",
        sum("week_order_ele") as "week_order_ele",
        sum("week_order_cnt") as "week_order_cnt"
      )
      .withColumn("week_socket_freq", when('on_week_socket_cnt =!= 0, round('week_order_cnt / 'on_week_socket_cnt, 4)).otherwise(0.0))
      .withColumn("week_avg_price", when('week_order_mount_cnt =!= 0, round(('week_order_mount / 'week_order_mount_cnt) / 100, 4)).otherwise(0.0))
      .withColumn("week_avg_ele", when('week_order_ele =!= 0, round(('week_order_ele / 'week_order_cnt) / 10000, 4)).otherwise(0.0))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('province_name, 'city_name, lit(""), lit(""), lit(""), lit(""), 'inc_day))
      .select(col_pub: _*)

    val step_region = devive_no_dim
      .groupBy("province_name", "city_name", "region")
      .agg(
        lit("/") as "street",
        lit("/") as "community",
        lit("/") as "village",
        sum("station_cnt") as "station_cnt", //站点数量
        sum("device_cnt") as "device_cnt", //设备总数
        sum("socket_cnt") as "socket_cnt", //设备总口数
        sum("on_device_cnt") as "on_device_cnt", //在线设备数
        sum("on_socket_cnt") as "on_socket_cnt", //在线口数
        sum("on_week_socket_cnt") as "on_week_socket_cnt", //近一周平均使用总数
        sum("week_order_mount") as "week_order_mount",
        sum("week_order_mount_cnt") as "week_order_mount_cnt",
        sum("week_order_ele") as "week_order_ele",
        sum("week_order_cnt") as "week_order_cnt"
      )
      .withColumn("week_socket_freq", when('on_week_socket_cnt =!= 0, round('week_order_cnt / 'on_week_socket_cnt, 4)).otherwise(0.0))
      .withColumn("week_avg_price", when('week_order_mount_cnt =!= 0, round(('week_order_mount / 'week_order_mount_cnt) / 100, 4)).otherwise(0.0))
      .withColumn("week_avg_ele", when('week_order_ele =!= 0, round(('week_order_ele / 'week_order_cnt) / 10000, 4)).otherwise(0.0))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('province_name, 'city_name, 'region, lit(""), lit(""), lit(""), 'inc_day))
      .select(col_pub: _*)
    //    logger.error(">>>>>>2222>>>>>step_region>>>>>>>>>>>>>>>>>>>>>>")
    //    step_region.limit(1000).collect().foreach(println(_))
    //        logger.error(s">>>>>>222>>>>>step_region 数据总量为>>>>>>>>>>>${devive_no_dim.count()}>>>>>>>>>>>")

    val step_street = devive_no_dim
      .groupBy("province_name", "city_name", "region", "street")
      .agg(
        lit("/") as "community",
        lit("/") as "village",
        sum("station_cnt") as "station_cnt", //站点数量
        sum("device_cnt") as "device_cnt", //设备总数
        sum("socket_cnt") as "socket_cnt", //设备总口数
        sum("on_device_cnt") as "on_device_cnt", //在线设备数
        sum("on_socket_cnt") as "on_socket_cnt", //在线口数
        sum("on_week_socket_cnt") as "on_week_socket_cnt", //近一周平均使用总数
        sum("week_order_mount") as "week_order_mount",
        sum("week_order_mount_cnt") as "week_order_mount_cnt",
        sum("week_order_ele") as "week_order_ele",
        sum("week_order_cnt") as "week_order_cnt"
      )
      .withColumn("week_socket_freq", when('on_week_socket_cnt =!= 0, round('week_order_cnt / 'on_week_socket_cnt, 4)).otherwise(0.0))
      .withColumn("week_avg_price", when('week_order_mount_cnt =!= 0, round(('week_order_mount / 'week_order_mount_cnt) / 100, 4)).otherwise(0.0))
      .withColumn("week_avg_ele", when('week_order_ele =!= 0, round(('week_order_ele / 'week_order_cnt) / 10000, 4)).otherwise(0.0))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('province_name, 'city_name, 'region, 'street, lit(""), lit(""), 'inc_day))
      .select(col_pub: _*)

    val step_community = devive_no_dim
      .groupBy("province_name", "city_name", "region", "street", "community")
      .agg(
        lit("/") as "village",
        sum("station_cnt") as "station_cnt", //站点数量
        sum("device_cnt") as "device_cnt", //设备总数
        sum("socket_cnt") as "socket_cnt", //设备总口数
        sum("on_device_cnt") as "on_device_cnt", //在线设备数
        sum("on_socket_cnt") as "on_socket_cnt", //在线口数
        sum("on_week_socket_cnt") as "on_week_socket_cnt", //近一周平均使用总数
        sum("week_order_mount") as "week_order_mount",
        sum("week_order_mount_cnt") as "week_order_mount_cnt",
        sum("week_order_ele") as "week_order_ele",
        sum("week_order_cnt") as "week_order_cnt"
      )
      .withColumn("week_socket_freq", when('on_week_socket_cnt =!= 0, round('week_order_cnt / 'on_week_socket_cnt, 4)).otherwise(0.0))
      .withColumn("week_avg_price", when('week_order_mount_cnt =!= 0, round(('week_order_mount / 'week_order_mount_cnt) / 100, 4)).otherwise(0.0))
      .withColumn("week_avg_ele", when('week_order_ele =!= 0, round(('week_order_ele / 'week_order_cnt) / 10000, 4)).otherwise(0.0))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('province_name, 'city_name, 'region, 'street, 'community, lit(""), 'inc_day))
      .select(col_pub: _*)

    val step_village = devive_no_dim
      .groupBy("province_name", "city_name", "region", "street", "community", "village")
      .agg(
        sum("station_cnt") as "station_cnt", //站点数量
        sum("device_cnt") as "device_cnt", //设备总数
        sum("socket_cnt") as "socket_cnt", //设备总口数
        sum("on_device_cnt") as "on_device_cnt", //在线设备数
        sum("on_socket_cnt") as "on_socket_cnt", //在线口数
        sum("on_week_socket_cnt") as "on_week_socket_cnt", //近一周平均使用总数
        sum("week_order_mount") as "week_order_mount",
        sum("week_order_mount_cnt") as "week_order_mount_cnt",
        sum("week_order_ele") as "week_order_ele",
        sum("week_order_cnt") as "week_order_cnt"
      )
      .withColumn("week_socket_freq", when('on_week_socket_cnt =!= 0, round('week_order_cnt / 'on_week_socket_cnt, 4)).otherwise(0.0))
      .withColumn("week_avg_price", when('week_order_mount_cnt =!= 0, round(('week_order_mount / 'week_order_mount_cnt) / 100, 4)).otherwise(0.0))
      .withColumn("week_avg_ele", when('week_order_ele =!= 0, round(('week_order_ele / 'week_order_cnt) / 10000, 4)).otherwise(0.0))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('province_name, 'city_name, 'region, 'street, 'community, 'village, 'inc_day))
      .select(col_pub: _*)

    writeToHive(spark, step_provice, Seq("inc_day"), "dm_gis_oms.scomm_device_order_summary_provice")
    writeToHive(spark, step_city, Seq("inc_day"), "dm_gis_oms.scomm_device_order_summary_city")
    writeToHive(spark, step_region, Seq("inc_day"), "dm_gis_oms.scomm_device_order_summary_region")
    writeToHive(spark, step_street, Seq("inc_day"), "dm_gis_oms.scomm_device_order_summary_street")
    writeToHive(spark, step_community, Seq("inc_day"), "dm_gis_oms.scomm_device_order_summary_community")
    writeToHive(spark, step_village, Seq("inc_day"), "dm_gis_oms.scomm_device_order_summary_village")
    devive_no_dim.unpersist()


    val o_charging_station = spark.sql(
      """
        |select
        |   code,
        |   company_code
        |from dm_gis_oms.scomm_charging_station
        |""".stripMargin)

    val o_property_company = spark.sql(
      """
        |select
        |   company,
        |   company_code,
        |   agent_code
        |from dm_gis_oms.scomm_property_company
        |""".stripMargin)

    val o_property_agent = spark.sql(
      """
        |select
        |   agent,
        |   agent_code
        |from dm_gis_oms.scomm_property_agent
        |""".stripMargin)

    val o_coding_info = spark.sql(
      """
        |select
        |   device_no,
        |   coding_no,
        |   coding_status
        |from dm_gis_oms.scomm_device_coding_info
        |where device_no is not null and trim(device_no) != ''
        |""".stripMargin)

    val o_charging_rule = spark.sql(
      """
        |select
        |   rule_no,
        |   rule_details,
        |   case
        |   when rule_name like '%时长%' and rule_no != 'RULE_202203161957236870' then regexp_replace(split(get_json_object(rule_details, '$.rule_desc'),'，') [0],'。','')
        |   when rule_name like '%功率%' then regexp_replace(regexp_replace(regexp_replace(regexp_replace(split(get_json_object(rule_details, '$.rule_desc'),'。') [1],'，',':'),' ',''),'\n',''),'小时','小时;')
        |   when rule_no = 'RULE_202203161957236870' then '8:00-22:00:0.2元/小时;22:00-8:00:0.1元/小时;'
        |   else '' end as rule_desc
        |from dm_gis_oms.scomm_charging_rule
        |""".stripMargin)
    //厂家平台及设备在线情况
    val simultaneously_status = 'd_status === 1 && 'custom_status === 1

    val device_agent = o_charging_device.alias("o_charging_device")
      .join(o_charging_station.alias("o_charging_station"), expr("o_charging_device.station_code = o_charging_station.code"), "left")
      .join(o_property_company, Seq("company_code"), "left")
      .join(o_property_agent, Seq("agent_code"), "left")
      .join(o_charging_rule, Seq("rule_no"), "left")
      .join(o_device_status, Seq("device_no"), "left")
      .withColumn("yes_total_cnt", when('statistic_date_tm === end_day, 1).otherwise(0))
      .withColumn("yes_part_cnt", when('statistic_date_tm === end_day && simultaneously_status, 1).otherwise(0))
      .withColumn("bef_total_cnt", when('statistic_date_tm === getdaysBefore(end_day, -1, "yyyy-MM-dd"), 1).otherwise(0))
      .withColumn("bef_part_cnt", when('statistic_date_tm === getdaysBefore(end_day, -1, "yyyy-MM-dd") && simultaneously_status, 1).otherwise(0))
      .na.fill("/", Seq("device_location", "device_no"))
      .groupBy("province_name", "city_name", "region", "street", "community", "village", "device_no")
      .agg(
        first("station_name") as "station_name",
        first("device_location") as "device_location",
        first("longitude") as "longitude",
        first("latitude") as "latitude",
        first("device_type") as "device_type",
        first("online_time") as "online_time",
        first("rule_desc") as "rule_details",
        first("socket_number") as "socket_number",
        first("brand") as "brand",
        first("building_supplier") as "building_supplier",
        first("supply_responsible") as "supply_responsible",
        first("supply_responsible_phone") as "supply_responsible_phone",
        first("custom_status") as "custom_status",
        first("d_status") as "d_status",
        first("company") as "company",
        first("agent") as "agent",
        sum("yes_total_cnt") as "yes_total_cnt",
        sum("yes_part_cnt") as "yes_part_cnt",
        sum("bef_total_cnt") as "bef_total_cnt",
        sum("bef_part_cnt") as "bef_part_cnt"
      )
      .withColumn("total_status_yes_flag", when('yes_total_cnt > 0, round('yes_part_cnt / 'yes_total_cnt, 2)).otherwise(0))
      .withColumn("total_status_bef_flag", when('bef_total_cnt > 0, round('bef_part_cnt / 'bef_total_cnt, 2)).otherwise(0))
      .withColumn("custom_status_flag", when('custom_status === 1, "上线")
        .when('custom_status === 2, "锁定")
        .when('custom_status === 3, "下线")
        .otherwise(""))
      .withColumn("d_status_flag", when('d_status === 0, "离线")
        .when('d_status === 1, "在线")
        .otherwise(""))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('device_no, lit(""), lit(""), lit(""), lit(""), lit(""), 'inc_day))
      .select("id", "province_name", "city_name", "region", "street", "community", "village",
        "station_name", "device_location", "longitude", "latitude", "device_no", "device_type", "online_time", "rule_details",
        "socket_number", "brand", "building_supplier",
        "supply_responsible", "supply_responsible_phone",
        "company", "agent", "custom_status_flag", "d_status_flag", "total_status_yes_flag", "total_status_bef_flag", "inc_day")

    writeToHive(spark, device_agent, Seq("inc_day"), "dm_gis_oms.scomm_device_company_agent_dtl")

    o_device_status.unpersist()
    //step3
    //    (charge_start 2021-09-01 14:01:55
    val order_start_date = getdaysBefore(end_day, -10, "yyyy-MM-dd")

    //一段时间内，端口有订单的信息数据
    val o_order_record_step3 = o_order_record.filter('create_time_tm >= order_start_date)
      .withColumnRenamed("charge_no", "device_no")
      .withColumn("order_cnt", lit(1))
      .withColumn("on_order_cnt", when(order_ele_ft, 1).otherwise(0))
      .groupBy("device_no", "coding_no")
      .agg(
        sum("order_cnt") as "order_cnt",
        sum("on_order_cnt") as "on_order_cnt"
      )

    val device_order_cnt = o_charging_device.select("device_no")
      .join(o_coding_info, Seq("device_no"), "left")
      .join(o_order_record_step3, Seq("device_no", "coding_no"), "left")
      .na.fill(0, Seq("order_cnt", "on_order_cnt"))
      .na.fill("/", Seq("coding_no"))
      .withColumn("order_start_date", lit(order_start_date))
      .withColumn("order_end_date", lit(end_day))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt('device_no, 'coding_no, lit(""), lit(""), lit(""), lit(""), 'inc_day))
      .select("id", "device_no", "coding_no", "order_start_date", "order_end_date", "order_cnt", "on_order_cnt", "inc_day")

    writeToHive(spark, device_order_cnt, Seq("inc_day"), "dm_gis_oms.scomm_device_order_on_cnt")

    //step4
    val o_order_record_step4 = o_order_record.withColumnRenamed("charge_no", "device_no")
      .withColumn("order_cnt", lit(1))
      .withColumn("on_order_cnt", when(order_ele_ft, 1).otherwise(0))
      .groupBy("device_no", "coding_no")
      .agg(
        sum("order_cnt") as "order_cnt",
        sum("on_order_cnt") as "on_order_cnt"
      )

    val device_order_coding = o_charging_device
      .select("province_name", "city_name", "region", "street", "community", "village",
        "station_name", "device_location", "online_time", "device_no", "socket_number", "online_time")
      .join(o_coding_info, Seq("device_no"), "left")
      .join(o_order_record_step4, Seq("device_no", "coding_no"), "left")
      .na.fill(0, Seq("order_cnt", "on_order_cnt"))
      .groupBy("device_no", "coding_no")
      .agg(
        first("province_name") as "province_name",
        first("city_name") as "city_name",
        first("region") as "region",
        first("street") as "street",
        first("community") as "community",
        first("village") as "village",
        first("station_name") as "station_name",
        first("device_location") as "device_location",
        first("online_time") as "online_time",
        first("socket_number") as "socket_number",
        first("coding_status") as "coding_status",
        sum("order_cnt") as "order_cnt",
        sum("on_order_cnt") as "on_order_cnt",
        lit(inc_day) as "inc_day"
      )

    val coding_num = o_coding_info.groupBy("device_no")
      .agg(
        count("coding_no") as "total_coding"
      )
    val device_coding_status = device_order_coding
      .join(coding_num, Seq("device_no"))
      .withColumn("coding_status_flag", when('coding_status === 1, "使用中").otherwise("未使用"))
      .withColumn("id", primaryKeyEncrypt('device_no, 'coding_no, lit(""), lit(""), lit(""), lit(""), 'inc_day))
      .na.fill(0, Seq("order_cnt", "on_order_cnt", "coding_status"))
      .na.fill("/", Seq("device_location", "device_no"))
      .select("id", "province_name", "city_name", "region", "street", "community", "village",
        "station_name", "device_location", "device_no", "total_coding", "online_time", "coding_no", "order_cnt", "on_order_cnt", "coding_status_flag", "inc_day")

    writeToHive(spark, device_coding_status, Seq("inc_day"), "dm_gis_oms.scomm_device_coding_status_dtl")
    o_charging_device.unpersist()
    o_order_record.unpersist()
  }

}