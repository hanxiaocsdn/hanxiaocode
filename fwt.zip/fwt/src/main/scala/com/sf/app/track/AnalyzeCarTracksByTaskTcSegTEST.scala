package com.sf.app.track

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder


/**
 * @task_id: 592969
 * @description: 线路规划轨迹源信息
 * @demander: ft80006356 马荣
 * @author 01418539 caojia
 * @date 2022/12/5 9:50
 */
case class DeptCoordTEST(dept: String, coord: String)

case class FixedPathTEST(x1: String, x2: String, x3: String, x4: String, x5: String, x6: String, x7: String, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String)

object AnalyzeCarTracksByTaskTcSegTEST extends DataSourceCommon {
  var envinited = false

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
    val endDate = Util.addDay(checkDate, 1).replaceAll("-", "")
    val buildCitys = ""
    initBills(spark, checkDate, endDate, buildCitys)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def initBills(spark: SparkSession, checkDate: String, endDate: String, buildCitys: String): Unit = {
    val ydayid = checkDate
    initEnv(spark, checkDate)
    System.err.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    System.err.println("即将开始舒华新天地--调度作业单元区域区间车辆轨迹推送T-1数据：" + ydayid)
    System.err.println("当前目录：" + System.getProperty("user.dir"))
    System.err.println("============================================================")
    Util.memTime()

    prepareData(spark, ydayid, step = 0)
    Util.showCost(s"准备轨迹数据【$ydayid】完成")
    try {
      Util.freeMem()
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
    Util.showCost(s"发送轨迹数据【$ydayid】完成")

    if (Util.addDay(checkDate, 1).replaceAll("-", "") < endDate)
      initBills(spark, Util.addDay(checkDate, 1).replaceAll("-", ""), endDate, buildCitys)
  }


  def prepareData(spark: SparkSession, dayid: String, step: Int = 2, moreDays: Boolean = true) = {
    import spark.implicits._
    spark.sql("use dm_gis")
    var sql =
      s"""
         |SELECT unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss') as tmstart,unix_timestamp(t.tmend,'yyyy-MM-dd HH:mm:ss') as tmend,
         |from_unixtime(unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd') as daystart,
         |from_unixtime(unix_timestamp(t.tmend,'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd') as dayend,
         |t.dayid,t.task_id,t.vehicle_serial,t.zone_from,t.zone_to,regexp_replace(t.coor_from,',',';') coor_from,
         |regexp_replace(t.coor_to,',',';') coor_to
         |FROM tt_vehicle_task_pass_zone_monitor_tc_seq t where t.vehicle_serial is not null and t.dayid between '$dayid' and '${Util.addDay(dayid, step).replaceAll("-", "")}' and unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss') is not null and unix_timestamp(t.tmend,'yyyy-MM-dd HH:mm:ss') is not null ORDER BY dayid""".stripMargin

    println(sql)
    val taskAll = spark.sql(sql).na.fill("").repartition(Util.defaultPartitionSize / 2).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    val tt_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq_test limit 1""").schema.map(_.name).map(col)
    val tt_1 = taskAll.withColumn("inc_day", lit(dayid)).select(tt_cols: _*)
    writeToHive(spark, tt_1, Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq_test")
    taskAll.show(false)
    val taskCnt = taskAll.count()
    if (taskCnt == 0) {
      println("任务初始化记录为空")
    }
    taskAll.createOrReplaceTempView("tmp_tt_vehicle_task_pass_zone_monitor_tc_seq")

    sql = "select min(dayid),max(dayid) from tmp_tt_vehicle_task_pass_zone_monitor_tc_seq"

    if (taskCnt > 0) {
      val dayrange = spark.sql(sql).take(1)(0)
      val daymin = dayrange.getString(0)
      val daymax = dayrange.getString(1)

      val delta = if (moreDays) Util.daysDiff(daymin, daymax).toInt else 0
      (0 to delta).foreach(i => {
        val day = Util.addDay(daymin, i).replaceAll("-", "")
        val task = taskAll.filter(_.getString(4) == day).rdd.collect().sortBy(d => {
          d.getLong(1) - d.getLong(0)
        })
        val dayid = day
        var sql = ""
        val taskCnt = task.length
        val btask = spark.sparkContext.broadcast(task)
        if (taskCnt > 0) {
          val dateFrom = task.map(_.getString(2).toInt).min
          val dateTo = task.map(_.getString(3).toInt).max
          Util.memTime()
          spark.sql("set spark.sql.shuffle.partitions=" + Util.defaultPartitionSize * 2)
          sql = s"select distinct regexp_replace(un,',','') as un,ak,tm,zx,zy,ac,tp,sp,be from dm_gis.esg_gis_loc_trajectory where inc_day between '$dateFrom' and '$dateTo' and tm is not null and tm<>'' and zx<>0 and zy<>0 and regexp_replace(un,',','') in (SELECT distinct regexp_replace(t.vehicle_serial,',','') as un FROM tt_vehicle_task_pass_zone_monitor_tc_seq t where t.vehicle_serial is not null and t.dayid='$dayid')"

          val fixedPath = spark.sql(sql).na.fill("").rdd.groupBy(_.getString(0)).map(d => {
            val un = d._1
            val paths = d._2
            val fixedPath = btask.value.filter(t => {
              t.getString(6) == un
            }).map(d => {
              val tms = d.getLong(0)
              val tme = d.getLong(1)
              val taskid = d.getString(5)
              val un = d.getString(6)
              val zoneFrom = d.getString(7)
              val zoneTo = d.getString(8)
              val coorFrom = d.getString(9)
              val coorTo = d.getString(10)
              val rst = paths.filter(path => {
                val tm = path.getString(2).toLong
                tm >= tms - 300 && tm <= tme + 300 //轨迹起止时间各向两端延时5分钟
              }).map(path => {
                s"$taskid,$zoneFrom,$zoneTo,$coorFrom,$coorTo,$tms,$tme,${path.mkString(",")}"
              })
              rst
            }).flatMap(d => d)
            fixedPath
          }).flatMap(d => d)

          val fixedPath_df = fixedPath.map(_.split(",")).map(row => {
            var taskid, zoneFrom, zoneTo, coorFrom, coorTo, tms, tme, un, ak, tm, zx, zy, ac, tp, sp, be = ""
            try {
              taskid = row(0)
              zoneFrom = row(1)
              zoneTo = row(2)
              coorFrom = row(3)
              coorTo = row(4)
              tms = row(5)
              tme = row(6)
              un = row(7)
              ak = row(8)
              tm = row(9)
              zx = row(10)
              zy = row(11)
              ac = row(12)
              tp = row(13)
              sp = row(14)
              be = row(15)
            } catch {
              case e: Exception => logger.error("数据中存在空值" + e.getMessage)
            }
            FixedPathTEST(taskid, zoneFrom, zoneTo, coorFrom, coorTo, tms, tme, un, ak, tm, zx, zy, ac, tp, sp, be)
          }).toDF("task_id", "zone_from", "zone_to", "coor_from", "coor_to", "tm_from", "tm_to", "un", "ak", "tm", "zx", "zy", "ac", "tp", "sp", "be")
            .withColumn("inc_day", lit(dayid))
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          writeToHive(spark, fixedPath_df, Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_test")
          Util.showCost(s"【$dateFrom - $dateTo】 done")
        }
        btask.destroy()
      })
    } else {
      println("【ERROR】taskAll 初始化记录为空")
    }
    taskAll.unpersist()
  }

  def initEnv(spark: SparkSession, checkDate: String): Unit = {
    if (envinited)
      return
    envinited = true
    spark.sql("use dm_gis")

    import spark.implicits._
    val dayid = Util.addDay(checkDate, -2).replaceAll("-", "") //20220722
    spark.sql(s"select code, create_tm,lat,lng from dm_gis.polygon_all where inc_day='$dayid' and level in (4,5) and state in (1,3) and type = 1 and lng is not null and lng<>'' and lat is not null and lat<>'' and code is not null and code<>''")
      .map(d => {
        val dept = d.getString(0)
        val x = d.getString(3)
        val y = d.getString(2)
        DeptCoordTEST(dept, x + "," + y)
      }).toDF().createOrReplaceTempView("deptcoords")

    var sql = s"""SELECT t.task_id,t.actual_pass_zone_code,case when t.pass_zone_coordinate='' or t.pass_zone_coordinate is null then q.coord else t.pass_zone_coordinate end as pass_zone_coordinate,t.sort_num,t.actual_depart_tm,t.actual_arrive_tm,t.last_update_tm from ods_russtask.tt_vehicle_task_pass_zone_monitor t left join deptcoords q on t.actual_pass_zone_code=q.dept WHERE t.actual_depart_tm IS NOT NULL or t.actual_arrive_tm IS NOT NULL"""
    sql = s"""select t.task_id,t.actual_pass_zone_code,t.pass_zone_coordinate,t.sort_num,t.actual_depart_tm,t.actual_arrive_tm from (select *,row_number() over (partition by task_id,actual_pass_zone_code order by last_update_tm desc) num2 from ($sql) q) t where t.num2=1 """
    sql = s"""select distinct a.task_id,a.actual_pass_zone_code as zone_from,b.actual_pass_zone_code as zone_to,a.pass_zone_coordinate as coor_from,b.pass_zone_coordinate as coor_to,a.sort_num,a.actual_depart_tm as tmstart,b.actual_arrive_tm as tmend from ($sql) a left join ($sql) b on a.task_id=b.task_id and a.sort_num+1 = b.sort_num WHERE b.actual_pass_zone_code IS NOT NULL and a.actual_depart_tm is not null and b.actual_arrive_tm is not null order by tmstart"""
    sql = s"""SELECT distinct from_unixtime(unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd') as dayid,REGEXP_replace(q.vehicle_serial,'\\'','') as vehicle_serial,q.transoport_level,q.capacity_load,q.actual_capacity_load,q.state,q.to_ground,t.* FROM ($sql) t LEFT JOIN ods_russtask.tt_vehicle_task_monitor q on t.task_id=q.task_id where datediff(t.tmend,t.tmstart)<=2 ORDER BY dayid """

    System.err.println("【initEnv】")
    System.err.println(sql)
    spark.sql(sql).createOrReplaceTempView("tt_vehicle_task_pass_zone_monitor_tc_seq")

    sql = "select * from tt_vehicle_task_pass_zone_monitor_tc_seq"
    println("[initEnv()] " + sql)
    spark.sql(sql).show(false)
  }
}
