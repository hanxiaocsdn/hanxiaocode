package com.sf.app.track

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder

import java.io.File


/**
 * @task_id: 577306
 * @description: 线路规划轨迹源信息 -- 补充部分轨迹信息
 * @demander: ft80006356 马荣
 * @author 01418539 caojia
 * @date 2022/12/5 9:50
 */
case class FixedPathBAKT(x1: String, x2: String, x3: String, x4: String, x5: String, x6: Long, x7: Long, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String)

object AnalyzeCarTracksByTaskTcSegCompTEST extends DataSourceCommon {
  var envinited = false

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
    initBills(spark, checkDate)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def initBills(spark: SparkSession, checkDate: String): Unit = {
    System.err.println(">>>>>>>>>>>>>>>>>>>即将开始舒华新天地--调度作业单元区域区间车辆轨迹推送：" + checkDate)
    Util.memTime()
    val ydayid = checkDate
    prepareDataBak(spark, ydayid, step = 0)
    Util.showCost(s"准备轨迹数据【$ydayid】完成")
    try {
      Util.freeMem()
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
  }

  def prepareDataBak(spark: SparkSession, dayid: String, step: Int = 2, moreDays: Boolean = true) = {
    import spark.implicits._
    spark.sql("use dm_gis")
    var sql = ""
    //此处为新增补充逻辑
    val taskAll = mergeLogic(spark, dayid).na.fill("").repartition(Util.defaultPartitionSize / 2).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val tt_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq_comp_test limit 0""").schema.map(_.name).map(col)
    val tt_1 = taskAll.withColumn("inc_day", lit(dayid)).select(tt_cols: _*)
    writeToHive(spark, tt_1.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq_comp_test")
    taskAll.show(false)
    val taskCnt = taskAll.count()
    if (taskCnt == 0) {
      println("任务初始化记录为空")
    }
    taskAll.createOrReplaceTempView("tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak")

    sql = "select min(dayid),max(dayid) from tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak"
    //获取task_id 和line_code的映射信息
    val lc_df = getLineCode(spark, dayid)
    if (taskCnt > 0) {
      val dayrange = spark.sql(sql).take(1)(0)
      val daymin = dayrange.getString(0)
      val daymax = dayrange.getString(1)

      val delta = if (moreDays) Util.daysDiff(daymin, daymax).toInt else 0
      (0 to delta).foreach(i => {
        val day = Util.addDay(daymin, i).replaceAll("-", "")
        val task = taskAll.filter(_.getString(4) == day).rdd.collect().sortBy(d => {
          (try {
            d.getString(1).toLong
          } catch {
            case e: Exception => logger.error(e.getMessage)
              0l
          }) - (try {
            d.getString(0).toLong
          } catch {
            case e: Exception => logger.error(e.getMessage)
              0l
          })
        })
        val dayid = day

        val taskCnt = task.length
        val btask = spark.sparkContext.broadcast(task)
        if (taskCnt > 0) {
          var dateFrom = 0
          try {
            dateFrom = task.map(_.getString(2).toInt).min
          } catch {
            case e: Exception => logger.error("------" + e.getMessage)
          }
          var dateTo = 0
          try {
            dateTo = task.map(_.getString(3).toInt).max
          } catch {
            case e: Exception => logger.error("------" + e.getMessage)
          }
          Util.memTime()
          spark.sql("set spark.sql.shuffle.partitions=" + Util.defaultPartitionSize * 2)
          //获取车牌 和 设备映射关系表
          val o_un = spark.sql(s"""SELECT distinct regexp_replace(t.vehicle_serial,',','') as un FROM tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak t where t.vehicle_serial is not null and t.dayid='$dayid'""")
            .select("un").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")

          val o_gps_track = spark.sql(
            s"""
               |select un,ak,ac,tp,tm,zx,zy,sp,be,'1' flag,inc_day
               |from dm_gis.esg_gis_loc_trajectory
               |where inc_day >= '$dateFrom' and inc_day <='$dateTo'
               |      and un in ($o_un)
               |      and tm is not null and trim(tm) != ''
               |      and zx is not null and trim(zx) != ''
               |      and zy is not null and trim(zy) != ''
               |      and sp is not null and trim(sp) != ''
               |      and be is not null and trim(be) != ''
               |""".stripMargin)
            .withColumn("num", row_number().over(Window.partitionBy("un", "tm", "inc_day").orderBy("un")))
            .filter('num === 1).drop("num", "inc_day")

          //t2 day: 7913万6914 45G tEXT 全国车行路径规划GPS轨迹原始数据表 特征抽取纠偏数据源
          val o_navi_track = spark.sql(
            s"""
               |select carno un,ak,ac,tp,tm,x zx,y zy,sp,be,'2' flag,inc_day
               |from dm_gis.gis_rss_eta_navi_track_flatmap
               |where inc_day >= '$dateFrom' and inc_day <='$dateTo'
               |      and carno in ($o_un)
               |      and ak in ('305','306','333','335','334','332')
               |      and tag = '1'
               |      and tm is not null and trim(tm) != ''
               |      and x is not null and trim(x) != ''
               |      and y is not null and trim(y) != ''
               |      and x<>0 and y<>0
               |      and sp is not null and trim(sp) != ''
               |      and be is not null and trim(be) != ''
               |""".stripMargin)
            .withColumn("num", row_number().over(Window.partitionBy("un", "tm", "inc_day").orderBy("un")))
            .filter('num === 1).drop("num", "inc_day")

          val step1_track = o_navi_track.union(o_gps_track)
            .persist(StorageLevel.MEMORY_AND_DISK_SER)
          val step2_track = step1_track.select("un", "tm", "flag")
            .groupBy("un", "tm").agg(min('flag) as "flag")

          val flatmap_track_df = step1_track.join(step2_track, Seq("un", "tm", "flag")).select("un", "ak", "tm", "zx", "zy", "ac", "tp", "sp", "be")

          val fixedPath = flatmap_track_df.na.fill("").rdd.groupBy(_.getString(0)).map(d => {
            val un = d._1
            val paths = d._2
            val fixedPath = btask.value.filter(t => {
              t.getString(6) == un
            }).map(d => {
              val tms = d.getString(0).toLong
              val tme = d.getString(1).toLong
              val taskid = d.getString(5)
              val un = d.getString(6)
              val zoneFrom = d.getString(7)
              val zoneTo = d.getString(8)
              val coorFrom = d.getString(9)
              val coorTo = d.getString(10)
              val rst = paths.filter(path => {
                val tm = path.getString(2).toLong
                tm >= tms - 300 && tm <= tme + 300 //轨迹起止时间各向两端延时5分钟
              }).map(path => {
                s"$taskid,$zoneFrom,$zoneTo,$coorFrom,$coorTo,$tms,$tme,${path.mkString(",")}"
              })
              rst
            }).flatMap(d => d)
            fixedPath
          }).flatMap(d => d)

          val fixedPath_df = fixedPath.map(_.split(",")).map(row => {
            var taskid, zoneFrom, zoneTo, coorFrom, coorTo, un, ak, tm, zx, zy, ac, tp, sp, be = ""
            var tms, tme = 0l
            try {
              taskid = row(0)
              zoneFrom = row(1)
              zoneTo = row(2)
              coorFrom = row(3)
              coorTo = row(4)
              tms = row(5).toLong
              tme = row(6).toLong
              un = row(7)
              ak = row(8)
              tm = row(9)
              zx = row(10)
              zy = row(11)
              ac = row(12)
              tp = row(13)
              sp = row(14)
              be = row(15)
            } catch {
              case e: Exception => logger.error("数据中存在空值" + e.getMessage)
            }
            FixedPathBAKT(taskid, zoneFrom, zoneTo, coorFrom, coorTo, tms, tme, un, ak, tm, zx, zy, ac, tp, sp, be)
          }).toDF("task_id", "zone_from", "zone_to", "coor_from", "coor_to", "tm_from", "tm_to", "un", "ak", "tm", "zx", "zy", "ac", "tp", "sp", "be")
            .withColumn("inc_day", lit(dayid))
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          //按照已有结果表字段排序
          val res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_test limit 0""").schema.map(_.name).map(col)
          val res_comp_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_comp_test limit 0""").schema.map(_.name).map(col)
          val merge_res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge_test limit 0""").schema.map(_.name).map(col)
          //根据 车牌 和 ak 筛选出 同个车牌 轨迹较多的车牌信息
          val fixedPath_df_ft = fixedPath_df.select("un", "ak", "tm_from", "tm_to")
            .withColumn("cnt", lit(1))
            .groupBy("un", "tm_from", "tm_to", "ak")
            .agg(
              sum("cnt") as "ak_cnt"
            )
            .withColumn("num", row_number().over(Window.partitionBy("un", "tm_from", "tm_to").orderBy(desc("ak_cnt"))))
            .filter('num === 1).select("un", "ak", "tm_from", "tm_to")
          //筛选完后的数据
          val fixedPath_df_res = fixedPath_df.join(fixedPath_df_ft, Seq("un", "tm_from", "tm_to", "ak"))
            .select(res_comp_cols: _*)
          val org_catch = spark.sql(s"""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_test where inc_day = '$dayid'""").select(res_cols: _*)

          val all_carpath_df = fixedPath_df_res.withColumn("org_flag", lit("result")).union(org_catch.withColumn("org_flag", lit("monitor")))
            .join(lc_df, Seq("task_id", "inc_day"), "left")
            .select(merge_res_cols: _*)
          writeToHive(spark, fixedPath_df_res.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_comp_test")
          writeToHive(spark, all_carpath_df.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge_test")
          Util.showCost(s"【$dateFrom - $dateTo】 done")
          step1_track.unpersist()
          fixedPath_df.unpersist()
          lc_df.unpersist()
        }
        btask.destroy()
      })
      makesegPathBakTest(spark, dayid)
    } else {
      println("【ERROR】taskAll 初始化记录为空")
    }

    taskAll.unpersist()
  }

  /**
   * 获取line code线路编码信息
   *
   * @param spark
   * @param dayid
   * @return
   */
  def getLineCode(spark: SparkSession, dayid: String): DataFrame = {
    val o_monitor_lc_df = spark.sql(
      s"""select task_id,line_code,inc_day from ods_russtask.tt_vehicle_task_monitor
         |where inc_day='$dayid'
         |      and task_id is not null and trim(task_id) !=''
         |      and line_code is not null and trim(line_code) !=''
         |      group by task_id,line_code,inc_day
         """.stripMargin)
    val o_result_lc_df = spark.sql(
      s"""
         |select task_id,line_code,inc_day from dm_gis.gis_navi_eta_result1
         |where inc_day='$dayid'
         |      and task_id is not null and trim(task_id) !=''
         |      and line_code is not null and trim(line_code) !=''
         |      group by task_id,line_code,inc_day
         |""".stripMargin)

    val task_code = o_monitor_lc_df.union(o_result_lc_df).groupBy("task_id", "line_code", "inc_day").agg(lit("1"))
      .select("task_id", "line_code", "inc_day").persist(StorageLevel.MEMORY_AND_DISK_SER)
    task_code
  }

  /**
   * 测试数据落盘 ftp 方法，暂时不用
   *
   * @param spark
   * @param dayid
   */
  def makesegPathBakTest(spark: SparkSession, dayid: String): Unit = {
    val hdfsPath = s"/hive/warehouse/dm/dm_gis/tt_vehicle_task_pass_zone_monitor_carpath_merge_test_${dayid}"
    Util.hdfsRM(hdfsPath)
    val sql_seg = s"select task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,zx,zy,ac,tp,sp,be from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge_test t where t.inc_day='$dayid' GROUP by task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,zx,zy,ac,tp,sp,be"
    spark.sql(sql_seg).rdd.map(_.mkString(",")).saveAsTextFile(hdfsPath)
    val file = s"./merge_test_track_path_tcseg_$dayid.csv"
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"hdfs dfs -getmerge $hdfsPath $file")
    Util.runShellCmd(s"ls -l $file")
    Util.runShellCmd(s"tar czf $file.tgz $file")
    Util.runShellCmd(s"ls -l $file.tgz")
    Util.ftpUpload(new File(file + ".tgz").getAbsolutePath, ftpPath = "/GIS-ASS-AOS/01366807/wuhan_track_path")
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"./rm -rf $file.tgz")
  }

  /**
   * 此处逻辑变换
   *
   * @param spark
   * @param taskAll
   * @param dayid
   * @return
   */
  def mergeLogic(spark: SparkSession, checkDate: String): DataFrame = {
    import spark.implicits._
    val day_bef = Util.addDay(checkDate, -1).replaceAll("-", "")
    val day_aft = Util.addDay(checkDate, 1).replaceAll("-", "")
    //"task_id", "vehicle_serial", "tmstart", "tmend", "daystart", "dayend", "zone_from", "zone_to", "coor_from", "coor_to", "dayid", "inc_day"
    val result_coords_df = replaceMonitorSeq(spark, checkDate)
    val carpath_df = spark.sql(
      s"""
         |SELECT task_id,zone_from,zone_to,tm_from,tm_to
         |FROM dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_test
         |WHERE  inc_day between '$day_bef' and '$day_aft'
         |group by task_id,zone_from,zone_to,tm_from,tm_to
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val union_cols = Seq(col("tmstart"), col("tmend"), col("daystart"), col("dayend"), col("dayid"),
      col("task_id"), col("vehicle_serial"), col("zone_from"), col("zone_to"), col("coor_from"), col("coor_to"))
    //result_coords_df 有  carpath_df  无
    val p1_merge_df = result_coords_df.join(carpath_df.select("task_id"), Seq("task_id"), "left_anti")
      .select(union_cols: _*)

    val filter_cond = when('tm_from.cast("long") >= 'tmend.cast("long") || 'tmstart.cast("long") >= 'tm_to.cast("long"), true).otherwise(false)

    val p2_merge_df = result_coords_df.join(carpath_df.select("task_id", "tm_from", "tm_to"), Seq("task_id"))
      .withColumn("flag", filter_cond)
      .filter('flag === true) //保留无时间交集的task_id
      .select(union_cols: _*)

    p1_merge_df.union(p2_merge_df)
      .withColumn("num", row_number().over(Window.partitionBy(union_cols: _*).orderBy("task_id")))
      .filter('num === 1)
      .select(union_cols: _*)
  }

  def replaceMonitorSeq(spark: SparkSession, checkDate: String): DataFrame = {
    import spark.implicits._
    val dayid = Util.addDay(checkDate, -2).replaceAll("-", "")
    //navi_starttime 1654947040004
    val result1_df = spark.sql(
      s"""
         |select id,task_id,vehicle vehicle_serial,
         |       cast(navi_starttime/1000 as bigint) tmstart,
         |       cast(navi_endtime/1000 as bigint) tmend,
         |       substring(from_unixtime(cast(navi_starttime/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),0,10) as daystart,
         |       substring(from_unixtime(cast(navi_endtime/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),0,10) as dayend,
         |       inc_day dayid,
         |       concat_ws(';',x1,y1) coor_from,
         |       concat_ws(';',x2,y2) coor_to,
         |       inc_day
         |from dm_gis.gis_navi_eta_result1
         |where
         |   req_type = 'top3'
         |   and inc_day = '$checkDate'
         |   and cast(distance as double) > 1000
         |   --and strategy2 not in ('20','21','22')
         |   --and start_type != '1'
         |""".stripMargin)
      .withColumn("tmstart", 'tmstart.cast("string"))
      .withColumn("tmend", 'tmend.cast("string"))
      .withColumn("daystart", regexp_replace('daystart, "-", "").cast("string"))
      .withColumn("dayend", regexp_replace('dayend, "-", "").cast("string"))

    val result2_df = spark.sql(
      s"""
         |select id,src_deptcode zone_from,dest_deptcode zone_to,inc_day
         |from dm_gis.gis_navi_eta_result2
         |where
         |  req_type = 'top3'
         |  and inc_day = '$checkDate'
         |  and cast(navi_distance as double) > 1000
         |  and cast(trackstart_distance as double) < 1000
         |  and cast(trackend_distance as double) < 1000
         |""".stripMargin)

    val source_p2_df = result1_df.join(result2_df, Seq("id", "inc_day"))
      .select("task_id", "vehicle_serial", "tmstart", "tmend", "daystart", "dayend", "zone_from", "zone_to", "coor_from", "coor_to", "dayid", "inc_day")
    source_p2_df
  }

}
