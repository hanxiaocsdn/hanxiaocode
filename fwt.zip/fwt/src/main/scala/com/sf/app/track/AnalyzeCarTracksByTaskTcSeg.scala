package com.sf.app.track

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{asc, broadcast, col, lit, row_number}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.tranTstampToTime
import utils.SparkBuilder

import java.io.File
import java.net.URLEncoder
import java.util.Properties


//任务ID:461997

case class DeptCoord(dept: String, coord: String)

case class FixedPath(x1: String, x2: String, x3: String, x4: String, x5: String, x6: String, x7: String, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String, x17: String)

object AnalyzeCarTracksByTaskTcSeg extends DataSourceCommon {

  var envinited = false

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
    val endDate = Util.addDay(checkDate, 1).replaceAll("-", "")

    val buildCitys = ""
    initBills(spark, checkDate, endDate, buildCitys)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def initBills(spark: SparkSession, checkDate: String, endDate: String, buildCitys: String): Unit = {
    //7天前 的数据
    val dayid = Util.addDay(checkDate.replaceAll("-", ""), -7).replaceAll("-", "") //20220717

    initEnv(spark, checkDate)

    System.err.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
    System.err.println("即将开始舒华新天地--调度作业单元区域区间车辆轨迹推送：" + dayid)
    System.err.println("当前目录：" + System.getProperty("user.dir"))
    System.err.println("============================================================")
    Util.memTime()

    val ydayid = checkDate
    prepareData(spark, ydayid, step = 0)
    Util.showCost(s"准备轨迹数据【$ydayid】完成")
    try {
      Util.freeMem()
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
    //    postToWuhan(spark, ydayid)
    Util.showCost(s"发送轨迹数据【$ydayid】完成")

    //重新加工 7天前 的数据加工 并 推送
    //    prepareData(spark, dayid)
    //    sendPath(spark, dayid)
    //    val dayid_15 = Util.addDay(dayid, -15).replaceAll("-", "")
    //    val hdfsPath = "hdfs://sfbdp1/hive/warehouse/dm/dm_gis/tt_vehicle_task_pass_zone_monitor_carpath_t/inc_day=" + dayid_15
    //    Util.dropPartition("dm_gis", "tt_vehicle_task_pass_zone_monitor_carpath_t", s"inc_day='$dayid_15'", hdfsPath)

    if (Util.addDay(checkDate, 1).replaceAll("-", "") < endDate)
      initBills(spark, Util.addDay(checkDate, 1).replaceAll("-", ""), endDate, buildCitys)
  }

  def makesegPath(spark: SparkSession, dayid: String): Unit = {
    val hdfsPath = "/hive/warehouse/dm/dm_gis/tt_vehicle_task_pass_zone_monitor_carpath_tmp"
    Util.hdfsRM(hdfsPath)
    val sql_seg = s"select task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,zx,zy,ac,tp,sp,be from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge t where t.inc_day='$dayid' GROUP by task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,zx,zy,ac,tp,sp,be"
    spark.sql(sql_seg).rdd.map(_.mkString(",")).saveAsTextFile(hdfsPath)
    val file = s"./track_path_tcseg_$dayid.csv"
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"hdfs dfs -getmerge $hdfsPath $file")
    Util.runShellCmd(s"ls -l $file")
    Util.runShellCmd(s"tar czf $file.tgz $file")
    Util.runShellCmd(s"ls -l $file.tgz")
    Util.ftpUpload(new File(file + ".tgz").getAbsolutePath, ftpPath = "/GIS-ASS-AOS/01366807/wuhan_track_path")
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"./rm -rf $file.tgz")
  }

  def prepareData(spark: SparkSession, dayid: String, step: Int = 2, moreDays: Boolean = true) = {
    import spark.implicits._
    spark.sql("use dm_gis")
    var sql =
      s"""
         |SELECT unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss') as tmstart,unix_timestamp(t.tmend,'yyyy-MM-dd HH:mm:ss') as tmend,
         |from_unixtime(unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd') as daystart,
         |from_unixtime(unix_timestamp(t.tmend,'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd') as dayend,
         |t.dayid,t.task_id,t.vehicle_serial,t.zone_from,t.zone_to,regexp_replace(t.coor_from,',',';') coor_from,
         |regexp_replace(t.coor_to,',',';') coor_to
         |FROM tt_vehicle_task_pass_zone_monitor_tc_seq t where t.vehicle_serial is not null and t.dayid between '$dayid' and '${Util.addDay(dayid, step).replaceAll("-", "")}' and unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss') is not null and unix_timestamp(t.tmend,'yyyy-MM-dd HH:mm:ss') is not null ORDER BY dayid""".stripMargin

    println(sql)
    val taskAll = spark.sql(sql).na.fill("").repartition(Util.defaultPartitionSize / 2).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    val tt_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq limit 1""").schema.map(_.name).map(col)
    val tt_1 = taskAll.withColumn("inc_day", lit(dayid)).select(tt_cols: _*)
    writeToHive(spark, tt_1, Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq")
    taskAll.show(false)
    val taskCnt = taskAll.count()
    if (taskCnt == 0) {
      println("任务初始化记录为空")
    }
    taskAll.createOrReplaceTempView("tmp_tt_vehicle_task_pass_zone_monitor_tc_seq")

    sql = "select min(dayid),max(dayid) from tmp_tt_vehicle_task_pass_zone_monitor_tc_seq"

    if (taskCnt > 0) {
      val dayrange = spark.sql(sql).take(1)(0)
      val daymin = dayrange.getString(0)
      val daymax = dayrange.getString(1)

      val delta = if (moreDays) Util.daysDiff(daymin, daymax).toInt else 0
      (0 to delta).foreach(i => {
        val day = Util.addDay(daymin, i).replaceAll("-", "")
        val task = taskAll.filter(_.getString(4) == day).rdd.collect().sortBy(d => {
          d.getLong(1) - d.getLong(0)
        })
        val dayid = day
        var sql = ""
        val taskCnt = task.length
        val btask = spark.sparkContext.broadcast(task)
        if (taskCnt > 0) {
          val dateFrom = task.map(_.getString(2).toInt).min
          val dateTo = task.map(_.getString(3).toInt).max
          Util.memTime()
          spark.sql("set spark.sql.shuffle.partitions=" + Util.defaultPartitionSize * 2)
          sql = s"select distinct regexp_replace(un,',','') as un,ak,tm,zx,zy,ac,tp,sp,be,sc from dm_gis.esg_gis_loc_trajectory where inc_day between '$dateFrom' and '$dateTo' and tm is not null and tm<>'' and zx<>0 and zy<>0 and regexp_replace(un,',','') in (SELECT distinct regexp_replace(t.vehicle_serial,',','') as un FROM tt_vehicle_task_pass_zone_monitor_tc_seq t where t.vehicle_serial is not null and t.dayid='$dayid')"

          val fixedPath = spark.sql(sql).na.fill("").rdd.groupBy(_.getString(0)).map(d => {
            val un = d._1
            val paths = d._2
            val fixedPath = btask.value.filter(t => {
              t.getString(6) == un
            }).map(d => {
              val tms = d.getLong(0)
              val tme = d.getLong(1)
              val taskid = d.getString(5)
              val un = d.getString(6)
              val zoneFrom = d.getString(7)
              val zoneTo = d.getString(8)
              val coorFrom = d.getString(9)
              val coorTo = d.getString(10)
              val rst = paths.filter(path => {
                val tm = path.getString(2).toLong
                tm >= tms - 300 && tm <= tme + 300 //轨迹起止时间各向两端延时5分钟
              }).map(path => {
                s"$taskid,$zoneFrom,$zoneTo,$coorFrom,$coorTo,$tms,$tme,${path.mkString(",")}"
              })
              rst
            }).flatMap(d => d)
            fixedPath
          }).flatMap(d => d)

          val fixedPath_df = fixedPath.map(_.split(",")).map(row => {
            var taskid, zoneFrom, tms, tme, zoneTo, coorFrom, coorTo, un, ak, tm, zx, zy, ac, tp, sp, be, sc = ""
            try {
              taskid = row(0)
              zoneFrom = row(1)
              zoneTo = row(2)
              coorFrom = row(3)
              coorTo = row(4)
              tms = row(5)
              tme = row(6)
              un = row(7)
              ak = row(8)
              tm = row(9)
              zx = row(10)
              zy = row(11)
              ac = row(12)
              tp = row(13)
              sp = row(14)
              be = row(15)
              sc = row(16)
            } catch {
              case e: Exception => logger.error("数据中存在空值")
            }
            FixedPath(taskid, zoneFrom, zoneTo, coorFrom, coorTo, tms, tme, un, ak, tm, zx, zy, ac, tp, sp, be, sc)
          }).toDF("task_id", "zone_from", "zone_to", "coor_from", "coor_to", "tm_from", "tm_to", "un", "ak", "tm", "zx", "zy", "ac", "tp", "sp", "be", "sc")
            .withColumn("inc_day", lit(dayid))
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          val res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath limit 1""").schema.map(_.name).map(col)

          val select_sc = fixedPath_df.select("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un", "tm", "sc")
            .withColumn("num", row_number().over(Window.partitionBy("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un").orderBy(asc("tm"))))
            .filter("num=1").drop("tm", "num")
          val res_df = fixedPath_df.join(broadcast(select_sc), Seq("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un", "sc"))
            .select(res_cols: _*)
            .persist(StorageLevel.MEMORY_AND_DISK_SER)
          writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath")
          Util.showCost(s"【$dateFrom - $dateTo】 done")
        }
        btask.destroy()
      })
      //      makesegPath(spark, dayid)
    } else {
      println("【ERROR】taskAll 初始化记录为空")
    }
    taskAll.unpersist()
  }

  def postToWuhan(spark: SparkSession, dayid: String, doPost: Boolean = true): Unit = {
    //增加推送轨迹到武汉功能
    val hdfsPath = "/hive/warehouse/dm/dm_gis/tt_vehicle_task_pass_zone_monitor_carpath_tmp"
    Util.hdfsRM(hdfsPath)
    var sql_org = s"select '' as task_id,'' as zone_from,'' as zone_to,'' as coor_from,'' as coor_to,'' as tm_from,'' as tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,zx,zy,ac,tp,sp,be from dm_gis.esg_gis_loc_trajectory t where t.inc_day='$dayid' and ak<>300 and zx>0 and zy>0 and length(un)<=16 and un regexp '[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1,2}' GROUP by un,ak,zx,zy,ac,tp,sp,be"

    if (doPost) {
      spark.sql(sql_org).rdd.map(_.mkString(",")).saveAsTextFile(hdfsPath)
      val file = s"./track_path_$dayid.csv"
      Util.runShellCmd(s"hdfs dfs -getmerge $hdfsPath $file")
      Util.runShellCmd(s"ls -l $file")
      Util.runShellCmd(s"tar czf track_path_$dayid.csv.tgz track_path_$dayid.csv")
      Util.runShellCmd(s"ls -l $file.tgz")
      Util.ftpUpload(new File(file + ".tgz").getAbsolutePath, ftpPath = "/GIS-ASS-AOS/01366807/wuhan_track_path")
      var url = s"http://10.119.72.205:8083/buildByToken/buildWithParameters?job=moveDataFromFtp_208&token=74b4ae32780f8ab5e9b383945be09d51&ftp_path=${URLEncoder.encode("/GIS-ASS-AOS/01366807/wuhan_track_path/", "utf8")}&file_name=track_path_$dayid.csv.tgz&des_path=${URLEncoder.encode("/app/wuhan_track_path/", "utf8")}"
      var rst = Util.tryGet(url, 3)
      System.out.println(rst)
      Util.runShellCmd(s"./rm -r -f $file*")
      Util.hdfsRM(hdfsPath)
      //Util.ftpDeleteFile(ftpPath = s"/GIS-ASS-AOS/01366807/wuhan_track_path/track_path_$dayid.csv.tgz")

      //增加输出 ak=200 的全部轨迹
      val sql = s"select distinct * from dm_gis.esg_gis_loc_trajectory t where t.inc_day='$dayid' and ak = 200 "
      Util.sql2ftp(spark, sql, "", s"./track_path_ak200_$dayid.csv", "/GIS-ASS-AOS/01366807/wuhan_track_path", ",")
      url = s"http://10.119.72.205:8083/buildByToken/buildWithParameters?job=moveDataFromFtp_208&token=74b4ae32780f8ab5e9b383945be09d51&ftp_path=${URLEncoder.encode("/GIS-ASS-AOS/01366807/wuhan_track_path/", "utf8")}&file_name=track_path_ak200_$dayid.csv&des_path=${URLEncoder.encode("/app/wuhan_track_path/", "utf8")}"
      rst = Util.tryGet(url, 3)
      System.out.println(rst)
    }
  }

  def initEnv(spark: SparkSession, checkDate: String): Unit = {
    if (envinited)
      return
    envinited = true
    spark.sql("use dm_gis")

    import spark.implicits._
    val dayid = Util.addDay(checkDate, -2).replaceAll("-", "") //20220722
    spark.sql(s"select code, create_tm,lat,lng from dm_gis.polygon_all where inc_day='$dayid' and level in (4,5) and state in (1,3) and type = 1 and lng is not null and lng<>'' and lat is not null and lat<>'' and code is not null and code<>''")
      .map(d => {
        val dept = d.getString(0)
        val x = d.getString(3)
        val y = d.getString(2)
        DeptCoord(dept, x + "," + y)
      }).toDF().createOrReplaceTempView("deptcoords")

    var sql = s"""SELECT t.task_id,t.actual_pass_zone_code,case when t.pass_zone_coordinate='' or t.pass_zone_coordinate is null then q.coord else t.pass_zone_coordinate end as pass_zone_coordinate,t.sort_num,t.actual_depart_tm,t.actual_arrive_tm,t.last_update_tm from ods_russtask.tt_vehicle_task_pass_zone_monitor t left join deptcoords q on t.actual_pass_zone_code=q.dept WHERE t.actual_depart_tm IS NOT NULL or t.actual_arrive_tm IS NOT NULL"""
    sql = s"""select t.task_id,t.actual_pass_zone_code,t.pass_zone_coordinate,t.sort_num,t.actual_depart_tm,t.actual_arrive_tm from (select *,row_number() over (partition by task_id,actual_pass_zone_code order by last_update_tm desc) num2 from ($sql) q) t where t.num2=1 """
    sql = s"""select distinct a.task_id,a.actual_pass_zone_code as zone_from,b.actual_pass_zone_code as zone_to,a.pass_zone_coordinate as coor_from,b.pass_zone_coordinate as coor_to,a.sort_num,a.actual_depart_tm as tmstart,b.actual_arrive_tm as tmend from ($sql) a left join ($sql) b on a.task_id=b.task_id and a.sort_num+1 = b.sort_num WHERE b.actual_pass_zone_code IS NOT NULL and a.actual_depart_tm is not null and b.actual_arrive_tm is not null order by tmstart"""
    sql = s"""SELECT distinct from_unixtime(unix_timestamp(t.tmstart,'yyyy-MM-dd HH:mm:ss'),'yyyyMMdd') as dayid,REGEXP_replace(q.vehicle_serial,'\\'','') as vehicle_serial,q.transoport_level,q.capacity_load,q.actual_capacity_load,q.state,q.to_ground,t.* FROM ($sql) t LEFT JOIN ods_russtask.tt_vehicle_task_monitor q on t.task_id=q.task_id where datediff(t.tmend,t.tmstart)<=2 ORDER BY dayid """

    System.err.println("【initEnv】")
    System.err.println(sql)
    spark.sql(sql).createOrReplaceTempView("tt_vehicle_task_pass_zone_monitor_tc_seq")

    sql = "select * from tt_vehicle_task_pass_zone_monitor_tc_seq"
    println("[initEnv()] " + sql)
    spark.sql(sql).show(false)
  }

  def sendPath(spark: SparkSession, dayid: String) = {
    import spark.implicits._
    var sql = s"""select zone_from,regexp_replace(un,' |,|\\t|\\r|\\n|\\'|\"|\\\\(|\\\\)|\\\\[|\\\\]|\\\\{|\\\\}|\\\\\\\\|(null)|(NULL)','') as un,count(1) as cnt from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge where inc_day>='$dayid' group by zone_from,regexp_replace(un,' |,|\\t|\\r|\\n|\\'|\"|\\\\(|\\\\)|\\\\[|\\\\]|\\\\{|\\\\}|\\\\\\\\|(null)|(NULL)','')"""
    System.err.println(sql)
    val rddUn = spark.sql(sql).rdd.sortBy(_.getString(0)).map(_.getString(1)).distinct().collect()
    val uncnt = rddUn.size
    val batchSize = 1000
    val loopCount = Math.ceil(uncnt.toDouble / batchSize.toDouble).toInt
    var start = 0
    var end = 0
    var invokeCnt = 0l
    var errorCnt = 0l

    for (i <- 0 to loopCount) {
      start = i * batchSize
      end = Math.min((i + 1) * batchSize, uncnt)
      if (start < uncnt) {
        System.err.println("\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        System.err.println("【" + dayid + "】车行用户数：" + uncnt + "\t批量：" + batchSize + "\t迭代数：" + loopCount + "\t批次：" + i + "\t【" + start + " - " + end + "】")
        val uncnd = rddUn.slice(start, end).mkString("'", "','", "'")
        sql = s"""select distinct regexp_replace(un,' |,|\\t|\\r|\\n|\\'|\"|\\\\(|\\\\)|\\\\[|\\\\]|\\\\{|\\\\}|\\\\\\\\|(null)|(NULL)','') as un,zx,zy,ac,tp,tm,ak,'3' as vehicle,sp,be,task_id,zone_from,zone_to,coor_from,coor_to from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge where inc_day='$dayid' and un in($uncnd) and tm is not null and tm<>'' order by zone_from"""

        //todo remove zip and limit
        val pathRdd = spark.sql(sql).rdd.groupBy(d => d.getString(0)).partitionBy(new HashKeyPartitioner(Util.defaultPartitionSize * 4)).persist() //.zipWithIndex().filter(_._2<500).map(_._1)
        val pcnt = pathRdd.count()
        Util.showCost("准备轨迹用户数：" + pcnt + "，耗时：")
        val properties = Util.properties
        val resultRDD = pathRdd.map(i => {
          val un = i._1
          //按taskid,zonefrom,zoneto，及起终点网点坐标切割轨迹

          i._2.groupBy(d => d.getString(10) + "," + d.getString(11) + "," + d.getString(12) + "," + d.getString(13) + "," + d.getString(14)).map(d => {
            val t = d._1.split(",")
            val taskid = t(0)
            val src_deptcode = t(1)
            val dest_deptcode = t(2)
            var x0, y0, x1, y1 = "0"
            //un,zx,zy,ac,tp,tm,ak,'3' as vehicle,sp,be,task_id,zone_from,zone_to,coor_from,coor_to
            val paths = d._2.groupBy(_.getString(6)).toIndexedSeq.sortBy(d => d._2.size).reverse(0)._2

            try {
              if (t(3) != "" && t(3) != "null") {
                val tt = t(3).split(";", 2)
                x0 = if (tt.length > 0 && tt(0) != "") tt(0) else "0"
                y0 = if (tt.length > 1 && tt(1) != "") tt(1) else "0"
              }
              if (t(4) != "" && t(4) != "null") {
                val tt = t(4).split(";", 2)
                x1 = if (tt.length > 0 && tt(0) != "") tt(0) else "0"
                y1 = if (tt.length > 1 && tt(1) != "") tt(1) else "0"
              }
            } catch {
              case e: Exception => logger.error("有空值" + e.getMessage)
            }
            postData(un, paths, dayid, taskid, x0, y0, x1, y1, properties, src_deptcode, dest_deptcode)
          })
        }).flatMap(d => d).persist()

        val intm = tranTstampToTime((System.currentTimeMillis() / 1000).toString)

        val backInfo = resultRDD.toDF("un", "tm", "backjson", "gdurl4", "src_deptcode", "dest_deptcode", "inc_day")
          .withColumn("intm", lit(intm))
          .select("un", "tm", "src_deptcode", "dest_deptcode", "backjson", "intm", "inc_day")
        appendToHive(spark, backInfo.coalesce(1), Seq("inc_day"), "dm_gis.analyze_cartracks_backinfo")

        val finalresult = resultRDD.filter(_ != null)

        val cntinvok = resultRDD.count()
        val cnterror = finalresult.filter(d => d._3 == null || d._4 != null).count()
        invokeCnt += cntinvok
        errorCnt += cnterror
        System.err.println("请求量：" + cntinvok + "，返回量：" + finalresult.count() + "，失败量：" + cnterror)
        finalresult.filter(d => d._3 == null || d._4 != null).take(10).foreach(d => println("===================================================================\n" + d._1 + "\n" + d._2 + "\n" + d._3 + "\n" + d._4))
        Util.showCost("提交数据耗时：")
        resultRDD.unpersist()
        pathRdd.unpersist()
        //finalresult.take(1).foreach(println)
      }
    }
    System.err.println(s"【$dayid】总请求量：$invokeCnt，总失败量：$errorCnt")
  }

  def postData(un: String, paths: Iterable[Row], checkDate: String, taskid: String, x0: String, y0: String, x1: String, y1: String, properties: Properties, src_deptcode: String, dest_deptcode: String) = {
    Util.memTime()
    val pathsRows = paths.toIndexedSeq.sortBy(d => d.getString(5).toInt)
    //val billsRows = bills.toIndexedSeq
    val vehicleType = 3
    //val branch = billsRows(0).getString(2)
    val sb = new StringBuilder()
    var c = 0
    //应孔令其要求，city 属性强行存储taskid信息，推送中附带起终点网点位置坐标参数
    //sb.append("{\"start_point_x\":\""+x0+"\",\"city\":\""+taskid+"\",\"carnum\":\"" + un + "\",\"date\":\"" + checkDate + "\",\"vehicle\":" + vehicleType + ",\"retdata\":\"false\",\"tracks\":[")
    sb.append(s"""{"start_point_x":$x0,"start_point_y":$y0,"end_point_x":$x1,"end_point_y":$y1,"city":"$taskid","carnum":"$un","date":"$checkDate","vehicle":$vehicleType,"src_deptcode":"$src_deptcode","dest_deptcode":"$dest_deptcode","retdata":"false","tracks":[""")
    var ftm = "0"
    for (i <- 0 to pathsRows.length - 1) {
      try {
        val row = pathsRows(i)
        //        un,zx,zy,ac,tp,tm,ak,'3' as vehicle,sp,be,task_id,zone_from,zone_to,coor_from,coor_to
        val x = row.getString(1).toDouble
        val y = row.getString(2).toDouble
        var ac = row.getString(3).toInt;
        var tp = row.getString(4).toInt;
        var tm = row.get(5).toString.toLong
        ftm = pathsRows(0).get(5).toString
        val sp = row.getString(8).toDouble
        val be = row.getString(9).toDouble

        if (tm >= 100000000000L)
          tm = (tm / 1000).toInt
        if (c > 0)
          sb.append(",")

        sb.append("{\"type\":" + tp + ",\"x\":" + x + ",\"y\":" + y + ",\"accuracy\":" + ac + ",\"speed\":" + sp + ",\"azimuth\":" + be + ",\"time\":" + tm + "}")
        c += 1
      } catch {
        case e: Exception => {
          System.err.println("轨迹数据错误：\n" + pathsRows(i))
          e.printStackTrace()
        }
      }
    }
    sb.append("]")
    sb.append("}")
    //    val url = "http://gis-rss-pns-expdb.int.sfdc.com.cn:1080/analyzecartracks"
    val str = sb.toString()
    //    var ret = -200
    //var result = ""
    //System.err.println("开始提交数据：轨迹数：" + pathsRows.length + "，发送字节：" + str.length)
    //    val url_res = Util.tryPostWithDetail(url, str, 1)

    val gdurl = "http://jysc.int.sfcloud.local:1080/analyzecartracks"
    val gdurl_res = Util.tryPostWithDetail(gdurl, str, 1)

    (un, ftm, gdurl_res._3, gdurl_res._4, src_deptcode, dest_deptcode, checkDate)
  }
}
