package com.sf.app.etastd

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{colTrimNotNull, strNotNull}
import utils.DateUtil.{daysBetweenDate, getdaysBefore, getdaysBeforeOrAfter}
import utils.SparkBuilder

/**
 * @task_id: 727539
 * @description: 线路时效变更指标监控 dm_gis.eta_std_acc_speed_monitor
 * @demander:ft80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/4/20 14:22
 */
object EficientStandLineAccelerateSpeed extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val p1_main_df = loadMainDistance(spark, inc_day)
    procStandLine(spark, p1_main_df, inc_day) //40 min~
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def procStandLine(spark: SparkSession, p1_main_df: DataFrame, inc_day: String): Unit = {
    import spark.implicits._
    val days_45_before = getdaysBeforeOrAfter(inc_day, -44)
    val pub_cols = Seq("cond_4", "cond_2", "line_code", "load_zone_code", "dest_zone_code", "revise_run_tm", "his_run_tm", "modified_tm",
      "remark", "modifier", "vehicle_type", "task_id", "task_area_code", "task_subid", "is_stop", "vehicle_serial", "actual_depart_tm", "actual_arrive_tm",
      "actual_run_time", "line_time", "accrual_dist", "line_distance", "line_distance_std", "highwaymileage", "halfway_integrate_rate", "conduct_type",
      "ac_is_run_ontime", "carrier_name", "carrier_type", "actual_highway_mileage", "revise_run_tm_pre", "effective_date_pre", "expiration_date_pre", "revise_run_tm_bef", "effective_date_bef", "expiration_date_bef",
      "change_type", "change_time", "type", "line_code1", "vehicle_type1", "transoport_level", "is_multi", "plan_depart_tm", "plan_arrive_tm", "load_area_code").map(col)
    //表2  ** start_dept,end_dept,line_code,vehicle_type 均不为空  45天 800w~
    val o_recall_sql =
      s"""
         |select * from
         |(select task_id,task_area_code,task_subid,is_stop,vehicle_serial,start_dept,end_dept,line_code line_code1,
         |vehicle_type vehicle_type1,transoport_level,plan_depart_tm,plan_arrive_tm,
         |actual_depart_tm,actual_arrive_tm,actual_run_time,line_time,accrual_dist,line_distance,line_distance_std,
         |highwaymileage,halfway_integrate_rate,conduct_type,ac_is_run_ontime,carrier_name,carrier_type,
         |concat_ws('_', start_dept, end_dept) cond_2,
         |concat_ws('_',start_dept,end_dept,line_code) cond_4,
         |row_number() over(partition by task_subid order by last_update_tm desc) as t
         |from dm_gis.eta_std_line_recall
         |where inc_day between '$days_45_before' and '$inc_day'
         |and regexp_replace(substr(actual_depart_tm, 0,10),'-','') between '$days_45_before' and '$inc_day'
         |--limit 20
         |) a
         |where t=1
         |""".stripMargin
    logger.error("o_recall_sql 取数>>>>>>" + o_recall_sql)
    val o_second1_recall_df = spark.sql(o_recall_sql)
      .na.fill("", Seq("accrual_dist", "highwaymileage"))
      .withColumn("actual_highway_mileage", getActualHighwayMileage('accrual_dist, 'highwaymileage))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("o_recall_sql 取数结果>>>>>>" + o_second1_recall_df.count())

    //表3 单天30w~  45天 770w8486
    val o_task_sql =
      s"""
         |select * from (select task_id,votes_d,inc_day,row_number() over(partition by task_id order by inc_day desc) as t
         |from dm_grd.grd_new_task_detail
         |where inc_day between '$days_45_before' and '$inc_day'
         |and task_id is not null and trim(task_id)!=''
         |and state=6
         |--limit 20
         |) a where t=1
         |""".stripMargin
    logger.error("o_task_sql 取数>>>>>>" + o_task_sql)
    val o_second2_task_df = spark.sql(o_task_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("o_second2_task_df 取数结果>>>>>>" + o_second2_task_df.count())

    val o_monitor_sql =
      s"""
         |select send_task_id,sort_num,plan_send_batch,plan_arrive_batch,actual_send_batch,actual_arrive_batch,task_subid from
         |(select send_task_id,sort_num,plan_send_batch,plan_arrive_batch,actual_send_batch,actual_arrive_batch,
         |concat(send_task_id,sort_num) task_subid,
         |row_number() over(partition by concat(send_task_id,sort_num) order by last_update_tm desc) as t
         |from ods_russ.tt_rs_vehicle_task_pass_zone_monitor
         |where inc_day between '$days_45_before' and '$inc_day'
         |and pass_zone_code is not null and trim(pass_zone_code)!=''
         |and send_task_id is not null and trim(send_task_id)!='' ) a
         |where t =1
         |group by send_task_id,sort_num,plan_send_batch,plan_arrive_batch,actual_send_batch,actual_arrive_batch,task_subid
         |--limit 20
         |""".stripMargin
    logger.error("o_monitor_sql 取数>>>>>>" + o_monitor_sql)

    val o_second3_monitor_df = spark.sql(o_monitor_sql)
      .withColumn("plan_arrive_batch_lead", lead('plan_arrive_batch, 1).over(Window.partitionBy("send_task_id").orderBy('sort_num)))
      .withColumn("actual_arrive_batch_lead", lead('actual_arrive_batch, 1).over(Window.partitionBy("send_task_id").orderBy('sort_num)))
      .filter('plan_arrive_batch_lead.isNotNull)
      .selectExpr("task_subid", "plan_send_batch", "plan_arrive_batch_lead as plan_arrive_batch", "actual_send_batch", "actual_arrive_batch_lead as actual_arrive_batch")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("o_second3_monitor_df 取数结果>>>>>>" + o_second3_monitor_df.count()) //45d  2438w9142

    val o_depart = spark.sql(s"""select dept_code,max(city_name) city_name from dim.dim_department where dept_code is not null and trim(dept_code) != '' group by dept_code""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val union_4_df1 = p1_main_df.filter('cond_4 =!= "").drop("cond_2").join(o_second1_recall_df, Seq("cond_4"), "left")
      .select(pub_cols: _*)
    val union_2_df1 = p1_main_df.filter('cond_2 =!= "").drop("cond_4").join(o_second1_recall_df, Seq("cond_2"), "left")
      .select(pub_cols: _*)
    val union_all_df = union_4_df1.union(union_2_df1)
    logger.error(">>>>合并关联完后的数据总量>>>>>" + union_all_df.count())
    val res_cols = spark.sql("""select * from dm_gis.eta_std_acc_speed_monitor limit 0""").schema.map(_.name).map(col)
    val res = union_all_df.join(o_second2_task_df, Seq("task_id"), "left")
      .join(o_second3_monitor_df, Seq("task_subid"), "left")
      .join(broadcast(o_depart.selectExpr("dept_code as load_zone_code", "city_name start_city")), Seq("load_zone_code"), "left")
      .join(broadcast(o_depart.selectExpr("dept_code as dest_zone_code", "city_name end_city")), Seq("dest_zone_code"), "left")
      .withColumn("direction", concat_ws("-", 'start_city, 'end_city))
      .na.fill("", Seq("line_distance_std", "actual_depart_tm", "effective_date_pre", "expiration_date_pre", "effective_date_bef", "expiration_date_bef", "revise_run_tm_pre"))
      .withColumn("taskid_type", getTaskidType('actual_depart_tm, 'effective_date_pre, 'expiration_date_pre, 'effective_date_bef, 'expiration_date_bef, 'is_multi))
      .filter('taskid_type =!= "")
      .withColumn("static_sp", getStaticsp('line_distance_std, 'line_distance, 'line_time)) //m km --- min
      .withColumn("trends_sp", when(trim('actual_run_time) =!= "", lit(0.06) * 'accrual_dist / 'actual_run_time).otherwise(0)) //m  --- min
      .withColumn("dist_flag", when(colTrimNotNull('line_distance_std), 'line_distance_std).otherwise('line_distance))
      .na.fill("", Seq("static_sp", "dist_flag"))
      .withColumn("is_standard", getPlanTimeStandardUDF('dist_flag, 'static_sp))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>最终的结果数据>>>>>>>" + res.count())
    writeToHive(spark, res.coalesce(10), Seq("inc_day"), "dm_gis.eta_std_acc_speed_monitor")
  }


  def getPlanTimeStandardUDF = udf((dist_flag: String, static_sp: String) => {
    var is_standard = "不满足"
    try {
      val dist = if (strNotNull(dist_flag)) dist_flag.toDouble / 1000.0 else 0.0
      val sp = if (strNotNull(static_sp)) static_sp.toDouble else 0.0
      (dist, sp) match {
        case (x, y) if x > 0 && x <= 10 && y > 30 && y <= 45 => is_standard = "满足"
        case (x, y) if x > 10 && x <= 50 && y > 40 && y <= 45 => is_standard = "满足"
        case (x, y) if x > 50 && x <= 100 && y > 55 && y <= 60 => is_standard = "满足"
        case (x, y) if x > 100 && x <= 200 && y > 60 && y <= 70 => is_standard = "满足"
        case (x, y) if x > 200 && x <= 500 && y > 60 && y <= 75 => is_standard = "满足"
        case (x, y) if x > 500 && x <= 1000 && y > 35 && y <= 75 => is_standard = "满足"
        case (x, y) if x > 1000 && y > 65 && y <= 80 => is_standard = "满足"
        case _ => ""
      }
    } catch {
      case e: Exception => "" + e
    }
    is_standard
  })

  def loadMainDistance(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    //表1 主表 单天100w~
    val o_distance_sql =
      s"""
         |select load_zone_code,dest_zone_code,revise_run_tm,his_run_tm,remark,modifier,modified_tm,effective_date,expiration_date,
         |if(line_code is not null and trim(line_code) !='',line_code,'') line_code,load_area_code,
         |if(car_type is not null and trim(car_type) !='',split(car_type,'T')[0],'') vehicle_type
         |from dm_pass_rss.rmsa_tm_distance_times_pro
         |where inc_day = '$inc_day' and status=1
         |-- and remark not like '%里程%'
         |--limit 20
         |""".stripMargin
    logger.error("o_distance_sql 取数>>>>>>" + o_distance_sql)
    val o_main_distance_df = spark.sql(o_distance_sql)
      .withColumn("vehicle_type", matchCartype('vehicle_type))
      .withColumn("type", typeUdf('line_code))
      .withColumn("cond_all", concat_ws("_", 'load_zone_code, 'dest_zone_code, 'line_code))
      .withColumn("cond_4", when('type === "1", concat_ws("_", 'load_zone_code, 'dest_zone_code, 'line_code)).otherwise(""))
      .withColumn("cond_2", when('type === "0", concat_ws("_", 'load_zone_code, 'dest_zone_code)).otherwise(""))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("初始化获取的数据总量>>>>>>" + o_main_distance_df.count())
    o_main_distance_df.filter('vehicle_type =!= "").select("load_zone_code", "dest_zone_code", "line_code", "vehicle_type").show(20)
    val agg_df = o_main_distance_df.groupBy("cond_all").agg(count("cond_all").as("cnt"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val cnt_over_1_df = o_main_distance_df.join(broadcast(agg_df.filter("cnt > 1")), Seq("cond_all"))
    val cnt_equa_1_df = o_main_distance_df.join(broadcast(agg_df.filter("cnt = 1")), Seq("cond_all"))

    val window = Window.partitionBy("cond_all").orderBy(desc("effective_date"))
    val p1_df = cnt_over_1_df.select("cond_all", "revise_run_tm", "effective_date", "expiration_date")
      .withColumn("num_tm", dense_rank().over(window))
      .withColumn("revise_run_tm_lead", lead("revise_run_tm", 1).over(window))
      .withColumn("revise_run_tm_lag", lag("revise_run_tm", 1).over(window))
      .withColumn("revise_run_tm_flag", when($"revise_run_tm" === $"revise_run_tm_lead", 1).otherwise(0))
      .withColumn("effective_date_ss", when('revise_run_tm_lag =!= 'revise_run_tm, 'effective_date).otherwise(""))
      .withColumn("num_ss", dense_rank().over(Window.partitionBy("cond_all").orderBy(desc("effective_date_ss"))))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //fix revise_run_tm 获取fix时间  modified_tm  2020-05-03 02:00:20
    val p1_2_df = p1_df.filter('num_tm === 1).select("cond_all", "revise_run_tm")
    val p1_2_tm_df = p1_df.filter('num_tm === 1).select("cond_all", "expiration_date")

    val p1_inter = p1_df.select('cond_all, 'revise_run_tm, 'revise_run_tm_flag, 'effective_date)
    val p1_3_df = p1_2_df.join(p1_inter, Seq("cond_all", "revise_run_tm"), "left")
      .join(p1_2_tm_df, Seq("cond_all"), "left")
      .filter('revise_run_tm_flag === 0)
      .withColumn("filt_cond", row_number().over(window))
      .filter('filt_cond === 1)
      .selectExpr("cond_all", "revise_run_tm as revise_run_tm_pre", "effective_date as effective_date_pre", "expiration_date as expiration_date_pre")

    //修正第2顺位
    val p2_2_df = p1_df.filter('num_ss === 1).select("cond_all", "revise_run_tm")
    val p2_2_tm_df = p1_df.filter('num_ss === 1).select("cond_all", "expiration_date")
    val p2_3_df = p2_2_df.join(p1_inter, Seq("cond_all", "revise_run_tm"), "left")
      .join(p2_2_tm_df, Seq("cond_all"), "left")
      .filter('revise_run_tm_flag === 0)
      .withColumn("filt_cond", row_number().over(window))
      .filter('filt_cond === 1)
      .selectExpr("cond_all", "revise_run_tm as revise_run_tm_bef", "effective_date as effective_date_bef", "expiration_date as expiration_date_bef")

    val pub_cols = Seq("cond_all", "load_zone_code", "dest_zone_code", "revise_run_tm", "his_run_tm", "remark", "modifier", "modified_tm", "line_code", "vehicle_type", "type", "cond_4", "cond_2", "revise_run_tm_pre", "effective_date_pre", "expiration_date_pre", "revise_run_tm_bef", "effective_date_bef", "expiration_date_bef", "change_type", "change_time", "is_multi", "load_area_code").map(col)
    val p1_main_df = cnt_over_1_df
      .join(broadcast(p1_3_df), Seq("cond_all"), "left")
      .join(broadcast(p2_3_df), Seq("cond_all"), "left")
      .na.fill("", Seq("revise_run_tm_pre", "revise_run_tm_bef", "effective_date_pre", "effective_date_bef", "expiration_date_pre", "expiration_date_bef"))
      .filter(modifiedTime2Udf('effective_date_pre, lit(inc_day)) >= 7 && modifiedTime2Udf('effective_date_pre, lit(inc_day)) < 45)
      .withColumn("expiration_date_bef", getExpEffectiveDateBef('effective_date_pre, 'expiration_date_bef))
      .withColumn("effective_date_bef", getBefEffectiveDateDate('effective_date_bef, 'expiration_date_bef))
      .filter(modifiedTime2Udf('effective_date_pre, 'effective_date_bef) >= 7)
      .withColumn("change_type", comTmUdf('revise_run_tm_pre, 'revise_run_tm_bef))
      .withColumn("change_time", comTmMinusUdf('revise_run_tm_pre, 'revise_run_tm_bef))
      .withColumn("num", row_number().over(Window.partitionBy("cond_all").orderBy(desc("effective_date"))))
      .filter('num === 1).drop("num")
      .withColumn("is_multi", lit("Y"))
      .select(pub_cols: _*)

    //part 2 --单条的数据
    val p2_main_df = cnt_equa_1_df
      .withColumn("revise_run_tm_pre", 'revise_run_tm)
      .withColumn("effective_date_pre", 'effective_date)
      .withColumn("expiration_date_pre", 'expiration_date)
      .withColumn("revise_run_tm_bef", lit(""))
      .withColumn("effective_date_bef", lit(""))
      .withColumn("expiration_date_bef", lit(""))
      .withColumn("change_type", lit(""))
      .withColumn("change_time", lit(""))
      .withColumn("is_multi", lit("N"))
      .select(pub_cols: _*)
    //20230523 fix 近7天的数据保留
    val p_main_df = p1_main_df.union(p2_main_df).filter(modifiedTime2Udf('effective_date_pre, lit(inc_day)) < 45).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("主表加工后的数据>>>>>>" + p_main_df.count())
    p_main_df
  }

  def getBefEffectiveDateDate = udf((effective_date_bef: String, expiration_date_bef: String) => {
    var res = effective_date_bef
    try {
      if (effective_date_bef == "2000-01-01") {
        res = getdaysBefore(expiration_date_bef, -45, "yyyy-MM-dd")
      }
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  def getExpEffectiveDateBef = udf((effective_date_pre: String, expiration_date_bef: String) => {
    var res = expiration_date_bef
    try {
      if (expiration_date_bef.contains("9999-12-31") && effective_date_pre != "") {
        res = getdaysBefore(effective_date_pre, -1, "yyyy-MM-dd")
      }
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  def getStaticsp = udf((line_distance_std: String, line_distance: String, line_time: String) => {
    var res = 0.0 //m  km --- min
    try {
      if (line_time.trim != "") {
        if (line_distance_std.trim == "" && line_distance.trim != "") {
          res = 60 * line_distance.toDouble / line_time.toDouble
        }
        if (line_distance_std.trim != "") { //m/min
          res = 0.06 * line_distance_std.toDouble / line_time.toDouble
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    res.toString
  })

  def getTaskidType = udf((actual_depart_tm: String, effective_date_pre: String, expiration_date_pre: String, effective_date_bef: String, expiration_date_bef: String, is_multi: String) => {
    var taskid_type = ""
    try {
      if (is_multi == "Y") {
        if (actual_depart_tm.trim != "" && expiration_date_bef.trim != "" && effective_date_bef.trim != "" && effective_date_pre.trim != "" && expiration_date_pre.trim != "") {
          if (actual_depart_tm >= effective_date_bef && actual_depart_tm < expiration_date_bef) {
            taskid_type = "调整前任务"
          }
          if (actual_depart_tm >= expiration_date_bef && actual_depart_tm < effective_date_pre) {
            taskid_type = "调整前标准时效任务"
          }

          if (actual_depart_tm >= effective_date_pre && actual_depart_tm <= expiration_date_pre) {
            taskid_type = "调整后任务"
          }
          if (actual_depart_tm > expiration_date_pre) {
            taskid_type = "调整后标准时效任务"
          }
        }
      }
      if (is_multi == "N") {
        if (actual_depart_tm.trim != "" && effective_date_pre.trim != "" && expiration_date_pre.trim != "") {
          if (actual_depart_tm < effective_date_pre) {
            taskid_type = "调整前标准时效任务"
          }
          if (effective_date_pre <= actual_depart_tm && actual_depart_tm <= expiration_date_pre) {
            taskid_type = "调整后任务"
          }
          if (actual_depart_tm > expiration_date_pre) {
            taskid_type = "调整后标准时效任务"
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    taskid_type
  })

  def getActualHighwayMileage = udf((accrual_dist: String, highwaymileage: String) => {
    var actual_highway_mileage = 0.0
    if (accrual_dist.trim != "" && highwaymileage.trim != "") {
      val rt_d = try {
        accrual_dist.toDouble
      } catch {
        case e: Exception => 0.0
      }
      val high_d = try {
        highwaymileage.toDouble
      } catch {
        case e: Exception => 0.0
      }
      actual_highway_mileage = rt_d - high_d
    }
    actual_highway_mileage
  })

  def comTmMinusUdf = udf((revise_run_tm_pre: String, revise_run_tm_bef: String) => {
    var change_type = 0.0
    if (revise_run_tm_pre.trim != "" && revise_run_tm_bef.trim != "") {
      val pre_tm = try {
        revise_run_tm_pre.toDouble
      } catch {
        case e: Exception => 0.0
      }

      val bef_tm = try {
        revise_run_tm_bef.toDouble
      } catch {
        case e: Exception => 0.0
      }
      change_type = (pre_tm - bef_tm).abs / 60
    }
    change_type //.formatted("%.2f")
  })


  def comTmUdf = udf((revise_run_tm_pre: String, revise_run_tm_bef: String) => {
    var change_type = ""
    if (revise_run_tm_pre.trim != "" && revise_run_tm_bef.trim != "") {
      val pre_tm = try {
        revise_run_tm_pre.toDouble
      } catch {
        case e: Exception => 0.0
      }

      val bef_tm = try {
        revise_run_tm_bef.toDouble
      } catch {
        case e: Exception => 0.0
      }
      change_type = pre_tm - bef_tm match {
        case x if x > 0 => "时效延迟"
        case x if x < 0 => "时效压缩"
        case _ => ""
      }
    }
    change_type
  })


  def modifiedTime2Udf = udf((modified_tm_pre: String, inc_day: String) => {
    var inter_days: Int = 0
    if (!modified_tm_pre.isEmpty && modified_tm_pre.trim != "" && !inc_day.isEmpty && inc_day.trim != "") {
      val reg = """\D+""".r
      val start_tm = reg.replaceAllIn(modified_tm_pre, "")
      val end_tm = reg.replaceAllIn(inc_day, "")
      inter_days = daysBetweenDate(start_tm, end_tm)
    }
    inter_days
  })


  def modifiedTimeUdf = udf((modified_tm: String, inc_day: String) => {
    var inter_days: Int = 0
    if (!modified_tm.isEmpty && modified_tm.trim != "") {
      val start_tm = modified_tm.split("\\s+")(0).replaceAll("-", "")
      inter_days = daysBetweenDate(start_tm, inc_day)
    }
    inter_days
  })


  /**
   * 0：精确匹配：起终网点+车型+线路编码均不为null
   * 1：模糊匹配：起终网点+车型/线路编码其一为空
   * 2：起终点匹配：起终网点+车型/线路编码为空
   */
  def typeUdf = udf((line_code: String) => {
    var type_back = "1"
    if (line_code.trim == "") type_back = "0"
    type_back
  })

  def matchCartype = udf((car_type: String) => {
    var car_type_res = ""
    try {
      if (car_type.trim != "") {
        car_type_res = car_type.toDouble match {
          case x if x >= 0 && x <= 1 => "5"
          case x if x > 1 && x <= 3 => "6"
          case x if x > 3 && x < 7 => "7"
          case x if x >= 7 => "8"
        }
      }
    } catch {
      case e: Exception => "" + e.getMessage
    }
    car_type_res
  })


}
