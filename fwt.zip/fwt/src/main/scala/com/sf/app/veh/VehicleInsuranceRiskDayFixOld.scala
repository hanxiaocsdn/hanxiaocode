package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil

/**
 * @description: 旧版清洗逻辑
 * @author 01418539 caojia
 * @date 2022/8/18 15:39
 */
object VehicleInsuranceRiskDayFixOld extends DataSourceCommon {
  def processFixDayOld(spark: SparkSession, o_day_df: DataFrame): DataFrame = {
    import spark.implicits._
    //part 1  16
    val o_dist_t_cols_str: Seq[String] = Seq("total_dist")
    //分时段 5
    val o_dist_d_cols_str: Seq[String] = Seq("night_dirve_dist", "before_dawn_drive_dist", "early_morning_drive_dist", "afternoon_drive_dist", "dusk_drive_dist")
    //道路等级 5
    val o_dist_c_cols_str: Seq[String] = Seq("high_speed_dist", "state_road_dist", "provincial_dist", "county_dist", "township_dist")
    //道路设施 5
    val o_dist_r_cols_str: Seq[String] = Seq("dangerous_road_dist", "high_accident_road_dist", "school_road_dist", "sharp_turn_road_dist", "village_road_dist")

    //part 2  13
    val o_dura_t_cols_str: Seq[String] = Seq("total_duration")
    //分时段 5
    val o_dura_d_cols_str: Seq[String] = Seq("night_dirve_duration", "before_dawn_drive_duration", "early_morning_drive_duration", "afternoon_drive_duration", "dusk_drive_duration")
    //道路设施 5
    val o_dura_r_cols_str: Seq[String] = Seq("dangerous_road_duration", "high_accident_road_duration", "school_road_duration", "sharp_turn_road_duration", "township_road_duration")

    //part 3 超速 超时 驾驶时长  2
    val o_dura_o_cols_str: Seq[String] = Seq("over_speed_duration", "over_speed_ser_duration") //, "over_drive_duration"

    val o_fix_cols = o_dist_t_cols_str ++ o_dist_d_cols_str ++ o_dist_c_cols_str ++ o_dist_r_cols_str ++ o_dura_t_cols_str ++ o_dura_d_cols_str ++ o_dura_r_cols_str ++ o_dura_o_cols_str

    o_day_df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    //1 时长异常
    val ne_dura_d_cols = fsdDuraCond(o_dura_d_cols_str, o_dist_d_cols_str, "before_dawn_drive_duration", "before_dawn_drive_dist", 10800, 14400)
    val ne_dura_cr_cols = fssDuraCond(o_dura_r_cols_str, o_dist_r_cols_str, 'total_duration, 86400)
    val ne_dura_t_cols = totalDuraCond(o_dura_d_cols_str, "first")

    //2 里程异常
    val ne_dist_d_cols = fsdDistCond(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", 300000, 400000, "first")
    val ne_dist_r_cols = fldDistCond(o_dist_c_cols_str, 'total_dist, 2400000)
    val ne_dist_cr_cols = fssDistCond(o_dist_r_cols_str, o_dura_r_cols_str, 'total_dist, 2400000, "first")
    val ne_dist_t_cols = totalDistCond(o_dist_d_cols_str, o_dist_c_cols_str, "first")

    //3 速度异常
    val ne_dura_os_cols = overSpeedCond(o_dura_o_cols_str, "first")

    val excp_cols = Seq(ne_dist_t_cols) ++ ne_dist_r_cols ++ ne_dist_d_cols ++ ne_dist_cr_cols ++ Seq(ne_dura_t_cols) ++ ne_dura_d_cols ++ ne_dura_cr_cols ++ ne_dura_os_cols
    //只要一个字段异常 则车辆标记为异常
    val ex_flag = excp_cols.foldLeft(lit(0))(_ + _).alias("ex_flag") //正常 14740/15554=94.7%

    val o_all_cols = o_day_df.schema.map(_.name).map(col)

    val o_day_add_ex_df = o_day_df.select(o_all_cols ++ excp_cols :+ ex_flag: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //计算各段的 正常速度 和 超速时长占比
    val agg_cols = ColumnUtil.renameColumn(o_fix_cols.map(sum(_)), o_fix_cols)
    val fd_speed_cols = partNormalSpeed(o_dist_t_cols_str ++ o_dist_d_cols_str ++ o_dist_r_cols_str, o_dura_t_cols_str ++ o_dura_d_cols_str ++ o_dura_r_cols_str)

    val norm_sp_prop_df = o_day_add_ex_df
      .select((o_fix_cols :+ "ex_flag" :+ "inc_day").map(col): _*)
      .filter('ex_flag === 0)
      .groupBy("inc_day")
      .agg(agg_cols.head, agg_cols.tail: _*)
      .withColumn("normal_osp_prop", when('over_speed_ser_duration =!= 0, 'over_speed_duration / 'over_speed_ser_duration).otherwise(0))
      .select(fd_speed_cols ++ Seq(col("normal_osp_prop"),col("inc_day")): _*)//.collect().head
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //异常标识字段 + 阶段正常速度字段
    val day_norm_sp_prop_df = o_day_add_ex_df
      .join(norm_sp_prop_df,Seq("inc_day"),"left")
      //剔除需要 第2次 异常判断 字段
      .drop((o_dura_t_cols_str ++ o_dist_d_cols_str ++ o_dist_r_cols_str ++ o_dist_t_cols_str ++ o_dura_o_cols_str).map(_ + "_ex"): _*)

    val day_norm_sp_prop_cols = day_norm_sp_prop_df.schema.map(_.name).map(col)

    //修正第1部分数据
    //fix时长 1
    val fd_dura_fix = fixFdDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", 10800, 14400, "dura")
    ///fix时长 2
    val other_dura_fix = fixOtherDistOrDura(o_dist_r_cols_str, o_dura_r_cols_str, 2400000, 'total_dist, 'total_duration, "dura")

    val t1 = day_norm_sp_prop_df.select(day_norm_sp_prop_cols ++ fd_dura_fix ++ other_dura_fix: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //重新 打标第2部分异常标签 总时长、分时段里程、分设施里程 3个
    val ne2_dura_t_cols = totalDuraCond(o_dura_d_cols_str, "second")
    val ne2_dist_d_cols = fsdDistCond(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", 300000, 400000, "second")
    val ne2_dist_cr_cols = fssDistCond(o_dist_r_cols_str, o_dura_r_cols_str, 'total_dist, 2400000, "second")

    //增加总时长、分时段里程、分设施里程  异常判断后的df
    val t2 = t1.select(t1.schema.map(_.name).map(col) ++ Seq(ne2_dura_t_cols) ++ ne2_dist_d_cols ++ ne2_dist_cr_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //fix时长 total
    val total_duration_fix = fixTotalDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, 'total_dist, 'total_duration, 'total_dist_sp, 86400, "dura")
      .alias("total_duration_fix")

    //fix里程 分时段里程
    val fd_dist_fix = fixFdDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", 300000, 400000, "dist")
    //fix里程 分路段 分设施里程
    val city_dist_fix = fixCityDist(o_dist_c_cols_str, 'total_dist, 2400000)
    //fix里程 分段3里程
    val other_dist_fix = fixOtherDistOrDura(o_dist_r_cols_str, o_dura_r_cols_str, 2400000, 'total_dist, 'total_duration, "dist")

    val t3 = t2.select(t2.schema.map(x => col(x.name)) ++ Seq(total_duration_fix) ++ fd_dist_fix ++ city_dist_fix ++ other_dist_fix: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //fix里程 总里程
    //总里程/超速/严重超速 异常重新打标
    val ne2_dist_t_cols = totalDistCond(o_dist_d_cols_str, o_dist_c_cols_str, "second")
    val ne2_dura_os_cols = overSpeedCond(o_dura_o_cols_str, "second")
    val t4 = t3.select(t3.schema.map(_.name).map(col) ++ Seq(ne2_dist_t_cols) ++ ne2_dura_os_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val total_dist_fix = fixTotalDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, 'total_dist, 'total_duration, 'total_dist_sp, 2400000, "dist")
      .alias("total_dist_fix")
    //fix严重超速
    val over_speed_ser_duration_fix = when('over_speed_ser_duration_ex === 1, 0)
      .otherwise('over_speed_ser_duration)
      .alias("over_speed_ser_duration_fix")
    //fix超速
    val over_speed_duration_fix = when('over_speed_duration_ex === 1, 'over_speed_ser_duration_fix * 'normal_osp_prop)
      .otherwise('over_speed_duration)

    val day_fix_df = t4.select(t4.schema.map(x => col(x.name)) ++ Seq(total_dist_fix) :+ over_speed_ser_duration_fix: _*)
      .withColumn("over_speed_duration_fix", over_speed_duration_fix)

    //加载fix表字段信息
    val fix_res_cols = spark.sql("""select * from dm_gis.old_org_first_part_insurance_daily limit 0""").schema.map(_.name).map(x => if (o_fix_cols.contains(x)) x + "_fix" else x).map(col)
    val res = day_fix_df.select(fix_res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)

//    writeToHive(spark, res.coalesce(50), Seq("inc_day", "ak"), "dm_gis.old_org_first_part_insurance_daily")
    res
  }

  /**
   * 列 比较大小  取最小值 min
   *
   * @param threshold 给定阈值
   * @return
   */
  def compareMinCol(threshold: Double) = udf((c1: String, c2: String) => {
    var res = threshold
    try {
      if (c1.toDouble >= c2.toDouble) res = c2.toDouble else res = c1.toDouble
    } catch {
      case e: Exception => logger.error("数据有空值。" + e.getMessage)
    }
    res
  })

  /**
   * 列 比较大小 取最大值max
   *
   * @param threshold 给定阈值
   * @return
   */
  def compareMaxCol(threshold: Double) = udf((c1: String, c2: String) => {
    var res = threshold
    try {
      if (c1.toDouble >= c2.toDouble) res = c1.toDouble else res = c2.toDouble
    } catch {
      case e: Exception => logger.error("数据有空值。" + e.getMessage)
    }
    res
  })

  /**
   * 计算 给定阶段 的 平均速度 （无异常车辆）
   *
   * @param cols_str
   * @param row
   * @return
   */
  def addSpeed(cols_str: Seq[String], row: Row): Seq[Column] = {
    var add_cols: Seq[Column] = Nil
    for (i <- 0 until row.schema.size) {
      add_cols = add_cols :+ lit(row.get(i)).alias(cols_str(i))
    }
    add_cols
  }

  /**
   * 计算 分段的平均速度
   *
   * @param t_cols_str
   * @param d_cols_str
   */
  def partNormalSpeed(t_cols_str: Seq[String], d_cols_str: Seq[String]): Seq[Column] = {
    val newNames = t_cols_str.map(_ + "_sp")
    val t_cols = t_cols_str.map(col)
    val d_cols = d_cols_str.map(col)
    val sp_cols = t_cols zip d_cols map { x => when(x._2 =!= 0, x._1 / x._2).otherwise(0) }
    ColumnUtil.renameColumn(sp_cols, newNames)
  }

  /**
   * fix 总时长 or 总里程
   *
   * @param d_cols_str     里程字段
   * @param t_cols_str     时长字段
   * @param total_dist     总里程-未修正
   * @param total_duration 总时长-未修正
   * @param norm_sp        正常车辆速度
   * @param threshold
   * @param flag           dist or dura
   * @return
   */
  def fixTotalDistOrDura(d_cols_str: Seq[String], t_cols_str: Seq[String], total_dist: Column, total_duration: Column, norm_sp: Column, threshold: Long, flag: String): Column = {
    var res_cols = lit("")
    if (flag == "dist") {
      val fd_dist_sum = d_cols_str.map(_ + "_fix").map(col).foldLeft(lit(0))(_ + _)
      val fd_dura_sum = t_cols_str.map(_ + "_fix").map(col).foldLeft(lit(0))(_ + _)
      val cond1_cols = fd_dist_sum + 800000
      val cond2 = (col("total_duration_fix") - fd_dura_sum) * norm_sp
      val cond2_cols = fd_dist_sum + compareMaxCol(0)(lit(0), cond2)
      val cond3_cols = lit(threshold)
      res_cols = when(col("total_dist_ex") =!= 0, compareMinCol(0)(cond1_cols, compareMinCol(0)(cond2_cols, cond3_cols))).otherwise(total_dist)
    }
    if (flag == "dura") {
      val fd_dist_sum = d_cols_str.map(col).foldLeft(lit(0))(_ + _)
      val fd_dura_sum = t_cols_str.map(_ + "_fix").map(col).foldLeft(lit(0))(_ + _)
      val cond1_cols = fd_dura_sum + 28800
      val cond2 = when(norm_sp =!= 0, (total_dist - fd_dist_sum) / norm_sp).otherwise(0)
      val cond2_cols = fd_dura_sum + compareMaxCol(0)(lit(0), cond2)
      val cond3_cols = lit(threshold)
      res_cols = when(col("total_duration_ex") =!= 0, compareMinCol(0)(cond1_cols, compareMinCol(0)(cond2_cols, cond3_cols))).otherwise(total_duration)
    }
    res_cols
  }

  /**
   * fix 分段时长 or 分段里程
   *
   * @param cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fixFdDistOrDura(d_cols_str: Seq[String], t_cols_str: Seq[String], d_diff_str: String, t_diff_str: String, threshold: Long, diff_threshold: Long, flag: String): Seq[Column] = {
    var fix_cols_str = Seq("")
    var ex_cols = Seq(lit(""))
    var norm_d = Seq(lit(""))
    var diff_d = Seq(lit(""))
    var fix_d_t = Seq(lit(""))

    var default_cols = Seq(lit(""))

    if (flag == "dist") {
      val d_order_str = d_cols_str.filter(_ == d_diff_str) ++ d_cols_str.filter(_ != d_diff_str)
      val t_order_str = (t_cols_str.filter(_ == t_diff_str) ++ t_cols_str.filter(_ != t_diff_str)).map(_ + "_fix")
      fix_cols_str = d_order_str.map(_ + "_fix")

      ex_cols = d_order_str.map(_ + "_ex").map(col)

      norm_d = d_cols_str.filter(_ == d_diff_str).map(x => lit(diff_threshold))
      diff_d = d_cols_str.filter(_ != d_diff_str).map(x => lit(threshold))
      //此处目的：顺序对应
      val fd_sp = d_order_str.map(_ + "_sp").map(col)
      val fd_tm = t_order_str.map(col)

      fix_d_t = fd_tm zip fd_sp map { x => x._1 * x._2 }

      default_cols = d_order_str.map(col)
    }
    if (flag == "dura") {
      val d_order_str = d_cols_str.filter(_ == d_diff_str) ++ d_cols_str.filter(_ != d_diff_str)
      val t_order_str = t_cols_str.filter(_ == t_diff_str) ++ t_cols_str.filter(_ != t_diff_str)

      fix_cols_str = t_order_str.map(_ + "_fix")
      ex_cols = t_order_str.map(_ + "_ex").map(col)

      norm_d = t_cols_str.filter(_ == t_diff_str).map(x => lit(diff_threshold))
      diff_d = t_cols_str.filter(_ != t_diff_str).map(x => lit(threshold))

      //此处目的：顺序对应
      val fd_dt = d_order_str.map(col)
      val fd_sp = d_order_str.map(_ + "_sp").map(col)

      fix_d_t = fd_dt zip fd_sp map { x => when(x._2 =!= 0, x._1 / x._2).otherwise(0) }

      default_cols = t_order_str.map(col)
    }
    val fd_dist = norm_d ++ diff_d //(((c1,c2),c3),c4)
    val fix_cols = ex_cols zip fd_dist zip fix_d_t zip default_cols map { x => when(x._1._1._1 === 1, compareMinCol(0)(x._1._1._2, x._1._2)).otherwise(x._2) }
    ColumnUtil.renameColumn(fix_cols, fix_cols_str)
  }


  /**
   * fix 其他路段或设施的 时长 or 里程
   *
   * @param cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fixOtherDistOrDura(d_cols_str: Seq[String], t_cols_str: Seq[String], threshold: Long, total_dist: Column, total_duration: Column, flag: String): Seq[Column] = {
    var fix_cols_str = Seq("")
    var fix_cols = Seq(lit(""))

    if (flag == "dist") {
      fix_cols_str = d_cols_str.map(_ + "_fix")

      val ex_cols_str = d_cols_str.map(_ + "_ex").map(col)
      val norm_d = d_cols_str.map(x => lit(threshold))
      val norm_dt = d_cols_str.map(x => total_dist)

      //速度 * 时间
      val fd_sp = d_cols_str.map(_ + "_sp").map(col)
      val fd_tm = t_cols_str.map(x => col(x + "_fix"))

      val norm_dc = fd_tm zip fd_sp map { x => x._1 * x._2 } //((((c1,c2),c3),c4),c5)

      val d_cols = d_cols_str.map(col)
      fix_cols = ex_cols_str zip norm_d zip norm_dt zip norm_dc zip d_cols map { x => when(x._1._1._1._1 === 1, compareMinCol(0)(x._1._1._1._2, compareMinCol(0)(x._1._1._2, x._1._2))).otherwise(x._2) }
    }
    if (flag == "dura") {
      fix_cols_str = t_cols_str.map(_ + "_fix")

      val ex_cols_str = t_cols_str.map(_ + "_ex").map(col)
      val norm_dt = t_cols_str.map(x => total_duration)
      //里程 / 时间
      val fd_sp = d_cols_str.map(_ + "_sp").map(col)
      val fd_dist = d_cols_str.map(col)
      val norm_dc = fd_dist zip fd_sp map { x => when(x._2 =!= 0, x._1 / x._2).otherwise(0) } //(((c1,c2),c3),c4)
      val t_cols = t_cols_str.map(col)
      fix_cols = ex_cols_str zip norm_dt zip norm_dc zip t_cols map { x => when(x._1._1._1 === 1, compareMinCol(0)(x._1._1._2, x._1._2)).otherwise(x._2) }
    }
    ColumnUtil.renameColumn(fix_cols, fix_cols_str)
  }

  /**
   * fix 城市 乡道 等 里程
   *
   * @param t_cols_str
   * @param total_dist
   * @param threshold
   * @return
   */
  def fixCityDist(t_cols_str: Seq[String], total_dist: Column, threshold: Long): Seq[Column] = {
    val fix_cols_str = t_cols_str.map(_ + "_fix")

    val ex_cols_str = t_cols_str.map(_ + "_ex").map(col)
    val norm_d = t_cols_str.map(x => lit(threshold))
    val d_cols = t_cols_str.map(col) //((c1,c2),c3)
    val fix_cols = ex_cols_str zip norm_d zip d_cols map { x => when(x._1._1 === 1, compareMinCol(0)(x._2, compareMinCol(0)(x._1._2, total_dist))).otherwise(x._2) }

    ColumnUtil.renameColumn(fix_cols, fix_cols_str)
  }

  /**
   * 超速行驶 时长 异常判断
   *
   * @param cols_str
   * @param t_dura
   */
  def overSpeedCond(cols_str: Seq[String], flag: String): Seq[Column] = {
    val ex_cols_str = cols_str.map(_ + "_ex")
    var res_cols = Seq(lit(""))
    if (flag == "first") {
      res_cols = cols_str.map(x => col(x).cast("double")).map { x => when(x > col("total_duration").cast("double") || x < 0, 1).otherwise(0) }
    }
    if (flag == "second") {
      res_cols = cols_str.map(x => col(x).cast("double")).map { x => when(x > col("total_duration_fix").cast("double") || x < 0, 1).otherwise(0) }
    }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 总里程total dist 异常判断  2次
   *
   * @param total_dist
   * @param fsd_dist_cols_str
   * @param fld_dist_cols_str
   * @param flag
   * @return
   */

  def totalDistCond(fsd_dist_cols_str: Seq[String], fld_dist_cols_str: Seq[String], flag: String): Column = {
    var fsd_dist_sum = lit(0.0)
    var fld_dist_sum = lit(0.0)
    var ex_total_dist = lit("")
    if (flag == "first") {
      fsd_dist_sum = fsd_dist_cols_str.map(x => col(x).cast("double")).foldLeft(lit(0.0))(_ + _)
      fld_dist_sum = fld_dist_cols_str.map(x => col(x).cast("double")).foldLeft(lit(0.0))(_ + _)

      ex_total_dist = when(col("total_dist") > 2400000, 1)
        .when(col("total_dist").cast("double") - fsd_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fsd_dist_sum, lit(-1000)).cast("double"), 2)
        .when(col("total_dist").cast("double") - fsd_dist_sum.cast("double") > 800000, 3)
        .when(col("total_dist").cast("double") - fld_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fld_dist_sum, lit(-1000)).cast("double"), 4)
        .when(col("total_dist").cast("double") - fld_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fld_dist_sum, lit(-1000)).cast("double"), 4)
        .when(col("total_duration").cast("double") === 0 && col("total_dist").cast("double") =!= 0, 5)
        .when(col("total_duration").cast("double") =!= 0 && col("total_dist") / col("total_duration") > 45, 5)
        .when(col("total_duration").cast("double") > 600 && col("total_dist").cast("double") === 0, 6)
        .otherwise(0)
        .alias("total_dist_ex")
    }
    if (flag == "second") {
      fsd_dist_sum = fsd_dist_cols_str.map(x => col(x + "_fix")).foldLeft(lit(0.0))(_ + _).alias("fsd_dist_sum")
      fld_dist_sum = fld_dist_cols_str.map(x => col(x + "_fix")).foldLeft(lit(0.0))(_ + _).alias("fld_dist_sum")

      ex_total_dist = when(col("total_dist") > 2400000, 1)
        .when(col("total_dist").cast("double") - fsd_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fsd_dist_sum, lit(-1000)).cast("double"), 2)
        .when(col("total_dist").cast("double") - fsd_dist_sum.cast("double") > 800000, 3)
        .when(col("total_dist").cast("double") - fld_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fld_dist_sum, lit(-1000)).cast("double"), 4)
        .when(col("total_duration_fix").cast("double") === 0 && col("total_dist").cast("double") =!= 0, 5)
        .when(col("total_duration_fix").cast("double") =!= 0 && col("total_dist").cast("double") / col("total_duration_fix").cast("double") > 45, 5)
        .when(col("total_duration_fix").cast("double") =!= 0 && col("total_dist") / col("total_duration_fix") > 45, 5)
        .when(col("total_duration_fix").cast("double") > 600 && col("total_dist").cast("double") === 0, 6)
        .otherwise(0)
        .alias("total_dist_ex")
    }
    ex_total_dist
  }

  /**
   * 总时长total duration 异常判断  2次
   *
   * @param fsd_duration_cols_str
   * @param flag
   * @return
   */
  def totalDuraCond(fsd_duration_cols_str: Seq[String], flag: String): Column = {
    var fsd_duration_sum = lit(0.0)

    if (flag == "first") {
      fsd_duration_sum = fsd_duration_cols_str.map(x => col(x).cast("double")).foldLeft(lit(0.0))(_ + _)
    }
    if (flag == "second") {
      fsd_duration_sum = fsd_duration_cols_str.map(x => col(x + "_fix").cast("double")).foldLeft(lit(0.0))(_ + _)
    }
    val ex_total_duration = when(col("total_duration") > 86400, 1)
      .when(col("total_duration").cast("double") - fsd_duration_sum.cast("double") < compareMinCol(-600)(lit(-0.01) * fsd_duration_sum, lit(-600)).cast("double"), 2)
      .when(col("total_duration").cast("double") - fsd_duration_sum.cast("double") > 28800, 3)
      .when(col("total_dist").cast("double") > 5000 && col("total_duration").cast("double") === 0, 5)
      .otherwise(0)
      .alias("total_duration_ex")
    ex_total_duration
  }

  /**
   * 分时段 里程dist  异常判断
   *
   * @param dist_cols_str
   * @param duration_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fsdDistCond(dist_cols_str: Seq[String], duration_cols_str: Seq[String], dist_diff_str: String, dura_diff_str: String, threshold: Long, diff_threshold: Long, flag: String): Seq[Column] = {
    val norm_dist_cols_str = dist_cols_str.filter(_ != dist_diff_str)
    val diff_dist_cols_str = dist_cols_str.filter(_ == dist_diff_str)

    val norm_duration_cols_str = duration_cols_str.filter(_ != dura_diff_str)
    val diff_duration_cols_str = duration_cols_str.filter(_ == dura_diff_str)

    val ex_cols_str = (norm_dist_cols_str ++ diff_dist_cols_str).map(_ + "_ex")

    //里程判断 2次条件不变
    val cond1_norm_cols = norm_dist_cols_str.map(x => col(x).cast("double")).map { x => when(x > threshold, 1).otherwise(0) }
    val cond1_diff_cols = diff_dist_cols_str.map(x => col(x).cast("double")).map { x => when(x > diff_threshold, 1).otherwise(0) }
    //需要2次异常判断
    var cond2_norm_cols = Seq(lit(""))
    var cond2_diff_cols = Seq(lit(""))

    if (flag == "first") {
      //时段速度判断 时长里程同时判断
      cond2_norm_cols = norm_dist_cols_str.map(x => col(x).cast("double")) zip norm_duration_cols_str.map(x => col(x).cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
      cond2_diff_cols = diff_dist_cols_str.map(x => col(x).cast("double")) zip diff_duration_cols_str.map(x => col(x).cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    if (flag == "second") {
      //时段速度判断 时长里程同时判断
      cond2_norm_cols = norm_dist_cols_str.map(x => col(x).cast("double")) zip norm_duration_cols_str.map(x => col(x + "_fix").cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
      cond2_diff_cols = diff_dist_cols_str.map(x => col(x).cast("double")) zip diff_duration_cols_str.map(x => col(x + "_fix").cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    val cond1 = cond1_norm_cols ++ cond1_diff_cols
    val cond2 = cond2_norm_cols ++ cond2_diff_cols

    //(c1,c2)
    val res_cols = cond1 zip cond2 map { x => when(x._1 === 1 || x._2 === 1, 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 分路段 dist 异常判断
   *
   * @param fld_cols_str
   * @param t_dist
   * @param threshold
   * @return
   */
  def fldDistCond(fld_cols_str: Seq[String], t_dist: Column, threshold: Long): Seq[Column] = {
    val ex_cols_str = fld_cols_str.map(_ + "_ex")
    val res_cols = fld_cols_str.map(x => col(x).cast("double")).map { x => when(x > compareMinCol(0)(lit(threshold), t_dist * 1.1).cast("double"), 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 分设施 里程dist  异常判断
   *
   * @param dist_cols_str
   * @param duration_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fssDistCond(dist_cols_str: Seq[String], duration_cols_str: Seq[String], t_dist: Column, threshold: Long, flag: String): Seq[Column] = {
    val ex_cols_str = dist_cols_str.map(_ + "_ex")
    //里程判断 两次条件不变
    val cond1 = dist_cols_str.map(x => col(x).cast("double")).map { x => when(x > compareMinCol(0)(t_dist * 1.1, lit(threshold)).cast("double"), 1).otherwise(0) }
    //需要第2次异常判断
    var cond2 = Seq(lit(""))

    if (flag == "first") {
      cond2 = dist_cols_str.map(x => col(x).cast("double")) zip duration_cols_str.map(x => col(x).cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    if (flag == "second") {
      cond2 = dist_cols_str.map(x => col(x).cast("double")) zip duration_cols_str.map(x => col(x + "_fix").cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    //((c1,c2),c3)
    val res_cols = cond1 zip cond2 map { x => when(x._1 === 1 || x._2 === 1, 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 分时段 时长duration 异常判断
   *
   * @param duration_cols_str
   * @param dist_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fsdDuraCond(duration_cols_str: Seq[String], dist_cols_str: Seq[String], dura_diff_str: String, dist_diff_str: String, threshold: Long, diff_threshold: Long): Seq[Column] = {
    val norm_duration_cols_str = duration_cols_str.filter(_ != dura_diff_str)
    val diff_duration_cols_str = duration_cols_str.filter(_ == dura_diff_str)

    val ex_cols_str = (norm_duration_cols_str ++ diff_duration_cols_str).map(_ + "_ex")

    val norm_dist_cols_str = dist_cols_str.filter(_ != dist_diff_str)
    val diff_dist_cols_str = dist_cols_str.filter(_ == dist_diff_str)
    //行驶时长判断
    val cond1_norm_cols = norm_duration_cols_str.map(x => col(x).cast("double")).map { x => when(x > threshold, 1).otherwise(0) }
    val cond1_diff_cols = diff_duration_cols_str.map(x => col(x).cast("double")).map { x => when(x > diff_threshold, 1).otherwise(0) }
    val cond1 = cond1_norm_cols ++ cond1_diff_cols

    //时长里程同时判断
    val cond2 = (norm_dist_cols_str ++ diff_dist_cols_str).map(x => col(x).cast("double")) zip (norm_duration_cols_str ++ diff_duration_cols_str).map(x => col(x).cast("double")) map { x => when(x._1 > 5000 && x._2 === 0, 1).otherwise(0) }

    //(c1,c2)
    val res_cols = cond1 zip cond2 map { x => when(x._1 === 1 || x._2 === 1, 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 分道路设施 时长duration 异常判断
   *
   * @param duration_cols_str
   * @param dist_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fssDuraCond(duration_cols_str: Seq[String], dist_cols_str: Seq[String], t_duration: Column, threshold: Long): Seq[Column] = {
    val ex_cols_str = duration_cols_str.map(_ + "_ex")
    //行驶时长判断 时长里程同时判断
    val res_cols = dist_cols_str.map(x => col(x).cast("double")) zip duration_cols_str.map(x => col(x).cast("double")) map { x => when(x._2 > compareMinCol(0)(lit(threshold), t_duration * 1.1).cast("double") || (x._1 > 5000 && x._2 === 0), 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }
}

