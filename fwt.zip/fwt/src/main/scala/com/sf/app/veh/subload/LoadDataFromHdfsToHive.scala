package com.sf.app.veh.subload

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.DateUtil.getInterDateList
import utils.SparkBuilder

/**
 * @task_id:
 * @description: 加载数据至hive表中
 * @demander: 01402323 罗祯
 * @author 01418539 caojia
 * @date 2023/2/24 14:08
 */
object LoadDataFromHdfsToHive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    //export_20230202.csv.gz
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    //    val file_name = args(0)
    //    loadFileFromHdfs(spark, file_name)
    logger.error("=======================")
    val start_day = args(0)
    val end_day = args(1)
    loadYearCycleFromHdfs2Hive(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")

  }

  def loadYearCycleFromHdfs2Hive(spark: SparkSession, start_day: String, end_day: String): Unit = {
    val day_list_str = getInterDateList(start_day, end_day, "yyyy-MM-dd")

    val day_list = day_list_str.split(",")
    //拼装结果字段
    val cols_name = spark.sql(s"""select * from dm_gis.insurance_model_duration_dist_daily_0313 limit 0""").schema.map(_.name)
    var res_df = spark.sql(s"""select * from dm_gis.insurance_model_duration_dist_daily_0313 limit 0""")

    for (day <- day_list) {
      try {
        val inputPath = "/user/01418539/upload/file/insur0313/" + day + ".csv"
        val vehicle_df = spark.read.option("header", "false").option("delimiter", "\\t").option("inferSchema", true.toString)
          .option("numPartitions", 100).csv(inputPath)
          .toDF((cols_name :+ "blank"): _*)
          .withColumn("ak", col("ak").cast("string"))
          .repartition(50)
          .select(cols_name.map(col): _*)

        res_df = res_df.union(vehicle_df)
      } catch {
        case e: Exception => logger.error("日期文件不存在：" + day + ".csv")
      }
    }

    writeToHive(spark, res_df, Seq("inc_day", "ak"), "dm_gis.insurance_model_duration_dist_daily_0313")
  }

  def loadFileFromHdfs(spark: SparkSession, file_name: String): Unit = {
    val inputPath = "/user/01418539/upload/file/insurance/" + file_name
    //拼装结果字段
    val cols_name = spark.sql(s"""select * from dm_gis.insurance_model_duration_dist_daily_np limit 0""").schema.map(_.name)
    val vehicle_df = spark.read.option("header", "false").option("delimiter", "\\t").option("inferSchema", true.toString).option("compresstion", "gzip")
      .option("numPartitions", 100).csv(inputPath)
      .toDF(cols_name: _*)
      .withColumn("ak", col("ak").cast("string"))
      .repartition(50)
      .select(cols_name.map(col): _*)

    //    val sf_arr = new Array[StructField](cols_name.size)
    //    for (i <- 0 until cols_name.size) {
    //      sf_arr(i) = StructField(cols_name(i), StringType, false)
    //    }
    //    val newSchema = StructType(sf_arr)
    //    val res_df = spark.createDataFrame(vehicle_df.rdd, newSchema)

    //    writeToHive(spark, vehicle_df, Seq("inc_day", "ak"), "dm_gis.insurance_model_duration_dist_daily_np")
    writeToHive(spark, vehicle_df, Seq("inc_day", "ak"), "dm_gis.insurance_model_duration_dist_daily_np_new")
  }
}
