package com.sf.app.navi

import com.alibaba.fastjson.JSONObject
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{SaveMode, SparkSession}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

/**
 * @description:
 * @author 01418539 caojia
 * @date 2022/7/18 下午3:28
 */
object StandLineRouteMerge extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processGetsubid(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processGetsubid(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val days_3_bef = getdaysBeforeOrAfter(inc_day, -3) //20220718  3天前：20220715

    val task_subid_arr = Seq("531Y64931952", "991Y23689561", "028Y77938261", "571Y119007762", "451Y29525771", "931Y30828961", "771Y46691231", "752Y27874511", "931Y30921162", "791Y44393621", "579Y46514811", "023Y43260012", "029Y48704952", "898Y13228201", "755Y126081181", "574Y57748331", "574Y57722432", "731Y64603721", "551Y65339601", "577Y50357352", "029Y48923812", "591Y41202882", "311Y62209561", "029Y48704332", "871Y40114532", "579Y46508691", "311Y62220052", "769Y60987092", "536Y54738462", "517Y46940382", "471Y26295602", "451Y29530341", "371Y78384702", "871Y40192072", "871Y40180832", "991Y23790592", "769Y60570412", "451Y29651211", "752Y27502291", "028Y78399871", "757Y41501341", "991Y23667532", "451Y29594582").map("'" + _ + "'").mkString(",")

    //eta标准线路  day 17w
    val o_line_rectify = spark.sql(
      s"""
         |select task_id,
         |       task_subid,
         |       rt_coords,
         |       task_inc_day,
         |       start_dept,
         |       end_dept,
         |       line_code,
         |       actual_capacity_load,
         |       start_time,
         |       inc_day
         |from dm_gis.eta_std_line_rectify
         |where inc_day = '$inc_day'
         |      and task_subid in ($task_subid_arr)
         |""".stripMargin)
    //标准线路 路径 day
    val o_line_route = spark.sql(
      s"""
         |select std_coords,
         |       start_dept,
         |       end_dept,
         |       line_code,
         |       actual_capacity_load,
         |       start_time,
         |       inc_day task_inc_day
         |from dm_gis.eta_std_line_route
         |where inc_day >= '$days_3_bef' and inc_day <= '$inc_day'
         |""".stripMargin)

    val r_coords = o_line_rectify.join(o_line_route, Seq("task_inc_day", "start_dept", "end_dept", "line_code", "actual_capacity_load", "start_time"), "left")
      .select("task_subid", "rt_coords", "std_coords", "inc_day")
      .repartition(200)
      .map(row => {
        val task_subid = row.getAs[String]("task_subid")
        val rt_coords = row.getAs[String]("rt_coords")
        val std_coords = row.getAs[String]("std_coords")
        val inc_day = row.getAs[String]("inc_day")
//        val jsonObj = new JSONObject(true)
//        jsonObj.put("task_subid", task_subid)
//        jsonObj.put("rt_coords", rt_coords)
//        jsonObj.put("std_coords", std_coords)

        (task_subid,rt_coords,std_coords, inc_day)
      }).toDF("task_subid","rt_coords","std_coords", inc_day)

    writeToHive(spark,r_coords.coalesce(1),Seq("inc_day"),"dm_gis.eta_std_line_tracks")

  }
}
