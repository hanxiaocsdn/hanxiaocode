package com.sf.app.scm

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions.{col, regexp_replace, substring}
import org.apache.spark.sql.{Column, SparkSession}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.JDBCUtils.{getSCMDevMysqlConnect, queryTablesInMysql}
import utils.SparkBuilder

/**
 * @task_id: 614429
 * @description: 表同步 里程提报数据 mysql2bdp "exception_report_line" 每天更新当天 up_tm = report_time
 * @demander: 01432447 陈俊璋
 * @author 01418539 caojia
 * @date 2023/11/28 09:55
 */
object LoadExceptionReportFromMysql2Hive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val flag = args(1)
    val mysql_tn = Seq("exception_report_line")
    for (mysqlTN <- mysql_tn) {
      run(spark, mysqlTN, inc_day, flag)
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, mysqlTN: String, inc_day: String, flag: String): Unit = {
    val conn_mysql = getSCMDevMysqlConnect()
    if (flag == "0") queryTablesInMysql(conn_mysql, "plan", mysqlTN)
    if (flag != "0") loadEfficientMysqlToHive(spark, mysqlTN, inc_day)
  }

  /**
   * 读取mysql表中的数据写入hive表中
   *
   * @param spark
   * @param mysqlTable
   * @param hiveTable
   */
  def loadEfficientMysqlToHive(spark: SparkSession, mysql_tn: String, inc_day: String): Unit = {
    val hive_table_struct: String = spark.sql(s"select * from dm_gis.$mysql_tn limit 0").schema.toList.map(_.name).filter(_ != "up_tm").mkString(",")
    val res_cols: Seq[Column] = spark.sql(s"select * from dm_gis.$mysql_tn limit 0").schema.map(_.name).map(col)
    val day_1_bef = getdaysBeforeOrAfter(inc_day, -1) //t-37
    val query_state: String = s"""(select $hive_table_struct from $mysql_tn where replace(substring(report_time,1,10),'-','') between '$day_1_bef' and '$inc_day') as tmp"""
    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://plan-m.db.sfcloud.local:3306/plan?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai",
      "user" -> "plan",
      "password" -> "plan20210121#",
      "dbtable" -> query_state)

    val df = spark.read.format("jdbc").options(params).load()
      .withColumn("up_tm", regexp_replace(substring(col("report_time"), 0, 10), "-", ""))
      .select(res_cols: _*)

    df.show(2)
    try {
      logger.error("获取的mysql中数据总量为：" + df.count())
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        writeToHive(spark, df.coalesce(2), Seq("up_tm"), s"dm_gis.$mysql_tn")
      } else {
        throw new Exception(s"mysql的 $mysql_tn 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $mysql_tn 中 插入数据时出现错误", ex)
        throw ex
    }
  }

}
