package com.sf.app.core

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import constant.HttpConstant.{HTTP_EVENT_REPORT_COND_P, HTTP_QUERY_ROAD_ATTR_P}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter}
import utils.{HttpInvokeUtil, SparkBuilder}

import java.util.StringTokenizer
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 681560 （已下线，每月执行一次）
 * @description: 筛选中转场--数据支撑
 * @demander:ft80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/3/15 9:42
 */
case class InterBack(task_id: String, task_subid: String, start_dept: String, province_start: String, end_dept: String, province_end: String, vehicle_serial: String, actual_depart_tm: String, actual_arrive_tm: String, transoport_level: String, start_station: String, start_high: String, start_coords: String, end_station: String, end_high: String, end_coords: String, inc_day: String)

object SupportingTransitHighwayArea extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val run_flag = args(1)
    if (run_flag == "0") siftingRecall(spark, inc_day)
    if (run_flag != "0") {
      getCoordsInter(spark, siftingRecall(spark, inc_day))
    }
    //    logger.error(">>>>>>.csv格式数据写入")
    //    saveCsv(spark)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  /**
   * 第1步 数据来源加工 近1个月数据
   *
   * @param spark
   */
  def siftingRecall(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    val last_month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
    val last_month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, 0) //本月第1天
    //recall 187751
    val sql =
      s"""select task_id,task_subid,start_dept,end_dept,vehicle_serial,rt_coords,actual_depart_tm,actual_arrive_tm,transoport_level,row_number() over(partition by task_subid order by last_update_tm desc) as rn  from dm_gis.eta_std_line_recall
         |where inc_day between '$last_month_first_day' and '$month_first_day' and regexp_replace(substr(actual_depart_tm, 0,10),'-','') between '$last_month_first_day' and '$last_month_last_day'
         |and transoport_level in ('1','2')
         |""".stripMargin
    logger.error("sql:" + sql)
    val o_recall_df = spark.sql(sql)
      .filter('rn === 1) //.limit(1000)

    val o_dim_df = spark.sql("""select dept_code,city_name,provinct_name,if(dept_type_name in ('陆运枢纽','片区中转场','临时中转场','集包中心'),'1','2') flag from dim.dim_department""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val res_cols = spark.sql("""select * from dm_gis.dwd_core_recall_info limit 0""").schema.map(_.name).map(col)
    val filter_cond = trim('transoport_level) === "2" && 'city_name_start === 'city_name_end

    val res_df = o_recall_df
      .join(broadcast(o_dim_df), expr("start_dept = dept_code or end_dept = dept_code")).repartition(400)
      .withColumn("city_name_start", when(trim('start_dept) =!= "" and 'start_dept === 'dept_code, 'city_name))
      .withColumn("city_name_end", when(trim('end_dept) =!= "" and 'end_dept === 'dept_code, 'city_name))
      .na.fill("", Seq("city_name_start", "city_name_end"))
      .groupBy("task_id", "task_subid", "start_dept", "end_dept", "vehicle_serial", "rt_coords", "actual_depart_tm", "actual_arrive_tm", "transoport_level")
      .agg(
        max("city_name_start") as "city_name_start",
        max("city_name_end") as "city_name_end"
      ).filter(!filter_cond)
      .join(broadcast(o_dim_df.filter('flag === "1")), expr("start_dept = dept_code or end_dept = dept_code")).repartition(200)
      .withColumn("province_start", when(trim('start_dept) =!= "" and 'start_dept === 'dept_code, 'provinct_name))
      .withColumn("province_end", when(trim('end_dept) =!= "" and 'end_dept === 'dept_code, 'provinct_name))
      .na.fill("", Seq("province_start", "province_end"))
      .groupBy("task_id", "task_subid", "start_dept", "end_dept", "vehicle_serial", "rt_coords", "actual_depart_tm", "actual_arrive_tm", "transoport_level")
      .agg(
        max("province_start") as "province_start",
        max("province_end") as "province_end"
      )
      .withColumn("inc_day", lit(month_first_day))
      .select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    writeToHive(spark, res_df.coalesce(20), Seq("inc_day"), "dm_gis.dwd_core_recall_info") //45w
    o_dim_df.unpersist()
    res_df
  }

  /**
   * 生产环境 全量接口调用
   * 实际接口调用次数，数据量* 接口1 + 数据量* （start_coords个数+end_coords个数) * 接口2 ~~ 5-10倍数据量
   * 20min
   *
   * @param spark
   */
  def getCoordsInter(spark: SparkSession, o_recall_info: DataFrame): Unit = {
    import spark.implicits._
    //    val o_recall_info = spark.sql("""select * from dm_gis.dwd_core_recall_info""").persist()
    val res_cols = spark.sql("""select * from dm_gis.dwd_core_recall_info_dtl limit 0""").schema.map(_.name).map(col)

    val res_df = o_recall_info.repartition(30).map(row => {
      val task_id = row.getAs[String]("task_id")
      val task_subid = row.getAs[String]("task_subid")
      val start_dept = row.getAs[String]("start_dept")
      val province_start = row.getAs[String]("province_start")
      val end_dept = row.getAs[String]("end_dept")
      val province_end = row.getAs[String]("province_end")
      val vehicle_serial = row.getAs[String]("vehicle_serial")
      val actual_depart_tm = row.getAs[String]("actual_depart_tm")
      val actual_arrive_tm = row.getAs[String]("actual_arrive_tm")
      val transoport_level = row.getAs[String]("transoport_level")
      val inc_day = row.getAs[String]("inc_day")
      val rt_coords = row.getAs[String]("rt_coords").replaceAll("\\[\\[|\\]\\]|\\r|\\t", "").replaceAll("\\],\\[", "|")
      val inter_res = getPostReq(rt_coords)

      val start_station = inter_res._1
      val start_high = inter_res._2
      val start_coords = if (inter_res._3 == "" || inter_res._3.isEmpty) "" else getPolyline(inter_res._3)

      val end_station = inter_res._4
      val end_high = inter_res._5
      val end_coords = if (inter_res._6 == "" || inter_res._6.isEmpty) "" else getPolyline(inter_res._6)
      InterBack(task_id, task_subid, start_dept, province_start, end_dept, province_end, vehicle_serial, actual_depart_tm, actual_arrive_tm, transoport_level, start_station, start_high, start_coords, end_station, end_high, end_coords, inc_day)
    }).toDF().select(res_cols: _*).persist()
    logger.error(">>>加载的数据总量为：>>" + res_df.count())
    o_recall_info.unpersist()
    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.dwd_core_recall_info_dtl")
    o_recall_info.unpersist()
    res_df.unpersist()
  }

  /**
   * 线下离线数据 时 数据取出
   *
   * @param spark
   */
  def saveCsv(spark: SparkSession): Unit = {
    val res_df = spark.sql("""select * from dm_gis.dwd_core_recall_info""")
    //csv的属性信息
    val path = "/user/01418539/upload/file/recall_info"
    val options = Map(
      "header" -> "true",
      "delimiter" -> "\\t",
      "compression" -> "gzip",
      "inferSchema" -> true.toString
    )
    writeToCsv(spark, res_df.coalesce(4), SaveMode.Overwrite, "20230301", options, path, false)
  }

  def getPostReq(rt_coords: String): (String, String, String, String, String, String) = {
    var start_station, lnk_type, lnk_type_r, start_high, start_coords, end_station, end_high, end_coords = ""
    var flag_1, flag_2, flag_3, flag_1_r, flag_2_r, flag_3_r = true
    val start_coords_ab = new ArrayBuffer[String]()
    val end_coords_ab = new ArrayBuffer[String]()
    val end_coords_ab_rn = new ArrayBuffer[String]()
    val params =
      s"""{"ak": "93ec117f7f1b4226b4e537c4802319e9",
         |    "points": "$rt_coords",
         |    "vehicle": "6",
         |    "opt": "sf4"
         |}""".stripMargin
    //    logger.error(params)
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_EVENT_REPORT_COND_P, params, 3, 2)
      logger.error(">>>>>>>>>>接口1111：输出>>>>")
      val hw_str_json = JSON.parseObject(hw_str)
      val route = hw_str_json.getJSONObject("route")
      if (route != null) { //3828 toll_name
        val paths_arr = route.getJSONArray("paths")
        if (paths_arr != null && paths_arr.size() > 0) {
          breakable {
            for (i <- 0 until paths_arr.size()) {
              val steps_arr = paths_arr.getJSONObject(i).getJSONArray("steps")
              if (steps_arr != null && steps_arr.size() > 0) {
                for (j <- 0 until steps_arr.size()) {
                  val links_arr = steps_arr.getJSONObject(j).getJSONArray("links")
                  if (links_arr != null && links_arr.size() > 0) {
                    for (k <- 0 until links_arr.size()) {
                      val lnk_type_tmp = links_arr.getJSONObject(k).getString("lnk_type")
                      if (lnk_type_tmp == "2" && flag_1) {
                        lnk_type = "2"
                        flag_1 = false
                      }
                      if (lnk_type == "2") {
                        val toll_name = links_arr.getJSONObject(k).getString("toll_name")
                        val name = links_arr.getJSONObject(k).getString("name")
                        val sw_id = links_arr.getJSONObject(k).getString("sw_id")
                        start_coords_ab += sw_id
                        if (toll_name != null && toll_name.trim != "" && flag_2) {
                          start_station = toll_name
                          flag_2 = false
                        }
                        if (name != null && name.contains("高速") && !name.contains("高速入口") && !name.contains("高速出口") && flag_3) {
                          start_high = name
                          flag_3 = false
                          break
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          breakable {
            for (i <- (0 until paths_arr.size()).reverse) {
              val steps_arr = paths_arr.getJSONObject(i).getJSONArray("steps")
              if (steps_arr != null && steps_arr.size() > 0) {
                for (j <- (0 until steps_arr.size()).reverse) {
                  val links_arr = steps_arr.getJSONObject(j).getJSONArray("links")
                  if (links_arr != null && links_arr.size() > 0) {
                    for (k <- (0 until links_arr.size()).reverse) {
                      val lnk_type_tmp = links_arr.getJSONObject(k).getString("lnk_type")
                      if (lnk_type_tmp == "2" && flag_1_r) {
                        lnk_type_r = "2"
                        flag_1_r = false
                      }
                      if (lnk_type_r == "2") {
                        val toll_name = links_arr.getJSONObject(k).getString("toll_name")
                        val name = links_arr.getJSONObject(k).getString("name")
                        val sw_id = links_arr.getJSONObject(k).getString("sw_id")
                        end_coords_ab += sw_id
                        if (toll_name != null && toll_name.trim != "" && flag_2_r) {
                          end_station = toll_name
                          flag_2_r = false
                        }
                        if (name != null && name.contains("高速") && !name.contains("高速入口") && !name.contains("高速出口") && flag_3_r) {
                          end_high = name
                          flag_3_r = false
                          break
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          start_coords = start_coords_ab.mkString("|")
          for (m <- (0 until end_coords_ab.size).reverse) {
            end_coords_ab_rn += end_coords_ab(m)
          }
          end_coords = end_coords_ab_rn.mkString("|")
        }
      }
    } catch {
      case e: Exception => logger.error("=====" + e)
    }
    (start_station, start_high, start_coords, end_station, end_high, end_coords)
  }

  def getPolyline(swId: String): String = {
    val coords = new ArrayBuffer[String]()
    try {
      if (swId != null && !swId.isEmpty) {
        val swid_arr = new StringTokenizer(swId, "\\|")
        for (i <- 0 until swid_arr.countTokens()) {
          val swid_info = swid_arr.nextToken()
          val params =
            s"""{
               |"ak": "93ec117f7f1b4226b4e537c4802319e9",
               |"swId": "$swid_info",
               |"output": "json",
               |"roadAttrToken": "6134FAA5B6B6ED55E87EA116466734ED"
               |}""".stripMargin
          val pl_str = HttpInvokeUtil.sendPost(HTTP_QUERY_ROAD_ATTR_P, params, 3, 2)
          val pl_str_json = JSON.parseObject(pl_str)
          logger.error(">>>>>>>>>>接口22222：输出>>>>")
          val line = pl_str_json.getJSONObject("line")
          if (line != null) {
            val polyline_arr = line.getJSONArray("polyline")
            if (polyline_arr != null && polyline_arr.size() > 0) {
              val serials_xy = new ArrayBuffer[String]()
              var x: java.lang.Long = polyline_arr.getJSONObject(0).getLong("x")
              var y: java.lang.Long = polyline_arr.getJSONObject(0).getLong("y")
              serials_xy += (x / 3600000.0).toString + "," + (y / 3600000.0).toString
              for (i <- 1 until polyline_arr.size()) {
                val X = polyline_arr.getJSONObject(i).getLong("x")
                val Y = polyline_arr.getJSONObject(i).getLong("y")
                x += X
                y += Y
                serials_xy += (x / 3600000.0).toString + "," + (y / 3600000.0).toString
              }
              coords += serials_xy.mkString("|")
            }
          }
        }
      }
    }
    catch {
      case e: Exception => logger.error("异常" + e)
    }
    coords.mkString("|")
  }
}
