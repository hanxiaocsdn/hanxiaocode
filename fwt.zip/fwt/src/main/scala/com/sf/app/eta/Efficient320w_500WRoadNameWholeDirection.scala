package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

/**
 * @task_id: 757166 （双周运行10号/25号）
 * @description: 流向维度行业高速时速 dm_gis.eta_track_qg_direction_speed_dtl
 * @demander:廖静文 01430321
 * @author 01418539 caojia
 * @date 2023/11/20 10:34
 */
object Efficient320w_500WRoadNameWholeDirection extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    //t-6 == inc_day 对应的日期
    val days_37_bef = getdaysBeforeOrAfter(inc_day, -37) //t-37
    val days_35_bef = getdaysBeforeOrAfter(inc_day, -35) //t-35
    val days_6_bef = getdaysBeforeOrAfter(inc_day, -6) //t-6
    val days_4_bef = getdaysBeforeOrAfter(inc_day, -4) //t-4
    getQuanguoDirectionData(spark, inc_day, days_37_bef, days_35_bef, days_6_bef, days_4_bef)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")

  }

  def getQuanguoDirectionData(spark: SparkSession, inc_day: String, days_37_bef: String, days_35_bef: String, days_6_bef: String, days_4_bef: String): Unit = {
    import spark.implicits._
    val qg_500w_sql =
      s"""
         |select * from (select row_number() over(partition by key_word order by time_highspeed_start_rep desc) as rank_num,*
         |from
         |(select un,highspeed_start_time,highspeed_start_hour,highspeed_end_time,concat(un,'_',highspeed_start_time,'_',highspeed_end_time) as key_word,city_start start_city,city_end end_city,direction,speed_highspeed_tl_2,time_highspeed_start_rep,inc_day
         |from dm_gis.eta_track_highway_detail_3d_with_328_city
         |where inc_day between '$days_37_bef' and '$days_4_bef'
         |  and cast(highspeed_dist_ratio as double) >= 0.8   -----------高速里程占比
         |  and cast(speed_highspeed_tl_2 as double) >= 50  -----------高速时速
         |  and cast(speed_highspeed_tl_2 as double) <= 120  ----------高速时速
         |  and cast(highspeed_dist as double) >= 50         -----------高速里程
         |  and cast(day_diff_duration as double) <= 60
         |  --and cast(wavg_road_track_continues_rate as double) >= 90
         |  --and cast(short_dist as double) < cast(highspeed_dist as double)
         |  and regexp_replace(time_highspeed_start_rep,'-','') between '$days_35_bef' and '$days_6_bef'
         |  ) a ) b
         |  where rank_num=1
         |""".stripMargin
    logger.error(">>加载的全国数据sql为>>" + qg_500w_sql)
    val org_qg_500w_df = spark.sql(qg_500w_sql).na.fill("", Seq("highspeed_start_hour", "speed_highspeed_tl_2")).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val res_cols = spark.sql(s"""select * from dm_gis.eta_track_qg_direction_speed_dtl limit 0""").schema.map(_.name).map(col)
    org_qg_500w_df.createOrReplaceTempView("org_qg_500w_df")
    val qg_500w_df = spark.sql(
      """select direction,start_city,end_city,count(key_word) as frequency,
        |percentile_approx(cast(speed_highspeed_tl_2 as double), array(0.05,0.1,0.15,0.2,0.25,0.3,0.35,0.4,0.45,0.5,0.55,0.6,0.65,0.7,0.75,0.80,0.85,0.9,0.95)) AS pt
        |from org_qg_500w_df group by direction,start_city,end_city""".stripMargin)
      .withColumn("highway_top95", 'pt(0))
      .withColumn("highway_top90", 'pt(1))
      .withColumn("highway_top85", 'pt(2))
      .withColumn("highway_top80", 'pt(3))
      .withColumn("highway_top75", 'pt(4))
      .withColumn("highway_top70", 'pt(5))
      .withColumn("highway_top65", 'pt(6))
      .withColumn("highway_top60", 'pt(7))
      .withColumn("highway_top55", 'pt(8))
      .withColumn("highway_top50", 'pt(9))
      .withColumn("highway_top45", 'pt(10))
      .withColumn("highway_top40", 'pt(11))
      .withColumn("highway_top35", 'pt(12))
      .withColumn("highway_top30", 'pt(13))
      .withColumn("highway_top25", 'pt(14))
      .withColumn("highway_top20", 'pt(15))
      .withColumn("highway_top15", 'pt(16))
      .withColumn("highway_top10", 'pt(17))
      .withColumn("highway_top5", 'pt(18))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
    writeToHive(spark, qg_500w_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_track_qg_direction_speed_dtl")
  }
}
