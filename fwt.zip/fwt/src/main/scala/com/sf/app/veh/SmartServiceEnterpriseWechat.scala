package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

/**
 * @task_id: 598054 （598109--前置ftp抽数至hdfs任务）
 * @description:智能客服 企微群聊天记录表
 * @demander: 01422522  黄晓冰
 * @author 01418539 caojia
 * @date 2022/12/8 16:31
 */
object SmartServiceEnterpriseWechat extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val flag = args(1)
    procPubData(spark, inc_day, flag)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def procPubData(spark: SparkSession, inc_day: String, flag: String): Unit = {
    val daily_cols_name = Seq("service_name", "group_nbs", "char_cnt", "mess_cnt", "word_cnt", "reply_nbs", "reply_time", "avg_reply_dura", "date")
    val week_cols_name = Seq("group_name", "cust_ser_word_cnt", "cust_ser_mess_cnt", "cust_ser_char_cnt", "yw_ser_word_cnt", "yw_ser_mess_cnt", "yw_ser_char_cnt", "yy_ser_word_cnt", "yy_ser_mess_cnt", "yy_ser_char_cnt", "sx_ser_word_cnt", "sx_ser_mess_cnt", "sx_ser_char_cnt", "hh_ser_word_cnt", "hh_ser_mess_cnt", "hh_ser_char_cnt", "yys_word_cnt", "yys_mess_cnt", "yys_char_cnt", "cust_word_cnt", "cust_mess_cnt", "cust_char_cnt", "cust_act_days", "total_mess_cnt", "group_act_degree", "week")
    processRead(spark, inc_day, flag, "time", "chat_result_mod.csv", "dm_gis.ods_smart_service_enterprise_wechat_log", Seq(""))
    processDailyReport(spark, inc_day, flag, "date", "daily_report.xls", "dm_gis.ods_smart_service_enterprise_wechat_daily_report", daily_cols_name)
    processDailyReport(spark, inc_day, flag, "week", "weekly_report.xls", "dm_gis.ods_smart_service_enterprise_wechat_weekly_report", week_cols_name)
  }

  def processRead(spark: SparkSession, inc_day: String, flag: String, tm: String, fname: String, tableN: String, cols_name: Seq[String]): Unit = {
    //拼装结果字段
    val res_cols = spark.sql(s"""select * from $tableN limit 0""").schema.map(_.name).map(col)
    val days_1_ago = getdaysBeforeOrAfter(inc_day, -1)
    val days_2_ago = getdaysBeforeOrAfter(inc_day, -2)
    val days_3_ago = getdaysBeforeOrAfter(inc_day, -3)
    val days_4_ago = getdaysBeforeOrAfter(inc_day, -4)
    val days_5_ago = getdaysBeforeOrAfter(inc_day, -5)
    val filter_cond = dealTime(col(tm)) === inc_day || dealTime(col(tm)) === days_1_ago || dealTime(col(tm)) === days_2_ago || dealTime(col(tm)) === days_3_ago  || dealTime(col(tm)) === days_4_ago  || dealTime(col(tm)) === days_5_ago
//    val chat_df = spark.read.format("com.crealytics.spark.excel")
//      .option("useHeader", "true") //是否首行为元数据
//      .load("/user/01418539/upload/file/smartser/" + fname)

    val chat_df = spark.read.option("header", "true")
      .option("delimiter", "\\t")
      .option("encoding", "utf-8") //utf-8
      .option("inferSchema", true.toString)
      .csv("/user/01418539/upload/file/smartser/" + fname)

    var res_df: DataFrame = null
    if (flag == "1") {
      res_df = chat_df
        .withColumn("inc_day", dealTime(col(tm)))
        .select(res_cols: _*)
    }
    if (flag != "1") {
      res_df = chat_df.filter(filter_cond)
        .withColumn("inc_day", dealTime(col(tm)))
        .select(res_cols: _*)
    }
    if (res_df != null) writeToHive(spark, res_df.coalesce(1), Seq("inc_day"), tableN)
  }

  def processDailyReport(spark: SparkSession, inc_day: String, flag: String, tm: String, fname: String, tableN: String, cols_name: Seq[String]): Unit = {
    //拼装结果字段
    val res_cols = spark.sql(s"""select * from $tableN limit 0""").schema.map(_.name).map(col)
    val days_1_ago = getdaysBeforeOrAfter(inc_day, -1)
    val days_2_ago = getdaysBeforeOrAfter(inc_day, -2)
    val days_3_ago = getdaysBeforeOrAfter(inc_day, -3)
    val days_4_ago = getdaysBeforeOrAfter(inc_day, -4)
    val days_5_ago = getdaysBeforeOrAfter(inc_day, -5)
    val filter_cond = dealTime(col(tm)) === inc_day || dealTime(col(tm)) === days_1_ago || dealTime(col(tm)) === days_2_ago || dealTime(col(tm)) === days_3_ago  || dealTime(col(tm)) === days_4_ago  || dealTime(col(tm)) === days_5_ago
    val chat_df = spark.read.format("com.crealytics.spark.excel")
      .option("useHeader", "false") //是否首行为元数据
      .load("/user/01418539/upload/file/smartser/" + fname)

    val sf_arr = new Array[StructField](cols_name.size)
    for (i <- 0 until cols_name.size) {
      sf_arr(i) = StructField(cols_name(i), StringType, false)
    }
    val newSchema = StructType(sf_arr)
    val tmp_df = spark.createDataFrame(chat_df.rdd, newSchema)
    var res_df: DataFrame = null
    if (flag == "1") {
      res_df = tmp_df
        .withColumn("inc_day", dealTime(col(tm)))
        .select(res_cols: _*)
    }
    if (flag != "1") {
      res_df = tmp_df.filter(filter_cond)
        .withColumn("inc_day", dealTime(col(tm)))
        .select(res_cols: _*)
    }
    if (res_df != null) writeToHive(spark, res_df.coalesce(1), Seq("inc_day"), tableN)
  }

  def dealTime = udf((time: String) => {
    var inc_day = ""
    try {
      if (!time.isEmpty && time.trim != "") {
        val whole_tm = time.split("\\s+")(0).split("-")
        var month = whole_tm(1)
        var day = whole_tm(2)
        if (whole_tm(1).size < 2) month = "0" + "" + whole_tm(1)
        if (whole_tm(2).size < 2) day = "0" + "" + whole_tm(2)
        inc_day = whole_tm(0) + "" + month + "" + day
      }
    } catch {
      case e: Exception => logger.error("日期中空指针异常" + e.getMessage)
    }
    inc_day
  })
}
