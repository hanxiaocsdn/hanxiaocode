package com.sf.app.veh

import com.sf.app.eta.EfficientLowerSpeedMerge.strNotNull
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getdaysBeforeOrAfter, timeToTimestampFormat}
import utils.SparkBuilder

import scala.collection.mutable.ListBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id:
 * @description: 任务数据_日（自营司机维度） dm_gis.insurance_model_task_alarm_dtl
 * @demander: 01412988 刘芮
 * @author 01418539 caojia
 * @date 2022/11/9 14:45
 */
object VehicleDriverTaskInfo extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processDriverTask(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processDriverTask(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val day_1_ago = getdaysBeforeOrAfter(inc_day, -1)
    val day_6_ago = getdaysBeforeOrAfter(inc_day, -6)
    val o_self_recall_df = getOrgData(spark, inc_day, day_6_ago).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val o_day_emp_code_df = o_self_recall_df.select("emp_code").filter('actual_depart_day === inc_day).distinct()
    val s1_week_df = o_self_recall_df.join(o_day_emp_code_df, Seq("emp_code")) //一周内的数据 仅保留当天有emp_code的数据信息
      .withColumn("task_cnt", when('actual_depart_day === inc_day, 1).otherwise(0))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //抽取当天 聚合拼接的字段
    val s21_agg_df = s1_week_df.filter('actual_depart_day === inc_day)
      .groupBy("emp_code")
      .agg(
        min('actual_depart_tm) as "earliest_depart_tm",
        max('actual_arrive_tm) as "latest_arrive_tm",
        sum('task_cnt) as "task_cnt",
        sum('actual_run_time) as "total_run_time",
        sum('rt_dist) as "total_rt_dist",
        sum('highwaymileage) as "total_highwaymileage",
        concat_ws("|", collect_set('vehicle_serial)) as "car_no",
        lit("") as "imei",
        lit("") as "type",
        concat_ws("|", collect_list('actual_depart_tm)) as "depart_tm_list",
        concat_ws("|", collect_list('actual_arrive_tm)) as "arrive_tm_list",
        concat_ws("|", collect_list('actual_run_time)) as "run_time_list",
        concat_ws("|", collect_set('transoport_level)) as "transoport_level_list"
      )
    val day_bef_tm = when('actual_depart_day === day_1_ago, concat_ws("_", 'actual_depart_tm, 'actual_arrive_tm))
    val s22_rest_df = s1_week_df.filter('actual_depart_day >= day_1_ago && 'actual_depart_day <= inc_day)
      .select("emp_code", "actual_depart_tm", "actual_arrive_tm", "actual_depart_day")
      .withColumn("day_bef_cnt", when('actual_depart_day === day_1_ago, 1).otherwise(0))
      .withColumn("day_bef_tm", day_bef_tm)
      .withColumn("start_end_tm", concat_ws("_", 'actual_depart_tm, 'actual_arrive_tm))
      .withColumn("day_start_end_tm", when('actual_depart_day === inc_day, concat_ws("_", 'actual_depart_tm, 'actual_arrive_tm)))
      .groupBy("emp_code")
      .agg(
        sum('day_bef_cnt) as "day_bef_cnt",
        concat_ws("|", sort_array(collect_list('day_bef_tm))) as "day_bef_tm_arr",
        concat_ws("|", sort_array(collect_list('start_end_tm))) as "start_end_tm_arr",
        concat_ws("|", sort_array(collect_list('day_start_end_tm))) as "day_start_end_tm_arr"
      )
      .withColumn("rest_tm_bef_task", restTimeBeforeTask(inc_day, day_6_ago)('start_end_tm_arr, 'day_bef_cnt, 'day_bef_tm_arr))
      .withColumn("avg_tm_interval", avgTaskTime(true)('day_start_end_tm_arr))
      .withColumn("tm_interval_list", avgTaskTime(false)('day_start_end_tm_arr))

    val s23_inter_tm_df = s1_week_df.select("emp_code", "actual_depart_day")
      .groupBy("emp_code").agg(concat_ws("|", collect_set('actual_depart_day)) as "actual_depart_day_arr")
      .withColumn("series_working_days", maxSerialDays(true)('actual_depart_day_arr))
      .withColumn("tm_period", maxSerialDays(false)('actual_depart_day_arr))

    val res_df_cols = spark.sql("""select * from dm_gis.insurance_model_task_alarm_dtl limit 0""").schema.map(_.name).map(col)
    val res_df = s21_agg_df.join(s22_rest_df, Seq("emp_code"))
      .join(s23_inter_tm_df, Seq("emp_code"))
      .withColumn("inc_day", lit(inc_day))
      .select(res_df_cols: _*)
    writeToHive(spark, res_df.coalesce(2), Seq("inc_day"), "dm_gis.insurance_model_task_alarm_dtl")
    s1_week_df.unpersist()
    o_self_recall_df.unpersist()
  }

  def avgTaskTime(flag: Boolean) = udf((day_start_end_tm_arr: String) => {
    var inter_seconds = 0l
    var avg_tm_interval = ""
    val inter_tms = new ListBuffer[String]()
    if (strNotNull(day_start_end_tm_arr)) {
      val tm_arr = day_start_end_tm_arr.split("\\|")
      for (i <- 0 until tm_arr.size) {
        try {
          val el_end_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(i).split("_")(1))
          if (i + 1 <= tm_arr.size - 1) {
            val la_start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(i + 1).split("_")(0))
            inter_seconds += la_start_tm - el_end_tm
            inter_tms += ((la_start_tm - el_end_tm) / 60).toString
          }
        } catch {
          case e: Exception => logger.error("1003异常：" + e.printStackTrace())
        }
      }
      if (flag) {
        if (tm_arr.size == 1) avg_tm_interval = "0.0"
        if (tm_arr.size > 1) avg_tm_interval = (inter_seconds / (tm_arr.size - 1) / 60).toString //min
      } else {
        avg_tm_interval = inter_tms.mkString("|")
      }
    }
    avg_tm_interval
  })

  def maxSerialDays(is_cycle: Boolean) = udf((actual_depart_day_arr: String) => {
    var serial_days = ""
    if (strNotNull(actual_depart_day_arr)) {
      val days_arr = actual_depart_day_arr.split("\\|").sortWith((x, y) => x > y)
      breakable {
        for (i <- 0 until days_arr.size) {
          if (i + 1 <= days_arr.size - 1) {
            if (days_arr(i).toInt - days_arr(i + 1).toInt > 1) {
              if (is_cycle) {
                serial_days = (days_arr(0).toInt - days_arr(i).toInt + 1).toString
              } else {
                serial_days = if (days_arr(i) != days_arr(0)) days_arr(i) + "_" + days_arr(0) else days_arr(0)
              }
              break
            }
          } else {
            if (is_cycle) {
              serial_days = "1"
            } else {
              serial_days = days_arr(0)
            }
          }
        }
      }
    }
    serial_days
  })

  /**
   * 计算任务前休息时长  min
   * 第1中情况 前1天任务数 0<=x<=1
   * 第2种情况 前2天任务数 x>=2
   *
   * @param inc_day
   * @param day_6_ago
   * @return
   */

  def restTimeBeforeTask(inc_day: String, day_6_ago: String) = udf((start_end_tm_arr: String, day_bef_cnt: Int, day_bef_tm_arr: String) => {
    val today_tm = timeToTimestampFormat("yyyyMMdd", inc_day)
    val day_6_ago_tm = timeToTimestampFormat("yyyyMMdd", day_6_ago)
    var tm_inter_across = 0l
    if (strNotNull(start_end_tm_arr)) {
      val tm_arr = start_end_tm_arr.split("\\|")
      var flag = true
      for (i <- (0 until tm_arr.size).reverse if flag) {
        try {
          val today_start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(i).split("_")(0))
          if (i - 1 >= 0) {
            //1 如果有>1条的任务信息 则需要进行后续的判断
            val bef_start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(i - 1).split("_")(0))
            val bef_end_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(i - 1).split("_")(1))
            val inter_seconds_p1 = today_start_tm - bef_end_tm
            if ((bef_end_tm <= today_tm && today_tm <= today_start_tm) || (bef_start_tm < today_tm && today_tm <= bef_end_tm)) {
              if (inter_seconds_p1 >= 8 * 3600) {
                tm_inter_across = inter_seconds_p1 //秒
                flag = false
              }
            }
          } else {
            //2 如果只有1条任务信息，则取最早日期与当天起始任务之间的时间差
            tm_inter_across = today_start_tm - day_6_ago_tm //秒
          }
        } catch {
          case e: Exception => logger.error("1001异常：" + e.printStackTrace())
        }
      }
    }
    if (tm_inter_across == 0 && day_bef_cnt > 1) {
      val tm_arr = day_bef_tm_arr.split("\\|")
      val o_early_start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(0).split("_")(0))
      for (i <- 0 until tm_arr.size) {
        try {
          val early_end_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(i).split("_")(1))
          if (i + 1 <= tm_arr.size - 1) {
            val later_start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tm_arr(i + 1).split("_")(0))
            val inter_seconds_p2 = later_start_tm - early_end_tm
            if (inter_seconds_p2 >= 8 * 3600 && inter_seconds_p2 >= tm_inter_across) {
              tm_inter_across = inter_seconds_p2
            }
          }
        } catch {
          case e: Exception => logger.error("1002异常：" + e.printStackTrace())
        }
      }
      if (tm_inter_across == 0) {
        tm_inter_across = o_early_start_tm - day_6_ago_tm
      }
    }
    (tm_inter_across / 3600).toString //h
  })

  def getOrgData(spark: SparkSession, inc_day: String, day_6_ago: String): DataFrame = {
    val o_recall_df = spark.sql(
      s"""
         |select task_id,main_driver_account emp_code,vehicle_serial,
         |       actual_depart_tm,regexp_replace(substring(actual_depart_tm,0,10),'-','') actual_depart_day,
         |       actual_arrive_tm,actual_run_time,rt_dist,highwaymileage,transoport_level,inc_day
         |from dm_gis.eta_std_line_recall1
         |where inc_day between '$day_6_ago' and '$inc_day'
         |      and main_driver_account is not null and trim(main_driver_account) !=''
         |      and regexp_replace(substring(actual_depart_tm,0,10),'-','') between '$day_6_ago' and '$inc_day'
         |""".stripMargin)

    val o_self_df = spark.sql(
      s"""
         |select attribute6 emp_code,inc_day from dm_arss.dm_alarm_detail_dtl_di
         |where inc_day between '$day_6_ago' and '$inc_day'
         |      and attribute6 is not null and trim(attribute6) !=''
         |group by attribute6,inc_day
         |""".stripMargin)
    o_recall_df.join(o_self_df, Seq("emp_code", "inc_day"))
  }
}
