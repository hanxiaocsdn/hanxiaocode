package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.ColumnUtil.primaryKeyEncrypt
import utils.DateUtil.{getFixedDayOfMonth, getdaysBeforeOrAfter}
import utils.SparkBuilder

/**
 * @task_id:（已下线20230710）444813
 * @description: 统计（充电桩、充电口） 全国 每天/月 充电桩和充电口变化 情况
 * @author 01418539 caojia
 * @date 2022/5/31 15:08
 */
object SmartDeviceDMChange extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val inc_day = args(0)

    val yesterday = getdaysBeforeOrAfter(inc_day, -1)
    val o_month_21 = getFixedDayOfMonth(inc_day, "21", 0) //20220521
    val o_last_22 = getFixedDayOfMonth(inc_day, "22", -1) //20220422
    val o_last_21 = getFixedDayOfMonth(inc_day, "21", -1) //20220421
    val t_last_22 = getFixedDayOfMonth(inc_day, "22", -2) //20220322
    val t_last_21 = getFixedDayOfMonth(inc_day, "21", -2) //20220321
    val ot_last_22 = getFixedDayOfMonth(inc_day, "22", -3) //20220222

    if (inc_day.substring(6).toInt >= 21) processStatistics(spark, inc_day, yesterday, o_month_21, o_last_22)
    if (inc_day.substring(6).toInt < 21) processStatistics(spark, inc_day, yesterday, o_last_21, t_last_22)

    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processStatistics(spark: SparkSession, inc_day: String, yesterday: String, o_month_21: String, o_last_22: String): Unit = {
    import spark.implicits._
    val o_device = spark.sql(
      s"""
         |select device_cnt,socket_cnt,inc_day --站点数量 设备总数
         |from dm_gis_oms.scomm_device_order_summary_provice
         |where inc_day in ('$inc_day','$yesterday','$o_month_21','$o_last_22')
         |""".stripMargin)

    val step = o_device.groupBy("inc_day")
      .agg(
        sum('device_cnt) as "device_cnt",
        sum('socket_cnt) as "socket_cnt",
        lit("1") as "flag"
      )
      .withColumn("inc_device", when('inc_day === inc_day, 'device_cnt).otherwise(0))
      .withColumn("inc_socket", when('inc_day === inc_day, 'socket_cnt).otherwise(0))
      .withColumn("yes_device", when('inc_day === yesterday, 'device_cnt).otherwise(0))
      .withColumn("yes_socket", when('inc_day === yesterday, 'socket_cnt).otherwise(0))
      .withColumn("o_month_21_device", when('inc_day === o_month_21, 'device_cnt).otherwise(0))
      .withColumn("o_month_21_socket", when('inc_day === o_month_21, 'socket_cnt).otherwise(0))
      .withColumn("o_last_22_device", when('inc_day === o_last_22, 'device_cnt).otherwise(0))
      .withColumn("o_last_22_socket", when('inc_day === o_last_22, 'socket_cnt).otherwise(0))
      .groupBy("flag")
      .agg(
        max("inc_device") as "inc_device",
        max("inc_socket") as "inc_socket",
        max("yes_device") as "yes_device",
        max("yes_socket") as "yes_socket",
        max("o_month_21_device") as "o_month_21_device",
        max("o_month_21_socket") as "o_month_21_socket",
        max("o_last_22_device") as "o_last_22_device",
        max("o_last_22_socket") as "o_last_22_socket"
      )
      .withColumn("device_day_sub", 'inc_device - 'yes_device)
      .withColumn("socket_day_sub", 'inc_socket - 'yes_socket)
      .withColumn("device_month_sub", 'o_month_21_device - 'o_last_22_device)
      .withColumn("socket_month_sub", 'o_month_21_socket - 'o_last_22_socket)
      .withColumn("inc_day", lit(inc_day))
      .withColumn("id", primaryKeyEncrypt(lit(""), lit(""), lit(""), lit(""), lit(""), lit(""), 'inc_day))
      .select("id", "inc_device","device_day_sub","device_month_sub", "inc_socket",  "socket_day_sub",  "socket_month_sub", "inc_day")
    //id  device_cnt  device_cnt_day  device_cnt_month  device_socket_cnt  device_socket_cnt_day  device_socket_cnt_month
    writeToHive(spark, step, Seq("inc_day"), "dm_gis.scomm_device_country")
  }


}
