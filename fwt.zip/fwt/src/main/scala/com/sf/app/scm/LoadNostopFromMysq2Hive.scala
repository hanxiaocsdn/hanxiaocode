package com.sf.app.scm

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.JDBCUtils.{getSCMDevMysqlConnect, queryTablesInMysql}
import utils.SparkBuilder

/**
 * @task_id: 674439 原始版本写入任务ID:453098
 * @description:GIS-RSS-SCM：【实时薪酬】平台不拆经停任务表同步需求 eta_std_line_nostop
 * @demander:王润泽 01422002
 * @author 01418539 caojia
 * @date 2023/3/9 16:00
 */
object LoadNostopFromMysq2Hive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val mysqlTN = args(1)
    val flag = args(2)
    processLoad(spark, mysqlTN, inc_day, flag)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processLoad(spark: SparkSession, mysqlTN: String, inc_day: String, flag: String): Unit = {
    val conn_mysql = getSCMDevMysqlConnect()
    if (flag == "0") queryTablesInMysql(conn_mysql, "plan", mysqlTN)
    if (flag != "0") loadNostopMysqlToHive(spark, "eta_std_line_nostop", inc_day)
  }

  /**
   * 读取mysql表中的数据写入hive表中
   *
   * @param spark
   * @param mysqlTable
   * @param hiveTable
   */
  def loadNostopMysqlToHive(spark: SparkSession, hiveTable: String, inc_day: String): Unit = {
    val hive_table_struct: String = spark.sql(s"select * from dm_gis.$hiveTable limit 0").schema.toList.filter(_.name != "inc_day").map(_.name).mkString(",")
    val res_cols: Seq[Column] = spark.sql(s"select * from dm_gis.$hiveTable limit 0").schema.map(_.name).map(col)

    val query_state = getQueryState(hive_table_struct, inc_day)
    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://plan-m.db.sfcloud.local:3306/plan?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai",
      "user" -> "plan",
      "password" -> "plan20210121#",
      "dbtable" -> query_state)

    try {
      val df:DataFrame = spark.read.format("jdbc").options(params).load()
        .withColumn("inc_day", lit(inc_day))
        .select(res_cols: _*)
      df.show(10)
      logger.error("获取的mysql中数据总量为：" + df.count())
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        writeToHive(spark,df,Seq("inc_day"),s"dm_gis.$hiveTable")
      } else {
        throw new Exception(s"mysql的 $hiveTable 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $hiveTable 中 插入数据时出现错误", ex)
        throw ex
    }
  }

  def getQueryState(hive_table_struct: String, inc_day: String): String = {
    val days_36_ago = getdaysBeforeOrAfter(inc_day, -35)
    var query_state, mysqlTN_1, mysqlTN_2, mysqlTN_3 = ""

    def query_state_1(mysqlTN_1: String): String =
      s"""
         |(select $hive_table_struct from $mysqlTN_1 where carrier_type = 0 and task_inc_day >= '$days_36_ago') as t
         |""".stripMargin

    def query_state_2(mysqlTN_1: String, mysqlTN_2: String): String =
      s"""
         |(select $hive_table_struct from $mysqlTN_1 where carrier_type = 0 and task_inc_day between '$days_36_ago' and '$inc_day'
         |union
         |select $hive_table_struct from $mysqlTN_2 where carrier_type = 0 and task_inc_day between '$days_36_ago' and '$inc_day') as t
         |""".stripMargin

    def query_state_3(mysqlTN_1: String, mysqlTN_2: String, mysqlTN_3: String): String =
      s"""
         |(select $hive_table_struct from $mysqlTN_1 where carrier_type = 0 and task_inc_day >= '$days_36_ago'
         |union
         |select $hive_table_struct from $mysqlTN_2 where carrier_type = 0 and task_inc_day >= '$days_36_ago'
         |union
         |select $hive_table_struct from $mysqlTN_3 where carrier_type = 0 and task_inc_day >= '$days_36_ago'
         |) as t
         |""".stripMargin

    if (inc_day.substring(0, 4) == "2023") {
      if (days_36_ago < "20230308" && inc_day < inc_day.substring(0, 4) + "0401") {
        mysqlTN_1 = "eta_std_line_nostop"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "01"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }

      if (days_36_ago < "20230308" && inc_day >= inc_day.substring(0, 4) + "0401") {
        mysqlTN_1 = "eta_std_line_nostop"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "01"
        mysqlTN_3 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "02"
        query_state = query_state_3(mysqlTN_1, mysqlTN_2, mysqlTN_3)
      }

      if ("20230308" <= days_36_ago && days_36_ago < inc_day.substring(0, 4) + "0401") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "01"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "02"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }

      if (inc_day.substring(0, 4) + "0401" <= days_36_ago && inc_day < inc_day.substring(0, 4) + "0701") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "02"
        query_state = query_state_1(mysqlTN_1)
      }

      if (days_36_ago < inc_day.substring(0, 4) + "0701" && inc_day >= inc_day.substring(0, 4) + "0701") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "02"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "03"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }

      if (inc_day.substring(0, 4) + "0701" <= days_36_ago && inc_day < inc_day.substring(0, 4) + "1001") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "03"
        query_state = query_state_1(mysqlTN_1)
      }

      if (days_36_ago < inc_day.substring(0, 4) + "1001" && inc_day >= inc_day.substring(0, 4) + "1001") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "03"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "04"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }

      if (inc_day.substring(0, 4) + "1001" <= days_36_ago && inc_day < (inc_day.substring(0, 4).toInt + 1).toString + "0101") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "04"
        query_state = query_state_1(mysqlTN_1)
      }
    }
    if (inc_day.substring(0, 4) != "2023") {
      if (days_36_ago < inc_day.substring(0, 4) + "0101" && inc_day >= inc_day.substring(0, 4) + "0101") {
        mysqlTN_1 = "eta_std_line_nostop_" + (inc_day.substring(0, 4).toInt - 1) + "04"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "01"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }
      if (inc_day.substring(0, 4) + "0101" <= days_36_ago && inc_day < inc_day.substring(0, 4) + "0401") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "01"
        query_state = query_state_1(mysqlTN_1)
      }
      if (days_36_ago < inc_day.substring(0, 4) + "0401" && inc_day >= inc_day.substring(0, 4) + "0401") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "01"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "02"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }
      if (inc_day.substring(0, 4) + "0401" <= days_36_ago && inc_day < inc_day.substring(0, 4) + "0701") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "02"
        query_state = query_state_1(mysqlTN_1)
      }

      if (days_36_ago < inc_day.substring(0, 4) + "0701" && inc_day >= inc_day.substring(0, 4) + "0701") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "02"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "03"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }

      if (inc_day.substring(0, 4) + "0701" <= days_36_ago && inc_day < inc_day.substring(0, 4) + "1001") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "03"
        query_state = query_state_1(mysqlTN_1)
      }

      if (days_36_ago < inc_day.substring(0, 4) + "1001" && inc_day >= inc_day.substring(0, 4) + "1001") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "03"
        mysqlTN_2 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "04"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }

      if (inc_day.substring(0, 4) + "1001" <= days_36_ago && inc_day < (inc_day.substring(0, 4).toInt + 1).toString + "0101") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "04"
        query_state = query_state_1(mysqlTN_1)
      }
      if (days_36_ago < (inc_day.substring(0, 4).toInt + 1).toString + "0101" && inc_day >= (inc_day.substring(0, 4).toInt + 1).toString + "0101") {
        mysqlTN_1 = "eta_std_line_nostop_" + inc_day.substring(0, 4) + "04"
        mysqlTN_2 = "eta_std_line_nostop_" + (inc_day.substring(0, 4).toInt + 1).toString + "01"
        query_state = query_state_2(mysqlTN_1, mysqlTN_2)
      }
    }
    logger.error("运行日期为:" + inc_day)
    logger.error("mysql中的查询语句：" + query_state)
    query_state

  }
}
