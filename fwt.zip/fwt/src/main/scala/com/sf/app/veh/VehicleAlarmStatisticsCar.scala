package com.sf.app.veh

import com.sf.app.veh.VehicleAlarmStatisticsDriver.{logger, writeToHive}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.timeToTimestamp_
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id:
 * @description: 告警统计数据_日（车辆维度表） insurance_model_alarm_statistic_car_dtl
 * @demander: 01412988 刘芮
 * @author 01418539 caojia
 * @date 2022/11/14 15:33
 */
object VehicleAlarmStatisticsCar {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processStaticsCar(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processStaticsCar(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val o_zy_alarm_df = spark.sql(
      s"""select car_no,imei,'zy' source,zy_type,p_type_r,sub_type_r,alarm_name,risk_level,defend_status,defend_submit_time,defend_recieve_time,inc_day
         |from dm_arss.dm_alarm_detail_dtl_di
         |where inc_day = '$inc_day' and car_no is not null and trim(car_no) != ''
         |""".stripMargin)

    val o_wb_alarm_df = spark.sql(
      s"""select car_no,imei,'wb' source,zy_type,p_type_r,sub_type_r,alarm_name,risk_level,defend_status,defend_submit_time,defend_recieve_time,inc_day
         |from dm_arss.dm_alarm_detail_wb_dtl_di
         |where inc_day = '$inc_day' and car_no is not null and trim(car_no) != ''
         |""".stripMargin)
    val o_alarm_df = o_zy_alarm_df.union(o_wb_alarm_df)
      .withColumn("defend_submit_time", timeToTimestamp_('defend_submit_time))
      .withColumn("defend_recieve_time", timeToTimestamp_('defend_recieve_time))
      .withColumn("defend_time", ('defend_submit_time - 'defend_recieve_time) / 60)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val o_mapping_alarm_df = spark.sql("""select p_type p_type_r,sub_type sub_type_r,alarm_name alarm_name_acc from dm_gis.alarm_type_mapping""".stripMargin)

    val s1_alarm_map_df = o_alarm_df.join(o_mapping_alarm_df, Seq("p_type_r", "sub_type_r"), "left")

    val org_df = diffAlarmNameDF(spark, "alarm_name", "1", o_alarm_df, inc_day)
    val acc_df = diffAlarmNameDF(spark, "alarm_name_acc", "2", s1_alarm_map_df, inc_day)
    val res_df = org_df.union(acc_df)

    writeToHive(spark, res_df.coalesce(2), Seq("inc_day"), "dm_gis.insurance_model_alarm_statistic_car_dtl")
    s1_alarm_map_df.unpersist()
  }

  def diffAlarmNameDF(spark: SparkSession, alarm_name: String, alarm_type: String, o_alarm_df: DataFrame, inc_day: String): DataFrame = {
    import spark.implicits._
    val dms_cols_str = Seq("dms_tired_cnt", "dms_eye_closed_cnt", "dms_yawn_cnt", "dms_yd_pl_cnt", "dms_yd_tired_cnt", "dms_dis_drive_cnt", "dms_dis_drive_dt_cnt", "dms_dis_drive_tt_cnt", "dms_phone_cnt", "dms_smoke_cnt", "dms_camera_occ_cnt", "dms_driver_abn_cnt", "dms_glasses_hide_cnt", "dms_block_glasses_cnt", "dms_driver_change_cnt")
    val adas_cols_str = Seq("adas_walker_coll_cnt", "adas_close_dist_cnt", "adas_road_depart_cnt", "adas_front_coll_cnt")
    val gj_cols_str = Seq("gj_rapid_acc_cnt", "gj_speed_limit_cnt", "gj_sudden_turn_cnt", "gj_sudden_dec_cnt", "gj_over_speed_cnt")
    val hod_cols_str = Seq("hod_play_cnt", "hod_off_wheel_cnt", "hod_no_belt_cnt")
    val bsd_cols_str = Seq("bsd_right_appro_cnt", "bsd_blind_area_cnt")
    val risk_cols_str = Seq("high_risk_level_cnt", "mid_risk_level_cnt", "low_risk_level_cnt")
    val defend_cols_str = Seq("defend_status_0_cnt", "defend_status_1_cnt", "defend_status_2_cnt")
    val pub_cols_str = Seq("imei", "zy_type")
    val defend_tm_cols_str = Seq("defend_time")
    val part_total_cols_str = Seq("dms_alarm_cnt", "adas_alarm_cnt", "gj_alarm_cnt", "hod_alarm_cnt", "bsd_alarm_cnt")

    val add_cols = pivoitCols(spark, alarm_name, dms_cols_str, adas_cols_str, gj_cols_str, hod_cols_str, bsd_cols_str, risk_cols_str, defend_cols_str)
    val agg_cols = aggFun(defend_tm_cols_str, pub_cols_str, dms_cols_str, adas_cols_str, gj_cols_str, hod_cols_str, bsd_cols_str, risk_cols_str, defend_cols_str)
    val splice_cols = spliceField(part_total_cols_str, dms_cols_str, adas_cols_str, gj_cols_str, hod_cols_str, bsd_cols_str)

    val s2_alarm_map_df = o_alarm_df.select(o_alarm_df.schema.map(_.name).map(col) ++ add_cols: _*).withColumn("alarm_type", lit(alarm_type))
      .groupBy("car_no", "source","alarm_type")
      .agg(agg_cols.head, agg_cols.tail: _*)
      .withColumn("risk_level_cnt", concat(lit("1:"), 'high_risk_level_cnt, lit(";2:"), 'mid_risk_level_cnt, lit(";3:"), 'low_risk_level_cnt))
      .withColumn("defend_status_cnt", 'defend_status_0_cnt + 'defend_status_1_cnt + 'defend_status_2_cnt)
      .withColumn("inc_day", lit(inc_day))
    val res_df_cols = spark.sql("""select * from dm_gis.insurance_model_alarm_statistic_car_dtl limit 0""").schema.map(_.name).map(col)
    val res_df = s2_alarm_map_df.select(s2_alarm_map_df.schema.map(_.name).map(col) ++ splice_cols: _*).select(res_df_cols: _*)

    res_df
  }

  def spliceField(part_total_cols_str: Seq[String], dms_cols_str: Seq[String], adas_cols_str: Seq[String], gj_cols_str: Seq[String], hod_cols_str: Seq[String], bsd_cols_str: Seq[String]): Seq[Column] = {
    val pub1_cols_str = dms_cols_str ++ adas_cols_str ++ gj_cols_str ++ hod_cols_str ++ bsd_cols_str
    val pub2_cols_str = Seq(dms_cols_str, adas_cols_str, gj_cols_str, hod_cols_str, bsd_cols_str)
    val part_total_cols = pub2_cols_str.map(x => x.map(col).foldLeft(lit(0))(_ + _))
    val alarm_cols = pub1_cols_str.map(col)
    val total_cols = alarm_cols.foldLeft(lit(0))(_ + _)

    ColumnUtil.renameColumn(part_total_cols :+ total_cols, part_total_cols_str :+ "alarm_cnt")
  }

  def aggFun(defend_tm_cols_str: Seq[String], pub_cols_str: Seq[String], dms_cols_str: Seq[String], adas_cols_str: Seq[String], gj_cols_str: Seq[String], hod_cols_str: Seq[String], bsd_cols_str: Seq[String], risk_cols_str: Seq[String], defend_cols_str: Seq[String]): Seq[Column] = {
    val alarm_cols_str = dms_cols_str ++ adas_cols_str ++ gj_cols_str ++ hod_cols_str ++ bsd_cols_str
    val risk_def_cols_str = risk_cols_str ++ defend_cols_str
    val step1_cols = ColumnUtil.renameColumn((defend_tm_cols_str ++ alarm_cols_str ++ risk_def_cols_str).map(col).map(sum(_)), defend_tm_cols_str ++ alarm_cols_str ++ risk_def_cols_str)
    val step2_cols = ColumnUtil.renameColumn(pub_cols_str.map(col).map(first(_)), pub_cols_str)
    step1_cols ++ step2_cols
  }

  def pivoitCols(spark: SparkSession, alarm_name: String, dms_cols_str: Seq[String], adas_cols_str: Seq[String], gj_cols_str: Seq[String], hod_cols_str: Seq[String], bsd_cols_str: Seq[String], risk_cols_str: Seq[String], defend_cols_str: Seq[String]): Seq[Column] = {
    import spark.implicits._
    val dms_cols = Seq("疲劳", "闭眼", "打哈欠", "云端算法-疲劳（闭眼）", "云端算法-打哈欠", "分心驾驶", "分心驾驶低头", "分心驾驶抬头", "打电话", "吸烟", "摄像头遮挡", "驾驶员异常", "墨镜遮挡", "阻断型墨镜", "驾驶员变更")
    val adas_cols = Seq("行人碰撞", "车距过近", "车道偏离", "前车碰撞")
    val gj_cols = Seq("急加速", "超限速告警", "急转弯", "急减速", "超速")
    val hod_cols = Seq("玩手机", "双手脱离方向盘", "未系安全带")
    val bsd_cols = Seq("右侧后方接近报警", "盲区行人报警")
    val risk_level_cols = Seq("1", "2", "3")
    val defend_status_cols = Seq("0", "1", "2")

    val alarm_cols = (dms_cols ++ adas_cols ++ gj_cols ++ hod_cols ++ bsd_cols).map(x => when(col(alarm_name) === x, 1).otherwise(0))
    val alarm_cols_str = dms_cols_str ++ adas_cols_str ++ gj_cols_str ++ hod_cols_str ++ bsd_cols_str

    val risk_cols = risk_level_cols.map(x => when('risk_level === x, 1).otherwise(0))
    val defend_cols = defend_status_cols.map(x => when('defend_status === x, 1).otherwise(0))
    ColumnUtil.renameColumn(alarm_cols ++ risk_cols ++ defend_cols, alarm_cols_str ++ risk_cols_str ++ defend_cols_str)
  }
}
