package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.poi.ss.usermodel.{BorderStyle, CellStyle, FillPatternType, IndexedColors}
import org.apache.poi.xssf.usermodel.{XSSFSheet, XSSFWorkbook}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import utils.{DateUtil, SparkBuilder}
import java.io.ByteArrayOutputStream
import java.lang.Thread.sleep
import java.util.{Date, Properties}

import javax.activation.{DataHandler, DataSource}
import javax.mail._
import javax.mail.internet._
import javax.mail.util.ByteArrayDataSource
import org.springframework.core.io.ByteArrayResource

import scala.collection.mutable.ArrayBuffer

/**
 * @description:(已下线2022年)431672
 * @author 01418539 caojia
 * @date 2022/4/22 21:18
 */
object SmartWaterbillsSendFoxmail extends DataSourceCommon {
  val myEmailAccount = "caojia2@sfmail.sf-express.com";

  val myEmailPassword = "AAAsss987123";

//  val myEmailSMTPHost = "lsmtp.sf-express.com";
  val myEmailSMTPHost = "mail.sfmail.sf-express.com";

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    //    val email = "caojia2@sfmail.sf-express.com," +
    //      "xuqianhao@sfmail.sf-express.com," +
    //      "cuixiazhang@sfmail.sf-express.com," +
    //      "layneshu@sfmail.sf-express.com," +
    //      "lishuangshuang1@sfmail.sf-express.com," +
    //      "zuojiayi@sfmail.sf-express.com"
    val email = "xuyanyan@sfmail.sf-express.com,zengxiaojuan@sfmail.sf-express.com,david.chen382@sf-express.com,zhenchen23@sfmail.sf-express.com," +
      "shiheng.du@sfmail.sf-express.com,gaojian@sfmail.sf-express.com,shenzhichao@sf-express.com,wumeng2@sfmail.sf-express.com,jasonyuan@sf-express.com," +
      "lishuangshuang1@sfmail.sf-express.com,layneshu@sfmail.sf-express.com,cuixiazhang@sfmail.sf-express.com," +
      "zuojiayi@sfmail.sf-express.com,weizhaoxiang@sf-express.com,caojia2@sfmail.sf-express.com"
    //    val email = "caojia2@sfmail.sf-express.com"
    val inc_day = args(0)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val o_foxmail = loadDataFromHive(spark, inc_day)
    val str_info = getBodyText(o_foxmail, inc_day)
    sendBodyAndAttachMail(spark, str_info, o_foxmail, email, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def loadDataFromHive(spark: SparkSession, inc_day: String): DataFrame = {
    val o_foxmail = spark.sql(
      s"""
         |select
         |  typetag,
         |  city,
         |  cast(device_cnt as int) device_cnt,
         |  cast(device_socket_cnt as int) device_socket_cnt,
         |  cast(online_device_cnt as int) online_device_cnt,
         |  cast(online_socket_cnt as int) online_socket_cnt,
         |  cast(effective_order_cnt as int) effective_order_cnt,
         |  round(ele_cnt,2) ele_cnt,
         |  round(amount,2) amount_t,
         |  case when city ='全国合计' then '/' when city !='全国合计' then round(cast(per_price as double),2)  else '0.0' end per_price,
         |  case when city ='全国合计' then '/' when city !='全国合计' then round(cast(per_ele_cnt as double),2)  else '0.0' end per_ele_cnt,
         |  case when city like '%合计%' then '/' when city not like '%合计%'  then round(cast(per_socket_ratio as double),2) else '0.0' end per_socket_ratio,--round(per_price,2) per_price,
         |  inc_day,
         |  amount
         |from
         |  dm_gis.scomm_waterbills_foxmail
         |where
         |  inc_day ='$inc_day'
       """.stripMargin)
      .na.fill("", Seq("typetag", "city"))
      .na.fill(0, Seq("device_cnt", "device_socket_cnt", "online_device_cnt", "online_socket_cnt", "effective_order_cnt"))
      .na.fill(0.0, Seq("ele_cnt", "amount", "amount_t", "per_price", "per_ele_cnt", "per_socket_ratio"))
    o_foxmail
  }

  def getBodyText(o_foxmail: DataFrame, inc_day: String): StringBuilder = {
    val day_wbill = o_foxmail.filter(col("typetag") === inc_day)
      .groupBy("typetag")
      .agg(
        sum("amount") as "amount",
        sum("effective_order_cnt") as "effective_order_cnt",
        sum("online_device_cnt") as "online_device_cnt",
        sum("online_socket_cnt") as "online_socket_cnt"
      )
      .withColumn("avg_amount_device", when(col("online_device_cnt") =!= 0, round(col("amount") / col("online_device_cnt"), 2)).otherwise(0.0))
      .withColumn("avg_amount_socket", when(col("online_socket_cnt") =!= 0, round(col("amount") / col("online_socket_cnt"), 2)).otherwise(0.0))
      .withColumn("amount", round(col("amount"), 2))

    val rows: Array[Row] = day_wbill.collect()
    val amount = rows(0).getAs[Double]("amount")
    val effective_order_cnt = rows(0).getAs[Long]("effective_order_cnt")
    val online_device_cnt = rows(0).getAs[Long]("online_device_cnt")
    val online_socket_cnt = rows(0).getAs[Long]("online_socket_cnt")
    val avg_amount_device = rows(0).getAs[Double]("avg_amount_device")
    val avg_amount_socket = rows(0).getAs[Double]("avg_amount_socket")


    val world_rows: Array[Row] = o_foxmail.filter(col("city") === "全国合计").select("amount_t").collect()
    val world_amount = world_rows(0).getAs[Double]("amount_t") //已保留2位有效数

    val strb = new StringBuilder
    if (o_foxmail.count != 0) { //&nbsp&#8195&#8195  缩进2个字符
      strb.append(s"<br>各位好！以下为截止${DateUtil.getCurrentDate("yyyy-MM-dd")} 00:00:00，统计的充电桩流水汇总展示表详情。全部数据明细请见附件，谢谢！</br>")
      strb.append(s"<br>截止昨日总订单流水：${world_amount}元")
      strb.append(s"<br>昨日总订单金额：${amount}元")
      strb.append(s"<br>昨日总有效订单数：${effective_order_cnt}单")
      strb.append(s"<br>昨日总在线桩数：${online_device_cnt}桩")
      strb.append(s"<br>昨日总在线口数：${online_socket_cnt}口")
      strb.append(s"<br>昨日平均每桩收费：${avg_amount_device}元/桩天")
      strb.append(s"<br>昨日平均每口收费：${avg_amount_socket}元/口天</br>")
      strb.append(s"<br>") //换1行

      strb.append("<table border=\"1\" cellspacing=\"0\" style=\"width:1400px; height:150px;border:solid 1px #E8F2F9;font-size=15px;text-align:center;\">") //font-size:15px;

      strb.append("<tr>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">&#8195日期&#8195</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">&#8195城市&#8195</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">上线桩数</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">上线口数</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">在线桩数</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">在线口数</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">有效订单数</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">充电能耗（度）</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">订单金额（元）</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">客单价（元）</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">单单耗电量（度/单）</td>" +
        "<td style=\"white-space:nowrap;background-color:#00FFFF;font-weight:bold;\">单口使用率（次天）</td>" +
        "</tr>")

      val rows: Array[Row] = o_foxmail.collect()
      for (row <- rows) {
        val typetag = row.getAs[String]("typetag")
        val city = row.getAs[String]("city")
        val device_cnt = row.getAs[Integer]("device_cnt")
        val device_socket_cnt = row.getAs[Integer]("device_socket_cnt")
        val online_device_cnt = row.getAs[Integer]("online_device_cnt")
        val online_socket_cnt = row.getAs[Integer]("online_socket_cnt")
        val effective_order_cnt = row.getAs[Integer]("effective_order_cnt")
        val ele_cnt = row.getAs[Double]("ele_cnt")
        val amount = row.getAs[Double]("amount_t")
        val per_price = row.getAs[String]("per_price")
        val per_ele_cnt = row.getAs[String]("per_ele_cnt")
        val per_socket_ratio = row.getAs[String]("per_socket_ratio")

        if (city.contains("合计") && !"全国合计".equals(city)) {
          strb
            .append("<tr>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + typetag + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + city + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + device_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + device_socket_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + online_device_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + online_socket_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + effective_order_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + ele_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + amount + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + per_price + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + per_ele_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"blue\"><b><span>" + per_socket_ratio + "</span></b></font></td>")
            .append("</tr>")
        } else if ("全国合计".equals(city)) {
          strb
            .append("<tr>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + typetag + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + city + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + device_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + device_socket_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + online_device_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + online_socket_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + effective_order_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + ele_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + amount + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + per_price + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + per_ele_cnt + "</span></b></font></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap;\"><font color=\"red\"><b><span>" + per_socket_ratio + "</span></b></font></td>")
            .append("</tr>")
        } else {
          strb
            .append("<tr>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + typetag + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + city + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + device_cnt + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + device_socket_cnt + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + online_device_cnt + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + online_socket_cnt + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + effective_order_cnt + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + ele_cnt + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + amount + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + per_price + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + per_ele_cnt + "</span></td>")
            .append("<td align=\"center\";style=\"white-space:nowrap\"><span>" + per_socket_ratio + "</span></td>")
            .append("</tr>")
        }
      }
      strb.append("</table>")
    } else {
      strb.append(s"<br>各位好！</br>")
      strb.append(s"<br>&nbsp&#8195&#8195以下为截止${DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")}，统计的充电桩流水汇总展示表总数据量为0。请核查准确性。</b></font></br>")
    }
    strb
  }

  def sendBodyAndAttachMail(spark: SparkSession, bodyInfo: StringBuilder, o_foxmail: DataFrame, mailBox: String, inc_day: String): Unit = {
    val prop = new Properties()
    prop.setProperty("mail.transport.protocol", "smtp")
    prop.setProperty("mail.smtp.host", myEmailSMTPHost)
    prop.setProperty("mail.smtp.auth", "true")
    prop.setProperty("mail.smtp.port", "25")
    prop.setProperty("mail.smtp.connectiontimeout", "25000")
    prop.setProperty("mail.smtp.timeout", "25000")
    prop.setProperty("mail.smtp.writetimeout", "25000")
    val auth = new Authenticator() {
      override protected def getPasswordAuthentication =
        new PasswordAuthentication(myEmailAccount, myEmailPassword)
    }

    val session = Session.getDefaultInstance(prop, auth) //设置端口信息
    session.setDebug(true)

    val transport = session.getTransport

    val addresses = new ArrayBuffer[InternetAddress]()

    val mail_nums = mailBox.split(",")
    if (mail_nums.length >= 0 && mail_nums != null) {
      for (mail <- mail_nums) {
        addresses += new InternetAddress(mail, "", "UTF-8")
      }
    }
    val tos = addresses // 收件人（可以增加多个收件人、抄送、密送）

    val mimeMessage = createNewMimeMessage(spark, session, o_foxmail, myEmailAccount, tos, bodyInfo, inc_day)

    try {
      transport.connect(myEmailAccount, myEmailPassword)
    } catch {
      case e1: MessagingException =>
        logger.error(s"首次连接邮箱失败，尝试重新连接。error：" + e1.getMessage)
        var count = 0
        do {
          count += 1
          sleep(1000 * 60 * 1)
          try {
            transport.connect(myEmailAccount, myEmailPassword)
          } catch {
            case e1: MessagingException => logger.error(s"第 $count 次重新连接邮箱失败，尝试重新连接。error：" + e1.getMessage)
          }
        }
        while (count <= 3)
      case e2: Exception => logger.error("连接邮箱出现异常，请检查…………" + e2.getMessage)
    }
    transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients)
    transport.close()
  }

  def createNewMimeMessage(spark: SparkSession, session: Session, o_foxmail: DataFrame, sendMail: String, tos: ArrayBuffer[InternetAddress], bodyInfo: StringBuilder, inc_day: String): MimeMessage = {
    val mimeMessage = new MimeMessage(session)
    mimeMessage.setFrom(new InternetAddress(sendMail, "", "UTF-8")) // 发件人
    mimeMessage.addRecipients(Message.RecipientType.TO, tos.mkString(",")) //抄送人
    mimeMessage.setSubject(inc_day + "充电桩流水汇总展示表", "UTF-8") //邮件主题
    val content = new StringBuilder("<html><head></head><body>")
    content.append(bodyInfo)
    content.append("</body></html>")
    // 添加邮件正文
    val contentPart = new MimeBodyPart
    contentPart.setContent(content.toString(), "text/html;charset=UTF-8")

    // 向multipart对象中添加邮件的各个部分内容，包括文本内容和附件
    val multipart = new MimeMultipart
    // 添加附件的内容
    val attBodyPart = new MimeBodyPart
    multipart.addBodyPart(contentPart)

    //原始数据生成excel表格  通过输入输出流直接处理
    val wb: XSSFWorkbook = getXSSFSheet(o_foxmail, new XSSFWorkbook()).getWorkbook
    val os = new ByteArrayOutputStream(1000)
    wb.write(os)

    val bar: Array[Byte] = new ByteArrayResource(os.toByteArray()).getByteArray
    val source: DataSource = new ByteArrayDataSource(bar, "application/excel").asInstanceOf[DataSource]

    attBodyPart.setDataHandler(new DataHandler(source))
    // MimeUtility.encodeWord可以避免文件名乱码
    attBodyPart.setFileName(MimeUtility.encodeWord(s"${inc_day}充电桩流水汇总展示表.xlsx"))
    multipart.addBodyPart(attBodyPart)

    mimeMessage.setContent(multipart)
    mimeMessage.setSentDate(new Date())
    mimeMessage.saveChanges()

    os.close()
    mimeMessage

  }

  def getXSSFSheet(o_foxmail: DataFrame, sxssf: XSSFWorkbook): XSSFSheet = {

    val rows: Array[Row] = o_foxmail.collect()

    val header_name = Seq("日期", "城市", "上线桩数", "上线口数", "在线桩数", "在线口数", "有效订单数", "充电能耗（度）", "订单金额（元）", "客单价（元）", "单单耗电量（度/单）",
      "单口使用率（次天）")
    val cellStyle = getHeaderStyle(sxssf) //9--WHITE

    val sheet: XSSFSheet = sxssf.createSheet("流水汇总展示表")
    val header = sheet.createRow(0)
    //表头添加
    for (i <- 0 until header_name.size) {
      sheet.setColumnWidth(i, 3500)
      val cell = header.createCell(i)
      cell.setCellStyle(cellStyle)
      cell.setCellValue(header_name(i))
    }
    //内容添加
    for (i <- 0 until rows.length) {
      val row = sheet.createRow(i + 1)
      row.createCell(0).setCellValue(rows(i).getString(0))
      row.createCell(1).setCellValue(rows(i).getString(1))
      row.createCell(2).setCellValue(rows(i).getInt(2))
      row.createCell(3).setCellValue(rows(i).getInt(3))
      row.createCell(4).setCellValue(rows(i).getInt(4))
      row.createCell(5).setCellValue(rows(i).getInt(5))
      row.createCell(6).setCellValue(rows(i).getInt(6))
      row.createCell(7).setCellValue(rows(i).getDouble(7))
      row.createCell(8).setCellValue(rows(i).getDouble(8))
      row.createCell(9).setCellValue(rows(i).getString(9))
      row.createCell(10).setCellValue(rows(i).getString(10))
      row.createCell(11).setCellValue(rows(i).getString(11))
    }
    sheet
  }

  private def getHeaderStyle(sxssf: XSSFWorkbook, foreGroundColor: Short = IndexedColors.YELLOW.getIndex): CellStyle = { //  SEA_GREEN
    val cellStyle = sxssf.createCellStyle()
    cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND)
    cellStyle.setFillForegroundColor(foreGroundColor)
    cellStyle.setBorderLeft(BorderStyle.THIN)
    cellStyle.setBorderTop(BorderStyle.THIN)
    cellStyle.setBorderRight(BorderStyle.THIN)
    cellStyle.setBorderBottom(BorderStyle.THIN)
    cellStyle.setLeftBorderColor(IndexedColors.TAN.index)
    cellStyle.setRightBorderColor(IndexedColors.TAN.index)
    cellStyle.setBottomBorderColor(IndexedColors.TAN.index)
    cellStyle.setTopBorderColor(IndexedColors.TAN.index)
    cellStyle
  }

}

