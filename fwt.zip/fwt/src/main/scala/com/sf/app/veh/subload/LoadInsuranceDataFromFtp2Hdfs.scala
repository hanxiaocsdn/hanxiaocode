package com.sf.app.veh.subload

import org.apache.commons.net.ftp.{FTPClient, FTPReply}
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.fs.{FSDataOutputStream, FileSystem, Path}
import org.apache.hadoop.io.IOUtils
import utils.FTPUtil
import utils.FTPUtil.logger

import java.io.InputStream

/**
 * @task_id:
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2023/3/13 10:04
 */
object LoadInsuranceDataFromFtp2Hdfs {
  def main(args: Array[String]): Unit = {
    val sourcePath = args(0)
    val destinationPath = args(1)
    downLoad(sourcePath, destinationPath)
  }

  def downLoad(sourcePath: String, destinationPath:
  String): Unit = {
    val conf = new Configuration()
    val ftp = FTPUtil.getFtpClient("gisftp.sf-express.com", 21, "devftp", "brYsj2.023ftKjdev", "")
    downloadFromFtpToHdfsHierarchy(ftp, sourcePath, destinationPath, conf)
  }


  /**
   * 将 ftp 上的文件拉取到 hdfs 上
   *
   * @param ftpClient
   * @param ftpPath
   * @param hdfsPath
   * @param fileName
   * @param conf
   * @return
   */
  def downloadFromFtpToHdfsHierarchy(ftpClient: FTPClient, ftpPath: String, hdfsPath: String, conf: Configuration): Boolean = {
    var inputStream: InputStream = null
    var outputStream: FSDataOutputStream = null
    var flag = true
    try {
      val reply = ftpClient.getReplyCode
      if (!FTPReply.isPositiveCompletion(reply)) ftpClient.disconnect

      val files = ftpClient.listFiles(ftpPath)
      val hdfsFile: FileSystem = FileSystem.get(conf)
      var i: Int = 1
      for (file <- files) {
        //        if (file.getName.equals(fileName)) {
        inputStream = ftpClient.retrieveFileStream(ftpPath + file.getName)
        outputStream = hdfsFile.create(new Path(hdfsPath + file.getName))
        IOUtils.copyBytes(inputStream, outputStream, conf, false)
        if (inputStream != null) {
          inputStream.close();
          ftpClient.completePendingCommand()
        }
        logger.error("上传第" + i)
        i += 1
        //        }
      }
      ftpClient.disconnect()
    } catch {
      case e: Exception => flag = false
        e.printStackTrace()
    }
    if (flag) logger.error("FTP上的文件,已成功拉取到hdfs上！")
    flag
  }

}
