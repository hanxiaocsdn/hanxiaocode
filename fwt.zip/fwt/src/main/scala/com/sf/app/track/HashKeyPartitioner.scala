package com.sf.app.track

import org.apache.spark.Partitioner

/**
  * Created by 01366807 on 2017/6/19.
  */
class HashKeyPartitioner(numParts: Int) extends Partitioner {
  override def numPartitions: Int = numParts

  override def getPartition(key: Any): Int = {
    val code = (key.toString.trim.hashCode % numPartitions)
    if (code < 0) {
      code + numPartitions
    } else {
      code
    }
  }

  override def equals(other: Any): Boolean = other match {
    case hashkey: HashKeyPartitioner =>
      hashkey.numPartitions == numPartitions
    case _ =>
      false
  }

  override def hashCode: Int = numPartitions
}
