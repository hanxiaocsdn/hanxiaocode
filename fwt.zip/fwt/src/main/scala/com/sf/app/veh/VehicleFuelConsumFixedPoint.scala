package com.sf.app.veh

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import constant.HttpConstant.{HTTP_GAS_STATION_DATA_P, HTTP_QUERY_ADJUST_PATH_P}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.getdaysBeforeOrAfter
import utils.{HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 临时,未上线 477240
 * @description: 原点油站推荐配置表
 * @demander:01412994 韩杰
 * @author 01418539 caojia
 * @date 2023/2/16 18:23
 */

case class GasStationInfo(name_chn: String, display_pos: String, query_brand: String, address: String, card_province: String, poiid: String, price_activity: String, chainCode: String, decision_price: String)

case class GasStationAndPrice(name_chn: String, display_pos: String, query_brand: String, address: String, card_province: String, poiid: String, price_activity: String, chainCode: String, decision_price: String, province: String, city: String, official_price_changetime: String, official_price: String, skid_mounted: String)

object VehicleFuelConsumFixedPoint extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processFixedPoint(spark, inc_day)

    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processFixedPoint(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val days_2_ago = getdaysBeforeOrAfter(inc_day, -2)
    val days_7_ago = getdaysBeforeOrAfter(inc_day, 7)
    //    val o_driver = spark.sql(
    //      s"""select driver_id from dwd_o.dwd_tp_grd_driver_dtl_df where inc_day ='$days_2_ago'
    //         |and driver_id is not null and trim(driver_id) !=''
    //         |and emp_code in ('01344575','41570230','40056749','40533389','41970956','41859842','41569858','41577572','00727551','00628566','40347320','40322752','00419978','41712463','00218164','41577856','41556908','41591532','00679266')""".stripMargin)
    //    val driver_id_info = o_driver.select("driver_id").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    //
    //    val o_task = spark.sql(
    //      s"""select src_zone_code,dest_zone_code from dm_grd.grd_new_task_detail
    //         |where inc_day between '$inc_day' and '$days_7_ago' and src_zone_code is not null and trim(src_zone_code) !=''
    //         |and driver_id in ($driver_id_info)
    //         |group by src_zone_code,dest_zone_code""".stripMargin)
    //
    //    val o_dept = spark.sql(
    //      s"""SELECT dept_code,concat_ws(',',longitude,latitude) dept_pos,provinct_name dept_province,city_name dept_city,
    //         |row_number() over(partition by dept_code order by create_tm desc) num
    //         |from dim.dim_dept_info_df
    //         |where inc_day = '$days_2_ago' and dept_code is not null and trim(dept_code) !=''""".stripMargin)
    //      .filter('num === 1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //
    val pub_cols = Seq("dept_code", "dept_pos", "dept_province", "dept_city").map(col)
    //    val start_dept_df = o_task.withColumnRenamed("src_zone_code", "dept_code").join(o_dept, Seq("dept_code"), "left").select(pub_cols: _*)
    //    val end_dept_df = o_task.withColumnRenamed("dest_zone_code", "dept_code").join(o_dept, Seq("dept_code"), "left").select(pub_cols: _*)

    val o_dept = spark.sql(
      s"""SELECT dept_code,concat_ws(',',longitude,latitude) dept_pos,provinct_name dept_province,city_name dept_city,
         |row_number() over(partition by dept_code order by create_tm desc) num
         |from dim.dim_dept_info_df
         |where inc_day = '$days_2_ago' and dept_code in ('576WH','451W','451BA','023W','755VF','316Z008','027WA','573XF','P010LFA','451EJ','027WH','851W','851ZHC','577Q','577WB','571WB','571KH','595XA','763X','022X','769XG','851AF','595X','595R','022WJ','579FWXL','027W','768FWW','316AEF','577CP','010ABV','010WB','010VV','316CEE','571FG','023LJ','023WH','022EDJ','577CH','023KF','010CF','023ZHSR','755WE','020W','512W','769WF','022W','022WB','021WD','029WA','021WW','451WD','027WK','451LE','010X','451HG','577TN','577GE','571SD','571WJ','592WD','311WB','576W','531W','595WH','551W','571XA','577W','010WA','010BEP','023ZHLD','023MEM','010WD','755WF','755R','024W','755X','023MCM','552W','010ADK','029EN')""".stripMargin)
      .filter('num === 1).persist(StorageLevel.MEMORY_AND_DISK_SER)


    //    val inter_dept_df = start_dept_df.union(end_dept_df)
    val res_cols = spark.sql("""select * from dm_gis.oil_station_conf_info_tmp limit 0""").schema.map(_.name).map(col)

    val inter_dept_df = o_dept
      //      .withColumn("num", row_number().over(Window.partitionBy("dept_code").orderBy(desc("dept_pos"))))
      //      .filter('num === 1)
      .select(pub_cols: _*).repartition(200)
      .map(row => {
        val dept_code = row.getAs[String]("dept_code")
        val dept_pos = row.getAs[String]("dept_pos")
        val dept_province = row.getAs[String]("dept_province")
        val dept_city = row.getAs[String]("dept_city")
        val dist_arr: Seq[Int] = Seq(20000, 30000, 40000, 50000)
        val res_ab_arr = ArrayBuffer[GasStationAndPrice]()

        val gas_station_info_1, gas_station_info_2, gas_station_info_3 = new ArrayBuffer[GasStationInfo]()
        val gas_station_c1 = getGasStationNearDept(dept_pos, "1", "全国", 10000, gas_station_info_1)
        val gas_station_c2 = getGasStationNearDept(dept_pos, "2", dept_province, 10000, gas_station_info_2)
        val gas_station_c3 = getGasStationNearDept(dept_pos, "2", "非本省", 10000, gas_station_info_3)

        val success_cond = gas_station_c1.size == 1 && gas_station_c2.size == 1 && gas_station_c3.size == 1

        if (!success_cond) {
          breakable {
            for (dist <- dist_arr) {
              val gas_station_info_1_tmp, gas_station_info_2_tmp, gas_station_info_3_tmp = new ArrayBuffer[GasStationInfo]()
              val gas_station_c1_tmp = getGasStationNearDept(dept_pos, "1", "全国", dist, gas_station_info_1_tmp)
              val gas_station_c2_tmp = getGasStationNearDept(dept_pos, "2", dept_province, dist, gas_station_info_2_tmp)
              val gas_station_c3_tmp = getGasStationNearDept(dept_pos, "2", "非本省", dist, gas_station_info_3_tmp)
              val success_cond_tmp = gas_station_c1_tmp.size == 1 && gas_station_c2_tmp.size == 1 && gas_station_c3_tmp.size == 1
              if (success_cond_tmp) {
                val c1_tmp = gas_station_c1_tmp(0)
                val c2_tmp = gas_station_c2_tmp(0)
                val c3_tmp = gas_station_c3_tmp(0)
                val c1_poiid = getStation(c1_tmp.poiid)
                val c2_poiid = getStation(c2_tmp.poiid)
                val c3_poiid = getStation(c3_tmp.poiid)
                res_ab_arr += GasStationAndPrice(c1_tmp.name_chn, c1_tmp.display_pos, c1_tmp.query_brand, c1_tmp.address, c1_tmp.card_province, c1_tmp.poiid, c1_tmp.price_activity, c1_tmp.chainCode, c1_tmp.decision_price, c1_poiid._1, c1_poiid._2, c1_poiid._3, c1_poiid._4, c1_poiid._5)
                res_ab_arr += GasStationAndPrice(c2_tmp.name_chn, c2_tmp.display_pos, c2_tmp.query_brand, c2_tmp.address, c2_tmp.card_province, c2_tmp.poiid, c2_tmp.price_activity, c2_tmp.chainCode, c2_tmp.decision_price, c2_poiid._1, c2_poiid._2, c2_poiid._3, c2_poiid._4, c2_poiid._5)
                res_ab_arr += GasStationAndPrice(c3_tmp.name_chn, c3_tmp.display_pos, c3_tmp.query_brand, c3_tmp.address, c3_tmp.card_province, c3_tmp.poiid, c3_tmp.price_activity, c3_tmp.chainCode, c3_tmp.decision_price, c3_poiid._1, c3_poiid._2, c3_poiid._3, c3_poiid._4, c3_poiid._5)
                break()
              }
            }
          }
        } else {
          val c1_tmp = gas_station_c1(0)
          val c2_tmp = gas_station_c2(0)
          val c3_tmp = gas_station_c3(0)
          val c1_poiid = getStation(c1_tmp.poiid)
          val c2_poiid = getStation(c2_tmp.poiid)
          val c3_poiid = getStation(c3_tmp.poiid)
          res_ab_arr += GasStationAndPrice(c1_tmp.name_chn, c1_tmp.display_pos, c1_tmp.query_brand, c1_tmp.address, c1_tmp.card_province, c1_tmp.poiid, c1_tmp.price_activity, c1_tmp.chainCode, c1_tmp.decision_price, c1_poiid._1, c1_poiid._2, c1_poiid._3, c1_poiid._4, c1_poiid._5)
          res_ab_arr += GasStationAndPrice(c2_tmp.name_chn, c2_tmp.display_pos, c2_tmp.query_brand, c2_tmp.address, c2_tmp.card_province, c2_tmp.poiid, c2_tmp.price_activity, c2_tmp.chainCode, c2_tmp.decision_price, c2_poiid._1, c2_poiid._2, c2_poiid._3, c2_poiid._4, c2_poiid._5)
          res_ab_arr += GasStationAndPrice(c3_tmp.name_chn, c3_tmp.display_pos, c3_tmp.query_brand, c3_tmp.address, c3_tmp.card_province, c3_tmp.poiid, c3_tmp.price_activity, c3_tmp.chainCode, c3_tmp.decision_price, c3_poiid._1, c3_poiid._2, c3_poiid._3, c3_poiid._4, c3_poiid._5)
        }
        (dept_code, dept_pos, dept_city, dept_province, res_ab_arr)
      }).toDF("dept_code", "dept_pos", "dept_city", "dept_province", "res_ab_arr")
      .na.fill("", Seq("res_ab_arr"))
      .withColumnRenamed("dept_code", "dept")
      .withColumn("inter_one", explode($"res_ab_arr"))
      .withColumn("poiid", $"inter_one"("poiid"))
      .withColumn("display_pos", $"inter_one"("display_pos"))
      .withColumn("name_chn", $"inter_one"("name_chn"))
      .withColumn("query_brand", $"inter_one"("query_brand"))
      .withColumn("address", $"inter_one"("address"))
      .withColumn("province", $"inter_one"("province"))
      .withColumn("city", $"inter_one"("city"))
      .withColumn("oilname", lit("0"))
      .withColumn("card_province", $"inter_one"("card_province"))
      .withColumn("official_price", $"inter_one"("official_price"))
      .withColumn("price_activity", $"inter_one"("price_activity"))
      .withColumn("decision_price", $"inter_one"("decision_price"))
      .withColumn("official_price_changetime", $"inter_one"("official_price_changetime"))
      .withColumn("skid_mounted", $"inter_one"("skid_mounted"))
      .withColumn("uid",concat_ws("_",'dept,'card_province,'query_brand,'oilname))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
    writeToHive(spark, inter_dept_df.coalesce(2), Seq("inc_day"), "dm_gis.oil_station_conf_info_tmp")
  }

  def getStation(poiid: String): (String, String, String, String, String) = {
    var gas_info_str, province, city, skidMounted, officialPriceVec, officialPriceChangeTimeVec = ""
    val params2 =
      s"""{"src":"5",
         |"dataVersion":-1,
         |"lastTimeStamp":"0",
         |"POIID":"$poiid"}""".stripMargin
    try {
      gas_info_str = HttpInvokeUtil.sendPost(HTTP_GAS_STATION_DATA_P, params2, 3, 2)
      logger.info(s"标准线路配置接口返回的数据：" + gas_info_str)
      val info_resp_json = JSON.parseObject(gas_info_str)
      val data_first = info_resp_json.getJSONArray("data").getJSONObject(0)
      if (data_first != null) {
        province = data_first.getString("province")
        city = data_first.getString("city")
        skidMounted = data_first.getString("skidMounted")
        val oilNameVec_arr = data_first.getJSONArray("oilNameVec")
        val officialPriceVec_arr = data_first.getJSONArray("officialPriceVec")
        val officialPriceChangeTimeVec_arr = data_first.getJSONArray("officialPriceChangeTimeVec")
        if (oilNameVec_arr != null && oilNameVec_arr.size() >= 1) {
          breakable {
            for (j <- 0 until oilNameVec_arr.size()) {
              val oilNameVec = oilNameVec_arr.get(j).toString
              if (oilNameVec == "0") {
                officialPriceVec = officialPriceVec_arr.get(j).toString
                officialPriceChangeTimeVec = officialPriceChangeTimeVec_arr.get(j).toString
                break
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (province, city, officialPriceChangeTimeVec, officialPriceVec, skidMounted)
  }

  def getGasStationNearDept(deptPoint: String, chain: String, cardProvince: String, dist: Int, gas_station_info: ArrayBuffer[GasStationInfo]): ArrayBuffer[GasStationInfo] = {
    val params1 =
      s"""{
         |"ak": "8bb09e5e110845f39a000391668e3e80",
         |"kind": "5",
         |"pathList": [""],
         |"projectNo": "5",
         |"fuelLeftDistance": $dist,
         |"alongDistance": $dist,
         |"deptAlongDistance": $dist,
         |"deptRange": $dist,
         |"topN": 1,
         |"chain": "$chain",
         |"deptPoint": "$deptPoint",
         |"carPos": "$deptPoint",
         |"cardProvince": "$cardProvince",
         |"fuelNo": "0"
         |}""".stripMargin
    var adj_info_str = ""

    try {
      adj_info_str = HttpInvokeUtil.sendPost(HTTP_QUERY_ADJUST_PATH_P, params1, 3, 2)
      logger.info(s"标准线路配置接口返回的数据：" + adj_info_str)
      val info_resp_json = JSON.parseObject(adj_info_str)
      //传参中 默认保留只有1个json结果 入参设置topN = 1
      if (info_resp_json.getJSONArray("pathWithPoi") != null && info_resp_json.getJSONArray("pathWithPoi").size() == 1) {
        val pathwithpoi_top1 = info_resp_json.getJSONArray("pathWithPoi").getJSONObject(0)
        if (pathwithpoi_top1 != null) {
          var dept_x, dept_y, price_activity, decision_price = ""
          val poi = pathwithpoi_top1.getJSONObject("poi")
          val name = poi.getString("name")
          val poiid = poi.getString("poiId")
          val address = poi.getString("address")
          val chainCode = poi.getString("chainCode")

          val displayPos_tmp = poi.getJSONObject("displayPos")
          try {
            dept_x = (displayPos_tmp.getString("x").toDouble / 3600000).toString
          } catch {
            case e: Exception => "_"
          }
          try {
            dept_y = (displayPos_tmp.getString("y").toDouble / 3600000).toString
          } catch {
            case e: Exception => "_"
          }
          val display_pos = dept_x + "," + dept_y
          try {
            price_activity = poi.getString("priceList").split(",")(1)
          } catch {
            case e1: Exception => "_"
          }
          decision_price = poi.getString("price")
          if (poiid != "") {
            gas_station_info += GasStationInfo(name, display_pos, chain, address, cardProvince, poiid, price_activity, chainCode, decision_price)
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    gas_station_info
  }
}
