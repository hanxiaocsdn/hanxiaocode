package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, SparkSession}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: 494483
 * @description: 时长监控需求
 * @demander: 01408890 邵一馨
 * @author 01418539 caojia
 * @date 2022/10/11 15:53
 */
object EfficientOntimeMonitor extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    processOntime(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processOntime(spark: SparkSession, inc_day: String): Unit = {
    val days_7_ago = getdaysBeforeOrAfter(inc_day, -6)
    //区域代码映射关系数据
    val area_map_df = spark.sql("""select * from dm_gis.dim_area_code_name_mapping""")
    val o_recall = spark.sql(
      s"""
         |select  concat_ws('_',line_code,start_dept,end_dept,start_type,end_type) `group`,
         |        line_code,task_area_code,start_dept,end_dept,start_type,end_type,transoport_level,if_evaluate_time,ac_is_run_ontime,carrier_type,inc_day
         |from (select regexp_replace(line_code,' ','') line_code,
         |        task_area_code,start_dept,end_dept,start_type,end_type,transoport_level,
         |        if_evaluate_time,ac_is_run_ontime,carrier_type,inc_day,
         |        row_number() over(PARTITION by task_subid ORDER by last_update_tm desc) as rn
         | from dm_gis.eta_std_line_recall_result
         | where task_subid is not null and trim(task_subid) != ''
         |       and inc_day between '$days_7_ago' and '$inc_day') a
         | where rn = 1""".stripMargin)
      .join(area_map_df, Seq("task_area_code"), "left")
    val agg_cols_str = Seq("group", "line_code", "start_dept", "end_dept", "inc_day", "start_type", "end_type")
    val add_cnt_cols_str = Seq("eval_task_num", "eval_ontime_num", "eval_late_num", "eval_self_task_num", "eval_self_ontime_num", "eval_self_late_num", "eval_outsource_task_num", "eva_outsource_ontime_num", "eval_outsource_late_num")
    val add_cnt_coll_cols_str = Seq("eval_task_num", "eval_ontime_num", "eval_late_num", "eval_self_task_num", "eval_self_ontime_num", "eval_self_late_num", "eval_outsource_task_num", "eva_outsource_ontime_num", "eval_outsource_late_num", "transoport_level", "task_area_code", "task_area_name")

    val agg_cnt_coll_cols = aggFun(add_cnt_coll_cols_str)
    //拼装结果表字段
    val res_cols = spark.sql("""select * from dm_gis.eta_time_ontime_daily limit 0""").schema.map(_.name).map(col)
    val res_df = o_recall.select(o_recall.schema.map(_.name).map(col) ++ addCntFun(spark, add_cnt_cols_str): _*)
      .groupBy(agg_cols_str.map(col): _*)
      .agg(agg_cnt_coll_cols.head, agg_cnt_coll_cols.tail: _*)
      .select(res_cols: _*)
    writeToHive(spark, res_df.coalesce(2), Seq("inc_day"), "dm_gis.eta_time_ontime_daily")
  }

  def aggFun(add_cnt_coll_cols_str: Seq[String]): Seq[Column] = {
    val diff_str = Seq("transoport_level", "task_area_code", "task_area_name")
    val new_cols = add_cnt_coll_cols_str.map(x => if (!diff_str.contains(x)) {
      sum(col(x))
    } else {
      concat_ws("|", collect_set(col(x)))
    })
    ColumnUtil.renameColumn(new_cols, add_cnt_coll_cols_str)
  }

  def addCntFun(spark: SparkSession, add_cnt_cols_str: Seq[String]): Seq[Column] = {
    import spark.implicits._
    val x1 = 'if_evaluate_time === "1"
    val y1 = 'ac_is_run_ontime === "1.0"
    val y2 = 'ac_is_run_ontime === "0.0"
    val z1 = 'carrier_type === "1"
    val z2 = 'carrier_type === "0"
    val multi_cond: Seq[Column] = Seq(lit(true), y1, y2, z2, y1 && z2, y2 && z2, z1, y1 && z1, y2 && z1)
    val all_cnt_cols = multi_cond.map(cond => when(x1 && cond, 1).otherwise(0))
    ColumnUtil.renameColumn(all_cnt_cols, add_cnt_cols_str)
  }
}
