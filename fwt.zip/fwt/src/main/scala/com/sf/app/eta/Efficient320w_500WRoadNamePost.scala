package com.sf.app.eta

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.HTTP_CLUSTER_LINK_P
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{randomAdd, splitFun, strNotNull}
import utils.EtaUtil.base32ToDecimal
import utils.{HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @task_id: 691974 (国房 的 前置数据接入任务ID : 769430)
 * @description: 20230401以后的数据需要接口补充3个字段数据  tl_road road_name tl_points road_points
 * @demander:舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/5/30 17:50
 */
object Efficient320w_500WRoadNamePost extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val startTN = "dm_gis.road_track_info_daily" //来源表
    val link_roadTN = "dm_gis.eta_link_road_points_map_daily" //接口返回道路名称映射信息表
    val endTN = "dm_gis.eta_track_daily" //每天的数据表
    val inc_day = args(0)
    val run_flag = args(1)
    procGetRoadName(spark, inc_day, startTN, link_roadTN, endTN, run_flag) //200core 单天20min
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  /**
   * 接口获取3个字段：tl_road road_name tl_points road_points
   *
   * @param spark
   * @param inc_day
   * @param startTN
   * @param endTN
   * @param link_roadTN
   */
  def procGetRoadName(spark: SparkSession, inc_day: String, startTN: String, link_roadTN: String, endTN: String, run_flag: String): Unit = {
    import spark.implicits._
    val org_sql =
      s"""select un,road_rank road_track_continues_rate,road_ids road_id,if_highspeed,road_start_time,road_end_time,road_start_adcode,road_end_adcode,road_dist,tl_periods,tl_link tl_link_p,tl_roadclass,inc_day
         |from $startTN where inc_day='$inc_day'
         |--and un in( '冀B6236V_2','冀RD5336_2')
         |--limit 300""".stripMargin
    logger.error(">>>>加载的原始数据sql:>>>>" + org_sql)
    val link_road_cols = spark.sql(s"""select * from $link_roadTN limit 0""").schema.map(_.name).map(col)
    val res_cols = spark.sql(s"""select * from $endTN limit 0""").schema.map(_.name).map(col)
    val road_id_infos_str = splitFun("&")('road_id_infos)
    val tl_link_p_infos_str = splitFun("&")('tl_link_p_infos)
    val o_track_daily_df = spark.sql(org_sql)
      .na.fill("", Seq("road_track_continues_rate", "tl_link_p"))
      .withColumn("tl_link_p_infos", tlLinkDisaUDF('tl_link_p))
      .withColumn("tl_link", tl_link_p_infos_str(0))
      .withColumn("tl_origin_points", tl_link_p_infos_str(1))
      .withColumn("tmp_col", split('road_track_continues_rate, "\\|")(0).cast("int"))
      .withColumn("num", row_number().over(Window.partitionBy("un").orderBy(desc("tmp_col"))))
      .filter("num=1").drop("num", "tmp_col")
      .withColumn("rank", getRankUdf('road_track_continues_rate))
      .withColumn("road_id_infos", getroadSwidWithPointUdf(col("road_id")))
      .withColumn("road_start_swid", road_id_infos_str(0))
      .withColumn("road_end_swid", road_id_infos_str(1))
      .withColumn("road_id", road_id_infos_str(2))
      .withColumn("tl_link", gettlLinkWithPointUdf('tl_link))
      .repartition(200)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val un_links_df = o_track_daily_df.select("un", "road_id", "tl_link", "inc_day")
    logger.error(">>>>>原始加载的数据总量为>>>>>" + o_track_daily_df.count())
    o_track_daily_df.show(10)

    if (run_flag == "1") {
      //      explodeFirstMulti(spark, o_track_daily_df, un_links_df, link_roadTN, endTN, link_road_cols, res_cols, inc_day)
    } else {
      explodeSecondMulti(spark, o_track_daily_df, un_links_df, link_roadTN, endTN, link_road_cols, res_cols, inc_day)
    }
    o_track_daily_df.unpersist()
    logger.error(">>>>>加载的数据总量>>>>" + o_track_daily_df.count())
  }

  //  /**
  //   * 第1天运行情况
  //   *
  //   * @param spark
  //   * @param o_track_daily_df
  //   * @param un_links_df
  //   * @param link_roadTN
  //   * @param link_road_cols
  //   * @param res_cols
  //   * @param inc_day
  //   * @return
  //   */
  //  def explodeFirstMulti(spark: SparkSession, o_track_daily_df: DataFrame, un_links_df: DataFrame, link_roadTN: String, endTN: String, link_road_cols: Seq[Column], res_cols: Seq[Column], inc_day: String): Unit = {
  //    import spark.implicits._
  //    val un_df = un_links_df
  //      .withColumn("merge_links", concat_ws("|", 'road_id, 'tl_link))
  //      .withColumn("one_links", explode(split($"merge_links", "\\|")))
  //      .withColumn("one_links", explode(split($"one_links", "_")))
  //      .repartition(300, col("un"))
  //      .persist(StorageLevel.MEMORY_AND_DISK_SER)
  //    logger.error(">>un_df的数据>>>" + un_df.count())
  //    //去重 links
  //    val links_df = un_df.groupBy("one_links")
  //      .agg(lit("true") as "flag")
  //
  //    //将去重后的links 每1000个分为一组，接口调用
  //    val cnt = links_df.count()
  //    val num = if ((cnt / 1000.0).toInt == 0) 1 else (cnt / 1000.0).toInt
  //
  //    val bef_post_df = links_df
  //      .withColumn("num", randomAdd(num)(lit(true)))
  //      .groupBy("num")
  //      .agg(concat_ws("|", collect_list('one_links)) as "more_links")
  //      .repartition(28)
  //    logger.error(">>>接口调用前的总数据量（1k~条一组）：>>>" + bef_post_df.count())
  //
  //    val aft_post_df = bef_post_df.map(row => {
  //      val more_links = row.getAs[String]("more_links")
  //      val link_road_info = getRoadInfo(more_links)
  //      link_road_info
  //    }).toDF("link_road_info")
  //      .withColumn("link_road_points", explode(split($"link_road_info", "\\|")))
  //      .withColumn("one_links", split('link_road_points, "&")(0))
  //      .withColumn("road_info", split('link_road_points, "&")(1))
  //      .withColumn("points", split('link_road_points, "&")(2))
  //      .select("one_links", "road_info", "points", "link_road_points")
  //      .withColumn("inc_day", lit(inc_day))
  //      .select(link_road_cols: _*)
  //      .repartition(400)
  //      .persist(StorageLevel.MEMORY_AND_DISK_SER)
  //    logger.error(">>>接口调用后的并拆分数据后总：>>>" + aft_post_df.count())
  //
  //    val get_un_road_df = un_df.join(aft_post_df, Seq("one_links"), "left")
  //      .groupBy("un")
  //      .agg(concat_ws("|", collect_list('link_road_points)) as "link_road_points")
  //      .select("un", "link_road_points")
  //
  //    val link_road_points_infos_str = splitFun("&")('link_road_points_infos) //
  //    val res_df = o_track_daily_df.join(get_un_road_df, Seq("un"), "left")
  //      .na.fill("", Seq("road_id", "tl_link", "link_road_points","road_start_swid","road_end_swid"))
  //      .withColumn("link_road_points_infos", getLinkMapRoad('road_id, 'tl_link, 'link_road_points,'road_start_swid,'road_end_swid))
  //      .withColumn("road_name", link_road_points_infos_str(0))
  //      .withColumn("tl_road", link_road_points_infos_str(1))
  //      .withColumn("tl_points", link_road_points_infos_str(2))
  //      .select(res_cols: _*)
  //    writeToHive(spark, aft_post_df.coalesce(20), Seq("inc_day"), link_roadTN)
  //    writeToHive(spark, res_df.coalesce(20), Seq("inc_day"), endTN)
  //  }

  /**
   * 第2天的运行情况---已经调过接口的数据不再调接口
   *
   * @param spark
   * @param o_track_daily_df
   * @param un_links_df
   * @param link_roadTN
   * @param link_road_cols
   * @param res_cols
   * @param inc_day
   * @return
   */
  def explodeSecondMulti(spark: SparkSession, o_track_daily_df: DataFrame, un_links_df: DataFrame, link_roadTN: String, endTN: String, link_road_cols: Seq[Column], res_cols: Seq[Column], inc_day: String): Unit = {
    import spark.implicits._
    val link_road_df = spark.sql(s"""select * from $link_roadTN where inc_day < '$inc_day'""")
      .withColumn("num", row_number().over(Window.partitionBy("one_links").orderBy(desc("one_links"))))
      .filter(col("num") === 1).drop("num")

    val un_df = un_links_df
      .withColumn("merge_links", concat_ws("|", 'road_id, 'tl_link))
      .withColumn("one_links", explode(split($"merge_links", "\\|")))
      .withColumn("one_links", explode(split($"one_links", "_")))
      .filter(!'one_links.contains(",") && !'one_links.contains(".")) //将经纬度的数据过滤不掉接口
      .repartition(300, col("un"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>un_df的数据>>>" + un_df.count())

    //去重 links
    val links_df = un_df.groupBy("one_links")
      .agg(lit("true") as "flag")

    val all_links_df = links_df.join(link_road_df, Seq("one_links"), "left").na.fill("", Seq("inc_day"))
      .withColumn("y_n", when('inc_day.isNotNull && trim('inc_day) =!= "", "N").otherwise("Y"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //拆分出需要重新调接口的links
    val need_no_inter_links_df = all_links_df.filter('y_n === "N").select(link_road_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val need_inter_links_df = all_links_df.filter('y_n === "Y").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>需要重新调接口的数据总量（1k~条一组）：>>>" + need_inter_links_df.count())
    //将去重后的links 每1000个分为一组，接口调用
    val cnt = need_inter_links_df.count()
    val num = if ((cnt / 1000.0).toInt == 0) 1 else (cnt / 1000.0).toInt
    val bef_post_df = need_inter_links_df
      .withColumn("num", randomAdd(num)(lit(true)))
      .groupBy("num")
      .agg(concat_ws("|", collect_list('one_links)) as "more_links")
      .repartition(28).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>接口调用后的并拆分数据后总：>>>" + bef_post_df.count())
    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "691974", "【500w日表-接口-补齐路段名称】Efficient320w_500WRoadNamePost", "swid获取道路名称", HTTP_CLUSTER_LINK_P, "", bef_post_df.count(), 28)
    all_links_df.unpersist()
    val aft_post_df = bef_post_df.map(row => {
      val more_links = row.getAs[String]("more_links")
      val link_road_info = getRoadInfo(more_links)
      link_road_info
    }).toDF("link_road_info")
      .withColumn("link_road_points", explode(split($"link_road_info", "\\|")))
      .withColumn("one_links", split('link_road_points, "&")(0))
      .withColumn("road_info", split('link_road_points, "&")(1))
      .withColumn("points", split('link_road_points, "&")(2))
      .withColumn("inc_day", lit(inc_day))
      .select(link_road_cols: _*)
      .repartition(200)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>接口调用后的总数据量为：>>>" + aft_post_df.count())
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)
    val get_un_road_df = un_df.join(need_no_inter_links_df.union(aft_post_df), Seq("one_links"), "left")
      .groupBy("un")
      .agg(concat_ws("|", collect_list('link_road_points)) as "link_road_points")
      .select("un", "link_road_points")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val link_road_points_infos_str = splitFun("&")('link_road_points_infos) //
    val res_df = o_track_daily_df.join(get_un_road_df, Seq("un"), "left")
      .na.fill("", Seq("road_id", "tl_link", "link_road_points", "road_start_swid", "road_end_swid"))
      .withColumn("link_road_points_infos", getLinkMapRoad('road_id, 'tl_link, 'link_road_points, 'road_start_swid, 'road_end_swid))
      .withColumn("road_name", link_road_points_infos_str(0))
      .withColumn("tl_road", link_road_points_infos_str(1))
      .withColumn("tl_points", link_road_points_infos_str(2))
      .withColumn("road_points", link_road_points_infos_str(3))
      .withColumn("road_points_start", link_road_points_infos_str(4))
      .withColumn("road_points_end", link_road_points_infos_str(5))
      .na.fill("", Seq("road_id", "tl_link", "tl_road", "tl_points"))
      .withColumn("tl_points", pointBackUDF('tl_points, 'tl_link))
      .withColumn("road_points", pointRoadBackUDF('road_points, 'road_id))
      .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>最终结果数据总量为>>>>>" + res_df.count())
    writeToHive(spark, aft_post_df.coalesce(40), Seq("inc_day"), link_roadTN)
    writeToHive(spark, res_df.coalesce(100), Seq("inc_day"), endTN)
  }

  def tlLinkDisaUDF = udf((tl_link_p: String) => {
    val link_ab, point_ab = new ListBuffer[String]()
    if (strNotNull(tl_link_p)) {
      val p_arr = tl_link_p.split("\\|", -1)
      for (i <- 0 until p_arr.size) {
        link_ab += p_arr(i).split("_")(0)
        val point = p_arr(i).split("_")(1)
        if (point.startsWith("Z") && point.contains("W")) {
          val xy = point.replace("Z", "").split("W")
          val x_point = xy(0)
          val y_point = xy(1)
          val x = base32ToDecimal(x_point) / 1000000.0
          val y = base32ToDecimal(y_point) / 1000000.0
          point_ab += (x + "," + y)
        } else {
          point_ab += "-"
        }
      }
    }
    link_ab.mkString("|") + "&" + point_ab.mkString("|")
  })

  def getRankUdf = udf((rate: String) => {
    var road_track_continues_rate = ""
    if (strNotNull(rate)) {
      try {
        val id_arr = rate.split("\\|", -1)
        val rand: Range = 1 to id_arr.size
        road_track_continues_rate = rand.mkString("|")
      } catch {
        case e: Exception => ""
      }
    }
    road_track_continues_rate
  })

  def pointRoadBackUDF = udf((road_points: String, road_id: String) => {
    val out_tl_points_arr = new ListBuffer[String]()
    try {
      if (strNotNull(road_points) && strNotNull(road_id)) {
        val points_arr = road_points.split("\\|", -1)
        val link_arr = road_id.split("\\|", -1)
        for (i <- 0 until points_arr.size) {
          val p_arr = points_arr(i).split("_", -1)
          val l_arr = link_arr(i).split("_", -1)
          val in_tl_points_arr = new ListBuffer[String]()
          for (j <- 0 until p_arr.size) {
            val p = p_arr(j)
            val l = l_arr(j)
            if ((p == "-" || p.trim == "") && (l.contains(",") && l.contains("."))) {
              in_tl_points_arr += l
            } else {
              in_tl_points_arr += p
            }
          }
          out_tl_points_arr += in_tl_points_arr.mkString("_")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    out_tl_points_arr.mkString("|")
  })

  def pointBackUDF = udf((tl_points: String, tl_link: String) => {
    val new_tl_points_arr = new ListBuffer[String]()
    try {
      if (strNotNull(tl_points) && strNotNull(tl_link)) {
        val tl_points_arr = tl_points.split("\\|")
        val tl_link_arr = tl_link.split("\\|")
        for (i <- 0 until tl_points_arr.size) {
          val p = tl_points_arr(i)
          val link = tl_link_arr(i)
          if ((p == "-" || p.trim == "") && (link.contains(",") && link.contains("."))) {
            new_tl_points_arr += link
          } else {
            new_tl_points_arr += p
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    new_tl_points_arr.mkString("|")
  })

  def getLinkMapRoad = udf((road_id: String, tl_link: String, link_road_points: String, road_start_swid: String, road_end_swid: String) => {
    val hm = collection.mutable.Map[String, (String, String)]()
    val more_link_ab, tl_road_ab, tl_points_ab, road_points_ab, road_points_start_ab, road_points_end_ab = new ArrayBuffer[String]()
    if (strNotNull(link_road_points)) {
      try {
        val all_arr = link_road_points.split("\\|", -1)
        for (i <- 0 until all_arr.size) {
          val one_links = all_arr(i).split("&")(0)
          val road_name = all_arr(i).split("&")(1)
          val points = all_arr(i).split("&")(2)
          hm.put(one_links, (road_name, points))
        }
      } catch {
        case e: Exception => "" + e
      }
    }

    if (strNotNull(road_start_swid) && strNotNull(road_end_swid)) {
      try {
        val start_swid_arr = road_start_swid.split("\\|", -1)
        val end_swid_arr = road_end_swid.split("\\|", -1)
        for (i <- 0 until start_swid_arr.size) {
          val start_pt = hm.getOrElse(start_swid_arr(i), ("-", "-"))._2
          val end_pt = hm.getOrElse(end_swid_arr(i), ("-", "-"))._2
          var st, ed = ""
          if (start_pt.trim != "-") {
            val new_xy = start_pt.split(";")(0)
            val x = new_xy.split(",")(0)
            val y = new_xy.split(",")(1)
            st = x.toDouble.formatted("%.6f") + "," + y.toDouble.formatted("%.6f")
          } else {
            st = hm.getOrElse(start_swid_arr(i), ("-", "-"))._2
          }
          if (end_pt.trim != "-") {
            val new_xy = end_pt.split(";")(0)
            val x = new_xy.split(",")(0)
            val y = new_xy.split(",")(1)
            ed = x.toDouble.formatted("%.6f") + "," + y.toDouble.formatted("%.6f")
          } else {
            ed = hm.getOrElse(end_swid_arr(i), ("-", "-"))._2
          }
          road_points_start_ab += st
          road_points_end_ab += ed
          road_points_ab += (st + "_" + ed)
        }
      } catch {
        case e: Exception => "" + e
      }
    }

    if (strNotNull(road_id)) {
      try {
        val road_id_arr = road_id.split("\\|", -1)
        for (i <- 0 until road_id_arr.size) {
          val more_links = road_id_arr(i)
          val o_link_ab = new ArrayBuffer[String]()
          if (strNotNull(more_links)) {
            val more_links_arr = more_links.split("_")
            for (j <- 0 until more_links_arr.size) {
              val o_link = more_links_arr(j)
              o_link_ab += hm.getOrElse(o_link, ("-", "-"))._1
            }
            more_link_ab += o_link_ab.mkString("_")
          }
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    if (strNotNull(tl_link)) {
      try {
        val tl_link_arr = tl_link.split("\\|", -1)
        for (i <- 0 until tl_link_arr.size) {
          val tl_one_links = tl_link_arr(i)
          if (strNotNull(tl_one_links)) {
            tl_road_ab += hm.getOrElse(tl_one_links, ("-", "-"))._1
            val xy = hm.getOrElse(tl_one_links, ("-", "-"))._2
            if (xy.trim != "-") {
              val new_xy = xy.split(";")(0)
              val x = new_xy.split(",")(0)
              val y = new_xy.split(",")(1)
              tl_points_ab += x.toDouble.formatted("%.6f") + "," + y.toDouble.formatted("%.6f")
            } else {
              tl_points_ab += hm.getOrElse(tl_one_links, ("-", "-"))._2
            }
          }
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    more_link_ab.mkString("|") + "&" + tl_road_ab.mkString("|") + "&" + tl_points_ab.mkString("|") + "&" + road_points_ab.mkString("|") + "&" + road_points_start_ab.mkString("|") + "&" + road_points_end_ab.mkString(" | ")
  })


  def gettlLinkWithPointUdf = udf((tl_link: String) => {
    val start_ab = new ArrayBuffer[String]()
    try {
      if (tl_link.trim != "") {
        val tl_link_arr = tl_link.split("\\|")
        for (i <- 0 until tl_link_arr.length) {
          val link = tl_link_arr(i)
          if (!link.startsWith("Z")) {
            start_ab += base32ToDecimal(link).toString
          }
          if (link.startsWith("Z") && link.contains("W")) {
            val xy = link.replace("Z", "").split("W")
            val x_point = xy(0)
            val y_point = xy(1)
            val x = base32ToDecimal(x_point) / 1000000.0
            val y = base32ToDecimal(y_point) / 1000000.0
            start_ab += (x + "," + y)
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    start_ab.mkString("|")
  })

  def getroadSwidWithPointUdf = udf((road_id: String) => {
    val start_ab = new ArrayBuffer[String]()
    val end_ab = new ArrayBuffer[String]()
    val road_id_ab = new ArrayBuffer[String]()

    if (road_id.trim != "") {
      val road_id_arr = road_id.split("\\|")
      for (i <- 0 until road_id_arr.length) {
        val in_ab = new ArrayBuffer[String]()
        try {
          val s1 = road_id_arr(i).split("_") //此处默认 首尾两处均为link 而非point
          start_ab += base32ToDecimal(s1(0)).toString
          end_ab += base32ToDecimal(s1(s1.length - 1)).toString
          for (j <- 0 until s1.length) {
            val link = s1(j)
            if (!link.startsWith("Z")) {
              in_ab += base32ToDecimal(link).toString
            }
            if (link.startsWith("Z") && link.contains("W")) {
              val xy = link.replace("Z", "").split("W")
              val x_point = xy(0)
              val y_point = xy(1)
              val x = base32ToDecimal(x_point) / 1000000.0
              val y = base32ToDecimal(y_point) / 1000000.0
              in_ab += (x + "," + y)
            }
          }
        } catch {
          case e: Exception => "" + e
        }
        road_id_ab += in_ab.mkString("_")
      }
    }
    start_ab.mkString("|") + "&" + end_ab.mkString("|") + "&" + road_id_ab.mkString("|")
  })

  /**
   * 接口获取道路信息
   *
   * @param td_links
   * @return
   */
  def getRoadInfo(td_links: String): String = {
    val merge_swid_road_points_arr = new ArrayBuffer[String]()
    val params = s"""sw_id=$td_links&point=1&output=json""".stripMargin
    try {
      val hw_str = HttpInvokeUtil.sendPostText(HTTP_CLUSTER_LINK_P, params, 3, 2)
      logger.error(">>>>>>>>>>接口正常调用中>>>>>>>")
      val hw_str_json = JSON.parseObject(hw_str)
      val clusters = hw_str_json.getJSONArray("clusters")
      if (clusters != null && clusters.size() > 0) {
        for (i <- 0 until clusters.size()) {
          val relLinks = clusters.getJSONObject(i).getJSONArray("relLinks")
          if (relLinks != null && relLinks.size() > 0) {
            val only = relLinks.getJSONObject(0)
            val swId = if (only.getString("swId") == "") "-" else only.getString("swId")
            val road_name = if (only.getString("name") == "") "-" else only.getString("name")
            val points = only.getJSONArray("points")
            val points_in_arr = new ArrayBuffer[String]()
            if (points != null && points.size() > 0) {
              for (k <- 0 until points.size()) {
                val x = points.getJSONObject(k).getString("x")
                val y = points.getJSONObject(k).getString("y")
                points_in_arr += x + "," + y
              }
            } else {
              points_in_arr += "-"
            }
            merge_swid_road_points_arr += swId + "&" + road_name + "&" + points_in_arr.mkString(";")
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    merge_swid_road_points_arr.mkString("|")
  }
}




















