package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.getSmartDeMysqlConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}

/**
 * @description: mysql数据抽至hive平台 422805
 * @author 01418539 caojia
 * @date 2022/3/24 11:17
 */
object LoadMysqlToHive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")

    val task = args(0) //0：查询mysql中表结构及表数据总量cnt 1：向hive表中插入数据
    //    val table_name = args(1) //需要导入hive的表信息,mysql与hive表名必须保持一致
    val inc_day = args(1)
    val flag = args(2) //scomm_flow_device_status  增量或者全量加载

    val table_name = "scomm_charging_device," +
      "scomm_flow_device_status," +
      "scomm_order_record," +
      "scomm_charging_station," +
      "scomm_property_company," +
      "scomm_property_agent," +
      "scomm_device_coding_info," +
      "scomm_order_payment," +
      "scomm_charging_rule," +
      "scomm_electrovalence," +
      "scomm_user," +
      "scomm_administrative_area"

    if (args.length == 3 && task.toInt == 0) {
      querySmartMysql(table_name)
    } else if (args.length == 3 && task.toInt == 1) {
      insertToHive(spark, table_name, flag, inc_day)
    } else {
      logger.error(
        """
          |需要输入2个参数：
          |     task:0或者1(0：查询mysql中表结构及表数据总量cnt 1：向hive表中插入数据)
          |     table_name:需要导入hive的表信息,mysql与hive表名必须保持一致
          |""".stripMargin)
      sys.exit(2)
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")

  }

  def querySmartMysql(table_name: String): Unit = {
    var connection: Connection = null
    val arr = table_name.replaceAll("'", "").split(",")
    //建表语句
    for (i <- 0 until arr.length) {
      connection = getSmartDeMysqlConnect()
      val tableName = arr(i)
      try {
        val cs = s"show create table $tableName"

        val cs_create: PreparedStatement = connection.prepareStatement(cs)
        val cs_res = cs_create.executeQuery()
        while (cs_res.next()) {
          val Table = cs_res.getString("Table")
          val Create = cs_res.getString("Create Table")
          logger.error("表：" + Table + "的建表语句为：" + Create)
        }
      } catch {
        case ex: Exception =>
          connection = getSmartDeMysqlConnect()
          val cs = s"show tables"
          val cs_create: PreparedStatement = connection.prepareStatement(cs)
          val cs_res = cs_create.executeQuery()
          while (cs_res.next()) {
            val tables = cs_res.getString("Tables_in_smart_community")
            logger.error("库：smart_community中所有表为：" + tables)
          }

          logger.error(s"查看 $tableName 的建表语句时出现错误，请核对输入的表名在mysql中是否存在", ex)
          throw ex
      }
    }
    //cnt
    for (i <- 0 until arr.length) {
      connection = getSmartDeMysqlConnect()
      val tableName = arr(i)
      try {
        val cnts = s"select count(1) as cnt from $tableName limit 100"
        val cnts_count: PreparedStatement = connection.prepareStatement(cnts)
        val cnts_res = cnts_count.executeQuery()
        while (cnts_res.next()) {
          val cnt = cnts_res.getString("cnt")
          logger.error("表：" + tableName + " 的数据总量为>" + cnt)
        }
      } catch {
        case ex: Exception => logger.error(s"查询表 $tableName 中 数据总量时出现错误", ex)
          throw ex
      }
    }
  }


  def insertToHive(spark: SparkSession, table_name: String, flag: String, inc_day: String): Unit = {
    val arr = table_name.replaceAll("'", "").split(",")
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      loadMysqlToHive(spark, tableName, tableName, flag, inc_day)
    }
  }
}
