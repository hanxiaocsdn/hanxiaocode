package com.sf.app.eta.realtime

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.common.DataSourceCommon
import com.sf.gis.utils.JSONUtils
import org.apache.commons.lang3.time.FastDateFormat
import utils.ColumnUtil.lngLatToDistance
import utils.HttpInvokeUtil

import java.util.Date
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id:
 * @description:拥堵路段信息标签
 * @demander: 01408890 邵一馨
 * @author 01418539 caojia
 * @date 2023/7/19 14:50
 */
object EfficientRealTimeTrackSpeedYD extends DataSourceCommon {
  val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")

  def main(args: Array[String]): Unit = {
  }

  /**
   * 汇总 统计
   */
  def addSumaryStatistics(jo: JSONObject): JSONObject = {
    val responsibility_reason = JSONUtils.getJsonValue(jo, "responsibility_reason", "")
    var keguan_responsibility_event_id, keguan_responsibility_event_content, keguan_responsibility_event_swid, keguan_responsibility_events_s = ""

    if ("客观-拥堵".equals(responsibility_reason)) {
      //warning段时间查找最大
      val warning_label = JSONUtils.getJsonValue(jo, "warning_label", "")
      val warning_duration = JSONUtils.getJsonValue(jo, "warning_duration", "")
      val warning_event_id = JSONUtils.getJsonValue(jo, "warning_event_id", "")
      val warning_event_content = JSONUtils.getJsonValue(jo, "warning_event_content", "")
      val warning_event_s = JSONUtils.getJsonValue(jo, "warning_event_s", "")
      val warning_event_swid = JSONUtils.getJsonValue(jo, "warning_event_swid", "")

      var max_w_dura = 0.0
      var max_w_id, max_w_content, max_w_swid, max_w_s = ""
      if (strNotNull(warning_label) && warning_label.contains("客观")) {
        val w_label_arr = warning_label.split("\\|", -1)
        val w_dura_arr = warning_duration.split("\\|", -1)
        val w_id_arr = warning_event_id.split("\\|", -1)
        val w_content_arr = warning_event_content.split("\\|", -1)
        val w_swid_arr = warning_event_swid.split("\\|", -1)
        val w_s_arr = warning_event_s.split("\\|", -1)

        try {
          for (i <- 0 until w_label_arr.size) {
            val w_dura = if (strNotNull(w_dura_arr(i))) w_dura_arr(i).toDouble else 0.0
            if ("客观".equals(w_label_arr(i)) && w_dura > max_w_dura) {
              max_w_dura = w_dura
              max_w_id = w_id_arr(i)
              max_w_content = w_content_arr(i)
              max_w_swid = w_swid_arr(i)
              max_w_s = w_s_arr(i)
            }
          }
        } catch {
          case e: Exception => ""
        }
      }
      //拥堵段时间查找最大
      var max_yd_dura = 0.0
      var max_yd_id, max_yd_content, max_yd_swid, max_yd_s = ""
      val youngduDetailInfo = jo.getJSONArray("youngduDetailInfo")
      try {
        if (youngduDetailInfo != null && youngduDetailInfo.size() > 0) {
          for (j <- 0 until youngduDetailInfo.size()) {
            val org_yd = youngduDetailInfo.getJSONObject(j)
            val is_keguan = JSONUtils.getJsonValue(org_yd, "is_keguan", "")
            val disu_duration_subob = JSONUtils.getJsonValue(org_yd, "disu_duration_subob", "")
            val yongdu_events_id = JSONUtils.getJsonValue(org_yd, "yongdu_events_id", "")
            val yongdu_events_content = JSONUtils.getJsonValue(org_yd, "yongdu_events_content", "")
            val yongdu_events_swid = JSONUtils.getJsonValue(org_yd, "yongdu_events_swid", "")
            val yogndu_events_s = JSONUtils.getJsonValue(org_yd, "yogndu_events_s", "")

            if (strNotNull(is_keguan) && (is_keguan.contains("停留客观") || is_keguan.contains("低速客观"))) {
              val yd_keguan_arr = is_keguan.split(";", -1)
              val yd_dura_arr = disu_duration_subob.split(";", -1)
              val yd_id_arr = yongdu_events_id.split(";", -1)
              val yd_content_arr = yongdu_events_content.split(";", -1)
              val yd_swid_arr = yongdu_events_swid.split(";", -1)
              val yd_s_arr = yogndu_events_s.split(";", -1)

              for (k <- 0 until yd_keguan_arr.size) {
                val yd_dura = if (strNotNull(yd_dura_arr(k))) yd_dura_arr(k).toDouble else 0.0
                if (Seq("停留客观", "低速客观").contains(yd_keguan_arr(k)) && yd_dura > max_yd_dura) {
                  max_yd_dura = yd_dura
                  max_yd_id = yd_id_arr(k)
                  max_yd_content = yd_content_arr(k)
                  max_yd_swid = yd_swid_arr(k)
                  max_yd_s = yd_s_arr(k)
                }
              }
            }
          }
        }
      } catch {
        case e: Exception => ""
      }
      //最终大小判断
      if (max_w_dura > max_yd_dura) {
        keguan_responsibility_event_id = max_w_id
        keguan_responsibility_event_content = max_w_content
        keguan_responsibility_event_swid = max_w_swid
        keguan_responsibility_events_s = max_w_s
      } else {
        keguan_responsibility_event_id = max_yd_id
        keguan_responsibility_event_content = max_yd_content
        keguan_responsibility_event_swid = max_yd_swid
        keguan_responsibility_events_s = max_yd_s
      }
    }
    //
    var swid, content, id = ""
    try {
      if ("客观-封路".equals(responsibility_reason)) {
        val roadClosure = jo.getJSONArray("roadClosure")
        breakable {
          if (roadClosure != null && roadClosure.size() > 0) {
            for (i <- 0 until roadClosure.size()) {
              val org_close = roadClosure.getJSONObject(i)
              val sub_closure = JSONUtils.getJsonValue(org_close, "closure", "")
              if (strNotNull(sub_closure) && strNotNull(sub_closure.replaceAll("\\|", ""))) {
                val inner_sub_closure = sub_closure.split("\\|", -1) //3个不同事件之间是双竖线切分，不同事件之间是单竖线切分
                for (m <- 0 until inner_sub_closure.size) {
                  val in_2_sub_closure = inner_sub_closure(m).split("\\|\\|", -1)
                  for (j <- 0 until in_2_sub_closure.size) {
                    val closure_arr = in_2_sub_closure(j).split("\\+")
                    swid = closure_arr(0)
                    content = closure_arr(7)
                    id = closure_arr(8)
                    if (strNotNull(id)) {
                      keguan_responsibility_event_id = id
                      keguan_responsibility_event_swid = swid
                      keguan_responsibility_event_content = content
                      keguan_responsibility_events_s = "封路"
                      break()
                    }
                  }
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e.printStackTrace())
    }
    jo.put("keguan_responsibility_event_id", keguan_responsibility_event_id)
    jo.put("keguan_responsibility_event_content", keguan_responsibility_event_content)
    jo.put("keguan_responsibility_event_swid", keguan_responsibility_event_swid)
    jo.put("keguan_responsibility_events_s", keguan_responsibility_events_s)
    jo
  }

  /**
   * 轨迹纠偏 字段新增
   *
   * @param x
   * @param sub_actual_depart_tm
   * @param sub_actual_arrive_tm
   * @return
   */
  def parseFixResponse(x: JSONObject, sub_actual_depart_tm: String, sub_actual_arrive_tm: String) = {
    val jo = new JSONObject()
    val warning_time = x.getString("warning_time")
    val result = x.getJSONObject("result")
    val tracks = result.getJSONArray("tracks")
    val stay_points = result.getJSONArray("stay_points")
    val jp_swidBuff, jp_coordsBuff, jp_statusBuff, sum_distBuff, link_lengthBuff, speedBuff, stayDurationBuffer, stayStartBuffer, stayEndBuffer, duationPeriodsBuffer = new ArrayBuffer[String]()
    val stay_formway_out, stay_linktype_out, stay_gas_out, stay_pois_out = new ListBuffer[String]()
    val jp_timeBuff = new ArrayBuffer[Long]()
    var stayTotalDuration = 0L

    for (i <- 0 until tracks.size()) {
      val t: JSONObject = tracks.getJSONObject(i)
      jp_swidBuff.append(t.getString("SWID"))
      jp_timeBuff.append(t.getLongValue("time"))
      val x: String = t.getString("x")
      val y: String = t.getString("y")
      jp_coordsBuff.append(x + "," + y)
      jp_statusBuff.append(t.getString("status"))
      sum_distBuff.append(t.getString("sum_dist"))
      link_lengthBuff.append(t.getString("link_length"))
      speedBuff.append(t.getString("speed"))
    }

    val dist = try {
      sum_distBuff.last.toDouble
    } catch {
      case e: Exception => 0
    }

    for (i <- 0 until stay_points.size()) {
      val stayJo = stay_points.getJSONObject(i)
      val stayStartIndex = JSONUtils.getJsonValueInt(stayJo, "start_index", 0)
      val stayEndIndex = JSONUtils.getJsonValueInt(stayJo, "end_index", 0)

      val stayStartJo = try {
        tracks.getJSONObject(stayStartIndex)
      } catch {
        case e: Exception => new JSONObject()
      }
      val x1: String = stayStartJo.getString("x")
      val y1: String = stayStartJo.getString("y")

      val stayEndJo = try {
        tracks.getJSONObject(stayEndIndex)
      } catch {
        case e: Exception => new JSONObject()
      }
      val x2: String = stayEndJo.getString("x")
      val y2: String = stayEndJo.getString("y")

      val start_time = JSONUtils.getJsonValueLong(stayStartJo, "time", 0)
      val end_time = JSONUtils.getJsonValueLong(stayEndJo, "time", 0)
      val sub_depart: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_depart_tm)
      val sub_arrive: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_arrive_tm)
      var start_time_date = tranTstampToTime(sdf1, start_time.toString)
      var end_time_date = tranTstampToTime(sdf1, end_time.toString)
      if (start_time < sub_depart) start_time_date = sub_actual_depart_tm
      if (end_time > sub_arrive) end_time_date = sub_actual_arrive_tm

      if (end_time - start_time > 300) {
        val dura_tm = start_time_date + "~" + end_time_date
        val dura_tm_new = diffDurationAndWarningTime(dura_tm, warning_time)
        if (dura_tm_new != "") {
          duationPeriodsBuffer.append(dura_tm_new)
          val dura_long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_tm_new.split("~")(1)) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_tm_new.split("~")(0))
          stayTotalDuration += dura_long
          stayDurationBuffer.append(dura_long.toString)
          stayStartBuffer.append(x1 + "," + y1)
          stayEndBuffer.append(x2 + "," + y2)

          //新增 从track中获取停留点信息
          val stay_formway_in, stay_linktype_in, stay_gas_in = new ListBuffer[Int]()
          val stay_pois_in = new ListBuffer[String]()
          for (k <- stayStartIndex.toInt to stayEndIndex.toInt) {
            val trackJo = tracks.getJSONObject(k)
            val formay = JSONUtils.getJsonValueInt(trackJo, "formway", 0)
            val linktype = JSONUtils.getJsonValueInt(trackJo, "linktype", 0)
            val gas = JSONUtils.getJsonValueInt(trackJo, "gas", 0)
            if (!stay_formway_in.contains(formay)) stay_formway_in.append(formay)
            if (!stay_linktype_in.contains(linktype)) stay_linktype_in.append(linktype)
            if (!stay_gas_in.contains(gas)) stay_gas_in.append(gas)
          }
          val gas_arr = stayJo.getJSONArray("pois")
          if (gas_arr != null && gas_arr.size() > 0) {
            for (g <- 0 until gas_arr.size()) {
              val gasJo = gas_arr.getJSONObject(g)
              val _type = JSONUtils.getJsonValueInt(gasJo, "type", 0)
              val dist = JSONUtils.getJsonValueDouble(gasJo, "dist", 0.0)
              stay_pois_in.append(_type + "_" + dist)
            }
          } else {
            stay_pois_in.append("-")
          }
          stay_formway_out += (if (stay_formway_in.size != 0) stay_formway_in.mkString(",") else "-")
          stay_linktype_out += (if (stay_linktype_in.size != 0) stay_linktype_in.mkString(",") else "-")
          stay_gas_out += (if (stay_gas_in.size != 0) stay_gas_in.mkString(",") else "-")
          stay_pois_out += (if (stay_pois_in.size != 0) stay_pois_in.mkString(",") else "-")
        }
      }
    }
    jo.put("stay_formway", stay_formway_out.mkString("|"))
    jo.put("stay_linktype", stay_linktype_out.mkString("|"))
    jo.put("stay_gas", stay_gas_out.mkString("|"))
    jo.put("stay_pois", stay_pois_out.mkString("|"))
    jo.put("jp_swid", jp_swidBuff.mkString("|"))
    jo.put("jp_time", jp_timeBuff.mkString("|"))
    jo.put("jp_coords", jp_coordsBuff.mkString("|"))
    jo.put("jp_length", link_lengthBuff.mkString("|"))
    jo.put("dist", dist)
    if (stay_points == null || stay_points.isEmpty || stay_points.size() == 0) {
      stayStartBuffer.append(0 + "," + 0)
      stayEndBuffer.append(0 + "," + 0)
      stayDurationBuffer.append("0")
    }
    jo.put("stay_duration", stayDurationBuffer.mkString("|"))
    jo.put("stay_start_point", stayStartBuffer.mkString("|"))
    jo.put("stay_end_point", stayEndBuffer.mkString("|"))
    jo.put("stay_total_duration", stayTotalDuration / 60.0)
    jo.put("duation_periods", duationPeriodsBuffer.mkString("|"))
    jo
  }

  /**
   * 处理天气信息数据
   *
   * @param org_json
   * @return
   */
  def weatherInfo(org_json: JSONObject): JSONObject = {
    val report_type = org_json.getString("report_type")
    val report_point = org_json.getString("report_point")
    val warn_linkid = org_json.getString("warn_linkid")
    val warn_level = org_json.getString("warn_level")
    val jp_swid = org_json.getString("jp_swid")
    val jp_coords = org_json.getString("jp_coords")
    val swid_coords_map = getSwidLengthMap(jp_swid, jp_coords)
    val (report_dist, report_level, report_linkid, report_dist2, report_level2, report_linkid2) = getWeatherReport(report_type, report_point, warn_linkid, warn_level, swid_coords_map)
    import scala.collection.JavaConversions._
    val javaMap: java.util.Map[String, Any] = Map("report_dist" -> report_dist, "report_level" -> report_level, "report_linkid" -> report_linkid, "report_dist2" -> report_dist2, "report_level2" -> report_level2, "report_linkid2" -> report_linkid2)
    org_json.putAll(javaMap)
    org_json
  }


  def getWeatherReport(report_type: String, report_point: String, warn_linkid: String, warn_level: String, swid_coords_map: mutable.Map[String, String]): (String, String, String, String, String, String) = {
    val report_dist_ab, report_level_ab, report_linkid_ab, report_dist_ab2, report_level_ab2, report_linkid_ab2 = new ListBuffer[String]()
    try {
      if (strNotNull(report_type)) {
        val type_arr = report_type.split("\\|")
        val point_arr = report_point.split("\\|")
        val linkid_arr = warn_linkid.split("\\|")
        val level_arr = warn_level.split("\\|")
        for (m <- 0 until point_arr.length) {
          if (type_arr(m) == "3") {
            val x_point = point_arr(m).split(",")(0)
            val y_point = point_arr(m).split(",")(1)
            var min_dist1, min_dist2: Double = 999999999.0
            var index1, index2: Int = 999999999
            for (i <- 0 until linkid_arr.length) {
              val coords = swid_coords_map.getOrElse(linkid_arr(i), "")
              val x_coords = coords.split(",")(0)
              val y_coords = coords.split(",")(1)
              if (strNotNull(linkid_arr(i)) && strNotNull(coords)) {
                val dist = lngLatToDistance(x_point, y_point, x_coords, y_coords)
                if (dist < min_dist1) {
                  min_dist1 = dist
                  index1 = i
                }
              }
              if (level_arr(i) != "1") {
                if (strNotNull(linkid_arr(i)) && strNotNull(coords)) {
                  val dist = lngLatToDistance(x_point, y_point, x_coords, y_coords)
                  if (dist < min_dist2) {
                    min_dist2 = dist
                    index2 = i
                  }
                }
              }
            }
            report_dist_ab += (if (min_dist1 == 999999999.0) "" else min_dist1.formatted("%.2f"))
            report_level_ab += (try {
              level_arr(index1)
            } catch {
              case e: Exception => ""
            })
            report_linkid_ab += (try {
              linkid_arr(index1)
            } catch {
              case e: Exception => ""
            })
            report_dist_ab2 += (if (min_dist2 == 999999999.0) "" else min_dist2.formatted("%.2f"))
            report_level_ab2 += (try {
              level_arr(index2)
            } catch {
              case e: Exception => ""
            })
            report_linkid_ab2 += (try {
              linkid_arr(index2)
            } catch {
              case e: Exception => ""
            })
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (report_dist_ab.mkString("|"), report_level_ab.mkString("|"), report_linkid_ab.mkString("|"), report_dist_ab2.mkString("|"), report_level_ab2.mkString("|"), report_linkid_ab2.mkString("|"))
  }

  /**
   * 处理停留信息数据
   *
   * @param org_json
   * @return
   */
  def stayInfo(org_json: JSONObject): JSONObject = {
    val status_gd = if (strNotNull(org_json.getString("status_gd"))) org_json.getString("status_gd") else ""
    val swid_gd = if (strNotNull(org_json.getString("swid_gd"))) org_json.getString("swid_gd") else ""
    val speed_gd = if (strNotNull(org_json.getString("speed_gd"))) org_json.getString("speed_gd") else ""
    val duation_periods_tmp = org_json.getString("duation_periods")
    val duation_periods = if (strNotNull(duation_periods_tmp)) duation_periods_tmp else ""
    val sub_actual_depart_tm = org_json.getString("sub_actual_depart_tm")
    val sub_actual_arrive_tm = org_json.getString("sub_actual_arrive_tm")
    val jp_swid = org_json.getString("jp_swid")
    val jp_time = org_json.getString("jp_time")
    val jp_length = org_json.getString("jp_length")
    val swid_length_map = getSwidLengthMap(jp_swid, jp_length)
    val swid_speed_map = getSwidSpeedMap(swid_gd, speed_gd)
    //todo add 停留stay的信息 新增6个字段
    val stay_start_point_tmp = org_json.getString("stay_start_point")
    val stay_end_point_tmp = org_json.getString("stay_end_point")
    val sub_start_dept_coordinate_tmp = org_json.getString("sub_start_dept_coordinate")
    val sub_end_dept_coordinate_tmp = org_json.getString("sub_end_dept_coordinate")
    val stay_linktype_tmp = org_json.getString("stay_linktype")
    val stay_formway_tmp = org_json.getString("stay_formway")
    val stay_start_point = if (strNotNull(stay_start_point_tmp)) stay_start_point_tmp else ""
    val stay_end_point = if (strNotNull(stay_end_point_tmp)) stay_end_point_tmp else ""
    val sub_start_dept_coordinate = if (strNotNull(sub_start_dept_coordinate_tmp)) sub_start_dept_coordinate_tmp else ""
    val sub_end_dept_coordinate = if (strNotNull(sub_end_dept_coordinate_tmp)) sub_end_dept_coordinate_tmp else ""
    val stay_linktype = if (strNotNull(stay_linktype_tmp)) stay_linktype_tmp else ""
    val stay_formway = if (strNotNull(stay_formway_tmp)) stay_formway_tmp else ""

    val stay_info_1 = getPeriods2WithIndexWithSwid(duation_periods, sub_actual_depart_tm, sub_actual_arrive_tm, jp_time, jp_swid)
    val duation_periods2 = stay_info_1._1
    val stay_index1 = stay_info_1._2
    val stay_index2 = stay_info_1._3
    val stay_swid = stay_info_1._4
    val stay_swid_length = getLength(stay_swid, swid_length_map)
    val len_speed = getlengthAndSpeed(stay_swid_length, duation_periods2)
    val stay_swid_length_total = len_speed._1
    val stay_speed_siji = len_speed._2
    val stay_index = getStayGDSwidIndex(stay_swid, swid_gd)
    val status_speed_info = getStaySwidAndSpeed(duation_periods2, stay_index, swid_gd, speed_gd, status_gd, swid_speed_map) //todo fix 占位符添加
    val stay_gd_swid = status_speed_info._1
    val stay_gd_speed = status_speed_info._2
    val stay_gd_status = status_speed_info._3
    val stay_swid_gd2 = status_speed_info._4
    val stay_speed_gd2 = status_speed_info._5
    val stay_swid_gd_len = getLength(stay_swid_gd2, swid_length_map)
    val stay_speed_avg_gd = getStaySpeedAvg(stay_speed_gd2, stay_swid_gd_len)
    val dist_info = getStayDist(stay_start_point, stay_end_point, sub_start_dept_coordinate, sub_end_dept_coordinate)
    val stay_start_dis = dist_info._1
    val stay_end_dis = dist_info._2
    val is_zhuguan = getZhuguan(stay_speed_avg_gd, stay_speed_siji, stay_linktype, stay_gd_status, stay_formway, stay_end_dis)
    import scala.collection.JavaConversions._
    if (strNotNull(duation_periods2)) {
      val javaMap: java.util.Map[String, Any] = Map("duation_periods2" -> duation_periods2, "stay_index1" -> stay_index1, "stay_index2" -> stay_index2, "stay_swid" -> stay_swid, "stay_swid_length" -> stay_swid_length, "stay_swid_length_total" -> stay_swid_length_total, "stay_speed_siji" -> stay_speed_siji, "stay_gd_swid" -> stay_gd_swid, "stay_gd_speed" -> stay_gd_speed, "stay_gd_status" -> stay_gd_status, "stay_swid_gd2" -> stay_swid_gd2, "stay_speed_gd2" -> stay_speed_gd2, "stay_swid_gd_len" -> stay_swid_gd_len, "stay_speed_avg_gd" -> stay_speed_avg_gd, "stay_start_dis" -> stay_start_dis, "stay_end_dis" -> stay_end_dis, "is_zhuguan" -> is_zhuguan)
      org_json.putAll(javaMap)
    }
    org_json
  }

  /**
   * 20230622 4.2 路段拥堵2段逻辑入口--路况接口后的数据返回
   * todo fix add col 20230926
   *
   * @param org_json
   */
  def parseTmcResponse(org_json: JSONObject): JSONObject = {
    val evenr_s_l_map = getEvent_S_L_Map()
    val event_info = getEventSLInfo(org_json, evenr_s_l_map) //todo fix 20230926
    val swid_gd = event_info._1
    val status_gd = event_info._2
    val speed_gd = event_info._3
    val events_swid = event_info._4
    val events_code = event_info._5
    val events_S = event_info._6
    val events_L = event_info._7
    val warn_linkid = event_info._8
    val warn_level = event_info._9
    val warn_description = event_info._10
    val event_id = event_info._11 //todo fix 20230926
    val event_content = event_info._12 //todo fix 20230926
    val new_json = new JSONObject(true)
    new_json.put("swid_gd", swid_gd)
    new_json.put("status_gd", status_gd)
    new_json.put("speed_gd", speed_gd)
    new_json.put("events_swid", events_swid)
    new_json.put("events_code", events_code)
    new_json.put("events_S", events_S)
    new_json.put("events_L", events_L)
    new_json.put("warn_linkid", warn_linkid)
    new_json.put("warn_level", warn_level)
    new_json.put("warn_description", warn_description)
    new_json.put("event_id", event_id) //todo fix 20230926
    new_json.put("event_content", event_content) //todo fix 20230926
    new_json
  }

  def getEventSLInfo(json_parse: JSONObject, evenr_s_l_map: mutable.Map[String, (String, String)]): (String, String, String, String, String, String, String, String, String, String, String, String) = {
    val swid_gd_ab, status_gd_ab, speed_gd_ab, events_swid_ab, events_code_ab, event_id_ab, event_content_ab, events_S_ab, events_L_ab, warn_linkid_ab, warn_level_ab, warn_description_ab = new ListBuffer[String]()
    val tracks = json_parse.getJSONArray("tracks")
    if (tracks != null && tracks.size() > 0) {
      val events_map = collection.mutable.Map[String, String]()
      val warn_map = collection.mutable.Map[String, String]()
      for (i <- 0 until tracks.size()) {
        //flow 的信息拆解
        val flow = tracks.getJSONObject(i).getJSONArray("flow")
        if (flow != null && flow.size() > 0) {
          for (j <- 0 until flow.size()) {
            val link_id = tracks.getJSONObject(i).getString("link_id")
            val speed = flow.getJSONObject(j).getString("speed")
            val status = flow.getJSONObject(j).getString("status")
            swid_gd_ab += link_id
            speed_gd_ab += speed
            status_gd_ab += status
          }
        }

        //events 的信息拆解
        val events = tracks.getJSONObject(i).getJSONArray("events")
        if (events != null && events.size() > 0) {
          for (j <- 0 until events.size()) {
            val link_id = tracks.getJSONObject(i).getString("link_id")
            val limit_c = events.getJSONObject(j).getString("limit_c")
            val limit_t = events.getJSONObject(j).getString("limit_t")
            val reason_c = events.getJSONObject(j).getString("reason_c")
            val reason_t = events.getJSONObject(j).getString("reason_t")
            //todo add 20230926
            val event_content_tmp = events.getJSONObject(j).getString("content")
            val event_id_tmp = events.getJSONObject(j).getString("event_id")
            val event_content = if (strNotNull(event_content_tmp)) event_content_tmp.replaceAll("\\n|\\r|\\t", "") else ""
            val event_id = if (strNotNull(event_id_tmp)) event_id_tmp else ""
            val diff_key = limit_c + "," + limit_t + "," + reason_c + "," + reason_t + "&" + link_id
            val event_key = limit_c + "," + limit_t + "," + reason_c + "," + reason_t + "&" + link_id + "&" + event_id + "&" + event_content

            if (!events_map.contains(diff_key)) {
              events_map.put(event_key, "-")
            }
          }
        }
        //warn 的信息拆解
        val warn = tracks.getJSONObject(i).getJSONArray("warn")
        if (warn != null && warn.size() > 0) {
          for (j <- 0 until warn.size()) {
            val link_id = tracks.getJSONObject(i).getString("link_id")
            val level = warn.getJSONObject(j).getString("level")
            val description = warn.getJSONObject(j).getString("description")
            val warn_key = level + "&" + description + "&" + link_id
            if (!warn_map.contains(warn_key)) {
              warn_map.put(warn_key, "-")
            }
          }
        }
      }
      if (events_map.size > 0) {
        val event_info = events_map.keys
        for (e_info <- event_info) {
          val code = e_info.split("&")(0)
          val linkid = e_info.split("&")(1)
          val event_id = e_info.split("&")(2)
          val event_content = e_info.split("&")(3)
          val event_s_l_info = evenr_s_l_map.getOrElse(code, ("-", "-"))
          events_swid_ab += linkid
          events_code_ab += code
          event_id_ab += event_id
          event_content_ab += event_content
          events_S_ab += event_s_l_info._1
          events_L_ab += event_s_l_info._2
        }
      }
      if (warn_map.size > 0) {
        val warn_level_desc = warn_map.keys
        for (warn <- warn_level_desc) {
          val level = warn.split("&")(0)
          val description = warn.split("&")(1)
          val linkid = warn.split("&")(2)
          warn_level_ab += level
          warn_description_ab += description
          warn_linkid_ab += linkid
        }
      }
    }
    (swid_gd_ab.mkString("|"), status_gd_ab.mkString("|"), speed_gd_ab.mkString("|"), events_swid_ab.mkString("|"), events_code_ab.mkString("|"), events_S_ab.mkString("|"), events_L_ab.mkString("|"), warn_linkid_ab.mkString("|"), warn_level_ab.mkString("|"), warn_description_ab.mkString("|"), event_id_ab.mkString("|"), event_content_ab.mkString("|"))
  }

  /**
   * 20230622 4.3 和 4.4 路段拥堵2段逻辑入口
   * todo fix add 20230926
   *
   * @param org_json
   */
  def processTrafficCongestion(org_json: JSONObject, url: String): JSONObject = {
    //1 原始字段
    val status_gd = org_json.getString("status_gd")
    val swid_gd = org_json.getString("swid_gd")
    val speed_gd = org_json.getString("speed_gd")
    val jp_swid = org_json.getString("jp_swid")
    val jp_coords = org_json.getString("jp_coords")
    val jp_time = org_json.getString("jp_time")
    val jp_length = org_json.getString("jp_length")
    val sub_actual_depart_tm = org_json.getString("sub_actual_depart_tm")
    val sub_actual_arrive_tm = org_json.getString("sub_actual_arrive_tm")
    val warning_time = org_json.getString("warning_time")
    //部分原始字段空值处理
    val duation_periods_tmp = org_json.getString("duation_periods")
    val events_swid_tmp = org_json.getString("events_swid")
    val events_code_tmp = org_json.getString("events_code")
    val events_id_tmp = org_json.getString("events_id") //todo add 20230926
    val events_content_tmp = org_json.getString("events_content") //todo add 20230926
    val events_S_tmp = org_json.getString("events_S")
    val events_L_tmp = org_json.getString("events_L")
    val duation_periods = if (strNotNull(duation_periods_tmp)) duation_periods_tmp else ""
    val events_swid = if (strNotNull(events_swid_tmp)) events_swid_tmp else ""
    val events_code = if (strNotNull(events_code_tmp)) events_code_tmp else ""
    val events_id = if (strNotNull(events_id_tmp)) events_id_tmp else "" //todo add 20230926
    val events_content = if (strNotNull(events_content_tmp)) events_content_tmp else "" //todo add 20230926
    val events_S = if (strNotNull(events_S_tmp)) events_S_tmp else ""
    val events_L = if (strNotNull(events_L_tmp)) events_L_tmp else ""
    //2 计算逻辑
    val event_map = getEventMap(events_swid, events_code, events_id, events_content, events_S, events_L) //todo fix 20230926
    val swid_speed_map = getSwidSpeedMap(swid_gd, speed_gd)
    val swid_length_map = getSwidLengthMap(jp_swid, jp_length)
    val xh_yd = getXuhaoAndYongdu(status_gd, swid_gd)
    val xuhao = xh_yd._1
    val yongdu_swid_tmp = xh_yd._2
    val yongdu_status = xh_yd._3
    val yt_m = getYongdutime(yongdu_swid_tmp, jp_swid, jp_time)
    val yongdu_time = yt_m._1
    val yongdu_time_tms = yt_m._2
    val fix_tm = mergeAndFixTm(xuhao, sub_actual_depart_tm, sub_actual_arrive_tm, yongdu_time_tms, jp_time, jp_swid, warning_time)
    val yongdu_time2 = fix_tm._1
    val xuhao2 = fix_tm._2
    val merge_index = fix_tm._3
    val yongdu_status2 = mergeYongduStatus(xuhao2, status_gd)
    val if_stay = durationIntersection(yongdu_time2, duation_periods)
    //jp 信息
    val coordsSwidTime = getSumDistCoordsSwid(merge_index, jp_coords, jp_swid, jp_time)
    val yongdu_coords = coordsSwidTime._1
    val yongdu_swid = coordsSwidTime._2
    val yongdu_continue_tm = coordsSwidTime._3
    val yongdu_total_duration = coordsSwidTime._4
    //事件 信息
    val event_info = getEventInfo(yongdu_swid, event_map) //todo fix 20230926
    val yongdu_events_swid = event_info._1
    val yongdu_events_code = event_info._2
    val yogndu_events_s = event_info._3
    val yongdu_events_l = event_info._4
    val yongdu_events_id = event_info._5 //todo fix 20230926
    val yongdu_events_content = event_info._6 //todo fix 20230926
    val yd_swid_speed = getYongduSwidAndSpeed(xuhao2, swid_gd, speed_gd, swid_speed_map)
    val yongdu_swid_gd = yd_swid_speed._1
    val yongdu_speed_gd = yd_swid_speed._2
    val yongdu_swid_gd2 = yd_swid_speed._3
    val yongdu_speed_gd2 = yd_swid_speed._4
    val yongdu_swid_gd_len = getLength(yongdu_swid_gd2, swid_length_map)
    val speed_len_info = getSpeedAvg(yongdu_speed_gd2, yongdu_swid_gd_len)
    val yongdu_speed_avg_gd = speed_len_info._1
    val yongdu_gd_len = speed_len_info._2

    //3 结果字段添加
    val yongduJo = new JSONObject()
    yongduJo.put("xuhao", xuhao)
    yongduJo.put("yongdu_time", yongdu_time)
    yongduJo.put("yongdu_status", yongdu_status)
    yongduJo.put("yongdu_time2", yongdu_time2)
    yongduJo.put("xuhao2", xuhao2)
    yongduJo.put("yongdu_status2", yongdu_status2)
    yongduJo.put("if_stay", if_stay)
    yongduJo.put("yongdu_coords", yongdu_coords)
    yongduJo.put("yongdu_swid", yongdu_swid)
    yongduJo.put("yongdu_continue_tm", yongdu_continue_tm)
    yongduJo.put("yongdu_total_duration", yongdu_total_duration)
    yongduJo.put("yongdu_events_swid", yongdu_events_swid)
    yongduJo.put("yongdu_events_code", yongdu_events_code)
    yongduJo.put("yogndu_events_s", yogndu_events_s)
    yongduJo.put("yongdu_events_l", yongdu_events_l)
    yongduJo.put("yongdu_events_id", yongdu_events_id) //todo fix 20230926
    yongduJo.put("yongdu_events_content", yongdu_events_content) //todo fix 20230926
    yongduJo.put("yongdu_swid_gd", yongdu_swid_gd)
    yongduJo.put("yongdu_speed_gd", yongdu_speed_gd)
    yongduJo.put("yongdu_swid_gd2", yongdu_swid_gd2)
    yongduJo.put("yongdu_speed_gd2", yongdu_speed_gd2)
    yongduJo.put("yongdu_swid_gd_len", yongdu_swid_gd_len)
    yongduJo.put("yongdu_speed_avg_gd", yongdu_speed_avg_gd)
    yongduJo.put("yongdu_gd_len", yongdu_gd_len)
    //2-2 4.4部分
    //调用经验速度接口
    val post_jam = postJamRequest(yongdu_swid, yongdu_time2, jp_swid, jp_length, url)
    val swid_exp = post_jam._1
    val speed_exp = post_jam._2
    val swid_len_exp = post_jam._3
    val disu_duration_exp = post_jam._4
    val sum_swid_len_exp = post_jam._5
    val disu_duration_subob = getDisuDurationSubob(yongdu_continue_tm, disu_duration_exp)
    val speed_siji = speedSiji(sum_swid_len_exp, yongdu_continue_tm)
    val is_keguan = getIsKeguan(yongdu_time2, disu_duration_subob, if_stay, yongdu_speed_avg_gd, speed_siji)
    yongduJo.put("swid_exp", swid_exp)
    yongduJo.put("swid_len_exp", swid_len_exp)
    yongduJo.put("speed_exp", speed_exp)
    yongduJo.put("disu_duration_exp", disu_duration_exp)
    yongduJo.put("disu_duration_subob", disu_duration_subob)
    yongduJo.put("speed_siji", speed_siji)
    yongduJo.put("is_keguan", is_keguan)

    yongduJo
  }

  def getZhuguan(stay_speed_avg_gd: String, stay_speed_siji: String, stay_linktype: String, stay_gd_status: String, stay_formway: String, stay_end_dis: String): String = {
    val is_zhuguan_arr = new ListBuffer[String]()
    if (strNotNull(stay_speed_siji)) {
      val avg_sp_arr = stay_speed_avg_gd.split("\\|")
      val siji_sp_arr = stay_speed_siji.split("\\|")
      val linktype_arr = stay_linktype.split("\\|")
      val status_arr = stay_gd_status.split(";") //todo 分隔符 需注意
      val formway_arr = stay_formway.split("\\|")
      val end_dis_arr = stay_end_dis.split("\\|")
      for (i <- 0 until siji_sp_arr.length) {
        var is_zhuguan = "未识别"
        val status_all = status_arr(i).split("\\|")
        val status_cond = status_all.contains("2") || status_all.contains("3") || status_all.contains("4")
        if (siji_sp_arr(i).toDouble > 50.0 || linktype_arr(i).split(",").contains("2")) {
          is_zhuguan = "异常数据"
        } else if (status_cond) {
          is_zhuguan = "路况拥堵"
        } else if (end_dis_arr(i).toDouble < 1500) {
          is_zhuguan = "终点"
        } else if (formway_arr(i).split(",").contains("5") && (avg_sp_arr(i).toDouble - siji_sp_arr(i).toDouble) > 15.0) {
          is_zhuguan = "服务区"
        } else if ((avg_sp_arr(i).toDouble - siji_sp_arr(i).toDouble) > 15.0) {
          is_zhuguan = "停留主观"
        }
        is_zhuguan_arr += is_zhuguan
      }
    }
    is_zhuguan_arr.mkString("|")
  }

  def getStayDist(stay_start_point: String, stay_end_point: String, sub_start_dept_coordinate: String, sub_end_dept_coordinate: String): (String, String) = {
    val stay_start_dis_arr, stay_end_dis_arr = new ListBuffer[String]()
    try {
      if (strNotNull(stay_end_point) && strNotNull(stay_end_point)) {
        val start_p_arr = stay_start_point.split("\\|")
        val end_p_arr = stay_end_point.split("\\|")
        val sub_s_lng = sub_start_dept_coordinate.split(",")(0)
        val sub_s_lat = sub_start_dept_coordinate.split(",")(1)
        val sub_e_lng = sub_end_dept_coordinate.split(",")(0)
        val sub_e_lat = sub_end_dept_coordinate.split(",")(1)
        for (i <- 0 until start_p_arr.length) {
          val s_lng = start_p_arr(i).split(",")(0)
          val s_lat = start_p_arr(i).split(",")(1)
          val e_lng = end_p_arr(i).split(",")(0)
          val e_lat = end_p_arr(i).split(",")(1)
          stay_start_dis_arr += lngLatToDistance(s_lng, s_lat, sub_s_lng, sub_s_lat).formatted("%.2f")
          stay_end_dis_arr += lngLatToDistance(e_lng, e_lat, sub_e_lng, sub_e_lat).formatted("%.2f")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (stay_start_dis_arr.mkString("|"), stay_end_dis_arr.mkString("|"))
  }

  def getStayGDSwidIndex(stay_swid: String, swid_gd: String): String = {
    val index = new ListBuffer[String]()
    if (strNotNull(stay_swid) && strNotNull(swid_gd)) {
      val swid_arr = stay_swid.split(";")
      val swid_gd_arr = swid_gd.split("\\|")
      try {
        for (i <- 0 until swid_arr.length) {
          val one_swid_arr = swid_arr(i).split("\\|")
          var ac_flag, ne_flag = true
          var start_index, end_index: Int = 999999999
          for (m <- 0 until one_swid_arr.length if ac_flag) {
            if (one_swid_arr(m) != "0") {
              ac_flag = false
              breakable {
                for (x <- 0 until swid_gd_arr.length) {
                  if (one_swid_arr(m) == swid_gd_arr(x)) {
                    start_index = x
                    break()
                  }
                }
              }
            }
          }
          for (n <- (0 until one_swid_arr.length).reverse if ne_flag) {
            if (one_swid_arr(n) != "0") {
              ne_flag = false
              breakable {
                for (y <- (0 until swid_gd_arr.length).reverse) {
                  if (one_swid_arr(n) == swid_gd_arr(y)) {
                    end_index = y
                    break()
                  }
                }
              }
            }
          }
          index += (if (start_index == 999999999) "-" else start_index) + "_" + (if (end_index == 999999999) "-" else end_index)
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    index.mkString("|")
  }

  def getlengthAndSpeed(stay_swid_length: String, duation_periods2: String): (String, String) = {
    val stay_swid_length_total_arr, stay_speed_siji_arr = new ListBuffer[String]()
    if (strNotNull(stay_swid_length) && strNotNull(duation_periods2)) {
      val len_arr = stay_swid_length.split(";", -1)
      val dura_arr = duation_periods2.split("\\|", -1)
      try {
        for (i <- 0 until len_arr.length) {
          val start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_arr(i).split("_")(0))
          val end_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_arr(i).split("_")(1))
          val swid_len_arr = len_arr(i).split("\\|", -1)
          var sum_len = 0.0
          for (j <- 0 until swid_len_arr.size) {
            sum_len += (try {
              swid_len_arr(j).toDouble
            } catch {
              case e: NumberFormatException => 0.0
            })
          }
          stay_swid_length_total_arr += sum_len.formatted("%.2f")
          stay_speed_siji_arr += (sum_len * 3.6 / (end_tm - start_tm)).formatted("%.2f")
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    (stay_swid_length_total_arr.mkString("|"), stay_speed_siji_arr.mkString("|"))
  }
  //todo add new function

  /**
   * 停留时段为子任务 task_subid,子任务内部 | 分割，子任务之间 ；分割
   *
   * @param duation_periods
   * @param sub_actual_depart_tm
   * @param sub_actual_arrive_tm
   * @param jp_time
   * @param jp_swid
   * @return
   */
  def getPeriods2WithIndexWithSwid(duation_periods: String, sub_actual_depart_tm: String, sub_actual_arrive_tm: String, jp_time: String, jp_swid: String): (String, String, String, String) = {
    var duation_periods2, stay_index1, stay_index2, stay_swid, dura_arr = new ListBuffer[String]()
    val sub_depart: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_depart_tm)
    val sub_arrive: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_arrive_tm)
    val jp_time_arr = jp_time.split("\\|")
    val jp_swid_arr = jp_swid.split("\\|")
    if (strNotNull(duation_periods)) {
      val periods_arr = duation_periods.split("\\|")
      for (j <- 0 until periods_arr.size) {
        var fix_start_tm, fix_end_tm = ""
        val start_tm_pd = periods_arr(j).split("~")(0)
        val end_tm_pd = periods_arr(j).split("~")(1)
        val start_stm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm_pd)
        val end_etm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm_pd)
        if (start_stm_pd - 60 < sub_depart) {
          fix_start_tm = sub_actual_depart_tm
        } else {
          fix_start_tm = tranTstampToTime(sdf1, (start_stm_pd - 60).toString)
        }
        if (end_etm_pd + 60 > sub_arrive) {
          fix_end_tm = sub_actual_arrive_tm
        } else {
          fix_end_tm = tranTstampToTime(sdf1, (end_etm_pd + 60).toString)
        }
        dura_arr += fix_start_tm + "_" + fix_end_tm
      }
      val jp_time_swid = getStartEndIndexFromJPTimeWithTimeBack(dura_arr, jp_time_arr, jp_swid_arr, timeToTimestampFormat)
      stay_index1 = jp_time_swid._1.map(_.toString)
      stay_index2 = jp_time_swid._2.map(_.toString)
      duation_periods2 = jp_time_swid._3
      stay_swid = jp_time_swid._4
    }
    (duation_periods2.mkString("|"), stay_index1.mkString("|"), stay_index2.mkString("|"), stay_swid.mkString(";"))
  }

  def speedSiji(sum_swid_len_exp: String, yongdu_continue_tm: String): String = {
    val speed_siji_ab = new ListBuffer[String]()
    if (strNotNull(sum_swid_len_exp)) {
      try {
        val sum_len_arr = sum_swid_len_exp.split(";")
        val yd_tm_arr = yongdu_continue_tm.split(";")
        for (i <- 0 until sum_len_arr.size) {
          val tmp = if (yd_tm_arr(i).toDouble > 0) {
            (sum_len_arr(i).toDouble * 3.6 / yd_tm_arr(i).toDouble).formatted("%.2f")
          } else "-"
          speed_siji_ab += tmp
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    speed_siji_ab.mkString(";")
  }

  def getDisuDurationSubob(yongdu_continue_tm: String, disu_duration_exp: String): String = {
    val disu_duration_subob = new ListBuffer[String]()
    if (strNotNull(yongdu_continue_tm)) {
      try {
        val ct_tm_arr = yongdu_continue_tm.split(";")
        val ex_tm_arr = disu_duration_exp.split(";")
        for (i <- 0 until ct_tm_arr.size) {
          val tmp = if (ct_tm_arr(i).toDouble < ex_tm_arr(i).toDouble) "0" else (ct_tm_arr(i).toDouble - ex_tm_arr(i).toDouble).toString
          disu_duration_subob += tmp

        }
      } catch {
        case e: Exception => "" + e
      }
    }
    disu_duration_subob.mkString(";")
  }

  def getIsKeguan(yongdu_time2: String, disu_duration_subob: String, if_stay: String, yongdu_speed_avg_gd: String, speed_siji: String): String = {
    var is_keguan = new ListBuffer[String]()
    if (strNotNull(disu_duration_subob)) {
      try {
        val yd_tm_arr = yongdu_time2.split(";")
        val dt_ob_arr = disu_duration_subob.split(";")
        val if_stay_arr = if_stay.split(";")
        val avg_gd_arr = yongdu_speed_avg_gd.split(";")
        val speed_arr = speed_siji.split(";")
        for (i <- 0 until dt_ob_arr.size) {
          val start_tm = yd_tm_arr(i).split("_")(0)
          val end_tm = yd_tm_arr(i).split("_")(1)
          if (start_tm > end_tm) {
            is_keguan += "无多余时长"
          } else if (dt_ob_arr(i).toDouble < 60.0) {
            is_keguan += "无多余时长"
          } else if (if_stay_arr(i) == "true" && avg_gd_arr(i).toDouble - speed_arr(i).toDouble <= 15.0) {
            is_keguan += "停留客观"
          } else if (if_stay_arr(i) == "true") {
            is_keguan += "停留"
          } else if (if_stay_arr(i) == "false" && avg_gd_arr(i).toDouble - speed_arr(i).toDouble <= 30.0) {
            is_keguan += "低速客观"
          } else if (if_stay_arr(i) == "false") {
            is_keguan += "低速"
          }
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    is_keguan.mkString(";")
  }

  def postJamRequest(yongdu_swid: String, yongdu_time2: String, jp_swid: String, jp_length: String, url: String): (String, String, String, String, String) = {
    val out_swid_exp_arr, out_speed_exp_arr, out_swid_len_exp_arr, out_disu_duration_exp, out_sum_swid_len_exp = new ListBuffer[String]()
    val task_swid_map = getSwidLengthMap(jp_swid, jp_length)
    val url = "http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/getExprCost"
    if (strNotNull(yongdu_swid)) {
      val yongdu_swid_arr = yongdu_swid.split(";")
      val yongdu_time2_arr = yongdu_time2.split(";")
      for (i <- 0 until (yongdu_swid_arr.length)) {
        val swid_exp_arr, speed_exp_arr, swid_len_exp_arr = new ListBuffer[String]()
        var disu_duration_exp, sum_swid_len_exp = 0.0
        val links = yongdu_swid_arr(i).replaceAll("\\|", ",")
        //去重后调接口
        val diff_links = diffSwid(links)
        val time = yongdu_time2_arr(i).split("_")(0).replaceAll("\\s+", "T").replaceAll("-|:", "")
        val start_time = yongdu_time2_arr(i).split("_")(0).split("\\s+")(1).replaceAll(":", "")
        val params = s"""{"ak": "dc894b4a3c7444b4a3505315d00b87ad","swId": 1,"links": "$diff_links","type": 1,"time": "$time","output": "json","gzip": "0","roadAttrToken": "6134FAA5B6B6ED55E87EA116466734ED"}""".stripMargin
        var jy_tracks: JSONArray = null
        try {
          val jam_str = HttpInvokeUtil.sendPost(url, params, 3, 2)
          logger.error(">>>>>>>>>>接口正常调用中>>>>>>>" + params)
          val jam_str_json = JSON.parseObject(jam_str)
          jy_tracks = jam_str_json.getJSONArray("linkCostArray")
        } catch {
          case e: Exception => "" + e
        }
        if (jy_tracks != null && jy_tracks.size() > 0) {
          for (i <- 0 until jy_tracks.size()) {
            val linkID = jy_tracks.getJSONObject(i).getString("linkID")
            swid_exp_arr += linkID
            //获取swid返回的长度
            val swid_len = task_swid_map.getOrElse(linkID, "")
            if (swid_len.trim != "") {
              swid_len_exp_arr += swid_len
            } else {
              swid_len_exp_arr += "0"
            }
            //低速速度拼接 km/h
            val costArray = jy_tracks.getJSONObject(i).getJSONArray("costArray")
            var diff = 235959
            var speed_exp_t = "0"
            if (costArray != null && costArray.size() > 0) {
              for (j <- 0 until costArray.size()) {
                val startTime = costArray.getJSONObject(j).getString("startTime")
                val speed = costArray.getJSONObject(j).getString("speed")
                val cur_diff = Math.abs(start_time.toDouble.toInt - startTime.toInt * 100) //start_time = 235523
                if (cur_diff <= diff) {
                  diff = cur_diff
                  speed_exp_t = speed
                }
              }
              val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
              disu_duration_exp += sd_tmp
              speed_exp_arr += speed_exp_t
            } else {
              val staticspeed = jy_tracks.getJSONObject(i).getString("staticSpeed")
              if (staticspeed != null) {
                speed_exp_t = staticspeed
                val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
                speed_exp_arr += staticspeed
                disu_duration_exp += sd_tmp
              } else {
                speed_exp_arr += "-"
              }
            }
          }
        }
        if (swid_len_exp_arr.size > 0) sum_swid_len_exp = swid_len_exp_arr.map(_.toDouble).sum
        if (swid_exp_arr.size == 0) swid_exp_arr += "-"
        if (speed_exp_arr.size == 0) speed_exp_arr += "-"
        if (swid_len_exp_arr.size == 0) swid_len_exp_arr += "-"
        out_swid_exp_arr += swid_exp_arr.mkString("|")
        out_speed_exp_arr += speed_exp_arr.mkString("|")
        out_swid_len_exp_arr += swid_len_exp_arr.mkString("|")
        out_disu_duration_exp += disu_duration_exp.formatted("%.2f")
        out_sum_swid_len_exp += sum_swid_len_exp.formatted("%.2f")
      }
    }
    (out_swid_exp_arr.mkString(";"), out_speed_exp_arr.mkString(";"), out_swid_len_exp_arr.mkString(";"), out_disu_duration_exp.mkString(";"), out_sum_swid_len_exp.mkString(";"))
  }

  def diffSwid(swid: String) = {
    var new_swid: Array[String] = null
    try {
      val swid_arr = swid.split(",")
      new_swid = new Array[String](swid_arr.size)
      for (i <- 0 until swid_arr.size) {
        if (swid_arr(i) != "0") {
          if (i < 1) new_swid(i) = swid_arr(i)
          if (i >= 1 && swid_arr(i) != swid_arr(i - 1)) new_swid(i) = swid_arr(i)
        }
      }
    } catch {
      case e: Exception => e + ""
    }
    new_swid.filter(_ != null).mkString(",")
  }

  def getStaySpeedAvg(stay_speed_gd2: String, stay_swid_gd_len: String): String = {
    val stay_speed_avg_gd = new ListBuffer[String]()
    try {
      if (strNotNull(stay_speed_gd2) && strNotNull(stay_swid_gd_len)) {
        val speed_arr = stay_speed_gd2.split(";", -1)
        val len_arr = stay_swid_gd_len.split(";", -1)
        for (i <- 0 until speed_arr.size) {
          val in_len_arr = len_arr(i).split("\\|", -1)
          val in_speed_arr = speed_arr(i).split("\\|", -1)
          var in_len, in_tm: Double = 0.0
          for (j <- 0 until in_speed_arr.size) {
            if (strNotNull(in_speed_arr(j)) && in_speed_arr(j) != "0" && in_speed_arr(j) != "-") {
              in_len += (try {
                in_len_arr(j).toDouble
              } catch {
                case e: NumberFormatException => 0.0
              })
              in_tm += (try {
                in_len_arr(j).toDouble
              } catch {
                case e: NumberFormatException => 0.0
              }) / 1000.0 / in_speed_arr(j).toDouble
            }
          }
          stay_speed_avg_gd += (in_len / 1000.0 / in_tm).formatted("%.2f")
        }
      }
    } catch {
      case e: Exception => ""
    }
    stay_speed_avg_gd.mkString("|")
  }

  def getSpeedAvg(yongdu_speed_gd2: String, yongdu_swid_gd_len: String): (String, String) = {
    val total_len, yongdu_speed_avg_gd = new ListBuffer[String]()
    if (strNotNull(yongdu_speed_gd2) && strNotNull(yongdu_swid_gd_len)) {
      val speed_arr = yongdu_speed_gd2.split(";", -1)
      val len_arr = yongdu_swid_gd_len.split(";", -1)
      for (i <- 0 until speed_arr.size) {
        val in_len_arr = len_arr(i).split("\\|", -1)
        val in_speed_arr = speed_arr(i).split("\\|", -1)
        var in_len, in_tm, in_total_len: Double = 0.0
        for (j <- 0 until in_speed_arr.size) {
          in_total_len += (try {
            in_len_arr(j).toDouble
          } catch {
            case e: NumberFormatException => 0.0
          })
          if (strNotNull(in_speed_arr(j)) && in_speed_arr(j) != "") {
            in_len += (try {
              in_len_arr(j).toDouble
            } catch {
              case e: NumberFormatException => 0.0
            })
            in_tm += (try {
              in_len_arr(j).toDouble
            } catch {
              case e: NumberFormatException => 0.0
            }) / 1000.0 / in_speed_arr(j).toDouble
          }
        }
        yongdu_speed_avg_gd += (in_len / 1000.0 / in_tm).formatted("%.2f")
        total_len += in_total_len.toString
      }

    }
    (yongdu_speed_avg_gd.mkString(";"), total_len.mkString(";"))
  }

  def getLength(yongdu_swid_gd2: String, swid_length_map: collection.mutable.Map[String, String]): String = {
    val yd_len_ab = new ListBuffer[String]()
    if (strNotNull(yongdu_swid_gd2)) {
      val yongdu_swid_gd2_arr = yongdu_swid_gd2.split(";")
      for (i <- 0 until yongdu_swid_gd2_arr.length) {
        val one = yongdu_swid_gd2_arr(i).split("\\|")
        val len_ab = new ListBuffer[String]()
        for (j <- 0 until one.size) {
          val len = swid_length_map.getOrElse(one(j), "-")
          len_ab += len
        }
        yd_len_ab += len_ab.mkString("|")
      }
    }
    yd_len_ab.mkString(";")
  }

  def getStaySwidAndSpeed(duation_periods2: String, index: String, swid_gd: String, speed_gd: String, status_gd: String, swid_speed_map: collection.mutable.Map[String, String]): (String, String, String, String, String) = {
    val stay_swid_ab, stay_speed_ab, stay_status_ab, stay_swid_diff_ab, stay_speed_diff_ab = new ArrayBuffer[String]()
    if (strNotNull(index) && strNotNull(swid_gd) && strNotNull(speed_gd) && strNotNull(status_gd)) {
      val index_arr = index.split("\\|")
      val swid_gd_arr = swid_gd.split("\\|")
      val speed_gd_arr = speed_gd.split("\\|")
      val status_gd_arr = status_gd.split("\\|")
      for (i <- 0 until index_arr.size) {
        val swid_ab, speed_ab, status_ab, swid_diff_ab, speed_diff_ab = new ArrayBuffer[String]()
        try {
          val start_index = index_arr(i).split("_")(0).toInt
          val end_index = index_arr(i).split("_")(1).toInt
          for (j <- start_index to end_index) {
            swid_ab += swid_gd_arr(j)
            speed_ab += speed_gd_arr(j)
            status_ab += status_gd_arr(j)
            if (!swid_diff_ab.contains(swid_gd_arr(j))) {
              val speed = swid_speed_map.getOrElse(swid_gd_arr(j), "0")
              swid_diff_ab += swid_gd_arr(j)
              speed_diff_ab += speed
            }
          }
        } catch {
          case e: Exception => "" + e
        }
        stay_swid_ab += (if (swid_ab.size > 0) swid_ab.mkString("|") else "-")
        stay_speed_ab += (if (speed_ab.size > 0) speed_ab.mkString("|") else "-")
        stay_status_ab += (if (status_ab.size > 0) status_ab.mkString("|") else "-")
        stay_swid_diff_ab += (if (swid_diff_ab.size > 0) swid_diff_ab.mkString("|") else "-")
        stay_speed_diff_ab += (if (speed_diff_ab.size > 0) speed_diff_ab.mkString("|") else "-")
      }
    } else {
      if (strNotNull(duation_periods2)) {
        val dura_pd = duation_periods2.split("\\|")
        for (i <- 0 until dura_pd.size) {
          stay_swid_ab += "-"
          stay_speed_ab += "-"
          stay_status_ab += "-"
          stay_swid_diff_ab += "-"
          stay_speed_diff_ab += "-"
        }
      }
    }
    (stay_swid_ab.mkString(";"), stay_speed_ab.mkString(";"), stay_status_ab.mkString(";"), stay_swid_diff_ab.mkString(";"), stay_speed_diff_ab.mkString(";"))
  }

  def getYongduSwidAndSpeed(xuhao2: String, swid_gd: String, speed_gd: String, swid_speed_map: collection.mutable.Map[String, String]): (String, String, String, String) = {
    val yd_swid_ab, yd_speed_ab, yd_swid_diff_ab, yd_speed_diff_ab = new ArrayBuffer[String]()
    if (strNotNull(xuhao2) && strNotNull(swid_gd) && strNotNull(speed_gd)) {
      val xuhao2_arr = xuhao2.split(";")
      val swid_gd_arr = swid_gd.split("\\|")
      val speed_gd_arr = speed_gd.split("\\|")
      for (i <- 0 until xuhao2_arr.size) {
        val start_index = xuhao2_arr(i).split("_")(0).toInt
        val end_index = xuhao2_arr(i).split("_")(1).toInt
        val swid_ab, speed_ab, swid_diff_ab, speed_diff_ab = new ArrayBuffer[String]()
        for (j <- start_index to end_index) {
          swid_ab += swid_gd_arr(j)
          speed_ab += speed_gd_arr(j)
          if (!swid_diff_ab.contains(swid_gd_arr(j))) {
            val speed = swid_speed_map.getOrElse(swid_gd_arr(j), "0")
            swid_diff_ab += swid_gd_arr(j)
            speed_diff_ab += speed
          }
        }
        yd_swid_ab += swid_ab.mkString("|")
        yd_speed_ab += speed_ab.mkString("|")
        yd_swid_diff_ab += swid_diff_ab.mkString("|")
        yd_speed_diff_ab += speed_diff_ab.mkString("|")
      }
    }
    (yd_swid_ab.mkString(";"), yd_speed_ab.mkString(";"), yd_swid_diff_ab.mkString(";"), yd_speed_diff_ab.mkString(";"))
  }

  //todo fix 20230926
  def getEventInfo(yongdu_swid: String, event_map: collection.mutable.Map[String, ListBuffer[(String, String, String, String, String)]]): (String, String, String, String, String, String) = {
    val yongdu_events_swid, yongdu_events_code, yongdu_events_id, yongdu_events_content, yogndu_events_S, yongdu_events_L = new ListBuffer[String]()
    if (strNotNull(yongdu_swid)) {
      val yongdu_swid_arr = yongdu_swid.split(";")
      for (i <- 0 until yongdu_swid_arr.size) {
        val one_swid = yongdu_swid_arr(i).split("\\|")
        val in_yongdu_events_swid, in_yongdu_events_code, in_yongdu_events_id, in_yongdu_events_content, in_yogndu_events_S, in_yongdu_events_L = new ListBuffer[String]()
        val diff_swid = new mutable.HashSet[String]()
        for (j <- 0 until one_swid.size) {
          if (event_map.contains(one_swid(j)) && !diff_swid.contains(one_swid(j))) {
            diff_swid.add(one_swid(j)) //去重yongdu_swid
            val default_lb = new ListBuffer[(String, String, String, String, String)]()
            val map_back = event_map.getOrElse(one_swid(j), default_lb)
            val mostin_yongdu_events_code, mostin_yongdu_events_id, mostin_yongdu_events_content, mostin_yogndu_events_S, mostin_yongdu_events_L = new ListBuffer[String]()
            for (k <- 0 until map_back.size) {
              val code = map_back(k)._1
              val id = map_back(k)._2
              val content = map_back(k)._3
              val s = map_back(k)._4
              val l = map_back(k)._5
              if (strNotNull(id) && !mostin_yongdu_events_id.contains(id)) {
                mostin_yongdu_events_code += code
                mostin_yongdu_events_id += id
                mostin_yongdu_events_content += content
                mostin_yogndu_events_S += s
                mostin_yongdu_events_L += l
              }
            }
            in_yongdu_events_swid += one_swid(j)
            in_yongdu_events_code += mostin_yongdu_events_code.mkString("|")
            in_yongdu_events_id += mostin_yongdu_events_id.mkString("|")
            in_yongdu_events_content += mostin_yongdu_events_content.mkString("|")
            in_yogndu_events_S += mostin_yogndu_events_S.mkString("|")
            in_yongdu_events_L += mostin_yongdu_events_L.mkString("|")
          }
        }
        if (in_yongdu_events_swid.size == 0) in_yongdu_events_swid += "-"
        if (in_yongdu_events_code.size == 0) in_yongdu_events_code += "-"
        if (in_yongdu_events_id.size == 0) in_yongdu_events_id += "-"
        if (in_yongdu_events_content.size == 0) in_yongdu_events_content += "-"
        if (in_yogndu_events_S.size == 0) in_yogndu_events_S += "-"
        if (in_yongdu_events_L.size == 0) in_yongdu_events_L += "-"
        yongdu_events_swid += in_yongdu_events_swid.mkString("|")
        yongdu_events_code += in_yongdu_events_code.mkString("|")
        yongdu_events_id += in_yongdu_events_id.mkString("|")
        yongdu_events_content += in_yongdu_events_content.mkString("|")
        yogndu_events_S += in_yogndu_events_S.mkString("|")
        yongdu_events_L += in_yongdu_events_L.mkString("|")
      }
    }
    (yongdu_events_swid.mkString(";"), yongdu_events_code.mkString(";"), yogndu_events_S.mkString(";"), yongdu_events_L.mkString(";"), yongdu_events_id.mkString(";"), yongdu_events_content.mkString(";"))
  }

  /**
   * 20230926修改前版本
   *
   * @param yongdu_swid
   * @param event_map
   * @return
   */
  def getEventInfoORG(yongdu_swid: String, event_map: collection.mutable.Map[String, ListBuffer[(String, String, String)]]): (String, String, String, String) = {
    val yongdu_events_swid, yongdu_events_code, yogndu_events_S, yongdu_events_L = new ListBuffer[String]()
    if (strNotNull(yongdu_swid)) {
      val yongdu_swid_arr = yongdu_swid.split(";")
      for (i <- 0 until yongdu_swid_arr.size) {
        val one_swid = yongdu_swid_arr(i).split("\\|")

        val in_yongdu_events_swid, in_yongdu_events_code, in_yogndu_events_S, in_yongdu_events_L = new ListBuffer[String]()
        val diff_swid = new mutable.HashSet[String]()
        var cnt_flag: Int = 0
        for (j <- 0 until one_swid.size) {
          if (event_map.contains(one_swid(j))) {
            val default_lb = new ListBuffer[(String, String, String)]()
            val map_back = event_map.getOrElse(one_swid(j), default_lb)

            if (!diff_swid.contains(one_swid(j))) {
              cnt_flag = 0
              in_yongdu_events_swid += one_swid(j)
              in_yongdu_events_code += map_back(cnt_flag)._1
              in_yogndu_events_S += map_back(cnt_flag)._2
              in_yongdu_events_L += map_back(cnt_flag)._3
              diff_swid.add(one_swid(j))
              cnt_flag += 1
            } else {
              if (cnt_flag <= map_back.size - 1) {
                in_yongdu_events_swid += one_swid(j)
                in_yongdu_events_code += map_back(cnt_flag)._1
                in_yogndu_events_S += map_back(cnt_flag)._2
                in_yongdu_events_L += map_back(cnt_flag)._3
                cnt_flag += 1
              }
            }
          }
        }
        if (in_yongdu_events_swid.size == 0) in_yongdu_events_swid += "-"
        if (in_yongdu_events_code.size == 0) in_yongdu_events_code += "-"
        if (in_yogndu_events_S.size == 0) in_yogndu_events_S += "-"
        if (in_yongdu_events_L.size == 0) in_yongdu_events_L += "-"
        yongdu_events_swid += in_yongdu_events_swid.mkString("|")
        yongdu_events_code += in_yongdu_events_code.mkString("|")
        yogndu_events_S += in_yogndu_events_S.mkString("|")
        yongdu_events_L += in_yongdu_events_L.mkString("|")
      }
    }
    (yongdu_events_swid.mkString(";"), yongdu_events_code.mkString(";"), yogndu_events_S.mkString(";"), yongdu_events_L.mkString(";"))
  }


  def getSwidLengthMap(jp_swid: String, jp_length: String): collection.mutable.Map[String, String] = {
    val swid_length_map = collection.mutable.Map[String, String]()
    if (strNotNull(jp_swid) && strNotNull(jp_length)) {
      val jp_swid_arr = jp_swid.split("\\|")
      val jp_length_arr = jp_length.split("\\|")
      for (i <- 0 until jp_swid_arr.size) {
        swid_length_map.put(jp_swid_arr(i), jp_length_arr(i))
      }
    }
    swid_length_map
  }

  def getSwidSpeedMap(swid_gd: String, speed_gd: String): collection.mutable.Map[String, String] = {
    val swid_speed_map = collection.mutable.Map[String, String]()
    if (strNotNull(swid_gd) && strNotNull(speed_gd)) {
      val swid_gd_arr = swid_gd.split("\\|")
      val speed_gd_arr = speed_gd.split("\\|")
      for (i <- 0 until swid_gd_arr.size) {
        if (swid_speed_map.contains(swid_gd_arr(i))) {
          val speed = swid_speed_map.getOrElse(swid_gd_arr(i), "0")
          if (speed_gd_arr(i).toDouble < speed.toDouble) {
            swid_speed_map.put(swid_gd_arr(i), speed_gd_arr(i))
          }
        } else {
          swid_speed_map.put(swid_gd_arr(i), speed_gd_arr(i))
        }
      }
    }
    swid_speed_map
  }

  //todo add 2 参数 20230926
  def getEventMap(events_swid: String, events_code: String, events_id: String, events_content: String, events_S: String, events_L: String): collection.mutable.Map[String, ListBuffer[(String, String, String, String, String)]] = {
    val event_map = collection.mutable.Map[String, ListBuffer[(String, String, String, String, String)]]()
    if (strNotNull(events_swid) && strNotNull(events_code) && strNotNull(events_S) && strNotNull(events_L)) {
      val events_swid_arr = events_swid.split("\\|", -1)
      val events_code_arr = events_code.split("\\|", -1)
      val events_id_arr = events_id.split("\\|", -1)
      val events_content_arr = events_content.split("\\|", -1)
      val events_S_arr = events_S.split("\\|", -1)
      val events_L_arr = events_L.split("\\|", -1)
      for (i <- 0 until events_swid_arr.size) {
        if (strNotNull(events_swid_arr(i))) {
          if (!event_map.contains(events_swid_arr(i))) {
            val new_ab = new ListBuffer[(String, String, String, String, String)]()
            new_ab += Tuple5(events_code_arr(i), events_id_arr(i), events_content_arr(i), events_S_arr(i), events_L_arr(i))
            event_map.put(events_swid_arr(i), new_ab)
          } else {
            val add_ab = event_map.getOrElse(events_swid_arr(i), ListBuffer())
            add_ab += Tuple5(events_code_arr(i), events_id_arr(i), events_content_arr(i), events_S_arr(i), events_L_arr(i))
            event_map.put(events_swid_arr(i), add_ab)
          }
        }
      }
    }
    event_map
  }

  def getSumDistCoordsSwid(merge_index: String, jp_coords: String, jp_swid: String, jp_time: String): (String, String, String, Long) = {
    val jp_coords_p, jp_swid_p, time_p = new ListBuffer[String]()
    var yongdu_total_duration: Long = 0l
    try {
      if (strNotNull(merge_index) && strNotNull(jp_coords) && strNotNull(jp_swid)) {
        val indexs: Array[String] = strHandle(merge_index, ";")
        val jp_coords_arr: Array[String] = strHandle(jp_coords, "\\|")
        val jp_swid_arr: Array[String] = strHandle(jp_swid, "\\|")
        val jp_time_arr: Array[String] = strHandle(jp_time, "\\|")
        for (index <- indexs) {
          val start_index = index.split("_")(0).toInt
          val end_index = index.split("_")(1).toInt
          val tm_inter = jp_time_arr(end_index).toLong - jp_time_arr(start_index).toLong
          time_p += tm_inter.toString
          yongdu_total_duration += tm_inter
          if (end_index + 1 < jp_coords_arr.length - 1) {
            jp_coords_p += jp_coords_arr.slice(start_index, end_index + 1).mkString("|")
            jp_swid_p += jp_swid_arr.slice(start_index, end_index + 1).mkString("|")
          } else {
            jp_coords_p += jp_coords_arr.slice(start_index, jp_coords_arr.length - 1).mkString("|")
            jp_swid_p += jp_swid_arr.slice(start_index, jp_swid_arr.length - 1).mkString("|")
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    //结果包含3部分信息： jp_coords截取部分拼接 & jp_swid 截取部分拼接 & 时间time 截取部分拼接
    (jp_coords_p.mkString(";"), jp_swid_p.mkString(";"), time_p.mkString(";"), yongdu_total_duration)
  }

  def strHandle(str: String, sep: String, flag: Boolean = true): Array[String] = {
    var res: Array[String] = Array()
    try {
      if (flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep)
      //是否需要排序
      if (!flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep).sortWith(_.compareTo(_) < 0)
    } catch {
      case e: NullPointerException => logger.error("原始数据为空" + e.getMessage)
      case e: ArrayIndexOutOfBoundsException => logger.error("指标越界" + e.getMessage)
    }
    res
  }

  def durationIntersection(yongdu_time2: String, duation_periods: String): String = {
    val if_stay = new ListBuffer[String]
    if (strNotNull(yongdu_time2)) {
      val yongdu_time2_arr = yongdu_time2.split(";")
      for (i <- 0 until yongdu_time2_arr.size) {
        val start_tm = yongdu_time2_arr(i).split("_")(0)
        val end_tm = yongdu_time2_arr(i).split("_")(1)
        val start_stm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm)
        val end_etm: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm)
        if (duation_periods == null || duation_periods.isEmpty || duation_periods.trim == "") {
          if_stay += "false"
        }
        var flag_stay = "false"
        if (strNotNull(duation_periods)) {
          val periods_arr = duation_periods.split("\\|")
          breakable {
            for (j <- 0 until periods_arr.size) {
              val start_tm_pd = periods_arr(j).split("~")(0)
              val end_tm_pd = periods_arr(j).split("~")(1)
              val start_stm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm_pd)
              val end_etm_pd: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm_pd)
              if (twoGroupinterLong(start_stm, end_etm, start_stm_pd, end_etm_pd) > 0l) {
                flag_stay = "true"
                break()
              }
            }
          }
          if_stay += flag_stay
        }
      }
    }
    if_stay.mkString(";")
  }


  /**
   * 给定时间区间 long值【0，30】--【3，10】
   *
   * @return 7（l）
   */
  def twoGroupinterLong(statistics_start_tm: Long, statistics_end_tm: Long, start_tm: Long, end_tm: Long) = {
    var diff: Long = 0
    try {
      if (statistics_end_tm < start_tm || end_tm < statistics_start_tm) {
        diff = 0
      } else if (statistics_start_tm <= start_tm && end_tm <= statistics_end_tm) {
        diff = end_tm - start_tm // 60
      } else if (start_tm <= statistics_start_tm && statistics_end_tm <= end_tm) {
        diff = statistics_end_tm - statistics_start_tm // 60
      } else if (start_tm <= statistics_end_tm && start_tm >= statistics_start_tm && statistics_end_tm <= end_tm) {
        diff = statistics_end_tm - start_tm // 60
      } else if (statistics_start_tm <= end_tm && statistics_start_tm >= start_tm && end_tm <= statistics_end_tm) {
        diff = end_tm - statistics_start_tm // 60
      } else {
        diff = 0
      }
    } catch {
      case e: Exception => logger.error("long值之间有异常" + e.getMessage)
    }
    diff
  }

  def mergeYongduStatus(Xuhao2: String, status_gd: String): String = {
    val yongdu_status2_ab = new ListBuffer[String]()
    if (strNotNull(Xuhao2) && strNotNull(status_gd)) {
      val Xuhao2_arr = Xuhao2.split(";")
      val status_gd_arr = status_gd.split("\\|") //原始数据切割符
      for (i <- 0 until Xuhao2_arr.size) {
        val start_index = Xuhao2_arr(i).split("_")(0).toInt
        val end_index = Xuhao2_arr(i).split("_")(1).toInt
        val status_hs = new mutable.HashSet[String]()
        for (j <- start_index to end_index) {
          if (Seq("2", "3", "4").contains(status_gd_arr(j))) {
            status_hs.add(status_gd_arr(j))
          }
        }
        yongdu_status2_ab += status_hs.mkString(",")
      }
    }
    yongdu_status2_ab.mkString(";")
  }

  def getYongdutime(swid_gd: String, jp_swid: String, jp_time: String): (String, String) = {
    val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")
    val road_time_tms_ab, road_time_ab = new ArrayBuffer[String]()
    if (strNotNull(swid_gd) && strNotNull(jp_swid) && strNotNull(jp_time)) {
      val swid_gd_arr = swid_gd.split(";")
      val jp_swid_arr = jp_swid.split("\\|")
      val jp_time_arr = jp_time.split("\\|")
      for (i <- 0 until swid_gd_arr.length) {
        var start_tm, end_tm = "-"
        var start_tm_lo, end_tm_lo = 0l
        try {
          val s_swid = swid_gd_arr(i).split("_")(0)
          val e_swid = swid_gd_arr(i).split("_")(1)
          if (s_swid != "-") {
            breakable {
              for (j <- 0 until jp_swid_arr.length) {
                if (jp_swid_arr(j) == s_swid) {
                  start_tm_lo = jp_time_arr(j).toLong
                  start_tm = tranTstampToTime(sdf1, jp_time_arr(j))
                  break()
                }
              }
            }
          } else {
            start_tm = "-"
          }
          if (s_swid != "-") {
            breakable {
              for (k <- (0 until jp_swid_arr.length).reverse) {
                if (jp_swid_arr(k) == e_swid) {
                  end_tm_lo = jp_time_arr(k).toLong
                  end_tm = tranTstampToTime(sdf1, jp_time_arr(k))
                  break()
                }
              }
            }
          } else {
            end_tm = "-"
          }
        } catch {
          case e: Exception => "" + e
        }
        road_time_tms_ab += start_tm_lo + "_" + end_tm_lo
        road_time_ab += start_tm + "_" + end_tm
      }
    }
    (road_time_ab.mkString(";"), road_time_tms_ab.mkString(";"))
  }

  //todo fix 时间乱序的问题
  def mergeAndFixTm(xuhao: String, sub_actual_depart_tm: String, sub_actual_arrive_tm: String, road_time_tms: String, jp_time: String, jp_swid: String, warning_time: String): (String, String, String) = {
    //判断时间间隔 并进行合并
    val merge_tm, fix_merge_tm, merge_xuhao = new ListBuffer[String]()
    try {
      val xuhao_arr = xuhao.split(";")
      val road_time_tms_ab = road_time_tms.split(";")
      var cnt = 0
      for (i <- 0 until road_time_tms_ab.size if i == cnt) {
        val s_tm = road_time_tms_ab(i).split("_")(0).toLong
        val e_tm = road_time_tms_ab(i).split("_")(1).toLong
        //xuhao
        val s_xuhao = xuhao_arr(i).split("_")(0)
        val e_xuhao = xuhao_arr(i).split("_")(1)
        breakable {
          for (j <- i + 1 until road_time_tms_ab.size if i + 1 <= road_time_tms_ab.size - 1) {
            val s_tm_p = road_time_tms_ab(j - 1).split("_")(0).toLong
            val e_tm_p = road_time_tms_ab(j - 1).split("_")(1).toLong
            val s_tm_pp = road_time_tms_ab(j).split("_")(0).toLong
            val e_tm_pp = road_time_tms_ab(j).split("_")(1).toLong
            //xuhao
            val s_xuhao_p = xuhao_arr(j - 1).split("_")(0)
            val e_xuhao_p = xuhao_arr(j - 1).split("_")(1)
            val s_xuhao_pp = xuhao_arr(j).split("_")(0)
            val e_xuhao_pp = xuhao_arr(j).split("_")(1)
            if (s_tm_p <= s_tm_pp) {
              if (j == i + 1) {
                if (s_tm_pp - e_tm > 5 * 60) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao
                  cnt = j
                  break()
                }
                if (j == road_time_tms_ab.size - 1) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_pp + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_pp
                }
              } else {
                if (s_tm_pp - e_tm_p > 5 * 60) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_p + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_p
                  cnt = j
                  break()
                }
                if (j == road_time_tms_ab.size - 1) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_pp + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_pp
                }
              }
            } else {
              if (j + 1 <= road_time_tms_ab.size - 1) {
                cnt = j + 1
                break()
              }
            }
          }
        }
        if (i == road_time_tms_ab.size - 1) {
          merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm + 2 * 60).toString)
          merge_xuhao += s_xuhao + "_" + e_xuhao
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    //计算开始和结束拥堵路段的信息
    //"sub_plan_arrive_tm":"2023-06-12 18:20:00|2023-06-12 19:15:00"
    if (merge_tm.size == 1) {
      val f1_start_tm = merge_tm(0).split("_")(0)
      val f1_end_tm = merge_tm(0).split("_")(1)
      var new_sttm = f1_start_tm
      var new_endm = f1_end_tm
      if (f1_start_tm < sub_actual_depart_tm) new_sttm = sub_actual_depart_tm
      if (f1_end_tm > sub_actual_arrive_tm) new_endm = sub_actual_arrive_tm
      fix_merge_tm += new_sttm + "_" + new_endm
    } else {
      for (k <- 0 until merge_tm.size) {
        val f1_start_tm = merge_tm(k).split("_")(0)
        val f1_end_tm = merge_tm(k).split("_")(1)
        if (k == 0) {
          if (f1_start_tm < sub_actual_depart_tm) {
            fix_merge_tm += sub_actual_depart_tm + "_" + f1_end_tm
          } else {
            fix_merge_tm += f1_start_tm + "_" + f1_end_tm
          }
        } else if (k == merge_tm.size - 1) {
          if (f1_end_tm > sub_actual_arrive_tm) {
            fix_merge_tm += f1_start_tm + "_" + sub_actual_arrive_tm
          } else {
            fix_merge_tm += f1_start_tm + "_" + f1_end_tm
          }
        } else {
          fix_merge_tm += f1_start_tm + "_" + f1_end_tm
        }
      }
    }
    //todo add
    val yd_warning = diffYongduAndWarningTime(fix_merge_tm, merge_xuhao, warning_time)
    val fix_yd_time = yd_warning._1
    val fix_xuhao = yd_warning._2
    val jp_time_arr = jp_time.split("\\|")
    val jp_swid_arr = jp_swid.split("\\|")
    //传入合并后的起始结束时间 纠偏时间集合
    val jp_index = getStartEndIndexFromJPTimeWithTimeBack(fix_yd_time, jp_time_arr, jp_swid_arr, timeToTimestampFormat)
    val start_index_arr = jp_index._1
    val end_index_arr = jp_index._2
    val start_end_index_arr = start_index_arr.zip(end_index_arr) map { x => x._1 + "_" + x._2 }

    (fix_yd_time.mkString(";"), fix_xuhao.mkString(";"), start_end_index_arr.mkString(";"))
  }

  def diffDurationAndWarningTime(dura_tm: String, warning_time: Any): String = {
    var dura_tm_new: String = ""
    val diff_warning_time = if (strNotNull(warning_time)) {
      warning_time.toString.split("\\|").flatMap(_.split("_")).map((_, 1)).groupBy(_._1).mapValues(_.length).filter(_._2 == 1).map(_._1).filter(x => x != null && x != "").toArray.sorted
    } else {
      new Array[String](0)
    }
    val warning_time_arr = new ListBuffer[String]()
    for (i <- 0 until diff_warning_time.length if i % 2 == 0) {
      val start = diff_warning_time(i)
      val end = diff_warning_time(i + 1)
      warning_time_arr += start + "_" + end
    }
    try {
      var dura_start = dura_tm.split("~")(0)
      var dura_end = dura_tm.split("~")(1)
      if (diff_warning_time.size > 0) {
        for (j <- 0 until warning_time_arr.length) {
          val wt_start = warning_time_arr(j).split("_")(0)
          val wt_end = warning_time_arr(j).split("_")(1)
          if (wt_start <= dura_end && wt_start >= dura_start && dura_end <= wt_end) { //有交集1
            dura_tm_new = dura_start + "~" + wt_start
            dura_start = dura_start
            dura_end = wt_start
          } else if (dura_start <= wt_end && dura_start >= wt_start && wt_end <= dura_end) { //有交集2
            dura_tm_new = wt_end + "~" + dura_end
            dura_start = wt_end
            dura_end = dura_end
          } else if (dura_start <= wt_start && wt_end <= dura_end) { //停留覆盖warning_time
            val l1 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_end) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_end)
            val l2 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_start) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_start)
            if (l1 >= l2) {
              dura_tm_new = wt_end + "~" + dura_end
              dura_start = wt_end
              dura_end = dura_end
            } else {
              dura_tm_new = dura_start + "~" + wt_start
              dura_start = dura_start
              dura_end = wt_start
            }
          } else if (wt_start <= dura_start && dura_end <= wt_end) { //warning_time覆盖停留
            dura_start = "99"
            dura_end = "00"
          } else if (j == warning_time_arr.length - 1 && (dura_end < wt_start || wt_end < dura_start)) { //无交集(dura_end < wt_start || wt_end < dura_start)
            dura_tm_new = dura_start + "~" + dura_end
            dura_start = dura_start
            dura_end = dura_end
          }
        }
      } else {
        dura_tm_new = dura_tm
      }
    } catch {
      case e: Exception => "" + e
    }
    dura_tm_new
  }

  //todo add function
  def diffYongduAndWarningTime(yongdu_time2_arr: ListBuffer[String], merge_xuhao: ListBuffer[String], warning_time: Any): (ListBuffer[String], ListBuffer[String]) = {
    var yd_tm, xuhao_new = new ListBuffer[String]()
    val diff_warning_time = if (strNotNull(warning_time)) {
      warning_time.toString.split("\\|").flatMap(_.split("_")).map((_, 1)).groupBy(_._1).mapValues(_.length).filter(_._2 == 1).map(_._1).filter(x => x != null && x != "").toArray.sorted
    } else {
      new Array[String](0)
    }
    val warning_time_arr = new ListBuffer[String]()
    for (i <- 0 until diff_warning_time.length if i % 2 == 0) {
      val start = diff_warning_time(i)
      val end = diff_warning_time(i + 1)
      warning_time_arr += start + "_" + end
    }
    try {
      if (diff_warning_time.size > 0) {
        for (i <- 0 until yongdu_time2_arr.length) {
          var yd_start = yongdu_time2_arr(i).split("_")(0)
          var yd_end = yongdu_time2_arr(i).split("_")(1)
          var yd_tm_new, xuhao: Any = null
          for (j <- 0 until warning_time_arr.length) {
            val wt_start = warning_time_arr(j).split("_")(0)
            val wt_end = warning_time_arr(j).split("_")(1)
            if (wt_start <= yd_end && wt_start >= yd_start && yd_end <= wt_end) { //有交集1
              xuhao = merge_xuhao(i)
              yd_tm_new = yd_start + "_" + wt_start
              yd_start = yd_start
              yd_end = wt_start
            } else if (yd_start <= wt_end && yd_start >= wt_start && wt_end <= yd_end) { //有交集2
              xuhao = merge_xuhao(i)
              yd_tm_new = wt_end + "_" + yd_end
              yd_start = wt_end
              yd_end = yd_end
            } else if (yd_start <= wt_start && wt_end <= yd_end) { //拥堵覆盖warning_time
              val l1 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", yd_end) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_end)
              val l2 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_start) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", yd_start)
              if (l1 >= l2) {
                xuhao = merge_xuhao(i)
                yd_tm_new = wt_end + "_" + yd_end
                yd_start = wt_end
                yd_end = yd_end
              } else {
                xuhao = merge_xuhao(i)
                yd_tm_new = yd_start + "_" + wt_start
                yd_start = yd_start
                yd_end = wt_start
              }
            } else if (wt_start <= yd_start && yd_end <= wt_end) { //warning_time覆盖拥堵
              xuhao = null
              yd_tm_new = null
              yd_start = "99"
              yd_end = "00"
            } else if (j == warning_time_arr.length - 1 && (yd_end < wt_start || wt_end < yd_start)) { //无交集(yd_end < wt_start || wt_end < yd_start)
              xuhao = merge_xuhao(i)
              yd_tm_new = yd_start + "_" + yd_end
              yd_start = yd_start
              yd_end = yd_end
            }
          }
          if (yd_tm_new != null) {
            yd_tm.append(yd_tm_new.toString)
            xuhao_new.append(xuhao.toString)
          }
        }
      } else {
        yd_tm = yongdu_time2_arr
        xuhao_new = merge_xuhao
      }
    } catch {
      case e: Exception => "" + e
    }
    (yd_tm, xuhao_new)
  }

  /**
   * 合并后的低速时段 在jp_time中找到时间最近的起始 和 结束 时间的index
   *
   * @param ds_start_to_end
   * @param jp_time_arr
   * @param fun
   * @return
   */
  def getStartEndIndexFromJPTimeWithTimeBack(ds_start_to_end: ListBuffer[String], jp_time_arr: Array[String], jp_swid_arr: Array[String], fun: (String, String) => Long): (ListBuffer[Int], ListBuffer[Int], ListBuffer[String], ListBuffer[String]) = {
    val ds_times = ds_start_to_end.flatMap(_.split("_")).map(fun("yyyy-MM-dd HH:mm:ss", _)).sortWith(_.compareTo(_) < 0)
    val start_index_arr, end_index_arr = new ListBuffer[Int]()
    val fix_tm_arr = new Array[String](ds_times.length)
    if (ds_start_to_end.length > 0 && jp_time_arr.length > 0) {
      for (i <- 0 until ds_times.length) {
        if (i % 2 == 0) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                start_index_arr += 0
                fix_tm_arr(i) = jp_time_arr(0)
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                start_index_arr += jp_time_arr.length - 1
                fix_tm_arr(i) = jp_time_arr(jp_time_arr.length - 1)
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  start_index_arr += j
                  fix_tm_arr(i) = jp_time_arr(j)
                } else {
                  start_index_arr += j + 1
                  fix_tm_arr(i) = jp_time_arr(j + 1)
                }
                break
              }
            }
          }
        }
        if (i % 2 == 1) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                end_index_arr += 0
                fix_tm_arr(i) = jp_time_arr(0)
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                end_index_arr += jp_time_arr.length - 1
                fix_tm_arr(i) = jp_time_arr(jp_time_arr.length - 1)
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  end_index_arr += j
                  fix_tm_arr(i) = jp_time_arr(j)
                } else {
                  end_index_arr += j + 1
                  fix_tm_arr(i) = jp_time_arr(j + 1)
                }
                break
              }
            }
          }
        }
      }
    }
    //停留时间在JP时间里的fix起始和结束时间
    val start_end_tm_arr = new ListBuffer[String]()
    for (k <- 0 until fix_tm_arr.length if k % 2 == 0) {
      start_end_tm_arr += tranTstampToTime(sdf1, fix_tm_arr(k)) + "_" + tranTstampToTime(sdf1, fix_tm_arr(k + 1))
    }
    //获取stay_swid，并去重
    val jp_swid_p = new ListBuffer[String]()
    val indexs = start_index_arr.zip(end_index_arr) map { x => x._1 + "_" + x._2 }
    for (index <- indexs) {
      val start_index = index.split("_")(0).toInt
      val end_index = index.split("_")(1).toInt
      if (end_index + 1 < jp_swid_arr.length - 1) {
        val pt_swid_arr = jp_swid_arr.slice(start_index, end_index + 1)
        val new_pt_swid_arr = new Array[String](pt_swid_arr.length)
        for (i <- 0 until pt_swid_arr.length) {
          if (!new_pt_swid_arr.contains(pt_swid_arr(i))) new_pt_swid_arr(i) = pt_swid_arr(i)
        }
        jp_swid_p += new_pt_swid_arr.filter(_ != null).mkString("|")
      } else {
        val pt_swid_arr = jp_swid_arr.slice(start_index, jp_swid_arr.length - 1)
        val new_pt_swid_arr = new Array[String](pt_swid_arr.length)
        for (i <- 0 until pt_swid_arr.length) {
          if (!new_pt_swid_arr.contains(pt_swid_arr(i))) new_pt_swid_arr(i) = pt_swid_arr(i)
        }
        jp_swid_p += new_pt_swid_arr.filter(_ != null).mkString("|")
      }
    }
    (start_index_arr, end_index_arr, start_end_tm_arr, jp_swid_p)
  }

  def getXuhaoAndYongdu(status_gd: String, swid_gd: String): (String, String, String) = {
    val index_arr, yongdu_swid_arr, yongdu_status_arr = new ListBuffer[String]()
    val conStatus = Seq("2", "3", "4")
    if (strNotNull(status_gd)) {
      val status_gd_arr = status_gd.split("\\|")
      val swid_gd_arr = swid_gd.split("\\|")
      var cnt = 0
      for (i <- 0 until status_gd_arr.size if i == cnt) {
        var yongdu_status_hs: mutable.HashSet[String] = null
        if (conStatus.contains(status_gd_arr(i))) {
          yongdu_status_hs = new mutable.HashSet[String]()
          yongdu_status_hs.add(status_gd_arr(i))
          val start_index = i
          breakable {
            for (j <- i + 1 until status_gd_arr.size if i + 1 <= status_gd_arr.size - 1) {
              if (!conStatus.contains(status_gd_arr(j))) {
                val end_index = j - 1
                index_arr += start_index + "_" + end_index
                yongdu_swid_arr += swid_gd_arr(start_index) + "_" + swid_gd_arr(end_index)
                cnt = j
                break()
              } else if (j == status_gd_arr.size - 1 && conStatus.contains(status_gd_arr(j))) {
                val end_index = j
                index_arr += start_index + "_" + end_index
                yongdu_status_hs.add(status_gd_arr(j))
                yongdu_swid_arr += swid_gd_arr(start_index) + "_" + swid_gd_arr(end_index)
              } else {
                yongdu_status_hs.add(status_gd_arr(j))
              }
            }
          }
          if (yongdu_status_hs != null) yongdu_status_arr += yongdu_status_hs.mkString(",")
        } else {
          cnt += 1
        }
      }
    }
    (index_arr.mkString(";"), yongdu_swid_arr.mkString(";"), yongdu_status_arr.mkString(";"))
  }

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * 2021-01-01 11:11:11("yyyy-MM-dd HH:mm:ss")
   *
   * @return 1609470671
   */
  def timeToTimestampFormat(format: String, colValue: String): Long = {
    var ts = 0l
    try {
      val fdf = FastDateFormat.getInstance(format)
      val dt = fdf.parse(colValue)
      //时间戳毫秒转秒
      ts = dt.getTime / 1000
    } catch {
      case e: Exception => logger.error("日期字段格式有异常" + e.getMessage)
    }
    ts
  }

  /**
   * 将指定格式的 时间戳 转 日期，单位为：秒
   * eg:1609470671
   * res:2021-01-01 11:11:11 or 2021/01/01 11:11:11
   */

  def tranTstampToTime(sdf: FastDateFormat, colValue: String): String = {
    var time = ""
    try {
      time = sdf.format(new Date(colValue.toLong * 1000))
    } catch {
      case e: Exception => logger.error("时间戳>>>时间" + e.getMessage)
    }
    time
  }

  def strNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case _ => !str.toString.isEmpty && str.toString.replace("-", "").trim != ""
    }
  }


  def getEvent_S_L_Map(): mutable.Map[String, (String, String)] = {
    val event_info = Seq(("未知", "1", "0,0,18,1", "0", "无限制", "0", "无", "18", "流量", "1", "未知"),
      ("畅通", "2", "0,0,18,2", "0", "无限制", "0", "无", "18", "流量", "2", "畅通"),
      ("缓行", "3", "0,0,18,3", "0", "无限制", "0", "无", "18", "流量", "3", "缓慢"),
      ("拥堵", "4", "0,0,18,4", "0", "无限制", "0", "无", "18", "流量", "4", "拥堵"),
      ("堵塞", "5", "0,0,18,5", "0", "无限制", "0", "无", "18", "流量", "5", "堵塞"),
      ("无交通流", "6", "0,0,18,6", "0", "无限制", "0", "无", "18", "流量", "6", "无交通流"),
      ("一般交通事故", "101", "0,0,100,101", "0", "无限制", "0", "无", "100", "交通事故", "101", "一般交通事故"),
      ("严重交通事故", "102", "0,0,100,102", "0", "无限制", "0", "无", "100", "交通事故", "102", "严重交通事故"),
      ("故障车", "103", "0,0,100,103", "0", "无限制", "0", "无", "100", "交通事故", "103", "故障车"),
      ("疑似事故", "104", "0,0,100,104", "0", "无限制", "0", "无", "100", "交通事故", "104", "疑似事故"),
      ("道路施工", "201", "0,0,200,201", "0", "无限制", "0", "无", "200", "道路施工", "201", "道路施工"),
      ("施工影响出行", "202", "0,0,200,202", "0", "无限制", "0", "无", "200", "道路施工", "202", "施工影响出行"),
      ("施工不建议穿行", "203", "0,0,200,203", "0", "无限制", "0", "无", "200", "道路施工", "203", "施工不建议穿行"),
      ("施工在建", "201399", "1,1,200,399", "1", "通行限制", "1", "封路", "200", "道路施工", "399", "道路建设中"),
      ("交通管制", "301", "0,0,300,301", "0", "无限制", "0", "无", "300", "交通管制", "301", "不明确"),
      ("道路关闭", "302", "1,1,300,302", "1", "通行限制", "1", "封路", "300", "交通管制", "302", "道路关闭"),
      ("出口匝道关闭", "303", "5,1,300,303", "5", "出口匝道限制", "1", "出口匝道关闭", "300", "交通管制", "303", "出口匝道关闭"),
      ("入口匝道关闭", "304", "4,1,300,304", "4", "入口匝道限制", "1", "入口匝道关闭", "300", "交通管制", "304", "入口匝道关闭"),
      ("1条车道关闭", "305", "1,0,300,305", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "305", "1条车道关闭"),
      ("2条车道关闭", "306", "1,0,300,306", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "306", "2条车道关闭"),
      ("3条车道关闭", "307", "1,0,300,307", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "307", "3条车道关闭"),
      ("4条车道关闭", "308", "1,0,300,308", "1", "通行限制", "0", "车道关闭", "300", "交通管制", "308", "4条车道关闭"),
      ("禁止左转", "309", "1,2,300,309", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "309", "禁止左转"),
      ("禁止右转", "310", "1,2,300,310", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "310", "禁止右转"),
      ("禁止左右转", "311", "1,2,300,311", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "311", "禁止左右转"),
      ("禁止直行", "312", "1,2,300,312", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "312", "禁止直行"),
      ("禁止掉头", "313", "1,2,300,313", "1", "通行限制", "2", "转弯限制", "300", "交通管制", "313", "禁止掉头"),
      ("道路限高|限重|限宽", "314", "1,3,300,314", "1", "通行限制", "3", "车辆限制", "300", "交通管制", "314", "道路限高|限重|限宽"),
      ("其他车辆限行", "315", "1,3,300,315", "1", "通行限制", "3", "车辆限制", "300", "交通管制", "315", "其他车辆限行"),
      ("禁止停车", "316", "1,3,300,316", "1", "通行限制", "3", "车辆限制", "300", "交通管制", "316", "禁止停车"),
      ("道路建设中", "399", "1,1,300,399", "1", "通行限制", "1", "封路", "300", "交通管制", "399", "道路建设中"),
      ("大风", "401", "0,0,400,401", "0", "无限制", "0", "无", "400", "天气", "401", "大风"),
      ("飓风", "402", "0,0,400,402", "0", "无限制", "0", "无", "400", "天气", "402", "飓风"),
      ("雾", "403", "0,0,400,403", "0", "无限制", "0", "无", "400", "天气", "403", "雾"),
      ("大雾", "404", "0,0,400,404", "0", "无限制", "0", "无", "400", "天气", "404", "大雾"),
      ("雨", "405", "0,0,400,405", "0", "无限制", "0", "无", "400", "天气", "405", "雨"),
      ("大雨", "406", "0,0,400,406", "0", "无限制", "0", "无", "400", "天气", "406", "大雨"),
      ("雨夹雪", "407", "0,0,400,407", "0", "无限制", "0", "无", "400", "天气", "407", "雨夹雪"),
      ("雪", "408", "0,0,400,408", "0", "无限制", "0", "无", "400", "天气", "408", "雪"),
      ("大雪", "409", "0,0,400,409", "0", "无限制", "0", "无", "400", "天气", "409", "大雪"),
      ("冰雹", "410", "0,0,400,410", "0", "无限制", "0", "无", "400", "天气", "410", "冰雹"),
      ("破坏性冰雹", "411", "0,0,400,411", "0", "无限制", "0", "无", "400", "天气", "411", "破坏性冰雹"),
      ("寒潮", "412", "0,0,400,412", "0", "无限制", "0", "无", "400", "天气", "412", "寒潮"),
      ("沙尘暴", "413", "0,0,400,413", "0", "无限制", "0", "无", "400", "天气", "413", "沙尘暴"),
      ("高温", "414", "0,0,400,414", "0", "无限制", "0", "无", "400", "天气", "414", "高温"),
      ("干旱", "415", "0,0,400,415", "0", "无限制", "0", "无", "400", "天气", "415", "干旱"),
      ("雷电", "416", "0,0,400,416", "0", "无限制", "0", "无", "400", "天气", "416", "雷电"),
      ("霜冻", "417", "0,0,400,417", "0", "无限制", "0", "无", "400", "天气", "417", "霜冻"),
      ("霾", "418", "0,0,400,418", "0", "无限制", "0", "无", "400", "天气", "418", "霾"),
      ("台风", "419", "0,0,400,419", "0", "无限制", "0", "无", "400", "天气", "419", "台风"),
      ("雷雨大风", "420", "0,0,400,420", "0", "无限制", "0", "无", "400", "天气", "420", "雷雨大风"),
      ("森林火灾", "421", "0,0,400,421", "0", "无限制", "0", "无", "400", "天气", "421", "森林火灾"),
      ("烈风", "422", "0,0,400,422", "0", "无限制", "0", "无", "400", "天气", "422", "烈风"),
      ("风暴", "423", "0,0,400,423", "0", "无限制", "0", "无", "400", "天气", "423", "风暴"),
      ("狂爆风", "424", "0,0,400,424", "0", "无限制", "0", "无", "400", "天气", "424", "狂爆风"),
      ("龙卷风", "425", "0,0,400,425", "0", "无限制", "0", "无", "400", "天气", "425", "龙卷风"),
      ("热带风暴", "426", "0,0,400,426", "0", "无限制", "0", "无", "400", "天气", "426", "热带风暴"),
      ("强雷阵雨", "427", "0,0,400,427", "0", "无限制", "0", "无", "400", "天气", "427", "强雷阵雨"),
      ("雷阵雨伴有冰雹", "428", "0,0,400,428", "0", "无限制", "0", "无", "400", "天气", "428", "雷阵雨伴有冰雹"),
      ("极端降雨", "429", "0,0,400,429", "0", "无限制", "0", "无", "400", "天气", "429", "极端降雨"),
      ("暴雨", "430", "0,0,400,430", "0", "无限制", "0", "无", "400", "天气", "430", "暴雨"),
      ("大暴雨", "431", "0,0,400,431", "0", "无限制", "0", "无", "400", "天气", "431", "大暴雨"),
      ("特大暴雨", "432", "0,0,400,432", "0", "无限制", "0", "无", "400", "天气", "432", "特大暴雨"),
      ("冻雨", "433", "0,0,400,433", "0", "无限制", "0", "无", "400", "天气", "433", "冻雨"),
      ("中雪", "434", "0,0,400,434", "0", "无限制", "0", "无", "400", "天气", "434", "中雪"),
      ("暴雪", "435", "0,0,400,435", "0", "无限制", "0", "无", "400", "天气", "435", "暴雪"),
      ("雨雪天气", "436", "0,0,400,436", "0", "无限制", "0", "无", "400", "天气", "436", "雨雪天气"),
      ("阵雨夹雪", "437", "0,0,400,437", "0", "无限制", "0", "无", "400", "天气", "437", "阵雨夹雪"),
      ("阵雪", "438", "0,0,400,438", "0", "无限制", "0", "无", "400", "天气", "438", "阵雪"),
      ("强沙尘暴", "439", "0,0,400,439", "0", "无限制", "0", "无", "400", "天气", "439", "强沙尘暴"),
      ("雷暴", "440", "0,0,400,440", "0", "无限制", "0", "无", "400", "天气", "440", "雷暴"),
      ("路面积水", "501", "0,0,500,501", "0", "无限制", "0", "无", "500", "路面", "501", "路面积水"),
      ("路面积雪", "502", "0,0,500,502", "0", "无限制", "0", "无", "500", "路面", "502", "路面积雪"),
      ("路面薄冰", "503", "0,0,500,503", "0", "无限制", "0", "无", "500", "路面", "503", "路面薄冰"),
      ("路面沉陷", "504", "0,0,500,504", "0", "无限制", "0", "无", "500", "路面", "504", "路面沉陷"),
      ("路面有障碍物", "505", "0,0,500,505", "0", "无限制", "0", "无", "500", "路面", "505", "路面有障碍物"),
      ("路面火灾", "506", "0,0,500,506", "0", "无限制", "0", "无", "500", "路面", "506", "路面火灾"),
      ("路滑", "507", "0,0,500,507", "0", "无限制", "0", "无", "500", "路面", "507", "路滑"),
      ("路面有油", "508", "0,0,500,508", "0", "无限制", "0", "无", "500", "路面", "508", "路面有油"),
      ("路面有汽油", "509", "0,0,500,509", "0", "无限制", "0", "无", "500", "路面", "509", "路面有汽油"),
      ("路面状况较差", "510", "0,0,500,510", "0", "无限制", "0", "无", "500", "路面", "510", "路面状况较差"),
      ("危险的行驶条件", "511", "0,0,500,511", "0", "无限制", "0", "无", "500", "路面", "511", "危险的行驶条件"),
      ("极端危险的行驶条件", "512", "0,0,500,512", "0", "无限制", "0", "无", "500", "路面", "512", "极端危险的行驶条件"),
      ("连续弯路", "531", "0,0,500,531", "0", "无限制", "0", "无", "500", "路面", "531", "连续弯路"),
      ("事故高发", "532", "0,0,500,532", "0", "无限制", "0", "无", "500", "路面", "532", "事故高发"),
      ("货车多", "534", "0,0,500,534", "0", "无限制", "0", "无", "500", "路面", "534", "货车多"),
      ("异常急减速", "535", "0,0,500,535", "0", "无限制", "0", "无", "500", "路面", "535", "异常急减速"),
      ("博览会", "601", "0,0,600,601", "0", "无限制", "0", "无", "600", "活动", "601", "博览会"),
      ("国家重大活动", "602", "0,0,600,602", "0", "无限制", "0", "无", "600", "活动", "602", "国家重大活动"),
      ("集会", "603", "0,0,600,603", "0", "无限制", "0", "无", "600", "活动", "603", "集会"),
      ("大型会议", "604", "0,0,600,604", "0", "无限制", "0", "无", "600", "活动", "604", "大型会议"),
      ("体育活动", "605", "0,0,600,605", "0", "无限制", "0", "无", "600", "活动", "605", "体育活动"),
      ("文艺活动", "606", "0,0,600,606", "0", "无限制", "0", "无", "600", "活动", "606", "文艺活动"),
      ("节假日", "607", "0,0,600,607", "0", "无限制", "0", "无", "600", "活动", "607", "节假日"),
      ("洪水", "701", "0,0,700,701", "0", "无限制", "0", "无", "700", "灾害", "701", "洪水"),
      ("地震", "702", "0,0,700,702", "0", "无限制", "0", "无", "700", "灾害", "702", "地震"),
      ("岩崩", "703", "0,0,700,703", "0", "无限制", "0", "无", "700", "灾害", "703", "岩崩"),
      ("坍坡", "704", "0,0,700,704", "0", "无限制", "0", "无", "700", "灾害", "704", "坍坡"),
      ("泥石流", "705", "0,0,700,705", "0", "无限制", "0", "无", "700", "灾害", "705", "泥石流"),
      ("公告", "901", "0,0,800,901", "0", "无限制", "0", "无", "800", "公告", "901", "公告"),
      ("通车", "902", "0,0,900,902", "0", "无限制", "0", "无", "900", "其他", "902", "通车"),
      ("完成改建", "903", "0,0,900,903", "0", "无限制", "0", "无", "900", "其他", "903", "完成改建"),
      ("实景路况", "904", "0,0,900,904", "0", "无限制", "0", "无", "900", "其他", "904", "实景路况"),
      ("紧急事件", "905", "0,0,900,905", "0", "无限制", "0", "无", "900", "其他", "905", "紧急事件"),
      ("地铁事件", "906", "0,0,900,906", "0", "无限制", "0", "无", "900", "其他", "906", "地铁事件"),
      ("疫情播报", "907", "0,0,900,907", "0", "无限制", "0", "无", "900", "其他", "907", "疫情播报"),
      ("疑似事件", "908", "0,0,900,908", "0", "无限制", "0", "无", "900", "其他", "908", "疑似事件"),
      ("定制播报", "910", "0,0,900,910", "0", "无限制", "0", "无", "900", "其他", "910", "定制播报"),
      ("慢速车", "911", "0,0,900,911", "0", "无限制", "0", "无", "900", "其他", "911", "慢速车"),
      ("一般交通事故&道路关闭", "101302", "1,1,100,101", "1", "通行限制", "1", "封路", "100", "交通事故", "101", "一般交通事故"),
      ("严重交通事故&道路关闭", "102302", "1,1,100,102", "1", "通行限制", "1", "封路", "100", "交通事故", "102", "严重交通事故"),
      ("道路施工&道路关闭", "201302", "1,1,200,201", "1", "通行限制", "1", "封路", "200", "道路施工", "201", "道路施工"),
      ("大雾&道路关闭", "404302", "1,1,400,404", "1", "通行限制", "1", "封路", "400", "天气", "404", "大雾"),
      ("大雨&道路关闭", "406302", "1,1,400,406", "1", "通行限制", "1", "封路", "400", "天气", "406", "大雨"),
      ("大雪&道路关闭", "409302", "1,1,400,409", "1", "通行限制", "1", "封路", "400", "天气", "409", "大雪"),
      ("冰雹&道路关闭", "410302", "1,1,400,410", "1", "通行限制", "1", "封路", "400", "天气", "410", "冰雹"),
      ("路面积水&道路关闭", "501302", "1,1,500,501", "1", "通行限制", "1", "封路", "500", "路面", "501", "路面积水"),
      ("路面积雪&道路关闭", "502302", "1,1,500,502", "1", "通行限制", "1", "封路", "500", "路面", "502", "路面积雪"),
      ("路面薄冰&道路关闭", "503302", "1,1,500,503", "1", "通行限制", "1", "封路", "500", "路面", "503", "路面薄冰"),
      ("路面沉陷&道路关闭", "504302", "1,1,500,504", "1", "通行限制", "1", "封路", "500", "路面", "504", "路面沉陷"),
      ("路面有障碍物&道路关闭", "505302", "1,1,500,505", "1", "通行限制", "1", "封路", "500", "路面", "505", "路面有障碍物"),
      ("严重火灾&道路关闭", "506302", "1,1,500,506", "1", "通行限制", "1", "封路", "500", "路面", "506", "路面火灾"),
      ("博览会&道路关闭", "601302", "1,1,600,601", "1", "通行限制", "1", "封路", "600", "活动", "601", "博览会"),
      ("国家重大活动&道路关闭", "602302", "1,1,600,602", "1", "通行限制", "1", "封路", "600", "活动", "602", "国家重大活动"),
      ("集会&道路关闭", "603302", "1,1,600,603", "1", "通行限制", "1", "封路", "600", "活动", "603", "集会"),
      ("大型会议&道路关闭", "604302", "1,1,600,604", "1", "通行限制", "1", "封路", "600", "活动", "604", "大型会议"),
      ("体育活动&道路关闭", "605302", "1,1,600,605", "1", "通行限制", "1", "封路", "600", "活动", "605", "体育活动"),
      ("文艺活动&道路关闭", "606302", "1,1,600,606", "1", "通行限制", "1", "封路", "600", "活动", "606", "文艺活动"),
      ("节假日&道路关闭", "607302", "1,1,600,607", "1", "通行限制", "1", "封路", "600", "活动", "607", "节假日"),
      ("洪水&道路关闭", "701302", "1,1,700,701", "1", "通行限制", "1", "封路", "700", "灾害", "701", "洪水"),
      ("地震&道路关闭", "702302", "1,1,700,702", "1", "通行限制", "1", "封路", "700", "灾害", "702", "地震"),
      ("岩崩&道路关闭", "703302", "1,1,700,703", "1", "通行限制", "1", "封路", "700", "灾害", "703", "岩崩"),
      ("坍坡&道路关闭", "704302", "1,1,700,704", "1", "通行限制", "1", "封路", "700", "灾害", "704", "坍坡"),
      ("泥石流&道路关闭", "705302", "1,1,700,705", "1", "通行限制", "1", "封路", "700", "灾害", "705", "泥石流"),
      ("疫情&道路关闭", "", "1,1,6,16", "1", "通行限制", "1", "封路", "6", "疫情", "16", "疫情管制"),
      ("防疫检查站", "", "0,0,6,16", "0", "无限制", "0", "无", "6", "疫情", "16", "疫情管制"),
      ("未来事件&道路关闭", "", "1,1,19,201", "1", "通行限制", "1", "封路", "19", "未来事件", "201", "道路施工"),
      ("未来事件&道路关闭", "", "1,1,19,302", "1", "通行限制", "1", "封路", "19", "未来事件", "302", "道路关闭"),
      ("新增道路关闭", "***302", "1,1,0,255", "1", "通行限制", "1", "封路", "0", "无原因现象", "255", "不明确"))
    val event_map = mutable.Map[String, (String, String)]()
    for (i <- 0 until event_info.size) {
      event_map.put(event_info(i)._3, (event_info(i)._1, event_info(i)._9))
    }
    event_map
  }
}
