package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.hadoop.conf.Configuration
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import utils.{FTPUtil, SparkBuilder}

import scala.collection.mutable.ListBuffer

/**
 * @description: 455306 数据从ftp拉到hdfs上
 * @author 01418539 caojia
 * @date 2022/7/5 17:38
 */
object LoadFromFtpToHive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val sourcePath = args(0)
    val destinationPath = args(1)
    val fileName = args(2)
    val tableN = args(3)
    downLoadData(sourcePath, destinationPath, fileName)
    loadcsvData(spark, fileName, tableN)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def loadcsvData(spark: SparkSession, fileName: String, tableN: String): Unit = {
    //表头
    val header_arr = Array("un", "inc_day", "total_dist", "night_dirve_dist", "before_dawn_drive_dist", "early_morning_drive_dist", "afternoon_drive_dist", "dusk_drive_dist", "high_speed_dist", "state_road_dist", "provincial_dist", "county_dist", "township_dist", "dangerous_road_dist", "high_accident_road_dist", "school_road_dist", "sharp_turn_road_dist", "village_road_dist", "drive_duration_array", "total_duration", "night_dirve_duration", "before_dawn_drive_duration", "early_morning_drive_duration", "afternoon_drive_duration", "dusk_drive_duration", "dangerous_road_duration", "high_accident_road_duration", "school_road_duration", "sharp_turn_road_duration", "township_road_duration", "over_speed_duration", "over_speed_ser_duration", "over_drive_duration", "lnk_cnt", "dangerous_road_cnt", "high_accident_road_cnt", "school_road_cnt", "sharp_turn_road_cnt", "township_road_road_cnt", "operation_cnt", "operation_same_city_cnt", "adcode_map", "adcode_dist_map", "adcode_duration_map", "http_cnt", "http_try_cnt")
    val hd_sf = new ListBuffer[StructField]()

    for (i <- 0 until header_arr.length) {
      hd_sf += StructField(header_arr(i), StringType, true)
    }
    val schema = StructType(hd_sf)
    val inputPath = "hdfs://sfbdp1/user/01418539/upload/file/" + fileName
    val yy_df = spark.read
      .option("header", "false")
      .option("delimiter", ",")
      .option("inferSchema", true.toString)
      .schema(schema)
      .csv(inputPath)
      .repartition(100)
      .filter(col("inc_day") =!= "inc_day")

    //结果表1 的字段信息数据
    val res_yy = spark.sql(s"""select * from $tableN limit 1""")
    val yy_cols = res_yy.schema.map(_.name).map(col)
    writeToHive(spark, yy_df.select(yy_cols: _*), Seq("inc_day"), tableN)
  }

  def downLoadData(sourcePath: String, destinationPath: String, fileName: String): Unit = {
    val conf = new Configuration()
    val ftp = FTPUtil.getFtpClient("gisftp.sf-express.com", 21, "devftp", "brYsj2.023ftKjdev", "")
    FTPUtil.downloadFromFtpToHdfs(ftp, sourcePath, destinationPath, fileName, conf)
  }

}
