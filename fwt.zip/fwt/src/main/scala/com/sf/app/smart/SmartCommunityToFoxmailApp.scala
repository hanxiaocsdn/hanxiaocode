package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getFirstDayofMonthBeforeOrAfterUDF, getLastDayofMonthBeforeOrAfter, getMonthsBeforeOrAfter, getdaysBeforeOrAfter, getdaysBeforeOrAfterUDF, interDayStartToEnd}
import utils.SparkBuilder

/**
 * @description:（已下线20230710）431466
 * @author 01418539 caojia
 * @date 2022/4/22 10:10
 */
object SmartCommunityToFoxmailApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val inc_day = args(0)

    foxmailProcess(spark, inc_day)

    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def foxmailProcess(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    //输入日期  20220421
    val day_12month_ago = getMonthsBeforeOrAfter(inc_day, -12) //20210422
    val lastday_12month_ago = getLastDayofMonthBeforeOrAfter(inc_day, -11) //20210430
    val firstday_11month_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -11) //20210501
    val lastday_1month_ago = getdaysBeforeOrAfter(getFirstDayofMonthBeforeOrAfter(inc_day, 0), -1) //20220331
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, 0) //20220401

    //    //输入日期  20220422
    //    val day_12month_ago = "20210911" //20210422
    //    val lastday_12month_ago = "20210930" //20210430
    //    val firstday_11month_ago = "20211001" //20210501
    //    val lastday_1month_ago = getdaysBeforeOrAfter(getFirstDayofMonthBeforeOrAfter("20220421", 0), -1) //20220331
    //    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, 0) //20220401


    val o_waterbills = spark.sql(
      s"""
         |select
         |*
         |from dm_gis.summary_display_waterbills
         |where inc_day >='$day_12month_ago' and  inc_day <='$inc_day'
         |      and type ='city'
         |""".stripMargin)
      .na.fill("0", Seq("effective_order_cnt", "pay_order_cnt","ele_cnt", "amount"))
      .na.fill(0.0, Seq("order_amount"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val fiter_p1 = 'inc_day >= day_12month_ago and 'inc_day <= lastday_12month_ago
    val fiter_p2 = 'inc_day >= firstday_11month_ago and 'inc_day <= lastday_1month_ago
    val fiter_p3 = 'inc_day >= month_first_day and 'inc_day <= inc_day

    val pub_cols = Seq(col("month_flag"), col("city"), col("device_cnt"), col("device_socket_cnt"),
      col("online_device_cnt"), col("online_socket_cnt"), col("effective_order_cnt_all"), col("ele_cnt_all"),
      col("amount_all"), col("per_price2"), col("per_ele_cnt"), col("per_socket_ratio"), col("inc_day"))

    val pub_window = Window.partitionBy("city", "month_flag").orderBy(desc("inc_day"))

    val p1_wbs = o_waterbills.filter(fiter_p1)
      .withColumn("month_flag", substring('inc_day, 0, 6))
      .withColumn("day_12month_ago", lit(day_12month_ago))
      .withColumn("lastday_12month_ago", lit(lastday_12month_ago))
      .withColumn("inter_days", interDayStartToEnd('day_12month_ago, 'lastday_12month_ago))
      .withColumn("act_inter_days_flag", lit(1))
      .withColumn("device_cnt", first("device_cnt").over(pub_window))
      .withColumn("device_socket_cnt", first("device_socket_cnt").over(pub_window))
      .withColumn("online_device_cnt", first("online_device_cnt").over(pub_window))
      .withColumn("online_socket_cnt", first("online_socket_cnt").over(pub_window))
      .groupBy("city", "month_flag")
      .agg(
        first("device_cnt") as "device_cnt",
        first("device_socket_cnt") as "device_socket_cnt",
        first("online_device_cnt") as "online_device_cnt",
        first("online_socket_cnt") as "online_socket_cnt",
        first("inter_days") as "inter_days",
        sum("effective_order_cnt") as "effective_order_cnt_all",
        sum("pay_order_cnt") as "pay_order_cnt_all",
        sum("ele_cnt") as "ele_cnt_all",
        sum("amount") as "amount_all",
        sum("order_amount") as "order_amount_all",
        sum("act_inter_days_flag") as "act_inter_days"
      )
      .withColumn("per_price2", when('pay_order_cnt_all =!= 0, 'order_amount_all / 'pay_order_cnt_all).otherwise("0"))
      .withColumn("per_ele_cnt", when('effective_order_cnt_all =!= 0, 'ele_cnt_all / 'effective_order_cnt_all).otherwise("0"))
      .withColumn("per_socket_ratio", when('online_socket_cnt =!= 0, 'effective_order_cnt_all / ('online_socket_cnt * 'act_inter_days)).otherwise("0"))
      .withColumn("inc_day", lit(inc_day))
      .select(pub_cols: _*)
    //inc_day 对应 月初和月底 日期
    val monthFirstDay = getFirstDayofMonthBeforeOrAfterUDF(0)('inc_day)
    val monthLastDay = getdaysBeforeOrAfterUDF(-1)(lit(getFirstDayofMonthBeforeOrAfterUDF(1)('inc_day)))

    val p2_wbs = o_waterbills.filter(fiter_p2)
      .withColumn("month_flag", substring('inc_day, 0, 6))
      .withColumn("monthFirstDay", monthFirstDay)
      .withColumn("monthLastDay", monthLastDay)
      .withColumn("inter_days", interDayStartToEnd('monthFirstDay, 'monthLastDay))
      .withColumn("act_inter_days_flag", lit(1))
      .withColumn("device_cnt", first("device_cnt").over(pub_window))
      .withColumn("device_socket_cnt", first("device_socket_cnt").over(pub_window))
      .withColumn("online_device_cnt", first("online_device_cnt").over(pub_window))
      .withColumn("online_socket_cnt", first("online_socket_cnt").over(pub_window))
      .groupBy("city", "month_flag")
      .agg(
        first("device_cnt") as "device_cnt",
        first("device_socket_cnt") as "device_socket_cnt",
        first("online_device_cnt") as "online_device_cnt",
        first("online_socket_cnt") as "online_socket_cnt",
        first("inter_days") as "inter_days",
        sum("effective_order_cnt") as "effective_order_cnt_all",
        sum("pay_order_cnt") as "pay_order_cnt_all",
        sum("ele_cnt") as "ele_cnt_all",
        sum("amount") as "amount_all",
        sum("order_amount") as "order_amount_all",
        sum("act_inter_days_flag") as "act_inter_days"
      )
      .withColumn("per_price2", when('pay_order_cnt_all =!= 0, 'order_amount_all / 'pay_order_cnt_all).otherwise("0"))
      .withColumn("per_ele_cnt", when('effective_order_cnt_all =!= 0, 'ele_cnt_all / 'effective_order_cnt_all).otherwise("0"))
      .withColumn("per_socket_ratio", when('online_socket_cnt =!= 0, 'effective_order_cnt_all / ('online_socket_cnt * 'act_inter_days)).otherwise("0"))
      .withColumn("inc_day", lit(inc_day))
      .select(pub_cols: _*)

    val month_1 = inc_day.substring(0, 6) + "01"
    val month_7 = inc_day.substring(0, 6) + "07"
    val month_8 = inc_day.substring(0, 6) + "08"
    val month_14 = inc_day.substring(0, 6) + "14"
    val month_15 = inc_day.substring(0, 6) + "15"
    val month_21 = inc_day.substring(0, 6) + "21"
    val month_22 = inc_day.substring(0, 6) + "22"
    val month_28 = inc_day.substring(0, 6) + "28"
    val month_1_7 = month_1 + "-" + month_7
    val month_8_14 = month_8 + "-" + month_14
    val month_15_21 = month_15 + "-" + month_21
    val month_22_28 = month_22 + "-" + month_28
    //考虑闰年 2月天数29天

    val p3_wbs = o_waterbills.filter(fiter_p3)
      .withColumn("month_flag", when(lit(inc_day) <= month_7, 'inc_day)
        .when(lit(inc_day) > month_7 && lit(inc_day) <= month_14 && 'inc_day <= month_7, lit(month_1_7))
        .when(lit(inc_day) > month_7 && lit(inc_day) <= month_14 && 'inc_day > month_7, 'inc_day)
        .when(lit(inc_day) > month_14 && lit(inc_day) <= month_21 && 'inc_day <= month_7, lit(month_1_7))
        .when(lit(inc_day) > month_14 && lit(inc_day) <= month_21 && 'inc_day > month_7 && 'inc_day <= month_14, lit(month_8_14))
        .when(lit(inc_day) > month_14 && lit(inc_day) <= month_21 && 'inc_day > month_14, 'inc_day)
        .when(lit(inc_day) > month_21 && lit(inc_day) <= month_28 && 'inc_day <= month_7, lit(month_1_7))
        .when(lit(inc_day) > month_21 && lit(inc_day) <= month_28 && 'inc_day > month_7 && 'inc_day <= month_14, lit(month_8_14))
        .when(lit(inc_day) > month_21 && lit(inc_day) <= month_28 && 'inc_day > month_14 && 'inc_day <= month_21, lit(month_15_21))
        .when(lit(inc_day) > month_21 && lit(inc_day) <= month_28 && 'inc_day > month_21, 'inc_day)
        .when(lit(inc_day) > month_28 && 'inc_day <= month_7, lit(month_1_7))
        .when(lit(inc_day) > month_28 && 'inc_day > month_7 && 'inc_day <= month_14, lit(month_8_14))
        .when(lit(inc_day) > month_28 && 'inc_day > month_14 && 'inc_day <= month_21, lit(month_15_21))
        .when(lit(inc_day) > month_28 && 'inc_day > month_21 && 'inc_day <= month_28, lit(month_22_28))
        .when(lit(inc_day) > month_28 && 'inc_day > month_28, 'inc_day))
      .withColumn("act_inter_days_flag", lit(1))
      .withColumn("inter_days", when(trim(length('month_flag)) > 8, 7).otherwise(1))
      .withColumn("device_cnt", first("device_cnt").over(pub_window))
      .withColumn("device_socket_cnt", first("device_socket_cnt").over(pub_window))
      .withColumn("online_device_cnt", first("online_device_cnt").over(pub_window))
      .withColumn("online_socket_cnt", first("online_socket_cnt").over(pub_window))
      .groupBy("city", "month_flag")
      .agg(
        first("device_cnt") as "device_cnt",
        first("device_socket_cnt") as "device_socket_cnt",
        first("online_device_cnt") as "online_device_cnt",
        first("online_socket_cnt") as "online_socket_cnt",
        first("inter_days") as "inter_days",
        sum("effective_order_cnt") as "effective_order_cnt_all",
        sum("pay_order_cnt") as "pay_order_cnt_all",
        sum("ele_cnt") as "ele_cnt_all",
        sum("amount") as "amount_all",
        sum("order_amount") as "order_amount_all",
        sum("act_inter_days_flag") as "act_inter_days"
      )
      .withColumn("per_price2", when('pay_order_cnt_all =!= 0, 'order_amount_all / 'pay_order_cnt_all).otherwise("0"))
      .withColumn("per_ele_cnt", when('effective_order_cnt_all =!= 0, 'ele_cnt_all / 'effective_order_cnt_all).otherwise("0"))
      .withColumn("per_socket_ratio", when('online_socket_cnt =!= 0, 'effective_order_cnt_all / ('online_socket_cnt * 'act_inter_days)).otherwise("0"))
      .withColumn("inc_day", lit(inc_day))
      .select(pub_cols: _*)

    val city_wbs = o_waterbills
      .withColumn("act_inter_days_flag", lit(1))
      .withColumn("device_cnt", first("device_cnt").over(Window.partitionBy("city").orderBy(desc("inc_day"))))
      .withColumn("device_socket_cnt", first("device_socket_cnt").over(Window.partitionBy("city").orderBy(desc("inc_day"))))
      .withColumn("online_device_cnt", first("online_device_cnt").over(Window.partitionBy("city").orderBy(desc("inc_day"))))
      .withColumn("online_socket_cnt", first("online_socket_cnt").over(Window.partitionBy("city").orderBy(desc("inc_day"))))
      .groupBy("city")
      .agg(
        last("device_cnt") as "device_cnt",
        last("device_socket_cnt") as "device_socket_cnt",
        last("online_device_cnt") as "online_device_cnt",
        last("online_socket_cnt") as "online_socket_cnt",
        sum("effective_order_cnt") as "effective_order_cnt_all",
        sum("pay_order_cnt") as "pay_order_cnt_all",
        sum("ele_cnt") as "ele_cnt_all",
        sum("amount") as "amount_all",
        sum("order_amount") as "order_amount_all",
        sum("act_inter_days_flag") as "act_inter_days"
      )
      .withColumn("per_price2", when('pay_order_cnt_all =!= 0, 'order_amount_all / 'pay_order_cnt_all).otherwise("0"))
      .withColumn("per_ele_cnt", when('effective_order_cnt_all =!= 0, 'ele_cnt_all / 'effective_order_cnt_all).otherwise("0"))
      .withColumn("per_socket_ratio", lit("/"))//20220424  新增规则 置空
      .withColumn("month_flag", lit(""))
      .withColumn("city", concat(regexp_replace('city, "市", ""), lit("合计")))
      .withColumn("inc_day", lit(inc_day))
      .select(pub_cols: _*)
      .persist()

    val world_wbs = city_wbs
      .groupBy("month_flag")
      .agg(
        sum("device_cnt") as "device_cnt",
        sum("device_socket_cnt") as "device_socket_cnt",
        sum("online_device_cnt") as "online_device_cnt",
        sum("online_socket_cnt") as "online_socket_cnt",
        sum("effective_order_cnt_all") as "effective_order_cnt_all",
        sum("ele_cnt_all") as "ele_cnt_all",
        sum("amount_all") as "amount_all"
      )
      .withColumn("per_price2", lit("/"))
      .withColumn("per_ele_cnt", lit("/"))
      .withColumn("per_socket_ratio", lit("/"))
      .withColumn("city", lit("全国合计"))
      .withColumn("inc_day", lit(inc_day))
      .select(pub_cols: _*)
    val whole_wbs = p1_wbs.union(p2_wbs).union(p3_wbs).union(city_wbs).union(world_wbs)
      .withColumn("city_flag", when('city === "玉树藏族自治州", 1)
        .when('city === "玉树藏族自治州合计", 2)
        .when('city === "全国合计", 4).otherwise(3))
      .orderBy('city_flag, desc("city"), 'month_flag)
      .na.fill("", Seq("month_flag", "city"))
      .na.fill("0.0", Seq("device_cnt", "device_socket_cnt",
      "online_device_cnt", "online_socket_cnt", "effective_order_cnt_all", "ele_cnt_all","amount_all",
      "per_price2", "per_ele_cnt", "per_socket_ratio"))
      .drop("city_flag")

    writeToHive(spark, whole_wbs, Seq("inc_day"), "dm_gis.scomm_waterbills_foxmail")
    o_waterbills.unpersist()
    city_wbs.unpersist()

  }

}
