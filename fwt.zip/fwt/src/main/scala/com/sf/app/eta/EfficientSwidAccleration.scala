package com.sf.app.eta

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import constant.HttpConstant.HTTP_XY_COORDS_P
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.splitFun
import utils.DateUtil.{sdf1, tranTstampToTime, tranTstampToTimeUDF}
import utils.{ColumnUtil, HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.Random
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 临时执行 (已下线，部分32个城市流向截取)
 * @description: 【时效加速】路段截取
 * @demander:舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/3/1 14:23
 */

case class EfficientSwidInfo(un: String, swid_gj: String, adcode_gj: String, time_gj: String, speed_gj: String, adcode_first_gj: String, adcode_end_gj: String, time_first_gj: String, time_end_gj: String, time_taken_gj: String, swid_qm: String, roadclass_qm: String, dr_length_qm: String, formway_qm: String, swid_name_qm: String, dist_gj: String)

object EfficientSwidAccleration extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val run_flag = args(1)
    val start_num = args(2)
    val inter_num = args(3)
    val end_num = args(4)
    //    if (run_flag == "1") loadEffectiveData(spark, start_day, end_day, inc_day)
    //    if (run_flag == "1") loadEffectiveDataOrg(spark, start_day, end_day, inc_day)
    if (run_flag == "2") {
      //      val o_tracks_df = spark.sql(s"""select * from dm_gis.eta_experience_speed_track_fix_to320_his where inc_day= '$inc_day'""")
      //      procAcce(spark, o_tracks_df)
      //      val o_tracks_df = spark.sql(s"""select * from dm_gis.eta_experience_speed_track_fix_to320_jp where inc_day= '$inc_day'""")
      //      procAcceTotal(spark, o_tracks_df)
      //      val part1_df = getFlow(spark, inc_day)

      //      chooseTwoCity(spark, inc_day)
      choose60TwoCity(spark, inc_day)

      //      dealAfterInter(spark, inter_back_df)
    }
    if (run_flag == "3") {
      citySegment(spark, inc_day)
    }
    if (run_flag == "4") {
      //      citySegmentWithPart(spark, inc_day, start_num, inter_num, end_num)
      citySegmentWithPart60(spark, inc_day, start_num, inter_num, end_num)
    }

    if (run_flag == "5") {
      loadEffectiveData0329(spark)
    }

    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  /**
   * 获取一段时间的 6个省市地区的轨迹拼接信息 包含city_flag 字段
   *
   * @param spark
   * @param start_day
   * @param end_day
   * @param inc_day
   * @return
   */
  def loadEffectiveData0329(spark: SparkSession): DataFrame = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_his_0329 limit 0""").schema.map(_.name).map(col)
    val swid_infos_str = splitFun("&")('swid_infos)

    val cond = lit("120|476|953|120|476|953|120|476|953|120|476|476")

    val tl_periods_cond = lit("2022-07-12 13:43:22_2022-07-12 14:01:29|2022-07-12 19:45:00_2022-07-12 20:02:12|2022-07-12 13:43:22_2022-07-12 14:01:29|2022-07-12 19:45:00_2022-07-12 20:02:12|2022-07-12 13:43:22_2022-07-12 14:01:29|2022-07-12 19:45:00_2022-07-12 20:02:12|2022-07-12 13:43:22_2022-07-12 14:01:29|2022-07-12 19:45:00_2022-07-12 20:02:12|2022-07-12 13:43:22_2022-07-12 14:01:29|2022-07-12 19:45:00_2022-07-12 20:02:12|2022-07-12 13:43:22_2022-07-12 14:01:29|2022-07-12 19:45:00_2022-07-12 20:02:12")
    val c2 = lit("G72泉南高速|云阳山服务区|G72泉南高速|云阳山服务区|G72泉南高速|云阳山服务区|G72泉南高速|云阳山服务区|G72泉南高速|云阳山服务区|G72泉南高速|云阳山服务区")
    val c3 = lit("0|0|0|0|0|0|0|0|0|0|0|0")
    val c4 = lit("6637519634645|6800057303506|6637519634645|6800057303506|6637519634645|6800057303506|6637519634645|6800057303506|6637519634645|6800057303506|6637519634645|6800057303506")

    val o_tracks_df = spark.sql(
      s"""select un,info,inc_day actural_inc_day from dm_gis.eta_experience_speed_tracks_fix_to320 where inc_day = '20221201'
         |and un is not null and trim(un) !='' and info is not null and trim(info) !=''
         |limit 100000
         |""".stripMargin).repartition(800).persist()

    logger.error(">>>>>>>>>>>" + o_tracks_df.count())

    val res_df = o_tracks_df.withColumn("swid_infos", splitUnInfo('info))
      .withColumn("jp_swid", swid_infos_str(0))
      .withColumn("adcode", swid_infos_str(1))
      .withColumn("jp_time", swid_infos_str(2))
      .na.fill("", Seq("jp_swid"))
      .withColumn("sum_dist", finalData('jp_swid, lit("1000")))
      .withColumn("roadname", finalData('jp_swid, lit("G72泉南高速")))
      .withColumn("roadclass", finalDataRandom('jp_swid))
      .withColumn("tl_index_start", cond)
      .withColumn("tl_index_end", cond)
      .withColumn("tl_periods", tl_periods_cond)
      .withColumn("tl_road", c2)
      .withColumn("tl_roadclass", c3)
      .withColumn("tl_link", c4)
      .withColumn("inc_day", lit("20221201"))
      .select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val path = "/user/01418539/upload/file/eta"
    val options = Map(
      "header" -> "true",
      "delimiter" -> "\\t",
      "compression" -> "gzip",
      "inferSchema" -> true.toString
    )
    writeToCsv(spark, res_df.coalesce(1), SaveMode.Append, "20230301", options, path, false)

    o_tracks_df
  }


  /**
   * 流向中满足32个 城市相互流动的信息表
   *
   * @param spark
   * @param inc_day
   */
  def choose60TwoCity(spark: SparkSession, inc_day: String) = {
    import spark.implicits._
    val city_name = Seq("120000", "110000", "500000", "310000", "610100", "420100", "320100", "510100", "370100", "650100", "330100", "150100", "130100", "140100", "350100", "210100", "460100", "530100", "340100", "430100", "440100", "520100", "410100", "450100", "640100", "620100", "220100", "630100", "360100", "230100", "440300", "440600", "370600", "440700", "330300", "441900", "210200", "131000", "440500", "350300", "330500", "442000", "330700", "370200", "331000", "370700", "330400", "320200", "321000", "441300", "320800", "440400", "350500", "330600", "340200", "320400", "320600", "320500", "350200", "330200")
    val adcode_six_infos_str = splitFun("&")('adcode_six_infos)
    val res_df_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_jp_60 limit 0""").schema.map(x => col(x.name))
    val o_tracks_df = spark.sql(s"""select * from dm_gis.eta_experience_speed_track_fix_to320_jp where inc_day= '$inc_day' and adcode is not null and trim(adcode) != ''""")
      .repartition(600)
      .withColumn("adcode_six_infos", getSixAdcodeUDF(city_name)('adcode))
      .withColumn("adcode_six", adcode_six_infos_str(0))
      .withColumn("city_flag", adcode_six_infos_str(1))
      .withColumn("city_infos", adcode_six_infos_str(2))
      .filter('city_flag =!= "").drop("adcode_six_infos")
      .withColumn("num", randomAdd('city_flag))
      .withColumn("inc_day", lit(inc_day))
      .select(res_df_cols: _*).persist()
    o_tracks_df.printSchema()
    logger.error(">>>过滤后总数据量>>>" + o_tracks_df.count())
    writeToHive(spark, o_tracks_df.coalesce(100), Seq("inc_day"), "dm_gis.eta_experience_speed_track_fix_to320_jp_60")
  }

  /**
   * 流向中满足32个 城市相互流动的信息表
   *
   * @param spark
   * @param inc_day
   */
  def chooseTwoCity(spark: SparkSession, inc_day: String) = {
    import spark.implicits._
    val city_name = Seq("310000", "110000", "500000", "120000", "440100", "330100", "320100", "410100", "420100", "140100", "350100", "610100", "640100", "620100", "630100", "360100", "450100", "430100", "340100", "460100", "370100", "210100", "230100", "130100", "150100", "510100", "540100", "220100", "520100", "650100", "530100", "440300")
    val adcode_six_infos_str = splitFun("&")('adcode_six_infos)
    val res_df_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_jp_32 limit 0""").schema.map(x => col(x.name))
    val o_tracks_df = spark.sql(s"""select * from dm_gis.eta_experience_speed_track_fix_to320_jp where inc_day= '$inc_day' and adcode is not null and trim(adcode) != ''""")
      .repartition(600)
      .withColumn("adcode_six_infos", getSixAdcodeUDF(city_name)('adcode))
      .withColumn("adcode_six", adcode_six_infos_str(0))
      .withColumn("city_flag", adcode_six_infos_str(1))
      .withColumn("city_infos", adcode_six_infos_str(2))
      .filter('city_flag =!= "").drop("adcode_six_infos")
      .withColumn("num", randomAdd('city_flag))
      .withColumn("inc_day", lit(inc_day))
      .select(res_df_cols: _*).persist()
    o_tracks_df.printSchema()
    logger.error(">>>过滤后总数据量>>>" + o_tracks_df.count())
    writeToHive(spark, o_tracks_df.coalesce(100), Seq("inc_day"), "dm_gis.eta_experience_speed_track_fix_to320_jp_32")
  }

  /**
   * 60city原始来源数据进行数据切分 5-8天一个批次，单个批次1min~
   *
   * @param spark
   * @param inc_day
   */
  def citySegmentWithPart60(spark: SparkSession, inc_day: String, start_num: String, inter_num: String, end_num: String): Unit = {
    import spark.implicits._

    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_direction_60 limit 0""").schema.map(_.name).map(col)
    val time_infos_str = splitFun("&")('time_infos)
    val sql = s"""select * from dm_gis.eta_experience_speed_track_fix_to320_jp_60 where inc_day= '$inc_day' and adcode is not null and trim(adcode) != ''"""
    logger.error("输入的sql语句：" + sql)
    val s_e_index_df_tmp = spark.sql(sql).repartition(600).persist()
    logger.error(">>读取的数据总量为：>>>" + s_e_index_df_tmp.count())

    var start_num_cnt = start_num.toInt
    val inter_num_cnt = inter_num.toInt
    var batch_num_cnt = start_num_cnt + inter_num_cnt
    val end_num_cnt = end_num.toInt

    for (i <- start_num_cnt until 1000 if i >= start_num_cnt && i <= end_num_cnt) {
      logger.error("首发批次：" + i + " >>执行的批次num范围:" + start_num_cnt + "结束批次>>>" + batch_num_cnt)
      val s_e_index_df = s_e_index_df_tmp.filter('num.cast("int") >= start_num_cnt && 'num.cast("int") <= batch_num_cnt)
        .withColumn("merge_res", getMultiCombinationUDF('adcode_six, 'city_infos))
        .withColumn("merge_arr", explode($"merge_res"))
        .withColumn("adcode_first_gj", $"merge_arr"("_1")("_1"))
        .withColumn("adcode_end_gj", $"merge_arr"("_1")("_2"))
        .withColumn("start_index", $"merge_arr"("_2")("_1"))
        .withColumn("end_index", $"merge_arr"("_2")("_2"))
        .drop(Seq("merge_res", "merge_arr"): _*)
        .withColumn("adcode_six_gj", reQuotaColwithIndex('adcode_six, 'start_index, 'end_index))
        .withColumn("adcode_gj", reQuotaColwithIndex('adcode, 'start_index, 'end_index))
        .withColumn("s_code", getFlowUDF("start")('adcode_six_gj))
        .withColumn("e_code", getFlowUDF("end")('adcode_six_gj))
        .filter('s_code === 'adcode_first_gj && 'e_code === 'adcode_end_gj)
        .withColumn("swid_gj", reQuotaColwithIndex('swid, 'start_index, 'end_index))
        .withColumn("time_gj", reQuotaColwithIndex('time, 'start_index, 'end_index))
        .withColumn("speed_gj", reQuotaColwithIndex('speed, 'start_index, 'end_index))
        .withColumn("time_infos", getTimeInfo('time_gj))
        .withColumn("time_first_gj", time_infos_str(0))
        .withColumn("time_end_gj", time_infos_str(1))
        .withColumn("time_taken_gj", time_infos_str(2))
        .withColumn("swid_diff", diffSwid('swid_gj))
        .na.fill("", Seq("swid_diff", "time_first_gj"))
        .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
      s_e_index_df.show(10)
      logger.error(">>最终数据总量：>>>>>" + s_e_index_df.count())
      writeToHive(spark, s_e_index_df.coalesce(100), Seq("inc_day", "num"), "dm_gis.eta_experience_speed_track_fix_to320_direction_60")
      s_e_index_df.unpersist()
      start_num_cnt = batch_num_cnt + 1
      batch_num_cnt = start_num_cnt + inter_num_cnt
    }
  }


  /**
   * 原始来源数据进行数据切分 5-8天一个批次，单个批次1min~
   *
   * @param spark
   * @param inc_day
   */
  def citySegmentWithPart(spark: SparkSession, inc_day: String, start_num: String, inter_num: String, end_num: String): Unit = {
    import spark.implicits._

    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_direction_32 limit 0""").schema.map(_.name).map(col)
    val time_infos_str = splitFun("&")('time_infos)
    val sql = s"""select * from dm_gis.eta_experience_speed_track_fix_to320_jp_32 where inc_day= '$inc_day' and adcode is not null and trim(adcode) != ''"""
    logger.error("输入的sql语句：" + sql)
    val s_e_index_df_tmp = spark.sql(sql).repartition(600).persist()
    logger.error(">>读取的数据总量为：>>>" + s_e_index_df_tmp.count())

    var start_num_cnt = start_num.toInt
    val inter_num_cnt = inter_num.toInt
    var batch_num_cnt = start_num_cnt + inter_num_cnt
    val end_num_cnt = end_num.toInt

    for (i <- start_num_cnt until 1000 if i >= start_num_cnt && i <= end_num_cnt) {
      logger.error("首发批次：" + i + " >>执行的批次num范围:" + start_num_cnt + "结束批次>>>" + batch_num_cnt)
      val s_e_index_df = s_e_index_df_tmp.filter('num.cast("int") >= start_num_cnt && 'num.cast("int") <= batch_num_cnt)
        .withColumn("merge_res", getMultiCombinationUDF('adcode_six, 'city_infos))
        .withColumn("merge_arr", explode($"merge_res"))
        .withColumn("adcode_first_gj", $"merge_arr"("_1")("_1"))
        .withColumn("adcode_end_gj", $"merge_arr"("_1")("_2"))
        .withColumn("start_index", $"merge_arr"("_2")("_1"))
        .withColumn("end_index", $"merge_arr"("_2")("_2"))
        .drop(Seq("merge_res", "merge_arr"): _*)
        .withColumn("adcode_six_gj", reQuotaColwithIndex('adcode_six, 'start_index, 'end_index))
        .withColumn("adcode_gj", reQuotaColwithIndex('adcode, 'start_index, 'end_index))
        .withColumn("s_code", getFlowUDF("start")('adcode_six_gj))
        .withColumn("e_code", getFlowUDF("end")('adcode_six_gj))
        .filter('s_code === 'adcode_first_gj && 'e_code === 'adcode_end_gj)
        .withColumn("swid_gj", reQuotaColwithIndex('swid, 'start_index, 'end_index))
        .withColumn("time_gj", reQuotaColwithIndex('time, 'start_index, 'end_index))
        .withColumn("speed_gj", reQuotaColwithIndex('speed, 'start_index, 'end_index))
        .withColumn("time_infos", getTimeInfo('time_gj))
        .withColumn("time_first_gj", time_infos_str(0))
        .withColumn("time_end_gj", time_infos_str(1))
        .withColumn("time_taken_gj", time_infos_str(2))
        .withColumn("swid_diff", diffSwid('swid_gj))
        .na.fill("", Seq("swid_diff", "time_first_gj"))
        .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
      s_e_index_df.show(10)
      logger.error(">>最终数据总量：>>>>>" + s_e_index_df.count())
      writeToHive(spark, s_e_index_df.coalesce(100), Seq("inc_day", "num"), "dm_gis.eta_experience_speed_track_fix_to320_direction_32")
      s_e_index_df.unpersist()
      start_num_cnt = batch_num_cnt + 1
      batch_num_cnt = start_num_cnt + inter_num_cnt
    }
  }

  /**
   * 原始来源数据进行数据切分
   *
   * @param spark
   * @param inc_day
   */
  def citySegment(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    val city_name = Seq("310000", "110000", "500000", "120000", "440100", "330100", "320100", "410100", "420100", "140100", "350100", "610100", "640100", "620100", "630100", "360100", "450100", "430100", "340100", "460100", "370100", "210100", "230100", "130100", "150100", "510100", "540100", "220100", "520100", "650100", "530100", "440300")
    val part1_cols = Seq("un", "swid_gj", "swid_diff", "adcode_gj", "time_gj", "speed_gj", "adcode_first_gj", "adcode_end_gj", "time_first_gj", "time_end_gj", "time_taken_gj", "num").map(col)
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_direction_32 limit 0""").schema.map(_.name).map(col)
    val start_map = getRandomCityMap(city_name)._1
    val end_map = getRandomCityMap(city_name)._2
    logger.error("start_map size:>>>" + start_map.size)
    val time_infos_str = splitFun("&")('time_infos)
    //    val sql = s"""select * from dm_gis.eta_experience_speed_track_fix_to320_jp_32 where inc_day= '$inc_day' and num ='1' and adcode is not null and trim(adcode) != '' limit 10"""
    val sql = s"""select * from dm_gis.eta_experience_speed_track_fix_to320_jp_32 where inc_day= '$inc_day' and num ='1' and adcode is not null and trim(adcode) != ''"""
    logger.error("输入的sql语句：" + sql)
    val s_e_index_df_tmp = spark.sql(sql).repartition(600).persist()
    logger.error(">>读取的数据总量为：>>>" + s_e_index_df_tmp.count())
    val s_e_index_df = s_e_index_df_tmp
      //      .withColumn("merge_res", getMultiCombinationUDF(start_map, end_map)('adcode_six))
      .withColumn("merge_res", getMultiCombinationUDF('adcode_six, 'city_infos))
      .withColumn("merge_arr", explode($"merge_res"))
      .withColumn("adcode_first_gj", $"merge_arr"("_1")("_1"))
      .withColumn("adcode_end_gj", $"merge_arr"("_1")("_2"))
      .withColumn("start_index", $"merge_arr"("_2")("_1"))
      .withColumn("end_index", $"merge_arr"("_2")("_2"))
      .drop(Seq("merge_res", "merge_arr"): _*)
      .withColumn("adcode_six_gj", reQuotaColwithIndex('adcode_six, 'start_index, 'end_index))
      .withColumn("adcode_gj", reQuotaColwithIndex('adcode, 'start_index, 'end_index))
      .withColumn("s_code", getFlowUDF("start")('adcode_six_gj))
      .withColumn("e_code", getFlowUDF("end")('adcode_six_gj))
      .filter('s_code === 'adcode_first_gj && 'e_code === 'adcode_end_gj)
      .withColumn("swid_gj", reQuotaColwithIndex('swid, 'start_index, 'end_index))
      .withColumn("time_gj", reQuotaColwithIndex('time, 'start_index, 'end_index))
      .withColumn("speed_gj", reQuotaColwithIndex('speed, 'start_index, 'end_index))
      .withColumn("time_infos", getTimeInfo('time_gj))
      .withColumn("time_first_gj", time_infos_str(0))
      .withColumn("time_end_gj", time_infos_str(1))
      .withColumn("time_taken_gj", time_infos_str(2))
      .withColumn("swid_diff", diffSwid('swid_gj))
      .na.fill("", Seq("swid_diff", "time_first_gj"))
      .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //      .repartition(30).persist(StorageLevel.MEMORY_AND_DISK_SER)
    s_e_index_df.show(10)
    logger.error(">>最终数据总量：>>>>>" + s_e_index_df.count())
    s_e_index_df_tmp.unpersist()
    writeToHive(spark, s_e_index_df.coalesce(100), Seq("inc_day", "num"), "dm_gis.eta_experience_speed_track_fix_to320_direction_32")
    //    logger.error("获取得到起始索引点数据总量>>>>" + s_e_index_df.count())
    //    logger.error("开始处理接口调用逻辑………………………………")
    //    val inter_back_df = s_e_index_df.map(row => {
    //      val un = row.getAs[String]("un")
    //      val swid_gj = row.getAs[String]("swid_gj")
    //      val adcode_gj = row.getAs[String]("adcode_gj")
    //      val time_gj = row.getAs[String]("time_gj")
    //      val speed_gj = row.getAs[String]("speed_gj")
    //      val adcode_first_gj = row.getAs[String]("adcode_first_gj")
    //      val adcode_end_gj = row.getAs[String]("adcode_end_gj")
    //      val time_first_gj = row.getAs[String]("time_first_gj")
    //      val time_end_gj = row.getAs[String]("time_end_gj")
    //      val time_taken_gj = row.getAs[String]("time_taken_gj")
    //      //      val num = row.getAs[String]("num")
    //      val swid_diff = row.getAs[String]("swid_diff")
    //      val date = time_first_gj.replaceAll("-|:|\\s+", "") //2022-11-05 10:44:28
    //      var links_info: (String, String, String, String, String, String) = null
    //      var swid_qm, roadclass_qm, dr_length_qm, formway_qm, swid_name_qm, dist_gj = ""
    //      if (date != "" && swid_diff != "") {
    //        links_info = getLinksInfo(swid_diff, date)
    //        swid_qm = links_info._1
    //        roadclass_qm = links_info._2
    //        dr_length_qm = links_info._3
    //        formway_qm = links_info._4
    //        swid_name_qm = links_info._5
    //        dist_gj = links_info._6
    //      }
    //      EfficientSwidInfo(un, swid_gj, adcode_gj, time_gj, speed_gj, adcode_first_gj, adcode_end_gj, time_first_gj, time_end_gj, time_taken_gj, swid_qm, roadclass_qm, dr_length_qm, formway_qm, swid_name_qm, dist_gj)
    //    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    inter_back_df.show(3)
    //    logger.error(">>>调用完接口返回数据量：>>" + inter_back_df.count())
    //    s_e_index_df.persist()
    //    inter_back_df
    s_e_index_df
  }

  def getMultiCombinationUDF = udf((adcode_six: String, city_infos: String) => {
    val city_name = city_infos.split("\\|").toSeq
    val start_map = getRandomCityMap(city_name)._1
    val end_map = getRandomCityMap(city_name)._2
    val adcode_six_arr = adcode_six.split("\\|")
    val city_index_res = getCityAndIndexMapFun(adcode_six_arr, start_map, end_map)
    val start_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]] = city_index_res._1
    val end_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]] = city_index_res._2
    val start_ab = getNewMergeMap(start_city_info, end_city_info)._1
    val end_ab = getNewMergeMap(start_city_info, end_city_info)._2
    val merge_res: ArrayBuffer[((String, String), (Int, Int))] = getMergerSet(start_ab, end_ab)
    merge_res
  })

  def getMultiCombinationUDF(start_map: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]], end_map: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]) = udf((adcode_six: String) => {
    val adcode_six_arr = adcode_six.split("\\|")
    val city_index_res = getCityAndIndexMapFun(adcode_six_arr, start_map, end_map)
    val start_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]] = city_index_res._1
    val end_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]] = city_index_res._2
    val start_ab = getNewMergeMap(start_city_info, end_city_info)._1
    val end_ab = getNewMergeMap(start_city_info, end_city_info)._2
    val merge_res: ArrayBuffer[((String, String), (Int, Int))] = getMergerSet(start_ab, end_ab)
    merge_res
  })

  def getMergerSet(start_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]], end_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]]): ArrayBuffer[((String, String), (Int, Int))] = {
    val all_city_vs: ArrayBuffer[((String, String), (Int, String))] = (start_ab ++ end_ab).sortBy(x => (x._1, x._2._1))
    val merger_ab = new ArrayBuffer[((String, String), (Int, Int))]()
    var cnt: Int = 0
    for (i <- cnt until all_city_vs.size if i == cnt) {
      val o_map_l: Tuple2[(String, String), (Int, String)] = all_city_vs(i)
      logger.error("start_city:" + o_map_l._1._1 + ">>end_city:" + o_map_l._1._2 + ">>start_index:" + o_map_l._2._1 + ">>start_or_end:" + o_map_l._2._2)
      if (i + 2 <= all_city_vs.size - 1) {
        val o_map_p: Tuple2[(String, String), (Int, String)] = all_city_vs(i + 1)
        val o_map_pp: Tuple2[(String, String), (Int, String)] = all_city_vs(i + 2)
        val l_p_cond = o_map_l._1._1 == o_map_p._1._1 && o_map_l._1._2 == o_map_p._1._2
        val l_pp_cond = o_map_p._1._1 == o_map_pp._1._1 && o_map_p._1._2 == o_map_pp._1._2

        if (l_p_cond && !l_pp_cond && o_map_l._2._2 == "start" && o_map_p._2._2 == "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, o_map_p._2._1))
          cnt = i + 2
        } else if (l_p_cond && l_pp_cond && o_map_l._2._2 == "start" && o_map_p._2._2 == "end" && o_map_pp._2._2 != "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, o_map_p._2._1))
          cnt = i + 2
        } else if (l_p_cond && l_pp_cond && o_map_l._2._2 == "start" && o_map_p._2._2 == "end" && o_map_pp._2._2 == "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, o_map_p._2._1))
          breakable {
            for (j <- i + 3 until all_city_vs.size if j <= all_city_vs.size - 1) {
              if (all_city_vs(j)._1._1 != o_map_l._1._1 || all_city_vs(j)._1._2 != o_map_l._1._2) {
                cnt = j
                break
              }
              val o_map_ppp: Tuple2[(String, String), (Int, String)] = all_city_vs(j)
              if (all_city_vs(j)._1._1 == o_map_l._1._1 && all_city_vs(j)._1._2 == o_map_l._1._2 && o_map_ppp._2._2 != "end") {
                cnt = j
                break
              }
            }
          }
        } else {
          cnt = i + 1
        }
      }
      if (i + 1 == all_city_vs.size - 1) {
        val o_map_p: Tuple2[(String, String), (Int, String)] = all_city_vs(i + 1)
        val l_p_cond = o_map_l._1._1 == o_map_p._1._1 && o_map_l._1._2 == o_map_p._1._2
        if (l_p_cond && o_map_p._2._2 == "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, all_city_vs(i + 1)._2._1))
        }
      }
    }
    merger_ab
  }

  def getNewMergeMap(start_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]], end_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]): (ArrayBuffer[Tuple2[(String, String), (Int, String)]], ArrayBuffer[Tuple2[(String, String), (Int, String)]]) = {
    val start_ab = new ArrayBuffer[Tuple2[(String, String), (Int, String)]]()
    val end_ab = new ArrayBuffer[Tuple2[(String, String), (Int, String)]]()
    //将新得到的数据放入新数组中
    if (start_city_info.keys.size != 0) {
      for (r <- start_city_info.keys) {
        val value = start_city_info.getOrElse(r, collection.mutable.Map.empty)
        if (!value.isEmpty && value != null && value.size > 0) {
          for (v <- value.keys) {
            val v2 = value.getOrElse(v, List.empty)
            if (!v2.isEmpty) {
              for (l <- v2) {
                start_ab += Tuple2(v, l)
              }
            }
          }
        }
      }
    }
    if (end_city_info.keys.size != 0) {
      for (r <- end_city_info.keys) {
        val value = end_city_info.getOrElse(r, collection.mutable.Map.empty)
        if (!value.isEmpty && value != null && value.size > 0) {
          for (v <- value.keys) {
            val v2 = value.getOrElse(v, List.empty)
            if (!v2.isEmpty) {
              for (l <- v2) {
                end_ab += Tuple2(v, l)
              }
            }
          }
        }
      }
    }
    (start_ab, end_ab)
  }

  def getRandomCityMap(city_name: Seq[String]): (collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]], collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]) = {
    val start_map = collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]()
    val end_map = collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]()
    for (i <- 0 until city_name.size) {
      val start_info: collection.mutable.Map[(String, String), List[(Int, String)]] = collection.mutable.Map.empty
      val end_info: collection.mutable.Map[(String, String), List[(Int, String)]] = collection.mutable.Map.empty
      for (j <- 0 until city_name.size if j != i) {
        if (city_name(i) != city_name(j)) {
          start_info.put((city_name(i), city_name(j)), List.empty)
          start_map.put(city_name(i), start_info)
          end_info.put((city_name(j), city_name(i)), List.empty)
          end_map.put(city_name(i), end_info)
        }
      }
    }
    (start_map, end_map)
  }

  def getSixAdcodeUDF(city_name: Seq[String]) = udf((adcode: String) => {
    val adcode_n = new ArrayBuffer[String]()
    var city_flag, city_infos = ""
    val hs = new mutable.HashSet[String]()
    val four_sp = Seq("31", "11", "50", "12")
    try {
      val adcode_arr = adcode.split("\\|")
      for (i <- 0 until adcode_arr.size) {
        val one_adcode_2 = adcode_arr(i).substring(0, 2)
        val one_adcode_4 = adcode_arr(i).substring(0, 4)
        if (four_sp.contains(one_adcode_2)) {
          adcode_n += (one_adcode_2 + "" + "0000")
          if (city_name.contains(one_adcode_2 + "" + "0000")) hs.add(one_adcode_2 + "" + "0000")
        }
        if (!four_sp.contains(one_adcode_2)) {
          adcode_n += (one_adcode_4 + "" + "00")
          if (city_name.contains(one_adcode_4 + "" + "00")) hs.add(one_adcode_4 + "" + "00")
        }
      }
      if (hs.size >= 2) {
        city_flag = hs.size.toString
        city_infos = hs.mkString("|")
      }
    } catch {
      case e: Exception => "" + e
    }
    adcode_n.mkString("|") + "&" + city_flag + "&" + city_infos
  })

  def dealAfterInterWithPart(spark: SparkSession, part1_df: DataFrame, inc_day: String, city_map_df: DataFrame, wriToTN: String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql(s"""select * from $wriToTN limit 0""").schema.map(_.name).map(col)
    val swid_tl_infos_str = splitFun("&")('swid_tl_infos)
    val roadclass_name_infos_str = splitFun("&")('roadclass_name_infos)
    val duration_infos_str = splitFun("&")('duration_infos)
    val part2_df = part1_df.repartition(600)
      .na.fill("0.0", Seq("time_taken_gj", "dr_length_qm"))
      .withColumn("avg_speed_gj", lit(60) * 'dist_gj / 'time_taken_gj)
      .withColumn("index_1", getIndex1234("1")('roadclass_qm, lit("0")))
      .withColumn("index_2", getIndex1234("2")('roadclass_qm, lit("0")))
      .withColumn("index_0_all", getIndex1234("3")('roadclass_qm, lit("0")))
      .withColumn("swid_highspeed_start", getStartOrEnd('swid_qm, 'index_1))
      .withColumn("swid_highspeed_end", getStartOrEnd('swid_qm, 'index_2))
      .withColumn("name_highspeed_start", getStartOrEnd('swid_name_qm, 'index_1))
      .withColumn("name_highspeed_end", getStartOrEnd('swid_name_qm, 'index_2))
      .withColumn("name_highspeed", getNameHighspeed('swid_name_qm, 'index_1, 'index_2))
      .withColumn("dis_highspeed", getDisHighspeed('dr_length_qm, 'index_1, 'index_2))
      .withColumn("dis_ac_highspeed", getDisAcHighspeed('dr_length_qm, 'index_0_all))
      .withColumn("highspeed_ration", round('dis_ac_highspeed / 'dis_highspeed, 3))
      .withColumn("highspeed_all_ration", round('dis_ac_highspeed / 'dist_gj, 3))
      .withColumn("index_3", getIndex1234("1")('swid_gj, 'swid_highspeed_start))
      .withColumn("index_4", getIndex1234("2")('swid_gj, 'swid_highspeed_end))
      .withColumn("time_highspeed_start", getStartOrEnd('time_gj, 'index_3))
      .withColumn("time_highspeed_end", getStartOrEnd('time_gj, 'index_4))
      .withColumn("duration_highspeed", round(('time_highspeed_end.cast("long") - 'time_highspeed_start.cast("long")) / 60, 2))
      .withColumn("time_highspeed_start", tranTstampToTimeUDF(sdf1)('time_highspeed_start))
      .withColumn("time_highspeed_end", tranTstampToTimeUDF(sdf1)('time_highspeed_end))
      .withColumn("avg_speed_instant_highspeed", round(getAvgSpeedHighspeed('speed_gj, 'index_3, 'index_4), 2))
      .withColumn("avg_speed_highspeed", lit(60) * 'dis_highspeed / 'duration_highspeed)
      .withColumn("dis_highspeed_block", getDisHighspeedBlock('dis_highspeed))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">第1部分标签加工后的数据量为：>>" + part2_df.count())
    part1_df.unpersist()
    val part3_df = part2_df
      .withColumn("adcode_first_gj_tmp", when(substring('adcode_first_gj, 0, 2).isin("31", "11", "50", "12"), concat(substring('adcode_first_gj, 0, 2), lit("0000"))).otherwise('adcode_first_gj))
      .withColumn("adcode_end_gj_tmp", when(substring('adcode_end_gj, 0, 2).isin("31", "11", "50", "12"), concat(substring('adcode_end_gj, 0, 2), lit("0000"))).otherwise('adcode_end_gj))
      .join(broadcast(city_map_df.selectExpr("adcode as adcode_first_gj_tmp", "city_name city_start")), Seq("adcode_first_gj_tmp"), "left")
      .join(broadcast(city_map_df.selectExpr("adcode as adcode_end_gj_tmp", "city_name city_end")), Seq("adcode_end_gj_tmp"), "left")
      .withColumn("swid_tl_infos", getSwid_tl('swid_gj, 'time_gj, 'index_3, 'index_4))
      .withColumn("swid_tl", swid_tl_infos_str(0))
      .withColumn("time_tl", swid_tl_infos_str(1))
      .withColumn("duration_tl", swid_tl_infos_str(2))
      .withColumn("roadclass_name_infos", getRoadclass_tl('swid_tl, 'swid_qm, 'roadclass_qm, 'swid_name_qm))
      .withColumn("roadclass_tl", roadclass_name_infos_str(0))
      .withColumn("roadname_tl", roadclass_name_infos_str(1))
      .na.fill("", Seq("duration_tl", "roadname_tl", "roadclass_tl"))
      .withColumn("duration_infos", getDuration_1_2('duration_tl, 'roadname_tl, 'roadclass_tl))
      .withColumn("total_duration_tl_1", duration_infos_str(0))
      .withColumn("total_duration_tl_2", duration_infos_str(1))
      .withColumn("avg_speed_highspeed_tl_1", lit(60) * 'dis_highspeed / ('duration_highspeed - 'total_duration_tl_1))
      .withColumn("avg_speed_highspeed_tl_2", lit(60) * 'dis_highspeed / ('duration_highspeed - 'total_duration_tl_2))
      .withColumn("duration_ratio_1", 'total_duration_tl_1 / 'duration_highspeed)
      .withColumn("duration_ratio_2", 'total_duration_tl_2 / 'duration_highspeed)
      .na.fill("", Seq("time_first_gj", "time_end_gj", "time_highspeed_start", "time_highspeed_end"))
      .withColumn("time_highspeed_start_rep", substring('time_highspeed_start, 0, 10))
      .na.fill("", Seq("time_highspeed_start_rep"))
      .filter('time_highspeed_start_rep =!= "")
      .withColumn("inc_day", lit(inc_day)).persist()

    val add_res_cols_str = Seq("date_start_gj", "date_end_gj", "hour_start_gj", "hour_end_gj", "date_start_highspeed", "date_end_highspeed", "hour_start_highspeed", "hour_end_highspeed")
    val add_res_cols = addDateOrHourCols(add_res_cols_str)

    val res_df = part3_df.select(part3_df.schema.map(_.name).map(col) ++ add_res_cols: _*).select(res_cols: _*)

    writeToHive(spark, res_df, Seq("inc_day", "num"), wriToTN)
    part3_df.unpersist()
  }

  def dealAfterInter(spark: SparkSession, part1_df: DataFrame): Unit = {
    import spark.implicits._
    val city_map_df = getCityMapAdcode(spark)
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_road_detail limit 0""").schema.map(_.name).map(col)
    val swid_tl_infos_str = splitFun("&")('swid_tl_infos)
    val roadclass_name_infos_str = splitFun("&")('roadclass_name_infos)
    val duration_infos_str = splitFun("&")('duration_infos)
    val part2_df = part1_df
      .na.fill("0.0", Seq("time_taken_gj", "dr_length_qm"))
      .withColumn("avg_speed_gj", lit(60) * 'dist_gj / 'time_taken_gj)
      .withColumn("index_1", getIndex1234("1")('roadclass_qm, lit("0")))
      .withColumn("index_2", getIndex1234("2")('roadclass_qm, lit("0")))
      .withColumn("index_0_all", getIndex1234("3")('roadclass_qm, lit("0")))
      .withColumn("swid_highspeed_start", getStartOrEnd('swid_qm, 'index_1))
      .withColumn("swid_highspeed_end", getStartOrEnd('swid_qm, 'index_2))
      .withColumn("name_highspeed_start", getStartOrEnd('swid_name_qm, 'index_1))
      .withColumn("name_highspeed_end", getStartOrEnd('swid_name_qm, 'index_2))
      .withColumn("name_highspeed", getNameHighspeed('swid_name_qm, 'index_1, 'index_2))
      .withColumn("dis_highspeed", getDisHighspeed('dr_length_qm, 'index_1, 'index_2))
      .withColumn("dis_ac_highspeed", getDisAcHighspeed('dr_length_qm, 'index_0_all))
      .withColumn("highspeed_ration", round('dis_ac_highspeed / 'dis_highspeed, 3))
      .withColumn("highspeed_all_ration", round('dis_ac_highspeed / 'dist_gj, 3))
      .withColumn("index_3", getIndex1234("1")('swid_gj, 'swid_highspeed_start))
      .withColumn("index_4", getIndex1234("2")('swid_gj, 'swid_highspeed_end))
      .withColumn("time_highspeed_start", getStartOrEnd('time_gj, 'index_3))
      .withColumn("time_highspeed_end", getStartOrEnd('time_gj, 'index_4))
      .withColumn("duration_highspeed", round(('time_highspeed_end.cast("long") - 'time_highspeed_start.cast("long")) / 60, 2))
      .withColumn("time_highspeed_start", tranTstampToTimeUDF(sdf1)('time_highspeed_start))
      .withColumn("time_highspeed_end", tranTstampToTimeUDF(sdf1)('time_highspeed_end))
      .withColumn("avg_speed_instant_highspeed", round(getAvgSpeedHighspeed('speed_gj, 'index_3, 'index_4), 2))
      .withColumn("avg_speed_highspeed", lit(60) * 'dis_highspeed / 'duration_highspeed)
      .withColumn("dis_highspeed_block", getDisHighspeedBlock('dis_highspeed))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">第1部分标签加工后的数据量为：>>" + part2_df.count())
    part1_df.unpersist()
    val part3_df = part2_df
      .withColumn("adcode_first_gj_tmp", when(substring('adcode_first_gj, 0, 2).isin("31", "11", "50", "12"), concat(substring('adcode_first_gj, 0, 2), lit("0000"))).otherwise('adcode_first_gj))
      .withColumn("adcode_end_gj_tmp", when(substring('adcode_end_gj, 0, 2).isin("31", "11", "50", "12"), concat(substring('adcode_end_gj, 0, 2), lit("0000"))).otherwise('adcode_end_gj))
      .join(broadcast(city_map_df.selectExpr("adcode as adcode_first_gj_tmp", "city_name city_start")), Seq("adcode_first_gj_tmp"), "left")
      .join(broadcast(city_map_df.selectExpr("adcode as adcode_end_gj_tmp", "city_name city_end")), Seq("adcode_end_gj_tmp"), "left")
      .withColumn("swid_tl_infos", getSwid_tl('swid_gj, 'time_gj, 'index_3, 'index_4))
      .withColumn("swid_tl", swid_tl_infos_str(0))
      .withColumn("time_tl", swid_tl_infos_str(1))
      .withColumn("duration_tl", swid_tl_infos_str(2))
      .withColumn("roadclass_name_infos", getRoadclass_tl('swid_tl, 'swid_qm, 'roadclass_qm, 'swid_name_qm))
      .withColumn("roadclass_tl", roadclass_name_infos_str(0))
      .withColumn("roadname_tl", roadclass_name_infos_str(1))
      .na.fill("", Seq("duration_tl", "roadname_tl", "roadclass_tl"))
      .withColumn("duration_infos", getDuration_1_2('duration_tl, 'roadname_tl, 'roadclass_tl))
      .withColumn("total_duration_tl_1", duration_infos_str(0))
      .withColumn("total_duration_tl_2", duration_infos_str(1))
      .withColumn("avg_speed_highspeed_tl_1", lit(60) * 'dis_highspeed / ('duration_highspeed - 'total_duration_tl_1))
      .withColumn("avg_speed_highspeed_tl_2", lit(60) * 'dis_highspeed / ('duration_highspeed - 'total_duration_tl_2))
      .withColumn("duration_ratio_1", 'total_duration_tl_1 / 'duration_highspeed)
      .withColumn("duration_ratio_2", 'total_duration_tl_2 / 'duration_highspeed)
      .na.fill("", Seq("time_first_gj", "time_end_gj", "time_highspeed_start", "time_highspeed_end"))
      .withColumn("inc_day", substring('time_highspeed_start, 0, 10))
      .na.fill("", Seq("inc_day"))
      .filter('inc_day =!= "")

    val add_res_cols_str = Seq("date_start_gj", "date_end_gj", "hour_start_gj", "hour_end_gj", "date_start_highspeed", "date_end_highspeed", "hour_start_highspeed", "hour_end_highspeed")
    val add_res_cols = addDateOrHourCols(add_res_cols_str)

    val res_df = part3_df.select(part3_df.schema.map(_.name).map(col) ++ add_res_cols: _*).select(res_cols: _*)

    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.eta_experience_speed_track_fix_to320_road_detail")
  }

  def getFlow(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    val o_tracks_df = spark.sql(s"""select * from dm_gis.eta_experience_speed_track_fix_to320_direction where inc_day= '$inc_day' and un ='54200C86A5D165DC'""")
    val part1_cols = Seq("un", "swid", "swid_diff", "adcode", "time", "speed", "adcode_first", "adcode_end", "time_first", "time_end", "time_taken", "inc_day").map(col)

    val city_code_infos_str = splitFun("&")('city_code_infos)
    val time_infos_str = splitFun("&")('time_infos)
    val part1_df = o_tracks_df
      .withColumn("index_list", flowDirectionPart('adcode, 'city_flag))
      .withColumn("index", explode(split('index_list, "\\|")))
      .withColumn("swid", reQuotaCol('swid, 'index))
      .withColumn("adcode", reQuotaCol('adcode, 'index))
      .withColumn("time", reQuotaCol('time, 'index))
      .withColumn("speed", reQuotaCol('speed, 'index))
      .na.fill("", Seq("adcode", "time"))
      .withColumn("city_code_infos", getCitycode('adcode))
      .withColumn("city_code", city_code_infos_str(0))
      .withColumn("adcode_first", city_code_infos_str(1))
      .withColumn("adcode_end", city_code_infos_str(2))
      .withColumn("time_infos", getTimeInfo('time))
      .withColumn("time_first", time_infos_str(0))
      .withColumn("time_end", time_infos_str(1))
      .withColumn("time_taken", time_infos_str(2))
      .filter('adcode_first === "310100" && 'adcode_end === "500100")
      .withColumn("swid_diff", diffSwid('swid))
      .select(part1_cols: _*)
      .map(row => {
        val un = row.getAs[String]("un")
        val swid_gj = row.getAs[String]("swid")
        val adcode_gj = row.getAs[String]("adcode")
        val time_gj = row.getAs[String]("time")
        val speed_gj = row.getAs[String]("speed")
        val adcode_first_gj = row.getAs[String]("adcode_first")
        val adcode_end_gj = row.getAs[String]("adcode_end")
        val time_first_gj = row.getAs[String]("time_first")
        val time_end_gj = row.getAs[String]("time_end")
        val time_taken_gj = row.getAs[String]("time_taken")

        val swid_diff = row.getAs[String]("swid_diff")
        val date = time_first_gj.replaceAll("-|:|\\s+", "") //2022-11-05 10:44:28
        val links_info = getLinksInfo(swid_diff, date)
        val swid_qm = links_info._1
        val roadclass_qm = links_info._2
        val dr_length_qm = links_info._3
        val formway_qm = links_info._4
        val swid_name_qm = links_info._5
        val dist_gj = links_info._6
        EfficientSwidInfo(un, swid_gj, adcode_gj, time_gj, speed_gj, adcode_first_gj, adcode_end_gj, time_first_gj, time_end_gj, time_taken_gj, swid_qm, roadclass_qm, dr_length_qm, formway_qm, swid_name_qm, dist_gj)
      }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    writeToHiveNoP(spark,part1_df,"eta_experience_speed_track_fix_to320_direction_tmp")
    part1_df.show(10)
    logger.error("调完接口返回的数据总量>>>>>" + part1_df.count())
    part1_df
  }

  /**
   *
   * @param spark
   * @param o_tracks_df
   */
  def procAcce(spark: SparkSession, o_tracks_df: DataFrame): Unit = {
    import spark.implicits._
    val city_code_infos_str = splitFun("&")('city_code_infos)
    val time_infos_str = splitFun("&")('time_infos)
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_part limit 0""").schema.map(_.name).map(col)
    val res_df = o_tracks_df
      .withColumn("index_list", flowDirection('adcode, 'city_flag))
      .withColumn("index", explode(split('index_list, "\\|")))
      .withColumn("swid", reQuotaCol('swid, 'index))
      .withColumn("adcode", reQuotaCol('adcode, 'index))
      .withColumn("time", reQuotaCol('time, 'index))
      .withColumn("speed", reQuotaCol('speed, 'index))
      .na.fill("", Seq("adcode", "time"))
      .withColumn("city_code_infos", getCitycode('adcode))
      .withColumn("city_code", city_code_infos_str(0))
      .withColumn("city_code_first", city_code_infos_str(1))
      .withColumn("city_code_end", city_code_infos_str(2))
      .withColumn("time_infos", getTimeInfo('time))
      .withColumn("time_first", time_infos_str(0))
      .withColumn("time_end", time_infos_str(1))
      .withColumn("time_taken", time_infos_str(2))
      .withColumn("road_class", lit(""))
      .withColumn("dr_length", lit(""))
      .withColumn("formway", lit(""))
      .withColumn("swid_name", lit(""))
      .withColumn("dist", lit(""))
      .withColumn("avg_speed", lit(""))
      .select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(2), Seq("inc_day"), "dm_gis.eta_experience_speed_track_fix_to320_part")
  }


  def procAcceTotal(spark: SparkSession, o_tracks_df: DataFrame): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_direction limit 0""").schema.map(_.name).map(col)
    val res_df = o_tracks_df.repartition(600)
      .withColumn("city_flag", getCityflagPart("3101", "5001")('adcode))
      .filter('city_flag =!= "")
      .select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_experience_speed_track_fix_to320_direction")
  }

  /**
   * 获取原始近一段时间的拼接的全量数据 不包含city_flag 字段
   *
   * @param spark
   * @param start_day
   * @param end_day
   * @param inc_day
   * @return
   */
  def loadEffectiveDataOrg(spark: SparkSession, start_day: String, end_day: String, inc_day: String): DataFrame = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_jp limit 0""").schema.map(_.name).map(col)
    val swid_infos_str = splitFun("&")('swid_infos)
    val o_tracks_df = spark.sql(
      s"""select un,info,inc_day actural_inc_day from dm_gis.eta_experience_speed_tracks_fix_to320 where inc_day between '$start_day' and '$end_day'
         |and un is not null and trim(un) !='' and info is not null and trim(info) !=''
         |""".stripMargin)
      .withColumn("swid_infos", splitUnInfo('info))
      .withColumn("swid", swid_infos_str(0))
      .withColumn("adcode", swid_infos_str(1))
      .withColumn("time", swid_infos_str(2))
      .withColumn("speed", swid_infos_str(3))
      .withColumn("num", row_number().over(Window.partitionBy("un").orderBy(asc("actural_inc_day"))))
      .groupBy("un")
      .agg(
        concat_ws("&", collect_list('num)) as "num",
        concat_ws("&", collect_list('swid)) as "swid",
        concat_ws("&", collect_list('adcode)) as "adcode",
        concat_ws("&", collect_list('time)) as "time",
        concat_ws("&", collect_list('speed)) as "speed"
      )
      .withColumn("swid", sortFieldN('num, 'swid))
      .withColumn("adcode", sortFieldN('num, 'adcode))
      .withColumn("time", sortFieldN('num, 'time))
      .withColumn("speed", sortFieldN('num, 'speed))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    writeToHive(spark, o_tracks_df.coalesce(100), Seq("inc_day"), "dm_gis.eta_experience_speed_track_fix_to320_jp") //393w4240
    o_tracks_df
  }

  /**
   * 获取一段时间的 6个省市地区的轨迹拼接信息 包含city_flag 字段
   *
   * @param spark
   * @param start_day
   * @param end_day
   * @param inc_day
   * @return
   */
  def loadEffectiveData(spark: SparkSession, start_day: String, end_day: String, inc_day: String): DataFrame = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_his limit 0""").schema.map(_.name).map(col)
    val swid_infos_str = splitFun("&")('swid_infos)
    val o_tracks_df = spark.sql(
      s"""select un,info,inc_day actural_inc_day from dm_gis.eta_experience_speed_tracks_fix_to320 where inc_day between '$start_day' and '$end_day'
         |and un is not null and trim(un) !='' and info is not null and trim(info) !=''
         |""".stripMargin)
      .withColumn("swid_infos", splitUnInfo('info))
      .withColumn("swid", swid_infos_str(0))
      .withColumn("adcode", swid_infos_str(1))
      .withColumn("time", swid_infos_str(2))
      .withColumn("speed", swid_infos_str(3))
      .withColumn("num", row_number().over(Window.partitionBy("un").orderBy(asc("actural_inc_day"))))
      .groupBy("un")
      .agg(
        concat_ws("&", collect_list('num)) as "num",
        concat_ws("&", collect_list('swid)) as "swid",
        concat_ws("&", collect_list('adcode)) as "adcode",
        concat_ws("&", collect_list('time)) as "time",
        concat_ws("&", collect_list('speed)) as "speed"
      )
      .withColumn("swid", sortFieldN('num, 'swid))
      .withColumn("adcode", sortFieldN('num, 'adcode))
      .withColumn("time", sortFieldN('num, 'time))
      .withColumn("speed", sortFieldN('num, 'speed))
      .withColumn("city_flag", getCityflag('adcode))
      .filter('city_flag =!= "")
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    writeToHive(spark, o_tracks_df.coalesce(100), Seq("inc_day"), "dm_gis.eta_experience_speed_track_fix_to320_his") //5915
    o_tracks_df
  }

  //

  def finalDataRandom = udf((swid: String) => {
    val sum_dist_arr = new ArrayBuffer[String]()
    try {
      val swid_arr = swid.split("\\|")
      for (i <- 0 until swid_arr.size) {
        val mm = Random.nextInt(9)
        if (mm == 2 || mm == 5) {
          sum_dist_arr += mm.toString
        } else {
          sum_dist_arr += "0"
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    sum_dist_arr.mkString("|")
  })


  def finalData = udf((swid: String, sum_dist: String) => {
    val sum_dist_arr = new ArrayBuffer[String]()
    try {
      val swid_arr = swid.split("\\|")
      for (i <- 0 until swid_arr.size) {
        sum_dist_arr += sum_dist.toString
      }
    } catch {
      case e: Exception => "" + e
    }
    sum_dist_arr.mkString("|")
  })


  def randomAdd = udf((random: String) => {
    Random.nextInt(1000)
  })

  def getCityAndIndexMapFun(cityArr: Array[String], start_map: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]], end_map: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]): (collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]], collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]) = {
    val indexedCityArr = cityArr.zipWithIndex
    var start_swap_index_map: collection.mutable.Map[(String, String), List[(Int, String)]] = null
    var end_swap_index_map: collection.mutable.Map[(String, String), List[(Int, String)]] = null
    for (i <- 0 until cityArr.length) {
      if (i == 0) {
        val (code_l, _) = indexedCityArr(i)
        val start_info_map = start_map.getOrElse(code_l, collection.mutable.Map.empty)
        start_swap_index_map = swapStartOrEnd("start", i, start_info_map)
        start_map.put(code_l, start_swap_index_map)
      }

      if (i >= 1 && i + 1 <= cityArr.length - 1) {
        val (code_q, _) = indexedCityArr(i - 1)
        val (code_l, _) = indexedCityArr(i)
        val (code_p, _) = indexedCityArr(i + 1)

        if (code_l == code_q && code_l != code_p) {
          val end_info_map = end_map.getOrElse(code_l, collection.mutable.Map.empty)
          end_swap_index_map = swapStartOrEnd("end", i, end_info_map)
          end_map.put(code_l, end_swap_index_map)
        }

        if (code_l != code_q && code_l != code_p) {
          val start_info_map = start_map.getOrElse(code_l, collection.mutable.Map.empty)
          start_swap_index_map = swapStartOrEnd("start", i, start_info_map)
          start_map.put(code_l, start_swap_index_map)

          val end_info_map = end_map.getOrElse(code_l, collection.mutable.Map.empty)
          end_swap_index_map = swapStartOrEnd("end", i, end_info_map)
          end_map.put(code_l, end_swap_index_map)
        }

        if (code_l != code_q && code_l == code_p) {
          val start_info_map = start_map.getOrElse(code_l, collection.mutable.Map.empty)
          start_swap_index_map = swapStartOrEnd("start", i, start_info_map)
          start_map.put(code_l, start_swap_index_map)
        }
      }
      if (i == cityArr.length - 1) {
        val (code_l, _) = indexedCityArr(i)
        val end_info_map = end_map.getOrElse(code_l, collection.mutable.Map.empty)
        end_swap_index_map = swapStartOrEnd("end", i, end_info_map)
        end_map.put(code_l, end_swap_index_map)
      }
    }
    (start_map, end_map)
  }

  def swapStartOrEnd(flag: String, index: Int, start_or_end_info_map: collection.mutable.Map[(String, String), List[(Int, String)]]): collection.mutable.Map[(String, String), List[(Int, String)]] = {
    if (flag == "start") {
      for (key <- start_or_end_info_map.keys if start_or_end_info_map.keys.size > 0) {
        val value = start_or_end_info_map.getOrElse(key, List.empty)
        var new_value = List[(Int, String)]()
        if (index == 0) {
          new_value = new_value :+ (index, "start")
        }
        if (index != 0) {
          new_value = value :+ (index, "start")
        }
        start_or_end_info_map.put(key, new_value)
      }
    }
    if (flag == "end") {
      for (key <- start_or_end_info_map.keys if start_or_end_info_map.keys.size > 0) {
        val value = start_or_end_info_map.getOrElse(key, List.empty)
        var new_value = List[(Int, String)]()
        if (index != 0) {
          new_value = value :+ (index, "end")
        }
        start_or_end_info_map.put(key, new_value)
      }
    }
    start_or_end_info_map
  }

  def addDateOrHourCols(add_res_cols_str: Seq[String]): Seq[Column] = {
    val flag = Seq("date", "date", "hour", "hour", "date", "date", "hour", "hour")
    val deal_cols = Seq("time_first_gj", "time_end_gj", "time_first_gj", "time_end_gj", "time_highspeed_start", "time_highspeed_end", "time_highspeed_start", "time_highspeed_end").map(col)

    val add_res_cols = flag zip deal_cols map { x => getDateOrHourUDF(x._1)(x._2) }
    ColumnUtil.renameColumn(add_res_cols, add_res_cols_str)
  }

  def getDateOrHourUDF(flag: String) = udf((tm: String) => {
    var tm_res = ""
    try {
      if (tm != "" && flag == "date") {
        tm_res = tm.substring(0, 10)
      }
      if (tm != "" && flag == "hour") {
        tm_res = tm.split("\\s+")(1).split(":")(0)
      }
    } catch {
      case e: Exception => "" + e
    }
    tm_res
  })

  def getFlowUDF(flag: String) = udf((adcode_six_gj: String) => {
    var code = ""
    val adcode_six_gj_arr = adcode_six_gj.split("\\|")
    if (flag == "start") {
      code = adcode_six_gj_arr(0)
    }
    if (flag == "end") {
      code = adcode_six_gj_arr(adcode_six_gj_arr.size - 1)
    }
    code
  })

  def getDuration_1_2 = udf((duration_tl: String, roadname_tl: String, roadclass_tl: String) => {
    var total_duration_tl_1, total_duration_tl_2 = 0.0
    val duration_tl_arr = duration_tl.split("\\|")
    try {
      total_duration_tl_1 = duration_tl_arr.map(x => try {
        x.toDouble
      } catch {
        case e: Exception => 0.0
      }).sum
      val roadname_tl_arr = roadname_tl.split("\\|")
      val roadclass_tl_arr = roadclass_tl.split("\\|")
      for (i <- 0 until roadname_tl_arr.size) {
        val start = roadclass_tl_arr(i).split("_")(0)
        val end = roadclass_tl_arr(i).split("_")(0)
        if (roadname_tl_arr(i).contains("服务区") || roadname_tl_arr(i).contains("停车区") || (start.toDouble != 0.0 && end.toDouble != 0.0)) {
          total_duration_tl_2 += (try {
            duration_tl_arr(i).toDouble
          } catch {
            case e: Exception => 0.0
          })
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    total_duration_tl_1 + "&" + total_duration_tl_2.toString
  })

  def getRoadclass_tl = udf((swid_tl: String, swid_qm: String, roadclass_qm: String, roadname_qm: String) => {
    val roadclass_tl = new ArrayBuffer[String]()
    val roadname_tl = new ArrayBuffer[String]()
    val index_swid_qm = collection.mutable.Map[String, Int]()

    val roadclass_qm_ab = new ArrayBuffer[String]()
    val roadname_qm_ab = new ArrayBuffer[String]()
    try {
      val swid_tl_arr = swid_tl.split("\\|").map(_.split("_")).flatten
      val swid_qm_arr: Array[(String, Int)] = swid_qm.split("\\|").zipWithIndex
      swid_qm_arr.foreach(x => index_swid_qm.put(x._1, x._2))

      val roadclass_qm_arr = roadclass_qm.split("\\|")
      val roadname_qm_arr = roadname_qm.split("\\|")

      for (i <- 0 until swid_tl_arr.size) {
        val index = index_swid_qm.getOrElse(swid_tl_arr(i), 999999999)
        if (index < 999999999) {
          roadclass_qm_ab += roadclass_qm_arr(index)
          roadname_qm_ab += roadname_qm_arr(index)
        } else {
          roadclass_qm_ab += "999"
          roadname_qm_ab += "-"
        }
      }
      for (i <- 0 until roadclass_qm_ab.size if i % 2 == 0) {
        roadclass_tl += roadclass_qm_ab(i) + "_" + roadclass_qm_ab(i + 1)
        roadname_tl += roadname_qm_ab(i) + "_" + roadname_qm_ab(i + 1)
      }
    } catch {
      case e: Exception => "" + e
    }

    roadclass_tl.mkString("|") + "&" + roadname_tl.mkString("|")
  })

  def getSwid_tl = udf((swid_gj: String, time_gj: String, index_3: String, index_4: String) => {
    val swid_tl = new ArrayBuffer[String]()
    val time_tl = new ArrayBuffer[String]()
    val duration_tl = new ArrayBuffer[String]()
    try {
      val swid_gj_arr = swid_gj.split("\\|")
      val time_gj_arr = time_gj.split("\\|")
      for (i <- 0 until time_gj_arr.size if i >= index_3.toInt && i <= index_4.toInt) {
        if (i + 1 <= index_4.toInt && (time_gj_arr(i + 1).toLong - time_gj_arr(i).toLong) >= 900l) {
          swid_tl += (swid_gj_arr(i) + "_" + swid_gj_arr(i + 1))
          time_tl += tranTstampToTime(sdf1, time_gj_arr(i)) + "_" + tranTstampToTime(sdf1, time_gj_arr(i + 1))
          duration_tl += ((time_gj_arr(i + 1).toLong - time_gj_arr(i).toLong) / 60.0).formatted("%.2f")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    swid_tl.mkString("|") + "&" + time_tl.mkString("|") + "&" + duration_tl.mkString("|")
  })

  def getDisHighspeedBlock = udf((dis_highspeed: String) => {
    val dis_db = dis_highspeed.toDouble
    val dis_highspeed_block = dis_db match {
      case x if x >= 0 && x <= 10 => "[0,10]"
      case x if x > 10 && x <= 50 => "(10,50]"
      case x if x > 0 && x <= 100 => "(50,100]"
      case x if x > 100 && x <= 200 => "(100,200]"
      case x if x > 200 && x <= 500 => "(200,500]"
      case x if x > 500 && x <= 1000 => "(500,1000]"
      case x if x > 1000 => "(1000,1000+]"
    }
    dis_highspeed_block
  })

  def getAvgSpeedHighspeed = udf((speed_gj: String, index_3: String, index_4: String) => {
    val speed_gj_arr = speed_gj.split("\\|")
    var avg_speed_instant_highspeed = 0.0
    var count = 1
    try {
      count = (index_4.toInt - index_3.toInt) + 1

      for (i <- 0 until speed_gj_arr.size if i >= index_3.toInt && i <= index_4.toInt) {
        avg_speed_instant_highspeed += speed_gj_arr(i).toDouble
      }
    } catch {
      case e: Exception => "" + e
    }
    (avg_speed_instant_highspeed / count).toString
  })

  def getDisAcHighspeed = udf((dr_length_qm: String, index_0_all: String) => {
    var dis_ac_highspeed = 0.0
    try {
      val dr_length_qm_arr = dr_length_qm.split("\\|")
      val index_0_all_arr = index_0_all.split("\\|")
      for (i <- 0 until dr_length_qm_arr.size if index_0_all_arr.contains(i.toString)) {
        dis_ac_highspeed += dr_length_qm_arr(i).toDouble
      }
    } catch {
      case e: Exception => e + ""
    }
    (dis_ac_highspeed / 1000).formatted("%.2f").toString
  })

  def getDisHighspeed = udf((dr_length_qm: String, index_1: String, index_2: String) => {
    var dis_highspeed = 0.0
    try {
      val dr_length_qm_arr = dr_length_qm.split("\\|")
      for (i <- 0 until dr_length_qm_arr.size if i >= index_1.toInt && i <= index_2.toInt) {
        dis_highspeed += (dr_length_qm_arr(i).toDouble) / 1000
      }
    } catch {
      case e: Exception => e + ""
    }
    dis_highspeed.formatted("%.2f").toString
  })

  def getNameHighspeed = udf((swid_name_qm: String, index_1: String, index_2: String) => {
    var name_highspeed: Array[String] = null
    try {
      val swid_name_qm_arr = swid_name_qm.split("\\|")
      name_highspeed = new Array[String](swid_name_qm_arr.size)
      for (i <- 0 until swid_name_qm_arr.size if i >= index_1.toInt && i <= index_2.toInt) {
        if (i < 1) name_highspeed(i) = swid_name_qm_arr(i)
        if (i >= 1 && swid_name_qm_arr(i) != swid_name_qm_arr(i - 1)) name_highspeed(i) = swid_name_qm_arr(i)
      }
    } catch {
      case e: Exception => e + ""
    }
    name_highspeed.filter(_ != null).mkString("|")
  })

  def getStartOrEnd = udf((other_info: String, index: String) => {
    var res = ""
    try {
      res = other_info.split("\\|")(index.toInt)
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  def getIndex1234(index_flag: String) = udf((roadclass_qm: String, position: String) => {
    var index = ""
    try {
      val roadclass_qm_arr = roadclass_qm.split("\\|")
      if (index_flag == "1") {
        breakable {
          for (i <- 0 until roadclass_qm_arr.size) {
            if (roadclass_qm_arr(i) == position) {
              index = i.toString
              break
            }
          }
        }
      }
      if (index_flag == "2") {
        breakable {
          for (j <- (0 until roadclass_qm_arr.size).reverse) {
            if (roadclass_qm_arr(j) == position) {
              index = j.toString
              break
            }
          }
        }
      }
      if (index_flag == "3") {
        val index_arr = new ArrayBuffer[String]()
        for (i <- 0 until roadclass_qm_arr.size) {
          if (roadclass_qm_arr(i) == position) {
            index_arr += i.toString
          }
        }
        index = index_arr.mkString("|")
      }
    } catch {
      case e: Exception => "" + e
    }
    index
  })

  def getLinksInfo(swid_diff: String, date: String): (String, String, String, String, String, String) = {
    val params = //2e4b2a16ef2a4427917f366fb22febb5   8bb09e5e110845f39a000391668e3e80
      s"""{
         |    "ak": "2e4b2a16ef2a4427917f366fb22febb5",
         |    "useEstimateTime": 1,
         |    "opt":"sf4",
         |    "simple_distance":0,
         |    "test": 0,
         |    "stype": 0,
         |    "etype": 2,
         |    "passport": "100000",
         |    "mode": 2,
         |    "speed": 1,
         |    "rtic":0,
         |    "rtic_dur":0,
         |    "output":"json",
         |    "Toll": 1,
         |    "point_src" : 1,
         |    "swid":"$swid_diff",
         |    "date": "$date"}
         |""".stripMargin //②那个qm_point接口的入参， "test": 1 改为 "test": 0 ，可以降低调接口的失败率；
    val sw_id_qm_ab = new ArrayBuffer[String]()
    val roadclass_qm_ab = new ArrayBuffer[String]()
    val dr_length_qm_ab = new ArrayBuffer[String]()
    val formway_ab = new ArrayBuffer[String]()
    val name_qm_ab = new ArrayBuffer[String]()

    try {
      //      val hw_str = HttpInvokeUtil.sendPost(HTTP_XY_COORDS_P, params, 3, 2)
      val hw_str = HttpInvokeUtil.sendPostH(HTTP_XY_COORDS_P, params, 3, 2, "2e4b2a16ef2a4427917f366fb22febb5", "")
      logger.error("》》》》》》》》》》》接口正常调用中》》》》》》》》")
      val hw_str_json = JSON.parseObject(hw_str)
      val route = hw_str_json.getJSONObject("route")
      if (route != null) {
        val paths_arr = route.getJSONArray("paths")
        if (paths_arr != null && paths_arr.size() > 0) {
          for (i <- 0 until paths_arr.size()) {
            val steps_arr = paths_arr.getJSONObject(i).getJSONArray("steps")
            if (steps_arr != null && steps_arr.size() > 0) {
              for (j <- 0 until steps_arr.size()) {
                val links_arr = steps_arr.getJSONObject(j).getJSONArray("links")
                if (links_arr != null && links_arr.size() > 0) {
                  for (k <- 0 until links_arr.size()) {
                    val sw_id_tmp = links_arr.getJSONObject(k).getString("sw_id")
                    val roadclass_tmp = links_arr.getJSONObject(k).getString("roadclass")
                    val dr_length_tmp = links_arr.getJSONObject(k).getString("dr_length")
                    val formway_tmp = links_arr.getJSONObject(k).getString("formway")
                    val name_tmp = links_arr.getJSONObject(k).getString("name")
                    sw_id_qm_ab += (if (sw_id_tmp != null && sw_id_tmp.trim != "") sw_id_tmp else "-")
                    roadclass_qm_ab += (if (roadclass_tmp != null && roadclass_tmp.trim != "") roadclass_tmp else "-")
                    dr_length_qm_ab += (if (dr_length_tmp != null && dr_length_tmp.trim != "") dr_length_tmp else "-")
                    formway_ab += (if (formway_tmp != null && formway_tmp.trim != "") formway_tmp else "-")
                    name_qm_ab += (if (name_tmp != null && name_tmp.trim != "") name_tmp else "-")
                  }
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    val dist_gj = (dr_length_qm_ab.map {
      x =>
        try {
          x.toDouble
        } catch {
          case e: Exception => 0
        }
    }.sum / 1000).toString
    (sw_id_qm_ab.mkString("|"), roadclass_qm_ab.mkString("|"), dr_length_qm_ab.mkString("|"), formway_ab.mkString("|"), name_qm_ab.mkString("|"), dist_gj)
  }

  def diffSwid = udf((swid: String) => {
    var new_swid: Array[String] = null
    try {
      val swid_arr = swid.split("\\|")
      new_swid = new Array[String](swid_arr.size)
      for (i <- 0 until swid_arr.size) {
        if (i < 1) new_swid(i) = swid_arr(i)
        if (i >= 1 && swid_arr(i) != swid_arr(i - 1)) new_swid(i) = swid_arr(i)
      }
    } catch {
      case e: Exception => e + ""
    }
    new_swid.filter(_ != null).mkString("|")
  })

  def sortFieldN = udf((num: String, other: String) => {
    val res = new ListBuffer[String]()
    if (num != null && num.trim != "" && other != null && other.trim != "") {
      val num_arr = num.split("&")
      val other_arr = other.split("&")
      val new_arr = num_arr.zip(other_arr).sortWith((x, y) => x._1.toInt <= y._1.toInt)
      for (i <- 0 until (new_arr.length)) {
        res += new_arr(i)._2
      }
    }
    res.mkString("|")
  })


  def getTimeInfo = udf((time: String) => {
    var time_first, time_end, time_taken = ""
    try {
      val time_arr = time.split("\\|")
      time_first = tranTstampToTime(sdf1, time_arr(0))
      time_end = tranTstampToTime(sdf1, time_arr(time_arr.length - 1))
      time_taken = ((time_arr(time_arr.length - 1).toLong - time_arr(0).toLong) / 60.0).toString
    } catch {
      case e: Exception => "" + e
    }
    time_first + "&" + time_end + "&" + time_taken
  })

  def getCitycode = udf((adcode: String) => {
    var city_code, city_code_first, city_code_end = ""

    try {
      val adcode_arr = adcode.split("\\|")
      city_code = adcode_arr.map(_.substring(0, 4) + "00").mkString("|")
      city_code_first = adcode_arr(0).substring(0, 4) + "00"
      city_code_end = adcode_arr(adcode_arr.length - 1).substring(0, 4) + "00"
    } catch {
      case e: Exception => "" + e
    }
    city_code + "&" + city_code_first + "&" + city_code_end
  })

  def reQuotaColwithIndex = udf((col: String, start_index: String, end_index: String) => {
    val one_res = new ArrayBuffer[String]()
    try {
      val col_arr = col.split("\\|")
      for (i <- 0 until col_arr.length if i >= start_index.toInt && i <= end_index.toInt) {
        one_res += col_arr(i)
      }
    } catch {
      case e: Exception => "" + e
    }
    one_res.mkString("|")
  })

  def reQuotaCol = udf((col: String, index_list: String) => {
    val merge_res = new ArrayBuffer[String]()
    try {
      val col_arr = col.split("\\|")
      val index_list_arr = index_list.split("\\|")
      for (index <- index_list_arr) {
        val start_index = index.split(",")(0)
        val end_index = index.split(",")(1)
        val one_res = new ArrayBuffer[String]()
        for (i <- 0 until col_arr.length if i >= start_index.toInt && i <= end_index.toInt) {
          one_res += col_arr(i)
        }
        merge_res += one_res.mkString("|")
      }
    } catch {
      case e: Exception => "" + e
    }
    merge_res.mkString("&")
  })

  def flowDirectionPart = udf((adcode: String, city_flag: String) => {
    var all_index_res_tmp = ""
    val all_index_res = new ArrayBuffer[String]()
    val adcode_arr = adcode.split("\\|").map(_.substring(0, 4)) //保留前4位 city_code信息

    val sh_cq = loopMultiCity(adcode_arr, "3101", "5001")

    if (city_flag == "sh_cq") {
      all_index_res_tmp = sh_cq.mkString("|")
    }

    try {
      val all_index_res_tmp_arr = all_index_res_tmp.split("\\|")
      for (k <- 0 until all_index_res_tmp_arr.size if k % 2 == 0) {
        all_index_res += all_index_res_tmp_arr(k) + "," + all_index_res_tmp_arr(k + 1)
      }
    } catch {
      case e: Exception => ""
    }
    all_index_res.mkString("|")
  })

  def flowDirection = udf((adcode: String, city_flag: String) => {
    var all_index_res_tmp = ""
    val all_index_res = new ArrayBuffer[String]()
    val adcode_arr = adcode.split("\\|").map(_.substring(0, 4)) //保留前4位 city_code信息
    // sh_cq_wh_xa_gz_bj sh_cq_wh_xa  wh_xa_gz_bj sh_cq_gz_bj sh_cq wh_xa gz_bj
    //上海：3101** 重庆：5001** 武汉：4201**  西安：6101** 广州：4401** 北京：1101**
    //    val sh_cq = loopMultiCity(adcode_arr, "3209", "3207")
    val sh_cq = loopMultiCity(adcode_arr, "3101", "5001")
    val wh_xa = loopMultiCity(adcode_arr, "4201", "6101")
    val gz_bj = loopMultiCity(adcode_arr, "4401", "1101")

    if (city_flag == "sh_cq_wh_xa_gz_bj") {
      all_index_res_tmp = (sh_cq ++ wh_xa ++ gz_bj).mkString("|")
    }
    if (city_flag == "sh_cq_wh_xa") {
      all_index_res_tmp = (sh_cq ++ wh_xa).mkString("|")
    }
    if (city_flag == "wh_xa_gz_bj") {
      all_index_res_tmp = (sh_cq ++ wh_xa).mkString("|")
    }
    if (city_flag == "sh_cq_gz_bj") {
      all_index_res_tmp = (sh_cq ++ gz_bj).mkString("|")
    }
    if (city_flag == "sh_cq") {
      all_index_res_tmp = sh_cq.mkString("|")
    }
    if (city_flag == "wh_xa") {
      all_index_res_tmp = wh_xa.mkString("|")
    }
    if (city_flag == "gz_bj") {
      all_index_res_tmp = gz_bj.mkString("|")
    }
    try {
      val all_index_res_tmp_arr = all_index_res_tmp.split("\\|")
      for (k <- 0 until all_index_res_tmp_arr.size if k % 2 == 0) {
        all_index_res += all_index_res_tmp_arr(k) + "," + all_index_res_tmp_arr(k + 1)
      }
    } catch {
      case e: Exception => ""
    }
    all_index_res.mkString("|")
  })

  def loopMultiCity(adcode_arr: Array[String], start_code: String, end_code: String): ArrayBuffer[String] = {
    val start_end_index = new ArrayBuffer[String]()
    val end_start_index = new ArrayBuffer[String]()
    var start_end_index_res: ArrayBuffer[String] = null
    var end_start_index_res: ArrayBuffer[String] = null
    val start_end_hm = new mutable.HashMap[String, String]()
    val end_start_hm = new mutable.HashMap[String, String]()
    for (i <- 0 until adcode_arr.size) {
      //起终
      if (start_end_hm.size == 0 && i != adcode_arr.size - 1 && adcode_arr(i) == start_code && !start_end_hm.contains(end_code)) {
        start_end_hm.put(adcode_arr(i), i.toString)
        start_end_index += i.toString
      }
      if (start_end_hm.contains(start_code) && adcode_arr(i) == end_code) {
        if ((i + 1) <= adcode_arr.size - 1 && adcode_arr(i + 1) != end_code) {
          start_end_hm.put(adcode_arr(i), i.toString)
          start_end_index += i.toString
          start_end_hm.clear()
        }
        if (i == adcode_arr.size - 1) {
          start_end_hm.put(adcode_arr(i), i.toString)
          start_end_index += i.toString
          start_end_hm.clear()
        }
      }
      //起终 变化
      if (end_start_hm.size == 0 && i != adcode_arr.size - 1 && adcode_arr(i) == end_code && !end_start_hm.contains(start_code)) {
        end_start_hm.put(adcode_arr(i), i.toString)
        end_start_index += i.toString
      }
      if (end_start_hm.contains(end_code) && adcode_arr(i) == start_code) {
        if ((i + 1) <= adcode_arr.size - 1 && adcode_arr(i + 1) != start_code) {
          end_start_hm.put(adcode_arr(i), i.toString)
          end_start_index += i.toString
          end_start_hm.clear()
        }
        if (i == adcode_arr.size - 1) {
          end_start_hm.put(adcode_arr(i), i.toString)
          end_start_index += i.toString
          end_start_hm.clear()
        }
      }
    }
    if (start_end_index.size % 2 == 1) start_end_index_res = start_end_index.dropRight(1) else start_end_index_res = start_end_index
    if (end_start_index.size % 2 == 1) end_start_index_res = end_start_index.dropRight(1) else end_start_index_res = end_start_index

    start_end_index_res ++ end_start_index_res
  }


  def splitUnInfo = udf((info: String) => {
    val swid_arr, adcode_arr, time_arr, speed_arr = new ArrayBuffer[String]()
    try {
      val info_json = JSON.parseObject(info)
      val roadspeed_arr = info_json.getJSONArray("roadspeed")
      if (roadspeed_arr.size() >= 2) {
        for (i <- 0 until roadspeed_arr.size()) {
          swid_arr += roadspeed_arr.getJSONObject(i).getString("linkid")
          adcode_arr += roadspeed_arr.getJSONObject(i).getString("adcode")
          time_arr += roadspeed_arr.getJSONObject(i).getString("time")
          speed_arr += roadspeed_arr.getJSONObject(i).getString("speed")
        }
      }
    } catch {
      case e: Exception => ""
    }
    swid_arr.mkString("|") + "&" + adcode_arr.mkString("|") + "&" + time_arr.mkString("|") + "&" + speed_arr.mkString("|")
  })

  def getCityflagPart(from_d: String, to_d: String) = udf((adcode: String) => {
    var city_flag = ""
    try {
      val adcode_arr = adcode.split("\\|")
      if (adcode_arr.size >= 2) {
        val ad_hs = new mutable.HashSet[String]()
        breakable {
          for (i <- 0 until adcode_arr.size) {
            val city_code = adcode_arr(i).substring(0, 4)
            if (from_d == city_code && ad_hs.size == 0) ad_hs.add(city_code)
            if (to_d == city_code && ad_hs.size != 0) {
              ad_hs.add(city_code)
              break
            }
          }
        }
        //上海：3101** 重庆：5001** 武汉：4201**  西安：6101** 广州：4401** 北京：1101**
        if (ad_hs.size == 2) {
          city_flag = "sh_cq"
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    city_flag
  })

  def getCityflag = udf((adcode: String) => {
    var city_flag = ""
    try {
      val adcode_arr = adcode.split("\\|")
      if (adcode_arr.size >= 2) {
        val ad_hs = new mutable.HashSet[String]()
        for (i <- 0 until adcode_arr.size) {
          val need_citys = Seq("3101", "5001", "4201", "6101", "4401", "1101")
          //val need_citys = Seq("3209", "3207", "4201", "6101", "4401", "1101")
          val city_code = adcode_arr(i).substring(0, 4)
          if (need_citys.contains(city_code)) ad_hs.add(city_code)
        }
        //上海：3101** 重庆：5001** 武汉：4201**  西安：6101** 广州：4401** 北京：1101**
        //      val sh_cq = ad_hs.contains("3209") && ad_hs.contains("3207")
        val sh_cq = ad_hs.contains("3101") && ad_hs.contains("5001")
        val wh_xa = ad_hs.contains("4201") && ad_hs.contains("6101")
        val gz_bj = ad_hs.contains("4401") && ad_hs.contains("1101")
        if (ad_hs.size == 6) {
          city_flag = "sh_cq_wh_xa_gz_bj"
        }
        if (ad_hs.size >= 4 && ad_hs.size <= 5) {
          if (sh_cq && wh_xa) {
            city_flag = "sh_cq_wh_xa"
          } else if (wh_xa && gz_bj) {
            city_flag = "wh_xa_gz_bj"
          } else if (sh_cq && gz_bj) {
            city_flag = "sh_cq_gz_bj"
          }
        }
        if (ad_hs.size >= 2 && ad_hs.size <= 3) {
          if (sh_cq) {
            city_flag = "sh_cq"
          } else if (wh_xa) {
            city_flag = "wh_xa"
          } else if (gz_bj) {
            city_flag = "gz_bj"
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    city_flag
  })

  def getCityMapAdcode(spark: SparkSession): DataFrame = {
    import spark.implicits._
    val city_map_df = Seq(("上海", "上海市", "310000", "直辖市"),
      ("北京", "北京市", "110000", "直辖市"),
      ("重庆", "重庆市", "500000", "直辖市"),
      ("天津", "天津市", "120000", "直辖市"),
      ("广州", "广州市", "440100", "省会"),
      ("杭州", "杭州市", "330100", "省会"),
      ("南京", "南京市", "320100", "省会"),
      ("豫北", "郑州市", "410100", "省会"),
      ("鄂东", "武汉市", "420100", "省会"),
      ("山西", "太原市", "140100", "省会"),
      ("福州", "福州市", "350100", "省会"),
      ("陕西", "西安市", "610100", "省会"),
      ("宁夏", "银川市", "640100", "省会"),
      ("甘肃", "兰州市", "620100", "省会"),
      ("甘肃", "西宁市", "630100", "省会"),
      ("赣北", "南昌市", "360100", "省会"),
      ("广西", "南宁市", "450100", "省会"),
      ("湘北", "长沙市", "430100", "省会"),
      ("皖北", "合肥市", "340100", "省会"),
      ("海南", "海口市", "460100", "省会"),
      ("济南", "济南市", "370100", "省会"),
      ("沈阳", "沈阳市", "210100", "省会"),
      ("黑龙江", "哈尔滨市", "230100", "省会"),
      ("冀州", "石家庄市", "130100", "省会"),
      ("内蒙古", "呼和浩特市", "150100", "省会"),
      ("四川", "成都市", "510100", "省会"),
      ("四川", "拉萨市", "540100", "省会"),
      ("吉林", "长春市", "220100", "省会"),
      ("贵州", "贵阳市", "520100", "省会"),
      ("新疆", "乌鲁木齐市", "650100", "省会"),
      ("云南", "昆明市", "530100", "省会"),
      ("深圳", "深圳市", "440300", "深圳市")).toDF("area_name", "city_name", "adcode", "descrip")
    city_map_df
  }

  def getCityMapAdcode60(spark: SparkSession): DataFrame = {
    import spark.implicits._
    val city_map_df = Seq(("天津", "天津市", "120000", "直辖市"),
      ("北京", "北京市", "110000", "直辖市"),
      ("重庆", "重庆市", "500000", "直辖市"),
      ("上海", "上海市", "310000", "直辖市"),
      ("陕西", "西安市", "610100", "省会"),
      ("鄂东", "武汉市", "420100", "省会"),
      ("南京", "南京市", "320100", "省会"),
      ("四川", "成都市", "510100", "省会"),
      ("济南", "济南市", "370100", "省会"),
      ("新疆", "乌鲁木齐市", "650100", "省会"),
      ("杭州", "杭州市", "330100", "省会"),
      ("内蒙古", "呼和浩特市", "150100", "省会"),
      ("冀州", "石家庄市", "130100", "省会"),
      ("山西", "太原市", "140100", "省会"),
      ("福州", "福州市", "350100", "省会"),
      ("沈阳", "沈阳市", "210100", "省会"),
      ("海南", "海口市", "460100", "省会"),
      ("云南", "昆明市", "530100", "省会"),
      ("皖北", "合肥市", "340100", "省会"),
      ("湘北", "长沙市", "430100", "省会"),
      ("广州", "广州市", "440100", "省会"),
      ("贵州", "贵阳市", "520100", "省会"),
      ("豫北", "郑州市", "410100", "省会"),
      ("广西", "南宁市", "450100", "省会"),
      ("宁夏", "银川市", "640100", "省会"),
      ("甘肃", "兰州市", "620100", "省会"),
      ("吉林", "长春市", "220100", "省会"),
      ("甘肃", "西宁市", "630100", "省会"),
      ("赣北", "南昌市", "360100", "省会"),
      ("黑龙江", "哈尔滨市", "230100", "省会"),
      ("深圳", "深圳市", "440300", "深圳市"),
      ("佛山", "佛山市", "440600", ""),
      ("烟台", "烟台市", "370600", ""),
      ("五邑", "江门市", "440700", ""),
      ("温州", "温州市", "330300", ""),
      ("东莞", "东莞市", "441900", ""),
      ("大连", "大连市", "210200", ""),
      ("冀北", "廊坊市", "131000", ""),
      ("潮汕", "汕头市", "440500", ""),
      ("泉州", "莆田市", "350300", ""),
      ("嘉兴", "湖州市", "330500", ""),
      ("中山", "中山市", "442000", ""),
      ("金华", "金华市", "330700", ""),
      ("青岛", "青岛市", "370200", ""),
      ("台州", "台州市", "331000", ""),
      ("鲁中", "潍坊市", "370700", ""),
      ("嘉兴", "嘉兴市", "330400", ""),
      ("无锡", "无锡市", "320200", ""),
      ("常州", "扬州市", "321000", ""),
      ("惠州", "惠州市", "441300", ""),
      ("苏北", "淮安市", "320800", ""),
      ("中山", "珠海市", "440400", ""),
      ("泉州", "泉州市", "350500", ""),
      ("绍兴", "绍兴市", "330600", ""),
      ("皖南", "芜湖市", "340200", ""),
      ("常州", "常州市", "320400", ""),
      ("南通", "南通市", "320600", ""),
      ("苏州", "苏州市", "320500", ""),
      ("厦门", "厦门市", "350200", ""),
      ("宁波", "宁波市", "330200", "")).toDF("area_name", "city_name", "adcode", "descrip")
    city_map_df
  }

}
