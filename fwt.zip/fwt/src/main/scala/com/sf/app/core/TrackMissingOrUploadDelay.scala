package com.sf.app.core


import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.DataSourceCommon
import constant.HttpConstant.HTTP_TRACK_DELAY_P
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.splitFun
import utils.{ColumnUtil, HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 临时exe 每次一周左右数据  接口调用2小时
 * @description:轨迹延迟上传验证
 * @demander:ft80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/4/11 22:41
 */
case class CntDelay(cnt: Int, cnt_delay_0: Int, cnt_delay_0_10: Int, cnt_delay_10_20: Int, cnt_delay_20_30: Int, cnt_delay_30_60: Int, cnt_delay_60_120: Int, cnt_delay_120_300: Int, cnt_delay_300_600: Int, cnt_delay_600_1800: Int, cnt_delay_1800_3600: Int, cnt_delay_3600_7200: Int, cnt_delay_7200_10800: Int, cnt_delay_10800_14400: Int, cnt_delay_14400_18000: Int, cnt_delay_18000_21600: Int, cnt_delay_21600_25200: Int, cnt_delay_25200_28800: Int, cnt_delay_28800_m: Int)

case class DelayInfo(task_id: String, start_dept: String, end_dept: String, un: String, begindatetime: String, enddatetime: String, carrier_type: String, cnt: Int, cnt_delay_0: Int, cnt_delay_0_10: Int, cnt_delay_10_20: Int, cnt_delay_20_30: Int, cnt_delay_30_60: Int, cnt_delay_60_120: Int, cnt_delay_120_300: Int, cnt_delay_300_600: Int, cnt_delay_600_1800: Int, cnt_delay_1800_3600: Int, cnt_delay_3600_7200: Int, cnt_delay_7200_10800: Int, cnt_delay_10800_14400: Int, cnt_delay_14400_18000: Int, cnt_delay_18000_21600: Int, cnt_delay_21600_25200: Int, cnt_delay_25200_28800: Int, cnt_delay_28800_m: Int)

case class TypeRate(task_id: String, start_dept: String, end_dept: String, un: String, begindatetime: String, enddatetime: String, carrier_type: String, rate: String)

case class HalfwayInterRate(task_id: String, start_dept: String, end_dept: String, un: String, begindatetime: String, enddatetime: String, carrier_type: String, actual_capacity_load: String, back_axis: String)

object TrackMissingOrUploadDelay extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val run_flag = args(0)
    if (run_flag == "1") loadDataChooseZyAndOutsourcing(spark)
    if (run_flag == "2") loadDataChooseZY(spark)
    if (run_flag == "3") loadDataChooseZYHalfIntegrate(spark)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  /**
   * 轨迹缺失 新增完整率
   *
   * @param spark
   */
  def loadDataChooseZYHalfIntegrate(spark: SparkSession): Unit = {
    import spark.implicits._
    val dim_df = spark.sql("""select dept_code,provinct_name from dim.dim_department group by dept_code,provinct_name""")
    val res_df_cols = spark.sql("""select * from dm_gis.eta_std_track_delay_axis_dtl limit 0""").schema.map(x => col(x.name))
    val load_sql =
      s"""
         |select *
         |from
         |  (
         |    select
         |      task_id,start_dept,end_dept,
         |      vehicle_serial as un,
         |      actual_depart_tm as begindatetime,
         |      actual_arrive_tm as enddatetime,
         |      carrier_type,actual_capacity_load,
         |      row_number() over(
         |        partition by task_subid
         |        order by last_update_tm desc
         |      ) as t
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day between '20230412' and '20230418'
         |      and carrier_type ='1'
         |      and cast(halfway_integrate_rate as double) > 0.9
         |  ) as a
         |where
         |  t = 1
         |""".stripMargin
    logger.error("传入的sql语句：" + load_sql)
    val o_df = spark.sql(load_sql).repartition(60).persist()
    logger.error("输入的数据总量为：" + o_df.count())
    val back_axis_infos_str = splitFun("_")('back_axis_infos)
    val o_recall_df = o_df
      .map(row => {
        val task_id = row.getAs[String]("task_id")
        val start_dept = row.getAs[String]("start_dept")
        val end_dept = row.getAs[String]("end_dept")
        val un = row.getAs[String]("un")
        val begindatetime = row.getAs[String]("begindatetime")
        val enddatetime = row.getAs[String]("enddatetime")
        val carrier_type = row.getAs[String]("carrier_type")
        val actual_capacity_load = row.getAs[String]("actual_capacity_load")

        val capacity_load = actual_capacity_load match {
          case x if !x.isEmpty && x.trim != "" => actual_capacity_load.toDouble
          case _ => 0.0
        }
        val axis_arr = new ArrayBuffer[Int]()
        axis_arr += 2
        if (capacity_load > 7) {
          axis_arr += 3
          axis_arr += 4
        }
        var back_axis = ""
        if (begindatetime != null && begindatetime.trim != "" && enddatetime != null && enddatetime.trim != "") {
          val begindatetime_post = begindatetime.replaceAll("-|:| ", "")
          val enddatetime_post = enddatetime.replaceAll("-|:| ", "")
          back_axis = postTrackHalfwayInter(un, begindatetime_post, enddatetime_post, axis_arr)
        }
        HalfwayInterRate(task_id, start_dept, end_dept, un, begindatetime, enddatetime, carrier_type, actual_capacity_load, back_axis)
      }).toDF()
      .withColumn("back_axis_infos", explode(split('back_axis, "&")))
      .na.fill("", Seq("back_axis_infos"))
      .withColumn("axis", back_axis_infos_str(0))
      .withColumn("tollcharge", back_axis_infos_str(1))
      .withColumn("rc_distance", back_axis_infos_str(2))
      .withColumn("weight", lit("14"))
      .withColumn("length", lit("9.6"))
      .join(broadcast(dim_df.selectExpr("dept_code as start_dept", "provinct_name start_province")), Seq("start_dept"), "left")
      .join(broadcast(dim_df.selectExpr("dept_code as end_dept", "provinct_name end_province")), Seq("end_dept"), "left")
      .withColumn("inc_day", lit("20230418"))
      .select(res_df_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>调完接口后的数据>>>" + o_recall_df.count())
    writeToHive(spark, o_recall_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_std_track_delay_axis_dtl")
    o_df.unpersist()
    o_recall_df.unpersist()
  }

  def loadDataChooseZY(spark: SparkSession): Unit = {
    import spark.implicits._
    val res_df_cols = spark.sql("""select * from dm_gis.eta_std_track_delay_rate_dtl limit 0""").schema.map(x => col(x.name))
    val load_sql =
      s"""
         |select *
         |from
         |  (
         |    select
         |      task_id,start_dept,end_dept,
         |      vehicle_serial as un,
         |      actual_depart_tm as begindatetime,
         |      actual_arrive_tm as enddatetime,
         |      carrier_type,
         |      row_number() over(
         |        partition by task_subid
         |        order by last_update_tm desc
         |      ) as t
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day between '20230403' and '20230409'
         |      and carrier_type ='1'
         |  ) as a
         |where
         |  t = 1
         |""".stripMargin
    logger.error("传入的sql语句：" + load_sql)
    val o_df = spark.sql(load_sql).repartition(60).persist()
    logger.error("输入的数据总量为：" + o_df.count())
    val o_recall_df = o_df
      .map(row => {
        val task_id = row.getAs[String]("task_id")
        val start_dept = row.getAs[String]("start_dept")
        val end_dept = row.getAs[String]("end_dept")
        val un = row.getAs[String]("un")
        val begindatetime = row.getAs[String]("begindatetime")
        val enddatetime = row.getAs[String]("enddatetime")
        val carrier_type = row.getAs[String]("carrier_type")

        var offtime1, offtime2, offtime3, offtime4 = ""
        if (begindatetime != null && begindatetime.trim != "" && enddatetime != null && enddatetime.trim != "") {
          val begindatetime_post = begindatetime.replaceAll("-|:| ", "")
          val enddatetime_post = enddatetime.replaceAll("-|:| ", "")
          offtime1 = postTrackOfftime(un, begindatetime_post, enddatetime_post, "0")._2
          offtime2 = postTrackOfftime(un, begindatetime_post, enddatetime_post, "401")._2
          offtime3 = postTrackOfftime(un, begindatetime_post, enddatetime_post, "1011")._2
          offtime4 = postTrackOfftime(un, begindatetime_post, enddatetime_post, "305")._2
        }
        val rate_json = new JSONObject()
        rate_json.put("0", offtime1)
        rate_json.put("401", offtime2)
        rate_json.put("1011", offtime3)
        rate_json.put("305", offtime4)
        val rate = rate_json.toString
        TypeRate(task_id, start_dept, end_dept, un, begindatetime, enddatetime, carrier_type, rate)
      }).toDF().withColumn("inc_day", lit("20230409")).select(res_df_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>调完接口后的数据>>>" + o_recall_df.count())
    writeToHive(spark, o_recall_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_std_track_delay_rate_dtl")
    o_df.unpersist()
    o_recall_df.unpersist()
  }

  def loadDataChooseZyAndOutsourcing(spark: SparkSession): Unit = {
    import spark.implicits._
    val res_df_cols = spark.sql("""select * from dm_gis.eta_std_track_delay_slot_dtl limit 0""").schema.map(x => col(x.name))
    val load_sql =
      s"""
         |select *
         |from
         |  (
         |    select
         |      task_id,start_dept,end_dept,
         |      vehicle_serial as un,
         |      actual_depart_tm as begindatetime,
         |      actual_arrive_tm as enddatetime,
         |      carrier_type,
         |      row_number() over(
         |        partition by task_subid
         |        order by last_update_tm desc
         |      ) as t
         |    from
         |      dm_gis.eta_std_line_recall
         |    where
         |      inc_day between '20230405' and '20230407'
         |      and carrier_type in ('1' ,'0')
         |  ) as a
         |where
         |  t = 1
         |""".stripMargin
    logger.error("传入的sql语句：" + load_sql)
    val o_df = spark.sql(load_sql).repartition(60).persist()
    logger.error("输入的数据总量为：" + o_df.count())
    val o_recall_df = o_df
      .map(row => {
        val task_id = row.getAs[String]("task_id")
        val start_dept = row.getAs[String]("start_dept")
        val end_dept = row.getAs[String]("end_dept")
        val un = row.getAs[String]("un")
        val begindatetime = row.getAs[String]("begindatetime")
        val enddatetime = row.getAs[String]("enddatetime")
        val carrier_type = row.getAs[String]("carrier_type")

        var back = CntDelay(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
        if (begindatetime != null && begindatetime.trim != "" && enddatetime != null && enddatetime.trim != "") {
          val begindatetime_post = begindatetime.replaceAll("-|:| ", "")
          val enddatetime_post = enddatetime.replaceAll("-|:| ", "")
          back = postTrackTimeSlotJson(un, begindatetime_post, enddatetime_post, "0")
        }

        DelayInfo(task_id, start_dept, end_dept, un, begindatetime, enddatetime, carrier_type, back.cnt, back.cnt_delay_0, back.cnt_delay_0_10, back.cnt_delay_10_20, back.cnt_delay_20_30, back.cnt_delay_30_60, back.cnt_delay_60_120, back.cnt_delay_120_300, back.cnt_delay_300_600, back.cnt_delay_600_1800, back.cnt_delay_1800_3600, back.cnt_delay_3600_7200, back.cnt_delay_7200_10800, back.cnt_delay_10800_14400, back.cnt_delay_14400_18000, back.cnt_delay_18000_21600, back.cnt_delay_21600_25200, back.cnt_delay_25200_28800, back.cnt_delay_28800_m)
      }).toDF()
      .withColumn("inc_day", lit("20230407")).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>>>>" + o_recall_df.count())
    val agg_cols = aggCnt()
    val res_df = o_recall_df
      .groupBy("inc_day", "carrier_type")
      .agg(agg_cols.head, agg_cols.tail: _*)
      .select(res_df_cols: _*)
    writeToHive(spark, res_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_std_track_delay_slot_dtl")
    o_df.unpersist()
    o_recall_df.unpersist()
  }


  def postTrackHalfwayInter(un: String, begindatetime_post: String, enddatetime_post: String, axis_arr: ArrayBuffer[Int]): String = {
    val res = new ArrayBuffer[String]()
    for (i <- 0 until axis_arr.size) {
      val axis = axis_arr(i)
      val params =
        s"""
           |{
           |    "addpoint": 0,
           |    "type": "0",
           |    "un": "$un",
           |    "unType": "0",
           |    "beginDateTime":"$begindatetime_post",
           |    "endDateTime":"$enddatetime_post",
           |    "ak": "93ec117f7f1b4226b4e537c4802319e9",
           |    "hasRate": true,
           |        "vehicleInfo": {
           |        "load": 13.59,
           |	      "axis": $axis,
           |        "weight": 14,
           |        "length": 9.6
           |    }
           |}""".stripMargin
      var tollCharge, rc_distance_0 = ""
      try {
        val hw_str = HttpInvokeUtil.sendPost(HTTP_TRACK_DELAY_P, params, 3, 2)
        logger.error("》》》》》》》》》》》接口正常调用中》》》》》》》》")
        val hw_str_json = JSON.parseObject(hw_str)
        val result = hw_str_json.getJSONObject("result")
        if (result != null) {
          val data = result.getJSONObject("data")
          if (data != null) {
            tollCharge = data.getString("tollCharge")
            val rc_distance = data.getJSONObject("rc_distance")
            if (rc_distance != null) {
              rc_distance_0 = rc_distance.getString("0")
            }
          }
        }
      } catch {
        case e: Exception => "" + e
      }
      res += axis + "_" + tollCharge + "_" + rc_distance_0
    }
    res.mkString("&")
  }

  def postTrackOfftime(un: String, begindatetime_post: String, enddatetime_post: String, n_type: String): (String, String) = {
    val params =
      s"""
         |{
         |"compensate": true,
         |"addpoint": 1,
         |"type": "$n_type",
         |"cardtype": "5200001",
         |"offTime": 60,
         |"un": "$un",
         |"unType": "0",
         |"beginDateTime": "$begindatetime_post",
         |"endDateTime": "$enddatetime_post",
         |"ak": "93ec117f7f1b4226b4e537c4802319e9",
         |"hasRate": true,
         |"rectify": true
         |}""".stripMargin
    var offtime = "0.0"
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_TRACK_DELAY_P, params, 3, 2)
      logger.error("》》》》》》》》》》》接口正常调用中》》》》》》》》")
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val data = result.getJSONObject("data")
        if (data != null) {
          val rate = data.getJSONObject("rate")
          if (rate != null) {
            if (rate.getString("offTime") != null) offtime = rate.getString("offTime")
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (n_type, offtime)
  }

  def aggCnt(): Seq[Column] = {
    val agg_cols_str = Seq("cnt", "cnt_delay_0", "cnt_delay_0_10", "cnt_delay_10_20", "cnt_delay_20_30", "cnt_delay_30_60", "cnt_delay_60_120", "cnt_delay_120_300", "cnt_delay_300_600", "cnt_delay_600_1800", "cnt_delay_1800_3600", "cnt_delay_3600_7200", "cnt_delay_7200_10800", "cnt_delay_10800_14400", "cnt_delay_14400_18000", "cnt_delay_18000_21600", "cnt_delay_21600_25200", "cnt_delay_25200_28800", "cnt_delay_28800_m")
    val no_seq_cols = agg_cols_str.map(x => {
      sum(col(x))
    })
    ColumnUtil.renameColumn(no_seq_cols, agg_cols_str)
  }

  def postTrackTimeSlotJson(un: String, begindatetime_post: String, enddatetime_post: String, n_type: String): CntDelay = {
    val params =
      s"""
         |{
         |"compensate": true,
         |"addpoint": 1,
         |"type": "$n_type",
         |"cardtype": "5200001",
         |"offTime": 60,
         |"un": "$un",
         |"unType": "0",
         |"beginDateTime": "$begindatetime_post",
         |"endDateTime": "$enddatetime_post",
         |"ak": "93ec117f7f1b4226b4e537c4802319e9",
         |"hasRate": true,
         |"rectify": true
         |}""".stripMargin
    var cnt: Int = 0
    var cnt_delay_0, cnt_delay_0_10, cnt_delay_10_20, cnt_delay_20_30, cnt_delay_30_60, cnt_delay_60_120, cnt_delay_120_300, cnt_delay_300_600, cnt_delay_600_1800, cnt_delay_1800_3600, cnt_delay_3600_7200, cnt_delay_7200_10800, cnt_delay_10800_14400, cnt_delay_14400_18000, cnt_delay_18000_21600, cnt_delay_21600_25200, cnt_delay_25200_28800, cnt_delay_28800_ = 0
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_TRACK_DELAY_P, params, 3, 2)
      logger.error("》》》》》》》》》》》接口正常调用中》》》》》》》》")
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val data = result.getJSONObject("data")
        if (data != null) {
          val track = data.getJSONArray("track")
          if (track != null && track.size() >= 1) {
            for (i <- 0 until track.size()) {
              if (track.getJSONObject(i).getString("tm") != null && track.getJSONObject(i).getString("xh") != null) {
                cnt += 1
                val tm = track.getJSONObject(i).getString("tm").toLong
                val xh = track.getJSONObject(i).getString("xh").toLong / 1000.0
                val tm_inter = (xh - tm).abs
                tm_inter match {
                  case x if x == 0 => cnt_delay_0 += 1
                  case x if x > 0 && x <= 10 => cnt_delay_0_10 += 1
                  case x if x > 10 && x <= 20 => cnt_delay_10_20 += 1
                  case x if x > 20 && x <= 30 => cnt_delay_20_30 += 1
                  case x if x > 30 && x <= 60 => cnt_delay_30_60 += 1
                  case x if x > 60 && x <= 120 => cnt_delay_60_120 += 1
                  case x if x > 120 && x <= 300 => cnt_delay_120_300 += 1
                  case x if x > 300 && x <= 600 => cnt_delay_300_600 += 1
                  case x if x > 600 && x <= 1800 => cnt_delay_600_1800 += 1
                  case x if x > 1800 && x <= 3600 => cnt_delay_1800_3600 += 1
                  case x if x > 3600 && x <= 7200 => cnt_delay_3600_7200 += 1
                  case x if x > 7200 && x <= 10800 => cnt_delay_7200_10800 += 1
                  case x if x > 10800 && x <= 14400 => cnt_delay_10800_14400 += 1
                  case x if x > 14400 && x <= 18000 => cnt_delay_14400_18000 += 1
                  case x if x > 18000 && x <= 21600 => cnt_delay_18000_21600 += 1
                  case x if x > 21600 && x <= 25200 => cnt_delay_21600_25200 += 1
                  case x if x > 25200 && x <= 28800 => cnt_delay_25200_28800 += 1
                  case x if x > 28800 => cnt_delay_28800_ += 1
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    CntDelay(cnt, cnt_delay_0, cnt_delay_0_10, cnt_delay_10_20, cnt_delay_20_30, cnt_delay_30_60, cnt_delay_60_120, cnt_delay_120_300, cnt_delay_300_600, cnt_delay_600_1800, cnt_delay_1800_3600, cnt_delay_3600_7200, cnt_delay_7200_10800, cnt_delay_10800_14400, cnt_delay_14400_18000, cnt_delay_18000_21600, cnt_delay_21600_25200, cnt_delay_25200_28800, cnt_delay_28800_)
  }

  def postTrackTimeSlot(un: String, begindatetime_post: String, enddatetime_post: String, n_type: String): (Int, String) = {
    val params =
      s"""
         |{
         |"compensate": true,
         |"addpoint": 1,
         |"type": "$n_type",
         |"cardtype": "5200001",
         |"offTime": 60,
         |"un": "$un",
         |"unType": "0",
         |"beginDateTime": "$begindatetime_post",
         |"endDateTime": "$enddatetime_post",
         |"ak": "93ec117f7f1b4226b4e537c4802319e9",
         |"hasRate": true,
         |"rectify": true
         |}""".stripMargin

    var cnt: Int = 0
    val hm = getHashMap()
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_TRACK_DELAY_P, params, 3, 2)
      logger.error("》》》》》》》》》》》接口正常调用中》》》》》》》》")
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val data = result.getJSONObject("data")
        if (data != null) {
          val track = data.getJSONArray("track")
          if (track != null && track.size() >= 1) {
            cnt = track.size()
            for (i <- 0 until track.size()) {
              val tm = track.getJSONObject(i).getString("tm").toLong
              val xh = track.getJSONObject(i).getString("xh").toLong / 1000
              val tm_inter = (xh - tm).abs
              tm_inter match {
                case x if x == 0 => hm.put("[0]", (0, hm.getOrElse("[0]", (0, 0))._2 + 1))
                case x if x > 0 && x <= 10 => hm.put("(0,10]", (1, hm.getOrElse("(0,10]", (0, 0))._2 + 1))
                case x if x > 10 && x <= 20 => hm.put("(10,20]", (2, hm.getOrElse("(10,20]", (0, 0))._2 + 1))
                case x if x > 20 && x <= 30 => hm.put("(20,30]", (3, hm.getOrElse("(20,30]", (0, 0))._2 + 1))
                case x if x > 30 && x <= 60 => hm.put("(30,60]", (4, hm.getOrElse("(30,60]", (0, 0))._2 + 1))
                case x if x > 60 && x <= 120 => hm.put("(60,120]", (5, hm.getOrElse("(60,120]", (0, 0))._2 + 1))
                case x if x > 120 && x <= 300 => hm.put("(120,300]", (6, hm.getOrElse("(120,300]", (0, 0))._2 + 1))
                case x if x > 300 && x <= 600 => hm.put("(300,600]", (7, hm.getOrElse("(300,600]", (0, 0))._2 + 1))
                case x if x > 600 && x <= 1800 => hm.put("(600,1800]", (8, hm.getOrElse("(600,1800]", (0, 0))._2 + 1))
                case x if x > 1800 && x <= 3600 => hm.put("(1800,3600]", (9, hm.getOrElse("(1800,3600]", (0, 0))._2 + 1))
                case x if x > 3600 && x <= 7200 => hm.put("(3600,7200]", (10, hm.getOrElse("(3600,7200]", (0, 0))._2 + 1))
                case x if x > 7200 && x <= 10800 => hm.put("(7200,10800]", (11, hm.getOrElse("(7200,10800]", (0, 0))._2 + 1))
                case x if x > 10800 && x <= 14400 => hm.put("(10800,14400]", (12, hm.getOrElse("(10800,14400]", (0, 0))._2 + 1))
                case x if x > 14400 && x <= 18000 => hm.put("(14400,18000]", (13, hm.getOrElse("(14400,18000]", (0, 0))._2 + 1))
                case x if x > 18000 && x <= 21600 => hm.put("(18000,21600]", (14, hm.getOrElse("(18000,21600]", (0, 0))._2 + 1))
                case x if x > 21600 && x <= 25200 => hm.put("(21600,25200]", (15, hm.getOrElse("(21600,25200]", (0, 0))._2 + 1))
                case x if x > 25200 && x <= 28800 => hm.put("(25200,28800]", (16, hm.getOrElse("(25200,28800]", (0, 0))._2 + 1))
                case x if x > 28800 => hm.put("(28800,-]", (17, hm.getOrElse("(28800,-]", (0, 0))._2 + 1))
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }

    val res = "{" + filterSortMap(hm, Ordering.Int, Ordering.Int).map(l => {
      l._1 + ":" + l._2._2
    }).mkString(";") + "}"

    (cnt, res)
  }

  def getHashMap(): mutable.HashMap[String, (Int, Int)] = {
    val hm = new mutable.HashMap[String, (Int, Int)]()
    val multi_cond = Seq("[0]", "(0,10]", "(10,20]", "(20,30]", "(30,60]", "(60,120]", "(120,300]", "(300,600]", "(600,1800]", "(1800,3600]", "(3600,7200]", "(7200,10800]", "(10800,14400]", "(14400,18000]", "(18000,21600]", "(21600,25200]", "(25200,28800]", "(28800,-]")
    for (i <- 0 until multi_cond.size) {
      hm.put(multi_cond(i), (i, 0))
    }
    hm
  }


  def getJsonCond(): JSONObject = {
    val json_cond = new JSONObject()
    val multi_cond = Seq("[0]", "(0,10]", "(10,20]", "(20,30]", "(30,60]", "(60,120]", "(120,300]", "(300,600]", "(600,1800]", "(1800,3600]", "(3600,7200]", "(7200,10800]", "(10800,14400]", "(14400,18000]", "(18000,21600]", "(21600,25200]", "(25200,28800]", "(28800,-]")
    for (i <- 0 until multi_cond.size) {
      json_cond.put(multi_cond(i), 0)
    }
    json_cond
  }

  /**
   * 自定义排序：map指定排序字段及顺序
   *
   * @param hm
   * @param order1
   * @param order2
   * @return
   */
  def filterSortMap(hm: mutable.HashMap[String, (Int, Int)], order1: Ordering[Int] = Ordering.Int, order2: Ordering[Int] = Ordering.Int): Array[(String, (Int, Int))] = {
    hm.toArray.sortBy(x => (x._2._1, x._2._2))(Ordering.Tuple2(order1, order2))
  }
}
