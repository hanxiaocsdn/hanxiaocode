package com.sf.app.veh

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.HTPP_STAY_POINTS_P
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{formatDiffTime, sdf1, tranTstampToTime, tranTstampToTimeUDF}
import utils.{HttpInvokeUtil, SparkBuilder}

import java.util
import java.util.function.Predicate
import java.util.stream.Collectors
import java.util.{Collections, Comparator}
import scala.collection.mutable.ArrayBuffer

/**
 * @description: EOS-VCMP-CORE：燃油消耗数据需求_V1.0 停车熄火中间表 442913
 * @author 01418539 caojia
 * @date 2022/5/24 14:38
 */
case class TimeInfo(tm: String, bk: String, zx: String, zy: String)

case class FlameOutStaypoint(len: String, parkf_start_time: String, parkf_start_x: String, parkf_start_y: String, parkf_end_time: String, parkf_end_x: String, parkf_end_y: String, parkf_duration: Long)

case class FlameOutInterBack(x1: String, x2: String, x3: String, x4: String, x5: String, x6: String, x7: String, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String, x17: String, x18: String, x19: String, x20: String, x21: String, x22: String, x202: String, x31: String, x32: String, x33: String, x34: String, x35: String, x23: ArrayBuffer[FlameOutStaypoint], x24: String, x25: String)

object VehicleFuelConsumGrdDetail_V1 extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    process1(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def process1(spark: SparkSession, start_day: String, end_day: String) = {
    import spark.implicits._
    val start_sec = start_day + "000000"
    val end_sec = end_day + "235959"
    //所需字段 顺序排列
    val all_task_cols = Seq(col("vehicle_serial"), col("task_id"), col("app_recive_task_tm"), col("actual_reach_tm"),
      col("actual_depart_tm"), col("actual_arrive_tm"), col("first_unload_op_tm"), col("driver_id"),
      col("main_driver_account"), col("driver_name"), col("deputy_driver_account"), col("deputy_driver_name"),
      col("vehicletask_status"), col("actual_run_time"), col("plan_run_time"), col("stop_over_zone_code"), col("cur_zone_type"), col("is_stop"),
      col("src_zone_code"), col("dest_zone_code"), col("serial"), col("inc_day"))

    val o_vms_vehicle = spark.sql(
      s"""
         |select vehicle_code vehicle_serial,max(fuel_type) fuel_type,inc_day
         |from ods_vms.tm_vms_vehicle
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and vehicle_code is not null and trim(vehicle_code) != ''
         |      --and vehicle_code in ('鄂AFE927','琼A56860','冀AKP417','鄂AFD877','苏CKJ506','桂AY1186')
         |      --and vehicle_code in ('湘AM172T','粤SB5183','晋A090HX','沪DD6862','京AD12239','冀HBU507','晋AP9760','湘AL9260','粤BV02W8','粤B1Z76L')
         |group by vehicle_code,inc_day
         |""".stripMargin)
    //    inc_day=T-1 actual_arrive_tm 在T-1当天
    //补齐 空驶 段的数据  赋值 异常空驶
    val win_spc_f = Window.partitionBy("vehicle_serial", "inc_day").orderBy(asc("app_recive_task_tm"))
    val o_grd_task = spark.sql(
      s"""
         |select
         |   task_id,stop_over_zone_code,
         |   vehicle_serial,
         |   src_zone_code,
         |   dest_zone_code,
         |   actual_depart_tm,
         |   actual_arrive_tm,
         |   cast(driver_id as string) driver_id,
         |   driver_name,
         |   '载货任务' vehicletask_status,
         |   cast(actual_run_time as string) actual_run_time,--new min
         |   cast(plan_run_time as string) plan_run_time,--new
         |   app_recive_task_tm,--new 比actual_depart_tm更早 格式相同 yyyy-mm-dd hh:mm:ss
         |   main_driver_account,--new
         |   deputy_driver_account,--new
         |   deputy_driver_name,--new
         |   cast(cur_zone_type as string) cur_zone_type,--new
         |   cast(is_stop as string) is_stop,--new
         |   actual_reach_tm,--new 0620    实际靠车时间(app靠车时间)
         |   first_unload_op_tm,--new 0620 目的地第一票卸车时间  2018-05-01 13:49:00
         |   '' serial,
         |   inc_day
         |from dm_tdsp_dw.grd_new_task_detail
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and vehicle_serial is not null and trim(vehicle_serial) != ''
         |      and actual_depart_tm is not null and trim(actual_depart_tm) != ''
         |      and regexp_replace(substr(actual_arrive_tm, 0,10),'-','') = inc_day
         |      and state = 6 and carrier_type = 0
         |""".stripMargin)
      .select(all_task_cols: _*)

    val o_empty_tasks_df = emptyDriveTasks(spark, start_day, end_day)
      .select(all_task_cols: _*)
    //grd表 和 自定义表 union后的新表
    val grd_empty_tasks = o_grd_task.union(o_empty_tasks_df)
      .na.fill("", Seq("first_unload_op_tm", "driver_id", "driver_name", "cur_zone_type", "is_stop", "src_zone_code", "dest_zone_code"))
      .withColumn("first_unload_op_tm_lag_1", lag('first_unload_op_tm, 1).over(win_spc_f))
      .withColumn("app_recive_task_tm_lead", lead('app_recive_task_tm, 1).over(win_spc_f))
      .withColumn("app_recive_task_tm_tmp", when('first_unload_op_tm_lag_1 > 'app_recive_task_tm, 'first_unload_op_tm_lag_1).otherwise('app_recive_task_tm))
      .withColumn("actual_arrive_tm_tmp", when(trim('first_unload_op_tm) =!= "", 'first_unload_op_tm).otherwise('actual_arrive_tm))
      .withColumn("start_tm", regexp_replace('app_recive_task_tm_tmp, " |-|:", ""))
      .withColumn("end_tm", regexp_replace('actual_arrive_tm_tmp, " |-|:", ""))
      .withColumn("start_end", concat_ws(",", 'start_tm, 'end_tm, lit(start_sec), lit(end_sec)))

    //选择自营车辆  27w 过滤完后6w~
    val mid_vehicle = grd_empty_tasks.join(broadcast(o_vms_vehicle), Seq("vehicle_serial", "inc_day"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val cond_col = split(regexp_replace('tmp, "\\(|\\)", ""), ",")
    //筛选24h的切分时间间隔
    val step1_vehicle = mid_vehicle.select("vehicle_serial", "start_end", "inc_day")
      .groupBy("vehicle_serial", "inc_day")
      .agg(
        concat_ws(",", collect_set('start_end)) as "start_end"
      )
      .repartition(300)
      .map(row => {
        val vehicle_serial = row.getAs[String]("vehicle_serial")
        val start_end = row.getAs[String]("start_end")
        val inc_day = row.getAs[String]("inc_day")
        //对于跨天的运行任务,保留跨天全时段
        val arr_tmp = start_end.split(",").toSet.toSeq.sortWith(_.compareTo(_) < 0)
        var arr: Seq[String] = arr_tmp
        if (arr_tmp(0) != inc_day.concat("000000")) arr = arr_tmp.filter(_ != inc_day.concat("000000")).sortWith(_.compareTo(_) < 0)
        val ab = new ArrayBuffer[(String, String)]()
        for (i <- 0 until arr.length - 1) {
          ab.append((arr(i), arr(i + 1)))
        }
        val res = ab.mkString("&")
        (vehicle_serial, res, inc_day)
      }).toDF("vehicle_serial", "res", "inc_day")
      .withColumn("tmp", explode(split('res, "&")))
      .withColumn("start_tm", cond_col(0))
      .withColumn("end_tm", cond_col(1))
      .select("vehicle_serial", "start_tm", "end_tm", "inc_day")

    //补齐 空驶 段的数据  赋值 异常空驶
    val win_spc = Window.partitionBy("vehicle_serial").orderBy(asc("start_tm"))
    //车辆信息和区域名称表
    val vehicle_df = vehicleInfo(spark, start_day, end_day)

    //需要保留的中间表
    val step2_vehicle_mid = step1_vehicle.join(broadcast(mid_vehicle), Seq("vehicle_serial", "start_tm", "end_tm", "inc_day"), "left")
      .withColumn("vehicletask_status", when('vehicletask_status.isNull, "异常空驶").otherwise('vehicletask_status))
      .withColumn("driver_name_lag", lag('driver_name, 1).over(win_spc))
      .withColumn("driver_name_lead", lead('driver_name, 1).over(win_spc))
      .withColumn("driver_id_lag", lag('driver_id, 1).over(win_spc))
      .withColumn("driver_id_lead", lead('driver_id, 1).over(win_spc))
      .withColumn("src_zone_code_lead", lead('src_zone_code, 1).over(win_spc))
      .withColumn("dest_zone_code_lag", lag('dest_zone_code, 1).over(win_spc))
      .withColumn("stop_over_zone_code_lag", lag('stop_over_zone_code, 1).over(win_spc))
      .withColumn("stop_over_zone_code_lead", lead('stop_over_zone_code, 1).over(win_spc))
      .withColumn("driver_name", when('driver_name.isNull && 'driver_name_lag.isNull, 'driver_name_lead).otherwise(coalesce('driver_name, 'driver_name_lag)))
      .withColumn("driver_id", when('driver_id.isNull && 'driver_id_lag.isNull, 'driver_id_lead).otherwise(coalesce('driver_id, 'driver_id_lag)))
      .withColumn("stop_over_zone_code", when('stop_over_zone_code.isNull && 'stop_over_zone_code_lag.isNull, 'stop_over_zone_code_lead).otherwise(coalesce('stop_over_zone_code, 'stop_over_zone_code_lag)))
      .withColumn("src_zone_code_t", coalesce('src_zone_code, 'dest_zone_code_lag))
      .withColumn("dest_zone_code_t", coalesce('dest_zone_code, 'src_zone_code_lead))
      .withColumn("main_driver_account_lag", lag('main_driver_account, 1).over(win_spc))
      .withColumn("main_driver_account_lead", lead('main_driver_account, 1).over(win_spc))
      .withColumn("main_driver_account", when('main_driver_account.isNull && 'main_driver_account_lag.isNull, 'main_driver_account_lead).otherwise(coalesce('main_driver_account, 'main_driver_account_lag)))
      .withColumn("main_driver_account_lag", lag('main_driver_account, 1).over(win_spc))
      .withColumn("main_driver_account_lead", lead('main_driver_account, 1).over(win_spc))
      .withColumn("main_driver_account", when('main_driver_account.isNull && 'main_driver_account_lag.isNull, 'main_driver_account_lead).otherwise(coalesce('main_driver_account, 'main_driver_account_lag)))
      .withColumn("deputy_driver_account_lag", lag('deputy_driver_account, 1).over(win_spc))
      .withColumn("deputy_driver_account_lead", lead('deputy_driver_account, 1).over(win_spc))
      .withColumn("deputy_driver_account", when('deputy_driver_account.isNull && 'deputy_driver_account_lag.isNull, 'deputy_driver_account_lead).otherwise(coalesce('deputy_driver_account, 'deputy_driver_account_lag)))
      .withColumn("deputy_driver_name_lag", lag('deputy_driver_name, 1).over(win_spc))
      .withColumn("deputy_driver_name_lead", lead('deputy_driver_name, 1).over(win_spc))
      .withColumn("deputy_driver_name", when('deputy_driver_name.isNull && 'deputy_driver_name_lag.isNull, 'deputy_driver_name_lead).otherwise(coalesce('deputy_driver_name, 'deputy_driver_name_lag)))
      .withColumn("fuel_type_lag", lag('fuel_type, 1).over(win_spc))
      .withColumn("fuel_type_lead", lead('fuel_type, 1).over(win_spc))
      .withColumn("fuel_type", when('fuel_type.isNull && 'fuel_type_lag.isNull, 'fuel_type_lead).otherwise(coalesce('fuel_type, 'fuel_type_lag)))
      .withColumn("app_recive_task_tm", when('app_recive_task_tm.isNull || trim('app_recive_task_tm) === "", formatDiffTime('start_tm)).otherwise('app_recive_task_tm))
      .withColumn("actual_depart_tm", coalesce('actual_depart_tm, 'app_recive_task_tm))
      .withColumn("actual_arrive_tm", when('actual_arrive_tm.isNull || trim('actual_arrive_tm) === "", formatDiffTime('end_tm)).otherwise('actual_arrive_tm))
      .withColumn("first_unload_op_tm_lag", lag('first_unload_op_tm, 1).over(win_spc))
      .na.fill("", Seq("first_unload_op_tm", "first_unload_op_tm_lag", "app_recive_task_tm", "actual_arrive_tm"))
      .withColumn("begindatetime", when(trim('first_unload_op_tm_lag) =!= "" && 'first_unload_op_tm_lag.isNotNull && 'app_recive_task_tm < 'first_unload_op_tm_lag, 'first_unload_op_tm_lag).otherwise('app_recive_task_tm))
      .withColumn("enddatetime", when(trim('first_unload_op_tm) =!= "" && 'first_unload_op_tm.isNotNull, 'first_unload_op_tm).otherwise('actual_arrive_tm))
      .na.fill("", Seq("begindatetime", "enddatetime"))
      .join(vehicle_df, Seq("vehicle_serial", "inc_day"), "left")
      //异常空驶 5个司机信息字段置空
      .withColumn("driver_id", when('vehicletask_status === "异常空驶", "").otherwise('driver_id))
      .withColumn("main_driver_account", when('vehicletask_status === "异常空驶", "").otherwise('main_driver_account))
      .withColumn("driver_name", when('vehicletask_status === "异常空驶", "").otherwise('driver_name))
      .withColumn("deputy_driver_account", when('vehicletask_status === "异常空驶", "").otherwise('deputy_driver_account))
      .withColumn("deputy_driver_name", when('vehicletask_status === "异常空驶", "").otherwise('deputy_driver_name))
      .select("vehicle_serial", "task_id",
        "app_recive_task_tm", "actual_reach_tm", "actual_depart_tm", "actual_arrive_tm", "first_unload_op_tm", "begindatetime", "enddatetime",
        "driver_id", "main_driver_account", "driver_name", "deputy_driver_account", "deputy_driver_name",
        "stop_over_zone_code", "src_zone_code_t", "dest_zone_code_t", "vehicletask_status",
        "actual_run_time", "cur_zone_type", "is_stop", "plan_run_time", "serial",
        "motorcade_code", "motorcade_name", "dept_code", "area_code", "area_name", "fuel_type",
        "inc_day").repartition(15)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    writeToHive(spark, step2_vehicle_mid, Seq("inc_day"), "dm_gis.dwd_vehicle_fuel_consum_flame_out_dtl")

    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "442913", "【EOS-VCMP-CORE】燃油V1熄火时长", "根据车牌号及时间点获取停留时间段信息", HTPP_STAY_POINTS_P, "b61f6c427934416dbc3248dbefef5eb0", step2_vehicle_mid.count(), 15)
    //停车熄火逻辑
    val step2_vehicle = step2_vehicle_mid
      .map(row => {
        val vehicle_serial = row.getAs[String]("vehicle_serial")
        val task_id = row.getAs[String]("task_id")
        val app_recive_task_tm = row.getAs[String]("app_recive_task_tm")
        val actual_reach_tm = row.getAs[String]("actual_reach_tm")
        val actual_depart_tm = row.getAs[String]("actual_depart_tm")
        val actual_arrive_tm = row.getAs[String]("actual_arrive_tm")
        val first_unload_op_tm = row.getAs[String]("first_unload_op_tm")
        var begindatetime = row.getAs[String]("begindatetime").replaceAll(" |-|:", "")
        var enddatetime = row.getAs[String]("enddatetime").replaceAll(" |-|:", "")
        val driver_id = row.getAs[String]("driver_id")
        val main_driver_account = row.getAs[String]("main_driver_account")
        val driver_name = row.getAs[String]("driver_name")
        val deputy_driver_account = row.getAs[String]("deputy_driver_account")
        val deputy_driver_name = row.getAs[String]("deputy_driver_name")
        val stop_over_zone_code = row.getAs[String]("stop_over_zone_code")
        val src_zone_code = row.getAs[String]("src_zone_code_t")
        val dest_zone_code = row.getAs[String]("dest_zone_code_t")
        val vehicletask_status = row.getAs[String]("vehicletask_status")
        val actual_run_time = row.getAs[String]("actual_run_time")
        val cur_zone_type = row.getAs[String]("cur_zone_type")
        val is_stop = row.getAs[String]("is_stop")
        val plan_run_time = row.getAs[String]("plan_run_time")
        val serial = row.getAs[String]("serial")
        val motorcade_code = row.getAs[String]("motorcade_code")
        val motorcade_name = row.getAs[String]("motorcade_name")
        val dept_code = row.getAs[String]("dept_code")
        val area_code = row.getAs[String]("area_code")
        val area_name = row.getAs[String]("area_name")
        val fuel_type = row.getAs[String]("fuel_type")
        val inc_day = row.getAs[String]("inc_day")
        //存放多个停留点的 停车熄火时间
        val flame = new ArrayBuffer[FlameOutStaypoint]()

        val params =
          s"""
             |{
             |"ak": "b61f6c427934416dbc3248dbefef5eb0",
             |"addpoint": 0,
             |"compensate": 0,
             |"beginDateTime": "$begindatetime",
             |"endDateTime": "$enddatetime",
             |"stayDuration": "600",
             |"stayRadius": "50",
             |"type": "408",
             |"un": "$vehicle_serial",
             |"unType": "0",
             |"opt": "all"
             |}
      """.stripMargin

        //bk 全部为 1 的 tm 值
        var info_str = ""
        var len = "0"

        try {
          if (begindatetime.trim != "" && enddatetime.trim != "") {
            info_str = HttpInvokeUtil.sendPost(HTPP_STAY_POINTS_P, params, 3, 2)
            //            logger.info(s"停留时间600,post请求返回的json为：" + info_str)
          }
          val info_resp_json = JSON.parseObject(info_str)
          val json_p1 = info_resp_json.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          val json_p2 = info_resp_json.getJSONObject("result").getJSONObject("data").getJSONArray("stayPoints")
          len = info_resp_json.getJSONObject("result").getJSONObject("data").getString("len")

          val min_tm = tranTstampToTime(json_p1.getJSONObject(0).getString("tm"))
          val max_tm = tranTstampToTime(json_p1.getJSONObject(json_p1.size() - 1).getString("tm"))

          if (begindatetime.contains("000000") && min_tm.toLong > begindatetime.toLong) begindatetime = min_tm
          if (enddatetime.contains("235959") && max_tm.toLong < enddatetime.toLong) enddatetime = max_tm
          //缓存tack行车轨迹的 tm -> bk zx zy
          val tm_bk_map = new util.HashMap[String, (String, String, String)]()
          //只存放时间 tm
          val tm_bk_arr = new util.ArrayList[String]()

          for (i <- 0 until json_p1.size()) {
            val tm = json_p1.getJSONObject(i).getString("tm")
            val bk = json_p1.getJSONObject(i).getString("bk")
            val zx = json_p1.getJSONObject(i).getString("zx")
            val zy = json_p1.getJSONObject(i).getString("zy")
            tm_bk_arr.add(tm)
            tm_bk_map.put(tm, (bk, zx, zy))
          }
          //时间顺序进行排序，实际是有序
          Collections.sort(tm_bk_arr)
          //存放staypoints返回的数据
          for (i <- 0 until json_p2.size()) {
            //初始化变量
            var parkf_duration: Long = 0
            var parkf_start_time, parkf_start_x, parkf_start_y, parkf_end_time, parkf_end_x, parkf_end_y = ""

            val json_for = json_p2.getJSONObject(i)
            val startTime = json_for.getString("startTime")
            val endTime = json_for.getString("endTime")

            //拿到指定start end时间之间的区间index
            val start_index: Int = tm_bk_arr.indexOf(startTime)
            val end_index: Int = tm_bk_arr.indexOf(endTime)
            //存放以bk（0 1）为主键的时间及经纬度信息 bk ->(tm zx zy)
            val bk_map = new util.HashMap[String, (String, String, String)]()

            val bk_info: util.List[TimeInfo] = new util.ArrayList[TimeInfo]

            if (tm_bk_map.get(tm_bk_arr.get(end_index))._1 == "1") {
              bk_info.add(TimeInfo(tm_bk_arr.get(end_index), "1", tm_bk_map.get(tm_bk_arr.get(end_index))._2, tm_bk_map.get(tm_bk_arr.get(end_index))._3))
              var flag = true
              for (i <- (start_index to end_index - 1).reverse if flag) {
                if (tm_bk_map.get(tm_bk_arr.get(i))._1 != "1") {
                  bk_info.add(TimeInfo(tm_bk_arr.get(i + 1), "1", tm_bk_map.get(tm_bk_arr.get(i + 1))._2, tm_bk_map.get(tm_bk_arr.get(i + 1))._3))
                  flag = false
                }
                if (i == start_index) bk_info.add(TimeInfo(tm_bk_arr.get(i), "1", tm_bk_map.get(tm_bk_arr.get(i))._2, tm_bk_map.get(tm_bk_arr.get(i))._3))
              }
            }
            for (j <- start_index to end_index) {
              val tm_bk = tm_bk_map.get(tm_bk_arr.get(j))
              val bk = tm_bk._1

              if ("1".equals(bk) && !bk_map.containsKey("1")) {
                bk_map.put(bk, (tm_bk_arr.get(j), tm_bk._2, tm_bk._3))
              } else if (!"1".equals(bk) && bk_map.containsKey("1") && !bk_map.containsKey("0")) {
                bk_map.put("0", (tm_bk_arr.get(j), tm_bk._2, tm_bk._3))
                bk_info.add(TimeInfo(bk_map.get("1")._1, "1", bk_map.get("1")._2, bk_map.get("1")._3))
                bk_info.add(TimeInfo(bk_map.get("0")._1, "0", bk_map.get("0")._2, bk_map.get("0")._3))
                bk_map.clear()
              }
            }
            Collections.sort(bk_info, new Comparator[TimeInfo]() {
              def compare(o1: TimeInfo, o2: TimeInfo): Int = (o1.tm.toLong - o2.tm.toLong).asInstanceOf[Int]
            })
            if (bk_info.size() != 0) {
              for (i <- 0 until bk_info.size() if i % 2 == 0) {
                val tm_filter_cond = new Predicate[String] {
                  override def test(t: String): Boolean = t.toLong >= bk_info.get(i).tm.toLong && t.toLong <= bk_info.get(i + 1).tm.toLong
                }
                val tm_inter_list = tm_bk_arr.stream().filter(tm_filter_cond).collect(Collectors.toList[String])
                Collections.sort(tm_inter_list)
                for (j <- 0 until tm_inter_list.size() - 1) {
                  if (tm_inter_list.get(j + 1).toLong - tm_inter_list.get(j).toLong > 10 * 60) {
                    //                    println("第" + j + "段时间范围为：" + tm_inter_list.get(j) + "--" + tm_inter_list.get(j + 1) + "，间隔时长为：" + (tm_inter_list.get(j + 1).toLong - tm_inter_list.get(j).toLong))
                    val info_j = TimeInfo(tm_inter_list.get(j), tm_bk_map.get(tm_inter_list.get(j))._1, tm_bk_map.get(tm_inter_list.get(j))._2, tm_bk_map.get(tm_inter_list.get(j))._3)
                    val info_j_1 = TimeInfo(tm_inter_list.get(j + 1), tm_bk_map.get(tm_inter_list.get(j + 1))._1, tm_bk_map.get(tm_inter_list.get(j + 1))._2, tm_bk_map.get(tm_inter_list.get(j + 1))._3)
                    if (bk_info.contains(info_j)) bk_info.remove(info_j) else bk_info.add(info_j)
                    if (bk_info.contains(info_j_1)) bk_info.remove(info_j_1) else bk_info.add(info_j_1)
                  }
                }
              }
            }
            Collections.sort(bk_info, new Comparator[TimeInfo]() {
              def compare(o1: TimeInfo, o2: TimeInfo): Int = (o1.tm.toLong - o2.tm.toLong).asInstanceOf[Int]
            })
            if (bk_info.size() != 0) {
              for (i <- 0 until bk_info.size() if i % 2 == 0) {
                parkf_duration = bk_info.get(i + 1).tm.toLong - bk_info.get(i).tm.toLong
                parkf_start_time = bk_info.get(i).tm
                parkf_start_x = bk_info.get(i).zx
                parkf_start_y = bk_info.get(i).zy
                parkf_end_time = bk_info.get(i + 1).tm
                parkf_end_x = bk_info.get(i + 1).zx
                parkf_end_y = bk_info.get(i + 1).zy
                flame += FlameOutStaypoint(len, parkf_start_time, parkf_start_x, parkf_start_y, parkf_end_time, parkf_end_x, parkf_end_y, parkf_duration)
              }
            }
          }
        } catch {
          case e: Exception => logger.error(s"$begindatetime and $enddatetime and $vehicle_serial 轨迹点无返回" + e.getMessage)
        }
        FlameOutInterBack(vehicle_serial, task_id, app_recive_task_tm, actual_reach_tm, actual_depart_tm, actual_arrive_tm, first_unload_op_tm, begindatetime, enddatetime,
          driver_id, main_driver_account, driver_name, deputy_driver_account, deputy_driver_name, stop_over_zone_code, src_zone_code, dest_zone_code, vehicletask_status,
          actual_run_time, cur_zone_type, is_stop, plan_run_time, serial, motorcade_code, motorcade_name, dept_code, area_code, area_name, flame, fuel_type, inc_day)
      }).toDF("vehicle_serial", "task_id", "app_recive_task_tm", "actual_reach_tm", "actual_depart_tm", "actual_arrive_tm", "first_unload_op_tm", "begindatetime", "enddatetime",
      "driver_id", "main_driver_account", "driver_name", "deputy_driver_account", "deputy_driver_name", "stop_over_zone_code", "src_zone_code", "dest_zone_code", "vehicletask_status",
      "actual_run_time", "cur_zone_type", " is_stop", "plan_run_time", "serial", "motorcade_code", "motorcade_name", "dept_code", "area_code", "area_name",
      "flame_arr", "fuel_type", "inc_day")
      .withColumn("flame", explode($"flame_arr"))
      .withColumn("len", $"flame"("len"))
      .withColumn("parkf_start_time", $"flame"("parkf_start_time"))
      .withColumn("parkf_start_x", $"flame"("parkf_start_x"))
      .withColumn("parkf_start_y", $"flame"("parkf_start_y"))
      .withColumn("parkf_end_time", $"flame"("parkf_end_time"))
      .withColumn("parkf_end_x", $"flame"("parkf_end_x"))
      .withColumn("parkf_end_y", $"flame"("parkf_end_y"))
      .withColumn("parkf_duration", $"flame"("parkf_duration"))
      .withColumn("begindatetime", formatDiffTime('begindatetime))
      .withColumn("enddatetime", formatDiffTime('enddatetime))
      .withColumn("parkf_start_time", tranTstampToTimeUDF(sdf1)('parkf_start_time))
      .withColumn("parkf_end_time", tranTstampToTimeUDF(sdf1)('parkf_end_time))
      .na.fill("", Seq("parkf_start_x", "parkf_start_y", "parkf_end_x", "parkf_end_y", "stop_over_zone_code"))
      .select("vehicle_serial", "task_id", "app_recive_task_tm", "actual_reach_tm", "actual_depart_tm", "actual_arrive_tm", "first_unload_op_tm", "begindatetime", "enddatetime",
        "driver_id", "main_driver_account", "driver_name", "deputy_driver_account", "deputy_driver_name", "stop_over_zone_code", "src_zone_code", "dest_zone_code", "vehicletask_status",
        "actual_run_time", "cur_zone_type", " is_stop", "plan_run_time",
        "parkf_start_time", "parkf_start_x", "parkf_start_y", "parkf_end_time", "parkf_end_x", "parkf_end_y", "parkf_duration", "serial",
        "motorcade_code", "motorcade_name", "dept_code", "area_code", "area_name", "fuel_type", "inc_day")
      .filter('parkf_duration > 0 && 'len.cast("double") >= 1000)
      .persist()
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)
    writeToHive(spark, step2_vehicle, Seq("inc_day"), "dm_gis.dwd_vehicle_fuel_consum_flame_out_step_dtl")

    step2_vehicle_mid.unpersist()
  }

  def emptyDriveTasks(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    import spark.implicits._
    //ods_shiva_ground.tt_customize_task  	2w0434
    val o_task_t = spark.sql(
      s"""
         |select serial,
         |       vehicle_code vehicle_serial,
         |       task_id,
         |       '' driver_id,
         |       user_name main_driver_account,
         |       '' driver_name,
         |       copilot deputy_driver_account,
         |       copilot_name deputy_driver_name,
         |       '自定义任务' vehicletask_status,
         |       '' actual_run_time,
         |       '' plan_run_time,
         |       '' cur_zone_type,
         |       '' is_stop,
         |       inc_day
         |from ods_shiva_ground.tt_customize_task
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and serial is not null and trim(serial) != ''
         |      and vehicle_code is not null and trim(vehicle_code) != ''
         |      --and vehicle_code in ('湘AM172T','粤SB5183','晋A090HX','沪DD6862','京AD12239','冀HBU507','晋AP9760','湘AL9260','粤BV02W8','粤B1Z76L')
         |""".stripMargin)

    //获取自营车辆的司机信息
    val o_self_driver = spark.sql(
      s"""
         |select  if(substr(emp_code,1,2)='00',substr(emp_code,3),emp_code) emp_code,
         |        name driver_name,
         |        name deputy_driver_name
         |from dwd_o.dwd_tp_grd_driver_dtl_df
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and emp_code is not null and trim(emp_code) != ''
         |group by emp_code,name
         |""".stripMargin)

    val o_task = o_task_t.drop("driver_name", "deputy_driver_name")
      .join(o_self_driver.select("emp_code", "driver_name").withColumnRenamed("emp_code", "main_driver_account"), Seq("main_driver_account"), "left")
      .join(o_self_driver.select("emp_code", "deputy_driver_name").withColumnRenamed("emp_code", "deputy_driver_account"), Seq("deputy_driver_account"), "left")

    //ods_shiva_ground.tt_customize_task_log  6w4847
    val o_task_log = spark.sql(
      s"""
         |select
         |       serial,
         |       max(app_recive_task_tm) app_recive_task_tm,
         |       max(actual_reach_tm) actual_reach_tm,
         |       max(actual_depart_tm) actual_depart_tm,
         |       max(actual_arrive_tm) actual_arrive_tm,
         |       max(first_unload_op_tm) first_unload_op_tm,
         |       max(src_zone_code) src_zone_code,
         |       max(dest_zone_code) dest_zone_code,
         |       inc_day
         |from
         |(select serial,
         |       task_operate_type,
         |       created_date_time,
         |       pass_zone_dept_code,
         |       if(task_operate_type=0,created_date_time,null) app_recive_task_tm,
         |       if(task_operate_type=0,created_date_time,null) actual_reach_tm,
         |       if(task_operate_type=1,created_date_time,null) actual_depart_tm,
         |       if(task_operate_type=2,created_date_time,null) actual_arrive_tm,
         |       if(task_operate_type=2,created_date_time,null) first_unload_op_tm,
         |       if(task_operate_type=1,pass_zone_dept_code,null) src_zone_code,
         |       if(task_operate_type=2,pass_zone_dept_code,null) dest_zone_code,
         |       inc_day
         |from ods_shiva_ground.tt_customize_task_log
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and task_operate_type in (0,1,2)
         |      and serial is not null and trim(serial) != ''
         |	  ) a
         |group by serial,inc_day
         |""".stripMargin)

    val empty_tasks_df = o_task.join(o_task_log, Seq("serial", "inc_day"))
      .withColumn("stop_over_zone_code", concat_ws(",", 'src_zone_code, 'dest_zone_code))

    empty_tasks_df
  }

  def vehicleInfo(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    val o_info = spark.sql(
      s"""
         |select vehicle_code vehicle_serial,
         |        max(motorcade_code) motorcade_code,
         |        max(motorcade_name) motorcade_name,
         |        max(dept_code) dept_code,
         |        inc_day
         |from dm_tdsp_dw.grd_vehicle_info_dtl
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and vehicle_code is not null and trim(vehicle_code) != ''
         |group by vehicle_code,inc_day
         |""".stripMargin)

    val o_depart = spark.sql(
      s"""
         |select dept_code,area_code,area_name
         |from dim.dim_department
         |where dept_code is not null and trim(dept_code) != ''
         |""".stripMargin)

    o_info.join(o_depart, Seq("dept_code"), "left")

  }

  def repeatTrack(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    spark.sql(
      s"""
         |select un vehicle_serial,inc_day
         |from dm_gis.track_quality_detail
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and un is not null and trim(un) != ''
         |      and ak = '314'
         |      and is_re_upload = '-1'
         |group by un,inc_day
         |""".stripMargin)
  }

}
