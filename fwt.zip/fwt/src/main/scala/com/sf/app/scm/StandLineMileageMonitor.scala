package com.sf.app.scm

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.primaryKeyEncrypt
import utils.JDBCUtils.{getDevMysqlConnect, upsertBatch}
import utils.{ColumnUtil, DateUtil, SparkBuilder}

import java.sql.{Connection, PreparedStatement}
import scala.collection.mutable.ListBuffer

/**
 * @description: 455594（已下线 20230306）
 * @author 01418539 caojia
 * @date 2022/7/5 14:05
 */
object StandLineMileageMonitor extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val inc_day = args(0)
    processStatistics(spark, inc_day)
    upsertMysql(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processStatistics(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    //往前推36天(20220601~20220703)
    val days_36_bef = DateUtil.getdaysBefore(inc_day, -35, "yyyyMMdd")

    //表a--1338198 任务里程确认表
    val o_dist_dtl = spark.sql(
      s"""
         |select * from dm_gis.eta_std_line_nostop
         |where inc_day = '$inc_day'
         |      and task_inc_day >= '$days_36_bef' and task_inc_day <= '$inc_day'
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("task_id").orderBy('inc_day.desc)))
      .filter('num === 1).drop("num")

    //表b--90659 申诉明细内容 create_time 2022-04-14 14:55:45
    val o_appeal_dtl = spark.sql(
      s"""
         |select * from dm_gis.accrual_dist_appeal
         |where inc_day = '$inc_day'
         |      and regexp_replace(substr(create_time, 0,10),'-','') >= '$days_36_bef'
         |      and regexp_replace(substr(create_time, 0,10),'-','') <= '$inc_day'
         |""".stripMargin)
      .withColumnRenamed("id", "appeal_id")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val appea_step1 = o_appeal_dtl.drop("raw_accrual_dist")
      .withColumn("num", row_number().over(Window.partitionBy("task_id").orderBy('update_time.desc)))
      .filter('num === 1).drop("num")

    val appea_step2 = o_appeal_dtl.select("task_id", "raw_accrual_dist", "update_time", "inc_day")
      .withColumn("num", row_number().over(Window.partitionBy("task_id").orderBy('update_time.asc)))
      .filter('num === 1).drop("update_time", "num")

    val o_appeal_dtl_t = appea_step1.join(appea_step2, Seq("task_id", "inc_day"), "left")
      .drop("task_area_code")
    //表c--90689 审核记录表 create_time 2022-04-14 14:55:45
    val o_verify_log = spark.sql(
      s"""
         |select * from dm_gis.accrual_dist_appeal_result
         |where inc_day = '$inc_day'
         |      and regexp_replace(substr(create_time, 0,10),'-','') >= '$days_36_bef'
         |      and regexp_replace(substr(create_time, 0,10),'-','') <= '$inc_day'
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("appeal_id").orderBy('update_time.desc)))
      .filter('num === 1).drop("num", "id", "create_time", "update_time")

    //结果表1 的字段信息数据
    val res_t = spark.sql("""select * from dm_gis.gis_eta_stdline_accrual_daily limit 1""")
    val res_cols = res_t.schema.map(_.name).map(col)
    //逻辑处理
    val part1_res = o_dist_dtl.join(o_appeal_dtl_t, Seq("task_id", "inc_day"), "left")
      .join(o_verify_log, Seq("appeal_id", "inc_day"), "left")
      .withColumn("conduct_type_new", when('conduct_type === "1", "执行").otherwise("未执行"))
      .withColumn("raw_accrual_dist", when('raw_accrual_dist.isNull || trim('raw_accrual_dist) === "", 'accrual_dist).otherwise('raw_accrual_dist.cast("double") * 1000))
      .withColumn("id", primaryKeyEncrypt('task_area_code, 'task_id, 'task_inc_day, lit(""), lit(""), lit(""), 'inc_day))
      .select(res_cols: _*)

    writeToHive(spark, part1_res, Seq("inc_day"), "dm_gis.gis_eta_stdline_accrual_daily")

    //获取地址编码信息表
    val o_area_code_map = spark.sql("""select * from dm_gis.dim_area_code_mapping""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val area_code = o_area_code_map.select("area_code", "area_name")
      .union(o_area_code_map.select("express_code", "area_name").withColumnRenamed("express_code", "area_code"))
      .withColumnRenamed("area_code", "task_area_code")
      .withColumnRenamed("area_name", "task_area_name")
      .select("task_area_code", "task_area_name")

    val accrual_dist_type_cond = when('accrual_dist_type === "1", "轨迹").when('accrual_dist_type === "2", "规划").otherwise("轨迹&规划")

    //结果表1 的字段信息数据
    val res_t2 = spark.sql("""select * from dm_gis.gis_eta_stdline_accrual_daily_result limit 1""")
    val res2_cols = res_t2.schema.map(_.name).map(col)
    val agg_cols = aggSumCols()

    val part2_res = part1_res.join(area_code, Seq("task_area_code"), "left")
      .withColumn("accrual_dist_type_new", accrual_dist_type_cond)
      .withColumn("task_id_num", lit(1))
      .withColumn("log_dist_error_num", when('log_dist.cast("double") > 3000, 1).otherwise(0))
      .withColumn("log_dist_sum", when('log_dist.cast("double") <= 3000, 'log_dist).otherwise(0))
      .withColumn("raw_accrual_dist_sum", when('log_dist.cast("double") <= 3000, 'raw_accrual_dist).otherwise(0))
      .withColumn("accrual_dist_sum", when('log_dist.cast("double") <= 3000, 'accrual_dist).otherwise(0))
      .withColumn("confirmed_num", when('confirmed === "1", 1).otherwise(0))
      .withColumn("appeal_num", when('appeal_login_name.isNotNull || trim('appeal_login_name) =!= "", 1).otherwise(0))
      .withColumn("non_audit_num", when(('appeal_login_name.isNotNull || trim('appeal_login_name) =!= "") && 'state =!= 2, 1).otherwise(0))
      .withColumn("audited_num", when('state =!= 2, 1).otherwise(0))
      .withColumn("gj_task_num", when(trim('accrual_dist_type_new) === "轨迹", 1).otherwise(0))
      .withColumn("gj_conduct_num", when(trim('accrual_dist_type_new) === "轨迹" && trim('conduct_type_new) === "执行", 1).otherwise(0))
      .withColumn("gh_task_num", when(trim('accrual_dist_type_new) === "规划", 1).otherwise(0))
      .withColumn("gh_conduct_num", when(trim('accrual_dist_type_new) === "规划" && trim('conduct_type_new) === "执行", 1).otherwise(0))
      .withColumn("mix_task_num", when(trim('accrual_dist_type_new) === "轨迹&规划", 1).otherwise(0))
      .withColumn("mix_conduct_num", when(trim('accrual_dist_type_new) === "轨迹&规划" && trim('conduct_type_new) === "执行", 1).otherwise(0))
      .groupBy("task_area_code", "task_area_name", "carrier_name", "task_inc_day", "line_code", "conduct_type_new", "inc_day")
      .agg(agg_cols.head, agg_cols.tail: _*)
      .withColumn("id", primaryKeyEncrypt('task_area_code, 'carrier_name, 'task_inc_day, 'line_code, 'conduct_type_new, 'inc_day, lit("")))
      .select(res2_cols: _*)
    writeToHive(spark, part2_res, Seq("inc_day"), "dm_gis.gis_eta_stdline_accrual_daily_result")
    o_appeal_dtl.unpersist()
    o_area_code_map.unpersist()
  }

  def aggSumCols(): Seq[Column] = {
    val cols_str = Seq("task_id_num", "log_dist_error_num", "log_dist_sum", "raw_accrual_dist_sum", "accrual_dist_sum", "confirmed_num", "appeal_num", "non_audit_num", "audited_num", "gj_task_num", "gj_conduct_num", "gh_task_num", "gh_conduct_num", "mix_task_num", "mix_conduct_num")
    val sum_cols = cols_str.map(sum(_))
    ColumnUtil.renameColumn(sum_cols, cols_str)
  }

  def upsertMysql(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    //往前推36天(20220604~20220703)
    val days_36_bef = DateUtil.getdaysBefore(inc_day, -35, "yyyyMMdd")
    //加载数据
    val o_dataDf = spark.sql(
      s"""
         |select
         |*
         |from dm_gis.gis_eta_stdline_accrual_daily_result
         |where inc_day>='$days_36_bef' and inc_day <= '$inc_day'
         |""".stripMargin)
      .na.fill("")
      .na.fill(0)
      .na.fill(0.0)
      .withColumn("num", row_number().over(Window.partitionBy("task_area_code", "task_area_name", "carrier_name", "task_inc_day", "line_code", "conduct_type_new").orderBy(desc("inc_day"))))
      .filter('num === 1).drop("num")
    //全量未分区表中
    writeToHiveNoP(spark, o_dataDf, "gis_eta_stdline_accrual_daily_result_tmp")

    //将mysql中原表数据分区删除 支持重跑
    val conn: Connection = getDevMysqlConnect()
    try {
      val querySql = s"select * from GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT WHERE SUBSTRING(STATDATE,1,8) >= '19700101' and SUBSTRING(STATDATE,1,8) <= '99999999' limit 1"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT where SUBSTRING(STATDATE,1,8) >= '19700101' and SUBSTRING(STATDATE,1,8) <= '99999999'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 gis_oms_pns.GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT 中全量数据时出现错误", ex)
        throw ex
    }
    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")

    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        upsertBatch(getDevMysqlConnect(), "GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT", fields, blank_places, listRows) //执行批量插入数据
      }
    })

    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT where SUBSTRING(STATDATE,1,8) >= '$days_36_bef' and SUBSTRING( STATDATE,1,8) <= '$inc_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 gis_oms_pns.GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT 中 近一个月内 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 gis_oms_pns.GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT 中 近一个月内最新 数据时出现错误", ex)
        throw ex
    }
  }

}
