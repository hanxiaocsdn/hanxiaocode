package com.sf.app.navi

import com.sf.app.navi.CreateMysqlTable.getMysqlcreateTable
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.JDBCUtils.{getFJTDevMysqlConnect, upsertBatch}
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}
import java.util
import scala.collection.mutable.ListBuffer

/**
 * @description: 440456 --18张表导航至mysql（eta_index_click,eta_index_top1_consis1,eta_index_top1_consis2,eta_index_top3_consis,gis_navi_stat_user_daily,gis_navi_stat_task_daily,gis_navi_stat_user_month,gis_navi_stat_task_month,eta_index_std_consis1,eta_index_appro_consis1,eta_index_kd_consis1,eta_index_sl_consis1,eta_index_fuse_consis1,eta_index_gd3_consis1,dwd_gis_std_navi_conv_rejion,dwd_gis_std_navi_use_rejion,dwd_gis_std_navi_sf_use_rejion,gis_eta_stdline_accrual_daily_result）
 * @author 01418539 caojia
 * @date 2022/5/18 16:43
 */
object LoadDailyNaviHiveToMysql extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val tableName = args(0)
    val start_day = args(1)
    val end_day = args(2)
    val flag = args(3).toInt
    val tables: Array[String] = tableName.replaceAll("'", "").split(",")
    //    val tables: Array[String] = Array("gis_eta_stdline_accrual_daily_result")
    createOrInsert(spark, tables, start_day, end_day, flag)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def createOrInsert(spark: SparkSession, tables: Array[String], start_day: String, end_day: String, flag: Int): Unit = {
    val mysql_tables = getMysqlcreateTable(tables)
    var createSql = ""
    for (table <- tables) {
      if (flag == 0) {
        createSql = mysql_tables.get(table)
        processBDPMysqlCreateTable(table, createSql)
      } else {
        if (table.contains("gis_navi_stat_")) upsertToDevMysql2(spark, table.toUpperCase, start_day, end_day)
        if (table == "gis_eta_stdline_accrual_daily_result") upsertToDevMysql(spark, table.toUpperCase, start_day, end_day)
        if (table.contains("gis_eta_jiazhi_")) upsertToDevMysqlwithAddID(spark, table.toUpperCase, start_day, end_day)
      }
    }
  }

  def upsertToDevMysql2(spark: SparkSession, tableName: String, start_day: String, end_day: String): Unit = {
    //加载数据
    val o_dataDf = spark.sql(
      s"""
         |select
         |*
         |from dm_gis.${tableName.toLowerCase}
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |""".stripMargin)
      .na.fill("")
      .na.fill(0)
      .na.fill(0.0)
      .select("province", "city", "source", "sdk_count", "navi_count", "sf_count", "gd_count", "service_id", "gd_sdk_count", "inc_day")

    //将mysql中原表数据分区删除 支持重跑
    val conn: Connection = getFJTDevMysqlConnect()
    try {
      val querySql = s"select * from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 navi_index.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")
    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        upsertBatch(getFJTDevMysqlConnect(), tableName, fields, blank_places, listRows) //执行批量插入数据
      }
    })
    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 navi_index.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 navi_index.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
  }

  def upsertToDevMysqlwithAddID(spark: SparkSession, tableName: String, start_day: String, end_day: String): Unit = {
    //加载数据
    val o_dataDf = spark.sql(
      s"""
         |select
         |*
         |from dm_gis.${tableName.toLowerCase}
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |""".stripMargin)
      .withColumn("random_id", row_number().over(Window.partitionBy("inc_day").orderBy("inc_day")))
      .withColumn("id", concat_ws("_", col("random_id"), col("inc_day"))).drop("random_id")
      .na.fill("")
      .na.fill(0)
      .na.fill(0.0)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //将mysql中原表数据分区删除 支持重跑
    val conn: Connection = getFJTDevMysqlConnect()
    try {
      val querySql = s"select * from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 navi_index.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }

    //优化设置为批量写入
    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")

    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        logger.error("listRows.size:" + listRows.size)
        upsertBatch(getFJTDevMysqlConnect(), tableName, fields, blank_places, listRows) //执行批量插入数据
      }
    })
    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 navi_index.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 navi_index.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
  }

  def upsertToDevMysql(spark: SparkSession, tableName: String, start_day: String, end_day: String): Unit = {
    //加载数据
    val o_dataDf = spark.sql(
      s"""
         |select
         |*
         |from dm_gis.${tableName.toLowerCase}
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |""".stripMargin)
      .na.fill("")
      .na.fill(0)
      .na.fill(0.0)
      .drop("statdate")

    //将mysql中原表数据分区删除 支持重跑
    val conn: Connection = getFJTDevMysqlConnect()
    try {
      val querySql = s"select * from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 navi_index.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
    //    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    //    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    //    val value_cnt = colNames.map(x => "?").mkString(",")
    //    //循环遍历数据写入
    //    o_dataDf.collect.map(row => { //toLocalIterator.foreach  .collect.map
    //      try {
    //        val insertSql = s"insert into $tableName($fields) values($value_cnt)" //115
    //        val insert: PreparedStatement = conn.prepareStatement(insertSql)
    //        for (i <- 0 until fields.split(",").length) {
    //          insert.setString(i + 1, row.get(i).toString) //此处若原字段为空 会报空指针异常，提前处理
    //        }
    //        insert.execute()
    //      } catch {
    //        case ex: Exception => logger.error(s"往表 navi_index.$tableName  中插入$start_day 至 $end_day 数据时出现错误", ex)
    //          throw ex
    //      }
    //    })
    //优化设置为批量写入
    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")

    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        upsertBatch(getFJTDevMysqlConnect(), tableName, fields, blank_places, listRows) //执行批量插入数据
      }
    })
    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 navi_index.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 navi_index.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
  }

  def processBDPMysqlCreateTable(tableName: String, sql: String): Unit = {
    val conn: Connection = getFJTDevMysqlConnect()
    //    val createSQL: util.HashMap[String, String] = getNaviMysqlcreateTable(tableName)
    //    val sql = createSQL.get(tableName)
    try {
      //删除
      val delSql = s"DROP table IF EXISTS $tableName"
      val delState: PreparedStatement = conn.prepareStatement(delSql)
      delState.execute()
    } catch {
      case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
    }
    //建表
    try {
      val createSQl: PreparedStatement = conn.prepareStatement(sql)
      createSQl.execute()
      logger.error(s"表：$tableName 的建表语句为：" + sql)
      logger.error(s"在bdp的mysql库中建表 $tableName 成功！！！！！")
    } catch {
      case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
    }

  }

  /**
   * dm_gis.dwd_gis_navi_detail_daily 导航大宽表建表
   *
   * @return
   */
  def getNaviMysqlcreateTable(tableName: String): util.HashMap[String, String] = {
    val map = new util.HashMap[String, String]()
    val dwd_gis_navi_detail_daily =
      """
        |CREATE TABLE IF NOT EXISTS `dwd_gis_navi_detail_daily`(
        |  `ID` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
        |  `STATDATE` varchar(50) NOT NULL COMMENT '统计日期（yyyyMMdd)',
        |
        |  `TASK_AREA_CODE` varchar(50) DEFAULT NULL COMMENT '任务所属地区（755Y）',
        |  `TASK_ID` varchar(50) DEFAULT NULL COMMENT '任务ID(755Y12345)',
        |  `LINE_CODE` varchar(50) DEFAULT NULL COMMENT '线路编码',
        |  `REQUIRE_CATEGORY` varchar(50) DEFAULT NULL COMMENT '需求类别(0普通1大客户发运2区域发运3自营短驳4代理短驳5二程接驳6重货快运7冷运产品8同城配9重货专运10中转直派11特殊收派(历史)12错分特派13内部件14物料配送15市场宣传16网点搬迁17同场操作18零担19特殊收派)',
        |  `LINE_REQUIRE_TYPE` varchar(50) DEFAULT NULL COMMENT '需求类型(1计划线路2临时线路3异常线路)',
        |  `VEHICLE_SERIAL` varchar(50) DEFAULT NULL COMMENT '车牌号码',
        |  `SRC_ZONE_CODE` varchar(50) DEFAULT NULL COMMENT '始发地',
        |  `DEST_ZONE_CODE` varchar(50) DEFAULT NULL COMMENT '目的地',
        |  `ACTUAL_CAPACITY_LOAD` varchar(50) DEFAULT NULL COMMENT '实际运力载量（指派的车辆吨位）',
        |  `PLAN_DEPART_TM` varchar(50) DEFAULT NULL COMMENT '计划发车时间',
        |  `ACTUAL_DEPART_TM` varchar(50) DEFAULT NULL COMMENT '实际发车时间',
        |  `PLAN_ARRIVE_TM` varchar(50) DEFAULT NULL COMMENT '计划到车时间',
        |  `ACTUAL_ARRIVE_TM` varchar(50) DEFAULT NULL COMMENT '实际到车时间',
        |  `DRIVER_ID` varchar(50) DEFAULT NULL COMMENT '司机ID',
        |  `IS_STOP` varchar(50) DEFAULT NULL COMMENT '是否经停(1：直发2：经停3：多卸货口)',
        |  `PLAN_RUN_TIME` varchar(50) DEFAULT NULL COMMENT '计划运行时长(MIN)',
        |  `ACTUAL_RUN_TIME` varchar(50) DEFAULT NULL COMMENT '实际运行时长(MIN)',
        |  `SRC_LONGITUDE` varchar(50) DEFAULT NULL COMMENT '始发地经度',
        |  `SRC_LATITUDE` varchar(50) DEFAULT NULL COMMENT '始发地纬度',
        |  `DEST_LONGITUDE` varchar(50) DEFAULT NULL COMMENT '目的地经度',
        |  `DEST_LATITUDE` varchar(50) DEFAULT NULL COMMENT '目的地纬度',
        |  `DRIVER_TYPE` varchar(50) DEFAULT NULL COMMENT '司机类型(0自营 1个体或企业 2个人 3外请)',
        |  `CARRIER_NAME` varchar(50) DEFAULT NULL COMMENT '承运商名称',
        |  `CARRIER_TYPE` varchar(50) DEFAULT NULL COMMENT '承运商类型(0自营1个体或企业2个人)',
        |  `GIS_DISTANCE` varchar(50) DEFAULT NULL COMMENT 'GIS里程',
        |  `IS_RUN_ONTIME` varchar(50) DEFAULT NULL COMMENT '运行是否准点 1:准点 0:不准点 -1:不考核',
        |  `HKO_VEHICLE_CODE` varchar(50) DEFAULT NULL COMMENT '港/澳车牌号',
        |  `TRAILER_VEHICLE_CODE` varchar(50) DEFAULT NULL COMMENT '车牌号(挂)',
        |  `LENGTH` varchar(50) DEFAULT NULL COMMENT '车长（米）(任务需求的车长及车辆实际车长)',
        |  `OUTER_LENGTH` varchar(50) DEFAULT NULL COMMENT '外部长度(毫米)',
        |  `OUTER_WIDTH` varchar(50) DEFAULT NULL COMMENT '外部宽度(毫米)',
        |  `OUTER_HEIGHT` varchar(50) DEFAULT NULL COMMENT '外部高度(毫米)',
        |  `INNER_LENGTH` varchar(50) DEFAULT NULL COMMENT '内部长度(毫米)',
        |  `INNER_WIDTH` varchar(50) DEFAULT NULL COMMENT '内部宽度(毫米)',
        |  `INNER_HEIGHT` varchar(50) DEFAULT NULL COMMENT '内部高度(毫米)',
        |  `AXIS` varchar(50) DEFAULT NULL COMMENT '轴数',
        |  `WEIGHT` varchar(50) DEFAULT NULL COMMENT '车身重量（吨）',
        |  `LOAD_WEIGHT` varchar(50) DEFAULT NULL COMMENT '核载重量(KG)',
        |  `FULL_LOAD_WEIGHT` varchar(50) DEFAULT NULL COMMENT '满载重量(车身+货物满载质量)（吨）',
        |  `COLOR` varchar(50) DEFAULT NULL COMMENT '颜色',
        |  `ENERGY` varchar(50) DEFAULT NULL COMMENT '能量',
        |  `LICENSE` varchar(50) DEFAULT NULL COMMENT '证件类型',
        |  `EMISSION` varchar(50) DEFAULT NULL COMMENT '排放标准',
        |  `IS_TRAILER` varchar(50) DEFAULT NULL COMMENT '是否挂车：1-是,2-否',
        |  `VEHICLE_TYPE_GROUND` varchar(50) DEFAULT NULL COMMENT 'GROUND报文的车辆类型',
        |  `SOURCE` varchar(50) DEFAULT NULL COMMENT '数据来源：1-顺丰自营；2-顺丰外包；3-顺丰外包外请；4-顺陆C端',
        |  `VEHICLE_TYPE` varchar(50) DEFAULT NULL COMMENT '车辆类型:1,4,5,6,7,8',
        |  `VEHICLE_LENGTH` varchar(50) DEFAULT NULL COMMENT '用于判定车辆类型的车长（米）',
        |  `VEHICLE_FULL_LOAD_WEIGHT` varchar(50) DEFAULT NULL COMMENT '用于判断车辆类型的车辆总重（吨）',
        |  `HALFWAY_INTEGRATE_RATE` varchar(50) DEFAULT NULL COMMENT '融合轨迹上传比例',
        |  `VALIDITY_VEHICLE` varchar(50) DEFAULT NULL COMMENT '车载轨迹是否有效',
        |  `VALIDITY_PHONE` varchar(50) DEFAULT NULL COMMENT '手机轨迹是否有效',
        |  `IS_HALFWAY_INTEGRATE` varchar(50) DEFAULT NULL COMMENT '融合轨迹是否有效',
        |  `IS_STD` varchar(50) DEFAULT NULL COMMENT '是否标准线路 1：是 0：否',
        |  `RECALL1_SRC` varchar(50) DEFAULT NULL COMMENT '标准线路来源',
        |  `RECALL1_LINE_CODE` varchar(50) DEFAULT NULL COMMENT '线路编码',
        |  `RECALL1_VEHICLE_TYPE` varchar(50) DEFAULT NULL COMMENT '车辆类型',
        |  `RECALL1_CONDUCT_TYPE` varchar(50) DEFAULT NULL COMMENT '执行情况',
        |  `RECALL_SRC` varchar(50) DEFAULT NULL COMMENT '标准线路来源',
        |  `RECALL_ACTUAL_RUN_TIME` varchar(50) DEFAULT NULL COMMENT '实际运行时长(MIN)',
        |  `RECALL_LINE_DISTANCE` varchar(50) DEFAULT NULL COMMENT '配置里程(M)',
        |  `START_TYPE` varchar(50) DEFAULT NULL COMMENT '始发网点类型',
        |  `END_TYPE` varchar(50) DEFAULT NULL COMMENT '目的网点类型',
        |  `RECALL_LOG_DIST` varchar(50) DEFAULT NULL COMMENT '码表里程',
        |  `RECALL_RT_DIST` varchar(50) DEFAULT NULL COMMENT '原始轨迹',
        |  `RECALL_START_DEPT` varchar(50) DEFAULT NULL COMMENT '始发网点',
        |  `RECALL_END_DEPT` varchar(50) DEFAULT NULL COMMENT '目的网点',
        |  `RECALL_CONDUCT_TYPE` varchar(50) DEFAULT NULL COMMENT '执行情况',
        |  `IS_SDK` varchar(50) DEFAULT NULL COMMENT '是否进入SDK 1：是 0：否',
        |  `NAVI_ID` varchar(50) DEFAULT NULL COMMENT '导航ID',
        |  `SYSTEM` varchar(50) DEFAULT NULL COMMENT '使用系统',
        |  `REQUEST_ID` varchar(50) DEFAULT NULL COMMENT '请求底层唯一ID标识，用于关联出参结果',
        |  `TOP3_STARTX` varchar(50) DEFAULT NULL COMMENT 'TOP3开始经度（X1）-GCJ02',
        |  `TOP3_STARTY` varchar(50) DEFAULT NULL COMMENT 'TOP3开始纬度（Y1）-GCJ02',
        |  `TOP3_ENDX` varchar(50) DEFAULT NULL COMMENT 'TOP3结束经度（路口位置）-GCJ02',
        |  `TOP3_ENDY` varchar(50) DEFAULT NULL COMMENT 'TOP3结束纬度（路口位置）-GCJ02',
        |  `TOP3_LINE_CODE` varchar(50) DEFAULT NULL COMMENT '线路编码',
        |  `TOP3_SRC_DEPTCODE` varchar(50) DEFAULT NULL COMMENT '始发地网点代码',
        |  `TOP3_DEST_DEPTCODE` varchar(50) DEFAULT NULL COMMENT '目的地网点代码',
        |  `TOP3_VEHICLE_TYPE` varchar(50) DEFAULT NULL COMMENT '车辆类型',
        |  `SERVICE_ID` varchar(50) DEFAULT NULL COMMENT '调用方编码',
        |  `AK` varchar(50) DEFAULT NULL COMMENT 'APP层请求接口传入AK',
        |  `REQ_STARTTIME` varchar(50) DEFAULT NULL COMMENT '微服务请求开始时间（毫秒）',
        |  `OPT` varchar(50) DEFAULT NULL COMMENT '类型',
        |  `STDID` varchar(50) DEFAULT NULL COMMENT '标准线路ID',
        |  `DURATION` varchar(50) DEFAULT NULL COMMENT '线路花费时长（单位秒）',
        |  `SRC` varchar(50) DEFAULT NULL COMMENT '线路来源',
        |  `DISTANCE` varchar(50) DEFAULT NULL COMMENT '线路长度（单位米）',
        |  `NAVI_STARTTIME` varchar(50) DEFAULT NULL COMMENT '导航开始时间',
        |  `NAVI_ENDTIME` varchar(50) DEFAULT NULL COMMENT '导航结束时间',
        |  `NAVI_TIME` varchar(50) DEFAULT NULL COMMENT '导航用时（秒）',
        |  `FIRST_NAVI_TM` varchar(50) DEFAULT NULL COMMENT '导航用时（秒）',
        |  `TASK_TIME` varchar(50) DEFAULT NULL COMMENT '导航用时（秒）',
        |  `NAVI_DISTANCE` varchar(50) DEFAULT NULL COMMENT '导航距离',
        |  `TRACKSTART_DISTANCE` varchar(50) DEFAULT NULL COMMENT '起点坐标与第一个轨迹坐标的距离',
        |  `TRACKEND_DISTANCE` varchar(50) DEFAULT NULL COMMENT '终点坐标与最后轨迹坐标的距离',
        |  `TYPE` varchar(50) DEFAULT NULL COMMENT '日志类型，1-TOP3线路选择,2-偏航确认,3-导航结束,4-车道线,5-路口放大图信息,6-语音播报',
        |  `IS_NAVI` varchar(50) DEFAULT NULL COMMENT '是否使用导航 1：是 0：否',
        |  `NAVI_TYPE` varchar(50) DEFAULT NULL COMMENT '导航类型（顺丰-SF，高德-GD，百度-BD）',
        |  `NAVI_STRATEGY` varchar(50) DEFAULT NULL COMMENT '用户实际选择的导航线路STRATEGY',
        |  `SDK_VER` varchar(50) DEFAULT NULL COMMENT '导航SDK版本号',
        |  `SDK_NAVI_TYPE` varchar(50) DEFAULT NULL COMMENT '导航SDK类型',
        |  `FIRST_NAVI_TYPE` varchar(50) DEFAULT NULL COMMENT '第一次使用导航类型',
        |  `TASK_NAVI_TYPE` varchar(50) DEFAULT NULL COMMENT '任务使用导航类型 （SF，GD，SF|GD）',
        |  `TASK_SDK_NAVI_TYPE` varchar(50) DEFAULT NULL COMMENT '任务使用导航SDK类型',
        |  `STRATEGY` varchar(50) DEFAULT NULL COMMENT '线路返回策略',
        |  `PARSE_SRC` varchar(50) DEFAULT NULL COMMENT '线路来源',
        |  `ENDSRC_DIST` varchar(50) DEFAULT NULL COMMENT '导航终点与起始网点距离（米）',
        |  `STARTSRC_DIST` varchar(50) DEFAULT NULL COMMENT '导航起点与起始网点距离（米）',
        |
        |  `CREATE_TIME` timestamp NULL DEFAULT current_timestamp(),
        |  `CREATE_USER` varchar(50) DEFAULT NULL,
        |  `MODIFY_TIME` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
        |  `MODIFY_USER` varchar(50) DEFAULT NULL,
        |  PRIMARY KEY (`ID`),
        |  KEY `STATDATE` (`STATDATE`) USING BTREE
        |  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='顺陆导航明细大宽表'
        |""".stripMargin

    map.put(tableName, dwd_gis_navi_detail_daily)

    map
  }
}


