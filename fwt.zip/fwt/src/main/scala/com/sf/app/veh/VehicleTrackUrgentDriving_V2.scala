package com.sf.app.veh

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.HTPP_RGEO_X_Y_G
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.DateUtil._
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @description: 三急识别数据  三类轨迹数据union  提前过滤后 一天 约12min 450247
 * @author 01418539 caojia
 * @date 2022/5/26 11:21
 */
object VehicleTrackUrgentDriving_V2 extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processOther(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processOther(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val o_multi_tracks = spark.sql(
      s"""
         |select *
         |from dm_gis.dwd_vehicle_fuel_consump_urgent_event_dtl
         |where inc_day >= '$start_day' and inc_day <= '$end_day'
         |      and risk_d_event in ('1','2','3')
         |""".stripMargin)
      .withColumn("sp_flag", when('risk_d_event.isin("1", "2") && 'risk_d_sp.cast("double") > 10, true)
        .when('risk_d_event === "3" && 'risk_d_sp.cast("double") > 30, true).otherwise(false))
      .filter('sp_flag === true)
      .drop("sp_flag")
      .na.fill("", Seq("risk_d_x", "risk_d_y"))

    val o_tracks_cols = o_multi_tracks.schema.map(_.name).map(col)

    val multi_tracks = o_multi_tracks
      .withColumn("num", row_number().over(Window.partitionBy(o_tracks_cols: _*).orderBy('inc_day)))
      .filter('num === 1).drop("num")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val ak = "b61f6c427934416dbc3248dbefef5eb0"

    val org_risk_d_x_y = multi_tracks.select("risk_d_x", "risk_d_y", "inc_day").filter(trim('risk_d_x) =!= "" && trim('risk_d_y) =!= "")
      .withColumn("num", row_number().over(Window.partitionBy("risk_d_x", "risk_d_y").orderBy(desc("inc_day"))))
      .filter('num === 1).repartition(10).persist()

    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "450247", "【EOS-VCMP-CORE】燃油V2三急方案", "根据经纬度获取停留点信息", HTPP_RGEO_X_Y_G, ak, org_risk_d_x_y.count(), 10)
    val risk_d_x_y = org_risk_d_x_y.map(row => {
      val risk_d_x = row.getAs[String]("risk_d_x")
      val risk_d_y = row.getAs[String]("risk_d_y")
      val inc_day = row.getAs[String]("inc_day")

      var risk_d_place = ""
      var place_name = ""
      try {
        if (risk_d_x.trim != "" && risk_d_y.trim != "") {
          val start_url = String.format(HTPP_RGEO_X_Y_G, risk_d_x, risk_d_y, ak)
          risk_d_place = HttpInvokeUtil.sendGet(start_url, "UTF-8", 3)
          val risk_d_place_json = JSON.parseObject(risk_d_place)
          place_name = risk_d_place_json.getJSONObject("result").getString("name")
          logger.info(s"start的get请求返回的json为：" + risk_d_place)
        }
      } catch {
        case e: Exception => logger.error(s"$risk_d_x and $risk_d_y 返回信息有异常" + e.getMessage)
      }
      (risk_d_x, risk_d_y, risk_d_place, place_name, inc_day)
    }).toDF("risk_d_x", "risk_d_y", "risk_d_place", "place_name", "inc_day").persist()
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)
    val risk_cnt = multi_tracks.select("vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "risk_d_event", "inc_day")
      .withColumn("depart_tm", timeToTimestamp1('actual_depart_tm))
      .withColumn("arrive_tm", timeToTimestamp1('actual_arrive_tm))
      .withColumn("tm_inter", 'arrive_tm.cast("long") - 'depart_tm.cast("long")) //单位：秒
      .groupBy("vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "inc_day")
      .agg(
        first("tm_inter") as "tm_inter",
        count("risk_d_event") as "risk_cnt"
      )
      .withColumn("is_outliers", when('tm_inter / 'risk_cnt < 30, 1).otherwise(0))
      .select("vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "is_outliers", "inc_day")

    //当三急发生地点  异常条件
    val excep_cond = when('place_name.contains("乡道") && !'place_name.contains("高速") && 'risk_d_sp.cast("double") > 70, 1)
      .when('place_name.contains("县道") && !'place_name.contains("高速") && 'risk_d_sp.cast("double") > 75, 1)
      .when('place_name.contains("省道") && !'place_name.contains("高速") && 'risk_d_sp.cast("double") > 80, 1)
      .when('place_name.contains("国道") && !'place_name.contains("高速") && 'risk_d_sp.cast("double") > 90, 1)
      .otherwise(0)

    //按已有表结构拼装字段
    val res_cols_str = spark.sql("""select * from dm_gis.dwd_vehicle_fuel_urgent_event_place_dtl limit 1""")
    val res_cols = res_cols_str.schema.map(_.name).map(col)
    val risk_d_place = multi_tracks
      .join(risk_d_x_y, Seq("risk_d_x", "risk_d_y", "inc_day"), "left")
      .join(risk_cnt, Seq("vehicle_serial", "actual_depart_tm", "actual_arrive_tm", "inc_day"))
      .withColumn("sp_check", excep_cond)
      .na.fill("", Seq("risk_d_place"))
      .na.fill(0, Seq("is_outliers"))
      .withColumn("num", row_number().over(Window.partitionBy(res_cols: _*).orderBy("inc_day")))
      .filter('num === 1)
      .select(res_cols: _*)

    writeToHive(spark, risk_d_place, Seq("inc_day"), "dm_gis.dwd_vehicle_fuel_urgent_event_place_dtl")

    multi_tracks.unpersist()

  }

}
