package com.sf.app.eta

import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.{HTTP_ETA_STDLINE_P, HTTP_XY_COORDS_P}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{randomAdd, strNotNull}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.EtaUtil.{getByroadInfo, postTrackqueryIntegrate, postTrackqueryIntegrateWithLongLat}
import utils.SparkBuilder

/**
 * @task_id: 776822 接口调用批次运行 25w~接口限制 500/min 9.5h  双周运行
 * @description:时效定则策略：可提速价值线路及晚点线路挖掘 dm_gis.eta_line_and_dept_dtl  dm_gis.eta_line_post_dist_sp_dtl
 * @demander:薛飞扬 01434058
 * @author 01418539 caojia
 * @date 2023/7/11 13:54
 */
object EfficientDurationDecisionStrategyPre extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val start_num = args(1)
    val inter_num = args(2)
    val end_num = args(3)
    val is_dept_tb = "dm_gis.eta_line_and_dept_dtl"
    val post_back_tb = "dm_gis.eta_line_post_dist_sp_dtl"
    val days_29_aft = getdaysBeforeOrAfter(inc_day, 29)
    //    val cnt = spark.sql(s"""select * from $is_dept_tb where inc_day='$inc_day' limit 1""".stripMargin).head(1).size
    //    if (cnt == 0) { //只有首批次还未生成，才会重新生成数据
    //      loadMainPointDF(spark, inc_day, days_29_aft, is_dept_tb) //获取基本任务信息
    //    }
    loadMainPointDF(spark, inc_day, days_29_aft, is_dept_tb)
    procPost(spark, is_dept_tb, post_back_tb, inc_day, start_num, inter_num, end_num)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  //p1 获取公路运输涉及【线路明细】数据
  def loadMainPointDF(spark: SparkSession, inc_day: String, days_29_aft: String, is_dept_tb: String): Unit = {
    import spark.implicits._
    //30w条数据 2min
    //主表 dm_pass_rss.scha_tt_plan_main_pro 公路计划需求 单天5kw条数据
    //次表 dm_pass_rss.scha_tt_plan_point_pro 公路计划需求停靠点表 单天1亿条数据
    val main_point_sql =
    s"""select
       |  *
       |from
       |  (
       |    select
       |      lag(dept_code, 1) over(
       |        PARTITION BY id
       |        order by
       |          docking_sequence
       |      ) start_dept,--始发网点
       |      dept_code end_dept,--目的网点
       |      distance as line_distance,--配置里程
       |      times as line_time,--配置时长
       |      line_code,--线路编码
       |      cvy_name,--运力名称
       |      line_belongs_code as task_area_code,--归属地区
       |      transport_level,--运输等级
       |      plan_run_dt,--计划执行日期
       |      id as table_id,--日需求表id
       |      docking_sequence as sort_num,--次序
       |      arrive_tm as plan_arrive_tm,--计划到车时间
       |      arrive_batch,--到达班次
       |      lag(send_batch, 1) over(
       |        PARTITION BY id
       |        order by
       |          docking_sequence
       |      ) send_batch,--发出班次
       |      lag(send_tm, 1) over(
       |        PARTITION BY id
       |        order by
       |          docking_sequence
       |      ) plan_depart_tm,--计划发车时间
       |      lag(latest_arrival_tm, 1) over(
       |        PARTITION BY id
       |        order by
       |          docking_sequence
       |      ) last_arrive_tm,--最晚到车时间
       |      job_type--作业类型。1：装；2：卸；3：装卸；4：海关查验
       |    from
       |      (
       |        select
       |          a.id,
       |          a.line_code,
       |          a.cvy_name,
       |          a.line_belongs_code,
       |          a.transport_level,
       |          a.plan_run_dt,
       |          b.dept_code,
       |          b.docking_sequence,
       |          b.latest_arrival_tm,
       |          b.arrive_tm,
       |          b.arrive_batch,
       |          b.send_tm,
       |          b.send_batch,
       |          b.distance,
       |          b.times,
       |          b.job_type
       |        from
       |          (
       |            select
       |              id,
       |              omcs_line_code as line_code,
       |              cvy_name,
       |              line_belongs_code,
       |              transport_level,
       |              plan_run_dt
       |            from
       |              dm_pass_rss.scha_tt_plan_main_pro
       |            where
       |              inc_day = '$inc_day'   --inc_day
       |              and oper_type in (1, 2)
       |              and status != 3
       |              and transport_level in (1,2,3)
       |              and regexp_replace(plan_run_dt,'-','') between '$inc_day' and '$days_29_aft'  --inc_day+13
       |          ) a
       |          inner join (
       |            select
       |              plan_main_id,
       |              dept_code,
       |              docking_sequence,
       |              latest_arrival_tm,
       |              arrive_tm,
       |              arrive_batch,
       |              send_tm,
       |              send_batch,
       |              distance,
       |              times,
       |              job_type,
       |              point_type
       |            from
       |              dm_pass_rss.scha_tt_plan_point_pro
       |            where
       |              inc_day = '$inc_day'    --inc_day
       |              and regexp_replace(plan_run_dt,'-','') between '$inc_day' and '$days_29_aft'  --inc_day+13
       |          ) b on a.id = b.plan_main_id
       |        order by
       |          id,
       |          docking_sequence
       |      ) aa
       |  ) bb
       |where
       |  bb.start_dept is not null""".stripMargin
    logger.error(">>加载主表班次线路sql>>" + main_point_sql)
    val main_point_df = spark.sql(main_point_sql)
      .withColumn("num", row_number().over(Window.partitionBy('line_code, 'start_dept, 'end_dept).orderBy('plan_run_dt.desc)))
      .filter("num = 1").drop("num")
      .withColumn("id", concat_ws("_", 'line_code, 'start_dept, 'end_dept))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val res_cols = spark.sql(s"""select * from $is_dept_tb limit 0""").schema.map(_.name).map(col)
    //接口获取下道里程及其他相关信息
    val inter_back_df = main_point_df.select("id", "line_code", "start_dept", "end_dept").groupBy("id", "line_code", "start_dept", "end_dept").agg(lit(true))
      .withColumn("num", randomAdd(20)('id))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
    logger.error(">>调用接口前数据总量>>" + inter_back_df.count())
    writeToHive(spark, inter_back_df, Seq("inc_day", "num"), is_dept_tb)
  }

  def procPost(spark: SparkSession, is_dept_tb: String, post_back_tb: String, inc_day: String, start_num: String, inter_num: String, end_num: String): Unit = {
    import spark.implicits._
    val dept_info_df = getDeptDF(spark, inc_day)
    val inter_back_df = spark.sql(s"""select * from $is_dept_tb where inc_day='$inc_day'""")
      .join(broadcast(dept_info_df.selectExpr("dept_code as start_dept", "longitude x1", "latitude y1")), Seq("start_dept"), "left")
      .join(broadcast(dept_info_df.selectExpr("dept_code as end_dept", "longitude x2", "latitude y2")), Seq("end_dept"), "left")
      .na.fill("", Seq("line_code", "start_dept", "end_dept", "x1", "y1", "x2", "y2"))
      .persist()
    logger.error(">>主表缩减分区为2，调用接口前数据总量>>" + inter_back_df.count())

    val httpInvoke_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "776822", "【时长决策PRE】可加速线路及晚点数据挖掘", "时效标准线路接口", HTTP_ETA_STDLINE_P, "70b8ef2d67a946ff8f2493389f77028f", inter_back_df.count(), 4)
    val httpInvoke_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "776822", "【时长决策PRE】可加速线路及晚点数据挖掘", "根据swid 获取 轨迹点信息接口", HTTP_XY_COORDS_P, "2e4b2a16ef2a4427917f366fb22febb5", inter_back_df.count(), 2)

    var start_num_cnt = start_num.toInt
    val inter_num_cnt = inter_num.toInt
    var batch_num_cnt = start_num_cnt + inter_num_cnt
    val end_num_cnt = end_num.toInt
    val res_cols = spark.sql(s"""select * from $post_back_tb limit 0""").schema.map(_.name).map(col)
    for (i <- start_num_cnt until 101 if i >= start_num_cnt && i <= end_num_cnt) {
      logger.error("首发批次：" + i + " >>执行的批次num范围:" + start_num_cnt + "结束批次>>>" + batch_num_cnt)
      val inter_post_df_t = inter_back_df.filter('num.cast("int") >= start_num_cnt && 'num.cast("int") <= batch_num_cnt).repartition(2)
      logger.error(">>>该批次总量为>>>" + inter_post_df_t.count())
      val inter_post_df = inter_post_df_t.map(row => {
        val id = row.getAs[String]("id")
        val line_code = row.getAs[String]("line_code")
        val start_dept = row.getAs[String]("start_dept")
        val end_dept = row.getAs[String]("end_dept")
        val num = row.getAs[String]("num")
        val inc_day = row.getAs[String]("inc_day")
        val x1 = row.getAs[String]("x1")
        val y1 = row.getAs[String]("y1")
        val x2 = row.getAs[String]("x2")
        val y2 = row.getAs[String]("y2")
        val plan_time = line_code.substring(line_code.length - 4)
        val date = inc_day + "" + plan_time + "" + "00"

        var points = ""
        var nonhighway_dist, highway_dist, nonhighway_speed = "-"
        if (strNotNull(line_code) && strNotNull(start_dept) && strNotNull(end_dept)) {
          points = postTrackqueryIntegrate(line_code, plan_time, start_dept, end_dept)
        }
        if (points == "" && strNotNull(x1) && strNotNull(y1) && strNotNull(x2) && strNotNull(y2)) {
          points = postTrackqueryIntegrateWithLongLat(line_code, plan_time, start_dept, end_dept, x1.toDouble, y1.toDouble, x2.toDouble, y2.toDouble)
        }
        if (points != "" && strNotNull(date)) {
          val res = getByroadInfo(points, date)
          nonhighway_dist = res._1
          highway_dist = res._2
          nonhighway_speed = res._3
        }
        (id, nonhighway_dist, highway_dist, nonhighway_speed, inc_day, num)
      }).toDF("id", "nonhighway_dist", "highway_dist", "nonhighway_speed", "inc_day", "num")
        .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
      inter_post_df.show(2)
      logger.error(">>最终数据总量：>>>>>" + inter_post_df.count())
      writeToHive(spark, inter_post_df.coalesce(1), Seq("inc_day", "num"), post_back_tb)
      inter_post_df.unpersist()
      start_num_cnt = batch_num_cnt + 1
      batch_num_cnt = start_num_cnt + inter_num_cnt
    }
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_1)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_2)
  }

  /**
   * 已不用 回填接口未返回的数据
   *
   * @param spark
   * @param post_back_tb
   * @param inc_day
   */
  def replBlankBack(spark: SparkSession, post_back_tb: String, post_back_tb_tmp: String, inc_day: String, start_num: String, inter_num: String, end_num: String): Unit = {
    import spark.implicits._
    val org_back_df = spark.sql(s"""select * from $post_back_tb where inc_day='$inc_day' and nonhighway_dist='-'""")
    //1 不需要补跑的部分
    //    val no_need_df = org_back_df.filter('nonhighway_dist =!= "-")
    //2 需要补跑的部分
    //加载网点及经纬度对应信息
    val dept_info_df = getDeptDF(spark, inc_day)
    val need_df = org_back_df.filter(trim('nonhighway_dist) === "-")
      .withColumn("line_dept", split('id, "_"))
      .withColumn("line_code", 'line_dept(0))
      .withColumn("start_dept", 'line_dept(1))
      .withColumn("end_dept", 'line_dept(2))
      .join(broadcast(dept_info_df.selectExpr("dept_code as start_dept", "longitude x1", "latitude y1")), Seq("start_dept"), "left")
      .join(broadcast(dept_info_df.selectExpr("dept_code as end_dept", "longitude x2", "latitude y2")), Seq("end_dept"), "left")
      .na.fill("", Seq("x1", "y1", "x2", "y2"))
      .select("id", "line_code", "start_dept", "end_dept", "inc_day", "num", "x1", "y1", "x2", "y2")
      .repartition(2)
    logger.error(">>>>需要重新接口调用的数据总量为>>>" + need_df.count())

    var start_num_cnt = start_num.toInt
    val inter_num_cnt = inter_num.toInt
    var batch_num_cnt = start_num_cnt + inter_num_cnt
    val end_num_cnt = end_num.toInt
    val res_cols = spark.sql(s"""select * from $post_back_tb limit 0""").schema.map(_.name).map(col)
    for (i <- start_num_cnt until 101 if i >= start_num_cnt && i <= end_num_cnt) {
      logger.error("首发批次：" + i + " >>执行的批次num范围:" + start_num_cnt + "结束批次>>>" + batch_num_cnt)
      val inter_post_df_t = need_df.filter('num.cast("int") >= start_num_cnt && 'num.cast("int") <= batch_num_cnt).repartition(2)
      logger.error(">>>该批次总量为>>>" + inter_post_df_t.count())
      val inter_post_df = inter_post_df_t.map(row => {
        val id = row.getAs[String]("id")
        val line_code = row.getAs[String]("line_code")
        val start_dept = row.getAs[String]("start_dept")
        val end_dept = row.getAs[String]("end_dept")
        val num = row.getAs[String]("num")
        val inc_day = row.getAs[String]("inc_day")
        val x1 = row.getAs[String]("x1")
        val y1 = row.getAs[String]("y1")
        val x2 = row.getAs[String]("x2")
        val y2 = row.getAs[String]("y2")

        val plan_time = line_code.substring(line_code.length - 4)
        val date = inc_day + "" + plan_time + "" + "00"

        var points, nonhighway_dist, highway_dist, nonhighway_speed = "-"
        if (strNotNull(line_code) && strNotNull(start_dept) && strNotNull(end_dept) && strNotNull(x1) && strNotNull(y1) && strNotNull(x2) && strNotNull(y2)) {
          points = postTrackqueryIntegrateWithLongLat(line_code, plan_time, start_dept, end_dept, x1.toDouble, y1.toDouble, x2.toDouble, y2.toDouble)
        }
        if (points != "" && strNotNull(date)) {
          val res = getByroadInfo(points, date)
          nonhighway_dist = res._1
          highway_dist = res._2
          nonhighway_speed = res._3
        }
        (id, nonhighway_dist, highway_dist, nonhighway_speed, inc_day, num)
      }).toDF("id", "nonhighway_dist", "highway_dist", "nonhighway_speed", "inc_day", "num")
        .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
      inter_post_df.show(2)
      logger.error(">>最终数据总量：>>>>>" + inter_post_df.count())
      writeToHive(spark, inter_post_df.coalesce(1), Seq("inc_day", "num"), post_back_tb_tmp)
      inter_post_df.unpersist()
      start_num_cnt = batch_num_cnt + 1
      batch_num_cnt = start_num_cnt + inter_num_cnt
    }
  }

  def getDeptDF(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    val dim_df = spark.sql(
      """Select dept_code,longitude,latitude,row_number() over(partition by dept_code order by create_tm desc) num  from dim.dim_department
        |where longitude is not null and latitude is not null and trim(longitude) !='' and trim(latitude) !='' and dept_code is not null and trim(dept_code) !=''
        |""".stripMargin)
      .filter("num = 1")
      .withColumn("source", lit("1"))
      .select("dept_code", "longitude", "latitude", "source")

    val network_df = spark.sql(
      s"""select addr_code,coordinate from dm_pass_rss.bdm_tm_outside_network_addr
         |where inc_day='$inc_day'
         |and addr_code is not null and trim(addr_code) !=''
         |and coordinate is not null and trim(coordinate) !=''
         |group by addr_code,coordinate""".stripMargin)
      .withColumn("coordinate", split('coordinate, ","))
      .withColumn("longitude", 'coordinate(0))
      .withColumn("latitude", 'coordinate(1))
      .withColumn("source", lit("2"))
      .selectExpr("addr_code dept_code", "longitude", "latitude", "source")
    val dept_info_df = dim_df.union(network_df)
      .withColumn("num", row_number().over(Window.partitionBy('dept_code).orderBy('source)))
      .filter("num = 1").select("dept_code", "longitude", "latitude")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    dept_info_df
  }

  def replaceTN(spark: SparkSession, post_back_tb: String, post_back_tb_tmp: String, inc_day: String): Unit = {
    val full_df = spark.sql(s"""select * from $post_back_tb where inc_day='$inc_day' and nonhighway_dist != '-'""")
    val lack_df = spark.sql(s"""select * from $post_back_tb_tmp where inc_day='$inc_day'""")
    val res_cols = spark.sql(s"""select * from $post_back_tb limit 0""").schema.map(_.name).map(col)
    val res_df = full_df.union(lack_df).select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>最终数据总量：>>>>>" + res_df.count())
    writeToHive(spark, res_df.coalesce(2), Seq("inc_day", "num"), post_back_tb)
  }


}
