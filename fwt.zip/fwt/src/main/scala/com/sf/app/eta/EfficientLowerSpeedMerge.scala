package com.sf.app.eta

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.HTPP_GIS_NAVI_ROAD_P
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.lngLatToDistance
import utils.DateUtil.{timeToTimestampFormat, timeToTimestamp_}
import utils.{HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.language.implicitConversions
import scala.util.control.Breaks.{break, breakable}

/**
 * @description: 467891 GIS-RSS-ETA：时效定责需求_第四部分
 * @author 01418539 caojia
 * @date 2022/8/1 下午5:31
 */
object EfficientLowerSpeedMerge extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    val p1 = processMergeP1(spark, start_day, end_day)
    val p2 = filterExceptRuleP2(spark, p1)
    val p3 = MergeDSRuleP3(spark, p2)
    val p4 = quotaDSP4(spark, p3)
    val p5 = labelHierarchy(spark, p4)
    processLastStep(spark, p5)
    p1.unpersist()
    p2.unpersist()
    p3.unpersist()
    p4.unpersist()
    p5.unpersist()
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processMergeP1(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    import spark.implicits._
    //结果包含5部分信息：合并后的低速时段 & 停留段是否在低速时段内的标签 & 合并后的低速时段在纠偏中的最近时间段的索引信息 & 在低速时段内的停留时间段 & 在在低速时段内的停留时间段对应的索引（取经纬度）
    val rt_event_info_parse_str = splitFun("&")('rt_event_info_parse)
    val ds_tl_infos_str = splitFun("&")('ds_tl_infos)
    val point_dura_str = splitFun("&")('point_dura_infos)
    val p5_infos_str = splitFun("&")('p5_infos)
    val disu_start_coord = splitFirstLastFun(";", "first")('disu_coord)
    val disu_end_coord = splitFirstLastFun(";", "last")('disu_coord)
    val disu_start_swid = splitFirstLastFun(";", "first")('disu_swid)
    val disu_end_swid = splitFirstLastFun(";", "last")('disu_swid)

    val df_monitor = spark.sql(
      s"""
         |select  ac_is_run_ontime,actual_arrive_tm,actual_depart_tm,actual_run_time,difftime_plan_actual,
         |        disu_periods,end_dept,end_latitude,end_longitude,error_type,jp_coords,jp_status,jp_swid,
         |        jp_time,plan_arrive_tm,plan_depart_tm,rt_event_info,service,service_station_linkpointinfo,
         |        sort_num,speed,start_dept,start_latitude,start_longitude,sum_dist,task_inc_day,task_subid,tl_durations,
         |        tl_stay_points,tl_time_periods,toll_station,toll_station_linkpointinfo,vehicle_serial,inc_day
         |from dm_gis.eta_time_monitor
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and task_subid is not null and trim(task_subid) !=''
         |""".stripMargin)
      .repartition(600, 'task_subid)
      .filter(!'error_type.contains("4"))
      //初始的低速时段 [重复时段/包含关系的时段] 处理
      .withColumn("disu_periods_tmp", dropDuplicationPeriods('disu_periods))
      //疫情和其他事件字段拆解
      .withColumn("rt_event_info_parse", parseEventInfo('rt_event_info))
      .withColumn("epi_codes", rt_event_info_parse_str(0))
      .withColumn("epi_points", rt_event_info_parse_str(1))
      .withColumn("epi_swids", rt_event_info_parse_str(2))
      .withColumn("other_codes", rt_event_info_parse_str(3))
      .withColumn("other_points", rt_event_info_parse_str(4))
      .withColumn("other_swids", rt_event_info_parse_str(5))
      //得到实际运行时长
      .withColumn("plan_run_time", (timeToTimestamp_('plan_arrive_tm) - timeToTimestamp_('plan_depart_tm)) / 60)
      //合并逻辑
      .withColumn("ds_tl_infos", dsMergeTlUDF(timeToTimestampFormat, ",")('disu_periods_tmp, 'tl_time_periods, 'jp_time))
      .withColumn("disu_periods_2", ds_tl_infos_str(0))
      .withColumn("if_tl_in_disu", ds_tl_infos_str(1))
      .withColumn("merge_disu_index", ds_tl_infos_str(2))
      .withColumn("tl_time_periods_in_disu", ds_tl_infos_str(3))
      .withColumn("tl_in_disu_index", ds_tl_infos_str(4))
      .withColumn("point_dura_infos", getTLStaypointsUDF('tl_in_disu_index, 'tl_stay_points, 'tl_durations))
      .withColumn("tl_stay_points_in_disu", point_dura_str(0))
      .withColumn("tl_durations_in_disu", point_dura_str(1))
      .withColumn("disu_duration", dsMergeperiodsUDF('disu_periods_2))
      .withColumn("p5_infos", getSumDistCoordsSwidUDF('merge_disu_index, 'sum_dist, 'jp_coords, 'jp_swid, 'speed))
      .withColumn("disu_dis_ib", p5_infos_str(0))
      .withColumn("disu_dis", p5_infos_str(1))
      .withColumn("disu_coord", p5_infos_str(2))
      .withColumn("disu_start_coord", disu_start_coord)
      .withColumn("disu_end_coord", disu_end_coord)
      .withColumn("disu_swid", p5_infos_str(3))
      .withColumn("disu_start_swid", disu_start_swid)
      .withColumn("disu_end_swid", disu_end_swid)
      .withColumn("disu_speed", dsSpeed('disu_dis, 'disu_duration))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    df_monitor
  }

  def filterExceptRuleP2(spark: SparkSession, p1_df: DataFrame): DataFrame = {
    import spark.implicits._
    val near_coords_str = splitFun("&")('near_coords)
    val disu_start_coord_front = near_coords_str(0)
    val disu_end_coord_behind = near_coords_str(1)

    val p2_df = p1_df
      .repartition(600, 'task_subid)
      .withColumn("near_coords", NearDistJPStatus('disu_start_coord, 'disu_end_coord, 'jp_coords, 'jp_status))
      .withColumn("disu_start_coord_front", disu_start_coord_front)
      .withColumn("disu_dist_start", coordsDist('disu_start_coord, 'disu_start_coord_front))
      .withColumn("disu_end_coord_behind", disu_end_coord_behind)
      .withColumn("disu_dist_end", coordsDist('disu_end_coord, 'disu_end_coord_behind))
      .withColumn("filter_index", effiEndDist('disu_periods_2, 'disu_dist_end, 'disu_start_coord_front, 'disu_end_coord_behind, 'disu_dis, 'disu_speed))
      //加上过滤条件后字段重新生成
      .withColumn("disu_periods_2", deleteRedundantDS('disu_periods_2, 'filter_index))
      .withColumn("disu_start_coord_front", deleteRedundantDS('disu_start_coord_front, 'filter_index))
      .withColumn("disu_dist_start", deleteRedundantDS('disu_dist_start, 'filter_index))
      .withColumn("disu_end_coord_behind", deleteRedundantDS('disu_end_coord_behind, 'filter_index))
      .withColumn("disu_dist_end", deleteRedundantDS('disu_dist_end, 'filter_index))
      .withColumn("disu_dis_ib", deleteRedundantDS('disu_dis_ib, 'filter_index))
      .withColumn("merge_disu_index", deleteRedundantDS('merge_disu_index, 'filter_index))
      .filter('disu_periods_2.isNotNull && trim('disu_periods_2) =!= "")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    p2_df
  }

  def MergeDSRuleP3(spark: SparkSession, p2_df: DataFrame): DataFrame = {
    import spark.implicits._
    val disu_periods_2 = splitMultiFun("&&", "disu_periods_2")('disu_periods_dist_infos)
    val disu_dis_ib = splitMultiFun("&&", "disu_dis_ib")('disu_periods_dist_infos)
    val merge_disu_index = splitMultiFun("&&", "merge_disu_index")('disu_periods_dist_infos)
    val cnt_rank_infos_str = splitFun("&")('cnt_rank_infos)
    //结果包含5部分信息：合并后的低速时段 & 停留段是否在低速时段内的标签 & 合并后的低速时段在纠偏中的最近时间段的索引信息 & 在低速时段内的停留时间段 & 在在低速时段内的停留时间段对应的索引（取经纬度）
    val ds_tl_infos_str = splitFun("&")('ds_tl_infos)
    val point_dura_str = splitFun("&")('point_dura_infos)
    val p5_infos_str = splitFun("&")('p5_infos)
    val disu_start_coord = splitFirstLastFun(";", "first")('disu_coord)
    val disu_end_coord = splitFirstLastFun(";", "last")('disu_coord)
    val disu_start_swid = splitFirstLastFun(";", "first")('disu_swid)
    val disu_end_swid = splitFirstLastFun(";", "last")('disu_swid)
    //p2
    val near_coords_str = splitFun("&")('near_coords)
    val disu_start_coord_front = near_coords_str(0)
    val disu_end_coord_behind = near_coords_str(1)
    val p3_df = p2_df
      .repartition(600, 'task_subid)
      .withColumn("disu_periods_dist_infos", disuMergeMulti('disu_periods_2, 'disu_dis_ib, 'merge_disu_index))
      .withColumn("disu_periods_2", disu_periods_2)
      .withColumn("disu_dis_ib", disu_dis_ib)
      .withColumn("merge_disu_index", merge_disu_index)
      .withColumn("cnt_rank_infos", cntPeriods('disu_periods_2))
      .withColumn("disu_cnt", cnt_rank_infos_str(0))
      .withColumn("disu_rank", cnt_rank_infos_str(1))
      //此处开始 按照第一阶段的逻辑加工
      .withColumn("ds_tl_infos", dsMergeTlUDF(timeToTimestampFormat, "\\|")('disu_periods_2, 'tl_time_periods, 'jp_time))
      .withColumn("if_tl_in_disu", ds_tl_infos_str(1))
      .withColumn("tl_time_periods_in_disu", ds_tl_infos_str(3))
      .withColumn("tl_in_disu_index", ds_tl_infos_str(4))
      .withColumn("point_dura_infos", getTLStaypointsUDF('tl_in_disu_index, 'tl_stay_points, 'tl_durations))
      .withColumn("tl_stay_points_in_disu", point_dura_str(0))
      .withColumn("tl_durations_in_disu", point_dura_str(1))
      .withColumn("tl_durations_in_disu_tmp", tiInDisu('if_tl_in_disu, 'tl_durations_in_disu))
      .withColumn("disu_duration", dsMergeperiodsUDF('disu_periods_2))
      .withColumn("p5_infos", getSumDistCoordsSwidUDF('merge_disu_index, 'sum_dist, 'jp_coords, 'jp_swid, 'speed))
      .withColumn("disu_dis", p5_infos_str(1))
      .withColumn("disu_coord", p5_infos_str(2))
      .withColumn("disu_start_coord", disu_start_coord)
      .withColumn("disu_end_coord", disu_end_coord)
      .withColumn("disu_swid", p5_infos_str(3))
      .withColumn("disu_start_swid", disu_start_swid)
      .withColumn("disu_end_swid", disu_end_swid)
      .withColumn("disu_speed", dsSpeed('disu_dis, 'disu_duration))
      //从部分新增或修改
      .withColumn("disu_speed_point", p5_infos_str(4))
      .withColumn("disu_minspeed", minSpeed("disu_minspeed")('disu_speed_point, 'disu_coord, 'disu_swid))
      .withColumn("disu_minspeed_point", minSpeed("disu_minspeed_point")('disu_speed_point, 'disu_coord, 'disu_swid))
      .withColumn("disu_minspeed_swid", minSpeed("disu_minspeed_swid")('disu_speed_point, 'disu_coord, 'disu_swid))
      //part3 取part2的逻辑
      .withColumn("near_coords", NearDistJPStatus('disu_start_coord, 'disu_end_coord, 'jp_coords, 'jp_status))
      .withColumn("disu_start_coord_front", disu_start_coord_front)
      .withColumn("disu_dist_start", coordsDist('disu_start_coord, 'disu_start_coord_front))
      .withColumn("disu_end_coord_behind", disu_end_coord_behind)
      .withColumn("disu_dist_end", coordsDist('disu_end_coord, 'disu_end_coord_behind))
      //低速段扣除停留后的低速时长
      .withColumn("disu_duration_tl", disuDuration('disu_periods_2, 'tl_time_periods_in_disu))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    p3_df
  }

  def quotaDSP4(spark: SparkSession, p3_df: DataFrame): DataFrame = {
    import spark.implicits._
    //1 服务区 service swid /service_station_linkpointinfo 经纬度
    val service_infos_str = splitFun("&")('service_infos)
    val service_points_infos_str = splitFun("&")('service_points_infos)
    val service_minspeed_dist_infos_str = splitFun("&")('service_minspeed_dist_infos)
    val update_service_infos_str = splitFun("&")('update_service_infos)
    val jp_service_infos_str = splitFun("&")('jp_service_infos)
    //2 收费站 toll_station  toll_station_linkpointinfo 经纬度
    val toll_station_infos_str = splitFun("&")('toll_station_infos)
    val toll_station_points_infos_str = splitFun("&")('toll_station_points_infos)
    val toll_station_minspeed_dist_infos_str = splitFun("&")('toll_station_minspeed_dist_infos)
    val update_toll_station_infos_str = splitFun("&")('update_toll_station_infos)
    //3 疫情
    val epi_infos_str = splitFun("&")('epi_infos)
    val epi_points_infos_str = splitFun("&")('epi_points_infos)
    val epi_minspeed_dist_infos_str = splitFun("&")('epi_minspeed_dist_infos)
    val update_epi_infos_str = splitFun("&")('update_epi_infos)
    //4 其他事件
    val other_infos_str = splitFun("&")('other_infos)
    val other_points_infos_str = splitFun("&")('other_points_infos)
    val other_minspeed_dist_infos_str = splitFun("&")('other_minspeed_dist_infos)
    val update_other_infos_str = splitFun("&")('update_other_infos)
    //5 起终点
    val start_end_dept_infos_str = splitFun("&")('start_end_dept_infos)

    val org_p4_df = p3_df
      .repartition(600, 'task_subid).persist()
    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "442913", "【ETA】第4部分EfficientLowerSpeedMerge", "纠偏服务 经纬度矩形框", HTPP_GIS_NAVI_ROAD_P, "b61f6c427934416dbc3248dbefef5eb0", org_p4_df.count(), 600)
    //1 服务区
    val p4_df = org_p4_df.withColumn("service_infos", disuInService('service, 'disu_swid, 'disu_minspeed_swid))
      .withColumn("if_service_in", service_infos_str(0))
      .withColumn("if_minspeed_in_service", service_infos_str(1))
      .withColumn("service_swid_in_disu", service_infos_str(2))
      .withColumn("service_swid_not_in_disu", service_infos_str(3))
      .withColumn("service_points_infos", servicePoints('service_swid_in_disu, 'service_swid_not_in_disu, 'service, 'service_station_linkpointinfo))
      .withColumn("service_in_disu_points", service_points_infos_str(0))
      .withColumn("service_not_in_disu_points", service_points_infos_str(1))
      .withColumn("service_minspeed_dist_infos", distFromServiceToMinDisu('disu_minspeed_point, 'service_in_disu_points, 'service_not_in_disu_points))
      .withColumn("dis_minspeed_service_in_start", service_minspeed_dist_infos_str(0))
      .withColumn("dis_minspeed_service_in_end", service_minspeed_dist_infos_str(1))
      .withColumn("dis_minspeed_service_in", service_minspeed_dist_infos_str(2))
      .withColumn("dis_minspeed_service_out_start", service_minspeed_dist_infos_str(3))
      .withColumn("dis_minspeed_service_out_end", service_minspeed_dist_infos_str(4))
      .withColumn("dis_minspeed_service_out", service_minspeed_dist_infos_str(5))
      .withColumn("update_service_infos", serviceStartToEnd(2000)('disu_periods_2, 'dis_minspeed_service_out))
      .withColumn("dis_minspeed_service_out", update_service_infos_str(0))
      .withColumn("if_service_out", update_service_infos_str(1))
      //纠偏服务区
      .withColumn("jp_service_infos", notInServiceJP('if_service_in, 'disu_minspeed_point))
      .withColumn("minspeed_jp_service_swid", jp_service_infos_str(0))
      .withColumn("if_jp_sevrice", jp_service_infos_str(1))
      //2 收费站  toll_station  toll_station_linkpointinfo
      .withColumn("toll_station_infos", disuInService('toll_station, 'disu_swid, 'disu_minspeed_swid))
      .withColumn("if_toll_station_in", toll_station_infos_str(0))
      .withColumn("if_minspeed_in_toll_station", toll_station_infos_str(1))
      .withColumn("toll_station_swid_in_disu", toll_station_infos_str(2))
      .withColumn("toll_station_swid_not_in_disu", toll_station_infos_str(3))
      .withColumn("toll_station_points_infos", servicePoints('toll_station_swid_in_disu, 'toll_station_swid_not_in_disu, 'toll_station, 'toll_station_linkpointinfo))
      .withColumn("toll_station_in_disu_points", toll_station_points_infos_str(0))
      .withColumn("toll_station_not_in_disu_points", toll_station_points_infos_str(1))
      .withColumn("toll_station_minspeed_dist_infos", distFromServiceToMinDisu('disu_minspeed_point, 'toll_station_in_disu_points, 'toll_station_not_in_disu_points))
      .withColumn("dis_minspeed_toll_station_in_start", toll_station_minspeed_dist_infos_str(0))
      .withColumn("dis_minspeed_toll_station_in_end", toll_station_minspeed_dist_infos_str(1))
      .withColumn("dis_minspeed_toll_station_in", toll_station_minspeed_dist_infos_str(2))
      .withColumn("dis_minspeed_toll_station_out_start", toll_station_minspeed_dist_infos_str(3))
      .withColumn("dis_minspeed_toll_station_out_end", toll_station_minspeed_dist_infos_str(4))
      .withColumn("dis_minspeed_toll_station_out", toll_station_minspeed_dist_infos_str(5))
      .withColumn("update_toll_station_infos", serviceStartToEnd(2000)('disu_periods_2, 'dis_minspeed_toll_station_out))
      .withColumn("dis_minspeed_toll_station_out", update_toll_station_infos_str(0))
      .withColumn("if_toll_station_out", update_toll_station_infos_str(1))
      //3 疫情
      .withColumn("epi_infos", disuInService('epi_swids, 'disu_swid, 'disu_minspeed_swid))
      .withColumn("if_epi_in", epi_infos_str(0))
      .withColumn("if_minspeed_in_epi", epi_infos_str(1))
      .withColumn("epi_swid_in_disu", epi_infos_str(2))
      .withColumn("epi_swid_not_in_disu", epi_infos_str(3))
      .withColumn("epi_points_infos", servicePoints('epi_swid_in_disu, 'epi_swid_not_in_disu, 'epi_swids, 'epi_points))
      .withColumn("epi_in_disu_points", epi_points_infos_str(0))
      .withColumn("epi_not_in_disu_points", epi_points_infos_str(1))
      .withColumn("epi_minspeed_dist_infos", distFromServiceToMinDisu('disu_minspeed_point, 'epi_in_disu_points, 'epi_not_in_disu_points))
      .withColumn("dis_minspeed_epi_in_start", epi_minspeed_dist_infos_str(0))
      .withColumn("dis_minspeed_epi_in_end", epi_minspeed_dist_infos_str(1))
      .withColumn("dis_minspeed_epi_in", epi_minspeed_dist_infos_str(2))
      .withColumn("dis_minspeed_epi_out_start", epi_minspeed_dist_infos_str(3))
      .withColumn("dis_minspeed_epi_out_end", epi_minspeed_dist_infos_str(4))
      .withColumn("dis_minspeed_epi_out", epi_minspeed_dist_infos_str(5))
      .withColumn("update_epi_infos", serviceStartToEnd(5000)('disu_periods_2, 'dis_minspeed_epi_out))
      .withColumn("dis_minspeed_epi_out", update_epi_infos_str(0))
      .withColumn("if_epi_out", update_epi_infos_str(1))
      //4 其他事件
      .withColumn("other_infos", disuInService('other_swids, 'disu_swid, 'disu_minspeed_swid))
      .withColumn("if_other_in", other_infos_str(0))
      .withColumn("if_minspeed_in_other", other_infos_str(1))
      .withColumn("other_swid_in_disu", other_infos_str(2))
      .withColumn("other_swid_not_in_disu", other_infos_str(3))
      .withColumn("other_points_infos", servicePoints('other_swid_in_disu, 'other_swid_not_in_disu, 'other_swids, 'other_points))
      .withColumn("other_in_disu_points", other_points_infos_str(0))
      .withColumn("other_not_in_disu_points", other_points_infos_str(1))
      .withColumn("other_minspeed_dist_infos", distFromServiceToMinDisu('disu_minspeed_point, 'other_in_disu_points, 'other_not_in_disu_points)) //todo  other_not_in_disu_points 只有4位
      .withColumn("dis_minspeed_other_in_start", other_minspeed_dist_infos_str(0))
      .withColumn("dis_minspeed_other_in_end", other_minspeed_dist_infos_str(1))
      .withColumn("dis_minspeed_other_in", other_minspeed_dist_infos_str(2))
      .withColumn("dis_minspeed_other_out_start", other_minspeed_dist_infos_str(3))
      .withColumn("dis_minspeed_other_out_end", other_minspeed_dist_infos_str(4))
      .withColumn("dis_minspeed_other_out", other_minspeed_dist_infos_str(5))
      .withColumn("update_other_infos", serviceStartToEnd(1500)('disu_periods_2, 'dis_minspeed_other_out))
      .withColumn("dis_minspeed_other_out", update_other_infos_str(0))
      .withColumn("if_other_out", update_other_infos_str(1))
      //5 起点 终点
      .withColumn("start_end_dept_infos", startDeptDist('disu_minspeed_point, 'start_longitude, 'start_latitude, 'end_longitude, 'end_latitude))
      .withColumn("dis_dept_start", start_end_dept_infos_str(0))
      .withColumn("dis_dept_end", start_end_dept_infos_str(1))
      .withColumn("if_dept_start", start_end_dept_infos_str(2))
      .withColumn("if_dept_end", start_end_dept_infos_str(3))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)
    p4_df
  }

  def labelHierarchy(spark: SparkSession, p4_df: DataFrame): DataFrame = {
    import spark.implicits._
    val disu_label_infos_str = splitFun("&")('disu_label_infos)
    val p5_df = p4_df
      .repartition(600, 'task_subid)
      .withColumn("fiels12_t1", concat_ws("&&", 'disu_periods_2,
        'if_service_in, 'if_service_out, 'if_jp_sevrice,
        'if_toll_station_in, 'if_toll_station_out,
        'if_epi_in, 'if_epi_out, 'if_other_in, 'if_other_out, 'if_dept_start, 'if_dept_end))
      .withColumn("disu_label_infos", disuLabel1('fiels12_t1))
      .withColumn("disu_label_1", disu_label_infos_str(0))
      .withColumn("step0", disu_label_infos_str(1))
      .withColumn("step1", step1Label('disu_periods_2, 'step0, 'if_service_in, 'if_minspeed_in_service,
        'if_toll_station_in, 'if_minspeed_in_toll_station, 'if_epi_in, 'if_minspeed_in_epi,
        'if_other_in, 'if_minspeed_in_other))
      .withColumn("fiels11_t2", concat_ws("&&", 'step1,
        'if_minspeed_in_service, 'if_minspeed_in_toll_station, 'if_minspeed_in_epi, 'if_minspeed_in_other,
        'dis_minspeed_service_in, 'dis_minspeed_toll_station_in,
        'dis_minspeed_epi_in, 'dis_minspeed_other_in, 'dis_dept_start, 'dis_dept_end))
      .withColumn("step2", step2Label('fiels11_t2))
      .withColumn("step3", step3Label('step2, 'if_jp_sevrice))
      .withColumn("step4", step4Label('step3, 'if_dept_start, 'if_dept_end, 'dis_dept_start, 'dis_dept_end))
      .withColumn("disu_label_2", step5Label('step4, 'if_service_out, 'if_toll_station_out,
        'if_epi_out, 'if_other_out, 'dis_minspeed_service_out, 'dis_minspeed_toll_station_out,
        'dis_minspeed_epi_out, 'dis_minspeed_other_out))
      .withColumn("disu_label_3", disuLabel3('disu_label_2))
      .withColumn("disu_label_2", when(trim('disu_label_2) === "" || 'disu_label_2.isNull, 'disu_label_1).otherwise('disu_label_2))
      .withColumn("disu_label_3", when(trim('disu_label_3) === "" || 'disu_label_3.isNull, 'disu_label_1).otherwise('disu_label_3))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    p5_df
  }

  def processLastStep(spark: SparkSession, p5_df: DataFrame): Unit = {
    import spark.implicits._
    val suspected_cond = when('difftime_plan_actual.cast("double") =!= 0 && 'total_lowspeed_duration.cast("double") / ('difftime_plan_actual.cast("double") * lit(60)) <= -1, 1).otherwise(0)

    val all_label_infos_str = splitFun("&")('all_label_infos)
    val res_cols = spark.sql("""select * from dm_gis.eta_time_monitor_disu limit 1""").schema.map(_.name).map(col)
    val red_df = p5_df
      .repartition(600, 'task_subid)
      .withColumn("disu_periods", 'disu_periods_2)
      .withColumn("total_lowspeed_duration", sumDisuDuration('disu_duration, 'tl_durations_in_disu_tmp, 'disu_dis))
      .withColumn("suspected_abnormal_disu", suspected_cond)
      .withColumn("all_label_infos", allLabelInfo('disu_label_3, 'disu_duration, 'tl_durations_in_disu_tmp, 'disu_dis, 'total_lowspeed_duration, 'difftime_plan_actual))
      .withColumn("no_total_lowspeed_duration", all_label_infos_str(0))
      .withColumn("no_total_lowspeed_duration_ratio", all_label_infos_str(1))
      .withColumn("no_total_lowspeed_duration_delay_ratio", all_label_infos_str(2))
      .withColumn("service_total_lowspeed_duration", all_label_infos_str(3))
      .withColumn("service_total_lowspeed_duration_ratio", all_label_infos_str(4))
      .withColumn("service_total_lowspeed_duration_delay_ratio", all_label_infos_str(5))
      .withColumn("tollstation_total_lowspeed_duration", all_label_infos_str(6))
      .withColumn("tollstation_total_lowspeed_duration_ratio", all_label_infos_str(7))
      .withColumn("tollstation_total_lowspeed_duration_delay_ratio", all_label_infos_str(8))
      .withColumn("epidemic_total_lowspeed_duration", all_label_infos_str(9))
      .withColumn("epidemic_total_lowspeed_duration_ratio", all_label_infos_str(10))
      .withColumn("epidemic_total_lowspeed_duration_delay_ratio", all_label_infos_str(11))
      .withColumn("other_total_lowspeed_duration", all_label_infos_str(12))
      .withColumn("other_total_lowspeed_duration_ratio", all_label_infos_str(13))
      .withColumn("other_total_lowspeed_duration_delay_ratio", all_label_infos_str(14))
      .withColumn("start_total_lowspeed_duration", all_label_infos_str(15))
      .withColumn("start_total_lowspeed_duration_ratio", all_label_infos_str(16))
      .withColumn("start_total_lowspeed_duration_delay_ratio", all_label_infos_str(17))
      .withColumn("end_total_lowspeed_duration", all_label_infos_str(18))
      .withColumn("end_total_lowspeed_duration_ratio", all_label_infos_str(19))
      .withColumn("end_total_lowspeed_duration_delay_ratio", all_label_infos_str(20))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //中间表
    val swid_info = red_df.select("task_subid", "disu_rank", "disu_periods", "merge_disu_index", "disu_swid", "inc_day")
    writeToHive(spark, swid_info.coalesce(10), Seq("inc_day"), "dm_gis.eta_swid_map_periods")
    //结果表
    writeToHive(spark, red_df.select(res_cols: _*).coalesce(10), Seq("inc_day"), "dm_gis.eta_time_monitor_disu")

  }

  def tiInDisu = udf((if_tl_in_disu: String, tl_durations_in_disu: String) => {
    var new_tl_durations_in_disu = ""
    val if_arr = strHandle(if_tl_in_disu, "\\|")
    val tl_tm_arr = strHandle(tl_durations_in_disu, "\\|")
    try {
      if (tl_tm_arr.length > 0) {
        val new_tl_tms = new Array[String](if_arr.length)
        var j = 0
        for (i <- 0 until if_arr.length) {
          if ("0".equals(if_arr(i))) {
            new_tl_tms(i) = "0"
          }
          if ("1".equals(if_arr(i))) {
            new_tl_tms(i) = tl_tm_arr(j)
            j += 1
          }
        }
        new_tl_durations_in_disu = new_tl_tms.mkString("|")
      } else {
        new_tl_durations_in_disu = tl_durations_in_disu
      }
    } catch {
      case e: Exception => "" + e
    }
    new_tl_durations_in_disu
  })

  def dropDuplicationPeriods = udf((disu_periods: String) => {
    val new_periods = new mutable.HashSet[String]()
    val merge_tm_set = new mutable.HashSet[String]()
    try {
      if (strNotNull(disu_periods)) {
        val periods_arr = strHandle(disu_periods, ",").toSeq.toSet.toArray.sortWith((x1, x2) => x1 <= x2)
        if (periods_arr.length == 1) {
          new_periods += periods_arr(0)
        }
        for (i <- 0 until periods_arr.length if periods_arr.length > 1) {
          val max_tm = if (merge_tm_set.size == 0) "0" else merge_tm_set.max
          val cond = periods_arr(i).split("_")(0) > max_tm //两两比较 较大的时间放入hashset 解决重复遍历
          if (cond) {
            val next_start_tm = periods_arr(i).split("_")(0)
            var flag = true
            for (j <- (i + 1 until periods_arr.length).reverse if flag) { //逆向寻找 可合并的最大时间段
              //this
              val start_tm_1 = periods_arr(i).split("_")(0)
              val end_tm_1 = periods_arr(i).split("_")(1)
              //next
              val start_tm_2 = periods_arr(j).split("_")(0)
              val end_tm_2 = periods_arr(j).split("_")(1)

              val merge_cond = start_tm_2 <= start_tm_1 && end_tm_1 <= end_tm_2
              if (merge_cond) {
                new_periods += start_tm_1 + "_" + end_tm_2
                merge_tm_set += end_tm_2
                flag = false
              }
              if (!merge_cond && j == i + 1) {
                new_periods += start_tm_1 + "_" + end_tm_1
              }
            }
            if (i + 1 == periods_arr.length && next_start_tm > max_tm) {
              new_periods += periods_arr(i)
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    new_periods.toArray.sortWith((x1, x2) => x1 <= x2).mkString(",")
  })

  def disuDuration = udf((disu_periods_2: String, tl_time_periods: String) => {
    val disu_duration_tl = new ListBuffer[String]()
    try {
      if (strNotNull(disu_periods_2)) {
        val periods_arr: Array[String] = strHandle(disu_periods_2, "\\|")
        val tl_time_periods_arr: Array[String] = strHandle(tl_time_periods, "\\|")

        if (periods_arr.length > 0 && tl_time_periods_arr.length > 0) {
          for (i <- 0 until periods_arr.length) {
            val ds_start = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(i).split("_")(0))
            val ds_end = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(i).split("_")(1))
            var tl_start = 0l
            var tl_end = 0l
            var sum_tl_out_ds_1 = 0l
            if (tl_time_periods_arr(i).trim != "-") {
              tl_start = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tl_time_periods_arr(i).split("_")(0))
              tl_end = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", tl_time_periods_arr(i).split("_")(1))
            }
            sum_tl_out_ds_1 = ds_end - ds_start - (tl_end - tl_start)
            disu_duration_tl += sum_tl_out_ds_1.toString
          }
        } else if (periods_arr.length > 0 && tl_time_periods_arr.length == 0) {
          for (i <- 0 until periods_arr.length) {
            val ds_start = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(i).split("_")(0))
            val ds_end = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(i).split("_")(1))
            var sum_tl_out_ds_1 = 0l
            sum_tl_out_ds_1 = ds_end - ds_start
            disu_duration_tl += sum_tl_out_ds_1.toString
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    disu_duration_tl.mkString("|")
  })

  def allLabelInfo = udf((disu_label_3: String, disu_duration: String, tl_durations_in_disu: String, disu_dis: String, total_lowspeed_duration: String, difftime_plan_actual: String) => {
    var no_total_duration = 0.0
    var no_total_ratio = 0.0
    var no_total_delay_ratio = 0.0

    var service_duration = 0.0
    var service_ratio = 0.0
    var service_delay_ratio = 0.0

    var toll_duration = 0.0
    var tollstation_ratio = 0.0
    var tollstation_delay_ratio = 0.0

    var epi_duration = 0.0
    var epidemic_ratio = 0.0
    var epidemic_delay_ratio = 0.0

    var other_duration = 0.0
    var other_ratio = 0.0
    var other_delay_ratio = 0.0

    var start_duration = 0.0
    var start_ratio = 0.0
    var start_delay_ratio = 0.0

    var end_duration = 0.0
    var end_ratio = 0.0
    var end_delay_ratio = 0.0

    try {
      if (strNotNull(disu_label_3)) {
        val labels_arr: Array[String] = strHandle(disu_label_3, "\\|")
        val disu_duration_arr: Array[String] = strHandle(disu_duration, "\\|")
        val tl_durations_in_disu_arr: Array[String] = strHandle(tl_durations_in_disu, "\\|")
        val disu_dis_arr: Array[String] = strHandle(disu_dis, "\\|")
        val total_duration = total_lowspeed_duration.toDouble
        val difftime = difftime_plan_actual.toDouble * 60

        for (i <- 0 until disu_duration_arr.length) {
          val ds_tm = if (disu_duration_arr(i).toDouble < 0) 0 else disu_duration_arr(i).toDouble
          val def_tm = disu_dis_arr(i).toDouble * 3.6 / 20 //默认低速 20 km/h 单位转换
          val tl_tm = try {
            tl_durations_in_disu_arr(i).toDouble
          } catch {
            case e1: ArrayIndexOutOfBoundsException =>
              0.0
          }
          val t2 = ds_tm - tl_tm - def_tm
          val tm = if (t2 < 0) 0 else t2
          if (labels_arr(i) == "无标记") no_total_duration += tm
          if (labels_arr(i) == "服务区") service_duration += tm
          if (labels_arr(i) == "收费站") toll_duration += tm
          if (labels_arr(i) == "疫情") epi_duration += tm
          if (labels_arr(i) == "其他") other_duration += tm
          if (labels_arr(i) == "起点") start_duration += tm
          if (labels_arr(i) == "终点") end_duration += tm
        }

        if (total_duration != 0) {
          no_total_ratio = no_total_duration / total_duration
          service_ratio = service_duration / total_duration
          tollstation_ratio = toll_duration / total_duration
          epidemic_ratio = epi_duration / total_duration
          other_ratio = other_duration / total_duration
          start_ratio = start_duration / total_duration
          end_ratio = end_duration / total_duration
        }
        if (difftime != 0) {
          no_total_delay_ratio = no_total_duration / difftime
          service_delay_ratio = service_duration / difftime
          tollstation_delay_ratio = toll_duration / difftime
          epidemic_delay_ratio = epi_duration / difftime
          other_delay_ratio = other_duration / difftime
          start_delay_ratio = start_duration / difftime
          end_delay_ratio = end_duration / difftime
        }
      }
    } catch {
      case e: Exception => ""
    }
    Array(no_total_duration, no_total_ratio, no_total_delay_ratio,
      service_duration, service_ratio, service_delay_ratio,
      toll_duration, tollstation_ratio, tollstation_delay_ratio,
      epi_duration, epidemic_ratio, epidemic_delay_ratio,
      other_duration, other_ratio, other_delay_ratio,
      start_duration, start_ratio, start_delay_ratio,
      end_duration, end_ratio, end_delay_ratio).map(_.toString).mkString("&")
  })

  def sumDisuDuration = udf((disu_duration: String, tl_durations_in_disu: String, disu_dis: String) => {
    var total_lowspeed_duration = 0.0
    try {
      if (strNotNull(disu_duration)) {
        val disu_duration_arr: Array[String] = strHandle(disu_duration, "\\|")
        val tl_durations_in_disu_arr: Array[String] = strHandle(tl_durations_in_disu, "\\|")
        val disu_dis_arr: Array[String] = strHandle(disu_dis, "\\|")

        for (i <- 0 until disu_duration_arr.length) {
          val t_ds = if (disu_duration_arr(i).toDouble < 0) 0 else disu_duration_arr(i).toDouble
          val t_tl = try {
            tl_durations_in_disu_arr(i).toDouble
          } catch {
            case e1: ArrayIndexOutOfBoundsException =>
              0.0
          }
          val t_avg = disu_dis_arr(i).toDouble * 3.6 / 20 //默认低速 20 km/h 单位转换
          val t2 = t_ds - t_tl - t_avg
          total_lowspeed_duration += (if (t2 < 0) 0 else t2)

        }
      }
    } catch {
      case e: Exception => ""
    }
    total_lowspeed_duration
  })


  def disuLabel3 = udf((disu_label_2: String) => {
    val label3 = new ListBuffer[String]()
    try {
      if (strNotNull(disu_label_2)) {
        val disu_label_2_arr: Array[String] = strHandle(disu_label_2, "\\|")
        for (i <- 0 until disu_label_2_arr.length) {
          var last_label = "无标记"
          if (disu_label_2_arr(i).endsWith("服务区")) {
            last_label = "服务区"
          } else if (disu_label_2_arr(i).endsWith("收费站")) {
            last_label = "收费站"
          } else if (disu_label_2_arr(i).endsWith("其他事件")) {
            last_label = "其他"
          } else if (disu_label_2_arr(i).endsWith("疫情事件")) {
            last_label = "疫情"
          } else if (disu_label_2_arr(i).startsWith("起点")) {
            last_label = "起点"
          } else if (disu_label_2_arr(i).startsWith("终点")) {
            last_label = "终点"
          }
          label3 += last_label
        }
      }
    } catch {
      case e: Exception => ""
    }
    label3.mkString("|")
  })

  def step5Label = udf((step4: String,
                        if_minspeed_in_service: String, if_minspeed_in_toll_station: String,
                        if_minspeed_in_epi: String, if_minspeed_in_other: String,
                        dis_minspeed_service_out: String, dis_minspeed_toll_station_out: String,
                        dis_minspeed_epi_out: String, dis_minspeed_other_out: String) => {
    val step5 = new ArrayBuffer[String]()
    try {
      if (strNotNull(step4)) {
        val step5_arr = step4.split("\\|")
        val if_minspeed_out_service_arr = if_minspeed_in_service.split("\\|")
        val if_minspeed_out_toll_station_arr = if_minspeed_in_toll_station.split("\\|")
        val if_minspeed_out_epi_arr = if_minspeed_in_epi.split("\\|")
        val if_minspeed_out_other_arr = if_minspeed_in_other.split("\\|")
        val dis_minspeed_service_out_arr = dis_minspeed_service_out.split("\\|")
        val dis_minspeed_toll_station_out_arr = dis_minspeed_toll_station_out.split("\\|")
        val dis_minspeed_epi_out_arr = dis_minspeed_epi_out.split("\\|")
        val dis_minspeed_other_out_arr = dis_minspeed_other_out.split("\\|")

        val out_label_map = Array("低速外服务区", "低速外收费站", "低速外疫情事件", "低速外其他事件")

        for (i <- 0 until step5_arr.length) {
          var only_label = "-"
          if (step5_arr(i) == "-") {
            val out_label = Array(if_minspeed_out_service_arr(i), if_minspeed_out_toll_station_arr(i), if_minspeed_out_epi_arr(i), if_minspeed_out_other_arr(i))
            val dis_out = Array(dis_minspeed_service_out_arr(i), dis_minspeed_toll_station_out_arr(i), dis_minspeed_epi_out_arr(i), dis_minspeed_other_out_arr(i))
            val dis_min: Double = dis_out.map(_.toDouble).min
            breakable {
              for (j <- 0 until out_label.length) {
                if (out_label(j) == "1" && dis_out(j).toDouble == dis_min) {
                  only_label = out_label_map(j)
                  break
                }
              }
            }
          } else {
            only_label = step5_arr(i)
          }
          step5 += only_label
        }
      }
    } catch {
      case e: Exception => ""
    }
    step5.mkString("|")
  })

  def step4Label = udf((step3: String, if_dept_start: String, if_dept_end: String, dis_dept_start: String, dis_dept_end: String) => {
    val step4 = new ArrayBuffer[String]()
    try {
      if (strNotNull(step3)) {
        val step4_arr = step3.split("\\|")
        val if_dept_start_arr = if_dept_start.split("\\|")
        val if_dept_end_arr = if_dept_end.split("\\|")
        val dis_dept_start_arr = dis_dept_start.split("\\|")
        val dis_dept_end_arr = dis_dept_end.split("\\|")

        for (i <- 0 until step4_arr.length) {
          var step4_quota = "-"
          if (step4_arr(i) == "-") {
            if (if_dept_start_arr(i) == "1" && if_dept_end_arr(i) != "1") {
              step4_quota = "起点低速"
            } else if (if_dept_start_arr(i) != "1" && if_dept_end_arr(i) == "1") {
              step4_quota = "终点低速"
            } else if (if_dept_start_arr(i) == "1" && if_dept_end_arr(i) == "1") {
              if (dis_dept_start_arr(i).toDouble >= dis_dept_end_arr(i).toDouble) step4_quota = "终点低速" else step4_quota = "起点低速"
            }
          } else {
            step4_quota = step4_arr(i)
          }
          step4 += step4_quota
        }
      }
    } catch {
      case e: Exception => ""
    }
    step4.mkString("|")
  })

  def step3Label = udf((step2: String, if_jp_sevrice: String) => {
    val step3 = new ArrayBuffer[String]()
    try {
      if (strNotNull(step2)) {
        val step3_arr = step2.split("\\|")
        val if_jp_sevrice_arr = if_jp_sevrice.split("\\|")
        for (i <- 0 until step3_arr.length) {
          var step3_quota = "-"
          if (step3_arr(i) == "-" && if_jp_sevrice_arr(i) == "1") {
            step3_quota = "服务区纠偏"
          } else {
            step3_quota = step3_arr(i)
          }
          step3 += step3_quota
        }
      }
    } catch {
      case e: Exception => ""
    }
    step3.mkString("|")
  })

  def step2Label = udf((fiels11_t2: String) => {
    val step2 = new ArrayBuffer[String]()
    val all_fields_name_arr = Array("step1", "if_minspeed_in_service", "if_minspeed_in_toll_station", "if_minspeed_in_epi", "if_minspeed_in_other",
      "dis_minspeed_service_in", "dis_minspeed_toll_station_in", "dis_minspeed_epi_in", "dis_minspeed_other_in", "dis_dept_start", "dis_dept_end")
    val all_fields_arr = new Array[String](all_fields_name_arr.length)
    //低速内小标签 最小距离
    val p4_map_arr = Array("低速内服务区", "低速内收费站", "低速内疫情事件", "低速内其他事件", "起点低速", "终点低速")
    try {
      if (strNotNull(fiels11_t2)) {
        val all_fs_arr = strHandle(fiels11_t2, "&&")
        for (i <- 0 until all_fields_name_arr.length) {
          all_fields_arr(i) = try {
            all_fs_arr(i)
          } catch {
            case e: NullPointerException => ""
              ""
          }
        }

        val step1_arr: Array[String] = strHandle(all_fields_arr(0), "\\|")
        val repEmpty_arr = (0 until step1_arr.length).map(x => "").toArray

        val if_minspeed_in_service_arr: Array[String] = repEmptyArr(all_fields_arr(1), repEmpty_arr)
        val if_minspeed_in_toll_station_arr: Array[String] = repEmptyArr(all_fields_arr(2), repEmpty_arr)
        val if_minspeed_in_epi_arr: Array[String] = repEmptyArr(all_fields_arr(3), repEmpty_arr)
        val if_minspeed_in_other_arr: Array[String] = repEmptyArr(all_fields_arr(4), repEmpty_arr)

        val dis_minspeed_service_in_arr: Array[String] = repEmptyArr(all_fields_arr(5), repEmpty_arr)
        val dis_minspeed_toll_station_in_arr: Array[String] = repEmptyArr(all_fields_arr(6), repEmpty_arr)
        val dis_minspeed_epi_in_arr: Array[String] = repEmptyArr(all_fields_arr(7), repEmpty_arr)
        val dis_minspeed_other_in_arr: Array[String] = repEmptyArr(all_fields_arr(8), repEmpty_arr)
        val dis_dept_start_arr: Array[String] = repEmptyArr(all_fields_arr(9), repEmpty_arr)
        val dis_dept_end_arr: Array[String] = repEmptyArr(all_fields_arr(10), repEmpty_arr)

        for (i <- 0 until step1_arr.length) {
          if (step1_arr(i).trim == "-") {
            var step2_quota = "-"
            //低速内小标签 及 最小速度标签
            val p4_arr = Array(if_minspeed_in_epi_arr(i), if_minspeed_in_service_arr(i), if_minspeed_in_toll_station_arr(i), if_minspeed_in_other_arr(i))
            //6类标签距离
            val p6_dist_arr = Array(dis_minspeed_service_in_arr(i), dis_minspeed_toll_station_in_arr(i), dis_minspeed_epi_in_arr(i), dis_minspeed_other_in_arr(i), dis_dept_start_arr(i), dis_dept_end_arr(i))
            val min_dist = p6_dist_arr.map(_.toDouble).min
            val sum_4a = p4_arr.map { x => if ("1".equals(x) || "0".equals(x)) x.toInt else 0 }
            if (sum_4a.sum == 0) {
              breakable {
                for (j <- 0 until p6_dist_arr.length) {
                  if (p6_dist_arr(j).toDouble == min_dist) {
                    step2_quota = p4_map_arr(j)
                    break
                  }
                }
              }
            } else {
              step2_quota = "-"
            }
            step2 += step2_quota
          } else {
            step2 += step1_arr(i)
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    step2.mkString("|")
  })

  def step1Label = udf((disu_periods_2: String, step0: String,
                        if_service_in: String, if_minspeed_in_service: String,
                        if_toll_station_in: String, if_minspeed_in_toll_station: String,
                        if_epi_in: String, if_minspeed_in_epi: String,
                        if_other_in: String, if_minspeed_in_other: String) => {
    val step1 = new ArrayBuffer[String]()
    try {
      if (strNotNull(disu_periods_2)) {
        val periods_arr: Array[String] = strHandle(disu_periods_2, "\\|")
        val repEmpty_arr = (0 until periods_arr.length).map(x => "").toArray
        val step0_arr: Array[String] = repEmptyArr(step0, repEmpty_arr)
        val if_service_in_arr: Array[String] = repEmptyArr(if_service_in, repEmpty_arr)
        val if_minspeed_in_service_arr: Array[String] = repEmptyArr(if_minspeed_in_service, repEmpty_arr)
        val if_toll_station_in_arr: Array[String] = repEmptyArr(if_toll_station_in, repEmpty_arr)
        val if_minspeed_in_toll_station_arr: Array[String] = repEmptyArr(if_minspeed_in_toll_station, repEmpty_arr)
        val if_epi_in_arr: Array[String] = repEmptyArr(if_epi_in, repEmpty_arr)
        val if_minspeed_in_epi_arr: Array[String] = repEmptyArr(if_minspeed_in_epi, repEmpty_arr)
        val if_other_in_arr: Array[String] = repEmptyArr(if_other_in, repEmpty_arr)
        val if_minspeed_in_other_arr: Array[String] = repEmptyArr(if_minspeed_in_other, repEmpty_arr)

        //p8 低速内小标签 及 最小速度标签
        val p4_map_arr = Array("低速内疫情事件", "低速内服务区", "低速内收费站", "低速内其他事件")

        for (i <- 0 until periods_arr.length) {
          if (step0_arr(i) == "-") {
            var step1_quota = "-"
            //低速内小标签 及 最小速度标签
            val p41_arr = Array(if_epi_in_arr(i), if_service_in_arr(i), if_toll_station_in_arr(i), if_other_in_arr(i))
            val p42_arr = Array(if_minspeed_in_epi_arr(i), if_minspeed_in_service_arr(i), if_minspeed_in_toll_station_arr(i), if_minspeed_in_other_arr(i))

            for (k <- 0 until p41_arr.length) {
              if ("1".equals(p41_arr(k)) && "1".equals(p42_arr(k))) {
                step1_quota = p4_map_arr(k)
              }
            }
            step1 += step1_quota
          } else {
            step1 += step0_arr(i)
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    step1.mkString("|")
  })

  /**
   * 第1类标签打标 +  第2类 无标签和单标签判断
   *
   * @return
   */
  def disuLabel1 = udf((fiels12_t1: String) => {
    val disu_label_1 = new ListBuffer[String]()
    val quota = new ArrayBuffer[String]()
    var disu_periods_2, if_service_in, if_service_out, if_jp_sevrice, if_toll_station_in, if_toll_station_out, if_epi_in, if_epi_out, if_other_in, if_other_out, if_dept_start, if_dept_end = ""
    val all_fields_arr = Array(disu_periods_2, if_service_in, if_service_out, if_jp_sevrice, if_toll_station_in, if_toll_station_out, if_epi_in, if_epi_out, if_other_in, if_other_out, if_dept_start, if_dept_end)

    //低速内、外小标签 不含 最小速度标签
    val p11_map_arr = Array("低速内服务区", "低速外服务区", "纠偏服务区", "低速内收费站", "低速外收费站",
      "低速内疫情事件", "低速外疫情事件", "低速内其他事件", "低速外其他事件", "起点低速", "终点低速")

    try {
      if (strNotNull(fiels12_t1)) {
        val all_fs_arr = strHandle(fiels12_t1, "&&")
        for (i <- 0 until all_fs_arr.length) {
          all_fields_arr(i) = try {
            all_fs_arr(i)
          } catch {
            case e: NullPointerException => ""
              ""
          }
        }
        val periods_arr: Array[String] = strHandle(all_fields_arr(0), "\\|")
        val repEmpty_arr = (0 until periods_arr.length).map(x => "").toArray

        val if_service_in_arr: Array[String] = repEmptyArr(all_fields_arr(1), repEmpty_arr)
        val if_service_out_arr: Array[String] = repEmptyArr(all_fields_arr(2), repEmpty_arr)
        val if_jp_sevrice_arr: Array[String] = repEmptyArr(all_fields_arr(3), repEmpty_arr)

        val if_toll_station_in_arr: Array[String] = repEmptyArr(all_fields_arr(4), repEmpty_arr)
        val if_toll_station_out_arr: Array[String] = repEmptyArr(all_fields_arr(5), repEmpty_arr)

        val if_epi_in_arr: Array[String] = repEmptyArr(all_fields_arr(6), repEmpty_arr)
        val if_epi_out_arr: Array[String] = repEmptyArr(all_fields_arr(7), repEmpty_arr)

        val if_other_in_arr: Array[String] = repEmptyArr(all_fields_arr(8), repEmpty_arr)
        val if_other_out_arr: Array[String] = repEmptyArr(all_fields_arr(9), repEmpty_arr)
        val if_dept_start_arr: Array[String] = repEmptyArr(all_fields_arr(10), repEmpty_arr)
        val if_dept_end_arr: Array[String] = repEmptyArr(all_fields_arr(11), repEmpty_arr)

        for (i <- 0 until periods_arr.length) {
          val part_label = new ListBuffer[String]()

          val label1_arr = Array(if_service_in_arr(i), if_service_out_arr(i), if_jp_sevrice_arr(i), if_toll_station_in_arr(i), if_toll_station_out_arr(i),
            if_epi_in_arr(i), if_epi_out_arr(i), if_other_in_arr(i), if_other_out_arr(i), if_dept_start_arr(i), if_dept_end_arr(i))
          //part 1 label
          for (j <- 0 until label1_arr.length) {
            if ("1".equals(label1_arr(j))) {
              part_label += p11_map_arr(j)
            }
          }
          if (part_label.length == 0) part_label += "无标记"

          disu_label_1 += part_label.mkString("_")

          val sum11 = label1_arr.map(x => {
            if ("1".equals(x) || "0".equals(x)) x.toInt else 0
          }).sum
          //part2 first step label
          if (sum11 == 0) {
            quota += "无标记"
          } else if (sum11 == 1) {
            breakable {
              for (j <- 0 until label1_arr.length) {
                if (label1_arr(j).toInt == 1) {
                  quota += p11_map_arr(j)
                  break
                }
              }
            }
          } else {
            quota += "-"
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    disu_label_1.mkString("|") + "&" + quota.mkString("|")
  })


  def startDeptDist = udf((disu_minspeed_point: String, start_longitude: String, start_latitude: String, end_longitude: String, end_latitude: String) => {
    val dis_dept_start = new ListBuffer[String]()
    val dis_dept_end = new ListBuffer[String]()
    val if_dept_start = new ListBuffer[String]()
    val if_dept_end = new ListBuffer[String]()

    try {
      if (strNotNull(disu_minspeed_point)) {
        val disu_minspeed_point_arr: Array[String] = strHandle(disu_minspeed_point, "\\|")
        for (i <- 0 until disu_minspeed_point_arr.length) {
          val min_speed_lng = disu_minspeed_point_arr(i).split(",")(0)
          val min_speed_lat = disu_minspeed_point_arr(i).split(",")(1)
          val dis_dept_start_d = lngLatToDistance(min_speed_lng, min_speed_lat, start_longitude, start_latitude)
          val dis_dept_end_d = lngLatToDistance(min_speed_lng, min_speed_lat, end_longitude, end_latitude)

          if (dis_dept_start_d <= 2000) {
            dis_dept_start += dis_dept_start_d.toString
            if_dept_start += "1"
          } else {
            dis_dept_start += "999999"
            if_dept_start += "0"
          }

          if (dis_dept_end_d <= 2000) {
            dis_dept_end += dis_dept_end_d.toString
            if_dept_end += "1"
          } else {
            dis_dept_end += "999999"
            if_dept_end += "0"
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    dis_dept_start.mkString("|") + "&" + dis_dept_end.mkString("|") + "&" + if_dept_start.mkString("|") + "&" + if_dept_end.mkString("|")
  })

  def notInServiceJP = udf((if_service_in: String, disu_minspeed_point: String) => {
    val swids = new ArrayBuffer[String]()
    val if_jp_sevrice = new ArrayBuffer[String]()
    try {
      if (strNotNull(disu_minspeed_point)) {
        val disu_minspeed_point_arr = disu_minspeed_point.split("\\|")
        val if_service_in_arr = if_service_in.split("\\|")
        for (i <- 0 until if_service_in_arr.length) {
          val x_point = disu_minspeed_point_arr(i).split(",")(0)
          val y_point = disu_minspeed_point_arr(i).split(",")(1)
          if (if_service_in_arr(i) == "0") {
            val matrix = serviceJP(x_point, y_point)

            val x1 = matrix._1
            val x2 = matrix._2
            val y1 = matrix._3
            val y2 = matrix._4
            if (x1 > 0 && x2 > 0 && y1 > 0 && y2 > 0) {
              val post_back = latLngSendPost(x1, y1, x2, y2)
              if (post_back.replaceAll("\\|", "").trim == "") {
                if_jp_sevrice += "0"
              } else {
                if_jp_sevrice += "1"
              }
              swids += post_back
            }
          } else {
            swids += ""
            if_jp_sevrice += "0"
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    if (swids.length == 0) swids += ""
    if (if_jp_sevrice.length == 0) if_jp_sevrice += ""
    swids.mkString("|") + "&" + if_jp_sevrice.mkString("|")
  })

  def latLngSendPost(x1: Double, y1: Double, x2: Double, y2: Double): String = {
    val params =
      s"""
         |{
         |"ak":"dc894b4a3c7444b4a3505315d00b87ad",
         |"x1":"$x1",
         |"y1":"$y1",
         |"x2":"$x2",
         |"y2":"$y2",
         |"FC":5,
         |"toll":0,
         |"inner":0,
         |"furniture":0,
         |"fw2":0,
         |"poi":0,
         |"exprIndex":-1,
         |"mask":35,
         |"output":"json",
         |"gzip":"0",
         |"roadAttrToken":"6134FAA5B6B6ED55E87EA116466734ED"
         |}""".stripMargin

    val swid_infos = new ListBuffer[String]()
    var info_str = ""
    var swID = ""
    try {
      info_str = HttpInvokeUtil.sendPost(HTPP_GIS_NAVI_ROAD_P, params, 3, 2)
      //      logger.error("传入接口的参数为：" + params)
      //      logger.error("矩阵经纬度返回的json为：" + info_str)
      val str = JSON.parseObject(info_str)
      val result = str.getJSONArray("lines")
      for (i <- 0 until result.size()) {
        if (result.getJSONObject(i).getString("formway") == "5") {
          swID = result.getJSONObject(i).getString("swID")
          swid_infos += swID
        }
      }
    } catch {
      case e: Exception => ""
    }
    swid_infos.mkString(",")
  }

  def serviceJP(x: String, y: String): (Double, Double, Double, Double) = {
    val dis: Double = 0.5
    val r = 6371 //(地球半径)

    val o_dlng = 2 * math.asin(math.sin(dis / (2 * r)) / math.cos(x.toDouble * math.Pi / 180))
    val dlng = o_dlng * 180 / math.Pi
    val o_dlat = dis / r
    val dlat = o_dlat * 180 / math.Pi

    val x1: Double = x.toDouble - dlat
    val x2: Double = x.toDouble + dlat
    val y1: Double = y.toDouble - dlng
    val y2: Double = y.toDouble + dlng
    (x1, x2, y1, y2)
  }

  def serviceStartToEnd(threshold: Int) = udf((disu_periods_2: String, dis_minspeed_service_out: String) => {
    val dis_minspeed_service_out_new = new ArrayBuffer[String]()
    val is_service_out = new ArrayBuffer[String]()
    try {
      if (strNotNull(dis_minspeed_service_out) && strNotNull(disu_periods_2)) {
        val min_dis_arr: Array[String] = strHandle(dis_minspeed_service_out, "\\|")
        for (i <- 0 until min_dis_arr.length) {
          val multi_arr = min_dis_arr(i).split(",")
          var is_service_p = "0"
          var multi_dist_p = "999999"
          val min_out_dist = multi_arr.map(_.toDouble).min

          for (j <- 0 until multi_arr.length) {
            var flag = true
            if (multi_arr(j).toDouble <= threshold && multi_arr(j).toDouble == min_out_dist && flag) {
              is_service_p = "1"
              multi_dist_p = multi_arr(j)
              flag = false
            }
          }
          is_service_out += is_service_p
          dis_minspeed_service_out_new += multi_dist_p
        }
      }
      if (!strNotNull(dis_minspeed_service_out) && strNotNull(disu_periods_2)) {
        val periods_arr: Array[String] = strHandle(disu_periods_2, "\\|")
        for (x <- periods_arr) {
          is_service_out += "0"
          dis_minspeed_service_out_new += "999999"
        }
      }
    } catch {
      case e: Exception => ""
    }
    if (dis_minspeed_service_out_new.isEmpty) dis_minspeed_service_out_new += "-"
    if (is_service_out.isEmpty) is_service_out += "-"
    dis_minspeed_service_out_new.mkString("|") + "&" + is_service_out.mkString("|")
  })

  def distFromServiceToMinDisu = udf((disu_minspeed_point: String, service_in_disu_points: String, service_not_in_disu_points: String) => {
    val in_start_dist_ab = new ArrayBuffer[String]()
    val in_end_dist_ab = new ArrayBuffer[String]()
    val in_start_end_dist_ab = new ArrayBuffer[String]()
    val not_in_start_dist_ab = new ArrayBuffer[String]()
    val not_in_end_dist_ab = new ArrayBuffer[String]()
    val not_in_start_end_dist_ab = new ArrayBuffer[String]()

    try {
      if (strNotNull(disu_minspeed_point)) {
        val min_speed_arr: Array[String] = strHandle(disu_minspeed_point, "\\|")
        val in_disu_points_arr: Array[String] = strHandle(service_in_disu_points, "\\|")
        val not_in_disu_points_arr: Array[String] = strHandle(service_not_in_disu_points, "\\|")

        for (i <- 0 until min_speed_arr.length) {
          var in_min_start_end = "999999"
          var not_in_min_start_end = "999999"

          val start_min_points = min_speed_arr(i).split(",")(0)
          val end_min_points = min_speed_arr(i).split(",")(1)
          //最小速度点 在服务区 与 起点 and 终点 距离
          if (in_disu_points_arr(i) != "-") {
            val p_points_arr: Array[String] = strHandle(in_disu_points_arr(i), ";;")
            val in_start_dist = new ArrayBuffer[String]()
            val in_end_dist = new ArrayBuffer[String]()
            val in_min_start_end_dist = new ArrayBuffer[String]()
            for (j <- 0 until p_points_arr.length) {
              val start_points_arr = p_points_arr(j).split(";")(0)
              val end_points_arr = p_points_arr(j).split(";")(1)
              val s1 = lngLatToDistance(start_min_points, end_min_points, start_points_arr.split(",")(0), start_points_arr.split(",")(1))
              val s2 = lngLatToDistance(start_min_points, end_min_points, end_points_arr.split(",")(0), end_points_arr.split(",")(1))
              in_start_dist += s1.toString
              in_end_dist += s2.toString
              in_min_start_end = if (s1 >= s2) s2.toString else s1.toString
              in_min_start_end_dist += in_min_start_end
            }
            in_start_dist_ab += in_start_dist.mkString(",")
            in_end_dist_ab += in_end_dist.mkString(",")
            in_start_end_dist_ab += in_min_start_end_dist.map(x => if ("".equals(x)) 0.0 else x.toDouble).min.toString
          } else {
            in_start_dist_ab += in_min_start_end
            in_end_dist_ab += in_min_start_end
            in_start_end_dist_ab += in_min_start_end
          }
          //最小速度点 不在服务区 与 起点 and 终点 距离
          if (not_in_disu_points_arr(i) != "-") {
            val p_points_arr: Array[String] = strHandle(not_in_disu_points_arr(i), ";;")
            val not_in_start_dist = new ArrayBuffer[String]()
            val not_in_end_dist = new ArrayBuffer[String]()
            val not_in_min_start_end_dist = new ArrayBuffer[String]()
            for (j <- 0 until p_points_arr.length) {
              val start_points_arr = p_points_arr(j).split(";")(0)
              val end_points_arr = p_points_arr(j).split(";")(1)
              val s1 = lngLatToDistance(start_min_points, end_min_points, start_points_arr.split(",")(0), start_points_arr.split(",")(1))
              val s2 = lngLatToDistance(start_min_points, end_min_points, end_points_arr.split(",")(0), end_points_arr.split(",")(1))
              not_in_start_dist += s1.toString
              not_in_end_dist += s2.toString
              not_in_min_start_end = if (s1 >= s2) s2.toString else s1.toString
              not_in_min_start_end_dist += not_in_min_start_end
            }
            not_in_start_dist_ab += not_in_start_dist.mkString(",")
            not_in_end_dist_ab += not_in_end_dist.mkString(",")
            not_in_start_end_dist_ab += not_in_min_start_end_dist.map(x => if (x == "") 0.0 else x.toDouble).min.toString
          } else {
            not_in_start_dist_ab += not_in_min_start_end
            not_in_end_dist_ab += not_in_min_start_end
            not_in_start_end_dist_ab += not_in_min_start_end
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    in_start_dist_ab.mkString("|") + "&" + in_end_dist_ab.mkString("|") + "&" + in_start_end_dist_ab.mkString("|") + "&" + not_in_start_dist_ab.mkString("|") + "&" + not_in_end_dist_ab.mkString("|") + "&" + not_in_start_end_dist_ab.mkString("|")
  })

  def servicePoints = udf((service_swid_in_disu: String, service_swid_not_in_disu: String, service: String, service_station_linkpointinfo: String) => {
    val service_points_in_disu = new ArrayBuffer[String]()
    val service_points_not_in_disu = new ArrayBuffer[String]()
    try {
      if (strNotNull(service_swid_in_disu) || strNotNull(service_swid_not_in_disu)) {
        val service_arr: Array[String] = strHandle(service, "\\|")
        val service_pionts_arr: Array[String] = strHandle(service_station_linkpointinfo, "\\|")
        val service_swid_in_disu_arr: Array[String] = strHandle(service_swid_in_disu, "\\|")
        val service_swid_not_in_disu_arr: Array[String] = strHandle(service_swid_not_in_disu, "\\|")
        for (i <- 0 until service_swid_in_disu_arr.length) {
          if (service_swid_in_disu_arr(i) != "-") {
            val in_arr = service_swid_in_disu_arr(i).split(";")
            val single_in = new ListBuffer[String]()
            for (j <- 0 until in_arr.length) {
              breakable {
                for (k <- 0 until service_arr.length) {
                  if (in_arr(j) == service_arr(k)) {
                    single_in += service_pionts_arr(k)
                    break
                  }
                }
              }
            }
            val tmp = if (single_in.length == 0) "-" else single_in.mkString(";;")
            service_points_in_disu += tmp
          } else {
            service_points_in_disu += "-"
          }
        }

        for (i <- 0 until service_swid_not_in_disu_arr.length) {
          if (service_swid_not_in_disu_arr(i) != "-") {
            val not_in_arr = service_swid_not_in_disu_arr(i).split(";")
            val single_not_in = new ListBuffer[String]()
            for (j <- 0 until not_in_arr.length) {
              breakable {
                for (k <- 0 until service_arr.length) {
                  if (not_in_arr(j) == service_arr(k)) {
                    single_not_in += service_pionts_arr(k)
                    break
                  }
                }
              }
            }
            val tmp = if (single_not_in.length == 0) "-" else single_not_in.mkString(";;")
            service_points_not_in_disu += tmp
          } else {
            service_points_not_in_disu += "-"
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    service_points_in_disu.mkString("|") + "&" + service_points_not_in_disu.mkString("|")
  })

  def disuInService = udf((service: String, disu_swid: String, disu_minspeed_swid: String) => {
    var if_service_in_arr, if_minspeed_in_service_arr, service_swid_in_disu_arr, service_swid_not_in_disu_arr = Array[String]()
    if (strNotNull(disu_swid)) {
      val service_arr: Array[String] = strHandle(service, "\\|")
      val disu_swid_arr: Array[String] = strHandle(disu_swid, "\\|")
      val disu_minspeed_swid_arr: Array[String] = strHandle(disu_minspeed_swid, "\\|")

      if_service_in_arr = new Array[String](disu_swid_arr.length)
      if_minspeed_in_service_arr = new Array[String](disu_swid_arr.length)
      service_swid_in_disu_arr = new Array[String](disu_swid_arr.length)
      service_swid_not_in_disu_arr = new Array[String](disu_swid_arr.length)

      try {
        for (i <- 0 until disu_swid_arr.length) {
          var flag = true
          val p_swid_arr = disu_swid_arr(i).split(";")
          if_service_in_arr(i) = "0"
          if_minspeed_in_service_arr(i) = "0"
          service_swid_in_disu_arr(i) = ""
          service_swid_not_in_disu_arr(i) = ""
          //低速段只要有一个服务区则打标 有服务区标识
          breakable {
            for (j <- 0 until p_swid_arr.length) {
              if (service_arr.contains(p_swid_arr(j))) {
                if_service_in_arr(i) = "1"
                break
              }
            }
          }
          //最小速度是否在服务区
          if (service_arr.contains(disu_minspeed_swid_arr(i)) && flag) {
            if_minspeed_in_service_arr(i) = "1"
            flag = false
          }
          val multil_in = new ListBuffer[String]()
          val multil_not_in = new ListBuffer[String]()
          for (j <- 0 until service_arr.length) {
            //一个低速段可能包含多个  服务区swid(同个服务区可能包含多个swid)
            if (p_swid_arr.contains(service_arr(j))) {
              multil_in += service_arr(j)
            } else {
              multil_not_in += service_arr(j)
            }
          }
          service_swid_in_disu_arr(i) = if (multil_in.length == 0) "-" else multil_in.mkString(";")
          service_swid_not_in_disu_arr(i) = if (multil_not_in.length == 0) "-" else multil_not_in.mkString(";")
        }
      } catch {
        case e: Exception => ""
      }
    }
    if_service_in_arr.mkString("|") + "&" + if_minspeed_in_service_arr.mkString("|") + "&" + service_swid_in_disu_arr.mkString("|") + "&" + service_swid_not_in_disu_arr.mkString("|")
  })

  /**
   * 根据最小速度（索引） 定位 对应的 coords经纬度 及 swid信息
   *
   * @param fields_flag
   * @return
   */
  def minSpeed(fields_flag: String) = udf((disu_speed_point: String, disu_coord: String, disu_swid: String) => {
    val res = new ArrayBuffer[String]()
    var minSpeed = ""
    try {
      if (strNotNull(disu_speed_point)) {
        val speeds_arr: Array[String] = strHandle(disu_speed_point, "\\|")
        val disu_coord_arr: Array[String] = strHandle(disu_coord, "\\|")
        val disu_swid_arr: Array[String] = strHandle(disu_swid, "\\|")
        for (i <- 0 until speeds_arr.length) {
          val single_speed = speeds_arr(i).split(";")
          val single_coord = disu_coord_arr(i).split(";")
          val single_swid = disu_swid_arr(i).split(";")
          minSpeed = single_speed.map(_.toDouble).min.toString
          var flag = true
          for (j <- 0 until single_speed.length if flag) {
            if (single_speed(j).toDouble == minSpeed.toDouble) {
              if (fields_flag == "disu_minspeed") {
                res += minSpeed
              }
              if (fields_flag == "disu_minspeed_point") {
                res += single_coord(j)
              }
              if (fields_flag == "disu_minspeed_swid") {
                res += single_swid(j)
              }
              flag = false
            }
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    res.mkString("|")
  })

  def disuMergeMulti = udf((disu_periods_2: String, disu_dis_ib: String, merge_disu_index: String) => {
    val disu_periods_dis = new mutable.HashMap[String, String]
    val merge_tm = new mutable.HashSet[String]()

    try {
      if (strNotNull(disu_periods_2)) {
        val periods_arr: Array[String] = strHandle(disu_periods_2, "\\|")
        val merge_disu_index_arr: Array[String] = strHandle(merge_disu_index, "\\|")
        val o_to_end_dist_arr: Array[String] = strHandle(disu_dis_ib, "\\|")
        if (periods_arr.length == 1) {
          disu_periods_dis.put(disu_periods_2, disu_dis_ib + "&" + merge_disu_index)
        }
        for (i <- 0 until periods_arr.length if periods_arr.length > 1) {
          val max_tm = if (merge_tm.size == 0) "0" else merge_tm.max
          val cond = periods_arr(i).split("_")(0) > max_tm //两两比较 较大的时间放入hashset 解决重复遍历
          if (cond) {
            val next_start_tm = periods_arr(i).split("_")(0)
            var flag = true
            for (j <- (i + 1 until periods_arr.length).reverse if flag) { //逆向寻找 可合并的最大时间段
              //this
              val start_tm_1 = periods_arr(i).split("_")(0)
              val end_tm_1 = periods_arr(i).split("_")(1)
              val start_dist_1 = o_to_end_dist_arr(i).split("_")(0)
              val end_dist_1 = o_to_end_dist_arr(i).split("_")(1)
              val start_index_1 = merge_disu_index_arr(i).split("_")(0)
              val end_index_1 = merge_disu_index_arr(i).split("_")(1)
              //next
              val start_tm_2 = periods_arr(j).split("_")(0)
              val end_tm_2 = periods_arr(j).split("_")(1)
              val start_dist_2 = o_to_end_dist_arr(j).split("_")(0)
              val end_dist_2 = o_to_end_dist_arr(j).split("_")(1)
              val start_index_2 = merge_disu_index_arr(j).split("_")(0)
              val end_index_2 = merge_disu_index_arr(j).split("_")(1)

              //cond1 距离值小于1500m 中间段速度小于50km/h
              val mid_dist_1 = start_dist_2.toDouble - end_dist_1.toDouble
              val mid_tm_1 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm_2) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm_1)
              val mid_speed_1 = 3.6 * mid_dist_1 / mid_tm_1
              //cond2 合并后的速度小于30km/h 低速路段距离小于等于5000m
              val mid_dist_2 = end_dist_2.toDouble - start_dist_1.toDouble
              val mid_tm_2 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", end_tm_2) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_tm_1)
              val mid_speed_2 = 3.6 * mid_dist_2 / mid_tm_2

              val merge_cond = mid_dist_1 <= 1500 && mid_speed_1 <= 50 && mid_dist_2 <= 5000 && mid_speed_2 <= 30
              if (merge_cond) {
                disu_periods_dis.put(start_tm_1 + "_" + end_tm_2, start_dist_1 + "_" + end_dist_2 + "&" + start_index_1 + "_" + end_index_2)
                merge_tm += start_tm_1
                merge_tm += end_tm_2
                flag = false
              }
              if (!merge_cond && j == i + 1) {
                disu_periods_dis.put(start_tm_1 + "_" + end_tm_1, start_dist_1 + "_" + end_dist_1 + "&" + start_index_1 + "_" + end_index_1)
              }
            }
            if (i + 1 == periods_arr.length && next_start_tm > max_tm) {
              disu_periods_dis.put(periods_arr(i), o_to_end_dist_arr(i) + "&" + merge_disu_index_arr(i))
            }
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    val orderly_map = disu_periods_dis.toList.sortBy(x => x._1)(Ordering.String)

    orderly_map.mkString("&&")
  })


  /**
   * 根据过滤条件得到的索引，删除停留时间段中不符合3个过滤 条件的停留时间段
   *
   * @return
   */
  def deleteRedundantDS = udf((deleCol: String, filter_index: String) => {
    val new_cols = new ListBuffer[String]()
    var res = ""
    try {
      if (strNotNull(filter_index)) {
        val filter_index_arr: Array[Int] = strHandle(filter_index, "\\|").map(_.toInt)
        val del_arr: Array[String] = strHandle(deleCol, "\\|")

        for (i <- 0 until del_arr.length) {
          if (!filter_index_arr.contains(i)) {
            new_cols += del_arr(i)
          }
        }
        res = new_cols.mkString("|")
      } else {
        res = deleCol
      }
    } catch {
      case e: Exception => ""
    }
    res
  })


  /**
   * 异常剔除的3个条件，拿到过滤条件的索引，对之前的打标字段进行fix修正
   * 1 低速终点与后一个有效点的距离大于4km
   * 2 低速起点 与 终点 均无有效点 且 低速距离 = 0
   * 3 低速段速度 大于30km/h
   * 入参：低速终点离有效点的距离 低速起点有效点经纬度 低速终点有效点经纬度 低速距离 低速段速度
   *
   * @return
   */
  def effiEndDist = udf((disu_periods_2: String, disu_dist_end: String, disu_start_coord_front: String, disu_end_coord_behind: String, disu_dis: String, disu_speed: String) => {
    val filter_index = new mutable.HashSet[String]()
    try {
      if (strNotNull(disu_periods_2)) {
        val disu_periods_2_arr: Array[String] = strHandle(disu_periods_2, "\\|")
        val disu_dist_end_arr: Array[String] = strHandle(disu_dist_end, "\\|")
        val disu_start_coord_front_arr: Array[String] = strHandle(disu_start_coord_front, "\\|")
        val disu_end_coord_behind_arr: Array[String] = strHandle(disu_end_coord_behind, "\\|")
        val disu_dis_arr: Array[String] = strHandle(disu_dis, "\\|")
        val disu_speed_arr: Array[String] = strHandle(disu_speed, "\\|")

        for (i <- 0 until disu_periods_2_arr.length) {
          if (disu_dist_end_arr(i).toDouble > 4000) filter_index.add(i.toString)
          if (disu_start_coord_front_arr(i) == "" && disu_end_coord_behind_arr(i) == "" && disu_dis_arr(i).toDouble == 0.0) filter_index.add(i.toString)
          if (disu_speed_arr(i).toDouble > 30) filter_index.add(i.toString)
        }
      }
    } catch {
      case e: Exception => ""
    }
    filter_index.mkString("|")
  })

  /**
   * 计算低速前后点 距离 上个or 下个有效点的距离
   *
   * @return
   */
  def coordsDist = udf((disu_start_coord_front: String, disu_start_coord: String) => {
    val near_dist_arr = new ListBuffer[String]()
    try {
      if (disu_start_coord_front.trim != "-" && strNotNull(disu_start_coord)) {
        val near_coords_arr = disu_start_coord_front.split("\\|")
        val self_coords_arr = disu_start_coord.split("\\|")
        for (i <- 0 until near_coords_arr.length) {
          if (strNotNull(near_coords_arr(i)) && strNotNull(self_coords_arr(i))) {
            near_dist_arr += lngLatToDistance(near_coords_arr(i).split(",")(0), near_coords_arr(i).split(",")(1), self_coords_arr(i).split(",")(0), self_coords_arr(i).split(",")(1)).toString
          } else {
            near_dist_arr += "999999"
          }
        }
      } else {
        near_dist_arr += "0"
      }
    } catch {
      case e: Exception => ""
    }
    near_dist_arr.mkString("|")
  })

  /**
   * 根据合并后的低速 索引 定位 jp_status
   * 索引往前寻找  往后寻找
   *
   * @return
   */
  def NearDistJPStatus = udf((disu_start_coord: String, disu_end_coord: String, jp_coords: String, jp_status: String) => {
    val jp_coords_near_bef = new ListBuffer[String]()
    val jp_coords_near_aft = new ListBuffer[String]()
    try {
      if (strNotNull(jp_status)) {
        val disu_start_coord_arr = disu_start_coord.split("\\|")
        val disu_end_coord_arr = disu_end_coord.split("\\|")
        val jp_coords_arr = jp_coords.split("\\|")
        val jp_status_arr = jp_status.split("\\|")

        for (i <- 0 until disu_start_coord_arr.length) {
          var flag_1 = true
          var start_near = "-"
          for (j <- 0 until jp_coords_arr.length if flag_1) {
            if (disu_start_coord_arr(i) == jp_coords_arr(j) && flag_1) {
              flag_1 = false
              breakable {
                for (k <- (0 until j + 1).reverse) {
                  if (jp_status_arr(k) == "0") {
                    start_near = jp_coords_arr(k)
                    break
                  }
                }
              }
            }
          }
          jp_coords_near_bef += start_near
        }
        for (i <- 0 until disu_end_coord_arr.length) {
          var flag_2 = true
          var end_near = "-"
          for (j <- (0 until jp_coords_arr.length).reverse if flag_2) {
            if (disu_end_coord_arr(i) == jp_coords_arr(j) && flag_2) {
              flag_2 = false
              breakable {
                for (k <- j + 1 until jp_status_arr.length if j + 1 <= jp_status_arr.length - 1) {
                  if (jp_status_arr(k) == "0") {
                    end_near = jp_coords_arr(k)
                    break
                  }
                }
              }
            }
          }
          jp_coords_near_aft += end_near
        }
      }
    } catch {
      case e: Exception => ""
    }
    jp_coords_near_bef.mkString("|") + "&" + jp_coords_near_aft.mkString("|")
  })

  def cntPeriods = udf((disu_periods_2: String) => {
    var cnt: Int = 0
    val rank = new ListBuffer[String]()
    try {
      if (strNotNull(disu_periods_2)) {
        val periods: Array[String] = strHandle(disu_periods_2, "\\|")
        cnt = periods.length
        for (i <- 0 until periods.length) {
          rank += i.toString
        }
      }
    } catch {
      case e: Exception => ""
    }
    cnt.toString + "&" + rank.mkString("|")

  })

  //对返回的5类数据切分
  def splitMultiFun(sep: String, fields: String) = udf((ds_tl_infos: String) => {
    var arr: Array[String] = Array()
    val res = new ArrayBuffer[String]()
    try {
      if (strNotNull(ds_tl_infos)) {
        arr = ds_tl_infos.replaceAll("\\(|\\)", "").split(sep)
        for (i <- 0 until arr.length) {
          if (fields == "disu_periods_2") res += arr(i).split(",")(0)
          if (fields == "disu_dis_ib") res += arr(i).split(",")(1).split("&")(0)
          if (fields == "merge_disu_index") res += arr(i).split(",")(1).split("&")(1)
        }
      }
    } catch {
      case e: Exception => ""
    }
    res.mkString("|")
  })

  //对返回的5类数据切分
  def splitFun(sep: String) = udf((ds_tl_infos: String) => {
    var res: Array[String] = Array()
    try {
      if (strNotNull(ds_tl_infos)) {
        res = strHandle(ds_tl_infos, sep)
      }
    } catch {
      case e: Exception => ""
    }
    res
  })

  //coords swid再加工
  def splitFirstLastFun(sep: String, flag: String) = udf((ds_tl_infos: String) => {
    var res: Array[String] = Array()
    val fl_res = new ArrayBuffer[String]()
    try {
      if (strNotNull(ds_tl_infos)) {
        val ds_tl_infos_arr: Array[String] = strHandle(ds_tl_infos, "\\|")
        for (i <- 0 until ds_tl_infos_arr.length) {
          res = ds_tl_infos_arr(i).split(sep)
          if (flag == "first") fl_res += res(0)
          if (flag == "last") fl_res += res(res.length - 1)
        }
      }
    } catch {
      case e: Exception => ""
    }
    fl_res.mkString("|")
  })

  def dsSpeed = udf((disu_dis: String, disu_duration: String) => {
    var speed = "" //km/h
    try {
      if (strNotNull(disu_dis) && strNotNull(disu_duration)) {
        val dis_arr = disu_dis.split("\\|")
        val duration_arr = disu_duration.split("\\|")
        speed = (dis_arr zip duration_arr map { x =>
          if (x._2.toDouble != 0) {
            (x._1.toDouble * 3.6 / x._2.toDouble).toString
          } else {
            "0"
          }
        }).mkString("|")
      }
    } catch {
      case e: Exception => ""
    }
    speed
  })

  def getSumDistCoordsSwidUDF = udf((merge_disu_index: String, sum_dist: String, jp_coords: String, jp_swid: String, speed: String) => {
    val merge_dist = new ListBuffer[String]()
    val diff_dist = new ListBuffer[String]()
    val jp_coords_p = new ListBuffer[String]()
    val jp_swid_p = new ListBuffer[String]()
    val speed_p = new ListBuffer[String]()

    try {
      if (strNotNull(merge_disu_index) && strNotNull(sum_dist) && strNotNull(jp_coords) && strNotNull(jp_swid)) {
        val indexs: Array[String] = strHandle(merge_disu_index, "\\|")
        val sum_dist_arr: Array[String] = strHandle(sum_dist, "\\|")
        val jp_coords_arr: Array[String] = strHandle(jp_coords, "\\|")
        val jp_swid_arr: Array[String] = strHandle(jp_swid, "\\|")
        val speed_arr: Array[String] = strHandle(speed, "\\|")
        for (index <- indexs) {
          val start_index = index.split("_")(0).toInt
          val end_index = index.split("_")(1).toInt
          merge_dist += (sum_dist_arr(start_index) + "_" + sum_dist_arr(end_index))
          diff_dist += (sum_dist_arr(end_index).toDouble - sum_dist_arr(start_index).toDouble).toString
          if (end_index + 1 < jp_coords_arr.length - 1) {
            jp_coords_p += jp_coords_arr.slice(start_index, end_index + 1).mkString(";") //同个停留时段内的 经纬度集合用;分割  不应用自带的 | 分割
            jp_swid_p += jp_swid_arr.slice(start_index, end_index + 1).mkString(";")
            speed_p += speed_arr.slice(start_index, end_index + 1).mkString(";")
          } else {
            jp_coords_p += jp_coords_arr.slice(start_index, jp_coords_arr.length - 1).mkString(";") //同个停留时段内的 经纬度集合用;分割  不应用自带的 | 分割
            jp_swid_p += jp_swid_arr.slice(start_index, jp_swid_arr.length - 1).mkString(";")
            speed_p += speed_arr.slice(start_index, jp_swid_arr.length - 1).mkString(";")
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    //结果包含5部分信息：sum_dist 拼接 & sum_dist 取差值 & jp_coords截取部分拼接 & jp_swid 截取部分拼接 & 速度speed 截取部分拼接
    merge_dist.mkString("|") + "&" + diff_dist.mkString("|") + "&" + jp_coords_p.mkString("|") + "&" + jp_swid_p.mkString("|") + "&" + speed_p.mkString("|")

  })

  /**
   * 合并后的低速时段 计算 时间间隔
   *
   * @return
   */
  def dsMergeperiodsUDF = udf((disu_periods_2: String) => {
    val ds_durations = new ListBuffer[String]()
    try {
      if (strNotNull(disu_periods_2)) {
        val ds_tm: Array[String] = strHandle(disu_periods_2, "\\|")
        for (ds <- ds_tm) {
          val start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", ds.split("_")(0))
          val end_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", ds.split("_")(1))
          ds_durations += (end_tm - start_tm).toString
        }
      }
    } catch {
      case e: Exception => ""
    }
    ds_durations.mkString("|")
  })

  /**
   * 根据在低速时段内的停留时段的 index 获取对应的 停留点的 stay points
   *
   * @return
   */
  def getTLStaypointsUDF = udf((tl_in_disu_index: String, tl_stay_points: String, tl_durations: String) => {
    val points = new ListBuffer[String]()
    val durations = new ListBuffer[String]()
    try {
      if (strNotNull(tl_in_disu_index) && strNotNull(tl_stay_points)) {
        val index_arr: Array[String] = strHandle(tl_in_disu_index, "\\|")
        val points_arr: Array[String] = strHandle(tl_stay_points, "\\|")
        val dura_arr: Array[String] = strHandle(tl_durations, ",")
        for (index <- index_arr) {
          points += points_arr(index.toInt)
          durations += dura_arr(index.toInt)
        }
      }
    } catch {
      case e: Exception => ""
    }
    points.mkString("|") + "&" + durations.mkString("|")
  })

  /**
   * 自定义函数 实现停留时段 和 低速时段的合并 并找到纠偏时间中的 index
   *
   * @param fun
   * @return 结果包含5部分信息：合并后的低速时段 & 停留段是否在低速时段内的标签 & 合并后的低速时段在纠偏中的最近时间段的索引信息 & 在低速时段内的停留时间段 & 在在低速时段内的停留时间段对应的索引（取经纬度）
   */
  def dsMergeTlUDF(fun: (String, String) => Long, sep: String) = udf((ds: String, tl: String, jp_time: String) => {
    val ds_arr: Array[String] = strHandle(ds, sep)
    val tl_arr: Array[String] = strHandle(tl, ",").toSeq.toSet.toArray.sortWith((x1, x2) => x1 <= x2)
    val jp_time_arr: Array[String] = strHandle(jp_time, "\\|", false) //false 表示需要排序
    val max_tl = new mutable.HashSet[String]()

    val ds_start_to_end = new ListBuffer[String]() //低速 和 停留时间合并后的结果
    val tl_in_ds_index = new ListBuffer[String]() //停留时间在低速时间内的索引，用于取经纬度
    val tl_in_ds_time = new ListBuffer[String]() //停留时间在低速时间内的时间
    val if_tingliu_in_disu: Array[String] = new Array[String](ds_arr.length)

    try {
      //合并 低速 和 停留时间
      if (ds_arr.length > 0 && tl_arr.length == 0) {
        for (i <- 0 until ds_arr.length) {
          ds_start_to_end += ds_arr(i)
          if_tingliu_in_disu(i) = "0"
        }
      }
      if (ds_arr.length > 0 && tl_arr.length > 0) {
        for (i <- 0 until ds_arr.length) {
          val ds_start = ds_arr(i).split("_")(0)
          val ds_end = ds_arr(i).split("_")(1)
          val max_tl_tm = if (max_tl.size == 0) "0" else max_tl.max
          breakable {
            for (j <- 0 until tl_arr.length) {
              if (tl_arr(j) > max_tl_tm || tl_arr(j) == tl_arr(tl_arr.length - 1)) {
                val tl_start = tl_arr(j).split("_")(0)
                val tl_end = tl_arr(j).split("_")(1)
                if (ds_start <= tl_start && tl_end <= ds_end) {
                  ds_start_to_end += ds_start + "_" + ds_end
                  tl_in_ds_index += j.toString
                  tl_in_ds_time += tl_arr(j)
                  if_tingliu_in_disu(i) = "1"
                  max_tl += tl_arr(j)
                  break
                } else if (ds_start <= tl_start && tl_start <= ds_end && ds_end <= tl_end) {
                  ds_start_to_end += ds_start + "_" + tl_end
                  tl_in_ds_time += tl_arr(j)
                  if_tingliu_in_disu(i) = "1"
                  max_tl += tl_arr(j)
                  break
                } else if (tl_start <= ds_start && ds_start <= tl_end && tl_end <= ds_end) {
                  ds_start_to_end += tl_start + "_" + ds_end
                  tl_in_ds_time += tl_arr(j)
                  if_tingliu_in_disu(i) = "1"
                  max_tl += tl_arr(j)
                  break
                } else if (j == tl_arr.length - 1) {
                  ds_start_to_end += ds_start + "_" + ds_end
                  tl_in_ds_time += "-"
                  if_tingliu_in_disu(i) = "0"
                  break
                }
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    //传入合并后的起始结束时间 纠偏时间集合
    val start_index_arr = getStartEndIndexFromJPTime(ds_start_to_end, jp_time_arr, fun)._1
    val end_index_arr = getStartEndIndexFromJPTime(ds_start_to_end, jp_time_arr, fun)._2

    val start_end_index_arr = start_index_arr.zip(end_index_arr) map { x => x._1 + "_" + x._2 }
    //结果包含5部分信息：合并后的低速时段 & 停留段是否在低速时段内的标签 & 合并后的低速时段在纠偏中的最近时间段的索引信息 & 在低速时段内的停留时间段 & 在在低速时段内的停留时间段对应的索引（取经纬度）
    ds_start_to_end.mkString("|") + "&" + if_tingliu_in_disu.mkString("|") + "&" + start_end_index_arr.mkString("|") + "&" + tl_in_ds_time.mkString("|") + "&" + tl_in_ds_index.mkString("|")
  })

  /**
   * 合并后的低速时段 在jp_time中找到时间最近的起始 和 结束 时间的index
   *
   * @param ds_start_to_end
   * @param jp_time_arr
   * @param fun
   * @return
   */
  def getStartEndIndexFromJPTime(ds_start_to_end: ListBuffer[String], jp_time_arr: Array[String], fun: (String, String) => Long): (ArrayBuffer[Int], ArrayBuffer[Int]) = {
    val ds_times = ds_start_to_end.flatMap(_.split("_")).map(fun("yyyy-MM-dd HH:mm:ss", _)).sortWith(_.compareTo(_) < 0)
    val start_index_arr = new ArrayBuffer[Int]()
    val end_index_arr = new ArrayBuffer[Int]()

    if (ds_start_to_end.length > 0 && jp_time_arr.length > 0) {
      for (i <- 0 until ds_times.length) {
        if (i % 2 == 0) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                start_index_arr += 0
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                start_index_arr += jp_time_arr.length - 1
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  start_index_arr += j
                } else {
                  start_index_arr += j + 1
                }
                break
              }
            }
          }
        }
        if (i % 2 == 1) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                end_index_arr += 0
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                end_index_arr += jp_time_arr.length - 1
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  end_index_arr += j
                } else {
                  end_index_arr += j + 1
                }
                break
              }
            }
          }
        }
      }
    }
    (start_index_arr, end_index_arr)
  }

  /**
   * 字段拆解 疫情 和 其他
   *
   * @return
   */
  def parseEventInfo = udf((rt_event_info: String) => {
    val epi_codes = new ArrayBuffer[String]()
    val epi_points = new ArrayBuffer[String]()
    val epi_swids = new ArrayBuffer[String]()

    val other_codes = new ArrayBuffer[String]()
    val other_points = new ArrayBuffer[String]()
    val other_swids = new ArrayBuffer[String]()
    try {
      if (strNotNull(rt_event_info)) {
        val str = JSON.parseArray(rt_event_info)
        for (i <- 0 until str.size()) {
          val event_orCode = str.getJSONObject(i).getString("event_orCode")
          val event_points = str.getJSONObject(i).getString("event_xy1") + ";" + str.getJSONObject(i).getString("event_xy2")
          val event_swids = str.getJSONObject(i).getString("event_swids")
          if (event_orCode == "0,0,6,16" || event_orCode == "1,1,6,16") {
            epi_codes += event_orCode
            epi_points += event_points
            epi_swids += event_swids
          }
          if (event_orCode != "0,0,6,16" && event_orCode != "1,1,6,16") {
            other_codes += event_orCode
            other_points += event_points
            other_swids += event_swids
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    epi_codes.mkString("|") + "&" + epi_points.mkString("|") + "&" + epi_swids.mkString("|") + "&" + other_codes.mkString("|") + "&" + other_points.mkString("|") + "&" + other_swids.mkString("|")
  })

  def repEmptyArr(org_str: String, repEmpty_arr: Array[String]): Array[String] = {
    try {
      if (strHandle(org_str, "\\|").length != 0) strHandle(org_str, "\\|") else repEmpty_arr
    } catch {
      case e: Exception => ""
        repEmpty_arr
    }
  }

  def strHandle(str: String, sep: String, flag: Boolean = true): Array[String] = {
    var res: Array[String] = Array()
    try {
      if (flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep)
      //是否需要排序
      if (!flag && str.replaceAll("\\[|\\]", "").trim != "") res = str.replaceAll("\\[|\\]", "").trim.split(sep).sortWith(_.compareTo(_) < 0)
    } catch {
      case e: NullPointerException => ""
      case e: ArrayIndexOutOfBoundsException => ""
    }
    res
  }

  def strNotNull(str: String): Boolean = {
    try {
      str.trim != "" && str.nonEmpty && str.replaceAll("\\|", "").trim != ""
    } catch {
      case e: NullPointerException =>
        false
    }
  }
}

