package com.sf.app.pns

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.SparkBuilder

/**
 * @task_id:
 * @description: 每个月更新一次最新数据
 * @demander:
 * @author 01418539 caojia
 * @date 2023/1/11 10:30
 */
object LoadLineFrombdpTohive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")

    val inc_day = args(0)
    val fileN = args(1)
    val run_flag = args(2)
    if (run_flag == "1") csv2Hive(spark, fileN, inc_day)
    if (run_flag == "2") backJzxl(spark)
    if (run_flag == "3") copbackJzxl(spark)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def copbackJzxl(spark: SparkSession): Unit = {
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_stdline_jzxl_dtl limit 0""").schema.map(_.name).map(col)

    val o_jzxl = spark.sql("""select * from dm_gis.gis_eta_stdline_jzxl_dtl_tmp""")
      .withColumn("inc_day", lit("20230307"))
      .select(res_cols: _*)
    writeToHive(spark, o_jzxl, Seq("inc_day"), "dm_gis.gis_eta_stdline_jzxl_dtl")
  }


  def backJzxl(spark: SparkSession): Unit = {
    val res_cols = spark.sql("""select * from dm_gis.gis_eta_stdline_jzxl_dtl_tmp limit 0""").schema.map(_.name).map(col)

    val o_jzxl = spark.sql("""select * from dm_gis.gis_eta_stdline_jzxl_dtl""")
      .withColumn("inc_day", lit("20230307"))
      .select(res_cols: _*)
    writeToHive(spark, o_jzxl, Seq("inc_day"), "dm_gis.gis_eta_stdline_jzxl_dtl_tmp")
  }


  def csv2Hive(spark: SparkSession, fileN: String, inc_day: String): Unit = {
    val inputPath = "/user/01418539/upload/file/jz/" + fileN

    val res_cols = spark.sql("""select * from dm_gis.gis_eta_stdline_jzxl_dtl limit 0""").schema.map(_.name).map(col)

    val o_jzxl = spark.read
      .option("header", "false")
      .option("delimiter", "\\t")
      .option("encoding", "utf-8") //utf-8 gbk
      .option("inferSchema", true.toString)
      .csv(inputPath)
      .toDF("taskid", "url", "avg_act_dist", "avg_act_toll", "avg_act_distcost", "avg_act_cost", "avg_hundred_oil", "avg_highway_dis", "zy", "line_time", "linemload", "task_code", "route_mload", "spt", "ept", "plan_dis", "plan_hundred_oil", "plan_oilcost", "plan_toll", "plan_allcost", "plan_time", "act_shape", "ft_coords", "plan_highway_dis", "plan_charge_dis", "trafficlightcout", "vehicle", "linemload_frequency", "vehicle_frequency", "min_act_dist", "max_act_dist", "min_act_toll", "max_act_toll", "min_act_distcost", "max_act_distcost", "min_act_cost", "max_act_cost", "avg_act_time", "max_act_time", "min_act_time", "model_type", "total_weight", "label", "evaluation_results", "task_subid", "s_highway_dis", "s_highway_speed", "s_highway_links", "e_highway_dis", "e_highway_speed", "e_highway_links", "cost_sort", "cost_sort_level", "highway_dis_percent", "mileage_interval", "avg_tolls_fromtb", "is_original_line", "remove_label", "rectify_url", "route_source", "top3_route", "source_summary", "route_frequence", "route_grade_percent", "lineid", "vehicle_type", "req_time", "weight", "mload", "height", "axle_weight", "length", "axle_number", "emit_stand", "width", "energy", "plate_color", "jy_hundred_oil", "src_toll", "src_oilcost", "src_allcost", "route_plate", "plate_axis", "jy_routeid", "zy_frequence", "road_closure_information", "new_sort", "low_grade_road_dis", "non_highway_dis", "save_cost_label", "frequence_label", "cost_percent_label", "timeout_label", "multisegment_label", "cost_label", "forbidden_label")
      .na.fill("")
      //      .filter(col("taskid") =!= "taskId")
      .filter(col("avg_act_dist") =!= "avg_act_dist")
      //      .filter(col("url") =!= "url")
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*).persist()
    logger.error(">>加载的数据总量>>>>>>" + o_jzxl.count())
    writeToHive(spark, o_jzxl, Seq("inc_day"), "dm_gis.gis_eta_stdline_jzxl_dtl")
  }

}
