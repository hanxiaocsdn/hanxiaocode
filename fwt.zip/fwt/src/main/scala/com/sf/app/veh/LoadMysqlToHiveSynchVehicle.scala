package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.getFlameDevMysqlConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}

/**
 * @description: 449460
 * @author 01418539 caojia 新增从mysql同步 mysqlvehicle_plate_color（车牌颜色字段）
 * @date 2022/6/17 17:56
 */
object LoadMysqlToHiveSynchVehicle extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
//    queryFlameMysql("tt_device_relation")
    insertToHive(spark,"tt_device_relation","tt_device_relation")
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def insertToHive(spark: SparkSession, table_name: String, inc_day: String): Unit = {
    val arr = table_name.replaceAll("'", "").split(",")
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      loadDeviceMysqlToHive(spark, tableName, tableName)
    }
  }

  def loadDeviceMysqlToHive(spark: SparkSession, mysqlTable: String, hiveTable: String): Unit = {
    val hive_table_struct: String = spark.sql(s"select * from dm_gis.$hiveTable limit 1").schema.toList.map(_.name).mkString(",")
    val query_state = s"(select id,car_id,device_id,bind_time,unbind_time,device_type,car_type,create_time,update_time,create_by,update_by,source,CAST(vehicle_plate_color AS UNSIGNED) AS vehicle_plate_color from $mysqlTable) as t"

    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://vmscore-s1.db.sfcloud.local:3306/vmscore?useUnicode=true&characterEncoding=utf-8",
      "user" -> "vmscore",
      "password" -> "vmscore123!@#",
      "dbtable" -> query_state
    )

    try {
      val df = spark.read.format("jdbc").options(params).load()
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        df.createOrReplaceTempView("tmpTableName") //临时表
        spark.sql("use dm_gis")
        spark.sql(s"insert overwrite table $hiveTable select * from tmpTableName")
      } else {
        throw new Exception(s"mysql的 $hiveTable 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $hiveTable 中 插入数据时出现错误", ex)
        throw ex
    }
  }

  def queryFlameMysql(table_name: String): Unit = {
    var connection: Connection = null
    val arr = table_name.replaceAll("'", "").split(",")
    //建表语句
    for (i <- 0 until arr.length) {
      connection = getFlameDevMysqlConnect()
      val tableName = arr(i)
      try {
        val cs = s"show create table $tableName"

        val cs_create: PreparedStatement = connection.prepareStatement(cs)
        val cs_res = cs_create.executeQuery()
        while (cs_res.next()) {
          val Table = cs_res.getString("Table")
          val Create = cs_res.getString("Create Table")
          logger.error("表：" + Table + "的建表语句为：" + Create)
        }
      } catch {
        case ex: Exception =>
          connection = getFlameDevMysqlConnect()
          val cs = s"show tables"
          val cs_create: PreparedStatement = connection.prepareStatement(cs)
          val cs_res = cs_create.executeQuery()
          while (cs_res.next()) {
            val tables = cs_res.getString("Tables_in_vmscore")
            logger.error("库：vmscore 中所有表为：" + tables)
          }

          logger.error(s"查看 $tableName 的建表语句时出现错误，请核对输入的表名在mysql中是否存在", ex)
          throw ex
      }
    }
  }

}
