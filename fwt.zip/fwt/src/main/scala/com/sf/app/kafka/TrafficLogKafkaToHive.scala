//package com.sf.app.kafka
//
//import com.sf.common.DataSourceCommon
//import com.sf.kafka.check.util.AuthUtil
//import kafka.serializer.StringDecoder
//import org.apache.spark.SparkConf
//import org.apache.spark.streaming.dstream.InputDStream
//import org.apache.spark.streaming.kafka.KafkaUtils
//import org.apache.spark.streaming.{Durations, StreamingContext}
//
///**
// * @description:
// * @author 01418539 caojia
// * @date 2022/3/19 16:52
// */
//object TrafficLogKafkaToHive extends DataSourceCommon {
//  def main(args: Array[String]): Unit = {
//    //    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
//    val conf = new SparkConf()
//      .setAppName(this.getClass.getSimpleName)
//      .set("spark.memory.storageFraction", "0.1")
//      .set("spark.memory.fraction", "0.6")
//      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
//    //    val spark = SparkSession.builder.config(conf).enableHiveSupport.getOrCreate
//    val streamingContext = new StreamingContext(conf, Durations.seconds(2))
//    streamingContext.sparkContext.setLogLevel("WARN")
//    //获取配置文件 topic等信息
//    //    val propertiesConf = ConfigFactory.load("conf/traffickafka.properties")
//    //    val clusterName = propertiesConf.getString("kafka.cluster")
//    //    val topicToken = propertiesConf.getString("kafka.topicToken")
//    //    val monitorUrl = propertiesConf.getString("kafka.monitorUrl")
//
//    val clusterName = "gis_rss_eta_loz97iq101"
//    val topicToken = "ETA_ACCIDENT_WARN_CONSUMER:pRMRbHfq"
//    val monitorUrl = "http://tkafka-gb3m2u8f-GIS-RSS-ETA.kafka.sfcloud.local:1080/mom-mon/monitor/requestService.pub"
//    val kafkaBrokers = AuthUtil.getBrokers(clusterName, topicToken, monitorUrl)
//    val topic = "GIS_RSS_ETA_ACCIDENT_WARN"
//    val groupid = "GIS_RSS_ETA_ACCIDENT_WARN_1"
//
//    val kafkaParam = Map(
//      "metadata.broker.list" -> kafkaBrokers,
//      "group.id" -> groupid
//    )
//    val topics = Set(topic)
//    /**
//     * User class threw exception: com.sf.kafka.check.KafkaCheckFailException: token check error,
//     * params: (RequestParams [values={cluster_name=gis_rss_eta_loz97iq101, validate_type=1, topic_tokens=ETA_ACCIDENT_WARN_CONSUMER:pRMRbHfq}])
//     */
//    val stream: InputDStream[(String, String)] = KafkaUtils.createDirectStream[String, String, StringDecoder, StringDecoder](streamingContext, kafkaParam, topics)
//    //    import spark.implicits._
//    stream.foreachRDD(rdd => {
//      if (rdd.count() > 0) {
//        rdd.map(x => {
//          val value = x._2
//          logger.info(value)
//          println(value)
//        })
//        //          .toDF("info")
//        //          .withColumn("inc_day", lit("20220101"))
//        //        res.createOrReplaceTempView("tmpTableName")
//        //        val sql = String.format(s"insert into table %s partition(inc_day) select * from %s", "dm_gis.gis_rss_eta_accident_warn", "tmpTableName")
//        //        logger.error(sql)
//        //        spark.sql(sql)
//        //        spark.catalog.dropTempView("tmpTableName")
//      }
//    })
//
//    streamingContext.start()
//    streamingContext.awaitTermination()
//
//  }
//
//}
