package com.sf.app.eta

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import org.apache.commons.math3.stat.descriptive.rank.Percentile
import utils.EtaUtil.calMultiQuantileUDF
//import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.HTTP_LINE_TIME_P
import org.apache.commons.math3.analysis.interpolation.LinearInterpolator
import org.apache.commons.math3.analysis.polynomials.PolynomialSplineFunction

import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{colTrimNotNull, splitFun, strNotNull}
import utils.DateUtil.{getInterDateListWithSep, getdaysBeforeOrAfter, timeToTimestampFormat}
import utils.EtaUtil.{extractCodeRlikeUDF, extractLinecodeRlikeUDF, getDepartTmBlockUDF}
import utils.{ColumnUtil, HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.math.BigDecimal.RoundingMode
import scala.util.Sorting
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 774511 （上游接口任务：776822 EfficientDurationDecisionStrategyPre） 月度执行 每月25号运行
 * @description: 时效定则策略：可提速价值线路及晚点线路挖掘 dm_gis.eta_line_speed_ac_mix_delay_mining_dtl
 * @demander:廖静文 01430321
 * @author 01418539 caojia
 * @date 2023/6/29 15:32
 */
object EfficientDurationDecisionStrategy extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val dest_tn = "dm_gis.eta_line_speed_ac_mix_delay_mining_dtl"
    //    val dest_tn = "dm_gis.eta_line_speed_ac_mix_delay_mining_dtl_tmp2"//临时执行 验证数据
    run(spark, inc_day, dest_tn)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, inc_day: String, dest_tn: String): Unit = {
    import spark.implicits._
    val section_num = Seq(95, 90, 85, 80, 75, 70, 65, 60, 55, 50, 45, 40, 35, 30, 25, 20, 15, 10, 5)
    //t == inc_day 对应的日期
    val days_29_aft = getdaysBeforeOrAfter(inc_day, 29) //t+29
    val days_29_bef = getdaysBeforeOrAfter(inc_day, -14) //t-29 用于任务运行周期拼接用

    //t-6 == inc_day 对应的日期
    val days_37_bef = getdaysBeforeOrAfter(inc_day, -37) //t-37
    val days_35_bef = getdaysBeforeOrAfter(inc_day, -35) //t-35
    val days_19_bef = getdaysBeforeOrAfter(inc_day, -29) //t-19
    val days_6_bef = getdaysBeforeOrAfter(inc_day, -6) //t-6
    val days_4_bef = getdaysBeforeOrAfter(inc_day, -4) //t-4

    //获取城市映射表
    val dm_adcode_df = spark.sql("""select city_name,city_code from dm_gis.dm_adcode_map_city_dtl group by city_name,city_code""") //获取城市映射表
    val dim_dept_df = spark.sql(s"""select belong_county city_name,dept_code city_code from dim.dim_dept_info_df where inc_day ='$inc_day' and dept_code like '%391%' and belong_county in ('济源市','焦作市')  group by dept_code,belong_county""")
    val city_map_df = dm_adcode_df.filter("city_code!='391'").union(dim_dept_df).persist(StorageLevel.MEMORY_AND_DISK_SER)

    //1 主表逻辑数据
    val main_point_df = getMainPointDF(spark, city_map_df, days_29_bef, inc_day, days_29_aft) //1获取基本任务信息 3min 246049
    val mian_part_df = main_point_df.select("id", "direction", "nonhighway_dist", "highway_dist", "nonhighway_speed", "line_time", "line_distance").repartition(200)
    val main_bc_df = main_point_df.select("id", "end_dept", "arrive_batch", "plan_arrive_tm").groupBy("id", "end_dept", "arrive_batch", "plan_arrive_tm")
      .agg(lit(true)).select("id", "end_dept", "arrive_batch", "plan_arrive_tm").persist(StorageLevel.MEMORY_AND_DISK_SER)
    //提前根据主表中的字段过滤
    val line_code_str = main_point_df.select("line_code").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    val id_str = main_point_df.select("id").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    val direction_str = main_point_df.select("direction").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    //2 次表逻辑加工
    //票件信息
    val votes_d_df = getTaskDetailDF(spark, line_code_str, days_35_bef, days_6_bef) //2 票件信息获取 2min  158259
    //时效近一个月
    val eta_29_df_t = getEtaTask29DF(spark, id_str, city_map_df, days_35_bef, days_6_bef) //3 29天时效信息获取 5min 4369174
    val eta_29_df = eta_29_df_t._1
    val eta_direct_df = eta_29_df_t._2
    //时效近半个月
    val eta_delay_14_df_t = getEtaTask14DF(spark, id_str, days_19_bef, days_6_bef) //4 14天时效信息获取 8min 159083
    val eta_delay_14_df = eta_delay_14_df_t._1
    val eta_delay_direct_df = eta_delay_14_df_t._2
    //全国328个全国流向
    val hy_500w_df = get500wDF(spark, direction_str, inc_day, days_37_bef, days_35_bef, days_6_bef, days_4_bef) //5 全国流向数据获取 5min
    val org_500w_df = hy_500w_df._1
    val qg_500w_df = hy_500w_df._2
    val hy_date_df = getHYRateDF(spark, mian_part_df, eta_direct_df.drop("line_distance", "inc_day"), qg_500w_df, section_num) //缓存数据合并加工 16min 244332
    //顺丰内部14w
    val sf_task_df = getSFTaskDF(spark, id_str, days_19_bef, days_6_bef)
    //获取上一班次数据
    val last_batch_df = getBanciDF(spark, main_bc_df, inc_day, days_29_aft) //6 班次数据获取 2min
    //3 计算
    val tmp_res_df = main_point_df
      .join(last_batch_df, Seq("id", "end_dept", "arrive_batch", "plan_arrive_tm"), "left")
      .join(votes_d_df, Seq("line_code"), "left")
      .join(eta_29_df, Seq("id"), "left")
      .join(eta_delay_14_df, Seq("id"), "left")
      .join(hy_date_df.drop("line_distance", "line_time"), Seq("id", "direction"), "left")
      .na.fill("", Seq("last_batch_arrive_tm", "plan_depart_tm", "nonhighway_dist", "nonhighway_speed"))
      .withColumn("last_batch_run_time", lastBatchRuntimeUDF('last_batch_arrive_tm, 'plan_depart_tm))
      .withColumn("last_batch_speed", when('last_batch_run_time > 0, ('line_distance * lit(60.0) / 'last_batch_run_time).cast("int")).otherwise("0"))
      .na.fill("", Seq("last_batch_run_time"))
      .withColumn("last_batch_highway_speed", lastBathHighwaySpeedUDF('last_batch_run_time, 'highway_dist, 'nonhighway_dist, 'nonhighway_speed))
      .persist(StorageLevel.MEMORY_AND_DISK)

    val rec_back_df = getTBBackDF(spark, tmp_res_df).persist(StorageLevel.MEMORY_AND_DISK)
    logger.info("提报接口返回的数据总量为:" + rec_back_df.count())
    val task_6_df = getRate6DF(spark, eta_delay_direct_df, rec_back_df)

    val this_batch_df = tmp_res_df
      .join(rec_back_df, Seq("id", "line_time"), "left")
      .withColumn("this_batch_speed", when('this_batch_run_time > 0, ('line_distance * lit(60.0) / 'this_batch_run_time).cast("int")).otherwise("0"))
      .withColumn("this_batch_highway_speed", lastBathHighwaySpeedUDF('this_batch_run_time, 'highway_dist, 'nonhighway_dist, 'nonhighway_speed))
      .persist(StorageLevel.MEMORY_AND_DISK)

    //4 结果输出
    val hy_improve_speed_df = this_batch_df.select("id", "direction", "this_batch_highway_speed", "last_batch_highway_speed", "last_batch_run_time", "depart_tm_block")
      .groupBy("direction")
      .agg(
        max("id") as "id",
        max("this_batch_highway_speed") as "this_batch_highway_speed",
        max("last_batch_highway_speed") as "last_batch_highway_speed",
        max("depart_tm_block") as "depart_tm_block",
        max("last_batch_run_time") as "last_batch_run_time"
      )

    val sf_improve_speed_df = this_batch_df.select("id", "this_batch_highway_speed", "last_batch_highway_speed", "last_batch_run_time", "depart_tm_block")
      .groupBy("id")
      .agg(
        max("this_batch_highway_speed") as "this_batch_highway_speed",
        max("last_batch_highway_speed") as "last_batch_highway_speed",
        max("depart_tm_block") as "depart_tm_block",
        max("last_batch_run_time") as "last_batch_run_time"
      )

    //行业500w和顺丰内部总数统计
    val hy_df = loadQGGSDirect(spark, org_500w_df, hy_improve_speed_df)
    val sf_df = loadSFGSDirect(spark, eta_direct_df, sf_improve_speed_df)

    val pressextends_infos_str = splitFun("&")('pressextends_infos)
    val filter_cond = (col("change_type") === "压缩" && col("time_press").cast("double") > 0.0) || (col("change_type") === "延长" && col("time_extend").cast("double") > 0.0)
    val nagtive_hy_cond = !(('last_batch.isNull || trim('last_batch) === "") || ('highway_dist.isNull || trim('highway_dist) === "" || 'highway_dist.cast("double") === 0.0) || 'last_batch_highway_speed.cast("double") < 0.0)
    val nagtive_sf_cond = !(('last_batch.isNull || trim('last_batch) === "") || 'last_batch_run_time.cast("double") <= 0.0)
    val t1_res_df = this_batch_df
      .join(hy_df, Seq("direction"), "left")
      .join(sf_df, Seq("id"), "left")
      .join(task_6_df, Seq("id"), "left")
      .join(sf_task_df, Seq("id"), "left")
      .withColumn("total_tasks_on_rate_1", when('total_tasks.cast("double") >= 0, 'total_tasks_on_1 / 'total_tasks).otherwise(0))
      .withColumn("total_tasks_on_rate_6", when('total_tasks.cast("double") >= 0, 'total_tasks_on_6 / 'total_tasks).otherwise(0))
      .na.fill("", Seq("line_distance", "hy_all_20", "hy_all_80", "line_time", "last_batch_run_time", "this_batch_run_time", "if_always_on", "total_tasks_on_rate_6", "improve_period", "top_20_this_batch_time", "top_80_this_batch_time", "top_20_last_batch_time", "top_20_line_time", "top_80_line_time"))
      .withColumn("top_20_line_time", topLineTime('line_distance, 'hy_all_20, 'line_time))
      .withColumn("top_80_line_time", topLineTime('line_distance, 'hy_all_80, 'line_time))
      .withColumn("top_20_last_batch_time", topLineTime('line_distance, 'hy_all_20, 'last_batch_run_time))
      .withColumn("top_20_this_batch_time", topLineTime('line_distance, 'hy_all_20, 'this_batch_run_time))
      .withColumn("top_80_this_batch_time", topLineTime('line_distance, 'hy_all_80, 'this_batch_run_time))
      //.na.fill("", Seq("if_always_on", "top_20_critical_time", "top_80_critical_time", "total_tasks_on_rate_6", "improve_period", "time_extend_type", "time_press_type"))
      //.withColumn("fd_lc_7_cols", concat_ws("&", 'if_always_on,'top_20_critical_time,'top_80_critical_time,'total_tasks_on_rate_6,'improve_period,'time_extend_type,'time_press_type))
      //.na.fill("", Seq("fd_lc_7_cols"))
      //.withColumn("line_code_label", lineCodeLabelUDF('if_always_on,'top_20_critical_time,'top_80_critical_time,'total_tasks_on_rate_6,'improve_period,'time_extend_type,'time_press_type))
      .withColumn("line_code_label", lit(""))

    //增加时间字段
    val add_top_time_cols = addTopTimeCols(col("line_distance"), section_num)
    val t2_res_df = t1_res_df.select(t1_res_df.schema.map(_.name).map(col) ++ add_top_time_cols: _*)
      .withColumn("critical_time", 'this_batch_run_time)
      .withColumn("top_80_critical_time", when('top_80_time < 'critical_time.cast("double"), "1").otherwise("0"))
      .withColumn("top_20_critical_time", when('top_20_time < 'critical_time.cast("double"), "1").otherwise("0"))
      .na.fill("", Seq("if_always_on", "rt_time_3", "critical_time", "line_time", "top_20_time", "top_80_time", "top_20_line_time", "top_80_line_time", "top_20_last_batch_time", "top_80_critical_time", "total_tasks_on_rate_6"))
      .withColumn("fds_11_cols", concat_ws("&", 'if_always_on, 'rt_time_3, 'critical_time, 'line_time, 'top_20_time, 'top_80_time, 'top_20_line_time, 'top_80_line_time, 'top_20_last_batch_time, 'top_80_critical_time, 'total_tasks_on_rate_6))
      .na.fill("", Seq("fds_11_cols"))
      .withColumn("pressextends_infos", pressOrExtends('fds_11_cols))
      .withColumn("change_type", pressextends_infos_str(0))
      .withColumn("time_press", pressextends_infos_str(1))
      .withColumn("time_extend", pressextends_infos_str(2))
      .withColumn("time_press_type", pressextends_infos_str(3))
      .withColumn("time_extend_type", pressextends_infos_str(4))
      //      .filter(filter_cond)
      .withColumn("improve_batch_trips", when(nagtive_hy_cond, 'improve_batch_trips).otherwise(0))
      .withColumn("improve_batch_days", when(nagtive_hy_cond && 'improve_batch_trips.cast("double") =!= 0.0, 'improve_batch_days).otherwise(0))
      .withColumn("improve_batch_trips_hour", when(nagtive_hy_cond, 'improve_batch_trips_hour).otherwise(0))
      .withColumn("improve_batch_days_hour", when(nagtive_hy_cond, 'improve_batch_days_hour).otherwise(0))
      .withColumn("sf_improve_batch_trips", when(nagtive_sf_cond, 'sf_improve_batch_trips).otherwise(0))
      .withColumn("sf_improve_batch_days", when(nagtive_sf_cond, 'sf_improve_batch_days).otherwise(0))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(s">>结果有效数据总量>>" + t2_res_df.count())
    val res_cols = spark.sql(s"""select * from $dest_tn limit 0""").schema.map(_.name).map(col)
    val blank_cols = addBlankColumn()
    val res_df = t2_res_df.select(t2_res_df.schema.map(_.name).map(col) ++ blank_cols: _*).withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)
    writeToHive(spark, res_df.coalesce(2), Seq("inc_day"), dest_tn)
  }

  def addTopTimeCols(line_distance: Column, section_num: Seq[Int]): Seq[Column] = {
    val name_cols = section_num.map("top_" + _ + "_time")
    val res_cols = section_num.map(x => col("hy_all_" + x)).map(y => when(y > 0, toIntWith(line_distance * lit(60.0) / y)))
    ColumnUtil.renameColumn(res_cols, name_cols)
  }

  def getTBBackDF(spark: SparkSession, tmp_res_df: DataFrame): DataFrame = {
    import spark.implicits._
    //时长提报接口获取
    val rec_tm_df = tmp_res_df.filter('if_always_on === "1").select("id", "line_time").groupBy("id", "line_time").agg(lit(true)).repartition(1)
    logger.error(">>>>需要时长提报数据总量>>>>>" + rec_tm_df.count())
    //    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "774511", "【时长决策】可加速线路及晚点数据挖掘", "时长接口", HTTP_LINE_TIME_P, "", rec_tm_df.count(), 1)
    val rec_back_df = rec_tm_df.map(row => {
      val id = row.getAs[String]("id")
      val line_time = row.getAs[Int]("line_time").toString
      var system_recommend_time = ""
      if (strNotNull(id) && strNotNull(line_time)) {
        system_recommend_time = postLineTime(id, line_time)
        Thread.sleep(100)
      }
      (id, line_time, system_recommend_time)
    }).toDF("id", "line_time", "system_recommend_time")
      .na.fill("", Seq("line_time", "system_recommend_time"))
      .withColumn("this_batch_run_time", thisBatchRunTimeUDF('line_time, 'system_recommend_time))
      .persist(StorageLevel.MEMORY_AND_DISK)
    //    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)
    logger.error(">>>>时长提报数据总量>>>>>" + rec_back_df.count())
    rec_back_df
  }

  def getRate6DF(spark: SparkSession, eta_delay_direct_df: DataFrame, rec_back_df: DataFrame): DataFrame = {
    import spark.implicits._
    val this_run_time_df = rec_back_df.groupBy("id").agg(first("this_batch_run_time") as "this_batch_run_time")
    val on_rate_1_cond = when('actual_run_time.cast("double") - 'this_batch_run_time.cast("double") <= 1.0, 'task_subid)
    val sub_on_rate_cond = when('actual_run_time_sub.cast("double") - 'this_batch_run_time.cast("double") <= 1.0, 'task_subid)
    val task_6_df = eta_delay_direct_df.select("id", "task_subid", "actual_run_time", "actual_run_time_sub")
      .join(this_run_time_df, Seq("id"))
      .withColumn("total_tasks_on_1", on_rate_1_cond)
      .withColumn("total_tasks_on_6", sub_on_rate_cond)
      .groupBy("id")
      .agg(
        count("total_tasks_on_1") as "total_tasks_on_1",
        count("total_tasks_on_6") as "total_tasks_on_6"
      )
      .select("id", "total_tasks_on_1", "total_tasks_on_6")
    task_6_df
  }

  def getHYRateDF(spark: SparkSession, mian_part_df: DataFrame, eta_direct_df: DataFrame, qg_500w_df: DataFrame, section_num: Seq[Int]): DataFrame = {
    import spark.implicits._
    val addcols_1 = addHYColums(spark, section_num)
    val aggcols_1 = aggHYColums(spark, section_num)
    val addcols_2 = addpropColumns(spark, section_num)
    val hy_all_infos_str = splitFun("&")('hy_all_infos)
    val hy_time_infos_str = splitFun("&")('hy_time_infos)

    val hy_500w_cols = Seq("id", "direction", "hy_highway_count", "can_rest_duration", "line_time_hy_top") ++ section_num.map("hy_highway_" + _) ++ section_num.map("hy_all_" + _) ++ section_num.map("hy_time_top" + _)

    val res_cols = (Seq("id", "direction") ++ section_num.map("hy_rate_on_" + _)).map(col)
    val p1_df = mian_part_df.join(qg_500w_df, Seq("direction"))
      .join(eta_direct_df, Seq("id", "direction"), "left")
      .withColumn("task_total_subid", lit(1))
      .na.fill("", Seq("highway_dist", "nonhighway_dist", "nonhighway_speed", "line_distance", "line_time"))
      .withColumn("hy_highway_sp", concat_ws("&", section_num.map("hy_highway_" + _).map(col): _*))
      .withColumn("hy_all_infos", gettop12spUDF('highway_dist, 'nonhighway_dist, 'nonhighway_speed, 'hy_highway_sp))
      .withColumn("hy_all_95", hy_all_infos_str(0))
      .withColumn("hy_all_90", hy_all_infos_str(1))
      .withColumn("hy_all_85", hy_all_infos_str(2))
      .withColumn("hy_all_80", hy_all_infos_str(3))
      .withColumn("hy_all_75", hy_all_infos_str(4))
      .withColumn("hy_all_70", hy_all_infos_str(5))
      .withColumn("hy_all_65", hy_all_infos_str(6))
      .withColumn("hy_all_60", hy_all_infos_str(7))
      .withColumn("hy_all_55", hy_all_infos_str(8))
      .withColumn("hy_all_50", hy_all_infos_str(9))
      .withColumn("hy_all_45", hy_all_infos_str(10))
      .withColumn("hy_all_40", hy_all_infos_str(11))
      .withColumn("hy_all_35", hy_all_infos_str(12))
      .withColumn("hy_all_30", hy_all_infos_str(13))
      .withColumn("hy_all_25", hy_all_infos_str(14))
      .withColumn("hy_all_20", hy_all_infos_str(15))
      .withColumn("hy_all_15", hy_all_infos_str(16))
      .withColumn("hy_all_10", hy_all_infos_str(17))
      .withColumn("hy_all_5", hy_all_infos_str(18))
      .withColumn("can_rest_duration", hy_all_infos_str(19))
      .withColumn("hy_time_infos", getFullSpeedWithoutRestUDF('highway_dist, 'nonhighway_dist, 'nonhighway_speed, 'line_distance, 'line_time, 'hy_highway_sp))
      .withColumn("hy_time_top95", hy_time_infos_str(0))
      .withColumn("hy_time_top90", hy_time_infos_str(1))
      .withColumn("hy_time_top85", hy_time_infos_str(2))
      .withColumn("hy_time_top80", hy_time_infos_str(3))
      .withColumn("hy_time_top75", hy_time_infos_str(4))
      .withColumn("hy_time_top70", hy_time_infos_str(5))
      .withColumn("hy_time_top65", hy_time_infos_str(6))
      .withColumn("hy_time_top60", hy_time_infos_str(7))
      .withColumn("hy_time_top55", hy_time_infos_str(8))
      .withColumn("hy_time_top50", hy_time_infos_str(9))
      .withColumn("hy_time_top45", hy_time_infos_str(10))
      .withColumn("hy_time_top40", hy_time_infos_str(11))
      .withColumn("hy_time_top35", hy_time_infos_str(12))
      .withColumn("hy_time_top30", hy_time_infos_str(13))
      .withColumn("hy_time_top25", hy_time_infos_str(14))
      .withColumn("hy_time_top20", hy_time_infos_str(15))
      .withColumn("hy_time_top15", hy_time_infos_str(16))
      .withColumn("hy_time_top10", hy_time_infos_str(17))
      .withColumn("hy_time_top5", hy_time_infos_str(18))
      .withColumn("line_time_hy_top", hy_time_infos_str(19))
      .drop("line_time")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val hy_500w_df = p1_df.withColumn("num", row_number().over(Window.partitionBy("id", "direction").orderBy("id", "direction")))
      .filter("num = 1")
      .select(hy_500w_cols.map(col): _*)
    val p2_df = p1_df.select(p1_df.schema.map(_.name).map(col) ++ addcols_1: _*)
      .groupBy("id", "direction").agg(aggcols_1.head, aggcols_1.tail: _*)
    val p3_df = p2_df.select(p2_df.schema.map(_.name).map(col) ++ addcols_2: _*).select(res_cols: _*)
      .join(hy_500w_df, Seq("id", "direction"), "left")
      .drop("line_distance")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>500w重货数据和线路时效合并标签数据总量>>>>" + p3_df.count())
    p3_df.show(2)
    p3_df
  }

  def get500wDF(spark: SparkSession, direction_str: String, inc_day: String, days_37_bef: String, days_35_bef: String, days_6_bef: String, days_4_bef: String): (DataFrame, DataFrame) = {
    import spark.implicits._
    val sp_infos_str = splitFun("&")('sp_infos)
    val qg_500w_sql =
      s"""
         |select * from (select row_number() over(partition by key_word order by time_highspeed_start_rep desc) as rank_num,*
         |from
         |(select un,highspeed_start_time,highspeed_start_hour,highspeed_end_time,concat(un,'_',highspeed_start_time,'_',highspeed_end_time) as key_word,city_start,city_end,direction,speed_highspeed_tl_2,time_highspeed_start_rep,inc_day
         |from dm_gis.eta_track_highway_detail_3d_with_328_city
         |where inc_day between '$days_37_bef' and '$days_4_bef'
         |  and cast(highspeed_dist_ratio as double) >= 0.8   -----------高速里程占比
         |  and cast(speed_highspeed_tl_2 as double) >= 50  -----------高速时速
         |  and cast(speed_highspeed_tl_2 as double) <= 120  ----------高速时速
         |  and cast(highspeed_dist as double) >= 50         -----------高速里程
         |  and cast(day_diff_duration as double) <= 60
         |  --and cast(wavg_road_track_continues_rate as double) >= 90
         |  --and cast(short_dist as double) < cast(highspeed_dist as double)
         |  and regexp_replace(time_highspeed_start_rep,'-','') between '$days_35_bef' and '$days_6_bef'
         |  and concat_ws('-',city_start,city_end) in ($direction_str)
         |  ) a ) b
         |  where rank_num=1
         |""".stripMargin
    //    logger.error(">>>外部全量500w数据加载的sql>>>>>" + qg_500w_sql)

    val org_qg_500w_df = spark.sql(qg_500w_sql).na.fill("", Seq("highspeed_start_hour", "speed_highspeed_tl_2")).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val qg_500w_df = org_qg_500w_df
      .groupBy("direction")
      .agg(
        count("key_word") as "hy_highway_count",
        concat_ws("|", collect_list("speed_highspeed_tl_2")) as "sp_hs_2"
      )
      .withColumn("sp_infos", calMultiQuantileUDF('sp_hs_2))
      .withColumn("hy_highway_95", sp_infos_str(0))
      .withColumn("hy_highway_90", sp_infos_str(1))
      .withColumn("hy_highway_85", sp_infos_str(2))
      .withColumn("hy_highway_80", sp_infos_str(3))
      .withColumn("hy_highway_75", sp_infos_str(4))
      .withColumn("hy_highway_70", sp_infos_str(5))
      .withColumn("hy_highway_65", sp_infos_str(6))
      .withColumn("hy_highway_60", sp_infos_str(7))
      .withColumn("hy_highway_55", sp_infos_str(8))
      .withColumn("hy_highway_50", sp_infos_str(9))
      .withColumn("hy_highway_45", sp_infos_str(10))
      .withColumn("hy_highway_40", sp_infos_str(11))
      .withColumn("hy_highway_35", sp_infos_str(12))
      .withColumn("hy_highway_30", sp_infos_str(13))
      .withColumn("hy_highway_25", sp_infos_str(14))
      .withColumn("hy_highway_20", sp_infos_str(15))
      .withColumn("hy_highway_15", sp_infos_str(16))
      .withColumn("hy_highway_10", sp_infos_str(17))
      .withColumn("hy_highway_5", sp_infos_str(18))
      .na.fill("", Seq("hy_highway_95", "hy_highway_90", "hy_highway_85", "hy_highway_80", "hy_highway_75", "hy_highway_70", "hy_highway_65", "hy_highway_60", "hy_highway_55", "hy_highway_50", "hy_highway_45", "hy_highway_40", "hy_highway_35", "hy_highway_30", "hy_highway_25", "hy_highway_20", "hy_highway_15", "hy_highway_10", "hy_highway_5"))
      .select("direction", "hy_highway_count", "hy_highway_95", "hy_highway_90", "hy_highway_85", "hy_highway_80", "hy_highway_75", "hy_highway_70", "hy_highway_65", "hy_highway_60", "hy_highway_55", "hy_highway_50", "hy_highway_45", "hy_highway_40", "hy_highway_35", "hy_highway_30", "hy_highway_25", "hy_highway_20", "hy_highway_15", "hy_highway_10", "hy_highway_5")
      .repartition(200).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>>>加载500w基准数据>>>>>" + qg_500w_df.count())
    qg_500w_df.show(2)
    (org_qg_500w_df, qg_500w_df)
  }

  def getBanciDF(spark: SparkSession, main_bc_df: DataFrame, inc_day: String, days_29_aft: String): DataFrame = {
    import spark.implicits._
    val banci_sql =
      s"""
         |select latest_arrival_tm,plan_main_id,dept_code,arrive_batch,send_batch,send_tm
         |from
         |  (
         |    select
         |      row_number() over(
         |        PARTITION by dept_code,
         |        send_batch,
         |        latest_arrival_tm,
         |        send_tm --新增去重字段
         |        ORDER by
         |          inc_day desc
         |      ) as rn,
         |      latest_arrival_tm,
         |      plan_main_id,
         |      dept_code,
         |      arrive_batch,
         |      send_batch,
         |      send_tm,--新增字段:发车时间
         |      inc_day
         |    from
         |      (
         |        select
         |          *
         |        from
         |          dm_pass_rss.scha_tt_plan_point_pro t
         |        where
         |          inc_day = '$inc_day'
         |          and regexp_replace(plan_run_dt,'-','') between '$inc_day' and '$days_29_aft'
         |          and latest_arrival_tm is not null and trim(latest_arrival_tm) != ''
         |          and send_batch is not null and trim(send_batch) != ''
         |          and job_type in ('1', '2', '3')
         |          and point_mean != 3
         |          and point_type = 1
         |      ) a
         |      inner join (
         |        SELECT id from dm_pass_rss.scha_tt_plan_main_pro
         |        where
         |          inc_day ='$inc_day'
         |          and oper_type in (1, 2)
         |        group by id
         |      ) b on a.plan_main_id = b.id
         |  ) t1
         |where
         |  rn = 1
         |""".stripMargin
    val banci_df = spark.sql(banci_sql).select("latest_arrival_tm", "dept_code", "send_batch", "send_tm").repartition(400)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>>>加载班次数据总量>>>>>" + banci_df.count())

    val cur_send_batch_df = main_bc_df
      .join(banci_df, expr("arrive_batch = send_batch"))
      .filter('plan_arrive_tm <= 'latest_arrival_tm)
      .withColumn("num", row_number().over(Window.partitionBy('id, 'dept_code, 'plan_arrive_tm, 'arrive_batch).orderBy('send_tm, 'latest_arrival_tm)))
      .filter("num = 1").selectExpr("id", "dept_code end_dept", "arrive_batch", "plan_arrive_tm", "send_tm send_tm_cur", "latest_arrival_tm latest_arrival_tm_cur")

    val last_batch_df = main_bc_df.select("id", "end_dept", "arrive_batch", "plan_arrive_tm")
      .join(banci_df.alias("b"), expr("end_dept = dept_code and arrive_batch != send_batch"))
      .join(cur_send_batch_df, Seq("id", "end_dept", "arrive_batch", "plan_arrive_tm"))
      .filter('latest_arrival_tm < 'latest_arrival_tm_cur && 'send_tm < 'send_tm_cur)
      .withColumn("num", row_number().over(Window.partitionBy("id", "end_dept", "arrive_batch", "plan_arrive_tm").orderBy('latest_arrival_tm.desc, 'send_tm)))
      .filter("num = 1").selectExpr("id", "end_dept", "arrive_batch", "plan_arrive_tm", "send_batch last_batch", "latest_arrival_tm last_batch_arrive_tm", "'中转' last_batch_category", "send_tm last_batch_send_tm")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(">>>>>>班次数据,加工完后的总量>>>>>" + last_batch_df.count())
    last_batch_df
  }

  def getSFTaskDF(spark: SparkSession, id_str: String, days_19_bef: String, days_6_bef: String): DataFrame = {
    import spark.implicits._
    //todo 临时用eta_task_track_sf eta_task_track_sf_all 的数据还未验证追齐
    val sf_task_sql =
      s"""select concat(line_code,'_',start_dept,'_',end_dept) id,highway_speed,highway_speed_tl_10_1,highway_speed_tl_10_2
         |from dm_gis.eta_task_track_sf
         |where inc_day between '$days_19_bef' and '$days_6_bef'
         |and concat(line_code,'_',start_dept,'_',end_dept) in ($id_str)""".stripMargin

    val res_cols = Seq("id", "actual_highway_speed94_m", "actual_highway_speed94_tm_m", "actual_highway_speed98_m", "actual_highway_speed98_tm_m", "actual_highway_speed94_qtl1_m", "actual_highway_speed94_qtl1_tm_m", "actual_highway_speed98_qtl1_m", "actual_highway_speed98_qtl1_tm_m", "actual_highway_speed94_qtl2_m", "actual_highway_speed94_qtl2_tm_m", "actual_highway_speed98_qtl2_m", "actual_highway_speed98_qtl2_tm_m").map(col)
    val highway_speed_list_infos_str = splitFun("&")('highway_speed_list_infos)
    val highway_speed_tl_10_1_list_infos_str = splitFun("&")('highway_speed_tl_10_1_list_infos)
    val highway_speed_tl_10_2_list_infos_str = splitFun("&")('highway_speed_tl_10_2_list_infos)
    val sf_task_df = spark.sql(sf_task_sql).na.fill("")
      .groupBy("id")
      .agg(
        concat_ws("|", collect_list('highway_speed)) as "highway_speed_list",
        concat_ws("|", collect_list('highway_speed_tl_10_1)) as "highway_speed_tl_10_1_list",
        concat_ws("|", collect_list('highway_speed_tl_10_2)) as "highway_speed_tl_10_2_list"
      )
      .withColumn("highway_speed_list_infos", calQuantile94_98UDF('highway_speed_list))
      .withColumn("highway_speed_tl_10_1_list_infos", calQuantile94_98UDF('highway_speed_tl_10_1_list))
      .withColumn("highway_speed_tl_10_2_list_infos", calQuantile94_98UDF('highway_speed_tl_10_2_list))
      .withColumn("actual_highway_speed94_m", highway_speed_list_infos_str(0))
      .withColumn("actual_highway_speed98_m", highway_speed_list_infos_str(1))
      .withColumn("actual_highway_speed94_tm_m", highway_speed_list_infos_str(2))
      .withColumn("actual_highway_speed98_tm_m", highway_speed_list_infos_str(3))
      .withColumn("actual_highway_speed94_qtl1_m", highway_speed_tl_10_1_list_infos_str(0))
      .withColumn("actual_highway_speed98_qtl1_m", highway_speed_tl_10_1_list_infos_str(1))
      .withColumn("actual_highway_speed94_qtl1_tm_m", highway_speed_tl_10_1_list_infos_str(2))
      .withColumn("actual_highway_speed98_qtl1_tm_m", highway_speed_tl_10_1_list_infos_str(3))
      .withColumn("actual_highway_speed94_qtl2_m", highway_speed_tl_10_2_list_infos_str(0))
      .withColumn("actual_highway_speed98_qtl2_m", highway_speed_tl_10_2_list_infos_str(1))
      .withColumn("actual_highway_speed94_qtl2_tm_m", highway_speed_tl_10_2_list_infos_str(2))
      .withColumn("actual_highway_speed98_qtl2_tm_m", highway_speed_tl_10_2_list_infos_str(3))
      .select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>顺丰内部15w标准速度获取的数据总量为>>>>>" + sf_task_df.count())

    sf_task_df
  }

  //p4 获取时效定则数据  ,
  def getEtaTask14DF(spark: SparkSession, id_str: String, days_19_bef: String, days_6_bef: String): (DataFrame, DataFrame) = {
    import spark.implicits._
    val eta_task_sql =
      s"""select * from
         |(select row_number() over (partition by task_subid order by inc_day desc) as rn,*
         |from (select line_code,start_dept,end_dept,task_subid,rt_dist,actual_run_time,ac_is_run_ontime,line_time,line_distance,
         |total_ob_tm,total_sub_tm,inc_day,
         |concat(line_code,'_',start_dept,'_',end_dept) as id,
         |concat(actual_run_time,'_',ac_is_run_ontime) as ac_run_ontime
         |from dm_gis.eta_std_line_recall_realtime_sub
         |where inc_day between '$days_19_bef' and '$days_6_bef'
         |and concat(line_code,'_',start_dept,'_',end_dept) in ($id_str)) a) b
         |where b.rn=1""".stripMargin
    //    logger.error(">>加载时效定则近15天数据>>>" + eta_task_sql)
    val o_eta_task_df_org = spark.sql(eta_task_sql).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
    //新增add 主观时长字段
    val actual_run_time_sub = calSubTime("actual_run_time")
    val actual_run_time_ob = calObjTime("actual_run_time")
    val actual_run_time_sub_ob = calSubObjTime("actual_run_time")
    //主观准点 和 主观晚点条件 actual_run_time_sub-line_time <= 1
    val task_delay_cond = when('ac_is_run_ontime === "0.0", 1).otherwise(0)
    val task_on_cond = when('ac_is_run_ontime === "1.0", 1).otherwise(0)
    val sub_on_rate_cond = when('actual_run_time_sub.cast("double") - 'line_time.cast("double") <= 1.0, 'task_subid)
    val obj_on_rate_cond = when('actual_run_time_ob.cast("double") - 'line_time.cast("double") <= 1.0, 'task_subid)
    val sub_obj_on_rate_cond = when('actual_run_time_sub_ob.cast("double") - 'line_time.cast("double") <= 1.0, 'task_subid)

    //晚点信息数 cond
    val delay_cond = 'ac_is_run_ontime === "0.0"
    val delay_cond1 = 'actual_run_time_sub.cast("double") / 60.0 >= 'actual_run_time.cast("double") - 'line_time.cast("double") - 1.0
    val delay_cond2 = 'actual_run_time_ob.cast("double") / 60.0 >= 'actual_run_time.cast("double") - 'line_time.cast("double") - 1.0
    val delay_cond3 = 'actual_run_time_sub_ob.cast("double") / 60.0 >= 'actual_run_time.cast("double") - 'line_time.cast("double") - 1.0

    //晚点时长标签
    val delay_tm = 'actual_run_time.cast("double") - 'line_time.cast("double") - 1.0
    val tasks_duration_1_cond = when(delay_cond && delay_tm > 0.0 && delay_tm <= 5.0, 'task_subid)
    val tasks_duration_2_cond = when(delay_cond && delay_tm > 5.0 && delay_tm <= 15.0, 'task_subid)
    val tasks_duration_3_cond = when(delay_cond && delay_tm > 15.0 && delay_tm <= 30.0, 'task_subid)
    val tasks_duration_4_cond = when(delay_cond && delay_tm > 30.0 && delay_tm <= 60.0, 'task_subid)
    val tasks_duration_5_cond = when(delay_cond && delay_tm > 60.0, 'task_subid)
    val eta_task_df = o_eta_task_df_org.select(o_eta_task_df_org.schema.map(_.name).map(col) ++ Seq(actual_run_time_sub, actual_run_time_ob, actual_run_time_sub_ob): _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val step1_eta_task_df = eta_task_df.withColumn("task_delay_subid", task_delay_cond)
      .withColumn("task_on_subid", task_on_cond)
      .withColumn("sub_on_subid", sub_on_rate_cond)
      .withColumn("obj_on_subid", obj_on_rate_cond)
      .withColumn("sub_obj_subid", sub_obj_on_rate_cond)
      .withColumn("tasks_sub", when(delay_cond && delay_cond1, 'task_subid))
      .withColumn("tasks_ob", when(delay_cond && !delay_cond1 && delay_cond2, 'task_subid))
      .withColumn("tasks_sub_ob", when(delay_cond && !delay_cond1 && !delay_cond2 && delay_cond3, 'task_subid))
      .withColumn("tasks_non", when(delay_cond && !delay_cond1 && !delay_cond2 && !delay_cond3, 'task_subid))
      .withColumn("tasks_duration_1", tasks_duration_1_cond)
      .withColumn("tasks_duration_2", tasks_duration_2_cond)
      .withColumn("tasks_duration_3", tasks_duration_3_cond)
      .withColumn("tasks_duration_4", tasks_duration_4_cond)
      .withColumn("tasks_duration_5", tasks_duration_5_cond)

    val qt_eta_df = step1_eta_task_df.select("id", "task_subid", "task_delay_subid", "task_on_subid", "sub_on_subid", "obj_on_subid", "sub_obj_subid",
      "tasks_sub", "tasks_ob", "tasks_sub_ob", "tasks_non", "tasks_duration_1", "tasks_duration_2", "tasks_duration_3", "tasks_duration_4", "tasks_duration_5", "inc_day")
      .groupBy("id", "inc_day")
      .agg(
        count("task_subid") as "task_cnt",
        sum("task_delay_subid") as "task_delay_cnt",
        sum("task_on_subid") as "task_on_cnt",
        count("sub_on_subid") as "sub_on_cnt",
        count("obj_on_subid") as "obj_on_cnt",
        count("sub_obj_subid") as "sub_obj_on_cnt",
        count("tasks_sub") as "tasks_sub_cnt",
        count("tasks_ob") as "tasks_ob_cnt",
        count("tasks_sub_ob") as "tasks_sub_ob_cnt",
        count("tasks_non") as "tasks_non_cnt",
        count("tasks_duration_1") as "tasks_duration_1_cnt",
        count("tasks_duration_2") as "tasks_duration_2_cnt",
        count("tasks_duration_3") as "tasks_duration_3_cnt",
        count("tasks_duration_4") as "tasks_duration_4_cnt",
        count("tasks_duration_5") as "tasks_duration_5_cnt"
      )
      .withColumn("task_date", concat_ws(":", 'inc_day, 'task_cnt))
      .withColumn("task_date_on", concat_ws(":", 'inc_day, 'task_delay_cnt))
      .groupBy("id")
      .agg(
        sum("task_cnt") as "total_tasks",
        sum("task_on_cnt") as "total_tasks_on",
        sum("sub_on_cnt") as "total_tasks_on_3",
        sum("obj_on_cnt") as "total_tasks_on_4",
        sum("sub_obj_on_cnt") as "total_tasks_on_5",
        sum("tasks_sub_cnt") as "tasks_sub",
        sum("tasks_ob_cnt") as "tasks_ob",
        sum("tasks_sub_ob_cnt") as "tasks_sub_ob",
        sum("tasks_non_cnt") as "tasks_non",
        sum("tasks_duration_1_cnt") as "tasks_duration_1",
        sum("tasks_duration_2_cnt") as "tasks_duration_2",
        sum("tasks_duration_3_cnt") as "tasks_duration_3",
        sum("tasks_duration_4_cnt") as "tasks_duration_4",
        sum("tasks_duration_5_cnt") as "tasks_duration_5",
        concat_ws("|", collect_list("task_date")) as "task_date",
        concat_ws("|", collect_list("task_date_on")) as "task_date_on",
        count("inc_day") as "task_days"
      )
      .na.fill("", Seq("task_date", "task_date_on"))
      .withColumn("task_date", getDateWithNumUDF('task_date, lit(days_19_bef), lit(days_6_bef)))
      .withColumn("task_date_on", getDateWithNumUDF('task_date_on, lit(days_19_bef), lit(days_6_bef)))
      .withColumn("task_period_on", concat_ws("-", lit(days_19_bef), lit(days_6_bef)))
      .withColumn("task_days_on", getTaskDateOnUDF('task_date_on))
      .withColumn("total_tasks_on_rate", when('total_tasks.cast("double") >= 0, 'total_tasks_on / 'total_tasks).otherwise(0))
      .withColumn("total_tasks_on_rate_3", when('total_tasks.cast("double") >= 0, 'total_tasks_on_3 / 'total_tasks).otherwise(0))
      .withColumn("total_tasks_on_rate_4", when('total_tasks.cast("double") >= 0, 'total_tasks_on_4 / 'total_tasks).otherwise(0))
      .withColumn("total_tasks_on_rate_5", when('total_tasks.cast("double") >= 0, 'total_tasks_on_5 / 'total_tasks).otherwise(0))
      .withColumn("if_always_on", when('task_days_on.cast("double") >= 7.0 && 'total_tasks_on_rate_3 < 0.5, "1").otherwise("0"))
      .withColumn("tasks_on", 'total_tasks_on)

    logger.error(">>>>时效近15天数据加工后的数据总量>>>>>" + qt_eta_df.count())
    qt_eta_df.show(2)
    (qt_eta_df, eta_task_df)
  }

  //p3 获取时效定则数据 ,
  def getEtaTask29DF(spark: SparkSession, id_str: String, city_map_df: DataFrame, days_35_bef: String, days_6_bef: String): (DataFrame, DataFrame) = {
    import spark.implicits._
    val rt_dist_qt_infos = splitFun("&")('rt_dist_qt)
    val rt_time_qt_infos = splitFun("&")('rt_time_qt)
    val rt_time_sub_qt_infos = splitFun("&")('rt_time_sub_qt)
    val rt_stay_time_qt_infos = splitFun("&")('rt_stay_time_qt)
    val rt_speed_list_infos_str = splitFun("&")('rt_speed_list_infos)
    val rt_speed_sub_list_infos_str = splitFun("&")('rt_speed_sub_list_infos)
    //单天25w左右
    val o_eta_task_sql =
      s"""select * from
         |(select row_number()  over (partition by task_subid order by inc_day desc) as rn,*
         |from (select line_code,start_dept,end_dept,task_subid,rt_dist,actual_run_time,ac_is_run_ontime,line_time,line_distance,
         |total_ob_tm,total_sub_tm,service_total_stay_time,inc_day,
         |0.06 * rt_dist/actual_run_time rt_speed,
         |concat(line_code,'_',start_dept,'_',end_dept) as id,
         |concat(actual_run_time,'_',ac_is_run_ontime) as ac_run_ontime
         |from dm_gis.eta_std_line_recall_realtime_sub
         |where inc_day between '$days_35_bef' and '$days_6_bef'
         |and concat(line_code,'_',start_dept,'_',end_dept) in ($id_str)
         |) a) b
         |where b.rn=1""".stripMargin
    //    logger.error(">>29天周期时效定则sql>>>" + o_eta_task_sql)
    val o_eta_task_df_org = spark.sql(o_eta_task_sql).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
    //新增 主观时长字段
    val actual_run_time_sub = calSubTime("actual_run_time")
    //主观准点 和 主观晚点条件 actual_run_time_sub-line_time <= 1
    val on_rate_cond = when('actual_run_time_sub.cast("double") - 'line_time.cast("double") <= 1.0, 1).otherwise(0)

    val eta_task_df = o_eta_task_df_org.select(o_eta_task_df_org.schema.map(_.name).map(col) :+ actual_run_time_sub: _*)
      .withColumn("rt_speed_sub", lit(0.06) * 'rt_dist.cast("double") / 'actual_run_time_sub.cast("double"))
      .withColumn("task_on_subid", when($"ac_is_run_ontime" === "1.0", 'task_subid))
      .withColumn("on_rate_cond", on_rate_cond)

    //算"task_subid", "rt_dist", "actual_run_time" 的分位值
    val qt_eta_df = eta_task_df.select("id", "task_subid", "task_on_subid", "rt_dist", "ac_run_ontime", "service_total_stay_time", "actual_run_time_sub", "on_rate_cond", "rt_speed", "rt_speed_sub")
      .groupBy("id")
      .agg(
        count("task_on_subid") as "task_on_num",
        count("task_subid") as "task_num",
        sum("on_rate_cond") as "on_rate_cnt",
        round(avg("service_total_stay_time") / lit(60), 4) as "actual_rest_duration_1",
        concat_ws("|", collect_list("rt_dist")) as "rt_dist_list",
        concat_ws("|", collect_list("ac_run_ontime")) as "ac_run_ontime_list",
        concat_ws("|", collect_list("service_total_stay_time")) as "service_total_stay_time_list",
        concat_ws("|", collect_list("actual_run_time_sub")) as "rt_time_sub_list",
        concat_ws("|", collect_list("rt_speed")) as "rt_speed_list",
        concat_ws("|", collect_list("rt_speed_sub")) as "rt_speed_sub_list"
      )
      .withColumn("task_on_num_kg", 'on_rate_cnt)
      .withColumn("on_rate_kg", when('task_on_num > 0, round('task_on_num_kg / 'task_on_num, 2)))
      .withColumn("rt_dist_qt", calQuantileUDF("1")(col("rt_dist_list")))
      .withColumn("rt_time_qt", calQuantileUDF("2")(col("ac_run_ontime_list")))
      .withColumn("rt_time_sub_qt", calQuantileUDF("1")(col("rt_time_sub_list")))
      .withColumn("rt_stay_time_qt", calAvgQuantileUDF(col("service_total_stay_time_list")))
      .withColumn("rt_speed_list_infos", calQuantile94_98UDF('rt_speed_list))
      .withColumn("rt_speed_sub_list_infos", calQuantile94_98UDF('rt_speed_sub_list))
      .withColumn("actual_speed94_m", rt_speed_list_infos_str(0)) //todo 新增字段
      .withColumn("actual_speed98_m", rt_speed_list_infos_str(1)) //todo 新增字段
      .withColumn("actual_speed94_tm_m", rt_speed_list_infos_str(2)) //todo 新增字段
      .withColumn("actual_speed98_tm_m", rt_speed_list_infos_str(3)) //todo 新增字段
      .withColumn("actual_speed94_kg_m", rt_speed_sub_list_infos_str(0)) //todo 新增字段
      .withColumn("actual_speed98_kg_m", rt_speed_sub_list_infos_str(1)) //todo 新增字段
      .withColumn("actual_speed94_kg_tm_m", rt_speed_sub_list_infos_str(2)) //todo 新增字段
      .withColumn("actual_speed98_kg_tm_m", rt_speed_sub_list_infos_str(3)) //todo 新增字段
      .withColumn("actual_rest_duration_2", rt_stay_time_qt_infos(0))
      .withColumn("actual_rest_duration_3", rt_stay_time_qt_infos(1))
      .withColumn("rt_dist_1", rt_dist_qt_infos(0))
      .withColumn("rt_dist_2", rt_dist_qt_infos(1))
      .withColumn("rt_dist_3", rt_dist_qt_infos(2))
      .withColumn("rt_dist_4", lit(""))
      .withColumn("rt_time_1", rt_time_qt_infos(0))
      .withColumn("rt_time_2", rt_time_qt_infos(1))
      .withColumn("rt_time_3", rt_time_qt_infos(2))
      .withColumn("rt_time_4", lit(""))
      .withColumn("rt_time_5", rt_time_qt_infos(6)) //todo 新增字段
      .withColumn("on_rate", when('task_num === 0, 0).otherwise('task_on_num / 'task_num))
      .withColumn("on_rate_1", rt_time_qt_infos(3))
      .withColumn("on_rate_2", rt_time_qt_infos(4))
      .withColumn("on_rate_3", rt_time_qt_infos(5))
      .withColumn("on_rate_4", when('task_num === 0, 0).otherwise('on_rate_cnt / 'task_num))
      .withColumn("rt_time_sub_1", rt_time_sub_qt_infos(0))
      .withColumn("rt_time_sub_2", rt_time_sub_qt_infos(1))
      .withColumn("rt_time_sub_3", rt_time_sub_qt_infos(2))
      .withColumn("rt_time_sub_4", lit(""))
      .withColumn("rt_time_sub_5", rt_time_sub_qt_infos(3)) //todo 新增字段
      .withColumn("run_time_recom", lit(""))
      .withColumn("speed_recom", lit(""))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>29天第1部分时效定则新增客观时长剔除字段后的数据总量为：>>>>" + qt_eta_df.count())
    qt_eta_df.show(2)
    //最后一部分字段单独计算
    val eta_direct_df = o_eta_task_df_org.select("id", "task_subid", "actual_run_time", "line_distance", "start_dept", "end_dept", "inc_day")
      .withColumn("start_city_code", extractCodeRlikeUDF('start_dept))
      .withColumn("end_city_code", extractCodeRlikeUDF('end_dept))
      .join(broadcast(city_map_df.selectExpr("city_code as start_city_code", "city_name start_city")), Seq("start_city_code"), "left")
      .join(broadcast(city_map_df.selectExpr("city_code as end_city_code", "city_name end_city")), Seq("end_city_code"), "left")
      .withColumn("start_city", when('start_city_code.like("%391%") && ('start_city.isNull || trim('start_city) === ""), "焦作市").otherwise('start_city))
      .withColumn("end_city", when('end_city_code.like("%391%") && ('end_city.isNull || trim('end_city) === ""), "焦作市").otherwise('end_city))
      .withColumn("direction", concat_ws("-", 'start_city, 'end_city))
      .select("id", "task_subid", "actual_run_time", "line_distance", "direction", "inc_day").repartition(200)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>29天第2部分时效定则最后一部分字段单独计算的数据总量为：>>>>" + qt_eta_df.count())
    eta_direct_df.show(2)
    (qt_eta_df, eta_direct_df)
  }

  //p2 任务明细表中获取【票件信息】数据 票件越多 线路越重要
  def getTaskDetailDF(spark: SparkSession, line_code_str: String, days_35_bef: String, days_6_bef: String): DataFrame = {
    import spark.implicits._
    val votes_d_sql =
      s"""select *
         |from
         |(select row_number() over (partition by task_id order by  inc_day desc)  as rn ,*
         |from
         |(select task_id,line_code,votes_d,inc_day
         |from dm_grd.grd_new_task_detail
         |where inc_day between '$days_35_bef' and '$days_6_bef'
         |and votes_d is not null and trim(votes_d)!=''
         |and line_code in ($line_code_str))a) b
         |where rn=1
         |""".stripMargin
    //    logger.error(">>任务明细表中获取票件信息>>" + votes_d_sql)
    val votes_d_df = spark.sql(votes_d_sql)
      .groupBy("line_code", "inc_day").agg(sum("votes_d") as "votes_d")
      .groupBy("line_code").agg(sum("votes_d") as "votes_d", count("inc_day") as "days")
      .withColumn("votes", when('days === 0, 0).otherwise(round('votes_d / 'days, 2)))
      .select("line_code", "votes").persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>任务明细表中获取票件总量为>>" + votes_d_df.count())
    votes_d_df.show(2)
    votes_d_df
  }

  //p1 获取公路运输涉及【线路明细】数据
  def getMainPointDF(spark: SparkSession, city_map_df: DataFrame, days_29_bef: String, inc_day: String, days_29_aft: String): DataFrame = {
    import spark.implicits._
    //30w条数据 2min
    //主表 dm_pass_rss.scha_tt_plan_main_pro 公路计划需求 单天5kw条数据
    //次表 dm_pass_rss.scha_tt_plan_point_pro 公路计划需求停靠点表 单天1亿条数据
    val main_cols_str = Seq("start_dept", "end_dept", "line_distance", "line_time", "line_code", "cvy_name", "task_area_code", "transport_level", "plan_run_dt", "table_id", "sort_num", "plan_arrive_tm", "arrive_batch", "send_batch", "plan_depart_tm", "last_arrive_tm", "job_type", "depart_tm_block", "id", "linecode_period", "start_city", "end_city", "direction", "task_period", "stop_stage", "start_city_bcjt", "end_city_bcjt", "is_stop", "line_speed")
    val main_point_sql =
      s"""select
         |  *
         |from
         |  (
         |    select
         |      lag(dept_code, 1) over(
         |        PARTITION BY id
         |        order by
         |          docking_sequence
         |      ) start_dept,--始发网点
         |      dept_code end_dept,--目的网点
         |      distance as line_distance,--配置里程
         |      times as line_time,--配置时长
         |      line_code,--线路编码
         |      cvy_name,--运力名称
         |      line_belongs_code as task_area_code,--归属地区
         |      transport_level,--运输等级
         |      plan_run_dt,--计划执行日期
         |      id as table_id,--日需求表id
         |      docking_sequence as sort_num,--次序
         |      arrive_tm as plan_arrive_tm,--计划到车时间
         |      arrive_batch,--到达班次
         |      lag(send_batch, 1) over(
         |        PARTITION BY id
         |        order by
         |          docking_sequence
         |      ) send_batch,--发出班次
         |      lag(send_tm, 1) over(
         |        PARTITION BY id
         |        order by
         |          docking_sequence
         |      ) plan_depart_tm,--计划发车时间
         |      lag(latest_arrival_tm, 1) over(
         |        PARTITION BY id
         |        order by
         |          docking_sequence
         |      ) last_arrive_tm,--最晚到车时间
         |      job_type--作业类型。1：装；2：卸；3：装卸；4：海关查验
         |    from
         |      (
         |        select
         |          a.id,
         |          a.line_code,
         |          a.cvy_name,
         |          a.line_belongs_code,
         |          a.transport_level,
         |          a.plan_run_dt,
         |          b.dept_code,
         |          b.docking_sequence,
         |          b.latest_arrival_tm,
         |          b.arrive_tm,
         |          b.arrive_batch,
         |          b.send_tm,
         |          b.send_batch,
         |          b.distance,
         |          b.times,
         |          b.job_type
         |        from
         |          (
         |            select
         |              id,
         |              omcs_line_code as line_code,
         |              cvy_name,
         |              line_belongs_code,
         |              transport_level,
         |              plan_run_dt
         |            from
         |              dm_pass_rss.scha_tt_plan_main_pro
         |            where
         |              inc_day = '$inc_day'   --inc_day
         |              and oper_type in (1, 2)
         |              and status != 3
         |              and transport_level in (1,2,3)
         |              and regexp_replace(plan_run_dt,'-','') between '$inc_day' and '$days_29_aft'  --inc_day+13
         |          ) a
         |          inner join (
         |            select
         |              plan_main_id,
         |              dept_code,
         |              docking_sequence,
         |              latest_arrival_tm,
         |              arrive_tm,
         |              arrive_batch,
         |              send_tm,
         |              send_batch,
         |              distance,
         |              times,
         |              job_type,
         |              point_type
         |            from
         |              dm_pass_rss.scha_tt_plan_point_pro
         |            where
         |              inc_day = '$inc_day'    --inc_day
         |              and regexp_replace(plan_run_dt,'-','') between '$inc_day' and '$days_29_aft'  --inc_day+13
         |          ) b on a.id = b.plan_main_id
         |        order by
         |          id,
         |          docking_sequence
         |      ) aa
         |  ) bb
         |where
         |  bb.start_dept is not null""".stripMargin
    //    logger.error(">>加载主表班次线路sql>>" + main_point_sql)
    val main_point_df = spark.sql(main_point_sql)
      .withColumn("num", row_number().over(Window.partitionBy('line_code, 'start_dept, 'end_dept).orderBy('plan_run_dt.desc)))
      .filter("num = 1").drop("num")
      .na.fill("", Seq("line_code"))
      //todo 新增拆经停起终网点字段
      .withColumn("start_city_code_bcjt", extractLinecodeRlikeUDF(1)('line_code))
      .withColumn("end_city_code_bcjt", extractLinecodeRlikeUDF(2)('line_code))
      .join(broadcast(city_map_df.selectExpr("city_code as start_city_code_bcjt", "city_name start_city_bcjt")), Seq("start_city_code_bcjt"), "left")
      .join(broadcast(city_map_df.selectExpr("city_code as end_city_code_bcjt", "city_name end_city_bcjt")), Seq("end_city_code_bcjt"), "left")
      .withColumn("start_city_bcjt", when('start_city_code_bcjt.like("%391%") && ('start_city_bcjt.isNull || trim('start_city_bcjt) === ""), "焦作市").otherwise('start_city_bcjt))
      .withColumn("end_city_bcjt", when('end_city_code_bcjt.like("%391%") && ('end_city_bcjt.isNull || trim('end_city_bcjt) === ""), "焦作市").otherwise('end_city_bcjt))
      .withColumn("start_city_code", extractCodeRlikeUDF('start_dept))
      .withColumn("end_city_code", extractCodeRlikeUDF('end_dept))
      .join(broadcast(city_map_df.selectExpr("city_code as start_city_code", "city_name start_city")), Seq("start_city_code"), "left")
      .join(broadcast(city_map_df.selectExpr("city_code as end_city_code", "city_name end_city")), Seq("end_city_code"), "left")
      .withColumn("start_city", when('start_city_code.like("%391%") && ('start_city.isNull || trim('start_city) === ""), "焦作市").otherwise('start_city))
      .withColumn("end_city", when('end_city_code.like("%391%") && ('end_city.isNull || trim('end_city) === ""), "焦作市").otherwise('end_city))
      .na.fill("", Seq("plan_depart_tm", "start_city", "end_city"))
      .withColumn("direction", concat_ws("-", 'start_city, 'end_city))
      .withColumn("depart_tm_block", getDepartTmBlockUDF('plan_depart_tm))
      .withColumn("id", concat_ws("_", 'line_code, 'start_dept, 'end_dept))
      .withColumn("linecode_period", concat_ws("-", lit(inc_day), lit(days_29_aft)))
      .withColumn("task_period", concat_ws("-", lit(days_29_bef), lit(inc_day))) //todo 任务周期待确认，半个月或者一个月周期，填充起始日期
      .withColumn("stop_stage", 'sort_num.cast("int") - 1)
      .withColumn("is_stop", when('stop_stage > 1, 1).otherwise(0))
      .withColumn("line_speed", round(lit(60.0) * 'line_distance.cast("double") / 'line_time.cast("double"), 2))
      .select(main_cols_str.map(col): _*)
      .filter('direction.isin("佛山市-东莞市")) //todo 测试单个流向 40条记录 1.2w , "北京市-北京市" "佛山市-东莞市", 40条
      .persist(StorageLevel.MEMORY_AND_DISK)

    //接口获取下道里程及其他相关信息
    val inter_post_df = spark.sql(s"""select id,nonhighway_dist,highway_dist,nonhighway_speed from dm_gis.eta_line_post_dist_sp_dtl where inc_day='$inc_day'""")
    //    val inter_post_df = spark.sql(s"""select id,nonhighway_dist,highway_dist,nonhighway_speed from dm_gis.eta_line_post_dist_sp_dtl where inc_day='$inc_day' and cast(highway_dist as double) > 0""")
    val last_main_df = main_point_df.join(inter_post_df, Seq("id")).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(">>加载的主表班次线路数据总量>>" + last_main_df.count())
    last_main_df.show(2, false)
    last_main_df
  }

  //空值填充 58个字段
  def addBlankColumn(): Seq[Column] = {
    val blank_cols = Seq("actual_highway_speed94_kg_m", "actual_highway_speed94_kg_tm_m", "actua_highway_speed98_kg_m", "actua_highway_speed98_kg_tm_m", "current_period", "last_batch_period", "imporve_period", "last_cvy", "last_cvy_arrive_tm", "last_cvy_category", "last_cvy_send_tm", "last_cvy_run_time", "last_cvy_speed", "last_cvy_highway_speed", "improve_cvy_trips", "improve_cvy_days", "improve_cvy_trips_hour", "improve_cvy_days_hour", "sf_improve_cvy_trips", "sf_improve_cvy_days", "plan_arrive_batch_f", "cvy_next_connection", "if_cross_batch", "no_match_reason", "highway_speed_recom", "speed_recom_trips", "speed_recom_days", "speed_recom_trips_hour", "speed_recom_days_hour", "total_tasks_on_2", "total_tasks_on_rate_2")
    ColumnUtil.renameColumn(blank_cols.map(x => lit("")), blank_cols)
  }

  def getDateWithNumUDF = udf((date: String, start_day: String, end_day: String) => {
    val res_dt = new ListBuffer[String]()
    val hm = collection.mutable.Map[String, String]()
    if (strNotNull(date)) {
      val org_arr = date.split("\\|")
      for (i <- 0 until org_arr.length) {
        hm.put(org_arr(i).split(":")(0), org_arr(i).split(":")(1))
      }
    }
    //遍历循环start_day 和 end_day之间的日期
    val date_arr = getInterDateListWithSep(start_day, end_day, "yyyyMMdd", "").split(",")
    for (dt <- date_arr) {
      val cnt = hm.getOrElse(dt, "0")
      res_dt += dt + ":" + cnt
    }
    res_dt.mkString("|")
  })

  def addHYColums(spark: SparkSession, section_num: Seq[Int]): Seq[Column] = {
    import spark.implicits._
    val multi_cols_str = section_num.map("hy_all_" + _)
    val hy_all_cols = multi_cols_str.map(col).map(x => when(('actual_run_time.cast("double") - lit(60.0) * 'line_distance.cast("double") / x) <= 1.0, 1).otherwise(0))
    ColumnUtil.renameColumn(hy_all_cols, multi_cols_str.map("task_" + _))
  }

  def aggHYColums(spark: SparkSession, section_num: Seq[Int]): Seq[Column] = {
    val multi_cols_str = Seq("total_subid") ++ section_num.map("hy_all_" + _)
    ColumnUtil.renameColumn(multi_cols_str.map("task_" + _).map(col).map(sum(_)), multi_cols_str.map(_ + "_cnt"))
  }

  def addpropColumns(spark: SparkSession, section_num: Seq[Int]): Seq[Column] = {
    val multi_cols_str = section_num.map("hy_all_" + _).map(_ + "_cnt")
    val res_cols_str = section_num.map("hy_rate_on_" + _)
    val front_cols = multi_cols_str.map(col).map(x => round(x / 'total_subid_cnt, 2))
    ColumnUtil.renameColumn(front_cols, res_cols_str)
  }

  //除去主观时长的剩余时长
  def calSubTime(time_col: String): Column = {
    //主观时长字段
    val res_cols_str = Seq("total_sub_tm")
    val sum_time = res_cols_str.map(col).map(x => when(x.isNotNull && trim(x) =!= "", x.cast(DoubleType)).otherwise(0.0)).foldLeft(lit(0.0))(_ + _) / lit(60.0)
    (col(time_col) - sum_time) as "actual_run_time_sub"
  }

  //客观时长的剩余时长
  def calObjTime(time_col: String): Column = {
    val obj_cols_str = Seq("total_ob_tm")
    val obj_sum_time = obj_cols_str.map(col).map(x => when(x.isNotNull && trim(x) =!= "", x.cast(DoubleType)).otherwise(0.0)).foldLeft(lit(0.0))(_ + _) / lit(60.0)
    (col(time_col) - obj_sum_time) as "actual_run_time_ob"
  }

  //除去主客观时长的剩余时长
  def calSubObjTime(time_col: String): Column = {
    //主观时长字段
    val sub_cols_str = Seq("total_sub_tm")

    val obj_cols_str = Seq("total_ob_tm")

    val sub_sum_time = sub_cols_str.map(col).map(x => when(x.isNotNull && trim(x) =!= "", x.cast(DoubleType)).otherwise(0.0)).foldLeft(lit(0.0))(_ + _) / lit(60.0)
    val obj_sum_time = obj_cols_str.map(col).map(x => when(x.isNotNull && trim(x) =!= "", x.cast(DoubleType)).otherwise(0.0)).foldLeft(lit(0.0))(_ + _) / lit(60.0)
    (col(time_col) - sub_sum_time - obj_sum_time) as "actual_run_time_sub_ob"
  }


  def getTaskDateOnUDF = udf((task_date_on: String) => {
    val cnt_hs = new mutable.HashSet[String]()
    if (strNotNull(task_date_on)) {
      val date_arr = task_date_on.split("\\|")
      for (i <- 0 until date_arr.length) {
        date_arr(i).split(":")(1).toInt match {
          case x if x > 0 => cnt_hs.add(date_arr(i).split(":")(0))
          case _ =>
        }
      }
    }
    cnt_hs.size.toString
  })


  def calQuantile94_98UDF = udf((sort_field: String) => {
    var res_fd = ""
    var time_94, time_98, time_94_del, time_98_del: Double = 0.0
    try {
      if (strNotNull(sort_field)) {
        val sort_field_arr = sort_field.split("\\|").filter(strNotNull(_) == true).map(_.toDouble)
        Sorting.stableSort(sort_field_arr)
        val del_2_arr = sort_field_arr.slice(2, sort_field_arr.size - 2)
        val qua_94_98 = calQuantile94_98(sort_field_arr, Array(0.94, 0.98)).split("&")
        val qua_94_98_del = calQuantile94_98(del_2_arr, Array(0.94, 0.98)).split("&")
        time_94 = qua_94_98(0).toDouble
        time_98 = qua_94_98(1).toDouble
        time_94_del = qua_94_98_del(0).toDouble
        time_98_del = qua_94_98_del(1).toDouble
        res_fd = time_94.formatted("%.4f") + "&" + time_98.formatted("%.4f") + "&" + time_94_del.formatted("%.4f") + "&" + time_98_del.formatted("%.4f")
      }
    } catch {
      case e: Exception => ""
    }
    res_fd
  })

  /**
   * 分位值类线性计算方法
   *
   * @param data
   * @param quant 至少传入2组数据
   */
  def calQuantile94_98(data: Array[Double], quant: Array[Double]): String = {
    // 计算分位数
    val pert = new Percentile()
    // 使用 LinearInterpolator 类执行线性插值
    val interpolator = new LinearInterpolator()

    val percts = quant.map(q => pert.evaluate(data, q * 100))
    val spfun: PolynomialSplineFunction = interpolator.interpolate(quant, percts)
    quant.map(spfun.value(_)).map(x => x.formatted("%.4f")).mkString("&")
  }


  def calQuantileUDF(flag: String) = udf((sort_field: String) => {
    var res_fd = ""
    var qt_94, std_94, qt_94_f2, qt_98_f2, on_rate_1, on_rate_2, on_rate_3: Double = 0.0
    if (strNotNull(sort_field)) {
      try {
        if (flag == "1") {
          val sort_field_arr = sort_field.split("\\|").filter(strNotNull(_) == true).map(_.toDouble)
          //底层归并排序
          Sorting.stableSort(sort_field_arr)
          val len = sort_field_arr.length
          // cond1 计算下四分位数 中位数 上四分位数
          val qt_1_4 = sort_field_arr((len - 1) / 4)
          val qt_mid = sort_field_arr(len / 2)
          val qt_3_4 = sort_field_arr((len - 1) * 3 / 4)
          val low_qt = qt_mid - 1.5 * (qt_3_4 - qt_1_4)
          val up_qt = qt_mid + 1.5 * (qt_3_4 - qt_1_4)
          //过滤范围后 计算94分位值
          val filter_arr = sort_field_arr.filter(x => x >= low_qt && x <= up_qt)
          qt_94 = calQuantile94_98(filter_arr, Array(0.94, 0.98)).split("&")(0).toDouble

          // cond2 计算均值 标准差
          val mean = sort_field_arr.sum / len
          val mean_sq = sort_field_arr.map(x => math.pow(x - mean, 2)).sum
          val std_dev = math.sqrt(mean_sq / len)
          val low_std = mean - 3 * std_dev
          val up_std = mean + 3 * std_dev
          //过滤范围后 计算94分位值
          val filter_arr_std = sort_field_arr.filter(x => x >= low_std && x <= up_std)
          std_94 = calQuantile94_98(filter_arr_std, Array(0.94, 0.98)).split("&")(0).toDouble

          // cond3 剔除最大的2个值以及最小的2个值 后计算94分位值
          val filter_arr_f2 = sort_field_arr.slice(2, len - 2)
          val quq_94_98 = calQuantile94_98(filter_arr_std, Array(0.94, 0.98)).split("&")

          qt_94_f2 = quq_94_98(0).toDouble
          qt_98_f2 = quq_94_98(1).toDouble
          res_fd = qt_94.formatted("%.4f") + "&" + std_94.formatted("%.4f") + "&" + qt_94_f2.formatted("%.4f") + "&" + qt_98_f2.formatted("%.4f")
        }
        //包含是否准点的参数判断
        if (flag == "2") {
          val sort_field_arr = sort_field.split("\\|").map(x => {
            val a = x.split("_")(0)
            val ontime = x.split("_")(1)
            (a, ontime)
          }).filter(y => strNotNull(y._1) == true).map(x => (x._1.toDouble, x._2)).sortBy(_._1)

          val len = sort_field_arr.length
          // cond1 计算下四分位数 中位数 上四分位数
          val qt_1_4 = sort_field_arr((len - 1) / 4)._1
          val qt_mid = sort_field_arr(len / 2)._1
          val qt_3_4 = sort_field_arr((len - 1) * 3 / 4)._1
          val low_qt = qt_mid - 1.5 * (qt_3_4 - qt_1_4)
          val up_qt = qt_mid + 1.5 * (qt_3_4 - qt_1_4)
          //过滤范围后 计算94分位值
          val filter_arr = sort_field_arr.filter(x => x._1 >= low_qt && x._1 <= up_qt)
          val len_filter = filter_arr.length
          val qt_ontime_cnt = filter_arr.filter(y => y._2 == "1.0").length
          qt_94 = calQuantile94_98(filter_arr.map(_._1), Array(0.94, 0.98)).split("&")(0).toDouble
          on_rate_1 = qt_ontime_cnt.toDouble / len_filter.toDouble

          // cond2 计算均值 标准差
          val mean = sort_field_arr.map(_._1).sum / len
          val mean_sq = sort_field_arr.map(_._1).map(x => math.pow(x - mean, 2)).sum
          val std_dev = math.sqrt(mean_sq / len)
          val low_std = mean - 3 * std_dev
          val up_std = mean + 3 * std_dev
          //过滤范围后 计算94分位值
          val filter_arr_std = sort_field_arr.filter(x => x._1 >= low_std && x._1 <= up_std)
          val len_filter_std = filter_arr_std.length
          val std_ontime_cnt = filter_arr_std.filter(y => y._2 == "1.0").length
          std_94 = calQuantile94_98(filter_arr_std.map(_._1), Array(0.94, 0.98)).split("&")(0).toDouble
          on_rate_2 = std_ontime_cnt.toDouble / len_filter_std.toDouble

          // cond3 剔除最大的2个值以及最小的2个值 后计算94分位值
          val filter_arr_f2 = sort_field_arr.slice(2, len - 2)
          val len_filter_f2 = filter_arr_f2.length
          val qt_f2_ontime_cnt = filter_arr_f2.filter(y => y._2 == "1.0").length

          val quq_94_98 = calQuantile94_98(filter_arr_f2.map(_._1), Array(0.94, 0.98)).split("&")

          qt_94_f2 = quq_94_98(0).toDouble
          on_rate_3 = qt_f2_ontime_cnt.toDouble / len_filter_f2.toDouble


          // cond4 剔除最大的2个值以及最小的2个值 后计算98分位值
          qt_98_f2 = quq_94_98(1).toDouble

          res_fd = qt_94.formatted("%.4f") + "&" + std_94.formatted("%.4f") + "&" + qt_94_f2.formatted("%.4f") + "&" + on_rate_1.formatted("%.4f") + "&" + on_rate_2.formatted("%.4f") + "&" + on_rate_3.formatted("%.4f") + "&" + qt_98_f2.formatted("%.4f")
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    res_fd
  })

  def calAvgQuantileUDF = udf((sort_field: String) => {
    var res_fd = ""
    var time_avg, time_94: Double = 0.0
    //里程 和 时间 service_total_stay_time
    if (strNotNull(sort_field)) {
      try {
        val sort_field_arr = sort_field.split("\\|").filter(strNotNull(_) == true).map(_.toDouble)
        Sorting.stableSort(sort_field_arr)
        val len = sort_field_arr.length
        val filter_arr = sort_field_arr.slice(2, len - 2)
        val len_filter = filter_arr.length
        // 去掉首尾算2个 均值和94分位数
        time_avg = filter_arr.sum / (len_filter * 60.0)

        // cond3 剔除最大的2个值以及最小的2个值 后计算94分位值
        val fenwei_arr = Array(0.94, 0.98)
        time_94 = calQuantile94_98(filter_arr, fenwei_arr).split("&")(0).toDouble
      } catch {
        case e: Exception => ""
      }
      res_fd = time_avg.formatted("%.2f") + "&" + time_94.formatted("%.2f")
    }
    res_fd
  })


  def gettop12spUDF = udf((highway_dist: String, nonhighway_dist: String, nonhighway_speed: String, hy_highway_sp: String) => {
    val hy_all_sp_ab = new ListBuffer[String]()
    var can_rest_duration = 0.0
    if (strNotNull(hy_highway_sp)) {
      val hy_dist = try {
        highway_dist.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val no_hy_dist = try {
        nonhighway_dist.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val no_hy_speed = try {
        nonhighway_speed.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val sp_arr = hy_highway_sp.split("&")
      for (i <- 0 until sp_arr.length) {
        val sp = try {
          sp_arr(i).toDouble
        } catch {
          case e: NumberFormatException => 0.0
        }

        val tm = hy_dist / sp + no_hy_dist / no_hy_speed
        val inter = (tm / 4.0).toInt
        if (i == 1) {
          can_rest_duration = inter * 20.0
        }
        val total_tm = tm + inter * 20.0 / 60.0
        val res_sp = (hy_dist + no_hy_dist) / total_tm
        hy_all_sp_ab += res_sp.formatted("%.2f")
      }
    }
    hy_all_sp_ab += can_rest_duration.toString
    hy_all_sp_ab.mkString("&")
  })

  /**
   *
   * 计算不加休息时间的全程时速
   *
   * @return
   */
  def getFullSpeedWithoutRestUDF = udf((highway_dist: String, nonhighway_dist: String, nonhighway_speed: String, line_distance: String, line_time: String, hy_highway_sp: String) => {
    val hy_all_sp_ab = new ListBuffer[String]()
    var line_time_hy_top = "top5以下"
    if (strNotNull(hy_highway_sp)) {
      val hy_dist = try {
        highway_dist.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val no_hy_dist = try {
        nonhighway_dist.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val no_hy_speed = try {
        nonhighway_speed.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val line_dist = try {
        line_distance.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val line_tm = try { //单位由秒转分钟
        line_time.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }
      val sp_arr = hy_highway_sp.split("&")
      for (i <- 0 until sp_arr.length) {
        val sp = try {
          sp_arr(i).toDouble
        } catch {
          case e: NumberFormatException => 0.0
        }
        val tm = hy_dist / sp + no_hy_dist / no_hy_speed
        val all_speed = (hy_dist + no_hy_dist) / tm
        if (all_speed > 0) hy_all_sp_ab += (line_dist * 60.0 / all_speed).formatted("%.2f")
        if (all_speed <= 0) hy_all_sp_ab += "0"
      }

      val labels = Seq("top95及以上", "top90-95", "top85-90", "top80-85", "top75-80", "top70-85", "top65-70", "top60-65", "top55-60", "top50-55", "top45-50", "top40-45", "top35-40", "top30-35", "top25-30", "top20-25", "top15-20", "top10-15", "top5-10")
      val zip_merge_arr = hy_all_sp_ab zip labels
      breakable {
        for (i <- 0 until zip_merge_arr.size) {
          if (line_tm >= hy_all_sp_ab(i).toDouble) {
            line_time_hy_top = zip_merge_arr(i)._2
            break()
          }
        }
      }
    }
    hy_all_sp_ab += line_time_hy_top
    hy_all_sp_ab.mkString("&")
  })

  /**
   * 时长提报
   *
   * @param lineCode
   * @param plan_time
   * @param src_zone_code
   * @param dest_zone_code
   * @return
   */
  def postLineTime(id: String, line_time: String): String = {
    var system_recommend_time = ""
    val line_code = id.split("_")(0)
    val start_dept = id.split("_")(1)
    val end_dept = id.split("_")(2)
    //将line_time 为70min 转为1H10M
    val add_line_time = line_time.toInt + 10
    var line_time_str = ""
    if (add_line_time / 60 != 0 && add_line_time % 60 != 0) {
      line_time_str = add_line_time / 60 + "H" + add_line_time % 60 + "M"
    } else if (add_line_time % 60 == 0) {
      line_time_str = add_line_time / 60 + "H"
    } else {
      line_time_str = add_line_time % 60 + "M"
    }
    val params =
      s"""{
         |    "srcDeptcode":"$start_dept",
         |    "destDeptcode":"$end_dept",
         |    "lineCode":"$line_code",
         |    "submissionPlanDuration":"$line_time_str"
         |  }""".stripMargin
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_LINE_TIME_P, params, 3, 2)
      logger.error("接口正常调用中,传入参数为>>" + params)
      val hw_str_json = JSON.parseObject(hw_str)
      val data = hw_str_json.getJSONObject("data")
      if (data != null) {
        system_recommend_time = data.getString("systemSuggestedTime")
      }
    } catch {
      case e: Exception => "" + e
    }
    system_recommend_time
  }

  def pressOrExtends = udf((fds_11_cols: String) => {
    val Array(if_always_on, rt_time_3, critical_time, line_time, top_20_time, top_80_time, top_20_line_time, top_80_line_time, top_20_last_batch_time, top_80_critical_time, total_tasks_on_rate_6) = fds_11_cols.split("&", -1).padTo(11, "").take(11).map(_.trim)
    var change_type, time_press, time_extend, time_press_type, time_extend_type = ""
    val rt_tm = if (strNotNull(rt_time_3)) rt_time_3.toDouble else 0.0
    val criti_tm = if (strNotNull(critical_time)) critical_time.toDouble else 0.0
    val line_tm = if (strNotNull(line_time)) line_time.toDouble else 0.0
    val top_80_tm = if (strNotNull(top_80_time)) top_80_time.toDouble else 0.0
    val top_20_tm = if (strNotNull(top_20_time)) top_20_time.toDouble else 0.0
    val total_tasks_on_rt = if (strNotNull(total_tasks_on_rate_6)) total_tasks_on_rate_6.toDouble else 0.0

    if (if_always_on == "1") {
      val filter_tm = Seq(criti_tm, rt_tm, top_80_tm).filter(x => x > line_tm && x <= criti_tm)
      if (filter_tm != null && filter_tm.size > 0) {
        val min_tm = try {
          filter_tm.min
        } catch {
          case e: Exception => 0.0
        }
        if (min_tm == criti_tm) {
          change_type = "延长"
          time_extend = (criti_tm - line_tm).formatted("%.2f")
          time_extend_type = "临界值延长"
        } else if (min_tm == rt_tm) {
          change_type = "延长"
          time_extend = (rt_tm - line_tm).formatted("%.2f")
          time_extend_type = "实际时长延长"
        } else if (min_tm == top_80_tm) {
          change_type = "延长"
          time_extend = (top_80_tm - line_tm).formatted("%.2f")
          time_extend_type = "TOP80延长"
        }
      }
    } else if (top_20_line_time == "1") {
      if (top_20_last_batch_time == "1") {
        change_type = "压缩"
        time_press = (line_tm - top_20_tm).formatted("%.2f")
        time_press_type = "TOP20压缩"
      } else if (top_80_line_time == "1") {
        change_type = "压缩"
        time_press = (line_tm - top_80_tm).formatted("%.2f")
        time_press_type = "TOP80压缩"
      }
    }
    change_type + "&" + time_press + "&" + time_extend + "&" + time_press_type + "&" + time_extend_type
  })


  def toIntWith = udf((value: String) => {
    val bd = BigDecimal(value)
    bd.setScale(0, RoundingMode.HALF_UP).toInt
  })

  def lineCodeLabelUDF = udf((fd_lc_7_cols: String) => {
    var label = "其他-无标签"
    val Array(if_always_on, top_20_critical_time, top_80_critical_time, total_tasks_on_rate_6, improve_period, time_extend_type, time_press_type) = fd_lc_7_cols.split("&", -1).padTo(7, "").take(7).map(_.trim)
    val total_tasks_on_rt = if (strNotNull(total_tasks_on_rate_6)) total_tasks_on_rate_6.toDouble else 0.0
    val improve_pd = if (strNotNull(improve_period)) improve_period.toDouble else 0.0
    if (if_always_on == "1") {
      if (time_extend_type == "实际时长延长") {
        label = "长期晚点-实际时长延长"
      } else if (time_extend_type == "TOP80延长") {
        label = "长期晚点-建议更换资源"
      } else if (time_extend_type == "临界值延长") {
        if (total_tasks_on_rt >= 0.8) {
          label = "长期晚点-临界值延长"
        } else if (top_20_critical_time == "0") {
          label = "长期晚点-进行激励"
        } else if (top_80_critical_time == "0") {
          label = "长期晚点-超出弹性范围"
        } else {
          label = "长期晚点-临界值延长"
        }
      }
    } else if (time_press_type == "TOP20压缩") {
      if (improve_pd > 0) {
        label = "价值线路-跨班次时效提升"
      } else {
        label = "价值线路-跨班次时效未提升"
      }
    } else if (time_press_type == "TOP80压缩") {
      label = "价值线路-无法跨班次"
    }
    label
  })

  def topLineTime = udf((line_distance: String, hy_all: String, line_time: String) => {
    var top_line_tm = "0"
    if (strNotNull(hy_all)) {
      try {
        val tmp_tm = 60.0 * (try {
          line_distance.toDouble
        } catch {
          case e: Exception => 0.0
        }) / hy_all.toDouble - (try {
          line_time.toDouble
        } catch {
          case e: Exception => 0.0
        })
        if (tmp_tm < 0.0) top_line_tm = "1"
      } catch {
        case e: Exception => "" + e
      }
    }
    top_line_tm
  })

  def loadQGGSDirect(spark: SparkSession, o_qd_df: DataFrame, improve_speed_df: DataFrame): DataFrame = {
    import spark.implicits._
    //行业总趟次
    val total_trips_df = o_qd_df.groupBy("direction").agg(count("key_word") as "total_trips_num")
      .select("direction", "total_trips_num")
    //行业满足跨班次趟次
    val tm_block_col = getTimeBlockUDF('highspeed_start_hour, 'depart_tm_block)
    val this_batch_cond = 'speed_highspeed_tl_2.cast("double") >= 'this_batch_highway_speed.cast("double")
    val last_batch_cond = 'speed_highspeed_tl_2.cast("double") >= 'last_batch_highway_speed.cast("double")
    val batch_trips_df = o_qd_df.join(improve_speed_df, Seq("direction"), "left")
      .withColumn("last_key_word", when(last_batch_cond, 'key_word))
      .withColumn("last_hsp", when(last_batch_cond, 'time_highspeed_start_rep))
      .withColumn("tm_block", when(tm_block_col === "Y", 'key_word))
      .withColumn("last_tm_block_key_word", when(tm_block_col === "Y" && last_batch_cond, 'key_word))
      .withColumn("last_tm_block_hsp", when(tm_block_col === "Y" && last_batch_cond, 'time_highspeed_start_rep))
      .withColumn("this_key_word", when(this_batch_cond, 'key_word))
      .withColumn("this_hsp", when(this_batch_cond, 'time_highspeed_start_rep))
      .withColumn("this_tm_block", when(tm_block_col === "Y" && this_batch_cond, 'key_word))
      .withColumn("this_tm_block_hsp", when(tm_block_col === "Y" && this_batch_cond, 'time_highspeed_start_rep))
      .groupBy("direction", "time_highspeed_start_rep")
      .agg(
        count("last_key_word") as "improve_batch_trips",
        max("time_highspeed_start_rep") as "improve_batch_days",
        count("tm_block") as "total_trips_num_hour",
        count("last_tm_block_key_word") as "improve_batch_trips_hour",
        max("last_tm_block_hsp") as "improve_batch_days_hour",
        count("this_key_word") as "this_batch_trips",
        max("this_hsp") as "this_batch_days",
        count("this_tm_block") as "this_batch_trips_hour",
        max("this_tm_block_hsp") as "this_batch_days_hour"
      ).groupBy("direction")
      .agg(
        sum("improve_batch_trips") as "improve_batch_trips",
        count("improve_batch_days") as "improve_batch_days",
        sum("total_trips_num_hour") as "total_trips_num_hour",
        sum("improve_batch_trips_hour") as "improve_batch_trips_hour",
        count("improve_batch_days_hour") as "improve_batch_days_hour",
        sum("this_batch_trips") as "this_batch_trips",
        count("this_batch_days") as "this_batch_days",
        sum("this_batch_trips_hour") as "this_batch_trips_hour",
        count("this_batch_days_hour") as "this_batch_days_hour"
      )
    val qg_df = total_trips_df
      .join(batch_trips_df, Seq("direction"), "left")
      .na.fill("", Seq("improve_batch_trips", "improve_batch_trips_days", "total_trips_num_hour", "improve_batch_trips_hour", "improve_batch_days_hour", "this_batch_trips", "this_batch_days", "this_batch_trips_hour", "this_batch_days_hour"))
      .select("direction", "total_trips_num", "improve_batch_trips", "improve_batch_days", "total_trips_num_hour", "improve_batch_trips_hour", "improve_batch_days_hour", "this_batch_trips", "this_batch_days", "this_batch_trips_hour", "this_batch_days_hour")
    logger.error(">>>>>>全国流向数据总量>>>>>" + qg_df.count())
    qg_df.show(10, false)
    qg_df
  }

  def loadSFGSDirect(spark: SparkSession, o_sf_df: DataFrame, improve_speed_df: DataFrame): DataFrame = {
    import spark.implicits._
    //行业总趟次
    val total_trips_df = o_sf_df.groupBy("id").agg(count("task_subid") as "sf_total_trips_num")
      .select("id", "sf_total_trips_num")

    //行业满足跨班次趟次
    val filter_cond = 'actual_run_time.cast("double") <= 'last_batch_run_time.cast("double")
    val batch_trips_df = o_sf_df.join(improve_speed_df, Seq("id"), "left")
      .withColumn("sf_improve_batch_trips", when(filter_cond, 'task_subid))
      .withColumn("inc_day", when(filter_cond, 'inc_day))
      .groupBy("id", "inc_day")
      .agg(
        count("sf_improve_batch_trips") as "sf_improve_batch_trips",
        max("inc_day") as "sf_improve_batch_days"
      ).groupBy("id")
      .agg(
        sum("sf_improve_batch_trips") as "sf_improve_batch_trips",
        count("sf_improve_batch_days") as "sf_improve_batch_days"
      )
      .select("id", "sf_improve_batch_trips", "sf_improve_batch_days")

    val sf_df = total_trips_df
      .join(batch_trips_df, Seq("id"), "left")
      .withColumn("sf_total_trips_num", when(colTrimNotNull('sf_total_trips_num), 'sf_total_trips_num).otherwise("0"))
      .withColumn("sf_improve_batch_trips", when(colTrimNotNull('sf_improve_batch_trips), 'sf_improve_batch_trips).otherwise("0"))
      .withColumn("sf_improve_batch_days", when(colTrimNotNull('sf_improve_batch_days), 'sf_improve_batch_days).otherwise("0"))
      .na.fill("0", Seq("sf_total_trips_num", "sf_improve_batch_trips", "sf_improve_batch_days"))
      .select("id", "sf_total_trips_num", "sf_improve_batch_trips", "sf_improve_batch_days")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>内部顺丰id维度数据总量>>>>>" + sf_df.count())
    sf_df
  }

  def thisBatchRunTimeUDF = udf((line_time: String, system_recommend_time: String) => {
    val regexHM = """(\d+)H(\d+)M""".r
    val regexH = """(\d+)H""".r
    val regexM = """(\d+)M""".r
    val result = system_recommend_time match {
      case regexHM(hour, min) => hour.toInt * 60 + min.toInt
      case regexH(hour) => hour.toInt * 60
      case regexM(min) => min.toInt
      case _ => 0
    }
    (line_time.toInt + result).toString
  })

  def getTimeBlockUDF = udf((highspeed_start_hour: String, depart_tm_block: String) => {
    var result = "N"
    if (strNotNull(highspeed_start_hour) && strNotNull(depart_tm_block)) {
      val hour = highspeed_start_hour.toInt
      val regexHM = """\[(\d+)-(\d+)([\)|\]]*)""".r
      depart_tm_block match {
        case regexHM(start, end, _) =>
          if (start.toInt == 20 && hour >= start.toInt && hour <= end.toInt) {
            result = "Y"
          } else if (start.toInt != 20 && hour >= start.toInt && hour < end.toInt) {
            result = "Y"
          } else {
            result = "N"
          }
        case _ => result = "N"
      }
    }
    result
  })

  def lastBathHighwaySpeedUDF = udf((last_batch_run_time: String, highway_dist: String, nonhighway_dist: String, nonhighway_speed: String) => {
    var last_batch_highway_speed = 0
    try {
      val inter_tm = ((last_batch_run_time.toDouble / 60.0 - nonhighway_dist.toDouble / nonhighway_speed.toDouble) / 4).toInt //h
      val diff_inter_tm = last_batch_run_time.toDouble / 60.0 - nonhighway_dist.toDouble / nonhighway_speed.toDouble - inter_tm / 3.0
      last_batch_highway_speed = (highway_dist.toDouble / diff_inter_tm).toInt
    } catch {
      case e: Exception => "" + e
    }
    last_batch_highway_speed
  })

  def lastBatchRuntimeUDF = udf((last_batch_arrive_tm: String, plan_depart_tm: String) => {
    var last_batch_run_time = ""
    try {
      if (strNotNull(last_batch_arrive_tm) && strNotNull(plan_depart_tm)) {
        last_batch_run_time = ((timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", last_batch_arrive_tm) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", plan_depart_tm)) / 60.0).formatted("%.2f")
      }
    } catch {
      case e: Exception => "" + e
    }
    last_batch_run_time
  })

}
