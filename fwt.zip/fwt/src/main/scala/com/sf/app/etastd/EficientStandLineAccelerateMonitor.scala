package com.sf.app.etastd

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions._
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 756298
 * @description: 线路时效变更指标监控表  dm_gis.eta_std_acc_speed_monitor_change_ratio
 * @demander: ft80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/5/17 14:44
 */
object EficientStandLineAccelerateMonitor extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    procMonitor(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def procMonitor(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val day_7_ago = getdaysBeforeOrAfter(inc_day, -6)
    val day_15_ago = getdaysBeforeOrAfter(day_7_ago, -7)
    val day_30_ago = getdaysBeforeOrAfter(day_15_ago, -15)

    val near_tm = $"sx_tm" >= day_7_ago && $"sx_tm" <= inc_day
    val d7_tm = $"sx_tm" >= day_15_ago && $"sx_tm" < day_7_ago
    val d15_tm = $"sx_tm" >= day_30_ago && $"sx_tm" < day_15_ago
    val change_period_cond = when(near_tm, "d0_7").when(d7_tm, "d7_14").when(d15_tm, "d14_30")

    val t_bef_task_cnt_cond = when(near_tm, 'd7_bef_task_cnt).when(d7_tm, 'd7_bef_task_cnt).when(d15_tm, 'd15_bef_task_cnt).otherwise(0)
    val t_bef_ontime_task_cnt_cond = when(near_tm, 'd7_bef_ontime_task_cnt).when(d7_tm, 'd7_bef_ontime_task_cnt).when(d15_tm, 'd15_bef_ontime_task_cnt).otherwise(0)
    val t_bef_exe_task_cnt_cond = when(near_tm, 'd7_bef_exe_task_cnt).when(d7_tm, 'd7_bef_exe_task_cnt).when(d15_tm, 'd15_bef_exe_task_cnt).otherwise(0)
    val t_bef_dynamic_link_task_cnt_cond = when(near_tm, 'd7_bef_dynamic_link_task_cnt).when(d7_tm, 'd7_bef_dynamic_link_task_cnt).when(d15_tm, 'd15_bef_dynamic_link_task_cnt).otherwise(0)
    val t_aft_task_cnt_cond = when(near_tm, 'd7_aft_task_cnt).when(d7_tm, 'd7_aft_task_cnt).when(d15_tm, 'd15_aft_task_cnt).otherwise(0)
    val t_aft_ontime_task_cnt_cond = when(near_tm, 'd7_aft_ontime_task_cnt).when(d7_tm, 'd7_aft_ontime_task_cnt).when(d15_tm, 'd15_aft_ontime_task_cnt).otherwise(0)
    val t_aft_exe_task_cnt_cond = when(near_tm, 'd7_aft_exe_task_cnt).when(d7_tm, 'd7_aft_exe_task_cnt).when(d15_tm, 'd15_aft_exe_task_cnt).otherwise(0)
    val t_aft_dynamic_link_task_cnt_cond = when(near_tm, 'd7_aft_dynamic_link_task_cnt).when(d7_tm, 'd7_aft_dynamic_link_task_cnt).when(d15_tm, 'd15_aft_dynamic_link_task_cnt).otherwise(0)

    val o_prop_df = spark.sql(
      s"""select line_code,load_zone_code,dest_zone_code,
         |change_type,effective_date_pre,regexp_replace(substr(effective_date_pre, 0,10),'-','') sx_tm,
         |bef_task_cnt,bef_ontime_task_cnt,bef_exe_task_cnt,bef_dynamic_link_task_cnt,aft_task_cnt,aft_ontime_task_cnt,aft_exe_task_cnt,aft_dynamic_link_task_cnt,
         |d7_bef_task_cnt,d7_bef_ontime_task_cnt,d7_bef_exe_task_cnt,d7_bef_dynamic_link_task_cnt,d7_aft_task_cnt,d7_aft_ontime_task_cnt,d7_aft_exe_task_cnt,d7_aft_dynamic_link_task_cnt,
         |d15_bef_task_cnt,d15_bef_ontime_task_cnt,d15_bef_exe_task_cnt,d15_bef_dynamic_link_task_cnt,d15_aft_task_cnt,d15_aft_ontime_task_cnt,d15_aft_exe_task_cnt,d15_aft_dynamic_link_task_cnt,
         |inc_day from dm_gis.eta_std_acc_speed_monitor_change_indicate
         |where inc_day = '$inc_day'
         |and change_type is not null and trim(change_type) != ''
         |and regexp_replace(substr(effective_date_pre, 0,10),'-','') between '$day_30_ago' and '$inc_day'
         |""".stripMargin).repartition(400).persist()

    logger.error(">>>>初始加载的数据总量>>>>>" + o_prop_df.count())
    val res_cols = spark.sql("""select * from dm_gis.eta_std_acc_speed_monitor_change_ratio limit 1""").schema.map(_.name).map(col)

    val res_df = o_prop_df.withColumn("change_period", change_period_cond)
      .withColumn("t_adj_line_cnt", lit(1))
      .withColumn("t_bef_task_cnt", t_bef_task_cnt_cond)
      .withColumn("t_bef_ontime_task_cnt", t_bef_ontime_task_cnt_cond)
      .withColumn("t_bef_exe_task_cnt", t_bef_exe_task_cnt_cond)
      .withColumn("t_bef_dynamic_link_task_cnt", t_bef_dynamic_link_task_cnt_cond)
      .withColumn("t_aft_task_cnt", t_aft_task_cnt_cond)
      .withColumn("t_aft_ontime_task_cnt", t_aft_ontime_task_cnt_cond)
      .withColumn("t_aft_exe_task_cnt", t_aft_exe_task_cnt_cond)
      .withColumn("t_aft_dynamic_link_task_cnt", t_aft_dynamic_link_task_cnt_cond)
      .groupBy("change_type", "change_period", "inc_day")
      .agg(
        sum("t_adj_line_cnt").as("t_adj_line_cnt"),
        sum("t_bef_task_cnt").as("t_bef_task_cnt"),
        sum("t_bef_ontime_task_cnt").as("t_bef_ontime_task_cnt"),
        sum("t_bef_exe_task_cnt").as("t_bef_exe_task_cnt"),
        sum("t_bef_dynamic_link_task_cnt").as("t_bef_dynamic_link_task_cnt"),
        sum("t_aft_task_cnt").as("t_aft_task_cnt"),
        sum("t_aft_ontime_task_cnt").as("t_aft_ontime_task_cnt"),
        sum("t_aft_exe_task_cnt").as("t_aft_exe_task_cnt"),
        sum("t_aft_dynamic_link_task_cnt").as("t_aft_dynamic_link_task_cnt")
      )
      .withColumn("t_bef_ontime_ratio", when('t_bef_task_cnt > 0, 't_bef_ontime_task_cnt / 't_bef_task_cnt).otherwise(0))
      .withColumn("t_bef_exe_ratio", when('t_bef_task_cnt > 0, 't_bef_exe_task_cnt / 't_bef_task_cnt).otherwise(0))
      .withColumn("t_bef_dynamic_coninc_ratio", when('t_bef_task_cnt > 0, 't_bef_dynamic_link_task_cnt / 't_bef_task_cnt).otherwise(0))
      .withColumn("t_aft_ontime_ratio", when('t_aft_task_cnt > 0, 't_aft_ontime_task_cnt / 't_aft_task_cnt).otherwise(0))
      .withColumn("t_aft_exe_ratio", when('t_aft_task_cnt > 0, 't_aft_exe_task_cnt / 't_aft_task_cnt).otherwise(0))
      .withColumn("t_aft_dynamic_coninc_ratio", when('t_aft_task_cnt > 0, 't_aft_dynamic_link_task_cnt / 't_aft_task_cnt).otherwise(0))
      .select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(1), Seq("inc_day"), "dm_gis.eta_std_acc_speed_monitor_change_ratio")

  }

  def multiCondCombine(spark: SparkSession, inc_day: String, day_7_ago: String, day_15_ago: String, day_30_ago: String): Seq[Column] = {
    import spark.implicits._
    val near_tm = $"sx_tm" >= day_7_ago && $"sx_tm" <= inc_day
    val d7_tm = $"sx_tm" >= day_15_ago && $"sx_tm" < day_7_ago
    val d15_tm = $"sx_tm" >= day_30_ago && $"sx_tm" < day_15_ago
    val tm_cond = Seq(near_tm, d7_tm, d15_tm)
    val near_cols_str = Seq("bef_task_cnt", "bef_ontime_task_cnt", "bef_exe_task_cnt", "bef_dynamic_link_task_cnt", "aft_task_cnt", "aft_ontime_task_cnt", "aft_exe_task_cnt", "aft_dynamic_link_task_cnt")
    val d7_cols_str = near_cols_str.map("d7_" + _)
    val d15_cols_str = near_cols_str.map("d15_" + _)
    val multi_cond = Seq(near_cols_str.map(col), d7_cols_str.map(col), d15_cols_str.map(col))
    val new_cols_str = near_cols_str.map("t_" + _)
    val col_ab = ArrayBuffer[Column]()
    //在near_tm取near_cols_str ，在d7_tm取d7_cols_str，在d15_tm取d15_cols_str
    for (i <- 0 until near_cols_str.length) {
      col_ab += when(tm_cond(0), multi_cond(0)(i)).when(tm_cond(1), multi_cond(1)(i)).when(tm_cond(2), multi_cond(2)(i)).as(new_cols_str(i))
    }
    col_ab.toSeq
  }
}
