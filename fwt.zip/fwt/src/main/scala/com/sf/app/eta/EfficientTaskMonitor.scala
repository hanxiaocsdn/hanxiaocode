package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions._
import utils.{ColumnUtil, SparkBuilder}

/**
 * @description: 473798 时效定则 任务各类事件占比统计
 * @author 01418539 caojia   修改 01390943
 * @date 2022/8/25 16:08
 */

object EfficientTaskMonitor extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    val day1 = args(2)
    val day2 = args(3)
    processLoadTaskData(spark, start_day, end_day,day1,day2)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processLoadTaskData(spark: SparkSession, start_day: String, end_day: String, day1: String, day2: String): Unit = {
    import spark.implicits._
    val p1_cols_str = Seq("line_time", "actual_run_time", "total_keguan", "total_zhuguan", "line_distance")
    val p2_cols_str = Seq("service_final", "service_ob_final", "service_gaosu_final", "tollstation_sub_final",
      "tollstation_ob_final", "epidemic_sub_final", "epidemic_ob_final", "start_sub_final", "start_ob_final",
      "end_sub_final", "end_ob_final", "other_event_final", "no_label_sub_final", "no_label_ob_final", "highwaymileage","is_rec","is_rec_satisfied",
      "std_highway", "std_dist", "jyz_total_stay_points_duration", "zhuguan_fuwuqu", "rt_dist","dept_pro","peak_congestion_final","total_zhuguan_ratio",
      "line_time","total_keguan_ratio1")
    val p3_cols_str = Seq("trackreliable", "error_type","other_event_total_code","other_event_total_code_title")
    //20221125新增
    val p4_cols_str = Seq("service_plan_stay_duration","service_sj_rest_times","service_tl_cn","jiayouzhan_tl_cn","gaosu_tl_sub_cn",
      "service_ds_sub_cn","service_ds_ob_cn","gaosu_sub_total_stay_points_duration","total_ob_tl","total_sub_tl",
      "total_ob_disu","total_sub_disu","service_total_stay_points_duration","service_sub_lowspeed_duration",
      "service_ob_lowspeed_duration","service_ob_sub_lowspeed_duration","toll_station_sub_total_stay_points_duration",
      "tollstation_sub_lowspeed_duration","toll_station_ob_total_stay_points_duration","tollstation_ob_lowspeed_duration",
      "tollstation_ob_sub_lowspeed_duration","epidemic_sub_total_stay_points_duration","epidemic_sub_lowspeed_duration",
      "epidemic_ob_total_stay_points_duration","epidemic_ob_lowspeed_duration","epidemic_ob_sub_lowspeed_duration",
      "start_total_stay_points_duration","start_sub_lowspeed_duration","start_ob_lowspeed_duration","start_ob_sub_lowspeed_duration",
      "end_total_stay_points_duration","end_sub_lowspeed_duration","end_ob_lowspeed_duration","end_ob_sub_lowspeed_duration",
      "other_event_total_stay_points_duration","other_ob_lowspeed_duration","other_sub_lowspeed_duration","other_ob_sub_lowspeed_duration",
      "no_sub_total_stay_points_duration","no_sub_lowspeed_duration","no_ob_total_stay_points_duration","gaosu_ob_total_stay_points_duration",
      "no_ob_lowspeed_duration","no_ob_sub_lowspeed_duration")

      //从dm_gis.eta_task_time_information获取数据
    val agg_cols = aggFun(p1_cols_str, p2_cols_str, p3_cols_str,p4_cols_str)
    val o_task = spark.sql(
      s"""
         |select  task_id,line_time,actual_run_time,total_keguan,total_zhuguan,line_distance,
         |        service_final,service_ob_final,service_gaosu_final,tollstation_sub_final,tollstation_ob_final,epidemic_sub_final,epidemic_ob_final,
         |        start_sub_final,start_ob_final,end_sub_final,end_ob_final,other_event_final,no_label_sub_final,no_label_ob_final,highwaymileage,
         |        std_highway,std_dist,is_rec,is_rec_satisfied,rec_time_change,rec_time,trackreliable,
         |        conduct_type,jyz_total_stay_points_duration,zhuguan_fuwuqu,rt_dist,error_type,inc_day,
         |        service_plan_stay_duration,service_sj_rest_times,service_tl_cn,jiayouzhan_tl_cn,gaosu_tl_sub_cn,
         |      service_ds_sub_cn,service_ds_ob_cn,gaosu_sub_total_stay_points_duration,total_ob_tl,total_sub_tl,
         |      total_ob_disu,total_sub_disu,service_total_stay_points_duration,service_sub_lowspeed_duration,
         |      service_ob_lowspeed_duration,service_ob_sub_lowspeed_duration,toll_station_sub_total_stay_points_duration,
         |      tollstation_sub_lowspeed_duration,toll_station_ob_total_stay_points_duration,tollstation_ob_lowspeed_duration,
         |      tollstation_ob_sub_lowspeed_duration,epidemic_sub_total_stay_points_duration,epidemic_sub_lowspeed_duration,
         |      epidemic_ob_total_stay_points_duration,epidemic_ob_lowspeed_duration,epidemic_ob_sub_lowspeed_duration,
         |      start_total_stay_points_duration,start_sub_lowspeed_duration,start_ob_lowspeed_duration,start_ob_sub_lowspeed_duration,
         |      end_total_stay_points_duration,end_sub_lowspeed_duration,end_ob_lowspeed_duration,end_ob_sub_lowspeed_duration,
         |      other_event_total_stay_points_duration,other_ob_lowspeed_duration,other_sub_lowspeed_duration,other_ob_sub_lowspeed_duration,
         |      no_sub_total_stay_points_duration,no_sub_lowspeed_duration,no_ob_total_stay_points_duration,gaosu_ob_total_stay_points_duration,
         |      no_ob_lowspeed_duration,no_ob_sub_lowspeed_duration,end_tl_start_tm,end_tl_end_tm,end_ds_start_tm,end_ds_end_tm,dept_pro
         |      ,other_event_total_code,other_event_total_code_title,peak_congestion_final,total_zhuguan_ratio,total_keguan_ratio1
         |from dm_gis.eta_task_time_information
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |      and task_id is not null and trim(task_id) !=''
         |""".stripMargin)


    
    val rpt_grd_task = spark.sql(s"""SELECT * from (
                                    |select report_date,task_id,line_require_id,carrier_type,task_area_code,task_area_name,type_name,src_zone_code,
                                    |dest_zone_code,modify_tm,plan_reach_tm,actual_src_gis_in_tm,plan_depart_tm,actual_src_gis_out_tm,car_close_op_tm,
                                    |plan_arrive_tm,actual_arrive_tm,car_open_op_tm,plan_run_time,actual_run_time,arrive_batch,plan_begin_tm,last_arrive_tm,
                                    |plan_end_tm,state,carrier_name,vehicle_serial,main_driver,outside_flag,seal_vehicle_label,contnr_code,line_code,
                                    |cvy_name,transoport_level,line_distance,actual_distance,plan_avg_speed,actual_avg_speed,run_mode,is_stop_over,
                                    |capacity_load,actual_capacity_load,vehicle_type,require_category,check_flag, require_change_type,
                                    |new_change_reason,new_change_remark,contract_service_type,last_update_tm,src_city_code,dest_city_code,
                                    |reach_tm_flag,depart_tm_flag,arrive_tm_flag,run_time_flag,early_warning_type,early_warning_category,
                                    |src_area_code,src_hq_code,dest_area_code,dest_hq_code,actual_vote,validity_vehicle,validity_phone,
                                    |load_ratio_1,client_typ_done,line_id,appoint_ontime,carrier_type_new,resource_type,assigned_tm,create_time,
                                    |tags_flag,biz_type_new,pricing_manner,contract_source,assign_type,require_type_new,line_area_level,
                                    |distance_period,task_vehicle_type,task_carrier_name,assign_vehicle_code,assign_vehicle_type,app_vehicle_code,
                                    |task_vehicle_supplier_name,app_vehicle_supplier_name,vehicle_type11,vehicle_type_flag,halfway_integrate_rate,
                                    |is_halfway_integrate,biz_type,task_dept_code,actual_carrier_name,require_change_category_name,piece_type,task_dept_name,
                                    |src_zone_name,dest_zone_name,src_city_name,dest_city_name,src_area_belong_name,dest_area_belong_name,
                                    |row_number() over( PARTITION by task_id ORDER by last_update_tm desc ) as rn
                                    |FROM dm_tdsp.rpt_grd_task_monitor_re_dtl_di where inc_day>='$day1' and inc_day <= '$day2'
                                    |) b where rn=1 """.stripMargin
                                ).drop("rn")


    val o1_line_dist_df = o_task.select("task_id", "line_distance", "inc_day")
      .groupBy("task_id", "inc_day")
      .agg(sum(col("line_distance").cast("double")) as "task_line_distance")
      .na.fill(0.0, Seq("task_line_distance"))

    //conduct_type 条件
    val conduct_type_flag = when('conduct_type.isin("1", "2") && 'task_line_distance > 0, 'line_distance.cast("double") / 'task_line_distance).otherwise(0)
    val rec_time_change_flag = when('is_rec === "1" && 'is_rec_satisfied === "1", 'rec_time_change).otherwise("0")
    val rec_time_flag = when('is_rec === "1" && 'is_rec_satisfied === "1", 'rec_time).otherwise('line_time)

    val o1_spec_3f_df = o_task.select("task_id", "line_distance", "line_time", "is_rec", "rec_time", "is_rec_satisfied", "conduct_type", "rec_time_change", "inc_day")
      .join(o1_line_dist_df, Seq("task_id", "inc_day"))
      .withColumn("conduct_type_flag", conduct_type_flag)
      .withColumn("rec_time_change", rec_time_change_flag)
      .withColumn("rec_time", rec_time_flag)
      .groupBy("task_id", "inc_day")
      .agg(
        sum("conduct_type_flag") as "conduct_type_flag",
        sum("rec_time_change") as "rec_time_change",
        sum("rec_time") as "rec_time"
      )

    //20221125 新增end_tl_start_tm,end_tl_end_tm,end_ds_start_tm,end_ds_end_tm
    val timeindex_df=o_task.select("inc_day","task_id","end_tl_start_tm","end_tl_end_tm","end_ds_start_tm","end_ds_end_tm")
      .groupBy("inc_day","task_id")
      .agg(concat_ws("|",collect_set("end_tl_start_tm")) as("end_tl_start_tm") ,
        concat_ws("|",collect_set("end_tl_end_tm")) as("end_tl_end_tm") ,
        concat_ws("|",collect_set("end_ds_start_tm")) as("end_ds_start_tm") ,
        concat_ws("|",collect_set("end_ds_end_tm")) as("end_ds_end_tm")
      )

    val o1_sum_df = o_task.drop("conduct_type", "rec_time_change","rec_time")
      .groupBy("task_id", "inc_day")
      .agg(agg_cols.head, agg_cols.tail: _*)
      //20221125修改zhuguan_fuwuqu，service_gaosu_final-service_plan_stay_duration/60
      .withColumn("zhuguan_fuwuqu",when(($"service_gaosu_final"-$"service_plan_stay_duration"/60)<0,0)
        .otherwise($"service_gaosu_final"-$"service_plan_stay_duration"/60))
      //20230210修改task_total_keguan,total_keguan_koufa
      .withColumn("task_total_keguan",$"epidemic_ob_final"+$"other_event_final"+$"tollstation_ob_final"+$"no_label_ob_final"+$"peak_congestion_final")
      .withColumn("task_total_zhuguan",when(($"zhuguan_fuwuqu"+$"tollstation_sub_final"+$"epidemic_sub_final"+$"start_sub_final"+$"no_label_sub_final"+$"gaosu_sub_total_stay_points_duration"/60)<0,0).
        otherwise($"zhuguan_fuwuqu"+$"tollstation_sub_final"+$"epidemic_sub_final"+$"start_sub_final"+$"no_label_sub_final"+$"gaosu_sub_total_stay_points_duration"/60))
      .withColumn("total_keguan_koufa",$"epidemic_ob_final"+$"other_event_final"+$"peak_congestion_final")
      .join(o1_spec_3f_df, Seq("task_id", "inc_day"), "left")
      .withColumn("conduct_type", when('conduct_type_flag >= 0.85, "1").otherwise("3"))
      .withColumn("error_type", dropDuplicat('error_type))
      //20221125 新增end_tl_start_tm,end_tl_end_tm,end_ds_start_tm,end_ds_end_tm
      .join(timeindex_df, Seq("task_id", "inc_day"), "left")
      .withColumn("task_difftime_plan_actual", 'task_line_time.cast("double") - 'task_actual_run_time.cast("double"))
      .withColumn("ac_is_run_ontime", when('task_difftime_plan_actual >= -1, 1).otherwise(0))
      .drop("conduct_type_flag")
      //20230210新增
      .withColumn("task_total_keguan1",$"epidemic_ob_final"+$"start_ob_final"+$"other_event_final"+$"tollstation_ob_final"+$"no_label_ob_final"+$"peak_congestion_final")
      .withColumn("task_total_keguan_ratio1",$"task_total_keguan1"/$"task_difftime_plan_actual")
      .withColumn("task_total_zhuguan1",$"zhuguan_fuwuqu"+$"tollstation_sub_final"+$"epidemic_sub_final"+$"start_sub_lowspeed_duration"/60+$"no_label_sub_final"+$"gaosu_sub_total_stay_points_duration"/60)
      .withColumn("task_total_zhuguan_ratio1",$"task_total_zhuguan1"/$"task_difftime_plan_actual")


    //task_label1
    val cond1 = 'ac_is_run_ontime === 0 && ('task_total_zhuguan_ratio <= -0.5 || (!'trackreliable.contains("false") && 'highwaymileagepercentagevalid === "false" && 'std_highway.cast("double") > 2000 && 'std_dist.cast("double") > 10000 && 'std_highway.cast("double") / 'std_dist.cast("double") >= 0.05 && 'conduct_type === "3"))
    val cond2 = 'ac_is_run_ontime === 0 && ('task_difftime_plan_actual.cast("double") =!= 0 && ('rec_time.cast("double") - 'task_line_time.cast("double")) / 'task_difftime_plan_actual.cast("double") <= -0.5)
    val con3='ac_is_run_ontime === 0 && 'end_sub_final_ratio <= -0.5
    //20221125修改，添加con3
    val label1_cond = when(cond1, "主观").when(con3,"终点异常").when(cond2, "规划时长不足")
      .when('ac_is_run_ontime === 0 && 'task_total_keguan_ratio.cast("double") <= -0.5, "客观")
      .when('ac_is_run_ontime === 0 , "系统未识别")
      .otherwise("")
    //task_label_keguan
    val label_toll_cond = when('task_label1 === "客观" && 'tollstation_ob_final_ratio.cast("double") <= -0.5, "收费站客观停留/低速")
    val epidemic_ob_cond = when('task_label1 === "客观" && 'epidemic_ob_final_ratio.cast("double") <= -0.5, "疫情检查")
    val other_event_cond = when('task_label1 === "客观" && 'other_event_final_ratio.cast("double") <= -0.5, "其他事件")
    val jyz_total_cond = when('task_label1 === "客观" && 'jyz_total_stay_points_duration_delay_ratio.cast("double") <= -0.5, "加油站客观停留/低速")
    val no_ob_cond = when('task_label1 === "客观" && 'no_label_ob_final_ratio.cast("double") <= -0.5, "路况拥堵")
    val start_ob = when('task_label1 === "客观" && 'start_ob_final_ratio.cast("double") <= -0.5, "起点拥堵")
    val end_ob = when('task_label1 === "客观" && 'end_ob_final_ratio.cast("double") <= -0.5, "终点拥堵")
    val service_ob = when('task_label1 === "客观" && 'task_difftime_plan_actual =!= 0 && 'service_ob_final.cast("double") / 'task_difftime_plan_actual.cast("double") <= -0.5, "服务区拥堵")

    //task_label_zhuguan
    val fuwuqu_cond = when('task_label1 === "主观" && 'zhuguan_fuwuqu_ratio.cast("double") <= -0.5, "服务区主观停留/低速")
    val qidian_cond = when('task_label1 === "主观" && 'start_sub_final_ratio.cast("double") <= -0.5, "起点主观停留/低速")
    val epidemic_cond = when('task_label1 === "主观" && 'epidemic_sub_final_ratio.cast("double") <= -0.5, "疫情检查站主观停留/低速")
    val toll_cond = when('task_label1 === "主观" && 'tollstation_sub_final_ratio.cast("double") <= -0.5, "收费站主观停留/低速")
    val track = when('task_label1 === "主观" && (!'trackreliable.contains("false") && 'highwaymileagepercentagevalid === "false" && 'std_highway.cast("double") > 2000 && 'std_dist.cast("double") > 10000 && 'std_highway.cast("double") / 'std_dist.cast("double") >= 0.05 && 'conduct_type === "3"), "未全程高速")
    val gaosuzg=when('task_label1 === "主观" && 'gaosu_sub_total_stay_points_duration_delay_ratio.cast("double") <= -0.5, "高速主观停留")
    val otherzg= when('task_label1 === "主观" && 'no_label_sub_final_ratio.cast("double") <= -0.5, "其他主观停留/低速")
    //task_label_other
    val other_cond = when('task_label1 === "系统未识别" && ('error_type.contains("4") || 'error_type.contains("5") || 'rt_dist.cast("double") === 0), "轨迹异常")
    val peak_congestion_final_ratio_cond=when($"peak_congestion_final_ratio"<= -0.5,"高峰拥堵")

    val need_cols = spark.sql("""select * from dm_gis.eta_task_time_information1 limit 0""").schema.map(_.name).map(col)
    //val need_cols = spark.sql("""select * from dm_gis.eta_task_time_information1 limit 0""").schema.map(_.name).map(col)

    val step_ratio = o1_sum_df.select(o1_sum_df.schema.map(_.name).map(col) ++ partRatioCalculate: _*)
      .withColumn("highwaymileagepercentage", when('std_highway.cast("double") > 0, 'highwaymileage.cast("double") / 'std_highway.cast("double")).otherwise(0))
      .withColumn("mileagepercentage", when('rt_dist.cast("double") > 0, 'std_dist.cast("double") / 'rt_dist.cast("double")).otherwise(0))
      .withColumn("highwaymileagepercentagevalid", when('mileagepercentage.cast("double") <= 1.3 && 'highwaymileagepercentage.cast("double") <= 0.5, "false").otherwise("true"))
      .withColumn("task_label1", label1_cond)
      .withColumn("label_toll", label_toll_cond)
      .withColumn("epidemic_ob", epidemic_ob_cond)
      .withColumn("other_event", other_event_cond)
      .withColumn("jyz_total", jyz_total_cond)
      .withColumn("no_ob_cond", no_ob_cond)
      .withColumn("start_ob", start_ob)
      .withColumn("end_ob", end_ob)
      .withColumn("service_ob", service_ob)
      .withColumn("peak_congestion_final_ratio_cond", peak_congestion_final_ratio_cond)
      //20230210修改task_label_keguan
      .withColumn("task_label_keguan", concat_ws("|", 'label_toll, 'epidemic_ob, 'other_event, 'no_ob_cond, 'peak_congestion_final_ratio_cond))
      .withColumn("fuwuqu", fuwuqu_cond)
      .withColumn("qidian", qidian_cond)
      .withColumn("toll", toll_cond)
      .withColumn("epidemic", epidemic_cond)
      .withColumn("track", track)
      .withColumn("gaosuzg", gaosuzg)
      .withColumn("otherzg", otherzg)
      //20221125修改task_label_zhuguan，去掉zhongdian_cond,新增gaosuzg和otherzg
      .withColumn("task_label_zhuguan", concat_ws("|", 'fuwuqu, 'qidian,'gaosuzg,'otherzg, 'toll, 'epidemic, 'track))
      .withColumn("task_label_other", other_cond)
      .withColumn("task_label2", concat_ws("&", 'task_label_keguan, 'task_label_zhuguan, 'task_label_other))
      .withColumn("task_label2", nullDeal('task_label2))
      //20221125添加zhuguan_max,keguan_max,task_label_keguan_max
      .withColumn("zhuguan_max",maxsix_fun_udf($"zhuguan_fuwuqu",$"tollstation_sub_final",$"epidemic_sub_final",$"start_sub_final",$"no_label_sub_final",$"gaosu_sub_total_stay_points_duration"/60))
      .withColumn("keguan_max",maxsix_fun_udf($"epidemic_ob_final",$"start_ob_final",$"other_event_final",$"tollstation_ob_final",$"no_label_ob_final",$"end_ob_final"))
      .withColumn("task_label_keguan_max",task_label_keguan_max_udf($"task_label1",
        $"epidemic_ob_final",$"other_event_final",$"tollstation_ob_final",$"no_label_ob_final",$"peak_congestion_final"))
      .withColumn("task_label_zhuguan_max",task_label_zhuguan_max_udf($"task_label1",
        $"zhuguan_fuwuqu",$"tollstation_sub_final",$"epidemic_sub_final",$"gaosu_sub_total_stay_points_duration"/60,$"start_sub_final",$"no_label_sub_final",$"total_zhuguan_ratio"
      ))
      .join(rpt_grd_task, Seq("task_id"), "left")
      //20230210新增
      .withColumn("task_label_test",when($"ac_is_run_ontime"==="0.0" && ($"task_total_zhuguan_ratio1" <= -0.5
        || ($"trackreliable"==="true" && $"highwaymileagepercentagevalid"==="false" && $"std_highway">2000 && $"std_dist">10000 && $"std_highway"/$"std_dist">0.05 && $"conduct_type"==="3"))
        ,"主观")
        .when($"ac_is_run_ontime"==="0.0" && $"dept_pro_ratio" <= -0.5,"疑似场地问题")
        .when($"ac_is_run_ontime"==="0.0" && $"is_rec"==="1" && $"is_rec_satisfied"==="1" && ($"rec_time"-$"line_time")/$"task_difftime_plan_actual" <= -0.5,"规划时长不足")
        .when($"ac_is_run_ontime"==="0.0" && $"total_keguan_ratio1" <= -0.5,"客观")
        .when($"ac_is_run_ontime"==="0.0","系统未识别").otherwise(""))
      .select(need_cols: _*)

    writeToHive(spark, step_ratio, Seq("inc_day"), "dm_gis.eta_task_time_information1")
    //writeToHive(spark, step_ratio, Seq("inc_day"), "dm_gis.eta_task_time_information1")
  }
  //定义udf函数，取最大值
  def maxsix_fun(x1:Double,x2:Double,x3:Double,x4:Double,x5:Double,x6:Double): Double ={Set(x1,x2,x3,x4,x5,x6).max}
  val  maxsix_fun_udf=udf(maxsix_fun _)

  //定义函数计算task_label_keguan_max
  def task_label_keguan_max_fun(y:String,x1:Double,x2:Double,x3:Double,x4:Double,x5:Double):String={
    if(y=="客观"){
      val x=Set(x1,x2,x3,x4,x5)
      if(x1==x.max){return "疫情检查"}
      else if(x2==x.max){return "其他事件"}
      else if(x3==x.max){return "收费站客观停留/低速"}
      else if(x4==x.max){return "路况拥堵"}
      else if(x5==x.max){return "高峰拥堵"}
      else ""
    }
    else ""
  }
  //注册udf函数
  val task_label_keguan_max_udf=udf(task_label_keguan_max_fun _)


  //定义函数计算task_label_zhuguan_max
  def task_label_zhuguan_max_fun(y:String,x1:Double,x2:Double,x3:Double,x4:Double,x5:Double,x6:Double,x7:Double):String={
    if(y=="主观"){
      val x=Set(x1,x2,x3,x4,x5,x6)
      if(x7> -0.5){return "未全程高速"}
      else if(x7<= -0.5 && x.max !=0&&x1==x.max){return "服务区主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x2==x.max){return "收费站主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x3==x.max){return "疫情检查站主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x4==x.max){return "高速主观停留"}
      else if(x7<= -0.5 && x.max !=0&&x5==x.max){return "起点主观停留/低速"}
      else if(x7<= -0.5 && x.max !=0&&x6==x.max){return "其他主观停留/低速"}
      else ""
    }
    else ""
  }
  //注册udf函数
  val task_label_zhuguan_max_udf=udf(task_label_zhuguan_max_fun _)

  //null处理
  def nullDeal = udf((task_label2: String) => {
    var res = ""
    try {
      if (task_label2.replace("&", "").trim != "") res = task_label2.replace("&", "") else res = ""
    } catch {
      case e: Exception => e.getMessage
    }
    res
  })

  def partRatioCalculate(): Seq[Column] = {
    val cols_str = Seq("tollstation_sub_final", "tollstation_ob_final", "epidemic_sub_final", "epidemic_ob_final", "start_sub_final", "start_ob_final", "end_sub_final",
      "end_ob_final", "other_event_final", "no_label_sub_final", "no_label_ob_final","total_zhuguan_ratio","dept_pro","is_rec","is_rec_satisfied",
      "zhuguan_fuwuqu", "jyz_total_stay_points_duration", "task_total_keguan", "task_total_zhuguan","gaosu_sub_total_stay_points_duration","peak_congestion_final",
      "line_time")


    val cols_str_nm = cols_str.map(x => if (x == "jyz_total_stay_points_duration" || x == "gaosu_sub_total_stay_points_duration") x + "_delay_ratio" else x + "_ratio")
    val ratio_cols = cols_str.map(x => if (x == "jyz_total_stay_points_duration" ) {
      when(col("task_difftime_plan_actual").cast("double") =!= 0, col(x).cast("double") / 60 / col("task_difftime_plan_actual").cast("double")).otherwise(0)
    } else if(x == "gaosu_sub_total_stay_points_duration" ) {
      when(col("task_difftime_plan_actual").cast("double") =!= 0, col(x).cast("double") / 60  / col("task_difftime_plan_actual").cast("double")).otherwise(0)
    }
    else {
      when(col("task_difftime_plan_actual").cast("double") =!= 0, col(x).cast("double") / col("task_difftime_plan_actual").cast("double")).otherwise(0)
    })
    ColumnUtil.renameColumn(ratio_cols, cols_str_nm)
  }
  //计算ratio指标
  def ratioCalculate(cols_str: Seq[String]): Seq[Column] = {
    val pub_str = cols_str.filter(x => !x.equals("line_time") && !x.equals("actual_run_time") && !x.equals("rt_dist"))
      .map(x => if (x == "total_keguan" || x == "total_zhuguan") "task_" + x else x)
    val new_name_str = pub_str.map(x => if (x.startsWith("zhuguan") || x.endsWith("zhuguan") || x.endsWith("keguan")) x + "_ratio" else x + "_delay_ratio")
    val new_cols = pub_str.map(x =>
      if (x.startsWith("zhuguan") || x.endsWith("zhuguan") || x.endsWith("keguan")) {
        when(col("task_difftime_plan_actual").cast("double") =!= 0, col(x).cast("double") / col("task_difftime_plan_actual").cast("double")).otherwise(0)
      } else {
        when(col("task_difftime_plan_actual").cast("double") =!= 0, col(x).cast("double") / 60 / col("task_difftime_plan_actual").cast("double")).otherwise(0)
      })
    ColumnUtil.renameColumn(new_cols, new_name_str)
  }

  def aggFun(p1_cols_str: Seq[String], p2_cols_str: Seq[String], p3_cols_str: Seq[String], p4_cols_str: Seq[String]): Seq[Column] = {
    //20221125修改添加p4_cols_str
    val p1_cols_str_new = p1_cols_str.map("task_" + _)
    val new_cosl_str = p1_cols_str_new ++ p2_cols_str ++ p3_cols_str++p4_cols_str
    val sum_cols = (p1_cols_str ++ p2_cols_str).map(x => sum(col(x).cast("double")))
    val concat_cols = p3_cols_str.map(x => concat_ws("|", collect_set(col(x))))
    val p4_sum_cols = p4_cols_str.map(x => sum(col(x).cast("double")))
    val new_cols = sum_cols ++ concat_cols++p4_sum_cols
    ColumnUtil.renameColumn(new_cols, new_cosl_str)
  }

  def dropDuplicat = udf((error_type: String) => {
    var col_str = ""
    try {
      col_str = error_type.split("\\|").toSet.toArray.sortWith((x1, x2) => x1.toInt <= x2.toInt).mkString("|")
    } catch {
      case e: Exception => logger.error("原始数据中erro_type为 null ‘’ " + e.getMessage)
    }
    col_str
  })
}
