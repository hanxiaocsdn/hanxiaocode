package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter}
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: 576546
 * @description:告警数据--月度/3-6-12月汇总表 dm_gis.dwd_insurance_risk_alert_month_dtl
 * @demander: 01402323 罗祯
 * @author 01418539 caojia
 * @date 2022/11/21 15:18
 */
object VehicleRiskAlertMonthAndFeature extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val flag = args(1)
    if (flag == "1") processMonth(spark, inc_day)
    if (flag == "2") processYear(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processMonth(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val o_day_df = spark.sql(s"""select * from dm_gis.insurance_risk_alert_daily_fix where inc_day between '$month_first_day' and '$month_last_day'""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val deal_cols = Seq("car_no", "zy_type", "imei", "total_links_dist", "abn_alarm", "susp_abn_alarm", "inc_day").map(col)
    val eff_agg_cols_str = Seq("total_links_dist", "eff_alert_days", "abn_camera_days", "dev_alarm_exe_days", "susp_dms_alarm_days", "susp_adas_alarm_days")
    val eff_agg_cols = ColumnUtil.renameColumn(eff_agg_cols_str.map(sum(_)), eff_agg_cols_str)
    //一个月内有效天数表及异常标
    val s1_1_eff_days_df = o_day_df.select(deal_cols: _*)
      .withColumn("num", row_number().over(Window.partitionBy("car_no", "inc_day").orderBy(desc("inc_day"))))
      .filter('num === 1)
      .select(deal_cols: _*)
      .withColumn("eff_alert_days", when('total_links_dist.cast("double") > 5000 && ('abn_alarm.isNull || trim('abn_alarm) === ""), 1).otherwise(0))
      .withColumn("abn_camera_days", when('abn_alarm === "1", 1).otherwise(0))
      .withColumn("dev_alarm_exe_days", when('abn_alarm === "2", 1).otherwise(0))
      .withColumn("susp_dms_alarm_days", when('susp_abn_alarm === "1", 1).otherwise(0))
      .withColumn("susp_adas_alarm_days", when('susp_abn_alarm === "2", 1).otherwise(0))
      .groupBy("car_no", "zy_type")
      .agg(eff_agg_cols.head, eff_agg_cols.tail: _*)
      .select((Seq("car_no", "zy_type") ++ eff_agg_cols_str).map(col): _*)

    val sum_agg_cols_str = Seq("days_cnt", "average_speed", "alarm_sum_cnt", "alarm_night_cnt", "alarm_before_dawn_cnt", "alarm_early_morning_cnt", "alarm_afternoon_cnt", "alarm_dusk_cnt", "alarm_high_speed_cnt", "alarm_state_road_cnt", "alarm_provincial_cnt", "alarm_county_speed_cnt", "alarm_township_cnt", "med_risk_cnt", "high_risk_cnt")
    val max_agg_cols_str = Seq("alarm_sum_cnt", "alarm_night_cnt", "alarm_before_dawn_cnt", "alarm_early_morning_cnt", "alarm_afternoon_cnt", "alarm_dusk_cnt")
    val max_agg_cols_n_str = Seq("daily_alarm_cnt_max", "daily_night_cnt_max", "daily_before_dawn_cnt_max", "daily_early_morning_cnt_max", "daily_afternoon_cnt_max", "daily_dusk_cnt_max")
    val agg_cols = ColumnUtil.renameColumn(sum_agg_cols_str.map(sum(_)) ++ max_agg_cols_str.map(max(_)), sum_agg_cols_str ++ max_agg_cols_n_str)

    val s1_2_eff_days_df = o_day_df
      .withColumn("days_cnt", lit(1))
      .groupBy("car_no", "imei", "zy_type", "alarm_name_sta")
      .agg(agg_cols.head, agg_cols.tail: _*)
      .withColumn("average_speed", 'average_speed / 'days_cnt)
    val res_df_cols = spark.sql("""select * from dm_gis.dwd_insurance_risk_alert_month_dtl limit 0""").schema.map(x => col(x.name))
    val res_df = s1_1_eff_days_df.join(s1_2_eff_days_df, Seq("car_no", "zy_type"))
      .withColumn("inc_day", lit(month_last_day))
      .select(res_df_cols: _*)

    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.dwd_insurance_risk_alert_month_dtl")
    o_day_df.unpersist()
  }

  def processYear(spark: SparkSession, inc_day: String): Unit = {
    val months_3_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -3) //3月前的月初日期
    val months_6_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -6)
    val months_12_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -12)
    val last_month_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月底最后一天
    val months_12_df = spark.sql(s"""select * from dm_gis.dwd_insurance_risk_alert_month_dtl where inc_day between '$months_12_ago' and '$last_month_day'""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    processPartQuota(spark, months_12_df, months_3_ago, last_month_day, "3")
    processPartQuota(spark, months_12_df, months_6_ago, last_month_day, "6")
    processPartQuota(spark, months_12_df, months_12_ago, last_month_day, "12")
  }

  def processPartQuota(spark: SparkSession, months_12_df: DataFrame, months_filter_ago: String, last_month_day: String, months_flag: String): Unit = {
    import spark.implicits._
    val months_df = months_12_df.filter('inc_day >= months_filter_ago && 'inc_day <= last_month_day)
    val sum_agg_cols_str = Seq("months_cnt", "average_speed", "alarm_sum_cnt", "alarm_night_cnt", "alarm_before_dawn_cnt", "alarm_early_morning_cnt", "alarm_afternoon_cnt", "alarm_dusk_cnt", "alarm_high_speed_cnt", "alarm_state_road_cnt", "alarm_provincial_cnt", "alarm_county_speed_cnt", "alarm_township_cnt", "med_risk_cnt", "high_risk_cnt", "eff_alert_days", "abn_camera_days", "dev_alarm_exe_days", "susp_dms_alarm_days", "susp_adas_alarm_days", "total_links_dist")
    val max_agg_cols_str = Seq("daily_alarm_cnt_max", "daily_night_cnt_max", "daily_before_dawn_cnt_max", "daily_early_morning_cnt_max", "daily_afternoon_cnt_max", "daily_dusk_cnt_max")

    val agg_cols = ColumnUtil.renameColumn(sum_agg_cols_str.map(sum(_)) ++ max_agg_cols_str.map(max(_)), sum_agg_cols_str ++ max_agg_cols_str)
    val res_df_cols = spark.sql("""select * from dm_gis.dwd_insurance_risk_alert_feature_dtl limit 0""").schema.map(x => col(x.name))
    val res_df = months_df.withColumn("months_cnt", lit(1))
      .groupBy("car_no", "imei", "zy_type", "alarm_name_sta")
      .agg(agg_cols.head, agg_cols.tail: _*)
      .withColumn("start_end_time", concat(lit(months_filter_ago), lit("-"), lit(last_month_day)))
      .withColumn("months_flag", lit(months_flag))
      .withColumn("average_speed", 'average_speed / 'months_cnt)
      .withColumn("inc_day", lit(last_month_day))
      .select(res_df_cols: _*)
    writeToHive(spark, res_df, Seq("inc_day", "months_flag"), "dm_gis.dwd_insurance_risk_alert_feature_dtl")
  }
}
