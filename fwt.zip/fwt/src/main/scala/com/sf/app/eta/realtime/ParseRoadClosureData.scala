package com.sf.app.eta.realtime

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import org.apache.commons.lang3.time.FastDateFormat
//import utils.{HttpConstant, HttpConstantTest, HttpUtils}

import java.util.Date
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION} 时效定则 客观数据补充（封路部分）
 @create 2023/7/25
*/
object ParseRoadClosureData {
  //根据轨迹获取事件信息 1000次/分钟
  //  lazy val HTTP_STANDARD_EVENT_P = HttpConstant.HTTP_STANDARD_EVENT_P
  lazy val HTTP_STANDARD_EVENT_P = ""
  //根据swid 获取 轨迹点信息接口 5000/min
  //  lazy val HTTP_XY_COORDS_P = HttpConstant.HTTP_XY_COORDS_P
  lazy val HTTP_XY_COORDS_P = ""

  val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")

  /**
   * 第5部分入口 时效定责实时化需求-任务维度 （封路数据补充）
   *
   * @param org_json
   * @return
   */
  def roadClosedReplenish(sub_actual_depart_tm: String, sub_actual_arrive_tm: String, std_coords: String, jp_coords: String): JSONObject = {

    val org_json = new JSONObject()
    //    val sub_actual_depart_tm = org_json.getString("sub_actual_depart_tm")
    //    val sub_actual_arrive_tm = org_json.getString("sub_actual_arrive_tm")
    //    val std_coords = org_json.getString("std_coords")
    //    val jp_coords = org_json.getString("jp_coords")
    val plandate = sub_actual_depart_tm.replaceAll("\\s+|:|-", "")
    //1 标准轨迹 和 纠偏轨迹 分别调用接口 2次
    var std_back, jp_back = Tuple5("", "", "", "", "")
    if (strNotNull(plandate) && strNotNull(std_coords)) std_back = postCoordsBack(plandate, std_coords)
    if (strNotNull(plandate) && strNotNull(jp_coords)) jp_back = postCoordsBack(plandate, jp_coords)
    val (std_sw_id, std_fc, std_duration_sum, std_dr_length_sum, std_msg) = std_back
    val (jp_sw_id, jp_fc, jp_duration_sum, jp_dr_length_sum, jp_msg) = jp_back

    import scala.collection.JavaConversions._
    val javaMap: java.util.Map[String, Any] = Map("std_duration_sum" -> std_duration_sum, "std_dr_length_sum" -> std_dr_length_sum,
      "jp_duration_sum" -> jp_duration_sum, "jp_dr_length_sum" -> jp_dr_length_sum, "std_msg" -> std_msg, "jp_msg" -> jp_msg)
    org_json.putAll(javaMap)

    //2 标准线路调取事件信息接口 3次
    val depart_tstmp = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_depart_tm)
    val arrive_tstmp = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_arrive_tm)
    val avg_tmstmp = (arrive_tstmp + depart_tstmp) / 2
    val swid_info = getSwidFcAndTimeMap(std_sw_id, std_fc, depart_tstmp, arrive_tstmp, avg_tmstmp)
    val depart_back = postHistoryBack(swid_info._2, swid_info._1)
    val arrive_back = postHistoryBack(swid_info._3, swid_info._1)
    val avg_back = postHistoryBack(swid_info._4, swid_info._1)
    val events = Seq(depart_back._1, arrive_back._1, avg_back._1).mkString("||")
    val closure = Seq(depart_back._2, arrive_back._2, avg_back._2).mkString("||")
    val is_closure = getIsClosure(closure, std_duration_sum, jp_duration_sum)._1
    val closure_contime = getIsClosure(closure, std_duration_sum, jp_duration_sum)._2
    org_json.put("events", events)
    org_json.put("closure", closure)
    org_json.put("is_closure", is_closure)
    org_json.put("closure_contime", closure_contime)
    org_json
  }


  def getIsClosure(closure: Any, std_duration_sum: String, jp_duration_sum: String): (String, String) = {
    var isClosure, closure_contime: String = "0"
    if (strNotNull(closure) && strNotNull(closure.toString.replaceAll("\\|", ""))) {
      isClosure = "1"
      val diff = (try {
        jp_duration_sum.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      }) - (try {
        std_duration_sum.toDouble
      } catch {
        case e: NumberFormatException => 0.0
      })
      if (diff > 0.0) closure_contime = diff.formatted("%.2f")
    }
    (isClosure, closure_contime)
  }


  def postHistoryBack(tracks: String, swid_fc_map: collection.mutable.Map[String, String]): (String, String) = {
    val events_arr, closure_arr = new ListBuffer[String]()
    val params = s"""{"ak":"0fa8cc5bafa34689be91cde4c0f9fe08","focus":"event","tracks":$tracks}"""
    try {
      //      val event_str = HttpUtils.doPost(HTTP_STANDARD_EVENT_P,JSON.parseObject(params))
      val event_str = ""
      val event_json = JSON.parseObject(event_str)
      val event_tracks = event_json.getJSONArray("tracks")
      if (event_tracks != null && event_tracks.size() > 0) {
        for (i <- 0 until event_tracks.size()) {
          val link_id = event_tracks.getJSONObject(i).getString("link_id")
          val fc = swid_fc_map.getOrElse(link_id, "")
          val time = tranTstampToTime(sdf1, event_tracks.getJSONObject(i).getString("timestamp"))
          val events = event_tracks.getJSONObject(i).getJSONArray("events")
          if (events != null && events.size() > 0) {
            for (j <- 0 until events.size()) {
              val dir = events.getJSONObject(j).getString("dir")
              val limit_c = events.getJSONObject(j).getString("limit_c")
              val limit_t = events.getJSONObject(j).getString("limit_t")
              val reason_c = events.getJSONObject(j).getString("reason_c")
              val reason_t = events.getJSONObject(j).getString("reason_t")
              val time_s = events.getJSONObject(j).getString("time_s")
              val time_e = events.getJSONObject(j).getString("time_e")
              val content = events.getJSONObject(j).getString("content").replaceAll("\\n|\\r|\\t", "")
              val lrct = limit_c + "," + limit_t + "," + reason_c + "," + reason_t
              val merge_info = Seq(link_id, dir, fc, time, lrct, time_s, time_e, content).mkString("+")
              events_arr += merge_info
              if (limit_t == "1" && fc.toDouble < 3) closure_arr += merge_info
            }
          }
        }
      }
    } catch {
      case e: Exception =>
    }
    (events_arr.mkString("|"), closure_arr.mkString("|"))
  }

  def postCoordsBack(plandate: String, points: String): (String, String, String, String, String) = {
    val ak = "8bb09e5e110845f39a000391668e3e80"
    val params = s"""{"No":0,"opt":"sf4","test":1,"stype":0,"mode":2,"etype":0,"passport":"100000","speed":1,"plandate":"$plandate","simple_distance":0,"useEstimateTime":1,"ak":"$ak","points":"$points"}"""
    var duration_sum, dr_length_sum = 0.0
    val sw_id_ab, fc_ab = new ArrayBuffer[String]()
    var msg = ""

    try {
      //      val hw_str = HttpUtils.doPost(HTTP_XY_COORDS_P,JSON.parseObject(params))
      val hw_str = ""
      //      val hw_str = HttpInvokeUtil.sendPostH(HTTP_XY_COORDS_P, params, 3, 2, ak, "") //3000次/分钟
      //      logger.error(">>>>>>>>>接口正常调用中>>>>>>>>>>>>>>>")
      val hw_str_json = JSON.parseObject(hw_str)

      if (hw_str_json.getString("status") == "0") {
        val route = hw_str_json.getJSONObject("route")
        if (route != null) {
          val paths_arr = route.getJSONArray("paths")
          if (paths_arr != null && paths_arr.size() > 0) {
            for (i <- 0 until paths_arr.size()) {
              //1 dist dura求和
              duration_sum += (try {
                paths_arr.getJSONObject(i).getString("duration").toDouble
              } catch {
                case e: NumberFormatException => 0.0
              })
              dr_length_sum += (try {
                paths_arr.getJSONObject(i).getString("distance").toDouble
              } catch {
                case e: NumberFormatException => 0.0
              })
              //2 steps下信息统计
              val steps_arr = paths_arr.getJSONObject(i).getJSONArray("steps")
              if (steps_arr != null && steps_arr.size() > 0) {
                for (j <- 0 until steps_arr.size()) {
                  val links_arr = steps_arr.getJSONObject(j).getJSONArray("links")
                  if (links_arr != null && links_arr.size() > 0) {
                    for (k <- 0 until links_arr.size()) {
                      val sw_id_tmp = links_arr.getJSONObject(k).getString("sw_id")
                      val fc_tmp = links_arr.getJSONObject(k).getString("fc")
                      sw_id_ab += (if (strNotNull(sw_id_tmp)) sw_id_tmp else "-")
                      fc_ab += (if (strNotNull(fc_tmp)) fc_tmp else "-")
                    }
                  }
                }
              }
            }
          }
        } else {
          msg = "routeEmpty"
        }
      } else {
        msg = "postFailed"
      }
    } catch {
      case e: Exception => msg = "parseFailed"
    }
    (sw_id_ab.mkString("|"), fc_ab.mkString("|"), duration_sum.formatted("%.2f"), dr_length_sum.formatted("%.2f"), msg)
  }

  def getSwidFcAndTimeMap(std_sw_id: String, std_fc: String, depart_tstmp: Long, arrive_tstmp: Long, avg_tmstmp: Long): (collection.mutable.Map[String, String], String, String, String) = {
    val swid_fc_map = collection.mutable.Map[String, String]()
    val joa_depart, joa_arrive, joa_avg = new JSONArray()
    if (strNotNull(std_sw_id)) {
      val swid_arr = std_sw_id.split("\\|")
      val fc_arr = std_fc.split("\\|")
      try {
        for (i <- 0 until swid_arr.length) {
          val job1, job2, job3 = new JSONObject(true)
          swid_fc_map.put(swid_arr(i), fc_arr(i))
          job1.put("link_id", swid_arr(i))
          job1.put("timestamp", depart_tstmp)
          job2.put("link_id", swid_arr(i))
          job2.put("timestamp", arrive_tstmp)
          job3.put("link_id", swid_arr(i))
          job3.put("timestamp", avg_tmstmp)
          joa_depart.add(job1)
          joa_arrive.add(job2)
          joa_avg.add(job3)
        }
      } catch {
        case e: Exception =>
      }
    }
    (swid_fc_map, joa_depart.toJSONString, joa_arrive.toJSONString, joa_avg.toJSONString)
  }

  def strNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case _ => !str.toString.isEmpty && str.toString.replaceAll("-", "").trim != ""
    }
  }

  /**
   * 将指定格式的日期转时间戳，单位为：秒
   * 2021-01-01 11:11:11("yyyy-MM-dd HH:mm:ss")
   *
   * @return 1609470671
   */
  def timeToTimestampFormat(format: String, colValue: String): Long = {
    var ts = 0l
    try {
      val fdf = FastDateFormat.getInstance(format)
      val dt = fdf.parse(colValue)
      //时间戳毫秒转秒
      ts = dt.getTime / 1000
    } catch {
      case e: Exception => ""
    }
    ts
  }

  /**
   * 将指定格式的 时间戳 转 日期，单位为：秒
   * eg:1609470671
   * res:2021-01-01 11:11:11 or 2021/01/01 11:11:11
   */

  def tranTstampToTime(sdf: FastDateFormat, colValue: String): String = {
    var time = ""
    try {
      time = sdf.format(new Date(colValue.toLong * 1000))
    } catch {
      case e: Exception => ""
    }
    time
  }
}
