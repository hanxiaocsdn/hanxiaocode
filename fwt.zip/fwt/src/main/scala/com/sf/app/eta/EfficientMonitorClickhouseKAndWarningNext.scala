package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.DateUtil.getdaysBefore
import utils.SparkBuilder

import java.time.LocalTime

/**
 * @task_id: 840467
 * @description: 时效定责数据实时监控
 * @demander: 01430321 廖静文
 * @author 01418539 caojia
 * @date 2023/9/15 15:09
 */
object EfficientMonitorClickhouseKAndWarningNext extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    run(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val time_slot = getSlotTime(inc_day)._1
    val new_inc_day = getSlotTime(inc_day)._2
    val yes_inc_day = getdaysBefore(new_inc_day, -1, "yyyyMMdd")
    if (time_slot != "") {
      val yes_df = spark.sql(
        s"""select
           |count_warning yes_count_warning,
           |count_flatmap yes_count_flatmap,
           |count_cal2 yes_count_cal2,
           |count_recall yes_count_recall,
           |count_recall2 yes_count_recall2,
           |cal2_recall yes_cal2_recall,
           |recall_recall2 yes_recall_recall2,inc_day yes_inc_day,time_slot from dm_gis.eta_monitor_warning where inc_day = '$yes_inc_day' and time_slot='$time_slot'""".stripMargin)
      val today_df = spark.sql(s"""select count_warning,count_flatmap,count_cal2,count_recall,count_recall2,cal2_recall,recall_recall2,inc_day,time_slot from dm_gis.eta_monitor_warning where inc_day = '$new_inc_day' and time_slot='$time_slot'""")

      val exe_cond = 'count_warning.cast("double") < 'yes_count_warning.cast("double") * lit(0.1) ||
        'count_flatmap.cast("double") < 'yes_count_flatmap.cast("double") * lit(0.1) ||
        'count_cal2.cast("double") < 'yes_count_cal2.cast("double") * lit(0.1) ||
        'count_recall.cast("double") < 'yes_count_recall.cast("double") * lit(0.1) ||
        'count_recall2.cast("double") < 'yes_count_recall2.cast("double") * lit(0.1) ||
        'cal2_recall.cast("double") >= 3000 || 'recall_recall2.cast("double") >= 3000


      val res_df = today_df.join(yes_df, Seq("time_slot"))
        .withColumn("flag", when(exe_cond, null).otherwise("success"))
        .withColumn("info", exeUDF('flag))
      res_df.show(3)

    }
  }


  def exeUDF = udf((flag: String) => {
    val tmp = flag
    "success"
  })

  def getSlotTime(inc_day: String): (String, String) = {
    val current_hour = LocalTime.now().getHour
//    val current_hour = 21
    val for_inc_day = inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)
    var new_inc_day = inc_day
    var st_tm, ed_tm = ""
    if (current_hour % 3 == 0) {
      if (current_hour == 0) {
        new_inc_day = getdaysBefore(inc_day, -1, "yyyyMMdd")
        st_tm = "21"
        ed_tm = "24"
      } else if (Seq(3, 6, 9).contains(current_hour)) {
        st_tm = "0" + "" + (current_hour - 3)
        ed_tm = "0" + "" + current_hour
      } else if (current_hour == 12) {
        st_tm = "0" + "" + (current_hour - 3)
        ed_tm = "" + current_hour
      } else {
        st_tm = "" + (current_hour - 3)
        ed_tm = "" + current_hour
      }
    }
    (st_tm + "_" + ed_tm, new_inc_day)
  }
}
