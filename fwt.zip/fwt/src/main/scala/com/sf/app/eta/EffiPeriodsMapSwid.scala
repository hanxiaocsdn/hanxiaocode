package com.sf.app.eta

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.app.eta.EfficientLowerSpeedMerge.{splitFun, strHandle, strNotNull}
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.{HTPP_GIS_JP_LINK_SWID_G, HTTP_GD_ROAD_COND_P, HTTP_GIS_GW_TRACK_P, HTTP_JY_ROAD_COND_P}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{lngLatToDistance, sortField}
import utils.DateUtil.timeToTimestampFormat
import utils.HttpClientUtil.getJsonParam
import utils.{ColumnUtil, HttpInvokeUtil, SparkBuilder}

import java.text.DecimalFormat
import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}

/**
 * @description: 474413 时效定则第4部分补充需求 45min/d 接口限制:700/s 每天3kw
 * @author 01418539 caojia
 * @date 2022/8/26 10:46
 */
case class PartFourSwidBBox(x1: String, x2: String, x3: String, x4: String, x5: String, x6: String, x7: String, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String, x17: String, x18: String, x19: String, x20: String, x21: String, x22: String, x23: String, x24: String, x25: String, x26: String, x27: String, x28: String, x29: String, x30: String, x31: String, x32: String, x33: String, x34: String, x35: String, x36: String, x37: String, x38: String, x39: String, x40: String, x41: String, x42: String)

object EffiPeriodsMapSwid extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processDisu(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processDisu(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    import spark.implicits._
    val single_periods_infos_str = splitFun("&")('single_periods_infos)
    val other_event_infos_str = splitFun("&")('other_event_infos)
    val holiday_map_df = spark.sql("""select holiday_date from dm_gis.date_holiday_map""")
    val o_disu = loadAllData(spark, start_day, end_day)._1
    val o_swid_map = loadAllData(spark, start_day, end_day)._2
      .withColumn("part3_infos", concat_ws("&&", 'disu_periods, 'disu_rank, 'disu_swid, 'disu_dis, 'disu_duration, 'disu_speed, 'disu_duration_tl, 'disu_label_3))
      .withColumn("combine_infos", reCombine('part3_infos))
      .withColumn("single_periods_infos", explode(split('combine_infos, "\\|")))
      .withColumn("disu_periods", single_periods_infos_str(0))
      .withColumn("disu_rank", single_periods_infos_str(1))
      .withColumn("disu_swids", single_periods_infos_str(2))
      .withColumn("tile_version", single_periods_infos_str(3))
      .withColumn("start_time", single_periods_infos_str(4))
      .withColumn("end_time", single_periods_infos_str(5))
      .withColumn("disu_dis", single_periods_infos_str(6))
      .withColumn("disu_duration", single_periods_infos_str(7))
      .withColumn("disu_speed", single_periods_infos_str(8))
      .withColumn("disu_duration_tl", single_periods_infos_str(9))
      .withColumn("disu_label_3", single_periods_infos_str(10))
      .repartition(12, 'disu_periods)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val gd_httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "474413", "【eta】4.2EffiPeriodsMapSwid", "高德路况接口", HTTP_GD_ROAD_COND_P, "ef789d00926d46cdae8fc721608557ad", o_swid_map.count(), 12)
    val jy_httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "474413", "【eta】4.2EffiPeriodsMapSwid", "调经验速度接口", HTTP_JY_ROAD_COND_P, "dc894b4a3c7444b4a3505315d00b87ad", o_swid_map.count(), 12)
    val res_swid_map = o_swid_map
      .map(row => {
        val task_subid = row.getAs[String]("task_subid")
        val disu_periods = row.getAs[String]("disu_periods")
        val disu_rank = row.getAs[String]("disu_rank")
        val disu_swids = row.getAs[String]("disu_swids")
        val tile_version = row.getAs[String]("tile_version")
        val start_time = row.getAs[String]("start_time")
        val end_time = row.getAs[String]("end_time")
        val disu_dis = row.getAs[String]("disu_dis")
        val disu_duration = row.getAs[String]("disu_duration")
        val disu_speed = row.getAs[String]("disu_speed")
        val disu_duration_tl = row.getAs[String]("disu_duration_tl")
        val disu_label_3 = row.getAs[String]("disu_label_3")
        val swid_len_task_subid = row.getAs[String]("swid_len_task_subid")
        val inc_day = row.getAs[String]("inc_day")

        var disu_speed_tl = "0"
        try {
          disu_speed_tl = (disu_dis.toDouble * 3.6 / disu_duration_tl.toDouble).toString
        } catch {
          case e: Exception => ""
        }
        var timestamp = 0l
        try {
          timestamp = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", disu_periods.split("_")(0))
        } catch {
          case e: Exception => ""
        }
        //0 获取swid_len_task_subid 中 swid 与 dist 的对应关系
        val swid_len_task_subid_map = getSwidAndCount(swid_len_task_subid)
        //1、调用link相关信息接口
        //        val in1_res = getSwidsInter(disu_swids, start_time, end_time)
        //        val bbox = in1_res._1.toJSONString
        //        val disu_xmin_ab = in1_res._2
        //        val disu_ymin_ab = in1_res._3
        //        val disu_xmax_ab = in1_res._4
        //        val disu_ymax_ab = in1_res._5
        //        val ori_bearing_ab = in1_res._6
        val disu_xmin_ab = ListBuffer("0")
        val disu_ymin_ab = ListBuffer("0")
        val disu_xmax_ab = ListBuffer("0")
        val disu_ymax_ab = ListBuffer("0")
        val ori_bearing_ab = ListBuffer("0")
        val bbox = "0"

        //2.1 调用货车轨迹点接口
        //        val cond_coninc = disu_periods.split("_")(0).substring(0, 10) != disu_periods.split("_")(1).substring(0, 10)
        //        val int2 = cond_coninc match {
        //          case true =>
        //            val new_bbox = bbox.replaceAll(end_time, "235959")
        //            trackInfoInter(tile_version, new_bbox)
        //          case false => trackInfoInter(tile_version, bbox)
        //        }
        //        val imei_lishi = int2._1
        //        val imei_count = int2._2
        //        val guiji_lishi_imei = int2._3
        //        val imei_count2 = int2._4
        //        val lishi_mean_speed_ins = int2._5
        //        val lishi_speed_ins_ls = int2._6
        //        val guiji_info = int2._7
        val imei_lishi, imei_count, guiji_lishi_imei, imei_count2, lishi_mean_speed_ins, lishi_speed_ins_ls, guiji_info = "0"

        //2.2、调用高德路况接口
        val gd = gdInter(disu_swids, timestamp, swid_len_task_subid_map)
        val swid_len = gd._1
        val swid_gd_len = gd._2
        val swid_gd = gd._3
        val status_gd = gd._4
        val speed_gd = gd._5
        val speed_avg_gd = gd._6

        //2.3、判断主客观
        val sub_oj = JudSubAndObj(disu_speed_tl, speed_avg_gd, imei_count, imei_count2, lishi_mean_speed_ins, disu_label_3)

        //2.4、调经验速度接口
        val jy = jyInter(disu_swids, tile_version, start_time, sub_oj, disu_dis, disu_duration_tl, speed_avg_gd, swid_len_task_subid_map)
        val swid_exp = jy._1
        val swid_len_exp = jy._2
        val speed_exp = jy._3
        val disu_duration_exp = if (jy._4 > "0") jy._4 else "0"
        val disu_duration_sub = jy._5
        val disu_duration_ob = jy._6
        val disu_duration_sub_ob = jy._7
        PartFourSwidBBox(task_subid, disu_rank, disu_swids, disu_periods, tile_version, start_time, end_time, disu_xmin_ab.mkString("|"), disu_ymin_ab.mkString("|"), disu_xmax_ab.mkString("|"), disu_ymax_ab.mkString("|"), ori_bearing_ab.mkString("|"), bbox, disu_dis, disu_duration, disu_speed, disu_duration_tl, disu_speed_tl, swid_len_task_subid, disu_label_3, imei_lishi, imei_count, guiji_lishi_imei, imei_count2, lishi_mean_speed_ins, lishi_speed_ins_ls, swid_gd, status_gd, speed_gd, swid_len, swid_gd_len, speed_avg_gd, sub_oj, swid_exp, swid_len_exp, speed_exp, disu_duration_exp, disu_duration_sub, disu_duration_ob, disu_duration_sub_ob, guiji_info, inc_day)
      }).toDF("task_subid", "disu_rank", "disu_swids", "disu_periods", "tile_version", "start_time", "end_time", "disu_xmin", "disu_ymin", "disu_xmax", "disu_ymax", "ori_bearing", "bbox", "disu_dis", "disu_duration", "disu_speed", "disu_duration_tl", "disu_speed_tl", "swid_len_task_subid", "disu_label_3", "Imei_lishi", "Imei_count", "guiji_lishi_imei", "Imei_count2", "lishi_mean_speed_ins", "lishi_speed_ins_ls", "swid_gd", "status_gd", "speed_gd", "swid_len", "swid_gd_len", "speed_avg_gd", "sub_oj", "swid_exp", "swid_len_exp", "speed_exp", "disu_duration_exp", "disu_duration_sub", "disu_duration_ob", "disu_duration_sub_ob", "guiji_info", "inc_day")
      .join(broadcast(holiday_map_df), expr("tile_version = holiday_date"), "left")
      .na.fill("", Seq("start_time", "end_time", "disu_label_3", "sub_oj", "holiday_date"))
      .withColumn("disu_label_sub_oj", gaofengTraffic('start_time, 'end_time, 'disu_label_3, 'sub_oj, 'holiday_date))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    BdpTaskRecordUtil.endNetworkInterface("01418539", gd_httpInvoke)
    BdpTaskRecordUtil.endNetworkInterface("01418539", jy_httpInvoke)
    //eta_time_monitor_split_disu_his落表字段  拼装结果字段
    val disu_his_cols = spark.sql("""select * from dm_gis.eta_time_monitor_split_disu_his limit 0""").schema.map(_.name).map(col)
    val disu_2_cols = spark.sql("""select * from dm_gis.eta_time_monitor_disu_2 limit 0""").schema.map(_.name).map(col)

    val partAgg_df = res_swid_map.select("task_subid", "disu_rank", "disu_label_3", "sub_oj", "disu_duration_ob", "disu_duration_sub", "disu_duration_sub_ob", "inc_day")
    val p1_df = partAgg(partAgg_df)
    //20230214 新增字段逻辑
    val disu_duration_sub_ob_cond = when('sub_oj === "主观", 'disu_duration_sub)
      .when('sub_oj === "客观", 'disu_duration_ob)
      .when('sub_oj === "无法识别", 'disu_duration_sub_ob).otherwise("0.0")
    val add_peak_df = res_swid_map.select("task_subid", "disu_rank", "sub_oj", "disu_duration_ob", "disu_duration_sub", "disu_duration_sub_ob", "disu_label_sub_oj", "inc_day")
      .withColumn("peak_congestion_lowspeed_duration", when('disu_label_sub_oj === "高峰拥堵", 'disu_duration_ob).otherwise("0.0"))
      .withColumn("no_ob_lowspeed_duration", when('disu_label_sub_oj === "道路拥堵", 'disu_duration_ob).otherwise("0.0"))
      .withColumn("disu_duration_sub_ob", disu_duration_sub_ob_cond)
      .withColumn("num", row_number().over(Window.partitionBy('task_subid, 'inc_day).orderBy(col("disu_rank").cast("int").asc)))
      .sort(col("task_subid"), col("inc_day"), col("disu_rank").cast("int").asc)
      .groupBy("task_subid", "inc_day")
      .agg(
        sum("peak_congestion_lowspeed_duration") as "peak_congestion_lowspeed_duration",
        sum("no_ob_lowspeed_duration") as "no_ob_lowspeed_duration",
        concat_ws("|", collect_list(col("num"))) as "num",
        concat_ws("|", collect_list(col("disu_label_sub_oj"))) as "disu_label_sub_oj",
        concat_ws("|", collect_list(col("disu_duration_sub_ob"))) as "disu_duration_sub_ob")
      .withColumn("disu_label_sub_oj", sortField('num, 'disu_label_sub_oj))
      .withColumn("disu_duration_sub_ob", sortField('num, 'disu_duration_sub_ob))
      .select("task_subid", "peak_congestion_lowspeed_duration", "no_ob_lowspeed_duration", "disu_label_sub_oj", "disu_duration_sub_ob", "inc_day")

    val p1_df_tmp = p1_df.drop("no_ob_lowspeed_duration").join(add_peak_df, Seq("task_subid", "inc_day"))

    val p2_df = o_disu.join(p1_df_tmp, Seq("task_subid", "inc_day"))
      //.withColumn("disu_label_sub_oj", mergeLabelAndSub('disu_label_3, 'disu_sub_oj))
      .na.fill("", Seq("disu_label_3", "event_content", "event_code"))
      .withColumn("other_event_infos", getOtherEvent('disu_label_3, 'event_content, 'event_code))
      .withColumn("other_event_content", other_event_infos_str(0))
      .withColumn("other_event_code", other_event_infos_str(1))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val p3_df = p2_df.select(p2_df.schema.map(_.name).map(col) ++ addProportion("difftime_plan_actual"): _*)
      .withColumn("peak_congestion_lowspeed_duration_delay_ratio", 'peak_congestion_lowspeed_duration.cast("double") / 60 / col("difftime_plan_actual").cast("double"))
      .select(disu_2_cols: _*)
    writeToHive(spark, res_swid_map.select("task_subid", "disu_rank", "guiji_info", "inc_day").coalesce(3), Seq("inc_day"), "dm_gis.disu_guiji_tmp")
    writeToHive(spark, res_swid_map.select(disu_his_cols: _*).coalesce(3), Seq("inc_day"), "dm_gis.eta_time_monitor_split_disu_his")
    writeToHive(spark, p3_df.coalesce(3), Seq("inc_day"), "dm_gis.eta_time_monitor_disu_2")
    res_swid_map.unpersist()
    o_disu.unpersist()
    p2_df.unpersist()
  }


  def getOtherEvent = udf((disu_label_3: String, event_content: String, event_code: String) => {
    val label_arr = disu_label_3.split("\\|")
    val other_event_content_arr: Array[String] = new Array(label_arr.size)
    val other_event_code_arr: Array[String] = new Array(label_arr.size)
    var count = 0
    for (i <- 0 until label_arr.length) {
      if (label_arr(i) == "其他") {
        if (strNotNull(event_content) && strNotNull(event_code)) {
          val contents = event_content.split("\\|")
          val codes = event_code.split("\\|")
          breakable {
            for (j <- count until contents.length) {
              try {
                other_event_content_arr(i) = contents(j)
                other_event_code_arr(i) = codes(j)
                count += 1
                break
              } catch {
                case e: Exception => {
                  other_event_content_arr(i) = "-"
                  other_event_code_arr(i) = "-"
                  break
                }
              }
            }
          }
        }
      } else {
        other_event_content_arr(i) = "-"
        other_event_code_arr(i) = "-"
      }
    }
    other_event_content_arr.mkString("|") + "&" + other_event_code_arr.mkString("|")
  })

  def gaofengTraffic = udf((start_time: String, end_time: String, disu_label_3: String, sub_oj: String, holiday_date: String) => {
    var disu_label_sub_oj = disu_label_3 + "" + sub_oj
    var new_start_time, new_end_time = 0.0
    try {
      new_start_time = start_time.toDouble
    } catch {
      case e: Exception => ""
    }
    try {
      new_end_time = end_time.toDouble
    } catch {
      case e: Exception => ""
    }
    val morning_rush_hour = new_start_time >= 70000.0 && new_end_time <= 85959.0
    val evening_rush_hour = new_start_time >= 170000.0 && new_end_time <= 185959.0
    if (disu_label_3 == "无标记" && sub_oj == "客观") {
      if (morning_rush_hour || evening_rush_hour || holiday_date != "") {
        disu_label_sub_oj = "高峰拥堵"
      } else {
        disu_label_sub_oj = "道路拥堵"
      }
    }
    disu_label_sub_oj
  })

  def mergeLabelAndSub = udf((disu_label_3: String, disu_sub_oj: String) => {
    val label_so = new ListBuffer[String]()
    try {
      val label_arr = disu_label_3.split("\\|")
      val so_arr = disu_sub_oj.split("\\|")
      for (i <- 0 until label_arr.length) {
        if (label_arr(i) == "无标记" && so_arr(i) == "客观") label_so += "道路拥堵" else label_so += (label_arr(i) + so_arr(i))
      }
    } catch {
      case e: Exception => ""
    }
    label_so.mkString("|")
  })

  def partAgg(res_swid_map: DataFrame): DataFrame = {
    val self_cols = res_swid_map.schema.map(_.name).map(col)
    val judge_cols = addDurationSum("disu_label_3", "sub_oj", "disu_duration_ob", "disu_duration_sub", "disu_duration_sub_ob")
    val bef_cols_str = multiNames() ++ Seq("sub_oj")
    val aft_cols_str = multiNames() ++ Seq("disu_sub_oj")

    val aft_cols = bef_cols_str.map(x => {
      if (x != "sub_oj") sum(col(x).cast("double")) else concat_ws("|", collect_list(col("sub_oj")))
    })
    val agg_cols = ColumnUtil.renameColumn(aft_cols, aft_cols_str)

    val p1_df = res_swid_map.select(self_cols ++ judge_cols: _*).sort(col("task_subid"), col("inc_day"), col("disu_rank").cast("int").asc)
      .groupBy("task_subid", "inc_day")
      .agg(agg_cols.head, agg_cols.tail: _*)
    p1_df
  }

  /**
   * 增加低速段不同时间的总时长占比
   *
   * @param difftime_plan_actual
   * @return
   */
  def addProportion(difftime_plan_actual: String): Seq[Column] = {
    val judge_cols = multiNames().map(col)
    val judge_cols_nn = multiNames().map(_ + "_delay_ratio")
    val ratio_cols = judge_cols.map(x => x.cast("double") / 60 / col(difftime_plan_actual).cast("double"))
    ColumnUtil.renameColumn(ratio_cols, judge_cols_nn)
  }

  /**
   * 增加 低速段不同事件的时间汇总
   *
   * @param disu_label_3
   * @param sub_oj
   * @param disu_duration_ob
   * @param disu_duration_sub
   * @param disu_duration_sub_ob
   * @return
   */
  def addDurationSum(disu_label_3: String, sub_oj: String, disu_duration_ob: String, disu_duration_sub: String, disu_duration_sub_ob: String): Seq[Column] = {
    val label_cols = Seq("收费站", "起点", "服务区", "其他", "无标记", "疫情", "终点").map(x => col(disu_label_3) === x)
    val sub_cols = Seq("主观", "无法识别", "客观").map(x => col(sub_oj) === x)
    val duration_cols = Seq(disu_duration_sub, disu_duration_sub_ob, disu_duration_ob).map(col)
    val judge_cols = label_cols.map(x => {
      sub_cols.zip(duration_cols).map(y => when(x && y._1, y._2).otherwise(0))
    }).flatten
    val judge_cols_nn = multiNames()
    ColumnUtil.renameColumn(judge_cols, judge_cols_nn)
  }

  /**
   * 21个新字段重命名
   *
   * @return
   */
  def multiNames(): Seq[String] = {
    val ob_names = Seq("service_", "tollstation_", "epidemic_", "other_", "end_", "start_", "no_").map(_ + "ob_lowspeed_duration")
    val sub_names = Seq("service_", "tollstation_", "epidemic_", "other_", "end_", "start_", "no_").map(_ + "sub_lowspeed_duration")
    val ob_sub_names = Seq("service_", "tollstation_", "epidemic_", "other_", "end_", "start_", "no_").map(_ + "ob_sub_lowspeed_duration")
    (ob_names ++ sub_names ++ ob_sub_names).sortWith((x, y) => x > y)
  }

  //4、调经验速度接口
  def jyInter(disu_swids: String, tile_version: String, start_time: String, sub_oj: String, disu_dis: String, disu_duration_tl: String, speed_avg_gd: String, task_swid_map: mutable.HashMap[String, String]): (String, String, String, String, String, String, String) = {
    val swid_exp_arr, swid_len_exp_arr, speed_exp_arr = new ListBuffer[String]()
    var disu_duration_exp = 0.0
    var swid_exp, swid_len_exp, speed_exp = ""
    var disu_duration_sub, disu_duration_ob, disu_duration_sub_ob = "0"
    var new_disu_duration_tl, new_disu_dis, new_speed_avg_gd = 0.0
    try {
      new_disu_duration_tl = disu_duration_tl.toDouble
    } catch {
      case _ =>
    }
    try {
      new_disu_dis = disu_dis.toDouble
    } catch {
      case _ =>
    }
    try {
      new_speed_avg_gd = speed_avg_gd.toDouble
    } catch {
      case _ =>
    }
    try {
      val links = disu_swids.replaceAll(";", ",")
      val time = tile_version + "T112800"
      val jy_param =
        s"""{
           |"ak": "dc894b4a3c7444b4a3505315d00b87ad",
           |"swId": 1,
           |"links": "$links",
           |"type": 1,
           |"time": "$time",
           |"output": "json",
           |"gzip": "0",
           |"roadAttrToken": "6134FAA5B6B6ED55E87EA116466734ED"}""".stripMargin
      val jy_str = HttpInvokeUtil.sendPost(HTTP_JY_ROAD_COND_P, jy_param, 3, 2)
      //      logger.error("4 经验JY input：" + jy_param)
      //      logger.error("4 经验JY output：" + jy_str)
      val jy_info_json = JSON.parseObject(jy_str)
      val jy_tracks = jy_info_json.getJSONArray("linkCostArray")

      for (i <- 0 until jy_tracks.size()) {
        val linkID = jy_tracks.getJSONObject(i).getString("linkID")
        //linkID拼接
        swid_exp_arr += linkID
        //获取swid返回的长度
        val swid_len = task_swid_map.getOrElse(linkID, "")
        if (swid_len.trim != "") swid_len_exp_arr += swid_len else swid_len_exp_arr += "0"
        //低速速度拼接 km/h
        val costArray = jy_tracks.getJSONObject(i).getJSONArray("costArray")

        var diff = 235959
        var speed_exp_t = "0"
        for (j <- 0 until costArray.size()) {
          val startTime = costArray.getJSONObject(j).getString("startTime")
          val speed = costArray.getJSONObject(j).getString("speed")
          val cur_diff = Math.abs(start_time.toInt - startTime.toInt * 100) //start_time = 235523
          if (cur_diff <= diff) {
            diff = cur_diff
            speed_exp_t = speed
          }
        }
        val sd_tmp = if (speed_exp_t.toDouble > 0) 3.6 * swid_len.toDouble / speed_exp_t.toDouble else 0.0
        disu_duration_exp += sd_tmp
        speed_exp_arr += speed_exp_t
      }
    } catch {
      case e: Exception => ""
    }

    if (sub_oj == "主观") {
      val res = new_disu_duration_tl - 3.6 * new_disu_dis / Math.min(20, new_speed_avg_gd)
      if (res >= 0) disu_duration_sub = res.toString
    }
    if (sub_oj == "客观") {
      val res = new_disu_duration_tl - disu_duration_exp
      if (res >= 0) disu_duration_ob = res.toString
    }
    if (sub_oj == "无法识别") {
      val res = new_disu_duration_tl - disu_duration_exp
      if (res >= 0) disu_duration_sub_ob = res.toString
    }
    swid_exp = swid_exp_arr.mkString("|")
    swid_len_exp = swid_len_exp_arr.mkString("|")
    speed_exp = speed_exp_arr.mkString("|")
    (swid_exp, swid_len_exp, speed_exp, disu_duration_exp.toString, disu_duration_sub, disu_duration_ob, disu_duration_sub_ob)
  }

  //3、判断主客观
  def JudSubAndObj(disu_speed_tl: String, speed_avg_gd: String, imei_count: String, imei_count2: String, lishi_mean_speed_ins: String, disu_label_3: String): String = {
    val add_cond = disu_label_3 != "服务区" && disu_label_3 != "起点" && disu_label_3 != "终点"
    val cond1_part = disu_speed_tl.toDouble > 30 || disu_speed_tl.toDouble - speed_avg_gd.toDouble >= -25
    val cond2_part = disu_speed_tl.toDouble - speed_avg_gd.toDouble < -25

    val cond1_all = disu_speed_tl.toDouble > 30 || disu_speed_tl.toDouble - speed_avg_gd.toDouble >= -25 || (imei_count.toInt >= 3 && imei_count2.toInt >= 2 && disu_speed_tl.toDouble - lishi_mean_speed_ins.toDouble >= -15)
    val cond2_all = disu_speed_tl.toDouble - speed_avg_gd.toDouble < -25 || (imei_count.toInt >= 3 && imei_count2.toInt >= 2 && disu_speed_tl.toDouble - lishi_mean_speed_ins.toDouble < -15)
    val sub_oj = add_cond match {
      case true =>
        if (cond1_all) {
          "客观"
        } else if (cond2_all) {
          "主观"
        } else {
          "无法识别"
        }
      case _ =>
        if (cond1_part) {
          "客观"
        } else if (cond2_part) {
          "主观"
        } else {
          "无法识别"
        }
    }
    sub_oj
  }

  def getSwidAndCount(swid_len_task_subid: String): mutable.HashMap[String, String] = {
    val task_swid_map = new mutable.HashMap[String, String]()
    val task_swid_arr = try {
      swid_len_task_subid.split("\\|")
    } catch {
      case e: Exception => Array()
    }
    try {
      for (i <- 0 until task_swid_arr.length) {
        val swid = task_swid_arr(i).split(",")(0)
        val dist = task_swid_arr(i).split(",")(1)
        task_swid_map.put(swid, dist)
      }
    } catch {
      case e: Exception => ""
    }
    task_swid_map
  }

  def gdInter(disu_swids: String, timestamp: Long, task_swid_map: mutable.HashMap[String, String]): (String, String, String, String, String, String) = {
    val joa = new JSONArray()
    val swid_len_arr, swid_gd_len_arr, swid_gd_arr, status_gd_arr, speed_gd_arr = new ListBuffer[String]()

    if (strNotNull(disu_swids)) {
      val swids_arr = disu_swids.split(";") //disu_swids : 5793273973958;5793274015834;5793273364468;5793273364479
      for (swid <- swids_arr) {
        val job = new JSONObject(true)
        job.put("link_id", swid)
        job.put("timestamp", timestamp)
        joa.add(job)
        //在 swid_len_task_subid 匹配 disu_swids 对应的长度
        val swid_cnt = task_swid_map.getOrElse(swid, "")
        if (swid_cnt.trim != "") swid_len_arr += swid_cnt
      }
    }

    val tracks = joa.toJSONString
    //    val imei_attach_param = s"""{"ak":"ebf48ecaa1fd436fa3d40c4600aa051f","focus":"flow,event,warn","tracks":$tracks}""".stripMargin
    val imei_attach_param = s"""{"ak":"ef789d00926d46cdae8fc721608557ad","focus":"flow,event,warn","tracks":$tracks}""".stripMargin
    var swid_len = ""
    var swid_gd_len = ""
    var swid_gd = ""
    var status_gd = ""
    var speed_gd = ""
    var speed_avg_gd: Double = 0.0
    //    22/09/16 11:47:28 ERROR EffiPeriodsMapSwid$: 3 高德接口 input:{"ak":"ebf48ecaa1fd436fa3d40c4600aa051f","focus":"flow,event,warn","tracks":[{"link_id":"7462103624362","timestamp":1661973498},{"link_id":"7462103166604","timestamp":1661973498},{"link_id":"7462103625318","timestamp":1661973498},{"link_id":"7462103166608","timestamp":1661973498},{"link_id":"7462103625775","timestamp":1661973498}]}
    //高德接口调取有异常For input string: "35|35|51|36|39|41|41|41|35|96|48|36|32|36|39|40|40|41|41|42|41|38|35|35|40|22|22|22|22|37|39|39|41|53|43"
    //    logger.error("3 高德接口 input:" + imei_attach_param)
    try {
      val gd_str = HttpInvokeUtil.sendPost(HTTP_GD_ROAD_COND_P, imei_attach_param, 3, 2)
      //      logger.error("3 高德接口 output:" + gd_str)
      val gd_info_json = JSON.parseObject(gd_str)
      val gd_tracks = gd_info_json.getJSONArray("tracks")

      for (i <- 0 until gd_tracks.size()) {
        val flow = gd_tracks.getJSONObject(i).getJSONArray("flow")
        if (flow.size() > 0 && flow.toJSONString.replaceAll(" ", "") != "[]") {
          val link_id = gd_tracks.getJSONObject(i).getString("link_id")
          swid_gd_arr += link_id
          status_gd_arr += flow.getJSONObject(0).getString("status") //todo 需要确认flow中 只有单组还是多组
          speed_gd_arr += flow.getJSONObject(0).getString("speed")
          //在 swid_len_task_subid 匹配 link_id 对应的长度
          val link_id_cnt = task_swid_map.getOrElse(link_id, "")
          if (link_id_cnt.trim != "") swid_gd_len_arr += link_id_cnt else swid_gd_len_arr += "0"
        }
      }
      swid_len = swid_len_arr.mkString("|")
      swid_gd_len = swid_gd_len_arr.mkString("|")
      swid_gd = swid_gd_arr.mkString("|")
      status_gd = status_gd_arr.mkString("|")
      speed_gd = speed_gd_arr.mkString("|")

      var dist_sum: Double = 0.0
      var tm_sum: Double = 0.0

      for (i <- 0 until speed_gd_arr.length) {
        if (speed_gd_arr(i).toDouble != 0.0) {
          dist_sum += swid_gd_len_arr(i).toDouble
          tm_sum += swid_gd_len_arr(i).toDouble / speed_gd_arr(i).toDouble
        }
      }
      speed_avg_gd = if (tm_sum > 0) dist_sum / tm_sum else 0.0
    } catch {
      case e: Exception => ""
    }
    (swid_len, swid_gd_len, swid_gd, status_gd, speed_gd, speed_avg_gd.toString)
  }

  //  def trackInfoInter(tile_version: String, bbox: String): (String, String, String, String, String, String, String) = {
  //    //key---imei...value---imei个数 速度总和 timemax timemin tmax(lng lat) tmin(lng lat)
  //    val imei_info = new mutable.HashMap[String, (Int, Double, Long, Long, (Double, Double), (Double, Double))]()
  //    var imei_lishi = ""
  //    var imei_count: Int = 0
  //    var new_trac_arr: Array[String] = Array[String]()
  //
  //    val track_param = s"""{"tile_version":"$tile_version","data_id":26,"bbox":$bbox}""".stripMargin
  //    var track_info_str = ""
  //    try {
  //      track_info_str = HttpInvokeUtil.sendPostH(HTTP_GIS_GW_TRACK_P, track_param, 3, 2, "b9e1ffc397124bb6b1129876ab64e622", "trace_batch")
  //      logger.error("2 货车轨迹点 input：" + track_param)
  //      logger.error("2 货车轨迹点 output：" + track_info_str)
  //      val track_info_json = JSON.parseObject(track_info_str)
  //      val trac_arr = track_info_json.getJSONArray("trajectory")
  //      new_trac_arr = new Array[String](trac_arr.size())
  //
  //      for (i <- 0 until trac_arr.size()) {
  //        val imei = trac_arr.getJSONObject(i).getString("imei")
  //        val lng = trac_arr.getJSONObject(i).getDouble("lng")
  //        val lat = trac_arr.getJSONObject(i).getDouble("lat")
  //        val speed = trac_arr.getJSONObject(i).getJSONObject("info").getDouble("speed")
  //        val timeStamp = trac_arr.getJSONObject(i).getJSONObject("info").getLong("timeStamp") //毫秒
  //
  //        if (imei_info.contains(imei)) {
  //          val p1 = imei_info.get(imei)
  //          val tmax: Long = if (timeStamp >= p1.get._3) timeStamp else p1.get._3
  //          val tmin: Long = if (timeStamp <= p1.get._4) timeStamp else p1.get._4
  //          val llmax: (Double, Double) = if (timeStamp >= p1.get._3) (lng, lat) else p1.get._5
  //          val llmin: (Double, Double) = if (timeStamp >= p1.get._3) (lng, lat) else p1.get._6
  //          imei_info.put(imei, (p1.get._1 + 1, p1.get._2 + speed, tmax, tmin, llmax, llmin))
  //        } else {
  //          imei_info.put(imei, (1, speed, timeStamp, timeStamp, (lng, lat), (lng, lat)))
  //        }
  //
  //        if (!new_trac_arr.contains(imei)) {
  //          new_trac_arr(i) = imei
  //          imei_count += 1
  //        }
  //      }
  //    } catch {
  //      case e: Exception => logger.error("调用 货车轨迹点 有异常：" + e.printStackTrace())
  //    }
  //    imei_lishi = new_trac_arr.filter(_ != null).mkString("|")
  //    //继续标签处理
  //    val job = new JSONObject(true)
  //    val res_arr = new_trac_arr.filter(_ != null)
  //    var imei_count2: Int = 0
  //    var lishi_mean_speed_ins_sum: Double = 0.0
  //    val lishi_speed_ins_ls_arr = new ArrayBuffer[String]()
  //
  //    for (i <- 0 until res_arr.length) {
  //      val imei_r = imei_info.get(res_arr(i))
  //      val speed_ins = 3.6 * imei_r.get._2 / imei_r.get._1 //km/h
  //      val count = imei_r.get._1
  //      if (count > 1) imei_count2 += 1
  //      lishi_mean_speed_ins_sum += speed_ins
  //      lishi_speed_ins_ls_arr += speed_ins.toString
  //      val dist = lngLatToDistance(imei_r.get._5._1.toString, imei_r.get._5._2.toString, imei_r.get._6._1.toString, imei_r.get._6._2.toString)
  //      val tm_diff = ((imei_r.get._3 - imei_r.get._4) / 1000).toInt
  //      val speed_eta = 3.6 * dist / tm_diff
  //      val imei_attach_info = s"""{"speed_ins":$speed_ins,"count":$count,"dist":$dist,"tm_diff":$tm_diff,"speed_eta":$speed_eta}""".stripMargin
  //      job.put(res_arr(i), imei_attach_info)
  //    }
  //    val guiji_lishi_imei = job.toJSONString
  //    val lishi_mean_speed_ins = if (lishi_mean_speed_ins_sum / res_arr.length > 0) (lishi_mean_speed_ins_sum / res_arr.length).toString else "0"
  //    val lishi_speed_ins_ls = lishi_speed_ins_ls_arr.mkString("|")
  //    (imei_lishi, imei_count.toString, guiji_lishi_imei, imei_count2.toString, lishi_mean_speed_ins, lishi_speed_ins_ls, track_info_str)
  //  }

  //  def getSwidsInter(disu_swids: String, start_time: String, end_time: String): (JSONArray, ListBuffer[String], ListBuffer[String], ListBuffer[String], ListBuffer[String], ListBuffer[String]) = {
  //    val ak = "dc894b4a3c7444b4a3505315d00b87ad"
  //    val token = "6134FAA5B6B6ED55E87EA116466734ED"
  //    val disu_xmin_ab, disu_ymin_ab, disu_xmax_ab, disu_ymax_ab, x1_ab, y1_ab, x2_ab, y2_ab, ori_bearing_ab = new ListBuffer[String]
  //    val joa = new JSONArray()
  //    val dfm = new DecimalFormat("######0") //double 四舍五入取值
  //    val swid_arr = disu_swids.split(";")
  //    for (swid <- swid_arr) {
  //      var disu_xmin, disu_ymin, disu_xmax, disu_ymax = 0.0
  //      var x1, y1, x2, y2 = "0.0"
  //      val job = new JSONObject(true)
  //
  //      try {
  //        val url_param = getJsonParam(HTPP_GIS_JP_LINK_SWID_G, swid, ak, token)
  //        logger.error("1 links接口 input：" + url_param)
  //        val back_json_str = HttpInvokeUtil.sendGet(url_param, "UTF-8", 3)
  //        logger.error("1 links接口 output：" + back_json_str)
  //        val back_json: JSONObject = JSON.parseObject(back_json_str)
  //
  //        val pub1_cond = back_json.getJSONObject("line").getJSONObject("box")
  //        val pub2_cond = back_json.getJSONObject("line").getJSONObject("startpos")
  //        val pub3_cond = back_json.getJSONObject("line").getJSONObject("endpos")
  //
  //        disu_xmin = pub1_cond.getString("xmin").toDouble / 3600000
  //        disu_ymin = pub1_cond.getString("ymin").toDouble / 3600000
  //        disu_xmax = pub1_cond.getString("xmax").toDouble / 3600000
  //        disu_ymax = pub1_cond.getString("ymax").toDouble / 3600000
  //
  //        x1 = (pub2_cond.getString("x").toDouble / 3600000).toString
  //        y1 = (pub2_cond.getString("y").toDouble / 3600000).toString
  //        x2 = (pub3_cond.getString("x").toDouble / 3600000).toString
  //        y2 = (pub3_cond.getString("y").toDouble / 3600000).toString
  //      } catch {
  //        case e: Exception => logger.error("调度接口中有异常" + e.printStackTrace())
  //      }
  //      val ori_bearing = calculatorAngle(x1.toDouble, y1.toDouble, x2.toDouble, y2.toDouble)
  //
  //      job.put("start_time", start_time)
  //      job.put("end_time", end_time)
  //      job.put("ori_bearing", dfm.format(ori_bearing).toInt)
  //      job.put("angle", 30)
  //      job.put("minx", disu_xmin)
  //      job.put("miny", disu_ymin)
  //      job.put("maxx", disu_xmax)
  //      job.put("maxy", disu_ymax)
  //      joa.add(job)
  //
  //      disu_xmin_ab += disu_xmin.toString
  //      disu_ymin_ab += disu_ymin.toString
  //      disu_xmax_ab += disu_xmax.toString
  //      disu_ymax_ab += disu_ymax.toString
  //      x1_ab += x1
  //      y1_ab += y1
  //      x2_ab += x2
  //      y2_ab += y2
  //      ori_bearing_ab += ori_bearing.toString
  //    }
  //    (joa, disu_xmin_ab, disu_ymin_ab, disu_xmax_ab, disu_ymax_ab, ori_bearing_ab)
  //  }

  def loadAllData(spark: SparkSession, start_day: String, end_day: String): (DataFrame, DataFrame) = {
    import spark.implicits._
    val index_swids_infos_str = splitFun("&")('index_swids_infos)
    val swid_roadname_infos_str = splitFun("&&")('swid_roadname_infos)
    val rt_event_info_parse_str = splitFun("&")('rt_event_info_parse)
    val disu_cols_str: Seq[String] = Seq("task_subid", "task_inc_day", "sort_num", "start_dept", "end_dept", "actual_depart_tm", "actual_arrive_tm", "plan_run_time",
      "actual_run_time", "ac_is_run_ontime", "difftime_plan_actual", "vehicle_serial", "disu_cnt", "disu_rank", "disu_periods", "disu_duration", "disu_dis",
      "disu_speed", "if_tl_in_disu", "tl_stay_points", "tl_durations", "disu_duration_tl", "disu_label_3",
      "disu_swid", "disu_swids_begin", "disu_swids_end", "disu_roadname", "disu_roadname_begin", "disu_roadname_end", "event_code", "event_content", "inc_day")

    val disu_monitor_cols_str: Seq[String] = Seq("task_subid", "disu_rank", "disu_periods", "merge_disu_index", "disu_swid", "disu_dis", "disu_duration", "disu_speed", "disu_duration_tl", "disu_label_3", "swid_len_task_subid", "inc_day")
    val o_monitor = spark.sql(
      s"""
         |select task_subid,jp_time,jp_swid,t_links_union,rt_event_info,inc_day from dm_gis.eta_time_monitor where inc_day>='$start_day' and inc_day <= '$end_day'
         |--and task_subid in ('571Y138458131','755Y143642211')
         |--'551Y75842911'
         |""".stripMargin)
      .withColumn("swid_len_task_subid", dismantlingP18Links('t_links_union))
      .withColumn("disu_roadname_task_subid", dismantlingP13Links('t_links_union))
      .withColumn("rt_event_info_parse", parseRtEventInfo('rt_event_info))
      .withColumn("event_code", rt_event_info_parse_str(0))
      .withColumn("event_content", rt_event_info_parse_str(1))

    val swid_map = spark.sql(
      s"""
         |select task_subid,task_inc_day,sort_num,start_dept,end_dept,actual_depart_tm,actual_arrive_tm,plan_run_time,actual_run_time,ac_is_run_ontime,
         |       difftime_plan_actual,vehicle_serial,disu_cnt,disu_rank,disu_periods,disu_duration,disu_dis,disu_speed,if_tl_in_disu,tl_stay_points,tl_durations,
         |       disu_duration_tl,disu_label_3,inc_day from dm_gis.eta_time_monitor_disu
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |--and task_subid in ('571Y138458131','755Y143642211')
         |--and task_subid in ('010Y128312572','010Y128357891') limit 100  and task_subid='551Y75842911'
         |""".stripMargin)
      .join(o_monitor, Seq("task_subid", "inc_day"))
      .withColumn("index_swids_infos", getStartEndIndexFromJPTimeUDF(timeToTimestampFormat)('disu_periods, 'jp_time, 'jp_swid))
      .withColumn("merge_disu_index", index_swids_infos_str(0))
      .withColumn("disu_swid", index_swids_infos_str(1))
      .withColumn("swid_roadname_infos", swidMapRoadnameUDF('disu_swid, 'disu_roadname_task_subid))
      .withColumn("disu_swids_begin", swid_roadname_infos_str(0))
      .withColumn("disu_swids_end", swid_roadname_infos_str(1))
      .withColumn("disu_roadname", swid_roadname_infos_str(2))
      .withColumn("disu_roadname_begin", swid_roadname_infos_str(3))
      .withColumn("disu_roadname_end", swid_roadname_infos_str(4))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val s1_df = swid_map.select(disu_cols_str.map(col): _*)
      .withColumnRenamed("disu_swid", "disu_swids")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val s2_df = swid_map.select(disu_monitor_cols_str.map(col): _*)
      .repartition(300, col("task_subid"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    (s1_df, s2_df)
  }


  /**
   * 字段拆解 疫情 和 其他
   *
   * @return
   */
  def parseRtEventInfo = udf((rt_event_info: String) => {
    val other_codes = new ArrayBuffer[String]()
    val other_contents = new ArrayBuffer[String]()
    try {
      if (strNotBracket(rt_event_info)) {
        val str = JSON.parseArray(rt_event_info)
        for (i <- 0 until str.size()) {
          val event_content = str.getJSONObject(i).getString("event_content")
          val event_orCode = str.getJSONObject(i).getString("event_orCode")
          if (event_orCode != "0,0,6,16" && event_orCode != "1,1,6,16") {
            other_codes += event_orCode
            other_contents += event_content
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    other_codes.mkString("|") + "&" + other_contents.mkString("|")
  })

  def strNotBracket(str: String): Boolean = {
    try {
      str.trim != "" && str.nonEmpty && str.replaceAll("\\[|\\]", "").trim != ""
    } catch {
      case e: NullPointerException =>
        ""
        false
    }
  }


  def swidMapRoadnameUDF = udf((disu_swid: String, disu_roadname_task_subid: String) => {
    var begain_swid, end_swid = ""
    val disu_swids_begin, disu_swids_end, disu_roadname, disu_roadname_begin, disu_roadname_end = new ArrayBuffer[String]()
    val swid_name_map = new mutable.HashMap[String, String]()
    if (strNotNull(disu_roadname_task_subid)) {
      try {
        val roadname_arr = disu_roadname_task_subid.split("\\|")
        for (i <- 0 until roadname_arr.length) {
          val swid = roadname_arr(i).split(",")(0)
          val roadname = roadname_arr(i).split(",")(1)
          if (!swid_name_map.contains(swid)) swid_name_map.put(swid, roadname)
        }
      } catch {
        case e: Exception => ""
      }
    }

    if (strNotNull(disu_swid)) {
      try {
        val swid_arr = disu_swid.split("\\|")
        for (i <- 0 until swid_arr.length) {
          val each_swid = swid_arr(i).split(";")
          begain_swid = each_swid(0)
          end_swid = each_swid(each_swid.length - 1)
          disu_swids_begin += begain_swid
          disu_swids_end += end_swid
          val disu_roadname_inner = new ArrayBuffer[String]()
          for (j <- 0 until each_swid.length) {
            val rn = swid_name_map.getOrElse(each_swid(j), null)
            if (!disu_roadname_inner.contains(rn)) disu_roadname_inner += rn
          }
          val each_names = disu_roadname_inner.filter(_ != null)
          if (each_names.size == 0) {
            disu_roadname += "-"
            disu_roadname_begin += "-"
            disu_roadname_end += "-"
          } else {
            disu_roadname += each_names.mkString(",")
            disu_roadname_begin += each_names(0)
            disu_roadname_end += each_names(each_names.length - 1)
          }
        }
      } catch {
        case e: Exception => logger.error("roadname map error" + e.getMessage)
      }
    }
    disu_swids_begin.mkString("|") + "&&" + disu_swids_end.mkString("|") + "&&" + disu_roadname.mkString("|") + "&&" + disu_roadname_begin.mkString("|") + "&&" + disu_roadname_end.mkString("|")
  })

  /**
   * 暂时不用
   *
   * @param spark
   * @param start_day
   * @param end_day
   * @return
   */
  def loadDayData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    val o_swid_map = spark.sql(
      s"""
         |select task_subid,disu_rank,disu_periods,merge_disu_index,disu_swid,inc_day from dm_gis.eta_swid_map_periods where inc_day>='$start_day' and inc_day <= '$end_day'
         |""".stripMargin).repartition(360, col("task_subid"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    o_swid_map
  }

  def dismantlingP18Links = udf((t_links_union: String) => {
    var new_links = Array[String]()
    try {
      if (strNotNull(t_links_union)) {
        val links_arr = t_links_union.split("\\|")
        new_links = new Array[String](links_arr.length)
        for (i <- 0 until links_arr.length) {
          if (links_arr(i).split(",")(0).trim != "") {
            new_links(i) = links_arr(i).split(",")(0) + "," + links_arr(i).split(",")(7)
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    new_links.mkString("|")
  })

  /**
   * 取第1位为swid，第3位为swid所在的道路名称
   *
   * @return
   */
  def dismantlingP13Links = udf((t_links_union: String) => {
    var new_links = Array[String]()
    try {
      if (strNotNull(t_links_union)) {
        val links_arr = t_links_union.split("\\|")
        new_links = new Array[String](links_arr.length)
        for (i <- 0 until links_arr.length) {
          if (links_arr(i).split(",")(0).trim != "") {
            new_links(i) = links_arr(i).split(",")(0) + "," + links_arr(i).split(",")(2)
          }
        }
      }
    } catch {
      case e: Exception => logger.error("t_links_union 字段为空" + e.printStackTrace())
    }
    new_links.mkString("|")
  })

  def calculatorAngle(x1: Double, y1: Double, x2: Double, y2: Double): Double = {
    var angle = 0.0
    try {
      val dx = x2 - x1
      val dy = y2 - y1
      if (x1 == x2) {
        angle = math.Pi / 2.0
        if (y2 == y1) angle = 0.0
        if (y2 < y1) angle = 3.0 * math.Pi / 2.0
      } else if (x2 > x1 && y2 > y1) {
        angle = math.atan(dx / dy)
      } else if (x2 > x1 && y2 < y1) {
        angle = math.Pi / 2 + math.atan(-dy / dx)
      } else if (x2 < x1 && y2 < y1) {
        angle = math.Pi + math.atan(dx / dy)
      } else if (x2 < x1 && y2 > y1) {
        angle = 3.0 * math.Pi / 2.0 + math.atan(dy / -dx)
      }
    } catch {
      case e: Exception => ""
    }
    angle * 180 / math.Pi
  }

  def reCombine = udf((part3_infos: String) => {
    val combine_infos = new ListBuffer[String]()
    var all_infos_arr, periods_arr, rank_arr, swid_arr, dis_arr, duration_arr, speed_arr, duration_tl_arr, label_3_arr: Array[String] = Array()
    if (!part3_infos.isEmpty || part3_infos.replace("&&", "").trim != "") {
      all_infos_arr = part3_infos.split("&&")
      periods_arr = try {
        all_infos_arr(0).split("\\|")
      } catch {
        case _ => Array()
      }
      rank_arr = try {
        all_infos_arr(1).split("\\|")
      } catch {
        case _ => Array()
      }
      swid_arr = try {
        all_infos_arr(2).split("\\|")
      } catch {
        case _ => Array()
      }
      dis_arr = try {
        all_infos_arr(3).split("\\|")
      } catch {
        case _ => Array()
      }
      duration_arr = try {
        all_infos_arr(4).split("\\|")
      } catch {
        case _ => Array()
      }
      speed_arr = try {
        all_infos_arr(5).split("\\|")
      } catch {
        case _ => Array()
      }
      duration_tl_arr = try {
        all_infos_arr(6).split("\\|")
      } catch {
        case _ => Array()
      }
      label_3_arr = try {
        all_infos_arr(7).split("\\|")
      } catch {
        case _ => Array()
      }
      for (i <- 0 until periods_arr.length) {
        val tm_info = periods_arr(i)
        val tile_version = try {
          tm_info.split("_")(0).substring(0, 10).replace("-", "")
        } catch {
          case _ => ""
        }
        val start_time = try {
          tm_info.split("_")(0).split("\\s+")(1).replace(":", "")
        } catch {
          case _ => ""
        }
        val end_time = try {
          tm_info.split("_")(1).split("\\s+")(1).replace(":", "")
        } catch {
          case _ => ""
        }
        val duration_tl_arr_replace = try {
          duration_tl_arr(i)
        } catch {
          case e: Exception =>
            "0"
        }
        combine_infos += (tm_info + "&" + rank_arr(i) + "&" + (try {
          swid_arr(i)
        } catch {
          case _ => ""
        }) + "&" + tile_version + "&" + start_time + "&" + end_time + "&" + (try {
          dis_arr(i)
        } catch {
          case _ => ""
        }) + "&" + (try {
          duration_arr(i)
        } catch {
          case _ => ""
        }) + "&" + (try {
          speed_arr(i)
        } catch {
          case _ => ""
        }) + "&" + duration_tl_arr_replace + "&" + (try {
          label_3_arr(i)
        } catch {
          case _ => ""
        }))
      }
    }
    combine_infos.mkString("|")
  })


  /**
   * 合并后的低速时段 在jp_time中找到时间最近的起始 和 结束 时间的index
   *
   * @param fun
   * @return
   */
  def getStartEndIndexFromJPTimeUDF(fun: (String, String) => Long) = udf((disu_periods: String, jp_time: String, jp_swid: String) => {
    val jp_swid_p = new ListBuffer[String]()
    val ds_times = strHandle(disu_periods, "\\|").flatMap(_.split("_")).map(fun("yyyy-MM-dd HH:mm:ss", _)).sortWith(_.compareTo(_) < 0)
    val jp_time_arr: Array[String] = strHandle(jp_time, "\\|", false) //false 表示需要排序
    val jp_swid_arr: Array[String] = strHandle(jp_swid, "\\|")

    var merge_disu_index = ""

    if (jp_time_arr.length > 0) {
      val start_index_arr = new ArrayBuffer[Int]()
      val end_index_arr = new ArrayBuffer[Int]()
      for (i <- 0 until ds_times.length) {
        if (i % 2 == 0) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                start_index_arr += 0
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                start_index_arr += jp_time_arr.length - 1
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  start_index_arr += j
                } else {
                  start_index_arr += j + 1
                }
                break
              }
            }
          }
        }
        if (i % 2 == 1) {
          breakable {
            for (j <- 0 until jp_time_arr.length) {
              if (ds_times(i) <= jp_time_arr(0).toLong) {
                end_index_arr += 0
                break
              } else if (ds_times(i) >= jp_time_arr(jp_time_arr.length - 1).toLong) {
                end_index_arr += jp_time_arr.length - 1
                break
              } else if (ds_times(i) >= jp_time_arr(j).toLong && ds_times(i) <= jp_time_arr(j + 1).toLong) {
                if ((ds_times(i) - jp_time_arr(j).toLong) - (jp_time_arr(j + 1).toLong - ds_times(i)) <= 0) {
                  end_index_arr += j
                } else {
                  end_index_arr += j + 1
                }
                break
              }
            }
          }
        }
      }
      val start_end_index_arr = start_index_arr.zip(end_index_arr) map { x => x._1 + "_" + x._2 }
      merge_disu_index = start_end_index_arr.mkString("|")
      //第2部分
      val indexs: Array[String] = strHandle(merge_disu_index, "\\|")

      for (index <- indexs) {
        val start_index = index.split("_")(0).toInt
        val end_index = index.split("_")(1).toInt
        if (end_index + 1 < jp_swid_arr.length - 1) {
          val pt_swid_arr = jp_swid_arr.slice(start_index, end_index + 1)
          val new_pt_swid_arr = new Array[String](pt_swid_arr.length)
          for (i <- 0 until pt_swid_arr.length) {
            if (!new_pt_swid_arr.contains(pt_swid_arr(i))) new_pt_swid_arr(i) = pt_swid_arr(i)
          }
          jp_swid_p += new_pt_swid_arr.filter(_ != null).mkString(";")
        } else {
          val pt_swid_arr = jp_swid_arr.slice(start_index, jp_swid_arr.length - 1)
          val new_pt_swid_arr = new Array[String](pt_swid_arr.length)
          for (i <- 0 until pt_swid_arr.length) {
            if (!new_pt_swid_arr.contains(pt_swid_arr(i))) new_pt_swid_arr(i) = pt_swid_arr(i)
          }
          jp_swid_p += new_pt_swid_arr.filter(_ != null).mkString(";")
        }
      }
    }
    //结果包含 jp_swid 截取部分拼接
    merge_disu_index + "&" + jp_swid_p.mkString("|")
  })
}
