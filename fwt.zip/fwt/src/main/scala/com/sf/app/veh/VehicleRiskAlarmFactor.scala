package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{AnalysisException, DataFrame, SparkSession}
import utils.DateUtil.getInterDateList
import utils.SparkBuilder

/**
 * @task_id: 595030
 * @description:风险因子（含告警特征）
 * @demander: 01402323 罗祯
 * @author 01418539 caojia
 * @date 2022/12/7 10:29
 */
object VehicleRiskAlarmFactor extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    val month_flag = args(2)
    processLoadGzipCsv(spark, start_day, end_day, month_flag)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processLoadGzipCsv(spark: SparkSession, start_day: String, end_day: String, month_flag: String): Unit = {
    //拼装最终表结构
    val res_cols = spark.sql("""select * from dm_gis.ods_insurance_model_risk_alarm_factor_dtl limit 0""").schema.map(x => col(x.name))

    val data_list = getInterDateList(start_day, end_day, "yyyy-MM-dd").split(",")
    for (inc_day <- data_list) {
      var day_df: DataFrame = null
      for (day_flag <- 1 until 12) {
        val inputPath = "/user/01418539/upload/file/4Gdata/" + month_flag + "/" + inc_day + "_" + day_flag.toString + ".csv.gz"
        logger.error("输入文件路径：" + inputPath)
        var day_branch_df: DataFrame = null
        try {
          day_branch_df = spark.read.option("header", "true").option("delimiter", ",").option("inferSchema", true.toString).option("compresstion", "gzip")
            .csv(inputPath)
        } catch {
          case e: AnalysisException => println("-----文件不存在---------" + e.getMessage())
        }
        if (day_flag == 1) day_df = day_branch_df
        try {
          if (day_flag != 1) day_df = day_df.union(day_branch_df)
        } catch {
          case e: NullPointerException => println("-----文件不存在---------" + e.getMessage())
        }
      }
      val res_df = day_df.withColumn("inc_day", lit(inc_day.replace("-",""))).select(res_cols: _*)
      writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.ods_insurance_model_risk_alarm_factor_dtl")
    }
  }

}
