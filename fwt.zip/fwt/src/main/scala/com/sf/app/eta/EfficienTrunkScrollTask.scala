package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{daysBetweenDate, getdaysBeforeOrAfter}
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: 488534 (已下线 20231108) (inc_day T-2更新)
 * @description: 一级干线数据明细表 - 近7日有任务的 line_code
 * @demander: 01423319 李晗
 * @author 01418539 caojia
 * @date 2022/9/22 14:13
 */
object EfficienTrunkScrollTask extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val o_day = "20221005"
    //    val o_day = "20220831"
    val inc_day = args(0) //实际业务时间 T-1
    val control_flag = args(1)
    processLastStep(spark, o_day, control_flag, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processLastStep(spark: SparkSession, o_day: String, control_flag: String, inc_day: String): Unit = {
    val inter_days = daysBetweenDate(o_day, inc_day)
    val days_2_ago = getdaysBeforeOrAfter(inc_day, -1)
    val days_5_ago = getdaysBeforeOrAfter(inc_day, -4)
    val days_7_ago = getdaysBeforeOrAfter(inc_day, -6)
    val days_8_ago = getdaysBeforeOrAfter(inc_day, -7)
    var res_df: DataFrame = null
    //此处第1部分 plan_tm表T-1更新数据时，T-1当天数据偏少，所以第2部分更新T-2
    if (control_flag != "0") {
      processFirstPart(spark, inc_day, days_5_ago, days_7_ago)
    }
    if (control_flag != "0" && inter_days % 7 == 0) {
      val week_first_df = processSecondPart(spark, inc_day, days_2_ago, days_8_ago)
      val start_day = getdaysBeforeOrAfter(inc_day, -7)
      val week_scroll_df = processScrollPart(spark, start_day, inc_day, days_2_ago)
      res_df = week_first_df.union(week_scroll_df)
    }
    if (control_flag != "0" && inter_days % 7 != 0) {
      val start_day = getdaysBeforeOrAfter(inc_day, -(inter_days % 7))
      res_df = processScrollPart(spark, start_day, inc_day, days_2_ago)
    }
    writeToHive(spark, res_df.coalesce(3), Seq("inc_day"), "dm_gis.eta_task_scroll_prop_dtl")
  }

  def processScrollPart(spark: SparkSession, start_day: String, inc_day: String, days_2_ago: String): DataFrame = {
    import spark.implicits._
    //1 一级干线任务明细表
    val o1_trunk_df = spark.sql(s"""select * from dm_gis.eta_trunk_task_schedule_dtl where plan_tm between '$start_day' and '$days_2_ago'""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val update_time = inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)
    //2 时效延长表  pass 推送表
    //2.1获取 表dm_gis.plan_line_audit 中 import_batch字段最新的值
    //    val batch = spark.sql(
    //      s"""select
    //         |import_batch,
    //         |cast(split(import_batch,'-')[0] as bigint) ym,
    //         |cast(split(import_batch,'-')[1] as bigint) batch,
    //         |inc_day
    //         |from dm_gis.plan_line_audit where inc_day ='$inc_day' and import_batch like '%-%'""".stripMargin)
    //      .withColumn("num", row_number().over(Window.partitionBy('inc_day).orderBy(desc("ym"), desc("batch"))))
    //      .filter('num === 1)
    //    val batch_latest = batch.select("import_batch").map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "")
    //    logger.error(">>>最新的批次号为：import_batch>>>>" + batch_latest)

    val batch = spark.sql(
      s"""select
         |import_batch,
         |inc_day
         |from dm_gis.plan_line_audit where inc_day ='$inc_day' and import_batch !=''""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy('inc_day).orderBy(desc("import_batch"))))
      .filter('num === 1)
    val batch_latest = batch.select("import_batch").map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "")
    logger.error(">>>最新的批次号为：import_batch>>>>" + batch_latest)

    val o1_eta_pass_df = spark.sql(
      s"""
         |select id,line_code line_code_eta,create_date,flag,is_push,is_meet_push,time_process_com,success,push_time,import_batch,inc_day from
         |(select id,line_code,create_date,flag,is_push,is_meet_push,time_process_com,import_batch,inc_day from dm_gis.plan_line_audit
         |       where inc_day = '$inc_day'
         |       and import_batch in ($batch_latest)
         |       and id is not null and trim(id) != ''
         |       and line_code is not null and trim(line_code) != ''
         |       and flag='延长时长') t1
         |left join (select p_id,success,push_time from dm_gis.pass_resp where inc_day = '$inc_day'
         |             and p_id is not null and trim(p_id) != '') t2
         |on id = p_id
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("line_code_eta").orderBy(desc("push_time"))))
      .filter('num === 1).drop("num")

    val time_push_cond = 'is_meet_push === "2" && 'time_process_com === "1" && 'success === "1"
    val reject_push_cond = ('is_meet_push =!= "2" && 'time_process_com === "1") || ('is_meet_push === "2" && 'time_process_com === "1" && 'success === "0")

    val o2_trunk_dtl_df = o1_trunk_df.drop("task_area_code", "inc_day")
      .join(o1_eta_pass_df.drop("inc_day"), expr("line_code = line_code_eta"), "left")
      .withColumn("is_time_change_apply", when('line_code_eta.isNotNull, 1).otherwise(0))
      .withColumn("change_apply_date", substring('create_date, 0, 10))
      .withColumn("is_time_change_push", when(time_push_cond, "1").otherwise("0"))
      .withColumn("change_use_date", when(time_push_cond, substring('push_time, 0, 10)).otherwise(""))
      .withColumn("is_reject_push", when(reject_push_cond, "1").otherwise("0"))
      .withColumn("task_cnt", when('plan_tm === days_2_ago, 1).otherwise(0))
      .withColumn("last7d_task_cnt", when('plan_tm >= start_day && 'plan_tm <= days_2_ago, 1).otherwise(0))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //新增 多条件组合的 1 0 标签
    val day_cur_str = Seq("ontime_task_cnt", "no_ontime_task_cnt", "exe_task_cnt", "noexe_task_cnt", "is_zhuguan_task_cnt", "exe_ontime_cnt", "noexe_ontime_cnt", "zhuguan_exe_cnt", "zhuguan_noexe_cnt")
    val multi_cond_cols = addStatisticsCols(spark, day_cur_str, days_2_ago, start_day)
    //新增 多条件聚合标签
    val agg_cond_cols = aggStatisticsCols(day_cur_str :+ "task_cnt")

    val o3_agg_trunk_df = o2_trunk_dtl_df.select(Seq("line_code", "plan_tm", "task_cnt", "last7d_task_cnt", "run_ontime", "conduct_type1", "task_label1").map(col) ++ multi_cond_cols: _*)
      .groupBy("line_code")
      .agg(agg_cond_cols.head, agg_cond_cols.tail: _*)
      .withColumn("nozhuguan_exe_ontime_cnt", 'exe_ontime_cnt + 'zhuguan_exe_cnt)
      .withColumn("nozhuguan_noexe_ontime_cnt", 'noexe_ontime_cnt + 'zhuguan_noexe_cnt)
      .withColumn("last7d_nozhuguan_exe_ontime_cnt", 'last7d_exe_ontime_cnt + 'last7d_zhuguan_exe_cnt)
      .withColumn("last7d_nozhuguan_noexe_ontime_cnt", 'last7d_noexe_ontime_cnt + 'last7d_zhuguan_noexe_cnt)
      .withColumn("flag", lit("new"))
    //获取week首日的任务信息
    val o_week_df = spark.sql(s"""select line_code,task_area_code,task_area_name,end_dept,start_dept,basic_period,transport_level,is_time_change_apply,change_apply_date,is_time_change_push,change_use_date,is_reject_push,update_time,split_tag_new_type,split_tag_new,split_tag_old_type,split_tag_old,import_batch from dm_gis.eta_task_scroll_prop_dtl where inc_day = '$start_day' and data_update_type ='1'""")

    logger.error("o_week_df的数据量：" + o_week_df.count())
    val cnt_cols_str = Seq("task_cnt", "ontime_task_cnt", "no_ontime_task_cnt", "exe_task_cnt", "noexe_task_cnt", "is_zhuguan_task_cnt", "exe_ontime_cnt", "noexe_ontime_cnt", "zhuguan_exe_cnt", "zhuguan_noexe_cnt")
    val all_cnt_cols_str = cnt_cols_str ++ cnt_cols_str.map("last7d_" + _) ++ Seq("nozhuguan_exe_ontime_cnt", "nozhuguan_noexe_ontime_cnt", "last7d_nozhuguan_exe_ontime_cnt", "last7d_nozhuguan_noexe_ontime_cnt")

    val new_o3_agg_trunk_df = o_week_df.join(o3_agg_trunk_df, Seq("line_code"), "left")
      .na.fill(0, all_cnt_cols_str)

    //拼装最终表结构
    val res_cols = spark.sql("""select * from dm_gis.eta_task_scroll_prop_dtl limit 0""").schema.map(_.name).map(col)
    //新增 准点率及占比计算
    val res_df = new_o3_agg_trunk_df.select(new_o3_agg_trunk_df.schema.map(_.name).map(col) ++ addOntimeRatio: _*)
      .withColumn("data_update_type", lit("0"))
      .withColumn("plan_tm", lit(days_2_ago))
      .withColumn("inc_day", lit(inc_day))
      .na.fill("")
      .withColumn("num", row_number().over(Window.partitionBy(res_cols: _*).orderBy("inc_day"))).filter('num === 1)
      .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    res_df.show(1)
    o1_trunk_df.unpersist()
    o2_trunk_dtl_df.unpersist()
    res_df
  }

  def processSecondPart(spark: SparkSession, inc_day: String, days_2_ago: String, days_8_ago: String): DataFrame = {
    import spark.implicits._
    //1 一级干线任务明细表
    val o1_trunk_df = spark.sql(s"""select * from dm_gis.eta_trunk_task_schedule_dtl where plan_tm between '$days_8_ago' and '$days_2_ago'""")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val update_time = inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)
    //2 时效延长表  pass 推送表
    //2.1获取 表dm_gis.plan_line_audit 中 import_batch字段最新的值
    //    val batch = spark.sql(
    //      s"""select
    //         |import_batch,
    //         |cast(split(import_batch,'-')[0] as bigint) ym,
    //         |cast(split(import_batch,'-')[1] as bigint) batch,
    //         |inc_day
    //         |from dm_gis.plan_line_audit where inc_day ='$inc_day' and import_batch like '%-%'""".stripMargin)
    //      .withColumn("num", row_number().over(Window.partitionBy('inc_day).orderBy(desc("ym"), desc("batch"))))
    //      .filter('num === 1)

    val batch = spark.sql(
      s"""select
         |import_batch,
         |inc_day
         |from dm_gis.plan_line_audit where inc_day ='$inc_day' and import_batch !=''""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy('inc_day).orderBy(desc("import_batch"))))
      .filter('num === 1)

    val batch_latest = batch.select("import_batch").map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "")
    logger.error(">>>最新的批次号为：import_batch>>>>" + batch_latest)
    //2.2 根据plan_depart_tm  2021-11-16 05:39:33 获取最新的task_area_code作为最新的区域编码
    //区域代码映射关系数据
    val area_map_df = spark.sql("""select * from dm_gis.dim_area_code_name_mapping""")

    val o1_area_code_df = o1_trunk_df.select("line_code", "plan_tm", "start_dept", "end_dept", "task_area_code", "line_require_type")
      .withColumn("type_flag", when('line_require_type === "1", 1).otherwise(2))
      .withColumn("num", row_number().over(Window.partitionBy("line_code").orderBy(asc("type_flag"), desc("plan_tm"))))
      .filter('num === 1)
      .join(broadcast(area_map_df), Seq("task_area_code"), "left")
      .select("line_code", "task_area_code", "task_area_name", "start_dept", "end_dept")

    val o1_eta_pass_df = spark.sql(
      s"""
         |select id,line_code line_code_eta,create_date,flag,is_push,is_meet_push,time_process_com,success,push_time,import_batch,inc_day from
         |(select id,line_code,create_date,flag,is_push,is_meet_push,time_process_com,import_batch,inc_day from dm_gis.plan_line_audit
         |       where inc_day = '$inc_day'
         |       and import_batch in ($batch_latest)
         |       and id is not null and trim(id) != ''
         |       and line_code is not null and trim(line_code) != ''
         |       and flag='延长时长') t1
         |left join (select p_id,success,push_time from dm_gis.pass_resp where inc_day = '$inc_day'
         |             and p_id is not null and trim(p_id) != '') t2
         |on id = p_id
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("line_code_eta").orderBy(desc("push_time"))))
      .filter('num === 1).drop("num")

    val time_push_cond = 'is_meet_push === "2" && 'time_process_com === "1" && 'success === "1"
    val reject_push_cond = ('is_meet_push =!= "2" && 'time_process_com === "1") || ('is_meet_push === "2" && 'time_process_com === "1" && 'success === "0")

    val o2_trunk_dtl_df = o1_trunk_df.drop("task_area_code", "start_dept", "end_dept", "inc_day")
      .join(o1_eta_pass_df.drop("inc_day"), expr("line_code = line_code_eta"), "left")
      .withColumn("is_time_change_apply", when('line_code_eta.isNotNull, 1).otherwise(0))
      .withColumn("change_apply_date", substring('create_date, 0, 10))
      .withColumn("is_time_change_push", when(time_push_cond, "1").otherwise("0"))
      .withColumn("change_use_date", when(time_push_cond, substring('push_time, 0, 10)).otherwise(""))
      .withColumn("is_reject_push", when(reject_push_cond, "1").otherwise("0"))
      .withColumn("task_cnt", when('plan_tm === days_2_ago, 1).otherwise(0))
      .withColumn("last7d_task_cnt", when('plan_tm >= days_8_ago && 'plan_tm <= days_2_ago, 1).otherwise(0))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //新增 多条件组合的 1 0 标签
    val day_cur_str = Seq("ontime_task_cnt", "no_ontime_task_cnt", "exe_task_cnt", "noexe_task_cnt", "is_zhuguan_task_cnt", "exe_ontime_cnt", "noexe_ontime_cnt", "zhuguan_exe_cnt", "zhuguan_noexe_cnt")
    val multi_cond_cols = addStatisticsCols(spark, day_cur_str, days_2_ago, days_8_ago)
    //新增 多条件聚合标签
    val agg_cond_cols = aggStatisticsCols(day_cur_str :+ "task_cnt")

    val o3_agg_trunk_df = o2_trunk_dtl_df.select(Seq("line_code", "plan_tm", "task_cnt", "last7d_task_cnt", "run_ontime", "conduct_type1", "task_label1").map(col) ++ multi_cond_cols: _*)
      .groupBy("line_code")
      .agg(agg_cond_cols.head, agg_cond_cols.tail: _*)
      .withColumn("nozhuguan_exe_ontime_cnt", 'exe_ontime_cnt + 'zhuguan_exe_cnt)
      .withColumn("nozhuguan_noexe_ontime_cnt", 'noexe_ontime_cnt + 'zhuguan_noexe_cnt)
      .withColumn("last7d_nozhuguan_exe_ontime_cnt", 'last7d_exe_ontime_cnt + 'last7d_zhuguan_exe_cnt)
      .withColumn("last7d_nozhuguan_noexe_ontime_cnt", 'last7d_noexe_ontime_cnt + 'last7d_zhuguan_noexe_cnt)

    //新增 准点率及占比计算
    val o4_add_ratio_df = o3_agg_trunk_df.select(o3_agg_trunk_df.schema.map(_.name).map(col) ++ addOntimeRatio: _*)

    val p1_df = o2_trunk_dtl_df.drop("task_cnt", "last7d_task_cnt").join(o4_add_ratio_df, Seq("line_code"))
      .withColumn("split_tag_new_type", etaExtendCol(spark, days_8_ago, true))
      .withColumn("split_tag_new", etaExtendCol(spark, days_8_ago, false))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //非时效延长标  直接走步骤2
    val p21_df = p1_df.filter('is_time_change_apply =!= 1).drop("split_tag_new_type", "split_tag_new")
      .withColumn("split_tag_new_type", portionCol(spark, true))
      .withColumn("split_tag_new", portionCol(spark, false))
    //时效延长标 全 走步骤1
    val p22_df = p1_df.filter('is_time_change_apply === 1)
    //时效延长标中特定2类 走步骤2
    val p23_df = p1_df.filter('is_time_change_apply === 1 && 'split_tag_new.isin("时效延长-已驳回未闭环", "时效延长-已推送未改善"))
      .drop("split_tag_new_type", "split_tag_new")
      .withColumn("split_tag_new_type", portionCol(spark, true))
      .withColumn("split_tag_new", portionCol(spark, false))

    val o5_p1_p2_df = p21_df.union(p22_df).union(p23_df).persist(StorageLevel.MEMORY_AND_DISK_SER)

    //7天前的标签数据
    val last7d_quota = spark.sql(s"""select line_code,split_tag_new_type split_tag_old_type_7d,split_tag_new split_tag_old_7d from dm_gis.eta_task_scroll_prop_dtl where inc_day = '$days_8_ago' and data_update_type ='1' and line_code is not null and trim(line_code) !=''""".stripMargin)
    //历史所有
    val line_code_his_df = spark.sql(s"""select line_code from dm_gis.eta_task_scroll_prop_dtl where inc_day < '$inc_day' and line_code is not null and trim(line_code) !='' group by line_code""".stripMargin)
    val line_code_day_new = o5_p1_p2_df.select("line_code").distinct().join(line_code_his_df, Seq("line_code"), "left_anti")
      .withColumn("split_tag_old_type_first", lit("首次滚动"))
      .withColumn("split_tag_old_first", lit("首次滚动"))

    //拼装最终表结构
    val res_cols = spark.sql("""select * from dm_gis.eta_task_scroll_prop_dtl limit 0""").schema.map(_.name).map(col)
    val res_df = o5_p1_p2_df
      .join(last7d_quota, Seq("line_code"), "left")
      .join(line_code_day_new, Seq("line_code"), "left")
      .join(broadcast(o1_area_code_df), Seq("line_code"))
      .withColumn("split_tag_old_type", when('split_tag_old_type_7d.isNotNull && trim('split_tag_old_type_7d) =!= "", 'split_tag_old_type_7d)
        .when('split_tag_old_first === "首次滚动", 'split_tag_old_first)
        .otherwise("首次滚动"))
      .withColumn("split_tag_old", when('split_tag_old_7d.isNotNull && trim('split_tag_old_7d) =!= "", 'split_tag_old_7d)
        .when('split_tag_old_first === "首次滚动", 'split_tag_old_first)
        .otherwise("首次滚动"))
      .withColumn("plan_tm", lit(days_2_ago))
      .withColumn("update_time", lit(update_time))
      .withColumn("basic_period", concat_ws("-", lit(days_8_ago), lit(days_2_ago)))
      .withColumn("data_update_type", lit("1"))
      .withColumn("inc_day", lit(inc_day))
      .na.fill("")
      .withColumn("num", row_number().over(Window.partitionBy(res_cols: _*).orderBy("inc_day"))).filter('num === 1)
      .select(res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
    res_df.show(1)
    o1_trunk_df.unpersist()
    o2_trunk_dtl_df.unpersist()
    p1_df.unpersist()
    o5_p1_p2_df.unpersist()
    res_df
  }

  def portionCol(spark: SparkSession, col_flag: Boolean): Column = {
    import spark.implicits._
    var tag_col = lit("")
    val r1 = 'last7d_exe_rate >= 0.85 && 'last7d_ontime_rate >= 0.85
    val r2 = 'last7d_exe_task_cnt > 0 && 'last7d_noexe_task_cnt > 0 && 'last7d_exe_ontime_rate === 1 && 'last7d_noexe_ontime_rate === 1
    val r3 = 'last7d_exe_task_cnt === 0 && 'last7d_noexe_task_cnt >= 2 && 'last7d_nozhuguan_noexe_ontime_rate >= 0.85
    val r4 = 'last7d_exe_task_cnt > 0 && 'last7d_noexe_task_cnt / 'last7d_exe_task_cnt >= 2 && 'last7d_nozhuguan_noexe_ontime_rate >= 0.85
    val r5 = 'last7d_task_cnt >= 3 && 'last7d_exe_task_cnt > 0 && 'last7d_noexe_task_cnt / 'last7d_exe_task_cnt < 2 && 'last7d_noexe_task_cnt / 'last7d_exe_task_cnt > 0.5 && 'last7d_nozhuguan_noexe_ontime_rate > 'last7d_nozhuguan_exe_ontime_rate
    val r6 = 'last7d_exe_task_cnt >= 3 && 'last7d_nozhuguan_exe_ontime_rate <= 0.5
    val r7 = 'last7d_is_zhuguan_task_cnt >= 1 && 'last7d_is_zhuguan_rate >= 0.5
    val r8 = 'last7d_task_cnt >= 3 && 'last7d_exe_rate <= 0.5 && (('last7d_ontime_task_cnt + 'last7d_is_zhuguan_task_cnt) / 'last7d_task_cnt) <= 0.5
    val r9 = 'last7d_task_cnt >= 3 && 'last7d_exe_task_cnt > 0 && 'last7d_noexe_task_cnt >= 2 && 'last7d_nozhuguan_exe_ontime_rate > 'last7d_nozhuguan_noexe_ontime_rate

    if (col_flag) {
      tag_col = when(r1 || r2, "高准点线路").when(r3 || r4 || r5 || r6, "线路评估")
        .when(r7 || r8 || r9, "地区管控").otherwise("暂未识别问题")
    } else {
      tag_col = when(r1, "高准点线路线路-高执行高准点").when(r2, "高准点线路-近7日准点率100%")
        .when(r3, "线路评估-低执行高准点").when(r4, "线路评估-低执行高准点")
        .when(r5, "线路评估-执行准点逆向").when(r6, "线路评估-高执行低准点")
        .when(r7, "地区管控-高主观问题占比").when(r8, "地区管控-规划线路执行")
        .when(r9, "地区管控-规划线路执行").otherwise("暂未识别问题")
    }
    tag_col
  }

  def etaExtendCol(spark: SparkSession, days_8_ago: String, col_flag: Boolean): Column = {
    import spark.implicits._
    var tag_col = lit("")
    //已驳回
    val x1 = 'is_reject_push === "1" && 'last7d_ontime_rate >= 0.85
    val x2 = 'is_reject_push === "1" && 'last7d_ontime_rate < 0.85
    //申请调整
    val y1 = 'is_time_change_push === "0" && 'is_time_change_apply === "1" && 'change_apply_date > days_8_ago
    val y2 = 'is_time_change_push === "0" && 'is_time_change_apply === "1" && 'change_apply_date <= days_8_ago && 'last7d_ontime_rate >= 0.85
    val y3 = 'is_time_change_push === "0" && 'is_time_change_apply === "1" && 'change_apply_date <= days_8_ago && 'last7d_ontime_rate < 0.85
    //已推送
    val z1 = 'is_time_change_push === "1" && 'change_apply_date > days_8_ago
    val z2 = 'is_time_change_push === "1" && 'change_apply_date <= days_8_ago && 'last7d_ontime_rate >= 0.85
    val z3 = 'is_time_change_push === "1" && 'change_apply_date <= days_8_ago && 'last7d_ontime_rate < 0.85

    val head_route = x1 || y2 || z2
    val eta_extend = x2 || y1 || y3 || z1 || z3

    if (col_flag) {
      tag_col = when(head_route, "高准点线路").when(eta_extend, "时效延长").otherwise("暂未识别问题")
    } else {
      tag_col = when(x1, "时效延长-已驳回已闭环").when(x2, "时效延长-已驳回未闭环")
        .when(y1, "时效延长-已申请审批中").when(y2, "时效延长-已申请已闭环").when(y3, "时效延长-已申请审批中")
        .when(z1, "时效延长-已推送待监控").when(z2, "时效延长-已推送已改善").when(z3, "时效延长-已推送未改善")
        .otherwise("暂未识别问题")
    }
    tag_col
  }

  def addOntimeRatio(): Seq[Column] = {
    val ratio_p_cols_str = Seq("ontime_task_cnt", "exe_task_cnt", "is_zhuguan_task_cnt", "exe_ontime_cnt", "noexe_ontime_cnt", "nozhuguan_exe_ontime_cnt", "nozhuguan_noexe_ontime_cnt")
    val ratio_a_cols_str = Seq("task_cnt", "task_cnt", "no_ontime_task_cnt", "exe_task_cnt", "noexe_task_cnt", "exe_task_cnt", "noexe_task_cnt")
    val ratio_cols_str = Seq("ontime_rate", "exe_rate", "is_zhuguan_rate", "exe_ontime_rate", "noexe_ontime_rate", "nozhuguan_exe_ontime_rate", "nozhuguan_noexe_ontime_rate")
    val cur_day_cols = ratio_p_cols_str.map(col) zip ratio_a_cols_str.map(col) map { x => when(x._2 =!= 0, x._1 / x._2).otherwise("-") }
    val last7d_day_cols = ratio_p_cols_str.map(x => col("last7d_" + x)) zip ratio_a_cols_str.map(x => col("last7d_" + x)) map { x => when(x._2 =!= 0, x._1 / x._2).otherwise("-") }
    ColumnUtil.renameColumn(cur_day_cols ++ last7d_day_cols, ratio_cols_str ++ ratio_cols_str.map("last7d_" + _))
  }

  def aggStatisticsCols(day_cur_str: Seq[String]): Seq[Column] = {
    val add_last7d_str = day_cur_str.map("last7d_" + _)
    val two_part_cols = (day_cur_str ++ add_last7d_str).map(x => sum(col(x)))
    ColumnUtil.renameColumn(two_part_cols, day_cur_str ++ add_last7d_str)
  }

  def addStatisticsCols(spark: SparkSession, day_cur_str: Seq[String], days_2_ago: String, days_8_ago: String): Seq[Column] = {
    import spark.implicits._
    val day_cur = 'plan_tm === days_2_ago
    val day_c7 = 'plan_tm >= days_8_ago && 'plan_tm <= days_2_ago
    val ontime = 'run_ontime === "准点"
    val no_ontime = 'run_ontime === "超时"
    val conduct_1 = 'conduct_type1 === "执行"
    val conduct_2 = 'conduct_type1 === "未执行"
    val zhuguan = 'task_label1 === "主观"
    val day_last7d_str = day_cur_str.map("last7d_" + _)
    val multi_conds = Seq(ontime, no_ontime, conduct_1, conduct_2, zhuguan, ontime && conduct_1, ontime && conduct_2, zhuguan && conduct_1, zhuguan && conduct_2)
    val day_cur_cols = multi_conds.map(x => when(x && day_cur, 1).otherwise(0))
    val day_7_cols = multi_conds.map(x => when(x && day_c7, 1).otherwise(0))
    ColumnUtil.renameColumn(day_cur_cols ++ day_7_cols, day_cur_str ++ day_last7d_str)
  }

  def processFirstPart(spark: SparkSession, inc_day: String, days_5_ago: String, days_7_ago: String): DataFrame = {
    val res_cols = spark.sql("""select * from dm_gis.eta_trunk_task_schedule_dtl limit 0""").schema.map(_.name).map(col)
    val fp_sql =
      s"""select
         |b.vehicle_serial,b.task_id,b.line_code,task_area_code,start_dept,end_dept,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,driver_name,driver_id,run_ontime,
         |if_evaluate_time,conduct_type1,rt_dist,pns_dist,is_stop1,carrier_type1,transoport_level transport_level,if_error,line_time,actual_run_time,(actual_run_time-line_time) as delay_time,b.carrier_name,tollstation_sub_final, -- 收费站主观停留时长
         |epidemic_sub_final,---疫情主观停留时长
         |zhuguan_fuwuqu, ---	服务区主观停留时长
         |start_sub_final,---起点主观停留时长
         |end_sub_final,---终点主观停留时长
         |task_label1,---标签
         |line_require_type,b.inc_day inc_day,regexp_replace(substr(b.plan_depart_tm, 1, 10),'-','') as plan_tm
         |from
         |(select plan_depart_tm,line_code,task_id,carrier_name,vehicle_serial,line_require_type,inc_day
         |from dm_grd.grd_new_task_detail where inc_day between '$days_5_ago' and '$inc_day'
         |      and transoport_level=1
         |      and is_timeliness_appraise=1
         |      and state='6'
         |      and regexp_replace(substr(plan_depart_tm, 1, 10),'-','') between '$days_5_ago' and '$inc_day')b
         |left join
         |(select cc.task_id,cc.tollstation_sub_final, -- 收费站主观停留时长
         |cc.epidemic_sub_final,---疫情主观停留时长
         |cc.zhuguan_fuwuqu, ---	服务区主观停留时长
         |cc.start_sub_final,---起点主观停留时长
         |cc.end_sub_final,---终点主观停留时长
         |cc.task_label1---标签
         |from
         |(select task_id,tollstation_sub_final,epidemic_sub_final,zhuguan_fuwuqu,start_sub_final,end_sub_final,task_label1,
         |    row_number() over(PARTITION by task_id ORDER by inc_day desc) as rk
         |    from dm_gis.eta_task_time_information1
         |    WHERE inc_day between '$days_7_ago' AND '$inc_day')cc
         |    where cc.rk=1)c
         |on b.task_id=c.task_id
         |left join
         |(select
         |dd.plan_depart_tm,
         |      dd.vehicle_serial,
         |      dd.task_id,
         |      dd.task_area_code,
         |      dd.line_code,
         |      dd.start_dept,
         |      dd.end_dept,
         |      dd.actual_depart_tm,
         |      dd.plan_arrive_tm,
         |      dd.actual_arrive_tm,
         |      dd.driver_name,
         |      dd.driver_id,
         |      dd.if_evaluate_time,
         |      dd.conduct_type1,
         |      dd.rt_dist,
         |      dd.pns_dist,
         |      dd.is_stop1,
         |      dd.carrier_type1,
         |      dd.if_error,
         |      dd.transoport_level,
         |      dd.line_time,
         |    dd.actual_run_time
         |        from
         |(select
         |      plan_depart_tm,
         |      vehicle_serial,
         |      task_id,
         |      task_area_code,
         |      line_code,
         |      start_dept,
         |      end_dept,
         |      actual_depart_tm,
         |      plan_arrive_tm,
         |      actual_arrive_tm,
         |      driver_name,
         |      driver_id,
         |      if_evaluate_time,
         |      case when conduct_type=1 then '执行' when conduct_type=3 then '未执行' else null end as conduct_type1,
         |      rt_dist,---实际里程
         | 	 pns_dist,---标准线路里程
         |    CASE WHEN is_stop=1 THEN '直发' when is_stop=2 then '经停' when is_stop=3 then '多卸货口' ELSE NULL END AS is_stop1,
         |      case when carrier_type=0 then '自营' when carrier_type=1 then '外包' else null end as carrier_type1,
         |    transoport_level,
         |    if_error,
         |    	line_time, --计划运行时长
         |        actual_run_time,
         |      row_number() over(partition by task_id order by last_update_tm desc) as t
         |    from
         |      dm_gis.eta_std_line_recall1
         |    where
         |      inc_day between '$days_7_ago' and '$inc_day'
         |      and transoport_level=1
         |      and if_evaluate_time=1
         |  )dd
         |  where t=1)d
         |  on b.task_id=d.task_id
         |left join
         |(select
         |task_id,
         |case when run_zd_flag='运行准点' then '准点' when run_zd_flag='运行晚点' then '超时' else null end as run_ontime
         |from dm_tdsp.grd_reach_run_detail_rpt
         |where inc_day between '$days_7_ago' and '$inc_day'
         |)e
         |on b.task_id=e.task_id
         |WHERE task_area_code IN ('111Y','666Y','999Y','888Y','333Y','222Y','777Y','300Y','555Y','700Y')
         |and run_ontime is not null""".stripMargin
    val o1_trunk_df = spark.sql(fp_sql).select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    writeToHive(spark, o1_trunk_df, Seq("plan_tm"), "dm_gis.eta_trunk_task_schedule_dtl")
    o1_trunk_df
  }

}
