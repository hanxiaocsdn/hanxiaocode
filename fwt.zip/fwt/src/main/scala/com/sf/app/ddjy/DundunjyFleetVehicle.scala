package com.sf.app.ddjy

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{splitFun, strNotNull}
import utils.DateUtil.{daysBetweenDate, getDaysApartDate, getdaysBeforeOrAfter}
import utils.SparkBuilder

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 540 (新平台)
 * @description: 车队全量表 V1.0/V1.1 dm_gis.ddjy_dwd_team_quota_dtl
 * @demander: 01424177 陶慧
 * @author 01418539 caojia
 * @date 2023/2/7 17:16
 */
object DundunjyFleetVehicle extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSparkNew(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val if_first_day = args(1)
    val first_day = args(2) // 首次设置初始日期："20230120"
    processDDJY(spark, inc_day, if_first_day, first_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processDDJY(spark: SparkSession, inc_day: String, if_first_day: String, first_day: String): Unit = {
    import spark.implicits._
    val o_day = "20220816"
    val days_1_ago = getdaysBeforeOrAfter(inc_day, -1)
    val days_10_ago = getdaysBeforeOrAfter(inc_day, -10)
    //1111 车队表(F全量) ddjy_dim_team_info_filter（id--车队id,  tax_no--纳税识别号）---del_flag='0'
    val o_chedui = spark.sql(
      s"""select id team_id,name,contact_name,contact_phone,tax_no,inc_day from dm_gis.ddjy_dim_team_info_filter
         |where inc_day = '$inc_day' and del_flag= '0'
         |and id is not null and trim(id)!=''""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //2222 销售表(F全量)  ddjy_ods_sales_team（team_id）
    val o_sales = spark.sql(
      s"""select team_id,max(user_name) user_name,max(user_id) user_id,max(sub_name) sub_name,max(sub_code) sub_code,max(sup_name) sup_name,
         |max(sup_code) sup_code,inc_day from dm_gis.ddjy_ods_sales_team
         |where inc_day = '$inc_day'
         |group by team_id,inc_day
         |""".stripMargin)

    //3333 充值表(I增量) ddjy_dwd_car_team_history_recharge（team_id） --trade_description = '车队充值上账'
    val o_recharge_initial = spark.sql(
      s"""select team_id,trade_time,trade_amount,inc_day from dm_gis.ddjy_dwd_car_team_history_recharge
         |where inc_day between '$o_day' and '$inc_day' and trade_description in ('车队充值上账','代收代付充值')""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val o_recharge = o_recharge_initial
      .groupBy("team_id")
      .agg(min('trade_time) as "first_trade_time",
        count('trade_time) as "cnt_trade_time",
        sum('trade_amount) as "total_trade_amount")
      .withColumn("first_mon_trade_time", substring('first_trade_time, 1, 7))
      .select("team_id", "first_trade_time", "cnt_trade_time", "total_trade_amount", "first_mon_trade_time")

    //4444 账单表(F全量) dm_ddjy_team_account_report_di（team_id）
    val o_bill = spark.sql(
      s"""select team_id,max(end_balance) total_end_balance from dm_gis.dm_ddjy_team_account_report_di
         |where inc_day = '$inc_day' and tag= '每日' group by team_id""".stripMargin)

    //5555 订单表(I增量) ddjy_dwd_station_order_pay_repartition_di（car_team_id --- 车队id, station_id --- 所属油站id） order_sn 唯一 order_status=2，petrol_resources=2
    val o_order = spark.sql( //pay_time 2023-02-06 00:07:00
      s"""select car_team_id team_id,station_id,station_name,order_sn,ft_sale_money,pay_time,inc_day from dm_gis.ddjy_dwd_station_order_pay_repartition_di
         |where inc_day between '$o_day' and '$inc_day' and order_status='2' and petrol_resources='2'""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //6666 油站信息表(F全量) ddjy_ods_dim_station_info(id---加油站点id,petrol_station_name--油站名称)
    val o_station = spark.sql(
      s"""select id station_id,city_name,petrol_station_name stationname from dm_gis.ddjy_ods_dim_station_info
         |where inc_day = '$inc_day' group by id,city_name,petrol_station_name""".stripMargin) // and enable_flag ='1'
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //7777 平台流水明细表(I增量)(包含区域--城市维度的信息) ddjy_dwd_station_stream_detail(car_team_id---车队id,last_pay_date--末单日期'2022-01-01')
    val o_plat_stream = spark.sql(
      s"""select car_team_id team_id,city_name,last_pay_date,inc_day from dm_gis.ddjy_dwd_station_stream_detail
         |where inc_day between '$o_day' and '$inc_day'""".stripMargin)
      .groupBy("team_id", "city_name")
      .agg(max("last_pay_date") as "city_last_pay_time")
      .withColumn("city_and_last_pay_time", concat_ws(":", 'city_name, 'city_last_pay_time))
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_set("city_last_pay_time")) as "city_last_pay_time",
        concat_ws(";", collect_set("city_and_last_pay_time")) as "city_and_last_pay_time"
      )
      .select("team_id", "city_last_pay_time", "city_and_last_pay_time") //获得车队维度 最后支付日期 + 车队{城市维度 最后支付日期的集合}

    //8888 线索车队周数据表(T-7 周更新-I增量) dm_ddjy_carrier_rlst_di  -- credit_code--统一社会信用代码 city_distribution（东莞市:1.0、惠州市:12.0、河源市:2.0）
    val o_week_day = spark.sql(s"""select max(inc_day) inc_day from dm_gis.dm_ddjy_carrier_rlst_di where inc_day between '$days_10_ago' and '$inc_day'""")
      .select("inc_day").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")

    val o_rlst_di = spark.sql(
      s"""select credit_code tax_no,max(city_distribution) city_distribution from dm_gis.dm_ddjy_carrier_rlst_di
         |where inc_day = $o_week_day and credit_code is not null and trim(credit_code) !=''
         |group by credit_code""".stripMargin)

    //9999 油站车队周维度聚合表(T-7 周更新-I增量) dm_ddjy_gas_carrier_merge_di  （stationname ---油站名称 	 credit_code--统一社会信用代码 one_carrier_gas_rank--车队推荐加油油站排序）
    val o_gas_merge = spark.sql(
      s"""select stationname,credit_code tax_no,one_carrier_gas_rank from dm_gis.dm_ddjy_gas_carrier_merge_di
         |where inc_day = $o_week_day""".stripMargin)

    //111100000车队标签表(F全量)  dm_gis.ddjy_carteam_label
    val o_label = spark.sql(
      s"""select car_team_id team_id,max(label_easy) label_easy,if(max(oil_dimension2)='Infinity','0',max(oil_dimension2)) oil_dimension2 from dm_gis.ddjy_carteam_label
         |where inc_day ='$inc_day' group by car_team_id""".stripMargin)
      .withColumn("oil_dimension2", when('oil_dimension2 === "Infinity", "0.0").otherwise('oil_dimension2))
    //====================================JOIN========================================================
    //-------------step1-------------------
    val chedui_sales_df = o_chedui.join(broadcast(o_sales), Seq("team_id", "inc_day"), "left")
      .join(broadcast(o_rlst_di), Seq("tax_no"), "left")
      .na.fill("", Seq("city_distribution"))
      .withColumn("freq_city_distribution", getFreqCityUdf('city_distribution))
      .withColumn("freq_city_distribution", regexp_replace(regexp_replace('freq_city_distribution, "\\(|\\)", ""), ",", ":"))
      .select("team_id", "name", "contact_name", "contact_phone", "user_name", "user_id", "sub_name", "sub_code", "sup_name", "sup_code", "freq_city_distribution", "inc_day")

    val rec_stream_df = o_recharge.join(broadcast(o_plat_stream), Seq("team_id"), "left")
      .select("team_id", "first_trade_time", "cnt_trade_time", "total_trade_amount", "first_mon_trade_time", "city_last_pay_time", "city_and_last_pay_time")

    //-------------step2-------------------
    //从全量表中获取 已上线的油站信息
    val rec_statiton = o_gas_merge.join(broadcast(o_station), Seq("stationname"))
      .select("stationname", "tax_no", "one_carrier_gas_rank")

    val top_station_df = o_chedui.select("team_id", "tax_no").join(broadcast(rec_statiton), Seq("tax_no"), "left")
      .withColumn("num", row_number().over(Window.partitionBy("team_id").orderBy('one_carrier_gas_rank.cast("int"))))
      .filter('num <= 3)
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("stationname")) as "top_stationname")
      .select("team_id", "top_stationname")

    //-------------step3-------------------
    //截至筛选时间，车队消费总额
    val money_order_df = o_order.select("team_id", "ft_sale_money", "pay_time")
      .groupBy("team_id")
      .agg(
        sum('ft_sale_money) as "total_ft_sale_money",
        min('pay_time) as "first_pay_time",
        max('pay_time) as "last_pay_time"
      ).select("team_id", "total_ft_sale_money", "first_pay_time", "last_pay_time")

    //-------------step4-------------------
    //城市维度  历史累积的订单量 及 当天订单量
    val station_order_cnt_df = o_order.select("team_id", "station_id", "ft_sale_money", "order_sn", "inc_day")
      .join(broadcast(o_station), Seq("station_id"), "left")
      .groupBy("team_id", "city_name")
      .agg(
        sum("ft_sale_money") as "total_ft_sale_money",
        count("order_sn") as "total_cnt_order_sn"
      )
      .withColumn("total_city_ft_sale_money", concat_ws(":", 'city_name, 'total_ft_sale_money))
      .withColumn("total_city_order_cnt", concat_ws(":", 'city_name, 'total_cnt_order_sn))
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_list("total_city_ft_sale_money")) as "total_city_ft_sale_money",
        concat_ws(";", collect_list("total_city_order_cnt")) as "total_city_order_cnt"
      ).select("team_id", "total_city_order_cnt", "total_city_ft_sale_money")

    val day_city_order_df = o_order.filter('inc_day === inc_day)
      .join(broadcast(o_station), Seq("station_id"), "left")
      .select("team_id", "city_name", "order_sn")
      .groupBy("team_id", "city_name")
      .agg(count("order_sn") as "day_cnt_order_sn")
      .withColumn("day_city_order_cnt", concat_ws(":", 'city_name, 'day_cnt_order_sn))
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("day_city_order_cnt")) as "day_city_order_cnt")
      .select("team_id", "day_city_order_cnt")

    //获取 历史主要加油站
    val station_money_df = o_order.select("team_id", "station_id", "station_name", "order_sn")
      .groupBy("team_id", "station_id", "station_name")
      .agg(
        count('station_id) as "station_id_cnt",
        count('order_sn) as "order_sn_cnt"
      )
      .withColumn("num", row_number().over(Window.partitionBy("team_id").orderBy(desc("station_id_cnt"))))
      .filter('num <= 3)
      .withColumn("top_station_info", concat_ws(":", 'station_name, 'order_sn_cnt))
      .groupBy("team_id")
      .agg(concat_ws(";", collect_list("top_station_info")) as "top_station_info")
      .select("team_id", "top_station_info")

    //结果条件拼接
    val res_cols = spark.sql(s"""select * from dm_gis.ddjy_dwd_team_quota_dtl limit 0""").schema.map(_.name).map(col)
    val p5_infos_str = splitFun("&&")('team_id_label_info)
    var res_df: DataFrame = null
    val today_df: DataFrame = chedui_sales_df
      .join(broadcast(o_bill), Seq("team_id"), "left")
      .join(broadcast(rec_stream_df), Seq("team_id"), "left")
      .join(broadcast(top_station_df), Seq("team_id"), "left")
      .join(broadcast(money_order_df), Seq("team_id"), "left")
      .join(broadcast(station_order_cnt_df), Seq("team_id"), "left")
      .join(broadcast(day_city_order_df), Seq("team_id"), "left")
      .join(broadcast(station_money_df), Seq("team_id"), "left")
      .join(broadcast(o_label), Seq("team_id"), "left")
      .na.fill("", Seq("first_trade_time", "first_pay_time", "last_pay_time", "city_last_pay_time", "team_id_label", "total_city_ft_sale_money", "city_and_last_pay_time"))
      .na.fill("0.0", Seq("total_ft_sale_money", "oil_dimension2"))
      .withColumn("statistical_day", lit(inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)))
      .withColumn("inc_day", lit(inc_day))

    if (if_first_day == "Y") {
      res_df = isOffRequota(spark, today_df, p5_infos_str, res_cols)
    }

    /**
     * 第1天数据---全部为无标签数据
     * 第2+数据--分为4部分，逻辑单独处理
     * （1）比第1天新增车队信息---完全走原始逻辑即可 1/2
     * （2）两天同份数据，但是【已关闭】的任务，标签替换 1/2
     * （3）两天同份数据，但是【满足】车队任务关闭的车队---部分标签更换 1/2 * 1/2
     * （4）两天同份数据，但是【不满足】车队任务关闭的车队---直接原始逻辑 1/2 * 1/2
     */
    if (if_first_day == "N") {
      val close_filter_1_cond = 'task_type.isin("消费唤醒任务", "流失召回任务") && dealPayTime('last_pay_time) === inc_day
      val close_filter_2_cond = 'task_type === "潜力拓展任务" && 'oil_dimension2.cast("double") > 0.3
      val close_filter_cond = close_filter_1_cond || close_filter_2_cond
      val select_cols = Seq("team_id", "team_id_label", "task_type", "close_time", "run_off_citys", "consumption_citys", "task_status", "city_ft_sale_money_ratio", "start_time", "is_off").map(col)

      val yesday_df = spark.sql(s"""select * from dm_gis.ddjy_dwd_team_quota_dtl where inc_day = '$days_1_ago'""".stripMargin)
      val yesday_no_df = yesday_df.filter('is_off === "否").select(select_cols: _*).withColumn("yes_team_id", 'team_id).persist(StorageLevel.MEMORY_AND_DISK_SER)
      val yesday_yes_df = yesday_df.filter('is_off === "是").persist(StorageLevel.MEMORY_AND_DISK_SER)

      //1 将is_off = 是 的数据 单独取出
      val close_df_1 = yesday_yes_df
        .withColumn("statistical_day", lit(inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)))
        .withColumn("inc_day", lit(inc_day))
        .select(res_cols: _*)

      val today_com_yesday_df = today_df.join(yesday_no_df.select("yes_team_id").distinct(), expr("team_id = yes_team_id"), "left").persist(StorageLevel.MEMORY_AND_DISK_SER)
      //2 相比于昨天 新增车队信息
      val today_add_df = today_com_yesday_df.filter('yes_team_id.isNull)
        .withColumn("team_id_label_info", getTeamLabelUdf('first_trade_time, 'first_pay_time, 'last_pay_time, 'city_and_last_pay_time, 'inc_day))
        .withColumn("team_id_label", p5_infos_str(0))
        .withColumn("run_off_citys", p5_infos_str(1))
        .withColumn("consumption_citys", getConsumptionCitys('total_city_ft_sale_money))
        .withColumn("city_ft_sale_money_ratio", getCityRatioUdf('total_city_ft_sale_money, 'total_ft_sale_money))
        .withColumn("task_type", getTaskType('team_id_label, 'oil_dimension2, 'label_easy))
        .na.fill("", Seq("task_type"))
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .withColumn("start_time", getStartTimeUdf('task_type, 'first_trade_time, 'last_pay_time, 'inc_day))
        .withColumn("task_status", lit("未闭环"))
        .withColumn("close_time", lit(""))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", lit(""))
        .withColumn("after_close_station", lit(""))
        .withColumn("after_close_recharge", lit(""))
        .withColumn("after_close_order", lit(""))
        .withColumn("after_close_gmv", lit(""))
        .withColumn("after_close_city_gmv", lit(""))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit(""))
        .withColumn("is_off", lit("否"))
        .select(res_cols: _*)

      //2 相比于昨天 相同车队信息
      val today_same_yes_df = today_com_yesday_df.filter('yes_team_id.isNotNull)
      //今天和昨天完全一致的数据量 需要对标签进行判断(yes_today_df 包含的字段：正常今天的字段 +  昨天的部分判断字段)
      val today_need_rejudge_df = today_same_yes_df.join(yesday_no_df.drop("yes_team_id"), Seq("team_id"), "left")

      val yesday_closed_df = today_need_rejudge_df.filter('is_off === "否" && 'task_status === "已闭环")
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", getCloseCycleUdf('start_time, 'close_time))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit("")).persist(StorageLevel.MEMORY_AND_DISK_SER)

      val yesday_closed_remark_df = processMultiDf_is_Close(spark, yesday_closed_df, o_order, o_recharge_initial, o_station, res_cols, inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)
      //已闭合满7天的数据 当天即 重派任务
      val if_off_closed_df = yesday_closed_remark_df.filter('is_off === "是").select("team_id")
      val remark_if_off_closed_df = today_df.join(if_off_closed_df,Seq("team_id"))
      val today_if_off_closed_remark_df = isOffRequota(spark, remark_if_off_closed_df, p5_infos_str, res_cols)

      //未闭环的数据
      val today_close_1_df = today_need_rejudge_df.filter('is_off === "否" && 'task_status === "未闭环").filter(close_filter_cond)
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .withColumn("task_status", lit("已闭环"))
        .withColumn("close_time", lit(inc_day))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", getCloseCycleUdf('start_time, 'close_time))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit("")).persist(StorageLevel.MEMORY_AND_DISK_SER)
      val part_3_1_df = processMultiDf_no_Close(spark, today_close_1_df, o_order, o_recharge_initial, o_station, res_cols, inc_day)

      val today_no_close_df = today_need_rejudge_df.filter('is_off === "否" && 'task_status === "未闭环").filter(!close_filter_cond)
        .withColumn("team_id_label_info", getTeamLabelUdf('first_trade_time, 'first_pay_time, 'last_pay_time, 'city_and_last_pay_time, 'inc_day))
        .withColumn("team_id_label", p5_infos_str(0))
        .withColumn("run_off_citys", p5_infos_str(1))
        .withColumn("consumption_citys", getConsumptionCitys('total_city_ft_sale_money))
        .withColumn("city_ft_sale_money_ratio", getCityRatioUdf('total_city_ft_sale_money, 'total_ft_sale_money))
        .withColumn("task_type", getTaskType('team_id_label, 'oil_dimension2, 'label_easy))
        .na.fill("", Seq("task_type"))
        .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
        .withColumn("start_time", getStartTimeUdf('task_type, 'first_trade_time, 'last_pay_time, 'inc_day)) //todo 此处直接带出来 未变更前的状态
        //第1天 能打上4类标签的数据 均未闭环
        .withColumn("task_status", lit("未闭环"))
        .withColumn("close_time", lit(""))
        .na.fill("", Seq("start_time", "close_time"))
        .withColumn("close_cycle", lit(""))
        .withColumn("after_close_station", lit(""))
        .withColumn("after_close_recharge", lit(""))
        .withColumn("after_close_order", lit(""))
        .withColumn("after_close_gmv", lit(""))
        .withColumn("after_close_city_gmv", lit(""))
        .withColumn("prob_reason", lit(""))
        .withColumn("prob_descrip", lit(""))
        .withColumn("is_off", lit("否"))
        .select(res_cols: _*)

      res_df = close_df_1.union(today_add_df).union(today_no_close_df).union(yesday_closed_remark_df).union(part_3_1_df).union(today_if_off_closed_remark_df)
        .withColumn("num", row_number().over(Window.partitionBy("team_id", "start_time", "close_time", "is_off").orderBy("inc_day")))
        .select(res_cols: _*)
    }
    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.ddjy_dwd_team_quota_dtl")
    o_chedui.unpersist()
    o_order.unpersist()
    o_recharge_initial.unpersist()
    o_station.unpersist()
  }

  def isOffRequota(spark: SparkSession, df: DataFrame, p5_infos_str: Column, res_cols: Seq[Column]): DataFrame = {
    import spark.implicits._
    val res_df = df
      .withColumn("team_id_label_info", getTeamLabelUdf('first_trade_time, 'first_pay_time, 'last_pay_time, 'city_and_last_pay_time, 'inc_day))
      .withColumn("team_id_label", p5_infos_str(0))
      .withColumn("run_off_citys", p5_infos_str(1))
      .withColumn("consumption_citys", getConsumptionCitys('total_city_ft_sale_money))
      .withColumn("city_ft_sale_money_ratio", getCityRatioUdf('total_city_ft_sale_money, 'total_ft_sale_money))
      .withColumn("task_type", getTaskType('team_id_label, 'oil_dimension2, 'label_easy))
      .na.fill("", Seq("task_type"))
      .withColumn("unconsum_days", getUnconsumDaysUdf('first_trade_time, 'last_pay_time, 'inc_day))
      .withColumn("start_time", getStartTimeUdf('task_type, 'first_trade_time, 'last_pay_time, 'inc_day))
      //第1天 能打上4类标签的数据 均未闭环
      .withColumn("task_status", lit("未闭环"))
      .withColumn("close_time", lit(""))
      .na.fill("", Seq("start_time", "close_time"))
      .withColumn("close_cycle", lit(""))
      .withColumn("after_close_station", lit(""))
      .withColumn("after_close_recharge", lit(""))
      .withColumn("after_close_order", lit(""))
      .withColumn("after_close_gmv", lit(""))
      .withColumn("after_close_city_gmv", lit(""))
      .withColumn("prob_reason", lit(""))
      .withColumn("prob_descrip", lit(""))
      .withColumn("is_off", lit("否"))
      .select(res_cols: _*)
    res_df
  }

  def processMultiDf_is_Close(spark: SparkSession, today_close_df: DataFrame, o_order: DataFrame, o_recharge_initial: DataFrame, o_station: DataFrame, res_cols: Seq[Column], inc_day: String): DataFrame = {
    import spark.implicits._
    val days_8_ago = getdaysBeforeOrAfter(inc_day, -8)
    val close_order_df = o_order.filter('inc_day >= days_8_ago && 'inc_day <= inc_day)
      .join(today_close_df.select("team_id", "close_time"), Seq("team_id"))
      .filter('inc_day >= 'close_time).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val recharge_df = o_recharge_initial.filter('inc_day >= days_8_ago && 'inc_day <= inc_day)
      .join(today_close_df.select("team_id", "close_time"), Seq("team_id"))
      .filter('inc_day >= 'close_time)

    val after_close_order_df = close_order_df
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_set('station_name)) as "after_close_station",
        count("order_sn") as "after_close_order",
        sum("ft_sale_money") as "after_close_gmv"
      ).select("team_id", "after_close_station", "after_close_order", "after_close_gmv")


    val after_close_city_gmv_df = close_order_df
      .join(o_station.select("station_id", "city_name"), Seq("station_id"))
      .groupBy("team_id", "city_name")
      .agg(
        sum("ft_sale_money") as "tmp_ft_sale_money"
      )
      .withColumn("after_close_city_gmv", concat_ws(":", 'city_name, 'tmp_ft_sale_money))
      .groupBy("team_id").agg(concat_ws(";", collect_set('after_close_city_gmv)) as "after_close_city_gmv")
      .select("team_id", "after_close_city_gmv")

    val close_recharge_cnt = recharge_df
      .filter(getFilterCloseUdf('trade_time, 'close_time) === true)
      .groupBy("team_id")
      .agg(
        count("trade_time") as "after_close_recharge"
      ).select("team_id", "after_close_recharge")

    val yesday_closed_remark_df = today_close_df
      .join(broadcast(after_close_order_df), Seq("team_id"), "left")
      .join(broadcast(after_close_city_gmv_df), Seq("team_id"), "left")
      .join(broadcast(close_recharge_cnt), Seq("team_id"), "left")
      .withColumn("is_off", getIsOffUdf('task_status, 'close_time, 'inc_day))
      .select(res_cols: _*)

    yesday_closed_remark_df
  }


  def processMultiDf_no_Close(spark: SparkSession, today_close_df: DataFrame, o_order: DataFrame, o_recharge_initial: DataFrame, o_station: DataFrame, res_cols: Seq[Column], inc_day: String): DataFrame = {
    import spark.implicits._
    val close_order_df = o_order.filter('inc_day === inc_day).join(today_close_df.select("team_id"), Seq("team_id")).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val recharge_df = o_recharge_initial.filter('inc_day === inc_day).join(today_close_df.select("team_id"), Seq("team_id"))
    val after_close_order_df = close_order_df
      .groupBy("team_id")
      .agg(
        concat_ws(";", collect_set('station_name)) as "after_close_station",
        count("order_sn") as "after_close_order",
        sum("ft_sale_money") as "after_close_gmv"
      ).select("team_id", "after_close_station", "after_close_order", "after_close_gmv")


    val after_close_city_gmv_df = close_order_df
      .join(o_station.select("station_id", "city_name"), Seq("station_id"))
      .groupBy("team_id", "city_name")
      .agg(
        sum("ft_sale_money") as "tmp_ft_sale_money"
      )
      .withColumn("after_close_city_gmv", concat_ws(":", 'city_name, 'tmp_ft_sale_money))
      .groupBy("team_id").agg(concat_ws(";", collect_set('after_close_city_gmv)) as "after_close_city_gmv")
      .select("team_id", "after_close_city_gmv")

    val close_recharge_cnt = recharge_df
      .withColumn("close_time", lit(inc_day))
      .filter(getFilterCloseUdf('trade_time, 'close_time) === true)
      .groupBy("team_id")
      .agg(
        count("trade_time") as "after_close_recharge"
      ).select("team_id", "after_close_recharge")

    val part_3_df = today_close_df
      .join(broadcast(after_close_order_df), Seq("team_id"), "left")
      .join(broadcast(after_close_city_gmv_df), Seq("team_id"), "left")
      .join(broadcast(close_recharge_cnt), Seq("team_id"), "left")
      .withColumn("is_off", getIsOffUdf('task_status, 'close_time, 'inc_day))
      .select(res_cols: _*)

    part_3_df
  }


  def dealPayTime(last_pay_time: Column): Column = {
    //格式切换 last_pay_time 2023-02-07 03:40:26  20230207
    regexp_replace(substring(last_pay_time, 0, 10), "-", "")
  }

  def getConsumptionCitys = udf((total_city_ft_sale_money: String) => {
    val arr_buf = new ArrayBuffer[String]()
    if (strNotNull(total_city_ft_sale_money)) {
      val aa_arr = total_city_ft_sale_money.split(";")
      for (i <- 0 until (aa_arr.length)) {
        arr_buf += aa_arr(i).split(":")(0)
      }
    }
    arr_buf.mkString(";")
  })

  def getCityRatioUdf = udf((total_city_ft_sale_money: String, total_ft_sale_money: String) => {
    val arr_buf = new ArrayBuffer[String]()
    if (strNotNull(total_city_ft_sale_money) && total_ft_sale_money.toDouble > 0) {
      val aa_arr = total_city_ft_sale_money.split(";")
      for (i <- 0 until aa_arr.length) {
        val city = aa_arr(i).split(":")(0)
        val money = try {
          aa_arr(i).split(":")(1)
        } catch {
          case e: Exception => "0.0"
        }
        if (total_ft_sale_money.toDouble > 0) {
          val money_ratio = money.toDouble / total_ft_sale_money.toDouble
          arr_buf += (city + ":" + money_ratio)
        }
      }
    }
    arr_buf.mkString(";")
  })

  def getIsOffUdf = udf((task_status: String, close_time: String, inc_day: String) => {
    var is_off = "否"
    if (strNotNull(close_time)) {
      if (daysBetweenDate(close_time, inc_day) >= 7 && task_status == "已闭环") {
        is_off = "是"
      }
    }
    is_off
  })

  def getFilterCloseUdf = udf((pay_time: String, close_time: String) => {
    var res: Boolean = false
    var ft_pay_time = ""
    val after_7_days = getDaysApartDate("yyyyMMdd", close_time, 7)
    if (strNotNull(pay_time)) {
      ft_pay_time = pay_time.substring(0, 10).replaceAll("-", "")
    }
    if (ft_pay_time > close_time && ft_pay_time < after_7_days) {
      res = true
    }
    res
  })

  def getCloseCycleUdf = udf((start_time: String, close_time: String) => {
    var close_cycle = ""
    if (strNotNull(close_time) && strNotNull(start_time)) {
      close_cycle = daysBetweenDate(close_time, start_time).toString
    }
    close_cycle
  })

  def getStartTimeUdf = udf((task_type: String, first_trade_time: String, last_pay_time: String, inc_day: String) => {
    var start_time = ""
    if (strNotNull(task_type)) {
      if (task_type == "消费唤醒任务") {
        val ft_trade_time = first_trade_time.substring(0, 10).replaceAll("-", "")
        start_time = getDaysApartDate("yyyyMMdd", ft_trade_time, 5)
      } else if (task_type == "流失召回任务") {
        val ft_pay_date = last_pay_time.substring(0, 10).replaceAll("-", "")
        start_time = getDaysApartDate("yyyyMMdd", ft_pay_date, 7)
      } else if (task_type == "潜力拓展任务" || task_type == "重要回访任务") {
        start_time = inc_day
      }
    }
    start_time
  })

  def getTaskType = udf((team_id_label: String, oil_dimension2: String, label_easy: String) => {
    var task_type = ""
    val exclude_quota = Seq("城市流失", "城市流失预警", "平台流失预警", "未消费预警", "暂未消费新客")
    if (team_id_label == "超5天未消费") {
      task_type = "消费唤醒任务"
    } else if (team_id_label == "平台流失") {
      task_type = "流失召回任务"
    } else if (!exclude_quota.contains(team_id_label) && oil_dimension2.toDouble <= 0.3) {
      task_type = "潜力拓展任务"
    } else if (!exclude_quota.contains(team_id_label) && label_easy == "重要价值客户") {
      task_type = "重要回访任务"
    }
    task_type
  })

  def getUnconsumDaysUdf = udf((first_trade_time: String, last_pay_time: String, inc_day: String) => {
    var unconsum_days, ft_trade_time, ft_pay_time = ""
    if (strNotNull(first_trade_time)) {
      if (strNotNull(last_pay_time)) {
        ft_pay_time = last_pay_time.substring(0, 10).replaceAll("-", "")
        unconsum_days = daysBetweenDate(ft_pay_time, inc_day).toString
      } else {
        ft_trade_time = first_trade_time.substring(0, 10).replaceAll("-", "")
        unconsum_days = daysBetweenDate(ft_trade_time, inc_day).toString
      }
    }
    unconsum_days
  })

  /**
   * 用户标签带出  城市city_name维度标签
   *
   * @return
   */
  def getTeamLabelUdf = udf((first_trade_time: String, first_pay_time: String, last_pay_time: String, city_and_last_pay_time: String, inc_day: String) => {
    var team_id_label, city_team_id_label, ft_trade_time, ft_first_pay_time, ft_last_pay_time = ""
    val lose_city = new ArrayBuffer[String]()

    if (strNotNull(first_trade_time)) ft_trade_time = first_trade_time.substring(0, 10).replaceAll("-", "")
    if (strNotNull(first_pay_time)) ft_first_pay_time = first_pay_time.substring(0, 10).replaceAll("-", "")
    if (strNotNull(last_pay_time)) ft_last_pay_time = last_pay_time.substring(0, 10).replaceAll("-", "")
    val check_trade_days = daysBetweenDate(ft_trade_time, inc_day)
    val check_last_pay_days = daysBetweenDate(ft_last_pay_time, inc_day)

    if (strNotNull(city_and_last_pay_time)) {
      val date_arr = city_and_last_pay_time.split(";")
      var flag = true
      for (i <- 0 until date_arr.length) {
        try {
          val city = date_arr(i).split(":")(0)
          val day = date_arr(i).split(":")(1).replaceAll("-", "")
          val city_inter = daysBetweenDate(day, inc_day)
          if (city_team_id_label != "城市流失预警" && day != "" && city_inter >= 7 && flag) {
            city_team_id_label = "城市流失"
            flag = false
          }
          if (city_team_id_label != "城市流失预警" && day != "" && city_inter >= 7) {
            lose_city += city
          }
          if (city_team_id_label != "城市流失" && day != "" && city_inter >= 5 && city_inter < 7 && flag) {
            city_team_id_label = "城市流失预警"
            flag = false
          }
          if (city_team_id_label != "城市流失" && city_inter >= 5 && city_inter < 7) {
            lose_city += city
          }
        } catch {
          case e: Exception => ""
        }
      }
    }

    if (ft_trade_time != "") {
      if (ft_first_pay_time == "" && check_trade_days > 5) {
        team_id_label = "超5天未消费"
      } else if (ft_first_pay_time != "" && check_last_pay_days >= 7) {
        team_id_label = "平台流失"
      } else if (city_team_id_label == "城市流失") {
        team_id_label = "城市流失"
      } else if (ft_first_pay_time != "" && check_last_pay_days >= 5 && check_last_pay_days < 7) {
        team_id_label = "平台流失预警"
      } else if (city_team_id_label == "城市流失预警") {
        team_id_label = "城市流失预警"
      } else if (ft_first_pay_time == "" && check_trade_days > 3 && check_trade_days <= 5) {
        team_id_label = "未消费预警"
      } else if (ft_first_pay_time == "" && check_trade_days <= 3) {
        team_id_label = "暂未消费新客"
      } else {
        team_id_label = "稳定消费"
      }
    }
    team_id_label + "&&" + lose_city.mkString(",")
  })


  def getFreqCityUdf = udf((city_distribution: String) => {
    var freq_city = "" //city_distribution（东莞市:1.0、惠州市:12.0、河源市:2.0）
    if (!city_distribution.isEmpty && city_distribution.trim != "") {
      val city_arr = city_distribution.split("、")
      val cnt_city = new mutable.HashMap[String, Double]()
      for (i <- 0 until city_arr.length) {
        val city_name = city_arr(i).split(":")(0)
        var city_cnt: Double = 0.0
        try {
          city_cnt = city_arr(i).split(":")(1).toDouble
        } catch {
          case e: Exception => ""
        }
        cnt_city.put(city_name, city_cnt)
      }
      val cnt_city_arr = filterSort(cnt_city, Ordering.Double.reverse, Ordering.String)
      freq_city = cnt_city_arr.mkString(";")
    }
    freq_city
  })


  /**
   * 自定义排序：map指定排序字段及顺序
   *
   * @param hm
   * @param order1
   * @param order2
   * @return
   */
  def filterSort(hm: mutable.HashMap[String, Double], order1: Ordering[Double] = Ordering.Double.reverse, order2: Ordering[String] = Ordering.String): Array[(String, Double)] = {
    hm.filter(!_._1.equals("0")).toArray
      .sortBy(x => (x._2, x._1))(Ordering.Tuple2(order1, order2))
  }

}
