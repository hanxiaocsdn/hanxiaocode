package com.sf.app.goddog

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.HTPP_RGEO_X_Y_G
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @description: 457547 小天犬中标准省市区经纬度映射表加工
 * @author 01418539 caojia
 * @date 2022/7/12 17:33
 */
object DeptNetwork extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processNetWork(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processNetWork(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val ak = "321029ea21954fe9923e4c3b8769be05"
    //经纬度带出 省市区标准化地址信息
    val org_newwork_df = spark.sql(
      s"""
         |select trim(zno_code) as dept_code,banner,lng,lat,create_tm,inc_day
         |from dm_gis.polygon_all
         |where inc_day >= '$start_day' and inc_day <= '$end_day'
         |      and code is not null and trim(code) != ''
         |      and lng is not null and trim(lng) != ''
         |      and lat is not null and trim(lat) != ''
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("dept_code").orderBy(desc("create_tm"))))
      .filter('num === 1).repartition(50).persist()
    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "457547", "天犬newtwork维表-DeptNetwork", "基础服务", HTPP_RGEO_X_Y_G, "321029ea21954fe9923e4c3b8769be05", org_newwork_df.count(), 50)
    val newwork_df = org_newwork_df
      .map(row => {
        val dept_code = row.getAs[String]("dept_code")
        val dept_name = row.getAs[String]("banner")
        val x_coord = row.getAs[String]("lng")
        val y_coord = row.getAs[String]("lat")
        val modified_tm = row.getAs[String]("create_tm")
        val is_del = "0"
        val inc_day = row.getAs[String]("inc_day")

        var province = ""
        var pro_ad_code = ""
        var city = ""
        var city_ad_code = ""
        var district = ""
        var ad_code = ""
        var town = ""
        var town_ad_code = ""
        var reg_code = ""

        try {
          val start_url = String.format(HTPP_RGEO_X_Y_G, x_coord, y_coord, ak)
          val infos_str = HttpInvokeUtil.sendGet(start_url, "UTF-8", 3)
          val infos_json = JSON.parseObject(infos_str)
          logger.info(s"start的get请求返回的json为：" + infos_str)
          val jsonObject = infos_json.getJSONObject("result")
          province = jsonObject.getString("province")
          pro_ad_code = jsonObject.getString("proadcode")
          city = jsonObject.getString("city")
          city_ad_code = jsonObject.getString("cityadcode")
          district = jsonObject.getString("district")
          ad_code = jsonObject.getString("adcode")
          town = jsonObject.getString("town")
          town_ad_code = jsonObject.getString("townadcode")
          reg_code = jsonObject.getString("regcode")
        } catch {
          case e: Exception => logger.error(s"$x_coord and $y_coord 返回信息有异常" + e.getMessage)
        }
        (dept_code, x_coord, y_coord, province, pro_ad_code, city, city_ad_code, district, ad_code, town, town_ad_code, reg_code, dept_name, modified_tm, is_del, inc_day)
      }).toDF("dept_code", "x_coord", "y_coord", "province", "pro_ad_code", "city", "city_ad_code", "district", "ad_code", "town", "town_ad_code", "reg_code", "dept_name", "modified_tm", "is_del", "inc_day")
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)
    writeToHive(spark, newwork_df, Seq("inc_day"), "dm_goddog.dm_dept_network_v0")
  }

}
