package com.sf.app.track

import com.sf.app.track.AnalyzeCarTracksByTaskTcSeg.{makesegPath, postToWuhan, sendPath}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder

import java.io.File

/**
 * 已废弃,新版在com.sf.gis.scala.pns.app.AnalyzeCarTracksByTaskTcSeg
 *
 * @param dept
 * @param coord
 */

//任务ID: 489226 测试版本（482949 ）--已变成一次性任务
case class DeptCoordBAK(dept: String, coord: String)

case class FixedPathBAK(x1: String, x2: String, x3: String, x4: String, x5: String, x6: Long, x7: Long, x8: String, x9: String, x10: String, x11: String, x12: String, x13: String, x14: String, x15: String, x16: String, x17: String)

object AnalyzeCarTracksByTaskTcSegBAK extends DataSourceCommon {

  var envinited = false

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
    val endDate = Util.addDay(checkDate, 1).replaceAll("-", "")
    val buildCitys = ""
    initBills(spark, checkDate, endDate, buildCitys)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def initBills(spark: SparkSession, checkDate: String, endDate: String, buildCitys: String): Unit = {
    //7天前 的数据
    val dayid = Util.addDay(checkDate.replaceAll("-", ""), -7).replaceAll("-", "") //20220717
    System.err.println(">>>>>>>>>>>>>>>>>>>即将开始舒华新天地--调度作业单元区域区间车辆轨迹推送：" + dayid)
    Util.memTime()
    val ydayid = checkDate
    prepareDataBak(spark, ydayid, step = 0)

    Util.showCost(s"准备轨迹数据【$ydayid】完成")
    try {
      Util.freeMem()
    } catch {
      case e: Exception => logger.error(e.getMessage)
    }
    postToWuhan(spark, ydayid)
    Util.showCost(s"发送轨迹数据【$ydayid】完成")
    //重新加工 7天前 的数据加工 并 推送
    //    prepareDataBak(spark, dayid)
    sendPath(spark, dayid)
    Util.showCost(s"准备轨迹数据【$ydayid】完成")

    if (Util.addDay(checkDate, 1).replaceAll("-", "") < endDate)
      initBills(spark, Util.addDay(checkDate, 1).replaceAll("-", ""), endDate, buildCitys)
  }


  def prepareDataBak(spark: SparkSession, dayid: String, step: Int = 2, moreDays: Boolean = true) = {
    import spark.implicits._
    spark.sql("use dm_gis")
    var sql = ""
    //此处为新增补充逻辑
    val taskAll = mergeLogic(spark, dayid).na.fill("").repartition(Util.defaultPartitionSize / 2).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    val tt_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq_bak limit 1""").schema.map(_.name).map(col)
    val tt_1 = taskAll.withColumn("inc_day", lit(dayid)).select(tt_cols: _*)
    writeToHive(spark, tt_1.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_tc_seq_bak")
    taskAll.show(false)
    val taskCnt = taskAll.count()
    if (taskCnt == 0) {
      println("任务初始化记录为空")
    }
    taskAll.createOrReplaceTempView("tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak")

    sql = "select min(dayid),max(dayid) from tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak"

    if (taskCnt > 0) {
      val dayrange = spark.sql(sql).take(1)(0)
      val daymin = dayrange.getString(0)
      val daymax = dayrange.getString(1)

      val delta = if (moreDays) Util.daysDiff(daymin, daymax).toInt else 0
      (0 to delta).foreach(i => {
        val day = Util.addDay(daymin, i).replaceAll("-", "")
        val task = taskAll.filter(_.getString(4) == day).rdd.collect().sortBy(d => {
          (try {
            d.getString(1).toLong
          } catch {
            case e: Exception => logger.error(e.getMessage)
              0l
          }) - (try {
            d.getString(0).toLong
          } catch {
            case e: Exception => logger.error(e.getMessage)
              0l
          })
        })
        val dayid = day

        val taskCnt = task.length
        val btask = spark.sparkContext.broadcast(task)
        if (taskCnt > 0) {
          val dateFrom = task.map(_.getString(2).toInt).min
          val dateTo = task.map(_.getString(3).toInt).max
          Util.memTime()
          spark.sql("set spark.sql.shuffle.partitions=" + Util.defaultPartitionSize * 2)
          /**
           * 1 轨迹表替换为 dm_gis.gis_rss_eta_navi_track_flatmap 取值
           * 2 轨迹中车牌范围变化 从 tt_vehicle_task_pass_zone_monitor_tc_seq 变化为 tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak
           */
          val flatmap_track_df = spark.sql(
            s"""select distinct regexp_replace(carno,',','') as un,ak,tm,x zx,y zy,ac,tp,sp,be,deviceid from dm_gis.gis_rss_eta_navi_track_flatmap
               |where inc_day between '$dateFrom' and '$dateTo'
               |      and ak in ('305','306','333','335','334','332')
               |      and tm is not null and tm<>'' and x<>0 and y<>0
               |      and tag = '1'
               |      and regexp_replace(carno,',','') in (SELECT distinct regexp_replace(t.vehicle_serial,',','') as un FROM tmp_tt_vehicle_task_pass_zone_monitor_tc_seq_bak t where t.vehicle_serial is not null and t.dayid='$dayid')
               |""".stripMargin)
          val fixedPath = flatmap_track_df.na.fill("").rdd.groupBy(_.getString(0)).map(d => {
            val un = d._1
            val paths = d._2
            val fixedPath = btask.value.filter(t => {
              t.getString(6) == un
            }).map(d => {
              val tms = d.getString(0).toLong
              val tme = d.getString(1).toLong
              val taskid = d.getString(5)
              val un = d.getString(6)
              val zoneFrom = d.getString(7)
              val zoneTo = d.getString(8)
              val coorFrom = d.getString(9)
              val coorTo = d.getString(10)
              val rst = paths.filter(path => {
                val tm = path.getString(2).toLong
                tm >= tms - 300 && tm <= tme + 300 //轨迹起止时间各向两端延时5分钟
              }).map(path => {
                s"$taskid,$zoneFrom,$zoneTo,$coorFrom,$coorTo,$tms,$tme,${path.mkString(",")}"
              })
              rst
            }).flatMap(d => d)
            fixedPath
          }).flatMap(d => d)

          val fixedPath_df = fixedPath.map(_.split(",")).map(row => {
            var taskid, zoneFrom, zoneTo, coorFrom, coorTo, un, ak, tm, zx, zy, ac, tp, sp, be, sc = ""
            var tms, tme = 0l
            try {
              taskid = row(0)
              zoneFrom = row(1)
              zoneTo = row(2)
              coorFrom = row(3)
              coorTo = row(4)
              tms = row(5).toLong
              tme = row(6).toLong
              un = row(7)
              ak = row(8)
              tm = row(9)
              zx = row(10)
              zy = row(11)
              ac = row(12)
              tp = row(13)
              sp = row(14)
              be = row(15)
              sc = row(16)
            } catch {
              case e: Exception => logger.error("数据中存在空值" + e.getMessage)
            }
            FixedPathBAK(taskid, zoneFrom, zoneTo, coorFrom, coorTo, tms, tme, un, ak, tm, zx, zy, ac, tp, sp, be, sc)
          }).toDF("task_id", "zone_from", "zone_to", "coor_from", "coor_to", "tm_from", "tm_to", "un", "ak", "tm", "zx", "zy", "ac", "tp", "sp", "be", "sc")
            .withColumn("inc_day", lit(dayid))
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          val select_sc = fixedPath_df.select("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un", "tm", "sc")
            .withColumn("num", row_number().over(Window.partitionBy("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un").orderBy(asc("tm"))))
            .filter("num=1").drop("tm", "num")
          val res_df = fixedPath_df.join(broadcast(select_sc), Seq("task_id", "zone_from", "zone_to", "tm_from", "tm_to", "un", "sc"))
            .select("task_id", "zone_from", "zone_to", "coor_from", "coor_to", "tm_from", "tm_to", "un", "ak", "zx", "zy", "ac", "tp", "sp", "be", "sc")
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          //按照已有结果表字段排序
          val res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath limit 0""").schema.map(_.name).map(col)
          val merge_res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge limit 0""").schema.map(_.name).map(col)
          //根据 车牌 和 ak 筛选出 同个车牌 轨迹较多的车牌信息
          val fixedPath_df_ft = res_df.select("un", "ak", "tm_from", "tm_to")
            .withColumn("cnt", lit(1))
            .groupBy("un", "tm_from", "tm_to", "ak")
            .agg(
              sum("cnt") as "ak_cnt"
            )
            .withColumn("num", row_number().over(Window.partitionBy("un", "tm_from", "tm_to").orderBy(desc("ak_cnt"))))
            .filter('num === 1).select("un", "ak", "tm_from", "tm_to")
          //筛选完后的数据
          val fixedPath_df_res = res_df.join(fixedPath_df_ft, Seq("un", "tm_from", "tm_to", "ak"))
            .select(res_cols: _*)
            .persist(StorageLevel.MEMORY_AND_DISK_SER)

          val org_catch = spark.sql(s"""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath where inc_day = '$dayid'""").select(res_cols: _*)

          val all_carpath_df = fixedPath_df_res.withColumn("org_flag", lit("result")).union(org_catch.withColumn("org_flag", lit("monitor")))
            .select(merge_res_cols: _*)

          writeToHive(spark, fixedPath_df_res.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_bak")
          writeToHive(spark, all_carpath_df.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge")
          Util.showCost(s"【$dateFrom - $dateTo】 done")
        }
        btask.destroy()
      })
      makesegPath(spark, dayid)
    } else {
      println("【ERROR】taskAll 初始化记录为空")
    }
    taskAll.unpersist()
  }

  /**
   * 测试数据落盘 ftp 方法，暂时不用
   *
   * @param spark
   * @param dayid
   */
  def makesegPathBak(spark: SparkSession, dayid: String): Unit = {
    val hdfsPath = s"/hive/warehouse/dm/dm_gis/tt_vehicle_task_pass_zone_monitor_carpath_tmp_${dayid}_bak" //todo 1 此处路径 + bak
    Util.hdfsRM(hdfsPath)
    //todo 2 来源表 + _bak
    val sql_seg = s"select task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,zx,zy,ac,tp,sp,be from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_bak t where t.inc_day='$dayid' GROUP by task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,zx,zy,ac,tp,sp,be"
    spark.sql(sql_seg).rdd.map(_.mkString(",")).saveAsTextFile(hdfsPath)
    val file = s"./bak_track_path_tcseg_$dayid.csv" //todo 3 此处路径 + bak
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"hdfs dfs -getmerge $hdfsPath $file")
    Util.runShellCmd(s"ls -l $file")
    Util.runShellCmd(s"tar czf $file.tgz $file")
    Util.runShellCmd(s"ls -l $file.tgz")
    Util.ftpUpload(new File(file + ".tgz").getAbsolutePath, ftpPath = "/GIS-ASS-AOS/01366807/wuhan_track_path")
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"./rm -rf $file.tgz")
  }

  /**
   * 此处逻辑变换
   *
   * @param spark
   * @param taskAll
   * @param dayid
   * @return
   */
  def mergeLogic(spark: SparkSession, checkDate: String): DataFrame = {
    import spark.implicits._
    val day_bef = Util.addDay(checkDate, -1).replaceAll("-", "")
    val day_aft = Util.addDay(checkDate, 1).replaceAll("-", "")
    //"task_id", "vehicle_serial", "tmstart", "tmend", "daystart", "dayend", "zone_from", "zone_to", "coor_from", "coor_to", "dayid", "inc_day"
    val result_coords_df = replaceMonitorSeq(spark, checkDate)
    val carpath_df = spark.sql(
      s"""
         |SELECT task_id,zone_from,zone_to,tm_from,tm_to
         |FROM dm_gis.tt_vehicle_task_pass_zone_monitor_carpath
         |WHERE  inc_day between '$day_bef' and '$day_aft'
         |group by task_id,zone_from,zone_to,tm_from,tm_to
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val union_cols = Seq(col("tmstart"), col("tmend"), col("daystart"), col("dayend"), col("dayid"),
      col("task_id"), col("vehicle_serial"), col("zone_from"), col("zone_to"), col("coor_from"), col("coor_to"))
    //result_coords_df 有  carpath_df  无
    val p1_merge_df = result_coords_df.join(carpath_df.select("task_id"), Seq("task_id"), "left_anti")
      .select(union_cols: _*)

    val filter_cond = when('tm_from.cast("long") >= 'tmend.cast("long") || 'tmstart.cast("long") >= 'tm_to.cast("long"), true).otherwise(false)

    val p2_merge_df = result_coords_df.join(carpath_df.select("task_id", "tm_from", "tm_to"), Seq("task_id"))
      .withColumn("flag", filter_cond)
      .filter('flag === true) //保留无时间交集的task_id
      .select(union_cols: _*)

    p1_merge_df.union(p2_merge_df)
      .withColumn("num", row_number().over(Window.partitionBy(union_cols: _*).orderBy("task_id")))
      .filter('num === 1)
      .select(union_cols: _*)
  }

  def replaceMonitorSeq(spark: SparkSession, checkDate: String): DataFrame = {
    import spark.implicits._
    val dayid = Util.addDay(checkDate, -2).replaceAll("-", "")
    //navi_starttime 1654947040004
    val result1_df = spark.sql(
      s"""
         |select id,task_id,vehicle vehicle_serial,
         |       cast(navi_starttime/1000 as bigint) tmstart,
         |       cast(navi_endtime/1000 as bigint) tmend,
         |       substring(from_unixtime(cast(navi_starttime/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),0,10) as daystart,
         |       substring(from_unixtime(cast(navi_endtime/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),0,10) as dayend,
         |       inc_day dayid,
         |       concat_ws(';',x1,y1) coor_from,
         |       concat_ws(';',x2,y2) coor_to,
         |       inc_day
         |from dm_gis.gis_navi_eta_result1
         |where
         |   req_type = 'top3'
         |   and inc_day = '$checkDate'
         |   and cast(distance as double) > 1000
         |   --and strategy2 not in ('20','21','22')
         |   --and start_type != '1'
         |""".stripMargin)
      .withColumn("tmstart", 'tmstart.cast("string"))
      .withColumn("tmend", 'tmend.cast("string"))
      .withColumn("daystart", regexp_replace('daystart, "-", "").cast("string"))
      .withColumn("dayend", regexp_replace('dayend, "-", "").cast("string"))

    val result2_df = spark.sql(
      s"""
         |select id,src_deptcode zone_from,dest_deptcode zone_to,inc_day
         |from dm_gis.gis_navi_eta_result2
         |where
         |  req_type = 'top3'
         |  and inc_day = '$checkDate'
         |  and cast(navi_distance as double) > 1000
         |  and cast(trackstart_distance as double) < 1000
         |  and cast(trackend_distance as double) < 1000
         |""".stripMargin)

    val source_p2_df = result1_df.join(result2_df, Seq("id", "inc_day"))
      .select("task_id", "vehicle_serial", "tmstart", "tmend", "daystart", "dayend", "zone_from", "zone_to", "coor_from", "coor_to", "dayid", "inc_day")
    source_p2_df
  }

}
