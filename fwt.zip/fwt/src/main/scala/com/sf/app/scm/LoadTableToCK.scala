package com.sf.app.scm

import com.sf.app.scm.StandLineMileageMonitor.logger
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import utils.JDBCUtils.getSmartNaviCKConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}
import java.util.Properties

/**
 * @task_id: 487978
 * @description: 同步2张表至ck GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT//、DWD_GIS_NAVI_CONV_REJION
 * @demander:
 * @author 01418539 caojia
 * @date 2022/9/23 16:53
 */
object LoadTableToCK {
  def main(args: Array[String]): Unit = {

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    upsertToClickhouse1(spark, "dm_gis", "gis_oms_uimp_pns", "GIS_ETA_STDLINE_ACCURAL_DAILY_RESULT", "gis_eta_stdline_accrual_daily_result", start_day, end_day)
//    upsertToClickhouse2(spark, "dm_gis", "gis_oms_uimp_pns", "DWD_GIS_NAVI_CONV_REJION", "dwd_gis_std_navi_conv_rejion", start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def upsertToClickhouse1(spark: SparkSession, hivedbName: String, ckdbName: String, cktableName: String, hivetableName: String, start_day: String, end_day: String): Unit = {
    val conn: Connection = getSmartNaviCKConnect()
    try {
      val querySql = s"select * from $ckdbName.$cktableName where SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING(STATDATE,1,10) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"ALTER TABLE $ckdbName.$cktableName DELETE WHERE SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING(STATDATE,1,10) <= '$end_day'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 $ckdbName.$cktableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
    val ck_url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_pns"
    val ckProp = new Properties()
    //写入/out读出参数
    val ck_params = Map[String, String](
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "gis_oms_pns",
      "password" -> "gis_oms_pns@123@"
    )

    //加载 hive 中的表数据
    spark.sql(
      s"""
         |select
         |   id,
         |   inc_day statdate,
         |   task_area_code,
         |   task_area_name,
         |   carrier_name,
         |   task_inc_day,
         |   line_code,
         |   conduct_type_new,
         |   cast(task_id_num as int) task_id_num,
         |   cast(log_dist_error_num	 as int) log_dist_error_num,
         |   cast(log_dist_sum as int) log_dist_sum,
         |   cast(raw_accrual_dist_sum as int) raw_accrual_dist_sum,
         |   cast(accrual_dist_sum as int) accrual_dist_sum,
         |   cast(confirmed_num as int) confirmed_num,
         |   cast(appeal_num as int) appeal_num,
         |   cast(non_audit_num as int) non_audit_num,
         |   cast(audited_num as int) audited_num,
         |   cast(gj_task_num as int) gj_task_num,
         |   cast(gj_conduct_num as int) gj_conduct_num,
         |   cast(gh_task_num as int) gh_task_num,
         |   cast(gh_conduct_num as int) gh_conduct_num,
         |   cast(mix_task_num as int) mix_task_num,
         |   cast(mix_conduct_num as int) mix_conduct_num
         |from $hivedbName.$hivetableName
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .withColumn("create_time", lit(new java.sql.Timestamp(new java.util.Date().getTime())))
      .withColumn("create_user", lit(""))
      .withColumn("modify_time", lit(new java.sql.Timestamp(new java.util.Date().getTime())))
      .withColumn("modify_user", lit(""))
      .write.mode(SaveMode.Append).options(ck_params).jdbc(ck_url, s"$ckdbName.$cktableName", ckProp)

    //读出数据，检查是否写成功
    val querySQL = s"(SELECT *  FROM $ckdbName.$cktableName where SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING( STATDATE,1,10) <= '$end_day') as tmp"

    val partData: DataFrame = spark.read
      .format("jdbc")
      .option("url", ck_url)
      .options(ck_params)
      .option("dbtable", querySQL)
      .load()
    partData.limit(20).collect().foreach(println(_))
    logger.error(s"insert into table $ckdbName.$cktableName,the count bettween $start_day to $end_day is:" + partData.count())
  }

//  def upsertToClickhouse2(spark: SparkSession, hivedbName: String, ckdbName: String, cktableName: String, hivetableName: String, start_day: String, end_day: String): Unit = {
//    val conn: Connection = getSmartNaviCKConnect()
//    try {
//      val querySql = s"select STATDATE from $ckdbName.$cktableName where SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING(STATDATE,1,10) <= '$end_day'"
//      val query: PreparedStatement = conn.prepareStatement(querySql)
//      val queryRes = query.executeQuery()
//      if (queryRes.next()) {
//        val delSql = s"ALTER TABLE $ckdbName.$cktableName DELETE WHERE SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING(STATDATE,1,10) <= '$end_day'"
//        val del: PreparedStatement = conn.prepareStatement(delSql)
//        del.execute()
//      }
//    } catch {
//      case ex: Exception => logger.error(s"删除表 $ckdbName.$cktableName 中$start_day 至 $end_day 数据时出现错误", ex)
//        throw ex
//    }
//
//    val ck_url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_pns"
//
//    val ckProp = new Properties()
//
//    //写入/out读出参数
//    val ck_params = Map[String, String](
//      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
//      "batchsize" -> "20000",
//      "isolationLevel" -> "NONE",
//      "numPartitions" -> "1",
//      "user" -> "gis_oms_pns",
//      "password" -> "gis_oms_pns@123@"
//    )
//
//    //加载 hive 中的表数据
//    spark.sql(
//      s"""
//         |select id,
//         |inc_day statdate,
//         |task_area_code,
//         |task_cn,
//         |sdk_cn,
//         |sdk_dis_cn,
//         |a_std_cn,
//         |re_std_cn,
//         |cho_std_cn,
//         |navi_cn,
//         |sf_cn,
//         |sf_75rate_cn,
//         |sf_75ontime_cn,
//         |sf_75overtime_cn
//         |from $hivedbName.$hivetableName
//         |where inc_day>='$start_day' and inc_day<='$end_day'
//         |""".stripMargin)
//      .withColumn("create_time", lit(new java.sql.Timestamp(new java.util.Date().getTime())))
//      .withColumn("create_user", lit(""))
//      .withColumn("modify_time", lit(new java.sql.Timestamp(new java.util.Date().getTime())))
//      .withColumn("modify_user", lit(""))
//      .write.mode(SaveMode.Append).options(ck_params).jdbc(ck_url, s"$ckdbName.$cktableName", ckProp)
//
//    //读出数据，检查是否写成功
//    val querySQL = s"(SELECT *  FROM $ckdbName.$cktableName where SUBSTRING(STATDATE,1,10) >= '$start_day' and SUBSTRING( STATDATE,1,10) <= '$end_day') as tmp"
//
//    val partData: DataFrame = spark.read
//      .format("jdbc")
//      .option("url", ck_url)
//      .options(ck_params)
//      .option("dbtable", querySQL)
//      .load()
//    partData.limit(20).collect().foreach(println(_))
//    logger.error(s"insert into table $ckdbName.$cktableName,the count bettween $start_day to $end_day is:" + partData.count())
//  }
}
