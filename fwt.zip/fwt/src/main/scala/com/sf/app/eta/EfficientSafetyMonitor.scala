package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.ColumnUtil.colNotNull
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

/**
 * @task_id: 670815(已下线20230913)
 * @description: 时效日常指标监控 dm_gis.eta_alarm_day_monitor_cnt、dm_gis.eta_alarm_carrier_monitor_cnt、dm_gis.eta_alarm_vehicle_monitor_cnt
 * @demander: 01408185 江瑞
 * @author 01418539 caojia
 * @date 2023/8/16 17:17
 */
object EfficientSafetyMonitor extends DataSourceCommon {
  val day_tn = "dm_gis.eta_alarm_day_monitor_cnt"
  val carrier_tn = "dm_gis.eta_alarm_carrier_monitor_cnt"
  val vehicle_tn = "dm_gis.eta_alarm_vehicle_monitor_cnt"

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    run(spark, day_tn, carrier_tn, vehicle_tn, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, day_tn: String, carrier_tn: String, vehicle_tn: String, inc_day: String): Unit = {
    import spark.implicits._
    val car_no_sql = s"""select car_no from dm_gis_scm.dm_soc_alarm_filter_dtl_di where inc_day='$inc_day' and car_no is not null and trim(car_no)!='' and filter_type='4' group by car_no""".stripMargin //500cnt
    val car_no_str = spark.sql(car_no_sql).distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    val recall_df = getRecallTaskDF(spark, car_no_str, inc_day)
    val recall_car_df = recall_df._1
    val recall_carrie_df = recall_df._2
    val recall_day_df = recall_df._3
    val alarm_df = getAlarmDF(spark, car_no_str, inc_day)
    val alarm_car_df = alarm_df._1
    val alarm_carrie_df = alarm_df._2
    val alarm_day_df = alarm_df._3

    val day_cols = spark.sql(s"""select * from $day_tn limit 0""").schema.map(x => col(x.name))
    val carrier_cols = spark.sql(s"""select * from $carrier_tn limit 0""").schema.map(x => col(x.name))
    val vehicle_cols = spark.sql(s"""select * from $vehicle_tn limit 0""").schema.map(x => col(x.name))

    val day_df = recall_day_df.join(alarm_day_df, Seq("inc_day"), "left")
      .withColumn("ratio_task_ontime", when(colNotNull('num_task), round('num_task_ontime / 'num_task, 2)).otherwise(0))
      .withColumn("ratio_ganyu_success", when(colNotNull('num_ganyu_task), round('num_ganyu_success / 'num_ganyu_task, 2)).otherwise(0))
      .select(day_cols: _*)

    val carrie_df = recall_carrie_df.join(alarm_carrie_df, Seq("inc_day", "carrier_name"), "left")
      .withColumn("ratio_task_ontime", when(colNotNull('num_task), round('num_task_ontime / 'num_task, 2)).otherwise(0))
      .withColumn("ratio_ganyu_success", when(colNotNull('num_ganyu_task), round('num_ganyu_success / 'num_ganyu_task, 2)).otherwise(0))
      .select(carrier_cols: _*)
    val car_df = recall_car_df.join(alarm_car_df, Seq("inc_day", "carrier_name", "vehicle_serial"), "left")
      .withColumn("ratio_task_ontime", when(colNotNull('num_task), round('num_task_ontime / 'num_task, 2)).otherwise(0))
      .withColumn("ratio_ganyu_success", when(colNotNull('num_ganyu_task), round('num_ganyu_success / 'num_ganyu_task, 2)).otherwise(0))
      .select(vehicle_cols: _*)
    writeToHive(spark, day_df.coalesce(1), Seq("inc_day"), day_tn)
    writeToHive(spark, carrie_df.coalesce(1), Seq("inc_day"), carrier_tn)
    writeToHive(spark, car_df.coalesce(1), Seq("inc_day"), vehicle_tn)
  }


  def getAlarmDF(spark: SparkSession, car_no_str: String, inc_day: String): (DataFrame, DataFrame, DataFrame) = {
    val alarm_sql = //10w
      s"""select inc_day,grd_child_carrier_name carrier_name,bd_car_no vehicle_serial,
         |if((tts_type in ('1', '2') or (tts_type = '0' and def_need_type= '1')) and trim(grd_task_id)!='',grd_task_id,null) gy_grd_task_id,
         |if((tts_type in ('1', '2') or (tts_type = '0' and def_need_type= '1')) and grd_punctual='1' and trim(grd_task_id)!='',grd_task_id,null) gycg_grd_task_id,
         |alarm_id,
         |if(def_need_type= '1' and trim(alarm_id)!='',alarm_id,null) gj_alarm_id,
         |if(def_need_type= '1' and def_major_reason is not null and trim(def_major_reason)!='' and trim(alarm_id)!='',alarm_id,null) gjcd_grd_task_id,
         |if(def_need_type= '1' and def_major_reason is not null and trim(def_major_reason)!='' and def_task_alarm_state='1' and grd_punctual='1' and trim(alarm_id)!='',alarm_id,null) gjcg_grd_task_id
         |from dm_gis.soc_alarms
         |where inc_day='$inc_day' and alarm_name in ('异常停车','异常低速')
         |and grd_child_carrier_name is not null and trim(grd_child_carrier_name) !=''
         |and bd_car_no in ($car_no_str)""".stripMargin
    logger.error(">>>加载的告警sql>>>>" + alarm_sql)
    val alarm_car_df = spark.sql(alarm_sql)
      .groupBy("inc_day", "carrier_name", "vehicle_serial")
      .agg(
        countDistinct("gy_grd_task_id") as "num_ganyu_task",
        countDistinct("gycg_grd_task_id") as "num_ganyu_success",
        countDistinct("alarm_id") as "num_alarm_shixiao",
        countDistinct("gj_alarm_id") as "num_alarm_shixiao_huhang",
        countDistinct("gjcd_grd_task_id") as "num_alarm_shixiao_huhang_chuda",
        countDistinct("gjcg_grd_task_id") as "num_alarm_shixiao_huhang_chenggong")
      .persist()
    logger.error(">>>加载的告警数据总量为>>>>" + alarm_car_df.count())

    val alarm_carrie_df = alarm_car_df.groupBy("inc_day", "carrier_name")
      .agg(
        countDistinct("vehicle_serial") as "num_alarm_vehicle_shixiao",
        sum("num_ganyu_task") as "num_ganyu_task",
        sum("num_ganyu_success") as "num_ganyu_success",
        sum("num_alarm_shixiao") as "num_alarm_shixiao",
        sum("num_alarm_shixiao_huhang") as "num_alarm_shixiao_huhang",
        sum("num_alarm_shixiao_huhang_chuda") as "num_alarm_shixiao_huhang_chuda",
        sum("num_alarm_shixiao_huhang_chenggong") as "num_alarm_shixiao_huhang_chenggong")
      .persist()

    val alarm_day_df = alarm_carrie_df.groupBy("inc_day")
      .agg(
        sum("num_alarm_vehicle_shixiao") as "num_alarm_vehicle_shixiao",
        sum("num_ganyu_task") as "num_ganyu_task",
        sum("num_ganyu_success") as "num_ganyu_success",
        sum("num_alarm_shixiao") as "num_alarm_shixiao",
        sum("num_alarm_shixiao_huhang") as "num_alarm_shixiao_huhang",
        sum("num_alarm_shixiao_huhang_chuda") as "num_alarm_shixiao_huhang_chuda",
        sum("num_alarm_shixiao_huhang_chenggong") as "num_alarm_shixiao_huhang_chenggong")

    (alarm_car_df, alarm_carrie_df, alarm_day_df)
  }

  def getRecallTaskDF(spark: SparkSession, car_no_str: String, inc_day: String): (DataFrame, DataFrame, DataFrame) = {
    val days_6_bef = getdaysBeforeOrAfter(inc_day, -6)
    val recall_sql = //16w
      s"""select carrier_name,vehicle_serial,task_id,if(ac_is_run_ontime = '1' and trim(task_id) !='',task_id,null) taskon_id
         |from dm_gis.eta_std_line_recall1
         |where inc_day between '$days_6_bef' and '$inc_day'
         |and if_evaluate_time='1'
         |and vehicle_serial in ($car_no_str)
         |and carrier_name is not null and trim(carrier_name) !=''
         |and regexp_replace(substring(actual_arrive_tm,0,10),'-','') = '$inc_day'""".stripMargin
    logger.error(">>>加载的线路sql>>>>" + recall_sql)
    val recall_vehicle_df = spark.sql(recall_sql)
      .withColumn("inc_day", lit(inc_day))
      .groupBy("inc_day", "carrier_name", "vehicle_serial")
      .agg(countDistinct("task_id") as "num_task",
        countDistinct("taskon_id") as "num_task_ontime")
      .persist()
    logger.error(">>>加载的线路数据总量为>>>>" + recall_vehicle_df.count())

    val recall_carrie_df = recall_vehicle_df.groupBy("inc_day", "carrier_name")
      .agg(
        countDistinct("vehicle_serial") as "num_vehicle",
        sum("num_task") as "num_task",
        sum("num_task_ontime") as "num_task_ontime")
      .persist()

    val recall_day_df = recall_carrie_df.groupBy("inc_day")
      .agg(
        sum("num_vehicle") as "num_vehicle",
        sum("num_task") as "num_task",
        sum("num_task_ontime") as "num_task_ontime")

    (recall_vehicle_df, recall_carrie_df, recall_day_df)
  }
}
