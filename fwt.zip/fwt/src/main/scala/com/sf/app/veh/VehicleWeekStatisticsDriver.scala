package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getdaysBeforeOrAfter, timeToTimestampUDF, timeToTimestamp_}
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: 577712
 * @description: 周表标签表_司机维度 insurance_model_alarm_week_driver_dtl
 * @demander: 01412988 刘芮
 * @author 01418539 caojia
 * @date 2022/11/14 17:09
 */
object VehicleWeekStatisticsDriver extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processWeekQuota(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processWeekQuota(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val day_1_ago = getdaysBeforeOrAfter(inc_day, -1)
    val day_6_ago = getdaysBeforeOrAfter(inc_day, -6)
    val day_7_ago = getdaysBeforeOrAfter(inc_day, -7)
    //1 告警明细表--包含driver信息 和 车牌信息
    val o_zy_alarm_df = spark.sql(
      s"""select attribute6 emp_code,car_no,imei,zy_type,p_type_r,sub_type_r,
         |       alarm_time,alarm_name,regexp_replace(substring(alarm_time,0,10),'-','') alarm_tm,
         |       risk_level,defend_status,defend_submit_time,defend_recieve_time,inc_day
         |from dm_arss.dm_alarm_detail_dtl_di
         |where inc_day between '$day_7_ago' and '$inc_day' and attribute6 is not null and trim(attribute6) != ''
         |""".stripMargin).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //获取最近一次 疲劳/分心/过激/驾驶习惯 告警时间等信息
    val recent_risk_df = getR(spark, o_zy_alarm_df, day_7_ago, day_1_ago, inc_day)
    //2 司机信息 driver维度
    val o_driver_df = spark.sql(
      s"""
         |select emp_code,gender,age,driving_age,education,inc_day from dm_gis_scm.dm_scm_driver where inc_day = '$inc_day' and emp_code is not null and trim(emp_code) != ''
         |group by emp_code,gender,age,driving_age,education,inc_day
         |""".stripMargin)

    val alarm_driver_basic_info_df = recent_risk_df.join(o_driver_df, Seq("emp_code"), "left")

    //3 emp_code --司机工号 un--设备号 lpn--车牌号
    val o_dist_df = spark.sql(
      s"""
         |select emp_code,mileage_count total_links_dist,inc_day from dm_gis.dm_alarm_driver_sta_dtl where inc_day between '$day_6_ago' and '$inc_day'  and emp_code is not null and trim(emp_code) != ''
         |""".stripMargin)
    //根据司机工号 带出司机工号信息
    val oo1_dist_df = alarm_driver_basic_info_df.join(o_dist_df, Seq("emp_code", "inc_day"), "left").withColumn("day_cnt", lit(1))
    //筛选保留当天有记录的 emp_code
    val day_dist_df = oo1_dist_df.filter('inc_day === inc_day).select("emp_code").groupBy("emp_code").agg(lit(1) as "flag").select("emp_code")

    val dist_df = oo1_dist_df.join(day_dist_df, Seq("emp_code"), "inner")
      .groupBy("emp_code")
      .agg(
        sum("day_cnt") as "day_cnt",
        sum("total_links_dist") as "week_total_links_dist")
      .withColumn("avg_links_dist", 'week_total_links_dist / 'day_cnt)

    //4
    val agg_week_cols_str = Seq("week_defend_cnt", "week_dms_alarm_cnt", "week_pl_alarm_cnt", "week_fx_alarm_cnt", "week_gj_alarm_cnt", "week_jsxg_alarm_cnt")
    val agg_week_cols = ColumnUtil.renameColumn(agg_week_cols_str.map(sum(_)), agg_week_cols_str)

    val o_alarm_df = spark.sql(
      s"""
         |select emp_code,dms_alarm_cnt,dms_tired_cnt,dms_eye_closed_cnt,dms_yawn_cnt,dms_dis_drive_cnt,dms_dis_drive_dt_cnt,dms_dis_drive_tt_cnt,gj_alarm_cnt,adas_close_dist_cnt,adas_road_depart_cnt,adas_front_coll_cnt,defend_status_cnt,inc_day
         |from dm_gis.insurance_model_alarm_statistic_driver_dtl where inc_day between '$day_6_ago' and '$inc_day' and emp_code is not null and trim(emp_code) != ''
         |""".stripMargin)
      .withColumn("week_defend_cnt", 'defend_status_cnt)
      .withColumn("week_dms_alarm_cnt", 'dms_alarm_cnt)
      .withColumn("week_pl_alarm_cnt", 'dms_tired_cnt + 'dms_eye_closed_cnt + 'dms_yawn_cnt)
      .withColumn("week_fx_alarm_cnt", 'dms_dis_drive_cnt + 'dms_dis_drive_dt_cnt + 'dms_dis_drive_tt_cnt)
      .withColumn("week_gj_alarm_cnt", 'gj_alarm_cnt)
      .withColumn("week_jsxg_alarm_cnt", 'adas_close_dist_cnt + 'adas_road_depart_cnt + 'adas_front_coll_cnt)
      .select("emp_code", "week_defend_cnt", "week_dms_alarm_cnt", "week_pl_alarm_cnt", "week_fx_alarm_cnt", "week_gj_alarm_cnt", "week_jsxg_alarm_cnt", "inc_day")
    val alarm_df = o_alarm_df.drop("inc_day").join(o_alarm_df.filter('inc_day === inc_day).select("emp_code", "inc_day"), Seq("emp_code"))
      .groupBy("emp_code", "inc_day")
      .agg(agg_week_cols.head, agg_week_cols.tail: _*)

    //5
    val o_task_df = spark.sql(
      s"""select emp_code,series_working_days,rest_tm_bef_task
         | from dm_gis.insurance_model_task_alarm_dtl
         | where inc_day = '$inc_day' and emp_code is not null and trim(emp_code) != ''""".stripMargin)

    val s1_risk_df = alarm_df.join(dist_df, Seq("emp_code"), "left")
      .withColumn("pl_100km_alarm_cnt", when('week_total_links_dist.isNull || 'week_total_links_dist === "", 0).otherwise(lit(100000) * 'week_pl_alarm_cnt / 'week_total_links_dist))
      .withColumn("fx_100km_alarm_cnt", when('week_total_links_dist.isNull || 'week_total_links_dist === "", 0).otherwise(lit(100000) * 'week_fx_alarm_cnt / 'week_total_links_dist))
      .withColumn("gj_100km_alarm_cnt", when('week_total_links_dist.isNull || 'week_total_links_dist === "", 0).otherwise(lit(100000) * 'week_gj_alarm_cnt / 'week_total_links_dist))
      .withColumn("jsxg_100km_alarm_cnt", when('week_total_links_dist.isNull || 'week_total_links_dist === "", 0).otherwise(lit(100000) * 'week_jsxg_alarm_cnt / 'week_total_links_dist))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //求算分位数
    val pl_100km_80_percent = s1_risk_df.select("pl_100km_alarm_cnt").withColumn("constant", lit(1)).filter('pl_100km_alarm_cnt > 0)
      .groupBy("constant").agg(callUDF("percentile_approx", $"pl_100km_alarm_cnt", lit(0.8)).as("pl_100km_80_percent"))
      .select("pl_100km_80_percent").take(1).mkString.replaceAll("\\[|\\]", "")

    val fx_100km_80_percent = s1_risk_df.select("fx_100km_alarm_cnt").withColumn("constant", lit(1)).filter('fx_100km_alarm_cnt > 0)
      .groupBy("constant").agg(callUDF("percentile_approx", $"fx_100km_alarm_cnt", lit(0.8)).as("fx_100km_80_percent"))
      .select("fx_100km_80_percent").take(1).mkString.replaceAll("\\[|\\]", "")

    val gj_100km_80_percent = s1_risk_df.select("gj_100km_alarm_cnt").withColumn("constant", lit(1)).filter('gj_100km_alarm_cnt > 0)
      .groupBy("constant").agg(callUDF("percentile_approx", $"gj_100km_alarm_cnt", lit(0.8)).as("gj_100km_80_percent"))
      .select("gj_100km_80_percent").take(1).mkString.replaceAll("\\[|\\]", "")

    val jsxg_100km_80_percent = s1_risk_df.select("jsxg_100km_alarm_cnt").withColumn("constant", lit(1)).filter('jsxg_100km_alarm_cnt > 0)
      .groupBy("constant").agg(callUDF("percentile_approx", $"jsxg_100km_alarm_cnt", lit(0.8)).as("jsxg_100km_80_percent"))
      .select("jsxg_100km_80_percent").take(1).mkString.replaceAll("\\[|\\]", "")

    val s2_weigh_avg_df = s1_risk_df
      .withColumn("pl_100km_80_percent", lit(pl_100km_80_percent))
      .withColumn("fx_100km_80_percent", lit(fx_100km_80_percent))
      .withColumn("gj_100km_80_percent", lit(gj_100km_80_percent))
      .withColumn("jsxg_100km_80_percent", lit(jsxg_100km_80_percent))
      .withColumn("pl_normalize_risk", when('pl_100km_alarm_cnt / 'pl_100km_80_percent < 1, lit(4) * 'pl_100km_alarm_cnt / 'pl_100km_80_percent).otherwise(4))
      .withColumn("fx_normalize_risk", when('fx_100km_alarm_cnt / 'fx_100km_80_percent < 1, lit(2) * 'fx_100km_alarm_cnt / 'fx_100km_80_percent).otherwise(2))
      .withColumn("gj_normalize_risk", when('gj_100km_alarm_cnt / 'gj_100km_80_percent < 1, lit(2) * 'gj_100km_alarm_cnt / 'gj_100km_80_percent).otherwise(2))
      .withColumn("jsxg_normalize_risk", when('jsxg_100km_alarm_cnt / 'jsxg_100km_80_percent < 1, lit(2) * 'jsxg_100km_alarm_cnt / 'jsxg_100km_80_percent).otherwise(2))
      .withColumn("driver_behavior_risk", when('week_defend_cnt > 0, 10).otherwise('pl_normalize_risk + 'fx_normalize_risk + 'gj_normalize_risk + 'jsxg_normalize_risk))
      .withColumn("driver_behavior_label", when('week_defend_cnt > 0, 1).otherwise(rowMaxUDF('pl_normalize_risk, 'fx_normalize_risk, 'gj_normalize_risk, 'jsxg_normalize_risk)))

    val s3_risk_df = s2_weigh_avg_df.join(o_task_df, Seq("emp_code"), "left")
      .withColumn("task_dist_risk", when('avg_links_dist / 500000 < 1, lit(4) * 'avg_links_dist / 500000).otherwise(4))
      .withColumn("rest_bef_task_risk", when('rest_tm_bef_task >= 3, lit(9) / 'rest_tm_bef_task).otherwise(3))
      .withColumn("series_working_risk", 'series_working_days * 3 / 7)
      .withColumn("task_risk", 'task_dist_risk + 'rest_bef_task_risk + 'series_working_risk)
      .withColumn("task_dist_risk", when('task_dist_risk.isNull || trim('task_dist_risk) === "", "0").otherwise('task_dist_risk))
      .withColumn("rest_bef_task_risk", when('rest_bef_task_risk.isNull || trim('rest_bef_task_risk) === "", "0").otherwise('rest_bef_task_risk))
      .withColumn("series_working_risk", when('series_working_risk.isNull || trim('series_working_risk) === "", "0").otherwise('series_working_risk))
      .withColumn("task_label", maxTaskRisk('task_dist_risk, 'rest_bef_task_risk, 'series_working_risk))
      .withColumn("flag", lit("all"))

    val normalize_risk_df = s3_risk_df.select("task_dist_risk", "rest_bef_task_risk", "series_working_risk").withColumn("flag", lit("all"))
      .groupBy("flag")
      .agg(
        callUDF("percentile_approx", $"task_dist_risk", lit(0.3)).as("task_dist_30_percent"),
        callUDF("percentile_approx", $"rest_bef_task_risk", lit(0.3)).as("rest_bef_30_percent"),
        callUDF("percentile_approx", $"series_working_risk", lit(0.3)).as("series_working_30_percent")
      )
    //画像标签
    val portrait_label = when('multi_label === "高高高", "1").when('multi_label === "高高低", "2").when('multi_label === "高低高", "3").when('multi_label === "高低低", "4")
      .when('multi_label === "低高高", "5").when('multi_label === "低高低", "6").when('multi_label === "低低高", "7").when('multi_label === "低低低", "8")
    val s4_percent_df = s3_risk_df.join(normalize_risk_df, Seq("flag"), "left")
      .withColumn("task_dist_risk_label", when('task_dist_risk <= 0.3, "高").otherwise("低"))
      .withColumn("rest_bef_task_risk_label", when('rest_bef_task_risk <= 0.3, "高").otherwise("低"))
      .withColumn("series_working_risk_label", when('series_working_risk <= 0.3, "高").otherwise("低"))
      .withColumn("multi_label", concat('task_dist_risk_label, 'rest_bef_task_risk_label, 'series_working_risk_label))
      .withColumn("portrait_label", portrait_label)
      .withColumn("statistic_tm_period", concat(lit(day_6_ago), lit("_"), lit(inc_day)))

    val res_df_cols = spark.sql("""select * from dm_gis.insurance_model_alarm_week_driver_dtl limit 0""").schema.map(_.name).map(col)
    val res_df = alarm_driver_basic_info_df.join(s4_percent_df.drop("inc_day"), Seq("emp_code"), "left")
      .filter('emp_code =!= "").withColumn("inc_day", lit(inc_day)).select(res_df_cols: _*)
    writeToHive(spark, res_df.coalesce(2), Seq("inc_day"), "dm_gis.insurance_model_alarm_week_driver_dtl")
  }

  def maxTaskRisk = udf((task_dist_risk: String, rest_bef_task_risk: String, series_working_risk: String) => {
    val s1 = Array((task_dist_risk, 1), (series_working_risk, 2), (rest_bef_task_risk, 3))
    val s2 = s1.sortWith((x, y) => x._1.toDouble >= y._1.toDouble)
    s2(0)._2.toString
  })


  def getR(spark: SparkSession, o_zy_alarm_df: DataFrame, day_7_ago: String, day_1_ago: String, inc_day: String): DataFrame = {
    import spark.implicits._
    val js_tm_cols_str = Seq("pl_js_tm", "fx_js_tm", "gj_js_tm", "jsxg_js_tm")
    val alarm_type_cols = latestDriverTime(spark, js_tm_cols_str)
    val agg_latest_tm_cols = ColumnUtil.renameColumn(js_tm_cols_str.map(x => timeToTimestamp_(max(col(x)))), js_tm_cols_str)
    val recent_risk_cols = addCalculate(spark, js_tm_cols_str)
    val s1_zy_df = o_zy_alarm_df.select("emp_code", "alarm_name", "alarm_time", "alarm_tm").filter('alarm_tm >= day_7_ago && 'alarm_tm <= day_1_ago)
    val zy_type_df = o_zy_alarm_df.select("emp_code", "zy_type").filter('alarm_tm === inc_day)
      .groupBy("emp_code").agg(concat_ws(",", collect_set('zy_type)) as "zy_type")
    val s1_recent_jstm_df = s1_zy_df.select(s1_zy_df.schema.map(x => col(x.name)) ++ alarm_type_cols: _*)
      .groupBy("emp_code")
      .agg(agg_latest_tm_cols.head, agg_latest_tm_cols.tail: _*)
      .withColumn("stand_tm", timeToTimestampUDF("yyyyMMdd")(lit(inc_day)))

    val s2_recent_risk_df = s1_recent_jstm_df.select(s1_recent_jstm_df.schema.map(x => col(x.name)) ++ recent_risk_cols: _*)
      .join(zy_type_df, Seq("emp_code"), "left")
      .withColumn("driver_status_risk", 'recent_pl_js_risk + 'recent_fx_js_risk + 'recent_gj_js_risk + 'recent_jsxg_js_risk)
      .withColumn("driver_trend_risk", rowMaxUDF('recent_pl_js_risk, 'recent_fx_js_risk, 'recent_gj_js_risk, 'recent_jsxg_js_risk))

    s2_recent_risk_df
  }

  def rowMaxUDF = udf((a: String, b: String, c: String, d: String) => {
    val res = Seq(a, b, c, d).map(_.toDouble).max
    res
  })

  def addCalculate(spark: SparkSession, js_tm_cols_str: Seq[String]): Seq[Column] = {
    import spark.implicits._
    val recent_tm_cols_str = js_tm_cols_str.map("recent_" + _)
    val recent_risk_cols_str = js_tm_cols_str.map(x => "recent_" + x.replaceAll("_tm", "_risk"))
    val js_tm_cols = js_tm_cols_str.map(col).map(x => ('stand_tm - x) / 3600)
    val recent_risk_cols = js_tm_cols_str.map(x =>
      if (x == "pl_js_tm") {
        when(('stand_tm - col(x)) / lit(3600) >= 6, lit(3600 * 24) / ('stand_tm - col(x))).otherwise(4)
      } else {
        when(('stand_tm - col(x)) / lit(3600) >= 6, lit(3600 * 12) / ('stand_tm - col(x))).otherwise(2)
      }
    )
    ColumnUtil.renameColumn(js_tm_cols ++ recent_risk_cols, recent_tm_cols_str ++ recent_risk_cols_str)
  }

  /**
   * 5类告警原则,实际使用4类
   *
   * @param spark
   * @param inc_day
   */
  def latestDriverTime(spark: SparkSession, js_tm_cols_str: Seq[String]): Seq[Column] = {
    import spark.implicits._
    val pl_js = Seq("闭眼", "疲劳", "打哈欠")
    val fx_js = Seq("分心驾驶", "分心驾驶抬头", "分心驾驶低头")
    val gj_js = Seq("急加速", "急减速", "急转弯", "超速", "超限速")
    val jsxg_js = Seq("前车碰撞", "车距过近", "车道偏离")
    val js_tm_cols = Seq(pl_js, fx_js, gj_js, jsxg_js).map(x => when('alarm_name.isin(x: _*), 'alarm_time))
    ColumnUtil.renameColumn(js_tm_cols, js_tm_cols_str)
  }
}
