package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import utils.ColumnUtil.{colNotNull, strNotNull}
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter, getdaysBeforeOrAfter}
import utils.SparkBuilder

/**
 * @task_id: 813348
 * @description: 时效护航价值指标线上化 指标监控
 * @demander: 左佳怡 01403789
 * @author 01418539 caojia
 * @date 2023/9/8 14:29
 */
object EfficientEscortValueLine extends DataSourceCommon {
  val jiazhi_task_tn = "dm_gis.shixiao_huhang_jiazhi_task"
  val jiazhi_line_tn = "dm_gis.shixiao_huhang_jiazhi_line"
  val level_detail_tn = "dm_gis.first_level_detail"
  val batch_delay_tn = "dm_gis.first_level_batch_delay"

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    run(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    //时间参数
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val bef_first_5_day = getdaysBeforeOrAfter(month_first_day, -4) //月初往前5天
    val aft_last_10_day = getdaysBeforeOrAfter(month_last_day, 10) //月末往后10天
    //加载2张原始 明细表
    val task_detail_df = getTaskDetailDF(spark, bef_first_5_day, month_first_day, month_last_day, aft_last_10_day)
    val warn_summary_df = getWarningSummaryDF(spark, bef_first_5_day, month_first_day, month_last_day, aft_last_10_day)
    val warn_yj_df = warn_summary_df._1
    val warn_sum_df = warn_summary_df._2

    val part_jiazhi_task_df = jiazhiTaskONE(spark, task_detail_df, warn_yj_df, jiazhi_task_tn, inc_day)
    jiazhiLineTWO(spark, part_jiazhi_task_df, jiazhi_line_tn, inc_day)
    val level_detail_df = levelDetailTHREE(spark, warn_sum_df, part_jiazhi_task_df, level_detail_tn, inc_day)

    var level_detail_low6_df: DataFrame = null
    if (month_first_day.substring(0, 6) < "202308") {
      //8月以前
      level_detail_low6_df = level_detail_df.filter('month.isin("3", "6") && 'msg_type.isin("5", "7", "8") && 'warn_level === "3")
    } else {
      level_detail_low6_df = level_detail_df.filter('month.isin("3", "6") && (('msg_type.isin("5", "7", "8") && 'warn_level === "3") || 'msg_type.isin("9", "10", "11", "12", "13")))
    }
    countAndRatioPart(spark, level_detail_low6_df, batch_delay_tn, inc_day)
  }

  def countAndRatioPart(spark: SparkSession, level_detail36_df: DataFrame, batch_delay_tn: String, inc_day: String): Unit = {
    import spark.implicits._
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val month3_cond = 'month === "3"
    val month6_cond = 'month === "6"
    val run_delay_cond = 'if_run_delay === "是"
    val batch_delay_cond = 'if_batch_delay === "是"
    val delay_batch_cond = 'delay_batch_tm.cast("double") / 60.0
    val delay_batch_cols = spark.sql(s"""select * from $batch_delay_tn limit 0""").schema.map(_.name).map(col)
    val count_and_ratio_df = level_detail36_df
      //3月
      .withColumn("num_first_level_3", when(month3_cond, 'group))
      .withColumn("num_first_level_task_3", when(month3_cond, 'task_id))
      .withColumn("num_first_level_task_ontime_3", when(month3_cond && run_delay_cond, 'task_id))
      .withColumn("num_first_level_task_batch_3", when(month3_cond && batch_delay_cond, 'task_id))
      .withColumn("num_first_level_task_batch_3_02", when(month3_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 0, 2), 'task_id))
      .withColumn("num_first_level_task_batch_3_24", when(month3_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 2, 4), 'task_id))
      .withColumn("num_first_level_task_batch_3_46", when(month3_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 4, 6), 'task_id))
      .withColumn("num_first_level_task_batch_3_68", when(month3_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 6, 8), 'task_id))
      .withColumn("num_first_level_task_batch_3_810", when(month3_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 8, 10), 'task_id))
      .withColumn("num_first_level_task_batch_3_10_", when(month3_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 10, 999999), 'task_id))
      //6月
      .withColumn("num_first_level_6", when(month6_cond, 'group))
      .withColumn("num_first_level_task_6", when(month6_cond, 'task_id))
      .withColumn("num_first_level_task_ontime_6", when(month6_cond && run_delay_cond, 'task_id))
      .withColumn("num_first_level_task_batch_6", when(month6_cond && batch_delay_cond, 'task_id))
      .withColumn("num_first_level_task_batch_6_02", when(month6_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 0, 2), 'task_id))
      .withColumn("num_first_level_task_batch_6_24", when(month6_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 2, 4), 'task_id))
      .withColumn("num_first_level_task_batch_6_46", when(month6_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 4, 6), 'task_id))
      .withColumn("num_first_level_task_batch_6_68", when(month6_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 6, 8), 'task_id))
      .withColumn("num_first_level_task_batch_6_810", when(month6_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 8, 10), 'task_id))
      .withColumn("num_first_level_task_batch_6_10_", when(month6_cond && batch_delay_cond && compMinAndMax(delay_batch_cond, 10, 999999), 'task_id))
      .groupBy("inc_day", "month")
      .agg(
        countDistinct("num_first_level_3") as "num_first_level_3",
        countDistinct("num_first_level_task_3") as "num_first_level_task_3",
        countDistinct("num_first_level_task_ontime_3") as "num_first_level_task_ontime_3",
        countDistinct("num_first_level_task_batch_3") as "num_first_level_task_batch_3",
        countDistinct("num_first_level_task_batch_3_02") as "num_first_level_task_batch_3_02",
        countDistinct("num_first_level_task_batch_3_24") as "num_first_level_task_batch_3_24",
        countDistinct("num_first_level_task_batch_3_46") as "num_first_level_task_batch_3_46",
        countDistinct("num_first_level_task_batch_3_68") as "num_first_level_task_batch_3_68",
        countDistinct("num_first_level_task_batch_3_810") as "num_first_level_task_batch_3_810",
        countDistinct("num_first_level_task_batch_3_10_") as "num_first_level_task_batch_3_10_",
        countDistinct("num_first_level_6") as "num_first_level_6",
        countDistinct("num_first_level_task_6") as "num_first_level_task_6",
        countDistinct("num_first_level_task_ontime_6") as "num_first_level_task_ontime_6",
        countDistinct("num_first_level_task_batch_6") as "num_first_level_task_batch_6",
        countDistinct("num_first_level_task_batch_6_02") as "num_first_level_task_batch_6_02",
        countDistinct("num_first_level_task_batch_6_24") as "num_first_level_task_batch_6_24",
        countDistinct("num_first_level_task_batch_6_46") as "num_first_level_task_batch_6_46",
        countDistinct("num_first_level_task_batch_6_68") as "num_first_level_task_batch_6_68",
        countDistinct("num_first_level_task_batch_6_810") as "num_first_level_task_batch_6_810",
        countDistinct("num_first_level_task_batch_6_10_") as "num_first_level_task_batch_6_10_"
      )
      .withColumn("ratio_ontime_3", when(colNotNull('num_first_level_task_3), 'num_first_level_task_ontime_3 / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_first_level_task_batch_3", when(colNotNull('num_first_level_task_3), 'num_first_level_task_batch_3 / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_first_level_task_batch_3_02", when(colNotNull('num_first_level_task_3), 'Num_first_level_task_batch_3_02 / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_first_level_task_batch_3_24", when(colNotNull('num_first_level_task_3), 'Num_first_level_task_batch_3_24 / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_first_level_task_batch_3_46", when(colNotNull('num_first_level_task_3), 'Num_first_level_task_batch_3_46 / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_first_level_task_batch_3_68", when(colNotNull('num_first_level_task_3), 'Num_first_level_task_batch_3_68 / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_first_level_task_batch_3_810", when(colNotNull('num_first_level_task_3), 'Num_first_level_task_batch_3_810 / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_first_level_task_batch_3_10_", when(colNotNull('num_first_level_task_3), 'Num_first_level_task_batch_3_10_ / 'num_first_level_task_3).otherwise(0))
      .withColumn("ratio_ontime_6", when(colNotNull('num_first_level_task_6), 'num_first_level_task_ontime_6 / 'num_first_level_task_6).otherwise(0))
      .withColumn("ratio_first_level_task_batch_6", when(colNotNull('num_first_level_task_6), 'num_first_level_task_batch_6 / 'num_first_level_task_6).otherwise(0))
      .withColumn("ratio_first_level_task_batch_6_02", when(colNotNull('num_first_level_task_6), 'Num_first_level_task_batch_6_02 / 'num_first_level_task_6).otherwise(0))
      .withColumn("ratio_first_level_task_batch_6_24", when(colNotNull('num_first_level_task_6), 'Num_first_level_task_batch_6_24 / 'num_first_level_task_6).otherwise(0))
      .withColumn("ratio_first_level_task_batch_6_46", when(colNotNull('num_first_level_task_6), 'Num_first_level_task_batch_6_46 / 'num_first_level_task_6).otherwise(0))
      .withColumn("ratio_first_level_task_batch_6_68", when(colNotNull('num_first_level_task_6), 'Num_first_level_task_batch_6_68 / 'num_first_level_task_6).otherwise(0))
      .withColumn("ratio_first_level_task_batch_6_810", when(colNotNull('num_first_level_task_6), 'Num_first_level_task_batch_6_810 / 'num_first_level_task_6).otherwise(0))
      .withColumn("ratio_first_level_task_batch_6_10_", when(colNotNull('num_first_level_task_6), 'Num_first_level_task_batch_6_10_ / 'num_first_level_task_6).otherwise(0))
      .withColumn("inc_day", lit(month_last_day))
      .select(delay_batch_cols: _*)
    writeToHive(spark, count_and_ratio_df, Seq("inc_day"), batch_delay_tn)
  }

  def compMinAndMax(colVal: Column, min: Int, max: Int): Column = {
    (colVal >= lit(min)) && (colVal < lit(max))
  }

  def levelDetailTHREE(spark: SparkSession, warn_sum_df: DataFrame, part_jiazhi_task_df: DataFrame, level_detail_tn: String, inc_day: String): DataFrame = {
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val level_detail_cols = spark.sql(s"""select * from $level_detail_tn limit 0""").schema.map(_.name).map(col)
    val level_detail_df = warn_sum_df.join(part_jiazhi_task_df, Seq("task_id"), "left")
      .withColumn("inc_day", lit(month_last_day))
      .select(level_detail_cols: _*)
    writeToHive(spark, level_detail_df, Seq("inc_day"), level_detail_tn)
    level_detail_df
  }

  def jiazhiLineTWO(spark: SparkSession, part_jiazhi_task_df: DataFrame, jiazhi_line_tn: String, inc_day: String): DataFrame = {
    import spark.implicits._
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val month3_cond = 'month === "3"
    val month6_cond = 'month === "6"
    val ontime_cond = 'is_run_ontime === "1"
    val batch_delay_cond = 'if_batch_delay === "是"
    val first_level_cond = 'first_level === "是"
    val first_level2_cond = 'first_level2 === "是"
    val jiazhi_task_cols = spark.sql(s"""select * from $jiazhi_line_tn limit 0""").schema.map(_.name).map(col)
    val jiazhi_task_df = part_jiazhi_task_df
      //3个月信息总结
      .withColumn("line_time_3", when(month3_cond, 'plan_run_time).otherwise("0"))
      .withColumn("line_distance_3", when(month3_cond, 'line_distance).otherwise("0"))
      .withColumn("num_task_3", when(month3_cond, 1).otherwise(0))
      .withColumn("num_task_ontime_3", when(month3_cond && ontime_cond, 1).otherwise(0))
      .withColumn("batch_delay_task_3", when(month3_cond && batch_delay_cond, 1).otherwise(0))
      .withColumn("first_task_3", when(month3_cond && first_level_cond, 1).otherwise(0))
      .withColumn("first_batch_delay_task_3", when(month3_cond && first_level_cond && batch_delay_cond, 1).otherwise(0))
      .withColumn("first_task_32", when(month3_cond && first_level2_cond, 1).otherwise(0))
      .withColumn("first_batch_delay_task_32", when(month3_cond && first_level2_cond && batch_delay_cond, 1).otherwise(0))
      .withColumn("avg_shidao_piao_3", when(month3_cond, 'votes_d).otherwise("0"))
      .withColumn("avg_batch_delay_time_3", when(month3_cond && batch_delay_cond, 'delay_batch_tm).otherwise("0"))
      //6个月信息总结
      .withColumn("line_time_6", when(month6_cond, 'plan_run_time).otherwise("0"))
      .withColumn("line_distance_6", when(month6_cond, 'line_distance).otherwise("0"))
      .withColumn("num_task_6", when(month6_cond, 1).otherwise(0))
      .withColumn("num_task_ontime_6", when(month6_cond && ontime_cond, 1).otherwise(0))
      .withColumn("batch_delay_task_6", when(month6_cond && batch_delay_cond, 1).otherwise(0))
      .withColumn("first_task_6", when(month6_cond && first_level_cond, 1).otherwise(0))
      .withColumn("first_batch_delay_task_6", when(month6_cond && first_level_cond && batch_delay_cond, 1).otherwise(0))
      .withColumn("first_task_62", when(month6_cond && first_level2_cond, 1).otherwise(0))
      .withColumn("first_batch_delay_task_62", when(month6_cond && first_level2_cond && batch_delay_cond, 1).otherwise(0))
      .withColumn("avg_shidao_piao_6", when(month6_cond, 'votes_d).otherwise("0"))
      .withColumn("avg_batch_delay_time_6", when(month6_cond && batch_delay_cond, 'delay_batch_tm).otherwise("0"))
      .groupBy("line_code")
      .agg(
        first("transoport_level") as "transoport_level",
        avg("line_time_3") as "line_time_3",
        avg("line_distance_3") as "line_distance_3",
        sum("num_task_3") as "num_task_3",
        sum("num_task_ontime_3") as "num_task_ontime_3",
        sum("batch_delay_task_3") as "batch_delay_task_3",
        sum("first_task_3") as "first_task_3",
        sum("first_batch_delay_task_3") as "first_batch_delay_task_3",
        sum("first_task_32") as "first_task_32",
        sum("first_batch_delay_task_32") as "first_batch_delay_task_32",
        avg("avg_shidao_piao_3") as "avg_shidao_piao_3",
        avg("avg_batch_delay_time_3") as "avg_batch_delay_time_3",
        avg("line_time_6") as "line_time_6",
        avg("line_distance_6") as "line_distance_6",
        sum("num_task_6") as "num_task_6",
        sum("num_task_ontime_6") as "num_task_ontime_6",
        sum("batch_delay_task_6") as "batch_delay_task_6",
        sum("first_task_6") as "first_task_6",
        sum("first_batch_delay_task_6") as "first_batch_delay_task_6",
        sum("first_task_62") as "first_task_62",
        sum("first_batch_delay_task_62") as "first_batch_delay_task_62",
        avg("avg_shidao_piao_6") as "avg_shidao_piao_6",
        avg("avg_batch_delay_time_6") as "avg_batch_delay_time_6",
        max("month") as "month"
      ).na.fill("", Seq("line_time_3", "line_time_6"))
      .withColumn("line_time_distribute_3", getLineTimeUDF('line_time_3))
      .withColumn("line_time_distribute_6", getLineTimeUDF('line_time_6))
      .withColumn("if_yasuo", when('line_time_6.cast("double") < 'line_time_3.cast("double"), "是").otherwise("否"))
      .withColumn("ratio_ontime_3", when(colNotNull('num_task_3), 'num_task_ontime_3 / 'num_task_3).otherwise(0.0))
      .withColumn("ratio_ontime_6", when(colNotNull('num_task_6), 'num_task_ontime_6 / 'num_task_6).otherwise(0.0))
      .withColumn("ratio_down", when(colNotNull('num_task_3) && colNotNull('num_task_6), 'batch_delay_task_3 / 'num_task_3 - 'batch_delay_task_6 / 'num_task_6).otherwise(0.0))
      .withColumn("num_task_down", round('ratio_down.cast("double") * 'num_task_3.cast("double"), 0))
      .withColumn("ratio_down_first_level", when(colNotNull('num_task_3) && colNotNull('num_task_6), 'first_batch_delay_task_3 / 'num_task_3 - 'first_batch_delay_task_6 / 'num_task_6).otherwise(0.0))
      .withColumn("num_task_down_first_level", when('first_task_3.cast("double") > 3, round('ratio_down_first_level * 'num_task_3, 0)).otherwise(round('ratio_down_first_level * 'num_task_6, 0)))
      .withColumn("distance_task_down_first_level", 'num_task_down_first_level * 'line_distance_3)
      .withColumn("piao_task_down_first_level", 'num_task_down_first_level * 'avg_shidao_piao_3)
      .withColumn("ratio_down_first_level2", when(colNotNull('num_task_3) && colNotNull('num_task_6), 'first_batch_delay_task_32 / 'num_task_3 - 'first_batch_delay_task_62 / 'num_task_6).otherwise(0.0))
      .withColumn("num_task_down_first_level2", when('first_task_32.cast("double") > 3, round('ratio_down_first_level2 * 'num_task_3, 0)).otherwise(round('ratio_down_first_level2 * 'num_task_6, 0)))
      .withColumn("distance_task_down_first_level2", 'num_task_down_first_level2 * 'line_distance_3)
      .withColumn("piao_task_down_first_level2", 'num_task_down_first_level2 * 'avg_shidao_piao_3)
      .withColumn("value_delay_piao", 'num_task_down * 'avg_shidao_piao_3)
      .withColumn("value_firstlevel_delay_piao", 'num_task_down_first_level * 'avg_shidao_piao_3)
      .withColumn("value_firstlevel_delay_piao2", 'num_task_down_first_level2 * 'avg_shidao_piao_3)
      .withColumn("delay_time_down_min", 'avg_batch_delay_time_3.cast("double") - 'avg_batch_delay_time_6.cast("double"))
      .withColumn("delay_time_down_h", when(colNotNull('delay_time_down_min), 'delay_time_down_min / 60.0).otherwise(0.0))
      .na.fill("", Seq("delay_time_down_h", "num_task_3", "num_task_6"))
      .withColumn("label_batch_time", getLabelBatchTimeUDF('delay_time_down_h))
      .withColumn("label", getLabelUDF('num_task_3, 'num_task_6))
      .withColumn("label_batch_delay", when('batch_delay_task_3 > 0 || 'batch_delay_task_6 > 0, "是").otherwise("否"))
      .withColumn("label_firstlevel", when('first_task_3 > 0 || 'first_task_6 > 0, "是").otherwise("否"))
      .withColumn("label_batch_delay_firstlevel", when('first_batch_delay_task_3 > 0 || 'first_batch_delay_task_6 > 0, "是").otherwise("否"))
      .withColumn("label_firstlevel2", when('first_task_32 > 0 || 'first_task_62 > 0, "是").otherwise("否"))
      .withColumn("label_batch_delay_firstlevel2", when('first_batch_delay_task_32 > 0 || 'first_batch_delay_task_62 > 0, "是").otherwise("否"))
      .withColumn("inc_day", lit(month_last_day))
      .select(jiazhi_task_cols: _*).persist()
    logger.error(">>>>>价值线路的数据总量为>>>>>>>" + jiazhi_task_df.count())
    writeToHive(spark, jiazhi_task_df, Seq("inc_day"), jiazhi_line_tn)
    jiazhi_task_df
  }

  def jiazhiTaskONE(spark: SparkSession, task_detail_df: DataFrame, warn_yj_df: DataFrame, jiazhi_task_tn: String, inc_day: String): DataFrame = {
    import spark.implicits._
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val jiazhi_task_cols = spark.sql(s"""select * from $jiazhi_task_tn limit 0""").schema.map(_.name).map(col)
    val jiazhi_task_df = task_detail_df.join(warn_yj_df, Seq("task_id"), "left")
      .withColumn("first_level", when('yujing === "紧急预警", "是").otherwise("否"))
      .withColumn("first_level2", when('yujing2 === "紧急预警2", "是").otherwise("否"))
      .withColumn("inc_day", lit(month_last_day))
      .select(jiazhi_task_cols: _*).persist()
    writeToHive(spark, jiazhi_task_df, Seq("inc_day"), jiazhi_task_tn)
    jiazhi_task_df.select("task_id", "if_run_delay", "delay_batch_tm", "line_code", "transoport_level", "month", "is_run_ontime", "if_batch_delay", "plan_run_time", "line_distance", "votes_d", "first_level", "first_level2", "month", "inc_day")
  }

  //  加载任务明细 全量27w/天~
  def getTaskDetailDF(spark: SparkSession, bef_first_5_day: String, month_first_day: String, month_last_day: String, aft_last_10_day: String): DataFrame = {
    val task_detail_sql =
      s"""select task_id,line_require_id,task_plan_depart_date,line_code,require_category,cvy_name,stop_over_zone_code,vehicle_serial,src_zone_code,dest_zone_code,vehicle_type,conveyance_type,capacity_load,actual_capacity_load,full_load_weight,transoport_level,plan_depart_tm,actual_depart_tm,plan_arrive_tm,actual_arrive_tm,votes,biz_type,src_city_code,dest_city_code,carrier_name,carrier_type,driver_id,driver_name,is_stop,state,actual_run_time,batch_last_arrive_tm,src_longitude,src_latitude,dest_longitude,dest_latitude,votes_ol,votes_od,votes_l,votes_lw,votes_s,votes_n,votes_d,votes_w,votes_st,votes_sp,votes_dp,is_timeliness_appraise,is_run_ontime,piece_type,inc_day,actual_send_batch,actual_arrive_batch,send_batch_date,send_work_day,send_batch,arrive_batch,
         |  if(plan_run_time is not null and trim(plan_run_time) != '',plan_run_time,'0') plan_run_time,
         |  if(line_distance is not null and trim(line_distance) != '',line_distance,'0') line_distance,
         |  if(actual_arrive_tm > batch_last_arrive_tm,'是', '否') as if_batch_delay,
         |  (unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(batch_last_arrive_tm, 'yyyy-MM-dd HH:mm:ss') ) / 60 AS delay_batch_tm,
         |  if(actual_run_time > plan_run_time + 1, '是', '否') as if_run_delay,
         |  (actual_run_time - plan_run_time - 1) as delay_run_tm,
         |  if(actual_arrive_tm > plan_arrive_tm, '是', '否') as if_plan_delay,
         |  (unix_timestamp(actual_arrive_tm, 'yyyy-MM-dd HH:mm:ss') - unix_timestamp(plan_arrive_tm, 'yyyy-MM-dd HH:mm:ss')) / 60 AS delay_plan_tm,
         |  Month(task_plan_depart_date) as month
         |from dm_tdsp_dw.grd_new_task_detail
         |where inc_day between '$bef_first_5_day' and '$aft_last_10_day'
         |      and task_id is not null and trim(task_id) != ''
         |      and is_timeliness_appraise in ('1')
         |      and piece_type in ('大件', '小件')
         |      and (actual_arrive_tm is not null or trim(actual_arrive_tm) != '')
         |      and regexp_replace(substr(plan_depart_tm, 0,10),'-','') between '$month_first_day' and '$month_last_day'
         |      --limit 100
         |      """.stripMargin
    logger.error(">>>>加载任务明细sql>>>>" + task_detail_sql)
    val task_detail_df = spark.sql(task_detail_sql).persist()
    logger.error(">>加载的任务明细数据总量为>>>" + task_detail_df.count())
    task_detail_df.show(1)
    task_detail_df
  }

  //  加载告警汇总明细 全量20w/天~
  def getWarningSummaryDF(spark: SparkSession, bef_first_5_day: String, month_first_day: String, month_last_day: String, aft_last_10_day: String): (DataFrame, DataFrame) = {
    val org_warn_summary_sql =
      s"""
         |SELECT task_id,attr39,concat(task_id,'_',attr39) group,msg_type,biz_type,task_plan_depart_date,warn_level,
         |if(msg_type in ('5','7','8') and warn_level = '3','紧急预警','') yujing,
         |if((msg_type in ('5','7','8') and warn_level = '3') or msg_type in ('9','10','11','12','13'),'紧急预警2','') yujing2,inc_day
         |FROM ods_russtask.tt_vehicle_monitor_warning_summary
         |where inc_day between '$bef_first_5_day' and '$aft_last_10_day'
         |      and task_id is not null and trim(task_id) != ''
         |      and regexp_replace(task_plan_depart_date,'-','') between '$month_first_day' and '$month_last_day'
         |      and msg_type in ('5','7','8','9','10','11','12','13')
         |      and biz_type in ('0','16')
         |      --limit 100
         |""".stripMargin
    logger.error(">>>>加载告警汇总明细sql>>>>" + org_warn_summary_sql)
    val warn_summary_df = spark.sql(org_warn_summary_sql).persist()
    warn_summary_df.show(1)
    logger.error(">>加载的告警汇总明细数据总量为>>>" + warn_summary_df.count())

    //--2023-07月yujing 保留，yujing2 置空，08月 yujing 置空，yujing2 保留，
    var warn_yj_df: DataFrame = null
    if (month_first_day.substring(0, 6) < "202308") {
      warn_yj_df = warn_summary_df.groupBy("task_id")
        .agg(
          max("yujing") as "yujing",
          lit("") as "yujing2")
        .select("task_id", "yujing", "yujing2")
    } else {
      warn_yj_df = warn_summary_df.groupBy("task_id")
        .agg(
          lit("") as "yujing",
          max("yujing2") as "yujing2")
        .select("task_id", "yujing", "yujing2")
    }

    val warn_sum_df = warn_summary_df
      .withColumn("num", row_number().over(Window.partitionBy("group").orderBy(desc("inc_day"))))
      .filter("num = 1")
      .select("task_id", "attr39", "group", "msg_type", "biz_type", "warn_level", "task_plan_depart_date")
    (warn_yj_df, warn_sum_df)
  }

  def getLabelUDF = udf((num_task_3: String, num_task_6: String) => {
    var label = "其他"
    val task_3 = if (strNotNull(num_task_3)) num_task_3.toDouble else 0.0
    val task_6 = if (strNotNull(num_task_6)) num_task_6.toDouble else 0.0
    if (task_3 > 0 && task_6 == 0) label = "3月有"
    if (task_3 == 0 && task_6 > 0) label = "6月有"
    if (task_3 > 0 && task_6 > 0) label = "3月有6月有"
    label
  })

  def getLabelBatchTimeUDF = udf((delay_time_down_h: String) => {
    var label_batch_time = "其他"
    val tm_h: Double = if (strNotNull(delay_time_down_h)) delay_time_down_h.toDouble / 60.0 else 0.0
    label_batch_time = tm_h match {
      case x if x <= 0 => "晚点时长增加"
      case x if x > 0 && x <= 2 => "晚点时长减少0-2h"
      case x if x > 2 && x <= 4 => "晚点时长减少2-4h"
      case x if x > 4 && x <= 6 => "晚点时长减少4-6h"
      case x if x > 6 && x <= 8 => "晚点时长减少6-8h"
      case x if x > 8 => "晚点时长减少>8h"
      case _ => "其他"
    }
    label_batch_time
  })

  def getLineTimeUDF = udf((line_time: String) => {
    var line_time_distribute = "其他"
    val tm: Double = if (strNotNull(line_time)) line_time.toDouble / 60.0 else 0.0
    line_time_distribute = tm match {
      case x if x >= 0 && x <= 2 => "0-2h"
      case x if x > 2 && x <= 4 => "2-4h"
      case x if x > 4 && x <= 8 => "4-8h"
      case x if x > 8 && x <= 12 => "8-12h"
      case x if x > 12 && x <= 16 => "12-16h"
      case x if x > 16 && x <= 20 => "16-20h"
      case x if x > 20 => ">20h"
      case _ => "其他"
    }
    line_time_distribute
  })
}
