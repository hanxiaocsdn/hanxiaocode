package com.sf.app.smart

import com.sf.app.smart.SmartAppContext.getCreateTable
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import ru.yandex.clickhouse.except.ClickHouseException
import utils.JDBCUtils.getSmartDevCKConnect
import utils.SparkBuilder
import java.sql.{Connection, PreparedStatement}
import java.util.Properties
import java.util.concurrent.ConcurrentHashMap

/**
 * @description:
 * @author 01418539 caojia
 * @date 2022/3/25 16:11
 */
object LoadHiveToClicKhouseApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")

    val tns: Array[String] = Array(
      "scomm_device_order_summary_provice",
      "scomm_device_order_summary_city",
      "scomm_device_order_summary_region",
      "scomm_device_order_summary_street",
      "scomm_device_order_summary_community",
      "scomm_device_order_summary_village",
      "scomm_device_company_agent_dtl",
      "scomm_device_order_on_cnt",
      "scomm_device_coding_status_dtl")

    val start_day = args(0)
    val end_day = args(1)
    val delFlag = args(2)

    var tableNanme = ""

    if (args.length == 3 && delFlag.toInt == 0) {
      processCreateTable(tns)
    } else if (args.length == 3 && delFlag.toInt != 0) {
      for (i <- 0 until tns.length) {
        tableNanme = tns(i)
        upsertToClickhouse(spark, tableNanme, start_day, end_day)
      }
    } else {
      logger.error(
        """
          |需要输入3个参数：
          |     start_day:yyyy-MM-dd
          |     end_day:yyyy-MM-dd
          |     delFlag:是否删除表重建，0：删除重建 非0：不建表  直接数据处理
          |""".stripMargin)
      sys.exit(2)
    }
    spark.stop()
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")

  }

  def processCreateTable(tns: Array[String]): Unit = {
    var conn: Connection = null
    var sql = ""
    val createSQL: ConcurrentHashMap[String, String] = getCreateTable()

    for (i <- 0 until tns.length) {
      sql = createSQL.get(tns(i))
      val tableName = tns(i)
      conn = getSmartDevCKConnect()
      try {
        //删除
        val delSql = s"DROP table smart_community.$tableName"
        val delState: PreparedStatement = conn.prepareStatement(delSql)
        delState.execute()
      } catch {
        case e1: ClickHouseException => logger.error(s"表 不存在 无需删除" + e1.getMessage)
        case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
      }
      //建表
      try {
        val createSQl: PreparedStatement = conn.prepareStatement(sql)
        logger.error(s"表：$tableName 的建表语句为：" + sql)
        logger.error(s"在clickhouse中建表 $tableName 成功！！！！！")
        createSQl.execute()
      } catch {
        case e1: ClickHouseException => logger.error(s"建表失败，请检查建表语句！" + e1.getMessage)
        case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
      }

    }
  }

  def upsertToClickhouse(spark: SparkSession, tableName: String, start_day: String, end_day: String): Unit = {
    val conn: Connection = getSmartDevCKConnect()
    try {
      val querySql = s"select inc_day from smart_community.$tableName where SUBSTRING( inc_day,1,10) >= '$start_day' and SUBSTRING( inc_day,1,10) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"ALTER TABLE smart_community.$tableName DELETE WHERE SUBSTRING( inc_day,1,10) >= '$start_day' and SUBSTRING( inc_day,1,10) <= '$end_day'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 smart_community.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }

    val ck_url = "jdbc:clickhouse://10.216.162.10:8123/smart_community"

    val ckProp = new Properties()

    //写入/out读出参数
    val ck_params = Map[String, String](
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "default",
      "password" -> "123456"
    )

    //加载 hive 中的表数据
    spark.sql(
      s"""
         |select
         | *
         |from dm_gis_oms.$tableName
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .write.mode(SaveMode.Append).options(ck_params).jdbc(ck_url, s"smart_community.$tableName", ckProp)

    //读出数据，检查是否写成功
    val querySQL = s"(SELECT *  FROM smart_community.$tableName where SUBSTRING( inc_day,1,10) >= '$start_day' and SUBSTRING( inc_day,1,10) <= '$end_day') as tmp"

    val partData: DataFrame = spark.read
      .format("jdbc")
      .option("url", ck_url)
      .options(ck_params)
      .option("dbtable", querySQL)
      .load()
    partData.limit(20).collect().foreach(println(_))
    logger.error(s"insert into table smart_community.$tableName,the count bettween $start_day to $end_day is:" + partData.count())

  }

  def creatDatabase(tableName: String): Unit = {
    val conn: Connection = getSmartDevCKConnect()
    try {
      val delSql = s"create database if not exists smart_community"
      val delState: PreparedStatement = conn.prepareStatement(delSql)
      delState.execute()
    } catch {
      case e1: ClickHouseException => logger.error(s"表 $tableName 不存在" + e1.getMessage)
      case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
    }
  }

}
