package com.sf.app.smart

import java.util
import java.util.concurrent.ConcurrentHashMap

/**
 * @description:
 * @author 01418539 caojia
 * @date 2022/3/25 18:11
 */
object SmartAppContext {

  val ck_table = new util.concurrent.ConcurrentHashMap[String, String]()
  val mysql_table = new util.concurrent.ConcurrentHashMap[String, String]()

  def getMysqlcreateTable(): ConcurrentHashMap[String, String] = {

    mysql_table.put("scomm_device_coding_status_dtl", SCOMM_DEVICE_CODING_STATUS_DTL)
    mysql_table.put("scomm_device_order_on_cnt", SCOMM_DEVICE_ORDER_ON_CNT)
    mysql_table.put("scomm_device_company_agent_dtl", SCOMM_DEVICE_COMPANY_AGENT_DTL)
    mysql_table.put("scomm_device_order_summary_provice", SCOMM_DEVICE_ORDER_SUMMARY_PROVICE)
    mysql_table.put("scomm_device_order_summary_city", SCOMM_DEVICE_ORDER_SUMMARY_CITY)
    mysql_table.put("scomm_device_order_summary_region", SCOMM_DEVICE_ORDER_SUMMARY_REGION)
    mysql_table.put("scomm_device_order_summary_street", SCOMM_DEVICE_ORDER_SUMMARY_STREET)
    mysql_table.put("scomm_device_order_summary_community", SCOMM_DEVICE_ORDER_SUMMARY_COMMUNITY)
    mysql_table.put("scomm_device_order_summary_village", SCOMM_DEVICE_ORDER_SUMMARY_VILLAGE)
    mysql_table

  }


  def getCreateTable(): ConcurrentHashMap[String, String] = {
    ck_table.put("scomm_device_coding_status_dtl", scomm_device_coding_status_dtl)
    ck_table.put("scomm_device_order_on_cnt", scomm_device_order_on_cnt)
    ck_table.put("scomm_device_company_agent_dtl", scomm_device_company_agent_dtl)
    ck_table.put("scomm_device_order_summary_provice", scomm_device_order_summary_provice)
    ck_table.put("scomm_device_order_summary_city", scomm_device_order_summary_city)
    ck_table.put("scomm_device_order_summary_region", scomm_device_order_summary_region)
    ck_table.put("scomm_device_order_summary_street", scomm_device_order_summary_street)
    ck_table.put("scomm_device_order_summary_community", scomm_device_order_summary_community)
    ck_table.put("scomm_device_order_summary_village", scomm_device_order_summary_village)
    ck_table
  }

  //bdp平台上mysql表
  lazy val SCOMM_DEVICE_CODING_STATUS_DTL =
    """
      |CREATE TABLE IF NOT EXISTS  gis_oms_lip_egov.SCOMM_DEVICE_CODING_STATUS_DTL(
      |  `ID` varchar(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` varchar(50) NOT NULL COMMENT '统计日期（yyyyMMdd)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_NAME` VARCHAR(255) DEFAULT NULL COMMENT '设备所属站名称',
      |  `DEVICE_LOCATION` VARCHAR(100) NOT NULL DEFAULT '' COMMENT ' 设备地址',
      |  `DEVICE_NO` VARCHAR(50) NOT NULL COMMENT '设备编号/对应海康的设备序列号',
      |  `TOTAL_CODING` int(11) DEFAULT NULL COMMENT '端口总数',
      |  `ONLINE_TIME` varchar(50) DEFAULT NULL  COMMENT '上线时间【精确到日期】',
      |  `CODING_NO` VARCHAR(10) DEFAULT NULL COMMENT '插口编号',
      |  `ORDER_CNT` int(11) DEFAULT NULL COMMENT '订单总数',
      |  `ON_ORDER_CNT` int(11) DEFAULT NULL COMMENT '有效订单总数',
      |  `CODING_STATUS` varchar(50) DEFAULT NULL COMMENT '插口状态 0-未使用，1-使用中',
      |
      |
      |  `CREATE_TIME` timestamp NULL DEFAULT current_timestamp(),
      |  `CREATE_USER` varchar(50) DEFAULT NULL,
      |  `MODIFY_TIME` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
      |  `MODIFY_USER` varchar(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='设备端口及状态明细表'
      |""".stripMargin

  lazy val SCOMM_DEVICE_ORDER_ON_CNT =
    """
      |CREATE TABLE IF NOT EXISTS  gis_oms_lip_pns.SCOMM_DEVICE_ORDER_ON_CNT(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `CHARGE_NO` VARCHAR(36) NOT NULL COMMENT '设备号',
      |  `CODING_NO` VARCHAR(10) DEFAULT NULL COMMENT '插口编号',
      |  `ORDER_START_DATE` VARCHAR(50) NOT NULL COMMENT '订单统计周期开始日期',
      |  `ORDER_END_DATE` VARCHAR(50) NOT NULL COMMENT '订单统计周期结束日期',
      |  `ORDER_CNT` INT(11) DEFAULT NULL COMMENT '订单总数',
      |  `ON_ORDER_CNT` INT(11) DEFAULT NULL COMMENT '有效订单总数',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='一段时间内的订单总数及有效数'
      |""".stripMargin

  lazy val SCOMM_DEVICE_COMPANY_AGENT_DTL =
    """
      |CREATE TABLE IF NOT EXISTS  gis_oms_lip_egov.SCOMM_DEVICE_COMPANY_AGENT_DTL(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_NAME` VARCHAR(255) DEFAULT NULL COMMENT '设备所属站名称',
      |  `DEVICE_LOCATION` VARCHAR(100) NOT NULL DEFAULT '' COMMENT ' 设备地址',
      |  `DEVICE_NO` VARCHAR(50) NOT NULL COMMENT '设备编号/对应海康的设备序列号',
      |  `ONLINE_TIME` VARCHAR(50) DEFAULT NULL  COMMENT '上线时间【精确到日期】',
      |  `RULE_DETAILS` VARCHAR(5000) DEFAULT NULL COMMENT '规则内容（JSON格式）',
      |  `SOCKET_NUMBER` INT(11) DEFAULT '0' COMMENT '设备路数,充电口数量',
      |  `BRAND` VARCHAR(20) DEFAULT NULL COMMENT '品牌',
      |  `BUILDING_SUPPLIER` VARCHAR(255) DEFAULT NULL COMMENT '建设供应商',
      |  `SUPPLY_RESPONSIBLE` VARCHAR(64) DEFAULT NULL COMMENT '建设供应商负责人',
      |  `SUPPLY_RESPONSIBLE_PHONE` VARCHAR(64) DEFAULT NULL COMMENT '建设供应商负责人联系电话',
      |  `COMPANY` VARCHAR(255) DEFAULT '' COMMENT '物业名称（公司）',
      |  `AGENT` VARCHAR(128) DEFAULT NULL COMMENT '代理公司名称',
      |  `CUSTOM_STATUS` VARCHAR(50) DEFAULT NULL COMMENT '自定义状态：1-上线，2-锁定，3-下线',
      |  `D_STATUS` VARCHAR(50) DEFAULT NULL COMMENT '设备状态：0-离线，1-在线，9-未上线，-1-故障',
      |  `TOTAL_STATUS_YES` VARCHAR(50) DEFAULT NULL COMMENT '当天是否同时上线 0 否 1 是',
      |  `TOTAL_STATUS_BE` VARCHAR(50) DEFAULT NULL COMMENT '当天是否同时上线 0 否 1 是',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='设备明细表-含公司信息'
      |""".stripMargin

  lazy val SCOMM_DEVICE_ORDER_SUMMARY_PROVICE =
    """
      | CREATE TABLE IF NOT EXISTS gis_oms_lip_pns.SCOMM_DEVICE_ORDER_SUMMARY_PROVICE(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_CNT` INT(11) DEFAULT NULL COMMENT '站点数量',
      |  `DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '设备总数',
      |  `SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '设备总口数',
      |  `ON_DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '在线设备数',
      |  `ON_SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '在线充电口数',
      |  `WEEK_SOCKET_RATE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均使用率,4位有效数',
      |  `WEEK_AVG_PRICE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均客单价',
      |  `WEEK_AVG_ELE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周耗电量/每单',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='设备汇总表-区域维度【省】'
      |""".stripMargin

  lazy val SCOMM_DEVICE_ORDER_SUMMARY_CITY =
    """
      | CREATE TABLE IF NOT EXISTS gis_oms_lip_pns.SCOMM_DEVICE_ORDER_SUMMARY_CITY(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_CNT` INT(11) DEFAULT NULL COMMENT '站点数量',
      |  `DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '设备总数',
      |  `SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '设备总口数',
      |  `ON_DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '在线设备数',
      |  `ON_SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '在线充电口数',
      |  `WEEK_SOCKET_RATE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均使用率,4位有效数',
      |  `WEEK_AVG_PRICE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均客单价',
      |  `WEEK_AVG_ELE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周耗电量/每单',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='设备汇总表-区域维度【市】'
      |""".stripMargin

  lazy val SCOMM_DEVICE_ORDER_SUMMARY_REGION =
    """
      |CREATE TABLE IF NOT EXISTS gis_oms_lip_pns.SCOMM_DEVICE_ORDER_SUMMARY_REGION(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_CNT` INT(11) DEFAULT NULL COMMENT '站点数量',
      |  `DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '设备总数',
      |  `SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '设备总口数',
      |  `ON_DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '在线设备数',
      |  `ON_SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '在线充电口数',
      |  `WEEK_SOCKET_RATE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均使用率,4位有效数',
      |  `WEEK_AVG_PRICE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均客单价',
      |  `WEEK_AVG_ELE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周耗电量/每单',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='设备汇总表-区域维度【区】'
      |""".stripMargin

  lazy val SCOMM_DEVICE_ORDER_SUMMARY_STREET =
    """
      | CREATE TABLE IF NOT EXISTS gis_oms_lip_pns.SCOMM_DEVICE_ORDER_SUMMARY_STREET(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_CNT` INT(11) DEFAULT NULL COMMENT '站点数量',
      |  `DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '设备总数',
      |  `SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '设备总口数',
      |  `ON_DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '在线设备数',
      |  `ON_SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '在线充电口数',
      |  `WEEK_SOCKET_RATE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均使用率,4位有效数',
      |  `WEEK_AVG_PRICE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均客单价',
      |  `WEEK_AVG_ELE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周耗电量/每单',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='设备汇总表-区域维度【街道】'
      |""".stripMargin

  lazy val SCOMM_DEVICE_ORDER_SUMMARY_COMMUNITY =
    """
      |CREATE TABLE IF NOT EXISTS gis_oms_lip_pns.SCOMM_DEVICE_ORDER_SUMMARY_COMMUNITY(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_CNT` INT(11) DEFAULT NULL COMMENT '站点数量',
      |  `DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '设备总数',
      |  `SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '设备总口数',
      |  `ON_DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '在线设备数',
      |  `ON_SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '在线充电口数',
      |  `WEEK_SOCKET_RATE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均使用率,4位有效数',
      |  `WEEK_AVG_PRICE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均客单价',
      |  `WEEK_AVG_ELE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周耗电量/每单',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='设备汇总表-区域维度【社区】'
      |""".stripMargin

  lazy val SCOMM_DEVICE_ORDER_SUMMARY_VILLAGE =
    """
      |CREATE TABLE IF NOT EXISTS gis_oms_lip_pns.SCOMM_DEVICE_ORDER_SUMMARY_VILLAGE(
      |    `ID` VARCHAR(50) NOT NULL COMMENT '主键（STATDATE+RATE的MD5值）',
      |  `STATDATE` VARCHAR(50) NOT NULL COMMENT '统计日期（YYYYMMDD)',
      |
      |  `PROVINCE_NAME` VARCHAR(50) DEFAULT NULL COMMENT '省',
      |  `CITY_NAME` VARCHAR(50) DEFAULT NULL COMMENT '城市',
      |  `REGION` VARCHAR(50) DEFAULT NULL COMMENT '行政区',
      |  `STREET` VARCHAR(50) DEFAULT NULL COMMENT '街道',
      |  `COMMUNITY` VARCHAR(50) DEFAULT NULL COMMENT '社区',
      |  `VILLAGE` VARCHAR(255) DEFAULT NULL COMMENT '小区',
      |  `STATION_CNT` INT(11) DEFAULT NULL COMMENT '站点数量',
      |  `DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '设备总数',
      |  `SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '设备总口数',
      |  `ON_DEVICE_CNT` INT(11) DEFAULT NULL COMMENT '在线设备数',
      |  `ON_SOCKET_CNT` INT(11) DEFAULT NULL COMMENT '在线充电口数',
      |  `WEEK_SOCKET_RATE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均使用率,4位有效数',
      |  `WEEK_AVG_PRICE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周平均客单价',
      |  `WEEK_AVG_ELE` DOUBLE(16,10) DEFAULT NULL COMMENT '近一周耗电量/每单',
      |
      |  `CREATE_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP(),
      |  `CREATE_USER` VARCHAR(50) DEFAULT NULL,
      |  `MODIFY_TIME` TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP(),
      |  `MODIFY_USER` VARCHAR(50) DEFAULT NULL,
      |  PRIMARY KEY (`ID`),
      |  KEY `STATDATE` (`STATDATE`) USING BTREE
      |  ) ENGINE=INNODB DEFAULT CHARSET=UTF8 COMMENT='设备汇总表-区域维度【小区】'
      |""".stripMargin


  //自建平台上的ck表
  lazy val scomm_device_coding_status_dtl =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_coding_status_dtl(
      |  `id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_name` String COMMENT '设备所属站名称',
      |  `device_location` String COMMENT '设备地址',
      |  `device_no` String  COMMENT '设备编号/对应海康的设备序列号',
      |  `total_coding` int COMMENT '端口总数',
      |  `online_time` String  COMMENT '上线时间【精确到日期】',
      |  `coding_no` String COMMENT '插口编号',
      |  `order_cnt` int COMMENT '订单总数',
      |  `on_order_cnt` int COMMENT '有效订单总数',
      |  `coding_status` String COMMENT '插口状态 0-未使用，1-使用中',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_order_on_cnt =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_order_on_cnt(
      |`id` String COMMENT '主键',
      |  `charge_no` String COMMENT '设备号',
      |  `coding_no` String COMMENT '插口编号',
      |  `order_start_date` String COMMENT '订单统计周期开始日期',
      |  `order_end_date` String COMMENT '订单统计周期结束日期',
      |  `order_cnt` int COMMENT '订单总数',
      |  `on_order_cnt` int COMMENT '有效订单总数',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_company_agent_dtl =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_company_agent_dtl(
      |`id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_name` String COMMENT '设备所属站名称',
      |  `device_location` String COMMENT '设备地址',
      |  `device_no` String  COMMENT '设备编号/对应海康的设备序列号',
      |  `online_time` String  COMMENT '上线时间【精确到日期】',
      |  `rule_details` String  COMMENT '规则内容（json格式）',
      |  `socket_number` int COMMENT '设备路数,充电口数量',
      |  `brand` String COMMENT '品牌',
      |  `building_supplier` String COMMENT '建设供应商',
      |  `supply_responsible` String COMMENT '建设供应商负责人',
      |  `supply_responsible_phone` String COMMENT '建设供应商负责人联系电话',
      |  `company` String COMMENT '物业名称（公司）',
      |  `agent` String COMMENT '代理公司名称',
      |  `custom_status` String COMMENT '自定义状态：1-上线，2-锁定，3-下线',
      |  `d_status` String COMMENT '设备状态：0-离线，1-在线，9-未上线，-1-故障',
      |  `total_status_yes` String COMMENT '当天是否同时上线 0 否 1 是',
      |  `total_status_be` String COMMENT '当天是否同时上线 0 否 1 是',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_order_summary_provice =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_order_summary_provice(
      |`id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_cnt` int COMMENT '站点数量',
      |  `device_cnt` int COMMENT '设备总数',
      |  `socket_cnt` int COMMENT '设备总口数',
      |  `on_device_cnt` int COMMENT '在线设备数',
      |  `on_socket_cnt` int COMMENT '在线充电口数',
      |  `week_socket_rate` double COMMENT '近一周平均使用率,4位有效数',
      |  `week_avg_price` double COMMENT '近一周平均客单价',
      |  `week_avg_ele` double COMMENT '近一周耗电量/每单',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_order_summary_city =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_order_summary_city(
      |`id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_cnt` int COMMENT '站点数量',
      |  `device_cnt` int COMMENT '设备总数',
      |  `socket_cnt` int COMMENT '设备总口数',
      |  `on_device_cnt` int COMMENT '在线设备数',
      |  `on_socket_cnt` int COMMENT '在线充电口数',
      |  `week_socket_rate` double COMMENT '近一周平均使用率,4位有效数',
      |  `week_avg_price` double COMMENT '近一周平均客单价',
      |  `week_avg_ele` double COMMENT '近一周耗电量/每单',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_order_summary_region =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_order_summary_region(
      |`id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_cnt` int COMMENT '站点数量',
      |  `device_cnt` int COMMENT '设备总数',
      |  `socket_cnt` int COMMENT '设备总口数',
      |  `on_device_cnt` int COMMENT '在线设备数',
      |  `on_socket_cnt` int COMMENT '在线充电口数',
      |  `week_socket_rate` double COMMENT '近一周平均使用率,4位有效数',
      |  `week_avg_price` double COMMENT '近一周平均客单价',
      |  `week_avg_ele` double COMMENT '近一周耗电量/每单',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_order_summary_street =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_order_summary_street(
      |`id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_cnt` int COMMENT '站点数量',
      |  `device_cnt` int COMMENT '设备总数',
      |  `socket_cnt` int COMMENT '设备总口数',
      |  `on_device_cnt` int COMMENT '在线设备数',
      |  `on_socket_cnt` int COMMENT '在线充电口数',
      |  `week_socket_rate` double COMMENT '近一周平均使用率,4位有效数',
      |  `week_avg_price` double COMMENT '近一周平均客单价',
      |  `week_avg_ele` double COMMENT '近一周耗电量/每单',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_order_summary_community =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_order_summary_community(
      |`id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_cnt` int COMMENT '站点数量',
      |  `device_cnt` int COMMENT '设备总数',
      |  `socket_cnt` int COMMENT '设备总口数',
      |  `on_device_cnt` int COMMENT '在线设备数',
      |  `on_socket_cnt` int COMMENT '在线充电口数',
      |  `week_socket_rate` double COMMENT '近一周平均使用率,4位有效数',
      |  `week_avg_price` double COMMENT '近一周平均客单价',
      |  `week_avg_ele` double COMMENT '近一周耗电量/每单',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

  lazy val scomm_device_order_summary_village =
    """
      |CREATE TABLE if not exists  smart_community.scomm_device_order_summary_village(
      |`id` String COMMENT '主键',
      |  `province_name` String COMMENT '省',
      |  `city_name` String COMMENT '城市',
      |  `region` String COMMENT '行政区',
      |  `street` String COMMENT '街道',
      |  `community` String COMMENT '社区',
      |  `village` String COMMENT '小区',
      |  `station_cnt` int COMMENT '站点数量',
      |  `device_cnt` int COMMENT '设备总数',
      |  `socket_cnt` int COMMENT '设备总口数',
      |  `on_device_cnt` int COMMENT '在线设备数',
      |  `on_socket_cnt` int COMMENT '在线充电口数',
      |  `week_socket_rate` double COMMENT '近一周平均使用率,4位有效数',
      |  `week_avg_price` double COMMENT '近一周平均客单价',
      |  `week_avg_ele` double COMMENT '近一周耗电量/每单',
      |  `inc_day` String COMMENT '分区日期'
      |  )
      |ENGINE=MergeTree()
      |PRIMARY KEY `id`
      |ORDER BY  `id`
      |PARTITION BY `inc_day`
      |""".stripMargin

}
