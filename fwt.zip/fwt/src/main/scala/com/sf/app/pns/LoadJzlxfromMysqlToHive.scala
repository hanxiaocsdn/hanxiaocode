package com.sf.app.pns

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.getPnsDevMysqlConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}

/**
 * @task_id: 暂时未用，取数方式已变化 --- 641890
 * @description: tname:jzlx_test1
 * @demander:
 * @author 01418539 caojia
 * @date 2023/1/3 10:15
 */
object LoadJzlxfromMysqlToHive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val flag = args(0)
    if (flag.toInt == 1) {
      queryPnsMysql("jzlx_test1")
    } else {
      insertPnsToHive(spark, "jzlx_test1")
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def queryPnsMysql(table_name: String): Unit = {
    var connection: Connection = null
    val arr = table_name.replaceAll("'", "").split(",")
    //建表语句
    for (i <- 0 until arr.length) {
      connection = getPnsDevMysqlConnect()
      val tableName = arr(i)
      try {
        val cs = s"show create table $tableName"

        val cs_create: PreparedStatement = connection.prepareStatement(cs)
        val cs_res = cs_create.executeQuery()
        while (cs_res.next()) {
          val Table = cs_res.getString("Table")
          val Create = cs_res.getString("Create Table")
          logger.error("表：" + Table + "的建表语句为：" + Create)
        }
      } catch {
        case ex: Exception =>
          connection = getPnsDevMysqlConnect()
          val cs = s"show tables"
          val cs_create: PreparedStatement = connection.prepareStatement(cs)
          val cs_res = cs_create.executeQuery()
          while (cs_res.next()) {
            val tables = cs_res.getString("Tables_in_rsspnsrt")
            logger.error("库：rsspnsrt中所有表为：" + tables)
          }

          logger.error(s"查看 $tableName 的建表语句时出现错误，请核对输入的表名在mysql中是否存在", ex)
          throw ex
      }
    }
    //cnt
    for (i <- 0 until arr.length) {
      connection = getPnsDevMysqlConnect()
      val tableName = arr(i)
      try {
        val cnts = s"select count(1) as cnt from $tableName limit 100"
        val cnts_count: PreparedStatement = connection.prepareStatement(cnts)
        val cnts_res = cnts_count.executeQuery()
        while (cnts_res.next()) {
          val cnt = cnts_res.getString("cnt")
          logger.error("表：" + tableName + " 的数据总量为>" + cnt)
        }
      } catch {
        case ex: Exception => logger.error(s"查询表 $tableName 中 数据总量时出现错误", ex)
          throw ex
      }
    }
  }

  def insertPnsToHive(spark: SparkSession, table_name: String): Unit = {
    val arr = table_name.replaceAll("'", "").split(",")
    for (i <- 0 until arr.length) {
      val tableName = arr(i)
      loadPnsMysqlToHive(spark, tableName, tableName)
    }
  }

  /**
   * 读取mysql表中的数据写入hive表中
   *
   * @param spark
   * @param mysqlTable
   * @param hiveTable
   */
  def loadPnsMysqlToHive(spark: SparkSession, mysqlTable: String, hiveTable: String): Unit = {
    val hive_table_struct: String = spark.sql(s"select * from dm_gis_oms.$hiveTable limit 0").schema.toList.map(_.name).mkString(",")
    val query_state = s"(select $hive_table_struct from $mysqlTable) as t"

    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://rsspnsrt-m.db.sfcloud.local:3306/rsspnsrt?useUnicode=true&characterEncoding=utf-8",
      "user" -> "rsspnsrt",
      "password" -> "T6TzIua9dI",
      "dbtable" -> query_state)

    try {
      val df = spark.read.format("jdbc").options(params).load()
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        df.createOrReplaceTempView("tmpTableName") //临时表
        spark.sql("use dm_gis")
        spark.sql(s"insert overwrite table $hiveTable partition(inc_day) select * from tmpTableName")
      } else {
        throw new Exception(s"mysql的 $hiveTable 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $hiveTable 中 插入数据时出现错误", ex)
        throw ex
    }
  }
}
