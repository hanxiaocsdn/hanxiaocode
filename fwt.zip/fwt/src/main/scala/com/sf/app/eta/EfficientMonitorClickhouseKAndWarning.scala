package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import utils.ColumnUtil.colNotNull
import utils.DateUtil.getdaysBefore
import utils.JDBCUtils.getSmartNaviCKConnect
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}
import java.time.LocalTime
import java.util.Properties

/**
 * @task_id: 824825
 * @description: 时效定责数据实时监控
 * @demander: 01430321 廖静文
 * @author 01418539 caojia
 * @date 2023/9/15 15:09
 */
object EfficientMonitorClickhouseKAndWarning extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    run(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val start_time = getStartAnEndTime(inc_day)._1
    val end_time = getStartAnEndTime(inc_day)._2
    val time_slot = getStartAnEndTime(inc_day)._3
    val new_inc_day = getStartAnEndTime(inc_day)._4
    if (start_time != "" && end_time != "") {
      //1 warning_info 2
      val trackwarning_info_sql = s"""select count(distinct JSONExtractString(info, 'id')) count_warning from dm_ck_scm.vms_gta_ground_trackwarning_info where create_time >= '$start_time' and create_time <'$end_time'""".stripMargin
      logger.error(">>trackwarning_info_sql--验证传入时间格式-->>" + trackwarning_info_sql)
      val trackwarning_info_sub_ob_sql =
        s"""
           |select JSONExtractString(info, 'mix_label') mix_label,count(distinct JSONExtractString(info, 'id')) cnt
           |from dm_ck_scm.vms_gta_ground_trackwarning_info
           |where create_time >= '$start_time' and create_time <'$end_time'
           |group by JSONExtractString(info, 'mix_label')
           |""".stripMargin
      //2 task_flatmap 1
      val task_flatmap_sql = s"""select count(1) count_flatmap from dm_ck_scm.omcs_ground_task_flatmap where create_time >= '$start_time' and create_time <'$end_time'""".stripMargin
      //3 recall_cal2 1
      val recall_cal2_sql = s"""select count(1) count_cal2 from dm_ck_scm.scm_plan_recall_cal2 where create_time >= '$start_time' and create_time <'$end_time'""".stripMargin
      //4 line_recall 4
      val line_recall_sql = s"""select count(1) count_recall from dm_ck_scm.eta_std_line_recall where create_time >= '$start_time' and create_time <'$end_time'""".stripMargin
      val line_recall_type_sql =
        s"""
           |select JSONExtractInt(info, 'task_conduct_type') task_conduct_type,count(1) cnt
           |from dm_ck_scm.eta_std_line_recall
           |where create_time >= '$start_time' and create_time <'$end_time'
           |group by JSONExtractInt(info, 'task_conduct_type')
           |""".stripMargin

      val line_recall2_sql = s"""select count(1) count_recall2 from dm_ck_scm.eta_std_line_recall2 where create_time >= '$start_time' and create_time <'$end_time'""".stripMargin
      val line_recall2_cnt_sql =
        s"""
           |select count(1) count_recall2_resp
           |from dm_ck_scm.eta_std_line_recall2
           |where create_time >= '$start_time' and create_time <'$end_time'
           |and JSONExtractString(info, 'actual_arrive_tm') <> ''
           |and JSONExtractString(info, 'actual_arrive_tm') >= '$start_time' and JSONExtractString(info, 'actual_arrive_tm') <'$end_time'
           |and JSONExtractString(info, 'ac_is_run_ontime') = '0'
           |and JSONExtractString(info, 'carrier_type')<> '0'
           |and JSONExtractString(info, 'require_category')in ('0','1','2','5','17','18')
           |""".stripMargin
      val line_recall2_final2_sql =
        s"""
           |select JSONExtractString(info, 'task_label_final2') task_label_final2,count(1) cnt
           |from dm_ck_scm.eta_std_line_recall2
           |where create_time >= '$start_time' and create_time <'$end_time'
           |and JSONExtractString(info, 'actual_arrive_tm') <> ''
           |and JSONExtractString(info, 'actual_arrive_tm') >= '$start_time' and JSONExtractString(info, 'actual_arrive_tm') <'$end_time'
           |and JSONExtractString(info, 'ac_is_run_ontime') = '0'
           |and JSONExtractString(info, 'carrier_type')<> '0'
           |and JSONExtractString(info, 'require_category')in ('0','1','2','5','17','18')
           |group by JSONExtractString(info, 'task_label_final2')
           |""".stripMargin

      val line_recall2_final_sql =
        s"""
           |select JSONExtractString(info, 'task_label_final') task_label_final,count(1) cnt
           |from dm_ck_scm.eta_std_line_recall2
           |where create_time >= '$start_time' and create_time <'$end_time'
           |and JSONExtractString(info, 'actual_arrive_tm') <> ''
           |and JSONExtractString(info, 'actual_arrive_tm') >= '$start_time' and JSONExtractString(info, 'actual_arrive_tm') <'$end_time'
           |and JSONExtractString(info, 'ac_is_run_ontime') = '0'
           |and JSONExtractString(info, 'carrier_type')<> '0'
           |and JSONExtractString(info, 'require_category')in ('0','1','2','5','17','18')
           |group by JSONExtractString(info, 'task_label_final')
           |""".stripMargin

      val trackwarning_info_df = loadCountDF(spark, trackwarning_info_sql, start_time, end_time)
      val trackwarning_info_sub_ob_df = loadCountDF(spark, trackwarning_info_sub_ob_sql, start_time, end_time)
      val task_flatmap_df = loadCountDF(spark, task_flatmap_sql, start_time, end_time)
      val recall_cal2_df = loadCountDF(spark, recall_cal2_sql, start_time, end_time)
      val line_recall_df = loadCountDF(spark, line_recall_sql, start_time, end_time)
      val line_recall_type_df = loadCountDF(spark, line_recall_type_sql, start_time, end_time)
      val line_recall2_df = loadCountDF(spark, line_recall2_sql, start_time, end_time)
      val line_recall2_cnt_df = loadCountDF(spark, line_recall2_cnt_sql, start_time, end_time)
      val line_recall2_final2_df = loadCountDF(spark, line_recall2_final2_sql, start_time, end_time)
      val line_recall2_final_df = loadCountDF(spark, line_recall2_final_sql, start_time, end_time)

      val warn_df = trackwarning_info_df.join(trackwarning_info_sub_ob_df, Seq("tm"), "left")
        .withColumn("mix_label_sub", when('mix_label === "主观", 'cnt).otherwise(0))
        .withColumn("mix_label_ob", when('mix_label === "客观", 'cnt).otherwise(0))
        .withColumn("mix_label_service", when('mix_label === "服务区", 'cnt).otherwise(0))
        .withColumn("mix_label_short", when('mix_label === "无多余时长", 'cnt).otherwise(0))
        .withColumn("mix_label_cont", when('mix_label === "无法识别", 'cnt).otherwise(0))
        .groupBy("tm")
        .agg(first("count_warning") as "count_warning",
          sum("mix_label_sub") as "mix_label_sub",
          sum("mix_label_ob") as "mix_label_ob",
          sum("mix_label_service") as "mix_label_service",
          sum("mix_label_short") as "mix_label_short",
          sum("mix_label_cont") as "mix_label_cont")
        .withColumn("mix_label_sub", when(colNotNull('count_warning), concat(round(lit(100) * 'mix_label_sub / 'count_warning, 2), lit("%"))))
        .withColumn("mix_label_ob", when(colNotNull('count_warning), concat(round(lit(100) * 'mix_label_ob / 'count_warning, 2), lit("%"))))
        .withColumn("mix_label_service", when(colNotNull('count_warning), concat(round(lit(100) * 'mix_label_service / 'count_warning, 2), lit("%"))))
        .withColumn("mix_label_short", when(colNotNull('count_warning), concat(round(lit(100) * 'mix_label_short / 'count_warning, 2), lit("%"))))
        .withColumn("mix_label_cont", when(colNotNull('count_warning), concat(round(lit(100) * 'mix_label_cont / 'count_warning, 2), lit("%"))))
        .select("tm", "count_warning", "mix_label_sub", "mix_label_ob", "mix_label_service", "mix_label_short", "mix_label_cont")

      val warn_recall_df = line_recall_df.join(line_recall_type_df, Seq("tm"), "left")
        .withColumn("conduct_no", when('task_conduct_type === "3", 'cnt).otherwise(0))
        .withColumn("conduct_yes", when('task_conduct_type === "1", 'cnt).otherwise(0))
        .groupBy("tm")
        .agg(first("count_recall") as "count_recall",
          sum("conduct_no") as "conduct_no",
          sum("conduct_yes") as "conduct_yes")
        .withColumn("conduct_no", when(colNotNull('count_recall), concat(round(lit(100) * 'conduct_no / 'count_recall, 2), lit("%"))))
        .withColumn("conduct_yes", when(colNotNull('count_recall), concat(round(lit(100) * 'conduct_yes / 'count_recall, 2), lit("%"))))
        .select("tm", "conduct_no", "conduct_yes")

      val recall_1_df = line_recall2_cnt_df.join(line_recall2_final2_df, Seq("tm"), "left")
        .withColumn("final2_ob1", when('task_label_final2 === "客观情况1", 'cnt).otherwise(0))
        .withColumn("final2_ob2", when('task_label_final2 === "客观情况2", 'cnt).otherwise(0))
        .withColumn("final2_sub", when('task_label_final2 === "主观", 'cnt).otherwise(0))
        .withColumn("final2_cont", when('task_label_final2 === "暂未识别", 'cnt).otherwise(0))
        .groupBy("tm")
        .agg(first("count_recall2_resp") as "count_recall2_resp",
          sum("final2_ob1") as "final2_ob1",
          sum("final2_ob2") as "final2_ob2",
          sum("final2_sub") as "final2_sub",
          sum("final2_cont") as "final2_cont")
        .withColumn("final2_ob1", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final2_ob1 / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final2_ob2", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final2_ob2 / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final2_sub", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final2_sub / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final2_cont", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final2_cont / 'count_recall2_resp, 2), lit("%"))))
        .select("tm", "count_recall2_resp", "final2_ob1", "final2_ob2", "final2_sub", "final2_cont")

      val recall_2_df = line_recall2_cnt_df.join(line_recall2_final_df, Seq("tm"), "left")
        .withColumn("final_noconduct", when('task_label_final === "未执行标准线路", 'cnt).otherwise(0))
        .withColumn("final_fullsub", when('task_label_final === "百分百主观", 'cnt).otherwise(0))
        .withColumn("final_ob1", when('task_label_final === "客观情况1", 'cnt).otherwise(0))
        .withColumn("final_ob2", when('task_label_final === "客观情况2", 'cnt).otherwise(0))
        .withColumn("final_sub", when('task_label_final === "主观", 'cnt).otherwise(0))
        .withColumn("final_cont", when('task_label_final === "暂未识别", 'cnt).otherwise(0))
        .groupBy("tm")
        .agg(first("count_recall2_resp") as "count_recall2_resp",
          sum("final_noconduct") as "final_noconduct",
          sum("final_fullsub") as "final_fullsub",
          sum("final_ob1") as "final_ob1",
          sum("final_ob2") as "final_ob2",
          sum("final_sub") as "final_sub",
          sum("final_cont") as "final_cont")
        .withColumn("final_noconduct", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final_noconduct / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final_fullsub", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final_fullsub / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final_ob1", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final_ob1 / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final_ob2", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final_ob2 / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final_sub", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final_sub / 'count_recall2_resp, 2), lit("%"))))
        .withColumn("final_cont", when(colNotNull('count_recall2_resp), concat(round(lit(100) * 'final_cont / 'count_recall2_resp, 2), lit("%"))))
        .select("tm", "final_noconduct", "final_fullsub", "final_ob1", "final_ob2", "final_sub", "final_cont")

      val res_cols = spark.sql("""select * from dm_gis.eta_monitor_warning limit 0""").schema.map(_.name).map(col)
      val res_df = warn_df.join(task_flatmap_df, Seq("tm"), "left")
        .join(recall_cal2_df, Seq("tm"), "left")
        .join(line_recall_df, Seq("tm"), "left")
        .join(line_recall2_df, Seq("tm"), "left")
        .join(warn_recall_df, Seq("tm"), "left")
        .join(recall_1_df, Seq("tm"), "left")
        .join(recall_2_df, Seq("tm"), "left")
        .withColumn("flatmap_cal2", 'count_flatmap - 'count_cal2)
        .withColumn("cal2_recall", 'count_cal2 - 'count_recall)
        .withColumn("recall_recall2", 'count_recall - 'count_recall2)
        .withColumn("inc_day", lit(new_inc_day))
        .withColumn("time_slot", lit(time_slot))
        .select(res_cols: _*).persist()
      upsertToClickhouseMonitor(spark, "gis_oms_uimp_pns", "ETA_MONITOR_WARNING", res_df, new_inc_day, time_slot)
      writeToHive(spark, res_df, Seq("inc_day", "time_slot"), "dm_gis.eta_monitor_warning")
    }
  }

  def upsertToClickhouseMonitor(spark: SparkSession, ckdbName: String, cktableName: String, res_df: DataFrame, inc_day: String, time_slot: String): Unit = {
    val conn: Connection = getSmartNaviCKConnect()
    try {
      val querySql = s"select * from $ckdbName.$cktableName where SUBSTRING(INC_DAY,1,8) >= '$inc_day' and SUBSTRING(INC_DAY,1,8) <= '$inc_day' and TIME_SLOT ='$time_slot'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"ALTER TABLE $ckdbName.$cktableName DELETE WHERE SUBSTRING(INC_DAY,1,8) >= '$inc_day' and SUBSTRING(INC_DAY,1,8) <= '$inc_day' and TIME_SLOT ='$time_slot'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 $ckdbName.$cktableName 中$inc_day 至 $inc_day 数据时出现错误", ex)
        throw ex
    }
    val ck_url = "jdbc:clickhouse://10.216.162.10:8123/gis_oms_uimp_pns"
    val ckProp = new Properties()
    //写入/out读出参数
    val ck_params = Map[String, String](
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "gis_oms_pns",
      "password" -> "gis_oms_pns@123@"
    )

    //加载 hive 中的表数据
    res_df.write.mode(SaveMode.Append).options(ck_params).jdbc(ck_url, s"$ckdbName.$cktableName", ckProp)

    //读出数据，检查是否写成功
    val querySQL = s"(SELECT *  FROM $ckdbName.$cktableName where SUBSTRING(INC_DAY,1,8) >= '$inc_day' and SUBSTRING( INC_DAY,1,8) <= '$inc_day') as tmp"

    val partData: DataFrame = spark.read
      .format("jdbc")
      .option("url", ck_url)
      .options(ck_params)
      .option("dbtable", querySQL)
      .load()
    partData.limit(20).collect().foreach(println(_))
    logger.error(s"insert into table $ckdbName.$cktableName,the count bettween $inc_day to $inc_day is:" + partData.count())
  }


  def loadCountDF(spark: SparkSession, query_sql: String, start_time: String, end_time: String): DataFrame = {
    //写入/out读出参数
    val ck_params = Map[String, String](
      "url" -> "jdbc:clickhouse://10.119.82.211:8123/dm_ck_scm",
      "driver" -> "ru.yandex.clickhouse.ClickHouseDriver",
      "batchsize" -> "20000",
      "isolationLevel" -> "NONE",
      "numPartitions" -> "1",
      "user" -> "dm_ck_scm",
      "password" -> "dm_ck_scm@123@"
    )
    //读出数据，检查是否写成功
    val querySQL = s"($query_sql) as tmp"
    val partDF: DataFrame = spark.read
      .format("jdbc")
      .options(ck_params)
      .option("dbtable", querySQL)
      .load()
      .withColumn("tm", concat_ws("_", lit(start_time), lit(end_time)))
    partDF
  }


  def getStartAnEndTime(inc_day: String): (String, String, String, String) = {
    val current_hour = LocalTime.now().getHour
    //    val current_hour = 12
    val for_inc_day = inc_day.substring(0, 4) + "-" + inc_day.substring(4, 6) + "-" + inc_day.substring(6, 8)
    var new_inc_day = inc_day
    var start_time, end_time = ""
    var st_tm, ed_tm = ""
    if (current_hour % 3 == 0) {
      if (current_hour == 0) {
        val yes_inc_day = getdaysBefore(for_inc_day, -1, "yyyy-MM-dd")
        new_inc_day = getdaysBefore(inc_day, -1, "yyyyMMdd")
        st_tm = "21"
        ed_tm = "24"
        start_time = yes_inc_day + " " + "21:00:00"
        end_time = yes_inc_day + " " + "23:59:59"
      } else if (Seq(3, 6, 9).contains(current_hour)) {
        st_tm = "0" + "" + (current_hour - 3)
        ed_tm = "0" + "" + current_hour
        start_time = for_inc_day + " " + st_tm + ":00:00"
        end_time = for_inc_day + " " + ed_tm + ":00:00"
      } else if (current_hour == 12) {
        st_tm = "0" + "" + (current_hour - 3)
        ed_tm = "" + current_hour
        start_time = for_inc_day + " " + st_tm + ":00:00"
        end_time = for_inc_day + " " + ed_tm + ":00:00"
      } else {
        st_tm = "" + (current_hour - 3)
        ed_tm = "" + current_hour
        start_time = for_inc_day + " " + st_tm + ":00:00"
        end_time = for_inc_day + " " + ed_tm + ":00:00"
      }
    }
    (start_time, end_time, st_tm + "_" + ed_tm, new_inc_day)
  }
}
