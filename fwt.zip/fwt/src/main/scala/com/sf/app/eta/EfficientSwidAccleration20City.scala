package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, udf}
import utils.SparkBuilder

/**
 * @task_id:
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2023/3/24 18:02
 */
object EfficientSwidAccleration20City extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val start_num = args(1)
    val end_num = args(2)
//    choose20City(spark, inc_day, start_num, end_num)
    choose20LeftCity(spark, inc_day, start_num, end_num)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def choose20LeftCity(spark: SparkSession, inc_day: String, start_num: String, end_num: String): Unit = {
    import spark.implicits._
    val start = start_num.toInt
    val end = end_num.toInt
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_direction_20 limit 0""").schema.map(_.name).map(col)
    val sql = s"""select * from dm_gis.eta_experience_speed_track_fix_to320_direction_32 where inc_day= '$inc_day' and cast(num as int) between $start and $end """
    logger.error("输入的sql语句：" + sql)
    val s_e_index_df_tmp = spark.sql(sql).repartition(600).persist()
    logger.error(">>>获取的数据总量>>>" + s_e_index_df_tmp.count())
    val s_e_index_df = s_e_index_df_tmp.na.fill("", Seq("adcode_first_gj", "adcode_end_gj"))
      .withColumn("save_flag", get20CityUDF('adcode_first_gj, 'adcode_end_gj))
      .filter('save_flag =!= "Y")
      .select(res_cols: _*)
    writeToHive(spark, s_e_index_df.coalesce(50), Seq("inc_day", "num"), "dm_gis.eta_experience_speed_track_fix_to320_direction_12")
  }

  def choose20City(spark: SparkSession, inc_day: String, start_num: String, end_num: String): Unit = {
    import spark.implicits._
    val start = start_num.toInt
    val end = end_num.toInt
    val res_cols = spark.sql("""select * from dm_gis.eta_experience_speed_track_fix_to320_direction_20 limit 0""").schema.map(_.name).map(col)
    val sql = s"""select * from dm_gis.eta_experience_speed_track_fix_to320_direction_32 where inc_day= '$inc_day' and cast(num as int) between $start and $end """
    logger.error("输入的sql语句：" + sql)
    val s_e_index_df_tmp = spark.sql(sql).repartition(600).persist()
    logger.error(">>>获取的数据总量>>>" + s_e_index_df_tmp.count())
    val s_e_index_df = s_e_index_df_tmp.na.fill("", Seq("adcode_first_gj", "adcode_end_gj"))
      .withColumn("save_flag", get20CityUDF('adcode_first_gj, 'adcode_end_gj))
      .filter('save_flag === "Y")
      .select(res_cols: _*)
    writeToHive(spark, s_e_index_df.coalesce(50), Seq("inc_day", "num"), "dm_gis.eta_experience_speed_track_fix_to320_direction_20")
  }

  def get20CityUDF = udf((adcode_first_gj: String, adcode_end_gj: String) => {
    var save_flag = ""
    val city_code_20 = Seq("310000", "110000", "500000", "120000", "440100", "330100", "320100", "410100", "420100", "350100", "610100", "430100", "340100", "370100", "210100", "230100", "130100", "510100", "220100", "440300")
    if (city_code_20.contains(adcode_first_gj) && city_code_20.contains(adcode_end_gj)) save_flag = "Y"
    save_flag
  })
}
