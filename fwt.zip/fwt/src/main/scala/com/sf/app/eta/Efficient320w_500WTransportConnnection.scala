package com.sf.app.eta


import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.{HTTP_ETA_STDLINE_P, HTTP_XY_COORDS_P}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{colTrimNotNull, strNotNull}
import utils.DateUtil.{getdaysBeforeOrAfter, timeToTimestampFormat}
import utils.EtaUtil.{extractCodeUDF, getCsvCityCodeDF}
import utils.{HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 765313
 * @description: 规划运力衔接表达速计算 来源表：dm_allin.transport_connection_weekly_statistics_0929
 * @demander:舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/6/6 17:19
 */
case class TranspWeeklyStatistics(line_code: String, src_zone_code: String, dest_zone_code: String, improve_batch_reduced_duration: String, start_city: String, end_city: String, direc_start_end: String, byroad_distance: String,
                                  highway_distance: String, byroad_speed: String, improve_batch_required_speed: String, improve_batch_period: String, prop_cnt: String, inc_day: String)

object Efficient320w_500WTransportConnnection extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0) //原始数据每周二更新
    val ft_table = "dm_gis.transport_connection_weekly_statistics_0929"
    val kj_table = "dm_allin.transport_connection_weekly_statistics_0929"
    val cnt = spark.sql(s"""select * from $kj_table where inc_day='$inc_day' limit 1""".stripMargin).head(1).size
    if (cnt > 0) {
      val city_map_df = getCsvCityCodeDF(spark)
      run(spark, city_map_df, ft_table, kj_table, inc_day)
    } else {
      logger.error(">>>>>>>>>该天无数据，无需运行>>>>>>>>>")
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, city_map_df: DataFrame, ft_table: String, kj_table: String, inc_day: String): Unit = {
    import spark.implicits._
    val day_15_bef = getdaysBeforeOrAfter(inc_day, -14)
    val operator_cols = Seq("line_code", "src_zone_code", "dest_zone_code", "plan_run_time", "plan_arrive_tm", "connection_last_tm", "inc_day").map(col)
    val o_tran_sql =
      s"""
         |select line_code,src_zone_code,src_area_code,dest_zone_code,plan_depart_tm,plan_send_batch,plan_arrive_tm,line_distance,plan_run_time,plan_run_speed,actual_run_speed,line_delivery_batch,current_period,last_batch,connection_last_tm,speed_connection,waybill_all_mean,speed_flag,days_per_week,last_batch_new_period,contactor,is_usable,usable_reason,notes,connection_arrive_tm,inc_day
         |from $kj_table
         |where inc_day='$inc_day'--业务表周更新
         |group by line_code,src_zone_code,src_area_code,dest_zone_code,plan_depart_tm,plan_send_batch,plan_arrive_tm,line_distance,plan_run_time,plan_run_speed,actual_run_speed,line_delivery_batch,current_period,last_batch,connection_last_tm,speed_connection,waybill_all_mean,speed_flag,days_per_week,last_batch_new_period,contactor,is_usable,usable_reason,notes,connection_arrive_tm,inc_day
         |--and line_code = '010WD028W0430'
         |--limit 5
         |""".stripMargin
    logger.error(">>>加载的运力原表为>>>" + o_tran_sql)
    val o_tran_df = spark.sql(o_tran_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val o_part_tran_df = o_tran_df.select(operator_cols: _*)
      .na.fill("", Seq("plan_arrive_tm", "connection_last_tm"))
      .withColumn("improve_batch_reduced_duration", getCompareUdf('plan_arrive_tm, 'connection_last_tm, 'inc_day))
      .withColumn("improve_batch_run_time", 'plan_run_time.cast("double") - 'improve_batch_reduced_duration.cast("double"))
      .withColumn("start_dept_code", extractCodeUDF('src_zone_code))
      .withColumn("end_dept_code", extractCodeUDF('dest_zone_code))
      .join(broadcast(city_map_df.selectExpr("city_code as start_dept_code", "city_name start_city")), Seq("start_dept_code"), "left")
      .join(broadcast(city_map_df.selectExpr("city_code as end_dept_code", "city_name end_city")), Seq("end_dept_code"), "left")
      .withColumn("direc_start_end", concat_ws("_", 'start_city, 'end_city))
      .repartition(2)
    logger.error(">>>加载的数据总量为>>>" + o_part_tran_df.count())
    val httpInvoke_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "765313", "【时效规划运力】Efficient320w_500WTransportConnnection", "时效标准线路接口", HTTP_ETA_STDLINE_P, "70b8ef2d67a946ff8f2493389f77028f", o_part_tran_df.count(), 2)
    val httpInvoke_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "765313", "【时效规划运力】Efficient320w_500WTransportConnnection", "根据swid 获取 轨迹点信息接口", HTTP_XY_COORDS_P, "2e4b2a16ef2a4427917f366fb22febb5", o_part_tran_df.count(), 2)
    val rep_tran_df = o_part_tran_df
      .map(row => {
        val line_code = row.getAs[String]("line_code")
        val src_zone_code = row.getAs[String]("src_zone_code")
        val dest_zone_code = row.getAs[String]("dest_zone_code")
        val improve_batch_reduced_duration = row.getAs[String]("improve_batch_reduced_duration")
        val improve_batch_run_time = row.getAs[Double]("improve_batch_run_time")
        val start_city = row.getAs[String]("start_city")
        val end_city = row.getAs[String]("end_city")
        val direc_start_end = row.getAs[String]("direc_start_end")
        val inc_day = row.getAs[String]("inc_day")
        val plan_time = line_code.substring(line_code.length - 4)
        val date = inc_day + "" + plan_time + "" + "00"

        var points, byroad_distance, highway_distance, byroad_speed, prop_cnt = "-"
        if (strNotNull(line_code) && strNotNull(src_zone_code) && strNotNull(dest_zone_code)) {
          points = postTrackqueryIntegrate(line_code, plan_time, src_zone_code, dest_zone_code)
        }
        if (points != "" && strNotNull(date)) {
          val res = getByroadInfo(points, date)
          byroad_distance = res._1
          highway_distance = res._2
          byroad_speed = res._3
          prop_cnt = res._4
        }
        val inter_tm = ((improve_batch_run_time / 60.0 - byroad_distance.toDouble / byroad_speed.toDouble) / 4).toInt //h
        val diff_inter_tm = improve_batch_run_time / 60.0 - byroad_distance.toDouble / byroad_speed.toDouble - inter_tm / 3.0
        val improve_batch_required_speed = (highway_distance.toDouble / diff_inter_tm).formatted("%.2f")
        val improve_batch_period = day_15_bef + "-" + inc_day

        TranspWeeklyStatistics(line_code, src_zone_code, dest_zone_code, improve_batch_reduced_duration, start_city, end_city, direc_start_end, byroad_distance,
          highway_distance, byroad_speed, improve_batch_required_speed, improve_batch_period, prop_cnt, inc_day)
      }).repartition(400).persist(StorageLevel.MEMORY_AND_DISK_SER)

    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_1)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_2)
    rep_tran_df.show(3)

    val direc_start_end_cols_str = rep_tran_df.select("direc_start_end").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    val improve_speed_df = rep_tran_df.groupBy("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "improve_batch_required_speed")
      .agg(lit(true))
      .select("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "improve_batch_required_speed")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val sf_df = loadSFDirect(spark, improve_speed_df, day_15_bef, inc_day, direc_start_end_cols_str)
    val qg_df = loadQGDirect(spark, improve_speed_df, day_15_bef, inc_day, direc_start_end_cols_str)

    val part_df = rep_tran_df
      .join(broadcast(sf_df), Seq("line_code", "src_zone_code", "dest_zone_code", "direc_start_end"), "left")
      .join(broadcast(qg_df), Seq("line_code", "src_zone_code", "dest_zone_code", "direc_start_end"), "left")
      .na.fill("0", Seq("sf_total_trips_num", "sf_improve_batch_trips_num", "sf_improve_batch_trips_days", "total_trips_num", "improve_batch_trips_num", "improve_batch_trips_days"))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(">>>>>>>重新拼装之后的数据总量>>>>>>" + part_df.count())
    improve_speed_df.unpersist()

    val res_cols = spark.sql(s"""select * from $ft_table limit 0""").schema.map(_.name).map(col)

    val res_df = o_tran_df.join(part_df, Seq("line_code", "src_zone_code", "dest_zone_code", "inc_day"), "left")
      .na.fill("", Seq("improve_batch_required_speed"))
      .withColumn("improve_batch_required_speed", when('improve_batch_required_speed.cast("double") <= 0, "").otherwise('improve_batch_required_speed))
      .withColumn("improve_batch_trips_num", when(trim('improve_batch_required_speed) === "", "0").otherwise('improve_batch_trips_num))
      .withColumn("improve_batch_trips_days", when(trim('improve_batch_required_speed) === "", "0").otherwise('improve_batch_trips_days))
      .withColumn("sf_improve_batch_trips_num", when(trim('improve_batch_required_speed) === "", "0").otherwise('sf_improve_batch_trips_num))
      .withColumn("sf_improve_batch_trips_days", when(trim('improve_batch_required_speed) === "", "0").otherwise('sf_improve_batch_trips_days))
      .withColumn("operations", getOperationsUdf('sf_improve_batch_trips_days, 'improve_batch_trips_days))
      .select(res_cols: _*)
    //反写回去
    writeToHive(spark, res_df, Seq("inc_day"), ft_table)
    writeToHive(spark, res_df, Seq("inc_day"), kj_table)
  }

  /**
   * SF内部
   *
   * @param spark
   * @param improve_speed_df
   * @param day_15_bef
   * @param inc_day
   * @param direc_start_end_cols_str
   * @return
   */
  def loadSFDirect(spark: SparkSession, improve_speed_df: DataFrame, day_15_bef: String, inc_day: String, direc_start_end_cols_str: String): DataFrame = {
    import spark.implicits._
    val day_15_bef_2d = getdaysBeforeOrAfter(day_15_bef, -2)
    val day_2_aft = getdaysBeforeOrAfter(inc_day, 2)
    val o_sf_sql =
      s"""
         |select *
         |from
         |(select row_number() over (partition by task_id order by highway_start_date desc) as rank_num,*
         |from
         |(select task_id,start_city,end_city,concat_ws('_',start_city,end_city) direc_start_end,highway_speed_tl_10_2,highway_start_date
         |from dm_gis.eta_task_track_sf
         |where inc_day between '$day_15_bef_2d' and '$day_2_aft'       --根据highway_start_date往前往后取2天
         |and cast(highway_pt as double)>=0.8
         |and cast(highway_speed_tl_10_2 as double)>=50 and cast(highway_speed_tl_10_2 as double)<=120
         |and cast(highway_dist as double)>=50
         |and regexp_replace(highway_start_date,'-','') between '$day_15_bef' and '$inc_day'
         |and concat_ws('_',start_city,end_city) in ($direc_start_end_cols_str)) a ) b        --限制始发、目的城市
         |where rank_num=1
         |""".stripMargin
    logger.error(">>>>加载的顺丰sql>>>>" + o_sf_sql)
    val o_sf_df = spark.sql(o_sf_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>加载的顺丰特定流向数据总量为>>>>" + o_sf_df.count())
    //行业总趟次
    val total_trips_df = o_sf_df.groupBy("direc_start_end").agg(count("task_id") as "sf_total_trips_num")
      .select("direc_start_end", "sf_total_trips_num")

    //行业满足跨班次趟次
    val filter_cond = 'highway_speed_tl_10_2.cast("double") >= 'improve_batch_required_speed.cast("double")
    val batch_trips_df = o_sf_df.join(broadcast(improve_speed_df), Seq("direc_start_end"), "left")
      .withColumn("task_id", when(filter_cond, 'task_id))
      .withColumn("highway_start_date", when(filter_cond, 'highway_start_date))
      .groupBy("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "highway_start_date")
      .agg(
        count("task_id") as "sf_improve_batch_trips_num",
        max("highway_start_date") as "sf_improve_batch_trips_days"
      ).groupBy("line_code", "src_zone_code", "dest_zone_code", "direc_start_end")
      .agg(
        sum("sf_improve_batch_trips_num") as "sf_improve_batch_trips_num",
        count("sf_improve_batch_trips_days") as "sf_improve_batch_trips_days"
      )
      .select("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "sf_improve_batch_trips_num", "sf_improve_batch_trips_days")

    val sf_df = total_trips_df
      .join(broadcast(batch_trips_df), Seq("direc_start_end"), "left")
      .withColumn("sf_total_trips_num", when(colTrimNotNull('sf_total_trips_num), 'sf_total_trips_num).otherwise("0"))
      .withColumn("sf_improve_batch_trips_num", when(colTrimNotNull('sf_improve_batch_trips_num), 'sf_improve_batch_trips_num).otherwise("0"))
      .withColumn("sf_improve_batch_trips_days", when(colTrimNotNull('sf_improve_batch_trips_days), 'sf_improve_batch_trips_days).otherwise("0"))
      .select("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "sf_total_trips_num", "sf_improve_batch_trips_num", "sf_improve_batch_trips_days")
    sf_df
  }

  /**
   * 全国城市信息
   *
   * @param spark
   * @param improve_speed_df
   * @param day_15_bef
   * @param inc_day
   * @param direc_start_end_cols_str
   * @return
   */

  def loadQGDirect(spark: SparkSession, improve_speed_df: DataFrame, day_15_bef: String, inc_day: String, direc_start_end_cols_str: String): DataFrame = {
    import spark.implicits._
    val day_15_bef_2d = getdaysBeforeOrAfter(day_15_bef, -2)
    val day_2_aft = getdaysBeforeOrAfter(inc_day, 2)
    val o_qg_sql =
      s"""
         |select *
         |from
         |(select row_number() over (partition by key_id order by time_highspeed_start_rep desc) as rank_num,*
         |from
         |(select concat(un,'_',highspeed_start_time,'_',highspeed_end_time)as key_id,city_start,city_end,concat_ws('_',city_start,city_end) direc_start_end,speed_highspeed_tl_2,time_highspeed_start_rep
         |from dm_gis.eta_track_highway_detail_3d_with_328_city
         |where inc_day between '$day_15_bef_2d' and '$day_2_aft'   --根据time_highspeed_start_rep往前往后取2天
         |and cast(highspeed_dist_ratio as double)>=0.8
         |and cast(speed_highspeed_tl_2 as double)>=50 and cast(speed_highspeed_tl_2 as double)<=120
         |and cast(highspeed_dist as double)>=50
         |and regexp_replace(time_highspeed_start_rep,'-','') between '$day_15_bef' and '$inc_day'
         |and concat_ws('_',city_start,city_end) in ($direc_start_end_cols_str) ) a ) b        --限制始发、目的城市
         |where rank_num=1
         |""".stripMargin
    logger.error(">>>>加载的全国sql>>>>" + o_qg_sql)
    val o_qd_df = spark.sql(o_qg_sql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>>>加载的全国特定流向数据总量为>>>>" + o_qd_df.count())
    //行业总趟次
    val total_trips_df = o_qd_df.groupBy("direc_start_end").agg(count("key_id") as "total_trips_num")
      .select("direc_start_end", "total_trips_num")
    //行业满足跨班次趟次
    val filter_cond = 'speed_highspeed_tl_2.cast("double") >= 'improve_batch_required_speed.cast("double")
    val batch_trips_df = o_qd_df.join(broadcast(improve_speed_df), Seq("direc_start_end"), "left")
      .withColumn("key_id", when(filter_cond, 'key_id))
      .withColumn("time_highspeed_start_rep", when(filter_cond, 'time_highspeed_start_rep))
      .groupBy("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "time_highspeed_start_rep")
      .agg(
        count("key_id") as "improve_batch_trips_num",
        max("time_highspeed_start_rep") as "improve_batch_trips_days"
      ).groupBy("line_code", "src_zone_code", "dest_zone_code", "direc_start_end")
      .agg(
        sum("improve_batch_trips_num") as "improve_batch_trips_num",
        count("improve_batch_trips_days") as "improve_batch_trips_days"
      )
      .select("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "improve_batch_trips_num", "improve_batch_trips_days")

    val qg_df = total_trips_df
      .join(broadcast(batch_trips_df), Seq("direc_start_end"), "left")
      .withColumn("total_trips_num", when(colTrimNotNull('total_trips_num), 'total_trips_num).otherwise("0"))
      .withColumn("improve_batch_trips_num", when(colTrimNotNull('improve_batch_trips_num), 'improve_batch_trips_num).otherwise("0"))
      .withColumn("improve_batch_trips_days", when(colTrimNotNull('improve_batch_trips_days), 'improve_batch_trips_days).otherwise("0"))
      .select("line_code", "src_zone_code", "dest_zone_code", "direc_start_end", "total_trips_num", "improve_batch_trips_num", "improve_batch_trips_days")
    qg_df
  }

  def getOperationsUdf = udf((sf_improve_batch_trips_days: String, improve_batch_trips_days: String) => {
    var operations = "不调整"
    try {
      if (sf_improve_batch_trips_days.toInt >= 12) {
        operations = "直接调整"
      } else if (sf_improve_batch_trips_days.toInt < 12 && improve_batch_trips_days.toInt >= 12) {
        operations = "换车调整"
      }
    } catch {
      case e: Exception => "" + e
    }
    operations
  })

  def getByroadInfo(points: String, date: String): (String, String, String, String) = {
    val params = //ak的并发 100/S
      s"""{
         |    "ak": "2e4b2a16ef2a4427917f366fb22febb5",
         |    "simple_distance": 0,
         |    "useEstimateTime": 1,
         |    "test": 1,
         |    "stype": 0,
         |    "etype": 2,
         |    "passport": "100000",
         |    "mode": 2,
         |    "speed": 1,
         |    "rtic":0,
         |    "rtic_dur":0,
         |    "output":"json",
         |    "Toll": 1,
         |    "point_src" : 1,
         |    "points":"$points",
         |    "date": "$date"}
         |""".stripMargin
    logger.error("接口正常调用中,传入参数为>>" + params)
    val dynSpeed_arr = Seq("2", "3", "4", "5", "6", "7", "8", "9")
    val dr_len_ab = new ArrayBuffer[String]()
    val speed_ab = new ArrayBuffer[String]()
    var byroad_distance, highway_distance, sum_len, prop_cnt: Double = 0.0
    var part_cnt, all_cnt: Int = 0
    var byroad_speed = "35.0"
    try {
      val hw_str = HttpInvokeUtil.sendPostH(HTTP_XY_COORDS_P, params, 3, 2, "2e4b2a16ef2a4427917f366fb22febb5", "")
      logger.error(">>>>>获取轨迹点信息接口 接口正常调用中>>>>>")
      val hw_str_json = JSON.parseObject(hw_str)
      val route = hw_str_json.getJSONObject("route")
      if (route != null) {
        val paths_arr = route.getJSONArray("paths")
        if (paths_arr != null && paths_arr.size() > 0) {
          for (i <- 0 until paths_arr.size()) {
            val outinfo = paths_arr.getJSONObject(i).getJSONObject("outinfo")
            if (outinfo != null) {
              val links_arr = outinfo.getJSONArray("links")
              if (links_arr != null && links_arr.size() > 0) {
                for (k <- 0 until links_arr.size()) {
                  val roadclass = if (strNotNull(links_arr.getJSONObject(k).getString("roadclass"))) links_arr.getJSONObject(k).getString("roadclass") else "-"
                  val dr_len = if (strNotNull(links_arr.getJSONObject(k).getString("dr_len"))) links_arr.getJSONObject(k).getString("dr_len") else "-"
                  val speed = if (strNotNull(links_arr.getJSONObject(k).getString("speed"))) links_arr.getJSONObject(k).getString("speed") else "-"
                  val dynSpeed = if (strNotNull(links_arr.getJSONObject(k).getString("dynSpeed"))) links_arr.getJSONObject(k).getString("dynSpeed") else "-"
                  sum_len += (try {
                    dr_len.toDouble
                  } catch {
                    case e: Exception => 0.0
                  })
                  if (roadclass == "0") {
                    highway_distance += (try {
                      dr_len.toDouble
                    } catch {
                      case e: Exception => 0.0
                    })
                  } else {
                    all_cnt += 1
                    if (dynSpeed_arr.contains(dynSpeed)) {
                      part_cnt += 1
                    }
                    byroad_distance += (try {
                      dr_len.toDouble
                    } catch {
                      case e: Exception => 0.0
                    })
                    dr_len_ab += dr_len
                    speed_ab += speed
                  }
                }
              }
            }
          }
          prop_cnt = if (all_cnt.toDouble > 0.0) part_cnt.toDouble / all_cnt.toDouble else 0.0
          var tm = 0.0
          if (prop_cnt >= 0.8) {
            for (i <- 0 until dr_len_ab.size) {
              tm += (try {
                dr_len_ab(i).toDouble / 1000 / speed_ab(i).toDouble
              } catch {
                case e: Exception => 0.0
              })
              logger.error(">>>>>>>>>" + tm)
            }
            byroad_speed = if (tm > 0) ((byroad_distance / 1000.0 / tm) * 0.9).formatted("%.2f") else "-"
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    ((byroad_distance / 1000).formatted("%.2f"), (highway_distance / 1000).formatted("%.2f"), byroad_speed, prop_cnt.formatted("%.2f"))
  }

  def postTrackqueryIntegrate(lineCode: String, plan_time: String, src_zone_code: String, dest_zone_code: String): String = {
    val points_ab = new ArrayBuffer[String]()

    val params = s"""{"interfaceControl":0,"planTime":"$plan_time","ak":"70b8ef2d67a946ff8f2493389f77028f","lineCode":"$lineCode","opt":"std2","srcZoneCode":"$src_zone_code","vehicle":8,"destZoneCode":"$dest_zone_code"}""".stripMargin
    try {
      val hw_str = HttpInvokeUtil.sendPost(HTTP_ETA_STDLINE_P, params, 3, 2)
      logger.error("接口正常调用中,传入参数为>>" + params)
      val hw_str_json = JSON.parseObject(hw_str)
      val result = hw_str_json.getJSONObject("result")
      if (result != null) {
        val coords = result.getJSONArray("coords")
        for (i <- 0 until coords.size()) {
          points_ab += coords.getJSONArray(i).toJSONString.replaceAll("\\[|\\]|\"", "")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    points_ab.mkString("|")
  }

  def getCompareUdf = udf((plan_arrive_tm: String, connection_last_tm: String, inc_day: String) => {
    var improve_batch_reduced_duration = "0.0"
    //plan_arrive_tm 2023-06-07 03:30:00  20230606 的 plan_arrive_tm 是年月日 时分秒的形式
    //connection_last_tm 330
    if (strNotNull(plan_arrive_tm) && strNotNull(connection_last_tm)) {
      try {
        val plan_arrive_tm_new = if (plan_arrive_tm.split("\\s+").size > 1) {
          plan_arrive_tm.replaceAll("-", "")
        } else {
          inc_day + " " + plan_arrive_tm.split("\\s+")(0)
        }
        val conn_tm = if (connection_last_tm.size == 3) {
          inc_day + " " + "0" + connection_last_tm.substring(0, 1) + ":" + connection_last_tm.substring(1, 3) + ":" + "00"
        } else {
          inc_day + " " + connection_last_tm.substring(0, 2) + ":" + connection_last_tm.substring(2, 4) + ":" + "00"
        }
        val plan_tm_l = timeToTimestampFormat("yyyyMMdd HH:mm:ss", plan_arrive_tm_new)
        val conn_tm_l = timeToTimestampFormat("yyyyMMdd HH:mm:ss", conn_tm)

        if (plan_tm_l > conn_tm_l) {
          improve_batch_reduced_duration = ((plan_tm_l - conn_tm_l) / 60.0).formatted("%.2f")
        }
        if (plan_tm_l <= conn_tm_l) {
          improve_batch_reduced_duration = ((plan_tm_l + 24 * 3600l - conn_tm_l) / 60.0).formatted("%.2f")
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    improve_batch_reduced_duration
  })

}
