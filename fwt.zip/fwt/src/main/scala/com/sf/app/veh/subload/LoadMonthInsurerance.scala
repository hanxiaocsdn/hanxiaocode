package com.sf.app.veh.subload

import org.apache.commons.lang3.time.FastDateFormat
import org.apache.log4j.Logger
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, SaveMode, SparkSession}
import utils.SparkBuilder

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

/**
 * @task_id: 477118 临时执行 每月一个统计 dm_gis.dwd_insurance_model_province_dtl dwd_insurance_model_province_dtl_qgzh
 * @description: 月度监控各省重货车辆运营率、各项物流运输特征指标变化走势；评估疫情放开前后市场运营环境变化。
 * @demander: 方洪虹  01427794
 * @author 01418539 caojia
 * @date 2023/2/24 15:47
 */
object LoadMonthInsurerance {
  lazy val logger: Logger = Logger.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    pcLoadMonthData(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def pcLoadMonthData(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天
    val month_days = daysBetweenDate(month_first_day, month_last_day) + 1
    val o_un = getMap(spark)
    val res_cols = spark.sql("""select * from dm_gis.dwd_insurance_model_province_dtl_qgzh limit 0""").schema.map(_.name).map(col)

    //	track_eff_days 有效行驶天数  operation_cnt_mt 月度运营次数 total_dist_mt 行驶里程	night_dirve_dist_mt 夜间行驶里程 over_drive_duration_mt	超时驾驶时长
    val o_month_df = spark.sql(s"""select lpn,total_dist_mt,operation_cnt_mt,night_dirve_dist_mt,over_drive_duration_mt,track_eff_days,inc_day from dm_gis.dwd_insurance_model_duration_dist_qgzh_month_dtl where inc_day = '$month_last_day'""")
      .withColumn("abbrev", substring('lpn, 0, 1))
      .join(broadcast(o_un), Seq("abbrev"), "left")
      .withColumn("province", when('province.isNull || trim('province) === "", "其他").otherwise('province))
      .withColumn("vehicle_nums", lit(1))
      .withColumn("month_days", lit(month_days))
      .groupBy("province", "inc_day")
      .agg(
        sum("vehicle_nums") as "vehicle_nums",
        max("month_days") as "month_days",
        sum("total_dist_mt") as "total_dist_mt",
        sum("operation_cnt_mt") as "operation_cnt_mt",
        sum("night_dirve_dist_mt") as "night_dirve_dist_mt",
        sum("over_drive_duration_mt") as "over_drive_duration_mt",
        sum("track_eff_days") as "track_eff_days"
      )
      .withColumn("operation_ratio", 'track_eff_days.cast("double") / ('vehicle_nums.cast("int") * 'month_days))
      .withColumn("avg_total_dist", 'total_dist_mt.cast("double") / ('vehicle_nums.cast("int") * 'month_days))
      .withColumn("avg_night_dist", 'night_dirve_dist_mt.cast("double") / ('vehicle_nums.cast("int") * 'month_days))
      .withColumn("avg_over_duration", 'over_drive_duration_mt.cast("double") / ('vehicle_nums.cast("int") * 'month_days))
      .select(res_cols: _*).persist()

    writeToHive(spark, o_month_df, Seq("inc_day"), "dm_gis.dwd_insurance_model_province_dtl_qgzh")

    val path = "/user/01418539/upload/file/recall_info"
    val options = Map(
      "header" -> "true",
      "delimiter" -> "\\t",
      "compression" -> "gzip",
      "inferSchema" -> true.toString
    )
    writeToCsv(spark, o_month_df.coalesce(1), SaveMode.Append, "20230301", options, path, false)

    o_month_df.unpersist()
  }

  def getVehicle(spark: SparkSession): DataFrame = {
    val sourceDf = spark.sql(s"""select device_id lpn,car_id un,source,bind_time from  dm_gis.tt_device_relation""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("lpn").orderBy(desc("bind_time"))))
      .filter(col("num") === 1).select("lpn", "un")
    sourceDf
  }

  def getMap(spark: SparkSession): DataFrame = {
    import spark.implicits._
    val o_map = Seq(("冀", "河北"),
      ("粤", "广东"),
      ("川", "四川"),
      ("苏", "江苏"),
      ("晋", "山西"),
      ("鲁", "山东"),
      ("云", "云南"),
      ("豫", "河南"),
      ("贵", "贵州"),
      ("浙", "浙江"),
      ("鄂", "湖北"),
      ("赣", "江西"),
      ("闽", "福建"),
      ("皖", "安徽"),
      ("辽", "辽宁"),
      ("陕", "陕西"),
      ("桂", "广西"),
      ("宁", "宁夏"),
      ("蒙", "内蒙古"),
      ("青", "青海"),
      ("甘", "甘肃"),
      ("京", "北京"),
      ("湘", "湖南"),
      ("吉", "吉林"),
      ("渝", "重庆"),
      ("新", "新疆"),
      ("藏", "西藏"),
      ("沪", "上海"),
      ("津", "天津"),
      ("黑", "黑龙江"),
      ("琼", "海南")).toDF("abbrev", "province")
    o_map
  }

  /**
   * 指定日期 11个月前的日期的 月初日期 输入： 20220421
   *
   * @param inc_day
   * @return yyyymmdd 20210501
   */
  def getFirstDayofMonthBeforeOrAfter(inc_day: String, num: Int): String = {
    val tmp_1 = inc_day.substring(0, 6) + "01"
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_1)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    dateFormat.format(cal.getTime())
  }

  def getLastDayofMonthBeforeOrAfter(inc_day: String, num: Int): String = {
    val tmp_1 = inc_day.substring(0, 6) + "01"
    val tmp_2 = getdaysBeforeOrAfter(tmp_1, -1)
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(tmp_2)
    cal.setTime(time_dt)
    cal.add(Calendar.MONTH, num)
    cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE))
    dateFormat.format(cal.getTime())
  }

  def getdaysBeforeOrAfter(inc_day: String, num: Int): String = {
    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val cal: Calendar = Calendar.getInstance()
    val time_dt: Date = dateFormat.parse(inc_day)
    cal.setTime(time_dt)
    cal.add(Calendar.DATE, num)
    dateFormat.format(cal.getTime())
  }

  def daysBetweenDate(start_day: String, end_day: String): Int = {
    var day: Int = 0
    val sdf_inc = FastDateFormat.getInstance("yyyyMMdd")
    val MS_PERDAY = 1000 * 60 * 60 * 24
    try {
      val start = sdf_inc.parse(start_day)
      val end = sdf_inc.parse(end_day)
      day = if (end.getTime - start.getTime >= 0) ((end.getTime - start.getTime) / MS_PERDAY).toInt else ((start.getTime - end.getTime) / MS_PERDAY).toInt //20220101-20220116  一起16天
    } catch {
      case e: Exception => logger.error("检查传入日期格式" + e.getMessage)
    }
    day
  }

  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  def writeToCsv(spark: SparkSession, ds: Dataset[_], saveMode: SaveMode, partitionCol: String, options: Map[String, String] = Map.empty[String, String], file_path: String, flag: Boolean, tableName: String = ""): Unit = {
    //1 将文件写入csv
    ds.write.options(options).mode(saveMode).format("csv").save(file_path)
    logger.info(s"写入csv文件:path:$file_path 成功")
    //2 将csv文件load到hive表中--外部表
    if (flag) {
      val sql_file = s"load data inpath '$file_path' overwrite into table $tableName partition(inc_day='$partitionCol')"
      spark.sqlContext.sql(sql_file)
      logger.info(s"映射hive表成功")
    }
  }

}
