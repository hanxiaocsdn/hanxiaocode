package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter}
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: tmp
 * @description: 风险因子（含告警特征） 月表和多月份特征汇总表
 * @demander: 01402323 罗祯
 * @author 01418539 caojia
 * @date 2022/12/7 13:57
 */
object VehicleRiskAlarmFactorMonthAndFeature extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val flag = args(1)
    if (flag == "1") processMonthRiskAlarm(spark, inc_day)
    if (flag == "2") processYearRiskAlarm(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processMonthRiskAlarm(spark: SparkSession, inc_day: String): Unit = {
    val month_first_day = getFirstDayofMonthBeforeOrAfter(inc_day, -1) //上月第一天
    val month_last_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月最后一天

    val o_month_df = spark.sql(
      s"""select vehicle_no,vehicle_color_name,alarm_code_name,inc_day from dm_gis.ods_insurance_model_risk_alarm_factor_dtl
         |where inc_day between '$month_first_day' and '$month_last_day'
         |      and vehicle_no is not null and trim(vehicle_no) !=''
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val alarm_info_str = Seq("车距过近报警", "车辆碰撞报警", "车道偏离报警", "压实线报警", "超速报警", "超时驾驶报警", "生理疲劳报警", "不目视前方报警", "接打手机报警", "玩手机报警", "抽烟报警", "未系安全带报警", "双手脱把报警", "偏离驾驶位报警", "设备遮挡失效报警", "疑似屏蔽信号报警")
    val alarm_name_str = Seq("close_forward_cnt", "front_collision_cnt", "lane_depart_cnt", "lane_change_cnt", "over_speed_cnt", "timeout_cnt", "phy_fatigue_cnt", "no_looking_ahead_cnt", "phone_call_cnt", "play_phone_cnt", "smoking_cnt", "no_seat_belt_cnt", "off_hand_cnt", "outof_position_cnt", "equip_occ_fail_cnt", "susp_shield_singal_cnt")
    val alarm_cnt_cols = ColumnUtil.renameColumn(alarm_info_str.map(x => when(col("alarm_code_name") === x, 1).otherwise(0)), alarm_name_str)
    val alarm_total_cols = ColumnUtil.renameColumn((Seq("total_alarm_cnt") ++ alarm_name_str).map(sum(_)), Seq("total_alarm_cnt") ++ alarm_name_str)
    //拼装最终表结构
    val res_cols = spark.sql("""select * from dm_gis.dwd_insurance_model_risk_alarm_month_dtl limit 0""").schema.map(x => col(x.name))
    val month_cnt_df = o_month_df.select(Seq("vehicle_no", "vehicle_color_name", "alarm_code_name").map(col) ++ alarm_cnt_cols: _*)
      .withColumn("total_alarm_cnt", lit(1))
      .groupBy("vehicle_no", "vehicle_color_name")
      .agg(alarm_total_cols.head, alarm_total_cols.tail: _*)
      .withColumn("inc_day", lit(month_last_day))
      .select(res_cols: _*)
    writeToHive(spark, month_cnt_df, Seq("inc_day"), "dm_gis.dwd_insurance_model_risk_alarm_month_dtl")
  }

  def processYearRiskAlarm(spark: SparkSession, inc_day: String): Unit = {
    val months_3_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -3) //3月前的月初日期
    val months_6_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -6)
    val months_12_ago = getFirstDayofMonthBeforeOrAfter(inc_day, -12)
    val last_month_day = getLastDayofMonthBeforeOrAfter(inc_day, 0) //上月底最后一天
    processMultiFeature(spark, months_3_ago, last_month_day, "3")
    processMultiFeature(spark, months_6_ago, last_month_day, "6")
    processMultiFeature(spark, months_12_ago, last_month_day, "12")
  }

  def processMultiFeature(spark: SparkSession, multi_month_day: String, last_month_day: String, months_flag: String): Unit = {
    import spark.implicits._
    val alarm_name_str = Seq("close_forward_cnt", "front_collision_cnt", "lane_depart_cnt", "lane_change_cnt", "over_speed_cnt", "timeout_cnt", "phy_fatigue_cnt", "no_looking_ahead_cnt", "phone_call_cnt", "play_phone_cnt", "smoking_cnt", "no_seat_belt_cnt", "off_hand_cnt", "outof_position_cnt", "equip_occ_fail_cnt", "susp_shield_singal_cnt")

    val sum_cols = ColumnUtil.renameColumn((alarm_name_str :+ "total_alarm_cnt").map(sum(_)), alarm_name_str :+ "total_alarm_cnt")
    val o_multi_month_df = spark.sql(
      s"""select * from dm_gis.dwd_insurance_model_risk_alarm_month_dtl
         |where inc_day between '$multi_month_day' and '$last_month_day'
         |      and vehicle_no is not null and trim(vehicle_no) !=''
         |""".stripMargin)
      .groupBy("vehicle_no", "vehicle_color_name")
      .agg(sum_cols.head, sum_cols.tail: _*)
      .withColumn("months_flag", lit(months_flag))
      .withColumn("inc_day", lit(last_month_day))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val alarm_prop_cols = propCols(alarm_name_str)

    //拼装最终表结构
    val res_cols = spark.sql("""select * from dm_gis.dwd_insurance_model_risk_alarm_feature_dtl limit 0""").schema.map(x => col(x.name))
    val p1_df = o_multi_month_df.select(o_multi_month_df.schema.map(_.name).map(col) ++ alarm_prop_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val p1_1_df = p1_df.select("vehicle_no", "vehicle_color_name", "inc_day", "months_flag", "total_alarm_cnt")
      .withColumn("num", row_number().over(Window.partitionBy("inc_day", "months_flag").orderBy(col("total_alarm_cnt").cast("int"))))
      .select("vehicle_no", "vehicle_color_name", "num")

    val p2_df = o_multi_month_df.select("total_alarm_cnt", "inc_day", "months_flag")
      .withColumn("cnt", lit(1))
      .groupBy("inc_day", "months_flag")
      .agg(
        sum("total_alarm_cnt") as "all_alarm_cnt",
        sum("cnt") as "total_cnt")

    val res_df = p1_df
      .join(broadcast(p1_1_df), Seq("vehicle_no", "vehicle_color_name"))
      .join(broadcast(p2_df), Seq("inc_day", "months_flag"))
      .withColumn("total_alarm_rank", 'num / 'total_cnt)
      .select(res_cols: _*)
    writeToHive(spark, res_df, Seq("inc_day", "months_flag"), "dm_gis.dwd_insurance_model_risk_alarm_feature_dtl")
    o_multi_month_df.unpersist()
    p1_df.unpersist()
  }

  def propCols(alarm_name_str: Seq[String]): Seq[Column] = {
    val prop_cond_cols = alarm_name_str.map(x => when(col("total_alarm_cnt") > 0, col(x) / col("total_alarm_cnt")).otherwise(0))
    val prop_cond_cols_str = alarm_name_str.map(_.replaceAll("_cnt", "_prop"))
    ColumnUtil.renameColumn(prop_cond_cols, prop_cond_cols_str)
  }
}
