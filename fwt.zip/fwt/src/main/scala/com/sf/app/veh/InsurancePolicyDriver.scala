package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{MS_PERDAY, getFirstDayofMonthBeforeOrAfter, getLastDayofMonthBeforeOrAfter, sdf_inc}
import utils.SparkBuilder

/**
 * @task_id: 574111
 * @description:承保理赔表 汇总表：insurance_policy_underwriting_claims_vehicle_dtl 明细表：insurance_policy_underwriting_claims
 * @demander: 01424465 张雪莹
 * @author 01418539 caojia
 * @date 2022/11/17 9:46
 */
object InsurancePolicyDriver extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processPolicy(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processPolicy(spark: SparkSession, start_day: String, end_day: String): Unit = {
    val months_3_ago = getFirstDayofMonthBeforeOrAfter(end_day, -3) //3月前的月初日期
    val months_6_ago = getFirstDayofMonthBeforeOrAfter(end_day, -6)
    val months_12_ago = getFirstDayofMonthBeforeOrAfter(end_day, -12)
    val last_month_day = getLastDayofMonthBeforeOrAfter(end_day, 0) //上月底最后一天
    monthsPeriodData(spark, months_3_ago, last_month_day, "3")
    monthsPeriodData(spark, months_6_ago, last_month_day, "6")
    monthsPeriodData(spark, months_12_ago, last_month_day, "12")
  }

  def monthsPeriodData(spark: SparkSession, start_month_day: String, last_month_day: String, months_flag: String): Unit = {
    import spark.implicits._
    //数据周期 近months_flag个月
    val o_policy_df = spark.sql(
      s"""select * from dm_gis.business_compulsory_insurance_policy_dtl
         |where inc_day between '$start_month_day' and '$last_month_day' and policy_no is not null and trim(policy_no) != ''""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("policy_no").orderBy(desc("modified_tm"))))
      .filter('num === 1).drop("inc_day", "num")
    val o_report_df = spark.sql(
      s"""select policy_no,claim_folder_no,report_case_no,reporter_name,reporter_mobile,report_dt,open_dt,closing_dt_lp,closing_dt_ba,diver,case_description,is_wounded,wounded_type,case_category,responsibility,survey_descrip,loss_event_place,loss_event_dt,case_status_lp,case_status_ba,claim_detail_status,underwriting_amount,estimated_loss_amount,accomm_expenses,whole_expenses,glass_no_premium,cnt_compensation,remarks,modified_tm
         |from dm_gis.report_claim_insurance_compensation_dtl
         |where inc_day between '$start_month_day' and '$last_month_day' and policy_no is not null and trim(policy_no) != ''""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("claim_folder_no").orderBy(desc("modified_tm"))))
      .filter('num === 1).drop("modified_tm", "num")
    val o_offline_policy_df = spark.sql("""select * from dm_gis.offline_policy_premium""")
    val o_offline_report_df = spark.sql("""select * from dm_gis.offline_report_case_no_dt""")

    //承保理赔表
    val report_claims_df = o_policy_df.join(o_report_df, Seq("policy_no"), "left")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val report_claims_cols = report_claims_df.schema.map(x => col(x.name))

    //1 修正 异常保费 数据
    val normal_premium_df = report_claims_df.filter('premium.cast("double") <= 50000).select(report_claims_cols: _*)
    val exe_premium_df = report_claims_df.filter('premium.cast("double") > 50000).drop("premium")
      .join(broadcast(o_offline_policy_df), Seq("policy_no"), "left").select(report_claims_cols: _*)
    val correct_premium_df = normal_premium_df.union(exe_premium_df).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val correct_premium_cols = correct_premium_df.schema.map(x => col(x.name))
    //2 修正 出险时间有缺失 数据
    val norm_loss_event_df = correct_premium_df.filter('loss_event_dt.isNotNull && trim('loss_event_dt) =!= "").select(correct_premium_cols: _*)
    val exe_loss_event_df = correct_premium_df.filter('loss_event_dt.isNull || trim('loss_event_dt) === "").drop("loss_event_dt")
      .join(broadcast(o_offline_report_df), Seq("report_case_no"), "left")
      .withColumn("loss_event_dt", concat(regexp_replace('loss_event_dt, "/", "-"), lit(" 00:00:00")))
      .select(correct_premium_cols: _*)
    val res_df_cols = spark.sql("""select * from dm_gis.insurance_policy_underwriting_claims limit 0""").schema.map(x => col(x.name))

    val fix_report_claims_df = norm_loss_event_df.union(exe_loss_event_df)
      .withColumn("pending_amount", when('estimated_loss_amount.cast("double") - 'underwriting_amount.cast("double") >= 0, 'estimated_loss_amount.cast("double") - 'underwriting_amount.cast("double")).otherwise(0))
      .withColumn("vehicle_code", regexp_replace('vehicle_code, "-|_", ""))
      .withColumn("reporter_mobile",lit(""))
      .withColumn("inc_day", lit(last_month_day))
      .withColumn("months_flag", lit(months_flag))
      .select(res_df_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    writeToHive(spark, fix_report_claims_df.coalesce(10), Seq("inc_day", "months_flag"), "dm_gis.insurance_policy_underwriting_claims")
    processQuota(spark, fix_report_claims_df, start_month_day)
    report_claims_df.unpersist()
    correct_premium_df.unpersist()
  }

  def processQuota(spark: SparkSession, org_df: DataFrame, start_month_day: String): Unit = {
    import spark.implicits._
    val months_df = org_df
      .withColumn("num", row_number().over(Window.partitionBy('vehicle_id, 'vehicle_code, 'vehicle_type, 'premium, 'start_dt, 'end_dt, 'type).orderBy(desc("modified_tm"))))
      .filter('num === 1)
      .withColumn("statis_start_day", lit(start_month_day))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val s1_df = months_df.select("vehicle_code", "start_dt", "end_dt", "statis_start_day", "inc_day")
      .groupBy("vehicle_code", "statis_start_day", "inc_day")
      .agg(
        min("start_dt") as "start_dt",
        max("end_dt") as "end_dt"
      )
      .withColumn("curr_risk_exposure", currEarnedPremiums('start_dt, 'end_dt, 'statis_start_day, 'inc_day))
      .select("vehicle_code", "curr_risk_exposure")

    val conbine_type = when('type_arr.contains("交强") && 'type_arr.contains("商业"), "交商共保")
      .when('type_arr.contains("交强") && !'type_arr.contains("商业"), "单交强")
      .when(!'type_arr.contains("交强") && 'type_arr.contains("商业"), "单商业")

    //loss_event_dt	2019-12-21 00:00:00
    val loss_event_dt_col = regexp_replace(substring('loss_event_dt, 1, 10), "-", "")
    val s2_1_df = months_df
      .withColumn("curr_earned_premiums", 'premium * currEarnedPremiums('start_dt, 'end_dt, 'statis_start_day, 'inc_day))
      .withColumn("curr_underwriting_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'underwriting_amount).otherwise(0))
      .withColumn("curr_estimated_loss_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'estimated_loss_amount).otherwise(0))
      .groupBy("vehicle_code", "vehicle_type", "vim_code", "statis_start_day", "inc_day", "months_flag")
      .agg(
        first('vehicle_id) as "vehicle_id",
        sum('curr_earned_premiums.cast("double")) as "curr_earned_premiums",
        concat_ws("|", collect_set('type)) as "type_arr"
      )
      .withColumn("conbine_type", conbine_type)

    val s2_2_df = org_df
      .withColumn("statis_start_day", lit(start_month_day))
      .withColumn("curr_underwriting_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'underwriting_amount).otherwise(0))
      .withColumn("curr_estimated_loss_amount", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day, 'estimated_loss_amount).otherwise(0))
      .groupBy("vehicle_code")
      .agg(
        sum('curr_underwriting_amount.cast("double")) as "curr_underwriting_amount",
        sum('curr_estimated_loss_amount.cast("double")) as "curr_estimated_loss_amount"
      )
      .withColumn("curr_pending_amount", when('curr_estimated_loss_amount.cast("double") - 'curr_underwriting_amount.cast("double") >= 0, 'curr_estimated_loss_amount.cast("double") - 'curr_underwriting_amount.cast("double")).otherwise(0))
      .select("vehicle_code", "curr_underwriting_amount", "curr_estimated_loss_amount", "curr_pending_amount")

    val accident_cols: Seq[Column] = Seq('vehicle_code, 'report_case_no, 'vim_code, 'start_dt, 'end_dt, 'loss_event_dt, 'case_status_lp, 'underwriting_amount, 'type, 'inc_day)
    val accident_df = org_df
      .select(accident_cols: _*).groupBy(accident_cols: _*).agg(lit("1") as "cos")
      .withColumn("statis_start_day", lit(start_month_day))
      .withColumn("curr_accidents_cnt", when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day && (('case_status_lp.isin("结案", "已结案") && 'underwriting_amount === 0) || 'case_status_lp.isin("拒赔", "注销")), 0)
        .when(loss_event_dt_col >= 'statis_start_day && loss_event_dt_col <= 'inc_day && !('case_status_lp.isin("结案", "已结案") && 'underwriting_amount === 0) && !'case_status_lp.isin("拒赔", "注销"), 1)
        .otherwise(0)) //去除：零结案定义为 case_status_lp 为结案/已结案&已决金额为0
      .groupBy("vehicle_code", "report_case_no")
      .agg(max('curr_accidents_cnt) as "curr_accidents_cnt")
      .groupBy("vehicle_code").agg(sum("curr_accidents_cnt") as "curr_accidents_cnt")

    val res_df_cols = spark.sql("""select * from dm_gis.insurance_policy_underwriting_claims_vehicle_dtl limit 0""").schema.map(x => col(x.name))
    val res_df = s2_1_df.join(s2_2_df, Seq("vehicle_code"), "left")
      .join(s1_df, Seq("vehicle_code"), "left")
      .join(broadcast(accident_df), Seq("vehicle_code"), "left")
      .withColumn("curr_comp_amount", 'curr_underwriting_amount.cast("double") + 'curr_pending_amount.cast("double"))
      .withColumn("occurr_freq", when('curr_risk_exposure > 0, 'curr_accidents_cnt / 'curr_risk_exposure).otherwise(0.0))
      .withColumn("ppcf_comp_amount", when('curr_accidents_cnt > 0, 'curr_comp_amount / 'curr_accidents_cnt).otherwise(0.0))
      .withColumn("claim_loss_ratio", when('curr_earned_premiums > 0, 'curr_comp_amount / 'curr_earned_premiums).otherwise(0.0))
      .select(res_df_cols: _*)

    writeToHive(spark, res_df, Seq("inc_day", "months_flag"), "dm_gis.insurance_policy_underwriting_claims_vehicle_dtl")
    months_df.unpersist()
    org_df.unpersist()
  }

  def currEarnedPremiums = udf((start_dt: String, end_dt: String, statis_start_day: String, inc_day: String) => {
    //已赚车年=([min(统计时间,保险结束日期) - max(统计起期,保险开始日期）]/365)
    val new_start_tm = start_dt.substring(0, 10).replaceAll("-", "")
    val new_end_tm = end_dt.substring(0, 10).replaceAll("-", "")
    val p1_tm = if (inc_day >= new_end_tm) new_end_tm else inc_day
    val p2_tm = if (statis_start_day >= new_start_tm) statis_start_day else new_start_tm
    val inter_day = if (daysBetweenDateActural(p1_tm, p2_tm).toDouble > 0) daysBetweenDateActural(p1_tm, p2_tm).toDouble else 0.0
    inter_day / 365
  })

  def daysBetweenDateActural(start_day: String, end_day: String): Int = {
    var day: Int = 0
    try {
      val start = sdf_inc.parse(start_day)
      val end = sdf_inc.parse(end_day)
      day = ((start.getTime - end.getTime) / MS_PERDAY).toInt //20220101-20220116  一起16天
    } catch {
      case e: Exception => logger.error("检查传入日期格式" + e.getMessage)
    }
    day
  }

}
