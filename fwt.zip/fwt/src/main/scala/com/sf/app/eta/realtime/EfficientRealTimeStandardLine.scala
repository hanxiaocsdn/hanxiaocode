package com.sf.app.eta.realtime

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}

import scala.collection.JavaConversions._
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id:
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2023/9/21 17:05
 */
object EfficientRealTimeStandardLine {
  val sim_url = "http://gis-apis.int.sfcloud.local:1080/lssrectify/api/comparetracks" //ak = "e640de2b47394b19862ee134d817bbc7"
  val standline_url = "http://gis-apis.int.sfcloud.local:1080/etaStdLine/queryByLineRequireId" //ak = "e0bdf942360b4bef8ef6fa425650a4c0"


  def run(org_json: JSONObject): JSONObject = {
    val response = org_json.getString("stdResponse")
    val carrier_type = org_json.getString("carrier_type")

    var res_json = new JSONObject(true)
    if (carrier_type == "0") res_json = parseStaLineRepZY(org_json, response)
    if (carrier_type != "0") res_json = parseStaLineRepWB(org_json, response)
    res_json
  }

  def parseStaLineRepZY(jo: JSONObject, response: String): JSONObject = {
    //上层轨迹接口拿到的数据
    val rt_coords = jo.getString("rt_coords")
    val task_subid_line_distance = jo.getDouble("task_subid_line_distance")
    val rt_dist = jo.getDouble("rt_dist")
    //自营（carrier_type = 0）车辆 标准线路接口返回的3条线路信息
    var tmpStdLineData, stdLineData, pnsLineData = new JSONObject()
    try {
      val resp = JSON.parseObject(response)
      val result = resp.getJSONObject("result")
      val linePassZoneInfoDtos = try {
        result.getJSONArray("linePassZoneInfoDtos").getJSONObject(0)
      } catch {
        case e: Exception => new JSONObject()
      }

      //1 潮汐线路
      try {
        tmpStdLineData = if (linePassZoneInfoDtos.getJSONObject("tmpStdLineData") != null) linePassZoneInfoDtos.getJSONObject("tmpStdLineData") else new JSONObject()
      } catch {
        case e: Exception => ""
      }
      //2 一条标准线路
      try {
        stdLineData = if (linePassZoneInfoDtos.getJSONObject("stdLineData") != null) linePassZoneInfoDtos.getJSONObject("stdLineData") else new JSONObject()
      } catch {
        case e: Exception => ""
      }
      //3 临时规划线路
      try {
        pnsLineData = if (linePassZoneInfoDtos.getJSONObject("pnsLineData") != null) linePassZoneInfoDtos.getJSONObject("pnsLineData") else new JSONObject()
      } catch {
        case e: Exception => ""
      }

      val cx_pns_dist = fixStrFill(tmpStdLineData.getDouble("pnsDist")) //todo 如果为null 默认值0 每条线路返回的字段，相似度判断
      val cx_pns_time = fixStrFill(tmpStdLineData.getString("pnsTime"))
      val cx_std_coords = fixStrFill(tmpStdLineData.getString("coords"))
      val cx_line_distance_std = fixStrFill(tmpStdLineData.getString("dist"))
      val cx_line_time_std = fixStrFill(tmpStdLineData.getString("time"))
      val cx_std_id = fixStrFill(linePassZoneInfoDtos.getString("stdId"))
      val cx_isEcon = fixStrFill(tmpStdLineData.getString("isEcon"))
      val cx_std_toll_charge = fixStrFill(tmpStdLineData.getString("tolls"))

      val (cx_conduct_type, cx_sim1, cx_sim5) = getConductType(rt_coords, cx_std_coords, rt_dist, cx_pns_dist, task_subid_line_distance)
      if (cx_conduct_type == 1) {
        val cx_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> cx_pns_dist, "pns_time" -> cx_pns_time, "src" -> cx_isEcon, "std_coords" -> cx_std_coords, "line_distance_std" -> cx_line_distance_std, "line_time_std" -> cx_line_time_std, "std_id" -> cx_std_id, "std_toll_charge" -> cx_std_toll_charge, "line_order" -> "1", "sim1_1" -> cx_sim1, "sim5_1" -> cx_sim5)
        jo.putAll(cx_javaMap)
      } else {
        //2 一条标准线路
        try {
          stdLineData = if (linePassZoneInfoDtos.getJSONObject("stdLineData") != null) linePassZoneInfoDtos.getJSONObject("stdLineData") else new JSONObject()
        } catch {
          case e: Exception => ""
        }
        val std_pns_dist = fixStrFill(stdLineData.getDouble("pnsDist")) //每条线路返回的字段，相似度判断
        val std_pns_time = fixStrFill(stdLineData.getString("pnsTime"))
        val std_std_coords = fixStrFill(stdLineData.getString("coords"))
        val std_line_distance_std = fixStrFill(stdLineData.getString("dist"))
        val std_line_time_std = fixStrFill(stdLineData.getString("time"))
        val std_std_id = fixStrFill(linePassZoneInfoDtos.getString("stdId"))
        val std_isEcon = fixStrFill(stdLineData.getString("isEcon"))
        val std_std_toll_charge = fixStrFill(stdLineData.getString("tolls"))

        val (std_conduct_type, std_sim1, std_sim5) = getConductType(rt_coords, std_std_coords, rt_dist, std_pns_dist, task_subid_line_distance)
        val default_std_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> std_pns_dist, "pns_time" -> std_pns_time, "src" -> std_isEcon, "std_coords" -> std_std_coords, "line_distance_std" -> std_line_distance_std, "line_time_std" -> std_line_time_std, "std_id" -> std_std_id, "std_toll_charge" -> std_std_toll_charge, "line_order" -> "2", "sim1_1" -> std_sim1, "sim5_1" -> std_sim5)
        jo.putAll(default_std_javaMap)

        if (std_conduct_type != 1) {
          //3 临时规划线路
          try {
            pnsLineData = if (linePassZoneInfoDtos.getJSONObject("pnsLineData") != null) linePassZoneInfoDtos.getJSONObject("pnsLineData") else new JSONObject()
          } catch {
            case e: Exception => ""
          }
          val ls_pns_dist = fixStrFill(pnsLineData.getDouble("dist")) //每条线路返回的字段，相似度判断
          val ls_pns_time = fixStrFill(pnsLineData.getString("time"))
          val ls_std_coords = fixStrFill(pnsLineData.getString("coords"))
          val ls_line_distance_std = fixStrFill(pnsLineData.getString("dist"))
          val ls_line_time_std = fixStrFill(pnsLineData.getString("time"))
          val ls_std_id = "-"
          val ls_isEcon = fixStrFill(pnsLineData.getString("srcPnsLine"))
          val ls_std_toll_charge = fixStrFill(pnsLineData.getString("tolls"))

          val (ls_conduct_type, ls_sim1, ls_sim5) = getConductType(rt_coords, ls_std_coords, rt_dist, ls_pns_dist, task_subid_line_distance)
          if (ls_conduct_type == 1) {
            val ls_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> ls_pns_dist, "pns_time" -> ls_pns_time, "src" -> ls_isEcon, "std_coords" -> ls_std_coords, "line_distance_std" -> ls_line_distance_std, "line_time_std" -> ls_line_time_std, "std_id" -> ls_std_id, "std_toll_charge" -> ls_std_toll_charge, "line_order" -> "3", "sim1_1" -> ls_sim1, "sim5_1" -> ls_sim5)
            jo.putAll(ls_javaMap)
          }
        }
      }
      val (line_type, line_id) = getLineTypeAndId(tmpStdLineData, stdLineData, pnsLineData)
      jo.put("line_type", line_type)
      jo.put("line_id", line_id)
    } catch {
      case e: Exception =>
        val blank_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> "-", "pns_time" -> "-", "src" -> "-", "std_coords" -> "-", "line_distance_std" -> "-", "line_time_std" -> "-", "std_id" -> "-", "std_toll_charge" -> "-", "line_type" -> "-", "line_id" -> "-", "line_order" -> "-", "sim1_1" -> "-", "sim5_1" -> "-")
        jo.putAll(blank_javaMap)
        if (e.toString.contains("轨迹点为空")) {
          jo.put("err", "轨迹点为空")
        } else {
          jo.put("err", e.toString + "++++" + response)
        }
    }
    jo
  }

  def parseStaLineRepWB(jo: JSONObject, response: String): JSONObject = {
    val rt_coords = jo.getString("rt_coords")
    val task_subid_line_distance = jo.getDouble("task_subid_line_distance")
    val rt_dist = jo.getDouble("rt_dist")
    //外包（carrier_type = 1）车辆 标准线路接口返回的3条线路信息
    var tmpStdLineData, pnsLineData = new JSONObject()
    var carrierStdLineDataList = new JSONArray()
    try {
      val resp = JSON.parseObject(response)
      val result = resp.getJSONObject("result")
      val linePassZoneInfoDtos = try {
        result.getJSONArray("linePassZoneInfoDtos").getJSONObject(0)
      } catch {
        case e: Exception => new JSONObject()
      }
      //1 潮汐线路
      try {
        tmpStdLineData = if (linePassZoneInfoDtos.getJSONObject("tmpStdLineData") != null) linePassZoneInfoDtos.getJSONObject("tmpStdLineData") else new JSONObject()
      } catch {
        case e: Exception => ""
      }
      //2 三条标准线路
      try {
        carrierStdLineDataList = if (linePassZoneInfoDtos.getJSONArray("carrierStdLineDataList") != null) linePassZoneInfoDtos.getJSONArray("carrierStdLineDataList") else new JSONArray()
      } catch {
        case e: Exception => ""
      }
      //3 临时规划线路
      try {
        pnsLineData = if (linePassZoneInfoDtos.getJSONObject("pnsLineData") != null) linePassZoneInfoDtos.getJSONObject("pnsLineData") else new JSONObject()
      } catch {
        case e: Exception => ""
      }
      val cx_pns_dist = fixStrFill(tmpStdLineData.getDouble("pnsDist")) //每条线路返回的字段，相似度判断
      val cx_pns_time = fixStrFill(tmpStdLineData.getString("pnsTime"))
      val cx_std_coords = fixStrFill(tmpStdLineData.getString("coords"))
      val cx_line_distance_std = fixStrFill(tmpStdLineData.getString("dist"))
      val cx_line_time_std = fixStrFill(tmpStdLineData.getString("time"))
      val cx_std_id = fixStrFill(linePassZoneInfoDtos.getString("stdId"))
      val cx_isEcon = fixStrFill(tmpStdLineData.getString("isEcon"))
      val cx_std_toll_charge = fixStrFill(tmpStdLineData.getString("tolls"))

      val (cx_conduct_type, cx_sim1, cx_sim5) = getConductType(rt_coords, cx_std_coords, rt_dist, cx_pns_dist, task_subid_line_distance)
      if (cx_conduct_type == 1) {
        val cx_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> cx_pns_dist, "pns_time" -> cx_pns_time, "src" -> cx_isEcon, "std_coords" -> cx_std_coords, "line_distance_std" -> cx_line_distance_std, "line_time_std" -> cx_line_time_std, "std_id" -> cx_std_id, "std_toll_charge" -> cx_std_toll_charge, "line_order" -> "1", "sim1_1" -> cx_sim1, "sim5_1" -> cx_sim5)
        jo.putAll(cx_javaMap)
      } else {
        //2 三条标准线路
        try {
          carrierStdLineDataList = if (linePassZoneInfoDtos.getJSONArray("carrierStdLineDataList") != null) linePassZoneInfoDtos.getJSONArray("carrierStdLineDataList") else new JSONArray()
        } catch {
          case e: Exception => ""
        }
        var car_pns_dist, car_pns_time, car_std_coords, car_line_distance_std, car_line_time_std, car_std_id, car_isEcon, car_std_toll_charge = "-"
        if (carrierStdLineDataList != null && carrierStdLineDataList.size() > 0) {
          breakable {
            for (i <- 0 until carrierStdLineDataList.size()) {
              val first_stdLineData = carrierStdLineDataList.getJSONObject(i)
              car_pns_dist = fixStrFill(first_stdLineData.getDouble("pnsDist")) //每条线路返回的字段，相似度判断
              car_pns_time = fixStrFill(first_stdLineData.getString("pnsTime"))
              car_std_coords = fixStrFill(first_stdLineData.getString("coords"))
              car_line_distance_std = fixStrFill(first_stdLineData.getString("dist"))
              car_line_time_std = fixStrFill(first_stdLineData.getString("time"))
              car_std_id = fixStrFill(linePassZoneInfoDtos.getString("stdId"))
              car_isEcon = fixStrFill(first_stdLineData.getString("isEcon"))
              car_std_toll_charge = fixStrFill(first_stdLineData.getString("tolls"))
              if (i == 0) {
                val (car_conduct_type, car_sim1, car_sim5) = getConductType(rt_coords, car_std_coords, rt_dist, car_pns_dist, task_subid_line_distance)
                val default_std_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> car_pns_dist, "pns_time" -> car_pns_time, "src" -> car_isEcon, "std_coords" -> car_std_coords, "line_distance_std" -> car_line_distance_std, "line_time_std" -> car_line_time_std, "std_id" -> car_std_id, "std_toll_charge" -> car_std_toll_charge, "line_order" -> "2", "sim1_1" -> car_sim1, "sim5_1" -> car_sim5)
                jo.putAll(default_std_javaMap)
                if (car_conduct_type == 1) break()
              } else {
                val (rest_car_conduct_type, rest_car_sim1, rest_car_sim5) = getConductType(rt_coords, car_std_coords, rt_dist, car_pns_dist, task_subid_line_distance)
                if (rest_car_conduct_type == 1) {
                  val default_std_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> car_pns_dist, "pns_time" -> car_pns_time, "src" -> car_isEcon, "std_coords" -> car_std_coords, "line_distance_std" -> car_line_distance_std, "line_time_std" -> car_line_time_std, "std_id" -> car_std_id, "std_toll_charge" -> car_std_toll_charge, "line_order" -> (i + 2).toString, "sim1_1" -> rest_car_sim1, "sim5_1" -> rest_car_sim5)
                  jo.putAll(default_std_javaMap)
                  break()
                }
              }
            }
          }
        } else {
          val blank_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> "-", "pns_time" -> "-", "src" -> "-", "std_coords" -> "-", "line_distance_std" -> "-", "line_time_std" -> "-", "std_id" -> "-", "std_toll_charge" -> "-", "line_type" -> "-", "line_id" -> "-", "line_order" -> "2", "sim1_1" -> "-", "sim5_1" -> "-")
          jo.putAll(blank_javaMap)
          //3 临时规划线路
          try {
            pnsLineData = if (linePassZoneInfoDtos.getJSONObject("pnsLineData") != null) linePassZoneInfoDtos.getJSONObject("pnsLineData") else new JSONObject()
          } catch {
            case e: Exception => ""
          }
          val ls_pns_dist = fixStrFill(pnsLineData.getDouble("dist")) //每条线路返回的字段，相似度判断
          val ls_pns_time = fixStrFill(pnsLineData.getString("time"))
          val ls_std_coords = fixStrFill(pnsLineData.getString("coords"))
          val ls_line_distance_std = fixStrFill(pnsLineData.getString("dist"))
          val ls_line_time_std = fixStrFill(pnsLineData.getString("time"))
          val ls_std_id = "-"
          val ls_isEcon = fixStrFill(pnsLineData.getString("srcPnsLine"))
          val ls_std_toll_charge = fixStrFill(pnsLineData.getString("tolls"))
          val (ls_conduct_type, ls_sim1, ls_sim5) = getConductType(rt_coords, ls_std_coords, rt_dist, ls_pns_dist, task_subid_line_distance)
          if (ls_conduct_type == 1) {
            val ls_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> ls_pns_dist, "pns_time" -> ls_pns_time, "src" -> ls_isEcon, "std_coords" -> ls_std_coords, "line_distance_std" -> ls_line_distance_std, "line_time_std" -> ls_line_time_std, "std_id" -> ls_std_id, "std_toll_charge" -> ls_std_toll_charge, "line_order" -> "5", "sim1_1" -> ls_sim1, "sim5_1" -> ls_sim5)
            jo.putAll(ls_javaMap)
          }
        }
      }
      val (line_type, line_id) = getLineTypeAndIdWB(tmpStdLineData, carrierStdLineDataList, pnsLineData)
      jo.put("line_type", line_type)
      jo.put("line_id", line_id)
    } catch {
      case e: Exception =>
        val blank_javaMap: java.util.Map[String, Any] = Map("pns_dist" -> "-", "pns_time" -> "-", "src" -> "-", "std_coords" -> "-", "line_distance_std" -> "-", "line_time_std" -> "-", "std_id" -> "-", "std_toll_charge" -> "-", "line_type" -> "-", "line_id" -> "-", "line_order" -> "-", "sim1_1" -> "-", "sim5_1" -> "-")
        jo.putAll(blank_javaMap)
        if (e.toString.contains("轨迹点为空")) {
          jo.put("err", "轨迹点为空")
        } else {
          jo.put("err", e.toString + "++++" + response)
        }
    }
    jo
  }

  def getConductType(rt_coords: String, other_coords: String, rt_dist: Double, other_dist: String, task_subid_line_distance: Double): (Int, Double, Double) = {
    val fix_pns_dist = if (other_dist.trim != "-") other_dist.toDouble else 0.0
    var conduct_type = 3
    var sim1, sim5 = 0.0
    if (strNotNull(rt_coords) && strNotNull(other_coords)) {
      sim1 = schedulerSimilarityInterface(rt_coords, other_coords)._1
      sim5 = schedulerSimilarityInterface(rt_coords, other_coords)._2
      conduct_type = parseTaskRep(task_subid_line_distance, fix_pns_dist, rt_dist, sim1, sim5)
    }
    (conduct_type, sim1, sim5)
  }

  /**
   * 自营车辆 3类羡慕JSONObject判断
   *
   * @param type1
   * @param type2
   * @param type3
   * @param std_id
   * @return
   */
  def getLineTypeAndId(type1: Any, type2: Any, type3: Any): (String, String) = {
    val cx_line_type_arr, cx_line_id_arr = new ArrayBuffer[String]()
    if (jsonNotNull(type1)) {
      cx_line_type_arr += "tmpStdLineData"
      cx_line_id_arr += (if (strNotNull(type1.asInstanceOf[JSONObject].getString("stdId"))) type1.asInstanceOf[JSONObject].getString("stdId") else "-")
    } else {
      cx_line_type_arr += "-"
      cx_line_id_arr += "-"
    }
    if (jsonNotNull(type2)) {
      cx_line_type_arr += "stdLineData"
      cx_line_id_arr += (if (strNotNull(type2.asInstanceOf[JSONObject].getString("stdId"))) type2.asInstanceOf[JSONObject].getString("stdId") else "-")
    } else {
      cx_line_type_arr += "-"
      cx_line_id_arr += "-"
    }
    if (jsonNotNull(type3)) {
      cx_line_type_arr += "pnsLineData"
      cx_line_id_arr += "-"
    } else {
      cx_line_type_arr += "-"
      cx_line_id_arr += "-"
    }
    val line_type = cx_line_type_arr.mkString("&")
    val line_id = cx_line_id_arr.mkString("&")
    (line_type, line_id)
  }

  /**
   * 外包车辆 5类羡慕JSONObject判断
   *
   * @param type1
   * @param type2
   * @param type3
   * @param std_id
   * @return
   */
  def getLineTypeAndIdWB(type1: Any, type2: Any, type3: Any): (String, String) = {
    val cx_line_type_arr, cx_line_id_arr = new ArrayBuffer[String]()
    if (jsonNotNull(type1)) {
      cx_line_type_arr += "tmpStdLineData"
      cx_line_id_arr += (if (strNotNull(type1.asInstanceOf[JSONObject].getString("stdId"))) type1.asInstanceOf[JSONObject].getString("stdId") else "-")
    } else {
      cx_line_type_arr += "-"
      cx_line_id_arr += "-"
    }
    if (jsonNotNull(type2)) {
      val fix_type2 = type2.asInstanceOf[JSONArray]
      for (i <- 0 until 3) {
        val flag =
          if (i + 1 > fix_type2.size()) {
            false
          } else {
            try {
              fix_type2.getJSONObject(i) != null
            } catch {
              case e: Exception => false
            }
          }
        if (flag) {
          cx_line_type_arr += "carrierStdLineDataList"
          cx_line_id_arr += (if (strNotNull(fix_type2.getJSONObject(i).getString("stdId"))) fix_type2.getJSONObject(i).getString("stdId") else "-")
        } else {
          cx_line_type_arr += "-"
          cx_line_id_arr += "-"
        }
      }
    } else {
      cx_line_type_arr += "-&-&-"
      cx_line_id_arr += "-&-&-"
    }
    if (jsonNotNull(type3)) {
      cx_line_type_arr += "pnsLineData"
      cx_line_id_arr += "-"
    } else {
      cx_line_type_arr += "-"
      cx_line_id_arr += "-"
    }
    val line_type = cx_line_type_arr.mkString("&")
    val line_id = cx_line_id_arr.mkString("&")
    (line_type, line_id)
  }

  /**
   * @note 子任务维度执行标签，rt_dist为历史轨迹输入，对比轨迹为rt_coords,is_navi问静文要不要判断， line_distance 是否为 task_subid_line_distance
   */

  def parseTaskRep(line_distance: Double, pns_dist: Double, rt_dist: Double, sim1: Double, sim5: Double) = {
    // TODO: 20220926新增  1执行 3不执行
    val conduct_type = line_distance match {
      case line_distance if (line_distance <= 5 && ((pns_dist <= 5000 && rt_dist <= 5000) || Math.abs(rt_dist - pns_dist) <= 2000 || (pns_dist <= 10000 && Math.max(sim1, sim5) > 0.5 && Math.min(sim1, sim5) >= 0.4) || (pns_dist > 10000 && Math.max(sim1, sim5) > 0.6 && Math.min(sim1, sim5) >= 0.5) || pns_dist <= 1000 || Math.max(sim1, sim5) >= 0.9)) => 1
      case line_distance if (line_distance > 5 && line_distance <= 10 && ((Math.max(sim1, sim5) >= 0.6 && Math.min(sim1, sim5) >= 0.5) || Math.max(sim1, sim5) >= 0.9)) => 1
      case line_distance if (line_distance > 10 && line_distance <= 50 && Math.max(sim1, sim5) > 0.75 && Math.min(sim1, sim5) >= 0.7) => 1
      case line_distance if (line_distance > 50 && line_distance <= 100 && Math.max(sim1, sim5) > 0.8 && Math.min(sim1, sim5) >= 0.75) => 1
      case line_distance if (line_distance > 100 && line_distance <= 500 && Math.max(sim1, sim5) > 0.85 && Math.min(sim1, sim5) >= 0.8) => 1
      case line_distance if (line_distance > 500 && Math.max(sim1, sim5) > 0.9 && Math.min(sim1, sim5) >= 0.85) => 1
      case line_distance if ((pns_dist <= 5000 && rt_dist <= 5000 && rt_dist != 0) || pns_dist == 0 || (pns_dist <= 10000 && Math.abs(rt_dist - pns_dist) <= 2000 && rt_dist != 0) ||
        ((rt_dist != 0 && Math.abs(rt_dist - pns_dist) <= 5000 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000)))
          || (rt_dist != 0 && Math.abs(rt_dist - pns_dist) / rt_dist <= 0.05 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000))))) => 1
      case _ => 3
    }
    conduct_type
  }


  def fixStrFill(str: Any): String = {
    if (strNotNull(str)) str.toString else "-"
  }

  /**
   * 对给定的字符串 进行空值判断
   *
   * @param col列字段
   * @return 列类型
   */
  def jsonNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case "null" => false
      case x if x.isInstanceOf[JSONObject] => !x.asInstanceOf[JSONObject].isEmpty
      case x if x.isInstanceOf[JSONArray] => x.asInstanceOf[JSONArray] != null && x.asInstanceOf[JSONArray].size() > 0
      case _ => !str.toString.isEmpty && str.toString.trim != ""
    }
  }

  /**
   * 对给定的字符串 进行空值判断
   *
   * @param col列字段
   * @return 列类型
   */
  def strNotNull(str: Any): Boolean = {
    str match {
      case null => false
      case "null" => false
      case _ => !str.toString.isEmpty && str.toString.replaceAll("-|\\[|\\]", "").trim != ""
    }
  }

  //-----未修改------------------
  def parseStaLineRep(response: String) = {
    val jo = new JSONObject()
    try {
      val resp = JSON.parseObject(response)
      val result = resp.getJSONObject("result")
      val linePassZoneInfoDtos = try {
        result.getJSONArray("linePassZoneInfoDtos").getJSONObject(0)
      } catch {
        case e: Exception => new JSONObject()
      }
      val stdLineData = try {
        linePassZoneInfoDtos.getJSONObject("stdLineData")
      } catch {
        case e: Exception => new JSONObject()
      }
      val pns_dist = stdLineData.getString("pnsDist")
      val pns_time = stdLineData.getString("pnsTime")
      val std_coords = stdLineData.getString("coords")
      val line_distance_std = stdLineData.getString("dist")
      val line_time_std = stdLineData.getString("time")

      //20211011增加统计字段
      val std_id = linePassZoneInfoDtos.getString("stdId")

      val isEcon = stdLineData.getString("isEcon")

      //20211118增加统计字段std_toll_charge
      val std_toll_charge = stdLineData.getString("tolls")

      jo.put("pns_dist", pns_dist)
      jo.put("pns_time", pns_time)
      jo.put("src", isEcon)
      jo.put("std_coords", std_coords)
      jo.put("line_distance_std", line_distance_std)
      jo.put("line_time_std", line_time_std)

      jo.put("std_id", std_id)
      jo.put("std_toll_charge", std_toll_charge)

    } catch {
      case e: Exception =>
        if (e.toString.contains("轨迹点为空")) {
          jo.put("err", "轨迹点为空")
        } else {
          jo.put("err", e.toString + "++++" + response)
        }
    }
    jo
  }

  def schedulerSimilarityInterface(rt_coords: String, std_coords: String) = {

    var sim1 = 0.0
    var sim5 = 0.0
    //        if (StringUtilsScala.nonEmpty(rt_coords) && StringUtilsScala.nonEmpty(std_coords)) {
    if (true) {

      //      val joArray1 = new JSONArray()
      //      val array1 = try { JSON.parseArray(rt_coords)} catch {case e:Exception => new JSONArray()}

      //      for (i <- 0 until (array1.size())) {
      //        val json = array1.getJSONObject(i)
      //        val x = json.getDouble("dx")
      //        val y = json.getDouble("dy")
      //        val arrayNew = new JSONArray()
      //        arrayNew.add(x)
      //        arrayNew.add(y)
      //        joArray1.add(arrayNew)
      //      }
      val joArray1 = try {
        JSON.parseArray(rt_coords)
      } catch {
        case e: Exception => new JSONArray()
      }
      val joArray2 = try {
        JSON.parseArray(std_coords)
      } catch {
        case e: Exception => new JSONArray()
      }


      val jo1 = new JSONObject()
      val jo2 = new JSONObject()

      jo1.put("rt_coords", joArray1)
      jo1.put("vehicle_type", "5")
      jo2.put("rt_coords", joArray2)

      var errLog = ""

      try {
        val sim = getSimilarInterface2.getSimilar2(jo1, jo2)
        sim1 = sim._1
        sim5 = sim._2
        //        val sim = PathSimilar.simProcess(jo1, jo2)
        //        //      val (sim1New,sim5New) = try{PathSimilar.simProcess(jo1,jo2)} catch {case e:Exception => (0.0,0.0)}
        //        sim1 = sim.first
        //        sim5 = sim.second
      } catch {
        case e: Exception => {
          errLog = e.getMessage
        }
      }

    }
    (sim1, sim5)

  }

}
