package com.sf.app.eta.realtime;/*
 @author 01401062
 @DESCRIPTION 
 @create 2023/4/11
*/
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
public class ExprCost {

    public String swid_exp;
    public String swid_len_exp;
    public String speed_exp;
    public String disu_duration_exp;
    public String disu_duration_subob;

}
