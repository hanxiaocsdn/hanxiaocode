package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions.{col, lit}
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import utils.JDBCUtils.{getSCMDevMysqlConnect, queryTablesInMysql}
import utils.SparkBuilder

import java.time.LocalTime

/**
 * @task_id: 826523
 * @description: 十一节假日数据表 plan.holiday_line_event mysql数据同步不用打所有依赖
 * @demander: 邵一馨  01408890
 * @author 01418539 caojia
 * @date 2023/9/18 17:53
 */
object LoadEtaHolidayLineEventFromMysql2Hive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val flag = args(1)
    val mysql_tn = Seq("holiday_line_event")
    for (mysqlTN <- mysql_tn) {
      run(spark, mysqlTN, inc_day, flag)
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, mysqlTN: String, inc_day: String, flag: String): Unit = {
    val conn_mysql = getSCMDevMysqlConnect()
    if (flag == "0") queryTablesInMysql(conn_mysql, "plan", mysqlTN)
    if (flag != "0") loadEfficientMysqlToHive(spark, mysqlTN, inc_day)
  }

  /**
   * 读取mysql表中的数据写入hive表中
   *
   * @param spark
   * @param mysqlTable
   * @param hiveTable
   */
  def loadEfficientMysqlToHive(spark: SparkSession, mysql_tn: String, inc_day: String): Unit = {
    val hive_table_struct: String = spark.sql(s"select * from dm_gis.$mysql_tn limit 0").schema.toList.map(_.name).filter(_ != "update_time").mkString(",")
    val res_cols: Seq[Column] = spark.sql(s"select * from dm_gis.$mysql_tn limit 0").schema.map(_.name).map(col)

    val query_state = getQueryState(mysql_tn, hive_table_struct, inc_day)
    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://plan-m.db.sfcloud.local:3306/plan?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai",
      "user" -> "plan",
      "password" -> "plan20210121#",
      "dbtable" -> query_state)

    val current_hour = LocalTime.now().getHour
    val update_time = inc_day + " " + current_hour + ":00"

    try {
      val df: DataFrame = spark.read.format("jdbc").options(params).load()
        .withColumn("update_time", lit(update_time))
        .select(res_cols: _*)
      df.show(2)
      logger.error("获取的mysql中数据总量为：" + df.count())
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        writeToHiveNoP(spark, df.coalesce(2), mysql_tn)
      } else {
        throw new Exception(s"mysql的 $mysql_tn 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $mysql_tn 中 插入数据时出现错误", ex)
        throw ex
    }
  }

  def getQueryState(mysql_tn: String, hive_table_struct: String, inc_day: String): String = {
    val query_state = s"""(select $hive_table_struct from $mysql_tn) as tmp"""
    logger.error("运行日期为:" + inc_day)
    logger.error("mysql中的查询语句：" + query_state)
    query_state
  }
}
