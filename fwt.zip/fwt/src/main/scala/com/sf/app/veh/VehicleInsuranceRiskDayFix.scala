package com.sf.app.veh

import com.sf.app.veh.VehicleInsuranceRiskDayFixNew.processFixDayNew
import com.sf.app.veh.VehicleInsuranceRiskDayFixOld.processFixDayOld
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.SparkBuilder

/**
 * @description: 车辆保险 日结表 异常修复 449514 (前置任务id:441364)
 * @author 01418539 caojia
 * @date 2022/6/17 10:36
 */
object VehicleInsuranceRiskDayFix extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    processMerge(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processMerge(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val full_df = rmExcpData(spark, start_day, end_day)
    //    val full_df = spark.sql(s"""select * from dm_gis.org_first_part_insurance_daily where inc_day >= '$start_day' and inc_day <= '$end_day'""")
    val o_df = full_df.filter('on_flag === "old").repartition(300, 'lpn, 'inc_day)
    val n_df = full_df.filter('on_flag === "new").repartition(300, 'lpn, 'inc_day)
    val old_df = processFixDayOld(spark, o_df)
    val new_df = processFixDayNew(spark, n_df)
    //    val old_df = spark.sql(s"""select * from dm_gis.old_org_first_part_insurance_daily where inc_day >= '$start_day' and inc_day <= '$end_day'""")
    //    val new_df = spark.sql(s"""select * from dm_gis.new_org_first_part_insurance_daily where inc_day >= '$start_day' and inc_day <= '$end_day'""")
    val mrg_df = new_df.union(old_df).drop("on_flag")
    writeToHive(spark, mrg_df.coalesce(10), Seq("inc_day", "ak"), "dm_gis.insurance_model_duration_dist_daily_fix")
    full_df.unpersist()
    old_df.unpersist()
    new_df.unpersist()
  }

  def rmExcpData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    import spark.implicits._
    val replNull_cols = Seq("drive_duration_array", "adcode_map", "adcode_dist_map", "adcode_duration_map", "sc_table", "ak",
      "total_links_dist", "total_links_duration", "high_speed_duration", "state_road_duration", "provincial_duration", "county_duration", "township_duration")

    val o_day_df = spark.sql(
      s"""select * from dm_gis.insurance_model_duration_dist_daily where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .withColumn("lpn", when(trim('lpn) === "" || 'lpn.isNull, 'un).otherwise('lpn))
      .withColumn("ak", when(trim('ak) === "-", "0").otherwise('ak))
      .withColumn("lpn_inc_day", concat_ws("_", 'lpn, 'inc_day))
      .na.fill("", replNull_cols)
      .na.fill("0")
      .withColumn("on_flag", oldOrNewDistinguish('total_links_dist, 'total_links_duration, 'high_speed_duration, 'state_road_duration,
        'provincial_duration, 'county_duration, 'township_duration))
      .repartition(600, 'lpn, 'inc_day)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    val org_cols = o_day_df.schema.map(_.name).filter(_ != "lpn_inc_day").map(col)
    o_day_df.createTempView("o_day_df")

    //需要修正的部分逻辑
    val fixp_df = spark.sql(
      """
        |select lpn,inc_day,lpn_inc_day,count(1) as cnt from o_day_df
        |where lpn is not null and trim(lpn) != '' group by lpn,inc_day,lpn_inc_day having cnt >= 2
        |""".stripMargin)

    val fix_lpn_inc_day = getOnlyCols(spark, fixp_df)

    var fixp_df_1 = spark.sql("""select lpn,ak,total_links_dist,lpn_inc_day,1 dist_ex,inc_day,1 num from o_day_df limit 0""")
    //1.1 增加 异常里程标
    if (fixp_df.head(1).size > 0) {
      fixp_df_1 = spark.sql(
        s"""
           |select lpn,ak,
           |       total_links_dist,
           |       lpn_inc_day,
           |       if(cast(total_links_dist as double) > 2400000,1,0) dist_ex,--异常 1 正常 0
           |       inc_day
           |from o_day_df
           |where lpn_inc_day in ($fix_lpn_inc_day)
           |""".stripMargin)
        .withColumn("total_links_dist", when('total_links_dist.isNull || trim('total_links_dist) === "", lit(0.0)).otherwise('total_links_dist.cast("double")))
        .withColumn("num", row_number().over(Window.partitionBy("lpn_inc_day").orderBy(col("total_links_dist").cast("double").asc)))
    }

    fixp_df_1.createTempView("fixp_df_1")

    //1.2 异常里程判断 同个车牌  剩下的 0 1 >=2 三类数据
    val fixp_df_2 = fixp_df_1.groupBy("lpn_inc_day")
      .agg(
        max("num") as "num_max",
        sum("dist_ex") as "dist_ex_sum"
      )

    val pub_cols = Seq(col("lpn"), col("ak"), col("total_links_dist"), col("lpn_inc_day"), col("inc_day"))

    //均异常  用字段 dist_ex1_sum 异常过滤后 = 0
    val t0_lpn_inc_day_df: DataFrame = fixp_df_2.filter('num_max - 'dist_ex_sum === 0)
    //有1天异常 用字段 dist_ex2_sum 异常过滤后 = 1
    val t1_lpn_inc_day_df: DataFrame = fixp_df_2.filter('num_max - 'dist_ex_sum === 1)
    //有2天及以上异常 异常过滤后 >= 2
    val t2_lpn_inc_day_df: DataFrame = fixp_df_2.filter('num_max - 'dist_ex_sum >= 2)

    var t0_df, t1_df, t2_df1_last, t2_df2_last = spark.sql("select lpn,ak,total_links_dist,lpn_inc_day,inc_day from fixp_df_1 limit 0").select(pub_cols: _*)

    if (t0_lpn_inc_day_df.head(1).size > 0) {
      val t0_lpn_inc_day = getOnlyCols(spark, t0_lpn_inc_day_df)
      //过滤完后有0条正常数据，取距离较小
      t0_df = spark.sql(
        s"""select lpn,ak,total_links_dist,lpn_inc_day,inc_day from fixp_df_1 where lpn_inc_day in ($t0_lpn_inc_day) """.stripMargin)
        .withColumn("cnt_0", row_number().over(Window.partitionBy("lpn_inc_day").orderBy('total_links_dist)))
        .filter('cnt_0 === 1)
        .select(pub_cols: _*)
    }

    if (t1_lpn_inc_day_df.head(1).size > 0) {
      val t1_lpn_inc_day = getOnlyCols(spark, t1_lpn_inc_day_df)
      //过滤完后只有1条正常数据
      t1_df = spark.sql(
        s"""select lpn,ak,total_links_dist,lpn_inc_day,inc_day from fixp_df_1
           |where lpn_inc_day in ($t1_lpn_inc_day)
           |      and num = 1
           |""".stripMargin)
        .select(pub_cols: _*)
    }
    if (t2_lpn_inc_day_df.head(1).size > 0) {
      val t2_lpn_inc_day = getOnlyCols(spark, t2_lpn_inc_day_df)
      //过滤完后只有1条正常数据
      //过滤完后有 》=2 条正常数据
      val t2_df_t1 = spark.sql(
        s"""select lpn,ak,total_links_dist,lpn_inc_day,inc_day from fixp_df_1
           |where lpn_inc_day in ($t2_lpn_inc_day)
           |      and dist_ex != 1
           |""".stripMargin)
        .withColumn("num", row_number().over(Window.partitionBy("lpn_inc_day").orderBy('total_links_dist)))
      val t2_df_t2 = t2_df_t1.groupBy("lpn_inc_day").agg(
        max("num") as "max_num",
        max("total_links_dist") as "max_dist",
        min("total_links_dist") as "min_dist"
      )
      val t2_df = t2_df_t1.join(t2_df_t2, Seq("lpn_inc_day"))
        .withColumn("ex_ratio", when('max_dist =!= 0, ('max_dist - 'min_dist) / 'max_dist).otherwise(0))
      //>=0.1的数据
      t2_df1_last = t2_df.filter('ex_ratio >= 0.1)
        .withColumn("flag_1", when('num === 'max_num, true).otherwise(false))
        .filter('flag_1 === true)
        .select(pub_cols: _*)
      //<0.1的数据
      val t2_df2 = t2_df.filter('ex_ratio < 0.1).select(pub_cols: _*)

      val t2_mid_df = t2_df2.groupBy("lpn_inc_day").agg(concat_ws(",", collect_set("ak")) as "ak_all")
        .withColumn("ak", getOnlyAK('ak_all))

      t2_df2_last = t2_df2.join(broadcast(t2_mid_df), Seq("lpn_inc_day", "ak"))
        .withColumn("num", row_number().over(Window.partitionBy("lpn_inc_day").orderBy('total_links_dist.desc)))
        .filter('num === 1)
        .select(pub_cols: _*)
    }

    val fix_df = t0_df.union(t1_df).union(t2_df1_last).union(t2_df2_last).toDF()
    val fix_part_lpn = getOnlyCols(spark, fix_df)

    var org_not_in_df = spark.sql(s"""select * from o_day_df limit 0""").select(org_cols: _*)
    var org_in_df = spark.sql(s"""select * from o_day_df limit 0""")
    if (fix_df.head(1).size > 0) {
      org_not_in_df = spark.sql(s"""select * from o_day_df where lpn_inc_day not in ($fix_part_lpn)""")
        .select(org_cols: _*)
      org_in_df = spark.sql(s"""select * from o_day_df where lpn_inc_day in ($fix_part_lpn)""")
    } else {
      org_not_in_df = spark.sql(s"""select * from o_day_df""")
        .select(org_cols: _*)
    }

    val in_df = org_in_df
      .join(fix_df, Seq("lpn", "ak", "total_links_dist", "lpn_inc_day", "inc_day"))
      .withColumn("num", row_number().over(Window.partitionBy("lpn_inc_day", "ak").orderBy('total_links_dist.desc)))
      .filter('num === 1)
      .select(org_cols: _*)

    val res_cols = spark.sql("""select * from dm_gis.org_first_part_insurance_daily limit 0""").schema.map(_.name).map(col)
    val res = org_not_in_df.union(in_df).select(res_cols: _*).coalesce(200).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    writeToHive(spark, res, Seq("inc_day", "ak"), "dm_gis.org_first_part_insurance_daily")
    res
  }

  def oldOrNewDistinguish = udf((c1: String, c2: String, c3: String, c4: String, c5: String, c6: String, c7: String) => {
    var flag = "new"
    try {
      if (c1.trim == "" && c2.trim == "" && c3.trim == "" && c4.trim == "" && c5.trim == "" && c6.trim == "" && c7.trim == "") {
        flag = "old"
      }
    } catch {
      case e: Exception => logger.error("共同判断的7个字段，有异常" + e.getMessage + e.printStackTrace())
    }
    flag
  })

  def getOnlyAK = udf((ak_all: String) => {
    var ak_only = 0
    try {
      if (!ak_all.isEmpty && ak_all.trim != "") {
        val ak_arr: Array[Int] = ak_all.replaceAll("\\[|\\]", "").split(",").map(_.toInt).sortWith((x1, x2) => x1 <= x2)
        val max_ak_ge300 = if (ak_arr.size > 0) ak_arr.max else 0
        val max_ak_le300 = if (ak_arr.filter(_ < 300).size > 0) ak_arr.filter(_ < 300).max else 301

        val c1 = ak_arr.filter(x => {
          x != 314 && x != 324
        })

        val c2 = ak_arr.filter(x => {
          x == 314 || x == 324
        })

        if (max_ak_ge300 >= 300 && c1.size > 0) {
          ak_only = c1.max
        }
        if (max_ak_ge300 >= 300 && c1.size == 0 && c2.size == 1) {
          ak_only = c2.max
        }
        if (max_ak_ge300 >= 300 && c1.size == 0 && c2.size == 2) {
          ak_only = 314
        }
        if (max_ak_ge300 < 300) {
          ak_only = max_ak_le300
        }
      }
    }
    catch {
      case e: Exception => logger.error("多个ak求取优先级时异常" + e.getMessage + e.printStackTrace())
    }
    ak_only.toString
  })

  def getOnlyCols(spark: SparkSession, df: DataFrame): String = {
    import spark.implicits._
    df.select("lpn_inc_day").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "")
  }
}