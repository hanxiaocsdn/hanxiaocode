package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.JDBCUtils.{getOMCSDevMysqlConnect, loadMysqlTableToHive, queryTablesInMysql}
import utils.{ConfigUtils, SparkBuilder}

/**
 * @task_id: 459601 (下线20231101)
 * @description:将数据库中的表抽至bdp平台的hive中 tt_rs_vehicle_common_cfg
 * @author 01418539 caojia
 * @date 2022/7/19 下午2:53
 */
object LoadSingleTableToHive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val mysqlTN = args(0)
    val flag = args(1)
    processQuery(spark, mysqlTN, flag)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processQuery(spark: SparkSession, mysqlTN: String, flag: String): Unit = {
    val url = ConfigUtils.readConfig().getProperty("eta_index.url")
    val driver = ConfigUtils.readConfig().getProperty("eta_index.driver")
    val username = ConfigUtils.readConfig().getProperty("eta_index.username")
    val password = ConfigUtils.readConfig().getProperty("eta_index.password")

    val params = Map(
      "url" -> "jdbc:mysql://OMCS-M.db.sfdc.com.cn:3306/omcs?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai",
      "driver" -> "com.mysql.jdbc.Driver",
      "user" -> "gisetl",
      "password" -> "GisBdp@0719"
    )
    if (flag == "0") queryTablesInMysql(getOMCSDevMysqlConnect(), "omcs", mysqlTN)

    if (flag == "1") loadMysqlTableToHive(spark, params, "dm_gis", mysqlTN, mysqlTN, false)

  }
}
