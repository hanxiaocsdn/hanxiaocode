package com.sf.app.eta.realtime

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.util.DistanceTool
import com.sf.gis.utils.JSONUtils
import org.apache.commons.lang3.time.FastDateFormat
import com.sf.app.eta.realtime.ParseRecallScala2.{getStartEndIndexFromJPTimeWithTimeBack, getSwidLengthMap, tranTstampToTime}
import com.sf.app.eta.realtime.ParseVmsScala.{StringExtensions, getEventMap, getSwidAndCount, strNotNull}

import java.text.SimpleDateFormat
import java.util
import scala.collection.JavaConversions.asScalaBuffer
import scala.collection.JavaConverters._

//import similar.PathSimilar
import utils.{DateTimeUtil}



import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.{ArrayBuffer, ListBuffer}
import scala.util.control.Breaks.{break, breakable}
import scala.util.Try

/*
 @author 01401062
 @DESCRIPTION ${DESCRIPTION} 时效定则-任务维度 客观数据补充
 @create 2023/6/1
*/

object ParseRecallScala {


  def calNaviSimilar(lineJo: JSONObject, rt_coords: String, pns_dist_str: String, rt_dist_str: String,line_distance_str:String) = {

    val polyline = JSONUtils.getJsonValue(lineJo, "polyline", "")
    val std_coords = convertToCoordinates(polyline)
    val pns_dist = try {pns_dist_str.toDouble} catch {case e:Exception => 0.0}
    val rt_dist = try {rt_dist_str.toDouble} catch {case e:Exception => 0.0}
    val line_distance = try {line_distance_str.toDouble} catch {case e:Exception => 0.0}


    val array1 = try {
      JSON.parseArray(std_coords)
    } catch {
      case e: Exception => new JSONArray()
    }

    val array2 = try {
      JSON.parseArray(rt_coords)
    } catch {
      case e: Exception => new JSONArray()
    }

    val jo1 = new JSONObject()
    val jo2 = new JSONObject()

    jo1.put("rt_coords", array1)
    jo1.put("vehicle_type", "5")
    jo2.put("rt_coords", array2)


    val (sim1Pre, sim5Pre) = try {
      getSimilarInterface2.getSimilar2(jo1, jo2)
    } catch {
      case e: Exception => (0, 0)
    }

    val sim1 = try {
      sim1Pre.asInstanceOf[Double]
    } catch {
      case e: Exception => 0.0
    }
    val sim5 = try {
      sim5Pre.asInstanceOf[Double]
    } catch {
      case e: Exception => 0.0
    }


    val conduct_type = line_distance match {
      case line_distance if (line_distance <= 5 && ((pns_dist <= 5000 && rt_dist <= 5000) || Math.abs(rt_dist - pns_dist) <= 2000 || (pns_dist <= 10000 && Math.max(sim1, sim5) > 0.5 && Math.min(sim1, sim5) >= 0.4) || (pns_dist > 10000 && Math.max(sim1, sim5) > 0.6 && Math.min(sim1, sim5) >= 0.5) || pns_dist <= 1000 || Math.max(sim1, sim5) >= 0.9)) => 1
      case line_distance if (line_distance > 5 && line_distance <= 10 && ((Math.max(sim1, sim5) >= 0.6 && Math.min(sim1, sim5) >= 0.5) || Math.max(sim1, sim5) >= 0.9)) => 1
      case line_distance if (line_distance > 10 && line_distance <= 50 && Math.max(sim1, sim5) > 0.75 && Math.min(sim1, sim5) >= 0.7) => 1
      case line_distance if (line_distance > 50 && line_distance <= 100 && Math.max(sim1, sim5) > 0.8 && Math.min(sim1, sim5) >= 0.75) => 1
      case line_distance if (line_distance > 100 && line_distance <= 500 && Math.max(sim1, sim5) > 0.85 && Math.min(sim1, sim5) >= 0.8) => 1
      case line_distance if (line_distance > 500 && Math.max(sim1, sim5) > 0.9 && Math.min(sim1, sim5) >= 0.85) => 1
      case line_distance if ((pns_dist <= 5000 && rt_dist <= 5000 && rt_dist != 0) || pns_dist == 0 || (pns_dist <= 10000 && Math.abs(rt_dist - pns_dist) <= 2000 && rt_dist != 0) ||
        ((rt_dist != 0 && Math.abs(rt_dist - pns_dist) <= 5000 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000)))
          || (rt_dist != 0 && Math.abs(rt_dist - pns_dist) / rt_dist <= 0.05 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000))))) => 1
      case _ => 3
    }

    val simJo = new JSONObject()
    simJo.put("sim1_navi", sim1)
    simJo.put("sim5_navi", sim5)
    simJo.put("conduct_type", conduct_type)

    simJo
  }

  /**
   *  解析导航数据，判断执行标签
   */
  def parseNaviResponse(response:String,taskJo:JSONObject,i:Int) = {

    val sub_start_dept = try {taskJo.getString("sub_start_dept").split("\\|")(i)} catch {case e:Exception => ""}
    val sub_end_dept = try {taskJo.getString("sub_end_dept").split("\\|")(i)} catch {case e:Exception => ""}
    val sub_start_dept_coordinate = try {taskJo.getString("sub_start_dept_coordinate").split("\\|")(i)} catch {case e:Exception => ""}
    val sub_end_dept_coordinate = try {taskJo.getString("sub_end_dept_coordinate").split("\\|")(i)} catch {case e:Exception => ""}
    val sub_actual_depart_tm = try {taskJo.getString("sub_actual_depart_tm").split("\\|")(i)} catch {case e:Exception => ""}
    val rt_coords = try {taskJo.getString("rt_coords").split(";")(i)} catch {case e:Exception => ""}
    val pns_dist = try {taskJo.getString("pns_dist").split(";")(i)} catch {case e:Exception => ""}
    val rt_dist = try {taskJo.getString("rt_dist").split(";")(i)} catch {case e:Exception => ""}
    val line_distance = try {taskJo.getString("task_subid_line_distance").split("\\|")(i)} catch {case e:Exception => ""}

    val responseJo = JSON.parseObject(response)
    val result = responseJo.getJSONObject("result")
    val lines = result.getJSONArray("lines")

    val filterBuffer = new ArrayBuffer[JSONObject]()

    for (j <- 0 until lines.size()) {
      val lineJo = lines.getJSONObject(j)
      val srcDeptCode = JSONUtils.getJsonValue(lineJo, "srcDeptCode","")
      val destDeptCode = JSONUtils.getJsonValue(lineJo, "destDeptCode","")
      val origin = JSONUtils.getJsonValue(lineJo, "origin","")
      val destination = JSONUtils.getJsonValue(lineJo, "destination","")
      val createTime = JSONUtils.getJsonValue(lineJo, "createTime","")

      if (sub_start_dept.equals(srcDeptCode) && sub_end_dept.equals(destDeptCode) && compareCoordinate(sub_start_dept_coordinate,origin) &&  compareCoordinate(sub_end_dept_coordinate,destination) ){
        // 筛选相关数据
        val timeDifference = getTimeDifference(sub_actual_depart_tm,createTime)
        if (timeDifference > 0){
          lineJo.put("timeDifference",timeDifference)
          filterBuffer.append(lineJo)
        }
      }
    }

    var filterBuffer2 = filterBuffer

    if (filterBuffer.size> 3){
      filterBuffer2 = filterBuffer.sortBy(_.getLongValue("timeDifference")).slice(0,3)
    }


    var tag = true

    var simJo = new JSONObject()


    for (k <- 0 until filterBuffer2.size if (tag)) {
      val lineJo = filterBuffer(k)
      val navi_id = JSONUtils.getJsonValue(lineJo, "naviId","-")
      val navi_route_id = JSONUtils.getJsonValue(lineJo, "routeId","-")
      val navi_stdId = JSONUtils.getJsonValue(lineJo, "stdId","-")

      simJo = calNaviSimilar(lineJo, rt_coords, pns_dist, rt_dist, line_distance)
      val conduct_type = JSONUtils.getJsonValueInt(simJo,"conduct_type",0)
      if (conduct_type != 3) {
        tag = false

        simJo.put("navi_id", navi_id)
        simJo.put("navi_route_id", navi_route_id)
        simJo.put("navi_stdId", navi_stdId)
      }
    }

    simJo

  }

  def getTimeDifference(dateTime1:String,dateTime2: String) = {
    val dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    var subActualDepartTm = -1L
    try {
      val dateTimeStamp1 = dateFormat.parse(dateTime1)
      val dateTimeStamp2 = dateFormat.parse(dateTime2)

      subActualDepartTm = dateTimeStamp2.getTime - dateTimeStamp1.getTime

    } catch {
      case e: Exception =>
    }
    subActualDepartTm
  }


  /**
   * 比较两坐标后6位是否相同
   * @param coordinate1
   * @param coordinate2
   * @return
   */
  def compareCoordinate(coordinate1: String, coordinate2: String): Boolean = {
    val separator = ","

    try {
      val lat1 = BigDecimal(coordinate1.split(separator)(0))
      val lat2 = BigDecimal(coordinate2.split(separator)(0))
      val lon1 = BigDecimal(coordinate1.split(separator)(1))
      val lon2 = BigDecimal(coordinate2.split(separator)(1))

      val dist = DistanceTool.getGreatCircleDistance(lat1.doubleValue(), lon1.doubleValue(), lat2.doubleValue(), lon2.doubleValue());
      if (dist <= 500) {
        true
      } else {
        false
      }
//      val scale = 6 // 设置精度为小数点后6位
//
//      lat1.setScale(scale, BigDecimal.RoundingMode.HALF_UP) == lat2.setScale(scale, BigDecimal.RoundingMode.HALF_UP) &&
//        lon1.setScale(scale, BigDecimal.RoundingMode.HALF_UP) == lon2.setScale(scale, BigDecimal.RoundingMode.HALF_UP)
    }catch {
      case e:Exception => false
    }
  }


  /**
   * 转换 105.215382,30.066767|105.214846,30.067194|105.213890,30.068058坐标为[[105.215382,30.066767],[105.214846,30.067194|],[105.213890,30.068058]]
   * @param input
   * @return
   */
  def convertToCoordinates(input: String) = {
    var list = ""
    try {
      list = input.split("\\|")
        .map(_.split(","))
        .map(parts => s"[${parts(0)},${parts(1)}]")
        .mkString(",")
    }catch {
      case e:Exception => ""
    }
    s"[$list]"
  }





  /**
   * 解析tmc接口返回结果
   * @param fixResponseParse
   */

  def parseTmcResponse(org_json: JSONObject): JSONObject = {
    val evenr_s_l_map = getEventMap()
    val event_info = getEvent_S_L_Info(org_json, evenr_s_l_map)
    val swid_gd = event_info._1
    val status_gd = event_info._2
    val speed_gd = event_info._3
    val events_swid = event_info._4
    val events_code = event_info._5
    val events_S = event_info._6
    val events_L = event_info._7
    val warn_linkid = event_info._8
    val warn_level = event_info._9
    val warn_description = event_info._10
    val new_json = new JSONObject(true)
    new_json.put("swid_gd", swid_gd)
    new_json.put("status_gd", status_gd)
    new_json.put("speed_gd", speed_gd)
    new_json.put("events_swid", events_swid)
    new_json.put("events_code", events_code)
    new_json.put("events_S", events_S)
    new_json.put("events_L", events_L)
    new_json.put("warn_linkid", warn_linkid)
    new_json.put("warn_level", warn_level)
    new_json.put("warn_description", warn_description)
    new_json
  }

  def getEvent_S_L_Info(json_parse: JSONObject, evenr_s_l_map: mutable.Map[String, (String, String)]): (String, String, String, String, String, String, String, String, String, String) = {

    val swid_gd_ab, status_gd_ab, speed_gd_ab, events_swid_ab, events_code_ab, events_S_ab, events_L_ab, warn_linkid_ab, warn_level_ab, warn_description_ab = new ListBuffer[String]()
    val tracks = json_parse.getJSONArray("tracks")
    if (tracks != null && tracks.size() > 0) {
      val events_map = collection.mutable.Map[String, String]()
      val warn_map = collection.mutable.Map[String, String]()
      for (i <- 0 until tracks.size()) {
        //flow 的信息拆解
        val flow = tracks.getJSONObject(i).getJSONArray("flow")
        if (flow != null && flow.size() > 0) {
          for (j <- 0 until flow.size()) {
            val link_id = tracks.getJSONObject(i).getString("link_id")
            val speed = flow.getJSONObject(j).getString("speed")
            val status = flow.getJSONObject(j).getString("status")
            swid_gd_ab += link_id
            speed_gd_ab += speed
            status_gd_ab += status
          }
        }

        //events 的信息拆解
        val events = tracks.getJSONObject(i).getJSONArray("events")
        if (events != null && events.size() > 0) {
          for (j <- 0 until events.size()) {
            val link_id = tracks.getJSONObject(i).getString("link_id")
            val limit_c = events.getJSONObject(j).getString("limit_c")
            val limit_t = events.getJSONObject(j).getString("limit_t")
            val reason_c = events.getJSONObject(j).getString("reason_c")
            val reason_t = events.getJSONObject(j).getString("reason_t")
            val event_key = limit_c + "," + limit_t + "," + reason_c + "," + reason_t + "&" + link_id
            if (!events_map.contains(event_key)) {
              events_map.put(event_key, "-")
            }
          }
        }
        //warn 的信息拆解
        val warn = tracks.getJSONObject(i).getJSONArray("warn")
        if (warn != null && warn.size() > 0) {
          for (j <- 0 until warn.size()) {
            val link_id = tracks.getJSONObject(i).getString("link_id")
            val level = warn.getJSONObject(j).getString("level")
            val description = warn.getJSONObject(j).getString("description")
            val warn_key = level + "&" + description + "&" + link_id
            if (!warn_map.contains(warn_key)) {
              warn_map.put(warn_key, "-")
            }
          }
        }
      }
      if (events_map.size > 0) {
        val event_info = events_map.keys
        for (e_info <- event_info) {
          val code = e_info.split("&")(0)
          val linkid = e_info.split("&")(1)
          val event_s_l_info = evenr_s_l_map.getOrElse(code, ("-", "-"))
          events_swid_ab += linkid
          events_code_ab += code
          events_S_ab += event_s_l_info._1
          events_L_ab += event_s_l_info._2
        }
      }
      if (warn_map.size > 0) {
        val warn_level_desc = warn_map.keys
        for (warn <- warn_level_desc) {
          val level = warn.split("&")(0)
          val description = warn.split("&")(1)
          val linkid = warn.split("&")(2)
          warn_level_ab += level
          warn_description_ab += description
          warn_linkid_ab += linkid
        }
      }
    }
    (swid_gd_ab.mkString("|"), status_gd_ab.mkString("|"), speed_gd_ab.mkString("|"), events_swid_ab.mkString("|"), events_code_ab.mkString("|"), events_S_ab.mkString("|"), events_L_ab.mkString("|"), warn_linkid_ab.mkString("|"), warn_level_ab.mkString("|"), warn_description_ab.mkString("|"))

  }




  /**
   * 调用tmc接口
   *
   * @param x
   * @return
   */

  def calTmcInterface(jo: JSONObject , tmcUrl: String) = {

    val joPost = new JSONObject()
    val jp_swid = jo.getString("jp_swid")
    val jp_time = jo.getString("jp_time")
    val swidList = jp_swid.split("\\|")
    val timeList = jp_time.split("\\|")
    val pairs = swidList.zip(timeList)
    val indexedDistinctPairs = pairs.zipWithIndex.map { case ((swid, time), index) => (swid, time, index) }.sortBy(_._3).filter(x => {
      !"0".equals(x._1)
    })
    //    val sortTuple = indexedDistinctPairs.groupBy(_._1).map(x => x._2.take(1)).flatten.toList.sortBy(_._3)
    // 0526修改为Jp_swid不去重，只去除为0的数据
    val sortTuple = indexedDistinctPairs.toList.sortBy(_._3)
    val swidArray = sortTuple.map(_._1)
    val timeArray = sortTuple.map(_._2)

    val tracksArray = new JSONArray()

    for (index <- (0 until (swidArray.length))) {
      val swid = swidArray(index)
      val time = timeArray(index)
      val track = new JSONObject()
      track.put("link_id", swid)
      track.put("timestamp", time)
      tracksArray.add(track)
    }

    joPost.put("ak", "0d2d6608470a45a28f9d0eb976277725")
    joPost.put("tracks", tracksArray)
    joPost.put("focus", "flow,warn,event")

//    val fixResponse = HttpUtils.doPost(tmcUrl, joPost)
//    val fixResponse = Utils.retryPost(tmcUrl, joPost)
    val fixResponse = ""

//    System.err.println("fixResponse:" + fixResponse)

    val resJo = try {
      JSON.parseObject(fixResponse)
    } catch {
      case e: Exception => new JSONObject()
    }

    val json = try {
      parseTmcResponse(resJo)
    } catch {
      case e: Exception => jo
    }

    json
  }


  def parseFixResponse(x: JSONObject,sub_actual_depart_tm:String,sub_actual_arrive_tm:String,warning_time:String) = {
    val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")
    val jo = new JSONObject()
      val result = x.getJSONObject("result")
      val tracks = result.getJSONArray("tracks")
      val stay_points = result.getJSONArray("stay_points")
      val jp_swidBuff, jp_coordsBuff, jp_statusBuff, sum_distBuff, link_lengthBuff, speedBuff, stayDurationBuffer, stayStartBuffer, stayEndBuffer, duationPeriodsBuffer = new ArrayBuffer[String]()
      val stay_formway_out, stay_linktype_out, stay_gas_out, stay_pois_out = new ListBuffer[String]()
      val jp_timeBuff = new ArrayBuffer[Long]()
      var stayTotalDuration = 0L

      for (i <- 0 until tracks.size()) {
        val t: JSONObject = tracks.getJSONObject(i)
        jp_swidBuff.append(t.getString("SWID"))
        jp_timeBuff.append(t.getLongValue("time"))
        val x: String = t.getString("x")
        val y: String = t.getString("y")
        jp_coordsBuff.append(x + "," + y)
        jp_statusBuff.append(t.getString("status"))
        sum_distBuff.append(t.getString("sum_dist"))
        link_lengthBuff.append(t.getString("link_length"))
        speedBuff.append(t.getString("speed"))
      }

      val dist = try {
        sum_distBuff.last.toDouble
      } catch {
        case e: Exception => 0
      }

      for (i <- 0 until stay_points.size()) {
        val stayJo = stay_points.getJSONObject(i)
        val stayStartIndex = JSONUtils.getJsonValueInt(stayJo, "start_index", 0)
        val stayEndIndex = JSONUtils.getJsonValueInt(stayJo, "end_index", 0)

        val stayStartJo = try {
          tracks.getJSONObject(stayStartIndex)
        } catch {
          case e: Exception => new JSONObject()
        }
        val x1: String = stayStartJo.getString("x")
        val y1: String = stayStartJo.getString("y")

        val stayEndJo = try {
          tracks.getJSONObject(stayEndIndex)
        } catch {
          case e: Exception => new JSONObject()
        }
        val x2: String = stayEndJo.getString("x")
        val y2: String = stayEndJo.getString("y")

        val start_time = JSONUtils.getJsonValueLong(stayStartJo, "time", 0)
        val end_time = JSONUtils.getJsonValueLong(stayEndJo, "time", 0)
        val sub_depart: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_depart_tm)
        val sub_arrive: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", sub_actual_arrive_tm)
        var start_time_date = tranTstampToTime(sdf1, start_time.toString)
        var end_time_date = tranTstampToTime(sdf1, end_time.toString)
        if (start_time < sub_depart) start_time_date = sub_actual_depart_tm
        if (end_time > sub_arrive) end_time_date = sub_actual_arrive_tm

        if (end_time - start_time > 300) {
          val dura_tm = start_time_date + "~" + end_time_date
          val dura_tm_new = try {diffDurationAndWarningTime(dura_tm, warning_time)} catch {case e: Exception => ""}
          if (dura_tm_new != "") {
            duationPeriodsBuffer.append(dura_tm_new)
            val dura_long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_tm_new.split("~")(1)) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_tm_new.split("~")(0))
            stayTotalDuration += dura_long
            stayDurationBuffer.append(dura_long.toString)
            stayStartBuffer.append(x1 + "," + y1)
            stayEndBuffer.append(x2 + "," + y2)

            //新增 从track中获取停留点信息
            val stay_formway_in, stay_linktype_in, stay_gas_in = new ListBuffer[Int]()
            val stay_pois_in = new ListBuffer[String]()
            for (k <- stayStartIndex.toInt to stayEndIndex.toInt) {
              val trackJo = tracks.getJSONObject(k)
              val formay = JSONUtils.getJsonValueInt(trackJo, "formway", 0)
              val linktype = JSONUtils.getJsonValueInt(trackJo, "linktype", 0)
              val gas = JSONUtils.getJsonValueInt(trackJo, "gas", 0)
              if (!stay_formway_in.contains(formay)) stay_formway_in.append(formay)
              if (!stay_linktype_in.contains(linktype)) stay_linktype_in.append(linktype)
              if (!stay_gas_in.contains(gas)) stay_gas_in.append(gas)
            }
            val gas_arr = stayJo.getJSONArray("pois")
            if (gas_arr != null && gas_arr.size() > 0) {
              for (g <- 0 until gas_arr.size()) {
                val gasJo = gas_arr.getJSONObject(g)
                val _type = JSONUtils.getJsonValueInt(gasJo, "type", 0)
                val dist = JSONUtils.getJsonValueDouble(gasJo, "dist", 0.0)
                stay_pois_in.append(_type + "_" + dist)
              }
            } else {
              stay_pois_in.append("-")
            }
            stay_formway_out += (if (stay_formway_in.size != 0) stay_formway_in.mkString(",") else "-")
            stay_linktype_out += (if (stay_linktype_in.size != 0) stay_linktype_in.mkString(",") else "-")
            stay_gas_out += (if (stay_gas_in.size != 0) stay_gas_in.mkString(",") else "-")
            stay_pois_out += (if (stay_pois_in.size != 0) stay_pois_in.mkString(",") else "-")
          }
        }
      }
      jo.put("stay_formway", stay_formway_out.mkString("|"))
      jo.put("stay_linktype", stay_linktype_out.mkString("|"))
      jo.put("stay_gas", stay_gas_out.mkString("|"))
      jo.put("stay_pois", stay_pois_out.mkString("|"))
      jo.put("jp_swid", jp_swidBuff.mkString("|"))
      jo.put("jp_time", jp_timeBuff.mkString("|"))
      jo.put("jp_coords", jp_coordsBuff.mkString("|"))
      jo.put("jp_length", link_lengthBuff.mkString("|"))
      jo.put("dist", dist)
      if (stay_points == null || stay_points.isEmpty || stay_points.size() == 0) {
        stayStartBuffer.append(0 + "," + 0)
        stayEndBuffer.append(0 + "," + 0)
        stayDurationBuffer.append("0")
      }
      jo.put("stay_duration", stayDurationBuffer.mkString("|"))
      jo.put("stay_start_point", stayStartBuffer.mkString("|"))
      jo.put("stay_end_point", stayEndBuffer.mkString("|"))
      jo.put("stay_total_duration", stayTotalDuration / 60.0)
      jo.put("duation_periods", duationPeriodsBuffer.mkString("|"))
      jo
    }


  /**
   * 处理天气信息数据
   *
   * @param org_json
   * @return
   */
  def weatherInfo(org_json: JSONObject): JSONObject = {
    val report_type = org_json.getString("report_type")
    val report_point = org_json.getString("report_point")
    val warn_linkid = org_json.getString("warn_linkid")
    val warn_level = org_json.getString("warn_level")
    val jp_swid = org_json.getString("jp_swid")
    val jp_coords = org_json.getString("jp_coords")
    val swid_coords_map = getSwidLengthMap(jp_swid, jp_coords)
    val (report_dist, report_level, report_linkid, report_dist2, report_level2, report_linkid2) = getWeatherReport(report_type, report_point, warn_linkid, warn_level, swid_coords_map)
    import scala.collection.JavaConversions._
    val javaMap: java.util.Map[String, Any] = Map("report_dist" -> report_dist, "report_level" -> report_level, "report_linkid" -> report_linkid, "report_dist2" -> report_dist2, "report_level2" -> report_level2, "report_linkid2" -> report_linkid2)
    val weatherJo = new JSONObject()
    weatherJo.putAll(javaMap)
    weatherJo
  }

  /**
   * 获取天气信息
   *
   * @param report_type
   * @param report_point
   * @param warn_linkid
   * @param warn_level
   * @param swid_coords_map
   * @return
   */
  def getWeatherReport(report_type: String, report_point: String, warn_linkid: String, warn_level: String, swid_coords_map: mutable.Map[String, String]): (String, String, String, String, String, String) = {
    val report_dist_ab, report_level_ab, report_linkid_ab, report_dist_ab2, report_level_ab2, report_linkid_ab2 = new ListBuffer[String]()
    try {
      if (strNotNull(report_type)) {
        val type_arr = report_type.split("\\|")
        val point_arr = report_point.split("\\|")
        val linkid_arr = warn_linkid.split("\\|")
        val level_arr = warn_level.split("\\|")
        for (m <- 0 until point_arr.length) {
          if (type_arr(m) == "3") {
            val x_point = Try(point_arr(m).split(",")(0).toDouble).getOrElse(0.0)
            val y_point = Try(point_arr(m).split(",")(1).toDouble).getOrElse(0.0)
            var min_dist1, min_dist2: Double = 999999999.0
            var index1, index2: Int = 999999999
            for (i <- 0 until linkid_arr.length) {
              val coords = swid_coords_map.getOrElse(linkid_arr(i), "")
              val x_coords = Try(coords.split(",")(0).toDouble).getOrElse(0.0)
              val y_coords = Try(coords.split(",")(1).toDouble).getOrElse(0.0)
              if (strNotNull(linkid_arr(i)) && strNotNull(coords)) {
                val dist = DistanceTool.getGreatCircleDistance(x_point, y_point, x_coords, y_coords)
                if (dist < min_dist1) {
                  min_dist1 = dist
                  index1 = i
                }
              }
              if (level_arr(i) != "1") {
                if (strNotNull(linkid_arr(i)) && strNotNull(coords)) {
                  val dist = DistanceTool.getGreatCircleDistance(x_point, y_point, x_coords, y_coords)
                  if (dist < min_dist2) {
                    min_dist2 = dist
                    index2 = i
                  }
                }
              }
            }
            report_dist_ab += (if (min_dist1 == 999999999.0) "" else min_dist1.formatted("%.2f"))
            report_level_ab += (try {
              level_arr(index1)
            } catch {
              case e: Exception => ""
            })
            report_linkid_ab += (try {
              linkid_arr(index1)
            } catch {
              case e: Exception => ""
            })
            report_dist_ab2 += (if (min_dist2 == 999999999.0) "" else min_dist2.formatted("%.2f"))
            report_level_ab2 += (try {
              level_arr(index2)
            } catch {
              case e: Exception => ""
            })
            report_linkid_ab2 += (try {
              linkid_arr(index2)
            } catch {
              case e: Exception => ""
            })
          }
        }
      }
    } catch {
      case e: Exception => ""
    }
    (report_dist_ab.mkString("|"), report_level_ab.mkString("|"), report_linkid_ab.mkString("|"), report_dist_ab2.mkString("|"), report_level_ab2.mkString("|"), report_linkid_ab2.mkString("|"))
  }



  //todo fix 时间乱序的问题
  def mergeAndFixTm(xuhao: String, sub_actual_depart_tm: String, sub_actual_arrive_tm: String, road_time_tms: String, jp_time: String, jp_swid: String, warning_time: String): (String, String, String) = {
    //判断时间间隔 并进行合并
    val merge_tm, fix_merge_tm, merge_xuhao = new ListBuffer[String]()
    val sdf1 = FastDateFormat.getInstance("yyyy-MM-dd HH:mm:ss")

    try {
      val xuhao_arr = xuhao.split(";")
      val road_time_tms_ab = road_time_tms.split(";")
      var cnt = 0
      for (i <- 0 until road_time_tms_ab.size if i == cnt) {
        val s_tm = road_time_tms_ab(i).split("_")(0).toLong
        val e_tm = road_time_tms_ab(i).split("_")(1).toLong
        //xuhao
        val s_xuhao = xuhao_arr(i).split("_")(0)
        val e_xuhao = xuhao_arr(i).split("_")(1)
        breakable {
          for (j <- i + 1 until road_time_tms_ab.size if i + 1 <= road_time_tms_ab.size - 1) {
            val s_tm_p = road_time_tms_ab(j - 1).split("_")(0).toLong
            val e_tm_p = road_time_tms_ab(j - 1).split("_")(1).toLong
            val s_tm_pp = road_time_tms_ab(j).split("_")(0).toLong
            val e_tm_pp = road_time_tms_ab(j).split("_")(1).toLong
            //xuhao
            val s_xuhao_p = xuhao_arr(j - 1).split("_")(0)
            val e_xuhao_p = xuhao_arr(j - 1).split("_")(1)
            val s_xuhao_pp = xuhao_arr(j).split("_")(0)
            val e_xuhao_pp = xuhao_arr(j).split("_")(1)
            if (s_tm_p <= s_tm_pp) {
              if (j == i + 1) {
                if (s_tm_pp - e_tm > 5 * 60) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao
                  cnt = j
                  break()
                }
                if (j == road_time_tms_ab.size - 1) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_pp + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_pp
                }
              } else {
                if (s_tm_pp - e_tm_p > 5 * 60) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_p + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_p
                  cnt = j
                  break()
                }
                if (j == road_time_tms_ab.size - 1) {
                  merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm_pp + 2 * 60).toString)
                  merge_xuhao += s_xuhao + "_" + e_xuhao_pp
                }
              }
            } else {
              if (j + 1 <= road_time_tms_ab.size - 1) {
                cnt = j + 1
                break()
              }
            }
          }
        }
        if (i == road_time_tms_ab.size - 1) {
          merge_tm += tranTstampToTime(sdf1, (s_tm - 2 * 60).toString) + "_" + tranTstampToTime(sdf1, (e_tm + 2 * 60).toString)
          merge_xuhao += s_xuhao + "_" + e_xuhao
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    //计算开始和结束拥堵路段的信息
    //"sub_plan_arrive_tm":"2023-06-12 18:20:00|2023-06-12 19:15:00"
    if (merge_tm.size == 1) {
      val f1_start_tm = merge_tm(0).split("_")(0)
      val f1_end_tm = merge_tm(0).split("_")(1)
      var new_sttm = f1_start_tm
      var new_endm = f1_end_tm
      if (f1_start_tm < sub_actual_depart_tm) new_sttm = sub_actual_depart_tm
      if (f1_end_tm > sub_actual_arrive_tm) new_endm = sub_actual_arrive_tm
      fix_merge_tm += new_sttm + "_" + new_endm
    } else {
      for (k <- 0 until merge_tm.size) {
        val f1_start_tm = merge_tm(k).split("_")(0)
        val f1_end_tm = merge_tm(k).split("_")(1)
        if (k == 0) {
          if (f1_start_tm < sub_actual_depart_tm) {
            fix_merge_tm += sub_actual_depart_tm + "_" + f1_end_tm
          } else {
            fix_merge_tm += f1_start_tm + "_" + f1_end_tm
          }
        } else if (k == merge_tm.size - 1) {
          if (f1_end_tm > sub_actual_arrive_tm) {
            fix_merge_tm += f1_start_tm + "_" + sub_actual_arrive_tm
          } else {
            fix_merge_tm += f1_start_tm + "_" + f1_end_tm
          }
        } else {
          fix_merge_tm += f1_start_tm + "_" + f1_end_tm
        }
      }
    }
    //todo add
    val yd_warning = diffYongduAndWarningTime(fix_merge_tm, merge_xuhao, warning_time)
    val fix_yd_time = yd_warning._1
    val fix_xuhao = yd_warning._2
    val jp_time_arr = jp_time.split("\\|")
    val jp_swid_arr = jp_swid.split("\\|")
    //传入合并后的起始结束时间 纠偏时间集合
    val jp_index = getStartEndIndexFromJPTimeWithTimeBack(fix_yd_time, jp_time_arr, jp_swid_arr, timeToTimestampFormat)
    val start_index_arr = jp_index._1
    val end_index_arr = jp_index._2
    val start_end_index_arr = start_index_arr.zip(end_index_arr) map { x => x._1 + "_" + x._2 }

    (fix_yd_time.mkString(";"), fix_xuhao.mkString(";"), start_end_index_arr.mkString(";"))
  }




  def diffDurationAndWarningTime(dura_tm: String, warning_time: Any): String = {
    var dura_tm_new: String = ""
    val diff_warning_time = if (strNotNull(warning_time)) {
      warning_time.toString.split("\\|").flatMap(_.split("_")).map((_, 1)).groupBy(_._1).mapValues(_.length).filter(_._2 == 1).map(_._1).filter(x => x != null && x != "").toArray.sorted
    } else {
      new Array[String](0)
    }
    val warning_time_arr = new ListBuffer[String]()
    for (i <- 0 until diff_warning_time.length if i % 2 == 0) {
      val start = diff_warning_time(i)
      val end = diff_warning_time(i + 1)
      warning_time_arr += start + "_" + end
    }
    try {
      var dura_start = dura_tm.split("~")(0)
      var dura_end = dura_tm.split("~")(1)
      if (diff_warning_time.size > 0) {
        for (j <- 0 until warning_time_arr.length) {
          val wt_start = warning_time_arr(j).split("_")(0)
          val wt_end = warning_time_arr(j).split("_")(1)
          if (wt_start <= dura_end && wt_start >= dura_start && dura_end <= wt_end) { //有交集1
            dura_tm_new = dura_start + "~" + wt_start
            dura_start = dura_start
            dura_end = wt_start
          } else if (dura_start <= wt_end && dura_start >= wt_start && wt_end <= dura_end) { //有交集2
            dura_tm_new = wt_end + "~" + dura_end
            dura_start = wt_end
            dura_end = dura_end
          } else if (dura_start <= wt_start && wt_end <= dura_end) { //停留覆盖warning_time
            val l1 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_end) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_end)
            val l2 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_start) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", dura_start)
            if (l1 >= l2) {
              dura_tm_new = wt_end + "~" + dura_end
              dura_start = wt_end
              dura_end = dura_end
            } else {
              dura_tm_new = dura_start + "~" + wt_start
              dura_start = dura_start
              dura_end = wt_start
            }
          } else if (wt_start <= dura_start && dura_end <= wt_end) { //warning_time覆盖停留
            dura_start = "99"
            dura_end = "00"
          } else if (j == warning_time_arr.length - 1 && (dura_end < wt_start || wt_end < dura_start)) { //无交集(dura_end < wt_start || wt_end < dura_start)
            dura_tm_new = dura_start + "~" + dura_end
            dura_start = dura_start
            dura_end = dura_end
          }
        }
      } else {
        dura_tm_new = dura_tm
      }
    } catch {
      case e: Exception => "" + e
    }
    dura_tm_new
  }


  //todo add function
  def diffYongduAndWarningTime(yongdu_time2_arr: ListBuffer[String], merge_xuhao: ListBuffer[String], warning_time: Any): (ListBuffer[String], ListBuffer[String]) = {
    var yd_tm, xuhao_new = new ListBuffer[String]()
    val diff_warning_time = if (strNotNull(warning_time)) {
      warning_time.toString.split("\\|").flatMap(_.split("_")).map((_, 1)).groupBy(_._1).mapValues(_.length).filter(_._2 == 1).map(_._1).filter(x => x != null && x != "").toArray.sorted
    } else {
      new Array[String](0)
    }
    val warning_time_arr = new ListBuffer[String]()
    for (i <- 0 until diff_warning_time.length if i % 2 == 0) {
      val start = diff_warning_time(i)
      val end = diff_warning_time(i + 1)
      warning_time_arr += start + "_" + end
    }
    try {
      if (diff_warning_time.size > 0) {
        for (i <- 0 until yongdu_time2_arr.length) {
          var yd_start = yongdu_time2_arr(i).split("_")(0)
          var yd_end = yongdu_time2_arr(i).split("_")(1)
          var yd_tm_new, xuhao: Any = null
          for (j <- 0 until warning_time_arr.length) {
            val wt_start = warning_time_arr(j).split("_")(0)
            val wt_end = warning_time_arr(j).split("_")(1)
            if (wt_start <= yd_end && wt_start >= yd_start && yd_end <= wt_end) { //有交集1
              xuhao = merge_xuhao(i)
              yd_tm_new = yd_start + "_" + wt_start
              yd_start = yd_start
              yd_end = wt_start
            } else if (yd_start <= wt_end && yd_start >= wt_start && wt_end <= yd_end) { //有交集2
              xuhao = merge_xuhao(i)
              yd_tm_new = wt_end + "_" + yd_end
              yd_start = wt_end
              yd_end = yd_end
            } else if (yd_start <= wt_start && wt_end <= yd_end) { //拥堵覆盖warning_time
              val l1 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", yd_end) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_end)
              val l2 = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", wt_start) - timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", yd_start)
              if (l1 >= l2) {
                xuhao = merge_xuhao(i)
                yd_tm_new = wt_end + "_" + yd_end
                yd_start = wt_end
                yd_end = yd_end
              } else {
                xuhao = merge_xuhao(i)
                yd_tm_new = yd_start + "_" + wt_start
                yd_start = yd_start
                yd_end = wt_start
              }
            } else if (wt_start <= yd_start && yd_end <= wt_end) { //warning_time覆盖拥堵
              xuhao = null
              yd_tm_new = null
              yd_start = "99"
              yd_end = "00"
            } else if (j == warning_time_arr.length - 1 && (yd_end < wt_start || wt_end < yd_start)) { //无交集(yd_end < wt_start || wt_end < yd_start)
              xuhao = merge_xuhao(i)
              yd_tm_new = yd_start + "_" + yd_end
              yd_start = yd_start
              yd_end = yd_end
            }
          }
          if (yd_tm_new != null) {
            yd_tm.append(yd_tm_new.toString)
            xuhao_new.append(xuhao.toString)
          }
        }
      } else {
        yd_tm = yongdu_time2_arr
        xuhao_new = merge_xuhao
      }
    } catch {
      case e: Exception => "" + e
    }
    (yd_tm, xuhao_new)
  }





  def timeToTimestampFormat(format: String, colValue: String): Long = {
    var ts = 0l
    try {
      val fdf = FastDateFormat.getInstance(format)
      val dt = fdf.parse(colValue)
      //时间戳毫秒转秒
      ts = dt.getTime / 1000
    } catch {
      case e: Exception => ""
    }
    ts
  }



  def calFixInterface(tracks: JSONArray, vehicle_type:String, fixUrl: String, sub_actual_depart_tm: String, sub_actual_arrive_tm: String,warning_time:String): JSONObject = {

    val joPost = new JSONObject()

    joPost.put("ak", "ef789d00926d46cdae8fc721608557ad")
    joPost.put("keeptype", 1)
    joPost.put("vehicle", vehicle_type)
    joPost.put("retflag", 3)
    joPost.put("addpoint", 1)
    joPost.put("roadinfo", 1)
    joPost.put("poiinfo", 1)
    joPost.put("only_primary", 0)
    joPost.put("tracks", tracks)
    joPost.put("slowinfo",1)


    val process = new JSONObject()
    process.put("stay_time",300)
    process.put("stay_radius",50)
    process.put("stay_join_dist",100)
    process.put("stay_join_time",120)

    joPost.put("process",process)

//    val fixResponse = HttpUtils.doPost(fixUrl, joPost)
    val fixResponse = ""

//    StringToCsv.stringToCsv("202308211815jp","",joPost.toJSONString);
//
//    StringToCsv.stringToCsv("20230801114500_output","",fixResponse);


    val fixResponseParse = try {
      JSON.parseObject(fixResponse)
    } catch {
      case e: Exception => new JSONObject()
    }


    val json = try {
      parseFixResponse(fixResponseParse,sub_actual_depart_tm,sub_actual_arrive_tm,warning_time)
    } catch {
      case e: Exception => new JSONObject()
    }

    json
  }



  def recalSim(list: JSONArray, rt_coords: String, pns_dist: Double, rt_dist: Double) = {

    var stopFlag = 0

    val size = if (list.size() >= 3) 3 else list.size()

    val x = new JSONObject()

    val stdIdBuffer = new ArrayBuffer[String]()

    for (i <- (0 until (size))) {
      val jo = list.getJSONObject(i)
      val std_id = JSONUtils.getJsonValue(jo, "stdId", "-")
      stdIdBuffer.append(std_id)
    }


    for (i <- (0 until (size)) if stopFlag == 0) {

      val jo = list.getJSONObject(i)
      val std_coords = jo.getString("jyTrack2")
      val line_distance = JSONUtils.getJsonValueDouble(jo, "lineDistance", 0) / 1000
      val pns_dist = JSONUtils.getJsonValueDouble(jo, "rtDistance", 0)

      if (strNotNull(std_coords) && strNotNull(rt_coords)) {

        val joArray1 = new JSONArray()
        val array1 = std_coords.split("\\|")

        for (pos <- array1) {
          val dx = try {
            pos.split(",")(0)
          } catch {
            case e: Exception => "0"
          }
          val dy = try {
            pos.split(",")(1)
          } catch {
            case e: Exception => "0"
          }
          val arrayNew = new JSONArray()
          arrayNew.add(dx)
          arrayNew.add(dy)
          joArray1.add(arrayNew)
        }


        val joArray2 = new JSONArray()
        val array2 = try {
          JSON.parseArray(rt_coords)
        } catch {
          case e: Exception => new JSONArray()
        }

        val jo1 = new JSONObject()
        val jo2 = new JSONObject()

        jo1.put("rt_coords", joArray1)
        jo1.put("vehicle_type", "5")
        jo2.put("rt_coords", array2)


        val (sim1Pre, sim5Pre) = try {
          getSimilarInterface2.getSimilar2(jo1, jo2)
        } catch {
          case e: Exception => (0, 0)
        }

        val sim1 = try {
          sim1Pre.asInstanceOf[Double]
        } catch {
          case e: Exception => 0.0
        }
        val sim5 = try {
          sim5Pre.asInstanceOf[Double]
        } catch {
          case e: Exception => 0.0
        }

        val conduct_type = line_distance match {
          case line_distance if (line_distance <= 5 && ((pns_dist <= 5000 && rt_dist <= 5000) || Math.abs(rt_dist - pns_dist) <= 2000 || (pns_dist <= 10000 && Math.max(sim1, sim5) > 0.5 && Math.min(sim1, sim5) >= 0.4) || (pns_dist > 10000 && Math.max(sim1, sim5) > 0.6 && Math.min(sim1, sim5) >= 0.5) || pns_dist <= 1000 || Math.max(sim1, sim5) >= 0.9)) => 1
          case line_distance if (line_distance > 5 && line_distance <= 10 && ((Math.max(sim1, sim5) >= 0.6 && Math.min(sim1, sim5) >= 0.5) || Math.max(sim1, sim5) >= 0.9)) => 1
          case line_distance if (line_distance > 10 && line_distance <= 50 && Math.max(sim1, sim5) > 0.75 && Math.min(sim1, sim5) >= 0.7) => 1
          case line_distance if (line_distance > 50 && line_distance <= 100 && Math.max(sim1, sim5) > 0.8 && Math.min(sim1, sim5) >= 0.75) => 1
          case line_distance if (line_distance > 100 && line_distance <= 500 && Math.max(sim1, sim5) > 0.85 && Math.min(sim1, sim5) >= 0.8) => 1
          case line_distance if (line_distance > 500 && Math.max(sim1, sim5) > 0.9 && Math.min(sim1, sim5) >= 0.85) => 1
          case line_distance if ((pns_dist <= 5000 && rt_dist <= 5000 && rt_dist != 0) || pns_dist == 0 || (pns_dist <= 10000 && Math.abs(rt_dist - pns_dist) <= 2000 && rt_dist != 0) ||
            ((rt_dist != 0 && Math.abs(rt_dist - pns_dist) <= 5000 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000)))
              || (rt_dist != 0 && Math.abs(rt_dist - pns_dist) / rt_dist <= 0.05 && (Math.max(sim1, sim5) >= 0.75 || (Math.max(sim1, sim5) > 0.7 && pns_dist <= 20000))))) => 1
          case _ => 3
        }

        if (conduct_type != 3) {
          val std_id = JSONUtils.getJsonValue(jo, "stdId", "")

          x.put("conduct_type", conduct_type)
          x.put("conduct_order", i + 1)
          x.put("std_id_kafka", std_id)
          x.put("sim1", sim1)
          x.put("sim5", sim5)
          x.put("line_distance2", line_distance)

          stopFlag = 1
        }
      }
    }

    if (strNotNull(stdIdBuffer.mkString(","))) {
      x.put("std_id2","-")
    } else {
      x.put("std_id2",stdIdBuffer.mkString(","))
    }
    x
  }

  /**
   * @note   解析conduct_type异常数据
   */

  def parseStd3Rep(rep:String,rt_coords:String,pns_dist:Double, rt_dist:Double) = {
    val fixResponse = try {
      JSON.parseObject(rep)
    } catch {
      case e: Exception => new JSONObject()
    }

    val result = fixResponse.getJSONObject("result")
    val list = result.getJSONArray("list")
    val jo = try {recalSim(list, rt_coords, pns_dist, rt_dist) } catch {case e: Exception => new JSONObject()}

    jo
  }


  /**
   * @note   任务维度逻辑计算
   */

  def parseTaskRep(list: List[JSONObject],line_distance:Double)= {
    var line_distance_core = 0.0
    var is_navi_core = 0.0
    var conduct_type_flag = 0

    // 增加分段权重占比
    list.map(x => {
      val part_line_distance = JSONUtils.getJsonValueDouble(x,"line_distance",0.0)
      val conduct_type = JSONUtils.getJsonValueInt(x,"conduct_type",1)
      val is_navi = JSONUtils.getJsonValueInt(x,"is_navi",0)

      val core = if (conduct_type == 1) 1 else 0
      val part_core =  (part_line_distance / line_distance) * core
      line_distance_core += part_core

      val navi_core = if (is_navi == 1) 1 else 0
      val part_core_navi =  (part_line_distance / line_distance) * core
      is_navi_core += part_core_navi

    })
    // 判断总得分是否大于0.85
    if (line_distance_core >= 0.85) conduct_type_flag = 1 else conduct_type_flag = 3
    conduct_type_flag

  }


  /**
   * @note   子任务维度执行标签
   */

  def parseTaskRep(line_distance:Double,is_navi:Int,pns_dist: Double,rt_dist: Double,sim1: Double,sim5: Double)= {

    // TODO: 20220926新增
    val conduct_type = (line_distance,is_navi) match {
      case (line_distance,is_navi) if (line_distance <= 5 && ((pns_dist <= 5000 && rt_dist <= 5000) || Math.abs(rt_dist - pns_dist) <= 2000 || (pns_dist <= 10000 && Math.max(sim1,sim5) >0.5 && Math.min(sim1,sim5) >=0.4) || (pns_dist > 10000 && Math.max(sim1,sim5) >0.6 && Math.min(sim1,sim5) >=0.5) || pns_dist <= 1000 || Math.max(sim1,sim5) >= 0.9)) => 1
      case (line_distance,is_navi) if (line_distance > 5 && line_distance <= 10 && ((Math.max(sim1,sim5) >=0.6 && Math.min(sim1,sim5) >= 0.5) || Math.max(sim1,sim5) >=0.9)) => 1
      case (line_distance,is_navi) if (line_distance > 10 && line_distance <= 50 && Math.max(sim1,sim5) > 0.75 && Math.min(sim1,sim5) >= 0.7) => 1
      case (line_distance,is_navi) if (line_distance > 50 && line_distance <= 100 && Math.max(sim1,sim5) > 0.8 && Math.min(sim1,sim5) >= 0.75) => 1
      case (line_distance,is_navi) if (line_distance > 100 && line_distance <= 500 && Math.max(sim1,sim5) > 0.85 && Math.min(sim1,sim5) >= 0.8) => 1
      case (line_distance,is_navi) if (line_distance > 500  && Math.max(sim1,sim5) > 0.9 && Math.min(sim1,sim5) >= 0.85) => 1
      case (line_distance,is_navi) if (( pns_dist <= 5000 && rt_dist <= 5000 && rt_dist!=0) || pns_dist == 0 || (pns_dist <= 10000 && Math.abs(rt_dist - pns_dist) <= 2000 && rt_dist!=0) ||
        ((rt_dist != 0 && Math.abs(rt_dist - pns_dist) <= 5000 && (Math.max(sim1,sim5) >= 0.75 || (Math.max(sim1,sim5) >0.7 && pns_dist <=20000) ))
          || (rt_dist != 0 && Math.abs(rt_dist - pns_dist) / rt_dist <= 0.05 && (Math.max(sim1,sim5) >= 0.75 || (Math.max(sim1,sim5) >0.7 && pns_dist <=20000))))) => 1
      case (line_distance,is_navi) if (is_navi==1) => 2
      case _ => 3
    }

    conduct_type


  }


  /**
   * @note   调用计算相似度
   */

  def schedulerSimilarityInterface(rt_coords:String ,std_coords:String) = {

    var sim1 = 0.0
    var sim5 = 0.0
    if (strNotNull(rt_coords) && strNotNull(std_coords)) {

//      val joArray1 = new JSONArray()
//      val array1 = try { JSON.parseArray(rt_coords)} catch {case e:Exception => new JSONArray()}

//      for (i <- 0 until (array1.size())) {
//        val json = array1.getJSONObject(i)
//        val x = json.getDouble("dx")
//        val y = json.getDouble("dy")
//        val arrayNew = new JSONArray()
//        arrayNew.add(x)
//        arrayNew.add(y)
//        joArray1.add(arrayNew)
//      }
      val joArray1 = try { JSON.parseArray(rt_coords)} catch {case e:Exception => new JSONArray()}
      val joArray2 = try { JSON.parseArray(std_coords)} catch {case e:Exception => new JSONArray()}


      val jo1 = new JSONObject()
      val jo2 = new JSONObject()

      jo1.put("rt_coords", joArray1)
      jo1.put("vehicle_type", "5")
      jo2.put("rt_coords", joArray2)

      var errLog = ""

      try {
        val sim = getSimilarInterface2.getSimilar2(jo1, jo2)
        sim1 = sim._1
        sim5 = sim._2
//        val sim = PathSimilar.simProcess(jo1, jo2)
//        //      val (sim1New,sim5New) = try{PathSimilar.simProcess(jo1,jo2)} catch {case e:Exception => (0.0,0.0)}
//        sim1 = sim.first
//        sim5 = sim.second
      } catch {
        case e: Exception => {
          errLog = e.getMessage
        }
      }

    }
    (sim1,sim5)

  }


  /** @note   调用历史轨迹接口*/
  def parseTrajRectify(rep:String):JSONObject = {
    val repJo = JSON.parseObject(rep)
    val result = repJo.getJSONObject("result")
    val data = result.getJSONObject("data")


    val jo = new JSONObject()


    //    val rt_coords_str = FileToString.fileCsv();
//    val rt_coords = JSON.parseArray(rt_coords_str)
    try {
      val rt_coords = data.getJSONArray("track")
      val rt_dist = data.getDouble("len")
      val highwaymileage = JSONUtils.getJsonValueInt(data.getJSONObject("rc_distance"),"0",0)

      val coordsBuffer = new ArrayBuffer[String]()
      val timeBuffer = new ArrayBuffer[String]()
      val jp_swidBuffer = new ArrayBuffer[String]()

      val joArray1 = new JSONArray()

    for (i <- (0 until(rt_coords.size())) if rt_coords.size()> 0){
        val x =  JSONUtils.getJsonValueDouble(rt_coords.getJSONObject(i), "dx", 0)
        val y =  JSONUtils.getJsonValueDouble(rt_coords.getJSONObject(i), "dy", 0)
        val time = JSONUtils.getJsonValue(rt_coords.getJSONObject(i), "tm", "0")

//        val time = rt_coords.getJSONObject(i).getString("tm")
//        val jp_swid = rt_coords.getJSONObject(i).getString("swid")

        val arrayNew = new JSONArray()
        arrayNew.add(x)
        arrayNew.add(y)
        joArray1.add(arrayNew)

//        coordsBuffer.append(x.toString + "," + y.toString)
        timeBuffer.append(time)
//        jp_swidBuffer.append(jp_swid)

    }


      jo.put("rt_coords",joArray1)
      jo.put("rt_time",timeBuffer.mkString("|"))
//      jo.put("jp_swid",jp_swidBuffer.mkString("|"))
      jo.put("rt_dist",rt_dist)
      jo.put("highwaymileage",highwaymileage)

    } catch {
      case e:Exception => {
        jo.put("rt_coords",new JSONArray())
        jo.put("rt_time","")
        jo.put("rt_dist",0)
        jo.put("highwaymileage",0)
      }
    }
    jo
  }


  /** @note   调用历史轨迹接口*/
  def parseTrajRectify2(rep:String):JSONObject = {
    val repJo = JSON.parseObject(rep)
    val result = repJo.getJSONObject("result")
    val data = result.getJSONObject("data")

    val jo = new JSONObject()

    //    val rt_coords_str = FileToString.fileCsv();
    //    val rt_coords = JSON.parseArray(rt_coords_str)
    try {
//      val rt_coords = data.getJSONArray("track")
      val rt_coords = sortJSONArrayByTM(data.getJSONArray("track"))

      val rt_dist = data.getDouble("len")
      val highwaymileage = JSONUtils.getJsonValueInt(data.getJSONObject("rc_distance"),"0",0)

      val coordsBuffer = new ArrayBuffer[String]()
      val timeBuffer = new ArrayBuffer[String]()
      val jp_swidBuffer = new ArrayBuffer[String]()

      val joArray1 = new JSONArray()
      val his_tracks = new JSONArray()


      for (i <- (0 until(rt_coords.size())) if rt_coords.size()> 0){
        val x =  JSONUtils.getJsonValueDouble(rt_coords.getJSONObject(i), "dx", 0)
        val y =  JSONUtils.getJsonValueDouble(rt_coords.getJSONObject(i), "dy", 0)
        val time = JSONUtils.getJsonValueInt(rt_coords.getJSONObject(i), "tm", 0)

        //        val time = rt_coords.getJSONObject(i).getString("tm")
        //        val jp_swid = rt_coords.getJSONObject(i).getString("swid")

        val arrayNew = new JSONArray()
        arrayNew.add(x)
        arrayNew.add(y)
        joArray1.add(arrayNew)

        //        coordsBuffer.append(x.toString + "," + y.toString)
        timeBuffer.append(time.toString)
        //        jp_swidBuffer.append(jp_swid)

        val jo = new JSONObject()
        val track = rt_coords.getJSONObject(i)
        val ac = JSONUtils.getJsonValueInt(track, "ac", 0)
        val be = JSONUtils.getJsonValueDouble(track, "be", 0)
        val index = i
        val sp = JSONUtils.getJsonValueDouble(track, "sp", 0)
        //        val time = JSONUtils.getJsonValueLong(track, "tm", 0)
        val zx = JSONUtils.getJsonValueDouble(track, "zx", 0)
        val zy = JSONUtils.getJsonValueDouble(track, "zy", 0)

        jo.put("accuracy", ac)
        jo.put("azimuth", be)
        jo.put("index", index)
        jo.put("speed", sp)
        jo.put("time", time)
        jo.put("type", 1)
        jo.put("x", zx)
        jo.put("y", zy)

        his_tracks.add(jo)
      }


      jo.put("rt_coords",joArray1)
      jo.put("rt_time",timeBuffer.mkString("|"))
      //    jo.put("jp_swid",jp_swidBuffer.mkString("|"))
      jo.put("rt_dist",rt_dist)
      jo.put("highwaymileage",highwaymileage)
      jo.put("his_tracks",his_tracks)

    } catch {
      case e:Exception => {
        jo.put("rt_coords",new JSONArray())
        jo.put("rt_time","")
        jo.put("rt_dist",0)
        jo.put("highwaymileage",0)
        jo.put("his_tracks",new JSONArray())
      }
    }
    jo
  }


  def sortJSONArrayByTM(jsonArray: JSONArray) = {
    val scalaJsonArray = jsonArray.sortBy(_.asInstanceOf[JSONObject].getLongValue("tm"))

    val jsonArrayNew = new JSONArray()
    scalaJsonArray.foreach(jsonArrayNew.add)
    jsonArrayNew
  }



  def parseStaLineRep(response: String)= {
    val jo = new JSONObject()

    try{
      val resp = JSON.parseObject(response)
      val result = resp.getJSONObject("result")
      val linePassZoneInfoDtos = try {result.getJSONArray("linePassZoneInfoDtos").getJSONObject(0)} catch {case e:Exception => new JSONObject()}
      val stdLineData = try {linePassZoneInfoDtos.getJSONObject("stdLineData")} catch {case e:Exception => new JSONObject()}
      val pns_dist = stdLineData.getString("pnsDist")
      val pns_time = stdLineData.getString("pnsTime")
      val std_coords = stdLineData.getString("coords")
      val line_distance_std = stdLineData.getString("dist")
      val line_time_std = stdLineData.getString("time")

      //20211011增加统计字段
      val std_id = linePassZoneInfoDtos.getString("stdId")

      val isEcon = stdLineData.getString("isEcon")

      //20211118增加统计字段std_toll_charge
      val std_toll_charge = stdLineData.getString("tolls")

      jo.put("pns_dist",pns_dist)
      jo.put("pns_time",pns_time)
      jo.put("src",isEcon)
      jo.put("std_coords",std_coords)
      jo.put("line_distance_std",line_distance_std)
      jo.put("line_time_std",line_time_std)

      jo.put("std_id",std_id)
      jo.put("std_toll_charge",std_toll_charge)

    } catch {
      case e:Exception =>
        if (e.toString.contains("轨迹点为空")){
          jo.put("err","轨迹点为空")
        }else {
          jo.put("err", e.toString + "++++" + response)
        }
    }
    jo
  }



  def schedulerStaInterface(x: JSONObject) = {

    //        val url = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/query"
    val url = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/queryByLineRequireId"

    val jo = new JSONObject()

    val start_dept = x.getString("start_dept")
    val end_dept = x.getString("end_dept")
    val line_code = x.getString("line_code")
    val start_time = x.getString("start_time")

    //        //20220316新增
    //        val x1 = x.getString("start_longitude")
    //        val y1 = x.getString("start_latitude")
    val x2 = JSONUtils.getJsonValueDouble(x,"end_longitude",0.0).toString
    val y2 = JSONUtils.getJsonValueDouble(x,"end_latitude",0.0).toString


    //20220823
    val start_outer_add_code = x.getString("start_outer_add_code")
    val end_outer_add_code = x.getString("end_outer_add_code")
    val start_sortnum = x.getString("start_sortnum")
    val end_sortnum = x.getString("end_sortnum")


    val line_require_id = x.getString("line_require_id")

    val actual_capacity_load = try {
      x.getString("actual_capacity_load").replaceAll("T", "")
    } catch {
      case e: Exception => ""
    }

    jo.put("ak", "4dc00a88a1f34bffa49a153103458efc")
    jo.put("lineRequireId",line_require_id)

    val linePassZoneInfoDtos = new JSONArray()
    val lineDtoJo = new JSONObject()
    lineDtoJo.put("sortNum",end_sortnum)
    if (strNotNull(end_outer_add_code)) lineDtoJo.put("passZoneCode",end_outer_add_code) else lineDtoJo.put("passZoneCode",end_dept)
    if (strNotNull(end_outer_add_code)) lineDtoJo.put("passAddrCode",end_outer_add_code)

    // TODO: 增加 passCoordinate字段
    lineDtoJo.put("passCoordinate",x2 + "," + y2)

    linePassZoneInfoDtos.add(lineDtoJo)

    jo.put("linePassZoneInfoDtos",linePassZoneInfoDtos)

    //        jo.put("opt", "std2")
    //        jo.put("compensateTime", 1)
    //        jo.put("srcZoneCode", start_dept)
    //        jo.put("destZoneCode", end_dept)
    //        jo.put("lineCode", line_code)
    //        jo.put("planTime", start_time)
    //        jo.put("mLoad", actual_capacity_load)
    //        jo.put("x1",x1)
    //        jo.put("y1",y1)
    //        jo.put("x2",x2)
    //        jo.put("y2",y2)
    //val response = Utils.post(url, jo, "utf-8")
//    val response = HttpUtils.doPost(url, jo)
    val response = ""

    var repJson = new JSONObject()

//    repJson = try {
//      parseStaLineRep(x, response)
//    } catch {
//      case e: Exception =>
//        if (e.toString.contains("轨迹点为空")){
//          x.put("err","轨迹点为空")
//        }else {
//          x.put("err", "Exception")
//        }
//        x
//    }
    repJson

  }




  }
