package com.sf.app.etastd

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{colTrimNotNull, strNotNull}
import utils.DateUtil.{getdaysBeforeOrAfter, getdaysBeforeOrAfterUDF}
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: 742792
 * @description: 线路时效变更指标监控 dm_gis.eta_std_acc_speed_monitor_change_indicate
 * @demander: ft80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/5/9 15:56
 */
object EficientStandLineAcceleratePropotion extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    procPropotion(spark, inc_day) //12636  5min
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def procPropotion(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val day_7_ago = getdaysBeforeOrAfter(inc_day, -6)
    val day_15_ago = getdaysBeforeOrAfter(inc_day, -14)

    val group_cols = Seq("line_code", "direction", "transoport_level", "load_zone_code", "dest_zone_code", "revise_run_tm_pre", "expiration_date_pre", "effective_date_pre", "revise_run_tm_bef", "expiration_date_bef", "effective_date_bef", "static_sp", "load_area_code", "is_standard").map(col)
    val res_cols = Seq("line_code", "direction", "transoport_level", "load_zone_code", "dest_zone_code", "revise_run_tm_pre", "expiration_date_pre", "effective_date_pre", "revise_run_tm_bef", "expiration_date_bef", "effective_date_bef", "bef_task_cnt", "bef_ontime_task_cnt", "bef_exe_task_cnt", "bef_dynamic_link_task_cnt", "aft_task_cnt", "aft_batch", "aft_ontime_task_cnt", "aft_exe_task_cnt", "aft_dynamic_link_task_cnt", "aft_ontime_ratio", "aft_exe_ratio", "aft_dynamic_coninc_ratio", "bef_ontime_ratio", "bef_exe_ratio", "bef_dynamic_coninc_ratio", "is_static_batch_flag", "static_batch", "ontime_change", "exe_change", "dynamic_coninc_change", "change_type", "change_time", "static_sp", "load_area_code", "is_standard")
    val filter_fun: String => Boolean = c => c.startsWith("bef_") || c.startsWith("aft_") || (c.startsWith("is_") && c != "is_standard") || (c.startsWith("static_") && c != "static_sp") || c.startsWith("ontime_") || c.startsWith("exe_") || c.startsWith("change_") || c.startsWith("dynamic_")
    val rec_cols = spark.sql("""select * from dm_gis.eta_std_acc_speed_monitor_change_indicate limit 0""").schema.map(_.name).map(col)

    val o_sp_monitor_df = spark.sql(
      s"""select line_code,direction,change_type,transoport_level,load_zone_code,dest_zone_code,revise_run_tm_pre,revise_run_tm_bef,effective_date_bef,expiration_date_pre,
         |actual_depart_tm,regexp_replace(substr(actual_depart_tm, 0,10),'-','') reg_actual_depart_tm,
         |expiration_date_bef,regexp_replace(expiration_date_bef,'-','') reg_expiration_date_bef,
         |effective_date_pre,regexp_replace(effective_date_pre,'-','') reg_effective_date_pre,
         |taskid_type,plan_arrive_batch,actual_arrive_batch,ac_is_run_ontime,conduct_type,change_time,line_time,static_sp,load_area_code,is_standard
         |from dm_gis.eta_std_acc_speed_monitor where inc_day='$inc_day'
         |and line_code is not null and trim(line_code)!=''
         |and actual_send_batch is not null and trim(actual_send_batch)!=''
         |and actual_arrive_batch is not null and trim(actual_arrive_batch)!=''
         |""".stripMargin)
      .na.fill("", Seq("taskid_type", "actual_depart_tm", "revise_run_tm_bef", "reg_expiration_date_bef", "reg_effective_date_pre"))
      .withColumn("d7_tm", getdaysBeforeOrAfterUDF(-6)('reg_expiration_date_bef))
      .withColumn("d15_tm", getdaysBeforeOrAfterUDF(-14)('reg_expiration_date_bef))
      .withColumn("d7_tm_pre", getdaysBeforeOrAfterUDF(-6)('reg_effective_date_pre))
      .withColumn("d15_tm_pre", getdaysBeforeOrAfterUDF(-14)('reg_effective_date_pre))
      .repartition(400)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error(">>加载的数据总量>>>>" + o_sp_monitor_df.count())

    val p1_filter_cond = expr(s"""(taskid_type = '调整前任务' and line_time != revise_run_tm/60) or (taskid_type = '调整后任务' and line_time = revise_run_tm/60)""".stripMargin)
    val p1_filter7_cond = expr(s"""(taskid_type = '调整前任务' and line_time != revise_run_tm/60 and reg_actual_depart_tm between d7_tm and reg_expiration_date_bef) or (taskid_type = '调整后任务' and line_time = revise_run_tm/60 and reg_actual_depart_tm between '$day_7_ago' and '$inc_day')""".stripMargin)
    val p1_filter15_cond = expr(s"""(taskid_type = '调整前任务' and line_time != revise_run_tm/60 and reg_actual_depart_tm between d15_tm and reg_expiration_date_bef) or (taskid_type = '调整后任务' and line_time = revise_run_tm/60 and reg_actual_depart_tm between '$day_15_ago' and '$inc_day')""".stripMargin)

    val p2_filter_cond = expr(s"""(taskid_type = '调整前标准时效任务' and line_time != revise_run_tm/60) or (taskid_type = '调整后任务' and line_time = revise_run_tm/60)""".stripMargin)
    val p2_filter7_cond = expr(s"""(taskid_type = '调整前标准时效任务' and line_time != revise_run_tm/60 and reg_actual_depart_tm between d7_tm_pre and reg_effective_date_pre) or (taskid_type = '调整后任务' and line_time = revise_run_tm/60 and reg_actual_depart_tm between '$day_7_ago' and '$inc_day')""".stripMargin)
    val p2_filter15_cond = expr(s"""(taskid_type = '调整前标准时效任务' and line_time != revise_run_tm/60 and reg_actual_depart_tm between d15_tm_pre and reg_effective_date_pre) or (taskid_type = '调整后任务' and line_time = revise_run_tm/60 and reg_actual_depart_tm between '$day_15_ago' and '$inc_day')""".stripMargin)

    val p1_1_df = o_sp_monitor_df.filter(colTrimNotNull('revise_run_tm_bef) && p1_filter_cond).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val p1_7_df = o_sp_monitor_df.filter(colTrimNotNull('revise_run_tm_bef) && p1_filter7_cond).na.fill("")
    //    val p1_7f_df = filterDataFm(spark, p1_7_df, group_cols).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val p1_15_df = o_sp_monitor_df.filter(colTrimNotNull('revise_run_tm_bef) && p1_filter15_cond).na.fill("")
    //    val p1_15f_df = filterDataFm(spark, p1_15_df, group_cols).na.fill("").na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)

    val aa_1 = dealReviseTimeNotNull(spark, p1_1_df, group_cols, "", filter_fun).select(res_cols.map(col): _*).na.fill("")
    val aa_7 = dealReviseTimeNotNull(spark, p1_7_df, group_cols, "d7_", filter_fun).select(res_cols.map(c => if (c.startsWith("bef_") || c.startsWith("aft_") || (c.startsWith("is_") && c != "is_standard") || (c.startsWith("static_") && c != "static_sp") || c.startsWith("ontime_") || c.startsWith("exe_") || c.startsWith("change_") || c.startsWith("dynamic_")) "d7_" + c else c).map(col): _*).na.fill("")
    val aa_15 = dealReviseTimeNotNull(spark, p1_15_df, group_cols, "d15_", filter_fun).select(res_cols.map(c => if (c.startsWith("bef_") || c.startsWith("aft_") || (c.startsWith("is_") && c != "is_standard") || (c.startsWith("static_") && c != "static_sp") || c.startsWith("ontime_") || c.startsWith("exe_") || c.startsWith("change_") || c.startsWith("dynamic_")) "d15_" + c else c).map(col): _*).na.fill("")

    val p2_1_df = o_sp_monitor_df.filter(trim('revise_run_tm_bef) === "" && p2_filter_cond).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val p2_7_df = o_sp_monitor_df.filter(trim('revise_run_tm_bef) === "" && p2_filter7_cond).na.fill("")
    //    val p2_7f_df = filterDataFm(spark, p2_7_df, group_cols).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)
    val p2_15_df = o_sp_monitor_df.filter(trim('revise_run_tm_bef) === "" && p2_filter15_cond).na.fill("")
    //    val p2_15f_df = filterDataFm(spark, p2_15_df, group_cols).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)

    val bb_1 = dealReviseTimeIsNull(spark, p2_1_df, group_cols, "", filter_fun).select(res_cols.map(col): _*).na.fill("")
    val bb_7 = dealReviseTimeIsNull(spark, p2_7_df, group_cols, "d7_", filter_fun).select(res_cols.map(c => if (c.startsWith("bef_") || c.startsWith("aft_") || (c.startsWith("is_") && c != "is_standard") || (c.startsWith("static_") && c != "static_sp") || c.startsWith("ontime_") || c.startsWith("exe_") || c.startsWith("change_") || c.startsWith("dynamic_")) "d7_" + c else c).map(col): _*).na.fill("")
    val bb_15 = dealReviseTimeIsNull(spark, p2_15_df, group_cols, "d15_", filter_fun).select(res_cols.map(c => if (c.startsWith("bef_") || c.startsWith("aft_") || (c.startsWith("is_") && c != "is_standard") || (c.startsWith("static_") && c != "static_sp") || c.startsWith("ontime_") || c.startsWith("exe_") || c.startsWith("change_") || c.startsWith("dynamic_")) "d15_" + c else c).map(col): _*).na.fill("")

    val res = aa_1.union(bb_1)
      .join(broadcast(aa_7.union(bb_7)), Seq(group_cols.map(_.toString()): _*), "left")
      .join(broadcast(aa_15.union(bb_15)), Seq(group_cols.map(_.toString()): _*), "left")
      .na.fill("", Seq("revise_run_tm_bef"))
      .withColumn("inc_day", lit(inc_day))
      .withColumn("fix_period", lit(""))
      .withColumn("ontime_ratio_change", lit(""))
      .select(rec_cols: _*)

    val df1_res = res.filter(colTrimNotNull('revise_run_tm_bef)).select(rec_cols: _*).na.fill("")
    val df2_res = res.filter(trim('revise_run_tm_bef) === "").select(rec_cols: _*).na.fill("").persist(StorageLevel.MEMORY_AND_DISK_SER)

    val get_new_bef_tm = p2_1_df.filter('taskid_type === "调整前标准时效任务")
      .groupBy("line_time", "line_code")
      .agg(count("line_time") as "cnt")
      .withColumn("num", row_number().over(Window.partitionBy("line_code").orderBy('cnt.desc)))
      .filter("num = 1").drop("num", "cnt")
      .withColumnRenamed("line_time", "revise_run_tm_bef")
      .select("line_code", "revise_run_tm_bef")

    val new_df2_res = df2_res.drop("revise_run_tm_bef").join(broadcast(get_new_bef_tm), Seq("line_code"), "left")
      .withColumn("ontime_ratio_change", lit(""))
      .select(rec_cols: _*).na.fill("")

    val last_res = df1_res.union(new_df2_res)
      .na.fill("", Seq("effective_date_pre", "d7_aft_ontime_ratio", "d7_bef_ontime_ratio"))
      .withColumn("fix_period", getEffectiveUdf('effective_date_pre, 'inc_day))
      .withColumn("ontime_ratio_change", getrRatioChangeUdf('d7_aft_ontime_ratio, 'd7_bef_ontime_ratio))
      .withColumn("d7_bef_ontime_ratio", concat(round(lit(100) * 'd7_bef_ontime_ratio, 2), lit("%")))
      .withColumn("d7_bef_dynamic_coninc_ratio", concat(round(lit(100) * 'd7_bef_dynamic_coninc_ratio, 2), lit("%")))
      .withColumn("d7_aft_ontime_ratio", concat(round(lit(100) * 'd7_aft_ontime_ratio, 2), lit("%")))
      .withColumn("d7_aft_dynamic_coninc_ratio", concat(round(lit(100) * 'd7_aft_dynamic_coninc_ratio, 2), lit("%")))
      .select(rec_cols: _*).na.fill("")
    writeToHive(spark, last_res, Seq("inc_day"), "dm_gis.eta_std_acc_speed_monitor_change_indicate")
  }


  def getrRatioChangeUdf = udf((d7_aft_ontime_ratio: String, d7_bef_ontime_ratio: String) => {
    var ontime_ratio_change = ""
    try {
      val bef = if (strNotNull(d7_bef_ontime_ratio)) d7_bef_ontime_ratio.toDouble else 0.0
      val aft = if (strNotNull(d7_aft_ontime_ratio)) d7_aft_ontime_ratio.toDouble else 0.0
      if (aft > bef) ontime_ratio_change = "提升"
      if (aft < bef) ontime_ratio_change = "下降"
      if (aft == bef) ontime_ratio_change = "相等"
    } catch {
      case e: Exception => "" + e
    }
    ontime_ratio_change
  })

  def getEffectiveUdf = udf((effective_date_pre: String, inc_day: String) => {
    var res = ""
    val day_7_ago = getdaysBeforeOrAfter(inc_day, -6)
    val day_15_ago = getdaysBeforeOrAfter(day_7_ago, -7)
    val day_30_ago = getdaysBeforeOrAfter(day_15_ago, -15)
    try {
      if (strNotNull(effective_date_pre)) {
        val tm = effective_date_pre.replaceAll("-", "")
        if (tm >= day_7_ago && tm <= inc_day) {
          res = "最近一周更新"
        } else if (tm >= day_15_ago && tm < day_7_ago) {
          res = "最近两周周更新"
        } else if (tm >= day_30_ago && tm < day_15_ago) {
          res = "最近一个月更新"
        } else {
          res = "更新时间一个月以上"
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    res
  })

  def filterDataFm(spark: SparkSession, df: DataFrame, group_cols: Seq[Column]): DataFrame = {
    import spark.implicits._
    val tmp_df = df.groupBy(group_cols :+ col("taskid_type"): _*).agg(count("taskid_type") as "cnt")
      .withColumn("flag", when('cnt >= 3, 1).otherwise(0))
      .groupBy(group_cols: _*).agg(sum("flag") as "flag").filter('flag > 1)
      .select(group_cols: _*).na.fill("")
    df.join(broadcast(tmp_df), Seq(group_cols.map(_.toString()): _*))
  }

  def dealReviseTimeNotNull(spark: SparkSession, p1_df: DataFrame, group_cols: Seq[Column], pre_fix: String, filter_fun: String => Boolean): DataFrame = {
    import spark.implicits._
    val bef_aft_cols_str = Seq("bef_task_cnt", "bef_ontime_task_cnt", "bef_exe_task_cnt", "bef_dynamic_link_task_cnt", "aft_task_cnt", "aft_batch", "aft_ontime_task_cnt", "aft_exe_task_cnt", "aft_dynamic_link_task_cnt", "change_type", "change_time")
    val bef_aft_cols = aggSumOrMaxCols(bef_aft_cols_str)
    val p2_df = p1_df
      .withColumn("aft_task_cnt", when('taskid_type === "调整后任务", 1).otherwise(0))
      .withColumn("aft_ontime_task_cnt", when('taskid_type === "调整后任务" && 'ac_is_run_ontime === "1.0", 1).otherwise(0))
      .withColumn("aft_exe_task_cnt", when('taskid_type === "调整后任务" && 'conduct_type === "1", 1).otherwise(0))
      .withColumn("aft_dynamic_link_task_cnt", when('taskid_type === "调整后任务" && 'plan_arrive_batch === 'actual_arrive_batch, 1).otherwise(0))
      .withColumn("aft_batch", when('taskid_type === "调整后任务", 'actual_arrive_batch).otherwise(""))
      .withColumn("bef_task_cnt", when('taskid_type === "调整前任务", 1).otherwise(0))
      .withColumn("bef_ontime_task_cnt", when('taskid_type === "调整前任务" && 'ac_is_run_ontime === "1.0", 1).otherwise(0))
      .withColumn("bef_exe_task_cnt", when('taskid_type === "调整前任务" && 'conduct_type === "1", 1).otherwise(0))
      .withColumn("bef_dynamic_link_task_cnt", when('taskid_type === "调整前任务" && 'plan_arrive_batch === 'actual_arrive_batch, 1).otherwise(0))
      .groupBy(group_cols: _*)
      .agg(bef_aft_cols.head, bef_aft_cols.tail: _*)
      .withColumn("aft_ontime_ratio", 'aft_ontime_task_cnt / 'aft_task_cnt)
      .withColumn("aft_exe_ratio", 'aft_exe_task_cnt / 'aft_task_cnt)
      .withColumn("aft_dynamic_coninc_ratio", 'aft_dynamic_link_task_cnt / 'aft_task_cnt)
      .withColumn("bef_ontime_ratio", 'bef_ontime_task_cnt / 'bef_task_cnt)
      .withColumn("bef_exe_ratio", 'bef_exe_task_cnt / 'bef_task_cnt)
      .withColumn("bef_dynamic_coninc_ratio", 'bef_dynamic_link_task_cnt / 'bef_task_cnt)
      .na.fill("", Seq("aft_ontime_ratio", "aft_exe_ratio", "aft_dynamic_coninc_ratio", "bef_ontime_ratio", "bef_exe_ratio", "bef_dynamic_coninc_ratio"))
      .withColumn("ontime_change", getBefAndAftChange('bef_ontime_ratio, 'aft_ontime_ratio))
      .withColumn("exe_change", getBefAndAftChange('bef_exe_ratio, 'aft_exe_ratio))
      .withColumn("dynamic_coninc_change", getBefAndAftChange('bef_dynamic_coninc_ratio, 'aft_dynamic_coninc_ratio))

    val static_quota_df = p1_df.groupBy(group_cols ++ Seq(col("taskid_type"), col("plan_arrive_batch")): _*)
      .agg(count("plan_arrive_batch") as "cnt")
      .withColumn("num", row_number().over(Window.partitionBy(group_cols :+ col("taskid_type"): _*).orderBy('cnt.desc)))
      .filter("num = 1")
      .withColumn("bef_batch", when('taskid_type === "调整前任务", 'plan_arrive_batch).otherwise("-"))
      .withColumn("aft_batch", when('taskid_type === "调整后任务", 'plan_arrive_batch).otherwise("-"))
      .groupBy(group_cols: _*)
      .agg(max("bef_batch") as "bef_batch", max("aft_batch") as "aft_batch")
      .withColumn("is_static_batch_flag", when('aft_batch === 'bef_batch, "N").otherwise("Y"))
      .withColumn("static_batch", concat_ws("-", 'bef_batch, 'aft_batch))
      .select(group_cols ++ Seq("is_static_batch_flag", "static_batch").map(col): _*)

    val p1_res_df = p2_df.join(static_quota_df, Seq(group_cols.map(_.toString()): _*))
    if (pre_fix == "") {
      p1_res_df
    } else {
      val originalColumns = p1_res_df.columns.filter(filter_fun)
      val newColumns = originalColumns.filter(filter_fun).map(pre_fix + _)
      val renamedDF = originalColumns.zip(newColumns).foldLeft(p1_res_df) {
        case (accDF, (oldCol, newCol)) => accDF.withColumn(newCol, p1_res_df(oldCol).alias(newCol)).drop(oldCol)
      }
      renamedDF
    }
  }

  def dealReviseTimeIsNull(spark: SparkSession, p2_df: DataFrame, group_cols: Seq[Column], pre_fix: String, filter_fun: String => Boolean): DataFrame = {
    import spark.implicits._
    val filter_p2_df = p2_df.select(group_cols :+ col("line_time"): _*)
      .groupBy(group_cols :+ col("line_time"): _*)
      .agg(count("line_time") as "cnt").filter('cnt >= 2)
      .groupBy(group_cols: _*).agg(lit(1))
      .select(group_cols: _*).na.fill("", group_cols.map(_.toString()))

    val bef_aft_cols_str = Seq("bef_task_cnt", "bef_ontime_task_cnt", "bef_exe_task_cnt", "bef_dynamic_link_task_cnt", "aft_task_cnt", "aft_batch", "aft_ontime_task_cnt",
      "aft_exe_task_cnt", "aft_dynamic_link_task_cnt", "bef_line_time", "aft_line_time")

    val bef_aft_cols = aggSumOrMaxT2Cols(bef_aft_cols_str)
    val p2_tmp_df = p2_df.join(broadcast(filter_p2_df), Seq(group_cols.map(_.toString()): _*))
      .withColumn("aft_task_cnt", when('taskid_type === "调整后任务", 1).otherwise(0))
      .withColumn("aft_ontime_task_cnt", when('taskid_type === "调整后任务" && 'ac_is_run_ontime === "1.0", 1).otherwise(0))
      .withColumn("aft_exe_task_cnt", when('taskid_type === "调整后任务" && 'conduct_type === "1", 1).otherwise(0))
      .withColumn("aft_dynamic_link_task_cnt", when('taskid_type === "调整后任务" && 'plan_arrive_batch === 'actual_arrive_batch, 1).otherwise(0))
      .withColumn("aft_batch", when('taskid_type === "调整后任务", 'actual_arrive_batch).otherwise(""))
      .withColumn("bef_task_cnt", when('taskid_type === "调整前标准时效任务", 1).otherwise(0))
      .withColumn("bef_ontime_task_cnt", when('taskid_type === "调整前标准时效任务" && 'ac_is_run_ontime === "1.0", 1).otherwise(0))
      .withColumn("bef_exe_task_cnt", when('taskid_type === "调整前标准时效任务" && 'conduct_type === "1", 1).otherwise(0))
      .withColumn("bef_dynamic_link_task_cnt", when('taskid_type === "调整前标准时效任务" && 'plan_arrive_batch === 'actual_arrive_batch, 1).otherwise(0))
      .withColumn("bef_line_time", when('taskid_type === "调整前标准时效任务", 'line_time).otherwise(""))
      .withColumn("aft_line_time", when('taskid_type === "调整后任务", 'line_time).otherwise(""))
      .groupBy(group_cols: _*)
      .agg(bef_aft_cols.head, bef_aft_cols.tail: _*)
      .withColumn("aft_ontime_ratio", 'aft_ontime_task_cnt / 'aft_task_cnt)
      .withColumn("aft_exe_ratio", 'aft_exe_task_cnt / 'aft_task_cnt)
      .withColumn("aft_dynamic_coninc_ratio", 'aft_dynamic_link_task_cnt / 'aft_task_cnt)
      .withColumn("bef_ontime_ratio", 'bef_ontime_task_cnt / 'bef_task_cnt)
      .withColumn("bef_exe_ratio", 'bef_exe_task_cnt / 'bef_task_cnt)
      .withColumn("bef_dynamic_coninc_ratio", 'bef_dynamic_link_task_cnt / 'bef_task_cnt)
      .na.fill("", Seq("aft_ontime_ratio", "aft_exe_ratio", "aft_dynamic_coninc_ratio", "bef_ontime_ratio", "bef_exe_ratio", "bef_dynamic_coninc_ratio"))
      .withColumn("ontime_change", getBefAndAftChange('bef_ontime_ratio, 'aft_ontime_ratio))
      .withColumn("exe_change", getBefAndAftChange('bef_exe_ratio, 'aft_exe_ratio))
      .withColumn("dynamic_coninc_change", getBefAndAftChange('bef_dynamic_coninc_ratio, 'aft_dynamic_coninc_ratio))
      .withColumn("change_time", abs('aft_line_time - 'bef_line_time))
      .withColumn("change_type", when('revise_run_tm_pre - 'bef_line_time > 0, "时效延迟").otherwise("时效压缩"))

    val static_quota_df = p2_df.groupBy(group_cols ++ Seq(col("taskid_type"), col("plan_arrive_batch")): _*)
      .agg(count("plan_arrive_batch") as "cnt")
      .withColumn("num", row_number().over(Window.partitionBy(group_cols :+ col("taskid_type"): _*).orderBy('cnt.desc)))
      .filter("num = 1")
      .withColumn("bef_batch", when('taskid_type === "调整前任务", 'plan_arrive_batch).otherwise(""))
      .withColumn("aft_batch", when('taskid_type === "调整后任务", 'plan_arrive_batch).otherwise(""))
      .groupBy(group_cols: _*)
      .agg(max("bef_batch") as "bef_batch", max("aft_batch") as "aft_batch")
      .withColumn("is_static_batch_flag", when('aft_batch === 'bef_batch, "Y").otherwise("N"))
      .withColumn("static_batch", concat_ws("-", 'bef_batch, 'aft_batch))
      .select(group_cols ++ Seq("is_static_batch_flag", "static_batch").map(col): _*)

    val p2_res_df = p2_tmp_df.join(static_quota_df, Seq(group_cols.map(_.toString()): _*))

    if (pre_fix == "") {
      p2_res_df
    } else {
      val originalColumns = p2_res_df.columns.filter(filter_fun)
      // 创建新的列名列表，加上前缀
      val newColumns = originalColumns.filter(filter_fun).map(pre_fix + _)
      // 使用withColumn方法批量添加前缀
      val renamedDF = originalColumns.zip(newColumns).foldLeft(p2_res_df) { case (accDF, (oldCol, newCol)) =>
        accDF.withColumn(newCol, p2_res_df(oldCol).alias(newCol)).drop(oldCol)
      }
      renamedDF
    }
  }

  def getBefAndAftChange = udf((bef_info: String, aft_info: String) => {
    var res = "未变"
    val bef = try {
      bef_info.toDouble
    } catch {
      case e: Exception => 0.0
    }
    val aft = try {
      aft_info.toDouble
    } catch {
      case e: Exception => 0.0
    }
    val diff = aft - bef
    if (diff > 0) res = "提升_" + (diff * 100).toInt + "%" else if (diff < 0) res = "下降_" + (diff * 100).abs.toInt + "%"
    res
  })

  def aggSumOrMaxCols(part_cols_str: Seq[String]): Seq[Column] = {
    val no_seq_cols: Seq[Column] = part_cols_str.map(x => {
      if (x.contains("_batch") || x.contains("change_")) max(col(x)) else sum(col(x))
    })
    ColumnUtil.renameColumn(no_seq_cols, part_cols_str)
  }

  def aggSumOrMaxT2Cols(part_cols_str: Seq[String]): Seq[Column] = {
    val no_seq_cols: Seq[Column] = part_cols_str.map(x => {
      if (x.contains("_batch") || x.contains("_line_time")) max(col(x)) else sum(col(x))
    })
    ColumnUtil.renameColumn(no_seq_cols, part_cols_str)
  }

}
