package com.sf.app.veh

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.HTPP_RGEO_X_Y_G
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.lngLatToDistance
import utils.DateUtil.timeToTimestamp1
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @description: EOS-VCMP-CORE：燃油消耗数据需求_V1.0 停车熄火结果表 450234
 * @author 01418539 caojia
 * @date 2022/5/24 14:38
 */

object VehicleFuelConsumGrdDetail_V2 extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    process2(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def process2(spark: SparkSession, start_day: String, end_day: String): Unit = {
    import spark.implicits._
    val step2_vehicle = spark.sql(
      s"""
         |select *
         |from dm_gis.dwd_vehicle_fuel_consum_flame_out_step_dtl
         |where inc_day >= '$start_day' and inc_day <= '$end_day'
         |""".stripMargin)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //part 2 经纬度带出信息
    val o_polygon = spark.sql(
      s"""
         |select code as zone_code,lng zone_code_x,lat zone_code_y,create_tm
         |from dm_gis.polygon_all
         |where inc_day >= '$start_day' and inc_day <= '$end_day'
         |      and code is not null and trim(code) != ''
         |      and lng is not null and trim(lng) != ''
         |      and lat is not null and trim(lat) != ''
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy("zone_code").orderBy(desc("create_tm"))))
      .filter('num === 1)

    val ak = "b61f6c427934416dbc3248dbefef5eb0"

    val filter_cond = (trim('parkf_start_x) === "" || trim('parkf_start_y) === "") && (trim('parkf_end_x) === "" || trim('parkf_end_y) === "")

    val httpInvoke = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "450234", "【EOS-VCMP-CORE】燃油V2熄火时长", "根据经纬度获取停留点信息", HTPP_RGEO_X_Y_G, "b61f6c427934416dbc3248dbefef5eb0", step2_vehicle.count(), 50)
    val start_end_json = step2_vehicle
      .select("parkf_start_x", "parkf_start_y", "parkf_end_x", "parkf_end_y")
      .filter(!filter_cond)
      .withColumn("num", row_number().over(Window.partitionBy("parkf_start_x", "parkf_start_y", "parkf_end_x", "parkf_end_y").orderBy("parkf_start_x")))
      .filter('num === 1).repartition(5)
      .map(row => {
        val parkf_start_x = row.getAs[String]("parkf_start_x")
        val parkf_start_y = row.getAs[String]("parkf_start_y")

        val parkf_end_x = row.getAs[String]("parkf_end_x")
        val parkf_end_y = row.getAs[String]("parkf_end_y")

        var parkf_start_place = ""
        var parkf_end_place = ""
        var start_place_name = ""
        var end_place_name = ""
        try {
          if (parkf_start_x.trim != "" && parkf_start_y.trim != "") {
            val start_url = String.format(HTPP_RGEO_X_Y_G, parkf_start_x, parkf_start_y, ak)
            parkf_start_place = HttpInvokeUtil.sendGet(start_url, "UTF-8", 3)
            val start_resp_json = JSON.parseObject(parkf_start_place)
            start_place_name = start_resp_json.getJSONObject("result").getString("name")
            logger.info(s"start的get请求返回的json为：" + parkf_start_place)
          }
        } catch {
          case e: Exception => logger.error(s"$parkf_start_x and $parkf_start_y 返回信息有异常" + e.getMessage)
        }

        try {
          if (parkf_end_x.trim != "" && parkf_end_y.trim != "") {
            val end_url = String.format(HTPP_RGEO_X_Y_G, parkf_end_x, parkf_end_y, ak)
            parkf_end_place = HttpInvokeUtil.sendGet(end_url, "UTF-8", 3)
            val end_resp_json = JSON.parseObject(parkf_end_place)
            end_place_name = end_resp_json.getJSONObject("result").getString("name")
            logger.info(s"end的get请求返回的json为：" + parkf_end_place)
          }
        } catch {
          case e: Exception => logger.error(s"$parkf_end_x and $parkf_end_y 返回信息有异常" + e.getMessage)
        }
        (parkf_start_x, parkf_start_y, parkf_end_x, parkf_end_y, parkf_start_place, start_place_name, parkf_end_place, end_place_name)
      }).toDF("parkf_start_x", "parkf_start_y", "parkf_end_x", "parkf_end_y", "parkf_start_place", "start_place_name", "parkf_end_place", "end_place_name")
      .persist()
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke)
    //stop_over_zone_code 切分后去重
    val splitFun = udf((info: String) => {
      var res: Array[String] = Array("")
      try {
        if (info.trim != "" && !info.isEmpty) {
          res = info.split(",").toSet.toArray
        }
      } catch {
        case e: Exception => logger.error("异常检查", e)
      }
      res
    })
    //怠速类型（1：始发装货怠速，2：经停装卸货怠速，3：目的网点卸货怠速，4：其他情况）
    val parkf_type_cd = when('isnear_zone === 1 && timeToTimestamp1('parkf_end_time).cast("long") - 5 * 60 <= timeToTimestamp1('actual_depart_tm).cast("long") && timeToTimestamp1('parkf_start_time).cast("long") + 5 * 60 > timeToTimestamp1('begindatetime).cast("long"), "1")
      .when(trim('zone_code) =!= "" && 'zone_code =!= 'src_zone_code && 'zone_code =!= 'dest_zone_code, "2")
      .when('parkf_start_time > 'actual_arrive_tm && 'parkf_end_time <= 'enddatetime, "3")
      .otherwise("4")

    //结果表 的字段信息数据
    val res_distance = spark.sql("""select * from dm_gis.dwd_vehicle_fuel_consum_distance_dtl limit 1""")
    val res_cols = res_distance.schema.map(_.name).map(col)

    val res = step2_vehicle.join(start_end_json, Seq("parkf_start_x", "parkf_start_y", "parkf_end_x", "parkf_end_y"), "left")
      .withColumn("zone_code", explode(splitFun('stop_over_zone_code)))
      .join(o_polygon, Seq("zone_code"), "left")
      .na.fill("", Seq("zone_code"))
      .withColumn("flame_distance", when('zone_code_x.isNotNull, lngLatToDistance('parkf_start_x, 'parkf_start_y, 'zone_code_x, 'zone_code_y)).otherwise(9999999))
      .withColumn("isnear_zone", when(trim('zone_code) =!= "" && 'flame_distance < 500, 1).otherwise(0))
      .withColumn("parkf_type", parkf_type_cd)
      .select(res_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //从结果表中抽取距离字段=1 500米以内 写入新表
    //结果表 的字段信息数据
    val res_near = spark.sql("""select * from dm_gis.dwd_vehicle_fuel_consum_distance_near_dtl limit 1""")
    val res_near_cols = res_near.schema.map(_.name).map(col)
    val partition_cols = res.schema.map(_.name).filter(!Seq("zone_code", "zone_code_x", "zone_code_y", "flame_distance", "isnear_zone", "parkf_type", "serial").contains(_)).map(col)

    val res_part = res
      .filter(col("isnear_zone").cast("int") === 1)
      .withColumn("num", row_number().over(Window.partitionBy(partition_cols: _*).orderBy(col("flame_distance").cast("double").asc)))
      .filter(col("num") === 1)
      .select(res_near_cols: _*)

    writeToHive(spark, res_part, Seq("inc_day"), "dm_gis.dwd_vehicle_fuel_consum_distance_near_dtl")
    writeToHive(spark, res, Seq("inc_day"), "dm_gis.dwd_vehicle_fuel_consum_distance_dtl")
    //    //从结果表中抽取距离字段=1 500米以内 写入新表
    //    processNewTable(spark,res)
    res.unpersist()
    step2_vehicle.unpersist()
  }

  def processNewTable(spark: SparkSession, df: DataFrame): Unit = {
    //结果表 的字段信息数据
    val res_near = spark.sql("""select * from dm_gis.dwd_vehicle_fuel_consum_distance_near_dtl limit 1""")
    val res_near_cols = res_near.schema.map(_.name).map(col)

    val partition_cols = df.schema.map(_.name).filter(!Seq("zone_code", "zone_code_x", "zone_code_y", "flame_distance", "isnear_zone", "parkf_type", "serial").contains(_)).map(col)

    val res_part = df
      .filter(col("isnear_zone").cast("int") === 1)
      .withColumn("num", row_number().over(Window.partitionBy(partition_cols: _*).orderBy(col("flame_distance").cast("double").asc)))
      .filter(col("num") === 1)
      .select(res_near_cols: _*)

    writeToHive(spark, res_part, Seq("inc_day"), "dm_gis.dwd_vehicle_fuel_consum_distance_near_dtl")

  }

}
