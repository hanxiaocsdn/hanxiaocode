package com.sf.app.etastd

import com.sf.app.navi.CreateMysqlTable.getMysqlcreateTable
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, concat_ws, row_number}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.JDBCUtils.{getFJTDevMysqlConnect, upsertBatch}
import utils.SparkBuilder

import java.sql.{Connection, PreparedStatement}
import scala.collection.mutable.ListBuffer

/**
 * @task_id: 758326
 * @description: 入生产库 "eta_std_acc_speed_monitor_change_indicate", "eta_std_acc_speed_monitor_change_ratio"
 * @demander:ft80006323 杨汶铭
 * @author 01418539 caojia
 * @date 2023/5/24 11:30
 */
object LoadEtaMonitorHiveToMysql extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val start_day = args(0)
    val end_day = args(1)
    val flag = args(2).toInt
    val tables: Array[String] = Array("eta_std_acc_speed_monitor_change_indicate", "eta_std_acc_speed_monitor_change_ratio")
    createOrInsert(spark, tables, start_day, end_day, flag)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def createOrInsert(spark: SparkSession, tables: Array[String], start_day: String, end_day: String, flag: Int): Unit = {
    val mysql_tables = getMysqlcreateTable(tables)
    var createSql = ""
    for (table <- tables) {
      if (flag == 0) {
        createSql = mysql_tables.get(table)
        processBDPMysqlCreateTable(table, createSql)
      } else {
        upsertToDevMysqlwithAddID(spark, table.toUpperCase, start_day, end_day)
      }
    }
  }

  def upsertToDevMysqlwithAddID(spark: SparkSession, tableName: String, start_day: String, end_day: String): Unit = {
    //加载数据
    val o_dataDf = spark.sql(
      s"""
         |select
         |*
         |from dm_gis.${tableName.toLowerCase}
         |where inc_day>='$start_day' and inc_day <= '$end_day'
         |""".stripMargin)
      .withColumn("random_id", row_number().over(Window.partitionBy("inc_day").orderBy("inc_day")))
      .withColumn("id", concat_ws("_", col("random_id"), col("inc_day"))).drop("random_id")
      .na.fill("")
      .na.fill(0)
      .na.fill(0.0)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //将mysql中原表数据分区删除 支持重跑
    val conn: Connection = getFJTDevMysqlConnect()
    try {
      val querySql = s"select * from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        val delSql = s"delete from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING(STATDATE,1,8) <= '$end_day'"
        val del: PreparedStatement = conn.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 bdp.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }

    //优化设置为批量写入
    val colNames = o_dataDf.withColumnRenamed("inc_day", "statdate").schema.toList
    val fields = colNames.map("`" + _.name.toUpperCase + "`").mkString(",")
    val blank_places = colNames.map(x => "?").mkString(",")

    //分批写入mysql
    o_dataDf.repartition(500).foreachPartition(record => {
      val listRows = new ListBuffer[Row]
      record.foreach(row => {
        listRows.append(row)
      })
      if (listRows.size > 0) {
        //批量写入
        logger.error("listRows.size:" + listRows.size)
        upsertBatch(getFJTDevMysqlConnect(), tableName, fields, blank_places, listRows) //执行批量插入数据
      }
    })
    //统计写入mysql中的数据总量
    try {
      val querySql = s"select count(1) as cnt from $tableName where SUBSTRING(STATDATE,1,8) >= '$start_day' and SUBSTRING( STATDATE,1,8) <= '$end_day'"
      val query: PreparedStatement = conn.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      if (queryRes.next()) {
        logger.error(s"表 bdp.$tableName 中$start_day to $end_day 之间成功插入的数据总量为：" + queryRes.getString("cnt"))
      }
    } catch {
      case ex: Exception => logger.error(s"统计 bdp.$tableName 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
  }

  def processBDPMysqlCreateTable(tableName: String, sql: String): Unit = {
    val conn: Connection = getFJTDevMysqlConnect()
    try {
      //删除
      val delSql = s"DROP table IF EXISTS $tableName"
      val delState: PreparedStatement = conn.prepareStatement(delSql)
      delState.execute()
    } catch {
      case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
    }
    //建表
    try {
      val createSQl: PreparedStatement = conn.prepareStatement(sql)
      createSQl.execute()
      logger.error(s"表：$tableName 的建表语句为：" + sql)
      logger.error(s"在bdp的mysql库中建表 $tableName 成功！！！！！")
    } catch {
      case e2: Exception => logger.error(s"系统异常 请检查" + e2.getMessage)
    }

  }

}
