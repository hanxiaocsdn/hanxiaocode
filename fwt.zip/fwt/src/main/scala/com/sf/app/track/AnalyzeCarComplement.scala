package com.sf.app.track

import com.sf.app.track.AnalyzeCarTracksByTaskTcSegCompTEST.{getLineCode, makesegPathBakTest, writeToHive}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{col, lit}
import utils.SparkBuilder

/**
 * @task_id: 593237
 * @description:合并初始 和 新增部分轨迹 20220713--20220912 需要合并 20220913之后直接取merge表带出line_code即可
 * @demander: ft80006356 马荣
 * @author 01418539 caojia
 * @date 2022/12/6 14:01
 */
object AnalyzeCarComplement extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
//    processLineCode(spark, checkDate)
    singleAdd(spark, checkDate)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }
  def singleAdd(spark: SparkSession, checkDate: String): Unit = {
    val o_df = spark.sql(s"""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge where inc_day='$checkDate'""")
    val o_line_code_df = getLineCode(spark, checkDate)//
    //按照已有结果表字段排序
    val res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge_test limit 0""").schema.map(_.name).map(col)

    val res_df = o_df.join(o_line_code_df, Seq("task_id", "inc_day"), "left").select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge_test")
    makesegPathBakTest(spark, checkDate)
  }
  def processLineCode(spark: SparkSession, dayid: String): Unit = {
    //按照已有结果表字段排序
    val merge_res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge_test limit 0""").schema.map(_.name).map(col)
    val res_cols = spark.sql("""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_bak limit 0""").schema.map(_.name).map(col)
    val org_catch = spark.sql(s"""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath where inc_day = '$dayid'""").select(res_cols: _*)
    val org_comp_test = spark.sql(s"""select * from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_bak where inc_day = '$dayid'""").select(res_cols: _*)

    val lc_df = getLineCode(spark, dayid)
    val all_carpath_df = org_comp_test.withColumn("org_flag", lit("result")).union(org_catch.withColumn("org_flag", lit("monitor")))
      .join(lc_df, Seq("task_id", "inc_day"), "left")
      .select(merge_res_cols: _*)
    writeToHive(spark, all_carpath_df.coalesce(10), Seq("inc_day"), "dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge_test")
    makesegPathBakTest(spark, dayid)
  }
}
