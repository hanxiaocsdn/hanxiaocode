package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions.{col, regexp_replace, substring}
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import utils.DateUtil.getdaysBeforeOrAfter
import utils.JDBCUtils.{getSCMDevMysqlConnect, queryTablesInMysql}
import utils.SparkBuilder

/**
 * @task_id: 684671
 * @description: 时效定责判读平台数据表 "eta_time_task_rt", "eta_time_alarm_rt", "eta_time_warning_extr"（create_time）, "driver_report_exception"(create_at)4张表同步
 * @demander: 01430321 廖静文
 * @author 01418539 caojia
 * @date 2023/8/25 14:26
 */
object LoadEfficientInterprePlatFromMysql2Hive extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val flag = args(1)
    val mysql_tn = Seq("eta_time_task_rt", "eta_time_alarm_rt", "eta_time_warning_extr", "driver_report_exception")
    for (mysqlTN <- mysql_tn) {
      run(spark, mysqlTN, inc_day, flag)
    }
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def run(spark: SparkSession, mysqlTN: String, inc_day: String, flag: String): Unit = {
    val conn_mysql = getSCMDevMysqlConnect()
    if (flag == "0") queryTablesInMysql(conn_mysql, "plan", mysqlTN)
    if (flag != "0") loadEfficientMysqlToHive(spark, mysqlTN, inc_day)
  }

  /**
   * 读取mysql表中的数据写入hive表中
   *
   * @param spark
   * @param mysqlTable
   * @param hiveTable
   */
  def loadEfficientMysqlToHive(spark: SparkSession, mysql_tn: String, inc_day: String): Unit = {
    val hive_table_struct: String = spark.sql(s"select * from dm_gis.$mysql_tn limit 0").schema.toList.map(_.name).mkString(",")
    val del_up_tm: String = spark.sql(s"select * from dm_gis.$mysql_tn limit 0").schema.toList.map(_.name).filter(_ != "up_tm").mkString(",")
    val res_cols: Seq[Column] = spark.sql(s"select * from dm_gis.$mysql_tn limit 0").schema.map(_.name).map(col)

    var df: DataFrame = null
    var query_state: String = null

    if (Seq("eta_time_task_rt", "eta_time_alarm_rt").contains(mysql_tn)) {
      query_state = getQueryState(mysql_tn, hive_table_struct, inc_day)
    } else if ("eta_time_warning_extr" == mysql_tn) {
      query_state = getQueryState(mysql_tn, del_up_tm, inc_day)
    } else {
      query_state = getQueryState(mysql_tn, del_up_tm, inc_day)
    }
    val params = Map(
      "driver" -> "com.mysql.jdbc.Driver",
      "url" -> "jdbc:mysql://plan-m.db.sfcloud.local:3306/plan?useSSL=false&useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai",
      "user" -> "plan",
      "password" -> "plan20210121#",
      "dbtable" -> query_state)

    if (Seq("eta_time_task_rt", "eta_time_alarm_rt").contains(mysql_tn)) {
      df = spark.read.format("jdbc").options(params).load()
        .select(res_cols: _*)
    } else if ("eta_time_warning_extr" == mysql_tn) {
      df = spark.read.format("jdbc").options(params).load()
        .withColumn("up_tm", regexp_replace(substring(col("create_time"), 0, 10), "-", ""))
        .select(res_cols: _*)
    } else {
      df = spark.read.format("jdbc").options(params).load()
        .withColumn("up_tm", regexp_replace(substring(col("create_at"), 0, 10), "-", ""))
        .select(res_cols: _*)
    }
    df.show(2)
    try {
      logger.error("获取的mysql中数据总量为：" + df.count())
      //将取出的数据写入hive表中
      if (df.head(1).size != 0) {
        if (Seq("eta_time_task_rt", "eta_time_alarm_rt").contains(mysql_tn)) {
          writeToHive(spark, df.coalesce(2), Seq("task_inc_day"), s"dm_gis.$mysql_tn")
        } else {
          writeToHive(spark, df.coalesce(2), Seq("up_tm"), s"dm_gis.$mysql_tn")
          //          writeToHiveNoP(spark, df.coalesce(2), mysql_tn)
        }
      } else {
        throw new Exception(s"mysql的 $mysql_tn 表数据为0，请核查源数据总量！")
      }
    } catch {
      case ex: Exception => logger.error(s"向hive表 $mysql_tn 中 插入数据时出现错误", ex)
        throw ex
    }
  }

  def getQueryState(mysql_tn: String, hive_table_struct: String, inc_day: String): String = {
    val quater = getQuarterInfo(inc_day)
    val days_1_ago = getdaysBeforeOrAfter(inc_day, -1)
    var fix_mysql_tn, query_state = ""
    if (Seq("eta_time_task_rt", "eta_time_alarm_rt").contains(mysql_tn)) {
      fix_mysql_tn = mysql_tn + "_" + quater
      query_state = s"""(select $hive_table_struct from $fix_mysql_tn where task_inc_day between '$days_1_ago' and '$inc_day') as tmp"""
    } else {
      fix_mysql_tn = mysql_tn
      if ("eta_time_warning_extr" == mysql_tn) {
        query_state = s"""(select $hive_table_struct from $fix_mysql_tn where DATE_FORMAT(create_time, '%Y%m%d') between '$days_1_ago' and '$inc_day') as tmp"""
      } else {
        query_state = s"""(select $hive_table_struct from $fix_mysql_tn where DATE_FORMAT(create_at, '%Y%m%d') between '$days_1_ago' and '$inc_day') as tmp"""
      }
    }
    logger.error("运行日期为:" + inc_day)
    logger.error("mysql中的查询语句：" + query_state)
    query_state
  }

  /**
   * 根据20230101格式的日期返回季度：202301
   *
   * @param inc_day
   */
  def getQuarterInfo(inc_day: String): String = {
    //获取20230101的年月季度202301
    val quarter = inc_day.substring(4, 6) match {
      case "01" | "02" | "03" => inc_day.substring(0, 4) + "" + "01"
      case "04" | "05" | "06" => inc_day.substring(0, 4) + "" + "02"
      case "07" | "08" | "09" => inc_day.substring(0, 4) + "" + "03"
      case "10" | "11" | "12" => inc_day.substring(0, 4) + "" + "04"
    }
    quarter
  }
}
