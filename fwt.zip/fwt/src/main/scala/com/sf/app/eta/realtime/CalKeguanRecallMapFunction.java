package com.sf.app.eta.realtime;/*
 @author 01401062
 @DESCRIPTION
 @create 2023/6/23
*/

import com.alibaba.fastjson.JSONObject;
import com.sf.gis.utils.JSONUtils;
import org.apache.flink.api.common.functions.MapFunction;
import utils.StringUtils;

public class CalKeguanRecallMapFunction implements MapFunction<JSONObject,JSONObject> {

    @Override
    public JSONObject map(JSONObject jo) throws Exception {

        double other_keguan_total = JSONUtils.getJsonValueDouble(jo, "other_keguan_total", 0.0);
        double ac_is_run_ontime = JSONUtils.getJsonValueDouble(jo, "ac_is_run_ontime", 0);
        double total_ob_tm = JSONUtils.getJsonValueDouble(jo, "total_ob_tm", 0);
        double total_ob_ratio = JSONUtils.getJsonValueDouble(jo, "total_ob_ratio", 0);
        double total_sub_tm = JSONUtils.getJsonValueDouble(jo, "total_sub_tm", 0);
        double total_sub_ratio = JSONUtils.getJsonValueDouble(jo, "total_sub_ratio", 0);

        double total_sub_ratio2 = JSONUtils.getJsonValueDouble(jo, "total_sub_ratio2", 0);
        double total_ob_ratio2 = JSONUtils.getJsonValueDouble(jo, "total_ob_ratio2", 0);


        double difftime_plan_actual = JSONUtils.getJsonValueDouble(jo, "difftime_plan_actual", 0);
        double closure_contime = JSONUtils.getJsonValueDouble(jo, "closure_contime", 0);
        double congestion_time = JSONUtils.getJsonValueDouble(jo, "congestion_time", 0);

        String def_ob_reason = JSONUtils.getJsonValue(jo, "def_ob_reason", "");
        String def_sub_reason = JSONUtils.getJsonValue(jo, "def_sub_reason", "");



        congestion_time = congestion_time + total_ob_tm;

        double other_keguan_total_ratio1 = 0.0;
        if (ac_is_run_ontime == 0) {
            other_keguan_total_ratio1 = Math.abs(other_keguan_total/(other_keguan_total+ total_sub_tm));
        }

        double other_keguan_total_ratio2 = 0.0;
        if (ac_is_run_ontime == 0) {
            other_keguan_total_ratio2 = Math.abs( (other_keguan_total /60) / difftime_plan_actual);
        }

//        double total_ob_tm2 = other_keguan_total + total_ob_tm + closure_contime;

//        double total_ob_tm2 = congestion_time + total_ob_tm + closure_contime;
        double total_ob_tm2 = congestion_time + closure_contime;
        double other_abnormal_stay_time2 = JSONUtils.getJsonValueDouble(jo, "other_abnormal_stay_time2", 0);
        double service_total_stay_time2 = JSONUtils.getJsonValueDouble(jo, "service_total_stay_time2", 0);
        double other_abnormal_stay_time = JSONUtils.getJsonValueDouble(jo, "other_abnormal_stay_time", 0);
        double service_total_stay_time = JSONUtils.getJsonValueDouble(jo, "service_total_stay_time", 0);
        double normal_stay_time = JSONUtils.getJsonValueDouble(jo, "normal_stay_time", 0);

        other_abnormal_stay_time2 += other_abnormal_stay_time;
        service_total_stay_time2 += service_total_stay_time;

        double abnormal_stay_time2 = 0.0;
        if (service_total_stay_time2 - normal_stay_time > 0 ){
            abnormal_stay_time2 = service_total_stay_time2 - normal_stay_time;
        } else {
            abnormal_stay_time2 = 0;
        }

        double total_sub_tm2 = abnormal_stay_time2 + other_abnormal_stay_time2;

        String task_label_final = "";
//
//        if (total_sub_ratio2 + total_ob_ratio2 >= 1 && total_ob_ratio >= 0.6) {
//            task_label_final = "客观情况1";
//        } else if (total_sub_ratio2+total_ob_ratio2 < 1 && total_ob_ratio2 >= 0.6){
//            task_label_final = "客观情况2";
//        } else if (total_sub_ratio2 + other_keguan_total_ratio2 >= 1 && other_keguan_total_ratio1 >= 0.6){
//            task_label_final = "新识别客观情况1";
//        } else if (total_sub_ratio2 + other_keguan_total_ratio2 < 1 && other_keguan_total_ratio2 >= 0.6){
//            task_label_final = "新识别客观情况2";
//        } else if (total_sub_ratio2 >= 0.6){
//            task_label_final = "主观";
//        } else {
//            task_label_final = "暂未识别";
//        }



        double keguan_total_final = 0.0;
        if (StringUtils.nonEmpty(task_label_final) && task_label_final.contains("新识别")) {
            keguan_total_final = other_keguan_total;
        } else {
            keguan_total_final = total_ob_tm;
        }

        double keguan_total_final_ratio1 = 0.0;
        if (ac_is_run_ontime == 0) {
            keguan_total_final_ratio1 = Math.abs(keguan_total_final/(keguan_total_final + total_sub_tm));
        }

        double keguan_total_final_ratio2 = 0.0;
        if (ac_is_run_ontime == 0) {
            keguan_total_final_ratio2 = Math.abs( (keguan_total_final/60) / difftime_plan_actual);
        }


        double total_sub_ratio_final = 0.0;
        double total_ob_ratio_final = 0.0;
        double total_sub_ratio_final2 = 0.0;
        double total_ob_ratio_final2 = 0.0;
        String task_label_final2 = "暂未识别";

        if (ac_is_run_ontime == 0) {
            total_sub_ratio_final = total_sub_tm2 / (total_sub_tm2 + total_ob_tm2);
            total_ob_ratio_final = total_ob_tm2 / (total_sub_tm2+total_ob_tm2);

            total_sub_ratio_final2 = Math.abs((total_sub_tm2 / 60) / difftime_plan_actual);
            total_ob_ratio_final2 = Math.abs( (total_ob_tm2 / 60)/ difftime_plan_actual);
        }

        if (total_sub_ratio_final2 + total_ob_ratio_final2 >= 1 && total_ob_ratio_final >= 0.6) {
            task_label_final2 = "客观情况1";
        } else if (total_sub_ratio_final2 + total_ob_ratio_final2 < 1 && total_ob_ratio_final2 >= 0.6){
            task_label_final2 = "客观情况2";
        } else if (total_sub_ratio_final2 >= 0.6){
            task_label_final2 = "主观";
        } else {
            task_label_final2 = "暂未识别";
        }


        // TODO: 2023/8/7 新增 Task_label_final判断逻辑、responsibility_reason字段
        int task_conduct_type = JSONUtils.getJsonValueInt(jo, "task_conduct_type", 0);
        int is_closure = JSONUtils.getJsonValueInt(jo, "is_closure", 0);
        int is_construction = JSONUtils.getJsonValueInt(jo, "is_construction", 0);
        int carrier_no_answer = JSONUtils.getJsonValueInt(jo, "carrier_no_answer", 0);

        // TODO: 2023/10/18 删除  && is_closure == 0
        if (task_conduct_type == 3) {
            task_label_final = "未执行标准线路";
        } else if (total_sub_ratio_final2 >= 1 && total_ob_ratio_final2 == 0) {
            task_label_final = "百分百主观";
        } else if (total_sub_ratio_final2 + total_ob_ratio_final2 >= 1 && total_ob_ratio_final >=0.6) {
            task_label_final = "客观情况1";
        } else if (total_sub_ratio_final2+total_ob_ratio_final2 < 1 && total_ob_ratio_final2 >=0.6) {
            task_label_final = "客观情况2";
        } else if (total_sub_ratio_final2 >=0.6) {
            task_label_final = "主观";
        } else {
            task_label_final = "暂未识别";
        }

        String responsibility_reason = "暂未识别";
        if ("未执行标准线路".equals(task_label_final)) {
            responsibility_reason = "主观-未执行标准线路";
        } else if (("客观情况1".equals(task_label_final) || "客观情况2".equals(task_label_final))) {
            if (is_construction != 0){
                responsibility_reason = "客观-修路";
            } else if (is_closure != 0 && congestion_time>closure_contime) {
                responsibility_reason = "客观-封路";
            } else if ("轮渡".equals(def_ob_reason)){
                responsibility_reason = "客观-轮渡";
            } else {
                responsibility_reason = "客观-拥堵";
            }
        } else if (("百分百主观".equals(task_label_final) || "主观".equals(task_label_final)) && !"无".equals(def_sub_reason) && StringUtils.nonEmpty(def_sub_reason)) {
            responsibility_reason = "主观-" + def_sub_reason;
        } else if (("百分百主观".equals(task_label_final) || "主观".equals(task_label_final) || "暂未识别".equals(task_label_final)) && carrier_no_answer == 1) {
            responsibility_reason = "主观-承运商两次不接电话";
        } else if ("百分百主观".equals(task_label_final) || "主观".equals(task_label_final)){
            if (abnormal_stay_time2 > other_abnormal_stay_time2) {
                responsibility_reason = "主观-服务区超时休息";
            } else {
                responsibility_reason = "主观-主观停留";
            }
        } else {
            responsibility_reason = "暂未识别";
        }



        jo.put("other_keguan_total_ratio1", other_keguan_total_ratio1);
        jo.put("other_keguan_total_ratio2", other_keguan_total_ratio2);
        jo.put("task_label_final", task_label_final);
        jo.put("keguan_total_final", keguan_total_final);
        jo.put("keguan_total_final_ratio1", keguan_total_final_ratio1);
        jo.put("keguan_total_final_ratio2", keguan_total_final_ratio2);

        jo.put("congestion_time",congestion_time);
        jo.put("total_ob_tm2", total_ob_tm2);
        jo.put("other_abnormal_stay_time2", other_abnormal_stay_time2);
        jo.put("service_total_stay_time2", service_total_stay_time2);
        jo.put("abnormal_stay_time2", abnormal_stay_time2);
        jo.put("total_sub_tm2", total_sub_tm2);

        jo.put("total_sub_ratio_final",total_sub_ratio_final);
        jo.put("total_ob_ratio_final",total_ob_ratio_final);
        jo.put("total_sub_ratio_final2",total_sub_ratio_final2);
        jo.put("total_ob_ratio_final2",total_ob_ratio_final2);
        jo.put("task_label_final2",task_label_final2);

        jo.put("responsibility_reason",responsibility_reason);

        return jo;
    }
}
