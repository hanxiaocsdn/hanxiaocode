package com.sf.app.pns

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import utils.DateUtil.getWeek
import utils.SparkBuilder

/**
 * @task_id: 769999
 * @description: 【路径规划】司机实走轨迹支持每日定时下载_V1.0
 * @demander: 01423208 蔡雨伦
 * @author 01418539 曹佳 01390943 周勇
 * @date 2023/1/3 17:30
 */
object LoadNaviResultData {
  def main(args: Array[String]): Unit = {
    val logger: Logger = Logger.getLogger(this.getClass)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val week_index = getWeek(inc_day)
    processLoadSpark(spark, week_index, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }


  def processLoadSpark(spark: SparkSession, week_index: String, inc_day: String): Unit = {
    val o_result = spark.sql(
      s"""
         |select
         |t1.ft_url as ft_url,
         |t2.tracks2 as tracks2,
         |t1.request_id as request_id,
         |t1.driver_type as driver_type,
         |t1.route_index as dianxuan_index,
         |t2.routeid as online_routeid,
         |t2.similarity1 as online_similarity1,
         |t2.similarity5 as online_similarity5,
         |t2.polyline as polyline,
         |t1.strategy2,
         |t2.navi_starttime,
         |t2.navi_endtime,
         |t2.links2,
         |t1.distance,
         |t2.navi_distance,
         |t1.inc_day
         |from
         |(select ft_url,request_id,driver_type,route_index,strategy2,distance,id,inc_day
         |From dm_gis.gis_navi_eta_result1 where inc_day = '$inc_day' and start_type <> '1' and distance > 1000 and req_type = 'top3' and id is not null and trim(id) != '') t1
         |join (select id,tracks2,polyline,similarity1,similarity5,routeid,links2,navi_starttime,navi_endtime,navi_distance
         |from dm_gis.gis_navi_eta_result2 where inc_day = '$inc_day' and tracks2 <> '' and req_type = 'top3' and trackstart_distance < 1000 and trackend_distance < 1000 and navi_distance > 1000
         | and id is not null and trim(id) != '') t2 on t1.id = t2.id
         |""".stripMargin)
    o_result.coalesce(1).write
      .option("header", "true")
      .option("delimiter", "\\t") //默认以","分割
      .csv("/user/01390943/upload/file/yesterday_tracks/w" + week_index)
  }
}
