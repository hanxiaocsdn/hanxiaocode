package com.sf.app.eta

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import utils.DateUtil.getdaysBeforeOrAfter
import utils.{ColumnUtil, SparkBuilder}

/**
 * @task_id: 573817
 * @description: 时效定责监控体系监控 dm_gis.eta_task_time_stats
 * @demander: 01408890 邵一馨
 * @author 01418539 caojia
 * @date 2022/11/7 10:31
 */
object EfficientTaskTimeStatus extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    processTaskTime(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processTaskTime(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val o_task_df = getTaskData(spark, inc_day)
      .withColumn("zhuguan_fuwuqu", when('zhuguan_fuwuqu.cast("double") > 0, 'zhuguan_fuwuqu).otherwise(0))
    val p1_ontime_cols_str = Seq("task_late_num", "task_ontime_num")
    val p2_label1_cols_str = Seq("task_sub_num", "task_ob_num")
    val p3_label2_cols_str = Seq("service_sub_num", "start_sub_num", "end_sub_num", "epidemic_sub_num", "tollstation_sub_num", "gaosu_sub_num", "service_ob_num", "start_ob_num", "end_ob_num", "epidemic_ob_num", "tollstation_ob_num", "otherevent_ob_num", "other_ob_num", "jyz_ob_num")
    val p4_trible_cols_str = Seq("else_sub_num", "else_ob_num", "task_error_num")
    val p5_exe_label1_cols_str = Seq("task_time_change_num", "task_unknown_num")
    //step1
    val num_flag_cols = multiCond(spark, p1_ontime_cols_str, p2_label1_cols_str, p3_label2_cols_str, p4_trible_cols_str, p5_exe_label1_cols_str)

    val step_1_1_cols_str = p1_ontime_cols_str ++ p2_label1_cols_str ++ p3_label2_cols_str ++ p4_trible_cols_str ++ p5_exe_label1_cols_str
    val step_1_2_cols_str = Seq("task_num", "task_total_keguan", "task_total_zhuguan", "zhuguan_fuwuqu", "service_ob_final", "tollstation_sub_final", "tollstation_ob_final", "epidemic_sub_final", "epidemic_ob_final", "start_sub_final", "start_ob_final", "end_sub_final", "end_ob_final", "other_event_final", "no_label_sub_final", "no_label_ob_final", "jyz_total_stay_points_duration")

    val p1_df = o_task_df.select(o_task_df.schema.map(_.name).map(col) ++ num_flag_cols: _*)
    //聚合求值
    val agg_cols = aggSumCols(step_1_1_cols_str, step_1_2_cols_str)
    val p2_df_cols = spark.sql("""select * from dm_gis.eta_task_time_stats limit 0""").schema.map(_.name).map(col)
    val group_cols: Seq[Column] = Seq('task_area_code, 'line_code, 'transoport_level, 'carrier_name, 'driver_id, 'driver_name, 'inc_day)
    val p2_df = p1_df.groupBy(group_cols: _*).agg(agg_cols.head, agg_cols.tail: _*).select(p2_df_cols: _*).coalesce(1)
    writeToHive(spark, p2_df, Seq("inc_day"), "dm_gis.eta_task_time_stats")
  }

  def aggSumCols(step_1_1_cols_str: Seq[String], step_1_2_cols_str: Seq[String]): Seq[Column] = {
    val s1 = step_1_1_cols_str.map(x => sum(col(x)))
    val s2 = step_1_2_cols_str.map(x => sum(col(x).cast("double")))
    ColumnUtil.renameColumn(s1 ++ s2, step_1_1_cols_str ++ step_1_2_cols_str)
  }

  def multiCond(spark: SparkSession, p1_ontime_cols_str: Seq[String], p2_label1_cols_str: Seq[String], p3_label2_cols_str: Seq[String], p4_trible_cols_str: Seq[String], p5_exe_label1_cols_str: Seq[String]): Seq[Column] = {
    import spark.implicits._
    //p1 准点 or 晚点 任务数
    val p1_ontime_cols = Seq("0", "1").map('ac_is_run_ontime === _)
    //p2 主观 or 客观
    val p2_label1_cols = Seq("主观", "客观").map('task_label1 === _)
    //p3 task_label2 contains 情况
    val p3_label2_cols = Seq("服务区主观停留/低速", "起点主观停留/低速", "终点主观停留/低速", "疫情检查站主观停留/低速", "收费站主观停留/低速", "未全程高速", "服务区拥堵", "起点拥堵", "终点拥堵", "疫情检查", "收费站客观停留/低速", "其他事件", "路况拥堵", "加油站客观停留/低速").map('task_label2.contains(_))
    //p4 单独3个条件
    val single1 = 'task_label1 === "主观" && ('task_label2.isNull || trim('task_label2) === "") // else_sub_num
    val single2 = 'task_label1 === "客观" && ('task_label2.isNull || trim('task_label2) === "") //else_ob_num
    val single3 = 'ac_is_run_ontime === "0" && 'task_label2 === "轨迹异常" //task_error_num
    val p4_trible_cols = Seq(single1, single2, single3)
    //p5
    val p5_exe_label1_cols = Seq('task_label1 === "规划时长不足",'ac_is_run_ontime === "0" && 'task_label1 === "系统未识别")
    val new_cols = (p1_ontime_cols ++ p2_label1_cols ++ p3_label2_cols ++ p4_trible_cols ++ p5_exe_label1_cols).map(x => when(x, 1).otherwise(0))
    val new_cols_str = p1_ontime_cols_str ++ p2_label1_cols_str ++ p3_label2_cols_str ++ p4_trible_cols_str ++ p5_exe_label1_cols_str

    ColumnUtil.renameColumn(new_cols, new_cols_str)
  }

  def getTaskData(spark: SparkSession, inc_day: String): DataFrame = {
    val day_6_ago = getdaysBeforeOrAfter(inc_day, -6) //首尾日期 近7天的数据
    val day_7_ago = getdaysBeforeOrAfter(inc_day, -7) //首尾日期 近8天的数据
    spark.sql(
      s"""select *,1 task_num from
         |  (select
         |      row_number() over(PARTITION by a.task_id ORDER by last_update_tm desc) as rn,
         |      task_line_time,task_actual_run_time,task_total_keguan,task_total_zhuguan,task_line_distance,service_final,service_ob_final,service_gaosu_final,tollstation_sub_final,tollstation_ob_final,epidemic_sub_final,epidemic_ob_final,start_sub_final,start_ob_final,end_sub_final,end_ob_final,other_event_final,no_label_sub_final,no_label_ob_final,jyz_total_stay_points_duration,zhuguan_fuwuqu,task_difftime_plan_actual,task_total_keguan_ratio,task_total_zhuguan_ratio,task_label1,task_label_keguan,task_label_zhuguan,task_label_other,task_label2,
         |      b.*
         |    from (select task_id,task_line_time,task_actual_run_time,task_total_keguan,task_total_zhuguan,task_line_distance,service_final,service_ob_final,service_gaosu_final,tollstation_sub_final,tollstation_ob_final,epidemic_sub_final,epidemic_ob_final,start_sub_final,start_ob_final,end_sub_final,end_ob_final,other_event_final,no_label_sub_final,no_label_ob_final,jyz_total_stay_points_duration,zhuguan_fuwuqu,task_difftime_plan_actual,ac_is_run_ontime,task_total_keguan_ratio,task_total_zhuguan_ratio,task_label1,task_label_keguan,task_label_zhuguan,task_label_other,task_label2
         |        from dm_gis.eta_task_time_information1 where inc_day between '$day_7_ago' and '$inc_day') a
         |    join (select * from dm_gis.eta_std_line_recall_result2 where inc_day between '$day_6_ago' and '$inc_day' and if_evaluate_time = '1' ) b
         |    on a.task_id = b.task_id and a.ac_is_run_ontime = b.ac_is_run_ontime
         |  ) t where rn = 1
         |""".stripMargin)
  }
}
