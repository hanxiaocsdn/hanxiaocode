package com.sf.app.smart

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import utils.SparkBuilder

/**
 * @description:用户监控基础表 dm_gis.scomm_user_monitor 用户监控统计表 dm_gis.scomm_user_monitor_static
 * @author 01418539 caojia
 * @date 2022/4/29 15:35
 */
object MonitorUserRetentionRate extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val inc_day = args(0)
    processRetention(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processRetention(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    val day_cols = Seq(col("province"),
      col("city"),
      col("region"),
      col("street"),
      col("community"),
      col("aoi_name"),
      col("effective_users"),
      col("first_day_effective_users"),
      col("first_day_effective_users_ratio"),
      col("after_first_day_effective_users"),
      col("three_day_effective_users"),
      col("three_day_effective_users_ratio"),
      col("after_three_day_effective_users"),
      col("six_day_effective_users"),
      col("six_day_effective_users_ratio"),
      col("after_six_day_effective_users"),
      col("nine_day_effective_users"),
      col("nine_day_effective_users_ratio"),
      col("after_nine_day_effective_users"),
      col("twelve_day_effective_users"),
      col("twelve_day_effective_users_ratio"),
      col("after_twelve_day_effective_users"),
      col("fifteen_day_effective_users"),
      col("fifteen_day_effective_users_ratio"),
      col("after_fifteen_day_effective_users"),
      col("eighteen_day_effective_users"),
      col("eighteen_day_effective_users_ratio"),
      col("after_eighteen_day_effective_users"),
      col("twenty_one_day_effective_users"),
      col("twenty_one_day_effective_users_ratio"),
      col("after_twenty_one_day_effective_users"),
      col("twenty_four_day_effective_users"),
      col("twenty_four_day_effective_users_ratio"),
      col("after_twenty_four_day_effective_users"),
      col("twenty_seven_day_effective_users"),
      col("twenty_seven_day_effective_users_ratio"),
      col("after_twenty_seven_day_effective_users"),
      col("thirty_day_effective_users"),
      col("thirty_day_effective_users_ratio"),
      col("inc_day")
    )

    val week_cols = Seq(col("province"),
      col("city"),
      col("region"),
      col("street"),
      col("community"),
      col("aoi_name"),
      col("effective_users"),
      col("first_week_effective_users"),
      col("first_week_effective_users_ratio"),
      col("after_first_week_effective_users"),
      col("second_week_effective_users"),
      col("second_week_effective_users_ratio"),
      col("after_second_week_effective_users"),
      col("third_week_effective_users"),
      col("third_week_effective_users_ratio"),
      col("after_third_week_effective_users"),
      col("fourth_week_effective_users"),
      col("fourth_week_effective_users_ratio"),
      col("after_fourth_week_effective_users"),
      col("fifth_week_effective_users"),
      col("fifth_week_effective_users_ratio"),
      col("after_fifth_week_effective_users"),
      col("sixth_week_effective_users"),
      col("sixth_week_effective_users_ratio"),
      col("after_sixth_week_effective_users"),
      col("seventh_week_effective_users"),
      col("seventh_week_effective_users_ratio"),
      col("after_seventh_week_effective_users"),
      col("eighth_week_effective_users"),
      col("eighth_week_effective_users_ratio"),
      col("inc_day"))

    val month_cols = Seq(col("province"),
      col("city"),
      col("region"),
      col("street"),
      col("community"),
      col("aoi_name"),
      col("effective_users"),
      col("first_month_effective_users"),
      col("first_month_effective_users_ratio"),
      col("after_first_month_effective_users"),
      col("second_month_effective_users"),
      col("second_month_effective_users_ratio"),
      col("after_second_month_effective_users"),
      col("third_month_effective_users"),
      col("third_month_effective_users_ratio"),
      col("after_third_month_effective_users"),
      col("fourth_month_effective_users"),
      col("fourth_month_effective_users_ratio"),
      col("after_fourth_month_effective_users"),
      col("fifth_month_effective_users"),
      col("fifth_month_effective_users_ratio"),
      col("after_fifth_month_effective_users"),
      col("sixth_month_effective_users"),
      col("sixth_month_effective_users_ratio"),
      col("after_sixth_month_effective_users"),
      col("seventh_month_effective_users"),
      col("seventh_month_effective_users_ratio"),
      col("after_seventh_month_effective_users"),
      col("eighth_month_effective_users"),
      col("eighth_month_effective_users_ratio"),
      col("after_eighth_month_effective_users"),
      col("ninth_month_effective_users"),
      col("ninth_month_effective_users_ratio"),
      col("after_ninth_month_effective_users"),
      col("tenth_month_effective_users"),
      col("tenth_month_effective_users_ratio"),
      col("after_tenth_month_effective_users"),
      col("eleventh_month_effective_users"),
      col("eleventh_month_effective_users_ratio"),
      col("after_eleventh_month_effective_users"),
      col("twelfth_month_effective_users"),
      col("twelfth_month_effective_users_ratio"),
      col("inc_day")
    )

    val o_user_monitor = spark.sql(
      s"""
         |select * from dm_gis.scomm_user_monitor where statdate = '$inc_day'
         |""".stripMargin)
      .withColumn("flag_0", when('effective_orders > 0, 1).otherwise(0)) //注册有效用户数
      .withColumn("flag_1_", when('first_day_retained > 0, 1).otherwise(0)) //注册第一天有效用户留存数
      .withColumn("flag_1", when('effective_orders > 0 && 'register_days > 0, 1).otherwise(0)) //注册当天后有效用户留存数
      .withColumn("flag_1_3", when('three_days_retained > 0, 1).otherwise(0)) //注册后3天内有效用户留存数
      .withColumn("flag_3", when('effective_orders > 0 && 'register_days > 3, 1).otherwise(0)) //注册后3天以上有效用户留存数
      .withColumn("flag_3_6", when('six_days_retained > 0, 1).otherwise(0)) //注册后6天内有效用户留存数
      .withColumn("flag_6", when('effective_orders > 0 && 'register_days > 6, 1).otherwise(0)) //注册后6天以上有效用户留存数
      .withColumn("flag_6_9", when('nine_days_retained > 0, 1).otherwise(0)) //注册后9天内有效用户留存数
      .withColumn("flag_9", when('effective_orders > 0 && 'register_days > 9, 1).otherwise(0)) //注册后9天以上有效用户留存数
      .withColumn("flag_9_12", when('twelve_days_retained > 0, 1).otherwise(0)) //注册后12天内有效用户留存数
      .withColumn("flag_12", when('effective_orders > 0 && 'register_days > 12, 1).otherwise(0)) //注册后12天以上有效用户留存数
      .withColumn("flag_12_15", when('fifteen_days_retained > 0, 1).otherwise(0)) //注册后15天内有效用户留存数
      .withColumn("flag_15", when('effective_orders > 0 && 'register_days > 15, 1).otherwise(0)) //注册后15天以上有效用户留存数
      .withColumn("flag_15_18", when('eighteen_days_retained > 0, 1).otherwise(0)) //注册后18天内有效用户留存数
      .withColumn("flag_18", when('effective_orders > 0 && 'register_days > 18, 1).otherwise(0)) //注册后18天以上有效用户留存数
      .withColumn("flag_18_21", when('twenty_one_days_retained > 0, 1).otherwise(0)) //注册后21天内有效用户留存数
      .withColumn("flag_21", when('effective_orders > 0 && 'register_days > 21, 1).otherwise(0)) //注册后21天以上有效用户留存数
      .withColumn("flag_21_24", when('twenty_four_days_retained > 0, 1).otherwise(0)) //注册后24天内有效用户留存数
      .withColumn("flag_24", when('effective_orders > 0 && 'register_days > 24, 1).otherwise(0)) //注册后24天以上有效用户留存数
      .withColumn("flag_24_27", when('twenty_seven_days_retained > 0, 1).otherwise(0)) //注册后27天内有效用户留存数
      .withColumn("flag_27", when('effective_orders > 0 && 'register_days > 27, 1).otherwise(0)) //注册后27天以上有效用户留存数
      .withColumn("flag_27_30", when('thirty_days_retained > 0, 1).otherwise(0)) //注册后30天内有效用户留存数
      //周流程统计表
      .withColumn("w_flag_1", when('first_week_retained > 0, 1).otherwise(0))
      .withColumn("w_flag_1_", when('effective_orders > 0 && 'register_days > 7, 1).otherwise(0))
      .withColumn("w_flag_1_2", when('second_week_retained > 0, 1).otherwise(0))
      .withColumn("w_flag_2", when('effective_orders > 0 && 'register_days > 14, 1).otherwise(0))
      .withColumn("w_flag_2_3", when('third_week_retained > 0, 1).otherwise(0))
      .withColumn("w_flag_3", when('effective_orders > 0 && 'register_days > 21, 1).otherwise(0))
      .withColumn("w_flag_3_4", when('fourth_week_retained > 0, 1).otherwise(0))
      .withColumn("w_flag_4", when('effective_orders > 0 && 'register_days > 28, 1).otherwise(0))
      .withColumn("w_flag_4_5", when('fifth_week_retained > 0, 1).otherwise(0))
      .withColumn("w_flag_5", when('effective_orders > 0 && 'register_days > 35, 1).otherwise(0))
      .withColumn("w_flag_5_6", when('sixth_week_retained > 0, 1).otherwise(0))
      .withColumn("w_flag_6", when('effective_orders > 0 && 'register_days > 42, 1).otherwise(0))
      .withColumn("w_flag_6_7", when('seventh_week_retained > 0, 1).otherwise(0))
      .withColumn("w_flag_7", when('effective_orders > 0 && 'register_days > 49, 1).otherwise(0))
      .withColumn("w_flag_7_8", when('eighth_week_retained > 0, 1).otherwise(0))
      //月留存统计表
      .withColumn("m_flag_1", when('first_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_1_", when('effective_orders > 0 && 'register_days > 30, 1).otherwise(0))
      .withColumn("m_flag_1_2", when('second_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_2", when('effective_orders > 0 && 'register_days > 60, 1).otherwise(0))
      .withColumn("m_flag_2_3", when('third_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_3", when('effective_orders > 0 && 'register_days > 90, 1).otherwise(0))
      .withColumn("m_flag_3_4", when('fourth_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_4", when('effective_orders > 0 && 'register_days > 120, 1).otherwise(0))
      .withColumn("m_flag_4_5", when('fifth_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_5", when('effective_orders > 0 && 'register_days > 150, 1).otherwise(0))
      .withColumn("m_flag_5_6", when('sixth_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_6", when('effective_orders > 0 && 'register_days > 180, 1).otherwise(0))
      .withColumn("m_flag_6_7", when('seventh_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_7", when('effective_orders > 0 && 'register_days > 210, 1).otherwise(0))
      .withColumn("m_flag_7_8", when('eighth_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_8", when('effective_orders > 0 && 'register_days > 240, 1).otherwise(0))
      .withColumn("m_flag_8_9", when('ninth_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_9", when('effective_orders > 0 && 'register_days > 270, 1).otherwise(0))
      .withColumn("m_flag_9_10", when('tenth_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_10", when('effective_orders > 0 && 'register_days > 300, 1).otherwise(0))
      .withColumn("m_flag_10_11", when('eleventh_month_retained > 0, 1).otherwise(0))
      .withColumn("m_flag_11", when('effective_orders > 0 && 'register_days > 330, 1).otherwise(0))
      .withColumn("m_flag_11_12", when('twelfth_month_retained > 0, 1).otherwise(0))
      .groupBy("province", "city", "region", "street", "community", "aoi_name", "statdate")
      .agg(
        sum("flag_0") as "effective_users",
        sum("flag_1_") as "first_day_effective_users",
        sum("flag_1") as "after_first_day_effective_users",
        sum("flag_1_3") as "three_day_effective_users",
        sum("flag_3") as "after_three_day_effective_users",
        sum("flag_3_6") as "six_day_effective_users",
        sum("flag_6") as "after_six_day_effective_users",
        sum("flag_6_9") as "nine_day_effective_users",
        sum("flag_9") as "after_nine_day_effective_users",
        sum("flag_9_12") as "twelve_day_effective_users",
        sum("flag_12") as "after_twelve_day_effective_users",
        sum("flag_12_15") as "fifteen_day_effective_users",
        sum("flag_15") as "after_fifteen_day_effective_users",
        sum("flag_15_18") as "eighteen_day_effective_users",
        sum("flag_18") as "after_eighteen_day_effective_users",
        sum("flag_18_21") as "twenty_one_day_effective_users",
        sum("flag_21") as "after_twenty_one_day_effective_users",
        sum("flag_21_24") as "twenty_four_day_effective_users",
        sum("flag_24") as "after_twenty_four_day_effective_users",
        sum("flag_24_27") as "twenty_seven_day_effective_users",
        sum("flag_27") as "after_twenty_seven_day_effective_users",
        sum("flag_27_30") as "thirty_day_effective_users",
        //周流程统计表
        sum("w_flag_1") as "first_week_effective_users",
        sum("w_flag_1_") as "after_first_week_effective_users",
        sum("w_flag_1_2") as "second_week_effective_users",
        sum("w_flag_2") as "after_second_week_effective_users",
        sum("w_flag_2_3") as "third_week_effective_users",
        sum("w_flag_3") as "after_third_week_effective_users",
        sum("w_flag_3_4") as "fourth_week_effective_users",
        sum("w_flag_4") as "after_fourth_week_effective_users",
        sum("w_flag_4_5") as "fifth_week_effective_users",
        sum("w_flag_5") as "after_fifth_week_effective_users",
        sum("w_flag_5_6") as "sixth_week_effective_users",
        sum("w_flag_6") as "after_sixth_week_effective_users",
        sum("w_flag_6_7") as "seventh_week_effective_users",
        sum("w_flag_7") as "after_seventh_week_effective_users",
        sum("w_flag_7_8") as "eighth_week_effective_users",
        //月留存统计表
        sum("m_flag_1") as "first_month_effective_users",
        sum("m_flag_1_") as "after_first_month_effective_users",
        sum("m_flag_1_2") as "second_month_effective_users",
        sum("m_flag_2") as "after_second_month_effective_users",
        sum("m_flag_2_3") as "third_month_effective_users",
        sum("m_flag_3") as "after_third_month_effective_users",
        sum("m_flag_3_4") as "fourth_month_effective_users",
        sum("m_flag_4") as "after_fourth_month_effective_users",
        sum("m_flag_4_5") as "fifth_month_effective_users",
        sum("m_flag_5") as "after_fifth_month_effective_users",
        sum("m_flag_5_6") as "sixth_month_effective_users",
        sum("m_flag_6") as "after_sixth_month_effective_users",
        sum("m_flag_6_7") as "seventh_month_effective_users",
        sum("m_flag_7") as "after_seventh_month_effective_users",
        sum("m_flag_7_8") as "eighth_month_effective_users",
        sum("m_flag_8") as "after_eighth_month_effective_users",
        sum("m_flag_8_9") as "ninth_month_effective_users",
        sum("m_flag_9") as "after_ninth_month_effective_users",
        sum("m_flag_9_10") as "tenth_month_effective_users",
        sum("m_flag_10") as "after_tenth_month_effective_users",
        sum("m_flag_10_11") as "eleventh_month_effective_users",
        sum("m_flag_11") as "after_eleventh_month_effective_users",
        sum("m_flag_11_12") as "twelfth_month_effective_users"
      )
      //月留存统计表
      .withColumn("first_day_effective_users_ratio", concat(round(when('effective_users > 0, ('first_day_effective_users / 'effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("three_day_effective_users_ratio", concat(round(when('after_first_day_effective_users > 0, ('three_day_effective_users / 'after_first_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("six_day_effective_users_ratio", concat(round(when('after_three_day_effective_users > 0, ('six_day_effective_users / 'after_three_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("nine_day_effective_users_ratio", concat(round(when('after_six_day_effective_users > 0, ('nine_day_effective_users / 'after_six_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("twelve_day_effective_users_ratio", concat(round(when('after_nine_day_effective_users > 0, ('twelve_day_effective_users / 'after_nine_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("fifteen_day_effective_users_ratio", concat(round(when('after_twelve_day_effective_users > 0, ('fifteen_day_effective_users / 'after_twelve_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("eighteen_day_effective_users_ratio", concat(round(when('after_fifteen_day_effective_users > 0, ('eighteen_day_effective_users / 'after_fifteen_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("twenty_one_day_effective_users_ratio", concat(round(when('after_eighteen_day_effective_users > 0, ('twenty_one_day_effective_users / 'after_eighteen_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("twenty_four_day_effective_users_ratio", concat(round(when('after_twenty_one_day_effective_users > 0, ('twenty_four_day_effective_users / 'after_twenty_one_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("twenty_seven_day_effective_users_ratio", concat(round(when('after_twenty_four_day_effective_users > 0, ('twenty_seven_day_effective_users / 'after_twenty_four_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("thirty_day_effective_users_ratio", concat(round(when('after_twenty_seven_day_effective_users > 0, ('thirty_day_effective_users / 'after_twenty_seven_day_effective_users) * 100).otherwise(0), 2), lit("%")))
      //周流程统计表
      .withColumn("first_week_effective_users_ratio", concat(round(when('effective_users > 0, ('first_week_effective_users / 'effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("second_week_effective_users_ratio", concat(round(when('after_first_week_effective_users > 0, ('second_week_effective_users / 'after_first_week_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("third_week_effective_users_ratio", concat(round(when('after_second_week_effective_users > 0, ('third_week_effective_users / 'after_second_week_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("fourth_week_effective_users_ratio", concat(round(when('after_third_week_effective_users > 0, ('fourth_week_effective_users / 'after_third_week_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("fifth_week_effective_users_ratio", concat(round(when('after_fourth_week_effective_users > 0, ('fifth_week_effective_users / 'after_fourth_week_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("sixth_week_effective_users_ratio", concat(round(when('after_fifth_week_effective_users > 0, ('sixth_week_effective_users / 'after_fifth_week_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("seventh_week_effective_users_ratio", concat(round(when('after_sixth_week_effective_users > 0, ('seventh_week_effective_users / 'after_sixth_week_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("eighth_week_effective_users_ratio", concat(round(when('after_seventh_week_effective_users > 0, ('eighth_week_effective_users / 'after_seventh_week_effective_users) * 100).otherwise(0), 2), lit("%")))
      //月留存统计表
      .withColumn("first_month_effective_users_ratio", concat(round(when('effective_users > 0, ('first_month_effective_users / 'effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("second_month_effective_users_ratio", concat(round(when('after_first_month_effective_users > 0, ('second_month_effective_users / 'after_first_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("third_month_effective_users_ratio", concat(round(when('after_second_month_effective_users > 0, ('third_month_effective_users / 'after_second_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("fourth_month_effective_users_ratio", concat(round(when('after_third_month_effective_users > 0, ('fourth_month_effective_users / 'after_third_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("fifth_month_effective_users_ratio", concat(round(when('after_fourth_month_effective_users > 0, ('fifth_month_effective_users / 'after_fourth_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("sixth_month_effective_users_ratio", concat(round(when('after_fifth_month_effective_users > 0, ('sixth_month_effective_users / 'after_fifth_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("seventh_month_effective_users_ratio", concat(round(when('after_sixth_month_effective_users > 0, ('seventh_month_effective_users / 'after_sixth_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("eighth_month_effective_users_ratio", concat(round(when('after_seventh_month_effective_users > 0, ('eighth_month_effective_users / 'after_seventh_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("ninth_month_effective_users_ratio", concat(round(when('after_eighth_month_effective_users > 0, ('ninth_month_effective_users / 'after_eighth_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("tenth_month_effective_users_ratio", concat(round(when('after_ninth_month_effective_users > 0, ('tenth_month_effective_users / 'after_ninth_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("eleventh_month_effective_users_ratio", concat(round(when('after_tenth_month_effective_users > 0, ('eleventh_month_effective_users / 'after_tenth_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("twelfth_month_effective_users_ratio", concat(round(when('after_eleventh_month_effective_users > 0, ('twelfth_month_effective_users / 'after_eleventh_month_effective_users) * 100).otherwise(0), 2), lit("%")))
      .withColumn("inc_day", 'statdate)
      .persist()

    val day_retained = o_user_monitor.select(day_cols: _*)
    val week_retained = o_user_monitor.select(week_cols: _*)
    val month_retained = o_user_monitor.select(month_cols: _*)

    writeToHive(spark, day_retained, Seq("inc_day"), "dm_gis.scomm_user_day_retained")
    writeToHive(spark, week_retained, Seq("inc_day"), "dm_gis.scomm_user_week_retained")
    writeToHive(spark, month_retained, Seq("inc_day"), "dm_gis.scomm_user_month_retained")

    o_user_monitor.unpersist()
  }

}
