package com.sf.app.veh

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil

/**
 * @description: 新版清洗逻辑
 * @author 01418539 caojia
 * @date 2022/8/18 15:39
 */
object VehicleInsuranceRiskDayFixNew extends DataSourceCommon {
  def processFixDayNew(spark: SparkSession, o_day_df: DataFrame): DataFrame = {
    import spark.implicits._
    //part 1 里程 16
    val o_dist_t_cols_str = Seq("total_links_dist")
    //分时段 早中晚 5
    val o_dist_d_cols_str = Seq("night_dirve_dist", "before_dawn_drive_dist", "early_morning_drive_dist", "afternoon_drive_dist", "dusk_drive_dist")
    //道路等级:高速 省道 5
    val o_dist_c_cols_str = Seq("high_speed_dist", "state_road_dist", "provincial_dist", "county_dist", "township_dist")
    //道路设施:危险 学校 5
    val o_dist_r_cols_str = Seq("dangerous_road_dist", "high_accident_road_dist", "school_road_dist", "sharp_turn_road_dist", "village_road_dist")
    //分时段的道路等级及道路设施
    val o_dist_20_cols_str = Seq("night_high_speed_dist", "night_state_road_dist", "night_provincial_dist", "night_county_dist", "night_township_dist", "before_dawn_high_speed_dist", "before_dawn_state_road_dist", "before_dawn_provincial_dist", "before_dawn_county_dist", "before_dawn_township_dist", "early_morning_high_speed_dist", "early_morning_state_road_dist", "early_morning_provincial_dist", "early_morning_county_dist", "early_morning_township_dist", "afternoon_high_speed_dist", "afternoon_state_road_dist", "afternoon_provincial_dist", "afternoon_county_dist", "afternoon_township_dist", "dusk_high_speed_dist", "dusk_state_road_dist", "dusk_provincial_dist", "dusk_county_dist", "dusk_township_dist")

    //part 2 时长 13
    val o_dura_t_cols_str = Seq("total_links_duration")
    //分时段 早中晚 5
    val o_dura_d_cols_str = Seq("night_dirve_duration", "before_dawn_drive_duration", "early_morning_drive_duration", "afternoon_drive_duration", "dusk_drive_duration")
    //道路等级:高速 省道 5
    val o_dura_c_cols_str = Seq("high_speed_duration", "state_road_duration", "provincial_duration", "county_duration", "township_duration")
    //道路设施:危险 学校 5
    val o_dura_r_cols_str = Seq("dangerous_road_duration", "high_accident_road_duration", "school_road_duration", "sharp_turn_road_duration", "township_road_duration")
    //分时段的道路等级及道路设施
    val o_dura_20_cols_str = Seq("night_high_speed_duration", "night_state_road_duration", "night_provincial_duration", "night_county_duration", "night_township_duration", "before_dawn_high_speed_duration", "before_dawn_state_road_duration", "before_dawn_provincial_duration", "before_dawn_county_duration", "before_dawn_township_duration", "early_morning_high_speed_duration", "early_morning_state_road_duration", "early_morning_provincial_duration", "early_morning_county_duration", "early_morning_township_duration", "afternoon_high_speed_duration", "afternoon_state_road_duration", "afternoon_provincial_duration", "afternoon_county_duration", "afternoon_township_duration", "dusk_high_speed_duration", "dusk_state_road_duration", "dusk_provincial_duration", "dusk_county_duration", "dusk_township_duration")

    //part 3 超速 超时 驾驶时长  2+1 新增了一个高速上低速行驶
    val o_dura_o_cols_str: Seq[String] = Seq("over_speed_duration", "over_speed_ser_duration", "high_speed_lowspeed_duration")

    val o_fix_cols_str = o_dist_t_cols_str ++ o_dist_d_cols_str ++ o_dist_c_cols_str ++ o_dist_r_cols_str ++ o_dist_20_cols_str ++ o_dura_t_cols_str ++ o_dura_d_cols_str ++ o_dura_c_cols_str ++ o_dura_r_cols_str ++ o_dura_20_cols_str ++ o_dura_o_cols_str

    o_day_df.persist(StorageLevel.MEMORY_AND_DISK_SER)

    val new_day_cols: Seq[Column] = o_day_df.schema.map(_.name).map(col)

    //1 时长异常
    val ne_dura_d_cols = fsdDuraCond(o_dura_d_cols_str, o_dist_d_cols_str, "before_dawn_drive_duration", "before_dawn_drive_dist", "before_dawn", 10800, 14400)
    val ne_dura_cr_cols = fssDuraCond(o_dura_r_cols_str, o_dist_r_cols_str, 'total_links_duration, 86400)
    val ne_dura_t_cols = totalDuraCond(o_dura_d_cols_str, o_dura_c_cols_str, "first")
    val ne_dura_20_cols = fsdDuraCond(o_dura_20_cols_str, o_dist_20_cols_str, "before_dawn_drive_duration", "before_dawn_drive_dist", "before_dawn", 10800, 14400, "start_index")

    //2 里程异常
    val ne_dist_d_cols = fsdDistCond(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", "before_dawn", 300000, 400000, "first")
    val ne_dist_cr_cols = fssDistCond(o_dist_r_cols_str, o_dura_r_cols_str, 'total_links_dist, 2400000, "first")
    val ne_dist_t_cols = totalDistCond(o_dist_d_cols_str, o_dist_c_cols_str, "first")
    val ne_dist_20_cols = fsdDistCond(o_dist_20_cols_str, o_dura_20_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", "before_dawn", 300000, 400000, "first", "start_index")

    //3 速度异常
    val ne_dura_os_cols = overSpeedCond(o_dura_o_cols_str.filter(_ != "high_speed_lowspeed_duration"), "first")
    val ne_dura_hl_cols = highSpeedLowerDuraCond(o_dura_o_cols_str.filter(_ == "high_speed_lowspeed_duration"), "first")

    val excp_cols = Seq(ne_dist_t_cols) ++ ne_dist_d_cols ++ ne_dist_cr_cols ++ Seq(ne_dura_t_cols) ++ ne_dura_d_cols ++ ne_dura_cr_cols ++ ne_dura_os_cols ++ ne_dura_hl_cols ++ ne_dura_20_cols ++ ne_dist_20_cols
    //只要一个字段异常 则车辆标记为异常
    val ex_flag = excp_cols.foldLeft(lit(0))(_ + _).alias("ex_flag") //正常 14740/15554=94.7%

    val o_day_add_ex_df = o_day_df.repartition(200)
      .select(new_day_cols ++ excp_cols :+ ex_flag: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //计算各段的 正常速度 和 超速时长占比
    val agg_cols = ColumnUtil.renameColumn(o_fix_cols_str.map(sum(_)), o_fix_cols_str)
    val fd_speed_cols = partNormalSpeed(o_dist_t_cols_str ++ o_dist_d_cols_str ++ o_dist_r_cols_str, o_dura_t_cols_str ++ o_dura_d_cols_str ++ o_dura_r_cols_str)

    val norm_sp_prop_df = o_day_add_ex_df
      .select((o_fix_cols_str :+ "ex_flag" :+ "inc_day").map(col): _*)
      .filter('ex_flag === 0)
      .groupBy("inc_day")
      .agg(agg_cols.head, agg_cols.tail: _*)
      .withColumn("normal_osp_prop", when('over_speed_ser_duration =!= 0, 'over_speed_duration / 'over_speed_ser_duration).otherwise(0))
      .select(fd_speed_cols ++ Seq(col("normal_osp_prop"), col("inc_day")): _*) //.collect().head

    //异常标签数据中 异常标识字段 ++ 阶段正常速度++ 超速时长占比 +12个字段
    val day_norm_sp_prop_df = o_day_add_ex_df
      .join(norm_sp_prop_df, Seq("inc_day"), "left")
      //剔除需要 第2次 异常判断 字段
      .drop((o_dura_t_cols_str ++ o_dist_d_cols_str ++ o_dist_r_cols_str ++ o_dist_t_cols_str ++ o_dura_o_cols_str ++ o_dist_20_cols_str).map(_ + "_ex"): _*)

    val day_norm_sp_prop_cols = day_norm_sp_prop_df.schema.map(_.name).map(col)

    //4.1 修正第1部分数据[分时段时长 分道路设施时长]
    val fd_dura_fix = fixFdDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", 10800, 14400, "dura")
    val r_dura_fix = fixOtherDistOrDura(o_dist_r_cols_str, o_dura_r_cols_str, 86400, 'total_links_dist, 'total_links_duration, "dura")
    val t1 = day_norm_sp_prop_df.select(day_norm_sp_prop_cols ++ fd_dura_fix ++ r_dura_fix: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //4.2 重新 打标第2部分异常标签 并进行时长 里程修正
    //4.2.1 异常打标：[总时长、分时段里程、分设施里程]
    val ne2_dura_t_cols = totalDuraCond(o_dura_d_cols_str, o_dura_c_cols_str, "second")
    val ne2_dist_d_cols = fsdDistCond(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", "before_dawn", 300000, 400000, "second")
    val ne2_dist_r_cols = fssDistCond(o_dist_r_cols_str, o_dura_r_cols_str, 'total_links_dist, 2400000, "second")
    val t2 = t1.select(t1.schema.map(_.name).map(col) ++ Seq(ne2_dura_t_cols) ++ ne2_dist_d_cols ++ ne2_dist_r_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //4.2.2 修正 先修正总时长 分路段时长5f 和 不同时段的分路段时长20f 不用异常判断
    //fix时长 total/分时段里程/分道路等级里程
    val total_links_duration_fix = fixTotalDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, 'total_links_dist, 'total_links_duration, 'total_links_dist_sp, 86400, "dura")
      .alias("total_links_duration_fix")
    val fd_dist_fix = fixFdDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", 300000, 400000, "dist")
    val other_dist_fix = fixOtherDistOrDura(o_dist_r_cols_str, o_dura_r_cols_str, 2400000, 'total_links_dist, 'total_links_duration, "dist")
    val t20 = t2.select(t2.schema.map(_.name).map(col) ++ Seq(total_links_duration_fix) ++ fd_dist_fix ++ other_dist_fix: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val fld_dura_fix = fixRoadDistOrDura(o_dura_c_cols_str, "dura")
    val t21 = t20.select(t20.schema.map(_.name).map(col) ++ fld_dura_fix: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val fsd_dura_p20_fix = fixPart20DistOrDura(o_dura_20_cols_str, "dura")
    val t22 = t21.select(t21.schema.map(_.name).map(col) ++ fsd_dura_p20_fix: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    //4.3 重新异常标签打标 总里程  并进行里程修正
    //4.3.1 异常打标 [总里程 速度]
    val ne2_dist_t_cols = totalDistCond(o_dist_d_cols_str, o_dist_c_cols_str, "second")
    val ne2_dura_os_cols = overSpeedCond(o_dura_o_cols_str.filter(_ != "high_speed_lowspeed_duration"), "second")
    val ne2_dura_hl_cols = highSpeedLowerDuraCond(o_dura_o_cols_str.filter(_ == "high_speed_lowspeed_duration"), "second")
    val ne2_dist_20_cols = fsdDistCond(o_dist_20_cols_str, o_dura_20_cols_str, "before_dawn_drive_dist", "before_dawn_drive_duration", "before_dawn", 300000, 400000, "second", "start_index")

    val t3 = t22.select(t22.schema.map(_.name).map(col) ++ Seq(ne2_dist_t_cols) ++ ne2_dura_os_cols ++ ne2_dura_hl_cols ++ ne2_dist_20_cols: _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //4.3.2 修正总里程 和 3类速度
    val total_links_dist_fix = fixTotalDistOrDura(o_dist_d_cols_str, o_dura_d_cols_str, 'total_links_dist, 'total_links_duration, 'total_links_dist_sp, 2400000, "dist")
      .alias("total_links_dist_fix")
    //fix严重超速
    val over_speed_ser_duration_fix = when('over_speed_ser_duration_ex === 1, 0)
      .otherwise('over_speed_ser_duration)
      .alias("over_speed_ser_duration_fix")
    //fix高度路段低速行驶
    val high_lower_duration_fix = when('high_speed_lowspeed_duration_ex === 1, 'high_speed_duration_fix)
      .otherwise('high_speed_lowspeed_duration)
      .alias("high_speed_lowspeed_duration_fix")
    val t30 = t3.select(t3.schema.map(_.name).map(col) ++ Seq(total_links_dist_fix, over_speed_ser_duration_fix, high_lower_duration_fix): _*)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //4.3.3 修正分路段里程 和 不同时段的分路段里程
    val fld_dist_fix = fixRoadDistOrDura(o_dist_c_cols_str, "dist")
    val t31 = t30.select(t30.schema.map(_.name).map(col) ++ fld_dist_fix: _*)
      .repartition(200)
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    val fsd_dist_p20_fix = fixPart20DistOrDura(o_dist_20_cols_str, "dist")
    //fix超速
    val over_speed_duration_fix = when('over_speed_duration_ex === 1, 'over_speed_ser_duration_fix * 'normal_osp_prop)
      .otherwise('over_speed_duration)
    val day_fix_df = t31.select(t31.schema.map(_.name).map(col) ++ fld_dist_fix ++ fsd_dist_p20_fix: _*)
      .withColumn("over_speed_duration_fix", over_speed_duration_fix)
      .withColumn("adcode_duration_map", fixCodeMap('adcode_duration_map, 'total_links_duration, 'total_links_duration_fix))
      .withColumn("adcode_dist_map", fixCodeMap('adcode_dist_map, 'total_links_dist, 'total_links_dist_fix))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    //加载fix表字段信息
    val fix_res_cols = spark.sql("""select * from dm_gis.new_org_first_part_insurance_daily limit 0""").schema.map(_.name).map(x => if (o_fix_cols_str.contains(x)) x + "_fix" else x).map(col)
    val res = day_fix_df.select(fix_res_cols: _*).persist(StorageLevel.MEMORY_AND_DISK_SER)
//    writeToHive(spark, res.coalesce(50), Seq("inc_day", "ak"), "dm_gis.new_org_first_part_insurance_daily")
    res
  }


  /**
   * 将映射map字段进行修正
   * adcode_duration_map	{510112=235.43998599999998, 510104=186.83998499999998, 510116=977.2199139999998, 510107=198.57597599999997}
   * adcode_dist_map	{510112=6187, 510104=4832, 510116=16272, 510107=4772}
   *
   * @param map_str
   * @return
   */
  def fixCodeMap = udf((adcode_duration_map: String, total_links_duration: String, total_links_duration_fix: String) => {
    val adcode_arr = adcode_duration_map.replaceAll("\\{|\\}| ", "").split(",")
    val new_arr = new Array[String](adcode_arr.length)

    val ratio: Double = try {
      if (total_links_duration.toDouble != 0) total_links_duration_fix.toDouble / total_links_duration.toDouble else 1
    } catch {
      case e: Exception => logger.error("原始里程/时长 有异常" + e.getMessage)
        1
    }
    for (i <- 0 until adcode_arr.length) {
      var key = ""
      var value = ""
      try {
        key = adcode_arr(i).split("=")(0)
        value = adcode_arr(i).split("=")(1)
        new_arr(i) = key + "=" + value.toDouble * ratio
      } catch {
        case e: ArrayIndexOutOfBoundsException =>
          new_arr(i) = adcode_arr(i)
          logger.error("指标越界，检查字段类型是否规范" + e.getMessage)
      }
    }
    "{" + new_arr.mkString(",").replaceAll("\\[|\\]", "") + "}"
  })

  /**
   * 列 比较大小  取最小值 min
   *
   * @param threshold 给定阈值
   * @return
   */
  def compareMinCol(threshold: Double) = udf((c1: String, c2: String) => {
    var res = threshold
    try {
      if (c1.toDouble >= c2.toDouble) res = c2.toDouble else res = c1.toDouble
    } catch {
      case e: Exception => logger.error("数据有空值。" + e.getMessage)
    }
    res
  })

  /**
   * 列 比较大小 取最大值max
   *
   * @param threshold 给定阈值
   * @return
   */
  def compareMaxCol(threshold: Double) = udf((c1: String, c2: String) => {
    var res = threshold
    try {
      if (c1.toDouble >= c2.toDouble) res = c1.toDouble else res = c2.toDouble
    } catch {
      case e: Exception => logger.error("数据有空值。" + e.getMessage)
    }
    res
  })

  /**
   * 计算 给定阶段 的 平均速度 （无异常车辆）
   *
   * @param cols_str
   * @param row
   * @return
   */
  def addSpeed(cols_str: Seq[String], row: Row): Seq[Column] = {
    var add_cols: Seq[Column] = Nil
    for (i <- 0 until row.schema.size) {
      add_cols = add_cols :+ lit(row.get(i)).alias(cols_str(i))
    }
    add_cols
  }

  /**
   * 计算 分段的平均速度
   *
   * @param t_cols_str
   * @param d_cols_str
   */
  def partNormalSpeed(t_cols_str: Seq[String], d_cols_str: Seq[String]): Seq[Column] = {
    val newNames = t_cols_str.map(_ + "_sp")
    val t_cols = t_cols_str.map(x => col(x).cast("double"))
    val d_cols = d_cols_str.map(x => col(x).cast("double"))
    val sp_cols = t_cols zip d_cols map { x => when(x._2 =!= 0, x._1 / x._2).otherwise(0) }
    ColumnUtil.renameColumn(sp_cols, newNames)
  }

  /**
   * fix 总时长 or 总里程
   *
   * @param d_cols_str           里程字段
   * @param t_cols_str           时长字段
   * @param total_links_dist     总里程-未修正
   * @param total_links_duration 总时长-未修正
   * @param norm_sp              正常车辆速度
   * @param threshold
   * @param flag                 dist or dura
   * @return
   */
  def fixTotalDistOrDura(d_cols_str: Seq[String], t_cols_str: Seq[String], total_links_dist: Column, total_links_duration: Column, norm_sp: Column, threshold: Long, flag: String): Column = {
    var res_cols = lit("")
    if (flag == "dist") {
      val fd_dist_sum = d_cols_str.map(_ + "_fix").map(col).foldLeft(lit(0))(_ + _)
      val fd_dura_sum = t_cols_str.map(_ + "_fix").map(col).foldLeft(lit(0))(_ + _)
      val cond1_cols = fd_dist_sum + 800000
      val cond2 = (col("total_links_duration_fix") - fd_dura_sum) * norm_sp
      val cond2_cols = fd_dist_sum + compareMaxCol(0)(lit(0), cond2)
      val cond3_cols = lit(threshold)
      res_cols = when(col("total_links_dist_ex") =!= 0, compareMinCol(0)(cond1_cols, compareMinCol(0)(cond2_cols, cond3_cols))).otherwise(total_links_dist)
    }
    if (flag == "dura") {
      val fd_dist_sum = d_cols_str.map(x => col(x).cast("double")).foldLeft(lit(0))(_ + _)
      val fd_dura_sum = t_cols_str.map(_ + "_fix").map(x => col(x).cast("double")).foldLeft(lit(0))(_ + _)
      val cond1_cols = fd_dura_sum + 28800
      val cond2 = when(norm_sp =!= 0, (total_links_dist - fd_dist_sum) / norm_sp).otherwise(0)
      val cond2_cols = fd_dura_sum + compareMaxCol(0)(lit(0), cond2)
      val cond3_cols = lit(threshold)
      res_cols = when(col("total_links_duration_ex") =!= 0, compareMinCol(0)(cond1_cols, compareMinCol(0)(cond2_cols, cond3_cols))).otherwise(total_links_duration)
    }
    res_cols
  }

  /**
   * fix 分段时长 or 分段里程
   *
   * @param cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fixFdDistOrDura(d_cols_str: Seq[String], t_cols_str: Seq[String], d_diff_str: String, t_diff_str: String, threshold: Long, diff_threshold: Long, flag: String): Seq[Column] = {
    var fix_cols_str = Seq("")
    var ex_cols = Seq(lit(""))
    var norm_d = Seq(lit(""))
    var diff_d = Seq(lit(""))
    var fix_d_t = Seq(lit(""))

    var default_cols = Seq(lit(""))

    if (flag == "dist") {
      val d_order_str = d_cols_str.filter(_ == d_diff_str) ++ d_cols_str.filter(_ != d_diff_str)
      val t_order_str = (t_cols_str.filter(_ == t_diff_str) ++ t_cols_str.filter(_ != t_diff_str)).map(_ + "_fix")
      fix_cols_str = d_order_str.map(_ + "_fix")

      ex_cols = d_order_str.map(_ + "_ex").map(x => col(x).cast("double"))

      norm_d = d_cols_str.filter(_ == d_diff_str).map(x => lit(diff_threshold))
      diff_d = d_cols_str.filter(_ != d_diff_str).map(x => lit(threshold))
      //此处目的：顺序对应
      val fd_sp = d_order_str.map(_ + "_sp").map(x => col(x).cast("double"))
      val fd_tm = t_order_str.map(x => col(x).cast("double"))

      fix_d_t = fd_tm zip fd_sp map { x => x._1 * x._2 }

      default_cols = d_order_str.map(x => col(x).cast("double"))
    }
    if (flag == "dura") {
      val d_order_str = d_cols_str.filter(_ == d_diff_str) ++ d_cols_str.filter(_ != d_diff_str)
      val t_order_str = t_cols_str.filter(_ == t_diff_str) ++ t_cols_str.filter(_ != t_diff_str)

      fix_cols_str = t_order_str.map(_ + "_fix")
      ex_cols = t_order_str.map(_ + "_ex").map(col)

      norm_d = t_cols_str.filter(_ == t_diff_str).map(x => lit(diff_threshold))
      diff_d = t_cols_str.filter(_ != t_diff_str).map(x => lit(threshold))

      //此处目的：顺序对应
      val fd_dt = d_order_str.map(x => col(x).cast("double"))
      val fd_sp = d_order_str.map(_ + "_sp").map(x => col(x).cast("double"))

      fix_d_t = fd_dt zip fd_sp map { x => when(x._2 =!= 0, x._1 / x._2).otherwise(0) }

      default_cols = t_order_str.map(x => col(x).cast("double"))
    }
    val fd_dist = norm_d ++ diff_d //(((c1,c2),c3),c4)
    val fix_cols = ex_cols zip fd_dist zip fix_d_t zip default_cols map { x => when(x._1._1._1 === 1, compareMinCol(0)(x._1._1._2, x._1._2)).otherwise(x._2) }
    ColumnUtil.renameColumn(fix_cols, fix_cols_str)
  }

  /**
   * fix 其他路段或设施的 时长 or 里程
   *
   * @param cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fixOtherDistOrDura(d_cols_str: Seq[String], t_cols_str: Seq[String], threshold: Long, total_links_dist: Column, total_links_duration: Column, flag: String): Seq[Column] = {
    var fix_cols_str = Seq("")
    var fix_cols = Seq(lit(""))

    if (flag == "dist") {
      fix_cols_str = d_cols_str.map(_ + "_fix")

      val ex_cols_str = d_cols_str.map(_ + "_ex").map(x => col(x).cast("double"))
      val norm_d = d_cols_str.map(x => lit(threshold))
      val norm_dt = d_cols_str.map(x => total_links_dist.cast("double"))

      //速度 * 时间
      val fd_sp = d_cols_str.map(_ + "_sp").map(x => col(x).cast("double"))
      val fd_tm = t_cols_str.map(x => col(x + "_fix"))

      val norm_dc = fd_tm zip fd_sp map { x => x._1 * x._2 } //((((c1,c2),c3),c4),c5)

      val d_cols = d_cols_str.map(x => col(x).cast("double"))
      fix_cols = ex_cols_str zip norm_d zip norm_dt zip norm_dc zip d_cols map { x => when(x._1._1._1._1 === 1, compareMinCol(0)(x._1._1._1._2, compareMinCol(0)(x._1._1._2, x._1._2))).otherwise(x._2) }
    }
    if (flag == "dura") {
      fix_cols_str = t_cols_str.map(_ + "_fix")

      val ex_cols_str = t_cols_str.map(_ + "_ex").map(col)
      val norm_d = t_cols_str.map(x => lit(threshold))
      val norm_dt = t_cols_str.map(x => total_links_duration.cast("double"))
      //里程 / 时间
      val fd_sp = d_cols_str.map(_ + "_sp").map(x => col(x).cast("double"))
      val fd_dist = d_cols_str.map(x => col(x).cast("double"))
      val norm_dc = fd_dist zip fd_sp map { x => when(x._2 =!= 0, x._1 / x._2).otherwise(0) }
      val t_cols = t_cols_str.map(x => col(x).cast("double")) //((((c1,c2),c3),c4),c5)
      fix_cols = ex_cols_str zip norm_d zip norm_dt zip norm_dc zip t_cols map { x => when(x._1._1._1._1 === 1, compareMinCol(0)(x._1._1._1._2, compareMinCol(0)(x._1._1._2, x._1._2))).otherwise(x._2) }
    }
    ColumnUtil.renameColumn(fix_cols, fix_cols_str)
  }

  /**
   * 修正分路段时长/里程 同比例缩放
   *
   * @param t
   * @param flag
   * @return
   */
  def fixRoadDistOrDura(t: Seq[String], flag: String): Seq[Column] = {
    val fix_cols_str = t.map(_ + "_fix")
    var fix_ratio = lit("")
    if (flag == "dura") {
      fix_ratio = when(col("total_links_duration").cast("double") =!= 0, col("total_links_duration_fix").cast("double") / col("total_links_duration").cast("double")).otherwise(1)
    }
    if (flag == "dist") {
      fix_ratio = when(col("total_links_dist").cast("double") =!= 0, col("total_links_dist_fix").cast("double") / col("total_links_dist").cast("double")).otherwise(1)
    }
    val zoom_cols = t.map(x => col(x).cast("double") * fix_ratio)
    ColumnUtil.renameColumn(zoom_cols, fix_cols_str)
  }

  /**
   * fix 其他路段或设施的 时长
   *
   * @param t    需要修正的20个 时长字段
   * @param flag dist 或 dura 修正标识
   */
  def fixPart20DistOrDura(t: Seq[String], flag: String): Seq[Column] = {
    val order_cols_str = t.filter(_.startsWith("night_")) ++ t.filter(_.startsWith("before_")) ++ t.filter(_.startsWith("early_")) ++ t.filter(_.startsWith("afternoon_")) ++ t.filter(_.startsWith("dusk_"))
    val fix_cols_str = order_cols_str.map(_ + "_fix")
    val ex_cols_str = order_cols_str.map(_ + "_ex").map(col)

    var p_col = lit("")

    if (flag == "dura") {
      p_col = when(col("total_links_duration") =!= 0, col("total_links_duration_fix") / col("total_links_duration")).otherwise(1)
    }
    if (flag == "dist") {
      p_col = when(col("total_links_dist") =!= 0, col("total_links_dist_fix") / col("total_links_dist")).otherwise(1)
    }
    val night_cols = t.filter(_.startsWith("night_")).map(x => col(x) * p_col)
    val before_cols = t.filter(_.startsWith("before_")).map(x => col(x) * p_col)
    val early_cols = t.filter(_.startsWith("early_")).map(x => col(x) * p_col)
    val afternoon_cols = t.filter(_.startsWith("afternoon_")).map(x => col(x) * p_col)
    val dusk_cols = t.filter(_.startsWith("dusk_")).map(x => col(x) * p_col)
    val ex_cols = night_cols ++ before_cols ++ early_cols ++ afternoon_cols ++ dusk_cols

    val fix_cols = ex_cols_str zip ex_cols zip order_cols_str.map(col) map { x => when(x._1._1 === 1, x._1._2).otherwise(x._2) }

    ColumnUtil.renameColumn(fix_cols, fix_cols_str)
  }

  /**
   * fix 城市 乡道 等 里程
   *
   * @param t_cols_str
   * @param total_links_dist
   * @param threshold
   * @return
   */
  def fixCityDist(t_cols_str: Seq[String], total_links_dist: Column, threshold: Long): Seq[Column] = {
    val fix_cols_str = t_cols_str.map(_ + "_fix")

    val ex_cols_str = t_cols_str.map(_ + "_ex").map(col)
    val norm_d = t_cols_str.map(x => lit(threshold))
    val d_cols = t_cols_str.map(x => col(x).cast("double")) //((c1,c2),c3)
    val fix_cols = ex_cols_str zip norm_d zip d_cols map { x => when(x._1._1 === 1, compareMinCol(0)(x._2, compareMinCol(0)(x._1._2, total_links_dist))).otherwise(x._2) }

    ColumnUtil.renameColumn(fix_cols, fix_cols_str)
  }

  /**
   * 高速上的低速行驶时长 异常判断
   *
   * @param cols_str
   * @param t_dura
   */
  def highSpeedLowerDuraCond(cols_str: Seq[String], flag: String): Seq[Column] = {
    val ex_cols_str = cols_str.map(_ + "_ex")
    var res_cols = Seq(lit(""))
    if (flag == "first") {
      res_cols = cols_str.map(x => col(x).cast("double")).map { x => when(x > col("high_speed_duration").cast("double") || x < 0, 1).otherwise(0) }
    }
    if (flag == "second") {
      res_cols = cols_str.map(x => col(x).cast("double")).map { x => when(x > col("high_speed_duration_fix").cast("double") || x < 0, 1).otherwise(0) }
    }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 超速行驶 时长 异常判断
   *
   * @param cols_str
   * @param t_dura
   */
  def overSpeedCond(cols_str: Seq[String], flag: String): Seq[Column] = {
    val ex_cols_str = cols_str.map(_ + "_ex")
    var res_cols = Seq(lit(""))
    if (flag == "first") {
      res_cols = cols_str.map(x => col(x).cast("double")).map { x => when(x > col("total_links_duration").cast("double") || x < 0, 1).otherwise(0) }
    }
    if (flag == "second") {
      res_cols = cols_str.map(x => col(x).cast("double")).map { x => when(x > col("total_links_duration_fix").cast("double") || x < 0, 1).otherwise(0) }
    }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 总里程total dist 异常判断  2次
   *
   * @param total_links_dist
   * @param fsd_dist_cols_str
   * @param fld_dist_cols_str
   * @param flag
   * @return
   */

  def totalDistCond(fsd_dist_cols_str: Seq[String], fld_dist_cols_str: Seq[String], flag: String): Column = {
    var fsd_dist_sum = lit(0.0)
    var fld_dist_sum = lit(0.0)
    var ex_total_links_dist = lit("")
    if (flag == "first") {
      fsd_dist_sum = fsd_dist_cols_str.map(x => col(x).cast("double")).foldLeft(lit(0.0))(_ + _)
      fld_dist_sum = fld_dist_cols_str.map(x => col(x).cast("double")).foldLeft(lit(0.0))(_ + _)

      ex_total_links_dist = when(col("total_links_dist") > 2400000, 1)
        .when(col("total_links_dist").cast("double") - fsd_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fsd_dist_sum, lit(-1000)).cast("double"), 2)
        .when(col("total_links_dist").cast("double") - fsd_dist_sum.cast("double") > 800000, 3)
        .when(col("total_links_dist").cast("double") - fld_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fld_dist_sum, lit(-1000)).cast("double"), 4)
        .when(col("total_links_duration").cast("double") === 0 && col("total_links_dist").cast("double") =!= 0, 5)
        .when(col("total_links_duration").cast("double") =!= 0 && col("total_links_dist").cast("double") / col("total_links_duration").cast("double") > 45, 5)
        .when(col("total_links_duration").cast("double") > 600 && col("total_links_dist").cast("double") === 0, 6)
        .otherwise(0)
        .alias("total_links_dist_ex")
    }
    if (flag == "second") {
      fsd_dist_sum = fsd_dist_cols_str.map(x => col(x + "_fix")).foldLeft(lit(0.0))(_ + _).alias("fsd_dist_sum")
      fld_dist_sum = fld_dist_cols_str.map(col).foldLeft(lit(0.0))(_ + _).alias("fld_dist_sum")

      ex_total_links_dist = when(col("total_links_dist") > 2400000, 1)
        .when(col("total_links_dist").cast("double") - fsd_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fsd_dist_sum, lit(-1000)).cast("double"), 2)
        .when(col("total_links_dist").cast("double") - fsd_dist_sum.cast("double") > 800000, 3)
        .when(col("total_links_dist").cast("double") - fld_dist_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fld_dist_sum, lit(-1000)).cast("double"), 4)
        .when(col("total_links_duration_fix").cast("double") === 0 && col("total_links_dist").cast("double") =!= 0, 5)
        .when(col("total_links_duration_fix").cast("double") =!= 0 && col("total_links_dist").cast("double") / col("total_links_duration_fix").cast("double") > 45, 5)
        .when(col("total_links_duration_fix").cast("double") > 600 && col("total_links_dist").cast("double") === 0, 6)
        .otherwise(0)
        .alias("total_links_dist_ex")
    }
    ex_total_links_dist
  }

  /**
   * 总时长total duration 异常判断  2次
   *
   * @param fsd_duration_cols_str
   * @param flag
   * @return
   */
  def totalDuraCond(fsd_duration_cols_str: Seq[String], fld_duration_cols_str: Seq[String], flag: String): Column = {
    var fsd_duration_sum = lit(0.0)
    var fld_duration_sum = lit(0.0)

    if (flag == "first") {
      fsd_duration_sum = fsd_duration_cols_str.map(x => col(x).cast("double")).foldLeft(lit(0.0))(_ + _)
    }
    if (flag == "second") {
      fsd_duration_sum = fsd_duration_cols_str.map(x => col(x + "_fix").cast("double")).foldLeft(lit(0.0))(_ + _)
    }
    val ex_total_links_duration = when(col("total_links_duration") > 86400, 1)
      .when(col("total_links_duration").cast("double") - fsd_duration_sum.cast("double") < compareMinCol(-600)(lit(-0.01) * fsd_duration_sum, lit(-600)).cast("double"), 2)
      .when(col("total_links_duration").cast("double") - fsd_duration_sum.cast("double") > 28800, 3)
      .when(col("total_links_duration").cast("double") - fld_duration_sum.cast("double") < compareMinCol(-1000)(lit(-0.01) * fld_duration_sum, lit(-600)).cast("double"), 4)
      .when(col("total_links_dist").cast("double") > 5000 && col("total_links_duration").cast("double") === 0, 5)
      .otherwise(0)
      .alias("total_links_duration_ex")
    ex_total_links_duration
  }

  /**
   * 分时段 里程dist  异常判断
   *
   * @param dist_cols_str
   * @param duration_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fsdDistCond(dist_cols_str: Seq[String], duration_cols_str: Seq[String], dist_diff_str: String, dura_diff_str: String, diff_str: String, threshold: Long, diff_threshold: Long, flag: String, start_index: String = ""): Seq[Column] = {
    var norm_dist_cols_str = dist_cols_str.filter(_ != dist_diff_str)
    var diff_dist_cols_str = dist_cols_str.filter(_ == dist_diff_str)
    var norm_duration_cols_str = duration_cols_str.filter(_ != dura_diff_str)
    var diff_duration_cols_str = duration_cols_str.filter(_ == dura_diff_str)

    if (start_index == "start_index") {
      norm_dist_cols_str = dist_cols_str.filter(!_.startsWith(diff_str))
      diff_dist_cols_str = dist_cols_str.filter(_.startsWith(diff_str))
      norm_duration_cols_str = duration_cols_str.filter(!_.startsWith(diff_str))
      diff_duration_cols_str = duration_cols_str.filter(_.startsWith(diff_str))
    }

    val ex_cols_str = (norm_dist_cols_str ++ diff_dist_cols_str).map(_ + "_ex")
    //里程判断 2次条件不变
    val cond1_norm_cols = norm_dist_cols_str.map(x => col(x).cast("double")).map { x => when(x > threshold, 1).otherwise(0) }
    val cond1_diff_cols = diff_dist_cols_str.map(x => col(x).cast("double")).map { x => when(x > diff_threshold, 1).otherwise(0) }
    //需要2次异常判断
    var cond2_norm_cols = Seq(lit(""))
    var cond2_diff_cols = Seq(lit(""))

    if (flag == "first") {
      //时段速度判断 时长里程同时判断
      cond2_norm_cols = norm_dist_cols_str.map(x => col(x).cast("double")) zip norm_duration_cols_str.map(x => col(x).cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
      cond2_diff_cols = diff_dist_cols_str.map(x => col(x).cast("double")) zip diff_duration_cols_str.map(x => col(x).cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    if (flag == "second") {
      //时段速度判断 时长里程同时判断
      cond2_norm_cols = norm_dist_cols_str.map(x => col(x).cast("double")) zip norm_duration_cols_str.map(x => col(x + "_fix").cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
      cond2_diff_cols = diff_dist_cols_str.map(x => col(x).cast("double")) zip diff_duration_cols_str.map(x => col(x + "_fix").cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    val cond1 = cond1_norm_cols ++ cond1_diff_cols
    val cond2 = cond2_norm_cols ++ cond2_diff_cols

    //(c1,c2)
    val res_cols = cond1 zip cond2 map { x => when(x._1 === 1 || x._2 === 1, 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 分设施 里程dist  异常判断
   *
   * @param dist_cols_str
   * @param duration_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fssDistCond(dist_cols_str: Seq[String], duration_cols_str: Seq[String], t_dist: Column, threshold: Long, flag: String): Seq[Column] = {
    val ex_cols_str = dist_cols_str.map(_ + "_ex")
    //里程判断 两次条件不变
    val cond1 = dist_cols_str.map(x => col(x).cast("double")).map { x => when(x > compareMinCol(0)(t_dist * 1.1, lit(threshold)).cast("double"), 1).otherwise(0) }
    //需要第2次异常判断
    var cond2 = Seq(lit(""))

    if (flag == "first") {
      cond2 = dist_cols_str.map(x => col(x).cast("double")) zip duration_cols_str.map(x => col(x).cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    if (flag == "second") {
      cond2 = dist_cols_str.map(x => col(x).cast("double")) zip duration_cols_str.map(x => col(x + "_fix").cast("double")) map { x => when((x._2 =!= 0 && x._1 / x._2 > 45) || (x._1 === 0 && x._2 > 600), 1).otherwise(0) }
    }
    //((c1,c2),c3)
    val res_cols = cond1 zip cond2 map { x => when(x._1 === 1 || x._2 === 1, 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 分时段 时长duration 异常判断
   *
   * @param duration_cols_str
   * @param dist_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fsdDuraCond(duration_cols_str: Seq[String], dist_cols_str: Seq[String], dura_diff_str: String, dist_diff_str: String, diff_str: String, threshold: Long, diff_threshold: Long, start_index: String = ""): Seq[Column] = {
    var norm_duration_cols_str = duration_cols_str.filter(_ != dura_diff_str)
    var diff_duration_cols_str = duration_cols_str.filter(_ == dura_diff_str)
    var norm_dist_cols_str = dist_cols_str.filter(_ != dist_diff_str)
    var diff_dist_cols_str = dist_cols_str.filter(_ == dist_diff_str)

    if (start_index == "start_index") {
      norm_duration_cols_str = duration_cols_str.filter(!_.startsWith(diff_str))
      diff_duration_cols_str = duration_cols_str.filter(_.startsWith(diff_str))
      norm_dist_cols_str = dist_cols_str.filter(!_.startsWith(diff_str))
      diff_dist_cols_str = dist_cols_str.filter(_.startsWith(diff_str))
    }

    val ex_cols_str = (norm_duration_cols_str ++ diff_duration_cols_str).map(_ + "_ex")

    //行驶时长判断
    val cond1_norm_cols = norm_duration_cols_str.map(x => col(x).cast("double")).map { x => when(x > threshold, 1).otherwise(0) }
    val cond1_diff_cols = diff_duration_cols_str.map(x => col(x).cast("double")).map { x => when(x > diff_threshold, 1).otherwise(0) }
    val cond1 = cond1_norm_cols ++ cond1_diff_cols

    //时长里程同时判断
    val cond2 = (norm_dist_cols_str ++ diff_dist_cols_str).map(x => col(x).cast("double")) zip (norm_duration_cols_str ++ diff_duration_cols_str).map(x => col(x).cast("double")) map { x => when(x._1 > 5000 && x._2 === 0, 1).otherwise(0) }

    //(c1,c2)
    val res_cols = cond1 zip cond2 map { x => when(x._1 === 1 || x._2 === 1, 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }

  /**
   * 分道路设施 时长duration 异常判断
   *
   * @param duration_cols_str
   * @param dist_cols_str
   * @param diff_str
   * @param threshold
   * @param diff_threshold
   * @param flag
   */
  def fssDuraCond(duration_cols_str: Seq[String], dist_cols_str: Seq[String], t_duration: Column, threshold: Long): Seq[Column] = {
    val ex_cols_str = duration_cols_str.map(_ + "_ex")
    //行驶时长判断 时长里程同时判断
    val res_cols = dist_cols_str.map(x => col(x).cast("double")) zip duration_cols_str.map(x => col(x).cast("double")) map { x => when(x._2 > compareMinCol(0)(lit(threshold), t_duration * 1.1).cast("double") || (x._1 > 5000 && x._2 === 0), 1).otherwise(0) }
    ColumnUtil.renameColumn(res_cols, ex_cols_str)
  }
}
