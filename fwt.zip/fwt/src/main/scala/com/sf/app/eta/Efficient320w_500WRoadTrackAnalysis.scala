package com.sf.app.eta


import com.sf.app.eta.EfficientSwidAccleration.{getCityAndIndexMapFun, getDisHighspeedBlock, getNewMergeMap}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.{getDateOrHourUDF, lngLatToDistance, sortFieldwithSpec, splitFun, strNotNull, twoGroupinterLong, twoGroupinterLongWithDetail}
import utils.DateUtil.{getdaysBeforeOrAfter, sdf1, timeToTimestampFormat, tranTstampToTime}
import utils.EtaUtil.{getCsv2DF, getDisHighspeedStand}
import utils.{ColumnUtil, SparkBuilder}

import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.util.control.Breaks.{break, breakable}

/**
 * @task_id: 691977
 * @description: 500w数据近3天数据拼接
 * @demander:舒雷 01412978
 * @author 01418539 caojia
 * @date 2023/4/11 15:14
 */
object Efficient320w_500WRoadTrackAnalysis extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val daily_TN = "dm_gis.eta_track_daily"
    val merge_3d_TN = "dm_gis.eta_track_merge_3daily"
    val direct_merge_3d_TN = "dm_gis.eta_track_merge_3daily_with_328_city"
    val res_TN = "dm_gis.eta_track_highway_detail_3d_with_328_city"
    val city_map_info = getCsv2DF(spark)
    val city_code_328 = city_map_info._1
    val city_map = city_map_info._2
    val city_df = city_map_info._3
    val filter_direct = Seq("")
    //全国328个城市
    processMerge(spark, daily_TN, merge_3d_TN, inc_day) //15-20min
    pro20cityDetail(spark, city_code_328, merge_3d_TN, direct_merge_3d_TN, inc_day) //5min
    choosePartSplitDirection(spark, city_map, city_df, direct_merge_3d_TN, res_TN, filter_direct, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  /**
   * part 1  近3天的数据拼接聚合
   *
   * @param spark
   * @param inc_day
   */
  def processMerge(spark: SparkSession, start_tableN: String, end_tableN: String, inc_day: String): Unit = {
    val bef_day = getdaysBeforeOrAfter(inc_day, -1)
    val aft_day = getdaysBeforeOrAfter(inc_day, 1)
    import spark.implicits._
    val org_cols = spark.sql(s"""select * from $start_tableN limit 0""").schema.map(_.name).filter(_ != "tl_origin_points").map(col)
    val res_cols = spark.sql(s"""select * from $end_tableN limit 0""").schema.map(_.name).map(col)
    val agg_cols_str = Seq("road_points_start", "road_points_end", "road_track_continues_rate", "road_start_swid", "road_end_swid", "road_start_time", "road_end_time", "road_start_adcode", "road_end_adcode", "if_highspeed", "road_dist", "tl_periods", "tl_roadname", "tl_link", "tl_roadclass", "road_name", "tl_points",
      "add_bef_last", "add_day_first", "add_day_last", "add_aft_last")
    val part_agg_cols = aggSequenceSortCols(agg_cols_str)

    //    val day_un = spark.sql(s"""select un from $start_tableN where inc_day ='$inc_day'""").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")
    val day_un = spark.sql(s"""select * from $start_tableN where inc_day ='$inc_day'""").select(org_cols: _*).persist()
    val bef_day_df = spark.sql(s"""select * from $start_tableN where inc_day ='$bef_day'""").join(broadcast(day_un.select("un")), Seq("un"), "right").select(org_cols: _*)
    val aft_day_df = spark.sql(s"""select * from $start_tableN where inc_day ='$aft_day'""").join(broadcast(day_un.select("un")), Seq("un"), "right").select(org_cols: _*)

    val o_500w_daily = bef_day_df.union(day_un).union(aft_day_df)
      .withColumn("tl_road", when('tl_road.isNotNull && trim('tl_road) =!= "", 'tl_road).otherwise("-"))
      .withColumn("tl_roadname", gettlRoadSize('tl_road))
      .na.fill("", Seq("road_start_time", "road_end_time", "tl_periods", "if_highspeed"))
      .withColumn("road_start_time", getTstamp2TimeUdf('road_start_time, lit("Y")))
      .withColumn("road_end_time", getTstamp2TimeUdf('road_end_time, lit("Y")))
      .withColumn("tl_periods", getTstamp2TimeUdf('tl_periods, lit("N")))
      .withColumn("add_bef_last", when('inc_day === bef_day, getAccrossDayUdf('road_end_time, lit("end"))))
      .withColumn("add_day_first", when('inc_day === inc_day, getAccrossDayUdf('road_start_time, lit("start"))))
      .withColumn("add_day_last", when('inc_day === inc_day, getAccrossDayUdf('road_end_time, lit("end"))))
      .withColumn("add_aft_last", when('inc_day === aft_day, getAccrossDayUdf('road_start_time, lit("start"))))
      .withColumn("num", row_number().over(Window.partitionBy("un").orderBy(asc("inc_day"))))
      .groupBy("un")
      .agg(part_agg_cols.head, part_agg_cols.tail: _*)
      .withColumn("day_diff_period", getDayDiffPeriodsUdf('add_bef_last, 'add_day_first, 'add_day_last, 'add_aft_last))
      .persist()
    logger.error(">>筛选当天有行程轨迹的数据总量>>" + o_500w_daily.count())
    day_un.unpersist()
    val road_points_infos_str = splitFun("&")('road_points_infos) //todo add
    val road_swid_infos_str = splitFun("&")('road_swid_infos)
    val road_time_infos_str = splitFun("&")('road_time_infos)
    val road_adcode_infos_str = splitFun("&")('road_adcode_infos)
    val if_highspeed_merge_infos_str = splitFun("&")('if_highspeed_merge_infos)
    val road_dist_merge_infos_str = splitFun("&")('road_dist_merge_infos)

    val res_df = o_500w_daily
      .withColumn("road_points_start", sortFieldwithSpec("&")('num, 'road_points_start)) //todo add
      .withColumn("road_points_end", sortFieldwithSpec("&")('num, 'road_points_end)) //todo add
      .withColumn("road_track_continues_rate", sortFieldwithSpec("&")('num, 'road_track_continues_rate)) //todo add
      .withColumn("road_swid_start", sortFieldwithSpec("&")('num, 'road_start_swid))
      .withColumn("road_swid_end", sortFieldwithSpec("&")('num, 'road_end_swid))
      .withColumn("road_start_time", sortFieldwithSpec("&")('num, 'road_start_time))
      .withColumn("road_end_time", sortFieldwithSpec("&")('num, 'road_end_time))
      .withColumn("road_start_adcode", sortFieldwithSpec("&")('num, 'road_start_adcode))
      .withColumn("road_end_adcode", sortFieldwithSpec("&")('num, 'road_end_adcode))
      .withColumn("if_highspeed", sortFieldwithSpec("&")('num, 'if_highspeed))
      .withColumn("road_dist", sortFieldwithSpec("&")('num, 'road_dist))
      .withColumn("tl_periods", sortFieldwithSpec("&")('num, 'tl_periods))
      .withColumn("tl_roadname", sortFieldwithSpec("&")('num, 'tl_roadname))
      .withColumn("tl_link", sortFieldwithSpec("&")('num, 'tl_link))
      .withColumn("tl_roadclass", sortFieldwithSpec("&")('num, 'tl_roadclass))
      .withColumn("road_name", sortFieldwithSpec("&")('num, 'road_name))
      .withColumn("tl_points", sortFieldwithSpec("&")('num, 'tl_points))
      .withColumn("road_swid_infos", getMergeStartAndEndUdf('road_swid_start, 'road_swid_end))
      .withColumn("road_time_infos", getMergeStartAndEndUdf('road_start_time, 'road_end_time))
      .withColumn("road_adcode_infos", getMergeStartAndEndUdf('road_start_adcode, 'road_end_adcode))
      .withColumn("if_highspeed_merge_infos", getMergeIfHighspeedOrDistUdf('if_highspeed))
      .withColumn("road_dist_merge_infos", getMergeIfHighspeedOrDistUdf('road_dist))
      .withColumn("road_points_infos", getMergeStartAndEndUdf('road_points_start, 'road_points_end)) //todo add
      .withColumn("road_points", road_points_infos_str(0)) //todo add
      .withColumn("road_points_pair", road_points_infos_str(1)) //todo add
      .withColumn("road_swid", road_swid_infos_str(0))
      .withColumn("road_swid_pair", road_swid_infos_str(1))
      .withColumn("road_time", road_time_infos_str(0))
      .withColumn("road_time_pair", road_time_infos_str(1))
      .withColumn("road_adcode", road_adcode_infos_str(0))
      .withColumn("road_adcode_pair", road_adcode_infos_str(1))
      .withColumn("if_highspeed_merge", if_highspeed_merge_infos_str(0))
      .withColumn("if_highspeed_merge_pair", if_highspeed_merge_infos_str(1))
      .withColumn("road_dist_merge", road_dist_merge_infos_str(0))
      .withColumn("road_dist_merge_pair", road_dist_merge_infos_str(1))
      .withColumn("adcode_six", getSixAdcodeCombineIfHighspeedUDF('road_adcode, 'if_highspeed_merge))
      .withColumn("inc_day", lit(inc_day))
      .select(res_cols: _*)

    writeToHive(spark, res_df.coalesce(30), Seq("inc_day"), end_tableN)
  }

  /**
   * part2 500w原始数据中选取10w条 查看符合20个城市流向的信息
   *
   * @param spark
   */
  def pro20cityDetail(spark: SparkSession, city_code: Seq[String], start_tableN: String, end_tableN: String, inc_day: String): Unit = {
    import spark.implicits._
    val res_cols = spark.sql(s"""select * from $end_tableN limit 0""").schema.map(_.name).map(col)
    val adcode_six_infos_str = splitFun("&")('adcode_six_infos)
    val city_20_df = spark.sql(s"""select * from $start_tableN where adcode_six is not null and trim(adcode_six) !='' and inc_day='$inc_day'""")
      .withColumn("adcode_six_infos", get20cityAdcodeUDF(city_code)('adcode_six))
      .withColumn("city_flag", adcode_six_infos_str(0))
      .withColumn("city_infos", adcode_six_infos_str(1))
      .select(res_cols: _*)

    writeToHive(spark, city_20_df, Seq("inc_day"), end_tableN)
  }

  /**
   * part3 拆分流向,并进行逻辑加工
   *
   * @param spark
   */
  def choosePartSplitDirection(spark: SparkSession, city_map: mutable.HashMap[String, String], city_map_df: DataFrame, start_tableN: String, end_tableN: String, filter_direct: Seq[String], inc_day: String): Unit = {
    import spark.implicits._
    val day_diff_this_infos_str = splitFun("&")('day_diff_this_infos)
    val duration_infos_str = splitFun("&")('duration_infos)
    //结果拼接
    val res_cols = spark.sql(s"""select * from $end_tableN limit 0""").schema.map(_.name).map(col)
    val o_eta_df = spark.sql(s"""select * from $start_tableN where city_flag !='' and inc_day='$inc_day' """).repartition(600)
      .withColumn("merge_res", getMultiCombinationWithSelfUDF('adcode_six, 'city_infos))
      .withColumn("merge_arr", explode($"merge_res"))
      .withColumn("adcode_first_gj", $"merge_arr"("_1")("_1"))
      .withColumn("adcode_end_gj", $"merge_arr"("_1")("_2"))
      .withColumn("start_index", $"merge_arr"("_2")("_1"))
      .withColumn("end_index", $"merge_arr"("_2")("_2"))
      .filter($"start_index" % 2 === 0 && $"end_index" % 2 =!= 0)
      .na.fill("", Seq("road_points", "road_swid", "start_index", "end_index"))
      .withColumn("point_start", getSwidUdf('road_points, 'start_index)) //todo add
      .withColumn("point_end", getSwidUdf('road_points, 'end_index)) //todo add
      .na.fill("", Seq("point_start", "point_end"))
      .withColumn("short_dist", getShortDistUDF('point_start, 'point_end)) //todo add
      .withColumn("swid_start", getSwidUdf('road_swid, 'start_index))
      .withColumn("swid_end", getSwidUdf('road_swid, 'end_index))
      .withColumn("highspeed_start_time", getSwidUdf('road_time, 'start_index))
      .withColumn("highspeed_start_day", getDateOrHourUDF("date")('highspeed_start_time))
      .withColumn("highspeed_start_hour", getDateOrHourUDF("hour")('highspeed_start_time))
      .withColumn("highspeed_end_time", getSwidUdf('road_time, 'end_index))
      .withColumn("highspeed_end_day", getDateOrHourUDF("date")('highspeed_end_time))
      .withColumn("highspeed_end_hour", getDateOrHourUDF("hour")('highspeed_end_time))
      .withColumn("time_highspeed_start_rep", substring('highspeed_start_time, 0, 10))
      .withColumn("highspeed_time", concat_ws("_", 'highspeed_start_time, 'highspeed_end_time))
      .na.fill("", Seq("start_index", "end_index", "highspeed_time", "day_diff_period", "road_dist_merge", "tl_periods", "tl_link", "tl_roadname", "tl_roadclass", "tl_points", "road_name"))
      .withColumn("day_diff_this_infos", getDayoffthisUdf('day_diff_period, 'highspeed_time))
      .withColumn("day_diff_this", day_diff_this_infos_str(0))
      .withColumn("day_diff_duration", day_diff_this_infos_str(1))
      .withColumn("highspeed_duration", day_diff_this_infos_str(2))
      .withColumn("highspeed_start_adcode", getSwidUdf('road_adcode, 'start_index))
      .withColumn("highspeed_end_adcode", getSwidUdf('road_adcode, 'end_index))
      .withColumn("highspeed_adcode", getDiffHSadcodeUdf('road_adcode, 'start_index, 'end_index))
      .withColumn("highspeed_dist", getDistUdf('road_dist_merge, 'start_index, 'end_index))
      .withColumn("dis_highspeed_block", getDisHighspeedBlock('highspeed_dist))
      .withColumn("highspeed_ac_dist", getAcDistUdf('road_dist_merge, 'if_highspeed_merge, 'start_index, 'end_index))
      .withColumn("highspeed_dist_ratio", when('highspeed_dist.cast("double") > 0, round('highspeed_ac_dist / 'highspeed_dist, 2)).otherwise(0.0))
      .join(broadcast(city_map_df.selectExpr("adcode as adcode_first_gj", "city_name city_start")), Seq("adcode_first_gj"), "left")
      .join(broadcast(city_map_df.selectExpr("adcode as adcode_end_gj", "city_name city_end")), Seq("adcode_end_gj"), "left")
      .withColumn("direction", concat_ws("-", 'city_start, 'city_end))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error(">>第一阶段数据总量>>>" + o_eta_df.count())

    val part_2_df = o_eta_df
      .withColumn("duration_infos", gettlDuraionUdf('tl_periods, 'tl_link, 'tl_roadname, 'tl_roadclass, 'tl_points, 'highspeed_time))
      .withColumn("tl_duration_1", duration_infos_str(0))
      .withColumn("tl_link_1", duration_infos_str(1))
      .withColumn("tl_roadname_1", duration_infos_str(2))
      .withColumn("tl_roadclass_1", duration_infos_str(3))
      .withColumn("tl_duration_2", duration_infos_str(4))
      .withColumn("tl_link_2", duration_infos_str(5))
      .withColumn("tl_roadname_2", duration_infos_str(6))
      .withColumn("tl_roadclass_2", duration_infos_str(7))
      .withColumn("tl_points_1", duration_infos_str(8))
      .withColumn("tl_points_2", duration_infos_str(9))
      .withColumn("tl_periods_mix", duration_infos_str(10)) //todo add
      .withColumn("tl_periods_1", duration_infos_str(11)) //todo add
      .withColumn("tl_periods_2", duration_infos_str(12)) //todo add
      .withColumn("speed_highspped", when('highspeed_duration.cast("double") > 0, round(lit(60) * 'highspeed_dist / 'highspeed_duration, 2)).otherwise(0.0))
      .withColumn("speed_highspeed_tl_1", round(lit(60) * 'highspeed_dist / ('highspeed_duration - 'tl_duration_1), 2))
      .withColumn("speed_highspeed_tl_2", round(lit(60) * 'highspeed_dist / ('highspeed_duration - 'tl_duration_2), 2))
      .withColumn("speed_highspeed_block", getDisHighspeedStand('speed_highspped))
      .withColumn("speed_highspeed_tl_1_block", getDisHighspeedStand('speed_highspeed_tl_1))
      .withColumn("speed_highspeed_tl_2_block", getDisHighspeedStand('speed_highspeed_tl_2))
      .filter('speed_highspeed_tl_2.cast("double") < 120)
      .na.fill("", Seq("start_index", "end_index", "road_name_sort", "road_name", "if_highspeed", "road_swid_pair", "road_time_pair", "road_adcode_pair", "road_dist_merge_pair"))
      .withColumn("road_name_sort", getRoadnameSort('road_name))
      .withColumn("road_cnt", getRoadCnt('start_index, 'end_index))
      .withColumn("road_rank", getRoadOrOther('start_index, 'end_index, 'road_name_sort))
      .withColumn("road_name_dir", getRoadOrOther('start_index, 'end_index, 'road_name))
      .withColumn("road_if_highspeed_dir", getRoadOrOther('start_index, 'end_index, 'if_highspeed))
      .withColumn("road_track_continues_rate_dir", getRoadOrOther('start_index, 'end_index, 'road_track_continues_rate)) //todo add
      .withColumn("road_swid_dir", getRoadOrOther('start_index, 'end_index, 'road_swid_pair))
      .withColumn("road_points_dir", getRoadOrOther('start_index, 'end_index, 'road_points_pair)) //todo add
      .withColumn("road_time_dir", getRoadOrOther('start_index, 'end_index, 'road_time_pair))
      .withColumn("road_adcode_dir", getRoadOrOther('start_index, 'end_index, 'road_adcode_pair))
      .withColumn("road_dist_dir", getDist('start_index, 'end_index, 'road_dist_merge_pair))
      .withColumn("road_city_dir", getRoadcity(city_map)('road_adcode_dir))
      .na.fill("", Seq("road_time_dir", "road_adcode_dir", "road_dist_dir", "road_track_continues_rate_dir")) //todo add
      .withColumn("road_duration_dir", getRoadDuration('road_time_dir))
      .na.fill("", Seq("road_duration_dir", "road_time_dir"))
      .withColumn("road_speed_dir", getRoadSpeed('road_dist_dir, 'road_duration_dir))
      .withColumn("road_duration_tl", gettlDuraionSingleUdf('tl_periods, 'tl_roadname, 'tl_roadclass, 'road_time_dir, 'road_duration_dir))
      .withColumn("road_speed_tl", getRoadSpeed('road_dist_dir, 'road_duration_tl))
      .withColumn("road_start_hour", getHourUDF("hour")('road_time_dir))
      .withColumn("road_start_time_tag", lit(""))
      .withColumn("wavg_road_track_continues_rate", getWavgRateUDF('road_track_continues_rate_dir, 'road_dist_dir))
      .withColumn("num", row_number().over(Window.partitionBy("un", "highspeed_start_time", "highspeed_end_time").orderBy("inc_day")))
      .filter('num === 1)
      .select(res_cols: _*)

    writeToHive(spark, part_2_df.coalesce(200), Seq("inc_day"), end_tableN)
    //    res_df.unpersist()
  }


  def getWavgRateUDF = udf((road_track_continues_rate_dir: String, road_dist_dir: String) => {
    var sum_w_rate = 0.0
    if (strNotNull(road_track_continues_rate_dir) && strNotNull(road_dist_dir)) {
      try {
        val rate_arr = road_track_continues_rate_dir.split("\\|", -1)
        val dist_arr = road_dist_dir.split("\\|", -1)
        var w_dist = 0.0
        for (i <- 0 until dist_arr.size) {
          w_dist += (try {
            dist_arr(i).toDouble
          } catch {
            case e: Exception => 0.0
          })
        }
        for (j <- 0 until dist_arr.size) {
          val rt = try {
            rate_arr(j).toDouble
          } catch {
            case e: Exception => 0.0
          }
          val dt = try {
            dist_arr(j).toDouble
          } catch {
            case e: Exception => 0.0
          }
          sum_w_rate += rt * (dt / w_dist)
        }
      } catch {
        case e: Exception => ""
      }
    }
    sum_w_rate.formatted("%.2f")
  })

  def getShortDistUDF = udf((point_start: String, point_end: String) => {
    var short_dist = "0.0"
    if (strNotNull(point_start) && strNotNull(point_end)) {
      try {
        val x1 = point_start.split(",")(0)
        val y1 = point_start.split(",")(1)
        val x2 = point_end.split(",")(0)
        val y2 = point_end.split(",")(1)
        short_dist = lngLatToDistance(x1, y1, x2, y2).formatted("%.2f")
      } catch {
        case e: Exception => ""
      }
    }
    short_dist
  })

  def getHourUDF(flag: String) = udf((tm: String) => {
    val tm_res = new ArrayBuffer[String]()

    if (tm != "" && flag == "date") {
      val tm_arr = tm.split("\\|")
      for (i <- 0 until tm_arr.size) {
        tm_res += (try {
          tm_arr(i).split("_")(0).substring(0, 10)
        } catch {
          case e: Exception => "-"
        })
      }
    }
    if (tm != "" && flag == "hour") {
      val tm_arr = tm.split("\\|")
      for (i <- 0 until tm_arr.size) {
        tm_res += (try {
          tm_arr(i).split("_")(0).split("\\s+")(1).split(":")(0)
        } catch {
          case e: Exception => "-"
        })
      }
    }

    tm_res.mkString("|")
  })


  def getRoadcity(city_map: mutable.HashMap[String, String]) = udf((road_adcode: String) => {
    val road_city_arr = new ArrayBuffer[String]()
    val four_sp = Seq("81", "31", "11", "50", "12")
    val six_sp = Seq("429004", "659001", "654003", "632801")
    try {
      if (road_adcode.trim != "") {
        val road_adcode_arr = road_adcode.split("\\|")
        for (i <- 0 until road_adcode_arr.size) {
          val one_adcode_2 = road_adcode_arr(i).split("_")(0).substring(0, 2)
          val one_adcode_4 = road_adcode_arr(i).split("_")(0).substring(0, 4)
          val one_adcode_6 = road_adcode_arr(i).split("_")(0)
          var adcode_n = ""
          if (four_sp.contains(one_adcode_2)) {
            adcode_n += (one_adcode_2 + "" + "0000")
          } else if (six_sp.contains(one_adcode_6)) {
            adcode_n += one_adcode_6
          } else {
            adcode_n += (one_adcode_4 + "" + "00")
          }
          road_city_arr += city_map.getOrElse(adcode_n, "-")
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    road_city_arr.mkString("|")
  })

  def gettlDuraionSingleUdf = udf((tl_periods: String, tl_roadname: String, tl_roadclass: String, road_time: String, road_duration: String) => {
    val dura_ab = new ArrayBuffer[String]()
    try {
      if (road_time.trim != "") {
        val road_time_arr = road_time.split("\\|")
        val road_duration_arr = road_duration.split("\\|")
        for (i <- 0 until road_time_arr.size) {
          if (road_time_arr(i).split("_")(0).trim == "-" || road_time_arr(i).split("_")(1).trim == "-" || road_duration_arr(i).trim == "-") {
            dura_ab += "-"
          } else {
            val hs_st = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", road_time_arr(i).split("_")(0))
            val hs_et = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", road_time_arr(i).split("_")(1))
            var dura_tm = 0.0
            if (tl_periods != "") {
              val periods_arr = tl_periods.split("\\|")
              val roadname_arr = tl_roadname.split("\\|")
              val roadclass_arr = tl_roadclass.split("\\|")
              for (j <- 0 until periods_arr.size) {
                val pe_st = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(j).split("_")(0))
                val pe_et = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(j).split("_")(1))
                if (pe_et - pe_st >= 600) {
                  if (roadname_arr(j).contains("服务区") || roadname_arr(j).contains("停车区") || roadclass_arr(j).toInt != 0) {
                    val cross_tm_2 = twoGroupinterLong(hs_st, hs_et, pe_st, pe_et)
                    dura_tm += cross_tm_2.toDouble
                  }
                }
              }
            }
            dura_ab += (road_duration_arr(i).toDouble - dura_tm / 60.0).formatted("%.2f")
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    dura_ab.mkString("|")
  })


  def getRoadSpeed = udf((road_dist_dir: String, road_duration: String) => {
    val res = new ArrayBuffer[String]()
    if (road_dist_dir.trim != "" && road_duration.trim != "") {
      try {
        val dist_arr = road_dist_dir.split("\\|", -1)
        val dura_arr = road_duration.split("\\|", -1)
        for (i <- 0 until dist_arr.size) {
          val dist = dist_arr(i).split("_")(0).toDouble
          val dura = try {
            dura_arr(i).toDouble / 60
          } catch {
            case e: Exception => 0
          }
          if (dura > 0) res += (dist / dura).formatted("%.2f") else res += "-"
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    res.mkString("|")
  })

  def getRoadDuration = udf((road_time: String) => {
    val res = new ArrayBuffer[String]()
    try {
      if (road_time.trim != "") {
        val road_time_arr = road_time.split("\\|", -1)
        for (i <- 0 until road_time_arr.length) {
          if (road_time_arr(i).trim == "-") {
            res += "0.0"
          } else {
            val start_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", road_time_arr(i).split("_")(0))
            val end_tm = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", road_time_arr(i).split("_")(1))
            res += ((end_tm - start_tm) / 60.0).formatted("%.2f")
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    res.mkString("|")
  })

  def getRoadCnt = udf((start_index: String, end_index: String) => {
    var other_ab = "0"
    if (start_index.trim != "" && end_index.trim != "") {
      val si = start_index.toInt / 2
      val ei = (end_index.toInt + 1) / 2
      other_ab = (ei - si).toString
    }
    other_ab
  })

  def getDist = udf((start_index: String, end_index: String, other: String) => {
    val other_ab = new ArrayBuffer[String]()
    if (start_index.trim != "" && end_index.trim != "" && other.trim != "") {
      try {
        val si = start_index.toInt / 2
        val ei = (end_index.toInt + 1) / 2
        val other_arr = other.split("\\|", -1)
        for (i <- si until ei) {
          other_ab += ((try {
            other_arr(i).split("_")(0).toDouble
          } catch {
            case e: Exception => 0.0
          }) / 1000).formatted("%.2f")
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    other_ab.mkString("|")
  })

  def getRoadOrOther = udf((start_index: String, end_index: String, other: String) => {
    val other_ab = new ArrayBuffer[String]()
    if (start_index.trim != "" && end_index.trim != "" && other.trim != "") {
      try {
        val si = start_index.toInt / 2
        val ei = (end_index.toInt + 1) / 2
        val other_arr = other.split("\\|", -1)
        for (i <- si until ei) {
          other_ab += other_arr(i)
        }
      } catch {
        case e: Exception => "" + e
      }
    }
    other_ab.mkString("|")
  })


  def getRoadnameSort = udf((road_name: String) => {
    val res = new ArrayBuffer[String]()
    try {
      if (road_name.trim != "") {
        val road_name_arr = road_name.split("\\|", -1)
        for (i <- 0 until road_name_arr.length) {
          res += i.toString
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    res.mkString("|")
  })

  def filterDirection(filter_direc: Seq[String]) = udf((direction: String) => {
    var flag = "N"
    if (filter_direc.contains(direction)) flag = "Y"
    flag
  })

  //todo add fun
  def gettlDuraionUdf = udf((tl_periods: String, tl_link: String, tl_roadname: String, tl_roadclass: String, tl_points: String, highspeed_time: String) => {
    var dura_1, dura_2 = 0l
    val link_ab, roadname_ab, roadclass_ab, points_ab, link_ab_2, roadname_ab_2, roadclass_ab_2, points_ab_2, tl_periods_mix_ab, tl_periods_1_ab, tl_periods_2_ab = new ArrayBuffer[String]()
    try {
      val hs_st = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highspeed_time.split("_")(0))
      val hs_et = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", highspeed_time.split("_")(1))
      if (tl_periods != "") {
        val periods_arr = tl_periods.split("\\|")
        val link_arr = tl_link.split("\\|")
        val roadname_arr = tl_roadname.split("\\|")
        val roadclass_arr = tl_roadclass.split("\\|")
        val points_arr = tl_points.split("\\|", -1)
        for (i <- 0 until periods_arr.size) {
          val pe_st = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(i).split("_")(0))
          val pe_et = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_arr(i).split("_")(1))
          val time_inter: (Long, String) = twoGroupinterLongWithDetail(hs_st, hs_et, pe_st, pe_et)
          if (time_inter._1 > 0l) {
            tl_periods_mix_ab += time_inter._2 //todo add
          }
          //停留时间大于10分钟的保留处理
          if (pe_et - pe_st >= 600) {
            val cross_tm = time_inter._1
            dura_1 += cross_tm
            if (cross_tm > 0) {
              link_ab += link_arr(i)
              roadname_ab += roadname_arr(i)
              roadclass_ab += roadclass_arr(i)
              points_ab += points_arr(i).replaceAll(" ", "")
              tl_periods_1_ab += time_inter._2 //todo add
            }
            if (roadname_arr(i).contains("服务区") || roadname_arr(i).contains("停车区") || roadclass_arr(i).toInt != 0) {
              val cross_tm_2 = time_inter._1
              dura_2 += cross_tm_2
              if (cross_tm > 0l) {
                link_ab_2 += link_arr(i)
                roadname_ab_2 += roadname_arr(i)
                roadclass_ab_2 += roadclass_arr(i)
                points_ab_2 += points_arr(i).replaceAll(" ", "")
                tl_periods_2_ab += time_inter._2 //todo add
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    (dura_1 / 60.0).formatted("%.2f") + "&" + link_ab.mkString("|") + "&" + roadname_ab.mkString("|") + "&" + roadclass_ab.mkString("|") + "&" + (dura_2 / 60.0).formatted("%.2f") + "&" + link_ab_2.mkString("|") + "&" + roadname_ab_2.mkString("|") + "&" + roadclass_ab_2.mkString("|") + "&" + points_ab.mkString("|") + "&" + points_ab_2.mkString("|") + "&" + tl_periods_mix_ab.mkString("|") + "&" + tl_periods_1_ab.mkString("|") + "&" + tl_periods_2_ab.mkString("|")
  })

  def getAcDistUdf = udf((road_dist_merge: String, if_highspeed_merge: String, start_index: String, end_index: String) => {
    var dist: Double = 0.0
    try {
      val dist_arr = road_dist_merge.split("\\|")
      val hspeed_arr = if_highspeed_merge.split("\\|")
      for (i <- 0 until dist_arr.size if i >= start_index.toInt && i <= end_index.toInt) {
        if (hspeed_arr(i) == "1") dist += dist_arr(i).toDouble
      }
    } catch {
      case e: Exception => "" + e
    }
    (dist / 2 / 1000.0).formatted("%.2f")
  })


  def getDistUdf = udf((road_dist_merge: String, start_index: String, end_index: String) => {
    var dist: Double = 0.0
    try {
      val dist_arr = road_dist_merge.split("\\|")
      for (i <- 0 until dist_arr.size if i >= start_index.toInt && i <= end_index.toInt) {
        dist += dist_arr(i).toDouble
      }
    } catch {
      case e: Exception => "" + e
    }
    (dist / 2 / 1000.0).formatted("%.2f")
  })

  def getDiffHSadcodeUdf = udf((road_adcode: String, start_index: String, end_index: String) => {
    val diff_adcode = new ArrayBuffer[String]()
    try {
      val adcode_arr = road_adcode.split("\\|")
      for (i <- 0 until adcode_arr.size if i >= start_index.toInt && i <= end_index.toInt) {
        if (!diff_adcode.contains(adcode_arr(i))) diff_adcode += adcode_arr(i)
      }
    } catch {
      case e: Exception => "" + e
    }

    diff_adcode.mkString("|")
  })


  def getDayoffthisUdf = udf((day_diff_period: String, highspeed_time: String) => {
    val hs_ab = new ArrayBuffer[String]()
    var tm_ab = 0.0
    var hs_peroids = 0.0
    try {
      if (highspeed_time != "" && day_diff_period != "") {
        val hs_tm_arr = highspeed_time.split("_")
        val hs_tm_start = hs_tm_arr(0)
        val hs_tm_end = hs_tm_arr(1)
        val hs_start_l = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", hs_tm_start)
        val hs_end_l = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", hs_tm_end)
        val periods_arr = day_diff_period.split("\\|")
        for (i <- 0 until periods_arr.size) {
          val periods_start = periods_arr(i).split("_")(0)
          val periods_end = periods_arr(i).split("_")(1)
          val start_l = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_start)
          val end_l = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", periods_end)
          if (hs_start_l <= start_l && end_l <= hs_end_l) {
            hs_ab += periods_arr(i)
            tm_ab += ((end_l - start_l) / 60.0)
          }
        }
        hs_peroids = (hs_end_l - hs_start_l) / 60.0 - tm_ab
      }
    } catch {
      case e: Exception => "" + e
    }
    hs_ab.mkString("|") + "&" + tm_ab.formatted("%.2f") + "&" + hs_peroids.formatted("%.2f")
  })


  def getSwidUdf = udf((road_swid: String, index: String) => {
    var res = ""
    try {
      if (road_swid != "" && index != "") {
        val road_swid_arr = road_swid.split("\\|")
        res = road_swid_arr(index.toInt)
      }
    } catch {
      case e: Exception => "" + e
    }
    res
  })


  def gettlRoadSize = udf((tl_road: String) => {
    val res = new ArrayBuffer[String]()
    val tl_road_arr = tl_road.split("\\|", -1)

    for (i <- 0 until tl_road_arr.size) {
      if (tl_road_arr(i).trim == "") res += "-"
      if (tl_road_arr(i).trim != "") res += tl_road_arr(i).trim
    }
    res.mkString("|")
  })

  def get20cityAdcodeUDF(city_name: Seq[String]) = udf((adcode_six: String) => {
    var city_flag, city_infos = ""
    val hs = new mutable.HashSet[String]()
    try {
      val adcode_arr = adcode_six.split("\\|")
      for (i <- 0 until adcode_arr.size) {
        if (city_name.contains(adcode_arr(i))) {
          hs.add(adcode_arr(i))
        }
      }
      if (hs.size >= 2) {
        city_flag = hs.size.toString
        city_infos = hs.mkString("|")
      }
    } catch {
      case e: Exception => "" + e
    }
    city_flag + "&" + city_infos
  })

  def getSixAdcodeCombineIfHighspeedUDF = udf((adcode: String, if_highspeed_merge: String) => {
    val adcode_n = new ArrayBuffer[String]()
    val four_sp = Seq("81", "31", "11", "50", "12")
    val six_sp = Seq("429004", "659001", "654003", "632801")
    try {
      val adcode_arr = adcode.split("\\|")
      val if_highspeed_merge_arr = if_highspeed_merge.split("\\|")
      for (i <- 0 until adcode_arr.size) {
        if (adcode_arr(i).size < 6) {
          adcode_n += "999999"
        }
        if (adcode_arr(i).size == 6) {
          val if_hs = if_highspeed_merge_arr(i)
          val one_adcode_2 = adcode_arr(i).substring(0, 2)
          val one_adcode_4 = adcode_arr(i).substring(0, 4)
          if (if_hs == "1") {
            if (four_sp.contains(one_adcode_2)) {
              adcode_n += (one_adcode_2 + "" + "0000")
            } else if (six_sp.contains(adcode_arr(i))) {
              adcode_n += adcode_arr(i)
            } else {
              adcode_n += (one_adcode_4 + "" + "00")
            }
          }
          if (if_hs != "1") {
            adcode_n += "999999"
          }
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    adcode_n.mkString("|")
  })

  def getMergeIfHighspeedOrDistUdf = udf((if_highspeed_or_dist: String) => {
    val start_end_merge = new ArrayBuffer[String]()
    val start_end_merge_pair = new ArrayBuffer[String]()
    try {
      val if_highspeed_arr = if_highspeed_or_dist.split("\\|")
      for (i <- 0 until if_highspeed_arr.length) {
        if (if_highspeed_arr(i).trim == "" || if_highspeed_arr(i).isEmpty) {
          start_end_merge += ("0" + "|" + "0")
          start_end_merge_pair += ("0" + "_" + "0")
        }
        if (if_highspeed_arr(i).trim != "" && !if_highspeed_arr(i).isEmpty) {
          start_end_merge += (if_highspeed_arr(i) + "|" + if_highspeed_arr(i))
          start_end_merge_pair += (if_highspeed_arr(i) + "_" + if_highspeed_arr(i))
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    start_end_merge.mkString("|") + "&" + start_end_merge_pair.mkString("|")
  })

  def getMergeStartAndEndUdf = udf((start: String, end: String) => {
    val start_end_merge = new ArrayBuffer[String]()
    val start_end_merge_pair = new ArrayBuffer[String]()

    try {
      val start_arr = start.split("\\|")
      val end_arr = end.split("\\|")
      for (i <- 0 until start_arr.size) {
        start_end_merge += (start_arr(i) + "|" + end_arr(i))
        start_end_merge_pair += (start_arr(i) + "_" + end_arr(i))
      }
    } catch {
      case e: Exception => "" + e
    }
    start_end_merge.mkString("|") + "&" + start_end_merge_pair.mkString("|")
  })

  def getDayDiffPeriodsUdf = udf((add_bef_last: String, add_day_first: String, add_day_last: String, add_aft_last: String) => {
    add_bef_last + "_" + add_day_first + "|" + add_day_last + "_" + add_aft_last
  })

  def aggSequenceSortCols(part_cols_str: Seq[String]): Seq[Column] = {
    val agg_cols_str = part_cols_str :+ "num"
    val agg_cols_sort_str = agg_cols_str.map(x => {
      if (x.startsWith("add_")) x else x
    })

    val no_seq_cols: Seq[Column] = agg_cols_str.map(x => {
      if (x.startsWith("add_")) max(col(x)) else concat_ws("&", collect_list(col(x)))
    })
    ColumnUtil.renameColumn(no_seq_cols, agg_cols_sort_str)
  }

  def getAccrossDayUdf = udf((road_time: String, flag: String) => {
    var res = ""
    val road_time_arr = road_time.split("\\|")
    if (flag == "start") res = road_time_arr(0)
    if (flag == "end") res = road_time_arr(road_time_arr.length - 1)
    res
  })

  def getTstamp2TimeUdf = udf((tm: String, flag: String) => {
    val res = new ArrayBuffer[String]()
    try {
      val tm_arr = tm.split("\\|")
      if (flag == "Y") {
        for (i <- 0 until tm_arr.size) res += tranTstampToTime(sdf1, tm_arr(i))
      }
      if (flag == "N") {
        for (i <- 0 until tm_arr.size) {
          val start = tm_arr(i).split("_")(0)
          val end = tm_arr(i).split("_")(1)
          res += (tranTstampToTime(sdf1, start) + "_" + tranTstampToTime(sdf1, end))
        }
      }
    } catch {
      case e: Exception => "" + e
    }
    res.mkString("|")
  })

  def getMultiCombinationWithSelfUDF = udf((adcode_six: String, city_infos: String) => {
    val city_name = city_infos.split("\\|").toSeq
    val adcode_six_arr = adcode_six.split("\\|")

    val start_map = getRandomCityMapWithSelf(city_name)._1
    val end_map = getRandomCityMapWithSelf(city_name)._2

    val city_index_res = getCityAndIndexMapFun(adcode_six_arr, start_map, end_map)

    val start_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]] = city_index_res._1
    val end_city_info: collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]] = city_index_res._2

    val start_ab = getNewMergeMap(start_city_info, end_city_info)._1
    val end_ab = getNewMergeMap(start_city_info, end_city_info)._2

    val merge_diff: ArrayBuffer[((String, String), (Int, Int))] = getMergerSetIsDiff(start_ab, end_ab)
    val merge_same: ArrayBuffer[((String, String), (Int, Int))] = getMergerSetIsSameF2(start_ab, end_ab)
    merge_diff ++ merge_same
  })

  def getRandomCityMapWithSelf(city_name: Seq[String]): (collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]], collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]) = {
    val start_map = collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]()
    val end_map = collection.mutable.Map[String, collection.mutable.Map[(String, String), List[(Int, String)]]]()
    for (i <- 0 until city_name.size) {
      val start_info: collection.mutable.Map[(String, String), List[(Int, String)]] = collection.mutable.Map.empty
      val end_info: collection.mutable.Map[(String, String), List[(Int, String)]] = collection.mutable.Map.empty
      for (j <- 0 until city_name.size) {
        if (city_name(i) != city_name(j)) {
          start_info.put((city_name(i), city_name(j)), List.empty)
          start_map.put(city_name(i), start_info)

          end_info.put((city_name(j), city_name(i)), List.empty)
          end_map.put(city_name(i), end_info)
        } else {
          start_info.put((city_name(i), city_name(j)), List.empty)
          start_map.put(city_name(i), start_info)
          end_info.put((city_name(j), city_name(i)), List.empty)
          end_map.put(city_name(i), end_info)
        }
      }
    }
    (start_map, end_map)
  }

  def getMergerSetIsDiff(start_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]], end_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]]): ArrayBuffer[((String, String), (Int, Int))] = {
    val all_city_vs: ArrayBuffer[((String, String), (Int, String))] = (start_ab ++ end_ab).filter(x => x._1._1 != x._1._2).sortBy(x => (x._1, x._2._1))
    val merger_ab = new ArrayBuffer[((String, String), (Int, Int))]()
    var cnt: Int = 0
    for (i <- cnt until all_city_vs.size if i == cnt) {
      val o_map_l: Tuple2[(String, String), (Int, String)] = all_city_vs(i)
      if (i + 2 <= all_city_vs.size - 1) {
        val o_map_p: Tuple2[(String, String), (Int, String)] = all_city_vs(i + 1)
        val o_map_pp: Tuple2[(String, String), (Int, String)] = all_city_vs(i + 2)
        val l_p_cond = o_map_l._1._1 == o_map_p._1._1 && o_map_l._1._2 == o_map_p._1._2
        val l_pp_cond = o_map_p._1._1 == o_map_pp._1._1 && o_map_p._1._2 == o_map_pp._1._2

        if (l_p_cond && !l_pp_cond && o_map_l._2._2 == "start" && o_map_p._2._2 == "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, o_map_p._2._1))
          cnt = i + 2
        } else if (l_p_cond && l_pp_cond && o_map_l._2._2 == "start" && o_map_p._2._2 == "end" && o_map_pp._2._2 != "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, o_map_p._2._1))
          cnt = i + 2
        } else if (l_p_cond && l_pp_cond && o_map_l._2._2 == "start" && o_map_p._2._2 == "end" && o_map_pp._2._2 == "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, o_map_p._2._1))
          breakable {
            for (j <- i + 3 until all_city_vs.size if j <= all_city_vs.size - 1) {
              if (all_city_vs(j)._1._1 != o_map_l._1._1 || all_city_vs(j)._1._2 != o_map_l._1._2) {
                cnt = j
                break
              }
              val o_map_ppp: Tuple2[(String, String), (Int, String)] = all_city_vs(j)
              if (all_city_vs(j)._1._1 == o_map_l._1._1 && all_city_vs(j)._1._2 == o_map_l._1._2 && o_map_ppp._2._2 != "end") {
                cnt = j
                break
              }
            }
          }
        } else {
          cnt = i + 1
        }
      }
      if (i + 1 == all_city_vs.size - 1) {
        val o_map_p: Tuple2[(String, String), (Int, String)] = all_city_vs(i + 1)
        val l_p_cond = o_map_l._1._1 == o_map_p._1._1 && o_map_l._1._2 == o_map_p._1._2
        if (l_p_cond && o_map_p._2._2 == "end") {
          merger_ab += Tuple2(o_map_l._1, (o_map_l._2._1, all_city_vs(i + 1)._2._1))
        }
      }
    }
    merger_ab
  }

  def getMergerSetIsSameF2(start_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]], end_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]]): ArrayBuffer[((String, String), (Int, Int))] = {
    val all_city_vs_same: ArrayBuffer[((String, String), (Int, String))] = (start_ab ++ end_ab).filter(x => x._1._1 == x._1._2).sortBy(x => (x._1, x._2._1))
    val merger_ab_same = new ArrayBuffer[((String, String), (Int, Int))]()
    var cnt: Int = 0
    for (i <- cnt until all_city_vs_same.size if i == cnt) {
      val o_map_l: Tuple2[(String, String), (Int, String)] = all_city_vs_same(i)
      val index_hs = new ArrayBuffer[Int]()
      index_hs += o_map_l._2._1
      breakable {
        for (j <- cnt + 1 until all_city_vs_same.size) {
          if (all_city_vs_same(j)._1._1 == o_map_l._1._1 && all_city_vs_same(j)._1._2 == o_map_l._1._2) {
            if (!index_hs.contains(all_city_vs_same(j)._2._1)) {
              index_hs += all_city_vs_same(j)._2._1
            }
          }
          if (all_city_vs_same(j)._1._1 != o_map_l._1._1 && all_city_vs_same(j)._1._2 != o_map_l._1._2) {
            cnt = j
            break()
          }
        }
      }
      if (index_hs.size == 2) {
        for (k <- 0 until index_hs.size - 1) {
          merger_ab_same += Tuple2(o_map_l._1, (index_hs(k), index_hs(k + 1)))
        }
      }
      if (index_hs.size > 2) {
        for (k <- 0 until index_hs.size - 1 if k % 2 == 0 && k + 3 <= index_hs.size - 1) {
          merger_ab_same += Tuple2(o_map_l._1, (index_hs(k), index_hs(k + 3)))
        }
      }
    }
    merger_ab_same
  }

  def getMergerSetIsSame(start_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]], end_ab: ArrayBuffer[Tuple2[(String, String), (Int, String)]]): ArrayBuffer[((String, String), (Int, Int))] = {
    val all_city_vs_same: ArrayBuffer[((String, String), (Int, String))] = (start_ab ++ end_ab).filter(x => x._1._1 == x._1._2).sortBy(x => (x._1, x._2._1))
    val merger_ab_same = new ArrayBuffer[((String, String), (Int, Int))]()
    var cnt: Int = 0
    for (i <- cnt until all_city_vs_same.size if i == cnt) {
      val o_map_l: Tuple2[(String, String), (Int, String)] = all_city_vs_same(i)
      println("start_city:" + o_map_l._1._1 + ">>end_city:" + o_map_l._1._2 + ">>start_index:" + o_map_l._2._1 + ">>start_or_end:" + o_map_l._2._2)
      val index_hs = new ArrayBuffer[Int]()
      index_hs += o_map_l._2._1
      breakable {
        for (j <- cnt + 1 until all_city_vs_same.size) {
          if (all_city_vs_same(j)._1._1 == o_map_l._1._1 && all_city_vs_same(j)._1._2 == o_map_l._1._2) {
            if (!index_hs.contains(all_city_vs_same(j)._2._1)) {
              index_hs += all_city_vs_same(j)._2._1
            }
          }
          if (all_city_vs_same(j)._1._1 != o_map_l._1._1 && all_city_vs_same(j)._1._2 != o_map_l._1._2) {
            cnt = j
            break()
          }
        }
      }
      for (k <- 0 until index_hs.size - 1) {
        merger_ab_same += Tuple2(o_map_l._1, (index_hs(k), index_hs(k + 1)))
      }
    }
    merger_ab_same
  }

  def getCityMapAdcode20(spark: SparkSession): DataFrame = {
    import spark.implicits._
    val city_map_df = Seq(("上海", "上海市", "310000", "直辖市"),
      ("北京", "北京市", "110000", "直辖市"),
      ("重庆", "重庆市", "500000", "直辖市"),
      ("天津", "天津市", "120000", "直辖市"),
      ("广州", "广州市", "440100", "省会"),
      ("杭州", "杭州市", "330100", "省会"),
      ("南京", "南京市", "320100", "省会"),
      ("豫北", "郑州市", "410100", "省会"),
      ("鄂东", "武汉市", "420100", "省会"),
      ("福州", "福州市", "350100", "省会"),
      ("陕西", "西安市", "610100", "省会"),
      ("湘北", "长沙市", "430100", "省会"),
      ("皖北", "合肥市", "340100", "省会"),
      ("济南", "济南市", "370100", "省会"),
      ("沈阳", "沈阳市", "210100", "省会"),
      ("黑龙江", "哈尔滨市", "230100", "省会"),
      ("冀州", "石家庄市", "130100", "省会"),
      ("四川", "成都市", "510100", "省会"),
      ("吉林", "长春市", "220100", "省会"),
      ("深圳", "深圳市", "440300", "深圳市")).toDF("area_name", "city_name", "adcode", "descrip")
    city_map_df
  }

  def getCityMapAdcode40(spark: SparkSession): DataFrame = {
    import spark.implicits._
    val city_map_df = Seq(("520100", "贵阳市"),
      ("210100", "沈阳市"),
      ("120000", "天津市"),
      ("610100", "西安市"),
      ("610100", "西安市"),
      ("410100", "郑州市"),
      ("610100", "西安市"),
      ("510100", "成都市"),
      ("120000", "天津市"),
      ("440100", "广州市"),
      ("310000", "上海市"),
      ("441900", "东莞市"),
      ("310000", "上海市"),
      ("410100", "郑州市"),
      ("440100", "广州市"),
      ("440300", "深圳市"),
      ("310000", "上海市"),
      ("350500", "泉州市"),
      ("350500", "泉州市"),
      ("110000", "北京市"),
      ("530100", "昆明市"),
      ("230100", "哈尔滨市"),
      ("210100", "沈阳市"),
      ("650100", "乌鲁木齐市"),
      ("620100", "兰州市"),
      ("610100", "西安市"),
      ("510100", "成都市"),
      ("530100", "昆明市"),
      ("150100", "呼和浩特市"),
      ("430100", "长沙市"),
      ("420100", "武汉市"),
      ("450100", "南宁市"),
      ("410100", "郑州市"),
      ("110000", "北京市"),
      ("450100", "南宁市"),
      ("350500", "泉州市"),
      ("360100", "南昌市"),
      ("440300", "深圳市"),
      ("441900", "东莞市"),
      ("330100", "杭州市")).toDF("adcode", "city_name")
      .groupBy("adcode")
      .agg(max("city_name") as "city_name")
    city_map_df
  }

  def getCityMapAdcode121(spark: SparkSession): (mutable.HashMap[String, String], DataFrame) = {
    import spark.implicits._
    val city_map_info = Seq(("清远市", "441800"), ("合肥市", "340100"), ("大庆市", "230600"), ("百色市", "451000"), ("乐山市", "511100"), ("重庆市", "500000"), ("南通市", "320600"), ("中山市", "442000"), ("常州市", "320400"), ("丽水市", "331100"), ("汉中市", "610700"), ("福州市", "350100"), ("晋城市", "140500"), ("怀化市", "431200"), ("德阳市", "510600"), ("济宁市", "370800"), ("郑州市", "410100"), ("和田地区", "653200"), ("西安市", "610100"), ("三亚市", "460200"), ("南京市", "320100"), ("淮安市", "320800"), ("江门市", "440700"), ("苏州市", "320500"), ("青岛市", "370200"), ("台州市", "331000"), ("临沂市", "371300"), ("阜阳市", "341200"), ("淮南市", "340400"), ("金华市", "330700"), ("贵阳市", "520100"), ("兰州市", "620100"), ("榆林市", "610800"), ("佳木斯市", "230800"), ("大理白族自治州", "532900"), ("长春市", "220100"), ("厦门市", "350200"), ("衡阳市", "430400"), ("韶关市", "440200"), ("惠州市", "441300"), ("锡林郭勒盟", "152500"), ("杭州市", "330100"), ("石家庄市", "130100"), ("太原市", "140100"), ("海口市", "460100"), ("大连市", "210200"), ("常德市", "430700"), ("成都市", "510100"), ("东莞市", "441900"), ("南平市", "350700"), ("乌鲁木齐市", "650100"), ("宜春市", "360900"), ("宿州市", "341300"), ("湖州市", "330500"), ("潍坊市", "370700"), ("南宁市", "450100"), ("芜湖市", "340200"), ("济南市", "370100"), ("绥化市", "231200"), ("阿勒泰地区", "654300"), ("漯河市", "411100"), ("天津市", "120000"), ("茂名市", "440900"), ("日照市", "371100"), ("昆明市", "530100"), ("连云港市", "320700"), ("宿迁市", "321300"), ("阿克苏地区", "652900"), ("临汾市", "141000"), ("普洱市", "530800"), ("菏泽市", "371700"), ("深圳市", "440300"), ("武汉市", "420100"), ("凉山彝族自治州", "513400"), ("长沙市", "430100"), ("西宁市", "630100"), ("温州市", "330300"), ("信阳市", "411500"), ("呼和浩特市", "150100"), ("沈阳市", "210100"), ("贵港市", "450800"), ("南昌市", "360100"), ("湛江市", "440800"), ("烟台市", "370600"), ("龙岩市", "350800"), ("包头市", "150200"), ("泉州市", "350500"), ("广州市", "440100"), ("徐州市", "320300"), ("蚌埠市", "340300"), ("嘉兴市", "330400"), ("柳州市", "450200"), ("揭阳市", "445200"), ("临沧市", "530900"), ("佛山市", "440600"), ("廊坊市", "131000"), ("铜仁市", "520600"), ("西双版纳傣族自治州", "532800"), ("漳州市", "350600"), ("衡水市", "131100"), ("沧州市", "130900"), ("银川市", "640100"), ("伊犁哈萨克自治州", "654000"), ("宁波市", "330200"), ("赤峰市", "150400"), ("无锡市", "320200"), ("泰州市", "321200"), ("赣州市", "360700"), ("北京市", "110000"), ("河源市", "441600"), ("唐山市", "130200"), ("南阳市", "411300"), ("黄山市", "341000"), ("邢台市", "130500"), ("周口市", "411600"), ("张家口市", "130700"), ("安阳市", "410500"), ("拉萨市", "540100"), ("上海市", "3100,00"), ("哈尔滨市", "230100"), ("滁州市", "341100"))
    val city_info = new mutable.HashMap[String, String]()
    for (i <- 0 until city_map_info.size) {
      city_info += (city_map_info(i)._2 -> city_map_info(i)._1)
    }
    val df = city_map_info.toDF("city_name", "adcode")
      .groupBy("adcode")
      .agg(max("city_name") as "city_name")
    (city_info, df)
  }


}
