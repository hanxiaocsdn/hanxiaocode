package com.sf.app.veh.subload


import org.apache.log4j.Logger
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.col
import utils.SparkBuilder

object ImportDistDailyFromFile {
  @transient lazy val logger: Logger = Logger.getLogger(ImportDistDailyFromFile.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")

  def main(args: Array[String]): Unit = {
    val biz_date = args(0)


    val cols = Seq("un"
      ,"total_dist"
      ,"total_duration"
      ,"drive_dist"
      ,"night_dirve_dist"
      ,"before_dawn_drive_dist"
      ,"early_morning_drive_dist"
      ,"afternoon_drive_dist"
      ,"dusk_drive_dist"
      ,"high_speed_dist"
      ,"state_road_dist"
      ,"provincial_dist"
      ,"county_dist"
      ,"township_dist"
      ,"dangerous_road_dist"
      ,"high_accident_road_dist"
      ,"school_road_dist"
      ,"sharp_turn_road_dist"
      ,"village_road_dist"
      ,"drive_duration"
      ,"drive_duration_array"
      ,"night_dirve_duration"
      ,"before_dawn_drive_duration"
      ,"early_morning_drive_duration"
      ,"afternoon_drive_duration"
      ,"dusk_drive_duration"
      ,"dangerous_road_duration"
      ,"high_accident_road_duration"
      ,"school_road_duration"
      ,"sharp_turn_road_duration"
      ,"township_road_duration"
      ,"over_speed_duration"
      ,"over_speed_ser_duration"
      ,"lnk_cnt"
      ,"dangerous_road_cnt"
      ,"high_accident_road_cnt"
      ,"school_road_cnt"
      ,"sharp_turn_road_cnt"
      ,"township_road_road_cnt"
      ,"operation_cnt"
      ,"operation_same_city_cnt"
      ,"adcode_map"
      ,"adcode_duration_map"
      ,"adcode_dist_map"
      ,"over_drive_duration"
      ,"night_high_speed_duration"
      ,"night_state_road_duration"
      ,"night_provincial_duration"
      ,"night_county_duration"
      ,"night_township_duration"
      ,"night_high_speed_dist"
      ,"night_state_road_dist"
      ,"night_provincial_dist"
      ,"night_county_dist"
      ,"night_township_dist"
      ,"night_dangerous_road_cnt"
      ,"night_high_accident_road_cnt"
      ,"night_school_road_cnt"
      ,"night_sharp_turn_road_cnt"
      ,"night_township_road_road_cnt"
      ,"night_lnk_cnt"
      ,"before_dawn_high_speed_duration"
      ,"before_dawn_state_road_duration"
      ,"before_dawn_provincial_duration"
      ,"before_dawn_county_duration"
      ,"before_dawn_township_duration"
      ,"before_dawn_high_speed_dist"
      ,"before_dawn_state_road_dist"
      ,"before_dawn_provincial_dist"
      ,"before_dawn_county_dist"
      ,"before_dawn_township_dist"
      ,"before_dawn_dangerous_road_cnt"
      ,"before_dawn_high_accident_road_cnt"
      ,"before_dawn_school_road_cnt"
      ,"before_dawn_sharp_turn_road_cnt"
      ,"before_dawn_township_road_road_cnt"
      ,"before_dawn_lnk_cnt"
      ,"early_morning_high_speed_duration"
      ,"early_morning_state_road_duration"
      ,"early_morning_provincial_duration"
      ,"early_morning_county_duration"
      ,"early_morning_township_duration"
      ,"early_morning_high_speed_dist"
      ,"early_morning_state_road_dist"
      ,"early_morning_provincial_dist"
      ,"early_morning_county_dist"
      ,"early_morning_township_dist"
      ,"early_morning_dangerous_road_cnt"
      ,"early_morning_high_accident_road_cnt"
      ,"early_morning_school_road_cnt"
      ,"early_morning_sharp_turn_road_cnt"
      ,"early_morning_township_road_road_cnt"
      ,"early_morning_lnk_cnt"
      ,"afternoon_high_speed_duration"
      ,"afternoon_state_road_duration"
      ,"afternoon_provincial_duration"
      ,"afternoon_county_duration"
      ,"afternoon_township_duration"
      ,"afternoon_high_speed_dist"
      ,"afternoon_state_road_dist"
      ,"afternoon_provincial_dist"
      ,"afternoon_county_dist"
      ,"afternoon_township_dist"
      ,"afternoon_dangerous_road_cnt"
      ,"afternoon_high_accident_road_cnt"
      ,"afternoon_school_road_cnt"
      ,"afternoon_sharp_turn_road_cnt"
      ,"afternoon_township_road_road_cnt"
      ,"afternoon_lnk_cnt"
      ,"dusk_high_speed_duration"
      ,"dusk_state_road_duration"
      ,"dusk_provincial_duration"
      ,"dusk_county_duration"
      ,"dusk_township_duration"
      ,"dusk_high_speed_dist"
      ,"dusk_state_road_dist"
      ,"dusk_provincial_dist"
      ,"dusk_county_dist"
      ,"dusk_township_dist"
      ,"dusk_dangerous_road_cnt"
      ,"dusk_high_accident_road_cnt"
      ,"dusk_school_road_cnt"
      ,"dusk_sharp_turn_road_cnt"
      ,"dusk_township_road_road_cnt"
      ,"dusk_lnk_cnt"
      ,"total_links_dist"
      ,"total_links_duration"
      ,"operation_same_prov_cnt"
      ,"sc_table"
      ,"lpn"
      ,"high_speed_duration"
      ,"state_road_duration"
      ,"provincial_duration"
      ,"county_duration"
      ,"township_duration"
      ,"high_speed_lowspeed_duration"
      ,"inc_day"
      ,"ak"
      ,"tab")

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val inputPath = "/user/01420395/upload/FT20230019/1611146/" + biz_date + ".csv.gz"
    val vehicle_df = spark.read.option("header", "false")
      .option("delimiter", "\\t")
      .option("inferSchema", true)
      .option("numPartitions", 100)
      .csv(inputPath)
      .toDF((cols): _*)
      .repartition(50)
      .select(cols.map(col): _*)

    vehicle_df.show(10, true)

    vehicle_df.createOrReplaceTempView("insurance_model_duration_dist_daily_quanguozhonghuo_temp")

    val vehicle =  spark.sql(s"""select  un
                                  ,subStr(un,-1) as vehicle_color
                                  , total_dist
                                  , total_duration
                                  , drive_dist
                                  , night_dirve_dist
                                  , before_dawn_drive_dist
                                  , early_morning_drive_dist
                                  , afternoon_drive_dist
                                  , dusk_drive_dist
                                  , high_speed_dist
                                  , state_road_dist
                                  , provincial_dist
                                  , county_dist
                                  , township_dist
                                  , dangerous_road_dist
                                  , high_accident_road_dist
                                  , school_road_dist
                                  , sharp_turn_road_dist
                                  , village_road_dist
                                  , drive_duration
                                  , drive_duration_array
                                  , night_dirve_duration
                                  , before_dawn_drive_duration
                                  , early_morning_drive_duration
                                  , afternoon_drive_duration
                                  , dusk_drive_duration
                                  , dangerous_road_duration
                                  , high_accident_road_duration
                                  , school_road_duration
                                  , sharp_turn_road_duration
                                  , township_road_duration
                                  , over_speed_duration
                                  , over_speed_ser_duration
                                  , lnk_cnt
                                  , dangerous_road_cnt
                                  , high_accident_road_cnt
                                  , school_road_cnt
                                  , sharp_turn_road_cnt
                                  , township_road_road_cnt
                                  , operation_cnt
                                  , operation_same_city_cnt
                                  , adcode_map
                                  , adcode_duration_map
                                  , adcode_dist_map
                                  , over_drive_duration
                                  , night_high_speed_duration
                                  , night_state_road_duration
                                  , night_provincial_duration
                                  , night_county_duration
                                  , night_township_duration
                                  , night_high_speed_dist
                                  , night_state_road_dist
                                  , night_provincial_dist
                                  , night_county_dist
                                  , night_township_dist
                                  , night_dangerous_road_cnt
                                  , night_high_accident_road_cnt
                                  , night_school_road_cnt
                                  , night_sharp_turn_road_cnt
                                  , night_township_road_road_cnt
                                  , night_lnk_cnt
                                  , before_dawn_high_speed_duration
                                  , before_dawn_state_road_duration
                                  , before_dawn_provincial_duration
                                  , before_dawn_county_duration
                                  , before_dawn_township_duration
                                  , before_dawn_high_speed_dist
                                  , before_dawn_state_road_dist
                                  , before_dawn_provincial_dist
                                  , before_dawn_county_dist
                                  , before_dawn_township_dist
                                  , before_dawn_dangerous_road_cnt
                                  , before_dawn_high_accident_road_cnt
                                  , before_dawn_school_road_cnt
                                  , before_dawn_sharp_turn_road_cnt
                                  , before_dawn_township_road_road_cnt
                                  , before_dawn_lnk_cnt
                                  , early_morning_high_speed_duration
                                  , early_morning_state_road_duration
                                  , early_morning_provincial_duration
                                  , early_morning_county_duration
                                  , early_morning_township_duration
                                  , early_morning_high_speed_dist
                                  , early_morning_state_road_dist
                                  , early_morning_provincial_dist
                                  , early_morning_county_dist
                                  , early_morning_township_dist
                                  , early_morning_dangerous_road_cnt
                                  , early_morning_high_accident_road_cnt
                                  , early_morning_school_road_cnt
                                  , early_morning_sharp_turn_road_cnt
                                  , early_morning_township_road_road_cnt
                                  , early_morning_lnk_cnt
                                  , afternoon_high_speed_duration
                                  , afternoon_state_road_duration
                                  , afternoon_provincial_duration
                                  , afternoon_county_duration
                                  , afternoon_township_duration
                                  , afternoon_high_speed_dist
                                  , afternoon_state_road_dist
                                  , afternoon_provincial_dist
                                  , afternoon_county_dist
                                  , afternoon_township_dist
                                  , afternoon_dangerous_road_cnt
                                  , afternoon_high_accident_road_cnt
                                  , afternoon_school_road_cnt
                                  , afternoon_sharp_turn_road_cnt
                                  , afternoon_township_road_road_cnt
                                  , afternoon_lnk_cnt
                                  , dusk_high_speed_duration
                                  , dusk_state_road_duration
                                  , dusk_provincial_duration
                                  , dusk_county_duration
                                  , dusk_township_duration
                                  , dusk_high_speed_dist
                                  , dusk_state_road_dist
                                  , dusk_provincial_dist
                                  , dusk_county_dist
                                  , dusk_township_dist
                                  , dusk_dangerous_road_cnt
                                  , dusk_high_accident_road_cnt
                                  , dusk_school_road_cnt
                                  , dusk_sharp_turn_road_cnt
                                  , dusk_township_road_road_cnt
                                  , dusk_lnk_cnt
                                  , total_links_dist
                                  , total_links_duration
                                  , operation_same_prov_cnt
                                  , sc_table
                                  , lpn
                                  , high_speed_duration
                                  , state_road_duration
                                  , provincial_duration
                                  , county_duration
                                  , township_duration
                                  , high_speed_lowspeed_duration
                                  , inc_day,ak
                                  from  insurance_model_duration_dist_daily_quanguozhonghuo_temp""")
    vehicle.show(10, true)

//    vehicle.write
    writeToHive(spark, vehicle, Seq("inc_day", "ak"), "dm_gis.insurance_model_duration_dist_daily_quanguozhonghuo_1")
  }

  def writeToHive(spark: SparkSession, dataframe: DataFrame, partitionCol: Seq[String], resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val parCols = partitionCol.mkString(",")
    val sql = String.format(s"insert overwrite table %s partition($parCols) select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }


}
