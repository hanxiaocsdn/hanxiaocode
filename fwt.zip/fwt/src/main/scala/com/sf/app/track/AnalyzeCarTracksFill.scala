package com.sf.app.track

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import utils.SparkBuilder

import java.io.File
import java.net.URLEncoder

/**
 * @task_id: 临时 692119 （一次性任务）
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2023/4/3 17:36
 */
object AnalyzeCarTracksFill extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val checkDate = args(0)
    makesegPathFill(spark, checkDate)
    postToWuhanFill(spark, checkDate)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def makesegPathFill(spark: SparkSession, dayid: String): Unit = {
    val hdfsPath = "/hive/warehouse/dm/dm_gis/tt_vehicle_task_pass_zone_monitor_carpath_tmp"
    Util.hdfsRM(hdfsPath)
    val sql_seg = s"select task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,zx,zy,ac,tp,sp,be from dm_gis.tt_vehicle_task_pass_zone_monitor_carpath_merge t where t.inc_day='$dayid' GROUP by task_id,zone_from,zone_to,coor_from,coor_to,tm_from,tm_to,un,ak,zx,zy,ac,tp,sp,be"
    spark.sql(sql_seg).rdd.map(_.mkString(",")).saveAsTextFile(hdfsPath)
    val file = s"./track_path_tcseg_$dayid.csv"
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"hdfs dfs -getmerge $hdfsPath $file")
    Util.runShellCmd(s"ls -l $file")
    Util.runShellCmd(s"tar czf $file.tgz $file")
    Util.runShellCmd(s"ls -l $file.tgz")
    Util.ftpUpload(new File(file + ".tgz").getAbsolutePath, ftpPath = "/GIS-ASS-AOS/01366807/wuhan_track_path")
    Util.runShellCmd(s"./rm -rf $file")
    Util.runShellCmd(s"./rm -rf $file.tgz")
  }

  def postToWuhanFill(spark: SparkSession, dayid: String, doPost: Boolean = true): Unit = {
    //增加推送轨迹到武汉功能
    val hdfsPath = "/hive/warehouse/dm/dm_gis/tt_vehicle_task_pass_zone_monitor_carpath_tmp"
    Util.hdfsRM(hdfsPath)
    var sql_org = s"select '' as task_id,'' as zone_from,'' as zone_to,'' as coor_from,'' as coor_to,'' as tm_from,'' as tm_to,un,ak,split(concat_ws(',', collect_set(tm)),',')[0] as tm,zx,zy,ac,tp,sp,be from dm_gis.esg_gis_loc_trajectory t where t.inc_day='$dayid' and ak<>300 and zx>0 and zy>0 and length(un)<=16 and un regexp '[京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领A-Z]{1}[A-Z]{1}[A-Z0-9]{4}[A-Z0-9挂学警港澳]{1,2}' GROUP by un,ak,zx,zy,ac,tp,sp,be"

    if (doPost) {
      spark.sql(sql_org).rdd.map(_.mkString(",")).saveAsTextFile(hdfsPath)
      val file = s"./track_path_$dayid.csv"
      Util.runShellCmd(s"hdfs dfs -getmerge $hdfsPath $file")
      Util.runShellCmd(s"ls -l $file")
      Util.runShellCmd(s"tar czf track_path_$dayid.csv.tgz track_path_$dayid.csv")
      Util.runShellCmd(s"ls -l $file.tgz")
      Util.ftpUpload(new File(file + ".tgz").getAbsolutePath, ftpPath = "/GIS-ASS-AOS/01366807/wuhan_track_path")
      Util.runShellCmd(s"./rm -r -f $file*")
      Util.hdfsRM(hdfsPath)
      //Util.ftpDeleteFile(ftpPath = s"/GIS-ASS-AOS/01366807/wuhan_track_path/track_path_$dayid.csv.tgz")

      //增加输出 ak=200 的全部轨迹
      val sql = s"select distinct * from dm_gis.esg_gis_loc_trajectory t where t.inc_day='$dayid' and ak = 200 "
      Util.sql2ftp(spark, sql, "", s"./track_path_ak200_$dayid.csv", "/GIS-ASS-AOS/01366807/wuhan_track_path", ",")
    }
  }

}
