package com.sf.app.eta

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.DataSourceCommon
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{DataTypes, StructField}
import org.apache.spark.sql.{DataFrame, Row, RowFactory, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{sdf1, tranTstampToTime}
import utils.SparkBuilder

import java.text.{DecimalFormat, SimpleDateFormat}
import java.util._
import scala.collection.mutable.ArrayBuffer

/**
 * @task_id: 712694
 * @description: 轨迹缺失重算日志解析 dm_gis.gis_vms_gta_track_miss
 * @demander: 01430321 廖静文
 * @author 01418539 caojia
 * @date 2023/4/17 14:06
 */
object EfficientTrackMissingRecount extends DataSourceCommon {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val df = new DecimalFormat("0.0000")
  var repartition = 100
  var spark: SparkSession = null

  implicit val b1: String => JSONObject = str => {
    val result = JSON.parseObject(str)
    try {
      result.fluentPutAll(result.getJSONObject("trackRecalculateArg"))
      result.keySet().toArray.foreach(key => {
        if (result.get(key.toString).isInstanceOf[JSONObject]) {
          val temp = result.getJSONObject(key.toString)
          temp.keySet().toArray.foreach(k => {
            result.put(k.toString.toLowerCase, temp.getString(k.toString))
          })
        }
      })
      "resultstatus,status"
        .split(";").foreach(x => result.put(x.split(",")(0), result.getString(x.split(",")(1))))
    } catch {
      case e: Exception => "json中无该分支字段》》》" + e
    }
    result
  }
  implicit val b2: String => RDD[String] = str => spark.sql(str).na.fill("").rdd.repartition(6400).map(row => row.getString(0)).filter(_ != null).persist()

  def get1[T](value: T)(implicit fun: T => RDD[T]): RDD[T] = value

  def get2[T <% JSONObject](value: T): JSONObject = value

  def main(args: Array[String]): Unit = {
    spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    ParseLog(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  /**
   * 解析日志
   *
   * @param spark
   * @param date
   * @return
   */
  def ParseLog(spark: SparkSession, date: String): Unit = {
    var getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String], String) => RDD[JSONObject] = null
    var getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject] = null
    var computeRddF: (RDD[JSONObject]) => RDD[JSONObject] = null
    var table = ""
    var structs: Array[String] = null
    var keys: Array[String] = null
    var saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit = null
    var dateList: ArrayBuffer[String] = null

    getHiveRddF = fiterMutiDayValidLog
    saveHiveRddF = mutiDayRddToHive
    dateList = getMutiDayDateList(date)

    getRddF = getGtaLogRdd
    computeRddF = null
    table = "gis_vms_gta_track_miss"

    structs = Array("type", "task_id", "vehicle_serial", "line_code", "startdept", "enddept", "continuetm", "starttime1", "starttime", "endtime1", "endtime", "recalculatestarttime1", "recalculatestarttime", "recalculateendtime1", "recalculateendtime", "recalculatecontinuetm", "time_slot", "crossflag")
    keys = Array("")

    logger.error("开始处理" + date)
    logger.error(">>>处理" + dateList.mkString(",") + "号的所有日志")
    parseSaveLog(spark, getRddF, getHiveRddF, computeRddF, table, structs, keys, saveHiveRddF, dateList, date)
  }

  def parseSaveLog(spark: SparkSession, getRddF: (SparkSession, (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], ArrayBuffer[String], String) => RDD[JSONObject], getHiveRddF: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], computeRddF: (RDD[JSONObject]) => RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], saveHiveRddF: (SparkSession, RDD[JSONObject], String, Array[String], Array[String], ArrayBuffer[String]) => Unit, dateList: ArrayBuffer[String], date: String): Unit = {
    val etaComputeRdd = getRddF(spark, getHiveRddF, dateList, date)
    if (computeRddF != null) {
      val resultRdd = computeRddF(etaComputeRdd)
      etaComputeRdd.unpersist()
      saveHiveRddF(spark, resultRdd, table, structs, keys, dateList)
      resultRdd.unpersist()
    }
    else {
      saveHiveRddF(spark, etaComputeRdd, table, structs, keys, dateList)
      etaComputeRdd.unpersist()
    }
  }

  /**
   * 获取轨迹缺失重算日志
   *
   * @param spark
   * @param getHiveRdd
   * @param dateList
   * @return
   */
  def getGtaLogRdd(spark: SparkSession, getHiveRdd: (SparkSession, ArrayBuffer[String], String) => RDD[JSONObject], dateList: ArrayBuffer[String], date: String): RDD[JSONObject] = {
    val logType = "trackRecalculate"
    logger.error(">>>获取" + dateList.mkString(",") + "号的" + logType + "日志")
    val validRdd = getHiveRdd(spark, dateList, logType)
    val computeRdd = validRdd.flatMap(json => {
      val list = new ArrayBuffer[JSONObject]()
      if (json != null) {
        val trr = json.getJSONObject("trackRecalculateResult")
        if (trr != null) {
          json.put("crossflag", trr.getString("crossFlag"))
          val list_arr = trr.getJSONArray("list")
          if (list_arr != null && list_arr.size() > 0) {
            for (i <- 0 until list_arr.size()) {
              val new_json = new JSONObject()
              json.keySet().toArray.map(key => {
                new_json.put(key.toString, json.getString(key.toString))
              })
              val starttime_tmp = list_arr.getJSONObject(i).getString("startTime")
              val endtime_tmp = list_arr.getJSONObject(i).getString("endTime")
              val recalculatecontinuetm_tmp = list_arr.getJSONObject(i).getString("recalculateContinueTm")
              val recalculatestarttime_tmp = list_arr.getJSONObject(i).getString("recalculateStartTime")
              val recalculateendtime_tmp = list_arr.getJSONObject(i).getString("recalculateEndTime")

              new_json.put("continuetm", list_arr.getJSONObject(i).getString("continueTm"))
              new_json.put("starttime1", starttime_tmp)
              new_json.put("starttime", tranTstampToTime(sdf1, starttime_tmp))
              new_json.put("endtime1", endtime_tmp)
              new_json.put("endtime", tranTstampToTime(sdf1, endtime_tmp))
              new_json.put("recalculatestarttime1", recalculatestarttime_tmp)
              new_json.put("recalculatestarttime", tranTstampToTime(sdf1, recalculatestarttime_tmp))
              new_json.put("recalculateendtime1", recalculateendtime_tmp)
              new_json.put("recalculateendtime", tranTstampToTime(sdf1, recalculateendtime_tmp))
              new_json.put("recalculatecontinuetm", recalculatecontinuetm_tmp)
              new_json.put("timeslot", getTimeSlot(recalculatecontinuetm_tmp))
              new_json.put("inc_day", date)
              list += new_json
            }
          }
        }
      }
      list
    }).map(json => {
      var taskid, linecode, starttime, endtime, sendtime = ""
      if (json != null) {
        taskid = json.getString("taskId")
        linecode = json.getString("linecode")
        starttime = json.getString("starttime")
        endtime = json.getString("endtime")
//        sendtime = json.getString("sendTime")
      }
      ((taskid, linecode, starttime, endtime), json)
    }).groupByKey()
      .map(obj => {
        val json = obj._2.head
//        val json = obj._2.toList.sortBy(_._1).map(_._2).reverse.head
        json
      })
      .repartition(10).persist()
    logger.error("处理后数据总量为>>>>" + computeRdd.count())
    validRdd.unpersist()
    computeRdd
  }


  def getTimeSlot(recalculatestarttime_tmp: String): String = {
    val tm = recalculatestarttime_tmp.toDouble
    val time_slot = tm match {
      case x if x >= 0 && x < 600 => "[0-600)"
      case x if x >= 600 && x < 1800 => "[600-1800)"
      case x if x >= 1800 && x < 3600 => "[1800-3600)"
      case x if x >= 3600 && x < 7200 => "[3600-7200)"
      case x if x >= 7200 => "2小时以上"
    }
    time_slot
  }

  /**
   * 获取日期列表
   *
   * @param endDate
   * @return
   */
  def getMutiDayDateList(endDate: String): ArrayBuffer[String] = {
    val dateList = new ArrayBuffer[String]()
    dateList += endDate
  }

  /**
   * 过滤有效日志
   *
   * @param spark
   * @param dateList
   * @param subType
   * @return
   */
  def fiterMutiDayValidLog(spark: SparkSession, dateList: ArrayBuffer[String], subType: String): (RDD[JSONObject]) = {
    val startDate = dateList(0)
    val endDate = dateList(dateList.size - 1)
    val sql =
      s"""
         |select info,inc_day from dm_gis.gis_vms_gta_log t
         | where inc_day between '$startDate' and '$endDate'
         | and get_json_object(info, '$$.type') = 'trackRecalculate'
       """.stripMargin
    logger.error("取数的sql语句>>>>>" + sql)
    val logRdd1 = get1(sql)
    logger.error("获取满足条件的原始数据总量>>>>" + logRdd1.count())
    logRdd1.map(x => get2(x)).persist(StorageLevel.MEMORY_AND_DISK_SER)
  }

  def mutiDayRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], dateList: ArrayBuffer[String]): Unit = {
    for (date <- dateList) {
      val resultRdd2 = filterRdd(resultRdd, date)
      filterRddToHive(spark, resultRdd2, table, structs, keys, date)
    }
    resultRdd.unpersist()
  }

  def filterRdd(resultRdd: RDD[JSONObject], date: String): RDD[JSONObject] = {
    val dateRdd = resultRdd.filter(json => {
      val inc_day = json.getString("inc_day")
      inc_day != null && inc_day.equals(date)
    }).persist()

    dateRdd
  }

  def filterRddToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], date: String): Unit = {
    saveJSONObjectRDDToHive(spark, resultRdd, table, structs, keys, date)
  }

  def saveJSONObjectRDDToHive(spark: SparkSession, resultRdd: RDD[JSONObject], table: String, structs: Array[String], keys: Array[String], incDay: String, dataBase: String = "dm_gis"): Unit = {
    val database = "dm_gis"
    try {
      logger.error(">>>table=" + database + "." + table)
      spark.sql(s"use $database")
      //1 构造DataFrame的元数据 StructField
      val structFileds = new ArrayList[StructField]()
      for (struct <- structs) structFileds.add(DataTypes.createStructField(struct, DataTypes.StringType, true))
      //2 构建StructType用于DataFrame的元数据描述
      val structType = DataTypes.createStructType(structFileds)
      //3 构建Row格式数据集RDD[Row]
      val rowRdd = resultRdd.filter(_ != null).map(obj => {
        var row: Row = null
        try {
          val v = new Array[String](structs.length)
          for (i <- structs.indices) v(i) = getJsonVal(obj, structs(i).replaceAll("_", ""), "")
          row = RowFactory.create(v: _*)
        } catch {
          case e: Exception => logger.error(">>>构造row异常:" + e + "," + obj)
        }
        row
      }).filter(_ != null)
      // 4 构建DataFrame
      val df: DataFrame = spark.createDataFrame(rowRdd, structType)
      //5 基于Datarame创建临时表
      val tempView = String.format("%s_temp_view", table)
      df.createOrReplaceTempView(tempView)
      //6 分区、表等操作
      val deleteSql = String.format("alter table %s drop if exists partition(inc_day='%s')", table, incDay)
      logger.error(">>>删除分区：" + deleteSql)
      spark.sql(deleteSql)
      val createPartitionSql = String.format("alter table %s add if not exists partition(inc_day = '%s')", table, incDay)
      logger.error(">>>新建分区：" + createPartitionSql)
      spark.sql(createPartitionSql)
      //7 把临时表的数据刷进hive表中
      spark.sql(String.format("insert into %s partition(inc_day = '%s') select * from %s", table, incDay, tempView))
      logger.error(">>>数据入hive库结束!")
    }
    catch {
      case e: Exception => logger.error(">>>" + database + "." + table + "数据入库异常：" + e)
    }
  }

  /**
   * 获取多层json的值
   *
   * @param obj
   * @param keys
   * @return
   */
  def getJsonVal(obj: JSONObject, keys: String, defaultValue: String): String = {
    var `val`: String = null
    var tempObj = obj
    try {
      var keyArr: Array[String] = keys.split("\\.")
      for (i <- 0 to keyArr.length - 1) {
        if (i < (keyArr.length - 1)) {
          tempObj = tempObj.getJSONObject(keyArr(i))
        }
        else
          `val` = tempObj.getString(keyArr(i))
      }
    } catch {
      case e: Exception =>
    }
    if (`val` == null) `val` = defaultValue
    `val`
  }

  /**
   * 时间戳转换为时分秒
   *
   * @param timestamp
   * @return
   */
  def longToTime(timestamp: Long, format: String = "yyyy-MM-dd HH:mm:ss SSS"): String = {
    var datetime = ""
    try {
      val sdf = new SimpleDateFormat(format)
      datetime = sdf.format(new Date(timestamp))
    } catch {
      case e: Exception => logger.error(">>>时间戳解析异常")
    }
    datetime
  }

  def getUrlPost(json: JSONObject, url: String): String = {
    var resultUrl = url
    if (json != null) resultUrl = url + ":" + json.toJSONString
    resultUrl
  }

}
