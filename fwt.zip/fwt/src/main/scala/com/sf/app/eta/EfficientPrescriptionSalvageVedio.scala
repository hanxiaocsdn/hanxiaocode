package com.sf.app.eta

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import constant.HttpConstant.HTTP_EFFI_VEDIO_P
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import utils.DateUtil.{sdf1, timeToTimestampFormat, tranTstampToTime}
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @task_id: (已下线20230629)686511
 * @description:时效低速和停留监控视频需求 筛选完流向：333条。
 * @demander: 01430321 廖静文
 * @author 01418539 caojia
 * @date 2023/3/28 10:42
 */
case class EfficientVedio(imei: String, line_code: String, task_subid: String, vehicle_serial: String, disu_rank: String, video_type: String, begin_time1: String, end_time1: String, begin_time2: String, end_time2: String, ac_is_run_ontime: String, disu_label_3: String, disu_label_sub_oj: String, label: String, label2: String, label3: String, code1: String, work_order_id1: String, errmsg1: String, code2: String, work_order_id2: String, errmsg2: String, inc_day: String)

object EfficientPrescriptionSalvageVedio extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inc_day = args(0)
    val mid_df = processVedio(spark, inc_day)
    processGetInter(spark, mid_df)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processGetInter(spark: SparkSession, mid_df: DataFrame): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from dm_gis.eta_disu_tl_vedio_dtl limit 0""").schema.map(_.name).map(col)
    val res_df = mid_df
      .map(row => {
        val imei = row.getAs[String]("imei")
        val line_code = row.getAs[String]("line_code")
        val task_subid = row.getAs[String]("task_subid")
        val vehicle_serial = row.getAs[String]("vehicle_serial")
        val disu_rank = row.getAs[String]("disu_rank")
        val video_type = row.getAs[String]("video_type")
        val begin_time1 = row.getAs[String]("begin_time1")
        val end_time1 = row.getAs[String]("end_time1")
        val begin_time2 = row.getAs[String]("begin_time2")
        val end_time2 = row.getAs[String]("end_time2")
        val ac_is_run_ontime = row.getAs[String]("ac_is_run_ontime")
        val disu_label_3 = row.getAs[String]("disu_label_3")
        val disu_label_sub_oj = row.getAs[String]("disu_label_sub_oj")
        val label = row.getAs[String]("label")
        val label2 = row.getAs[String]("label2")
        val label3 = row.getAs[String]("label3")
        val inc_day = row.getAs[String]("inc_day")
        Thread.sleep(700)
        val inter_back1 = getInterBack(imei, begin_time1, end_time1)
        Thread.sleep(700)
        val inter_back2 = getInterBack(imei, begin_time2, end_time2)
        val code1 = inter_back1._1
        val work_order_id1 = inter_back1._2
        val errmsg1 = inter_back1._3
        val code2 = inter_back2._1
        val work_order_id2 = inter_back2._2
        val errmsg2 = inter_back2._3
        EfficientVedio(imei, line_code, task_subid, vehicle_serial, disu_rank, video_type, begin_time1, end_time1, begin_time2, end_time2, ac_is_run_ontime, disu_label_3, disu_label_sub_oj, label, label2, label3, code1, work_order_id1, errmsg1, code2, work_order_id2, errmsg2, inc_day)
      }).toDF().select(res_cols: _*).persist()
    writeToHive(spark, res_df.coalesce(10), Seq("inc_day"), "dm_gis.eta_disu_tl_vedio_dtl")
    mid_df.unpersist()
    res_df.unpersist()
  }

  def processVedio(spark: SparkSession, inc_day: String): DataFrame = {
    import spark.implicits._
    val monitor_sql =
      s"""select line_code,task_subid, vehicle_serial,ac_is_run_ontime,inc_day
         |--,regexp_replace(line_code,'^[a-z]|[A-Z]+','-') line_code_p,
         |--split(regexp_replace(line_code,'^[a-z]|[A-Z]+','-'),'-')[0] src_code,
         |--split(regexp_replace(line_code,'^[a-z]|[A-Z]+','-'),'-')[1] dept_code
         | from dm_gis.eta_time_monitor
         |where inc_day ='$inc_day' and ac_is_run_ontime ='0.0'
         |--and split(regexp_replace(line_code,'^[a-z]|[A-Z]+','-'),'-')[0] in ('371','371','371','371','371','395','595','592','595','595','591','595','7311','7311')
         |--and split(regexp_replace(line_code,'^[a-z]|[A-Z]+','-'),'-')[1] in ('769','020','755','757','758','769','757','757','755','769','755','020','579','571')
         |""".stripMargin

    logger.error("传入的取数sql>>" + monitor_sql)
    val o_monitor = spark.sql(monitor_sql) //.filter(codeFilterUDF('src_code, 'dept_code) === "Y")
      .select("line_code", "task_subid", "vehicle_serial", "ac_is_run_ontime")
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取的任务总数量为》》》" + o_monitor.count())

    val task_subid_cols = o_monitor.select("task_subid").distinct().map("'" + _ + "'").collect().mkString(",").replaceAll("\\[|\\]", "").replaceAll(",''", ",'")

    val pub_cols = Seq("task_subid", "disu_rank", "vehicle_serial", "line_code", "begin_time1", "end_time1", "begin_time2", "end_time2", "video_type", "ac_is_run_ontime", "disu_label_3", "disu_label_sub_oj", "label", "label2", "label3").map(col)
    //单天18w左右
    val o_disu_his = spark.sql(
      s"""select task_subid,disu_periods,split(disu_periods,'_')[0] begin_time1,split(disu_periods,'_')[1] end_time2,disu_rank,
         |disu_label_3,disu_label_sub_oj,'' label,'' label2,'' label3,inc_day from dm_gis.eta_time_monitor_split_disu_his
         |where inc_day ='$inc_day' and task_subid in ($task_subid_cols)
         |and disu_label_3 in ('其他','收费站','无标记','终点','起点')""".stripMargin)
      .withColumn("end_time1", subtractTime('begin_time1, lit("+")))
      .withColumn("begin_time2", subtractTime('end_time2, lit("-")))

    //
    val o_staypoint = spark.sql(
      s"""select task_subid,tl_time_period,split(tl_time_period,'_')[0] begin_time1,split(tl_time_period,'_')[1] end_time2,
         |'' disu_label_3,'' disu_label_sub_oj,label,label2,label3,inc_day from dm_gis.eta_time_monitor_split_staypoint
         |where inc_day ='$inc_day' and task_subid in ($task_subid_cols)
         |and label in ('高速停留','其他事件停留','收费站停留','无标记停留','终点停留')""".stripMargin)
      .withColumn("end_time1", subtractTime('begin_time1, lit("+")))
      .withColumn("begin_time2", subtractTime('end_time2, lit("-")))
      .withColumn("disu_rank", lit(""))

    //单天7w~
    val o_device_hh = spark.sql(s"""select carplate vehicle_serial,imei from dm_arss.dm_device_hh_dtl_di where inc_day ='$inc_day'""".stripMargin)

    val o_step1 = o_disu_his.join(broadcast(o_monitor), Seq("task_subid")).withColumn("video_type", lit("disu")).select(pub_cols: _*)
    val o_step2 = o_staypoint.join(broadcast(o_monitor), Seq("task_subid")).withColumn("video_type", lit("staypoint")).select(pub_cols: _*)

    val mid_df = o_step1.union(o_step2).join(broadcast(o_device_hh), Seq("vehicle_serial"))
      //      .withColumn("req_id1", primaryKeyEncrypt('task_subid, 'begin_time1, 'end_time1, 'imei, 'disu_rank, 'video_type, lit("")))
      //      .withColumn("req_id2", primaryKeyEncrypt('task_subid, 'begin_time2, 'end_time2, 'imei, 'disu_rank, 'video_type, lit("")))
      .withColumn("inc_day", lit(inc_day)) //.limit(200)
      .repartition(1) //线下：接口每min 100（并发--2）  线上：暂时无限制，不能集中访问（并发--10）
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    mid_df.show()
    logger.error(">>>拼接后数据总量为：>>>" + mid_df.count())
    o_monitor.unpersist()
    mid_df
  }


  def getInterBack(imei: String, begin_time: String, end_time: String): (String, String, String) = {
    val params =
      s"""{"imei": "$imei","cameraId": "0","extrStartTime":"$begin_time","extrEndTime":"$end_time"}""".stripMargin
    var res_back, code, work_order_id: String = ""
    var errmsg = "0"

    try {
      res_back = HttpInvokeUtil.sendPost(HTTP_EFFI_VEDIO_P, params, 2, 1)
      val hw_str_json = JSON.parseObject(res_back)
      logger.error("》接口正常调用中》入参》》》》》》》" + params)
      logger.error("》接口正常调用中》出参》》》》》》》" + res_back)
      code = hw_str_json.getString("code")
      work_order_id = hw_str_json.getString("data")
      errmsg = hw_str_json.getString("success") match {
        case "true" => "1"
        case _ => "0"
      }
    } catch {
      case e: Exception => "" + e
    }
    (code, work_order_id, errmsg)
  }

  def subtractTime = udf((start_time: String, symbol: String) => {
    var tm = ""
    val timestamp: Long = timeToTimestampFormat("yyyy-MM-dd HH:mm:ss", start_time)

    if (symbol == "+") {
      tm = tranTstampToTime(sdf1, (timestamp + 20).toString)
    }
    if (symbol == "-") {
      tm = tranTstampToTime(sdf1, (timestamp - 20).toString)
    }
    tm
  })


  def codeFilterUDF = udf((src_code: String, dept_code: String) => {
    val dept_code_arr1 = Seq("769", "020", "755", "757", "758")
    val dept_code_arr2 = Seq("757", "755", "769", "020")
    val dept_code_arr3 = Seq("579", "571")

    val code_filter_flag = src_code match {
      case "371" if dept_code_arr1.contains(dept_code) => "Y"
      case "395" if dept_code_arr1 == "769" => "Y"
      case "595" if dept_code_arr2.contains(dept_code) => "Y"
      case "592" if dept_code_arr1 == "757" => "Y"
      case "591" if dept_code_arr1 == "755" => "Y"
      case "7311" if dept_code_arr3.contains(dept_code) => "Y"
      case _ => ""
    }
    code_filter_flag
  })

}
