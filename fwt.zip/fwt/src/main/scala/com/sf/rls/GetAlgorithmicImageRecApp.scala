package com.sf.rls

import com.alibaba.fastjson.JSON
import com.sf.common.DataSourceCommon
import constant.HttpConstant
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import utils.DateUtil.timeToTimestamp2
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @description:调度事故接口 439827(已冻结20230906，由于下游事故接口已停止运维) [[imei,start_ts,end_ts,rule,alarm_ts]
 * @author 01418539 caojia
 * @date 2022/5/11 18:18
 *       任务id：439827
 */
object GetAlgorithmicImageRecApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day: String = args(0)
    logger.error(s"取数日期：$inc_day")
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")

    val ruleDF: DataFrame = spark.sql(
      s"""select
         |*
         |from
         |dm_gis.grd_new_stay_info_alarm_rule
         |where inc_day ='$inc_day'
         |      and vehicle_serial is not null and trim(vehicle_serial) != ''
         |      and starttime is not null and trim(starttime) != ''
         |      and endtime is not null and trim(endtime) != ''
         |""".stripMargin)
    val rulewbDF: DataFrame = spark.sql(
      s"""select
         |*
         |from
         |dm_gis.grd_new_stay_info_alarm_rule_wb
         |where inc_day ='$inc_day'
         |      and vehicle_serial is not null and trim(vehicle_serial) != ''
         |      and starttime is not null and trim(starttime) != ''
         |      and endtime is not null and trim(endtime) != ''
         |""".stripMargin)

    getImei(spark, inc_day, ruleDF, "dm_gis.grd_new_stay_info_alarm_rule_imei")
    getImei(spark, inc_day, rulewbDF, "dm_gis.grd_new_stay_info_alarm_rule_wb_imei")
    getrulePro(spark, inc_day)
    getruleWbPro(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  //    def processImageReco(spark: SparkSession, inc_day: String): Unit = {
  //        import spark.implicits._
  //        val o_alarm_rule = spark.sql(
  //            s"""select
  //               |*
  //               |from
  //               |dm_gis.grd_new_stay_info_alarm_rule
  //               |where inc_day ='$inc_day'
  //               |      and vehicle_serial is not null and trim(vehicle_serial) != ''
  //               |      and starttime is not null and trim(starttime) != ''
  //               |      and endtime is not null and trim(endtime) != ''
  //               |""".stripMargin)
  //          .withColumn("start_ts", timeToTimestamp2('starttime))
  //          .withColumn("end_ts", timeToTimestamp2('endtime))
  //          .withColumn("alarm_ts", timeToTimestamp2('alarm_time))
  //          .repartition(20, 'vehicle_serial)
  //          .persist()
  //        //车牌号 -- imei 一对多
  //        val o_dm_device = spark.sql(
  //            s"""select carplate vehicle_serial,
  //               |       imei
  //               |from dm_arss.dm_device_hh_dtl_di
  //               |where inc_day ='$inc_day'
  //               |      and carplate is not null and trim(carplate) != ''
  //               |      and imei is not null and trim(imei) != ''
  //               |group by carplate,imei
  //               |""".stripMargin)
  //          .repartition(20, 'vehicle_serial)
  //
  //        val rule_device = o_alarm_rule.select("vehicle_serial", "start_ts", "end_ts", "rule", "alarm_ts")
  //          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "start_ts", "end_ts", "rule", "alarm_ts").orderBy("vehicle_serial")))
  //          .filter('num === 1)
  //          .join(o_dm_device, Seq("vehicle_serial")).repartition(1)
  //          .map(row => {
  //              val vehicle_serial = row.getAs[String]("vehicle_serial")
  //              val imei = row.getAs[String]("imei")
  //              val start_ts = row.getAs[String]("start_ts")
  //              val end_ts = row.getAs[String]("end_ts")
  //              val rule = row.getAs[String]("rule")
  //              var alarm_ts = row.getAs[String]("alarm_ts")
  //              if (alarm_ts.trim == "0") alarm_ts = "-1"
  //
  //              var info_str = ""
  //              var message = ""
  //              var res = ""
  //              val params =
  //                  s"""
  //                     |[["$imei",$start_ts,$end_ts,"$rule",$alarm_ts]]
  //          """.stripMargin
  //              try {
  //                  logger.info("传入的参数为：" + params)
  //                  info_str = HttpInvokeUtil.sendPost(HttpConstant.HTPP_VEHICLE_IMEI_P, params, 2, 2)
  //                  logger.info("post请求的json返回为：" + info_str)
  //                  // "{\"code\":200,\"message\":\"success\",\"res\":2}"
  //                  //          {"code":200,"message":"success","res":[1,4,0]}  branch的顺序是1--branch0  4--branch1 0--branch2
  //                  val imei_json = JSON.parseObject(info_str)
  //                  message = imei_json.getString("message")
  //                  res = imei_json.getString("res").replaceAll("\\[\\[|\\]\\]", "")
  //              } catch {
  //                  case e: Exception => logger.error(s"imei:$imei start_ts:$start_ts,end_ts:$end_ts 无返回值" + e.getMessage)
  //              }
  //              (vehicle_serial, start_ts, end_ts, imei, res)
  //          }).toDF("vehicle_serial", "start_ts", "end_ts", "imei", "res")
  //
  //        val arr: Column = split('res, ",")
  //
  //        val pic_res: DataFrame = o_alarm_rule.join(rule_device, Seq("vehicle_serial", "start_ts", "end_ts"), "left")
  //          .withColumn("branch0", when(arr(3) === "0", "normal30")
  //            .when(arr(3) === "1", "unnormal30")
  //            .when(arr(3) === "2", "normal00")
  //            .when(arr(3) === "3", "unnormal00"))
  //          .withColumn("branch1", when(arr(4) === "0", "wo_dms_pic")
  //            .when(arr(4) === "1", "with_1_dms_pic")
  //            .when(arr(4) === "2", "no_leave")
  //            .when(arr(4) === "4", "driver_leave"))
  //          .withColumn("branch2", when(arr(5) === "0", "wo_dms_pic")
  //            .when(arr(5) === "1", "with_1_dms_pic")
  //            .when(arr(5) === "2", "no_leave")
  //            .when(arr(5) === "4", "driver_leave"))
  //          .withColumn("pic_res", concat_ws(",", 'branch0, 'branch1, 'branch2))
  //          .select("vehicle_serial",
  //              "startindex",
  //              "endindex",
  //              "starttime",
  //              "endtime",
  //              "duration",
  //              "roadclass_x",
  //              "navi_addr",
  //              "business",
  //              "sub_type",
  //              "alarm_time",
  //              "time_gap",
  //              "startlon",
  //              "startlat",
  //              "task_area_code",
  //              "driver_id",
  //              "rule",
  //              "pic_res",
  //              "inc_day")
  //          .cache()
  //
  //        pic_res.count()
  //
  //        writeToHive(spark, pic_res, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule_imei")
  //
  //        pic_res.unpersist()
  //    }


  def getImei(spark: SparkSession, inc_day: String, df: DataFrame, tab: String): Unit = {
    import spark.implicits._
    val o_alarm_rule = df
      .withColumn("start_ts", timeToTimestamp2('starttime))
      .withColumn("end_ts", timeToTimestamp2('endtime))
      .withColumn("alarm_ts", timeToTimestamp2('alarm_time))
      .repartition(20, 'vehicle_serial)
      .persist()
    //车牌号 -- imei 一对多
    val o_dm_device = spark.sql(
      s"""select carplate vehicle_serial,
         |       imei
         |from dm_arss.dm_device_hh_dtl_di
         |where inc_day ='$inc_day'
         |      and carplate is not null and trim(carplate) != ''
         |      and imei is not null and trim(imei) != ''
         |group by carplate,imei
         |""".stripMargin)
      .repartition(20, 'vehicle_serial)

    val rule_device = o_alarm_rule.select("vehicle_serial", "start_ts", "end_ts", "rule", "alarm_ts")
      .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "start_ts", "end_ts", "rule", "alarm_ts").orderBy("vehicle_serial")))
      .filter('num === 1)
      .join(o_dm_device, Seq("vehicle_serial")).repartition(1)
      .map(row => {
        val vehicle_serial = row.getAs[String]("vehicle_serial")
        val imei = row.getAs[String]("imei")
        val start_ts = row.getAs[String]("start_ts")
        val end_ts = row.getAs[String]("end_ts")
        val rule = row.getAs[String]("rule")
        var alarm_ts = row.getAs[String]("alarm_ts")
        if (alarm_ts.trim == "0") alarm_ts = "-1"

        var info_str = ""
        var message = ""
        var res = ""
        val params =
          s"""
             |[["$imei",$start_ts,$end_ts,"$rule",$alarm_ts]]
          """.stripMargin
        try {
          logger.info("传入的参数为：" + params)
          info_str = HttpInvokeUtil.sendPost(HttpConstant.HTPP_VEHICLE_IMEI_P, params, 2, 2)
          logger.info("post请求的json返回为：" + info_str)
          // "{\"code\":200,\"message\":\"success\",\"res\":2}"
          //          {"code":200,"message":"success","res":[1,4,0]}  branch的顺序是1--branch0  4--branch1 0--branch2
          val imei_json = JSON.parseObject(info_str)
          message = imei_json.getString("message")
          res = imei_json.getString("res").replaceAll("\\[\\[|\\]\\]", "")
        } catch {
          case e: Exception => logger.error(s"imei:$imei start_ts:$start_ts,end_ts:$end_ts 无返回值" + e.getMessage)
        }
        (vehicle_serial, start_ts, end_ts, imei, res)
      }).toDF("vehicle_serial", "start_ts", "end_ts", "imei", "res")

    val arr: Column = split('res, ",")

    val pic_res: DataFrame = o_alarm_rule.join(rule_device, Seq("vehicle_serial", "start_ts", "end_ts"), "left")
      .withColumn("branch0", when(arr(3) === "0", "normal30")
        .when(arr(3) === "1", "unnormal30")
        .when(arr(3) === "2", "normal00")
        .when(arr(3) === "3", "unnormal00"))
      .withColumn("branch1", when(arr(4) === "0", "wo_dms_pic")
        .when(arr(4) === "1", "with_1_dms_pic")
        .when(arr(4) === "2", "no_leave")
        .when(arr(4) === "4", "driver_leave"))
      .withColumn("branch2", when(arr(5) === "0", "wo_dms_pic")
        .when(arr(5) === "1", "with_1_dms_pic")
        .when(arr(5) === "2", "no_leave")
        .when(arr(5) === "4", "driver_leave"))
      .withColumn("pic_res", concat_ws(",", 'branch0, 'branch1, 'branch2))
      .select("vehicle_serial",
        "startindex",
        "endindex",
        "starttime",
        "endtime",
        "duration",
        "roadclass_x",
        "navi_addr",
        "business",
        "sub_type",
        "alarm_time",
        "time_gap",
        "startlon",
        "startlat",
        "task_area_code",
        "driver_id",
        "rule",
        "pic_res",
        "inc_day")
      .cache()

    pic_res.count()

    writeToHive(spark, pic_res, Seq("inc_day"), tab)

    pic_res.unpersist()
  }

  def getrulePro(spark: SparkSession, inc_day: String): Unit = {

    val ruleSql: String =
      s"""
         |select
         |  *
         |from
         |  dm_gis.grd_new_stay_info_alarm_rule
         |where
         |  cast(if(points_in_area is null or points_in_area = '', '0',points_in_area) as int) < 20
         |  and inc_day = '$inc_day'
         |""".stripMargin
    val imeiSql: String =
      s"""
         |select
         |  vehicle_serial,
         |  starttime,
         |  endtime,
         |  pic_res
         |from
         |  dm_gis.grd_new_stay_info_alarm_rule_imei
         |where
         |  inc_day= $inc_day
         |  and pic_res not like 'normal%no_leave'
         |""".stripMargin

    val ruleDF: DataFrame = spark.sql(ruleSql).drop("inc_day")
    val imeiDF: DataFrame = spark.sql(imeiSql).dropDuplicates()


    val rule_proDF: DataFrame = ruleDF.join(imeiDF,
      ruleDF("vehicle_serial") === imeiDF("vehicle_serial")
        && ruleDF("starttime") === imeiDF("starttime")
        && ruleDF("endtime") === imeiDF("endtime"), "left"
    )
      .drop(imeiDF("vehicle_serial"))
      .drop(imeiDF("starttime"))
      .drop(imeiDF("endtime"))
      .withColumn("inc_day", lit(inc_day))
      .cache()

    logger.error(s"rule_pro 的数据量：${rule_proDF.count()} 条")

    rule_proDF.show(3, truncate = false)

    writeToHive(spark, rule_proDF, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule_pro")
  }

  def getruleWbPro(spark: SparkSession, inc_day: String): Unit = {

    val ruleSql: String =
      s"""
         |select
         |  *
         |from
         |  dm_gis.grd_new_stay_info_alarm_rule_wb
         |where
         |  cast(if(points_in_area is null or points_in_area = '', '0',points_in_area) as int) < 20
         |  and inc_day = '$inc_day'
         |""".stripMargin
    val imeiSql: String =
      s"""
         |select
         |  vehicle_serial,
         |  starttime,
         |  endtime,
         |  pic_res
         |from
         |  dm_gis.grd_new_stay_info_alarm_rule_wb_imei
         |where
         |  inc_day= $inc_day
         |  and pic_res not like 'normal%no_leave'
         |""".stripMargin

    val ruleDF: DataFrame = spark.sql(ruleSql).drop("inc_day")
    val imeiDF: DataFrame = spark.sql(imeiSql).dropDuplicates()


    val rule_proDF: DataFrame = ruleDF.join(imeiDF,
      ruleDF("vehicle_serial") === imeiDF("vehicle_serial")
        && ruleDF("starttime") === imeiDF("starttime")
        && ruleDF("endtime") === imeiDF("endtime"), "left"
    )
      .drop(imeiDF("vehicle_serial"))
      .drop(imeiDF("starttime"))
      .drop(imeiDF("endtime"))
      .withColumn("inc_day", lit(inc_day))
      .cache()

    logger.error(s"rule_pro 的数据量：${rule_proDF.count()} 条")

    rule_proDF.show(3, truncate = false)

    writeToHive(spark, rule_proDF, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule_wb_pro")
  }
}
