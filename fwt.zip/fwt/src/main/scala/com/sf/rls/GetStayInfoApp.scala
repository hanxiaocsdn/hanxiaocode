package com.sf.rls

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.DataSourceCommon
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import constant.HttpConstant.{HTPP_RGEO_X_Y_G, HTPP_STAY_POINTS_P}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.DateUtil.tranTimestampToDate
import utils.HttpClientUtil.getJsonParam
import utils.{HttpInvokeUtil, SparkBuilder}

import java.text.SimpleDateFormat
import java.util
import scala.collection.mutable.ArrayBuffer

/**
 * 任务ID：404757
 */
case class StayPoints(startIndex: String, endIndex: String, startTime: String, endTime: String, duration: String, startLon: String, startLat: String, endLon: String, endLat: String, tm_x: String, roadClass_x: String, roadName_x: String, tm_y: String, roadClass_y: String, roadName_y: String)

case class StayInfo(vehicle_serial: String, task_area_code: String, beginDateTime: String, endDateTime: String, len: String, roadTime: String, startIndex: String, endIndex: String, startTime: String, endTime: String, duration: String, startLon: String, startLat: String, endLon: String, endLat: String, tm_x: String, roadClass_x: String, roadName_x: String, tm_y: String, roadClass_y: String, roadName_y: String, name: String, navi_addr: String, business: String, is_zy: String, inc_day: String)

object GetStayInfoApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {

    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)

    val initData = loadDataInfo(spark, inc_day)
    val httpInvoke_1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "404757", "CLAQYY001安全护航】GetStayInfo", "第1次调用--根据车牌号及时间点获取停留时间段信息", HTPP_STAY_POINTS_P, "d9e6e04d1f3044538d4aa91bb08df217", initData.count(), 40)
    val stayPointsDs = getStayPoints(spark, initData, inc_day)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_1)
    //需求2.7新增逻辑，取最后一个轨迹停留点
    val initDataMaxTm = loadDataInfoMaxTm(spark, inc_day)

    val httpInvoke_2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "404757", "CLAQYY001安全护航】GetStayInfo", "第2次调用--根据车牌号及时间点获取停留时间段信息", HTPP_STAY_POINTS_P, "d9e6e04d1f3044538d4aa91bb08df217", initDataMaxTm.count(), 40)
    val stayPointsLastDs = getStayPointsLast(spark, initDataMaxTm, inc_day)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_2)

    val stayPointsDsNew = stayPointsDs.union(stayPointsLastDs)

    val httpInvoke_3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01418539", "404757", "CLAQYY001安全护航】GetStayInfo", "根据经纬度获取停留点信息", HTPP_RGEO_X_Y_G, "d9e6e04d1f3044538d4aa91bb08df217", stayPointsDsNew.count(), 40)
    val addr_info = getNaviAddreInfoGet(spark, stayPointsDsNew)
    BdpTaskRecordUtil.endNetworkInterface("01418539", httpInvoke_3)

    writeToHive(spark, addr_info, Seq("inc_day"), "dm_gis.grd_new_stay_info")
    spark.stop()
  }

  def loadDataInfo(spark: SparkSession, inc_day: String): DataFrame = {

    val init_df: DataFrame = spark.sql(
      s"""
         |select
         |   carplate vehicle_serial, --车牌
         |   deptcode task_area_code,
         |   concat(inc_day,'000000') as beginDateTime,
         |   concat(inc_day,'235959') as endDateTime,
         |   if(substring(data_code,0,8) ='10001004','1','0') as is_zy,
         |   inc_day
         |from
         |   dm_arss.dm_device_hh_dtl_di
         |where
         |   inc_day = '$inc_day'
         |   and carplate is not null and trim(carplate) != ''
         |   and is_security = '0'
         |group by
         |   carplate,
         |   deptcode,
         |   substring(data_code,0,8),
         |   inc_day
         |""".stripMargin)



    //    val init_res = init_df.filter(col("vehicle_serial").like("%京%")).limit(50)
    init_df
    //    val init_res = init_df.filter(trim(col("task_area_code")).isin("010Y", "111Y", "028Y")) //北京区 010Y 华南分拨区 111Y 四川区 028Y
    //      .toDF()
    //    init_res
  }

  def loadDataInfoMaxTm(spark: SparkSession, inc_day: String): DataFrame = {

    val init_df: DataFrame = spark.sql(
      s"""
         |select
         |  vehicle_serial, --车牌
         |  task_area_code,
         |  is_zy,
         |  imei,
         |  tm,
         |  inc_day
         |from(
         |    select
         |      carplate as vehicle_serial, --车牌
         |      deptcode as task_area_code,
         |      if(substring(data_code, 0, 8) = '10001004', '1', '0') as is_zy,
         |      imei,
         |      inc_day
         |    from
         |      dm_arss.dm_device_hh_dtl_di
         |    where
         |      inc_day = '$inc_day'
         |      and carplate is not null
         |      and trim(carplate) <> ''
         |      and is_security = '0'
         |    group by
         |      carplate,
         |      deptcode,
         |      imei,
         |      substring(data_code, 0, 8),
         |      inc_day
         |  ) t1
         |  left join (
         |    select
         |      un,
         |      tm
         |    from(
         |        select
         |          un,
         |          tm,
         |          row_number() over(partition by un order by tm desc) rn
         |        from
         |          dm_gis.gis_vms_track_device_track_flatmap
         |        where
         |          inc_day = '$inc_day'
         |          and sp <> 0
         |          and sp <> ''
         |          and sp is not null
         |      ) t2
         |    where rn = 1
         |    group by un,tm
         |  ) t3 on t1.imei = t3.un
         |  where length(tm) = 10
         |""".stripMargin)
    init_df
  }

  def getStayPoints(spark: SparkSession, initDf: DataFrame, inc_day: String): DataFrame = {
    import spark.implicits._

    val stay_info_df = initDf.repartition(40)
      .map(row => {
        val vehicle_serial = row.getAs[String]("vehicle_serial")
        val task_area_code = row.getAs[String]("task_area_code")
        val beginDateTime = row.getAs[String]("beginDateTime")
        val endDateTime = row.getAs[String]("endDateTime")
        val is_zy = row.getAs[String]("is_zy")
        val params =
          s"""
             | {
             |"ak": "d9e6e04d1f3044538d4aa91bb08df217",
             |"type": "404",
             |"un": "$vehicle_serial",
             |"unType": 0,
             |"stayRadius": 100,
             |"stayDuration": 1800,
             |"beginDateTime": "$beginDateTime",
             |"endDateTime": "$endDateTime"
             |}
      """.stripMargin

        var startIndex = ""
        var endIndex = ""
        var startTime = ""
        var endTime = ""
        var duration = ""
        var startLon = ""
        var startLat = ""
        var endLon = ""
        var endLat = ""
        var len = ""
        var roadTime = ""
        var info_str = ""

        //缓存tack行车轨迹的tm  roadClass  roadName
        val vehicle_tm_cacheMap = new util.concurrent.ConcurrentHashMap[String, (String, String)]()
        //存放staypoints返回的数据
        val stayPoint_arr = new ArrayBuffer[StayPoints]()
        try {
          info_str = HttpInvokeUtil.sendPost(HTPP_STAY_POINTS_P, params, 3, 2)
          val info_resp_json = JSON.parseObject(info_str)
          val json_p1 = info_resp_json.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          val json_p2 = info_resp_json.getJSONObject("result").getJSONObject("data").getJSONArray("stayPoints")
          len = info_resp_json.getJSONObject("result").getJSONObject("data").getString("len")
          roadTime = info_resp_json.getJSONObject("result").getJSONObject("data").getString("roadTime")

          for (i <- 0 to json_p1.size() - 1) {
            val mt_key = json_p1.getJSONObject(i).getString("tm")
            val roadClass_v = json_p1.getJSONObject(i).getString("roadClass")
            val roadName_v = json_p1.getJSONObject(i).getString("roadName")
            vehicle_tm_cacheMap.put(mt_key, (roadClass_v, roadName_v))
          }

          for (j <- 0 to json_p2.size() - 1) {
            val json_for = json_p2.getJSONObject(j)
            startIndex = json_for.getString("startIndex")
            endIndex = json_for.getString("endIndex")
            startTime = json_for.getString("startTime")
            endTime = json_for.getString("endTime")
            duration = json_for.getString("duration")
            startLon = json_for.getString("startLon")
            startLat = json_for.getString("startLat")
            endLon = json_for.getString("endLon")
            endLat = json_for.getString("endLat")

            val tm_x = startTime
            val key_tm_x = vehicle_tm_cacheMap.get(startTime)
            val roadClass_x = key_tm_x._1
            val roadName_x = key_tm_x._2

            val tm_y = endTime
            val key_tm_y = vehicle_tm_cacheMap.get(endTime)
            val roadClass_y = key_tm_y._1
            val roadName_y = key_tm_y._2
            stayPoint_arr += StayPoints(startIndex, endIndex, startTime, endTime, duration, startLon, startLat, endLon, endLat, tm_x, roadClass_x, roadName_x, tm_y, roadClass_y, roadName_y)
          }
        } catch {
          case e: Exception => logger.error("Connection ……" + e.getMessage)
        }
        (vehicle_serial, task_area_code, beginDateTime, endDateTime, is_zy, len, roadTime, stayPoint_arr)

      }).toDF("vehicle_serial", "task_area_code", "beginDateTime", "endDateTime", "is_zy", "len", "roadTime", "stayPoint_arr")
    val stay_info_res = stay_info_df
      .withColumn("stayPoints", explode($"stayPoint_arr"))
      .withColumn("startIndex", $"stayPoints"("startIndex"))
      .withColumn("endIndex", $"stayPoints"("endIndex"))
      .withColumn("startTime", tranTimestampToDate($"stayPoints"("startTime")))
      .withColumn("endTime", tranTimestampToDate($"stayPoints"("endTime")))
      .withColumn("duration", $"stayPoints"("duration"))
      .withColumn("startLon", $"stayPoints"("startLon"))
      .withColumn("startLat", $"stayPoints"("startLat"))
      .withColumn("endLon", $"stayPoints"("endLon"))
      .withColumn("endLat", $"stayPoints"("endLat"))
      .withColumn("tm_x", tranTimestampToDate($"stayPoints"("tm_x")))
      .withColumn("roadClass_x", $"stayPoints"("roadClass_x"))
      .withColumn("roadName_x", $"stayPoints"("roadName_x"))
      .withColumn("tm_y", tranTimestampToDate($"stayPoints"("tm_y")))
      .withColumn("roadClass_y", $"stayPoints"("roadClass_y"))
      .withColumn("roadName_y", $"stayPoints"("roadName_y"))
      .withColumn("inc_day", lit(inc_day))
      .drop("stayPoints", "stayPoint_arr")
    stay_info_res
  }

  def getStayPointsLast(spark: SparkSession, initDf: DataFrame, inc_day: String): DataFrame = {
    import spark.implicits._
    val stay_info_df = initDf.repartition(40)
      .map(row => {
        val vehicle_serial = row.getAs[String]("vehicle_serial")
        val task_area_code = row.getAs[String]("task_area_code")
        val is_zy = row.getAs[String]("is_zy")

        val sdf = new SimpleDateFormat("yyyyMMddHHmmss")
        var tm: Long = 0
        var beginDateTime = ""
        var endDateTime = ""
        try {
          tm = row.getAs[String]("tm").toLong
          beginDateTime = sdf.format(tm * 1000)
          endDateTime = sdf.format(tm * 1000 + 5000)
        } catch {
          case e: Exception => logger.error("tm数据异常 …… tm=" + tm + "..." + e.getMessage)
        }

        val params =
          s"""
             | {
             |"ak": "d9e6e04d1f3044538d4aa91bb08df217",
             |"type": "404",
             |"un": "$vehicle_serial",
             |"unType": 0,
             |"stayRadius": 100,
             |"stayDuration": 0,
             |"beginDateTime": "$beginDateTime",
             |"endDateTime": "$endDateTime"
             |}
      """.stripMargin

        var startIndex = ""
        var endIndex = ""
        var startTime = ""
        var endTime = ""
        var duration = ""
        var startLon = ""
        var startLat = ""
        var endLon = ""
        var endLat = ""
        var len = ""
        var roadTime = ""
        var info_str = ""

        //缓存tack行车轨迹的tm  roadClass  roadName
        val vehicle_tm_cacheMap = new util.concurrent.ConcurrentHashMap[String, (String, String)]()
        //存放staypoints返回的数据
        val stayPoint_arr = new ArrayBuffer[StayPoints]()
        try {
          info_str = HttpInvokeUtil.sendPost(HTPP_STAY_POINTS_P, params, 3, 2)
          val info_resp_json = JSON.parseObject(info_str)
          val json_p1 = info_resp_json.getJSONObject("result").getJSONObject("data").getJSONArray("track")
          val json_p2 = info_resp_json.getJSONObject("result").getJSONObject("data").getJSONArray("stayPoints")
          len = info_resp_json.getJSONObject("result").getJSONObject("data").getString("len")
          roadTime = info_resp_json.getJSONObject("result").getJSONObject("data").getString("roadTime")

          for (i <- 0 to json_p1.size() - 1) {
            val mt_key = json_p1.getJSONObject(i).getString("tm")
            val roadClass_v = json_p1.getJSONObject(i).getString("roadClass")
            val roadName_v = json_p1.getJSONObject(i).getString("roadName")
            vehicle_tm_cacheMap.put(mt_key, (roadClass_v, roadName_v))
          }

          if (json_p2.isEmpty) {
            val tm_y = ""
            val roadClass_y = ""
            val roadName_y = ""
            startLon = json_p1.getJSONObject(0).getString("dx")
            startLat = json_p1.getJSONObject(0).getString("dy")
            val tm_x = json_p1.getJSONObject(0).getString("tm")
            val roadClass_x = json_p1.getJSONObject(0).getString("roadClass")
            val roadName_x = json_p1.getJSONObject(0).getString("roadName")

            stayPoint_arr += StayPoints(startIndex, endIndex, startTime, endTime, duration, startLon, startLat, endLon, endLat, tm_x, roadClass_x, roadName_x, tm_y, roadClass_y, roadName_y)
          } else {
            for (j <- 0 to json_p2.size() - 1) {
              val json_for = json_p2.getJSONObject(j)
              startIndex = json_for.getString("startIndex")
              endIndex = json_for.getString("endIndex")
              startTime = json_for.getString("startTime")
              endTime = json_for.getString("endTime")
              duration = json_for.getString("duration")
              startLon = json_for.getString("startLon")
              startLat = json_for.getString("startLat")
              endLon = json_for.getString("endLon")
              endLat = json_for.getString("endLat")

              val tm_x = startTime
              val key_tm_x = vehicle_tm_cacheMap.get(startTime)
              val roadClass_x = key_tm_x._1
              val roadName_x = key_tm_x._2

              val tm_y = endTime
              val key_tm_y = vehicle_tm_cacheMap.get(endTime)
              val roadClass_y = key_tm_y._1
              val roadName_y = key_tm_y._2
              stayPoint_arr += StayPoints(startIndex, endIndex, startTime, endTime, duration, startLon, startLat, endLon, endLat, tm_x, roadClass_x, roadName_x, tm_y, roadClass_y, roadName_y)
            }
          }
        } catch {
          case e: Exception => logger.error("Connection ……" + e.getMessage)
        }
        (vehicle_serial, task_area_code, beginDateTime, endDateTime, is_zy, len, roadTime, stayPoint_arr)

      }).toDF("vehicle_serial", "task_area_code", "beginDateTime", "endDateTime", "is_zy", "len", "roadTime", "stayPoint_arr")

    val stay_info_res = stay_info_df
      .withColumn("stayPoints", explode($"stayPoint_arr"))
      .withColumn("startIndex", $"stayPoints"("startIndex"))
      .withColumn("endIndex", $"stayPoints"("endIndex"))
      //.withColumn("startTime", tranTimestampToDate($"stayPoints"("startTime")))
      .withColumn("startTime", when($"stayPoints"("startTime") =!= "", tranTimestampToDate($"stayPoints"("startTime"))))
      //.withColumn("endTime", tranTimestampToDate($"stayPoints"("endTime")))
      .withColumn("endTime", when($"stayPoints"("endTime") =!= "", tranTimestampToDate($"stayPoints"("endTime"))))
      .withColumn("duration", $"stayPoints"("duration"))
      .withColumn("startLon", $"stayPoints"("startLon"))
      .withColumn("startLat", $"stayPoints"("startLat"))
      .withColumn("endLon", $"stayPoints"("endLon"))
      .withColumn("endLat", $"stayPoints"("endLat"))
      //.withColumn("tm_x", tranTimestampToDate($"stayPoints"("tm_x")))
      .withColumn("tm_x", when($"stayPoints"("tm_x") =!= "", tranTimestampToDate($"stayPoints"("tm_x"))))
      .withColumn("roadClass_x", $"stayPoints"("roadClass_x"))
      .withColumn("roadName_x", $"stayPoints"("roadName_x"))
      //.withColumn("tm_y", tranTimestampToDate($"stayPoints"("tm_y")))
      .withColumn("tm_y", when($"stayPoints"("tm_y") =!= "", tranTimestampToDate($"stayPoints"("tm_y"))))
      .withColumn("roadClass_y", $"stayPoints"("roadClass_y"))
      .withColumn("roadName_y", $"stayPoints"("roadName_y"))
      .withColumn("timestamp", $"stayPoints"("tm_x"))
      .withColumn("tm_x_tmp", from_unixtime(col("timestamp"), "yyyyMMdd"))
      .filter(col("tm_x_tmp") === inc_day)
      .withColumn("inc_day", lit(inc_day))
      .drop("stayPoints", "stayPoint_arr", "timestamp", "tm_x_tmp")
    stay_info_res
  }

  def getNaviAddreInfoGet(spark: SparkSession, postDF: DataFrame): DataFrame = {
    import spark.implicits._
    val navi_info_df = postDF
      .map(row => {
        val vehicle_serial = row.getAs[String]("vehicle_serial")
        val task_area_code = row.getAs[String]("task_area_code")
        val beginDateTime = row.getAs[String]("beginDateTime")
        val endDateTime = row.getAs[String]("endDateTime")
        val is_zy = row.getAs[String]("is_zy")
        val len = row.getAs[String]("len")
        val roadTime = row.getAs[String]("roadTime")
        //        val json_1 = row.getAs[String]("json_1")
        val startIndex = row.getAs[String]("startIndex")
        val endIndex = row.getAs[String]("endIndex")
        val startTime = row.getAs[String]("startTime")
        val endTime = row.getAs[String]("endTime")
        val duration = row.getAs[String]("duration")
        val startLon = row.getAs[String]("startLon")
        val startLat = row.getAs[String]("startLat")
        val endLon = row.getAs[String]("endLon")
        val endLat = row.getAs[String]("endLat")
        val tm_x = row.getAs[String]("tm_x")
        val roadClass_x = row.getAs[String]("roadClass_x")
        val roadName_x = row.getAs[String]("roadName_x")
        val tm_y = row.getAs[String]("tm_y")
        val roadClass_y = row.getAs[String]("roadClass_y")
        val roadName_y = row.getAs[String]("roadName_y")
        val inc_day = row.getAs[String]("inc_day")


        var name = ""
        var navi_addr = ""
        var business = ""
        var json_2 = ""
        try {
          val urlParam = getJsonParam(HTPP_RGEO_X_Y_G, startLon, startLat, "d9e6e04d1f3044538d4aa91bb08df217")
          val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
          val response_str: JSONObject = JSON.parseObject(getUrlRes)
          val json_pub = response_str.getJSONObject("result")
          json_2 = getUrlRes
          //          logger.info("第2个post请求的json返回为：" + json_2)
          name = json_pub.getString("name")
          navi_addr = json_pub.getString("navi_addr")
          business = json_pub.getString("business")
        } catch {
          case e: Exception => logger.error("Connection ………url2………" + e.getMessage)
        }
        StayInfo(vehicle_serial, task_area_code, beginDateTime, endDateTime, len, roadTime, startIndex, endIndex, startTime, endTime, duration, startLon, startLat, endLon, endLat, tm_x, roadClass_x, roadName_x, tm_y, roadClass_y, roadName_y, name, navi_addr, business, is_zy, inc_day) //去掉 json_1, json_2,
      })
      .toDF("vehicle_serial", "task_area_code", "beginDateTime", "endDateTime", "len", "roadTime", "startIndex", "endIndex", "startTime", "endTime", "duration", "startLon", "startLat", "endLon", "endLat", "tm_x", "roadClass_x", "roadName_x", "tm_y", "roadClass_y", "roadName_y", "name", "navi_addr", "business", "is_zy", "inc_day")
      .coalesce(10)

    navi_info_df
  }


}
