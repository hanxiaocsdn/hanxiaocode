package com.sf.rls

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{Column, SparkSession}
import org.apache.spark.sql.functions._
import utils.SparkBuilder

/**
 * @description: 	430171
 * @author 01418539 caojia
 * @date 2022/4/19 9:56
 */
object HyInsuranceAccidentApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val start_day = args(0)
    processData(spark, start_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processData(spark: SparkSession, start_day: String): Unit = {
    import spark.implicits._
    val o_insurePolicy = spark.sql(
      s"""
         |select
         |     vehicle_code,     --车牌号
         |     loss_event_dt,    --出险时间
         |     regexp_replace(substr(loss_event_dt, 0, 10),'-', '') loss_event_dt_sub,
         |     loss_event_place, --出险地点
         |     case_category,    --事故类型
         |     insurant,         --被保险人
         |     type,             --险种分类
         |     responsibility,   --事故责任
         |     case_status_lp,   --案件状态-理赔
         |     case_status_ba,   --案件状态-报案
         |     claim_detail_status,  --理赔明细状态<立案明细>
         |     underwriting_amount,  --已决金额
         |     estimated_loss_amount --估损金额
         |from dm_gis.report_claim_insurance_compensation_dtl
         |where is_new_status = '是'
         |      and regexp_replace(substr(loss_event_dt, 0, 10),'-', '') >= '20210929'
         |      and regexp_replace(substr(loss_event_dt, 0, 10),'-', '') <='$start_day'
         |      and vehicle_code is not null and trim(vehicle_code) !=''
         |group by vehicle_code,loss_event_dt,loss_event_place,case_category,insurant,type,responsibility,case_status_lp,case_status_ba,claim_detail_status,underwriting_amount,estimated_loss_amount
         |""".stripMargin)

    val o_accidentAlarm = spark.sql(
      s"""
         |select
         |     *
         |from dm_gis.grd_new_stay_info_alarm_rule
         |where vehicle_serial is not null and trim(vehicle_serial) !=''
         |      and inc_day >= '20210929' and inc_day <='$start_day'
         |""".stripMargin)

    val cols_all: Seq[Column] = Seq('vehicle_code, 'loss_event_dt, 'loss_event_place, 'case_category, 'insurant, 'type, 'responsibility, 'case_status_lp, 'case_status_ba,
      'claim_detail_status, 'underwriting_amount, 'estimated_loss_amount, 'vehicle_serial, 'startindex, 'endindex, 'starttime, 'endtime, 'duration,
      'roadclass_x, 'navi_addr, 'business, 'sub_type, 'alarm_time, 'time_gap, 'startlon, 'startlat, 'task_area_code, 'driver_id, 'rule, 'inc_day)

    val insureAlarm = o_insurePolicy.alias("o_insurePolicy")
      .join(o_accidentAlarm.as("o_accidentAlarm"), expr("o_insurePolicy.vehicle_code = o_accidentAlarm.vehicle_serial and o_insurePolicy.loss_event_dt_sub = o_accidentAlarm.inc_day"), "left")
      .select(cols_all: _*)
    //全量未分区表中
    writeToHiveNoP(spark, insureAlarm, "report_claim_insurance_accident_alarm_dtl")


  }

}
