package com.sf.rls

import com.sf.common.DataSourceCommon
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.functions.{broadcast, col}
import org.apache.spark.sql.{DataFrame, Encoders, Row, SparkSession}
import utils.SparkBuilder

import scala.collection.mutable.ArrayBuffer
import scala.util.Random

/**
 * @task_id:
 * @description:
 * @demander:
 * @author 01418539 caojia
 * @date 2022/10/26 12:42
 */
case class A1(company_name: String,
              company_id: String,
              reg_number: String,
              credit_code: String,
              abnormal_put_cnt: String,
              abnormal_put_reason_type_cnt: String,
              abnormal_most_put_reason_type: String,
              abnormal_recent_yr_put_main_reason: String,
              abnormal_put_remove_avg_duration: String,
              abnormal_put_remove_max_duration: String,
              license_total_cnt: String,
              license_type_cnt: String,
              license_most_type: String,
              license_valid_gt_1_yr_cnt: String,
              dishonested_label: String,
              liquidation_label: String,
              punishment_total_cnt: String,
              punishment_type_cnt: String,
              punishment_most_type: String,
              punishment_penalty_type_cnt: String,
              punishment_most_penalty_type: String,
              punishment_recent_yr_total_cnt: String,
              punishment_recent_yr_total_type_cnt: String,
              punishment_recent_yr_most_type: String,
              punishment_recent_yr_penalty_type_cnt: String,
              punishment_recent_yr_most_penalty_type: String,
              zhixing_type: String,
              zhixing_total_cnt: String,
              zhixing_recent_yr_cnt: String,
              comp_change_chg_cnt: String,
              comp_change_chg_type_cnt: String,
              comp_change_most_chg_type: String,
              comp_change_recent_yr_most_chg_type: String,
              job_total_cnt: String,
              lawsuit_bg_cnt: String,
              tax_total_cnt: String,
              tax_tax_type_cnt: String,
              tax_added_value_tax_times: String,
              tax_corp_tax_times: String,
              tax_credit_nation_freq_rate: String,
              tax_credit_local_freq_rate: String,
              tax_credit_recent_nation_rate: String,
              tax_credit_recent_local_rate: String,
              phone_number: String,
              legal_person_name: String)

case class A2(company_name: String, company_id: String,
              reg_number: String,
              credit_code: String,
              abnormal_put_cnt: String,
              abnormal_put_reason_type_cnt: String,
              abnormal_most_put_reason_type: String,
              abnormal_recent_yr_put_main_reason: String,
              abnormal_put_remove_avg_duration: String,
              abnormal_put_remove_max_duration: String,
              license_total_cnt: String,
              license_type_cnt: String,
              license_most_type: String,
              license_valid_gt_1_yr_cnt: String,
              dishonested_label: String,
              liquidation_label: String,
              punishment_total_cnt: String,
              punishment_type_cnt: String,
              punishment_most_type: String,
              punishment_penalty_type_cnt: String,
              punishment_most_penalty_type: String,
              punishment_recent_yr_total_cnt: String,
              punishment_recent_yr_total_type_cnt: String,
              punishment_recent_yr_most_type: String,
              punishment_recent_yr_penalty_type_cnt: String,
              punishment_recent_yr_most_penalty_type: String,
              zhixing_type: String,
              zhixing_total_cnt: String,
              zhixing_recent_yr_cnt: String,
              comp_change_chg_cnt: String,
              comp_change_chg_type_cnt: String,
              comp_change_most_chg_type: String,
              comp_change_recent_yr_most_chg_type: String,
              job_total_cnt: String,
              lawsuit_bg_cnt: String,
              tax_total_cnt: String,
              tax_tax_type_cnt: String,
              tax_added_value_tax_times: String,
              tax_corp_tax_times: String,
              tax_credit_nation_freq_rate: String,
              tax_credit_local_freq_rate: String,
              tax_credit_recent_nation_rate: String,
              tax_credit_recent_local_rate: String,
              phone_number: String,
              legal_person_name: String, reg_location: String, company_org_type_new: String, business_scope: String, cate_1: String, cate_2: String, cate_3: String, legal_person_type: String)

object DataLoadTest extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> START CALCULATION>>>>>")
    val inpath = args(0)
    val tableName = args(1)
    //    loadData(spark, "alarm_type_mapping")
    //    processaa(spark)
    //    loadData(spark, inpath, tableName)
    //    processOther(spark)
    processOtherAAA(spark)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> COMPLETELY SUCCESS!")
  }

  def processOtherAAA(spark: SparkSession): Unit = {
    import spark.implicits._
    val res_cols = spark.sql("""select * from default.vehicle_company_info22 limit 0""").schema.map(x => col(x.name))

    val a1 = spark.sql(
      """
        |select * from dm_gis_edt.tyc_merged_profile_base where inc_day='20221101' and comp_name is not null and trim(comp_name) != ''
        |""".stripMargin)
      .withColumnRenamed("comp_name", "company_name").repartition(600, col("company_name"))
    val a2 = spark.sql("""select * from default.vehicle_company2 where owner_name is not null and trim(owner_name) != ''""").withColumnRenamed("owner_name", "company_name")
      .repartition(600, col("company_name"))
    val a12 = a1.join(broadcast(a2), Seq("company_name"), "inner").select("company_name",
      "company_id",
      "reg_number",
      "credit_code",
      "abnormal_put_cnt",
      "abnormal_put_reason_type_cnt",
      "abnormal_most_put_reason_type",
      "abnormal_recent_yr_put_main_reason",
      "abnormal_put_remove_avg_duration",
      "abnormal_put_remove_max_duration",
      "license_total_cnt",
      "license_type_cnt",
      "license_most_type",
      "license_valid_gt_1_yr_cnt",
      "dishonested_label",
      "liquidation_label",
      "punishment_total_cnt",
      "punishment_type_cnt",
      "punishment_most_type",
      "punishment_penalty_type_cnt",
      "punishment_most_penalty_type",
      "punishment_recent_yr_total_cnt",
      "punishment_recent_yr_total_type_cnt",
      "punishment_recent_yr_most_type",
      "punishment_recent_yr_penalty_type_cnt",
      "punishment_recent_yr_most_penalty_type",
      "zhixing_type",
      "zhixing_total_cnt",
      "zhixing_recent_yr_cnt",
      "comp_change_chg_cnt",
      "comp_change_chg_type_cnt",
      "comp_change_most_chg_type",
      "comp_change_recent_yr_most_chg_type",
      "job_total_cnt",
      "lawsuit_bg_cnt",
      "tax_total_cnt",
      "tax_tax_type_cnt",
      "tax_added_value_tax_times",
      "tax_corp_tax_times",
      "tax_credit_nation_freq_rate",
      "tax_credit_local_freq_rate",
      "tax_credit_recent_nation_rate",
      "tax_credit_recent_local_rate")


    val encoder12 = Encoders.tuple(
      Encoders.STRING, RowEncoder(a12.schema))

    val aa12 = a12.map(row => {
      val key = row.getAs[String]("company_name")
      (key, row)
    })(encoder12).rdd

    val a3 = spark.sql(
      """ select
        |      company_name,
        |      phone_number,
        |      legal_person_name
        |    from
        |      dm_gis_edt.annual_report_info_filtered
        |    where
        |      inc_day = '20221001' and company_name is not null and trim(company_name) != ''
        |      group by company_name,phone_number,legal_person_name
        |      """.stripMargin)
      .repartition(600, col("company_name"))
    val encoder3 = Encoders.tuple(
      Encoders.STRING, RowEncoder(a3.schema))
    val aa3 = a3.map(row => {
      val key = row.getAs[String]("company_name")
      (key, row)
    })(encoder3).rdd

    val a4 = spark.sql(
      """  select
        |      name as company_name,
        |      reg_location,
        |      company_org_type_new,
        |      business_scope,
        |      cate_1,
        |      cate_2,
        |      cate_3,
        |      legal_person_type
        |    from
        |      dm_gis_edt.company_basic_info_clean
        |    where
        |      inc_day = '20221101'  and name is not null and trim(name) != ''
        |     group by name,reg_location,company_org_type_new,business_scope,cate_1,cate_2,cate_3,legal_person_type
        |      """.stripMargin)
      .repartition(600, col("company_name"))
    val encoder4 = Encoders.tuple(
      Encoders.STRING, RowEncoder(a4.schema))
    val aa4 = a4.map(row => {
      val key = row.getAs[String]("company_name")
      (key, row)
    })(encoder4).rdd

    val aa123: RDD[(String, (Row, Option[Row]))] = leftOuterJoinKeyS(aa12, aa3, 10, 20)
    val aaa123 = aa123.map(row => {
      var company_name, company_id, reg_number, credit_code, abnormal_put_cnt, abnormal_put_reason_type_cnt, abnormal_most_put_reason_type,
      abnormal_recent_yr_put_main_reason, abnormal_put_remove_avg_duration, abnormal_put_remove_max_duration,
      license_total_cnt, license_type_cnt, license_most_type,
      license_valid_gt_1_yr_cnt, dishonested_label, liquidation_label, punishment_total_cnt, punishment_type_cnt,
      punishment_most_type, punishment_penalty_type_cnt, punishment_most_penalty_type,
      punishment_recent_yr_total_cnt, punishment_recent_yr_total_type_cnt,
      punishment_recent_yr_most_type, punishment_recent_yr_penalty_type_cnt, punishment_recent_yr_most_penalty_type,
      zhixing_type, zhixing_total_cnt, zhixing_recent_yr_cnt, comp_change_chg_cnt, comp_change_chg_type_cnt,
      comp_change_most_chg_type, comp_change_recent_yr_most_chg_type, job_total_cnt, lawsuit_bg_cnt, tax_total_cnt,
      tax_tax_type_cnt, tax_added_value_tax_times, tax_corp_tax_times, tax_credit_nation_freq_rate,
      tax_credit_local_freq_rate, tax_credit_recent_nation_rate, tax_credit_recent_local_rate = ""
      try {
        company_name = row._2._1.getAs[String]("company_name")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        company_id = row._2._1.getAs[String]("company_id")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        reg_number = row._2._1.getAs[String]("reg_number")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        credit_code = row._2._1.getAs[String]("credit_code")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }

      try {
        abnormal_put_cnt = row._2._1.getAs[Int]("abnormal_put_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        abnormal_put_reason_type_cnt = row._2._1.getAs[Int]("abnormal_put_reason_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        abnormal_most_put_reason_type = row._2._1.getAs[String]("abnormal_most_put_reason_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        abnormal_recent_yr_put_main_reason = row._2._1.getAs[String]("abnormal_recent_yr_put_main_reason")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        abnormal_put_remove_avg_duration = row._2._1.getAs[Float]("abnormal_put_remove_avg_duration").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        abnormal_put_remove_max_duration = row._2._1.getAs[Float]("abnormal_put_remove_max_duration").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        license_total_cnt = row._2._1.getAs[Int]("license_total_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        license_type_cnt = row._2._1.getAs[Int]("license_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        license_most_type = row._2._1.getAs[String]("license_most_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        license_valid_gt_1_yr_cnt = row._2._1.getAs[Float]("license_valid_gt_1_yr_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        dishonested_label = row._2._1.getAs[String]("dishonested_label")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        liquidation_label = row._2._1.getAs[String]("liquidation_label")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_total_cnt = row._2._1.getAs[Int]("punishment_total_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_type_cnt = row._2._1.getAs[Int]("punishment_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_most_type = row._2._1.getAs[String]("punishment_most_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_penalty_type_cnt = row._2._1.getAs[Int]("punishment_penalty_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_most_penalty_type = row._2._1.getAs[String]("punishment_most_penalty_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_recent_yr_total_cnt = row._2._1.getAs[Int]("punishment_recent_yr_total_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_recent_yr_total_type_cnt = row._2._1.getAs[Int]("punishment_recent_yr_total_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_recent_yr_most_type = row._2._1.getAs[String]("punishment_recent_yr_most_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_recent_yr_penalty_type_cnt = row._2._1.getAs[Int]("punishment_recent_yr_penalty_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        punishment_recent_yr_most_penalty_type = row._2._1.getAs[String]("punishment_recent_yr_most_penalty_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        zhixing_type = row._2._1.getAs[String]("zhixing_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        zhixing_total_cnt = row._2._1.getAs[Int]("zhixing_total_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        zhixing_recent_yr_cnt = row._2._1.getAs[Int]("zhixing_recent_yr_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        comp_change_chg_cnt = row._2._1.getAs[Int]("comp_change_chg_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        comp_change_chg_type_cnt = row._2._1.getAs[Int]("comp_change_chg_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        comp_change_most_chg_type = row._2._1.getAs[String]("comp_change_most_chg_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        comp_change_recent_yr_most_chg_type = row._2._1.getAs[String]("comp_change_recent_yr_most_chg_type")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        job_total_cnt = row._2._1.getAs[Int]("job_total_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        lawsuit_bg_cnt = row._2._1.getAs[Int]("lawsuit_bg_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_total_cnt = row._2._1.getAs[Int]("tax_total_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_tax_type_cnt = row._2._1.getAs[Int]("tax_tax_type_cnt").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_added_value_tax_times = row._2._1.getAs[Int]("tax_added_value_tax_times").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_corp_tax_times = row._2._1.getAs[Int]("tax_corp_tax_times").toString
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_credit_nation_freq_rate = row._2._1.getAs[String]("tax_credit_nation_freq_rate")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_credit_local_freq_rate = row._2._1.getAs[String]("tax_credit_local_freq_rate")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_credit_recent_nation_rate = row._2._1.getAs[String]("tax_credit_recent_nation_rate")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      try {
        tax_credit_recent_local_rate = row._2._1.getAs[String]("tax_credit_recent_local_rate")
      } catch {
        case e: Exception => logger.error(e.getMessage)
      }
      var phone_number, legal_person_name = ""

      try {
        phone_number = row._2._2.get.getAs[String]("phone_number")
        legal_person_name = row._2._2.get.getAs[String]("legal_person_name")
      } catch {
        case e: Exception => logger.error("未关联上")
      }
      A1(company_name, company_id,
        reg_number,
        credit_code,
        abnormal_put_cnt,
        abnormal_put_reason_type_cnt,
        abnormal_most_put_reason_type,
        abnormal_recent_yr_put_main_reason,
        abnormal_put_remove_avg_duration,
        abnormal_put_remove_max_duration,
        license_total_cnt,
        license_type_cnt,
        license_most_type,
        license_valid_gt_1_yr_cnt,
        dishonested_label,
        liquidation_label,
        punishment_total_cnt,
        punishment_type_cnt,
        punishment_most_type,
        punishment_penalty_type_cnt,
        punishment_most_penalty_type,
        punishment_recent_yr_total_cnt,
        punishment_recent_yr_total_type_cnt,
        punishment_recent_yr_most_type,
        punishment_recent_yr_penalty_type_cnt,
        punishment_recent_yr_most_penalty_type,
        zhixing_type,
        zhixing_total_cnt,
        zhixing_recent_yr_cnt,
        comp_change_chg_cnt,
        comp_change_chg_type_cnt,
        comp_change_most_chg_type,
        comp_change_recent_yr_most_chg_type,
        job_total_cnt,
        lawsuit_bg_cnt,
        tax_total_cnt,
        tax_tax_type_cnt,
        tax_added_value_tax_times,
        tax_corp_tax_times,
        tax_credit_nation_freq_rate,
        tax_credit_local_freq_rate,
        tax_credit_recent_nation_rate,
        tax_credit_recent_local_rate,
        phone_number,
        legal_person_name)
    }).toDF("company_name", "company_id", "reg_number", "credit_code", "abnormal_put_cnt", "abnormal_put_reason_type_cnt", "abnormal_most_put_reason_type", "abnormal_recent_yr_put_main_reason", "abnormal_put_remove_avg_duration", "abnormal_put_remove_max_duration", "license_total_cnt", "license_type_cnt", "license_most_type", "license_valid_gt_1_yr_cnt", "dishonested_label", "liquidation_label", "punishment_total_cnt", "punishment_type_cnt", "punishment_most_type", "punishment_penalty_type_cnt", "punishment_most_penalty_type", "punishment_recent_yr_total_cnt", "punishment_recent_yr_total_type_cnt", "punishment_recent_yr_most_type", "punishment_recent_yr_penalty_type_cnt", "punishment_recent_yr_most_penalty_type", "zhixing_type", "zhixing_total_cnt", "zhixing_recent_yr_cnt", "comp_change_chg_cnt", "comp_change_chg_type_cnt", "comp_change_most_chg_type", "comp_change_recent_yr_most_chg_type", "job_total_cnt", "lawsuit_bg_cnt", "tax_total_cnt", "tax_tax_type_cnt", "tax_added_value_tax_times", "tax_corp_tax_times", "tax_credit_nation_freq_rate", "tax_credit_local_freq_rate", "tax_credit_recent_nation_rate", "tax_credit_recent_local_rate", "phone_number", "legal_person_name")

    val encoder123 = Encoders.tuple(
      Encoders.STRING, RowEncoder(aaa123.schema))
    val as123 = aaa123.map(row => {
      val key = row.getAs[String]("company_name")
      (key, row)
    })(encoder123).rdd

    val am123: RDD[(String, (Row, Option[Row]))] = leftOuterJoinKeyS(as123, aa4, 10, 20)
    val res_df = am123.map(row => {
      val company_name = row._2._1.getAs[String]("company_name")
      val company_id = row._2._1.getAs[String]("company_id")
      val reg_number = row._2._1.getAs[String]("reg_number")
      val credit_code = row._2._1.getAs[String]("credit_code")
      val abnormal_put_cnt = row._2._1.getAs[String]("abnormal_put_cnt")
      val abnormal_put_reason_type_cnt = row._2._1.getAs[String]("abnormal_put_reason_type_cnt")
      val abnormal_most_put_reason_type = row._2._1.getAs[String]("abnormal_most_put_reason_type")
      val abnormal_recent_yr_put_main_reason = row._2._1.getAs[String]("abnormal_recent_yr_put_main_reason")
      val abnormal_put_remove_avg_duration = row._2._1.getAs[String]("abnormal_put_remove_avg_duration")
      val abnormal_put_remove_max_duration = row._2._1.getAs[String]("abnormal_put_remove_max_duration")
      val license_total_cnt = row._2._1.getAs[String]("license_total_cnt")
      val license_type_cnt = row._2._1.getAs[String]("license_type_cnt")
      val license_most_type = row._2._1.getAs[String]("license_most_type")
      val license_valid_gt_1_yr_cnt = row._2._1.getAs[String]("license_valid_gt_1_yr_cnt")
      val dishonested_label = row._2._1.getAs[String]("dishonested_label")
      val liquidation_label = row._2._1.getAs[String]("liquidation_label")
      val punishment_total_cnt = row._2._1.getAs[String]("punishment_total_cnt")
      val punishment_type_cnt = row._2._1.getAs[String]("punishment_type_cnt")
      val punishment_most_type = row._2._1.getAs[String]("punishment_most_type")
      val punishment_penalty_type_cnt = row._2._1.getAs[String]("punishment_penalty_type_cnt")
      val punishment_most_penalty_type = row._2._1.getAs[String]("punishment_most_penalty_type")
      val punishment_recent_yr_total_cnt = row._2._1.getAs[String]("punishment_recent_yr_total_cnt")
      val punishment_recent_yr_total_type_cnt = row._2._1.getAs[String]("punishment_recent_yr_total_type_cnt")
      val punishment_recent_yr_most_type = row._2._1.getAs[String]("punishment_recent_yr_most_type")
      val punishment_recent_yr_penalty_type_cnt = row._2._1.getAs[String]("punishment_recent_yr_penalty_type_cnt")
      val punishment_recent_yr_most_penalty_type = row._2._1.getAs[String]("punishment_recent_yr_most_penalty_type")
      val zhixing_type = row._2._1.getAs[String]("zhixing_type")
      val zhixing_total_cnt = row._2._1.getAs[String]("zhixing_total_cnt")
      val zhixing_recent_yr_cnt = row._2._1.getAs[String]("zhixing_recent_yr_cnt")
      val comp_change_chg_cnt = row._2._1.getAs[String]("comp_change_chg_cnt")
      val comp_change_chg_type_cnt = row._2._1.getAs[String]("comp_change_chg_type_cnt")
      val comp_change_most_chg_type = row._2._1.getAs[String]("comp_change_most_chg_type")
      val comp_change_recent_yr_most_chg_type = row._2._1.getAs[String]("comp_change_recent_yr_most_chg_type")
      val job_total_cnt = row._2._1.getAs[String]("job_total_cnt")
      val lawsuit_bg_cnt = row._2._1.getAs[String]("lawsuit_bg_cnt")
      val tax_total_cnt = row._2._1.getAs[String]("tax_total_cnt")
      val tax_tax_type_cnt = row._2._1.getAs[String]("tax_tax_type_cnt")
      val tax_added_value_tax_times = row._2._1.getAs[String]("tax_added_value_tax_times")
      val tax_corp_tax_times = row._2._1.getAs[String]("tax_corp_tax_times")
      val tax_credit_nation_freq_rate = row._2._1.getAs[String]("tax_credit_nation_freq_rate")
      val tax_credit_local_freq_rate = row._2._1.getAs[String]("tax_credit_local_freq_rate")
      val tax_credit_recent_nation_rate = row._2._1.getAs[String]("tax_credit_recent_nation_rate")
      val tax_credit_recent_local_rate = row._2._1.getAs[String]("tax_credit_recent_local_rate")
      val phone_number = row._2._1.getAs[String]("phone_number")
      val legal_person_name = row._2._1.getAs[String]("legal_person_name")
      var reg_location, company_org_type_new, business_scope, cate_1, cate_2, cate_3, legal_person_type = ""
      try {
        reg_location = row._2._2.get.getAs[String]("reg_location")
        company_org_type_new = row._2._2.get.getAs[String]("company_org_type_new")
        business_scope = row._2._2.get.getAs[String]("business_scope")
        cate_1 = row._2._2.get.getAs[String]("cate_1")
        cate_2 = row._2._2.get.getAs[String]("cate_2")
        cate_3 = row._2._2.get.getAs[String]("cate_3")
        legal_person_type = row._2._2.get.getAs[String]("legal_person_type")
      } catch {
        case e: Exception => logger.error("未关联上")
      }
      A2(company_name, company_id,
        reg_number,
        credit_code,
        abnormal_put_cnt,
        abnormal_put_reason_type_cnt,
        abnormal_most_put_reason_type,
        abnormal_recent_yr_put_main_reason,
        abnormal_put_remove_avg_duration,
        abnormal_put_remove_max_duration,
        license_total_cnt,
        license_type_cnt,
        license_most_type,
        license_valid_gt_1_yr_cnt,
        dishonested_label,
        liquidation_label,
        punishment_total_cnt,
        punishment_type_cnt,
        punishment_most_type,
        punishment_penalty_type_cnt,
        punishment_most_penalty_type,
        punishment_recent_yr_total_cnt,
        punishment_recent_yr_total_type_cnt,
        punishment_recent_yr_most_type,
        punishment_recent_yr_penalty_type_cnt,
        punishment_recent_yr_most_penalty_type,
        zhixing_type,
        zhixing_total_cnt,
        zhixing_recent_yr_cnt,
        comp_change_chg_cnt,
        comp_change_chg_type_cnt,
        comp_change_most_chg_type,
        comp_change_recent_yr_most_chg_type,
        job_total_cnt,
        lawsuit_bg_cnt,
        tax_total_cnt,
        tax_tax_type_cnt,
        tax_added_value_tax_times,
        tax_corp_tax_times,
        tax_credit_nation_freq_rate,
        tax_credit_local_freq_rate,
        tax_credit_recent_nation_rate,
        tax_credit_recent_local_rate,
        phone_number,
        legal_person_name, reg_location, company_org_type_new, business_scope, cate_1, cate_2, cate_3, legal_person_type)
    }).toDF("company_name", "company_id", "reg_number", "credit_code", "abnormal_put_cnt", "abnormal_put_reason_type_cnt", "abnormal_most_put_reason_type", "abnormal_recent_yr_put_main_reason", "abnormal_put_remove_avg_duration", "abnormal_put_remove_max_duration", "license_total_cnt", "license_type_cnt", "license_most_type", "license_valid_gt_1_yr_cnt", "dishonested_label", "liquidation_label", "punishment_total_cnt", "punishment_type_cnt", "punishment_most_type", "punishment_penalty_type_cnt", "punishment_most_penalty_type", "punishment_recent_yr_total_cnt", "punishment_recent_yr_total_type_cnt", "punishment_recent_yr_most_type", "punishment_recent_yr_penalty_type_cnt", "punishment_recent_yr_most_penalty_type", "zhixing_type", "zhixing_total_cnt", "zhixing_recent_yr_cnt", "comp_change_chg_cnt", "comp_change_chg_type_cnt", "comp_change_most_chg_type", "comp_change_recent_yr_most_chg_type", "job_total_cnt", "lawsuit_bg_cnt", "tax_total_cnt", "tax_tax_type_cnt", "tax_added_value_tax_times", "tax_corp_tax_times", "tax_credit_nation_freq_rate", "tax_credit_local_freq_rate", "tax_credit_recent_nation_rate",
      "tax_credit_recent_local_rate", "phone_number", "legal_person_name", "reg_location", "company_org_type_new", "business_scope", "cate_1", "cate_2", "cate_3", "legal_person_type")
      .select(res_cols: _*)
    writeToHiveNoPS(spark, res_df, "vehicle_company_info22")

  }


  def leftOuterJoinKeyS(left: RDD[(String, Row)], right: RDD[(String, Row)], hashNum: Int, topLean: Int = 10): RDD[(String, (Row, Option[Row]))] = {
    val keyCounts = left.map(obj => (obj._1, 1)).reduceByKey(_ + _).sortBy(-_._2).take(topLean)
    val keys: Array[String] = keyCounts.map(obj => obj._1)

    val counts = keyCounts.map(obj => obj._2).sum
    logger.error("单独处理的keys:" + keyCounts.mkString(","))
    logger.error("单独处理的总数量:" + counts)
    //拆分数据为独立处理的key和非独立处理的key
    val leftHashKeyData = left.filter(obj => keys.contains(obj._1))
    val leftOtherData = left.filter(obj => !keys.contains(obj._1))
    val rightHashKeyData = right.filter(obj => keys.contains(obj._1))
    val rightOtherData = right.filter(obj => !keys.contains(obj._1))
    //先关联其他key数据
    //    val otherJoin: RDD[(String, (Row, Option[Row]))] = leftOtherData.leftOuterJoin(rightOtherData)//leftOuterJoin
    val otherJoin: RDD[(String, (Row, Option[Row]))] = leftOtherData.leftOuterJoin(rightOtherData) //leftOuterJoin
    //扩展单独处理的数据
    val leftHashKeyDataExpand: RDD[((Int, String), Row)] = leftHashKeyData.map(obj => {
      val hashPrefix = new Random().nextInt(hashNum)
      ((hashPrefix, obj._1), obj._2)
    })

    val rightHashKeyDataExpand: RDD[((Int, String), Row)] = rightHashKeyData.flatMap(obj => {
      val dataArray = new ArrayBuffer[((Int, String), Row)]()
      for (i <- 0 until hashNum) {
        dataArray.append(((i, obj._1), obj._2))
      }
      dataArray.iterator
    })
    //关联数据
    val hashKeyJoin: RDD[(String, (Row, Option[Row]))] = leftHashKeyDataExpand.leftOuterJoin(rightHashKeyDataExpand).map(obj => (obj._1._2, obj._2))

    hashKeyJoin.union(otherJoin)
  }


  def processOther(spark: SparkSession): Unit = {
    val res_cols = spark.sql("""select * from default.vehicle_company_info22 limit 0""").schema.map(x => col(x.name))
    val df = spark.sql(
      """select
        |  yp.phone_number,
        |  yp.legal_person_name,
        |  p.company_name as company_name,
        |  bs.reg_location,
        |  bs.company_org_type_new,
        |  bs.business_scope,
        |  bs.cate_1,
        |  bs.cate_2,
        |  bs.cate_3,
        |  bs.legal_person_type,
        |  p.company_id,
        |  p.reg_number,
        |  p.credit_code,
        |  p.abnormal_put_cnt,
        |  p.abnormal_put_reason_type_cnt,
        |  p.abnormal_most_put_reason_type,
        |  p.abnormal_recent_yr_put_main_reason,
        |  p.abnormal_put_remove_avg_duration,
        |  p.abnormal_put_remove_max_duration,
        |  p.license_total_cnt,
        |  p.license_type_cnt,
        |  p.license_most_type,
        |  p.license_valid_gt_1_yr_cnt,
        |  p.dishonested_label,
        |  p.liquidation_label,
        |  p.punishment_total_cnt,
        |  p.punishment_type_cnt,
        |  p.punishment_most_type,
        |  p.punishment_penalty_type_cnt,
        |  p.punishment_most_penalty_type,
        |  p.punishment_recent_yr_total_cnt,
        |  p.punishment_recent_yr_total_type_cnt,
        |  p.punishment_recent_yr_most_type,
        |  p.punishment_recent_yr_penalty_type_cnt,
        |  p.punishment_recent_yr_most_penalty_type,
        |  p.zhixing_type,
        |  p.zhixing_total_cnt,
        |  p.zhixing_recent_yr_cnt,
        |  p.comp_change_chg_cnt,
        |  p.comp_change_chg_type_cnt,
        |  p.comp_change_most_chg_type,
        |  p.comp_change_recent_yr_most_chg_type,
        |  p.job_total_cnt,
        |  p.lawsuit_bg_cnt,
        |  p.tax_total_cnt,
        |  p.tax_tax_type_cnt,
        |  p.tax_added_value_tax_times,
        |  p.tax_corp_tax_times,
        |  p.tax_credit_nation_freq_rate,
        |  p.tax_credit_local_freq_rate,
        |  p.tax_credit_recent_nation_rate,
        |  p.tax_credit_recent_local_rate
        |from
        |  (
        |    select
        |      comp_name as company_name,
        |      company_id,
        |      reg_number,
        |      credit_code,
        |      abnormal_put_cnt,
        |      abnormal_put_reason_type_cnt,
        |      abnormal_most_put_reason_type,
        |      abnormal_recent_yr_put_main_reason,
        |      abnormal_put_remove_avg_duration,
        |      abnormal_put_remove_max_duration,
        |      license_total_cnt,
        |      license_type_cnt,
        |      license_most_type,
        |      license_valid_gt_1_yr_cnt,
        |      dishonested_label,
        |      liquidation_label,
        |      punishment_total_cnt,
        |      punishment_type_cnt,
        |      punishment_most_type,
        |      punishment_penalty_type_cnt,
        |      punishment_most_penalty_type,
        |      punishment_recent_yr_total_cnt,
        |      punishment_recent_yr_total_type_cnt,
        |      punishment_recent_yr_most_type,
        |      punishment_recent_yr_penalty_type_cnt,
        |      punishment_recent_yr_most_penalty_type,
        |      zhixing_type,
        |      zhixing_total_cnt,
        |      zhixing_recent_yr_cnt,
        |      comp_change_chg_cnt,
        |      comp_change_chg_type_cnt,
        |      comp_change_most_chg_type,
        |      comp_change_recent_yr_most_chg_type,
        |      job_total_cnt,
        |      lawsuit_bg_cnt,
        |      tax_total_cnt,
        |      tax_tax_type_cnt,
        |      tax_added_value_tax_times,
        |      tax_corp_tax_times,
        |      tax_credit_nation_freq_rate,
        |      tax_credit_local_freq_rate,
        |      tax_credit_recent_nation_rate,
        |      tax_credit_recent_local_rate
        |    from
        |      dm_gis_edt.tyc_merged_profile_base pr,
        |      default.vehicle_company2 vc
        |    where
        |      pr.inc_day = 20221101
        |      and pr.comp_name = vc.owner_name
        |  ) p
        |  left join (
        |    select
        |      company_name,
        |      phone_number,
        |      legal_person_name
        |    from
        |      dm_gis_edt.annual_report_info_filtered
        |    where
        |      inc_day = 20221001
        |  ) yp on p.company_name = yp.company_name
        |  left join (
        |    select
        |      name as company_name,
        |      reg_location,
        |      company_org_type_new,
        |      business_scope,
        |      cate_1,
        |      cate_2,
        |      cate_3,
        |      legal_person_type
        |    from
        |      dm_gis_edt.company_basic_info_clean
        |    where
        |      inc_day = 20221101
        |  ) bs on p.company_name = bs.company_name""".stripMargin)
      .select(res_cols: _*)
    writeToHiveNoPS(spark, df, "vehicle_company_info22")

  }

  def writeToHiveNoPS(spark: SparkSession, dataframe: DataFrame, resTableName: String): Unit = {
    dataframe.createOrReplaceTempView("tmpTableName")
    val sql = String.format(s"insert into %s select * from %s", resTableName, "tmpTableName")
    logger.error(sql)
    spark.sql("use default")
    spark.sql(s"truncate table default.$resTableName")
    spark.sql(sql)
    spark.catalog.dropTempView("tmpTableName")
  }

  def processaa(spark: SparkSession): Unit = {
    val as = spark.sql(
      """SELECT
        |*
        |from
        |dm_gis.dwd_insurance_model_duration_dist_year_feature_dtl
        |where
        |months_flag = '12' and inc_day = '20221031'""".stripMargin)

    val lpn_df = spark.sql("""select lpn from dm_gis.lpn""")

    val df = as.join(broadcast(lpn_df), Seq("lpn")).select(as.schema.map(x => col(x.name)): _*)
    writeToHive(spark, df, Seq("inc_day", "months_flag"), "dm_gis.dwd_insurance_model_duration_dist_year_feature_dtl_tmp2")
  }

  def loadData(spark: SparkSession, inpath: String, tableName: String): Unit = {
    val inputPath = "/user/01418539/upload/file/" + inpath

    val res_cols = spark.sql(s"select * from dm_gis.$tableName limit 0").schema.map(_.name).map(col)
    val o_monitor = spark.read
      .option("header", "true")
      .option("delimiter", "\t")
      //.option("encoding", "gbk") //utf-8
      .option("encoding", "utf-8") //utf-8
      .option("inferSchema", true.toString)
      .csv(inputPath)

    writeToHiveNoP(spark, o_monitor.select(res_cols: _*), tableName)
  }
}
