package com.sf.rls


import com.sf.common.DataSourceCommon
import utils.SparkBuilder

/**
 * @description: sparkSQL查询hivesql语句
 * @author 01418539 caojia
 * @date 2022年03月11日 9:36
 */
object QuerySQL extends DataSourceCommon{
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val sql = args(0)
    val num = args(1)

    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |     sql:sql查询语句
          |     num:展示条数
          |""".stripMargin)
      sys.exit(2)
    }
    logger.error(s"2个参数//-param1为起始时间:$sql，条数:$num")

    val querysql = s"""$sql""".stripMargin
    println("传入的sql为："+querysql)

    val sqlDf = spark.sql(querysql)

    sqlDf.limit(num.toInt).collect().foreach(println(_))

    sqlDf.show(num.toInt)

    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

}
