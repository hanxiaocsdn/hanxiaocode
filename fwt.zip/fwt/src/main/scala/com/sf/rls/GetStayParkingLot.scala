package com.sf.rls

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.DataSourceCommon
import constant.HttpConstant.HTPP_CLOUD_X_Y_G
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel.MEMORY_AND_DISK_SER
import utils.HttpClientUtil.getJsonParam
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @description: 445159(已下线2022年)根据停留点信息获取 停车点信息
 * @author 01418539 caojia
 * @date 2022/6/2 15:06
 */
object GetStayParkingLot extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    processParkingLot(spark, inc_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processParkingLot(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._

    val o_alarm_rule = spark.sql(
      s"""select
         |*
         |from
         |dm_gis.grd_new_stay_info_alarm_rule
         |where inc_day ='$inc_day'
         |""".stripMargin)
      .na.fill("", Seq("startlon", "startlat"))
      .persist(MEMORY_AND_DISK_SER)

    val s_lon_lat = o_alarm_rule.select("startlon", "startlat").filter(trim('startlon) =!= "" && trim('startlat) =!= "")
      .withColumn("num", row_number().over(Window.partitionBy("startlon", "startlat").orderBy("startlon")))
      .filter('num === 1)
      .map(row => {
        val startlon = row.getAs[String]("startlon")
        val startlat = row.getAs[String]("startlat")

        var getUrlRes = ""
        var parking_idx = ""
        var points_in_area = ""
        try {
          val urlParam = getJsonParam(HTPP_CLOUD_X_Y_G, startlon, startlat)
          getUrlRes = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 3)
          logger.error("返回的停车点信息为：" + getUrlRes)
          val response_str: JSONObject = JSON.parseObject(getUrlRes)
          val json_pub = response_str.getJSONObject("result")

          parking_idx = json_pub.getString("parking_idx")
          points_in_area = json_pub.getString("points_in_area")

        } catch {
          case e: Exception => logger.error(s"$startlon == $startlat 经纬度 调取接口返回有异常" + e.getMessage)
        }
        (startlon, startlat, parking_idx, points_in_area)

      }).toDF("startlon", "startlat", "parking_idx", "points_in_area")

    val parkres = o_alarm_rule.join(broadcast(s_lon_lat), Seq("startlon", "startlat"), "left")
      .select(
        "vehicle_serial",
        "startindex",
        "endindex",
        "starttime",
        "endtime",
        "duration",
        "roadclass_x",
        "navi_addr",
        "business",
        "sub_type",
        "alarm_time",
        "time_gap",
        "startlon",
        "startlat",
        "task_area_code",
        "driver_id",
        "rule",
        "parking_idx",
        "points_in_area",
        "inc_day"
      )
    writeToHive(spark, parkres, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule_park")
    o_alarm_rule.unpersist()
  }
}
