package com.sf.rls

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.ColumnUtil.lngLatToDistance
import utils.DateUtil.getdaysBeforeOrAfter
import utils.SparkBuilder

/**
 * @description: 457443 GIS-LSS-MMS：顺陆_导航_标准线路表合并汇总_V1.2
 * @author 01413698
 * @date 2022年03月10日 18:37
 * 任务ID：457443
 */
object HyGisNavicationDetailApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark: SparkSession = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day: String = args(0)
    val start_day: String = getdaysBeforeOrAfter(inc_day,-3)
    val end_day: String = getdaysBeforeOrAfter(inc_day,2)

    logger.error(s"inc_day:$inc_day//-param1为起始时间:$start_day,param2为结束时间:$end_day")
    processMultiJoin(spark, inc_day,start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processMultiJoin(spark: SparkSession, inc_day: String,start_day: String, end_day: String): Unit = {
    import spark.implicits._
    //t1 导航SDK,top3请求的入参表
    val t1 = spark.sql(
      s"""
         |select task_id
         |,if(task_id is not null,1,0) as is_sdk
         |	         ,navi_id--导航id
         |			 ,(case when substr(navi_id,-1) ='0' then 'Android'
         |			        when substr(navi_id,-1) ='1' then 'ios'
         |					else null end) as system
         |             ,request_id
         |             ,startx  as top3_startx
         |             ,starty  as top3_starty
         |             ,endx  as top3_endx
         |             ,endy  as top3_endy
         |             ,line_code  as top3_line_code
         |             ,src_deptcode  as top3_src_deptcode
         |             ,dest_deptcode  as top3_dest_deptcode
         |             ,vehicle_type  as top3_vehicle_type
         |             ,Service_Id
         |             ,ak
         |             ,req_Time as reqTime
         |             ,opt
         |             ,econ_id as StdId
         |			 ,inc_day
         |       from dm_gis.gis_navi_top3_parse  --导航SDK,top3请求的入参表
         |	   where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .persist()

    //t2 grd任务明细表  主表
    val t2 = spark.sql(
      s"""
         |select task_id
         |            ,task_area_code
         |            ,line_code
         |            ,require_category
         |            ,line_require_type
         |            ,vehicle_serial --车牌号码
         |            ,src_zone_code
         |            ,dest_zone_code
         |            ,actual_capacity_load
         |            ,plan_depart_tm
         |            ,actual_depart_tm
         |            ,plan_arrive_tm
         |            ,actual_arrive_tm
         |            ,driver_id
         |            ,is_stop
         |            ,plan_run_time
         |            ,actual_run_time
         |            ,src_longitude
         |            ,src_latitude
         |            ,dest_longitude
         |            ,dest_latitude
         |            ,driver_type
         |			,carrier_name--20211214新增1/2
         |			,carrier_type--20211214新增2/2
         |            ,gis_distance
         |            ,is_run_ontime
         |			,inc_day
         |	  from dm_grd.grd_new_task_detail --grd任务明细表
         |	  where inc_day='$inc_day' and state = 6
         |""".stripMargin)
      .persist()

    //t3//t3 轨迹有效情况
    val t3 = spark.sql(
      s"""
         |select task_id
         |	        ,halfway_integrate_rate
         |            ,validity_vehicle
         |            ,validity_phone
         |            ,is_halfway_integrate
         |			,inc_day
         |	  from dm_tdsp.rpt_grd_task_monitor_re_dtl_di --轨迹有效情况
         |	  where inc_day>='$start_day' and inc_day<='$end_day' and state = '已完成'
         |""".stripMargin)
      .persist()

    //t4 导航结果表_1
    val t4 = spark.sql(
      s"""
         |select id
         |	        ,duration
         |            ,src
         |			,navi_id--导航id
         |            ,distance
         |            ,navi_starttime
         |            ,navi_endtime
         |            ,navi_time--导航用时（秒）
         |			,min(navi_starttime) over(partition by task_id,inc_day) as first_navi_tm
         |			,sum(cast(navi_time as double)) over(partition by task_id,inc_day) as task_time
         |			,inc_day
         |from dm_gis.gis_navi_eta_result1 --导航结果表_1
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |      and req_type = 'top3'
         |      and distance >= 1000
         |      and navi_endtime is not null
         |""".stripMargin)
      .persist()

    //t5 导航结果表_2
    val t5 = spark.sql(
      s"""
         |select id
         |	        ,navi_id--导航id
         |	        ,navi_distance
         |            ,trackstart_distance
         |            ,trackend_distance
         |            ,similarity1
         |            ,similarity5
         |            ,if(similarity1 >= similarity5,similarity1,similarity5) as similarity15
         |			,inc_day
         |	  from dm_gis.gis_navi_eta_result2 --导航结果表_2
         |	  where inc_day>='$start_day' and inc_day<='$end_day' and req_type = 'top3'
         |""".stripMargin)
      .persist()

    //t6 导航偏航结果解析表
    val t6 = spark.sql(
      s"""
         |select strategy
         |	        ,request_id
         |	        ,src as parse_src
         |			,inc_day
         |	  from dm_gis.gis_navi_top3_yaw_result_parse
         |	  where inc_day>='$start_day' and inc_day<='$end_day'
         |	        and subType = 'naviTop3V2LogResult'
         |	        and route_index='0' --string类型
         |""".stripMargin)
      .persist()

    //t7 标准线路任务（拆经停）
    val t7 = spark.sql(
      s"""
         |select task_id
         |	        ,src as recall_src
         |            ,actual_run_time as recall_actual_run_time
         |            ,line_distance as recall_line_distance
         |            ,start_type
         |            ,end_type
         |            ,log_dist as  recall_log_dist
         |            ,rt_dist  as recall_rt_dist
         |            ,start_dept as recall_start_dept
         |            ,end_dept  as recall_end_dept
         |            ,conduct_type  as   recall_conduct_type
         |			,inc_day
         |	  from dm_gis.eta_std_line_recall --标准线路任务（拆经停）
         |	  where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .persist()

    //t8 标准线路任务（不拆经停）
    val t8 = spark.sql(
      s"""
         |select task_id
         |	        ,src as recall1_src
         |         ,if(task_id is not null,1,0)as is_std
         |            ,line_code as recall1_line_code
         |            ,vehicle_type as recall1_vehicle_type
         |            ,conduct_type as recall1_conduct_type
         |			,inc_day
         |	  from dm_gis.eta_std_line_recall1--标准线路任务（不拆经停）
         |	  where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
      .persist()

    //t9 车参表
    val t9 = spark.sql(
      s"""
         |select  vehicle--车牌（大陆车牌号）
         |	        ,hko_vehicle_code--港/澳车牌号
         |            ,trailer_vehicle_code
         |            ,length
         |            ,outer_length
         |            ,outer_width
         |            ,outer_height
         |            ,inner_length
         |            ,inner_width
         |            ,inner_height
         |            ,axis
         |            ,weight
         |            ,load_weight
         |            ,full_load_weight
         |            ,color
         |            ,energy
         |            ,license
         |            ,emission
         |            ,is_trailer
         |            ,vehicle_type_ground
         |            ,source
         |            ,vehicle_type
         |            ,vehicle_length
         |            ,vehicle_full_load_weight
         |			,inc_day
         |	  from
         |	  (select *,row_number() over (partition by vehicle,hko_vehicle_code,inc_day order by length desc) num
         |	  from dm_gis.gis_tm_vehicle --车参表
         |      where inc_day>='$start_day' and inc_day<='$end_day' and vehicle is not null and trim(vehicle) !='') t90
         |	  where num= 1
         |""".stripMargin)
      .persist()

    //t10
    val content_flag = "$"
    val t101 = spark.sql(
      s"""
         |select type
         |     ,task_id
         |     ,if(navi_id is not null,1,0) as is_navi
         |	    ,navi_id
         |      ,navi_type
         |	    ,navi_strategy
         |	    ,sdk_ver
         |	    ,report_time--日志时间
         |	    ,(case when type='9' then 'gd_SDK'
         |		       when type='1' and navi_type='sf' then 'sf_SDK'
         |			   when type='1' and navi_type='gd' then 'gd_APP'
         |			   when type='1' and navi_type='gdwl' then 'gdwl_SDK'
         |			   else null end) as sdk_navi_type
         |      ,pull_navitype as pull_navi_type
         |			,inc_day
         |from dm_gis.gis_navi_sdk_navi_parse --客户端日志记录表
         |where inc_day>='$start_day' and inc_day<='$end_day' and type in ('1','9')
         |""".stripMargin)
      .filter('task_id.isNotNull && trim('task_id) =!= "")
      .withColumn("num", row_number().over(Window.partitionBy('task_id, 'inc_day).orderBy('report_time.asc)))
      .withColumn("first_navi_type", when('num === 1, 'navi_type).otherwise(null))
      .withColumn("navi_type", when('navi_type.isNotNull && trim('navi_type) =!= "", 'navi_type).otherwise(null))
      .withColumn("sdk_navi_type", when('sdk_navi_type.isNotNull && trim('sdk_navi_type) =!= "", 'sdk_navi_type).otherwise(null))
      .persist()

    val t102 = t101
      .groupBy('task_id, 'inc_day)
      .agg(
        concat_ws("|", collect_set('navi_type)) as "task_navi_type", //任务使用导航类型 （sf，gd，sf|gd）
        concat_ws("|", collect_set('sdk_navi_type)) as "task_sdk_navi_type" //任务使用导航SDK类型
      )
      .persist()

    val t10 = t101.join(t102, Seq("task_id", "inc_day"), "left")
      .select(
        'type,
        'is_navi,
        'task_id,
        'navi_id,
        'navi_type,
        'navi_strategy,
        'sdk_ver,
        'sdk_navi_type,
        'first_navi_type,
        'task_navi_type,
        'task_sdk_navi_type,
        'pull_navi_type,
        'inc_day
      )
      .persist()


    //10表关联
    val joinAllRes = t2.alias("t2")
      .join(t9.alias("t9"), expr("t2.vehicle_serial=t9.vehicle"), "left")
      .join(t3.alias("t3"), expr("t2.task_id=t3.task_id"), "left")
      .join(t8.alias("t8"), expr("t2.task_id=t8.task_id"), "left")
      .join(t7.alias("t7"), expr("t8.task_id=t7.task_id"), "left")
      .join(t1.alias("t1"), expr("t2.task_id=t1.task_id"), "left")
      .join(t4.alias("t4"), expr("t1.navi_id=t4.navi_id"), "left")
      .join(t5.alias("t5"), expr("t4.id=t5.id and t5.navi_id=t1.navi_id"), "left")
      .join(t10.alias("t10"), expr("t1.navi_id=t10.navi_id"), "left")
      .join(t6.alias("t6"), expr("t6.request_id=t1.request_id"), "left")
      .withColumn("endsrc_dist", round(lngLatToDistance(t1.col("top3_endx"), t1.col("top3_endy"), t2.col("src_longitude"), t2.col("src_latitude")), 2))
      .withColumn("startsrc_dist", round(lngLatToDistance(t1.col("top3_startx"), t1.col("top3_starty"), t2.col("src_longitude"), t2.col("src_latitude")), 2))
      .select(
        t2.col("task_area_code")
        , t2.col("task_id")
        , t2.col("line_code")
        , t2.col("require_category")
        , t2.col("line_require_type")
        , t2.col("vehicle_serial")
        , t2.col("src_zone_code")
        , t2.col("dest_zone_code")
        , t2.col("actual_capacity_load")
        , t2.col("plan_depart_tm")
        , t2.col("actual_depart_tm")
        , t2.col("plan_arrive_tm")
        , t2.col("actual_arrive_tm")
        , t2.col("driver_id")
        , t2.col("is_stop")
        , t2.col("plan_run_time")
        , t2.col("actual_run_time")
        , t2.col("src_longitude")
        , t2.col("src_latitude")
        , t2.col("dest_longitude")
        , t2.col("dest_latitude")
        , t2.col("driver_type")
        , t2.col("carrier_name") //20211214新增1/2
        , t2.col("carrier_type") //20211214新增2/2
        , t2.col("gis_distance")
        , t2.col("is_run_ontime")
        , t9.col("hko_vehicle_code")
        , t9.col("trailer_vehicle_code")
        , t9.col("length")
        , t9.col("outer_length")
        , t9.col("outer_width")
        , t9.col("outer_height")
        , t9.col("inner_length")
        , t9.col("inner_width")
        , t9.col("inner_height")
        , t9.col("axis")
        , t9.col("weight")
        , t9.col("load_weight")
        , t9.col("full_load_weight")
        , t9.col("color")
        , t9.col("energy")
        , t9.col("license")
        , t9.col("emission")
        , t9.col("is_trailer")
        , t9.col("vehicle_type_ground")
        , t9.col("source")
        , t9.col("vehicle_type")
        , t9.col("vehicle_length")
        , t9.col("vehicle_full_load_weight")
        , t3.col("halfway_integrate_rate")
        , t3.col("validity_vehicle")
        , t3.col("validity_phone")
        , t3.col("is_halfway_integrate")
        , t8.col("is_std")
        , t8.col("recall1_src")
        , t8.col("recall1_line_code")
        , t8.col("recall1_vehicle_type")
        , t8.col("recall1_conduct_type")
        , t7.col("recall_src")
        , t7.col("recall_actual_run_time")
        , t7.col("recall_line_distance")
        , t7.col("start_type")
        , t7.col("end_type")
        , t7.col("recall_log_dist")
        , t7.col("recall_rt_dist")
        , t7.col("recall_start_dept")
        , t7.col("recall_end_dept")
        , t7.col("recall_conduct_type")
        , t1.col("is_sdk")
        , t1.col("navi_id")
        , t1.col("system") //使用系统
        , t1.col("request_id")
        , t1.col("top3_startx")
        , t1.col("top3_starty")
        , t1.col("top3_endx")
        , t1.col("top3_endy")
        , t1.col("top3_line_code")
        , t1.col("top3_src_deptcode")
        , t1.col("top3_dest_deptcode")
        , t1.col("top3_vehicle_type")
        , t1.col("Service_Id")
        , t1.col("ak")
        , t1.col("reqTime")
        , t1.col("opt")
        , t1.col("StdId")
        , t4.col("duration")
        , t4.col("src")
        , t4.col("distance")
        , t4.col("navi_starttime")
        , t4.col("navi_endtime")
        , t4.col("navi_time")
        , t4.col("first_navi_tm") //第一次使用导航时间,计算得到
        , t4.col("task_time") //任务使用导航时长,计算得到
        , t5.col("navi_distance")
        , t5.col("trackstart_distance")
        , t5.col("trackend_distance")
        , t5.col("similarity1") //新增以下6个字段
        , t5.col("similarity5")
        , t5.col("similarity15")
        , t10.col("type")
        , t10.col("is_navi")
        , t10.col("navi_type")
        , t10.col("navi_strategy")
        , t10.col("sdk_ver")
        , t10.col("sdk_navi_type") //导航SDK类型,表内转换得到
        , t10.col("first_navi_type") //第一次使用导航类型，计算得到
        , t10.col("task_navi_type") //任务使用导航类型 （sf，gd，sf|gd），计算得到
        , t10.col("task_sdk_navi_type") //任务使用导航类型 （sf，gd，sf|gd），计算得到
        , t6.col("strategy")
        , t6.col("parse_src")
        , col("endsrc_dist")
        , col("startsrc_dist")
        , t10.col("pull_navi_type")
        , t2.col("inc_day") as "inc_day"
      )
      .withColumn("inc_day",lit(inc_day))
      .persist()


    val cnt: Long = joinAllRes.count()
    logger.error(s"最终的数据总量：$cnt 条")
    logger.error(s"最终的样例数据：")
    joinAllRes.show(3,truncate = true)

    val table:String="dm_gis.dwd_gis_navi_detail_daily"
    logger.error(s"开始写入到 Hive：$table")
    joinAllRes
      .write
      .mode(SaveMode.Overwrite)
      .insertInto(table)
    logger.error(s"写入 $table 成功！")

  }

}
