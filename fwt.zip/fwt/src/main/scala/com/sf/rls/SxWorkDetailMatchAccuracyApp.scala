package com.sf.rls

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.DataSourceCommon
import constant.HttpConstant
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.HttpClientUtil.getJsonParam
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @description: GIS-ASS-EDS：测算顺心审补库主体词拼接匹配的贡献度和准确率
 * @author 01418539 caojia
 * @date 2022年03月01日 18:03
 */
object SxWorkDetailMatchAccuracyApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val inc_day = args(0)
    if (args.length != 1) {
      logger.error(
        """
          |需要输入1个参数：
          |     inc_day:数据日期
          |""".stripMargin)
      sys.exit(2)
    }
    logger.error(s"1个参数---param1为数据日期:$inc_day")

    processLoadSXData(spark, inc_day)

  }

  def processLoadSXData(spark: SparkSession, inc_day: String): Unit = {
    import spark.implicits._
    //1 审补数据
    val auditDf = spark.sql(
      s"""
         |select check_address,
         |       check_x,
         |       check_y,
         |       inc_day
         |from dm_gis.sx_work_detail_his
         |  where inc_day ='$inc_day'
         |  and del_flag = '0'
         |  and kafka_state = '1'
         |""".stripMargin)

    //2 工单数据
    val waybillSql =
      """
        |select
        |  get_json_object(detail,'$.ewb_no') ewb_no,--运单号
        |  get_json_object(get_json_object(get_json_object(detail,'$.gisDeptBody'),'$.result'),'$.type') type2,
        |  get_json_object(get_json_object(get_json_object(get_json_object(detail,'$.gisDeptBody'),'$.result'),'$.sxData'),'$.codeSource') codeSource,
        |  get_json_object(detail,'$.ewb_no') gis_identify_site_code,
        |  get_json_object(detail,'$.ewb_no') urlVersion,
        |  get_json_object(detail,'$.ewb_sign_site_code') ewb_sign_site_code,---签收网点
        |  get_json_object(detail,'$.code_eff_sign') code_eff_sign,---签收网点信息维护
        |  get_json_object(detail,'$.banner_sign') banner_sign,--签收网点名称
        |  get_json_object(detail,'$.codeNew') codeNew,----二次重跑网点
        |  get_json_object(detail,'$.code_eff_gis') code_eff_gis,------二次重跑网点信息维护
        |  get_json_object(detail,'$.banner_gis') banner_gis,----二次重跑网点名称
        |  get_json_object(detail,'$.ewb_dispatch_site') ewb_dispatch_site,-----生产识别网点
        |  get_json_object(detail,'$.tag') tag,
        |  get_json_object(detail,'$.uid') uid,-----日志中AOIid
        |  get_json_object(detail,'$.townNew') townNew,----二次重跑town
        |  get_json_object(detail,'$.countyNew') countyNew,----二次重跑county
        |  get_json_object(detail,'$.cityNew') cityNew,----二次重跑城市
        |  get_json_object(detail,'$.provinceNew') provinceNew,----二次重跑省
        |  get_json_object(detail,'$.cityCodeNew') cityCodeNew,----二次重跑citycode
        |  get_json_object(detail,'$.codeSourceNew') codeSourceNew,----二次重跑网点来源
        |  get_json_object(detail,'$.areaSourceNew') areaSourceNew,
        |  get_json_object(detail,'$.ChnameNew') ChnameNew,
        |  get_json_object(detail,'$.artificial_choose_site') artificial_choose_site,----人工开单
        |  get_json_object(detail,'$.artificial_town_name') artificial_town_name,--人工开单名称
        |  get_json_object(detail,'$.artificial_county_name') artificial_county_name,----人工开单county
        |  get_json_object(detail,'$.splitLevel') splitLevel,--切词
        |  get_json_object(detail,'$.sxDeptNotCover') sxDeptNotCover,----二次盲区
        |  get_json_object(detail,'$.sign_city_name') sign_city_name,---签收城市
        |  get_json_object(detail,'$.sign_county_name') sign_county_name,---签收城市
        |  get_json_object(detail,'$.signCityCode') signCityCode,----签收citycode
        |  get_json_object(detail,'$.sign_town_name') sign_town_name,---签收town
        |  regexp_replace(get_json_object(get_json_object(get_json_object(get_json_object(detail,'$.gisDeptBody'),'$.result'),'$.sxData'),'$.code'), '[\r\n\t]+', '') code_sc,
        |  regexp_replace(get_json_object(detail,'$.gis_identify_site_address'),'[\r\n\t",]+', '') gis_identify_site_address,
        |  regexp_replace(get_json_object(detail,'$.ewb_sign_address'),'[\r\n\t",]+', '') ewb_sign_address,
        |  regexp_replace(get_json_object(detail,'$.extend_attrs_gis'),'[\r\n\t",]+', '') extend_attrs_gis,
        |  regexp_replace(get_json_object(detail,'$.extend_attrs_sign'),'[\r\n\t",]+', '') extend_attrs_sign,
        |  inc_day
        |from dm_gis.shunxin_detail_di_new
        |where inc_day = '%s'
        |""".stripMargin

    val waybillDf = spark.sql(String.format(waybillSql, inc_day))
    val ak_code = "8cb19f422db34736922479ba0bc848f4"
    val ak_kw_town = "8bb09e5e110845f39a000391668e3e80"

    //v2逻辑的第4)条规则的逻辑判断
    val key_level_cond = """^.*(13\^[1-5]\|13\^6).*""".r()
    val key_level_bool = udf((key_level: String) => {
      key_level match {
        case key_level_cond(rand) => true
        case _ => false
      }
    })

    val auditRes = auditDf.repartition(50)
      .map(row => {
        val check_x = row.getAs[String]("check_x") //经度
        val check_y = row.getAs[String]("check_y") //纬度
        val check_address = row.getAs[String]("check_address")
        val check_address_nos = check_address.replaceAll("\\s+", "") //地址
        val inc_day = row.getAs[String]("inc_day")

        //广东省广州市白云区钟落潭镇钟落谭镇
        //地址获取citycode + town
        var citycode = ""
        var town = ""
        //地址接口获取的分级地址信息
        var key_tag = ""
        var key_level = ""
        var key_word = ""
        var key_levels = ""
        //经纬度获取的网点编号code信息
        var code = ""

        var json_town = ""
        var json_kw = ""
        var json_code = ""

        if (check_address != null && check_address.trim != "") {
          try {
            //获取citycode + town信息借口
            val formatUrl_town = getJsonParam(HttpConstant.HTTP_ADDR_CODE_TOWN, ak_kw_town, check_address_nos)
            val getResult_town_str: String = HttpInvokeUtil.sendGet(formatUrl_town, "UTF-8", 1)
            logger.error(s"审补town信息：" + getResult_town_str)
            val response_town: JSONObject = JSON.parseObject(getResult_town_str)
            json_town = getResult_town_str
            citycode = response_town.getJSONObject("result").getJSONObject("data").getString("citycode")
            town = response_town.getJSONObject("result").getJSONObject("data").getString("town")
          }
          catch {
            case e: Exception => logger.error("审补表数据获取 citycode 和 town 等 信息有异常：" + e.getMessage)
          }

          try {
            //获取关键字接口
            val formatUrl_kw = getJsonParam(HttpConstant.HTTP_ADDR_KW, ak_kw_town, check_address_nos)
            val getResult_kw_str: String = HttpInvokeUtil.sendGet(formatUrl_kw, "UTF-8", 1)
            logger.error(s"审补keyword信息：" + getResult_kw_str)
            val response_kw: JSONObject = JSON.parseObject(getResult_kw_str)
            json_kw = getResult_kw_str

            val pub_json = response_kw.getJSONObject("result").getJSONObject("keyInfo")
            key_tag = pub_json.getString("key_tag")
            key_level = pub_json.getString("key_level")
            key_word = pub_json.getString("key_word")
            key_levels = pub_json.getString("key_levels")
          }
          catch {
            case e: Exception => logger.error("审补表数据获取 key_word等 信息有异常：" + e.getMessage)
          }
        }
        try {
          if (check_x != null && check_x.trim != "" && check_y != null && check_y.trim != "") {
            val formatUrl_code = getJsonParam(HttpConstant.HTPP_LNG_LAT_CODE, ak_code, check_x, check_y)
            val getResult_code_str: String = HttpInvokeUtil.sendGet(formatUrl_code, "UTF-8", 1)
            logger.error(s"审补网点编号code信息：" + getResult_code_str)
            val response_code: JSONObject = JSON.parseObject(getResult_code_str)
            json_code = getResult_code_str
            code = response_code.getJSONObject("result").getJSONArray("map_data").getJSONObject(0).getString("code")
          }
        } catch {
          case e: Exception => logger.error("审补表数据获取 网点编号code 信息有异常：" + e.getMessage)
        }
        (check_x, check_y, check_address, citycode, town, key_tag, key_level, key_word, key_levels, code, json_town, json_kw, json_code, inc_day)
      }).toDF("check_x", "check_y", "check_address", "citycode", "town", "key_tag", "key_level", "key_word", "key_levels", "code", "json_town", "json_kw", "json_code", "inc_day")
      .withColumn("keyword_sb", when('key_level === "10", 'key_word)
        .when('key_level === "11", concat_ws("|", split('key_word, "\\|")(0), split('key_word, "\\|")(1)))
        .when('key_level === "13" and !'key_level.contains("13^6"), split('key_word, "\\|")(0))
        //        .when('key_level === "13" and ('key_level.contains("13^1|13^6").or('key_level.contains("13^2|13^6")).or('key_level.contains("13^3|13^6")).or('key_level.contains("13^4|13^6")).or('key_level.contains("13^5|13^6"))), concat_ws("|", split('key_word, "\\|")(0), split('key_word, "\\|")(1)))
        .when('key_level === "13" and key_level_bool('key_level), concat_ws("|", split('key_word, "\\|")(0), split('key_word, "\\|")(1)))
      )
      .withColumn("address_all", concat('citycode, 'town, 'key_tag, 'keyword_sb))
      .select("address_all", "check_address", "code", "json_town", "json_kw", "json_code", "inc_day")
      .persist()

    val waybillRes = waybillDf.repartition(60)
      .map(row => {
      val ewb_sign_site_code = row.getAs[String]("ewb_sign_site_code") //签收网点
      val ewb_sign_address = row.getAs[String]("ewb_sign_address") //address
      val ewb_sign_address_nos = ewb_sign_address.replaceAll("\\s+", "") //address
      val inc_day = row.getAs[String]("inc_day")
      //地址获取citycode + town
      var citycode = ""
      var town = ""
      //地址接口获取的分级地址信息
      var key_tag = ""
      var key_level = ""
      var key_word = ""
      var key_levels = ""

      var json_town_gd = ""
      var json_kw_gd = ""

      if (ewb_sign_address != null && ewb_sign_address.trim != "") {
        try {
          //获取citycode + town信息借口
          val formatUrl_town = getJsonParam(HttpConstant.HTTP_ADDR_CODE_TOWN, ak_kw_town, ewb_sign_address_nos)
          val getResult_town_str: String = HttpInvokeUtil.sendGet(formatUrl_town, "UTF-8", 1)
          logger.error(s"工单town信息：" + getResult_town_str)
          val response_town: JSONObject = JSON.parseObject(getResult_town_str)
          json_town_gd = getResult_town_str
          citycode = response_town.getJSONObject("result").getJSONObject("data").getString("citycode")
          town = response_town.getJSONObject("result").getJSONObject("data").getString("town")
        }
        catch {
          case e: Exception => logger.error("工单表数据获取 citycode 和 town 等 信息有异常：" + e.getMessage)
        }

        try {
          val formatUrl_addr_2 = getJsonParam(HttpConstant.HTTP_ADDR_KW, ak_kw_town, ewb_sign_address_nos)
          val getResult_addr_2: String = HttpInvokeUtil.sendGet(formatUrl_addr_2, "UTF-8", 1)
          logger.error(s"工单keyword信息：" + getResult_addr_2)
          val response_addr_str_2: JSONObject = JSON.parseObject(getResult_addr_2)
          json_kw_gd = getResult_addr_2
          val pub_json = response_addr_str_2.getJSONObject("result").getJSONObject("keyInfo")
          key_tag = pub_json.getString("key_tag")
          key_level = pub_json.getString("key_level")
          key_word = pub_json.getString("key_word")
          key_levels = pub_json.getString("key_levels")
        } catch {
          case e: Exception => logger.error("工单表数据获取 key_word等 信息有异常：" + e.getMessage)
        }
      }
      (ewb_sign_site_code, ewb_sign_address, citycode, town, key_tag, key_level, key_word, key_levels, json_town_gd, json_kw_gd, inc_day)
    }).toDF("ewb_sign_site_code", "ewb_sign_address", "citycode", "town", "key_tag", "key_level", "key_word", "key_levels", "json_town_gd", "json_kw_gd", "inc_day")
      .withColumn("keyword_gd", when('key_level === "10", 'key_word)
        .when('key_level === "11", concat_ws("|", split('key_word, "\\|")(0), split('key_word, "\\|")(1)))
        .when('key_level === "13" and !'key_level.contains("13^6"), split('key_word, "\\|")(0))
        .when('key_level === "13" and key_level_bool('key_level), concat_ws("|", split('key_word, "\\|")(0), split('key_word, "\\|")(1)))
        //        .when('key_level === "13" and ('key_level.contains("13^1|13^6").or('key_level.contains("13^2|13^6")).or('key_level.contains("13^3|13^6")).or('key_level.contains("13^4|13^6")).or('key_level.contains("13^5|13^6"))), concat_ws("|", split('key_word, "\\|")(0), split('key_word, "\\|")(1)))
      )
      .withColumn("address_all", concat('citycode, 'town, 'key_tag, 'keyword_gd))
      .select("address_all", "ewb_sign_address", "ewb_sign_site_code", "json_town_gd", "json_kw_gd", "inc_day")
      .persist()

    val auditDf_filter = auditRes.filter('address_all.isNotNull && trim('address_all) =!= "")
      .withColumn("num", row_number().over(Window.partitionBy("address_all", "code", "inc_day").orderBy("inc_day")))
      .filter('num === 1)
      .persist()

    //    val waybillDf_filter = waybillRes.filter('address_all.isNotNull && trim('address_all) =!= "")
    //     .withColumn("num", row_number().over(Window.partitionBy("address_all", "ewb_sign_site_code", "inc_day").orderBy("inc_day")))
    //      .filter('num === 1)

    //按照citycode+town+keyflag+keyword匹配
    val join_step_1 = waybillRes
      .join(auditDf_filter, Seq("address_all", "inc_day"), "left")
      .na.fill("")
      .withColumn("address_cnt", when(trim('json_town) =!= "" and 'json_town.isNotNull, 1).otherwise(0))
      .withColumn("code_cnt", when(trim('ewb_sign_site_code) === trim('code), 1).otherwise(0))
      .withColumn("total_cnt", lit(1))
      .select("address_all", "ewb_sign_address", "check_address", "ewb_sign_site_code", "code", "address_cnt", "code_cnt", "total_cnt", "json_town_gd", "json_kw_gd", "json_town", "json_kw", "json_code", "inc_day")
      .persist()
    auditDf_filter.unpersist()
    val join_step_2 = join_step_1
      .groupBy("inc_day")
      .agg(
        sum("address_cnt") as "address_cnt",
        sum("code_cnt") as "code_cnt",
        sum("total_cnt") as "total_cnt"
      )
      .withColumn("address_coinc_rate", when('total_cnt =!= 0, round('address_cnt / 'total_cnt, 2)).otherwise(0))
      .withColumn("code_coinc_rate", when('total_cnt =!= 0, round('code_cnt / 'total_cnt, 2)).otherwise(0))
      .select("address_cnt", "code_cnt", "total_cnt", "address_coinc_rate", "code_coinc_rate", "inc_day")

    writeToHive(spark, auditRes, Seq("inc_day"), "dm_gis.sx_work_detail_shenbu")
    auditRes.unpersist()
    writeToHive(spark, waybillRes, Seq("inc_day"), "dm_gis.sx_work_detail_gongdan")
    waybillRes.unpersist()
    writeToHive(spark, join_step_1, Seq("inc_day"), "dm_gis.sx_work_detail_compare")
    join_step_1.unpersist()
    writeToHive(spark, join_step_2, Seq("inc_day"), "dm_gis.sx_work_detail_rate")

  }

}
