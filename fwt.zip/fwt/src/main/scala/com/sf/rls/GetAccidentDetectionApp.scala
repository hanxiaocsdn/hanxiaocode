package com.sf.rls

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql._
import utils.ColumnUtil.{colNotNull, regexpMatch}
import utils.DateUtil.{getdaysBeforeOrAfter, timeToTimestamp1, timeToTimestamp2, tranTimestampToDate}
import utils.SparkBuilder

/**
 * 任务ID：413431
 */
object GetAccidentDetectionApp extends DataSourceCommon {
    def main(args: Array[String]): Unit = {
        val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
        val inc_day = args(0)
        logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
        processRuleJudge(spark, inc_day)
        processRuleJudge2(spark, inc_day)
        logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
    }

    def processRuleJudge(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._
        val three_days_before = getdaysBeforeOrAfter(inc_day, -3)
        val three_days_after = getdaysBeforeOrAfter(inc_day, 3)
        val stay_info_7days_df = spark.sql(
            s"""
               |select trim(vehicle_serial) as vehicle_serial,
               |       startindex,
               |       endindex,
               |       starttime,
               |       endtime,
               |       duration,
               |       roadclass_x,
               |       navi_addr,
               |       business,
               |       name,
               |       len,
               |       task_area_code,--20220319新增1/3
               |       startlon,--20220319新增2/3
               |       startlat,--20220319新增3/3
               |       inc_day
               |from dm_gis.grd_new_stay_info
               |where inc_day >='$three_days_before' and inc_day<='$three_days_after'
               |      and vehicle_serial is not null and trim(vehicle_serial) !=''
               |      and is_zy='1'
               |""".stripMargin)
          .persist()

        val o_dm_grd_df = spark.sql(
            s"""
               |select
               |  trim(vehicle_serial) as vehicle_serial,
               |  task_area_code,
               |  inc_day,
               |  error_info,
               |  driver_id,
               |  run_status,
               |  actual_depart_tm,
               |  actual_arrive_tm
               |from
               |  dm_grd.grd_new_task_detail
               |where inc_day >='$three_days_before' and inc_day<='$three_days_after'
               |  and vehicle_serial is not null and trim(vehicle_serial) != ''
               |  and task_area_code is not null and trim(task_area_code) != ''
               |  and (regexp_replace(substr(actual_depart_tm, 0,10),'-','') <=inc_day or regexp_replace(substr(actual_arrive_tm, 0,10),'-','') >=inc_day)
               |  and substr(src_zone_code, 1, 1) not in ('P', 'M')
               |  and conveyance_type = 5
               |group by
               |  vehicle_serial,
               |  task_area_code,
               |  inc_day,
               |  error_info,
               |  driver_id,
               |  run_status,actual_depart_tm,
               |  actual_arrive_tm
               |""".stripMargin)
        val o_device_df = spark.sql(
            s"""
               |select
               |   carplate vehicle_serial, --车牌
               |   deptcode task_area_code,
               |   inc_day
               |from
               |   dm_arss.dm_device_hh_dtl_di
               |where
               |   inc_day >='$three_days_before' and inc_day<='$three_days_after'
               |   and carplate is not null and trim(carplate) != ''
               |   and deptcode is not null and trim(deptcode) != ''
               |   and substring(data_code,0,8) ='10001004'
               |group by
               |   carplate,
               |   deptcode,
               |   inc_day
               |""".stripMargin)

        val dm_grd_day_df = o_dm_grd_df.join(o_device_df, Seq("vehicle_serial", "task_area_code", "inc_day"))
          .persist()
        //新表dm_arss.dm_alarm_detail_dtl_di  后期生产用该表
        val alarm_info_df = spark.sql(
            s"""
               |select trim(car_no) as vehicle_serial,
               |       alarm_time,
               |       case when p_type = 1 and sub_type = 1 then '疲劳'
               |       when p_type = 1 and sub_type = 2 then '打哈欠'
               |       when p_type = 1 and sub_type = 3 then '吸烟'
               |       when p_type = 1 and sub_type = 4 then '打电话'
               |       when p_type = 1 and sub_type = 5 then '未系安全带'
               |       when p_type = 1 and sub_type = 6 then '左顾右盼'
               |       when p_type = 1 and sub_type = 7 then '分心驾驶'
               |       when p_type = 1 and sub_type = 8 then '喝水'
               |       when p_type = 1 and sub_type = 9 then '驾驶员变更'
               |       when p_type = 1 and sub_type = 10 then '摄像头遮挡 '
               |       when p_type = 2 and sub_type = 1 then '前车碰撞'
               |       when p_type = 2 and sub_type = 2 then '车道偏离'
               |       when p_type = 2 and sub_type = 3 then '车距过近'
               |       when p_type = 2 and sub_type = 4 then '行人碰撞'
               |       when p_type = 3 and sub_type = 1 then '急加速'
               |       when p_type = 3 and sub_type = 2 then '急减速'
               |       when p_type = 3 and sub_type = 3 then '急转弯'
               |       when p_type = 3 and sub_type = 4 then '超速'
               |       when p_type = 3 and sub_type = 5 then '超限速告警'
               |       when p_type = 4 and sub_type = 2 then '偏离或遮挡镜头'
               |       when p_type = 5 and sub_type = 1 then '盲区行人报警'
               |       when p_type = 5 and sub_type = 2 then '停车未熄火'
               |       else '' END as sub_type,
               |       alarm_id,
               |	     inc_day
               |from dm_arss.dm_alarm_detail_dtl_di
               |where inc_day >= '$inc_day' and inc_day <='$three_days_after'
               |      and car_no is not null and trim(car_no) != ''
               |""".stripMargin)
        /**
         * r1新增剔除字段【服务区|停车区|加油站|顺丰速运|顺丰中转场|物流中心、物流园、物流公司、物流有限公司】
         * r2新增剔除字段【物流中心、物流园、物流公司、物流有限公司】
         * 【服务区|停车区|加油站|顺丰速运|顺丰中转场|物流中心|物流园|物流公司|物流有限公司】
         */
        //r1和r2 same  三个条件满足一个即排除
        val match_cond = "(.*)(服务区|停车区|加油站|顺丰速运|顺丰中转场|物流中心|物流园|物流公司|物流有限公司|集配站)+(.*)"
        val bool_cond = regexpMatch(match_cond)(col("navi_addr")) || regexpMatch(match_cond)(col("business")) || regexpMatch(match_cond)(col("name"))

        //r1 规则：告警发生30s内，出现长时间停留；
        val alarm_r1_df = alarm_info_df
          .select(
              col("vehicle_serial"),
              timeToTimestamp1(col("alarm_time")) as "alarm_time", //2022-02-16 11:42:15
              col("sub_type"),
              lit("") as "startindex",
              lit("") as "endindex",
              lit("") as "endtime",
              lit("") as "duration",
              lit("") as "roadclass_x",
              lit("") as "navi_addr",
              lit("") as "business",
              lit("") as "startlon",
              lit("") as "startlat",
              lit("") as "task_area_code",
              col("alarm_id"),
              col("inc_day")
          )
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "alarm_time", "sub_type", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num")

        val stay_info_day_r1_df = stay_info_7days_df.filter(col("inc_day") >= inc_day && col("inc_day") <= three_days_after)
          .filter(!bool_cond)
          .withColumn("sub_type", lit("staypoint"))
          .select(
              col("vehicle_serial"),
              timeToTimestamp2(col("starttime")) as "alarm_time", //2022/02/16 11:42:15
              col("sub_type"),
              col("startindex"),
              col("endindex"),
              col("endtime"),
              col("duration"),
              col("roadclass_x"),
              col("navi_addr"),
              col("business"),
              col("startlon"),
              col("startlat"),
              col("task_area_code"),
              lit("") as "alarm_id",
              col("inc_day"))
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "alarm_time", "sub_type", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num")
          .persist()

        val cond_sub_type = col("sub_type") =!= "staypoint" && trim(col("sub_type")) =!= "" && col("sub_type").isNotNull && col("stay_next_sub_type") === "staypoint"

        val stay_alarm_r1_df = stay_info_day_r1_df.union(alarm_r1_df).repartition(500)
          .withColumn("stay_next_starttime", lead(col("alarm_time"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("stay_next_sub_type", lead(col("sub_type"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("startindex_t", lead(col("startindex"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("endindex_t", lead(col("endindex"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("endtime_t", lead(col("endtime"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("duration_t", lead(col("duration"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("roadclass_x_t", lead(col("roadclass_x"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("navi_addr_t", lead(col("navi_addr"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("business_t", lead(col("business"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("startlon_t", lead(col("startlon"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("startlat_t", lead(col("startlat"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("task_area_code_t", lead(col("task_area_code"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .na.fill("")
          .na.fill("0", Seq("stay_next_starttime", "stay_next_sub_type"))
          .withColumn("time_gap", (col("stay_next_starttime") - col("alarm_time")).cast("int").cast("string"))
          .withColumn("time_gap_flag", when(col("time_gap").cast("int") <= 30 and col("time_gap").cast("int") >= 0, 1).otherwise(0))
          .withColumn("sub_type_flag", when(cond_sub_type, 1).otherwise(0))
          .filter(col("time_gap_flag") === 1 && col("sub_type_flag") === 1)
          .select(
              col("vehicle_serial"),
              col("startindex_t") as "startindex",
              col("endindex_t") as "endindex",
              tranTimestampToDate(col("stay_next_starttime")) as "starttime",
              col("endtime_t") as "endtime",
              col("duration_t") as "duration",
              col("roadclass_x_t") as "roadclass_x",
              col("navi_addr_t") as "navi_addr",
              col("business_t") as "business",
              col("sub_type"),
              tranTimestampToDate(col("alarm_time")) as "alarm_time",
              col("time_gap"),
              col("startlon_t") as "startlon",
              col("startlat_t") as "startlat",
              col("task_area_code_t") as "task_area_code",
              lit("") as "driver_id",
              lit("r1") as "rule",
              col("alarm_id"),
              col("inc_day")
          )


        //r2 取当天的数据--异常停留 规则道路等级等于0 1 2 剔除异常道路poi
        //20220428新增aoi信息比对
        val ak = "3eb300d2e06947f7945cd02530a32fd2"
//        val aoi_infos = new HashSet[String]()

//        spark.sql(
//            """
//              |select longitude,latitude from dim.dim_department
//              |where trim(longitude) != '' and longitude is not null
//              |      and trim(latitude) != '' and latitude is not null
//              |""".stripMargin) //8w0189条数据
//          .toLocalIterator
//          .foreach(row => {
//              val longitude = row.getAs[String]("longitude")
//              val latitude = row.getAs[String]("latitude")
//              var aoi_id = ""
//              var aoi_name = ""
//              var aoi_info = ""
//              try {
//                  val urlParam = getJsonParam(HTPP_LNG_LAT_AOI, ak, longitude, latitude)
//                  val res_str = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
//                  //          println("dim_department 返回的json为：" + res_str)
//                  val getAoiJson = JSON.parseObject(res_str)
//                  val pub_json: JSONObject = getAoiJson.getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0)
//                  aoi_id = pub_json.getString("aoi_id")
//                  aoi_name = pub_json.getString("aoi_name")
//              } catch {
//                  case e: Exception => logger.error(s"dim_department 经度：$longitude，纬度：$latitude 无返回值" + e.getMessage)
//              }
//              if (aoi_id.trim != "" && aoi_name.trim != "") {
//                  aoi_info = aoi_id + "_" + aoi_name //拼接aoi_id aoi_name
//                  aoi_infos.add(aoi_info)
//              }
//          })
        //20220427新增不以部分区域结尾的字段
        val navi_addr_filter = udf((navi_addr: String) => {
            var flag = false
            try {
                flag = navi_addr.endsWith("机场") || navi_addr.endsWith("航站楼") || navi_addr.endsWith("码头")
            } catch {
                case e: Exception => logger.error(s"字段 $navi_addr 为null" + e.getMessage)
            }
            flag
        })
        //r2 原始逻辑
        val dm_grd_tmp = dm_grd_day_df.filter(col("inc_day") >= inc_day && col("inc_day") <= three_days_after)
          .select("vehicle_serial", "driver_id", "inc_day")
          .groupBy("vehicle_serial", "inc_day")
          .agg(
              concat_ws(",", collect_set("driver_id")) as "driver_id"
          )
        val fiter_cond_sty_info: Column = (col("inc_day") >= inc_day && col("inc_day") <= three_days_after) && (col("roadclass_x").isin("0", "1", "2"))

        val stay_info_day_r2_df = stay_info_7days_df
          .filter(fiter_cond_sty_info)
          .filter(!bool_cond && !navi_addr_filter('navi_addr))
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "startindex", "endindex", "starttime", "endtime", "duration", "roadclass_x", "navi_addr", "business", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num", "driver_id")
          .join(broadcast(dm_grd_tmp), Seq("vehicle_serial", "inc_day"), "left")
          .select(
              col("vehicle_serial"),
              col("startindex"),
              col("endindex"),
              col("starttime"),
              col("endtime"),
              col("duration"),
              col("roadclass_x"),
              col("navi_addr"),
              col("business"),
              lit("") as "sub_type",
              lit("") as "alarm_time",
              lit("") as "time_gap",
              col("startlon"),
              col("startlat"),
              col("task_area_code"),
              col("driver_id"),
              lit("r2") as "rule",
              lit("") as "alarm_id",
              col("inc_day")
          )
        //r3 r4 r5 三个规则公共part
        //startindex	endindex	starttime	endtime	duration	roadclass_x	navi_addr	business	startlon	startlat	task_area_code
        val stay_info_pub = stay_info_7days_df.filter(col("inc_day") === inc_day)
          .select("vehicle_serial", "startindex", "endindex", "starttime", "endtime", "duration", "roadclass_x", "navi_addr", "business", "startlon", "startlat", "task_area_code", "inc_day")
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(desc("endtime"))))
          .filter('num === 1)
          .persist()

        //r3 规则：里程超时且（满足异常停留规则的里程）当天和前三天有里程，后三天无里程；
        val dm_grd_r3_df = dm_grd_day_df
          .filter(col("inc_day") === inc_day)
          .filter(col("run_status").cast("int") === 4)
          .select("vehicle_serial", "inc_day")
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1)
          .drop("num")

        val cond_3days_before_len = colNotNull(col("len")) && (col("inc_day") >= three_days_before && col("inc_day") <= inc_day)
        val cond_3days_after_len = colNotNull(col("len")) && (col("inc_day") > inc_day && col("inc_day") <= three_days_after)

        val stay_info_r3_df = stay_info_7days_df
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "len", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num")
          .withColumn("three_days_bofore_len", when(cond_3days_before_len, 1).otherwise(0))
          .withColumn("three_days_after_len", when(cond_3days_after_len, 1).otherwise(0))
          .groupBy("vehicle_serial")
          .agg(
              max("task_area_code") as "task_area_code",
              sum("three_days_bofore_len") as "three_days_bofore_len",
              sum("three_days_after_len") as "three_days_after_len"
          )
          .withColumn("inc_day", lit(inc_day))
          .filter(col("three_days_bofore_len") >= 4 && col("three_days_after_len") === 0)

        val r3_df = dm_grd_r3_df
          .join(stay_info_pub.drop("task_area_code"), Seq("vehicle_serial", "inc_day"), "left")
          .join(broadcast(stay_info_r3_df), Seq("vehicle_serial", "inc_day"))
          .select(
              col("vehicle_serial"),
              col("startindex"),
              col("endindex"),
              col("starttime"),
              col("endtime"),
              col("duration"),
              col("roadclass_x"),
              col("navi_addr"),
              col("business"),
              lit("") as "sub_type",
              lit("") as "alarm_time",
              lit("") as "time_gap",
              col("startlon"),
              col("startlat"),
              col("task_area_code"),
              lit("") as "driver_id",
              lit("r3") as "rule",
              lit("") as "alarm_id",
              col("inc_day")
          )

        //r4 规则：grd表上报事故；
        val dm_grd_r4_df = dm_grd_day_df
          .filter(col("inc_day") === inc_day)
          .filter(col("error_info").cast("int") === 5)
          .select("vehicle_serial", "task_area_code", "driver_id", "inc_day")
          .groupBy("vehicle_serial", "inc_day")
          .agg(
              max("task_area_code") as "task_area_code",
              concat_ws(",", collect_set("driver_id")) as "driver_id"
          )
          .join(stay_info_pub.drop("task_area_code"), Seq("vehicle_serial", "inc_day"), "left")
          .select(
              col("vehicle_serial"),
              col("startindex"),
              col("endindex"),
              col("starttime"),
              col("endtime"),
              col("duration"),
              col("roadclass_x"),
              col("navi_addr"),
              col("business"),
              lit("") as "sub_type",
              lit("") as "alarm_time",
              lit("") as "time_gap",
              col("startlon"),
              col("startlat"),
              col("task_area_code"),
              col("driver_id"),
              lit("r4") as "rule",
              lit("") as "alarm_id",
              col("inc_day")
          )

        //Rule5 规则：里程超时；且当天和前三天司机有排班，后三天无排班；todo col("run_status").cast("int") === 4 只判断今天即可
        val cond_3days_before_driver_id = (('driver_id.isNotNull && trim('driver_id) =!= "") || ('actual_depart_tm.isNotNull && trim('actual_depart_tm) =!= "" && 'actual_arrive_tm.isNotNull && trim('actual_arrive_tm) =!= "")) && (col("inc_day") >= three_days_before && col("inc_day") <= inc_day)
        val cond_3days_after_driver_id = (('driver_id.isNotNull && trim('driver_id) =!= "") || ('actual_depart_tm.isNotNull && trim('actual_depart_tm) =!= "" && 'actual_arrive_tm.isNotNull && trim('actual_arrive_tm) =!= "")) && (col("inc_day") > inc_day && col("inc_day") <= three_days_after)

        val splitFun = udf((info: String) => {
            var res: Array[String] = Array("")
            try {
                if (info.trim != "" && !info.isEmpty) {
                    res = info.split(",").toSet.toArray
                }
            } catch {
                case e: Exception => logger.error("异常检查", e)
            }
            res
        })
        val cond_status = (col("run_status").cast("int") === 4 && col("inc_day") === inc_day) || col("inc_day") =!= inc_day
        val r5_last_df_mid = o_dm_grd_df.filter(cond_status)
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "run_status", "driver_id", "actual_depart_tm", "actual_arrive_tm", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num")
          .withColumn("vehicle_serial", when(col("inc_day") === inc_day, col("vehicle_serial")).otherwise(null))
          .withColumn("three_days_bofore_driver_id", when(cond_3days_before_driver_id, 1).otherwise(0))
          .withColumn("three_days_after_driver_id", when(cond_3days_after_driver_id, 1).otherwise(0))
          .na.fill(0, Seq("three_days_bofore_driver_id", "three_days_after_driver_id"))

        val r5_last_df = r5_last_df_mid
          .groupBy("driver_id", "inc_day")
          .agg(
              concat_ws(",", collect_set('vehicle_serial)) as "vehicle_serial_arr",
              max("three_days_bofore_driver_id") as "three_days_bofore_driver_id",
              max("three_days_after_driver_id") as "three_days_after_driver_id"
          )
          .groupBy("driver_id")
          .agg(
              concat_ws(",", collect_set('vehicle_serial_arr)) as "vehicle_serial_arr",
              sum("three_days_bofore_driver_id") as "three_days_bofore_driver_id",
              sum("three_days_after_driver_id") as "three_days_after_driver_id"
          )
          .withColumn("inc_day", lit(inc_day))
          .filter(col("three_days_bofore_driver_id") >= 4 && col("three_days_after_driver_id") === 0)
          .withColumn("vehicle_serial", explode(splitFun('vehicle_serial_arr)))

        val r5_df = r5_last_df
          .join(stay_info_pub, Seq("vehicle_serial", "inc_day"), "left")
          .join(o_device_df.drop("task_area_code"), Seq("vehicle_serial", "inc_day"))
          .select(
              col("vehicle_serial"),
              col("startindex"),
              col("endindex"),
              col("starttime"),
              col("endtime"),
              col("duration"),
              col("roadclass_x"),
              col("navi_addr"),
              col("business"),
              lit("") as "sub_type",
              lit("") as "alarm_time",
              lit("") as "time_gap",
              col("startlon"),
              col("startlat"),
              col("task_area_code"),
              col("driver_id"),
              lit("r5") as "rule",
              lit("") as "alarm_id",
              col("inc_day")
          )
        stay_info_7days_df.unpersist()
        // 4+1 个规则的数据汇总统计
        val totalRule_0 = stay_alarm_r1_df.union(stay_info_day_r2_df).union(r3_df).union(dm_grd_r4_df).union(r5_df).persist()

        val totalRule_2 = totalRule_0
          .groupBy("vehicle_serial", "inc_day")
          .agg(concat_ws(",", sort_array(collect_set(col("rule")))) as "rule")

        val deviceDF: DataFrame = spark.sql(s"select carplate,data_code,imei,inc_day as inc_day2 from dm_arss.dm_device_hh_dtl_di where inc_day >='$three_days_before' and inc_day<='$three_days_after'")

        val totalRule = totalRule_0.drop("rule")
          .join(broadcast(totalRule_2), Seq("vehicle_serial", "inc_day"))
          .join(deviceDF, totalRule_0("vehicle_serial") === deviceDF("carplate") and totalRule_0("inc_day") === deviceDF("inc_day2"), "left")
          .select("vehicle_serial",
              "startindex",
              "endindex",
              "starttime",
              "endtime",
              "duration",
              "roadclass_x",
              "navi_addr",
              "business",
              "sub_type",
              "alarm_time",
              "time_gap",
              "startlon",
              "startlat",
              "task_area_code",
              "driver_id",
              "rule",
              "data_code",
              "imei",
              "alarm_id",
              "inc_day")
        writeToHive(spark, totalRule, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule")
        //    writeToHive(spark, totalRule, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule_tmp")
        dm_grd_day_df.unpersist()
        totalRule_0.unpersist()
        stay_info_pub.unpersist()

    }

    def processRuleJudge2(spark: SparkSession, inc_day: String): Unit = {
        import spark.implicits._
        val three_days_before: String = getdaysBeforeOrAfter(inc_day, -3)
        val three_days_after: String = getdaysBeforeOrAfter(inc_day, 3)
        val stay_info_7days_df: DataFrame = spark.sql(
            s"""
               |select trim(vehicle_serial) as vehicle_serial,
               |       startindex,
               |       endindex,
               |       starttime,
               |       endtime,
               |       duration,
               |       roadclass_x,
               |       navi_addr,
               |       business,
               |       name,
               |       len,
               |       task_area_code,--20220319新增1/3
               |       startlon,--20220319新增2/3
               |       startlat,--20220319新增3/3
               |       inc_day
               |from dm_gis.grd_new_stay_info
               |where inc_day >='$three_days_before' and inc_day<='$three_days_after'
               |      and vehicle_serial is not null and trim(vehicle_serial) !=''
               |      and is_zy='0'
               |""".stripMargin)
          .persist()

        val o_dm_grd_df: DataFrame = spark.sql(
            s"""
               |select
               |  trim(vehicle_serial) as vehicle_serial,
               |  task_area_code,
               |  inc_day,
               |  error_info,
               |  driver_id,
               |  run_status,
               |  actual_depart_tm,
               |  actual_arrive_tm
               |from
               |  dm_grd.grd_new_task_detail
               |where inc_day >='$three_days_before' and inc_day<='$three_days_after'
               |  and vehicle_serial is not null and trim(vehicle_serial) != ''
               |  and task_area_code is not null and trim(task_area_code) != ''
               |  and (regexp_replace(substr(actual_depart_tm, 0,10),'-','') <=inc_day or regexp_replace(substr(actual_arrive_tm, 0,10),'-','') >=inc_day)
               |  and substr(src_zone_code, 1, 1) not in ('P', 'M')
               |  and conveyance_type = 5
               |group by
               |  vehicle_serial,
               |  task_area_code,
               |  inc_day,
               |  error_info,
               |  driver_id,
               |  run_status,actual_depart_tm,
               |  actual_arrive_tm
               |""".stripMargin)
        val o_device_df: DataFrame = spark.sql(
            s"""
               |select
               |   carplate vehicle_serial, --车牌
               |   deptcode task_area_code,
               |   inc_day
               |from
               |   dm_arss.dm_device_hh_dtl_di
               |where
               |   inc_day >='$three_days_before' and inc_day<='$three_days_after'
               |   and carplate is not null and trim(carplate) != ''
               |   and deptcode is not null and trim(deptcode) != ''
               |   and substring(data_code,0,8) !='10001004'
               |group by
               |   carplate,
               |   deptcode,
               |   inc_day
               |""".stripMargin)

        val dm_grd_day_df: DataFrame = o_dm_grd_df.join(o_device_df, Seq("vehicle_serial", "task_area_code", "inc_day"))
          .persist()
        //新表dm_arss.dm_alarm_detail_dtl_di  后期生产用该表
        val alarm_info_df: DataFrame = spark.sql(
            s"""
               |select trim(car_no) as vehicle_serial,
               |       alarm_time,
               |       case when p_type = 1 and sub_type = 1 then '疲劳'
               |       when p_type = 1 and sub_type = 2 then '打哈欠'
               |       when p_type = 1 and sub_type = 3 then '吸烟'
               |       when p_type = 1 and sub_type = 4 then '打电话'
               |       when p_type = 1 and sub_type = 5 then '未系安全带'
               |       when p_type = 1 and sub_type = 6 then '左顾右盼'
               |       when p_type = 1 and sub_type = 7 then '分心驾驶'
               |       when p_type = 1 and sub_type = 8 then '喝水'
               |       when p_type = 1 and sub_type = 9 then '驾驶员变更'
               |       when p_type = 1 and sub_type = 10 then '摄像头遮挡 '
               |       when p_type = 2 and sub_type = 1 then '前车碰撞'
               |       when p_type = 2 and sub_type = 2 then '车道偏离'
               |       when p_type = 2 and sub_type = 3 then '车距过近'
               |       when p_type = 2 and sub_type = 4 then '行人碰撞'
               |       when p_type = 3 and sub_type = 1 then '急加速'
               |       when p_type = 3 and sub_type = 2 then '急减速'
               |       when p_type = 3 and sub_type = 3 then '急转弯'
               |       when p_type = 3 and sub_type = 4 then '超速'
               |       when p_type = 3 and sub_type = 5 then '超限速告警'
               |       when p_type = 4 and sub_type = 2 then '偏离或遮挡镜头'
               |       when p_type = 5 and sub_type = 1 then '盲区行人报警'
               |       when p_type = 5 and sub_type = 2 then '停车未熄火'
               |       else '' END as sub_type,
               |	     alarm_id,
               |	     inc_day
               |from dm_arss.dm_alarm_detail_wb_dtl_di
               |where inc_day >= '$inc_day' and inc_day <='$three_days_after'
               |      and car_no is not null and trim(car_no) != ''
               |""".stripMargin)
        /**
         * r1新增剔除字段【服务区|停车区|加油站|顺丰速运|顺丰中转场|物流中心、物流园、物流公司、物流有限公司】
         * r2新增剔除字段【物流中心、物流园、物流公司、物流有限公司】
         * 【服务区|停车区|加油站|顺丰速运|顺丰中转场|物流中心|物流园|物流公司|物流有限公司】
         */
        //r1和r2 same  三个条件满足一个即排除
        val match_cond = "(.*)(服务区|停车区|加油站|顺丰速运|顺丰中转场|物流中心|物流园|物流公司|物流有限公司|集配站)+(.*)"
        val bool_cond: Column = regexpMatch(match_cond)(col("navi_addr")) || regexpMatch(match_cond)(col("business")) || regexpMatch(match_cond)(col("name"))

        //r1 规则：告警发生30s内，出现长时间停留；
        val alarm_r1_df: DataFrame = alarm_info_df
          .select(
              col("vehicle_serial"),
              timeToTimestamp1(col("alarm_time")) as "alarm_time", //2022-02-16 11:42:15
              col("sub_type"),
              lit("") as "startindex",
              lit("") as "endindex",
              lit("") as "endtime",
              lit("") as "duration",
              lit("") as "roadclass_x",
              lit("") as "navi_addr",
              lit("") as "business",
              lit("") as "startlon",
              lit("") as "startlat",
              lit("") as "task_area_code",
              col("alarm_id"),
              col("inc_day")
          )
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "alarm_time", "sub_type", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num")

        val stay_info_day_r1_df: DataFrame = stay_info_7days_df.filter(col("inc_day") >= inc_day && col("inc_day") <= three_days_after)
          .filter(!bool_cond)
          .withColumn("sub_type", lit("staypoint"))
          .select(
              col("vehicle_serial"),
              timeToTimestamp2(col("starttime")) as "alarm_time", //2022/02/16 11:42:15
              col("sub_type"),
              col("startindex"),
              col("endindex"),
              col("endtime"),
              col("duration"),
              col("roadclass_x"),
              col("navi_addr"),
              col("business"),
              col("startlon"),
              col("startlat"),
              col("task_area_code"),
              lit("") as "alarm_id",
              col("inc_day")
          )
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "alarm_time", "sub_type", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num")
          .persist()

        val cond_sub_type: Column = col("sub_type") =!= "staypoint" && trim(col("sub_type")) =!= "" && col("sub_type").isNotNull && col("stay_next_sub_type") === "staypoint"

        val stay_alarm_r1_df: DataFrame = stay_info_day_r1_df.union(alarm_r1_df).repartition(500)
          .withColumn("stay_next_starttime", lead(col("alarm_time"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("stay_next_sub_type", lead(col("sub_type"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("startindex_t", lead(col("startindex"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("endindex_t", lead(col("endindex"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("endtime_t", lead(col("endtime"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("duration_t", lead(col("duration"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("roadclass_x_t", lead(col("roadclass_x"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("navi_addr_t", lead(col("navi_addr"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("business_t", lead(col("business"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("startlon_t", lead(col("startlon"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("startlat_t", lead(col("startlat"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .withColumn("task_area_code_t", lead(col("task_area_code"), 1).over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(col("alarm_time"), desc("sub_type"))))
          .na.fill("")
          .na.fill("0", Seq("stay_next_starttime", "stay_next_sub_type"))
          .withColumn("time_gap", (col("stay_next_starttime") - col("alarm_time")).cast("int").cast("string"))
          .withColumn("time_gap_flag", when(col("time_gap").cast("int") <= 30 and col("time_gap").cast("int") >= 0, 1).otherwise(0))
          .withColumn("sub_type_flag", when(cond_sub_type, 1).otherwise(0))
          .filter(col("time_gap_flag") === 1 && col("sub_type_flag") === 1)
          .select(
              col("vehicle_serial"),
              col("startindex_t") as "startindex",
              col("endindex_t") as "endindex",
              tranTimestampToDate(col("stay_next_starttime")) as "starttime",
              col("endtime_t") as "endtime",
              col("duration_t") as "duration",
              col("roadclass_x_t") as "roadclass_x",
              col("navi_addr_t") as "navi_addr",
              col("business_t") as "business",
              col("sub_type"),
              tranTimestampToDate(col("alarm_time")) as "alarm_time",
              col("time_gap"),
              col("startlon_t") as "startlon",
              col("startlat_t") as "startlat",
              col("task_area_code_t") as "task_area_code",
              lit("") as "driver_id",
              lit("r1") as "rule",
              col("alarm_id"),
              col("inc_day")
          )
        stay_info_day_r1_df.unpersist()

        //r2 取当天的数据--异常停留 规则道路等级等于0 1 2 剔除异常道路poi
        //20220428新增aoi信息比对
        val ak = "3eb300d2e06947f7945cd02530a32fd2"
//        val aoi_infos = new HashSet[String]()


        //20220427新增不以部分区域结尾的字段
        val navi_addr_filter: UserDefinedFunction = udf((navi_addr: String) => {
            var flag = false
            try {
                flag = navi_addr.endsWith("机场") || navi_addr.endsWith("航站楼") || navi_addr.endsWith("码头")
            } catch {
                case e: Exception => logger.error(s"字段 $navi_addr 为null" + e.getMessage)
            }
            flag
        })
        //r2 原始逻辑
        val dm_grd_tmp: DataFrame = dm_grd_day_df.filter(col("inc_day") >= inc_day && col("inc_day") <= three_days_after)
          .select("vehicle_serial", "driver_id", "inc_day")
          .groupBy("vehicle_serial", "inc_day")
          .agg(
              concat_ws(",", collect_set("driver_id")) as "driver_id"
          )
        val fiter_cond_sty_info: Column = (col("inc_day") >= inc_day && col("inc_day") <= three_days_after) && (col("roadclass_x").isin("0", "1", "2"))

        val stay_info_day_r2_df: DataFrame = stay_info_7days_df
          .filter(fiter_cond_sty_info)
          .filter(!bool_cond && !navi_addr_filter('navi_addr))
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "startindex", "endindex", "starttime", "endtime", "duration", "roadclass_x", "navi_addr", "business", "inc_day").orderBy("inc_day")))
          .filter(col("num") === 1).drop("num", "driver_id")
          .join(broadcast(dm_grd_tmp), Seq("vehicle_serial", "inc_day"), "left")
          .select(
              col("vehicle_serial"),
              col("startindex"),
              col("endindex"),
              col("starttime"),
              col("endtime"),
              col("duration"),
              col("roadclass_x"),
              col("navi_addr"),
              col("business"),
              lit("") as "sub_type",
              lit("") as "alarm_time",
              lit("") as "time_gap",
              col("startlon"),
              col("startlat"),
              col("task_area_code"),
              col("driver_id"),
              lit("r2") as "rule",
              lit("") as "alarm_id",
              col("inc_day")
          )
        //r3 r4 r5 三个规则公共part
        //startindex	endindex	starttime	endtime	duration	roadclass_x	navi_addr	business	startlon	startlat	task_area_code
        val stay_info_pub: Dataset[Row] = stay_info_7days_df.filter(col("inc_day") === inc_day)
          .select("vehicle_serial", "startindex", "endindex", "starttime", "endtime", "duration", "roadclass_x", "navi_addr", "business", "startlon", "startlat", "task_area_code", "inc_day")
          .withColumn("num", row_number().over(Window.partitionBy("vehicle_serial", "inc_day").orderBy(desc("endtime"))))
          .filter('num === 1)
          .persist()

        stay_info_7days_df.unpersist()
        // 4+1 个规则的数据汇总统计
        val totalRule_0: Dataset[Row] = stay_alarm_r1_df.union(stay_info_day_r2_df).persist()

        val totalRule_2: DataFrame = totalRule_0
          .groupBy("vehicle_serial", "inc_day")
          .agg(concat_ws(",", sort_array(collect_set(col("rule")))) as "rule")

        val totalRule: DataFrame = totalRule_0.drop("rule")
          .join(broadcast(totalRule_2), Seq("vehicle_serial", "inc_day"))
          .select("vehicle_serial",
              "startindex",
              "endindex",
              "starttime",
              "endtime",
              "duration",
              "roadclass_x",
              "navi_addr",
              "business",
              "sub_type",
              "alarm_time",
              "time_gap",
              "startlon",
              "startlat",
              "task_area_code",
              "driver_id",
              "rule",
              "alarm_id",
              "inc_day")


        val deviceDF: DataFrame = spark.sql(s"select carplate,data_code,imei,inc_day as inc_day2 from dm_arss.dm_device_hh_dtl_di where inc_day >='$three_days_before' and inc_day<='$three_days_after'")
        val totalRule2: DataFrame = totalRule
          .join(deviceDF, totalRule("vehicle_serial") === deviceDF("carplate") and totalRule("inc_day") === deviceDF("inc_day2"), "left")
          .select("vehicle_serial",
              "startindex",
              "endindex",
              "starttime",
              "endtime",
              "duration",
              "roadclass_x",
              "navi_addr",
              "business",
              "sub_type",
              "alarm_time",
              "time_gap",
              "startlon",
              "startlat",
              "task_area_code",
              "driver_id",
              "rule",
              "data_code",
              "imei",
              "alarm_id",
              "inc_day")

        writeToHive(spark, totalRule2, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule_wb")
        //    writeToHive(spark, totalRule, Seq("inc_day"), "dm_gis.grd_new_stay_info_alarm_rule_tmp")
        dm_grd_day_df.unpersist()
        totalRule_0.unpersist()
        stay_info_pub.unpersist()

    }


}
