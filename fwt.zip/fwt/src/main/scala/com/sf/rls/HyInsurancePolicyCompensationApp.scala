package com.sf.rls

import com.sf.common.DataSourceCommon
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import utils.DateUtil.{getYearOrBefore, interDayStartToEnd, interSectionDays, timeToTimestamp_}
import utils.SparkBuilder

/**
 * @description: 【车辆安全运营】保险数据明细层开发需求 420926
 * @author 01418539 caojia
 * @date 2022/3/16 21:01
 */
object HyInsurancePolicyCompensationApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    val start_day = args(0)
    processLoadData(spark, start_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> Completely Success!")
  }

  def processLoadData(spark: SparkSession, start_day: String): Unit = {
    import spark.implicits._

    //商业险
    val insurance_business_df = spark.sql(
      s"""
         |select
         |    insurance_id,
         |    policy_no,
         |    vehicle_id,
         |    vendor_id,
         |    insurant,
         |    premium,
         |    start_dt,
         |    end_dt,
         |    state,
         |    remark,
         |    created_emp_code,
         |    created_tm,
         |    modified_emp_code,
         |    modified_tm,
         |    contract_id,
         |    not_renew_reason,
         |    not_renew_other_reason,
         |    bukrs,
         |    '商业险' as type,
         |    inc_day
         |from dm_vms.dm_vms_insurance_dtl_df
         |where inc_day = '$start_day'
         |""".stripMargin)

    //交通强制险
    val insurance_compul_df = spark.sql(
      s"""
         |select
         |    insurance_id,
         |    policy_no,
         |    vehicle_id,
         |    vendor_id,
         |    insurant,
         |    premium,
         |    start_dt,
         |    end_dt,
         |    state,
         |    remark,
         |    created_emp_code,
         |    created_tm,
         |    modified_emp_code,
         |    modified_tm,
         |    contract_id,
         |    not_renew_reason,
         |    not_renew_other_reason,
         |    bukrs,
         |    '交强险' as type,
         |    inc_day
         |from dm_vms.dm_vms_insurance_compulsory_dtl_df
         |where inc_day = '$start_day'
         |""".stripMargin)

    //车辆信息表
    val vehicle_info = spark.sql(
      s"""
         |select
         |       vehicle_id,
         |       vehicle_code
         |from ods_vms.tm_vms_vehicle
         |where inc_day='$start_day'
         |      and vehicle_id is not null and trim(vehicle_id) != ''
         |      and vehicle_code is not null and trim(vehicle_code) != ''
         |group by vehicle_id,vehicle_code
         |""".stripMargin)
    /**
     * 顺丰：每个保单对应两个统计周期：
     * 若更新日期<11.16：周期为去年11.16-今年11.15，前年11.16-去年11.15
     * 若更新日期>=11.16：周期为今年11.16-明年11.15，去年11.16-今年11.15
     *
     * '=保费/[起保日期,  终止日期]之间的天数*
     * {[统计开始时间, min(更新日期/inc_day, 统计结束日期)]和[起保日期, 终止日期]交集的天数}
     *
     * 系统自动判断：modified_tm是否是同个保单号中最大的
     */
    val buss_puls_insurance = insurance_business_df.union(insurance_compul_df)
      .join(vehicle_info, Seq("vehicle_id"), "left")
      .withColumn("stand_policy_day", concat(substring(col("inc_day"), 0, 4), lit("1116")))
      .withColumn("flag", when('inc_day < 'stand_policy_day, 1).otherwise(0))
      .persist()
    val buss_puls_insurance_1 = buss_puls_insurance.withColumn("statistics_tm", getYearOrBefore('inc_day, 'flag, lit(0))) //远周期
    val buss_puls_insurance_2 = buss_puls_insurance.withColumn("statistics_tm", getYearOrBefore('inc_day, 'flag, lit(1))) //近周期

    val buss_puls_statistics = buss_puls_insurance_1.union(buss_puls_insurance_2)
      .withColumn("statistics_start_tm", $"statistics_tm"("_1"))
      .withColumn("statistics_end_tm", $"statistics_tm"("_2"))
      .drop("statistics_tm")
      .withColumn("start_dt_new", regexp_replace(substring(col("start_dt"), 0, 10), "[/|-]", ""))
      .withColumn("end_dt_new", regexp_replace(substring(col("end_dt"), 0, 10), "[/|-]", ""))
      //[起保日期,  终止日期]之间的天数
      .withColumn("start_end_days", interDayStartToEnd('start_dt_new, 'end_dt_new))
      //min(更新日期/inc_day, 统计结束日期)
      .withColumn("min_day", when('inc_day.cast("long") > 'statistics_end_tm.cast("long"), 'statistics_end_tm).otherwise('inc_day))
      //{[统计开始时间, min(更新日期/inc_day, 统计结束日期)]和[起保日期, 终止日期]交集的天数}
      .withColumn("statistics_start_end_days", interSectionDays('statistics_start_tm, 'min_day, 'start_dt_new, 'end_dt_new))
      .withColumn("statistics_start_tm", concat_ws("-", substring('statistics_start_tm, 0, 4), substring('statistics_start_tm, 5, 2), substring('statistics_start_tm, 7, 2)))
      .withColumn("statistics_end_tm", concat_ws("-", substring('statistics_end_tm, 0, 4), substring('statistics_end_tm, 5, 2), substring('statistics_end_tm, 7, 2)))
      .withColumn("expiration_premium", ('premium.cast("double") / 'start_end_days.cast("long")) * 'statistics_start_end_days)
      .withColumn("create_modified_flag", when(timeToTimestamp_('modified_tm) > timeToTimestamp_('created_tm), 'modified_tm).otherwise('created_tm))
      .withColumn("is_new_status_flag", rank().over(Window.partitionBy("policy_no", "type").orderBy(desc("create_modified_flag"))))
      .withColumn("is_new_status", when('is_new_status_flag === 1, "是").otherwise(lit("")))
      .withColumn("inc_day", lit(start_day))
      .select(
        lit("") as "dataCode",
        col("inc_day") as "update_tm",
        col("vendor_id"), //保险公司
        regexp_replace('policy_no, "([^a-zA-Z0-9]+)", "") as "policy_no", //保单号  每天的唯一标识
        col("state"), //保单状态
        lit("") as "policy_holder",
        col("insurant"), //被保人
        col("vehicle_id"), //车辆ID
        col("vehicle_code"), //车牌号
        lit("") as "vim_code",
        lit("") as "engine_code",
        lit("") as "vehicle_type",
        col("premium"), //保费
        col("start_dt"), //起保日期
        col("end_dt"), //终止日期
        col("statistics_start_tm"),
        col("statistics_end_tm"),
        col("expiration_premium"),
        lit("") as "damage_premium",
        lit("") as "third_premium",
        lit("") as "broad_premium",
        lit("") as "robbery_premium",
        lit("") as "glass_premium",
        lit("") as "damage_no_premium",
        lit("") as "third_no_premium",
        lit("") as "broad_no_premium",
        lit("") as "robbery_no_premium",
        lit("") as "other_premium",
        col("is_new_status"),
        col("modified_tm"), //原始表更新时间
        col("created_tm"),
        col("type"), //险种
        col("inc_day") //原始表分区时间
      )
      .persist()

    //理赔表
    val insurance_claim_df = spark.sql(
      s"""
         |select
         |    id,
         |    trim(policy_no) policy_no,
         |    claim_folder_no,
         |    report_case_no,
         |    claim_detail_status,
         |    estimated_loss_amount,
         |    underwriting_amount,
         |    closing_dt as closing_dt_lp,--结案时间
         |    case_status as case_status_lp,
         |    created_emp_code,
         |    created_tm,
         |    modified_tm,
         |    inc_day
         |from dm_vms.dm_vms_insurance_claim_info_dtl_df
         |where inc_day = '$start_day'
         |""".stripMargin)
      .withColumn("policy_no", regexp_replace('policy_no, "([^a-zA-Z0-9]+)", ""))
    //报案表
    val insurance_report_df = spark.sql(
      s"""
         |select
         |    report_case_no,--报案号
         |    loss_event_dt,--出险时间
         |    loss_event_place,--出险地点
         |    case_description,--案件描述
         |    reporter_name,--报案人姓名
         |    reporter_mobile,--报案人电话
         |    report_dt,--报案时间
         |    closing_dt as closing_dt_ba,--结案时间
         |    case_status as case_status_ba,
         |    case_category,--事故类型
         |    responsibility--事故责任
         |from dm_vms.dm_vms_insurance_report_case_dtl_df
         |where inc_day = '$start_day'
         |      and report_case_no is not null and trim(report_case_no) != ''
         |""".stripMargin)

    //按已有表结构拼装字段
    val o_comp = spark.sql(s"""select * from dm_gis.report_claim_insurance_compensation_dtl limit 1""")
    val comp_cols = o_comp.schema.map(_.name).map(col)

    val claim_report = insurance_claim_df.join(insurance_report_df, Seq("report_case_no"), "left")
      .join(buss_puls_statistics.drop("modified_tm", "created_tm", "is_new_status", "inc_day"), Seq("policy_no"), "left")
      .withColumn("create_modified_flag", when(timeToTimestamp_('modified_tm) > timeToTimestamp_('created_tm), 'modified_tm).otherwise('created_tm))
      .withColumn("is_new_status_flag", rank().over(Window.partitionBy("claim_folder_no").orderBy(desc("create_modified_flag"))))
      .withColumn("is_new_status", when('is_new_status_flag === 1, "是").otherwise(lit("")))
      .withColumn("reporter_mobile",lit(""))
      .select(
        col("claim_folder_no"),
        col("report_case_no"),
        col("reporter_name"),
        col("reporter_mobile"),
        col("report_dt"),
        lit("") as "open_dt",
        col("closing_dt_lp"),
        col("closing_dt_ba"),
        lit("") as "diver",
        col("case_description"),
        lit("") as "is_wounded",
        lit("") as "wounded_type",
        col("case_category"),
        col("responsibility"),
        lit("") as "survey_descrip",
        col("policy_no"),
        col("statistics_start_tm"),
        col("statistics_end_tm"),
        col("vehicle_id"),
        col("vehicle_code"),
        col("vim_code"),
        col("engine_code"),
        lit("") as "dataCode",
        col("start_dt"),
        col("end_dt"),
        col("insurant"),
        col("type"),
        col("loss_event_place"),
        col("loss_event_dt"),
        col("case_status_lp"),
        col("case_status_ba"),
        col("claim_detail_status"),
        col("underwriting_amount"),
        col("estimated_loss_amount"),
        lit("") as "accomm_expenses",
        lit("") as "whole_expenses",
        col("damage_premium"),
        col("third_premium"),
        col("broad_premium"),
        col("robbery_premium"),
        col("glass_premium"),
        col("damage_no_premium"),
        col("third_no_premium"),
        col("broad_no_premium"),
        col("robbery_no_premium"),
        lit("") as "glass_no_premium",
        col("other_premium"),
        lit(0) as "cnt_compensation",
        lit("") as "remarks",
        col("is_new_status"),
        col("modified_tm"),
        col("created_tm"),
        col("inc_day") as "update_tm",
        col("vendor_id"),
        col("inc_day")
      )
      .select(comp_cols: _*)

    writeToHive(spark, buss_puls_statistics, Seq("inc_day"), "dm_gis.business_compulsory_insurance_policy_dtl")
    writeToHive(spark, claim_report, Seq("inc_day"), "dm_gis.report_claim_insurance_compensation_dtl")

    buss_puls_statistics.unpersist()
    buss_puls_insurance.unpersist()

  }

}
