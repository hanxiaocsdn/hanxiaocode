//package com.sf.rls
//
//import com.sf.gis.java.base.constant.FixedConstant
//import com.sf.gis.java.base.util.DateUtil
//import com.sf.gis.scala.base.spark.Spark
//import org.apache.log4j.Logger
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.{DataFrame, Row, SparkSession}
//import org.apache.spark.storage.StorageLevel
//import utils.DateUtil.getWeek
//import utils.SparkBuilder
//
//import java.text.SimpleDateFormat
//import java.util.Date
//import scala.collection.mutable
//import scala.collection.mutable.ArrayBuffer
//
///**
// * @author 01418539 411813
// * @date 2022年02月10日 9:48
// */
//object TimeReportDailyDemand {
//  val className: String = this.getClass.getSimpleName.replace("$", "")
//  @transient
//  val logger: Logger = Logger.getLogger(className)
//  var calPartitions = 100
//  //中转班次数据
//  def transferShift(spark: SparkSession, DayBefore1:String,inc_Day_bef_8d: String,DayAfter15:String) = {
//    val transferSql=
//      s"""
//         |select
//         |  start_dept
//         |  ,end_dept
//         |  ,line_distance
//         |  ,line_time
//         |  ,line_code
//         |  ,cvy_name
//         |  ,task_area_code
//         |  ,plan_depart_tm
//         |  ,last_arrive_tm
//         |  ,send_time
//         |  ,substring(regexp_replace(to_date(plan_depart_tm),"-",""),0,8) as require_inc_day
//         |  ,job_type
//         |  ,batch_type
//         |  ,inc_day
//         |from
//         |  (
//         |    select
//         |      lag(aa.dept_code, 1) over(
//         |        PARTITION BY aa.id
//         |        order by
//         |          aa.docking_sequence
//         |      ) start_dept,--始发网点
//         |      dept_code end_dept,--目的网点
//         |      distance as line_distance,--配置里程
//         |      case when times<60 then concat(times%60,"M")
//         |                when times%60=0 then concat(floor(times/60),"H")
//         |                else concat(floor(times/60),"H",times%60,"M")
//         |                end as line_time,--配置时长
//         |      line_code,--线路编码
//         |      cvy_name,--运力名称
//         |      line_belongs_code as task_area_code,--归属地区
//         |      id as table_id,--日需求表id
//         |      docking_sequence as sort_num,--次序
//         |      arrive_tm as plan_arrive_tm,--计划到车时间
//         |      arrive_batch,--到达班次
//         |      lag(aa.send_batch, 1) over(
//         |        PARTITION BY aa.id
//         |        order by
//         |          aa.docking_sequence
//         |      ) send_batch,--发出班次
//         |      lag(aa.send_tm, 1) over(
//         |        PARTITION BY aa.id
//         |        order by
//         |          aa.docking_sequence
//         |      ) plan_depart_tm,--计划发车时间
//         |      lag(aa.latest_arrival_tm, 1) over(
//         |        PARTITION BY aa.id
//         |        order by
//         |          aa.docking_sequence
//         |      ) last_arrive_tm,--最晚到车时间
//         |      send_tm as send_time,
//         |      job_type,--作业类型。1：装；2：卸；3：装卸；4：海关查验
//         |      "0" as batch_type,
//         |      '$DayBefore1' as inc_day
//         |    from
//         |      (
//         |        select
//         |          a.id,
//         |          a.line_code,
//         |          a.cvy_name,
//         |          a.line_belongs_code,
//         |          b.dept_code,
//         |          b.docking_sequence,
//         |          b.latest_arrival_tm,
//         |          b.arrive_tm,
//         |          b.arrive_batch,
//         |          b.send_tm,
//         |          b.send_batch,
//         |          b.distance,
//         |          b.times,
//         |          b.job_type
//         |        from
//         |          (
//         |            select
//         |              id,
//         |              omcs_line_code as line_code,
//         |              cvy_name,
//         |              line_belongs_code
//         |            from
//         |              dm_pass_rss.scha_tt_plan_main_pro
//         |            where
//         |              inc_day = '$DayBefore1'   --inc_day
//         |              and oper_type in (1, 2)
//         |              and status != 3
//         |              and plan_run_dt >= '$inc_Day_bef_8d'   --date1
//         |              and plan_run_dt <= '$DayAfter15'   --date2
//         |          ) a
//         |          inner join (
//         |            select
//         |              plan_main_id,
//         |              dept_code,
//         |              docking_sequence,
//         |              latest_arrival_tm,
//         |              arrive_tm,
//         |              arrive_batch,
//         |              send_tm,
//         |              send_batch,
//         |              distance,
//         |              times,
//         |              job_type,
//         |              point_type
//         |            from
//         |              dm_pass_rss.scha_tt_plan_point_pro
//         |            where
//         |              inc_day = '$DayBefore1'   --inc_day
//         |              and plan_run_dt >= '$inc_Day_bef_8d'  --date1
//         |              and plan_run_dt <= '$DayAfter15'  --date2
//         |          ) b on a.id = b.plan_main_id
//         |        order by
//         |          id,
//         |          docking_sequence
//         |      ) aa
//         |  ) bb
//         |where
//         |  bb.start_dept is not null
//         |""".stripMargin
//    val transferDf = spark.sql(transferSql).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val transferRdd: RDD[Row] = transferDf.rdd
//    transferRdd.take(10).foreach(println(_))
//    logger.error("中转数据量："+transferRdd.count())
//    transferRdd
//  }
//  case class paiCangSourceData(start_dept: String,
//                               line_code: String,
//                               un_effective_tm: String,
//                               effective_tm: String,
//                               workday: String,
//                               rows:mutable.Seq[(String)],
//                               inc_day: String
//                              )
//  //派仓班次数据
//  def paicangShift(spark: SparkSession, DayBefore1:String,inc_Day: String,inc_Day_bef_8d:String) = {
//    import spark.implicits._
//    val paicangSql=
//      s"""
//         |select
//         |  operate_zone_code as start_dept,
//         |  batch_code as line_code,
//         |  un_effective_tm,  --失效日期
//         |  effective_tm,  --生效日期
//         |  workday, -- 适用工作日
//         |  concat(substring(last_arrive_tm, 2, 5),':00') as latest_arrival_tm,
//         | '$DayBefore1' as inc_day
//         |from
//         |  dm_pass_rss.sbsa_tm_deliver_depot_pro
//         |where
//         |  inc_day = '$DayBefore1'
//         |  and delete_flg = 0
//         |  and un_effective_tm >= '$inc_Day_bef_8d'
//         |""".stripMargin
//    val paicangDf: DataFrame = spark.sql(paicangSql)
//    val paicangDf1: DataFrame = paicangDf.rdd.repartition(calPartitions).map(obj => {
//      val start_dept: String = obj.getString(0)
//      val line_code: String = obj.getString(1)
//      val un_effective_tm: String = obj.getDate(2).toString
//      val un_effective_tm_int: Int = un_effective_tm.replaceAll("-", "").toInt
//      val effective_tm: String = obj.getDate(3).toString
//      val effective_tm_int: Int = effective_tm.replaceAll("-", "").toInt
//      val workday: String = obj.getString(4)
//      var latest_arrival_tm: String = obj.getString(5)
//      val inc_day: String = obj.getString(6)
//      val dateArray = new ArrayBuffer[Int]()
//      for (i <- 0 to 15) {
//        val date: Int = DateUtil.getDayAfter(inc_Day, "yyyy-MM-dd", i).replaceAll("-", "").toInt
//        dateArray.append(date)
//      }
//      dateArray.foreach(println(_))
//      var require_inc_day: String = ""
//      //var tag =""
//      var dateWeek: String = ""
//      val format1 = new SimpleDateFormat("yyyyMMdd")
//      val format2 = new SimpleDateFormat("yyyy-MM-dd")
//      val rows= new ArrayBuffer[(String)]()
//      //var latest_arrival_tm_tmp=""
//      //var require_inc_day_tmp=""
//      //var dateWeek_tmp =""
//      var row_tmp=""
//      for (i <- 0 until dateArray.size) {
//        dateWeek= getWeek(dateArray(i).toString)
//        latest_arrival_tm= obj.getString(5)
//        if (dateArray(i) <= un_effective_tm_int && dateArray(i) >= effective_tm_int && workday.contains(dateWeek)) {
//          val date1: Date = format1.parse(dateArray(i).toString)
//          val date2: String = format2.format(date1)
//          latest_arrival_tm = date2 + " " + latest_arrival_tm
//          require_inc_day = dateArray(i).toString
//          row_tmp=latest_arrival_tm+","+require_inc_day+","+dateWeek
//          //latest_arrival_tm_tmp=latest_arrival_tm+";"+latest_arrival_tm_tmp
//          //require_inc_day_tmp=require_inc_day+";"+require_inc_day_tmp
//          //dateWeek_tmp=dateWeek+";"+dateWeek_tmp
//          //tag = "yes"
//          //logger.error("====>>>>>>进入最晚到车时间判断语句")
//          //rows.append(Row(start_dept, "", "", "", line_code, "", "", "", latest_arrival_tm, "", require_inc_day, "", "1", inc_day, un_effective_tm_int, effective_tm_int, dateWeek, workday))
//          rows.append(row_tmp)
//        }
//      }
//      paiCangSourceData(start_dept,line_code,un_effective_tm, effective_tm, workday,rows,inc_day)
//    }).toDF()
//    paicangDf1.createOrReplaceTempView("paicangShiftTmp")
//    val paicangShiftSql: String =
//      """
//        |select
//        |start_dept
//        |,line_code
//        |,un_effective_tm
//        |,effective_tm
//        |,workday
//        |,explode_rows
//        |,inc_day
//        |from paicangShiftTmp
//        |LATERAL VIEW explode(rows) tmp as explode_rows
//        |""".stripMargin
//    val frame: DataFrame = spark.sql(paicangShiftSql)
//    val paicangRdd: RDD[Row] = frame.rdd.map(obj => {
//      val rowArray: Array[String] = obj.getString(5).split(",")
//      Row(obj.getString(0), "", "", "", obj.getString(1), "", "", "", rowArray(0), "", rowArray(1), "", "1", obj.getString(6), obj.getString(2), obj.getString(3), rowArray(2), obj.getString(4))
//    }).filter(obj => {
//      !obj.getString(10).equals("")
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    //paicangRdd.filter(obj=>{obj.getString(14).equals("yes")}).take(10).foreach(println(_))
//    paicangRdd.take(10).foreach(println(_))
//    logger.error("派仓数据量："+paicangRdd.count())
//    paicangRdd
//  }
//  //航管班次数据
//  def airTrafficControlShift(spark: SparkSession, DayBefore1: String, inc_Day_bef_8d: String, DayAfter15: String) = {
//    val airTrafficControlSql =
//      s"""
//         |select
//         |  src_dept_code as start_dept,
//         |  "" as end_dept,
//         |  "" as line_distance,
//         |  "" as line_time,
//         |  cvy_name as line_code,--20220124:将cvy_name作为line_code
//         |  cvy_name,
//         |  line_belongs_code as task_area_code,
//         |  "" as plan_depart_tm,
//         |  lastest_arrive_tm as latest_arrival_tm,
//         |  src_send_tm as send_time,
//         |  substring(regexp_replace(to_date(src_send_tm),"-",""),0,8) as require_inc_day,
//         |  "" as job_type,
//         |  "2" as batch_type,
//         |  '$DayBefore1' as inc_day
//         |from
//         |  dm_pass_rss.aira_tm_air_transport_batch_pro
//         |where
//         |  inc_day = '$DayBefore1'
//         |  and send_date >= '$inc_Day_bef_8d'
//         |  and send_date <= '$DayAfter15'
//         |  and practical_cvy_type = 1
//         |  and lastest_arrive_tm !=''
//         |""".stripMargin
//    val airRrafficControlDf: DataFrame = spark.sql(airTrafficControlSql).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val airRrafficControlRdd: RDD[Row] = airRrafficControlDf.rdd
//    airRrafficControlRdd.take(10).foreach(println(_))
//    logger.error("航管数据量："+airRrafficControlRdd.count())
//    airRrafficControlRdd
//  }
//  case class timeReportDaily(start_dept: String,
//                             end_dept: String,
//                             line_distance: String,
//                             line_time: String,
//                             line_code: String,
//                             cvy_name: String,
//                             task_area_code: String,
//                             plan_depart_tm: String,
//                             latest_arrival_tm: String,
//                             send_time: String,
//                             require_inc_day: String,
//                             job_type: String,
//                             batch_type: String,
//                             inc_day: String
//                            )
//  def save2Hive(spark: SparkSession, resultRdd: RDD[Row]) = {
//    import spark.implicits._
//    val resultDf: DataFrame = resultRdd.map(obj => {
//      //val Md5Id = System.currentTimeMillis().toString + obj.getAs[String]("task_area_code") + obj.getAs[String]("line_code")+rand("")
//      timeReportDaily(
//        obj.getString(0),
//        obj.getString(1),
//        obj.getString(2),
//        obj.get(3) match {
//          case null => obj.getString(3)
//          case _ => obj.get(3).toString
//        },
//        obj.getString(4),
//        obj.getString(5),
//        obj.getString(6),
//        obj.getString(7),
//        obj.getString(8),
//        obj.getString(9),
//        obj.get(10) match {
//          case null => obj.getString(10)
//          case _ => obj.get(10).toString
//        },
//        obj.get(11) match {
//          case null => obj.getString(11)
//          case _ => obj.get(11).toString
//        },
//        obj.getString(12),
//        obj.getString(13))
//    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rdd: RDD[Row] = resultDf.rdd
//    rdd.take(10).foreach(println(_))
//    resultDf.createOrReplaceTempView("timeReportDailyTableTmp")
//    val insert_sql = "insert overwrite table dm_gis.dm_time_report_daily_dtl_di partition(inc_day) select row_number() over(partition by 1 order by plan_depart_tm asc) as id,* from timeReportDailyTableTmp"
//    spark.sql(insert_sql)
//  }
//
//  case class paiCangData(start_dept: String,
//                         end_dept: String,
//                         line_distance: String,
//                         line_time: String,
//                         line_code: String,
//                         cvy_name: String,
//                         task_area_code: String,
//                         plan_depart_tm: String,
//                         latest_arrival_tm: String,
//                         send_time: String,
//                         require_inc_day: String,
//                         job_type: String,
//                         batch_type: String,
//                         inc_day: String,
//                         un_effective_tm_int: String,
//                         effective_tm_int: String,
//                         dateWeek: String,
//                         workday: String
//                        )
//  //测试用表
//  def paiCangSave2Hive(spark: SparkSession, paicangRdd: RDD[Row]) = {
//    import spark.implicits._
//    val value: DataFrame = paicangRdd.map(obj => {
//      paiCangData(obj.getString(0),
//        obj.getString(1),
//        obj.getString(2),
//        obj.get(3).toString,
//        obj.getString(4),
//        obj.getString(5),
//        obj.getString(6),
//        obj.getString(7),
//        obj.getString(8),
//        obj.getString(9),
//        obj.get(10).toString,
//        obj.getString(11),
//        obj.getString(12),
//        obj.getString(13),
//        obj.get(14).toString,
//        obj.get(15).toString,
//        obj.get(16).toString,
//        obj.get(17).toString
//      )
//    }).toDF().persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rdd: RDD[Row] = value.rdd
//    rdd.take(10).foreach(println(_))
//    value.createOrReplaceTempView("paiCangTableTmp")
//    val insert_sql = "insert overwrite table dm_gis.dm_paicang_tmp_mid select * from paiCangTableTmp"
//    spark.sql(insert_sql)
//  }
//
//
//  //spark入口
//  def execute(incDay: String) = {
//    val spark: SparkSession = SparkBuilder.initSpark(className)
////    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
//    spark.sparkContext.setLogLevel(FixedConstant.LOG_LEVEL_ERROR)
//    val (excutors, cores) = Spark.getExcutorInfo(spark)
//    calPartitions = excutors * cores * 4
//    val DayBefore1: String = DateUtil.getDayBefore(incDay, "yyyy-MM-dd", 1).replace("-","")
//    val inc_Day: String = DateUtil.getDayBefore(incDay, "yyyy-MM-dd", 0)
//    val inc_Day_bef_8d: String = DateUtil.getDayBefore(incDay, "yyyy-MM-dd", 8)
//    val DayAfter15: String = DateUtil.getDayAfter(incDay, "yyyy-MM-dd", 15)
//
//    logger.error("获取中转班次数据")
//    val transferDf: RDD[Row] = transferShift(spark, DayBefore1,inc_Day_bef_8d,DayAfter15)
//    logger.error("获取派仓班次数据")
//    val paicangRdd: RDD[Row] = paicangShift(spark, DayBefore1, inc_Day, inc_Day_bef_8d)
//    logger.error("派仓数据入表")
//    paiCangSave2Hive(spark,paicangRdd)
//    logger.error("获取航管班次数据")
//    val airTrafficControlRdd: RDD[Row] = airTrafficControlShift(spark, DayBefore1, inc_Day_bef_8d, DayAfter15)
//    logger.error("关联三类数据")
//    val resultRdd: RDD[Row] = transferDf.union(paicangRdd).union(airTrafficControlRdd)
//    logger.error("保存数据到结果表")
//    save2Hive(spark,resultRdd)
//  }
//
//  def main(args: Array[String]): Unit = {
//    val incDay = args(0)
//    execute(incDay)
//    logger.error("======>>>>>>timeReportDailyDemand Execute Ok")
//  }
//}
//
