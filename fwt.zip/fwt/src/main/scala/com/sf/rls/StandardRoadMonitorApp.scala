package com.sf.rls

import com.sf.common.ColumnCommon.{md5EncryptUDF, notNullDef}
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SparkSession}
import utils.SparkBuilder

/**
 * task_id : 409306（已下线并删除）
   @author 01418539
   @date 2022年01月18日 19:04
 */
object StandardRoadMonitorApp extends DataSourceCommon with Serializable {
  def main(args: Array[String]): Unit = {
    //spark初始化 参数配置
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val start_time = args(0)
    val end_time = args(1)

    val middle_navi_df = loadInitialData(spark, start_time, end_time)
    writeToHive(spark, middle_navi_df, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_standard")
    val res = naviConvertRejion(spark, middle_navi_df)
    writeToHive(spark, res._1, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_conv_rejion")
    writeToHive(spark, res._2, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_conv_source")
    writeToHive(spark, res._3, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_use_rejion")
    writeToHive(spark, res._4, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_use_source")
    writeToHive(spark, res._5, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_sf_use_rejion")
    writeToHive(spark, res._6, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_sf_use_source")
    writeToHive(spark, res._7, Seq("inc_day"), "dm_gis.dwd_gis_std_navi_task_mileage_com")
  }

  def loadInitialData(spark: SparkSession, start_time: String, end_time: String): DataFrame = {
    import spark.implicits._
    val initial_df = spark.sql(
      s"""
         |select task_id,
         |       navi_id,
         |       recall_src as std_src,--标准线路来源
         |       task_area_code,
         |       --task_area_code regexp '^[0-9]' as flag,
         |       is_halfway_integrate,--融合轨迹是否有效
         |       is_run_ontime,
         |       recall1_conduct_type,--是否执行标准线路 1:执行3:未执行
         |       navi_time,--导航用时（秒）
         |       actual_run_time,--实际运行时长(min)
         |       recall_actual_run_time,
         |       recall_line_distance,--规划里程（单位km）
         |       recall_log_dist,--码表里程（单位km）
         |       recall_rt_dist/1000 as recall_rt_dist,--任务实际里程（单位km）
         |       is_sdk,--是否进入SDK 1：是 0：否 int
         |       is_navi,--int
         |       startsrc_dist,--double
         |       endsrc_dist,--double
         |       stdid,
         |       strategy,
         |       navi_strategy,
         |       sdk_navi_type,
         |       inc_day
         |from dm_gis.dwd_gis_navi_detail_daily
         |where inc_day >= '$start_time' and inc_day <= '$end_time'
         |       and task_id is not null and trim(task_id) !=''
         |       and is_std = 1
         |       and start_type != '1'
         |       and end_type != '1'
         |       and is_run_ontime in (0, 1)
         |       and (validity_vehicle is not null and validity_phone is not null and halfway_integrate_rate is not null)
         |""".stripMargin)
    val pub_cond1 = $"is_sdk" === 1 && $"startsrc_dist" <= 500 && $"endsrc_dist" > 500 && notNullDef($"stdid")

    val middle_navi_df_1: DataFrame = initial_df.filter(substring(trim(col("task_area_code")),1,1).isin("0","1","2","3","4","5","6","7","8","9"))
      .withColumn("navi_time_t", replaceCol($"navi_time")) //导航时长
      .withColumn("actual_run_time", replaceCol($"recall_actual_run_time")) //	实际运行时长(min)
      .withColumn("line_distance", replaceCol($"recall_line_distance"))
      .withColumn("log_dist", replaceCol($"recall_log_dist"))
      .withColumn("rt_dist", replaceCol($"recall_rt_dist"))
      .withColumn("is_sdk_t", when($"is_sdk" === 1, 1).otherwise(0)) //直接task_id维度
      .withColumn("is_sdk_dis", when($"is_sdk" === 1 && $"startsrc_dist" <= 500 && $"endsrc_dist" > 500, 1).otherwise(0)) //是否进入sdk+
      .withColumn("is_a_std", when(pub_cond1, 1).otherwise(0)) //是否请求标准线路
      .withColumn("is_re_std", when(pub_cond1 && $"strategy".isin("21", "22"), 1).otherwise(0)) //是否返回标准线路
      .withColumn("is_cho_std_line", when(pub_cond1 && $"navi_strategy".isin("21", "22"), 1).otherwise(0)) //是否选择标准线路
      .withColumn("is_navi_t", when(pub_cond1 && $"is_navi" === 1, 1).otherwise(0)) //是否使用导航
      .withColumn("is_sf", when(pub_cond1 && trim($"sdk_navi_type").isin("sf_SDK", "gd_SDK"), 1).otherwise(0)) //是否使用导航
      .withColumn("is_sfsdk", when(pub_cond1 && trim($"sdk_navi_type") === "sf_SDK", 1).otherwise(0)) //是否使用顺丰SDK导航
      .withColumn("is_gdsdk", when(pub_cond1 && trim($"sdk_navi_type") === "gd_SDK", 1).otherwise(0)) //是否使用高德SDK导航
      .groupBy(col("task_id"),col("navi_id"), col("std_src"), col("task_area_code"), col("is_run_ontime"), col("is_halfway_integrate"), col("recall1_conduct_type"), col("inc_day"))
      .agg(
        max($"navi_time_t") as "navi_time",
        sum($"actual_run_time") as "actual_run_time",
        sum($"line_distance") as "line_distance",
        sum($"log_dist") as "log_dist",
        sum($"rt_dist") as "rt_dist",
        max($"is_sdk_t") as "is_sdk",
        max($"is_sdk_dis") as "is_sdk_dis",
        max($"is_a_std") as "is_a_std",
        max($"is_re_std") as "is_re_std",
        max($"is_cho_std_line") as "is_cho_std_line",
        max($"is_navi_t") as "is_navi",
        max($"is_sf") as "is_sf",
        max($"is_sfsdk") as "is_sfsdk",
        max($"is_gdsdk") as "is_gdsdk"
      )
      .groupBy(col("task_id"), col("std_src"), col("task_area_code"), col("is_run_ontime"), col("is_halfway_integrate"), col("recall1_conduct_type"), col("inc_day"))
      .agg(
        sum($"navi_time") as "navi_time",
        max($"actual_run_time") as "actual_run_time",
        max($"line_distance") as "line_distance",
        max($"log_dist") as "log_dist",
        max($"rt_dist") as "rt_dist",
        max($"is_sdk") as "is_sdk",
        max($"is_sdk_dis") as "is_sdk_dis",
        max($"is_a_std") as "is_a_std",
        max($"is_re_std") as "is_re_std",
        max($"is_cho_std_line") as "is_cho_std_line",
        max($"is_navi") as "is_navi",
        max($"is_sf") as "is_sf",
        max($"is_sfsdk") as "is_sfsdk",
        max($"is_gdsdk") as "is_gdsdk"
      )

    val middle_navi_df_2 = middle_navi_df_1.groupBy(col("task_id"), col("task_area_code"), col("is_run_ontime"), col("is_halfway_integrate"), col("recall1_conduct_type"), col("inc_day"))
      .agg(
        sum("navi_time") as "navi_time",
        sum("actual_run_time") as "actual_run_time"
      )
      .withColumn("navitm_rate", when($"actual_run_time" =!= 0, $"navi_time" / ($"actual_run_time" * 60)).otherwise(0))

    val middle_navi_df = middle_navi_df_1.drop("navi_time","actual_run_time")
      .join(middle_navi_df_2,Seq("task_id", "task_area_code", "is_run_ontime", "is_halfway_integrate", "recall1_conduct_type", "inc_day"),"left")
      .na.fill(0, Seq("line_distance", "log_dist", "rt_dist", "is_sdk", "is_sdk_dis",
      "is_a_std", "is_re_std", "is_cho_std_line", "is_navi", "is_sf", "is_sfsdk", "is_gdsdk"))
      .select(
        col("task_id"),
        col("std_src"),
        col("task_area_code"),
        col("is_halfway_integrate"),
        col("is_run_ontime"),
        col("recall1_conduct_type"),
        middle_navi_df_2.col("navi_time") as "navi_time",
        middle_navi_df_2.col("actual_run_time") as "actual_run_time",
        col("line_distance"),
        col("log_dist"),
        col("rt_dist"),
        col("is_sdk"),
        col("is_sdk_dis"),
        col("is_a_std"),
        col("is_re_std"),
        col("is_cho_std_line"),
        col("is_navi"),
        col("is_sf"),
        col("is_sfsdk"),
        col("is_gdsdk"),
        col("navitm_rate"),
        col("inc_day"))
    middle_navi_df
  }

     def naviConvertRejion(spark: SparkSession, middleDf: DataFrame): (DataFrame, DataFrame, DataFrame, DataFrame, DataFrame, DataFrame, DataFrame) = {
     import spark.implicits._
     val naviDf_tmp = middleDf
     //2.1导航转化情况[大区] 2.2与2.1维度不同
     .withColumn("task_cn", lit(1))
     .withColumn("sdk_cn", when($"is_sdk" === 1, 1).otherwise(0))
     .withColumn("sdk_dis_cn", when($"is_sdk_dis" === 1, 1).otherwise(0))
     .withColumn("a_std_cn", when($"is_a_std" === 1, 1).otherwise(0))
     .withColumn("re_std_cn", when($"is_re_std" === 1, 1).otherwise(0))
     .withColumn("cho_std_cn", when($"is_cho_std_line" === 1, 1).otherwise(0))
     .withColumn("navi_cn", when($"is_cho_std_line" === 1 && $"is_navi" === 1, 1).otherwise(0))
     .withColumn("sf_cn", when($"is_sf" === 1, 1).otherwise(0))
     .withColumn("sf_75rate_cn", when($"is_sf" === 1 && $"navitm_rate" > 0.75, 1).otherwise(0))
     .withColumn("sf_75ontime_cn", when($"is_sf" === 1 && $"navitm_rate" > 0.75 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("sf_75overtime_cn", when($"is_sf" === 1 && $"navitm_rate" > 0.75 && $"is_run_ontime" === 0, 1).otherwise(0))
     //2.3导航使用情况[大区]  2.4与2.3维度不同
     .withColumn("nosdk_cn", when($"is_sdk" === 0, 1).otherwise(0))
     .withColumn("nosdk_otcn", when($"is_sdk" === 0 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("nosdk_yxcn", when($"is_sdk" === 0 && $"is_halfway_integrate" === "有效", 1).otherwise(0))
     .withColumn("nosdk_cdcn", when($"is_sdk" === 0 && $"recall1_conduct_type" === 1, 1).otherwise(0))
     .withColumn("nonavi_cn", when($"is_sdk" === 1 && $"is_navi" === 0, 1).otherwise(0))
     .withColumn("nonavi_otcn", when($"is_sdk" === 1 && $"is_navi" === 0 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("nonavi_yxcn", when($"is_sdk" === 1 && $"is_navi" === 0 && $"is_halfway_integrate" === "有效", 1).otherwise(0))
     .withColumn("nonavi_cdcn", when($"is_sdk" === 1 && $"is_navi" === 0 && $"recall1_conduct_type" === 1, 1).otherwise(0))
     .withColumn("navi_cn_t", when($"is_navi" === 1, 1).otherwise(0))
     .withColumn("navi_otcn", when($"is_navi" === 1 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("navi_yxcn", when($"is_navi" === 1 && $"is_halfway_integrate" === "有效", 1).otherwise(0))
     .withColumn("navi_cdcn", when($"is_navi" === 1 && $"recall1_conduct_type" === 1, 1).otherwise(0))
     .withColumn("sf_ontime_cn", when($"is_sf" === 1 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("sf_overtime_cn", when($"is_sf" === 1 && $"is_run_ontime" === 0, 1).otherwise(0))
     .withColumn("sfsdk_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1, 1).otherwise(0))
     .withColumn("sfsdk_ontime_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("sfsdk_overtime_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"is_run_ontime" === 0, 1).otherwise(0))
     .withColumn("gdsdk_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1, 1).otherwise(0))
     .withColumn("gdsdk_ontime_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("gdsdk_overtime_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"is_run_ontime" === 0, 1).otherwise(0))
     .withColumn("gdapp_cn", when($"is_navi" === 1 && $"is_sf" === 0, 1).otherwise(0))
     .withColumn("gdapp_ontime_cn", when($"is_navi" === 1 && $"is_sf" === 0 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("gdapp_overtime_cn", when($"is_navi" === 1 && $"is_sf" === 0 && $"is_run_ontime" === 0, 1).otherwise(0))
     //2.5 顺丰导航使用情况 2.6与2.5维度不同
     //up75_cn up75_ontime_cn up75_overtime_cn 与sf_75rate_cn sf_75ontime_cn sf_75overtime_cn
     .withColumn("d75_cn", when($"is_sf" === 1 && $"navitm_rate" <= 0.75, 1).otherwise(0))
     .withColumn("d75_ontime_cn", when($"is_sf" === 1 && $"navitm_rate" <= 0.75 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("d75_overtime_cn", when($"is_sf" === 1 && $"navitm_rate" <= 0.75 && $"is_run_ontime" === 0, 1).otherwise(0))
     .withColumn("sfsdk_up75_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"navitm_rate" > 0.75, 1).otherwise(0))
     .withColumn("sfsdk_up75_ontime_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"navitm_rate" > 0.75 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("sfsdk_up75_overtime_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"navitm_rate" > 0.75 && $"is_run_ontime" === 0, 1).otherwise(0))
     .withColumn("sfsdk_d75_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"navitm_rate" <= 0.75, 1).otherwise(0))
     .withColumn("sfsdk_d75_ontime_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"navitm_rate" <= 0.75 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("sfsdk_d75_overtime_cn", when($"is_sf" === 1 && $"is_sfsdk" === 1 && $"navitm_rate" <= 0.75 && $"is_run_ontime" === 0, 1).otherwise(0))
     .withColumn("gdsdk_up75_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"navitm_rate" > 0.75, 1).otherwise(0))
     .withColumn("gdsdk_up75_ontime_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"navitm_rate" > 0.75 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("gdsdk_up75_overtime_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"navitm_rate" > 0.75 && $"is_run_ontime" === 0, 1).otherwise(0))
     .withColumn("gdsdk_d75_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"navitm_rate" <= 0.75, 1).otherwise(0))
     .withColumn("gdsdk_d75_ontime_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"navitm_rate" <= 0.75 && $"is_run_ontime" === 1, 1).otherwise(0))
     .withColumn("gdsdk_d75_overtime_cn", when($"is_sf" === 1 && $"is_gdsdk" === 1 && $"navitm_rate" <= 0.75 && $"is_run_ontime" === 0, 1).otherwise(0))
     //2.7 导航任务里程对比
     val naviDf = naviDf_tmp
     .withColumn("line_distance_t", when($"is_navi" === 1, $"line_distance").otherwise(0))
     .withColumn("log_dist_t", when($"is_navi" === 1, $"log_dist").otherwise(0))
     .withColumn("rt_dist_t", when($"is_navi" === 1, $"rt_dist").otherwise(0))
     .withColumn("sf_line_distance", when($"is_sf" === 1, $"line_distance").otherwise(0))
     .withColumn("sf_log_dist", when($"is_sf" === 1, $"log_dist").otherwise(0))
     .withColumn("sf_rt_dist", when($"is_sf" === 1, $"rt_dist").otherwise(0))
     .withColumn("notsf_line_distance", when($"is_navi" === 1 && $"is_sf" === 0, $"line_distance").otherwise(0))
     .withColumn("notsf_log_dist", when($"is_navi" === 1 && $"is_sf" === 0, $"log_dist").otherwise(0))
     .withColumn("notsf_rt_dist", when($"is_navi" === 1 && $"is_sf" === 0, $"rt_dist").otherwise(0))
     .withColumn("up75_line_distance", when($"is_sf" === 1 && $"navitm_rate" > 0.75, $"line_distance").otherwise(0))
     .withColumn("up75_log_dist", when($"is_sf" === 1 && $"navitm_rate" > 0.75, $"log_dist").otherwise(0))
     .withColumn("up75_rt_dist", when($"is_sf" === 1 && $"navitm_rate" > 0.75, $"rt_dist").otherwise(0))
     .withColumn("d75_line_distance", when($"is_sf" === 1 && $"navitm_rate" <= 0.75, $"line_distance").otherwise(0))
     .withColumn("d75_log_dist", when($"is_sf" === 1 && $"navitm_rate" <= 0.75, $"log_dist").otherwise(0))
     .withColumn("d75_rt_dist", when($"is_sf" === 1 && $"navitm_rate" <= 0.75, $"rt_dist").otherwise(0))
     middleDf.unpersist()
     naviDf.persist()
     val navi_2_1 = naviDf.groupBy("task_area_code", "task_id", "inc_day")
     .agg(
     max("task_cn") as "task_cn",
     max("sdk_cn") as "sdk_cn",
     max("sdk_dis_cn") as "sdk_dis_cn",
     max("a_std_cn") as "a_std_cn",
     max("re_std_cn") as "re_std_cn",
     max("cho_std_cn") as "cho_std_cn",
     max("navi_cn") as "navi_cn",
     max("sf_cn") as "sf_cn",
     max("sf_75rate_cn") as "sf_75rate_cn",
     max("sf_75ontime_cn") as "sf_75ontime_cn",
     max("sf_75overtime_cn") as "sf_75overtime_cn"
     )
     .groupBy("task_area_code", "inc_day")
     .agg(
     sum("task_cn") as "task_cn",
     sum("sdk_cn") as "sdk_cn",
     sum("sdk_dis_cn") as "sdk_dis_cn",
     sum("a_std_cn") as "a_std_cn",
     sum("re_std_cn") as "re_std_cn",
     sum("cho_std_cn") as "cho_std_cn",
     sum("navi_cn") as "navi_cn",
     sum("sf_cn") as "sf_cn",
     sum("sf_75rate_cn") as "sf_75rate_cn",
     sum("sf_75ontime_cn") as "sf_75ontime_cn",
     sum("sf_75overtime_cn") as "sf_75overtime_cn"
     )
     .withColumn("id", md5EncryptUDF(col("task_area_code"), col("inc_day"), lit(""), lit("")))
     .select("id", "task_area_code", "task_cn", "sdk_cn", "sdk_dis_cn", "a_std_cn", "re_std_cn",
     "cho_std_cn", "navi_cn", "sf_cn", "sf_75rate_cn", "sf_75ontime_cn", "sf_75overtime_cn", "inc_day")

     val navi_2_2 = naviDf.groupBy("task_area_code", "std_src", "task_id", "inc_day")
     .agg(
     max("task_cn") as "task_cn",
     max("sdk_cn") as "sdk_cn",
     max("sdk_dis_cn") as "sdk_dis_cn",
     max("a_std_cn") as "a_std_cn",
     max("re_std_cn") as "re_std_cn",
     max("cho_std_cn") as "cho_std_cn",
     max("navi_cn") as "navi_cn",
     max("sf_cn") as "sf_cn",
     max("sf_75rate_cn") as "sf_75rate_cn",
     max("sf_75ontime_cn") as "sf_75ontime_cn",
     max("sf_75overtime_cn") as "sf_75overtime_cn"
     )
     .groupBy("task_area_code", "std_src", "inc_day")
     .agg(
     sum("task_cn") as "task_cn",
     sum("sdk_cn") as "sdk_cn",
     sum("sdk_dis_cn") as "sdk_dis_cn",
     sum("a_std_cn") as "a_std_cn",
     sum("re_std_cn") as "re_std_cn",
     sum("cho_std_cn") as "cho_std_cn",
     sum("navi_cn") as "navi_cn",
     sum("sf_cn") as "sf_cn",
     sum("sf_75rate_cn") as "sf_75rate_cn",
     sum("sf_75ontime_cn") as "sf_75ontime_cn",
     sum("sf_75overtime_cn") as "sf_75overtime_cn"
     )
     .withColumn("id", md5EncryptUDF(col("task_area_code"), col("inc_day"), col("std_src"), lit("")))
     .select("id", "task_area_code", "std_src", "task_cn", "sdk_cn", "sdk_dis_cn", "a_std_cn", "re_std_cn",
     "cho_std_cn", "navi_cn", "sf_cn", "sf_75rate_cn", "sf_75ontime_cn", "sf_75overtime_cn", "inc_day")

     val navi_2_3 = naviDf.groupBy("task_area_code", "task_id", "inc_day")
     .agg(
     max("nosdk_cn") as "nosdk_cn",
     max("nosdk_otcn") as "nosdk_otcn",
     max("nosdk_yxcn") as "nosdk_yxcn",
     max("nosdk_cdcn") as "nosdk_cdcn",
     max("nonavi_cn") as "nonavi_cn",
     max("nonavi_otcn") as "nonavi_otcn",
     max("nonavi_yxcn") as "nonavi_yxcn",
     max("nonavi_cdcn") as "nonavi_cdcn",
     max("navi_cn_t") as "navi_cn",
     max("navi_otcn") as "navi_otcn",
     max("navi_yxcn") as "navi_yxcn",
     max("navi_cdcn") as "navi_cdcn",
     max("sf_cn") as "sf_cn",
     max("sf_ontime_cn") as "sf_ontime_cn",
     max("sf_overtime_cn") as "sf_overtime_cn",
     max("sfsdk_cn") as "sfsdk_cn",
     max("sfsdk_ontime_cn") as "sfsdk_ontime_cn",
     max("sfsdk_overtime_cn") as "sfsdk_overtime_cn",
     max("gdsdk_cn") as "gdsdk_cn",
     max("gdsdk_ontime_cn") as "gdsdk_ontime_cn",
     max("gdsdk_overtime_cn") as "gdsdk_overtime_cn",
     max("gdapp_cn") as "gdapp_cn",
     max("gdapp_ontime_cn") as "gdapp_ontime_cn",
     max("gdapp_overtime_cn") as "gdapp_overtime_cn"
     )
     .groupBy("task_area_code", "inc_day")
     .agg(
     sum("nosdk_cn") as "nosdk_cn",
     sum("nosdk_otcn") as "nosdk_otcn",
     sum("nosdk_yxcn") as "nosdk_yxcn",
     sum("nosdk_cdcn") as "nosdk_cdcn",
     sum("nonavi_cn") as "nonavi_cn",
     sum("nonavi_otcn") as "nonavi_otcn",
     sum("nonavi_yxcn") as "nonavi_yxcn",
     sum("nonavi_cdcn") as "nonavi_cdcn",
     sum("navi_cn") as "navi_cn",
     sum("navi_otcn") as "navi_otcn",
     sum("navi_yxcn") as "navi_yxcn",
     sum("navi_cdcn") as "navi_cdcn",
     sum("sf_cn") as "sf_cn",
     sum("sf_ontime_cn") as "sf_ontime_cn",
     sum("sf_overtime_cn") as "sf_overtime_cn",
     sum("sfsdk_cn") as "sfsdk_cn",
     sum("sfsdk_ontime_cn") as "sfsdk_ontime_cn",
     sum("sfsdk_overtime_cn") as "sfsdk_overtime_cn",
     sum("gdsdk_cn") as "gdsdk_cn",
     sum("gdsdk_ontime_cn") as "gdsdk_ontime_cn",
     sum("gdsdk_overtime_cn") as "gdsdk_overtime_cn",
     sum("gdapp_cn") as "gdapp_cn",
     sum("gdapp_ontime_cn") as "gdapp_ontime_cn",
     sum("gdapp_overtime_cn") as "gdapp_overtime_cn"
     )
     .withColumn("id", md5EncryptUDF(col("task_area_code"), col("inc_day"), lit(""), lit("")))
     .select(
     "id",
     "task_area_code",
     "nosdk_cn",
     "nosdk_otcn",
     "nosdk_yxcn",
     "nosdk_cdcn",
     "nonavi_cn",
     "nonavi_otcn",
     "nonavi_yxcn",
     "nonavi_cdcn",
     "navi_cn",
     "navi_otcn",
     "navi_yxcn",
     "navi_cdcn",
     "sf_cn",
     "sf_ontime_cn",
     "sf_overtime_cn",
     "sfsdk_cn",
     "sfsdk_ontime_cn",
     "sfsdk_overtime_cn",
     "gdsdk_cn",
     "gdsdk_ontime_cn",
     "gdsdk_overtime_cn",
     "gdapp_cn",
     "gdapp_ontime_cn",
     "gdapp_overtime_cn",
     "inc_day")

     val navi_2_4 = naviDf.groupBy("task_area_code", "std_src", "task_id", "inc_day")
     .agg(
     max("nosdk_cn") as "nosdk_cn",
     max("nosdk_otcn") as "nosdk_otcn",
     max("nosdk_yxcn") as "nosdk_yxcn",
     max("nosdk_cdcn") as "nosdk_cdcn",
     max("nonavi_cn") as "nonavi_cn",
     max("nonavi_otcn") as "nonavi_otcn",
     max("nonavi_yxcn") as "nonavi_yxcn",
     max("nonavi_cdcn") as "nonavi_cdcn",
     max("navi_cn_t") as "navi_cn",
     max("navi_otcn") as "navi_otcn",
     max("navi_yxcn") as "navi_yxcn",
     max("navi_cdcn") as "navi_cdcn",
     max("sf_cn") as "sf_cn",
     max("sf_ontime_cn") as "sf_ontime_cn",
     max("sf_overtime_cn") as "sf_overtime_cn",
     max("sfsdk_cn") as "sfsdk_cn",
     max("sfsdk_ontime_cn") as "sfsdk_ontime_cn",
     max("sfsdk_overtime_cn") as "sfsdk_overtime_cn",
     max("gdsdk_cn") as "gdsdk_cn",
     max("gdsdk_ontime_cn") as "gdsdk_ontime_cn",
     max("gdsdk_overtime_cn") as "gdsdk_overtime_cn",
     max("gdapp_cn") as "gdapp_cn",
     max("gdapp_ontime_cn") as "gdapp_ontime_cn",
     max("gdapp_overtime_cn") as "gdapp_overtime_cn"
     )
     .groupBy("task_area_code", "std_src", "inc_day")
     .agg(
     sum("nosdk_cn") as "nosdk_cn",
     sum("nosdk_otcn") as "nosdk_otcn",
     sum("nosdk_yxcn") as "nosdk_yxcn",
     sum("nosdk_cdcn") as "nosdk_cdcn",
     sum("nonavi_cn") as "nonavi_cn",
     sum("nonavi_otcn") as "nonavi_otcn",
     sum("nonavi_yxcn") as "nonavi_yxcn",
     sum("nonavi_cdcn") as "nonavi_cdcn",
     sum("navi_cn") as "navi_cn",
     sum("navi_otcn") as "navi_otcn",
     sum("navi_yxcn") as "navi_yxcn",
     sum("navi_cdcn") as "navi_cdcn",
     sum("sf_cn") as "sf_cn",
     sum("sf_ontime_cn") as "sf_ontime_cn",
     sum("sf_overtime_cn") as "sf_overtime_cn",
     sum("sfsdk_cn") as "sfsdk_cn",
     sum("sfsdk_ontime_cn") as "sfsdk_ontime_cn",
     sum("sfsdk_overtime_cn") as "sfsdk_overtime_cn",
     sum("gdsdk_cn") as "gdsdk_cn",
     sum("gdsdk_ontime_cn") as "gdsdk_ontime_cn",
     sum("gdsdk_overtime_cn") as "gdsdk_overtime_cn",
     sum("gdapp_cn") as "gdapp_cn",
     sum("gdapp_ontime_cn") as "gdapp_ontime_cn",
     sum("gdapp_overtime_cn") as "gdapp_overtime_cn"
     )
     .withColumn("id", md5EncryptUDF(col("task_area_code"), col("inc_day"), col("std_src"), lit("")))
     .select(
     "id",
     "task_area_code",
     "std_src",
     "nosdk_cn",
     "nosdk_otcn",
     "nosdk_yxcn",
     "nosdk_cdcn",
     "nonavi_cn",
     "nonavi_otcn",
     "nonavi_yxcn",
     "nonavi_cdcn",
     "navi_cn",
     "navi_otcn",
     "navi_yxcn",
     "navi_cdcn",
     "sf_cn",
     "sf_ontime_cn",
     "sf_overtime_cn",
     "sfsdk_cn",
     "sfsdk_ontime_cn",
     "sfsdk_overtime_cn",
     "gdsdk_cn",
     "gdsdk_ontime_cn",
     "gdsdk_overtime_cn",
     "gdapp_cn",
     "gdapp_ontime_cn",
     "gdapp_overtime_cn",
     "inc_day")

     //sf_75rate_cn sf_75ontime_cn sf_75overtime_cn
     val navi_2_5 = naviDf.groupBy("task_area_code", "task_id", "inc_day")
     .agg(
     max("sf_75rate_cn") as "up75_cn",
     max("sf_75ontime_cn") as "up75_ontime_cn",
     max("sf_75overtime_cn") as "up75_overtime_cn",
     max("d75_cn") as "d75_cn",
     max("d75_ontime_cn") as "d75_ontime_cn",
     max("d75_overtime_cn") as "d75_overtime_cn",
     max("sfsdk_up75_cn") as "sfsdk_up75_cn",
     max("nonavi_cdcn") as "nonavi_cdcn",
     max("sfsdk_up75_ontime_cn") as "sfsdk_up75_ontime_cn",
     max("sfsdk_up75_overtime_cn") as "sfsdk_up75_overtime_cn",
     max("sfsdk_d75_cn") as "sfsdk_d75_cn",
     max("sfsdk_d75_ontime_cn") as "sfsdk_d75_ontime_cn",
     max("sfsdk_d75_overtime_cn") as "sfsdk_d75_overtime_cn",
     max("gdsdk_up75_cn") as "gdsdk_up75_cn",
     max("gdsdk_up75_ontime_cn") as "gdsdk_up75_ontime_cn",
     max("gdsdk_up75_overtime_cn") as "gdsdk_up75_overtime_cn",
     max("gdsdk_d75_cn") as "gdsdk_d75_cn",
     max("gdsdk_d75_ontime_cn") as "gdsdk_d75_ontime_cn",
     max("gdsdk_d75_overtime_cn") as "gdsdk_d75_overtime_cn"
     )
     .groupBy("task_area_code", "inc_day")
     .agg(
     sum("up75_cn") as "up75_cn",
     sum("up75_ontime_cn") as "up75_ontime_cn",
     sum("up75_overtime_cn") as "up75_overtime_cn",
     sum("d75_cn") as "d75_cn",
     sum("d75_ontime_cn") as "d75_ontime_cn",
     sum("d75_overtime_cn") as "d75_overtime_cn",
     sum("sfsdk_up75_cn") as "sfsdk_up75_cn",
     sum("nonavi_cdcn") as "nonavi_cdcn",
     sum("sfsdk_up75_ontime_cn") as "sfsdk_up75_ontime_cn",
     sum("sfsdk_up75_overtime_cn") as "sfsdk_up75_overtime_cn",
     sum("sfsdk_d75_cn") as "sfsdk_d75_cn",
     sum("sfsdk_d75_ontime_cn") as "sfsdk_d75_ontime_cn",
     sum("sfsdk_d75_overtime_cn") as "sfsdk_d75_overtime_cn",
     sum("gdsdk_up75_cn") as "gdsdk_up75_cn",
     sum("gdsdk_up75_ontime_cn") as "gdsdk_up75_ontime_cn",
     sum("gdsdk_up75_overtime_cn") as "gdsdk_up75_overtime_cn",
     sum("gdsdk_d75_cn") as "gdsdk_d75_cn",
     sum("gdsdk_d75_ontime_cn") as "gdsdk_d75_ontime_cn",
     sum("gdsdk_d75_overtime_cn") as "gdsdk_d75_overtime_cn"
     )
     .withColumn("id", md5EncryptUDF(col("task_area_code"), col("inc_day"), lit(""), lit("")))
     .select(
     "id",
     "task_area_code",
     "up75_cn",
     "up75_ontime_cn",
     "up75_overtime_cn",
     "d75_cn",
     "d75_ontime_cn",
     "d75_overtime_cn",
     "sfsdk_up75_cn",
     "sfsdk_up75_ontime_cn",
     "sfsdk_up75_overtime_cn",
     "sfsdk_d75_cn",
     "sfsdk_d75_ontime_cn",
     "sfsdk_d75_overtime_cn",
     "gdsdk_up75_cn",
     "gdsdk_up75_ontime_cn",
     "gdsdk_up75_overtime_cn",
     "gdsdk_d75_cn",
     "gdsdk_d75_ontime_cn",
     "gdsdk_d75_overtime_cn",
     "inc_day")
     val navi_2_6 = naviDf.groupBy("task_area_code", "std_src", "task_id", "inc_day")
     .agg(
     max("sf_75rate_cn") as "up75_cn",
     max("sf_75ontime_cn") as "up75_ontime_cn",
     max("sf_75overtime_cn") as "up75_overtime_cn",
     max("d75_cn") as "d75_cn",
     max("d75_ontime_cn") as "d75_ontime_cn",
     max("d75_overtime_cn") as "d75_overtime_cn",
     max("sfsdk_up75_cn") as "sfsdk_up75_cn",
     max("nonavi_cdcn") as "nonavi_cdcn",
     max("sfsdk_up75_ontime_cn") as "sfsdk_up75_ontime_cn",
     max("sfsdk_up75_overtime_cn") as "sfsdk_up75_overtime_cn",
     max("sfsdk_d75_cn") as "sfsdk_d75_cn",
     max("sfsdk_d75_ontime_cn") as "sfsdk_d75_ontime_cn",
     max("sfsdk_d75_overtime_cn") as "sfsdk_d75_overtime_cn",
     max("gdsdk_up75_cn") as "gdsdk_up75_cn",
     max("gdsdk_up75_ontime_cn") as "gdsdk_up75_ontime_cn",
     max("gdsdk_up75_overtime_cn") as "gdsdk_up75_overtime_cn",
     max("gdsdk_d75_cn") as "gdsdk_d75_cn",
     max("gdsdk_d75_ontime_cn") as "gdsdk_d75_ontime_cn",
     max("gdsdk_d75_overtime_cn") as "gdsdk_d75_overtime_cn"
     )
     .groupBy("task_area_code", "std_src", "inc_day")
     .agg(
     sum("up75_cn") as "up75_cn",
     sum("up75_ontime_cn") as "up75_ontime_cn",
     sum("up75_overtime_cn") as "up75_overtime_cn",
     sum("d75_cn") as "d75_cn",
     sum("d75_ontime_cn") as "d75_ontime_cn",
     sum("d75_overtime_cn") as "d75_overtime_cn",
     sum("sfsdk_up75_cn") as "sfsdk_up75_cn",
     sum("nonavi_cdcn") as "nonavi_cdcn",
     sum("sfsdk_up75_ontime_cn") as "sfsdk_up75_ontime_cn",
     sum("sfsdk_up75_overtime_cn") as "sfsdk_up75_overtime_cn",
     sum("sfsdk_d75_cn") as "sfsdk_d75_cn",
     sum("sfsdk_d75_ontime_cn") as "sfsdk_d75_ontime_cn",
     sum("sfsdk_d75_overtime_cn") as "sfsdk_d75_overtime_cn",
     sum("gdsdk_up75_cn") as "gdsdk_up75_cn",
     sum("gdsdk_up75_ontime_cn") as "gdsdk_up75_ontime_cn",
     sum("gdsdk_up75_overtime_cn") as "gdsdk_up75_overtime_cn",
     sum("gdsdk_d75_cn") as "gdsdk_d75_cn",
     sum("gdsdk_d75_ontime_cn") as "gdsdk_d75_ontime_cn",
     sum("gdsdk_d75_overtime_cn") as "gdsdk_d75_overtime_cn"
     )
     .withColumn("id", md5EncryptUDF(col("task_area_code"), col("inc_day"), col("std_src"), lit("")))
     .select("id",
     "task_area_code",
     "std_src",
     "up75_cn",
     "up75_ontime_cn",
     "up75_overtime_cn",
     "d75_cn",
     "d75_ontime_cn",
     "d75_overtime_cn",
     "sfsdk_up75_cn",
     "sfsdk_up75_ontime_cn",
     "sfsdk_up75_overtime_cn",
     "sfsdk_d75_cn",
     "sfsdk_d75_ontime_cn",
     "sfsdk_d75_overtime_cn",
     "gdsdk_up75_cn",
     "gdsdk_up75_ontime_cn",
     "gdsdk_up75_overtime_cn",
     "gdsdk_d75_cn",
     "gdsdk_d75_ontime_cn",
     "gdsdk_d75_overtime_cn",
     "inc_day")
     //2.7.导航任务里程对比
     val navi_2_7 = naviDf.groupBy("task_area_code", "std_src", "task_id", "inc_day")
     .agg(
     max("line_distance_t") as "line_distance",
     max("log_dist_t") as "log_dist",
     max("rt_dist_t") as "rt_dist",
     max("sf_line_distance") as "sf_line_distance",
     max("sf_log_dist") as "sf_log_dist",
     max("sf_rt_dist") as "sf_rt_dist",
     max("notsf_line_distance") as "notsf_line_distance",
     max("notsf_log_dist") as "notsf_log_dist",
     max("notsf_rt_dist") as "notsf_rt_dist",
     max("up75_line_distance") as "up75_line_distance",
     max("up75_log_dist") as "up75_log_dist",
     max("up75_rt_dist") as "up75_rt_dist",
     max("d75_line_distance") as "d75_line_distance",
     max("d75_log_dist") as "d75_log_dist",
     max("d75_rt_dist") as "d75_rt_dist"
     )
     .groupBy("task_area_code", "std_src", "inc_day")
     .agg(
     round(sum("line_distance"),2) as "line_distance",
     round(sum("log_dist"),2) as "log_dist",
     round(sum("rt_dist"),2) as "rt_dist",
     round(sum("sf_line_distance"),2) as "sf_line_distance",
     round(sum("sf_log_dist"),2) as "sf_log_dist",
     round(sum("sf_rt_dist"),2) as "sf_rt_dist",
     round(sum("notsf_line_distance"),2) as "notsf_line_distance",
     round(sum("notsf_log_dist"),2) as "notsf_log_dist",
     round(sum("notsf_rt_dist"),2) as "notsf_rt_dist",
     round(sum("up75_line_distance"),2) as "up75_line_distance",
     round(sum("up75_log_dist"),2) as "up75_log_dist",
     round(sum("up75_rt_dist"),2) as "up75_rt_dist",
     round(sum("d75_line_distance"),2) as "d75_line_distance",
     round(sum("d75_log_dist"),2) as "d75_log_dist",
     round(sum("d75_rt_dist"),2)as "d75_rt_dist"
     )
     .withColumn("id", md5EncryptUDF(col("task_area_code"), col("inc_day"), col("std_src"), lit("")))
     .select(
     "id",
     "task_area_code",
     "std_src",
     "line_distance",
     "log_dist",
     "rt_dist",
     "sf_line_distance",
     "sf_log_dist",
     "sf_rt_dist",
     "notsf_line_distance",
     "notsf_log_dist",
     "notsf_rt_dist",
     "up75_line_distance",
     "up75_log_dist",
     "up75_rt_dist",
     "d75_line_distance",
     "d75_log_dist",
     "d75_rt_dist",
     "inc_day")
     naviDf.unpersist()
     (navi_2_1, navi_2_2, navi_2_3, navi_2_4, navi_2_5, navi_2_6, navi_2_7)
     }

  //空值判断 返回0值
  def replaceCol(col: Column): Column = {
    when(notNullDef(col), col).otherwise(0)
  }

}
