package com.sf.rls

import com.alibaba.fastjson.JSONObject
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, SaveMode}
import org.slf4j.LoggerFactory
import utils.DateUtil.get10daysBefore
import utils.{DateUtil, HttpClientUtil, SparkBuilder}

/**
 * @task_id: (临时执行) 已下线
 * @author 01418539
 * @date 2021年12月10日 14:29
 */
object DistanceRLS extends DataSourceCommon {

  //spark初始化 参数配置
  val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

  import spark.implicits._

  def main(args: Array[String]): Unit = {
    logger.info(s"请传入需要跑批的日期---inc_day")
    val inc_day = args(0)
    //            val inc_day = "20211211"
    //数据接入 转化 接口调用
    val res_ds = transData(inc_day)
    //    res_ds.show(3)

    //    val file_path = "hdfs://sfbdp1/user/01418539/upload/distanceRLS" //写入文件的hdfs路径
    //落盘，写csv数据
    //    writeCsv(spark, res_ds, SaveMode.Overwrite, inc_day, file_path)
    res_ds.createOrReplaceTempView("res_ds")
    val sql = String.format("insert overwrite table %s partition(inc_day) select * from %s", "dm_gis.rls_fw_trajectory", "res_ds");
    spark.sql(sql)

  }

  /**
   * 测试test造数进行功能验证
   *
   * @param partitionBy
   * @return
   */
  def transDataTest(partitionBy: String) = {

    //1 A表 运单时长表
    val codeTm_ds: Dataset[_] = Seq(
      ("41000126", "184688529787", "0:00:00", "12:10:05", "020BD", "20211211"),
      ("40609507", "184650158973", "0:00:00", "12:10:05", "029CD", "20211211")
    ).toDF("man", "code", "starttime", "endtime", "site_code", "inc_day")

    //2 B表 路由标签丰网日志解析表 dm_gis.rls_log_fw
    val fwlog_ds: Dataset[_] = Seq(
      ("广东省", "深圳市", "南山区", "软件园", "62556EAEF2951B9DE0530EF4520A0CFC", "184688529787"),
      ("广东省", "深圳市", "宝安区", "万象城", "62556EAEF2951B9DE0530EF4520A0CFC", "184650158973")
    ).toDF("dest_province", "dest_city", "dest_country", "dest_addr", "dest_aoiid", "waybill_no")

    //3 C表 全国车行骑行GPS轨迹数据表 dm_gis.esg_gis_loc_trajectory
    val gps_ds: Dataset[_] = Seq(
      ("41000126", "020BD", "114.01845253", "22.555711237", "1639190169", "1"), //2021-12-11 10:36:09
      ("40609507", "029CD", "114.05845253", "22.585711237", "1639190342", "1"), //2021-12-11 10:39:02
      ("40609507", "030CD", "113.82460789", "34.209144418", "1639190342", "0")
    ).toDF("un", "bn", "zx", "zy", "tm", "ak")

    val codeTm_cols = Seq(
      col("man"), //运单编号
      col("starttime"), //拼接时间 起始时间 20211208 0:00:00
      col("endtime"), //
      col("site_code"), //网点号
      col("code"), //订单编号
      col("inc_day")
    )

    val fwlog_cols = Seq(
      col("waybill_no"),
      col("dest_province"),
      col("dest_city"),
      col("dest_country"),
      col("dest_addr"),
      col("dest_aoiid")
    )
    val gps_cols = Seq(
      col("un"),
      col("bn"),
      col("zx"),
      col("zy"),
      col("tm")
    )

    val codeTm_df = codeTm_ds.select(codeTm_cols: _*)
    val fwlog_df = fwlog_ds.select(fwlog_cols: _*)
    val gps_df = gps_ds.select(gps_cols: _*)

    val fwlog_fwlog_df: DataFrame = gps_df
      .join(codeTm_df, $"bn" === $"site_code" && $"un" === $"man", "inner")
      .join(fwlog_df, $"waybill_no" === $"code", "inner")
      .filter($"tm".between(DateUtil.timeToTimestamp(concat_ws(" ", $"inc_day", $"starttime")), DateUtil.timeToTimestamp(concat_ws(" ", $"inc_day", $"endtime"))))
      .select($"man",
        $"code",
        $"starttime",
        $"endtime",
        $"site_code",
        $"zx",
        $"zy",
        $"dest_aoiid"
      )
    fwlog_fwlog_df.show(3)
    getCoorAoiDist(fwlog_fwlog_df, partitionBy)
  }

  /**
   * 数据接入并进行关联筛选
   *
   * @param partitionBy
   * @return
   */
  def transData(partitionBy: String) = {

    //1 A表 运单时长表
    val codeTm_ds = spark.sql(
      """
        |select
        |*
        |from
        |default.fw_trajectory1216
        |""".stripMargin)

    codeTm_ds.createTempView("tmp")
    val inc_day_max: String = spark.sql("SELECT MAX(inc_day) as maxval FROM tmp").collect()(0).getString(0)
    val inc_day_min: String = spark.sql("SELECT MIN(inc_day) as minval FROM tmp").collect()(0).getString(0)
    val inc_day_min_10daysBef: String = get10daysBefore(inc_day_min)


    //2 B表 路由标签丰网日志解析表 dm_gis.rls_log_fw
    val fwlog_ds = spark.sql(
      s"""
         |select
         |*
         |from
         |dm_gis.rls_log_fw
         |where inc_day>='${inc_day_min_10daysBef}' and inc_day<='${inc_day_max}'
         |""".stripMargin)

    //3 C表 全国车行骑行GPS轨迹数据表 dm_gis.esg_gis_loc_trajectory
    val gpsPath = "hdfs://sfbdp1/user/hive/warehouse/dm_gis.db/esg_gis_loc_trajectory"
    //    val gps_ds: Dataset[_] = getDSByParquet(spark, gpsPath, partitionBy).filter($"ak" === "1").coalesce(400)
    val gps_ds = spark.sql(
      s"""
         |select
         |*
         |from
         |dm_gis.esg_gis_loc_trajectory
         |where inc_day>='${inc_day_min}' and inc_day<='${inc_day_max}' and ak='1'
         |""".stripMargin)
    val codeTm_cols = Seq(
      col("man"), //运单编号
      col("starttime"), //拼接时间 起始时间 20211208 0:00:00
      col("endtime"), //
      col("site_code"), //网点号
      col("code"), //订单编号
      col("inc_day")
    )

    val fwlog_cols = Seq(
      col("waybill_no"),
      col("dest_province"),
      col("dest_city"),
      col("dest_country"),
      col("dest_addr"),
      col("dest_aoiid"),
      col("inc_day")
    )
    val gps_cols = Seq(
      col("un"),
      col("bn"),
      col("zx"),
      col("zy"),
      col("tm"),
      col("inc_day")
    )

    val codeTm_df = codeTm_ds.select(codeTm_cols: _*)
    val fwlog_df = fwlog_ds.select(fwlog_cols: _*)
    val gps_df = gps_ds.select(gps_cols: _*)

    val fwlog_fwlog_df = gps_df.alias("gps_df")
      .join(codeTm_df.alias("codeTm_df"), $"bn" === $"site_code" && $"un" === $"man" && $"gps_df.inc_day" === $"codeTm_df.inc_day", "inner")
      .filter($"tm".between(DateUtil.timeToTimestamp(concat_ws(" ", $"codeTm_df.inc_day", $"starttime")), DateUtil.timeToTimestamp(concat_ws(" ", $"codeTm_df.inc_day", $"endtime"))))
      .join(fwlog_df.alias("fwlog_df"), $"waybill_no" === $"code", "inner")
      .select($"man",
        $"code",
        $"starttime",
        $"endtime",
        $"site_code",
        $"zx",
        $"zy",
        $"dest_aoiid",
        $"codeTm_df.inc_day" as "inc_day"
      )
    getCoorAoiDist(fwlog_fwlog_df, partitionBy)
  }

  /**
   * 调接口并返回最后距离计算结果数据
   *
   * @param partitionBy
   * @return
   */
  def getCoorAoiDist(df: DataFrame, partitionBy: String): DataFrame = {
    var distance: Double = 0.0
    //    logger.info("=============df展示2条数据=============")
    //    df.show(3)
    val getAoids = df.map(row => {
      val zx = row.getAs[String]("zx")
      val zy = row.getAs[String]("zy")
      val aoiId = row.getAs[String]("dest_aoiid")
      val man = row.getAs[String]("man")
      val code = row.getAs[String]("code")
      val starttime = row.getAs[String]("starttime")
      val endtime = row.getAs[String]("endtime")
      val site_code = row.getAs[String]("site_code")
      val inc_day = row.getAs[String]("inc_day")

      // url地址  访问接口
      val url: String = s"http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?" +
        s"x=$zx&y=$zy&aoiId=$aoiId&type=side"
      val jsonData: JSONObject = HttpClientUtil.getJsonByGet(url, 2, "UTF-8")
      //            println(jsonData.toJSONString)
      try {
        if (jsonData != null) {
          distance = jsonData.getString("data").toDouble
        } else {
          distance = 0.0
        }
      } catch {
        case e1: NullPointerException => distance = 0.0
        case e2: Exception => {
          distance = 0.0
          e2.printStackTrace()
          logger.error("获取与aoi之间未获取距离data值异常")
        }
      }
      (man, code, starttime, endtime, site_code, distance, zx, zy, aoiId, inc_day)
    }).toDF("man", "code", "starttime", "endtime", "site_code", "distance", "zx", "zy", "aoiId", "inc_day")

    val res = getAoids
      .withColumn("minDist", when($"distance" === 0.0, 999999999).otherwise($"distance"))
      .withColumn("fiftylow", when($"distance" >= 0 && $"distance" < 50, 1).otherwise(0))
      .withColumn("hundredlow", when($"distance" >= 0 and $"distance" < 100, 1).otherwise(0))
      .withColumn("towHundredlow", when($"distance" >= 0 and $"distance" < 200, 1).otherwise(0))
      .groupBy("man", "code", "starttime", "endtime", "site_code", "inc_day")
      .agg(
        round(min("minDist"), 2) as "minDist",
        sum("fiftylow") as "fiftylow",
        sum("hundredlow") as "hundredlow",
        sum("towHundredlow") as "towHundredlow"
      )
      .withColumn("minDist", when($"minDist" === 999999999, 0.0).otherwise($"minDist"))
      .select(
        col("man"),
        col("code"),
        col("starttime"),
        col("endtime"),
        col("site_code"),
        col("minDist"),
        col("fiftylow"),
        col("hundredlow"),
        col("towHundredlow"),
        col("inc_day")
      )
    res
  }
}
