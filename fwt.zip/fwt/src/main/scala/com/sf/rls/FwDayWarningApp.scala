package com.sf.rls

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import utils.DateUtil.{getOnedaysBefore, getdaysBeforeOrAfter}
import utils.{DateUtil, SparkBuilder}

import java.io.File
import java.util.{Date, Properties}
import javax.activation.{DataHandler, DataSource}
import javax.mail._
import javax.mail.internet._
import javax.mail.util.ByteArrayDataSource
import scala.collection.mutable.ArrayBuffer

/**
 * task_id : 442677 因邮箱变更 该功能已下线，但前置hive任务在线上
 * @author 01418539
 * @date 2021年12月27日 15:04
 */
object FwDayWarningApp {

  val myEmailAccount = "caojia2@sfmail.sf-express.com";

  val myEmailPassword = "AAAsss987123";

//  val myEmailSMTPHost = "lsmtp.sf-express.com";
  val myEmailSMTPHost = "mail.sfmail.sf-express.com"

  def main(args: Array[String]): Unit = {
    //spark初始化 参数配置
    //    val spark = SparkBuilder.localInitSpark(this.getClass.getSimpleName)
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    import spark.implicits._
    val email = "zhangjianpei@sfmail.sf-express.com," +
      "rongwang1@sfmail.sf-express.com," +
      "yangzhenping@sfmail.sf-express.com," +
      "victorwang@sfmail.sf-express.com," +
      "gaozhi@sf-express.com," +
      "yuanqinglan@sf-express.com," +
      "junyang5@sfmail.sf-express.com,miaoyang1@sfmail.sf-express.com,caojia2@sfmail.sf-express.com"
//                val email1 = "caojia2@sfmail.sf-express.com"
    //        val email = "caojia2@sfmail.sf-express.com,rongwang1@sfmail.sf-express.com"
    val inc_day = args(0)
    //    val inc_day = "20211226"

    //    val init_df_1 = Seq(
    //      ("fns_first", "FNS_543001000", "1963", "1962", "0.05%", "2021/12/27 18:42", "修改", "9B78EAD7585A45AEA8A06AC1774C1B2C", "20211226"),
    //      ("fns_first", "FNS_319003000", "1414", "1412", "0.14%", "2021/12/26 20:51", "修改", "A369B47CD1B1495A89A0CA2C9318A796,DEE163A55A884D95B6D5AF4AACBD746B", "20211226")
    //    ).toDF("tc_type", "ky_unit", "stat_aoi_count", "before_aoi_count", "proportion", "update_date", "remarks", "aoi_id_excep", "inc_day")
    //    val filter = regexp_replace(regexp_replace(substring(col("update_date"), 1, 10), "-", ""), "\\/", "") =!= inc_day
    //    val init_df = init_df_1.filter(filter)
    //    init_df.show(2)

    //        val hdfs_path = "/user/01418539/upload/附件：网点对应异常aoi详情.txt"
    val hdfs_path = "file/附件：网点对应异常aoi详情.txt"
    val file = new File(hdfs_path)
    val init_df = loadDataFromHive(spark, inc_day)
    val str_info: StringBuilder = getFwExcepTable(spark, init_df, inc_day)
    sendExcepMail(str_info, init_df, email, file, inc_day)
  }

  def loadDataFromHive(spark: SparkSession, inc_day: String): DataFrame = {
    val yesterday = getdaysBeforeOrAfter(inc_day, -1)
    val excep_info_ds = spark.sql(
      s"""
         |select
         |*
         |from dm_gis.fw_fd_stat_warning
         |where inc_day = '$inc_day'
         |""".stripMargin)
    val filter1 = regexp_replace(regexp_replace(substring(col("update_date"), 1, 10), "-", ""), "\\/", "") =!= inc_day
    val filter2 = regexp_replace(regexp_replace(substring(col("update_date"), 1, 10), "-", ""), "\\/", "") =!= yesterday
    val initDf = excep_info_ds.filter(filter1 && filter2)
    initDf
  }

  def getFwExcepTable(spark: SparkSession, excepDf: DataFrame, inc_day: String): StringBuilder = {
    val one_day_ago = inc_day
    val two_days_ago = getOnedaysBefore(inc_day)

    val strb = new StringBuilder
    if (excepDf.count == 0) {
      strb.append(s"<br>各位好！</br>")
      strb.append(s"<br>&nbsp&#8195&#8195以下为截止${DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")}，统计的丰网网点关联的疑似异常AOI明细，“差异aoi”已关联《aoi变更记录表》剔除前一天有新增删除或者范围修改的aoiid。<b>请及时查看差异aoi与丰网网点关联关系是否存在异常。</b></font></br>")
      strb.append(s"<br>当日全部数据明细请见附件，谢谢！</br>")
      strb.append(s"<br><b>网点对应aoi数量有变化明细：</b></br>")
      strb.append(s"<br>截止当前时间${DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")}，一级网点对应aoi数量均无变化。<br>")
    } else {
      strb.append(s"<br>各位好！</br>")
      strb.append(s"<br>&nbsp&#8195&#8195以下为截止${DateUtil.getCurrentDate("yyyy-MM-dd HH:mm:ss")}，统计的丰网网点关联的疑似异常AOI明细，“差异aoi”已关联《aoi变更记录表》剔除前一天有新增删除或者范围修改的aoiid。<b>请及时查看差异aoi与丰网网点关联关系是否存在异常。</b></font></br>")
      strb.append(s"<br>当日全部数据明细请见附件，谢谢！</br>")
      strb.append("<table border=\"1\" cellspacing=\"0\" style=\"width:800px; height:150px;border:solid 1px #E8F2F9;font-size=15px;\">") //font-size:15px;
      //      strb.append("<table border=\"1\" style=\"width:800px; height:150px;border:solid 1px #E8F2F9;font-size=15px;font-size:15px;\">")//
      strb.append("<tr>" +
        "<td style=\"white-space:nowrap\">网点级别</td>" +
        "<td style=\"white-space:nowrap\">网点编码</td>" +
        "<td style=\"white-space:nowrap\">" + one_day_ago + "的AOI数量" +
        "</td><td style=\"white-space:nowrap\">" + two_days_ago + "的AOI数量" +
        "</td><td style=\"white-space:nowrap\">环比差值</td>" +
        "<td style=\"white-space:nowrap\">最后修改时间</td>" +
        "<td style=\"white-space:nowrap\">备注</td>" +
        "<td style=\"white-space:nowrap\">异常aoi_id明细</td>" +
        "</tr>")
      strb.append("<tr>")

      val rows: Array[Row] = excepDf.orderBy(asc("ky_unit"),asc("proportion")).collect()
      for (row <- rows) {
        val tc_type = row.getAs[String]("tc_type")
        val ky_unit = row.getAs[String]("ky_unit")
        val stat_aoi_count = row.getAs[String]("stat_aoi_count")
        val before_aoi_count = row.getAs[String]("before_aoi_count")
        val proportion = row.getAs[String]("proportion")
        val update_date = row.getAs[String]("update_date")
        val remarks = row.getAs[String]("remarks")
        val aoi_id_excep = row.getAs[String]("aoi_id_excep")
        strb.append("<tr>")
        strb.append("<td style=\"white-space:nowrap\"><span>" + tc_type + "</span></td>")
          .append("<td style=\"white-space:nowrap\"><span>" + ky_unit + "</span></td>")
          .append("<td style=\"white-space:nowrap\"><span>" + stat_aoi_count + "</span></td>")
          .append("<td style=\"white-space:nowrap\"><span>" + before_aoi_count + "</span></td>")
          .append("<td style=\"white-space:nowrap\"><span>" + proportion + "</span></td>")
          .append("<td style=\"white-space:nowrap\"><span>" + update_date + "</span></td>")
          .append("<td style=\"white-space:nowrap\"><span>" + remarks + "</span></td>")
          .append("<td style=\"white-space:nowrap\"><span>" + aoi_id_excep + "</span></td>")
          .append("</tr>")
      }
      strb.append("</table>")
    }
    strb
  }

  def sendExcepMail(info: StringBuilder, df: DataFrame, mailBox: String, path: File, inc_day: String): Unit = {
    val prop = new Properties()
    prop.setProperty("mail.transport.protocol", "smtp")
    prop.setProperty("mail.smtp.host", myEmailSMTPHost)
    prop.setProperty("mail.smtp.auth", "true")
    prop.setProperty("mail.smtp.port", "25")
    prop.setProperty("mail.smtp.connectiontimeout", "25000")
    prop.setProperty("mail.smtp.timeout", "25000")
    prop.setProperty("mail.smtp.writetimeout", "25000")
    val auth = new Authenticator() {
      override protected def getPasswordAuthentication =
        new PasswordAuthentication(myEmailAccount, myEmailPassword)
    }

    val session = Session.getDefaultInstance(prop, auth)
    session.setDebug(true)

    val transport = session.getTransport

    val addresses = new ArrayBuffer[InternetAddress]()

    val mail_nums = mailBox.split(",")
    if (mail_nums.length >= 0 && mail_nums != null) {
      for (mail <- mail_nums) {
        addresses += new InternetAddress(mail, "预警用戶", "UTF-8")
      }
    }
    val tos = addresses // 收件人（可以增加多个收件人、抄送、密送）

    val mimeMessage = createNewMimeMessage(session, df, myEmailAccount, tos, info, path, inc_day) //设置端口信息

    transport.connect(myEmailAccount, myEmailPassword)

    transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients)

    transport.close()

  }

  def createNewMimeMessage(session: Session, df: DataFrame, sendMail: String, tos: ArrayBuffer[InternetAddress], info: StringBuilder, path: File, inc_day: String): MimeMessage = {
    val mimeMessage = new MimeMessage(session)
    mimeMessage.setFrom(new InternetAddress(sendMail, "丰网预警", "UTF-8")) // 发件人
    mimeMessage.addRecipients(Message.RecipientType.TO, tos.mkString(",")) //抄送人
    mimeMessage.setSubject("丰网网点关联的异常AOI明细" + inc_day, "UTF-8") //邮件主题
    val content = new StringBuilder("<html><head></head><body>")
    content.append(info)
    content.append("</body></html>")
    // 添加邮件正文
    val contentPart = new MimeBodyPart
    contentPart.setContent(content.toString(), "text/html;charset=UTF-8")

    //    // 向multipart对象中添加邮件的各个部分内容，包括文本内容和附件
    //    val multipart = new MimeMultipart
    //
    //    multipart.addBodyPart(contentPart)
    //    val attFile: File = path
    //    val flag = attFile.exists()
    //    logger.error(s"文件存在状况：$flag")
    //    // 添加附件的内容
    //    if (attFile != null && attFile.exists()) {
    //      val attBodyPart = new MimeBodyPart
    //      val source = new FileDataSource(attFile)
    //      attBodyPart.setDataHandler(new DataHandler(source))
    //      // MimeUtility.encodeWord可以避免文件名乱码
    //      attBodyPart.setFileName(MimeUtility.encodeWord(attFile.getName))
    //      val excep_info = df.collect().mkString("\n")

    // 向multipart对象中添加邮件的各个部分内容，包括文本内容和附件
    val multipart = new MimeMultipart
    // 添加附件的内容
    val attBodyPart = new MimeBodyPart
    multipart.addBodyPart(contentPart)

    val excep_info_byte: Array[Byte] = df.drop("inc_day").orderBy(asc("ky_unit"),asc("proportion")).collect().mkString("\n").getBytes
    val excep_info = df.orderBy(asc("ky_unit"),asc("proportion")).collect().mkString("\n")
    val source: DataSource = new ByteArrayDataSource(excep_info_byte, "UTF-8").asInstanceOf[DataSource]
    if (df.count() != 0) {
      attBodyPart.setDataHandler(new DataHandler(source))
      // MimeUtility.encodeWord可以避免文件名乱码
      attBodyPart.setFileName(MimeUtility.encodeWord(s"附件：${inc_day}网点对应异常aoi详情.txt"))
      attBodyPart.setText(excep_info)
      multipart.addBodyPart(attBodyPart)
    }
    mimeMessage.setContent(multipart)
    mimeMessage.setSentDate(new Date())
    mimeMessage.saveChanges()
    mimeMessage

  }

}
