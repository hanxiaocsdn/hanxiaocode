package com.sf.rls

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.ColumnCommon.{notNullDef, similarity}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.LoggerFactory
import utils.HttpClientUtil.{getJsonByGet, getJsonParam, postResponse}
import utils.{HttpInvokeUtil, SparkBuilder}

/**
 * @author 01418539 (临时执行 已下线)
 * @date 2021年12月17日 15:54
 */
object LocationExcLoopApp {

  val logger = LoggerFactory.getLogger(this.getClass)

  //url接口链接
  //1 图商坐标获取接口 8e645407f88f410e9db6c85afc90d05e  20211222
//  val url1 = s"http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=8e645407f88f410e9db6c85afc90d05e&opt=gd2&address=%s&city=%s"
  val url1 = ""
  //坐标获取AOI接口 ak  e781937be5314dd1bdbb98c1f968824f
//  val url2 = s"http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=e781937be5314dd1bdbb98c1f968824f"
  val url2 = ""
  //派件容灾环境接口 ak  dec044d089524419b371bc94555c539d
//  val url3 = s"http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=dec044d089524419b371bc94555c539d&opt=zh&company=&tel=&mobile=&showserver=true"
  val url3 = ""
  //坐标点到AOI距离接口 no ak
//  val url4 = s"http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?x=%s&y=%s&aoiId=%s&type=side"
  val url4 = ""

  def main(args: Array[String]): Unit = {
    //spark初始化 参数配置
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)

    val start_day = args(0)
    val initdata = loadData(spark, start_day)
    val last_res = getAddrCity(spark, initdata)

    val join_ds = joinDF(spark, start_day, initdata, last_res)

    join_ds._1.createOrReplaceTempView("join_ds")
    val sql_1 = String.format("insert overwrite table %s partition(inc_day) select * from %s", "dm_gis.lbs_waybill_info_locat_exception", "join_ds");
    spark.sql(sql_1)
    //post请求更新cms系统中的数据返回数据更新情况信息
    val cms_post_ds = dealPostRes(spark, join_ds._2)

    cms_post_ds.createOrReplaceTempView("cms_post_ds")
    val sql_2 = String.format("insert overwrite table %s partition(inc_day) select * from %s", "dm_gis.lbs_waybill_info_locat_post", "cms_post_ds");
    spark.sql(sql_2)

  }

  def testData(spark: SparkSession): DataFrame = {
    import spark.implicits._

    val ds = Seq(
      ("SF1407892309239", "四川省成都市成都高新区天泰路145号特拉克斯国际广场1栋(南楼)8楼", "028", "104.070273", "30.591379", "62556EACB86E1B9DE0530EF4520A0CFC"),
      ("SF1136643601524", "广东省深圳市光明区光明区深房传麒山7B801室", "755", "113.943418", "22.743313", "B6C6AB5D2D7249CBB4619AB7807EE8EF")
    ).toDF("waybill_no", "address", "city", "lng80", "lat80", "aoi_id")
    ds
  }

  def loadData(spark: SparkSession, start_day: String): DataFrame = {

    //1 表1 快递小哥相关信息
    val info_ds = spark.sql(
      s"""
         |select
         |waybillno as waybill_no,--运单号
         |userid,--用户id
         |dialogcontent--小哥选择项内容
         |from dm_tdos.middle_lbs_way_info
         |where inc_day = '$start_day' and dialogcontent = '定位错误'
         |""".stripMargin)

    //2.1 表2 派件日志表--待去重
    val log_ds_tmp = spark.sql(
      s"""
         |select distinct waybill_no,--运单号
         |city,
         |aoi_id,--派件地址 AOI ID
         |address,
         |company,
         |tracks,--轨迹串
         |standard,--	是否规范
         |standard_result--是否规范
         |from dm_gis.lbs_log_pnsaoi
         |where inc_day = '$start_day'
         |""".stripMargin)
    //2.2 表2 派件日志表---已去重
    val log_ds = log_ds_tmp.groupBy("waybill_no")
      .agg(
        last("city") as "city",
        last("aoi_id") as "aoi_id", //派件地址 AOI ID
        last("address") as "address",
        last("company") as "company",
        last("tracks") as "tracks",
        last("standard") as "standard",
        last("standard_result") as "standard_result" //是否规范
      )

    //3 表3 lbs管控表 位置信息
    val locat_ds = spark.sql(
      s"""
         |select
         |waybill_no,--运单号
         |aoi_name, --aoi名称
         |lng80,--投递经度
         |lat80,--投递纬度
         |dist_aoi_80 --妥投aoi中心点和投递点的距离
         |from dm_gis.lbs_loc_index--lbs管控表
         |where inc_day = '$start_day'
         |""".stripMargin)

    val res_ds = info_ds.join(log_ds, Seq("waybill_no"), "left")
      .join(locat_ds, Seq("waybill_no"), "left")
    res_ds

  }

  /**
   * 调接口并返回最后距离计算结果数据
   */

  def getAddrCity(spark: SparkSession, df: DataFrame): (DataFrame, DataFrame, DataFrame) = {
    import spark.implicits._

    val interCols_df = df.select("waybill_no", "address", "city", "lng80", "lat80", "aoi_id")

    interCols_df.persist(StorageLevel.MEMORY_AND_DISK)
    //三类接口调用数据，过滤条件分别列出
    val addr_city_filter = notNullDef($"address") && notNullDef($"city")
    val lng_lat_filter = notNullDef($"lng80") && notNullDef($"lat80")
    val lng_lat_aoi_filter = notNullDef($"lng80") && notNullDef($"lat80") && notNullDef($"aoi_id")
    //根据过滤条件筛选接口调用所需数据
    val addr_city_cols_df = interCols_df.filter(addr_city_filter)
      .select("waybill_no", "address", "city")
    val lng_lat_cols_df = interCols_df.filter(lng_lat_filter)
      .select("waybill_no", "lng80", "lat80")

    val lng_lat_aoi_cols_df = interCols_df.filter(lng_lat_aoi_filter)
      .select("waybill_no", "lng80", "lat80", "aoi_id")

    interCols_df.unpersist()
    addr_city_cols_df.persist()
    lng_lat_cols_df.persist()
    lng_lat_aoi_cols_df.persist()
    //1 address city数据接口调用
    val ds_addrCity_1 = addr_city_cols_df.map(row => {
      val waybill_no = row.getAs[String]("waybill_no")
      val address = row.getAs[String]("address")
      val city = row.getAs[String]("city")
      var lng_ts = ""
      var lat_ts = ""
      var precision_ts = ""

      try {
        //1.1 调图商坐标
        val urlParam = getJsonParam(url1, address, city)
        Thread.sleep(800)
        val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
        val ts1_jsonData: JSONObject = JSON.parseObject(getUrlRes)
        logger.error("step1返回:" + ts1_jsonData)
        val ts1_json_pub = ts1_jsonData.getJSONObject("result")
        lng_ts = ts1_json_pub.getString("xcoord")
        lat_ts = ts1_json_pub.getString("ycoord")
        precision_ts = ts1_json_pub.getString("precision")
      } catch {
        case e: Exception => logger.error("首次调取图上坐标获取接口数据异常：" + e.getMessage)
      }
      (waybill_no, address, city, lng_ts, lat_ts, precision_ts)
    }).toDF("waybill_no", "address", "city", "lng_ts", "lat_ts", "precision_ts")
    addr_city_cols_df.unpersist()
    ds_addrCity_1.persist()
    val ds_addrCity_2 = ds_addrCity_1.map(row => {
      val waybill_no = row.getAs[String]("waybill_no")
      val address = row.getAs[String]("address")
      val city = row.getAs[String]("city")
      val lng_ts = row.getAs[String]("lng_ts")
      val lat_ts = row.getAs[String]("lat_ts")
      val precision_ts = row.getAs[String]("precision_ts")

      var ts_aoiid = ""
      var ts_aoiname = ""
      try {
        if (!lng_ts.isEmpty && lng_ts != "" && !lat_ts.isEmpty && lat_ts != "") {
          //1.2 调坐标获取AOI接口
          val urlParam = getJsonParam(url2, lng_ts, lat_ts)
          val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
          val aoi1_jsonData: JSONObject = JSON.parseObject(getUrlRes)
          logger.error("step2返回:" + aoi1_jsonData)

          //                    val aoi1_jsonData: JSONObject = getJsonObject(url2, lng_ts, lat_ts)
          //提取公共部分
          val aoi1_pub: JSONObject = aoi1_jsonData.getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0)
          ts_aoiid = aoi1_pub.getString("aoi_id")
          ts_aoiname = aoi1_pub.getString("aoi_name")
        }
      } catch {
        case e: Exception => logger.error("首次url2======接口数据异常：" + e.getMessage)
      }

      //2.1 派件容灾接口调用
      var groupid = ""
      var std_aoiid = ""
      var match_addr = ""
      var std_addr = ""
      try {
        val urlParam = getJsonParam(url3, address, city)
        val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
        val pj_jsonData: JSONObject = JSON.parseObject(getUrlRes)
        logger.error("step3返回:" + pj_jsonData)
        //        val pj_jsonData: JSONObject = getJsonObject(url3, address, city)
        val pj_pub1 = pj_jsonData.getJSONObject("result").getJSONArray("tcs").getJSONObject(0)
        val pj_pub2 = pj_jsonData.getJSONObject("result").getJSONObject("other").getJSONObject("normresp")
          .getJSONObject("result").getJSONArray("geocoder").getJSONObject(0)

        groupid = pj_pub1.getString("groupid")
        std_aoiid = pj_pub1.getString("aoiid")
        match_addr = pj_pub2.getString("name")
        std_addr = pj_pub2.getString("standardization")
      } catch {
        case e: Exception => logger.error("首次url3获取接口数据异常：" + e.getMessage)
      }
      (waybill_no, address, city, lng_ts, lat_ts, precision_ts, ts_aoiid, ts_aoiname, groupid, std_aoiid, match_addr, std_addr)
    }).toDF("waybill_no", "address", "city", "lng_ts", "lat_ts", "precision_ts", "ts_aoiid", "ts_aoiname", "groupid", "std_aoiid", "match_addr", "std_addr")

    ds_addrCity_1.unpersist()
    ds_addrCity_2.persist()

    val ds_addrCity_3 = ds_addrCity_2.map(row => {
      val waybill_no = row.getAs[String]("waybill_no")
      val address = row.getAs[String]("address")
      val city = row.getAs[String]("city")
      val lng_ts = row.getAs[String]("lng_ts")
      val lat_ts = row.getAs[String]("lat_ts")
      val precision_ts = row.getAs[String]("precision_ts")
      val ts_aoiid = row.getAs[String]("ts_aoiid")
      val ts_aoiname = row.getAs[String]("ts_aoiname")
      val groupid = row.getAs[String]("groupid")
      val std_aoiid = row.getAs[String]("std_aoiid")
      val match_addr = row.getAs[String]("match_addr")
      val std_addr = row.getAs[String]("std_addr")
      //定义初始变量
      var lng_std = ""
      var lat_std = ""
      var precision_std = ""
      try {
        if (!std_addr.isEmpty && std_addr != "") {
          //2.2 图商坐标获取接口
          val urlParam = getJsonParam(url1, std_addr, city)
          Thread.sleep(800)
          val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
          val ts2_jsonData: JSONObject = JSON.parseObject(getUrlRes)
          logger.error("step4返回:" + ts2_jsonData)
          //          val ts2_jsonData: JSONObject = getJsonObject(url1, std_addr, city)
          lng_std = ts2_jsonData.getJSONObject("result").getString("xcoord")
          lat_std = ts2_jsonData.getJSONObject("result").getString("ycoord")
          precision_std = ts2_jsonData.getJSONObject("result").getString("precision")
        }
      } catch {
        case e: Exception => logger.error("调取url1数据接口异常：" + e.getMessage)
      }
      (waybill_no, address, city, lng_ts, lat_ts, precision_ts, ts_aoiid, ts_aoiname, groupid, std_aoiid, match_addr, std_addr, lng_std, lat_std, precision_std)
    }).toDF("waybill_no", "address", "city", "lng_ts", "lat_ts", "precision_ts", "ts_aoiid", "ts_aoiname", "groupid", "std_aoiid", "match_addr", "std_addr", "lng_std", "lat_std", "precision_std")
    ds_addrCity_2.unpersist()
    ds_addrCity_3.persist()

    val ds_addrCity = ds_addrCity_3.map(row => {
      val waybill_no = row.getAs[String]("waybill_no")
      val address = row.getAs[String]("address")
      val city = row.getAs[String]("city")
      val lng_ts = row.getAs[String]("lng_ts")
      val lat_ts = row.getAs[String]("lat_ts")
      val precision_ts = row.getAs[String]("precision_ts")
      val ts_aoiid = row.getAs[String]("ts_aoiid")
      val ts_aoiname = row.getAs[String]("ts_aoiname")
      val groupid = row.getAs[String]("groupid")
      val std_aoiid = row.getAs[String]("std_aoiid")
      val match_addr = row.getAs[String]("match_addr")
      val std_addr = row.getAs[String]("std_addr")
      //定义初始变量
      val lng_std = row.getAs[String]("lng_std")
      val lat_std = row.getAs[String]("lat_std")
      val precision_std = row.getAs[String]("precision_std")
      var stdaddr_aoiid = ""
      var stdaddr_aoiname = ""
      try {
        if (!lng_std.isEmpty && lng_std != "" && !lat_std.isEmpty && lat_std != "") {
          //2.3 调坐标获取AOI接口
          val urlParam = getJsonParam(url2, lng_std, lat_std)
          val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
          val aoi2_jsonData: JSONObject = JSON.parseObject(getUrlRes)
          logger.error("step5返回:" + aoi2_jsonData)
          //          val aoi2_jsonData: JSONObject = getJsonObject(url2, lng_std, lat_std)
          //提取公共部分
          val aoi2_pub: JSONObject = aoi2_jsonData.getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0)
          stdaddr_aoiid = aoi2_pub.getString("aoi_id")
          stdaddr_aoiname = aoi2_pub.getString("aoi_name")
        }
      } catch {
        case e: Exception => logger.error("调取url2数据接口异常：" + e.getMessage)
      }
      (waybill_no, address, city, ts_aoiid, ts_aoiname, groupid, std_aoiid, match_addr, std_addr, lng_std, lat_std, precision_std, stdaddr_aoiid, stdaddr_aoiname, lng_ts, lat_ts, precision_ts)
    }).toDF("waybill_no", "address", "city", "ts_aoiid", "ts_aoiname", "groupid", "std_aoiid", "match_addr", "std_addr", "lng_std", "lat_std", "precision_std", "stdaddr_aoiid", "stdaddr_aoiname", "lng_ts", "lat_ts", "precision_ts")
    ds_addrCity_3.unpersist()

    //2 lng lat数据接口调用
    val ds_lngLat = lng_lat_cols_df.map(row => {
      val waybill_no = row.getAs[String]("waybill_no")
      val lng80 = row.getAs[String]("lng80")
      val lat80 = row.getAs[String]("lat80")
      var aoiid_80 = ""
      var aoiname_80 = ""

      try {
        //2.1 坐标获取AOI接口
        val urlParam = getJsonParam(url2, lng80, lat80)
        val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
        val aoi3_jsonData: JSONObject = JSON.parseObject(getUrlRes)
        logger.error("step6返回:" + aoi3_jsonData)
        //        val aoi3_jsonData: JSONObject = getJsonObject(url2, lng80, lat80)
        println("=========addr_city_jsonData的数据信息=================")
        println(aoi3_jsonData.toJSONString)
        //提取公共部分
        val aoi3_pub: JSONObject = aoi3_jsonData.getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0)
        aoiid_80 = aoi3_pub.getString("aoi_id")
        aoiname_80 = aoi3_pub.getString("aoi_name")
      } catch {
        case e: Exception => logger.error("第3次调取坐标获取AOI接口异常：" + e.getMessage)
      }
      (waybill_no, aoiid_80, aoiname_80)
    }).toDF("waybill_no", "aoiid_80", "aoiname_80")
    lng_lat_cols_df.unpersist()

    //3 lng lat aoi_id数据接口调用
    val ds_lngLatAoi = lng_lat_aoi_cols_df.map(row => {
      val waybill_no = row.getAs[String]("waybill_no")
      val lng80 = row.getAs[String]("lng80")
      val lat80 = row.getAs[String]("lat80")
      val aoi_id = row.getAs[String]("aoi_id")
      var dist_80_aoiside = 0.0

      try {
        //3 坐标点到AOI距离接口
        val urlParam = getJsonParam(url4, lng80, lat80, aoi_id)
        val getUrlRes: String = HttpInvokeUtil.sendGet(urlParam, "UTF-8", 1)
        val aoid_jsonData: JSONObject = JSON.parseObject(getUrlRes)
        logger.error("step7返回:" + aoid_jsonData)
        //        val aoid_jsonData: JSONObject = getJsonObject(url4, lng80, lat80, aoi_id)
        println("=====坐标点到AOI距离接口====aoid_jsonData的数据信息=================")
        println(aoid_jsonData.toJSONString)
        dist_80_aoiside = aoid_jsonData.getDouble("data")
      } catch {
        case e: Exception => logger.error("第3次调取坐标获取AOI接口异常：" + e.getMessage)
      }
      (waybill_no, dist_80_aoiside)
    }).toDF("waybill_no", "dist_80_aoiside")
    lng_lat_aoi_cols_df.unpersist()
    println("========ds_addrCity==========")
    //    ds_addrCity.show(3)
    (ds_addrCity, ds_lngLat, ds_lngLatAoi)
  }

  /**
   * 功能：df关联获取最终想要的错误数据
   *
   * @param initDF 初始数据
   * @param df     调用接口完毕后，返回的3个接口数据结果
   * @return
   */
  def joinDF(spark: SparkSession, inc_day: String, initDF: DataFrame, df: (DataFrame, DataFrame, DataFrame)): (DataFrame, DataFrame) = {
    val res_df = initDF
      .join(df._1.drop("address", "city"), Seq("waybill_no"), "left").repartition(600, col("waybill_no"))
      .join(df._2, Seq("waybill_no"), "left").repartition(600, col("waybill_no"))
      .join(df._3, Seq("waybill_no"), "left").repartition(600, col("waybill_no"))
      .withColumn("sys_80_aoiname_similarity", when(col("aoiname_80").isNull, null).otherwise(similarity(col("aoi_name"), col("aoiname_80"))))
      .withColumn("inc_day", lit(inc_day))
    res_df.printSchema()
    res_df.persist(StorageLevel.MEMORY_AND_DISK)
    //res_df.show(10)//测试完注释

    val filter1 = col("aoiid_80").isNull || col("aoiid_80") =!= col("aoi_id")
    val filter2 = col("aoiid_80") =!= col("ts_aoiid")
    val filter3 = col("ts_aoiid") === col("aoi_id") && col("dist_80_aoiside") >= 50
    val filter4 = col("sys_80_aoiname_similarity") <= 0.5 || col("aoiid_80").isNull
    val filter5 = col("groupid").isNotNull && col("aoiid_80") === col("stdaddr_aoiid") //todo stdaddr_aoiid字段20211223

    val res_wrong_ds = res_df.filter(filter1 && filter2 && filter3 && filter4)
      .select(
        col("waybill_no"),
        col("userid"),
        col("city"),
        col("aoi_id"),
        col("address"),
        col("company"),
        col("aoi_name"),
        col("lng80"),
        col("lat80"),
        col("lng_ts"),
        col("lat_ts"),
        col("precision_ts"),
        col("ts_aoiid"),
        col("ts_aoiname"),
        col("aoiid_80"),
        col("aoiname_80"),
        col("dist_80_aoiside"),
        col("sys_80_aoiname_similarity"),
        col("inc_day")
      )
    val res_right_ds = res_df.filter(filter1 && !filter2 && filter5)
      .select(
        col("city"),
        col("groupid"),
        col("aoiid_80"),
        col("inc_day")
      )
    res_df.unpersist()
    (res_wrong_ds, res_right_ds)
  }

  /**
   * http发送get请求：根据传入的参数进行http请求补齐，并获取get请求返回值
   *
   * @param urlPattern
   * @param param1
   * @param param2
   * @param param3
   * @return
   */
  def getJsonObject(urlPattern: String, param1: String, param2: String, param3: String = ""): JSONObject = {
    val url = String.format(urlPattern, param1, param2, param3)
    println(url)
    val jsonData: JSONObject = getJsonByGet(url, 2, "UTF-8")
    jsonData
  }

  def dealPostRes(spark: SparkSession, postDF: DataFrame): DataFrame = {
    import spark.implicits._
    val post_filter = notNullDef($"city") && notNullDef($"groupid") && notNullDef($"aoiid_80")

    val res_post_df = postDF
      .filter(post_filter)
      .map(row => {
        val city = row.getAs[String]("city")
        val groupid = row.getAs[String]("groupid")
        val aoiid_80 = row.getAs[String]("aoiid_80")
        val inc_day = row.getAs[String]("inc_day")
//        val postUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId"
        val postUrl = ""
        val params =
          s"""
             |{
             |    "cityCode": "$city",
             |    "addressId": "$groupid",
             |    "aoiId": "$aoiid_80",
             |    "operSource":"LBS_LOC_ERR"//  AOI_ADD
             |}
      """.stripMargin

        val header =
          s"""
             |{"Content-Type": "application/json"}
      """.stripMargin
        var success = ""
        var message = ""

        try {
          val response_str = postResponse(postUrl, params, header)
          val response_json = JSON.parseObject(response_str)
          success = response_json.getString("success")
          message = response_json.getString("message")
          println("========response_str==========" + response_str)
        } catch {
          case e: Exception => logger.error("Connection ……" + e.getMessage)
        }
        (city, groupid, aoiid_80, success, message, inc_day)
      }).toDF("city", "groupid", "aoiid_80", "success", "message", "inc_day")
    res_post_df
  }
}
