package com.sf.rls

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.common.ColumnCommon.notNullDef
import com.sf.common.DataSourceCommon
import constant.HttpConstant.{HTTP_CT_DTL_STEP, HTTP_GD_DTL_STEP}
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.storage.StorageLevel
import utils.ColumnUtil.colGetWeek
import utils.DateUtil.{DEFAULT_DATE_FORMAT, getInterDateList, timeToTimestamp_}
import utils.{HttpInvokeUtil, SparkBuilder}

import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @description: 420543 GIS_RSS_SCM：【路由串联】提频减车线路场景数据输出_V1.0
 * @author 01418539 caojia
 * @date 2022/3/15 16:24
 */
object RoutOptimizitionApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val start_day = args(0)
    val end_day = args(1)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> start calculation>>>>>")
    processRout(spark, start_day, end_day)
    logger.error(s">>>>>>>>>>>>>>>>>>>>>> completely success!")
  }

  def processRout(spark: SparkSession, start_day: String, end_day: String) = {
    import spark.implicits._
    //陆运运力预测预警 cond1 	3万1012
    val monitor_dtl_1 = spark.sql(
      s"""
         |select
         |  line_require_id,    --线路需求ID
         |  owndeptcode,        --车辆管理区
         |  src_zone_code,      --发出网点
         |  dest_zone_code,     --到达网点
         |  line_code,          --线路编码
         |  load_rate,          --装载率
         |  capacityload,       --车型
         |  full_load_weight,   --满载重量
         |  load_bweight,       --计费重量
         |  line_distance,      --线路里程（KM）
         |  plan_time_cost,     --计划运行时长
         |  actual_time_cost,   --实际运行时长[46][60][63][73]
         |  plan_send_batch,    --计划发出班次
         |  actual_send_batch,  --实际发出班次
         |  plan_depart_tm,     --计划发车时间
         |  actual_depart_tm,   --实际发车时间
         |  plan_arrive_batch,  --计划到达班次
         |  actual_arrive_batch,--实际到达班次
         |  plan_arrive_tm,     --计划到车时间 2022-04-12 16:50:00
         |  actual_arrive_tm,   --实际到车时间
         |  transoport_level,   --运输等级
         |  vehicle,            --车辆类型
         |  vehicle_serial      --车牌号
         |from
         |  dm_ops.pass_forecast_road_convy_monitor_dtl
         |where
         |  inc_day >= '$start_day' and inc_day <= '$end_day'
         |  and is_stop_over = '直发'
         |  and car_status = '已完成' --任务状态(1待指派,2已指派,3待执行,4 异常,5执行中,6已完成,7
         |  and substr(src_zone_code, 1, 1) not in ('S','P','M') -- 剔除冷运 和 医 药 20190404
         |  and src_zone_code is not null and trim(src_zone_code) != '' and src_zone_code not in ('852', '853', '886') -- 剔除港澳台20190619
         |  and dest_zone_code is not null and trim(dest_zone_code) != '' and dest_zone_code not in ('852', '853', '886')
         |  and trim(src_zone_code) != trim(dest_zone_code)
         |  and transoport_level in ('一级运输', '二级运输','三级运输')
         |  and actual_time_cost is not null and actual_time_cost != ''
         |  and trim(vehicle) != '虚拟车'
         |""".stripMargin)
    //公路计划需求 6856万6326
    val main_pro = spark.sql(
      s"""
         |select
         |   id as line_require_id
         |from
         |  dm_pass_rss.scha_tt_plan_main_pro
         |where
         |  inc_day = '$end_day'
         |  and id is not null and trim(id) != ''
         |  and oper_type in (1, 2)
         |  and status != 3
         |  and regexp_replace(plan_run_dt,'-','') >= '$start_day' and regexp_replace(plan_run_dt,'-','') <= '$end_day'
         |group by id
         |""".stripMargin)

    //step1 获取运力数据
    val monitor_main_1 = monitor_dtl_1.join(main_pro, Seq("line_require_id"))

    //陆运运力预测预警 cond2 	3万1012
    val monitor_dtl_2 = spark.sql(
      s"""
         |select
         |  line_code,
         |  line_require_id
         |from
         |  dm_ops.pass_forecast_road_convy_monitor_dtl
         |where
         |  inc_day >= '$start_day' and inc_day <= '$end_day'
         |  and line_code is not null and trim(line_code) != ''
         |  and line_require_id is not null and trim(line_require_id) != ''
         |  and car_status = '已完成'
         |  and substr(src_zone_code, 1, 1) not in ('P', 'M')
         |  and src_zone_code not in ('852', '853', '886')
         |  and dest_zone_code not in ('852', '853', '886')
         |""".stripMargin)
    // 209万2196
    val zone_monitor = spark.sql(
      s"""
         |select
         |    line_require_id
         |from
         |    ods_russ.tt_rs_vehicle_task_pass_zone_monitor
         |where
         |  inc_day >= '$start_day' and inc_day <= '$end_day'
         |  and line_require_id is not null and trim(line_require_id) != ''
         |  and regexp_replace(line_require_date,'-','') >= '$start_day' and regexp_replace(line_require_date,'-','') <= '$end_day'
         |  and trim(dept_site_id) != trim(pass_zone_code)
         |group by  line_require_id
         |""".stripMargin)

    val monitor_zone = monitor_dtl_2.join(zone_monitor, Seq("line_require_id"))
      .withColumn("num", row_number().over(Window.partitionBy("line_code").orderBy("line_code")))
      .filter('num === 1)
      .select("line_code")

    val monitor_main_2 = monitor_main_1
      .join(monitor_zone, Seq("line_code"), "left_anti")
      .withColumn("plan_depart_tm_sec", timeToTimestamp_('plan_depart_tm))
      .persist()
    //按照出发和到达地分组  并将满足时间范围的数据合在同一组
    val step1 = monitor_main_2
      .groupBy("src_zone_code", "dest_zone_code")
      .agg(
        concat_ws(",", collect_set('plan_depart_tm_sec)) as "plan_depart_tm_sec"
      )
      .map(
        row => {
          val src_zone_code = row.getAs[String]("src_zone_code")
          val dest_zone_code = row.getAs[String]("dest_zone_code")
          val plan_depart_tm_sec = row.getAs[String]("plan_depart_tm_sec")
          val arr_tm: Array[String] = plan_depart_tm_sec.split(",").sortWith(_.compareTo(_) < 0)
          val tm_inter = new ArrayBuffer[(String, String)]()
          for (i <- 0 until arr_tm.length) {
            for (j <- i + 1 until arr_tm.length) {
              if (arr_tm(j).toLong - arr_tm(i).toLong <= 6 * 60 * 60) { //6小时以内时间间隔
                tm_inter.append((arr_tm(i), arr_tm(j)))
              }
            }
          }
          (src_zone_code, dest_zone_code, tm_inter)
        }).toDF("src_zone_code", "dest_zone_code", "tm_inter")
    //src_zone_code  dest_zone_code 1:00 2:00
    val step2 = step1
      .withColumn("tm_inter_explode", explode('tm_inter))
      .withColumn("tm_start", $"tm_inter_explode"("_1"))
      .withColumn("tm_end", $"tm_inter_explode"("_2"))
      .select("src_zone_code", "dest_zone_code", "tm_start", "tm_end")
      .persist()

    //    val df01 = monitor_main_2.alias("monitor_main_2")
    //      .join(step2.alias("step2"), expr("monitor_main_2.src_zone_code = step2.src_zone_code and  monitor_main_2.dest_zone_code = step2.dest_zone_code and monitor_main_2.plan_depart_tm_sec = step2.tm_start"))
    val df01 = monitor_main_2
      .join(step2.withColumn("plan_depart_tm_sec", col("tm_start")), Seq("src_zone_code", "dest_zone_code", "plan_depart_tm_sec"))
      .withColumn("line_require_id_a", col("line_require_id"))
      .withColumn("owndeptcode_a", col("owndeptcode"))
      .withColumn("line_code_a", col("line_code"))
      .withColumn("plan_depart_tm_a", col("plan_depart_tm"))
      .withColumn("plan_time_cost_a", col("plan_time_cost"))
      .withColumn("plan_arrive_batch_a", col("plan_arrive_batch"))
      .withColumn("line_distance_a", col("line_distance"))
      .withColumn("load_rate_a", col("load_rate"))
      .withColumn("capacityload_a", col("capacityload"))
      .withColumn("transoport_level_a", col("transoport_level"))
      .withColumn("full_load_weight_a", col("full_load_weight"))
      .withColumn("load_bweight_a", col("load_bweight"))
      .withColumn("actual_time_cost_a", col("actual_time_cost"))
      .withColumn("actual_depart_tm_a", col("actual_depart_tm"))
      .withColumn("actual_arrive_tm_a", col("actual_arrive_tm"))
      .withColumn("plan_send_batch_a", col("plan_send_batch"))
      .withColumn("actual_send_batch_a", col("actual_send_batch"))
      .withColumn("actual_arrive_batch_a", col("actual_arrive_batch"))
      .withColumn("plan_arrive_tm_a", col("plan_arrive_tm"))
      .withColumn("vehicle_a", col("vehicle"))

    val df02 = monitor_main_2
      .join(step2.withColumn("plan_depart_tm_sec", col("tm_end")), Seq("src_zone_code", "dest_zone_code", "plan_depart_tm_sec"))
      .withColumn("line_require_id_b", col("line_require_id"))
      .withColumn("owndeptcode_b", col("owndeptcode"))
      .withColumn("line_code_b", col("line_code"))
      .withColumn("plan_depart_tm_b", col("plan_depart_tm"))
      .withColumn("plan_time_cost_b", col("plan_time_cost"))
      .withColumn("plan_arrive_batch_b", col("plan_arrive_batch"))
      .withColumn("line_distance_b", col("line_distance"))
      .withColumn("load_rate_b", col("load_rate"))
      .withColumn("capacityload_b", col("capacityload"))
      .withColumn("transoport_level_b", col("transoport_level"))
      .withColumn("full_load_weight_b", col("full_load_weight"))
      .withColumn("load_bweight_b", col("load_bweight"))
      .withColumn("actual_time_cost_b", col("actual_time_cost"))
      .withColumn("actual_depart_tm_b", col("actual_depart_tm"))
      .withColumn("actual_arrive_tm_b", col("actual_arrive_tm"))
      .withColumn("plan_send_batch_b", col("plan_send_batch"))
      .withColumn("actual_send_batch_b", col("actual_send_batch"))
      .withColumn("actual_arrive_batch_b", col("actual_arrive_batch"))
      .withColumn("plan_arrive_tm_b", col("plan_arrive_tm"))
      .withColumn("vehicle_b", col("vehicle"))
    step2.unpersist()
    monitor_main_2.unpersist()
    //此为part1 的最终结果表
    val combination_a_b_df = df01.join(df02, Seq("src_zone_code", "dest_zone_code", "tm_start", "tm_end"))
      .select(
        "src_zone_code",
        "dest_zone_code",
        "line_require_id_a",
        "owndeptcode_a",
        "line_code_a",
        "plan_depart_tm_a",
        "plan_time_cost_a",
        "plan_arrive_batch_a",
        "line_distance_a",
        "load_rate_a",
        "capacityload_a",
        "transoport_level_a",
        "full_load_weight_a",
        "load_bweight_a",
        "actual_time_cost_a",
        "actual_depart_tm_a",
        "actual_arrive_tm_a",
        "plan_send_batch_a",
        "actual_send_batch_a",
        "actual_arrive_batch_a",
        "plan_arrive_tm_a",
        "vehicle_a",
        "line_require_id_b",
        "owndeptcode_b",
        "line_code_b",
        "plan_depart_tm_b",
        "plan_time_cost_b",
        "plan_arrive_batch_b",
        "line_distance_b",
        "load_rate_b",
        "capacityload_b",
        "transoport_level_b",
        "full_load_weight_b",
        "load_bweight_b",
        "actual_time_cost_b",
        "actual_depart_tm_b",
        "actual_arrive_tm_b",
        "plan_send_batch_b",
        "actual_send_batch_b",
        "actual_arrive_batch_b",
        "plan_arrive_tm_b",
        "vehicle_b"
      )
      .withColumn("avg_load_bweight_a", avg("load_bweight_a").over(Window.partitionBy("src_zone_code", "dest_zone_code", "line_code_a").orderBy("line_code_a")))
      .withColumn("avg_load_bweight_b", avg("load_bweight_b").over(Window.partitionBy("src_zone_code", "dest_zone_code", "line_code_b").orderBy("line_code_b")))
      .persist()
    //    combination_a_b_df.limit(100).collect().foreach(println(_))
    //    combination_a_b_df.show(100)

    //网点经纬度信息
    val zone_lng_lat = spark.sql(
      """
        |select
        |  dept_code,
        |  longitude,
        |  latitude
        |from dim.dim_department
        |where dept_code is not null and trim(dept_code) != ''
        |  and longitude is not null and trim(longitude) != ''
        |  and latitude is not null and trim(latitude) != ''
        |group by dept_code,longitude,latitude
        |""".stripMargin)
      .persist()

    val single_b_fields = combination_a_b_df.select("src_zone_code", "dest_zone_code", "capacityload_b", "plan_depart_tm_b")
      .withColumn("num", row_number().over(Window.partitionBy("src_zone_code", "dest_zone_code", "capacityload_b", "plan_depart_tm_b").orderBy("src_zone_code")))
      .filter('num === 1).drop("num")
      .alias("combination_a_b_df")
      .join(broadcast(zone_lng_lat.alias("zone_lng_lat_src")), expr("combination_a_b_df.src_zone_code = zone_lng_lat_src.dept_code"))
      .join(broadcast(zone_lng_lat.alias("zone_lng_lat_dest")), expr("combination_a_b_df.dest_zone_code = zone_lng_lat_dest.dept_code"))
      .selectExpr(
        "src_zone_code",
        "dest_zone_code",
        "capacityload_b",
        "plan_depart_tm_b",
        "zone_lng_lat_src.longitude as x1",
        "zone_lng_lat_src.latitude as y1",
        "zone_lng_lat_dest.longitude as x2",
        "zone_lng_lat_dest.latitude as y2"
      )
    zone_lng_lat.unpersist()
    //调用高德、传统接口获取数据 time 和 dist 距离
    val ak = "ebf48ecaa1fd436fa3d40c4600aa051f"
    val gd_ct_planB_df = single_b_fields.repartition(1000) //.limit(1000)
      .map(row => {
        val src_zone_code = row.getAs[String]("src_zone_code")
        val dest_zone_code = row.getAs[String]("dest_zone_code")
        val x1 = row.getAs[String]("x1")
        val y1 = row.getAs[String]("y1")
        val x2 = row.getAs[String]("x2")
        val y2 = row.getAs[String]("y2")
        val capacityload_b = row.getAs[String]("capacityload_b")
        val plan_depart_tm_b = row.getAs[String]("plan_depart_tm_b") //2022-04-08 12:10:00
        val planDate = plan_depart_tm_b.replaceAll("[-: ]", "").substring(0, 12) //202204081210

        val param_gd_ct = s"&ak=$ak&x1=$x1&y1=$y1&x2=$x2&y2=$y2&mload=$capacityload_b&planDate=$planDate"
        var gd_steps_str = ""
        var gd_dist: Double = 0.0
        var gd_time: Double = 0.0
        var ct_steps_str = ""
        var ct_dist: Double = 0.0
        var ct_time: Double = 0.0

        try {
          val gd_url = HTTP_GD_DTL_STEP + param_gd_ct
          gd_steps_str = HttpInvokeUtil.sendGet(gd_url, "UTF-8", 1)
          logger.error(s"调取GD返回的结果是：" + gd_steps_str)
          val gd_steps_json: JSONObject = JSON.parseObject(gd_steps_str)
          gd_dist = gd_steps_json.getJSONObject("result").getString("dist").toDouble
          gd_time = gd_steps_json.getJSONObject("result").getString("time").toDouble
        } catch {
          case e: Exception => logger.error("B路线获取高德GD的轨迹信息有异常,请检查传出参数的准确性：" + e.getMessage)
        }
        //内存  多个轨迹节点数据加入
        val ct_trajectory_dist = new ListBuffer[Double]()
        val ct_trajectory_time = new ListBuffer[Double]()

        try {
          val ct_url = HTTP_CT_DTL_STEP + param_gd_ct
          ct_steps_str = HttpInvokeUtil.sendGet(ct_url, "UTF-8", 1)
          logger.error(s"调取CT返回的结果是：" + ct_steps_str)
          val ct_steps_json: JSONObject = JSON.parseObject(ct_steps_str)
          val arr_step = ct_steps_json.getJSONObject("result").getJSONArray("list")
          for (i <- 0 to arr_step.size() - 1) {

            val dist = arr_step.getJSONObject(i).getString("dist").toDouble
            val time = arr_step.getJSONObject(i).getString("time").toDouble
            ct_trajectory_dist.append(dist)
            ct_trajectory_time.append(time)
          }
          ct_dist = ct_trajectory_dist.min
          ct_time = ct_trajectory_time.min
        } catch {
          case e: Exception => logger.error("B路线获取传统CT的轨迹信息有异常,请检查传出参数的准确性：" + e.getMessage)
        }
        (src_zone_code, dest_zone_code, capacityload_b, plan_depart_tm_b, gd_dist, gd_time, ct_dist, ct_time, gd_steps_str, ct_steps_str)
      }).toDF("src_zone_code", "dest_zone_code", "capacityload_b", "plan_depart_tm_b", "gd_dist", "gd_time", "ct_dist", "ct_time", "gd_json", "ct_json")

    val gd_ct_recall_com = combination_a_b_df.join(gd_ct_planB_df, Seq("src_zone_code", "dest_zone_code", "capacityload_b", "plan_depart_tm_b"), "left")
      .na.fill("")
    combination_a_b_df.unpersist()

    //  }
    //  def latestArriveTime(spark: SparkSession, start_day: String, end_day: String) = {
    //    import spark.implicits._
    //1 日需求班次数据
    //公路计划需求停靠点表---	1亿5124万6482
    val point_pro = spark.sql(
      s"""
         |select
         |     dept_code,--网点代码（pass内部使用，外部系统参见upper_dept_code
         |     send_batch,--发出班次 371WB0830
         |     latest_arrival_tm,--最晚到车时间 2021-11-17 16:00:00
         |     send_tm,--新增字段:发车时间  2021-11-17 16:30:00
         |     plan_main_id,--计划需求ID
         |     arrive_batch,--到达班次
         |     inc_day
         |from
         |  dm_pass_rss.scha_tt_plan_point_pro
         |where
         |     inc_day = '$end_day'
         |     and regexp_replace(plan_run_dt,'-','') >= '$start_day' and regexp_replace(plan_run_dt,'-','') <= '$end_day'
         |     and latest_arrival_tm is not null and trim(latest_arrival_tm) != ''
         |     and send_batch is not null and trim(send_batch) != ''
         |     and job_type in ('1', '2', '3')
         |     and point_mean != 3
         |     and point_type = 1
         |""".stripMargin)
    //公路计划需求 6856万6326
    val main_pro_id = spark.sql(
      s"""
         |SELECT
         |   id as plan_main_id
         |from
         |  dm_pass_rss.scha_tt_plan_main_pro
         |where
         |   inc_day = '$end_day'
         |   and oper_type in (1, 2)
         |group by id
         |""".stripMargin)

    val main_point = point_pro.join(main_pro_id, Seq("plan_main_id"))
      .withColumn("num", row_number().over(Window.partitionBy('dept_code, 'send_batch, 'latest_arrival_tm, 'send_tm).orderBy(desc("inc_day"))))
      .withColumn("type", lit("中转"))
      .filter('num === 1).drop('num)
      .select("plan_main_id", "dept_code", "send_batch", "send_tm", "arrive_batch", "latest_arrival_tm","type", "inc_day")
    //2 航管运输班次  591万9980
    val batch_pro = spark.sql(
      s"""
         |select
         |    lastest_arrive_tm as latest_arrival_tm,
         |    cvy_name as plan_main_id,
         |    src_dept_code as dept_code,
         |    dest_arrive_batch as arrive_batch,
         |    src_send_batch as send_batch,
         |    src_send_tm as send_tm,  --新增字段:发车时间
         |    inc_day
         |from
         |    dm_pass_rss.aira_tm_air_transport_batch_pro
         |where
         |    inc_day = '$end_day'
         |    and regexp_replace(send_date,'-','') >= '$start_day' and regexp_replace(send_date,'-','') <= '$end_day'
         |    and practical_cvy_type = 1
         |    and lastest_arrive_tm is not null and trim(lastest_arrive_tm) !=''
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy('dept_code, 'send_batch, 'latest_arrival_tm, 'send_tm).orderBy(desc("inc_day"))))
      .withColumn("type", lit("中转"))
      .filter('num === 1).drop('num)
      .select("plan_main_id", "dept_code", "send_batch", "send_tm", "arrive_batch", "latest_arrival_tm","type", "inc_day")

    //3 收仓数据 收仓班次基础表 67万4395
    val pickup_depot_pro = spark.sql(
      s"""
         |select
         |      last_indepot_tm,--最晚入仓时间:HH:MM，不能早于班次开始时间 018:05
         |      substring(last_indepot_tm, 2, 5) latest_arrival_tm,--18:05
         |      operate_zone_code  as dept_code,--操作网点
         |      batch_code,--班次编码:操作网点+2位数字+P  592AK05P
         |      un_effective_tm,  --失效日期 2020-08-22
         |      effective_tm,  --生效日期 2020-08-22
         |      workday,--适用工作日:1-7数字，不能重复
         |      inc_day
         |    from
         |      dm_pass_rss.sbsa_tm_pickup_depot_pro
         |    where
         |      inc_day = '$end_day'
         |      and regexp_replace(un_effective_tm,'-','') >= '$start_day'
         |      and data_state = 1
         |      and delete_flg = 0
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy('batch_code, 'workday, 'last_indepot_tm).orderBy(desc("inc_day"))))
      .filter('num === 1).drop("num", "last_indepot_tm")
      .withColumn("type", lit("收仓"))
      .withColumn("arrive_batch", lit(""))
      .withColumn("merge_col", lit("1"))

    //4 派仓数据  派仓班次基础表 51万9144
    val deliver_depot_pro_df = spark.sql(
      s"""
         |select
         |	    last_arrive_tm,
         |      substring(last_arrive_tm, 2, 5) latest_arrival_tm,
         |      operate_zone_code as dept_code,
         |      batch_code as send_batch,--20220324 业务确认
         |      un_effective_tm,  --失效日期
         |      effective_tm,  --生效日期
         |      workday,
         |      inc_day
         |    from
         |      dm_pass_rss.sbsa_tm_deliver_depot_pro
         |    where
         |      inc_day = '$end_day'
         |      and regexp_replace(un_effective_tm,'-','') >= '$start_day'
         |      and delete_flg = 0
         |""".stripMargin)
      .withColumn("num", row_number().over(Window.partitionBy('send_batch, 'workday, 'last_arrive_tm).orderBy(desc("inc_day"))))
      .filter('num === 1).drop("num", "last_arrive_tm")
      .withColumn("type", lit("派仓"))
      .withColumn("arrive_batch", lit(""))
      .withColumn("merge_col", lit("1"))

    val date_inter_pub = getInterDateList(start_day, end_day, DEFAULT_DATE_FORMAT)
    val data_pub_df = date_inter_pub.split(",").toSeq
      .toDF("date")
      .withColumn("weekday_type", colGetWeek('date))
      .withColumn("merge_col", lit("1"))
    //收仓
    val pickup_pub_df = pickup_depot_pro.join(data_pub_df, Seq("merge_col"), "left")
      .filter('effective_tm <= 'date && 'date <= 'un_effective_tm && 'workday.contains('weekday_type))
      .withColumn("latest_arrival_tm", concat('date, lit(""), 'latest_arrival_tm, lit(":00")))
      .drop("date", "weekday_type", "merge_col")
      .withColumn("plan_main_id", lit(""))
      .withColumn("send_tm", lit(""))

    //派仓
    val deliver_pub_df = deliver_depot_pro_df.join(data_pub_df, Seq("merge_col"), "left")
      .filter('effective_tm <= 'date && 'date <= 'un_effective_tm && 'workday.contains('weekday_type))
      .withColumn("latest_arrival_tm", concat('date, lit(""), 'latest_arrival_tm, lit(":00")))
      .drop("date", "weekday_type", "merge_col")
      .withColumn("plan_main_id", lit(""))
      .withColumn("send_tm", lit(""))
      .select("plan_main_id","dept_code","send_batch","send_tm","arrive_batch","latest_arrival_tm","type","inc_day")
    /**
     * "plan_main_id","dept_code","arrive_batch","latest_arrival_tm","type","inc_day","batch_code","un_effective_tm","effective_tm","send_time"，
     * "plan_main_id","dept_code","arrive_batch","latest_arrival_tm","type","inc_day","send_batch", "send_tm",
     */
    //todo "send_batch", "send_tm"在收仓派仓中缺少
    val main_batch_df = main_point.union(batch_pro).union(deliver_pub_df)//派仓数据合并
      .filter(notNullDef('latest_arrival_tm) && notNullDef('send_batch) && col("inc_day") =!= "inc_day" && col("inc_day") > "20211001") // inc_day不等于'inc_day' todo  inc_day>20211001数据
      .withColumn("num", row_number().over(Window.partitionBy('dept_code, 'send_batch, 'latest_arrival_tm, 'send_tm).orderBy(desc("inc_day")))) //asc("dept_code"), asc("latest_arrival_tm"), asc("send_batch")
      .filter('num === 1).drop("num")
      .persist()
    val main_batch_df_mid = main_batch_df
      .select("plan_main_id", "dept_code", "send_batch", "send_tm", "arrive_batch", "latest_arrival_tm","type", "inc_day")
      .orderBy(asc("dept_code"), asc("send_tm"),asc("latest_arrival_tm"),asc("send_batch"))

    writeToHive(spark, main_batch_df_mid, Seq("inc_day"), "dm_gis.vehicle_frequency_increase_day_air")

    //"plan_main_id","dept_code","arrive_batch","latest_arrival_tm","type","inc_day","send_batch", "send_tm",
    val last_res = gd_ct_recall_com.join(main_batch_df.withColumnRenamed("send_batch", "plan_arrive_batch_a"), Seq("plan_arrive_batch_a"), "left")
      .filter(timeToTimestamp_('latest_arrival_tm) > timeToTimestamp_('plan_arrive_tm_a)) //判断latest_arrival_tm > plan_arrive_tm_a
      .withColumn("inter_sec", timeToTimestamp_('latest_arrival_tm) - timeToTimestamp_('plan_arrive_tm_a))
      .withColumn("num", row_number().over(Window.partitionBy("src_zone_code", "dest_zone_code", "plan_send_batch_a").orderBy(asc("inter_sec"))))
      .filter('num === 1).drop("num")
      .withColumn("T1", 'latest_arrival_tm) //最接近晚点时间的数据
      .withColumn("T2", ((timeToTimestamp_('latest_arrival_tm) - timeToTimestamp_('plan_depart_tm_b)) / 60) + 10) //单位：分钟 T2=T1-plan_depart_tm_b+10min
      .withColumn("T2_ignore", ((timeToTimestamp_('latest_arrival_tm) - timeToTimestamp_('plan_depart_tm_b)) / 60)) //单位：分钟 T2=T1-plan_depart_tm_b+10min
      .withColumn("plan_depart_tm_inter", (timeToTimestamp_('plan_depart_tm_b) - timeToTimestamp_('plan_depart_tm_a)) / 60)
      .withColumn("actual_depart_tm_inter", (timeToTimestamp_('actual_depart_tm_b) - timeToTimestamp_('actual_depart_tm_a)) / 60)
      .withColumn("pnsTime", when('gd_time > 'ct_time && 'ct_time > 0, 'ct_time).otherwise('gd_time))
      .withColumn("is_punc_optimiz", when('actual_time_cost_b < 'T2, "Y").otherwise("N"))
      .withColumn("is_sing_double", when('pnsTime / 60 < 'T2 && 'is_punc_optimiz === "N", "Y").otherwise("N"))
      .withColumn("loading_rate", when('full_load_weight_b.isNotNull && trim('full_load_weight_b) =!= "", ('avg_load_bweight_a.cast("double") + 'avg_load_bweight_a.cast("double")) / 'full_load_weight_b.cast("double")).otherwise(0))
      .withColumn("is_diliver", when(substring('plan_arrive_batch_a, -1, 1) === "D", "Y").otherwise("N"))
      .select(
        "src_zone_code",
        "dest_zone_code",
        "line_require_id_a",
        "owndeptcode_a",
        "line_code_a",
        "plan_depart_tm_a",
        "plan_time_cost_a",
        "plan_arrive_batch_a",
        "line_distance_a",
        "load_rate_a",
        "capacityload_a",
        "transoport_level_a",
        "full_load_weight_a",
        "load_bweight_a",
        "actual_time_cost_a",
        "actual_depart_tm_a",
        "actual_arrive_tm_a",
        "plan_send_batch_a",
        "actual_send_batch_a",
        "actual_arrive_batch_a",
        "plan_arrive_tm_a",
        "vehicle_a",
        "line_require_id_b",
        "owndeptcode_b",
        "line_code_b",
        "plan_depart_tm_b",
        "plan_time_cost_b",
        "plan_arrive_batch_b",
        "line_distance_b",
        "load_rate_b",
        "capacityload_b",
        "transoport_level_b",
        "full_load_weight_b",
        "load_bweight_b",
        "actual_time_cost_b",
        "actual_depart_tm_b",
        "actual_arrive_tm_b",
        "plan_send_batch_b",
        "actual_send_batch_b",
        "actual_arrive_batch_b",
        "plan_arrive_tm_b",
        "vehicle_b",
        "avg_load_bweight_a",
        "avg_load_bweight_b",
        "plan_depart_tm_inter",
        "actual_depart_tm_inter",
        "T1",
        "T2",
        "T2_ignore",
        "loading_rate",
        "is_diliver",
        "pnsTime",
        "gd_dist",
        "gd_time",
        "ct_dist",
        "ct_time",
        "plan_main_id",
        "dept_code",
        "send_tm",
        "arrive_batch",
        "latest_arrival_tm",
        "type",
        "inter_sec",
        "is_punc_optimiz",
        "is_sing_double",
        "inc_day"
      )
      .persist(StorageLevel.MEMORY_AND_DISK_SER)

//    logger.error(last_res.printSchema())

    val opt_vehicle_res = last_res.filter('is_punc_optimiz === "Y")
      .select(
        "owndeptcode_b",
        "src_zone_code",
        "dest_zone_code",
        "line_code_a",
        "line_distance_a",
        "plan_time_cost_a",
        "plan_depart_tm_a",
        "actual_depart_tm_a",
        "plan_arrive_batch_a",
        "capacityload_a",
        "full_load_weight_a",
        "avg_load_bweight_a",
        "line_code_b",
        "plan_depart_tm_b",
        "actual_depart_tm_b",
        "plan_time_cost_b",
        "actual_time_cost_b",
        "capacityload_b",
        "full_load_weight_b",
        "avg_load_bweight_b",
        "plan_depart_tm_inter",
        "actual_depart_tm_inter",
        "T1",
        "T2",
        "T2_ignore",
        "loading_rate",
        "is_diliver",
        "inc_day"
      )
    writeToHive(spark, opt_vehicle_res, Seq("inc_day"), "dm_gis.vehicle_frequency_increase_task_optimization")
    logger.error("表 dm_gis.vehicle_frequency_increase_task_optimization 更新成功")
    val no_opt_vehicle_res = last_res.filter('is_sing_double === "Y")
      .select(
        "owndeptcode_b",
        "src_zone_code",
        "dest_zone_code",
        "line_code_a",
        "line_distance_a",
        "plan_time_cost_a",
        "plan_depart_tm_a",
        "actual_depart_tm_a",
        "plan_arrive_batch_a",
        "capacityload_a",
        "full_load_weight_a",
        "avg_load_bweight_a",
        "line_code_b",
        "plan_depart_tm_b",
        "actual_depart_tm_b",
        "plan_time_cost_b",
        "actual_time_cost_b",
        "capacityload_b",
        "full_load_weight_b",
        "avg_load_bweight_b",
        "plan_depart_tm_inter",
        "actual_depart_tm_inter",
        "T1",
        "T2",
        "T2_ignore",
        "loading_rate",
        "is_diliver",
        "inc_day"
      )

    writeToHive(spark, no_opt_vehicle_res, Seq("inc_day"), "dm_gis.vehicle_frequency_increase_task_optimization_no")
    logger.error("表 dm_gis.vehicle_frequency_increase_task_optimization_no 更新成功")
    writeToHive(spark, last_res, Seq("inc_day"), "dm_gis.vehicle_frequency_increase_task_plan_a_b_full")
    logger.error("表 dm_gis.vehicle_frequency_increase_task_plan_a_b_full 更新成功")

    main_batch_df.unpersist()
    last_res.unpersist()
  }

}
