package com.sf.rls

import com.sf.common.ColumnCommon.md5EncryptUDF
import com.sf.common.DataSourceCommon
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import utils.JDBCUtils.getDevMysqlConnect
import utils.SparkBuilder
import java.sql.{Connection, PreparedStatement}
import scala.collection.JavaConversions.asScalaIterator

/**
 * @description: 415561 货运导航-偏航反应时间分类汇总及平均偏航时间值
 * @author 01418539 caojia
 * @date 2022年02月25日 11:45
 */
object HyAverageYawTimeApp extends DataSourceCommon {
  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val start_day = args(0)
    val end_day = args(1)

    if (args.length != 2) {
      logger.error(
        """
          |需要输入2个参数：
          |     start_day:起始时间
          |     end_day:结束时间
          |""".stripMargin)
      sys.exit(2022)
    }

    logger.error(s"2个参数---param1为起始时间:$start_day,param2为结束时间:$end_day")
    val res_df = yawTimeCnt(spark, start_day, end_day)

    res_df.persist()
    upsertToMysql(res_df, start_day, end_day)
    writeToHive(spark, res_df, Seq("inc_day"), "dm_gis.gis_navi_yaw_time_cnt")
    res_df.unpersist()

    spark.stop()
  }

  def yawTimeCnt(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    import spark.implicits._
    val initYawDf = spark.sql(
      s"""
         |select navi_id,
         |       yaw_time2,
         |       yaw_time2/1000 as yaw_time_sec,
         |       inc_day
         |from dm_gis.gis_navi_eta_result2
         |where
         |  inc_day between '$start_day' and '$end_day'
         |  and navi_id is not null and trim(navi_id) != ''
         |  and req_type = 'yaw'
         |  and tracks2 is not null and trim(tracks2) != ''
         |  and trackstart_distance < 100
         |  and navi_distance > 1000
         |  and yaw_time2/1000 > 0
         |  and yaw_time2/1000 < 60
         |""".stripMargin)

    val yawClassicDf = initYawDf
      .withColumn("navi_cnt", lit(1))
      .withColumn("l_5cnt", when('yaw_time_sec.cast("double") <= 5, 1).otherwise(0))
      .withColumn("g5_10cnt", when('yaw_time_sec.cast("double") > 5 && 'yaw_time_sec.cast("double") <= 10, 1).otherwise(0))
      .withColumn("g10_15cnt", when('yaw_time_sec.cast("double") > 10 && 'yaw_time_sec.cast("double") <= 15, 1).otherwise(0))
      .withColumn("g15_20cnt", when('yaw_time_sec.cast("double") > 15 && 'yaw_time_sec.cast("double") <= 20, 1).otherwise(0))
      .withColumn("g20_25cnt", when('yaw_time_sec.cast("double") > 20 && 'yaw_time_sec.cast("double") <= 25, 1).otherwise(0))
      .withColumn("g25_30cnt", when('yaw_time_sec.cast("double") > 25 && 'yaw_time_sec.cast("double") <= 30, 1).otherwise(0))
      .withColumn("g30_60cnt", when('yaw_time_sec.cast("double") > 30 && 'yaw_time_sec.cast("double") <= 60, 1).otherwise(0))
      .groupBy("inc_day")
      .agg(
        round(avg('yaw_time_sec), 2) as "yaw_time_avg",
        sum("navi_cnt") as "navi_cnt",
        sum("l_5cnt") as "l_5cnt",
        sum("g5_10cnt") as "g5_10cnt",
        sum("g10_15cnt") as "g10_15cnt",
        sum("g15_20cnt") as "g15_20cnt",
        sum("g20_25cnt") as "g20_25cnt",
        sum("g25_30cnt") as "g25_30cnt",
        sum("g30_60cnt") as "g30_60cnt"
      )
      .withColumn("id", md5EncryptUDF(col("inc_day"), lit("yaw_time"), lit(""), lit("")))
      .select("id", "yaw_time_avg", "navi_cnt", "l_5cnt", "g5_10cnt", "g10_15cnt", "g15_20cnt", "g20_25cnt", "g25_30cnt", "g30_60cnt", "inc_day")
    yawClassicDf
  }

  def upsertToMysql(dataDf: DataFrame, start_day: String, end_day: String): Unit = {
    val connection: Connection = getDevMysqlConnect()
    try {
      val querySql = s"select * from GIS_NAVI_YAW_TIME_CNT where STATDATE >= '$start_day' and STATDATE <= '$end_day'"
      val query: PreparedStatement = connection.prepareStatement(querySql)
      val queryRes = query.executeQuery()
      while (queryRes.next()) {
        val delSql = s"delete from GIS_NAVI_YAW_TIME_CNT where STATDATE >= '$start_day' and STATDATE <= '$end_day'"
        val del: PreparedStatement = connection.prepareStatement(delSql)
        del.execute()
      }
    } catch {
      case ex: Exception => logger.error(s"删除表 A_TEST_DUPLICATION 中$start_day 至 $end_day 数据时出现错误", ex)
        throw ex
    }
    //循环遍历数据写入
    dataDf.toLocalIterator.foreach(row => {
      try {
        val insertSql = s"insert into GIS_NAVI_YAW_TIME_CNT values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
        val insert: PreparedStatement = connection.prepareStatement(insertSql)
        insert.setString(1, row.getAs[String]("id"))
        insert.setString(2, row.getAs[String]("inc_day"))
        insert.setDouble(3, row.getAs[Double]("yaw_time_avg"))
        insert.setLong(4, row.getAs[Long]("navi_cnt"))
        insert.setLong(5, row.getAs[Long]("l_5cnt"))
        insert.setLong(6, row.getAs[Long]("g5_10cnt"))
        insert.setLong(7, row.getAs[Long]("g10_15cnt"))
        insert.setLong(8, row.getAs[Long]("g15_20cnt"))
        insert.setLong(9, row.getAs[Long]("g20_25cnt"))
        insert.setLong(10, row.getAs[Long]("g25_30cnt"))
        insert.setLong(11, row.getAs[Long]("g30_60cnt"))
        insert.setString(12, row.getAs[String]("inc_day"))
        insert.setNull(13, 0)
        insert.setString(14, row.getAs[String]("inc_day"))
        insert.setNull(15, 0)
        insert.execute()
      } catch {
        case ex: Exception => logger.error(s"往表 A_TEST_DUPLICATION 中插入$start_day 至 $end_day 数据时出现错误", ex)
          throw ex
      }
    })
  }

}
