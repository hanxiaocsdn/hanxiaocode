package com.sf.rls

import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import utils.DateUtil.colValueFun
import utils.SparkBuilder

/**
 * @author 01418539 (临时执行 已下线)
 * @date 2022年01月11日 19:45
 */
object WaybillCoincWriteApp {
  val logger = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val spark = SparkBuilder.initSpark(this.getClass.getSimpleName)
    val start_day = args(0)
    val end_day = args(1)
    val union_df = loadUnionData(spark, start_day, end_day).persist()
    val first_res_df = loadFirstData(spark, start_day, end_day)
    val second_res_df = loadSecondData(spark, start_day, end_day)
    val third_res_df = loadThirdData(spark, start_day, end_day)
    val forth_res_df = loadForthData(spark, start_day, end_day)

    val join_ds = joinAll(union_df, first_res_df, second_res_df, third_res_df, forth_res_df, end_day)

    join_ds.createOrReplaceTempView("join_ds")
    val sql = String.format("insert overwrite table %s partition(inc_day) select * from %s", "dm_gis.waybill_coninc_middle", "join_ds");
    spark.sql(sql)
  }

  def loadUnionData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    //1 下call 收件量（不吻合）
    val init_call_df = spark.sql(
      s"""
         |select
         |  trim(regexp_replace(dest_dept_code,'([^a-zA-Z0-9]+)','')) as dest_dept_code,--	网点编码
         |  trim(regexp_replace(act_code,'([^a-zA-Z0-9]+)','')) as act_code,--揽收员工工号
         |  trim(regexp_replace(waybillno,'([^a-zA-Z0-9]+)','')) as waybill_no,--订单号
         |  inc_day
         |from dm_tc_waybillinfo.execution_detail_shou
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |      and is_distribute_receipt='否'
         |      and dest_dept_code is not null and trim(dest_dept_code) !=''
         |      and act_code is not null and trim(act_code) !=''
         |      and waybillno is not null and trim(waybillno) !=''
         |""".stripMargin)

    //2 扫码 收件量（不吻合）
    val init_app_df = spark.sql(
      s"""
         |select
         |  trim(regexp_replace(zonecode,'([^a-zA-Z0-9]+)','')) as dest_dept_code,--实际揽收网点
         |  trim(regexp_replace(act_loginid,'([^a-zA-Z0-9]+)',''))  as act_code,--	实际揽收小哥(sds)
         |  trim(regexp_replace(waybill_no,'([^a-zA-Z0-9]+)','')) as waybill_no,--订单号
         |  inc_day
         |from
         |dm_tdos.application_nocall_pick_time
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |      and is_wh='N'
         |      and zonecode is not null and trim(zonecode) !=''
         |      and act_loginid is not null and trim(act_loginid) !=''
         |      and waybill_no is not null and trim(waybill_no) !=''
         |""".stripMargin)

    //合并两类 收件量（不吻合）
    val call_app_df = init_call_df.select("dest_dept_code", "act_code", "waybill_no","inc_day")
      .union(init_app_df.select("dest_dept_code", "act_code", "waybill_no","inc_day"))

    //自己区域--AOI
    val own_area_df1 = spark.sql(
      s"""
         |select
         |   trim(regexp_replace(waybillno,'([^a-zA-Z0-9]+)','')) as waybill_no,
         |   eventtype,
         |	 eventlng,
         |   eventlat,
         |   inc_day
         |from ods_inc_sgs_core.inc_sgs_task_flow_new
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |      and eventtype in ('31201','31127')
         |      and waybillno is not null and trim(waybillno)!=''
         |      and eventlng is not null and trim(eventlng)!=''
         |      and eventlat is not null and trim(eventlat)!=''
         |group by trim(regexp_replace(waybillno,'([^a-zA-Z0-9]+)','')),eventlng,eventlat,eventtype,inc_day
         |""".stripMargin)

    val own_area_df2 = spark.sql(
      s"""
         |select
         |   trim(regexp_replace(waybillno,'([^a-zA-Z0-9]+)','')) as waybill_no,
         |	 eventlng,
         |   eventlat,
         |   inc_day,
         |   max(eventtype) as eventtype
         |from ods_inc_sgs_core.inc_sgs_task_flow_new
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |      and eventtype in ('31201','31127')
         |      and waybillno is not null and trim(waybillno)!=''
         |      and eventlng is not null and trim(eventlng)!=''
         |      and eventlat is not null and trim(eventlat)!=''
         |group by trim(regexp_replace(waybillno,'([^a-zA-Z0-9]+)','')),eventlng,eventlat,inc_day
         |""".stripMargin)

    val own_area_df = own_area_df1.join(own_area_df2, Seq("waybill_no", "eventlng", "eventlat","inc_day"))

    val init_call_t1 = call_app_df.join(own_area_df, Seq("waybill_no","inc_day"))

    init_call_t1
  }

  def loadFirstData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    import spark.implicits._
    //--客户下单经纬度-AOI
    val init_custom_order_df = spark.sql(
      s"""
         |select
         |   trim(regexp_replace(appoint_internal_no,'([^a-zA-Z0-9]+)','')) as order_no,--	流水号（用于做分库字段）
         |   addition_key,
         |   addition_value,
         |   inc_day
         |from ods_shiva_oms.tt_appoint_addition
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |      and appoint_internal_no is not null and trim(appoint_internal_no)!=''
         |      and addition_key in ('LONGITUDE','LATITUDE')
         |""".stripMargin)

    //--客户下单经纬度-AOI
    val hook_df = spark.sql(
      s"""
         |select
         |  trim(regexp_replace(order_no,'([^a-zA-Z0-9]+)','')) as order_no,
         |  trim(regexp_replace(waybill_no,'([^a-zA-Z0-9]+)','')) as waybill_no,
         |  inc_day
         |from dm_gis.tt_order_hook
         |where inc_day>= '$start_day' and inc_day<='$end_day'
         |      and order_no is not null and trim(order_no)!=''
         |      and waybill_no is not null and trim(waybill_no)!=''
         |""".stripMargin)

    val first_cond_res = init_custom_order_df.join(hook_df, Seq("order_no","inc_day"))
      .select("waybill_no", "addition_key", "addition_value","inc_day") //580w5444
      .withColumn("longitude", when($"addition_key" === "LONGITUDE", $"addition_value"))
      .withColumn("latitude", when($"addition_key" === "LATITUDE", $"addition_value"))
      .groupBy("waybill_no","inc_day")
      .agg(
        max("longitude") as "longitude",
        max("latitude") as "latitude"
      ) //300w~

    first_cond_res
  }

  def loadSecondData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    //客户填写寄件地址---AOI
    val second_cond_res = spark.sql(
      s"""
         |select
         |  trim(regexp_replace(waybill_no,'([^a-zA-Z0-9]+)','')) as waybill_no,
         |  aoi_id as aoi_id2,
         |  inc_day
         |from dm_gis.tt_order_hook
         |where inc_day>= '$start_day' and inc_day<='$end_day'
         |      and waybill_no is not null and trim(waybill_no)!=''
         |      and aoi_id is not null and trim(aoi_id)!=''
         |""".stripMargin)

    second_cond_res
  }

  def loadThirdData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    //自己区域aoi
    val init_own_area_df = spark.sql(
      s"""
         |select
         |   trim(regexp_replace(dept_code,'([^a-zA-Z0-9]+)','')) as dest_dept_code,
         |   trim(regexp_replace(emp_no,'([^a-zA-Z0-9]+)','')) as act_code,
         |   aoi_id,
         |   inc_day
         |from dm_tc_waybillinfo.sds_scheduling_result
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |""".stripMargin)
    val own_area_df = init_own_area_df
      .withColumn("aoi_code", explode(split(colValueFun(col("aoi_id"), col("act_code")), ",")))
      .drop("aoi_id")
    //aoi_code取值
    val aoi_sch_df = spark.sql(
      s"""
         |select
         |   trim(regexp_replace(aoi_code,'([^a-zA-Z0-9]+)','')) as aoi_code,
         |   aoi_id
         |from dm_gis.cms_aoi_sch
         |""".stripMargin)
    val third_conf_res = own_area_df.join(aoi_sch_df, Seq("aoi_code"))
      .groupBy("dest_dept_code", "act_code","inc_day")
      .agg(concat_ws(",", collect_set("aoi_id")) as "aoi_id3")

    third_conf_res //todo 此处最终数据为0  与union join没关联上
  }

  def loadForthData(spark: SparkSession, start_day: String, end_day: String): DataFrame = {
    //网点-AOI
    val forth_cond_res = spark.sql(
      s"""
         |select
         |  trim(regexp_replace(zno_code,'([^a-zA-Z0-9]+)','')) as dest_dept_code,
         |  lng,
         |  lat,
         |  inc_day
         |from dm_gis.polygon_all
         |where inc_day>='$start_day' and inc_day<='$end_day'
         |      and state in (1,3)
         |      and type='1'
         |      and level in (4,5)
         |      and lng is not null and trim(lng)!=''
         |      and lat is not null and trim(lat)!=''
         |""".stripMargin) //3w4115
    forth_cond_res
  }

  def joinAll(union_df: DataFrame, first_cond_res: DataFrame, second_cond_res: DataFrame, third_conf_res: DataFrame, forth_cond_res: DataFrame, end_day: String): DataFrame = {
    val last_res = union_df
      .join(first_cond_res, Seq("waybill_no","inc_day"), "left")
      .join(second_cond_res, Seq("waybill_no","inc_day"), "left")
      .join(third_conf_res, Seq("dest_dept_code", "act_code","inc_day"), "left")
      .join(forth_cond_res, Seq("dest_dept_code","inc_day"), "left")
      .select("dest_dept_code", "act_code", "waybill_no", "eventlng", "eventlat", "longitude", "latitude", "lng", "lat", "aoi_id2", "aoi_id3", "inc_day")
    last_res
  }
}


