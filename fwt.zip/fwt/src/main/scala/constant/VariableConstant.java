package constant;

import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;

import java.util.Properties;
import java.util.Set;

/**
 * @author 01418539
 * @date 2021年12月02日 11:32
 */
public class VariableConstant {
    public static String appType = null;
    public static String src = null;
    public static int partitions = 1200;
    public static int cores = 8;
    public static Properties configProps = null;
    public static Set<Integer> acLimitCodeSet = null;
    public static Set<String> provLevelCitySet = null;
    public static JavaSparkContext sc = null;
    public static SparkSession spark = null;
}
