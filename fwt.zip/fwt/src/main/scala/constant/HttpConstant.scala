package constant

/**
 * @author 01418539
 * @date 2022年01月18日 11:34
 */
object HttpConstant {
  //根据车牌号及时间点获取停留时间段信息
  lazy val HTPP_STAY_POINTS_P = s"http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/queryDetail"

  //根据经纬度获取停留点信息
  lazy val HTPP_RGEO_X_Y_G = s"http://gis-int.int.sfdc.com.cn:1080/rgeo/api?x=%s&y=%s&opt=sf1&ak=%s"

  //纠偏服务 经纬度矩形框
  lazy val HTPP_GIS_NAVI_ROAD_P = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/qRoad"

  //高德路况接口
  lazy val HTTP_GD_ROAD_COND_P = "http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/tmc/history2"

  //调经验速度接口
  lazy val HTTP_JY_ROAD_COND_P = "http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/getExprCost"

  //根据swid 获取 轨迹点信息接口 5000/min
  lazy val HTTP_XY_COORDS_P = "http://gis-int2.int.sfdc.com.cn:1080/rp/qm_point/sf?"

  //融合历史轨迹接口
  lazy val HTTP_TRACK_INTEGRATION_REP_P = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"

  //纠偏获取停留信息
  lazy val HTTP_LSS_RECTIFY_P = "http://gis-int.int.sfdc.com.cn:1080/lssrectify/api/rectify"

  //时效标准线路接口 并发500/min
  lazy val HTTP_ETA_STDLINE_P = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/query"

  //时长提报 并发100/S
  lazy val HTTP_LINE_TIME_P = "http://gis-rss-scm-plan-data.int.sfcloud.local:1080/app/external/calculateSuggestLineTime"

  //********非大数据平台****swid 获取道路名称 + points 信息--物理机单台 1000个link--200并发==20w/s
  lazy val HTTP_CLUSTER_LINK_P = "http://10.216.162.38:7170/cluster_link"

  //------------以下接口暂无使用任务-------------------------------------------------------------------------
  //******接口无使用，主类保留*****
  //******根据地址信息获取区域+镇信息
  lazy val HTTP_ADDR_CODE_TOWN = s"http://gis-int.int.sfdc.com.cn:1080/seg/api/split?ak=%s&address=%s"

  //******地址信息获取地址关键字段信息 get
  lazy val HTTP_ADDR_KW = s"http://gis-int.int.sfdc.com.cn:1080/iad/api/keyword?ak=%s&address=%s&addrType=0"

  //******根据经纬度获取网点信息数据 get
  lazy val HTPP_LNG_LAT_CODE = s"http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=SX&ak=%s&lng=%s&lat=%s"

  //******调用高德规划接口
  lazy val HTTP_GD_DTL_STEP = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&passport=100000&tolls=1&test=0&stype=0&etype=2&pathCount=1&fencedist=50&merge=4&fixedroute=2&frequency=1&type=0&cc=1&strategy=0&opt=gd3"

  //******调用传统规划接口
  lazy val HTTP_CT_DTL_STEP = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/get?url=http://gis-int2.int.sfdc.com.cn:1080/rp/v2/api&passport=100000&tolls=1&test=0&stype=0&etype=2&pathCount=2&fencedist=50&merge=4&fixedroute=2&frequency=1&type=0&cc=1&strategy=0&opt=sf2"

  //******根据车牌号和车牌 imei号+时间 调取算法接口
  lazy val HTPP_VEHICLE_IMEI_P = s"http://10.240.23.123:80/vision_strategy"

  //******根据经纬度 返回停车点id 停车场规模
  lazy val HTPP_CLOUD_X_Y_G = s"http://10.242.4.97:1325/check_within_parking_area/?lon=%s&lat=%s" //new 10.242.4.97 old 10.220.21.49

  //******根据swid获取区域经纬度等相关信息
  lazy val HTPP_GIS_JP_LINK_SWID_G = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/roadAttr?gzip=0&swId=%s&output=json&mask=31&ak=%s&roadAttrToken=%s"

  //******货车轨迹点接口
  lazy val HTTP_GIS_GW_TRACK_P = "http://gis-gw.int.sfdc.com.cn:9080/dt/api/query"

  //******根据轨迹获取事件信息 1000次/分钟
  lazy val HTTP_STANDARD_EVENT_P = "http://gis-int.int.sfdc.com.cn:1080/tmcgd/api/tmc/history2?"

  //******调用标准线路配置接口
  lazy val HTTP_STAND_ROAD_COND_P = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/getLine"

  //******调用事件接口/提报数据接口
  lazy val HTTP_EVENT_REPORT_COND_P = "http://gis-int.int.sfdc.com.cn:1080/rp/qm_point/sf"

  //******调用标准线路数据更新接口
  lazy val HTTP_STAND_UPDATE_COND_P = "http://gis-int2.int.sfdc.com.cn:1080/etaStdLine/operate/addLine"

  //******获取油站数据
  lazy val HTTP_GAS_STATION_DATA_P = "http://gis-rss-ddjy-gas-c.int.sfcloud.local:1080/getGasStationData"

  //******根据swid 获取 轨迹点信息借口 5000/min
  lazy val HTTP_QUERY_ROAD_ATTR_P = "http://gis-int2.int.sfdc.com.cn:1080/rp/navi/query/roadAttr"

  //******视频提取-提交工单 并发是默认每分钟100次。
  lazy val HTTP_EFFI_VEDIO_P = "http://gis-rss-scm-stsoc-data.int.sfcloud.local:1080/app/api/workOrder"

  //******轨迹接口 10000/min
  lazy val HTTP_TRACK_DELAY_P = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrateDetail"

  //******获取网点附近油站接口
  lazy val HTTP_QUERY_ADJUST_PATH_P = "http://gis-int.int.sfdc.com.cn:1080/rp/navi/query/adjustPath"

  //******接口已无使用，主类*******
  //******根据地址获取图商坐标
  lazy val HTTP_URL_GEO = s"http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=%s&opt=gd2&address=%s&city=%s"

  //******坐标获取AOI接口 ak  e781937be5314dd1bdbb98c1f968824f
  lazy val HTTP_URL_DEPT2 = s"http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=%s"

  //******派件容灾环境接口 ak  dec044d089524419b371bc94555c539d
  lazy val HTTP_URL_DISPATCH = s"http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=%s&opt=zh&company=&tel=&mobile=&showserver=true"

  //******坐标点到AOI距离接口 no ak
  lazy val HTTP_URL_DISTANCE = s"http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?x=%s&y=%s&aoiId=%s&type=side"

  //******经纬度获取AOI信息
  lazy val HTTP_URL_AOI = s"http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/byxy?x=%s&y=%s&ak=%s"

  //******POST请求-根据传入城市编号 获取对应地点信息
  lazy val HTTP_URL_ADDRESS = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId"

  //******根据经纬度获取网点信息数据 get
  lazy val HTPP_LNG_LAT_AOI = s"http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-apis.int.sfcloud.local:1080/dept2/byxy&ak=%s&x=%s&y=%s&opt=aoi&geom=0"
  //******根据输入车牌号、司机实际出发事件、司机实际到达时间调用融合历史轨迹接口
  lazy val HTTP_TRACK_INTEGRATION_P = "http://gis-vms-query-new.int.sfcloud.local:1080/trackquery-new/api/integrate"
}
