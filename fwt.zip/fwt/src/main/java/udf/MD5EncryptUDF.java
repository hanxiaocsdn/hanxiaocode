package udf;

import com.google.common.base.Strings;
import com.google.common.hash.Hashing;
import org.apache.commons.compress.utils.Charsets;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * @author 01418539
 * @date 2021年12月09日 15:24
 */
public class MD5EncryptUDF extends UDF {
    //重写evaluate
    public static String evaluate(String...input) {
        //传入多个参数生成唯一主键
        StringBuilder str = new StringBuilder();
        for (String s : input) {
            str.append(s);
        }
        String inputStr = str.toString();

        if (Strings.isNullOrEmpty(inputStr.trim())) {
            return null;
        }
        return Hashing.md5().newHasher().putString(inputStr, Charsets.UTF_8).hash().toString();

    }


//    public static void main(String[] args) {
//        System.out.println(evaluate("20211209","sim1top1","new"));
//        System.out.println(evaluate("20211209sim1top1new"));
//        System.out.println(evaluate("20211209sim1top1"));
//        System.out.println(evaluate("20211209sim5top1"));
//        System.out.println(evaluate("20211209sim15"));
//        System.out.println(evaluate("20211210sim15"));
//        System.out.println(evaluate("20211210sim15",null));
//    }
}





