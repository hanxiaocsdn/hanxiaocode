package utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.Properties;

/**
 * @description: 读取配置文件工具类
 * @author 01418539 caojia
 * @date 2022/7/14 13:46
 */
public class ConfigUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(ConfigUtils.class);

    private static final ConfigUtils self = new ConfigUtils();

    private ConfigUtils(){}

    public static Properties readConfig() {
        String filePath = "application.properties";
        return self.config(filePath);
    }

    public static Properties readConfig(String filePath) {
        return self.config(filePath);
    }

    private Properties config(String filePath) {
        Properties prop = new Properties();
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(filePath);
        try {
            prop.load(inputStream);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return prop;
    }

}
