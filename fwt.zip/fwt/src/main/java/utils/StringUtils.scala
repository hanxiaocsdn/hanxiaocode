package utils;

/**
 * Created by 01374443 on 2020/3/25.
 */
object StringUtils {

  def isEmpty(str: String): Boolean = {str == null || str.isEmpty}

  def nonEmpty(str: String): Boolean = str != null && !str.isEmpty

  def nonEmptyEq(str1: String, str2: String): Boolean = {
    if (str1 == null || str2 == null) return false
    str1.equals(str2)
  }
}

