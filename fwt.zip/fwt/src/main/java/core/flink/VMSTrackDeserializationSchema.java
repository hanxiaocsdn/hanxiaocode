package core.flink;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.String;
import org.apache.flink.api.common.serialization.DeserializationSchema;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.typeutils.TypeExtractor;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
/**
 * @author 01418539 caojia
 * @description: core.flink.VMSTrackDeserializationSchema
 * @date 2022/3/22 14:31
 */
public class VMSTrackDeserializationSchema implements DeserializationSchema<String> {
    public String deserialize(byte[] bytes) throws IOException {
        // 注意: 函数 byte[] 类型的参数名为 bytes
        return uncompressToString(bytes,"utf-8");
    }

    public boolean isEndOfStream(String t) {
        return false;
    }

    public TypeInformation<String> getProducedType() {
        return TypeExtractor.getForClass(String.class);
    }

    /*
     *解压缩
     */
    public static String uncompressToString(byte[] bytes, String encoding) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayInputStream in = new ByteArrayInputStream(bytes);
        try {
            GZIPInputStream ungzip = new GZIPInputStream(in);
            byte[] buffer = new byte[256];
            int n;
            while ((n = ungzip.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
            return out.toString(encoding);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
}