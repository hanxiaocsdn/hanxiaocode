package com.sf.gis.java.sx.constant.util;

public class GetSimilar {

    public static Double getReult(String word,String aoiname) {
        String prefix = "http://10.119.72.209:8080/rds_web/noControl/similar/";
        StringBuilder sb = new StringBuilder();
        sb.append(prefix).append(word).append("/").append(aoiname);
        String s = sb.toString();
        try{
            String s1 = HttpClientUtils.httpGetRequest(s).toString();
            double v = Double.parseDouble(s1);
            return v;
        }catch (Exception e){
            return 0.0;
        }


    }







}
