package com.sf.gis.java.sx.constant.util;

import java.io.Serializable;
//标签类
public  class EnumKuaiyunWdTag implements Serializable {
    public static final String drop = "drop";
    public static final String gisEmpty = "gisEmpty";
    public static final String same = "same";
    public static final String addressEmpty = "addressEmpty";
    public static final String multiReq = "multiReq";
    public static final String multiSign = "multiSign";
    public static final String destAddressModify = "destAddressModify";
    public static final String signNotLocalCity = "signNotLocalCity";
    public static final String allDeptSame = "allDeptSame";
    public static final String allAoiSame = "allAoiSame";
    public static final String noLocal = "noLocal";
    public static final String drawWrong = "drawWrong";
    public static final String outletsNoExist = "outletsNoExist";
    public static final String sameTeamCode = "sameTeamCode";
};

