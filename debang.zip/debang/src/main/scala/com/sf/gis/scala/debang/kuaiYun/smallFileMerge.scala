package com.sf.gis.scala.debang.kuaiYun

import Kuaiyun_tmp.{logger, startSta}
import com.sf.gis.scala.debang.util._
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.{lit, _}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object smallFileMerge {
  @transient lazy val logger: Logger = Logger.getLogger(smallFileMerge.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val sqlpartition = 200
  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    val startDay2 = args.apply(2)
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days,startDay2)
    logger.error("结束所有运行")

  }


  def start(startDay: String, days: Int,startDay2:String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error("开始计算：" + startDay)
    startSta(spark,startDay,startDay2,days)
    logger.error("计算结束：" + startDay)
    logger.error("统计完毕")
  }



  def startSta(spark: SparkSession, incDay: String,startDay2:String,days:Int) = {
        var  formatDay= incDay
        for (i <- 0 until days) {
          val sepDay = DateUtil.getDateStr(formatDay, 10, "")
          logger.error("获取数据源formatDay:"+formatDay+"sepDay :"+sepDay)
          //取数据源
          val dataDf = getDataDf(spark,formatDay,sepDay)
          logger.error("开始入库")
          //入库
          saveTable(spark,dataDf,incDay)
          formatDay = sepDay
          logger.error("结束所有运行")
        }
  }
//入库
  def saveTable(spark: SparkSession,  saveRdd:DataFrame ,incDay: String): Unit = {
    logger.error("最终表数据：" + saveRdd.count())
//    val tableName = "dm_gis.aoi_real_acc_rate_report_tmp" //生产数据表
    val tableName2 = "dm_gis.xiaoge_trajectory_monitor_2_tmp2" //生产数据表
//    saveRdd.coalesce(20).write.mode(SaveMode.Overwrite).insertInto(tableName)
    saveRdd.coalesce(4000).write.mode(SaveMode.Overwrite).insertInto(tableName2)
    logger.error("导数完成，创建新表")
    val delSql = """drop table IF  EXISTS dm_gis.xiaoge_trajectory_monitor_2_tmp1"""
    logger.error(delSql)
    spark.sql(delSql)
    val createSql=
      """
        |CREATE TABLE IF NOT EXISTS dm_gis.xiaoge_trajectory_monitor_2_tmp1(
        |area_code	string	comment '地区代码'
        |,area_name	string	comment '地区名称'
        |,city_code	string	comment '城市代码'
        |,city_name	string	comment '城市名称'
        |,dept_code	string	comment '网点代码'
        |,dept_addr	string	comment '点部地址'
        |,emp_code	string	comment '工号'
        |,emp_name	string	comment '员工姓名'
        |,position_name	string	comment '岗位'
        |,plan_aoi_area_list	string	comment '排班aoi区域'
        |,dept_aoi_id	string	comment '网点aoiid'
        |,is_aoi_area	string	comment '网点是否排班区域'
        |,dept_aoi_area	string	comment '网点归属aoi区域'
        |,first_into_dept_time	string	comment '第一次进入网点时间'
        |,last_out_dept_time	string	comment '最后一次离开网点时间'
        |,dist_all	string	comment '全量里程'
        |,effective_workhour	string	comment '全天有效工作时长'
        |,hour_0_5_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_0_5_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_0_5_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_0_5_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_0_5_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_0_5_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_0_5_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_0_5_move_period_time_m	string	comment '移动时长'
        |,hour_0_5_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_5_6_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_5_6_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_5_6_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_5_6_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_5_6_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_5_6_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_5_6_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_5_6_move_period_time_m	string	comment '移动时长'
        |,hour_5_6_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_6_7_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_6_7_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_6_7_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_6_7_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_6_7_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_6_7_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_6_7_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_6_7_move_period_time_m	string	comment '移动时长'
        |,hour_6_7_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_7_8_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_7_8_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_7_8_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_7_8_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_7_8_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_7_8_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_7_8_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_7_8_move_period_time_m	string	comment '移动时长'
        |,hour_7_8_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_8_10_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_8_10_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_8_10_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_8_10_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_8_10_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_8_10_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_8_10_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_8_10_move_period_time_m	string	comment '移动时长'
        |,hour_8_10_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_10_12_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_10_12_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_10_12_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_10_12_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_10_12_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_10_12_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_10_12_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_10_12_move_period_time_m	string	comment '移动时长'
        |,hour_10_12_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_12_14_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_12_14_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_12_14_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_12_14_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_12_14_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_12_14_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_12_14_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_12_14_move_period_time_m	string	comment '移动时长'
        |,hour_12_14_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_14_16_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_14_16_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_14_16_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_14_16_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_14_16_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_14_16_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_14_16_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_14_16_move_period_time_m	string	comment '移动时长'
        |,hour_14_16_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_16_18_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_16_18_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_16_18_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_16_18_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_16_18_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_16_18_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_16_18_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_16_18_move_period_time_m	string	comment '移动时长'
        |,hour_16_18_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_18_20_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_18_20_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_18_20_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_18_20_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_18_20_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_18_20_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_18_20_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_18_20_move_period_time_m	string	comment '移动时长'
        |,hour_18_20_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_20_21_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_20_21_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_20_21_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_20_21_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_20_21_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_20_21_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_20_21_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_20_21_move_period_time_m	string	comment '移动时长'
        |,hour_20_21_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_21_22_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_21_22_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_21_22_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_21_22_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_21_22_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_21_22_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_21_22_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_21_22_move_period_time_m	string	comment '移动时长'
        |,hour_21_22_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_22_23_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_22_23_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_22_23_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_22_23_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_22_23_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_22_23_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_22_23_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_22_23_move_period_time_m	string	comment '移动时长'
        |,hour_22_23_consignee_delivery_waybill	string	comment '收派件量'
        |,hour_23_24_is_plan_period_intersection	string	comment '班次与周期是否有交集'
        |,hour_23_24_dept_inner_work_m	string	comment '网点内工作时长'
        |,hour_23_24_dept_inner_other_m	string	comment '网点内其他时长'
        |,hour_23_24_plan_aoi_inner_work_m	string	comment '区域内工作时长'
        |,hour_23_24_plan_aoi_inner_other_m	string	comment '区域内其他时长'
        |,hour_23_24_plan_aoi_outter_work_m	string	comment '区域外工作时长'
        |,hour_23_24_plan_aoi_outter_other_m	string	comment '区域外其他时长'
        |,hour_23_24_move_period_time_m	string	comment '移动时长'
        |,hour_23_24_consignee_delivery_waybill	string	comment '收派件量'
        |,plan_aoi_inner_work_total_hour	string	comment '区域内工作总时长'
        |,plan_aoi_outter_work_total_hour	string	comment '区域外工作总时长'
        |,dept_inner_work_total_hour	string	comment '网点内工作总时长'
        |,plan_aoi_inner_other_work_total_hour	string	comment '区域内其他总时长'
        |,plan_aoi_outter_other_work_total_hour	string	comment '区域外其他总时长'
        |,dept_inner_other_work_total_hour	string	comment '网点内其他总时长'
        |,delivery_consignee_amount	string	comment '全天收派件量'
        |,op_before_time	string	comment '作业开始前在网点总时长'
        |,op_after_time	string	comment '作业结束后在网点总时长'
        |,coor_aoi_req	string	comment '坐标查询aoi请求'
        |,coor_aoi_resp	string	comment '坐标查询aoi返回'
        |,addr_aoi_req	string	comment '地址查询aoi请求'
        |,addr_aoi_resp	string	comment '坐标查询aoi返回'
        |,planaoiidlist	string	comment '排班区域列表'
        |,plantimelist	string	comment '排班时间集合'
        |,tracklist	string	comment '小哥全天轨迹,纠偏前'
        |,trackaoiareamap	string	comment '轨迹经过的aoi区域'
        |,trackaoimap	string	comment '轨迹经过的aoi'
        |,fvplist	string	comment '巴枪操作列表'
        |,aoi_area_res_json  	string	comment ''
        |)
        |PARTITIONED BY (`inc_day` string) row format delimited fields terminated by '\t'  stored as Parquet;
      """.stripMargin
    logger.error(createSql)
    spark.sql(createSql)
    logger.error("完成")
  }

//获取数据
  def getDataDf(spark: SparkSession ,incDay: String,startDay2:String) = {

    val resSql =
      s"""
        |select
        |*
        |from
        |dm_gis.xiaoge_trajectory_monitor_2_tmp1
        |where '2022-01-24'<= inc_day and inc_day < '2022-04-28'
        |--where '${incDay}'<= inc_day and inc_day < '${startDay2}'
      """.stripMargin

    logger.error(resSql)
    val resDf = spark.sql(resSql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取的数量"+resDf.count())
    resDf.createOrReplaceTempView("resTable")

    val sql =
      """
        |select inc_day
        |from resTable
        |group by inc_day
      """.stripMargin
    logger.error("获取到分区数"+spark.sql(sql).count())

    resDf.show(3,false)
    resDf
  }

}
