package com.sf.gis.scala.debang.suYun

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util. MD5Util
import com.sf.gis.scala.base.constants.CommonUrl
import com.sf.gis.scala.base.net_module.{HttpCommonAccess, IHttpCommonPost}
import com.sf.gis.scala.base.spark.{SparkNetBase, SparkWrite}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.debang.util._
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.util


import scala.collection.JavaConversions._
/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object SuyunMasterAndApprentice {
  @transient lazy val logger: Logger = Logger.getLogger(SuyunMasterAndApprentice.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200



  case class result(
                     apprentice_code:String
                     ,master_emp:String
                     ,success_time:String
                     ,train_date:String
                     ,aoi_id:String
                     ,aoi_code:String
                     ,start_time:String
                     ,end_time:String
                     ,all_start_time:String
                     ,all_end_time:String
                     ,sta_tm:String
                     ,end_tm:String
                     ,dis_tm:String
                     ,tm_list:String

  )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)

    logger.error("起始时间:" + startDay)
    start(startDay)
    logger.error("结束所有运行")

  }

  //  $[time(yyyyMM)]
  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取小哥跟师傅表数据")
    //取数据源
    val (sourRdd,"sourTable")= getDataDf(spark, incDay)
    logger.error("获取轨迹数据")
    val (traJectoryRdd,xyGroupRdd)= getTrajectoryDf(spark,"sourTable", incDay)
    logger.error("开始跑坐标")
    val pickAoiRdd = runPickAoi(spark,xyGroupRdd,incDay)
    logger.error(s"开始关联回轨迹纠偏")
    val joinAoiRdd= joinAoiTrack(spark,traJectoryRdd,pickAoiRdd)
    logger.error(s"取纠偏最早跟最晚时间,关联原始数据")
   val reRdd=  joinSoure(joinAoiRdd,sourRdd).map(_._2)
    logger.error("指标计算并入库")
    //入库
    saveTable(spark, reRdd, incDay)
    logger.error("解析表入库完毕")
  }


  def joinSoure(joinAoiRdd:RDD[(Boolean, JSONObject)] ,sourRdd:RDD[JSONObject]) ={

    val aoitmRdd =  joinAoiRdd.filter(_._1).map(o=>{
      val json = o._2
      ((JSONUtil.getJsonVal(json ,"un",""),
        JSONUtil.getJsonVal(json ,"aoiId","aoiId"),
        JSONUtil.getJsonVal(json,"all_start_time",""),
        JSONUtil.getJsonVal(json,"all_end_time","")),json)
    }).groupByKey().map(o=>{
      val un = o._1
      val list = o._2.toList.sortBy(o=>JSONUtil.getJsonVal(o,"tm","").toLong)
      val (dis,timeList)= getLessList(list)
      val sta_tm = JSONUtil.getJsonVal(list.head,"tm","").toLong
      (un,(sta_tm,dis,list.mkString(";"),timeList.mkString(";")))
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("聚合算完时间的数据量"+aoitmRdd.count())
    aoitmRdd.take(2).foreach(o=>logger.error("聚合时间后的数据："+o))
    val reRdd: RDD[(Boolean, JSONObject)] = sourRdd.map(o=>((JSONUtil.getJsonVal(o,"apprentice_code",""),JSONUtil.getJsonVal(o,"aoi_code",""),JSONUtil.getJsonVal(o,"all_start_time",""),JSONUtil.getJsonVal(o,"all_end_time","")),o)).leftOuterJoin(aoitmRdd).map(o=>{
      val left  = o._2._1
      val right: Option[(Long,Long, String, String)] = o._2._2
      var tag = false
      if(right.nonEmpty){
        val (sta_tm,dis_tm, list,timeList) = right.get
        left.put("un_sta_tm",sta_tm+"")
        left.put("un_tm_list_object",list)
        left.put("un_tm_list",timeList)
        left.put("dis_tm",dis_tm)
       tag = true
      }
      (tag,left)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联轨迹时间的数据量"+reRdd.count())
    reRdd.take(2).foreach(o=>logger.error(o._2.toJSONString))
    val noJoinRdd = reRdd.filter(!_._1).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)
    val joinRdd = reRdd.filter(_._1).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联不到aoi的数据量"+noJoinRdd.count())
    noJoinRdd.take(2).foreach(o=>logger.error("关联不到aoi的数据"+o))
    logger.error("关联到aoi的数据量"+joinRdd.count())
    joinRdd.take(2).foreach(o=>logger.error("关联到aoi的数据"+o))
//    logger.error("取师傅的时间排序")
//   val allRdd =  joinRdd.map(o=>((JSONUtil.getJsonVal(o,"master_emp",""),JSONUtil.getJsonVal(o,"aoi_code",""),JSONUtil.getJsonVal(o,"all_start_time",""),JSONUtil.getJsonVal(o,"all_end_time","")),o)).leftOuterJoin(aoitmRdd)
//      .map(o=>{
//        val left  = o._2._1
//        val right: Option[(Long, String, String)] = o._2._2
//        var tag = false
//        if(right.nonEmpty){
//          val (sta_tm, list,timeList) = right.get
//          left.put("ma_sta_tm",sta_tm+"")
//          left.put("ma_tm_list_object",list)
//          left.put("ma_tm_list",timeList)
//          tag = true
//        }
//        (tag,left)
//      }).persist(StorageLevel.MEMORY_AND_DISK)

//    allRdd.take(2).foreach(o=>logger.error(o._2.toJSONString))
//    val mnJoinRdd = allRdd.filter(!_._1).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)
//    val mJoinRdd = allRdd.filter(_._1).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)
//    logger.error("师傅关联不到aoi的数据量"+mnJoinRdd.count())
//    mnJoinRdd.take(2).foreach(o=>logger.error("师傅关联不到aoi的数据"+o))
//    logger.error("师傅关联到aoi的数据量"+mJoinRdd.count())
//    mJoinRdd.take(2).foreach(o=>logger.error("师傅关联到aoi的数据"+o))
//
//logger.error("计算停留时长")
//    val disTimeRdd = mJoinRdd.map(o=>{
//
//      var end_tm = 0L
//      var dis_tm = 0L
//      //师傅时间序列
//      val ma_tm_list = JSONUtil.getJsonVal(o,"ma_tm_list","").split(";").toList.map(o=>{
//        val tm = try{o.toLong}catch {case exception: Exception=>0L}
//        tm
//      })
//      //徒弟时间序列
//      val un_tm_list= JSONUtil.getJsonVal(o,"un_tm_list","").split(";").toList.toList.map(o=>{
//        val tm = try{o.toLong}catch {case exception: Exception=>0L}
//        tm
//      })
//      //取徒弟最早时间，跟师傅徒弟相差一个半钟内的最晚时间
//      val un_sta_tm = try{JSONUtil.getJsonVal(o,"un_sta_tm","").toLong}catch {case exception: Exception=>0L}
//
//      val size = if(ma_tm_list.size>=un_tm_list.size)  un_tm_list.size else ma_tm_list.size
//      val ma_tm_list_tmp = ma_tm_list.reverse
//      val un_tm_list_tmp = un_tm_list.reverse
//      for (i<- 0 until size){
////        println(s"${ma_tm_list_tmp(i)}____${un_tm_list_tmp(i)}_____${Math.abs(ma_tm_list_tmp(i) - un_tm_list_tmp(i))}____${end_tm}")
//        if(end_tm == 0L && Math.abs(ma_tm_list_tmp(i) - un_tm_list_tmp(i)) <=5400 ) {
//          end_tm = un_tm_list_tmp(i)
//        }
//      }
//      dis_tm=end_tm - un_sta_tm
//      o.put("final_end_tm",end_tm+"")
//      o.put("dis_tm",dis_tm+"")
//      o
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//    logger.error("计算完aoi的数据量"+disTimeRdd.count())
//    disTimeRdd.take(2).foreach(o=>logger.error("计算完aoi的数据"+o))
//    val finalRdd = disTimeRdd.union(mnJoinRdd).union(noJoinRdd).repartition(100)
    logger.error("最终数据量"+reRdd.count())

    aoitmRdd.unpersist()
    noJoinRdd.unpersist()
    joinRdd.unpersist()
    reRdd
  }


  def runPickAoi(spark: SparkSession, xyRdd: RDD[JSONObject], incDay: String) = {




    var trackRetRdd:RDD[JSONObject] = null
    logger.error("获取接口缓存结果")
    val cacheRdd = queryRuleCacheData(spark,incDay)

    if(cacheRdd.count()!=0) {
      logger.error("缓存数量不为空，直接用缓存数据")
      trackRetRdd = cacheRdd
      }else {
      logger.error("缓存数量为空，跑接口的量："+xyRdd.count())
     var patitionNum = 1000
     trackRetRdd = queryBactchXyToAoiSuYun(spark, xyRdd, null, patitionNum, 1000000, "xyList", false, 5000 * 60)
    val aoiXyCnt = trackRetRdd.map(obj => {
      JSONUtil.getJsonArrayFromObject(obj, "xyAoiRetList").size()
    }).sum()
    logger.error(s"返回值里面的点数据量：" + aoiXyCnt)
    logger.error(s"存储到坐标AOI缓存表")
    SparkWrite.save2HiveStaticSingleColumn(spark, trackRetRdd, "dm_gis.suyun_track_ret_xy_aoi_cache_fix", Array(("inc_day", incDay)), 100, SaveMode.Overwrite, 7000)
    }
    logger.error("跑完接口的数据量"+trackRetRdd.count())
    trackRetRdd
  }



  def queryRuleCacheData(spark:SparkSession,incDay:String) ={
    val sql =
      s"""
        |select data
        |from dm_gis.suyun_track_ret_xy_aoi_cache_fix
        |where inc_day = ${incDay}
      """.stripMargin
    val cacheRdd = SparkUtils.getRowToJson(spark,sql).map(o=>{
      val json = try{JSON.parseObject(JSONUtil.getJsonVal(o,"data",""))}catch {case exception: Exception =>new JSONObject()}
      json
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取到缓存的数据量"+cacheRdd.count())
    cacheRdd.take(2).foreach(o=>logger.error(o.toJSONString))
    cacheRdd
  }


  def joinAoiTrack(spark: SparkSession, fixTrajJoin: RDD[JSONObject],
                   pickAoiRdd: RDD[JSONObject]) = {



    val pickAoiFlatRdd = pickAoiRdd.repartition(1000).flatMap(obj => {
      val trackRetList = JSONUtil.getJsonArrayFromObject(obj, "xyAoiRetList")

      val xyAoiRetArray = new java.util.ArrayList[(String, JSONObject)]()
      for (i <- 0 until trackRetList.size()) {
        val xyAoiRetItem = trackRetList.getJSONObject(i)
        val cooorItem = try{xyAoiRetItem.getJSONArray("coors").getJSONObject(0)} catch {case exception: Exception => new JSONObject()}
       val lng = try{cooorItem.getDouble("lng")} catch {case exception: Exception =>0.0}
       val lat = try{cooorItem.getDouble("lat")} catch {case exception: Exception =>0.0}
        xyAoiRetArray.add((lng + "_" + lat, xyAoiRetItem))
      }
      xyAoiRetArray.iterator()
    }).reduceByKey((o1, o2) => o1).persist(StorageLevel.MEMORY_ONLY_SER_2)

    logger.error(s"点的数据量:" + pickAoiFlatRdd.count())
    import spark.implicits._
    val retRdd = fixTrajJoin.map(obj => {
      (JSONUtil.getJsonVal(obj,"zx","") + "_" + JSONUtil.getJsonVal(obj,"zy",""), obj)
    }).leftOuterJoin(pickAoiFlatRdd).map(obj => {
      val left = obj._2._1
      var aoiId = ""
      var aoiCode = ""
      var aoiName = ""
      val rightOp = obj._2._2
      var tag = false
      if (rightOp.nonEmpty) {
        val right = rightOp.get
        aoiId =JSONUtil.getJsonValSingle(right, "aoiId")
        aoiCode=JSONUtil.getJsonValSingle(right, "aoiCode")
        aoiName = JSONUtil.getJsonValSingle(right, "aoiName")
        left.put("aoiId",aoiId)
        left.put("aoiCode",aoiId)
        left.put("aoiName",aoiId)
       if(aoiId.nonEmpty) tag = true
      }
      (tag,left)
    }).persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error(s"关联坐标后的数量：" + retRdd.count())
    retRdd.take(10).foreach(o=>logger.error(o._2.toJSONString()))


    logger.error(s"54_aoi_id为空的数据量：" + retRdd.filter(!_._1).count())
    logger.error(s"54_aoi_id不为空的数据量：" + retRdd.filter(_._1).count())
    //    Spark.clearPersistWithoutId(spark, retRdd.rdd.id)
    retRdd
  }



def getLessList(list: Seq[JSONObject]) ={
  val timeList = new util.ArrayList[String]()
  var dis = 0L
  if(list.size>1){
    for(i <- 1 until list.size){
      val o = list(i)
      val o2 = list(i-1)
      val tm = try{JSONUtil.getJsonVal(o,"tm","").toLong}catch {case  exception: Exception => 0L}
      val tm2 = try{JSONUtil.getJsonVal(o2,"tm","").toLong}catch {case  exception: Exception => 0L}
      val dist = tm - tm2
      if(dist<=5400)  {
        dis = dis+dist
        timeList.add(s"${tm2}_${tm}_${dist}")
      }
    }
  }

//  for(i <- list){
//    val tm = try{JSONUtil.getJsonVal(i,"tm","").toLong}catch {case  exception: Exception => 0L}
//    if (timeList.length < 1) {
//      timeList.add(tm)
//    } else {
//      val dist = tm - timeList(timeList.length - 1)
//      if(dist<=5400) {
//        dis = dis+dist
//        timeList.add(tm)
//      }
////      if (tm <= 5400 + timeList(timeList.length - 1)) {
////      }
//    }
////    last = i
//  }
  (dis,timeList)
}


  def bactchXyToAoi(ak: String, obj: JSONObject, keyMap: Map[String, String], httpTimeout: Int): JSONObject = {
    HttpCommonAccess.doPost(obj, keyMap, CommonUrl.suyunbatchXyToAoi, httpTimeout, Thread.currentThread.getStackTrace()(1).getMethodName, new IHttpCommonPost() {
      /**
        * 获取网址需要的参数在数据体中的名称数组
        * @return
        */
      override def urlNeedKey(): Array[String] = {
        Array("xyList")
      }

      /**
        * 检测参数是否合理，不合理则直接返回带错误参数异常的结果
        * 正确返回true,错误返回false
        *
        * @param parmMap 参数值映射
        * @return
        */
      override def checkParm(parmMap: util.Map[String, String]): Boolean = {
        !StringUtils.isBlank(parmMap.get("xyList"))
      }

      /**
        * 拼接传入数据体
        *
        * @param parmMap 参数值映射
        * @return
        */
      override def createFinalBody(parmMap: util.Map[String, String]): String = {
        parmMap.get("xyList")
      }
    })
    return obj
  }


  //入库
  def saveTable(spark: SparkSession, saveRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._

    val tableName = "dm_gis.suyun_shunt_detail"
    val saveTableName = "dm_gis.suyun_master_apprentice_shunt_detail"
    val totalTableName = "dm_gis.suyun_master_apprentice_shunt_di"
    //明细表入库
    val rowDf = saveRdd.map(_.toJSONString.replaceAll("[\r\n\t]+", "")).toDF()

    logger.error(s"入明细表数量：${tableName}" + rowDf.count())


    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

    val reDf = saveRdd.map(o => {
      result(
        JSONUtil.getJsonVal(o, "apprentice_code", ""),
        JSONUtil.getJsonVal(o, "master_emp", ""),
        JSONUtil.getJsonVal(o, "success_time", ""),
        JSONUtil.getJsonVal(o, "train_date", ""),
        JSONUtil.getJsonVal(o, "aoi_id", ""),
        JSONUtil.getJsonVal(o, "aoi_code", ""),
        JSONUtil.getJsonVal(o, "start_time", ""),
        JSONUtil.getJsonVal(o, "end_time", ""),
        JSONUtil.getJsonVal(o, "all_start_time", ""),
        JSONUtil.getJsonVal(o, "all_end_time", ""),
        JSONUtil.getJsonVal(o, "un_sta_tm", ""),
        JSONUtil.getJsonVal(o, "final_end_tm", ""),
        JSONUtil.getJsonVal(o, "dis_tm", ""),
        JSONUtil.getJsonVal(o, "un_tm_list", "")
      )
    }).toDF()
    logger.error("开始入库")
    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

    reDf.createOrReplaceTempView("alltable")
    logger.error("算总aoi的停留时间")





    val totalsql =
      """
        |select
        | apprentice_code
        |,master_emp
        |,success_time
        |,train_date
        |,aoi_id
        |,aoi_code
        |,sum(dis_tm) as dis_tm
        |from alltable
        |group by
        |apprentice_code
        |,master_emp
        |,success_time
        |,train_date
        |,aoi_id
        |,aoi_code

      """.stripMargin
   logger.error(totalsql)
    val totalDf = spark.sql(totalsql)
    logger.error("最终表数据量"+totalDf.count())
    totalDf.show(2,false)
    totalDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(totalTableName)

  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      s"""
         |select
         |a.apprentice_code
         |,a.master_emp
         |,a.success_time
         |,a.train_date
         |,b.aoi_id
         |,b.start_time
         |,b.end_time
         |,c.aoi_id as aoi_code
         |--,concat(substr(a.success_time,1,10),substr(from_unixtime(cast(start_time as bigint),'yyyy-MM-dd HH:mm:ss'),11)) as all_start_time
         |,from_unixtime(cast(start_time as bigint),'yyyy-MM-dd HH:mm:ss') as all_start_time
         |,if(a.train_date is null or a.train_date = '',from_unixtime(cast(end_time as bigint),'yyyy-MM-dd HH:mm:ss'),concat(substr(a.train_date,1,10),substr(from_unixtime(cast(end_time as bigint),'yyyy-MM-dd HH:mm:ss'),11))) as all_end_time
         |from dm_cps.dzb_tt_master_apprentice_monitor a
         |left join(
         |--select
         |--loginid
         |--,start_time
         |--,end_time
         |--,concat_ws(',',collect_set(aoi_id)) as aoi_id
         |-- from
         |--dm_tc_waybillinfo.schedule_width_data b
         |--where inc_day = '${incDay}'
         |--group by loginid
         |--,start_time
         |--,end_time
         |select
         |loginid
         |,start_time
         |,end_time
         |,aoi_id
         | from
         |dm_tc_waybillinfo.schedule_width_data b
         |where inc_day = '${incDay}'
         |)b
         |on a.master_emp = b.loginid
         |--取对应的aoicode
         |left join(
         |select
         |aoi_id
         |,aoi_code
         |from dm_gis.cms_aoi_sch
         |group by aoi_id
         |,aoi_code
         |)c
         |on b.aoi_id = c.aoi_code
         |where inc_day = '${incDay}'
      """.stripMargin

    logger.error(totalDfSql)


    val sourDf = spark.sql(totalDfSql).persist(StorageLevel.DISK_ONLY)

    val colList = sourDf.columns
    val sourRdd = sourDf.rdd.repartition(800).map( obj => {
      val jsonObj = new JSONObject()
      for (columns <- colList) {
        jsonObj.put(columns,obj.getAs[String](columns))
      }
      jsonObj
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共获取数据:${sourRdd.count()}")
    sourDf.createOrReplaceTempView("sourTable")
    logger.error(sourRdd.take(10).foreach(println(_)))

    (sourRdd,"sourTable")
  }


  //获取数据
  def getTrajectoryDf(spark: SparkSession,sourTable:String, incDay: String) = {

    val sq =
      s"""
        |--徒弟轨迹
        |select
        |apprentice_code
        |,all_start_time
        |,all_end_time
        |from ${sourTable} b
        |group by
        |apprentice_code
        |,all_start_time
        |,all_end_time
        |--师傅轨迹
        |union all
        |select
        |master_emp  as apprentice_code
        |,all_start_time
        |,all_end_time
        |from ${sourTable} b
        |group by
        |master_emp
        |,all_start_time
        |,all_end_time
      """.stripMargin
    logger.error("师徒表数据去重"+sq)
    val stDf = spark.sql(sq).repartition(800).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("去重后的数据量"+stDf.count())
    stDf.createOrReplaceTempView("stTable")


    //获取数据源
    val totalDfSql =
      s"""
        |select
        |un
        |,tm
        |,zx
        |,zy
        |,b.all_start_time
        |,b.all_end_time
        |from dm_gis.esg_gis_loc_trajectory a
        |left join stTable b
        |on a.un = b.apprentice_code
        |where inc_day = '${incDay}'
        |and unix_timestamp(b.all_end_time) >= tm
        |and tm >= unix_timestamp(b.all_start_time)
      """.stripMargin
    logger.error(totalDfSql)
    val totalRdd = SparkUtils.getRowToJson(spark, totalDfSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("轨迹表的数据量：===》"+totalRdd.count())
    logger.error(totalRdd.take(10).foreach(println(_)))

    val xyGroupRdd = totalRdd.map(o => {
      val x = JSONUtil.getJsonVal(o,"zx","")
      val y = JSONUtil.getJsonVal(o,"zy","")
      (x + "_" + y, (x, y))
    }).reduceByKey((obj1, obj2) => {
      obj1
    }).map(obj => {
      ((MD5Util.getMD5(obj._1) + scala.util.Random.nextInt()).hashCode % 1000000, obj._2)
    }).groupByKey().map(obj => {
      val iter = obj._2.iterator
      val trackObj = new JSONObject()
      val trackArr = new JSONArray()
      while (iter.hasNext) {
        val item = iter.next()
        val json = new JSONObject()
        json.put("lng", item._1)
        json.put("lat", item._2)
        trackArr.add(json)
      }
      trackObj.put("xyList", trackArr)
      trackObj
    }).persist(StorageLevel.MEMORY_ONLY_SER_2)
    logger.error(s"坐标聚合后数量:" + xyGroupRdd.count())

    val aoiXyCnt = xyGroupRdd.map(obj => {
      JSONUtil.getJsonArrayFromObject(obj, "xyList").size()
    }).sum()
    logger.error(s"请求值里面的点数据量：" + aoiXyCnt)
    stDf.unpersist()
    (totalRdd,xyGroupRdd)
  }


  def queryBactchXyToAoiSuYun(sparkSession: SparkSession, jObject: RDD[JSONObject], ak: String, parallelism: Int, minuLimit: Int,
                         trackKey: String, saveTotal: Boolean = false, httpTimeOutMill: Int = 5000): RDD[JSONObject] = {

    val keyMap = Map("xyList" -> trackKey)
    val retRdd = SparkNetBase.runInterfaceWithAkLimitMultiThread(sparkSession, jObject,bactchXyToAoi, keyMap,
      parallelism, ak, minuLimit, httpTimeOutMill).map(obj => {
      obj.put("xyAoiRetList",JSONUtil.getJsonArrayMulti(obj,"bactchXyToAoi.data"))
      if (!saveTotal) {
        obj.remove("bactchXyToAoi")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("批量坐标获取aoi,整体数量为:" + retRdd.count());
    retRdd
  }
}
