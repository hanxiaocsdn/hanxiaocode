package com.sf.gis.scala.debang.DebangCuofen

import com.sf.gis.scala.debang.util.Util
import org.apache.log4j.Logger
import org.apache.spark.sql.{SaveMode, SparkSession}

object etl {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")



    logger.error("开始执行")

    //获取文件
    val beginDf = spark.read.option("inferschema", "true")
      .option("head", "false")
      .option("delimiter", "\t")
      .option("encoding", "UTF-8")
//      .csv("/user/01412406/upload/ys.csv")
      .csv("/user/01403862/upload/ys.csv")
      .toDF("citycode", "address", "aoiid", "zc")

    logger.error(s"获取文件数：${beginDf.count()}:"+beginDf.show(2))








    beginDf.createOrReplaceTempView("begintable")

    val reDf = spark.sql(
      """
        |select
        |citycode
        |,address
        |,aoiid
        |,zc
        |from
        |(
        |select
        | a.citycode
        |,a.address
        |,a.aoiid
        |,a.zc
        |from deppon_address_remove_conf_new a
        |left join
        |begintable b
        |on a.address = b.address
        |where b.address is null
        |union all
        |select
        | citycode
        |,address
        |,aoiid
        |,zc
        |from begintable b
        |)a
        |group by
        |citycode
        |,address
        |,aoiid
        |,zc
      """.stripMargin)

    logger.error(s"入标准库数量：${reDf.count()}")

    //入库
    reDf.write.mode(SaveMode.Overwrite).saveAsTable("tmp_dm_gis.tmp_res2")
//    spark.table("tmp_dm_gis.deppon_address_remove_conf_new").write.mode(SaveMode.Overwrite).insertInto("tmp_dm_gis.tmp_res3")
//    spark.table("tmp_dm_gis.tmp_res2").write.mode(SaveMode.Overwrite).insertInto("tmp_dm_gis.deppon_address_remove_conf_new2")
    spark.table("tmp_dm_gis.tmp_res2").write.mode(SaveMode.Overwrite).insertInto("deppon_address_remove_conf_new")
    logger.error("压数完成")

  }
}
