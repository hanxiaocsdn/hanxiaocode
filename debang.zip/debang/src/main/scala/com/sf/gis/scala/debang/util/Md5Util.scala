package com.sf.gis.scala.debang.util

import java.security.MessageDigest

object Md5Util {

  def MD5Encode(input: String): String = {
    // 指定MD5加密算法
    val md5 = MessageDigest.getInstance("MD5")
    //进行随机哈希
    val encoded = md5.digest(input.getBytes)
    //转十六进制
    encoded.map("%02x".format(_)).mkString
  }

}
