package com.sf.gis.scala.debang.DebangCuofen

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.MD5Util
import com.sf.gis.java.sx.constant.util.JavaUtil
import com.sf.gis.scala.base.spark.{Spark, SparkWrite}
import com.sf.gis.scala.base.util.DateUtil
import com.sf.gis.scala.debang.pojo.Obj.{DebangReqObj, KyObj}
import com.sf.gis.scala.debang.util.{CityInfoUtils, DbUtils}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01374443 on 2019/3/5.
 * 任务id:156
 * 任务名称：德邦指标统计
 */
object DebangStaIndex {
  @transient lazy val logger: Logger = Logger.getLogger(DebangStaIndex.getClass)

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val debangHiveTable = "dm_gis.debang_log_flink_collect"
  val debangStaResultTable = "debang_rcg"
  //下次打包请勿必去掉这个,太难看了,会出错的....
  val javaUtil = new JavaUtil(6)

  def main(args: Array[String]): Unit = {
    //    val log = "{\"syn\":false,\"createTime\":\"2020-08-28 08:06:20.225\",\"level\":\"HDFS\",\"message\":\"{\\\"request\\\":\\\"{\\\\\\\"createTime\\\\\\\":1598573180115,\\\\\\\"ak\\\\\\\":\\\\\\\"d5653f4efbb4450ba8589a300456b80e\\\\\\\",\\\\\\\"remoteIp\\\\\\\":\\\\\\\"180.153.16.2\\\\\\\",\\\\\\\"url\\\\\\\":\\\\\\\"http://nginxwa/eds/api/deppon?ak=d5653f4efbb4450ba8589a300456b80e&citycode=411500&address=%25E6%25B2%25B3%25E5%258D%2597%25E7%259C%2581%25E4%25BF%25A1%25E9%2598%25B3%25E5%25B8%2582%25E6%25B5%2589%25E6%25B2%25B3%25E5%258C%25BA%25E4%25BA%2594%25E9%2587%258C%25E5%25A2%25A9%25E8%25A1%2597%25E9%2581%2593%25E6%25B2%25B3%25E5%258D%2597%25E4%25BF%25A1%25E9%2598%25B3%25E5%25B8%2582%25E6%25B5%2589%25E6%25B2%25B3%25E5%258C%25BA%25E5%259F%258E%25E5%258C%25BA%25E5%2585%25AB%25E4%25B8%2580%25E8%25B7%25AF252%25E5%258F%25B789%25E6%25A0%258B&sn=8110620473\\\\\\\",\\\\\\\"address\\\\\\\":\\\\\\\"河南省信阳市浉河区五里墩街道河南信阳市浉河区城区八一路252号89栋\\\\\\\",\\\\\\\"citycode\\\\\\\":\\\\\\\"411500\\\\\\\",\\\\\\\"sn\\\\\\\":\\\\\\\"8110620473\\\\\\\",\\\\\\\"opt\\\\\\\":\\\\\\\"ZH\\\\\\\"}\\\",\\\"requestId\\\":\\\"0124972020082808062011520383_8110620473\\\",\\\"response\\\":\\\"{\\\\\\\"query\\\\\\\":{\\\\\\\"address\\\\\\\":\\\\\\\"河南省信阳市浉河区五里墩街道河南信阳市浉河区城区八一路252号89栋\\\\\\\",\\\\\\\"citycode\\\\\\\":\\\\\\\"411500\\\\\\\",\\\\\\\"sn\\\\\\\":\\\\\\\"8110620473\\\\\\\",\\\\\\\"opt\\\\\\\":\\\\\\\"ZH\\\\\\\"},\\\\\\\"data\\\\\\\":{\\\\\\\"source\\\\\\\":\\\\\\\"AUTO|KEYWORD\\\\\\\",\\\\\\\"code\\\\\\\":[{\\\\\\\"zc\\\\\\\":\\\\\\\"W0000028248\\\\\\\"}]},\\\\\\\"sn\\\\\\\":\\\\\\\"0124972020082808062011520383_8110620473\\\\\\\"}\\\",\\\"atResult\\\":\\\"{\\\\\\\"result\\\\\\\":\\\\\\\"[{\\\\\\\\\\\\\\\"zc\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"W0000028248\\\\\\\\\\\\\\\"}]\\\\\\\",\\\\\\\"success\\\\\\\":true}\\\",\\\"type\\\":\\\"3\\\",\\\"dataSrc\\\":\\\"AUTO|KEYWORD\\\"}\",\"index_time\":\"2020-08-28\",\"ip\":\"10.219.190.16\",\"appname\":\"gis-ass-eds-ms\",\"@version\":\"1\",\"@timestamp\":\"2020-08-28T00:06:20.227Z\"}"
    //    parseLog(log,null,"2020-08-28")
    val logDays: Int = -1
    var incDaySep: String = DateUtil.dateDelta(logDays, "-")
    var days = 1
    if (args.length == 2) {
      incDaySep = args(0)
      days = args(1).toInt
    }

    start(days, incDaySep)
  }

  def parseLogDebang(ret: JSONObject, message: JSONObject, adcodeCityCodeMap: Map[String, String], dataSrc: String): JSONObject = {
    ret.put("reqId", message.getString("requestId"))
    val request = message.getJSONObject("request")
    val reqAdcode = request.getString("citycode")
    ret.put("adcode", reqAdcode)
    if (reqAdcode != null && !reqAdcode.isEmpty
      && adcodeCityCodeMap != null
      && adcodeCityCodeMap.contains(reqAdcode)) {
      ret.put("reqCityCode", adcodeCityCodeMap.apply(reqAdcode))
    } else {
      ret.put("reqCityCode", "")
    }
    ret.put("addr", request.getString("address"))
    val response = message.getJSONObject("response")
    if (response != null && response.getJSONObject("data") != null
      && response.getJSONObject("data").getJSONArray("code") != null
    ) {
      val codeArray = response.getJSONObject("data").getJSONArray("code")
      if (codeArray.size() > 0) {
        val codeItem = codeArray.getJSONObject(0)
        if (codeItem.getString("tc") != null) {
          ret.put("tc", codeItem.getString("tc"))
        }
        if (codeItem.getString("zc") != null) {
          ret.put("zc", codeItem.getString("zc"))
        }
      }
    }
    //    if(dataSrc!=null && dataSrc.startsWith("AUTO|")){
    //      return ret
    //    }
    val atResult = message.getJSONObject("atResult")
    if (atResult != null && atResult.getJSONObject("result") != null
      && atResult.getJSONObject("result").getJSONArray("tcs") != null
    ) {
      val tcsArray = atResult.getJSONObject("result").getJSONArray("tcs")
      if (tcsArray.size() > 0) {
        val tcsItem = tcsArray.getJSONObject(0)
        if (tcsItem.getString("aoicode") != null) {
          ret.put("aoicode", tcsItem.getString("aoicode"))
        }
      }
    }
    ret
  }

  def parseLogKuaiYun(ret: JSONObject, message: JSONObject) = {
    ret.put("reqId", message.getString("requestId"))
    val request = message.getJSONObject("request")
    ret.put("cityCode", request.getString("cityCode"))
    val response = message.getJSONObject("response")
    if (response != null) {
      val teamCode = response.getString("teamCode")
      ret.put("tc", teamCode)
      ret.put("address", response.getString("address"))
    }

  }

  def parseLog(log: String, adcodeCityCodeMap: Map[String, String], incDaySep: String): JSONObject = {
    val jObj = JSON.parseObject(log)
    val createTime = jObj.getString("createTime")
    if (createTime == null || !createTime.contains(incDaySep)) {
      logger.error("日期不对")
      return null
    }

    val ret = new JSONObject()
    ret.put("createTime", createTime)
    val message = jObj.getJSONObject("message")
    val dataType = message.getString("type")
    if ("3".equals(dataType)) {
      ret.put("dataType", "3")
      ret.put("dataSrc", message.getString("dataSrc"))
      parseLogDebang(ret, message, adcodeCityCodeMap, message.getString("dataSrc"))
    } else if ("1".equals(dataType)) {
      ret.put("dataType", "1")
      parseLogKuaiYun(ret, message)
    } else {
      return null
    }
    //    println(ret.toJSONString)
    ret
  }

  def getKafakRdd(spark: SparkSession, beginDate: String, endDate: String, adcodeCityCodeMapBc: Broadcast[Map[String, String]], incDaySep: String): (RDD[(String, JSONObject)], RDD[(String, JSONObject)]) = {
    val sql =
      s"""select log from $debangHiveTable where inc_day between '$beginDate' and '$endDate'
         |
       """.stripMargin
    logger.error(sql)
    spark.sql(sql).rdd.take(100).map(obj=>{
      parseLog(obj.getString(0), adcodeCityCodeMapBc.value, incDaySep)
    })
    val dataRdd = spark.sql(sql).rdd.map(obj => {
      var reqId: String = null
      var jObj: JSONObject = null
      try {
        jObj = parseLog(obj.getString(0), adcodeCityCodeMapBc.value, incDaySep)
        if (jObj != null) {
          reqId = jObj.getString("reqId")
        }
      } catch {
        case e: Exception => logger.error(e)
      }
      (reqId, jObj)
    }).filter(obj => obj._1 != null).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("总数据量:" + dataRdd.count())
    val debangRdd = dataRdd.filter(obj => "3".equals(obj._2.getString("dataType")))
      .reduceByKey((obj1, obj2) => {
        if (obj1.getString("createTime") <= obj2.getString("createTime")) {
          obj2
        } else {
          obj1
        }
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("德邦数据量:" + debangRdd.count())
    val kyRdd = dataRdd.filter(obj => "1".equals(obj._2.getString("dataType")))
      .reduceByKey((obj1, obj2) => {
        if (obj1.getString("createTime") <= obj2.getString("createTime")) {
          obj2
        } else {
          obj1
        }
      }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("快运数据量:" + kyRdd.count())
    dataRdd.unpersist()
    (debangRdd, kyRdd)
  }

  def mergeDebang(obj1: DebangReqObj, obj2: DebangReqObj): DebangReqObj = {
    val region = obj1.region
    val city = obj1.city
    val cityCode = obj1.cityCode
    val adcode = obj1.adcode
    val reqCnt = obj1.reqCnt + obj2.reqCnt
    val aoiCnt = obj1.aoiCnt + obj2.aoiCnt
    val zcCnt = obj1.zcCnt + obj2.zcCnt
    val tcCnt = obj1.tcCnt + obj2.tcCnt

    val aoiRdsCnt = obj1.aoiRdsCnt + obj2.aoiRdsCnt
    val zcRdsCnt = obj1.zcRdsCnt + obj2.zcRdsCnt
    val tcRdsCnt = obj1.tcRdsCnt + obj2.tcRdsCnt

    val aoiChknCnt = obj1.aoiChknCnt + obj2.aoiChknCnt
    val zcChknCnt = obj1.zcChknCnt + obj2.zcChknCnt
    val tcChknCnt = obj1.tcChknCnt + obj2.tcChknCnt

    DebangReqObj(region, city, cityCode, adcode, reqCnt, aoiCnt, zcCnt, tcCnt,
      aoiRdsCnt, zcRdsCnt, tcRdsCnt, aoiChknCnt, zcChknCnt, tcChknCnt)
  }

  def mergeKy(obj1: KyObj, obj2: KyObj): KyObj = {
    val region = obj1.region
    val city = obj1.city
    val cityCode = obj1.cityCode
    val reqCnt = obj1.reqCnt + obj2.reqCnt
    val tcCnt = obj1.tcCnt + obj2.tcCnt
    KyObj(region, city, cityCode, reqCnt, tcCnt)
  }

  def statDebangIndex(kafkaRdd: RDD[(String, JSONObject)]): RDD[DebangReqObj] = {
    val cityMap: Map[String, ArrayBuffer[Array[String]]] = CityInfoUtils.getCityMap(javaUtil)
    val retRdd = kafkaRdd.map(obj => {
      val jObj = obj._2
      val reqCnt = 1
      var aoiCnt = 0
      var isRds = 0
      var isChkn = 0
      val dataSrc = jObj.getString("dataSrc")
      //    if (validRcCnt == 1) {
      if ("RDS".equals(dataSrc)) {
        isRds = 1
      } else {
        isChkn = 1
      }
      if (jObj.getString("aoicode") != null && !jObj.getString("aoicode").isEmpty) {
        aoiCnt = 1
      }
      var zcCnt = 0
      if (jObj.getString("zc") != null && !jObj.getString("zc").isEmpty) {
        zcCnt = 1
      }
      var tcCnt = 0
      if (jObj.getString("tc") != null && !jObj.getString("tc").isEmpty) {
        tcCnt = 1
      }
      val isValidCity = CityInfoUtils.matchCityCode(jObj, jObj.getString("addr"), jObj.getString("reqCityCode"), cityMap)
      if (isValidCity) {
        (Array(jObj.getString("region"), jObj.getString("city"), jObj.getString("cityCode")).mkString("_"), DebangReqObj(jObj.getString("region"), jObj.getString("city"), jObj.getString("cityCode"), jObj.getString("adcode"),
          reqCnt, aoiCnt, zcCnt, tcCnt, aoiCnt & isRds, zcCnt & isRds, tcCnt & isRds, aoiCnt & isChkn, zcCnt & isChkn, tcCnt & isChkn))
      } else {
        (null, null)
      }
    }).filter(obj => obj._1 != null).reduceByKey((obj1, obj2) => {
      mergeDebang(obj1, obj2)
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("按adcode聚合后数量：" + retRdd.count())
    kafkaRdd.unpersist()
    retRdd
  }

  def save(spark: SparkSession, indexRdd: RDD[DebangReqObj], incDay: String): Unit = {
    val conn = DbUtils.getConnectionNew
    val md5Instance = MD5Util.getMD5Instance
    val DEBANG_RCG = "DEBANG_RCG"
    try {
      val delDebangSql = String.format(s"delete from $DEBANG_RCG where stat_date='%s'", incDay)
      logger.error(">>>保存之前，删除德邦一天的数据:" + delDebangSql)
      DbUtils.executeSql(conn, delDebangSql)

      val insertSql = s"insert into $DEBANG_RCG (`id`, `stat_date`, `region`, `city`, `city_code`,`adcode`," +
        s" `req`,`aoi`,`zc`,`tc`,`aoi_rds`,`zc_rds`,`tc_rds`,`aoi_chkn`,`zc_chkn`,`tc_chkn`) " +
        s" values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
      var insertParams: Array[Any] = null
      indexRdd.collect().foreach(o => {
        //计算md5值
        val id = MD5Util.getMD5(md5Instance, Array(incDay, o.region, o.city, o.cityCode).mkString("_"))
        insertParams = Array(id, incDay, o.region, o.city, o.cityCode, o.adcode, o.reqCnt,
          o.aoiCnt, o.zcCnt, o.tcCnt, o.aoiRdsCnt, o.zcRdsCnt, o.tcRdsCnt, o.aoiChknCnt, o.zcChknCnt, o.tcChknCnt)
        DbUtils.execute(conn, insertSql, insertParams)
      })
      logger.error(">>>debang指标入库结束！")
    } catch {
      case e: Exception => logger.error(">>>debang指标入库失败！" + e)
    }
  }


  def saveResult(spark: SparkSession, indexRdd: RDD[DebangReqObj], parDay_1: String) = {
    //目标库表名称
    val descDBName = "dm_gis"
    val descTableName = "debang_rcg"
    //插入目标表SQL
    val insertSQL =
      s"""
         |INSERT OVERWRITE TABLE $descDBName.$descTableName PARTITION (inc_day = '$parDay_1')
         |select
         |  row_number() over(order by rand()) as id
         |  ,'$parDay_1'
         |  ,region,city,city_code,adcode,req,aoi,zc,tc,aoi_rds,zc_rds,tc_rds,aoi_chkn,zc_chkn,tc_chkn
         |from tmp
         |""".stripMargin
    val schemaString = "region,city,city_code,adcode,req,aoi,zc,tc,aoi_rds,zc_rds,tc_rds,aoi_chkn,zc_chkn,tc_chkn"
    val fields = schemaString.split(",").map(fieldsName => StructField(fieldsName, StringType, nullable = true))
    val schema = StructType(fields)
    val rdd = indexRdd.repartition(1).map(o => {
      val sb = new StringBuilder()
      sb.append(o.region).append("\t\t\t")
      sb.append(o.city).append("\t\t\t")
      sb.append(o.cityCode).append("\t\t\t")
      sb.append(o.adcode).append("\t\t\t")
      sb.append(o.reqCnt).append("\t\t\t")
      sb.append(o.aoiCnt).append("\t\t\t")
      sb.append(o.zcCnt).append("\t\t\t")
      sb.append(o.tcCnt).append("\t\t\t")
      sb.append(o.aoiRdsCnt).append("\t\t\t")
      sb.append(o.zcRdsCnt).append("\t\t\t")
      sb.append(o.tcRdsCnt).append("\t\t\t")
      sb.append(o.aoiChknCnt).append("\t\t\t")
      sb.append(o.zcChknCnt).append("\t\t\t")
      sb.append(o.tcChknCnt).append("\t\t\t")
      sb.toString()
    }).map(_.split("\t\t\t", -1)).map(attr => Row(attr(0), attr(1), attr(2), attr(3), attr(4)
      , attr(5), attr(6), attr(7), attr(8), attr(9), attr(10), attr(11), attr(12), attr(13)))
    val df = spark.createDataFrame(rdd, schema)
    df.printSchema()
    df.createOrReplaceTempView("tmp")
    df.show(5)
    logger.error(">>>>>>>>>>入hive库开始")
    logger.error(">>>>>>>>>>>>>>>>>>>>>>>>>>>插入hive: " + insertSQL)
    spark.sql(insertSQL)
    logger.error(">>>>>>>>>>入hive库结束")
  }

  def saveKy(spark: SparkSession, indexRdd: RDD[KyObj], incDay: String): Unit = {
    val conn = DbUtils.getConnectionNew
    val md5Instance = MD5Util.getMD5Instance
    val KY_RCG = "KY_RCG"
    try {
      val delDebangSql = String.format(s"delete from $KY_RCG where stat_date='%s'", incDay)
      logger.error(">>>保存之前，删除快运一天的数据:" + delDebangSql)
      DbUtils.executeSql(conn, delDebangSql)

      val insertSql = s"insert into $KY_RCG (`id`, `stat_date`, `region`, `city`, `city_code`," +
        s" `req`,`tc`) values(?, ?, ?, ?, ?, ?, ?)"
      var insertParams: Array[Any] = null
      indexRdd.collect().foreach(o => {
        //计算md5值
        val id = MD5Util.getMD5(md5Instance, Array(incDay, o.region, o.city, o.cityCode).mkString("_"))
        insertParams = Array(id, incDay, o.region, o.city, o.cityCode, o.reqCnt,
          o.tcCnt)
        DbUtils.execute(conn, insertSql, insertParams)
      })
      logger.error(">>>快运指标入库结束！")
    } catch {
      case e: Exception => logger.error(">>>快运指标入库失败！" + e)
    }
  }

  def statKyIndex(kyRdd: RDD[(String, JSONObject)]): RDD[KyObj] = {
    val cityMap: Map[String, ArrayBuffer[Array[String]]] = CityInfoUtils.getCityMap(javaUtil)
    val retRdd = kyRdd.map(obj => {
      val jObj = obj._2
      val reqCnt = 1
      var tcCnt = 0
      if (jObj.getString("tc") != null && !jObj.getString("tc").isEmpty) {
        tcCnt = 1
      }
      val isValidCity = CityInfoUtils.matchCityCode(jObj, jObj.getString("address"), jObj.getString("cityCode"), cityMap)
      if (isValidCity) {
        (Array(jObj.getString("region"), jObj.getString("city"), jObj.getString("cityCode")).mkString("_"),
          KyObj(jObj.getString("region"), jObj.getString("city"), jObj.getString("cityCode"),
            reqCnt, tcCnt))
      } else {
        (null, null)
      }

    }).filter(obj => obj._1 != null).reduceByKey((obj1, obj2) => {
      mergeKy(obj1, obj2)
    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER)
    retRdd.take(3).foreach(obj => {
      logger.error(obj)
    })
    logger.error("按城市聚合后数量：" + retRdd.count())
    kyRdd.unpersist()
    retRdd
  }

  def startSta(spark: SparkSession, incDay: String, endDay: String, incDaySep: String): Unit = {
    val adcodeCityCodeMap = CityInfoUtils.loadAdcodeCityCodemap()
    val adcodeCityCodeMapBc = spark.sparkContext.broadcast(adcodeCityCodeMap)

    logger.error("获取debang数据")
    val (debangRdd, kyRdd) = getKafakRdd(spark, incDay, endDay, adcodeCityCodeMapBc, incDaySep)
    logger.error("统计德邦指标数据")
    val debangIndexRdd = statDebangIndex(debangRdd)
    logger.error("统计快运指标数据")
    val kyIndexRdd = statKyIndex(kyRdd)
    logger.error("指标入库")
    //保存到hive表
    saveResult(spark,debangIndexRdd,incDay)
    save(spark, debangIndexRdd, incDay)
    saveKy(spark, kyIndexRdd, incDay)
  }


  def start(days: Int, beginDaySep: String): Unit = {
    val spark = Spark.getSparkSession(appName)
    for (i <- 0 until days) {
      val incDaySep = DateUtil.getDay(beginDaySep, i, "-")
      val incDay = incDaySep.replaceAll("-", "")
      val endDay: String = DateUtil.getDay(incDay, 1, "")
      logger.error("incDaySep:" + incDaySep)
      startSta(spark, incDay, endDay, incDaySep)
    }
    logger.error("the end~")
  }


}
