package com.sf.gis.scala.debang.DebangCuofen

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, StringNumUtils}
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil, JSONUtil, StringUtils}
import com.sf.gis.scala.debang.util.SparkUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.net.URLEncoder
import java.util.UUID


/*
* DB错分数据任务下发核实及入库需求 - 张锦
* 徐千皓
* 迁移新集群
* 任务id:152
* 任务名称：德邦错分下发
* */

object DebangCuofenIssue {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  //关闭fastjson引用检测
  JSON.DEFAULT_GENERATE_FEATURE |= SerializerFeature.DisableCircularReferenceDetect.getMask
  //精细化接口
  val assUrl = "http://gis-int.int.sfdc.com.cn:1080/iad/api?address=%s&citycode=%s&ak=3a191e7427e8470c86271a069411c66b&opt=detail"
  //CGCS错柯错分审补核接口
  val pushChknWrongAoiTaskUrl = "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushChknWrongAoiTask"
  //容灾opt=norm,atpai
  val normUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?opt=%s&ak=dec044d089524419b371bc94555c539d&city=%s&address=%s"
  //CGCS错柯错分标准核实接口
  val pushNormHisTaskUrl = "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushNormHisTask"

  val atpUrl = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&tel=&mobile=&company=&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh"
  val depponUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&opt=%s&show=1"
  val getAddrByCityCodeAndAddrUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressId=%s"

  val finalTable = "dm_gis.dm_debang_cuofen_issues_new_di"
  val detailName = "dm_gis.dm_debang_cuofen_issues_new_detail_di"

  val account = "01412406"
  val taskId = "152"
  val taskName = "德邦错分下发"
  val taskDesc = "德邦错分下发"


  case class Re(
                 sn: String
                 , address: String
                 , citycode: String
                 , city: String
                 , depponZc: String
                 , zc: String
                 , aoiid: String
                 , mapa_precision: String
                 , mapa_x: String
                 , mapa_y: String
                 , mapa_aoi_id: String
                 , mapa_aoi_name: String
                 , ts_precision: String
                 , ts_x: String
                 , ts_y: String
                 , ts_aoi_id: String
                 , ts_aoi_name: String
                 , dataSrc: String
                 , src: String
                 , adcode: String
                 , groupid: String
                 , standardization: String
                 , keyWord: String
                 , model_Zc: String
                 , ts_xy_Zc: String
                 , mapa_xy_Zc: String
                 , mapa_aoi_zc: String
                 , ts_aoi_zc: String
                 , deptcode: String
                 , aoiid_at: String
                 , groupid_at: String
                 , src_at: String
                 , aoicode_at: String
                 , keyword_at: String
                 , adcode_at: String
                 , is_aoi_modify: String
                 , zc_new: String
                 , tc_new: String
                 , keyword_new: String
                 , msg_new: String
                 , zc_modzc: String
                 , tc_modzc: String
                 , keyword_modzc: String
                 , msg_modzc: String
                 , is_zc_modify: String
                 , explicit: String
                 , originId: String
                 , except_addr: String
                 , tag: String
                 , adcode_cms: String
                 , cms_aoi_right: String
                 , aoi_code_at: String
                 , aoiname_at: String
                 , address_clear: String
                 , keyword_at_clear: String
                 , aoiname_at_clear: String
                 , aoi_concat: String
                 , push_aoi_task: String
               )

  val numPartiton = 16

  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)
    val incDay = args(0)
    val lastDay = args(1)

    run(spark, incDay, lastDay)
  }


  def run(spark: SparkSession, incDay: String, lastDay: String): Unit = {
    //获取德邦t-1错分数据
    val debangRdd = getDebangCuofenData(spark, incDay, lastDay)
    //调取at派获取识别aoiid
    val (zcFalseRdd, trueRdd) = getAtpResp(spark, debangRdd)
    //过滤Explict != 1和地址包含`德邦`、`营业`、`网点`以及`对面`结尾
    val unionRdd = filterAddr(spark, zcFalseRdd)
    unionRdd.take(2).foreach(println(_))
    //处理需要保存的数据
    val resRdd = trueRdd.union(unionRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    resRdd.take(2).foreach(println(_))
    logger.error(s"共入库:${resRdd.count()}")
    //入库
    saveTable(spark, resRdd, incDay)
    logger.error("完成")
  }

  def getAtpResp(spark: SparkSession, debangRdd: RDD[JSONObject]): (RDD[JSONObject], RDD[JSONObject]) = {
    val id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atpUrl, "3eb300d2e06947f7945cd02530a32fd2", debangRdd.count(), 2)
    val atpRdd = debangRdd.repartition(2).map(o => {
      val address = JSONUtil.getJsonVal(o, "address", "")
      val city = JSONUtil.getJsonVal(o, "city", "")
      val aoiid = JSONUtil.getJsonVal(o, "aoiid", "")
      var aoiid_at = ""
      if (StringUtils.nonEmpty(address)) {
        val req = String.format(atpUrl, URLEncoder.encode(address, "UTF-8"), city)
        val resp = HttpInvokeUtil.sendGet(req)

        val deptcode = try {
          JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("dept")
        } catch {
          case _ => ""
        }
        aoiid_at = try {
          JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid")
        } catch {
          case _ => ""
        }
        val groupid_at = try {
          JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("groupid")
        } catch {
          case _ => ""
        }
        val src_at = try {
          JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("src")
        } catch {
          case _ => ""
        }
        val aoicode_at = try {
          JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoicode")
        } catch {
          case _ => ""
        }
        val keyword_at = try {
          JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("keyWord")
        } catch {
          case _ => ""
        }
        val adcode_at = try {
          JSON.parseObject(resp).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("adcode")
        } catch {
          case _ => ""
        }

        o.put("deptcode", deptcode)
        o.put("aoiid_at", aoiid_at)
        o.put("groupid_at", groupid_at)
        o.put("src_at", src_at)
        o.put("aoicode_at", aoicode_at)
        o.put("keyword_at", keyword_at)
        o.put("adcode_at", adcode_at)
      }

      if (StringUtils.nonEmpty(aoiid_at) && StringUtils.nonEmpty(aoiid) && aoiid_at.equals(aoiid)) {
        o.put("is_aoi_modify", "false")
      } else {
        o.put("is_aoi_modify", "true")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("atpRdd cnt:" + atpRdd.count())
    debangRdd.unpersist()
    BdpTaskRecordUtil.endNetworkInterface(account, id1)

    val aoiFalseRdd = atpRdd.filter(o => "false".equals(o.getString("is_aoi_modify"))).persist(StorageLevel.MEMORY_AND_DISK)
    val aoiTrueRdd = atpRdd.filter(o => "true".equals(o.getString("is_aoi_modify"))).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("aoiFalseRdd cnt:" + aoiFalseRdd.count())
    logger.error("aoiTrueRdd cnt:" + aoiTrueRdd.count())
    atpRdd.unpersist()

    val id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", depponUrl, "3a191e7427e8470c86271a069411c66b", aoiFalseRdd.count() * 2, 2)
    val zcModifyRdd = aoiFalseRdd.repartition(2).map(o => {
      val address = JSONUtil.getJsonVal(o, "address", "")
      val citycode = JSONUtil.getJsonVal(o, "citycode", "")
      if (StringUtils.nonEmpty(address)) {
        //opt=rds 查一遍
        val (zc_new, tc_new, keyword_new, msg_new) = depponRev(citycode, address, "rds")
        o.put("zc_new", zc_new)
        o.put("tc_new", tc_new)
        o.put("keyword_new", keyword_new)
        o.put("msg_new", msg_new)
        //opt=zc 查一遍
        val (zc_modzc, tc_modzc, keyword_modzc, msg_modzc) = depponRev(citycode, address, "zc")
        o.put("zc_modzc", zc_modzc)
        o.put("tc_modzc", tc_modzc)
        o.put("keyword_modzc", keyword_modzc)
        o.put("msg_modzc", msg_modzc)
      }

      val zc_new = JSONUtil.getJsonVal(o, "zc_new", "")
      val depponZc = JSONUtil.getJsonVal(o, "depponZc", "")
      if (StringUtils.nonEmpty(zc_new) && zc_new.equals(depponZc)) {
        o.put("is_zc_modify", "true")
      } else {
        o.put("is_zc_modify", "false")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("zcModifyRdd cnt:" + zcModifyRdd.count())
    aoiFalseRdd.unpersist()
    BdpTaskRecordUtil.endNetworkInterface(account, id2)

    val zcTrueRdd = zcModifyRdd.filter(o => "true".equals(o.getString("is_zc_modify"))).persist(StorageLevel.MEMORY_AND_DISK)
    val zcFalseRdd = zcModifyRdd.filter(o => "false".equals(o.getString("is_zc_modify"))).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("zcTrueRdd cnt:" + zcTrueRdd.count())
    logger.error("zcFalseRdd cnt:" + zcFalseRdd.count())
    zcModifyRdd.unpersist()

    val trueRdd = aoiTrueRdd.union(zcTrueRdd).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("trueRdd cnt:" + trueRdd.count())
    aoiTrueRdd.unpersist()
    zcTrueRdd.unpersist()
    (zcFalseRdd, trueRdd)
  }

  def depponRev(citycode: String, address: String, opt: String): (String, String, String, String) = {
    val req = String.format(depponUrl, citycode, URLEncoder.encode(address, "UTF-8"), opt)
    val res = HttpInvokeUtil.sendGet(req)
    val zc = try {
      JSON.parseObject(res).getJSONObject("result").getJSONObject("data").getJSONArray("code").getJSONObject(0).getString("zc")
    } catch {
      case _ => ""
    }
    val tc = try {
      JSON.parseObject(res).getJSONObject("result").getJSONObject("data").getJSONArray("code").getJSONObject(0).getString("tc")
    } catch {
      case _ => ""
    }
    val keyword = try {
      JSON.parseObject(res).getJSONObject("result").getString("keyword")
    } catch {
      case _ => ""
    }
    val msg = try {
      JSON.parseObject(res).getJSONObject("result").getString("msg")
    } catch {
      case _ => ""
    }
    (zc, tc, keyword, msg)
  }


  def getFilterWeek(spark: SparkSession, incDay: String, sourRdd: RDD[JSONObject]) = {

    val beginDay = DateUtil.getDateStr(incDay, -7)

    val issuesSql =
      s"""
         |select
         |  address
         |from
         |  ${finalTable}
         |where
         |  inc_day BETWEEN '${beginDay}' and '${incDay}'
         |  and push_aoi_task = 'true'
         |
       """.stripMargin

    val sourRdd2 = sourRdd.map(x => {
      val address = x.getString("address")
      (address, x)
    })


    val issuesRdd = SparkUtils.getRowToJson(spark, issuesSql).map(x => {
      val address = x.getString("address")
      (address, x)
    }).reduceByKey((o1, o2) => o1)

    val filterRdd = sourRdd2.leftOuterJoin(issuesRdd).map(x => {

      val left = x._2._1
      val rightOption = x._2._2
      var filterTag = "0"

      if (!rightOption.isEmpty) {
        filterTag = "1"
      }
      left.put("filterTag", filterTag)

      left

    }).filter(x => {
      "0".equals(x.getString("filterTag"))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    filterRdd

  }

  def getDebangCuofenData(spark: SparkSession, incDay: String, lastDay: String) = {
    logger.error("开始获取德邦t-1错分数据")
    var querySql =
      """
        |select
        |  b.sn as sn,
        |  regexp_replace(b.address, '[\\r\\n\\s,]+', '') as address,
        |  b.citycode as citycode,
        |  b.city as city,
        |  b.depponZc as depponZc,
        |  b.zc as zc,
        |  b.aoiid as aoiid,
        |  b.mapa_precision as mapa_precision,
        |  b.mapa_x as mapa_x,
        |  b.mapa_y as mapa_y,
        |  b.mapa_aoi_id as mapa_aoi_id,
        |  b.mapa_aoi_name as mapa_aoi_name,
        |  b.ts_precision as ts_precision,
        |  b.ts_x as ts_x,
        |  b.ts_y as ts_y,
        |  b.ts_aoi_id as ts_aoi_id,
        |  b.ts_aoi_name as ts_aoi_name,
        |  b.dataSrc as dataSrc,
        |  b.src as src,
        |  b.adcode as adcode,
        |  b.groupid as groupid,
        |  b.standardization as standardization,
        |  b.keyWord as keyWord,
        |  b.model_Zc as model_Zc,
        |  b.ts_xy_Zc as ts_xy_Zc,
        |  b.mapa_xy_Zc as mapa_xy_Zc,
        |  b.inc_day as inc_day,
        |  b.mapaaoizc as mapa_aoi_zc,
        |  b.tsaoizc as ts_aoi_zc
        |from
        |  (
        |    select
        |      get_json_object(data_info, '$.sn') sn,
        |      inc_day
        |    from
        |      dm_gis.t_deppon_sign_index_info_d
        |    where
        |      data_type = 'wd'
        |      and get_json_object(data_info, '$.reqBody.dataSrc') = 'RDS'
        |      and inc_day BETWEEN '%s'
        |      AND '%s'
        |  --     and get_json_object(data_info, '$.sn') in
        |  -- ('DPK330145133741','DPK330145133734','DPK330145133704','DPK330145133792','DPK330145133727','DPK330145133746','DPK330145133745','DPK330145133718','DPK330145133702','DPK210135464043','DPK330145133782','DPK330145133720','DPK330145133793','DPK330145133740','DPK330145133791','DPK330145133780','DPK330145133758','DPK330145133710','DPK330145133742','DPK330145133815','DPK330145133789','DPK330145133722','DPK330145133732','DPK330145133760','DPK330145133802','DPK330145133743','DPK330145133750','DPK330145133705','DPK330145133784','DPK330145133708','DPK330145133803','DPK330145133719','DPK330145133755','DPK330145133767','DPK330145133810','DPK330145133700','DPK330145133716','DPK330145133707','DPK330145133812','DPK330145133748','DPK330145133813','DPK330145133775','DPK330145133795','DPK330145133757','DPK330145133711','DPK330145133764','DPK330145133785','DPK330145133772','DPK330145133771','DPK330145133728','DPK330145133737','DPK330145133800','DPK330145133703','DPK330145133765','DPK330145133805','DPK330145133731','DPK330145133788','DPK330145133756','DPK330145133814','DPK330145133717','DPK330145133768','DPK330145133807','DPK330145133733','DPK330145133769','DPK330145133806','DPK330145133779','DPK330145133724','DPK330145133777','DPK330145133763','DPK330145133799','DPK368049718669','DPK330145133790','DPK330145133735','DPK330145133804','DPK368048929985','DPK330145133754','DPK330145133712','DPK330145133781','DPK330145133752')
        |     )a
        |  left outer join (
        |    select
        |      get_json_object(data_info, '$.sn') sn,
        |      get_json_object(data_info, '$.reqBody.address') address,
        |      get_json_object(data_info, '$.depponZc') depponZc,
        |      get_json_object(data_info, '$.mapAXy.x') mapa_x,
        |      get_json_object(data_info, '$.mapAXy.y') mapa_y,
        |      get_json_object(data_info, '$.mapAXy.precision') mapa_precision,
        |      get_json_object(data_info, '$.mapAXy.aoi_id') mapa_aoi_id,
        |      get_json_object(data_info, '$.mapAXy.aoi_name') mapa_aoi_name,
        |      get_json_object(data_info, '$.tsXy.precision') ts_precision,
        |      get_json_object(data_info, '$.tsXy.x') ts_x,
        |      get_json_object(data_info, '$.tsXy.y') ts_y,
        |      get_json_object(data_info, '$.tsXy.aoi_id') ts_aoi_id,
        |      get_json_object(data_info, '$.tsXy.aoi_name') ts_aoi_name,
        |      get_json_object(data_info, '$.reqBody.src') src,
        |      get_json_object(data_info, '$.reqBody.adcode') adcode,
        |      get_json_object(data_info, '$.reqBody.zc') zc,
        |      get_json_object(data_info, '$.reqBody.standardization') standardization,
        |      get_json_object(data_info, '$.reqBody.keyWord') keyWord,
        |      get_json_object(data_info, '$.model_Zc') model_Zc,
        |      get_json_object(data_info, '$.ts_xy_Zc') ts_xy_Zc,
        |      get_json_object(data_info, '$.mapa_xy_Zc') mapa_xy_Zc,
        |      get_json_object(data_info, '$.reqBody.aoiid') aoiid,
        |      get_json_object(data_info, '$.reqBody.dataSrc') dataSrc,
        |      get_json_object(data_info, '$.reqBody.group') groupid,
        |      get_json_object(data_info, '$.reqBody.cityCode') citycode,
        |      get_json_object(data_info, '$.cityCode') city,
        |      get_json_object(data_info, '$.mapaAoiZc') mapaAoiZc,
        |      get_json_object(data_info, '$.tsAoiZc')  tsAoiZc,
        |      inc_day
        |    from
        |      dm_gis.t_deppon_sign_index_info_d
        |    where
        |      data_type in ('src', 'zcmodel_buzErrZCModelRight')
        |      and inc_day BETWEEN '%s'
        |      AND '%s'
        |  ) b on a.sn = b.sn
        |""".stripMargin

    querySql = String.format(querySql, lastDay, incDay, lastDay, incDay)

    logger.error(querySql)

    val sourRdd = SparkUtils.getRowToJson(spark, querySql)
    logger.error(s"共获取t-1德邦错分数据:${sourRdd.count}")

    val sourceRdd = getFilterWeek(spark, incDay, sourRdd)
    logger.error("过滤后输入数据量为：" + sourceRdd.count())

    sourceRdd
  }


  def filterAddr(spark: SparkSession, zcFalseRdd: RDD[JSONObject]) = {
    val reNum = zcFalseRdd.count()
    logger.error("调精细化接口: " + reNum)

    val cmsLimit = 1000
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, assUrl, "3a191e7427e8470c86271a069411c66b", reNum, 2)
    val jxhRdd = zcFalseRdd.repartition(2).mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        var tag = false
        val address = JSONUtil.getJsonVal(o, "address", "")
        val citycode = JSONUtil.getJsonVal(o, "city", "")
        val url = String.format(assUrl, URLEncoder.encode(address, "utf-8"), citycode)
        if (address.nonEmpty && citycode.nonEmpty) {
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, index, cmsLimit / 2, logger)
          val res = HttpClientUtil.getJsonByGet(url)
          o.put("filterRes", res)
          if (res != null) {
            val explicit = JSONUtil.getJsonVal(res, "result.data.explicit", "")
            o.put("explicit", explicit)
            if (explicit.equals("1")) tag = true
          }
        }
        o.put("jxhTag", tag)
        o.put("filterUrl", url)
        o.put("originId", UUID.randomUUID().toString.replaceAll("-", ""))
        (tag, o)
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完接口的数据量：" + jxhRdd.count())
    zcFalseRdd.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)

    val nextRdd = jxhRdd.filter(_._1).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd = jxhRdd.filter(!_._1).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("explicit=1 的数据量：" + nextRdd.count())
    logger.error("explicit!=1 的数据量：" + unionRdd.count())
    jxhRdd.unpersist()
    logger.error("开始过滤地址信息")
    val filterRdd = nextRdd.map(o => {
      val jsonObj = o._2
      val address = JSONUtil.getJsonVal(jsonObj, "address", "")
      val flag = address.matches("(.*德邦.*)|(.*营业.*)|(.*网点.*)|(.*对面$)")
      jsonObj.put("except_addr", flag)
      (flag, jsonObj)
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("过滤完地址信息的数据量：" + filterRdd.count())
    val nextRdd1 = filterRdd.filter(!_._1).map(tp => {
      val jsonObj = tp._2
      val zc = JSONUtil.getJsonVal(jsonObj, "zc", "")
      val depponZc = JSONUtil.getJsonVal(jsonObj, "depponZc", "")

      val mapa_aoi_zc = JSONUtil.getJsonVal(jsonObj, "mapa_aoi_zc", "")
      val ts_aoi_zc = JSONUtil.getJsonVal(jsonObj, "ts_aoi_zc", "")
      val zc_modzc = JSONUtil.getJsonVal(jsonObj, "zc_modzc", "")

      //zc比较计数
      val zc_cnt = new Cnt(0)
      compareAndAdd(mapa_aoi_zc, zc, zc_cnt)
      compareAndAdd(ts_aoi_zc, zc, zc_cnt)
      compareAndAdd(zc_modzc, zc, zc_cnt)
      jsonObj.put("zc_cnt", zc_cnt.cnt)

      //depponZc比较计数
      val deppon_zc_cnt = new Cnt(0)
      compareAndAdd(mapa_aoi_zc, depponZc, deppon_zc_cnt)
      compareAndAdd(ts_aoi_zc, depponZc, deppon_zc_cnt)
      compareAndAdd(zc_modzc, depponZc, deppon_zc_cnt)
      jsonObj.put("deppon_zc_cnt", deppon_zc_cnt.cnt)

      jsonObj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd1 = filterRdd.filter(_._1).map(_._2).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("共获取过滤地址数据共：" + unionRdd1.count())
    logger.error("打标签的数据量：" + nextRdd1.count())
    filterRdd.unpersist()
    val checkRdd = nextRdd1.map(jsonObj => {
      val tag = jsonObj match {
        case jsonObj if StringUtils.nonEmptyEq(jsonObj.getString("mapa_aoi_id"), jsonObj.getString("aoiid"))
          || StringUtils.nonEmptyEq(jsonObj.getString("ts_aoi_id"), jsonObj.getString("aoiid"))
        => "-1"
        case jsonObj if jsonObj.getInteger("zc_cnt") >= 2
        => "0"
        case jsonObj if jsonObj.getInteger("deppon_zc_cnt") >= 2
        => "4"
        case jsonObj if jsonObj.getInteger("deppon_zc_cnt") >= 1
        => "3"
        case jsonObj if StringUtils.nonEmptyEq(jsonObj.getString("mapa_xy_Zc"), jsonObj.getString("depponZc"))
          || StringUtils.nonEmptyEq(jsonObj.getString("ts_xy_Zc"), jsonObj.getString("depponZc"))
        => "2"
        case _ => "1"
      }
      jsonObj.put("tag", tag)
      jsonObj
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("打完标签的数据量：" + checkRdd.count())
    nextRdd1.unpersist()

    logger.error("获取adcode")
    val adcodeRdd = checkRdd.repartition(2).map(o => {
      val cityCode = JSONUtil.getJsonVal(o, "city", "")
      val groupid_at = JSONUtil.getJsonVal(o, "groupid_at", "")
      var adcode = ""
      if (StringUtils.nonEmpty(groupid_at)) {
        val req = String.format(getAddrByCityCodeAndAddrUrl, cityCode, groupid_at)
        val res = HttpInvokeUtil.sendGet(req)
        adcode = try {
          JSON.parseObject(res).getJSONObject("data").getString("adcode")
        } catch {
          case _ => ""
        }
      }
      o.put("adcode_cms", adcode)
      if ("1,4,5,6,7,8".split(",").contains(adcode)) {
        o.put("cms_aoi_right", "true")
      } else {
        o.put("cms_aoi_right", "false")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("adcodeRdd cnt:" + adcodeRdd.count())
    checkRdd.unpersist()

    val adcodeTrueRdd = adcodeRdd.filter(o => "true".equals(JSONUtil.getJsonVal(o, "cms_aoi_right", ""))).persist(StorageLevel.MEMORY_AND_DISK)
    val adcodeFalseRdd = adcodeRdd.filter(o => "false".equals(JSONUtil.getJsonVal(o, "cms_aoi_right", ""))).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("adcodeTrueRdd cnt:" + adcodeTrueRdd.count())
    logger.error("adcodeFalseRdd cnt:" + adcodeFalseRdd.count())
    adcodeRdd.unpersist()

    val cms_sql = "select aoi_id,aoi_code,aoi_name from dm_gis.cms_aoi_sch where (aoi_id is not null and aoi_id <>'')"
    val cmsRdd = SparkUtils.getRowToJson(spark, cms_sql)

    val clearRdd = adcodeFalseRdd.map(o => (o.getString("aoiid_at"), o)).leftOuterJoin(cmsRdd.map(o => (o.getString("aoi_id"), o)).reduceByKey((o1, o2) => o1)).map(tp => {
      val left = tp._2._1
      if (tp._2._2.nonEmpty) {
        val right = tp._2._2.get
        val aoi_code = right.getString("aoi_code")
        val aoi_name = right.getString("aoi_name")

        left.put("aoi_code_at", aoi_code)
        left.put("aoiname_at", aoi_name)
      }
      left
    }).map(o => {
      val address = o.getString("address")
      val keyword_at = o.getString("keyword_at")
      val aoiname_at = o.getString("aoiname_at")
      //将字段中的中文数字转化成阿拉伯数字
      var address_clear = ""
      var keyword_at_clear = ""
      var aoiname_at_clear = ""
      if (StringUtils.nonEmpty(address)) {
        address_clear = StringNumUtils.outputArabNumberString(address)
      }
      if (StringUtils.nonEmpty(keyword_at)) {
        keyword_at_clear = StringNumUtils.outputArabNumberString(keyword_at)
      }
      if (StringUtils.nonEmpty(aoiname_at)) {
        aoiname_at_clear = StringNumUtils.outputArabNumberString(aoiname_at)
      }
      o.put("address_clear", address_clear)
      o.put("keyword_at_clear", keyword_at_clear)
      o.put("aoiname_at_clear", aoiname_at_clear)

      if ((StringUtils.nonEmpty(address_clear) && StringUtils.nonEmpty(aoiname_at_clear) && address_clear.contains(aoiname_at_clear))
        || (StringUtils.nonEmpty(keyword_at_clear) && StringUtils.nonEmpty(aoiname_at_clear) && keyword_at_clear.contains(aoiname_at_clear))
        || (StringUtils.nonEmpty(aoiname_at_clear) && StringUtils.nonEmpty(keyword_at_clear) && aoiname_at_clear.contains(keyword_at_clear))) {
        o.put("aoi_concat", "true")
      } else {
        o.put("aoi_concat", "false")
        val src = o.getString("src")
        if ("chkn".equals(src)) {
          o.put("push_aoi_task", "false")
        } else {
          o.put("push_aoi_task", "true")
        }
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("clearRdd cnt:" + clearRdd.count())
    adcodeFalseRdd.unpersist()
    cmsRdd.unpersist()

    val unionAllRdd = unionRdd.union(unionRdd1).union(adcodeTrueRdd).union(clearRdd).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("汇总的总数据量：" + unionAllRdd.count())
    unionRdd.unpersist()
    unionRdd1.unpersist()
    adcodeTrueRdd.unpersist()
    clearRdd.unpersist()
    unionAllRdd
  }

  def compareAndAdd(text1: String, text2: String, cnt: Cnt): Unit = {
    if (StringUtils.nonEmptyEq(text1, text2)) {
      cnt.cnt += 1
    }
  }


  def doReview(spark: SparkSession, notNormRdd: RDD[JSONObject]) = {

    val reNum = notNormRdd.count()
    logger.error("开始进行压审补: " + reNum)

    val cmsLimit = 5000
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskDesc, assUrl, "3a191e7427e8470c86271a069411c66b", reNum, 20)
    val sbRdd = notNormRdd.repartition(2).mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (o <- iter) yield {
        var tag = false
        val address = JSONUtil.getJsonVal(o, "address", "")
        val citycode = JSONUtil.getJsonVal(o, "city", "")
        var deptcode = ""
        if (address.nonEmpty && citycode.nonEmpty) {
          //ak限速
          SparkUtils.limitAkUse(startTime, cnt, index, cmsLimit / 2, logger)
          //跑容灾接口
          val normReq = String.format(normUrl, "zh", citycode, URLEncoder.encode(address, "utf-8"))
          val normRes = HttpClientUtil.getJsonByGet(normReq)
          deptcode = try {
            JSONUtil.getJsonVal(normRes.getJSONObject("result").getJSONArray("tcs").getJSONObject(0), "dept", "")
          } catch {
            case _ => ""
          }
          o.put("normReq", normReq)
          o.put("normRes", normRes)
          o.put("deptcode", deptcode)
          if (deptcode.isEmpty) o.put("type", "NoDept") else o.put("type", "No")
        }
        o
      }
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完接口的数据量：" + sbRdd.count())
    notNormRdd.unpersist()
    BdpTaskRecordUtil.endNetworkInterface("01412406", httpInvokeId)
    //    val reviewRdd = notNormRdd.map(obj => {
    //      val citycode = obj.getString("city")
    //      val address = obj.getString("address")
    //      var deptcode = ""
    //      //跑容灾接口
    //      val normReq = String.format(normUrl, "zh", citycode, URLEncoder.encode(address, "utf-8"))
    //      val normRes = Utils.retryGet(normReq)
    //
    //      deptcode = try {
    //        JSON.parseObject(normRes).getJSONObject("result").
    //          getJSONArray("tcs").getJSONObject(0).getString("dept")
    //      }
    //      catch {
    //        case _ => ""
    //      }
    //
    //      obj.put("normReq", normReq)
    //      obj.put("normRes", try {
    //        JSON.parseObject(normRes)
    //      } catch {
    //        case e: Exception => new JSONObject().put("error", e + "\n" + normRes)
    //      })
    //
    //      (deptcode, obj)
    //    }).repartition(10)
    //      .aggregateByKey(List[JSONObject]())(SparkUtils.seqOp, SparkUtils.combOp)
    //      .flatMap(obj => {
    //        if (!StringUtils.nonEmpty(obj._1)) {
    //          obj._2.map(elem => {
    //            ("NoDept", elem)
    //          })
    //        } else {
    //          val list = obj._2
    //          var resList = List[(String, JSONObject)]()
    //          //计算工单地址频次，去重后按地址tag优先级、频次降序排列
    //          val addrList = list.groupBy(_.getString("address"))
    //            .map(elem => {
    //              val tagTopJsonObj = elem._2.maxBy(_.getString("tag"))
    //
    //              ((tagTopJsonObj.getString("tag"), elem._2.size), tagTopJsonObj)
    //            }).toList.sortBy(elem => elem._1).reverse
    //
    //          //每个网点取前15条地址到错柯错分审补核实
    //          var cnt = 0
    //          for (elem <- addrList if cnt < 15) {
    //            cnt += 1
    //            val json = new JSONObject()
    //            json.put("cityCode", elem._2.getString("city"))
    //            json.put("znoCode", obj._1)
    //            json.put("address", elem._2.getString("address"))
    //            json.put("taskSource", "DB")
    //            json.put("originId", elem._2.getString("originId"))
    //            json.put("ak", "15F6437FF8A2EDFE0C22EA37B12D421A")
    //
    //            //生产
    //            val reviewRes = SparkUtils.doPost(pushChknWrongAoiTaskUrl, json, logger)
    //            elem._2.put("reviewRes", reviewRes)
    //            elem._2.put("reviewReq", json)
    //            elem._2.put("rank", cnt)
    //            resList = ("shenbu", elem._2) :: resList
    //          }
    //          //  resList
    //          for (root <- list) yield {
    //            var resJson = ("No", root)
    //
    //            for (leaf <- resList if resJson._1.equals("No")) {
    //              if (root.getString("originId").equals(leaf._2.getString("originId"))) {
    //                root.fluentPutAll(leaf._2)
    //                resJson = ("shenbu", root)
    //              }
    //            }
    //            resJson
    //          }
    //
    //        }
    //      }).persist(StorageLevel.DISK_ONLY)
    //
    //    logger.error(s"共推送地址到CGCS错柯错分审补核实:${reviewRdd.count()} 组")
    //
    //    notNormRdd.unpersist()

    sbRdd
  }

  def saveTable(spark: SparkSession, resRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    //    val rowDf = allRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    //    logger.error("入明细表数量：" + rowDf.count())
    //    rowDf.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(detailName)

    val reDf = resRdd.map(o => {
      Re(
        JSONUtil.getJsonVal(o, "sn", "")
        , JSONUtil.getJsonVal(o, "address", "")
        , JSONUtil.getJsonVal(o, "citycode", "")
        , JSONUtil.getJsonVal(o, "city", "")
        , JSONUtil.getJsonVal(o, "depponZc", "")
        , JSONUtil.getJsonVal(o, "zc", "")
        , JSONUtil.getJsonVal(o, "aoiid", "")
        , JSONUtil.getJsonVal(o, "mapa_precision", "")
        , JSONUtil.getJsonVal(o, "mapa_x", "")
        , JSONUtil.getJsonVal(o, "mapa_y", "")
        , JSONUtil.getJsonVal(o, "mapa_aoi_id", "")
        , JSONUtil.getJsonVal(o, "mapa_aoi_name", "")
        , JSONUtil.getJsonVal(o, "ts_precision", "")
        , JSONUtil.getJsonVal(o, "ts_x", "")
        , JSONUtil.getJsonVal(o, "ts_y", "")
        , JSONUtil.getJsonVal(o, "ts_aoi_id", "")
        , JSONUtil.getJsonVal(o, "ts_aoi_name", "")
        , JSONUtil.getJsonVal(o, "dataSrc", "")
        , JSONUtil.getJsonVal(o, "src", "")
        , JSONUtil.getJsonVal(o, "adcode", "")
        , JSONUtil.getJsonVal(o, "groupid", "")
        , JSONUtil.getJsonVal(o, "standardization", "")
        , JSONUtil.getJsonVal(o, "keyWord", "")
        , JSONUtil.getJsonVal(o, "model_Zc", "")
        , JSONUtil.getJsonVal(o, "ts_xy_Zc", "")
        , JSONUtil.getJsonVal(o, "mapa_xy_Zc", "")
        , JSONUtil.getJsonVal(o, "mapa_aoi_zc", "")
        , JSONUtil.getJsonVal(o, "ts_aoi_zc", "")
        , JSONUtil.getJsonVal(o, "deptcode", "")
        , JSONUtil.getJsonVal(o, "aoiid_at", "")
        , JSONUtil.getJsonVal(o, "groupid_at", "")
        , JSONUtil.getJsonVal(o, "src_at", "")
        , JSONUtil.getJsonVal(o, "aoicode_at", "")
        , JSONUtil.getJsonVal(o, "keyword_at", "")
        , JSONUtil.getJsonVal(o, "adcode_at", "")
        , JSONUtil.getJsonVal(o, "is_aoi_modify", "")
        , JSONUtil.getJsonVal(o, "zc_new", "")
        , JSONUtil.getJsonVal(o, "tc_new", "")
        , JSONUtil.getJsonVal(o, "keyword_new", "")
        , JSONUtil.getJsonVal(o, "msg_new", "")
        , JSONUtil.getJsonVal(o, "zc_modzc", "")
        , JSONUtil.getJsonVal(o, "tc_modzc", "")
        , JSONUtil.getJsonVal(o, "keyword_modzc", "")
        , JSONUtil.getJsonVal(o, "msg_modzc", "")
        , JSONUtil.getJsonVal(o, "is_zc_modify", "")
        , JSONUtil.getJsonVal(o, "explicit", "")
        , JSONUtil.getJsonVal(o, "originId", "")
        , JSONUtil.getJsonVal(o, "except_addr", "")
        , JSONUtil.getJsonVal(o, "tag", "")
        , JSONUtil.getJsonVal(o, "adcode_cms", "")
        , JSONUtil.getJsonVal(o, "cms_aoi_right", "")
        , JSONUtil.getJsonVal(o, "aoi_code_at", "")
        , JSONUtil.getJsonVal(o, "aoiname_at", "")
        , JSONUtil.getJsonVal(o, "address_clear", "")
        , JSONUtil.getJsonVal(o, "keyword_at_clear", "")
        , JSONUtil.getJsonVal(o, "aoiname_at_clear", "")
        , JSONUtil.getJsonVal(o, "aoi_concat", "")
        , JSONUtil.getJsonVal(o, "push_aoi_task", "")
      )
    }).toDF()

    //汇总表入库
    logger.error("入统计表数量：" + reDf.count())
    reDf.show(2, false)

    reDf.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(finalTable)

    logger.error("完成")

  }


}
