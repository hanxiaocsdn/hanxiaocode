package com.sf.gis.scala.debang.kuaiYun

import com.sf.gis.java.base.util.HbaseUtil
import com.sf.gis.scala.debang.util._
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.hbase.client._
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.{CellUtil, HBaseConfiguration, TableName}
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession

/**
 * 网络定位服务脏数据处理_V1.0 01412406
 * hbase删除指定数据
 */

object NetServiceDirtyProcesse {
  @transient lazy val logger: Logger = Logger.getLogger(NetServiceDirtyProcesse.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val sqlpartition = 200


  //  hbase相关信息（生产）
  val hbase_zookeeper_quorum = "cnsz26plc8uk,cnsz26plydsr,cnsz26pljlt6,cnsz26plw5a0,cnsz26pldicw"
  val hbase_zookeeper_property_clientPort = "2181"
  val zookeeper_znode_parent = "/hbase"
  val hbase_gis_family = "info"


  def main(args: Array[String]): Unit = {
    val tableName = args.apply(0)
    val rowkey = args.apply(1)
    val value = args.apply(2)
    logger.error(s"删除${tableName}的rowkey:" + rowkey + ",删除的值:" + value)
    start(tableName, rowkey, value)
    logger.error("结束所有运行")

  }


  def start(tableName: String, rowkey: String, value: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error(s"删除${tableName}里${rowkey}=${value}的数据")
    startSta(spark, tableName, rowkey, value)
    logger.error("删除完毕")

  }


  def startSta(spark: SparkSession, tableName: String, rowkey: String, value: String) = {
    logger.error(s"获取表数据，rowkey是${rowkey}")
    val hbaseConf = getHbaseConf()
    val con: Connection = ConnectionFactory.createConnection(hbaseConf)
    println("================>" + con)

    val table: Table = con.getTable(TableName.valueOf(tableName))

    //    val scan = new Scan()
    //    //获取表数据
    //    val scanner = table.getScanner(scan)


    //      val wiriPrefixTmp = Math.abs(value.hashCode.toLong) % 20
    //      val wiriPrefix = wiriPrefixTmp.toInt
    //    println("wiriPrefix是"+wiriPrefix)
    //
    //    var rowkey = new StringBuffer()
    //    if(wiriPrefix<10){
    //      rowkey.append("0").append(wiriPrefix).append("_").append(value)
    //    }else{
    //      rowkey.append(wiriPrefix).append("_").append(value)
    //    }
    //
    //    println("rowkey是："+rowkey.toString)
    //

    //    val result = HbaseUtil.getByKey(table,rowkey.toString)
    val result = HbaseUtil.getByKey(table, rowkey)


    val out = new StringBuilder();
    out.append("[");
    for (kv <- result.rawCells()) {

      val rowKey = Bytes.toString(CellUtil.cloneRow(kv)); //取行键
      val timestamp = kv.getTimestamp(); //取到时间戳

      val col = new String(CellUtil.cloneQualifier(kv))
      val value = new String(CellUtil.cloneValue(kv))
      out.append(col).append(":").append(value).append(";      ")
      println(s"rowKey :${rowKey}  timestamp:${timestamp}  ")
    }
    out.append("]");

    logger.error("获取到的值：" + out.toString())


    logger.error("删除rowkey：" + out.toString())

    //根据rowkey删除数据
    HbaseUtil.deleteByKey(table, rowkey)

    logger.error("再次查询：" + out.toString())
    //再次查询
    val resultG = HbaseUtil.getByKey(table, rowkey)
    out.clear()
    out.append("[");
    for (kv <- resultG.rawCells()) {

      val rowKey = Bytes.toString(CellUtil.cloneRow(kv)); //取行键
      val timestamp = kv.getTimestamp(); //取到时间戳
      val col = new String(CellUtil.cloneQualifier(kv))
      val value = new String(CellUtil.cloneValue(kv))
      out.append(col).append(":").append(value).append(";      ")
      println(s"rowKey :${rowKey}  timestamp:${timestamp}  ")
    }
    out.append("]");
    logger.error("删除后重新获取值：" + out.toString())

    logger.error("结束所有运行")

  }


  def getHbaseConf() = {
    var hbaseConf: Configuration = null
    try {
      //获取hbase的conf
      hbaseConf = HBaseConfiguration.create()

      //设置写入的表
      hbaseConf.set("hbase.zookeeper.quorum", hbase_zookeeper_quorum)
      hbaseConf.set("hbase.zookeeper.property.clientPort", hbase_zookeeper_property_clientPort)
      hbaseConf.set("zookeeper.znode.parent", zookeeper_znode_parent)
      hbaseConf.setInt("timeout", 1200000)
      hbaseConf.setInt("hbase.client.scanner.timeout.period", 600000)
      hbaseConf.setInt("hbase.rpc.timeout", 600000)


      logger.error(s"hbase.zookeeper.quorum.value: {${hbase_zookeeper_quorum}")
      logger.error(s"hbase.zookeeper.property.clientPort.value: {${hbase_zookeeper_quorum}}")
      logger.error(s"zookeeper.znode.parent.value: {${hbase_zookeeper_quorum}}")
    } catch {
      case e: Exception => logger.error(">>>连接hbase失败:" + e)
    }
    hbaseConf
  }


}
