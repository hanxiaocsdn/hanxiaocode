package com.sf.gis.scala.debang.kuaiYun

import java.util

import com.sf.gis.scala.base.util.Sakyamuni
import com.sf.gis.scala.debang.util._
import org.apache.log4j.Logger
import org.apache.spark.SparkConf
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, Dataset, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ListBuffer

object kuaiYunComplaint {
  @transient lazy val logger: Logger = Logger.getLogger(kuaiYunComplaint.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val sqlpartition = 200
  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  case class  savaTable(   waybillno :String = ""
                   ,input_data :String= ""
                   ,serial_inc_day_data :String= ""
                   ,appointmentno :String= ""
                   ,properties_time :String= ""
                   ,sn :String= ""
                   ,dt :String= ""
                   ,src :String= ""
                   ,address :String= ""
                   ,province :String= ""
                   ,city :String= ""
                   ,county :String= ""
                   ,town :String= ""
                   ,detailaddr :String= ""
                   ,addresstext :String= ""
                   ,phonenumber :String= ""
                   ,personname :String= ""
                   ,Inc_day :String= ""
               )

  def start(startDay: String, days: Int): Unit = {

    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error("开始计算：" + startDay)
    startSta(spark,startDay)
    logger.error("计算结束：" + startDay)
    logger.error("统计完毕")
  }

  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataDf: RDD[savaTable] = getDataDf(spark,incDay)
    logger.error("开始入库")
    //入库
    saveTable(spark,dataDf,incDay)
    logger.error("结束所有运行")
  }


//入库
  def saveTable(spark: SparkSession,  saveRdd:RDD[savaTable],incDay: String): Unit = {
    logger.error("最终表数据：" + saveRdd.count())
    val tableName = "dm_gis.adds_customer_complain_di" //生产数据表
    import spark.implicits._
      saveRdd.toDF().withColumn("dt_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
  }

//获取数据
  def getDataDf(spark: SparkSession ,incDay: String) = {


    //获取文件
    val beginDf: DataFrame = spark.read.option("inferschema", "false")
      .option("header","true")
      .option("delimiter", ",")
      .option("encoding", "UTF-8")
      .csv("/user/01412406/upload/weekkesu.csv")
//      .csv("/user/01324490/upload/weekkesu.csv")
//      .csv("/user/01416396/upload/weekkesu.csv")
//      .csv("/user/01403862/upload/ys.csv")
      .toDF("input_data","waybillno")
      .persist(StorageLevel.MEMORY_AND_DISK)

    logger.error(s"获取文件数：${beginDf.count()}:"+beginDf.show(2,false))


    logger.error("获取cx_appointment_req_serial表数据")

    import spark.implicits._
    val list = beginDf.map(obj=>{
      val input_data  = obj.getAs[String]("input_data")
      val waybillno  = obj.getAs[String]("waybillno")
      val before_input_data =   DateUtil.getDateStr(input_data, -7, "")
      val after_input_data =   DateUtil.getDateStr(input_data, 7, "")
      (input_data,waybillno,before_input_data,after_input_data)
    }).collect().toList.toBuffer


    var listBuffer = new ListBuffer[savaTable]()

    for(i <- 0 until list.size){
   val t:(String, String, String, String)=  list(i)
      val serialDf = getSerialDataDf(spark,t)
      //查询ods_inc_ubas.product_inc_ubas_cx
      if(!serialDf.rdd.isEmpty()){
        val serialList = serialDf.collect().toList.toBuffer
        val UbasData= getUbasData(spark,serialList(0))
        //查询ods_inc_ubas.product_inc_ubas_cx
        if(UbasData._1){
         val  UbasList = UbasData._2.collect().toList.toBuffer

          for(i<- 0 until UbasList.size){

            val CollectStdData= getCollectStdData(spark,UbasList(i))
            // 查询dm_gis.gis_ass_adds_log_parse/dm_gis.gis_rss_seg_cloud_log_collect_std
            if(CollectStdData._1){

              val CollectStdList=CollectStdData._2.collect().toList.toBuffer


              for(i<- 0 until CollectStdList.size){
                listBuffer.append(CollectStdList(i))
              }
            }else{
              val re = UbasList(i)
              listBuffer.append(savaTable(re._1,re._2,re._5,re._6,re._10,re._11,re._12))
            }
          }


        }else{
          val re = serialList(0)
          listBuffer.append(savaTable(re._1,re._2,re._5,re._6))
        }

      }else{
        listBuffer.append(savaTable(t._2,t._1))
      }

      logger.error(s"结果集数量：${listBuffer.size}:${listBuffer.take(3).toString()}")

    }


    val reRdd = spark.sparkContext.makeRDD(listBuffer)
    reRdd
   }




  def  getSerialDataDf(spark:SparkSession,tu:(String, String, String, String)) ={
    import spark.implicits._
    //获取cx_appointment_req_serial表数据
    val serialSql =
      s"""
         |select /*+COALESCE(1)*/
         | '${tu._2}' as waybillno
         |,'${tu._1}' as input_data
         |,'${tu._3}' as before_input_data
         |,'${tu._4}' as after_input_data
         |,inc_day  as serial_inc_day_data
         |,appointmentno
         |--,date_format(date_add(from_unixtime(unix_timestamp(b.inc_day,'yyyyMMdd'),'yyyy-mm-dd'),-7),'yyyyMMdd') as  before_serial_data
         |--,date_format(date_add(from_unixtime(unix_timestamp(b.inc_day,'yyyyMMdd'),'yyyy-mm-dd'),7),'yyyyMMdd') as  after_serial_data
         |from
         |ods_cx.cx_appointment_req_serial b
         |where b.waybillno = '${tu._2}'
         and b.inc_day between '${tu._3}' and  '${tu._4}'
      """.stripMargin
    logger.error(serialSql)
    val serialDf = spark.sql(serialSql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联cx_appointment_req_serial的数量"+serialDf.count())
    serialDf.createOrReplaceTempView("serialTable")
    serialDf.show(3,false)
    val re = serialDf.map(
      obj=>{
        val waybillno =  obj.getAs[String]("waybillno")
        val input_data =  obj.getAs[String]("input_data")
        val before_input_data =  obj.getAs[String]("before_input_data")
        val after_input_data =  obj.getAs[String]("after_input_data")
        val serial_inc_day_data =  obj.getAs[String]("serial_inc_day_data")
        val appointmentno =  obj.getAs[String]("appointmentno")
        val before_serial_data = if(obj.getAs[String]("serial_inc_day_data").nonEmpty) DateUtil.getDateStr(obj.getAs[String]("serial_inc_day_data"), -7, "") else obj.getAs[String]("serial_inc_day_data")
        val after_serial_data =  if(obj.getAs[String]("serial_inc_day_data").nonEmpty) DateUtil.getDateStr(obj.getAs[String]("serial_inc_day_data"), 7, "") else obj.getAs[String]("serial_inc_day_data")
        (waybillno,
          input_data,
          before_input_data,
          after_input_data,
          serial_inc_day_data,
          appointmentno,
          before_serial_data,
          after_serial_data )
      }
    )

    re
  }


  def  getUbasData(spark:SparkSession,inputData:(String, String, String, String, String, String, String, String)) ={
    import spark.implicits._
    //获取cx_appointment_req_serial表数据


//    val test =
//      s"""
//        |select
//        |b.properties['appointmentNo'] as properties_appointmentno
//        |,b.properties['time'] as properties_time
//        |,b.properties['sn'] as properties_sn
//        |,event_id
//        |,dt
//        |from
//        |ods_inc_ubas.product_inc_ubas_cx b
//        |where '${inputData._7}' <= dt and dt<= '${inputData._8}' and event_id = 'XCX1035'
//      """.stripMargin
//
//    spark.sql(test).persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("tmp")
//
//    val ubas_cx_sql =
//      s"""
//         |select /*+COALESCE(1)*/
//         |'${inputData._1}' as waybillno
//         |,'${inputData._2}' as input_data
//         |,'${inputData._3}' as before_input_data
//         |,'${inputData._4}' as after_input_data
//         |,'${inputData._5}' as serial_inc_day_data
//         |,'${inputData._6}' as appointmentno
//         |,'${inputData._7}' as before_serial_data
//         |,'${inputData._8}' as after_serial_data
//         |,properties_appointmentno
//         |,properties_time
//         |,properties_sn
//         |,dt
//         |from
//         |tmp b
//         |where properties_appointmentno = '${inputData._6}' and event_id = 'XCX1035'
//      """.stripMargin
//

    val ubas_cx_sql =
      s"""
         |select /*+COALESCE(1)*/
         |'${inputData._1}' as waybillno
         |,'${inputData._2}' as input_data
         |,'${inputData._3}' as before_input_data
         |,'${inputData._4}' as after_input_data
         |,'${inputData._5}' as serial_inc_day_data
         |,'${inputData._6}' as appointmentno
         |,'${inputData._7}' as before_serial_data
         |,'${inputData._8}' as after_serial_data
         |,b.properties['appointmentNo'] as properties_appointmentno
         |,b.properties['time'] as properties_time
         |,b.properties['sn'] as properties_sn
         |,dt
         |from
         |ods_inc_ubas.product_inc_ubas_cx b
         |where '${inputData._7}' <= dt and dt<= '${inputData._8}'
         |and b.properties['appointmentNo'] = '${inputData._6}' and event_id = 'XCX1035'
      """.stripMargin
    logger.error(ubas_cx_sql)
    val ubasDf = spark.sql(ubas_cx_sql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("关联cx_appointment_req_serial的数量"+ubasDf.count())
    ubasDf.show(3,false)

    val re = ubasDf.map(
      obj=>{
        val waybillno =  obj.getAs[String]("waybillno")
        val input_data =  obj.getAs[String]("input_data")
        val before_input_data =  obj.getAs[String]("before_input_data")
        val after_input_data =  obj.getAs[String]("after_input_data")
        val serial_inc_day_data =  obj.getAs[String]("serial_inc_day_data")
        val appointmentno =  obj.getAs[String]("appointmentno")
        val before_serial_data =  obj.getAs[String]("before_serial_data")
        val after_serial_data =  obj.getAs[String]("after_serial_data")
        val properties_appointmentno =  obj.getAs[String]("properties_appointmentno")
        val properties_time =  obj.getAs[String]("properties_time")
        val properties_sn =  obj.getAs[String]("properties_sn")
        val dt =  obj.getAs[String]("dt")
        (waybillno,
          input_data,
          before_input_data,
          after_input_data,
          serial_inc_day_data,
          appointmentno,
          before_serial_data,
          after_serial_data,
          properties_appointmentno,
          properties_time,
          properties_sn,
          dt )
      }
    )
    (!re.rdd.isEmpty(),re)

  }


  def  getCollectStdData(spark:SparkSession,inputData:(String, String, String, String, String, String, String, String, String, String, String, String)) ={
    import spark.implicits._
    //获取cx_appointment_req_serial表数据


    val CollectStdSql =
      s"""
         |select /*+COALESCE(1)*/
         | '${inputData._1}' as waybillno
         |,'${inputData._2}' as input_data
         |,'${inputData._5}' as serial_inc_day_data
         |,'${inputData._6}' as appointmentno
         |,'${inputData._10}' as properties_time
         |,'${inputData._11}' as sn
         |,'${inputData._12}' as dt
         |,b.src
         |,b.address
         |,b.province
         |,b.city
         |,b.county
         |,b.town
         |,b.detailaddr
         |,b.phonenumber
         |,b.addresstext
         |,b.personname
         |,b.Inc_day
         |,'gis_rss_seg_cloud_log_collect_std' as from_table
         |from dm_gis.gis_rss_seg_cloud_log_collect_std b
         |where  b.sn is not null and  b.sn = '${inputData._11}'
         |and  b.inc_day = '${inputData._10}'
      """.stripMargin
    logger.error(CollectStdSql)
    val CollectStdDf = spark.sql(CollectStdSql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取product_inc_ubas_cx的数量"+CollectStdDf.count())
    CollectStdDf.show(3,false)
    var res = CollectStdDf

    if(res.rdd.isEmpty()){
      CollectStdDf.unpersist()
      logger.error("==========================>product_inc_ubas_cx获取不到数据")
      val parseSql =
        s"""
           |select /*+COALESCE(1)*/
           | '${inputData._1}' as waybillno
           |,'${inputData._2}' as input_data
           |,'${inputData._5}' as serial_inc_day_data
           |,'${inputData._6}' as appointmentno
           |,'${inputData._10}' as properties_time
           |,'${inputData._11}' as sn
           |,'${inputData._12}' as dt
           |,b.src
           |,b.address
           |,b.province
           |,b.city
           |,b.county
           |,b.town
           |,b.detailaddr
           |,'' as addresstext
           |,'' as phonenumber
           |,'' as personname
           |,b.Inc_day
           |,'gis_ass_adds_log_parse' as from_table
           |from dm_gis.gis_ass_adds_log_parse b
           |where   b.sn = '${inputData._11}'
           |and  b.inc_day = '${inputData._10}'
      """.stripMargin
      logger.error(parseSql)
      val parseSqlDf = spark.sql(parseSql).persist(StorageLevel.MEMORY_AND_DISK)
      logger.error("获取gis_ass_adds_log_parse的数量"+parseSqlDf.count())
      parseSqlDf.show(3,false)
      res =parseSqlDf
    }


    val re = res.map(
      obj=> {
        val waybillno = obj.getAs[String]("waybillno")
        val input_data = obj.getAs[String]("input_data")
        val serial_inc_day_data = obj.getAs[String]("serial_inc_day_data")
        val appointmentno = obj.getAs[String]("appointmentno")
        val properties_time = obj.getAs[String]("properties_time")
        val sn = obj.getAs[String]("sn")
        val dt = obj.getAs[String]("dt")
        val addresstext = obj.getAs[String]("addresstext")
        val src = obj.getAs[String]("src")
        val phonenumber = obj.getAs[String]("phonenumber")
        val personname = obj.getAs[String]("personname")
        val address = obj.getAs[String]("address")
        val province = obj.getAs[String]("province")
        val city = obj.getAs[String]("city")
        val county = obj.getAs[String]("county")
        val town = obj.getAs[String]("town")
        val detailaddr = obj.getAs[String]("detailaddr")
        val Inc_day = obj.getAs[String]("Inc_day")

        savaTable( waybillno
          ,input_data
          ,serial_inc_day_data
          ,appointmentno
          ,properties_time
          ,sn
          ,dt
          ,src
          ,address
          ,province
          ,city
          ,county
          ,town
          ,detailaddr
          ,addresstext
          ,phonenumber
          ,personname
          ,Inc_day
        )
      }
    )
    (!re.rdd.isEmpty(),re)
  }


}


