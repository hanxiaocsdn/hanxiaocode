package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.{DesUtils, GzipUtils, HttpInvokeUtil}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.debang.util._
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object KuaiyunDispatchShunt {
  @transient lazy val logger: Logger = Logger.getLogger(KuaiyunDispatchReptile.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  //http://gis-int.int.sfdc.com.cn:1080/geo/api

  val dispatch_url = "http://gis-int.int.sfdc.com.cn:1080/elevator/api/queryElevator?address=%s&citycode=%s&ak=379924356e8b444da83f04ebb1703f19&showmore=true"
  val similarit_url = "http://gis-int.int.sfdc.com.cn:1080/rdsks/api/getSimilar?ak=3eb300d2e06947f7945cd02530a32fd2&beforeAddress=%s&afterAddress=%s"
//  val gd_url = "https://gis-rss-eta-navi-query.sf-express.com/navi-query/v2/poi"
  val gd_url = "http://sfmap-gis-rss-eta-apis.int.sfcloud.local:8000/navi-query/v2/poi"
  val tableName = "dm_gis.adds_dispatch_shunt_detail" //生产数据表
  val saveTableName = "dm_gis.adds_dispatch_shunt_di"

  val   reg =".*114.*|.*214.*|.*314.*|.*414.*|.*514.*|.*115.*|.*215.*|.*315.*|.*415.*|.*515.*|.*615.*|" +
    ".*116.*|.*216.*|.*316.*|.*416.*|.*516.*|.*117.*|.*217.*|.*317.*|.*417.*|.*517.*"

  val reg1=".*村.*|.*工业园.*|.*创业园.*|.*小区.*|.*组.*|.*学校.*|.*学院.*|.*大学.*|.*小学.*|.*中学.*|.*校区.*|.*厂.*|.*科技园.*|.*物流园.*"
  val reg2=".*[\\d](期|区|座).*|.*[a-zA-Z](期|区|座).*"

  case class result(
                     datetime:String
                     ,`type`:String
                     ,sn:String
                     ,ak:String
                     ,address:String
                     ,citycode:String
                     ,waybillno:String
                     ,time:String
                     ,src:String
                     ,status:String
                     ,iselevator:String
                     ,isclimb:String
                     ,floor:String
                     ,err:String
                     ,msg:String
                     ,message:String
                     ,log:String
                     ,group_id:String
                     ,aoi_id:String
                     ,tag:String
                     ,tag2:String
                     ,tag3:String
                     ,first13:String
                     ,last13:String
                     ,result:String
                     ,aoiName:String
                     ,aoiTypeCode:String
                     ,similarity:String
                     ,similarity_poi:String
                     ,detail:String
  )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)

    logger.error("起始时间:" + startDay)
    start(startDay)
    logger.error("结束所有运行")

  }

  //  $[time(yyyyMM)]
  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataRdd: RDD[JSONObject] = getDataDf(spark, incDay)
    logger.error("调用派件上楼服务接口")
    val (noClimbRdd, climbRdd_1, climbRdd_2, climbRdd_3) = runDispatchInteface(dataRdd)
    logger.error("对Is_climb=1，-1的数据打标签")


   val saveRddTmp =  getTag(climbRdd_1, climbRdd_2)

  val saveRdd =   saveRddTmp.union(noClimbRdd).union(climbRdd_3)
    logger.error("指标计算并入库")
    //入库
    saveTable(spark, saveRdd, incDay)
    logger.error("解析表入库完毕")


  }


  def runDispatchInteface(dataRdd: RDD[JSONObject]) = {

    logger.error("筛选Is_climb=0的数据打标签")

    val noClimbRdd = dataRdd.filter(o => JSONUtil.getJsonVal(o, "isclimb", "").equals("0"))
      .map(o => {
        val tag2 = ""
        o.put("tag1", "不爬楼")
        val is_elevator = JSONUtil.getJsonVal(o, "iselevator", "")
        is_elevator match {
          case "0" => o.put("tag2", "无电梯1楼")
          case "1" => o.put("tag2", "有电梯不爬楼")
          case "-1" => o.put("tag2", "floor&aoitype")
          case "" => o.put("tag2", "特殊配置")
          case _ => o.put("tag2", is_elevator)
        }
        o
      }).persist(StorageLevel.MEMORY_AND_DISK)


    logger.error("isclimb!=0的数据跑接口")
    val climbRdd = dataRdd.filter(o => !JSONUtil.getJsonVal(o, "isclimb", "").equals("0")).repartition(1).map(o => {
      val address = JSONUtil.getJsonVal(o, "address", "")
      val citycode = JSONUtil.getJsonVal(o, "citycode", "")
      var reqObject: JSONObject = null
      if (address.nonEmpty || citycode.nonEmpty) {
        val formatUrl = String.format(dispatch_url, URLEncoder.encode(address, "utf-8"), citycode)
        o.put("dispatchUrl", formatUrl)
        reqObject = HttpClientUtil.getJsonByGet(formatUrl)
//        println("url===>"+formatUrl)
//        Thread.sleep(2000);
      }
      o.put("dispatchReq", reqObject)

      if (reqObject != null) {
        val splitResult = JSONUtil.getJsonVal(reqObject, "result.detail.splitResult", "")
        val aoiTypeCode = JSONUtil.getJsonVal(reqObject, "result.detail.aoiTypeCode", "")
        val aoiName = JSONUtil.getJsonVal(reqObject, "result.detail.aoiName", "")
        o.put("splitResult", splitResult)
        o.put("aoiTypeCode", aoiTypeCode)
        o.put("aoiName", aoiName)
      }
      o
    }).repartition(200).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("Is_climb=0的数据量:" + noClimbRdd.count())
    logger.error("Is_climb！=0的数据量" + climbRdd.count())

    val climbRdd_1 = climbRdd.filter(o => JSONUtil.getJsonVal(o, "isclimb", "").equals("1")).persist(StorageLevel.MEMORY_AND_DISK)
    val climbRdd_2 = climbRdd.filter(o => JSONUtil.getJsonVal(o, "isclimb", "").equals("-1")).persist(StorageLevel.MEMORY_AND_DISK)
    val climbRdd_3 = climbRdd.filter(o => !"1,-1".split(",").contains(JSONUtil.getJsonVal(o, "isclimb", ""))).persist(StorageLevel.MEMORY_AND_DISK)
    climbRdd.unpersist()

    logger.error("Is_climb=1的数据量:" + climbRdd_1.count())
    logger.error("Is_climb=-1的数据量" + climbRdd_2.count())
    logger.error("Is_climb!=1,-1的数据量" + climbRdd_3.count())
    (noClimbRdd, climbRdd_1, climbRdd_2, climbRdd_3)
  }

  def getTag(climbRdd_1: RDD[JSONObject], climbRdd_2: RDD[JSONObject]) = {

    val climbRdd_1_tmp = climbRdd_1.map(o => {
      o.put("tag1", "爬楼")
      val Is_elevtor = JSONUtil.getJsonVal(o, "iselevator", "")
      //50默认值，判断空的打tag
      val floor = try{JSONUtil.getJsonVal(o, "floor", "").toInt}catch {case exception: Exception =>50}
      if (!Is_elevtor.equals("0")) {
        o.put("tag2", "特殊配置")
      } else if (floor == 0 || floor > 100) {
        o.put("tag2", "无楼层爬楼")
      } else o.put("tag2", "有楼层爬楼")
      o
    })

    logger.error("处理Is_climb=-1的数据打tag2")
    val climbRdd_2_tmp = climbRdd_2.map(o => {
      o.put("tag1", "未识别")
      val splitResult = JSONUtil.getJsonVal(o, "splitResult", "")
      val grouid = JSONUtil.getJsonVal(o, "group_id", "")
      //50默认值，判断空的打tag
      val floor = try{JSONUtil.getJsonVal(o, "floor", "").toInt}catch {case exception: Exception =>50}
      val aoiid = JSONUtil.getJsonVal(o, "aoi_id", "")
      val cj = try {
        splitResult.split(";")(1).toInt
      } catch {
        case exception: Exception => 0
      }
      o.put("cj", cj)
      if (cj < 11) {
        o.put("tag2", "地址无9+11")
      } else if (grouid.isEmpty && aoiid.isEmpty) {
        o.put("tag2", "无aoi和group")
      } else if (floor == 0 || floor > 100) {
        o.put("tag2", "有group或aoi且无楼层电梯属性未知")
      } else o.put("tag2", "有group或aoi且有楼层电梯属性未知")
      o
    })

    val climbRdd = climbRdd_1_tmp.union(climbRdd_2_tmp).map(o => {

      val tag2 = JSONUtil.getJsonVal(o, "tag2", "")
      if (tag2.equals("无楼层爬楼") || tag2.equals("有group或aoi且无楼层电梯属性未知")) {

        val splitResult = JSONUtil.getJsonVal(o, "splitResult", "")
        val aoiName = JSONUtil.getJsonVal(o, "aoiName", "")
        val (first13, last13) = getSplitresult(splitResult)
        //对address对应的first13和aoiName中文数字转阿拉伯、大写字母转小写字母
        val formatFirst13 = chToNum(first13).toLowerCase
        val formatLast13 = chToNum(last13).toLowerCase
        val formataoiName = chToNum(aoiName).toLowerCase
        o.put("first13", first13)
        o.put("last13", last13)
        o.put("formatFirst13", formatFirst13)
        o.put("formataoiName", formataoiName)
        o.put("formatLast13", formatLast13)
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("處理完tag2的數據量：" + climbRdd.count())
    logger.error("开始调相似度接口" + climbRdd.count())


    val similaritRdd = climbRdd.repartition(20).map(o => {
      val splitResult = JSONUtil.getJsonVal(o, "splitResult", "")
      val tag2 = JSONUtil.getJsonVal(o, "tag2", "")
      var result = 0.0
      if (tag2.equals("无楼层爬楼") || tag2.equals("有group或aoi且无楼层电梯属性未知")) {
        val formatFirst13 = JSONUtil.getJsonVal(o, "formatFirst13", "")
        val formataoiName = JSONUtil.getJsonVal(o, "formataoiName", "")
        val aoiTypeCode = JSONUtil.getJsonVal(o, "aoiTypeCode", "")
        val address = JSONUtil.getJsonVal(o, "address", "")

        val limitMin = 6000/20
        var cnt = 0
        var startTime = System.currentTimeMillis()

        // 1、若last13包含村|工业园|创业园|小区|组|学校|学院|大学|小学|中学|校区|厂|科技园|物流园，则similarity=1
        // 2、若last13包含数字+期/区/座或字母+期/区/苑，则similarity=1
        if(formatFirst13.matches(reg1)||formatFirst13.matches(reg2)){
          result=1
        }else{


          if (cnt == limitMin) {
            val endTime = System.currentTimeMillis() - startTime
            if( endTime <= 60 * 1000 ){
              logger.error(s"每分钟访问量超过限制$limitMin,休眠${60*1000 - endTime }ms中")
              Thread.sleep(60*1000 - endTime )
            }
            startTime = System.currentTimeMillis()
            cnt = 0
          }


          val formatUrl = String.format(similarit_url, formatFirst13, formataoiName)
          val reqObject = HttpClientUtil.getJsonByGet(formatUrl)

          if (reqObject != null) {
            o.put("similaritReq", reqObject)
            result = try{reqObject.getDoubleValue("result")}catch {case exception: Exception => 0.0}
          }
        }

        o.put("similarity", result+"")
        if (result >= 0.8) o.put("tag3", "big_poi")
        else if (splitResult.matches(reg)) o.put("tag3", "无法确定")
        else if (aoiTypeCode.equals("120302") || aoiTypeCode.equals("120305")) o.put("tag4", "gd_tag")
        else o.put("tag3", "无法确定")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("跑完相似度接口:" + similaritRdd.count())

    val gdRunRdd = similaritRdd.filter(o => JSONUtil.getJsonVal(o, "tag4", "").equals("gd_tag"))
    val gdUnoinRdd = similaritRdd.filter(o => !JSONUtil.getJsonVal(o, "tag4", "").equals("gd_tag"))

    logger.error("需要跑高德接口判断数据的数据量:" + gdRunRdd.count())
    logger.error("不需要跑高德接口判断数据的数据量:" + gdUnoinRdd.count())
    similaritRdd.unpersist()

    logger.error("开始调高德接口")
    val gdRdd = gdRunRdd.repartition(20).map(o => {
      var resuletStr = ""
      var types = ""
      var name = ""
      val address = JSONUtil.getJsonVal(o, "address", "")
      val citycode = JSONUtil.getJsonVal(o, "citycode", "")
      val json= new JSONObject()
      json.put("keywords",address)
      json.put("city",citycode)
      json.put("extensions","all")
      json.put("pageSize",10)
      json.put("pageCount",1)
      val des  =new DesUtils()
      val req = des.encrypt(json.toJSONString,"utf-8")
      val param= new JSONObject()
      param.put("ak","ae9c0205b5834a8da2cd362f1fe3d713")
      param.put("param",req)
      val limitMin = 6000/20
      var cnt = 0
      var startTime = System.currentTimeMillis()

      val res = HttpInvokeUtil.postGetByte(gd_url, param,3)

      if (res != null) {
        var unzipRes: String = null
        val unEncryptStr = new String(res, "utf-8")
        if (!unEncryptStr.contains("status")) {
          unzipRes = new String(GzipUtils.uncompress(new DesUtils().decryptByte(res)), "UTF-8")
        } else {
          //ak的日志是明文的
          logger.error(unEncryptStr)
          unzipRes = unEncryptStr
        }
        val data = try {
          JSON.parseObject(unzipRes)
        } catch {
          case exception: Exception => null
        }
        o.put("gdReq", data.toString)
        Thread.sleep(10000)

        if (data != null) {
          val poi = try {
            JSONUtil.getJsonArrayFromObject(data, "result.pois").getJSONObject(0)
          } catch {
            case _ => new JSONObject()
          }
          name = JSONUtil.getJsonVal(poi, "name", "xx")
          val typecode = JSONUtil.getJsonVal(poi, "typeCode", "xx")
          types = JSONUtil.getJsonVal(poi, "type", "xx")
          val location = JSONUtil.getJsonVal(poi, "location", "xx")
          val xyArray = location.split(",")
          var x = "xx"
          var y = "xx"
          if (xyArray.size > 1) {
            x = xyArray(0)
            y = xyArray(1)
          }
          resuletStr = s"""${name}_${typecode}_${types}_${x}_${y}"""
        }
        o.put("types", types)
        o.put("result", resuletStr)
      }


      val typesSplit = try {
        types.split(";")(0)
      } catch {
        case exception: Exception => ""
      }

      if (types.equals("生活服务;美容美发店;美容美发店")
        || (typesSplit.equals("购物服务") && !types.equals("购物服务;综合市场;综合市场") && !types.equals("购物服务;家居建材市场;家具城"))
        || typesSplit.equals("汽车服务")
        || typesSplit.equals("餐饮服务")
        || types.equals("医疗保健服务;诊所;诊所")
        || types.equals("医疗保健服务;医药保健销售店;医疗保健用品")) {


        var similarity_poi = 0.0
        //调相似度接口判断相似度
        val formatLast13 = JSONUtil.getJsonVal(o, "formatLast13", "")
        val formatName = chToNum(name).toLowerCase
        o.put("formatName", formatName)


        if (cnt == limitMin) {
          val endTime = System.currentTimeMillis() - startTime
          if( endTime <= 60 * 1000 ){
            logger.error(s"每分钟访问量超过限制$limitMin,休眠${60*1000 - endTime }ms中")
            Thread.sleep(60*1000 - endTime )
          }
          startTime = System.currentTimeMillis()
          cnt = 0
        }




        val formatUrl = String.format(similarit_url, formatLast13, formatName)
        val reqObject = HttpClientUtil.getJsonByGet(formatUrl)
        if (reqObject != null) {
          o.put("similaritLast13Req", reqObject)
          similarity_poi = try{reqObject.getDoubleValue("result")}catch {case exception: Exception => 0.0}
        }


        o.put("similarity_poi", similarity_poi+"")
        if (similarity_poi > 0.3) o.put("tag3", "商铺") else o.put("tag3", "无法确定")
        o
      }
      else {
        o.put("tag3", "无法确定")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("跑完高德接口的数据量："+gdRdd.count())

    val reRdd = gdUnoinRdd.union(gdRdd)
    reRdd
  }


  //入库
  def saveTable(spark: SparkSession, saveRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._


    //明细表入库
    val rowDf = saveRdd.map(_.toJSONString.replaceAll("[\r\n\t]+", "")).toDF()

    logger.error("入明细表数量：" + rowDf.count())


    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

    val reDf = saveRdd.map(o => {
      result(
        JSONUtil.getJsonVal(o, "datetime", ""),
        JSONUtil.getJsonVal(o, "type", ""),
        JSONUtil.getJsonVal(o, "sn", ""),
        JSONUtil.getJsonVal(o, "ak", ""),
        JSONUtil.getJsonVal(o, "address", ""),
        JSONUtil.getJsonVal(o, "citycode", ""),
        JSONUtil.getJsonVal(o, "waybillno", ""),
        JSONUtil.getJsonVal(o, "time", ""),
        JSONUtil.getJsonVal(o, "src", ""),
        JSONUtil.getJsonVal(o, "status", ""),
        JSONUtil.getJsonVal(o, "iselevator", ""),
        JSONUtil.getJsonVal(o, "isclimb", ""),
        JSONUtil.getJsonVal(o, "floor", ""),
        JSONUtil.getJsonVal(o, "err", ""),
        JSONUtil.getJsonVal(o, "msg", ""),
        JSONUtil.getJsonVal(o, "message", ""),
        JSONUtil.getJsonVal(o, "log", ""),
        JSONUtil.getJsonVal(o, "group_id", ""),
        JSONUtil.getJsonVal(o, "aoi_id", ""),
        JSONUtil.getJsonVal(o, "tag1", ""),
        JSONUtil.getJsonVal(o, "tag2", ""),
        JSONUtil.getJsonVal(o, "tag3", ""),
        JSONUtil.getJsonVal(o, "first13", ""),
        JSONUtil.getJsonVal(o, "last13", ""),
        JSONUtil.getJsonVal(o, "result", ""),
        JSONUtil.getJsonVal(o, "aoiName", ""),
        JSONUtil.getJsonVal(o, "aoiTypeCode", ""),
        JSONUtil.getJsonVal(o, "similarity", ""),
        JSONUtil.getJsonVal(o, "similarity_poi", ""),
        o.toJSONString.replaceAll("[\r\n\t]+", "")
      )
    }).toDF()
    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(saveTableName)

  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      s"""
         |select
         |datetime
         |,type
         |,sn
         |,ak
         |,address
         |,citycode
         |,waybillno
         |,time
         |,src
         |,status
         |,iselevator
         |,isclimb
         |,floor
         |,err
         |,msg
         |,message
         |,log
         |,group_id
         |,aoi_id
         |,inc_day
         | from dm_gis.adds_log_kafka_elev_analysis where  inc_day = '${incDay}' and ak = 'a4f3c06085e64df18d1aedfa4dcebe35'
      """.stripMargin

    logger.error(totalDfSql)
    val totalRdd = SparkUtils.getRowToJson(spark, totalDfSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }


  //根据词条获取
//  def getSplitresult(splitStr: String) = {
//    val spStrArray = try{splitStr.split(";")(0).split(",")}catch {case exception: Exception=>new Array[String](0)}
//    var reStr = ""
//    var last13 = ""
//    val formatLevel = "113,213,313,413,513,713,813".split(",")
//    for (i <- 0 until spStrArray.size) {
//      val str = spStrArray(i).split("\\^")
//      if (str.size > 0 && formatLevel.contains(str(1))) {
//        reStr = str(0)
//      } else if (str(1).equals("613")) reStr += str(0)
//    }
//    //倒序遍历splitResult取第一个包含'13'的词级为last13（实例：splitresult=江苏省^11,淮安市^12,清江浦区^13,柳树湾街道^15,益兴名流花苑^113,1期^613,9栋^214,608^217；则last13=1期）
//    spStrArray.reverse.map(o => {
//      val str = o.split("\\^")
//      if (last13.isEmpty && str(1).contains("13")) last13 = str(0)
//    })
//    (reStr, last13)
//  }
  def getSplitresult(splitStr: String) = {
    val spStrArray = try{splitStr.split(";")(0).split(",")}catch {case exception: Exception=>new Array[String](0)}
    var reStr = ""
    var last13 = ""
    val formatLevel = "113,213,313,413,513,713,813".split(",")
    for (i <- 0 until spStrArray.size) {
      val str = spStrArray(i).split("\\^")
      if (str.size > 1 && formatLevel.contains(str(1))) {
        reStr = str(0)
      } else if (str.size > 1 && str(1).equals("613")) reStr += str(0)
    }
    //倒序遍历splitResult取第一个包含'13'的词级为last13（实例：splitresult=江苏省^11,淮安市^12,清江浦区^13,柳树湾街道^15,益兴名流花苑^113,1期^613,9栋^214,608^217；则last13=1期）
    spStrArray.reverse.map(o => {
      val str = o.split("\\^")
      if (str.size > 1 && last13.isEmpty && str(1).contains("13")) last13 = str(0)
    })
    (reStr, last13)
  }


  /**
    * 中文转数字
    *
    * @param orginal
    * @return
    */
  def chToNum(orginal: String) = {
    val p0 = """(一|二|三|四|五|六|七|八|九)百(一|二|三|四|五|六|七|八|九)十(一|二|三|四|五|六|七|八|九)""".r
    val p1 = """(一|二|三|四|五|六|七|八|九)百(一|二|三|四|五|六|七|八|九)十?""".r
    val p2 = """(一|二|三|四|五|六|七|八|九)百""".r
    val p3 = """(一|二|三|四|五|六|七|八|九)十(一|二|三|四|五|六|七|八|九)""".r
    val p4 = """(一|二|三|四|五|六|七|八|九)十""".r
    val p5 = """(一|二|三|四|五|六|七|八|九|零)""".r

    val mapping = Map("一" -> 1, "二" -> 2, "三" -> 3, "四" -> 4, "五" -> 5, "六" -> 6, "七" -> 7, "八" -> 8, "九" -> 9, "零" -> 0)
    var text = orginal
    text = p0.replaceAllIn(text, matchs => {
      mapping(matchs.group(1)) * 100 + mapping(matchs.group(2)) * 10 + mapping(matchs.group(3)) + ""
    })
    text = p1.replaceAllIn(text, matchs => {
      mapping(matchs.group(1)) * 100 + mapping(matchs.group(2)) * 10 + ""
    })
    text = p2.replaceAllIn(text, matchs => {
      mapping(matchs.group(1)) * 100 + ""
    })
    text = p3.replaceAllIn(text, matchs => {
      mapping(matchs.group(1)) * 10 + mapping(matchs.group(2)) + ""
    })
    text = p4.replaceAllIn(text, matchs => {
      mapping(matchs.group(1)) * 10 + ""
    })
    text = p5.replaceAllIn(text, matchs => {
      mapping(matchs.group(1)) + ""
    })

    text
  }

}
