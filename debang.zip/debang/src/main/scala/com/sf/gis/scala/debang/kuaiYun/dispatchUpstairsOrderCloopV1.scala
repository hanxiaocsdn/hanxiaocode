package com.sf.gis.scala.debang.kuaiYun

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.{DateUtil, Util}
import com.sf.gis.scala.debang.util.{JSONUtil, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * create by 01412406
  * 【派件上楼】下单环节数据闭环工艺
  * id：
  * 负责人：李嘉欣(01412989)
  */



object dispatchUpstairsOrderCloopV1 {
  @transient lazy val logger: Logger = Logger.getLogger(dispatchUpstairsOrderCloopV1.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  case class result(
                     addr:String
                     ,dest_dist_code:String
                     ,group_id:String
                     ,aoi_id:String
                     ,src:String
                     ,iselevator:String
                     ,isclimb:String
                     ,message:String
                     ,service_fee:String
                     ,xg_id:String
                     ,zno_code:String
                     ,addr_ele:String
                     ,aoi_ele:String
                     ,bu_tag:String

  )

  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    val lastDay = args.apply(1)
    logger.error("起始时间:" + startDay+s" 上个月时间：${lastDay}")
    start(startDay,lastDay)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String,lastDay:String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay,lastDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String,lastDay:String) = {
    logger.error("获取数据源")
    //取数据源
    val (dataRdd, xgRdd) = getData(spark, incDay,lastDay)
    logger.error("获取业务数据")
    val (groupData,aoiData) = getBusinessData(spark,incDay)


    //判断src是否包含'group'

    val groupRdd = dataRdd.filter(o => JSONUtil.getJsonVal(o, "src", "").contains("group")).persist(StorageLevel.MEMORY_AND_DISK)
    val ungroupRdd = dataRdd.filter(o => !JSONUtil.getJsonVal(o, "src", "").contains("group")).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("src是否包含'group'的数据量："+groupRdd.count())
    logger.error("src不包含'group'的数据量："+ungroupRdd.count())


    logger.error("剔除业务数据")
    val reGroupRdd = groupRdd.map(o=>(JSONUtil.getJsonVal(o,"group_id",""),o)).leftOuterJoin(groupData).filter(_._2._2.isEmpty).map(_._2._1)
    val reUnGroupRdd= ungroupRdd.map(o=>(JSONUtil.getJsonVal(o,"aoi_id",""),o)).leftOuterJoin(aoiData).filter(_._2._2.isEmpty).map(_._2._1)

    logger.error("剔除group_id后的数据量："+reGroupRdd.count())
    logger.error("剔除aoi_id后的数据量："+reUnGroupRdd.count())

    logger.error("关联取小哥工号")
  val reRdd =   reGroupRdd.union(reUnGroupRdd).map(o=>(JSONUtil.getJsonVal(o,"aoi_id",""),o))
        .leftOuterJoin(xgRdd).map(o=>{
      val left  = o._2._1
      if(o._2._2.nonEmpty) left.put("xg_id",o._2._2.get)
      left
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("最终关联完的数据量："+reRdd.count())
    logger.error("开始入库")
    saveTable(spark, reRdd, incDay)
    logger.error("结束所有运行")

  }


  //入库
  def saveTable(spark: SparkSession, reRdd: RDD[JSONObject], incDay: String): Unit = {
    //明细表入库
    logger.error("入汇总表数量：" + reRdd.count())
    import spark.implicits._
   val saveRdd =  reRdd.map(o=>{
      val addr = JSONUtil.getJsonVal(o,"addr","")
      val dest_dist_code = JSONUtil.getJsonVal(o,"dest_dist_code","")
      val group_id = JSONUtil.getJsonVal(o,"group_id","")
      val aoi_id = JSONUtil.getJsonVal(o,"aoi_id","")
      val src = JSONUtil.getJsonVal(o,"src","")
      val iselevator = JSONUtil.getJsonVal(o,"iselevator","")
      val isclimb = JSONUtil.getJsonVal(o,"isclimb","")
      val message = JSONUtil.getJsonVal(o,"message","")
      val service_fee = JSONUtil.getJsonVal(o,"service_fee","")
      val zno_code = JSONUtil.getJsonVal(o,"zno_code","")
      val xg_id = JSONUtil.getJsonVal(o,"xg_id","")
      result(
          addr
          ,dest_dist_code
          ,group_id
          ,aoi_id
          ,src
          ,iselevator
          ,isclimb
          ,message
          ,service_fee
          ,xg_id
          ,zno_code
          ,""
          ,""
          ,""
      )
    }).toDF

    val tableName = "dm_gis.aoiele_operate_addedvalue" //生产数据表
    logger.error(tableName+"=========>"+incDay)
    saveRdd.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

  }

  //获取数据
  def getData(spark: SparkSession, incDay: String,lastDay:String) = {


    val beforeDay = DateUtil.getDateStr(incDay, -45)
    val last15Day = DateUtil.getDateStr(incDay, -15)
    val last13Day = DateUtil.getDateStr(incDay, -13)
    val last1Day = DateUtil.getDateStr(incDay, -1)

    //基本数据
    val baseSql =
      """
        |select
        | get_json_object(a.message, "$.data.result.query.address") as addr,
        | a.dest_dist_code,
        | a.group_id,
        | a.aoi_id,
        | a.src,
        | a.iselevator,
        | a.isclimb,
        | a.message,
        | a.service_fee,
        | b.zno_code
        |from dm_gis.IN45_waybill a
        |left join (
        |select
        |zno_code
        |,aoi_id
        |from dm_gis.cms_aoi_sch
        |group by
        |zno_code
        |,aoi_id
        |)b
        |on a.aoi_id=b.aoi_id
        |left join (
        |select
        |addr
        |from dm_gis.aoiele_operate_addedvalue
        |where inc_day = '%s'
        |group by
        |addr
        |)c
        |on get_json_object(a.message, "$.data.result.query.address") = c.addr
        |where src != 'floor' and
        |aoitypecode in ('120302', '120301', '120305', '120203')
        |and ((isclimb in ('-1','0') and service_fee is not null and service_fee <> '')
        |or (isclimb ='1' and (service_fee is null or service_fee = '')))
        |and c.addr is null
        |and inc_day between '%s' and '%s'
      """.stripMargin
    val bSql = String.format(baseSql, lastDay, beforeDay, last15Day)


    logger.error("tmp====>" + bSql)


    val totalRdd = SparkUtils.getRowToJson(spark, bSql)

    logger.error("获取到的数据量：" + totalRdd.count())


    logger.error("取小哥id数据")

    val xgSql =
      s"""
         |    select
         |      guid,
         |      loginid
         |    from
         |      dm_tc_waybillinfo.schedule_width_data
         |    where
         |      inc_day between '${last13Day}' and '${last1Day}'
         |	  group by guid,loginid
      """.stripMargin
    logger.error(xgSql)

    val xgRdd = SparkUtils.getRowToJson(spark, xgSql).map(o => (JSONUtil.getJsonVal(o, "guid", ""), JSONUtil.getJsonVal(o, "loginid", "")))
        .groupByKey().map(o=>{
      val guid = o._1
      val xgidList = o._2.toList
      val reList = xgidList.take(4).sorted.mkString("|")
      (guid,reList)
    })

    logger.error("获取到小哥id的数据量：" + xgRdd.count())
    (totalRdd, xgRdd)
  }
  //获取业务数据
  def getBusinessData(spark: SparkSession, incDay: String) = {



    //基本数据
    val baseSql =
      """
        |select
        |group_id
        |,aoi_id
        |from dm_gis.aoiele_operate_addedvalue
        |where bu_tag is not null or bu_tag <>''
        |group by
        |group_id
        |,aoi_id
      """.stripMargin

    logger.error("tmp====>" + baseSql)

    val groupRdd = SparkUtils.getRowToJson(spark, baseSql).map(o=>(JSONUtil.getJsonVal(o,"group_id",""),false)).filter(_._1.nonEmpty)
    val aoiRdd = SparkUtils.getRowToJson(spark, baseSql).map(o=>(JSONUtil.getJsonVal(o,"aoi_id",""),false)).filter(_._1.nonEmpty)
    logger.error("取到group_id业务数据量"+groupRdd.count())
    logger.error("取到aoi_id业务数据量"+aoiRdd.count())
    (groupRdd,aoiRdd)
  }

}
