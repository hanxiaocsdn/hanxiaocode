package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.debang.util._
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object kuaiYunReceive {
  @transient lazy val logger: Logger = Logger.getLogger(kuaiYunReceive.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  //接口
  val runTcUrl = "http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=%s&lat=%s&ak=1245f89114fb4f5e896213904b4923a5"
  //  【入参】：【gd_x】和【mapa_x】传入【lng】，【gd_y】和【mapa_y】传入【lat】
  //  【出参】：【level】=3下的【code】记为【gd_tc】和【mapa_tc】
  val mapa_url = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=ma1&ak=1245f89114fb4f5e896213904b4923a5"
  val ts_url = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=gd2&ak=1245f89114fb4f5e896213904b4923a5"


  case class result(
                     cityCode: String
                     , city:String
                     , region:String
                     , adressEmptyCnt: Int
                     , unidentifiedCnt: Int
                     , rangeOutCnt: Int
                     , recognitionCnt: Int
                     , pbYwCnt: Int
                     , pbFlaseCnt: Int
                     , bgYwCnt: Int
                     , bgFlaseCnt: Int
                     , empcodeEmptyCnt: Int
                     , xgYwCnt: Int
                     , unitCodeEmptyCnt: Int
                     , empFlaseCnt: Int
                     , pbSyCnt:Int
                     , bgSyCnt:Int
                     , xgSyCnt:Int
                     , pb54Cnt:Int  = 0
                     , bg54Cnt:Int  = 0
                     , xg54Cnt:Int  = 0
                   )





  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

//  startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val formatDay = startDay.replaceAll("-", "")//20210823
    val formatDay1 = DateUtil.getDateStr(startDay, 1, "-")//2021-08-24
    val formatDay3 = DateUtil.getDateStr(startDay, -1, "-")//2021-08-22


//        for (i <- 0 until days) {
    val sepDay = DateUtil.getDateStr(formatDay, 0, "") //20210823
    val T1Day = DateUtil.getDateStr(formatDay, 1, "")   //20210824
    val T4Day = DateUtil.getDateStr(formatDay, -2, "")  //20210821
    val T3Day = DateUtil.getDateStr(formatDay, -1, "")  //20210822
    val incDay = sepDay.replaceAll("-", "")         //t-2

    logger.error("开始计算：" + incDay+"&&formatDay1:"+formatDay1+"&&formatDay3:"+formatDay3)
    startSta(spark, incDay, sepDay,T1Day,T3Day,T4Day,formatDay1,formatDay3)
    logger.error("计算结束：" + incDay)
//        }
    logger.error("统计完毕")
  }



  def startSta(spark: SparkSession, incDay: String, sepDay: String,T1Day:String,T3Day:String,T4Day:String,formatDay1:String,formatDay3:String) = {

    logger.error("获取数据源")
    //取数据源
    val dataRdd = getDataDf(spark,incDay,sepDay,T1Day,T3Day,T4Day,formatDay1,formatDay3)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("打tag标签")
    //打tag
    val tagRdd = checkTag(dataRdd)
    logger.error(tagRdd.take(10).foreach(println(_)))
    logger.error("打tag2标签")
    //打tag2
    val checkRdd = checkTag2(tagRdd)
    logger.error(checkRdd.take(10).foreach(println(_)))

    logger.error("获取城市映射表")
    val cityMap= queryCityMap(spark)


    logger.error("开始汇总")
    //汇总
    val staIndexRdd = staIndex(checkRdd,cityMap)
    logger.error("开始入库")
    //入库
    saveTable(spark,staIndexRdd,checkRdd,incDay)
    logger.error("结束所有运行")

  }


  def checkTag(dataRdd: RDD[JSONObject]) = {
    logger.error("打tag的数据量：" + dataRdd.count())
    val tagResult1Rdd = dataRdd.map(obj => {
      val address = JSONUtil.getJsonVal(obj, "address", "")
      val data_type = JSONUtil.getJsonVal(obj, "data_type", "")
      val task_status = JSONUtil.getJsonVal(obj, "task_status", "")

      if (!address.isEmpty) {
        if (data_type.equals("1")) {

          task_status match {
            case "2" => obj.put("tag", "unidentified")
            case "4" => obj.put("tag", "range_out")
            case _ => obj.put("tag", "recognition")
          }
        } else {
          //识别总量
          obj.put("tag", "recognition")
        }
      } else obj.put("tag", "address_empty")
      obj
    }

    ).persist(StorageLevel.MEMORY_AND_DISK)
    val tagRdd = tagResult1Rdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "", "").isEmpty()
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val NotagRdd = tagResult1Rdd.filter(obj => {
      !JSONUtil.getJsonVal(obj, "", "").isEmpty()
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("tag有值的数据量：" + tagRdd.count())
    logger.error("未打上tag的数据量：" + NotagRdd.count())

    tagRdd.unpersist()
    NotagRdd.unpersist()
    tagResult1Rdd
  }


  def checkTag2(dataRdd: RDD[JSONObject]) = {

    logger.error("打tag2的数量："+dataRdd.count())
    logger.error(dataRdd.take(10).foreach(println(_)))


     val nexteRdd =  dataRdd.filter(obj=>{JSONUtil.getJsonVal(obj,"tag","").equals("recognition")}).persist(StorageLevel.MEMORY_AND_DISK)
     val UnionRdd =  dataRdd.filter(obj=>{!JSONUtil.getJsonVal(obj,"tag","").equals("recognition")}).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("tag是recognition的数量："+nexteRdd.count())
    logger.error("tag不是recognition的数量："+UnionRdd.count())

    val result1 = nexteRdd.map(obj => {
      val data_type = JSONUtil.getJsonVal(obj, "data_type", "")
      val teamid = JSONUtil.getJsonVal(obj, "teamid", "")
      val old_teamid = JSONUtil.getJsonVal(obj, "old_teamid", "")
      val transfor_emp = JSONUtil.getJsonVal(obj, "transfor_emp", "")
      val employee_code = JSONUtil.getJsonVal(obj, "employee_code", "")
      val responsible = JSONUtil.getJsonVal(obj, "responsible", "")

      if (data_type.equals("2")) {
        //        teamid与old_teamid是否一致？
        if (!(teamid.nonEmpty  && teamid.equals(old_teamid))) {
          if (transfor_emp.equals("2")) obj.put("tag2", "pb_yw") else obj.put("tag2", "pb_false")
        } else {
          obj.put("emp_tag", "1")
        }
      } else {
        obj.put("emp_tag", "1")
      }

      if (JSONUtil.getJsonVal(obj, "emp_tag", "").equals("1") && !transfor_emp.equals("1") && !transfor_emp.equals("2") ) {
        if (!employee_code.isEmpty && employee_code.equals(transfor_emp)) obj.put("tag2", "bg_yw")
        else if (responsible.equals("3")) obj.put("tag2", "bg_yw")
        else obj.put("tag2", "bg_false")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)


logger.error("next的数据量："+    result1.filter(obj => {
  JSONUtil.getJsonVal(obj, "emp_tag", "").equals("1")
}).persist(StorageLevel.MEMORY_AND_DISK).take(10).foreach(println(_)))





    val nextRdd1 = result1.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("判断emp_code的数量:" + nextRdd1.count())


    val UnionRdd1 = result1.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("确定的数量:" + UnionRdd1.count())


    val result2 = nextRdd1.map(obj => {
      val emp_code = JSONUtil.getJsonVal(obj, "emp_code", "")
      if (emp_code.isEmpty) {
        obj.put("tag2", "empcode_empty")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val UnionRdd2 = result2.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("emp_code是空的数量:" + UnionRdd2.count())
    val nextRdd2 = result2.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("判断emp_code与pickup_emp_code的数量:" + nextRdd2.count())

    val result3 = nextRdd2.map(obj => {
      val emp_code = JSONUtil.getJsonVal(obj, "emp_code", "")
      val pickup_emp_code = JSONUtil.getJsonVal(obj, "pickup_emp_code", "")
      if (!emp_code.isEmpty && emp_code.equals(pickup_emp_code)) {
        obj.put("tag2", "xg_yw")
      }
      obj
    })

    val UnionRdd3 = result3.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("emp_code与pickup_emp_code一致的数量:" + UnionRdd3.count())
    val nextRdd3 = result3.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("判断unit_code_list为空的数量:" + nextRdd3.count())


    val result4 = nextRdd3.map(obj => {
      if (JSONUtil.getJsonVal(obj, "unit_code_list", "").isEmpty) obj.put("tag2", "unit_code_empty")
      obj
    })
    val UnionRdd4 = result4.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("unit_code_list为空的数量:" + UnionRdd4.count())
    val nextRdd4 = result4.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("判断unit_code_list包含teamCode" + nextRdd4.count())


    val result5 = nextRdd4.map(obj => {
      val unit_code_list = JSONUtil.getJsonVal(obj, "unit_code_list", "")
      //改
      val teamCode = JSONUtil.getJsonVal(obj, "unit_code", "")
//      val teamCode = JSONUtil.getJsonVal(obj, "teamCode", "")
      if (unit_code_list.split(",").contains(teamCode)) obj.put("tag2", "xg_yw")
          else obj.put("tag2", "emp_false")
      obj
    })


    val UnionRdd5 = result5.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").equals("xg_yw")
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("unit_code_list包含teamCode的数量:" + UnionRdd5.count())
    val nextRdd5: RDD[JSONObject] = result5.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").equals("emp_false")
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("unit_code_list不包含teamCode的数量:" + nextRdd5.count())



    val runUrlRdd = result5.union(UnionRdd1).union(UnionRdd2).union(UnionRdd3).union(UnionRdd4).union(UnionRdd).persist(StorageLevel.MEMORY_AND_DISK)




    //调Mapa跟图商
    val re = getTc(runUrlRdd)
    logger.error("pb_sy:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("pb_sy")
    }).count())
    logger.error("bg_sy:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("bg_sy")
    }).count())
    logger.error("xg_sy:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("xg_sy")
    }).count())
    logger.error("sy_false:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("sy_false")
    }).count())

    logger.error("总数据量："+re.count())
    re
  }


  def staIndex(dataRdd: RDD[JSONObject],cityMap: Broadcast[collection.Map[String, String]]) = {


    //获取城市映射
    val staRdd= dataRdd.map(obj=>{
      val cityNameMap = cityMap.value
      val cityCode = JSONUtil.getJsonVal(obj,"city_code","")

      var city: String   = ""
      var region: String =""
      var area: String   =""


      val mapString = cityNameMap.applyOrElse(cityCode, { num: String => "" })

      if(!mapString.isEmpty){
        city=  cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(0)
        region= cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(1)
        area=cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(2)
      }


      //大区
      obj.put("region",region)
      //地区
      obj.put("area",area)
      //城市名称
      obj.put("city",city)
      obj
    })




    val reRdd = staRdd.map(obj => {
      var adressEmptyCnt
      , unidentifiedCnt
      , rangeOutCnt
      , recognitionCnt
      , pbYwCnt
      , pbFlaseCnt
      , bgYwCnt
      , bgFlaseCnt
      , empcodeEmptyCnt
      , xgYwCnt
      , unitCodeEmptyCnt
      , empFlaseCnt
      , pbSyCnt
      , bgSyCnt
      , xgSyCnt
      = 0
      val tag = JSONUtil.getJsonVal(obj, "tag", "")
      val tag2 = JSONUtil.getJsonVal(obj, "tag2", "")
      val tag3 = JSONUtil.getJsonVal(obj, "tag3", "")
      val cityCode = JSONUtil.getJsonVal(obj, "city_code", "")
      val region = JSONUtil.getJsonVal(obj, "region", "")
      val city = JSONUtil.getJsonVal(obj, "city", "")


      if (tag.equals("address_empty")) adressEmptyCnt = 1
      if (tag.equals("unidentified")) unidentifiedCnt = 1
      if (tag.equals("range_out")) rangeOutCnt = 1
      if (tag.equals("recognition")) recognitionCnt = 1
      if (tag2.equals("pb_yw")) pbYwCnt = 1
      if (tag2.equals("pb_false")) pbFlaseCnt = 1
      if (tag2.equals("bg_yw")) bgYwCnt = 1
      if (tag2.equals("bg_false")) bgFlaseCnt = 1
      if (tag2.equals("empcode_empty")) empcodeEmptyCnt = 1
      if (tag2.equals("xg_yw")) xgYwCnt = 1
      if (tag2.equals("unit_code_empty")) unitCodeEmptyCnt = 1
      if (tag2.equals("emp_false")) empFlaseCnt = 1
      if (tag3.equals("pb_sy")) pbSyCnt = 1
      if (tag3.equals("bg_sy")) bgSyCnt = 1
      if (tag3.equals("xg_sy")) xgSyCnt = 1

      result(
         cityCode
        , city
        , region
        , adressEmptyCnt
        , unidentifiedCnt
        , rangeOutCnt
        , recognitionCnt
        , pbYwCnt
        , pbFlaseCnt
        , bgYwCnt
        , bgFlaseCnt
        , empcodeEmptyCnt
        , xgYwCnt
        , unitCodeEmptyCnt
        , empFlaseCnt
        , pbSyCnt
        , bgSyCnt
        , xgSyCnt
        )
    }).map(obj => {
      ((obj.cityCode,obj.city,obj.region), obj)
    }).reduceByKey((obj1, obj2) => {
      val cityCode = obj1.cityCode
      val city = obj1.city
      val region = obj1.region
      val adressEmptyCnt = obj1.adressEmptyCnt + obj2.adressEmptyCnt
      val unidentifiedCnt = obj1.unidentifiedCnt + obj2.unidentifiedCnt
      val rangeOutCnt = obj1.rangeOutCnt + obj2.rangeOutCnt
      val recognitionCnt = obj1.recognitionCnt + obj2.recognitionCnt
      val pbYwCnt = obj1.pbYwCnt + obj2.pbYwCnt
      val pbFlaseCnt = obj1.pbFlaseCnt + obj2.pbFlaseCnt
      val bgYwCnt = obj1.bgYwCnt + obj2.bgYwCnt
      val bgFlaseCnt = obj1.bgFlaseCnt + obj2.bgFlaseCnt
      val empcodeEmptyCnt = obj1.empcodeEmptyCnt + obj2.empcodeEmptyCnt
      val xgYwCnt = obj1.xgYwCnt + obj2.xgYwCnt
      val unitCodeEmptyCnt = obj1.unitCodeEmptyCnt + obj2.unitCodeEmptyCnt
      val empFlaseCnt = obj1.empFlaseCnt + obj2.empFlaseCnt
      val pbSyCnt = obj1.pbSyCnt+obj2.pbSyCnt
      val bgSyCnt = obj1.bgSyCnt+obj2.bgSyCnt
      val xgSyCnt = obj1.xgSyCnt+obj2.xgSyCnt

      result(cityCode,city,region,adressEmptyCnt,unidentifiedCnt,rangeOutCnt,recognitionCnt,pbYwCnt,pbFlaseCnt,bgYwCnt,bgFlaseCnt,empcodeEmptyCnt,xgYwCnt,unitCodeEmptyCnt,empFlaseCnt,pbSyCnt,bgSyCnt,xgSyCnt)
    })

    reRdd
  }


  def queryCityMap(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
    val sql =
      """
        | select max(city) as city ,citycode,max(region) as region ,max(area) as area
        | from dm_gis.city_name_map
        | group by citycode
      """.stripMargin
    logger.error(sql)
    val cityMap = spark.sql(sql).rdd.map(obj => {
      (obj.getString(1), obj.getString(0)+"&&"+obj.getString(2)+"&&"+obj.getString(3))
    }).collectAsMap()
    logger.error("城市映射表数量:" + cityMap.size)
    spark.sparkContext.broadcast(cityMap)
  }




  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = null
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          if (xyObj.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          ret = new JSONObject()
          var status, x, y, precision = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getDouble("precision") != null) precision = result.getInteger("precision") + ""
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }

  def runTeamCode(teamCodeUrl: String, deliveryLgt: String, deliveryLat: String) = {
    val re = new JSONObject()
    try {
      if (!deliveryLgt.isEmpty && !deliveryLat.isEmpty) {
        val url = String.format(teamCodeUrl, deliveryLgt, deliveryLat)
        val tc: JSONObject = HttpClientUtil.getJsonByGet(url)
        re.put("rerunTeam", tc.toJSONString)
        if (tc != null && tc.getJSONObject("result") != null) {
          val tcArray = tc.getJSONObject("result").getJSONArray("map_data")
          if (tcArray != null && tcArray.size() > 0) {
            for (i <- 0 to tcArray.size() - 1) {
              val job = tcArray.getJSONObject(i)
              if (JSONUtil.getJsonVal(job, "level", "") == "3") {
                val eTeamCode = JSONUtil.getJsonVal(job, "code", "")
                re.put("TeamCode", eTeamCode)

              }
            }
          }
        }
      }
    } catch {
      case x: Exception => logger.error(x)
        re.put("myException", x.toString)
    }
    re
  }

  def getTc(runUrlRdd: RDD[JSONObject]) = {

    val re = runUrlRdd.repartition(seg_partition).map(

      obj => {
      val tag2 = JSONUtil.getJsonVal(obj,"tag2","")


        if(tag2.equals("emp_false") || tag2.equals("pb_false") || tag2.equals("bg_false")){

                //        val teamCode = JSONUtil.getJsonVal(obj, "teamCode", "")
                //改
                val teamCode = JSONUtil.getJsonVal(obj, "unit_code", "")
                val city_code = JSONUtil.getJsonVal(obj, "city_code", "")
                val address = JSONUtil.getJsonVal(obj, "address", "")
                //调Mapa接口
                val mapxy = runMapXyInteface(mapa_url, city_code, address)
                val mapxy_x = JSONUtil.getJsonVal(mapxy, "x", "")
                val mapxy_y = JSONUtil.getJsonVal(mapxy, "y", "")

                //mapa xy获取tc
                val mapTc = runTeamCode(runTcUrl, mapxy_x, mapxy_y)
                val mapTeamCode = JSONUtil.getJsonVal(mapTc, "TeamCode", "")
                mapxy.put("mapReqTc", mapTc.toJSONString)
                obj.put("mapa_tc", mapTeamCode)
                obj.put("mapxy", mapxy)
                obj.put("mapxy_x", mapxy_x)
                obj.put("mapxy_y", mapxy_y)

                //调图商接口
                val tsxy = runMapXyInteface(ts_url, city_code, address)
                val tsxy_x = JSONUtil.getJsonVal(tsxy, "x", "")
                val tsxy_y = JSONUtil.getJsonVal(tsxy, "y", "")
                //图商xy获取tc
                val tsTc = runTeamCode(runTcUrl, tsxy_x, tsxy_y)
                val tsTeamCode = JSONUtil.getJsonVal(tsTc, "TeamCode", "")
                tsxy.put("tsReqTc", tsTc.toJSONString)
                obj.put("ts_tc", tsTeamCode)
                obj.put("tsxy", tsxy)
                obj.put("tsxy_x", tsxy_x)
                obj.put("tsxy_y", tsxy_y)
                //判断3者是否相等
                if (!mapTeamCode.isEmpty && mapTeamCode.equals(tsTeamCode) && mapTeamCode.equals(teamCode) ) {
                  tag2 match {
                    case "pb_false"=>obj.put("tag3","pb_sy")
                    case "bg_false"=>obj.put("tag3","bg_sy")
                    case _=>obj.put("tag3","xg_sy")

                  }
                }
        }

        obj
      }
    ).persist(StorageLevel.MEMORY_AND_DISK)
    re
  }

  def saveTable(spark: SparkSession, checkOverRdd: RDD[((String, String, String), result)], detailRdd: RDD[JSONObject],incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = detailRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    val tableName = "dm_gis.test_kuaiyun_detail_di" //测试数据表
    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

  //汇总表入库
    val wdDf = checkOverRdd.map(obj => obj._2).toDF()
    logger.error("入统计表数量：" + wdDf.count())
    wdDf.take(2).foreach(obj=>{logger.error(obj.toString())})
    val wdTableName = "dm_gis.kuaiyun_receipt_wd_di" //生产表
    wdDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(wdTableName)

  }

 //incDay:t-2  T1Day:t-1 T3Day:t-3 T4Day:t-4
  def getDataDf(spark: SparkSession ,incDay: String, sepDay: String,T1Day:String,T3Day:String,T4Day:String,formatDay1:String,formatDay3:String) = {
    //获取数据源
    val dataRddSql =
      s"""
        |select
        |a.inc_day
        |,a.city_code
        |,a.unit_code
        |,a.status
        |,a.remark
        |,a.sys_order_id
        |,a.update_time
        |,task_express.oms_order_no
        |,task_express.address as  express_address
        |,task_express.teamid
        |,task_express.old_teamid
        |,task_express.data_type
        |,task_express.task_status
        |,record_sheet.sys_order_no
        |,record_sheet.responsible
        |,record_sheet.employee_code
        |,nvl(record_sheet.transfor_emp,'1') as transfor_emp
        |,record_sheet.unit_area_code
        |,record_sheet.new_unit_area_code
        |,c.address
        |from (
        |
        |select
        |inc_day
        |,city_code
        |,unit_code
        |,status
        |,remark
        |,sys_order_id
        |,update_time
        |,row_number() over(partition by sys_order_id order by update_time desc) as rank1
        |from ky.ods_oss_dispatch.et_sgs_match_bro_resp_info
        |where inc_day='${incDay}'
        |)a
        |
        |left join
        |(
        |SELECT
        | oms_order_no
        |,address
        |,teamid
        |,old_teamid
        |,data_type
        |,task_status
        |,row_number()over(partition by oms_order_no order by modify_time desc ) rn
        |FROM
        |dm_gis.tt_task_express
        |where inc_day <'${T1Day}' and inc_day>'${T3Day}' and oms_order_no is not null
        |) task_express
        |on a.sys_order_id = task_express.oms_order_no and task_express.rn = 1
        |
        |left join
        |(
        |select sys_order_no
        |,responsible
        |,employee_code
        |,data_type
        |,unit_area_code
        |,new_unit_area_code
        |,nvl(transfor_emp,'2') transfor_emp
        |,row_number()over(partition by sys_order_no order by modify_time desc ) rn
        |from dm_gis.tt_task_express_record_sheet
        |where inc_day <'${T1Day}' and inc_day>'${T3Day}' and sys_order_no is not null
        |) record_sheet
        |on a.sys_order_id = record_sheet.sys_order_no and record_sheet.rn = 1
        |
        |--获取address
        |left join
        |(
        |select concat(province,city,county,address) as address,sysorderno
        |from dm_gis.gis_rds_omsfrom
        |where inc_day='${incDay}' and sysorderno is not null
        |)c
        |on a.sys_order_id=c.sysorderno
        |where a.rank1=1
      """.stripMargin

    logger.error(dataRddSql)

    val dataDf = spark.sql(dataRddSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取数据量：" + dataDf.count())
    logger.error(dataDf.show(10, false))
    dataDf.createOrReplaceTempView("dataTable")


    val joindataDfSql =
      """
        |select
        |a.sys_order_id
        |,a.emp_code
        |,b.pickup_emp_code
        |,b.teamCode
        |,d.unit_code_list
        |from ky.ods_oss_dispatch.et_sgs_match_bro_resp_info a
        |left join
        |(
        |--去重
        |select
        |a.src_order_no
        |,a.waybill_no[0] as waybill_no
        |,a.pickup_emp_code
        |,b.teamCode
        |from
        |dwd.dwd_pub_order_dtl_di  a
        |left join
        |(
        |--去重
        |select
        |get_json_object(get_json_object(get_json_object(log,'$.message'),'$.request'),'$.waybillNo') as waybill_no
        |,get_json_object(get_json_object(get_json_object(log,'$.message'),'$.response'),'$.teamCode') as teamCode
        |from dm_gis.kuaiyun_log_flink
        |where inc_day >'%s' AND inc_day <'%s'  and get_json_object(get_json_object(get_json_object(log,'$.message'),'$.response'),'$.teamCode') <> ''
        |group by
        |get_json_object(get_json_object(get_json_object(log,'$.message'),'$.request'),'$.waybillNo')
        |,get_json_object(get_json_object(get_json_object(log,'$.message'),'$.response'),'$.teamCode')
        |) B
        |on a.waybill_no[0] = b.waybill_no
        |where a.inc_day >'%s'  AND A.inc_day <'%s'
        |) b
        |on a.sys_order_id = b.src_order_no
        |left join(
        |Select emp_code,concat_ws(',',collect_set(cast(zone_code as string))) as unit_code_list
        |from
        |ky.ods_oss.et_employee_pd_schedule_info
        |where inc_day = '%s'
        |group by emp_code
        |) d
        |on a.emp_code = d.emp_code
        |where to_date(update_time) < to_date('%s') and  to_date(update_time)>to_date('%s')
      """.stripMargin


    val formatSql = String.format(joindataDfSql,T4Day,T1Day,T3Day,T1Day,incDay,formatDay1,formatDay3)

    logger.error(formatSql)



    val joinDF = spark.sql(formatSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("获取到joinDF的数据量：" + joinDF.count())
    logger.error(joinDF.show(10, false))

    joinDF.createOrReplaceTempView("joinTable")


    val totalDfSql =
      """
        |select
        | a.inc_day
        |,a.city_code
        |,a.unit_code
        |,a.status
        |,a.remark
        |,a.sys_order_id
        |,a.update_time
        |,a.oms_order_no
        |,a.express_address
        |,a.teamid
        |,a.old_teamid
        |,a.data_type
        |,a.task_status
        |,a.sys_order_no
        |,a.responsible
        |,a.employee_code
        |,a.transfor_emp
        |,a.unit_area_code
        |,a.new_unit_area_code
        |,a.address
        |,a.sys_order_id_b
        |,a.emp_code
        |,a.pickup_emp_code
        |,a.unit_code_list
        |,a.teamCode
        |from(
        |select
        |--datadf
        | a.inc_day
        |,a.city_code
        |,a.unit_code
        |,a.status
        |,a.remark
        |,a.sys_order_id
        |,a.update_time
        |,a.oms_order_no
        |,a.express_address
        |,a.teamid
        |,a.old_teamid
        |,a.data_type
        |,a.task_status
        |,a.sys_order_no
        |,a.responsible
        |,a.employee_code
        |,a.transfor_emp
        |,a.unit_area_code
        |,a.new_unit_area_code
        |,a.address
        |--joinDF
        |,b.sys_order_id as sys_order_id_b
        |,b.emp_code
        |,b.pickup_emp_code
        |,b.unit_code_list
        |,b.teamCode
        |,row_number()over(distribute by a.sys_order_id sort by a.update_time desc ) rn
        |from dataTable a
        |left join
        |joinTable b
        |on a.sys_order_id = b.sys_order_id
        |)a
        |where a.rn =1
      """.stripMargin

    logger.error(totalDfSql)
    val totalRdd = SparkUtils.getRowToJson(spark, totalDfSql).repartition(sqlpartition)
    logger.error(totalRdd.take(10).foreach(println(_)))

    totalRdd
  }


}
