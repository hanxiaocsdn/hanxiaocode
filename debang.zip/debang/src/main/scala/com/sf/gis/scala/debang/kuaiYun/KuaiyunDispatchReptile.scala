package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.debang.util._
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object KuaiyunDispatchReptile {
  @transient lazy val logger: Logger = Logger.getLogger(KuaiyunDispatchReptile.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  //http://gis-int.int.sfdc.com.cn:1080/geo/api

  val ts_url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=e3b7cdb1a14644eb89c11c616937a1b0&opt=gd2&address=%s&city=%s"
  val aoi_url = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=e3b7cdb1a14644eb89c11c616937a1b0"

  case class result(
                     city: String,
                     area: String,
                     url: String,
                     subdistrict: String,
                     floor: String,
                     supporting_elevator: String,
                     proportion_of_households: String,
                     number_of_buildings: String,
                     construction_year: String,
                     source_tag: String,
                     address: String,
                     gd_x: String,
                     gd_y: String,
                     x_gd: String,
                     y_gd: String,
                     distance: String,
                     aoiid: String,
                     gd_aoiid: String,
                     tag: String,
                     citycode:String
                   )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)

    logger.error("起始时间:" + startDay)
    start(startDay)
    logger.error("结束所有运行")

  }

  //  $[time(yyyyMM)]
  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataRdd = getDataDf(spark, incDay)
    logger.error("开始解析")
    val saveRdd = analysisRdd(dataRdd)

    logger.error("指标计算并入库")
    //入库
    saveTable(spark, saveRdd, incDay)
    logger.error("解析表入库完毕")


  }


  //入库
  def saveTable(spark: SparkSession, saveRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._


    //明细表入库
    val rowDf = saveRdd.map(_.toJSONString.replaceAll("[\r\n\t]+", "")).toDF()

    logger.error("入明细表数量：" + rowDf.count())

    val tableName = "dm_gis.crawler_gdaoi_elevator_detail" //生产数据表
    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

    val tmpTable = saveRdd.map(o => {
      result(
        JSONUtil.getJsonVal(o, "city", ""),
        JSONUtil.getJsonVal(o, "area", ""),
        JSONUtil.getJsonVal(o, "url", ""),
        JSONUtil.getJsonVal(o, "subdistrict", ""),
        JSONUtil.getJsonVal(o, "floor", ""),
        JSONUtil.getJsonVal(o, "supporting_elevator", ""),
        JSONUtil.getJsonVal(o, "proportion_of_households", ""),
        JSONUtil.getJsonVal(o, "number_of_buildings", ""),
        JSONUtil.getJsonVal(o, "construction_year", ""),
        JSONUtil.getJsonVal(o, "source_tag", ""),
        JSONUtil.getJsonVal(o, "address", ""),
        JSONUtil.getJsonVal(o, "gd_x", ""),
        JSONUtil.getJsonVal(o, "gd_y", ""),
        JSONUtil.getJsonVal(o, "x_gd", ""),
        JSONUtil.getJsonVal(o, "y_gd", ""),
        JSONUtil.getJsonVal(o, "distance", ""),
        JSONUtil.getJsonVal(o, "aoiid", ""),
        JSONUtil.getJsonVal(o, "gd_aoiid", ""),
        JSONUtil.getJsonVal(o, "tag", ""),
        JSONUtil.getJsonVal(o, "citycode", "")
      )
    }).toDF()

    tmpTable.createOrReplaceTempView("tmp_table")


    val jsSql =
      """
        |select
        | a.city
        |,a.area
        |,a.url
        |,a.subdistrict
        |,a.floor
        |,a.supporting_elevator
        |,a.proportion_of_households
        |,a.number_of_buildings
        |,a.construction_year
        |,a.source_tag
        |,a.address
        |,a.gd_x
        |,a.gd_y
        |,a.x_gd
        |,a.y_gd
        |,a.distance
        |,a.aoiid
        |,a.aoiid_gd_freq
        |,a.aoi_elev_cnt
        |,a.aoi_nonelev_cnt
        |,a.aoi_elev_rate
        |,a.aoi_nonelev_rate
        |,case when a.aoi_elev_rate>=0.9 then '有电梯'
        | when a.aoi_nonelev_rate >= 0.9 then '无电梯' end as tag
        |,a.citycode
        |from (
        |select
        | city
        |,area
        |,url
        |,subdistrict
        |,floor
        |,supporting_elevator
        |,proportion_of_households
        |,number_of_buildings
        |,construction_year
        |,source_tag
        |,address
        |,gd_x
        |,gd_y
        |,x_gd
        |,y_gd
        |,distance
        |,aoiid
        |,aoiid_gd_freq
        |,aoi_elev_cnt
        |,aoi_nonelev_cnt
        |,citycode
        |,aoi_elev_cnt/aoiid_gd_freq as aoi_elev_rate
        |,aoi_nonelev_cnt/aoiid_gd_freq as aoi_nonelev_rate
        |from(
        |select
        | city
        |,area
        |,url
        |,subdistrict
        |,floor
        |,supporting_elevator
        |,proportion_of_households
        |,number_of_buildings
        |,construction_year
        |,source_tag
        |,address
        |,gd_x
        |,gd_y
        |,x_gd
        |,y_gd
        |,distance
        |,gd_aoiid as aoiid
        |,sum(if(tag = 'yes',1,0))over(PARTITION by gd_aoiid) aoiid_gd_freq
        |,sum(if(tag = 'yes' and supporting_elevator = '有',1,0))over(PARTITION by gd_aoiid) aoi_elev_cnt
        |,sum(if(tag = 'yes' and supporting_elevator = '无',1,0))over(PARTITION by gd_aoiid) aoi_nonelev_cnt
        |,citycode
        |from tmp_table
        |) a
        |)a
        |left join
        |(
        |select
        |aoiid_cg
        |from dm_gis.aoi_elevator_info_stat b
        |where elevator_type = '3'
        |group by aoiid_cg
        |) b
        |on a.aoiid = b.aoiid_cg
        |where b.aoiid_cg is null
      """.stripMargin

    logger.error(jsSql)

    val jsTableName = "dm_gis.crawler_gdaoi_elevator"
    val updataTable = "dm_gis.spider_aoi_elevator_stat"
//    val updataTable = "dm_gis.spider_aoi_elevator_stat_tmp"

    val reDf = spark.sql(jsSql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s"写入最终表的数据量${jsTableName}" + reDf.count())

    reDf.take(10).foreach(o => logger.error(o.toString()))

    reDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(jsTableName)

    //更新spider_aoi_elevator_stat表数据
    val updataSql =
      s"""
         |
         |select
         |aoi_id
         |,citycode
         |,source
         |,aoi_type
         |,elevator_cnt
         |,no_elevator_cnt
         |,is_elevator
         |from  dm_gis.spider_aoi_elevator_stat a
         |union all
         |select
         |aoi_id
         |,citycode
         |,"4" as source
         |,"" as aoi_type
         |,elevator_cnt
         |,no_elevator_cnt
         |,"1" as is_elevator
         |from (
         |select
         |a.aoiid as aoi_id
         |,a.citycode
         |,a.aoi_elev_cnt as elevator_cnt
         |,a.aoi_nonelev_cnt as no_elevator_cnt
         |from
         |dm_gis.crawler_gdaoi_elevator a
         |left join
         |  dm_gis.spider_aoi_elevator_stat b
         | on a.aoiid  =b.aoi_id
         | and b.inc_day = '${incDay}'
         | where b.aoi_id is null and a.tag = '有电梯' and a.inc_day = '${incDay}'
         |)a
         |group by
         |aoi_id
         |,citycode
         |,elevator_cnt
         |,no_elevator_cnt
      """.stripMargin

    logger.error(updataSql)
   val updataRdd =  spark.sql(updataSql)
    updataRdd.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(updataTable)

  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      s"""
         |select *
         |from dm_gis.dm_spider_elevator_group_dtl_mi
         | where aoiid = '' and inc_month = ${incDay}
         | --where aoiid = '' and inc_month = ${incDay} and  tag  not in ('无电梯','有电梯','部分有电梯')
      """.stripMargin

    logger.error(totalDfSql)
    val totalRdd = SparkUtils.getRowToJson(spark, totalDfSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }

  //数据处理
  def analysisRdd(dataRdd: RDD[JSONObject]) = {
    logger.error("获取高德坐标")


    val aoiRdd: RDD[JSONObject] = dataRdd.repartition(10).map(o => {
      val citycode = JSONUtil.getJsonVal(o, "citycode", "")
      var address = JSONUtil.getJsonVal(o, "address", "")


      if(address.contains("/")){
        address =  address.substring(0, address.indexOf("/"))
      }

      var gdxyRet = runMapXyInteface(ts_url, citycode, address)
      o.put("address", address)
      o.put("gd_aoiid", JSONUtil.getJsonVal(gdxyRet, "aoiId", ""))
      o.put("gd_aoiname", JSONUtil.getJsonVal(gdxyRet, "aoiName", ""))
      o.put("aoiDeptRet", JSONUtil.getJsonVal(gdxyRet, "aoiDeptRet", ""))
      o.put("x_gd", JSONUtil.getJsonVal(gdxyRet, "x", ""))
      o.put("y_gd", JSONUtil.getJsonVal(gdxyRet, "y", ""))
      o.put("precision", JSONUtil.getJsonVal(gdxyRet, "precision", ""))
      o.put("xyRet", JSONUtil.getJsonVal(gdxyRet, "xyRet", ""))
      o.put("gdxyRet", gdxyRet)
      o

    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("跑完aoi的数据量" + aoiRdd.count())
    aoiRdd.take(2).foreach(o => logger.error(o.toJSONString))

    logger.error("计算火星坐标的距离")

    val dsRdd = aoiRdd.map(o => {
      val gd_x1 = try {
        JSONUtil.getJsonVal(o, "x_gd", "").toDouble
      } catch {
        case e: Exception => 0
      }
      val gd_y2 = try {
        JSONUtil.getJsonVal(o, "y_gd", "").toDouble
      } catch {
        case e: Exception => 0
      }
      val gd_x = try {
        JSONUtil.getJsonVal(o, "gd_x", "").toDouble
      } catch {
        case e: Exception => 0
      }
      val gd_y = try {
        JSONUtil.getJsonVal(o, "gd_y", "").toDouble
      } catch {
        case e: Exception => 0
      }

      val distance = getDistance2(gd_x1, gd_y2, gd_x, gd_y)
      o.put("distance", distance)
      if (distance <= 150) o.put("tag", "yes") else o.put("tag", "no")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("跑完距离的数据量" + dsRdd.count())

    dsRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })
    dsRdd
  }


  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          if (xyObj.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep((60 - second)*1000)
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          ret = new JSONObject()
          var status, x, y, precision = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getDouble("precision") != null) precision = result.getInteger("precision") + ""

            //取高精
            if (precision.equals("2")) {
              //点落面接口
              val (aoi_id, aoi_name, deptRet) = xy2Dept(aoi_url, x, y)
              ret.put("aoiId", aoi_id)
              ret.put("aoiName", aoi_name)
              ret.put("aoiDeptRet", deptRet)
            }
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
          ret.put("xyRet", xyObj.toJSONString)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }

  def xy2Dept(xyDeptUrl: String, lgt: String, lat: String): (String, String, JSONObject) = {
    var ret = null: JSONObject
    try {
      if (lgt != null && !lgt.isEmpty) {
        ret = HttpClientUtil.getJsonByGet(String.format(xyDeptUrl, lgt, lat))

        if (ret != null && ret.getJSONObject("result") != null) {
          if (ret.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep((60 - second)*1000)
            return xy2Dept(xyDeptUrl, lgt, lat)
          }
          val mapArray = JSONUtil.getJsonArrayFromObject(ret, "result.aoi_data", null)
          if (mapArray != null && mapArray.size() > 0) {
            val code = JSONUtil.getJsonVal(mapArray.getJSONObject(0), "aoi_id", "")
            val aoi_name = JSONUtil.getJsonVal(mapArray.getJSONObject(0), "aoi_name", "")
            return (code, aoi_name, ret)
          }
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ("", "", ret)
  }

  def getDistance2(longitude1: Double, latitude1: Double, longitude2: Double, latitude2: Double): Double = { // 纬度
    val R = 6371.00

    val lat1: Double = Math.toRadians(latitude1)
    val lat2: Double = Math.toRadians(latitude2)
    // 经度
    val lng1: Double = Math.toRadians(longitude1)
    val lng2: Double = Math.toRadians(longitude2)
    // 纬度之差
    val a: Double = lat1 - lat2
    // 经度之差
    val b: Double = lng1 - lng2
    // 计算两点距离的公式
    var s: Double = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(lat1) * Math.cos(lat2) * Math.pow(Math.sin(b / 2), 2)))
    // 弧长乘地球半径, 返回单位: 千米
    s = s * R
    s
  }

}
