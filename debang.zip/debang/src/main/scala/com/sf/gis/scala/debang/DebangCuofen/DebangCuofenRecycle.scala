package com.sf.gis.scala.debang.DebangCuofen

import java.net.URLEncoder

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.sx.constant.util.Utils
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.debang.pojo.DebangCuofen
import com.sf.gis.scala.debang.util.{DateTimeUtil, JSONUtil, SparkUtils}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.io.Source

/**
 * 任务id:155
 * 任务名称:德邦错分回传_cxg
 */
object DebangCuofenRecycle {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  //关闭fastjson引用检测
  JSON.DEFAULT_GENERATE_FEATURE |= SerializerFeature.DisableCircularReferenceDetect.getMask
  //审补任务核实结果查询接口
  val chknUrl = "http://gis-aos-cgcs.sf-express.com/audit/api/exportQuery/chkn"
  //标准任务核实结果查询接口
  val normUrl = "http://gis-aos-cgcs.sf-express.com/audit/api/exportQuery/norm"
  //相似度接口
  val similarUrl = "http://10.119.72.209:8080/rds_web/noControl/similar/%s/%s"
  //GIS_CMS更新大组接口
  val updateAddrAoiIdUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId"
  //DBZC接口
  val dbZcUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/api/cache/query?ak=3a191e7427e8470c86271a069411c66b&type=3&aoi=%s"
  //文本压审补Url：
  val addrReviewUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon/his/opt?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&type=1&zc=%s&tc=%s"
  //根据城市对压入审补数据生效url:
  val cityReviewUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/opt/effect?ak=3a191e7427e8470c86271a069411c66b&city=%s&showserver=true"
  //容灾
  val atdispatchUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?ak=e9106d80834e483189c3439938bac5d2&opt=hp&city=%s&address=%s"
  //cms审补库
  val cmsReviewUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd"
  //  val cmsReviewUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd?cityCode=%s&address=%s&znoCode=%s&aoiId=%s&src=0&operSource=DB&operUserName=1394694"
  //审补地址下线
  val deleteRgsbAddrUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/deleteRgsbAddr"
  //  val deleteRgsbAddrUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/deleteRgsbAddr?cityCode=%s&address=%s&type=2&operSource=DB&operUserName=1394694"

  private def scheduleDBTcInterface(x: String, y: String): String = {
    var code = ""

    val dbTcUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/geom/query?ak=3a191e7427e8470c86271a069411c66b&x=%s&y=%s"
    try {
      if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
        val url = String.format(dbTcUrl, x, y)
        val response = Source.fromURL(url, "UTF-8").mkString
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val response2 = JSON.parseObject(response)
            val result = response2.getJSONObject("result")
            val data = result.getJSONObject("data")
            val codeNew = data.getString("code")
            code = codeNew
          }
        }
      }
    } catch {
      case e: Exception => println("调度DBTc接口时出现异常Exception: " + e.getMessage)
    }
    code
  }


  def main(args: Array[String]): Unit = {
    val spark = Spark.getSparkSession(appName)

    val incDay = args(0)
    val thirdDay = DateTimeUtil.getDaysApartDate("yyyyMMdd", incDay, 1)
    val incDayT = DateTimeUtil.getConvertFormatDate(incDay, "yyyyMMdd", "yyyy-MM-dd")
    val thirdDayT = DateTimeUtil.getConvertFormatDate(thirdDay, "yyyyMMdd", "yyyy-MM-dd")

    //val incDay ="20210103"
    //val thirdDay = "20210106"
    //val incDayT = "2021-01-03"
    //val thirdDayT = "2021-01-06"

    println(incDayT, thirdDayT)

    //    val json = new JSONObject()

    run(spark, incDay, thirdDay, incDayT, thirdDayT)
  }

  def run(spark: SparkSession, incDay: String, thirdDay: String, incDayT: String, thirdDayT: String): Unit = {
    import spark.implicits._
    //获取错分下发数据
    val (cityDeptList, issueMap) = getIssueData(spark, incDay, thirdDay)
    logger.error("cityDeptList数量为：" + cityDeptList.length)

    //接口获取仓管错柯错分标准核实和审补核实结果
    val (verifyDetailNormRdd, verifyDetailShenbuRdd) = getVerifyData(spark, cityDeptList, incDay, issueMap, incDayT, thirdDayT)

    //处理标准核实结果流程
    val normResRdd = processNormData(verifyDetailNormRdd)

    //处理审补结果为1
    val shenbuResRdd = processShenbuData(verifyDetailShenbuRdd)

    //处理审补结果为1的数据调用db生产服务接口
    val reshenbuResRdd = getBzTag(shenbuResRdd)

    val unionRdd = normResRdd.union(reshenbuResRdd)


    val bzSql =
      s"""
         |select citycode
         |,address
         |,aoiid
         |,zc
         |from dm_gis.deppon_address_remove_conf_new where inc_day='online'
      """.stripMargin
    logger.error(bzSql)
    //获取标准配置表
    spark.sql(bzSql).persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("deppon_address_remove_conf_new1")


    //入标准库          resJson.put("reZc", "ture")
    val bzReRdd = unionRdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "zcTag", "").equals("true")
    }).map(obj => {
      val citycode = obj.getString("reCityCode")
      val address = obj.getString("address")
      val zc = obj.getString("reZc")
      val aoiid = obj.getString("checkAoiId")
      DebangCuofen(citycode, address, aoiid, zc)
    }
    )

    bzReRdd.toDF().persist(StorageLevel.MEMORY_AND_DISK).createOrReplaceTempView("deppon_address_remove")

    logger.error("入标准库的数量：" + bzReRdd.count())


    val rkSql =
      """
        |select
        | citycode
        |,address
        |,aoiid
        |,zc
        | from (
        |select
        | a.citycode
        |,a.address
        |,a.aoiid
        |,a.zc
        |from deppon_address_remove_conf_new1 a
        |left join
        |deppon_address_remove b
        |on a.address = b.address
        |where b.address is null
        |union all
        |select
        | citycode
        |,address
        |,aoiid
        |,zc
        |from deppon_address_remove b
        |)
        |group by
        | citycode
        |,address
        |,aoiid
        |,zc
      """.stripMargin
    logger.error(rkSql)

    val tableName = "dm_gis.deppon_address_remove_conf_new" //测试备份表
    val as: DataFrame = spark.sql(rkSql).repartition(1).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("存入备份表数量：" + as.count())

    val tmpViewName = "tmp" + System.currentTimeMillis()
    as.createOrReplaceTempView(tmpViewName)
    //      .write.mode(SaveMode.Overwrite).saveAsTable("tmp_dm_gis.tmp_res")
    val insertRecordSql = s"insert overwrite table ${tableName} partition(inc_day='${incDay}') " +
      s" select * from ${tmpViewName} "
    logger.error(insertRecordSql)
    spark.sql(insertRecordSql)

    val insertOnlineSql = s"insert overwrite table ${tableName} partition(inc_day='online') " +
      s" select * from ${tmpViewName} "
    logger.error(insertOnlineSql)
    spark.sql(insertOnlineSql)
    //    spark.table("tmp_dm_gis.tmp_res").write.mode(SaveMode.Overwrite).insertInto(tableName)

    //    as.write.mode(SaveMode.Overwrite).insertInto(tableName)


    logger.error("标准库数据入库完成")

    val saveRdd = unionRdd.map(obj => {
      Row(obj.getString("type"), obj.toJSONString, incDay)
    })
    //入库
    //    SparkUtils.df2Hive(spark,saveRdd,schema,"append", "dm_gis.debang_cuofen_recycle_res2","inc_day",incDay,logger)
    //    SparkUtils.df2Hive(spark,saveRdd,schema,"append", "tmp_dm_gis.debang_cuofen_recycle_res2","inc_day",incDay,logger)
    SparkUtils.df2Hive(spark, saveRdd, schema, "append", "dm_gis.debang_cuofen_recycle_res2", "inc_day", incDay, logger)
    logger.error("数据入库完成")

  }


  val schema = StructType(List(
    StructField("type", StringType, true)
    , StructField("info", StringType, true)
    , StructField("inc_day", StringType, true))
  )

  val verifySchema = StructType(List(
    StructField("type", StringType, true)
    , StructField("citycode", StringType, true)
    , StructField("deptCode", StringType, true)
    , StructField("resJson", StringType, true)
    , StructField("inc_day", StringType, true)))

  def getIssueData(spark: SparkSession, incDay: String, thirdDay: String) = {
    logger.error("开始获取德邦错分下发数据")
    val beginDay = DateTimeUtil.getDaysApartDate("yyyyMMdd", incDay, -5)
    //---CxG
    var querySql =
      """
        |select
        | type,
        | get_json_object(info,'$.city') city,
        | get_json_object(info,'$.zc') zc,
        | get_json_object(info, '$.address') address,
        | get_json_object(info, '$.mapa_aoi_id') mapa_aoi_id,
        | get_json_object(info, '$.ts_aoi_id') ts_aoi_id,
        | get_json_object(info, '$.keyword') keyword,
        | get_json_object(info, '$.originId') originId,
        | get_json_object(info, '$.citycode') citycode,
        | info
        | from dm_gis.debang_cuofen_issues
        |where inc_day >= '%s' and inc_day<= '%s' and type in ('shenbu','biaozhun')
        |""".stripMargin


    //'biaozhun',
    querySql = String.format(querySql, beginDay, thirdDay)

    logger.error(querySql)

    val issueRdd = SparkUtils.getRowToJson(spark, querySql)
    logger.error(s"共获取错分任务下发数据:${issueRdd.count}")

    val cityDeptList = issueRdd.map(json => {
      val normString = JSON.parseObject(json.getString("info")).getString("normRes")
        .replaceAll("\\\"\\{", "{").replaceAll("\\}\\\"", "}")
      // (json.getString("type"),json.getString("city"))
      val zc = try {
        JSON.parseObject(normString).getJSONObject("result").getJSONArray("tcs")
          .getJSONObject(0).getString("dept")
      } catch {
        case _ => ""
      }
      (json.getString("type"), json.getString("city"), zc)
    }
    ).collect().toList.distinct

    cityDeptList.take(2).foreach(println(_))
    logger.error(s"获取下发网点城市分类:${cityDeptList.size}")

    val issueMap = issueRdd.map(obj => (obj.getString("originId"), obj)).collect().toMap

    logger.error(s"获取originId共:${issueMap.size}")

    issueRdd.unpersist()
    (cityDeptList, issueMap)
  }


  //判断调用db生产服务，根据check_aoiid返回dbZC
  def getBzTag(shenbuResRdd: RDD[JSONObject]) = {

    //    .filter(obj=>{obj.getString("zcTag").isEmpty() && obj.getString("zcTag").equals("true")})

    logger.error("开始调用db打标签判断Zc的数量" + shenbuResRdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "getdbZC", "").equals("true")
    }).count())

    val reRdd = shenbuResRdd.map(obj => {
      val tag = JSONUtil.getJsonVal(obj, "getdbZC", "")
      val checkAoiId = obj.getString("checkAoiId")
      val reZc = JSONUtil.getJsonVal(obj, "reZc", "")
      if (tag.equals("true")) {
        //调用接口返回dbZC
        val dbZcReq = dbZcUrl.format(checkAoiId)
        val dbZcRes = Utils.retryGet(dbZcReq)
        obj.put("dbZcReq", dbZcReq)
        obj.put("dbZcRes", try {
          JSON.parseObject(dbZcRes)
        } catch {
          case e: Exception => new JSONObject().put("error", e + "\n" + dbZcRes)
        })


        val zcJsonArray = try {
          //获取德邦zc
          JSON.parseObject(dbZcRes).getJSONObject("result").getJSONArray("deppon")
        } catch {
          case _ => null
        }

        var zcList = List[String]()

        if (zcJsonArray != null) {


          if (zcJsonArray.size() == 1)
            zcList = zcJsonArray.getJSONObject(0).getString("dept") :: zcList
          //如果返回ZC个数为2，且2个ZC相等，取其中一个zc返回；若2个ZC不相等，则2个都返回
          else {
            val zc1 = zcJsonArray.getJSONObject(0).getString("dept")
            val zc2 = zcJsonArray.getJSONObject(1).getString("dept")

            if (zc1.equals(zc2))
              zcList = zc1 :: zcList
            else {
              zcList = zc1 :: zcList
              zcList = zc2 :: zcList
            }
          }


          if (zcList != null) {
            for (i <- Range(0, zcList.size)) yield {
              if (StringUtils.isNotEmpty(reZc) && StringUtils.isNotEmpty(zcList(i)) && zcList(i).equals(reZc)) {
                obj.put("zcTag", "true")
                obj
              } else {
                obj.put("type", "normNoProcess")
                obj
              }
            }
          } else {
            obj.put("type", "notDbZc2")
            obj
          }

        } else {
          obj.put("type", "notDbZc")
          obj
        }
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("审补结果需要入标准库的数量：" + reRdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "zcTag", "").equals("true")
    }).count())
    reRdd
  }


  def getVerifyData(spark: SparkSession, cityDeptList: List[(String, String, String)], incDay: String, issueMap: Map[String, JSONObject]
                    , incDayT: String, thirdDayT: String):
  (RDD[(String, String, String, JSONObject, JSONObject, Boolean, Boolean)], RDD[(String, String, String, JSONObject, JSONObject, Boolean, Boolean)]) = {
    logger.error("开始获取德邦错分核实结果")
    //val tuples = Array("010","020")

    val verifyRdd = spark.sparkContext.parallelize(cityDeptList, 200)
      .flatMap(obj => {
        val (issueType, citycode, zc) = obj
        val reqJson = new JSONObject()
        reqJson.put("city", citycode)
        reqJson.put("checkZnoCode", zc)
        reqJson.put("deptCode", zc)
        val arr = new JSONArray()
        arr.add("DB")
        reqJson.put("staTypes", arr)
        reqJson.put("beginDate", incDayT + " 00:00:00")
        reqJson.put("endDate", thirdDayT + " 00:00:00")
        reqJson.put("pageNo", 1)
        reqJson.put("pageSize", 5000)


        //reqJson.put("sourceTypes",arr)
        //        reqJson.put("beginCheckDate",incDayT+" 00:00:00")
        //        reqJson.put("endCheckDate",thirdDayT+" 00:00:00")

        var resJsonString = ""


        if ("biaozhun".equals(issueType))
          resJsonString = SparkUtils.doPost(normUrl, reqJson, logger)
        else
          resJsonString = SparkUtils.doPost(chknUrl, reqJson, logger)

        val resJsonArr = try {
          JSON.parseObject(resJsonString).getJSONObject("data").getJSONArray("result")
        } catch {
          case _ => new JSONArray()
        }


        //       val list_res= resJsonArr.toArray().map(x => {
        //          val resJson = try { x.asInstanceOf[JSONObject] } catch { case _ => new JSONObject() }
        //          resJson.put("reqJson",reqJson)
        //          val originId = resJson.getString("originId")
        //          val checkZnoCode = resJson.getString("znoCode")
        //          val isNorm = resJson.getString("isNorm")
        //          //val checkZnoCode = resJson.getString("checkZnoCode")
        //          ((originId,isNorm),(issueType,citycode,checkZnoCode,resJson,originId))
        //        }).groupBy(_._1).map(x => {
        //         val b = x._2.toList.head
        //          b._2
        //        }).toList

        //      list_res
        resJsonArr.toArray().map(x => {
          val resJson = try {
            x.asInstanceOf[JSONObject]
          } catch {
            case _ => new JSONObject()
          }
          resJson.put("reqJson", reqJson)
          val originId = resJson.getString("originId")
          val checkZnoCode = resJson.getString("znoCode")
          //val checkZnoCode = resJson.getString("checkZnoCode")
          (issueType, citycode, checkZnoCode, resJson, originId)
        })
      }).distinct()
      .persist(StorageLevel.DISK_ONLY)

    logger.error(s"获取核实数据共:${verifyRdd.count()}")

    //入库hive

    val saveRdd = verifyRdd.map(obj => Row(obj._1, obj._2, obj._3, obj._4.toJSONString, incDay)).distinct()

    //---CXG
    //    SparkUtils.df2Hive(spark,saveRdd,verifySchema,"append", "dm_gis.debang_cuofen_recycle_res1","inc_day",incDay,logger)
    SparkUtils.df2Hive(spark, saveRdd, verifySchema, "append", "dm_gis.debang_cuofen_recycle_res1", "inc_day", incDay, logger)

    val verifyDetailRdd = verifyRdd
      .map(obj => {
        val (issueType, citycode, zc, resJson, originId) = obj
        if (StringUtils.isNotEmpty(originId) && issueMap.contains(originId))
          (issueType, citycode, zc, resJson, originId)
        else null
      })
      .filter(_ != null)
      .map(obj => {
        val (issueType, citycode, zc, resJson, originId) = obj

        if (StringUtils.isNotEmpty(originId)) {
          val issueResJson = issueMap.getOrElse(originId, null)


          //判断工单地址与标准地址是否一致? 审补结果为1?
          val flag1 = "biaozhun".equals(issueType) && "1".equals(resJson.getString("isSamePlace"))

          val flag2 = !flag1 || "shenbu".equals(issueType)
          //--CXG
          val reCityCode = issueResJson.getString("city")
          val zc = issueResJson.getString("zc")
          val address = issueResJson.getString("address")
          resJson.put("reCityCode", reCityCode)
          resJson.put("address", address)
          resJson.put("reZc", zc)


          (issueType, citycode, zc, resJson, issueResJson, flag1, flag2)
        } else null
      })
      .filter(_ != null)
      .persist(StorageLevel.DISK_ONLY)


    logger.error(s"获取核实明细数据共:${verifyDetailRdd.count()}")

    val verifyDetailNormRdd = verifyDetailRdd.filter(_._6).persist(StorageLevel.DISK_ONLY)
    val verifyDetailShenbuRdd = verifyDetailRdd.filter(_._7).persist(StorageLevel.DISK_ONLY)

    logger.error(s"获取标准核实明细数据共:${verifyDetailNormRdd.count()}")
    logger.error(s"获取审补核实明细数据共:${verifyDetailShenbuRdd.count()}")

    verifyRdd.unpersist()
    verifyDetailRdd.unpersist()

    (verifyDetailNormRdd, verifyDetailShenbuRdd)
  }

  def processNormData(verifyDetailNormRdd: RDD[(String, String, String, JSONObject, JSONObject, Boolean, Boolean)]) = {
    logger.error(s"开始处理标准核实结果流程")

    val normResRdd = verifyDetailNormRdd.repartition(6).flatMap(obj => {
      val (issueType, citycode, zc, resJson, issueResJson, flag1, flag2) = obj

      if (!Array("1", "2").contains(resJson.getString("checkDataType"))) {
        resJson.put("type", "noProcess")
        List(resJson)
      } else {

        val checkAoiId = resJson.getString("checkAoiId")
        val mapaAoiId = issueResJson.getString("mapa_aoi_id")
        val tsAoiId = issueResJson.getString("ts_aoi_id")
        val keyword = issueResJson.getString("keyword")
        val standardization = issueResJson.getString("standardization")
        val address = issueResJson.getString("address")
        val checkAoiName = resJson.getString("checkAoiName")


        //判断是否根据根据check_aoiid更新CMS大组AOI
        val isUpdate = judgeUpdate(checkAoiId, mapaAoiId, tsAoiId, address, keyword, checkAoiName, standardization, resJson)

        //更新或db压审补
        if (isUpdate) {
          val addressId = resJson.getString("groupId")
          //val addressId = resJson.getString("addressMd5")
          val json = new JSONObject()

          json.put("cityCode", citycode)
          json.put("addressId", addressId)
          json.put("aoiId", checkAoiId)
          json.put("operSource", "DB")
          json.put("operUserName", "1394694")
          //生产
          val updateAddrAoiIdRes = SparkUtils.doPost(updateAddrAoiIdUrl, json, logger)
          resJson.put("updateAddrAoiIdRes", try {
            JSON.parseObject(updateAddrAoiIdRes)
          } catch {
            case e: Exception => new JSONObject().put("error", e + "\n" + updateAddrAoiIdRes)
          })


          resJson.put("updateAddrAoiIdReq", json)
          resJson.put("type", "updateAddrAoiId")

          List(resJson)
        } else {
          //调用db生产服务，根据check_aoiid返回dbZC
          //resJson.put("type","YDBZC")
          doDbReview(checkAoiId: String, issueResJson: JSONObject, resJson: JSONObject, citycode: String, address: String)
        }
      }

    }).persist(StorageLevel.DISK_ONLY)
    logger.error(s"共处理标准核实结果共:${normResRdd.count()}")

    normResRdd.take(2).foreach(obj => {
      logger.error(obj.toString)
    })

    logger.error(s"标准核实需要入标准库的数量:${
      normResRdd.filter(obj => {
        !JSONUtil.getJsonVal(obj, "zcTag", "").isEmpty() && obj.getString("zcTag").equals("true")
      }).count()
    }")
    normResRdd
  }

  def judgeUpdate(checkAoiId: String, mapaAoiId: String, tsAoiId: String, address: String,
                  keyword: String, checkAoiName: String, standardization: String, resJson: JSONObject
                 ) = {
    var isUpdate = false

    if (StringUtils.isNotEmpty(checkAoiId) && StringUtils.isNotEmpty(mapaAoiId) && StringUtils.isNotEmpty(tsAoiId)) {
      //check_aoiid=mapa_aoiid=ts_aoiid?
      if (checkAoiId.equals(mapaAoiId) && mapaAoiId.equals(tsAoiId))
        isUpdate = true
      else {
        // check_aoiid=ts_aoiid&keyword和check_aoiname  相似度>=1 ? 且address不包含对面/左边/右边/向东/向西等方位词
        if (mapaAoiId.equals(tsAoiId) && !address.matches("(.*对面.*)|(.*左边.*)|(.*右边.*)|(.*向东.*)|(.*向西.*)")) {


          val checkAoiName1 = if (checkAoiName == null) checkAoiName else checkAoiName.trim

          val similarkeywordReq = similarUrl.format(keyword, checkAoiName1)
          val similarkeywordRes = Utils.retryGet(similarkeywordReq)
          resJson.put("similarkeywordReq", similarkeywordReq)
          resJson.put("similarkeywordRes", try {
            JSON.parseObject(similarkeywordRes)
          } catch {
            case e: Exception => new JSONObject().put("error", e + "\n" + similarkeywordRes)
          })

          //check_aoiname  相似度>=1
          if (StringUtils.isNotEmpty(similarkeywordRes) && similarkeywordRes.toDouble > 1)
            isUpdate = true
          else {
            val similarStaReq = similarUrl.format(standardization, checkAoiName1)
            val similarStaRes = Utils.retryGet(similarStaReq)

            resJson.put("similarStaReq", similarStaReq)
            resJson.put("similarStaRes", try {
              JSON.parseObject(similarStaRes)
            } catch {
              case e: Exception => new JSONObject().put("error", e + "\n" + similarStaRes)
            })

            //check_aoiname相似度>=0.7
            if (StringUtils.isNotEmpty(similarStaRes) && similarStaRes.toDouble > 0.7)
              isUpdate = true
          }
        }
      }
    }

    isUpdate
  }

  def doDbReview(checkAoiId: String, issueResJson: JSONObject, resJson: JSONObject, citycode: String, address: String) = {
    val dbZcReq = dbZcUrl.format(checkAoiId)
    val dbZcRes = Utils.retryGet(dbZcReq)
    val deppoonZc = issueResJson.getJSONObject("info").getString("depponZc")

    //--CXG 获取ZC
    val reZc = resJson.getString("reZc")


    resJson.put("issueResJson", issueResJson)
    resJson.put("dbZcReq", dbZcReq)
    resJson.put("dbZcRes", try {
      JSON.parseObject(dbZcRes)
    } catch {
      case e: Exception => new JSONObject().put("error", e + "\n" + dbZcRes)
    })

    val zcJsonArray = try {
      //获取德邦zc
      JSON.parseObject(dbZcRes).getJSONObject("result").getJSONArray("deppon")
    } catch {
      case _ => null
    }

    var zcList = List[String]()

    if (zcJsonArray != null) {
      if (zcJsonArray.size() == 1)
        zcList = zcJsonArray.getJSONObject(0).getString("dept") :: zcList
      //如果返回ZC个数为2，且2个ZC相等，取其中一个zc返回；若2个ZC不相等，则2个都返回
      else {
        val zc1 = zcJsonArray.getJSONObject(0).getString("dept")
        val zc2 = zcJsonArray.getJSONObject(1).getString("dept")

        if (zc1.equals(zc2))
          zcList = zc1 :: zcList
        else {
          zcList = zc1 :: zcList
          zcList = zc2 :: zcList
        }
      }





      //check_aoiid对应dbZC包含deppoonZc:zcList里的就是dbZc
      if (zcList != null) {
        for (i <- Range(0, zcList.size)) yield {

          //check_aoiid对应的dbZC等于Zc  判断是否要入配置表
          if (StringUtils.isNotEmpty(reZc) && StringUtils.isNotEmpty(zcList(i)) && zcList(i).equals(reZc)) {
            resJson.put("zcTag", "true")
          } else {
            resJson.put("type", "normNoProcess")
          }


          if (StringUtils.isNotEmpty(deppoonZc) && StringUtils.isNotEmpty(zcList(i)) && zcList(i).contains(deppoonZc)) {
            val checkX = resJson.getString("checkX")
            val checkY = resJson.getString("checkY")
            //获取德邦Tc接口
            val tcCode = scheduleDBTcInterface(checkX, checkY)
            resJson.put("tc", tcCode)

            //1、先将地址压审补库
            val addrReviewReq = addrReviewUrl.format(citycode, URLEncoder.encode(address, "utf-8"), zcList(i), tcCode)
            //生产
            resJson.put("addrReviewReq", addrReviewReq)
            try {
              val addrReviewRes = Utils.retryGet(addrReviewReq)
              //resJson.put("addrReviewRes", addrReviewRes)
              resJson.put("addrReviewRes", try {
                JSON.parseObject(addrReviewRes)
              } catch {
                case e: Exception => new JSONObject().put("error", e + "\n" + addrReviewRes)
              })
            } catch {
              case e: Exception =>
                resJson.put("addrReviewRes", "err" + "\n" + e)
            }

            //2、根据城市对压入审补数据生效url
            val cityReviewReq = cityReviewUrl.format(citycode)
            //生产
            val cityReviewRes = Utils.retryGet(cityReviewReq)
            resJson.put("cityReviewRes", cityReviewRes)
            resJson.put("cityReviewReq", cityReviewReq)
            /*resJson.put("cityReviewReS",try {JSON.parseObject(cityReviewReS)} catch {case e:Exception => new JSONObject().put("error",e +"\n"+ cityReviewReS)})*/

            resJson.put("type", "dbReview")
          } else {
            resJson.put("type", "normNoProcess")
          }
          resJson
        }
      } else {
        resJson.put("type", "notDbZc2")
        List(resJson)
      }

    } else {
      resJson.put("type", "notDbZc")
      List(resJson)
    }

  }


  def processShenbuData(verifyDetailShenbuRdd: RDD[(String, String, String, JSONObject, JSONObject, Boolean, Boolean)]) = {
    logger.error("开始处理审补结果为1的数据")

    val shenbuResRdd = verifyDetailShenbuRdd.map(obj => {
      val (issueType, citycode, zc, resJson, issueResJson, flag1, flag2) = obj

      if (!Array("1", "2").contains(resJson.getString("checkDataType"))) {
        resJson.put("type", "noProcess")
        resJson
      } else {
        val address = issueResJson.getString("address")
        val checkAoiId = resJson.getString("checkAoiId")
        val src = issueResJson.getString("src")

        //调用容灾接口
        val atdispatchReq = atdispatchUrl.format(citycode, URLEncoder.encode(address, "utf-8"))
        val atdispatchRes = Utils.retryGet(atdispatchReq, logger)
        resJson.put("atdispatchReq", atdispatchReq)
        resJson.put("atdispatchRes", try {
          JSON.parseObject(atdispatchRes)
        } catch {
          case e: Exception => new JSONObject().put("error", e + "\n" + atdispatchRes)
        })

        val aoiId_zh = try {
          JSON.parseObject(atdispatchRes).getJSONObject("result").getJSONObject("tcs").getString("aoiid")
        } catch {
          case _ => ""
        }


        //aoiid为空
        if (aoiId_zh.isEmpty) {
          resJson.put("getdbZC", "true")
        }



        //审补下线
        if (StringUtils.isNotEmpty(aoiId_zh) && aoiId_zh.equals(checkAoiId)) {
          //address src='chkn'?
          if ("chkn".equals(src)) {
            val jo = new JSONObject()
            jo.put("ak", "3a191e7427e8470c86271a069411c66b")
            jo.put("operSource", "DB")
            jo.put("operUserName", "1394694")

            val addressDel = new JSONObject()

            addressDel.put("cityCode", citycode)
            addressDel.put("address", address)
            //addressDel.put("address",URLEncoder.encode(address,"utf-8"))
            addressDel.put("type", 2)
            jo.put("addressDel", addressDel)
            //线上生产
            val deleteRgsbAddrRes = SparkUtils.doPost(deleteRgsbAddrUrl, jo, logger)
            resJson.put("deleteRgsbAddrRes", deleteRgsbAddrRes)
            resJson.put("type", "deleteRgsbAddr")
            resJson.put("deleteRgsbAddrReq", jo)
            /*resJson.put("deleteRgsbAddrRes",try {JSON.parseObject(deleteRgsbAddrRes)} catch {case e:Exception => new JSONObject().put("error",e +"\n"+ deleteRgsbAddrRes)})*/
            resJson
          } else {
            resJson.put("type", "cmsNoProcess")
            resJson.put("getdbZC", "true")
            resJson
          }
        } else {
          //入库逻辑压入cms审补库

          val jo = new JSONObject()
          jo.put("ak", "3a191e7427e8470c86271a069411c66b")
          jo.put("operSource", "DB")
          jo.put("operUserName", "1394694")
          val addressSave = new JSONObject()
          addressSave.put("cityCode", citycode)
          addressSave.put("address", address)
          addressSave.put("znoCode", zc)
          addressSave.put("aoiId", checkAoiId)
          jo.put("addressSave", addressSave)

          //生产
          val cmsReviewRes = SparkUtils.doPost(cmsReviewUrl, jo, logger)
          resJson.put("cmsReviewRes", try {
            JSON.parseObject(cmsReviewRes)
          } catch {
            case e: Exception => new JSONObject().put("error", e + "\n" + cmsReviewRes)
          })
          resJson.put("cmsReviewReq", jo)
          resJson.put("type", "cmsReview")
          resJson.put("getdbZC", "true")
          resJson
        }
      }
    }).persist(StorageLevel.DISK_ONLY)

    logger.error(s"共处理审补核实结果共:${shenbuResRdd.count()}")

    shenbuResRdd
  }
}
