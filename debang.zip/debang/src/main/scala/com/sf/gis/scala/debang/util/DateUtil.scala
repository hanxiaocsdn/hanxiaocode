package com.sf.gis.scala.debang.util

import java.text.{ParseException, SimpleDateFormat}
import java.util.{Calendar, Date}

import scala.collection.mutable.ArrayBuffer

/**
  * Created by 01375125 on 2019/4/3.
  */
object DateUtil {


  /**
    * 获取本机日历日期的字符串数字
    * @param size
    * @return
    */
  def getDateStr(size: Int, separator:String): String = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val cal = Calendar.getInstance()
    cal.add(Calendar.DATE, size)
    val date = sdf.format(cal.getTime)
    date
  }

  /**
    * 获取本机日历日期字符串，默认无分隔符
    * @param size
    * @return
    */
  def getDateStr(size: Int): String = {
    val incDay = getDateStr(size,"")
    incDay
  }



  /**
    * 获取昨日，无分隔符
    * @return
    */
  def getYesterday: String ={
    getDateStr(-1,"")
  }

  /**
    * 获取昨日
    * @param sep 分隔符
    * @return
    */
  def getYesterday(sep:String): String ={
    getDateStr(-1,sep)
  }

  /**
    * 获取今天，默认""分隔
    * @return
    */
  def getToday: String ={
    getDateStr(0,"")
  }

  /**
    * 获取今天
    * @param sep 日期分隔符
    * @return
    */
  def getToday(sep:String): String ={
    getDateStr(0,sep)
  }


  /**
    * 获取Date格式的相距天数为size的Date结果
    * @param inputDate
    * @param size
    * @return
    */
  def getDateNum(inputDate:Date,size:Int): Date ={
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, size)
    val outPutDate = tempDate.getTime
    outPutDate
  }

  /**
    * 获得两个字符串日期中所有日期的字符格式集合(左闭右开)
    * @param startDateStr
    * @param endDateStr
    * @return
    */
  def getTwoDatesStr(startDateStr: String, endDateStr: String,separator:String): ArrayBuffer[String] = {
    val sdf = new SimpleDateFormat("yyyy"+separator+"MM"+separator+"dd")
    val dateListStr = new ArrayBuffer[String]
    try {
      var startDate:Date = sdf.parse(startDateStr)
      var endDate:Date = sdf.parse(endDateStr)
      val dateList = getBetweenDates(getDateNum(startDate,-1), endDate)
      for(date <- dateList) dateListStr += (sdf.format(date))
    } catch {
      case e: ParseException => println(">>>日期转换异常"+e)
    }
    dateListStr
  }

  /**
    * 获得两个字符串日期中所有日期的字符格式集合(左闭右开)
    * @param startDateStr
    * @param endDateStr
    * @return
    */
  def getTwoDatesStr(startDateStr: String, endDateStr: String): ArrayBuffer[String] = {
    getTwoDatesStr(startDateStr,endDateStr,"")
  }

  /**
    * 获取某天字符日期之前、后几天的日期字符串
    * @param inputDateStr 日期
    * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
    * @param separator 日期分隔符
    * @return
    */
  def getDateStr(inputDateStr:String, num:Int, separator:String): String ={
    val dateStrFormat = "yyyy"+separator+"MM"+separator+"dd"
    val sdf = new SimpleDateFormat(dateStrFormat)
    var inputDate:Date = sdf.parse(inputDateStr)
    val tempDate = Calendar.getInstance
    tempDate.setTime(inputDate)
    tempDate.add(Calendar.DAY_OF_YEAR, num)
    val outPutDate = tempDate.getTime
    val outPutDateStr = sdf.format(outPutDate)
    outPutDateStr
  }

  /**
    * 改变日期的分隔符
    * @param inputdate 输入的日期
    * @param inputSep 输入日期的分隔符
    * @param outputSep 输出日期的分隔符
    * @return
    */
  def changeDateSep(inputdate:String, inputSep:String,outputSep:String): String ={
    val inputSdf = new SimpleDateFormat("yyyy"+inputSep+"MM"+inputSep+"dd")
    val inputFormatDate:Date = inputSdf.parse(inputdate)
    val outputSdf = new SimpleDateFormat("yyyy"+outputSep+"MM"+outputSep+"dd")
    val outPutDateStr = outputSdf.format(inputFormatDate)
    outPutDateStr
  }

  /**
    * 获取某天日期之后几天的日期字符串
    * @param inputDateStr 日期
    * @param num 相隔天数 正数表示在之后n天，负数表示在之前n天
    */
  def getDateStr(inputDateStr:String, num:Int): String ={
    getDateStr(inputDateStr,num,"")
  }


  /**
    * 获得两个Date格式日期之间的所有日期列表(左右开区间)
    *
    * @param start
    * @param end
    * @return
    */
  def getBetweenDates(start: Date, end: Date): ArrayBuffer[Date] = {
    val result = new ArrayBuffer[Date]
    val tempStart = Calendar.getInstance
    tempStart.setTime(start)
    tempStart.add(Calendar.DAY_OF_YEAR, 1)
    val tempEnd = Calendar.getInstance
    tempEnd.setTime(end)
    while (tempStart.before(tempEnd)) {
      result += (tempStart.getTime)
      tempStart.add(Calendar.DAY_OF_YEAR, 1)
    }
    result
  }


  def main(args: Array[String]): Unit = {
   println(DateUtil.getDateStr(-2))
  }

}
