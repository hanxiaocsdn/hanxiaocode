//package com.sf.gis.scala.debang.kuaiYun
//
//import java.net.URLEncoder
//import java.util.Calendar
//
//import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
//import com.sf.gis.java.base.util.{FileUtil, HttpConnection}
//import com.sf.gis.java.sx.constant.util.EnumKuaiyunWdTag
//import com.sf.gis.scala.debang.util._
//import org.apache.log4j.Logger
//import org.apache.spark.broadcast.Broadcast
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.functions.lit
//import org.apache.spark.sql.{SaveMode, SparkSession}
//import org.apache.spark.storage.StorageLevel
//
///**
// * Created by 01374443 on 2019/3/5.
// * * Update by 01412406 on 2021/6/23.
// */
//
//object Kuaiyun {
//  @transient lazy val logger: Logger = Logger.getLogger(Kuaiyun.getClass)
//  val appName: String = this.getClass.getSimpleName.replace("$", "")
//  val version = 1.0
//  println(version)
//  val file_prop = FileUtil.getFileProperties("conf/kuaiyun_sta.properties")
//  val seg_url = file_prop.getProperty("seg_url")
//  val seg_partition = file_prop.getProperty("seg_partition").toInt
//  val seg_ak_limit = (file_prop.getProperty("seg_ak_limit").toInt * 0.95) / seg_partition
//  val common_partition = file_prop.getProperty("common_partition").toInt
//  val mapa_url = file_prop.getProperty("mapa_url")
//  val ts_url = file_prop.getProperty("ts_url")
//  val xy_aoi_url = file_prop.getProperty("xy_aoi_url")
//  val xy_aoi_ak = file_prop.getProperty("xy_aoi_ak")
//  val team_Code = file_prop.getProperty("team_Code")
//
//  case class KuaiyunCover(
//                           id: String,
//                           cityCode: String,
//                           city: String,
//                           validCnt: Int,
//                           zcEmptyCnt: Int,
//                           zcEmptyXySucCnt: Int,
//                           zcEmptyXyEmptyCnt: Int,
//                           zcSucCnt: Int,
//                           addressEmptyCnt: Int,
//                           CREATETIME: String,
//                           CREATEUSER: String,
//                           MODIFYTIME: String,
//                           MODIFYUSER: String,
//                           region: String,
//                           area: String
//                         )
//
//
//  //CXG
//  case class KuaiyunWd(
//                        id: String,
//                        cityCode: String,
//                        city: String,
//                        totalCnt: Int,
//                        multiReq: Int,
//                        multiSign: Int,
//                        rightCnt: Int,
//                        drop: Int,
//                        destModify: Int,
//                        notLocalCity: Int,
//                        signWrong: Int,
//                        wd: Int,
//                        wdGdss: Int,
//                        wdEds: Int,
//                        notCover: Int,
//                        addressEmptyCnt: Int,
//                        drawWrong: Int,
//                        outletsNoExist: Int,
//                        CREATETIME: String = null,
//                        CREATEUSER: String = null,
//                        MODIFYTIME: String = null,
//                        MODIFYUSER: String = null,
//                        region: String,
//                        area: String
//                      )
//
//  def queryOriginReqData(spark: SparkSession, startDay: String, endDay: String): RDD[(String, JSONObject)] = {
//    val sql = "select distinct get_json_object(log,'$.message') from dm_gis.kuaiyun_log_flink " +
//      s" where inc_day between '$startDay' and '$endDay'  "
//    logger.error(sql)
//    val dataRdd = spark.sql(sql).rdd.map(obj => {
//      val json = JSONUtil.parseJSONObject(obj.getString(0))
//      val request = JSONUtil.parseJSONObject(json.getString("request"))
//      val response = JSONUtil.parseJSONObject(json.getString("response"))
//      val reqWaybillNo = JSONUtil.getJsonVal(request, "waybillNo", "")
//      val reqAddress = JSONUtil.getJsonVal(request, "address", "")
//      val reTeamCode = JSONUtil.getJsonVal(response, "teamCode", "")
//      val aoiId = JSONUtil.getJsonVal(response, "aoiId", "")
//      // --CXG 取Citycode
//      val meCityCode = JSONUtil.getJsonVal(response, "cityCode", "")
//
//      val ret = new JSONObject()
//      ret.put("reqWaybillNo", reqWaybillNo)
//      ret.put("reqAddress", reqAddress)
//      ret.put("reTeamCode", reTeamCode)
//      ret.put("aoiId", aoiId)
//      ret.put("meCityCode", meCityCode)
//      ret.put("cnt", 1)
//      (reqWaybillNo, ret)
//    }).filter(obj => !obj._1.isEmpty)
//      //      .reduceByKey((obj1, obj2) => {
//      //        obj1.put("cnt", obj1.getInteger("cnt") + obj2.getInteger("cnt"))
//      //      obj1
//      //    })
//      .persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("请求单量总数:" + dataRdd.count())
//    dataRdd.take(10).foreach(obj => {
//      logger.error(obj._2.toJSONString)
//    })
//    dataRdd
//  }
//
//  def querySignData(spark: SparkSession, startTime: String, endTime: String, incDay: String): (RDD[(String, JSONObject)], RDD[(String, Int)]) = {
//    logger.error("获取签收数据")
//    val sql = s" select waybill_no,unit_code,dest_city_code,dest_city_name	" +
//      s" from dm_heavy_cargo.receiving_delivery_detail_report where inc_day between '$incDay' and '$incDay' " +
//      s" and data_type='派件' and Sy_or_ky='快运' "
//    logger.error(sql)
//    val signDataRdd = spark.sql(sql).rdd.map(obj => {
//      val json = new JSONObject()
//      json.put("waybillno", obj.getString(0))
//      json.put("tc", obj.getString(1))
//      json.put("cityCode", obj.getString(2))
//      json.put("cityName", obj.getString(3))
//      (json.getString("waybillno"), json)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("快运签收单号总数量：" + signDataRdd.count())
//    logger.error("获取多次签收单号")
//
//    val multiSql = s" select waybill_no 	" +
//      s" from dm_heavy_cargo.receiving_delivery_detail_report where inc_day between '$startTime' and '$endTime' " +
//      s" and data_type='派件' and Sy_or_ky='快运' " +
//      s" group by waybill_no having count(waybill_no)>1 "
//    logger.error(sql)
//    val multiDataRdd = spark.sql(multiSql).rdd.map(obj => {
//      (obj.getString(0), 1)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("快运多次签收单号总数量：" + multiDataRdd.count())
//    multiDataRdd.take(10).foreach(x => {
//      logger.error(x)
//    })
//    (signDataRdd, multiDataRdd)
//  }
//
//
//  def joinOriginData(originReqRdd: RDD[(String, JSONObject)], signDataRdd: RDD[(String, JSONObject)], multiDataRdd: RDD[(String, Int)],
//                     ttWaybillInfoRdd: RDD[(String, (String, String, String, String))]): RDD[JSONObject] = {
//
//
//    val joinDataOriginReqRdd = originReqRdd.leftOuterJoin(signDataRdd).map({ obj =>
//      val key = obj._1
//      val left = obj._2._1
//      val rightOp = obj._2._2
//      if (rightOp.nonEmpty) {
//        val rightBody = rightOp.get
//        left.put("ct", JSONUtil.getJsonVal(rightBody, "tc", ""))
//      }
//      (key, left)
//    }).reduceByKey((obj1, obj2) => {
//      val obj1Tc = JSONUtil.getJsonVal(obj1, "ct", "")
//      val obj2Tc = JSONUtil.getJsonVal(obj2, "ct", "")
//      if (!obj1Tc.isEmpty && !obj2Tc.isEmpty && !obj1Tc.equals(obj2Tc)) {
//        obj1.put("cnt", obj1.getInteger("cnt") + obj2.getInteger("cnt"))
//      }
//      obj1
//    })
//
//
//    val joinDataRdd = signDataRdd.leftOuterJoin(joinDataOriginReqRdd).map(obj => {
//      val left = obj._2._1
//      val rightOp = obj._2._2
//      if (rightOp.nonEmpty) {
//        val rightBody = rightOp.get
//        left.put("reqBody", rightBody)
//        left.put("cnt", rightBody.getInteger("cnt"))
//
//        val cnt = rightBody.getInteger("cnt")
//        if (cnt == 1) {
//          left.put("multiReq", 0)
//        } else {
//          left.put("multiReq", 1)
//        }
//
//        (obj._1, left)
//      } else {
//        (null: String, null: JSONObject)
//      }
//    }).filter(obj => obj._1 != null).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//
//
//    logger.error("签收关联到请求的数量:" + joinDataRdd.count())
//    originReqRdd.unpersist()
//    signDataRdd.unpersist()
//    logger.error("关联多次签收的数据")
//
//
//    val joinCompareDataRdd = joinDataRdd.leftOuterJoin(multiDataRdd).map(obj => {
//      val left = obj._2._1
//      val rightOp = obj._2._2
//      if (rightOp.nonEmpty) {
//        left.put("multiSign", 1)
//      } else {
//        left.put("multiSign", 0)
//      }
//      (obj._1, left)
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("关联多次签收的数据:" + joinCompareDataRdd.count())
//    joinDataRdd.unpersist()
//    multiDataRdd.unpersist()
//    logger.error("关联宽表解密数据")
//    val joinWaybillRdd = joinCompareDataRdd.leftOuterJoin(ttWaybillInfoRdd).map(obj => {
//      val left = obj._2._1
//      val rightOp = obj._2._2
//      if (rightOp.nonEmpty) {
//        val right = rightOp.get
//        left.put("consigneeAddr", right._1)
//        left.put("destCityCode", right._2)
//        left.put("deliveryLgt", right._3)
//        left.put("deliveryLat", right._4)
//      }
//      left
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("关联宽表解密数据完毕：" + joinWaybillRdd.count())
//    joinCompareDataRdd.unpersist()
//    joinWaybillRdd
//  }
//
//  def queryCityMap(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
//    val sql =
//      """
//        | select max(city) as city ,citycode,max(region) as region ,max(area) as area
//        | from dm_gis.city_name_map
//        | group by citycode
//      """.stripMargin
//    logger.error(sql)
//    val cityMap = spark.sql(sql).rdd.map(obj => {
//      (obj.getString(1), obj.getString(0) + "&&" + obj.getString(2) + "&&" + obj.getString(3))
//    }).collectAsMap()
//    logger.error("城市映射表数量:" + cityMap.size)
//    spark.sparkContext.broadcast(cityMap)
//  }
//
//  //  def staCoverData(obj: JSONObject, cityNameMap: collection.Map[String, String]): KuaiyunCover = {
//  //    val validCnt = 1
//  //    var zcSucCnt = 0
//  //    var zcEmptyCnt = 0
//  //    var zcEmptyXyEmptyCnt = 0
//  //    var zcEmptyXySucCnt = 0
//  //    var addressEmptyCnt = 0
//  //    val reqAddress = JSONUtil.getJsonVal(obj, "reqBody.reqAddress", "")
//  //    val cityCode = JSONUtil.getJsonVal(obj, "cityCode", "")
//  //    val src = obj.getString("src")
//  //    val gisTc = JSONUtil.getJsonVal(obj, "reqBody.reTeamCode", "")
//  //    val city = JSONUtil.getJsonVal(obj, "city", "")
//  //    val region = JSONUtil.getJsonVal(obj, "region", "")
//  //    val area = JSONUtil.getJsonVal(obj, "area", "")
//  //    val aoiId = JSONUtil.getJsonVal(obj, "reqBody.aoiId", "")
//  //
//  //
//  //    if (reqAddress.isEmpty) {
//  //               addressEmptyCnt = 1
//  //    } else {
//  //              if (gisTc.isEmpty) {
//  //                      zcEmptyCnt = 1
//  //                      if (aoiId.isEmpty) {
//  //                        //aoid无值
//  //                        zcEmptyXyEmptyCnt = 1
//  //                      } else {
//  //                        //aoid有值
//  //                        zcEmptyXySucCnt = 1
//  //                      }
//  //      } else {
//  //               zcSucCnt = 1
//  //      }
//  //    }
//  //
//  //
//  //
//  //
//  //
//  ////    val city: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(0)
//  ////    val region: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(1)
//  ////    val area: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(2)
//  //    val md5Id =  System.currentTimeMillis().toString+city+cityCode+region+area
//  //    val id = Md5Util.MD5Encode(md5Id)
//  //
//  //
//  //    KuaiyunCover(
//  //      id,
//  //      cityCode,
//  //      city,
//  //      validCnt,
//  //      zcEmptyCnt,
//  //      zcEmptyXySucCnt,
//  //      zcEmptyXyEmptyCnt,
//  //      zcSucCnt,
//  //      addressEmptyCnt
//  //      ,null
//  //      ,null
//  //      ,null
//  //      ,null
//  //      ,region
//  //      ,area
//  //    )
//  //  }
//
//
//  def staCoverData(obj: JSONObject): KuaiyunCover = {
//    val validCnt = 1
//    var zcSucCnt = 0
//    var zcEmptyCnt = 0
//    var zcEmptyXyEmptyCnt = 0
//    var zcEmptyXySucCnt = 0
//    var addressEmptyCnt = 0
//    val reqAddress = JSONUtil.getJsonVal(obj, "reqBody.reqAddress", "")
//    val gisTc = JSONUtil.getJsonVal(obj, "reqBody.reTeamCode", "")
//    val cityCode = JSONUtil.getJsonVal(obj, "cityCode", "")
//    val src = obj.getString("src")
//    val city = JSONUtil.getJsonVal(obj, "city", "")
//    val region = JSONUtil.getJsonVal(obj, "region", "")
//    val area = JSONUtil.getJsonVal(obj, "area", "")
//    val aoiId = JSONUtil.getJsonVal(obj, "reqBody.aoiId", "")
//
//
//    if (reqAddress.isEmpty) {
//      addressEmptyCnt = 1
//    } else {
//      if (gisTc.isEmpty) {
//        zcEmptyCnt = 1
//        if (aoiId.isEmpty) {
//          //aoid无值
//          zcEmptyXyEmptyCnt = 1
//        } else {
//          //aoid有值
//          zcEmptyXySucCnt = 1
//        }
//      } else {
//        zcSucCnt = 1
//      }
//    }
//
//
//    //    val city: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(0)
//    //    val region: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(1)
//    //    val area: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(2)
//    val md5Id = System.currentTimeMillis().toString + city + cityCode + region + area
//    val id = Md5Util.MD5Encode(md5Id)
//
//
//    KuaiyunCover(
//      id,
//      cityCode,
//      city,
//      validCnt,
//      zcEmptyCnt,
//      zcEmptyXySucCnt,
//      zcEmptyXyEmptyCnt,
//      zcSucCnt,
//      addressEmptyCnt
//      , null
//      , null
//      , null
//      , null
//      , region
//      , area
//    )
//  }
//
//
//  def mergeKuaiyunCover(obj1: KuaiyunCover, obj2: KuaiyunCover): KuaiyunCover = {
//    val cityCode = obj1.cityCode
//    val id = obj1.id
//    val city = obj1.city
//    val region = obj1.region
//    val area = obj1.area
//    val CREATETIME = obj1.CREATETIME
//    val CREATEUSER = obj1.CREATEUSER
//    val MODIFYTIME = obj1.MODIFYTIME
//    val MODIFYUSER = obj1.MODIFYUSER
//    val validCnt = obj1.validCnt + obj2.validCnt
//    val zcEmptyCnt = obj1.zcEmptyCnt + obj2.zcEmptyCnt
//    val zcEmptyXySucCnt = obj1.zcEmptyXySucCnt + obj2.zcEmptyXySucCnt
//    val zcEmptyXyEmptyCnt = obj1.zcEmptyXyEmptyCnt + obj2.zcEmptyXyEmptyCnt
//    val zcSucCnt = obj1.zcSucCnt + obj2.zcSucCnt
//    val addressEmptyCnt = obj1.addressEmptyCnt + obj2.addressEmptyCnt
//
//    KuaiyunCover(
//      id,
//      cityCode,
//      city,
//      validCnt,
//      zcEmptyCnt,
//      zcEmptyXySucCnt,
//      zcEmptyXyEmptyCnt,
//      zcSucCnt,
//      addressEmptyCnt,
//      CREATETIME,
//      CREATEUSER,
//      MODIFYTIME,
//      MODIFYUSER,
//      region,
//      area
//    )
//  }
//
//
//  //CXG
//  def staWdData(cityCode: String, city: String, region: String, area: String, obj: JSONObject): KuaiyunWd = {
//
//    val Md5Id = System.currentTimeMillis().toString + city + cityCode + region + area
//    val id = Md5Util.MD5Encode(Md5Id)
//
//
//    val tag = obj.getString("tag")
//    var totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist = 0
//    totalCnt = 1
//    if (tag.equals(EnumKuaiyunWdTag.addressEmpty)) {
//      addressEmptyCnt = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    if (tag.equals(EnumKuaiyunWdTag.multiReq)) {
//      multiReq = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    if (tag.equals(EnumKuaiyunWdTag.multiSign)) {
//      multiSign = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    if (tag.equals(EnumKuaiyunWdTag.drop)) {
//      drop = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    if (tag.equals(EnumKuaiyunWdTag.gisEmpty)) {
//      notCover = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//
//    if (tag.equals(EnumKuaiyunWdTag.same)) {
//      rightCnt = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//
//    //    if (tag.equals(EnumKuaiyunWdTag.sameTeamCode)) {
//    //      sameTeamCode = 1
//    //      return KuaiyunWd(cityCode, city, totalCnt, multiReq, multiSign, right, drop,sameTeamCode,destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist)
//    //    }
//
//
//    if (tag.equals(EnumKuaiyunWdTag.destAddressModify)) {
//      destModify = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    if (tag.equals(EnumKuaiyunWdTag.signNotLocalCity)) {
//      notLocalCity = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//
//    //CXG--
//    if (tag.equals(EnumKuaiyunWdTag.drawWrong)) {
//      drawWrong = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    if (tag.equals(EnumKuaiyunWdTag.outletsNoExist)) {
//      outletsNoExist = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    //--CXG
//
//    if (tag.equals(EnumKuaiyunWdTag.allDeptSame)) {
//      signWrong = 1
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//
//    if (tag.isEmpty) {
//      wd = 1
//      val tc = JSONUtil.getJsonVal(obj, "tc", "")
//      val gisAoiId = JSONUtil.getJsonVal(obj, "reqBody.aoiId", "")
//      if (!tc.isEmpty && gisAoiId.isEmpty) {
//        wdGdss = 1
//      } else if (!gisAoiId.isEmpty && !tc.isEmpty) {
//        wdEds = 1
//      }
//      return KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//    }
//    KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//  }
//
//  def mergeKuaiyunWd(obj1: KuaiyunWd, obj2: KuaiyunWd): KuaiyunWd = {
//    val cityCode = obj1.cityCode
//    val city = obj1.city
//    val region = obj1.region
//    val area = obj1.area
//    val id = obj1.id
//    val totalCnt = obj1.totalCnt + obj2.totalCnt
//    val multiReq = obj1.multiReq + obj2.multiReq
//    val multiSign = obj1.multiSign + obj2.multiSign
//    val rightCnt = obj1.rightCnt + obj2.rightCnt
//    val drop = obj1.drop + obj2.drop
//    val destModify = obj1.destModify + obj2.destModify
//    val notLocalCity = obj1.notLocalCity + obj2.notLocalCity
//    val signWrong = obj1.signWrong + obj2.signWrong
//    val wd = obj1.wd + obj2.wd
//    val wdGdss = obj1.wdGdss + obj2.wdGdss
//    val wdEds = obj1.wdEds + obj2.wdEds
//    val notCover = obj1.notCover + obj2.notCover
//    val addressEmptyCnt = obj1.addressEmptyCnt + obj2.addressEmptyCnt
//    val drawWrong = obj1.drawWrong + obj2.drawWrong
//    val outletsNoExist = obj1.outletsNoExist + obj2.outletsNoExist
//    KuaiyunWd(id, cityCode, city, totalCnt, multiReq, multiSign, rightCnt, drop, destModify, notLocalCity, signWrong, wd, wdGdss, wdEds, notCover, addressEmptyCnt, drawWrong, outletsNoExist, null, null, null, null, region, area)
//  }
//
//
//  def staIndex(checkOverRdd: RDD[JSONObject]): RDD[(KuaiyunCover, KuaiyunWd)] = {
//    //cxg 剔除运单宽表【ods_kafka_fvp.fvp_core_fact_route】获取【opcode】=‘99’的运单【waybillno】
//    val indexRdd = checkOverRdd.filter(obj => {
//      JSONUtil.getJsonVal(obj, "tctag", "").isEmpty()
//    }).map(obj => {
//      val staCoverObj = staCoverData(obj)
//      val staWdObj = staWdData(staCoverObj.cityCode, staCoverObj.city, staCoverObj.region, staCoverObj.area, obj)
//      ((staCoverObj.cityCode, staCoverObj.city, staCoverObj.region, staCoverObj.area), (staCoverObj, staWdObj))
//    }).reduceByKey((obj1, obj2) => {
//      val staCoverObj = mergeKuaiyunCover(obj1._1, obj2._1)
//      val staWdObj = mergeKuaiyunWd(obj1._2, obj2._2)
//      (staCoverObj, staWdObj)
//    }).values.persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("聚合后数量:" + indexRdd.count())
//    indexRdd
//  }
//
//  //  def saveStaIndex(spark: SparkSession, staIndexRdd: RDD[(KuaiyunCover,KuaiyunWd)], incDay: String):Unit = {
//  //    import spark.implicits._
//  //    val rowDf = staIndexRdd.map(obj=>obj._1).toDF()
//  //    logger.error("数量："+rowDf.count())
//  ////    val tableName = "tmp_dm_gis.tmp_cover_kuaiyun_cover_cnt"
//  //  val tableName = "tmp_dm_gis.tmp_test_cover_kuaiyun_cover_cnt"//测试备份表
//  //    rowDf.withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
//  //
//  //    val wdDf = staIndexRdd.map(obj=>obj._2).toDF()
//  //    logger.error("错分数量："+wdDf.count())
//  ////    val wdTableName = "tmp_dm_gis.tmp_cover_kuaiyun_wd_cnt"
//  //    val wdTableName = "tmp_dm_gis.tmp_test_cover_kuaiyun_wd_cnt"//测试备份表
//  //    wdDf.withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(wdTableName)
//  //  }
//
//  def checkWdDetail(obj: JSONObject): String = {
//
//    val reqBody = obj.getJSONObject("reqBody")
//    val reqAddress = JSONUtil.getJsonVal(reqBody, "reqAddress", "")
//    if (reqAddress.isEmpty) {
//      return EnumKuaiyunWdTag.addressEmpty
//    }
//
//    val multiReq = obj.getInteger("multiReq")
//    if (multiReq == 1) {
//      return EnumKuaiyunWdTag.multiReq
//    }
//
//    val multiSign = obj.getInteger("multiSign")
//    if (multiSign == 1) {
//      return EnumKuaiyunWdTag.multiSign
//    }
//
//    val signTc = JSONUtil.getJsonVal(obj, "tc", "")
//    if (signTc.isEmpty) {
//      return EnumKuaiyunWdTag.drop
//    }
//    val gisTc = JSONUtil.getJsonVal(reqBody, "reTeamCode", "")
//    if (gisTc.isEmpty) {
//      return EnumKuaiyunWdTag.gisEmpty
//    }
//    if (signTc.equals(gisTc)) {
//      return EnumKuaiyunWdTag.same
//    }
//    ""
//  }
//
//  def runSeg(needSegTagRdd: RDD[JSONObject]): RDD[JSONObject] = {
//    val segRsltRdd = needSegTagRdd.repartition(seg_partition).mapPartitions(row => {
//      var lastMin = Calendar.getInstance().get(Calendar.MINUTE)
//      var timeInt = 0
//      var partitionsCount = 0
//      row.map(obj => {
//        partitionsCount = partitionsCount + 1
//        if (partitionsCount % 10000 == 0) {
//          logger.error(partitionsCount)
//        }
//        val second = Calendar.getInstance().get(Calendar.SECOND)
//        val cur = Calendar.getInstance().get(Calendar.MINUTE)
//        if (cur == lastMin) {
//          timeInt = timeInt + 1
//          if (timeInt >= seg_ak_limit) {
//            logger.error("秒数:" + cur + ",次数：" + timeInt + ",总数：" + partitionsCount)
//            Thread.sleep((60 - second) * 1000)
//          }
//        } else {
//          timeInt = 1
//          lastMin = cur
//        }
//        val (segCityCode, ret) = getSeg(seg_url, JSONUtil.getJsonVal(obj, "consigneeAddr", ""))
//        obj.put("segCityCode", segCityCode)
//        obj.put("segRet", ret)
//        obj
//      })
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("seg跑数结果数量:" + segRsltRdd.count())
//    needSegTagRdd.unpersist()
//    val segRsltTagRdd = segRsltRdd.map(obj => {
//      val segCityCode = obj.getString("segCityCode")
//      val signCityCode = JSONUtil.getJsonVal(obj, "destCityCode", "")
//      if (!segCityCode.isEmpty && !signCityCode.isEmpty) {
//        if (!segCityCode.equals(signCityCode)) {
//          obj.put("tag", EnumKuaiyunWdTag.destAddressModify) ////修改
//        }
//      }
//
//
//      //      val signTcCityCode = JSONUtil.getJsonVal(obj, "tc", "").replaceAll("([a-zA-Z]+)([0-9]+)", "")
//      //      if (obj.getString("tag").isEmpty && !signTcCityCode.isEmpty && !segCityCode.isEmpty) {
//      //        if (!segCityCode.equals(signTcCityCode)) {
//      //          obj.put("tag", EnumKuaiyunWdTag.signNotLocalCity)
//      //        }
//      //      }
//
//      obj
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    segRsltRdd.unpersist()
//    segRsltTagRdd
//  }
//
//
//  def getSeg(url: String, address: String): (String, JSONObject) = {
//
//    var ret: JSONObject = null
//    if (address.isEmpty) {
//      return ("", ret)
//    }
//    try {
//      val finalUrl = url.format(URLEncoder.encode(address, "utf-8"))
//      ret = HttpClientUtil.getJsonByGet(finalUrl, 3)
//      if (ret != null && ret.getJSONObject("result") != null) {
//        if (ret.getJSONObject("result").getInteger("err") == 109) {
//          val second = Calendar.getInstance().get(Calendar.SECOND)
//          Thread.sleep(60 - second)
//          return getSeg(url, null)
//        }
//        val cityCode = JSONUtil.getJsonVal(ret, "result.data.citycode", "")
//        return (cityCode, ret)
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//    }
//    ("", ret)
//  }
//
//  def runXy(needXyTagRdd: RDD[JSONObject]): RDD[JSONObject] = {
//    logger.error("跑mapA和网点")
//    val mapARdd = runMapAoi(needXyTagRdd, mapa_url, "mapAXy", xy_aoi_url).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("mapA跑完网点不为空总数：" + mapARdd.filter(obj => !JSONUtil.getJsonVal(obj, "mapAXyAoi", "").isEmpty).count())
//    needXyTagRdd.unpersist()
//    mapARdd.take(2).foreach(obj => {
//      logger.error(obj.toJSONString)
//    })
//    logger.error("跑图商和Aoi")
//    val tsRdd = runMapAoi(mapARdd, ts_url, "tsXy", xy_aoi_url)
//    logger.error("ts跑完网点不为空总数：" + tsRdd.filter(obj => !JSONUtil.getJsonVal(obj, "tsXyAoi", "").isEmpty).count())
//    mapARdd.unpersist()
//    tsRdd.take(2).foreach(obj => {
//      logger.error(obj.toJSONString)
//    })
//    val retRdd = tsRdd.map(obj => {
//      val mapAXyAoi = JSONUtil.getJsonVal(obj, "mapAXyAoi", "")
//      val tsXyAoi = JSONUtil.getJsonVal(obj, "tsXyAoi", "")
//      val gisAoiId = JSONUtil.getJsonVal(obj, "reqBody.aoiId", "")
//      if (!mapAXyAoi.isEmpty && !tsXyAoi.isEmpty && !gisAoiId.isEmpty && tsXyAoi.equals(mapAXyAoi) && gisAoiId.equals(tsXyAoi)) {
//        obj.put("tag", EnumKuaiyunWdTag.allAoiSame)
//      }
//      obj
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("xy跑完剔除数量：" + tsRdd.filter(obj => !JSONUtil.getJsonVal(obj, "tag", "").equals(EnumKuaiyunWdTag.allAoiSame)).count())
//    tsRdd.unpersist()
//    retRdd
//  }
//
//  def runMapAoi(groupInfoRdd: RDD[JSONObject], mapUrl: String, xyType: String,
//                xyDeptUrl: String): RDD[JSONObject] = {
//    groupInfoRdd.repartition(seg_partition).map(obj => {
//      val cityCode = JSONUtil.getJsonVal(obj, "destCityCode", "")
//      val address = JSONUtil.getJsonVal(obj, "consigneeAddr", "")
//      val mapRet = runMapXyInteface(mapUrl, cityCode, address)
//      obj.put(xyType + "Body", mapRet)
//      obj
//    }).map(obj => {
//      val precision = JSONUtil.getJsonVal(obj, xyType + "Body.precision", "")
//      if ("2".equals(precision)) {
//        val x = JSONUtil.getJsonVal(obj, xyType + "Body.x", "")
//        val y = JSONUtil.getJsonVal(obj, xyType + "Body.y", "")
//        val (aoi, ret) = xy2Aoi(xyDeptUrl, x, y)
//        obj.put(xyType + "AoiBody", ret)
//        obj.put(xyType + "Aoi", aoi)
//      }
//      obj
//    })
//  }
//
//  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
//    var ret: JSONObject = null
//    try {
//      if (!cityCode.isEmpty && !address.isEmpty) {
//        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
//        val xyObj = HttpClientUtil.getJsonByGet(url)
//
//
//        if (xyObj != null && xyObj.getJSONObject("result") != null) {
//          val errCode = xyObj.getJSONObject("result").getInteger("err")
//          if (errCode == 109) {
//            val second = Calendar.getInstance().get(Calendar.SECOND)
//            Thread.sleep(60 - second)
//            return runMapXyInteface(mapUrl, cityCode, address)
//          }
//          ret = new JSONObject()
//          var status, x, y, precision = ""
//          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
//          val result = xyObj.getJSONObject("result")
//          if (result != null) {
//            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
//            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
//            if (result.getDouble("precision") != null) precision = result.getInteger("precision") + ""
//          }
//          ret.put("x", x)
//          ret.put("y", y)
//          ret.put("status", status)
//          ret.put("precision", precision)
//          ret.put("errCode", errCode)
//        }
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//    }
//    ret
//  }
//
//  def xy2Aoi(xyAoiUrl: String, lng: String, lat: String): (String, JSONObject) = {
//    var ret = null: JSONObject
//    try {
//      if (lng != null && !lng.isEmpty) {
//        val parm = new JSONObject()
//        parm.put("ak", xy_aoi_ak)
//        val xyArray = new JSONArray()
//        val xyObj = new JSONObject()
//        xyObj.put("lng", lng)
//        xyObj.put("lat", lat)
//        xyArray.add(xyObj)
//        parm.put("coords", xyArray)
//        val httpData = HttpConnection.sendPost(xyAoiUrl, parm.toJSONString)
//        if (httpData != null && httpData.containsKey("content") && httpData.get("content") != null) {
//          val content = httpData.get("content").toString
//          ret = JSON.parseObject(content)
//          if (ret != null && ret.getJSONObject("result") != null) {
//            if (ret.getJSONObject("result").getInteger("err") == 109) {
//              val second = Calendar.getInstance().get(Calendar.SECOND)
//              Thread.sleep(60 - second)
//              return xy2Aoi(xyAoiUrl, lng, lat)
//            }
//            val data = ret.getJSONObject("result").getJSONObject("data")
//            val aois = data.getJSONArray("aois")
//            if (aois != null && aois.size() != 0) {
//              val aoiData = aois.getJSONObject(0)
//              val aoi_id: String = JSONUtil.getJsonVal(aoiData, "aoi_id", "")
//              return (aoi_id, ret)
//            }
//          }
//        }
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//    }
//    ("", ret)
//  }
//
//
//  //CXG--
//  //通过经纬度获取快运单元区域 reTeamCode
//  def runTeamCode(runTeamRdd: RDD[JSONObject], teamCodeUrl: String): RDD[JSONObject] = {
//    logger.error("-------------------开始跑teamcode数量:" + runTeamRdd.count())
//
//    val runTeamRdd1 = runTeamRdd.repartition(seg_partition).map(obj => {
//      val deliveryLgt = JSONUtil.getJsonVal(obj, "deliveryLgt", "")
//      val deliveryLat = JSONUtil.getJsonVal(obj, "deliveryLat", "")
//      try {
//        if (!deliveryLgt.isEmpty && !deliveryLat.isEmpty) {
//          val url = String.format(teamCodeUrl, deliveryLgt, deliveryLat)
//          val tc: JSONObject = HttpClientUtil.getJsonByGet(url)
//          obj.put("rerunTeam", tc.toJSONString)
//          if (tc != null && tc.getJSONObject("result") != null) {
//            val tcArray = tc.getJSONObject("result").getJSONArray("map_data")
//
//            if (tcArray != null && tcArray.size() > 0) {
//              for (i <- 0 to tcArray.size() - 1) {
//                val job = tcArray.getJSONObject(i)
//                if (JSONUtil.getJsonVal(job, "level", "") == "3") {
//                  val eTeamCode = JSONUtil.getJsonVal(job, "code", "")
//                  obj.put("eTeamCode", eTeamCode)
//                }
//              }
//            }
//          }
//        }
//
//      } catch {
//        case x: Exception => logger.error(x)
//          obj.put("eTeamCode", x.toString)
//      }
//      //判断与message.teamCode是否相等
//      val eTeamCode: String = JSONUtil.getJsonVal(obj, "eTeamCode", "")
//      val reTeamCode: String = JSONUtil.getJsonVal(obj, "reqBody.reTeamCode", "")
//
//      if (!eTeamCode.isEmpty && !reTeamCode.isEmpty && eTeamCode.equals(reTeamCode)) {
//        //相等为正确量
//        obj.put("tag", EnumKuaiyunWdTag.same)
//      }
//      obj
//    })
//    runTeamRdd1
//  }
//
//  //--CXG
//
//
//  def queryTcAoi(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
//    val sql = "SELECT tc,cover_aoi FROM dm_gis.emap_ky_tc_aoi_quantity_report where rec_type='kytc' group by tc,cover_aoi"
//    logger.error(sql)
//    val tcAoi = spark.sql(sql).rdd.map(obj => {
//      val coverAoi = obj.getString(1).replaceAll("([-]+)([\u4e00-\u9fa5]*)", "")
//      (obj.getString(0) + "_" + coverAoi, "1")
//    }).collectAsMap()
//    logger.error("Tc_Aoi映射表:" + tcAoi.size)
//    spark.sparkContext.broadcast(tcAoi)
//  }
//
//  def queryCode(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
//    val sql = "SELECT code FROM dm_gis.emap_layer_feature where layer_id='3' group by code"
//    logger.error(sql)
//    val Code = spark.sql(sql).rdd.map(obj => {
//      (obj.getString(0), "1")
//    }).collectAsMap()
//    logger.error("网点映射表:" + Code.size)
//    spark.sparkContext.broadcast(Code)
//  }
//
//
//  //--CXG
//  def checkWdData(spark: SparkSession, joinDataRdd: RDD[JSONObject], cityMapBc: Broadcast[collection.Map[String, String]], tcrdd: RDD[(String, Boolean)], tcCityRdd: RDD[(String, Boolean)]): RDD[JSONObject] = {
//    //判断是否剔除 return:转寄退回 ,noOperation:暂时不需要运营的城市
//    val DataRdd = joinDataRdd.map(obj => {
//      (JSONUtil.getJsonVal(obj, "waybillno", ""), obj)
//    }).leftOuterJoin(tcrdd).map(obj => {
//      val right = obj._2._1
//      if (obj._2._2.nonEmpty) {
//        right.put("tctag", "return")
//      }
//      right
//    }
//    )
//      .map(obj => {
//        //val cityCode = JSONUtil.getJsonVal(obj,"cityCode","")
//        (JSONUtil.getJsonVal(obj, "cityCode", ""), obj)
//      }).leftOuterJoin(tcCityRdd).map(
//      obj => {
//        val right = obj._2._1
//        if (obj._2._2.isEmpty) {
//          right.put("tctag", "noOperation")
//        }
//        right
//      }
//    ).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//
//    logger.error(DataRdd.take(10).foreach(println(_)))
//
//
//    logger.error("开始打标签")
//    val checkTagRdd = DataRdd.map(obj => {
//      val tag = checkWdDetail(obj)
//      obj.put("tag", tag)
//      obj
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//
//    //CXG-- 判断判断80经纬度对应的快递单元区域与code是否一致
//    val runTeamCodeRdd = checkTagRdd.filter(obj => obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rsltRdd1 = checkTagRdd.filter(obj => !obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("确定的数量:" + rsltRdd1.count())
//    logger.error("需要跑TeamCode数量:" + runTeamCodeRdd.count())
//    checkTagRdd.unpersist()
//    val teamCdeTagRdd: RDD[JSONObject] = runTeamCode(runTeamCodeRdd, team_Code)
//    //--CXG
//
//    val needSegTagRdd = teamCdeTagRdd.filter(obj => obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rsltRdd2 = teamCdeTagRdd.filter(obj => !obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("TeamCode确定的数量:" + rsltRdd2.count())
//    logger.error("需要跑seg数量:" + needSegTagRdd.count())
//    teamCdeTagRdd.unpersist()
//    logger.error("开始跑seg")
//    val segTagRdd = runSeg(needSegTagRdd)
//
//    //CXG--
//    //判断解析到的城市与日志返回的message.citycode是否一致   --CXG
//    val cityCodeTagRdd = segTagRdd.filter(obj => obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rsltRdd3 = segTagRdd.filter(obj => !obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("seg确定的数量:" + rsltRdd3.count())
//    logger.error("需要确定城市与日志citycode的数量:" + cityCodeTagRdd.count())
//    segTagRdd.unpersist()
//
//    val cityCodeTagRdd1 = cityCodeTagRdd.map(obj => {
//      //      val signTcCityCode:String = JSONUtil.getJsonVal(obj, "tc", "")
//      val signTcCityCode = JSONUtil.getJsonVal(obj, "tc", "").replaceAll("([a-zA-Z]+)([0-9]+)", "")
//      val meCityCode: String = JSONUtil.getJsonVal(obj, "reqBody.meCityCode", "")
//      if (!signTcCityCode.isEmpty && !meCityCode.isEmpty && !signTcCityCode.equals(meCityCode)) {
//        obj.put("tag", EnumKuaiyunWdTag.signNotLocalCity)
//      }
//      obj
//    }
//    ).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    //判断签收单元区域（unit_code）和系统识别到的AOI（aoiid），是否存在于绘制区域质量表中  --CXG
//    val wdTagRdd = cityCodeTagRdd1.filter(obj => obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rsltRdd4 = cityCodeTagRdd1.filter(obj => !obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("城市与日志citycode不一致的数量:" + rsltRdd4.count())
//    logger.error("需要匹配绘制区域质量表的数量:" + wdTagRdd.count())
//    logger.error("获取绘制区域区域质量表")
//    cityCodeTagRdd.unpersist()
//    cityCodeTagRdd1.unpersist()
//    val tcAoiMap = queryTcAoi(spark)
//
//    val wdTagRdd1 = wdTagRdd.map(obj => {
//      val tc: String = JSONUtil.getJsonVal(obj, "tc", "")
//      val aoiId: String = JSONUtil.getJsonVal(obj, "reqBody.aoiId", "")
//      val tcAoi = tc + "_" + aoiId
//      obj.put("tcAoi", tcAoi)
//      val tcAoiTag: String = tcAoiMap.value.applyOrElse(tcAoi, { num: String => "" })
//      if (!tcAoiTag.isEmpty) {
//        obj.put("tag", EnumKuaiyunWdTag.drawWrong)
//      }
//      obj
//    })
//
//
//    //识别网点是否存在？
//    val CodeTagRdd = wdTagRdd1.filter(obj => obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rsltRdd5 = wdTagRdd1.filter(obj => !obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("绘制区域质量表不存在的数量:" + rsltRdd5.count())
//    logger.error("需要网点识别的数量:" + CodeTagRdd.count())
//    wdTagRdd.unpersist()
//    wdTagRdd1.unpersist()
//    logger.error("获取网点识别表")
//    val codeMap = queryCode(spark)
//    val CodeTagRdd1 = CodeTagRdd.map(obj => {
//      val teamCode = JSONUtil.getJsonVal(obj, "reqBody.reTeamCode", "")
//      val CodeTag: String = codeMap.value.applyOrElse(teamCode, { num: String => "" })
//      if (CodeTag.isEmpty) {
//        obj.put("tag", EnumKuaiyunWdTag.outletsNoExist)
//      }
//      obj
//    })
//    //--CXG
//
//
//    val needXyTagRdd = CodeTagRdd1.filter(obj => obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    //    val needXyTagRdd = segTagRdd.filter(obj=>obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    val rsltRdd6 = CodeTagRdd1.filter(obj => !obj.getString("tag").isEmpty).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    CodeTagRdd.unpersist()
//    logger.error("网点识别表不存在的数量:" + rsltRdd6.count())
//    logger.error("需要跑xy数量:" + needXyTagRdd.count())
//    needXyTagRdd.collect().foreach(x => {
//      logger.error(x)
//    })
//    logger.error("开始跑坐标")
//    val xyTagRdd = runXy(needXyTagRdd)
//    logger.error("错分检测完毕，开始合并")
//    val finalRsltRdd = xyTagRdd.union(rsltRdd2).union(rsltRdd1).union(rsltRdd3).union(rsltRdd4).union(rsltRdd5).union(rsltRdd6).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("跑完结果总数量:" + finalRsltRdd.count())
//
//    //新增区域维度
//    val finalRsltRdd2 = finalRsltRdd.map(obj => {
//      val cityNameMap = cityMapBc.value
//      val cityCode = JSONUtil.getJsonVal(obj, "cityCode", "")
//      val city: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(0)
//      val region: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(1)
//      val area: String = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(2)
//      obj.put("region", region)
//      obj.put("area", area)
//      obj.put("city", city)
//      obj
//    })
//
//
//    xyTagRdd.unpersist()
//    rsltRdd2.unpersist()
//    rsltRdd3.unpersist()
//    rsltRdd4.unpersist()
//    rsltRdd5.unpersist()
//    rsltRdd6.unpersist()
//    DataRdd.unpersist()
//    finalRsltRdd2
//  }
//
//
//  def queryShunXinCityMap(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
//    val sql = "select name, regcode from dm_gis.city_adcode_map_shunxin"
//    val dataMap = spark.sql(sql).rdd.map(obj => {
//      (obj.getString(0), obj.getString(1))
//    }).collectAsMap()
//    logger.error("顺心城市表数量:" + dataMap.size)
//    val shunxinCityMapBc = spark.sparkContext.broadcast(dataMap)
//    shunxinCityMapBc
//  }
//
//  def queryShunxinDeptInfoMap(spark: SparkSession, incDay: String): Broadcast[collection.Map[String, String]] = {
//    val sql = s"select distinct ky_unit,city_code from dm_gis.emap_efsms_kyunit_relate_aoi where inc_day='$incDay'" +
//      s" and tc_type='sxzc'  "
//    val dataMap = spark.sql(sql).rdd.map(obj => {
//      (obj.getString(0), obj.getString(1))
//    }).collectAsMap()
//    val dataMapBc = spark.sparkContext.broadcast(dataMap)
//    dataMapBc
//  }
//
//
//  def saveStaIndex(spark: SparkSession, staIndexRdd: RDD[(KuaiyunCover, KuaiyunWd)], incDay: String): Unit = {
//    import spark.implicits._
//    val rowDf = staIndexRdd.map(obj => obj._1).filter(_.zcSucCnt != 0).toDF()
//    logger.error("数量：" + rowDf.count())
//    rowDf.take(2).foreach(obj => {
//      logger.error(obj.toString())
//    })
//
//    //    val tableName = "tmp_dm_gis.tmp_cover_kuaiyun_cover_cnt"
//    val tableName = "tmp_dm_gis.tmp_cover_kuaiyun_cover_cnt_di" //生产表
//    //    val tableName = "tmp_dm_gis.cover_kuaiyun_cover_cnt_di" //测试备份表
//    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
//
//
//    val wdDf = staIndexRdd.map(obj => obj._2).toDF()
//    logger.error("错分数量：" + wdDf.count())
//    wdDf.take(2).foreach(obj => {
//      logger.error(obj.toString())
//    })
//    //    val wdTableName = "tmp_dm_gis.tmp_cover_kuaiyun_wd_cnt"
//    val wdTableName = "tmp_dm_gis.tmp_cover_kuaiyun_wd_cnt_di" //生产表
//    //    val wdTableName = "tmp_dm_gis.cover_kuaiyun_wd_cnt_di" //测试备份表
//    wdDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(wdTableName)
//
//
//  }
//
//  def saveDetail(spark: SparkSession, checkOverRdd: RDD[JSONObject], incDay: String): Unit = {
//    import spark.implicits._
//    val rowDf = checkOverRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
//    logger.error("数量：" + rowDf.count())
//    //    val tableName = "tmp_dm_gis.tmp_kuaiyun_wyabill_detail"
//    //    val tableName = "tmp_dm_gis.tmp_kuaiyun_wyabill_detail_di" //生产表
//    val tableName = "tmp_dm_gis.tmp_kuaiyun_wyabill_detail_di" //测试数据表
//    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
//  }
//
//  //CXG-- 新增经纬度字段 lgt经度
//  def queryWaybillInfo(spark: SparkSession, startTime: String, incDay: String): RDD[(String, (String, String, String, String))] = {
//    val sql = s" select waybill_no, consignee_addr,dest_dist_code,delivery_lgt,delivery_lat from ( " +
//      s"select waybill_no, consignee_addr,dest_dist_code,delivery_lgt,delivery_lat,row_number() over(partition by waybill_no order by inc_day desc ) rank from dm_gis.tt_waybill_info where inc_day between '$startTime' and '$incDay' " +
//      s")b where rank=1 "
//    logger.error(sql)
//    val waybillRdd = spark.sql(sql).rdd.map(obj => {
//      (obj.getString(0), (obj.getString(1), obj.getString(2), obj.getString(3), obj.getString(4)))
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
//    logger.error("运单量：" + waybillRdd.count())
//    waybillRdd
//  }
//
//  //--CXG
//
//
//  def startSta(spark: SparkSession, incDay: String, sepDay: String): Unit = {
//
//    logger.error("获取当天签收数据和多次签收的数据")
//    val startTime = DateUtil.getDateStr(incDay, -8)
//    val endTime = DateUtil.getDateStr(incDay, 8)
//    val sevenEndTime = DateUtil.getDateStr(incDay, -7)
//    val (signDataRdd, multiDataRdd) = querySignData(spark, startTime, endTime, incDay)
//    logger.error("获取快运请求数据")
//    val originReqRdd = queryOriginReqData(spark, startTime, incDay)
//    logger.error("获取宽表数据")
//    val ttWaybillInfoRdd = queryWaybillInfo(spark, startTime, incDay)
//    logger.error("开始关联数据信息")
//    val joinDataRdd = joinOriginData(originReqRdd, signDataRdd, multiDataRdd, ttWaybillInfoRdd)
//    logger.error("关联结束")
//
//
//    logger.error("获取城市映射表")
//    val cityMapBc = queryCityMap(spark)
//    logger.error("获取城市映射表结束")
//
//    logger.error("获取剔除配置表")
//    val (tcrdd, tcCityRdd) = getTcTag(spark, incDay, sevenEndTime)
//
//
//    logger.error("开始错分判断流程")
//    val checkOverRdd = checkWdData(spark, joinDataRdd, cityMapBc, tcrdd, tcCityRdd)
//    logger.error("错分判断流程结束")
//    checkOverRdd.take(10).foreach(x => {
//      logger.error(x)
//    })
//
//    logger.error("开始统计")
//    val staIndexRdd = staIndex(checkOverRdd)
//    logger.error("统计完毕")
//    logger.error("入库指标数据")
//    saveStaIndex(spark, staIndexRdd, incDay)
//
//
//    logger.error("入库指标完毕")
//    logger.error("入库明细开始")
//    saveDetail(spark, checkOverRdd, incDay)
//    logger.error("入库明细完毕")
//
//
//  }
//
//  def getTcTag(spark: SparkSession, incDay: String, sevenEndTime: String) = {
//    //cxg 新增快运剔除ods_kafka_fvp.fvp_core_fact_route   return:转寄退回
//    val tcSql =
//      s"""
//         |select waybillno
//         |from
//         |ods_kafka_fvp.fvp_core_fact_route
//         |where opcode = '99' and inc_day <= ${incDay} and inc_day >= ${sevenEndTime}
//         |group by waybillno
//      """.stripMargin
//    //需要参与统计的citycode:    noOperation:暂时不需要运营的城市
//    val tcCitySql =
//      s"""
//         |select cityCode
//         |from
//         |dm_gis.kuaiyuntccity_wyabill_di
//         |group by cityCode
//      """.stripMargin
//
//    logger.error(tcSql)
//    logger.error(tcCitySql)
//    val tcrdd = SparkUtils.getRowToJson(spark, tcSql).map(obj => {
//      (JSONUtil.getJsonVal(obj, "waybillno", ""), true)
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//    val tcCityRdd = SparkUtils.getRowToJson(spark, tcCitySql).map(obj => {
//      (JSONUtil.getJsonVal(obj, "cityCode", ""), true)
//    }).persist(StorageLevel.MEMORY_AND_DISK)
//
//
//    logger.error(s"tcrdd剔除的数量：${tcrdd.count()}:" + tcrdd.take(10).foreach(println(_)))
//    logger.error(s"tcCityRdd剔除的数量：${tcCityRdd.count()}:" + tcCityRdd.take(10).foreach(println(_)))
//    (tcrdd, tcCityRdd)
//  }
//
//  def getAoiXy(url: String, aoiId: String): (Double, Double, JSONObject) = {
//    var ret: JSONObject = null
//    try {
//      ret = HttpClientUtil.getJsonByGet(url.format(aoiId), 3)
//      if (ret != null && ret.getJSONObject("result") != null) {
//        if (ret.getJSONObject("result").getInteger("err") == 109) {
//          Thread.sleep(1 * 1000)
//          ret = HttpClientUtil.getJsonByGet(url.format(aoiId), 3)
//        }
//        val dataArray = ret.getJSONObject("result").getJSONArray("data")
//        if (dataArray != null && dataArray.size() > 0) {
//          val dataItem = dataArray.getJSONObject(0)
//          val centralCoord = dataItem.getJSONObject("central_coord")
//          if (centralCoord != null && centralCoord.containsKey("x")) {
//            return (centralCoord.getDouble("x"), centralCoord.getDouble("y"), null)
//          }
//        }
//      }
//    } catch {
//      case e: Exception => logger.error(e)
//    }
//    (-1, -1, ret)
//  }
//
//  def getCmsDept(url: String, cityCodeArray: Array[String]): Map[String, String] = {
//    var retMap: Map[String, String] = Map()
//    for (cityCode <- cityCodeArray) {
//      val urlStr = String.format(url, cityCode)
//      logger.error(urlStr)
//      try {
//        val ret = HttpClientUtil.getJsonByGet(urlStr)
//        val data = ret.getJSONArray("data")
//        for (i <- 0 until data.size()) {
//          val item = data.getJSONObject(i)
//          retMap += (item.getString("znoCode") -> item.getString("departCode"))
//        }
//      } catch {
//        case e: Exception => logger.error(e)
//      }
//    }
//    logger.error("cmsDeptMap size:" + retMap.size)
//    retMap
//  }
//
//  def start(startDay: String, days: Int): Unit = {
//    //    val spark = SparkSession.builder().master("local[*]").config(Util.getSparkConf(appName)).getOrCreate()
//    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
//    spark.sparkContext.setLogLevel("ERROR")
//    //    for (i <- 0 until days) {
//    val sepDay = DateUtil.getDateStr(startDay, 0, "-")
//    val incDay = sepDay.replaceAll("-", "")
//    logger.error("开始计算：" + incDay)
//    startSta(spark, incDay, sepDay)
//    logger.error("计算结束：" + incDay)
//    //    }
//    logger.error("统计完毕")
//  }
//
//
//  def main(args: Array[String]): Unit = {
//    //    val signTcCityCode = "755AC002".replaceAll("([a-zA-Z]+)([0-9]+)", "")
//    //    println(signTcCityCode)
//    val startDay = args.apply(0)
//    //    val startDay = "2021-04-11"
//    val days = args.apply(1).toInt
//    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
//    start(startDay, days)
//    logger.error("结束所有运行")
//
//
//  }
//
//}
