package com.sf.gis.scala.debang.DebangCuofen

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.sx.constant.util.GetSimilar
import com.sf.gis.scala.base.AkUtil
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.debang.util.{DateTimeUtil, JdbcTemplateUtil, StringToolUtil}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.{Level, Logger}
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import java.security.MessageDigest
import java.sql.Connection
import java.util
import java.util.Objects
import scala.collection.JavaConversions._
import scala.collection.mutable
import scala.collection.mutable.ArrayBuffer
import scala.io.{BufferedSource, Source}
import scala.util.matching.Regex

/**
 * 德邦错分
 * 匡仁衡
 * 迁移新集群
 * 任务id:150
 * 业务：01416486张剑佩
 */

object DepPonReportInfo extends Serializable {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(appName)
  Logger.getLogger("org.apache").setLevel(Level.ERROR)
//  val sourceTableName = "dm_gis.t_deppon_sign_index_info_d"
  val sourceTableName = "dm_gis.t_deppon_sign_index_info_d_tmp"

  case class DepPonReportDO(
                             id: String,
                             dataType: String, // 概览; GIS明细； 剔除明细
                             statDate: String, // 数据计算日期
                             eventTimestamp: String, //
                             region: String,
                             depPonCode: String,
                             depPonName: String,
                             bigType: String,
                             dataSrc: String,

                             totalSignCnt: Int, // 总的签收数据量
                             validSignCnt: Int, // 有效签收量
                             piPeiCnt: Int, // 有效匹配量
                             rightCnt: Int, // right 量
                             wdCnt: Int, // 错分量
                             wdAndRightCnt: Int, // right+错分量
                             distinguishCnt: Int, // 识别量

                             // 剔除明细: 总签收量、 有效签收量、整体剔除、识别率剔除、准确率剔除
                             // 整体剔除部分
                             multiReqDiffAddressCnt: Int, // 多次请求地址不一致量
                             singleReqDiffAddressCnt: Int, // 单次请求地址不一致量
                             nonReqSignCnt: Int, // 未关联到请求的签收量
                             inExplicitAddressCnt: Int, // 地址不详量
                             // 识别率剔除部分：
                             multiZcCnt: Int, // 多ZC量
                             noMapZcCnt: Int, // 无ZC多边形量
                             aoiWithoutZcCnt: Int, // AOI无多边形覆盖量
                             aoiNotIntersectZcCnt: Int, // AOI 与 ZC 不相交量
                             // 准确率剔除：
                             otherCityCnt: Int, // 非本市量
                             buzErrCnt: Int, // 业务帮派量
                             buzErrAoiRightCnt: Int, // 区域基础数据错误量
                             depPonWrongCnt: Int, // 人工处理错误量
                             buzErrXyZCRightCnt: Int, // xyZc剔除量
                             buzErrZCModelRightCnt: Int, //zcmodel剔除量
                             buzErrsimilarityRightCnt: Int, // 相似度/率剔除量
                             buzErrconfigRightCnt: Int, // 剔除配置表剔除量
                             changeZcCnt: Int, //变更zc剔除量
                             buzErrDeleteZcRightCnt: Int //错误zc删除剔除量
                           )

  val dlr = '$'
  var parallelism: Int = 1

  val CHARACTER_SET = "UTF-8"
  var SEPARATOR_LINE = "\n"

  var depPonCodeCityNameMap: Map[String, String] = Map()
  var depPonCodeCityCodeMap: Map[String, String] = Map()
  var depPonZcCityMap: Map[String, String] = Map()

  // 获取德邦城市文件ip
  private val depPonZcCityFileIpUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=440300&address=深圳市软件产业基地&showserver=true"
  // 获取德邦营业部代码所属城市映射表
  private val depPonZcCityMapUrl = "http://%s:8080/eds/api/download?ak=3a191e7427e8470c86271a069411c66b&type=2"

  // 地理编码生产接口 mapA
  private val mapAUrl = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=ma1&ak=3a191e7427e8470c86271a069411c66b"

  //根据xy坐标获取德邦Zc接口
  private val DeBangZcXYUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/geom/query?ak=3a191e7427e8470c86271a069411c66b&x=%s&y=%s"

  //根据aoi获取德邦Zc接口
  private val DeBangZcAoiUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/api/cache/query?ak=3a191e7427e8470c86271a069411c66b&type=3&aoi=%s"

  //  opt=zc Zc模型服务接口
  private val ZcModelUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&opt=zc&show=1"

  //CMS获取大组主体词接口
  //private val cmsKeyWordUrl ="http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?cityCode=%s&addressId=%s"

  private val cmsKeyWordUrl = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/getAddrByCityCodeAndAddr?cityCode=%s&addressId=%s"


  // 地理编码生产接口 图商
  private val tsUrl = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=gd2&ak=3a191e7427e8470c86271a069411c66b"
  // 坐标获取aoi
  private val dept2AoiUrl = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=3a191e7427e8470c86271a069411c66b"
  // AOI与德邦多边形面积相交占比
  private val aoiIntersectPerUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/area/query?zc=%s&aoi=%s&ak=3a191e7427e8470c86271a069411c66b"
  // 地址相似度接口
  private val addressSimilarityUrl = "http://10.119.72.209:8080/rds_web/noControl/similar/%s/%s"

  // 地址精细化接口
  private val addressIadUrl = "http://gis-int2.int.sfdc.com.cn:1080/iad/api?address=%s&citycode=%s&ak=3a191e7427e8470c86271a069411c66b"

  //获取分词结果接口
  private val splitResultUrl = "http://gis-int.int.sfdc.com.cn:1080/atroad/api/split?address=%s&ak=3a191e7427e8470c86271a069411c66b&adcode=%s"

  //获取aoiname的接口
  private val aoiNameUrl = "http://gis-apis.int.sfcloud.local:1080/dept/zctc/aoiid?ak=e6b53e609c2440c8b20b14552bab4e09&aoi_id=%s"

  //判断depponzc是否存在的接口
  private val judgeZcExistUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon/query?ak=3a191e7427e8470c86271a069411c66b&parent_code=%s"

  //根据groupid查询aoiid接口
  private val aoiidUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/group/query?ak=3a191e7427e8470c86271a069411c66b&groupId=%s&type=his&cityCode=%s"


  /** @note 港澳台城市 */
  lazy val HK_MACAO_TAIWAN_DEP_PON_CODE_MAP: Map[String, Int] = {
    Map("710100" -> 1, "710200" -> 1, "710300" -> 1, "710400" -> 1, "710500" -> 1, "710600" -> 1, "710700" -> 1, "710800" -> 1,
      "710900" -> 1, "711000" -> 1, "711100" -> 1, "711200" -> 1, "711300" -> 1, "711400" -> 1, "711500" -> 1, "711600" -> 1,
      "711700" -> 1, "711800" -> 1, "711900" -> 1, "712000" -> 1, "712100" -> 1, "712200" -> 1, "820100" -> 1, "810000-1" -> 1
    )
  }

  /** @note 读取外部德邦城市编码配置生成deBangCodeCityCodeMap */
  private def getDeBangCodeCityCodeMap(spark: SparkSession): Unit = {
    /*
    val extraFilePath = "/user/01395847/upload/sch/GIS/Deppon/DepPonReportInfo/extraFile/t_depponcode_citycode_cityname_relation.csv"
    val df: DataFrame = spark.read.format("CSV").option("header","true").csv(extraFilePath)
    depPonCodeCityCodeMap = df.rdd.map(row => {
        val depPonCode = row.getString(0)
        val cityCode = row.getString(1)
        (depPonCode,cityCode)
    }).coalesce(1).collect().toMap
    logger.error("读取外部德邦城市编码配置文件获取depPonCodeCityCodeMap即DepPonCode->CityCode的数量为: " + depPonCodeCityCodeMap.size )

    depPonCodeCityNameMap = df.rdd.map(row => {
        val depPonCode = row.getString(0)
        val cityName = row.getString(2)
        (depPonCode,cityName)
    }).coalesce(1).collect().toMap
    logger.error("读取外部德邦城市编码配置文件获取depPonCodeCityNameMap即DepPonCode->CityName的数量为: " + depPonCodeCityNameMap.size )
    */
    // 由读取DFS配置文件修改为读取MYSQL配置表获取DepPonCode映射关系
    val depPonCodeMap = new AoiDeBangDML().getDepPonCodeMap()
    depPonCodeCityCodeMap = depPonCodeMap._1
    depPonCodeCityNameMap = depPonCodeMap._2
  }

  /** @note 基于InterfaceUrl获取DepPonZcCityMap(parentCode -> cityCode) */
  private def getDepPonZcCityCodeMap(): Unit = {
    val response = customSourceFromUrlToStr(depPonZcCityFileIpUrl, "UTF-8")
    // logger.error("获取德邦城市文件IP内容: " + response)
    if (JSONUtil.isValidJSON(response)) {
      val json = JSON.parseObject(response)
      val ip = JSONUtil.getJsonVal(json, "rpcInfo.ip", "")
      val url = String.format(depPonZcCityMapUrl, ip)
//      val depPonZcCityContent = Source.fromURL(url, "UTF-8")
//      val iteratorLines: Iterator[String] = depPonZcCityContent.getLines()
      val iteratorLines: Iterator[String] = customSourceFromUrlToLines(url, "UTF-8")
      var map = Map[String, String]()
      while (iteratorLines.hasNext) {
        val line = iteratorLines.next()
        val lineArray = line.split(",")
        if (lineArray.length == 2) {
          val parentCode = lineArray(0)
          val cityCode = lineArray(1)
          map += (parentCode -> cityCode)
        }
      }
      logger.error("获取到的DepPonZcCity映射关系数据量为size:" + map.size)
      depPonZcCityMap = map
      logger.error("获取到的DepPonZcCity映射关系数据量为:" + depPonZcCityMap.size)
    }
  }

  /** @note 获取德邦签收退回的数据 */
  private def getDeBangSignReturnRdd(spark: SparkSession, incDay: String): RDD[(String, JSONObject)] = {
    // 获取某日T的德邦签收数据
    val beginDate = incDay
    val endDate = incDay
    // 取数要求: 签收表type=2
    val sourceTableName = "dm_gis.debang_wd_log_flink_collect"
    //val sourceTableName = "dm_gis.debang_wd_collect"
    val sqlText =
      s"""
         |    select
         |        get_json_object(log, '$dlr.address') as address,
         |        get_json_object(log, '$dlr.cityCode') as cityCode,
         |        get_json_object(log, '$dlr.depponCode') as depponCode,
         |        get_json_object(log, '$dlr.depponZc') as depponZc,
         |        get_json_object(log, '$dlr.reqTime') as reqTime,
         |        get_json_object(log, '$dlr.sn') as sn
         |    from $sourceTableName
         |    where inc_day between '$beginDate' and '$endDate'
         |    and get_json_object(log, '$dlr.type') = 2
         |    and get_json_object(log, '$dlr.depponZc') != ''
         |    and get_json_object(log, '$dlr.sn') != ''
                         """.stripMargin

    logger.error("获取德邦签收数据Type=2的执行Sql Text: " + sqlText)
    val df: DataFrame = spark.sql(sqlText)
    logger.error("获取德邦签收数据Type=2的源数据量为Count: " + df.count())
    val fields = df.schema.fieldNames
    logger.error("获取德邦签收数据Type=2时需要计算的fields: " + fields.mkString(","))
    val broadcastTuple = spark.sparkContext.broadcast(Tuple1(fields))
    val rdd = df.rdd.map(row => {
      var sn: String = ""
      val json: JSONObject = new JSONObject()
      for (i <- broadcastTuple.value._1.indices) {
        json.put(broadcastTuple.value._1(i), StringToolUtil.convertString(row.getString(i)))
        json.put("dataType", "1")
      }
      sn = StringToolUtil.convertString(json.getString("sn"))
      (sn, json)
    }).filter(x => x._1 != "").coalesce(parallelism).persist(StorageLevel.DISK_ONLY)
    logger.error("获取德邦签收数据Type=2的数据量为: " + rdd.count())
    rdd
  }

  /** @note 获取德邦签收数据 */
  private def getDeBangSignRdd(spark: SparkSession, incDay: String): RDD[(String, JSONObject)] = {
    // 获取某日T的德邦签收数据
    val beginDate = incDay
    val endDate = incDay
    // 取数要求: depponzc不为空 & type为空 另外若同一个sn对应多个address则取最近的reqTime
    val sourceTableName = "dm_gis.debang_wd_log_flink_collect"
    //val sourceTableName = "dm_gis.debang_wd_collect"
    val sqlText =
      s"""
         |select t1.address,t1.cityCode,t1.depponCode,t1.depponZc,t1.reqTime,t1.sn from (
         |    select
         |        get_json_object(log, '$dlr.address') as address,
         |        get_json_object(log, '$dlr.cityCode') as cityCode,
         |        get_json_object(log, '$dlr.depponCode') as depponCode,
         |        get_json_object(log, '$dlr.depponZc') as depponZc,
         |        get_json_object(log, '$dlr.reqTime') as reqTime,
         |        get_json_object(log, '$dlr.sn') as sn,
         |        row_number() over(partition by get_json_object(log, '$dlr.sn') order by get_json_object(log, '$dlr.reqTime') desc) as rank
         |    from $sourceTableName
         |    where inc_day between '$beginDate' and '$endDate'
         |    and get_json_object(log, '$dlr.type') is null
         |    and get_json_object(log, '$dlr.depponZc') != ''
         |    and get_json_object(log, '$dlr.sn') != ''
         |) t1
         |where t1.rank = 1
                         """.stripMargin


    logger.error("获取指定条件下的德邦签收数据的执行Sql Text: " + sqlText)
    val df: DataFrame = spark.sql(sqlText)
    logger.error("获取指定条件下的德邦签收数据的源数据量为Count: " + df.count())
    val fields = df.schema.fieldNames
    logger.error("获取德邦签收数据时需要计算的fields: " + fields.mkString(","))
    val broadcastTuple = spark.sparkContext.broadcast(Tuple1(fields))
    val rdd = df.rdd.map(row => {
      var sn: String = ""
      val json: JSONObject = new JSONObject()
      for (i <- broadcastTuple.value._1.indices) {
        json.put(broadcastTuple.value._1(i), StringToolUtil.convertString(row.getString(i)))
        json.put("statTag", "sign")
      }
      sn = StringToolUtil.convertString(json.getString("sn"))
      (sn, json)
    }).filter(x => x._1 != "")
    rdd
  }

  /** @note 解析德邦请求数据中的JSON数据 */
  private def parseDeBangReqLog(log: String, codeCityMapBroadcast: Broadcast[Map[String, String]], json: JSONObject): Unit = {
    if (JSONUtil.isValidJSON(log)) {
      val deBangReqJson = JSON.parseObject(log)
      val createTime = JSONUtil.getJsonVal(deBangReqJson, "createTime", "")
      json.put("createTime", createTime)

      // 解析德邦请求数据中log下的message部分
      val message = deBangReqJson.getJSONObject("message")
      val dataType = JSONUtil.getJsonVal(message, "type", "")
      val dataSrc = JSONUtil.getJsonVal(message, "dataSrc", "")
      json.put("dataType", dataType)
      json.put("dataSrc", dataSrc)
      json.put("bigType", "0")
      var reqCityAll = ""
      // 解析message下的request部分
      val request = message.getJSONObject("request")
      if (request != null) {
        val bigType = StringToolUtil.convertString(request.getString("bigType"))
        if(StringUtils.isNotEmpty(bigType)){
          json.put("bigType", bigType)
        }
        val cityCode = request.getString("citycode")
        json.put("cityCode", cityCode)
        val reqCity = codeCityMapBroadcast.value.get(cityCode)
        if (cityCode != null && !cityCode.isEmpty && codeCityMapBroadcast != null && reqCity.nonEmpty) {
          reqCityAll = reqCity.get
          json.put("reqCity", reqCity.get)
        } else {
          json.put("reqCity", "")
        }
        val address = StringToolUtil.convertString(request.getString("address"))
        // 注意可能request下无sn这个key
        val sn = StringToolUtil.convertString(request.getString("sn"))
        json.put("address", address)
        json.put("sn", sn)
      }

      // 解析message下的response部分
      val response = message.getJSONObject("response")
      if (response != null) {
        val data = response.getJSONObject("data")
        if (data != null) {
          val codeArray = data.getJSONArray("code")
          if (codeArray != null) {
            if (codeArray.size() > 0) {
              val zcSet = scala.collection.mutable.Set[String]()
              val tcSet = scala.collection.mutable.Set[String]()
              for (i <- 0 until codeArray.size()) {
                val codeItem = codeArray.getJSONObject(i)
                val tc = codeItem.getString("tc")
                val zc = codeItem.getString("zc")
                if (tc != null)
                  tcSet.add(tc)
                if (zc != null)
                  zcSet.add(zc)
              }
              json.put("zc", zcSet.mkString(";"))
              json.put("tc", tcSet.mkString(";"))
            }
          }
        }
      }
      // 解析message下的atResult部分
      if ("RDS".equals(dataSrc.toUpperCase()) || "DB_RDS".equals(dataSrc.toUpperCase())) {
        // 注意只有当DataSrc为RDS时,才取数据
        val atResult = message.getJSONObject("atResult")
        if (atResult != null) {
          val result = atResult.getJSONObject("result")
          if (result != null) {
            var src = ""
            val tcsArray = result.getJSONArray("tcs")
            if (tcsArray != null && tcsArray.size() > 0) {
              val tcsItem = tcsArray.getJSONObject(0)
              src = JSONUtil.getJsonVal(tcsItem, "src", "")
              json.put("src", src)
              json.put("aoicode", JSONUtil.getJsonVal(tcsItem, "aoicode", ""))
              json.put("keyWord", JSONUtil.getJsonVal(tcsItem, "keyWord", ""))
              json.put("aoiid", JSONUtil.getJsonVal(tcsItem, "aoiid", ""))
              if (StringUtils.isNotEmpty(dataSrc) && "DB_RDS".equals(dataSrc.toUpperCase())) {

                val groupid = JSONUtil.getJsonVal(tcsItem, "groupid", "")
                json.put("group", groupid)
              }
            }
            val other = result.getJSONObject("other")
            if (other != null) {
              val normResp = other.getJSONObject("normresp")
              if (normResp != null) {
                val otherNormRespResult = normResp.getJSONObject("result")
                if (otherNormRespResult != null) {
                  val geoCoder = otherNormRespResult.getJSONArray("geocoder")
                  if (geoCoder != null && geoCoder.size() > 0) {
                    val geoCoderItem = geoCoder.getJSONObject(0)
                    json.put("adcode", JSONUtil.getJsonVal(geoCoderItem, "adcode", ""))
                    if ("norm".equals(src)) {
                      json.put("group", JSONUtil.getJsonVal(geoCoderItem, "group", ""))
                      json.put("standardization", JSONUtil.getJsonVal(geoCoderItem, "standardization", ""))
                    }
                  }
                }
              }
            }
          }
        }
      }
    } else {
      println("==============>>>无效的德邦请求JSON数据源log: " + log)
    }

  }

  /** @note 获取德邦请求数据 */
  private def getDeBangReqRdd(spark: SparkSession, incDay: String): RDD[(String, JSONObject)] = {
    // 获取基于某日T德邦签收数据前的15天的德邦请求数据
    val endDate = incDay
    val beginDate = DateTimeUtil.getDaysApartDate("yyyyMMdd", endDate, -14)
    val sqlText =
      s"""
         |select
         |	log
         |from
         |  dm_gis.debang_log_flink_collect
         | -- dm_gis.debang_kafka_collect
         |where inc_day between '$beginDate' and '$endDate'
         |and trim(get_json_object(get_json_object(log, '$dlr.message'),'$dlr.type')) = 3
         |and trim(get_json_object(get_json_object(get_json_object(log, '$dlr.message'),'$dlr.request'),'$dlr.ak')) = 'd5653f4efbb4450ba8589a300456b80e'
         |and log != ''
         |and get_json_object(get_json_object(get_json_object(log,'$dlr.message'),'$dlr.request'),'$dlr.sn') != 'TEST202003241503'
         |and get_json_object(get_json_object(get_json_object(log,'$dlr.message'),'$dlr.request'),'$dlr.sn') != 'PDD1234567'
         |and get_json_object(get_json_object(get_json_object(log,'$dlr.message'),'$dlr.request'),'$dlr.sn') != ''
         |and (get_json_object(get_json_object(log,'$dlr.message'),'$dlr.dataSrc') !='DB_RDS' or (get_json_object(get_json_object(log,'$dlr.message'),'$dlr.dataSrc') ='DB_RDS' and log not like '%查询数据不存在%'))
             """.stripMargin

    //    val sqlText =
    //      s"""
    //         |select
    //         |  log
    //         |from
    //         |  dm_gis.tmp_debang_kafka_collect
    //         |where
    //         |  inc_day='20201105_2'
    //       """.stripMargin


    logger.error("获取德邦请求数据时需执行的Sql Text: " + sqlText)
    val df: DataFrame = spark.sql(sqlText) //.cache()
    //logger.error("获取德邦请求源数据量为Count: " +  df.count())
    val broadcastTuple = spark.sparkContext.broadcast(depPonCodeCityCodeMap)
    logger.error(">>>>>>>>>>>>>>>>>deBangCodeCityMap.size == " + broadcastTuple.value.size)
    val longAccumulator = spark.sparkContext.longAccumulator
    // 基于RDD解析德邦请求数据中的JSON数据
    val deBangReqRdd = df.rdd.map(row => {
      var sn: String = ""
      val json: JSONObject = new JSONObject()
      val log = row.getString(0)
      try {
        if (StringUtils.isNotEmpty(log)) {
          parseDeBangReqLog(log, broadcastTuple, json)
          sn = json.getString("sn")
        }
      } catch {
        case e: Exception => {
          longAccumulator.add(1L)
          println("解析德邦请求数据中的JSON数据时出现异常Exception: " + e.getMessage + "\t源数据为: " + log)
        }
      }
      (sn, json)
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("获取德邦请求数据中有效的总JSON数据量为: " + deBangReqRdd.count())
    logger.error("其中解析德邦请求源数据JSON数据出现异常的数据量为: " + longAccumulator.value)
    val rdd = deBangReqRdd.filter(x => (x._1 != "")).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中德邦请求数据中的SN不为空的数据量为: " + rdd.count())
    rdd
  }


  /** @note 判断depponc是否存在接口 */

  private def scheduleJudgeZcExistInterface(broadcast: Broadcast[String], depponzc: String): String = {
    //val list = new ArrayBuffer[String]()
    var dept = "0"
    val zcUrl = broadcast.value
    try {
      if (StringUtils.isNotEmpty(depponzc)) {
        val url = String.format(zcUrl, depponzc)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val status = responseJson.getString("status")
            if (StringUtils.isNotEmpty(status) && "0".equals(status)) {
              dept = "1"
            } else {
              dept = "0"
            }
          }
        }
      }
    } catch {
      case e: Exception => println("根据aoi调用德邦ZC接口时出现异常Exception: " + e.getMessage)
    }
    dept
  }


  /** @note 调度Zc模型接口 获取Zc模型 */
  private def scheduleZcModelInterface(zcUrl: String, cityCode: String, address: String): String = {
    var zcModel = ""
    try {
      if (StringUtils.isNotEmpty(cityCode) && StringUtils.isNotEmpty(address)) {
        val url = String.format(zcUrl, URLEncoder.encode(cityCode, "utf-8"), URLEncoder.encode(address.replace(" ", ""), "UTF-8").replaceAll("\\+", "%20"))
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val data = result.getJSONObject("data")
            val array = data.getJSONArray("code")
            if (array.length > 0) {
              val zcM = array.getJSONObject(0)
              zcModel = zcM.getString("zc")
            }
          }
        }
      }
    } catch {
      case e: Exception => println("调度Zc模型接口出现异常Exception: " + e.getMessage)
    }
    zcModel
  }


  /** @note 调度Cms主体词接口 */
  private def scheduleCmsInterface(cmsUrl: String, cityCode: String, addressid: String): String = {
    var keyword = ""
    try {
      if (StringUtils.isNotEmpty(cityCode) && StringUtils.isNotEmpty(addressid)) {
        val url = String.format(cmsUrl, URLEncoder.encode(cityCode, "utf-8"), addressid)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val data = responseJson.getJSONObject("data")
            keyword = data.getString("keyword")
          }
        }
      }
    } catch {
      case e: Exception => println("调度Cms主体词接口时出现异常Exception: " + e.getMessage)
    }
    keyword
  }


  /** @note 根据x，y坐标调用德邦ZC接口 */
  private def scheduleDeBangXYInterface(broadcast: Broadcast[String], x: String, y: String): String = {
    val xyUrl = broadcast.value
    var parentCode = ""
    try {
      if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
        val url = String.format(xyUrl, x, y)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val data = result.getJSONObject("data")
            parentCode = data.getString("parentCode")
          }
        }
      }
    } catch {
      case e: Exception => println("根据x，y坐标调用德邦ZC接口时出现异常Exception: " + e.getMessage)
    }
    parentCode
  }

  //  /** @note   根据aoi坐标调用德邦ZC接口*/
  //
  //  private def scheduleDeBangAoiInterface(broadcast:  Broadcast[String],aoi: String): Set[String] = {
  //    //val list = new ArrayBuffer[String]()
  //    val set = mutable.Set[String]("000")
  //    val aoiUrl = broadcast.value
  //    try {
  //      if (StringUtils.isNotEmpty(aoi)) {
  //        val url = String.format(aoiUrl, aoi)
  //        val response = Source.fromURL(url,"UTF-8").mkString
  //        if(StringUtils.isNotEmpty(response)) {
  //          if (JSONUtil.isValidJSON(response)) {
  //            val responseJson = JSON.parseObject(response)
  //            val result = responseJson.getJSONObject("result")
  //            val array = result.getJSONArray("deppon")
  //            for(i <- 0 to array.length-1){
  //              val jo = array.getJSONObject(i)
  //              val dept = jo.getString("dept")
  //              set.add(dept)
  //            }
  //          }
  //        }
  //      }
  //    } catch {
  //      case e: Exception => println("根据aoi坐标调用德邦ZC接口时出现异常Exception: " + e.getMessage)
  //    }
  //    set
  //  }
  /** @note 根据aoi坐标调用德邦ZC接口 */

  private def scheduleDeBangAoiInterface(broadcast: Broadcast[String], aoi: String): String = {
    //val list = new ArrayBuffer[String]()
    var dept = ""
    val aoiUrl = broadcast.value
    try {
      if (StringUtils.isNotEmpty(aoi)) {
        val url = String.format(aoiUrl, aoi)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val array = result.getJSONArray("deppon")
            val jo = array.getJSONObject(0)
            dept = jo.getString("dept")
          }
        }
      }
    } catch {
      case e: Exception => println("根据aoi调用德邦ZC接口时出现异常Exception: " + e.getMessage)
    }
    dept
  }

  /** @note aoiid获取对应的aoiname接口 */
  private def scheduleDeBangAoiNameInterface(url: String, aoi_id: String): String = {
    var aoi_name = ""
    try {
      if (StringUtils.isNotEmpty(aoi_id)) {
        val aoi_url = String.format(url, aoi_id)
        val response = customSourceFromUrlToStr(aoi_url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val data = result.getJSONArray("data")
            val data1 = data.getJSONObject(0)
            aoi_name = data1.getString("aoi_name")
          }
        }
      }
    } catch {
      case e: Exception => println("根据aoiid获取aoiname接口时出现异常")
    }
    aoi_name
  }


  /** @note address和adcode获取对应的splitresult接口 */
  private def scheduleSplitResultInterface(url: String, address: String, adcode: String): String = {
    var splitResult = ""
    try {
      if (StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(adcode)) {
        val aoi_url = String.format(url, URLEncoder.encode(address.replace(" ", ""), "UTF-8").replaceAll("\\+", "%20"), adcode)
        val response = customSourceFromUrlToStr(aoi_url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val addrSplitInfo = result.getJSONArray("addrSplitInfo")
            val sb = new StringBuilder
            for (i <- 0 until addrSplitInfo.size()) {
              val json = addrSplitInfo.getJSONObject(i)
              val name = json.getString("name")
              val prop = json.getString("prop")
              val level = json.getString("level")
              sb.append(name).append("^").append(prop).append(level).append("|")
            }
            splitResult = sb.toString()
          }
        }
      }
    } catch {
      case e: Exception => println("获取分词接口时出现异常")
    }
    splitResult
  }


  /** @note 获取高精坐标及其对应的AOI信息 */
  private def getMapAPointAndAoiRdd(rdd: RDD[JSONObject], broadcast1: Broadcast[String], xyType: Broadcast[String], broadcast2: Broadcast[String]): RDD[JSONObject] = {
    rdd.repartition(5).map(obj => {
      val reqBody = obj.getJSONObject("reqBody")
      val cityCode = reqBody.getString("reqCity")
      val address = reqBody.getString("address")
      val mapAJson = scheduleMapAInterface(broadcast1.value, cityCode, address)
      obj.put(xyType.value, mapAJson)
      obj
    }).repartition(5).map(obj => {
      val precision = JSONUtil.getJsonVal(obj, xyType.value + ".precision", "")
//      if ("2".equals(precision)) {
        val x = JSONUtil.getJsonVal(obj, xyType.value + ".x", "")
        val y = JSONUtil.getJsonVal(obj, xyType.value + ".y", "")
        val aoiJson = scheduleDept2Interface(broadcast2.value, x, y)
        obj.getJSONObject(xyType.value).fluentPutAll(aoiJson)
//      }
      obj
    })
  }

  /** @note 调度MapA接口 基于地址获取高精坐标 */
  private def scheduleMapAInterface(mapAUrl: String, cityCode: String, address: String): JSONObject = {
    val json: JSONObject = new JSONObject()
    try {
      if (StringUtils.isNotEmpty(cityCode) && StringUtils.isNotEmpty(address)) {
        val url = String.format(mapAUrl, URLEncoder.encode(address.replace(" ", ""), "UTF-8").replaceAll("\\+", "%20"), cityCode)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        var status = ""
        var x = ""
        var y = ""
        var precision = ""
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            if (responseJson.getInteger("status") != null)
              status = responseJson.getInteger("status").toString
            val result = responseJson.getJSONObject("result")
            if (result != null) {
              if (result.getDouble("xcoord") != null)
                x = result.getDouble("xcoord") + ""
              if (result.getDouble("ycoord") != null)
                y = result.getDouble("ycoord") + ""
              if (result.getDouble("precision") != null)
                precision = result.getInteger("precision") + ""
            }
            json.put("x", x)
            json.put("y", y)
            json.put("status", status)
            json.put("precision", precision)
            if (Objects.equals(status, "1"))
              json.put("result", result)

          }
        }
      }
    } catch {
      case e: Exception => println("基于地址获取高精坐标时出现异常Exception: " + e.getMessage)
    }
    json
  }

  /** @note 调度aoiid 基于groupid获取aoiid */
  private def scheduleGroupIdGetAoiIdInterface(groupId: String, city: String): String = {

    var aoiId = ""
    val aoiidUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/group/query?ak=3a191e7427e8470c86271a069411c66b&groupId=%s&type=his&cityCode=%s"
    try {
      if (StringUtils.isNotEmpty(groupId) && StringUtils.isNotEmpty(city)) {
        val url = String.format(aoiidUrl, groupId, city)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        var status = ""

        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            val data = result.getJSONObject("data")
            aoiId = JSONUtil.getJsonVal(data, "aoiId", "")
          }
        }
      }
    } catch {
      case e: Exception => println("解析aoiid出现异常: " + e.getMessage)
    }
    aoiId
  }


  /** @note 调度Dept2接口 获取高精坐标获取AOI */
  private def scheduleDept2Interface(dept2Url: String, lgt: String, lat: String): JSONObject = {
    val json = new JSONObject()
    try {
      if (StringUtils.isNotEmpty(lgt) && StringUtils.isNotEmpty(lat)) {
        val url = String.format(dept2Url, lgt, lat)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            val result = responseJson.getJSONObject("result")
            if (null != result) {
              val aoiDataArray = result.getJSONArray("aoi_data")
              if (null != aoiDataArray && aoiDataArray.size() > 0) {
                val aoiData = aoiDataArray.getJSONObject(0)
                json.put("aoi_code", aoiData.getString("aoi_code"))
                json.put("aoi_id", aoiData.getString("aoi_id"))
                json.put("aoi_name", aoiData.getString("aoi_name"))
              }
            }
          }
        }
      }
    } catch {
      case e: Exception => println("获取高精坐标的AOI时出现异常Exception: " + e.getMessage)
    }
    json
  }

  /** @note 调度PolygonIntersect接口 计算多边形相交 */
  private def schedulePolygonIntersectInterfaceForGis(spark: SparkSession, rdd: RDD[JSONObject], broadcastTuple: Broadcast[(String)]): (RDD[JSONObject]) = {
    val aoiIntersectPerUrlBc = broadcastTuple.value
    val aoiIntersectRdd = rdd.coalesce(2).map(obj => {
      val depPonZc = obj.getString("depponZc")
      val reqBody = obj.getJSONObject("reqBody")
      if (reqBody != null) {
        val aoiId = reqBody.getString("aoiid")
        val url = String.format(aoiIntersectPerUrlBc, depPonZc, aoiId)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            obj.put("polygonRet", responseJson)
            val status = responseJson.getInteger("status")
            // TODO
            if (status == 1) {
              val result = responseJson.getJSONObject("result")
              if (null != result) {
                val result = responseJson.getJSONObject("result")
                val msg = StringToolUtil.convertString(result.getString("msg"))
                if (StringUtils.isNotEmpty(msg)) {
                  if ("zc查询数据不存在".equals(msg.toLowerCase()))
                    obj.put("wdTag", "zcNoMap")
                  else
                    obj.put("wdTag", "emptyAoiRight")
                }
              }
            } else if (status == 0 && responseJson.getJSONObject("result") != null) {
              val dataArray = responseJson.getJSONObject("result").getJSONArray("data")
              if (dataArray != null && dataArray.size() > 0) {
                var isSmall = true
                for (i <- 0 until dataArray.size()) {
                  val aPercent = dataArray.getJSONObject(i).getDouble("aPercent")
                  if (aPercent > 0.1) {
                    isSmall = false
                  }
                }
                if (isSmall) {
                  obj.put("wdTag", "emptyAoiRight")
                } else {
                  obj.put("wdTag", "gisEmpty")
                }
              }
            }
          }
        }
      }
      obj
    })
    aoiIntersectRdd
  }

  /** @note 调度PolygonIntersect接口 计算多边形相交 */
  private def schedulePolygonIntersectInterface(spark: SparkSession, rdd: RDD[JSONObject], broadcastTuple: Broadcast[(String)]): (RDD[JSONObject]) = {
    val aoiIntersectPerUrlBc = broadcastTuple.value
    val aoiIntersectRdd = rdd.coalesce(2).map(obj => {
      val depPonZc = obj.getString("depponZc")
      val reqBody = obj.getJSONObject("reqBody")
      if (reqBody != null) {
        val aoiId = reqBody.getString("aoiid")
        val url = String.format(aoiIntersectPerUrlBc, depPonZc, aoiId)
        val response = customSourceFromUrlToStr(url, "UTF-8")
        if (StringUtils.isNotEmpty(response)) {
          if (JSONUtil.isValidJSON(response)) {
            val responseJson = JSON.parseObject(response)
            obj.put("polygonRet", responseJson)
            val status = responseJson.getInteger("status")
            if (status == 1) {
              obj.put("wdTag", "buzErrAoiRight")
            } else if (status == 0 && responseJson.getJSONObject("result") != null) {
              val dataArray = responseJson.getJSONObject("result").getJSONArray("data")
              if (dataArray != null && dataArray.size() > 0) {
                var isSmall = true
                for (i <- 0 until dataArray.size()) {
                  val aPercent = dataArray.getJSONObject(i).getDouble("aPercent")
                  if (aPercent > 0.1) {
                    isSmall = false
                  }
                }
                if (isSmall) {
                  obj.put("wdTag", "buzErrAoiRight")
                } else {
                  obj.put("wdTag", "judge_buzErr")
                }
              }
            }
          }
        }
      }
      obj
    })
    aoiIntersectRdd
  }


  /** @note 获取德邦签收数据报表指标数据RDD */
  private def getDeBangSignReportRdd(spark: SparkSession, resultStatRdd: RDD[JSONObject], statDate: String): RDD[DepPonReportDO] = {
    val broadcastTuple = spark.sparkContext.broadcast(Tuple3(depPonCodeCityNameMap, statDate, HK_MACAO_TAIWAN_DEP_PON_CODE_MAP))
    // 开始统计指标数据
    val reportRdd = resultStatRdd.flatMap(x => {
      val statDate = broadcastTuple.value._2
      val depPonCode = x.getString("depponCode")
      val region = "ALL" // TODO 预留的GROUP KEY 字段
      val depPonCityNameOption = broadcastTuple.value._1.get(depPonCode)
      var depPonCityName = depPonCode // 若获取不到对应的depPonCityName则默认为depPonCode
      if (depPonCityNameOption.nonEmpty)
        depPonCityName = depPonCityNameOption.get

      var dataSrc = "unknown"
      var bigType = "0"
      val reqBody = x.getJSONObject("reqBody")
      if (null != reqBody) {
        dataSrc = reqBody.getString("dataSrc")
        bigType = reqBody.getString("bigType")
        // 当DataSrc 为 RDS时, 需要根据SRC的值(NORM、CHKN、CHKE、ROAD、TC2、NORMHP)
        if ("RDS".equals(dataSrc.toUpperCase)) {
          val src = StringToolUtil.convertString(reqBody.getString("src"))
          if (StringUtils.isNotEmpty(src))
            dataSrc = "RDS_" + src.toUpperCase
          else
            dataSrc = "RDS_EMPTY"
        }
      }
      var totalSignCnt: Int = 0
      // 概览数据Down：
      var validSignCnt: Int = 0 // 有效签收量
      var piPeiCnt: Int = 0 // 有效匹配量量
      var distinguishCnt: Int = 0 // 识别量

      var rightCnt: Int = 0 // right 量
      var wdCnt: Int = 0 // 错分量
      var wdAndRightCnt: Int = 0 // right+错分量

      // 剔除明细: 总签收量、 有效签收量、整体剔除、识别率剔除、准确率剔除
      // 整体剔除部分
      var multiReqDiffAddressCnt: Int = 0 // 多次请求地址不一致量
      var singleReqDiffAddressCnt: Int = 0 // 单次请求地址不一致量
      var nonReqSignCnt: Int = 0 // 未关联到请求的签收量
      var inExplicitAddressCnt: Int = 0 // 地址不详量
      // 识别率剔除部分：
      var multiZcCnt: Int = 0 // 多ZC量
      var noMapZcCnt: Int = 0 // 无ZC多边形量
      var aoiWithoutZcCnt: Int = 0 // AOI无多边形覆盖量
      var aoiNotIntersectZcCnt: Int = 0 // AOI与ZC不相交的量

      // 准确率剔除：
      var otherCityCnt: Int = 0 // 非本市量
      var buzErrCnt: Int = 0 // 业务帮派量
      var buzErrAoiRightCnt: Int = 0 // 区域基础数据错误量
      var depPonWrongCnt: Int = 0 // 人工处理错误量

      var buzErrXyZCRightCnt: Int = 0 //xy坐标zc剔除量
      var buzErrZCModelRightCnt: Int = 0 //zcmodel 剔除量
      var buzErrsimilarityRightCnt: Int = 0 //相似度率剔除量
      var buzErrconfigRightCnt: Int = 0 //配置表剔除量
      var changeZcCnt: Int = 0 //变更zc剔除量
      var buzErrDeleteZcRightCnt: Int = 0 //错误zc删除量
      // 获取统计标注标签 nonReqSign multiReqDiffAddressPush singleReqDiffAddressPush validSign
      // multiZc validPiPei right otherCity buzErr buzErrAoiRight wd wdAndRight
      val statTag = x.getString("statTag")
      statTag match {
        case "sign" => totalSignCnt = 1
        case "validSign" => validSignCnt = 1
        case "validPiPei" => piPeiCnt = 1
        case "right" => rightCnt = 1
        case "wd" => wdCnt = 1
        case "wdAndRight" => wdAndRightCnt = 1
        case "distinguish" => distinguishCnt = 1
        case "multiReqDiffAddressPush" => multiReqDiffAddressCnt = 1
        case "singleReqDiffAddressPush" => singleReqDiffAddressCnt = 1
        case "nonReqSign" => nonReqSignCnt = 1
        case "inExplicit" => inExplicitAddressCnt = 1
        case "multiZc" => multiZcCnt = 1
//        case "noMapZc" => noMapZcCnt = 1
        case "zcNoMap" => noMapZcCnt = 1
        case "aoiWithoutZc" => aoiWithoutZcCnt = 1
        case "emptyAoiRight" => aoiNotIntersectZcCnt = 1
        case "otherCity" => otherCityCnt = 1
        case "buzErr" => buzErrCnt = 1
        case "buzErrAoiRight" => buzErrAoiRightCnt = 1
        case "depPonWrong" => depPonWrongCnt = 1
        case "buzErrXyZCRight" => buzErrXyZCRightCnt = 1
        case "buzErrZCModelRight" => buzErrZCModelRightCnt = 1
        case "buzErrsimilarityRight" => buzErrsimilarityRightCnt = 1
        case "buzErrconfigRight" => buzErrconfigRightCnt = 1
        case "changeZc" => changeZcCnt = 1
        case "buzErrDeleteZcRight" => buzErrDeleteZcRightCnt = 1
        case _ => println("未匹配到对应的统计标注标签")
      }

      // 针对不同的DataType输出不同的Key,Key-格式为:(dataType, statDate, region, cityCode, cityName, bigType, dataSrc)
      // 统计概览页面各个城市维度下的数据报表数据：
      val overViewKey_1 = ("OVER-VIEW", statDate, "ALL", depPonCode, depPonCityName,bigType, "ALL")
      val overViewRdd_1 = DepPonReportDO(
        "default-id", "OVER-VIEW", statDate, "default-eventTimeStamp", region, depPonCode, depPonCityName,bigType, "ALL",
        totalSignCnt, validSignCnt, piPeiCnt, rightCnt, wdCnt, wdAndRightCnt, distinguishCnt,
        multiReqDiffAddressCnt, singleReqDiffAddressCnt, nonReqSignCnt, inExplicitAddressCnt,
        multiZcCnt, noMapZcCnt, aoiWithoutZcCnt, aoiNotIntersectZcCnt, otherCityCnt, buzErrCnt, buzErrAoiRightCnt, depPonWrongCnt
        , buzErrXyZCRightCnt, buzErrZCModelRightCnt, buzErrsimilarityRightCnt, buzErrconfigRightCnt, changeZcCnt, buzErrDeleteZcRightCnt
      )

      // 统计概览页面所有城市维度下的数据报表数据：
      val overViewKey_2 = ("OVER-VIEW", statDate, "ALL", "ALL", "ALL",bigType, "ALL")
      val overViewRdd_2 = DepPonReportDO(
        "default-id", "OVER-VIEW", statDate, "default-eventTimeStamp", region, "ALL", "ALL",bigType, "ALL",
        totalSignCnt, validSignCnt, piPeiCnt, rightCnt, wdCnt, wdAndRightCnt, distinguishCnt,
        multiReqDiffAddressCnt, singleReqDiffAddressCnt, nonReqSignCnt, inExplicitAddressCnt,
        multiZcCnt, noMapZcCnt, aoiWithoutZcCnt, aoiNotIntersectZcCnt, otherCityCnt, buzErrCnt, buzErrAoiRightCnt, depPonWrongCnt
        , buzErrXyZCRightCnt, buzErrZCModelRightCnt, buzErrsimilarityRightCnt, buzErrconfigRightCnt, changeZcCnt, buzErrDeleteZcRightCnt
      )

      // 统计GIS-明细页面各个城市维度下的数据报表数据：
      val gisDetailKey_1 = ("GIS-DETAIL", statDate, "ALL", depPonCode, depPonCityName,bigType, dataSrc)
      val gisDetailRdd_1 = DepPonReportDO(
        "default-id", "GIS-DETAIL", statDate, "default-eventTimeStamp", region, depPonCode, depPonCityName,bigType, dataSrc,
        totalSignCnt = 0, validSignCnt, piPeiCnt, rightCnt, wdCnt, wdAndRightCnt, distinguishCnt,
        multiReqDiffAddressCnt, singleReqDiffAddressCnt, nonReqSignCnt, inExplicitAddressCnt,
        multiZcCnt, noMapZcCnt, aoiWithoutZcCnt, aoiNotIntersectZcCnt, otherCityCnt, buzErrCnt, buzErrAoiRightCnt, depPonWrongCnt
        , buzErrXyZCRightCnt, buzErrZCModelRightCnt, buzErrsimilarityRightCnt, buzErrconfigRightCnt, changeZcCnt, buzErrDeleteZcRightCnt
      )

      // 统计GIS-明细所有城市维度下的数据报表数据：
      val gisDetailKey_2 = ("GIS-DETAIL", statDate, "ALL", "ALL", "ALL",bigType, dataSrc)
      val gisDetailRdd_2 = DepPonReportDO(
        "default-id", "GIS-DETAIL", statDate, "default-eventTimeStamp", region, "ALL", "ALL",bigType, dataSrc,
        totalSignCnt = 0, validSignCnt, piPeiCnt, rightCnt, wdCnt, wdAndRightCnt, distinguishCnt,
        multiReqDiffAddressCnt, singleReqDiffAddressCnt, nonReqSignCnt, inExplicitAddressCnt,
        multiZcCnt, noMapZcCnt, aoiWithoutZcCnt, aoiNotIntersectZcCnt, otherCityCnt, buzErrCnt, buzErrAoiRightCnt, depPonWrongCnt
        , buzErrXyZCRightCnt, buzErrZCModelRightCnt, buzErrsimilarityRightCnt, buzErrconfigRightCnt, changeZcCnt, buzErrDeleteZcRightCnt
      )

      // 统计剔除-明细页面各个城市维度下的数据报表数据：
      val delDetailKey_1 = ("DEL-DETAIL", statDate, "ALL", depPonCode, depPonCityName,bigType, "ALL")
      val delDetailRdd_1 = DepPonReportDO(
        "default-id", "DEL-DETAIL", statDate, "default-eventTimeStamp", region, depPonCode, depPonCityName,bigType, "ALL",
        totalSignCnt, validSignCnt, piPeiCnt, rightCnt, wdCnt, wdAndRightCnt, distinguishCnt,
        multiReqDiffAddressCnt, singleReqDiffAddressCnt, nonReqSignCnt, inExplicitAddressCnt,
        multiZcCnt, noMapZcCnt, aoiWithoutZcCnt, aoiNotIntersectZcCnt, otherCityCnt, buzErrCnt, buzErrAoiRightCnt
        , depPonWrongCnt, buzErrXyZCRightCnt, buzErrZCModelRightCnt, buzErrsimilarityRightCnt, buzErrconfigRightCnt
        , changeZcCnt, buzErrDeleteZcRightCnt
      )

      // 统计剔除-明细所有城市维度下的数据报表数据：
      val delDetailKey_2 = ("DEL-DETAIL", statDate, "ALL", "ALL", "ALL", bigType,"ALL")
      val delDetailRdd_2 = DepPonReportDO(
        "default-id", "DEL-DETAIL", statDate, "default-eventTimeStamp", region, "ALL", "ALL",bigType, "ALL",
        totalSignCnt, validSignCnt, piPeiCnt, rightCnt, wdCnt, wdAndRightCnt, distinguishCnt,
        multiReqDiffAddressCnt, singleReqDiffAddressCnt, nonReqSignCnt, inExplicitAddressCnt,
        multiZcCnt, noMapZcCnt, aoiWithoutZcCnt, aoiNotIntersectZcCnt, otherCityCnt, buzErrCnt, buzErrAoiRightCnt, depPonWrongCnt
        , buzErrXyZCRightCnt, buzErrZCModelRightCnt, buzErrsimilarityRightCnt, buzErrconfigRightCnt, changeZcCnt, buzErrDeleteZcRightCnt
      )

      // 输出三种类型数据
      // ((overViewKey,overViewRdd), (gisDetailKey,gisDetailRdd),(delDetailKey,delDetailRdd))
      val list = new util.ArrayList[((String, String, String, String, String, String, String), DepPonReportDO)]()
      list.add((overViewKey_1, overViewRdd_1))
      list.add((overViewKey_2, overViewRdd_2))
      list.add((gisDetailKey_1, gisDetailRdd_1))
      list.add((gisDetailKey_2, gisDetailRdd_2))
      list.add((delDetailKey_1, delDetailRdd_1))
      list.add((delDetailKey_2, delDetailRdd_2))
      list.iterator
    }).filter(x => (!"unknown".equals(x._1._7))).filter(x => {
      // 当计算维度DepPonCode为ALL时,需要剔除港澳台地区数据再计算
      val depPonCode = x._1._4
      var flag = true
      if ("ALL".equals(depPonCode)) {
        val codeOption = broadcastTuple.value._3.get(x._2.depPonCode)
        if (codeOption.nonEmpty) {
          flag = false
        }
      }
      flag
    }).reduceByKey((obj1, obj2) => {
      mergeAoiDeBangReportDO(obj1, obj2)
    }).map(x => {
      // 更新eventTimeStamp的值 并生成新的ID的MD5值
      val obj = x._2
      Thread.sleep(100)
      val eventTimeStamp = String.valueOf(System.currentTimeMillis() + scala.util.Random.nextInt(100).toString)
      var id = Array(obj.dataType, obj.statDate, obj.depPonCode, eventTimeStamp, obj.totalSignCnt, obj.dataSrc, obj.bigType).mkString
      id = MessageDigest.getInstance("MD5").digest(id.getBytes).map("%02x".format(_)).mkString
      DepPonReportDO(
        id, obj.dataType, obj.statDate, eventTimeStamp, obj.region, obj.depPonCode, obj.depPonName, obj.bigType,obj.dataSrc,
        obj.totalSignCnt, obj.validSignCnt, obj.piPeiCnt, obj.rightCnt, obj.wdCnt, obj.wdAndRightCnt, obj.distinguishCnt,
        obj.multiReqDiffAddressCnt, obj.singleReqDiffAddressCnt, obj.nonReqSignCnt, obj.inExplicitAddressCnt, obj.multiZcCnt,
        obj.noMapZcCnt, obj.aoiWithoutZcCnt, obj.aoiNotIntersectZcCnt, obj.otherCityCnt, obj.buzErrCnt, obj.buzErrAoiRightCnt, obj.depPonWrongCnt,
        obj.buzErrXyZCRightCnt, obj.buzErrZCModelRightCnt, obj.buzErrsimilarityRightCnt, obj.buzErrconfigRightCnt, obj.changeZcCnt, obj.buzErrDeleteZcRightCnt
      )
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("===>>>>>>获取最终指标结果的数据量为: " + reportRdd.count())
    reportRdd
  }

  private def mergeAoiDeBangReportDO(obj1: DepPonReportDO, obj2: DepPonReportDO): DepPonReportDO = {
    val id = obj1.id
    val dataType = obj1.dataType
    val statDate = obj1.statDate
    val eventTimestamp = obj1.eventTimestamp
    val region = obj1.region
    val depPonCode = obj1.depPonCode
    val depPonName = obj1.depPonName
    val bigType = obj1.bigType
    val dataSrc = obj1.dataSrc

    val totalSignCnt = obj1.totalSignCnt + obj2.totalSignCnt
    val validSignCnt = obj1.validSignCnt + obj2.validSignCnt
    val piPeiCnt = obj1.piPeiCnt + obj2.piPeiCnt
    val rightCnt = obj1.rightCnt + obj2.rightCnt
    val wdCnt = obj1.wdCnt + obj2.wdCnt
    val wdAndRightCnt = obj1.wdAndRightCnt + obj2.wdAndRightCnt
    val distinguishCnt = obj1.distinguishCnt + obj2.distinguishCnt

    val multiReqDiffAddressCnt = obj1.multiReqDiffAddressCnt + obj2.multiReqDiffAddressCnt
    val singleReqDiffAddressCnt = obj1.singleReqDiffAddressCnt + obj2.singleReqDiffAddressCnt
    val nonReqSignCnt = obj1.nonReqSignCnt + obj2.nonReqSignCnt
    val inExplicitAddressCnt = obj1.inExplicitAddressCnt + obj2.inExplicitAddressCnt
    val multiZcCnt = obj1.multiZcCnt + obj2.multiZcCnt
    val noMapZcCnt = obj1.noMapZcCnt + obj2.noMapZcCnt
    val aoiWithoutZcCnt = obj1.aoiWithoutZcCnt + obj2.aoiWithoutZcCnt
    val aoiNotIntersectZcCnt = obj1.aoiNotIntersectZcCnt + obj2.aoiNotIntersectZcCnt

    val otherCityCnt = obj1.otherCityCnt + obj2.otherCityCnt
    val buzErrCnt = obj1.buzErrCnt + obj2.buzErrCnt
    val buzErrAoiRightCnt = obj1.buzErrAoiRightCnt + obj2.buzErrAoiRightCnt
    val depPonWrongCnt = obj1.depPonWrongCnt + obj2.depPonWrongCnt

    val buzErrZCModelRightCnt = obj1.buzErrZCModelRightCnt + obj2.buzErrZCModelRightCnt
    val buzErrXyZCRightCnt = obj1.buzErrXyZCRightCnt + obj2.buzErrXyZCRightCnt

    val buzErrsimilarityRightCnt = obj1.buzErrsimilarityRightCnt + obj2.buzErrsimilarityRightCnt
    val buzErrconfigRightCnt = obj1.buzErrconfigRightCnt + obj2.buzErrconfigRightCnt
    val changeZcCnt = obj1.changeZcCnt + obj2.changeZcCnt
    val buzErrDeleteZcRightCnt = obj1.buzErrDeleteZcRightCnt + obj2.buzErrDeleteZcRightCnt
    DepPonReportDO(
      id, dataType, statDate, eventTimestamp, region, depPonCode, depPonName,bigType, dataSrc,
      totalSignCnt, validSignCnt, piPeiCnt, rightCnt, wdCnt, wdAndRightCnt, distinguishCnt,
      multiReqDiffAddressCnt, singleReqDiffAddressCnt, nonReqSignCnt, inExplicitAddressCnt,
      multiZcCnt, noMapZcCnt, aoiWithoutZcCnt, aoiNotIntersectZcCnt, otherCityCnt, buzErrCnt, buzErrAoiRightCnt, depPonWrongCnt,
      buzErrXyZCRightCnt, buzErrZCModelRightCnt, buzErrsimilarityRightCnt, buzErrconfigRightCnt, changeZcCnt, buzErrDeleteZcRightCnt
    )
  }

  /** @note 解析德邦签收关联请求数据中各流程获取最终需要参与统计的部分数据 */
  private def getResultRdd(spark: SparkSession, incDay: String): (RDD[JSONObject], RDD[(String, String, String)]) = {

    // 1. 加载外部配置文件获取德邦城市编码与城市映射关系数据
    getDeBangCodeCityCodeMap(spark)

    // 2. 获取德邦T天(T指具体的日期,即inc_day = T)的签收数据(或者叫错分数据)
    logger.error("获取德邦签收(错分)数据......")
    val deBangSignRdd = getDeBangSignRdd(spark, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val deBangSignRddCount = deBangSignRdd.count() // 德邦签收数据量
    logger.error("(deBangSignRdd)获取SN不为空的德邦签收数据量为: " + deBangSignRddCount)

    val denBangMap = deBangSignRdd.map(x => {

      val sn = x._1
      val json = x._2

      val address = json.getString("address")
      val cityCode = json.getString("cityCode")
      val depponCode = json.getString("depponCode")
      val depponZc = json.getString("depponZc")
      val reqTime = json.getString("reqTime")
      val statTag = json.getString("statTag")
      //t1.address,t1.cityCode,t1.depponCode,t1.depponZc,t1.reqTime,t1.sn

      (sn, (address, cityCode, depponCode, depponZc, reqTime, statTag))
    }).collectAsMap()

    val denBangMapBroadcast = spark.sparkContext.broadcast(denBangMap)
    logger.error("广播denBangMap数据量为：" + denBangMap.size)


    // 3. 获取德邦T-15区间内的请求数据
    logger.error("获取德邦请求数据......")
    val deBangReqRdd = getDeBangReqRdd(spark, incDay)
    logger.error("德邦请求数据量为：" + deBangReqRdd.count())
    //        deBangSignRdd.countByKey().toList.sortBy(-_._2).take(20).foreach(println(_))
    //        logger.error("================================================================")
    //        deBangReqRdd.countByKey().toList.sortBy(-_._2).take(20).foreach(println(_))

    // 4. 左关联后获取统计需要计算的有效数据,(即德邦签收数据 左关联 德邦请求数据 后的数据)

    val rddPre = deBangReqRdd.repartition(400).map(x => {
      val jo = new JSONObject()
      val sn = x._1
      val right = x._2
      val leftOption = denBangMapBroadcast.value.get(sn)
      if (leftOption.nonEmpty) {
        val (address, cityCode, depponCode, depponZc, reqTime, statTag) = leftOption.get
        jo.put("sn", sn)
        jo.put("address", address)
        jo.put("cityCode", cityCode)
        jo.put("depponCode", depponCode)
        jo.put("depponZc", depponZc)
        jo.put("reqTime", reqTime)
        jo.put("reqBody", right)
        jo.put("statTag", statTag)
      } else {
        jo.put("wdTag", "nonReqSign")
      }
      (sn, jo)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val rdd = rddPre.filter(x => {
      StringUtils.isEmpty(x._2.getString("wdTag")) || !"nonReqSign".equals(x._2.getString("wdTag"))
    }).persist(StorageLevel.DISK_ONLY)
    logger.error("德邦签收数据左关联德邦请求数据后的数据量为Count: " + rdd.count())

    // 获取未关联到任何请求的签收且标注标签(无效的签收数据)
    val nonReqSignRdd = rddPre.filter(x => "nonReqSign".equals(x._2.getString("wdTag"))).map(x => {
      x._2.put("statTag", "nonReqSign")
      x._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(nonReqSignRdd)===>>>其中未关联到请求的数据量为Count: " + nonReqSignRdd.count())

    val reqWdRdd = rdd.filter(x => (null != x._2.getString("reqBody"))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中关联到请求的笛卡尔数据量为Count: " + reqWdRdd.count())

    // 5. 验证签收数据是否有关联到多个请求记录(这里只验证已经确认关联到了请求的签收数据),并完成对应的数据标签标注
    val reqAggRdd = reqWdRdd.aggregateByKey(scala.collection.mutable.Set[(JSONObject)]())((set, item) => {
      set += item
    }, (set1, set2) => set1 union set2).map(x => {
      // 5.1 先计算每个签收订单数据关联到的请求记录数(sn, reqCount, List[JSONObject])
      (x._1, x._2.size, x._2.toList)
    }).map(x => {
      val sn = x._1
      val reqCount = x._2
      val jsonList = x._3
      // 5.2 若关联到多个请求 则判断多个请求记录的地址中是否存在与签收地址一致的记录
      if (reqCount >= 2) {
        for (json <- jsonList) {
          // 分别获取签收与请求记录的地址
          val wdAddress = json.getString("address")
          val reqBody = json.getJSONObject("reqBody")
          if (reqBody != null) {
            val reqAddress = reqBody.getString("address")
            if (StringUtils.isNotEmpty(wdAddress) && StringUtils.isNotEmpty(reqAddress)) {
              if (!wdAddress.toLowerCase().equals(reqAddress.toLowerCase()))
                json.put("wdTag", "multiReqDiffAddress")
              else
                json.put("wdTag", "multiReqSameAddress")
            }
          }
        }
      }
      // 5.3 若仅关联到一个请求 则判断该请求地址是否与签收地址是否一致
      if (reqCount == 1) {
        for (json <- jsonList) {
          // 分别获取签收与请求记录的地址
          val wdAddress = json.getString("address")
          val reqBody = json.getJSONObject("reqBody")
          if (reqBody != null) {
            val reqAddress = reqBody.getString("address")
            if (StringUtils.isNotEmpty(wdAddress) && StringUtils.isNotEmpty(reqAddress)) {
              if (!wdAddress.toLowerCase().equals(reqAddress.toLowerCase()))
                json.put("wdTag", "singleReqDiffAddress")
              else
                json.put("wdTag", "singleReqSameAddress")
            }
          }
        }
      }
      (sn, reqCount, jsonList)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("签收数据关联到请求数据聚合后的数据量为Count: " + reqAggRdd.count())

    val multiReqRdd = reqAggRdd.filter(_._2 >= 2).map(x => (x._1, x._3))
    logger.error("其中关联到多个请求的数据量为Count: " + multiReqRdd.count())

    // 关联到多个请求: 签收地址与请求地址一致
    val multiReqSameAddressRdd = multiReqRdd.map(x => {
      val sn = x._1
      val list = new util.ArrayList[JSONObject]()
      for (json <- x._2) {
        if ("multiReqSameAddress".equals(json.getString("wdTag")))
          list.add(json)
      }
      (sn, list)
    }).filter(x => x._2.size() > 0).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("签收数据中关联到多个请求记录数据中且签收地址与请求地址一致的数据集的数据量为Count: " + multiReqSameAddressRdd.count())

    // 关联到多个请求: 签收地址与请求地址不一致
    val multiReqDiffAddressRdd = multiReqRdd.map(x => {
      val sn = x._1
      val list = new util.ArrayList[JSONObject]()
      for (json <- x._2) {
        if ("multiReqDiffAddress".equals(json.getString("wdTag")))
          list.add(json)
      }
      (sn, list)
    }).filter(x => x._2.size() > 0).leftOuterJoin(multiReqSameAddressRdd).map(x => {
      // 注意关联到多个请求的签收数据中, SN-A [A1,A2,A3,A4] 签收数据SN对应的签收地址A与A1 A2一致，但与A3 A4不一致
      // 因此SN-A已经存在有效的请求地址数据 需要剔除过滤掉 SN-A [A3 A4]
      var flag = true
      val left = x._2._1
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        flag = false
      }
      (flag, x._1, left)
    }).filter(x => x._1).map(x => (x._2, x._3)).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("签收数据中关联到多个请求记录数据中且签收地址与请求地址不一致的数据集的数据量为Count: " + multiReqDiffAddressRdd.count())

    // 广播相似度接口
    val addressSimilarityUrlBroadcast = spark.sparkContext.broadcast(addressSimilarityUrl)
    // 关联到多个请求: 若多个请求记录的地址中存在与签收地址不一致的记录,则调用相似度服务接口完成签收地址与请求地址间的比较
    val similarityExceptionLongAccumulator = spark.sparkContext.longAccumulator
    val multiReqDiffAddressSimilarityStatRdd = multiReqDiffAddressRdd.repartition(20).map(x => {
      val sn = x._1
      val list = new util.ArrayList[JSONObject]()
      for (json <- x._2) {
        // 默认地址都不相似
        json.put("isSimilar", "0")
        // 获取签收地址
        val wdAddress = json.getString("address")
        // 获取请求地址
        val reqAddress = json.getJSONObject("reqBody").getString("address")
        var url = ""
        var similarity: Double = 0.0
        try {
          url = String.format(addressSimilarityUrlBroadcast.value, URLEncoder.encode(wdAddress, "UTF-8"), URLEncoder.encode(reqAddress, "UTF-8"))
          val wdAddressKeySimilarity = customSourceFromUrlToStr(url, "UTF-8").toDouble

          url = String.format(addressSimilarityUrlBroadcast.value, URLEncoder.encode(reqAddress, "UTF-8"), URLEncoder.encode(wdAddress, "UTF-8"))
          val reqAddressKeySimilarity = customSourceFromUrlToStr(url, "UTF-8").toDouble

          similarity = Math.max(wdAddressKeySimilarity, reqAddressKeySimilarity)
        } catch {
          case e: Exception => {
            similarityExceptionLongAccumulator.add(1L)
            println("计算请求与签收地址的相似度时出现异常Exception: " + e.getMessage + "\t源Request URL: " + url)
          }
        }
        if (similarity >= 0.9)
        // 修改为相似
          json.put("isSimilar", "1")
        list.add(json)
      }
      (sn, list)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取多个请求记录地址完成与签收地址相似度计算标注标签后的数据量为Count: " + multiReqDiffAddressSimilarityStatRdd.count())
    logger.error("其中出现的异常数据量为Count: " + similarityExceptionLongAccumulator.value)


    // 关联到多个请求: 获取相似度结果为1的数据集
    val multiReqDiffAddressSimilarityRdd = multiReqDiffAddressSimilarityStatRdd.map(x => {
      val sn = x._1
      val list = new util.ArrayList[JSONObject]()
      for (json <- x._2) {
        if ("1".equals(json.getString("isSimilar")))
          list.add(json)
      }
      (sn, list)
    }).filter(x => x._2.size() > 0).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中获取相似度结果为1的数据集数据量为Count: " + multiReqDiffAddressSimilarityRdd.count())

    // 关联到多个请求: 获取相似度结果不为1的数据集
    val multiReqDiffAddressNonSimilarityRdd = multiReqDiffAddressSimilarityStatRdd.map(x => {
      val sn = x._1
      val list = new util.ArrayList[JSONObject]()
      for (json <- x._2) {
        if (!"1".equals(json.getString("isSimilar"))) {
          list.add(json)
        }
      }
      (sn, list)
    }).filter(x => x._2.size() > 0).leftOuterJoin(multiReqDiffAddressSimilarityRdd).map(x => {
      // 同地址判断一样需要做剔除逻辑
      var flag = true
      val left = x._2._1
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        flag = false
      }
      (flag, x._1, left)
    }).filter(x => x._1).map(x => (x._2, x._3)).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中获取相似度结果不为1的数据集数据量为Count: " + multiReqDiffAddressNonSimilarityRdd.count())

    // 关联到多个请求: 获取相似结果不为1的数据集中最近日期的数据推送给德邦
    val multiReqDiffAddressPushRdd = multiReqDiffAddressNonSimilarityRdd.map(x => {
      val sn = x._1
      val buffer = x._2.toBuffer
      val sortByLineCountBuffer = buffer.sortBy(x => {
        val reqBody = x.getJSONObject("reqBody")
        val createTime = DateTimeUtil.timeToLong(reqBody.getString("createTime"), "yyyy-MM-dd HH:mm:ss.SSS")
        (createTime)
      })
      // 且只获取最近一条时间记录的数据
      (sn, sortByLineCountBuffer.reverse.take(1))
    }).flatMap(x => {
      val buffer = x._2
      for (json <- buffer)
        yield (x._1, json)
    }).map(x => {
      x._2.put("statTag", "multiReqDiffAddressPush")
      x._2.put("dataType", "6")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(multiReqDiffAddressPush)===>>>其中获取相似度结果不为1的数据集中最近日期的数据推送给德邦的数据量为Count: " + multiReqDiffAddressPushRdd.count())

    // 关联到多个请求: 将获取相似度结果为1的数据集与多个请求记录与签收地址也一致的数据集合并获取所有有效的多请求地址的数据,然后取最近时间的请求记录数据
    val validMultiReqSameAddressRdd = multiReqDiffAddressSimilarityRdd.union(multiReqSameAddressRdd).map(x => {
      val sn = x._1
      val buffer = x._2.toBuffer
      val sortByLineCountBuffer = buffer.sortBy(x => {
        val reqBody = x.getJSONObject("reqBody")
        val createTime = DateTimeUtil.timeToLong(reqBody.getString("createTime"), "yyyy-MM-dd HH:mm:ss.SSS")
        (createTime)
      })
      // 且只获取最近一条时间记录的数据
      (sn, sortByLineCountBuffer.reverse.take(1))
    }).flatMap(x => {
      val buffer = x._2
      for (json <- buffer)
        yield (x._1, json)
    }).aggregateByKey(scala.collection.mutable.MutableList[(JSONObject)]())((list, item) => {
      list += item
    }, (list1, list2) => list1 union list2).map(x => {
      (x._1, x._2.toList)
    }).map(x => {
      val sn = x._1
      val size = x._2.size
      val jsonList = x._2
      val list = new util.ArrayList[JSONObject]()
      // 若经过相似度计算后有多个请求地址与签收地址相似度结果为1且该数据的的SN仍然在未经过相似度计算但请求记录与签收地址也一致的数据集中,则优先获取不经过相似度计算的地址一致的数据
      // size == 2 表示存在重复的SN即在经过相似度计算结果为1 与未经过相似度计算的SN重复, 这里仅取未经过相似度计算的SN
      if (size >= 2) {
        for (json <- jsonList) {
          val isSimilar = json.getString("isSimilar")
          if (isSimilar == null) {
            list.add(json)
          }
        }
      }
      if (size == 1) {
        for (json <- jsonList) {
          list.add(json)
        }
      }
      (sn, list)
    }).flatMap(x => {
      val buffer = x._2
      for (json <- buffer)
        yield (x._1, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取相似度结果为1的数据集与多个请求记录与签收地址也一致的数据集合并获取所有有效的多请求地址的数据,然后获取最近时间的请求记录数据的数据量为Count: " + validMultiReqSameAddressRdd.count())

    val singleReqRdd = reqAggRdd.filter(_._2 == 1).map(x => (x._1, x._3))
    logger.error("其中仅关联到一个请求的数据量为Count: " + singleReqRdd.count())
    // 仅关联到一条请求: 筛选出签收数据仅关联到一条请求记录的数据中请求地址与签收地址不一致的记录
    val singleReqDiffAddressRdd = singleReqRdd.map(x => {
      val sn = x._1
      val list = new util.ArrayList[JSONObject]()
      for (json <- x._2) {
        if ("singleReqDiffAddress".equals(json.getString("wdTag")))
          list.add(json)
      }
      (sn, list)
    }).flatMap(x => {
      val buffer = x._2
      for (json <- buffer)
        yield (x._1, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("筛选出签收数据仅关联到一条请求记录的数据中请求地址与签收地址不一致的记录数据量为Count: " + singleReqDiffAddressRdd.count())

    // 仅关联到一条请求: 若签收数据仅关联到一条请求记录的数据中请求地址与签收地址不一致的记录,则调用相似度服务接口完成签收地址与请求地址间的比较
    val singleLongAccumulator = spark.sparkContext.longAccumulator
    val singleReqDiffAddressSimilarityStatRdd = singleReqDiffAddressRdd.repartition(20).map(x => {
      val sn = x._1
      val json = x._2
      // 默认地址都不相似
      json.put("isSimilar", "0")
      // 获取签收地址
      val wdAddress = json.getString("address")
      // 获取请求地址
      val reqAddress = json.getJSONObject("reqBody").getString("address")
      var url = ""
      var similarity = 0.0
      try {
        url = String.format(addressSimilarityUrlBroadcast.value, URLEncoder.encode(wdAddress, "UTF-8"), URLEncoder.encode(reqAddress, "UTF-8"))
        val wdAddressKeySimilarity = customSourceFromUrlToStr(url, "UTF-8").toDouble

        url = String.format(addressSimilarityUrlBroadcast.value, URLEncoder.encode(reqAddress, "UTF-8"), URLEncoder.encode(wdAddress, "UTF-8"))
        val reqAddressKeySimilarity = customSourceFromUrlToStr(url, "UTF-8").toDouble

        similarity = Math.max(wdAddressKeySimilarity, reqAddressKeySimilarity)
      } catch {
        case e: Exception => {
          singleLongAccumulator.add(1L)
          println("计算仅关联到一条请求记录时与签收地址计算相似度时出现异常Exception: " + e.getMessage + "\t源Request URL: " + url)
        }
      }
      if (similarity >= 0.9)
      // 修改为相似
        json.put("isSimilar", "1")
      (sn, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取仅关联到一条请求记录时与签收地址相似度计算标注标签后的数据量为Count: " + singleReqDiffAddressSimilarityStatRdd.count())
    logger.error("获取仅关联到一条请求记录时与签收地址相似度计算出现的异常数据量为Count: " + singleLongAccumulator.value)


    // 仅关联到一条请求: 获取相似度结果为1的数据集
    val singleReqDiffAddressSimilarityRdd = singleReqDiffAddressSimilarityStatRdd.filter(x => "1".equals(x._2.getString("isSimilar"))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中获取相似度结果为1的数据集数据量为Count: " + singleReqDiffAddressSimilarityRdd.count())

    // 仅关联到一条请求: 获取相似度结果不为1的数据集 将不为1的数据集推送给德邦
    val singleReqDiffAddressPushRdd = singleReqDiffAddressSimilarityStatRdd.filter(x => !"1".equals(x._2.getString("isSimilar"))).map(x => {
      x._2.put("statTag", "singleReqDiffAddressPush")
      x._2.put("dataType", "6")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(singleReqDiffAddressPushRdd)其中获取相似度结果不为1的数据集数据量(Push)为Count: " + singleReqDiffAddressPushRdd.count())

    // 仅关联到一条请求: 筛选出签收数据仅关联到一条请求记录的数据中请求地址与签收地址一致的记录
    val singleReqSameAddressRdd = singleReqRdd.map(x => {
      val sn = x._1
      val list = new util.ArrayList[JSONObject]()
      for (json <- x._2) {
        if ("singleReqSameAddress".equals(json.getString("wdTag")))
          list.add(json)
      }
      (sn, list)
    }).flatMap(x => {
      val buffer = x._2
      for (json <- buffer)
        yield (x._1, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("筛选出签收数据仅关联到一条请求记录的数据中请求地址与签收地址一致的记录数据量为Count: " + singleReqSameAddressRdd.count())

    val validSingleReqSameAddressRdd = singleReqSameAddressRdd.union(singleReqDiffAddressSimilarityRdd)
    logger.error("获取相似度结果为1的数据集与单个请求记录与签收地址也一致的数据集合并获取所有有效的请求地址的数据,然后获取最近时间的请求记录数据的数据量为validSingleReqAddressRddCount: " + validSingleReqSameAddressRdd.count())

    // TODO 则有效的签收量为：签收量 = validMultiReqAddressRdd + validSingleReqAddressRdd
    val validSignRdd = validMultiReqSameAddressRdd.union(validSingleReqSameAddressRdd).map(x => {
      val reqBody = x._2.getJSONObject("reqBody")

      val dataSrc = JSONUtil.getJsonVal(reqBody, "dataSrc", "")

      if (StringUtils.isNotEmpty(dataSrc) && "DB_RDS".equals(dataSrc)) {
        val groupId = JSONUtil.getJsonVal(reqBody, "group", "")
        val city = JSONUtil.getJsonVal(reqBody, "reqCity", "")
        val aoiid = scheduleGroupIdGetAoiIdInterface(groupId, city)
        x._2.put("aoiid", aoiid)
      }
      x._2.put("statTag", "validSign")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(validSignRdd)其中有效的签收量validSignRdd的数据量为Count: " + validSignRdd.count())

    // 6. 基于有效的签收量数据验证请求数据中的zc是否为空
    val zcRdd = validSignRdd.map(x => {
      val sn = x._1
      val json = x._2
      var zc = ""
      val reqBody = json.getJSONObject("reqBody")
      if (reqBody != null) {
        zc = StringToolUtil.convertString(reqBody.getString("zc"))
        if (StringUtils.isEmpty(zc)) {
          // ZC为空
          json.put("wdTag", "emptyZc")
        } else {
          // 7.1 若ZC不为空则继续判断ZC是否有多个值
          val zcs = zc.split(";")
          if (zcs.length > 1) {
            // ZC 存在多个值
            json.put("wdTag", "multiZc")
          }
          else {
            // ZC 只有一个值 并标注为有效的匹配
            json.put("wdTag", "validPiPei")
          }
        }
      }
      (sn, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("验证ZC后的总数据量为Count: " + zcRdd.count())
    val emptyZcRdd = zcRdd.filter(x => ("emptyZc".equals(x._2.getString("wdTag")))).coalesce(parallelism).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中ZC为空的数据量为Count: " + emptyZcRdd.count())
    // 针对空ZC数据调用地址精细化接口处理
    val broadcastTuple = spark.sparkContext.broadcast(Tuple2(addressIadUrl, CHARACTER_SET))
    val iadRdd = emptyZcRdd.map(x => {
      val address = x._2.getString("address")
      val cityCode = x._2.getString("cityCode")
      if(StringUtils.isNotEmpty(address)){
        val url = String.format(broadcastTuple.value._1, URLEncoder.encode(address.replace(" ", ""), "UTF-8").replaceAll("\\+", "%20"), cityCode)
        val response = customSourceFromUrlToStr(url, broadcastTuple.value._2)
        if (JSONUtil.isValidJSON(response)) {
          val json = JSON.parseObject(response)
          val status = json.getInteger("status")
          if (null != status) {
            if (0 == status) {
              val result = json.getJSONObject("result")
              if (null != result) {
                val data = result.getJSONObject("data")
                if (null != data) {
                  val explicit = data.getInteger("explicit")
                  if (null != explicit) {
                    if (0 == explicit) {
                      x._2.put("wdTag", "inExplicit")
                    } else {
                      val reqBody = x._2.getJSONObject("reqBody")
                      if (null != reqBody) {
                        val aoiId = StringToolUtil.convertString(reqBody.getString("aoiid"))
                        if (StringUtils.isNotEmpty(aoiId)) {
                          x._2.put("wdTag", "gisNotEmpty")
                        } else {
                          x._2.put("wdTag", "gisEmpty")
                        }
                      }
                    }
                  }
                }
              }
            } else {
              x._2.put("wdTag", "gisEmpty")
            }
          }
        }
      }
      x._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ZC为空时调用精细化接口后的数据量为Count: " + iadRdd.count())
    iadRdd.take(1).foreach(println(_))

    val statusNotZeroAndEmptyAoiIdRdd = iadRdd.filter(x => ("gisEmpty".equals(x.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ZC为空时状态不为0和AoiId为空的总数据量为Count: " + statusNotZeroAndEmptyAoiIdRdd.count())

    val inExplicitRdd = iadRdd.filter(x => ("inExplicit".equals(x.getString("wdTag")))).map(x => {
      x.put("statTag", "inExplicit")
      x.put("dataType", "9")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ZC为空时地址不详细即Explicit为0数据量为Count: " + inExplicitRdd.count())

    val notEmptyAoiIdRdd = iadRdd.filter(x => ("gisNotEmpty".equals(x.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ZC为空时AoiId不为空的数据量为Count: " + notEmptyAoiIdRdd.count())

    // TODO 针对AOI ID不为空的数据获取坐标信息等
    val mapAXyBroadcast = spark.sparkContext.broadcast("mapAXy")
    val tsXyBroadcast = spark.sparkContext.broadcast("tsXy")
    val mapAUrlBroadcast = spark.sparkContext.broadcast(mapAUrl)
    val xyDeBangBroadcast = spark.sparkContext.broadcast(DeBangZcXYUrl)
    val aoiDeBangBroadcast = spark.sparkContext.broadcast(DeBangZcAoiUrl)
    val zcModelUrlBroadcast = spark.sparkContext.broadcast(ZcModelUrl)
    val cmsKeyWordUrlBroadcast = spark.sparkContext.broadcast(cmsKeyWordUrl)
    val tsUrlBroadcast = spark.sparkContext.broadcast(tsUrl)
    val dept2AoiUrlBroadcast = spark.sparkContext.broadcast(dept2AoiUrl)
    val judgeZcExistBroadcast = spark.sparkContext.broadcast(judgeZcExistUrl)


    val notEmptyAoiIdMapARdd = getMapAPointAndAoiRdd(notEmptyAoiIdRdd, mapAUrlBroadcast, mapAXyBroadcast, dept2AoiUrlBroadcast).persist(StorageLevel.MEMORY_AND_DISK_SER)
//      .map(x => {
//      // 添加标注标签信息：若没有获取到高精坐标 则 wdTag = wd;  若没有获取到坐标AOI 则wdTag = wd
//      val mapAJson = x.getJSONObject(mapAXyBroadcast.value)
//      if (mapAJson != null) {
//        if ("2".equals(mapAJson.getString("precision"))) {
//          if (StringUtils.isNotEmpty(mapAJson.getString("x")) && StringUtils.isNotEmpty(mapAJson.getString("y"))) {
//            if (StringUtils.isEmpty(mapAJson.getString("aoi_id")))
//              x.put("wdTag", "gisEmpty")
//          }
//          else
//            x.put("wdTag", "gisEmpty")
//        } else
//          x.put("wdTag", "gisEmpty")
//      }
//      x
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("notEmptyAoiIdMapARdd的数据量为Count: " + notEmptyAoiIdMapARdd.count())

    logger.error("再基于图商 URL 获取高精坐标和坐标对应的AOI信息......")
    val notEmptyAoiIdTsRdd = getMapAPointAndAoiRdd(notEmptyAoiIdMapARdd, tsUrlBroadcast, tsXyBroadcast, dept2AoiUrlBroadcast).persist(StorageLevel.MEMORY_AND_DISK_SER)
//      .map(x => {
//      // 添加标注标签信息：若没有获取到高精坐标 则 wdTag = wd;  若没有获取到坐标AOI 则wdTag = wd
//      val tsJson = x.getJSONObject(tsXyBroadcast.value)
//      if (tsJson != null) {
//        if ("2".equals(tsJson.getString("precision"))) {
//          if (StringUtils.isNotEmpty(tsJson.getString("x")) && StringUtils.isNotEmpty(tsJson.getString("y"))) {
//            if (StringUtils.isEmpty(tsJson.getString("aoi_id")))
//              x.put("wdTag", "gisEmpty")
//          }
//          else
//            x.put("wdTag", "gisEmpty")
//
//        } else
//          x.put("wdTag", "gisEmpty")
//      }
//      x
//    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("notEmptyAoiIdTsRdd的数据量为Count: " + notEmptyAoiIdTsRdd.count())
    notEmptyAoiIdTsRdd.take(1).foreach(println(_))

    // 验证园区 以及三者AOI ID是否相等
    val notEmptyAoiIdSrcRdd = notEmptyAoiIdTsRdd.filter(x => (!"gisEmpty".equals(x.getString("wdTag")))).map(obj => {
      val reqBody = obj.getJSONObject("reqBody")
      if (reqBody != null) {
        val src = reqBody.getString("src")
        val dataSrc = reqBody.getString("dataSrc")
        // 若src = norm
        if ("norm".equals(src) || "DB_RDS".equals(dataSrc)) {
          val standardization = JSONUtil.getJsonVal(obj, "standardization", "")
          val address = JSONUtil.getJsonVal(obj, "address", "")

         if(standardization.matches(".*(产业园|创业园|园区|工业园|科技园)") && address.matches(".*(栋|区).*")) obj.put("wdTag", "gisEmpty")

//          val endStrArray = Array("产业园", "创业园", "园区", "工业园", "科技园")
//          val containStrArray = Array("栋", "区")
//          for (itemEnd <- endStrArray) {
//            if (standardization.endsWith(itemEnd)) {
//              for (itemContain <- containStrArray) {
//                if (standardization.contains(itemContain)) {
//                  // obj.put("tag","standardization结尾符合要求")
//                  obj.put("wdTag", "gisEmpty")
//                }
//              }
//            }
//          }


        }
//        val mapAGjXyAoi = JSONUtil.getJsonVal(obj, "mapAXy.aoi_id", "")
//        val tsGjXyAoi = JSONUtil.getJsonVal(obj, "tsXy.aoi_id", "")
//        val aoiId = JSONUtil.getJsonVal(reqBody, "aoiid", "")
//
//        if (StringUtils.isEmpty(aoiId) || StringUtils.isEmpty(mapAGjXyAoi) || StringUtils.isEmpty(tsGjXyAoi)
//          || !aoiId.equals(mapAGjXyAoi) || !aoiId.equals(tsGjXyAoi)) {
//          // obj.put("tag","三方aoi不相等")
//          obj.put("wdTag", "gisEmpty")
//        }
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("notEmptyAoiIdSrcRdd的数据量为Count: " + notEmptyAoiIdSrcRdd.count())

    val aoiIntersectPerUrlBroadcast = spark.sparkContext.broadcast(aoiIntersectPerUrl)
    // 14.查询德邦AOI与面积多边形相交占比
    val notEmptyAoiIdPolygonIntersectRdd = schedulePolygonIntersectInterfaceForGis(spark, notEmptyAoiIdSrcRdd.filter(x => (!"gisEmpty".equals(x.getString("wdTag")))), aoiIntersectPerUrlBroadcast).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("notEmptyAoiIdPolygonIntersectRdd的数据量为:" + notEmptyAoiIdPolygonIntersectRdd.count())

    val zcNoMapRdd = notEmptyAoiIdPolygonIntersectRdd.filter(x => "zcNoMap".equals(JSONUtil.getJsonVal(x, "wdTag", ""))).map(x => {
      x.put("statTag", "zcNoMap")
      x.put("dataType", "8")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(zcNoMapRdd)区域基础数据错误量为Count: " + zcNoMapRdd.count())

    val emptyAoiRightRdd = notEmptyAoiIdPolygonIntersectRdd.filter(x => "emptyAoiRight".equals(JSONUtil.getJsonVal(x, "wdTag", ""))).map(x => {
      x.put("statTag", "emptyAoiRight")
      x.put("dataType", "8")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(emptyAoiRightRdd)区域基础数据错误量为Count: " + emptyAoiRightRdd.count())
    logger.error("地址不详业务逻辑验证完毕.............................................................")


    val multiZcRdd = zcRdd.filter(x => ("multiZc".equals(x._2.getString("wdTag")))).map(x => {
      x._2.put("statTag", "multiZc")
      x._2.put("dataType", "8")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(multiZcRdd)ZC存在多值的数据量为Count: " + multiZcRdd.count())

    val validPiPeiRdd = zcRdd.filter(x => ("validPiPei".equals(x._2.getString("wdTag")))).map(x => {
      x._2.put("statTag", "validPiPei")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(validPiPeiRdd)ZC仅有一个值的数据量为Count: " + validPiPeiRdd.count())

    // 7 基于ZC仅有一个值的数据再次判断该ZC的值是否等于depPonZc
    val depPonZcRdd = validPiPeiRdd.map(x => {
      val sn = x._1
      val json = x._2
      var zc = ""
      val reqBody = json.getJSONObject("reqBody")
      val zcTypeFlag = json.getString("wdTag")
      val depPonZc = json.getString("depponZc")
      if (reqBody != null && zcTypeFlag.equals("validPiPei")) {
        zc = StringToolUtil.convertString(reqBody.getString("zc"))
      }
      if (StringUtils.isNotEmpty(zc) && zc.toLowerCase().equals(depPonZc.toLowerCase())) {
        json.put("wdTag", "right")
      }
      (sn, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("验证并区分ZC是否与depPonZc的值是否一致后的数据量为Count: " + depPonZcRdd.count())
    val rightRdd = depPonZcRdd.filter(x => ("right".equals(x._2.getString("wdTag")))).map(x => {
      x._2.put("statTag", "right")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(rightRdd)其中ZC与depPonZc的值一致的数据量为Count: " + rightRdd.count())
    /** ###############################################################################################################################################################* */
    // TODO 错分数据 即ZC与depPonZc的值不不不一致
    val notRightRdd = depPonZcRdd.filter(x => (!"right".equals(x._2.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("ZC与depPonZc的值不不不一致的数据量为Count: " + notRightRdd.count())

    // 8. 验证数据一致前先加载德邦映射表数据,然后基于depPonZc的值获取depPonZc所对应的城市编码
    getDepPonZcCityCodeMap()

    // 9. 若zc与depPonZc的值不一致,则继续验证depPonZc对应的城市是签收数据中的cityCode 一致
    val depPonZcCityMapBroadcastTuple = spark.sparkContext.broadcast(Tuple1(depPonZcCityMap))
    val depPonZcCityCodeRdd = notRightRdd.map(x => {
      val sn = x._1
      val json = x._2
      val depPonZc = json.getString("depponZc")
      val depPonZcCityCodeOption = depPonZcCityMapBroadcastTuple.value._1.get(depPonZc)
      if (depPonZcCityCodeOption.nonEmpty) {
        val depPonZcCityCode = depPonZcCityCodeOption.get.toLowerCase().trim
        val cityCode = StringToolUtil.convertString(json.getString("cityCode")).toLowerCase().trim
        if (!depPonZcCityCode.equals(cityCode)) {
          json.put("wdTag", "otherCity")
        }
      }
      (sn, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("验证并区分depPonZcCityCode = cityCode是否一致后的数据量为Count: " + depPonZcCityCodeRdd.count())

    val otherCityRdd = depPonZcCityCodeRdd.filter(x => ("otherCity".equals(x._2.getString("wdTag")))).map(x => {
      x._2.put("statTag", "otherCity")
      x._2.put("dataType", "1")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(otherCityRdd)depPonZcCityCode与cityCode的值不不不一致的数据量为Count: " + otherCityRdd.count())
    val notOtherCityRdd = depPonZcCityCodeRdd.filter(x => (!"otherCity".equals(x._2.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中depPonZcCityCode与cityCode的值一致的数据量为Count: " + notOtherCityRdd.count())

    // 10. 若depPonZcCityCode与cityCode的值一致,则接下来继续验证keyWord是否存在
    val keyWordRdd = notOtherCityRdd.map(x => {
      val json = x._2
      val reqBody = json.getJSONObject("reqBody")
      if (reqBody != null) {
        val keyWord = StringToolUtil.convertString(reqBody.getString("keyWord"))
        if (StringUtils.isEmpty(keyWord))
          json.put("wdTag", "emptyKeyWord")
      }
      (x._1, json)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("验证keyWord是否存在后的数据量为Count: " + keyWordRdd.count())
    val notEmptyKeyWordRdd = keyWordRdd.filter(x => (!"emptyKeyWord".equals(x._2.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中keyWord不为空的数据量为Count: " + notEmptyKeyWordRdd.count())
    val emptyKeyWordRdd = keyWordRdd.filter(x => ("emptyKeyWord".equals(x._2.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中keyWord为空的数据量为Count: " + emptyKeyWordRdd.count())

    // 10.1 若存在keyWord即不为空的数据 则将请求数据中的adCode+keyWord去全量识别中查找
    val adCodeAndKeyWordRdd = notEmptyKeyWordRdd.map(x => {
      var selectKey = ""
      val sn = x._1
      val json = x._2
      val reqBody = json.getJSONObject("reqBody")
      if (reqBody != null) {
        val adCode = StringToolUtil.convertString(reqBody.getString("adcode"))
        val keyWord = StringToolUtil.convertString(reqBody.getString("keyWord"))
        selectKey = adCode + keyWord
      }
      (sn, (json, selectKey))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("adCode+keyWord为查找词的数据量为Count: " + adCodeAndKeyWordRdd.count())

    // 10.2 否则adCode+address去全量识别中查找
    val adCodeAndAddressRdd = emptyKeyWordRdd.map(x => {
      var selectKey = ""
      val sn = x._1
      val json = x._2
      val reqBody = json.getJSONObject("reqBody")
      if (reqBody != null) {
        val adCode = StringToolUtil.convertString(reqBody.getString("adcode"))
        val address = StringToolUtil.convertString(reqBody.getString("address"))
        selectKey = adCode + address
      }
      (sn, (json, selectKey))
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("adCode+address为查找词的数据量为Count: " + adCodeAndAddressRdd.count())
    // 10.3 Combiner
    val adCodeRdd = adCodeAndKeyWordRdd.union(adCodeAndAddressRdd)
    logger.error("获取满足条件的查找词数据量为Count: " + adCodeRdd.count())

    // TODO 查找词去全量识别中即validPiPei且为本市的数据中查找(即从validPiPei中剔除非本市数据)
    //  先获取全量识别中即validPiPei且为本市的数据中查找
    val validThisCityPiPeiRdd = validPiPeiRdd.leftOuterJoin(otherCityRdd).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        left.put("isPiPeiThisCity", "0")
      }
      (x._1, left)
    }).filter(x => !"0".equals(x._2.getString("isPiPeiThisCity"))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取全量识别数据中(即validPiPei)且为本市的数据" + validThisCityPiPeiRdd.count())

    val perRdd = validThisCityPiPeiRdd.leftOuterJoin(adCodeRdd).map(x => {
      var selectKey = ""
      val left = x._2._1 // validPiPei JSON
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        val right = rightOption.get
        selectKey = right._2
        left.put("wdTag", "isWd") // 额外标注有效匹配数据中有多少是错分的数据
      }
      (selectKey, left)
    }).filter(x => ("isWd".equals(x._2.getString("wdTag")))).aggregateByKey(scala.collection.mutable.MutableList[(JSONObject)]())((list, item) => {
      list += item
    }, (list1, list2) => list1 union list2).map(x => {
      (x._1, x._2.toList)
    }).flatMap(x => {
      val list = new util.ArrayList[JSONObject]()
      var totalCnt: Int = 0
      var wdCnt: Int = 0
      val iter = x._2.iterator
      while (iter.hasNext) {
        val json: JSONObject = iter.next
        list.add(json)
        if ("isWd".equals(json.getString("wdTag"))) {
          wdCnt = wdCnt + 1
        }
        totalCnt = totalCnt + 1
      }
      val per = wdCnt * 1.0 / totalCnt
      for (i <- 0 until list.size()) {
        val json = list.get(i)
        json.put("validPiPeiCnt", totalCnt + "")
        json.put("isWdCnt", wdCnt + "")
        json.put("per", per + "")
      }
      val ret = Array[JSONObject]()
      list.toArray(ret).iterator
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("全量查找后perRdd的数据量为: " + perRdd.count())
    perRdd.take(1).foreach(println(_))

    // 11. 验证全量查找后per是否小于0.8
    val buzRdd = perRdd.map(x => {
      val per = x.getString("per").toDouble
      if ("isWd".equals(x.getString("wdTag")) && per < 0.8) {
        x.put("wdTag", "buzErr")
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)


    logger.error("验证全量占比数据后的量为Count: " + buzRdd.count())
    val buzErrRdd = buzRdd.filter(x => ("buzErr".equals(x.getString("wdTag")))).map(x => {
      x.put("statTag", "buzErr")
      x.put("dataType", "2")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(buzErrRdd)其中per小于0.8的数据量为Count: " + buzErrRdd.count())
    val notBuzErrRdd = buzRdd.filter(x => (!"buzErr".equals(x.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("其中per大于0.8的数据量为Count: " + notBuzErrRdd.count())

    val notBuzErrWdRdd = notBuzErrRdd.filter(x => ("isWd".equals(x.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("per大于0.8的数据中筛选出wdTag=isWd即错分的的数据量为: " + notBuzErrWdRdd.count())

    val notBuzErrWdRdd2 = notBuzErrRdd.map(x => {
      val reqBody = x.getJSONObject("reqBody")
      val address = StringToolUtil.convertString(reqBody.getString("address"))
      if (address.endsWith("对面")) {
        x.put("wdTag", "addressEndWithopposite")
      }
      x
    }
    ).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("计算address以对面结尾的数据")

    val addressEndWithopposite = notBuzErrWdRdd2.filter(x => "addressEndWithopposite".equals(x.getString("wdTag"))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addressEndWithopposite数据量为" + addressEndWithopposite.count())


    //筛选src为norm的数据
    val notBuzErrWdRdd3 = notBuzErrWdRdd2.map(x => {
      val reqBody = x.getJSONObject("reqBody")
      if (null != reqBody) {
        var src = reqBody.getString("src")
        val dataSrc = reqBody.getString("dataSrc")
        if (StringUtils.isNotEmpty(src)) {
          src = src.replace("|", "_")
          if ("norm".equals(src))
            x.put("wdTag", "waitDefine")
        } else if (StringUtils.isNotEmpty(dataSrc)) {
          if ("DB_RDS".equals(dataSrc))
            x.put("wdTag", "waitDefine")
        }
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("notBuzErrWdRdd3数据量为" + notBuzErrWdRdd3.count())

    val notBuzErrWdRdd4 = notBuzErrWdRdd3.repartition(3).filter(x => "waitDefine".equals(x.getString("wdTag"))).map(x => {
      val reqBody = x.getJSONObject("reqBody")
      val address = StringToolUtil.convertString(reqBody.getString("address"))
      val addressid = StringToolUtil.convertString(reqBody.getString("group"))
      val cityCode = reqBody.getString("cityCode")
      if (addressid != null) {
        if (address.contains("对面")) {
          val keyWord = scheduleCmsInterface(cmsKeyWordUrlBroadcast.value, cityCode, addressid)
          if (address.contains(keyWord)) {
            val beginIndex = address.indexOf(keyWord) + keyWord.length
            val substr = address.substring(beginIndex)

            if (substr != null) {
              if (substr.contains("（") && substr.contains("）")) {
                val prefix = substr.indexOf("（")
                val endfix = substr.indexOf("）")
                val deletebracketspre = substr.substring(0, prefix)
                val deletebracketsend = substr.substring(endfix)
                val deletebrackets = deletebracketspre + deletebracketsend
                val containsStrArray = Array("对面", "东", "南", "西", "北", "东南", "东北", "西南", "西北")
                for (i <- containsStrArray) {
                  if (deletebrackets.contains(i)) {
                    x.put("wdTag", "wrong_pipei")
                  }
                }
                val pattern = new Regex("([0-9]+)(米|千米)")
                if (pattern.findAllMatchIn(deletebrackets) != null) {
                  x.put("wdTag", "wrong_pipei")
                }
              } else {
                val containsStrArray = Array("对面", "东", "南", "西", "北", "东南", "东北", "西南", "西北")
                for (i <- containsStrArray) {
                  if (substr.contains(i)) {
                    x.put("wdTag", "wrong_pipei")
                  }
                }
                val pattern = new Regex("([0-9]+)(米|千米)")
                if (pattern.findAllMatchIn(substr).toList.size != 0) {
                  x.put("wdTag", "wrong_pipei")
                }
              }
            }
          }
        }
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val wrong_pipei = notBuzErrWdRdd4.repartition(6).filter(x => "wrong_pipei".equals(x.getString("wdTag"))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("wrong_pipei数据量为" + wrong_pipei.count())

    logger.error("针对Per大于0.8的错分数据开始验证是否具有高精坐标坐标..........................")

    // 验证是否有获取到高精坐标
    // 12. 先基于MapA URL获取高精坐标
    logger.error("先基于MapA 获取高精坐标和坐标对应的AOI信息......")
    val mapARdd = getMapAPointAndAoiRdd(notBuzErrWdRdd, mapAUrlBroadcast, mapAXyBroadcast, dept2AoiUrlBroadcast).map(x => {
      // 添加标注标签信息：若没有获取到高精坐标 则 wdTag = wd;  若没有获取到坐标AOI 则wdTag = wd
      val mapAJson = x.getJSONObject(mapAXyBroadcast.value)
      if (mapAJson != null) {
        if ("2".equals(mapAJson.getString("precision"))) {
          if (StringUtils.isNotEmpty(mapAJson.getString("x")) && StringUtils.isNotEmpty(mapAJson.getString("y"))) {
            if (StringUtils.isEmpty(mapAJson.getString("aoi_id")))
            //x.put("wdTag","judge_buzErrZC")
              x.put("wdTag", "judgeUndefine")
          }
          else
            x.put("wdTag", "judge_buzErrZC")

        } else
          x.put("wdTag", "judge_buzErrZC")
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("mapARdd的数据量为Count: " + mapARdd.count())
    logger.error("再基于图商 URL 获取高精坐标和坐标对应的AOI信息......")

    val judgeUndefineCal = mapARdd.filter(x => ("judgeUndefine".equals(x.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("judgeUndefine的数据量为Count: " + judgeUndefineCal.count())
    mapARdd.take(1).foreach(println(_))

    val tsRdd = getMapAPointAndAoiRdd(mapARdd, tsUrlBroadcast, tsXyBroadcast, dept2AoiUrlBroadcast).map(x => {
      // 添加标注标签信息：若没有获取到高精坐标 则 wdTag = wd;  若没有获取到坐标AOI 则wdTag = wd
      val tsJson = x.getJSONObject(tsXyBroadcast.value)
      if (tsJson != null) {
        if ("2".equals(tsJson.getString("precision"))) {
          if (StringUtils.isNotEmpty(tsJson.getString("x")) && StringUtils.isNotEmpty(tsJson.getString("y"))) {
            if (StringUtils.isNotEmpty(tsJson.getString("aoi_id"))) {
              if ("judgeUndefine".equals(x.getString("wdTag"))) {
                x.put("wdTag", "judge_buzErrXY")
              }
            }
          }
          else
            x.put("wdTag", "judge_buzErrZC")

        } else
          x.put("wdTag", "judge_buzErrZC")
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    tsRdd.take(1).foreach(println(_))
    logger.error("tsRdd的数据量为Count: " + tsRdd.count())

    //均有高精坐标无aoi的数据获取zc，来判断是否是buzErrXyRight
    val buzErrXyZCRightCalculate = tsRdd.filter(x => ("judge_buzErrXY".equals(x.getString("wdTag")))).repartition(1).map(x => {
      val tsJson = x.getJSONObject(tsXyBroadcast.value)
      val mapaJson = x.getJSONObject(mapAXyBroadcast.value)
      var ts_xy_Zc = ""
      var mapa_xy_Zc = ""

      if (tsJson != null) {
        if (StringUtils.isNotEmpty(tsJson.getString("x")) && StringUtils.isNotEmpty(tsJson.getString("y"))) {
          val x1 = tsJson.getString("x")
          val y1 = tsJson.getString("y")
          ts_xy_Zc = scheduleDeBangXYInterface(xyDeBangBroadcast, x1, y1)
          x.put("ts_xy_Zc", ts_xy_Zc)
        }
      }
      if (mapaJson != null) {
        if (StringUtils.isNotEmpty(mapaJson.getString("x")) && StringUtils.isNotEmpty(mapaJson.getString("y"))) {
          val x2 = mapaJson.getString("x")
          val y2 = mapaJson.getString("y")
          mapa_xy_Zc = scheduleDeBangXYInterface(xyDeBangBroadcast, x2, y2)
          x.put("mapa_xy_Zc", mapa_xy_Zc)
        }
      }

      val reqBody = x.getJSONObject("reqBody")
      val gisZc = StringToolUtil.convertString(reqBody.getString("zc"))

      if (ts_xy_Zc.equals(mapa_xy_Zc) && ts_xy_Zc.equals(gisZc)) {
        x.put("wdTag", "buzErrXyZCRight")
        x.put("Type", "4")
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrXyZCRightCalculate的数据量为" + buzErrXyZCRightCalculate.count())
    buzErrXyZCRightCalculate.take(1).foreach(println(_))


    //mapa和高德不完全有高精坐标的数据调用zcModel端口获取是否是buzErrZCModelRight
    val buzErrZCModelRightCalculate = tsRdd.filter(x => ("judge_buzErrZC".equals(x.getString("wdTag")))).union(buzErrXyZCRightCalculate.filter(x => !("buzErrXyZCRight".equals(x.getString("wdTag"))))).repartition(5).map(x => {
      val tsJson = x.getJSONObject(tsXyBroadcast.value)
      val mapAXyJson = x.getJSONObject(mapAXyBroadcast.value)
      val tsX = tsJson.getString("x")
      val tsY = tsJson.getString("y")
      val mapAX = mapAXyJson.getString("x")
      val mapAY = mapAXyJson.getString("y")

      val tsJo = scheduleDept2Interface(tsUrlBroadcast.value, tsX, tsY)

      val ts_aoi_id = tsJo.getString("aoi_id")
      val ts_aoi_code = tsJo.getString("aoi_code")
      val ts_aoi_name = tsJo.getString("aoi_name")

      val mapAJo = scheduleDept2Interface(mapAUrlBroadcast.value, mapAX, mapAY)
      val mapA_aoi_id = mapAJo.getString("aoi_id")
      val mapA_aoi_code = mapAJo.getString("aoi_code")
      val mapA_aoi_name = mapAJo.getString("aoi_name")

      tsJson.put("aoi_id", ts_aoi_id)
      tsJson.put("aoi_code", ts_aoi_code)
      tsJson.put("aoi_name", ts_aoi_name)
      mapAXyJson.put("aoi_id", ts_aoi_id)
      mapAXyJson.put("aoi_code", ts_aoi_code)
      mapAXyJson.put("aoi_name", ts_aoi_name)
      x.put(tsXyBroadcast.value, tsJson)
      x.put(mapAXyBroadcast.value, mapAXyJson)

      val reqBody = x.getJSONObject("reqBody")
      val depPonCode = x.getString("depponCode")
      val address = StringToolUtil.convertString(reqBody.getString("address"))
      val gisZc = StringToolUtil.convertString(reqBody.getString("zc"))
      var dataSrc = reqBody.getString("dataSrc")
      if (StringUtils.isNotEmpty(dataSrc)) {
        dataSrc = dataSrc.replace("|", "_")
        //rds等于datasrc
        if ("RDS".equals(dataSrc.toUpperCase()) || "DB_RDS".equals(dataSrc.toUpperCase())) {
          val modelZc = scheduleZcModelInterface(zcModelUrlBroadcast.value.toString, depPonCode, address)
          x.put("model_Zc", modelZc)
          if (null != modelZc) {
            if (gisZc.equals(modelZc)) {
              x.put("wdTag", "buzErrZCModelRight")
              x.put("Type", "4")
            }
          }
        }
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val buzErrZCModelRight_pre = buzErrZCModelRightCalculate.filter(x => ("buzErrZCModelRight".equals(x.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrZCModelRight_pre数据量为" + buzErrZCModelRight_pre.count())
    val buzErrXyZCRight_pre = buzErrXyZCRightCalculate.filter(x => ("buzErrXyZCRight".equals(x.getString("wdTag")))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrXyZCRight_pre数据量为" + buzErrXyZCRight_pre.count())

    // 13. 验证园区 以及三者AOI ID是否相等
    val srcRdd = tsRdd.filter(x => (!"judge_buzErrZC".equals(x.getString("wdTag"))) && (!"judge_buzErrXY".equals(x.getString("wdTag")))).repartition(1).map(obj => {
      val reqBody = obj.getJSONObject("reqBody")
      if (reqBody != null) {
        val src = reqBody.getString("src")
        val dataSrc = reqBody.getString("dataSrc")
        // 若src = norm
        if ("norm".equals(src) || (StringUtils.isNotEmpty(dataSrc) && "DB_RDS".equals(dataSrc))) {
          val endStrArray = Array("产业园", "创业园", "园区", "工业园", "科技园")
          val containStrArray = Array("栋", "区")
          val standardization = JSONUtil.getJsonVal(obj, "standardization", "")
          for (itemEnd <- endStrArray) {
            if (standardization.endsWith(itemEnd)) {
              for (itemContain <- containStrArray) {
                if (standardization.contains(itemContain)) {
                  // obj.put("tag","standardization结尾符合要求")
                  obj.put("wdTag", "wd")
                }
              }
            }
          }
        }
        val mapAGjXyAoi = JSONUtil.getJsonVal(obj, "mapAXy.aoi_id", "")
        val tsGjXyAoi = JSONUtil.getJsonVal(obj, "tsXy.aoi_id", "")
        val aoiId = JSONUtil.getJsonVal(reqBody, "aoiid", "")

        val tsJson = obj.getJSONObject(tsXyBroadcast.value)
        val mapaJson = obj.getJSONObject(mapAXyBroadcast.value)
        var ts_xy_Zc = ""
        var mapa_xy_Zc = ""
        if (tsJson != null) {
          if (StringUtils.isNotEmpty(tsJson.getString("x")) && StringUtils.isNotEmpty(tsJson.getString("y"))) {
            val x1 = tsJson.getString("x")
            val y1 = tsJson.getString("y")
            ts_xy_Zc = scheduleDeBangXYInterface(xyDeBangBroadcast, x1, y1)
          }
        }
        if (mapaJson != null) {
          if (StringUtils.isNotEmpty(mapaJson.getString("x")) && StringUtils.isNotEmpty(mapaJson.getString("y"))) {
            val x2 = mapaJson.getString("x")
            val y2 = mapaJson.getString("y")
            mapa_xy_Zc = scheduleDeBangXYInterface(xyDeBangBroadcast, x2, y2)
          }
        }

        val mapaAoiZc = scheduleDeBangAoiInterface(aoiDeBangBroadcast, mapAGjXyAoi)
        val tsAoiZc = scheduleDeBangAoiInterface(aoiDeBangBroadcast, tsGjXyAoi)
        obj.put("mapaAoiZc", mapaAoiZc)
        obj.put("tsAoiZc", tsAoiZc)
        obj.put("ts_xy_Zc", ts_xy_Zc)
        obj.put("mapa_xy_Zc", mapa_xy_Zc)

        //        val mapaJsonOutput = new JSONArray()
        //        mapaJsonOutput.add(mapaAoiZc.asJava)
        //        val tsAoiZcOutput = new JSONArray()
        //        tsAoiZcOutput.add(tsAoiZc.asJava)
        //
        //        if(mapaJsonOutput != null){
        //          obj.put("mapaAoiZc",mapaJsonOutput)
        //        }
        //        if(tsAoiZcOutput != null){
        //          obj.put("tsAoiZc",tsAoiZcOutput)
        //        }
        //        if(ts_xy_Zc != null){
        //          obj.put("ts_xy_Zc",ts_xy_Zc)
        //        }
        //        if(mapa_xy_Zc != null){
        //          obj.put("mapa_xy_Zc",mapa_xy_Zc)
        //        }
        if (StringUtils.isEmpty(aoiId) || StringUtils.isEmpty(mapAGjXyAoi) || StringUtils.isEmpty(tsGjXyAoi)
          || !aoiId.equals(mapAGjXyAoi) || !aoiId.equals(tsGjXyAoi)) {
          // obj.put("tag","三方aoi不相等")
          obj.put("wdTag", "new_undefine")
        }
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("src的数据量为Count: " + srcRdd.count())
    srcRdd.take(4).foreach(println(_))


    //执行更新后的逻辑
    val newMapaGdZcsrcRdd = srcRdd.filter(x => ("new_undefine").equals(x.getString("wdTag"))).map(x => {

      val depPonZc = x.getString("depponZc")
      val mapaAoiZc = JSONUtil.getJsonVal(x, "mapaAoiZc", "")
      val tsAoiZc = JSONUtil.getJsonVal(x, "tsAoiZc", "")
      //      val mapaAoiZc = x.getJSONArray("mapaAoiZc")
      //      val tsAoiZc = x.getJSONArray("tsAoiZc")
      //      var mapaAoiFlag = false
      //      if(mapaAoiZc != null){
      //        for(i <- mapaAoiZc.toArray())
      //          if(i.toString.contains(depPonZc))
      //            mapaAoiFlag = true
      //      }
      //      var tsAoiFlag = false
      //      if(tsAoiZc != null){
      //        for(j <- tsAoiZc.toArray())
      //          if(j.toString.contains(depPonZc))
      //            tsAoiFlag = true
      //      }

      val ts_xy_Zc = JSONUtil.getJsonVal(x, "ts_xy_Zc", "")
      val mapa_xy_Zc = JSONUtil.getJsonVal(x, "mapa_xy_Zc", "")

      val reqBody = x.getJSONObject("reqBody")
      val gisZc = StringToolUtil.convertString(reqBody.getString("zc"))
      //val depPonCode = x.getString("depponCode")
      // val address = StringToolUtil.convertString(reqBody.getString("address"))
      val mapaAoi = JSONUtil.getJsonVal(x, "mapAXy.aoi_id", "")
      val tsAoi = JSONUtil.getJsonVal(x, "tsXy.aoi_id", "")
      val aoiId = JSONUtil.getJsonVal(reqBody, "aoiid", "")


      if (aoiId.equals(tsAoi) && !aoiId.equals(mapaAoi)) {
        //判断mapaAoiZc是否包含depPonZc 是则标识下一步判断逻辑
        if (mapaAoiZc.contains(depPonZc)) {
          x.put("wdTag", "judge_buzErrXY")
        } else {
          //mapa_xyZC是否包含depponzc 是则执行最终判断
          if (mapa_xy_Zc.contains(depPonZc)) {
            x.put("wdTag", "judge_buzErrXY")
          } else {
            x.put("wdTag", "undefine_Zc")
          }
        }
      } else {
        //判断aoiid和mapaaoi 是否相等，如果不等则执行最终判断
        if (aoiId.equals(mapaAoi) && !aoiId.equals(tsAoi)) {
          if (tsAoiZc.contains(depPonZc)) {
            //最终判断
            x.put("wdTag", "judge_buzErrXY")
          } else {
            //判断gd_xyZC包含depponzc 是的话执行最终判断
            if (ts_xy_Zc.contains(depPonZc)) {
              x.put("wdTag", "judge_buzErrXY")
            } else {
              x.put("wdTag", "undefine_Zc")
            }
          }
        } else {
          //最终判断
          x.put("wdTag", "judge_buzErrXY")
        }
      }
      x
    }
    ).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //newMapaGdZcsrcRdd.take(1).foreach(println(_))
    newMapaGdZcsrcRdd.take(2).foreach(println(_))
    logger.error("newMapaGdZcsrcRdd数据量为" + newMapaGdZcsrcRdd.count())


    // 14.查询德邦AOI与面积多边形相交占比
    val polygonIntersectRdd1 = schedulePolygonIntersectInterface(spark, srcRdd.filter(x => (!"wd".equals(x.getString("wdTag")) && !("new_undefine".equals(x.getString("wdTag"))))), aoiIntersectPerUrlBroadcast).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val polygonIntersectRdd2 = schedulePolygonIntersectInterface(spark, newMapaGdZcsrcRdd.filter(x => ("undefine_Zc".equals(x.getString("wdTag")))), aoiIntersectPerUrlBroadcast).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("额外的polygonIntersectRdd2的数据量为:" + polygonIntersectRdd2.count())
    val polygonIntersectRdd = polygonIntersectRdd1.union(polygonIntersectRdd2)
    logger.error("polygonIntersectRdd的数据量为:" + polygonIntersectRdd.count())
    val buzErrAoiRightRdd = polygonIntersectRdd.filter(obj => "buzErrAoiRight".equals(JSONUtil.getJsonVal(obj, "wdTag", ""))).map(x => {
      x.put("statTag", "buzErrAoiRight")
      x.put("dataType", "4")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("(buzErrAoiRightRdd)aoi多边形交叉剔除量:" + buzErrAoiRightRdd.count())
    val notBuzErrAoiRightRdd = polygonIntersectRdd.filter(obj => !"buzErrAoiRight".equals(JSONUtil.getJsonVal(obj, "wdTag", ""))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("aoi多边形交叉未剔除: " + notBuzErrAoiRightRdd.count())


    val newMapaGdZcsrcRdd2 = newMapaGdZcsrcRdd.filter(x => !("undefine_Zc".equals(x.getString("wdTag")))).union(notBuzErrAoiRightRdd).map(x => {
      val ts_xy_Zc = JSONUtil.getJsonVal(x, "ts_xy_Zc", "")
      val mapa_xy_Zc = JSONUtil.getJsonVal(x, "mapa_xy_Zc", "")

      val reqBody = x.getJSONObject("reqBody")
      val gisZc = StringToolUtil.convertString(reqBody.getString("zc"))

      if (ts_xy_Zc.equals(mapa_xy_Zc) && ts_xy_Zc.equals(gisZc)) {
        x.put("wdTag", "buzErrXyZCRight")
        x.put("Type", "4")
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    newMapaGdZcsrcRdd2.take(1).foreach(println(_))


    logger.error("newMapaGdZcsrcRdd2的数据量为" + newMapaGdZcsrcRdd2.count())


    val newMapaGdZcsrcRdd3 = newMapaGdZcsrcRdd2.filter(x => (!"buzErrXyZCRight".equals(x.getString("wdTag")))).repartition(2).map(x => {
      val reqBody = x.getJSONObject("reqBody")
      var dataSrc = reqBody.getString("dataSrc")
      val depPonCode = x.getString("depponCode")
      val address = reqBody.getString("address")
      val gisZc = StringToolUtil.convertString(reqBody.getString("zc"))
      val mapaAoiZc = JSONUtil.getJsonVal(x, "mapaAoiZc", "")
      val tsAoiZc = JSONUtil.getJsonVal(x, "tsAoiZc", "")
      val depPonZc = JSONUtil.getJsonVal(x, "depponZc", "")
      val ts_xy_Zc = JSONUtil.getJsonVal(x, "ts_xy_Zc", "")
      val mapa_xy_Zc = JSONUtil.getJsonVal(x, "mapa_xy_Zc", "")

      val modelZc = scheduleZcModelInterface(zcModelUrlBroadcast.value.toString, depPonCode, address)
      x.put("model_Zc", modelZc)

      if (StringUtils.isNotEmpty(dataSrc)) {
        if ("RDS".equals(dataSrc) || "DB_RDS".equals(dataSrc)) {
          if (null != modelZc) {
            if (gisZc.equals(modelZc)) {
              if (mapaAoiZc.contains(depPonZc) && tsAoiZc.contains(depPonZc) && mapa_xy_Zc.contains(depPonZc) && ts_xy_Zc.contains(depPonZc)) {
                x.put("wdTag", "wd")
              } else {
                x.put("wdTag", "buzErrZCModelRight")
                x.put("Type", "4")
              }
            } else {
              x.put("wdTag", "wd")
            }
          } else {
            x.put("wdTag", "wd")
          }
        } else {
          x.put("wdTag", "wd")
        }
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("newMapaGdZcsrcRdd3的数据量为" + newMapaGdZcsrcRdd3.count())
    newMapaGdZcsrcRdd3.take(2).foreach(println(_))
    //newMapaGdZcsrcRdd3.collect().map(println(_))

    //判断aoi与gdaoi与mapaAOI
    val buzErrXyZCRight = newMapaGdZcsrcRdd2.filter(x => "buzErrXyZCRight".equals(x.getString("wdTag"))).union(buzErrXyZCRight_pre).map(x => {
      x.put("dataType", "4")
      x.put("statTag", "buzErrXyZCRight")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrXyZCRight数据量为" + buzErrXyZCRight.count())
    val buzErrZCModelRight = newMapaGdZcsrcRdd3.filter(x => "buzErrZCModelRight".equals(x.getString("wdTag"))).union(buzErrZCModelRight_pre).map(x => {
      x.put("dataType", "4")
      x.put("statTag", "buzErrZCModelRight")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrZCModelRight数据量为" + buzErrZCModelRight.count())

    val buzErrXyZc_All = buzErrXyZCRight.union(buzErrZCModelRight).map(x => (x.getString("sn"), x)).reduceByKey((x, y) => x)
    logger.error("查询占比的总量为" + buzErrXyZc_All.count())

    val standardWdRddNewPre = ((srcRdd.union(buzErrZCModelRightCalculate).map(x => (x.getString("sn"), x))).leftOuterJoin(((buzErrAoiRightRdd.union(buzErrRdd).union(buzErrZCModelRight)).map(x => (x.getString("sn"), x)).union(otherCityRdd)).union(buzErrXyZc_All).reduceByKey((x, y) => x))).repartition(5).map(x => {
      val leftBody = x._2._1
      val rightOption = x._2._2
      var isWdFlag = true
      if (rightOption.nonEmpty) {
        isWdFlag = false
      }
      (isWdFlag, leftBody)
    }).filter(x => x._1).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("standardWdRddNewPre的数据量为：" + standardWdRddNewPre.count())

    //    standardWdRddNewPre.map(x => {
    //      (x._1.toString,x._2.toJSONString)
    //    }).toDF("isWdFalg","leftBody").write.mode(SaveMode.Overwrite).insertInto("dm_gis.deppon_temp_test")

    val standardWdRddNew = standardWdRddNewPre.repartition(1).map(x => {
      val reqBody = x._2.getJSONObject("reqBody")
      var mapaXyZc = x._2.getString("mapaXyZc")
      var tsXyZc = x._2.getString("ts_xy_Zc")
      val gisZc = reqBody.getString("zc")
      val tsJson = x._2.getJSONObject(tsXyBroadcast.value)
      val mapAJson = x._2.getJSONObject(mapAXyBroadcast.value)

      var mapaAoiId = mapAJson.getString("aoi_id")
      var mapaAoiName = mapAJson.getString("aoi_name")
      var tsAoiId = tsJson.getString("aoi_id")
      var tsAoiName = tsJson.getString("aoi_name")

      if (StringUtils.isEmpty(tsXyZc) || StringUtils.isEmpty(mapaXyZc)) {
        val tsX = tsJson.getString("x")
        val tsY = tsJson.getString("y")
        val mapAX = mapAJson.getString("x")
        val mapAY = mapAJson.getString("y")
        if (tsJson != null) {
          if (StringUtils.isNotEmpty(tsJson.getString("x")) && StringUtils.isNotEmpty(tsJson.getString("y"))) {

            tsXyZc = scheduleDeBangXYInterface(xyDeBangBroadcast, tsX, tsY)
            x._2.put("ts_xy_Zc", tsXyZc)
          }
        }

        if (mapAJson != null) {
          if (StringUtils.isNotEmpty(mapAJson.getString("x")) && StringUtils.isNotEmpty(mapAJson.getString("y"))) {
            mapaXyZc = scheduleDeBangXYInterface(xyDeBangBroadcast, mapAX, mapAY)
            x._2.put("mapaXyZc", mapaXyZc)
          }
        }

        if (StringUtils.isEmpty(mapaAoiId)) {
          val mapAJo = scheduleDept2Interface(mapAUrlBroadcast.value, mapAX, mapAY)

          mapaAoiId = JSONUtil.getJsonVal(mapAJo, "aoi_id", "-")
          mapaAoiName = JSONUtil.getJsonVal(mapAJo, "aoi_name", "-")
          mapAJson.put("aoi_id", mapaAoiId)
          mapAJson.put("aoi_name", mapaAoiName)
          x._2.put(mapAXyBroadcast.value, mapAJson)
        }

        if (StringUtils.isEmpty(tsAoiId)) {
          val tsJo = scheduleDept2Interface(tsUrlBroadcast.value, tsX, tsY)
          tsAoiId = JSONUtil.getJsonVal(tsJo, "aoi_id", "-")
          tsAoiName = JSONUtil.getJsonVal(tsJo, "aoi_name", "-")
          tsJson.put("aoi_id", tsAoiId)
          tsJson.put("aoi_name", tsAoiName)
          x._2.put(tsXyBroadcast.value, tsJson)
        }

      }

      var similarity_max = 0.0
      var index = 0

      if (null != reqBody) {
        val aoiId = reqBody.getString("aoiid")
        val address = reqBody.getString("address")
        val addressGetSplit = address.replaceAll("\\s", "")
        val cityCode = reqBody.getString("cityCode").substring(0, 6)
        //val adcode = reqBody.getString("adcode")
        val aoiName = scheduleDeBangAoiNameInterface(aoiNameUrl, aoiId)
        val splitResult = scheduleSplitResultInterface(splitResultUrl, addressGetSplit, cityCode)

        val addressNew = address.toLowerCase.replace("零", "0").replace("一", "1").replace("二", "2").replace("三", "3")
          .replace("四", "4").replace("五", "5").replace("六", "6")
          .replace("七", "7").replace("八", "8").replace("九", "9")
        val splitResultNew = splitResult.toLowerCase.replace("零", "0").replace("一", "1").replace("二", "2").replace("三", "3")
          .replace("四", "4").replace("五", "5").replace("六", "6")
          .replace("七", "7").replace("八", "8").replace("九", "9")
        val aoi_name = aoiName.toLowerCase.replace("零", "0").replace("一", "1").replace("二", "2").replace("三", "3")
          .replace("四", "4").replace("五", "5").replace("六", "6")
          .replace("七", "7").replace("八", "8").replace("九", "9")
        val split = splitResultNew.split("\\|")

        val map = mutable.HashMap()
        val regexAll = new Regex("\\^16|\\^26|\\^113|\\^213|\\^313|\\^513|\\^813")
        val pattern613 = new Regex(".*\\^613")
        val getWordRex = new Regex("(.*)\\^[1-9+]")
        val isVillage = new Regex(".*村\\^[1-9+]")
        val isVillage2 = new Regex(".*村$")

        if (split.size > 1) {
          for (i <- 0 until (split.size)) {

            if (regexAll.findFirstMatchIn(split(i)) != None) {
              var similar = 0.0
              if ((i + 1 < split.size) && pattern613.findFirstIn(split(i + 1)) != None) {
                val getWord = getWordRex.findAllMatchIn(split(i)).map(_.group(1)).toList.mkString("")
                val getWord613 = getWordRex.findAllMatchIn(split(i + 1)).map(_.group(1)).toList.mkString("")
                val word = getWord + getWord613
                val builder = new StringBuilder
                val builder1 = builder.append(word).append("^").append("613").toString()

                if (isVillage2.findFirstIn(builder1) != None) {
                  val str = builder1.replace("村", "")
                  val new_word = getWordRex.findAllMatchIn(str).map(_.group(1)).toList.mkString("")

                  if (aoi_name.contains(new_word) || new_word.contains(aoi_name)) {
                    similar = 1
                  } else {
                    similar = 0
                  }
                } else {
                  val str = builder1.replace("有限公司", "")
                  val getWord = getWordRex.findAllMatchIn(str)
                  val new_word = getWord.map(_.group(1)).toList.mkString("")

                  val similarRet = GetSimilar.getReult(new_word, aoi_name)
                  similar = similarRet
                }
              } else {
                val word = getWordRex.findAllMatchIn(split(i)).map(_.group(1)).toList.mkString("")
                if (isVillage2.findFirstIn(aoi_name) != None) {
                  val aoi_name_new = aoi_name.replace("村", "")
                  //val str = word.replace("村", "")
                  // val new_word = getWordRex.findAllMatchIn(split(i)).map(_.group(1)).toList.mkString("")
                  if (aoi_name_new.contains(word) || word.contains(aoi_name)) {
                    similar = 1
                  } else {
                    similar = 0
                  }
                } else {
                  val str = split(i).replace("有限公司", "")
                  val getWord = getWordRex.findAllMatchIn(str)
                  // println(getWord)
                  val new_word = getWord.map(_.group(1)).toList.mkString("")
                  // println(new_word)
                  val similarRet = GetSimilar.getReult(new_word, aoi_name)
                  similar = similarRet
                }

              }
              if (similar > similarity_max && ((i + 1 < split.size) && pattern613.findFirstIn(split(i + 1)) != None)) {
                similarity_max = similar
                index = i + 1
              } else if (similar > similarity_max) {
                similarity_max = similar
                index = i
              }
            }
          }
        }
        x._2.put("similar", similarity_max)
        if (similarity_max > 0.5) {
          var strFlag = "0"
          for (i <- index until (split.size)) {
            val pattern18 = new Regex(".*\\^[1-9]18")
            if (pattern18.findFirstMatchIn(split(i)) != None) {
              val containsStrArray = Array("东", "南", "西", "北")
              for (j <- containsStrArray) {
                if (split(i).contains(j)) {
                  strFlag = "1"
                }
              }
              if ("1".equals(strFlag)) {
                x._2.put("isWd", "0")
              }
            }
          }
          val regexAddr = new Regex("(村)?([a-zA-Z0-9一二三四五六七八九十东西南北]{1})([期|组|区])")

          //val getWord = getWordRex.findAllMatchIn(split(i)).map(_.group(1)).toList.mkString("")
          var addrMatch = regexAddr.findFirstMatchIn(addressNew).map(_.group(0)).toList.mkString("")
          var aoiMatch = regexAddr.findFirstMatchIn(aoi_name).map(_.group(0)).toList.mkString("")
          if (StringUtils.isEmpty(addrMatch))
            addrMatch = "-"
          if (StringUtils.isEmpty(aoiMatch))
            aoiMatch = "-"
          if ((addrMatch.equals("-") && aoiMatch.equals("-")) || (!addrMatch.equals("-") && !aoiMatch.equals("-"))) {
            if (!addrMatch.equals(aoiMatch) && (!addrMatch.equals("-") && !aoiMatch.equals("-"))) {
              x._2.put("isWd", "1")
            } else {
              //mapa_xyZC=gd_xyZC(非空)且mapa_xyZC !=giszc
              if (!StringUtils.isEmpty(tsXyZc) && !StringUtils.isEmpty(mapaXyZc) && mapaXyZc.equals(tsXyZc) && !mapaXyZc.equals(gisZc)) {
                x._2.put("isWd", "1")
              } else {
                //mapa坐标为高精且mapa_xyZC !=giszc或gd坐标为高精且gd_xyZC !=giszc

                if ((!StringUtils.isEmpty(mapaXyZc) && "2".equals(mapAJson.getString("precision")) && mapaXyZc != gisZc) || (!StringUtils.isEmpty(tsXyZc) && "2".equals(tsJson.getString("precision")) && tsXyZc != gisZc)) {
                  x._2.put("isWd", "1")
                } else {
                  if ((!StringUtils.isEmpty(aoiId) && !StringUtils.isEmpty(aoi_name) && mapaAoiName.contains(aoi_name) && !mapaAoiId.equals(aoiId)) || (!StringUtils.isEmpty(aoiId) && !StringUtils.isEmpty(aoi_name) && tsAoiName.contains(aoi_name) && !tsAoiId.equals(aoiId))) {
                    x._2.put("isWd", "1")
                  } else {
                    if (aoi_name.contains("村") && !aoi_name.endsWith("村")) {
                      x._2.put("isWd", "1")
                    } else {
                      var endStrFlag = "0"
                      val endStrArray = Array("产业园", "创业园", "园区", "工业园", "科技园")
                      for (itemEnd <- endStrArray) {
                        if (aoi_name.endsWith(itemEnd)) {
                          endStrFlag = "1"
                        }
                      }
                      if ("1".equals(endStrFlag)) {
                        x._2.put("isWd", "1")
                      }
                    }
                  }
                }
              }
            }
          } else {
            x._2.put("isWd", "1")
          }
        } else
          x._2.put("isWd", "1")
      }
      x._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("standardWdRddNew处理的数据量为：" + standardWdRddNew.count())
    standardWdRddNew.take(2).foreach(println(_))

    val judge_buzErrconfigRight_pre = standardWdRddNew.filter(x => !"1".equals(x.getString("isWd"))).map(x => {
      val reqBody = x.getJSONObject("reqBody")
      if (null != reqBody) {
        val aoiId = reqBody.getString("aoiid")
        val address = reqBody.getString("address")
        val adcode = reqBody.getString("adcode")
        val aoiName = scheduleDeBangAoiNameInterface(aoiNameUrl, aoiId)
        val aoi_name = aoiName.toLowerCase.replace("零", "0").replace("一", "1").replace("二", "2").replace("三", "3")
          .replace("四", "4").replace("五", "5").replace("六", "6")
          .replace("七", "7").replace("八", "8").replace("九", "9")
        val addressNew = address.toLowerCase.replace("零", "0").replace("一", "1").replace("二", "2").replace("三", "3")
          .replace("四", "4").replace("五", "5").replace("六", "6")
          .replace("七", "7").replace("八", "8").replace("九", "9")
        if (aoi_name.endsWith("社区") && !addressNew.endsWith("社区")) {
          x.put("wdTag", "judge_buzErrconfigRight")
        } else {
          x.put("wdTag", "buzErrsimilarityRight")
        }
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("judge_buzErrconfigRight_pre处理的数据量为：" + judge_buzErrconfigRight_pre.count())
    judge_buzErrconfigRight_pre.take(2).foreach(println(_))

    val buzErrsimilarityRight = judge_buzErrconfigRight_pre.filter(x => "buzErrsimilarityRight".equals(x.getString("wdTag"))).map(x => {
      x.put("dataType", "4")
      x.put("statTag", "buzErrsimilarityRight")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrsimilarityRight的数据量为：" + buzErrsimilarityRight.count())
    buzErrsimilarityRight.take(2).foreach(println(_))


    //202104版之前剔除表位置
    val buzErrconfigRightCal = judge_buzErrconfigRight_pre.filter(x => "judge_buzErrconfigRight".equals(x.getString("wdTag"))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrconfigRightCal的数据量为：" + buzErrconfigRightCal.count())


    val depponWrongCal = buzErrconfigRightCal.map(x => {
      val reqBody = x.getJSONObject("reqBody")
      if (null != reqBody) {
        var dataSrc = reqBody.getString("dataSrc")
        if (StringUtils.isNotEmpty(dataSrc)) {
          dataSrc = dataSrc.replace("|", "_")
          if ("DEPPON_TEXT".equals(dataSrc) || "DEPPON_KEYWORD".equals(dataSrc))
            x.put("wdTag", "depponWrong")
        }
      }
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    depponWrongCal.take(2).foreach(println(_))
    logger.error("depponWrongCal的数据量为：" + depponWrongCal.count())

    val depPonWrongRdd = depponWrongCal.filter(x => ("depponWrong".equals(x.getString("wdTag")))).map(x => {
      x.put("dataType", "7")
      x.put("statTag", "depponWrong")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("===>>>其中包含德邦人工处理错误的数据量为: " + depPonWrongRdd.count())


    val standardWdRdd = ((notBuzErrWdRdd.map(x => (x.getString("sn"), x))).leftOuterJoin(((buzErrAoiRightRdd.union(buzErrRdd)).map(x => (x.getString("sn"), x)).union(otherCityRdd)).union(buzErrXyZc_All).reduceByKey((x, y) => x))).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      var isWdFlag = true
      if (rightOption.nonEmpty) {
        isWdFlag = false
      }
      (isWdFlag, left)
    }).filter(x => x._1).map(x => x._2).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val wdRddPre = standardWdRdd.map(x => (x.getString("sn"), x)).leftOuterJoin(((depPonWrongRdd.union(buzErrsimilarityRight)).map(x => (x.getString("sn"), x))).reduceByKey((x, y) => x)).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      var isWdFlag = true
      if (rightOption.nonEmpty) {
        isWdFlag = false
      }
      (isWdFlag, left)
    }).filter(x => x._1).map(x => x._2).map(x => {
      x.put("statTag", "wd")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("===>>>其中初步错分数据量为: " + wdRddPre.count())

    val changeZcRddPre = wdRddPre.map(x => {
      val reqBody = x.getJSONObject("reqBody")
      val aoiId = JSONUtil.getJsonVal(reqBody, "aoiid", "")
      val newZc = scheduleDeBangAoiInterface(aoiDeBangBroadcast, aoiId)
      val depponZc = x.getString("depponZc")
      if (StringUtils.isNotEmpty(newZc) && StringUtils.isNotEmpty(depponZc) && newZc.contains(depponZc)) {
        x.put("isNewZc", "1")
      }
      x.put("newZc", newZc)
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val changeZcRdd = changeZcRddPre.filter(x => {
      "1".equals(x.getString("isNewZc"))
    }).map(x => {
      x.put("dataType", "3")
      x.put("statTag", "changeZc")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("changeZcRdd的数据量为：" + changeZcRdd.count())
    changeZcRdd.take(2).foreach(println(_))


    val addrConfSql =
      s"""
         |select
         |  citycode,address,aoiid,zc
         |from
         |  dm_gis.deppon_address_remove_conf_new where inc_day='online'
       """.stripMargin

    val addrRemoveConfTable1 = spark.sql(addrConfSql).rdd.map(x => {
      val citycode = x.getString(0)
      val address = x.getString(1)
      val aoiid = x.getString(2)
      val zc = x.getString(3)
      val jo = new JSONObject()
      jo.put("ciytcode", citycode)
      jo.put("address", address)
      jo.put("aoiid", aoiid)
      jo.put("zc", zc)
      ((citycode, address), jo)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addrRemoveConfTable1的数据量为：" + addrRemoveConfTable1.count())


    //    val addrRemoveConfTable2 = spark.sql(addrConfSql).rdd.map(x => {
    //      val cityCode = x.getString(0)
    //      val address = x.getString(1)
    //      val aoiid = x.getString(2)
    //      val zc = x.getString(3)
    //      val jo = new JSONObject()
    //      jo.put("ciytcode",cityCode)
    //      jo.put("address",address)
    //      jo.put("aoiid",aoiid)
    //      jo.put("zc",zc)
    //      ((cityCode,address,zc),jo)
    //    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //    logger.error("addrRemoveConfTable2的数据量为：" + addrRemoveConfTable2.count())

    val removeConfRDD = changeZcRddPre.filter(x => {
      StringUtils.isEmpty(x.getString("isNewZc")) || !"1".equals(x.getString("isNewZc"))
    }).map(x => {
      val reqBody = x.getJSONObject("reqBody")
      val aoiId = JSONUtil.getJsonVal(reqBody, "aoiid", "")
      val address = reqBody.getString("address").replaceAll("(\\r|\\n|\\s+)", "")
      val zc = reqBody.getString("zc")
      val cityCode = x.getString("cityCode")
      ((cityCode, address), x)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("removeConfRDD的数据量为：" + removeConfRDD.count())


    val removeConfEmptyIdRDD = removeConfRDD.leftOuterJoin(addrRemoveConfTable1).map(x => {
      val leftBody = x._2._1
      val rightOption = x._2._2
      if (rightOption.nonEmpty) {
        leftBody.put("wdTag", "buzErrconfigRight")
      }
      ((x._1._1, x._1._2), leftBody)
    })
    logger.error("removeConfEmptyIdRDD的数据量为：" + removeConfEmptyIdRDD.count())



    val addrRemoveConfTable = removeConfEmptyIdRDD.filter(x => {
      StringUtils.isNotEmpty(x._2.getString("wdTag")) && "buzErrconfigRight".equals(x._2.getString("wdTag"))
    }).map(x => {
      x._2.put("dataType", "4")
      x._2.put("statTag", "buzErrconfigRight")
      ((x._1._1, x._1._2), x._2)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)

    logger.error("剔除配置表的数据量为：" + addrRemoveConfTable.count())
    addrRemoveConfTable.take(2).foreach(println(_))

    val buzErrDeleteZcRdd1 = removeConfRDD.leftOuterJoin(addrRemoveConfTable.reduceByKey((x, y) => x))
      .map(x => {
        val left = x._2._1
        val rightOption = x._2._2
        var isWdFlag = true
        if (rightOption.nonEmpty) {
          isWdFlag = false
        }
        (isWdFlag, left)
      }).filter(x => x._1).map(x => x._2).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrDeleteZcRdd1的数据量为：" + buzErrDeleteZcRdd1.count())


    val buzErrDeleteZcRightRdd = buzErrDeleteZcRdd1.mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)
      for (x <- iter) yield {
        //限制ak使用
        AkUtil.limitAkUse(startTime, cnt, index, 5, logger)
        val depponZc = x.getString("depponZc")
        val isZcExist = scheduleJudgeZcExistInterface(judgeZcExistBroadcast, depponZc)
        if (StringUtils.isNotEmpty(isZcExist) && "1".equals(isZcExist)) {
          x.put("isZcExist", "1")
        } else {
          x.put("isZcExist", "0")
        }
        x
      }
    }).filter(x => {
      StringUtils.isEmpty(x.getString("isZcExist")) || "0".equals(x.getString("isZcExist"))
    }).map(x => {
      x.put("dataType", "3")
      x.put("statTag", "buzErrDeleteZcRight")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("buzErrDeleteZcRightRdd的数据量为：" + buzErrDeleteZcRightRdd.count())

    val wdRdd = standardWdRdd.map(x => {
      val reqBody = x.getJSONObject("reqBody")
      val address = reqBody.getString("address").replaceAll("(\\r|\\n|\\s+)", "")
      val cityCode = x.getString("cityCode")
      ((cityCode, address), x)
    }).leftOuterJoin(addrRemoveConfTable.reduceByKey((x, y) => x))
      .map(x => {
        val left = x._2._1
        val rightOption = x._2._2
        var isWdFlag = true
        if (rightOption.nonEmpty) {
          isWdFlag = false
        }
        (isWdFlag, left)
      }).filter(x => x._1).map(x => x._2)
      .map(x => (x.getString("sn"), x)).leftOuterJoin(((depPonWrongRdd.union(buzErrsimilarityRight).union(changeZcRdd).union(buzErrDeleteZcRightRdd)).map(x => (x.getString("sn"), x))).reduceByKey((x, y) => x)).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      var isWdFlag = true
      if (rightOption.nonEmpty) {
        isWdFlag = false
      }
      (isWdFlag, left)
    }).filter(x => x._1).map(x => x._2).map(x => {
      x.put("statTag", "wd")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("===>>>其中错分数据量为: " + wdRdd.count())


    // 错分量数据 + 准确量数据
    val wdAndRightRdd = wdRdd.union(rightRdd.map(_._2)).map(x => {
      x.put("statTag", "wdAndRight")
      x
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("===>>>(wdAndRightRdd)错分数据与准确数据的总量为: " + wdAndRightRdd.count())


    // 识别量数据 目前版本是validSignRdd-multiZcRdd -InExplicit - ZC_noMap - emptyAoiRightRdd  TODO validSignRdd-multiZcRdd -InExplicit - ZC_noMap - emptyAoiRightRdd - AOIWithoutZC
    val right = multiZcRdd.union(inExplicitRdd.map(x => (x.getString("sn"), x))).union(zcNoMapRdd.map(x => (x.getString("sn"), x))).union(emptyAoiRightRdd.map(x => (x.getString("sn"), x))).persist(StorageLevel.MEMORY_AND_DISK_SER)
    val distinguishRdd = validSignRdd.leftOuterJoin(right).map(x => {
      val left = x._2._1
      val rightOption = x._2._2
      var isWdFlag = true
      if (rightOption.nonEmpty) {
        isWdFlag = false
      }
      (isWdFlag, left)
    }).filter(x => x._1).map(x => {
      x._2.put("statTag", "distinguish")
      x._2
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("===>>>(distinguishRdd)识别数据的的总量为: " + distinguishRdd.count())

    // TODO 归类需要计算的数据集并标注相应的统计标签statTag
    val u_1 = validSignRdd.map(_._2.toJSONString) // 有效签收量数据
    val u_2 = validPiPeiRdd.map(_._2.toJSONString) // 识别数据
    val u_3 = rightRdd.map(_._2.toJSONString) // 准确量数据
    val u_4 = wdRdd.map(_.toJSONString) // 错分量数据
    val u_5 = wdAndRightRdd.map(_.toJSONString) // 错分量数据 + 准确量数据
    val u_6 = distinguishRdd.map(_.toJSONString)
    val u_7 = deBangSignRdd.map(_._2.toJSONString) // 总签收量数据
    val u_8 = multiReqDiffAddressPushRdd.map(_._2.toJSONString) // 多次请求地址不一致量数据
    val u_9 = singleReqDiffAddressPushRdd.map(_._2.toJSONString) // 单次请求地址不一致量
    val u_10 = nonReqSignRdd.map(_.toJSONString) // 未关联到请求量
    val u_11 = multiZcRdd.map(_._2.toJSONString) // 匹配多ZC量  multiZcRdd
    val u_12 = otherCityRdd.map(_._2.toJSONString) // 非本市量 otherCityRdd
    val u_13 = buzErrRdd.map(_.toJSONString) // 业务帮派量 buzErrRdd
    val u_14 = buzErrAoiRightRdd.map(_.toJSONString) // 区域基础数据错误量 buzErrAoiRightRdd
    val u_15 = depPonWrongRdd.map(_.toJSONString) // 人工处理错误量 depPonWrongRdd
    val u_16 = inExplicitRdd.map(_.toJSONString) // 地址不详量 inExplicitRdd
    val u_17 = zcNoMapRdd.map(_.toJSONString) // 无ZC多边形量 zcNoMapRdd
    val u_18 = emptyAoiRightRdd.map(_.toJSONString) // AOI与ZC不相交量 emptyAoiRightRdd
    val u_19 = buzErrXyZCRight.map(_.toJSONString) //剔除坐标zc
    val u_20 = buzErrZCModelRight.map(_.toJSONString) //剔除zc模型

    val u_21 = buzErrsimilarityRight.map(_.toJSONString) //剔除相似度模型
    val u_22 = addrRemoveConfTable.map(tp => tp._2).map(_.toJSONString) //剔除配置表模型

    val u_23 = changeZcRdd.map(_.toJSONString) //剔除ZC变更错误

    val u_24 = buzErrDeleteZcRightRdd.map(_.toJSONString) //剔除明细：ZC删除
    val resultStatRdd = (u_1.union(u_2).union(u_3).union(u_4).union(u_5).union(u_6).union(u_7).union(u_8)
      .union(u_9).union(u_10).union(u_11).union(u_12).union(u_13).union(u_14).union(u_15).union(u_16).union(u_17).union(u_18).union(u_19).union(u_20).union(u_21).union(u_22).union(u_23).union(u_24)).map(x => {
      val json = JSON.parseObject(x)
      json
    }).coalesce(parallelism).persist(StorageLevel.DISK_ONLY)
    logger.error("获取最终归类需要计算的partitions为: " + resultStatRdd.partitions.length)
    logger.error("获取最终归类需要计算的数据量为: " + resultStatRdd.count())
    resultStatRdd.take(2).foreach(println(_))

    // TODO  在获取需要存BDP的明细数据
    // 输出明细数据到BDP-Hive表:
    val h_1 = rdd.map(x => ("ALL", "签收记录关联到的源请求数据", x._2.toJSONString))
    val h_2 = multiReqDiffAddressPushRdd.map(x => ("multiReqDiffAddress", "多次请求地址与签收地址不一致数据", x._2.toJSONString))
    val h_3 = validMultiReqSameAddressRdd.map(x => ("validMultiReqSameAddress", "多次请求地址与签收地址一致的数据", x._2.toJSONString))
    val h_4 = singleReqDiffAddressPushRdd.map(x => ("singleReqDiffAddress", "单次请求与签收地址不一致的数据", x._2.toJSONString))
    val h_5 = validSingleReqSameAddressRdd.map(x => ("validSingleReqSameAddress", "单次请求与签收地址一致的数据", x._2.toJSONString))
    val h_6 = validSignRdd.map(x => ("validSign", "有效的签收量", x._2.toJSONString)) // validSignRdd = validMultiReqSameAddressRdd+validSingleReqSameAddressRdd
    val h_7 = emptyZcRdd.map(x => ("emptyZc", "ZC为空", x._2.toJSONString))
    val h_8 = multiZcRdd.map(x => ("multiZc", "多ZC", x._2.toJSONString))
    val h_9 = validPiPeiRdd.map(x => ("validPiPei", "单ZC", x._2.toJSONString)) // validPiPeiRdd =  rightRdd + notRightRdd
    val h_10 = distinguishRdd.map(x => ("distinguish", "识别量", x.toJSONString))
    val h_11 = rightRdd.map(x => ("right", "right", x._2.toJSONString))
    val h_12 = notRightRdd.map(x => ("notRight", "非right", x._2.toJSONString)) // notRightRdd = otherCityRdd +  notOtherCityRdd
    val h_13 = otherCityRdd.map(x => ("otherCity", "非本市", x._2.toJSONString))
    val h_14 = notOtherCityRdd.map(x => ("notOtherCity", "本市", x._2.toJSONString)) // notOtherCityRdd = notEmptyKeyWordRdd + emptyKeyWordRdd
    val h_15 = buzRdd.map(x => ("buz", "查找词", x.toJSONString)) // buzRdd = buzErrRdd + notBuzErrRdd
    val h_16 = buzErrRdd.map(x => ("buzErr", "业务问题", x.toJSONString))
    val h_17 = notBuzErrRdd.map(x => ("notBuzErr", "非业务", x.toJSONString))
    val h_18 = notBuzErrWdRdd.map(x => ("notBuzErrWd", "非业务问题中筛选wdTag=isWd", x.toJSONString))
    val h_19 = mapARdd.map(x => ("mapA", "MapA", x.toJSONString))
    val h_20 = tsRdd.map(x => ("tsRdd", "图商", x.toJSONString))
    val h_21 = srcRdd.map(x => ("src", "src=norm", x.toJSONString))
    val h_22 = polygonIntersectRdd.map(x => ("polygonIntersect", "多边形相交", x.toJSONString)) // polygonIntersectRdd = buzErrAoiRightRdd + notBuzErrAoiRightRdd
    val h_23 = buzErrAoiRightRdd.map(x => ("buzErrAoiRightRdd", "buzErrAoiRight的数据", x.toJSONString))
    val h_24 = notBuzErrAoiRightRdd.map(x => ("notBuzErrAoiRightRdd", "非buzErrAoiRight", x.toJSONString))
    val h_25 = wdRdd.map(x => ("wd", "错分", x.toJSONString))
    val h_26 = depPonWrongRdd.map(x => ("depponWrong", "人工处理错误", x.toJSONString))
    val h_27 = inExplicitRdd.map(x => ("inExplicit", "地址不详细", x.toJSONString))
    val h_28 = zcNoMapRdd.map(x => ("zcNoMap", "无ZC多边形量", x.toJSONString))
    val h_29 = emptyAoiRightRdd.map(x => ("emptyAoiRight", "AOI与ZC不相交", x.toJSONString))
    val h_30 = iadRdd.map(x => ("iad", "ZC为空调用地址精细化服务", x.toJSONString))

    val h_31 = buzErrXyZCRight.map(x => ("buzErrXyZCRight", "地址ZC(x,y)模型剔除率", x.toJSONString))
    val h_32 = buzErrZCModelRight.map(x => ("buzErrZCModelRight", "Zc模型剔除率", x.toJSONString))

    val h_33 = addressEndWithopposite.map(x => ("addressEndWithopposite", "地址以对面结尾", x.toJSONString))
    val h_34 = wrong_pipei.map(x => ("wrong_pipei", "错误方位词", x.toJSONString))

    val h_35 = buzErrZCModelRightCalculate.map(x => ("zcmodel_buzErrZCModelRight", "坐标或者aoi有缺失的数据zc模型", x.toJSONString))

    val h_36 = buzErrsimilarityRight.map(x => ("buzErrsimilarityRight", "剔除相似度模型", x.toJSONString))
    val h_37 = addrRemoveConfTable.map(tp => tp._2).map(x => ("buzErrconfigRight", "剔除配置表", x.toJSONString))

    val h_38 = changeZcRdd.map(x => ("changeZc", "剔除ZC变更错误", x.toJSONString))
    val h_39 = buzErrDeleteZcRightRdd.map(x => ("buzErrDeleteZcRight", "剔除zc删除", x.toJSONString))
    // 需要写入到BDP-Hive表中的明细数据
    val resultDetailRdd = h_1.union(h_2).union(h_3).union(h_4).union(h_5).union(h_6).union(h_7).union(h_8).union(h_9).union(h_10)
      .union(h_11).union(h_12).union(h_13).union(h_14).union(h_15).union(h_16).union(h_17).union(h_18).union(h_19)
      .union(h_20).union(h_21).union(h_22).union(h_23).union(h_24).union(h_25).union(h_26).union(h_27).union(h_28).union(h_29).union(h_30).union(h_31).union(h_32)
      .union(h_33).union(h_34).union(h_35).union(h_36).union(h_37).union(h_38).union(h_39)
      .map(x => (x._1, x._2, x._3)).coalesce(parallelism).persist(StorageLevel.DISK_ONLY)
    logger.error("获取写入到BDP-Hive表中的各个流程的德邦明细数据量为: " + resultDetailRdd.count())

    (resultStatRdd, resultDetailRdd)
  }

  /** @note Main Rich Services */
  def analysisRichService(spark: SparkSession, incDay: String): Unit = {
    logger.error("开始解析德邦签收关联请求数据中各流程获取最终需要参与统计的部分数据")
    val (resultStatRdd, resultDetailRdd) = getResultRdd(spark, incDay)

    logger.error("开始获取德邦签收数据报表指标数据RDD.........")
    val reportRdd = getDeBangSignReportRdd(spark, resultStatRdd, incDay)

    // 打印统计部分结果输出数据
    val checkReportRdd = reportRdd.map(x => {
      val obj = x
      implicit val formats = org.json4s.DefaultFormats
      val jsonStr = org.json4s.jackson.Serialization.write(obj)
      JSON.parseObject(jsonStr)
    })
    checkReportRdd.filter(x => ("ALL".equals(x.getString("depPonCode")))).collect().foreach(println(_))
    val reportToHiveRdd = checkReportRdd.map(x => ("report", "指标", x.toJSONString))

    logger.error("开始获取德邦签收数据报表指标入DB库.........")
//    new AoiDeBangDML().saveDB(spark, reportRdd, incDay)
    logger.error("德邦签收数据指标报表数据入库完毕..............................")

    logger.error("开始获取德邦指标计算各流程明细数据写入BDP-Hive.........")
    logger.error("先获取德邦签收表数据中type=2的明细数据.........")
    val deBangSignReturnRdd = getDeBangSignReturnRdd(spark, incDay).map(x => {
      ("returnSign", "退回", x._2.toJSONString)
    })
    val rdd = resultDetailRdd.union(deBangSignReturnRdd).union(reportToHiveRdd)
    logger.error("写入指定Hive表的数据量为: " + rdd.count())
    new AoiDeBangHive().saveFs(spark, incDay, rdd)
    logger.error("德邦指标计算各流程明细数据写入Hive完毕..............................")

  }

//  /** @note Main Rich Services */
//  def analysisRichService1(spark: SparkSession, incDay: String): Unit = {
//    val sqlText =
//      s"""
//         |SELECT
//         |  data_info
//         |FROM dm_gis.t_deppon_sign_index_info_d
//         |WHERE inc_day = '20200924'
//         |AND data_type = 'report'
//                         """.stripMargin
//    val df: DataFrame = spark.sql(sqlText)
//    val reportRdd = df.rdd.map(row => {
//      row.getString(0)
//    }).map(x => {
//      JSON.parseObject(x, classOf[DepPonReportDO])
//    })
//    logger.error("开始获取德邦签收数据报表指标入DB库........." + reportRdd.count())
//    new AoiDeBangDML().saveDB(spark, reportRdd, incDay)
//    logger.error("德邦签收数据指标报表数据入库完毕..............................")
//  }

  class AoiDeBangHive {
    //生产表


    def saveFs(spark: SparkSession, incDay: String, rdd: RDD[(String, String, String)]): Unit = {

      logger.error("开始写入数据")
      import spark.implicits._
      rdd.repartition(1).toDF("data_type", "data_note", "data_info").withColumn("inc_day", lit(incDay))
        .repartition(1).write.mode(SaveMode.Overwrite).insertInto(sourceTableName)

      logger.error("写入数据到 OK......")

    }
  }

  class AoiDeBangDML extends Serializable {
    /*DataSource信息*/
    private val APPLICATION_DB: String = "application-db.properties"
    private val DRIVER: String = "gis.oms.lip.com.sf.gis.rds.datasource.driver-class-name"
    private val URL: String = "gis.oms.lip.com.sf.gis.rds.datasource.url"
    private val USERNAME: String = "gis.oms.lip.com.sf.gis.rds.datasource.data-username"
    private val PASSWORD: String = "gis.oms.lip.com.sf.gis.rds.datasource.data-password"

    /** @note 从库表中获取DEPPON_CODE数据
     * @return map
     * */
    def getDepPonCodeMap(): (Map[String, String], Map[String, String]) = {
      val conn: Connection = JdbcTemplateUtil.getDataSourceConnection(APPLICATION_DB, DRIVER, URL, USERNAME, PASSWORD)
      val sourceTable = "DEPPON_CODE"
      val columns = Array("depponcode", "citycode", "cityname")
      val sqlText = s"""select depponcode,citycode,cityname from $sourceTable """.stripMargin
      logger.error(">>>>>>从指定的关系库表中获取DepPonCode数据: " + sqlText)
      val depPonCodeMap: ArrayBuffer[Array[String]] = JdbcTemplateUtil.selectColumns(conn, sqlText, columns)
      logger.error(">>>>>>获取depPonCodeMap数据量:" + depPonCodeMap.size)
      var depPonCodeCityCodeMap: Map[String, String] = Map()
      var depPonCodeCityNameMap: Map[String, String] = Map()
      for (arr <- depPonCodeMap) {
        val depPonCode = arr(0).toString
        val cityCode = arr(1).toString
        val depPonCityName = arr(2).toString
        depPonCodeCityCodeMap += (depPonCode -> cityCode)
        depPonCodeCityNameMap += (depPonCode -> depPonCityName)
      }
      logger.error("读取外部德邦城市编码配置表获取depPonCodeCityCodeMap即DepPonCode->CityCode的数量为: " + depPonCodeCityCodeMap.size)
      logger.error("读取外部德邦城市编码配置表获取depPonCodeCityNameMap即DepPonCode->CityName的数量为: " + depPonCodeCityNameMap.size)
      if (!Objects.isNull(conn)) {
        conn.close()
        logger.error(">>>>>>Close Get DEP_PON CODE Operation Of DataSource Connection......" + conn.isClosed)
      }
      (depPonCodeCityCodeMap, depPonCodeCityNameMap)
    }

    // 指定DML操作的具体表名
    //生产表
    private val DB_TABLE_NAME = "DEBANG_SIGN_REPORT"

    //测试表
//    private val DB_TABLE_NAME = "DEBANG_SIGN_REPORT_TEST"

    /** @note 删除目标表中当前日期下已经存在的数据 */
    def deleteCurrentDateExistData(tableName: String, date: String): Unit = {
      val conn: Connection = JdbcTemplateUtil.getDataSourceConnection(APPLICATION_DB, DRIVER, URL, USERNAME, PASSWORD)
      val sqlText = s"delete from $tableName where STAT_DATE = '$date'"
      logger.error(">>>>>>保存之前先删除当天的数据,Delete Sql Text: " + sqlText)
      JdbcTemplateUtil.executeSql(conn, sqlText, null)
      if (!Objects.isNull(conn)) {
        conn.close()
        logger.error(">>>>>>Close Delete Operation Of DataSource Connection......" + conn.isClosed)
      }
    }

    /** @note 将AOI运单派件数据挂接量数据推送到GisOms运营平台表中 */
    def saveDB(spark: SparkSession, rdd: RDD[DepPonReportDO], date: String): Unit = {
      try {
        // 保存数据之前先删除当天的数据
        deleteCurrentDateExistData(DB_TABLE_NAME, date)
        val fields = Array("ID", "DATA_TYPE", "STAT_DATE", "EVENT_TIMESTAMP", "REGION", "DEPPON_CODE", "DEPPON_NAME","BIG_TYPE",
          "DATA_SRC", "TOTAL_SIGN_CNT", "VALID_SIGN_CNT", "PIPEI_CNT", "RIGHT_CNT", "WD_CNT", "WD_AND_RIGHT_CNT", "DISTINGUISH_CNT",
          "MULTI_REQ_DIFF_ADDRESS_CNT", "SINGLE_REQ_DIFF_ADDRESS_CNT", "NON_REQ_SIGN_CNT", "IN_EXPLICIT_ADDRESS_CNT", "MULTI_ZC_CNT",
          "NON_MAP_ZC_CNT", "AOI_WITHOUT_ZC_CNT", "AOI_NOT_INTERSECT_ZC_CNT", "OTHER_CITY_CNT", "BUZ_ERR_CNT", "BUZ_ERR_AOI_RIGHT_CNT",
          "DEPPON_WRONG_CNT", "BUZ_ERR_XY_ZC_RIGHT_CNT", "BUZ_ERR_ZCMODEL_RIIGHT_CNT", "BUZ_ERR_SIMILARITY_RIGHT_CNT", "BUZ_ERR_CONFIG_RIGHT_CNT",
          "CHANGE_ZC_CNT", "BUZ_ERR_DELETE_ZC_CNT"
        )
        val fieldsMkString = fields.mkString(",")
        val sqlText = s"""insert into $DB_TABLE_NAME ($fieldsMkString) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) """.stripMargin
        logger.error(">>>>>>Insert Into Sql Text: " + sqlText)

        val conn: Connection = JdbcTemplateUtil.getDataSourceConnection(APPLICATION_DB, DRIVER, URL, USERNAME, PASSWORD)
        var count = 0
        var failedCount = 0
        rdd.collect().foreach(obj => {
          count = count + 1
          val detailArray: Array[Any] = Array(
            obj.id, obj.dataType, obj.statDate, obj.eventTimestamp, obj.region, obj.depPonCode, obj.depPonName,obj.bigType, obj.dataSrc,
            obj.totalSignCnt, obj.validSignCnt, obj.piPeiCnt, obj.rightCnt, obj.wdCnt, obj.wdAndRightCnt, obj.distinguishCnt,
            obj.multiReqDiffAddressCnt, obj.singleReqDiffAddressCnt, obj.nonReqSignCnt, obj.inExplicitAddressCnt,
            obj.multiZcCnt, obj.noMapZcCnt, obj.aoiWithoutZcCnt, obj.aoiNotIntersectZcCnt, obj.otherCityCnt, obj.buzErrCnt, obj.buzErrAoiRightCnt, obj.depPonWrongCnt, obj.buzErrXyZCRightCnt, obj.buzErrZCModelRightCnt, obj.buzErrsimilarityRightCnt, obj.buzErrconfigRightCnt, obj.changeZcCnt, obj.buzErrDeleteZcRightCnt
          )
          val value = JdbcTemplateUtil.executeSqlAnyParams(conn, sqlText, detailArray)
          if (value < 0) {
            failedCount = failedCount + 1
          }
        })
        logger.error(">>>>>>累计推送Deppon签收指标数据到DB库的总数据量 " + count)
        logger.error(">>>>>>其中包括推送失败的数据量为: " + failedCount)
        logger.error(">>>>>>Deppon签收指标数据推送到DB库结束......")
        if (!Objects.isNull(conn)) {
          conn.close()
          logger.error(">>>>>>Close RDD Collect ForeachPartition Operation Of DataSource Connection......" + conn.isClosed)
        }
      } catch {
        case e: Exception => logger.error(">>>>>>德邦签收数据指标报表数据推送到GisOms运营平台表中出现异常Exception: " + e)
      }
    }
  }

  /**
   * @note 初始化spark并执行任务
   * @param incDay String
   **/
  def execute(incDay: String): Unit = {
    val spark = Spark.getSparkSession(appName)
    val numCores = spark.sparkContext.getConf.get("spark.executor.cores").toInt
    val numExecutors = spark.sparkContext.getConf.get("spark.executor.instances").toInt
    parallelism = numCores * numExecutors
    logger.error(">>>>>>Custom Parallelism == " + parallelism)
    analysisRichService(spark, incDay)
    logger.error(">>>>>>Analysis OK")
    Thread.sleep(1 * 1000 * 10 * 1)
    spark.stop()
  }
  def customSourceFromUrlToStr(url:String,encoding:String) ={
    val response = customSourceFromUrl(url,encoding)
    if(response==null){
      ""
    }else{
      response.mkString
    }
  }
  def customSourceFromUrlToLines(url:String,encoding:String) ={
    val response = customSourceFromUrl(url,encoding)
    if(response==null){
      var emptyArray=Array[String]()
      emptyArray.iterator
    }else{
      response.getLines()
    }
  }
  def customSourceFromUrl(url:String,encoding:String):BufferedSource ={
    try {
      val response = Source.fromURL(url, encoding)
      return response
    }catch {
      case exception: Exception=>{
        logger.error(exception)
      }
    }
    return null
  }

  def main(args: Array[String]): Unit = {


    val incDay = args(0)
    logger.error(">>>>>>Start Execute Date " + incDay)
    execute(incDay)
    logger.error(">>>>>>OK End Execute Date " + incDay)
  }
}
