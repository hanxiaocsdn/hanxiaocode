package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.JSON
import com.sf.gis.java.sx.constant.util.Utils
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.debang.util.{DateTimeUtil, SparkUtils}
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.JavaConversions._
/*
*快运标准库 - 01412406
*/
object kuaiYunNorm {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)
  //关闭fastjson引用检测
  JSON.DEFAULT_GENERATE_FEATURE |= SerializerFeature.DisableCircularReferenceDetect.getMask
  val calPartition = 2000
  val limitMin = 80
  val splitUrl = "http://gis-int.int.sfdc.com.cn:1080/atdispatchlite/api?address=%s&province=&cityName=&district=&city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=norm"


  def main(args: Array[String]) = {
    val spark = SparkSession.builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()
      .config("hive.exec.dynamic.partition", true)
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val incDay = args(0)
    val beforeDay =DateTimeUtil.getDaysApartDate("yyyyMMdd",incDay,-30)
    logger.error(incDay+"-"+beforeDay)
    run(spark, incDay,beforeDay)
  }



  def run(spark: SparkSession, incDay: String,beforeDay:String) = {

    val deletSql =
      """
        |select
        |get_json_object(detail,'$.cityName') cityName,
        |get_json_object(detail,'$.cityCode') cityCode_shibie,
        |get_json_object(detail,'$.reqBody.reqWaybillNo') reqWaybillNo,
        |get_json_object(detail,'$.reqBody.aoiId') aoiId,
        |get_json_object(detail,'$.reqBody.reqAddress') reqAddress,
        |get_json_object(detail,'$.reqBody.reTeamCode') reTeamCode_shibie,
        |get_json_object(detail,'$.tc') tc,
        |inc_day as day
        |from tmp_dm_gis.tmp_kuaiyun_wyabill_detail_di
        |where inc_day < '%s' and inc_day >= '%s' and get_json_object(detail,'$.reqBody.reTeamCode') <> ''
        |limit 10000
      """.stripMargin

    val formatSql = String.format(deletSql, incDay, beforeDay)
    logger.error(formatSql)
    //取近一个月的数据
    val sourRdd = SparkUtils.getRowToJson(spark, formatSql, calPartition)

    logger.error("一个月的数据量:" + sourRdd.count())
    sourRdd.unpersist()


    //跑at派服获取字段 key_word


    //错分获取主体
    val aoiRdd= sourRdd.mapPartitionsWithIndex((index, iter) => {
      val startTime = new StratTime(System.currentTimeMillis())
      val cnt = new Cnt(0)

      for (obj <- iter) yield {
        val reqAddress = obj.getString("reqAddress")
        val cityCode = obj.getString("cityCode_shibie")


        if (StringUtils.isNotEmpty(reqAddress)) {
          //限制ak使用
          SparkUtils.limitAkUse(startTime, cnt, index, limitMin, logger)

          //调用分词微服务
          //调用分词获取分词结果
          val splitReq = String.format(splitUrl, URLEncoder.encode(reqAddress), cityCode)
          val startSplitTime = System.currentTimeMillis()
          val splitResp = Utils.retryGet(splitReq)
          val endSplitTime = System.currentTimeMillis()

          obj.put("splitReq", splitReq)
          obj.put("splitResp", splitResp)

          logger.error(s"cost:${endSplitTime - startSplitTime} -> $splitReq")

          val splitArr = try{
           JSON.parseObject(splitResp).getJSONObject("result").getJSONArray("tcs")
          } catch { case _=>null }


          if(splitArr != null && splitArr.length>0){
            val keyWorld = try{
            JSONUtil.getJsonVal(splitArr.getJSONObject(0),"keyWord","")
            }catch{
              case _ => null
            }

            val reAoiid = try{
              JSONUtil.getJsonVal(splitArr.getJSONObject(0),"aoiid","")
            }catch{
              case _ => null
            }

            obj.put("keyWorld", keyWorld)
            obj.put("reAoiid", reAoiid)
          }

          obj.put("tag", "noTcs")

        }


        obj
      }

    }).persist(StorageLevel.DISK_ONLY)








//明细表
    import spark.implicits._
    val reDf = aoiRdd.map(obj => {

        (
          JSONUtil.getJsonVal(obj, "cityName", "")
          , JSONUtil.getJsonVal(obj, "reqAddress", "")
          , JSONUtil.getJsonVal(obj, "cityCode_shibie", "")
          , JSONUtil.getJsonVal(obj, "reqWaybillNo", "")
          , JSONUtil.getJsonVal(obj, "reAoiid", "")
          , JSONUtil.getJsonVal(obj, "reqAddress", "")
          , JSONUtil.getJsonVal(obj, "reTeamCode_shibie", "")
          , JSONUtil.getJsonVal(obj, "tc", "")
          , JSONUtil.getJsonVal(obj, "keyWorld", "")
          , JSONUtil.getJsonVal(obj, "keyWorld", "")+"_"+JSONUtil.getJsonVal(obj, "reTeamCode_shibie", "")
          , JSONUtil.getJsonVal(obj, "keyWorld", "").length
          , JSONUtil.getJsonVal(obj, "day", "")
          ,obj.toJSONString
        )
      }).toDF(
      "cityName"
      , "consigneeAddr"
      , "cityCode_shibie"
      , "reqWaybillNo"
      , "aoiId"
      , "reqAddress"
      , "reTeamCode_shibie"
      , "tc"
      , "key_word"
      , "key_word_reTeamCode_shibie"
      , "key_word_length"
      , "day"
      , "req"
    )
    reDf.createOrReplaceTempView("tmp")

    reDf.take(10).foreach(x=>{logger.error(x)})


//计算【key_word】以及对应【reTeamCode_shibie】去重后的组合频次【tc_count】
    val count_key_word =
      """
        |select key_word_reTeamCode_shibie,count(*) as rn
        |from (
        |select key_word_reTeamCode_shibie
        |from tmp
        |group by key_word_reTeamCode_shibie
        |)a
        |group by key_word_reTeamCode_shibie

      """.stripMargin

    logger.error(count_key_word)

   val countR =  spark.sql(count_key_word).createOrReplaceTempView("count_key_word")




    val resql =
      """
        |select
        | cityName
        |,consigneeAddr
        |,cityCode_shibie as city_code
        |,reqWaybillNo
        |,aoiId
        |,reqAddress
        |,reTeamCode_shibie as tc
        |,tc as tc2
        |,key_word
        |,key_word_reTeamCode_shibie
        |,key_word_length
        |,day
        |,tc_count1
        |,req
        |,aoi_name
        |,if(tag = 'ture' and a.tc_count1 = 1 ,'ture','tiChu') tag
        | from (
        |select
        | a.cityName
        |,a.consigneeAddr
        |,a.cityCode_shibie
        |,a.reqWaybillNo
        |,a.aoiId
        |,a.reqAddress
        |,a.reTeamCode_shibie
        |,a.tc
        |,a.key_word
        |,a.key_word_reTeamCode_shibie
        |,a.key_word_length
        |,a.day
        |,c.rn as tc_count1
        |,a.req
        |,d.aoi_name
        |,if(key_word_length>2 and b.key_word is null,'ture','tiChu') as tag
        |from tmp a
        |left join dm_gis.kuaiyun_general_keyword_di b
        |on a.key_word = b.key_word
        |left join count_key_word c
        |on a.key_word_reTeamCode_shibie = c.key_word_reTeamCode_shibie
        |left join dm_gis.cms_aoi_sch d
        |on a.aoiId = d.aoi_id
        |)a
      """.stripMargin





//    cityName
//    ,consigneeAddr
//    ,cityCode_shibie
//    ,reqWaybillNo
//    ,aoiId
//    ,reqAddress
//    ,reTeamCode_shibie
//    ,tc
//    ,key_word
//    ,key_word_reTeamCode_shibie
//    ,key_word_length
//    ,day
//    ,tc_count1
//    ,req
//    ,aoi_name
//    , tag

    logger.error(resql)
    logger.error("开始入库")
    val resultDf = spark.sql(resql).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(resultDf.show(2))
    logger.error("标准数据入库")
    logger.error("入标准库的数量："+resultDf.filter(_.getAs[String]("tag").equals("ture")).count())

    resultDf.filter(_.getAs[String]("tag").equals("ture")).select('city_code,'reqAddress,'key_word,'tc,'aoiId,'aoi_name)
      .withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.kuaiyun_wyabill_norm_di")


    logger.error("明细数据入库")
    resultDf.withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.kuaiyun_wyabill_norm_detail_di")
   logger.error("入库完毕")






    //    val room_accessibility_new: Array[Column] = {
    //      val Roomkeys = Seq("公司", "电子", "智能", "厂", "装饰", "纺织")
    //      val addr_room_regex_str = "(" + Roomkeys.mkString("$|") + "$)"
    //      val room_accessibility_supplements = F.when(F.regexp_extract(F.col("address_append"), addr_room_regex_str, 0) =!= "", 1).otherwise(0)
    //      val room_accessibility_raw = F.col("room_accessibility").cast("int")
    //      Array(F.when((room_accessibility_supplements + room_accessibility_raw) > 0, 1).otherwise(0).cast("string").alias("room_accessibility_new"))
    //    }
  }


}
