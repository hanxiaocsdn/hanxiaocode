
package com.sf.gis.scala.debang.DebangCuofen

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.HttpConnection
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.debang.util.StringToolUtil
import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel


/**
 * 德邦剔除推送
 * 徐俊/徐千皓
 * 迁移新集群
 * 任务id:151
 * 任务名称：DepPonRejectDataPush
 */
/** @note 推送剔除的明细数据给德邦* */
object DepPonRejectDataPush {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(appName)
  Logger.getLogger("org.apache").setLevel(Level.ERROR)

  case class RejectDetailDO(reason: String, waybillNo: String, signTime: String, signCityCode: String,
                            signDeptCode: String, fullSignAddress: String, matchTime: String, matchDeptCode: String)

  var SEPARATOR_LINE = "\n"

  val dlr = '$'
  var parallelism: Int = 1
  val reasonArray = Array(1, 2, 3, 4, 6, 7, 8, 9)
  val SEPARATOR_COMMA = ","

  val url = "http://gis-int2.int.sfdc.com.cn:1080/eds/push/data"
  val ak = "3a191e7427e8470c86271a069411c66b"

  def getRejectDetailRdd(spark: SparkSession, incDay: String): RDD[JSONObject] = {
    val broadcastTuple = spark.sparkContext.broadcast(Tuple1(SEPARATOR_LINE))
    val sourceTableName = "dm_gis.t_deppon_sign_index_info_d"
    val sqlText =
      s"""
         |select
         |	t1.reason,t1.waybillNo,t1.signTime,t1.signCityCode,t1.signDeptCode,t1.fullSignAddress,
         |	get_json_object(t1.reqBody, '$dlr.createTime') as matchTime,
         |	get_json_object(t1.reqBody, '$dlr.zc') as matchDeptCode
         |from $sourceTableName
         |lateral view json_tuple(data_info,'sn', 'reqTime', 'depponCode','depponZc','address','dataType','reqBody') t1 as waybillNo,signTime,signCityCode,signDeptCode,fullSignAddress,reason,reqBody
         |where inc_day = '$incDay'
         |and t1.reason is not null
         |and t1.reason in (${reasonArray.mkString(SEPARATOR_COMMA)})
                         """.stripMargin
    logger.error("获取剔除的明细数据时执行的Sql Text: " + sqlText)
    val df: DataFrame = spark.sql(sqlText)
    val rejectDetailRdd = df.rdd.map(x => {
      val reason = StringToolUtil.convertString(x.getString(0))
      val waybillNo = StringToolUtil.convertString(x.getString(1))
      val signTime = StringToolUtil.convertString(x.getString(2))
      val signCityCode = StringToolUtil.convertString(x.getString(3))
      val signDeptCode = StringToolUtil.convertString(x.getString(4))
      val fullSignAddress = StringToolUtil.convertString(x.getString(5)).replace(broadcastTuple.value._1, "")
      val matchTime = StringToolUtil.convertString(x.getString(6))
      val matchDeptCode = StringToolUtil.convertString(x.getString(7))
      RejectDetailDO(reason, waybillNo, signTime, signCityCode, signDeptCode, fullSignAddress, matchTime, matchDeptCode)
    }).map(x => {
      implicit val formats = org.json4s.DefaultFormats
      val jsonStr = org.json4s.jackson.Serialization.write(x)
      JSON.parseObject(jsonStr)
    }).coalesce(parallelism)
    rejectDetailRdd
  }

  def getPushDetailRdd(spark: SparkSession, incDay: String, rdd: RDD[JSONObject]): RDD[JSONObject] = {
    val broadcastTuple = spark.sparkContext.broadcast(Tuple2(url, ak))
    logger.error("============>>>Partitions为: " + rdd.partitions.length)
    val result = rdd.map(x => {
      x.put("ak", broadcastTuple.value._2)
      Thread.sleep(40)
      val depPonResponse = HttpConnection.httpPost(2, broadcastTuple.value._1, x.toJSONString)
      x.put("depPonResponse", depPonResponse)
      x
    })
    result
  }

  /** @note Main Rich Services */
  def analysisRichService(spark: SparkSession, incDay: String): Unit = {
    // 1. 获取德邦指标计算流程中各明细数据,然后筛选指定DataType值的明细数据推送给德邦
    val rejectDetailRdd = getRejectDetailRdd(spark, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("获取需要推送给德邦明细数据量为: " + rejectDetailRdd.count())
    logger.error("获取需要推送给德邦明细数据Partitions为: " + rejectDetailRdd.partitions.length)

    // 2. 开始调用推送接口服务推送数据
    val pushDetailRdd = getPushDetailRdd(spark, incDay, rejectDetailRdd).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("调用推送服务接口后的德邦明细数据量为: " + pushDetailRdd.count())
    pushDetailRdd.take(1).foreach(println(_))

    // 3. 保存推送的明细数据以及响应结果到BDP表
    saveData(spark, incDay, pushDetailRdd)
    logger.error(" 保存推送的明细数据以及响应结果到BDP表OK......")
  }

  def saveData(spark: SparkSession, incDay: String, rdd: RDD[JSONObject]) = {
    import spark.implicits._
    val sourceTableName = "dm_gis.t_deppon_reject_push_info_d"
    logger.error("开始写入数据")
    val tmpViewName = "tmp" + System.currentTimeMillis()
    rdd.map(x => {
      val reason = StringToolUtil.convertString(x.getString("reason"))
      val waybillNo = StringToolUtil.convertString(x.getString("waybillNo"))
      val signTime = StringToolUtil.convertString(x.getString("signTime"))
      val signCityCode = StringToolUtil.convertString(x.getString("signCityCode"))
      val signDeptCode = StringToolUtil.convertString(x.getString("signDeptCode"))
      val fullSignAddress = StringToolUtil.convertString(x.getString("fullSignAddress"))
      val matchTime = StringToolUtil.convertString(x.getString("matchTime"))
      val matchDeptCode = StringToolUtil.convertString(x.getString("matchDeptCode"))
      val depPonResponse = StringToolUtil.convertString(x.getString("depPonResponse"))
      (reason, waybillNo, signTime, signCityCode, signDeptCode, fullSignAddress, matchTime, matchDeptCode, depPonResponse)
    }).repartition(2).toDF("reason", "waybillno", "signtime", "signcitycode", "signdeptcode", "fullsignaddress", "matchtime", "matchdeptcode", "depponresponse")
      .createOrReplaceTempView(tmpViewName)
    val sql = s"insert overwrite table $sourceTableName partition(inc_day='${incDay}') " +
      s" select * from ${tmpViewName}"
    logger.error(sql)
    spark.sql(sql)
    logger.error("添加新的分区完毕 ")
  }


  def test(): Unit = {
    val ak = "8bb09e5e110845f39a000391668e3e80"
    val jsonObject = new JSONObject()
    jsonObject.put("reason", "1")
    jsonObject.put("waybillNo", "DPK30000210196312")
    jsonObject.put("signTime", "2020-09-06 19:27:41")
    jsonObject.put("signCityCode", "519")
    jsonObject.put("signDeptCode", "W0000033952")
    jsonObject.put("fullSignAddress", "江苏省常州市溧阳市南渡镇嘉程物流有限公司")
    jsonObject.put("matchDeptCode", "W0000036324")
    jsonObject.put("matchTime", "2020-09-04 18:46:10.069")
    jsonObject.put("ak", ak)
    val depPonPushRejectUrl = "http://gis-int.intsit.sfdc.com.cn:1080/eds/push/data"
    // TODO http://gis-int.intsit.sfdc.com.cn:1080/eds/push/data  ak: 8bb09e5e110845f39a000391668e3e80
    logger.error("jsonObject>>>>>>>>>" + jsonObject.toJSONString)
    // {"reason":"1","signCityCode":"519","matchDeptCode":"W0000036324","signTime":"2020-09-06 19:27:41","fullSignAddress":"江苏省常州市溧阳市南渡镇嘉程物流有限公司","signDeptCode":"W0000033952","ak":"0376a9aa84724dd2a995f858dd963346","matchTime":"2020-09-04 18:46:10.069","waybillNo":"DPK300002101963"}
    val result = HttpConnection.httpPost(2, depPonPushRejectUrl, jsonObject.toJSONString)
    logger.error("result>>>>>>>>>" + result)
  }

  /**
   * @note 初始化spark并执行任务
   * @param incDay String
   **/
  def execute(incDay: String): Unit = {
    val spark = Spark.getSparkSession(appName)
    val numCores = spark.sparkContext.getConf.get("spark.executor.cores").toInt
    val numExecutors = spark.sparkContext.getConf.get("spark.executor.instances").toInt
    parallelism = numCores * numExecutors
    logger.error(">>>>>>Custom Parallelism == " + parallelism)
    analysisRichService(spark, incDay)
    logger.error(">>>>>>Analysis OK")
    Thread.sleep(1 * 1000 * 60 * 1)
    spark.stop()
  }

  def main(args: Array[String]): Unit = {
    val incDay = args(0)
    logger.error(">>>>>>Start Execute Date " + incDay)
    execute(incDay)
    logger.error(">>>>>>OK End Execute Date " + incDay)

  }
}
