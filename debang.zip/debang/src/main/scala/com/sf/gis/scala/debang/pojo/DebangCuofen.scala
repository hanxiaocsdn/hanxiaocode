package com.sf.gis.scala.debang.pojo

case class DebangCuofen(citycode: String,address:String,aoiid:String,zc:String)


