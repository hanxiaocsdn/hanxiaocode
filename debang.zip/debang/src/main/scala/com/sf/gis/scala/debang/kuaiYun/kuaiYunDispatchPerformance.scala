package com.sf.gis.scala.debang.kuaiYun

import com.sf.gis.scala.debang.util.Util
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object kuaiYunDispatchPerformance {
  @transient lazy val logger: Logger = Logger.getLogger(kuaiYunDispatchPerformance.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(incDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    logger.error("开始计算：" + incDay)
    startSta(spark, incDay)
    logger.error("计算结束：" + incDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error("计算数据")
    //取数据源
    val dataRdd = getDataDf(spark, incDay)
    logger.error("结束所有运行")

  }


  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {

    //初始响应的数据源
    val staSql =
      s"""
         |select
         |ak
         |,time
         |,type
         |,dateTime
         |--分位点时间排序
         |,count(*)over(distribute by ak) as tatol_reponse_num
         |,count(*)over(distribute by ak,substr(dateTime,1,16)) as min_reponse_num
         |,row_number()over(distribute by ak sort by cast(time as bigint)) as reponse_time_rn
         |--每分钟分位点时间排序
         |,row_number()over(distribute by substr(dateTime,1,16),ak sort by cast(time as bigint)) as min_reponse_time_rn
         |from (
         |select
         |ak
         |,time
         |,type
         |,dateTime
         |from
         |dm_gis.adds_log_kafka_elev_analysis
         |where inc_day = '${incDay}' and type = 'url_e'
         |union all
         |select
         |'ALL' as ak
         |,time
         |,type
         |,dateTime
         |from
         |dm_gis.adds_log_kafka_elev_analysis
         |where inc_day = '${incDay}' and type = 'url_e'
         |) a
      """.stripMargin




//    //初始响应的数据源
//    val staSql =
//      """
//         |select
//         |ak
//         |,time
//         |,type
//         |,dateTime
//         |--分位点时间排序
//         |,row_number()over(distribute by ak sort by time) as reponse_time_rn
//         |--每分钟分位点时间排序
//         |,row_number()over(distribute by substr(dateTime,1,16),ak sort by time) as min_reponse_time_rn
//         |from (
//         |select
//         |ak
//         |,time
//         |,type
//         |,get_json_object(message,'$.dateTime')  as dateTime
//         |from
//         |dm_gis.adds_log_kafka_elev_analysis
//         |where inc_day = '%s' and type = 'url_e'
//         |union all
//         |select
//         |'ALL' as ak
//         |,time
//         |,type
//         |,get_json_object(message,'$.dateTime')  as dateTime
//         |from
//         |dm_gis.adds_log_kafka_elev_analysis
//         |where inc_day = '%s' and type = 'url_e'
//         |) a
//      """.stripMargin
//
//      val foemarSql = String.format(staSql,incDay,incDay)

    logger.error("sta_table" + staSql)
    val staRdd = spark.sql(staSql).repartition(2000).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(staRdd.take(2).foreach(println(_)))
    logger.error("初始数据源的数量" + staRdd.count())
    staRdd.createOrReplaceTempView("sta_table")
    logger.error("入库")
    staRdd.coalesce(100).withColumn("inc_day",lit(incDay)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.adds_log_kafka_elev_detail")


    //求请求峰值+请求量
    val maxPeakSql =
      s"""
         |--每个ak，每分钟的请求量
         |select
         |count(*) as min_res_count
         |,ak
         |,substr(dateTime,1,16) as min_date
         |from
         |(
         |select
         |ak
         |,dateTime
         |,type
         |from dm_gis.adds_log_kafka_elev_analysis
         |where type = 'url_s' and inc_day = '${incDay}'
         |union all
         |select
         |'ALL' as ak
         |,dateTime
         |,type
         |from dm_gis.adds_log_kafka_elev_analysis
         |where type = 'url_s' and inc_day = '${incDay}'
         |)a
         |group by
         |ak
         |,substr(dateTime,1,16)
      """.stripMargin

    logger.error("max_peak_table:" + maxPeakSql)
    val maxPeakRdd = spark.sql(maxPeakSql).repartition(2000).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(maxPeakRdd.take(2).foreach(println(_)))
    logger.error("峰值的数据量" + maxPeakRdd.count())
    maxPeakRdd.createOrReplaceTempView("max_peak_table")


    //ak维度的统计响应时间，响应数量
    val all_reponse =
      s"""
         |select
         |ak
         |,reponse_time_sum
         |,reponse_sum
         |,0_range_time
         |,200_range_time
         |,500_range_time
         |,1000_range_time
         |,2000_range_time
         |,3000_range_time
         |--算90,95,99分位点
         |,ROUND(reponse_sum * 0.9)   as 90_reponse_sum
         |,ROUND(reponse_sum * 0.95)  as 95_reponse_sum
         |,ROUND(reponse_sum * 0.99)  as 99_reponse_sum
         |from(
         |select
         |ak
         |--响应时间
         |,sum(time) as reponse_time_sum
         |--响应数量
         |,count(type) as reponse_sum
         |--响应的超时量
         |,sum(if (time>=0 and time <200,1,0))     as 0_range_time
         |,sum(if (time>=200 and time <500,1,0))   as 200_range_time
         |,sum(if (time>=500 and time <1000,1,0))  as 500_range_time
         |,sum(if (time>=1000 and time <2000,1,0)) as 1000_range_time
         |,sum(if (time>=2000 and time <3000,1,0)) as 2000_range_time
         |,sum(if (time>=3000,1,0))   as 3000_range_time
         |from
         |sta_table
         |group by ak
         |)a
      """.stripMargin
    logger.error("all_reponse_table:" + all_reponse)
    val allReponseRdd = spark.sql(all_reponse).repartition(2000).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(allReponseRdd.take(2).foreach(println(_)))
    logger.error("ak维度的统计响应时间，响应的数量" + allReponseRdd.count())
    allReponseRdd.createOrReplaceTempView("all_reponse_table")


    //总性能表+超时量表
    val quantileReponseSql =
      s"""
         |select
         |ak
         |,reponse_time_sum --响应时间
         |,reponse_sum  --响应量
         |--超时量
         |,0_range_time
         |,200_range_time
         |,500_range_time
         |,1000_range_time
         |,2000_range_time
         |,3000_range_time
         |--峰值
         |,max_res
         |,res_count
         |--分位点
         |,sum(90_reponse_sum) as 90_reponse_sum
         |,sum(95_reponse_sum) as 95_reponse_sum
         |,sum(99_reponse_sum) as 99_reponse_sum
         |from(
         |
         |
         |select
         | a.ak
         |,a.reponse_time_sum
         |,a.reponse_sum
         |,a.0_range_time
         |,a.200_range_time
         |,a.500_range_time
         |,a.1000_range_time
         |,a.2000_range_time
         |,a.3000_range_time
         |,c.max_res
         |,c.res_count
         |,if(b.reponse_time_rn = a.90_reponse_sum,b.time,0) as  90_reponse_sum
         |,if(b.reponse_time_rn = a.95_reponse_sum,b.time,0) as  95_reponse_sum
         |,if(b.reponse_time_rn = a.99_reponse_sum,b.time,0) as  99_reponse_sum
         |from all_reponse_table a
         |inner join
         |sta_table b
         |on a.ak = b.ak
         |left join
         |(
         |--分钟汇总到ak，取总的请求量，跟峰值
         |select
         |ak
         |,max(min_res_count) as max_res   --峰值
         |,sum(min_res_count) as res_count --总的请求量
         |from
         |max_peak_table
         |group by ak
         |)c
         |on c.ak = a.ak
         |where b.reponse_time_rn = a.90_reponse_sum or  b.reponse_time_rn = a.95_reponse_sum or b.reponse_time_rn = a.99_reponse_sum
         |)a
         |group by
         |ak
         |,reponse_time_sum
         |,reponse_sum
         |,0_range_time
         |,200_range_time
         |,500_range_time
         |,1000_range_time
         |,2000_range_time
         |,3000_range_time
         |,max_res
         |,res_count
         """.stripMargin

    logger.error(quantileReponseSql)
    val RepRdd = spark.sql(quantileReponseSql).repartition(2000).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(RepRdd.take(2).foreach(println(_)))
    logger.error("总性能表+超时量表的数据量" + RepRdd.count())

    val all_table = "dm_gis.adds_log_kafka_elev_performance"
    logger.error("总性能表入库:"+all_table)
    RepRdd.coalesce(100).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(all_table)


    //每分钟的性能表
    val minQuantileRepSql =
      """
        |
        |
        |select
        | ak
        |,regexp_replace(dateTime,'-|:|\\s','') as dateTime
        |,reponse_time_sum
        |,reponse_sum
        |,min_res_count
        |,sum(90_reponse_sum) as  90_reponse_sum
        |,sum(95_reponse_sum) as 95_reponse_sum
        |,sum(99_reponse_sum) as 99_reponse_sum
        |from
        |(
        |select
        |a.ak
        |,a.reponse_time_sum
        |,a.reponse_sum
        |,a.dateTime
        |,c.min_res_count
        |,if(b.min_reponse_time_rn = a.90_reponse_sum,b.time,0) as  90_reponse_sum
        |,if(b.min_reponse_time_rn = a.95_reponse_sum,b.time,0) as  95_reponse_sum
        |,if(b.min_reponse_time_rn = a.99_reponse_sum,b.time,0) as  99_reponse_sum
        |from(
        |select
        | ak
        |,dateTime
        |--响应时间
        |,reponse_time_sum
        |--响应数量
        |,reponse_sum
        |--算90,95,99分位点
        |,ROUND(reponse_sum * 0.9)   as 90_reponse_sum
        |,ROUND(reponse_sum * 0.95)  as 95_reponse_sum
        |,ROUND(reponse_sum * 0.99)  as 99_reponse_sum
        |from
        |(
        |select
        | ak
        |,substr(dateTime,1,16) as dateTime
        |--响应时间
        |,sum(time) as reponse_time_sum
        |--响应数量
        |,count(type) as reponse_sum
        |from sta_table a
        |group by
        | ak
        |,substr(dateTime,1,16)
        |)a
        |)a
        |--取每分钟分位点数据
        |inner join
        |sta_table b
        |on a.ak = b.ak
        |and a.dateTime = substr(b.dateTime,1,16)
        |left join
        |max_peak_table c
        |on c.ak = a.ak
        |and c.min_date=a.dateTime
        |where b.min_reponse_time_rn = a.90_reponse_sum or  b.min_reponse_time_rn = a.95_reponse_sum or b.min_reponse_time_rn = a.99_reponse_sum
        |
        |)a
        |group by
        | ak
        |,dateTime
        |,reponse_time_sum
        |,reponse_sum
        |,min_res_count
      """.stripMargin

    logger.error(minQuantileRepSql)
    val minRepRdd = spark.sql(minQuantileRepSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(minRepRdd.take(10).foreach(println(_)))


    val min_table = "dm_gis.adds_log_kafka_elev_min_performance"
    logger.error("每分钟的性能表入库:"+min_table)
    minRepRdd.coalesce(100).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(min_table)

  }



}
