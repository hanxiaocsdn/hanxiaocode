package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.debang.util._
import org.apache.commons.lang.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * Created by 01374443 on 2019/3/5.
 * * Update by 01412406 on 2021/6/23.
 * 时间确定
 */

object kuaiYunDispatchService {
  @transient lazy val logger: Logger = Logger.getLogger(kuaiYunDispatchService.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  case class result(
                     dateTime: String,
                     mtype: String,
                     sn: String,
                     ak: String,
                     address: String,
                     citycode: String,
                     waybillno: String,
                     time: String,
                     src: String,
                     status: String,
                     isElevator: String,
                     isClimb: String,
                     floor: String,
                     err: String,
                     msg: String,
                     message: String,
                     log: String,
                     group_id: String,
                     aoi_id: String,
                     aoiTypeCode: String
                   )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val formatDay = startDay.replaceAll("-", "") //20210823
    val formatDay1 = DateUtil.getDateStr(startDay, 1, "-") //2021-08-24
    val formatDay3 = DateUtil.getDateStr(startDay, -1, "-") //2021-08-22


    //        for (i <- 0 until days) {
    val sepDay = DateUtil.getDateStr(formatDay, 0, "") //20210823 t-2
    val T1Day = DateUtil.getDateStr(formatDay, 1, "") //20210824
    val T4Day = DateUtil.getDateStr(formatDay, -2, "") //20210821
    val T3Day = DateUtil.getDateStr(formatDay, -1, "") //20210822
    val incDay = sepDay.replaceAll("-", "") //t-2

    logger.error("开始计算：" + incDay + "&&formatDay1:" + formatDay1 + "&&formatDay3:" + formatDay3)
    startSta(spark, incDay, sepDay, T1Day, T3Day, T4Day, formatDay1, formatDay3)
    logger.error("计算结束：" + incDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String, sepDay: String, T1Day: String, T3Day: String, T4Day: String, formatDay1: String, formatDay3: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataRdd = getDataDf(spark, incDay)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("开始解析")
    val saveRdd = analysisRdd(dataRdd)

    logger.error("获取新日志")
    val dataRdd_new = getDataDf_new(spark, incDay)
    logger.error("解析新日志")
    val saveRdd_new = analysisRdd_new(dataRdd_new)

    logger.error("开始入库")
    //入库
    saveTable(spark, saveRdd.union(saveRdd_new), incDay)
    logger.error("解析表入库完毕")
    logger.error("开始计算指标")
    runAnalysisDataDf(spark, incDay)
    logger.error("结束所有运行")

  }


  //入库
  def saveTable(spark: SparkSession, saveRdd: RDD[result], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = saveRdd.toDF()


    logger.error("入明细表数量：" + rowDf.count())


    //    val tableName = "dm_gis.dispatch_service_log_analysis_di" //生产数据表
    val tableName = "dm_gis.adds_log_kafka_elev_analysis" //生产数据表
    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)


    //    rowDf.write.mode(SaveMode.Overwrite).partitionBy( "inc_day").saveAsTable(tableName)

  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      """
        |select
        |log
        |,get_json_object(log,'$.message') as message
        |from
        |dm_gis.adds_log_kafka_elev
        |where inc_day = '%s'
        |and substr(get_json_object(get_json_object(get_json_object(log,'$.message') ,'$.url'),'$.url'),1,41)= 'http://nginxwa/elevator/api/queryElevator'
      """.stripMargin


    val formatSql = String.format(totalDfSql, incDay)

    logger.error(formatSql)
    val totalRdd = SparkUtils.getRowToJson(spark, formatSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }

  def getDataDf_new(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      """
        |select
        |log
        |,get_json_object(log,'$.message') as message
        |from
        |dm_gis.adds_log_kafka_elev
        |where inc_day = '%s'
        |and get_json_object(get_json_object(log,'$.message') ,'$.url')= '/elevator/api/queryElevator'
      """.stripMargin


    val formatSql = String.format(totalDfSql, incDay)

    logger.error(formatSql)
    val totalRdd = SparkUtils.getRowToJson(spark, formatSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }

  //日志解析
  def analysisRdd(dataRdd: RDD[JSONObject]) = {

    logger.error("解析的数据量" + dataRdd.count())

    val finalRdd = dataRdd.map(obj => {

      var message = JSONUtil.getJsonVal(obj, "message", "")
      var log = JSONUtil.getJsonVal(obj, "log", "")

      var sn = ""
      var ak = ""
      var address = ""
      var citycode = ""
      var waybillno = ""
      var time = ""
      var src = ""
      var status = ""
      var isElevator = ""
      var isClimb = ""
      var floor = ""
      var err = ""
      var msg = ""
      var group_id = ""
      var aoi_id = ""
      var mtype = ""

      var dateTime = ""
      var aoiTypeCode = ""
      val messageObject = JSONUtil.parseJSONObject(message)

      if (messageObject != null) {
        dateTime = JSONUtil.getJsonVal(messageObject, "dateTime", "")
        //      if(dateTime.size>=10) dateTime = dateTime.substring(0,10)
        sn = JSONUtil.getJsonVal(messageObject, "sn", "")
        ak = JSONUtil.getJsonVal(messageObject, "url.ak", "")
        address = JSONUtil.getJsonVal(messageObject, "url.address", "")
        citycode = JSONUtil.getJsonVal(messageObject, "url.citycode", "")
        waybillno = JSONUtil.getJsonVal(messageObject, "url.waybillno", "")
        time = JSONUtil.getJsonVal(messageObject, "time", "")
        mtype = JSONUtil.getJsonVal(messageObject, "type", "")
        src = JSONUtil.getJsonVal(messageObject, "data.result.data.data_src", "")
        status = JSONUtil.getJsonVal(messageObject, "data.status", "")
        isElevator = JSONUtil.getJsonVal(messageObject, "data.result.data.isElevator", "")
        isClimb = JSONUtil.getJsonVal(messageObject, "data.result.data.isClimb", "")
        floor = JSONUtil.getJsonVal(messageObject, "data.result.data.floor", "")
        err = JSONUtil.getJsonVal(messageObject, "data.result.err", "")
        msg = JSONUtil.getJsonVal(messageObject, "data.result.msg", "").trim.toLowerCase()
        group_id = JSONUtil.getJsonVal(messageObject, "data.result.data.group_id", "").trim
        aoi_id = JSONUtil.getJsonVal(messageObject, "data.result.data.aoi_id", "").trim


      }

      result(
        dateTime,
        mtype,
        sn,
        ak,
        address,
        citycode,
        waybillno,
        time,
        src,
        status,
        isElevator,
        isClimb,
        floor,
        err,
        msg,
        message,
        log,
        group_id,
        aoi_id,
        aoiTypeCode
      )

    }).persist(StorageLevel.MEMORY_AND_DISK)
    finalRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })
    finalRdd
  }

  def analysisRdd_new(dataRdd: RDD[JSONObject]) = {

    logger.error("解析的数据量" + dataRdd.count())

    val finalRdd = dataRdd.map(obj => {

      var message = JSONUtil.getJsonVal(obj, "message", "")
      var log = JSONUtil.getJsonVal(obj, "log", "")

      var sn = ""
      var ak = ""
      var address = ""
      var citycode = ""
      var waybillno = ""
      var time = ""
      var src = ""
      var status = ""
      var isElevator = ""
      var isClimb = ""
      var floor = ""
      var err = ""
      var msg = ""
      var group_id = ""
      var aoi_id = ""
      var mtype = ""

      var dateTime = ""
      var aoiTypeCode = ""
      val messageObject = JSONUtil.parseJSONObject(message)

      if (messageObject != null) {
        dateTime = JSONUtil.getJsonVal(messageObject, "dateTime", "")
        //      if(dateTime.size>=10) dateTime = dateTime.substring(0,10)
        sn = JSONUtil.getJsonVal(messageObject, "sn", "")
        ak = JSONUtil.getJsonVal(messageObject, "param.ak", "")
        if (StringUtils.isEmpty(ak)) {
          ak = JSONUtil.getJsonVal(messageObject, "ak", "")
        }
        address = JSONUtil.getJsonVal(messageObject, "param.address", "")
        citycode = JSONUtil.getJsonVal(messageObject, "param.citycode", "")
        waybillno = JSONUtil.getJsonVal(messageObject, "param.waybillno", "")
        time = JSONUtil.getJsonVal(messageObject, "time", "")
        mtype = JSONUtil.getJsonVal(messageObject, "type", "")
        src = JSONUtil.getJsonVal(messageObject, "data.result.data.data_src", "")
        status = JSONUtil.getJsonVal(messageObject, "data.status", "")
        isElevator = JSONUtil.getJsonVal(messageObject, "data.result.data.isElevator", "")
        isClimb = JSONUtil.getJsonVal(messageObject, "data.result.data.isClimb", "")
        floor = JSONUtil.getJsonVal(messageObject, "data.result.data.floor", "")
        aoiTypeCode = JSONUtil.getJsonVal(messageObject, "data.result.data.aoiTypeCode", "")
        err = JSONUtil.getJsonVal(messageObject, "data.result.err", "")
        msg = JSONUtil.getJsonVal(messageObject, "data.result.msg", "").trim.toLowerCase()
        group_id = JSONUtil.getJsonVal(messageObject, "data.result.data.group_id", "").trim
        aoi_id = JSONUtil.getJsonVal(messageObject, "data.result.data.aoi_id", "").trim


      }

      result(
        dateTime,
        mtype,
        sn,
        ak,
        address,
        citycode,
        waybillno,
        time,
        src,
        status,
        isElevator,
        isClimb,
        floor,
        err,
        msg,
        message,
        log,
        group_id,
        aoi_id,
        aoiTypeCode
      )

    }).persist(StorageLevel.MEMORY_AND_DISK)
    finalRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })
    finalRdd
  }


  //根据解析表计算指标
  def runAnalysisDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      s"""
         |select
         | substr(a.datetime,1,10) as datetime
         |,a.ak
         |,b.province
         |,b.city
         |,a.citycode
         |,count(*) 											as total_cnt	--总返回量
         |,sum(if(status = '0',1,0)) 							as success_cnt	--成功量
         |,sum(if(iselevator ='1' or iselevator = '0',1,0 )) 	as elevator_cnt	--电梯识别量
         |,sum(if(iselevator = '1',1,0)) 						as is_elevator_cnt--有电梯
         |,sum(if(iselevator = '0',1,0)) 						as not_elevator_cnt--无电梯
         |,sum(if(iselevator = '-1',1,0)) 					as un_elevator_cnt--电梯无法判断
         |,sum(if(isclimb ='1' or isclimb = '0',1,0 ))    	as climb_cnt--爬楼识别量
         |,sum(if(isclimb = '1',1,0)) 						as is_climb_cnt--需要爬楼
         |,sum(if(isclimb = '0',1,0)) 						as not_climb_cnt--不需要爬楼
         |,sum(if(isclimb = '-1',1,0)) 						as un_climb_cnt--爬楼无法判断
         |,sum(if(floor <> '0',1,0))							as floor_cnt--楼层识别量
         |,sum(if(src ='group-1' or src = 'group-2' or src = 'group-3' or src = 'group-21' or src = 'group-22',1,0))	as src_group_cnt
         |,sum(if(src ='group-1',1,0)) 	as src_group_1_cnt
         |,sum(if(src = 'group-2',1,0)) 	as src_group_2_cnt
         |,sum(if(src = 'group-3',1,0)) 	as src_group_3_cnt
         |,sum(if(src = 'group-21',1,0)) 	as src_group_21_cnt
         |,sum(if(src = 'group-22',1,0)) 	as src_group_22_cnt
         |,sum(if(src ='aoi-1' or src = 'aoi-2' or src = 'aoi-3' or src = 'aoi-21' or src = 'aoi-22',1,0))	as src_aoi_cnt
         |,sum(if(src = 'aoi-2',1,0)) 	as src_aoi_2_cnt
         |,sum(if(src = 'aoi-3',1,0)) 	as src_aoi_3_cnt
         |,sum(if(src = 'aoi-21',1,0)) 	as src_aoi_21_cnt
         |,sum(if(src = 'aoi-22',1,0)) 	as src_aoi_22_cnt
         |,sum(if(src = 'floor',1,0)) 	as src_floor_cnt
         |,sum(if(status = '1',1,0)) 		as fail_cnt--失败量
         |,sum(if(status = '1' and err = '-106' and msg = 'address不能为空',1,0)) as 	address_empty_cnt	--地址为空
         |,sum(if(status = '1' and err = '-106' and msg = 'citycode不能为空',1,0)) as citycode_empty_cnt		--城市代码为空
         |,sum(if(status = '1' and err = '-106' and msg = 'params error',1,0)) as 	ak_empty_cnt		--ak为空
         |,sum(if(status = '1' and err = '1' and msg = '无法匹配',1,0))    as 		not_match_cnt		--无法匹配
         |,sum(if(status = '1' and err = '1' and msg = 'src数据为空',1,0)) as 		src_empty_cnt		--SRC数据为空
         |,0 as src_aoi_0_cnt
         |,sum(if(src = 'aoi-1',1,0)) 	as src_aoi_1_cnt
         |from
         |dm_gis.adds_log_kafka_elev_analysis a
         |left join
         |(
         | select max(city) as city ,citycode,max(province) as province
         | from dm_gis.address_info_map_di
         | group by citycode
         |)b
         |on a.citycode = b.citycode
         |where inc_day = '${incDay}' and type = 'url_e'
         |group by
         | substr(a.datetime,1,10)
         |,a.ak
         |,b.province
         |,b.city
         |,a.citycode
      """.stripMargin


    logger.error(totalDfSql)

    //获取数据
    val dataDf = spark.sql(totalDfSql).repartition(200).persist(StorageLevel.MEMORY_AND_DISK)


    dataDf.createOrReplaceTempView("tmp")

    //汇总统计
    val resql =
      """
        |select
        | datetime
        |,ak
        |,province
        |,city
        |,citycode
        |,sum(total_cnt) AS total_cnt
        |,sum(success_cnt) AS success_cnt
        |,sum(elevator_cnt) AS elevator_cnt
        |,sum(is_elevator_cnt) AS is_elevator_cnt
        |,sum(not_elevator_cnt) AS not_elevator_cnt
        |,sum(un_elevator_cnt) AS un_elevator_cnt
        |,sum(climb_cnt) AS climb_cnt
        |,sum(is_climb_cnt) AS is_climb_cnt
        |,sum(not_climb_cnt) AS not_climb_cnt
        |,sum(un_climb_cnt) AS un_climb_cnt
        |,sum(floor_cnt) AS floor_cnt
        |,sum(src_group_cnt) AS src_group_cnt
        |,sum(src_group_1_cnt) AS src_group_1_cnt
        |,sum(src_group_2_cnt) AS src_group_2_cnt
        |,sum(src_group_3_cnt) AS src_group_3_cnt
        |,sum(src_group_21_cnt) AS src_group_21_cnt
        |,sum(src_group_22_cnt) AS src_group_22_cnt
        |,sum(src_aoi_cnt) AS src_aoi_cnt
        |,sum(src_aoi_2_cnt) AS src_aoi_2_cnt
        |,sum(src_aoi_3_cnt) AS src_aoi_3_cnt
        |,sum(src_aoi_21_cnt) AS src_aoi_21_cnt
        |,sum(src_aoi_22_cnt) AS src_aoi_22_cnt
        |,sum(src_floor_cnt) AS src_floor_cnt
        |,sum(fail_cnt) AS fail_cnt
        |,sum(address_empty_cnt) AS address_empty_cnt
        |,sum(citycode_empty_cnt) AS citycode_empty_cnt
        |,sum(ak_empty_cnt) AS ak_empty_cnt
        |,sum(not_match_cnt) AS not_match_cnt
        |,sum(src_empty_cnt) AS src_empty_cnt
        |,sum(src_aoi_0_cnt) AS src_aoi_0_cnt
        |,sum(src_aoi_1_cnt) AS src_aoi_1_cnt
        |from tmp
        |group by
        | datetime
        |,ak
        |,province
        |,city
        |,citycode
        |--AK为ALL
        |union all
        |select
        | datetime
        |,'ALL' as ak
        |,'ALL' AS province
        |,'ALL' AS city
        |,'ALL' AS citycode
        |,sum(total_cnt) AS total_cnt
        |,sum(success_cnt) AS success_cnt
        |,sum(elevator_cnt) AS elevator_cnt
        |,sum(is_elevator_cnt) AS is_elevator_cnt
        |,sum(not_elevator_cnt) AS not_elevator_cnt
        |,sum(un_elevator_cnt) AS un_elevator_cnt
        |,sum(climb_cnt) AS climb_cnt
        |,sum(is_climb_cnt) AS is_climb_cnt
        |,sum(not_climb_cnt) AS not_climb_cnt
        |,sum(un_climb_cnt) AS un_climb_cnt
        |,sum(floor_cnt) AS floor_cnt
        |,sum(src_group_cnt) AS src_group_cnt
        |,sum(src_group_1_cnt) AS src_group_1_cnt
        |,sum(src_group_2_cnt) AS src_group_2_cnt
        |,sum(src_group_3_cnt) AS src_group_3_cnt
        |,sum(src_group_21_cnt) AS src_group_21_cnt
        |,sum(src_group_22_cnt) AS src_group_22_cnt
        |,sum(src_aoi_cnt) AS src_aoi_cnt
        |,sum(src_aoi_2_cnt) AS src_aoi_2_cnt
        |,sum(src_aoi_3_cnt) AS src_aoi_3_cnt
        |,sum(src_aoi_21_cnt) AS src_aoi_21_cnt
        |,sum(src_aoi_22_cnt) AS src_aoi_22_cnt
        |,sum(src_floor_cnt) AS src_floor_cnt
        |,sum(fail_cnt) AS fail_cnt
        |,sum(address_empty_cnt) AS address_empty_cnt
        |,sum(citycode_empty_cnt) AS citycode_empty_cnt
        |,sum(ak_empty_cnt) AS ak_empty_cnt
        |,sum(not_match_cnt) AS not_match_cnt
        |,sum(src_empty_cnt) AS src_empty_cnt
        |,sum(src_aoi_0_cnt) AS src_aoi_0_cnt
        |,sum(src_aoi_1_cnt) AS src_aoi_1_cnt
        |from tmp
        |group by
        | datetime
        |--province为ALL
        |UNION ALL
        |select
        | datetime
        |,ak
        |,'ALL' AS province
        |,'ALL' AS city
        |,'ALL' AS citycode
        |,sum(total_cnt) AS total_cnt
        |,sum(success_cnt) AS success_cnt
        |,sum(elevator_cnt) AS elevator_cnt
        |,sum(is_elevator_cnt) AS is_elevator_cnt
        |,sum(not_elevator_cnt) AS not_elevator_cnt
        |,sum(un_elevator_cnt) AS un_elevator_cnt
        |,sum(climb_cnt) AS climb_cnt
        |,sum(is_climb_cnt) AS is_climb_cnt
        |,sum(not_climb_cnt) AS not_climb_cnt
        |,sum(un_climb_cnt) AS un_climb_cnt
        |,sum(floor_cnt) AS floor_cnt
        |,sum(src_group_cnt) AS src_group_cnt
        |,sum(src_group_1_cnt) AS src_group_1_cnt
        |,sum(src_group_2_cnt) AS src_group_2_cnt
        |,sum(src_group_3_cnt) AS src_group_3_cnt
        |,sum(src_group_21_cnt) AS src_group_21_cnt
        |,sum(src_group_22_cnt) AS src_group_22_cnt
        |,sum(src_aoi_cnt) AS src_aoi_cnt
        |,sum(src_aoi_2_cnt) AS src_aoi_2_cnt
        |,sum(src_aoi_3_cnt) AS src_aoi_3_cnt
        |,sum(src_aoi_21_cnt) AS src_aoi_21_cnt
        |,sum(src_aoi_22_cnt) AS src_aoi_22_cnt
        |,sum(src_floor_cnt) AS src_floor_cnt
        |,sum(fail_cnt) AS fail_cnt
        |,sum(address_empty_cnt) AS address_empty_cnt
        |,sum(citycode_empty_cnt) AS citycode_empty_cnt
        |,sum(ak_empty_cnt) AS ak_empty_cnt
        |,sum(not_match_cnt) AS not_match_cnt
        |,sum(src_empty_cnt) AS src_empty_cnt
        |,sum(src_aoi_0_cnt) AS src_aoi_0_cnt
        |,sum(src_aoi_1_cnt) AS src_aoi_1_cnt
        |from tmp
        |group by
        | datetime
        |,ak
        |--city为ALL
        |UNION ALL
        |select
        | datetime
        |,ak
        |,province
        |,'ALL' AS city
        |,'ALL' AS citycode
        |,sum(total_cnt) AS total_cnt
        |,sum(success_cnt) AS success_cnt
        |,sum(elevator_cnt) AS elevator_cnt
        |,sum(is_elevator_cnt) AS is_elevator_cnt
        |,sum(not_elevator_cnt) AS not_elevator_cnt
        |,sum(un_elevator_cnt) AS un_elevator_cnt
        |,sum(climb_cnt) AS climb_cnt
        |,sum(is_climb_cnt) AS is_climb_cnt
        |,sum(not_climb_cnt) AS not_climb_cnt
        |,sum(un_climb_cnt) AS un_climb_cnt
        |,sum(floor_cnt) AS floor_cnt
        |,sum(src_group_cnt) AS src_group_cnt
        |,sum(src_group_1_cnt) AS src_group_1_cnt
        |,sum(src_group_2_cnt) AS src_group_2_cnt
        |,sum(src_group_3_cnt) AS src_group_3_cnt
        |,sum(src_group_21_cnt) AS src_group_21_cnt
        |,sum(src_group_22_cnt) AS src_group_22_cnt
        |,sum(src_aoi_cnt) AS src_aoi_cnt
        |,sum(src_aoi_2_cnt) AS src_aoi_2_cnt
        |,sum(src_aoi_3_cnt) AS src_aoi_3_cnt
        |,sum(src_aoi_21_cnt) AS src_aoi_21_cnt
        |,sum(src_aoi_22_cnt) AS src_aoi_22_cnt
        |,sum(src_floor_cnt) AS src_floor_cnt
        |,sum(fail_cnt) AS fail_cnt
        |,sum(address_empty_cnt) AS address_empty_cnt
        |,sum(citycode_empty_cnt) AS citycode_empty_cnt
        |,sum(ak_empty_cnt) AS ak_empty_cnt
        |,sum(not_match_cnt) AS not_match_cnt
        |,sum(src_empty_cnt) AS src_empty_cnt
        |,sum(src_aoi_0_cnt) AS src_aoi_0_cnt
        |,sum(src_aoi_1_cnt) AS src_aoi_1_cnt
        |from tmp
        |group by
        | datetime
        |,ak
        |,province
      """.stripMargin

    logger.error(resql)
    val resDf = spark.sql(resql).repartition(200).persist(StorageLevel.MEMORY_AND_DISK)


    resDf.show(10, true)
    logger.error("汇总表入库数据量：" + resDf.count())
    //入库
    val tableName = "dm_gis.adds_log_kafka_elev_analysis_cnt" //生产数据表
    //    val tableName = "dm_gis.dispatch_service_log_analysis_cnt_di" //生产数据表
    logger.error("汇总表入库：" + tableName + "分区:" + incDay)
    resDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("入库完毕")

  }


}
