package com.sf.gis.scala.debang.kuaiYun

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.debang.util.{SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2021/11/24
  * 时间确定
  */



object KuaiyunAoiCuokeClean {
  @transient lazy val logger: Logger = Logger.getLogger(KuaiyunAoiCuokeClean.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  //容灾接口ur
  val rz_url = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?opt=zh&ak=dec044d089524419b371bc94555c539d&city=%s&address=%s"
  //cgcs接口 post
  // 审补AOI错分数据推送接口
  val cgcs_url_3 = "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushChknWrongAoiTask"
  //标准地址完整数据推送接口
  val cgcs_url_4 = "http://gis-aos-cgcs.sf-express.com/audit/api/deal/pushNormHisTask"

  case class result(
                     cityCode: String
                     , normAddress: String
                     , groupId: String
                     , normZnoCode: String
                     , chknAddress: String
                     , aoiid: String
                     , chknZnoCode: String
                     , filter: String
                     , adcode: String
                     , splitResult: String
                     , tag: String
                     , taskSource: String = "KY"
                   )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error(s"获取数据源 incDay:${incDay}")
    //取数据源
    val dataRdd: RDD[JSONObject] = getDataDf(spark, incDay)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("获取剔除配置表")
    val signDataRdd = querySignData(spark)
    //    dm_gis.kycuokeaoi_task_to_cgcs
    logger.error("获取t-7日内下发任务表")
    val cgcsDataRdd: RDD[(String, Int)] = queryCgcsData(spark)
    logger.error("开始打标签")
    val checkRdd = checkTagData(dataRdd, signDataRdd, cgcsDataRdd)
    logger.error("开始入库")
    //入库
    saveTable(spark, checkRdd, incDay)
    logger.error("结束所有运行")
  }


  //获取签收表,确定时间分区
  def querySignData(spark: SparkSession) = {
    val sql =
      s"""
         |select * from (
         |select
         |	   city
         |	  ,address
         |    ,aoi
         |	  ,row_number()over(distribute by address sort by address desc) rn
         |from dm_gis.ky_address_remove_conf
         |)a
         |where rn =1
      """.stripMargin
    logger.error(sql)
    val dataRdd = SparkUtils.getRowToJson(spark, sql).repartition(sqlpartition)
      .map(o => (JSONUtil.getJsonVal(o, "address", ""), 1)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)

    logger.error("剔除配置表总数量：" + dataRdd.count())
     dataRdd
  }


  //获取签收表
  def queryCgcsData(spark: SparkSession) = {
    val sql =
      s"""
         |select
         |chknAddress
         |from dm_gis.kycuokeaoi_task_to_cgcs
         |group by chknAddress
      """.stripMargin
    logger.error(sql)
    val dataRdd = SparkUtils.getRowToJson(spark, sql).repartition(sqlpartition)
      .map(o => (JSONUtil.getJsonVal(o, "chknAddress", ""), 1)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("t-7日内下发任务表总数量：" + dataRdd.count())
//    val reRdd = dataRdd.map(o=>("",1))
//    reRdd
    dataRdd
  }

  //打标签
  def checkTagData(dataRdd: RDD[JSONObject], signDataRdd: RDD[(String, Int)], cgcsDataRdd: RDD[(String, Int)]) = {


    val staRdd = dataRdd.map(o => (JSONUtil.getJsonVal(o, "address", ""), o)).leftOuterJoin(signDataRdd)
      .filter(_._2._2.isEmpty).map(o => (o._1, o._2._1)).leftOuterJoin(cgcsDataRdd).filter(_._2._2.isEmpty).map(_._2._1).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("剔除配置表,t-7日任务表的数据量：" + staRdd.count())

    val cntRdd = staRdd.map(obj => {
      val teamCode = JSONUtil.getJsonVal(obj, "team", "")
      val bdDept = JSONUtil.getJsonVal(obj, "bd_tc", "")
      val tcDept = JSONUtil.getJsonVal(obj, "tc_tc", "")
      val gdDept = JSONUtil.getJsonVal(obj, "gd_tc", "")
      val rhDept = JSONUtil.getJsonVal(obj, "rh_tc", "")


      val bdMatchLevel = JSONUtil.getJsonVal(obj, "rh_level", "")
      val tcMatchLevel = JSONUtil.getJsonVal(obj, "tc_level", "")
      val gdMatchLevel = JSONUtil.getJsonVal(obj, "gd_level", "")
      val rhMatchLevel = JSONUtil.getJsonVal(obj, "bd_level", "")

      var drptCnt = 0
      var matchLevelCnt = 0

      if (teamCode.nonEmpty) {
        if (teamCode.equals(bdDept)) drptCnt += 1
        if (teamCode.equals(tcDept)) drptCnt += 1
        if (teamCode.equals(gdDept)) drptCnt += 1
        if (teamCode.equals(rhDept)) drptCnt += 1
      }

      if (bdMatchLevel.nonEmpty && bdMatchLevel.toInt > 4) matchLevelCnt += 1
      if (tcMatchLevel.nonEmpty && tcMatchLevel.toInt > 4) matchLevelCnt += 1
      if (gdMatchLevel.nonEmpty && gdMatchLevel.toInt > 4) matchLevelCnt += 1
      if (rhMatchLevel.nonEmpty && rhMatchLevel.toInt > 4) matchLevelCnt += 1
      obj.put("drptCnt", drptCnt.toString)
      obj.put("matchLevelCnt", matchLevelCnt.toString)
      var reObj = obj
      var mapTeamCode = ""
      var tsTeamCode = ""
      var Tc54 = ""
      if (!(drptCnt == 0 && matchLevelCnt > 2)) {
        obj.put("tag", "cnt")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val nextRdd = cntRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd = cntRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("判断地址的数据量：" + nextRdd.count())
    logger.error("四元校验剔除的数据量：" + unionRdd.count())


    val addressRdd = nextRdd.map(o => {
      val address = JSONUtil.getJsonVal(o, "address", "")
      if (address.contains("快运") || address.endsWith("对面")) o.put("tag", "address")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val nextRdd1 = addressRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd1 = addressRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("地址剔除的数据量：" + unionRdd1.count())
    logger.error("地址未剔除的数据量：" + nextRdd1.count())



    val aoiRdd = nextRdd1.map(o => {
      val city = JSONUtil.getJsonVal(o, "city", "")
      val address = JSONUtil.getJsonVal(o, "address", "")
      val url = String.format(rz_url, city, address)
      val tc: JSONObject = HttpClientUtil.getJsonByGet(url, 3)
      var src = ""
      var groupid = ""
      var dept = ""

      var aoiid = ""
      var splitResult = ""
      var standardization = ""
      var adcode = ""
      var filter = ""
      if (tc != null) {
        val tcs = try {
          JSONUtil.getJsonArrayMulti(tc, "result.tcs").getJSONObject(0)
        } catch {
          case _ => new JSONObject()
        }
        val geocoder = try {
          JSONUtil.getJsonArrayMulti(tc, "result.other.normresp.result.geocoder").getJSONObject(0)
        } catch {
          case _ => new JSONObject()
        }
        splitResult = JSONUtil.getJsonVal(tc, "result.other.normresp.result.splitResult", "")
        src = JSONUtil.getJsonVal(tcs, "src", "")
        groupid = JSONUtil.getJsonVal(tcs, "groupid", "")
        dept = JSONUtil.getJsonVal(tcs, "dept", "")
        aoiid = JSONUtil.getJsonVal(tcs, "aoiid", "")
        standardization = JSONUtil.getJsonVal(geocoder, "standardization", "")
        adcode = JSONUtil.getJsonVal(geocoder, "adcode", "")
        filter = JSONUtil.getJsonVal(geocoder, "filter", "")

      }
      o.put("src", src)
      o.put("groupid", groupid)
      o.put("dept", dept)
      o.put("aoiid", aoiid)
      o.put("standardization", standardization)
      o.put("adcode", adcode)
      o.put("filter", filter)
      o.put("splitResult", splitResult)
      if (aoiid.isEmpty) o.put("tag", "aoiempty")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val nextRdd2 = aoiRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd2 = aoiRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("aoi为空的数据量：" + unionRdd2.count())
    logger.error("aoi不为空的数据量：" + nextRdd2.count())


    val reRdd = nextRdd2.map(o => {
      var src = JSONUtil.getJsonVal(o, "src", "")
      if (src.equals("norm")) o.put("tag", "bz") else o.put("tag", "sb")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val retmp: RDD[JSONObject] = reRdd.union(unionRdd2).union(unionRdd1).union(unionRdd)
    logger.error("打完tag的数据量：" + retmp.count())
    logger.error("推送到CGCS错柯错分标准核实")

    val re = pushCgcs(retmp)
    logger.error("tag是bz的数据量：" + re.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("bz")).count())
    logger.error("tag是sb的数据量：" + re.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("sb")).count())
    re
  }


  //入库
  def saveTable(spark: SparkSession, checkRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = checkRdd.map(_.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    val datailTableName = s"dm_gis.kycuokeaoi_task_to_cgcs_detail" //生产数据表
    logger.error(s"明细表${datailTableName}分区${incDay}")
    rowDf.repartition(sqlpartition).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(datailTableName)
    logger.error("入明细表完毕")


    logger.error("开始入错分库")
    val tableName = "dm_gis.kycuokeaoi_task_to_cgcs"
    logger.error(s"明细表${tableName}分区${incDay}")
    //入库错分表
    val reDf = checkRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("bz")
      || JSONUtil.getJsonVal(o, "tag", "").equals("sb")
    ).map(o => {
      result(
        JSONUtil.getJsonVal(o, "city", "")
        , JSONUtil.getJsonVal(o, "standardization", "")
        , JSONUtil.getJsonVal(o, "groupid", "")
        , JSONUtil.getJsonVal(o, "dept", "")
        , JSONUtil.getJsonVal(o, "address", "")
        , JSONUtil.getJsonVal(o, "aoiid", "")
        , JSONUtil.getJsonVal(o, "dept", "")
        , JSONUtil.getJsonVal(o, "filter", "")
        , JSONUtil.getJsonVal(o, "adcode", "")
        , JSONUtil.getJsonVal(o, "splitResult", "")
        , JSONUtil.getJsonVal(o, "tag", "")
      )
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("错分入库数量:" + reDf.count())
    reDf.repartition(sqlpartition).toDF().withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("错分入库完毕")
    //生产打开
//    logger.error("清除7天前的错分数据")
//    val incDay7 = DateUtil.getDateStr(incDay, -5, "") //2021-08-24
//    val del = s"alter table ${tableName} drop if exists partition(inc_day = '${incDay7}') "
//    logger.error(del)
//    spark.sql(del)
//    logger.error("清除完毕")

  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {

    //获取数据源
    val totalDfSql =
      """
        |select
        |*
        |from (
        |select
        | city
        |,address
        |,bd_tc
        |,tc_tc
        |,gd_tc
        |,rh_tc
        |,rh_level
        |,tc_level
        |,gd_level
        |,bd_level
        |,team
        |,row_number()over(distribute by city,address sort by city desc) rn
        | from
        |    (
        |        select
        |            regexp_replace(get_json_object(detail, '$.city_code'),'[\r\t]+','') city
        |            ,regexp_replace(get_json_object(detail, '$.address'),'[\r\n\0, \s, \.,\,,\t,\0022]+','') address
        |            ,get_json_object(detail,'$.bdDept') as bd_tc
        |            ,get_json_object(detail,'$.tcDept') as tc_tc
        |            ,get_json_object(detail,'$.gdDept') as gd_tc
        |            ,get_json_object(detail,'$.rhDept') as rh_tc
        |            ,get_json_object(detail,'$.rhBody.match_level') as rh_level
        |            ,get_json_object(detail,'$.tcBody.match_level') as tc_level
        |            ,get_json_object(detail,'$.gdBody.match_level') as gd_level
        |            ,get_json_object(detail,'$.bdBody.match_level') as bd_level
        |            ,get_json_object(detail,'$.team') as team
        |        from dm_gis.test_kuaiyun_detail_di
        |        where inc_day = '%s'
        |       -- where inc_day between '20211221' and '20211228'
        |        and regexp_replace(get_json_object(detail, '$.wr_tag'),'[\r\t]+','') = 'rec_wr'
        |        and regexp_replace(get_json_object(detail, '$.tag'), '[\r\t]+', '') = 'recognition'
        |        and regexp_replace(get_json_object(detail, '$.src'), '[\r\t]+', '') = 'ADDRESS'
        |    ) a
        |)a
        |where rn = 1
      """.stripMargin
    val formatSql = String.format(totalDfSql, incDay)
    logger.error(formatSql)
    val totalRdd = SparkUtils.getRowToJson(spark, formatSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }

  def pushCgcs(staRdd: RDD[JSONObject]) = {

    val reRdd = staRdd.repartition(seg_partition).map(o => {

      val tag = JSONUtil.getJsonVal(o, "tag", "")
      val param = new JSONObject()
      if (tag.equals("bz")) {
        param.put("cityCode", JSONUtil.getJsonVal(o, "city", ""))
        param.put("normAddress", JSONUtil.getJsonVal(o, "standardization", ""))
        param.put("groupId", JSONUtil.getJsonVal(o, "groupid", ""))
        param.put("normZnoCode", JSONUtil.getJsonVal(o, "dept", ""))
        param.put("chknAddress", JSONUtil.getJsonVal(o, "address", ""))
//        param.put("aoiid", JSONUtil.getJsonVal(o, "aoiid", ""))
        param.put("chknZnoCode", JSONUtil.getJsonVal(o, "dept", ""))
        param.put("filter", JSONUtil.getJsonVal(o, "filter", ""))
        param.put("adcode", JSONUtil.getJsonVal(o, "adcode", ""))
        param.put("splitInfo", JSONUtil.getJsonVal(o, "splitResult", ""))
        param.put("taskSource", "KY")
        param.put("ak","15F6437FF8A2EDFE0C22EA37B12D421A")







        //生产
        val reReq = SparkUtils.doPost(cgcs_url_4, param, logger)

        o.put("cgcsReq", reReq)
        o.put("cgcstype", "v1.4")

      }
      else if (tag.equals("sb")) {
        param.put("cityCode", JSONUtil.getJsonVal(o, "city", ""))
        param.put("znoCode", JSONUtil.getJsonVal(o, "dept", ""))
        param.put("address", JSONUtil.getJsonVal(o, "address", ""))
        param.put("taskSource", "KY")
        param.put("ak","15F6437FF8A2EDFE0C22EA37B12D421A")
        //生产


        val reReq = SparkUtils.doPost(cgcs_url_3, param, logger)
        o.put("cgcsReq", reReq)
        o.put("cgcstype", "v1.3")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("错柯错分审补核实后的数据量：" + reRdd.count())
    reRdd
  }

}
