package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.serializer.SerializerFeature
import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.debang.util.{DateUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2021/11/24
  * 时间确定
  */

object KuaiyunCuokeClean {
  @transient lazy val logger: Logger = Logger.getLogger(KuaiyunCuokeClean.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  //关闭fastjson引用检测
  JSON.DEFAULT_GENERATE_FEATURE |= SerializerFeature.DisableCircularReferenceDetect.getMask
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  //审补删除接口：
  val sb_del_url = "http://gis-int.int.sfdc.com.cn:1080/ky/his/del?ak=0376a9aa84724dd2a995f858dd963346&address=%s&cityCode=%s&showserver=true"
  //容灾接口：
  val rz_url = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?ak=dec044d089524419b371bc94555c539d&opt=zh&city=%s&address=%s"
  //大网更新接口
  val dw_add = "http://gis-int.int.sfdc.com.cn:1080/ky/his/add?address=%s&cityCode=%s&tc=%s&aoiId=%s&ak=0376a9aa84724dd2a995f858dd963346&showserver=true"
  val dw_del = "http://gis-int.int.sfdc.com.cn:1080/ky/his/del?ak=0376a9aa84724dd2a995f858dd963346&address=%s&cityCode=%s&showserver=true"
  val xyAoiUrl = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?&ak=dec044d089524419b371bc94555c539d&x=%s&y=%s&opt=aoi&geom=0"


  val ts_url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=1245f89114fb4f5e896213904b4923a5&opt=gd2&address=%s&city=%s"
  val rh_url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=1245f89114fb4f5e896213904b4923a5&opt=rh1&address=%s&city=%s"


  case class result(
                     city_code: String
                     , zno_code: String
                     , address: String
                     , tag: String = "审补库已下发"
                   )

  case class cgcsResult(
                         city_code: String
                         , zno_code: String
                         , address: String
                       )

  case class updataResult(
                           city_code: String
                           , zno_code: String
                           , address: String
                           , tag: String
                           , inc_day: String
                         )

  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error(s"获取数据源 incDay:${incDay}")
    //取数据源
    val dataRdd: RDD[JSONObject] = getDataDf(spark, incDay)


    logger.error("大网下发作业表")
    val cgcsDataRdd: RDD[(String, JSONObject)] = queryCgcsData(spark, incDay)

    logger.error("开始打标签")
    val checkRdd = checkTagData(dataRdd, cgcsDataRdd)
    logger.error("下发任务集")
    saveIssueTable(spark, checkRdd, incDay)
    logger.error("取审补库已下发的数据关联作业结果")
    val ReceiveDf = getReceiveData(spark, incDay)
    logger.error("调接口更新tag")
    val updateRdd = updateTag(ReceiveDf)
    logger.error("更新任务集中tag")
    updataTable(spark, updateRdd, incDay)
    logger.error("结束所有运行")

  }


  //获取签收表
  def queryCgcsData(spark: SparkSession, inc_day: String) = {

    val fromDay = DateUtil.getDateStr(inc_day, -30, "") //2021-08-24
    val sql =
      s"""
         |select
         |a.address
         |,b.check_aoi_id
         |,c.tccode as check_tc
         |from (
         |select
         |address
         |from dm_gis.cgcss_misclassification_data_shunt
         |where operate_date >= '${fromDay}' and operate_date <='${inc_day}'
         |group by address
         |) a
         |left join
         |(
         |select
         |check_aoi_id
         |,address
         |from
         |dm_gis.cghs_result_data
         |where inc_day >= '${fromDay}' and inc_day <='${inc_day}'
         |and source = 'chkn_WRONG_AOI_PN&norm_WRONG_AOI_SAME&norm_WRONG_AOI_PN'
         |group by check_aoi_id
         |,address
         |) b
         |on a.address = b.address
         |left join
         |(
         |select
         |aoi
         |,tccode
         |from dm_gis.tcAoi_relationship_init_new_di
         |group by
         |aoi
         |,tccode
         |)c
         |on b.check_aoi_id =c.aoi
      """.stripMargin
    logger.error(sql)
    val dataRdd = SparkUtils.getRowToJson(spark, sql).repartition(sqlpartition)
      .map(o => (JSONUtil.getJsonVal(o, "address", ""), o)).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
    logger.error("大网下发作业表总数量：" + dataRdd.count())
    dataRdd
  }

  //打标签
  def checkTagData(dataRdd: RDD[JSONObject], cgcsDataRdd: RDD[(String, JSONObject)]) = {

    logger.error("调删除接口审补库数据")
    val delRdd = dataRdd.coalesce(seg_partition).map(o => {
      //调删除接口审补库数据
      val city_code = JSONUtil.getJsonVal(o, "city_code", "")
      val address = JSONUtil.getJsonVal(o, "address", "")
      val delurl = String.format(sb_del_url, URLEncoder.encode(address, "utf-8"), city_code)
      val deReq = HttpClientUtil.getJsonByGet(delurl)
      o.put("deReq", deReq)
      //调容灾接口
      val rzurl = String.format(rz_url, city_code, URLEncoder.encode(address, "utf-8"))
      val rzReq = HttpClientUtil.getJsonByGet(rzurl, 3)
      var zno_code = ""
      if (rzReq != null) {
        val tcs = try {
          JSONUtil.getJsonArrayMulti(rzReq, "result.tcs").getJSONObject(0)
        } catch {
          case _ => new JSONObject()
        }
        zno_code = JSONUtil.getJsonVal(tcs, "dept", "")
      }
      o.put("zno_code", zno_code)
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("调完删除接口的数据量:" + delRdd.count())


    val reRdd = delRdd.map(o => (JSONUtil.getJsonVal(o, "address", ""), o)).leftOuterJoin(cgcsDataRdd)
      .map(o => {
        val left = o._2._1
        val right = o._2._2
        val address = JSONUtil.getJsonVal(left, "address", "")
        val city_code = JSONUtil.getJsonVal(left, "city_code", "")
        val zno_code = JSONUtil.getJsonVal(left, "zno_code", "")

        if (right.nonEmpty) {
          val rJson = right.get
          val check_aoi_id = JSONUtil.getJsonVal(rJson, "check_aoi_id", "")
          val check_tc = JSONUtil.getJsonVal(rJson, "check_tc", "")
          left.put("check_aoi_id", check_aoi_id)
          left.put("check_tc", check_tc)
          left.put("joinData", rJson)
          //调接口
          val daAddUrl = String.format(dw_add, URLEncoder.encode(address, "utf-8"), city_code, check_tc, check_aoi_id)
          val addReq = HttpClientUtil.getJsonByGet(daAddUrl)
          left.put("dwAddReq", addReq)
          left.put("tag", "dw_add")


        } else if (address.contains("快运")) {
          //删除接口 http://gis-int.int.sfdc.com.cn:1080/ky/his/del?ak=0376a9aa84724dd2a995f858dd963346&address=%s&cityCode=%s&showserver=true
          val delUrl = String.format(dw_del, URLEncoder.encode(address, "utf-8"), city_code)
          val delReq = HttpClientUtil.getJsonByGet(delUrl)
          left.put("dwDelReq", delReq)
          left.put("tag", "dw_del")
        } else if(zno_code.isEmpty){ left.put("tag","zno_codeEmpty")}
        else left.put("tag", "issue")
        left
      }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("跑完大网的数据量:" + reRdd.count())
    var unionRdd = reRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").nonEmpty)
    var nextRdd = reRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").isEmpty)
    logger.error("关联上大网下发作业表跟address是否包含【快运】的数据量:" + unionRdd.count())
    logger.error("下发任务集的数据量:" + nextRdd.count())
    reRdd
  }


  //入库
  def updataTable(spark: SparkSession, checkRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = checkRdd.map(_.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    val datailTableName = "dm_gis.kycuoke_task_to_cgcs_detail2" //生产数据表
    rowDf.repartition(sqlpartition).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(datailTableName)
    logger.error("入明细表完毕")

//    updataResult

    val saveDf = checkRdd.filter(o=>JSONUtil.getJsonVal(o,"tag","").equals("审补库已回收")).map(o=> {
      updataResult(
        JSONUtil.getJsonVal(o,"city_code","")
        ,JSONUtil.getJsonVal(o,"zno_code","")
        ,JSONUtil.getJsonVal(o,"address","")
        ,JSONUtil.getJsonVal(o,"tag","")
        ,JSONUtil.getJsonVal(o,"inc_day","")
      )
    } ).toDF("city_code","zno_code","address","tag","inc_day")

    saveDf.createOrReplaceTempView("updataTable")

    logger.error("审补库已回收数据量"+saveDf.count())




   val  updataSql =
     """
       |select
       |a.city_code
       |,a.zno_code
       |,a.address
       |,if(b.tag is not null,b.tag,a.tag) as tag
       |,a.inc_day
       |from dm_gis.kycuoke_task_to_cgcs a
       |left join
       |updataTable b
       |on a.city_code = b.city_code
       |and a.address = b.address
       |and a.zno_code = b.zno_code
       |and a.inc_day = b.inc_day
     """.stripMargin
    logger.error(updataSql)
   val updataRdd =  spark.sql(updataSql).repartition(200).write.mode(SaveMode.Overwrite).insertInto("dm_gis.kycuoke_task_to_cgcs")
    logger.error("更新完毕")
  }


  //存下发任务集
  def saveIssueTable(spark: SparkSession, checkRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    logger.error("存入明细表")
    val rowDf = checkRdd.map(_.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    val datailTableName = "dm_gis.kycuoke_task_to_cgcs_detail" //生产数据表
    rowDf.repartition(sqlpartition).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(datailTableName)
    logger.error("入明细表完毕")


    val staRdd = checkRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("issue"))
    logger.error("开始入下发任务集")
    val tableName = "dm_gis.kycuoke_task_to_cgcs"
    //入库错分表
    val reDf = staRdd.map(o => {
      result(
        JSONUtil.getJsonVal(o, "city_code", "")
        , JSONUtil.getJsonVal(o, "zno_code", "")
        , JSONUtil.getJsonVal(o, "address", "")
      )
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(s"入下发任务集数量:${tableName}:" + reDf.count())
    reDf.repartition(20).toDF().withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)



    logger.error("清除10天前的任务集数据")
    val incDay10 = DateUtil.getDateStr(incDay, -10, "") //2021-08-24
    val del = s"alter table ${tableName} drop if exists partition(inc_day = '${incDay10}') "
    logger.error(del)
    spark.sql(del)
    logger.error("清除完毕")


        val cgcsTable= "dm_gis.sxky_task_to_cgcs"
//    val cgcsTable = "dm_gis.sxky_task_to_cgcs_tmp"

    val fromDay = DateUtil.getDateStr(incDay, 3, "") //incDay 跑数时间t-2，保存到人工表时间t+1

    logger.error(s"推送人工任务进表:${cgcsTable}")
    val cgcsDf = staRdd.map(o => {
      cgcsResult(
        JSONUtil.getJsonVal(o, "city_code", "")
        , JSONUtil.getJsonVal(o, "zno_code", "")
        , JSONUtil.getJsonVal(o, "address", "")
      )
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("入下发任务集数量:" + cgcsDf.count())

    cgcsDf.repartition(20).toDF().withColumn("inc_day", lit(fromDay)).write.mode(SaveMode.Append).insertInto(cgcsTable)
    logger.error("推送完成")
  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {

    //    incDay:T-2
    //获取数据源
    val totalDfSql =
    """
      |select city_code,address from (
      |Select a.city_code, a.address
      |from
      |(
      |
      |        select
      |            regexp_replace(get_json_object(detail, '$.city_code'),'[\r\t]+','') city_code
      |            ,regexp_replace(get_json_object(detail, '$.address'),'[\r\n\0, \s, \.,\,,\t,\0022]+','') address
      |        from dm_gis.test_kuaiyun_detail_di
      |        where inc_day = '%s'
      |        and regexp_replace(get_json_object(detail, '$.wr_tag'),'[\r\t]+','') = 'rec_wr'
      |        and regexp_replace(get_json_object(detail, '$.tag'), '[\r\t]+', '') = 'recognition'
      |        and regexp_replace(get_json_object(detail, '$.src'), '[\r\t]+', '') = 'ADDRESSHIS'
      |		group by
      |		    regexp_replace(get_json_object(detail, '$.city_code'),'[\r\t]+','')
      |            ,regexp_replace(get_json_object(detail, '$.address'),'[\r\n\0, \s, \.,\,,\t,\0022]+','')
      |) a
      |left join
      |(
      |    select
      |	address
      |	,tag
      |    from dm_gis.kuaiyun_shenbu_clear
      |	group by
      |	address
      |	,tag
      |) b
      |on a.address = b.address
      |where (b.tag = '输出文件' or b.tag is null)
      |)a
      |group by city_code,address
    """.stripMargin
    val formatSql = String.format(totalDfSql, incDay)
    logger.error(formatSql)
    val totalRdd = SparkUtils.getRowToJson(spark, formatSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }


  //获取数据
  def getReceiveData(spark: SparkSession, incDay: String) = {
    val fomatDay = DateUtil.getDateStr(incDay, 1, "") //2021-08-24
    //    incDay:T-2
    //获取数据源
    val totalDfSql =
    s"""
       |select
       | a.city_code
       |,a.zno_code
       |,a.address
       |,a.tag
       |,b.check_aoi_id
       |,c.tccode as check_tc
       |,a.inc_day
       |from
       |dm_gis.kycuoke_task_to_cgcs a
       |inner join
       |(
       |select
       |city_code
       |,address
       |,check_aoi_id
       |from dm_gis.sxky_result_from_cgcs
       |where inc_day = '${fomatDay}'
       |group by
       |city_code
       |,check_aoi_id
       |,address
       |)b
       |on a.city_code = b.city_code
       |and a.address = b.address
       |left join
       |(
       |select
       |aoi
       |,tccode
       |from dm_gis.tcAoi_relationship_init_new_di
       |group by
       |aoi
       |,tccode
       |)c
       |on b.check_aoi_id =c.aoi
      """.stripMargin
    logger.error(totalDfSql)
    val totalRdd = SparkUtils.getRowToJson(spark, totalDfSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }


  def updateTag(staRdd: RDD[JSONObject]) = {

    val reRdd = staRdd.repartition(seg_partition).map(o => {

      val cityCode = JSONUtil.getJsonVal(o, "city_code", "")
      val address = JSONUtil.getJsonVal(o, "address", "")
      val check_aoi_id = JSONUtil.getJsonVal(o, "check_aoi_id", "")
      val check_tc = JSONUtil.getJsonVal(o, "check_tc", "")
      val tsRet = runMapXyInteface(ts_url, cityCode, address)
      val mapaRet = runMapXyInteface(rh_url, cityCode, address)
      o.put("tsBody", tsRet)
      o.put("mapaBody", mapaRet)
      val gdx = JSONUtil.getJsonVal(o, "tsBody.x", "")
      val gdy = JSONUtil.getJsonVal(o, "tsBody.y", "")
      val ts_pre = JSONUtil.getJsonVal(o, "tsBody.precision", "")
      val rhx = JSONUtil.getJsonVal(o, "mapaBody.x", "")
      val rhy = JSONUtil.getJsonVal(o, "mapaBody.y", "")
      val mapa_pre = JSONUtil.getJsonVal(o, "mapaBody.precision", "")

      val (ts_aoiid, tsret) = getAoi(gdx, gdy)
      val (mapa_aoiid, maparet) = getAoi(rhx, rhy)
      o.put("tsDeptBody", tsret)
      o.put("ts_aoiid", ts_aoiid)
      o.put("mapaDeptBody", maparet)
      o.put("mapa_aoiid", mapa_aoiid)
      o.put("ts_pre", ts_pre)
      o.put("mapa_pre", mapa_pre)

      if (check_aoi_id.nonEmpty && check_aoi_id.equals(mapa_aoiid) && mapa_aoiid.equals(ts_aoiid) && ts_pre == "2" && mapa_pre == "2") {
        //调接口
        val daAddUrl = String.format(dw_add, URLEncoder.encode(address, "utf-8"), cityCode, check_tc, check_aoi_id)
        val addReq = HttpClientUtil.getJsonByGet(daAddUrl)
        o.put("dwAddReq", addReq)
        o.put("tag", "审补库已回收")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("跑完接口后的数据量：" + reRdd.count())
    reRdd
  }


  //获取xy
  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          val errcode = xyObj.getJSONObject("result").getInteger("err")
          if (errcode == 109 || errcode == -106) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep((60 - second)*1000)
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          //          ret = new JSONObject()
          var status, x, y, precision, match_level = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getInteger("precision") != null) precision = result.getInteger("precision") + ""
            if (result.getInteger("match_level") != null) match_level = result.getInteger("match_level") + ""
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
          ret.put("match_level", match_level)
          ret.put("req", xyObj)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  def getAoi(x: String, y: String) = {
    val obj = new JSONObject()
    var aoiid = ""
    var reqObejct: JSONObject = null
    if (x.nonEmpty && y.nonEmpty) {

      reqObejct = HttpClientUtil.getJsonByGet(String.format(xyAoiUrl, x, y), 3)

      if (reqObejct != null) {
        //获取aoiid
        aoiid = try {
          reqObejct.getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id")
        }
        catch {
          case e: Exception => ""
        }

      }
    }
    (aoiid, reqObejct)
  }

}
