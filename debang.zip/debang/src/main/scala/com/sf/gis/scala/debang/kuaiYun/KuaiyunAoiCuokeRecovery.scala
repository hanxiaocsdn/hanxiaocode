package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.sx.constant.util.Utils
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil}
import com.sf.gis.scala.debang.util.{DateTimeUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01412406 on 2021/12/07
  * 时间确定
  */

object KuaiyunAoiCuokeRecovery {
  @transient lazy val logger: Logger = Logger.getLogger(KuaiyunAoiCuokeRecovery.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  //获取rhxy
  val rh_url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=1245f89114fb4f5e896213904b4923a5&opt=rh1&address=%s&city=%s"
  //容灾接口ur
  val rz_url = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?opt=zh&ak=dec044d089524419b371bc94555c539d&city=%s&address=%s"

  // 地址相似度接口
  val addressSimilarityUrl = "http://10.119.72.209:8080/rds_web/noControl/similar/%s/%s"
  //审补任务核实结果查询接口
  val chknUrl = "http://gis-aos-cgcs.sf-express.com/audit/api/exportQuery/chkn"
  //标准任务核实结果查询接口
  val normUrl = "http://gis-aos-cgcs.sf-express.com/audit/api/exportQuery/norm"

  //  跑ts接口url:  输入参数：opt=gd2& rh1, city, address
  val ts_url = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=1245f89114fb4f5e896213904b4923a5&opt=gd2&address=%s&city=%s"
  //  坐标落aoi接口url:   输入参数：x, y
  val xyAoiUrl = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?&ak=Dec044d089524419b371bc94555c539d&x=%s&y=%s&opt=aoi&geom=0"
  //GIS_CMS更新大组接口：
  val gis_cms_update = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId"
  //入库逻辑压入cms审补库
  val gis_cms_insert = "http://gis-cms-bg.sf-express.com/cms/api/address/rgsbAdd"


  case class result(
                     city: String
                     , address: String
                     , aoi: String
                   )


  case class cgcsResult(
                         normaddress: String,
                         tag: String,
                         inc_day: String
                       )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    logger.error("开始计算：" + startDay)
    startSta(spark, startDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String) = {
    logger.error(s"获取数据源 incDay:${incDay}")
    //取数据源
    val dataRdd: RDD[JSONObject] = getDataDf(spark, incDay)
    logger.error(dataRdd.take(10).foreach(println(_)))

    logger.error("开始打标签")
    val checkRdd = checkTagData(dataRdd, incDay)

    logger.error("开始入库")
    //入库
    saveTable(spark, checkRdd, incDay)

    logger.error("结束所有运行")

  }


  //打标签
  def checkTagData(dataRdd: RDD[JSONObject], incDay: String) = {

    val staRdd = dataRdd.coalesce(seg_partition).map(o => {
      val incDayT = DateTimeUtil.getConvertFormatDate(incDay, "yyyyMMdd", "yyyy-MM-dd")
      val tag = JSONUtil.getJsonVal(o, "tag", "")
      val cityCode = JSONUtil.getJsonVal(o, "citycode", "")
      val chknAddress = JSONUtil.getJsonVal(o, "chknaddress", "")
      var resJsonString = "{}"

      val param = new JSONObject()
      param.put("cityCode", cityCode)
      val arr = new JSONArray()
      arr.add("KY")
      param.put("staTypes", arr)
      param.put("beginDate", incDayT + " 00:00:00")
      param.put("endDate", incDayT + " 23:59:59")
      //     param.put("beginDate","2021-12-30"+" 00:00:00")
      //      param.put("endDate","2022-01-05"+" 23:59:59")
      param.put("pageNo", 1)
      param.put("pageSize", 5000)
      //取仓管核实结果
      if ("bz".equals(tag))
        resJsonString = SparkUtils.doPost(normUrl, param, logger)
      else
        resJsonString = SparkUtils.doPost(chknUrl, param, logger)

      //      o.put("resJsonString", resJsonString.replaceAll("[\\r\\n\\t]", ""))

      val resJsonArr = try {
        JSON.parseObject(resJsonString).getJSONObject("data").getJSONArray("result")
      } catch {
        case _ => new JSONArray()
      }

      o.put("resultArray", resJsonArr)


      for (i <- 0 until resJsonArr.size()) {
        val reObject = resJsonArr.getJSONObject(i)
        val address = JSONUtil.getJsonVal(reObject, "address", "")
        o.put(s"address_${i}_${address}_chknAddress${chknAddress}", reObject.toJSONString)
        if (address.equals(chknAddress)) o.put("verifyReq", reObject.toJSONString)
      }


      //      for (i <- resJsonArr.toArray) {
      //        val resJson = try {
      //          i.asInstanceOf[JSONObject]
      //        } catch {
      //          case _ => new JSONObject()
      //        }
      //        val address = JSONUtil.getJsonVal(resJson, "address", "")
      //
      //
      ////        val checkDate = try {
      ////          JSONUtil.getJsonVal(resJson, "checkDate", "").substring(0, 10).replaceAll("-", "")
      ////        } catch {
      ////          case _ => ""
      ////        }
      //        //        && checkDate.equals(incDay)
      //
      //
      //
      //        if (address.equals(chknAddress)) o.put("verifyReq", resJson)
      //      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("调取核实结果的数量" + staRdd.count())
    logger.error(staRdd.take(2).foreach(println(_)))


    val bzRdd = staRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("bz"))
    val sbRdd = staRdd.filter(o => JSONUtil.getJsonVal(o, "tag", "").equals("sb"))

    logger.error("标准核实的数据量" + bzRdd.count())
    logger.error("柯错分审补的数据量" + sbRdd.count())

    val bzResRdd = bzhs(bzRdd)
    val sbResRdd = sbhs(sbRdd)

    val totalRdd = bzResRdd.union(sbResRdd).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("处理完总数据量：" + totalRdd.count())
    totalRdd

  }

  //入库
  def saveTable(spark: SparkSession, checkRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = checkRdd.map(_.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    val datailTableName = "dm_gis.ky_address_remove_detail" //生产数据表
    rowDf.repartition(sqlpartition).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(datailTableName)
    logger.error("入明细表完毕")


    logger.error("开始推送到剔除配置表")
    val tableName = "dm_gis.ky_address_remove_conf"
    val reDf = checkRdd.filter(o => JSONUtil.getJsonVal(o, "tag1", "").equals("savetable")
    ).map(o => {
      result(
        JSONUtil.getJsonVal(o, "citycode", "")
        , JSONUtil.getJsonVal(o, "chknaddress", "")
        , JSONUtil.getJsonVal(o, "aoiid", "")
      )
    }).persist(StorageLevel.MEMORY_AND_DISK).toDF("city", "address", "aoi")
    logger.error(reDf.show(2))
    reDf.createOrReplaceTempView("ky_address_remove_conf_new")

    //更新配置表
    val updataSql =
      """
        |select
        |city
        |,address
        |,aoi
        |from (
        |select
        |a.city
        |,a.address
        |,a.aoi
        |from dm_gis.ky_address_remove_conf a
        |left join
        |ky_address_remove_conf_new b
        |on a.address = b.address
        |where b.address is null
        |union all
        |select
        |city
        |,address
        |,aoi
        |from ky_address_remove_conf_new
        |)a
        |group by
        |city
        |,address
        |,aoi
      """.stripMargin
    logger.error(updataSql)
    val updataDf = spark.sql(updataSql)
    val reUpdataDf = spark.createDataFrame(updataDf.rdd, updataDf.schema).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("推送到剔除配置表:" + reUpdataDf.count())
    reUpdataDf.write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("推送到剔除配置表完毕")


    //更新kycuokeaoi_task_to_cgcs的tag

    logger.error("更新cgcs表的tag")
    val sbDf = checkRdd.filter(o =>
      JSONUtil.getJsonVal(o, "tag", "").equals("sb已回收")).map(o => {
      cgcsResult(
        JSONUtil.getJsonVal(o, "chknaddress", "")
        , JSONUtil.getJsonVal(o, "tag", "")
        , JSONUtil.getJsonVal(o, "inc_day", "")
      )
    }).toDF("chknaddress", "tag", "inc_day").createOrReplaceTempView("sbtmp")


    val bzDf = checkRdd.filter(o => {
      JSONUtil.getJsonVal(o, "tag", "").equals("bz已回收")
    }).map(o => {
      cgcsResult(
        JSONUtil.getJsonVal(o, "chknaddress", "")
        , JSONUtil.getJsonVal(o, "tag", "")
        , JSONUtil.getJsonVal(o, "inc_day", "")
      )
    }).toDF("chknaddress", "tag", "inc_day").createOrReplaceTempView("bztmp")


    val sbUpdateSql =
      """
        |select
        | a.citycode
        |,a.normaddress
        |,a.groupid
        |,a.normznocode
        |,a.chknaddress
        |,a.aoiid
        |,a.chknznocode
        |,a.filter
        |,a.adcode
        |,a.splitresult
        |,if(b.tag is not null,b.tag,a.tag) as tag
        |,a.tasksource
        |,a.inc_day
        |from dm_gis.kycuokeaoi_task_to_cgcs a
        |left join sbtmp b
        |on a.inc_day = b.inc_day
        |and a.chknaddress = b.chknaddress
        |where  a.tag = 'sb'
        |union all
        |select
        | a.citycode
        |,a.normaddress
        |,a.groupid
        |,a.normznocode
        |,a.chknaddress
        |,a.aoiid
        |,a.chknznocode
        |,a.filter
        |,a.adcode
        |,a.splitresult
        |,if(b.tag is not null,b.tag,a.tag) as tag
        |,a.tasksource
        |,a.inc_day
        |from dm_gis.kycuokeaoi_task_to_cgcs a
        |left join bztmp b
        |on a.inc_day = b.inc_day
        |and a.chknaddress = b.chknaddress
        |where  a.tag = 'bz'
        |union all
        |select
        |*
        |from dm_gis.kycuokeaoi_task_to_cgcs
        |where   tag not in ('bz','sb')
      """.stripMargin

    val cgcsUpdataDf: DataFrame = spark.sql(sbUpdateSql)
    logger.error(s"更新后结果的数据量：" + cgcsUpdataDf.count())
    cgcsUpdataDf.repartition(10).write.mode(SaveMode.Overwrite).insertInto("dm_gis.kycuokeaoi_task_to_cgcs")
    logger.error("dm_gis.kycuokeaoi_task_to_cgcs更新完毕")

  }




  //获取数据
  def getDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源
    val totalDfSql =
      """
        |select
        |*
        |from
        |dm_gis.kycuokeaoi_task_to_cgcs
        |where  tag = 'sb' or tag='bz'
      """.stripMargin
    logger.error(totalDfSql)
    val totalRdd = SparkUtils.getRowToJson(spark, totalDfSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }

  //错分标准核实结果处理
  def bzhs(staRdd: RDD[JSONObject]) = {

    val value = staRdd.filter(o => {
      JSONUtil.getJsonVal(o, "verifyReq", "").nonEmpty
    })
    logger.error("关联上的数据量" + value.count())


    val updateRdd = staRdd.map(o => {
      val isSamePlace = JSONUtil.getJsonVal(o, "verifyReq.isSamePlace", "")
      val checkAoiId = JSONUtil.getJsonVal(o, "verifyReq.checkAoiId", "")
      val checkDataType = JSONUtil.getJsonVal(o, "verifyReq.checkDataType", "")
      val aoiid = JSONUtil.getJsonVal(o, "aoiid", "")
      var reobj = o
      if (isSamePlace.equals("1")) {
        if (checkAoiId.nonEmpty && checkAoiId.equals(aoiid)) reobj.put("tag1", "savetable")
        else if (checkDataType.equals("1") || (checkDataType.equals("2"))) reobj = runMapDeptNotPrecision(reobj)
      } else reobj.put("tag1", "tc")
      reobj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("处理完标准核实结果的数据量" + updateRdd.count())
    logger.error(updateRdd.take(2).foreach(println(_)))

    val reRdd = updateRdd.coalesce(seg_partition).map(o => {
      val tag1 = JSONUtil.getJsonVal(o, "tag1", "")
      val checkAoiId = JSONUtil.getJsonVal(o, "verifyReq.checkAoiId", "")
      val cityCode = JSONUtil.getJsonVal(o, "citycode", "")
      val groupId = JSONUtil.getJsonVal(o, "groupid", "")
      //更新大组接口
      if (tag1.equals("update")) {
        val param = new JSONObject()
        param.put("cityCode", cityCode)
        param.put("aoiId", checkAoiId)
        param.put("addressId", groupId)
        param.put("operSource", "KY")
        param.put("operUserName", "01412995")
        param.put("aoiSource", "S95")
        //生产
        val reReq = SparkUtils.doPost(gis_cms_update, param, logger)
        o.put("gis_cms_update", reReq)
        val gis_cms_updateTag = JSONUtil.getJsonVal(o, "gis_cms_update", "")
        if (gis_cms_updateTag.nonEmpty) o.put("tag", "bz已回收")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("更新完数据量 " + reRdd.count())
    logger.error("更新大组接口的数据量" + reRdd.filter(o => JSONUtil.getJsonVal(o, "tag1", "").equals("update")).count())
    logger.error(reRdd.take(2).foreach(println(_)))

    reRdd
  }

  //错分审补核实结果处理
  def sbhs(staRdd: RDD[JSONObject]) = {
    val updateRdd = staRdd.map(o => {
      val checkAoiId = JSONUtil.getJsonVal(o, "verifyReq.checkAoiId", "")
      val checkDataType = JSONUtil.getJsonVal(o, "verifyReq.checkDataType", "")
      val aoiid = JSONUtil.getJsonVal(o, "aoiid", "")

      if (checkAoiId.nonEmpty && checkAoiId.equals(aoiid)) o.put("tag1", "savetable")
      else if (checkDataType.equals("1") || (checkDataType.equals("2"))) o.put("tag1", "cms")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("处理完错分审补核实结果的数据量" + updateRdd.count())
    logger.error("错分审补核实结果的数据量" + updateRdd.filter(o => JSONUtil.getJsonVal(o, "tag1", "").equals("cms")).count())
    logger.error(updateRdd.take(2).foreach(println(_)))


    val reRdd = updateRdd.coalesce(seg_partition).map(o => {
      val tag1 = JSONUtil.getJsonVal(o, "tag1", "")
      val checkAoiId = JSONUtil.getJsonVal(o, "verifyReq.checkAoiId", "")
      val cityCode = JSONUtil.getJsonVal(o, "citycode", "")
      val address = JSONUtil.getJsonVal(o, "chknaddress", "")
      val checkDeptCode = JSONUtil.getJsonVal(o, "verifyReq.checkDeptCode", "")
      //更新大组接口
      if (tag1.equals("cms")) {
        val param = new JSONObject()
        param.put("operSource", "KY")
        param.put("ak", "3a191e7427e8470c86271a069411c66b")
        param.put("operUserName", "01412995")
        val addressSave = new JSONObject()
        addressSave.put("cityCode", cityCode)
        addressSave.put("src", 0)
        addressSave.put("address", address)
        addressSave.put("znoCode", checkDeptCode)
        addressSave.put("aoiId", checkAoiId)
        param.put("addressSave", addressSave)
        param.put("aoiSource", "S95")
        //生产
        val reReq = SparkUtils.doPost(gis_cms_insert, param, logger)
        o.put("gis_cms_insert", reReq)
        val gis_cms_insertTag = JSONUtil.getJsonVal(o, "gis_cms_insert", "")
        if (gis_cms_insertTag.nonEmpty) o.put("tag", "sb已回收")
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("压入cms审补库后的数据量" + reRdd.count())
    logger.error(reRdd.take(2).foreach(println(_)))
    reRdd
  }


  //获取xy
  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          val errcode = xyObj.getJSONObject("result").getInteger("err")
          if (errcode == 109 || errcode == -106) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          //          ret = new JSONObject()
          var status, x, y, precision, match_level = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getInteger("precision") != null) precision = result.getInteger("precision") + ""
            if (result.getInteger("match_level") != null) match_level = result.getInteger("match_level") + ""
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
          ret.put("match_level", match_level)
          ret.put("req", xyObj)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }


  //坐标跑网点
  def runMapDeptNotPrecision(obj: JSONObject): JSONObject = {
    val cityCode = JSONUtil.getJsonVal(obj, "cityCode", "")
    val address = JSONUtil.getJsonVal(obj, "chknaddress", "")
    val normAddress = JSONUtil.getJsonVal(obj, "normAddress", "")
    val checkAoiId = JSONUtil.getJsonVal(obj, "verifyReq.checkAoiId", "")
    val checkAoiName = JSONUtil.getJsonVal(obj, "verifyReq.checkAoiName", "")
    val tsRet = runMapXyInteface(ts_url, cityCode, address)
    val mapaRet = runMapXyInteface(rh_url, cityCode, address)
    obj.put("tsBody", tsRet)
    obj.put("mapaBody", mapaRet)
    val gdx = JSONUtil.getJsonVal(obj, "tsBody.x", "")
    val gdy = JSONUtil.getJsonVal(obj, "tsBody.y", "")
    val ts_pre = JSONUtil.getJsonVal(obj, "gdBody.precision", "")
    val rhx = JSONUtil.getJsonVal(obj, "mapaBody.x", "")
    val rhy = JSONUtil.getJsonVal(obj, "mapaBody.y", "")
    val mapa_pre = JSONUtil.getJsonVal(obj, "mapaBody.precision", "")

    val (ts_aoiid, tsret) = getAoi(gdx, gdy)
    val (mapa_aoiid, maparet) = getAoi(rhx, rhy)
    obj.put("tsDeptBody", tsret)
    obj.put("ts_aoiid", ts_aoiid)
    obj.put("mapaDeptBody", maparet)
    obj.put("mapa_aoiid", mapa_aoiid)
    obj.put("ts_pre", ts_pre)
    obj.put("mapa_pre", mapa_pre)

    //更新CMS大组AOI
    if (ts_aoiid.nonEmpty && ts_aoiid.equals(mapa_aoiid) && mapa_aoiid.equals(checkAoiId) && mapa_pre.equals("2") && ts_pre.equals("2")) obj.put("tag1", "update")
    else if (checkAoiId.nonEmpty && ts_aoiid.equals(checkAoiId)) {
      //跑容灾
      val url = String.format(rz_url, cityCode, address)
      val tc: JSONObject = HttpClientUtil.getJsonByGet(url, 3)
      var keyWord = ""
      if (tc != null) {
        val tcs = try {
          JSONUtil.getJsonArrayMulti(tc, "result.tcs").getJSONObject(0)
        } catch {
          case _ => new JSONObject()
        }
        keyWord = JSONUtil.getJsonVal(tcs, "keyWord", "")
      }
      obj.put("rzReq", tc.toJSONString)
      obj.put("keyWord", keyWord)

      //判断相似度
      val SimilarityUrl = String.format(addressSimilarityUrl, URLEncoder.encode(keyWord, "UTF-8"), URLEncoder.encode(checkAoiName, "UTF-8"))
      val similarStaRes = Utils.retryGet(SimilarityUrl)
      val SimilarityUrl2 = String.format(addressSimilarityUrl, URLEncoder.encode(normAddress, "UTF-8"), URLEncoder.encode(checkAoiName, "UTF-8"))
      val similarStaRes2 = Utils.retryGet(SimilarityUrl2)
      if (similarStaRes.nonEmpty && similarStaRes.toDouble >= 1 && !address.matches(".*(对面|左边|右边|向东|向西)")) obj.put("tag1", "update")
      else if (similarStaRes2.nonEmpty && similarStaRes2.toDouble >= 0.7 && !address.matches(".*(对面|左边|右边|向东|向西)")) obj.put("tag1", "update")
    }
    obj
  }


  def getAoi(x: String, y: String) = {
    val obj = new JSONObject()
    var aoiid = ""
    var reqObejct: JSONObject = null
    if (x.nonEmpty && y.nonEmpty) {

      reqObejct = HttpClientUtil.getJsonByGet(String.format(xyAoiUrl, x, y), 3)

      if (reqObejct != null) {
        //获取aoiid
        aoiid = try {
          reqObejct.getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id")
        }
        catch {
          case e: Exception => ""
        }

      }
    }
    (aoiid, reqObejct)
  }


}
