package com.sf.gis.scala.debang.kuaiYun

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.debang.util._
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object KuaiyunDispatchConsistency {
  @transient lazy val logger: Logger = Logger.getLogger(KuaiyunDispatchConsistency.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200

  case class result(
                     waybillno: String
                     , citycode: String
                     , city: String
                     , province: String
                     , isclimb: String
                     , review_status: String
                     , log: String
                     , message: String
                     , waybill_no_monitor3: String
                     , ky_climb: String
                   )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    logger.error("起始时间:" + startDay + ",时间跨度:" + days)
    start(startDay, days)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String, days: Int): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")


    val formatDay = DateUtil.getDateStr(startDay, -7, "") //2021-08-22


    //        for (i <- 0 until days) {


    logger.error("开始计算：" + startDay + "&&formatDay:" + formatDay)
    startSta(spark, startDay, formatDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String, formatDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataRdd = getDataDf(spark, incDay, formatDay)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("开始判断")
    val saveRdd = analysisRdd(dataRdd)
    logger.error("中间表开始入库")
    //入库
    saveTable(spark, saveRdd, incDay)
    logger.error("中间表入库完毕")
    logger.error("开始计算指标")
    runAnalysisDataDf(spark, incDay)
    logger.error("结束所有运行")

  }


  //入库
  def saveTable(spark: SparkSession, saveRdd: RDD[result], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = saveRdd.toDF()


    logger.error("入明细表数量：" + rowDf.count())


    val tableName = "dm_gis.adds_log_kafka_elev_consistency_tmp" //生产数据表

    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)


    //    rowDf.write.mode(SaveMode.Overwrite).partitionBy( "inc_day").saveAsTable(tableName)

  }

  //获取数据
  def getDataDf(spark: SparkSession, incDay: String, formatDay: String) = {
    //获取数据源
    val totalDfSql =
      s"""
         |select
         | a.waybillno
         |,a.citycode
         |,c.province
         |,c.city
         |,a.isclimb
         |,b.review_status
         |,a.log
         |,a.message
         |,b.waybill_no as waybill_no_monitor3
         |from
         |dm_gis.adds_log_kafka_elev_analysis a
         |left join(
         |select
         | waybill_no
         |,review_status
         |from dm_heavy_cargo.ky_gdl_pack_waybillno_monitor3
         |where inc_day between '${formatDay}' and '${incDay}'
         |) b
         |on a.waybillno = b.waybill_no
         |--取地区维度
         |left join
         |(
         | select max(city) as city ,citycode,max(province) as province
         | from dm_gis.address_info_map_di
         | group by citycode
         |)c
         |on a.citycode = c.citycode
         |where a.ak = 'a4f3c06085e64df18d1aedfa4dcebe35' and a.type='url_e' and a.isclimb in ('0','1') and a.inc_day = '${incDay}'
      """.stripMargin


    logger.error(totalDfSql)
    val totalRdd = SparkUtils.getRowToJson(spark, totalDfSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error(totalRdd.take(10).foreach(println(_)))
    totalRdd
  }


  //日志解析
  def analysisRdd(dataRdd: RDD[JSONObject]) = {

    logger.error("判断的数据量" + dataRdd.count())


    val finalRdd = dataRdd.map(obj => {


      var waybillno = ""
      var citycode = ""
      var province = ""
      var city = ""
      var isclimb = ""
      var review_status = ""
      var log = ""
      var message = ""
      var waybill_no_monitor3 = ""
      var ky_climb = ""


      var waybillNoMonitor3 = JSONUtil.getJsonVal(obj, "waybill_no_monitor3", "")
      review_status = JSONUtil.getJsonVal(obj, "review_status", "")


      if (waybillNoMonitor3.isEmpty) obj.put("ky_climb", "404")
      else if (review_status.equals("已审批")) {
        if (review_status.equals("通过")) obj.put("ky_climb", "1") else obj.put("ky_climb", "0")
      }
      else obj.put("ky_climb", "-1")

      waybillno = JSONUtil.getJsonVal(obj, "waybillno", "")
      citycode = JSONUtil.getJsonVal(obj, "citycode", "")
      province = JSONUtil.getJsonVal(obj, "province", "")
      city = JSONUtil.getJsonVal(obj, "city", "")
      isclimb = JSONUtil.getJsonVal(obj, "isclimb", "")
      message = JSONUtil.getJsonVal(obj, "message", "")
      waybill_no_monitor3 = JSONUtil.getJsonVal(obj, "waybill_no_monitor3", "")
      log = JSONUtil.getJsonVal(obj, "log", "")
      ky_climb = JSONUtil.getJsonVal(obj, "ky_climb", "")


      result(
        waybillno
        , citycode
        , city
        , province
        , isclimb
        , review_status
        , log
        , message
        , waybill_no_monitor3
        , ky_climb
      )

    }).persist(StorageLevel.MEMORY_AND_DISK)
    finalRdd.take(10).foreach(obj => {
      logger.error(println(obj))
    })
    finalRdd
  }


  //根据解析表计算指标
  def runAnalysisDataDf(spark: SparkSession, incDay: String) = {
    //获取数据源

    //dm_gis.adds_log_kafka_elev_consistency_tmp

    //汇总统计
    val resql =
      s"""
         |select
         | province
         |,citycode
         |,city
         |,count(*) as climb_cnt
         |,sum(if(ky_climb <> '404',1,0))  				as success_cnt
         |,sum(if(ky_climb = '404',1,0))  				as fail_cnt
         |,sum(if(ky_climb not in ('-1','404') ,1,0))  	as ky_cnt
         |,sum(if(ky_climb = '-1',1,0))  					as no_ky_cnt
         |,sum(if(isclimb = '1',1,0))						as is_climb_cnt
         |,sum(if(isclimb = '1' and ky_climb = '1',1,0)) as is_climb_ky_cnt
         |,sum(if(isclimb = '1' and ky_climb = '0',1,0)) as is_climb_not_ky_cnt
         |,sum(if(isclimb = '0',1,0))						as not_climb_cnt
         |,sum(if(isclimb = '0' and ky_climb = '0',1,0))  as not_climb_not_ky_cnt
         |,sum(if(isclimb = '0' and ky_climb = '1',1,0))	as not_climb_ky_cnt
         |from dm_gis.adds_log_kafka_elev_consistency_tmp where inc_day = '${incDay}'
         |group by
         | province
         |,citycode
         |,city
         |union all
         |select
         | 'ALL' as province
         |,'ALL' as citycode
         |,'ALL' as city
         |,count(*) as climb_cnt
         |,sum(if(ky_climb <> '404',1,0))  				as success_cnt
         |,sum(if(ky_climb = '404',1,0))  				as fail_cnt
         |,sum(if(ky_climb not in ('-1','404') ,1,0))  	as ky_cnt
         |,sum(if(ky_climb = '-1',1,0))  					as no_ky_cnt
         |,sum(if(isclimb = '1',1,0))						as is_climb_cnt
         |,sum(if(isclimb = '1' and ky_climb = '1',1,0)) as is_climb_ky_cnt
         |,sum(if(isclimb = '1' and ky_climb = '0',1,0)) as is_climb_not_ky_cnt
         |,sum(if(isclimb = '0',1,0))						as not_climb_cnt
         |,sum(if(isclimb = '0' and ky_climb = '0',1,0))  as not_climb_not_ky_cnt
         |,sum(if(isclimb = '0' and ky_climb = '1',1,0))	as not_climb_ky_cnt
         |from dm_gis.adds_log_kafka_elev_consistency_tmp where inc_day = '${incDay}'
         |union all
         |select
         | province
         |,'ALL' as citycode
         |,'ALL' as city
         |,count(*) as climb_cnt
         |,sum(if(ky_climb <> '404',1,0))  				as success_cnt
         |,sum(if(ky_climb = '404',1,0))  				as fail_cnt
         |,sum(if(ky_climb not in ('-1','404') ,1,0))  	as ky_cnt
         |,sum(if(ky_climb = '-1',1,0))  					as no_ky_cnt
         |,sum(if(isclimb = '1',1,0))						as is_climb_cnt
         |,sum(if(isclimb = '1' and ky_climb = '1',1,0)) as is_climb_ky_cnt
         |,sum(if(isclimb = '1' and ky_climb = '0',1,0)) as is_climb_not_ky_cnt
         |,sum(if(isclimb = '0',1,0))						as not_climb_cnt
         |,sum(if(isclimb = '0' and ky_climb = '0',1,0))  as not_climb_not_ky_cnt
         |,sum(if(isclimb = '0' and ky_climb = '1',1,0))	as not_climb_ky_cnt
         |from dm_gis.adds_log_kafka_elev_consistency_tmp where inc_day = '${incDay}'
         |group by
         |province
      """.stripMargin

    logger.error(resql)
    val resDf = spark.sql(resql).repartition(200).persist(StorageLevel.MEMORY_AND_DISK)


    resDf.show(10, true)
    logger.error("汇总表入库数据量：" + resDf.count())
    //入库
    val tableName = "dm_gis.adds_log_kafka_elev_consistency" //生产数据表
    logger.error("汇总表入库：" + tableName + "分区:" + incDay)
    resDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)
    logger.error("入库完毕")

  }


}
