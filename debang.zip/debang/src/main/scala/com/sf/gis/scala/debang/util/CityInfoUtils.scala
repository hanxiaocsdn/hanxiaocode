package com.sf.gis.scala.debang.util

import com.alibaba.fastjson.JSONObject
import com.csvreader.CsvReader
import com.sf.gis.java.sx.constant.util.JavaUtil
import org.apache.log4j.Logger

import scala.collection.mutable.ArrayBuffer

object CityInfoUtils {
  @transient lazy val logger: Logger = Logger.getLogger(CityInfoUtils.getClass)

  def main(args: Array[String]): Unit = {
  }
  def loadAdcodeCityCodemap(): Map[String, String] ={
    val adcodeCityCodeFileName = System.getProperty("user.dir")+"/t_deppon_code_relation_list.csv"
    var adcodeCityMap: Map[String, String] = Map()
    //    val adcodeCityCodeFilePath = this.getClass.getClassLoader.getResource(adcodeCityCodeFileName).getPath

    logger.error(System.getProperty("user.dir"))
    val csvReader = new CsvReader(adcodeCityCodeFileName)
    csvReader.setSafetySwitch(false)
    if (csvReader.readRecord()) logger.error("headers:" + csvReader.getValues.mkString(","))
    while (csvReader.readRecord()) {
      val row = csvReader.getValues
      val adcode = row(0)
      val req_city = row(1)
      if(!adcode.isEmpty)
        adcodeCityMap += (adcode -> req_city)
    }
    logger.error("数量:" + adcodeCityMap.size)
    adcodeCityMap
  }
  def getCityMap(javaUtil:JavaUtil): Map[String, ArrayBuffer[Array[String]]] = {
    logger.error(">>>javaUtil：" + javaUtil.getFlag)
    //val conn = DbUtils.getConnection(javaUtil)
    val conn = DbUtils.getConnectionNew
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("region", "city", "citycode", "adcode","area")
    val regionSelectSql = s"select region,city,citycode,adcode,area from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val citycode = arr(2).toString
      if (cityMap.contains(citycode)) {
        val cityCodeList = cityMap.apply(citycode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (citycode -> cityCodeList)
      }
    }
    cityMap
  }
  def getAdcodeMap(javaUtil: JavaUtil): Map[String, ArrayBuffer[Array[String]]] = {
    logger.error(">>>javaUtil：" + javaUtil.getFlag)
    val conn = DbUtils.getConnection(javaUtil)
    val regoinCityTable = "ADMIN_AREA"
    val columns = Array("region", "city", "citycode", "adcode")
    val regionSelectSql = s"select region,city,citycode,adcode from $regoinCityTable"
    logger.error(">>>regionSelectSql:" + regionSelectSql)
    val regions: ArrayBuffer[Array[String]] = DbUtils.selectColumns(conn, regionSelectSql, columns)
    //    for(arr <- regions)println(arr.mkString(","))
    var cityMap: Map[String, ArrayBuffer[Array[String]]] = Map()
    for (arr <- regions) {
      val adcode = arr(3).toString
      if (cityMap.contains(adcode)) {
        val cityCodeList = cityMap.apply(adcode)
        cityCodeList += arr
      } else {
        val cityCodeList = new ArrayBuffer[Array[String]]()
        cityCodeList += arr
        cityMap += (adcode -> cityCodeList)
      }
    }
    cityMap
  }
  def matchAdcode(jObj: JSONObject, cityMap: Map[String, ArrayBuffer[Array[String]]]): Boolean = {
    val adcode = jObj.getString("adcode")
    var cityCode = "0"
    var city = "0"
    var region = "0"
    var flag = false
    if (cityMap.contains(adcode)) {
      flag = true
      val cityInfo = cityMap.apply(adcode)(0)
      region = cityInfo.apply(0)
      city = cityInfo.apply(1)
      cityCode = cityInfo.apply(2)
    }
    jObj.put("city", city)
    jObj.put("cityCode", cityCode)
    jObj.put("region", region)
    flag
  }
  def matchCityCode(jObj: JSONObject, addresseeAddr: String,
                    destCityCode: String,
                    cityMap: Map[String, ArrayBuffer[Array[String]]]): Boolean = {
    val cityCode = destCityCode
    var city = "0"
    var region = "0"
    var area = "0"
    var flag = false
    if (cityMap.contains(cityCode)) {
      flag = true
      val cityList: ArrayBuffer[Array[String]] = cityMap.apply(cityCode)
      if (cityList.length == 1) {
        //如果只有一个list，一一对应的，直接返回
        city = cityList(0)(1)
        region = cityList(0)(0)
        area = cityList(0)(4)
      } else if (cityList.length > 1) {
        //一个城市代码对应多个城市名
        region = cityList(0)(0)
        area = cityList(0)(4)
        for (cityObj <- cityList) {
          val tmpCity = cityObj(1)
          val tmpCity1 = tmpCity.substring(0, tmpCity.length - 1) //有的地址里面没有‘市’这个字样，要去掉识别
          if (addresseeAddr != null && (addresseeAddr.contains(tmpCity) || addresseeAddr.contains(tmpCity1))) {
            city = cityObj(1)
          }
        }
      }
    }
    jObj.put("city", city)
    jObj.put("cityCode", cityCode)
    jObj.put("region", region)
    jObj.put("area",area)
    flag
  }
}
