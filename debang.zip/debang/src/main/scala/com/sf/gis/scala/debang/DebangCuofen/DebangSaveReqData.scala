package com.sf.gis.scala.debang.DebangCuofen

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.ShellExcutor
import com.sf.gis.java.sx.constant.util.JavaUtil
import com.sf.gis.scala.base.spark.Spark
import com.sf.gis.scala.base.util.{DateUtil, JSONUtil, StringUtils}
import com.sf.gis.scala.debang.util.CityInfoUtils
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * Created by 01374443 on 2019/3/5.
 * 任务id:157
 * 任务名称：德邦请求数据明细
 */
object DebangSaveReqData {
  @transient lazy val logger: Logger = Logger.getLogger(DebangSaveReqData.getClass)

  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val debangHiveTable = "dm_gis.debang_log_flink_collect"
  val debangReqStdTable = "dm_gis.debang_req_std"
  val javaUtil = new JavaUtil(6)

  def main(args: Array[String]): Unit = {
    //    val log = "{\"syn\":false,\"createTime\":\"2020-08-28 08:06:20.225\",\"level\":\"HDFS\",\"message\":\"{\\\"request\\\":\\\"{\\\\\\\"createTime\\\\\\\":1598573180115,\\\\\\\"ak\\\\\\\":\\\\\\\"d5653f4efbb4450ba8589a300456b80e\\\\\\\",\\\\\\\"remoteIp\\\\\\\":\\\\\\\"180.153.16.2\\\\\\\",\\\\\\\"url\\\\\\\":\\\\\\\"http://nginxwa/eds/api/deppon?ak=d5653f4efbb4450ba8589a300456b80e&citycode=411500&address=%25E6%25B2%25B3%25E5%258D%2597%25E7%259C%2581%25E4%25BF%25A1%25E9%2598%25B3%25E5%25B8%2582%25E6%25B5%2589%25E6%25B2%25B3%25E5%258C%25BA%25E4%25BA%2594%25E9%2587%258C%25E5%25A2%25A9%25E8%25A1%2597%25E9%2581%2593%25E6%25B2%25B3%25E5%258D%2597%25E4%25BF%25A1%25E9%2598%25B3%25E5%25B8%2582%25E6%25B5%2589%25E6%25B2%25B3%25E5%258C%25BA%25E5%259F%258E%25E5%258C%25BA%25E5%2585%25AB%25E4%25B8%2580%25E8%25B7%25AF252%25E5%258F%25B789%25E6%25A0%258B&sn=8110620473\\\\\\\",\\\\\\\"address\\\\\\\":\\\\\\\"河南省信阳市浉河区五里墩街道河南信阳市浉河区城区八一路252号89栋\\\\\\\",\\\\\\\"citycode\\\\\\\":\\\\\\\"411500\\\\\\\",\\\\\\\"sn\\\\\\\":\\\\\\\"8110620473\\\\\\\",\\\\\\\"opt\\\\\\\":\\\\\\\"ZH\\\\\\\"}\\\",\\\"requestId\\\":\\\"0124972020082808062011520383_8110620473\\\",\\\"response\\\":\\\"{\\\\\\\"query\\\\\\\":{\\\\\\\"address\\\\\\\":\\\\\\\"河南省信阳市浉河区五里墩街道河南信阳市浉河区城区八一路252号89栋\\\\\\\",\\\\\\\"citycode\\\\\\\":\\\\\\\"411500\\\\\\\",\\\\\\\"sn\\\\\\\":\\\\\\\"8110620473\\\\\\\",\\\\\\\"opt\\\\\\\":\\\\\\\"ZH\\\\\\\"},\\\\\\\"data\\\\\\\":{\\\\\\\"source\\\\\\\":\\\\\\\"AUTO|KEYWORD\\\\\\\",\\\\\\\"code\\\\\\\":[{\\\\\\\"zc\\\\\\\":\\\\\\\"W0000028248\\\\\\\"}]},\\\\\\\"sn\\\\\\\":\\\\\\\"0124972020082808062011520383_8110620473\\\\\\\"}\\\",\\\"atResult\\\":\\\"{\\\\\\\"result\\\\\\\":\\\\\\\"[{\\\\\\\\\\\\\\\"zc\\\\\\\\\\\\\\\":\\\\\\\\\\\\\\\"W0000028248\\\\\\\\\\\\\\\"}]\\\\\\\",\\\\\\\"success\\\\\\\":true}\\\",\\\"type\\\":\\\"3\\\",\\\"dataSrc\\\":\\\"AUTO|KEYWORD\\\"}\",\"index_time\":\"2020-08-28\",\"ip\":\"10.219.190.16\",\"appname\":\"gis-ass-eds-ms\",\"@version\":\"1\",\"@timestamp\":\"2020-08-28T00:06:20.227Z\"}"
    //    parseLog(log,"2020-08-10")
    val logDays: Int = -1
    var incDaySep: String = DateUtil.dateDelta(logDays, "-")
    var days = 1
    if (args.length == 2) {
      incDaySep = args(0)
      days = args(1).toInt
    }
    start(days, incDaySep)
  }

  def parseRequest(ret: JSONObject, request: JSONObject): Unit = {
    ret.put("citycode", JSONUtil.getJsonVal(request, "citycode", ""))
    ret.put("address", JSONUtil.getJsonVal(request, "address", ""))
    ret.put("sn", JSONUtil.getJsonVal(request, "sn", ""))
  }

  def parseResponse(ret: JSONObject, response: JSONObject): Unit = {
    if (response == null || response.getJSONObject("data") == null
      || response.getJSONObject("data").getJSONArray("code") == null) {
      return
    }
    val codeArray = response.getJSONObject("data").getJSONArray("code")
    val zcSb = new StringBuilder()
    val tcSb = new StringBuilder()
    for (i <- 0 until codeArray.size()) {
      val codeItem = codeArray.getJSONObject(i)
      zcSb.append(JSONUtil.getJsonVal(codeItem, "zc", "")).append("$")
      tcSb.append(JSONUtil.getJsonVal(codeItem, "tc", "")).append("$")
    }
    ret.put("zc", zcSb.deleteCharAt(zcSb.length - 1).toString())
    ret.put("tc", tcSb.deleteCharAt(tcSb.length - 1).toString())
  }

  def parseAtResult(ret: JSONObject, atResult: JSONObject): Unit = {
    if (atResult == null || atResult.getJSONObject("result") == null) {
      return
    }
    val result = atResult.getJSONObject("result")
    val tcsArray = result.getJSONArray("tcs")
    if (tcsArray != null && tcsArray.size() > 0) {
      val tcsItem = tcsArray.getJSONObject(0)
      val keyArray = Array("src", "dept", "team", "groupid", "aoicode", "aoiid", "aoiSrc", "atAoiSrc", "atDeptSrc", "atTeamSrc", "keyWord")
      for (key <- keyArray) {
        ret.put(key, JSONUtil.getJsonVal(tcsItem, key, ""))
      }
    }
    val geocoderKey = Array("adcode", "filter", "group", "name", "standardization")
    val groupId = ret.getString("groupid")
    if (StringUtils.nonEmpty(groupId)) {

      val geocoderArray = JSONUtil.getJsonArrayMulti(result, "other.normresp.result.geocoder")
      if (geocoderArray != null && geocoderArray.size()!=0) {
        for (i <- 0 until geocoderArray.size()) {
          val geocoderItem = geocoderArray.getJSONObject(i)
          val groupIdItem = JSONUtil.getJsonVal(geocoderItem, "group", "")
          if (groupIdItem.equals(groupId)) {
            for (geoKey <- geocoderKey) {
              ret.put(geoKey, JSONUtil.getJsonVal(geocoderItem, geoKey, ""))
            }
          }
        }
      }
    }
    val idList = result.getJSONObject("id_list")
    if(idList == null){
      return
    }
    ret.put("id_list", idList.toJSONString)
  }

  def parseLogDebang(ret: JSONObject, message: JSONObject): JSONObject = {
    ret.put("reqId", message.getString("requestId"))
    val request = JSONUtil.parseJSONObject(message.getString("request"))
    parseRequest(ret, request)
    val response = JSONUtil.parseJSONObject(message.getString("response"))
    parseResponse(ret, response)
    val atResult = JSONUtil.parseJSONObject(message.getString("atResult"))
    parseAtResult(ret, atResult)
    ret
  }

  def parseLog(log: String, incDaySep: String): JSONObject = {
    val jObj = JSON.parseObject(log)
    val createTime = jObj.getString("createTime")
    val ret = new JSONObject()
    ret.put("createTime", createTime)
    val message = JSONUtil.parseJSONObject(jObj.getString("message"))
    val dataType = message.getString("type")
    if ("3".equals(dataType)) {
      ret.put("dataType", "3")
      ret.put("dataSrc", message.getString("dataSrc"))
      parseLogDebang(ret, message)
    }
    //    println(ret.toJSONString)
    ret
  }

  def getKafakRdd(spark: SparkSession, beginDate: String, endDate: String, incDaySep: String): RDD[JSONObject] = {
    val sql =
      s"""select log from $debangHiveTable where inc_day between '$beginDate' and '$endDate'
         |
       """.stripMargin
    logger.error(sql)
    val tmpRdd = spark.sql(sql).rdd.take(100).map(obj=>{
      logger.error(obj.getString(0))
      parseLog(obj.getString(0), incDaySep)
    })
    val dataRdd = spark.sql(sql).rdd.map(obj => {
      var reqId: String = null
      var jObj: JSONObject = null
      try {
        jObj = parseLog(obj.getString(0), incDaySep)
        if (jObj != null) {
          reqId = jObj.getString("reqId")
        }
      } catch {
        case e: Exception => {
          logger.error(e)
        }
      }
      (reqId, jObj)
    })
    val debangRdd = dataRdd.filter(obj => obj._1 != null).filter(obj => "3".equals(obj._2.getString("dataType")))
      .persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("德邦数据量:" + debangRdd.count())
    debangRdd.values
  }

  def saveDebangDataOld(spark: SparkSession, formatRdd: RDD[JSONObject], incDay: String,
                        adcodeCityCodeMapBc: Broadcast[Map[String, String]]): Unit = {
    val rows = formatRdd.repartition(20).map(obj => {
      val saveArray = Array("createTime", "dataType", "dataSrc", "reqId", "citycode",
        "address", "sn", "zc", "tc", "src", "dept", "team", "groupid", "aoicode", "aoiid",
        "aoiSrc", "atAoiSrc", "atDeptSrc", "atTeamSrc", "keyWord", "adcode", "filter",
        "group", "name", "standardization", "id_list", "reqCityCode"
      )
      val sb = new StringBuilder()
      for (item <- saveArray) {
        if (item.equals("reqCityCode")) {
          val depponCityCode = JSONUtil.getJsonVal(obj, "citycode", "")
          var reqCityCode = ""
          if (!depponCityCode.isEmpty && adcodeCityCodeMapBc.value.contains(depponCityCode)) {
            reqCityCode = adcodeCityCodeMapBc.value.apply(depponCityCode)
          }
          sb.append(reqCityCode).append("\t")
        } else {
          sb.append(JSONUtil.getJsonVal(obj, item, "").replaceAll("[\\r\\n\\t]", "")).append("\t")
        }

      }
      sb.deleteCharAt(sb.length - 1)
      sb.toString()
    })
    val finalTable = debangReqStdTable
    val dropSql = String.format("alter table dm_gis.%s drop if exists partition(inc_day = '%s')", finalTable, incDay)
    spark.sql(dropSql)
    ShellExcutor.exeCmd(String.format("hdfs dfs -rm -R hdfs://sfbd/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, incDay))
    rows.saveAsTextFile(String.format("hdfs://sfbd/user/hive/warehouse/dm_gis.db/%s/inc_day=%s", finalTable, incDay))
    val addSql = String.format("alter table dm_gis.%s add if not exists partition(inc_day = '%s')", finalTable, incDay)
    spark.sql(addSql)
  }

  def saveDebangData(spark: SparkSession, formatRdd: RDD[JSONObject], incDay: String,
                     adcodeCityCodeMapBc: Broadcast[Map[String, String]]): Unit = {
    val saveArray = Array("createTime", "dataType", "dataSrc", "reqId", "citycode",
      "address", "sn", "zc", "tc", "src", "dept", "team", "groupid", "aoicode", "aoiid",
      "aoiSrc", "atAoiSrc", "atDeptSrc", "atTeamSrc", "keyWord", "adcode", "filter",
      "group", "name", "standardization", "id_list", "reqCityCode"
    )
    val schemaEle = new ArrayBuffer[StructField]()
    for (i <- saveArray.indices) {
      schemaEle.append(StructField(saveArray.apply(i), StringType, nullable = true))
    }
    val schema = StructType(schemaEle.toArray)
    val rows = formatRdd.map(obj => {
      val row = new ArrayBuffer[String]
      for (i <- saveArray.indices) {
        if (saveArray.apply(i).equals("reqCityCode")) {
          val depponCityCode = JSONUtil.getJsonVal(obj, "citycode", "")
          var reqCityCode = ""
          if (!depponCityCode.isEmpty && adcodeCityCodeMapBc.value.contains(depponCityCode)) {
            reqCityCode = adcodeCityCodeMapBc.value.apply(depponCityCode)
          }
          row.append(reqCityCode.replaceAll("[\\r\\n\\t]", ""))
        } else {
          row.append(JSONUtil.getJsonVal(obj, saveArray.apply(i), "").replaceAll("[\\r\\n\\t]", ""))
        }
      }
      val ret = Row.fromSeq(row)
      ret
    }).repartition(20)
    var rowDf = spark.createDataFrame(rows, schema).withColumn("inc_day", lit(incDay))
    val finalTable = debangReqStdTable
    rowDf.write.mode(SaveMode.Overwrite).insertInto(finalTable)
  }

  def startSta(spark: SparkSession, incDay: String, endDay: String, incDaySep: String): Unit = {
    val adcodeCityCodeMap = CityInfoUtils.loadAdcodeCityCodemap()
    val adcodeCityCodeMapBc = spark.sparkContext.broadcast(adcodeCityCodeMap)
    logger.error("获取debang数据")
    val debangRdd = getKafakRdd(spark, incDay, endDay, incDaySep)

    saveDebangData(spark, debangRdd, incDay, adcodeCityCodeMapBc)
  }


  def start(days: Int, beginDaySep: String): Unit = {
    val spark = Spark.getSparkSession(appName)
    for (i <- 0 until days) {
      val incDaySep = DateUtil.getDay(beginDaySep, i, "-")
      val incDay = incDaySep.replaceAll("-", "")
      val endDay: String = incDay
      logger.error("incDaySep:" + incDaySep)
      startSta(spark, incDay, endDay, incDaySep)
    }
    logger.error("the end~")
  }


}
