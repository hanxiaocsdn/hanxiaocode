package com.sf.gis.scala.debang.DebangCuofen

import java.net.URLEncoder

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.sx.constant.util.Utils
import com.sf.gis.scala.base.util.StringUtils
import org.apache.log4j.Logger

import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
 * 任务id:153
 * 任务名称：德邦db_rds
 */
object DepponDbRds {

  @transient lazy val logger: Logger = Logger.getLogger(DepponDbRds.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val rdsZcUrl = "http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&opt=rds&show=1"
  //val rdsZcUrl ="http://gis-int.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&opt=zc&show=1"

  val deleteGroupIdUrl ="http://gis-int.int.sfdc.com.cn:1080/eds/group/del?ak=3a191e7427e8470c86271a069411c66b&groupId=%s&type=his&cityCode=%s"


  case class dbRds(
                    sn:String,
                    address:String,
                    citycode:String,
                    city:String,
                    depponZc:String,
                    zc:String,
                    dataSrc:String,
                    groupid:String
                  )


  def getdbRdsData(spark: SparkSession, inc_day: String) = {

    val dlr = '$'

    //获取字段city，groupid，dataSrc, address，citycode,zc,depponzc
    val sourceSql =
      s"""
         |select
         |  b.sn as sn,
         |  regexp_replace(b.address, '[\\r\\n\\s,]+', '') as address,
         |  b.citycode as citycode,
         |  b.city as city,
         |  b.depponZc as depponZc,
         |  b.zc as zc,
         |  b.dataSrc as dataSrc,
         |  b.groupid as groupid
         |from
         |  (
         |    select
         |      get_json_object(data_info, '$dlr.sn') sn,
         |      inc_day
         |    from
         |      dm_gis.t_deppon_sign_index_info_d
         |    where
         |      data_type = 'wd'
         |      and inc_day BETWEEN '$inc_day'
         |      and '$inc_day'
         |  ) a
         |  left outer join (
         |    select
         |      get_json_object(data_info, '$dlr.sn') sn,
         |      get_json_object(data_info, '$dlr.reqBody.address') address,
         |      get_json_object(data_info, '$dlr.depponZc') depponZc,
         |      get_json_object(data_info, '$dlr.mapAXy.x') mapa_x,
         |      get_json_object(data_info, '$dlr.mapAXy.y') mapa_y,
         |      get_json_object(data_info, '$dlr.mapAXy.precision') mapa_precision,
         |      get_json_object(data_info, '$dlr.mapAXy.aoi_id') mapa_aoi_id,
         |      get_json_object(data_info, '$dlr.mapAXy.aoi_name') mapa_aoi_name,
         |      get_json_object(data_info, '$dlr.tsXy.precision') ts_precision,
         |      get_json_object(data_info, '$dlr.tsXy.x') ts_x,
         |      get_json_object(data_info, '$dlr.tsXy.y') ts_y,
         |      get_json_object(data_info, '$dlr.tsXy.aoi_id') ts_aoi_id,
         |      get_json_object(data_info, '$dlr.tsXy.aoi_name') ts_aoi_name,
         |      get_json_object(data_info, '$dlr.reqBody.src') src,
         |      get_json_object(data_info, '$dlr.reqBody.adcode') adcode,
         |      get_json_object(data_info, '$dlr.reqBody.zc') zc,
         |      get_json_object(data_info, '$dlr.reqBody.standardization') standardization,
         |      get_json_object(data_info, '$dlr.reqBody.keyWord') keyWord,
         |      get_json_object(data_info, '$dlr.model_Zc') model_Zc,
         |      get_json_object(data_info, '$dlr.ts_xy_Zc') ts_xy_Zc,
         |      get_json_object(data_info, '$dlr.mapa_xy_Zc') mapa_xy_Zc,
         |      get_json_object(data_info, '$dlr.reqBody.aoiid') aoiid,
         |      get_json_object(data_info, '$dlr.reqBody.dataSrc') dataSrc,
         |      get_json_object(data_info, '$dlr.reqBody.group') groupid,
         |      get_json_object(data_info, '$dlr.reqBody.cityCode') citycode,
         |      get_json_object(data_info, '$dlr.cityCode') city,
         |      get_json_object(data_info, '$dlr.mapaAoiZc') mapaAoiZc,
         |      get_json_object(data_info, '$dlr.tsAoiZc') tsAoiZc,
         |      inc_day
         |    from
         |      dm_gis.t_deppon_sign_index_info_d
         |    where
         |      data_type in ('src', 'zcmodel_buzErrZCModelRight')
         |      and inc_day BETWEEN '$inc_day'
         |      and '$inc_day'
         |  ) b on a.sn = b.sn
       """.stripMargin

    logger.error(sourceSql)

    val sourceData = spark.sql(sourceSql).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("输入sourceData的数据量为：" + sourceData.count())
    sourceData.take(2).foreach(println(_))

    val dbRdsDf = sourceData.na.drop(Seq("dataSrc")).filter(sourceData("dataSrc").equalTo("DB_RDS")).toDF("sn","address","citycode","city","depponZc","zc","dataSrc","groupid")

    logger.error("输入dbRdsDf的数据量为：" + dbRdsDf.count())

    dbRdsDf

  }

  def parseProcess(city: String, citycode: String, address: String, zc: String, depponZc: String, groupId: String): String = {

    val json = new JSONObject()

    val rdsReq = String.format(rdsZcUrl, URLEncoder.encode(citycode, "utf-8"), URLEncoder.encode(address, "utf-8"))
    val rdsRes = Utils.retryGet(rdsReq)


    val rdsZc = try {

      val responseJson = JSON.parseObject(rdsRes)
      val result = responseJson.getJSONObject("result")
      val data = result.getJSONObject("data")
      val array = data.getJSONArray("code")

      var zcM =""
      if(array.size()>0){
        zcM = array.getJSONObject(0).getString("zc")
      }
      zcM
    }catch {
      case e:Exception => "err" + "\n" + e
    }

    var tag = ""
    if(StringUtils.nonEmpty(depponZc) && StringUtils.nonEmpty(rdsZc) && rdsZc.equals(depponZc)){
      tag = "deleteGroupId"
    }else {
      if(StringUtils.nonEmpty(rdsZc) && rdsZc.equals(zc)){
        tag = "deleteGroupId"
      }else{
        tag = "noProcess"
      }
    }


    var delGroupIdRes =""
    if("deleteGroupId".equals(tag)){
       val delGroupIdReq = String.format(deleteGroupIdUrl,URLEncoder.encode(groupId, "utf-8"),URLEncoder.encode(city, "utf-8"))
       json.put("delGroupIdReq",delGroupIdReq)
       delGroupIdRes = Utils.retryGet(delGroupIdReq)
    }


    json.put("rdsReq",rdsReq)
    json.put("rdsRes",rdsRes)
    json.put("rdsZc",rdsZc)
    json.put("delGroupIdRes",delGroupIdRes)
    json.put("tag",tag)

    json.toString()
  }


  def processZc(spark: SparkSession,dbRdsData: DataFrame,inc_day:String) = {


     import org.apache.spark.sql.functions._

     val parseFuction = udf(parseProcess _)

    // val parseFuction = udf(((String,String,String,String),null))



     val processDf = dbRdsData.select(col("*"),parseFuction(col("city"),col("citycode"),col("address"),col("zc"),col("depponZc"),col("groupid")) as "delGroupIdRes").persist(StorageLevel.MEMORY_AND_DISK_SER)

     val schema = processDf.printSchema()

     processDf.take(2).foreach(println(_))

     processDf.withColumn("inc_day",lit(inc_day)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.deppon_db_rds_info")


  }



//  def processZc(dbRdsData: DataFrame) = {
//
//    val process1Df = dbRdsData.map(x => {
//      val citycode = x.getAs[String]("citycode")
//      val address = x.getAs[String]("address")
//      val zc = x.getAs[String]("zc")
//      val depponZc = x.getAs[String]("depponZc")
//
//      val rdsReq = String.format(rdsZcUrl,citycode,address)
//      val rdsRes = Utils.retryGet(rdsReq)
//
//      val rdsZc = JSON.parseObject(rdsRes).getString("zc")
//
//      var tag = ""
//
//      //val rdsJson = try{JSON.parseObject(rdsRes)} catch {case e:Exception =>  new JSONObject().put("err",e + "\n" + rdsRes)}
//      if(StringUtils.nonEmpty(depponZc) && StringUtils.nonEmpty(rdsZc) && rdsZc.equals(depponZc)){
//        tag = "deleteGroupId"
//      }else {
//        if(StringUtils.nonEmpty(rdsZc) && rdsZc.equals(zc)){
//          tag = "deleteGroupId"
//        }else{
//          tag = "noProcess"
//        }
//      }
////      val buffer = Row.unapplySeq(x).get.map(_.asInstanceOf[String]).toBuffer
////      buffer.append("tag",tag)
////      val schema: StructType = x.schema
////        .add("tag","StringType")
////
////      val newRow = new GenericRowWithSchema(buffer.toArray, schema)
////      newRow
//
//      Row(x,tag)
//
//    })
//
//  }

  def startSta(spark: SparkSession, inc_day: String): Unit = {

    val dbRdsData = getdbRdsData(spark,inc_day).persist(StorageLevel.MEMORY_AND_DISK_SER)

    val dbRdsZc = processZc(spark,dbRdsData,inc_day)


  }

  def start(inc_day: String): Unit = {
    val spark = SparkSession
      .builder()
      .appName("SparkDecode")
      .master("yarn")
      .enableHiveSupport()

      .config("hive.exec.dynamic.partition",true)
      .config("hive.exec.dynamic.partition.mode","nonstrict")
      .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    startSta(spark,inc_day)



  }

  def main(args: Array[String]): Unit = {


    val inc_day =args(0)

//    val rdsReq = String.format(rdsZcUrl,URLEncoder.encode("445100", "utf-8"), URLEncoder.encode("广东省潮州市潮安区枫溪镇火车站李厝小学变压台对面巷直入第二条巷第二栋绿闸门", "utf-8"))
//    val rdsRes = Utils.retryGet(rdsReq)
//    logger.error("rdsReq:" + rdsReq)
//    logger.error("rdsRes:" + rdsRes)

    start(inc_day)

    logger.error("统计完毕")
  }


}
