package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder
import java.util.Calendar

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.util.HttpClientUtil
import com.sf.gis.scala.debang.util.{DateUtil, JSONUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * Created by 01374443 on 2019/3/5.
  * * Update by 01412406 on 2021/6/23.
  * 时间确定
  */

object kuaiYunReceiveNew {
  @transient lazy val logger: Logger = Logger.getLogger(kuaiYunReceiveNew.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  //接口
  val runTcUrl = "http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=%s&lat=%s&ak=1245f89114fb4f5e896213904b4923a5"
  //  点落面服务接口：http://gis-int.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=113.936683&lat=22.532681&ak=8cb19f422db34736922479ba0bc848f4
  //  【入参】：【gd_x】和【mapa_x】传入【lng】，【gd_y】和【mapa_y】传入【lat】
  //  【出参】：【level】=3下的【code】记为【gd_tc】和【mapa_tc】
  val mapa_url = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=ma1&ak=1245f89114fb4f5e896213904b4923a5"
  val ts_url = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?address=%s&city=%s&opt=gd2&ak=1245f89114fb4f5e896213904b4923a5"
  //  切片服务接口
  val qp_url = "http://gis-ass-dqs.sf-express.com/emap/api/efs/getEfsBusiFeatureByAois?aoiId=%s&layerAbbr=KY"


  case class result(
                     cityCode: String
                     , city: String
                     , region: String
                     , adressEmptyCnt: Int
                     , unidentifiedCnt: Int
                     , rangeOutCnt: Int
                     , recognitionCnt: Int
                     , pbYwCnt: Int
                     , pbFlaseCnt: Int
                     , bgYwCnt: Int
                     , bgFlaseCnt: Int
                     , empcodeEmptyCnt: Int
                     , xgYwCnt: Int
                     , unitCodeEmptyCnt: Int
                     , empFlaseCnt: Int
                     , pbSyCnt: Int
                     , bgSyCnt: Int
                     , xgSyCnt: Int
                     , pb54Cnt: Int
                     , bg54Cnt: Int
                     , xg54Cnt: Int
                     , reAddressCnt: Int
                     , reAddresshisCnt: Int
                     , reSignCnt: Int

                     , falseAddressCnt: Int
                     , falseAddresshisCnt: Int
                     , falseSignCnt: Int
                     , falseMapbCnt: Int
                     , reMapbCnt: Int
                     , stat_type: String
                     , nozcDataCnt: Int
                     //--cxg
                     , unoNullCnt: Int
                     , unitNullCnt: Int
                     , pbAllCnt: Int
                     , customerCnt: Int
                     , transforServiceCnt: Int
                     , allFalseCnt: Int
                     , bgNoschCnt: Int
                     , ksCnt: Int

                     , false_ks_cnt: Int
                     , artificial_1_cnt: Int
                     , cus_weight_wr_1_cnt: Int
                     , artificial_2_cnt: Int
                     , schedule_wr_cnt: Int
                     , cus_weight_wr_2_cnt: Int
                     , rec_wr_cnt: Int
                     , rec_wr_address_cnt: Int
                     , rec_wr_addresshis_cnt: Int
                     , rec_wr_sign_cnt: Int
                     , rec_wr_mapb_cnt: Int
                     , rec_wr_ks_cnt: Int
                   )


  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    //    val startDay = "2021-04-11"
    val days = args.apply(1).toInt
    var num = days
    var Day = startDay
    for (i <- 0 until num) {
      val incDay = DateUtil.getDateStr(startDay, i, "-") //2021-08-24
      logger.error("起始时间:" + incDay + ",时间跨度:" + i)
      start(incDay)
      logger.error("结束所有运行")

    }


  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    val formatDay = startDay.replaceAll("-", "") //20210823
    val formatDay1 = DateUtil.getDateStr(startDay, 1, "-") //2021-08-24
    val formatDay3 = DateUtil.getDateStr(startDay, -1, "-") //2021-08-22


    //        for (i <- 0 until days) {
    val sepDay = DateUtil.getDateStr(formatDay, 0, "") //20210823 t-2
    val T1Day = DateUtil.getDateStr(formatDay, 1, "") //20210824
    val T4Day = DateUtil.getDateStr(formatDay, -2, "") //20210821
    val T3Day = DateUtil.getDateStr(formatDay, -1, "") //20210822
    val incDay = sepDay.replaceAll("-", "") //t-2

    logger.error("开始计算：" + incDay + "&&formatDay1:" + formatDay1 + "&&formatDay3:" + formatDay3)
    startSta(spark, incDay, sepDay, T1Day, T3Day, T4Day, formatDay1, formatDay3)
    logger.error("计算结束：" + incDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String, sepDay: String, T1Day: String, T3Day: String, T4Day: String, formatDay1: String, formatDay3: String) = {

    logger.error("获取数据源")
    //取数据源
    val dataRdd = getDataDf(spark, incDay, sepDay, T1Day, T3Day, T4Day, formatDay1, formatDay3)
    logger.error(dataRdd.take(10).foreach(println(_)))
    logger.error("获取城市映射表")
    val cityMap = queryCityMap(spark)

    logger.error("打tag标签")
    //打tag
    val tagRdd = checkTag(dataRdd)
    logger.error(tagRdd.take(10).foreach(println(_)))
    logger.error("打tag2标签")
    //打tag2
    val checkRdd2 = checkTag2(tagRdd)
    logger.error(checkRdd2.take(10).foreach(println(_)))
    //打tag4标签
    val checkRdd = checkTag4(checkRdd2, cityMap)
    logger.error("开始汇总")
    //汇总
    val staIndexRdd = staIndex(checkRdd)
    logger.error("开始入库")
    //入库
    saveTable(spark, staIndexRdd, checkRdd, incDay)
    logger.error("结束所有运行")

  }

//  //写入未画tc表
//  def saveNoZcData(spark: SparkSession, checkOverRdd: RDD[JSONObject], incDay: String): Unit = {
//    import spark.implicits._
//
//    val rowDf = checkOverRdd.filter(obj => JSONUtil.getJsonVal(obj, "tag4", "").equals("nozcdata")).map(
//      obj => {
//        (JSONUtil.getJsonVal(obj, "waybill_no", ""), JSONUtil.getJsonVal(obj, "tag4", ""), JSONUtil.getJsonVal(obj, "aoiId", ""))
//      }
//    ).toDF()
//
//    logger.error("数量：" + rowDf.count())
//    val tableName = "dm_gis.kuaiyun_nozcdata_di" //生产表
//    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Append).insertInto(tableName)
//  }


  def checkTag(dataRdd: RDD[JSONObject]) = {


    logger.error("打tag的数据量：" + dataRdd.count())
    //判断
    val nextRdd = dataRdd.map(obj => {
      val uno = JSONUtil.getJsonVal(obj, "uno", "")
      val unit_code = JSONUtil.getJsonVal(obj, "unit_code", "")
      if (uno.isEmpty) obj.put("tag", "uno_null")
      else if (unit_code.isEmpty) obj.put("tag", "unit_null")
      obj
    })

    val nextRdd11 = nextRdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val UnionRdd1 = nextRdd.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("uno_null跟unit_null有值的数据量：" + nextRdd11.count())
    logger.error("未打上tag的数据量：" + UnionRdd1.count())

    //打wr_tag
    val nextRdd1 = getWrTag(nextRdd11)
    //     UnionRdd1.filter(obj => {JSONUtil.getJsonVal(obj, "tag", "").isEmpty}).persist(StorageLevel.MEMORY_AND_DISK)
    //     UnionRdd1.filter(obj => {!JSONUtil.getJsonVal(obj, "tag", "").isEmpty}).persist(StorageLevel.MEMORY_AND_DISK)


    val tagResult1Rdd = nextRdd1.map(obj => {
      val address = JSONUtil.getJsonVal(obj, "address", "")
      val data_type = JSONUtil.getJsonVal(obj, "data_type", "")
      val task_status = JSONUtil.getJsonVal(obj, "task_status", "")
      val pickup_emp_code = JSONUtil.getJsonVal(obj, "pickup_emp_code", "")
      val team = JSONUtil.getJsonVal(obj, "team", "")
      val emp_code_task_express = JSONUtil.getJsonVal(obj, "emp_code_task_express", "")


      if (address.isEmpty) obj.put("tag", "address_empty")
      else if (pickup_emp_code.isEmpty) obj.put("tag", "pickup_empty")
      else if (data_type.equals("1") && task_status.equals("4")) obj.put("tag", "range_out")
      else if (team.isEmpty || team.equals("null")) {
        if (emp_code_task_express.equals("system")) {
          obj.put("tag", "recognition")
          obj.put("src", "KS")
        } else obj.put("tag", "unidentified")

      }
      else obj.put("tag", "recognition")
      obj
    }

    ).persist(StorageLevel.MEMORY_AND_DISK)

    val tagRdd = tagResult1Rdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag", "").isEmpty()
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val NotagRdd = tagResult1Rdd.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag", "").isEmpty()
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("tag有值的数据量：" + tagRdd.count())
    logger.error("未打上tag的数据量：" + NotagRdd.count())

    val reRdd = tagResult1Rdd.union(UnionRdd1).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("未完tag的数据量：" + reRdd.count())
    tagRdd.unpersist()
    NotagRdd.unpersist()
    nextRdd1.unpersist()
    UnionRdd1.unpersist()
    reRdd
  }


  def checkTag2(dataRdd: RDD[JSONObject]) = {

    logger.error("打tag2的数量：" + dataRdd.count())
    logger.error(dataRdd.take(10).foreach(println(_)))


    val nexteRdd = dataRdd.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag", "").equals("recognition")
    }).persist(StorageLevel.MEMORY_AND_DISK)
    val UnionRdd = dataRdd.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag", "").equals("recognition")
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("tag是recognition的数量：" + nexteRdd.count())
    logger.error("tag不是recognition的数量：" + UnionRdd.count())

    val result1 = nexteRdd.map(obj => {
      val data_type = JSONUtil.getJsonVal(obj, "data_type", "")
      val transfor_emp = JSONUtil.getJsonVal(obj, "transfor_emp", "")
      val employee_code = JSONUtil.getJsonVal(obj, "employee_code", "")
      val responsible = JSONUtil.getJsonVal(obj, "responsible", "")
      val tc_list1 = JSONUtil.getJsonVal(obj, "tc_list1", "")
      val tc_list2 = JSONUtil.getJsonVal(obj, "tc_list2", "")
      val team = JSONUtil.getJsonVal(obj, "team", "")

      //--cxg
      if (data_type.equals("2")) {
        obj.put("tag2", "pb_all")
      }
      else {
        if (!transfor_emp.equals("1") && !transfor_emp.equals("2")) {
          if (!employee_code.isEmpty && employee_code.equals(transfor_emp)) obj.put("tag2", "transfor_service")
          else if (responsible.equals("3")) obj.put("tag2", "customer")
          else if (tc_list1.isEmpty && tc_list2.isEmpty) obj.put("tag2", "bg_nosch")
          else if (tc_list1.split(",").contains(team) || tc_list2.split(",").contains(team)) obj.put("tag2", "bg_yw")
          else obj.put("tag2", "bg_false")
        }
        else if (transfor_emp.equals("2")) obj.put("tag2", "transfor_service")
      }


      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)


    val nextRdd1 = result1.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("判断emp_code的数量:" + nextRdd1.count())


    val UnionRdd1 = result1.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("确定的数量:" + UnionRdd1.count())


    val result2 = nextRdd1.map(obj => {
      val emp_code = JSONUtil.getJsonVal(obj, "emp_code", "")
      if (emp_code.isEmpty) {
        obj.put("tag2", "empcode_empty")
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK)

    val UnionRdd2 = result2.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("emp_code是空的数量:" + UnionRdd2.count())
    val nextRdd2 = result2.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("判断emp_code与pickup_emp_code的数量:" + nextRdd2.count())

    val result3 = nextRdd2.map(obj => {
      val emp_code = JSONUtil.getJsonVal(obj, "emp_code", "")
      val pickup_emp_code = JSONUtil.getJsonVal(obj, "pickup_emp_code", "")
      if (!emp_code.isEmpty && emp_code.equals(pickup_emp_code)) {
        obj.put("tag2", "xg_yw")
      }
      obj
    })

    val UnionRdd3 = result3.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("emp_code与pickup_emp_code一致的数量:" + UnionRdd3.count())
    val nextRdd3 = result3.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("判断unit_code_lis是否为空的数量:" + nextRdd3.count())


    val result4 = nextRdd3.map(obj => {
      if (JSONUtil.getJsonVal(obj, "tc_list1", "").isEmpty && JSONUtil.getJsonVal(obj, "tc_list2", "").isEmpty) obj.put("tag2", "tc_list_empty")
      obj
    })
    val UnionRdd4 = result4.filter(obj => {
      !JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("unit_code_list为空的数量:" + UnionRdd4.count())
    val nextRdd4 = result4.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").isEmpty
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("判断unit_code_list包含teamCode" + nextRdd4.count())


    val result5 = nextRdd4.map(obj => {
      val tc_list1 = JSONUtil.getJsonVal(obj, "tc_list1", "")
      val tc_list2 = JSONUtil.getJsonVal(obj, "tc_list2", "")
      //改
      val team = JSONUtil.getJsonVal(obj, "team", "")
      //      val teamCode = JSONUtil.getJsonVal(obj, "teamCode", "")
      if (tc_list1.split(",").contains(team) || tc_list2.split(",").contains(team)) obj.put("tag2", "xg_yw")
      else obj.put("tag2", "emp_false")
      obj
    })


    val UnionRdd5 = result5.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").equals("xg_yw")
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("unit_code_list包含teamCode的数量:" + UnionRdd5.count())
    val nextRdd5: RDD[JSONObject] = result5.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag2", "").equals("emp_false")
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("unit_code_list不包含teamCode的数量:" + nextRdd5.count())


    val runUrlRdd = result5.union(UnionRdd1).union(UnionRdd2).union(UnionRdd3).union(UnionRdd4).union(UnionRdd).persist(StorageLevel.MEMORY_AND_DISK)


    //调Mapa跟图商
    val re = getTc(runUrlRdd)
    logger.error("pb_sy:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("pb_sy")
    }).count())
    logger.error("bg_sy:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("bg_sy")
    }).count())
    logger.error("xg_sy:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("xg_sy")
    }).count())
    logger.error("sy_false:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("sy_false")
    }).count())
    logger.error("pb_54:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("pb_54")
    }).count())
    logger.error("bg_54:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("bg_54")
    }).count())
    logger.error("xg_54:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("xg_54")
    }).count())
    logger.error("All_false:" + re.filter(obj => {
      JSONUtil.getJsonVal(obj, "tag3", "").equals("all_false")
    }).count())


    logger.error("总数据量：" + re.count())
    re
  }


  def checkTag4(dataRdd: RDD[JSONObject], cityMap: Broadcast[collection.Map[String, String]]) = {
    //未画TC
    val reRdd = dataRdd.map(
      obj => {
        val aoiId = JSONUtil.getJsonVal(obj, "aoiId", "")
        val tag = JSONUtil.getJsonVal(obj, "tag", "")
        if (tag.equals("unidentified") && aoiId.nonEmpty) {
          val (codeList, ret) = getCode(aoiId)
          if (codeList.isEmpty) obj.put("tag4", "nozcdata")
        }
        obj
      }
    ).persist(StorageLevel.MEMORY_AND_DISK)


    //获取城市映射
    val staRdd = reRdd.map(obj => {
      val cityNameMap = cityMap.value
      val cityCode = JSONUtil.getJsonVal(obj, "city_code", "")

      var city: String = ""
      var region: String = ""
      var area: String = ""


      val mapString = cityNameMap.applyOrElse(cityCode, { num: String => "" })

      if (!mapString.isEmpty) {
        city = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(0)
        region = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(1)
        area = cityNameMap.applyOrElse(cityCode, { num: String => "" }).split("&&")(2)
      }


      //大区
      obj.put("region", region)
      //地区
      obj.put("area", area)
      //城市名称
      obj.put("city", city)
      obj
    })

    staRdd
  }


  def staIndex(dataRdd: RDD[JSONObject]) = {
    //根据城市汇总
    val reCityRdd = dataRdd.map(obj => {
      val cityCode = JSONUtil.getJsonVal(obj, "city_code", "")
      val region = JSONUtil.getJsonVal(obj, "region", "")
      val city = JSONUtil.getJsonVal(obj, "city", "")
      val result = getstaIndexRdd(cityCode, city, region, "CITY", obj)

      result
    }).persist(StorageLevel.MEMORY_AND_DISK)

    //根据地区汇总
    val reRegionRdd = dataRdd.map(obj => {
      val region = JSONUtil.getJsonVal(obj, "region", "")
      val result = getstaIndexRdd("ALL", "ALL", region, "REGION", obj)

      result
    }).persist(StorageLevel.MEMORY_AND_DISK)


    val allRdd = dataRdd.map(obj => {
      val result = getstaIndexRdd("ALL", "ALL", "ALL", "ALL", obj)

      result
    }).persist(StorageLevel.MEMORY_AND_DISK)


    val reRdd = reRegionRdd.union(reCityRdd).union(allRdd)

    val finalRdd = reRdd.map(obj => {
      ((obj.cityCode, obj.city, obj.region, obj.stat_type), obj)
    }).reduceByKey((obj1, obj2) => {
      val cityCode = obj1.cityCode
      val city = obj1.city
      val region = obj1.region
      val stat_type = obj1.stat_type
      val adressEmptyCnt = obj1.adressEmptyCnt + obj2.adressEmptyCnt
      val unidentifiedCnt = obj1.unidentifiedCnt + obj2.unidentifiedCnt
      val rangeOutCnt = obj1.rangeOutCnt + obj2.rangeOutCnt
      val recognitionCnt = obj1.recognitionCnt + obj2.recognitionCnt
      val pbYwCnt = obj1.pbYwCnt + obj2.pbYwCnt
      val pbFlaseCnt = obj1.pbFlaseCnt + obj2.pbFlaseCnt
      val bgYwCnt = obj1.bgYwCnt + obj2.bgYwCnt
      val bgFlaseCnt = obj1.bgFlaseCnt + obj2.bgFlaseCnt
      val empcodeEmptyCnt = obj1.empcodeEmptyCnt + obj2.empcodeEmptyCnt
      val xgYwCnt = obj1.xgYwCnt + obj2.xgYwCnt
      val unitCodeEmptyCnt = obj1.unitCodeEmptyCnt + obj2.unitCodeEmptyCnt
      val empFlaseCnt = obj1.empFlaseCnt + obj2.empFlaseCnt
      val pbSyCnt = obj1.pbSyCnt + obj2.pbSyCnt
      val bgSyCnt = obj1.bgSyCnt + obj2.bgSyCnt
      val xgSyCnt = obj1.xgSyCnt + obj2.xgSyCnt
      val pb54Cnt = obj1.pb54Cnt + obj2.pb54Cnt
      val bg54Cnt = obj1.bg54Cnt + obj2.bg54Cnt
      val xg54Cnt = obj1.xg54Cnt + obj2.xg54Cnt

      val reAddressCnt = obj1.reAddressCnt + obj2.reAddressCnt
      val reAddresshisCnt = obj1.reAddresshisCnt + obj2.reAddresshisCnt
      val reSignCnt = obj1.reSignCnt + obj2.reSignCnt
      val reMapbCnt = obj1.reMapbCnt + obj2.reMapbCnt
      val falseAddressCnt = obj1.falseAddressCnt + obj2.falseAddressCnt
      val falseAddresshisCnt = obj1.falseAddresshisCnt + obj2.falseAddresshisCnt
      val falseSignCnt = obj1.falseSignCnt + obj2.falseSignCnt
      val falseMapbCnt = obj1.falseMapbCnt + obj2.falseMapbCnt
      val nozcDataCnt = obj1.nozcDataCnt + obj2.nozcDataCnt

      val unoNullCnt = obj1.unoNullCnt + obj2.unoNullCnt
      val unitNullCnt = obj1.unitNullCnt + obj2.unitNullCnt
      val pbAllCnt = obj1.pbAllCnt + obj2.pbAllCnt
      val customerCnt = obj1.customerCnt + obj2.customerCnt
      val transforServiceCnt = obj1.transforServiceCnt + obj2.transforServiceCnt
      val allFalseCnt = obj1.allFalseCnt + obj2.allFalseCnt
      val bgNoschCnt = obj1.bgNoschCnt + obj2.bgNoschCnt
      val ksCnt = obj1.ksCnt + obj2.ksCnt

      val false_ks_cnt = obj1.false_ks_cnt + obj2.false_ks_cnt
      val artificial_1_cnt = obj1.artificial_1_cnt + obj2.artificial_1_cnt
      val cus_weight_wr_1_cnt = obj1.cus_weight_wr_1_cnt + obj2.cus_weight_wr_1_cnt
      val artificial_2_cnt = obj1.artificial_2_cnt + obj2.artificial_2_cnt
      val schedule_wr_cnt = obj1.schedule_wr_cnt + obj2.schedule_wr_cnt
      val cus_weight_wr_2_cnt = obj1.cus_weight_wr_2_cnt + obj2.cus_weight_wr_2_cnt
      val rec_wr_cnt = obj1.rec_wr_cnt + obj2.rec_wr_cnt
      val rec_wr_address_cnt = obj1.rec_wr_address_cnt + obj2.rec_wr_address_cnt
      val rec_wr_addresshis_cnt = obj1.rec_wr_addresshis_cnt + obj2.rec_wr_addresshis_cnt
      val rec_wr_sign_cnt = obj1.rec_wr_sign_cnt + obj2.rec_wr_sign_cnt
      val rec_wr_mapb_cnt = obj1.rec_wr_mapb_cnt + obj2.rec_wr_mapb_cnt
      val rec_wr_ks_cnt = obj1.rec_wr_ks_cnt + obj2.rec_wr_ks_cnt


      result(cityCode
        , city
        , region
        , adressEmptyCnt
        , unidentifiedCnt
        , rangeOutCnt
        , recognitionCnt
        , pbYwCnt
        , pbFlaseCnt
        , bgYwCnt
        , bgFlaseCnt
        , empcodeEmptyCnt
        , xgYwCnt
        , unitCodeEmptyCnt
        , empFlaseCnt
        , pbSyCnt
        , bgSyCnt
        , xgSyCnt
        , pb54Cnt
        , bg54Cnt
        , xg54Cnt
        , reAddressCnt
        , reAddresshisCnt
        , reSignCnt
        , falseAddressCnt
        , falseAddresshisCnt
        , falseSignCnt
        , falseMapbCnt
        , reMapbCnt
        , stat_type
        , nozcDataCnt
        //---cxg
        , unoNullCnt
        , unitNullCnt
        , pbAllCnt
        , customerCnt
        , transforServiceCnt
        , allFalseCnt
        , bgNoschCnt
        , ksCnt
        , false_ks_cnt
        , artificial_1_cnt
        , cus_weight_wr_1_cnt
        , artificial_2_cnt
        , schedule_wr_cnt
        , cus_weight_wr_2_cnt
        , rec_wr_cnt
        , rec_wr_address_cnt
        , rec_wr_addresshis_cnt
        , rec_wr_sign_cnt
        , rec_wr_mapb_cnt
        , rec_wr_ks_cnt
      )
    })

    finalRdd
  }


  def queryCityMap(spark: SparkSession): Broadcast[collection.Map[String, String]] = {
    val sql =
      """
        | select max(city) as city ,citycode,max(region) as region ,max(area) as area
        | from dm_gis.city_name_map
        | group by citycode
      """.stripMargin
    logger.error(sql)
    val cityMap = spark.sql(sql).rdd.map(obj => {
      (obj.getString(1), obj.getString(0) + "&&" + obj.getString(2) + "&&" + obj.getString(3))
    }).collectAsMap()
    logger.error("城市映射表数量:" + cityMap.size)
    spark.sparkContext.broadcast(cityMap)
  }

  def runMapXyInteface(mapUrl: String, cityCode: String, address: String): JSONObject = {
    var ret: JSONObject = new JSONObject()
    try {
      if (!cityCode.isEmpty && !address.isEmpty) {
        val url = String.format(mapUrl, URLEncoder.encode(address, "utf-8"), cityCode)
        val xyObj = HttpClientUtil.getJsonByGet(url)
        if (xyObj != null && xyObj.getJSONObject("result") != null) {
          if (xyObj.getJSONObject("result").getInteger("err") == 109) {
            val second = Calendar.getInstance().get(Calendar.SECOND)
            Thread.sleep(60 - second)
            return runMapXyInteface(mapUrl, cityCode, address)
          }
          ret = new JSONObject()
          var status, x, y, precision = ""
          if (xyObj.getInteger("status") != null) status = xyObj.getInteger("status") + ""
          val result = xyObj.getJSONObject("result")
          if (result != null) {
            if (result.getDouble("xcoord") != null) x = result.getDouble("xcoord") + ""
            if (result.getDouble("ycoord") != null) y = result.getDouble("ycoord") + ""
            if (result.getDouble("precision") != null) precision = result.getInteger("precision") + ""
          }
          ret.put("x", x)
          ret.put("y", y)
          ret.put("status", status)
          ret.put("precision", precision)
        }
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    ret
  }

  def runTeamCode(teamCodeUrl: String, deliveryLgt: String, deliveryLat: String) = {
    val re = new JSONObject()
    try {
      if (!deliveryLgt.isEmpty && !deliveryLat.isEmpty) {
        val url = String.format(teamCodeUrl, deliveryLgt, deliveryLat)
        val tc: JSONObject = HttpClientUtil.getJsonByGet(url)
        re.put("rerunTeam", tc.toJSONString)
        if (tc != null && tc.getJSONObject("result") != null) {
          val tcArray = tc.getJSONObject("result").getJSONArray("map_data")
          if (tcArray != null && tcArray.size() > 0) {
            for (i <- 0 to tcArray.size() - 1) {
              val job = tcArray.getJSONObject(i)
              if (JSONUtil.getJsonVal(job, "level", "") == "3") {
                val eTeamCode = JSONUtil.getJsonVal(job, "code", "")
                re.put("TeamCode", eTeamCode)

              }
            }
          }
        }
      }
    } catch {
      case x: Exception => logger.error(x)
        re.put("myException", x.toString)
    }
    re
  }


  //调mapa，ts，54接口获取tc
  def runXyTc(obj: JSONObject) = {
    var mapxy: JSONObject = new JSONObject()
    var mapxy_x = ""
    var mapxy_y = ""
    var mapTeamCode = ""

    //        val teamCode = JSONUtil.getJsonVal(obj, "teamCode", "")
    //改
    val city_code = JSONUtil.getJsonVal(obj, "city_code", "")
    val address = JSONUtil.getJsonVal(obj, "address", "")


    //调Mapa接口
    mapxy = runMapXyInteface(mapa_url, city_code, address)
    mapxy_x = JSONUtil.getJsonVal(mapxy, "x", "")
    mapxy_y = JSONUtil.getJsonVal(mapxy, "y", "")

    //mapa xy获取tc
    val mapTc = runTeamCode(runTcUrl, mapxy_x, mapxy_y)
    mapTeamCode = JSONUtil.getJsonVal(mapTc, "TeamCode", "")
    mapxy.put("mapReqTc", mapTc.toJSONString)
    obj.put("mapa_tc", mapTeamCode)
    obj.put("mapxy", mapxy)
    obj.put("mapxy_x", mapxy_x)
    obj.put("mapxy_y", mapxy_y)


    //调图商接口
    val tsxy = runMapXyInteface(ts_url, city_code, address)
    val tsxy_x = JSONUtil.getJsonVal(tsxy, "x", "")
    val tsxy_y = JSONUtil.getJsonVal(tsxy, "y", "")
    //图商xy获取tc
    val tsTc = runTeamCode(runTcUrl, tsxy_x, tsxy_y)
    val tsTeamCode = JSONUtil.getJsonVal(tsTc, "TeamCode", "")
    tsxy.put("tsReqTc", tsTc.toJSONString)
    obj.put("ts_tc", tsTeamCode)
    obj.put("tsxy", tsxy)
    obj.put("tsxy_x", tsxy_x)
    obj.put("tsxy_y", tsxy_y)
    //54坐标获取tc
    val x54 = JSONUtil.getJsonVal(obj, "consign_lgt", "")
    val y54 = JSONUtil.getJsonVal(obj, "consign_lat", "")
    val Tc54req = runTeamCode(runTcUrl, x54, y54)
    val Tc54 = JSONUtil.getJsonVal(tsTc, "TeamCode", "")
    obj.put("54ReqTc", Tc54req.toJSONString)
    obj.put("54_tc", Tc54)
    obj
  }


  def getTc(runUrlRdd: RDD[JSONObject]) = {

    val re = runUrlRdd.repartition(seg_partition).map(

      obj => {
        val tag2 = JSONUtil.getJsonVal(obj, "tag2", "")
        val reObj = runXyTc(obj)
        if (tag2.equals("emp_false") || tag2.equals("bg_false")) {
          val team = JSONUtil.getJsonVal(reObj, "team", "")
          var mapTeamCode = JSONUtil.getJsonVal(reObj, "mapa_tc", "")
          var tsTeamCode = JSONUtil.getJsonVal(reObj, "ts_tc", "")
          var Tc54 = JSONUtil.getJsonVal(reObj, "54_tc", "")
          //判断3者是否相等
          if (!mapTeamCode.isEmpty && mapTeamCode.equals(tsTeamCode) && mapTeamCode.equals(team)) {
            tag2 match {
              case "bg_false" => reObj.put("tag3", "bg_sy")
              case _ => reObj.put("tag3", "xg_sy")

            }
          } else if (Tc54.nonEmpty && Tc54.equals(team)) {
            tag2 match {
              case "bg_false" => reObj.put("tag3", "bg_54")
              case _ => reObj.put("tag3", "xg_54")
            }
          } else {
            reObj.put("tag3", "all_false")
          }
        }
        reObj
      }
    ).persist(StorageLevel.MEMORY_AND_DISK)
    re
  }

  def saveTable(spark: SparkSession, checkOverRdd: RDD[((String, String, String, String), result)], detailRdd: RDD[JSONObject], incDay: String): Unit = {
    import spark.implicits._
    //明细表入库
    val rowDf = detailRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()


    logger.error("入明细表数量：" + rowDf.count())
    val tableName = "dm_gis.test_kuaiyun_detail_di" //生产数据表
    //    val tableName = "dm_gis.test_kuaiyun_detail_di1" //测试数据表
    rowDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

    //汇总表入库
    val wdDf = checkOverRdd.map(obj => obj._2).toDF()
    logger.error("入统计表数量：" + wdDf.count())
    wdDf.take(2).foreach(obj => {
      logger.error(obj.toString())
    })
    val wdTableName = "dm_gis.kuaiyun_receipt_wd_di" //生产表
    //    val wdTableName = "dm_gis.kuaiyun_receipt_wd_di1" //测试表
    wdDf.withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(wdTableName)

  }


  //incDay:t-2  T1Day:t-1 T3Day:t-3 T4Day:t-4
  def getDataDf(spark: SparkSession, incDay: String, sepDay: String, T1Day: String, T3Day: String, T4Day: String, formatDay1: String, formatDay3: String) = {
    //获取数据源
    val dataRddSql =
      """
        |select
        | a.inc_day
        |,a.city_code
        |,a.unit_code
        |,a.status
        |,a.remark
        |,a.sys_order_id
        |,a.update_time
        |,a.oms_order_no
        |,a.express_address
        |,a.teamid
        |,a.old_teamid
        |,a.data_type
        |,a.task_status
        |,a.sys_order_no
        |,a.responsible
        |,a.employee_code
        |,a.transfor_emp
        |,a.unit_area_code
        |,a.new_unit_area_code
        |,a.address
        |,a.emp_code
        |,a.pickup_emp_code
        |,a.est_weight
        |,a.tc_list1
        |,a.tc_list2
        |,a.waybill_no
        |,a.recv_bar_tm
        |,a.consign_lgt
        |,a.consign_lat
        |,a.recv_bar_dept_code
        |,a.aoiId
        |,a.citycode
        |,a.uno
        |,a.ak
        |,a.team
        |,a.createTime
        |,a.src
        |,a.reqType
        |,a.emp_code_task_express
        |,a.meterage_weight_qty --计费总重量
        |,a.real_weight_qty --实际重量
        |,a.order_no --订单号
        |,a.meterage_weight_qty_kg --计费总重量（kg）
        |,a.real_weight_qty_kg --实际总重量（kg）
        |from(
        |
        |select
        |a.inc_day
        |,a.city_code
        |,a.unit_code
        |,a.status
        |,a.remark
        |,a.sys_order_id
        |,a.update_time
        |,task_express.oms_order_no
        |,task_express.address as  express_address
        |,task_express.teamid
        |,task_express.old_teamid
        |,task_express.data_type
        |,task_express.task_status
        |,record_sheet.sys_order_no
        |,record_sheet.responsible
        |,record_sheet.employee_code
        |,nvl(record_sheet.transfor_emp,'1') as transfor_emp
        |,record_sheet.unit_area_code
        |,record_sheet.new_unit_area_code
        |,d.address
        |,a.emp_code
        |,b.pickup_emp_code
        |,b.est_weight
        |,c.unit_code_list as tc_list1
        |,f.tc_list2
        |,b.waybill_no
        |,e.recv_bar_tm
        |,e.consign_lgt
        |,e.consign_lat
        |,e.recv_bar_dept_code
        |,d.aoiId
        |,d.citycode
        |,d.uno
        |,d.ak
        |,d.team
        |,d.createTime
        |,d.src
        |,d.reqType
        |,task_express.emp_code as emp_code_task_express
        |,g.meterage_weight_qty --计费总重量
        |,g.real_weight_qty --实际重量
        |,g.order_no --订单号
        |,g.meterage_weight_qty_kg --计费总重量（kg）
        |,g.real_weight_qty_kg --实际总重量（kg）
        |,row_number() over(partition by sys_order_id order by update_time desc) as rn
        |from (
        |
        |	select
        |	inc_day
        |	,city_code
        |	,unit_code
        |	,status
        |	,remark
        |	,sys_order_id
        |	,update_time
        |	,emp_code
        |	,row_number() over(partition by sys_order_id order by update_time desc) as rank1
        |	from ky.ods_oss_dispatch.et_sgs_match_bro_resp_info
        |	where inc_day='%s'
        |)a
        |
        |left join
        |(
        |	SELECT
        |	 oms_order_no
        |	,address
        |	,teamid
        |	,old_teamid
        |	,data_type
        |	,task_status
        |	,emp_code
        |	,row_number()over(partition by oms_order_no order by modify_time desc ) rn
        |	FROM
        |	dm_gis.tt_task_express
        |	where inc_day between '%s' and '%s' and oms_order_no is not null
        |) task_express
        |on a.sys_order_id = task_express.oms_order_no and task_express.rn = 1
        |
        |left join
        |(
        |	select sys_order_no
        |	,responsible
        |	,employee_code
        |	,data_type
        |	,unit_area_code
        |	,new_unit_area_code
        |	,if(transfor_emp is null or transfor_emp = '','2',transfor_emp) transfor_emp
        |	,row_number()over(partition by sys_order_no order by modify_time desc ) rn
        |	from dm_gis.tt_task_express_record_sheet
        |	where inc_day  between '%s' and '%s' and sys_order_no is not null
        |) record_sheet
        |on a.sys_order_id = record_sheet.sys_order_no and record_sheet.rn = 1
        |--获取请求日志数据
        |left join
        |(
        |select
        |address
        |,aoiId
        |,citycode
        |,uno
        |,ak
        |,team
        |,createTime
        |,src
        |,reqType
        | from (
        |	select
        |	get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.request'),'$.address') address,
        |	get_json_object(get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.atResult'),'$.result'),'$.aoiId') aoiId,
        |	get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.request'),'$.citycode') citycode,
        |	get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.request'),'$.uno') uno,
        |	get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.request'),'$.ak') ak,
        |	get_json_object(get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.response'),'$.data'),'$.team') team,
        |	get_json_object(`log`,'$.createTime') createTime,
        |	get_json_object(get_json_object(`log`,'$.message'),'$.src') src,
        |	row_number() over(partition by get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.request'),'$.uno') order by get_json_object(`log`,'$.createTime') asc) as rank1,
        |	get_json_object(get_json_object(`log`,'$.message'),'$.reqType') reqType
        |	from dm_gis.kuaiyun_log_flink
        |	where  inc_day between '%s' and '%s'
        |	and get_json_object(get_json_object(`log`,'$.message'),'$.reqType')='CONSIGN'
        |	and get_json_object(get_json_object(get_json_object(`log`,'$.message'),'$.request'),'$.ak') in ('99f1a41e5fb245f1a9a93a1ec613d21b','a4f3c06085e64df18d1aedfa4dcebe35')
        |	)a
        |	 where rank1=1
        |)d
        |on a.sys_order_id=d.uno
        |
        |--获取dwd.dwd_pub_order_dtl_di
        |left join
        |(
        |	--去重
        |	select
        |	a.src_order_no
        |	,a.waybill_no[0] as waybill_no
        |	,a.pickup_emp_code
        |	,a.est_weight
        |	from
        |	dwd.dwd_pub_order_dtl_di  a
        |	where a.inc_day between  '%s'  AND  '%s'
        |) b
        |on a.sys_order_id = b.src_order_no
        |--取unit_code_list1
        |left join(
        |	Select emp_code,concat_ws(',',collect_set(cast(zone_code as string))) as unit_code_list
        |	from
        |	ky.ods_oss.et_employee_pd_schedule_info
        |	where inc_day = '%s' and schedule_type='1'
        |	group by emp_code
        |) c
        |on a.emp_code = c.emp_code
        |--取unit_code_list2
        |left join(
        |	select backup_emp_code,concat_ws(',',collect_set(cast(zone_code as string))) as tc_list2 from
        |	ky.ods_oss.et_employee_backup_schedule_info
        |	where inc_day = '%s'  and schedule_type='1'
        |	group by backup_emp_code
        |	) f
        |on a.emp_code = f.backup_emp_code
        |left join
        |(
        |--获取 t-3到t-1的54经纬度
        |select
        |     b.waybill_no
        |    ,b.recv_bar_tm --收件巴枪扫描时间
        |    ,b.consign_lgt --收件巴枪操作经度
        |    ,b.consign_lat --收件巴枪操作纬度
        |    ,b.recv_bar_dept_code    --收件巴枪扫描时所在网点
        |from
        |(
        |    select
        |         t.waybillno 		  as waybill_no
        |        ,t.operatime_new 	as recv_bar_tm
        |        ,t.eventlng 		    as consign_lgt
        |        ,t.eventlat 		    as consign_lat
        |        ,t.org_code			  as recv_bar_dept_code
        |        ,t.inc_day
        |    from
        |       (
        |       select
        |		   waybillno
        |		  ,operatime_new
        |		  ,eventlng
        |		  ,eventlat
        |		  ,org_code
        |		  ,inc_day
        |		 ,row_number() over(partition by waybillno order by operatime_new ) as rn
        |         from ods_inc_sgs_core.inc_sgs_task_flow_new
        |         where inc_day>='%s' and inc_day<='%s' and eventtype in('31201','31127','31133','31134','31145')
        |       )t
        |       where t.rn=1
        |	   )b
        |)e
        |on b.waybill_no = e.waybill_no
        |--取运单宽表 dwd.dwd_waybill_info_dtl_di
        |left join(
        |	select
        |	 waybill_no --运单号
        |	,meterage_weight_qty --计费总重量
        |	,real_weight_qty --实际重量
        |	,order_no --订单号
        |	,meterage_weight_qty_kg --计费总重量（kg）
        |	,real_weight_qty_kg --实际总重量（kg）
        |	from  dwd.dwd_waybill_info_dtl_di
        |	where inc_day between  '%s'  AND  '%s'
        |)g
        |on b.waybill_no = g.waybill_no
        |where a.rank1=1
        |)a
        |where rn = 1
      """.stripMargin


    val dataSql = String.format(dataRddSql, incDay, T3Day, T1Day, T3Day, T1Day, T3Day, T1Day, T4Day, T1Day, incDay, incDay, T3Day, T1Day, T4Day, T1Day)


    logger.error(dataSql)

    val dataDf = spark.sql(dataSql).repartition(sqlpartition).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("获取数据量：" + dataDf.count())
    logger.error(dataDf.show(10, false))
    dataDf.createOrReplaceTempView("dataTable")


    val totalRdd = SparkUtils.getRowToJson(spark, dataSql).repartition(sqlpartition)
    logger.error(totalRdd.take(10).foreach(println(_)))

    totalRdd
  }


  //aoi调切片获取code
  def getCode(aoiId: String) = {
    val buff = new StringBuffer()
    var ret: JSONObject = null
    val url = String.format(qp_url, aoiId)
    logger.error(url)
    try {
      ret = HttpClientUtil.getJsonByGet(url)
      val data = ret.getJSONArray("data")
      for (i <- 0 until data.size()) {
        val code = JSONUtil.getJsonVal(data.getJSONObject(i), "code", "")
        if (code.nonEmpty && i < data.size() - 1) buff.append(code).append(",")
        else buff.append(code)
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    (buff.toString, ret)
  }


  def getBybgTag(obj: JSONObject) = {
    val responsible = JSONUtil.getJsonVal(obj, "responsible", "")
    val tc_list = JSONUtil.getJsonVal(obj, "tc_list", "")
    val team = JSONUtil.getJsonVal(obj, "team", "")

    if (responsible.equals("3")) obj.put("tag2", "bg_yw")
    //    else if (tc_list.isEmpty) obj.put("tag2", "tc_list_empty")
    else if (tc_list.split(",").contains(team)) obj.put("tag2", "bg_yw")
    else obj.put("tag2", "bg_false")
    obj
  }

  //汇总
  //根据地区汇总
  def getstaIndexRdd(cityCode: String, city: String, region: String, stat_type: String, obj: JSONObject) = {

    var adressEmptyCnt
    , unidentifiedCnt
    , rangeOutCnt
    , recognitionCnt
    , pbYwCnt
    , pbFlaseCnt
    , bgYwCnt
    , bgFlaseCnt
    , empcodeEmptyCnt
    , xgYwCnt
    , unitCodeEmptyCnt
    , empFlaseCnt
    , pbSyCnt
    , bgSyCnt
    , xgSyCnt
    , pb54Cnt
    , bg54Cnt
    , xg54Cnt
    , reAddressCnt
    , reAddresshisCnt
    , reSignCnt
    , reMapbCnt
    , ksCnt
    , falseAddressCnt
    , falseAddresshisCnt
    , falseSignCnt
    , falseMapbCnt
    , nozcDataCnt

    , unoNullCnt
    , unitNullCnt
    , pbAllCnt
    , customerCnt
    , transforServiceCnt
    , allFalseCnt
    , bgNoschCnt
    , false_ks_cnt
    , artificial_1_cnt
    , cus_weight_wr_1_cnt
    , artificial_2_cnt
    , schedule_wr_cnt
    , cus_weight_wr_2_cnt
    , rec_wr_cnt
    , rec_wr_address_cnt
    , rec_wr_addresshis_cnt
    , rec_wr_sign_cnt
    , rec_wr_mapb_cnt
    , rec_wr_ks_cnt
    = 0
    val tag = JSONUtil.getJsonVal(obj, "tag", "")
    val tag2 = JSONUtil.getJsonVal(obj, "tag2", "")
    val tag3 = JSONUtil.getJsonVal(obj, "tag3", "")
    val tag4 = JSONUtil.getJsonVal(obj, "tag4", "")
    val wr_tag = JSONUtil.getJsonVal(obj, "wr_tag", "")
    //    val cityCode = JSONUtil.getJsonVal(obj, "city_code", "")
    //    val region = JSONUtil.getJsonVal(obj, "region", "")
    //    val city = JSONUtil.getJsonVal(obj, "city", "")
    val src = JSONUtil.getJsonVal(obj, "src", "").toUpperCase

    if (tag.equals("address_empty")) adressEmptyCnt = 1
    if (tag.equals("unidentified")) unidentifiedCnt = 1
    if (tag.equals("range_out")) rangeOutCnt = 1
    if (tag.equals("recognition")) recognitionCnt = 1
    if (tag.equals("uno_null")) unoNullCnt = 1
    if (tag.equals("unit_null")) unitNullCnt = 1


    if (tag2.equals("pb_yw")) pbYwCnt = 1
    if (tag2.equals("pb_false")) pbFlaseCnt = 1
    if (tag2.equals("bg_yw")) bgYwCnt = 1
    if (tag2.equals("bg_false")) bgFlaseCnt = 1
    if (tag2.equals("empcode_empty")) empcodeEmptyCnt = 1
    if (tag2.equals("xg_yw")) xgYwCnt = 1
    if (tag2.equals("bg_nosch")) bgNoschCnt = 1
    if (tag2.equals("tc_list_empty")) unitCodeEmptyCnt = 1
    if (tag2.equals("empFlaseCnt")) empFlaseCnt = 1

    if (tag2.equals("pb_all")) pbAllCnt = 1
    if (tag2.equals("emp_false")) customerCnt = 1
    if (tag2.equals("transfor_service")) transforServiceCnt = 1


    if (tag3.equals("pb_sy")) pbSyCnt = 1
    if (tag3.equals("bg_sy")) bgSyCnt = 1
    if (tag3.equals("xg_sy")) xgSyCnt = 1
    if (tag3.equals("pb_54")) pb54Cnt = 1
    if (tag3.equals("bg_54")) bg54Cnt = 1
    if (tag3.equals("xg_54")) xg54Cnt = 1
    if (tag3.equals("all_false")) allFalseCnt = 1


    if (tag4.equals("nozcdata")) nozcDataCnt = 1

    if (tag.equals("recognition")) {
      src match {
        case "ADDRESS" => reAddressCnt = 1
        case "ADDRESSHIS" => reAddresshisCnt = 1
        case "SIGN" => reSignCnt = 1
        case "MAPB" => reMapbCnt = 1
        case "KS" => ksCnt = 1
        case _ =>
      }
    }

    if (tag3.equals("all_false")) {
      src match {
        case "ADDRESS" => falseAddressCnt = 1
        case "ADDRESSHIS" => falseAddresshisCnt = 1
        case "SIGN" => falseSignCnt = 1
        case "MAPB" => falseMapbCnt = 1
        case "KS" => false_ks_cnt = 1
        case _ =>
      }
    }
    wr_tag match {
      case "artificial_1" => artificial_1_cnt = 1
      case "cus_weight_wr_1" => cus_weight_wr_1_cnt = 1
      case "artificial_2" => artificial_2_cnt = 1
      case "schedule_wr" => schedule_wr_cnt = 1
      case "cus_weight_wr_2" => cus_weight_wr_2_cnt = 1
      case "rec_wr" => {
                       rec_wr_cnt = 1
                       src match {
                         case "ADDRESS" => rec_wr_address_cnt = 1
                         case "ADDRESSHIS" => rec_wr_addresshis_cnt = 1
                         case "SIGN" => rec_wr_sign_cnt = 1
                         case "MAPB" => rec_wr_mapb_cnt = 1
                         case "KS" => rec_wr_ks_cnt = 1
                         case _ =>
                       }
      }
      case _ =>
    }




    result(
      cityCode
      , city
      , region
      , adressEmptyCnt
      , unidentifiedCnt
      , rangeOutCnt
      , recognitionCnt
      , pbYwCnt
      , pbFlaseCnt
      , bgYwCnt
      , bgFlaseCnt
      , empcodeEmptyCnt
      , xgYwCnt
      , unitCodeEmptyCnt
      , empFlaseCnt
      , pbSyCnt
      , bgSyCnt
      , xgSyCnt
      , pb54Cnt
      , bg54Cnt
      , xg54Cnt
      , reAddressCnt
      , reAddresshisCnt
      , reSignCnt

      , falseAddressCnt
      , falseAddresshisCnt
      , falseSignCnt
      , falseMapbCnt
      , reMapbCnt
      , stat_type
      , nozcDataCnt
      //--cxg
      , unoNullCnt
      , unitNullCnt
      , pbAllCnt
      , customerCnt
      , transforServiceCnt
      , allFalseCnt
      , bgNoschCnt
      , ksCnt
      , false_ks_cnt
      , artificial_1_cnt
      , cus_weight_wr_1_cnt
      , artificial_2_cnt
      , schedule_wr_cnt
      , cus_weight_wr_2_cnt
      , rec_wr_cnt
      , rec_wr_address_cnt
      , rec_wr_addresshis_cnt
      , rec_wr_sign_cnt
      , rec_wr_mapb_cnt
      , rec_wr_ks_cnt
    )

  }

  //打wr_tag
  def getWrTag(rdd: RDD[JSONObject]) = {


    logger.error("打wr_tag的数据量：" + rdd.count())
    var wrRdd = rdd.repartition(seg_partition).map(obj => {
      val sys_order_no = JSONUtil.getJsonVal(obj, "sys_order_no", "")
      val team = JSONUtil.getJsonVal(obj, "team", "")
      val est_weight = JSONUtil.getJsonVal(obj, "est_weight", "")
      val real_weight_qty_kg = JSONUtil.getJsonVal(obj, "real_weight_qty_kg", "")
      val data_type = JSONUtil.getJsonVal(obj, "data_type", "")


      if (sys_order_no.nonEmpty && (team.isEmpty || team.equals("null"))) {
        if (est_weight.nonEmpty && real_weight_qty_kg.nonEmpty && est_weight.toDouble >= 20 && real_weight_qty_kg.toDouble >= 20) obj.put("wr_tag", "artificial_1") else obj.put("wr_tag", "cus_weight_wr_1")
        obj
      } else if (sys_order_no.nonEmpty) {
        val reObj = runXyTc(obj)

        var mapTeamCode = JSONUtil.getJsonVal(reObj, "mapa_tc", "")
        var tsTeamCode = JSONUtil.getJsonVal(reObj, "ts_tc", "")
        var Tc54 = JSONUtil.getJsonVal(reObj, "54_tc", "")

        //判断3者是否相等,不相等判断tc54
        if (!(!mapTeamCode.isEmpty && mapTeamCode.equals(tsTeamCode) && mapTeamCode.equals(team) && Tc54.equals(team))) reObj.put("wr_tag", "rec_wr")

        //剩下3者相等部分，统一判断逻辑
        var wr_tag = JSONUtil.getJsonVal(reObj, "wr_tag", "")
        if (wr_tag.isEmpty && mapTeamCode.nonEmpty && mapTeamCode.equals(tsTeamCode) && mapTeamCode.equals(team)) {
          if (!(est_weight.nonEmpty && real_weight_qty_kg.nonEmpty && est_weight.toDouble >= 20 && real_weight_qty_kg.toDouble >= 20)) obj.put("wr_tag", "cus_weight_wr_2")
          else if (!data_type.equals("2")) obj.put("wr_tag", "schedule_wr")
          else obj.put("wr_tag", "artificial_2")
        }
        reObj
      } else obj
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("打完wr_tag的数据量：" + wrRdd.count())
    logger.error("没打wr_tag的数据量：" + wrRdd.filter(obj => JSONUtil.getJsonVal(obj, "wr_tag", "").isEmpty).count())
    logger.error("打wr_tag的数据量：" + wrRdd.filter(obj => JSONUtil.getJsonVal(obj, "wr_tag", "").nonEmpty).count())
    wrRdd.take(2).foreach(println(_))
    wrRdd
  }


}
