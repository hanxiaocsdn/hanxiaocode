package com.sf.gis.scala.debang.kuaiYun

import java.net.URLEncoder

import com.alibaba.fastjson.{JSONArray, JSONObject}
import com.sf.gis.scala.base.util.{DateUtil, HttpClientUtil, Util}
import com.sf.gis.scala.debang.util.{JSONUtil, SparkUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

/**
  * create by 01412406
  * 【派件上楼】下单环节数据闭环工艺
  * id：484714
  * 负责人：李嘉欣(01412989)
  */


object dispatchUpstairsOrderCloopV2 {
  @transient lazy val logger: Logger = Logger.getLogger(dispatchUpstairsOrderCloopV2.getClass)
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val version = 1.0
  println(version)
  val seg_partition = 5
  val sqlpartition = 200
  val url = "http://gis-int.int.sfdc.com.cn:1080/elevator/api/delete?ak=379924356e8b444da83f04ebb1703f19&target=%s&cityCode=%s&id=%s&source=%s&updateBy=00000001&updateReason=S100-外包核实"
  val cmsUrl = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressId=%s"
  val updataUrl = "http://gis-int.int.sfdc.com.cn:1080/elevator/api/add?ak=379924356e8b444da83f04ebb1703f19&target=%s&cityCode=%s&id=%s&isElevator=%s&isClimb=%s&source=100&updateBy=00000001&updateReason=S100-外包核实"

  case class result(
                     addr:String
                     ,dest_dist_code:String
                     ,group_id:String
                     ,aoi_id:String
                     ,src:String
                     ,iselevator:String
                     ,isclimb:String
                     ,message:String
                     ,service_fee:String
                     ,xg_id:String
                     ,zno_code:String
                     ,addr_ele:String
                     ,aoi_ele:String
                     ,bu_tag:String

                   )
  def main(args: Array[String]): Unit = {
    val startDay = args.apply(0)
    logger.error("起始时间:" + startDay)
    start(startDay)
    logger.error("结束所有运行")

  }

  //  t-2 startDay:2021-08-23
  def start(startDay: String): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    // beforDay是每月24号，afterDay 1号 startDay分区时间：25号
    val afterDay = DateUtil.getDateStr(startDay, -24)
    val beforDay = DateUtil.getDateStr(startDay, -1)
    logger.error(s"分区时间${startDay}=====>开始计算：" + beforDay + "截止时间" + afterDay)
    startSta(spark, startDay, afterDay, beforDay)
    logger.error("计算结束：" + startDay)
    //        }
    logger.error("统计完毕")
  }


  def startSta(spark: SparkSession, incDay: String, afterDay: String, beforDay: String) = {
    logger.error("获取数据源")
    //取数据源
    val dataRdd = getData(spark, afterDay, beforDay, incDay)
    logger.error("数据分组")
    val (unionRdd, unaddreleRdd, unaoieleRdd) = getGroupData(dataRdd)
    logger.error("打标签")
    val checkRdd = checkTag(unionRdd)
    logger.error("判断aoi_ele更新ele")
    val unionAoieleRdd = updataEle(unaoieleRdd)
    logger.error("addr下线数据")
    val unionAddreleRdd = updataAddrEle(unaddreleRdd)
    val reRdd = checkRdd.union(unionAoieleRdd).union(unionAddreleRdd)
    logger.error("开始入库")
    saveTable(spark, reRdd, afterDay)
    logger.error("结束所有运行")

  }


  //入库
  def saveTable(spark: SparkSession, reRdd: RDD[JSONObject], incDay: String): Unit = {
    //明细表入库

    val tableName = "dm_gis.aoiele_operate_addedvalue_result_detail" //生产数据表
    val reTableName = "dm_gis.aoiele_operate_addedvalue"


    import spark.implicits._
    //明细表入库
    val rowDf = reRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error(s"入明细表数量：${tableName}:分区：${incDay}" + rowDf.count())
    rowDf.coalesce(100).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(tableName)

    logger.error("入汇总表数量：" + reRdd.count())
    import spark.implicits._
    val saveRdd = reRdd.map(o => {
      val addr = JSONUtil.getJsonVal(o, "addr", "")
      val dest_dist_code = JSONUtil.getJsonVal(o, "dest_dist_code", "")
      val group_id = JSONUtil.getJsonVal(o, "group_id", "")
      val aoi_id = JSONUtil.getJsonVal(o, "aoi_id", "")
      val src = JSONUtil.getJsonVal(o, "src", "")
      val iselevator = JSONUtil.getJsonVal(o, "iselevator", "")
      val isclimb = JSONUtil.getJsonVal(o, "isclimb", "")
      val message = JSONUtil.getJsonVal(o, "message", "")
      val service_fee = JSONUtil.getJsonVal(o, "service_fee", "")
      val xg_id = JSONUtil.getJsonVal(o, "xg_id", "")
      val zno_code = JSONUtil.getJsonVal(o, "zno_code", "")
      val bu_tag = JSONUtil.getJsonVal(o, "bu_tag", "")
      val addr_ele = JSONUtil.getJsonVal(o, "addr_ele", "")
      val aoi_ele = JSONUtil.getJsonVal(o, "aoi_ele", "")

      result(
        addr
        , dest_dist_code
        , group_id
        , aoi_id
        , src
        , iselevator
        , isclimb
        , message
        , service_fee
        , xg_id
        ,zno_code
        ,addr_ele
        ,aoi_ele
        ,bu_tag
      )
    }).toDF


    logger.error(reTableName + "=========>" + incDay)
    saveRdd.coalesce(10).withColumn("inc_day", lit(incDay)).write.mode(SaveMode.Overwrite).insertInto(reTableName)
  }

  //获取数据
  def getData(spark: SparkSession, afterDay: String, beforDay: String, incDay: String) = {

    //月初数据
    val baseSql =
      s"""
         |select
         |a.*
         |,b.aoi_ele
         |,b.addr_ele
         |,c.source_aoi
         |,d.source_group
         |from dm_gis.aoiele_operate_addedvalue a
         |left join
         |(
         |select
         |address
         |,if(aoi_ele = '2',0,aoi_ele) as aoi_ele
         |,if(addr_ele = '2',0,addr_ele) as addr_ele
         |--from dm_gis.aoieletask_result
         |--where inc_day between '${afterDay}' and '${beforDay}'
         |from default.jxtest_aoieletask_result
         |group by address
         |,if(aoi_ele = '2',0,aoi_ele)
         |,if(addr_ele = '2',0,addr_ele)
         |)b
         |on a.addr = b.address
         |left join
         |(
         |select
         |aoi_id
         |,concat_ws(',', collect_set(source)) as source_aoi
         |from dm_gis.td_aoi_elevator_result
         |where update_day = '${incDay}'
         |group by aoi_id
         |)c
         |on a.aoi_id = c.aoi_id
         |left join
         |(
         |select
         |aoi_id
         |,concat_ws(',', collect_set(source)) as source_group
         |from dm_gis.td_group_elevator_result
         |where update_day = '${incDay}'
         |group by aoi_id
         |)d
         |on a.aoi_id = d.aoi_id
         |where a.inc_day = '${afterDay}'
      """.stripMargin


    logger.error(baseSql)

    val totalRdd = SparkUtils.getRowToJson(spark, baseSql).map(o => {
      o.remove("inc_day")
      o
    })

    logger.error("获取到的数据量：" + totalRdd.count())

    totalRdd
  }

  //获取业务数据
  def getBusinessData(spark: SparkSession, incDay: String) = {

    val beforeDay = DateUtil.getDateStr(incDay, -30)
    val lastDay = DateUtil.getDateStr(incDay, -1)
    val last13Day = DateUtil.getDateStr(incDay, -13)

    //基本数据
    val baseSql =
      """
        |select
        |group_id
        |,aoi_id
        |from dm_gis.aoiele_operate_addedvalue
        |where bu_tag is not null or bu_tag <>''
        |group by
        |group_id
        |,aoi_id
      """.stripMargin
    val bSql = String.format(baseSql, lastDay)

    logger.error("tmp====>" + bSql)

    val groupRdd = SparkUtils.getRowToJson(spark, bSql).map(o => (JSONUtil.getJsonVal(o, "group_id", ""), false)).filter(_._1.nonEmpty)
    val aoiRdd = SparkUtils.getRowToJson(spark, bSql).map(o => (JSONUtil.getJsonVal(o, "aoi_id", ""), false)).filter(_._1.nonEmpty)
    logger.error("取到group_id业务数据量" + groupRdd.count())
    logger.error("取到aoi_id业务数据量" + aoiRdd.count())
    (groupRdd, aoiRdd)
  }

  //数据分组
  def getGroupData(dataRdd: RDD[JSONObject]) = {

    //判断src是否包含'group'

    val groupRdd = dataRdd.filter(o => JSONUtil.getJsonVal(o, "src", "").contains("group")).persist(StorageLevel.MEMORY_AND_DISK)
    val ungroupRdd = dataRdd.filter(o => !JSONUtil.getJsonVal(o, "src", "").contains("group")).persist(StorageLevel.MEMORY_AND_DISK)

    logger.error("src是否包含'group'的数据量：" + groupRdd.count())
    logger.error("src不包含'group'的数据量：" + ungroupRdd.count())

    val addreleRdd = groupRdd.filter(o =>
      JSONUtil.getJsonVal(o, "iselevator", "").nonEmpty &&  JSONUtil.getJsonVal(o, "iselevator", "").equals(JSONUtil.getJsonVal(o, "addr_ele", "")))
    val unaddreleRdd = groupRdd.filter(o => !(
     JSONUtil.getJsonVal(o, "iselevator", "").nonEmpty && JSONUtil.getJsonVal(o, "iselevator", "").equals(JSONUtil.getJsonVal(o, "addr_ele", ""))
      )).persist(StorageLevel.MEMORY_AND_DISK)
    val aoieleRdd = ungroupRdd.filter(o =>
      JSONUtil.getJsonVal(o, "iselevator", "").nonEmpty && JSONUtil.getJsonVal(o, "iselevator", "").equals(JSONUtil.getJsonVal(o, "aoi_ele", "")))
    val unaoieleRdd = ungroupRdd.filter(o => !(
      JSONUtil.getJsonVal(o, "iselevator", "").nonEmpty && JSONUtil.getJsonVal(o, "iselevator", "").equals(JSONUtil.getJsonVal(o, "aoi_ele", ""))
      )).persist(StorageLevel.MEMORY_AND_DISK)
    val unionRdd = addreleRdd.union(aoieleRdd).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("只打标签的数据量：" + unionRdd.count())
    logger.error("需要下线的数据量：" + unaddreleRdd.count())
    logger.error("判断aoi_ele的数据量：" + unaoieleRdd.count())
    groupRdd.unpersist()
    ungroupRdd.unpersist()
    (unionRdd, unaddreleRdd, unaoieleRdd)
  }

  def checkTag(dataRdd: RDD[JSONObject]) = {
    val reRdd = dataRdd.map(o => {
      val isclimb = JSONUtil.getJsonVal(o, "isclimb", "")
      if (isclimb.equals("1")) o.put("bu_tag", "climb_uncharge")
      else if (isclimb.equals("0")) o.put("bu_tag", "unclimb_charge")
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("打完标签的数据量：" + reRdd.count())
    reRdd.take(2).foreach(logger.error(_))
    dataRdd.unpersist()
    reRdd
  }

  //更新ele
  def updataEle(dataRdd: RDD[JSONObject]) = {

    val reRdd =  dataRdd.repartition(20).map(o => {
      val aoi_ele = JSONUtil.getJsonVal(o, "aoi_ele", "")
      val dest_dist_code = JSONUtil.getJsonVal(o, "dest_dist_code", "")
      val aoi_id = JSONUtil.getJsonVal(o, "aoi_id", "")
      val source = JSONUtil.getJsonVal(o, "source_aoi", "").split(",")
      if (Array("1", "0", "4").contains(aoi_ele)) {
        //调接口下线

        source.foreach(o1=>{
          val formatUrl = String.format(url,"aoi",dest_dist_code,aoi_id,o1)
          val reJson =  HttpClientUtil.getJsonByGet(formatUrl)
          if(reJson != null)o.put(s"aoiReq_${o1}",reJson.toJSONString)
        })

        //上传数据

        //          2.上传
        //          接口：http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-int.int.sfdc.com.cn:1080/elevator/api/add&ak=379924356e8b444da83f04ebb1703f19&target=aoi&cityCode={}&id={}&isElevator={}&isClimb={}&source=100&updateBy=00000001&updateReason=S100-外包核实
        //          字段：cityCode = dest_dist_code, id = aoi_id,
        //          isElevator = aoi_ele(当aoi_ele= 4时为0，其余不变)
        //          isClimb:当aoi_ele=1,isClimb=0;当aoi_ele=0,isClimb=1;当aoi_ele=4,isClimb=0
        val  isElevator =  if(aoi_ele.equals("4")) "0" else aoi_ele
        val isClimb = if(aoi_ele.equals("1")) "0" else if(aoi_ele.equals("0")) "1" else "0"
        val formatUpdataUrl = String.format(updataUrl,"aoi",dest_dist_code,aoi_id,isElevator,isClimb)
        val reUpdataJson =  HttpClientUtil.getJsonByGet(formatUpdataUrl)
        if(reUpdataJson != null)o.put(s"UpdataAoiReq",reUpdataJson.toJSONString)


      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("跑完接口的数据量："+reRdd.count())
    reRdd.take(2).foreach(o=>logger.error(o.toJSONString))
    reRdd
  }


  def updataAddrEle(dataRdd: RDD[JSONObject]) = {

    val reRdd =  dataRdd.repartition(20).map(o => {
      val addr_ele = JSONUtil.getJsonVal(o, "addr_ele", "")
      val dest_dist_code = JSONUtil.getJsonVal(o, "dest_dist_code", "")
      val group_id = JSONUtil.getJsonVal(o, "group_id", "")
      val source = JSONUtil.getJsonVal(o, "source_group", "").split(",")

      val str = new StringBuffer()

      if (Array("1", "0").contains(addr_ele)) {

        //调接口下线
        source.foreach(o1 => {
          val formatUrl = String.format(url, "group", dest_dist_code, group_id, o1)
          val reJson = HttpClientUtil.getJsonByGet(formatUrl)
          if (reJson != null) o.put(s"groupReq_${o1}", reJson.toJSONString)
        })

        //groupid获取标准地址

        //      接口：http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode={}&addressId={}
        //      传参cityCode：dest_dist_code
        //      addressId ：group_id
        //      输出字段 ：address 命名为 std_addr
        val formatCmsUrl = String.format(cmsUrl, dest_dist_code, group_id)
        val cmsJson = HttpClientUtil.getJsonByGet(formatCmsUrl)
        if (cmsJson != null) {
          val std_addr = JSONUtil.getJsonVal(cmsJson, "data.address", "")
          o.put("cmsReq", cmsJson.toJSONString)
          o.put("std_addr", std_addr)

          //标准地址跑分词
          val normAdrrUrl = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=3eb300d2e06947f7945cd02530a32fd2"
          val formatNormAdrrUrl = String.format(normAdrrUrl, URLEncoder.encode(std_addr, "utf-8"), dest_dist_code)
          val normJson = HttpClientUtil.getJsonByGet(formatNormAdrrUrl)
          if (normJson != null) {
            o.put("normReq", normJson.toJSONString)

            val infoArray = JSONUtil.getJsonArrayFromObject(normJson, "result.data.info", new JSONArray())

            for (i <- 0 until infoArray.size()) {
              val resJson = infoArray.getJSONObject(i)
              val level = JSONUtil.getJsonVal(resJson, "level", "")
              if (i < infoArray.size() - 1) str.append(s"${level},") else str.append(s"${level}")
            }

            val levelList = str.toString
            o.put("levelList", levelList)
            //level 包含14或者包含9+10+11

            if (levelList.contains("14") || (levelList.contains("9") && levelList.contains("10") && levelList.contains("11"))) {
              //更新接口
              //上传数据
              //          2.上传
              //          接口：http://gis-ass-mg.sf-express.com/ScriptTool3215302/extension/forward?url=http://gis-int.int.sfdc.com.cn:1080/elevator/api/add&ak=379924356e8b444da83f04ebb1703f19&target=aoi&cityCode={}&id={}&isElevator={}&isClimb={}&source=100&updateBy=00000001&updateReason=S100-外包核实
              //              cityCode = dest_dist_code, id = group_id, isElevator = addr_ele,
              //              isClimb:当addr_ele=1,isClimb=0;当addr_ele=0,isClimb=1
              val isElevator = addr_ele
              val isClimb = if (addr_ele.equals("1")) "0" else if (addr_ele.equals("0")) "1" else ""
              val formatUpdataUrl = String.format(updataUrl, "group", dest_dist_code, group_id, isElevator, isClimb)
              val reGroupUpdataJson = HttpClientUtil.getJsonByGet(formatUpdataUrl)
              if (reGroupUpdataJson != null) o.put(s"updatagGroupReq", reGroupUpdataJson.toJSONString)


            }
          }

        }
      }
      o
    }).persist(StorageLevel.MEMORY_AND_DISK)
    logger.error("跑完接口的数据量："+reRdd.count())
    reRdd.take(2).foreach(o=>logger.error(o.toJSONString))
    reRdd
  }


}
