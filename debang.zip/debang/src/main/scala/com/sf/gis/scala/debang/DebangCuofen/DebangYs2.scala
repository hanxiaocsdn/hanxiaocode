package com.sf.gis.scala.debang.DebangCuofen

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.debang.util.{JSONUtil, SparkUtils, Util}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel

object DebangYs2 {
  val appName: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger(appName)

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().config(Util.getSparkConf(appName)).enableHiveSupport().getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")

    logger.error("开始执行")

    val sql =
      """
        |select
        |  citycode,address,aoiid,zc
        |from
        |  default.deppon_address_remove_conf_new
        | where
        |address = '广东省肇庆市四会市广东省肇庆四会大旺高新区唯品会物流园12库1号门（华南VI组）'
      """.stripMargin
    val addrRemoveConfTable1 = spark.sql(sql).rdd.map(x => {
      val citycode = x.getString(0)
      val address = x.getString(1)
      val aoiid = x.getString(2)
      val zc = x.getString(3)
      val jo = new JSONObject()
      jo.put("ciytcode",citycode)
      jo.put("address",citycode)
      jo.put("aoiid",citycode)
      jo.put("zc",zc)
      ((citycode,address,aoiid),jo)
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("addrRemoveConfTable1的数据：" + addrRemoveConfTable1.take(1).foreach(println(_)))


//    val reqBody = x.getJSONObject("reqBody")
//    val aoiId = JSONUtil.getJsonVal(reqBody,"aoiid","")
//    val address = reqBody.getString("address").replaceAll("(\\r|\\n|\\s+)","")
//    val zc = reqBody.getString("zc")
//    val cityCode = x.getString("cityCode")
//


    val sql2 =
      """
        |select   get_json_object(data_info, '$.reqBody.address') as address
        |,get_json_object(data_info, '$.reqBody.aoiid') as aoiid
        |,get_json_object(data_info, '$.cityCode') as cityCode
        |,get_json_object(data_info, '$.reqBody.zc') as zc
        |,data_info
        |from  dm_gis.t_deppon_sign_index_info_d where   get_json_object(data_info, '$.reqBody.address') = '广东省肇庆市四会市广东省肇庆四会大旺高新区唯品会物流园12库1号门（华南VI组）'
        |and inc_day = '20210817'  and data_type = 'wd'
        |limit 1
      """.stripMargin


      val rdd = SparkUtils.getRowToJson(spark,sql2)






   val rdd2=  rdd.map(obj=>{
      val aoiId = obj.getString("aoiid")
      val address = obj.getString("address").replaceAll("(\\r|\\n|\\s+)","")
      val zc = obj.getString("zc")
      val cityCode = obj.getString("cityCode")
      ((cityCode,address,aoiId),obj)
    })

    logger.error("rdd2：" + rdd2.take(10).foreach(println(_)))


   val s =  rdd2.leftOuterJoin(addrRemoveConfTable1).map(
      obj=>{
        val left = obj._1
        val right = obj._2

        if(right._2.nonEmpty){
          right._1.put("c","true")
        }else {
          right._1.put("c","flase")
        }
        right._1
      }
    )

    logger.error("s：" + s.take(10).foreach(println(_)))
    logger.error("s：" + s.filter(obj=>{JSONUtil.getJsonVal(obj,"c","true").equals()}).take(10).foreach(println(_)))




    logger.error("压数完成")

  }
}
