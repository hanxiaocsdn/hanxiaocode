package com.sf.gis.scala.debang.test

import com.alibaba.fastjson.{JSONArray, JSONObject}

object test {
  def main(args: Array[String]): Unit = {

//    val js = new JSONArray()
//    val jss = new JSONObject()
//    jss.put("1","222")
//    jss.put("2","211")
//    jss.put("3","212")
//    val jss1 = new JSONObject()
//    jss.put("1","221")
//    jss.put("2","222")
//    jss.put("3","223")
//
//    val jss2 = new JSONObject()
//    jss.put("1","223")
//    jss.put("2","221")
//    jss.put("3","222")
//
//    js.add(jss)
//    js.add(jss1)
//    js.add(jss2)
//
//    js.toArray().foreach(println(_))
//
//



    val   s = "广东省^11,广州市^12,花都区^13,凤凰村^16,河畔东路^19,209号^211;11"

    println(s.split(",").mkString("|"))




  }

}
