package com.sf.gis.java.util;

import org.json.XML;

import java.io.Serializable;

public class XMLParse implements Serializable {


    public static String parse(String xml){
        String result="";
        try {
            result = XML.toJSONObject(xml).toString();
        }catch (Exception e){
            e.printStackTrace();
            result=e.toString();
        }


       return result;
    }
}
