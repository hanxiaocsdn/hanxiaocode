package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.pojo.{slaSegmentation, villageSegmentation}
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel
import java.time.{Instant, LocalDateTime, ZoneId}
import java.time.format.DateTimeFormatter

/**
 * @Description:SLA数据指标
 * @Author: Liyucheng 01421359
 * @Date: 2023/03/24
 */
object slaQuery {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readSourceData(spark: SparkSession, calPartitions: Int,startTime:String,endTime:String,startTimestamp:String,endTimestamp:String,month:String,week:String) = {
    val omsfromSql=
      s"""
         |select
         |index
         |,service
         |,api
         |,response_average
         |,response_99
         |,sys_code
         |,service_name
         |from
         |dm_gis.sla_input_data
         |""".stripMargin
    logger.error(omsfromSql)
    val omsfromDf: DataFrame = spark.sql(omsfromSql)
    val omsfromRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, omsfromDf, calPartitions).map(obj=>{
      obj.put("startTime",startTime)
      obj.put("endTime",endTime)
      obj.put("startTimestamp",startTimestamp)
      obj.put("endTimestamp",endTimestamp)
      obj.put("month",month)
      obj.put("week",week)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("omsfromRdd:"+omsfromRdd.count())
    omsfromRdd
  }

  def interfaceAtpAt(spark: SparkSession, omsfromRdd: RDD[JSONObject]) = {
    val atpRdd = omsfromRdd.map(obj => {
      val retObj = SfNetInteface.slaInterface("XGwErcjyeFqWNCzX7m15usEQcF7LyaYZ", obj)
      val atp: JSONObject = JSONUtil.getJSONObject(retObj, "atpRet")
      val objArray = JSONUtil.getJsonArrayMulti(atp, "obj")
      val objList = objArray.toArray().map(o => try {
        JSON.parseObject(o.toString)
      } catch {
        case exception: Exception => new JSONObject()
      })

      if (objList.nonEmpty) {
        val maxJson = objList.maxBy(o => JSONUtil.getJsonValInt(o, "totalCounts", 0))
        val index = obj.getString("index")
        val api = obj.getString("api")
        val service_name = obj.getString("service_name")
        val sys_code = obj.getString("sys_code")
        val response_average = obj.getString("response_average")
        val response_99 = obj.getString("response_99")
        val startTimestamp = obj.getString("startTimestamp")
        val endTimestamp = obj.getString("endTimestamp")
        val startTime = obj.getString("startTime")
        val endTime = obj.getString("endTime")
        val clusterName = maxJson.getString("clusterName")
        val totalCounts = maxJson.getString("totalCounts")
        val failCounts = maxJson.getString("failCounts")
        val successPercent = maxJson.getString("successPercent")
        val cost_max2000 = maxJson.getString("cost_max2000")
        val cost_btn1000to2000 = maxJson.getString("cost_btn1000to2000")
        val cost_btn500to1000 = maxJson.getString("cost_btn500to1000")
        val cost_btn200to500 = maxJson.getString("cost_btn200to500")
        val cost_btn100to200 = maxJson.getString("cost_btn100to200")
        val cost_min100 = maxJson.getString("cost_min100")
        val cost_avg = maxJson.getString("cost_avg")
        val timeSum = maxJson.getString("timeSum")
        val cost_p95_avg = maxJson.getString("cost_p95_avg")
        val cost_p99_avg = maxJson.getString("cost_p99_avg")
        val month = obj.getString("month")
        val week = obj.getString("week")
        obj.put("index", index)
        obj.put("api", api)
        obj.put("service_name",service_name)
        obj.put("sys_code",sys_code)
        obj.put("response_average",response_average)
        obj.put("response_99",response_99)
        obj.put("startTime", startTime)
        obj.put("endTime", endTime)
        obj.put("startTimestamp", startTimestamp)
        obj.put("endTimestamp", endTimestamp)
        obj.put("clusterName", clusterName)
        obj.put("totalCounts", totalCounts)
        obj.put("failCounts", failCounts)
        obj.put("successPercent", successPercent)
        obj.put("cost_max2000", cost_max2000)
        obj.put("cost_btn1000to2000", cost_btn1000to2000)
        obj.put("cost_btn500to1000", cost_btn500to1000)
        obj.put("cost_btn200to500", cost_btn200to500)
        obj.put("cost_btn100to200", cost_btn100to200)
        obj.put("cost_min100", cost_min100)
        obj.put("cost_avg", cost_avg)
        obj.put("timeSum", timeSum)
        obj.put("cost_p95_avg", cost_p95_avg)
        obj.put("cost_p99_avg", cost_p99_avg)
        obj.put("retObj", retObj)
        obj.put("month", month)
        obj.put("week",week)
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    atpRdd.take(50).foreach(println(_))
    logger.error("atpRdd:"+atpRdd.count())
    atpRdd
  }

  def insertHiveTable(spark: SparkSession, month: String, atpRdd: RDD[JSONObject], calPartitions: Int) = {
    import spark.implicits._
    val resultDf: DataFrame = atpRdd.map(obj => {
      val index: String = JSONUtil.getJsonVal(obj, "index", "")
      val api: String = JSONUtil.getJsonVal(obj, "api", "")
      val service_name: String = JSONUtil.getJsonVal(obj, "service_name", "")
      val sys_code: String = JSONUtil.getJsonVal(obj, "sys_code", "")
      val response_average: String = JSONUtil.getJsonVal(obj, "response_average", "")
      val response_99: String = JSONUtil.getJsonVal(obj, "response_99", "")
      val startTime: String = JSONUtil.getJsonVal(obj, "startTime", "")
      val endTime: String = JSONUtil.getJsonVal(obj, "endTime", "")
      val startTimestamp: String = JSONUtil.getJsonVal(obj, "startTimestamp", "")
      val endTimestamp: String = JSONUtil.getJsonVal(obj, "endTimestamp", "")
      var clusterName: String = JSONUtil.getJsonVal(obj, "clusterName", "")
      var totalCounts: String = JSONUtil.getJsonVal(obj, "totalCounts", "")
      var failCount: String = JSONUtil.getJsonVal(obj, "failCounts", "")
      var successPercent: String = JSONUtil.getJsonVal(obj, "successPercent", "")
      var cost_max2000: String = JSONUtil.getJsonVal(obj, "cost_max2000", "")
      var cost_btn1000to2000: String = JSONUtil.getJsonVal(obj, "cost_btn1000to2000", "")
      var cost_btn500to1000: String = JSONUtil.getJsonVal(obj, "cost_btn500to1000", "")
      var cost_btn200to500: String = JSONUtil.getJsonVal(obj, "cost_btn200to500", "")
      var cost_btn100to200: String = JSONUtil.getJsonVal(obj, "cost_btn100to200", "")
      var cost_min100: String = JSONUtil.getJsonVal(obj, "cost_min100", "")
      var cost_avg: String = JSONUtil.getJsonVal(obj, "cost_avg", "")
      var timeSum: String = JSONUtil.getJsonVal(obj, "timeSum", "")
      var cost_p95_avg: String = JSONUtil.getJsonVal(obj, "cost_p95_avg", "")
      var cost_p99_avg: String = JSONUtil.getJsonVal(obj, "cost_p99_avg", "")
      val week: String = JSONUtil.getJsonVal(obj, "week", "")
      if (api=="kafka异步"){
        clusterName = "消费速率正常"
        totalCounts = "消费速率正常"
        failCount = "消费速率正常"
        successPercent = "消费速率正常"
        cost_max2000 = "消费速率正常"
        cost_btn1000to2000 = "消费速率正常"
        cost_btn500to1000 = "消费速率正常"
        cost_btn200to500 = "消费速率正常"
        cost_btn100to200 = "消费速率正常"
        cost_min100 = "消费速率正常"
        cost_avg = "消费速率正常"
        timeSum = "消费速率正常"
        cost_p95_avg = "消费速率正常"
        cost_p99_avg = "消费速率正常"
      }
      slaSegmentation(index, api, service_name, sys_code, response_average, response_99, startTime, endTime, startTimestamp, endTimestamp, clusterName, totalCounts,failCount, successPercent, cost_max2000, cost_btn1000to2000, cost_btn500to1000, cost_btn200to500, cost_btn100to200, cost_min100, cost_avg, timeSum, cost_p95_avg, cost_p99_avg, week)
    }).toDF()
    resultDf.createOrReplaceTempView("aoiShouPaiObtainSegmentationTmp")
    spark.sql(
      s"""
         |insert into table dm_gis.dm_sla_indicators partition(month=${month})
         |select
         |index, api, service_name, sys_code, response_average, response_99, startTime, endTime, startTimestamp, endTimestamp, clusterName, totalCounts,failCount, successPercent, cost_max2000, cost_btn1000to2000, cost_btn500to1000, cost_btn200to500, cost_btn100to200, cost_min100, cost_avg, timeSum, cost_p95_avg, cost_p99_avg, week
         |from aoiShouPaiObtainSegmentationTmp
         |""".stripMargin)
  }

  def execute(startTime:String,endTime:String,startTimestamp:String,endTimestamp:String,month:String,week:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    //读取omsfrom_wrong_data和aoi_real_acctury_rate_final_data数据，union拼接一起
    val omsfromRdd: RDD[JSONObject] = readSourceData(spark, calPartitions,startTime,endTime,startTimestamp,endTimestamp,month,week)
    //调取接口ATP跑数和AT收跑数
    val atpRdd: RDD[JSONObject] = interfaceAtpAt(spark, omsfromRdd)
    //插入hive表
    insertHiveTable(spark,month,atpRdd,calPartitions)
  }

  def main(args: Array[String]): Unit = {
    val startTime: String = args(0)
    val endTime: String = args(1)
    var startTimestamp = startTime + " 00:00:00"
    var endTimestamp = endTime + " 23:59:59"
    val formatter = DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss")
    startTimestamp = LocalDateTime.parse(startTimestamp, formatter).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli().toString
    endTimestamp = LocalDateTime.parse(endTimestamp, formatter).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli().toString
    val month: String = args(2)
    val week: String = args(3)
    execute(startTime,endTime,startTimestamp,endTimestamp,month,week)
    //execute()
    logger.error("======>>>>>>AoiShouPaiObtainSegmentationResult4 Execute Ok")
  }
}