package com.sf.gis.app

import java.util

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.pojo.villageSegmentation
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * @Description:AOI收派件错分跑数获取分词结果需求，source=4
 * @Author: lixiangzhi 01405644
 * @Date: 11:15 2022/4/18
 */
object villageQuery {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  def readSourceData(spark: SparkSession, calPartitions: Int) = {
    val omsfromSql=
      s"""
         |select
         |req_waybillno
         |,city_code
         |,addr
         |from
         |xxy_omsto_1208
         |""".stripMargin
    logger.error(omsfromSql)
    val omsfromDf: DataFrame = spark.sql(omsfromSql)
    val omsfromRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, omsfromDf, calPartitions).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("omsfromRdd:"+omsfromRdd.count())
    omsfromRdd
  }

  /*def interfaceAtpAt(spark: SparkSession, omsfromRdd: RDD[JSONObject]) = {
    val returnAtpRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,omsfromRdd, SfNetInteface.villageInterface, 200, "5686a2aca02e42c9807158558446a455", 50000)
    returnAtpRDD.take(10).foreach(println(_))
    val atpRdd: RDD[JSONObject] = returnAtpRDD.map(obj => {
      val atp: JSONObject = JSONUtil.getJSONObject(obj, "atpRet")
      val result: JSONObject = JSONUtil.getJSONObject(atp, "result")
      val data: JSONObject = JSONUtil.getJsonObjectMulti(obj, "atpRet.result.data")
      val query: JSONObject = JSONUtil.getJSONObject(obj, "atpRet.result.query")
      val waybillNo = obj.getString("req_waybillno")
      val citycode = obj.getString("city_code")
      val address = obj.getString("addr")
      val province = data.getString("province")
      val city = data.getString("city")
      val county = data.getString("county")
      val town = data.getString("town")
      val src = data.getString("src")
      val x = data.getString("x")
      val y = data.getString("y")
      val vilName = data.getString("vilName")
      val vilSpaceCode = data.getString("vilSpaceCode")
      val classCode = data.getString("classCode")
      val level = data.getString("level")
      val filter = data.getInteger("filter")
      val vilCode = data.getString("vilCode")
      val townAdCode = data.getString("townAdCode")
      val aoiId = data.getString("aoiId")
      val aoiCode = data.getString("aoiCode")
      val deptCode = data.getString("deptCode")
      obj.put("waybillNo", waybillNo)
      obj.put("citycode", citycode)
      obj.put("address", address)
      obj.put("province", province)
      obj.put("city", city)
      obj.put("county", county)
      obj.put("town", town)
      obj.put("src", src)
      obj.put("x", x)
      obj.put("y", y)
      obj.put("vilName", vilName)
      obj.put("vilSpaceCode", vilSpaceCode)
      obj.put("classCode", classCode)
      obj.put("level", level)
      obj.put("filter", filter)
      obj.put("vilCode", vilCode)
      obj.put("townAdCode", townAdCode)
      obj.put("aoiId", aoiId)
      obj.put("aoiCode", aoiCode)
      obj.put("deptCode", deptCode)
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    atpRdd.take(10).foreach(println(_))
    logger.error("atpRdd:"+atpRdd.count())
    atpRdd
  }*/

  def insertHiveTable(spark: SparkSession, incDay: String, atpRdd: RDD[JSONObject], calPartitions: Int) = {
    import spark.implicits._
    val resultDf: DataFrame = atpRdd.map(obj => {
      val waybillNo: String = JSONUtil.getJsonVal(obj, "waybillNo", "")
      val citycode: String = JSONUtil.getJsonVal(obj, "citycode", "")
      val address: String = JSONUtil.getJsonVal(obj, "address", "")
      val province: String = JSONUtil.getJsonVal(obj, "province", "")
      val city: String = JSONUtil.getJsonVal(obj, "city", "")
      val county: String = JSONUtil.getJsonVal(obj, "county", "")
      val town: String = JSONUtil.getJsonVal(obj, "town", "")
      val src: String = JSONUtil.getJsonVal(obj, "src", "")
      val x: String = JSONUtil.getJsonVal(obj, "x", "")
      val y: String = JSONUtil.getJsonVal(obj, "y", "")
      val vilName: String = JSONUtil.getJsonVal(obj, "vilName", "")
      val vilSpaceCode: String = JSONUtil.getJsonVal(obj, "vilSpaceCode", "")
      val classCode: String = JSONUtil.getJsonVal(obj, "classCode", "")
      val level: String = JSONUtil.getJsonVal(obj, "level", "")
      val filter: Integer = obj.getInteger("filter")
      val vilCode: String = JSONUtil.getJsonVal(obj, "vilCode", "")
      val townAdCode: String = JSONUtil.getJsonVal(obj, "townAdCode", "")
      val aoiId: String = JSONUtil.getJsonVal(obj, "aoiId", "")
      val aoiCode: String = JSONUtil.getJsonVal(obj, "aoiCode", "")
      val deptCode: String = JSONUtil.getJsonVal(obj, "deptCode", "")
      villageSegmentation(waybillNo, citycode, address, province, city, county,town, src, x, y, vilName, vilSpaceCode, classCode, level, filter, vilCode, townAdCode, aoiId, aoiCode, deptCode)
    }).toDF()
    resultDf.createOrReplaceTempView("aoiShouPaiObtainSegmentationTmp")
    spark.sql(
      s"""
         |insert overwrite table dm_gis.village_query_20221213
         |select
         |waybillNo, citycode, address, province, city, county,town, src, x, y, vilName, vilSpaceCode, classCode, level, filter, vilCode, townAdCode, aoiId, aoiCode, deptCode
         |from aoiShouPaiObtainSegmentationTmp
         |""".stripMargin)
  }

  def execute(incDay: String,citySample:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    //读取omsfrom_wrong_data和aoi_real_acctury_rate_final_data数据，union拼接一起
    val omsfromRdd: RDD[JSONObject] = readSourceData(spark, calPartitions)
    //调取接口ATP跑数和AT收跑数
    //val atpRdd: RDD[JSONObject] = interfaceAtpAt(spark, omsfromRdd)
    //插入hive表
    //insertHiveTable(spark,incDay,atpRdd,calPartitions)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val citySample: String = args(1)
    execute(incDay,citySample)
    //execute()
    logger.error("======>>>>>>AoiShouPaiObtainSegmentationResult4 Execute Ok")
  }
}