package com.sf.gis.app

import com.alibaba.fastjson.JSONObject
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkWrite}
import com.sf.gis.scala.base.util.{JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{Row, SparkSession}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @ProductManager:01377527
 * @Author: 01407499
 * @CreateTime: 2024-01-09 10:44
 * @TaskId:961279
 * @TaskName:
 * @Description:作战地图-竞司运单件量按比例扩大
 */

object OperationMapCompetitorWaybillQuantityExpand {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val saveKey=Array("city_code","aoi_id","aoi_name","fa_type","zno_code","dept_code","deliver_quantity","out_deliver_quantity","pick_quantity","out_pick_quantity","out_zno_code_deliver_quantity","out_zno_code_pick_quantity","inc_month")

    val saveInfoKey=Array("inc_month","city_code","company_name","pick_quantity","diff","aoi_cnt","aoi_diff_num")
    def main(args: Array[String]): Unit = {
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val (competitorQuantityInfoRdd,dateArr) = getCompetitorWaybillQuantityInfo(sparkSession)
        getData2(sparkSession,competitorQuantityInfoRdd,dateArr)


    }

    def getCompetitorWaybillQuantityInfo(sparkSession:SparkSession)={
        var sql=
            """
              |
              |select inc_month,city_code,company_name,pick_quantity from (
              |select inc_month,city_code,company_name,pick_quantity,create_time,row_number()over(partition by inc_month,city_code,company_name order by create_time desc ) as rnk from dm_gis.dm_competitor_waybill_quantity_info_nd where pick_quantity<>'' and pick_quantity>0
              |
              |) t
              |where t.rnk=1
              |
              |""".stripMargin


        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val competitorQuantityInfoRdd = dataRdd.map(obj => {
            val inc_month = obj.getString("inc_month")
            val city_code = obj.getString("city_code")
            val company_name = obj.getString("company_name")
            var company = ""
            if (StringUtils.nonEmpty(company_name)) {
                company_name match {
                    case "best" => company = "渠道1"
                    case "sto" => company = "渠道2"
                    case "yd" => company = "渠道3"
                    case "yto" => company = "渠道4"
                    case "zto" => company = "渠道5"
                    case _=>logger.error("其它类型")
                }
            }
            (inc_month + "_" + city_code + "_" + company, obj)
        }).distinct()

        val dateArr: Set[String] = dataRdd.map(x => x.getString("inc_month")).collect().toSet
        (competitorQuantityInfoRdd,dateArr)

    }

    def getData(sparkSession:SparkSession,competitorQuantityInfoRdd:RDD[(String,JSONObject)],dateArr:Array[String])={

        var sql=
            s"""
              |
              |select * from dm_gis.dm_qg_competitor_aoi_quantity_sum_di where inc_month in ('${dateArr.mkString("','")}')
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val allCompanyQuantityRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {

                val out_pick_quantity = obj.getString("out_pick_quantity")
                if(StringUtils.nonEmpty(out_pick_quantity)&&out_pick_quantity.length>5){
                    val out_pick_quantitys = out_pick_quantity.split(",")
                    for (i <- 0 until (out_pick_quantitys.size)) {
                        val company = out_pick_quantitys(i).split(":")(0)
                        val quantity = out_pick_quantitys(i).split(":")(1)
                        val tmpObj = new JSONObject()
                        tmpObj.fluentPutAll(obj)
                        tmpObj.put("company", company)
                        tmpObj.put("quantity", quantity)
                        listbuffer += tmpObj

                    }

                }

            }


            listbuffer.iterator


        }).map(x=>(x.getString("inc_month")+"_"+x.getString("city_code")+"_"+x.getString("company"),x))

        val quantityAggRdd = allCompanyQuantityRdd.groupByKey().flatMap(x => {
            var quantity_sum = 0.0
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()

            for (obj <- x._2) {
                val quantity = obj.getString("quantity")
                if (StringUtils.nonEmpty(quantity)) {
                    quantity_sum += quantity.toDouble
                }


            }
            dataObj.put("key", x._1)
            dataObj.put("quantity_sum", quantity_sum)
            listBuffer += dataObj
            listBuffer

        }).map(x=>(x.getString("key"),x))

        val competitorQuantityRateRdd = competitorQuantityInfoRdd.leftOuterJoin(quantityAggRdd).map(x => {
            val dataObj = new JSONObject()
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                dataObj.fluentPutAll(leftObj)
                if (rightOp.nonEmpty) {
                    val pick_quantity = dataObj.getString("pick_quantity")
                    val quantity_sum = rightOp.get.getString("quantity_sum")
                    if (StringUtils.nonEmpty(pick_quantity) && StringUtils.nonEmpty(quantity_sum)) {
                        val rate = pick_quantity.toDouble / quantity_sum.toDouble
                        dataObj.put("rate", rate)

                    }

                }


            }

            (x._1,dataObj)


        })

        val resultRdd = allCompanyQuantityRdd.leftOuterJoin(competitorQuantityRateRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                dataObj.fluentPutAll(leftObj)
                if (rightOp.nonEmpty) {
                    val quantity = leftObj.getString("quantity")
                    val rate = rightOp.get.getString("rate")

                    if (StringUtils.nonEmpty(quantity) && StringUtils.nonEmpty(rate)) {
                        dataObj.put("quantity", math.round(quantity.toDouble * rate.toDouble))
                    }
                }

            }


            dataObj


        }).distinct().groupBy(x => (x.getString("city_code"), x.getString("aoi_id"), x.getString("aoi_name"), x.getString("fa_type"), x.getString("zno_code"), x.getString("dept_code"), x.getString("deliver_quantity"), x.getString("out_deliver_quantity"), x.getString("pick_quantity"), x.getString("out_zno_code_deliver_quantity"), x.getString("out_zno_code_pick_quantity"), x.getString("inc_month"))).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            var out_pick_quantity = ""
            val quantitySet = new mutable.HashSet[String]()
            val head = x._2.head
            for (obj <- x._2) {
                val company = obj.getString("company")
                val quantity = obj.getString("quantity")
                if (StringUtils.nonEmpty(company) && StringUtils.nonEmpty(quantity)) {
                    quantitySet.add(company + ":" + quantity)

                }


            }
            out_pick_quantity = quantitySet.mkString(",")
            head.put("out_pick_quantity", out_pick_quantity)
            listBuffer += head

            listBuffer


        })

        saveDataToHive(sparkSession,resultRdd)


    }

    def getData2(sparkSession:SparkSession,competitorQuantityInfoRdd:RDD[(String,JSONObject)],dateArr:Set[String])={

        var sql=
            s"""
               |
               |select * from dm_gis.dm_qg_competitor_aoi_quantity_sum_di where inc_month in ('${dateArr.mkString("','")}')
               |
               |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)
        val allCompanyQuantityRdd = dataRdd.mapPartitions(x => {
            val listbuffer = new ListBuffer[JSONObject]
            for (obj <- x) {

                val out_pick_quantity = obj.getString("out_pick_quantity")
                if(StringUtils.nonEmpty(out_pick_quantity)&&out_pick_quantity.length>5){
                    val out_pick_quantitys = out_pick_quantity.split(",")
                    for (i <- 0 until (out_pick_quantitys.size)) {
                        val company = out_pick_quantitys(i).split(":")(0)
                        val quantity = out_pick_quantitys(i).split(":")(1)
                        val tmpObj = new JSONObject()
                        tmpObj.fluentPutAll(obj)
                        tmpObj.put("company", company)
                        tmpObj.put("quantity", quantity)
                        listbuffer += tmpObj

                    }

                }

            }


            listbuffer.iterator


        }).map(x=>(x.getString("inc_month")+"_"+x.getString("city_code")+"_"+x.getString("company"),x))

        val quantityAggRdd = allCompanyQuantityRdd.groupByKey().flatMap(x => {
            var quantity_sum = 0.0
            val listBuffer = new ListBuffer[JSONObject]
            val dataObj = new JSONObject()

            var cnt=0L

            for (obj <- x._2) {
                val quantity = obj.getString("quantity")
                if (StringUtils.nonEmpty(quantity)&&quantity.toDouble>0.0) {
                    quantity_sum += quantity.toDouble
                    cnt+=1
                }


            }
            dataObj.put("key", x._1)
            dataObj.put("aoi_cnt",cnt)
            dataObj.put("quantity_sum", quantity_sum)
            listBuffer += dataObj
            listBuffer

        }).map(x=>(x.getString("key"),x))

        val competitorQuantityRateRdd = competitorQuantityInfoRdd.leftOuterJoin(quantityAggRdd).map(x => {
            val dataObj = new JSONObject()
            val leftObj = x._2._1
            val rightOp = x._2._2
            if (!leftObj.isEmpty) {
                dataObj.fluentPutAll(leftObj)
                if (rightOp.nonEmpty) {
                    val pick_quantity = dataObj.getString("pick_quantity")
                    val quantity_sum = rightOp.get.getString("quantity_sum")
                    val aoi_cnt=rightOp.get.getString("aoi_cnt")
                    if (StringUtils.nonEmpty(pick_quantity) && StringUtils.nonEmpty(quantity_sum)&&StringUtils.nonEmpty(aoi_cnt)&&aoi_cnt.toLong>0) {
                        val rate = pick_quantity.toDouble / quantity_sum.toDouble
                        var diff=Math.round((pick_quantity.toDouble-quantity_sum.toDouble))
                        if(diff>0){
                            diff=Math.round(diff*0.94)

                        }else if(diff<0){
                            diff=Math.round(diff*1.04)
                        }
                        val avg_quantity=quantity_sum.toDouble/aoi_cnt.toLong
                        dataObj.put("rate", rate)
                        dataObj.put("diff", diff)
                        dataObj.put("aoi_cnt", aoi_cnt)
                        dataObj.put("avg_quantity", avg_quantity)
                        dataObj.put("aoi_diff_num", Math.round(diff/aoi_cnt.toLong))

                    }

                }


            }

            (x._1,dataObj)


        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("关联后维表的数据量----》"+competitorQuantityRateRdd.count())

        SparkWrite.save2HiveStaticNew(sparkSession, competitorQuantityRateRdd.map(x=>x._2), saveInfoKey, "tmp_dm_gis.dm_competitor_waybill_quantity_info_nd",null, 25)


        val resultRdd = allCompanyQuantityRdd.leftOuterJoin(competitorQuantityRateRdd).map(x => {
            val leftObj = x._2._1
            val rightOp = x._2._2
            val dataObj = new JSONObject()
            if (!leftObj.isEmpty) {
                dataObj.fluentPutAll(leftObj)
                if (rightOp.nonEmpty) {
                    val quantity = leftObj.getString("quantity")
                    val rate = rightOp.get.getString("rate")
                    dataObj.put("rate", rate)
                    dataObj.put("diff", rightOp.get.getString("diff"))
                    dataObj.put("aoi_cnt", rightOp.get.getString("aoi_cnt"))
                    dataObj.put("aoi_diff_num", rightOp.get.getString("aoi_diff_num"))
                    dataObj.put("avg_quantity", rightOp.get.getString("avg_quantity"))

                }

            }


            dataObj


        }).distinct().map(x=>(x.getString("inc_month")+"_"+x.getString("city_code")+"_"+x.getString("company"),x)).groupByKey().flatMap(x=>{
            val listBuffer = new ListBuffer[JSONObject]
            val diff = x._2.head.getString("diff")
            val aoi_cnt = x._2.head.getString("aoi_cnt")
            val aoi_diff_num = x._2.head.getString("aoi_diff_num")
            val avg_quantity=x._2.head.getString("avg_quantity")
            val aoi_cnt_a=0L





            for(obj<-x._2){
                val tmpObj = new JSONObject()
                tmpObj.fluentPutAll(obj)
                val quantity = obj.getString("quantity")
                if(StringUtils.nonEmpty(quantity)&&quantity.toDouble>0.0){
                    if(StringUtils.nonEmpty(diff)&&StringUtils.nonEmpty(aoi_cnt)&&StringUtils.nonEmpty(aoi_diff_num)&&StringUtils.nonEmpty(avg_quantity)){
                        var diff_num=diff.toDouble
                        val aoi_diff_num_L=aoi_diff_num.toDouble
                        val quantityD = quantity.toDouble+math.round(aoi_diff_num_L*quantity.toDouble/avg_quantity.toDouble)
                        if(quantityD>=0.0&&aoi_diff_num_L>0.0&&diff_num>0.0&&(diff_num-math.round(aoi_diff_num_L*quantity.toDouble/avg_quantity.toDouble))>=0.0){
                            tmpObj.put("quantity",quantityD)
                            diff_num=diff_num-math.round(aoi_diff_num_L*quantity.toDouble/avg_quantity.toDouble)
                        }else if(aoi_diff_num_L<0.0&&quantityD>=0.0&&(diff_num-math.round(aoi_diff_num_L*quantity.toDouble/avg_quantity.toDouble))<=0.0&&diff_num<0.0){
                            tmpObj.put("quantity",quantityD)
                            diff_num=diff_num-math.round(aoi_diff_num_L*quantity.toDouble/avg_quantity.toDouble)

                        }



                    }



                }
                listBuffer+=tmpObj

            }



            listBuffer
        })
            .groupBy(x => (x.getString("city_code"), x.getString("aoi_id"), x.getString("aoi_name"), x.getString("fa_type"), x.getString("zno_code"), x.getString("dept_code"), x.getString("deliver_quantity"), x.getString("out_deliver_quantity"), x.getString("pick_quantity"), x.getString("out_zno_code_deliver_quantity"), x.getString("out_zno_code_pick_quantity"), x.getString("inc_month"))).flatMap(x => {
            val listBuffer = new ListBuffer[JSONObject]
            var out_pick_quantity = ""
            val quantitySet = new mutable.HashSet[String]()
            val head = x._2.head
            for (obj <- x._2) {
                val company = obj.getString("company")
                val quantity = obj.getString("quantity")
                if (StringUtils.nonEmpty(company) && StringUtils.nonEmpty(quantity)) {
                    quantitySet.add(company + ":" + quantity)

                }


            }
            out_pick_quantity = quantitySet.mkString(",")
            head.put("out_pick_quantity", out_pick_quantity)
            listBuffer += head

            listBuffer


        })

        saveDataToHive(sparkSession,resultRdd)


    }


    def saveDataToHive(sparkSession:SparkSession,standardRdd:RDD[JSONObject])={

        val schemaEle = new ArrayBuffer[StructField]()
        for (i <- saveKey.indices) {
            schemaEle.append(StructField(saveKey.apply(i), StringType, nullable = true))
        }
        val schema = StructType(schemaEle.toArray)
        val rowRdd = standardRdd.map(obj => {
            val row = new ArrayBuffer[String]
            for (i <- saveKey.indices) {
                var tmpStr = JSONUtil.getJsonValSingle(obj, saveKey.apply(i))
                row.append(tmpStr)
            }
            val ret = Row.fromSeq(row)
            ret
        })

        sparkSession.createDataFrame(rowRdd, schema).createOrReplaceTempView("tmp_result")
//        logger.error(s"清除数据，分区---》 $end_date")

//        logger.error(String.format("alter table dm_gis.dm_tt_waybill_normalization_dtl_di drop partition(inc_day = '%s')", end_date))
//        sparkSession.sql(String.format("alter table dm_gis.dm_tt_waybill_normalization_dtl_di drop partition(inc_day = '%s')", end_date))
        var sql_w=
            s"""
               |
               |insert overwrite table dm_gis.dm_qg_competitor_aoi_quantity_sum_di partition(inc_month)
               |select
               |city_code
               |,aoi_id
               |,aoi_name
               |,fa_type
               |,zno_code
               |,dept_code
               |,deliver_quantity
               |,out_deliver_quantity
               |,pick_quantity
               |,out_pick_quantity
               |,out_zno_code_deliver_quantity
               |,out_zno_code_pick_quantity
               |,inc_month
               |
               |from tmp_result
               |
               |
               |
               |
               |""".stripMargin

        logger.error("存储数据sql---》"+sql_w)
        sparkSession.sql(sql_w)
        logger.error("存储数据完毕")

    }


}
