package com.sf.gis.pojo

case class villageSegmentation (waybillNo:String,
                                citycode:String,
                                address:String,
                                province:String,
                                city:String,
                                county:String,
                                town:String,
                                src:String,
                                x:String,
                                y:String,
                                vilName:String,
                                vilSpaceCode:String,
                                classCode:String,
                                level:String,
                                filter:Integer,
                                vilCode:String,
                                townAdCode:String,
                                aoiId:String,
                                aoiCode:String,
                                deptCode:String
                               )
