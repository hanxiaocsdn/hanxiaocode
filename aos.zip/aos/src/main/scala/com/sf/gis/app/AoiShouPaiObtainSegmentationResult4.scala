package com.sf.gis.app

import java.util

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.java.base.util.BdpTaskRecordUtil
import com.sf.gis.pojo.AoiShouPaiObtainSegmentation
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkRead, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.storage.StorageLevel

import scala.collection.mutable.ArrayBuffer

/**
 * @Description:AOI收派件错分跑数获取分词结果需求，source=4
 * @Author: lixiangzhi 01405644
 * @Date: 11:15 2022/4/18
 *       任务id： 477595
 */
object AoiShouPaiObtainSegmentationResult4 {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)


  def readExamineData(spark: SparkSession, incDay: String, calPartitions: Int) = {
    val sql =
      s"""
         |select
         |src_order_no
         |,'' as isnotundercall
         |,'' as syssource
         |,'' as customeraccount
         |,'' as area
         |,region
         |,citycode
         |,req_address
         |,'' as req_comp_name
         |,'' as user_delivered_id
         |,'' as operatime_new
         |,finalzc
         |,finalgisaoicode
         |,'' as finalaoicode
         |,org_code
         |,'' as aoisrc
         |,'' as tag2
         |,'' as mobile
         |,'' as groupid
         |,'' as key_word
         |,'' as city
         |,'' as phone
         |,'' as src
         |,'' as id
         |,'' as operatime_new_pai
         |,'' as distribute_code
         |,'' as distribute_name
         |,'' as delivered_name
         |,'' as finalaoiname
         |,'' as aoi_area_code
         |,'' as req_time
         |,'' as bm_aoi
         |,'' as bm_userid
         |,'' as bm_time
         |,'' as cg_aoi
         |,'' as cg_userid
         |,'' as cg_time
         |,'' as src_aoi
         |,'10' as source
         |,'' as address_frc
         |,inc_day as date_time
         |from default.cuofen_ft80006291
         |where inc_day='$incDay'
         |and source='10'
         |and src_order_no regexp '^SF*'
         |group by citycode,org_code,req_address,finalzc,src_order_no,region,finalgisaoicode,inc_day
         |""".stripMargin

    logger.error(sql)
    var dataRdd: RDD[JSONObject] = spark.sparkContext.emptyRDD[JSONObject]
    try {
      val (originRdd, columns) = SparkRead.readHiveAsJson(spark, sql)
      dataRdd = originRdd
    } catch {
      case _ => {
        logger.error("补码考核数据異常")
      }
    }
    logger.error("examineRdd:" + dataRdd.count())
    dataRdd

  }

  def readSourceData(spark: SparkSession, incDay: String, calPartitions: Int, citySample: String,parDay_1 : String) = {
    val accturySql =
      s"""
         |select
         |src_order_no
         |,isnotundercall
         |,syssource
         |,customeraccount
         |,area
         |,region
         |,citycode
         |,req_address
         |,req_comp_name
         |,user_delivered_id
         |,operatime_new
         |,finalzc
         |,finalgisaoicode
         |,finalaoicode
         |,org_code
         |,aoisrc
         |,tag2
         |,mobile
         |,groupid
         |,key_word
         |,city
         |,phone
         |,src
         |,id
         |,operatime_new_pai
         |,distribute_code
         |,distribute_name
         |,delivered_name
         |,finalaoiname
         |,aoi_area_code
         |,req_time
         |,bm_aoi
         |,bm_userid
         |,bm_time
         |,cg_aoi
         |,cg_userid
         |,cg_time
         |,src_aoi
         |,source
         |,address_frc
         |,date_time
         |,waybillno
         |from
         |(
         |	select
         |	'' as src_order_no,
         |	'' as isnotundercall,
         |	'' as syssource,
         |	'' as customeraccount,
         |	area,
         |	region,
         |	city_code as citycode,
         |	req_addresseeaddr as req_address,
         |	req_comp_name,
         |	delivered_userid as user_delivered_id,
         |	'' as operatime_new,
         |	'' as finalzc,
         |	gisaoicode_rds as finalgisaoicode,
         |	finalaoicode,
         |	org_code,
         |	gisaoisrc as aoisrc,
         |	tag2,
         |	req_addresseephone as mobile,
         |	gis_to_sys_groupid as groupid,
         |	key_word,
         |	city_name as city,
         |	req_addresseemobile as phone,
         |	'' as src,
         |	id,
         |	operatime_new as operatime_new_pai,
         |	distribute_code,
         |	distribute_name,
         |	delivered_name,
         |	finalaoiname,
         |	aoi_area_code,
         |	req_time,
         |	bm_aoi,
         |	bm_userid,
         |	bm_time,
         |	cg_aoi,
         |	cg_userid,
         |	cg_time,
         |	src as src_aoi,
         |	'4' as source,
         |	row_number() over(partition by req_addresseeaddr,req_comp_name order by inc_day desc) as rn,
         |	count(1) over(partition by req_addresseeaddr,req_comp_name) as address_frc,
         |	inc_day as date_time,
         |  waybillno
         |	from dm_gis.aoi_real_acctury_rate_final_data
         |	where inc_day='$incDay'
         |	and gisaoisrc in ('chkn','norm')
         |  --and city_code in($citySample)
         |) t1
         |where t1.rn=1
         |and address_frc>=2
         |--and req_address in ('广东省韶关市浈江区新韶镇大学路288号韶关学院西区修德楼C211','浙江省金华市东阳市横店镇金佛庄路6号佐佑广告')
         |
         |union all
         |
         |select
         |	'' src_order_no,
         |	'' isnotundercall,
         |	'SX' as syssource,
         |	'' as customeraccount,
         |	substring(b.fbq_name, 1, 2) as area,
         |	b.area_name as region,
         |	a.final_citycode as citycode,
         |	a.sign_address as req_address,
         |	'' as req_comp_name,
         |	'' as user_delivered_id,
         |	'' as operatime_new,
         |	'' as finalzc,
         |	--a.final_aoiid as finalgisaoicode,
         |	c.aoi_code as finalgisaoicode,
         |	c.aoi_code as finalaoicode,
         |	'' as org_code,
         |	'' as aoisrc,
         |	'' as tag2,
         |	'' as mobile,
         |	'' as groupid,
         |	'' as key_word,
         |	b.dist_name as city,
         |	'' as phone,
         |	'' as src,
         |	'' as id,
         |	'' as operatime_new_pai,
         |	'' as distribute_code,
         |	'' as distribute_name,
         |	'' as delivered_name,
         |	c.aoi_name as finalaoiname,
         |	'' as aoi_area_code,
         |	'' as req_time,
         |	'' as bm_aoi,
         |	'' as bm_userid,
         |	'' as bm_time,
         |	'' as cg_aoi,
         |	'' as cg_userid,
         |	'' as cg_time,
         |	'' as src_aoi,
         |	'4' as source,
         |	'2' as address_frc,
         |	inc_day as date_time,
         |	'' as waybillno
         |from
         |(
         |  select
         |    distinct final_citycode,
         |    sign_address,
         |    final_aoiid,
         |    inc_day
         |  from
         |    dm_gis.shunxin_wrong_close_loop_detaid
         |  where
         |    inc_day = '$incDay'
         |    and aoi_arss_task_puss = 'true'
         |    --and sign_address in ('广东省韶关市浈江区新韶镇大学路288号韶关学院西区修德楼C211','浙江省金华市东阳市横店镇金佛庄路6号佐佑广告')
         |) a
         |
         |left join
         |
         |(
         |    select
         |      dist_code,
         |      dist_name,
         |      prov_name,
         |      area_name,
         |      fbq_name
         |    from
         |      dim.dim_city_info_df
         |    where
         |      inc_day = '$incDay'
         |) b
         |
         |on a.final_citycode = b.dist_code
         |
         |left join
         |(
         |  select
         |    aoi_id,
         |    aoi_code,
         |    aoi_name
         |  from
         |    dm_gis.cms_aoi_sch
         |) c
         |on a.final_aoiid = c.aoi_id
         |
         |union all
         |
         |select
         |  '' src_order_no,
         |  '' isnotundercall,
         |  'DB' as syssource,
         |  '' as customeraccount,
         |  substring(b.fbq_name, 1, 2) as area,
         |  b.area_name as region,
         |  a.city as citycode,
         |  a.address as req_address,
         |  '' as req_comp_name,
         |  '' as user_delivered_id,
         |  '' as operatime_new,
         |  '' as finalzc,
         |  --a.final_aoiid as finalgisaoicode,
         |  a.aoicode_at as finalgisaoicode,
         |  a.aoicode_at as finalaoicode,
         |  '' as org_code,
         |  a.src_at as aoisrc,
         |  '' as tag2,
         |  '' as mobile,
         |  a.groupid_at as groupid,
         |  a.keyWord_at as key_word,
         |  b.dist_name as city,
         |  '' as phone,
         |  '' as src,
         |  '' as id,
         |  '' as operatime_new_pai,
         |  '' as distribute_code,
         |  '' as distribute_name,
         |  '' as delivered_name,
         |  c.aoi_name as finalaoiname,
         |  '' as aoi_area_code,
         |  '' as req_time,
         |  '' as bm_aoi,
         |  '' as bm_userid,
         |  '' as bm_time,
         |  '' as cg_aoi,
         |  '' as cg_userid,
         |  '' as cg_time,
         |  '' as src_aoi,
         |  '4' as source,
         |  '2' as address_frc,
         |  inc_day as date_time,
         |  '' as waybillno
         |from
         |  (
         |    select
         |      inc_day,
         |      city,
         |      deptcode,
         |      address,
         |      aoicode_at,
         |      aoiname_at,
         |      aoiid_at,
         |      groupid_at,
         |      src_at,
         |      keyWord_at
         |    from
         |      dm_gis.dm_debang_cuofen_issues_new_di
         |    where
         |      inc_day = '$incDay'
         |      and push_aoi_task = 'true'
         |  ) a
         |  left join (
         |    select
         |      distinct dist_code,
         |      dist_name,
         |      prov_name,
         |      area_name,
         |      fbq_name
         |    from
         |      dm_gis.dim_city_info_df
         |    where
         |      inc_day = '$parDay_1'
         |  ) b on a.city = b.dist_code
         |  left join (
         |    select
         |      distinct aoi_id,
         |      aoi_code,
         |      aoi_name
         |    from
         |      dm_gis.cms_aoi_sch
         |  ) c on c.aoi_id = a.aoiid_at
         |""".stripMargin
    /*val accturySql =
      s"""
         |select
         |src_order_no
         |,isnotundercall
         |,syssource
         |,customeraccount
         |,area
         |,region
         |,citycode
         |,req_address
         |,req_comp_name
         |,user_delivered_id
         |,operatime_new
         |,finalzc
         |,finalgisaoicode
         |,finalaoicode
         |,org_code
         |,aoisrc
         |,tag2
         |,mobile
         |,groupid
         |,key_word
         |,city
         |,phone
         |,src
         |,id
         |,operatime_new_pai
         |,distribute_code
         |,distribute_name
         |,delivered_name
         |,finalaoiname
         |,aoi_area_code
         |,req_time
         |,bm_aoi
         |,bm_userid
         |,bm_time
         |,cg_aoi
         |,cg_userid
         |,cg_time
         |,src_aoi
         |,source
         |,address_frc
         |,date_time
         |,waybillno
         |from
         |(
         |	select
         |	'' as src_order_no,
         |	'' as isnotundercall,
         |	'' as syssource,
         |	'' as customeraccount,
         |	area,
         |	region,
         |	city_code as citycode,
         |	req_addresseeaddr as req_address,
         |	req_comp_name,
         |	delivered_userid as user_delivered_id,
         |	'' as operatime_new,
         |	'' as finalzc,
         |	gisaoicode_rds as finalgisaoicode,
         |	finalaoicode,
         |	org_code,
         |	gisaoisrc as aoisrc,
         |	tag2,
         |	req_addresseephone as mobile,
         |	gis_to_sys_groupid as groupid,
         |	key_word,
         |	city_name as city,
         |	req_addresseemobile as phone,
         |	'' as src,
         |	id,
         |	operatime_new as operatime_new_pai,
         |	distribute_code,
         |	distribute_name,
         |	delivered_name,
         |	finalaoiname,
         |	aoi_area_code,
         |	req_time,
         |	bm_aoi,
         |	bm_userid,
         |	bm_time,
         |	cg_aoi,
         |	cg_userid,
         |	cg_time,
         |	src as src_aoi,
         |	'4' as source,
         |	row_number() over(partition by req_addresseeaddr,req_comp_name order by inc_day desc) as rn,
         |	count(1) over(partition by req_addresseeaddr,req_comp_name) as address_frc,
         |	inc_day as date_time,
         |  waybillno
         |	from dm_gis.aoi_real_acctury_rate_final_data
         |	where inc_day='$incDay'
         |	and gisaoisrc in ('chkn','norm')
         |  --and city_code in($citySample)
         |) t1
         |where t1.rn=1
         |and address_frc>=2
         |--and req_address in ('广东省韶关市浈江区新韶镇大学路288号韶关学院西区修德楼C211','浙江省金华市东阳市横店镇金佛庄路6号佐佑广告')
         |""".stripMargin*/
    logger.error(accturySql)
    val accturyDf: DataFrame = spark.sql(accturySql)
    val accturyRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, accturyDf, calPartitions).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("accturyRdd:" + accturyRdd.count())
    accturyRdd
  }

  def interfaceAtpAt(spark: SparkSession, accturyRdd: RDD[JSONObject], calPartitions: Int) = {
    val returnAtpRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark, accturyRdd, SfNetInteface.atpInterface, 50, "12797991c7e64fadb1272910d9d01aef", 2000)
    val atpRdd: RDD[JSONObject] = returnAtpRDD.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "atpRet.result")
      val tcs: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tcs")
      val tcs_src: String = JSONUtil.getJsonValSingle(tcs, "src")
      val flag: String = JSONUtil.getJsonValSingle(tcs, "flag")
      val gis_aoiunit: String = JSONUtil.getJsonValSingle(tcs, "aoiUnit")
      val tcs_groupid: String = JSONUtil.getJsonValSingle(tcs, "groupid")
      val resultOther: JSONObject = JSONUtil.getJSONObject(result, "other")
      val normresp: JSONObject = JSONUtil.getJSONObject(resultOther, "normresp")
      val otherResult: JSONObject = JSONUtil.getJSONObject(normresp, "result")
      val geocoder: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(otherResult, "geocoder")
      val STANDARD: String = JSONUtil.getJsonValSingle(geocoder, "standardization")
      val SFLAG: String = JSONUtil.getJsonValSingle(geocoder, "sflag")
      val MATCH_X: String = JSONUtil.getJsonValSingle(geocoder, "x")
      val MATCH_Y: String = JSONUtil.getJsonValSingle(geocoder, "y")
      val GL_LEVEL: String = JSONUtil.getJsonValSingle(geocoder, "level")
      val SCORE: String = JSONUtil.getJsonValSingle(geocoder, "score")
      val addrSplitInfoArray: util.Iterator[AnyRef] = JSONUtil.getJsonArrayFromObject(otherResult, "addrSplitInfo").iterator()
      val addrSplitInfoNewArray = new ArrayBuffer[String]()
      while (addrSplitInfoArray.hasNext) {
        val addrSplitInfo: JSONObject = addrSplitInfoArray.next().asInstanceOf[JSONObject]
        val name: String = JSONUtil.getJsonValSingle(addrSplitInfo, "name")
        val level: String = JSONUtil.getJsonValSingle(addrSplitInfo, "level")
        val prop: String = JSONUtil.getJsonValSingle(addrSplitInfo, "prop")
        val match_data: String = JSONUtil.getJsonValSingle(addrSplitInfo, "match")
        val addrSplitInfoNew: String = name + "^" + level + "^" + prop + "^" + match_data
        addrSplitInfoNewArray.append(addrSplitInfoNew)
      }
      val MATCH_INFO: String = addrSplitInfoNewArray.mkString("|")
      val gis_new_dept: String = JSONUtil.getJsonValSingle(tcs, "dept")
      val gis_aoicode: String = JSONUtil.getJsonValSingle(tcs, "aoicode")
      val gis_aoiid: String = JSONUtil.getJsonValSingle(tcs, "aoiid")
      val gis_keyWord: String = JSONUtil.getJsonValSingle(tcs, "keyWord")
      val gis_splitResult: String = JSONUtil.getJsonValSingle(otherResult, "splitResult")
      val adcode: String = JSONUtil.getJsonValSingle(resultOther, "adcode")
      obj.put("tcs_src", tcs_src)
      obj.put("flag", flag)
      obj.put("gis_aoiunit", gis_aoiunit)
      obj.put("tcs_groupid", tcs_groupid)
      obj.put("STANDARD", STANDARD)
      obj.put("SFLAG", SFLAG)
      obj.put("MATCH_X", MATCH_X)
      obj.put("MATCH_Y", MATCH_Y)
      obj.put("GL_LEVEL", GL_LEVEL)
      obj.put("SCORE", SCORE)
      obj.put("MATCH_INFO", MATCH_INFO)
      obj.put("gis_new_dept", gis_new_dept)
      obj.put("gis_aoicode", gis_aoicode)
      obj.put("gis_aoiid", gis_aoiid)
      obj.put("gis_keyWord", gis_keyWord)
      obj.put("gis_splitResult", gis_splitResult)
      obj.put("adcode", adcode)
      //obj.put("result", result)
      obj
    }).filter(obj => {
      val adcode: String = obj.getString("adcode")
      StringUtils.isNoneEmpty(adcode)
    }).filter(obj => {
      val finalaoicode: String = JSONUtil.getJsonVal(obj, "finalgisaoicode", "")
      val gis_aoicode: String = JSONUtil.getJsonVal(obj, "gis_aoicode", "")//020NJ000380
      val syssource: String = JSONUtil.getJsonVal(obj, "syssource", "")
      !(("SX" == syssource || "DB" == syssource) && finalaoicode != gis_aoicode) //过滤掉syssource in ('SX'，'DB') 且 finalaoicode <> gis_aoicode
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    //atpRdd.take(2).foreach(println(_))
    logger.error("atpRdd:" + atpRdd.count())
    atpRdd
  }

  def insertHiveTable(spark: SparkSession, incDay: String, resultRdd: RDD[JSONObject], calPartitions: Int, parDay_1: String, parDay_2: String) = {
    import spark.implicits._
    val resultDf: DataFrame = resultRdd.map(obj => {
      val src_order_no: String = JSONUtil.getJsonVal(obj, "src_order_no", "")
      val isnotundercall: String = JSONUtil.getJsonVal(obj, "isnotundercall", "")
      val syssource: String = JSONUtil.getJsonVal(obj, "syssource", "")
      val customeraccount: String = JSONUtil.getJsonVal(obj, "customeraccount", "")
      val area: String = JSONUtil.getJsonVal(obj, "area", "")
      val region: String = JSONUtil.getJsonVal(obj, "region", "")
      val citycode: String = JSONUtil.getJsonVal(obj, "citycode", "")
      val req_address: String = JSONUtil.getJsonVal(obj, "req_address", "")
      val req_comp_name: String = JSONUtil.getJsonVal(obj, "req_comp_name", "")
      val user_delivered_id: String = JSONUtil.getJsonVal(obj, "user_delivered_id", "")
      val operatime_new: String = JSONUtil.getJsonVal(obj, "operatime_new", "")
      val finalzc: String = JSONUtil.getJsonVal(obj, "finalzc", "")
      val finalgisaoicode: String = JSONUtil.getJsonVal(obj, "finalgisaoicode", "")
      val finalaoicode: String = JSONUtil.getJsonVal(obj, "finalaoicode", "")
      val org_code: String = JSONUtil.getJsonVal(obj, "org_code", "")
      val aoisrc: String = JSONUtil.getJsonVal(obj, "aoisrc", "")
      val tag2: String = JSONUtil.getJsonVal(obj, "tag2", "")
      val mobile: String = JSONUtil.getJsonVal(obj, "mobile", "")
      val groupid: String = JSONUtil.getJsonVal(obj, "groupid", "")
      val key_word: String = JSONUtil.getJsonVal(obj, "key_word", "")
      val city: String = JSONUtil.getJsonVal(obj, "city", "")
      val phone: String = JSONUtil.getJsonVal(obj, "phone", "")
      val src: String = JSONUtil.getJsonVal(obj, "src", "")
      val id: String = JSONUtil.getJsonVal(obj, "id", "")
      val operatime_new_pai: String = JSONUtil.getJsonVal(obj, "operatime_new_pai", "")
      val distribute_code: String = JSONUtil.getJsonVal(obj, "distribute_code", "")
      val distribute_name: String = JSONUtil.getJsonVal(obj, "distribute_name", "")
      val delivered_name: String = JSONUtil.getJsonVal(obj, "delivered_name", "")
      val finalaoiname: String = JSONUtil.getJsonVal(obj, "finalaoiname", "")
      val aoi_area_code: String = JSONUtil.getJsonVal(obj, "aoi_area_code", "")
      val req_time: String = JSONUtil.getJsonVal(obj, "req_time", "")
      val bm_aoi: String = JSONUtil.getJsonVal(obj, "bm_aoi", "")
      val bm_userid: String = JSONUtil.getJsonVal(obj, "bm_userid", "")
      val bm_time: String = JSONUtil.getJsonVal(obj, "bm_time", "")
      val cg_aoi: String = JSONUtil.getJsonVal(obj, "cg_aoi", "")
      val cg_userid: String = JSONUtil.getJsonVal(obj, "cg_userid", "")
      val cg_time: String = JSONUtil.getJsonVal(obj, "cg_time", "")
      val src_aoi: String = JSONUtil.getJsonVal(obj, "src_aoi", "")
      val source: String = JSONUtil.getJsonVal(obj, "source", "")
      val address_frc: String = JSONUtil.getJsonVal(obj, "address_frc", "")
      val date_time: String = JSONUtil.getJsonVal(obj, "date_time", "")
      val tcs_src: String = JSONUtil.getJsonVal(obj, "tcs_src", "")
      val flag: String = JSONUtil.getJsonVal(obj, "flag", "")
      val tcs_groupid: String = JSONUtil.getJsonVal(obj, "tcs_groupid", "")
      val STANDARD: String = JSONUtil.getJsonVal(obj, "STANDARD", "")
      val SFLAG: String = JSONUtil.getJsonVal(obj, "SFLAG", "")
      val MATCH_X: String = JSONUtil.getJsonVal(obj, "MATCH_X", "")
      val MATCH_Y: String = JSONUtil.getJsonVal(obj, "MATCH_Y", "")
      val GL_LEVEL: String = JSONUtil.getJsonVal(obj, "GL_LEVEL", "")
      val SCORE: String = JSONUtil.getJsonVal(obj, "SCORE", "")
      val MATCH_INFO: String = JSONUtil.getJsonVal(obj, "MATCH_INFO", "")
      val gis_new_dept: String = JSONUtil.getJsonVal(obj, "gis_new_dept", "")
      val gis_aoicode: String = JSONUtil.getJsonVal(obj, "gis_aoicode", "")
      val gis_aoiid: String = JSONUtil.getJsonVal(obj, "gis_aoiid", "")
      val gis_keyWord: String = JSONUtil.getJsonVal(obj, "gis_keyWord", "")
      val gis_splitResult: String = JSONUtil.getJsonVal(obj, "gis_splitResult", "")
      val adcode: String = JSONUtil.getJsonVal(obj, "adcode", "")
      val waybillno: String = JSONUtil.getJsonVal(obj, "waybillno", "")
      val gis_aoiunit: String = JSONUtil.getJsonVal(obj, "gis_aoiunit", "")
      AoiShouPaiObtainSegmentation(src_order_no, isnotundercall, syssource, customeraccount, area, region, citycode, req_address, req_comp_name, user_delivered_id, operatime_new, finalzc, finalgisaoicode, finalaoicode, org_code, aoisrc, tag2, mobile, groupid, key_word, city, phone, src, id, operatime_new_pai, distribute_code, distribute_name, delivered_name, finalaoiname, aoi_area_code, req_time, bm_aoi, bm_userid, bm_time, cg_aoi, cg_userid, cg_time, src_aoi, source, address_frc, date_time, tcs_src, flag, tcs_groupid, STANDARD, SFLAG, MATCH_X, MATCH_Y, GL_LEVEL, SCORE, MATCH_INFO, gis_new_dept, gis_aoicode, gis_aoiid, gis_keyWord, gis_splitResult, adcode, "", "", "", "", waybillno, gis_aoiunit)
    }).toDF()
    resultDf.createOrReplaceTempView("aoiShouPaiObtainSegmentationTmp")
    resultDf.rdd.take(2).foreach(println(_))
    /*spark.sql(
      s"""
         |insert overwrite table dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new partition(inc_day=$incDay,src_flag = '4')
         |select
         |src_order_no, isnotundercall, syssource, customeraccount, area, region, citycode, req_address, req_comp_name, user_delivered_id, operatime_new, finalzc, finalgisaoicode, finalaoicode, org_code, aoisrc, tag2, mobile, groupid, key_word, city, phone, src,
         |concat(date_time,row_number() over(order by 1),source) as id,
         |operatime_new_pai, distribute_code, distribute_name, delivered_name, finalaoiname, aoi_area_code, req_time, bm_aoi, bm_userid, bm_time, cg_aoi, cg_userid, cg_time, src_aoi, source, address_frc, date_time, tcs_src, flag, tcs_groupid, STANDARD, SFLAG, MATCH_X, MATCH_Y, GL_LEVEL, SCORE, MATCH_INFO, gis_new_dept, gis_aoicode, gis_aoiid, gis_keyWord, gis_splitResult, adcode,"","","","",waybillno,gis_aoiunit
         |from
         |
         |(select * from aoiShouPaiObtainSegmentationTmp) as t1
         |
         |left join
         |
         |(SELECT aoi_unit FROM dm_gis.chk_alter_fw where inc_day='$incDay' and opt_type='shopAoiUnit' group by aoi_unit) as t2
         |
         |on t1.gis_aoiunit = t2.aoi_unit
         |
         |where t2.aoi_unit is null
         |""".stripMargin)*/
    spark.sql(
      s"""
         |insert overwrite table dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new partition(inc_day=$incDay,src_flag = '4')
         |select
         |src_order_no, isnotundercall, syssource, customeraccount, area, region, citycode, req_address, req_comp_name, user_delivered_id, operatime_new, finalzc, finalgisaoicode, finalaoicode, org_code, aoisrc, tag2, mobile, groupid, key_word, city, phone, src,
         |concat(date_time,row_number() over(order by 1),source) as id,
         |operatime_new_pai, distribute_code, distribute_name, delivered_name, finalaoiname, aoi_area_code, req_time, bm_aoi, bm_userid, bm_time, cg_aoi, cg_userid, cg_time, src_aoi, source, address_frc, date_time, tcs_src, flag, tcs_groupid, STANDARD, SFLAG, MATCH_X, MATCH_Y, GL_LEVEL, SCORE, MATCH_INFO, gis_new_dept, gis_aoicode, gis_aoiid, gis_keyWord, gis_splitResult, adcode,"","","","",waybillno,gis_aoiunit
         |from
         |
         |(select * from aoiShouPaiObtainSegmentationTmp) as t1
         |
         |left join
         |
         |(SELECT aoi_unit FROM dm_gis.chk_alter_fw where inc_day='$incDay' and opt_type='shopAoiUnit' group by aoi_unit) as t2
         |
         |on t1.gis_aoiunit = t2.aoi_unit
         |
         |left join
         |
         |(
         |	select req_address as req_address_t3 from dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new where inc_day between '$parDay_2' and '$parDay_1' and src_flag = '4' group by req_address
         |) as t3
         |
         |on t1.req_address = t3.req_address_t3
         |
         |where t2.aoi_unit is null and t3.req_address_t3 is null
         |""".stripMargin)
  }

  def execute(incDay: String, citySample: String, parDay_1: String, parDay_2: String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    //读取omsfrom_wrong_data和aoi_real_acctury_rate_final_data数据，union拼接一起
    val accturyRdd: RDD[JSONObject] = readSourceData(spark, incDay, calPartitions, citySample,parDay_1)
    accturyRdd.take(1).foreach(println(_))
    //新增补码考核数据源
    val examineRdd: RDD[JSONObject] = readExamineData(spark, incDay, calPartitions)
    //调取接口ATP跑数和AT收跑数
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "477595", "AOI收派件错分获取分词(source=4)", "AOI收派件错分获取分词", "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api", "12797991c7e64fadb1272910d9d01aef", accturyRdd.union(examineRdd).count(), 40)

    val resultRdd: RDD[JSONObject] = interfaceAtpAt(spark, accturyRdd.union(examineRdd), calPartitions)
    resultRdd.take(1).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    //插入hive表
    insertHiveTable(spark, incDay, resultRdd, calPartitions, parDay_1, parDay_2)
  }

  def main(args: Array[String]): Unit = {
    val incDay: String = args(0)
    val citySample: String = args(1)
    val parDay_1: String = args(2)//t-2
    val parDay_2: String = args(3)//t-4
    println(incDay)
    println(citySample)
    println(parDay_1)
    println(parDay_2)
    execute(incDay, citySample, parDay_1, parDay_2)
    //execute()
    logger.error("======>>>>>>AoiShouPaiObtainSegmentationResult4 Execute Ok")
  }
}