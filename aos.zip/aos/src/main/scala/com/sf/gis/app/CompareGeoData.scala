package com.sf.gis.app

import com.alibaba.fastjson.{JSON, JSONObject}
import com.sf.gis.app.OperationMapCompetitorWaybillQuantityExpand.{className, logger}
import com.sf.gis.java.util.XMLParse
import com.sf.gis.scala.base.pojo.{Cnt, StratTime}
import com.sf.gis.scala.base.spark.{Spark, SparkRead, SparkUtils, SparkWrite}
import com.sf.gis.scala.base.util.{HttpClientUtil, JSONUtil, StringUtils}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.storage.StorageLevel

import java.net.URLEncoder
import scala.collection.mutable.ListBuffer

/**
 * @ProductManager:01412980
 * @Author: 01407499
 * @CreateTime: 2024-01-31 11:23
 * @TaskId:1007761
 * @TaskName:
 * @Description:测试geo接口
 */

object CompareGeoData {
    val className: String = this.getClass.getSimpleName.replace("$", "")
    val logger: Logger = Logger.getLogger( className )
    val beforeUrl="http://10.240.162.41:8081/?query_type=GEOCODE&address=%s&filter_uprecision=3&ret_splitinfo=2&adcode=%s&OPT="

    val afterUrl="http://10.119.72.201:8087/?query_type=GEOCODE&address=%s&filter_uprecision=3&ret_splitinfo=2&adcode=%s&OPT="
    val saveKey=Array("address","adcode","groupid_before","id_before","normalized_before","splitresult_before","filter_before","score_before","adcode_before","level_before","log_before","groupid_after","id_after","normalized_after","splitresult_after","filter_after","score_after","adcode_after","level_after","log_after","groupid_accord","id_accord","normalized_accord","splitresult_accord","filter_accord","score_accord","adcode_accord","level_accord")

    def main(args: Array[String]): Unit = {
        val limit_cnt=args(0)
        val sparkSession = Spark.getSparkSession(className)
        sparkSession.sparkContext.setLogLevel("ERROR")
        val resultRdd = compare(sparkSession,limit_cnt)
        SparkWrite.save2HiveStaticNew(sparkSession, resultRdd, saveKey, "tmp_dm_gis.compare_geo_data",null, 1)

    }

    def compare(sparkSession:SparkSession,limitnum:String)={
        def sql=
            s"""
              |
              |select * from tmp_dm_gis.xiongan_test limit $limitnum
              |
              |""".stripMargin

        logger.error("sql---->"+sql)
        val (dataRdd, columns1) =SparkRead.readHiveAsJson(sparkSession, sql)

        val value: RDD[JSONObject] = dataRdd.repartition(3).mapPartitionsWithIndex((index, iter) => {
            val startTime = new StratTime(System.currentTimeMillis())

            val cn1 = new Cnt(0)

            for (obj <- iter) yield {
                val address = obj.getString("address")
                val adcode = obj.getString("adcode")
                val (group_before,id_before,filter_before,score_before,adcode_before,level_before,message_before,normalized_before,splitResult_before)=getInterfaceData(beforeUrl,address,adcode)

                val (group_after,id_after,filter_after,score_after,adcode_after,level_after,message_after,normalized_after,splitResult_after)=getInterfaceData(afterUrl,address,adcode)

                val groupid_accord = compareValue(group_before, group_after)
                val id_accord = compareValue(id_before, id_after)
                val filter_accord = compareValue(filter_before, filter_after)
                val score_accord = compareValue(score_before, score_after)
                val adcode_accord = compareValue(adcode_before, adcode_after)
                val level_accord = compareValue(level_before, level_after)
                val normalized_accord = compareValue(normalized_before, normalized_after)
                val splitResult_accord = compareValue(splitResult_before, splitResult_after)
                obj.put("groupid_before",group_before)

                obj.put("groupid_before",group_before)
                obj.put("id_before",id_before)
                obj.put("filter_before",filter_before)
                obj.put("score_before",score_before)
                obj.put("adcode_before",adcode_before)
                obj.put("level_before",level_before)
                obj.put("log_before",message_before)
                obj.put("normalized_before",normalized_before)
                obj.put("splitresult_before",splitResult_before)

                obj.put("groupid_after",group_after)
                obj.put("id_after",id_after)
                obj.put("filter_after",filter_after)
                obj.put("score_after",score_after)
                obj.put("adcode_after",adcode_after)
                obj.put("level_after",level_after)
                obj.put("log_after",message_after)
                obj.put("normalized_after",normalized_after)
                obj.put("splitresult_after",splitResult_after)

                obj.put("groupid_accord",groupid_accord)
                obj.put("id_accord",id_accord)
                obj.put("filter_accord",filter_accord)
                obj.put("score_accord",score_accord)
                obj.put("adcode_accord",adcode_accord)
                obj.put("level_accord",level_accord)
                obj.put("normalized_accord",normalized_accord)
                obj.put("splitresult_accord",splitResult_accord)



//                SparkUtils.limitAkUse(startTime, cn1, index, 500, logger)

//                val start=System.currentTimeMillis()


                obj
            }
        }).persist(StorageLevel.MEMORY_AND_DISK_SER_2)
        logger.error("调接口数据量----》"+value.count())

        value

    }


    def compareValue(before:String,after:String)={
        var accord="-1"
        if(StringUtils.nonEmpty(before)&&StringUtils.nonEmpty(after)&&before.equals(after)){
            accord="1"

        }else if(StringUtils.nonEmpty(before)||StringUtils.nonEmpty(after)){
            accord="0"

        }

        accord

    }
    def getInterfaceData(url:String,addr:String,adcode:String)={
        var addressGbk= try {
            URLEncoder.encode(addr, "GBK")
        }catch {
            case _=>""

        }
        var message=""
        var normalized=""
        var splitResult=""
        var group=""
        var id=""
        var filter=""
        var score=""
        var adcodes=""
        var level=""
        val groupList = new ListBuffer[String]
        val idList = new ListBuffer[String]
        val filterList = new ListBuffer[String]
        val scoreList = new ListBuffer[String]
        val adcodeList = new ListBuffer[String]
        val levelList = new ListBuffer[String]
//        groupList.sortWith((a,b)=>a>b)
        val requrl = String.format(url,addressGbk,adcode)
        var jSONstr = try {
            HttpClientUtil.getStrByGetFromTargetCharset(requrl,"GBK").replace("&", "&amp;")
        }
        catch {
            case e: Exception=>{
                logger.error(" 报错信息------->"+e.toString)
                logger.error("error url-----> "+requrl)
                null
            }
        }

        var jSONObject= try {
            message=XMLParse.parse(jSONstr)
            JSON.parseObject(XMLParse.parse(jSONstr)).getJSONObject("searchresult")

        }
        catch {
            case exception: Exception=>{
                logger.error(exception.getMessage)
                null
            }
        }

        if(jSONObject!=null){
            normalized = JSONUtil.getJsonVal(jSONObject, "normalized", "")
            splitResult = JSONUtil.getJsonVal(jSONObject, "splitResult", "")
            val poiArr = JSONUtil.getJsonArrayFromObject(jSONObject, "list.poi")
            message=jSONObject.toString()
            if(poiArr.size()>0){
                for(i<-0 until(poiArr.size())){
                    val dataObj = poiArr.getJSONObject(i)
                    groupList+=dataObj.getString("group")
                    idList+=dataObj.getString("id")
                    filterList+=dataObj.getString("filter")
                    scoreList+=dataObj.getString("score")
                    adcodeList+=dataObj.getString("adcode")
                    levelList+=dataObj.getString("level")
                }

                group=groupList.sortWith((a,b)=>a>b).mkString(",")
                id=idList.sortWith((a,b)=>a>b).mkString(",")
                filter=filterList.sortWith((a,b)=>a>b).mkString(",")
                score=scoreList.sortWith((a,b)=>a>b).mkString(",")
                adcodes=adcodeList.sortWith((a,b)=>a>b).mkString(",")
                level=levelList.sortWith((a,b)=>a>b).mkString(",")

            }else{
                group=JSONUtil.getJsonVal(jSONObject,"list.poi.group","")
                id=JSONUtil.getJsonVal(jSONObject,"list.poi.id","")
                filter=JSONUtil.getJsonVal(jSONObject,"list.poi.filter","")
                score=JSONUtil.getJsonVal(jSONObject,"list.poi.score","")
                adcodes=JSONUtil.getJsonVal(jSONObject,"list.poi.adcode","")
                level=JSONUtil.getJsonVal(jSONObject,"list.poi.level","")


            }


        }



        (group,id,filter,score,adcodes,level,message,normalized,splitResult)
    }



}
