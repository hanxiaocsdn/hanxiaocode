package com.sf.gis.app

import java.sql.Connection
import java.util
import java.util.stream.Collectors
import java.util.{List, Properties}

import com.alibaba.druid.pool.DruidDataSource
import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.constant.FixedConstant
import com.sf.gis.java.base.util.{BdpTaskRecordUtil, HttpInvokeUtil, UrlUtil}
import com.sf.gis.pojo.AoiShouPaiObtainSegmentation
import com.sf.gis.scala.base.custom_module.SfNetInteface
import com.sf.gis.scala.base.spark.{Spark, SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.{DateUtil, FileUtil, JSONUtil}
import org.apache.commons.lang3.StringUtils
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.apache.spark.sql.functions.lit

import scala.collection.JavaConversions._
import scala.collection.mutable.{ArrayBuffer, ListBuffer}

/**
 * @Description:AOI收派件错分跑数获取分词结果需求1.3,source=7
 * @Author: lixiangzhi 01405644
 * @Date: 11:15 2022/4/18
 *       任务id: 442224
  *
 */
object AoiShouPaiObtainSegmentationResult {
  val className: String = this.getClass.getSimpleName.replace("$", "")
  @transient
  val logger: Logger = Logger.getLogger(className)

  val ks = "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam"

  def readSourceData(spark: SparkSession,start_day: String, end_day:String,calc_day:String,calPartitions: Int) = {
    val create_start_day: String = DateUtil.getDateStr(calc_day, -12)
    val create_end_day: String = DateUtil.getDateStr(calc_day, -5)
    val accturySql=
      s"""
         |select
         |*
         |from
         |(
         |	select
         |	a.*,
         |	count(src_order_no) over(partition by req_address,mobile,customeraccount) as address_frc,
         |	row_number() over(partition by req_address,mobile,customeraccount order by operatime_new desc) as rnk,
         |   '' as flag_qf
         |	from
         |	(
         |		select
         |		x.src_order_no,
         |		x.isnotundercall,
         |		x.syssource,
         |		x.customeraccount,
         |		x.area,
         |		x.region,
         |		x.citycode,
         |		x.req_address,
         |		x.req_comp_name,
         |		x.userid as user_delivered_id,
         |		x.operatime_new,
         |		x.finalzc,
         |		x.finalaoicode as finalgisaoicode,
         |		x.54_aoicode as finalaoicode,
         |		x.54_zc as org_code,
         |		x.aoisrc,
         |		x.tag2,
         |		if(x.mobile is not null and x.mobile !='',x.mobile,x.phone) as  mobile,
         |		x.groupid,
         |		x.key_word,
         |		x.city,
         |		x.phone,
         |		x.src,
         |		'' as id,
         |		'' as operatime_new_pai,
         |		'' as distribute_code,
         |		'' as distribute_name,
         |		'' as delivered_name,
         |		'' as finalaoiname,
         |		'' as aoi_area_code,
         |		'' as req_time,
         |		'' as bm_aoi,
         |		'' as bm_userid,
         |		'' as bm_time,
         |		'' as cg_aoi,
         |		'' as cg_userid,
         |		'' as cg_time,
         |		'' as src_aoi,
         |		'7' as source,
         |    x.inc_day as date_time
         |    from
         |		(
         |select * ,row_number() over(partition by src_order_no order by operatime_new desc ) as rnk
         |from dm_gis.omsfrom_wrong_data
         |where inc_day='$end_day' and citycode not in ('852','853','886')
         |--where inc_day>='$start_day' and inc_day<='$end_day'
         |) x
         |left join --t-3
         |(select * from dm_gis.wdp_merge_miss_task where inc_day='$calc_day' and substring(create_time,0,10)>='$end_day' and substring(create_time,0,10)<='$calc_day'  and task_status='3'  and data_type = '7' )y
         |--on x.mobile=y.mobile and x.req_address=y.address and x.customeraccount=y.customeraccount
         |on x.mobile=y.mobile and x.req_address=y.address and x.customeraccount=y.customeraccount
         |where y.mobile is null and x.rnk=1
         |	) a
         |) b
         |--where b.rnk=1 and address_frc>=5
         |where b.rnk=1 and address_frc>=2
         |and finalzc = org_code
         |
         |union all
         |
         |select
         |  a.src_order_no,
         |  a.isnotundercall,
         |  a.syssource,
         |  a.customeraccount,
         |  a.area,
         |  a.region,
         |  a.citycode,
         |  a.req_address,
         |  a.req_comp_name,
         |  b.userid,
         |  c.operatime_new,
         |  a.finalzc,
         |  a.finalaoicode,
         |  '' as 54_aoicode,
         |  '' as 54_zc,
         |  a.aoisrc,
         |  '' as tag2,
         |  a.mobile,
         |  a.groupid,
         |  '' as key_word,
         |  a.city,
         |  a.phone,
         |  a.src,
         |  '' as id,
         |  '' as operatime_new_pai,
         |  '' as distribute_code,
         |  '' as distribute_name,
         |  '' as delivered_name,
         |  '' as finalaoiname,
         |  '' as aoi_area_code,
         |  '' as req_time,
         |  '' as bm_aoi,
         |  '' as bm_userid,
         |  '' as bm_time,
         |  '' as cg_aoi,
         |  '' as cg_userid,
         |  '' as cg_time,
         |  '' as src_aoi,
         |  '7' as source,
         |  a.inc_day as date_time,
         |   '',
         |   '',
         |   'XG' as flag_qf
         | from
         |(
         |    select
         |      *
         |    from
         |    (
         |      select
         |        t1.*,
         |        row_number() over (partition by src_order_no order by max_time desc) as rank
         |      from
         |	  (
         |          select
         |            sysorderno as src_order_no,
         |            isnotundercall,
         |            syssource,
         |            customeraccount,
         |            '港澳台' as area,
         |            '香港区' as region,
         |            citycode,
         |            concat(province, city, county, address) as req_address,
         |            company as req_comp_name,
         |            deptcode as finalzc,
         |            case when asyncaoicode is not null and asyncaoicode <> '' then asyncaoicode else syncaoicode end as finalgisaoicode,
         |            finalaoicode,
         |            aoisrc,
         |            mobile,
         |            groupid,
         |            city,
         |            phone,
         |            src,
         |            case
         |              when syncredatetime > asyncredatetime
         |              and syncredatetime > arssredatatime then syncredatetime
         |              when asyncredatetime > syncredatetime
         |              and asyncredatetime > arssredatatime then asyncredatetime
         |              when arssredatatime > asyncredatetime
         |              and arssredatatime > syncredatetime then arssredatatime
         |              else ''
         |            end as max_time,
         |             inc_day,
         |			 errcallflag
         |          from
         |            dm_gis.gis_rds_omsfrom
         |          where
         |            inc_day ='$end_day'
         |            and citycode = '852'
         |            and isnotundercall != '1'
         |      ) t1
         |    ) t2
         |    where
         |    t2.rank = 1
         |) a
         |
         |left join
         |
         |(
         |    select
         |      *
         |    from
         |    (
         |      select
         |        src_order_no,
         |        concat_ws(',', waybill_no) as waybill_no,
         |        pickup_emp_code as userid
         |      from
         |      dwd.dwd_order_info_di
         |      where inc_day ='$end_day'
         |      and sender_city_code = '852'
         |    ) a
         |) b
         |
         |on a.src_order_no = b.src_order_no
         |
         |left join
         |
         |(
         |	select
         |		t.*
         |	from
         |	(
         |		select
         |			waybillno,
         |			eventlng as 54_x,---妥投经度
         |			eventlat as 54_y,---妥投维度
         |			org_code as userid,
         |			operatime_new as operatime_new,
         |			row_number() over (partition by waybillno order by operatime_new desc) as rn
         |		from
         |		ods_inc_sgs_core.inc_sgs_task_flow_new
         |		where
         |		inc_day = '$end_day'
         |		and eventlng != ''
         |		and eventlng is not null
         |		and eventlat != ''
         |		and eventlat is not null
         |		and eventtype in ('31201','31127')
         |		and city_code = '852'
         |	) t
         |	where t.rn = 1
         |) c
         |on b.waybill_no = c.waybillno
         |where
         |a.errcallflag = 'true'
         |and finalaoicode is not null
         |and finalaoicode <> ''
         |""".stripMargin
    logger.error(accturySql)
    val accturyDf: DataFrame = spark.sql(accturySql)
    val accturyRdd: RDD[JSONObject] = SparkUtils.getDfToJson(spark, accturyDf, calPartitions).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("accturyRdd:"+accturyRdd.count())
    accturyRdd
  }

  def interfaceAtpAt(spark: SparkSession,accturyRdd: RDD[JSONObject], calPartitions: Int) = {
    val returnAtRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,accturyRdd, SfNetInteface.atOtherInterface, 50, "664df91a30d370971387ef670b1358a3", 5000)
    val atRdd: RDD[JSONObject] = returnAtRDD.map(obj => {
      val result: JSONObject = JSONUtil.getJsonObjectMulti(obj, "atRet.result")
      val tcs: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(result, "tcs")
      val tcs_src: String = JSONUtil.getJsonValSingle(tcs, "atAoiSrc")
      val atDisResult: String = JSONUtil.getJsonValSingle(result, "atDisResult")
      val atDisResultObject: JSONObject = JSON.parseObject(atDisResult)
      var tcs_groupid: String = ""
      if (tcs_src=="chk"){
        tcs_groupid = JSONUtil.getJsonValSingle(result, "chkId")
      }else if(tcs_src=="dispatch-chkn"){
        val id_list = JSONUtil.getJsonObjectMulti(atDisResultObject, "result.id_list")
        tcs_groupid = JSONUtil.getJsonValSingle(id_list, "chknId")
      }else{
        tcs_groupid = JSONUtil.getJsonValSingle(tcs, "groupid")
      }
      val flag: String = JSONUtil.getJsonValSingle(tcs, "flag")
      val resultOther: JSONObject = JSONUtil.getJsonObjectMulti(atDisResultObject, "result.other")
      val atDisResultResult: JSONObject = JSONUtil.getJSONObject(atDisResultObject, "result")
      val resultTcs: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(atDisResultResult, "tcs")
      val normresp: JSONObject = JSONUtil.getJSONObject(resultOther, "normresp")
      val otherResult: JSONObject = JSONUtil.getJSONObject(normresp, "result")
      val geocoder: JSONObject = JSONUtil.getJsonArrayMultiOfFirstObject(otherResult, "geocoder")
      val STANDARD: String = JSONUtil.getJsonValSingle(geocoder, "standardization")
      val SFLAG: String = JSONUtil.getJsonValSingle(geocoder, "sflag")
      val MATCH_X: String = JSONUtil.getJsonValSingle(geocoder, "x")
      val MATCH_Y: String = JSONUtil.getJsonValSingle(geocoder, "y")
      val GL_LEVEL: String = JSONUtil.getJsonValSingle(geocoder, "level")
      val SCORE: String = JSONUtil.getJsonValSingle(geocoder, "score")
      val addrSplitInfoArray: util.Iterator[AnyRef] = JSONUtil.getJsonArrayFromObject(otherResult, "addrSplitInfo").iterator()
      val addrSplitInfoNewArray = new ArrayBuffer[String]()
      while (addrSplitInfoArray.hasNext){
        val addrSplitInfo: JSONObject = addrSplitInfoArray.next().asInstanceOf[JSONObject]
        val name: String = JSONUtil.getJsonValSingle(addrSplitInfo, "name")
        val level: String = JSONUtil.getJsonValSingle(addrSplitInfo, "level")
        val prop: String = JSONUtil.getJsonValSingle(addrSplitInfo, "prop")
        val match_data: String = JSONUtil.getJsonValSingle(addrSplitInfo, "match")
        val addrSplitInfoNew: String = name+"^" + level + "^"+ prop + "^" + match_data
        addrSplitInfoNewArray.append(addrSplitInfoNew)
      }
      val MATCH_INFO: String = addrSplitInfoNewArray.mkString("|")
      val gis_new_dept: String = JSONUtil.getJsonValSingle(tcs, "dept")
      val gis_aoicode: String = JSONUtil.getJsonValSingle(tcs, "aoicode")
      val gis_aoiid: String = JSONUtil.getJsonValSingle(tcs, "aoiid")
      val gis_keyWord: String = JSONUtil.getJsonValSingle(resultTcs, "keyWord")
      val gis_splitResult: String = JSONUtil.getJsonValSingle(otherResult, "splitResult")
      var adcode: String = JSONUtil.getJsonValSingle(resultOther, "adcode")
      if (adcode.length!=6){
        adcode = JSONUtil.getJsonValSingle(geocoder, "adcode")
      }
      if (adcode.length==6){
        obj.put("adcode", adcode)
      }else{
        obj.put("adcode", "")
      }


      obj.put("tcs_src", tcs_src)
      obj.put("flag", flag)
      obj.put("tcs_groupid", tcs_groupid)
      obj.put("STANDARD", STANDARD)
      obj.put("SFLAG", SFLAG)
      obj.put("MATCH_X", MATCH_X)
      obj.put("MATCH_Y", MATCH_Y)
      obj.put("GL_LEVEL", GL_LEVEL)
      obj.put("SCORE", SCORE)
      obj.put("MATCH_INFO", MATCH_INFO)
      obj.put("gis_new_dept", gis_new_dept)
      obj.put("gis_aoicode", gis_aoicode)
      obj.put("gis_aoiid", gis_aoiid)
      obj.put("gis_keyWord", gis_keyWord)
      obj.put("gis_splitResult", gis_splitResult)
      //obj.put("atRet", atRet)

      if (StringUtils.isEmpty(gis_aoiid)) {
        val citycode = JSONUtil.getJsonVal(obj,"citycode","")
        val req_address = JSONUtil.getJsonVal(obj,"req_address","")
        val req_comp_name = JSONUtil.getJsonVal(obj,"req_comp_name","")
        val finalzc = JSONUtil.getJsonVal(obj,"finalzc","")
        val city = JSONUtil.getJsonVal(obj,"city","")
        val mobile = JSONUtil.getJsonVal(obj,"mobile","")
        val phone = JSONUtil.getJsonVal(obj,"phone","")
        val param = new JSONObject()
//        param.put("ak", "d54e00e389524aa1a2e73946dc323b2a")
        param.put("ak", "2d56aff133e7456584abd3c1be674f0f")
        param.put("address", req_address)
        param.put("dept", finalzc)
        param.put("city", citycode)
        param.put("cityName", city)
        param.put("company", req_comp_name)
        param.put("mobile", mobile)
        param.put("tel", phone)

        val content1 = pushDataInterface(ks,param.toJSONString)

        obj.put("response_ks", content1)

        if (StringUtils.isNotEmpty(content1)) {
          val jsonObject = JSON.parseObject(content1)
          if (jsonObject != null && jsonObject.getInteger("status") == 0) {
            val result = jsonObject.getJSONObject("result")
            if (result != null) {
              val ks_aoiid = JSONUtil.getJsonVal(result,"aoi","")
              val ks_aoitag = JSONUtil.getJsonVal(result,"aoiTag","")
              val ks_aoicode = JSONUtil.getJsonVal(result,"aoiCode","")
              obj.put("ks_aoiid", ks_aoiid)
              obj.put("ks_aoitag", ks_aoitag)
              obj.put("ks_aoicode", ks_aoicode)
            }
          }
        }
      }

      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("atRdd:"+atRdd.count())
    atRdd
  }

  def pushDataInterface(url: String,toJSONString: String): String = {
    var response = ""
    try {
      if (!toJSONString.isEmpty) {
        response = HttpInvokeUtil.sendPostNew(url, toJSONString, FixedConstant.MAX_TRY_TIME_ONCE)
      }
    } catch {
      case e: Exception => logger.error(e)
    }
    response
  }

  def insertHiveTable(spark: SparkSession, resultRdd: RDD[JSONObject], calPartitions: Int,end_day:String,parDay_1 : String,parDay_2 : String) = {
    import spark.implicits._

    //明细表入库
    val rowDf = resultRdd.map(obj => obj.toJSONString.replaceAll("[\\r\\n\\t]", "")).toDF()
    logger.error("入明细表数量：" + rowDf.count())
    rowDf.coalesce(10).withColumn("inc_day", lit(end_day)).write.mode(SaveMode.Overwrite).insertInto("dm_gis.dm_aoi_shoupai_obtain_segmentation_detail_di")

    val resultDf: DataFrame = resultRdd.filter(obj => {
      val adcode: String = JSONUtil.getJsonVal(obj, "adcode", "")
      val aoisrc: String = JSONUtil.getJsonVal(obj, "aoisrc", "")
      !Array("4","5","6","7","8").contains(adcode) && aoisrc != "monthAcc"
    }).filter(obj => {
      val finalaoicode: String = JSONUtil.getJsonVal(obj, "finalgisaoicode", "")
      val gis_aoicode: String = JSONUtil.getJsonVal(obj, "gis_aoicode", "")
      val ks_aoicode: String = JSONUtil.getJsonVal(obj, "ks_aoicode", "")
      val flag_qf: String = JSONUtil.getJsonVal(obj, "flag_qf", "")
      !("XG" == flag_qf && finalaoicode != gis_aoicode && finalaoicode != ks_aoicode)
      //finalaoicode == gis_aoicode || finalaoicode == ks_aoicode
    }).map(obj => {
      val src_order_no: String = JSONUtil.getJsonVal(obj, "src_order_no", "")
      val isnotundercall: String = JSONUtil.getJsonVal(obj, "isnotundercall", "")
      val syssource: String = JSONUtil.getJsonVal(obj, "syssource", "")
      val customeraccount: String = JSONUtil.getJsonVal(obj, "customeraccount", "")
      val area: String = JSONUtil.getJsonVal(obj, "area", "")
      val region: String = JSONUtil.getJsonVal(obj, "region", "")
      val citycode: String = JSONUtil.getJsonVal(obj, "citycode", "")
      val req_address: String = JSONUtil.getJsonVal(obj, "req_address", "")
      val req_comp_name: String = JSONUtil.getJsonVal(obj, "req_comp_name", "")
      val user_delivered_id: String = JSONUtil.getJsonVal(obj, "user_delivered_id", "")
      val operatime_new: String = JSONUtil.getJsonVal(obj, "operatime_new", "")
      val finalzc: String = JSONUtil.getJsonVal(obj, "finalzc", "")
      val finalgisaoicode: String = JSONUtil.getJsonVal(obj, "finalgisaoicode", "")
      val finalaoicode: String = JSONUtil.getJsonVal(obj, "finalaoicode", "")
      val org_code: String = JSONUtil.getJsonVal(obj, "org_code", "")
      val aoisrc: String = JSONUtil.getJsonVal(obj, "aoisrc", "")
      val tag2: String = JSONUtil.getJsonVal(obj, "tag2", "")
      val mobile: String = JSONUtil.getJsonVal(obj, "mobile", "")
      val groupid: String = JSONUtil.getJsonVal(obj, "groupid", "")
      val key_word: String = JSONUtil.getJsonVal(obj, "key_word", "")
      val city: String = JSONUtil.getJsonVal(obj, "city", "")
      val phone: String = JSONUtil.getJsonVal(obj, "phone", "")
      val src: String = JSONUtil.getJsonVal(obj, "src", "")
      val id: String = JSONUtil.getJsonVal(obj, "id", "")
      val operatime_new_pai: String = JSONUtil.getJsonVal(obj, "operatime_new_pai", "")
      val distribute_code: String = JSONUtil.getJsonVal(obj, "distribute_code", "")
      val distribute_name: String = JSONUtil.getJsonVal(obj, "distribute_name", "")
      val delivered_name: String = JSONUtil.getJsonVal(obj, "delivered_name", "")
      val finalaoiname: String = JSONUtil.getJsonVal(obj, "finalaoiname", "")
      val aoi_area_code: String = JSONUtil.getJsonVal(obj, "aoi_area_code", "")
      val req_time: String = JSONUtil.getJsonVal(obj, "req_time", "")
      val bm_aoi: String = JSONUtil.getJsonVal(obj, "bm_aoi", "")
      val bm_userid: String = JSONUtil.getJsonVal(obj, "bm_userid", "")
      val bm_time: String = JSONUtil.getJsonVal(obj, "bm_time", "")
      val cg_aoi: String = JSONUtil.getJsonVal(obj, "cg_aoi", "")
      val cg_userid: String = JSONUtil.getJsonVal(obj, "cg_userid", "")
      val cg_time: String = JSONUtil.getJsonVal(obj, "cg_time", "")
      val src_aoi: String = JSONUtil.getJsonVal(obj, "src_aoi", "")
      val source: String = JSONUtil.getJsonVal(obj, "source", "")
      val address_frc: String = JSONUtil.getJsonVal(obj, "address_frc", "")
      val date_time: String = JSONUtil.getJsonVal(obj, "date_time", "")
      val tcs_src: String = JSONUtil.getJsonVal(obj, "tcs_src", "")
      val flag: String = JSONUtil.getJsonVal(obj, "flag", "")
      val tcs_groupid: String = JSONUtil.getJsonVal(obj, "tcs_groupid", "")
      val STANDARD: String = JSONUtil.getJsonVal(obj, "STANDARD", "")
      val SFLAG: String = JSONUtil.getJsonVal(obj, "SFLAG", "")
      val MATCH_X: String = JSONUtil.getJsonVal(obj, "MATCH_X", "")
      val MATCH_Y: String = JSONUtil.getJsonVal(obj, "MATCH_Y", "")
      val GL_LEVEL: String = JSONUtil.getJsonVal(obj, "GL_LEVEL", "")
      val SCORE: String = JSONUtil.getJsonVal(obj, "SCORE", "")
      val MATCH_INFO: String = JSONUtil.getJsonVal(obj, "MATCH_INFO", "")
      val gis_new_dept: String = JSONUtil.getJsonVal(obj, "gis_new_dept", "")
      val gis_aoicode: String = JSONUtil.getJsonVal(obj, "gis_aoicode", "")
      val gis_aoiid: String = JSONUtil.getJsonVal(obj, "gis_aoiid", "")
      val gis_keyWord: String = JSONUtil.getJsonVal(obj, "gis_keyWord", "")
      val gis_splitResult: String = JSONUtil.getJsonVal(obj, "gis_splitResult", "")
      val adcode: String = JSONUtil.getJsonVal(obj, "adcode", "")
      val ks_aoiid: String = JSONUtil.getJsonVal(obj, "ks_aoiid", "")
      val ks_aoitag: String = JSONUtil.getJsonVal(obj, "ks_aoitag", "")
      val ks_aoicode: String = JSONUtil.getJsonVal(obj, "ks_aoicode", "")
      val response_ks: String = JSONUtil.getJsonVal(obj, "response_ks", "")
      AoiShouPaiObtainSegmentation(src_order_no, isnotundercall, syssource, customeraccount, area, region, citycode, req_address, req_comp_name, user_delivered_id, operatime_new, finalzc, finalgisaoicode, finalaoicode, org_code, aoisrc, tag2, mobile, groupid, key_word, city, phone, src, id, operatime_new_pai, distribute_code, distribute_name, delivered_name, finalaoiname, aoi_area_code, req_time, bm_aoi, bm_userid, bm_time, cg_aoi, cg_userid, cg_time, src_aoi, source, address_frc, date_time, tcs_src, flag, tcs_groupid, STANDARD, SFLAG, MATCH_X, MATCH_Y, GL_LEVEL, SCORE, MATCH_INFO, gis_new_dept, gis_aoicode, gis_aoiid, gis_keyWord, gis_splitResult, adcode, ks_aoiid, ks_aoitag, ks_aoicode, response_ks,"","")
    }).toDF()
    resultDf.createOrReplaceTempView("aoiShouPaiObtainSegmentationTmp")
    /*spark.sql(
      s"""
         |insert overwrite table dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new partition(inc_day='$end_day',src_flag = '7')
         |select
         |src_order_no, isnotundercall, syssource, customeraccount, area, region, citycode, req_address, req_comp_name, user_delivered_id, operatime_new, finalzc, finalgisaoicode, finalaoicode, org_code, aoisrc, tag2, mobile, groupid, key_word, city, phone, src,
         |concat(date_time,row_number() over(order by 1),source) as id,
         |operatime_new_pai, distribute_code, distribute_name, delivered_name, finalaoiname, aoi_area_code, req_time, bm_aoi, bm_userid, bm_time, cg_aoi, cg_userid, cg_time, src_aoi, source, address_frc, date_time, tcs_src, flag, tcs_groupid, STANDARD, SFLAG, MATCH_X, MATCH_Y, GL_LEVEL, SCORE, MATCH_INFO, gis_new_dept, gis_aoicode, gis_aoiid, gis_keyWord, gis_splitResult, adcode, ks_aoiid, ks_aoitag, ks_aoicode,response_ks,"",""
         |from aoiShouPaiObtainSegmentationTmp
         |""".stripMargin)*/
    spark.sql(
      s"""
         |insert overwrite table dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new partition(inc_day='$end_day',src_flag = '7')
         |select
         |	t1.*
         |from
         |(
         |	select
         |src_order_no, isnotundercall, syssource, customeraccount, area, region, citycode, req_address, req_comp_name, user_delivered_id, operatime_new, finalzc, finalgisaoicode, finalaoicode, org_code, aoisrc, tag2, mobile, groupid, key_word, city, phone, src,
         |concat(date_time,row_number() over(order by 1),source) as id,
         |operatime_new_pai, distribute_code, distribute_name, delivered_name, finalaoiname, aoi_area_code, req_time, bm_aoi, bm_userid, bm_time, cg_aoi, cg_userid, cg_time, src_aoi, source, address_frc, date_time, tcs_src, flag, tcs_groupid, STANDARD, SFLAG, MATCH_X, MATCH_Y, GL_LEVEL, SCORE, MATCH_INFO, gis_new_dept, gis_aoicode, gis_aoiid, gis_keyWord, gis_splitResult, adcode, ks_aoiid, ks_aoitag, ks_aoicode,response_ks,"",""
         |from aoiShouPaiObtainSegmentationTmp
         |) as t1
         |
         |left join
         |
         |(
         |	--select src_order_no from dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new where inc_day between '$parDay_2' and '$parDay_1' and src_flag = '7' group by src_order_no
         |	select req_address as req_address_t2 from dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new where inc_day between '$parDay_2' and '$parDay_1' and src_flag = '7' group by req_address
         |) as t2
         |
         |on t1.req_address = t2.req_address_t2
         |
         |where t2.req_address_t2 is null
         |""".stripMargin)
    /*spark.sql(
      s"""
         |insert overwrite table dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new partition(inc_day='$end_day',src_flag = '7')
         |select
         |	t1.*
         |from
         |(
         |	select
         |src_order_no, isnotundercall, syssource, customeraccount, area, region, citycode, req_address, req_comp_name, user_delivered_id, operatime_new, finalzc, finalgisaoicode, finalaoicode, org_code, aoisrc, tag2, mobile, groupid, key_word, city, phone, src,
         |concat(date_time,row_number() over(order by 1),source) as id,
         |operatime_new_pai, distribute_code, distribute_name, delivered_name, finalaoiname, aoi_area_code, req_time, bm_aoi, bm_userid, bm_time, cg_aoi, cg_userid, cg_time, src_aoi, source, address_frc, date_time, tcs_src, flag, tcs_groupid, STANDARD, SFLAG, MATCH_X, MATCH_Y, GL_LEVEL, SCORE, MATCH_INFO, gis_new_dept, gis_aoicode, gis_aoiid, gis_keyWord, gis_splitResult, adcode, ks_aoiid, ks_aoitag, ks_aoicode,response_ks,"",""
         |from aoiShouPaiObtainSegmentationTmp
         |) as t1
         |""".stripMargin)*/
  }

  def filterChknAndOtherData(spark: SparkSession, filterRdd: RDD[JSONObject]) = {
    val chknList = filterRdd
      .filter(obj => Array("chkn", "dispatch-chkn").contains(obj.getString("tcs_src")))
      .map(obj => {
        (obj.getString("citycode"), obj.getString("tcs_groupid"))
      }).distinct().groupByKey().collect().to[ListBuffer]
    val otherList = filterRdd
      .filter(obj => Array("norm", "dispatch-norm").contains(obj.getString("tcs_src")))
      .map(obj => {
        (obj.getString("citycode"), obj.getString("tcs_groupid"))
      }).distinct().groupByKey().collect().to[ListBuffer]
    logger.error("其他库城市数量:" + otherList.size + ",审补库城市数量:" + chknList.size)
    (chknList, otherList)
  }

  def queryCmsTableInfo() = {
    val prop = FileUtil.getFilePropertieRes("conf/cms_group_config.properties")
    val cmsTableMap: util.HashMap[String, String] = parseCmsTableMap(prop)
    val url = prop.getProperty("cms.mysql.url")
    val user = prop.getProperty("cms.mysql.uid")
    val pwd = prop.getProperty("cms.mysql.pwd")
    val driver = prop.getProperty("cms.mysql.driver")
    logger.error("user:" + user)
    var conn: Connection = null
    val dataSource: DruidDataSource = new DruidDataSource()
    dataSource.setDriverClassName(driver)
    dataSource.setUrl(url)
    dataSource.setUsername(user)
    dataSource.setPassword(pwd)
    dataSource.setMaxActive(20)
    dataSource.setMaxWait(1000)
    dataSource.setRemoveAbandoned(false)
    conn = dataSource.getConnection
    (conn, cmsTableMap, dataSource)
  }
  def parseCmsTableMap(prop: Properties): java.util.HashMap[String, String] = {
    val shardingDbObj: JSONObject = JSON.parseObject(prop.getProperty("shardingDb"))
    val shardingDbMap = new java.util.HashMap[String, String] //每个表的城市集合

    for (entry <- shardingDbObj.entrySet) { //null
      val array = entry.getValue.toString.split(",")
      for (item <- array) {
        shardingDbMap.put(item, entry.getKey)
      }
    }
    shardingDbMap
  }
  /**
   * 分隔数组 根据每段数量分段
   *
   * @param data  被分隔的数组
   * @param count 每段数量
   * @return
   */
  def subListByCount(data: ListBuffer[String], count: Int): ListBuffer[List[String]] = {
    val result = new ListBuffer[List[String]]
    val size = data.size // 数据长度
    if (size > 0 && count > 0) {
      var segments = size / count // 商
      /**
       * 1.整除，  即分隔为segments     段
       * 2.除不尽，即分隔为segments + 1 段
       */
      segments = if (size % count == 0) segments
      else segments + 1 // 段数

      var cutList: List[String] = null // 每段List
      for (i <- 0 until segments) {
        if (i == segments - 1) cutList = data.subList(count * i, size)
        else cutList = data.subList(count * i, count * (i + 1))
        result.add(cutList)
      }
    }
    else result.add(data)
    result
  }
  def  findCmsGroupInfo(otherList: ListBuffer[(String, Iterable[String])],
                       chknList: ListBuffer[(String, Iterable[String])],
                       cmsTableMap: util.HashMap[String, String],
                       conn: Connection) = {
    val mysqlResultJsonList = new ListBuffer[JSONObject]

    //查询other数据
    otherList.map(item => {
      val city_code = item._1
      val groupidList = item._2.to[ListBuffer]
      val listBuffer: ListBuffer[util.List[String]] = subListByCount(groupidList, 300)
      val index = cmsTableMap.apply(city_code)
      listBuffer.map(list => {
        val sql =
          s"""
             |select city_code,address_id,adcode
             |from cms_address_$index
             |where city_code='$city_code' and del_flag=0 and address_id in ('${list.mkString("','")}')
             |""".stripMargin
        val ps = conn.prepareStatement(sql)
        val resultSet = ps.executeQuery()
        while (resultSet.next()) {
          val obj = new JSONObject()
          obj.put("city_code", resultSet.getString("city_code"))
          obj.put("address_id", resultSet.getString("address_id"))
          obj.put("adcode", resultSet.getString("adcode"))
          mysqlResultJsonList.add(obj)
        }
        ps.close()
      })
    })

    //查询cms chkn数据
    chknList.map(item => {
      val city_code = item._1
      val groupidList = item._2.to[ListBuffer]
      val listBuffer: ListBuffer[util.List[String]] = subListByCount(groupidList, 300)
      val index = cmsTableMap.apply(city_code)
      listBuffer.map(list => {
        val sql =
          s"""
             select city_code,address_md5 as address_id,adcode
             |from cms_address_$index
             |where city_code='$city_code' and del_flag=0 and  address_md5 in ('${list.mkString("','")}')
             |""".stripMargin

        val ps = conn.prepareStatement(sql)
        val resultSet = ps.executeQuery()
        while (resultSet.next()) {
          val obj = new JSONObject()
          obj.put("city_code", resultSet.getString("city_code"))
          obj.put("address_id", resultSet.getString("address_id"))
          obj.put("adcode", resultSet.getString("adcode"))
          mysqlResultJsonList.add(obj)
        }
        ps.close()
      })
    })
    mysqlResultJsonList
  }

  def joinCmsData(spark: SparkSession, mysqlResultJsonList: ListBuffer[JSONObject], filterRdd: RDD[JSONObject]) = {
    val mysqlResultRDD: RDD[(String, JSONObject)] = spark.sparkContext.parallelize(mysqlResultJsonList, 200).map(obj => (obj.getString("city_code") + obj.getString("address_id"), obj))
    val resultRDD: RDD[JSONObject] = filterRdd.map(obj => {
      (obj.getString("citycode") + obj.getString("tcs_groupid"), obj)
    }).leftOuterJoin(mysqlResultRDD)
      .map(obj => {
        val leftBody: JSONObject = obj._2._1
        val rightBody: JSONObject = obj._2._2.getOrElse(new JSONObject())
        val rightAdcode: String = rightBody.getString("adcode")
        leftBody.put("rightAdcode", rightAdcode)
        leftBody
      }).filter(obj=>{!Array("4","5","6","7","8").contains(obj.getString("rightAdcode"))}).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("总数量：" + resultRDD.count())
    resultRDD
  }

  def normalizeMicroserviceInterface(spark: SparkSession, retRdd: RDD[JSONObject]) = {
    val emptyAdcodeRdd: RDD[JSONObject] = retRdd.filter(obj => {
      val adcode: String = JSONUtil.getJsonValSingle(obj, "adcode")
      StringUtils.isEmpty(adcode)
    })
    val returnAdcodeRDD: RDD[JSONObject] = SparkNet.runInterfaceWithAkLimit(spark,emptyAdcodeRdd, SfNetInteface.adcodeInterface, 20, "664df91a30d370971387ef670b1358a3", 2000)
    val updateAdcodeRdd: RDD[JSONObject] = returnAdcodeRDD.map(obj => {
      val ret_result: JSONObject = JSONUtil.getJSONObject(obj, "ret_result")
      val resultJsonArray: JSONArray = JSONUtil.getJsonArrayMulti(ret_result, "result")
      if (resultJsonArray.nonEmpty) {
        val result = resultJsonArray.toArray()
        val adcode: String = result(1).asInstanceOf[String]
        obj.put("adcode", adcode)
      }
      obj
    }).persist(StorageLevel.MEMORY_AND_DISK_SER)
    logger.error("更新adcode")
    updateAdcodeRdd.take(10).foreach(println(_))
    val nonEmptyAdcodeRdd: RDD[JSONObject] = retRdd.repartition(200).filter(obj => {
      val adcode: String = JSONUtil.getJsonValSingle(obj, "adcode")
      StringUtils.isNoneEmpty(adcode)
    })
    val adcodeRdd: RDD[JSONObject] = nonEmptyAdcodeRdd.union(updateAdcodeRdd)
    adcodeRdd
  }

  def execute(start_day: String, end_day:String, calc_day:String, parDay_1:String, parDay_2:String) = {
    val spark: SparkSession = Spark.getSparkSession(className, null, false, 2)
    val (excutors, cores) = Spark.getExcutorInfo(spark)
    val calPartitions = excutors * cores * 3
    //读取omsfrom_wrong_data和aoi_real_acctury_rate_final_data数据，union拼接一起
    val accturyRdd: RDD[JSONObject] = readSourceData(spark, start_day,end_day, calc_day,calPartitions)
    accturyRdd.take(2).foreach(println(_))
    //调取接口ATP跑数和AT收跑数和KS接口
    val httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "442224", "AOI收派件错分获取分词(source=7)", "AOI收派件错分获取分词", "http://gis-int2.int.sfdc.com.cn:1080/rdsks/api/getTeam", "664df91a30d370971387ef670b1358a3", accturyRdd.count(), 40)

    val filterRdd: RDD[JSONObject] = interfaceAtpAt(spark, accturyRdd, calPartitions)
    filterRdd.take(2).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId)
    //处理原始数据
    val (chknList, otherList) = filterChknAndOtherData(spark, filterRdd)
    //读取重库信息
    val (conn, cmsTableMap, dataSource): (Connection, util.HashMap[String, String], DruidDataSource) = queryCmsTableInfo()
    //读取重库index表信息
    val mysqlResultJsonList = findCmsGroupInfo(otherList, chknList, cmsTableMap, conn)
    logger.error("mysqlResultJsonList.count=" + mysqlResultJsonList.size)
    conn.close()
    dataSource.close()
    //关联cms数据
    val retRdd = joinCmsData(spark, mysqlResultJsonList, filterRdd)
    retRdd.take(2).foreach(println(_))
    //判断adcode是否为空，为空，则调接口获取adcode
    val httpInvokeId1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, "01417629", "442224", "AOI收派件错分获取分词(source=7)", "AOI收派件错分获取分词", "http://gis-int.int.sfdc.com.cn:1080/atdispatch/api/normal", "664df91a30d370971387ef670b1358a3", retRdd.count(), 40)

    val resultRdd: RDD[JSONObject] = normalizeMicroserviceInterface(spark, retRdd)
    resultRdd.take(2).foreach(println(_))
    BdpTaskRecordUtil.endNetworkInterface("01417629", httpInvokeId1)
    //gis_aoiid为空的数据跑ks服务

    //插入hive表
    insertHiveTable(spark,resultRdd,calPartitions,end_day,parDay_1,parDay_2)
  }

  def main(args: Array[String]): Unit = {
    val start_day: String = args(0)
    val end_day: String = args(1)
    val calc_day:String=args(2)
    val parDay_1:String=args(3)//t-4
    val parDay_2:String=args(4)//t-6
    logger.error(
      """
        |任务：AOI收派件错分跑数获取分词结果需求1.3,source=7
        |负责人：01412406
        |需求人：01412995
      """.stripMargin)
    execute(start_day,end_day,calc_day,parDay_1,parDay_2)
    //execute()
    logger.error("======>>>>>>AoiShouPaiObtainSegmentationResult Execute Ok")
  }
}
