package com.sf.gis.scala.inc.app

import java.util.Date

import com.alibaba.fastjson.JSONObject
import com.sf.gis.java.base.util.DateUtil
import com.sf.gis.scala.base.spark.{Spark, SparkNetNew, SparkRead, SparkWrite}
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession

/**
 * 丰巢柜坐标转aoi信息
 * 任务已冻结，可认为已下线，交给业务方自己修改， 01374443 20231103
 * 任务id:396943
 */


object IncBdpDlsDeptXy {

//  val className: String = this.getClass.getSimpleName.replace("$", "")
//  @transient
//  val logger: Logger = Logger.getLogger(className)
//  val maxCal = 10
//
//  def queryData(sparkSession: SparkSession, srcTable: String,incDay:String):(RDD[JSONObject],Array[String]) = {
//    val sql = s"select cabinetcode,throwdate,wholethrowaddress,throwbuildinglocation,longitude,latitude,status,updatetm,cabinetid,belongorg,province,city,district,citycode,throwaddress,throwareaname,throwareatype,cellcount,bigcellcount,middlecellcount,smallcellcount,vicetype,cabinetchangestatus,cabinetmodifyflag,edinfotype,createtm from (" +
//      s" select cabinetcode,throwdate,wholethrowaddress,throwbuildinglocation,longitude,latitude,status,updatetm,cabinetid,belongorg,province,city,district,citycode,throwaddress,throwareaname,throwareatype,cellcount,bigcellcount,middlecellcount,smallcellcount,vicetype,cabinetchangestatus,cabinetmodifyflag,edinfotype,createtm,row_number() over(partition by cabinetcode order by updatetm desc) as rn " +
//      s"from ${srcTable} where inc_day<='${incDay}' and cabinetcode is not null and cabinetcode <> 'null' and cabinetcode <> ''" +
//      s") a where  rn = 1 " //+s" limit 10 "
//    logger.error(sql)
//    val (dataRdd,retColumns) = SparkRead.readHiveAsJson(sparkSession,sql,10)
//    (dataRdd,retColumns)
//  }
//
//  def start(incDay:String, srcTable: String, targetTable: String,calNum:Integer): Unit = {
//    val sparkSession = Spark.getSparkSession(className)
//    logger.error("开始读取数据表")
//    val (originRdd, column) = queryData(sparkSession, srcTable, incDay)
//    val aoi2Rdd = SparkNetNew.queryXyToAoiZcAoi2(sparkSession, originRdd, "65f5619cffb94f55942c1086b99e2a8f", calNum, 10000, "longitude", "latitude", true, 20000)
//    logger.error("包含aoi2结果的数量：" + aoi2Rdd.filter(obj => obj.containsKey("aoiInfoDataAoi2")).count())
//    val aoi2RsltRdd = aoi2Rdd.map(obj => {
//      if (obj.containsKey("aoiInfoDataAoi2")) {
//        obj.put("gis_json_aoi2", obj.getJSONObject("aoiInfoDataAoi2"))
//        obj.remove("aoiInfoDataAoi2")
//      }
//      obj
//    })
//    val aoiTypeRdd = SparkNetNew.queryXyToAoiZcAoitype(sparkSession, aoi2RsltRdd, "65f5619cffb94f55942c1086b99e2a8f", calNum, 10000, "longitude", "latitude",  true, 20000)
//    logger.error("包含aoiType结果的数量：" + aoiTypeRdd.filter(obj => obj.containsKey("aoiInfoDataAoitype")).count())
//    val aoiTypeRsltRdd = aoiTypeRdd.map(obj => {
//      if (obj.containsKey("aoiInfoDataAoitype")) {
//        obj.put("gis_json_aoitype", obj.getJSONObject("aoiInfoDataAoitype"))
//        obj.remove("aoiInfoDataAoitype")
//      }
//      obj
//    })
//    logger.error("保存结果")
//    val columnsKey = Array("cabinetcode","throwdate","wholethrowaddress","throwbuildinglocation","longitude",
//      "latitude","status","updatetm","gis_json_aoi2","cabinetid","belongorg","province","city","district","citycode"
//      ,"throwaddress","throwareaname","throwareatype","cellcount","bigcellcount","middlecellcount","smallcellcount",
//      "vicetype","cabinetchangestatus","cabinetmodifyflag","edinfotype","createtm","gis_json_aoitype")
//    SparkWrite.save2HiveStatic(sparkSession,aoiTypeRsltRdd,columnsKey,targetTable,Array(("inc_day",incDay)),1)
//  }
//
////  def queryAoiTypeByAoiiid(spark: SparkSession,aoiId:Array[String]): Unit ={
////
////  }
//
//  def main(args: Array[String]): Unit = {
//    var incDay = args(0)
//    //重新计算 封版期间没法改参数，代码中调整
//    incDay = DateUtil.getDayBefore(incDay,"yyyyMMdd",1)
//    var srcTable = args(1)
//    var targetTable = args(2)
//    var calNum = args(3).toInt
////    var columns = args(4)
////    if(calNum>maxCal){
////      logger.error("控制最多十并发")
////      calNum = maxCal
////    }
//    logger.error("先写死")
//    var hour = new Date().getHours
//    if(hour>=10){
//      calNum = 2
//    }else{
//      calNum = 20
//    }
//    logger.error("inc_day:"+incDay+",原始表：" + srcTable + ",目标表：" + targetTable+",calNum:"+calNum)
//    start(incDay,srcTable, targetTable,calNum)
//    logger.error("结束流程~")
//  }
}


