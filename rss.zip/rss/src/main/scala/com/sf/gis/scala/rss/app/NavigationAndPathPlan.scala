package com.sf.gis.scala.rss.app

import com.alibaba.fastjson.{JSON, JSONArray, JSONObject}
import com.sf.gis.java.base.util.{SparkUtil, UrlUtil}
import com.sf.gis.scala.base.spark.{SparkNet, SparkUtils}
import com.sf.gis.scala.base.util.JSONUtil
import com.sf.gis.scala.rss.constant.NavigationObj.FuseAndGDResultDF
import com.sf.gis.scala.rss.utils.SparkUtils.df2HiveByOverwrite
import org.apache.log4j.Logger
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import java.security.MessageDigest
import scala.collection.mutable.ArrayBuffer

/**
 * @description:
 * @author 01417347
 * @date 2022/8/30 13:36
 * 任务id 465212
 */
object NavigationAndPathPlan {

  val className: String = this.getClass.getSimpleName.replace("$", "")
  val logger: Logger = Logger.getLogger( className )
  //val TOP3_URL: String = "http://gis-rss-pns-reweb.sf-express.com/rsseditor/jump/post?url=http://gis-int.int.sfdc.com.cn:1080/rp/navi/v2/top3"
  val TOP3_URL: String = "http://gis-int.int.sfdc.com.cn:1080/rp/navi/v2/top3"
  //val COMPARE_TRACK_URL: String = "http://tlocrectify-gis-lss-tloc.dcn-gis1.k8s.sf-express.com/lssrectify/api/comparetracks"
  val COMPARE_TRACK_URL: String = "http://gis-int2.int.sfdc.com.cn:1080/lssrectify/api/comparetracks"

  def main(args: Array[String]): Unit = {

    val DayBefore2 = args(0)
    //日期检查
    logger.error("DayBefore2="+DayBefore2)
    val SparkInfo = SparkUtil.getSpark(className)
    val spark = SparkInfo.getSession

    //注册一个MD5加密函数
    spark.udf.register("MD5UDF",(input:String)=>{
      // 指定MD5加密算法
      val md5 = MessageDigest.getInstance("MD5")
      //进行随机哈希
      val encoded = md5.digest(input.getBytes)
      //转十六进制
      encoded.map("%02x".format(_)).mkString
    })

    logger.error("++++++++  任务开始  ++++")
    run(spark, DayBefore2)
    logger.error("++++++++  任务完成  ++++")
    spark.stop()

  }

  def run(spark: SparkSession, DayBefore2: String) = {
    //获取数据源
    var dataRDD = getDataSource(spark, DayBefore2)

    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runFuseTop3Inteface, 20, "98ea2536062445cba6cab556423a3b38", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runGDTop3Inteface, 20, "98ea2536062445cba6cab556423a3b38", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runFuseAndGDTop3Inteface, 20, "98ea2536062445cba6cab556423a3b38", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runJYTop3Inteface, 20, "98ea2536062445cba6cab556423a3b38", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runSFTop3Inteface, 20, "98ea2536062445cba6cab556423a3b38", 2000)

    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runFuseSimilarityInteface, 20, "e640de2b47394b19862ee134d817bbc7", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runGDSimilarityInteface, 20, "e640de2b47394b19862ee134d817bbc7", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runFuseAndGDSimilarityInteface, 20, "e640de2b47394b19862ee134d817bbc7", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runJYSimilarityInteface, 20, "e640de2b47394b19862ee134d817bbc7", 2000)
    dataRDD = SparkNet.runInterfaceWithAkLimit(spark, dataRDD, runSFSimilarityInteface, 20, "e640de2b47394b19862ee134d817bbc7", 2000)

    import spark.implicits._
    val result = dataRDD.repartition(100).map(obj => {
      val id = JSONUtil.getJsonVal(obj, "id", "")
      val task_id = JSONUtil.getJsonVal(obj, "task_id", "")
      val navi_id = JSONUtil.getJsonVal(obj, "navi_id", "")
      val routeid = JSONUtil.getJsonVal(obj, "routeid", "")
      val navi_starttime = JSONUtil.getJsonVal(obj, "navi_starttime", "")
      val req_time = JSONUtil.getJsonVal(obj, "req_time", "")
      val req_type = JSONUtil.getJsonVal(obj, "req_type", "")
      val x1 = JSONUtil.getJsonVal(obj, "x1", "")
      val x2 = JSONUtil.getJsonVal(obj, "x2", "")
      val y1 = JSONUtil.getJsonVal(obj, "y1", "")
      val y2 = JSONUtil.getJsonVal(obj, "y2", "")
      val plate = JSONUtil.getJsonVal(obj, "vehicle", "")
      val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "6")
      val weight = JSONUtil.getJsonVal(obj, "weight", "")
      val mload = JSONUtil.getJsonVal(obj, "mload", "")
      val length = JSONUtil.getJsonVal(obj, "length", "")
      val width = JSONUtil.getJsonVal(obj, "width", "")
      val height = JSONUtil.getJsonVal(obj, "height", "")
      val axle_weight = JSONUtil.getJsonVal(obj, "axle_weight", "")
      val axle_number = JSONUtil.getJsonVal(obj, "axle_number", "")
      val plateColor = JSONUtil.getJsonVal(obj, "plate_color", "")
      val energy = JSONUtil.getJsonVal(obj, "energy", "")
      val emitStand = JSONUtil.getJsonVal(obj, "emit_stand", "")
      val passport = JSONUtil.getJsonVal(obj, "passport", "")
      val driver_id = JSONUtil.getJsonVal(obj, "driver_id", "")
      val ft_url = JSONUtil.getJsonVal(obj, "ft_url", "")
      val plan_date = JSONUtil.getJsonVal(obj, "plan_date", "")
      val stype = JSONUtil.getJsonVal(obj, "stype", "")
      val path_count = JSONUtil.getJsonVal(obj, "path_count", "")
      val merge = JSONUtil.getJsonVal(obj, "merge", "")
      val strategy = JSONUtil.getJsonVal(obj, "strategy", "")
      val routeid_in = JSONUtil.getJsonVal(obj, "routeid_in", "")
      val fixed_route = JSONUtil.getJsonVal(obj, "fixed_route", "")
      val src = JSONUtil.getJsonVal(obj, "src", "")
      val routeid_out = JSONUtil.getJsonVal(obj, "routeid_out", "")
      val navi_endtime = JSONUtil.getJsonVal(obj, "navi_endtime", "")
      val navi_endx = JSONUtil.getJsonVal(obj, "navi_endx", "")
      val navi_endy = JSONUtil.getJsonVal(obj, "navi_endy", "")
      val driver_type = JSONUtil.getJsonVal(obj, "driver_type", "")
      val start_type = JSONUtil.getJsonVal(obj, "start_type", "")
      val is_econ = JSONUtil.getJsonVal(obj, "is_econ", "")
      val line_code = JSONUtil.getJsonVal(obj, "line_code", "")
      val navi_type = JSONUtil.getJsonVal(obj, "navi_type", "")
      val route_index = JSONUtil.getJsonVal(obj, "route_index", "")
      val sdk_type = JSONUtil.getJsonVal(obj, "sdk_type", "")
      val request_id = JSONUtil.getJsonVal(obj, "request_id", "")
      val src_province = JSONUtil.getJsonVal(obj, "src_province", "")
      val src_citycode = JSONUtil.getJsonVal(obj, "src_citycode", "")
      val src_deptcode = JSONUtil.getJsonVal(obj, "src_deptcode", "")
      val dest_province = JSONUtil.getJsonVal(obj, "dest_province", "")
      val dest_citycode = JSONUtil.getJsonVal(obj, "dest_citycode", "")
      val dest_deptcode = JSONUtil.getJsonVal(obj, "dest_deptcode", "")
      val tracks2 = JSONUtil.getJsonVal(obj, "tracks2", "")
      val opt = JSONUtil.getJsonVal(obj, "opt", "")
      val polyline_fuse = JSONUtil.getJsonVal(obj, "polyline_fuse", "")
      val distance_fuse = JSONUtil.getJsonVal(obj, "distance_fuse", "")
      val polyline_gd = JSONUtil.getJsonVal(obj, "polyline_gd", "")
      val distance_gd = JSONUtil.getJsonVal(obj, "distance_gd", "")
      val sim1_fuse = JSONUtil.getJsonVal(obj, "sim1_fuse", "")
      val sim5_fuse = JSONUtil.getJsonVal(obj, "sim5_fuse", "")
      val sim1_gd = JSONUtil.getJsonVal(obj, "sim1_gd", "")
      val sim5_gd = JSONUtil.getJsonVal(obj, "sim5_gd", "")
      val pull_navi_type = JSONUtil.getJsonVal(obj, "pull_navi_type", "")
      val polyline_jy_sf_gd = JSONUtil.getJsonVal(obj, "polyline_jy_sf_gd", "")
      val distance_jy_sf_gd = JSONUtil.getJsonVal(obj, "distance_jy_sf_gd", "")
      val sim1_jy_sf_gd = JSONUtil.getJsonVal(obj, "sim1_jy_sf_gd", "")
      val sim5_jy_sf_gd = JSONUtil.getJsonVal(obj, "sim5_jy_sf_gd", "")
      val top3_url = JSONUtil.getJsonVal(obj, "top3_url", "")
      val polyline_jy = JSONUtil.getJsonVal(obj, "polyline_jy", "")
      val distance_jy = JSONUtil.getJsonVal(obj, "distance_jy", "")
      val polyline_sf = JSONUtil.getJsonVal(obj, "polyline_sf", "")
      val distance_sf = JSONUtil.getJsonVal(obj, "distance_sf", "")
      val sim1_jy= JSONUtil.getJsonVal(obj, "sim1_jy", "")
      val sim5_jy = JSONUtil.getJsonVal(obj, "sim5_jy", "")
      val sim1_sf= JSONUtil.getJsonVal(obj, "sim1_sf", "")
      val sim5_sf = JSONUtil.getJsonVal(obj, "sim5_sf", "")

      FuseAndGDResultDF(id,task_id,navi_id,routeid,navi_starttime,req_time,req_type,x1,x2,y1,y2,plate,vehicle,weight,mload,length,width,height,axle_weight,
        axle_number,plateColor,energy,emitStand,passport,driver_id,ft_url,plan_date,stype,path_count,opt,merge,strategy,routeid_in,fixed_route,src,
        routeid_out,navi_endtime,navi_endx,navi_endy,driver_type,start_type,is_econ,line_code,navi_type,route_index,sdk_type,request_id,src_province,
        src_citycode,src_deptcode,dest_province,dest_citycode,dest_deptcode,tracks2,polyline_fuse,polyline_gd,distance_fuse,distance_gd,sim1_fuse,sim5_fuse,
        sim1_gd,sim5_gd,pull_navi_type,polyline_jy_sf_gd,distance_jy_sf_gd,sim1_jy_sf_gd,sim5_jy_sf_gd,top3_url,polyline_jy,distance_jy,polyline_sf,distance_sf,
        sim1_jy,sim5_jy,sim1_sf,sim5_sf)
    }).toDF()

    val top3SimDF = result
      .withColumn("sim15_fuse",when('sim1_fuse >= 'sim5_fuse,'sim1_fuse).otherwise('sim5_fuse))
      .withColumn("sim15_gd",when('sim1_gd >= 'sim5_gd,'sim1_gd).otherwise('sim5_gd))
      .withColumn("sim15_jy_sf_gd",when('sim1_jy_sf_gd >= 'sim5_jy_sf_gd,'sim1_jy_sf_gd).otherwise('sim5_jy_sf_gd))
      .withColumn("sim15_jy",when('sim1_jy >= 'sim5_jy,'sim1_jy).otherwise('sim5_jy))
      .withColumn("sim15_sf",when('sim1_sf >= 'sim5_sf,'sim1_sf).otherwise('sim5_sf))
      .withColumn("issim_fuse",when('sim15_fuse > 0.8,1).otherwise(0))
      .withColumn("issim_gd",when('sim15_gd > 0.8,1).otherwise(0))
      .withColumn("issim_jy_sf_gd",when('sim15_jy_sf_gd > 0.8,1).otherwise(0))
      .withColumn("issim_jy",when('sim15_jy > 0.8,1).otherwise(0))
      .withColumn("issim_sf",when('sim15_sf > 0.8,1).otherwise(0))
      .withColumn("inc_day",lit(DayBefore2))

    println("gis_navi_optSequence_top3_sim 表结构")
    top3SimDF.printSchema()
    df2HiveByOverwrite(logger,top3SimDF,"dm_gis.gis_navi_optSequence_top3_sim")

    //统计数据指标，并保存至hive
    saveStatisticalTableToHive(spark,DayBefore2)

  }

  /**
   * 从hive表取前一天的日志数据
   * @param spark
   * @param DayBefore2
   * @return
   */
  def getDataSource(spark: SparkSession, DayBefore2: String) = {
    val data_querySql =
      s"""
         |select
         |  a.id,
         |  a.task_id,
         |  a.navi_id,
         |  a.routeid,
         |  a.navi_starttime,
         |  a.req_time,
         |  a.req_type,
         |  a.x1,
         |  a.x2,
         |  a.y1,
         |  a.y2,
         |  a.vehicle,
         |  a.vehicle_type,
         |  a.weight,
         |  a.mload,
         |  a.length,
         |  a.width,
         |  a.height,
         |  a.axle_weight,
         |  a.axle_number,
         |  a.plate_color,
         |  a.energy,
         |  a.emit_stand,
         |  a.passport,
         |  a.driver_id,
         |  a.ft_url,
         |  a.plan_date,
         |  a.stype,
         |  a.path_count,
         |  a.opt,
         |  a.merge,
         |  a.strategy,
         |  a.routeid_in,
         |  a.fixed_route,
         |  a.src,
         |  a.routeid_out,
         |  a.navi_endtime,
         |  a.navi_endx,
         |  a.navi_endy,
         |  a.driver_type,
         |  a.start_type,
         |  a.is_econ,
         |  a.line_code,
         |  a.navi_type,
         |  a.route_index,
         |  a.sdk_type,
         |  a.pull_navi_type,
         |  a.strategy2,
         |  b.request_id,
         |  b.src_province,
         |  b.src_citycode,
         |  b.src_deptcode,
         |  b.dest_province,
         |  b.dest_citycode,
         |  b.dest_deptcode,
         |  b.tracks2
         |from
         |  (
         |    select
         |      id,
         |      task_id,
         |      navi_id,
         |      routeid,
         |      navi_starttime,
         |      req_time,
         |      req_type,
         |      x1,
         |      x2,
         |      y1,
         |      y2,
         |      vehicle,
         |      vehicle_type,
         |      weight,
         |      mload,
         |      length,
         |      width,
         |      height,
         |      axle_weight,
         |      axle_number,
         |      plate_color,
         |      energy,
         |      emit_stand,
         |      passport,
         |      driver_id,
         |      ft_url,
         |      plan_date,
         |      stype,
         |      path_count,
         |      opt,
         |      merge,
         |      strategy,
         |      routeid_in,
         |      fixed_route,
         |      src,
         |      routeid_out,
         |      navi_endtime,
         |      navi_endx,
         |      navi_endy,
         |      driver_type,
         |      start_type,
         |      is_econ,
         |      line_code,
         |      navi_type,
         |      route_index,
         |      sdk_type,
         |      pull_navitype as pull_navi_type,
         |      strategy2,
         |      inc_day
         |    from
         |      dm_gis.gis_navi_eta_result1
         |    where
         |      inc_day = '$DayBefore2'
         |      and distance >= 1000
         |      and req_type = 'top3'
         |      and strategy2 <> '20'
         |      and strategy2 <> '21'
         |      and strategy2 <> '22'
         |      and src <> ''
         |  ) a
         |  join (
         |    select
         |      id,
         |      request_id,
         |      navi_starttime,
         |      navi_endtime,
         |      src_province,
         |      src_citycode,
         |      src_deptcode,
         |      dest_province,
         |      dest_citycode,
         |      dest_deptcode,
         |      tracks2
         |    from
         |      dm_gis.gis_navi_eta_result2
         |    where
         |      inc_day = '$DayBefore2'
         |      and navi_distance >= 1000
         |      and trackstart_distance < 1000
         |      and trackend_distance < 1000
         |      and req_type = 'top3'
         |  ) b on a.id = b.id
         |""".stripMargin
    println(data_querySql)
    val dataRdd: RDD[JSONObject] = SparkUtils.getRowToJson(spark, data_querySql)
    dataRdd.take(2).foreach(println(_))
    dataRdd
  }

  /**
   * 接口参数格式化
   * @param obj
   * @param ak
   * @param opt
   * @param optSequence
   * @return
   */
  def getTop3Param(obj: JSONObject, ak: String, opt: String, optSequence: Int) = {

    val x1 = JSONUtil.getJsonVal(obj, "x1", "")
    val x2 = JSONUtil.getJsonVal(obj, "x2", "")
    val y1 = JSONUtil.getJsonVal(obj, "y1", "")
    val y2 = JSONUtil.getJsonVal(obj, "y2", "")
    val plate = JSONUtil.getJsonVal(obj, "vehicle", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "6")
    val weight = JSONUtil.getJsonVal(obj, "weight", "")
    val mload = JSONUtil.getJsonVal(obj, "mload", "")
    val width = JSONUtil.getJsonVal(obj, "width", "")
    val height = JSONUtil.getJsonVal(obj, "height", "")
    val plateColor = JSONUtil.getJsonVal(obj, "plate_color", "")
    val energy = JSONUtil.getJsonVal(obj, "energy", "")
    val emitStand = JSONUtil.getJsonVal(obj, "emit_stand", "")
    val passport = JSONUtil.getJsonVal(obj, "passport", "")
    val stype = JSONUtil.getJsonVal(obj, "stype", "")
    val merge = JSONUtil.getJsonVal(obj, "merge", "")
    val planDate = JSONUtil.getJsonVal(obj, "plan_date", "")
    val origin = x1 + ',' + y1
    val destination = x2 + ',' + y2
    val ft_url = JSONUtil.getJsonVal(obj, "ft_url", "")

    var ft_url_obj = new JSONObject()
    try{
      ft_url_obj = JSON.parseObject(ft_url.split("/rp/navi/v2/top3:")(1))
    }catch{
      case e: Exception => logger.error(e)
    }

    val label = JSONUtil.getJsonVal(ft_url_obj, "label", "")
    val reqType = JSONUtil.getJsonVal(ft_url_obj, "reqType", "")
    val vehicleDir = JSONUtil.getJsonVal(ft_url_obj, "vehicleDir", "")
    val axleNumber = JSONUtil.getJsonVal(ft_url_obj, "axleNumber", "")
    val mergeMark = JSONUtil.getJsonVal(ft_url_obj, "mergeMark", "")
    val lineCode = JSONUtil.getJsonVal(ft_url_obj, "lineCode", "")
    val maxDetailDistance = JSONUtil.getJsonVal(ft_url_obj, "maxDetailDistance", "")
    val dataSourceSwitch = JSONUtil.getJsonVal(ft_url_obj, "dataSourceSwitch", "")
    val actionCode = JSONUtil.getJsonVal(ft_url_obj, "actionCode", "")
    val avoidCheckStation = JSONUtil.getJsonVal(ft_url_obj, "avoidCheckStation", "")
    val fencedist = JSONUtil.getJsonVal(ft_url_obj, "fencedist", "")
    val fixedRoute = JSONUtil.getJsonVal(ft_url_obj, "fixedRoute", "")
    val distScale = JSONUtil.getJsonVal(ft_url_obj, "distScale", "")
    val nucleicData_str = JSONUtil.getJsonVal(ft_url_obj, "nucleicData", "")
    val vlimit = JSONUtil.getJsonVal(ft_url_obj, "vlimit", "")
    val nucleicData = JSON.parseArray(nucleicData_str)

    //    val req_time = JSONUtil.getJsonVal(obj, "req_time", "")
    //    var planDate = ""
    //    val sdf = new SimpleDateFormat("yyyyMMddHHmm")
    //    try{
    //      planDate = sdf.format(req_time.toLong)
    //    }catch {
    //      case e: Exception => logger.error(e)
    //    }

    //初始化top3接口请求参数
    val param = new JSONObject()
    param.put("ak", ak)
    param.put("origin", origin)
    param.put("destination", destination)
    param.put("plate", plate)
    param.put("weight", weight)
    param.put("mload", mload)
    param.put("height", height)
    param.put("vehicle", vehicle)
    param.put("plateColor", plateColor)
    param.put("width", width)
    param.put("energy", energy)
    param.put("emitStand", emitStand)
    param.put("opt", opt)
    param.put("merge", merge)
    param.put("stype", stype)
    param.put("passport", passport)
    param.put("output", "json")
    param.put("planDate", planDate)
    param.put("label", label)
    param.put("optSequence", optSequence)

    param.put("reqType", reqType)
    param.put("vehicleDir", vehicleDir)
    param.put("axleNumber", axleNumber)
    param.put("mergeMark", mergeMark)
    param.put("lineCode", lineCode)
    param.put("maxDetailDistance", maxDetailDistance)
    param.put("dataSourceSwitch", dataSourceSwitch)
    param.put("actionCode", actionCode)
    param.put("avoidCheckStation", avoidCheckStation)
    param.put("fencedist", fencedist)
    param.put("fixedRoute", fixedRoute)
    param.put("distScale", distScale)
    param.put("nucleicData", nucleicData)
    param.put("vlimit", vlimit)

    param
  }

  /**
   * 调top3接口,请求参数1
   * @param spark
   * @param dataDF
   */
  def runFuseTop3Inteface(ak:String, obj: JSONObject): JSONObject = {

    // 请求参数1
    val opt = "fuse"
    val optSequence = 1
    val param_fuse = getTop3Param(obj, ak, opt, optSequence)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(TOP3_URL,param_fuse.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    val top3_url = s"""${TOP3_URL}:${param_fuse.toString}"""
    //解析top3接口返回值,获取线路
    val httpData: (String, String, String, String) = parseTop3HttpData(retJSONObject)
    obj.put("polyline_fuse",httpData._3)
    obj.put("distance_fuse",httpData._4)
    obj.put("top3_url",top3_url)
    obj
  }

  /**
   * 调top3接口,请求参数2
   * @param spark
   * @param dataDF
   */
  def runGDTop3Inteface(ak:String, obj: JSONObject): JSONObject = {

    // 请求参数2
    val opt = "gd"
    val optSequence = 1
    val param_gd = getTop3Param(obj, ak, opt, optSequence)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(TOP3_URL,param_gd.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析top3接口返回值,获取线路
    val httpData: (String, String, String, String) = parseTop3HttpData(retJSONObject)
    obj.put("polyline_gd",httpData._3)
    obj.put("distance_gd",httpData._4)
    obj
  }

  /**
   * 调top3接口,请求参数3
   * @param spark
   * @param dataDF
   */
  def runFuseAndGDTop3Inteface(ak:String, obj: JSONObject): JSONObject = {

    // 请求参数3
    val opt = "fuse"
    val optSequence = 0
    val param_jy_sf_gd = getTop3Param(obj, ak, opt, optSequence)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(TOP3_URL,param_jy_sf_gd.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析top3接口返回值,获取线路
    val httpData: (String, String, String, String) = parseTop3HttpData(retJSONObject)
    obj.put("polyline_jy_sf_gd",httpData._3)
    obj.put("distance_jy_sf_gd",httpData._4)
    obj
  }

  /**
   * 调top3接口,请求参数4
   * @param spark
   * @param dataDF
   */
  def runJYTop3Inteface(ak:String, obj: JSONObject): JSONObject = {

    // 请求参数4
    val opt = "jy"
    val optSequence = 1
    val param_fuse = getTop3Param(obj, ak, opt, optSequence)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(TOP3_URL,param_fuse.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析top3接口返回值,获取线路
    val httpData: (String, String, String, String) = parseTop3HttpData(retJSONObject)
    obj.put("polyline_jy",httpData._3)
    obj.put("distance_jy",httpData._4)
    obj
  }

  /**
   * 调top3接口,请求参数5
   * @param spark
   * @param dataDF
   */
  def runSFTop3Inteface(ak:String, obj: JSONObject): JSONObject = {

    // 请求参数5
    val opt = "sf"
    val optSequence = 1
    val param_fuse = getTop3Param(obj, ak, opt, optSequence)

    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(TOP3_URL,param_fuse.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }

    //解析top3接口返回值,获取线路
    val httpData: (String, String, String, String) = parseTop3HttpData(retJSONObject)
    obj.put("polyline_sf",httpData._3)
    obj.put("distance_sf",httpData._4)
    obj
  }

  /**
   * top3接口返回值解析函数
   * @param httpData
   * @return
   */
  def parseTop3HttpData(ret : JSONObject) : (String,String,String,String) ={
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        logger.error("获取轨迹数据失败: " + ret.getString("info"))
        return (codeStatue, "请求失败", ret.getString("info"), null)
      } else {
        val polylineX =
          try {
            ret.getJSONObject("basePath").getJSONArray("pathes").getJSONObject(0).getJSONArray("polylineX").toArray()
          } catch {
            case _ => null
          }
        val polylineY =
          try {
            ret.getJSONObject("basePath").getJSONArray("pathes").getJSONObject(0).getJSONArray("polylineY").toArray()
          } catch {
            case _ => null
          }
        val distance =
          try {
            ret.getJSONObject("basePath").getJSONArray("pathes").getJSONObject(0).getString("distance")
          } catch {
            case _ => null
          }

        val polyline = getPolyline(polylineX, polylineY)
        return (codeStatue, "成功", polyline, distance)
      }
    }
    ("2", "请求失败", null, null)
  }

  /**
   * Fuse 调相似度接口
   * @param spark
   * @param dataDF
   */
  def runFuseSimilarityInteface(ak:String, obj: JSONObject) = {
    val polyline_fuse = JSONUtil.getJsonVal(obj, "polyline_fuse", "")
    val tracks2 = JSONUtil.getJsonVal(obj, "tracks2", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "6")

    //初始化polyline_fuse轨迹对比接口参数
    val param_fuse = new JSONObject()
    param_fuse.put("tracks1", tarckChanangeToJSONObject(polyline_fuse))
    param_fuse.put("ak", ak)
    param_fuse.put("tracks2", tarckChanangeToJSONObject(tracks2))
    param_fuse.put("tracktype", 0)
    param_fuse.put("vehicle", vehicle)
    param_fuse.put("retflag", 5)

    //向接口发送Post请求获取数据
    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(COMPARE_TRACK_URL,param_fuse.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析Fuse相似度接口返回值,获取线路
    val httpData: (String, String, String, String) = parseSimilarityHttpData(retJSONObject)
    obj.put("sim1_fuse",httpData._3)
    obj.put("sim5_fuse",httpData._4)
    obj
  }

  /**
   * GD 调相似度接口
   * @param spark
   * @param dataDF
   */
  def runGDSimilarityInteface(ak:String, obj: JSONObject) = {
    val polyline_gd = JSONUtil.getJsonVal(obj, "polyline_gd", "")
    val tracks2 = JSONUtil.getJsonVal(obj, "tracks2", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "6")

    //初始化polyline_gd轨迹对比接口参数
    val param_gd = new JSONObject()
    param_gd.put("tracks1", tarckChanangeToJSONObject(polyline_gd))
    param_gd.put("ak", ak)
    param_gd.put("tracks2", tarckChanangeToJSONObject(tracks2))
    param_gd.put("tracktype", 0)
    param_gd.put("vehicle", vehicle)
    param_gd.put("retflag", 5)

    //向接口发送Post请求获取数据
    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(COMPARE_TRACK_URL,param_gd.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析Fuse相似度接口返回值,获取线路
    val httpData: (String, String, String, String) = parseSimilarityHttpData(retJSONObject)
    obj.put("sim1_gd",httpData._3)
    obj.put("sim5_gd",httpData._4)

    obj
  }

  /**
   * Fuse和GD 调相似度接口
   * @param spark
   * @param dataDF
   */
  def runFuseAndGDSimilarityInteface(ak:String, obj: JSONObject) = {
    val polyline_jy_sf_gd = JSONUtil.getJsonVal(obj, "polyline_jy_sf_gd", "")
    val tracks2 = JSONUtil.getJsonVal(obj, "tracks2", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "6")

    //初始化polyline_jy_sf_gd轨迹对比接口参数
    val param_gd = new JSONObject()
    param_gd.put("tracks1", tarckChanangeToJSONObject(polyline_jy_sf_gd))
    param_gd.put("ak", ak)
    param_gd.put("tracks2", tarckChanangeToJSONObject(tracks2))
    param_gd.put("tracktype", 0)
    param_gd.put("vehicle", vehicle)
    param_gd.put("retflag", 5)

    //向接口发送Post请求获取数据
    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(COMPARE_TRACK_URL,param_gd.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析Fuse相似度接口返回值,获取线路
    val httpData: (String, String, String, String) = parseSimilarityHttpData(retJSONObject)
    obj.put("sim1_jy_sf_gd",httpData._3)
    obj.put("sim5_jy_sf_gd",httpData._4)

    obj
  }

  /**
   * JY 调相似度接口
   * @param spark
   * @param dataDF
   */
  def runJYSimilarityInteface(ak:String, obj: JSONObject) = {
    val polyline_jy = JSONUtil.getJsonVal(obj, "polyline_jy", "")
    val tracks2 = JSONUtil.getJsonVal(obj, "tracks2", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "6")

    //初始化polyline_jy轨迹对比接口参数
    val param_fuse = new JSONObject()
    param_fuse.put("tracks1", tarckChanangeToJSONObject(polyline_jy))
    param_fuse.put("ak", ak)
    param_fuse.put("tracks2", tarckChanangeToJSONObject(tracks2))
    param_fuse.put("tracktype", 0)
    param_fuse.put("vehicle", vehicle)
    param_fuse.put("retflag", 5)

    //向接口发送Post请求获取数据
    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(COMPARE_TRACK_URL,param_fuse.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析Fuse相似度接口返回值,获取线路
    val httpData: (String, String, String, String) = parseSimilarityHttpData(retJSONObject)
    obj.put("sim1_jy",httpData._3)
    obj.put("sim5_jy",httpData._4)
    obj
  }

  /**
   * SF 调相似度接口
   * @param spark
   * @param dataDF
   */
  def runSFSimilarityInteface(ak:String, obj: JSONObject) = {
    val polyline_sf = JSONUtil.getJsonVal(obj, "polyline_sf", "")
    val tracks2 = JSONUtil.getJsonVal(obj, "tracks2", "")
    val vehicle = JSONUtil.getJsonVal(obj, "vehicle_type", "6")

    //初始化polyline_sf轨迹对比接口参数
    val param_fuse = new JSONObject()
    param_fuse.put("tracks1", tarckChanangeToJSONObject(polyline_sf))
    param_fuse.put("ak", ak)
    param_fuse.put("tracks2", tarckChanangeToJSONObject(tracks2))
    param_fuse.put("tracktype", 0)
    param_fuse.put("vehicle", vehicle)
    param_fuse.put("retflag", 5)

    //向接口发送Post请求获取数据
    var retJSONObject = new JSONObject()
    try {
      val retStr: String = UrlUtil.sendPost(COMPARE_TRACK_URL,param_fuse.toJSONString,3)
      retJSONObject = JSON.parseObject(retStr)
    } catch {
      case e: Exception => logger.error(e)
    }
    //解析Fuse相似度接口返回值,获取线路
    val httpData: (String, String, String, String) = parseSimilarityHttpData(retJSONObject)
    obj.put("sim1_sf",httpData._3)
    obj.put("sim5_sf",httpData._4)
    obj
  }

  /**
   * 相似度接口返回值解析函数
   * @param httpData
   * @return
   */
  def parseSimilarityHttpData(ret : JSONObject) : (String,String,String,String) = {
    if (ret != null ) {
      //获取返回请求返回状态
      val codeStatue = ret.getString("status")
      //判断获取的数据是否成功
      if (!"0".equalsIgnoreCase(codeStatue)) {
        logger.error("post请求获取数据失败: " + ret.getJSONObject("result").toJSONString)
        return (codeStatue, ret.getJSONObject("result").getString("msg"), null, null)
      } else {
        val similarity1 =
          try {
            ret.getJSONObject("result").getString("similarity1")
          } catch {
            case _ => null
          }
        val similarity2 =
          try {
            ret.getJSONObject("result").getString("similarity2")
          } catch {
            case _ => null
          }
        return (codeStatue, "成功", similarity1,similarity2)
      }
    }
    ("2", "请求失败", null, null)
  }

  /**
   * 将接口返回轨迹数据转换成x,y格式
   * @param polylineX
   * @param polylineY
   * @return
   */
  def getPolyline(polylineX: Array[AnyRef], polylineY: Array[AnyRef]) = {
    val r = 3600000
    var lastX = -100.0
    var lastY = -100.0
    val arr_track = new ArrayBuffer[String]()
    val arr_tracks = new ArrayBuffer[String]()

    try{
      for (i <- 0 until polylineX.length) {
        if(i == 0){
          lastX = polylineX(i).toString.toDouble
          lastY = polylineY(i).toString.toDouble
        }else{
          lastX = lastX + polylineX(i).toString.toDouble
          lastY = lastY + polylineY(i).toString.toDouble
        }
        val x = lastX / r
        val y = lastY / r

        val track = s"""[${x},${y}]"""
        arr_track.append(track)
      }
    }catch {
      case e: Exception => logger.error(e)
    }

    val track = arr_track.mkString(",")
    val tracks = s"""[${track}]"""
    arr_tracks.append(tracks)
    val Polyline = arr_tracks.mkString(",")
    Polyline
  }

  /**
   * 将轨迹点转换成接口需要的格式JSONArray
   * @param track
   * @return
   */
  def tarckChanangeToJSONObject(track: String) = {
    val track_Obj = new JSONArray()
    if(track != "" && track != null ) {
      var trackJSONArray = new JSONArray()
      try {
        trackJSONArray = JSON.parseArray(track)
      } catch {
        case e: Exception => logger.error("轨迹转换成JSONArray出错："+e)
      }
      for (i <- 0 until trackJSONArray.size()) {
        val arr = trackJSONArray.getJSONArray(i)
        if (arr.size() == 2) {
          val obj = new JSONObject()
          try {
            obj.put("x", arr.getString(0).toDouble)
            obj.put("y", arr.getString(1).toDouble)
            obj.put("type", 1)
            track_Obj.add(obj)
          } catch {
            case e: Exception => logger.error("轨迹坐标转换成Double出错："+e)
          }
        }
      }
    }
    track_Obj
  }

  /**
   * 从宽表数据取数统计，并将统计结果存入hive表
   * @param spark
   * @param DayBefore2
   */
  def saveStatisticalTableToHive(spark: SparkSession, DayBefore2: String) = {
    val calcSql =
      s"""
         |insert overwrite table dm_gis.gis_navi_optSequence_top3_sim_statistics partition (inc_day='$DayBefore2')
         |select
         |  MD5UDF(CONCAT(src, driver_type, '$DayBefore2', rand(10))) as md5_id,
         |  src,
         |  driver_type,
         |  distance_fuse,
         |  distance_gd,
         |  count(distinct navi_id) as all_navi_num,
         |  count(if(sim1_fuse > '0.8', 1, null)) as sim1_fuse_num,
         |  count(if(sim5_fuse > '0.8', 1, null)) as sim5_fuse_num,
         |  count(if(sim15_fuse > '0.8', 1, null)) as sim15_fuse_num,
         |  count(if(sim1_gd > '0.8', 1, null)) as sim1_gd_num,
         |  count(if(sim5_gd > '0.8', 1, null)) as sim5_gd_num,
         |  count(if(sim15_gd > '0.8', 1, null)) as sim15_gd_num,
         |  pull_navi_type,
         |  count(if(sim1_jy_sf_gd > '0.8', 1, null)) as sim1_jy_sf_gd_num,
         |  count(if(sim5_jy_sf_gd > '0.8', 1, null)) as sim5_jy_sf_gd_num,
         |  count(if(sim15_jy_sf_gd > '0.8', 1, null)) as sim15_jy_sf_gd_num,
         |  count(if(sim1_gd <> '' and sim5_gd <> '', 1, null)) as gdnumll,
         |  count(if(sim1_jy > '0.8', 1, null)) as sim1_jy_num,
         |  count(if(sim5_jy > '0.8', 1, null)) as sim5_jy_num,
         |  count(if(sim15_jy > '0.8', 1, null)) as sim15_jy_num,
         |  count(if(sim1_sf > '0.8', 1, null)) as sim1_sf_num,
         |  count(if(sim5_sf > '0.8', 1, null)) as sim5_sf_num,
         |  count(if(sim15_sf > '0.8', 1, null)) as sim15_sf_num
         |from(
         |    select
         |      src,
         |      case
         |        when driver_type = '0' then '自营'
         |        when driver_type = '1' then '个体或企业'
         |        when driver_type = '2' then '个人'
         |        when driver_type = '3' then '外请'
         |        else '其他'
         |      end as driver_type,
         |      case
         |        when distance_fuse / 1000 < 5 then '小于5KM'
         |        when 5 <= distance_fuse / 1000
         |        and distance_fuse / 1000 < 10 then '5-10KM'
         |        when 10 <= distance_fuse / 1000
         |        and distance_fuse / 1000 < 30 then '10-30KM'
         |        when 30 <= distance_fuse / 1000
         |        and distance_fuse / 1000 < 50 then '30-50KM'
         |        when 50 <= distance_fuse / 1000
         |        and distance_fuse / 1000 < 100 then '50-100KM'
         |        when 100 <= distance_fuse / 1000 then '100KM以上'
         |        else '其他'
         |      end as distance_fuse,
         |      case
         |        when distance_gd / 1000 < 5 then '小于5KM'
         |        when 5 <= distance_gd / 1000
         |        and distance_gd / 1000 < 10 then '5-10KM'
         |        when 10 <= distance_gd / 1000
         |        and distance_gd / 1000 < 30 then '10-30KM'
         |        when 30 <= distance_gd / 1000
         |        and distance_gd / 1000 < 50 then '30-50KM'
         |        when 50 <= distance_gd / 1000
         |        and distance_gd / 1000 < 100 then '50-100KM'
         |        when 100 <= distance_gd / 1000 then '100KM以上'
         |        else '其他'
         |      end as distance_gd,
         |      navi_id,
         |      sim1_fuse,
         |      sim5_fuse,
         |      sim15_fuse,
         |      sim1_gd,
         |      sim5_gd,
         |      sim15_gd,
         |      sim15_jy_sf_gd,
         |      sim1_jy_sf_gd,
         |      sim5_jy_sf_gd,
         |      sim15_jy,
         |      sim1_jy,
         |      sim5_jy,
         |      sim15_sf,
         |      sim1_sf,
         |      sim5_sf,
         |      pull_navi_type,
         |      inc_day
         |    from
         |      dm_gis.gis_navi_optSequence_top3_sim
         |    where
         |      inc_day = '$DayBefore2'
         |      and sim1_fuse <> ''
         |      and sim5_fuse <> ''
         |      and sim1_jy_sf_gd <> ''
         |      and sim5_jy_sf_gd <> ''
         |  ) t1
         |group by src,driver_type,distance_fuse,distance_gd,pull_navi_type,inc_day
         |""".stripMargin
    println(calcSql)
    spark.sql(calcSql)
    println("dm_gis.gis_navi_optSequence_top3_sim_statistics 数据落表完成")
  }

}
