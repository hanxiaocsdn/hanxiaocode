package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.SpecialInboundIdentificationReport;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

public class SpecialInboundAddrGroupController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(SpecialInboundAddrGroupController.class);
    private static String spliturl = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=e9106d80834e483189c3439938bac5d2&address=%s&city=%s&opt=zh";
    private static String account = "01399581";
    private static String taskId = "762332";
    private static String taskName = "冷运场景下在库数据聚合逻辑表输出";

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());

        JavaRDD<SpecialInboundIdentificationReport> rdd = loadData(sparkInfo, date, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        String id = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, taskId, taskName, "", spliturl, "e9106d80834e483189c3439938bac5d2", rdd.count(), 40);
        JavaRDD<SpecialInboundIdentificationReport> splitResultRdd = rdd.map(o -> {
            String addr = o.getAddress();
            String citycode = o.getCitycode();
            String splitResult = "";
            if (StringUtils.isNotEmpty(addr)) {
                String req = String.format(spliturl, URLEncoder.encode(addr, "UTF-8"), citycode);
                String content = HttpInvokeUtil.sendGet(req);
                if (StringUtils.isNotEmpty(content)) {
                    try {
                        splitResult = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            o.setSplitResult(splitResult);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitResultRdd cnt:{}", splitResultRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);

        JavaRDD<SpecialInboundIdentificationReport> joinRdd = splitResultRdd.map(o -> {
            String splitResult = o.getSplitResult();
            if (StringUtils.isNotEmpty(splitResult)) {
                String split = splitResult.split(";")[0];
//                陕西省^11,西安市^12,临潼区^13,嘉浩丝路科技产业园^213,3号库^214
                String[] split1 = split.split(",");
                List<String> list = new ArrayList<>();
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String level = split2[1];
                        if (!StringUtils.equals(level, "613")) {
                            list.add(level.substring(1, level.length()));
                        }
                    }
                }
                String join = list.size() > 0 ? String.join("#", list) : "";
                o.setJoin_level("#" + join);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("joinRdd cnt:{}", joinRdd.count());
        splitResultRdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> term1Rdd = joinRdd.map(SpecialInboundIdentificationReportController::processJoin).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("term1Rdd cnt:{}", term1Rdd.count());
        joinRdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> noEqRdd = term1Rdd.filter(o -> !(StringUtils.equals(o.getType(), "4") || StringUtils.equals(o.getType(), "8") || StringUtils.equals(o.getType(), "9"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEqRdd cnt:{}", noEqRdd.count());

        JavaRDD<SpecialInboundIdentificationReport> eq1or2Rdd = noEqRdd.filter(o -> StringUtils.equals(o.getType(), "1") || StringUtils.equals(o.getType(), "2")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SpecialInboundIdentificationReport> noEq1or2Rdd = noEqRdd.filter(o -> !(StringUtils.equals(o.getType(), "1") || StringUtils.equals(o.getType(), "2"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2Rdd cnt:{}", eq1or2Rdd.count());
        logger.error("noEq1or2Rdd cnt:{}", noEq1or2Rdd.count());
        noEqRdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> eq1or2Contains13Rdd = eq1or2Rdd.filter(o -> StringUtils.isNotEmpty(o.getJoin_level()) && o.getJoin_level().contains("#13")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SpecialInboundIdentificationReport> eq1or2NoContains13Rdd = eq1or2Rdd.filter(o -> !(StringUtils.isNotEmpty(o.getJoin_level()) && o.getJoin_level().contains("#13"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2Contains13Rdd cnt:{}", eq1or2Contains13Rdd.count());
        logger.error("eq1or2NoContains13Rdd cnt:{}", eq1or2NoContains13Rdd.count());
        eq1or2Rdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> eq1or2Contains13Term2Rdd = eq1or2Contains13Rdd.map(o -> {
            String term1 = o.getTerm1();
            String term2 = "";
            String splitResult = o.getSplitResult();
            String split = splitResult.split(";")[0];
            String[] split1 = split.split(",");
            for (String s : split1) {
                String[] split2 = s.split("\\^");
                if (split2.length >= 2) {
                    String word = split2[0];
                    String level = split2[1];
                    String substring = level.substring(1, level.length());
                    if (!StringUtils.equals(level, "613") && StringUtils.equals(substring, "13")) {
                        term2 = term1 + word;
                        break;
                    }
                }
            }
            o.setTerm2(term2);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2Contains13Term2Rdd cnt:{}", eq1or2Contains13Term2Rdd.count());
        eq1or2Contains13Rdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> eq1or2NoContains13Term2Rdd = eq1or2NoContains13Rdd.filter(o -> {
            boolean flag = false;
            String join_level = o.getJoin_level();
            if (StringUtils.isNotEmpty(join_level) && join_level.contains("#11")) {
                int index11 = join_level.indexOf("#11");
                String splitResult = o.getSplitResult();
                if (StringUtils.isNotEmpty(splitResult)) {
                    String split = splitResult.split(";")[0];
//                陕西省^11,西安市^12,临潼区^13,嘉浩丝路科技产业园^213,3号库^214
                    String[] split1 = split.split(",");
                    List<String> list = new ArrayList<>();
                    for (String s : split1) {
                        String[] split2 = s.split("\\^");
                        if (split2.length >= 2) {
                            String level = split2[1];
                            if (!StringUtils.equals(level, "613")) {
                                list.add(level.substring(1, level.length()));
                            } else {
                                list.add(level);
                            }
                        }
                    }

                    String join = list.size() > 0 ? String.join("#", list) : "";
                    String temp_join_level = "#" + join;

                    if ((StringUtils.isNotEmpty(temp_join_level) && temp_join_level.contains("#613") && temp_join_level.indexOf("#613") > temp_join_level.indexOf("#11")) || (join_level.contains("#16") && join_level.indexOf("#16") > index11) || (join_level.contains("#17") && join_level.indexOf("#17") > index11)) {
                        flag = true;
                    }
                }
            }
            return flag;
        }).map(o -> {
            String term1 = o.getTerm1();
            String term2 = "";
            String splitResult = o.getSplitResult();
            if (StringUtils.isNotEmpty(splitResult)) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.equals(level, "613") || StringUtils.equals(substring, "16") || StringUtils.equals(substring, "17")) {
                            term2 = term1 + word;
                            break;
                        }
                    }
                }
            }
            o.setTerm2(term2);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1or2NoContains13Term2Rdd cnt:{}", eq1or2NoContains13Term2Rdd.count());
        eq1or2NoContains13Rdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> term3Rdd = eq1or2Contains13Term2Rdd.union(noEq1or2Rdd).map(o -> {
            String term3 = "";
            int cnt = caculate(o);
            if (cnt > 1) {
                String type = o.getType();
                if (StringUtils.equals(type, "1") || StringUtils.equals(type, "2")) {
                    String term2 = o.getTerm2();
                    StringBuilder sb = new StringBuilder(StringUtils.isNotEmpty(term2) ? term2 : "");
                    String splitResult = o.getSplitResult();
                    if (StringUtils.isNotEmpty(splitResult)) {
                        String split = splitResult.split(";")[0];
                        String[] split1 = split.split(",");
                        for (String s : split1) {
                            String[] split2 = s.split("\\^");
                            if (split2.length >= 2) {
                                String word = split2[0];
                                String level = split2[1];
                                String substring = level.substring(1, level.length());
                                if (StringUtils.equals(substring, "13")) {
                                    if (!term2.contains(word)) {
                                        sb.append(word);
                                    }
                                }
                            }
                        }
                    }
                    term3 = sb.toString();
                } else if (StringUtils.equals(type, "3") || StringUtils.equals(type, "5") || StringUtils.equals(type, "6") || StringUtils.equals(type, "7")) {
                    String term1 = o.getTerm1();
                    StringBuilder sb = new StringBuilder(StringUtils.isNotEmpty(term1) ? term1 : "");
                    String splitResult = o.getSplitResult();
                    if (StringUtils.isNotEmpty(splitResult)) {
                        String split = splitResult.split(";")[0];
                        String[] split1 = split.split(",");
                        for (String s : split1) {
                            String[] split2 = s.split("\\^");
                            if (split2.length >= 2) {
                                String word = split2[0];
                                String level = split2[1];
                                String substring = level.substring(1, level.length());
                                if (StringUtils.equals(substring, "13")) {
                                    if (!term1.contains(word)) {
                                        sb.append(word);
                                    }
                                }
                            }
                        }
                    }
                    term3 = sb.toString();
                }
            } else {
                if (processSplit(o)) {
                    String type = o.getType();
                    if (StringUtils.equals(type, "1") || StringUtils.equals(type, "2")) {
                        String term2 = o.getTerm2();
                        String splitResult = o.getSplitResult();
                        if (StringUtils.isNotEmpty(splitResult)) {
                            String split = splitResult.split(";")[0];
                            String[] split1 = split.split(",");
                            for (String s : split1) {
                                String[] split2 = s.split("\\^");
                                if (split2.length >= 2) {
                                    String word = split2[0];
                                    String level = split2[1];
                                    String substring = level.substring(1, level.length());
                                    if (StringUtils.equals(substring, "14") || StringUtils.equals(substring, "16") || StringUtils.equals(substring, "17")) {
                                        term3 = term2 + word;
                                        break;
                                    }
                                }
                            }
                        }
                    } else if (StringUtils.equals(type, "3") || StringUtils.equals(type, "5") || StringUtils.equals(type, "6") || StringUtils.equals(type, "7")) {
                        String term1 = o.getTerm1();
                        String splitResult = o.getSplitResult();
                        if (StringUtils.isNotEmpty(splitResult)) {
                            String split = splitResult.split(";")[0];
                            String[] split1 = split.split(",");
                            for (String s : split1) {
                                String[] split2 = s.split("\\^");
                                if (split2.length >= 2) {
                                    String word = split2[0];
                                    String level = split2[1];
                                    String substring = level.substring(1, level.length());
                                    if (StringUtils.equals(substring, "14") || StringUtils.equals(substring, "16") || StringUtils.equals(substring, "17")) {
                                        term3 = term1 + word;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            o.setTerm3(term3);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("term3Rdd cnt:{}", term3Rdd.count());
        eq1or2Contains13Term2Rdd.unpersist();
        noEq1or2Rdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> termRdd = term3Rdd.union(eq1or2NoContains13Term2Rdd).union(term1Rdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("termRdd cnt:{}", termRdd.count());
        term3Rdd.unpersist();
        eq1or2NoContains13Term2Rdd.unpersist();
        term1Rdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> areaRdd = termRdd.map(o -> {
            String splitResult = o.getSplitResult();
            StringBuilder sb = new StringBuilder();
            if (StringUtils.isNotEmpty(splitResult)) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.isNotEmpty(substring) && Integer.parseInt(substring) <= 3) {
                            sb.append(word);
                        }
                    }
                }
            }
            o.setArea(sb.toString());
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("areaRdd cnt:{}", areaRdd.count());
        termRdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> finalAreaRdd = areaRdd.mapToPair(o -> new Tuple2<>(o.getCitycode() + "_" + o.getTerm1(), o)).groupByKey().flatMap(tp -> {
            List<SpecialInboundIdentificationReport> list = Lists.newArrayList(tp._2);
            String finalarea = "";
            List<SpecialInboundIdentificationReport> filterList = list.stream().filter(o -> StringUtils.isNotEmpty(o.getArea())).collect(Collectors.toList());
            if (filterList.size() > 0) {
                finalarea = filterList.stream()
                        .collect(Collectors.groupingBy(SpecialInboundIdentificationReport::getArea))
                        .values()
                        .stream()
                        .max(Comparator.comparing(List::size))
                        .get()
                        .get(0)
                        .getArea();
            }
            String finalArea = finalarea;
            return list.stream().peek(o -> o.setFinalarea(finalArea)).collect(Collectors.toList()).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalAreaRdd cnt:{}", finalAreaRdd.count());
        areaRdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> termAddrRdd = finalAreaRdd.map(o -> {
            String type = o.getType();
            if (StringUtils.equals(type, "1") || StringUtils.equals(type, "2") || StringUtils.equals(type, "3") || StringUtils.equals(type, "4") || StringUtils.equals(type, "5") || StringUtils.equals(type, "6") || StringUtils.equals(type, "7") || StringUtils.equals(type, "8")) {
                o.setTerm1_addr(o.getFinalarea() + o.getTerm1());
            } else if (StringUtils.equals(type, "9")) {
                o.setTerm1_addr(o.getTerm1());
            }

            String term2 = o.getTerm2();
            if (StringUtils.isNotEmpty(term2)) {
                o.setTerm2_addr(o.getFinalarea() + term2);
            }

            String term3 = o.getTerm3();
            if (StringUtils.isNotEmpty(term3)) {
                o.setTerm3_addr(o.getFinalarea() + term3);
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("termAddrRdd cnt:{}", termAddrRdd.count());
        finalAreaRdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> termFreqRdd = termAddrRdd.mapToPair(o -> new Tuple2<>(o.getTerm1_addr(), o)).groupByKey().flatMap(tp -> {
            List<SpecialInboundIdentificationReport> list = Lists.newArrayList(tp._2);
            int term1_freq = list.size();
            return list.stream().peek(o -> o.setTerm1_freq(term1_freq + "")).collect(Collectors.toList()).iterator();
        }).mapToPair(o -> new Tuple2<>(o.getTerm2_addr(), o)).groupByKey().flatMap(tp -> {
            List<SpecialInboundIdentificationReport> list = Lists.newArrayList(tp._2);
            int term2_freq = list.size();
            return list.stream().peek(o -> o.setTerm2_freq(term2_freq + "")).collect(Collectors.toList()).iterator();
        }).mapToPair(o -> new Tuple2<>(o.getTerm3_addr(), o)).groupByKey().flatMap(tp -> {
            List<SpecialInboundIdentificationReport> list = Lists.newArrayList(tp._2);
            int term3_freq = list.size();
            return list.stream().peek(o -> o.setTerm3_freq(term3_freq + "")).collect(Collectors.toList()).iterator();
        }).map(o -> {
            String term1_addr = o.getTerm1_addr();
            String term2_addr = o.getTerm2_addr();
            String term3_addr = o.getTerm3_addr();

            if (StringUtils.isEmpty(term1_addr)) {
                o.setTerm1_freq("");
            }

            if (StringUtils.isEmpty(term2_addr)) {
                o.setTerm2_freq("");
            }

            if (StringUtils.isEmpty(term3_addr)) {
                o.setTerm3_freq("");
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("termFreqRdd cnt:{}", termFreqRdd.count());
        termAddrRdd.unpersist();

        JavaRDD<SpecialInboundIdentificationReport> lastRdd = termFreqRdd.mapToPair(o -> new Tuple2<>(o.getAddress_id(), o)).reduceByKey((o1, o2) -> {
            String term2 = o1.getTerm2();
            if (StringUtils.isNotEmpty(term2)) {
                return o1;
            } else {
                return o2;
            }
        }).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        termFreqRdd.unpersist();

        saveData(sparkInfo.getSession(), lastRdd, date, "dm_gis.specialstorage_addr_group");
        lastRdd.unpersist();

        sparkInfo.getContext().stop();
    }

    public static void saveData(SparkSession spark, JavaRDD<SpecialInboundIdentificationReport> inRdd, String date, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getAddress_id(), o.getZc(), o.getCitycode(), o.getAddress(), o.getCompany_name(), o.getSplitResult(),
                    o.getTerm1(), o.getTerm1_addr(), o.getTerm1_freq(),
                    o.getTerm2(), o.getTerm2_addr(), o.getTerm2_freq(),
                    o.getTerm3(), o.getTerm3_addr(), o.getTerm3_freq()
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        if (rows.count() > 0) {
            int partSize = CalPartitionUtil.getPartitionSize(rows);
            List<StructField> structFieldList = new ArrayList<>();
            String[] columnNames = new String[]{
                    "address_id", "zc", "citycode", "address", "company_name", "splitResult",
                    "term1", "term1_addr", "term1_freq",
                    "term2", "term2_addr", "term2_freq",
                    "term3", "term3_addr", "term3_freq"
            };
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }
            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = spark.createDataFrame(rows.repartition(partSize), structType);
            String tempTable = "specialstorage_addr_group_" + System.currentTimeMillis();
            ds.createOrReplaceTempView(tempTable);
            logger.error("targetTable:{}", table);
            spark.sql(String.format("insert overwrite table %s partition(inc_day = '%s') " +
                    "select * from %s", table, date, tempTable));
            rows.unpersist();
            spark.catalog().dropTempView(tempTable);
        }
    }


    public static boolean processSplit(SpecialInboundIdentificationReport o) {
        boolean flag1 = false;
        boolean flag2 = false;
        String splitResult = o.getSplitResult();
        if (StringUtils.isNotEmpty(splitResult)) {
            String split = splitResult.split(";")[0];
//                陕西省^11,西安市^12,临潼区^13,嘉浩丝路科技产业园^213,3号库^214
            String[] split1 = split.split(",");
            List<String> list = new ArrayList<>();
            for (String s : split1) {
                String[] split2 = s.split("\\^");
                if (split2.length >= 2) {
                    String word = split2[0];
                    String level = split2[1];
                    String substring = level.substring(1, level.length());
                    if (!StringUtils.equals(level, "613")) {
                        list.add(substring);
                        if (StringUtils.equals(substring, "13")) {
                            if (StringUtils.isNotEmpty(word) && (word.endsWith("物流园") || word.endsWith("产业园") || word.endsWith("工业园") || word.endsWith("园区") || word.endsWith("基地"))) {
                                flag1 = true;
                            }
                        }
                    } else {
                        list.add(substring);
                    }
                }
            }
            String join = list.size() > 0 ? String.join("#", list) : "";
            String temp_join_level = "#" + join;
            if (StringUtils.isNotEmpty(temp_join_level) && temp_join_level.contains("#13")) {
                int index13 = temp_join_level.indexOf("#13");
                int index14 = temp_join_level.indexOf("#14");
                int index16 = temp_join_level.indexOf("#16");
                int index17 = temp_join_level.indexOf("#17");
                if (index14 > index13 || index16 > index13 || index17 > index13) {
                    flag2 = true;
                }
            }
        }
        return flag1 && flag2;
    }

    public static int caculate(SpecialInboundIdentificationReport o) {
        String splitResult = o.getSplitResult();
        int cnt = 0;
        if (StringUtils.isNotEmpty(splitResult)) {
            String split = splitResult.split(";")[0];
            String[] split1 = split.split(",");
            for (String s : split1) {
                String[] split2 = s.split("\\^");
                if (split2.length >= 2) {
                    String level = split2[1];
                    String substring = level.substring(1, level.length());
                    if (StringUtils.equals(substring, "13")) {
                        cnt++;
                    }
                }
            }
        }
        return cnt;
    }


    public static SpecialInboundIdentificationReport processJoin(SpecialInboundIdentificationReport o) {
        String join_level = o.getJoin_level();
        if (StringUtils.isNotEmpty(join_level)) {
            String splitResult = o.getSplitResult();
            if (join_level.contains("#9#10#11")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag10 = 0;
                int tag11 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "10") || StringUtils.equals(substring, "11")) {
                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }
                            if (StringUtils.equals(substring, "10") && tag10 == 0) {
                                term1.append(word);
                                tag10 = tag10 + 1;
                            }
                            if (StringUtils.equals(substring, "11") && tag11 == 0) {
                                term1.append(word);
                                tag11 = tag11 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("1");
            } else if (join_level.contains("#9#11")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag11 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "11")) {

                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }

                            if (StringUtils.equals(substring, "11") && tag11 == 0) {
                                term1.append(word);
                                tag11 = tag11 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("2");

            } else if (join_level.contains("#9") && join_level.contains("#13")) {
                String split = sortSplitResult(splitResult);
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "13"))) {

                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("3");
            } else if (join_level.contains("#9#14")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag9 = 0;
                int tag14 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.equals(substring, "9") || StringUtils.equals(substring, "14")) {

                            if (StringUtils.equals(substring, "9") && tag9 == 0) {
                                term1.append(word);
                                tag9 = tag9 + 1;
                            }

                            if (StringUtils.equals(substring, "14") && tag14 == 0) {
                                term1.append(word);
                                tag14 = tag14 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("4");
            } else if (join_level.contains("#6") && join_level.contains("#13")) {
                String split = sortSplitResult(splitResult);
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag6 = 0;
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && (StringUtils.equals(substring, "6") || StringUtils.equals(substring, "13"))) {

                            if (StringUtils.equals(substring, "6") && tag6 == 0) {
                                term1.append(word);
                                tag6 = tag6 + 1;
                            }

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("5");
            } else if (join_level.contains("#5") && join_level.contains("#13")) {
                String split = sortSplitResult(splitResult);
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag5 = 0;
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && (StringUtils.equals(substring, "5") || StringUtils.equals(substring, "13"))) {

                            if (StringUtils.equals(substring, "5") && tag5 == 0) {
                                term1.append(word);
                                tag5 = tag5 + 1;
                            }

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("6");
            } else if (join_level.contains("#13")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                int tag13 = 0;
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (!StringUtils.equals(level, "613") && StringUtils.equals(substring, "13")) {

                            if (StringUtils.equals(substring, "13") && tag13 == 0) {
                                term1.append(word);
                                tag13 = tag13 + 1;
                            }
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("7");
            } else if (join_level.contains("#9")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.isNotEmpty(substring) && Integer.parseInt(substring) >= 9) {
                            term1.append(word);
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("8");
            } else if (join_level.contains("#11") || join_level.contains("#12") || join_level.contains("#13") || join_level.contains("#14") || join_level.contains("#15") || join_level.contains("#16") || join_level.contains("#17") || join_level.contains("#18")) {
                String split = splitResult.split(";")[0];
                String[] split1 = split.split(",");
                StringBuilder term1 = new StringBuilder();
                for (String s : split1) {
                    String[] split2 = s.split("\\^");
                    if (split2.length >= 2) {
                        String word = split2[0];
                        String level = split2[1];
                        String substring = level.substring(1, level.length());
                        if (StringUtils.isNotEmpty(substring)) {
                            term1.append(word);
                        }
                    }
                }
                o.setTerm1(term1.toString());
                o.setType("9");
            }
        }
        return o;
    }

    public static String sortSplitResult(String splitResult) {
        String sortSplit = "";
        if (StringUtils.isNotEmpty(splitResult)) {
            String split = splitResult.split(";")[0];
            List<String> collect = Arrays.stream(split.split(",")).sorted((o1, o2) -> {
                int code = 0;
                String[] split1 = o1.split("\\^");
                String[] split2 = o2.split("\\^");
                if (split1.length >= 2 && split2.length >= 2) {
                    String level1 = split1[1];
                    String level2 = split2[1];

                    String substring1 = level1.substring(1, level1.length());
                    String substring2 = level2.substring(1, level2.length());
                    if (Integer.parseInt(substring1) < Integer.parseInt(substring2)) {
                        code = -1;
                    } else if (Integer.parseInt(substring1) > Integer.parseInt(substring2)) {
                        code = 1;
                    }
                }
                return code;
            }).collect(Collectors.toList());
            sortSplit = String.join(",", collect);
        }
        return sortSplit;
    }

    public JavaRDD<SpecialInboundIdentificationReport> loadData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select address_id,area_code zc,citycode,address,company_name from dm_gis.specialstorage_baseaddress_lengyun where inc_day between '%s' and '%s' and del_flag = 0", startDate, endDate);
        //加载数据
        return DataUtil.loadData(si, sql, SpecialInboundIdentificationReport.class);
    }
}
