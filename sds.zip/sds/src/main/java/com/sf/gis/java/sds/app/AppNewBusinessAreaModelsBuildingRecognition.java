package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.DwdWaybillInfoDtlDi;
import com.sf.gis.java.sds.pojo.NewBusinessAreaModelsBuildingRecognitionDetail;
import com.sf.gis.java.sds.pojo.NewBusinessAreaModelsBuildingRecognitionStat;
import com.sf.gis.scala.base.spark.SparkUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import com.sf.gis.scala.base.pojo.Cnt;
import com.sf.gis.scala.base.pojo.StratTime;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 任务id：959998（【商圈区域划分】业务新区域模式楼栋识别量需求）
 * 业务方：01434061（褚鑫诚）
 * 研发：01399581（匡仁衡）
 */

public class AppNewBusinessAreaModelsBuildingRecognition {
    private static final Logger logger = Logger.getLogger(AppNewBusinessAreaModelsBuildingRecognition.class);
    private static String atpoi = "http://gis-gw.int.sfdc.com.cn:9080/atpoi/api";
    private static int limitMin = 3000 / 5;

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:" + startDate);
        logger.error("endDate:" + endDate);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppNewBusinessAreaModelsBuildingRecognition");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("获取源数据");
        JavaRDD<DwdWaybillInfoDtlDi> rdd = getData(spark, sc, startDate, endDate);
        logger.error("将数据转化并过滤aoi");
        JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> transformRdd = transform(spark, sc, rdd);
        logger.error("调楼栋识别接口");
        List<String> list = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (String date : list) {
            logger.error("date:" + date);
            JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> dateRdd = transformRdd.filter(o -> StringUtils.equals(o.getInc_day(), date)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("dateRdd cnt:" + dateRdd.count());
            try {
                stat(spark, sc, dateRdd);
            } catch (Exception e) {
                logger.error("date:" + date + ",process error");
            }
        }
        transformRdd.unpersist();
        sc.stop();
        logger.error("end...");
    }

    public static void stat(SparkSession spark, JavaSparkContext sc, JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> dateRdd) {
        JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> uniqueRdd = dateRdd.mapToPair(o -> new Tuple2<>(o.getAddr(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueRdd cnt:" + uniqueRdd.count());

        JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> uniqueDetailRdd = uniqueRdd.repartition(5).mapPartitionsWithIndex(((index, itr) -> {
            ArrayList<NewBusinessAreaModelsBuildingRecognitionDetail> list = new ArrayList<>();
            StratTime stratTime = new StratTime(System.currentTimeMillis());
            Cnt cnt = new Cnt(0);
            while (itr.hasNext()) {
                SparkUtils.limitAkUse(stratTime, cnt, index, limitMin, logger);
                NewBusinessAreaModelsBuildingRecognitionDetail o = itr.next();
                String addr = o.getAddr();
                String city_code = o.getCity_code();

                JSONObject param = new JSONObject();
                param.put("cityCode", city_code);
                param.put("address", addr);
                param.put("requestId", System.currentTimeMillis());
                String content = HttpInvokeUtil.sendPostHeader(atpoi, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE, "ak", "0a2521b0b871463ca5fa65445bf33ac0", "utf-8", "utf-8");
                o.setResp(content);
                String aoiId = "";
                String buildingId = "";
                try {
                    aoiId = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("aoiId");
                    buildingId = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("buildingId");
                } catch (Exception e) {
//                        e.printStackTrace();
                }
                logger.error("aoiId:" + aoiId);
                logger.error("buildingId:" + buildingId);
                o.setAoi_id(aoiId);
                o.setBuilding_id(buildingId);
                list.add(o);
            }
            return list.iterator();
        }), false).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueDetailRdd cnt:" + uniqueDetailRdd.count());
        uniqueRdd.unpersist();

        JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> returnRdd = dateRdd.mapToPair(o -> new Tuple2<>(o.getAddr(), o)).leftOuterJoin(uniqueDetailRdd.mapToPair(o -> new Tuple2<>(o.getAddr(), o))).map(tp -> {
            NewBusinessAreaModelsBuildingRecognitionDetail o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                NewBusinessAreaModelsBuildingRecognitionDetail other = tp._2._2.get();
                o.setResp(other.getResp());
                o.setAoi_id(other.getAoi_id());
                o.setBuilding_id(other.getBuilding_id());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("returnRdd cnt:" + returnRdd.count());
        dateRdd.unpersist();
        uniqueDetailRdd.unpersist();

        logger.error("明细数据存储");
        DataUtil.saveInto(spark, sc, "dm_gis.dwd_new_business_area_models_building_recognitionDetail_di", NewBusinessAreaModelsBuildingRecognitionDetail.class, returnRdd, "inc_day");

        logger.error("数据汇总");
        JavaRDD<NewBusinessAreaModelsBuildingRecognitionStat> statRdd = returnRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).groupByKey().map(tp -> {
            List<NewBusinessAreaModelsBuildingRecognitionDetail> list = Lists.newArrayList(tp._2);
            NewBusinessAreaModelsBuildingRecognitionDetail one = list.get(0);
            String aoi_id = one.getAoi_id();
            String city_code = one.getCity_code();
            String inc_day = one.getInc_day();

            int aoi_num = list.size();
            int poi_num = list.stream().filter(t -> StringUtils.isNotEmpty(t.getBuilding_id())).collect(Collectors.toList()).size();

            NewBusinessAreaModelsBuildingRecognitionStat o = new NewBusinessAreaModelsBuildingRecognitionStat();
            o.setAoi_id(aoi_id);
            o.setCity_code(StringUtils.isNotEmpty(aoi_id) ? city_code : "");
            o.setInc_day(inc_day);
            o.setAoi_id_num(aoi_num + "");
            o.setPoi_num(poi_num + "");

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statRdd cnt:" + statRdd.count());
        returnRdd.unpersist();

        logger.error("统计数据存储");
        DataUtil.saveInto(spark, sc, "dm_gis.dws_new_business_area_models_building_recognitionDetail_di", NewBusinessAreaModelsBuildingRecognitionStat.class, statRdd, "inc_day");
        statRdd.unpersist();

    }

    public static JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> transform(SparkSession spark, JavaSparkContext sc, JavaRDD<DwdWaybillInfoDtlDi> rdd) {
        String sql = "select\n" +
                "  aoi_id addressee_aoi_id\n" +
                "from\n" +
                "  dm_gis.poi_info\n" +
                "where\n" +
                "  inc_day = '20240222'\n" +
                "  and city_code in ('023', '021')\n" +
                "  and (aoi_id is not null and aoi_id <>'')\n" +
                "  group by aoi_id";
        JavaPairRDD<String, DwdWaybillInfoDtlDi> aoiRdd = DataUtil.loadData(spark, sc, sql, DwdWaybillInfoDtlDi.class).mapToPair(o -> new Tuple2<>(o.getAddressee_aoi_id(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:" + aoiRdd.count());

        JavaRDD<NewBusinessAreaModelsBuildingRecognitionDetail> filterAoiRdd = rdd.flatMap(o -> {
            ArrayList<NewBusinessAreaModelsBuildingRecognitionDetail> list = new ArrayList<>();
            NewBusinessAreaModelsBuildingRecognitionDetail o1 = new NewBusinessAreaModelsBuildingRecognitionDetail();
            o1.setAddr(o.getConsignor_addr_decrypt());
            o1.setCity_code(o.getSrc_dist_code());
            o1.setTemp_aoi(o.getConsignor_aoi_id());
            o1.setInc_day(o.getInc_day());

            NewBusinessAreaModelsBuildingRecognitionDetail o2 = new NewBusinessAreaModelsBuildingRecognitionDetail();
            o2.setAddr(o.getConsignee_addr_decrypt());
            o2.setCity_code(o.getDest_dist_code());
            o2.setTemp_aoi(o.getAddressee_aoi_id());
            o2.setInc_day(o.getInc_day());

            list.add(o1);
            list.add(o2);
            return list.iterator();
        }).filter(o -> StringUtils.isNotEmpty(o.getAddr()))
                .filter(o -> Arrays.asList("023,021".split(",")).contains(o.getCity_code()))
                .mapToPair(o -> new Tuple2<>(o.getTemp_aoi(), o))
                .leftOuterJoin(aoiRdd)
                .filter(tp -> tp._2._2 != null && tp._2._2.isPresent()).map(tp -> tp._2._1)
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterAoiRdd cnt:" + filterAoiRdd.count());
        rdd.unpersist();
        aoiRdd.unpersist();
        return filterAoiRdd;
    }

    public static JavaRDD<DwdWaybillInfoDtlDi> getData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select\n" +
                "  consignor_addr_decrypt,\n" +
                "  src_dist_code,\n" +
                "  consignor_aoi_id,\n" +
                "  consignee_addr_decrypt,\n" +
                "  dest_dist_code,\n" +
                "  addressee_aoi_id,\n" +
                "  inc_day\n" +
                "from\n" +
                "  dm_gis.dwd_waybill_info_dtl_di\n" +
                "where\n" +
                "  (\n" +
                "    src_dist_code in ('023', '021')\n" +
                "    or dest_dist_code in ('023', '021')\n" +
                "  )\n" +
                "  and inc_day between '%s'\n" +
                "  and '%s'", startDate, endDate);
        JavaRDD<DwdWaybillInfoDtlDi> rdd = DataUtil.loadData(spark, sc, sql, DwdWaybillInfoDtlDi.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());
        return rdd;
    }
}
