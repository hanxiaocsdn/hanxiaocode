package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Entity;
import java.io.UnsupportedEncodingException;

@Entity
public class GisPaiAddrFreqStat {
    @Column(name = "key")
    private String key;
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "address")
    private String address;
    @Column(name = "match_freq")
    private int match_freq;
    @Column(name = "src")
    private String src;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "inc_day")
    private String inc_day;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getMatch_freq() {
        return match_freq;
    }

    public void setMatch_freq(int match_freq) {
        this.match_freq = match_freq;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public GisPaiAddrFreqStat(String key, String address_id, String address, double match_freq, String src,
                              String citycode, String inc_day) {
        this.key = key;
        this.address_id = address_id;
        if (!containsMb4Char(address)) {
            this.address = address;
        } else {
            this.address = "";
        }

        this.match_freq = (int) match_freq;
        this.src = src;
        this.citycode = citycode;
        this.inc_day = inc_day;
    }

    public static boolean containsMb4Char(String input) {
        if (input == null) {
            return false;
        }

        try {
            byte[] bytes = input.getBytes("utf-8");
            for (int i = 0; i < bytes.length; i++) {
                byte b = bytes[i];
                // four bytes
                if ((b & 0XF0) == 0XF0) {
                    return true;
                } else if ((b & 0XE0) == 0XE0) {
                    // three bytes
                    // forward 2 byte
                    i += 2;
                } else if ((b & 0XC0) == 0XC0) {
                    i += 1;
                }
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return true;
        }

        return false;
    }

}