package com.sf.gis.java.sds.app;

//import com.sf.gis.java.sds.controller.TtOrderAoiInfoController1;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//
//public class AppTtOrderAoiInfo1 {
//    private static Logger logger = LoggerFactory.getLogger(AppTtOrderAoiInfo1.class);
//
//    public static void main(String[] args) {
//        String date = args[0];
//        String citycodes = args[1];
//        logger.error("date:{}", date);
//        logger.error("citycodes:{}", citycodes);
//        logger.error("run start");
//        new TtOrderAoiInfoController1().start(date, citycodes);
//        logger.error("run end");
//    }
//}
