package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.LbsLogStatController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id:374604(小哥行为管控服务日志指标统计)
 * 业务方：01408947（刘雨婷）
 * 研发：01399581（匡仁衡）
 */
public class LbsLogStatApp {
    private static final Logger logger = LoggerFactory.getLogger(LbsLogStatApp.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        new LbsLogStatController().process(startDate, endDate);
    }
}
