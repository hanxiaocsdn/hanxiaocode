package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class EtDeliveryAssistantClockInfo implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "addr_position")
    private String addr_position;
    @Column(name = "signin_tm")
    private String signin_tm;
    @Column(name = "emp1_code")
    private String emp1_code;
    @Column(name = "emp1_position")
    private String emp1_position;
    @Column(name = "emp1_tm")
    private String emp1_tm;
    @Column(name = "emp2_code")
    private String emp2_code;
    @Column(name = "emp2_position")
    private String emp2_position;
    @Column(name = "emp2_tm")
    private String emp2_tm;
    @Column(name = "is_emp1_onsite")
    private String is_emp1_onsite;
    @Column(name = "is_emp2_onsite")
    private String is_emp2_onsite;
    @Column(name = "is_emps_onsite")
    private String is_emps_onsite;
    @Column(name = "is_onsite")
    private String is_onsite;

    @Column(name = "tag")
    private String tag;
    @Column(name = "dis")
    private String dis;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "waybill_tag")
    private String waybill_tag;

    @Column(name = "inc_day")
    private String inc_day;

    private String resp1;
    private String resp2;

    public String getWaybill_tag() {
        return waybill_tag;
    }

    public void setWaybill_tag(String waybill_tag) {
        this.waybill_tag = waybill_tag;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getDis() {
        return dis;
    }

    public void setDis(String dis) {
        this.dis = dis;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getResp1() {
        return resp1;
    }

    public void setResp1(String resp1) {
        this.resp1 = resp1;
    }

    public String getResp2() {
        return resp2;
    }

    public void setResp2(String resp2) {
        this.resp2 = resp2;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getAddr_position() {
        return addr_position;
    }

    public void setAddr_position(String addr_position) {
        this.addr_position = addr_position;
    }

    public String getSignin_tm() {
        return signin_tm;
    }

    public void setSignin_tm(String signin_tm) {
        this.signin_tm = signin_tm;
    }

    public String getEmp1_code() {
        return emp1_code;
    }

    public void setEmp1_code(String emp1_code) {
        this.emp1_code = emp1_code;
    }

    public String getEmp1_position() {
        return emp1_position;
    }

    public void setEmp1_position(String emp1_position) {
        this.emp1_position = emp1_position;
    }

    public String getEmp1_tm() {
        return emp1_tm;
    }

    public void setEmp1_tm(String emp1_tm) {
        this.emp1_tm = emp1_tm;
    }

    public String getEmp2_code() {
        return emp2_code;
    }

    public void setEmp2_code(String emp2_code) {
        this.emp2_code = emp2_code;
    }

    public String getEmp2_position() {
        return emp2_position;
    }

    public void setEmp2_position(String emp2_position) {
        this.emp2_position = emp2_position;
    }

    public String getEmp2_tm() {
        return emp2_tm;
    }

    public void setEmp2_tm(String emp2_tm) {
        this.emp2_tm = emp2_tm;
    }

    public String getIs_emp1_onsite() {
        return is_emp1_onsite;
    }

    public void setIs_emp1_onsite(String is_emp1_onsite) {
        this.is_emp1_onsite = is_emp1_onsite;
    }

    public String getIs_emp2_onsite() {
        return is_emp2_onsite;
    }

    public void setIs_emp2_onsite(String is_emp2_onsite) {
        this.is_emp2_onsite = is_emp2_onsite;
    }

    public String getIs_emps_onsite() {
        return is_emps_onsite;
    }

    public void setIs_emps_onsite(String is_emps_onsite) {
        this.is_emps_onsite = is_emps_onsite;
    }

    public String getIs_onsite() {
        return is_onsite;
    }

    public void setIs_onsite(String is_onsite) {
        this.is_onsite = is_onsite;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
