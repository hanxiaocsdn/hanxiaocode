package com.sf.gis.java.sds.controller;

import com.sf.gis.java.base.api.AoiApi;
import com.sf.gis.java.base.dto.AoiInfo;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.constant.SdsConstant;
import com.sf.gis.java.sds.pojo.SrcData4RuralXyAoi;
import com.sf.gis.java.sds.service.RuralXyAoiService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 乡村驿站坐标转化为AOI控制器(需求：蓝媛青)
 * 任务ID：324639
 * 任务名称：根据乡村驿站坐标获取AOI
 * @author 01370539 Created On: May.07 2021
 */
public class RuralXyAoiController {
    private static final Logger logger = LoggerFactory.getLogger(RuralXyAoiController.class);

    private final RuralXyAoiService rxaService = new RuralXyAoiService();

    public void process(String statDate) {
        logger.error("process start. statDate - {}", statDate);
        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext jsc = sparkInfo.getContext();
        SparkSession ss = sparkInfo.getSession();

        JavaRDD<SrcData4RuralXyAoi> rddSd4rxa = rxaService.loadData(ss, jsc, statDate).persist(StorageLevel.MEMORY_AND_DISK_SER());

        rddSd4rxa.filter(temp -> StringUtils.isNotEmpty(temp.getLatitude())).take(1).forEach(temp -> {
            AoiInfo coord = AoiApi.getCoorAoiByDist(SdsConstant.GET_AOI_DISTANCE, temp.getLongitude(), temp.getLatitude());
            logger.error("for test: x: {}, y: {}, aoi: {}", temp.getLongitude(), temp.getLatitude(), coord.getAoiId());
        });

        logger.error("start get aoi by xy, need process count - {}", rddSd4rxa.count());
        JavaRDD<SrcData4RuralXyAoi> rddFinal = rddSd4rxa.map(temp -> {
            AoiInfo coord = AoiApi.getCoorAoiByDist(SdsConstant.GET_AOI_DISTANCE, temp.getLongitude(), temp.getLatitude());
            temp.setAoiid(coord.getAoiId());
            temp.setAoicode(coord.getAoiCode());
            return temp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());

        logger.error("complete get aoi by xy.");
        rddFinal.filter(temp -> StringUtils.isNotEmpty(temp.getLatitude())).take(1).forEach(temp -> logger.error("data - {}", temp.toString()));
        rddSd4rxa.unpersist();

        DataUtil.saveOverwrite(ss, jsc, "dm_gis.sds_ruralxy_aoi", SrcData4RuralXyAoi.class, rddFinal, "inc_day");
        rddFinal.unpersist();
        logger.error("process end.");

    }
}
