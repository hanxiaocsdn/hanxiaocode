package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;
import java.util.List;

@Table
public class ScheduleWidthData implements Serializable {
    @Column(name = "dept_code")
    private String dept_code;
    @Column(name = "loginid")
    private String loginid;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoi_name")
    private String aoi_name;
    @Column(name = "pick_jiti")
    private String pick_jiti;
    @Column(name = "send_jiti")
    private String send_jiti;
    @Column(name = "aoi_count")
    private String aoi_count;
    @Column(name = "inc_day")
    private String inc_day;

    @Column(name = "aoi_area_id")
    private String aoi_area_id;
    @Column(name = "batch_code")
    private String batch_code;
    @Column(name = "start_time")
    private String start_time;
    @Column(name = "end_time")
    private String end_time;

    private String jiti;
    private List<CmsAoiSch> list;
    private String sp_jiti;
    private String qd_jiti;
    private int aoi_size;

    public String getAoi_area_id() {
        return aoi_area_id;
    }

    public void setAoi_area_id(String aoi_area_id) {
        this.aoi_area_id = aoi_area_id;
    }

    public String getBatch_code() {
        return batch_code;
    }

    public void setBatch_code(String batch_code) {
        this.batch_code = batch_code;
    }

    public String getStart_time() {
        return start_time;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public String getEnd_time() {
        return end_time;
    }

    public void setEnd_time(String end_time) {
        this.end_time = end_time;
    }

    public String getPick_jiti() {
        return pick_jiti;
    }

    public void setPick_jiti(String pick_jiti) {
        this.pick_jiti = pick_jiti;
    }

    public String getSend_jiti() {
        return send_jiti;
    }

    public void setSend_jiti(String send_jiti) {
        this.send_jiti = send_jiti;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getQd_jiti() {
        return qd_jiti;
    }

    public void setQd_jiti(String qd_jiti) {
        this.qd_jiti = qd_jiti;
    }

    public String getAoi_count() {
        return aoi_count;
    }

    public String getSp_jiti() {
        return sp_jiti;
    }

    public void setSp_jiti(String sp_jiti) {
        this.sp_jiti = sp_jiti;
    }

    public void setAoi_count(String aoi_count) {
        this.aoi_count = aoi_count;
    }

    public String getJiti() {
        return jiti;
    }

    public void setJiti(String jiti) {
        this.jiti = jiti;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public List<CmsAoiSch> getList() {
        return list;
    }

    public void setList(List<CmsAoiSch> list) {
        this.list = list;
    }

    public int getAoi_size() {
        return aoi_size;
    }

    public void setAoi_size(int aoi_size) {
        this.aoi_size = aoi_size;
    }

    public String getLoginid() {
        return loginid;
    }

    public void setLoginid(String loginid) {
        this.loginid = loginid;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }
}
