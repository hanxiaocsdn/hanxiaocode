package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.CmsAoiTown;
import com.sf.gis.java.sds.pojo.XzqFindZcDiff;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 任务id：909994（【壹竿-SD】行政区找出网点不一致的数据）
 * 业务方：01424110（喻少丰）
 * 研发：01399581（匡仁衡）
 */

public class AppXzqFindZcDiffData {
    private static Logger logger = LoggerFactory.getLogger(AppXzqFindZcDiffData.class);
    private static String url = "http://gis-int.int.sfdc.com.cn:1080/split/api?address=%s&citycode=%s&ak=87106f6380af4df0845a693eee58843c";
    private static String account = "01399581";
    private static String taskId = "909994";
    private static String taskName = "【壹竿-SD】行政区找出网点不一致的数据";

    public static void main(String[] args) {
        String date = args[0];
        String cityCodes = args[1];
        logger.error("date:{}", date);
        logger.error("cityCodes:{}", cityCodes);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppXzqFindZcDiffData");
        SparkSession spark = sparkInfo.getSession();
        JavaSparkContext sc = sparkInfo.getContext();

        String lastest_date = spark.sql("show partitions dm_gis.cms_aoi_town").toJavaRDD().map(row -> row.getString(0)).collect().stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0).split("=")[1];
        logger.error("lastest_date:{}", lastest_date);
        String cms_aoi_town_sql = String.format("select\n" +
                "  a.aoi_id aoi_id,\n" +
                "  a.name_d name_d,\n" +
                "  b.zno_code zno_code\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      aoi_id,\n" +
                "      name_d\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_town\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "    group by\n" +
                "      aoi_id,\n" +
                "      name_d\n" +
                "  ) a\n" +
                "  left join (\n" +
                "    select\n" +
                "      aoi_id,\n" +
                "      zno_code\n" +
                "    from\n" +
                "      dm_gis.cms_aoi_sch\n" +
                "      group by aoi_id,zno_code\n" +
                "  ) b on a.aoi_id = b.aoi_id", lastest_date);
        JavaRDD<CmsAoiTown> cmsAoiTownRdd = DataUtil.loadData(spark, sc, cms_aoi_town_sql, CmsAoiTown.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiTownRdd cnt:{}", cmsAoiTownRdd.count());

        Properties city_num_map = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");
        for (Map.Entry<Object, Object> map : city_num_map.entrySet()) {
            String city = (String) map.getKey();
            if (!Arrays.asList(cityCodes.split(",")).contains(city)) {
                continue;
            }
            String num = (String) map.getValue();
            String table = "wchka.cms_address_" + num;
            String condition = String.format("city_code = '%s' and status = 1 and del_flag != 1", city);
            logger.error("获取表:{},city_code:{},数据", table, city);

            JavaRDD<XzqFindZcDiff> rdd = spark.read().format("jdbc")
                    .option("driver", "com.mysql.jdbc.Driver")
                    .option("url", "jdbc:mysql://wchka-s1.db.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull")
                    .option("dbtable", table)
                    .option("user", "wchka_aoi")
                    .option("password", "giscmsaoi123")
                    .load()
                    .where(condition)
                    .select("aoi_id", "city_code", "address", "address_id", "type", "zno_code", "adcode")
                    .repartition(10)
                    .toJavaRDD()
                    .map(row -> {
                        String aoi_id = "";
                        String city_code = "";
                        String address = "";
                        String address_id = "";
                        String type = "";
                        String zno_code = "";
                        String adcode = "";

                        try {
                            aoi_id = row.getString(0);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        try {
                            city_code = row.getString(1);
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }

                        try {
                            address = row.getString(2);
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }

                        try {
                            address_id = row.getString(3);
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }

                        try {
                            type = row.getInt(4) + "";
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }

                        try {
                            zno_code = row.getString(5);
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }

                        try {
                            adcode = row.getString(6);
                        } catch (Exception e) {
//                            e.printStackTrace();
                        }

                        XzqFindZcDiff o = new XzqFindZcDiff();
                        o.setAoi_id(fixnulltoStr(aoi_id));
                        o.setCity_code(fixnulltoStr(city_code));
                        o.setAddress(fixnulltoStr(address));
                        o.setAddress_id(fixnulltoStr(address_id));
                        o.setType(fixnulltoStr(type));
                        o.setZno_code(fixnulltoStr(zno_code));
                        o.setAdcode(fixnulltoStr(adcode));
                        o.setInc_day(date);
                        return o;
                    }).filter(o -> StringUtils.isNotEmpty(o.getAddress())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd cnt:{}", rdd.count());
            rdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", url, "87106f6380af4df0845a693eee58843c", rdd.count(), 10);
            JavaRDD<XzqFindZcDiff> nameRdd = rdd.map(o -> {
                String address = o.getAddress();
                String city_code = o.getCity_code();
                String req = String.format(url, URLEncoder.encode(address, "UTF-8"), city_code);
                String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                String name = getName(content);
                o.setName(name);
                return o;
            }).filter(o -> StringUtils.isNotEmpty(o.getName())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("nameRdd cnt:{}", nameRdd.count());
            rdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id);

            JavaRDD<XzqFindZcDiff> aoiRdd = nameRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_id())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<XzqFindZcDiff> empAoiRdd = nameRdd.filter(o -> StringUtils.isEmpty(o.getAoi_id())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiRdd cnt:{}", aoiRdd.count());
            logger.error("empAoiRdd cnt:{}", empAoiRdd.count());
            nameRdd.unpersist();

            JavaRDD<XzqFindZcDiff> aoiNameRdd = aoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).leftOuterJoin(cmsAoiTownRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o))).map(tp -> {
                XzqFindZcDiff o = tp._2._1;
                String result = "0";
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    CmsAoiTown cmsAoiTown = tp._2._2.get();
                    String name_d = cmsAoiTown.getName_d();
                    o.setName_d(name_d);
                    String name = o.getName();
                    if (StringUtils.isNotEmpty(name) && StringUtils.equals(name, name_d)) {
                        result = "1";
                    }
                }
                o.setResult(result);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiNameRdd cnt:{}", aoiNameRdd.count());
            aoiRdd.unpersist();

            JavaRDD<XzqFindZcDiff> zcNameRdd = empAoiRdd.mapToPair(o -> new Tuple2<>(o.getZno_code(), o)).leftOuterJoin(cmsAoiTownRdd.mapToPair(o -> new Tuple2<>(o.getZno_code(), o)).groupByKey()).map(tp -> {
                XzqFindZcDiff o = tp._2._1;
                String result = "0";
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    List<CmsAoiTown> list = Lists.newArrayList(tp._2._2.get());
                    String name = o.getName();
                    List<String> name_d_list = list.stream().filter(t -> StringUtils.isNotEmpty(t.getName_d())).map(CmsAoiTown::getName_d).distinct().collect(Collectors.toList());
                    o.setName_d(name_d_list.size() > 0 ? String.join("|", name_d_list) : "");

                    List<CmsAoiTown> filterNameList = list.stream().filter(t -> StringUtils.equals(t.getName_d(), name)).collect(Collectors.toList());
                    if (filterNameList.size() > 0) {
                        result = "1";
                    }
                }
                o.setResult(result);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("zcNameRdd cnt:{}", zcNameRdd.count());
            empAoiRdd.unpersist();

            JavaRDD<XzqFindZcDiff> resultRdd = aoiNameRdd.union(zcNameRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            aoiNameRdd.unpersist();
            zcNameRdd.unpersist();

            spark.sql(String.format("alter table dm_gis.xzq_find_zc_diff_data drop if EXISTS partition(inc_day='%s',city_code='%s')", date, city));
            DataUtil.saveInto(spark, sc, "dm_gis.xzq_find_zc_diff_data", XzqFindZcDiff.class, resultRdd, "inc_day", "city_code");
            resultRdd.unpersist();

        }
        cmsAoiTownRdd.unpersist();
        sc.stop();
        logger.error("end...");
    }

    public static String getName(String content) {
        String rs = "";
        String name3 = "";
        String name4 = "";
        if (StringUtils.isNotEmpty(content)) {
            JSONObject jsonObject = JSON.parseObject(content);
            if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                JSONObject result = jsonObject.getJSONObject("result");
                if (result != null) {
                    JSONObject data = result.getJSONObject("data");
                    if (data != null) {
                        JSONArray info = data.getJSONArray("info");
                        if (info != null && info.size() > 0) {
                            for (int i = 0; i < info.size(); i++) {
                                JSONObject jsonObject1 = info.getJSONObject(i);
                                Integer level = jsonObject1.getInteger("level");
                                String name = jsonObject1.getString("name");
                                if (level == 3) {
                                    name3 = name;
                                }
                                if (level == 4) {
                                    name4 = name;
                                }
                            }
                        }
                    }
                }
            }
        }

        if (StringUtils.isNotEmpty(name3)) {
            rs = name3;
        } else {
            rs = name4;
        }
        return rs;
    }

    public static String fixnulltoStr(String str) {
        if (str == null || str.trim().toLowerCase() == "null") {
            return "";
        }
        return str;
    }
}
