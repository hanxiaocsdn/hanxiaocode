package com.sf.gis.java.sds.utils;

/**
 * AES 128bit 加密解密工具类
 */

import cn.hutool.core.exceptions.UtilException;
import cn.hutool.core.util.ReflectUtil;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.security.Key;
import java.security.SecureRandom;
import java.util.List;
import java.util.Map;


public class AesEncryptUtil {
    private static Logger log = LoggerFactory.getLogger(AesEncryptUtil.class);


    public static String aesKey = "yHjivvAwo60Xl7w4PiTbm5N5Xw0F5lSw";

    public static final String KEY = "6iJTrFvXPe4o3aAec0P8zhxlzeKNLMuk";

    public static final String IV = "1F26262CF05EC8D6";

    // optional value AES/DES/DESede
    public static final String CIPHER_ALGORITHM = "AES";

    public static final String EMPTY_STRTRING = "";

    public static final String CHAUFFEUR_TEL = "chauffeurTel";
    public static final String MOVEINADDRESS = "moveInAddress";
    public static final String MOVEOUTADDRESS = "moveOutAddress";
    public static final String USERCODE = "userCode";
    public static final String ADDRESS = "address";


    static {
        String errorString = "Failed manually overriding key-length permissions.";
        int newMaxKeyLength;
        try {
            if ((newMaxKeyLength = Cipher.getMaxAllowedKeyLength("AES")) < 256) {
                Class c = Class.forName("javax.crypto.CryptoAllPermissionCollection");
                Constructor con = c.getDeclaredConstructor();
                con.setAccessible(true);
                Object allPermissionCollection = con.newInstance();
                Field f = c.getDeclaredField("all_allowed");
                f.setAccessible(true);
                f.setBoolean(allPermissionCollection, true);

                c = Class.forName("javax.crypto.CryptoPermissions");
                con = c.getDeclaredConstructor();
                con.setAccessible(true);
                Object allPermissions = con.newInstance();
                f = c.getDeclaredField("perms");
                f.setAccessible(true);
                ((Map) f.get(allPermissions)).put("*", allPermissionCollection);

                c = Class.forName("javax.crypto.JceSecurityManager");
                f = c.getDeclaredField("defaultPolicy");
                f.setAccessible(true);
                Field mf = Field.class.getDeclaredField("modifiers");
                mf.setAccessible(true);
                mf.setInt(f, f.getModifiers() & ~Modifier.FINAL);
                f.set(null, allPermissions);

                newMaxKeyLength = Cipher.getMaxAllowedKeyLength("AES");
            }
        } catch (Exception e) {
            throw new RuntimeException(errorString, e);
        }
        if (newMaxKeyLength < 256)
            throw new RuntimeException(errorString); // hack failed
    }


    public static Key getKey(String strKey) throws Exception {
        if (strKey == null) {
            strKey = "";
        }
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        SecureRandom secureRandom = SecureRandom.getInstance("SHA1PRNG");
        secureRandom.setSeed(strKey.getBytes());
        keyGenerator.init(256, secureRandom);
        return keyGenerator.generateKey();
    }

//    public static String encrypt(String data, String key) throws Exception {
//        if (StringUtils.isBlank(data)) {
//            return data;
//        }
//        SecureRandom sr = new SecureRandom();
//        Key secureKey = getKey(key);
//        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
//        cipher.init(Cipher.ENCRYPT_MODE, secureKey, sr);
//        byte[] bt = cipher.doFinal(data.getBytes());
//        String strS = new Base64().encodeAsString(bt);
//        return strS;
//    }


    public static String decrypt(String message, String key) throws Exception {
        if (StringUtils.isBlank(message)) {
            return message;
        }
        SecureRandom sr = new SecureRandom();
        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        Key secureKey = getKey(key);
        cipher.init(Cipher.DECRYPT_MODE, secureKey, sr);
        byte[] res = new Base64().decode(message);
        res = cipher.doFinal(res);
        return new String(res);
    }


    /**
     * 加密
     *
     * @param data
     * @return
     * @throws Exception
     */
//    public static String encrypt(String data, String key, String iv) {
//        if (StringUtils.isBlank(data)) {
//            return EMPTY_STRTRING;
//        }
//        String result = null;
//        try {
//            result = encrypt(data, key + aesKey);
//        } catch (Exception e) {
//            log.error("encrypt error:{}", e);
//        }
//
//        return result;
//    }

    /**
     * 解密
     *
     * @param data
     * @return
     * @throws Exception
     */
    public static String desEncrypt(String data, String key, String iv) {
        if (StringUtils.isBlank(data)) {
            return EMPTY_STRTRING;
        }
        String result = null;
        try {
            result = decrypt(data, key + aesKey);
        } catch (Exception e) {
            log.error("desEncrypt error:{}", e);
        }
        return result;
    }

    /**
     * 加密
     *
     * @param data
     * @return
     * @throws Exception
     */
//    public static String encrypt(String data) {
//        if (StringUtils.isBlank(data)) {
//            return EMPTY_STRTRING;
//        }
//        String result = null;
//        try {
//            result = encrypt(data, KEY + aesKey);
//        } catch (Exception e) {
//            log.error("encrypt error:{}", e);
//        }
//        return result;
//    }


    /**
     * 解密
     *
     * @param message
     * @return
     * @throws Exception
     */
    public static String desEncrypt(String message) {
        if (StringUtils.isBlank(message)) {
            return EMPTY_STRTRING;
        }
        String result = null;
        try {
            result = decrypt(message, KEY + aesKey);
            //如果解密前不为空，解密后为空，取解密前的。
            if (StringUtils.isNotEmpty(message) && StringUtils.isEmpty(result)) {
                return message;
            }
        } catch (Exception e) {
            log.error(">>>>>>解密字段:{}失败", message, e);
            result = message;
        }
        return result;
    }

    /**
     * 添加实体属性解密 by wwu @date 2020-01-13
     *
     * @param t
     * @param attrs
     * @param <T>
     * @return
     */
    public static <T> T desEncrypt(T t, String... attrs) {
        for (String attr : attrs) {
            try {
                Object value = ReflectUtil.getFieldValue(t, attr);
                if (value instanceof String) {
                    if (StringUtils.isNotEmpty((String) value)) {
                        String desEncryptStr = desEncrypt((String) value);
                        ReflectUtil.setFieldValue(t, attr, desEncryptStr);
                    }
                }
            } catch (UtilException ex) {
                log.error("字段[{}]解密失败", attr);
            }
        }
        return t;
    }

    /**
     * 批量实体属性解密 by wwu @date 2020-01-13
     *
     * @param list
     * @param attrs
     * @param <T>
     * @return
     */
    public static <T> List<T> desEncrypt(List<T> list, String... attrs) {
        list.forEach(data -> {
            desEncrypt(data, attrs);
        });
        return list;
    }

    public static void main(String[] args) {
        System.out.println(desEncrypt("+LLNikJOxKYCHayuk23x2XG/o5+WAnweR0V9/db+B9DG9d28ji+/OlVe470QfSjO663kLA4diXEspKkKb36yYyXz5PUOGOUg2HcIp2KTi2Y="));
    }
}
