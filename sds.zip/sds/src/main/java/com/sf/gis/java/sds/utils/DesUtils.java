package com.sf.gis.java.sds.utils;

import javax.crypto.*;
import javax.crypto.spec.DESedeKeySpec;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.KeySpec;
import java.util.Base64;

/**
 * Des加解密类
 */
public class DesUtils {
    private String key = "openmap007spas$#@!888888";
    private String strAlgorithm = "DESede";
    private Cipher cipherEncode = null;
    private Cipher cipherDecode = null;

    public static void main(String[] args) throws Exception{
        String param = new DesUtils().encrypt("中","utf-8");
        System.out.println(param);
    }
    public DesUtils() {
        // SecureRandom secureRandom = null;
        byte[] baKey = key.getBytes();
        KeySpec keySpec = null;
        SecretKeyFactory secretKeyFactory = null;
        SecretKey secretKey = null;
        try {
            //  secureRandom = new SecureRandom();
            //设置密钥
            baKey = key.getBytes();
            keySpec = new DESedeKeySpec(baKey);
            secretKeyFactory = SecretKeyFactory.getInstance(strAlgorithm);
            secretKey = secretKeyFactory.generateSecret(keySpec);
            cipherEncode = Cipher.getInstance(strAlgorithm);
            cipherEncode.init(Cipher.ENCRYPT_MODE, secretKey);
            cipherDecode = Cipher.getInstance(strAlgorithm);
            cipherDecode.init(Cipher.DECRYPT_MODE, secretKey);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            baKey = null;
            keySpec = null;
            secretKeyFactory = null;
            secretKey = null;
        }
    }

    /**
     * 进行DES加密
     *
     * @param str 输入字符串
     * @return String
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     */
    public String encrypt(String str, String strEncode) throws IllegalBlockSizeException, BadPaddingException {
        if (str == null || str.length() == 0) {
            return str;
        }
        String strResult = null;
        strResult = bytes2hex(cipherEncode.doFinal(str.getBytes(Charset.forName(strEncode) )));
        return strResult;
    }

    public byte[] encryptByte(byte[] arg) throws IllegalBlockSizeException, BadPaddingException {
        return cipherEncode.doFinal(arg);
    }

    public byte[] decryptByte(byte[] ba) throws IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        byte[] ra = cipherDecode.doFinal(ba);
        return ra;
    }

    /**
     * 进行DES加密
     *
     * @param sb
     * @return 无
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     */
    public void encrypt(StringBuilder sb) throws IllegalBlockSizeException, BadPaddingException {
        if (sb == null || sb.length() == 0) {
            return;
        }
        byte[] baInput = null;
        baInput = sb.toString().getBytes();
        sb.delete(0, sb.length());
        sb.append(bytes2hex(cipherEncode.doFinal(baInput)));
    }

    /**
     * 进行DES解密
     *
     * @param strData 输入数据
     * @return strEncode 字符编码
     * @throws BadPaddingException
     * @throws IllegalBlockSizeException
     * @throws UnsupportedEncodingException
     */
    public String decrypt(String strData, String strEncode) throws IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException {
        if (strData == null || strData.length() == 0) {
            return null;
        }
        String strResult = null;
        byte[] ba = hex2bytes(strData);
        ba = cipherDecode.doFinal(ba);
        strResult = new String(ba, strEncode);
        return strResult;
    }

    /**
     *
     * @param ba
     * @return
     */
    public String bytes2hex(byte[] ba) {
        StringBuilder sb = new StringBuilder();
        for (byte b : ba) {
            String str = Integer.toHexString(b & 0XFF);
            if (str.length() == 1) {
                sb.append(String.format("0%s", str));
            } else {
                sb.append(str);
            }
        }
        return sb.toString();
    }

    public byte[] hex2bytes(String str) {
        if (str == null || str.length() == 0 || str.length() % 2 == 1) {
            return null;
        }
        byte[] ba = null;
        try {
            ba = new byte[str.length() / 2];
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < str.length(); i += 2) {
                sb.delete(0, sb.length());
                sb.append("0X");
                sb.append(str.substring(i, i + 2));
                String strDecode = sb.toString();
                ba[i / 2] = (byte) Integer.decode(strDecode).intValue();
            }
            sb = null;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            str = null;
        }
        return ba;
    }


    /**利用MD5进行加密
     * @param str  待加密的字符串
     * @return  加密后的字符串
     * @throws NoSuchAlgorithmException  没有这种产生消息摘要的算法
     * @throws UnsupportedEncodingException
     */
    public static String encoderByMd5(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException{
        //确定计算方法
        MessageDigest md5 = MessageDigest.getInstance("MD5");
        Base64.Encoder encoder = Base64.getEncoder();
        //加密后的字符串
        String newstr = encoder.encodeToString(md5.digest(str.getBytes("UTF-8")));
        return newstr;
    }



}
