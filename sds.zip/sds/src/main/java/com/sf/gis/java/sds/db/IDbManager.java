package com.sf.gis.java.sds.db;

import java.sql.Connection;
import java.sql.SQLException;

public interface IDbManager {
    public Connection getConnection() throws SQLException;
    public void update(String sql);
}
