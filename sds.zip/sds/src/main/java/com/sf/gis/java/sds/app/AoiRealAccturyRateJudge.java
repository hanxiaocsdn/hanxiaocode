package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AoiAccuracyAddrTsAoiJoinTrajShouRet;
import com.sf.gis.java.sds.pojo.FaultFeedbackShouAoiSrc;
import com.sf.gis.java.sds.pojo.MonthlyAccount;
import com.sf.gis.java.sds.pojo.aoicompletion.TmDepartment;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.java.sds.service.AoiRealAccturyRateService;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 任务id：424133（aoi真实准确率_收件二期_收件报表工艺月结信息判对）
 * 业务：01424110（喻少丰）
 * 研发：01399581（匡仁衡）
 */
public class AoiRealAccturyRateJudge {
    private static Logger logger = LoggerFactory.getLogger(AoiRealAccturyRateJudge.class);
    private static String url = "http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&province=&cityName=&district=&city=%s&tel=&mobile=&company=&ak=87106f6380af4df0845a693eee58843c&opt=zh&callDispatch=1&isNotUnderCall=1&contacts=&customerAccount=%s";
    private static String radius = "http://gis-apis.int.sfcloud.local:1080/dept2/info/aoi/radius?x=%s&y=%s&radius=%s&ak=3eb300d2e06947f7945cd02530a32fd2";
    private static String gdUrl = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/v5/queryPoi?keywords=%s";
    private static String getAoiByxy = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?ak=87106f6380af4df0845a693eee58843c&x=%s&y=%s&opt=aoi&geom=0";
    // ak每分钟限速 / 并发数
    private static int limitMin = 20000 / 40;
    private static int limitMinGd = 1000 / 40;

    private static String account = "01399581";
    private static String taskId = "424133";
    private static String taskName = "aoi真实准确率_收件二期_收件报表工艺月结信息判对";


    public static void main(String[] args) {
        String date1 = args[0];
        String date2 = args[1];
        logger.error("date1:{},date2:{}", date1, date2);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AoiRealAccturyRateJudge");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        AoiRealAccturyRateService service = new AoiRealAccturyRateService();

        List<String> dateList = DateUtil.getDateList(date1, date2, "yyyyMMdd");
        for (String date : dateList) {
            logger.error("date:{}", date);
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> rdd = loadSourceData(spark, sc, date).repartition(1200).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdd cnt:{}", rdd.count());

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> wrongRdd = rdd.filter(o -> StringUtils.equals(o.getTag1(), "wrong") && StringUtils.isNotEmpty(o.getExtra()) && StringUtils.isNotEmpty(JSON.parseObject(o.getExtra()).getString("customeraccount"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> rightRdd = rdd.filter(o -> !(StringUtils.equals(o.getTag1(), "wrong") && StringUtils.isNotEmpty(o.getExtra()) && StringUtils.isNotEmpty(JSON.parseObject(o.getExtra()).getString("customeraccount")))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("wrongRdd cnt:{}", wrongRdd.count());
            logger.error("rightRdd cnt:{}", rightRdd.count());
            rdd.unpersist();

            String afterDay = DateUtil.getDaysBefore(date, -1);
            logger.error("afterDay:{}", afterDay);
            JavaRDD<MonthlyAccount> monthlyAccountRdd = loadMonthlyAccount(spark, sc, afterDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("monthlyAccountRdd cnt:{}", monthlyAccountRdd.count());

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> resultRdd = wrongRdd.mapToPair(o -> new Tuple2<>(JSON.parseObject(o.getExtra()).getString("citycode") + "_" + JSON.parseObject(o.getExtra()).getString("customeraccount"), o))
                    .leftOuterJoin(monthlyAccountRdd.mapToPair(o -> new Tuple2<>(o.getCity_code() + "_" + o.getAccount(), o)).groupByKey())
                    .map(tp -> {
                        AoiAccuracyAddrTsAoiJoinTrajShouRet o = tp._2._1;
                        String finalaoiid = o.getFinalaoiid();
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            List<MonthlyAccount> list = Lists.newArrayList(tp._2._2.get());
                            if (list.size() == 1) {
                                MonthlyAccount monthlyAccount = list.get(0);
                                String aoi = monthlyAccount.getAoi_id_atp();
                                if (StringUtils.isNotEmpty(finalaoiid) && StringUtils.isNotEmpty(aoi) && StringUtils.equals(finalaoiid, aoi)) {
                                    o.setTag1("correct");
                                    o.setTag2("bsp_correct");
                                }
                            }
                        }
                        return o;
                    }).union(rightRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            wrongRdd.unpersist();
            monthlyAccountRdd.unpersist();
            rightRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> trueRdd = resultRdd.filter(o -> judge(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> falseRdd = resultRdd.filter(o -> !judge(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("trueRdd cnt:{}", trueRdd.count());
            logger.error("falseRdd cnt:{}", falseRdd.count());
            resultRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> noEmpTag1Rdd = trueRdd.filter(o -> StringUtils.isNotEmpty(o.getTag1())).map(o -> {
                o.setTag1("correct");
                o.setTag2("zy_correct");
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> empTag1Rdd = trueRdd.filter(o -> StringUtils.isEmpty(o.getTag1())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("noEmpTag1Rdd cnt:{}, empTag1Rdd cnt:{}", noEmpTag1Rdd.count(), empTag1Rdd.count());
            trueRdd.unpersist();

            JavaRDD<TmDepartment> tmDepartmentRdd = loadTmDepartmentWageLevel(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("tmDepartmentRdd cnt:{}", tmDepartmentRdd.count());

//            String path = "/user/01399581/upload/yunying_demand/data/code_lng_lat.csv";
//            JavaRDD<String> lines = sc.textFile(path).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("lines cnt:{}", lines.count());
//            String header = lines.first();
//            logger.error("header:{}", header);
//            JavaRDD<CodeLngLat> codeLngLatRdd = lines.filter(o -> !o.equals(header)).map(line -> {
//                String[] split = line.split(",");
//                CodeLngLat o = new CodeLngLat();
//                if (split.length >= 3) {
//                    o.setCode(split[0]);
//                    o.setLng(split[1]);
//                    o.setLat(split[2]);
//                }
//                return o;
//            }).filter(o -> StringUtils.isNotEmpty(o.getCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//            logger.error("codeLngLatRdd cnt:{}", codeLngLatRdd.count());
//            lines.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> finalRdd = empTag1Rdd.mapToPair(o -> new Tuple2<>(o.getZonecode(), o))
                    .leftOuterJoin(tmDepartmentRdd.mapToPair(o -> new Tuple2<>(o.getDept_code(), o)).reduceByKey((o1, o2) -> o1))
                    .map(tp -> {
                        AoiAccuracyAddrTsAoiJoinTrajShouRet o = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            TmDepartment tmDepartment = tp._2._2.get();
                            String dept_aoi_id = tmDepartment.getDept_aoi_id();
                            if (StringUtils.isNotEmpty(dept_aoi_id)) {
                                o.setTag1("correct");
                                o.setTag2("zy_correct");
                                String extra = o.getExtra();
                                JSONObject jsonObject2 = JSON.parseObject(extra);
                                jsonObject2.put("zc_aoi", dept_aoi_id);
                                o.setExtra(jsonObject2.toJSONString());
                            }
                        }
                        return o;
                    }).union(noEmpTag1Rdd).union(falseRdd).map(o -> {
                        String extra = o.getExtra();
                        if (StringUtils.isNotEmpty(extra)) {
                            JSONObject jsonObject = JSON.parseObject(extra);
                            if (jsonObject != null) {
                                String aoisrc = jsonObject.getString("aoisrc");
                                o.setAoisrc(aoisrc);
                                String phone = jsonObject.getString("phone");
                                String mobile = jsonObject.getString("mobile");
                                if (StringUtils.isNotEmpty(phone)) {
                                    o.setMobile(phone);
                                } else {
                                    o.setMobile(mobile);
                                }
                            }
                        }
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalRdd cnt:{}", finalRdd.count());
            empTag1Rdd.unpersist();
            noEmpTag1Rdd.unpersist();
            falseRdd.unpersist();
            tmDepartmentRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> eqWrongRdd = finalRdd.filter(o -> StringUtils.equals(o.getTag1(), "wrong")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> noEqWrongRdd = finalRdd.filter(o -> !StringUtils.equals(o.getTag1(), "wrong")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("eqWrongRdd cnt:{}", eqWrongRdd.count());
            logger.error("noEqWrongRdd cnt:{}", noEqWrongRdd.count());
            finalRdd.unpersist();

            String cms_aoi_sch = "select aoi_id,aoi_code from dm_gis.cms_aoi_sch";
            logger.error("cms_aoi_sch sql: {}", cms_aoi_sch);
            JavaPairRDD<String, CmsAoiSch> cmsAoiRdd = DataUtil.loadData(spark, sc, cms_aoi_sch, CmsAoiSch.class).mapToPair(o -> new Tuple2<>(o.getAoi_code(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cmsAoiRdd cnt:{}", cmsAoiRdd.count());

            JavaRDD<FaultFeedbackShouAoiSrc> feedbackShouAoiSrcRdd = loadFaultFeedback(spark, sc, afterDay).filter(o -> StringUtils.isNotEmpty(o.getFinalaoicode())).mapToPair(o -> new Tuple2<>(o.getFinalaoicode(), o)).leftOuterJoin(cmsAoiRdd).map(tp -> {
                FaultFeedbackShouAoiSrc o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    CmsAoiSch cmsAoiSch = tp._2._2.get();
                    o.setFinalaoicode(cmsAoiSch.getAoi_id());
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("feedbackShouAoiSrcRdd cnt:{}", feedbackShouAoiSrcRdd.count());
            cmsAoiRdd.unpersist();

            JavaPairRDD<String, FaultFeedbackShouAoiSrc> companyRdd = feedbackShouAoiSrcRdd.filter(o -> StringUtils.equals(o.getAoisrc(), "dispatch-normcompany") || StringUtils.equals(o.getAoisrc(), "company") || StringUtils.equals(o.getAoisrc(), "normcompany"))
                    .mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getReq_comp_name(), o))
                    .groupByKey()
                    .map(tp -> {
                        List<FaultFeedbackShouAoiSrc> list = Lists.newArrayList(tp._2);
                        return list.stream().sorted((o1, o2) -> o2.getCreate_time().compareTo(o1.getCreate_time())).collect(Collectors.toList()).get(0);
                    }).mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getReq_comp_name(), o))
                    .persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaPairRDD<String, Iterable<FaultFeedbackShouAoiSrc>> mobileRdd = feedbackShouAoiSrcRdd.filter(o -> StringUtils.equals(o.getAoisrc(), "tel_His") || (StringUtils.isNotEmpty(o.getAoisrc()) && o.getAoisrc().contains("phone")))
                    .mapToPair(o -> new Tuple2<>(o.getMobile() + "_" + o.getReq_address(), o))
                    .groupByKey()
                    .map(tp -> {
                        List<FaultFeedbackShouAoiSrc> list = Lists.newArrayList(tp._2);
                        return list.stream().sorted((o1, o2) -> o2.getCreate_time().compareTo(o1.getCreate_time())).collect(Collectors.toList()).get(0);
                    }).mapToPair(o -> new Tuple2<>(o.getMobile(), o))
                    .groupByKey()
                    .persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaPairRDD<String, FaultFeedbackShouAoiSrc> addrRdd = feedbackShouAoiSrcRdd.filter(o -> StringUtils.equals(o.getAoisrc(), "dispatch-normhp") || StringUtils.equals(o.getAoisrc(), "normhp"))
                    .mapToPair(o -> new Tuple2<>(o.getReq_address(), o))
                    .groupByKey()
                    .map(tp -> {
                        List<FaultFeedbackShouAoiSrc> list = Lists.newArrayList(tp._2);
                        return list.stream().sorted((o1, o2) -> o2.getCreate_time().compareTo(o1.getCreate_time())).collect(Collectors.toList()).get(0);
                    }).mapToPair(o -> new Tuple2<>(o.getReq_address(), o))
                    .persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("companyRdd cnt:{}", companyRdd.count());
            logger.error("mobileRdd cnt:{}", mobileRdd.count());
            logger.error("addrRdd cnt:{}", addrRdd.count());
            feedbackShouAoiSrcRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> processRdd = eqWrongRdd.mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getReq_comp_name(), o))
                    .leftOuterJoin(companyRdd)
                    .map(tp -> {
                        AoiAccuracyAddrTsAoiJoinTrajShouRet o = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            FaultFeedbackShouAoiSrc faultFeedbackShouAoiSrc = tp._2._2.get();
                            if (StringUtils.isNotEmpty(o.getFinalaoiid()) && StringUtils.equals(o.getFinalaoiid(), faultFeedbackShouAoiSrc.getFinalaoicode())) {
                                o.setTag1("correct");
                                o.setTag2("com_ph_correct");
                            }
                        }
                        return o;
                    }).mapToPair(o -> new Tuple2<>(o.getMobile(), o))
                    .leftOuterJoin(mobileRdd)
                    .map(tp -> {
                        AoiAccuracyAddrTsAoiJoinTrajShouRet o = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            List<FaultFeedbackShouAoiSrc> list = Lists.newArrayList(tp._2._2.get());
                            for (FaultFeedbackShouAoiSrc faultFeedbackShouAoiSrc : list) {
                                String aoisrc = o.getAoisrc();
                                if (((StringUtils.isNotEmpty(aoisrc) && aoisrc.contains("phone")) || StringUtils.equals(aoisrc, "tel_His")) && StringUtils.isNotEmpty(o.getFinalaoiid()) && StringUtils.equals(o.getFinalaoiid(), faultFeedbackShouAoiSrc.getFinalaoicode())) {
                                    o.setTag1("correct");
                                    o.setTag2("com_ph_correct");
                                }
                            }
                        }
                        return o;
                    }).mapToPair(o -> new Tuple2<>(o.getReq_address(), o))
                    .leftOuterJoin(addrRdd)
                    .map(tp -> {
                        AoiAccuracyAddrTsAoiJoinTrajShouRet o = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            FaultFeedbackShouAoiSrc faultFeedbackShouAoiSrc = tp._2._2.get();
                            if (StringUtils.isNotEmpty(o.getFinalaoiid()) && StringUtils.equals(o.getFinalaoiid(), faultFeedbackShouAoiSrc.getFinalaoicode())) {
                                o.setTag1("correct");
                                o.setTag2("com_ph_correct");
                            }
                        }
                        return o;
                    }).union(noEqWrongRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("processRdd cnt:{}", processRdd.count());
            eqWrongRdd.unpersist();
            companyRdd.unpersist();
            mobileRdd.unpersist();
            addrRdd.unpersist();
            noEqWrongRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> eqRdd = processRdd.filter(o -> StringUtils.equals(o.getTag1(), "wrong") || StringUtils.equals(o.getTag1(), "correct")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> noEqRdd = processRdd.filter(o -> !(StringUtils.equals(o.getTag1(), "wrong") || StringUtils.equals(o.getTag1(), "correct"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("eqRdd cnt:{}, noEqRdd cnt:{}", eqRdd.count(), noEqRdd.count());
            processRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> lastRdd = eqRdd.mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getFinalaoiid(), o))
                    .groupByKey()
                    .flatMap(tp -> {
                        List<AoiAccuracyAddrTsAoiJoinTrajShouRet> list = Lists.newArrayList(tp._2);
                        long correctCnt = list.stream().filter(o -> StringUtils.equals(o.getTag1(), "correct")).count();
                        long wrongCnt = list.stream().filter(o -> StringUtils.equals(o.getTag1(), "wrong")).count();
                        if (correctCnt >= 1 && wrongCnt >= 1) {
                            list = list.stream().peek(o -> {
                                if (StringUtils.equals(o.getTag1(), "wrong")) {
                                    o.setTag1("correct");
                                    o.setTag2("addr_correct");
                                }
                            }).collect(Collectors.toList());
                        }
                        return list.iterator();
                    }).union(noEqRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("lastRdd cnt:{}", lastRdd.count());
            eqRdd.unpersist();
            noEqRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> chke_curRdd = lastRdd.map(o -> {
                String aoisrc = o.getAoisrc();
                if (StringUtils.equals(aoisrc, "chke_cur")) {
                    o.setTag1("no");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("chke_curRdd cnt:{}", chke_curRdd.count());
            lastRdd.unpersist();

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> wrongOrNoTagRdd = chke_curRdd.filter(o -> StringUtils.equals(o.getTag1(), "wrong") || StringUtils.equals(o.getTag1(), "no")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> otherTagRdd = chke_curRdd.filter(o -> !(StringUtils.equals(o.getTag1(), "wrong") || StringUtils.equals(o.getTag1(), "no"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("wrongOrNoTagRdd cnt:{}", wrongOrNoTagRdd.count());
            logger.error("otherTagRdd cnt:{}", otherTagRdd.count());
            chke_curRdd.unpersist();

            String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", radius, "3eb300d2e06947f7945cd02530a32fd2", wrongOrNoTagRdd.count(), 40);
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> nrAoiRdd = wrongOrNoTagRdd.mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                ArrayList<AoiAccuracyAddrTsAoiJoinTrajShouRet> list = new ArrayList<>();
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMin) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    AoiAccuracyAddrTsAoiJoinTrajShouRet o = itr.next();
                    String x = o.getPick_lgt();
                    String y = o.getPick_lat();
                    if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                        String req10 = String.format(radius, x, y, 10);
                        String content10 = HttpInvokeUtil.sendGet(req10);
                        if (StringUtils.isNotEmpty(content10) && JSON.parseObject(content10) != null && JSON.parseObject(content10).getInteger("status") == 0) {
                            o = processJSon(o, content10);
                        } else {
                            String req30 = String.format(radius, x, y, 30);
                            String content30 = HttpInvokeUtil.sendGet(req30);
                            if (StringUtils.isNotEmpty(content30)) {
                                o = processJSon(o, content30);
                            }
                        }
                    }
                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("nrAoiRdd cnt:{}", nrAoiRdd.count());
            wrongOrNoTagRdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id1);

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> nrAoiEqRdd = nrAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getFinalaoiid()) && StringUtils.equals(o.getFinalaoiid(), o.getNr_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> nrAoiNoEqRdd = nrAoiRdd.filter(o -> !(StringUtils.isNotEmpty(o.getFinalaoiid()) && StringUtils.equals(o.getFinalaoiid(), o.getNr_aoiid()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("nrAoiEqRdd cnt:{}", nrAoiEqRdd.count());
            logger.error("nrAoiNoEqRdd cnt:{}", nrAoiNoEqRdd.count());
            nrAoiRdd.unpersist();

            String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gdUrl, "860aafa74c7846a3b4519f552851a5aa", nrAoiEqRdd.count(), 40);
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> gdXyRdd = nrAoiEqRdd.mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<AoiAccuracyAddrTsAoiJoinTrajShouRet> list = new ArrayList<>();
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMinGd) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMinGd, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    AoiAccuracyAddrTsAoiJoinTrajShouRet o = itr.next();
                    String req_address = o.getReq_address();
                    if (StringUtils.isNotEmpty(req_address)) {
                        String req = String.format(gdUrl, URLEncoder.encode(req_address, "UTF-8"));
                        String content = getJsonByGet(req);
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = null;
                            try {
                                jsonObject = JSON.parseObject(content);
                                if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                    JSONObject result = jsonObject.getJSONObject("result");
                                    if (result != null) {
                                        JSONArray pois = result.getJSONArray("pois");
                                        if (pois != null && pois.size() > 0) {
                                            for (int i = 0; i < pois.size(); i++) {
                                                JSONObject jsonObject1 = pois.getJSONObject(i);
                                                if (jsonObject1 != null) {
                                                    String location = jsonObject1.getString("location");
                                                    if (StringUtils.isNotEmpty(location)) {
                                                        String[] split = location.split(",");
                                                        if (split.length >= 2) {
                                                            o.setGd_x(split[0]);
                                                            o.setGd_y(split[1]);
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            } catch (Exception e) {
//                                e.printStackTrace();
                            }
                        }
                    }
                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("gdXyRdd cnt:{}", gdXyRdd.count());
            nrAoiEqRdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id2);

            String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getAoiByxy, "87106f6380af4df0845a693eee58843c", gdXyRdd.count(), 40);
            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> gdAoiRdd = gdXyRdd.mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<AoiAccuracyAddrTsAoiJoinTrajShouRet> list = new ArrayList<>();
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMin) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    AoiAccuracyAddrTsAoiJoinTrajShouRet o = itr.next();
                    String gd_x = o.getGd_x();
                    String gd_y = o.getGd_y();
                    if (StringUtils.isNotEmpty(gd_x) && StringUtils.isNotEmpty(gd_y)) {
                        String req = String.format(getAoiByxy, gd_x, gd_y);
                        String content = HttpInvokeUtil.sendGet(req);

                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = JSON.parseObject(content);
                            if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                JSONObject result = jsonObject.getJSONObject("result");
                                if (result != null) {
                                    JSONArray aoi_data = result.getJSONArray("aoi_data");
                                    if (aoi_data != null && aoi_data.size() > 0) {
                                        JSONObject jsonObject1 = aoi_data.getJSONObject(0);
                                        if (jsonObject1 != null) {
                                            String aoi_id = jsonObject1.getString("aoi_id");
                                            o.setGd_ps_aoiid(aoi_id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("gdAoiRdd cnt:{}", gdAoiRdd.count());
            gdXyRdd.unpersist();
            BdpTaskRecordUtil.endNetworkInterface(account, id3);

            JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> tagGdRdd = gdAoiRdd.map(o -> {
                String finalaoiid = o.getFinalaoiid();
                String gd_ps_aoiid = o.getGd_ps_aoiid();
                if (StringUtils.equals(finalaoiid, gd_ps_aoiid)) {
                    o.setTag1("correct");
                    o.setTag2("is_gd");
                }
                return o;
            }).union(otherTagRdd).union(nrAoiNoEqRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("tagGdRdd cnt:{}", tagGdRdd.count());
            gdAoiRdd.unpersist();
            otherTagRdd.unpersist();
            nrAoiNoEqRdd.unpersist();


            spark.sql(String.format("alter table dm_gis.aoi_accuracy_54_aoiname_ret_bsp drop if EXISTS partition(inc_day='%s')", date));
            service.saveData(spark, tagGdRdd, date, "dm_gis.aoi_accuracy_54_aoiname_ret_bsp");
            tagGdRdd.unpersist();

        }
        logger.error("end...");
    }

    public static String getJsonByGet(String url) {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        String stringEntity = "";
        try {
            HttpGet httpGet = new HttpGet(url);
            httpGet.addHeader("ak", "860aafa74c7846a3b4519f552851a5aa");
            CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
            if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                HttpEntity httpEntity = httpResponse.getEntity();
                try {
                    stringEntity = EntityUtils.toString(httpEntity, "UTF-8");
                } catch (Exception e) {
                    logger.error(">>>获取stringEntity异常：" + e);
                }
            }
            httpResponse.close();
            httpClient.close();
        } catch (Exception e) {
            logger.error(">>>获取httpResponse异常：" + e);
        }
        return stringEntity;
    }

    public static AoiAccuracyAddrTsAoiJoinTrajShouRet processJSon(AoiAccuracyAddrTsAoiJoinTrajShouRet o, String content) {
        JSONObject jsonObject = JSON.parseObject(content);
        if (jsonObject != null && jsonObject.getInteger("status") == 0) {
            JSONObject result = jsonObject.getJSONObject("result");
            if (result != null) {
                JSONObject data = result.getJSONObject("data");
                if (data != null) {
                    JSONArray aois = data.getJSONArray("aois");
                    if (aois != null && aois.size() > 0) {
                        for (int i = 0; i < aois.size(); i++) {
                            JSONObject jsonObject1 = aois.getJSONObject(i);
                            if (jsonObject1 != null) {
                                String aoi_id = jsonObject1.getString("aoi_id");
                                if (StringUtils.isNotEmpty(aoi_id) && StringUtils.equals(aoi_id, o.getFinalaoiid())) {
                                    o.setNr_aoiid(aoi_id);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        return o;
    }

    public static boolean judge(AoiAccuracyAddrTsAoiJoinTrajShouRet o) {
        String req_address = o.getReq_address();
        String extra = o.getExtra();
        if (StringUtils.isNotEmpty(req_address) && req_address.endsWith("顺丰就近营业点") && StringUtils.isNotEmpty(extra)) {
            JSONObject extraJson = JSON.parseObject(extra);
            if (extraJson != null) {
                String customerAccount = extraJson.getString("customeraccount");
                String[] list = {"8712267083", "7911510046", "8511384469", "7312036724", "0210443907", "0225997080", "0276726640", "4513517045", "0235427805",
                        "3113707196", "5313527110", "7604935604", "7561233283", "7590535147", "7502203840", "6620338001", "6680444475", "0244501241", "5717132670", "9911269422"};
                return StringUtils.isNotEmpty(customerAccount) && Arrays.asList(list).contains(customerAccount);
            }
        }
        return false;
    }

    public static JavaRDD<AoiAccuracyAddrTsAoiJoinTrajShouRet> loadSourceData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.aoi_accuracy_54_aoiname_ret where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiAccuracyAddrTsAoiJoinTrajShouRet.class);
    }

    public static JavaRDD<MonthlyAccount> loadMonthlyAccount(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select city_code,account,aoi_id_atp from dm_gis.monthly_account where inc_day = '%s' and del_flag = 0 and is_finish = 'Y'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, MonthlyAccount.class);
    }

    public static JavaRDD<FaultFeedbackShouAoiSrc> loadFaultFeedback(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.fault_feedback_shou_aoisrc where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, FaultFeedbackShouAoiSrc.class);
    }

    public static JavaRDD<TmDepartment> loadTmDepartmentWageLevel(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select dept_code,pick_wage_aoi_id,send_wage_aoi_id,dept_aoi_id from dm_gis.tm_department_wage_level where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据dm_gis.tm_department_wage_level
        return DataUtil.loadData(spark, sc, sql, TmDepartment.class);
    }
}
