package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.DistanceAndConsumeTimeChangeController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppDistanceAndConsumeTimeChange {
    private static Logger logger = LoggerFactory.getLogger(AppDistanceAndConsumeTimeChange.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        logger.error("run start");
        new DistanceAndConsumeTimeChangeController().start(startDate, endDate);
        logger.error("run end");
    }
}
