package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.DbPressSb;
import com.sf.gis.java.sds.utils.UrlUtil;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.net.URLEncoder;

public class DbAutoPressSbController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(DbAutoPressSbController.class);
    private static String depponUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/deppon?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&opt=%s&show=1";
    private static String getZcAndTcUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/geom/query?ak=3a191e7427e8470c86271a069411c66b&x=%s&y=%s&showserver=true";
    private static String atdispatchUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=dec044d089524419b371bc94555c539d&opt=zh&company=&tel=&mobile=&showserver=true";
    private static String queryUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/cache/query?ak=3a191e7427e8470c86271a069411c66b&type=3&aoi=%s";
    private static String textPressSbUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/api/deppon/his/opt?ak=3a191e7427e8470c86271a069411c66b&citycode=%s&address=%s&type=%s&zc=%s&tc=%s";
    private static String pressSbValidUrl = "http://gis-int2.int.sfdc.com.cn:1080/eds/opt/effect?ak=3a191e7427e8470c86271a069411c66b&city=%s&showserver=true";

    private static String taskId = "154";
    private static String taskName = "德邦错分自动压审补工艺";
    private static String account = "01399581";

    public void start(String date) {
        //初始化spark
        SparkSession spark = Spark.getSparkSession("DbAutoPressSbController", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        logger.error("获取德邦错分数据");
        JavaRDD<DbPressSb> dbSbAutoClearRdd = loadData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("dbSbAutoClearRdd cnt:{}", dbSbAutoClearRdd.count());

        logger.error("调取德邦分单，获取最新识别结果zc_new");
        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", depponUrl, "3a191e7427e8470c86271a069411c66b", dbSbAutoClearRdd.count(), 1);
        JavaRDD<DbPressSb> zcNewRdd = depponFd(dbSbAutoClearRdd);
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        logger.error("过滤出zc未修改的");
        JavaRDD<DbPressSb> noModifyRdd = zcNewRdd.filter(o -> !StringUtils.equals(o.getZc_new(), o.getDepponZc())).map(o -> {
            o.setIs_modify("false");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DbPressSb> modifyRdd = zcNewRdd.filter(o -> StringUtils.equals(o.getZc_new(), o.getDepponZc())).map(o -> {
            o.setIs_modify("true");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noModifyRdd cnt:{}", noModifyRdd.count());
        logger.error("modifyRdd cnt:{}", modifyRdd.count());
        zcNewRdd.unpersist();

        logger.error("v1.4新增逻辑,增加频次判断");
        JavaRDD<DbPressSb> fraRdd = addIsFra(noModifyRdd);
        JavaRDD<DbPressSb> fraTrueRdd = fraRdd.filter(o -> "true".equals(o.getIs_fra())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DbPressSb> fraFalseRdd = fraRdd.filter(o -> "false".equals(o.getIs_fra())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("fraTrueRdd cnt:{}, fraFalseRdd cnt:{}", fraTrueRdd.count(), fraFalseRdd.count());
        fraRdd.unpersist();

        logger.error("根据mapa及ts坐标x,y分别获取德邦mapa_zc,mapa_tc;ts_zc,ts_tc;");
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getZcAndTcUrl, "3a191e7427e8470c86271a069411c66b", noModifyRdd.count(), 5);
        JavaRDD<DbPressSb> mapaZcTcRdd = fraFalseRdd.map(o -> getZcAndTc(o, "mapa")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("mapaZcTcRdd cnt:{}", mapaZcTcRdd.count());
        fraFalseRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getZcAndTcUrl, "3a191e7427e8470c86271a069411c66b", mapaZcTcRdd.count(), 5);
        JavaRDD<DbPressSb> tsZcTcRdd = mapaZcTcRdd.map(o -> getZcAndTc(o, "ts")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tsZcTcRdd cnt:{}", tsZcTcRdd.count());
        mapaZcTcRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        logger.error("ts_precision=mapa_precision=2.0&ts_zc=mapa_zc=depponZc");
        JavaRDD<DbPressSb> yesRdd = tsZcTcRdd.filter(o -> StringUtils.equals(o.getTs_zc(), o.getDepponZc()) || StringUtils.equals(o.getMapa_zc(), o.getDepponZc())).map(o -> {
            o.setGj_zc_equal("true");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DbPressSb> noRdd = tsZcTcRdd.filter(o -> !(StringUtils.equals(o.getTs_zc(), o.getDepponZc()) || StringUtils.equals(o.getMapa_zc(), o.getDepponZc()))).map(o -> {
            o.setGj_zc_equal("false");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("yesRdd cnt:{}", yesRdd.count());
        logger.error("noRdd cnt:{}", noRdd.count());
        tsZcTcRdd.unpersist();

        logger.error("若mapa_tc=ts_tc,将ts_tc赋值给tc_chkn");
        JavaRDD<DbPressSb> mapaTcEqTsTcRdd = yesRdd.map(o -> {
            String tc = "";
            if (StringUtils.equals(o.getMapa_tc(), o.getTs_tc())) {
                tc = o.getTs_tc();
            }
            o.setTc_chkn(tc);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("mapaTcEqTsTcRdd cnt:{}", mapaTcEqTsTcRdd.count());
        yesRdd.unpersist();

        logger.error("调服务opt=zc获取ZC模型识别ZC");
        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", depponUrl, "3a191e7427e8470c86271a069411c66b", noRdd.count(), 5);
        JavaRDD<DbPressSb> modelZcProRdd = getModelZcPro(noRdd);
        BdpTaskRecordUtil.endNetworkInterface(account, id4);

        JavaRDD<DbPressSb> tcEqTsTcRdd = modelZcProRdd.filter(o -> StringUtils.equals(o.getModel_zc_pro(), o.getDepponZc())).map(o -> {
            o.setMod_zc_equal("true");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tcEqTsTcRdd cnt:{}", tcEqTsTcRdd.count());

        JavaRDD<DbPressSb> rdsRdd = modelZcProRdd.filter(o -> !StringUtils.equals(o.getModel_zc_pro(), o.getDepponZc())).map(o -> {
            o.setMod_zc_equal("false");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsRdd cnt:{}", rdsRdd.count());
        modelZcProRdd.unpersist();

        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", atdispatchUrl, "dec044d089524419b371bc94555c539d", rdsRdd.count(), 5);
        String id6 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", queryUrl, "3a191e7427e8470c86271a069411c66b", rdsRdd.count(), 5);
        JavaRDD<DbPressSb> rdsAoiRdd = getRdsAoi(rdsRdd);
        JavaRDD<DbPressSb> rdsZcContainsRdd = rdsAoiRdd.filter(o -> StringUtils.equals(o.getRds_sign_zc_equal(), "true")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DbPressSb> rdsZcNoContainsRdd = rdsAoiRdd.filter(o -> !StringUtils.equals(o.getRds_sign_zc_equal(), "true")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsZcContainsRdd cnt:{}", rdsZcContainsRdd.count());
        logger.error("rdsZcNoContainsRdd cnt:{}", rdsZcNoContainsRdd.count());
        rdsAoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id5);
        BdpTaskRecordUtil.endNetworkInterface(account, id6);

        JavaRDD<DbPressSb> unionRdd = mapaTcEqTsTcRdd.union(tcEqTsTcRdd).union(rdsZcContainsRdd).union(fraTrueRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unionRdd cnt:{}", unionRdd.count());
        mapaTcEqTsTcRdd.unpersist();
        tcEqTsTcRdd.unpersist();
        rdsZcContainsRdd.unpersist();
        fraTrueRdd.unpersist();

        logger.error("压入德邦审补库");
        String id7 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", textPressSbUrl, "3a191e7427e8470c86271a069411c66b", unionRdd.count(), 5);
        String id8 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", pressSbValidUrl, "3a191e7427e8470c86271a069411c66b", unionRdd.count(), 5);
        JavaRDD<DbPressSb> sbRdd = pressSb(unionRdd);
        BdpTaskRecordUtil.endNetworkInterface(account, id7);
        BdpTaskRecordUtil.endNetworkInterface(account, id8);

        logger.error("结果数据存表");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_deppon_auto_press_sb_di", DbPressSb.class, sbRdd.union(modifyRdd).union(rdsZcNoContainsRdd), "inc_day");
        sbRdd.unpersist();
        modifyRdd.unpersist();
        rdsZcNoContainsRdd.unpersist();

        spark.stop();
    }

    public JavaRDD<DbPressSb> addIsFra(JavaRDD<DbPressSb> noModifyRdd) {
        JavaRDD<DbPressSb> fraRdd = noModifyRdd.map(o -> {
            String is_fra = "";
            if (judgeIsFra(o)) {
                is_fra = "true";
            } else {
                is_fra = "false";
            }
            o.setIs_fra(is_fra);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("fraRdd cnt:{}", fraRdd.count());
        noModifyRdd.unpersist();
        return fraRdd;
    }

    public boolean judgeIsFra(DbPressSb o) {
        int addr_fra_num = StringUtils.isNotEmpty(o.getAddr_fra_num()) ? Integer.parseInt(o.getAddr_fra_num()) : 0;
        String addr_sign_zc_diff = o.getAddr_sign_zc_diff();
        String addr_reg_zc_diff = o.getAddr_reg_zc_diff();
        return addr_fra_num > 1 && "1".equals(addr_sign_zc_diff) && "1".equals(addr_reg_zc_diff);
    }

    public JavaRDD<DbPressSb> pressSb(JavaRDD<DbPressSb> unionRdd) {
        JavaRDD<DbPressSb> sbRdd = unionRdd.map(o -> {
            o.setPress_chkn("true");
            String citycode = o.getCity();
            String address = o.getAddress();
            String type = "1";
            String tc = o.getTc_chkn();
            String zc = o.getDepponZc();
            String content1 = textPressSb(textPressSbUrl, citycode, address, type, zc, tc);
            o.setPress_msg(content1);
            String content2 = cityValidSb(pressSbValidUrl, citycode);
            o.setEffect_msg(content2);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sbRdd cnt:{}", sbRdd.count());
        unionRdd.unpersist();
        return sbRdd;
    }

    public JavaRDD<DbPressSb> getRdsAoi(JavaRDD<DbPressSb> rdsRdd) {
        JavaRDD<DbPressSb> rdsAoiRdd = rdsRdd.map(o -> {
            String dataSrc = o.getDataSrc();
            if ("MODEL_ZC".equals(dataSrc)) {
                String address = o.getAddress();
                String city = o.getCity();
                if (StringUtils.isNotEmpty(address)) {
                    String req = String.format(atdispatchUrl, URLEncoder.encode(address, "UTF-8"), city);
                    String content = HttpInvokeUtil.sendGet(req);
                    String aoiid = "";
                    try {
                        aoiid = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    o.setRds_aoiid(aoiid);
                    if (StringUtils.isNotEmpty(aoiid)) {
                        String req1 = String.format(queryUrl, aoiid);
                        String content1 = HttpInvokeUtil.sendGet(req1);
                        String rds_zc = "";
                        try {
                            JSONArray deppon = JSON.parseObject(content1).getJSONObject("result").getJSONArray("deppon");
                            for (int i = 0; i < deppon.size(); i++) {
                                JSONObject jsonObject = deppon.getJSONObject(i);
                                String dept = jsonObject.getString("dept");
                                if (i == deppon.size() - 1) {
                                    rds_zc = rds_zc.concat(dept);
                                } else {
                                    rds_zc = rds_zc.concat(dept).concat("|");
                                }
                            }

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        o.setRds_zc(rds_zc);
                        String rds_sign_zc_equal = "";
                        if (StringUtils.isNotEmpty(rds_zc) && StringUtils.isNotEmpty(o.getDepponZc()) && rds_zc.contains(o.getDepponZc())) {
                            rds_sign_zc_equal = "true";
                        } else {
                            rds_sign_zc_equal = "false";
                        }
                        o.setRds_sign_zc_equal(rds_sign_zc_equal);
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdsAoiRdd cnt:{}", rdsAoiRdd.count());
        rdsRdd.unpersist();
        return rdsAoiRdd;
    }

    public JavaRDD<DbPressSb> getModelZcPro(JavaRDD<DbPressSb> noRdd) {
        JavaRDD<DbPressSb> modelZcProRdd = noRdd.map(o -> {
            String address = o.getAddress();
            String citycode = o.getCitycode();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(depponUrl, citycode, URLEncoder.encode(address, "UTF-8"), "zc");
                String content = HttpInvokeUtil.sendGet(req);
                String zc = "";
                try {
                    zc = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("code").getJSONObject(0).getString("zc");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                o.setModel_zc_pro(zc);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("modelZcProRdd cnt:{}", modelZcProRdd.count());
        noRdd.unpersist();
        return modelZcProRdd;
    }

    public JavaRDD<DbPressSb> depponFd(JavaRDD<DbPressSb> dbSbAutoClearRdd) {
        JavaRDD<DbPressSb> zcNewRdd = dbSbAutoClearRdd.repartition(1).map(o -> {
            String address = o.getAddress();
            String citycode = o.getCitycode();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(depponUrl, citycode, URLEncoder.encode(address, "UTF-8"), "zh");
                String content = HttpInvokeUtil.sendGet(req);

                String source_new = "";
                String keyword_new = "";
                String zc_new = "";
                String tc_new = "";
                String match_new = "";
                String adcode_new = "";
                String msg_new = "";

                try {
                    keyword_new = JSON.parseObject(content).getJSONObject("result").getString("keyword");
                    msg_new = JSON.parseObject(content).getJSONObject("result").getString("msg");
                } catch (Exception e) {
                }
                try {
                    source_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("source");
                    match_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("match");
                    adcode_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("adcode");
                } catch (Exception e) {
                }
                try {
                    zc_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("code").getJSONObject(0).getString("zc");
                    tc_new = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getJSONArray("code").getJSONObject(0).getString("tc");
                } catch (Exception e) {
                }

                o.setKeyword_new(keyword_new);
                o.setMsg_new(msg_new);
                o.setSource_new(source_new);
                o.setMatch_new(match_new);
                o.setAdcode_new(adcode_new);
                o.setZc_new(zc_new);
                o.setTc_new(tc_new);

            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zcNewRdd cnt:{}", zcNewRdd.count());
        dbSbAutoClearRdd.unpersist();
        return zcNewRdd;
    }

    public String cityValidSb(String urlPattern, String citycode) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, citycode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String textPressSb(String urlPattern, String citycode, String address, String type, String zc, String tc) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, citycode, URLEncoder.encode(address, "UTF-8"), type, zc, tc);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String getRdsZc(String urlPattern, String aoiid) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, aoiid);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }


    public String queryAddrDetail(String urlPattern, String address, String cityCode) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }


    public DbPressSb getZcAndTc(DbPressSb o, String tag) {
        String content = "";
        String x = "";
        String y = "";
        if ("mapa".equals(tag)) {
            x = o.getMapa_x();
            y = o.getMapa_y();
        } else {
            x = o.getTs_x();
            y = o.getTs_y();
        }
        if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
            String req = String.format(getZcAndTcUrl, x, y);
            content = HttpInvokeUtil.sendGet(req);
        }

        String zc = "";
        String tc = "";

        try {
            zc = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("parentCode");
            tc = JSON.parseObject(content).getJSONObject("result").getJSONObject("data").getString("code");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if ("mapa".equals(tag)) {
            o.setMapa_zc(zc);
            o.setMapa_tc(tc);
        } else {
            o.setTs_zc(zc);
            o.setTs_tc(tc);
        }
        return o;
    }


    public JavaRDD<DbPressSb> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = SqlUtil.getSqlStr("db_press_sb.sql", date, date, DateUtil.getDaysBefore(date, 6), date);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, DbPressSb.class);
    }
}
