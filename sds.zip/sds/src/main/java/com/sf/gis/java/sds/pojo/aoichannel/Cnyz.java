package com.sf.gis.java.sds.pojo.aoichannel;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class Cnyz implements Serializable {
    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "county")
    private String county;
    @Column(name = "town")
    private String town;
    @Column(name = "pointname")
    private String pointname;
    @Column(name = "nettype")
    private String nettype;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;
    @Column(name = "address")
    private String address;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "region")
    private String region;
    @Column(name = "company")
    private String company;
    @Column(name = "pingtai")
    private String pingtai;

    private String stdAoi;
    private String stdAoiCode;
    private String aoi_area_code;
    private String origion_aoi_area_code;

    private String req;
    private String resJson;
    private String aoi_id;
    private String aoi_code;
    private String aoi_name;

    public String getStdAoi() {
        return stdAoi;
    }

    public void setStdAoi(String stdAoi) {
        this.stdAoi = stdAoi;
    }

    public String getStdAoiCode() {
        return stdAoiCode;
    }

    public void setStdAoiCode(String stdAoiCode) {
        this.stdAoiCode = stdAoiCode;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }

    public String getOrigion_aoi_area_code() {
        return origion_aoi_area_code;
    }

    public void setOrigion_aoi_area_code(String origion_aoi_area_code) {
        this.origion_aoi_area_code = origion_aoi_area_code;
    }

    public String getReq() {
        return req;
    }

    public void setReq(String req) {
        this.req = req;
    }

    public String getResJson() {
        return resJson;
    }

    public void setResJson(String resJson) {
        this.resJson = resJson;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getPointname() {
        return pointname;
    }

    public void setPointname(String pointname) {
        this.pointname = pointname;
    }

    public String getNettype() {
        return nettype;
    }

    public void setNettype(String nettype) {
        this.nettype = nettype;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPingtai() {
        return pingtai;
    }

    public void setPingtai(String pingtai) {
        this.pingtai = pingtai;
    }
}
