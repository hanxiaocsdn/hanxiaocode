package com.sf.gis.java.sds.enumtype;

public enum ConfigKey {
    commonDayAgo,bigCityDayAgo,smallCityDayAgo,days,
    sshUserName,sshPwd,sshHost,openCity,sshPath,sshFileName,move_data_url,forward,
    csv_header,save_by_day,clear_expire_data_days,data_type,aoi_order_task,
    phone_hook_days,phone_hook_city,dept_change_url,change_city_code,flag,
    beginDate,endDate,save_hbase_url,ak,zhiyu_city_code,duomi_city_code,
    project_type,dept_hook,sync_city,save_sta_day,use_cache
}
