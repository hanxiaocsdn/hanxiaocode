package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiMaxIndexByGroupW;
import com.sf.gis.java.sds.service.GroupAoiToCmsService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public class GroupAoiToCmsController implements Serializable {
    private Logger logger = LoggerFactory.getLogger(GroupAoiToCmsController.class);
    GroupAoiToCmsService service = new GroupAoiToCmsService();

    public void start(String incDay) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
//        Broadcast<String> addressUpdateAoiUrlBc = sc.broadcast(VariableConstant.configProps.getProperty("addressUpdateAoiUrl"));
//        Broadcast<String> getAddrByCityCodeAndAddrUrlBc = sc.broadcast(VariableConstant.configProps.getProperty("getAddrByCityCodeAndAddrUrl"));

        JavaRDD<AoiMaxIndexByGroupW> aoiMaxIndexByGroupWRdd = service.loadData(spark, sc, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiMaxIndexByGroupWRdd cnt:{}", aoiMaxIndexByGroupWRdd.count());
        aoiMaxIndexByGroupWRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<AoiMaxIndexByGroupW> freqRdd = aoiMaxIndexByGroupWRdd.map(o -> {
            String max_r_aoi_cnt = o.getMax_r_aoi_cnt();
            String max_80_aoi_cnt = o.getMax_80_aoi_cnt();
            String group_size = o.getGroup_size();
            double max_r_aoi_freq = 0, max_80_aoi_freq = 0;
            if (StringUtils.isNotEmpty(group_size) && Double.valueOf(group_size) != 0) {
                double group_size_double = Double.valueOf(group_size);
                double max_r_aoi_double = Double.valueOf(StringUtils.isNotEmpty(max_r_aoi_cnt) ? max_r_aoi_cnt : "0");
                double max_80_aoi_double = Double.valueOf(StringUtils.isNotEmpty(max_80_aoi_cnt) ? max_80_aoi_cnt : "0");

                max_r_aoi_freq = max_r_aoi_double / group_size_double;
                max_80_aoi_freq = max_80_aoi_double / group_size_double;
                o.setMax_r_aoi_freq(String.valueOf(max_r_aoi_freq));
                o.setMax_80_aoi_freq(String.valueOf(max_80_aoi_freq));
            }
            String byxy_resp = o.getByxy_resp();
            if (StringUtils.isNotEmpty(byxy_resp)) {
                JSONObject jsonObject = JSON.parseObject(byxy_resp);
                int status = jsonObject.getInteger("status");
                if (status == 0) {
                    JSONObject result = jsonObject.getJSONObject("result");
                    if (result != null) {
                        JSONArray aoi_data = result.getJSONArray("aoi_data");
                        if (aoi_data != null) {
                            String aoi_id = aoi_data.getJSONObject(0).getString("aoi_id");
                            o.setTs_aoi_id(aoi_id);
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("freqRdd cnt:{}", freqRdd.count());
        freqRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        aoiMaxIndexByGroupWRdd.unpersist();

        JavaRDD<AoiMaxIndexByGroupW> filterRdd = freqRdd.filter(o -> service.judge(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());
        filterRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        freqRdd.unpersist();

        JavaRDD<AoiMaxIndexByGroupW> finalRdd = filterRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalRdd cnt:{}", finalRdd.count());
        finalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        filterRdd.unpersist();

        //数据入库
        service.saveData(spark, finalRdd, incDay);

//        finalRdd = finalRdd.map(o -> {
//            String cityCode = o.getReq_destcitycode();
//            String addressId = o.getGis_to_sys_groupid();
//            String content = service.runGetCmsAoi(getAddrByCityCodeAndAddrUrlBc.value(), cityCode, addressId);
//            if (StringUtils.isNotEmpty(content)) {
//                JSONObject jsonObject = JSON.parseObject(content);
//                if (jsonObject != null) {
//                    Boolean success = jsonObject.getBoolean("success");
//                    if (success) {
//                        JSONObject data = jsonObject.getJSONObject("data");
//                        if (data != null) {
//                            String aoiId = data.getString("aoiId");
//                            String adcode = data.getString("adcode");
//                            String znoCode = data.getString("znoCode");
//
//                            o.setCmsAoi(aoiId);
//                            o.setCmsAdcode(adcode);
//                            o.setCmsZnoCode(znoCode);
//                        }
//                    }
//                }
//            }
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("finalRdd cnt:{}", finalRdd.count());
//        finalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//
//        JavaRDD<AoiMaxIndexByGroupW> aoiEqualRdd = finalRdd.filter(o -> StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("aoi equals cnt:{}", aoiEqualRdd.count());
//        aoiEqualRdd.unpersist();
//
//        JavaRDD<AoiMaxIndexByGroupW> adcodeEqual1Rdd = finalRdd.filter(o -> !StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi())
//                && StringUtils.equals(o.getCmsAdcode(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("adcode == '1' cnt:{}", adcodeEqual1Rdd.count());
//        adcodeEqual1Rdd.unpersist();
//
//        JavaRDD<AoiMaxIndexByGroupW> checkRdd = finalRdd.filter(o -> !StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi()) &&
//                !StringUtils.equals(o.getCmsAdcode(), "1") &&
//                StringUtils.isNotEmpty(o.getMax_r_aoi()) &&
//                StringUtils.isNotEmpty(o.getCmsZnoCode()) &&
//                !o.getMax_r_aoi().contains(o.getCmsZnoCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("checkRdd cnt:{}",checkRdd.count());
//        checkRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        //存储
//        if(checkRdd.count() > 0){
//            service.saveCheckData(spark,checkRdd,incDay);
//        }
//        checkRdd.unpersist();
//
//
//        logger.error("调用更新接口");
//        //调用更新接口
//        JavaRDD<AoiMaxIndexByGroupW> updateRdd = finalRdd.filter(o -> !StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi()) &&
//                !StringUtils.equals(o.getCmsAdcode(), "1") &&
//                StringUtils.isNotEmpty(o.getMax_r_aoi()) &&
//                StringUtils.isNotEmpty(o.getCmsZnoCode()) &&
//                o.getMax_r_aoi().contains(o.getCmsZnoCode())).map(o -> {
//            String req_destcitycode = o.getReq_destcitycode();
//            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
//            String ts_aoi_id = o.getTs_aoi_id();
//            String checkZnoCode = "1";
//            String operSource = "AOI_ADD";
//            String operUserName = "01407317";
//
//            JSONObject jsonObject = new JSONObject();
//            jsonObject.put("cityCode", req_destcitycode);
//            jsonObject.put("addressId", gis_to_sys_groupid);
//            jsonObject.put("aoiId", ts_aoi_id);
//            jsonObject.put("checkZnoCode", checkZnoCode);
//            jsonObject.put("operSource", operSource);
//            jsonObject.put("operUserName", operUserName);
//
//            String content = service.runAddrUpdateAoi(addressUpdateAoiUrlBc.value(), jsonObject.toJSONString());
//            o.setContent(content);
//            if (StringUtils.isNotEmpty(content)) {
//                JSONObject result = JSON.parseObject(content);
//                if (result != null) {
//                    Boolean success = result.getBoolean("success");
//                    o.setFlag(success);
//                    if (success) {
//                        logger.error("-----------access success-----------");
//                    } else {
//                        logger.error("-----------access fail,param:{}-----------", jsonObject.toJSONString());
//                    }
//                }
//            }
//
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("updateRdd cnt:{}", updateRdd.count());
//        updateRdd.take(3).forEach(o -> logger.error(JSON.toJSONString(o)));
//
//        logger.error("success cnt:{}", updateRdd.filter(o -> true == o.getFlag()).count());
//        logger.error("fial cnt:{}", updateRdd.filter(o -> true != o.getFlag()).count());

        finalRdd.unpersist();
//        updateRdd.unpersist();

        spark.stop();

    }

    public static void main(String[] args) {
        System.out.println("asf".contains("a"));
    }
}
