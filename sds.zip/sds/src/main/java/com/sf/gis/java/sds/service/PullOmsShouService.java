package com.sf.gis.java.sds.service;


import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.ShellExcutor;
import com.sf.gis.java.sds.bean.FtpClient;
import com.sf.gis.java.sds.bean.GisToAddrStatShou;
import com.sf.gis.java.sds.enumtype.ConfigKey;
import com.sf.gis.java.sds.utils.ZipCompress;
import com.sf.gis.scala.base.spark.Spark;
import com.sf.gis.scala.base.util.HttpClientUtil;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PullOmsShouService implements Serializable {
    private static final Logger logger = LoggerFactory.getLogger(PullOmsShouService.class);

    /**
     *
     */
    private static final long serialVersionUID = 8028863965782523787L;
    private SparkSession sparkSession;
    private String gis_rds_omsfrom = "dm_gis.gis_rds_omsfrom";

    public PullOmsShouService() {
        Map<String, String> map = new HashMap<String, String>();
        // map.put("spark.executor.memory","10g");
        // map.put("spark.executor.instances","20");
        // map.put("spark.driver.memory", "10g");
        sparkSession = Spark.getSparkSession(PullOmsShouService.class.getSimpleName(), null, false, 2);

    }

    public void pullData(int commonDayAgo, int bigCityDayAgo, int smallCityDayAgo, Map<String, String> configMap) {
        String endDate = DateUtil.getCurrentDateBefore("yyyyMMdd", commonDayAgo);
        String bigBegin = DateUtil.getCurrentDateBefore("yyyyMMdd", bigCityDayAgo + commonDayAgo);
        String smallBegin = DateUtil.getCurrentDateBefore("yyyyMMdd", smallCityDayAgo + commonDayAgo);
        logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        logger.error(smallBegin + "," + bigBegin + "," + endDate);
        String ftpPath = configMap.get(ConfigKey.sshPath.name());
        String ftpFileName = configMap.get(ConfigKey.sshFileName.name());

        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));

        parserCity(openCityList.stream().collect(Collectors.joining("','")), bigBegin, endDate, ftpClient, ftpPath,
                ftpFileName, configMap);

        ftpClient.close();

    }

    private void parserCity(String city, String beginDate, String endDate, FtpClient ftpClient, String ftpPath,
                            String ftpFileName, Map<String, String> configMap) {
        String sql = "SELECT regexp_replace(sysorderno, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') sysorderno, '' as id,"
                + " regexp_replace(address, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') norm_address,"
                + " regexp_replace(deptcode, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', ''), regexp_replace(teamcode, '[\\r\\n\\0, \\,, \\.,\"]+', '') his_teamcode,"
                + " inc_day, citycode, '1' as count,"
                + " regexp_replace(province, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', ''),"
                + " regexp_replace(city, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', ''),"
                + " regexp_replace(county, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', ''),"
                + " regexp_replace(company, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', ''),"
                + " get_json_object(pickupbody, '$.pick_up_tc')," + " errcallteamid,errcallflag,phone,mobile,src FROM "
                + gis_rds_omsfrom + " where inc_day >= '" + beginDate + "' and inc_day <= '" + endDate
                + "' and citycode in ('" + city + "') and deptcode <> '' ";
        // String group_sql = "select first(sysorderno) ,first(id)
        // ,norm_address,"
        // + "deptcode,his_teamcode,first(inc_day) ,"
        // + "citycode,sum(count) from (" + sql
        // + ") b group by citycode,norm_address,deptcode,his_teamcode ";
        logger.error(sql);
        JavaRDD<GisToAddrStatShou> dataRdd = sparkSession.sql(sql).javaRDD().persist(StorageLevel.MEMORY_AND_DISK_SER())
                .map(x -> new GisToAddrStatShou(x.getString(0), x.getString(1), x.getString(2), "", x.getString(3),
                        x.getString(4), x.getString(5), x.getString(6), x.getString(7), "", "", "", "", x.getString(8),
                        x.getString(9), x.getString(10), x.getString(11), x.getString(12), x.getString(13),
                        x.getString(14), x.getString(15), x.getString(16), x.getString(17)));
        parserAllData(dataRdd, ftpClient, ftpPath, ftpFileName, configMap, beginDate);
    }

    private void parserAllData(JavaRDD<GisToAddrStatShou> dataRdd, FtpClient ftpClient, String ftpPath,
                               String ftpFileName, Map<String, String> configMap, String beginDate) {
        // 加上分区得到唯一id
        String csvHeader = configMap.get(ConfigKey.csv_header.name());
        JavaRDD<String> ret = dataRdd.map(x -> x.getWaybillno() + "," + x.getCitycode() + "," + x.getDeptcode() + ","
                + x.getHis_teamcode() + "," + x.getInc_day() + "," + x.getNorm_address() + "," + x.getSss_deptcode()
                + "," + x.getCount() + "," + x.getZonecode() + "," + x.getXiaoge_deptcode() + "," + x.getXiaoge_no()
                + "," + x.getLogteamcode() + "," + x.getReq_province() + "," + x.getReq_city() + "," + x.getReq_area()
                + "," + x.getReq_comp_name() + "," + x.getPick_up_tc() + "," + x.getErrcallteamid() + ","
                + x.getErrcallflag() + "," + x.getTel() + "," + x.getMobile() + "," + x.getSrc());
        String saveByDay = configMap.get(ConfigKey.save_by_day.name());
        String srcName = "multi" + ftpFileName;
        try {
            String hdfsFile = "/user/01374443/upload/tmp/oms_data_shou/" + srcName;
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            ret.zipWithIndex().map(obj -> {
                return obj._2 + "," + obj._1;
            }).saveAsTextFile(hdfsFile);
            ShellExcutor.exeCmd("hadoop fs -getmerge " + hdfsFile + " " + srcName + ".csv");
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            if ("true".equals(csvHeader)) {
                logger.error("增加文件头~");
                ShellExcutor.exeCmd("sed -i '1i\\id,waybillno,citycode,deptcode,"
                        + "his_teamcode,inc_day,norm_address,sss_deptcode,count,"
                        + "zonecode,xiaoge_deptcode,xiaoge_no,logteamcode,"
                        + "province,cityName,district,company,pick_up_tc,errcallteamid,errcallflag,"
                        + "tel,mobile,src' " + srcName + ".csv");
                if ("true".equals(saveByDay)) {
                    ftpPath = ftpPath + "/" + beginDate;
                }
            }
            if (!checkFile(srcName + ".csv")) {
                return;
            }
            ZipCompress.zip(srcName + ".zip", srcName + ".csv");
            uploadFile(srcName + ".zip", ftpClient, ftpPath);
            delete_file(srcName);
            String forward = configMap.get(ConfigKey.forward.name());
            if (forward != null && forward.equals("true")) {
                String moveUrl = configMap.get(ConfigKey.move_data_url.name());

                HttpClientUtil.getStrByGet(
                        String.format(moveUrl, ftpPath, srcName + ".zip", beginDate + "/" + srcName + ".zip"),"UTF-8");

            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

    private void delete_file(String srcName) {
        File file = new File(srcName + ".zip");
        if (file.exists()) {
            file.delete();
        }
        file = new File(srcName + ".csv");
        if (file.exists()) {
            file.delete();
        }
    }

    private boolean checkFile(String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            return false;
        } else if (file.length() == 0) {
            file.delete();
            return false;
        }
        return true;
    }

    private void uploadFile(String fileName, FtpClient ftpClient, String ftpPath) {
        try {
            ftpClient.uploadFile(fileName, ftpPath);
        } catch (Exception e) {
            logger.error("ftp error:" + e.getMessage());
        }
    }

    /**
     * 获取tc缺失数据
     *
     * @param commonDayAgo
     * @param configMap
     */
    public void pullTcEmptyData(int commonDayAgo, Map<String, String> configMap) {
        String endDate = DateUtil.getCurrentDateBefore("yyyyMMdd", commonDayAgo);
        logger.error("open city:" + configMap.get(ConfigKey.openCity.name()));
        List<String> openCityList = Arrays.asList(configMap.get(ConfigKey.openCity.name()).split(","));
        String ftpPath = configMap.get(ConfigKey.sshPath.name());
        String ftpFileName = configMap.get(ConfigKey.sshFileName.name());
        FtpClient ftpClient = new FtpClient(configMap.get(ConfigKey.sshHost.name()),
                configMap.get(ConfigKey.sshUserName.name()), configMap.get(ConfigKey.sshPwd.name()));

        parserTcEmptyCity(openCityList.stream().collect(Collectors.joining("','")), endDate, endDate, ftpClient,
                ftpPath, ftpFileName, configMap);

        ftpClient.close();

    }

    /**
     * tc empty下载城市级别
     *
     * @param collect
     * @param endDate
     * @param endDate2
     * @param ftpClient
     * @param ftpPath
     * @param ftpFileName
     * @param configMap
     */
    private void parserTcEmptyCity(String city_str, String beginDate, String endDate, FtpClient ftpClient,
                                   String ftpPath, String ftpFileName, Map<String, String> configMap) {
        String sql = "select inc_day,citycode as city,sysorderno,regexp_replace(orderNo, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', ''),"
                + "regexp_replace(province, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') province,"
                + "regexp_replace(city, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') cityName,"
                + "regexp_replace(county, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') district,"
                + "regexp_replace(address, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') address,"
                + "regexp_replace(company, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') company,"
                + "phone,mobile,src as src_src,groupid,errcallflag as errcallflag,"
                + "deptcode as deptcode,teamcode as teamcode,"
                + "if (errcallflag = 'true', errcallteamid, teamcode) as his_teamcode,"
                + "regexp_replace(errcalladdrabb, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '') as errcalladdrabb,"
                + "concat(errcallprovince,errcallcity,errcallcounty,"
                + "regexp_replace(errcalladdrabb, '[\\r,\\n,\\0,\\t, \\,, \\.,\"]+', '')) as errnorm_address,"
                + "errcalladdrgroupid as errcalladdrgroupid,errcalldept as errcalldept,"
                + "errcallteamid as errcallteamid,get_json_object(pickupbody, '$.pick_up_tc') as teamid "
                + "FROM dm_gis.gis_rds_omsfrom WHERE inc_day between '" + beginDate + "' and '" + endDate
                + "' and citycode in ('" + city_str + "') and (src in ('sch','chke_cur') or teamcode='') ";
        logger.error(sql);
        JavaRDD<String> ret = sparkSession.sql(sql).javaRDD()
                .map(x -> x.getString(0) + "," + x.getString(1) + "," + x.getString(2) + "," + x.getString(3) + ","
                        + x.getString(4) + "," + x.getString(5) + "," + x.getString(6) + "," + x.getString(7) + ","
                        + x.getString(8) + "," + x.getString(9) + "," + x.getString(10) + "," + x.getString(11) + ","
                        + x.getString(12) + "," + x.getString(13) + "," + x.getString(14) + "," + x.getString(15) + ","
                        + x.getString(16) + "," + x.getString(17) + "," + x.getString(18) + "," + x.getString(19) + ","
                        + x.getString(20) + "," + x.getString(21) + "," + (x.getString(22) == null ? "" : x.getString(22)));
        // 加上分区得到唯一id
        String srcName = "multi" + "_" + beginDate + ftpFileName;
        try {
            String hdfsFile = "/user/01374443/upload/tmp/oms_data_tc_empty/" + srcName;
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);
            ret.saveAsTextFile(hdfsFile);
            ShellExcutor.exeCmd("hadoop fs -getmerge " + hdfsFile + " " + srcName + ".csv");
            ShellExcutor.exeCmd(" hdfs dfs -rm -r " + hdfsFile);

            logger.error("增加文件头~");
            ShellExcutor.exeCmd("sed -i '1i\\inc_day,city,sysorderno,orderNo,"
                    + "province,cityName,district,address,company," + "phone,mobile,src_src,groupid,"
                    + "errcallflag,deptcode,teamcode,his_teamcode,errcalladdrabb,errnorm_address,"
                    + "errcalladdrgroupid," + "errcalldept,errcallteamid,teamid' " + srcName + ".csv");
            if (!checkFile(srcName + ".csv")) {
                return;
            }
            ZipCompress.zip(srcName + ".zip", srcName + ".csv");
            uploadFile(srcName + ".zip", ftpClient, ftpPath);
            delete_file(srcName);
            String moveUrl = configMap.get(ConfigKey.move_data_url.name());
            String useUrl = String.format(moveUrl, ftpPath, srcName + ".zip");
            logger.error(useUrl);
            HttpClientUtil.getStrByGet(useUrl,"UTF-8");

        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }

}