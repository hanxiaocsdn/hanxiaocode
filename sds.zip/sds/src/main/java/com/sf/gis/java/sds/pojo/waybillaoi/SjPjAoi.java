package com.sf.gis.java.sds.pojo.waybillaoi;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SjPjAoi implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "original_zone_code")
    private String original_zone_code;
    @Column(name = "original_city_code")
    private String original_city_code;
    @Column(name = "member_no")
    private String member_no;
    @Column(name = "tm")
    private String tm;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "original_aoi_code")
    private String original_aoi_code;
    @Column(name = "original_aoi_area_code")
    private String original_aoi_area_code;
    @Column(name = "fa_type")
    private String fa_type;
    @Column(name = "tag")
    private String tag;
    @Column(name = "destination_zone_code")
    private String destination_zone_code;
    @Column(name = "destination_city_code")
    private String destination_city_code;
    @Column(name = "inc_day")
    private String inc_day;

    @Column(name = "aoi_category")
    private String aoi_category;

    public String getAoi_category() {
        return aoi_category;
    }

    public void setAoi_category(String aoi_category) {
        this.aoi_category = aoi_category;
    }

    public String getDestination_city_code() {
        return destination_city_code;
    }

    public void setDestination_city_code(String destination_city_code) {
        this.destination_city_code = destination_city_code;
    }

    public String getDestination_zone_code() {
        return destination_zone_code;
    }

    public void setDestination_zone_code(String destination_zone_code) {
        this.destination_zone_code = destination_zone_code;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getOriginal_zone_code() {
        return original_zone_code;
    }

    public void setOriginal_zone_code(String original_zone_code) {
        this.original_zone_code = original_zone_code;
    }

    public String getOriginal_city_code() {
        return original_city_code;
    }

    public void setOriginal_city_code(String original_city_code) {
        this.original_city_code = original_city_code;
    }

    public String getMember_no() {
        return member_no;
    }

    public void setMember_no(String member_no) {
        this.member_no = member_no;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getOriginal_aoi_code() {
        return original_aoi_code;
    }

    public void setOriginal_aoi_code(String original_aoi_code) {
        this.original_aoi_code = original_aoi_code;
    }

    public String getOriginal_aoi_area_code() {
        return original_aoi_area_code;
    }

    public void setOriginal_aoi_area_code(String original_aoi_area_code) {
        this.original_aoi_area_code = original_aoi_area_code;
    }

    public String getFa_type() {
        return fa_type;
    }

    public void setFa_type(String fa_type) {
        this.fa_type = fa_type;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }
}
