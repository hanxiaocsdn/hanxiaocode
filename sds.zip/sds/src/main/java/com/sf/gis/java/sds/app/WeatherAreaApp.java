package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.WeatherAreaController;

public class WeatherAreaApp {
    public static void main(String[] args) {
        new WeatherAreaController().ftpFile2Hive();
    }
}
