package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class EdcsWaybillContentSwsKafkaSjOutAreaRealAoi implements Serializable {
    @Column(name = "original_waybill_no")
    private String original_waybill_no;
    @Column(name = "original_zone_code")
    private String original_zone_code;
    @Column(name = "original_city_code")
    private String original_city_code;
    @Column(name = "original_member_no")
    private String original_member_no;
    @Column(name = "original_tm")
    private String original_tm;
    @Column(name = "original_aoi_id")
    private String original_aoi_id;
    @Column(name = "original_aoi_code")
    private String original_aoi_code;
    @Column(name = "original_aoi_area_code")
    private String original_aoi_area_code;
    @Column(name = "original_fa_type")
    private String original_fa_type;
    @Column(name = "original_tag")
    private String original_tag;
    @Column(name = "destination_zone_code")
    private String destination_zone_code;
    @Column(name = "destination_city_code")
    private String destination_city_code;

    @Column(name = "initial_original_aoi_id")
    private String initial_original_aoi_id;
    @Column(name = "initial_original_aoi_code")
    private String initial_original_aoi_code;
    @Column(name = "initial_original_aoi_area_code")
    private String initial_original_aoi_area_code;
    @Column(name = "initial_original_fa_type")
    private String initial_original_fa_type;

    @Column(name = "inc_day")
    private String inc_day;


    public String getOriginal_waybill_no() {
        return original_waybill_no;
    }

    public void setOriginal_waybill_no(String original_waybill_no) {
        this.original_waybill_no = original_waybill_no;
    }

    public String getOriginal_zone_code() {
        return original_zone_code;
    }

    public void setOriginal_zone_code(String original_zone_code) {
        this.original_zone_code = original_zone_code;
    }

    public String getOriginal_city_code() {
        return original_city_code;
    }

    public void setOriginal_city_code(String original_city_code) {
        this.original_city_code = original_city_code;
    }

    public String getOriginal_member_no() {
        return original_member_no;
    }

    public void setOriginal_member_no(String original_member_no) {
        this.original_member_no = original_member_no;
    }

    public String getOriginal_tm() {
        return original_tm;
    }

    public void setOriginal_tm(String original_tm) {
        this.original_tm = original_tm;
    }

    public String getOriginal_aoi_id() {
        return original_aoi_id;
    }

    public void setOriginal_aoi_id(String original_aoi_id) {
        this.original_aoi_id = original_aoi_id;
    }

    public String getOriginal_aoi_code() {
        return original_aoi_code;
    }

    public void setOriginal_aoi_code(String original_aoi_code) {
        this.original_aoi_code = original_aoi_code;
    }

    public String getOriginal_aoi_area_code() {
        return original_aoi_area_code;
    }

    public void setOriginal_aoi_area_code(String original_aoi_area_code) {
        this.original_aoi_area_code = original_aoi_area_code;
    }

    public String getOriginal_fa_type() {
        return original_fa_type;
    }

    public void setOriginal_fa_type(String original_fa_type) {
        this.original_fa_type = original_fa_type;
    }

    public String getOriginal_tag() {
        return original_tag;
    }

    public void setOriginal_tag(String original_tag) {
        this.original_tag = original_tag;
    }

    public String getDestination_zone_code() {
        return destination_zone_code;
    }

    public void setDestination_zone_code(String destination_zone_code) {
        this.destination_zone_code = destination_zone_code;
    }

    public String getDestination_city_code() {
        return destination_city_code;
    }

    public void setDestination_city_code(String destination_city_code) {
        this.destination_city_code = destination_city_code;
    }

    public String getInitial_original_aoi_id() {
        return initial_original_aoi_id;
    }

    public void setInitial_original_aoi_id(String initial_original_aoi_id) {
        this.initial_original_aoi_id = initial_original_aoi_id;
    }

    public String getInitial_original_aoi_code() {
        return initial_original_aoi_code;
    }

    public void setInitial_original_aoi_code(String initial_original_aoi_code) {
        this.initial_original_aoi_code = initial_original_aoi_code;
    }

    public String getInitial_original_aoi_area_code() {
        return initial_original_aoi_area_code;
    }

    public void setInitial_original_aoi_area_code(String initial_original_aoi_area_code) {
        this.initial_original_aoi_area_code = initial_original_aoi_area_code;
    }

    public String getInitial_original_fa_type() {
        return initial_original_fa_type;
    }

    public void setInitial_original_fa_type(String initial_original_fa_type) {
        this.initial_original_fa_type = initial_original_fa_type;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
