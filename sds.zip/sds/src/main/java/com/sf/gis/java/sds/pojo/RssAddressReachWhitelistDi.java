package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class RssAddressReachWhitelistDi implements Serializable {
    @Column(name = "mainwaybillno")
    private String mainwaybillno;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "result")
    private String result;
    @Column(name = "province")
    private String province;
    @Column(name = "city")
    private String city;
    @Column(name = "county")
    private String county;
    @Column(name = "town")
    private String town;
    @Column(name = "village")
    private String village;
    @Column(name = "detailinfo")
    private String detailinfo;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "inc_day")
    private String inc_day;

    private int temp_result;
    private String temp_src;

    public int getTemp_result() {
        return temp_result;
    }

    public void setTemp_result(int temp_result) {
        this.temp_result = temp_result;
    }

    public String getTemp_src() {
        return temp_src;
    }

    public void setTemp_src(String temp_src) {
        this.temp_src = temp_src;
    }

    public String getMainwaybillno() {
        return mainwaybillno;
    }

    public void setMainwaybillno(String mainwaybillno) {
        this.mainwaybillno = mainwaybillno;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getDetailinfo() {
        return detailinfo;
    }

    public void setDetailinfo(String detailinfo) {
        this.detailinfo = detailinfo;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
