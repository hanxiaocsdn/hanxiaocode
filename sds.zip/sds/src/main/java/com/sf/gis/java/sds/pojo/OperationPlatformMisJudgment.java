package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class OperationPlatformMisJudgment implements Serializable {
    @Column(name = "gis_gid")
    private String gis_gid;
    @Column(name = "new_data_date")
    private String new_data_date;
    @Column(name = "receive_addr")
    private String receive_addr;
    @Column(name = "origi_id")
    private String origi_id;
    @Column(name = "upload_date")
    private String upload_date;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "company_name")
    private String company_name;
    @Column(name = "final_aoi_name")
    private String final_aoi_name;
    @Column(name = "gis_final_aoi")
    private String gis_final_aoi;
    @Column(name = "fault_reason")
    private String fault_reason;
    @Column(name = "remark_reason")
    private String remark_reason;
    @Column(name = "gis_src")
    private String gis_src;
    @Column(name = "inc_day")
    private String inc_day;

    private String month;
    private String finalaoicode;
    private String bottomcorrected;
    private String tag;

    private String label;
    private String right_freq;
    private String week_finalaoicode;
    private String check_aoi_code;

    private String gj_aoicode_t;
    private String aoi_80_code;

    private List<String> gj_aoi_list;
    private List<String> aoi_80_list;
    private String xcoord;
    private String ycoord;
    private String precision;
    private String gd_aoi;
    private String proAoi;

    private String group_tag;

    private String unionTag1;
    private String unionTag2;
    private String unionTag3;
    private String unionTag4;
    private String unionTag5;
    private String unionTag6;
    private String unionTag7;
    private String unionTag8;

    private String region;

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getUnionTag8() {
        return unionTag8;
    }

    public void setUnionTag8(String unionTag8) {
        this.unionTag8 = unionTag8;
    }

    private String address_count;
    private String address_count_monthly;
    @Column(name = "address_count_zc")
    private String address_count_zc;

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getAddress_count() {
        return address_count;
    }

    public void setAddress_count(String address_count) {
        this.address_count = address_count;
    }

    public String getAddress_count_monthly() {
        return address_count_monthly;
    }

    public void setAddress_count_monthly(String address_count_monthly) {
        this.address_count_monthly = address_count_monthly;
    }

    public String getAddress_count_zc() {
        return address_count_zc;
    }

    public void setAddress_count_zc(String address_count_zc) {
        this.address_count_zc = address_count_zc;
    }

    public String getUnionTag7() {
        return unionTag7;
    }

    public void setUnionTag7(String unionTag7) {
        this.unionTag7 = unionTag7;
    }

    public String getGroup_tag() {
        return group_tag;
    }

    public void setGroup_tag(String group_tag) {
        this.group_tag = group_tag;
    }

    public String getProAoi() {
        return proAoi;
    }

    public void setProAoi(String proAoi) {
        this.proAoi = proAoi;
    }

    public String getGd_aoi() {
        return gd_aoi;
    }

    public void setGd_aoi(String gd_aoi) {
        this.gd_aoi = gd_aoi;
    }

    public String getPrecision() {
        return precision;
    }

    public void setPrecision(String precision) {
        this.precision = precision;
    }

    public String getXcoord() {
        return xcoord;
    }

    public void setXcoord(String xcoord) {
        this.xcoord = xcoord;
    }

    public String getYcoord() {
        return ycoord;
    }

    public void setYcoord(String ycoord) {
        this.ycoord = ycoord;
    }

    public String getUnionTag6() {
        return unionTag6;
    }

    public void setUnionTag6(String unionTag6) {
        this.unionTag6 = unionTag6;
    }

    public List<String> getGj_aoi_list() {
        return gj_aoi_list;
    }

    public void setGj_aoi_list(List<String> gj_aoi_list) {
        this.gj_aoi_list = gj_aoi_list;
    }

    public List<String> getAoi_80_list() {
        return aoi_80_list;
    }

    public void setAoi_80_list(List<String> aoi_80_list) {
        this.aoi_80_list = aoi_80_list;
    }

    public String getGj_aoicode_t() {
        return gj_aoicode_t;
    }

    public void setGj_aoicode_t(String gj_aoicode_t) {
        this.gj_aoicode_t = gj_aoicode_t;
    }

    public String getAoi_80_code() {
        return aoi_80_code;
    }

    public void setAoi_80_code(String aoi_80_code) {
        this.aoi_80_code = aoi_80_code;
    }

    public String getUnionTag5() {
        return unionTag5;
    }

    public void setUnionTag5(String unionTag5) {
        this.unionTag5 = unionTag5;
    }

    public String getUnionTag4() {
        return unionTag4;
    }

    public void setUnionTag4(String unionTag4) {
        this.unionTag4 = unionTag4;
    }

    public String getCheck_aoi_code() {
        return check_aoi_code;
    }

    public void setCheck_aoi_code(String check_aoi_code) {
        this.check_aoi_code = check_aoi_code;
    }

    public String getUnionTag3() {
        return unionTag3;
    }

    public void setUnionTag3(String unionTag3) {
        this.unionTag3 = unionTag3;
    }

    public String getUnionTag1() {
        return unionTag1;
    }

    public void setUnionTag1(String unionTag1) {
        this.unionTag1 = unionTag1;
    }

    public String getUnionTag2() {
        return unionTag2;
    }

    public void setUnionTag2(String unionTag2) {
        this.unionTag2 = unionTag2;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getRight_freq() {
        return right_freq;
    }

    public void setRight_freq(String right_freq) {
        this.right_freq = right_freq;
    }

    public String getWeek_finalaoicode() {
        return week_finalaoicode;
    }

    public void setWeek_finalaoicode(String week_finalaoicode) {
        this.week_finalaoicode = week_finalaoicode;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getBottomcorrected() {
        return bottomcorrected;
    }

    public void setBottomcorrected(String bottomcorrected) {
        this.bottomcorrected = bottomcorrected;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getGis_src() {
        return gis_src;
    }

    public void setGis_src(String gis_src) {
        this.gis_src = gis_src;
    }

    public String getGis_gid() {
        return gis_gid;
    }

    public void setGis_gid(String gis_gid) {
        this.gis_gid = gis_gid;
    }

    public String getNew_data_date() {
        return new_data_date;
    }

    public void setNew_data_date(String new_data_date) {
        this.new_data_date = new_data_date;
    }

    public String getReceive_addr() {
        return receive_addr;
    }

    public void setReceive_addr(String receive_addr) {
        this.receive_addr = receive_addr;
    }

    public String getOrigi_id() {
        return origi_id;
    }

    public void setOrigi_id(String origi_id) {
        this.origi_id = origi_id;
    }

    public String getUpload_date() {
        return upload_date;
    }

    public void setUpload_date(String upload_date) {
        this.upload_date = upload_date;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getFinal_aoi_name() {
        return final_aoi_name;
    }

    public void setFinal_aoi_name(String final_aoi_name) {
        this.final_aoi_name = final_aoi_name;
    }

    public String getGis_final_aoi() {
        return gis_final_aoi;
    }

    public void setGis_final_aoi(String gis_final_aoi) {
        this.gis_final_aoi = gis_final_aoi;
    }

    public String getFault_reason() {
        return fault_reason;
    }

    public void setFault_reason(String fault_reason) {
        this.fault_reason = fault_reason;
    }

    public String getRemark_reason() {
        return remark_reason;
    }

    public void setRemark_reason(String remark_reason) {
        this.remark_reason = remark_reason;
    }
}
