package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.EdcsWaybillContentSwsKafkaSjController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppEdcsWaybillContentSwsKafkaSj {
    private static Logger logger = LoggerFactory.getLogger(AppEdcsWaybillContentSwsKafkaSj.class);

    public static void main(String[] args) {
        String date = args[0];
        String minDate = args[1];
        String[] split = minDate.split("#");
        minDate = split[0] + " " + split[1];
        logger.error("date:{},minDate:{}", date, minDate);
        new EdcsWaybillContentSwsKafkaSjController().process(date, minDate);
        logger.error("process end...");
    }
}
