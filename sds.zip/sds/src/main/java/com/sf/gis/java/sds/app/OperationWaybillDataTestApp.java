package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.SparkUtil;
//import com.sf.gis.java.sds.controller.EdcsWaybillContentSwsKafkaSjController;
import com.sf.gis.java.sds.pojo.aoicompletion.ShivaOmsCoreOperationWaybillKafka;
import com.sf.gis.java.sds.pojo.aoicompletion.TtAppointAdditionKafka;
import com.sf.gis.java.sds.pojo.waybillaoi.IncSgsTaskFlowNew;
import com.sf.gis.java.sds.service.EdcsWaybillContentSwsKafkaService;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

public class OperationWaybillDataTestApp {
    private static final Logger logger = LoggerFactory.getLogger(OperationWaybillDataTestApp.class);

    public static void main(String[] args) {

        String date = args[0];
        logger.error("date:{}", date);

        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("OperationWaybillDataTestApp");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        EdcsWaybillContentSwsKafkaService service = new EdcsWaybillContentSwsKafkaService();

//        JavaRDD<ShivaOmsCoreOperationWaybillKafka> rdd = service.loadOperationWaybillData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("rdd cnt:{}", rdd.count());

//        JavaRDD<IncSgsTaskFlowNew> rdd = service.loadIncSgsTaskFlowSjData(spark, sc, "20220928").persist(StorageLevel.MEMORY_AND_DISK_SER());

        JavaRDD<TtAppointAdditionKafka> rdd = service.loadTtAppointAdditionKafka(sparkInfo, "20220928").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<TtAppointAdditionKafka> ttAppointAdditionXyRdd = rdd.map(o -> {
            String express_info_list = o.getExpress_info_list();
            try {
                if (StringUtils.isNotEmpty(express_info_list)) {
                    JSONArray jsonArray = JSON.parseArray(express_info_list);
                    if (jsonArray != null && jsonArray.size() > 0) {
                        JSONObject jsonObject = jsonArray.getJSONObject(0);
                        String longitude = jsonObject.getJSONObject("originateInfo").getJSONObject("addressInfo").getString("longitude");
                        String latitude = jsonObject.getJSONObject("originateInfo").getJSONObject("addressInfo").getString("latitude");
                        o.setLongitude(longitude);
                        o.setLatitude(latitude);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return o;
        }).filter(o -> StringUtils.isNotEmpty(o.getLongitude()) && StringUtils.isNotEmpty(o.getLatitude())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ttAppointAdditionXyRdd cnt:{}", ttAppointAdditionXyRdd.count());
        rdd.unpersist();

//        JavaRDD<ShivaOmsCoreOperationWaybillKafka> resultRdd = rdd.map(o -> {
//            String operation_waybill_fee_list = o.getOperation_waybill_fee_list();
//            if (StringUtils.isNotEmpty(operation_waybill_fee_list)) {
//                JSONArray jsonArray = JSON.parseArray(operation_waybill_fee_list);
//                if (jsonArray != null && jsonArray.size() > 0) {
//                    for (int i = 0; i < jsonArray.size(); i++) {
//                        JSONObject jsonObject = jsonArray.getJSONObject(i);
//                        String settlementTypeCode = jsonObject.getString("settlementTypeCode");
//                        if (StringUtils.equals(settlementTypeCode, "2")) {
//                            String customerAcctCode = jsonObject.getString("customerAcctCode");
//                            o.setCustomer_acct_code(customerAcctCode);
//                            break;
//                        }
//                    }
//                }
//            }
//
//            String operation_waybill_addition_list = o.getOperation_waybill_addition_list();
//            if (StringUtils.isNotEmpty(operation_waybill_addition_list)) {
//                JSONArray jsonArray = JSON.parseArray(operation_waybill_addition_list);
//                if (jsonArray != null && jsonArray.size() > 0) {
//                    for (int i = 0; i < jsonArray.size(); i++) {
//                        JSONObject jsonObject = jsonArray.getJSONObject(i);
//                        String additionalKey = jsonObject.getString("additionalKey");
//                        if (StringUtils.equals(additionalKey, "SOURCE_WAYBILL_NO")) {
//                            String source_waybill_no = jsonObject.getString("additionalValues");
//                            o.setSource_waybill_no(source_waybill_no);
//                            break;
//                        }
//                    }
//                }
//            }
//            return o;
//        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("resultRdd cnt:{}", resultRdd.count());
//        rdd.unpersist();

        service.saveSgsSjData(spark, ttAppointAdditionXyRdd, "dm_gis.tt_appoint_addition_kafka_test", "20220928");
        ttAppointAdditionXyRdd.unpersist();

    }
}
