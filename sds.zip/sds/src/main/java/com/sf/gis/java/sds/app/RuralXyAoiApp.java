package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.controller.RuralXyAoiController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 乡村驿站坐标转化为AOI应用
 * @author 01370539 Created On: May.07 2021
 * 离线任务ID：324639
 */
public class RuralXyAoiApp {
    private static final Logger logger = LoggerFactory.getLogger(RuralXyAoiApp.class);

    public static void main(String[] args) {
        String statDate;
        if (args != null && args.length >= 1) {
            statDate = args[0];
        } else {
            String curDate = DateUtil.getCurrentDate(FixedConstant.DATE_FORMATE_INCDAY);
            statDate = DateUtil.getDayBefore(curDate, FixedConstant.DATE_FORMATE_INCDAY, 1);
        }

        if (!statDate.matches("20\\d{6}")) {
            logger.error("date format must be yyyyMMdd, statDate - {}", statDate);
            System.exit(0);
        }
        new RuralXyAoiController().process(statDate);
    }
}
