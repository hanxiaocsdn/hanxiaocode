package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CmsAddress implements Serializable {
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "address_md5")
    private String address_md5;
    @Column(name = "address")
    private String address;
    @Column(name = "keyword")
    private String keyword;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "receipt_zno_code")
    private String receipt_zno_code;
    @Column(name = "x")
    private String x;
    @Column(name = "y")
    private String y;
    @Column(name = "type")
    private String type;
    @Column(name = "delivery_type")
    private String delivery_type;
    @Column(name = "status")
    private String status;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "src")
    private String src;

    @Column(name = "aoi_code")
    private String aoi_code;
    @Column(name = "aoi_name")
    private String aoi_name;
    @Column(name = "fa_type")
    private String fa_type;
    @Column(name = "aoi_area_code")
    private String aoi_area_code;

    @Column(name = "group_alias")
    private String group_alias;
    @Column(name = "group_type")
    private String group_type;
    @Column(name = "group_name")
    private String group_name;
    @Column(name = "group_adcode")
    private String group_adcode;

    @Column(name = "address_split_info")
    private String address_split_info;
    @Column(name = "key_split_info")
    private String key_split_info;

    @Column(name = "max_split_addr")
    private String max_split_addr;
    @Column(name = "max_split_key")
    private String max_split_key;

    @Column(name = "key_14")
    private String key_14;
    @Column(name = "key_cnt13")
    private String key_cnt13;
    @Column(name = "key_deny14")
    private String key_deny14;
    @Column(name = "key_deny14_t")
    private String key_deny14_t;

    @Column(name = "address_new")
    private String address_new;
    @Column(name = "key_new")
    private String key_new;

    @Column(name = "address_new_sp")
    private String address_new_sp;
    @Column(name = "key_new_sp")
    private String key_new_sp;
    @Column(name = "key_deny14_t_sp")
    private String key_deny14_t_sp;

    @Column(name = "address_new_qp")
    private String address_new_qp;
    @Column(name = "key_new_qp")
    private String key_new_qp;
    @Column(name = "key_deny14_t_qp")
    private String key_deny14_t_qp;

    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "city_code")
    private String city_code;

    private String tag;
    private String city;
    private double similar;
    private double distance_xy;
    private double distance_aoi;

    private String province;
    private String county;
    private String town;

    @Column(name = "finalprovince")
    private String finalprovince;
    @Column(name = "finalcity")
    private String finalcity;
    @Column(name = "finalcounty")
    private String finalcounty;

    @Column(name = "l5_norm")
    private String l5_norm;
    @Column(name = "freq5_norm")
    private String freq5_norm;

    private String adcode;
    private String del_flag;
    private String extend_attach1;
    private String lock_status;

    public String getLock_status() {
        return lock_status;
    }

    public void setLock_status(String lock_status) {
        this.lock_status = lock_status;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getDel_flag() {
        return del_flag;
    }

    public void setDel_flag(String del_flag) {
        this.del_flag = del_flag;
    }

    public String getExtend_attach1() {
        return extend_attach1;
    }

    public void setExtend_attach1(String extend_attach1) {
        this.extend_attach1 = extend_attach1;
    }

    public String getL5_norm() {
        return l5_norm;
    }

    public void setL5_norm(String l5_norm) {
        this.l5_norm = l5_norm;
    }

    public String getFreq5_norm() {
        return freq5_norm;
    }

    public void setFreq5_norm(String freq5_norm) {
        this.freq5_norm = freq5_norm;
    }

    public String getFinalprovince() {
        return finalprovince;
    }

    public void setFinalprovince(String finalprovince) {
        this.finalprovince = finalprovince;
    }

    public String getFinalcounty() {
        return finalcounty;
    }

    public void setFinalcounty(String finalcounty) {
        this.finalcounty = finalcounty;
    }

    public String getFinalcity() {
        return finalcity;
    }

    public void setFinalcity(String finalcity) {
        this.finalcity = finalcity;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public double getDistance_aoi() {
        return distance_aoi;
    }

    public void setDistance_aoi(double distance_aoi) {
        this.distance_aoi = distance_aoi;
    }

    public double getDistance_xy() {
        return distance_xy;
    }

    public void setDistance_xy(double distance_xy) {
        this.distance_xy = distance_xy;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getAddress_new_qp() {
        return address_new_qp;
    }

    public void setAddress_new_qp(String address_new_qp) {
        this.address_new_qp = address_new_qp;
    }

    public String getKey_new_qp() {
        return key_new_qp;
    }

    public void setKey_new_qp(String key_new_qp) {
        this.key_new_qp = key_new_qp;
    }

    public String getKey_deny14_t_qp() {
        return key_deny14_t_qp;
    }

    public void setKey_deny14_t_qp(String key_deny14_t_qp) {
        this.key_deny14_t_qp = key_deny14_t_qp;
    }

    public double getSimilar() {
        return similar;
    }

    public void setSimilar(double similar) {
        this.similar = similar;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getAddress_new_sp() {
        return address_new_sp;
    }

    public void setAddress_new_sp(String address_new_sp) {
        this.address_new_sp = address_new_sp;
    }

    public String getKey_new_sp() {
        return key_new_sp;
    }

    public void setKey_new_sp(String key_new_sp) {
        this.key_new_sp = key_new_sp;
    }

    public String getKey_deny14_t_sp() {
        return key_deny14_t_sp;
    }

    public void setKey_deny14_t_sp(String key_deny14_t_sp) {
        this.key_deny14_t_sp = key_deny14_t_sp;
    }

    public String getAddress_new() {
        return address_new;
    }

    public void setAddress_new(String address_new) {
        this.address_new = address_new;
    }

    public String getKey_new() {
        return key_new;
    }

    public void setKey_new(String key_new) {
        this.key_new = key_new;
    }

    public String getKey_deny14_t() {
        return key_deny14_t;
    }

    public void setKey_deny14_t(String key_deny14_t) {
        this.key_deny14_t = key_deny14_t;
    }

    public String getKey_deny14() {
        return key_deny14;
    }

    public void setKey_deny14(String key_deny14) {
        this.key_deny14 = key_deny14;
    }

    public String getKey_cnt13() {
        return key_cnt13;
    }

    public void setKey_cnt13(String key_cnt13) {
        this.key_cnt13 = key_cnt13;
    }

    public String getKey_14() {
        return key_14;
    }

    public void setKey_14(String key_14) {
        this.key_14 = key_14;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getMax_split_addr() {
        return max_split_addr;
    }

    public void setMax_split_addr(String max_split_addr) {
        this.max_split_addr = max_split_addr;
    }

    public String getMax_split_key() {
        return max_split_key;
    }

    public void setMax_split_key(String max_split_key) {
        this.max_split_key = max_split_key;
    }

    public String getAddress_split_info() {
        return address_split_info;
    }

    public void setAddress_split_info(String address_split_info) {
        this.address_split_info = address_split_info;
    }

    public String getKey_split_info() {
        return key_split_info;
    }

    public void setKey_split_info(String key_split_info) {
        this.key_split_info = key_split_info;
    }

    public String getGroup_alias() {
        return group_alias;
    }

    public void setGroup_alias(String group_alias) {
        this.group_alias = group_alias;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getGroup_adcode() {
        return group_adcode;
    }

    public void setGroup_adcode(String group_adcode) {
        this.group_adcode = group_adcode;
    }

    public String getGroup_type() {
        return group_type;
    }

    public void setGroup_type(String group_type) {
        this.group_type = group_type;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getFa_type() {
        return fa_type;
    }

    public void setFa_type(String fa_type) {
        this.fa_type = fa_type;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getAddress_md5() {
        return address_md5;
    }

    public void setAddress_md5(String address_md5) {
        this.address_md5 = address_md5;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getReceipt_zno_code() {
        return receipt_zno_code;
    }

    public void setReceipt_zno_code(String receipt_zno_code) {
        this.receipt_zno_code = receipt_zno_code;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDelivery_type() {
        return delivery_type;
    }

    public void setDelivery_type(String delivery_type) {
        this.delivery_type = delivery_type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }
}
