package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class OperationBottomcorrected implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "gj_aoiid_t")
    private String gj_aoiid_t;
    @Column(name = "finalaoicode")
    private String finalaoicode;
    @Column(name = "bottomcorrected")
    private String bottomcorrected;
    @Column(name = "inc_day")
    private String inc_day;
    private String month;

    @Column(name = "tag1")
    private String tag1;
    @Column(name = "tag2")
    private String tag2;
    @Column(name = "tag3")
    private String tag3;

    private String std_address;
    private String keyword;
    private String aoiId;
    private String adcode;
    private String znoCode;

    private String gd_name;
    private String gd_address;
    private String location;

    private String gdaoi_id;
    private String gdaoi_name;
    private String gdaoi_zc;

    private String cms_aoiname;
    private boolean flag;
    private boolean checkFlag;

    private String content;

    private String address_count;
    private String address_count_monthly;
    private String address_count_zc;

    public String getAddress_count_zc() {
        return address_count_zc;
    }

    public void setAddress_count_zc(String address_count_zc) {
        this.address_count_zc = address_count_zc;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getAddress_count() {
        return address_count;
    }

    public void setAddress_count(String address_count) {
        this.address_count = address_count;
    }

    public String getAddress_count_monthly() {
        return address_count_monthly;
    }

    public void setAddress_count_monthly(String address_count_monthly) {
        this.address_count_monthly = address_count_monthly;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getFinalaoicode() {
        return finalaoicode;
    }

    public void setFinalaoicode(String finalaoicode) {
        this.finalaoicode = finalaoicode;
    }

    public String getBottomcorrected() {
        return bottomcorrected;
    }

    public void setBottomcorrected(String bottomcorrected) {
        this.bottomcorrected = bottomcorrected;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public boolean isCheckFlag() {
        return checkFlag;
    }

    public void setCheckFlag(boolean checkFlag) {
        this.checkFlag = checkFlag;
    }

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getCms_aoiname() {
        return cms_aoiname;
    }

    public void setCms_aoiname(String cms_aoiname) {
        this.cms_aoiname = cms_aoiname;
    }

    public String getGdaoi_id() {
        return gdaoi_id;
    }

    public void setGdaoi_id(String gdaoi_id) {
        this.gdaoi_id = gdaoi_id;
    }

    public String getGdaoi_name() {
        return gdaoi_name;
    }

    public void setGdaoi_name(String gdaoi_name) {
        this.gdaoi_name = gdaoi_name;
    }

    public String getGdaoi_zc() {
        return gdaoi_zc;
    }

    public void setGdaoi_zc(String gdaoi_zc) {
        this.gdaoi_zc = gdaoi_zc;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getGd_name() {
        return gd_name;
    }

    public void setGd_name(String gd_name) {
        this.gd_name = gd_name;
    }

    public String getGd_address() {
        return gd_address;
    }

    public void setGd_address(String gd_address) {
        this.gd_address = gd_address;
    }

    public String getStd_address() {
        return std_address;
    }

    public void setStd_address(String std_address) {
        this.std_address = std_address;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getZnoCode() {
        return znoCode;
    }

    public void setZnoCode(String znoCode) {
        this.znoCode = znoCode;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getGj_aoiid_t() {
        return gj_aoiid_t;
    }

    public void setGj_aoiid_t(String gj_aoiid_t) {
        this.gj_aoiid_t = gj_aoiid_t;
    }
}
