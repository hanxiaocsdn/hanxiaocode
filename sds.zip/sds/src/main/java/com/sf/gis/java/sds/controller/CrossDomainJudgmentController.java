package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiAreaAoi;
import com.sf.gis.java.sds.pojo.ApplicationNocallPickCrossRegional;
import com.sf.gis.java.sds.pojo.CmsAoiSch;
import com.sf.gis.java.sds.service.CrossDomainJudgmentService;
import com.sf.gis.java.sds.utils.Utils;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class CrossDomainJudgmentController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(CrossDomainJudgmentController.class);
    CrossDomainJudgmentService service = new CrossDomainJudgmentService();
    // ak每分钟限速 / 并发数
    private static int limitMin = 30000 / 200;

    public void start(String startDate, String endDate) {
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        Broadcast<String> coorAoiUrlBc = sc.broadcast("http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&ak=70130f4193624a56beef2ffa821d0fd0&opt=aoi");
        Broadcast<String> coorAoiDistUrlBc = sc.broadcast("http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiDist?x=%s&y=%s&aoiId=%s&type=side");
        Broadcast<String> coorAoiAreaDistUrlBc = sc.broadcast("http://sds-core-datarun.sf-express.com/datarun/aoi/getCoorAoiAreaDist?x=%s&y=%s&areaCode=%s");

        logger.error("获取aoi_code与aoi_area_code映射关系");
        JavaRDD<AoiAreaAoi> aoiAreaAoiRdd = service.loadAoiAreaAoi(spark, sc).map(o -> {
            String aoi_area_code = o.getAoi_area_code();
            if (StringUtils.isNotEmpty(aoi_area_code)) {
                String zonecode = aoi_area_code.substring(0, aoi_area_code.length() - 3);
                o.setZonecode(zonecode);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiAreaAoiRdd cnt:{}", aoiAreaAoiRdd.count());
        aoiAreaAoiRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("获取aoi_code和aoi_id映射关系");
        JavaRDD<CmsAoiSch> cmsAoiSchRdd = service.loadCmsAoiSch(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());
        cmsAoiSchRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (int j = dates.size() - 1; j >= 0; j--) {
            String date = dates.get(j);
            logger.error("date:{}", date);
            logger.error("获取小哥是否跨域揽收数据源");
            JavaRDD<ApplicationNocallPickCrossRegional> applicationNocallPickCrossRegionalRdd = service.loadData(spark, sc, date).map(o -> {
                String aoi_group = o.getAoi_group();
                if (StringUtils.isNotEmpty(aoi_group)) {
                    o.setAoi_group(aoi_group.replaceAll("^(,)|(,)$", ""));
                }
                return o;
            }).repartition(1000).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("applicationNocallPickCrossRegionalRdd cnt:{}", applicationNocallPickCrossRegionalRdd.count());
//            applicationNocallPickCrossRegionalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            logger.error("获取已跑出aoiid数据");
            JavaRDD<ApplicationNocallPickCrossRegional> crossDomainJudgeRdd = service.loadCrossDomainJudgeData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("crossDomainJudgeRdd cnt:{}", crossDomainJudgeRdd.count());
//            crossDomainJudgeRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            logger.error("从源数据中剔除已经跑出aoiid的数据");
            JavaRDD<ApplicationNocallPickCrossRegional> afterFilterRdd = applicationNocallPickCrossRegionalRdd.mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getTime(), o.getSrc_order_no(), o.getInner_order_no(), o.getWaybill_no(), o.getZonecode()}, "_"), o))
                    .leftOuterJoin(crossDomainJudgeRdd.mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getTime(), o.getSrc_order_no(), o.getInner_order_no(), o.getWaybill_no(), o.getZonecode()}, "_"), o)))
                    .filter(tp -> {
                        boolean flag = true;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            flag = false;
                        }
                        return flag;
                    }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("afterFilterRdd cnt:{}", afterFilterRdd.count());
//            afterFilterRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            applicationNocallPickCrossRegionalRdd.unpersist();
            crossDomainJudgeRdd.unpersist();


            logger.error("根据x,y跑出aoi");
            JavaRDD<ApplicationNocallPickCrossRegional> coorAoiRdd = afterFilterRdd.mapPartitionsWithIndex(((index, iter) -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<ApplicationNocallPickCrossRegional> list = new ArrayList<>();
                while (iter.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMin) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("分区:{},每分钟访问量超过限制:{},休眠:{}ms中", index, limitMin, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    ApplicationNocallPickCrossRegional o = iter.next();
                    String x = o.getEventlng();
                    String y = o.getEventlat();
                    if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                        String content = service.runAoi(coorAoiUrlBc.value(), x, y, acLimitCodeSetBc.value());
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = JSON.parseObject(content);
                            int status = jsonObject.getInteger("status");
                            if (status == 0) {
                                JSONObject result = jsonObject.getJSONObject("result");
                                JSONObject aoi_data = result.getJSONArray("aoi_data").getJSONObject(0);
                                String aoi_id = aoi_data.getString("aoi_id");
                                String aoi_code = aoi_data.getString("aoi_code");
                                String aoi_zc = aoi_data.getString("aoi_zc");
                                logger.error("aoi_id:{}", aoi_id);
                                o.setCoor_aoi(aoi_id);
                                o.setCoor_aoi_code(aoi_code);
                                o.setCoor_zno_code(aoi_zc);
                            }
                        }
                    }
                    list.add(o);
                }
                return list.iterator();
            }), false).filter(o -> StringUtils.isNotEmpty(o.getCoor_aoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("coorAoiRdd cnt:{}", coorAoiRdd.count());
//            coorAoiRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            afterFilterRdd.unpersist();

            logger.error("揽收经纬度所在AOI是否在源表小哥AOI区域aoi_group里（是/否）");
            JavaRDD<ApplicationNocallPickCrossRegional> coorAoiInAoiGroupFlagRdd = coorAoiRdd.map(o -> {
                String coor_aoi_code = o.getCoor_aoi_code();
                String aoi_group = o.getAoi_group();
                if (StringUtils.isNotEmpty(aoi_group) && StringUtils.isNotEmpty(coor_aoi_code) && aoi_group.contains(coor_aoi_code)) {
                    o.setCoor_aoi_group("1");
                } else {
                    o.setCoor_aoi_group("0");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("coorAoiInAoiGroupFlagRdd cnt:{}", coorAoiInAoiGroupFlagRdd.count());
//            coorAoiInAoiGroupFlagRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            coorAoiRdd.unpersist();

            logger.error("揽收经纬度与小哥AOI区域aoi_group的距离");
            JavaRDD<ApplicationNocallPickCrossRegional> aoiCodeRdd = coorAoiInAoiGroupFlagRdd.flatMap(o -> {
                List<ApplicationNocallPickCrossRegional> list = new ArrayList<>();
                String aoi_group = o.getAoi_group();
                if (StringUtils.isNotEmpty(aoi_group)) {
                    String[] split = aoi_group.split(",");
                    for (String s : split) {
                        ApplicationNocallPickCrossRegional anpcr = new ApplicationNocallPickCrossRegional();
                        BeanUtils.copyProperties(anpcr, o);
                        anpcr.setAoi_code(s);
                        list.add(anpcr);
                    }
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiCodeRdd cnt:{}", aoiCodeRdd.count());
//            aoiCodeRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            coorAoiInAoiGroupFlagRdd.unpersist();

            JavaRDD<ApplicationNocallPickCrossRegional> aoiIdRdd = aoiCodeRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o)).leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
                ApplicationNocallPickCrossRegional applicationNocallPickCrossRegional = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    CmsAoiSch cmsAoiSch = tp._2._2.get();
                    applicationNocallPickCrossRegional.setAoi_id(cmsAoiSch.getAoi_id());
                }
                return applicationNocallPickCrossRegional;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiIdRdd cnt:{}", aoiIdRdd.count());
//            aoiIdRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            aoiCodeRdd.unpersist();

            JavaRDD<ApplicationNocallPickCrossRegional> aoiIdGroupRdd = aoiIdRdd.mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getEventlng(), o.getEventlat(), o.getZonecode(), o.getAoi_group()}, "_"), o))
                    .groupByKey().map(tp -> {
                        List<ApplicationNocallPickCrossRegional> list = Lists.newArrayList(tp._2);
                        ApplicationNocallPickCrossRegional o = list.get(0);
                        String aoi_id_group = "";
                        for (ApplicationNocallPickCrossRegional applicationNocallPickCrossRegional : list) {
                            String aoi_id = applicationNocallPickCrossRegional.getAoi_id();
                            if (StringUtils.isNotEmpty(aoi_id)) {
                                aoi_id_group = aoi_id_group.concat(aoi_id).concat(",");
                            }
                        }
                        o.setAoi_id_group(aoi_id_group.replaceAll("(,)$", ""));
                        return o;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiIdGroupRdd cnt:{}", aoiIdGroupRdd.count());
//            aoiIdGroupRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            aoiIdRdd.unpersist();

            JavaRDD<ApplicationNocallPickCrossRegional> coorAreaDistRdd = aoiIdGroupRdd.map(o -> {
                String x = o.getEventlng();
                String y = o.getEventlat();
                String aoi_id_group = o.getAoi_id_group();
                String[] split = aoi_id_group.split(",");
                int i = 0;
                double coor_area_dist = 0;
                for (String s : split) {
                    String req = String.format(coorAoiDistUrlBc.value(), x, y, s);
                    logger.error("req:{}", req);
                    String content = Utils.retryGet(req);
                    logger.error("content:{}", content);
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null) {
                            if (jsonObject.getBoolean("success")) {
                                if (content.contains("data")) {
                                    i = i + 1;
                                    double data = jsonObject.getDouble("data");
                                    logger.error("aoi dist:{}", data);
                                    if (i == 1) {
                                        coor_area_dist = data;
                                    } else if (data < coor_area_dist) {
                                        coor_area_dist = data;
                                    }
                                }
                            }
                        }
                    }
                }
                o.setCoor_area_dist(coor_area_dist + "");
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("coorAreaDistRdd cnt:{}", coorAreaDistRdd.count());
//            coorAreaDistRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            aoiIdGroupRdd.unpersist();

            logger.error("揽收经纬度与小哥网点边界的距离");
            JavaRDD<ApplicationNocallPickCrossRegional> equalCoorZnoDistRdd = coorAreaDistRdd.map(o -> {
                String coor_zno_code = o.getCoor_zno_code();
                String zonecode = o.getZonecode();
                if (StringUtils.isNotEmpty(coor_zno_code) && StringUtils.isNotEmpty(zonecode) && (StringUtils.equals(coor_zno_code, zonecode) || coor_zno_code.contains(zonecode) || zonecode.contains(coor_zno_code))) {
                    o.setCoor_zno_dist("0");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("equalCoorZnoDistRdd cnt:{}", equalCoorZnoDistRdd.count());
//            equalCoorZnoDistRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            coorAreaDistRdd.unpersist();


            JavaRDD<ApplicationNocallPickCrossRegional> equalCoorZnoDistRdd1 = equalCoorZnoDistRdd.filter(o -> StringUtils.equals(o.getCoor_zno_dist(), "0")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("equalCoorZnoDistRdd1 cnt:{}", equalCoorZnoDistRdd1.count());
//            equalCoorZnoDistRdd1.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<ApplicationNocallPickCrossRegional> aoiAreaCodeRdd = equalCoorZnoDistRdd.filter(o -> !StringUtils.equals(o.getCoor_zno_dist(), "0")).mapToPair(o -> new Tuple2<>(o.getCoor_zno_code(), o))
                    .leftOuterJoin(aoiAreaAoiRdd.mapToPair(o -> new Tuple2<>(o.getZonecode(), o)).groupByKey()).map(tp -> {
                        ApplicationNocallPickCrossRegional applicationNocallPickCrossRegional = tp._2._1;
                        if (tp._2._2 != null && tp._2._2.isPresent()) {
                            List<AoiAreaAoi> aoiAreaAoisList = Lists.newArrayList(tp._2._2.get()).stream()
                                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(AoiAreaAoi::getZonecode))), ArrayList::new));
                            String aoi_area_code_list = "";
                            for (AoiAreaAoi aoiAreaAoi : aoiAreaAoisList) {
                                aoi_area_code_list = aoi_area_code_list.concat(aoiAreaAoi.getAoi_area_code()).concat(",");
                            }
                            applicationNocallPickCrossRegional.setAoi_area_code_list(aoi_area_code_list.replaceAll("(,)$", ""));
                        }
                        return applicationNocallPickCrossRegional;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiAreaCodeRdd cnt:{}", aoiAreaCodeRdd.count());
//            aoiAreaCodeRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            equalCoorZnoDistRdd.unpersist();

            JavaRDD<ApplicationNocallPickCrossRegional> equalCoorZnoDistRdd2 = aoiAreaCodeRdd.repartition(1000).map(o -> {
                String aoi_area_code_list = o.getAoi_area_code_list();
                if (StringUtils.isNotEmpty(aoi_area_code_list)) {
                    String[] split = aoi_area_code_list.split(",");
                    String x = o.getEventlng();
                    String y = o.getEventlat();
                    int i = 0;
                    double coor_zno_dist = 0;
                    for (String s : split) {
                        String req = String.format(coorAoiAreaDistUrlBc.value(), x, y, s);
                        logger.error("req:{}", req);
                        String content = Utils.retryGet(req);
                        logger.error("content:{}", content);
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = JSON.parseObject(content);
                            if (jsonObject != null) {
                                if (content.contains("data")) {
                                    i = i + 1;
                                    double data = jsonObject.getDouble("data");
                                    logger.error("aera dist:{}", data);
                                    if (i == 1) {
                                        coor_zno_dist = data;
                                    } else if (data < coor_zno_dist) {
                                        coor_zno_dist = data;
                                    }
                                }
                            }
                        }
                    }
                    o.setCoor_zno_dist(coor_zno_dist + "");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("equalCoorZnoDistRdd2 cnt:{}", equalCoorZnoDistRdd2.count());
//            equalCoorZnoDistRdd2.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            aoiAreaCodeRdd.unpersist();

            JavaRDD<ApplicationNocallPickCrossRegional> finalRdd = equalCoorZnoDistRdd1.union(equalCoorZnoDistRdd2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalRdd cnt:{}", finalRdd.count());
            finalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            equalCoorZnoDistRdd1.unpersist();
            equalCoorZnoDistRdd2.unpersist();

//            String executeSql = String.format("alter table dm_gis.cross_domain_judge drop if EXISTS partition( inc_day='%s' )", date);
//            logger.error("executeSql :{}", executeSql);
//            spark.sql(executeSql);
            logger.error("数据入库");
            service.saveData(spark, finalRdd, date);
            finalRdd.unpersist();
        }

        cmsAoiSchRdd.unpersist();
        aoiAreaAoiRdd.unpersist();
        spark.stop();
    }

    public static void main(String[] args) {
        System.out.println(Double.parseDouble(3 + "") / Double.parseDouble(5 + ""));
    }
}
