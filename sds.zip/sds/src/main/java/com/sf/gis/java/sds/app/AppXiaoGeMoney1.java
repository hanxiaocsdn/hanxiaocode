package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.AppXiaoGeMoneyController1;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id：399878（丰源小哥计提2）
 * 业务方：李嘉欣
 * 研发：01399581（匡仁衡）
 */
public class AppXiaoGeMoney1 {
    private static Logger logger = LoggerFactory.getLogger(AppXiaoGeMoney1.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        String loadDate = args[2];
        String today = args[3];
        logger.error("startDate:{}", startDate);
        logger.error("endDate:{}", endDate);
        logger.error("loadDate:{}", loadDate);
        logger.error("today:{}", today);
        new AppXiaoGeMoneyController1().start(startDate, endDate, loadDate, today);
        logger.error("process end");
    }
}
