package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TtWayBillHook implements Serializable {

    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "dest_zone_code")
    private String dest_zone_code;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "signin_tm")
    private String signin_tm;

    @Column(name = "dest_lgt")
    private String dest_lgt;
    @Column(name = "dest_lat")
    private String dest_lat;
    @Column(name = "inc_day")
    private String inc_day;

    @Column(name = "waybill_tag")
    private String waybill_tag;

    private String groupId;
    private String aoiId;
    private String floor;
    private String stdAddr;
    private String splitResult;
    private String is_groupid_elevator;
    private String is_aoiid_elevator;
    private String group_source;
    private String aoi_source;

    private String aoiType;
    private String aoi_2Type;

    private String elevator_cnt;
    private String tag1;
    private String tag2;
    private String tag3;
    private String tag4;
    private String tag5;
    private String tag6;

    private String last14;
    private String last15;
    private String process_address;
    private String maxSplit;
    private String src_tag;

    private String group_id_2;
    private String aoi_id_2;
    private String floor_2;
    private String norm_address_2;
    private String norm_addr_split;
    private String group2_freq;
    private String aoi2_freq;

    public String getWaybill_tag() {
        return waybill_tag;
    }

    public void setWaybill_tag(String waybill_tag) {
        this.waybill_tag = waybill_tag;
    }

    public String getDest_lgt() {
        return dest_lgt;
    }

    public void setDest_lgt(String dest_lgt) {
        this.dest_lgt = dest_lgt;
    }

    public String getDest_lat() {
        return dest_lat;
    }

    public void setDest_lat(String dest_lat) {
        this.dest_lat = dest_lat;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getAoi_2Type() {
        return aoi_2Type;
    }

    public void setAoi_2Type(String aoi_2Type) {
        this.aoi_2Type = aoi_2Type;
    }

    public String getAoi2_freq() {
        return aoi2_freq;
    }

    public void setAoi2_freq(String aoi2_freq) {
        this.aoi2_freq = aoi2_freq;
    }

    public String getSplitResult() {
        return splitResult;
    }

    public void setSplitResult(String splitResult) {
        this.splitResult = splitResult;
    }

    public String getSrc_tag() {
        return src_tag;
    }

    public void setSrc_tag(String src_tag) {
        this.src_tag = src_tag;
    }

    public String getMaxSplit() {
        return maxSplit;
    }

    public void setMaxSplit(String maxSplit) {
        this.maxSplit = maxSplit;
    }

    public String getGroup2_freq() {
        return group2_freq;
    }

    public void setGroup2_freq(String group2_freq) {
        this.group2_freq = group2_freq;
    }

    public String getGroup_id_2() {
        return group_id_2;
    }

    public void setGroup_id_2(String group_id_2) {
        this.group_id_2 = group_id_2;
    }

    public String getAoi_id_2() {
        return aoi_id_2;
    }

    public void setAoi_id_2(String aoi_id_2) {
        this.aoi_id_2 = aoi_id_2;
    }

    public String getFloor_2() {
        return floor_2;
    }

    public void setFloor_2(String floor_2) {
        this.floor_2 = floor_2;
    }

    public String getNorm_address_2() {
        return norm_address_2;
    }

    public void setNorm_address_2(String norm_address_2) {
        this.norm_address_2 = norm_address_2;
    }

    public String getTag4() {
        return tag4;
    }

    public void setTag4(String tag4) {
        this.tag4 = tag4;
    }

    public String getTag5() {
        return tag5;
    }

    public void setTag5(String tag5) {
        this.tag5 = tag5;
    }

    public String getTag6() {
        return tag6;
    }

    public void setTag6(String tag6) {
        this.tag6 = tag6;
    }

    public String getProcess_address() {
        return process_address;
    }

    public void setProcess_address(String process_address) {
        this.process_address = process_address;
    }

    public String getLast14() {
        return last14;
    }

    public void setLast14(String last14) {
        this.last14 = last14;
    }

    public String getLast15() {
        return last15;
    }

    public void setLast15(String last15) {
        this.last15 = last15;
    }

    public String getNorm_addr_split() {
        return norm_addr_split;
    }

    public void setNorm_addr_split(String norm_addr_split) {
        this.norm_addr_split = norm_addr_split;
    }

    public String getTag1() {
        return tag1;
    }

    public void setTag1(String tag1) {
        this.tag1 = tag1;
    }

    public String getTag2() {
        return tag2;
    }

    public void setTag2(String tag2) {
        this.tag2 = tag2;
    }

    public String getTag3() {
        return tag3;
    }

    public void setTag3(String tag3) {
        this.tag3 = tag3;
    }

    public String getSignin_tm() {
        return signin_tm;
    }

    public void setSignin_tm(String signin_tm) {
        this.signin_tm = signin_tm;
    }

    public String getElevator_cnt() {
        return elevator_cnt;
    }

    public void setElevator_cnt(String elevator_cnt) {
        this.elevator_cnt = elevator_cnt;
    }

    public String getIs_groupid_elevator() {
        return is_groupid_elevator;
    }

    public void setIs_groupid_elevator(String is_groupid_elevator) {
        this.is_groupid_elevator = is_groupid_elevator;
    }

    public String getIs_aoiid_elevator() {
        return is_aoiid_elevator;
    }

    public void setIs_aoiid_elevator(String is_aoiid_elevator) {
        this.is_aoiid_elevator = is_aoiid_elevator;
    }

    public String getAoiType() {
        return aoiType;
    }

    public void setAoiType(String aoiType) {
        this.aoiType = aoiType;
    }

    public String getGroup_source() {
        return group_source;
    }

    public void setGroup_source(String group_source) {
        this.group_source = group_source;
    }

    public String getAoi_source() {
        return aoi_source;
    }

    public void setAoi_source(String aoi_source) {
        this.aoi_source = aoi_source;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getStdAddr() {
        return stdAddr;
    }

    public void setStdAddr(String stdAddr) {
        this.stdAddr = stdAddr;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getDest_zone_code() {
        return dest_zone_code;
    }

    public void setDest_zone_code(String dest_zone_code) {
        this.dest_zone_code = dest_zone_code;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }
}
