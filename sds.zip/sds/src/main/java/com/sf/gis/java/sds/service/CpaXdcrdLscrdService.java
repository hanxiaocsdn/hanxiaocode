package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.XdLsCrd;
import org.apache.spark.api.java.JavaRDD;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 客户下单位置信息和揽收位置信息分析
 * @author 01370539
 * Created on Jun.15 2022
 * 需求人员：赵瑜婷
 */
public class CpaXdcrdLscrdService {
    private static final Logger logger = LoggerFactory.getLogger(CpaXdcrdLscrdService.class);

    public JavaRDD<XdLsCrd> loadSrcData(SparkInfo si, String startDate, String endDate, String cityCode){
        String sql = SqlUtil.getSqlStr("xdcrd_lscrd_cpa.sql", startDate, endDate, cityCode, startDate, endDate, startDate, endDate, startDate, endDate);
        return DataUtil.loadData(si, sql, XdLsCrd.class);
    }
}
