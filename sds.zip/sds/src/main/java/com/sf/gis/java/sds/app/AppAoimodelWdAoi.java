package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoimodelWdAoi;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.HashSet;


/**
 * 任务id：885798（疑似错误数据派件一期修正）
 * 业务方：01424110（喻少丰）
 * 研发：01399581（匡仁衡）
 */
public class AppAoimodelWdAoi {
    private static final Logger logger = LoggerFactory.getLogger(AppAoimodelWdAoi.class);
    private static final String getAddrByCityCodeAndAddr = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressId=%s";
    private static final String getAddrByCityCodeAndAddrMd5 = "http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressMd5=%s";
    private static final String gd = "http://gis-gaode.int.sfcloud.local:1080/optimalMatching?address=%s";
    private static final String account = "01399581";
    private static final String taskId = "885798";
    private static final String taskName = "疑似错误数据派件一期修正";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppAoimodelWdAoi");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String sql = String.format("select * from dm_gis.aoimodel_wd_aoi where inc_day = '%s' and gisaoisrc in ('norm','chkn')", date);
        JavaRDD<AoimodelWdAoi> rdd = DataUtil.loadData(spark, sc, sql, AoimodelWdAoi.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<AoimodelWdAoi> uniqueRdd = rdd.mapToPair(o -> new Tuple2<>(o.getGisaoisrc() + "_" + o.getGis_to_sys_groupid() + "_" + o.getCity_code(), o)).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueRdd cnt:{}", uniqueRdd.count());


        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getAddrByCityCodeAndAddr, "", uniqueRdd.count(), 5);
        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", getAddrByCityCodeAndAddrMd5, "", uniqueRdd.count(), 5);
        JavaRDD<AoimodelWdAoi> stdRdd = getAddrByCityCodeAndAddr(uniqueRdd);
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", stdRdd.count(), 5);
        JavaRDD<AoimodelWdAoi> gdRdd = stdRdd.map(o -> {
            String std_address = o.getStd_address();
            if (StringUtils.isNotEmpty(std_address)) {
                String req = String.format(gd, URLEncoder.encode(std_address, "UTF-8"));
                String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                o.setGd_result(content);

                HashSet<String> aoi_set = new HashSet<>();
                HashSet<String> name_set = new HashSet<>();
                try {
                    JSONArray result = JSON.parseObject(content).getJSONObject("message").getJSONArray("result");
                    if (result != null && result.size() > 0) {
                        for (int i = 0; i < result.size(); i++) {
                            JSONObject jsonObject = result.getJSONObject(i);
                            String aoiid = jsonObject.getString("aoiid");
                            String name = jsonObject.getString("name");
                            aoi_set.add(aoiid);
                            name_set.add(name);
                        }
                        int size = aoi_set.size();
                        if (size > 0) {
                            o.setGd_aoiid(String.join(",", aoi_set));
                            if (size == 1) {
                                o.setResult("1");
                            } else {
                                o.setResult("2");
                            }
                        } else {
                            o.setResult("0");
                        }
                        if (name_set.size() > 0) {
                            o.setGd_name(String.join(",", name_set));
                        }
                    }
                } catch (Exception e) {
//                    e.printStackTrace();
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdRdd cnt:{}", gdRdd.count());
        stdRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        String cms_sql = "select aoi_id,zno_code from dm_gis.cms_aoi_sch";
        JavaPairRDD<String, CmsAoiSch> cmsRdd = DataUtil.loadData(spark, sc, cms_sql, CmsAoiSch.class).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsRdd cnt:{}", cmsRdd.count());

        JavaRDD<AoimodelWdAoi> eq1Rdd = gdRdd.filter(o -> StringUtils.equals(o.getResult(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<AoimodelWdAoi> noEq1Rdd = gdRdd.filter(o -> !StringUtils.equals(o.getResult(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eq1Rdd cnt:{}, noEq1Rdd cnt:{}", eq1Rdd.count(), noEq1Rdd.count());
        gdRdd.unpersist();

        JavaRDD<AoimodelWdAoi> gdZnoCodeRdd = eq1Rdd.mapToPair(o -> new Tuple2<>(o.getGd_aoiid(), o)).leftOuterJoin(cmsRdd).map(tp -> {
            AoimodelWdAoi o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                CmsAoiSch cmsAoiSch = tp._2._2.get();
                o.setGdzno_code(cmsAoiSch.getZno_code());
            }
            return o;
        }).map(o -> {
            String std_zc = o.getStd_zc();
            String gdzno_code = o.getGdzno_code();
            if (StringUtils.isNotEmpty(std_zc) && !StringUtils.equals(std_zc, gdzno_code)) {
                o.setResult("3");
            }
            return o;
        }).map(o -> {
            String result = o.getResult();
            if (StringUtils.equals(result, "1")) {
                String gd_name = o.getGd_name();
                String std_address = o.getStd_address();
                String key_word = o.getKey_word();
                if (StringUtils.isNotEmpty(gd_name)) {
                    String name = gd_name.split(",")[0];
                    if ((StringUtils.isNotEmpty(std_address) && judgeContains(std_address, name)) || (StringUtils.isNotEmpty(key_word) && judgeContains(name, key_word))) {

                    } else {
                        o.setResult("4");
                    }
                }

            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdZnoCodeRdd cnt:{}", gdZnoCodeRdd.count());
        eq1Rdd.unpersist();
        cmsRdd.unpersist();

        JavaRDD<AoimodelWdAoi> resultRdd = noEq1Rdd.union(gdZnoCodeRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        noEq1Rdd.unpersist();
        gdZnoCodeRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.aoimodel_wd_aoi_correct", AoimodelWdAoi.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();

    }

    public static boolean judgeContains(String str1, String str2) {
        for (int i = 0; i < str2.length(); i++) {
            char c = str2.charAt(i);
            if ((c >= 48 && c <= 57) || Character.isIdeographic(c)) {
                if (!str1.contains(Character.toString(c))) {
                    return false;
                }
            }
        }

        return true;
    }

    public static JavaRDD<AoimodelWdAoi> getAddrByCityCodeAndAddr(JavaRDD<AoimodelWdAoi> uniqueRdd) {
        JavaRDD<AoimodelWdAoi> stdRdd = uniqueRdd.map(o -> {
            String gisaoisrc = o.getGisaoisrc();
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                String req = "";
                if (StringUtils.equals(gisaoisrc, "norm")) {
                    req = String.format(getAddrByCityCodeAndAddr, city_code, gis_to_sys_groupid);
                } else {
                    req = String.format(getAddrByCityCodeAndAddrMd5, city_code, gis_to_sys_groupid);
                }
                String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                String std_address = "";
                String std_aoiid = "";
                String std_zc = "";
                String adcode = "";
                String key_word = "";

                try {
                    std_address = JSON.parseObject(content).getJSONObject("data").getString("address");
                    std_aoiid = JSON.parseObject(content).getJSONObject("data").getString("aoiId");
                    std_zc = JSON.parseObject(content).getJSONObject("data").getString("znoCode");
                    adcode = JSON.parseObject(content).getJSONObject("data").getString("adcode");
                    key_word = JSON.parseObject(content).getJSONObject("data").getString("keyword");
                } catch (Exception e) {
//                    e.printStackTrace();
                }
                o.setStd_address(std_address);
                o.setStd_aoiid(std_aoiid);
                o.setStd_zc(std_zc);
                o.setAdcode(adcode);
                o.setKey_word(key_word);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdRdd cnt:{}", stdRdd.count());
        uniqueRdd.unpersist();
        return stdRdd;
    }
}
