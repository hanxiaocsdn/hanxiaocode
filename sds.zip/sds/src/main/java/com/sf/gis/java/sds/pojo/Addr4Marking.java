package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class Addr4Marking implements Serializable {

    @Column(name = "address_id")
    private String addressId;
    @Column(name = "address")
    private String address;
    @Column(name = "keyword")
    private String keyword;
    @Column(name = "zno_code")
    private String znoCode;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_name")
    private String aoiName;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "type")
    private String type;
    @Column(name = "last6")
    private String last6;
    @Column(name = "last13")
    private String last13;
    @Column(name = "last613")
    private String last613;
    @Column(name = "last14")
    private String last14;
    @Column(name = "last1361314")
    private String last1361314;
    @Column(name = "last1314")
    private String last1314;
    @Column(name = "last13613")
    private String last13613;
    @Column(name = "last6613")
    private String last6613;
    @Column(name = "last661314")
    private String last661314;
    @Column(name = "status")
    private String status;
    @Column(name = "city_code")
    private String cityCode;

    public String getAddressId() {
        return addressId;
    }

    public void setAddressId(String addressId) {
        this.addressId = addressId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getZnoCode() {
        return znoCode;
    }

    public void setZnoCode(String znoCode) {
        this.znoCode = znoCode;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiName() {
        return aoiName;
    }

    public void setAoiName(String aoiName) {
        this.aoiName = aoiName;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLast6() {
        return last6;
    }

    public void setLast6(String last6) {
        this.last6 = last6;
    }

    public String getLast13() {
        return last13;
    }

    public void setLast13(String last13) {
        this.last13 = last13;
    }

    public String getLast613() {
        return last613;
    }

    public void setLast613(String last613) {
        this.last613 = last613;
    }

    public String getLast14() {
        return last14;
    }

    public void setLast14(String last14) {
        this.last14 = last14;
    }

    public String getLast1361314() {
        return last1361314;
    }

    public void setLast1361314(String last1361314) {
        this.last1361314 = last1361314;
    }

    public String getLast1314() {
        return last1314;
    }

    public void setLast1314(String last1314) {
        this.last1314 = last1314;
    }

    public String getLast13613() {
        return last13613;
    }

    public void setLast13613(String last13613) {
        this.last13613 = last13613;
    }

    public String getLast6613() {
        return last6613;
    }

    public void setLast6613(String last6613) {
        this.last6613 = last6613;
    }

    public String getLast661314() {
        return last661314;
    }

    public void setLast661314(String last661314) {
        this.last661314 = last661314;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    @Override
    public String toString() {
        return "Addr4Marking{" +
                "addressId='" + addressId + '\'' +
                ", address='" + address + '\'' +
                ", keyword='" + keyword + '\'' +
                ", znoCode='" + znoCode + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiName='" + aoiName + '\'' +
                ", adcode='" + adcode + '\'' +
                ", type='" + type + '\'' +
                ", last6='" + last6 + '\'' +
                ", last13='" + last13 + '\'' +
                ", last613='" + last613 + '\'' +
                ", last14='" + last14 + '\'' +
                ", last1361314='" + last1361314 + '\'' +
                ", last1314='" + last1314 + '\'' +
                ", last13613='" + last13613 + '\'' +
                ", last6613='" + last6613 + '\'' +
                ", last661314='" + last661314 + '\'' +
                ", status='" + status + '\'' +
                ", cityCode='" + cityCode + '\'' +
                '}';
    }
}
