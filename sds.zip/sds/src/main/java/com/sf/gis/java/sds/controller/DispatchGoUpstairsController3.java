package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ConfigurationUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AddressInfoMapDi;
import com.sf.gis.java.sds.pojo.KyGdlPackWaybillnoMonitor;
import com.sf.gis.java.sds.pojo.TtWayBillHook;
import com.sf.gis.java.sds.service.DispatchGoUpstairsService3;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

import static com.sf.gis.java.base.util.DateUtil.getDaysBefore;

public class DispatchGoUpstairsController3 implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(DispatchGoUpstairsController3.class);
    DispatchGoUpstairsService3 service = new DispatchGoUpstairsService3();
    // ak每秒钟限速 / 并发数
    private static int limitSec = 600 / 200;

    public void start(String startDate, String endDate, String nowdate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        Broadcast<String> queryElevatorUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/elevator/api/queryElevator?address=%s&citycode=%s&ak=e4d9287738bd41569d46640454caf2e0");
        Map<String, String> map = ConfigurationUtil.loadMap("allcity3.csv", "CITYCODE", "CITY");
        Broadcast<Map<String, String>> mapBc = sc.broadcast(map);

//        Broadcast<String> regexBc = sc.broadcast(VariableConstant.configProps.getProperty("addr.replace.regex"));
        String today = nowdate;
        logger.error("today:{}", today);

        logger.error("获取地址关系映射表");
        JavaRDD<AddressInfoMapDi> addressInfoMapRdd = service.loadAddressInfoMapDiData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addressInfoMapRdd cnt:{}", addressInfoMapRdd.count());
        addressInfoMapRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("获取快运业务数据");
        JavaRDD<KyGdlPackWaybillnoMonitor> kyGdRdd = service.loadKyGdData(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("kyGdRdd cnt:{}", kyGdRdd.count());
        kyGdRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        String beforeDate = getDaysBefore(startDate, 5);
        String afterDate = getDaysBefore(endDate, -5);
        logger.error("beforeDate:{},afterDate:{}", beforeDate, afterDate);

        logger.error("获取运单数据");
        JavaRDD<TtWayBillHook> ttWayRdd = service.loadTtWayData(spark, sc, beforeDate, afterDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ttWayRdd cnt:{}", ttWayRdd.count());
        ttWayRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("快运数据关联地址");
        JavaRDD<KyGdlPackWaybillnoMonitor> kyGdAddrRdd = kyGdRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).leftOuterJoin(ttWayRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))).map(tp -> {
            KyGdlPackWaybillnoMonitor o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                TtWayBillHook ttWayBillHook = tp._2._2.get();
                o.setAddr(ttWayBillHook.getConsignee_addr());
                o.setDest_city_code(ttWayBillHook.getDest_dist_code());
                o.setDest_zone_code(ttWayBillHook.getDest_zone_code());
            }
            return o;
        }).filter(o -> StringUtils.isNotEmpty(o.getDest_city_code()) && service.hasChineseCharacter(o.getDest_city_code()))
                .mapToPair(o -> new Tuple2<>(o.getDest_city_code(), o))
                .leftOuterJoin(addressInfoMapRdd.mapToPair(o -> new Tuple2<>(o.getCitycode(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    KyGdlPackWaybillnoMonitor o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AddressInfoMapDi addressInfoMapDi = tp._2._2.get();
                        o.setProvince(addressInfoMapDi.getProvince());
                        o.setRegion(addressInfoMapDi.getRegion());
                    }
                    return o;
                })
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("kyGdAddrRdd cnt:{}", kyGdAddrRdd.count());
        kyGdAddrRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        kyGdRdd.unpersist();
        ttWayRdd.unpersist();
        addressInfoMapRdd.unpersist();

        logger.error("跑服务获取 is_elevator,is_climb,floor");
        JavaRDD<KyGdlPackWaybillnoMonitor> elevatorRdd = kyGdAddrRdd.repartition(800).mapPartitionsWithIndex(((index, iter) -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<KyGdlPackWaybillnoMonitor> list = new ArrayList<>();
            while (iter.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitSec) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 1000) {
                        logger.error("分区:{},每秒钟访问量超过限制:{},休眠:{}ms中", index, limitSec, 1000 - endTime);
                        Thread.sleep(1000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                KyGdlPackWaybillnoMonitor o = iter.next();
                String addr = o.getAddr();
                String citycode = o.getDest_city_code();
                if (StringUtils.isNotEmpty(addr)) {
                    String content = service.queryElevator(queryElevatorUrlBc.value(), addr, citycode);
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        int status = jsonObject.getInteger("status");
                        if (status == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            if (result != null) {
                                JSONObject data = result.getJSONObject("data");
                                String isElevator = data.getString("isElevator");
                                String isClimb = data.getString("isClimb");
                                String floor = data.getString("floor");
                                String data_src = data.getString("data_src");
                                String group_id = data.getString("group_id");
                                String aoi_id = data.getString("aoi_id");

                                logger.error("isElevator:{}", isElevator);
                                logger.error("isClimb:{}", isClimb);
                                logger.error("floor:{}", floor);
                                o.setIs_elevator(isElevator);
                                o.setIs_climb(isClimb);
                                o.setFloor(floor);

                                o.setData_src(data_src);
                                o.setGroup_id(group_id);
                                o.setAoi_id(aoi_id);
                            }
                        }
                    }
                }
                list.add(o);
            }
            return list.iterator();
        }), false).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("elevatorRdd cnt:{}", elevatorRdd.count());
        elevatorRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        kyGdAddrRdd.unpersist();

        JavaRDD<KyGdlPackWaybillnoMonitor> kyClimbRdd = elevatorRdd.map(o -> {
            String is_check = o.getIs_check();
            String review_status = o.getReview_status();
            String pass_status = o.getPass_status();
            String ky_climb = "";
            if (!StringUtils.equals(is_check, "爬楼（需审批）")) {
                ky_climb = "0";
            } else if (StringUtils.equals(is_check, "爬楼（需审批）")) {
                if (!StringUtils.equals(review_status, "已审批")) {
                    ky_climb = "-1";
                } else if (StringUtils.equals(review_status, "已审批")) {
                    if (!StringUtils.equals(pass_status, "通过")) {
                        ky_climb = "-2";
                    } else if (StringUtils.equals(pass_status, "通过")) {
                        ky_climb = "1";
                    }
                }
            }
            o.setKy_climb(ky_climb);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("kyClimbRdd cnt:{}", kyClimbRdd.count());
        kyClimbRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        elevatorRdd.unpersist();

        JavaRDD<KyGdlPackWaybillnoMonitor> checkRdd = kyClimbRdd.map(o -> {
            String is_climb = o.getIs_climb();
            String ky_climb = o.getKy_climb();
            String check = "";
            if (StringUtils.isNotEmpty(is_climb) && StringUtils.isNotEmpty(ky_climb) && !StringUtils.equals(ky_climb, "-1") && !StringUtils.equals(is_climb, ky_climb)) {
                check = "false";
            } else if (StringUtils.isNotEmpty(is_climb) && StringUtils.isNotEmpty(ky_climb) && !StringUtils.equals(ky_climb, "-1") && StringUtils.equals(is_climb, ky_climb)) {
                check = "true";
            }
            o.setCheck(check);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checkRdd cnt:{}", checkRdd.count());
        checkRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        kyClimbRdd.unpersist();

        logger.error("保存数据");
        String executeSql1 = String.format("alter table dm_gis.adds_ele_ky_check_kuang drop if EXISTS partition(inc_day='%s')", today);
        logger.error("executeSql1 :{}", executeSql1);
        spark.sql(executeSql1);
        service.saveData(spark, checkRdd, today);


        logger.error("通过映射表赋值城市名");
        JavaRDD<KyGdlPackWaybillnoMonitor> cityRdd = checkRdd.map(o -> {
            String cityCode = o.getDest_city_code();
            String addr = o.getAddr();
            Map<String, String> codeNameMap = mapBc.value();
            String city = codeNameMap.getOrDefault(cityCode, "");
            String[] citys = city.split("\\|");
            for (String ct : citys) {
                if (StringUtils.isNotEmpty(addr) && addr.contains(ct)) {
                    o.setCity(ct);
                    break;
                }else {
                    o.setCity(ct);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cityRdd cnt:{}", cityRdd.count());
        cityRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        checkRdd.unpersist();

        logger.error("按省份统计");
        JavaRDD<KyGdlPackWaybillnoMonitor> provinceRdd = cityRdd.mapToPair(o -> new Tuple2<>(o.getProvince() + "_" + o.getDate(), o))
                .groupByKey().map(tp -> {
                    List<KyGdlPackWaybillnoMonitor> list = Lists.newArrayList(tp._2);
                    KyGdlPackWaybillnoMonitor kyGdlPackWaybillnoMonitor = list.get(0);
                    String id = UUID.randomUUID().toString().replaceAll("-", "");
                    String stat_type = "PROVINCE";
                    String stat_type_content = StringUtils.isNotEmpty(kyGdlPackWaybillnoMonitor.getProvince()) ? kyGdlPackWaybillnoMonitor.getProvince() : "";

//                    int totalSize1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0") || StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
//                    int size1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
//                    double cover_ele_rate = (double) size1 / (double) totalSize1;
//
//                    int totalSize2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0") || StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
//                    int size2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
//                    double cover_climb_rate = (double) size2 / (double) totalSize2;
//
//                    int totalSize3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true") || StringUtils.equals(o.getCheck(), "false")).collect(Collectors.toList()).size();
//                    int size3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true")).collect(Collectors.toList()).size();
//                    double rightRate = (double) size3 / (double) totalSize3;

                    //总量
                    int cnt = list.size();
                    //匹配量
                    int match_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIs_climb())).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setMatch_cnt(match_cnt);
                    //电梯识别量：is_elevator=1或0
                    int elevator_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_distinguish_cnt(elevator_distinguish_cnt);
                    //有电梯
                    int has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setHas_elevator_cnt(has_elevator_cnt);
                    //无电梯
                    int no_has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_has_elevator_cnt(no_has_elevator_cnt);
                    //电梯无法判断
                    int elevator_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_no_judge_cnt(elevator_no_judge_cnt);
                    //爬楼识别量：is_climb=1或0
                    int climb_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_cnt(climb_distinguish_cnt);
                    //爬楼识别准确量
                    int climb_distinguish_right_cnt = list.stream().filter(o -> (StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")) || (StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2")))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_right_cnt(climb_distinguish_right_cnt);
                    //需要爬楼
                    int need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_cnt(need_climb_cnt);
                    //需要爬楼准确量
                    int need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_right_cnt(need_climb_right_cnt);
                    //快运爬楼审批通过
                    int ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_pass_cnt(ky_climb_approve_pass_cnt);
                    //快运爬楼审批驳回
                    int ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_reject_cnt(ky_climb_approve_reject_cnt);
                    //快运爬楼未审批
                    int ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_approve_cnt(ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_need_approve_cnt(ky_climb_no_need_approve_cnt);
                    //不需要爬楼
                    int no_need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_cnt(no_need_climb_cnt);
                    //不需要爬楼准确量
                    int no_need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2"))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_right_cnt(no_need_climb_right_cnt);


                    //快运未爬楼审批通过
                    int no_ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_pass_cnt(no_ky_climb_approve_pass_cnt);
                    //快运未爬楼审批驳回
                    int no_ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_reject_cnt(no_ky_climb_approve_reject_cnt);
                    //快运未爬楼未审批
                    int no_ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_approve_cnt(no_ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int no_ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_need_approve_cnt(no_ky_climb_no_need_approve_cnt);


                    //爬楼无法判断
                    int climb_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_no_judge_cnt(climb_no_judge_cnt);
                    //楼层识别量
                    int floor_distinguish_cnt = list.stream().filter(o -> !StringUtils.equals(o.getFloor(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setFloor_distinguish_cnt(floor_distinguish_cnt);

                    kyGdlPackWaybillnoMonitor.setId(id);
                    kyGdlPackWaybillnoMonitor.setStat_type(stat_type);
                    kyGdlPackWaybillnoMonitor.setStat_type_content(stat_type_content);
                    kyGdlPackWaybillnoMonitor.setRegion("ALL");
                    kyGdlPackWaybillnoMonitor.setCity("ALL");
                    kyGdlPackWaybillnoMonitor.setDest_city_code("ALL");
                    kyGdlPackWaybillnoMonitor.setDest_zone_code("ALL");
                    kyGdlPackWaybillnoMonitor.setCnt(cnt);

                    return kyGdlPackWaybillnoMonitor;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("provinceRdd cnt:{}", provinceRdd.count());
        provinceRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));


        logger.error("按大区统计");
        JavaRDD<KyGdlPackWaybillnoMonitor> regionRdd = cityRdd.mapToPair(o -> new Tuple2<>(o.getRegion() + "_" + o.getDate(), o))
                .groupByKey().map(tp -> {
                    List<KyGdlPackWaybillnoMonitor> list = Lists.newArrayList(tp._2);
                    KyGdlPackWaybillnoMonitor kyGdlPackWaybillnoMonitor = list.get(0);
                    String id = UUID.randomUUID().toString().replaceAll("-", "");
                    String stat_type = "REGION";
                    String stat_type_content = StringUtils.isNotEmpty(kyGdlPackWaybillnoMonitor.getRegion()) ? kyGdlPackWaybillnoMonitor.getRegion() : "";

//                    int totalSize1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0") || StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
//                    int size1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
//                    double cover_ele_rate = (double) size1 / (double) totalSize1;
//
//                    int totalSize2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0") || StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
//                    int size2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
//                    double cover_climb_rate = (double) size2 / (double) totalSize2;
//
//                    int totalSize3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true") || StringUtils.equals(o.getCheck(), "false")).collect(Collectors.toList()).size();
//                    int size3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true")).collect(Collectors.toList()).size();
//                    double rightRate = (double) size3 / (double) totalSize3;

                    //总量
                    int cnt = list.size();
                    //匹配量
                    int match_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIs_climb())).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setMatch_cnt(match_cnt);
                    //电梯识别量：is_elevator=1或0
                    int elevator_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_distinguish_cnt(elevator_distinguish_cnt);
                    //有电梯
                    int has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setHas_elevator_cnt(has_elevator_cnt);
                    //无电梯
                    int no_has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_has_elevator_cnt(no_has_elevator_cnt);
                    //电梯无法判断
                    int elevator_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_no_judge_cnt(elevator_no_judge_cnt);
                    //爬楼识别量：is_climb=1或0
                    int climb_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_cnt(climb_distinguish_cnt);
                    //爬楼识别准确量
                    int climb_distinguish_right_cnt = list.stream().filter(o -> (StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")) || (StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2")))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_right_cnt(climb_distinguish_right_cnt);
                    //需要爬楼
                    int need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_cnt(need_climb_cnt);
                    //需要爬楼准确量
                    int need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_right_cnt(need_climb_right_cnt);
                    //快运爬楼审批通过
                    int ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_pass_cnt(ky_climb_approve_pass_cnt);
                    //快运爬楼审批驳回
                    int ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_reject_cnt(ky_climb_approve_reject_cnt);
                    //快运爬楼未审批
                    int ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_approve_cnt(ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_need_approve_cnt(ky_climb_no_need_approve_cnt);
                    //不需要爬楼
                    int no_need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_cnt(no_need_climb_cnt);
                    //不需要爬楼准确量
                    int no_need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2"))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_right_cnt(no_need_climb_right_cnt);


                    //快运未爬楼审批通过
                    int no_ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_pass_cnt(no_ky_climb_approve_pass_cnt);
                    //快运未爬楼审批驳回
                    int no_ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_reject_cnt(no_ky_climb_approve_reject_cnt);
                    //快运未爬楼未审批
                    int no_ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_approve_cnt(no_ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int no_ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_need_approve_cnt(no_ky_climb_no_need_approve_cnt);


                    //爬楼无法判断
                    int climb_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_no_judge_cnt(climb_no_judge_cnt);
                    //楼层识别量
                    int floor_distinguish_cnt = list.stream().filter(o -> !StringUtils.equals(o.getFloor(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setFloor_distinguish_cnt(floor_distinguish_cnt);

                    kyGdlPackWaybillnoMonitor.setId(id);
                    kyGdlPackWaybillnoMonitor.setStat_type(stat_type);
                    kyGdlPackWaybillnoMonitor.setStat_type_content(stat_type_content);
                    kyGdlPackWaybillnoMonitor.setProvince("ALL");
                    kyGdlPackWaybillnoMonitor.setCity("ALL");
                    kyGdlPackWaybillnoMonitor.setDest_city_code("ALL");
                    kyGdlPackWaybillnoMonitor.setDest_zone_code("ALL");
                    kyGdlPackWaybillnoMonitor.setCnt(cnt);

                    return kyGdlPackWaybillnoMonitor;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("regionRdd cnt:{}", regionRdd.count());
        regionRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

//        logger.error("按城市维度统计");
        JavaRDD<KyGdlPackWaybillnoMonitor> statRegionCityRdd = cityRdd.mapToPair(o -> new Tuple2<>(o.getCity() + "_" + o.getDate(), o))
                .groupByKey().map(tp -> {
                    List<KyGdlPackWaybillnoMonitor> list = Lists.newArrayList(tp._2);
                    KyGdlPackWaybillnoMonitor kyGdlPackWaybillnoMonitor = list.get(0);
                    String id = UUID.randomUUID().toString().replaceAll("-", "");
                    String stat_type = "REGION";
                    String stat_type_content = StringUtils.isNotEmpty(kyGdlPackWaybillnoMonitor.getRegion()) ? kyGdlPackWaybillnoMonitor.getRegion() : "";

//                    int totalSize1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0") || StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
//                    int size1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
//                    double cover_ele_rate = (double) size1 / (double) totalSize1;
//
//                    int totalSize2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0") || StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
//                    int size2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
//                    double cover_climb_rate = (double) size2 / (double) totalSize2;
//
//                    int totalSize3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true") || StringUtils.equals(o.getCheck(), "false")).collect(Collectors.toList()).size();
//                    int size3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true")).collect(Collectors.toList()).size();
//                    double rightRate = (double) size3 / (double) totalSize3;

                    //总量
                    int cnt = list.size();
                    //匹配量
                    int match_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIs_climb())).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setMatch_cnt(match_cnt);
                    //电梯识别量：is_elevator=1或0
                    int elevator_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_distinguish_cnt(elevator_distinguish_cnt);
                    //有电梯
                    int has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setHas_elevator_cnt(has_elevator_cnt);
                    //无电梯
                    int no_has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_has_elevator_cnt(no_has_elevator_cnt);
                    //电梯无法判断
                    int elevator_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_no_judge_cnt(elevator_no_judge_cnt);
                    //爬楼识别量：is_climb=1或0
                    int climb_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_cnt(climb_distinguish_cnt);
                    //爬楼识别准确量
                    int climb_distinguish_right_cnt = list.stream().filter(o -> (StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")) || (StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2")))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_right_cnt(climb_distinguish_right_cnt);
                    //需要爬楼
                    int need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_cnt(need_climb_cnt);
                    //需要爬楼准确量
                    int need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_right_cnt(need_climb_right_cnt);
                    //快运爬楼审批通过
                    int ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_pass_cnt(ky_climb_approve_pass_cnt);
                    //快运爬楼审批驳回
                    int ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_reject_cnt(ky_climb_approve_reject_cnt);
                    //快运爬楼未审批
                    int ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_approve_cnt(ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_need_approve_cnt(ky_climb_no_need_approve_cnt);
                    //不需要爬楼
                    int no_need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_cnt(no_need_climb_cnt);
                    //不需要爬楼准确量
                    int no_need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2"))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_right_cnt(no_need_climb_right_cnt);


                    //快运未爬楼审批通过
                    int no_ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_pass_cnt(no_ky_climb_approve_pass_cnt);
                    //快运未爬楼审批驳回
                    int no_ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_reject_cnt(no_ky_climb_approve_reject_cnt);
                    //快运未爬楼未审批
                    int no_ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_approve_cnt(no_ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int no_ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_need_approve_cnt(no_ky_climb_no_need_approve_cnt);


                    //爬楼无法判断
                    int climb_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_no_judge_cnt(climb_no_judge_cnt);
                    //楼层识别量
                    int floor_distinguish_cnt = list.stream().filter(o -> !StringUtils.equals(o.getFloor(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setFloor_distinguish_cnt(floor_distinguish_cnt);

                    kyGdlPackWaybillnoMonitor.setId(id);
                    kyGdlPackWaybillnoMonitor.setStat_type(stat_type);
                    kyGdlPackWaybillnoMonitor.setStat_type_content(stat_type_content);
                    kyGdlPackWaybillnoMonitor.setDest_zone_code("ALL");
                    kyGdlPackWaybillnoMonitor.setCnt(cnt);

                    return kyGdlPackWaybillnoMonitor;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statRegionCityRdd cnt:{}", statRegionCityRdd.count());
        statRegionCityRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));


        JavaRDD<KyGdlPackWaybillnoMonitor> statProvinceCityRdd = cityRdd.mapToPair(o -> new Tuple2<>(o.getCity() + "_" + o.getDate(), o))
                .groupByKey().map(tp -> {
                    List<KyGdlPackWaybillnoMonitor> list = Lists.newArrayList(tp._2);
                    KyGdlPackWaybillnoMonitor kyGdlPackWaybillnoMonitor = list.get(0);
                    String id = UUID.randomUUID().toString().replaceAll("-", "");
                    String stat_type = "PROVINCE";
                    String stat_type_content = StringUtils.isNotEmpty(kyGdlPackWaybillnoMonitor.getProvince()) ? kyGdlPackWaybillnoMonitor.getProvince() : "";

//                    int totalSize1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0") || StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
//                    int size1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
//                    double cover_ele_rate = (double) size1 / (double) totalSize1;
//
//                    int totalSize2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0") || StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
//                    int size2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
//                    double cover_climb_rate = (double) size2 / (double) totalSize2;
//
//                    int totalSize3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true") || StringUtils.equals(o.getCheck(), "false")).collect(Collectors.toList()).size();
//                    int size3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true")).collect(Collectors.toList()).size();
//                    double rightRate = (double) size3 / (double) totalSize3;

                    //总量
                    int cnt = list.size();
                    //匹配量
                    int match_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIs_climb())).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setMatch_cnt(match_cnt);
                    //电梯识别量：is_elevator=1或0
                    int elevator_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_distinguish_cnt(elevator_distinguish_cnt);
                    //有电梯
                    int has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setHas_elevator_cnt(has_elevator_cnt);
                    //无电梯
                    int no_has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_has_elevator_cnt(no_has_elevator_cnt);
                    //电梯无法判断
                    int elevator_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_no_judge_cnt(elevator_no_judge_cnt);
                    //爬楼识别量：is_climb=1或0
                    int climb_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_cnt(climb_distinguish_cnt);
                    //爬楼识别准确量
                    int climb_distinguish_right_cnt = list.stream().filter(o -> (StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")) || (StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2")))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_right_cnt(climb_distinguish_right_cnt);
                    //需要爬楼
                    int need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_cnt(need_climb_cnt);
                    //需要爬楼准确量
                    int need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_right_cnt(need_climb_right_cnt);
                    //快运爬楼审批通过
                    int ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_pass_cnt(ky_climb_approve_pass_cnt);
                    //快运爬楼审批驳回
                    int ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_reject_cnt(ky_climb_approve_reject_cnt);
                    //快运爬楼未审批
                    int ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_approve_cnt(ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_need_approve_cnt(ky_climb_no_need_approve_cnt);
                    //不需要爬楼
                    int no_need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_cnt(no_need_climb_cnt);
                    //不需要爬楼准确量
                    int no_need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2"))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_right_cnt(no_need_climb_right_cnt);


                    //快运未爬楼审批通过
                    int no_ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_pass_cnt(no_ky_climb_approve_pass_cnt);
                    //快运未爬楼审批驳回
                    int no_ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_reject_cnt(no_ky_climb_approve_reject_cnt);
                    //快运未爬楼未审批
                    int no_ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_approve_cnt(no_ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int no_ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_need_approve_cnt(no_ky_climb_no_need_approve_cnt);


                    //爬楼无法判断
                    int climb_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_no_judge_cnt(climb_no_judge_cnt);
                    //楼层识别量
                    int floor_distinguish_cnt = list.stream().filter(o -> !StringUtils.equals(o.getFloor(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setFloor_distinguish_cnt(floor_distinguish_cnt);

                    kyGdlPackWaybillnoMonitor.setId(id);
                    kyGdlPackWaybillnoMonitor.setStat_type(stat_type);
                    kyGdlPackWaybillnoMonitor.setStat_type_content(stat_type_content);
                    kyGdlPackWaybillnoMonitor.setDest_zone_code("ALL");
                    kyGdlPackWaybillnoMonitor.setCnt(cnt);

                    return kyGdlPackWaybillnoMonitor;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("statProvinceCityRdd cnt:{}", statProvinceCityRdd.count());
        statProvinceCityRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        logger.error("只按时间维度统计");
        JavaRDD<KyGdlPackWaybillnoMonitor> regionDateRdd = cityRdd.mapToPair(o -> new Tuple2<>(o.getDate(), o))
                .groupByKey().map(tp -> {
                    List<KyGdlPackWaybillnoMonitor> list = Lists.newArrayList(tp._2);
                    KyGdlPackWaybillnoMonitor kyGdlPackWaybillnoMonitor = list.get(0);

                    String stat_type = "REGION";
                    String stat_type_content = "ALL";
                    String city = "ALL";
                    String citycode = "ALL";
                    String zc = "ALL";
                    String id = UUID.randomUUID().toString().replaceAll("-", "");

//                    int totalSize1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0") || StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
//                    int size1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
//                    double cover_ele_rate = (double) size1 / (double) totalSize1;
//
//                    int totalSize2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0") || StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
//                    int size2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
//                    double cover_climb_rate = (double) size2 / (double) totalSize2;
//
//                    int totalSize3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true") || StringUtils.equals(o.getCheck(), "false")).collect(Collectors.toList()).size();
//                    int size3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true")).collect(Collectors.toList()).size();
//                    double rightRate = (double) size3 / (double) totalSize3;

                    //总量
                    int cnt = list.size();
                    //匹配量
                    int match_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIs_climb())).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setMatch_cnt(match_cnt);
                    //电梯识别量：is_elevator=1或0
                    int elevator_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_distinguish_cnt(elevator_distinguish_cnt);
                    //有电梯
                    int has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setHas_elevator_cnt(has_elevator_cnt);
                    //无电梯
                    int no_has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_has_elevator_cnt(no_has_elevator_cnt);
                    //电梯无法判断
                    int elevator_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_no_judge_cnt(elevator_no_judge_cnt);
                    //爬楼识别量：is_climb=1或0
                    int climb_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_cnt(climb_distinguish_cnt);
                    //爬楼识别准确量
                    int climb_distinguish_right_cnt = list.stream().filter(o -> (StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")) || (StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2")))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_right_cnt(climb_distinguish_right_cnt);
                    //需要爬楼
                    int need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_cnt(need_climb_cnt);
                    //需要爬楼准确量
                    int need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_right_cnt(need_climb_right_cnt);
                    //快运爬楼审批通过
                    int ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_pass_cnt(ky_climb_approve_pass_cnt);
                    //快运爬楼审批驳回
                    int ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_reject_cnt(ky_climb_approve_reject_cnt);
                    //快运爬楼未审批
                    int ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_approve_cnt(ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_need_approve_cnt(ky_climb_no_need_approve_cnt);
                    //不需要爬楼
                    int no_need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_cnt(no_need_climb_cnt);
                    //不需要爬楼准确量
                    int no_need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2"))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_right_cnt(no_need_climb_right_cnt);


                    //快运未爬楼审批通过
                    int no_ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_pass_cnt(no_ky_climb_approve_pass_cnt);
                    //快运未爬楼审批驳回
                    int no_ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_reject_cnt(no_ky_climb_approve_reject_cnt);
                    //快运未爬楼未审批
                    int no_ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_approve_cnt(no_ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int no_ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_need_approve_cnt(no_ky_climb_no_need_approve_cnt);


                    //爬楼无法判断
                    int climb_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_no_judge_cnt(climb_no_judge_cnt);
                    //楼层识别量
                    int floor_distinguish_cnt = list.stream().filter(o -> !StringUtils.equals(o.getFloor(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setFloor_distinguish_cnt(floor_distinguish_cnt);

                    kyGdlPackWaybillnoMonitor.setId(id);
                    kyGdlPackWaybillnoMonitor.setStat_type(stat_type);
                    kyGdlPackWaybillnoMonitor.setStat_type_content(stat_type_content);
                    kyGdlPackWaybillnoMonitor.setCity(city);
                    kyGdlPackWaybillnoMonitor.setDest_city_code(citycode);
                    kyGdlPackWaybillnoMonitor.setDest_zone_code(zc);
                    kyGdlPackWaybillnoMonitor.setCnt(cnt);
                    kyGdlPackWaybillnoMonitor.setProvince("ALL");
                    kyGdlPackWaybillnoMonitor.setRegion("ALL");

                    return kyGdlPackWaybillnoMonitor;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("regionDateRdd cnt:{}", regionDateRdd.count());
        regionDateRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));


        logger.error("只按时间维度统计");
        JavaRDD<KyGdlPackWaybillnoMonitor> provinceDateRdd = cityRdd.mapToPair(o -> new Tuple2<>(o.getDate(), o))
                .groupByKey().map(tp -> {
                    List<KyGdlPackWaybillnoMonitor> list = Lists.newArrayList(tp._2);
                    KyGdlPackWaybillnoMonitor kyGdlPackWaybillnoMonitor = list.get(0);

                    String stat_type = "PROVINCE";
                    String stat_type_content = "ALL";
                    String city = "ALL";
                    String citycode = "ALL";
                    String zc = "ALL";
                    String id = UUID.randomUUID().toString().replaceAll("-", "");

//                    int totalSize1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0") || StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
//                    int size1 = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
//                    double cover_ele_rate = (double) size1 / (double) totalSize1;
//
//                    int totalSize2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0") || StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
//                    int size2 = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
//                    double cover_climb_rate = (double) size2 / (double) totalSize2;
//
//                    int totalSize3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true") || StringUtils.equals(o.getCheck(), "false")).collect(Collectors.toList()).size();
//                    int size3 = list.stream().filter(o -> StringUtils.equals(o.getCheck(), "true")).collect(Collectors.toList()).size();
//                    double rightRate = (double) size3 / (double) totalSize3;

                    //总量
                    int cnt = list.size();
                    //匹配量
                    int match_cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getIs_climb())).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setMatch_cnt(match_cnt);
                    //电梯识别量：is_elevator=1或0
                    int elevator_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1") || StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_distinguish_cnt(elevator_distinguish_cnt);
                    //有电梯
                    int has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setHas_elevator_cnt(has_elevator_cnt);
                    //无电梯
                    int no_has_elevator_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_has_elevator_cnt(no_has_elevator_cnt);
                    //电梯无法判断
                    int elevator_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_elevator(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setElevator_no_judge_cnt(elevator_no_judge_cnt);
                    //爬楼识别量：is_climb=1或0
                    int climb_distinguish_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") || StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_cnt(climb_distinguish_cnt);
                    //爬楼识别准确量
                    int climb_distinguish_right_cnt = list.stream().filter(o -> (StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")) || (StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2")))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_distinguish_right_cnt(climb_distinguish_right_cnt);
                    //需要爬楼
                    int need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_cnt(need_climb_cnt);
                    //需要爬楼准确量
                    int need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNeed_climb_right_cnt(need_climb_right_cnt);
                    //快运爬楼审批通过
                    int ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_pass_cnt(ky_climb_approve_pass_cnt);
                    //快运爬楼审批驳回
                    int ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_approve_reject_cnt(ky_climb_approve_reject_cnt);
                    //快运爬楼未审批
                    int ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_approve_cnt(ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "1") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setKy_climb_no_need_approve_cnt(ky_climb_no_need_approve_cnt);
                    //不需要爬楼
                    int no_need_climb_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_cnt(no_need_climb_cnt);
                    //不需要爬楼准确量
                    int no_need_climb_right_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && (StringUtils.equals(o.getKy_climb(), "0") || StringUtils.equals(o.getKy_climb(), "-2"))).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_need_climb_right_cnt(no_need_climb_right_cnt);


                    //快运未爬楼审批通过
                    int no_ky_climb_approve_pass_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_pass_cnt(no_ky_climb_approve_pass_cnt);
                    //快运未爬楼审批驳回
                    int no_ky_climb_approve_reject_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-2")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_approve_reject_cnt(no_ky_climb_approve_reject_cnt);
                    //快运未爬楼未审批
                    int no_ky_climb_no_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_approve_cnt(no_ky_climb_no_approve_cnt);
                    //快运未爬楼无需审批
                    int no_ky_climb_no_need_approve_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "0") && StringUtils.equals(o.getKy_climb(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setNo_ky_climb_no_need_approve_cnt(no_ky_climb_no_need_approve_cnt);


                    //爬楼无法判断
                    int climb_no_judge_cnt = list.stream().filter(o -> StringUtils.equals(o.getIs_climb(), "-1")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setClimb_no_judge_cnt(climb_no_judge_cnt);
                    //楼层识别量
                    int floor_distinguish_cnt = list.stream().filter(o -> !StringUtils.equals(o.getFloor(), "0")).collect(Collectors.toList()).size();
                    kyGdlPackWaybillnoMonitor.setFloor_distinguish_cnt(floor_distinguish_cnt);

                    kyGdlPackWaybillnoMonitor.setId(id);
                    kyGdlPackWaybillnoMonitor.setStat_type(stat_type);
                    kyGdlPackWaybillnoMonitor.setStat_type_content(stat_type_content);
                    kyGdlPackWaybillnoMonitor.setCity(city);
                    kyGdlPackWaybillnoMonitor.setDest_city_code(citycode);
                    kyGdlPackWaybillnoMonitor.setDest_zone_code(zc);
                    kyGdlPackWaybillnoMonitor.setCnt(cnt);
                    kyGdlPackWaybillnoMonitor.setProvince("ALL");
                    kyGdlPackWaybillnoMonitor.setRegion("ALL");

                    return kyGdlPackWaybillnoMonitor;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("provinceDateRdd cnt:{}", provinceDateRdd.count());
        provinceDateRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));


        JavaRDD<KyGdlPackWaybillnoMonitor> unoinRdd = provinceRdd.union(regionRdd).union(statRegionCityRdd).union(statProvinceCityRdd).union(regionDateRdd).union(provinceDateRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unoinRdd cnt:{}", unoinRdd.count());
        unoinRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        provinceRdd.unpersist();
        regionRdd.unpersist();
        cityRdd.unpersist();
        statRegionCityRdd.unpersist();
        statProvinceCityRdd.unpersist();
        regionDateRdd.unpersist();
        provinceDateRdd.unpersist();


        logger.error("保存数据");
        String executeSql2 = String.format("alter table dm_gis.adds_ele_ky_check_stat drop if EXISTS partition(inc_day='%s')", today);
        logger.error("executeSql2 :{}", executeSql2);
        spark.sql(executeSql2);
        service.saveStatData(spark, unoinRdd, today);

        logger.error("存储mysql数据库");
        service.saveToMysql(sc, unoinRdd);
        unoinRdd.unpersist();
        spark.stop();
    }

    public static void main(String[] args) {
//        Map<String, String> mapRegex = ConfigurationUtil.loadMap("allcity3.csv", "CITYCODE", "CITY");
//        System.out.println(mapRegex.size());
    }

}
