package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.DispatchGoUpstairsController1;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppDispatchGoUpstairs1 {
    private static Logger logger = LoggerFactory.getLogger(AppDispatchGoUpstairs1.class);

    public static void main(String[] args) throws Exception {
        String startDate = args[0];
        String endDate = args[1];
        String cityCodes = args[2];
        logger.error("cityCodes:{}", cityCodes);
        logger.error("startDate:{}, endDate:{}", startDate, endDate);
        logger.error("run start");
        new DispatchGoUpstairsController1().start(startDate, endDate, cityCodes);
        logger.error("run end");
    }
}
