package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.EconomizeTotalIndexController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppEconomizeTotalIndex {
    private static Logger logger = LoggerFactory.getLogger(AppEconomizeTotalIndex.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        logger.error("run start");
        new EconomizeTotalIndexController().start(startDate, endDate);
        logger.error("run end");
    }
}
