package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.controller.CpAnalysisController;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 竞品分析（analysis for competitive products，蓝媛青）（竞对位置数据挖掘）
 * @author 01370539 Created On: Jun.22 2021
 */
public class CpAnalysisApp {
    private static final Logger logger = LoggerFactory.getLogger(CpAnalysisApp.class);

    public static void main(String[] args) {
        String startDate;
        String endDate;
        String isFromOrig;
        String cityCode = null;
        if (args != null && args.length >= 4) {
            if (!"ALL".equalsIgnoreCase(args[0])) {
                cityCode = args[0];
            }
            startDate = args[1];
            endDate = args[2];
            isFromOrig = args[3];
        } else {
            startDate = DateUtil.getDayBefore(DateUtil.getCurrentDate(), "yyyyMMdd", 30);
            endDate = DateUtil.getDayBefore(DateUtil.getCurrentDate(), "yyyyMMdd", 1);
            isFromOrig = "true";
        }

        if (!startDate.matches("20\\d{6}") || !endDate.matches("20\\d{6}")) {
            logger.error("param not match, startDate - {}, endDate - {}", startDate, endDate);
            System.exit(0);
        }
        new CpAnalysisController().process(cityCode, startDate, endDate, isFromOrig);
    }
}
