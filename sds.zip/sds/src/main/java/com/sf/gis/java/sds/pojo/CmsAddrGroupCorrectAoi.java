package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CmsAddrGroupCorrectAoi implements Serializable {
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "address")
    private String address;
    @Column(name = "address_md5")
    private String address_md5;
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "type")
    private String type;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "splitresult")
    private String splitresult;
    @Column(name = "key_tag")
    private String key_tag;
    @Column(name = "key_word")
    private String key_word;
    @Column(name = "new_aoi")
    private String new_aoi;
    @Column(name = "update_result")
    private String update_result;

    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "city_code")
    private String city_code;

    public String getUpdate_result() {
        return update_result;
    }

    public void setUpdate_result(String update_result) {
        this.update_result = update_result;
    }

    public String getNew_aoi() {
        return new_aoi;
    }

    public void setNew_aoi(String new_aoi) {
        this.new_aoi = new_aoi;
    }

    public String getKey_tag() {
        return key_tag;
    }

    public void setKey_tag(String key_tag) {
        this.key_tag = key_tag;
    }

    public String getKey_word() {
        return key_word;
    }

    public void setKey_word(String key_word) {
        this.key_word = key_word;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress_md5() {
        return address_md5;
    }

    public void setAddress_md5(String address_md5) {
        this.address_md5 = address_md5;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }
}
