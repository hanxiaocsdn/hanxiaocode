package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.SwCityMatchSceneController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 需求：特殊入仓城配场景数据跑数
 * 需求方：潘宜鹏(01412980)
 * 研发：匡仁衡（01399581）
 * 研发时间：2023-04-17
 * 任务id:712312
 */
public class SwCityMatchScene {
    private static final Logger logger = LoggerFactory.getLogger(SwCityMatchScene.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        new SwCityMatchSceneController().start(date);
        logger.error("process end...");
    }
}
