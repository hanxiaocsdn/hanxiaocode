package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CgcsSgsAoiExp implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "dest_city_code")
    private String dest_city_code;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "aoi")
    private String aoi;
    @Column(name = "addressee_aoi_type")
    private String addressee_aoi_type;
    @Column(name = "src")
    private String src;

    @Column(name = "fa_type")
    private String fa_type;
    @Column(name = "xg_aoiid")
    private String xg_aoiid;
    @Column(name = "finalaoiid")
    private String finalaoiid;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "gisaoisrc")
    private String gisaoisrc;
    @Column(name = "tag")
    private String tag;
    private String mark;
    private String vague_tag;

    @Column(name = "std_addr")
    private String std_addr;
    @Column(name = "groupid")
    private String groupid;
    @Column(name = "std_aoiid")
    private String std_aoiid;
    private String std_dept;

    @Column(name = "gd_x")
    private String gd_x;
    @Column(name = "gd_y")
    private String gd_y;
    private String gd_aoiid;
    private String std_task_aoiid;
    private String cons_task_aoiid;
    private String check_dept_code;
    private String flag;

    private String rgsbAddContent;
    private String aoiCheckTagContent;
    private String updateAddressIdContent;

    @Column(name = "city_code")
    private String city_code;

    public String getGisaoisrc() {
        return gisaoisrc;
    }

    public void setGisaoisrc(String gisaoisrc) {
        this.gisaoisrc = gisaoisrc;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getFa_type() {
        return fa_type;
    }

    public void setFa_type(String fa_type) {
        this.fa_type = fa_type;
    }

    public String getRgsbAddContent() {
        return rgsbAddContent;
    }

    public void setRgsbAddContent(String rgsbAddContent) {
        this.rgsbAddContent = rgsbAddContent;
    }

    public String getAoiCheckTagContent() {
        return aoiCheckTagContent;
    }

    public void setAoiCheckTagContent(String aoiCheckTagContent) {
        this.aoiCheckTagContent = aoiCheckTagContent;
    }

    public String getUpdateAddressIdContent() {
        return updateAddressIdContent;
    }

    public void setUpdateAddressIdContent(String updateAddressIdContent) {
        this.updateAddressIdContent = updateAddressIdContent;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getCheck_dept_code() {
        return check_dept_code;
    }

    public void setCheck_dept_code(String check_dept_code) {
        this.check_dept_code = check_dept_code;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getCons_task_aoiid() {
        return cons_task_aoiid;
    }

    public void setCons_task_aoiid(String cons_task_aoiid) {
        this.cons_task_aoiid = cons_task_aoiid;
    }

    public String getStd_task_aoiid() {
        return std_task_aoiid;
    }

    public void setStd_task_aoiid(String std_task_aoiid) {
        this.std_task_aoiid = std_task_aoiid;
    }

    public String getGd_aoiid() {
        return gd_aoiid;
    }

    public void setGd_aoiid(String gd_aoiid) {
        this.gd_aoiid = gd_aoiid;
    }

    public String getGd_x() {
        return gd_x;
    }

    public void setGd_x(String gd_x) {
        this.gd_x = gd_x;
    }

    public String getGd_y() {
        return gd_y;
    }

    public void setGd_y(String gd_y) {
        this.gd_y = gd_y;
    }

    public String getStd_addr() {
        return std_addr;
    }

    public void setStd_addr(String std_addr) {
        this.std_addr = std_addr;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getStd_aoiid() {
        return std_aoiid;
    }

    public void setStd_aoiid(String std_aoiid) {
        this.std_aoiid = std_aoiid;
    }

    public String getStd_dept() {
        return std_dept;
    }

    public void setStd_dept(String std_dept) {
        this.std_dept = std_dept;
    }

    public String getVague_tag() {
        return vague_tag;
    }

    public void setVague_tag(String vague_tag) {
        this.vague_tag = vague_tag;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getFinalaoiid() {
        return finalaoiid;
    }

    public void setFinalaoiid(String finalaoiid) {
        this.finalaoiid = finalaoiid;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getXg_aoiid() {
        return xg_aoiid;
    }

    public void setXg_aoiid(String xg_aoiid) {
        this.xg_aoiid = xg_aoiid;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getDest_city_code() {
        return dest_city_code;
    }

    public void setDest_city_code(String dest_city_code) {
        this.dest_city_code = dest_city_code;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getAddressee_aoi_type() {
        return addressee_aoi_type;
    }

    public void setAddressee_aoi_type(String addressee_aoi_type) {
        this.addressee_aoi_type = addressee_aoi_type;
    }
}
