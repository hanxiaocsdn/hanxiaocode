package com.sf.gis.java.sds.app;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.EsgGisLocTrajectory;
import com.sf.gis.java.sds.pojo.HnYnXiaoge;
import com.sf.gis.scala.base.util.DistanceTool;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * 任务id：957986（湖南云南小哥服务范围需求）
 * 业务：01408947（刘雨婷）
 * 研发：01399581（匡仁衡）
 */
public class AppHnYnXiaoge {
    private static final Logger logger = Logger.getLogger(AppHnYnXiaoge.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:" + startDate);
        logger.error("endDate:" + endDate);

        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppHnYnXiaoge");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("获取湖南云南小哥数据");
        JavaRDD<HnYnXiaoge> xiaoGeRdd = getXiaoGeData(sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        List<String> unList = xiaoGeRdd.filter(o -> StringUtils.isNotEmpty(o.getUn())).map(HnYnXiaoge::getUn).distinct().collect();
        logger.error("获取轨迹数据");
        JavaRDD<EsgGisLocTrajectory> gjRdd = getGjData(sc, spark, startDate, endDate, unList);
        logger.error("小哥数据关联轨迹");
        JavaRDD<HnYnXiaoge> lastRdd = join(xiaoGeRdd, gjRdd, startDate, endDate);
        logger.error("结果数据存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.hu_yn_xiaoge_data", HnYnXiaoge.class, lastRdd);
    }

    public static JavaRDD<HnYnXiaoge> join(JavaRDD<HnYnXiaoge> xiaoGeRdd, JavaRDD<EsgGisLocTrajectory> gjRdd, String startDate, String endDate) {
        JavaRDD<HnYnXiaoge> lastRdd = xiaoGeRdd.mapToPair(o -> new Tuple2<>(o.getUn(), o)).leftOuterJoin(gjRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).groupByKey()).flatMap(tp -> {
            ArrayList<HnYnXiaoge> result = new ArrayList<>();
            HnYnXiaoge o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                List<EsgGisLocTrajectory> list = Lists.newArrayList(tp._2._2.get());
                List<String> dateList = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
                for (String date : dateList) {
                    List<EsgGisLocTrajectory> dateFilterList = list.stream().filter(t -> StringUtils.equals(date, t.getInc_day())).collect(Collectors.toList());
                    if (dateFilterList.size() > 0) {
                        EsgGisLocTrajectory start = dateFilterList.stream().sorted((o1, o2) -> o1.getTm().compareTo(o2.getTm())).collect(Collectors.toList()).get(0);
                        String zx = start.getZx();
                        String zy = start.getZy();

                        double radius = 0;
                        for (EsgGisLocTrajectory t : dateFilterList) {
                            String zx1 = t.getZx();
                            String zy1 = t.getZy();
                            double distance = DistanceTool.getGreatCircleDistance(Double.parseDouble(zx), Double.parseDouble(zy), Double.parseDouble(zx1), Double.parseDouble(zy1));
                            if (distance > radius) {
                                radius = distance;
                            }
                        }
                        HnYnXiaoge newO = new HnYnXiaoge();
                        BeanUtils.copyProperties(newO, o);
                        newO.setStart_zx(zx);
                        newO.setStart_zy(zy);
                        newO.setRadius((radius / 2) + "");
                        newO.setInc_day(date);
                        result.add(newO);
                    } else {
                        result.add(o);
                    }
                }
            } else {
                result.add(o);
            }
            return result.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:" + lastRdd.count());
        xiaoGeRdd.unpersist();
        gjRdd.unpersist();
        return lastRdd;
    }

    public static JavaRDD<EsgGisLocTrajectory> getGjData(JavaSparkContext sc, SparkSession spark, String startDate, String endDate, List<String> unList) {
        String un_list = "\'" + String.join("\',\'", unList) + "\'";
        logger.error("un_list:" + un_list);
        String sql = String.format("select\n" +
                "  un emp_code,\n" +
                "  zx,\n" +
                "  zy,\n" +
                "  tm,\n" +
                "  inc_day\n" +
                "from\n" +
                "  dm_gis.esg_gis_loc_trajectory\n" +
                "where\n" +
                "  inc_day between '%s'\n" +
                "  and '%s'\n" +
                "  and un in (%s)\n" +
                "  and ak = '1' and (zx is not null and zx <>'') and (zy is not null and zy <>'')\n" +
                "  and (\n" +
                "    (\n" +
                "      tp = '1'\n" +
                "      and ac < 100\n" +
                "      and sp < 15\n" +
                "    )\n" +
                "    or (\n" +
                "      tp = '5'\n" +
                "      and ac < 30\n" +
                "    )\n" +
                "  )", startDate, endDate, un_list);

        JavaRDD<EsgGisLocTrajectory> trajectoryRdd = DataUtil.loadData(spark, sc, sql, EsgGisLocTrajectory.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trajectoryRdd cnt:" + trajectoryRdd.count());
        return trajectoryRdd;
    }

    public static JavaRDD<HnYnXiaoge> getXiaoGeData(JavaSparkContext sc) {
        JavaRDD<String> lineRdd = sc.textFile("hdfs://sfbdp1/user/01399581/upload/yunying_demand/data/hn_yn_xiaoge.csv").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lineRdd cnt:" + lineRdd.count());
        String header = lineRdd.first();
        logger.error("header:" + header);

        JavaRDD<HnYnXiaoge> rdd = lineRdd.filter(o -> !StringUtils.equals(o, header)).map(line -> {
            String[] split = line.split(",");
            String un = "";
            String name = "";
            String dept = "";
            String area = "";
            try {
                un = split[0];
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                name = split[1];
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                dept = split[2];
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                area = split[3];
            } catch (Exception e) {
                e.printStackTrace();
            }
            return new HnYnXiaoge(un, name, dept, area);
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());
        lineRdd.unpersist();
        return rdd;
    }
}
