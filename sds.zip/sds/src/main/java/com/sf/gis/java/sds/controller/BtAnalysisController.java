package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.github.davidmoten.geo.LatLong;
import com.sf.gis.java.base.api.AoiApi;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.AoiInfo;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.BtDetail;
import com.sf.gis.java.sds.pojo.BtStat;
import com.sf.gis.java.sds.service.BtAnalysisService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * 摆摊数据挖掘
 * @author 01370539 Created On: Mar.10 2022
 */
public class BtAnalysisController {
    private static final Logger logger = LoggerFactory.getLogger(BtAnalysisController.class);

    private static final BtAnalysisService btService = new BtAnalysisService();

    public void process(String cityCodes, String startDate, String endDate, String isFromOrig) {
        logger.error("process start. cityCode - {}, startDate - {}, endDate - {}, isFromOrig - {}", cityCodes, startDate, endDate, isFromOrig);
        // 初始化spark
        SparkInfo si = SparkUtil.getSpark(this.getClass().getSimpleName());

        String[] cityCodeArr = cityCodes.split(",");
        for (String cityCode : cityCodeArr) {
            logger.error("start process city: {}, startDate: {}, endDate:{}, isFromOrig: {}", cityCode, startDate, endDate, isFromOrig);
            // 获取打过标签的轨迹数据
            JavaPairRDD<String, Iterable<String>> rddGj = processGj(si, cityCode, startDate, endDate, isFromOrig);

            // 获取巴枪数据并处理
            JavaPairRDD<String, Iterable<BtDetail>> rddBq = processBq(si, cityCode, startDate, endDate);

            long invokeCnt = rddGj.join(rddBq).count();
            logger.error("摆摊数据挂接运单数量: {}", invokeCnt);
            String httpInvokeId = BdpTaskRecordUtil.startRunNetworkInterface(si.getSession(), "01370539", "808232", "摆摊数据挖掘", "小哥派件不规范行为挖掘", HttpConstant.HTTP_URL_GETCOORAOI, "", invokeCnt, SysConstant.THREAD_COUNT);

            // 摆摊数据挂接运单
            JavaRDD<BtDetail> rddBt = rddGj.join(rddBq).flatMap(tmp -> {
                String[] xyArr = Lists.newArrayList(tmp._2._1).get(0).split("_");
                AoiInfo ai = AoiApi.getCoorAoiByDist("500", xyArr[0], xyArr[1]);
                List<BtDetail> bqList = Lists.newArrayList(tmp._2._2);
                for (BtDetail bq : bqList) {
                    bq.setAoi(ai.getAoiId());
                    bq.setCenterX(xyArr[0]);
                    bq.setCenterY(xyArr[1]);
                }
                bqList.forEach(o -> o.setAoi(ai.getAoiId()));
                return bqList.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("已经挂接的运单数量为：{}", rddBt.count());
            rddBt.take(2).forEach(o -> logger.error("rddBt ---->> {}", o.toString()));
            rddGj.unpersist();
            rddBq.unpersist();
            logger.error("调用服务完成，调用服务ID：{}", httpInvokeId);
            BdpTaskRecordUtil.endNetworkInterface("01370539", httpInvokeId);

            JavaPairRDD<String, String> rddAoi = btService.loadAoiData(si, cityCode).mapToPair(tmp -> new Tuple2<>(tmp.getAoi(), tmp.getAoiType())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoi count: {}", rddAoi.count());


            JavaRDD<BtDetail> rddAoiDetail = rddBt.mapToPair(tmp -> new Tuple2<>(tmp.getAoi(), tmp)).groupByKey().leftOuterJoin(rddAoi.groupByKey()).flatMap(tmp -> {
                List<BtDetail> btDetailList = Lists.newArrayList(tmp._2._1);
                if (tmp._2._2.isPresent()) {
                    String aoiType = Lists.newArrayList(tmp._2._2.get()).get(0);
                    btDetailList.forEach(o -> o.setAoiType(aoiType));
                }
                return btDetailList.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("挂接AOI类型");
            rddAoiDetail.take(3).forEach(o -> logger.error("rddRs ---->> {}", o.toString()));
            rddBt.unpersist();
            rddAoi.unpersist();

            logger.error("开始保存摆摊数据明细...........");
            DataUtil.saveInto(si, "dm_gis.bt_detail", BtDetail.class, rddAoiDetail, "inc_day");

            // 获取aoi统计信息
            JavaRDD<BtStat> rddAoiCnt = btService.loadAoiCount(si, cityCode, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoi cnt count: {}", rddAoiCnt.count());

            JavaRDD<BtStat> rddAoiStat = rddAoiDetail.mapToPair(tmp -> new Tuple2<>(tmp.getIncDay() + "_" + tmp.getAoi(), tmp)).reduceByKey((o1, o2) -> o1).leftOuterJoin(rddAoiCnt.mapToPair(tmp -> new Tuple2<>(tmp.getIncDay() + "_" + tmp.getAoi(), tmp))).map(tmp -> {
                BtStat btStat = new BtStat();
                btStat.setCityCode(tmp._2._1.getCityCode());
                btStat.setZc(tmp._2._1.getZc());
                btStat.setAoi(tmp._2._1.getAoi());
                btStat.setAoiType(tmp._2._1.getAoiType());
                btStat.setIncDay(tmp._2._1.getIncDay());
                if (tmp._2._2.isPresent()) {
                    btStat.setAoiPuCnt(tmp._2._2.get().getAoiPuCnt());
                    btStat.setAoiDlvCnt(tmp._2._2.get().getAoiDlvCnt());
                }
                return btStat;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoi统计数据数量为：{}", rddAoiStat.count());
            rddAoiStat.take(3).forEach(o -> logger.error("aoiStat----->> {}", o.toString()));
            rddAoiDetail.unpersist();
            rddAoiCnt.unpersist();

            DataUtil.saveInto(si, "dm_gis.bt_stat", BtStat.class, rddAoiStat, "inc_day");


            si.getSession().catalog().clearCache();
            logger.error("end process city:{} ", cityCode);
        }
        logger.error("process end.");
    }

    private static JavaRDD<BtDetail> getInitData(SparkInfo si, String cityCode, String startDate, String endDate) {
        // 获取轨迹数据
        JavaRDD<BtDetail> rddGj = btService.loadGjData(si, cityCode, startDate, endDate).map(tmp -> {
            String key = tmp.getOpTime().substring(0, 10) + "_" + Integer.valueOf(tmp.getOpTime().substring(10, 12)) / 15;
            tmp.setCityCode(tmp.getZc().substring(0, 3));
            tmp.setTmTag(key);
            return tmp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("获取轨迹数据：startDate:{}, endDate: {}, citycode: {}, data count: {}", startDate, endDate, cityCode, rddGj.count());
        rddGj.take(2).forEach(o -> logger.error("GjSrc ---->> {}", o.toString()));

        JavaRDD<BtDetail> rddGjAoi = btService.loadGjAoiData(si, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("获取轨迹aoi数据：startDate:{}, endDate: {}, data count: {}", startDate, endDate, rddGjAoi.count());
        rddGjAoi.take(2).forEach(o -> logger.error("rddGjAoi ---->> {}", o.toString()));

        JavaRDD<BtDetail> rddGjDetail = rddGj.mapToPair(o -> new Tuple2<>(o.getX() + "_" + o.getY(), o)).groupByKey().leftOuterJoin(rddGjAoi.mapToPair(o -> new Tuple2<>(o.getX() + "_" + o.getY(), o.getAoi())).groupByKey()).flatMap(o -> {
            List<BtDetail> gjList = Lists.newArrayList(o._2._1);
            if (o._2._2.isPresent()) {
                List<String> aoiList = Lists.newArrayList(o._2._2.get());
                if (aoiList.size() > 0 && StringUtils.isNotEmpty(aoiList.get(0))) {
                    for (BtDetail gj : gjList) {
                        gj.setAoi(aoiList.get(0));
                    }
                }
            }
            return gjList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("填充了aoi信息的轨迹数据量： {}", rddGjDetail.count());
        rddGjDetail.take(3).forEach(o -> logger.error("rddGjDetail ---->> {}", o.toString()));
        rddGj.unpersist();
        rddGjAoi.unpersist();

        return rddGjDetail;
    }

    private static JavaPairRDD<String, Iterable<String>> processGj(SparkInfo si, String cityCode, String startDate, String endDate, String isFromOrig) {
        JavaRDD<BtDetail> rddGjLbl;
        if ("true".equalsIgnoreCase(isFromOrig)) {
            // 轨迹数据划定时间周期并分组
            JavaPairRDD<String, Iterable<BtDetail>> rddTpTmGroup = getInitData(si, cityCode, startDate, endDate).mapToPair(tmp -> {
                return new Tuple2<>(tmp.getTmTag() + "_" + tmp.getEmpNo(), tmp);
            }).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("时间段分组数量： {}", rddTpTmGroup.count());
            rddTpTmGroup.take(10).forEach(o -> logger.error("时间： {}， 数量：{}", o._1, Lists.newArrayList(o._2).size()));

            // 处理未挂接上aoi的轨迹，并打标签
            rddGjLbl = rddTpTmGroup.flatMap(tmp -> {
                List<BtDetail> gjList = Lists.newArrayList(tmp._2);

                gjList.sort((a, b) -> a.getOpTime().compareTo(b.getOpTime()));
                String duration = String.valueOf(DateUtil.getTime(gjList.get(0).getOpTime(), gjList.get(gjList.size() - 1).getOpTime(), "yyyyMMddHHmmss") / 60000);

                LinkedList<LatLong> lllist = new LinkedList<>();

                for (BtDetail o : gjList) {
                    if (StringUtils.isEmpty(o.getAoi())) {
                        lllist.add(new LatLong(Double.parseDouble(o.getY()), Double.parseDouble(o.getX())));
                    }
                    o.setDuration(duration);
                }

                if (lllist.size() > 0) {
                    LatLong center = GeometryUtil.getCenter(lllist);
                    logger.error("center {} {}", center.getLon(), center.getLat());

                    int size = 0;
                    double dis;
                    for (BtDetail gj : gjList) {
                        if (StringUtils.isEmpty(gj.getAoi())) {
                            dis = GeometryUtil.getDistance(GeometryUtil.createPoint(gj.getX(), gj.getY()), GeometryUtil.createPoint(center.getLon(), center.getLat()));
                            if (dis <= 10) {
                                size++;
                            }
                            gj.setDis(String.valueOf(dis));
                            gj.setCenterX(String.valueOf(center.getLon()));
                            gj.setCenterY(String.valueOf(center.getLat()));
                        }
                    }

                    double btRate = new BigDecimal((float) size / gjList.size()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
                    for (BtDetail gj : gjList) {
                        if (StringUtils.isEmpty(gj.getAoi())) {
                            gj.setBtRate(String.valueOf(btRate));
                        }
                    }
                }
                return gjList.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("符合条件的时间段总数据量: {}", rddGjLbl.count());
            rddGjLbl.take(3).forEach(o -> logger.error("result -->> {}", o.toString()));
            rddTpTmGroup.unpersist();

            DataUtil.saveInto(si, "dm_gis.bt_gj", BtDetail.class, rddGjLbl, "inc_day");
        } else {
            rddGjLbl = btService.loadBtEmpData(si, cityCode, startDate, endDate);
        }

        // 过滤符合条件的轨迹数据，找出有摆摊可能性的小哥
        JavaRDD<BtDetail> rddGjRs = rddGjLbl.filter(tmp -> StringUtils.isEmpty(tmp.getAoi()) && Double.parseDouble(tmp.getBtRate()) >= 0.9 && Integer.parseInt(tmp.getDuration()) > 5).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("符合条件的时间段数据量: {}", rddGjRs.count());
        rddGjRs.take(3).forEach(o -> logger.error("result -->> {}", o.toString()));
        rddGjLbl.unpersist();

        JavaPairRDD<String, Iterable<String>> rddBtEmp = rddGjRs.mapToPair(tmp -> new Tuple2<>(tmp.getEmpNo() + "_" + tmp.getTmTag(), tmp.getCenterX() + "_" + tmp.getCenterY())).groupByKey().persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("摆摊小哥的数据量：{}", rddBtEmp.count());
        rddBtEmp.take(3).forEach(o -> logger.error("result -->> {}", o.toString()));
        rddGjRs.unpersist();

        return rddBtEmp;
    }

    // 处理巴枪的数据
    private JavaPairRDD<String, Iterable<BtDetail>> processBq(SparkInfo si, String cityCode, String startDate, String endDate) {
        // 获取巴枪数据
        JavaRDD<BtDetail> rddBq = btService.loadBqData(si, cityCode, startDate, endDate).map(tmp -> {
            String key = tmp.getOpTime().substring(0, 10) + "_" + Integer.valueOf(tmp.getOpTime().substring(10, 12)) / 15;
            tmp.setCityCode(tmp.getZc().substring(0, 3));
            tmp.setTmTag(key);
            return tmp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("巴枪数量：{}", rddBq.count());
        rddBq.take(2).forEach(o -> logger.error("rddBq ---->> {}", o.toString()));

        JavaRDD<BtDetail> rddEmp = btService.loadEmpData(si, cityCode, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("运单量：{}", rddEmp.count());
        JavaPairRDD<String, String> rddTpWb = rddEmp.mapToPair(tmp -> new Tuple2<>(tmp.getCityCode() + "_" + tmp.getIncDay() + "_" + tmp.getEmpNo(), tmp)).groupByKey().flatMap(tmp -> {
            List<BtDetail> btDetailList = Lists.newArrayList(tmp._2);
            String size = btDetailList.size() + "";
            btDetailList.forEach(o -> o.setEmpWbCount(size));
            return btDetailList.iterator();
        }).mapToPair(tmp -> new Tuple2<>(tmp.getWaybillNo(), tmp.getEmpWbCount())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("统计了收件人当天件量之后的运单量：{}", rddTpWb.count());
        rddEmp.unpersist();

        // 对巴枪数据进行过滤；
        JavaPairRDD<String, Iterable<BtDetail>> rddBtRs = rddBq.mapToPair(tmp -> new Tuple2<>(tmp.getWaybillNo(), tmp)).groupByKey().leftOuterJoin(rddTpWb.groupByKey()).flatMap(tmp -> {
            List<BtDetail> btDetailList = Lists.newArrayList(tmp._2._1);
            if (tmp._2._2.isPresent()) {
                String wbCount = Lists.newArrayList(tmp._2._2.get()).get(0);
                btDetailList.forEach(o -> o.setEmpWbCount(wbCount));
            }
            return btDetailList.iterator();
        }).mapToPair(tmp -> new Tuple2<>(tmp.getEmpNo() + "_" + tmp.getTmTag(), tmp)).groupByKey().filter(tmp -> {
            boolean isResult = true;

            List<BtDetail> btDetailList = Lists.newArrayList(tmp._2);
            for (BtDetail o : btDetailList) {
                if (isResult && StringUtils.isNotEmpty(o.getEmpWbCount()) && Integer.parseInt(o.getEmpWbCount()) >= 30) {
                    isResult = false;
                    break;
                }
            }
            if (isResult) {
                Map<String, Integer> tmFreq = new HashMap<>();
                btDetailList.forEach(o -> {
                    if (tmFreq.get(o.getOpTime()) != null) {
                        tmFreq.put(o.getOpTime(), tmFreq.get(o.getOpTime()) + 1);
                    } else {
                        tmFreq.put(o.getOpTime(), 0);
                    }
                });
                for (String tm : tmFreq.keySet()) {
                    if (tmFreq.get(tm) >= 5) {
                        isResult = false;
                    }
                }
            }
            return isResult;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("过滤掉每秒操作超过5次的以及收件人存在当天有30以上的件的巴枪数据后巴枪数据数量： {}", rddBtRs.count());
        rddBq.unpersist();
        return rddBtRs;
    }

}
