package com.sf.gis.java.sds.appaoihook;



import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.base.util.SystemProperty;
import com.sf.gis.java.sds.controller.UploadWaybillAoiDataToHiveController;
import com.sf.gis.java.sds.db.GisRdsDbManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.Map;

public class MainUploadWaybillAoiDataToHive {
    private static final Logger logger = LoggerFactory.getLogger(MainUploadWaybillAoiDataToHive.class);

    public static void main(String[] args) throws Exception {
        logger.error("begin Main");
        long begin = System.currentTimeMillis();
//        try {
            start(args);
//        } catch (Exception e) {
//            e.printStackTrace();
//            logger.error(e.getMessage());
//        }
        logger.error("over:" + (System.currentTimeMillis() - begin));
    }

    private static void start(String[] args) throws Exception {
        Map<String, String> configMap = ConfigUtil
                .parserConfig(SystemProperty.homeDir + SystemProperty.fileSeparator + "common.properties");
        UploadWaybillAoiDataToHiveController sssWrongDistribute = new UploadWaybillAoiDataToHiveController(configMap);
        sssWrongDistribute.start();
        GisRdsDbManager.getInstance().close();
    }

}