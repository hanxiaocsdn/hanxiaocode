package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.pojo.WbTrack;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.FcDlv;
import com.sf.gis.java.sds.service.FalseControlsService;
import jodd.util.StringUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.ArrayList;
import java.util.List;
/**
 * 虚假管控：实时弹窗逻辑修正验证（处理逻辑）, 任务ID：363987
 * @author 01370539
 * Created on Jun.20 2022
 */
public class FalseControlsController {
    private static final Logger logger = LoggerFactory.getLogger(FalseControlsController.class);

    private static final FalseControlsService fcSvc = new FalseControlsService();

    public void processDlv(String cityCodes, String incDays, String isFromRs, int chkAoiBuffer) {
        logger.error("start processDlv: cityCodes - {}, incDays - {}, isFromRs - {}", cityCodes, incDays, isFromRs);
        SparkInfo si = SparkUtil.getSpark4File(FalseControlsController.class.getName());
        si.getSession().sql("set mapred.min.split.size.per.node = 2000000");
        si.getSession().sql("set mapred.min.split.size.per.rack = 2000000");
        JavaRDD<FcDlv> rddCnyz = DataUtil.loadFile(si, "/user/01370539/upload/cnyz.csv", "GBK", FcDlv.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error(">>>>>>>>>>>>>>>> 菜鸟驿站信息数据量：{}", rddCnyz.count());
        logger.error(">>>>>>>>>>>>>>>> 菜鸟驿站有AOI信息的数据量：{}", rddCnyz.filter(o -> StringUtils.isNotEmpty(o.getAoiId())).count());
        rddCnyz.filter(o -> StringUtils.isNotEmpty(o.getAoiId())).take(3).forEach(o -> logger.error("菜鸟驿站数据详细信息：{}", o.toString()));
        SparkUtil.setCfgSplit(si);

        String[] cityCodeArr = cityCodes.split(",");
//        String[] cityCodeArr = new String[]{"010","020","021","022","023","024","025","027","028","029","052","053","086","088","310","311","312","313","314","315","316","317","318","319","335","349","350","351","352","353","354","355","356","357","358","359","370","371","372","373","374","375","376","377","378","379","391","392","393","394","395","396","398","411","412","414","415","416","417","418","419","421","427","429","431","432","433","434","435","436","437","438","439","451","452","453","454","455","456","457","458","459","464","467","468","469","470","471","472","473","474","475","476","477","478","479","482","483","510","511","512","513","514","515","516","517","518","519","523","527","530","531","532","533","534","535","536","537","538","539","543","546","550","551","552","553","554","555","556","557","558","559","561","562","563","564","566","570","571","572","573","574","575","576","577","578","579","580","591","592","593","594","595","596","597","598","599","631","632","633","634","635","660","662","663","668","691","692","701","710","711","712","713","714","715","716","717","718","719","722","724","728","730","7311","7312","7313","734","735","736","737","738","739","743","744","745","746","750","751","752","753","754","755","756","757","758","759","760","762","763","766","768","769","770","771","772","773","774","775","776","777","778","779","790","791","792","793","794","795","796","797","798","799","812","813","816","817","818","825","826","827","830","831","832","833","834","835","836","837","838","839","851","852","853","854","855","856","857","858","859","870","871","872","873","874","875","876","877","878","879","883","886","887","891","892","893","894","895","896","897","898","8981","901","902","903","906","908","909","911","912","913","914","915","916","917","919","930","931","932","933","934","935","936","937","938","939","941","943","951","952","953","954","955","970","971","972","973","974","975","976","977","979","990","991","992","993","994","995","996","997","998","999"};
        String[] incDayArr = incDays.split(",");
        for (String cityCode : cityCodeArr) {
            for (String incDay : incDayArr) {
                logger.error("start processDlv: cityCode - {}, incDay - {}, isFromRs - {}", cityCode, incDay, isFromRs);

                JavaRDD<FcDlv> rddWbInit = fcSvc.loadWbDlvInfo(si, cityCode, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error(">>>>>>>>>>>>>>>> 运单妥投信息数据量：{}", rddWbInit.count());
                rddWbInit.take(3).forEach(o -> logger.error("运单妥投数据详细信息：{}", o.toString()));

                JavaRDD<FcDlv> rddWbAddr = fcSvc.loadWbDlvAddr(si, cityCode, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error(">>>>>>>>>>>>>>>> 运单地址信息数据量：{}", rddWbAddr.count());
                rddWbAddr.take(3).forEach(o -> logger.error("运单地址数据详细信息：{}", o.toString()));

                JavaRDD<FcDlv> rddWb = rddWbInit.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey().leftOuterJoin(rddWbAddr.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey()).flatMap(o -> {
                    List<FcDlv> wb = Lists.newArrayList(o._2._1);
                    if (o._2._2.isPresent()) {
                        List<FcDlv> wbAddr = Lists.newArrayList(o._2._2.get());
                        if (wb.size() == 1 && wbAddr.size() == 1) {
                            wb.get(0).setAddr(wbAddr.get(0).getAddr());
                            wb.get(0).setLngZc(wbAddr.get(0).getLngZc());
                            wb.get(0).setLatZc(wbAddr.get(0).getLatZc());
                        } else {
                            wbAddr.forEach(tmp -> tmp.setAddr("多条记录"));
                        }
                    }
                    return wb.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error(">>>>>>>>>>>>>>>> 挂接了地址的运单数据量：{}", rddWb.count());
                rddWb.filter(o -> StringUtils.isNotEmpty(o.getAddr())).take(3).forEach(o -> logger.error("挂接了地址的运单数据详细信息：{}", o.toString()));
                rddWbInit.unpersist();
                rddWbAddr.unpersist();

                JavaRDD<FcDlv> rddAddrRcg = fcSvc.loadDlvAddrRcg(si, cityCode, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error(">>>>>>>>>>>>>>>> 可识别的地址数据量：{}", rddAddrRcg.count());
                rddAddrRcg.take(3).forEach(o -> logger.error("可识别的地址详细信息：{}", o.toString()));

                JavaRDD<FcDlv> rddAddrRcgRs = fcSvc.loadDlvAddrRcgRs(si, cityCode, incDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error(">>>>>>>>>>>>>>>> 可识别的地址结果数据量：{}", rddAddrRcgRs.count());
                rddAddrRcgRs.take(3).forEach(o -> logger.error("可识别的地址结果详细信息：{}", o.toString()));

                JavaRDD<FcDlv> rddAddrTag = rddWb.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey().leftOuterJoin(rddAddrRcg.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey()).leftOuterJoin(rddAddrRcgRs.mapToPair(o -> new Tuple2<>(o.getWaybillNo(), o)).groupByKey()).flatMap(o -> {
                    List<FcDlv> rcgs = Lists.newArrayList(o._2._1._1);
                    if (o._2._2.isPresent()) {
                        List<FcDlv> rcgRss = Lists.newArrayList(o._2._2.get());
                        if (rcgs.size() == 1 && rcgRss.size() == 1) {
                            if ("correct".equals(rcgRss.get(0).getAddrTag())) {
                                rcgs.get(0).setAddrTag("ADDR_CORRCT");
                                rcgs.get(0).setAddrSrc(rcgRss.get(0).getAddrSrc());
                            } else if ("wrong".equals(rcgRss.get(0).getAddrTag())) {
                                rcgs.get(0).setAddrTag("ADDR_WRONG");
                            }
                        } else {
                            rcgs.forEach(tmp -> tmp.setAddrTag("多条记录"));
                        }
                    } else if (o._2._1._2.isPresent()) {
                        rcgs.forEach(tmp -> tmp.setAddrTag("ADDR_RCG"));
                    }
                    return rcgs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error(">>>>>>>>>>>>>>>> 可识别的地址关联识别结果数据量：{}", rddAddrTag.count());
                rddAddrTag.filter(o -> StringUtils.isNotEmpty(o.getAddrTag())).take(3).forEach(o -> logger.error("可识别的地址关联识别结果详细信息：{}", o.toString()));
                rddWb.unpersist();
                rddAddrRcg.unpersist();
                rddAddrRcgRs.unpersist();

                JavaRDD<FcDlv> rddWbDetail = rddAddrTag.mapToPair(o -> new Tuple2<>(o.getAoiId(), o)).groupByKey().leftOuterJoin(rddCnyz.filter(o -> StringUtils.isNotEmpty(o.getAoiId())).mapToPair(o -> new Tuple2<>(o.getAoiId(), o)).groupByKey()).flatMap(o -> {
                    List<FcDlv> wbs = Lists.newArrayList(o._2._1);
                    if (o._2._2.isPresent()) {
                        List<FcDlv> cnyzList = Lists.newArrayList(o._2._2.get());
                        wbs.forEach(tmp -> {
                            tmp.setCnyzList(cnyzList);
                            tmp.setCnyzCnt(String.valueOf(cnyzList.size()));
                        });
                    }
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("运单详细信息数据量：{}", rddWbDetail.count());
                rddWbDetail.filter(o -> o.getCnyzList().size() > 0).take(3).forEach(o -> logger.error("运单详细信息数据详细信息：{}", o.toString()));
                rddAddrTag.unpersist();

                JavaRDD<WbTrack> rddTrack = fcSvc.loadTrackInfo(si, cityCode, incDay);
                logger.error("轨迹信息数据量：{}", rddTrack.count());
                rddTrack.take(3).forEach(o -> logger.error("轨迹数据详细信息：{}", o.toString()));

                // 根据运单号，aoiid，小哥工号关联运单妥投信息和轨迹信息
                JavaRDD<FcDlv> rddFinal = rddWbDetail.mapToPair(o -> new Tuple2<>(KeyUtil.keyLinkWithUnderline(o.getWaybillNo(), o.getAoiId(), o.getCouriercode()), o)).groupByKey().leftOuterJoin(rddTrack.mapToPair(o -> new Tuple2<>(KeyUtil.keyLinkWithUnderline(o.getWaybillNo(), o.getAoiId(), o.getCourier()), o)).groupByKey()).flatMap(o -> {
                    List<FcDlv> wbs = Lists.newArrayList(o._2._1);
                    if (o._2._2.isPresent()) {
                        List<WbTrack> tracks = Lists.newArrayList(o._2._2().get());
                        long barScanTm;
                        long trackTm;
                        List<WbTrack> tmpList = new ArrayList<>();
                        int disLess50Cnt;
                        int inCnyzCnt;
                        for (FcDlv wb : wbs) {
                            tmpList.clear();
                            disLess50Cnt = 0;
                            inCnyzCnt = 0;
                            if (StringUtils.isNotEmpty(wb.getLng80()) && StringUtils.isNotEmpty(wb.getLat80())) {
                                if (StringUtils.isNotEmpty(wb.getAoiId())) {
                                    if (tracks.size() > 0) {
                                        barScanTm = Long.parseLong(wb.getBarscantm80());
                                        // 巴枪前5分钟内的轨迹点
                                        for (WbTrack track : tracks) {
                                            trackTm = Long.parseLong(track.getTmTrack()) * 1000;
                                            if (trackTm <= barScanTm && barScanTm - trackTm <= 300000) {
                                                if (barScanTm - trackTm <= 300000) {
                                                    tmpList.add(track);   // 巴枪前5分钟内的轨迹点
                                                }
                                            }
                                        }
                                        wb.setTrackCnt(tmpList.size() + "");
                                        if (tmpList.size() >= 5) {
                                            for (WbTrack track : tmpList) {
                                                if (Double.parseDouble(track.getDis()) <= chkAoiBuffer) {
                                                    disLess50Cnt++;   // 根据轨迹点坐标，计算轨迹点与AOI的距离小于200m的轨迹点数量
                                                }
                                                if (StringUtil.isEmpty(wb.getIsInZc300()) && StringUtil.isNotEmpty(wb.getLngZc()) && StringUtil.isNotEmpty(wb.getLatZc())) {
                                                    if (GeometryUtil.getDistance(GeometryUtil.createPoint(wb.getLngZc(), wb.getLatZc()), GeometryUtil.createPoint(track.getLngTrack(), track.getLatTrack())) <= 300) {
                                                        wb.setIsInZc300("1");
                                                    }
                                                }
                                            }
                                            if (disLess50Cnt == tmpList.size()) {   // 当所有轨迹点都落入AOI或者AOI周围50米以内时，打STANDARD标记
                                                wb.setType("STANDARD");
                                            } else if (disLess50Cnt == 0) {  // 当所有轨迹点都落入AOI周围50米以外时，打AOI_LIMIT标记
                                                wb.setType("AOI_LIMIT");
                                            } else {
                                                if (disLess50Cnt >= 2 && "1".equals(wb.getIscallphone())) {    // 当至少有两个轨迹点落入AOI或者AOI周围50米内，并且小哥长按查看客户电话
                                                    for (WbTrack tmp : tmpList) {
                                                        for (FcDlv cnyz : wb.getCnyzList()) {
                                                            if (GeometryUtil.getDistance(GeometryUtil.createPoint(tmp.getLngTrack(), tmp.getLatTrack()), GeometryUtil.createPoint(cnyz.getLngTrack(), cnyz.getLatTrack())) <= 50) {
                                                                inCnyzCnt++;    // 确认轨迹点在菜鸟驿站的数量
                                                                if (inCnyzCnt >= 2) {
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                        if (inCnyzCnt >= 2) {
                                                            break;
                                                        }
                                                    }
                                                    if (inCnyzCnt >= 2) {
                                                        wb.setType("STOP_LIMIT");     // 当至少有两个轨迹点落入AOI或者AOI周围50米内，并且小哥长按查看客户电话时，如果有两个及以上轨迹点在菜鸟驿站50米内，打STOP_LIMIT标记
                                                    }
                                                }
                                            }
                                        } else {
                                            wb.setType("LESS_TRACKS");    // 当轨迹点数量为0时，打LESS_TRACKS标记
                                        }
                                    } else {
                                        wb.setType("TRACKS_IS_NULL");    // 当小哥全天轨迹点数量数量为0时
                                    }
                                } else {
                                    wb.setType("AOI_FAULT");   // 当AOI为空时，打AOI_FAULT标记
                                }
                            }
                        }
                    }
                    return wbs.iterator();
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
                logger.error("最终结果数据量：{}", rddFinal.count());
                rddFinal.filter(o -> StringUtils.isNotEmpty(o.getType())).repartition(50).take(3).forEach(o -> logger.error("结果数据详细信息：{}", o.toString()));

                String tbl = "dm_gis.fc_dlv";
                if (chkAoiBuffer != 500) {
                    tbl += "_" + chkAoiBuffer;
                }

                DataUtil.saveOverwrite(si, tbl, FcDlv.class, rddFinal, "inc_day");
                logger.error("end processDlv: cityCode - {}, incDay - {}", cityCode, incDay);
                si.getSession().catalog().clearCache();
            }
        }
    }
}
