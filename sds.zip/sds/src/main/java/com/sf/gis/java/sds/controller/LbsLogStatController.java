package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.LbsLogPnsAoi;
import com.sf.gis.java.sds.pojo.LbsLogPnsAoiStat;
import com.sf.gis.java.sds.service.LbsLogAnalysisService;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class LbsLogStatController {
    private static final Logger logger = LoggerFactory.getLogger(LbsLogStatController.class);
    private final LbsLogAnalysisService lbsLogAnalysisService = new LbsLogAnalysisService();

    public void process(String startDate, String endDate) {
        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        SparkSession sparkSession = sparkInfo.getSession();
        JavaSparkContext sc = sparkInfo.getContext();

        List<String> dateList = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (String date : dateList) {
            logger.error("date:{}", date);
            JavaRDD<Row> rddRow = lbsLogAnalysisService.loadOrigLog(sparkInfo, date, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rddRow cnt:{}", rddRow.count());
            rddRow.take(1).forEach(row -> logger.error("log -> {}", row.getString(0)));

            JavaRDD<LbsLogPnsAoi> rddLog = lbsLogAnalysisService.analysis(rddRow, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rddLog cnt:{}", rddLog.count());
            rddLog.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            rddRow.unpersist();

            JavaRDD<LbsLogPnsAoi> processRdd = rddLog.filter(o -> StringUtils.isNotEmpty(o.getCity())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("processRdd cnt:{}", processRdd.count());
            rddLog.unpersist();

            JavaRDD<LbsLogPnsAoiStat> resultRdd = lbsLogAnalysisService.analysisStat(sc, processRdd, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            resultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            processRdd.unpersist();

            String executeSql = String.format("alter table dm_gis.lbs_log_pnsaoi_stat drop if EXISTS partition( inc_day='%s' )", date);
            logger.error("executeSql :{}", executeSql);
            sparkSession.sql(executeSql);
            DataUtil.saveOverwrite(sparkInfo, "dm_gis.lbs_log_pnsaoi_stat", LbsLogPnsAoiStat.class, resultRdd, "inc_day");
            resultRdd.unpersist();
        }
        sparkSession.stop();
        logger.error("process: end ");
    }
}
