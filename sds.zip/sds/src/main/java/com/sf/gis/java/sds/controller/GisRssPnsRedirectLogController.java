package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.GisRssPnsRedirectLog;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class GisRssPnsRedirectLogController {
    private Logger logger = LoggerFactory.getLogger(GisRssPnsRedirectLogController.class);

    public void process(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String sql = String.format("select log from dm_gis.gis_rss_pns_redirect_log_flink where inc_day = '%s'", date);
        logger.error("sql:{}", sql);
        JavaRDD<Row> rowRdd = spark.sql(sql).repartition(1200).toJavaRDD();
        logger.error("rowRdd cnt:{}", rowRdd.count());

        JavaRDD<GisRssPnsRedirectLog> resultRdd = rowRdd.map(row -> {
            GisRssPnsRedirectLog o = new GisRssPnsRedirectLog();
            try {
                String content = row.getString(0);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        JSONObject message = jsonObject.getJSONObject("message");
                        if (message != null) {
                            String dateTime = message.getString("dateTime");
                            String type = message.getString("type");
                            String sn = message.getString("sn");
                            o.setDateTime(dateTime);
                            o.setType(type);
                            o.setSn(sn);

                            JSONObject url = message.getJSONObject("url");
                            if (url != null) {
                                String ak = url.getString("ak");
                                String geometryCode = url.getString("geometryCode");
                                String address1 = url.getString("address1");
                                String address2 = url.getString("address2");
                                String orderNo = url.getString("orderNo");

                                o.setAk(ak);
                                o.setGeometryCode(geometryCode);
                                o.setAddress1(address1);
                                o.setAddress2(address2);
                                o.setOrderNo(orderNo);
                            }
                            String time = message.getString("time");
                            o.setTime(time);

                            JSONObject data = message.getJSONObject("data");
                            if (data != null) {
                                Integer status = data.getInteger("status");
                                o.setStatus(status + "");
                                JSONObject result = data.getJSONObject("result");
                                if (status == 1 && result != null) {
                                    String err = result.getString("err");
                                    String msg = result.getString("msg");
                                    o.setErr(err);
                                    o.setMsg(msg);
                                } else if (status == 0 && result != null) {
                                    JSONObject query = result.getJSONObject("query");
                                    if (query != null) {
                                        String q_address1 = query.getString("address1");
                                        String q_address2 = query.getString("address2");
                                        o.setQ_address1(q_address1);
                                        o.setQ_address2(q_address2);
                                    }
                                    JSONObject region = result.getJSONObject("region");
                                    if (region != null) {
                                        String q_province1 = region.getString("province1");
                                        String city1 = region.getString("city1");
                                        String county1 = region.getString("county1");
                                        String adcode1 = region.getString("adcode1");
                                        String geometryCode1 = region.getString("geometryCode1");
                                        String specialLevel1 = region.getString("specialLevel1");
                                        String province2 = region.getString("province2");
                                        String city2 = region.getString("city2");
                                        String county2 = region.getString("county2");
                                        String adcode2 = region.getString("adcode2");
                                        String identical = region.getString("identical");

                                        o.setQ_province1(q_province1);
                                        o.setCity1(city1);
                                        o.setCounty1(county1);
                                        o.setAdcode1(adcode1);
                                        o.setGeometryCode1(geometryCode1);
                                        o.setSpecialLevel1(specialLevel1);
                                        o.setProvince2(province2);
                                        o.setCity2(city2);
                                        o.setCounty2(county2);
                                        o.setAdcode2(adcode2);
                                        o.setIdentical(identical);
                                    }
                                    JSONObject route_plan = result.getJSONObject("route_plan");
                                    if (route_plan != null) {
                                        JSONObject driving = route_plan.getJSONObject("driving");
                                        JSONObject walk = route_plan.getJSONObject("walk");
                                        if (driving != null) {
                                            String driving_distance = driving.getString("distance");
                                            String driving_time = driving.getString("time");
                                            o.setDriving_distance(driving_distance);
                                            o.setDriving_time(driving_time);
                                        }
                                        if (walk != null) {
                                            String walking_distance = walk.getString("distance");
                                            String walking_time = walk.getString("time");
                                            o.setWalking_distance(walking_distance);
                                            o.setWalking_time(walking_time);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        rowRdd.unpersist();

        logger.error("存储数据");
        String executeSql = String.format("alter table dm_gis.gis_rss_pns_redirect_analysis drop if EXISTS partition(inc_day='%s')", date);
        logger.error("executeSql :{}", executeSql);
        spark.sql(executeSql);
        saveData(spark, resultRdd, date);
        resultRdd.unpersist();
    }

    public void saveData(SparkSession spark, JavaRDD<GisRssPnsRedirectLog> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getDateTime(), o.getType(), o.getSn(), o.getAk(), o.getGeometryCode(), o.getAddress1(), o.getAddress2(), o.getOrderNo(), o.getTime(),
                    o.getStatus(), o.getErr(), o.getMsg(), o.getQ_address1(), o.getQ_address2(), o.getQ_province1(), o.getCity1(), o.getCounty1(), o.getAdcode1(),
                    o.getGeometryCode1(), o.getSpecialLevel1(), o.getProvince2(), o.getCity2(), o.getCounty2(), o.getAdcode2(), o.getIdentical(),
                    o.getDriving_distance(), o.getDriving_time(), o.getWalking_distance(), o.getWalking_time()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"datetime", "type", "sn", "ak", "geometrycode", "address1", "address2", "orderno",
                "time", "status", "err", "msg", "q_address1", "q_address2", "q_province1", "city1", "county1", "adcode1", "geometryCode1",
                "speciallevel1", "province2", "city2", "county2", "adcode2", "identical", "driving_distance", "driving_time", "walking_distance", "walking_time"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "gis_rss_pns_redirect_analysis_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.gis_rss_pns_redirect_analysis";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }
}
