package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.KuaiYunWaybillDetailDiController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppKuaiYunWaybillDetailDi {
    private static Logger logger = LoggerFactory.getLogger(AppKuaiYunWaybillDetailDi.class);

    /**
     * 需求：标杆库数据存储需求
     * 需求方：张剑佩（01416486）
     * 研发：匡仁衡（01399581）
     * 任务id:170(新平台)
     * 由于上游任务表冻结，现已停止，后续再看是否有需求 上游为快运错分报表报表：Kuaiyun_tmp
     * @param args
     */
    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        logger.error("run start");
        new KuaiYunWaybillDetailDiController().start(startDate, endDate);
        logger.error("run end");
    }
}
