package com.sf.gis.java.sds.pojo.aoichannel;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiChannelStat implements Serializable {
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "flag")
    private String flag;
    @Column(name = "code")
    private String code;

    private String aoi_channel;
    private String fc_code_list;
    private String bld_code_list;

    public String getFc_code_list() {
        return fc_code_list;
    }

    public void setFc_code_list(String fc_code_list) {
        this.fc_code_list = fc_code_list;
    }

    public String getBld_code_list() {
        return bld_code_list;
    }

    public void setBld_code_list(String bld_code_list) {
        this.bld_code_list = bld_code_list;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAoi_channel() {
        return aoi_channel;
    }

    public void setAoi_channel(String aoi_channel) {
        this.aoi_channel = aoi_channel;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }
}
