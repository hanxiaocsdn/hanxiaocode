package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.FcgAnalysisController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 丰巢柜位置挖掘（形成最优AOI串）
 * @author 01370539 Created On: Mar.10 2022
 */
public class FcgAnalysisApp {
    private static final Logger logger = LoggerFactory.getLogger(FcgAnalysisApp.class);

    public static void main(String[] args) {
        logger.error("FcgAnalysisApp args: {}, args length: {}", args, args.length);
        String cityCode = null;
        String fileUrl = null;
        String incDay = null;
        int dis = 5000;
        int wbCntDl = 200;
        int wbCntUl = 350;
        int aoiCntUl = 5;
        if (args != null && args.length >= 3) {
            cityCode = args[0];
            fileUrl = args[1];
            incDay = args[2];
            dis = Integer.parseInt(args[3]);
            wbCntDl = Integer.parseInt(args[4]);
            wbCntUl = Integer.parseInt(args[5]);
            aoiCntUl = Integer.parseInt(args[6]);
        } else {
            cityCode = "551";
            fileUrl = "C:/Users/01370539/fslinker/Downloads/551.csv";
            incDay = "all";
        }
        new FcgAnalysisController().process(cityCode, fileUrl, incDay, dis, wbCntDl, wbCntUl, aoiCntUl);
    }
}
