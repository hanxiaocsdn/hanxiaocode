package com.sf.gis.java.sds.pojo;

import com.sf.gis.java.sds.pojo.FcDlv;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Table
public class LbsLctCtrl implements Serializable {
    @Column(name = "waybill_no")
    private String waybillNo;   // 派件运单号
    @Column(name = "dest_hq_code")
    private String destHqCode;   // 派件大区编码
    @Column(name = "dest_zone_code")
    private String destZoneCode;    // 派件小哥所在网点代码
    @Column(name = "aoi_id")
    private String aoiId;    // aoiID
    @Column(name = "aoi_lng")
    private String aoiLng;    // aoi经度
    @Column(name = "aoi_lat")
    private String aoiLat;    // aoi纬度
    @Column(name = "dlv_lng")
    private String dlvLng;    // 80派件时间经度
    @Column(name = "dlv_lat")
    private String dlvLat;    // 80派件时间纬度
    @Column(name = "aoi_type_name")
    private String aoiTypeName;     // 派件运单aoi类型名称
    @Column(name = "aoi_type_code")
    private String aoiTypeCode;    // 派件运单aoi类型编码
    @Column(name = "consignee_phone")
    private String consigneePhone;     // 收件人电话
    @Column(name = "couriercode")
    private String couriercode;    // 小哥工号
    @Column(name = "service_prod_code")
    private String serviceProdCode;    // 增值服务代码为扫码:1081、1080、口令签收：21813、10065、电子签名页面：1052
    @Column(name = "barscantm")
    private String barscantm;    // 巴枪扫描时间
    @Column(name = "opcode")
    private String opcode;    // 操作码
    @Column(name = "track_lng")
    private String trackLng;   // 轨迹经度
    @Column(name = "track_lat")
    private String trackLat;    // 轨迹纬度
    @Column(name = "track_tm")
    private String trackTm;    // 轨迹时间
    @Column(name = "track_tp")
    private String trackTp;    // 轨迹定位类型
    @Column(name = "track_ad")
    private String trackAd;    // 轨迹海拔
    @Column(name = "track_ak")
    private String trackAk;    // 轨迹app-pk的简写（数据来源）
    @Column(name = "track30s_cnt")
    private String track30sCnt;    // 80前30S内轨迹点数
    @Column(name = "track30s_in_aoi_cnt")
    private String track30sInAoiCnt;    // 80前30S内在客户AOI边界内轨迹点数
    @Column(name = "track30s_in_aoi200_cnt")
    private String track30sInAoi200Cnt;    // 80前30S内在客户AOI200米内轨迹点数
    @Column(name = "track5m_in_aoi200_gps_cnt")
    private String track5mInAoi200GpsCnt;    // 80前后5分钟内在客户AOI200米内类型为gps的轨迹点数
    @Column(name = "track30s_in_cnyz100_cnt")
    private String track30sInCnyz100Cnt;    // 80前30S在驿站100米内轨迹点数
    @Column(name = "is_track5m_ad_change")
    private String isTrack5mAdChange;    // 80前后5分钟内在客户AOI200米内类型为gps的轨迹点海拔是否有变化
    @Column(name = "is_call_client")
    private String isCallClient;    // 是否拨打客户电话
    @Column(name = "is_copy_phone")
    private String isCopyPhone;    // 是否“长按查看客户真实号码”
    @Column(name = "is2box")
    private String is2box;    // 是否投柜或投店
    @Column(name = "is_oper_self")
    private String isOperSelf;    // 是否自寄自取（83）
    @Column(name = "is_dld")
    private String isDld;    // 是否代理点
    @Column(name = "is_dlv_err")
    private String isDlvErr;    // 是否错分（72）
    @Column(name = "is_rdrct_or_back")
    private String isRdrctOrBack;    // 是否转寄退回（67、82、99）
    @Column(name = "is_token")
    private String isToken;    // 是否口令签收、客户手机号扫码签收等
    @Column(name = "is_dlv_batch")
    private String isDlvBatch;    // 是否集派场景（单客户≥100票）
    @Column(name = "is_fwsj")
    private String isFwsj;    // 是否丰网、双捷、柜到柜
    @Column(name = "is_internal")
    private String isInternal;    // 是否丰网、双捷、柜到柜
    @Column(name = "is_complaint")
    private String isComplaint;    // 是否客诉
    @Column(name = "complaint1")
    private String complaint1;    // 客户投诉第一层
    @Column(name = "complaint2")
    private String complaint2;    // 客户投诉第一层
    @Column(name = "complaint3")
    private String complaint3;    // 客户投诉第一层
    @Column(name = "dlv_aoi_center_dis")
    private String dlvAoiCenterDis;    // 妥投aoi中心点和投递点的距离
    @Column(name = "dlv_aoi_side_dis")
    private String dlvAoiSideDis;    // 80投递经纬度距离AOI边界的距离
    @Column(name = "action_type")
    private String actionType;    // 操作类型，如：DLV_COMPETE:投竞业；NEVER_BEEN_CLIENT_AOI200: 未达到客户边界200m；NEVER_BEEN_CLIENT_HOME：疑似未上门；
    @Column(name = "event_id")
    private String eventId;    // 操作事件ID
    @Column(name = "inc_day")
    private String incDay;    // 数据日期
    private List<FcDlv> cnyzList = new ArrayList<>();
    private int trackRptCnt;

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getDestHqCode() {
        return destHqCode;
    }

    public void setDestHqCode(String destHqCode) {
        this.destHqCode = destHqCode;
    }

    public String getDestZoneCode() {
        return destZoneCode;
    }

    public void setDestZoneCode(String destZoneCode) {
        this.destZoneCode = destZoneCode;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiLng() {
        return aoiLng;
    }

    public void setAoiLng(String aoiLng) {
        this.aoiLng = aoiLng;
    }

    public String getAoiLat() {
        return aoiLat;
    }

    public void setAoiLat(String aoiLat) {
        this.aoiLat = aoiLat;
    }

    public String getDlvLng() {
        return dlvLng;
    }

    public void setDlvLng(String dlvLng) {
        this.dlvLng = dlvLng;
    }

    public String getDlvLat() {
        return dlvLat;
    }

    public void setDlvLat(String dlvLat) {
        this.dlvLat = dlvLat;
    }

    public String getAoiTypeName() {
        return aoiTypeName;
    }

    public void setAoiTypeName(String aoiTypeName) {
        this.aoiTypeName = aoiTypeName;
    }

    public String getAoiTypeCode() {
        return aoiTypeCode;
    }

    public void setAoiTypeCode(String aoiTypeCode) {
        this.aoiTypeCode = aoiTypeCode;
    }

    public String getConsigneePhone() {
        return consigneePhone;
    }

    public void setConsigneePhone(String consigneePhone) {
        this.consigneePhone = consigneePhone;
    }

    public String getCouriercode() {
        return couriercode;
    }

    public void setCouriercode(String couriercode) {
        this.couriercode = couriercode;
    }

    public String getServiceProdCode() {
        return serviceProdCode;
    }

    public void setServiceProdCode(String serviceProdCode) {
        this.serviceProdCode = serviceProdCode;
    }

    public String getBarscantm() {
        return barscantm;
    }

    public void setBarscantm(String barscantm) {
        this.barscantm = barscantm;
    }

    public String getOpcode() {
        return opcode;
    }

    public void setOpcode(String opcode) {
        this.opcode = opcode;
    }

    public String getTrackLng() {
        return trackLng;
    }

    public void setTrackLng(String trackLng) {
        this.trackLng = trackLng;
    }

    public String getTrackLat() {
        return trackLat;
    }

    public void setTrackLat(String trackLat) {
        this.trackLat = trackLat;
    }

    public String getTrackTm() {
        return trackTm;
    }

    public void setTrackTm(String trackTm) {
        this.trackTm = trackTm;
    }

    public String getTrackTp() {
        return trackTp;
    }

    public void setTrackTp(String trackTp) {
        this.trackTp = trackTp;
    }

    public String getTrackAd() {
        return trackAd;
    }

    public void setTrackAd(String trackAd) {
        this.trackAd = trackAd;
    }

    public String getTrackAk() {
        return trackAk;
    }

    public void setTrackAk(String trackAk) {
        this.trackAk = trackAk;
    }

    public String getTrack30sCnt() {
        return track30sCnt;
    }

    public void setTrack30sCnt(String track30sCnt) {
        this.track30sCnt = track30sCnt;
    }

    public String getTrack30sInAoiCnt() {
        return track30sInAoiCnt;
    }

    public void setTrack30sInAoiCnt(String track30sInAoiCnt) {
        this.track30sInAoiCnt = track30sInAoiCnt;
    }

    public String getTrack30sInAoi200Cnt() {
        return track30sInAoi200Cnt;
    }

    public void setTrack30sInAoi200Cnt(String track30sInAoi200Cnt) {
        this.track30sInAoi200Cnt = track30sInAoi200Cnt;
    }

    public String getTrack5mInAoi200GpsCnt() {
        return track5mInAoi200GpsCnt;
    }

    public void setTrack5mInAoi200GpsCnt(String track5mInAoi200GpsCnt) {
        this.track5mInAoi200GpsCnt = track5mInAoi200GpsCnt;
    }

    public String getTrack30sInCnyz100Cnt() {
        return track30sInCnyz100Cnt;
    }

    public void setTrack30sInCnyz100Cnt(String track30sInCnyz100Cnt) {
        this.track30sInCnyz100Cnt = track30sInCnyz100Cnt;
    }

    public String getIsTrack5mAdChange() {
        return isTrack5mAdChange;
    }

    public void setIsTrack5mAdChange(String isTrack5mAdChange) {
        this.isTrack5mAdChange = isTrack5mAdChange;
    }

    public String getIsCallClient() {
        return isCallClient;
    }

    public void setIsCallClient(String isCallClient) {
        this.isCallClient = isCallClient;
    }

    public String getIsCopyPhone() {
        return isCopyPhone;
    }

    public void setIsCopyPhone(String isCopyPhone) {
        this.isCopyPhone = isCopyPhone;
    }

    public String getIs2box() {
        return is2box;
    }

    public void setIs2box(String is2box) {
        this.is2box = is2box;
    }

    public String getIsOperSelf() {
        return isOperSelf;
    }

    public void setIsOperSelf(String isOperSelf) {
        this.isOperSelf = isOperSelf;
    }

    public String getIsDld() {
        return isDld;
    }

    public void setIsDld(String isDld) {
        this.isDld = isDld;
    }

    public String getIsDlvErr() {
        return isDlvErr;
    }

    public void setIsDlvErr(String isDlvErr) {
        this.isDlvErr = isDlvErr;
    }

    public String getIsRdrctOrBack() {
        return isRdrctOrBack;
    }

    public void setIsRdrctOrBack(String isRdrctOrBack) {
        this.isRdrctOrBack = isRdrctOrBack;
    }

    public String getIsToken() {
        return isToken;
    }

    public void setIsToken(String isToken) {
        this.isToken = isToken;
    }

    public String getIsDlvBatch() {
        return isDlvBatch;
    }

    public void setIsDlvBatch(String isDlvBatch) {
        this.isDlvBatch = isDlvBatch;
    }

    public String getIsFwsj() {
        return isFwsj;
    }

    public void setIsFwsj(String isFwsj) {
        this.isFwsj = isFwsj;
    }

    public String getIsInternal() {
        return isInternal;
    }

    public void setIsInternal(String isInternal) {
        this.isInternal = isInternal;
    }

    public String getIsComplaint() {
        return isComplaint;
    }

    public void setIsComplaint(String isComplaint) {
        this.isComplaint = isComplaint;
    }

    public String getComplaint1() {
        return complaint1;
    }

    public void setComplaint1(String complaint1) {
        this.complaint1 = complaint1;
    }

    public String getComplaint2() {
        return complaint2;
    }

    public void setComplaint2(String complaint2) {
        this.complaint2 = complaint2;
    }

    public String getComplaint3() {
        return complaint3;
    }

    public void setComplaint3(String complaint3) {
        this.complaint3 = complaint3;
    }

    public String getDlvAoiCenterDis() {
        return dlvAoiCenterDis;
    }

    public void setDlvAoiCenterDis(String dlvAoiCenterDis) {
        this.dlvAoiCenterDis = dlvAoiCenterDis;
    }

    public String getDlvAoiSideDis() {
        return dlvAoiSideDis;
    }

    public void setDlvAoiSideDis(String dlvAoiSideDis) {
        this.dlvAoiSideDis = dlvAoiSideDis;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getEventId() {
        return eventId;
    }

    public void setEventId(String eventId) {
        this.eventId = eventId;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public List<FcDlv> getCnyzList() {
        return cnyzList;
    }

    public void setCnyzList(List<FcDlv> cnyzList) {
        this.cnyzList = cnyzList;
    }

    public int getTrackRptCnt() {
        return trackRptCnt;
    }

    public void setTrackRptCnt(int trackRptCnt) {
        this.trackRptCnt = trackRptCnt;
    }

    @Override
    public String toString() {
        return "LbsLctCtrl{" +
                "waybillNo='" + waybillNo + '\'' +
                ", destHqCode='" + destHqCode + '\'' +
                ", destZoneCode='" + destZoneCode + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiLng='" + aoiLng + '\'' +
                ", aoiLat='" + aoiLat + '\'' +
                ", dlvLng='" + dlvLng + '\'' +
                ", dlvLat='" + dlvLat + '\'' +
                ", aoiTypeName='" + aoiTypeName + '\'' +
                ", aoiTypeCode='" + aoiTypeCode + '\'' +
                ", consigneePhone='" + consigneePhone + '\'' +
                ", couriercode='" + couriercode + '\'' +
                ", serviceProdCode='" + serviceProdCode + '\'' +
                ", barscantm='" + barscantm + '\'' +
                ", opcode='" + opcode + '\'' +
                ", trackLng='" + trackLng + '\'' +
                ", trackLat='" + trackLat + '\'' +
                ", trackTm='" + trackTm + '\'' +
                ", trackTp='" + trackTp + '\'' +
                ", trackAd='" + trackAd + '\'' +
                ", trackAk='" + trackAk + '\'' +
                ", track30sCnt='" + track30sCnt + '\'' +
                ", track30sInAoiCnt='" + track30sInAoiCnt + '\'' +
                ", track30sInAoi200Cnt='" + track30sInAoi200Cnt + '\'' +
                ", track5mInAoi200GpsCnt='" + track5mInAoi200GpsCnt + '\'' +
                ", track30sInCnyz100Cnt='" + track30sInCnyz100Cnt + '\'' +
                ", isTrack5mAdChange='" + isTrack5mAdChange + '\'' +
                ", isCallClient='" + isCallClient + '\'' +
                ", isCopyPhone='" + isCopyPhone + '\'' +
                ", is2box='" + is2box + '\'' +
                ", isOperSelf='" + isOperSelf + '\'' +
                ", isDld='" + isDld + '\'' +
                ", isDlvErr='" + isDlvErr + '\'' +
                ", isRdrctOrBack='" + isRdrctOrBack + '\'' +
                ", isToken='" + isToken + '\'' +
                ", isDlvBatch='" + isDlvBatch + '\'' +
                ", isFwsj='" + isFwsj + '\'' +
                ", isInternal='" + isInternal + '\'' +
                ", isComplaint='" + isComplaint + '\'' +
                ", complaint1='" + complaint1 + '\'' +
                ", complaint2='" + complaint2 + '\'' +
                ", complaint3='" + complaint3 + '\'' +
                ", trackAoiCenterDis='" + dlvAoiCenterDis + '\'' +
                ", trackAoiSideDis='" + dlvAoiSideDis + '\'' +
                ", actionType='" + actionType + '\'' +
                ", eventId='" + eventId + '\'' +
                ", incDay='" + incDay + '\'' +
                ", cnyzList.size=" + cnyzList.size() +
                ", trackRptCnt=" + trackRptCnt +
                '}';
    }
}
