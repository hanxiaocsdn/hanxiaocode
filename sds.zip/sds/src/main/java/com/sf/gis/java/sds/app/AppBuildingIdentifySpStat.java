package com.sf.gis.java.sds.app;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.BuildingIdentify;
import com.sf.gis.java.sds.pojo.BuildingIdentifyStat;
import com.sf.gis.java.sds.pojo.CityNameMap;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AppBuildingIdentifySpStat {
    private static Logger logger = LoggerFactory.getLogger(AppBuildingIdentifySpStat.class);
    private static String fnTable = "dm_gis.bld_recognition_rate_sp_stat_tmp";

    private static  String pjTable = "dm_gis.bld_recognition_rate_delivery_detail_tmp";
    private static String sjTable = "dm_gis.bld_recognition_rate_pickup_detail_tmp";
    /**
     * 需求:(【壹竿-SD】楼栋识别服务收件&派件统计)
     * 需求方：谢皓旸（01424739）
     * 研发：匡仁衡（01399581）
     * 任务id：778436
     */
    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppBuildingIdentifySpStat");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String sql = String.format("select dist_code citycode,dist_name city,area_name area,region_name region from dm_gis.dim_city_info_df where inc_day = '%s'", date);
        Map<String, CityNameMap> map = DataUtil.loadData(spark, sc, sql, CityNameMap.class).collect().stream().collect(Collectors.toMap(CityNameMap::getCitycode, t -> t, (key1, key2) -> key2));
        Broadcast<Map<String, CityNameMap>> mapBc = sc.broadcast(map);

//        String sj_sql = String.format("select * from dm_gis.bld_recognition_rate_pickup_detail where inc_day = '%s'and citycode <>''", date);
        String sj_sql = String.format("select * from %s where inc_day = '%s'",sjTable, date);
        JavaRDD<BuildingIdentify> sjRdd = DataUtil.loadData(spark, sc, sj_sql, BuildingIdentify.class).map(o -> {
            String fei_call = o.getFei_call();
            if (StringUtils.isEmpty(fei_call)) {
                o.setFei_call("0");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sjRdd cnt:{}", sjRdd.count());

//        String pj_sql = String.format("select * from dm_gis.bld_recognition_rate_delivery_detail where inc_day = '%s' and citycode <>''", date);
        String pj_sql = String.format("select * from %s where inc_day = '%s'",pjTable, date);
        JavaRDD<BuildingIdentify> pjRdd = DataUtil.loadData(spark, sc, pj_sql, BuildingIdentify.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("pjRdd cnt:{}", pjRdd.count());

        JavaRDD<BuildingIdentifyStat> sjStatRdd = stat(sjRdd, "sj", mapBc, date);
        JavaRDD<BuildingIdentifyStat> pjStatRdd = stat(pjRdd, "pj", mapBc, date);

        JavaRDD<BuildingIdentifyStat> resultRdd = sjStatRdd.union(pjStatRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        sjStatRdd.unpersist();
        pjStatRdd.unpersist();


        logger.error("最终结果表：{}",fnTable);
//        DataUtil.saveOverwrite(spark, sc, fnTable, BuildingIdentifyStat.class, resultRdd, "inc_day");
        DataUtil.saveOverwrite(spark, sc,fnTable , BuildingIdentifyStat.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();

    }

    public static JavaRDD<BuildingIdentifyStat> stat(JavaRDD<BuildingIdentify> rdd, String type, Broadcast<Map<String, CityNameMap>> mapBc, String statDate) {
        JavaRDD<BuildingIdentifyStat> lastRdd = rdd.mapToPair(o -> new Tuple2<>(o.getCitycode() + "_" + o.getFei_call() + "_" + o.getIs_complete() + o.getZno_code() + "_"+ o.getAoi_id()+ "_"+ o.getAoi_src(), o)).groupByKey().map(tp -> {
            List<BuildingIdentify> list = Lists.newArrayList(tp._2);

            long aoi_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_id())).map(BuildingIdentify::getAoi_id).distinct().count();

            long res_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getBuildingId())).count();
            long lvl14_num = list.stream().filter(o -> StringUtils.equals(o.getLvl14_info(), "1")).count();
            long lvl14_res_num = list.stream().filter(o -> StringUtils.equals(o.getLvl14_info(), "1") && StringUtils.isNotEmpty(o.getBuildingId())).count();
            long no_lvl14_num = list.stream().filter(o -> StringUtils.equals(o.getLvl14_info(), "0")).count();
            long no_lvl14_res_num = list.stream().filter(o -> StringUtils.equals(o.getLvl14_info(), "0") && StringUtils.isNotEmpty(o.getBuildingId())).count();

//            long waybillno_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getWaybillno())).count();
            long waybillno_num = lvl14_num+no_lvl14_num;



            long lvl14_AllkeywordMatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "14levelMatch") && StringUtils.equals(o.getDetailSrc(), "AllkeywordMatch")).count();
            long lvl14_SomekeywordMatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "14levelMatch") && StringUtils.equals(o.getDetailSrc(), "SomekeywordMatch")).count();
            long lvl14_pmatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "14levelMatch") && StringUtils.equals(o.getDetailSrc(), "pmatch")).count();

            long lvl15_AllkeywordMatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "15levelMatch") && StringUtils.equals(o.getDetailSrc(), "AllkeywordMatch")).count();
            long lvl15_SomekeywordMatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "15levelMatch") && StringUtils.equals(o.getDetailSrc(), "SomekeywordMatch")).count();
            long lvl15_pmatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "15levelMatch") && StringUtils.equals(o.getDetailSrc(), "pmatch")).count();

            long lvl13_pmatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "13levelMatch") && StringUtils.equals(o.getDetailSrc(), "pmatch")).count();
            long lvl13_escape_match_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "13levelMatch") && StringUtils.equals(o.getDetailSrc(), "escape_match")).count();
            long lvl13_pinyin_pmatch_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "13levelMatch") && StringUtils.equals(o.getDetailSrc(), "pinyin_pmatch")).count();
            long lvl13_pinyin_pmatch2_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "13levelMatch") && StringUtils.equals(o.getDetailSrc(), "pinyin_pmatch2")).count();

            long singleBD_num = list.stream().filter(o -> StringUtils.equals(o.getLevelSrc(), "singleBD")).count();

            BuildingIdentify buildingIdentify = list.get(0);
            String citycode = buildingIdentify.getCitycode();
            BuildingIdentifyStat o = new BuildingIdentifyStat();
            o.setStat_date(statDate);

            CityNameMap cityNameMap = mapBc.value().get(citycode);
            o.setArea(cityNameMap.getArea());
            o.setRegion(cityNameMap.getRegion());
            o.setCity(cityNameMap.getCity());
            o.setCity_code(citycode);
            o.setSpj_type(type);
            o.setFei_call(buildingIdentify.getFei_call());
            o.setIs_complete(buildingIdentify.getIs_complete());
            o.setZno_code(buildingIdentify.getZno_code());
            o.setAoi_id(buildingIdentify.getAoi_id());
            o.setAoi_src(buildingIdentify.getAoi_src());

            o.setAoi_num(aoi_num + "");
            o.setWaybillno_num(waybillno_num + "");
            o.setRes_num(res_num + "");
            o.setLvl14_num(lvl14_num + "");
            o.setLvl14_res_num(lvl14_res_num + "");
            o.setNo_lvl14_num(no_lvl14_num + "");
            o.setNo_lvl14_res_num(no_lvl14_res_num + "");
            o.setLvl14_allkeywordmatch_num(lvl14_AllkeywordMatch_num + "");
            o.setLvl14_somekeywordmatch_num(lvl14_SomekeywordMatch_num + "");
            o.setLvl14_pmatch_num(lvl14_pmatch_num + "");
            o.setLvl15_allkeywordmatch_num(lvl15_AllkeywordMatch_num + "");
            o.setLvl15_somekeywordmatch_num(lvl15_SomekeywordMatch_num + "");
            o.setLvl15_pmatch_num(lvl15_pmatch_num + "");
            o.setLvl13_pmatch_num(lvl13_pmatch_num + "");
            o.setLvl13_escape_match_num(lvl13_escape_match_num + "");
            o.setLvl13_pinyin_pmatch_num(lvl13_pinyin_pmatch_num + "");
            o.setLvl13_pinyin_pmatch2_num(lvl13_pinyin_pmatch2_num + "");
            o.setSinglebd_num(singleBD_num + "");
            o.setInc_day(statDate);

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        rdd.unpersist();
        return lastRdd;
    }
}
