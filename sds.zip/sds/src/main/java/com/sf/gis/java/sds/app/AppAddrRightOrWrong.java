package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.AddrRightOrWrongController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id:
 */
public class AppAddrRightOrWrong {
    private static Logger logger = LoggerFactory.getLogger(AppAddrRightOrWrong.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        logger.error("run start");
        new AddrRightOrWrongController().start(startDate, endDate);
        logger.error("run end");
    }
}
