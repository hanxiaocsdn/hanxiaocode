package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.KeyInfo;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.CmsAddrGroupCorrectAoi;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.sf.gis.java.base.util.StringNumUtils.fixnulltoStr;

/**
 * 任务id:938893(CMS地址库分组修正地址挂接AOI需求)
 * 研发：01399581（匡仁衡）
 * 业务：01434066（宋雨莲）
 */
public class AppCmsAddrGroupCorrectAoi {
    private static final Logger logger = Logger.getLogger(AppCmsAddrGroupCorrectAoi.class);
    private static final String url = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=dec044d089524419b371bc94555c539d&opt=normdetail&company=";
    private static final String updateAddrAoiId = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiId";
    private static final String account = "01399581";
    private static final String taskId = "938893";
    private static final String taskName = "CMS地址库分组修正地址挂接AOI需求";

    private static final int limitMin = 4000 / 10;

    public static void main(String[] args) {
        String date = args[0];
        String citycodes = args[1];
        logger.error("date:" + date);
        logger.error("citycodes:" + citycodes);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppCmsAddrGroupCorrectAoi");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        String[] split = citycodes.split(",");
        for (String city_code : split) {
            processByCity(city_code, cityDbPro, spark, sc, date);
//            try {
//            } catch (Exception e) {
//                logger.error("*****************************");
//                logger.error("process err city :" + city_code);
//                logger.error("*****************************");
//            }
        }
        sc.stop();
        logger.error("end...");
    }

    public static void processByCity(String city_code, Properties cityDbPro, SparkSession spark, JavaSparkContext sc, String date) {
        String number = cityDbPro.getProperty(city_code);
        String table = "wchka.cms_address_" + number;
        logger.error("process city:" + city_code);
        logger.error("table:" + table);
        String condition = String.format("city_code = '%s' and status = 1 and del_flag != 1 and tag != 1 and extend_attach2 not in ('1','2','5','7','9','10','11')", city_code);
        JavaRDD<CmsAddrGroupCorrectAoi> rdd = spark.read().format("jdbc")
                .option("driver", "com.mysql.jdbc.Driver")
                .option("url", "jdbc:mysql://wchka-s1.db.sfdc.com.cn:3306/wchka?useSSL=false&amp;useUnicode=true&amp;characterEncoding=utf8&amp;characterSetResults=utf8&amp;autoReconnect=true&amp;failOverReadOnly=false&amp;useOldAliasMetadataBehavior=true&amp;zeroDateTimeBehavior=convertToNull")
                .option("dbtable", table)
                .option("user", "wchka_aoi")
                .option("password", "giscmsaoi123")
                .load()
                .where(condition)
                .select("city_code", "zno_code", "address", "address_md5", "address_id", "type", "adcode", "aoi_id")
                .repartition(10)
                .toJavaRDD()
                .map(AppCmsAddrGroupCorrectAoi::transform).filter(o -> StringUtils.isNotEmpty(o.getAddress())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());

        JavaRDD<CmsAddrGroupCorrectAoi> keyRdd = rdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).groupByKey().flatMap(tp -> {
            List<CmsAddrGroupCorrectAoi> list = Lists.newArrayList(tp._2);
            CmsAddrGroupCorrectAoi o = list.get(0);
            String address = o.getAddress();
            String city = o.getCity_code();
            String req = String.format(url, URLEncoder.encode(address, "UTF-8"), city);
            String content = HttpInvokeUtil.sendGet(req);
            String splitresult = "";
            try {
                splitresult = JSON.parseObject(content).getJSONObject("result").getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
            } catch (Exception e) {
//                e.printStackTrace();
            }
            String finalSplitresult = splitresult;
            return list.stream().peek(t -> t.setSplitresult(finalSplitresult)).iterator();
        }).filter(o -> StringUtils.isNotEmpty(o.getSplitresult()) && judgeSplit(o.getSplitresult())).map(o -> {
            KeyInfo keyInfo = new KeyInfo(o.getSplitresult().split(";")[0]);
            Map<String, String> keyResult = keyInfo.pick_key();
            String key_tag = keyResult.get("key_tag");
            String key_word = keyResult.get("key_word");

            o.setKey_tag(key_tag);
            o.setKey_word(key_word);
            return o;
        }).filter(o -> StringUtils.isNotEmpty(o.getKey_tag()) && StringUtils.isNotEmpty(o.getKey_word())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("keyRdd cnt:" + keyRdd.count());
        rdd.unpersist();

        JavaRDD<CmsAddrGroupCorrectAoi> resultRdd = keyRdd.mapToPair(o -> new Tuple2<>(o.getKey_tag() + "_" + o.getKey_word(), o)).groupByKey().filter(tp -> {
            List<CmsAddrGroupCorrectAoi> list = Lists.newArrayList(tp._2);
            int all_size = list.size();
            List<CmsAddrGroupCorrectAoi> adcodeList = list.stream().filter(o -> Arrays.asList("4", "5", "6", "7", "8").contains(o.getAdcode())).collect(Collectors.toList());
            int adcode_size = adcodeList.size();
            int adcode_distinct_size = (int) adcodeList.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_id())).map(CmsAddrGroupCorrectAoi::getAoi_id).distinct().count();
            int znoe_code_size = (int) list.stream().filter(o -> StringUtils.isNotEmpty(o.getZno_code())).map(CmsAddrGroupCorrectAoi::getZno_code).distinct().count();
            int aoi_size = (int) list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_id())).map(CmsAddrGroupCorrectAoi::getAoi_id).distinct().count();

            return adcode_size < all_size && adcode_size >= 1 && adcode_distinct_size == 1 && znoe_code_size == 1 && aoi_size > 1;
        }).flatMap(tp -> {
            List<CmsAddrGroupCorrectAoi> list = Lists.newArrayList(tp._2);
            String aoi_id = list.stream().filter(o -> Arrays.asList("4", "5", "6", "7", "8").contains(o.getAdcode())).collect(Collectors.toList()).get(0).getAoi_id();
            return list.stream().peek(o -> {
                o.setNew_aoi(aoi_id);
                o.setInc_day(date);
            }).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:" + resultRdd.count());
        keyRdd.unpersist();

        JavaRDD<CmsAddrGroupCorrectAoi> updateRdd = resultRdd.repartition(5).map(o -> {
            String new_aoi = o.getNew_aoi();
            String aoi_id = o.getAoi_id();
            if (StringUtils.isNotEmpty(new_aoi) && !StringUtils.equals(new_aoi, aoi_id)) {
                String type = o.getType();
                String cityCode = o.getCity_code();
                String address_id = o.getAddress_id();
                String address_md5 = o.getAddress_md5();
                String operSource = "keyword_update";
                String operUserName = "01434066";
                String aoiSource = "S99";

                JSONObject param = new JSONObject();
                param.put("cityCode", cityCode);
                param.put("aoiId", new_aoi);
                param.put("operSource", operSource);
                param.put("operUserName", operUserName);
                param.put("aoiSource", aoiSource);
                if ("1".equals(type)) {
                    param.put("addressId", address_id);
                } else if ("2".equals(type)) {
                    param.put("addressMd5", address_md5);
                }
                String rs = HttpInvokeUtil.sendPost(updateAddrAoiId, param.toJSONString());
                o.setUpdate_result(rs);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("updateRdd cnt:" + updateRdd.count());
        resultRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.cms_keyword_update_aoi", CmsAddrGroupCorrectAoi.class, updateRdd, "inc_day", "city_code");
        updateRdd.unpersist();
        logger.error("process city:" + city_code + ",end");
    }

    public static boolean judgeSplit(String splitresult) {
        //广东省^11,深圳市^12,南山区^13,软件产业基地^213,1a栋^214,21楼^216
        int level_9_tag = 0;
        int level_11_tag = 0;
        int level_13_tag = 0;
        int cn_tag = 0;
        String regex = "[\\u4E00-\\u9FFF]";
        String text = splitresult.split(";")[0];
        String[] split = text.split(",");
        for (String s : split) {
            String[] split1 = s.split("\\^");
            if (split1.length >= 2) {
                String word = split1[0];
                String level = split1[1];
                String prefix = level.substring(0, 1);
                String after = level.substring(1, level.length());
                if ("9".equals(after)) {
                    level_9_tag = 1;
                }
                if ("11".equals(after)) {
                    level_11_tag = 1;
                }
                if (Arrays.asList("1", "2", "3", "4").contains(prefix) && "13".equals(after)) {
                    level_13_tag = 1;
                    continue;
                }

                if (level_13_tag == 1 && StringUtils.isNotEmpty(word) && wordContains(word)) {
                    cn_tag = 1;
                }

//                if (level_13_tag == 1 && StringUtils.isNotEmpty(word) && Pattern.compile(regex).matcher(word).find()) {
//                    cn_tag = 1;
//                }
            }
        }
        boolean flag1 = false;
        boolean flag2 = false;
        if (level_9_tag == 1 && level_11_tag == 1 && level_13_tag == 0) {
            flag1 = true;
        }

        if (level_13_tag == 1 && cn_tag == 0 && (level_9_tag + level_11_tag) != 2) {
            flag2 = true;
        }

        return flag1 || flag2;
    }

    public static boolean wordContains(String word) {
        String[] list = "对面,旁边,右边,左边,前面,后面,前边,后边,斜对面".split(",");
        for (String s : list) {
            if (word.contains(s)) {
                return true;
            }
        }
        return false;
    }

    public static CmsAddrGroupCorrectAoi transform(Row row) {
        CmsAddrGroupCorrectAoi o = new CmsAddrGroupCorrectAoi();
        String city_code = "";
        try {
            city_code = row.getString(0);
        } catch (Exception e) {
        }
        String zno_code = "";
        try {
            zno_code = row.getString(1);
        } catch (Exception e) {
        }
        String address = "";
        try {
            address = row.getString(2);
        } catch (Exception e) {
        }
        String address_md5 = "";
        try {
            address_md5 = row.getString(3);
        } catch (Exception e) {
        }
        String address_id = "";
        try {
            address_id = row.getString(4);
        } catch (Exception e) {
        }
        String type = "";
        try {
            type = row.getInt(5) + "";
        } catch (Exception e) {
        }
        String adcode = "";
        try {
            adcode = row.getString(6);
        } catch (Exception e) {
        }
        String aoi_id = "";
        try {
            aoi_id = row.getString(7);
        } catch (Exception e) {
        }

        o.setCity_code(fixnulltoStr(city_code));
        o.setZno_code(fixnulltoStr(zno_code));
        o.setAddress(fixnulltoStr(address));
        o.setAddress_md5(fixnulltoStr(address_md5));
        o.setAddress_id(fixnulltoStr(address_id));
        o.setType(fixnulltoStr(type));
        o.setAdcode(fixnulltoStr(adcode));
        o.setAoi_id(fixnulltoStr(aoi_id));
        return o;
    }
}
