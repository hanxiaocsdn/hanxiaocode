package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.MisjudgmentGroupCorrectController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppMisjudgmentGroupCorrect {
    private static Logger logger = LoggerFactory.getLogger(AppMisjudgmentGroupCorrect.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        logger.error("startDate:{},endDate:{}", startDate, endDate);
        logger.error("run start");
        new MisjudgmentGroupCorrectController().start(startDate, endDate);
        logger.error("run end");
    }
}
