package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class RdsOmsAoi implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "orderno")
    private String orderno;
    @Column(name = "deptcode")
    private String deptcode;
    @Column(name = "aoicode")
    private String aoicode;
    @Column(name = "reqtime")
    private String reqtime;

    private String aoiid;
    private String emp_code;
    private String reqtimetm;

    private String jiti;
    private String sp_jiti;
    private String qd_jiti;
    private String aoi_count;

    public String getAoi_count() {
        return aoi_count;
    }

    public void setAoi_count(String aoi_count) {
        this.aoi_count = aoi_count;
    }

    public String getJiti() {
        return jiti;
    }

    public void setJiti(String jiti) {
        this.jiti = jiti;
    }

    public String getSp_jiti() {
        return sp_jiti;
    }

    public void setSp_jiti(String sp_jiti) {
        this.sp_jiti = sp_jiti;
    }

    public String getQd_jiti() {
        return qd_jiti;
    }

    public void setQd_jiti(String qd_jiti) {
        this.qd_jiti = qd_jiti;
    }

    public String getReqtimetm() {
        return reqtimetm;
    }

    public void setReqtimetm(String reqtimetm) {
        this.reqtimetm = reqtimetm;
    }

    public String getOrderno() {
        return orderno;
    }

    public void setOrderno(String orderno) {
        this.orderno = orderno;
    }

    public String getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(String emp_code) {
        this.emp_code = emp_code;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getAoicode() {
        return aoicode;
    }

    public void setAoicode(String aoicode) {
        this.aoicode = aoicode;
    }

    public String getReqtime() {
        return reqtime;
    }

    public void setReqtime(String reqtime) {
        this.reqtime = reqtime;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }
}
