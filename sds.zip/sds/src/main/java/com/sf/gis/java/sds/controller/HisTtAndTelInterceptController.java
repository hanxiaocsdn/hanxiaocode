package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.SssDwdWaybillInfoDtlDi;
import com.sf.gis.java.sds.pojo.SssGisRdsOmsto;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class HisTtAndTelInterceptController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(HisTtAndTelInterceptController.class);

    public void process(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        JavaRDD<SssDwdWaybillInfoDtlDi> rdd = loadData(spark, sc, "", "", "").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<SssDwdWaybillInfoDtlDi> fiterCityRdd = rdd.filter(o -> !(StringUtils.isNotEmpty(o.getDest_zone_code()) && StringUtils.isNotEmpty(o.getDest_dist_code()) && o.getDest_zone_code().contains(o.getDest_dist_code()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("fiterCityRdd cnt:{}", fiterCityRdd.count());
        rdd.unpersist();

        JavaRDD<SssDwdWaybillInfoDtlDi> filterOpcodeRdd = fiterCityRdd.filter(o -> !StringUtils.equals(o.getOpcode(), "99")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterOpcodeRdd cnt:{}", filterOpcodeRdd.count());
        fiterCityRdd.unpersist();

        JavaRDD<SssDwdWaybillInfoDtlDi> deptTypeCodeRdd = filterOpcodeRdd.filter(this::judgeDeptTypeCode).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("deptTypeCodeRdd cnt:{}", deptTypeCodeRdd.count());
        filterOpcodeRdd.unpersist();


        JavaRDD<CmsAoiSch> cmsRdd = loadCmsData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsRdd cnt:{}", cmsRdd.count());

        JavaRDD<SssDwdWaybillInfoDtlDi> zoneRdd = deptTypeCodeRdd.mapToPair(o -> new Tuple2<>(o.getDest_zone_code(), o)).leftOuterJoin(cmsRdd.mapToPair(o -> new Tuple2<>(o.getZno_code(), o)))
                .filter(tp -> {
                    boolean flag = false;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = true;
                    }
                    return flag;
                }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("zoneRdd cnt:{}", zoneRdd.count());
        deptTypeCodeRdd.unpersist();
        cmsRdd.unpersist();

        Broadcast<List<String>> configBc = sc.broadcast(ConfigurationUtil.loadFileByConf("invalid_config.csv"));

        JavaRDD<SssDwdWaybillInfoDtlDi> processSplitRdd = zoneRdd.map(o -> {
            String splitresult = o.getSplitresult();
            if (StringUtils.isNotEmpty(splitresult)) {
                List<String> configList = configBc.value();
                String new_splitresult = processSplitresult(splitresult, configList);
                o.setNew_splitresult(new_splitresult);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("processSplitRdd cnt:{}", processSplitRdd.count());
        zoneRdd.unpersist();

        JavaPairRDD<String, Iterable<SssDwdWaybillInfoDtlDi>> threeHisWaybillRdd = processSplitRdd.mapToPair(o -> new Tuple2<>(o.getDest_dist_code() + "_" + o.getConsignee_phone(), o))
                .groupByKey()
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("threeHisWaybillRdd cnt:{}", threeHisWaybillRdd.count());
        processSplitRdd.unpersist();


        JavaRDD<SssGisRdsOmsto> gisRdsOmsRdd = loadData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gisRdsOmsRdd cnt:{}", gisRdsOmsRdd.count());

        JavaRDD<SssGisRdsOmsto> splitGisRdsOmsRdd = gisRdsOmsRdd.map(o -> {
            String splitresult = o.getSplitresult();
            if (StringUtils.isNotEmpty(splitresult)) {
                List<String> configList = configBc.value();
                String new_splitresult = processSplitresult(splitresult, configList);
                o.setNew_splitresult(new_splitresult);
            }
            return o;
        }).filter(o -> StringUtils.isNotEmpty(o.getNew_splitresult())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("splitGisRdsOmsRdd cnt:{}", splitGisRdsOmsRdd.count());
        gisRdsOmsRdd.unpersist();

        JavaRDD<SssGisRdsOmsto> filterSrcRdd = splitGisRdsOmsRdd.filter(o -> !StringUtils.equals(o.getGis_to_sys_src(), "auto")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterSrcRdd:{}", filterSrcRdd.count());
        splitGisRdsOmsRdd.unpersist();

        JavaRDD<SssGisRdsOmsto> similarRdd = filterSrcRdd.mapToPair(o -> new Tuple2<>(o.getReq_destcitycode() + "_" + o.getReq_addresseephone(), o)).leftOuterJoin(threeHisWaybillRdd)
                .filter(tp -> {
                    boolean flag = false;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = true;
                    }
                    return flag;
                }).map(tp -> {
                    SssGisRdsOmsto o = tp._2._1;
                    String gis_split = o.getNew_splitresult();
                    List<SssDwdWaybillInfoDtlDi> list = Lists.newArrayList(tp._2._2.get());
                    List<SssDwdWaybillInfoDtlDi> similarList = new ArrayList<>();
                    for (SssDwdWaybillInfoDtlDi sssDwdWaybillInfoDtlDi : list) {
                        String dtldi_split = sssDwdWaybillInfoDtlDi.getNew_splitresult();
                        if (StringUtils.isNotEmpty(dtldi_split)) {
                            if (processSimilar(gis_split, dtldi_split)) {
                                similarList.add(sssDwdWaybillInfoDtlDi);
                            }
                        }
                    }
                    o.setList(similarList);
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("similarRdd cnt:{}", similarRdd.count());
        filterSrcRdd.unpersist();
        threeHisWaybillRdd.unpersist();

        JavaRDD<SssGisRdsOmsto> resultRdd = similarRdd.filter(o -> o.getList() != null && o.getList().size() > 0).filter(o -> {
            boolean flag = true;
            String finalzc = o.getFinalzc();
            List<SssDwdWaybillInfoDtlDi> list = o.getList();
            for (SssDwdWaybillInfoDtlDi sssDwdWaybillInfoDtlDi : list) {
                String dest_zone_code = sssDwdWaybillInfoDtlDi.getDest_zone_code();
                String org_code = sssDwdWaybillInfoDtlDi.getOrg_code();
                if (StringUtils.isNotEmpty(finalzc) && StringUtils.equals(finalzc, dest_zone_code) && StringUtils.equals(finalzc, org_code)) {
                    flag = false;
                    break;
                }
            }
            return flag;
        }).map(o -> {
            List<SssDwdWaybillInfoDtlDi> list = o.getList();
            String tags = list.stream().map(t -> t.getDest_zone_code() + "_" + t.getOrg_code() + "_" + t.getNew_splitresult()).collect(Collectors.joining("#"));
            o.setTags(tags);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        similarRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.sss_gis_rds_omsto drop if EXISTS partition(inc_day='%s')", "20220906"));
        saveData(spark, resultRdd, "20220906", "dm_gis.sss_gis_rds_omsto");

        sc.stop();
    }


    public void saveData(SparkSession spark, JavaRDD<SssGisRdsOmsto> inRdd, String date, String targetTable) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getReq_waybillno(), o.getReq_addresseeaddr(), o.getReq_destcitycode(), o.getReq_addresseephone(), o.getSplitresult(),
                    o.getFinalzc(), o.getGis_to_sys_src(), o.getFinalzc() + "_" + o.getNew_splitresult(), o.getTags()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "req_waybillno", "req_addresseeaddr", "req_destcitycode", "req_addresseephone", "splitresult",
                "finalzc", "gis_to_sys_src", "tag", "tags"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "sss_gis_rds_omsto_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public boolean processSimilar(String gis_split, String dtldi_split) {
        List<String> list = new ArrayList<>();
        String[] split = gis_split.split(",");
        String[] split1 = dtldi_split.split(",");
        for (String s : split) {
            String word = s.split("\\^")[0];
            String level = s.split("\\^")[1];
            for (String s1 : split1) {
                String word1 = s1.split("\\^")[0];
                String level1 = s1.split("\\^")[1];
                if (Integer.parseInt(level) == 9 && Integer.parseInt(level1) == 9) {
                    if (StringUtils.equals(word, word1) || word.contains(word1) || word1.contains(word)) {
                        list.add(level + "_" + word + "#" + level1 + "_" + word1);
                    }
                } else if (StringUtils.equals(word, word1)) {
                    list.add(level + "_" + word + "#" + level1 + "_" + word1);
                }
            }
        }
        if (list.size() == 1) {
            String s = list.get(0);
            String[] tempSplit = s.split("#");
            if (StringUtils.equals(tempSplit[0].split("_")[0], "9") && StringUtils.equals(tempSplit[1].split("_")[0], "9")) {
                List<String> collect_11 = Arrays.stream(split).filter(o -> o.contains("11")).collect(Collectors.toList());
                List<String> collect1_11 = Arrays.stream(split1).filter(o -> o.contains("11")).collect(Collectors.toList());
                if (collect_11.size() > 0 && collect1_11.size() > 0) {
                    if (!StringUtils.equals(collect_11.get(0).split("\\^")[0], collect1_11.get(0).split("\\^")[0])) {
                        return false;
                    }
                }
                List<String> collect_13_18 = Arrays.stream(split).filter(o -> o.contains("13") || o.contains("18")).collect(Collectors.toList());
                List<String> collect1_13_18 = Arrays.stream(split1).filter(o -> o.contains("13") || o.contains("18")).collect(Collectors.toList());
                if (collect_13_18.size() > 0 && collect1_13_18.size() > 0) {
                    List<String> collect_13 = collect_13_18.stream().filter(o -> o.contains("13")).collect(Collectors.toList());
                    List<String> collect_18 = collect_13_18.stream().filter(o -> o.contains("18")).collect(Collectors.toList());
                    String word_13 = "";
                    String word_18 = "";
                    if (collect_13.size() > 0) {
                        word_13 = collect_13.get(0).split("\\^")[0];
                    }
                    if (collect_18.size() > 0) {
                        word_18 = collect_18.get(0).split("\\^")[0];
                    }
                    List<String> collect1_13 = collect1_13_18.stream().filter(o -> o.contains("13")).collect(Collectors.toList());
                    List<String> collect1_18 = collect1_13_18.stream().filter(o -> o.contains("18")).collect(Collectors.toList());
                    String word1_13 = "";
                    String word1_18 = "";
                    if (collect1_13.size() > 0) {
                        word1_13 = collect1_13.get(0).split("\\^")[0];
                    }
                    if (collect1_18.size() > 0) {
                        word1_18 = collect1_18.get(0).split("\\^")[0];
                    }
                    int cnt1 = similarStr(word_13, word1_13);
                    int cnt2 = similarStr(word_13, word1_18);
                    int cnt3 = similarStr(word_18, word1_13);
                    int cnt4 = similarStr(word_18, word1_18);
                    if (cnt1 <= 2 && cnt2 <= 2 && cnt3 <= 2 && cnt4 <= 2) {
                        return false;
                    }
                }
            }

            if (StringUtils.equals(tempSplit[0].split("_")[0], "11") && StringUtils.equals(tempSplit[1].split("_")[0], "11")) {
                List<String> collect_9 = Arrays.stream(split).filter(o -> o.contains("9")).collect(Collectors.toList());
                List<String> collect1_9 = Arrays.stream(split1).filter(o -> o.contains("9")).collect(Collectors.toList());
                int cnt = 0;
                if (collect_9.size() > 0 && collect1_9.size() > 0) {
                    for (String s1 : collect_9) {
                        String word = s1.split("\\^")[0];
                        for (String s2 : collect1_9) {
                            String word1 = s2.split("\\^")[0];
                            if (StringUtils.isNotEmpty(word) && StringUtils.isNotEmpty(word1) && (word.contains(word1) || word1.contains(word))) {
                                cnt++;
                            }
                        }
                    }
                }
                if (cnt != 0) {
                    return false;
                }
            }
            if ((StringUtils.equals(tempSplit[0].split("_")[0], "5") && StringUtils.equals(tempSplit[1].split("_")[0], "5"))
                    || (StringUtils.equals(tempSplit[0].split("_")[0], "14") && StringUtils.equals(tempSplit[1].split("_")[0], "14"))
                    || (StringUtils.equals(tempSplit[0].split("_")[0], "15") && StringUtils.equals(tempSplit[1].split("_")[0], "15"))
                    || (StringUtils.equals(tempSplit[0].split("_")[0], "16") && StringUtils.equals(tempSplit[1].split("_")[0], "16"))
                    || (StringUtils.equals(tempSplit[0].split("_")[0], "17") && StringUtils.equals(tempSplit[1].split("_")[0], "17"))
                    || (StringUtils.equals(tempSplit[0].split("_")[0], "613") && StringUtils.equals(tempSplit[1].split("_")[0], "613"))) {
                List<String> collect_13 = Arrays.stream(split).filter(o -> o.contains("13")).collect(Collectors.toList());
                List<String> collect1_13 = Arrays.stream(split1).filter(o -> o.contains("13")).collect(Collectors.toList());
                if (collect_13.size() > 0 && collect1_13.size() > 0) {
                    String word = collect_13.get(0).split("\\^")[0];
                    String word1 = collect1_13.get(0).split("\\^")[0];
                    int cnt = similarStr(word, word1);
                    if (cnt <= 2) {
                        return false;
                    }
                }
            }
        }
        return list.size() > 0;
    }

    public int similarStr(String a, String b) {
        int cnt = 0;
        if (StringUtils.isNotEmpty(a) && StringUtils.isNotEmpty(b)) {
            for (int i = 0; i < a.length(); i++) {
                char c = a.charAt(i);
                for (int j = 0; j < b.length(); j++) {
                    char c1 = b.charAt(j);
                    if (c == c1) {
                        cnt++;
                    }
                }
            }
        }
        return cnt;
    }

    public String processSplitresult(String splitresult, List<String> configList) {
        List<String> list = new ArrayList<>();
        String word = splitresult.split(";")[0];
        String[] split = word.split(",");
        for (String s : split) {
            String prefix = s.split("\\^")[0];
            String level = s.split("\\^")[1];
            int i = Integer.parseInt(level.substring(1, level.length()));
            if (i >= 5) {
                if (i == 18 && configList.contains(prefix)) {
                    continue;
                }
                if (StringUtils.equals(level, "613")) {
                    list.add(s);
                } else {
                    list.add(prefix + "^" + i);
                }
            }
        }
        if (list.size() > 0) {
            return list.stream().collect(Collectors.joining(","));
        }
        return "";
    }

    public boolean judgeDeptTypeCode(SssDwdWaybillInfoDtlDi o) {
        String dept_type_code = o.getDept_type_code();
        return !(StringUtils.equals(dept_type_code, "DB05-XMDB") || StringUtils.equals(dept_type_code, "FB04-WXJ") || StringUtils.equals(dept_type_code, "FB04-XMFB")
                || StringUtils.equals(dept_type_code, "FB05-CCPSCK") || StringUtils.equals(dept_type_code, "B04-GLX") || StringUtils.equals(dept_type_code, "DB05-JPZ")
                || StringUtils.equals(dept_type_code, "FB04-KYFB") || StringUtils.equals(dept_type_code, "ZZC04-ERJ") || StringUtils.equals(dept_type_code, "ZZC05-KYJS")
                || StringUtils.equals(dept_type_code, "QB03-KYGS") || StringUtils.equals(dept_type_code, "FB04-ZHB"));
    }

    public JavaRDD<SssDwdWaybillInfoDtlDi> loadData(SparkSession ss, JavaSparkContext jsc, String date, String before90Date, String before93Date) {
        String sql = SqlUtil.getSqlStr("sss_dwd_waybill_info_dtl_di.sql", "20221024", "20220601", "20220831", "20220529", "20220831", "20220831", "20220831", "20220601", "20220831");
        return DataUtil.loadData(ss, jsc, sql, SssDwdWaybillInfoDtlDi.class);
    }

    public JavaRDD<CmsAoiSch> loadCmsData(SparkSession ss, JavaSparkContext jsc) {
        String sql = "select zno_code from dm_gis.cms_aoi_sch where del_flag = '0' group by zno_code";
        return DataUtil.loadData(ss, jsc, sql, CmsAoiSch.class);
    }

    public JavaRDD<SssGisRdsOmsto> loadData(SparkSession ss, JavaSparkContext jsc) {
        String sql = SqlUtil.getSqlStr("sss_gis_rds_omsto.sql", "20221024", "20220906");
        return DataUtil.loadData(ss, jsc, sql, SssGisRdsOmsto.class);
    }
}
