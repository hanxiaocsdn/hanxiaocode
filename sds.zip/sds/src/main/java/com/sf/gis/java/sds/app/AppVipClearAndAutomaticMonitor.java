package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.DkhRdsInfoClear;
import com.sf.gis.scala.base.pojo.Cnt;
import com.sf.gis.scala.base.pojo.StratTime;
import com.sf.gis.scala.base.spark.SparkUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.Optional;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;

/**
 * 任务id：943390（【壹竿-SD】大客户地址自动接入监控及清洗）
 * 研发：01399581（匡仁衡）
 * 业务：01394694（郭本婕）
 */
public class AppVipClearAndAutomaticMonitor {
    private static final Logger logger = Logger.getLogger(AppVipClearAndAutomaticMonitor.class);
    private static final String ar_url = "http://gis-int2.int.sfdc.com.cn:1080/ar/api?address=%s&city=%s&datatype=r01&ak=58d89a9c079d4eff85918822de309c61";
    private static final String segbsp_url = "http://gis-apis.int.sfcloud.local:1080/segbsp/api/split?address=%s&ak=3eb300d2e06947f7945cd02530a32fd2";
    private static final String atpai_url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&city=%s&mobile=%s&company=%s&ak=87106f6380af4df0845a693eee58843c&opt=zh";
    private static final String account = "01399581";
    private static final String taskId = "943390";
    private static final String taskName = "大客户地址自动接入监控及清洗";

    private static final int limitMin = 5000 / 10;

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:" + date);
        String last_month = DateUtil.getDaysBefore(date, 1).substring(0, 6);
        logger.error("last_month:" + last_month);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppVipClearAndAutomaticMonitor");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        logger.error("获取行政区划");
        Set<String> set = getXzqh(sc);
        Broadcast<Set<String>> setBc = sc.broadcast(set);
        logger.error("获取当月大客户数据");
        JavaRDD<DkhRdsInfoClear> monthDataRdd = getMonthData(spark, sc, last_month);
        logger.error("获取在监控中的的大客户数据");
        JavaRDD<DkhRdsInfoClear> monitorVipDataRdd = getMonitorVipData(spark, sc, date);
        logger.error("打标");
        JavaRDD<DkhRdsInfoClear> resultRdd = join(monthDataRdd, monitorVipDataRdd, setBc, date);
        logger.error("存储");
        DataUtil.saveOverwrite(sparkInfo, "dm_gis.vip_clear_and_automatic_monitor", DkhRdsInfoClear.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        logger.error("process end...");

    }

    public static Set<String> getXzqh(JavaSparkContext sc) {
        JavaRDD<String> lineRdd = sc.textFile("hdfs://sfbdp1/user/01399581/upload/yunying_demand/data/xzqh.csv").persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lineRdd cnt:" + lineRdd.count());
        String header = lineRdd.first();
        logger.error("header:" + header);
        Set<String> set = new HashSet<>(lineRdd.filter(line -> !StringUtils.equals(line, header)).flatMap(line -> {
            String[] split = line.split(",");
            return Arrays.stream(split).iterator();
        }).filter(StringUtils::isNotEmpty).collect());
        lineRdd.unpersist();
        logger.error("set size:" + set.size());
        return set;
    }

    public static JavaRDD<DkhRdsInfoClear> join(JavaRDD<DkhRdsInfoClear> monthDataRdd, JavaRDD<DkhRdsInfoClear> monitorVipDataRdd, Broadcast<Set<String>> setBc, String date) {
        JavaRDD<DkhRdsInfoClear> joinRdd = monthDataRdd.mapToPair(o -> new Tuple2<>(o.getAddr(), o)).fullOuterJoin(monitorVipDataRdd.mapToPair(o -> new Tuple2<>(o.getAddr(), o))).flatMap(tp -> {
            Optional<DkhRdsInfoClear> leftOpt = tp._2._1;
            Optional<DkhRdsInfoClear> rightOp = tp._2._2;

            ArrayList<DkhRdsInfoClear> list = new ArrayList<>();
            if (leftOpt.isPresent() && !rightOp.isPresent()) {
                DkhRdsInfoClear left = leftOpt.get();
                left.setTag("new");
                list.add(left);
            } else if (!leftOpt.isPresent() && rightOp.isPresent()) {
                DkhRdsInfoClear right = rightOp.get();
                right.setTag("del");
                list.add(right);
            } else if (leftOpt.isPresent() && rightOp.isPresent()) {
                DkhRdsInfoClear left = leftOpt.get();
                list.add(left);
            }
            return list.iterator();
        }).map(o -> {
            String addr = o.getAddr();
            if (StringUtils.isNotEmpty(addr)) {
                addr = addr.replaceAll("^[-]+", "");
                o.setAddr(addr);
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("joinRdd cnt:" + joinRdd.count());
        monthDataRdd.unpersist();
        monitorVipDataRdd.unpersist();

        JavaRDD<DkhRdsInfoClear> newRdd = joinRdd.filter(o -> "new".equals(o.getTag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DkhRdsInfoClear> del1Rdd = joinRdd.filter(o -> "del".equals(o.getTag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DkhRdsInfoClear> crossRdd = joinRdd.filter(o -> StringUtils.isEmpty(o.getTag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("newRdd cnt:" + newRdd.count());
        logger.error("del1Rdd cnt:" + del1Rdd.count());
        logger.error("crossRdd cnt:" + crossRdd.count());
        joinRdd.unpersist();

        JavaRDD<DkhRdsInfoClear> arAndSegRdd = newRdd.repartition(10).mapPartitionsWithIndex(((index, itr) -> {
            ArrayList<DkhRdsInfoClear> list = new ArrayList<>();
            StratTime stratTime = new StratTime(System.currentTimeMillis());
            Cnt cnt = new Cnt(0);
            while (itr.hasNext()) {
                SparkUtils.limitAkUse(stratTime, cnt, index, limitMin, logger);
                DkhRdsInfoClear o = itr.next();
                String addr = o.getAddr();
                String cityCode = o.getCityCode();
                if (StringUtils.isNotEmpty(addr)) {
                    String req1 = String.format(ar_url, URLEncoder.encode(addr, "UTF-8"), cityCode);
                    String content1 = HttpInvokeUtil.sendGet(req1);
                    String result = "";
                    try {
                        result = JSON.parseObject(content1).getString("result");
                    } catch (Exception e) {
//                    e.printStackTrace();
                    }
                    o.setArsresult(result);
                    o.setArsnormresult(result);

                    String req2 = String.format(segbsp_url, URLEncoder.encode(addr, "UTF-8"));
                    String content2 = HttpInvokeUtil.sendGet(req2);
                    String city_code = "";
                    try {
                        city_code = JSON.parseObject(content2).getJSONObject("result").getJSONObject("data").getString("citycode");
                    } catch (Exception e) {
//                    e.printStackTrace();
                    }
                    o.setSegcitycode(city_code);
                    o.setSegnormcitycode(city_code);
                }
                list.add(o);
            }
            return list.iterator();
        }), false).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("arAndSegRdd cnt:" + arAndSegRdd.count());
        newRdd.unpersist();

        JavaRDD<DkhRdsInfoClear> tagRdd = arAndSegRdd.map(o -> {
            String tag = o.getTag();
            String cityCode = o.getCityCode();
            String segcitycode = o.getSegcitycode();
            String addr = o.getAddr();
            if (StringUtils.isNotEmpty(cityCode) && !StringUtils.equals(cityCode, segcitycode)) {
                tag = "del";
            } else {
                if (StringUtils.isNotEmpty(addr) && !addr.matches(".*[\\u4E00-\\u9FFF]+.*")) {
                    tag = "del";
                } else {
                    int length = addr.length();
                    if (length <= 3) {
                        tag = "del";
                    } else {
                        Set<String> set = setBc.value();
                        for (String s : set) {
                            if (StringUtils.isNotEmpty(addr)) {
                                addr = addr.replaceAll(s, "");
                            } else {
                                break;
                            }
                        }
                        if (StringUtils.isEmpty(addr)) {
                            tag = "del";
                        }
                    }
                }
            }
            o.setTag(tag);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:" + tagRdd.count());
        arAndSegRdd.unpersist();

        JavaRDD<DkhRdsInfoClear> del2Rdd = tagRdd.filter(o -> StringUtils.equals(o.getTag(), "del")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<DkhRdsInfoClear> otherRdd = tagRdd.filter(o -> !StringUtils.equals(o.getTag(), "del")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("del2Rdd cnt:" + del2Rdd.count());
        logger.error("otherRdd cnt:" + otherRdd.count());
        tagRdd.unpersist();

        JavaRDD<DkhRdsInfoClear> atRdd = otherRdd.repartition(2).map(o -> {
            String addr = o.getAddr();
            String cityCode = o.getCityCode();
            String phone = o.getPhone();
            String compName = o.getCompName();
            if (StringUtils.isNotEmpty(addr)) {
                //重跑atpai获取最新aoisrc及groupid，aoiid, aoiunit,deptsrc,dept
                String req = String.format(atpai_url, URLEncoder.encode(addr, "UTF-8"), cityCode, phone, URLEncoder.encode(compName, "UTF-8"));
                String content = HttpInvokeUtil.sendGet(req);
                setProp(o, content);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atRdd cnt:" + atRdd.count());
        otherRdd.unpersist();

        JavaRDD<DkhRdsInfoClear> resultRdd = del2Rdd.union(atRdd).union(del1Rdd).union(crossRdd).map(o -> {
            o.setIncDay(date);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:" + resultRdd.count());
        del2Rdd.unpersist();
        atRdd.unpersist();
        del1Rdd.unpersist();
        crossRdd.unpersist();
        return resultRdd;
    }

    public static void setProp(DkhRdsInfoClear o, String content) {
        String aoiid = "";
        String aoicode = "";
        String atAoiSrc = "";
        String dept = "";
        String atDeptSrc = "";
        String groupid = "";
        String aoiunit = "";
        try {
            JSONObject jsonObject = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0);
            aoiid = jsonObject.getString("aoiid");
            aoicode = jsonObject.getString("aoicode");
            atAoiSrc = jsonObject.getString("atAoiSrc");
            atDeptSrc = jsonObject.getString("atDeptSrc");
            dept = jsonObject.getString("dept");
            groupid = jsonObject.getString("groupid");
            aoiunit = jsonObject.getString("aoiUnit");

        } catch (Exception e) {
//            e.printStackTrace();
        }

        String chknId = "";
        try {
            chknId = JSON.parseObject(content).getJSONObject("result").getJSONObject("id_list").getString("chknId");
        } catch (Exception e) {
//                e.printStackTrace();
        }

        o.setAoi_id_at(aoiid);
        o.setAoi_code_at(aoicode);
        o.setAoi_src_at(atAoiSrc);
        o.setDeptsrc_at(atDeptSrc);
        o.setDept_at(dept);
        o.setAoi_unit_at(aoiunit);

        if ("chkn".equals(atAoiSrc)) {
            o.setGroup1_at(chknId);
        } else if ("chkn".equals(atDeptSrc) && StringUtils.isEmpty(atAoiSrc)) {
            o.setGroup1_at(chknId);
        } else if ("norm".equals(atAoiSrc)) {
            o.setGroup1_at(groupid);
        }

    }

    public static JavaRDD<DkhRdsInfoClear> getMonthData(SparkSession spark, JavaSparkContext sc, String last_month) {
        String sql = String.format("SELECT" +
                "  city_code," +
                "  detail_addr," +
                "  regexp_replace(addr, '[\\\\r\\\\s\\\\n\\0,\\,,\"]+', '') addr," +
                "  aoi_80xy," +
                "  group_id," +
                "  phone," +
                "  comp_name," +
                "  ttl_cnt," +
                "  ttl_freight," +
                "  cnt," +
                "  freight," +
                "  zc," +
                "  zc_src," +
                "  aoi_id," +
                "  aoi_code," +
                "  aoi_src," +
                "  aoi_unit" +
                "  FROM" +
                "  dm_gis.dwd_dkh_rds_mf" +
                "  where" +
                "  inc_day = '%s'" +
                "  and (city_code <> '' and city_code is not null)" +
                "  and city_code not in ('853', '852', '886')", last_month);
        JavaRDD<DkhRdsInfoClear> rdd = DataUtil.loadData(spark, sc, sql, DkhRdsInfoClear.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());
        return rdd;
    }

    public static JavaRDD<DkhRdsInfoClear> getMonitorVipData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("SELECT citycode city_code,regexp_replace(address, '[\\\\r\\\\s\\\\n\\0,\\,,\"]+','') addr from dm_gis.atpai_vip_addres_console where inc_day = '%s' group by citycode,regexp_replace(address, '[\\\\r\\\\s\\\\n\\0,\\,,\"]+','')", date);
        JavaRDD<DkhRdsInfoClear> monitorVipRdd = DataUtil.loadData(spark, sc, sql, DkhRdsInfoClear.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("monitorVipRdd cnt:" + monitorVipRdd.count());
        return monitorVipRdd;
    }


}
