package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class In45Addedvalue implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "service_fee")
    private String service_fee;
    @Column(name = "service_prod_name")
    private String service_prod_name;
    @Column(name = "pickup_barsn")
    private String pickup_barsn;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "pay_cust_type")
    private String pay_cust_type;
    @Column(name = "freight_payment_type_code")
    private String freight_payment_type_code;
    @Column(name = "payment_type_code")
    private String payment_type_code;
    @Column(name = "consigned_tm")
    private String consigned_tm;
    @Column(name = "src")
    private String src;
    @Column(name = "status")
    private String status;
    @Column(name = "iselevator")
    private String iselevator;
    @Column(name = "isclimb")
    private String isclimb;
    @Column(name = "floor")
    private String floor;
    @Column(name = "err")
    private String err;
    @Column(name = "msg")
    private String msg;
    @Column(name = "message")
    private String message;
    @Column(name = "log")
    private String log;
    @Column(name = "group_id")
    private String group_id;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoitypecode")
    private String aoitypecode;
    @Column(name = "opcode")
    private String opcode;
    @Column(name = "inc_day")
    private String inc_day;

    private String region;
    private String city;

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getService_fee() {
        return service_fee;
    }

    public void setService_fee(String service_fee) {
        this.service_fee = service_fee;
    }

    public String getService_prod_name() {
        return service_prod_name;
    }

    public void setService_prod_name(String service_prod_name) {
        this.service_prod_name = service_prod_name;
    }

    public String getPickup_barsn() {
        return pickup_barsn;
    }

    public void setPickup_barsn(String pickup_barsn) {
        this.pickup_barsn = pickup_barsn;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getPay_cust_type() {
        return pay_cust_type;
    }

    public void setPay_cust_type(String pay_cust_type) {
        this.pay_cust_type = pay_cust_type;
    }

    public String getFreight_payment_type_code() {
        return freight_payment_type_code;
    }

    public void setFreight_payment_type_code(String freight_payment_type_code) {
        this.freight_payment_type_code = freight_payment_type_code;
    }

    public String getPayment_type_code() {
        return payment_type_code;
    }

    public void setPayment_type_code(String payment_type_code) {
        this.payment_type_code = payment_type_code;
    }

    public String getConsigned_tm() {
        return consigned_tm;
    }

    public void setConsigned_tm(String consigned_tm) {
        this.consigned_tm = consigned_tm;
    }

    public String getSrc() {
        return src;
    }

    public void setSrc(String src) {
        this.src = src;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getIselevator() {
        return iselevator;
    }

    public void setIselevator(String iselevator) {
        this.iselevator = iselevator;
    }

    public String getIsclimb() {
        return isclimb;
    }

    public void setIsclimb(String isclimb) {
        this.isclimb = isclimb;
    }

    public String getFloor() {
        return floor;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public String getErr() {
        return err;
    }

    public void setErr(String err) {
        this.err = err;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getLog() {
        return log;
    }

    public void setLog(String log) {
        this.log = log;
    }

    public String getGroup_id() {
        return group_id;
    }

    public void setGroup_id(String group_id) {
        this.group_id = group_id;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoitypecode() {
        return aoitypecode;
    }

    public void setAoitypecode(String aoitypecode) {
        this.aoitypecode = aoitypecode;
    }

    public String getOpcode() {
        return opcode;
    }

    public void setOpcode(String opcode) {
        this.opcode = opcode;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
