package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.List;

@Table
public class PathFix implements Serializable, Comparable<PathFix> {
    @Column(name = "un")
    private String un;
    @Column(name = "req")
    private String req;
    @Column(name = "bn")
    private String bn;
    @Column(name = "rsp")
    private String rsp;

    private String hour;
    private double distance;
    private List<SaTrajectoryAoi> list;

    public List<SaTrajectoryAoi> getList() {
        return list;
    }

    public void setList(List<SaTrajectoryAoi> list) {
        this.list = list;
    }

    public String getBn() {
        return bn;
    }

    public void setBn(String bn) {
        this.bn = bn;
    }

    public String getRsp() {
        return rsp;
    }

    public void setRsp(String rsp) {
        this.rsp = rsp;
    }

    public String getHour() {
        return hour;
    }

    public void setHour(String hour) {
        this.hour = hour;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public String getUn() {
        return un;
    }

    public void setUn(String un) {
        this.un = un;
    }

    public String getReq() {
        return req;
    }

    public void setReq(String req) {
        this.req = req;
    }

    @Override
    public int compareTo(PathFix o) {
        double distance = this.getDistance();
        double distance1 = o.getDistance();
        if (distance > distance1) {
            return 1;
        } else if (distance < distance1) {
            return -1;
        }
        return 0;
    }
}
