package com.sf.gis.java.sds.app;


import com.alibaba.fastjson.JSON;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.BdpTaskRecordUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.Specialstorage21RetentionData;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;

import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * 任务id：1002052（特殊入仓21滞留数据表搭建）
 * 研发：01399581（匡仁衡）
 * 业务：01412980（潘宜鹏）
 */
public class AppSpecialstorage_21RetentionData {
    private static final Logger logger = Logger.getLogger(AppSpecialstorage_21RetentionData.class);
    private static final String url = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?ak=9c1d529c40f54877a9a6372e686fee47&address=%s&city=%s&opt=zh&company=%s";

    private static final String account = "01399581";
    private static final String taskId = "1002052";
    private static final String taskName = "特殊入仓21滞留数据表搭建";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:" + date);
        SparkInfo sparkInfo = SparkUtil.getSpark("AppSpecialstorage_21RetentionData");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        logger.error("取数");
        JavaRDD<Specialstorage21RetentionData> rdd = getData(spark, sc, date);
        logger.error("获取网点、aoi");
        JavaRDD<Specialstorage21RetentionData> aoiRdd = api(spark, rdd);
        logger.error("存储");
        DataUtil.saveOverwrite(spark, sc, "dm_gis.dwd_specialstorage_21_retention_data_di", Specialstorage21RetentionData.class, aoiRdd, "inc_day");
        aoiRdd.unpersist();
        sc.stop();

    }

    public static JavaRDD<Specialstorage21RetentionData> api(SparkSession spark, JavaRDD<Specialstorage21RetentionData> rdd) {
        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", url, "9c1d529c40f54877a9a6372e686fee47", rdd.count(), 2);
        JavaRDD<Specialstorage21RetentionData> aoiRdd = rdd.map(o -> {
            String address = o.getAddress();
            String citycode = o.getCitycode();
            String company_name = o.getCompany_name();
            if (StringUtils.isNotEmpty(address)) {
                String req = String.format(url, URLEncoder.encode(address, "UTF-8"), citycode, StringUtils.isNotEmpty(company_name) ? URLEncoder.encode(company_name, "UTF-8") : "");
                String resp = HttpInvokeUtil.sendGet(req);
//                o.setResp(resp);
                String dept = "";
                String aoiid = "";
                String aoicode = "";

                try {
                    dept = JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("dept");
                    aoiid = JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid");
                    aoicode = JSON.parseObject(resp).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoicode");
                } catch (Exception e) {
                    e.printStackTrace();
                }

                o.setDept(dept);
                o.setAoiid(aoiid);
                o.setAoicode(aoicode);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:" + aoiRdd.count());
        rdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);
        return aoiRdd;
    }

    public static JavaRDD<Specialstorage21RetentionData> getData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select address_id,citycode,address,warehouseid,company_name,inc_day from dm_gis.specialstorage_baseaddress_suyun where inc_day = '%s' and del_flag = '0'", date);
        JavaRDD<Specialstorage21RetentionData> rdd = DataUtil.loadData(spark, sc, sql, Specialstorage21RetentionData.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:" + rdd.count());
        return rdd;
    }
}
