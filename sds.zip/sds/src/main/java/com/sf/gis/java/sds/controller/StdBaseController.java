package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.pojo.*;
import com.sf.gis.java.sds.service.StdBaseService;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class StdBaseController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(StdBaseController.class);
    StdBaseService service = new StdBaseService();
    private static String atdispatchUrl = "http://gis-int2.int.sfdc.com.cn:1080/atdispatchlite/api?address=%s&city=%s&ak=1f7a7412dabd4d219129ff96e3b522fb&opt=normdetail&company=";
    // ak每分钟限速 / 并发数
    private static int limitMin = 20000 / 40;

    public void start(String startDate, String endDate) {
        //初始化spark
//        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
//        JavaSparkContext sc = sparkInfo.getContext();
//        SparkSession spark = sparkInfo.getSession();
        SparkSession spark = Spark.getSparkSession("StdBaseController", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());


        Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCodeSet);
        Broadcast<String> regexBc = sc.broadcast("\\(.*?\\)|（.*?）|\\<.*?\\>|《.*?》|【.*?】|\\[.*?\\]|[^\\-0-9a-zA-Z\\u4e00-\\u9fa5]");


        //获取city,region,citycode映射关系表
        List<CityNameMap> cityNameMapList = service.loadCityNameMapNew(spark, sc, DateUtil.getDaysBefore(startDate, -2)).collect();
        logger.error("cityNameMapList cnt:{}", cityNameMapList.size());
        Broadcast<List<CityNameMap>> cityNameMapListBc = sc.broadcast(cityNameMapList);

        Map<String, ZnocodeDepartcodeMapping> map = service.loadZnoCodeDepartCode(spark, sc).collect().stream().collect(Collectors.toMap(ZnocodeDepartcodeMapping::getZnocode, t -> t, (key1, key2) -> key2));
        logger.error("map cnt:{}", map.size());
        Broadcast<Map<String, ZnocodeDepartcodeMapping>> mapBc = sc.broadcast(map);

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (String date : dates) {
            logger.error("date:{}", date);
            Broadcast<String> dateBc = sc.broadcast(date);

            //获取派件请求报表数据
            JavaRDD<TalsGisRdsOmsto> rdsOmstoRdd = service.loadRdsOmstoData(spark, sc, date).filter(o -> StringUtils.isNotEmpty(o.getDeptcode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("rdsOmstoRdd cnt:{}", rdsOmstoRdd.count());

            //通过citycode补充region,req_city
            JavaRDD<TalsGisRdsOmsto> cityNameRdd = rdsOmstoRdd.map(o -> {
                List<CityNameMap> cityNameMapListTemp = cityNameMapListBc.value();
                String req_destcitycode = o.getReq_destcitycode();
                List<CityNameMap> collect = cityNameMapListTemp.stream().filter(t -> StringUtils.equals(t.getCitycode(), req_destcitycode)).collect(Collectors.toList());
                if (collect.size() > 0) {
                    o.setRegion(collect.get(0).getRegion());
                    o.setArea(collect.get(0).getArea());
                    o.setReq_city(collect.get(0).getCity());
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cityNameRdd cnt:{}", cityNameRdd.count());
            rdsOmstoRdd.unpersist();

            JavaRDD<TalsGisRdsOmsto> deptRdd = cityNameRdd.map(o -> {
                String dept = "";
                String at_pai_body = o.getAt_pai_body();
                if (StringUtils.isNotEmpty(at_pai_body) && at_pai_body.contains("tcs")) {
                    JSONObject jsonObject = JSON.parseObject(at_pai_body);
                    JSONArray tcs = jsonObject.getJSONArray("tcs");
                    if (tcs != null) {
                        JSONObject jsonObject1 = tcs.getJSONObject(0);
                        if (jsonObject1 != null) {
                            dept = jsonObject1.getString("dept");
                            String atDeptSrc = jsonObject1.getString("atDeptSrc");
                            String atAoiSrc = jsonObject1.getString("atAoiSrc");
                            o.setAtdept(dept);
                            o.setAtdept_src(atDeptSrc);
                            o.setAtaoi_src(atAoiSrc);
                        }
                    }
                } else {
                    String re_body_latest = o.getRe_body_latest();
                    if (StringUtils.isNotEmpty(re_body_latest)) {
                        JSONObject jsonObject = JSON.parseObject(re_body_latest);
                        if (jsonObject != null) {
                            String abnormSrc = jsonObject.getString("abnormSrc");
                            if (StringUtils.isNotEmpty(abnormSrc)) {
                                o.setAt_abnormSrc(abnormSrc.toLowerCase());
                                dept = jsonObject.getString("addresseeDeptCode");
                                o.setAtdept(dept);
                                o.setAtdept_src(abnormSrc.toLowerCase());
                                o.setAtaoi_src(abnormSrc.toLowerCase());
                            }
                        }
                    }
                }
                if (StringUtils.isNotEmpty(dept)) {
                    Map<String, ZnocodeDepartcodeMapping> value = mapBc.value();
                    o.setTypecode(value.get(dept) != null ? value.get(dept).getTypecode() : "");
                }
                String ks_re_body = o.getKs_re_body();
                if (StringUtils.isNotEmpty(ks_re_body)) {
                    String ksdept_src = "";
                    String ksaoi_src = "";

                    try {
                        ksdept_src = JSON.parseObject(ks_re_body).getJSONObject("result").getString("zcTag");
                        ksaoi_src = JSON.parseObject(ks_re_body).getJSONObject("result").getString("aoiTag");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                    o.setKsdept_src(ksdept_src);
                    o.setKsaoi_src(ksaoi_src);
                }

                o.setRe_body_latest("");
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("deptRdd cnt:{}", deptRdd.count());
            cityNameRdd.unpersist();

            JavaRDD<TalsGisRdsOmsto> chknRdd = deptRdd.filter(o -> StringUtils.equals(o.getKsdept_src(), "company") || StringUtils.equals(o.getKsaoi_src(), "company") || StringUtils.equals(o.getAtdept_src(), "chkn") || (StringUtils.equals(o.getAtdept_src(), "normhp") && (StringUtils.equals(o.getTypecode(), "DB05-XMDB") || StringUtils.equals(o.getTypecode(), "FB04-XMFB"))) || (StringUtils.isNotEmpty(o.getAtdept_src()) && o.getAtdept_src().contains("phone"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<TalsGisRdsOmsto> noChknRdd = deptRdd.filter(o -> !(StringUtils.equals(o.getKsdept_src(), "company") || StringUtils.equals(o.getKsaoi_src(), "company") || StringUtils.equals(o.getAtdept_src(), "chkn") || (StringUtils.equals(o.getAtdept_src(), "normhp") && (StringUtils.equals(o.getTypecode(), "DB05-XMDB") || StringUtils.equals(o.getTypecode(), "FB04-XMFB"))) || (StringUtils.isNotEmpty(o.getAtdept_src()) && o.getAtdept_src().contains("phone")))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("chknRdd cnt:{}", chknRdd.count());
            logger.error("noChknRdd cnt:{}", noChknRdd.count());
            deptRdd.unpersist();

            JavaRDD<TalsGisRdsOmsto> atpRdd = chknRdd.repartition(40).mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<TalsGisRdsOmsto> list = new ArrayList<>();
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMin) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    TalsGisRdsOmsto o = itr.next();
                    String addr = o.getReq_addresseeaddr();
                    String content = "";
                    if (StringUtils.isNotEmpty(addr)) {
                        if (StringUtils.equals(o.getKsdept_src(), "company") || StringUtils.equals(o.getKsaoi_src(), "company")) {
                            addr = addr.replaceAll(regexBc.value(), "") + o.getReq_comp_name();
                        }
                        content = service.runAtdispatch(atdispatchUrl, addr, o.getReq_destcitycode(), acLimitCodeSetBc.value());
                        o.setResp(content);
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = JSON.parseObject(content);
                            int status = jsonObject.getInteger("status");
                            if (status == 0) {
                                JSONObject result = jsonObject.getJSONObject("result");
                                JSONArray tcs = result.getJSONArray("tcs");
                                String dept = tcs.getJSONObject(0).getString("dept");
                                String groupid = tcs.getJSONObject(0).getString("groupid");
                                String aoicode = tcs.getJSONObject(0).getString("aoicode");
                                if (StringUtils.equals(o.getAtdept_src(), "chkn")) {
                                    o.setDept_chkn(dept);
                                    o.setGroupid_chkn(groupid);
                                    o.setAoi_chkn(aoicode);
                                    JSONObject other = result.getJSONObject("other");
                                    if (other != null) {
                                        JSONObject normresp = other.getJSONObject("normresp");
                                        if (normresp != null) {
                                            Boolean success = normresp.getBoolean("success");
                                            if (success) {
                                                JSONObject result1 = normresp.getJSONObject("result");
                                                if (result1 != null) {
                                                    Integer status1 = result1.getInteger("status");
                                                    if (status1 == 0) {
                                                        JSONArray geocoder = result1.getJSONArray("geocoder");
                                                        String groupids_chkn_list = "";
                                                        String filters_chkn_list = "";
                                                        for (int i = 0; i < geocoder.size(); i++) {
                                                            String group = geocoder.getJSONObject(i).getString("group");
                                                            Integer filter = geocoder.getJSONObject(i).getInteger("filter");

                                                            if (StringUtils.isNotEmpty(group)) {
                                                                groupids_chkn_list = groupids_chkn_list.concat(group).concat("$");
                                                            }
                                                            if (filter != null) {
                                                                filters_chkn_list = filters_chkn_list.concat(String.valueOf(filter)).concat("$");
                                                            }
                                                        }
                                                        o.setGroupids_chkn(groupids_chkn_list.replaceAll("(\\$)$", ""));
                                                        o.setFilters_chkn(filters_chkn_list.replaceAll("(\\$)$", ""));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else if (StringUtils.equals(o.getAtdept_src(), "normhp") && (StringUtils.equals(o.getTypecode(), "DB05-XMDB") || StringUtils.equals(o.getTypecode(), "FB04-XMFB"))) {
                                    o.setDept_hp(dept);
                                    o.setAoi_hp(aoicode);
                                } else if (StringUtils.isNotEmpty(o.getAtdept_src()) && o.getAtdept_src().contains("phone")) {
                                    o.setDept_phone(dept);
                                    o.setAoi_phone(aoicode);
                                }

                                if (StringUtils.equals(o.getKsdept_src(), "company") || StringUtils.equals(o.getKsaoi_src(), "company")) {
                                    o.setDept_ks(dept);
                                    o.setAoi_ks(aoicode);
                                }
                            }
                        }
                    }
                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("atpRdd cnt:{}", atpRdd.count());
            chknRdd.unpersist();

            JavaRDD<TalsGisRdsOmsto> ysDeptChknRdd = atpRdd.map(o -> {
                String dept_chkn = o.getDept_chkn();
                Map<String, ZnocodeDepartcodeMapping> value = mapBc.value();
                o.setYs_dept_chkn(value.get(dept_chkn) != null ? value.get(dept_chkn).getDepartcode() : "");
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("ysDeptChknRdd cnt:{}", ysDeptChknRdd.count());
            atpRdd.unpersist();

            JavaRDD<TalsGisRdsOmsto> unionRdd = ysDeptChknRdd.union(noChknRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("unionRdd cnt:{}", unionRdd.count());
            ysDeptChknRdd.unpersist();
            noChknRdd.unpersist();

            JavaRDD<TalsGisRdsOmsto> ysAtdeptRdd = unionRdd.map(o -> {
                String atdept = o.getAtdept();
                Map<String, ZnocodeDepartcodeMapping> value = mapBc.value();
                o.setYs_atdept(value.get(atdept) != null ? value.get(atdept).getDepartcode() : "");
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("ysAtdeptRdd cnt:{}", ysAtdeptRdd.count());
            unionRdd.unpersist();

            JavaRDD<TalsGisRdsOmsto> resultRdd = ysAtdeptRdd.map(o -> {
                String deptcode = o.getDeptcode();
                if (StringUtils.isNotEmpty(deptcode)) {
                    Map<String, ZnocodeDepartcodeMapping> value = mapBc.value();
                    o.setYs_deptcode(value.get(deptcode) != null ? value.get(deptcode).getDepartcode() : "");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("resultRdd cnt:{}", resultRdd.count());
            ysAtdeptRdd.unpersist();

            //存储数据
            spark.sql(String.format("alter table dm_gis.norm_tt_pai1 drop if EXISTS partition(inc_day='%s')", date));
            service.saveData(spark, resultRdd, date);

            String key_city = resultRdd.mapToPair(o -> new Tuple2<>(o.getReq_destcitycode(), 1))
                    .reduceByKey(Integer::sum)
                    .mapToPair(tp -> new Tuple2<>(tp._2, tp._1))
                    .sortByKey(false)
                    .take(1).get(0)._2();
            logger.error("key_city : {}", key_city);

            JavaRDD<TalsGisRdsOmsto> eqKeyCityRdd = resultRdd.filter(o -> StringUtils.equals(o.getReq_destcitycode(), key_city)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<TalsGisRdsOmsto> noEqKeyCityRdd = resultRdd.filter(o -> !StringUtils.equals(o.getReq_destcitycode(), key_city)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("eqKeyCityRdd cnt:{}", eqKeyCityRdd.count());
            logger.error("noEqKeyCityRdd cnt:{}", noEqKeyCityRdd.count());
            resultRdd.unpersist();

            StatNormTtPai city1 = processSingleStat(eqKeyCityRdd, "CITY", date);
            eqKeyCityRdd.unpersist();
            List<StatNormTtPai> list_stat = new ArrayList<StatNormTtPai>();
            list_stat.add(city1);

            JavaRDD<StatNormTtPai> statNormTtPaiAllRdd = sc.parallelize(list_stat).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("statNormTtPaiAllRdd cnt:{}", statNormTtPaiAllRdd.count());

            //城市维度
            JavaRDD<StatNormTtPai> statNormTtPaiCityRdd = noEqKeyCityRdd.mapToPair(o -> new Tuple2<>(o.getReq_destcitycode(), o)).groupByKey(2400).map(tp -> processStat("CITY", tp._1, dateBc.value(), Lists.newArrayList(tp._2))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("statNormTtPaiCityRdd cnt:{}", statNormTtPaiCityRdd.count());
            noEqKeyCityRdd.unpersist();


            JavaRDD<StatNormTtPai> finalRdd = statNormTtPaiAllRdd.union(statNormTtPaiCityRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("finalRdd cnt:{}", finalRdd.count());
            statNormTtPaiAllRdd.unpersist();
            statNormTtPaiCityRdd.unpersist();

            spark.sql(String.format("alter table dm_gis.norm_tt_pai_stat_new drop if EXISTS partition(inc_day='%s')", date));
            service.saveStatData(spark, finalRdd, "dm_gis.norm_tt_pai_stat_new", date);
            finalRdd.unpersist();
        }

        spark.stop();

    }

    public StatNormTtPai processSingleStat(JavaRDD<TalsGisRdsOmsto> resultRdd, String stat_type, String date) {
        //号铺-网点识别量
        long hp_zc_num = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDept_hp())).count();

        //号铺-aoi识别量
        long hp_aoi_num = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_hp())).count();

        //电话-网点识别量
        long phone_zc_num = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDept_phone())).count();

        //电话-aoi识别量
        long phone_aoi_num = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_phone())).count();

        //有妥投网点工单总量
        long tt_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode())).count();

        //chkn识别量
        long chkn_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.equals(o.getAtdept_src(), "chkn")).count();

        //其他来源识别量
        long other_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && !StringUtils.equals(o.getAtdept_src(), "chkn")).count();

        //非审补-geo识别量
        long log_norm_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && !StringUtils.equals(o.getAtdept_src(), "chkn")
                && StringUtils.isNotEmpty(o.getGroupids()) && service.judge_groupids(o.getGroupids())
                && service.judge_filters(o.getFilters())).count();

        //审补-geo识别量
        long chkn_norm_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.isNotEmpty(o.getGroupids_chkn()) && service.judge_groupids(o.getGroupids_chkn())
                && service.judge_filters(o.getFilters_chkn())).count();

        //非审补-大组重复量
        long log_muti_group_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && !StringUtils.equals(o.getAtdept_src(), "chkn")
                && StringUtils.isNotEmpty(o.getGroupids()) && service.judge_groupids(o.getGroupids())
                && StringUtils.isNotEmpty(o.getFilters()) && service.judge_filters(o.getFilters())
                && service.calGroupidNum(o.getGroupids()) >= 2).count();

        //审补-大组重复量
        long chkn_muti_group_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.equals(o.getAtdept_src(), "chkn")
                && StringUtils.isNotEmpty(o.getGroupids_chkn()) && service.judge_groupids(o.getGroupids_chkn())
                && service.judge_filters(o.getFilters_chkn()) && service.calGroupidNum(o.getGroupids_chkn()) >= 2).count();

        //非审补-网点识别量
        long log_zc_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normhp") || StringUtils.equals(o.getAtdept_src(), "normcompany"))
                && StringUtils.isNotEmpty(o.getAtdept())).count();

        //非审补-网点识别量
        long log_zc_num_all_new = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normcompany"))
                && StringUtils.isNotEmpty(o.getAtdept())).count();

        //审补-网点识别量
        long chkn_zc_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.isNotEmpty(o.getDept_chkn())).count();

        //非审补-网点一致量
        long log_zc_correct_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normhp") || StringUtils.equals(o.getAtdept_src(), "normcompany"))
                && StringUtils.isNotEmpty(o.getAtdept()) && StringUtils.equals(o.getYs_deptcode(), o.getYs_atdept())).count();

        long log_zc_correct_num_all_new = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normcompany"))
                && StringUtils.isNotEmpty(o.getAtdept()) && StringUtils.equals(o.getYs_deptcode(), o.getYs_atdept())).count();

        //审补-网点一致量
        long chkn_zc_correct_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.isNotEmpty(o.getDept_chkn())
                && StringUtils.equals(o.getYs_deptcode(), o.getYs_dept_chkn())).count();

        //非审补-aoi识别量
        long log_aoi_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getGisaoicode()) && (StringUtils.equals(o.getAtaoi_src(), "norm") || StringUtils.equals(o.getAtaoi_src(), "normcompany"))).count();

        //审补-aoi识别量
        long chkn_aoi_num_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_chkn()) && StringUtils.equals(o.getAtaoi_src(), "chkn")).count();

        //其他来源aoi识别量
        long other_num_aoi_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getGisaoicode()) && !StringUtils.equals(o.getAtaoi_src(), "chkn")).count();

        //chknaoi识别量
        long chkn_num_aoi_all = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getGisaoicode()) && StringUtils.equals(o.getAtaoi_src(), "chkn")).count();

        //Ks-网点识别量
        long ks_zc_num = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getDept_ks())).count();

        //Ks-aoi识别量
        long ks_aoi_num = resultRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi_ks())).count();


        StatNormTtPai snt = new StatNormTtPai();
        snt.setTt_num(tt_num_all);
        snt.setChkn_num(chkn_num_all);
        snt.setOther_num(other_num_all);
        snt.setLog_norm_num(log_norm_num_all);
        snt.setChkn_norm_num(chkn_norm_num_all);
        snt.setLog_muti_group_num(log_muti_group_num_all);
        snt.setChkn_muti_group_num(chkn_muti_group_num_all);
        snt.setLog_zc_num(log_zc_num_all);
        snt.setChkn_zc_num(chkn_zc_num_all);
        snt.setLog_zc_correct_num(log_zc_correct_num_all);
        snt.setChkn_zc_correct_num(chkn_zc_correct_num_all);
        snt.setChkn_num_aoi(chkn_num_aoi_all);
        snt.setOther_num_aoi(other_num_aoi_all);
        snt.setLog_aoi_num(log_aoi_num_all);
        snt.setChkn_aoi_num(chkn_aoi_num_all);
        snt.setLog_zc_num_new(log_zc_num_all_new);
        snt.setLog_zc_correct_num_new(log_zc_correct_num_all_new);

        snt.setHp_zc_num(hp_zc_num);
        snt.setHp_aoi_num(hp_aoi_num);
        snt.setPhone_zc_num(phone_zc_num);
        snt.setPhone_aoi_num(phone_aoi_num);

        snt.setKs_zc_num(ks_zc_num);
        snt.setKs_aoi_num(ks_aoi_num);

        if (StringUtils.equals(stat_type, "ALL")) {
            snt.setArea("ALL");
            snt.setStat_type_content("ALL");

            snt.setRegion("ALL");
            snt.setCityCode("ALL");
            snt.setCity("ALL");
        } else if (StringUtils.equals(stat_type, "AREA")) {
            String area = resultRdd.take(1).get(0).getArea();
            snt.setArea(area);
            snt.setStat_type_content(area);

            snt.setRegion("ALL");
            snt.setCityCode("ALL");
            snt.setCity("ALL");
        } else if (StringUtils.equals(stat_type, "REGION")) {
            TalsGisRdsOmsto talsGisRdsOmsto = resultRdd.take(1).get(0);
            String area = talsGisRdsOmsto.getArea();
            String region = talsGisRdsOmsto.getRegion();

            snt.setArea(area);
            snt.setRegion(region);
            snt.setCityCode("ALL");
            snt.setCity("ALL");
            snt.setStat_type_content(region != null ? region : "");

        } else if (StringUtils.equals(stat_type, "CITY")) {
            TalsGisRdsOmsto talsGisRdsOmsto = resultRdd.take(1).get(0);
            String area = talsGisRdsOmsto.getArea();
            String region = talsGisRdsOmsto.getRegion();
            String cityCode = talsGisRdsOmsto.getReq_destcitycode();
            String city = talsGisRdsOmsto.getReq_city();

            snt.setArea(area);
            snt.setRegion(region);
            snt.setCityCode(cityCode);
            snt.setCity(city);
            snt.setStat_type_content(city != null ? city : "");

        }
        snt.setStat_type(stat_type);
        snt.setInc_day(date);
        snt.setStat_date(date);
        snt.setId(DigestUtils.md5Hex(snt.getStat_date() + snt.getStat_type() + snt.getStat_type_content()));

        return snt;
    }


    public StatNormTtPai processStat(String stat_type, String stat_type_content, String date, List<TalsGisRdsOmsto> list) {
        TalsGisRdsOmsto talsGisRdsOmsto = list.get(0);
        StatNormTtPai st = new StatNormTtPai();

        //号铺-网点识别量
        long hp_zc_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_hp())).count();

        //号铺-aoi识别量
        long hp_aoi_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_hp())).count();

        //电话-网点识别量
        long phone_zc_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDept_phone())).count();

        //电话-aoi识别量
        long phone_aoi_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_phone())).count();

        //有妥投网点工单总量
        long tt_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode())).count();

        //chkn识别量
        long chkn_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.equals(o.getAtdept_src(), "chkn")).count();

        //其他来源识别量
        long other_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && !StringUtils.equals(o.getAtdept_src(), "chkn")).count();

        //非审补-geo识别量
        long log_norm_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && !StringUtils.equals(o.getAtdept_src(), "chkn")
                && StringUtils.isNotEmpty(o.getGroupids()) && service.judge_groupids(o.getGroupids())
                && service.judge_filters(o.getFilters())).count();

        //审补-geo识别量
        long chkn_norm_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.isNotEmpty(o.getGroupids_chkn()) && service.judge_groupids(o.getGroupids_chkn())
                && service.judge_filters(o.getFilters_chkn())).count();

        //非审补-大组重复量
        long log_muti_group_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && !StringUtils.equals(o.getAtdept_src(), "chkn")
                && StringUtils.isNotEmpty(o.getGroupids()) && service.judge_groupids(o.getGroupids())
                && StringUtils.isNotEmpty(o.getFilters()) && service.judge_filters(o.getFilters())
                && service.calGroupidNum(o.getGroupids()) >= 2).count();

        //审补-大组重复量
        long chkn_muti_group_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.equals(o.getAtdept_src(), "chkn")
                && StringUtils.isNotEmpty(o.getGroupids_chkn()) && service.judge_groupids(o.getGroupids_chkn())
                && service.judge_filters(o.getFilters_chkn()) && service.calGroupidNum(o.getGroupids_chkn()) >= 2).count();

        //非审补-网点识别量
        long log_zc_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normcompany") || StringUtils.equals(o.getAtdept_src(), "normhp"))
                && StringUtils.isNotEmpty(o.getAtdept())).count();

        long log_zc_num_new = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normcompany"))
                && StringUtils.isNotEmpty(o.getAtdept())).count();

        //审补-网点识别量
        long chkn_zc_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.isNotEmpty(o.getDept_chkn())).count();

        //非审补-网点一致量
        long log_zc_correct_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normcompany") || StringUtils.equals(o.getAtdept_src(), "normhp"))
                && StringUtils.isNotEmpty(o.getAtdept()) && StringUtils.equals(o.getYs_deptcode(), o.getYs_atdept())).count();

        //非审补-网点一致量
        long log_zc_correct_num_new = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode())
                && (StringUtils.equals(o.getAtdept_src(), "norm") || StringUtils.equals(o.getAtdept_src(), "normcompany"))
                && StringUtils.isNotEmpty(o.getAtdept()) && StringUtils.equals(o.getYs_deptcode(), o.getYs_atdept())).count();

        //审补-网点一致量
        long chkn_zc_correct_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDeptcode()) && StringUtils.isNotEmpty(o.getDept_chkn())
                && StringUtils.equals(o.getYs_deptcode(), o.getYs_dept_chkn())).count();

        //非审补-aoi识别量
        long log_aoi_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getGisaoicode()) && (StringUtils.equals(o.getAtaoi_src(), "norm") || StringUtils.equals(o.getAtaoi_src(), "normcompany"))).count();

        //审补-aoi识别量
        long chkn_aoi_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_chkn()) && StringUtils.equals(o.getAtaoi_src(), "chkn")).count();

        //其他来源aoi识别量
        long other_num_aoi = list.stream().filter(o -> StringUtils.isNotEmpty(o.getGisaoicode()) && !StringUtils.equals(o.getAtaoi_src(), "chkn")).count();

        //chknaoi识别量
        long chkn_num_aoi = list.stream().filter(o -> StringUtils.isNotEmpty(o.getGisaoicode()) && StringUtils.equals(o.getAtaoi_src(), "chkn")).count();

        //Ks-网点识别量
        long ks_zc_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getDept_ks())).count();

        //Ks-aoi识别量
        long ks_aoi_num = list.stream().filter(o -> StringUtils.isNotEmpty(o.getAoi_ks())).count();

        st.setTt_num(tt_num);
        st.setChkn_num(chkn_num);
        st.setOther_num(other_num);
        st.setLog_norm_num(log_norm_num);
        st.setChkn_norm_num(chkn_norm_num);
        st.setLog_muti_group_num(log_muti_group_num);
        st.setChkn_muti_group_num(chkn_muti_group_num);
        st.setLog_zc_num(log_zc_num);
        st.setChkn_zc_num(chkn_zc_num);
        st.setLog_zc_correct_num(log_zc_correct_num);
        st.setChkn_zc_correct_num(chkn_zc_correct_num);
        st.setChkn_num_aoi(chkn_num_aoi);
        st.setOther_num_aoi(other_num_aoi);
        st.setLog_aoi_num(log_aoi_num);
        st.setChkn_aoi_num(chkn_aoi_num);
        st.setLog_zc_num_new(log_zc_num_new);
        st.setLog_zc_correct_num_new(log_zc_correct_num_new);
        st.setHp_zc_num(hp_zc_num);
        st.setHp_aoi_num(hp_aoi_num);
        st.setPhone_zc_num(phone_zc_num);
        st.setPhone_aoi_num(phone_aoi_num);

        st.setKs_zc_num(ks_zc_num);
        st.setKs_aoi_num(ks_aoi_num);

        if (StringUtils.equals(stat_type, "REGION")) {
            String area = talsGisRdsOmsto.getArea();
            String region = talsGisRdsOmsto.getRegion();

            st.setArea(area);
            st.setRegion(region);
            st.setCityCode("ALL");
            st.setCity("ALL");
            st.setStat_type_content(stat_type_content != null ? stat_type_content : "");

        } else if (StringUtils.equals(stat_type, "CITY")) {
            String area = talsGisRdsOmsto.getArea();
            String region = talsGisRdsOmsto.getRegion();
            String cityCode = talsGisRdsOmsto.getReq_destcitycode();
            String city = talsGisRdsOmsto.getReq_city();

            st.setArea(area);
            st.setRegion(region);
            st.setCityCode(cityCode);
            st.setCity(city);
            st.setStat_type_content(city != null ? city : "");

        } else if (StringUtils.equals(stat_type, "AREA")) {
            String area = talsGisRdsOmsto.getArea();

            st.setArea(area);
            st.setRegion("ALL");
            st.setCityCode("ALL");
            st.setCity("ALL");
            st.setStat_type_content(stat_type_content != null ? stat_type_content : "");

        }
        st.setStat_type(stat_type);

        st.setStat_date(date);
        st.setInc_day(date);
        st.setId(DigestUtils.md5Hex(st.getStat_date() + st.getStat_type() + st.getStat_type_content()));

        return st;
    }
}
