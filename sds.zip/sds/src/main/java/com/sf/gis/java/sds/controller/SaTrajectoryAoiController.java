package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.CalPartitionUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.HttpInvokeUtil;
import com.sf.gis.java.sds.pojo.SaTrajectoryAoi;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SaTrajectoryAoiController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(SaTrajectoryAoiController.class);
    private static String url = "http://sds-core-datarun.sf-express.com/datarun/track/getTrackAoiDist?showAoiCode=1";

    public void start(String date) {
        SparkSession spark = Spark.getSparkSession("SaTrajectoryAoiController", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        JavaRDD<SaTrajectoryAoi> rdd = loadTrajectoryData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<SaTrajectoryAoi> coorsRdd = rdd.mapToPair(o -> new Tuple2<>(o.getUn(), o)).groupByKey().flatMap(tp -> {
            List<SaTrajectoryAoi> list = Lists.newArrayList(tp._2);
            if (list.size() > 0) {
                String coor = list.stream().sorted((o1, o2) -> o1.getTm().compareTo(o2.getTm())).map(o -> o.getZx() + "," + o.getZy()).collect(Collectors.joining(";"));
                String content = HttpInvokeUtil.sendPostNew(url, coor, FixedConstant.MAX_TRY_TIME_ONCE);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null && jsonObject.getBoolean("success")) {
                        JSONArray data = jsonObject.getJSONArray("data");
                        if (data != null && data.size() > 0) {
                            for (int i = 0; i < data.size(); i++) {
                                JSONObject jsonObject1 = data.getJSONObject(i);
                                if (jsonObject1 != null) {
                                    String aoiId = jsonObject1.getString("aoiId");
                                    String aoiName = jsonObject1.getString("aoiName");
                                    String trackDist = jsonObject1.getString("trackDist");
                                    logger.error("aoiId:{}", aoiId);
                                    logger.error("aoiName:{}", aoiName);
                                    logger.error("trackDist:{}", trackDist);
                                    JSONArray trackLineWkts = jsonObject1.getJSONArray("trackLineWkts");
                                    if (trackLineWkts != null && trackLineWkts.size() > 0) {
                                        JSONObject jsonObject2 = trackLineWkts.getJSONObject(0);
                                        if (jsonObject2 != null) {
                                            JSONArray coors = jsonObject2.getJSONArray("coors");
                                            if (coors != null && coors.size() > 0) {
                                                for (int i1 = 0; i1 < coors.size(); i1++) {
                                                    JSONObject jsonObject3 = coors.getJSONObject(i1);
                                                    if (jsonObject3 != null) {
                                                        String lng = jsonObject3.getString("lng");
                                                        String lat = jsonObject3.getString("lat");
                                                        list = list.stream().map(o -> {
                                                            if (StringUtils.equals(o.getZx(), lng) && StringUtils.equals(o.getZy(), lat)) {
                                                                o.setAoi(aoiId);
                                                                o.setAoi_name(aoiName);
                                                                o.setAoi_length(trackDist);
                                                            }
                                                            return o;
                                                        }).collect(Collectors.toList());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("coorsRdd cnt:{}", coorsRdd.count());
        rdd.unpersist();

        JavaRDD<SaTrajectoryAoi> aoiRdd = coorsRdd.filter(o -> StringUtils.isNotEmpty(o.getAoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:{}", aoiRdd.count());

        JavaRDD<SaTrajectoryAoi> aoiTrackRdd = aoiRdd.mapToPair(o -> new Tuple2<>(o.getUn() + "_" + o.getAoi(), o)).groupByKey().map(tp -> {
            List<SaTrajectoryAoi> list = Lists.newArrayList(tp._2);
            SaTrajectoryAoi saTrajectoryAoi = list.get(0);
            List<SaTrajectoryAoi> sortTmList = list.stream().sorted((o1, o2) -> o1.getTm().compareTo(o2.getTm())).collect(Collectors.toList());
            String start_tm = sortTmList.get(0).getTm();
            String end_tm = sortTmList.get(sortTmList.size() - 1).getTm();
            if (StringUtils.isNotEmpty(start_tm) && StringUtils.isNotEmpty(end_tm)) {
                long interval_tm = Long.parseLong(end_tm) - Long.parseLong(start_tm);
                saTrajectoryAoi.setAoi_interval_tm(interval_tm + "");
            }
            long count = list.stream().map(o -> o.getZx() + "_" + o.getZy()).distinct().count();
            saTrajectoryAoi.setAoi_track_size(count + "");
            return saTrajectoryAoi;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiTrackRdd cnt:{}", aoiTrackRdd.count());
        aoiRdd.unpersist();

        JavaRDD<CmsAoiSch> cmsAoiSchRdd = getCmsAoiSch(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        JavaRDD<SaTrajectoryAoi> resultRdd = aoiTrackRdd.mapToPair(o -> new Tuple2<>(o.getAoi(), o))
                .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)))
                .map(tp -> {
                    SaTrajectoryAoi o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        String city_code = tp._2._2.get().getCity_code();
                        o.setCitycode(city_code);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        aoiTrackRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        spark.sql(String.format("alter table dm_gis.esg_gis_loc_trajectory_length drop if EXISTS partition(inc_day='%s')", date));
        saveData(spark, resultRdd, date, "dm_gis.esg_gis_loc_trajectory_length");
        resultRdd.unpersist();
    }

    public void saveData(SparkSession spark, JavaRDD<SaTrajectoryAoi> inRdd, String date, String targetTable) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getAoi(), o.getAoi_name(), o.getUn(), o.getAoi_length(), o.getAoi_interval_tm(), o.getAoi_track_size(), o.getCitycode()
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        if (rows.count() > 0) {
            int partSize = CalPartitionUtil.getPartitionSize(rows);
            List<StructField> structFieldList = new ArrayList<>();
            String[] columnNames = new String[]{"aoi", "aoi_name", "un", "aoi_length", "aoi_interval_tm", "aoi_track_size", "city_code"};
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }
            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = spark.createDataFrame(rows.repartition(partSize), structType);
            String tempTable = "esg_gis_loc_trajectory_length_" + System.currentTimeMillis();
            ds.createOrReplaceTempView(tempTable);
            logger.error("targetTable:{}", targetTable);
            spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                    "select * from %s", targetTable, date, tempTable));
            rows.unpersist();
            spark.catalog().dropTempView(tempTable);
        }
    }

    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,city_code from dm_gis.cms_aoi_sch";
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public JavaRDD<SaTrajectoryAoi> loadTrajectoryData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select un,zx,zy,tm,inc_day from dm_gis.esg_gis_loc_trajectory_ewl where inc_day = '%s' and zx is not null and zy is not null union all (select un,zx,zy,tm,inc_day from dm_gis.esg_gis_loc_trajectory_ewl_drift where inc_day = '%s' and zx is not null and zy is not null)", date, date);
        return DataUtil.loadData(spark, sc, sql, SaTrajectoryAoi.class);
    }


}
