package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiMaxIndexByGroupW;
import com.sf.gis.java.sds.service.GroupAoiToCmsService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;

public class GroupAoiUpdateCmsController implements Serializable {
    private Logger logger = LoggerFactory.getLogger(GroupAoiUpdateCmsController.class);
    GroupAoiToCmsService service = new GroupAoiToCmsService();

    public void start(String incDay) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Broadcast<String> addressUpdateAoiUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId");
        Broadcast<String> getAddrByCityCodeAndAddrUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1&cityCode=%s&addressId=%s");
        Broadcast<String> aoiCheckTagUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck");

        //获取更新数据
        JavaRDD<AoiMaxIndexByGroupW> finalRdd = service.loadUpdateData(spark, sc, incDay).repartition(800).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalRdd cnt:{}", finalRdd.count());
        finalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        finalRdd = finalRdd.map(o -> {
            String cityCode = o.getReq_destcitycode();
            String addressId = o.getGis_to_sys_groupid();
            String content = service.runGetCmsAoi(getAddrByCityCodeAndAddrUrlBc.value(), cityCode, addressId);
            if (StringUtils.isNotEmpty(content)) {
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null) {
                    Boolean success = jsonObject.getBoolean("success");
                    if (success) {
                        JSONObject data = jsonObject.getJSONObject("data");
                        if (data != null) {
                            String aoiId = data.getString("aoiId");
                            String adcode = data.getString("adcode");
                            String znoCode = data.getString("znoCode");

                            o.setCmsAoi(aoiId);
                            o.setCmsAdcode(adcode);
                            o.setCmsZnoCode(znoCode);
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalRdd cnt:{}", finalRdd.count());
        finalRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<AoiMaxIndexByGroupW> aoiEqualRdd = finalRdd.filter(o -> StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoi equals cnt:{}", aoiEqualRdd.count());
        aoiEqualRdd.unpersist();

        JavaRDD<AoiMaxIndexByGroupW> adcodeEqual1Rdd = finalRdd.filter(o -> !StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi())
                && StringUtils.equals(o.getCmsAdcode(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("adcode == '1' cnt:{}", adcodeEqual1Rdd.count());
        adcodeEqual1Rdd.unpersist();

        JavaRDD<AoiMaxIndexByGroupW> checkRdd = finalRdd.filter(o -> !StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi()) &&
                !StringUtils.equals(o.getCmsAdcode(), "1") &&
                StringUtils.isNotEmpty(o.getMax_r_aoi()) &&
                StringUtils.isNotEmpty(o.getCmsZnoCode()) &&
                !o.getMax_r_aoi().contains(o.getCmsZnoCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checkRdd cnt:{}", checkRdd.count());
        checkRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        //存储
        if (checkRdd.count() > 0) {
            service.saveCheckData(spark, checkRdd, incDay);
        }
        checkRdd.unpersist();

        logger.error("获取上周数据");
        String daysBefore = DateUtil.getDaysBefore(incDay, 7);
        JavaRDD<AoiMaxIndexByGroupW> lastWeekRdd = service.loadUpdateData(spark, sc, daysBefore).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastWeekRdd cnt:{}", lastWeekRdd.count());
        lastWeekRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<AoiMaxIndexByGroupW> compareRdd = finalRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid() + "_" + o.getMax_r_aoi(), o))
                .leftOuterJoin(lastWeekRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid() + "_" + o.getMax_r_aoi(), o)))
                .filter(tp -> {
                    boolean flag = true;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = false;
                    }
                    return flag;
                }).map(tp -> {
                    AoiMaxIndexByGroupW o = tp._2._1;
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("compareRdd cnt:{}", compareRdd.count());
        compareRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        finalRdd.unpersist();


        JavaRDD<AoiMaxIndexByGroupW> filterRdd = compareRdd.filter(o ->
                !StringUtils.equals(o.getTs_aoi_id(), o.getCmsAoi()) &&
                        !StringUtils.equals(o.getCmsAdcode(), "1") &&
                        StringUtils.isNotEmpty(o.getMax_r_aoi()) &&
                        StringUtils.isNotEmpty(o.getCmsZnoCode()) &&
                        o.getMax_r_aoi().contains(o.getCmsZnoCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());
        filterRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        compareRdd.unpersist();

        logger.error("调用更新接口");
        //调用更新接口
        JavaRDD<AoiMaxIndexByGroupW> updateRdd = filterRdd.map(o -> {
            try {
                String req_destcitycode = o.getReq_destcitycode();
                String gis_to_sys_groupid = o.getGis_to_sys_groupid();
                String ts_aoi_id = o.getTs_aoi_id();
                String checkZnoCode = "1";
                String operSource = "AOI_ADD";
                String operUserName = "01407317";

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("cityCode", req_destcitycode);
                jsonObject.put("addressId", gis_to_sys_groupid);
                jsonObject.put("aoiId", ts_aoi_id);
                jsonObject.put("checkZnoCode", checkZnoCode);
                jsonObject.put("operSource", operSource);
                jsonObject.put("operUserName", operUserName);

                String content = service.runAddrUpdateAoi(addressUpdateAoiUrlBc.value(), jsonObject.toJSONString());
//            o.setContent(content);
                if (StringUtils.isNotEmpty(content)) {
                    logger.error("content:{}", content);
                    JSONObject result = JSON.parseObject(content);
                    if (result != null) {
                        boolean success = result.getBoolean("success");
                        o.setFlag(success);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("updateRdd cnt:{}", updateRdd.count());
        updateRdd.take(3).forEach(o -> logger.error(JSON.toJSONString(o)));
        logger.error("success cnt:{}", updateRdd.filter(o -> o.isFlag()).count());
        logger.error("fail cnt:{}", updateRdd.filter(o -> !o.isFlag()).count());

        logger.error("打标签");
        JavaRDD<AoiMaxIndexByGroupW> checkFlagRdd = filterRdd.map(o -> {
            String city_code = o.getReq_destcitycode();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {

                JSONArray list = new JSONArray();
                list.add(gis_to_sys_groupid);

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("cityCode", city_code);
                jsonObject.put("aoiCheckTag", 1);
                jsonObject.put("addressIds", list);

                String content = service.runCheckTag(aoiCheckTagUrlBc.value(), jsonObject.toJSONString());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject1 = JSON.parseObject(content);
                    if (jsonObject1 != null) {
                        Boolean success = jsonObject1.getBoolean("success");
                        o.setCheckFlag(success);
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checkFlagRdd cnt:{}", checkFlagRdd.count());
        checkFlagRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        logger.error("checkFlagRdd sucess cnt:{}", checkFlagRdd.filter(o -> o.isCheckFlag()).count());
        logger.error("checkFlagRdd fail cnt:{}", checkFlagRdd.filter(o -> !o.isCheckFlag()).count());

        filterRdd.unpersist();
        updateRdd.unpersist();
        checkFlagRdd.unpersist();
        spark.stop();
    }


    public static void main(String[] args) {
        String data = "{\n" +
                "  \"status\": 0,\n" +
                "  \"result\": [\n" +
                "    \"广东省广州市海珠区瑞宝街道池窖西大街10号3巷5楼\",\n" +
                "    \"440105\"\n" +
                "  ]\n" +
                "}";

        JSONObject jsonObject = JSON.parseObject(data);
        JSONArray result = jsonObject.getJSONArray("result");
        System.out.println((String)result.get(0));
    }
}
