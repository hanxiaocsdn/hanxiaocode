package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class AoiAreaAoi implements Serializable {
    @Column(name = "aoi_id")
    private String aoi_code;
    @Column(name = "aoi_area_code")
    private String aoi_area_code;
    private String zonecode;

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }
}
