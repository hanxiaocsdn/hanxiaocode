package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import com.sf.gis.java.sds.pojo.CgcsSgsAoiExp;
import com.sf.gis.java.sds.pojo.CmsAoiSch;
import com.sf.gis.java.sds.pojo.GisRdsOmsto;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class AppXiaoGeMoneyController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(AppXiaoGeMoneyController.class);

    public void start(String startDate, String endDate, String today) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        Broadcast<List<String>> configBc = sc.broadcast(ConfigurationUtil.loadFileByConf("config.csv"));
        Broadcast<String> atdispatchUrl_gaoBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh&showserver=true&tel=&mobile=&company=&contact=");

        JavaRDD<CgcsSgsAoiExp> cgcsRdd = loadCgcs(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cgcsRdd cnt:{}", cgcsRdd.count());

        JavaRDD<CmsAoiSch> cmsAoiSchRdd = getCmsAoiSch(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        JavaRDD<CgcsSgsAoiExp> xgAoiRdd = cgcsRdd.mapToPair(o -> new Tuple2<>(o.getAoi(), o))
                .leftOuterJoin(cmsAoiSchRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    CgcsSgsAoiExp o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        o.setXg_aoiid(cmsAoiSch.getAoi_id());
                        o.setFa_type(cmsAoiSch.getFa_type());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xgAoiRdd cnt:{}", xgAoiRdd.count());
        cgcsRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        String before14Day = DateUtil.getDaysBefore(startDate, 7);
        String before11Day = DateUtil.getDaysBefore(today, 11);
        logger.error("before14Day:{}", before14Day);
        logger.error("before11Day:{}", before11Day);

        JavaRDD<GisRdsOmsto> gisRdsOmstoRdd = getGisRdsOmsto(spark, sc, before14Day, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gisRdsOmstoRdd cnt:{}", gisRdsOmstoRdd.count());

        JavaRDD<CgcsSgsAoiExp> finalAoiRdd = xgAoiRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                .leftOuterJoin(gisRdsOmstoRdd.mapToPair(o -> new Tuple2<>(o.getReq_waybillno(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    CgcsSgsAoiExp o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        GisRdsOmsto gisRdsOmsto = tp._2._2.get();
                        o.setFinalaoiid(gisRdsOmsto.getFinalaoiid());
                        o.setFinalzc(gisRdsOmsto.getFinalzc());
                        o.setGisaoisrc(gisRdsOmsto.getGisaoisrc());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalAoiRdd cnt:{}", finalAoiRdd.count());
        xgAoiRdd.unpersist();
        gisRdsOmstoRdd.unpersist();

        logger.error("获取路径规划数据");
        JavaRDD<CgcsSgsAoiExp> productIncUbasNextAppRdd = loadProductIncUbasNextApp(spark, sc, startDate, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("productIncUbasNextAppRdd cnt:{}", productIncUbasNextAppRdd.count());

        JavaRDD<CgcsSgsAoiExp> gisRdsOmsToRdd = loadGisRdsOmsTo(spark, sc, before11Day, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gisRdsOmsToRdd cnt:{}", gisRdsOmsToRdd.count());

        JavaRDD<CgcsSgsAoiExp> ljgh_10068Rdd = productIncUbasNextAppRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                .leftOuterJoin(gisRdsOmsToRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)))
                .map(tp -> {
                    CgcsSgsAoiExp o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CgcsSgsAoiExp cgcsSgsAoiExp = tp._2._2.get();
                        o.setConsignee_addr(cgcsSgsAoiExp.getConsignee_addr());
                        o.setDest_city_code(cgcsSgsAoiExp.getDest_city_code());
                        o.setGisaoisrc(cgcsSgsAoiExp.getGisaoisrc());
                        o.setFinalzc(cgcsSgsAoiExp.getFinalzc());
                        o.setFinalaoiid(cgcsSgsAoiExp.getFinalaoiid());
                    }
                    o.setSrc("ljgh_10068");
                    return o;
                }).filter(o -> StringUtils.isNotEmpty(o.getConsignee_addr()))
                .mapToPair(o -> new Tuple2<>(o.getConsignee_addr(), o))
                .reduceByKey((o1, o2) -> o1)
                .map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("ljgh_10068Rdd cnt:{}", ljgh_10068Rdd.count());
        productIncUbasNextAppRdd.unpersist();
        gisRdsOmsToRdd.unpersist();


        logger.error("获取小哥计提数据");
        String beforeDay = DateUtil.getDaysBefore(today, 14);
        String lastDay = DateUtil.getDaysBefore(today, 7);
        logger.error("beforeDay:{}, lastDay:{}", beforeDay, lastDay);
        JavaRDD<CgcsSgsAoiExp> XiaogeMoneyexpRdd = loadXiaoge_moneyexp(spark, sc, beforeDay, lastDay).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("XiaogeMoneyexpRdd cnt:{}", XiaogeMoneyexpRdd.count());

        JavaRDD<CgcsSgsAoiExp> productIncUbasNextAppFilterRdd = ljgh_10068Rdd.mapToPair(o -> new Tuple2<>(o.getConsignee_addr(), o))
                .leftOuterJoin(XiaogeMoneyexpRdd.mapToPair(o -> new Tuple2<>(o.getConsignee_addr(), o)).reduceByKey((o1, o2) -> o1))
                .filter(tp -> {
                    boolean flag = true;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = false;
                    }
                    return flag;
                }).map(tp -> tp._2._1)
                .persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("productIncUbasNextAppFilterRdd cnt:{}", productIncUbasNextAppFilterRdd.count());
        ljgh_10068Rdd.unpersist();
        XiaogeMoneyexpRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> equalRdd = finalAoiRdd.union(productIncUbasNextAppFilterRdd).filter(o -> StringUtils.equals(o.getXg_aoiid(), o.getFinalaoiid()) && StringUtils.equals(o.getSrc(), "xgjt")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> noEqualRdd = finalAoiRdd.union(productIncUbasNextAppFilterRdd).filter(o -> !(StringUtils.equals(o.getXg_aoiid(), o.getFinalaoiid()) && StringUtils.equals(o.getSrc(), "xgjt"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("equalRdd cnt:{}", equalRdd.count());
        logger.error("noEqualRdd cnt:{}", noEqualRdd.count());
        finalAoiRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> yesRdd = equalRdd.filter(o -> StringUtils.equals(o.getFa_type(), "190109") || StringUtils.equals(o.getFa_type(), "120203") || StringUtils.equals(o.getFa_type(), "120302") || StringUtils.equals(o.getFa_type(), "120301") || StringUtils.equals(o.getFa_type(), "120305")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> noRdd = equalRdd.filter(o -> !(StringUtils.equals(o.getFa_type(), "190109") || StringUtils.equals(o.getFa_type(), "120203") || StringUtils.equals(o.getFa_type(), "120302") || StringUtils.equals(o.getFa_type(), "120301") || StringUtils.equals(o.getFa_type(), "120305"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("yesRdd cnt:{}", yesRdd.count());
        logger.error("noRdd cnt:{}", noRdd.count());
        equalRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag10Rdd = yesRdd.map(o -> {
            o.setTag("10");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag10Rdd cnt:{}", tag10Rdd.count());
        yesRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag11Rdd = noRdd.map(o -> {
            o.setTag("11");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag11Rdd cnt:{}", tag11Rdd.count());
        noRdd.unpersist();

        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> aoiRealAccturyRdd = loadAoiRealAccturyRateJudgeWrongOperation(spark, sc, before14Day, endDate).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRealAccturyRdd cnt:{}", aoiRealAccturyRdd.count());

        JavaRDD<CgcsSgsAoiExp> markRdd = noEqualRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))
                .leftOuterJoin(aoiRealAccturyRdd.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    CgcsSgsAoiExp o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiRealAccturyRateJudgeWrongOperation aoiRealAccturyRateJudgeWrongOperation = tp._2._2.get();
                        o.setMark(aoiRealAccturyRateJudgeWrongOperation.getMark());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("markRdd cnt:{}", markRdd.count());
        noEqualRdd.unpersist();
        aoiRealAccturyRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> eqWrongRdd = markRdd.filter(o -> StringUtils.equals(o.getMark(), "wrong")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> noEqWrongRdd = markRdd.filter(o -> !StringUtils.equals(o.getMark(), "wrong")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqWrongRdd cnt:{}", eqWrongRdd.count());
        logger.error("noEqWrongRdd cnt:{}", noEqWrongRdd.count());
        markRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag20Rdd = eqWrongRdd.map(o -> {
            o.setTag("20");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag20Rdd cnt:{}", tag20Rdd.count());
        eqWrongRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> vagueTagRdd = noEqWrongRdd.map(o -> {
            String consignee_addr = o.getConsignee_addr();
            if (StringUtils.isNotEmpty(consignee_addr)) {
                List<String> list = configBc.value();
                String vague_tag = "false";
                for (String s : list) {
                    if (consignee_addr.contains(s)) {
                        vague_tag = "true";
                        break;
                    }
                }
                o.setVague_tag(vague_tag);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("vagueTagRdd cnt:{}", vagueTagRdd.count());
        noEqWrongRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> trueRdd = vagueTagRdd.filter(o -> StringUtils.equals(o.getVague_tag(), "true") || StringUtils.equals(o.getGisaoisrc(), "chkn")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> falseRdd = vagueTagRdd.filter(o -> !(StringUtils.equals(o.getVague_tag(), "true") || StringUtils.equals(o.getGisaoisrc(), "chkn"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("trueRdd cnt:{}", trueRdd.count());
        logger.error("falseRdd cnt:{}", falseRdd.count());
        vagueTagRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag31Rdd = trueRdd.map(o -> {
            o.setTag("31");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag31Rdd cnt:{}", tag31Rdd.count());
        trueRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> stdAddrRdd = falseRdd.map(o -> {
            String consignee_addr = o.getConsignee_addr();
            String dest_city_code = o.getDest_city_code();
            if (StringUtils.isNotEmpty(consignee_addr)) {
                String content = runStd(atdispatchUrl_gaoBc.value(), consignee_addr, dest_city_code, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        int status = jsonObject.getInteger("status");
                        if (status == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            if (result != null) {
                                JSONArray tcs = result.getJSONArray("tcs");
                                if (tcs != null && tcs.size() > 0) {
                                    JSONObject jsonObject1 = tcs.getJSONObject(0);
                                    String dept = jsonObject1.getString("dept");
                                    String aoiid = jsonObject1.getString("aoiid");
                                    logger.error("dept :{}", dept);
                                    logger.error("aoiid:{}", aoiid);
                                    o.setStd_dept(dept);
                                    o.setStd_aoiid(aoiid);
                                }
                                JSONObject other = result.getJSONObject("other");
                                if (other != null) {
                                    JSONObject normresp = other.getJSONObject("normresp");
                                    if (normresp != null) {
                                        JSONObject result1 = normresp.getJSONObject("result");
                                        if (result1 != null) {
                                            JSONArray geocoder = result1.getJSONArray("geocoder");
                                            if (geocoder != null && geocoder.size() > 0) {
                                                JSONObject jsonObject1 = geocoder.getJSONObject(0);
                                                if (jsonObject1 != null) {
                                                    String group = jsonObject1.getString("group");
                                                    String standardization = jsonObject1.getString("standardization");
                                                    logger.error("group :{}", group);
                                                    logger.error("standardization:{}", standardization);
                                                    o.setGroupid(group);
                                                    o.setStd_addr(standardization);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdAddrRdd cnt:{}", stdAddrRdd.count());
        falseRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> stdAoiEqXgAoiRdd = stdAddrRdd.filter(o -> StringUtils.equals(o.getStd_aoiid(), o.getXg_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> stdAoiNoEqXgAoiRdd = stdAddrRdd.filter(o -> !StringUtils.equals(o.getStd_aoiid(), o.getXg_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdAoiEqXgAoiRdd cnt:{}", stdAoiEqXgAoiRdd.count());
        logger.error("stdAoiNoEqXgAoiRdd cnt:{}", stdAoiNoEqXgAoiRdd.count());
        stdAddrRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag00Rdd = stdAoiEqXgAoiRdd.map(o -> {
            o.setTag("00");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag00Rdd cnt:{}", tag00Rdd.count());
        stdAoiEqXgAoiRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> noEmptyAddrRdd = stdAoiNoEqXgAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getStd_addr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsSgsAoiExp> emptyAddrRdd = stdAoiNoEqXgAoiRdd.filter(o -> StringUtils.isEmpty(o.getStd_addr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmptyAddrRdd cnt:{}", noEmptyAddrRdd.count());
        logger.error("emptyAddrRdd cnt:{}", emptyAddrRdd.count());
        stdAoiNoEqXgAoiRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag41Rdd = emptyAddrRdd.map(o -> {
            o.setTag("41");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag41Rdd cnt:{}", tag41Rdd.count());
        emptyAddrRdd.unpersist();

        JavaRDD<CgcsSgsAoiExp> tag40Rdd = noEmptyAddrRdd.map(o -> {
            o.setTag("40");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tag40Rdd cnt:{}", tag40Rdd.count());
        noEmptyAddrRdd.unpersist();


        JavaRDD<CgcsSgsAoiExp> resultRdd = tag11Rdd.union(tag10Rdd).union(tag20Rdd).union(tag31Rdd).union(tag41Rdd).union(tag40Rdd).union(tag00Rdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        tag11Rdd.unpersist();
        tag10Rdd.unpersist();
        tag20Rdd.unpersist();
        tag31Rdd.unpersist();
        tag41Rdd.unpersist();
        tag40Rdd.unpersist();
        tag00Rdd.unpersist();

        String executeSql = String.format("alter table dm_gis.xiaoge_moneyexp drop if EXISTS partition(inc_day='%s')", today);
        logger.error("executeSql :{}", executeSql);
        spark.sql(executeSql);
        saveData(spark, resultRdd, "dm_gis.xiaoge_moneyexp", today);

        spark.stop();
    }

    public JavaRDD<CgcsSgsAoiExp> loadCgcs(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("cgcs_sgs_aoi_exp.sql", startDate, endDate);
        logger.error("cgcs_sgs_aoi_exp sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CgcsSgsAoiExp.class);
    }

//    public JavaRDD<CgcsSgsAoiExp> loadProductIncUbasNextApp(SparkSession spark, JavaSparkContext sc, String startDate1, String startDate2, String endDate) {
//        String sql = DataUtil.loadSql("product_inc_ubas_next_app1.sql", startDate1, endDate, startDate2, endDate);
//        logger.error("product_inc_ubas_next_app1 sql: {}", sql);
//        //加载数据
//        return DataUtil.loadData(spark, sc, sql, CgcsSgsAoiExp.class);
//    }

    public JavaRDD<CgcsSgsAoiExp> loadProductIncUbasNextApp(SparkSession spark, JavaSparkContext sc, String startDate1, String endDate) {
        String sql = String.format("select properties_waybillno waybill_no,properties['selectedCode'] xg_aoiid from ods_inc_ubas.product_inc_ubas_next_app where dt between '%s' and '%s' and event_id = '10068'", startDate1, endDate);
        logger.error("product_inc_ubas_next_app1 sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CgcsSgsAoiExp.class);
    }

    public JavaRDD<CgcsSgsAoiExp> loadGisRdsOmsTo(SparkSession spark, JavaSparkContext sc, String startDate2, String endDate) {
        String sql = String.format("select req_addresseeaddr consignee_addr,req_destcitycode dest_city_code,req_waybillno waybill_no,gisaoisrc,finalzc,finalaoiid from dm_gis.gis_rds_omsto where inc_day between '%s' and '%s'", startDate2, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CgcsSgsAoiExp.class);
    }

    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,aoi_code,fa_type from dm_gis.cms_aoi_sch";
        logger.error("cms_aoi_sch sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public JavaRDD<GisRdsOmsto> getGisRdsOmsto(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = String.format("select req_waybillno,finalaoiid,finalzc,gisaoisrc from dm_gis.gis_rds_omsto where inc_day between '%s' and '%s' and (finalaoiid is not null or finalaoiid <>'')", startDate, endDate);
        logger.error("cms_aoi_sch sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, GisRdsOmsto.class);
    }

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadAoiRealAccturyRateJudgeWrongOperation(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("aoi_real_acctury_rate_judge_wrong_operation2.sql", startDate, endDate);
        logger.error("aoi_real_acctury_rate_judge_wrong_operation2 sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }

//    public JavaRDD<TaskAoiid> getTaskAoiid(SparkSession spark, JavaSparkContext sc, String date) {
//        String sql = String.format("select addr,task_aoiid from table where inc_day = '%s'", date);
//        logger.error("sql: {}", sql);
//        //加载数据
//        return DataUtil.loadData(spark, sc, sql, TaskAoiid.class);
//    }

    public JavaRDD<CgcsSgsAoiExp> loadXiaoge_moneyexp(SparkSession spark, JavaSparkContext sc, String beforeDay, String lastDay) {
        String sql = String.format("select city_code,std_addr,consignee_addr,std_aoiid,xg_aoiid,oper tag,groupid from dm_gis.xiaoge_moneyexp where inc_day between '%s' and '%s'", beforeDay, lastDay);
        logger.error("xiaoge_moneyexp sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CgcsSgsAoiExp.class);
    }

    public String runStd(String urlPattern, String addr, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(addr, "UTF-8"), cityCode);
            logger.error("url:{}", url);
            content = HttpInvokeUtil.sendGet(url);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = HttpInvokeUtil.sendGet(url);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runAoi(String urlPattern, String x, String y, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, x, y);
            logger.error("aoi url:{}", url);
            content = HttpInvokeUtil.sendGet(url, FixedConstant.MAX_TRY_TIME_ONCE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = HttpInvokeUtil.sendGet(url, FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request aoi error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public void saveData(SparkSession spark, JavaRDD<CgcsSgsAoiExp> inRdd, String targetTable, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getDest_city_code(), o.getConsignee_addr(), o.getXg_aoiid(), o.getAddressee_aoi_type(), o.getFinalaoiid(), o.getFinalzc(), o.getVague_tag(),
                    o.getMark(), o.getStd_addr(), o.getGroupid(), o.getStd_aoiid(), o.getGd_x(), o.getGd_y(), o.getGd_aoiid(), o.getStd_task_aoiid(), o.getCons_task_aoiid(), o.getTag(), o.getStd_dept(), o.getFa_type(),o.getSrc(), o.getGisaoisrc()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "waybill_no", "city_code", "consignee_addr", "xg_aoiid", "aoi_type", "finalaoiid", "finalzc", "vague_tag",
                "mark", "std_addr", "groupid", "std_aoiid", "gd_x", "gd_y", "gd_aoiid", "std_task_aoiid", "cons_task_aoiid", "oper", "std_dept", "fa_type", "src","gisaoisrc"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "xiaoge_moneyexp_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);
    }


}
