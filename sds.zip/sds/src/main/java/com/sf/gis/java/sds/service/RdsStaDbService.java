package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.db.GisRdsDbManager;
import com.sf.gis.java.sds.pojo.AoiHook;
import com.sf.gis.java.sds.utils.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;


public class RdsStaDbService extends BaseService {
    private static final Logger logger = LoggerFactory.getLogger(RdsStaDbService.class);

    private final static String aoi_hook_table = "AOI_HOOK";
    private static String[] columns = {"ID", "DATA_TYPE", "STAT_TYPE", "STAT_TYPE_CONTENT", "STAT_DATE", "REGION",
            "CITY_CODE", "ZONECODE", "WB_COUNT", "WB_HOOK", "WB_HOOK_TYPE"};
    private static String[] update_columns = {"WB_COUNT", "WB_HOOK", "WB_HOOK_TYPE"};

    public RdsStaDbService() {
        super(GisRdsDbManager.getInstance());
    }

    public void insertBatch(List<AoiHook> list) throws Exception {
        excuBatch(list, 5000, new ExcuBatchListener() {

            @Override
            public String createSql() {
                StringBuilder sb = new StringBuilder();
                sb.append(crateInsertSqlWithOutValue(columns, aoi_hook_table));
                sb.append(" on DUPLICATE key update ");
                sb.append(crateSetSqlWithOutValue(update_columns));
                return sb.toString();
            }

            @Override
            public void prepareParameters(PreparedStatement stmt, Object data) throws Exception {
                Map<String, Object> map = ObjectUtils.toHashMapByAnnotationColumn(data);

                int i = 0;
                for (String column : columns) {
                    stmt.setString(++i, (String) map.get(column));
                }
                for (String column : update_columns) {
                    stmt.setString(++i, (String) map.get(column));
                }
            }

        });
    }

    /**
     * 删除对应数据记录
     *
     * @param dataTime
     * @param dataType
     */
    public void delete(String dataTime, String dataType) {
        String sql = "delete from " + aoi_hook_table + "where STAT_DATE='" + dataTime + "'"
                + " and DATA_TYPE='" + dataType + "'";
        logger.error(sql);
        GisRdsDbManager.getInstance().update(sql);
    }

    public List<AoiHook> selectRcg(String yesterday, String statType, String mapType) {

        @SuppressWarnings("unchecked")
        List<AoiHook> list = queryList(AoiHook.class, new QueryListener() {
            @Override
            public PreparedStatement prepareSql(Connection conn) throws SQLException {
                String sql = "select * from " + aoi_hook_table +
                        " where DATA_TYPE ='" + mapType + "' and STAT_TYPE='" + statType + "' and STAT_DATE='" + yesterday + "'";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                return pstmt;
            }
        });
        return list;
    }
}

