package com.sf.gis.java.sds.controller;


import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.sds.bean.DeptData;
import com.sf.gis.java.sds.enumtype.WrongDataConfigKey;
import com.sf.gis.java.sds.pojo.AddressOrder;
import com.sf.gis.java.sds.pojo.WrongDataDeptEmpty;
import com.sf.gis.java.sds.pojo.WrongDataDiff;
import com.sf.gis.java.sds.service.OrderMapService;
import com.sf.gis.java.sds.service.WrongDataDeptEmptyService;
import com.sf.gis.java.sds.service.WrongDataDiffService;
import com.sf.gis.java.sds.service.WrongDataServiceNew;
import com.sf.gis.java.sds.service.impl.IOrderMapService;
import com.sf.gis.java.sds.service.impl.IWrongDataDeptEmptyService;
import com.sf.gis.java.sds.service.impl.IWrongDataDiffService;
import com.sf.gis.java.sds.service.impl.IWrongDataService;
import com.sf.gis.java.sds.utils.IDGenerator;
import org.apache.spark.sql.SparkSession;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ExportWrongDataController {

    private IWrongDataService wrongDataService;

    //	private String cityCodes;
    private String date, dateDivid;
    //	private DataType dataType;
    private String gisEmptyCity;
    private List<String> totalCityList;

    public ExportWrongDataController(SparkSession sparkSession, Map<String, String> configMap
    ) throws Exception {
        initService(sparkSession);
        date = DateUtil.getCurrentDateBefore("yyyyMMdd", Integer.valueOf(configMap.get("dayAgo")));
        dateDivid = DateUtil.getCurrentDateBefore("yyyy-MM-dd", Integer.valueOf(configMap.get("dayAgo")));
        //		cityCodes = "('" + configMap.getCityCode().replaceAll(" ", "").replaceAll(",", "','") + "')";
//		dataType = DataType.getType(configMap.getType());
        gisEmptyCity = createGisEmptyCity(configMap);
        totalCityList = Arrays.asList(configMap.get("totalCity").split(","));
    }

    private String createGisEmptyCity(Map<String, String> configMap) {
        String tmp = configMap.get(WrongDataConfigKey.gisEmptyCity.name()).trim();
        if (tmp.isEmpty()) {
            return null;
        }
        String cities = "('" + tmp.replace(",", "','") + "')";
        return cities;
    }

    private void initService(SparkSession sparkSession) {
        wrongDataService = new WrongDataServiceNew(sparkSession);

    }

    public void startSaveToHive() throws Exception {
//		wrongDataService.createDiffData(date);
        wrongDataService.createDeptEmptyData(date, gisEmptyCity);
        deptEmpty();
//		diff();
    }

    private void deptEmpty() throws Exception {
        for (String cityCode : totalCityList) {
            List<DeptData> list = wrongDataService.getWrongDataDeptEmpty(date, cityCode);
            List<WrongDataDeptEmpty> saveResult = list.stream().map(x -> {
                return new WrongDataDeptEmpty(x, dateDivid);
            }).collect(Collectors.toList());
            IWrongDataDeptEmptyService wrongDataDeptEmptyService = new WrongDataDeptEmptyService();
            wrongDataDeptEmptyService.createTable();
            wrongDataDeptEmptyService.deleteData(dateDivid, cityCode);
            wrongDataDeptEmptyService.insert(saveResult);
        }
    }

    @SuppressWarnings("unused")
    private void diff() throws Exception {
        List<DeptData> list = wrongDataService.getWrongDataDiff(date);
        List<WrongDataDiff> saveResult = list.stream().map(x -> {
            return new WrongDataDiff(x, dateDivid);
        }).collect(Collectors.toList());
        addToDiffOriginTable(saveResult);

        List<AddressOrder> adressMapList = saveResult.stream().map(x -> {
            return new AddressOrder(IDGenerator.getID(), x.getWaybillNo(), x.getAddress(), x.getOriginSrc(),
                    x.getDataTime(), x.getCity_code());
        }).collect(Collectors.toList());
        addToOrderMap(adressMapList);
    }

    private void addToOrderMap(List<AddressOrder> list) throws Exception {
        IOrderMapService orderMapService = new OrderMapService();
        orderMapService.createTable();
        orderMapService.insert(list);
    }

    private void addToDiffOriginTable(List<WrongDataDiff> saveResult) throws Exception {
        IWrongDataDiffService wrongDataResultService = new WrongDataDiffService();
        wrongDataResultService.createTable();
        wrongDataResultService.deleteData(dateDivid, null);
        wrongDataResultService.insert(saveResult);
    }
}
