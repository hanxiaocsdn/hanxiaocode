package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.TownInformationTodw;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 需求：【偏远乡村派件上门】快递进村收派件数据统计
 * 业务方：01425243（敖少良）
 * 研发：01399581（匡仁衡）
 * 任务id：799848
 * 时间：2023年8月31日16:44:32
 */

public class AppTownInformationTodw {
    private static Logger logger = LoggerFactory.getLogger(AppTownInformationTodw.class);
    private static String ftkj_url = "http://gis-apis.int.sfcloud.local:1080/rp/v2/api?strategy=0&stype=2&etype=2&pathCount=1&ak=9a0daa124a724ee5a8d85ec60500895b&opt=sf1&x1=%s&y1=%s&x2=%s&y2=%s";
    private static String tsp_url = "http://gis-int.int.sfdc.com.cn:1080/rpmp/tsp";
    private static int limitMin = 2000 / 20;
    private static String taskId = "799848";
    private static String taskName = "快递进村收派件数据统计";
    private static String account = "01399581";


    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);

        SparkInfo sparkInfo = SparkUtil.getSpark("AppTownInformationTodw");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Map<String, String> districtTownMap = ConfigUtil.loadDistrictTownMap("emap_district_town.csv", "adcode", "centerx", "centery", "UTF-8");
        Broadcast<Map<String, String>> districtTownMapBc = sc.broadcast(districtTownMap);

        Map<String, Integer> areaMap = ConfigUtil.loadDistrictMap("xzqh_pcct.csv", "code", "area", "UTF-8");
        Map<String, Integer> rkMap = ConfigUtil.loadDistrictMap("xzqh_pcct.csv", "code", "rk", "UTF-8");
        Broadcast<Map<String, Integer>> areaMapBc = sc.broadcast(areaMap);
        Broadcast<Map<String, Integer>> rkMapBc = sc.broadcast(rkMap);

        String emap_district_village_lastest_date = spark.sql("show partitions dm_gis.emap_district_village").toJavaRDD().map(row -> row.getString(0)).collect().stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0).split("=")[1];
        logger.error("emap_district_village_lastest_date:{}", emap_district_village_lastest_date);

        String before1Date = DateUtil.getDaysBefore(date, 1);
        String town_information_todw_sql = String.format("select\n" +
                "  a.agent_code agent_code,\n" +
                "  a.town town,\n" +
                "  a.biz_type biz_type,\n" +
                "  a.district_code district_code,\n" +
                "  b.name village_name,\n" +
                "  a.inc_day inc_day\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      agent_code,\n" +
                "      village town,\n" +
                "      biz_type,\n" +
                "      district_code,\n" +
                "      inc_day\n" +
                "    from\n" +
                "      dm_yjy.town_information_todw\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and biz_type = '代理'\n" +
                "  ) a\n" +
                "  left join (\n" +
                "    select\n" +
                "      adcode_t,\n" +
                "      name\n" +
                "    from\n" +
                "      dm_gis.emap_district_village\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "    group by\n" +
                "      adcode_t,\n" +
                "      name\n" +
                "  ) b on a.district_code = b.adcode_t", before1Date, emap_district_village_lastest_date);
        JavaRDD<TownInformationTodw> rdd = DataUtil.loadData(spark, sc, town_information_todw_sql, TownInformationTodw.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<TownInformationTodw> centerXyRdd = rdd.map(o -> {
            String district_code = o.getDistrict_code();

            Map<String, Integer> tempAreaMap = areaMapBc.value();
            int area = tempAreaMap.getOrDefault(district_code, 0);
            o.setArea(area);

            Map<String, Integer> tempRkMap = rkMapBc.value();
            int rk = tempRkMap.getOrDefault(district_code, 0);
            o.setRk(rk);

            Map<String, String> value = districtTownMapBc.value();
            String xy = value.getOrDefault(district_code, "");
            if (StringUtils.isNotEmpty(xy)) {
                String[] split = xy.split(",");
                o.setCenterx(split[0]);
                o.setCentery(split[1]);
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getAgent_code(), o)).groupByKey().map(tp -> {
            List<TownInformationTodw> list = Lists.newArrayList(tp._2);
            TownInformationTodw o = list.get(0);
            Set<String> town_set = list.stream().filter(t -> StringUtils.isNotEmpty(t.getTown())).map(TownInformationTodw::getTown).collect(Collectors.toSet());
            Set<String> district_code_set = list.stream().filter(t -> StringUtils.isNotEmpty(t.getDistrict_code())).map(TownInformationTodw::getDistrict_code).collect(Collectors.toSet());

            Set<String> xy_set = list.stream().filter(t -> StringUtils.isNotEmpty(t.getDistrict_code()))
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TownInformationTodw::getDistrict_code))), ArrayList::new))
                    .stream()
                    .filter(t -> StringUtils.isNotEmpty(t.getCenterx()) && StringUtils.isNotEmpty(t.getCentery())).map(t -> t.getCenterx() + "," + t.getCentery()).collect(Collectors.toSet());

            int area_sum = list.stream().filter(t -> StringUtils.isNotEmpty(t.getDistrict_code()))
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TownInformationTodw::getDistrict_code))), ArrayList::new))
                    .stream()
                    .map(TownInformationTodw::getArea).reduce(Integer::sum).orElse(0);

            int rk_sum = list.stream().filter(t -> StringUtils.isNotEmpty(t.getDistrict_code()))
                    .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(TownInformationTodw::getDistrict_code))), ArrayList::new))
                    .stream()
                    .map(TownInformationTodw::getRk).reduce(Integer::sum).orElse(0);

            List<String> village_name_set = list.stream().filter(t -> StringUtils.isNotEmpty(t.getDistrict_code())).map(TownInformationTodw::getVillage_name).collect(Collectors.toList());

            o.setTown(town_set.size() > 0 ? String.join("|", town_set) : "");
            o.setTown_cnt(town_set.size() + "");
            o.setDistrict_code(district_code_set.size() > 0 ? String.join("|", district_code_set) : "");
            o.setCenter_xy_str(xy_set.size() > 0 ? String.join("|", xy_set) : "");
            o.setArea_sum(area_sum + "");
            o.setRk_sum(rk_sum + "");
            o.setVillage_name(village_name_set.size() > 0 ? String.join("|", village_name_set) : "");
            o.setVillage_cnt(village_name_set.size() + "");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("centerXyRdd cnt:{}", centerXyRdd.count());
        rdd.unpersist();

        String dim_dept_info_df_sql = String.format("select dept_code agent_code,area_code,area_name,longitude,latitude,parent_dept_code from dim.dim_dept_info_df where inc_day = '%s' and dept_code is not null and dept_code <>''", date);
        JavaPairRDD<String, TownInformationTodw> deptRdd = DataUtil.loadData(spark, sc, dim_dept_info_df_sql, TownInformationTodw.class).mapToPair(o -> new Tuple2<>(o.getAgent_code(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("deptRdd cnt:{}", deptRdd.count());

        JavaRDD<TownInformationTodw> centerXyDeptRdd = centerXyRdd.mapToPair(o -> new Tuple2<>(o.getAgent_code(), o)).leftOuterJoin(deptRdd).map(tp -> {
            TownInformationTodw o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                TownInformationTodw townInformationTodw = tp._2._2.get();
                o.setArea_code(townInformationTodw.getArea_code());
                o.setArea_name(townInformationTodw.getArea_name());
                o.setLongitude(townInformationTodw.getLongitude());
                o.setLatitude(townInformationTodw.getLatitude());
                o.setParent_dept_code(townInformationTodw.getParent_dept_code());
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getParent_dept_code(), o)).leftOuterJoin(deptRdd).map(tp -> {
            TownInformationTodw o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                TownInformationTodw townInformationTodw = tp._2._2.get();
                o.setParent_longitude(townInformationTodw.getLongitude());
                o.setParent_latitude(townInformationTodw.getLatitude());
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("centerXyDeptRdd cnt:{}", centerXyDeptRdd.count());
        centerXyRdd.unpersist();
        deptRdd.unpersist();

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", ftkj_url, "9a0daa124a724ee5a8d85ec60500895b", centerXyDeptRdd.count(), 20);
        JavaRDD<TownInformationTodw> deptToParentDeptDistRdd = centerXyDeptRdd.repartition(20).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<TownInformationTodw> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                TownInformationTodw o = itr.next();
                String longitude = o.getLongitude();
                String latitude = o.getLatitude();
                String parent_longitude = o.getParent_longitude();
                String parent_latitude = o.getParent_latitude();
                if (StringUtils.isNotEmpty(longitude) && StringUtils.isNotEmpty(latitude) && StringUtils.isNotEmpty(parent_longitude) && StringUtils.isNotEmpty(parent_latitude)) {
                    String req = String.format(ftkj_url, longitude, latitude, parent_longitude, parent_latitude);
                    String resp = HttpInvokeUtil.sendGet(req);
//                    o.setFtkj_resp(resp);
                    String dist = "";
                    try {
                        dist = ((JSON.parseObject(resp).getJSONObject("result").getDouble("dist")) / 1000) + "";
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                    o.setDept_to_parent_dept_dist(dist);
                }
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("deptToParentDeptDistRdd cnt:{}", deptToParentDeptDistRdd.count());
        centerXyDeptRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, tsp_url, "9a0daa124a724ee5a8d85ec60500895b", deptToParentDeptDistRdd.count(), 20);
        JavaRDD<TownInformationTodw> lastRdd = deptToParentDeptDistRdd.repartition(20).mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<TownInformationTodw> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                TownInformationTodw o = itr.next();
                String x = o.getLongitude();
                String y = o.getLatitude();
                String center_xy_str = o.getCenter_xy_str();
                if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y) && StringUtils.isNotEmpty(center_xy_str)) {
                    JSONObject param = new JSONObject();
                    param.put("waypoints", center_xy_str);
                    param.put("starts", x + "," + y);
                    param.put("ends", x + "," + y);
                    param.put("opt", "sf1");
                    param.put("ak", "9a0daa124a724ee5a8d85ec60500895b");
                    param.put("strategy", "0");

                    String resp = HttpInvokeUtil.sendPostNew(tsp_url, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
//                    o.setResp(resp);
                    String agent_dist = "";
                    String agent_time = "";
                    try {
                        agent_dist = ((JSON.parseObject(resp).getJSONObject("result").getDouble("dist")) / 1000) + "";
                        agent_time = ((JSON.parseObject(resp).getJSONObject("result").getDouble("time")) / 3600) + "";
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                    o.setAgent_dist(agent_dist);
                    o.setAgent_time(agent_time);

                }

                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:{}", lastRdd.count());
        deptToParentDeptDistRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        spark.sql(String.format("alter table dm_gis.town_information_todw drop if EXISTS partition( inc_day='%s' )", before1Date));
        DataUtil.saveOverwrite(spark, sc, "dm_gis.town_information_todw", TownInformationTodw.class, lastRdd, "inc_day");
        lastRdd.unpersist();
    }
}
