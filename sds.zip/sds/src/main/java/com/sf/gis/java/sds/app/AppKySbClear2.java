package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.KySbClearControlle2;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppKySbClear2 {
    private static Logger logger = LoggerFactory.getLogger(AppKySbClear2.class);

    public static void main(String[] args) {
        String date1 = args[0];
        String date2 = args[1];
        date1 = "20211107";
        date2 = "20211107";
        logger.error("date1:{}, date2:{}", date1, date2);
        logger.error("run start");
        new KySbClearControlle2().start(date1, date2);
        logger.error("run end");
    }
}
