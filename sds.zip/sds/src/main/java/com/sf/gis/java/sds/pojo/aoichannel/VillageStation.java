package com.sf.gis.java.sds.pojo.aoichannel;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class VillageStation implements Serializable {

    @Column(name = "network_id")
    private String network_id;
    @Column(name = "network_name")
    private String network_name;
    @Column(name = "type")
    private String type;
    @Column(name = "province_code")
    private String province_code;
    @Column(name = "province_name")
    private String province_name;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "city_name")
    private String city_name;
    @Column(name = "district_code")
    private String district_code;
    @Column(name = "district_name")
    private String district_name;
    @Column(name = "address")
    private String address;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;

    private String req;
    private String resJson;
    private String aoi_id;
    private String aoi_code;
    private String aoi_name;

    private String stdAoi;
    private String stdAoiCode;
    private String aoi_area_code;
    private String origion_aoi_area_code;

    public String getStdAoi() {
        return stdAoi;
    }

    public void setStdAoi(String stdAoi) {
        this.stdAoi = stdAoi;
    }

    public String getStdAoiCode() {
        return stdAoiCode;
    }

    public void setStdAoiCode(String stdAoiCode) {
        this.stdAoiCode = stdAoiCode;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }

    public String getOrigion_aoi_area_code() {
        return origion_aoi_area_code;
    }

    public void setOrigion_aoi_area_code(String origion_aoi_area_code) {
        this.origion_aoi_area_code = origion_aoi_area_code;
    }

    public String getReq() {
        return req;
    }

    public void setReq(String req) {
        this.req = req;
    }

    public String getResJson() {
        return resJson;
    }

    public void setResJson(String resJson) {
        this.resJson = resJson;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getNetwork_id() {
        return network_id;
    }

    public void setNetwork_id(String network_id) {
        this.network_id = network_id;
    }

    public String getNetwork_name() {
        return network_name;
    }

    public void setNetwork_name(String network_name) {
        this.network_name = network_name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getProvince_code() {
        return province_code;
    }

    public void setProvince_code(String province_code) {
        this.province_code = province_code;
    }

    public String getProvince_name() {
        return province_name;
    }

    public void setProvince_name(String province_name) {
        this.province_name = province_name;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getDistrict_code() {
        return district_code;
    }

    public void setDistrict_code(String district_code) {
        this.district_code = district_code;
    }

    public String getDistrict_name() {
        return district_name;
    }

    public void setDistrict_name(String district_name) {
        this.district_name = district_name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
}
