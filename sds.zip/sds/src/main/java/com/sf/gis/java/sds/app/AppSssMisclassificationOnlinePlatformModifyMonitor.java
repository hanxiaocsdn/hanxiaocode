package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.SssMisclassificationOnlinePlatformModifyMonitorController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 任务id:646454(【SSS中转站错分】中转站错分运营闭环)
 * 业务方：01427169（邓蔼娟）
 * 研发：01399581（匡仁衡）
 */
public class AppSssMisclassificationOnlinePlatformModifyMonitor {
    private static Logger logger = LoggerFactory.getLogger(AppSssMisclassificationOnlinePlatformModifyMonitor.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new SssMisclassificationOnlinePlatformModifyMonitorController().start(date);
        logger.error("run end");
    }
}
