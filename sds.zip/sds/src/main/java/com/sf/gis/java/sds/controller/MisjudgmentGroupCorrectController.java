package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.OperationBottomcorrected;
import com.sf.gis.java.sds.service.MisjudgmentGroupCorrectService;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class MisjudgmentGroupCorrectController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(MisjudgmentGroupCorrectController.class);
    MisjudgmentGroupCorrectService service = new MisjudgmentGroupCorrectService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);
        Broadcast<String> cmsGetAddrByCityCodeAndAddrUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/getAddrByCityCodeAndAddr?cityCode=%s&addressId=%s&ticket=ST-1609819-CtBGlY0DaSTKiWKkFSDf-casnode1");
        Broadcast<String> gdpoiurlBc = sc.broadcast("http://sfmap-gis-rss-eta-apis.int.sfcloud.local:8000/navi-query/v2/poi");
        Broadcast<String> aoiidurlBc = sc.broadcast("http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=dec044d089524419b371bc94555c539d");
        Broadcast<String> aoinameurlBc = sc.broadcast("http://gis-apis.int.sfcloud.local:1080/dept/zctc/aoiid?ak=e6b53e609c2440c8b20b14552bab4e09&aoi_id=%s");
        Broadcast<String> updateAddressIdUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId");
        Broadcast<String> aoiCheckTagUrlBc = sc.broadcast("http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck");

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        for (String date : dates) {
            logger.error("date:{}", date);
            logger.error("获取源数据");
            JavaRDD<OperationBottomcorrected> operationBottomcorrectedRdd = service.loadData(spark, sc, date, date)
                    .mapToPair(o -> new Tuple2<>(o.getCity_code() + "_" + o.getGis_to_sys_groupid(), o))
                    .reduceByKey((o1, o2) -> o1)
                    .map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("operationBottomcorrectedRdd cnt:{}", operationBottomcorrectedRdd.count());
            operationBottomcorrectedRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

            logger.error("调接口获取标准地址");
            JavaRDD<OperationBottomcorrected> stdAddressRdd = service.processCms(cmsGetAddrByCityCodeAndAddrUrlBc.value(), operationBottomcorrectedRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("stdAddressRdd cnt:{}", stdAddressRdd.count());
            stdAddressRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            operationBottomcorrectedRdd.unpersist();


            logger.error("过滤keyword以特定词结尾的记录");
            JavaRDD<OperationBottomcorrected> keywordRdd = stdAddressRdd.map(o -> {
                String keyword = o.getKeyword();
                if (StringUtils.isNotEmpty(keyword)) {
                    keyword = keyword.replaceAll("制品有限公司|电镀有限公司|有限责任公司|股份有限公司|科技有限公司|有限公司|公司|制品厂|大酒店|酒店|商场|小区|栋|号楼|幢", "");
                    o.setKeyword(keyword);
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("keywordRdd cnt:{}", keywordRdd.count());
            keywordRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            stdAddressRdd.unpersist();

            logger.error("过滤address以特定词结尾的记录");
            JavaRDD<OperationBottomcorrected> addressRdd = keywordRdd.filter(o -> service.processAddress(o.getStd_address())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("addressRdd cnt:{}", addressRdd.count());
            addressRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            keywordRdd.unpersist();

            logger.error("过滤adcode=1的记录");
            JavaRDD<OperationBottomcorrected> adcodeRdd = addressRdd.filter(o -> !StringUtils.equals(o.getAdcode(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("adcodeRdd cnt:{}", adcodeRdd.count());
            adcodeRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            addressRdd.unpersist();

            logger.error("根据大组地址获取取高德api结果poi");
            JavaRDD<OperationBottomcorrected> poisRdd = adcodeRdd.repartition(90).map(o -> {
                String content = service.getGdPoi(gdpoiurlBc.value(), o);
                o.setContent(content);
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("poisRdd cnt:{}", poisRdd.count());
            poisRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            adcodeRdd.unpersist();

            JavaRDD<OperationBottomcorrected> locationRdd = poisRdd.flatMap(o -> {
                List<OperationBottomcorrected> list = new ArrayList<>();
                String content = o.getContent();
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    Integer status = jsonObject.getInteger("status");
                    if (status == 0) {
                        String keyword = o.getKeyword();
                        JSONObject result = jsonObject.getJSONObject("result");
                        JSONArray pois = result.getJSONArray("pois");
                        if (pois != null) {
                            if (pois.size() > 1) {
                                for (int i = 0; i < pois.size(); i++) {
                                    JSONObject jsonObject1 = pois.getJSONObject(i);
                                    String name = jsonObject1.getString("name");
                                    String address = jsonObject1.getString("address");
                                    String location = jsonObject1.getString("location");
                                    if (StringUtils.isNotEmpty(name) && StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(keyword)) {
                                        name = service.replaceSymbol(service.transformNumber(service.exChange(name)));
                                        address = service.replaceSymbol(service.transformNumber(service.exChange(address)));

                                        if ((name.contains(keyword) || address.contains(keyword) || keyword.endsWith(name)) &&
                                                !(address.contains(keyword + "对面") && address.contains(keyword + "旁") && address.contains(keyword + "东")
                                                        && address.contains(keyword + "西") && address.contains(keyword + "南") && address.contains(keyword + "北"))) {

                                            logger.error("name:{}", name);
                                            logger.error("address:{}", address);
                                            logger.error("location:{}", location);
                                            OperationBottomcorrected o1 = new OperationBottomcorrected();
                                            BeanUtils.copyProperties(o1, o);
                                            o1.setGd_name(name);
                                            o1.setGd_address(address);
                                            o1.setLocation(location);
                                            list.add(o1);
                                        }
                                    }
                                }
                            } else if (pois.size() == 1) {
                                JSONObject jsonObject1 = pois.getJSONObject(0);
                                String name = jsonObject1.getString("name");
                                String address = jsonObject1.getString("address");
                                String location = jsonObject1.getString("location");
                                if (StringUtils.isNotEmpty(name) && StringUtils.isNotEmpty(address) && StringUtils.isNotEmpty(keyword)) {
                                    name = service.replaceSymbol(service.transformNumber(service.exChange(name)));
                                    address = service.replaceSymbol(service.transformNumber(service.exChange(address)));

                                    if (name.contains(keyword) || address.contains(keyword)) {
                                        logger.error("name:{}", name);
                                        logger.error("address:{}", address);
                                        logger.error("location:{}", location);
                                        OperationBottomcorrected o1 = new OperationBottomcorrected();
                                        BeanUtils.copyProperties(o1, o);
                                        o1.setGd_name(name);
                                        o1.setGd_address(address);
                                        o1.setLocation(location);
                                        list.add(o1);
                                    }
                                }
                            }
                        }
                    }
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("locationRdd cnt:{}", locationRdd.count());
            locationRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            poisRdd.unpersist();

            logger.error("获取aoiid和aoiname");
            JavaRDD<OperationBottomcorrected> aoiRdd = locationRdd.map(o -> {
                String location = o.getLocation();
                if (StringUtils.isNotEmpty(location)) {
                    String x = location.split(",")[0];
                    String y = location.split(",")[1];
                    String content = service.runAoi(aoiidurlBc.value(), x, y, acLimitCodeSetBc.value());
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject1 = JSON.parseObject(content);
                        Integer status = jsonObject1.getInteger("status");
                        if (status == 0) {
                            JSONObject result = jsonObject1.getJSONObject("result");
                            JSONArray aoi_data = result.getJSONArray("aoi_data");
                            if (aoi_data.size() > 0) {
                                String gdaoi_id = aoi_data.getJSONObject(0).getString("aoi_id");
                                String gdaoi_name = aoi_data.getJSONObject(0).getString("aoi_name");
                                String gdaoi_zc = aoi_data.getJSONObject(0).getString("aoi_zc");
                                gdaoi_name = service.replaceSymbol(service.transformNumber(service.exChange(gdaoi_name)));

                                o.setGdaoi_id(gdaoi_id);
                                o.setGdaoi_name(gdaoi_name);
                                o.setGdaoi_zc(gdaoi_zc);
                            }
                        }
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("aoiRdd cnt:{}", aoiRdd.count());
            aoiRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            locationRdd.unpersist();

            logger.error("过滤高德zc与标准地址中zc不一致的记录");
            JavaRDD<OperationBottomcorrected> zcRdd = aoiRdd.filter(o -> StringUtils.equals(o.getGdaoi_zc(), o.getZnoCode())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("zcRdd cnt:{}", zcRdd.count());
            zcRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            aoiRdd.unpersist();

            logger.error("过滤gd_aoiid不唯一的");
            JavaRDD<OperationBottomcorrected> gdaoiidSameRdd = zcRdd.mapToPair(o -> new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getGis_to_sys_groupid(), o.getAoiId()}, "_"), o))
                    .groupByKey()
                    .filter(tp -> {
                        boolean flag = false;
                        ArrayList<OperationBottomcorrected> list = Lists.newArrayList(tp._2);
                        int size = list.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(OperationBottomcorrected::getGdaoi_id))), ArrayList::new)).size();
                        if (size == 1) {
                            flag = true;
                        }
                        return flag;
                    }).map(tp -> {
                        ArrayList<OperationBottomcorrected> list = Lists.newArrayList(tp._2);
                        OperationBottomcorrected operationBottomcorrected = list.get(0);
                        return operationBottomcorrected;
                    }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("gdaoiidSameRdd cnt:{}", gdaoiidSameRdd.count());
            gdaoiidSameRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            zcRdd.unpersist();

            logger.error("aoiname的号栋区间与地址号栋数冲突");
            JavaRDD<OperationBottomcorrected> compareRdd1 = gdaoiidSameRdd.filter(o -> service.compareAoinameAndAddress(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("compareRdd1 cnt:{}", compareRdd1.count());
            compareRdd1.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            gdaoiidSameRdd.unpersist();

            logger.error("分别在Std_address与gd_aoiname中查找[A-Za-z0-9]{1,4})(号楼|号院|栋|座|幢|坐|区|期|组)的结果值,两者一致");
            JavaRDD<OperationBottomcorrected> compareRdd2 = compareRdd1.filter(o -> service.processAoinameAndAddress(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("compareRdd2 cnt:{}", compareRdd2.count());
            compareRdd2.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            compareRdd1.unpersist();

            logger.error("gd_aoiid=原大组aoiid");
            JavaRDD<OperationBottomcorrected> equalsRdd = compareRdd2.filter(o -> StringUtils.equals(o.getGdaoi_id(), o.getAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<OperationBottomcorrected> noEqualsRdd = compareRdd2.filter(o -> !StringUtils.equals(o.getGdaoi_id(), o.getAoiId())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("equalsRdd cnt:{}", equalsRdd.count());
            logger.error("noEqualsRdd cnt:{}", noEqualsRdd.count());
            compareRdd2.unpersist();

            logger.error("equalsRdd 此大组地址标志正确 Tag=correct");
            service.saveData(spark, equalsRdd, date, "dm_gis.mis_judgment_group_correct");

            JavaRDD<OperationBottomcorrected> checkRdd1 = equalsRdd.map(o -> {
                String city_code = o.getCity_code();
                String gis_to_sys_groupid = o.getGis_to_sys_groupid();
                if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {

                    JSONArray list = new JSONArray();
                    list.add(gis_to_sys_groupid);

                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("cityCode", city_code);
                    jsonObject.put("aoiCheckTag", 1);
                    jsonObject.put("addressIds", list);

                    String content = service.runCheckTag(aoiCheckTagUrlBc.value(), jsonObject.toJSONString());
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject1 = JSON.parseObject(content);
                        if (jsonObject1 != null) {
                            Boolean success = jsonObject1.getBoolean("success");
                            o.setCheckFlag(success);
                        }
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("checkRdd1 sucess cnt:{}", checkRdd1.filter(o -> o.isCheckFlag()).count());
            logger.error("checkRdd1 fail cnt:{}", checkRdd1.filter(o -> !o.isCheckFlag()).count());
            checkRdd1.unpersist();
            equalsRdd.unpersist();


            logger.error("获取原大组cms_aoiname");
            JavaRDD<OperationBottomcorrected> cmsAoiNameRdd = service.processCms_aoiname(aoinameurlBc.value(), noEqualsRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cmsAoiNameRdd cnt:{}", cmsAoiNameRdd.count());
            cmsAoiNameRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            noEqualsRdd.unpersist();

            logger.error("取std_address不包含cms_aoiname,用gd_aoiid更新cms大组");
            JavaRDD<OperationBottomcorrected> updateRdd = cmsAoiNameRdd.filter(o -> !(StringUtils.isNotEmpty(o.getStd_address()) && StringUtils.isNotEmpty(o.getCms_aoiname()) && o.getStd_address().contains(o.getCms_aoiname()))).map(o -> {
                String city_code = o.getCity_code();
                String addressId = o.getGis_to_sys_groupid();
                String gdaoi_id = o.getGdaoi_id();

                JSONObject jsonObject = new JSONObject();
                jsonObject.put("cityCode", city_code);
                jsonObject.put("addressId", addressId);
                jsonObject.put("aoiId", gdaoi_id);
                jsonObject.put("checkZnoCode", "1");
                jsonObject.put("operSource", "误判大组日修正");
                jsonObject.put("operUserName", "01394694");

                String content = service.runAddrUpdateAoi(updateAddressIdUrlBc.value(), jsonObject.toJSONString());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject result = JSON.parseObject(content);
                    if (result != null) {
                        boolean success = result.getBoolean("success");
                        o.setFlag(success);
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("updateRdd cnt:{}", updateRdd.count());
            updateRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
            cmsAoiNameRdd.unpersist();
            logger.error("success cnt:{}", updateRdd.filter(o -> o.isFlag()).count());
            logger.error("fail cnt:{}", updateRdd.filter(o -> !o.isFlag()).count());


            logger.error("标志正确 Tag=correct");
            service.saveData(spark, updateRdd, date, "dm_gis.mis_judgment_group_correct_update");
            JavaRDD<OperationBottomcorrected> checkRdd2 = updateRdd.map(o -> {
                String city_code = o.getCity_code();
                String gis_to_sys_groupid = o.getGis_to_sys_groupid();
                if (StringUtils.isNotEmpty(gis_to_sys_groupid)) {
                    JSONArray list = new JSONArray();
                    list.add(gis_to_sys_groupid);

                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("cityCode", city_code);
                    jsonObject.put("aoiCheckTag", 1);
                    jsonObject.put("addressIds", list);

                    String content = service.runCheckTag(aoiCheckTagUrlBc.value(), jsonObject.toJSONString());
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject1 = JSON.parseObject(content);
                        if (jsonObject != null) {
                            Boolean success = jsonObject1.getBoolean("success");
                            o.setCheckFlag(success);
                        }
                    }
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("checkRdd2 sucess cnt:{}", checkRdd2.filter(o -> o.isCheckFlag()).count());
            logger.error("checkRdd2 fail cnt:{}", checkRdd2.filter(o -> !o.isCheckFlag()).count());
            updateRdd.unpersist();
            checkRdd2.unpersist();
        }
        spark.stop();
    }

    public static void main(String[] args) {
    }
}
