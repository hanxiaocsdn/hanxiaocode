package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;
import java.util.List;

@Table
public class TtOrderAoiInfo implements Serializable,Comparable<TtOrderAoiInfo> {
    @Column(name = "waybill_id")
    private String waybill_id;
    @Column(name = "waybill_type")
    private String waybill_type;
    @Column(name = "src_dist_code")
    private String src_dist_code;
    @Column(name = "source_zone_code")
    private String source_zone_code;
    @Column(name = "freight_monthly_acct_code")
    private String freight_monthly_acct_code;
    @Column(name = "consignee_emp_code")
    private String consignee_emp_code;
    @Column(name = "consigned_tm")
    private String consigned_tm;
    @Column(name = "src_lgt")
    private String src_lgt;
    @Column(name = "src_lat")
    private String src_lat;
    @Column(name = "consignor_addr")
    private String consignor_addr;
    @Column(name = "order_no")
    private String order_no;
    @Column(name = "source_waybill_no")
    private String source_waybill_no;
    @Column(name = "src_dist_code")
    private String src_city_code;
    @Column(name = "src_county")
    private String src_county;
    @Column(name = "dest_dist_code")
    private String dest_dist_code;
    @Column(name = "dest_county")
    private String dest_county;

    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoi_zc")
    private String aoi_zc;

    private String eventlng;
    private String eventlat;

    private String consigned_date;
    private String barscantmstd;

    private String before10min;
    private String after10min;

    private String sd_type;

    private int aoiCnt;
    private String aoiid;
    private String lastAoiid;

    private List<CmsAoiSch> list;

    private String waybill_type_new;

    private String tag;
    private String jiti;
    private String sp_jiti;
    private String qd_jiti;
    private String aoi_count;
    private String aoi_name;
    private String similarity;

    public String getSimilarity() {
        return similarity;
    }

    public void setSimilarity(String similarity) {
        this.similarity = similarity;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getAoi_zc() {
        return aoi_zc;
    }

    public void setAoi_zc(String aoi_zc) {
        this.aoi_zc = aoi_zc;
    }

    public String getDest_dist_code() {
        return dest_dist_code;
    }

    public void setDest_dist_code(String dest_dist_code) {
        this.dest_dist_code = dest_dist_code;
    }

    public String getDest_county() {
        return dest_county;
    }

    public void setDest_county(String dest_county) {
        this.dest_county = dest_county;
    }

    public String getSrc_city_code() {
        return src_city_code;
    }

    public void setSrc_city_code(String src_city_code) {
        this.src_city_code = src_city_code;
    }

    public String getSrc_county() {
        return src_county;
    }

    public void setSrc_county(String src_county) {
        this.src_county = src_county;
    }

    public String getSource_waybill_no() {
        return source_waybill_no;
    }

    public void setSource_waybill_no(String source_waybill_no) {
        this.source_waybill_no = source_waybill_no;
    }

    public String getSp_jiti() {
        return sp_jiti;
    }

    public void setSp_jiti(String sp_jiti) {
        this.sp_jiti = sp_jiti;
    }

    public String getQd_jiti() {
        return qd_jiti;
    }

    public void setQd_jiti(String qd_jiti) {
        this.qd_jiti = qd_jiti;
    }

    public String getAoi_count() {
        return aoi_count;
    }

    public void setAoi_count(String aoi_count) {
        this.aoi_count = aoi_count;
    }

    public String getJiti() {
        return jiti;
    }

    public void setJiti(String jiti) {
        this.jiti = jiti;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getWaybill_type_new() {
        return waybill_type_new;
    }

    public void setWaybill_type_new(String waybill_type_new) {
        this.waybill_type_new = waybill_type_new;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getConsignor_addr() {
        return consignor_addr;
    }

    public void setConsignor_addr(String consignor_addr) {
        this.consignor_addr = consignor_addr;
    }

    public String getSrc_lgt() {
        return src_lgt;
    }

    public void setSrc_lgt(String src_lgt) {
        this.src_lgt = src_lgt;
    }

    public String getSrc_lat() {
        return src_lat;
    }

    public void setSrc_lat(String src_lat) {
        this.src_lat = src_lat;
    }

    public String getEventlat() {
        return eventlat;
    }

    public void setEventlat(String eventlat) {
        this.eventlat = eventlat;
    }

    public String getEventlng() {
        return eventlng;
    }

    public void setEventlng(String eventlng) {
        this.eventlng = eventlng;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAfter10min() {
        return after10min;
    }

    public void setAfter10min(String after10min) {
        this.after10min = after10min;
    }

    public String getBefore10min() {
        return before10min;
    }

    public void setBefore10min(String before10min) {
        this.before10min = before10min;
    }

    public String getBarscantmstd() {
        return barscantmstd;
    }

    public void setBarscantmstd(String barscantmstd) {
        this.barscantmstd = barscantmstd;
    }

    public List<CmsAoiSch> getList() {
        return list;
    }

    public void setList(List<CmsAoiSch> list) {
        this.list = list;
    }

    public String getConsigned_date() {
        return consigned_date;
    }

    public void setConsigned_date(String consigned_date) {
        this.consigned_date = consigned_date;
    }

    public String getSd_type() {
        return sd_type;
    }

    public void setSd_type(String sd_type) {
        this.sd_type = sd_type;
    }

    public String getLastAoiid() {
        return lastAoiid;
    }

    public void setLastAoiid(String lastAoiid) {
        this.lastAoiid = lastAoiid;
    }

    public int getAoiCnt() {
        return aoiCnt;
    }

    public void setAoiCnt(int aoiCnt) {
        this.aoiCnt = aoiCnt;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getWaybill_id() {
        return waybill_id;
    }

    public void setWaybill_id(String waybill_id) {
        this.waybill_id = waybill_id;
    }

    public String getWaybill_type() {
        return waybill_type;
    }

    public void setWaybill_type(String waybill_type) {
        this.waybill_type = waybill_type;
    }

    public String getSrc_dist_code() {
        return src_dist_code;
    }

    public void setSrc_dist_code(String src_dist_code) {
        this.src_dist_code = src_dist_code;
    }

    public String getSource_zone_code() {
        return source_zone_code;
    }

    public void setSource_zone_code(String source_zone_code) {
        this.source_zone_code = source_zone_code;
    }

    public String getFreight_monthly_acct_code() {
        return freight_monthly_acct_code;
    }

    public void setFreight_monthly_acct_code(String freight_monthly_acct_code) {
        this.freight_monthly_acct_code = freight_monthly_acct_code;
    }

    public String getConsignee_emp_code() {
        return consignee_emp_code;
    }

    public void setConsignee_emp_code(String consignee_emp_code) {
        this.consignee_emp_code = consignee_emp_code;
    }

    public String getConsigned_tm() {
        return consigned_tm;
    }

    public void setConsigned_tm(String consigned_tm) {
        this.consigned_tm = consigned_tm;
    }

    @Override
    public int compareTo(TtOrderAoiInfo o) {
        String aoi_count = this.getAoi_count();
        String aoi_count1 = o.getAoi_count();
        if (Integer.parseInt(aoi_count) > Integer.parseInt(aoi_count1)) {
            return 1;
        } else if (Integer.parseInt(aoi_count) < Integer.parseInt(aoi_count1)) {
            return -1;
        }
        return 0;
    }
}
