package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SaTrajectoryAoi implements Serializable {
    @Column(name = "un")
    private String un;
    @Column(name = "zx")
    private String zx;
    @Column(name = "zy")
    private String zy;

    @Column(name = "dx")
    private String dx;
    @Column(name = "dy")
    private String dy;

    @Column(name = "tm")
    private String tm;
    @Column(name = "inc_day")
    private String inc_day;

    private String aoi;
    private String aoiCode;
    private String aoi_name;
    private String aoi_length;
    private String aoi_interval_tm;
    private String aoi_track_size;
    private String citycode;

    public String getDy() {
        return dy;
    }

    public void setDy(String dy) {
        this.dy = dy;
    }

    public String getDx() {
        return dx;
    }

    public void setDx(String dx) {
        this.dx = dx;
    }

    public String getAoiCode() {
        return aoiCode;
    }

    public void setAoiCode(String aoiCode) {
        this.aoiCode = aoiCode;
    }

    public String getAoi() {
        return aoi;
    }

    public void setAoi(String aoi) {
        this.aoi = aoi;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getAoi_length() {
        return aoi_length;
    }

    public void setAoi_length(String aoi_length) {
        this.aoi_length = aoi_length;
    }

    public String getAoi_interval_tm() {
        return aoi_interval_tm;
    }

    public void setAoi_interval_tm(String aoi_interval_tm) {
        this.aoi_interval_tm = aoi_interval_tm;
    }

    public String getAoi_track_size() {
        return aoi_track_size;
    }

    public void setAoi_track_size(String aoi_track_size) {
        this.aoi_track_size = aoi_track_size;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getUn() {
        return un;
    }

    public void setUn(String un) {
        this.un = un;
    }

    public String getZx() {
        return zx;
    }

    public void setZx(String zx) {
        this.zx = zx;
    }

    public String getZy() {
        return zy;
    }

    public void setZy(String zy) {
        this.zy = zy;
    }

    public String getTm() {
        return tm;
    }

    public void setTm(String tm) {
        this.tm = tm;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
