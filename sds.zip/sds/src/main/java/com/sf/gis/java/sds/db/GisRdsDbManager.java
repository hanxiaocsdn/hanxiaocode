package com.sf.gis.java.sds.db;

import com.sf.gis.java.sds.pojo.AreaInfo;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class GisRdsDbManager implements IDbManager {
    private static GisRdsDbManager instance;
    private DruidManager druidManager;

    public static GisRdsDbManager getInstance() {
        if (instance == null) {
            synchronized (GisRdsDbManager.class) {
                if (instance == null) {
                    try {
                        instance = new GisRdsDbManager();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return instance;
    }

    private GisRdsDbManager() throws IOException {
        druidManager = new DruidManager("com.mysql.cj.jdbc.Driver",
                "jdbc:mysql://10.119.72.209:3306/gis_oms_lip_rds?useSSL=false&useUnicode=true&characterEncoding=utf8&autoReconnect=true&failOverReadOnly=false&useOldAliasMetadataBehavior=true",
                "gis_oms_rds", "gis_oms_rds@123@");
    }

    public DruidManager getDruidManager() {
        return druidManager;
    }

    public void close() {
        druidManager.close();
    }

    @Override
    public Connection getConnection() throws SQLException {
        return druidManager.getConnection();
    }

    @Override
    public void update(String sql) {
        druidManager.update(sql);
    }

    /**
     * 获取大区城市信息
     *
     * @return
     */
    public List<AreaInfo> queryAreaInfo() {
        String sql = "select PROVINCE,REGION,CITY,CITYCODE from ADMIN_AREA";
        @SuppressWarnings("unchecked")
        List<AreaInfo> rsltList = druidManager.getResultList(sql, AreaInfo.class);
        return rsltList;
    }
}
