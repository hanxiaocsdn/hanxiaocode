package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.db.GisAoiDbManager;
import com.sf.gis.java.sds.pojo.GisPaiAddrFreqStat;
import com.sf.gis.java.sds.utils.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.PreparedStatement;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AoiDbService extends BaseService {
    private static final Logger logger = LoggerFactory.getLogger(AoiDbService.class);

    private final static String TABLE_NAME = "mapb_address_freq_";
    private static String[] columns = {"address_id", "key", "address", "match_freq", "src", "citycode", "inc_day"};
    private static String[] update_columns = {"key", "address", "match_freq", "src", "citycode", "inc_day"
    };


    public AoiDbService() {
        super(GisAoiDbManager.getInstance());
    }

    public void insertBatch(List<GisPaiAddrFreqStat> list, String cityCode) throws Exception {
        excuBatch(list, 5000, new ExcuBatchListener() {

            @Override
            public String createSql() {
                return createJsonSql(cityCode);
            }

            @Override
            public void prepareParameters(PreparedStatement stmt, Object data) throws Exception {
                Map<String, Object> map = ObjectUtils.toHashMapByAnnotationColumn(data);
                int i = 0;
                for (String column : columns) {
                    if (column.equals("match_freq")) {
                        stmt.setString(++i, (String) map.get("inc_day"));
                        stmt.setInt(++i, Integer.valueOf((String) map.get("match_freq")));
                    } else {
                        stmt.setString(++i, (String) map.get(column));
                    }
                }
                for (String column : update_columns) {
                    if (column.equals("match_freq")) {
                        stmt.setString(++i, (String) map.get("inc_day"));
                        stmt.setInt(++i, Integer.valueOf((String) map.get("match_freq")));
                    } else {
                        stmt.setString(++i, (String) map.get(column));
                    }
                }
            }

        });
    }

    private String createJsonSql(String cityCode) {
        StringBuilder sql = new StringBuilder("insert into " + TABLE_NAME + cityCode + "(");
        for (String column : columns) {
            sql.append("`" + column + "`" + ",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(") values(");
        for (String column : columns) {
            if (column.equals("match_freq")) {
                sql.append("column_create(?,?),");
            } else {
                sql.append("?,");
            }
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        sql.append(" on  DUPLICATE key update ");
        for (String column : update_columns) {
            if (column.equals("match_freq")) {
                sql.append("match_freq=column_add(match_freq,?,?),");
            } else {
                sql.append("`" + column + "`" + "=?,");
            }
        }
        sql.deleteCharAt(sql.length() - 1);
        return sql.toString();
    }

    /**
     * 按日期删除过期数据
     *
     * @param date
     * @param cityList
     */
    public void delete_by_day(List<String> date, List<String> cityList) {
        String date_str = date.stream().collect(Collectors.joining("','"));
        for (String city : cityList) {
            String sql = "update " + TABLE_NAME + city + " set match_freq=COLUMN_DELETE(match_freq, '" + date_str + "')";
            logger.error("clear:" + sql);
            dbManager.update(sql);
        }
    }

}
