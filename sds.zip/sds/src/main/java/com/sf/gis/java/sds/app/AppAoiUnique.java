package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.AoiUniqueController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppAoiUnique {
    private static Logger logger = LoggerFactory.getLogger(AppAoiUnique.class);

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);
        logger.error("run start");
        new AoiUniqueController().start(date);
        logger.error("run end");
    }
}
