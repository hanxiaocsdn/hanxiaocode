package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ArrayUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.EconomizeRatio;
import com.sf.gis.java.sds.service.EconomizeRatioService;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

public class EconomizeRatioController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(EconomizeRatioController.class);
    EconomizeRatioService service = new EconomizeRatioService();

    public void start(String startDate, String endDate) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

//        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
//        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        List<String> dates = DateUtil.getDateList(startDate, endDate, "yyyyMMdd");
        int size = dates.size();
        int flag = 0;
        for (String date : dates) {
            flag++;
            logger.error("date:{}", date);
            JavaRDD<EconomizeRatio> economizeRatioRdd = service.loadData(spark, sc, date).filter(o -> (StringUtils.equals(o.getError_type(), "0") || StringUtils.equals(o.getError_type(), "1")) && StringUtils.equals(o.getIsPushLine(), "1")).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("economizeRatioRdd cnt:{}", economizeRatioRdd.count());
            economizeRatioRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<EconomizeRatio> economizeRatioResultRdd = economizeRatioRdd.mapToPair(o -> {
                return new Tuple2<>(ArrayUtil.joinArr(new String[]{o.getSrcProvince(), o.getDestProvince(), o.getTaskAreaCode(), o.getSrcCityName(), o.getDestCityName(), o.getIncDay()}, "_"), o);
            }).groupByKey().map(tp -> {
                List<EconomizeRatio> list = Lists.newArrayList(tp._2);
                EconomizeRatio economizeRatio = list.get(0);

                //[自营]基准总etc
                double zy_sumBaseLineEtctoll = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getBaseLineEtctoll()))
                        .map(o -> Double.valueOf(o.getBaseLineEtctoll()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                // [自营]任务量
                int zy_taskNumber = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(EconomizeRatio::getTaskId))), ArrayList::new))
                        .size();

                //[自营]总etc
                double zy_sumEtcTollCharge = list.stream()
                        .filter(o -> o.getIsZy() == 1 && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                //[外包]任务量
                int no_zy_taskNumber = list.stream()
                        .filter(o -> o.getIsZy() == 0 && StringUtils.isNotEmpty(o.getTaskId()))
                        .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(EconomizeRatio::getTaskId))), ArrayList::new))
                        .size();

                //[外包]总etc
                double no_zy_sumEtcTollCharge = list.stream()
                        .filter(o -> o.getIsZy() == 0 && StringUtils.isNotEmpty(o.getEtcTollCharge()))
                        .map(o -> Double.valueOf(o.getEtcTollCharge()))
                        .reduce((o1, o2) -> o1 + o2)
                        .orElse(Double.valueOf(0));

                economizeRatio.setZy_sumBaseLineEtctoll(zy_sumBaseLineEtctoll);
                economizeRatio.setZy_taskNumber(zy_taskNumber);
                economizeRatio.setZy_sumEtcTollCharge(zy_sumEtcTollCharge);
                economizeRatio.setNo_zy_taskNumber(no_zy_taskNumber);
                economizeRatio.setNo_zy_sumEtcTollCharge(no_zy_sumEtcTollCharge);

                return economizeRatio;
            }).persist(StorageLevel.MEMORY_AND_DISK());
            logger.error("economizeRatioResultRdd cnt:{}", economizeRatioResultRdd.count());
            economizeRatioResultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            economizeRatioRdd.unpersist();
            if (economizeRatioResultRdd.count() > 0) {
                if (flag != size) {
                    //删除数据
                    spark.sql(String.format("insert overwrite table dm_gis.ETA_ECONOMICAL_RATIO_STAT select * from dm_gis.ETA_ECONOMICAL_RATIO_STAT where stat_date != '%s'", date));
                    service.delete(date);
                }
                service.saveData(spark, economizeRatioResultRdd);
                service.saveToMysql(sc, economizeRatioResultRdd);
            } else {
                logger.error("date:{},查无数据!", date);
            }
            economizeRatioResultRdd.unpersist();
        }
        spark.stop();
    }
}
