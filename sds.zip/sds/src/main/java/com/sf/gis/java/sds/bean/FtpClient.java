package com.sf.gis.java.sds.bean;


import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.net.SocketException;
import java.util.Calendar;
import java.util.Date;


public class FtpClient extends TransferClient {
    private static final Logger logger = LoggerFactory.getLogger(FtpClient.class);
    private FTPClient ftpClient;
    private String ftpFilePath;
    private String ftpFileName;

    public FtpClient(String host, String userName, String pwd) {
        super(host, userName, pwd);
        ftpClient = new FTPClient();
    }

    public String getFtpFilePath() {
        return ftpFilePath;
    }

    public void setFtpFilePath(String ftpFilePath) {
        this.ftpFilePath = ftpFilePath;
    }

    public String getFtpFileName() {
        return ftpFileName;
    }

    public void setFtpFileName(String ftpFileName) {
        this.ftpFileName = ftpFileName;
    }

    public void connect() throws SocketException, IOException {
        ftpClient.connect(host);
        loginFtp();
    }

    public boolean loginFtp() {
        boolean isLogin;
        try {
            isLogin = ftpClient.login(userName, pwd);
            // 连接ftp失败返回null
            if (!isLogin) {
                ftpClient.disconnect();
                ftpClient = null;
                return false;
            }
            ftpClient.setControlEncoding("UTF-8"); // 中文支持
            ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
            ftpClient.enterLocalPassiveMode();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    /**
     * 获取ftp上文件的最后修改时间
     *
     * @param host     ftp主机地址 e.g. "127.0.0.1"
     * @param username 用户名 e.g. "username"
     * @param password 密码 e.g. "passowrd"
     * @param path     文件路径 e.g. "ftputil/test.txt"
     * @return Date 如果连接成功返回java.util.Date时间，如果连接失败返回null
     * @throws Exception
     */
    public Date getFileLastModifiedTime(String path, int zoneTimeDiff) throws Exception {
        connect();
        Date lastModifiedDate = null;
        // 获取ftp上path路径下的文件
        FTPFile[] fileList = ftpClient.listFiles(path);
        for (int i = 0; i < fileList.length; i++) {
            lastModifiedDate = fileList[i].getTimestamp().getTime();
        }
        if (lastModifiedDate == null) {
            logger.error("请检查ftp路径是否正确:" + path);
            throw new Exception("ftp路径修改时间获取失败~");
        }
        Calendar tmp = Calendar.getInstance();
        tmp.setTime(lastModifiedDate);
        tmp.add(Calendar.HOUR_OF_DAY, zoneTimeDiff);
        logger.error("lastModifiedTime:" + tmp.getTime());
        return tmp.getTime();
    }

    public void close() {
        try {
            ftpClient.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean uploadFile(String localPath, String ftpPath) throws SocketException, IOException {
        boolean flag = false;
        connect();
        File tmp = new File(localPath);
        try (InputStream inputStream = new FileInputStream(tmp);) {
            logger.error("开始上传文件:" + localPath + "," + ftpPath);
            ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
            ftpClient.makeDirectory(ftpPath);
            ftpClient.changeWorkingDirectory(ftpPath);

            ftpClient.storeFile(tmp.getName(), inputStream);
            flag = true;
            logger.error("上传文件成功");
        } catch (Exception e) {
            logger.error("上传文件失败:" + e.getMessage());
        } finally {
            close();
        }
        return flag;
    }

    public boolean downloadFile(String ftpPath, String localPath, String fileName) throws Exception {
        boolean flag = false;
        connect();
        FTPFile[] fileList = ftpClient.listFiles(ftpPath + "/" + fileName);
        long lRemoteSize = fileList[0].getSize();
        logger.error("lRemoteSize:" + lRemoteSize);
        File localFile = new File(localPath + File.separatorChar + fileName);
        try (OutputStream os = new FileOutputStream(localFile);
             InputStream in = ftpClient.retrieveFileStream(ftpPath + "/" + fileName);) {
            byte[] bytes = new byte[1024];
            int c;
            long localSize = 0;
            int percent = 0;
            while ((c = in.read(bytes)) != -1) {
                os.write(bytes, 0, c);
                localSize += c;
                int tmp = (int) (localSize * 1.0 / lRemoteSize * 100);
                if (tmp != percent && tmp % 10 == 0) {
                    logger.error("down percent:" + tmp);
                    percent = tmp;
                }
            }
            flag = true;
        } catch (FileNotFoundException e) {
            logger.error("没有找到" + ftpPath + "文件");
        } catch (IOException e) {
            logger.error("文件读取错误:" + ftpPath);
        } finally {
            close();
        }
        return flag;
    }

    /**
     * 删除文件
     *
     * @param string
     * @throws IOException
     * @throws SocketException
     */
    public void delete(String ftpPath, String fileName) throws SocketException, IOException {
        connect();
        try {
            logger.error("删除ftp文件:" + ftpPath + "/" + fileName);
            ftpClient.deleteFile(ftpPath + "/" + fileName);
            logger.error("删除ftp文件完毕~");
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("删除ftp文件失败~");
        } finally {
            close();
        }
    }
}