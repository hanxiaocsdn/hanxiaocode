package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class WdpMergeMissTask implements Serializable {
    @Column(name = "way_bill_no")
    private String way_bill_no;
    @Column(name = "address")
    private String address;
    @Column(name = "done_time")
    private String done_time;
    @Column(name = "is_done")
    private String is_done;
    @Column(name = "receive_time")
    private String receive_time;
    @Column(name = "is_receive")
    private String is_receive;

    public String getWay_bill_no() {
        return way_bill_no;
    }

    public void setWay_bill_no(String way_bill_no) {
        this.way_bill_no = way_bill_no;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDone_time() {
        return done_time;
    }

    public void setDone_time(String done_time) {
        this.done_time = done_time;
    }

    public String getIs_done() {
        return is_done;
    }

    public void setIs_done(String is_done) {
        this.is_done = is_done;
    }

    public String getReceive_time() {
        return receive_time;
    }

    public void setReceive_time(String receive_time) {
        this.receive_time = receive_time;
    }

    public String getIs_receive() {
        return is_receive;
    }

    public void setIs_receive(String is_receive) {
        this.is_receive = is_receive;
    }
}
