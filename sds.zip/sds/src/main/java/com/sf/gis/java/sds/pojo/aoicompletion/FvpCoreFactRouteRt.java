package com.sf.gis.java.sds.pojo.aoicompletion;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class FvpCoreFactRouteRt implements Serializable {
    @Column(name = "mainwaybillno")
    private String mainwaybillno;
    @Column(name = "couriercode")
    private String couriercode;
    @Column(name = "exts")
    private String exts;

    public String getExts() {
        return exts;
    }

    public void setExts(String exts) {
        this.exts = exts;
    }

    public String getMainwaybillno() {
        return mainwaybillno;
    }

    public void setMainwaybillno(String mainwaybillno) {
        this.mainwaybillno = mainwaybillno;
    }

    public String getCouriercode() {
        return couriercode;
    }

    public void setCouriercode(String couriercode) {
        this.couriercode = couriercode;
    }
}
