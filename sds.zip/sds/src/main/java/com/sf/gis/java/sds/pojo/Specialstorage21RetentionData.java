package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class Specialstorage21RetentionData implements Serializable {
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "address")
    private String address;
    @Column(name = "warehouseid")
    private String warehouseid;
    @Column(name = "company_name")
    private String company_name;
    @Column(name = "resp")
    private String resp;
    @Column(name = "dept")
    private String dept;
    @Column(name = "aoiid")
    private String aoiid;
    @Column(name = "aoicode")
    private String aoicode;
    @Column(name = "inc_day")
    private String inc_day;

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getAoiid() {
        return aoiid;
    }

    public void setAoiid(String aoiid) {
        this.aoiid = aoiid;
    }

    public String getAoicode() {
        return aoicode;
    }

    public void setAoicode(String aoicode) {
        this.aoicode = aoicode;
    }

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWarehouseid() {
        return warehouseid;
    }

    public void setWarehouseid(String warehouseid) {
        this.warehouseid = warehouseid;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
