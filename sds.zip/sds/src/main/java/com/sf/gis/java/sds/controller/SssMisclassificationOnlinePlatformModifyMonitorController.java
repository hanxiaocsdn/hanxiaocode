package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.DimDeptInfoDf;
import com.sf.gis.java.sds.pojo.SssMisclassificationOnlinePlatformModifyMonitor;
import com.sf.gis.java.sds.pojo.WdpMergeMissTask;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

public class SssMisclassificationOnlinePlatformModifyMonitorController {
    private static Logger logger = LoggerFactory.getLogger(SssMisclassificationOnlinePlatformModifyMonitorController.class);
    private static String atp = "http://gis-int2.int.sfdc.com.cn:1080/atdispatch/api?address=%s&province=&cityName=&district=&city=%s&tel=&mobile=%s&company=%s&ak=3eb300d2e06947f7945cd02530a32fd2&opt=%s";
    private static String geo = "http://10.119.72.201:8087/?query_type=GEOCODE&address=%s&filter_uprecision=2&ret_splitinfo=2&adcode=%s&OPT=&output=json";
    private static String queryRedisById = "http://10.240.162.42:9010/cms/api/address/queryRedisById?cityCode=%s&addressId=%s";
    //    private static int limitMin = 40000 / 40;
    private static String account = "01399581";
    private static String taskId = "646454";
    private static String taskName = "【SSS中转站错分】中转站错分运营闭环";

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("SssMisclassificationOnlinePlatformModifyMonitorController");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        String before1Date = DateUtil.getDaysBefore(date, 1);
        String before2Date = DateUtil.getDaysBefore(date, 2);
        String before3Date = DateUtil.getDaysBefore(date, 3);
        String before7Date = DateUtil.getDaysBefore(date, 7);
        String before14Date = DateUtil.getDaysBefore(date, 14);

        JavaRDD<DimDeptInfoDf> dimDeptInfoDfRdd = loadDimDeptInfoDfData(spark, sc, before1Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("dimDeptInfoDfRdd cnt:{}", dimDeptInfoDfRdd.count());

        Map<String, String> deptMap = dimDeptInfoDfRdd.collect().stream().collect(Collectors.toMap(DimDeptInfoDf::getDept_code, DimDeptInfoDf::getParent_dept_code, (key1, key2) -> key2));
        logger.error("deptMap size:{}", deptMap.size());
        Broadcast<Map<String, String>> deptMapBc = sc.broadcast(deptMap);

        Map<String, String> deptTypeMap = dimDeptInfoDfRdd.collect().stream().collect(Collectors.toMap(DimDeptInfoDf::getDept_code, DimDeptInfoDf::getDept_type_code, (key1, key2) -> key2));
        logger.error("deptTypeMap size:{}", deptTypeMap.size());
        Broadcast<Map<String, String>> deptTypeMapBc = sc.broadcast(deptTypeMap);
        dimDeptInfoDfRdd.unpersist();

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> rdd = loadData(spark, sc, date, before1Date, before2Date, before14Date);
        logger.error("rdd cnt:{}", rdd.count());

        JavaPairRDD<String, SssMisclassificationOnlinePlatformModifyMonitor> before3DayRdd = loadBefore3DayData(spark, sc, before3Date, before1Date).mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("before3DayRdd cnt:{}", before3DayRdd.count());

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> taskTagRdd = rdd.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).leftOuterJoin(before3DayRdd)
                .filter(tp -> {
                    return tp._2._2 == null || !tp._2._2.isPresent();
                }).map(tp -> tp._2._1)
                .filter(o -> StringUtils.equals(o.getTask_tag(), "SSS错分") || StringUtils.equals(o.getTask_tag(), "网点错分"))
                .filter(o -> StringUtils.equals(o.getTask_tag(), "SSS错分") || (StringUtils.equals(o.getTask_tag(), "网点错分") && (StringUtils.isEmpty(o.getDelivered_zc()) || (StringUtils.isNotEmpty(o.getDelivered_zc()) && !o.getDelivered_zc().contains("FW")))))
                .filter(o -> {
                    String delivered_zc = o.getDelivered_zc();
                    String task_tag = o.getTask_tag();
                    if (StringUtils.equals(task_tag, "SSS错分")) {
                        return true;
                    } else {
                        if (StringUtils.isNotEmpty(delivered_zc)) {
                            String dept_type_code = deptTypeMapBc.value().get(delivered_zc);
                            return StringUtils.isNotEmpty(dept_type_code) && Arrays.asList("FB04-YWX,DB05-DB,DB05-SFZ,DB05-DLD,DB05-YJY".split(",")).contains(dept_type_code);
                        }
                    }
                    return false;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("taskTagRdd cnt:{}", taskTagRdd.count());
        rdd.unpersist();
        before3DayRdd.unpersist();

//        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> eqNormRdd = taskTagRdd.filter(o -> StringUtils.equals(o.getGis_to_sys_src(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> noEqNormRdd = taskTagRdd.filter(o -> !StringUtils.equals(o.getGis_to_sys_src(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("eqNormRdd cnt:{}", eqNormRdd.count());
//        logger.error("noEqNormRdd cnt:{}", noEqNormRdd.count());
//        taskTagRdd.unpersist();

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> sssCfRdd = taskTagRdd.filter(o -> StringUtils.equals(o.getTask_tag(), "SSS错分")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sssCfRdd cnt:{}", sssCfRdd.count());
        taskTagRdd.unpersist();

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, geo, "", sssCfRdd.count(), 1);
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> geoRdd = sssCfRdd.repartition(1).map(o -> {
            String req_address = o.getReq_address();
            String adcode = o.getAdcode();
            String before_new_groupid = "";
            if (StringUtils.isNotEmpty(req_address)) {
                String req = String.format(geo, URLEncoder.encode(req_address, "GBK"), adcode);
                String content = HttpInvokeUtil.sendGet(req, "GBK");
                o.setGeo_resp(content);
                if (StringUtils.isNotEmpty(content)) {
                    if (!content.endsWith("\"}")) {
                        content = content.substring(0, content.length() - 1) + "\"}";
                    }
                    try {
                        before_new_groupid = JSON.parseObject(content).getJSONArray("geocoder").getJSONObject(0).getString("group");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                if (StringUtils.isNotEmpty(before_new_groupid)) {
                    o.setBefore_new_groupid(before_new_groupid);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("geoRdd cnt:{}", geoRdd.count());
        sssCfRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, queryRedisById, "", geoRdd.count(), 20);
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> queryRedisRdd = geoRdd.repartition(20).map(o -> {
            String before_new_groupid = o.getBefore_new_groupid();
            String citycode = o.getCitycode();
            String before_new_dept = "";
            if (StringUtils.isNotEmpty(before_new_groupid)) {
                String req = String.format(queryRedisById, citycode, before_new_groupid);
                String content = HttpInvokeUtil.sendGet(req);
                o.setQueryredis_resp(content);
                if (StringUtils.isNotEmpty(content)) {
                    try {
                        before_new_dept = JSON.parseObject(content).getJSONArray("result").getJSONObject(0).getJSONObject("tcresult").getJSONArray("result").getJSONObject(0).getString("dept");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            o.setBefore_new_dept(before_new_dept);
            if (StringUtils.isNotEmpty(before_new_dept)) {
                o.setBefore_new_src("norm");
                o.setRerun_source("1");
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("queryRedisRdd cnt:{}", queryRedisRdd.count());
        geoRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, atp, "3eb300d2e06947f7945cd02530a32fd2", queryRedisRdd.count(), 20);
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> atpRdd = queryRedisRdd.map(o -> {
            String req_address = o.getReq_address();
            String citycode = o.getCitycode();
            String req_mobile = o.getReq_mobile();
            String req_comp_name = o.getReq_comp_name();
            if (StringUtils.isNotEmpty(req_address)) {
                String req = String.format(atp, URLEncoder.encode(req_address, "UTF-8"), citycode, req_mobile, URLEncoder.encode(req_comp_name, "UTF-8"), "zh");
                String content = HttpInvokeUtil.sendGet(req);
                o.setAtp_resp(content);
                if (StringUtils.isNotEmpty(content)) {
//                    o.setResp(content);
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                        JSONObject result = jsonObject.getJSONObject("result");
                        if (result != null) {
                            String splitResult = "";
                            try {
                                splitResult = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getString("splitResult");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            o.setGis_splitresult(splitResult);

                            String match_info = "";
                            ArrayList<String> list = new ArrayList<>();
                            try {
                                JSONArray jsonArray = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("addrSplitInfo");
                                if (jsonArray != null && jsonArray.size() > 0) {
                                    for (int i = 0; i < jsonArray.size(); i++) {
                                        JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                                        String match = jsonObject1.getString("match");
                                        if (StringUtils.equals(match, "1")) {
                                            String name = jsonObject1.getString("name");
                                            String level = jsonObject1.getString("level");
                                            String prop = jsonObject1.getString("prop");
                                            list.add(name + "^" + level + "^" + prop + "^" + match);
                                        }
                                    }
                                }
                                match_info = list.size() > 0 ? String.join("|", list) : "";
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            o.setMatch_info(match_info);

                            String adcode = o.getAdcode();
                            if (StringUtils.isEmpty(adcode)) {
                                try {
                                    adcode = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("adcode");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                                o.setAdcode(adcode);
                            }
                            String standardization = "";
                            String sflag = "";
                            String x = "";
                            String y = "";
                            String level = "";
                            String score = "";
                            try {
                                standardization = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("standardization");
                                sflag = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("sflag");
                                x = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("x");
                                y = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("y");
                                level = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("level");
                                score = result.getJSONObject("other").getJSONObject("normresp").getJSONObject("result").getJSONArray("geocoder").getJSONObject(0).getString("score");
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            o.setStandard(standardization);
                            o.setSflag(sflag);
                            o.setMatch_x(x);
                            o.setMatch_y(y);
                            o.setGl_level(level);
                            o.setScore(score);

                            JSONArray tcs = result.getJSONArray("tcs");
                            String src = "";
                            String dept = "";
                            String groupid = "";
                            String flag = "";
                            String aoicode = "";
                            String aoiid = "";
                            String keyWord = "";
                            String aoiUnit = "";
                            if (tcs != null && tcs.size() > 0) {
                                JSONObject jsonObject1 = tcs.getJSONObject(0);
                                src = jsonObject1.getString("src");
                                dept = jsonObject1.getString("dept");
                                groupid = jsonObject1.getString("groupid");
                                flag = jsonObject1.getString("flag");
                                aoicode = jsonObject1.getString("aoicode");
                                aoiid = jsonObject1.getString("aoiid");
                                keyWord = jsonObject1.getString("keyWord");

                                aoiUnit = jsonObject1.getString("aoiUnit");
                                o.setGis_aoiUnit(aoiUnit);

                                o.setFlag(flag);
                                o.setBefore_new_src(src);
                                String before_new_dept = o.getBefore_new_dept();
                                if (StringUtils.isEmpty(before_new_dept)) {
                                    o.setBefore_new_dept(dept);
                                    o.setRerun_source("2");
                                }

                                o.setGis_aoicode(aoicode);
                                o.setGis_aoiid(aoiid);
                                o.setGis_keyword(keyWord);
                            }

                            String before_new_groupid = o.getBefore_new_groupid();
                            if (StringUtils.isEmpty(before_new_groupid)) {
                                String chknId = "";
                                String matchId = "";
                                JSONObject id_list = result.getJSONObject("id_list");
                                if (id_list != null) {
                                    chknId = id_list.getString("chknId");
                                    JSONObject roadId = id_list.getJSONObject("roadId");
                                    if (roadId != null) {
                                        matchId = roadId.getString("matchId");
                                    }
                                }
                                if (StringUtils.equals(src, "chkn")) {
                                    o.setBefore_new_groupid(chknId);
                                } else if (StringUtils.equals(src, "road")) {
                                    o.setBefore_new_groupid(matchId);
                                } else {
                                    o.setBefore_new_groupid(groupid);
                                }
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atpRdd cnt:{}", atpRdd.count());
        queryRedisRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> beforeDepartNewDeptRdd = atpRdd.map(o -> {
            String before_new_dept = o.getBefore_new_dept();
            if (StringUtils.isNotEmpty(before_new_dept)) {
                String before_depart_new_dept = deptMapBc.value().get(before_new_dept);
                if (StringUtils.isNotEmpty(before_depart_new_dept)) {
                    o.setBefore_depart_new_dept(before_depart_new_dept);
                } else {
                    o.setBefore_depart_new_dept(before_new_dept);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("beforeDepartNewDeptRdd cnt:{}", beforeDepartNewDeptRdd.count());
        atpRdd.unpersist();

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> modifyRdd = beforeDepartNewDeptRdd.map(o -> {
            String before_is_modify = "";
            String gis_to_sys_by = o.getGis_to_sys_by();
            String before_depart_new_dept = o.getBefore_depart_new_dept();
            String gis_to_sys_zc = o.getGis_to_sys_zc();

            String finalretby = o.getFinalretby();
            String before_new_src = o.getBefore_new_src();

            String finalzc = o.getFinalzc();
            String before_new_dept = o.getBefore_new_dept();

            if (StringUtils.equals(gis_to_sys_by, "gis")) {
                if (StringUtils.isNotEmpty(gis_to_sys_zc)) {
                    String depart_gis_dept = deptMapBc.value().get(gis_to_sys_zc);
                    if (StringUtils.isNotEmpty(depart_gis_dept)) {
                        o.setDepart_gis_dept(depart_gis_dept);
                    } else {
                        o.setDepart_gis_dept(gis_to_sys_zc);
                    }
                }
                if (StringUtils.isNotEmpty(before_depart_new_dept) && (StringUtils.equals(before_depart_new_dept, gis_to_sys_zc) || StringUtils.equals(before_depart_new_dept, o.getDepart_gis_dept()))) {
                    before_is_modify = "0";
                } else {
                    if (StringUtils.equals(finalzc, before_new_dept) && (StringUtils.equals(finalretby, "arss") || StringUtils.equals(finalretby, "awsm")) && StringUtils.equals(before_new_src, "chkn")) {
                        before_is_modify = "0";
                    } else {
                        before_is_modify = "1";
                    }
                }
            } else {
                if (StringUtils.isEmpty(before_depart_new_dept)) {
                    before_is_modify = "0";
                } else {
                    if (StringUtils.equals(finalzc, before_new_dept) && (StringUtils.equals(finalretby, "arss") || StringUtils.equals(finalretby, "awsm")) && StringUtils.equals(before_new_src, "chkn")) {
                        before_is_modify = "0";
                    } else {
                        before_is_modify = "1";
                    }
                }
            }

            String task_tag = o.getTask_tag();
            String source = "";
            if (StringUtils.equals(task_tag, "SSS错分")) {
                source = "5";
            } else if (StringUtils.equals(task_tag, "网点错分")) {
                source = "6";
            }
            o.setSource(source);
            o.setBefore_is_modify(before_is_modify);
            o.setSend_time(DateUtil.getTheTimeInSeconds());
            o.setInc_day(date);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("modifyRdd cnt:{}", modifyRdd.count());
        beforeDepartNewDeptRdd.unpersist();

        JavaPairRDD<String, SssMisclassificationOnlinePlatformModifyMonitor> chkAlterFwRdd = loadChkAlterFwData(spark, sc, before1Date).mapToPair(o -> new Tuple2<>(o.getGis_aoiUnit(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("chkAlterFwRdd cnt:{}", chkAlterFwRdd.count());

        JavaPairRDD<String, SssMisclassificationOnlinePlatformModifyMonitor> addressDataHisRdd = loadAddressDataHis2Data(spark, sc, before1Date, DateUtil.parseFormat(before3Date) + " 00:00:00", DateUtil.parseFormat(before1Date) + " 23:59:59").mapToPair(o -> new Tuple2<>(o.getBefore_new_groupid(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addressDataHisRdd cnt:{}", addressDataHisRdd.count());

        String lastest_date = spark.sql("show partitions dm_compass.dm_t_virtual_address_mapping_mid_df").toJavaRDD().map(row -> row.getString(0)).collect().stream().sorted((o1, o2) -> o2.compareTo(o1)).collect(Collectors.toList()).get(0).split("=")[1];
        logger.error("lastest_date:{}", lastest_date);

        JavaPairRDD<String, SssMisclassificationOnlinePlatformModifyMonitor> virtualRdd = loadVirtualData(spark, sc, lastest_date).mapToPair(o -> new Tuple2<>(o.getGis_aoiUnit(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("virtualRdd cnt:{}", virtualRdd.count());

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> modifyRdd_5 = modifyRdd.filter(o -> StringUtils.equals(o.getSource(), "5")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> modifyRdd_6 = modifyRdd.filter(o -> StringUtils.equals(o.getSource(), "6")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("modifyRdd_5 cnt :{}", modifyRdd_5.count());
        logger.error("modifyRdd_6 cnt :{}", modifyRdd_6.count());

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> modifyEq0Rdd = modifyRdd_6.mapToPair(o -> new Tuple2<>(o.getGis_aoiUnit(), o)).leftOuterJoin(chkAlterFwRdd)
                .filter(tp -> {
                    return tp._2._2 == null || !tp._2._2.isPresent();
                }).mapToPair(tp -> new Tuple2<>(tp._1, tp._2._1)).leftOuterJoin(virtualRdd)
                .filter(tp -> {
                    return tp._2._2 == null || !tp._2._2.isPresent();
                }).map(tp -> tp._2._1)
                .mapToPair(o -> new Tuple2<>(o.getBefore_new_groupid(), o)).leftOuterJoin(addressDataHisRdd)
                .filter(tp -> {
                    return tp._2._2 == null || !tp._2._2.isPresent();
                })
                .map(tp -> tp._2._1)
                .union(modifyRdd_5)
//                .filter(o -> StringUtils.equals(o.getBefore_is_modify(), "0"))  //TODO  到时解除注释
                .filter(o -> StringUtils.equals(o.getSource(), "5")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("modifyEq0Rdd cnt:{}", modifyEq0Rdd.count());
        chkAlterFwRdd.unpersist();
        virtualRdd.unpersist();
        addressDataHisRdd.unpersist();
        modifyRdd_6.unpersist();
        modifyRdd_5.unpersist();

        saveSegmentationDiData(spark, modifyEq0Rdd, date, "1", "dm_gis.dm_aoi_shoupai_obtain_segmentation_di_new");
        modifyEq0Rdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.rpt_trans_misclassification_rdsmosto_task", SssMisclassificationOnlinePlatformModifyMonitor.class, modifyRdd, "inc_day");
        modifyRdd.unpersist();

        logger.error("修改监控报表流程");
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> before2DateRdd = loadBefore2DayData(spark, sc, before2Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("before2DateRdd cnt:{}", before2DateRdd.count());

        JavaRDD<WdpMergeMissTask> missTaskRdd = loadWdpMergeMissTaskData(spark, sc, before1Date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("missTaskRdd cnt:{}", missTaskRdd.count());

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> modifyMissTaskRdd = before2DateRdd.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).leftOuterJoin(missTaskRdd.mapToPair(o -> new Tuple2<>(o.getWay_bill_no(), o)))
                .map(tp -> {
                    SssMisclassificationOnlinePlatformModifyMonitor o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        WdpMergeMissTask wdpMergeMissTask = tp._2._2.get();
                        o.setDone_time(wdpMergeMissTask.getDone_time());
                        o.setIs_done(wdpMergeMissTask.getIs_done());
                        o.setReceive_time(wdpMergeMissTask.getReceive_time());
                        o.setIs_receive(wdpMergeMissTask.getIs_receive());
                    }
                    String send_time = o.getSend_time();
                    if (StringUtils.isNotEmpty(send_time)) {
                        String[] send_time_list = send_time.split(" ");
                        o.setInvald_time(DateUtil.getDaysBefore(send_time_list[0], -2, "yyyy-MM-dd") + " " + send_time_list[1]);
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("modifyMissTaskRdd cnt:{}", modifyMissTaskRdd.count());
        before2DateRdd.unpersist();
        missTaskRdd.unpersist();

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> doneEq1Rdd = modifyMissTaskRdd.filter(o -> StringUtils.equals(o.getIs_done(), "1") && (o.getSend_time().replaceAll("-", "").compareTo(before2Date + " 00:00:00") >= 0 && o.getSend_time().replaceAll("-", "").compareTo(before2Date + " 23:59:59") <= 0)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> doneNoEq1Rdd = modifyMissTaskRdd.filter(o -> !(StringUtils.equals(o.getIs_done(), "1") && (o.getSend_time().replaceAll("-", "").compareTo(before2Date + " 00:00:00") >= 0 && o.getSend_time().replaceAll("-", "").compareTo(before2Date + " 23:59:59") <= 0))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("doneEq1Rdd cnt:{}", doneEq1Rdd.count());
        logger.error("doneNoEq1Rdd cnt:{}", doneNoEq1Rdd.count());
        modifyMissTaskRdd.unpersist();

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> eqRdd = doneEq1Rdd.filter(o -> StringUtils.equals(o.getGis_to_sys_src(), "normhp") || StringUtils.equals(o.getGis_to_sys_src(), "normcompany")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> noEqRdd = doneEq1Rdd.filter(o -> !(StringUtils.equals(o.getGis_to_sys_src(), "normhp") || StringUtils.equals(o.getGis_to_sys_src(), "normcompany"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqRdd cnt:{}", eqRdd.count());
        logger.error("noEqRdd cnt:{}", noEqRdd.count());
        doneEq1Rdd.unpersist();

        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, geo, "", noEqRdd.count(), 1);
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> newTestGroupidRdd = noEqRdd.repartition(1).map(o -> {
            o.setRun_time(DateUtil.getTheTimeInSeconds());
            String req_address = o.getReq_address();
            String adcode = o.getAdcode();
            String new_test_groupid = "";
            if (StringUtils.isNotEmpty(req_address)) {
                String req = String.format(geo, URLEncoder.encode(req_address, "GBK"), adcode);
                String content = HttpInvokeUtil.sendGet(req, "GBK");
                if (StringUtils.isNotEmpty(content)) {
                    if (!content.endsWith("\"}")) {
                        content = content.substring(0, content.length() - 1) + "\"}";
                    }

                    try {
                        new_test_groupid = JSON.parseObject(content).getJSONArray("geocoder").getJSONObject(0).getString("group");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                o.setNew_test_groupid(new_test_groupid);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("newTestGroupidRdd cnt:{}", newTestGroupidRdd.count());
        noEqRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id4);

        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, queryRedisById, "", newTestGroupidRdd.count(), 20);
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> departNewTestDeptRdd = newTestGroupidRdd.map(o -> {
            String new_test_groupid = o.getNew_test_groupid();
            String citycode = o.getCitycode();
            String new_test_dept = "";
            if (StringUtils.isNotEmpty(new_test_groupid)) {
                String req = String.format(queryRedisById, citycode, new_test_groupid);
                String content = HttpInvokeUtil.sendGet(req);
                if (StringUtils.isNotEmpty(content)) {
                    try {
                        new_test_dept = JSON.parseObject(content).getJSONArray("result").getJSONObject(0).getJSONObject("tcresult").getJSONArray("result").getJSONObject(0).getString("dept");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            o.setNew_test_dept(new_test_dept);
            if (StringUtils.isNotEmpty(new_test_dept)) {
                String depart_new_test_dept = deptMapBc.value().get(new_test_dept);
                if (StringUtils.isNotEmpty(depart_new_test_dept)) {
                    o.setDepart_new_test_dept(depart_new_test_dept);
                } else {
                    o.setDepart_new_test_dept(new_test_dept);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("departNewTestDeptRdd cnt:{}", departNewTestDeptRdd.count());
        newTestGroupidRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id5);

        String id6 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, taskName, atp, "3eb300d2e06947f7945cd02530a32fd2", departNewTestDeptRdd.count() + eqRdd.count(), 20);
        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> newzhRdd = departNewTestDeptRdd.union(eqRdd).map(o -> {
            String req_address = o.getReq_address();
            String citycode = o.getCitycode();
            String req_mobile = o.getReq_mobile();
            String req_comp_name = o.getReq_comp_name();
            if (StringUtils.isNotEmpty(req_address)) {
                String req = String.format(atp, URLEncoder.encode(req_address, "UTF-8"), citycode, req_mobile, URLEncoder.encode(req_comp_name, "UTF-8"), "zh");
                String content = HttpInvokeUtil.sendGet(req);
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                        JSONObject result = jsonObject.getJSONObject("result");
                        if (result != null) {
                            JSONArray tcs = result.getJSONArray("tcs");
                            if (tcs != null && tcs.size() > 0) {
                                JSONObject jsonObject1 = tcs.getJSONObject(0);
                                String src = jsonObject1.getString("src");
                                String dept = jsonObject1.getString("dept");

                                o.setNew_zh_src(src);
                                o.setNew_zh_dept(dept);
                                if (StringUtils.isNotEmpty(dept)) {
                                    String depart_new_zh_dept = deptMapBc.value().get(dept);
                                    if (StringUtils.isNotEmpty(depart_new_zh_dept)) {
                                        o.setDepart_new_zh_dept(depart_new_zh_dept);
                                    } else {
                                        o.setDepart_new_zh_dept(dept);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("newzhRdd cnt:{}", newzhRdd.count());
        departNewTestDeptRdd.unpersist();
        eqRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id6);

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> newSrcRdd = newzhRdd.map(o -> {
            String depart_new_test_dept = o.getDepart_new_test_dept();
            String depart_new_zh_dept = o.getDepart_new_zh_dept();
            String new_zh_src = o.getNew_zh_src();
            String new_src = "";
            String depart_new_dept = "";
            if (StringUtils.isEmpty(depart_new_test_dept)) {
                depart_new_dept = depart_new_zh_dept;
                new_src = new_zh_src;
            } else {
                depart_new_dept = depart_new_test_dept;
                new_src = "norm";
            }

            o.setNew_src(new_src);
            o.setDepart_new_dept(depart_new_dept);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("newSrcRdd cnt:{}", newSrcRdd.count());
        newzhRdd.unpersist();

        JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> resultRdd = newSrcRdd.map(o -> {
            String gis_to_sys_by = o.getGis_to_sys_by();
            String is_modify = "";
            String modify_type = "";
            String chang_valid = "";
            String delivery_fit = "";
            String depart_new_dept = o.getDepart_new_dept();
            String gis_to_sys_zc = o.getGis_to_sys_zc();
            String depart_delivered_zc = o.getDepart_delivered_zc();
            String gis_to_sys_src = o.getGis_to_sys_src();
            String new_zh_src = o.getNew_zh_src();
            if (StringUtils.equals(gis_to_sys_by, "gis")) {
                if (StringUtils.isNotEmpty(depart_new_dept) && (StringUtils.equals(depart_new_dept, gis_to_sys_zc) || StringUtils.equals(depart_new_dept, o.getDepart_gis_dept()))) {
                    is_modify = "0";
                    modify_type = "0";
                    chang_valid = "0";
                    delivery_fit = "0";
                } else {
                    if (StringUtils.isEmpty(depart_new_dept)) {
                        is_modify = "1";
                        modify_type = "3";
                        chang_valid = "3";
                        delivery_fit = "3";
                    } else {
                        is_modify = "1";
                        if (StringUtils.equals(depart_new_dept, depart_delivered_zc)) {
                            delivery_fit = "1";
                        } else {
                            delivery_fit = "0";
                        }
                        if (StringUtils.isNotEmpty(gis_to_sys_src) && StringUtils.equals(gis_to_sys_src, new_zh_src)) {
                            if (!StringUtils.equals(new_zh_src, "chkn")) {
                                modify_type = "4";
                                chang_valid = "1";
                            } else {
                                String opt = "";
                                if (StringUtils.equals(gis_to_sys_src, "chkn")) {
                                    opt = "chkn";
                                } else if (StringUtils.equals(gis_to_sys_src, "road")) {
                                    opt = "road";
                                } else if (StringUtils.equals(gis_to_sys_src, "tc2")) {
                                    opt = "tc2";
                                } else if (StringUtils.equals(gis_to_sys_src, "phone")) {
                                    opt = "phone";
                                } else {
                                    opt = "norm";
                                }
                                String req_address = o.getReq_address();
                                String citycode = o.getCitycode();
                                String req_mobile = o.getReq_mobile();
                                String req_comp_name = o.getReq_comp_name();
                                if (StringUtils.isNotEmpty(req_address)) {
                                    String req = String.format(atp, URLEncoder.encode(req_address, "UTF-8"), citycode, req_mobile, URLEncoder.encode(req_comp_name, "UTF-8"), opt);
                                    String content = HttpInvokeUtil.sendGet(req);
                                    if (StringUtils.isNotEmpty(content)) {
                                        JSONObject jsonObject = JSON.parseObject(content);
                                        if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                                            JSONObject result = jsonObject.getJSONObject("result");
                                            if (result != null) {
                                                JSONArray tcs = result.getJSONArray("tcs");
                                                if (tcs != null && tcs.size() > 0) {
                                                    JSONObject jsonObject1 = tcs.getJSONObject(0);
                                                    String src = jsonObject1.getString("src");
                                                    String dept = jsonObject1.getString("dept");

                                                    o.setNew_opt_src(src);
                                                    o.setNew_opt_dept(dept);
                                                    if (StringUtils.isNotEmpty(dept)) {
                                                        String depart_new_opt_dept = deptMapBc.value().get(dept);
                                                        if (StringUtils.isNotEmpty(depart_new_opt_dept)) {
                                                            o.setDepart_new_opt_dept(depart_new_opt_dept);
                                                        } else {
                                                            o.setDepart_new_opt_dept(dept);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                String depart_new_opt_dept = o.getDepart_new_opt_dept();
                                if (StringUtils.isNotEmpty(depart_new_opt_dept) && (StringUtils.equals(depart_new_opt_dept, o.getDepart_finalzc()) || StringUtils.equals(depart_new_opt_dept, o.getDepart_gis_dept()))) {
                                    modify_type = "6";
                                    chang_valid = "0";
                                } else {
                                    modify_type = "5";
                                    chang_valid = "1";
                                }
                            }
                        } else {
                            modify_type = "1";
                            chang_valid = "1";
                        }
                    }
                }
            } else {
                if (StringUtils.isEmpty(depart_new_dept)) {
                    is_modify = "0";
                    modify_type = "0";
                    chang_valid = "0";
                    delivery_fit = "0";
                } else {
                    is_modify = "1";
                    modify_type = "2";
                    chang_valid = "1";
                    if (StringUtils.equals(depart_new_dept, depart_delivered_zc)) {
                        delivery_fit = "1";
                    } else {
                        delivery_fit = "0";
                    }
                }
            }
            o.setIs_modify(is_modify);
            o.setModify_type(modify_type);
            o.setChang_valid(chang_valid);
            o.setDelivery_fit(delivery_fit);
            return o;
        }).union(doneNoEq1Rdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        newSrcRdd.unpersist();
        doneNoEq1Rdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.rpt_trans_misclassification_rdsmosto_task_result", SssMisclassificationOnlinePlatformModifyMonitor.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();
    }


    public void saveSegmentationDiData(SparkSession spark, JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> inRdd, String date, String src_flag, String targetTable) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    "", "", "", o.getCustomeraccount(), o.getReq_area(), o.getReq_region(),
                    o.getCitycode(), o.getReq_address(), o.getReq_comp_name(), o.getDelivered_emp_code(), "", "",
                    "", "", o.getDelivered_zc(), "", "", "",
                    o.getGroupid(), "", o.getReq_city(), o.getReq_mobile(), "", o.getId(),
                    "", "", "", "", "", "",
                    o.getReq_time(), "", "", "", "", "",
                    "", "", o.getSource(), "", o.getSend_time(), o.getBefore_new_src(),
                    o.getFlag(), o.getBefore_new_groupid(), o.getStandard(), o.getSflag(), o.getMatch_x(), o.getMatch_y(),
                    o.getGl_level(), o.getScore(), o.getMatch_info(), o.getBefore_new_dept(), o.getGis_aoicode(), o.getGis_aoiid(),
                    o.getGis_keyword(), o.getGis_splitresult(), o.getAdcode(), "", "", "",
                    "", o.getWaybillno(), o.getGis_aoiUnit()
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        if (rows.count() > 0) {
            int partSize = CalPartitionUtil.getPartitionSize(rows);
            List<StructField> structFieldList = new ArrayList<>();
            String[] columnNames = new String[]{
                    "src_order_no", "isnotundercall", "syssource", "customeraccount", "area", "region",
                    "citycode", "req_address", "req_comp_name", "user_delivered_id", "operatime_new", "finalzc",
                    "finalgisaoicode", "finalaoicode", "org_code", "aoisrc", "tag2", "mobile",
                    "groupid", "key_word", "city", "phone", "src", "id",
                    "operatime_new_pai", "distribute_code", "distribute_name", "delivered_name", "finalaoiname", "aoi_area_code",
                    "req_time", "bm_aoi", "bm_userid", "bm_time", "cg_aoi", "cg_userid",
                    "cg_time", "src_aoi", "source", "address_frc", "date_time", "tcs_src",
                    "flag", "tcs_groupid", "standard", "sflag", "match_x", "match_y",
                    "gl_level", "score", "match_info", "gis_new_dept", "gis_aoicode", "gis_aoiid",
                    "gis_keyword", "gis_splitresult", "adcode", "ks_aoiid", "ks_aoitag", "ks_aoicode",
                    "response_ks", "waybillno", "gis_aoiUnit"
            };
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }
            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = spark.createDataFrame(rows.repartition(partSize), structType);
            String tempTable = "dm_aoi_shoupai_obtain_segmentation_di_new_" + System.currentTimeMillis();
            ds.createOrReplaceTempView(tempTable);
            logger.error("targetTable:{}", targetTable);
            spark.sql(String.format("insert overwrite table %s partition(inc_day = '%s', src_flag = '%s') " +
                    "select * from %s", targetTable, date, src_flag, tempTable));
            rows.unpersist();
            spark.catalog().dropTempView(tempTable);
        }
    }


    public JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> loadData(SparkSession ss, JavaSparkContext jsc, String date, String before1Date, String before2Date, String before14Date) {
        String sql = SqlUtil.getSqlStr("sssmisclassificationonlineplatformmodifymonitor.sql", date, before1Date, before1Date, before1Date, before1Date, before2Date, before1Date, before14Date, date);
        return DataUtil.loadData(ss, jsc, sql, SssMisclassificationOnlinePlatformModifyMonitor.class);
    }

    public JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> loadBefore3DayData(SparkSession ss, JavaSparkContext jsc, String startDate, String endDate) {
        String sql = String.format("select waybillno from dm_gis.rpt_trans_misclassification_rdsmosto_task where inc_day between '%s' and '%s' and waybillno is not null and waybillno <>'' group by waybillno", startDate, endDate);
        return DataUtil.loadData(ss, jsc, sql, SssMisclassificationOnlinePlatformModifyMonitor.class);
    }

    public JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> loadChkAlterFwData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("select aoi_unit gis_aoi_unit from dm_gis.chk_alter_fw where inc_day = '%s' and opt_type = 'shopAoiUnit' and aoi_unit is not null and aoi_unit <>'' group by aoi_unit", date);
        return DataUtil.loadData(ss, jsc, sql, SssMisclassificationOnlinePlatformModifyMonitor.class);
    }

    public JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> loadVirtualData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("select aoi_unit gis_aoi_unit from dm_compass.dm_t_virtual_address_mapping_mid_df where inc_day = '%s' and del_flag = 0 and opt_type = 4 group by aoi_unit", date);
        return DataUtil.loadData(ss, jsc, sql, SssMisclassificationOnlinePlatformModifyMonitor.class);
    }

    public JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> loadAddressDataHis2Data(SparkSession ss, JavaSparkContext jsc, String date, String startDate, String endDate) {
        String sql = String.format("select address_id before_new_groupid from dm_gis.address_data_his_2 where inc_day = '%s' and source in ('5','6') and address_id is not null and address_id <>'' and create_date between '%s' and '%s' group by address_id", date, startDate, endDate);
        return DataUtil.loadData(ss, jsc, sql, SssMisclassificationOnlinePlatformModifyMonitor.class);
    }

    public JavaRDD<SssMisclassificationOnlinePlatformModifyMonitor> loadBefore2DayData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("select * from dm_gis.rpt_trans_misclassification_rdsmosto_task where inc_day = '%s' and before_is_modify = '0'", date);
        return DataUtil.loadData(ss, jsc, sql, SssMisclassificationOnlinePlatformModifyMonitor.class);
    }

    public JavaRDD<DimDeptInfoDf> loadDimDeptInfoDfData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("select dept_code,parent_dept_code,dept_type_code from dim.dim_dept_info_df where inc_day = '%s' and delete_flg <> '1'", date);
        return DataUtil.loadData(ss, jsc, sql, DimDeptInfoDf.class);
    }

    public JavaRDD<WdpMergeMissTask> loadWdpMergeMissTaskData(SparkSession ss, JavaSparkContext jsc, String date) {
        String sql = String.format("select\n" +
                "  waybill_no as way_bill_no,\n" +
                "  update_date as done_time,\n" +
                "  If(update_date is not null, '1', '0') as is_done,\n" +
                "  create_date as receive_time,\n" +
                "  If(create_date is not null, '1', '0') as is_receive\n" +
                "from\n" +
                "  dm_gis.address_data_his_2\n" +
                "where\n" +
                "  inc_day = '%s'\n" +
                "  and status = '3'\n" +
                "  and source in ('5', '6')", date);
        return DataUtil.loadData(ss, jsc, sql, WdpMergeMissTask.class);
    }


}
