package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AddressInfoMapDi;
import com.sf.gis.java.sds.pojo.DimDeptInfoDf;
import com.sf.gis.java.sds.pojo.aoicompletion.*;
import com.sf.gis.java.sds.pojo.waybillaoi.*;
import com.sf.shiva.oms.csm.utils.common.dto.NsCfgDto;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class EdcsWaybillContentSwsKafkaService implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(EdcsWaybillContentSwsKafkaService.class);

    public JavaRDD<TbResUser> loadTbResUser(SparkInfo si, String date) {
        String sql = String.format("select loginid,service_dept from ods_rmds.tb_res_user where inc_day = '%s' and loginid is not null and service_dept is not null", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sql, TbResUser.class);
    }

    public JavaRDD<DimDeptInfoDf> loadDimDeptInfoDf(SparkInfo si, String date) {
        String sql = String.format("select dept_code,dept_type_name,parent_dept_code from dim.dim_dept_info_df where inc_day = '%s'", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sql, DimDeptInfoDf.class);
    }

    public String getKsAoi(String url, EdcsWaybillContentSwsKafka o) {
        String Addr = o.getAddr();
        String Province = o.getProvince();
        String City = o.getCity();
        String CityCode = o.getCityCode();
        String CompName = o.getCompName();
        String Mobile = o.getMobile();
        String Phone = o.getPhone();
        String original_zone_code = o.getOriginal_zone_code();
        String aoi = "";
        try {
            JSONObject param = new JSONObject();
            param.put("ak", "2d56aff133e7456584abd3c1be674f0f");
            param.put("address", URLEncoder.encode(Addr, "UTF-8").replaceAll("\\+", "%20"));
            param.put("dept", original_zone_code);
            param.put("city", CityCode);
            param.put("province", StringUtils.isNotEmpty(Province) ? URLEncoder.encode(Province, "UTF-8") : "");
            param.put("cityName", StringUtils.isNotEmpty(City) ? URLEncoder.encode(City, "UTF-8") : "");
            param.put("company", StringUtils.isNotEmpty(CompName) ? URLEncoder.encode(CompName, "UTF-8") : "");
            param.put("mobile", Mobile);
            param.put("tel", Phone);

            String content = HttpInvokeUtil.sendPost(url, param.toJSONString());
            if (StringUtils.isNotEmpty(content)) {
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                    JSONObject result = jsonObject.getJSONObject("result");
                    if (result != null) {
                        aoi = result.getString("aoi");
                        logger.error("aoi:{}", aoi);
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return aoi;
    }

    public String getAtsAoi(String url, EdcsWaybillContentSwsKafka o) {
        String addr = o.getAddr();
        String province = o.getProvince();
        String city = o.getCity();
        String citycode = o.getCityCode();
        String county = o.getCounty();
        String compname = o.getCompName();
        String mobile = o.getMobile();
        String phone = o.getPhone();
        String customerAcctCode = o.getCustomerAcctCode();
        String aoi = "";
        try {
            String req = String.format(url, URLEncoder.encode(addr, "UTF-8").replaceAll("\\+", "%20"), StringUtils.isNotEmpty(province) ? URLEncoder.encode(province, "UTF-8") : "", StringUtils.isNotEmpty(city) ? URLEncoder.encode(city, "UTF-8") : "", StringUtils.isNotEmpty(county) ? URLEncoder.encode(county, "UTF-8") : "", citycode, phone, mobile, StringUtils.isNotEmpty(compname) ? URLEncoder.encode(compname, "UTF-8") : "", "", customerAcctCode);
            String content = HttpInvokeUtil.sendGet(req);
            if (StringUtils.isNotEmpty(content)) {
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                    JSONObject result = jsonObject.getJSONObject("result");
                    if (result != null) {
                        JSONArray tcs = result.getJSONArray("tcs");
                        if (tcs != null && tcs.size() > 0) {
                            JSONObject jsonObject1 = tcs.getJSONObject(0);
                            if (jsonObject1 != null) {
                                aoi = jsonObject1.getString("aoiid");
                                logger.error("ats aoi:{}", aoi);
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return aoi;
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> processAddr(SparkSession ss, JavaRDD<EdcsWaybillContentSwsKafka> cityCodeRdd) {
        JavaRDD<EdcsWaybillContentSwsKafka> noEmpAddrRdd = cityCodeRdd.filter(o -> StringUtils.isNotEmpty(o.getAddr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<EdcsWaybillContentSwsKafka> empAddrRdd = cityCodeRdd.filter(o -> StringUtils.isEmpty(o.getAddr())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpAddrRdd cnt:{}", noEmpAddrRdd.count());
        logger.error("empAddrRdd cnt:{}", empAddrRdd.count());
        cityCodeRdd.unpersist();

        JavaRDD<Row> row = noEmpAddrRdd.map(o -> {
            return RowFactory.create(o.getWaybill_no(), o.getAddr());
        });
        logger.error("row cnt:{}", row.count());
        List<StructField> structFieldList = new ArrayList<>();
        structFieldList.add(DataTypes.createStructField("waybill_no", DataTypes.StringType, true));
        structFieldList.add(DataTypes.createStructField("addr", DataTypes.StringType, true));
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = ss.createDataFrame(row, structType);
        String tempTable = "processaddr" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);

        ss.sql("add jar hdfs://sfbdp1/tmp/udf/01397450/97887/1000/decrypt-1.0.0.jar");
        ss.sql("add file hdfs://sfbdp1//tmp/udf/sfencode/01399581/sfdencrpt.ini");
        ss.sql("create temporary function new_decrypt as 'com.sf.udf.decrypt.Decrypt'");

        JavaRDD<EdcsWaybillContentSwsKafka> decryptAddrRdd = ss.sql(String.format("select waybill_no,new_decrypt(addr) addr from %s", tempTable)).repartition(SysConstant.PARTITION_COUNT).toJavaRDD().map(o -> {
            EdcsWaybillContentSwsKafka edcsWaybillContentSwsKafka = new EdcsWaybillContentSwsKafka();
            String waybill_no = o.getString(0);
            String addr = o.getString(1);

            edcsWaybillContentSwsKafka.setWaybill_no(waybill_no);
            edcsWaybillContentSwsKafka.setAddr(addr);
            return edcsWaybillContentSwsKafka;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("decryptAddrRdd cnt:{}", decryptAddrRdd.count());
        decryptAddrRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<EdcsWaybillContentSwsKafka> resultRdd = noEmpAddrRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).leftOuterJoin(decryptAddrRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o))).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                EdcsWaybillContentSwsKafka edcsWaybillContentSwsKafka = tp._2._2.get();
                o.setAddr(edcsWaybillContentSwsKafka.getAddr());
            }
            return o;
        }).union(empAddrRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        noEmpAddrRdd.unpersist();
        decryptAddrRdd.unpersist();
        empAddrRdd.unpersist();

        return resultRdd;
    }

    public JavaRDD<GisRdsOmsto> loadRdsOmstoPretreatmentAoiData(SparkInfo si) {
        String sql = String.format("select * from dm_gis.gis_rds_omsto_pretreatment_aoi");
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sql, GisRdsOmsto.class);
    }

    public JavaRDD<GisRdsOmsfrom> loadRdsOmsfromPretreatmentEmpCodeData(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.gis_rds_omsfrom_pretreatment_emp_code where inc_day = '%s'", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sql, GisRdsOmsfrom.class);
    }


    public JavaRDD<FvpCoreFactRouteRt> loadFvpCoreFactRouteRtExtsPretreatmentData(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.fvp_core_fact_route_rt_pretreatment where inc_day = '%s'", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sql, FvpCoreFactRouteRt.class);
    }

    //waybillNo,originalZoneCode,destinationZoneCode,empCode,takeoverTm,aoiId dm_gis.the_shipping_address_does_not_match_1
    public JavaRDD<EdcsWaybillContentSwsKafka> loadTheShippingAddressDoesNotMatch(SparkSession si, JavaSparkContext sc, String date) {
        String sql = String.format("SELECT waybillno as waybill_no,original_zone_code,destination_zone_code,emp_code,takeover_tm,aoi_id FROM dm_gis.the_shipping_address_does_not_match_1 where inc_day = '%s'", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sc,sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> loadTheShippingAddressDoesNotMatch_1(SparkSession spark, JavaSparkContext sc, String date, String hour_1) {
        String sql = String.format("SELECT waybillno as waybill_no,original_zone_code,destination_zone_code,emp_code,takeover_tm,aoiid as aoi_id FROM dm_gis.sa_false_profit_incoming_shipments_process_pre_1 where inc_day = '%s' and inc_hour = '%s'", date, hour_1);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(spark, sc, sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> loadTheShippingAddressDoesNotMatch_2(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select\n" +
                "\twaybill_no,original_zone_code,destination_zone_code,emp_code,takeover_tm,aoi_id \n" +
                "from\n" +
                "(\n" +
                "\tselect\n" +
                "\t\twaybill_no,original_zone_code,destination_zone_code,emp_code,aoi_id\n" +
                "\tfrom\n" +
                "\t(\n" +
                "\t\tSELECT \n" +
                "\t\t\twaybill_no,original_zone_code,destination_zone_code,emp_code,aoi_id\n" +
                "\t\t\t,row_number() over(distribute by waybill_no sort by waybill_no) as rn\n" +
                "\t\tFROM dm_ecas_dcs.tt_edcs_hive_commission_detail \n" +
                "\t\twhere inc_day = '%s' \n" +
                "\t\tand is_apply_aoi = '1' \n" +
                "\t\tand audit_type = '1' \n" +
                "\t\tand scene_type = '2' \n" +
                "\t\tand self_send_flg <> '1' \n" +
                "\t\tand oneself_pickup_flg <> '1' \n" +
                "\t\tand subtract_type = '1'\n" +
                "\t) as a\n" +
                "\twhere rn = 1\n" +
                ") as t1\n" +
                "\n" +
                "left join\n" +
                "\n" +
                "(\n" +
                "\tselect \n" +
                "\t\twaybill_no as waybill_no_1\n" +
                "\t\t,from_unixtime(cast(barscantm as int),'yyyy-MM-dd HH:mm:ss') as takeover_tm \n" +
                "\tfrom dm_gis.sa_false_profit_incoming_shipments_source \n" +
                "\twhere inc_day = '%s' \n" +
                ") as t2\n" +
                "\n" +
                "on t1.waybill_no = t2.waybill_no_1", date, date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(spark, sc, sql, EdcsWaybillContentSwsKafka.class);
    }

    /*public JavaRDD<EdcsWaybillContentSwsKafka> loadTheShippingAddressDoesNotMatch_2(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("SELECT waybill_no,original_zone_code,destination_zone_code,emp_code,takeover_tm,aoi_id FROM dm_ecas_dcs.tt_edcs_hive_commission_detail where inc_day = '%s' and is_apply_aoi = '1' and audit_type = '1' and scene_type = '2' and self_send_flg <> '1' and oneself_pickup_flg <> '1' and subtract_type = '1'", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(spark, sc, sql, EdcsWaybillContentSwsKafka.class);
    }*/

    public JavaRDD<EdcsWaybillContentSwsKafka> loadTheShippingAddressDoesNotMatch_3(SparkSession si, JavaSparkContext sc, String date) {
        String sql = String.format("SELECT waybillno as waybill_no,original_zone_code,destination_zone_code,emp_code,takeover_tm,aoiid as aoi_id FROM dm_gis.sa_false_profit_incoming_shipments_process_pre_1 where inc_day = '%s'", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sc,sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> loadData(SparkInfo si, String date, String minDate, String auditType, String outArea) {
        String sql = "";
        if (StringUtils.equals(auditType, "1")) {
            if (StringUtils.isNotEmpty(outArea)) {
                sql = SqlUtil.getSqlStr("tt_edcs_waybill_content_sws_kafka_sj_out_area.sql", date, minDate);
            } else {
                sql = SqlUtil.getSqlStr("tt_edcs_waybill_content_sws_kafka_sj.sql", date, minDate);
            }
        } else if (StringUtils.equals(auditType, "2")) {
            sql = SqlUtil.getSqlStr("tt_edcs_waybill_content_sws_kafka_pj.sql", date, minDate);
        }
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafkaSjOutArea> loadSjTagOutAreaAoi(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.sj_aoi_out_area where inc_day = '%s' and original_tag is not null and original_tag <>''", date);
        logger.error("sql:{}", sql);
        return DataUtil.loadData(si, sql, EdcsWaybillContentSwsKafkaSjOutArea.class);
    }


    public List<EdcsWaybillContentSwsKafka> getSrcXy(List<JSONObject> jsonList, List<EdcsWaybillContentSwsKafka> tempList) {
        int count = 0;
        List<EdcsWaybillContentSwsKafka> reList = new ArrayList<>();
        for (int i = 0; i < tempList.size(); i++) {
            JSONObject jsonObject = jsonList.get(i);
            EdcsWaybillContentSwsKafka edcsWaybillContentSwsKafka = tempList.get(i);
            if (jsonObject != null) {
                edcsWaybillContentSwsKafka.setSrc_lgt(jsonObject.getString("longitude"));
                edcsWaybillContentSwsKafka.setSrc_lat(jsonObject.getString("latitude"));
                reList.add(edcsWaybillContentSwsKafka);
            }
            count++;
        }
        logger.error("deal size " + count);
        return reList;
    }

    public List<EdcsWaybillContentSwsKafka> getEventlngXy(List<JSONObject> jsonList, List<EdcsWaybillContentSwsKafka> tempList) {
        int count = 0;
        List<EdcsWaybillContentSwsKafka> reList = new ArrayList<>();
        for (int i = 0; i < tempList.size(); i++) {
            JSONObject jsonObject = jsonList.get(i);
            EdcsWaybillContentSwsKafka edcsWaybillContentSwsKafka = tempList.get(i);
            if (jsonObject != null) {
                edcsWaybillContentSwsKafka.setEventlng(jsonObject.getString("eventLng"));
                edcsWaybillContentSwsKafka.setEventlat(jsonObject.getString("eventLat"));
                reList.add(edcsWaybillContentSwsKafka);
            }
            count++;
        }
        logger.error("deal size " + count);
        return reList;
    }

    public List<EdcsWaybillContentSwsKafka> getOrderNo(List<JSONObject> jsonList, List<EdcsWaybillContentSwsKafka> tempList) {
        int count = 0;
        List<EdcsWaybillContentSwsKafka> reList = new ArrayList<>();
        for (int i = 0; i < tempList.size(); i++) {
            JSONObject jsonObject = jsonList.get(i);
            EdcsWaybillContentSwsKafka edcsWaybillContentSwsKafka = tempList.get(i);
            if (jsonObject != null) {
                edcsWaybillContentSwsKafka.setOrderNo(jsonObject.getString("order_no"));
                reList.add(edcsWaybillContentSwsKafka);
            }
            count++;
        }
        logger.error("deal size " + count);
        return reList;
    }

    public List<EdcsWaybillContentSwsKafka> getOperationWaybill(List<JSONObject> jsonList, List<EdcsWaybillContentSwsKafka> tempList, String tag) {
        int count = 0;
        List<EdcsWaybillContentSwsKafka> reList = new ArrayList<>();
        for (int i = 0; i < tempList.size(); i++) {
            JSONObject jsonObject = jsonList.get(i);
            EdcsWaybillContentSwsKafka edcsWaybillContentSwsKafka = tempList.get(i);
            if (jsonObject != null) {
                edcsWaybillContentSwsKafka.setSourceWaybillNo(jsonObject.getString("source_waybill_no"));
                edcsWaybillContentSwsKafka.setWaybillnoOrderNo(jsonObject.getString("order_no"));
                edcsWaybillContentSwsKafka.setCustomerAcctCode(jsonObject.getString("customer_acct_code"));
                if (StringUtils.equals(tag, "sj")) {
                    edcsWaybillContentSwsKafka.setAddr(jsonObject.getString("sender_addr"));
                    edcsWaybillContentSwsKafka.setCompName(jsonObject.getString("sender_comp_name"));
                    edcsWaybillContentSwsKafka.setMobile(jsonObject.getString("sender_mobile"));
                    edcsWaybillContentSwsKafka.setPhone(jsonObject.getString("sender_phone"));
                    edcsWaybillContentSwsKafka.setProvince(jsonObject.getString("sender_province"));
                    edcsWaybillContentSwsKafka.setCity(jsonObject.getString("sender_city"));
                    edcsWaybillContentSwsKafka.setCityCode(jsonObject.getString("sender_city_code"));
                    edcsWaybillContentSwsKafka.setCounty(jsonObject.getString("sender_area"));
                } else if (StringUtils.equals(tag, "pj")) {
                    String receiver_addr = jsonObject.getString("receiver_addr");
                    if (StringUtils.isNotEmpty(receiver_addr)) {
                        edcsWaybillContentSwsKafka.setAddr(jsonObject.getString("receiver_addr"));
                    } else {
                        String addressee_addr = jsonObject.getString("addressee_addr");
                        edcsWaybillContentSwsKafka.setAddr(addressee_addr);
                    }
                    edcsWaybillContentSwsKafka.setCompName(jsonObject.getString("receiver_comp_name"));
                    edcsWaybillContentSwsKafka.setMobile(jsonObject.getString("receiver_mobile"));
                    edcsWaybillContentSwsKafka.setPhone(jsonObject.getString("receiver_phone"));
                    edcsWaybillContentSwsKafka.setProvince(jsonObject.getString("receiver_province"));
                    edcsWaybillContentSwsKafka.setCity(jsonObject.getString("receiver_city"));
                    edcsWaybillContentSwsKafka.setCityCode(jsonObject.getString("receiver_city_code"));
                    edcsWaybillContentSwsKafka.setCounty(jsonObject.getString("receiver_area"));
                }
            }
            reList.add(edcsWaybillContentSwsKafka);
            count++;
        }
        logger.error("deal size " + count);
        return reList;
    }


    public void saveSgsSjData(SparkSession spark, JavaRDD<TtAppointAdditionKafka> inRdd, String table, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getTxid(), o.getLongitude(), o.getLatitude()
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        if (rows.count() > 0) {
            int partSize = CalPartitionUtil.getPartitionSize(rows);
            List<StructField> structFieldList = new ArrayList<>();
            String[] columnNames = new String[]{"txid", "eventlng", "eventlat"};
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }
            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = spark.createDataFrame(rows.repartition(partSize), structType);
            String tempTable = "shiva_oms_core_operation_waybill_test_" + System.currentTimeMillis();
            ds.createOrReplaceTempView(tempTable);
            logger.error("targetTable:{}", table);
            spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                    "select * from %s", table, date, tempTable));
            rows.unpersist();
            spark.catalog().dropTempView(tempTable);
        }
    }


    public void saveData(SparkSession spark, JavaRDD<ShivaOmsCoreOperationWaybillKafka> inRdd, String table, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getOrder_no(),
                    o.getSender_comp_name(), o.getSender_addr(), o.getSender_province(), o.getSender_city(), o.getSender_city_code(), o.getSender_area(), o.getSender_phone(), o.getSender_mobile(),
                    o.getReceiver_comp_name(), o.getReceiver_addr(), o.getReceiver_province(), o.getReceiver_city(), o.getReceiver_city_code(), o.getReceiver_area(), o.getReceiver_phone(), o.getReceiver_mobile(),
                    o.getSource_waybill_no(), o.getCustomer_acct_code()
            );
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        if (rows.count() > 0) {
            int partSize = CalPartitionUtil.getPartitionSize(rows);
            List<StructField> structFieldList = new ArrayList<>();
            String[] columnNames = new String[]{"waybill_no", "order_no",
                    "sender_comp_name", "sender_addr", "sender_province", "sender_city", "sender_city_code", "sender_area", "sender_phone", "sender_mobile",
                    "receiver_comp_name", "receiver_addr", "receiver_province", "receiver_city", "receiver_city_code", "receiver_area", "receiver_phone", "receiver_mobile",
                    "source_waybill_no", "customer_acct_code"};
            DataType stringType = DataTypes.StringType;
            for (String columnName : columnNames) {
                structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
            }
            StructType structType = DataTypes.createStructType(structFieldList);
            Dataset<Row> ds = spark.createDataFrame(rows.repartition(partSize), structType);
            String tempTable = "shiva_oms_core_operation_waybill_test_" + System.currentTimeMillis();
            ds.createOrReplaceTempView(tempTable);
            logger.error("targetTable:{}", table);
            spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                    "select * from %s", table, date, tempTable));
            rows.unpersist();
            spark.catalog().dropTempView(tempTable);
        }
    }

    public JavaRDD<ShivaOmsCoreOperationWaybillKafka> loadOperationWaybillData(SparkInfo si, String date) {
        String sql = SqlUtil.getSqlStr("shiva_oms_core_operation_waybill_kafka.sql", date);
        return DataUtil.loadData(si, sql, ShivaOmsCoreOperationWaybillKafka.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafkaSj> loadSjTagAoi(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.sj_aoi where inc_day = '%s' and original_tag is not null and original_tag <>''", date);
        return DataUtil.loadData(si, sql, EdcsWaybillContentSwsKafkaSj.class);
    }

    public JavaRDD<AoiAreaAoi> loadAoiAreaAoiData(SparkInfo si) {
        String sql = "select aoi_id,aoi_area_code from dm_tc_waybillinfo.aoi_area_aoi";
        return DataUtil.loadData(si, sql, AoiAreaAoi.class);
    }

    public JavaRDD<TmDepartment> loadTmDepartmentWageLevel(SparkInfo si, String date) {
        String sql = String.format("select dept_code,pick_wage_aoi_id,send_wage_aoi_id,dept_aoi_id from dm_gis.tm_department_wage_level where inc_day = '%s'", date);
        return DataUtil.loadData(si, sql, TmDepartment.class);
    }

    public JavaRDD<OrderWaybillHook> loadTtOrderWaybillData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select consignee_emp_code emp_code,aoi_id,aoi_zc from dm_gis.tt_order_hook where inc_day between '%s' and '%s' and consignee_emp_code is not null and consignee_emp_code <>'' and aoi_id is not null and aoi_id <>'' union (select deliver_emp_code emp_code,aoi_id,aoi_zc from dm_gis.tt_waybill_hook where inc_day between '%s' and '%s' and deliver_emp_code is not null and deliver_emp_code <>'' and aoi_id is not null and aoi_id <>'')", startDate, endDate, startDate, endDate);
        return DataUtil.loadData(si, sql, OrderWaybillHook.class);
    }

    public JavaRDD<OrderWaybillHook> loadTtOrderWaybillPretreatmentData(SparkInfo si) {
        String sql = String.format("select * from dm_gis.hook_pretreatment");
        return DataUtil.loadData(si, sql, OrderWaybillHook.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> joinZnocodeToAoi(JavaRDD<EdcsWaybillContentSwsKafka> swsKafkaRdd, JavaRDD<ZnocodeToAoi> znocodeToAoiRdd, String getAoiByXyUrl, String tag) {
        return swsKafkaRdd.mapToPair(o -> new Tuple2<>(StringUtils.equals(tag, "sj") ? o.getOriginal_zone_code() : o.getDestination_zone_code(), o))
                .leftOuterJoin(znocodeToAoiRdd.mapToPair(o -> new Tuple2<>(o.getDept_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        String type_code = o.getType_code();
                        String position_name = o.getPosition_name();
                        if (StringUtils.equals(type_code, "FB05-CCPSCK") || StringUtils.equals(position_name, "仓管员") || StringUtils.equals(position_name, "仓管组长")
                                || StringUtils.equals(position_name, "接驳员") || StringUtils.equals(position_name, "营业员")) {
                            ZnocodeToAoi znocodeToAoi = tp._2._2.get();
                            String aoi_id = znocodeToAoi.getAoi_id();
                            if (StringUtils.isNotEmpty(aoi_id)) {
                                o.setLastAoiid(aoi_id);
                                o.setTag("zc");
                            }
                        }
                    }
                    return o;
                }).map(o -> {
                    if (StringUtils.isNotEmpty(o.getLastAoiid())) {
                        String position_name = o.getPosition_name();
                        if (StringUtils.equals(position_name, "国际件理货员") || StringUtils.equals(position_name, "数据信息员") || StringUtils.equals(position_name, "运作员")
                                || StringUtils.equals(position_name, "运作组长") || StringUtils.equals(position_name, "中转场负责人") || StringUtils.equals(position_name, "中转场运营主管")) {
                            String emap_lng = o.getEmap_lng();
                            String emap_lat = o.getEmap_lat();
                            if (StringUtils.isNotEmpty(emap_lng) && StringUtils.isNotEmpty(emap_lat)) {
                                String aoiAndZc = getAoiByXy(getAoiByXyUrl, emap_lng, emap_lng);
                                if (StringUtils.isNotEmpty(aoiAndZc) && aoiAndZc.split(",").length > 0) {
                                    String aoi = aoiAndZc.split(",")[0];
                                    if (StringUtils.isNotEmpty(aoi)) {
                                        o.setLastAoiid(aoi);
                                        o.setTag("trans");
                                    }
                                }
                            }
                        }
                    }
                    return o;
                });
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> joinPositionName(JavaRDD<EdcsWaybillContentSwsKafka> swsKafkaRdd, JavaRDD<TmDepartment> tmDepartmentRdd, JavaRDD<EmpInfoDtlDf> empInfoDtlDfRdd, JavaRDD<EmapLayerFeatureCmsemap> emapLayerFeatureCmsemapRdd, String tag) {
        return swsKafkaRdd.mapToPair(o -> new Tuple2<>(StringUtils.equals(tag, "sj") ? o.getOriginal_zone_code() : o.getDestination_zone_code(), o))
                .leftOuterJoin(tmDepartmentRdd.mapToPair(o -> new Tuple2<>(o.getDept_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        TmDepartment tmDepartment = tp._2._2.get();
                        o.setType_code(tmDepartment.getType_code());
                    }
                    return o;
                }).mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).leftOuterJoin(empInfoDtlDfRdd.mapToPair(o -> new Tuple2<>(o.getEmp_code(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        EmpInfoDtlDf empInfoDtlDf = tp._2._2.get();
                        o.setPosition_name(empInfoDtlDf.getPosition_name());
                        o.setDept_code(empInfoDtlDf.getDept_code());
                    }
                    return o;
                }).mapToPair(o -> new Tuple2<>(o.getDept_code(), o)).leftOuterJoin(emapLayerFeatureCmsemapRdd.mapToPair(o -> new Tuple2<>(o.getCode(), o)).reduceByKey((o1, o2) -> o1))
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        EmapLayerFeatureCmsemap emapLayerFeatureCmsemap = tp._2._2.get();
                        o.setEmap_lng(emapLayerFeatureCmsemap.getLng());
                        o.setEmap_lat(emapLayerFeatureCmsemap.getLat());
                    }
                    return o;
                });
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> joinTtAppointAddition(JavaRDD<EdcsWaybillContentSwsKafka> swsKafkaRdd, JavaRDD<TtAppointAdditionKafka> ttAppointAdditionRdd) {
        return swsKafkaRdd.mapToPair(o -> new Tuple2<>(o.getWaybillnoOrderNo(), o)).leftOuterJoin(ttAppointAdditionRdd.mapToPair(o -> new Tuple2<>(o.getTxid(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
            EdcsWaybillContentSwsKafka o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                TtAppointAdditionKafka ttAppointAdditionKafka = tp._2._2.get();
                o.setSrc_lgt(ttAppointAdditionKafka.getLongitude());
                o.setSrc_lat(ttAppointAdditionKafka.getLatitude());
            }
            return o;
        });
    }


    public JavaRDD<EdcsWaybillContentSwsKafka> joinIncSgsTaskFlow(JavaRDD<EdcsWaybillContentSwsKafka> swsKafkaRdd, JavaRDD<IncSgsTaskFlowNew> incSgsTaskFlowSjRdd) {
        return swsKafkaRdd.mapToPair(o -> new Tuple2<>(o.getWaybill_no(), o)).leftOuterJoin(incSgsTaskFlowSjRdd.mapToPair(o -> new Tuple2<>(o.getWaybillno(), o)).groupByKey())
                .map(tp -> {
                    EdcsWaybillContentSwsKafka o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        List<IncSgsTaskFlowNew> list = Lists.newArrayList(tp._2._2.get());
                        List<IncSgsTaskFlowNew> type54List = list.stream().filter(tt -> StringUtils.equals(tt.getEventtype(), "31201")).collect(Collectors.toList());
                        if (type54List.size() > 0) {
                            IncSgsTaskFlowNew incSgsTaskFlowNew = type54List.get(0);
                            String eventlng = incSgsTaskFlowNew.getEventlng();
                            String eventlat = incSgsTaskFlowNew.getEventlat();

                            o.setEventlng(eventlng);
                            o.setEventlat(eventlat);
                        } else {
                            List<IncSgsTaskFlowNew> type50List = list.stream().filter(tt -> StringUtils.equals(tt.getEventtype(), "31127")).collect(Collectors.toList());
                            if (type50List.size() > 0) {
                                IncSgsTaskFlowNew incSgsTaskFlowNew = type50List.get(0);
                                String eventlng = incSgsTaskFlowNew.getEventlng();
                                String eventlat = incSgsTaskFlowNew.getEventlat();

                                o.setEventlng(eventlng);
                                o.setEventlat(eventlat);
                            }
                        }
                    }
                    return o;
                });
    }

    public JavaRDD<AoiStatAoiid> loadAoiStatAoiid(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select aoi_id,count,inc_day from dm_gis.aoi_stat_aoiid where inc_day between '%s' and '%s' and stattype = 'all'", startDate, endDate);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, AoiStatAoiid.class);
    }

    public JavaRDD<AoiValue> loadAoiValueApplacation(SparkInfo si, String date) {
        String cntsql = String.format("select count(1) from dm_tc_waybillinfo.aoi_value_applacation where inc_month = '%s' and application_value_source != 3", date.substring(0, 6));
        logger.error(cntsql);
        List<Row> list = si.getSession().sql(cntsql).toJavaRDD().collect();
        long count = list.get(0).getLong(0);
        String sql = "";
        String last_month = "";
        if (count != 0) {
            last_month = date.substring(0, 6);
        } else {
            last_month = DateUtil.getMouthBefore(date, 1, "yyyyMMdd").substring(0, 6);
        }
        sql = String.format("select aoi_id,pick_wage_level,send_wage_level from dm_tc_waybillinfo.aoi_value_applacation where inc_month = '%s' and application_value_source != 3", last_month);
        return DataUtil.loadData(si, sql, AoiValue.class);
    }

    public JavaRDD<EmapLayerFeatureCmsemap> loadEmapLayer(SparkInfo si) {
        String sql = "select code,lng,lat from dm_gis.emap_layer_feature_cmsemap where layer_id = '5' and state = '3' and code is not null and code <>''";
        return DataUtil.loadData(si, sql, EmapLayerFeatureCmsemap.class);
    }

    public JavaRDD<TmDepartment> loadTmDepartment(SparkInfo si, String date) {
        String sql = String.format("select dept_code,type_code from ods_asura.tm_department where inc_day = '%s' and dept_code is not null and dept_code <>''", date);
        return DataUtil.loadData(si, sql, TmDepartment.class);
    }

    public JavaRDD<ZnocodeToAoi> loadZnocodeToAoi(SparkInfo si, String date) {
        String sql = String.format("select dept_code,aoi_id from dm_gis.znocode_2_aoi where inc_day = '%s' and aoi_id is not null and aoi_id <>''", date);
        return DataUtil.loadData(si, sql, ZnocodeToAoi.class);
    }


    public JavaRDD<TtAppointAdditionKafka> loadTtAppointAdditionKafka(SparkInfo si, String date) {
        String sql = String.format("select get_json_object(log, '$.txid') txid,get_json_object(log, '$.expressInfoList') express_info_list from dm_gis.tt_appoint_addition_kafka where inc_day = '%s' and get_json_object(log, '$.txid') is not null and get_json_object(log, '$.txid') <>''", date);
        return DataUtil.loadData(si, sql, TtAppointAdditionKafka.class);
    }

    public JavaRDD<IncSgsTaskFlowNew> loadIncSgsTaskFlowSjData(SparkInfo si, String date) {
        String sql = SqlUtil.getSqlStr("sgs_exp_core_bizlog_data_kafka_sj.sql", date);
        return DataUtil.loadData(si, sql, IncSgsTaskFlowNew.class);
    }

    public JavaRDD<FvpCoreFactRouteRt> loadFvpCoreFactRouteRtData(SparkInfo si, String date) {
        String sql = String.format("select mainwaybillno,couriercode from ods_kafka_fvp.fvp_core_fact_route_rt where inc_day = '%s' and mainwaybillno is not null and mainwaybillno <>'' and couriercode is not null and couriercode <>'' and couriercode != 'null'", date);
        return DataUtil.loadData(si, sql, FvpCoreFactRouteRt.class);
    }

    public JavaRDD<FvpCoreFactRouteRt> loadFvpCoreFactRouteRtExtsData(SparkInfo si, String date) {
        String sql = SqlUtil.getSqlStr("fvp_core_fact_route_rt_contnrcode.sql", date);
        return DataUtil.loadData(si, sql, FvpCoreFactRouteRt.class);
    }

    public JavaRDD<GisRdsOmsfrom> loadRdsOmsfromData(SparkInfo si, String date) {
        String sql = String.format("select waybillno,syncreqdatetime,finalaoicode,deptcode,inc_day from dm_gis.gis_rds_omsfrom where inc_day = '%s' and waybillno is not null and waybillno <>''", date);
        return DataUtil.loadData(si, sql, GisRdsOmsfrom.class);
    }

    public JavaRDD<GisRdsOmsfrom> loadRdsOmsfromPretreatmentData(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.gis_rds_omsfrom_pretreatment where inc_day = '%s'", date);
        return DataUtil.loadData(si, sql, GisRdsOmsfrom.class);
    }

    public JavaRDD<ScheduleWidthData> loadScheduleWidthData(SparkInfo si, String date) {
        String sql = String.format("select dept_code,loginid,guid aoi_id,inc_day from dm_tc_waybillinfo.tm_schedule_width_data_v2 where inc_day = '%s' and guid is not null and guid <>''", date);
        return DataUtil.loadData(si, sql, ScheduleWidthData.class);
    }

    public JavaRDD<ScheduleWidthData> loadScheduleWidthPretreatmentData(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.tm_schedule_width_data_v2_pretreatment where inc_day = '%s'", date);
        return DataUtil.loadData(si, sql, ScheduleWidthData.class);
    }

    public String processTakeoverMemberNo(String takeover_member_no) {
        int length = takeover_member_no.length();
        StringBuilder fix = new StringBuilder();
        if (length < 8) {
            for (int i = 0; i < 8 - length; i++) {
                fix.append("0");
            }
            takeover_member_no = fix + takeover_member_no;
        }
        return takeover_member_no;
    }

    public JavaRDD<EmpInfoDtlDf> loadEmpInfoAll(SparkInfo si, String date) {
        String sql = String.format("select emp_code,position_name,dept_code from dwd.dwd_emp_info_dtl_df where inc_day = '%s'", date);
        return DataUtil.loadData(si, sql, EmpInfoDtlDf.class);
    }

    public JavaRDD<EmpInfoDtlDf> loadEmpInfoAll_1(SparkSession si, JavaSparkContext sc, String date) {
        String sql = String.format("select emp_code,position_name,dept_code from (SELECT emp_code,position as position_name,dept_code,row_number() over(distribute by emp_code sort by emp_code) as rn FROM dm_gis.the_shipping_address_does_not_match_1 where inc_day = '%s') as tmp where rn = 1", date);
        return DataUtil.loadData(si, sc, sql, EmpInfoDtlDf.class);
    }

    public JavaRDD<EmpInfoDtlDf> loadEmpInfoAll_2(SparkSession si, JavaSparkContext sc, String date, String hour_1) {
        String sql = String.format("select emp_code,position_name,dept_code from (SELECT emp_code,position as position_name,dept_code,row_number() over(distribute by emp_code sort by emp_code) as rn FROM dm_gis.sa_false_profit_incoming_shipments_process_pre_1 where inc_day = '%s' and inc_hour = '%s') as tmp where rn = 1", date, hour_1);
        return DataUtil.loadData(si, sc, sql, EmpInfoDtlDf.class);
    }

    public JavaRDD<EmpInfoDtlDf> loadEmpInfoAll_3(SparkSession si, JavaSparkContext sc, String date) {
        String sql = String.format("select emp_code,position_name,dept_code from (SELECT emp_code,position as position_name,dept_code,row_number() over(distribute by emp_code sort by emp_code) as rn FROM dm_ecas_dcs.tt_edcs_hive_commission_detail where inc_day = '%s' and is_apply_aoi = '1' and audit_type = '1' and scene_type = '2') as tmp where rn = 1", date);
        return DataUtil.loadData(si, sc, sql, EmpInfoDtlDf.class);
    }

    public JavaRDD<EmpInfoDtlDf> loadEmpInfoAll_4(SparkSession si, JavaSparkContext sc, String date) {
        String sql = String.format("select emp_code,position_name,dept_code from (SELECT emp_code,position as position_name,dept_code,row_number() over(distribute by emp_code sort by emp_code) as rn FROM dm_gis.sa_false_profit_incoming_shipments_process_pre_1 where inc_day = '%s') as tmp where rn = 1", date);
        return DataUtil.loadData(si, sc, sql, EmpInfoDtlDf.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> loadData(SparkInfo si, String date, String minDate) {
        String sql = SqlUtil.getSqlStr("tt_edcs_waybill_content_sws_kafka_sj.sql", date, minDate);
        return DataUtil.loadData(si, sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<GisRdsOmsto> loadRdsOmstoData(SparkInfo si, String startDate, String endDate) {
        String sql = String.format("select req_orderno,finalzc,finalaoiid from dm_gis.gis_rds_omsto where inc_day between '%s' and '%s' and req_orderno is not null and req_orderno <>''", startDate, endDate);
        return DataUtil.loadData(si, sql, GisRdsOmsto.class);
    }

    public JavaRDD<GisRdsOmsto> loadRdsOmstoPretreatmentData(SparkInfo si) {
        String sql = String.format("select * from dm_gis.gis_rds_omsto_pretreatment");
        return DataUtil.loadData(si, sql, GisRdsOmsto.class);
    }

    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkInfo si) {
        String sql = "select aoi_id,aoi_code,aoi_name,fa_type,zno_code from dm_gis.cms_aoi_sch";
        return DataUtil.loadData(si, sql, CmsAoiSch.class);
    }

    public JavaRDD<TtWaybillInfo> getTtWaybillInfoRdd(SparkInfo si,String date) {
        //String sql = String.format("select waybill_no,order_no,consignee_addr from dm_gis.tt_waybill_info where inc_day = '%s'", date);
        String sql = String.format("select waybill_no,order_no,consignee_addr_decrypt as consignee_addr from dm_gis.dwd_waybill_info_dtl_di where inc_day = '%s'", date);
        return DataUtil.loadData(si, sql, TtWaybillInfo.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> getEventLngLatRDD(SparkInfo si,String date) {
        String sql = String.format("select waybillno as waybill_no,eventlng,eventlat from ods_inc_sgs_core.inc_sgs_task_flow_new where inc_day = '%s' and eventtype in ('31201','31127')", date);
        return DataUtil.loadData(si, sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> getTrackAoiRDD(SparkInfo si,String date) {
        String sql = String.format("SELECT lng as eventlng,lat as eventlat,aoi_id FROM dm_gis.dwb_track_aoi_di where inc_day = '%s'", date);
        return DataUtil.loadData(si, sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<EdcsWaybillContentSwsKafka> getTtAppointAdditionRDD(SparkInfo si,String date) {
        String sql = String.format("select\n" +
                "\t a.appoint_internal_no as waybill_no\n" +
                "\t,a.x as eventlng\n" +
                "\t,b.y as eventlat\n" +
                "from\n" +
                "(\n" +
                "\tselect appoint_internal_no,addition_value as x from ods_shiva_oms.tt_appoint_addition where inc_day = '%s' and addition_key = 'LONGITUDE' group by inc_day,appoint_internal_no,addition_value\n" +
                ") as a\n" +
                "\n" +
                "left join\n" +
                "\n" +
                "(\n" +
                " \tselect appoint_internal_no,addition_value as y from ods_shiva_oms.tt_appoint_addition where inc_day = '%s' and addition_key = 'LATITUDE'group by inc_day,appoint_internal_no,addition_value\n" +
                ") as b\n" +
                "\n" +
                "on a.appoint_internal_no = b.appoint_internal_no", date, date);
        return DataUtil.loadData(si, sql, EdcsWaybillContentSwsKafka.class);
    }

    public JavaRDD<AddressInfoMapDi> loadAddressInfoMapDiData(SparkInfo si) {
        String sql = "select * from dm_gis.city_name_map where inc_day = '20210317'";
        return DataUtil.loadData(si, sql, AddressInfoMapDi.class);
    }

    public String getCityCode(String zonecode) {
        String str = "";
        if (StringUtils.isNotEmpty(zonecode)) {
            zonecode = zonecode.trim();
            for (int i = 0; i < zonecode.length(); i++) {
                char c = zonecode.charAt(i);
                if (Character.isLowerCase(c) || Character.isUpperCase(c)) {
                    break;
                }
                if (c >= 48 && c <= 57) {
                    str += c;
                }
            }

        }
        return str;
    }

    public List<NsCfgDto> getNsCfgList() {
        String dbConfig = "rls-mysql.properties";
        Connection conn = DbUtil.getInstance(dbConfig).getConn();
        List<NsCfgDto> nsCfgList = new ArrayList<>();
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("select ns_code,ns_type_code,check_code_rule,extend from TM_NS_CFG");
            while (rs.next()) {
                NsCfgDto nsCfgDto = new NsCfgDto();
                String ns_code = rs.getString(1);
                String ns_type_code = rs.getString(2);
                String check_code_rule = rs.getString(3);
                String extend = rs.getString(4);

                nsCfgDto.setNsCode(ns_code);
                nsCfgDto.setNsTypeCode(ns_type_code);
                nsCfgDto.setCheckCodeRule(check_code_rule);
                nsCfgDto.setExtend(extend);
                nsCfgList.add(nsCfgDto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return nsCfgList;
    }


    public String getSimilarity(String url, String beforeAddress, String afterAddress) {
        String similarity = "";
        try {
            String req = String.format(url, URLEncoder.encode(beforeAddress, "UTF-8"), URLEncoder.encode(afterAddress, "UTF-8"));
            String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
            if (StringUtils.isNotEmpty(content)) {
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null && jsonObject.getInteger("status") == 0) {
                    similarity = jsonObject.getString("result");
                    logger.error("similarity:{}", similarity);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return similarity;
    }


    public String getAoiByXy(String url, String x, String y) {
        String aoi = "";
        String ac = "";
        try {
            JSONArray coords = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("lng", x);
            jsonObject.put("lat", y);
            coords.add(jsonObject);

            JSONObject param = new JSONObject();
            param.put("ak", "2d56aff133e7456584abd3c1be674f0f");
            param.put("coords", coords);
            String content = HttpInvokeUtil.sendPost(url, param.toJSONString());
            if (StringUtils.isNotEmpty(content)) {
                JSONObject jsonObject1 = JSON.parseObject(content);
                if (jsonObject1 != null && jsonObject1.getInteger("status") == 0) {
                    JSONObject result = jsonObject1.getJSONObject("result");
                    if (result != null) {
                        JSONObject data = result.getJSONObject("data");
                        if (data != null) {
                            JSONArray aois = data.getJSONArray("aois");
                            if (aois != null && aois.size() > 0) {
                                JSONObject jsonObject2 = aois.getJSONObject(0);
                                aoi = jsonObject2.getString("aoi_id");
                                ac = jsonObject2.getString("ac");
                                logger.error("aoi:{}, ac:{}", aoi, ac);
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return aoi + "," + ac;
    }


    public String doGet(String url, String systemKey) {
        HttpClient client = HttpClientBuilder.create().build();
        HttpGet get = new HttpGet(url);
        JSONObject response = null;
        get.addHeader("Content-type", "application/json; charset=utf-8");
        get.setHeader("Accept", "application/json");
        get.setHeader("systemKey", systemKey);
        String result = "";
        try {
            HttpResponse res = client.execute(get);
            if (res.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                HttpEntity entity = res.getEntity();
                result = EntityUtils.toString(entity, "UTF-8");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
}
