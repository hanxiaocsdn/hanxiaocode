package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 虚假管控：实时弹窗逻辑修正验证（数据对象），存储运单妥投和轨迹相关信息
 * @author 01370539
 * Created on Jun.20 2022
 */
@Table
public class FcDlv implements Serializable {
    @Column(name = "couriercode")
    private String couriercode;
    @Column(name = "waybill_no")
    private String waybillNo;
    @Column(name = "area_code")
    private String areaCode;
    @Column(name = "dest_zone_code")
    private String destZoneCode;
    @Column(name = "aoi_id")
    private String aoiId;
    @Column(name = "aoi_type_name")
    private String aoiTypeName;
    @Column(name = "aoi_type_code")
    private String aoiTypeCode;
    @Column(name = "barscantm80")
    private String barscantm80;
    @Column(name = "lng80")
    private String lng80;
    @Column(name = "lat80")
    private String lat80;
    @Column(name = "istougui")
    private String istougui;
    @Column(name = "iszijiziqu")
    private String iszijiziqu;
    @Column(name = "isdld")
    private String isdld;
    @Column(name = "iswd")
    private String iswd;
    @Column(name = "iszhuanjituihui")
    private String iszhuanjituihui;
    @Column(name = "istoken")
    private String istoken;
    @Column(name = "isphone100")
    private String isphone100;
    @Column(name = "iscopyphone")
    private String iscopyphone;
    @Column(name = "iscallphone")
    private String iscallphone;
    @Column(name = "isfwsjg2g")
    private String isfwsjg2g;
    @Column(name = "isexternal")
    private String isexternal;
    @Column(name = "addr")
    private String addr;
    @Column(name = "lng_blding")
    private String lngBlding;
    @Column(name = "lat_blding")
    private String latBlding;
    @Column(name = "lng_track")
    private String lngTrack;
    @Column(name = "lat_track")
    private String latTrack;
    @Column(name = "tm_track")
    private String tmTrack;
    @Column(name = "tp_track")
    private String tpTrack;
    @Column(name = "type")
    private String type;
    @Column(name = "track_cnt")
    private String trackCnt;
    @Column(name = "cnyz_cnt")
    private String cnyzCnt;
    @Column(name = "addr_tag")
    private String addrTag;
    @Column(name = "city_code")
    private String cityCode;
    @Column(name = "lng_zc")
    private String lngZc;
    @Column(name = "lat_zc")
    private String latZc;
    @Column(name = "addr_src")
    private String addrSrc;
    @Column(name = "isinzc300")
    private String isInZc300;
    @Column(name = "inc_day")
    private String incDay;
    private double tmpDis;
    private List<FcDlv> cnyzList = new ArrayList<>();

    public String getCouriercode() {
        return couriercode;
    }

    public void setCouriercode(String couriercode) {
        this.couriercode = couriercode;
    }

    public String getWaybillNo() {
        return waybillNo;
    }

    public void setWaybillNo(String waybillNo) {
        this.waybillNo = waybillNo;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getDestZoneCode() {
        return destZoneCode;
    }

    public void setDestZoneCode(String destZoneCode) {
        this.destZoneCode = destZoneCode;
    }

    public String getAoiId() {
        return aoiId;
    }

    public void setAoiId(String aoiId) {
        this.aoiId = aoiId;
    }

    public String getAoiTypeName() {
        return aoiTypeName;
    }

    public void setAoiTypeName(String aoiTypeName) {
        this.aoiTypeName = aoiTypeName;
    }

    public String getAoiTypeCode() {
        return aoiTypeCode;
    }

    public void setAoiTypeCode(String aoiTypeCode) {
        this.aoiTypeCode = aoiTypeCode;
    }

    public String getBarscantm80() {
        return barscantm80;
    }

    public void setBarscantm80(String barscantm80) {
        this.barscantm80 = barscantm80;
    }

    public String getLng80() {
        return lng80;
    }

    public void setLng80(String lng80) {
        this.lng80 = lng80;
    }

    public String getLat80() {
        return lat80;
    }

    public void setLat80(String lat80) {
        this.lat80 = lat80;
    }

    public String getIstougui() {
        return istougui;
    }

    public void setIstougui(String istougui) {
        this.istougui = istougui;
    }

    public String getIszijiziqu() {
        return iszijiziqu;
    }

    public void setIszijiziqu(String iszijiziqu) {
        this.iszijiziqu = iszijiziqu;
    }

    public String getIsdld() {
        return isdld;
    }

    public void setIsdld(String isdld) {
        this.isdld = isdld;
    }

    public String getIswd() {
        return iswd;
    }

    public void setIswd(String iswd) {
        this.iswd = iswd;
    }

    public String getIszhuanjituihui() {
        return iszhuanjituihui;
    }

    public void setIszhuanjituihui(String iszhuanjituihui) {
        this.iszhuanjituihui = iszhuanjituihui;
    }

    public String getIstoken() {
        return istoken;
    }

    public void setIstoken(String istoken) {
        this.istoken = istoken;
    }

    public String getIsphone100() {
        return isphone100;
    }

    public void setIsphone100(String isphone100) {
        this.isphone100 = isphone100;
    }

    public String getIscopyphone() {
        return iscopyphone;
    }

    public void setIscopyphone(String iscopyphone) {
        this.iscopyphone = iscopyphone;
    }

    public String getIscallphone() {
        return iscallphone;
    }

    public void setIscallphone(String iscallphone) {
        this.iscallphone = iscallphone;
    }

    public String getIsfwsjg2g() {
        return isfwsjg2g;
    }

    public void setIsfwsjg2g(String isfwsjg2g) {
        this.isfwsjg2g = isfwsjg2g;
    }

    public String getIsexternal() {
        return isexternal;
    }

    public void setIsexternal(String isexternal) {
        this.isexternal = isexternal;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getLngBlding() {
        return lngBlding;
    }

    public void setLngBlding(String lngBlding) {
        this.lngBlding = lngBlding;
    }

    public String getLatBlding() {
        return latBlding;
    }

    public void setLatBlding(String latBlding) {
        this.latBlding = latBlding;
    }

    public String getLngTrack() {
        return lngTrack;
    }

    public void setLngTrack(String lngTrack) {
        this.lngTrack = lngTrack;
    }

    public String getLatTrack() {
        return latTrack;
    }

    public void setLatTrack(String latTrack) {
        this.latTrack = latTrack;
    }

    public String getTmTrack() {
        return tmTrack;
    }

    public void setTmTrack(String tmTrack) {
        this.tmTrack = tmTrack;
    }

    public String getTpTrack() {
        return tpTrack;
    }

    public void setTpTrack(String tpTrack) {
        this.tpTrack = tpTrack;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTrackCnt() {
        return trackCnt;
    }

    public void setTrackCnt(String trackCnt) {
        this.trackCnt = trackCnt;
    }

    public String getCnyzCnt() {
        return cnyzCnt;
    }

    public void setCnyzCnt(String cnyzCnt) {
        this.cnyzCnt = cnyzCnt;
    }

    public String getAddrTag() {
        return addrTag;
    }

    public void setAddrTag(String addrTag) {
        this.addrTag = addrTag;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getLngZc() {
        return lngZc;
    }

    public void setLngZc(String lngZc) {
        this.lngZc = lngZc;
    }

    public String getLatZc() {
        return latZc;
    }

    public void setLatZc(String latZc) {
        this.latZc = latZc;
    }

    public String getAddrSrc() {
        return addrSrc;
    }

    public void setAddrSrc(String addrSrc) {
        this.addrSrc = addrSrc;
    }

    public String getIsInZc300() {
        return isInZc300;
    }

    public void setIsInZc300(String isInZc300) {
        this.isInZc300 = isInZc300;
    }

    public String getIncDay() {
        return incDay;
    }

    public void setIncDay(String incDay) {
        this.incDay = incDay;
    }

    public double getTmpDis() {
        return tmpDis;
    }

    public void setTmpDis(double tmpDis) {
        this.tmpDis = tmpDis;
    }

    public List<FcDlv> getCnyzList() {
        return cnyzList;
    }

    public void setCnyzList(List<FcDlv> cnyzList) {
        this.cnyzList = cnyzList;
    }

    @Override
    public String toString() {
        return "FcDlv{" +
                "couriercode='" + couriercode + '\'' +
                ", waybillNo='" + waybillNo + '\'' +
                ", areaCode='" + areaCode + '\'' +
                ", destZoneCode='" + destZoneCode + '\'' +
                ", aoiId='" + aoiId + '\'' +
                ", aoiTypeName='" + aoiTypeName + '\'' +
                ", aoiTypeCode='" + aoiTypeCode + '\'' +
                ", barscantm80='" + barscantm80 + '\'' +
                ", lng80='" + lng80 + '\'' +
                ", lat80='" + lat80 + '\'' +
                ", istougui='" + istougui + '\'' +
                ", iszijiziqu='" + iszijiziqu + '\'' +
                ", isdld='" + isdld + '\'' +
                ", iswd='" + iswd + '\'' +
                ", iszhuanjituihui='" + iszhuanjituihui + '\'' +
                ", istoken='" + istoken + '\'' +
                ", isphone100='" + isphone100 + '\'' +
                ", iscopyphone='" + iscopyphone + '\'' +
                ", iscallphone='" + iscallphone + '\'' +
                ", isfwsjg2g='" + isfwsjg2g + '\'' +
                ", isexternal='" + isexternal + '\'' +
                ", addr='" + addr + '\'' +
                ", lngBlding='" + lngBlding + '\'' +
                ", latBlding='" + latBlding + '\'' +
                ", lngTrack='" + lngTrack + '\'' +
                ", latTrack='" + latTrack + '\'' +
                ", tmTrack='" + tmTrack + '\'' +
                ", tpTrack='" + tpTrack + '\'' +
                ", type='" + type + '\'' +
                ", trackCnt='" + trackCnt + '\'' +
                ", cnyzCnt='" + cnyzCnt + '\'' +
                ", addrTag='" + addrTag + '\'' +
                ", cityCode='" + cityCode + '\'' +
                ", lngZc='" + lngZc + '\'' +
                ", latZc='" + latZc + '\'' +
                ", addrSrc='" + addrSrc + '\'' +
                ", isInZc300='" + isInZc300 + '\'' +
                ", incDay='" + incDay + '\'' +
                ", tmpDis=" + tmpDis +
                ", cnyzList=" + cnyzList +
                '}';
    }
}
