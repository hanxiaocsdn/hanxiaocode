package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ChkDisFieldStat implements Serializable {
    @Column(name = "id")
    private String id;
    @Column(name = "stat_day")
    private String stat_day;
    @Column(name = "stat_hour")
    private String stat_hour;
    @Column(name = "stat_start_min")
    private String stat_start_min;
    @Column(name = "stat_end_min")
    private String stat_end_min;
    @Column(name = "addresseeaoiarea_emp_cnt")
    private String addresseeaoiarea_emp_cnt;
    @Column(name = "addresseeaoiareagroup_emp_cnt")
    private String addresseeaoiareagroup_emp_cnt;
    @Column(name = "addresseeaoiareagrouppf_emp_cnt")
    private String addresseeaoiareagrouppf_emp_cnt;
    @Column(name = "addresseeaoiid_emp_cnt")
    private String addresseeaoiid_emp_cnt;
    @Column(name = "addresseeaoitype_emp_cnt")
    private String addresseeaoitype_emp_cnt;
    @Column(name = "addresseecitycode_emp_cnt")
    private String addresseecitycode_emp_cnt;
    @Column(name = "addresseedeptcode_emp_cnt")
    private String addresseedeptcode_emp_cnt;
    @Column(name = "addresseekeyword_emp_cnt")
    private String addresseekeyword_emp_cnt;
    @Column(name = "addresseetransitcode_emp_cnt")
    private String addresseetransitcode_emp_cnt;
    @Column(name = "addresseetransitcodecp_emp_cnt")
    private String addresseetransitcodecp_emp_cnt;
    @Column(name = "aggbuild_emp_cnt")
    private String aggbuild_emp_cnt;
    @Column(name = "aggroom_emp_cnt")
    private String aggroom_emp_cnt;
    @Column(name = "aggunit_emp_cnt")
    private String aggunit_emp_cnt;
    @Column(name = "autosrc_emp_cnt")
    private String autosrc_emp_cnt;
    @Column(name = "fnsdeliverycode_emp_cnt")
    private String fnsdeliverycode_emp_cnt;
    @Column(name = "fnsfirstdeptcode_emp_cnt")
    private String fnsfirstdeptcode_emp_cnt;
    @Column(name = "fnstransfercode_emp_cnt")
    private String fnstransfercode_emp_cnt;
    @Column(name = "inneradflag_emp_cnt")
    private String inneradflag_emp_cnt;
    @Column(name = "kwsrc_emp_cnt")
    private String kwsrc_emp_cnt;
    @Column(name = "kydeptcode_emp_cnt")
    private String kydeptcode_emp_cnt;
    @Column(name = "kyteamcode_emp_cnt")
    private String kyteamcode_emp_cnt;
    @Column(name = "kytransfercode_emp_cnt")
    private String kytransfercode_emp_cnt;
    @Column(name = "logdata_emp_cnt")
    private String logdata_emp_cnt;
    @Column(name = "lpflag_emp_cnt")
    private String lpflag_emp_cnt;
    @Column(name = "orderno_emp_cnt")
    private String orderno_emp_cnt;
    @Column(name = "overlargeinfo_emp_cnt")
    private String overlargeinfo_emp_cnt;
    @Column(name = "receiveraddr_emp_cnt")
    private String receiveraddr_emp_cnt;
    @Column(name = "receiverarea_emp_cnt")
    private String receiverarea_emp_cnt;
    @Column(name = "receivercity_emp_cnt")
    private String receivercity_emp_cnt;
    @Column(name = "receiverprovince_emp_cnt")
    private String receiverprovince_emp_cnt;
    @Column(name = "requestid_emp_cnt")
    private String requestid_emp_cnt;
    @Column(name = "resptime_emp_cnt")
    private String resptime_emp_cnt;
    @Column(name = "src_emp_cnt")
    private String src_emp_cnt;
    @Column(name = "success_emp_cnt")
    private String success_emp_cnt;
    @Column(name = "waybillno_emp_cnt")
    private String waybillno_emp_cnt;
    @Column(name = "inc_day")
    private String inc_day;

    private boolean addresseeaoiarea_flag;
    private boolean addresseeaoiareagroup_flag;
    private boolean addresseeaoiareagrouppf_flag;
    private boolean addresseeaoiid_flag;
    private boolean addresseeaoitype_flag;
    private boolean addresseecitycode_flag;
    private boolean addresseedeptcode_flag;
    private boolean addresseekeyword_flag;
    private boolean addresseetransitcode_flag;
    private boolean addresseetransitcodecp_flag;
    private boolean aggbuild_flag;
    private boolean aggroom_flag;
    private boolean aggunit_flag;
    private boolean autosrc_flag;
    private boolean fnsdeliverycode_flag;
    private boolean fnsfirstdeptcode_flag;
    private boolean fnstransfercode_flag;
    private boolean inneradflag_flag;
    private boolean kwsrc_flag;
    private boolean kydeptcode_flag;
    private boolean kyteamcode_flag;
    private boolean kytransfercode_flag;
    private boolean logdata_flag;
    private boolean lpflag_flag;
    private boolean orderno_flag;
    private boolean overlargeinfo_flag;
    private boolean receiveraddr_flag;
    private boolean receiverarea_flag;
    private boolean receivercity_flag;
    private boolean receiverprovince_flag;
    private boolean requestid_flag;
    private boolean resptime_flag;
    private boolean src_flag;
    private boolean success_flag;
    private boolean waybillno_flag;

    public boolean isAddresseeaoiarea_flag() {
        return addresseeaoiarea_flag;
    }

    public void setAddresseeaoiarea_flag(boolean addresseeaoiarea_flag) {
        this.addresseeaoiarea_flag = addresseeaoiarea_flag;
    }

    public boolean isAddresseeaoiareagroup_flag() {
        return addresseeaoiareagroup_flag;
    }

    public void setAddresseeaoiareagroup_flag(boolean addresseeaoiareagroup_flag) {
        this.addresseeaoiareagroup_flag = addresseeaoiareagroup_flag;
    }

    public boolean isAddresseeaoiareagrouppf_flag() {
        return addresseeaoiareagrouppf_flag;
    }

    public void setAddresseeaoiareagrouppf_flag(boolean addresseeaoiareagrouppf_flag) {
        this.addresseeaoiareagrouppf_flag = addresseeaoiareagrouppf_flag;
    }

    public boolean isAddresseeaoiid_flag() {
        return addresseeaoiid_flag;
    }

    public void setAddresseeaoiid_flag(boolean addresseeaoiid_flag) {
        this.addresseeaoiid_flag = addresseeaoiid_flag;
    }

    public boolean isAddresseeaoitype_flag() {
        return addresseeaoitype_flag;
    }

    public void setAddresseeaoitype_flag(boolean addresseeaoitype_flag) {
        this.addresseeaoitype_flag = addresseeaoitype_flag;
    }

    public boolean isAddresseecitycode_flag() {
        return addresseecitycode_flag;
    }

    public void setAddresseecitycode_flag(boolean addresseecitycode_flag) {
        this.addresseecitycode_flag = addresseecitycode_flag;
    }

    public boolean isAddresseedeptcode_flag() {
        return addresseedeptcode_flag;
    }

    public void setAddresseedeptcode_flag(boolean addresseedeptcode_flag) {
        this.addresseedeptcode_flag = addresseedeptcode_flag;
    }

    public boolean isAddresseekeyword_flag() {
        return addresseekeyword_flag;
    }

    public void setAddresseekeyword_flag(boolean addresseekeyword_flag) {
        this.addresseekeyword_flag = addresseekeyword_flag;
    }

    public boolean isAddresseetransitcode_flag() {
        return addresseetransitcode_flag;
    }

    public void setAddresseetransitcode_flag(boolean addresseetransitcode_flag) {
        this.addresseetransitcode_flag = addresseetransitcode_flag;
    }

    public boolean isAddresseetransitcodecp_flag() {
        return addresseetransitcodecp_flag;
    }

    public void setAddresseetransitcodecp_flag(boolean addresseetransitcodecp_flag) {
        this.addresseetransitcodecp_flag = addresseetransitcodecp_flag;
    }

    public boolean isAggbuild_flag() {
        return aggbuild_flag;
    }

    public void setAggbuild_flag(boolean aggbuild_flag) {
        this.aggbuild_flag = aggbuild_flag;
    }

    public boolean isAggroom_flag() {
        return aggroom_flag;
    }

    public void setAggroom_flag(boolean aggroom_flag) {
        this.aggroom_flag = aggroom_flag;
    }

    public boolean isAggunit_flag() {
        return aggunit_flag;
    }

    public void setAggunit_flag(boolean aggunit_flag) {
        this.aggunit_flag = aggunit_flag;
    }

    public boolean isAutosrc_flag() {
        return autosrc_flag;
    }

    public void setAutosrc_flag(boolean autosrc_flag) {
        this.autosrc_flag = autosrc_flag;
    }

    public boolean isFnsdeliverycode_flag() {
        return fnsdeliverycode_flag;
    }

    public void setFnsdeliverycode_flag(boolean fnsdeliverycode_flag) {
        this.fnsdeliverycode_flag = fnsdeliverycode_flag;
    }

    public boolean isFnsfirstdeptcode_flag() {
        return fnsfirstdeptcode_flag;
    }

    public void setFnsfirstdeptcode_flag(boolean fnsfirstdeptcode_flag) {
        this.fnsfirstdeptcode_flag = fnsfirstdeptcode_flag;
    }

    public boolean isFnstransfercode_flag() {
        return fnstransfercode_flag;
    }

    public void setFnstransfercode_flag(boolean fnstransfercode_flag) {
        this.fnstransfercode_flag = fnstransfercode_flag;
    }

    public boolean isInneradflag_flag() {
        return inneradflag_flag;
    }

    public void setInneradflag_flag(boolean inneradflag_flag) {
        this.inneradflag_flag = inneradflag_flag;
    }

    public boolean isKwsrc_flag() {
        return kwsrc_flag;
    }

    public void setKwsrc_flag(boolean kwsrc_flag) {
        this.kwsrc_flag = kwsrc_flag;
    }

    public boolean isKydeptcode_flag() {
        return kydeptcode_flag;
    }

    public void setKydeptcode_flag(boolean kydeptcode_flag) {
        this.kydeptcode_flag = kydeptcode_flag;
    }

    public boolean isKyteamcode_flag() {
        return kyteamcode_flag;
    }

    public void setKyteamcode_flag(boolean kyteamcode_flag) {
        this.kyteamcode_flag = kyteamcode_flag;
    }

    public boolean isKytransfercode_flag() {
        return kytransfercode_flag;
    }

    public void setKytransfercode_flag(boolean kytransfercode_flag) {
        this.kytransfercode_flag = kytransfercode_flag;
    }

    public boolean isLogdata_flag() {
        return logdata_flag;
    }

    public void setLogdata_flag(boolean logdata_flag) {
        this.logdata_flag = logdata_flag;
    }

    public boolean isLpflag_flag() {
        return lpflag_flag;
    }

    public void setLpflag_flag(boolean lpflag_flag) {
        this.lpflag_flag = lpflag_flag;
    }

    public boolean isOrderno_flag() {
        return orderno_flag;
    }

    public void setOrderno_flag(boolean orderno_flag) {
        this.orderno_flag = orderno_flag;
    }

    public boolean isOverlargeinfo_flag() {
        return overlargeinfo_flag;
    }

    public void setOverlargeinfo_flag(boolean overlargeinfo_flag) {
        this.overlargeinfo_flag = overlargeinfo_flag;
    }

    public boolean isReceiveraddr_flag() {
        return receiveraddr_flag;
    }

    public void setReceiveraddr_flag(boolean receiveraddr_flag) {
        this.receiveraddr_flag = receiveraddr_flag;
    }

    public boolean isReceiverarea_flag() {
        return receiverarea_flag;
    }

    public void setReceiverarea_flag(boolean receiverarea_flag) {
        this.receiverarea_flag = receiverarea_flag;
    }

    public boolean isReceivercity_flag() {
        return receivercity_flag;
    }

    public void setReceivercity_flag(boolean receivercity_flag) {
        this.receivercity_flag = receivercity_flag;
    }

    public boolean isReceiverprovince_flag() {
        return receiverprovince_flag;
    }

    public void setReceiverprovince_flag(boolean receiverprovince_flag) {
        this.receiverprovince_flag = receiverprovince_flag;
    }

    public boolean isRequestid_flag() {
        return requestid_flag;
    }

    public void setRequestid_flag(boolean requestid_flag) {
        this.requestid_flag = requestid_flag;
    }

    public boolean isResptime_flag() {
        return resptime_flag;
    }

    public void setResptime_flag(boolean resptime_flag) {
        this.resptime_flag = resptime_flag;
    }

    public boolean isSrc_flag() {
        return src_flag;
    }

    public void setSrc_flag(boolean src_flag) {
        this.src_flag = src_flag;
    }

    public boolean isSuccess_flag() {
        return success_flag;
    }

    public void setSuccess_flag(boolean success_flag) {
        this.success_flag = success_flag;
    }

    public boolean isWaybillno_flag() {
        return waybillno_flag;
    }

    public void setWaybillno_flag(boolean waybillno_flag) {
        this.waybillno_flag = waybillno_flag;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStat_day() {
        return stat_day;
    }

    public void setStat_day(String stat_day) {
        this.stat_day = stat_day;
    }

    public String getStat_hour() {
        return stat_hour;
    }

    public void setStat_hour(String stat_hour) {
        this.stat_hour = stat_hour;
    }

    public String getStat_start_min() {
        return stat_start_min;
    }

    public void setStat_start_min(String stat_start_min) {
        this.stat_start_min = stat_start_min;
    }

    public String getStat_end_min() {
        return stat_end_min;
    }

    public void setStat_end_min(String stat_end_min) {
        this.stat_end_min = stat_end_min;
    }

    public String getAddresseeaoiarea_emp_cnt() {
        return addresseeaoiarea_emp_cnt;
    }

    public void setAddresseeaoiarea_emp_cnt(String addresseeaoiarea_emp_cnt) {
        this.addresseeaoiarea_emp_cnt = addresseeaoiarea_emp_cnt;
    }

    public String getAddresseeaoiareagroup_emp_cnt() {
        return addresseeaoiareagroup_emp_cnt;
    }

    public void setAddresseeaoiareagroup_emp_cnt(String addresseeaoiareagroup_emp_cnt) {
        this.addresseeaoiareagroup_emp_cnt = addresseeaoiareagroup_emp_cnt;
    }

    public String getAddresseeaoiareagrouppf_emp_cnt() {
        return addresseeaoiareagrouppf_emp_cnt;
    }

    public void setAddresseeaoiareagrouppf_emp_cnt(String addresseeaoiareagrouppf_emp_cnt) {
        this.addresseeaoiareagrouppf_emp_cnt = addresseeaoiareagrouppf_emp_cnt;
    }

    public String getAddresseeaoiid_emp_cnt() {
        return addresseeaoiid_emp_cnt;
    }

    public void setAddresseeaoiid_emp_cnt(String addresseeaoiid_emp_cnt) {
        this.addresseeaoiid_emp_cnt = addresseeaoiid_emp_cnt;
    }

    public String getAddresseeaoitype_emp_cnt() {
        return addresseeaoitype_emp_cnt;
    }

    public void setAddresseeaoitype_emp_cnt(String addresseeaoitype_emp_cnt) {
        this.addresseeaoitype_emp_cnt = addresseeaoitype_emp_cnt;
    }

    public String getAddresseecitycode_emp_cnt() {
        return addresseecitycode_emp_cnt;
    }

    public void setAddresseecitycode_emp_cnt(String addresseecitycode_emp_cnt) {
        this.addresseecitycode_emp_cnt = addresseecitycode_emp_cnt;
    }

    public String getAddresseedeptcode_emp_cnt() {
        return addresseedeptcode_emp_cnt;
    }

    public void setAddresseedeptcode_emp_cnt(String addresseedeptcode_emp_cnt) {
        this.addresseedeptcode_emp_cnt = addresseedeptcode_emp_cnt;
    }

    public String getAddresseekeyword_emp_cnt() {
        return addresseekeyword_emp_cnt;
    }

    public void setAddresseekeyword_emp_cnt(String addresseekeyword_emp_cnt) {
        this.addresseekeyword_emp_cnt = addresseekeyword_emp_cnt;
    }

    public String getAddresseetransitcode_emp_cnt() {
        return addresseetransitcode_emp_cnt;
    }

    public void setAddresseetransitcode_emp_cnt(String addresseetransitcode_emp_cnt) {
        this.addresseetransitcode_emp_cnt = addresseetransitcode_emp_cnt;
    }

    public String getAddresseetransitcodecp_emp_cnt() {
        return addresseetransitcodecp_emp_cnt;
    }

    public void setAddresseetransitcodecp_emp_cnt(String addresseetransitcodecp_emp_cnt) {
        this.addresseetransitcodecp_emp_cnt = addresseetransitcodecp_emp_cnt;
    }

    public String getAggbuild_emp_cnt() {
        return aggbuild_emp_cnt;
    }

    public void setAggbuild_emp_cnt(String aggbuild_emp_cnt) {
        this.aggbuild_emp_cnt = aggbuild_emp_cnt;
    }

    public String getAggroom_emp_cnt() {
        return aggroom_emp_cnt;
    }

    public void setAggroom_emp_cnt(String aggroom_emp_cnt) {
        this.aggroom_emp_cnt = aggroom_emp_cnt;
    }

    public String getAggunit_emp_cnt() {
        return aggunit_emp_cnt;
    }

    public void setAggunit_emp_cnt(String aggunit_emp_cnt) {
        this.aggunit_emp_cnt = aggunit_emp_cnt;
    }

    public String getAutosrc_emp_cnt() {
        return autosrc_emp_cnt;
    }

    public void setAutosrc_emp_cnt(String autosrc_emp_cnt) {
        this.autosrc_emp_cnt = autosrc_emp_cnt;
    }

    public String getFnsdeliverycode_emp_cnt() {
        return fnsdeliverycode_emp_cnt;
    }

    public void setFnsdeliverycode_emp_cnt(String fnsdeliverycode_emp_cnt) {
        this.fnsdeliverycode_emp_cnt = fnsdeliverycode_emp_cnt;
    }

    public String getFnsfirstdeptcode_emp_cnt() {
        return fnsfirstdeptcode_emp_cnt;
    }

    public void setFnsfirstdeptcode_emp_cnt(String fnsfirstdeptcode_emp_cnt) {
        this.fnsfirstdeptcode_emp_cnt = fnsfirstdeptcode_emp_cnt;
    }

    public String getFnstransfercode_emp_cnt() {
        return fnstransfercode_emp_cnt;
    }

    public void setFnstransfercode_emp_cnt(String fnstransfercode_emp_cnt) {
        this.fnstransfercode_emp_cnt = fnstransfercode_emp_cnt;
    }

    public String getInneradflag_emp_cnt() {
        return inneradflag_emp_cnt;
    }

    public void setInneradflag_emp_cnt(String inneradflag_emp_cnt) {
        this.inneradflag_emp_cnt = inneradflag_emp_cnt;
    }

    public String getKwsrc_emp_cnt() {
        return kwsrc_emp_cnt;
    }

    public void setKwsrc_emp_cnt(String kwsrc_emp_cnt) {
        this.kwsrc_emp_cnt = kwsrc_emp_cnt;
    }

    public String getKydeptcode_emp_cnt() {
        return kydeptcode_emp_cnt;
    }

    public void setKydeptcode_emp_cnt(String kydeptcode_emp_cnt) {
        this.kydeptcode_emp_cnt = kydeptcode_emp_cnt;
    }

    public String getKyteamcode_emp_cnt() {
        return kyteamcode_emp_cnt;
    }

    public void setKyteamcode_emp_cnt(String kyteamcode_emp_cnt) {
        this.kyteamcode_emp_cnt = kyteamcode_emp_cnt;
    }

    public String getKytransfercode_emp_cnt() {
        return kytransfercode_emp_cnt;
    }

    public void setKytransfercode_emp_cnt(String kytransfercode_emp_cnt) {
        this.kytransfercode_emp_cnt = kytransfercode_emp_cnt;
    }

    public String getLogdata_emp_cnt() {
        return logdata_emp_cnt;
    }

    public void setLogdata_emp_cnt(String logdata_emp_cnt) {
        this.logdata_emp_cnt = logdata_emp_cnt;
    }

    public String getLpflag_emp_cnt() {
        return lpflag_emp_cnt;
    }

    public void setLpflag_emp_cnt(String lpflag_emp_cnt) {
        this.lpflag_emp_cnt = lpflag_emp_cnt;
    }

    public String getOrderno_emp_cnt() {
        return orderno_emp_cnt;
    }

    public void setOrderno_emp_cnt(String orderno_emp_cnt) {
        this.orderno_emp_cnt = orderno_emp_cnt;
    }

    public String getOverlargeinfo_emp_cnt() {
        return overlargeinfo_emp_cnt;
    }

    public void setOverlargeinfo_emp_cnt(String overlargeinfo_emp_cnt) {
        this.overlargeinfo_emp_cnt = overlargeinfo_emp_cnt;
    }

    public String getReceiveraddr_emp_cnt() {
        return receiveraddr_emp_cnt;
    }

    public void setReceiveraddr_emp_cnt(String receiveraddr_emp_cnt) {
        this.receiveraddr_emp_cnt = receiveraddr_emp_cnt;
    }

    public String getReceiverarea_emp_cnt() {
        return receiverarea_emp_cnt;
    }

    public void setReceiverarea_emp_cnt(String receiverarea_emp_cnt) {
        this.receiverarea_emp_cnt = receiverarea_emp_cnt;
    }

    public String getReceivercity_emp_cnt() {
        return receivercity_emp_cnt;
    }

    public void setReceivercity_emp_cnt(String receivercity_emp_cnt) {
        this.receivercity_emp_cnt = receivercity_emp_cnt;
    }

    public String getReceiverprovince_emp_cnt() {
        return receiverprovince_emp_cnt;
    }

    public void setReceiverprovince_emp_cnt(String receiverprovince_emp_cnt) {
        this.receiverprovince_emp_cnt = receiverprovince_emp_cnt;
    }

    public String getRequestid_emp_cnt() {
        return requestid_emp_cnt;
    }

    public void setRequestid_emp_cnt(String requestid_emp_cnt) {
        this.requestid_emp_cnt = requestid_emp_cnt;
    }

    public String getResptime_emp_cnt() {
        return resptime_emp_cnt;
    }

    public void setResptime_emp_cnt(String resptime_emp_cnt) {
        this.resptime_emp_cnt = resptime_emp_cnt;
    }

    public String getSrc_emp_cnt() {
        return src_emp_cnt;
    }

    public void setSrc_emp_cnt(String src_emp_cnt) {
        this.src_emp_cnt = src_emp_cnt;
    }

    public String getSuccess_emp_cnt() {
        return success_emp_cnt;
    }

    public void setSuccess_emp_cnt(String success_emp_cnt) {
        this.success_emp_cnt = success_emp_cnt;
    }

    public String getWaybillno_emp_cnt() {
        return waybillno_emp_cnt;
    }

    public void setWaybillno_emp_cnt(String waybillno_emp_cnt) {
        this.waybillno_emp_cnt = waybillno_emp_cnt;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
