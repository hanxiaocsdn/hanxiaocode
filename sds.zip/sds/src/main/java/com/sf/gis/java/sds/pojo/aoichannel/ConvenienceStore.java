package com.sf.gis.java.sds.pojo.aoichannel;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ConvenienceStore implements Serializable {

    @Column(name = "service_code")
    private String service_code;
    @Column(name = "service_name")
    private String service_name;
    @Column(name = "service_type")
    private String service_type;
    @Column(name = "service_addr")
    private String service_addr;
    @Column(name = "province")
    private String province;
    @Column(name = "cityid")
    private String cityid;
    @Column(name = "longitude")
    private String longitude;
    @Column(name = "latitude")
    private String latitude;

    private String stdAoi;
    private String stdAoiCode;
    private String aoi_area_code;
    private String origion_aoi_area_code;


    private String req;
    private String resJson;
    private String aoi_id;
    private String aoi_code;
    private String aoi_name;

    public String getOrigion_aoi_area_code() {
        return origion_aoi_area_code;
    }

    public void setOrigion_aoi_area_code(String origion_aoi_area_code) {
        this.origion_aoi_area_code = origion_aoi_area_code;
    }

    public String getAoi_area_code() {
        return aoi_area_code;
    }

    public void setAoi_area_code(String aoi_area_code) {
        this.aoi_area_code = aoi_area_code;
    }

    public String getStdAoi() {
        return stdAoi;
    }

    public void setStdAoi(String stdAoi) {
        this.stdAoi = stdAoi;
    }

    public String getStdAoiCode() {
        return stdAoiCode;
    }

    public void setStdAoiCode(String stdAoiCode) {
        this.stdAoiCode = stdAoiCode;
    }

    public String getReq() {
        return req;
    }

    public void setReq(String req) {
        this.req = req;
    }

    public String getResJson() {
        return resJson;
    }

    public void setResJson(String resJson) {
        this.resJson = resJson;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getService_code() {
        return service_code;
    }

    public void setService_code(String service_code) {
        this.service_code = service_code;
    }

    public String getService_name() {
        return service_name;
    }

    public void setService_name(String service_name) {
        this.service_name = service_name;
    }

    public String getService_type() {
        return service_type;
    }

    public void setService_type(String service_type) {
        this.service_type = service_type;
    }

    public String getService_addr() {
        return service_addr;
    }

    public void setService_addr(String service_addr) {
        this.service_addr = service_addr;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCityid() {
        return cityid;
    }

    public void setCityid(String cityid) {
        this.cityid = cityid;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }
}
