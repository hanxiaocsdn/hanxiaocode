package com.sf.gis.java.sds.service.impl;


import com.sf.gis.java.sds.pojo.WrongDataDiff;

import java.util.List;

public interface IWrongDataDiffService {

    void insert(List<WrongDataDiff> list) throws Exception;

    void createTable();

    void deleteData(String date, String cityCode);

}
