package com.sf.gis.java.sds.enumtype;

public enum DeptBy {
    gis,gis_sss
}
