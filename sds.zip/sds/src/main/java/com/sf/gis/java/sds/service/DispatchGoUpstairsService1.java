package com.sf.gis.java.sds.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.AoiElevator;
import com.sf.gis.java.sds.pojo.CmsAoiSch;
import com.sf.gis.java.sds.pojo.GroupElevator;
import com.sf.gis.java.sds.pojo.TtWayBillHook;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DispatchGoUpstairsService1 implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(DispatchGoUpstairsService1.class);
    private static Pattern numPattern = Pattern.compile("\\d+");

    public JavaRDD<TtWayBillHook> loadTtWayData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate, String citycode) {
        String sql = SqlUtil.getSqlStr("tt_waybill_hook1.sql", startDate, endDate, citycode);
        logger.error("tt_waybill_hook1 sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TtWayBillHook.class);
    }

    public JavaRDD<CmsAoiSch> loadCmsData(SparkSession spark, JavaSparkContext sc) {
        String sql = SqlUtil.getSqlStr("tals_cms_aoi_sch.sql");
        logger.error("tals_cms_aoi_sch sql: {}", sql);
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public JavaRDD<GroupElevator> loadGroupStatData(SparkSession spark, JavaSparkContext sc, String date, String citycode) {
        String sql = String.format("select * from dm_gis.tt_group_elevator_stat_final where inc_day = '%s' and city = '%s'", date, citycode);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, GroupElevator.class);
    }

    public JavaRDD<AoiElevator> loadAoiStatData(SparkSession spark, JavaSparkContext sc, String date, String citycode) {
        String sql = String.format("select * from dm_gis.tt_aoi_elevator_stat_final where inc_day = '%s' and city = '%s'", date, citycode);
        logger.error("aoi_elevator_stat sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiElevator.class);
    }

    public String runAtdispatch(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request cf error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }

    public boolean isContain_14(String splitResult) {
        boolean flag = false;
        if (StringUtils.isNotEmpty(splitResult)) {
            String result = splitResult.split(";")[0];
            if (StringUtils.isNotEmpty(result)) {
                String[] splits = result.split(",");
                for (String split : splits) {
                    String number = split.split("\\^")[1];
                    if (StringUtils.isNotEmpty(number)) {
                        String level = number.substring(number.length() - 2, number.length());
                        if (StringUtils.isNotEmpty(level) && StringUtils.equals(level, "14")) {
                            flag = true;
                            break;
                        }
                    }
                }
            }
        }
        return flag;
    }

    public boolean judge_aoi_type(String aoi_type) {
        boolean flag = false;
        if (StringUtils.isNotEmpty(aoi_type)) {
            if (StringUtils.equals(aoi_type, "120201") || StringUtils.equals(aoi_type, "120203") || StringUtils.equals(aoi_type, "060100") ||
                    StringUtils.equals(aoi_type, "120302") || StringUtils.equals(aoi_type, "120301") || StringUtils.equals(aoi_type, "141100") ||
                    StringUtils.equals(aoi_type, "100100")) {
                flag = true;
            }
        }
        return flag;
    }

    public String[] getLast(String splitResult) {
        StringBuilder last14 = new StringBuilder();
        StringBuilder last15 = new StringBuilder();
        if (StringUtils.isNotEmpty(splitResult)) {
            String txt = splitResult.split(";")[0];
            if (StringUtils.isNotEmpty(txt)) {
                String[] split = txt.split(",");
                for (String s : split) {
                    String[] split1 = s.split("\\^");
                    String num = split1[1];
                    if (num.length() == 3) {
                        String substring = num.substring(1, num.length());
                        if (StringUtils.isNotEmpty(substring) && Integer.parseInt(substring) == 14) {
                            String content = split1[0];
                            last14.append(content);
                        }
                        if (StringUtils.isNotEmpty(substring) && Integer.parseInt(substring) == 15) {
                            String content = split1[0];
                            last15.append(content);
                        }
                    }
                }
            }
        }
        return new String[]{last14.toString(), last15.toString()};
    }

    public boolean aoiTypejudge1(String aoiType) {
        if (StringUtils.equals(aoiType, "141201") || StringUtils.equals(aoiType, "141206") || StringUtils.equals(aoiType, "141202") || StringUtils.equals(aoiType, "141203") || StringUtils.equals(aoiType, "141204")) {
            return true;
        }
        return false;
    }

    public boolean judgeAddr1(String addr) {
        String regex2 = ".*[a-zA-Z]\\d{4,}";
        Pattern p = Pattern.compile(regex2);
        Matcher m = p.matcher(addr);
        return m.find();
    }

    public String[] processAddr1(String addr, String tag) {
        String regex2 = "\\(.*?\\)|\\【.*?\\】|\\[.*?\\]|（.*?）";
        Pattern p = Pattern.compile(regex2);
        Matcher m = p.matcher(addr);
        while (m.find()) {
            tag = "括号删除";
        }
        return new String[]{addr.replaceAll(regex2, ""), tag};
    }

    public String[] processAddr2(String addr, String tag) {
        String regex2 = "0{4,}|1{4,}|2{4,}|3{4,}|4{4,}|5{4,}|6{4,}|7{4,}|8{4,}|9{4,}";
        Pattern p = Pattern.compile(regex2);
        Matcher m = p.matcher(addr);
        while (m.find()) {
            tag = "连续字符";
        }
        return new String[]{addr.replaceAll(regex2, ""), tag};
    }

    public String[] processAddr3(String addr, String tag) {
//        addr = addr.replace(" ", "-").replace("**", "*");
        String regex = "\\d[.|*|.:|。|:|#|.：|\\s]+\\d";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(addr);
        while (m.find()) {
            String group = m.group();
            String new_group = group.replaceAll("\\.|\\*|。|:|#|：|\\s", "栋").replace("栋栋", "栋");
            addr = addr.replace(group, new_group);
            tag = "符号替换";
        }
        return new String[]{addr, tag};
    }

    public static void main(String[] args) {
        DispatchGoUpstairsService1 service1 = new DispatchGoUpstairsService1();

        String[] strings = service1.processAddr3("江苏省淮安市清江浦区城南乡淮海南路198号 四季金辉小区 3号楼 1单元 1405号", "");
        System.out.println(strings[0]);
    }


    public String[] processAddr4(String addr, String tag, String aoiType) {
        String regex = "\\d+[楼]\\d+";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(addr);
        while (m.find() && ((StringUtils.equals(aoiType, "120302") || StringUtils.equals(aoiType, "120301") || StringUtils.equals(aoiType, "120305")))) {
            String group = m.group();
            String new_group = group.replace("楼", "号楼");
            addr = addr.replace(group, new_group);
            tag = "新增号";
        }
        return new String[]{addr, tag};
    }

    public String[] processAddr5(String addr, String tag) {
        String regex = "\\d+[#|\\*]楼";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(addr);
        while (m.find()) {
            String group = m.group();
            String new_group = group.replaceAll("#|\\*", "号");
            addr = addr.replace(group, new_group);
            tag = "#号替换";
        }
        return new String[]{addr, tag};
    }

    public boolean processAddr6(String addr) {
        String regex = "\\d+(号楼|栋|幢|座)[0-9]{3,4}[室|号]$";
        Pattern p = Pattern.compile(regex);
        Matcher m = p.matcher(addr);
        while (m.find()) {
            return true;
        }
        return false;
    }

    public boolean processAddr7(String addr, String aoiType) {
        if (StringUtils.isNotEmpty(addr) &&
                (StringUtils.equals(aoiType, "120302") || StringUtils.equals(aoiType, "120301") || StringUtils.equals(aoiType, "120305") || StringUtils.equals(aoiType, "190109")) &&
                (addr.contains("门店") || addr.contains("商铺") || addr.contains("门面"))) {
            return true;
        }
        return false;
    }

    public String getMaxSplit(String splitResult) {
        return splitResult.split(";")[1];
    }

    public void saveGroupData(SparkSession spark, JavaRDD<TtWayBillHook> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getConsignee_addr(), o.getSignin_tm(), o.getGroupId(), o.getDest_dist_code(), o.getGroup_source(), o.getStdAddr(), o.getAoiId(), o.getIs_groupid_elevator(), o.getFloor(), o.getTag1(), o.getTag2(), o.getTag3()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"waybill_no", "consignee_addr", "signin_tm", "group_id", "citycode", "source", "norm_address", "aoi_id", "is_elevator", "floor", "tag1", "tag2", "tag3"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "tt_group_elevator_process_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.tt_group_elevator_process";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }


    public void saveGroupDataN(SparkSession spark, JavaRDD<TtWayBillHook> inRdd, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getConsignee_addr(), o.getSignin_tm(), o.getGroupId(), o.getDest_dist_code(), "3", o.getStdAddr(),
                    o.getAoiId(), o.getIs_groupid_elevator(), o.getFloor(), o.getProcess_address(), o.getGroup_id_2(), o.getAoi_id_2(), o.getFloor_2(), o.getNorm_address_2(), o.getGroup2_freq(),
                    o.getNorm_addr_split(), o.getSplitResult(), o.getLast14(), o.getLast15(), o.getMaxSplit(), o.getSrc_tag(), o.getTag1(), o.getTag2(), o.getTag3(), o.getTag4(), o.getTag5(), o.getTag6(), o.getAoiType(),
                    o.getInc_day(), o.getDest_dist_code()

            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"waybill_no", "consignee_addr", "signin_tm", "group_id", "citycode", "source", "norm_address",
                "aoi_id", "is_elevator", "floor", "process_addr", "group_id_2", "aoi_id_2", "floor_2", "norm_address_2", "group2_freq",
                "norm_addr_split", "splitResult", "last14", "last15", "maxsplit", "src_tag", "tag1", "tag2", "tag3", "tag4", "tag5", "tag6", "aoi_type_code",
                "inc_day", "city"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "tt_elevator_process_n_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", table);
        spark.sql(String.format("insert overwrite table %s partition(inc_day, city) " +
                "select * from %s", table, tempTable));
        spark.catalog().dropTempView(tempTable);

    }


    public void saveAoiDataN(SparkSession spark, JavaRDD<TtWayBillHook> inRdd, String table) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getConsignee_addr(), o.getSignin_tm(), o.getGroupId(), o.getDest_dist_code(), "3", o.getStdAddr(),
                    o.getAoiId(), o.getIs_groupid_elevator(), o.getFloor(), o.getProcess_address(), o.getGroup_id_2(), o.getAoi_id_2(), o.getFloor_2(), o.getNorm_address_2(), o.getAoi2_freq(),
                    o.getNorm_addr_split(), o.getSplitResult(), o.getLast14(), o.getLast15(), o.getMaxSplit(), o.getSrc_tag(), o.getTag1(), o.getTag2(), o.getTag3(), o.getTag4(), o.getTag5(), o.getTag6(), o.getAoiType(),
                    o.getInc_day(), o.getDest_dist_code()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"waybill_no", "consignee_addr", "signin_tm", "group_id", "citycode", "source", "norm_address",
                "aoi_id", "is_elevator", "floor", "process_addr", "group_id_2", "aoi_id_2", "floor_2", "norm_address_2", "aoi2_freq",
                "norm_addr_split", "splitResult", "last14", "last15", "maxsplit", "src_tag", "tag1", "tag2", "tag3", "tag4", "tag5", "tag6", "aoi_type_code",
                "inc_day", "city"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "tt_elevator_process_n_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        logger.error("targetTable:{}", table);
        spark.sql(String.format("insert overwrite table %s partition(inc_day, city) " +
                "select * from %s", table, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveAoiData(SparkSession spark, JavaRDD<TtWayBillHook> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getConsignee_addr(), o.getSignin_tm(), o.getAoiId(), o.getDest_dist_code(), o.getAoi_source(), o.getAoiType(), o.getIs_aoiid_elevator(), o.getFloor(), o.getTag1(), o.getTag2(), o.getTag3()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"waybill_no", "consignee_addr", "signin_tm", "aoi_id", "citycode", "source", "aoi_type", "is_elevator", "floor", "tag1", "tag2", "tag3"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "tt_aoi_elevator_process_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.tt_aoi_elevator_process";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveGroupStatData(SparkSession spark, JavaRDD<GroupElevator> inRdd, String date, String citycode) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getGroup_id(), o.getCityCode(), o.getSource(), o.getNorm_address(), o.getAoi_id(), o.getElevator_cnt()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"group_id", "citycode", "source", "norm_address", "aoi_id", "elevator_cnt"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "tt_group_elevator_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.tt_group_elevator_stat_final";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s', city = '%s') " +
                "select * from %s", targetTable, date, citycode, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveAoiStatData(SparkSession spark, JavaRDD<AoiElevator> inRdd, String date, String citycode) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getAoi_id(), o.getCityCode(), o.getSource(), o.getAoi_type(), o.getElevator_cnt()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"aoi_id", "citycode", "source", "aoi_type", "elevator_cnt"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "tt_aoi_elevator_stat_final_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.tt_aoi_elevator_stat_final";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s', city = '%s') " +
                "select * from %s", targetTable, date, citycode, tempTable));
        spark.catalog().dropTempView(tempTable);

    }
}
