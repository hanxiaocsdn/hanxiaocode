package com.sf.gis.java.sds.service;

import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DbUtil;
import com.sf.gis.java.base.util.SqlUtil;
import com.sf.gis.java.sds.pojo.AddressInfoMapDi;
import com.sf.gis.java.sds.pojo.KyGdlPackWaybillnoMonitor;
import com.sf.gis.java.sds.pojo.TtWayBillHook;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

public class DispatchGoUpstairsService3 implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(DispatchGoUpstairsService3.class);

    public JavaRDD<AddressInfoMapDi> loadAddressInfoMapDiData(SparkSession spark, JavaSparkContext sc) {
        String sql = "select * from dm_gis.city_name_map where inc_day = '20210317'";
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AddressInfoMapDi.class);
    }

    public JavaRDD<KyGdlPackWaybillnoMonitor> loadKyGdData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("tals_ky_gdl_pack_waybillno_monitor.sql", startDate, endDate);
        logger.error("tals_ky_gdl_pack_waybillno_monitor sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, KyGdlPackWaybillnoMonitor.class);
    }

    public JavaRDD<TtWayBillHook> loadTtWayData(SparkSession spark, JavaSparkContext sc, String beforeDate, String afterDate) {
        String sql = SqlUtil.getSqlStr("tt_waybill_hook2.sql", beforeDate, afterDate);
        logger.error("tt_waybill_hook2 sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TtWayBillHook.class);
    }

    public String queryElevator(String urlPattern, String address, String cityCode) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean hasChineseCharacter(String str) {
        for (char c : str.toCharArray()) {
            if (isChineseCharacter(c))
                return false;
        }
        return true;
    }

    public boolean isChineseCharacter(char c) {
        return c >= 0x4E00 && c <= 0x9FA5;
    }


    public void saveData(SparkSession spark, JavaRDD<KyGdlPackWaybillnoMonitor> inRdd, String today) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getWaybill_no(), o.getDest_city_code(), o.getDest_zone_code(), o.getAddr(), o.getIs_check(), o.getReview_status(), o.getPass_status(), o.getBomb_box(),
                    o.getIs_climb(), o.getIs_elevator(), o.getFloor(), o.getKy_climb(), o.getCheck(), o.getDate(), o.getData_src(), o.getGroup_id(), o.getAoi_id()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"waybill_no", "dest_dist_code", "dest_zone_code", "consignee_addr", "is_check", "review_status", "pass_status", "bomb_box",
                "is_climb", "is_elevator", "floor", "ky_climb", "check", "date", "data_src", "group_id", "aoi_id"};
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "adds_ele_ky_check_kuang_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.adds_ele_ky_check_kuang";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, today, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveStatData(SparkSession spark, JavaRDD<KyGdlPackWaybillnoMonitor> inRdd, String today) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getDest_city_code(), o.getDest_zone_code(), o.getDate(),
                    o.getCnt() + "", o.getMatch_cnt() + "", o.getElevator_distinguish_cnt() + "", o.getHas_elevator_cnt() + "", o.getNo_has_elevator_cnt() + "",
                    o.getElevator_no_judge_cnt() + "", o.getClimb_distinguish_cnt() + "", o.getClimb_distinguish_right_cnt() + "", o.getNeed_climb_cnt() + "", o.getNeed_climb_right_cnt() + "",
                    o.getKy_climb_approve_pass_cnt() + "", o.getKy_climb_approve_reject_cnt() + "", o.getKy_climb_no_approve_cnt() + "", o.getKy_climb_no_need_approve_cnt() + "", o.getNo_need_climb_cnt() + "",
                    o.getNo_need_climb_right_cnt() + "", o.getClimb_no_judge_cnt() + "", o.getFloor_distinguish_cnt() + "", o.getNo_ky_climb_approve_pass_cnt() + "", o.getNo_ky_climb_approve_reject_cnt() + "",
                    o.getNo_ky_climb_no_approve_cnt() + "", o.getNo_ky_climb_no_need_approve_cnt() + "", o.getStat_type(), o.getStat_type_content(), o.getProvince(), o.getRegion()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{"dest_dist_code", "dest_zone_code", "stat_date",
                "cnt", "match_cnt", "elevator_distinguish_cnt", "has_elevator_cnt", "no_has_elevator_cnt", "elevator_no_judge_cnt", "climb_distinguish_cnt", "climb_distinguish_right_cnt", "need_climb_cnt", "need_climb_right_cnt",
                "ky_climb_approve_pass_cnt", "ky_climb_approve_reject_cnt", "ky_climb_no_approve_cnt", "ky_climb_no_need_approve_cnt", "no_need_climb_cnt",
                "no_need_climb_right_cnt", "climb_no_judge_cnt", "floor_distinguish_cnt", "no_ky_climb_approve_pass_cnt", "no_ky_climb_approve_reject_cnt", "no_ky_climb_no_approve_cnt", "no_ky_climb_no_need_approve_cnt",
                "stat_type", "stat_type_content", "province", "region"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "adds_ele_ky_check_stat_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.adds_ele_ky_check_stat";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s') " +
                "select * from %s", targetTable, today, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveToMysql(JavaSparkContext sc, JavaRDD<KyGdlPackWaybillnoMonitor> rdd) {
        String dbConfig = "rds-mysql.properties";
        logger.error("rdd cnt: {}", rdd.count());

        logger.error("insert into mysql");
        Broadcast<String> dbConfigBc = sc.broadcast(dbConfig);
        rdd.repartition(16).foreachPartition(p -> {
            Connection conn = DbUtil.getInstance(dbConfigBc.value()).getConn();
            conn.setAutoCommit(false);
            PreparedStatement pstmt = conn.prepareStatement(
                    String.format("insert into ADDS_ELE_KY_CHECK(`ID`,`STAT_TYPE`,`STAT_TYPE_CONTENT`,`STAT_DATE`,`CITY`,`CITY_CODE`,`ZONECODE`," +
                            "`WAYBILL_NO`,`CONSIGNEE_ADDR`,`IS_CHECK`,`REVIEW_STATUS`,`PASS_STATUS`,`BOMB_BOX`," +
                            "`IS_CLIMB`,`IS_ELEVATOR`,`FLOOR`,`KY_CLIMB`,`CHECK`,`COVER_ELE_RATE`,`COVER_CLIMB_RATE`,`RIGHTRATE`,`CNT`,`AT_CNT`,`ELEVATOR_CNT`,`CLIMB_CNT`," +
                            "`MATCH_CNT`,`ELEVATOR_DISTINGUISH_CNT`,`HAS_ELEVATOR_CNT`,`NO_HAS_ELEVATOR_CNT`,`ELEVATOR_NO_JUDGE_CNT`,`CLIMB_DISTINGUISH_CNT`,`CLIMB_DISTINGUISH_RIGHT_CNT`," +
                            "`NEED_CLIMB_CNT`,`NEED_CLIMB_RIGHT_CNT`,`KY_CLIMB_APPROVE_PASS_CNT`,`KY_CLIMB_APPROVE_REJECT_CNT`,`KY_CLIMB_NO_APPROVE_CNT`," +
                            "`KY_CLIMB_NO_NEED_APPROVE_CNT`,`NO_NEED_CLIMB_CNT`,`NO_NEED_CLIMB_RIGHT_CNT`,`CLIMB_NO_JUDGE_CNT`,`FLOOR_DISTINGUISH_CNT`, " +
                            "`NO_KY_CLIMB_APPROVE_PASS_CNT`,`NO_KY_CLIMB_APPROVE_REJECT_CNT`,`NO_KY_CLIMB_NO_APPROVE_CNT`,`NO_KY_CLIMB_NO_NEED_APPROVE_CNT`,`REGION`,`PROVINCE`) " +
                            "values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
            );
            while (p.hasNext()) {
                KyGdlPackWaybillnoMonitor o = p.next();
                pstmt.setString(1, o.getId());
                pstmt.setString(2, o.getStat_type());
                pstmt.setString(3, o.getStat_type_content());
                pstmt.setString(4, o.getDate());
                pstmt.setString(5, o.getCity());
                pstmt.setString(6, o.getDest_city_code());
                pstmt.setString(7, o.getDest_zone_code());
                pstmt.setString(8, o.getWaybill_no());
                pstmt.setString(9, o.getAddr());
                pstmt.setString(10, o.getIs_check());
                pstmt.setString(11, o.getReview_status());
                pstmt.setString(12, o.getPass_status());
                pstmt.setString(13, o.getBomb_box());
                pstmt.setString(14, o.getIs_climb());
                pstmt.setString(15, o.getIs_elevator());
                pstmt.setString(16, o.getFloor());
                pstmt.setString(17, o.getKy_climb());
                pstmt.setString(18, o.getCheck());
                pstmt.setString(19, o.getCover_ele_rate() + "");
                pstmt.setString(20, o.getCover_climb_rate() + "");
                pstmt.setString(21, o.getRightRate() + "");
                pstmt.setString(22, o.getCnt() + "");
                pstmt.setString(23, o.getAt_cnt() + "");
                pstmt.setString(24, o.getElevator_cnt() + "");
                pstmt.setString(25, o.getClimb_cnt() + "");
                pstmt.setString(26, o.getMatch_cnt() + "");
                pstmt.setString(27, o.getElevator_distinguish_cnt() + "");
                pstmt.setString(28, o.getHas_elevator_cnt() + "");
                pstmt.setString(29, o.getNo_has_elevator_cnt() + "");
                pstmt.setString(30, o.getElevator_no_judge_cnt() + "");
                pstmt.setString(31, o.getClimb_distinguish_cnt() + "");
                pstmt.setString(32, o.getClimb_distinguish_right_cnt() + "");
                pstmt.setString(33, o.getNeed_climb_cnt() + "");
                pstmt.setString(34, o.getNeed_climb_right_cnt() + "");
                pstmt.setString(35, o.getKy_climb_approve_pass_cnt() + "");
                pstmt.setString(36, o.getKy_climb_approve_reject_cnt() + "");
                pstmt.setString(37, o.getKy_climb_no_approve_cnt() + "");
                pstmt.setString(38, o.getKy_climb_no_need_approve_cnt() + "");
                pstmt.setString(39, o.getNo_need_climb_cnt() + "");
                pstmt.setString(40, o.getNo_need_climb_right_cnt() + "");
                pstmt.setString(41, o.getClimb_no_judge_cnt() + "");
                pstmt.setString(42, o.getFloor_distinguish_cnt() + "");

                pstmt.setString(43, o.getNo_ky_climb_approve_pass_cnt() + "");
                pstmt.setString(44, o.getNo_ky_climb_approve_reject_cnt() + "");
                pstmt.setString(45, o.getNo_ky_climb_no_approve_cnt() + "");
                pstmt.setString(46, o.getNo_ky_climb_no_need_approve_cnt() + "");
                pstmt.setString(47, o.getRegion());
                pstmt.setString(48, o.getProvince());

                pstmt.addBatch();
            }
            pstmt.executeBatch();
            conn.commit();
            conn.setAutoCommit(true);
            pstmt.close();
            conn.close();
        });
        logger.error("insert into mysql end");
    }

    public static void main(String[] args) {
    }
}
