package com.sf.gis.java.sds.controller;

import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.api.AddrApi;
import com.sf.gis.java.base.constant.SysConstant;
import com.sf.gis.java.base.dto.AddrInfo;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.Addr4Marking;
import com.sf.gis.java.sds.pojo.Aoi;
import com.sf.gis.java.sds.service.AddrService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.Optional;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.sql.Connection;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 地址库标记流程
 *
 * @author 01370539 Created On: Jun.18 2021
 */
public class StdMarkingController {
    private static final Logger logger = LoggerFactory.getLogger(StdMarkingController.class);

    private final static AddrService addrService = new AddrService();

    /**
     * 控制器主入口
     * @param citys    需要处理的城市
     */
    public void process(String[] citys) {
        logger.error("process start. ");
        // 初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext jsc = sparkInfo.getContext();
        SparkSession ss = sparkInfo.getSession();

        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        JavaPairRDD<String, String> rddAoi = DataUtil.loadData(ss, jsc, "select aoi_id, aoi_name from dm_gis.cms_aoi_sch", Aoi.class).mapToPair(temp -> new Tuple2<>(temp.getAoiId(), temp.getAoiName())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoi count: {}", rddAoi.count());


        JavaRDD<Addr4Marking> rddStdOrig;
        for (String city : citys) {
            logger.error("process city - {}", city);

            rddStdOrig = addrService.loadZc(jsc, JdbcUtil.getMysqlConnection("mysql_wchka.properties"), city).repartition(20).mapToPair(zc -> new Tuple2<>(DigestUtils.md5Hex(zc).hashCode(), zc)).groupByKey().mapPartitions(iter -> {
                Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
                List<Addr4Marking> list = new ArrayList<>();
                while (iter.hasNext()) {
                    Lists.newArrayList(iter.next()._2).forEach(zc -> {
                        logger.error("load city {} zc {} data.", city, zc);
                        String sql = "select address_id, city_code, address, keyword, zno_code, aoi_id, adcode, type from cms_address_" + cityDbPro.getProperty(city) + " where city_code = '" + city + "' and zno_code = '" + zc + "' and status = 1 and del_flag = 0 and aoi_id != '' and aoi_id is not null";
                        list.addAll(DataUtil.loadData(conn, sql, Addr4Marking.class));
                    });
                }
                if (conn != null) {
                    conn.close();
                }
                return list.iterator();
            }).repartition(SysConstant.PARTITION_COUNT).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("city {} data count: {}", city, rddStdOrig.count());

            JavaRDD<Addr4Marking> rddStd = rddStdOrig.mapToPair(temp -> new Tuple2<>(temp.getAoiId(), temp)).groupByKey().leftOuterJoin(rddAoi).flatMap(tp -> {
                Optional<String> aoiName = tp._2._2;
                if (aoiName.isPresent()) {
                    List<Addr4Marking> tempList = Lists.newArrayList(tp._2._1);
                    for (Addr4Marking temp : tempList) {
                        temp.setAoiName(aoiName.get());
                    }
                    return tempList.iterator();
                } else {
                    return Lists.newArrayList(tp._2._1).iterator();
                }
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            rddStd.take(1).forEach(temp -> logger.error(temp.toString()));

            process(ss, jsc, rddStd);
        }
        logger.error("process end. ");
    }

    private static void process(SparkSession ss, JavaSparkContext jsc, JavaRDD<Addr4Marking> rddStd) {
        // 地址进行分词，并获取最后一个6,613,13,14等，并按照是否核实进行分组
        JavaPairRDD<String, Addr4Marking> rddTpStd = splitAddr(rddStd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rddTpStd {}", rddTpStd.count());
        rddStd.unpersist();

        // 获取已核实数据
        JavaRDD<Addr4Marking> rddChecked = rddTpStd.filter(tp -> "1".equals(tp._1)).map(tp->tp._2).map(temp -> {
            temp.setStatus("checked");
            return temp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        // 获取未核实数据
        JavaRDD<Addr4Marking> rddUncheck = rddTpStd.filter(tp -> !"1".equals(tp._1)).map(tp->tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("checked data count - {}, uncheck data count - {}", rddChecked.count(), rddUncheck.count());
        rddTpStd.unpersist();

        // 未核实的数据经经过aoiname进行第一次判断
        JavaRDD<Addr4Marking> rddCheck = rddUncheck.map(temp -> {
            if (StringUtils.isNotEmpty(temp.getAoiName())) {
                String newAoiName = AddrUtil.transferNumber(temp.getAoiName()).toLowerCase();

                String regex = ".*([a-zA-Z0-9]{1,4})(号楼|号院|栋|座|幢|坐|区|期|组).*";
                Matcher m = Pattern.compile(regex).matcher(newAoiName);
                if ((temp.getAddress().contains(temp.getAoiName()) || temp.getAddress().contains(newAoiName)) && m.matches()) {
                    temp.setStatus("name_check_match");
                }
            }
            return temp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the first time check count - {}", rddCheck.count());
        rddUncheck.unpersist();

        JavaRDD<Addr4Marking> rddSave1 = rddCheck.filter(temp -> StringUtils.isNotEmpty(temp.getStatus())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<Addr4Marking> rddNeedCheck = rddCheck.filter(temp -> StringUtils.isEmpty(temp.getStatus())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the first need save count: {}, uncheck count: {}", rddSave1.count(), rddNeedCheck.count());
        rddCheck.unpersist();

        rddUncheck = rddNeedCheck.filter(temp -> StringUtils.isNotEmpty(temp.getLast1361314())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<Addr4Marking> rddNull = rddNeedCheck.filter(temp -> StringUtils.isEmpty(temp.getLast1361314())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the second need check count: {}, can't check count: {}", rddUncheck.count(), rddNull.count());
        rddNeedCheck.unpersist();

        rddCheck = rddUncheck.mapToPair(temp -> new Tuple2<>(temp.getZnoCode()+"#"+temp.getLast1361314(), temp)).groupByKey().leftOuterJoin(rddChecked.mapToPair(temp -> new Tuple2<>(temp.getZnoCode()+"#"+temp.getLast1361314(), temp)).groupByKey()).flatMap(tp -> {
            List<Addr4Marking> wrongList = Lists.newArrayList(tp._2._1);
            Optional<Iterable<Addr4Marking>> temp = tp._2._2;
            if (temp.isPresent()) {
                List<Addr4Marking> correctList = Lists.newArrayList(temp.get());
                boolean isCorrect;
                String newAoiName;
                if (isOneAoi(correctList)) {
                    for (Addr4Marking a4mWrong : wrongList) {
                        if (a4mWrong.getAoiId().equals(correctList.get(0).getAoiId())) {
                            a4mWrong.setStatus("last13_613_14_aoi_only_match");
                        } else {
                            newAoiName = AddrUtil.transferNumber(a4mWrong.getAoiName()).toLowerCase();
                            if (!newAoiName.contains(a4mWrong.getLast613()) && !a4mWrong.getLast13().contains("村")) {
                                isCorrect = false;
                                for (Addr4Marking a4mCorrect : correctList) {
                                    if (AddrUtil.transferNumber(a4mCorrect.getAoiName()).toLowerCase().contains(a4mWrong.getLast613())) {
                                        a4mWrong.setAoiId(a4mCorrect.getAoiId());
                                        a4mWrong.setAoiName(a4mCorrect.getAoiName());
                                        isCorrect = true;
                                        break;
                                    }
                                }
                                if (isCorrect) {
                                    a4mWrong.setStatus("last13_613_14_aoi_only_unmatch_change_aoi");
                                } else {
                                    a4mWrong.setStatus("last13_613_14_aoi_only_unmatch");
                                }
                            }
                        }
                    }
                } else {
                    for (Addr4Marking a4mWrong : wrongList) {
                        a4mWrong.setStatus("last13_613_14_aoi_mult");
                    }
                }
            }
            return wrongList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the second time Check count - {}", rddCheck.count());
        rddUncheck.unpersist();

        JavaRDD<Addr4Marking> rddSave2 = rddCheck.filter(temp -> StringUtils.isNotEmpty(temp.getStatus())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNeedCheck = rddCheck.filter(temp -> StringUtils.isEmpty(temp.getStatus())).union(rddNull).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the second need save count: {}, uncheck count: {}", rddSave2.count(), rddNeedCheck.count());
        rddCheck.unpersist();

        rddUncheck = rddNeedCheck.filter(temp -> StringUtils.isNotEmpty(temp.getLast1314())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNull = rddNeedCheck.filter(temp -> StringUtils.isEmpty(temp.getLast1314())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the third need check count: {}, can't check count: {}", rddUncheck.count(), rddNull.count());
        rddNeedCheck.unpersist();

        rddCheck = rddUncheck.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast1314(), temp)).groupByKey().leftOuterJoin(rddChecked.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast1314(), temp)).groupByKey()).flatMap(tp -> {
            List<Addr4Marking> wrongList = Lists.newArrayList(tp._2._1);
            Optional<Iterable<Addr4Marking>> temp = tp._2._2;
            if (temp.isPresent()) {
                List<Addr4Marking> correctList = Lists.newArrayList(temp.get());
                boolean isCorrect;
                String newAoiName;
                if (isOneAoi(correctList)) {
                    for (Addr4Marking a4mWrong : wrongList) {
                        if (a4mWrong.getAoiId().equals(correctList.get(0).getAoiId())) {
                            a4mWrong.setStatus("last13_14_aoi_only_match");
                        } else {
                            newAoiName = AddrUtil.transferNumber(a4mWrong.getAoiName()).toLowerCase();
                            if (!newAoiName.contains(a4mWrong.getLast14()) && !a4mWrong.getLast13().contains("村")) {
                                isCorrect = false;
                                for (Addr4Marking a4mCorrect : correctList) {
                                    if (AddrUtil.transferNumber(a4mCorrect.getAoiName()).toLowerCase().contains(a4mWrong.getLast14())) {
                                        a4mWrong.setAoiId(a4mCorrect.getAoiId());
                                        a4mWrong.setAoiName(a4mCorrect.getAoiName());
                                        isCorrect = true;
                                        break;
                                    }
                                }
                                if (isCorrect) {
                                    a4mWrong.setStatus("last13_14_aoi_only_unmatch_change_aoi");
                                } else {
                                    a4mWrong.setStatus("last13_14_aoi_only_unmatch");
                                }
                            }
                        }
                    }
                } else {
                    for (Addr4Marking a4mWrong : wrongList) {
                        a4mWrong.setStatus("last13_14_aoi_mult");
                    }
                }
            }
            return wrongList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the third time Check count - {}", rddCheck.count());
        rddUncheck.unpersist();

        JavaRDD<Addr4Marking> rddSave3 = rddCheck.filter(temp -> StringUtils.isNotEmpty(temp.getStatus())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNeedCheck = rddCheck.filter(temp -> StringUtils.isEmpty(temp.getStatus())).union(rddNull).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the third need save count: {}, uncheck count: {}", rddSave3.count(), rddNeedCheck.count());
        rddCheck.unpersist();

        rddUncheck = rddNeedCheck.filter(temp -> StringUtils.isNotEmpty(temp.getLast13613())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNull = rddNeedCheck.filter(temp -> StringUtils.isEmpty(temp.getLast13613())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the forth need check count: {}, can't check count: {}", rddUncheck.count(), rddNull.count());
        rddNeedCheck.unpersist();

        rddCheck = rddUncheck.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast13613(), temp)).groupByKey().leftOuterJoin(rddChecked.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast13613(), temp)).groupByKey()).flatMap(tp -> {
            List<Addr4Marking> wrongList = Lists.newArrayList(tp._2._1);
            Optional<Iterable<Addr4Marking>> temp = tp._2._2;
            if (temp.isPresent()) {
                List<Addr4Marking> correctList = Lists.newArrayList(temp.get());
                boolean isCorrect;
                String newAoiName;
                if (isOneAoi(correctList)) {
                    for (Addr4Marking a4mWrong : wrongList) {
                        if (a4mWrong.getAoiId().equals(correctList.get(0).getAoiId())) {
                            a4mWrong.setStatus("last13_613_aoi_only_match");
                        } else {
                            newAoiName = AddrUtil.transferNumber(a4mWrong.getAoiName()).toLowerCase();
                            if (!newAoiName.contains(a4mWrong.getLast613()) && !a4mWrong.getLast13().contains("村")) {
                                isCorrect = false;
                                for (Addr4Marking a4mCorrect : correctList) {
                                    if (AddrUtil.transferNumber(a4mCorrect.getAoiName()).toLowerCase().contains(a4mWrong.getLast613())) {
                                        a4mWrong.setAoiId(a4mCorrect.getAoiId());
                                        a4mWrong.setAoiName(a4mCorrect.getAoiName());
                                        isCorrect = true;
                                        break;
                                    }
                                }
                                if (isCorrect) {
                                    a4mWrong.setStatus("last13_613_aoi_only_unmatch_change_aoi");
                                } else {
                                    a4mWrong.setStatus("last13_613_aoi_only_unmatch");
                                }
                            }
                        }
                    }
                } else {
                    for (Addr4Marking a4mWrong : wrongList) {
                        a4mWrong.setStatus("last13_613_aoi_mult");
                    }
                }
            }
            return wrongList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the fourth time Check count - {}", rddCheck.count());
        rddUncheck.unpersist();

        JavaRDD<Addr4Marking> rddSave4 = rddCheck.filter(temp -> StringUtils.isNotEmpty(temp.getStatus())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNeedCheck = rddCheck.filter(temp -> StringUtils.isEmpty(temp.getStatus())).union(rddNull).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the forth need save count: {}, uncheck count: {}", rddSave4.count(), rddNeedCheck.count());
        rddCheck.unpersist();

        rddUncheck = rddNeedCheck.filter(temp -> StringUtils.isNotEmpty(temp.getLast661314())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNull = rddNeedCheck.filter(temp -> StringUtils.isEmpty(temp.getLast661314())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the fifth need check count: {}, can't check count: {}", rddUncheck.count(), rddNull.count());
        rddNeedCheck.unpersist();

        rddCheck = rddUncheck.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast661314(), temp)).groupByKey().leftOuterJoin(rddChecked.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast661314(), temp)).groupByKey()).flatMap(tp -> {
            List<Addr4Marking> wrongList = Lists.newArrayList(tp._2._1);
            Optional<Iterable<Addr4Marking>> temp = tp._2._2;
            if (temp.isPresent()) {
                List<Addr4Marking> correctList = Lists.newArrayList(temp.get());
                if (isOneAoi(correctList)) {
                    for (Addr4Marking a4mWrong : wrongList) {
                        if (a4mWrong.getAoiId().equals(correctList.get(0).getAoiId())) {
                            a4mWrong.setStatus("last_6_613_14_aoi_only_match");
                        } else {
                            a4mWrong.setStatus("last_6_613_14_aoi_only_unmatch");

                        }
                    }
                } else {
                    for (Addr4Marking a4mWrong : wrongList) {
                        a4mWrong.setStatus("last_6_613_14_aoi_mult");
                    }
                }
            }
            return wrongList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the fifth time Check count - {}", rddCheck.count());
        rddUncheck.unpersist();

        JavaRDD<Addr4Marking> rddSave5 = rddCheck.filter(temp -> StringUtils.isNotEmpty(temp.getStatus())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNeedCheck = rddCheck.filter(temp -> StringUtils.isEmpty(temp.getStatus())).union(rddNull).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the fifth need save count: {}, uncheck count: {}", rddSave5.count(), rddNeedCheck.count());
        rddCheck.unpersist();

        rddUncheck = rddNeedCheck.filter(temp -> StringUtils.isNotEmpty(temp.getLast6613())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNull = rddNeedCheck.filter(temp -> StringUtils.isEmpty(temp.getLast6613())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the sixth need check count: {}, can't check count: {}", rddUncheck.count(), rddNull.count());
        rddNeedCheck.unpersist();

        rddCheck = rddUncheck.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast6613(), temp)).groupByKey().leftOuterJoin(rddChecked.mapToPair(temp -> new Tuple2<>(temp.getZnoCode() + "#" + temp.getLast6613(), temp)).groupByKey()).flatMap(tp -> {
            List<Addr4Marking> wrongList = Lists.newArrayList(tp._2._1);
            Optional<Iterable<Addr4Marking>> temp = tp._2._2;
            if (temp.isPresent()) {
                List<Addr4Marking> correctList = Lists.newArrayList(temp.get());
                if (isOneAoi(correctList)) {
                    for (Addr4Marking a4mWrong : wrongList) {
                        if (a4mWrong.getAoiId().equals(correctList.get(0).getAoiId())) {
                            a4mWrong.setStatus("last_6_613_aoi_only_match");
                        } else {
                            a4mWrong.setStatus("last_6_613_aoi_only_unmatch");
                        }
                    }
                } else {
                    for (Addr4Marking a4mWrong : wrongList) {
                        a4mWrong.setStatus("last_6_613_aoi_mult");
                    }
                }
            }
            return wrongList.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("the sixth time Check count - {}", rddCheck.count());
        rddUncheck.unpersist();

        JavaRDD<Addr4Marking> rddSave6 = rddCheck.filter(temp -> StringUtils.isNotEmpty(temp.getStatus())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        rddNeedCheck = rddCheck.filter(temp -> StringUtils.isEmpty(temp.getStatus())).union(rddNull).map(temp -> {
            temp.setStatus("null");
            return temp;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("The sixth time need save count: {}, still need check count: {}", rddSave6.count(), rddUncheck.count());
        rddCheck.unpersist();

//        JavaRDD<Addr4Marking> rddSave = rddSave1.union(rddSave2).union(rddSave3).union(rddSave4).union(rddSave5).union(rddSave6).union(rddChecked).union(rddNeedCheck).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<Addr4Marking> rddSave = rddNeedCheck.repartition(SysConstant.PARTITION_COUNT).union(rddSave1).union(rddSave2).union(rddSave3).union(rddSave4).union(rddSave5).union(rddSave6).union(rddChecked).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("Finally, need save count: {}", rddSave.count());
        rddSave1.unpersist();
        rddSave2.unpersist();
        rddSave3.unpersist();
        rddSave4.unpersist();
        rddSave5.unpersist();
        rddSave6.unpersist();
        DataUtil.saveOverwrite(ss, jsc, "dm_gis.sds_std_marking", Addr4Marking.class, rddSave, "city_code");
    }

    private static JavaPairRDD<String, Addr4Marking> splitAddr(JavaRDD<Addr4Marking> rddStd) {
        return rddStd.map(temp -> {
            AddrInfo addrInfo = AddrApi.split("4ee00c498e334e4da3cc6e35469d5afd", temp.getCityCode(), temp.getAddress());
            temp.setLast6(isEmpty(new String[]{addrInfo.getLast6()}));
            temp.setLast13(isEmpty(new String[]{addrInfo.getLast13()}));
            temp.setLast613(isEmpty(new String[]{addrInfo.getLast613()}));
            temp.setLast14(isEmpty(new String[]{addrInfo.getLast14()}));
            if (StringUtils.isNotEmpty(addrInfo.getLast13()) && StringUtils.isNotEmpty(addrInfo.getLast613()) && StringUtils.isNotEmpty(addrInfo.getLast14())) {
                temp.setLast1361314(isEmpty(new String[]{addrInfo.getLast13(), addrInfo.getLast613(), addrInfo.getLast14()}));
            }
            if (StringUtils.isNotEmpty(addrInfo.getLast13()) && StringUtils.isNotEmpty(addrInfo.getLast14())) {
                temp.setLast1314(isEmpty(new String[]{addrInfo.getLast13(), addrInfo.getLast14()}));
            }
            if (StringUtils.isNotEmpty(addrInfo.getLast13()) && StringUtils.isNotEmpty(addrInfo.getLast613())) {
                temp.setLast13613(isEmpty(new String[]{addrInfo.getLast13(), addrInfo.getLast613()}));
            }
            if (StringUtils.isNotEmpty(addrInfo.getLast6()) && StringUtils.isNotEmpty(addrInfo.getLast613())) {
                temp.setLast6613(isEmpty(new String[]{addrInfo.getLast6(), addrInfo.getLast613()}));
            }
            if (StringUtils.isNotEmpty(addrInfo.getLast6()) && StringUtils.isNotEmpty(addrInfo.getLast613()) && StringUtils.isNotEmpty(addrInfo.getLast14())) {
                temp.setLast661314(isEmpty(new String[]{addrInfo.getLast6(), addrInfo.getLast613(), addrInfo.getLast14()}));
            }
            return temp;
        }).mapToPair(temp -> new Tuple2<>(temp.getAdcode(), temp));
    }

    private static boolean isOneAoi(List<Addr4Marking> correctList) {
        Map<String, Integer> aoiMap = new HashMap<>();
        for (Addr4Marking a4mCorrect : correctList) {
            aoiMap.put(a4mCorrect.getAoiId(), 1);
        }
        return aoiMap.size() == 1;
    }

    private static String isEmpty(String[] args) {
        String result = "";
        if (args == null) {
            return result;
        }
        for (String arg : args) {

            result = StringUtils.isEmpty(arg) ? "" : ((StringUtils.isEmpty(result) ? "" : (result + "|")) + arg);
        }
        return result;
    }
}
