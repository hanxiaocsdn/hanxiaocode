package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class ZcModelComparisonResult implements Serializable {
    @Column(name = "waybill_no")
    private String waybill_no;
    @Column(name = "consignee_addr")
    private String consignee_addr;
    @Column(name = "dest_city_code")
    private String dest_city_code;
    @Column(name = "dest_city_name")
    private String dest_city_name;
    @Column(name = "addressee_dept_code")
    private String addressee_dept_code;
    @Column(name = "dest_zone_code")
    private String dest_zone_code;
    @Column(name = "consignee_aoi_code_dept_code")
    private String consignee_aoi_code_dept_code;
    @Column(name = "old_resp")
    private String old_resp;
    @Column(name = "new_resp")
    private String new_resp;
    @Column(name = "old_dept")
    private String old_dept;
    @Column(name = "new_dept")
    private String new_dept;
    @Column(name = "vip_tag")
    private String vip_tag;

    @Column(name = "dest_zone_code_up")
    private String dest_zone_code_up;
    @Column(name = "old_dept_up")
    private String old_dept_up;
    @Column(name = "new_dept_up")
    private String new_dept_up;
    @Column(name = "old_dept_weight")
    private String old_dept_weight;
    @Column(name = "new_dept_weight")
    private String new_dept_weight;
    @Column(name = "old_dept_up_weight")
    private String old_dept_up_weight;
    @Column(name = "new_dept_up_weight")
    private String new_dept_up_weight;
    @Column(name = "old_tag")
    private String old_tag;
    @Column(name = "new_tag")
    private String new_tag;

    @Column(name = "inc_day")
    private String inc_day;

    public String getDest_zone_code_up() {
        return dest_zone_code_up;
    }

    public void setDest_zone_code_up(String dest_zone_code_up) {
        this.dest_zone_code_up = dest_zone_code_up;
    }

    public String getOld_dept_up() {
        return old_dept_up;
    }

    public void setOld_dept_up(String old_dept_up) {
        this.old_dept_up = old_dept_up;
    }

    public String getNew_dept_up() {
        return new_dept_up;
    }

    public void setNew_dept_up(String new_dept_up) {
        this.new_dept_up = new_dept_up;
    }

    public String getOld_dept_weight() {
        return old_dept_weight;
    }

    public void setOld_dept_weight(String old_dept_weight) {
        this.old_dept_weight = old_dept_weight;
    }

    public String getNew_dept_weight() {
        return new_dept_weight;
    }

    public void setNew_dept_weight(String new_dept_weight) {
        this.new_dept_weight = new_dept_weight;
    }

    public String getOld_dept_up_weight() {
        return old_dept_up_weight;
    }

    public void setOld_dept_up_weight(String old_dept_up_weight) {
        this.old_dept_up_weight = old_dept_up_weight;
    }

    public String getNew_dept_up_weight() {
        return new_dept_up_weight;
    }

    public void setNew_dept_up_weight(String new_dept_up_weight) {
        this.new_dept_up_weight = new_dept_up_weight;
    }

    public String getOld_tag() {
        return old_tag;
    }

    public void setOld_tag(String old_tag) {
        this.old_tag = old_tag;
    }

    public String getNew_tag() {
        return new_tag;
    }

    public void setNew_tag(String new_tag) {
        this.new_tag = new_tag;
    }

    public String getWaybill_no() {
        return waybill_no;
    }

    public void setWaybill_no(String waybill_no) {
        this.waybill_no = waybill_no;
    }

    public String getConsignee_addr() {
        return consignee_addr;
    }

    public void setConsignee_addr(String consignee_addr) {
        this.consignee_addr = consignee_addr;
    }

    public String getDest_city_code() {
        return dest_city_code;
    }

    public void setDest_city_code(String dest_city_code) {
        this.dest_city_code = dest_city_code;
    }

    public String getDest_city_name() {
        return dest_city_name;
    }

    public void setDest_city_name(String dest_city_name) {
        this.dest_city_name = dest_city_name;
    }

    public String getAddressee_dept_code() {
        return addressee_dept_code;
    }

    public void setAddressee_dept_code(String addressee_dept_code) {
        this.addressee_dept_code = addressee_dept_code;
    }

    public String getDest_zone_code() {
        return dest_zone_code;
    }

    public void setDest_zone_code(String dest_zone_code) {
        this.dest_zone_code = dest_zone_code;
    }

    public String getConsignee_aoi_code_dept_code() {
        return consignee_aoi_code_dept_code;
    }

    public void setConsignee_aoi_code_dept_code(String consignee_aoi_code_dept_code) {
        this.consignee_aoi_code_dept_code = consignee_aoi_code_dept_code;
    }

    public String getOld_resp() {
        return old_resp;
    }

    public void setOld_resp(String old_resp) {
        this.old_resp = old_resp;
    }

    public String getNew_resp() {
        return new_resp;
    }

    public void setNew_resp(String new_resp) {
        this.new_resp = new_resp;
    }

    public String getOld_dept() {
        return old_dept;
    }

    public void setOld_dept(String old_dept) {
        this.old_dept = old_dept;
    }

    public String getNew_dept() {
        return new_dept;
    }

    public void setNew_dept(String new_dept) {
        this.new_dept = new_dept;
    }

    public String getVip_tag() {
        return vip_tag;
    }

    public void setVip_tag(String vip_tag) {
        this.vip_tag = vip_tag;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
