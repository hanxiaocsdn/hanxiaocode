package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import com.sf.gis.java.sds.pojo.CgcsErrorAddressResult;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;


/**
 * 任务id:	658816(cgcs任务数据回收)
 * 业务方：01394694（郭本婕）
 * 研发：01399581（匡仁衡）
 */
public class AppCgcsDataRecovery {
    private static Logger logger = LoggerFactory.getLogger(AppCgcsDataRecovery.class);
    private static String updateAddrAoiCheck = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiCheck";
    private static String updateAddrMd5AoiCheck = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrMd5AoiCheck";
    private static String updateAddrAoiId = "http://gis-cms-bg.sf-express.com/cms/api/address/updateAddrAoiId";
    private static String queryPoi = "http://gis-gw.int.sfdc.com.cn:9080/transform/gd/v5/queryPoi?keywords=%s";
    private static String byxy = "http://gis-apis.int.sfcloud.local:1080/dept2/byxy?x=%s&y=%s&opt=aoi&ak=87106f6380af4df0845a693eee58843c";
    private static String geo = "http://gis-int.int.sfdc.com.cn:1080/geo/api?ak=87106f6380af4df0845a693eee58843c&opt=%s&address=%s&city=%s";

    private static int limitMinGd = 1000 / 40;
    private static String account = "01399581";
    private static String taskId = "658816";
    private static String taskName = "cgcs任务数据回收";

    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);

        SparkInfo sparkInfo = SparkUtil.getSpark("AppCgcsDataRecovery");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");

        JavaRDD<CgcsErrorAddressResult> rdd = loadCgcsErrorAddressResultData(spark, sc, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        String beforeDay = DateUtil.getDaysBefore(14, FixedConstant.DATE_FROMAT_YYYYMMDD_GAPLESS);
        JavaRDD<AoiRealAccturyRateJudgeWrongOperation> cgcsMisclassificationRdd = loadCgcsMisclassification(spark, sc, beforeDay, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cgcsMisclassificationRdd cnt:{}", cgcsMisclassificationRdd.count());

        JavaRDD<CgcsErrorAddressResult> guidRdd = rdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o))
                .leftOuterJoin(cgcsMisclassificationRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1))
                .filter(tp -> tp._2._2 != null && tp._2._2.isPresent())
                .map(tp -> {
                    CgcsErrorAddressResult o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        AoiRealAccturyRateJudgeWrongOperation aoiRealAccturyRateJudgeWrongOperation = tp._2._2.get();
                        o.setGuid(aoiRealAccturyRateJudgeWrongOperation.getGuid());
                        o.setGisaoisrc(aoiRealAccturyRateJudgeWrongOperation.getGisaoisrc());
                        o.setGis_to_sys_groupid(aoiRealAccturyRateJudgeWrongOperation.getGis_to_sys_groupid());
                        o.setOld_cms_aoiid(aoiRealAccturyRateJudgeWrongOperation.getOld_cms_aoiid());
                        o.setOrg_code(aoiRealAccturyRateJudgeWrongOperation.getOrg_code());
                        o.setGj_aoiid_t(aoiRealAccturyRateJudgeWrongOperation.getGj_aoiid_t());
                        o.setAoi_80_code(aoiRealAccturyRateJudgeWrongOperation.getAoi_80_code());
                    }
                    return o;
                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("guidRdd cnt:{}", guidRdd.count());
        rdd.unpersist();
        cgcsMisclassificationRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> adcodeRdd = guidRdd.mapPartitions(itr -> {
            Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
            Statement stmt = conn.createStatement();
            List<CgcsErrorAddressResult> list = new ArrayList<>();
            try {
                while (itr.hasNext()) {
                    CgcsErrorAddressResult o = itr.next();
                    String gis_to_sys_groupid = o.getGis_to_sys_groupid();
                    String gisaoisrc = o.getGisaoisrc();
                    String city_code = o.getCity_code();
                    if (StringUtils.isNotEmpty(gis_to_sys_groupid) && StringUtils.isNotEmpty(city_code) && StringUtils.isNotEmpty(gisaoisrc)) {
                        String sql = "";
                        if (StringUtils.equals(gisaoisrc, "norm")) {
                            sql = String.format("select adcode,aoi_id from cms_address_%s where city_code='%s' and address_id = '%s'", cityDbPro.getProperty(city_code), city_code, gis_to_sys_groupid);
                        } else if (StringUtils.equals(gisaoisrc, "chkn")) {
                            sql = String.format("select adcode,aoi_id from cms_address_%s where city_code='%s' and address_md5 = '%s'", cityDbPro.getProperty(city_code), city_code, gis_to_sys_groupid);
                        }
                        logger.info("sql:{}", sql);
                        if (StringUtils.isNotEmpty(sql)) {
                            ResultSet rs = stmt.executeQuery(sql);
                            while (rs.next()) {
                                String adcode = rs.getString("adcode");
                                String aoi_id = rs.getString("aoi_id");
                                o.setAdcode(adcode);
                                o.setAoi_id(aoi_id);
                            }
                        }
                    }
                    list.add(o);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                stmt.close();
                conn.close();
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("adcodeRdd cnt:{}", adcodeRdd.count());
        guidRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> filterAdcodeRdd = adcodeRdd.filter(o -> {
            boolean flag = true;
            String adcode = o.getAdcode();
            String[] list = {"1", "4", "5", "6", "7", "8", "9", "10", "11", "12"};
            if (StringUtils.isNotEmpty(adcode) && Arrays.asList(list).contains(adcode)) {
                flag = false;
            }
            return flag;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterAdcodeRdd cnt:{}", filterAdcodeRdd.count());
        adcodeRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> eqAoiRdd = filterAdcodeRdd.filter(o -> StringUtils.isNotEmpty(o.getCheck_aoi_id()) && StringUtils.equals(o.getCheck_aoi_id(), o.getAoi_id())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsErrorAddressResult> noEqAoiRdd = filterAdcodeRdd.filter(o -> !(StringUtils.isNotEmpty(o.getCheck_aoi_id()) && StringUtils.equals(o.getCheck_aoi_id(), o.getAoi_id()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqAoiRdd cnt:{}", eqAoiRdd.count());
        logger.error("noEqAoiRdd cnt:{}", noEqAoiRdd.count());
        filterAdcodeRdd.unpersist();

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", updateAddrAoiCheck, "", eqAoiRdd.count(), 40);
        JavaRDD<CgcsErrorAddressResult> eqAoiCheckRdd = eqAoiRdd.map(o -> {
            String guid = o.getGuid();
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            JSONObject param = new JSONObject();
            JSONArray list = new JSONArray();
            list.add(gis_to_sys_groupid);
            param.put("cityCode", city_code);
            param.put("aoiCheckTag", 6);
            if (StringUtils.equals(guid, "norm")) {
                o.setUpdateaddraoicheck_tag("updateAddrAoiCheck");
                param.put("addressIds", list);
                String content = HttpInvokeUtil.sendPostNew(updateAddrAoiCheck, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
                o.setUpdateaddraoicheck_response(content);

            } else if (StringUtils.equals(guid, "chkn")) {
                o.setUpdateaddraoicheck_tag("updateAddrMd5AoiCheck");
                param.put("addressMd5s", list);
                String content = HttpInvokeUtil.sendPostNew(updateAddrMd5AoiCheck, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
                o.setUpdateaddraoicheck_response(content);

            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqAoiCheckRdd cnt:{}", eqAoiCheckRdd.count());
        eqAoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", queryPoi, "860aafa74c7846a3b4519f552851a5aa", noEqAoiRdd.count(), 40);
        JavaRDD<CgcsErrorAddressResult> xyRdd = noEqAoiRdd.mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<CgcsErrorAddressResult> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMinGd) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMinGd, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                CgcsErrorAddressResult o = itr.next();
                String address = o.getAddress();
                if (StringUtils.isNotEmpty(address)) {
                    String req = String.format(queryPoi, URLEncoder.encode(address, "UTF-8"));
                    String gd_result = getJsonByGet(req, "ak", "860aafa74c7846a3b4519f552851a5aa");
                    if (StringUtils.isNotEmpty(gd_result)) {
                        o.setGd_result(gd_result);
                        try {
                            String location = JSON.parseObject(gd_result).getJSONObject("result").getJSONArray("pois").getJSONObject(0).getString("location");
                            if (StringUtils.isNotEmpty(location)) {
                                String[] split = location.split(",");
                                if (split.length >= 2) {
                                    o.setX(split[0]);
                                    o.setY(split[1]);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("xyRdd cnt:{}", xyRdd.count());
        noEqAoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", byxy, "87106f6380af4df0845a693eee58843c", xyRdd.count(), 40);
        JavaRDD<CgcsErrorAddressResult> gdAoiRdd = xyRdd.map(o -> {
            String x = o.getX();
            String y = o.getY();
            if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                String req = String.format(byxy, x, y);
                String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                if (StringUtils.isNotEmpty(content)) {
                    try {
                        String aoi_id = JSON.parseObject(content).getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id");
                        o.setGdps_aoiid(aoi_id);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdAoiRdd cnt:{}", gdAoiRdd.count());
        xyRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id3);


        JavaRDD<CgcsErrorAddressResult> eqGdAoiRdd = gdAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getCheck_aoi_id()) && StringUtils.equals(o.getCheck_aoi_id(), o.getGdps_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsErrorAddressResult> noEqGdAoiRdd = gdAoiRdd.filter(o -> !(StringUtils.isNotEmpty(o.getCheck_aoi_id()) && StringUtils.equals(o.getCheck_aoi_id(), o.getGdps_aoiid()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqGdAoiRdd cnt:{}", eqGdAoiRdd.count());
        logger.error("noEqGdAoiRdd cnt:{}", noEqGdAoiRdd.count());
        gdAoiRdd.unpersist();


        JavaRDD<CgcsErrorAddressResult> eqGjAoiRdd = noEqGdAoiRdd.filter(o -> StringUtils.isNotEmpty(o.getCheck_aoi_id()) && StringUtils.equals(o.getCheck_aoi_id(), o.getGj_aoiid_t())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsErrorAddressResult> noEqGjAoiRdd = noEqGdAoiRdd.filter(o -> !(StringUtils.isNotEmpty(o.getCheck_aoi_id()) && StringUtils.equals(o.getCheck_aoi_id(), o.getGj_aoiid_t()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqGjAoiRdd cnt:{}", eqGjAoiRdd.count());
        logger.error("noEqGjAoiRdd cnt:{}", noEqGjAoiRdd.count());
        noEqGdAoiRdd.unpersist();

        String id4 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", geo, "87106f6380af4df0845a693eee58843c", noEqGjAoiRdd.count(), 40);
        String id5 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", byxy, "87106f6380af4df0845a693eee58843c", noEqGjAoiRdd.count(), 40);
        JavaRDD<CgcsErrorAddressResult> tsAoiRdd = noEqGjAoiRdd.map(o -> {
            String address = o.getAddress();
            String city_code = o.getCity_code();
            if (StringUtils.isNotEmpty(address)) {
                String gd2_req = String.format(geo, "gd2", URLEncoder.encode(address, "UTF-8"), city_code);
                String rh1_req = String.format(geo, "rh1", URLEncoder.encode(address, "UTF-8"), city_code);
                String bd2_req = String.format(geo, "bd2", URLEncoder.encode(address, "UTF-8"), city_code);
                String tc2_req = String.format(geo, "tc2", URLEncoder.encode(address, "UTF-8"), city_code);
                String gd_aoi = getAoi(o, gd2_req);
                String mapa_aoi = getAoi(o, rh1_req);
                String bd_aoi = getAoi(o, bd2_req);
                String tc_aoi = getAoi(o, tc2_req);

                o.setGd_aoiid(gd_aoi);
                o.setMapa_aoiid(mapa_aoi);
                o.setBd_aoiid(bd_aoi);
                o.setTc_aoiid(tc_aoi);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tsAoiRdd cnt:{}", tsAoiRdd.count());
        noEqGjAoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id4);
        BdpTaskRecordUtil.endNetworkInterface(account, id5);


        JavaRDD<CgcsErrorAddressResult> containRdd = noEqGjAoiRdd.filter(AppCgcsDataRecovery::judgeAoi).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsErrorAddressResult> noContainRdd = noEqGjAoiRdd.filter(o -> !judgeAoi(o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("containRdd cnt:{}", containRdd.count());
        logger.error("noContainRdd cnt:{}", noContainRdd.count());
        noEqGjAoiRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> eqAoiCodeRdd = noContainRdd.filter(o -> StringUtils.isNotEmpty(o.getCheck_aoi_code()) && StringUtils.equals(o.getCheck_aoi_code(), o.getAoi_80_code())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsErrorAddressResult> noEqAoiCodeRdd = noContainRdd.filter(o -> !(StringUtils.isNotEmpty(o.getCheck_aoi_code()) && StringUtils.equals(o.getCheck_aoi_code(), o.getAoi_80_code()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqAoiCodeRdd cnt:{}", eqAoiCodeRdd.count());
        logger.error("noEqAoiCodeRdd cnt:{}", noEqAoiCodeRdd.count());
        noContainRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> empRdd = noEqAoiCodeRdd.filter(o -> StringUtils.isEmpty(o.getGd_aoiid()) && StringUtils.isEmpty(o.getMapa_aoiid()) && StringUtils.isEmpty(o.getBd_aoiid()) && StringUtils.isEmpty(o.getTc_aoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<CgcsErrorAddressResult> noEmpRdd = noEqAoiCodeRdd.filter(o -> !(StringUtils.isEmpty(o.getGd_aoiid()) && StringUtils.isEmpty(o.getMapa_aoiid()) && StringUtils.isEmpty(o.getBd_aoiid()) && StringUtils.isEmpty(o.getTc_aoiid()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("empRdd cnt:{}", empRdd.count());
        logger.error("noEmpRdd cnt:{}", noEmpRdd.count());
        noEqAoiCodeRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> noEqAoiAllRdd = eqGdAoiRdd.union(eqGjAoiRdd).union(containRdd).union(eqAoiCodeRdd).union(empRdd).map(o -> {
            String gisaoisrc = o.getGisaoisrc();
            String guid = o.getGuid();
            String city_code = o.getCity_code();
            String check_dept_code = o.getCheck_dept_code();
            String address = o.getAddress();
            String check_aoi_id = o.getCheck_aoi_id();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            String check_by = o.getCheck_by();
            JSONObject param = new JSONObject();
            o.setUpdateaddraoiid_tag("updateAddrAoiId");
            param.put("cityCode", city_code);
            param.put("aoiId", check_aoi_id);
            param.put("operUserName", check_by);
            param.put("lockCheck", 0);
            param.put("aoiSource", "S93");
            if (StringUtils.equals(gisaoisrc, "norm")) {
                param.put("addressId", gis_to_sys_groupid);
                param.put("operSource", "PAI_WRONG_BIAOZHUN");

            } else if (StringUtils.equals(gisaoisrc, "chkn")) {
                param.put("addressMd5", gis_to_sys_groupid);
                param.put("operSource", "PAI_WRONG_SHENBU");
            }
            String content = HttpInvokeUtil.sendPostNew(updateAddrAoiId, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
            if (StringUtils.isNotEmpty(content)) {
                o.setUpdateaddraoiid_response(content);
                JSONObject jsonObject = JSON.parseObject(content);
                if (jsonObject != null) {
                    o.setFlag(jsonObject.getString("success"));
                }
            }

            if (StringUtils.equals(o.getFlag(), "true")) {
                JSONObject jsonObject = new JSONObject();
                JSONArray list = new JSONArray();
                list.add(gis_to_sys_groupid);
                jsonObject.put("cityCode", city_code);
                jsonObject.put("aoiCheckTag", 6);
                if (StringUtils.equals(guid, "norm")) {
                    o.setUpdateaddraoicheck_tag("updateAddrAoiCheck");
                    jsonObject.put("addressIds", list);
                    String rs = HttpInvokeUtil.sendPostNew(updateAddrAoiCheck, jsonObject.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
                    o.setUpdateaddraoicheck_response(rs);

                } else if (StringUtils.equals(guid, "chkn")) {
                    o.setUpdateaddraoicheck_tag("updateAddrMd5AoiCheck");
                    jsonObject.put("addressMd5s", list);
                    String rs = HttpInvokeUtil.sendPostNew(updateAddrMd5AoiCheck, jsonObject.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
                    o.setUpdateaddraoicheck_response(rs);
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEqAoiAllRdd cnt:{}", noEqAoiAllRdd.count());
        eqGdAoiRdd.unpersist();
        eqGjAoiRdd.unpersist();
        containRdd.unpersist();
        eqAoiCodeRdd.unpersist();
        empRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> noEmpLastRdd = noEmpRdd.map(o -> {
            String gisaoisrc = o.getGisaoisrc();
            String city_code = o.getCity_code();
            String check_dept_code = o.getCheck_dept_code();
            String address = o.getAddress();
            String check_aoi_id = o.getCheck_aoi_id();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            String check_by = o.getCheck_by();
            JSONObject param = new JSONObject();
            o.setUpdateaddraoiid_tag("updateAddrAoiId");
            param.put("cityCode", city_code);
            param.put("aoiId", check_aoi_id);
            param.put("operUserName", check_by);
            param.put("lockCheck", 0);
            param.put("aoiSource", "S95");
            if (StringUtils.equals(gisaoisrc, "norm")) {
                param.put("addressId", gis_to_sys_groupid);
                param.put("operSource", "PAI_WRONG_BIAOZHUN");

            } else if (StringUtils.equals(gisaoisrc, "chkn")) {
                param.put("addressMd5", gis_to_sys_groupid);
                param.put("operSource", "PAI_WRONG_SHENBU");
            }
            String content = HttpInvokeUtil.sendPostNew(updateAddrAoiId, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
            if (StringUtils.isNotEmpty(content)) {
                o.setUpdateaddraoiid_response(content);
//                JSONObject jsonObject = JSON.parseObject(content);
//                if (jsonObject != null) {
//                    o.setFlag(jsonObject.getString("success"));
//                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpLastRdd cnt:{}", noEmpLastRdd.count());
        noEmpRdd.unpersist();

        JavaRDD<CgcsErrorAddressResult> resultRdd = eqAoiCheckRdd.union(noEqAoiAllRdd).union(noEmpLastRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        eqAoiCheckRdd.unpersist();
        noEqAoiAllRdd.unpersist();
        noEmpLastRdd.unpersist();


        spark.sql(String.format("alter table dm_gis.cgcs_error_address_result_recovery drop if EXISTS partition( inc_day='%s')", date));
        DataUtil.saveInto(spark, sc, "dm_gis.cgcs_error_address_result_recovery", CgcsErrorAddressResult.class, resultRdd, "inc_day");
        resultRdd.unpersist();

        sc.stop();
        logger.error("run end...");
    }

    public static boolean judgeAoi(CgcsErrorAddressResult o) {
        String check_aoi_id = o.getCheck_aoi_id();
        String gd_aoiid = o.getGd_aoiid();
        String mapa_aoiid = o.getMapa_aoiid();
        String bd_aoiid = o.getBd_aoiid();
        String tc_aoiid = o.getTc_aoiid();
        String[] list = {gd_aoiid, mapa_aoiid, bd_aoiid, tc_aoiid};
        return StringUtils.isNotEmpty(check_aoi_id) && Arrays.asList(list).contains(check_aoi_id);
    }

    public static String getAoi(CgcsErrorAddressResult o, String req) {
        String aoi_id = "";
        String content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
        if (StringUtils.isNotEmpty(content)) {
            try {
                String x = JSON.parseObject(content).getJSONObject("result").getString("xcoord");
                String y = JSON.parseObject(content).getJSONObject("result").getString("ycoord");
                if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                    String xy_req = String.format(byxy, x, y);
                    String xy_content = HttpInvokeUtil.sendGet(req, FixedConstant.MAX_TRY_TIME_ONCE);
                    if (StringUtils.isNotEmpty(xy_content)) {
                        aoi_id = JSON.parseObject(xy_content).getJSONObject("result").getJSONArray("aoi_data").getJSONObject(0).getString("aoi_id");
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return aoi_id;
    }

    public static String getJsonByGet(String url, String header, String value) {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        String stringEntity = "";
        try {
            HttpGet httpGet = new HttpGet(url);
            httpGet.addHeader(header, value);
            CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
            if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                HttpEntity httpEntity = httpResponse.getEntity();
                try {
                    stringEntity = EntityUtils.toString(httpEntity, "UTF-8");
                } catch (Exception e) {
                    logger.error(">>>获取stringEntity异常：" + e);
                }
            }
            httpResponse.close();
            httpClient.close();
        } catch (Exception e) {
            logger.error(">>>获取httpResponse异常：" + e);
        }
        return stringEntity;
    }

    public static JavaRDD<CgcsErrorAddressResult> loadCgcsErrorAddressResultData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select check_result,city_code,zno_code,address,check_by,check_aoi_id,check_dept_code,check_aoi_code,inc_day from dm_gis.cgcs_error_address_result where inc_day between '%s' and '%s' and check_result in ('1','2')", date, date);
        return DataUtil.loadData(spark, sc, sql, CgcsErrorAddressResult.class);
    }

    public static JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadCgcsMisclassification(SparkSession spark, JavaSparkContext sc, String date1, String date2) {
        String sql = String.format("select address,guid,gisaoisrc,gis_to_sys_groupid,old_cms_aoiid,org_code,gj_aoiid_t,80_aoi_code from dm_gis.cgcss_misclassification_data_shunt where operate_date between '%s' and '%s'", date1, date2);
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }
}
