package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class AoiValue implements Serializable {
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "channel")
    private String channel;
    @Column(name = "wage_level")
    private String wage_level;

    @Column(name = "pick_wage_level")
    private String pick_wage_level;
    @Column(name = "send_wage_level")
    private String send_wage_level;

    public String getPick_wage_level() {
        return pick_wage_level;
    }

    public void setPick_wage_level(String pick_wage_level) {
        this.pick_wage_level = pick_wage_level;
    }

    public String getSend_wage_level() {
        return send_wage_level;
    }

    public void setSend_wage_level(String send_wage_level) {
        this.send_wage_level = send_wage_level;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public String getWage_level() {
        return wage_level;
    }

    public void setWage_level(String wage_level) {
        this.wage_level = wage_level;
    }
}
