package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.BottomcorrectedPaiGdv5;
import com.sf.gis.java.sds.pojo.BottomcorrectedVillageAddr;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.scala.base.pojo.Cnt;
import com.sf.gis.scala.base.pojo.StratTime;
import com.sf.gis.scala.base.spark.SparkUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.apache.log4j.Logger;
import scala.Tuple2;

import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * 任务id：932036（乡村地址一期误判数据_高德ps修正需求）
 * 业务：01434066（宋雨莲）
 * 研发：01399581（匡仁衡）
 */

public class AppBottomcorrectedVillageAddrMisjudgmentCorrecte {
    private static final Logger logger = Logger.getLogger(AppBottomcorrectedVillageAddrMisjudgmentCorrecte.class);
    private static final String gd = "http://gis-gaode.int.sfcloud.local:1080/optimalMatching?address=%s";
    private static final String updateAddrAoiId = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiId";
    private static final String rgsbAdd = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/rgsbAdd";
    private static final String updateAddrAoiCheck = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrAoiCheck";
    private static final String updateAddrMd5AoiCheck = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateAddrMd5AoiCheck";
    private static final String account = "01399581";
    private static final String taskId = "932036";
    private static final String taskName = "乡村地址一期误判数据_高德ps修正需求";

    private static final int limitMin = 4000 / 10;

    public static void main(String[] args) {
        String date = args[0];
        String before3Date = DateUtil.getDaysBefore(date, 1);
        logger.error("date:" + date);
        logger.error("before3Date:" + before3Date);
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppBottomcorrectedVillageAddrMisjudgmentCorrecte");
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();
        Properties cityDbPro = ConfigUtil.loadPropertiesConfiguration("std_tbl_reflect.properties");
        Broadcast<Properties> cityDbProBc = sc.broadcast(cityDbPro);
        //获取数据源
        JavaRDD<BottomcorrectedVillageAddr> rdd = getData(spark, sc, date, before3Date);
        //获取80_aoi_code对应aoiid
        JavaRDD<BottomcorrectedVillageAddr> aoi80Rdd = get80Aoi(spark, sc, rdd);
        //根据gisaoisrc来源，走不同工艺
        JavaRDD<BottomcorrectedVillageAddr> gdRdd = process(aoi80Rdd, spark, sc, date, cityDbProBc);
        //结果存储
        DataUtil.saveOverwrite(spark, sc, "dm_gis.bottomcorrected_village_addr_misjudgment_correcte", BottomcorrectedVillageAddr.class, gdRdd, "inc_day");
        gdRdd.unpersist();
        sc.stop();
    }

    public static JavaRDD<BottomcorrectedVillageAddr> process(JavaRDD<BottomcorrectedVillageAddr> aoi80Rdd, SparkSession spark, JavaSparkContext sc, String date, Broadcast<Properties> cityDbProBc) {
        JavaRDD<BottomcorrectedVillageAddr> normRdd = aoi80Rdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<BottomcorrectedVillageAddr> otherRdd = aoi80Rdd.filter(o -> !StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normRdd cnt:" + normRdd.count());
        logger.error("otherRdd cnt:" + otherRdd.count());
        aoi80Rdd.unpersist();

        logger.error("处理norm数据");
        String group_sql = String.format("select\n" +
                "  gis_to_sys_groupid\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      gis_to_sys_groupid\n" +
                "    FROM\n" +
                "      dm_gis.bottomcorrected_pai_gdv5\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and (gis_to_sys_groupid is not null and gis_to_sys_groupid <>'')\n" +
                "    union\n" +
                "    select\n" +
                "      address_id as gis_to_sys_groupid\n" +
                "    FROM\n" +
                "      dm_gis.split_aoi_address_cleansing_c\n" +
                "    where\n" +
                "      inc_day = '20231114'\n" +
                "      and (address_id is not null and address_id <>'')\n" +
                "    union\n" +
                "    select\n" +
                "      gis_to_sys_groupid\n" +
                "    From\n" +
                "      dm_gis.sfxg_event_pai_gdv5\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and (gis_to_sys_groupid is not null and gis_to_sys_groupid <>'')\n" +
                "  ) t\n" +
                "group by\n" +
                "  t.gis_to_sys_groupid", date, date);
        JavaPairRDD<String, BottomcorrectedPaiGdv5> gisToSysGroupidRdd = DataUtil.loadData(spark, sc, group_sql, BottomcorrectedPaiGdv5.class).mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gisToSysGroupidRdd cnt:" + gisToSysGroupidRdd.count());

        logger.error("过滤掉符合清除条件的大组");
        JavaRDD<BottomcorrectedVillageAddr> afterFilterRdd = normRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).leftOuterJoin(gisToSysGroupidRdd).filter(tp -> {
            return tp._2._2 == null || !tp._2._2.isPresent();
        }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("afterFilterRdd cnt:" + afterFilterRdd.count());
        normRdd.unpersist();
        gisToSysGroupidRdd.unpersist();

        JavaRDD<BottomcorrectedVillageAddr> stdAddrRdd = afterFilterRdd.mapPartitions(itr -> {
            Properties cityMap = cityDbProBc.value();
            Connection conn = JdbcUtil.getMysqlConnection("mysql_wchka.properties");
            Statement stmt = conn.createStatement();
            List<BottomcorrectedVillageAddr> list = new ArrayList<>();
            try {
                while (itr.hasNext()) {
                    BottomcorrectedVillageAddr o = itr.next();
                    String gis_to_sys_groupid = o.getGis_to_sys_groupid();
                    String city_code = o.getCity_code();
                    if (StringUtils.isNotEmpty(gis_to_sys_groupid) && StringUtils.isNotEmpty(city_code)) {
                        String sql = String.format("select address from cms_address_%s where city_code='%s' and address_id = '%s'", cityMap.getProperty(city_code), city_code, gis_to_sys_groupid);
                        logger.info("sql:" + sql);
                        if (StringUtils.isNotEmpty(sql)) {
                            ResultSet rs = stmt.executeQuery(sql);
                            while (rs.next()) {
                                String address = rs.getString("address");
                                o.setStd_address(fixnulltoStr(address));
                            }
                        }
                    }
                    list.add(o);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                stmt.close();
                conn.close();
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdAddrRdd cnt:" + stdAddrRdd.count());
        afterFilterRdd.unpersist();


        String id = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", gd, "", stdAddrRdd.count() + otherRdd.count(), 10);
        JavaRDD<BottomcorrectedVillageAddr> gdRdd = stdAddrRdd.union(otherRdd).repartition(10).mapPartitionsWithIndex(((index, itr) -> {
            ArrayList<BottomcorrectedVillageAddr> list = new ArrayList<>();
            StratTime stratTime = new StratTime(System.currentTimeMillis());
            Cnt cnt = new Cnt(0);
            while (itr.hasNext()) {
                SparkUtils.limitAkUse(stratTime, cnt, index, limitMin, logger);
                BottomcorrectedVillageAddr o = itr.next();
                String gisaoisrc = o.getGisaoisrc();
                String address = "";
                if ("norm".equals(gisaoisrc)) {
                    address = o.getStd_address();
                } else {
                    address = o.getReq_addresseeaddr();
                }
                String gd_aoi = "";
                if (StringUtils.isNotEmpty(address)) {
                    String req = String.format(gd, URLEncoder.encode(address, "UTF-8"));
                    String content = HttpInvokeUtil.sendGet(req);
                    o.setGd_resp(content);
                    try {
                        gd_aoi = JSON.parseObject(content).getJSONObject("message").getJSONArray("result").getJSONObject(0).getString("aoiid");
                    } catch (Exception e) {
//                        e.printStackTrace();
                    }
                }
                o.setGdaoi(gd_aoi);
                list.add(o);
            }
            return list.iterator();
        }), false).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdRdd cnt:" + gdRdd.count());
        stdAddrRdd.unpersist();
        otherRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id);
        //取gdaoi=80_aoiid and 不为空

        JavaRDD<BottomcorrectedVillageAddr> eqAoiRdd = gdRdd.filter(o -> StringUtils.isNotEmpty(o.getGdaoi()) && StringUtils.equals(o.getGdaoi(), o.getAoi_id_80())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqAoiRdd cnt:" + eqAoiRdd.count());
        gdRdd.unpersist();

        JavaRDD<BottomcorrectedVillageAddr> lastRdd = eqAoiRdd.repartition(2).map(o -> {
            String gisaoisrc = o.getGisaoisrc();
            String city_code = o.getCity_code();
            String gis_to_sys_groupid = o.getGis_to_sys_groupid();
            String gdaoi = o.getGdaoi();
            String req_addresseeaddr = o.getReq_addresseeaddr();
            String aoi_code_80 = o.getAoi_code_80();

            String operUserName = "01434066";
            String operSource = "80_gdps";
            JSONObject param1 = new JSONObject();
            param1.put("operUserName", operUserName);
            param1.put("operSource", operSource);
            String url1 = "";
            if ("norm".equals(gisaoisrc)) {
                url1 = updateAddrAoiId;
                param1.put("cityCode", city_code);
                param1.put("aoiId", gdaoi);
                param1.put("addressId", gis_to_sys_groupid);
                param1.put("aoiSource", "S99");
            } else {
                url1 = rgsbAdd;
                param1.put("ak", "7577390e76cc40b6ad6542640edd9d84");
                JSONObject addressSave = new JSONObject();
                addressSave.put("cityCode", city_code);
                addressSave.put("address", req_addresseeaddr);
                addressSave.put("aoiId", gdaoi);
                addressSave.put("znoCode", StringUtils.isNotEmpty(aoi_code_80) ? aoi_code_80.substring(0, aoi_code_80.length() - 6) : "");
                param1.put("addressSave", addressSave);
            }
            String content1 = HttpInvokeUtil.sendPost(url1, param1.toString());
            boolean update_result = false;
            try {
                update_result = JSON.parseObject(content1).getBoolean("success");
            } catch (Exception e) {
//                e.printStackTrace();
            }

            if (update_result) {
                o.setUpdate_result(update_result + "");
                JSONObject param2 = new JSONObject();
                param2.put("cityCode", city_code);
                param2.put("aoiCheckTag", "10");
                JSONArray list = new JSONArray();
                String url2 = "";
                if ("norm".equals(gisaoisrc)) {
                    url2 = updateAddrAoiCheck;
                    list.add(gis_to_sys_groupid);
                    param2.put("addressIds", list);
                } else {
                    url2 = updateAddrMd5AoiCheck;
                    String addressMd5 = JSON.parseObject(content1).getJSONObject("data").getString("addressMd5");
                    list.add(addressMd5);
                    param2.put("addressMd5s", list);
                }
                String content2 = HttpInvokeUtil.sendPost(url2, param2.toString());
                boolean update_tag = false;
                try {
                    update_tag = JSON.parseObject(content2).getBoolean("success");
                } catch (Exception e) {
                    e.printStackTrace();
                }
                if (update_tag) {
                    o.setUpdate_tag(update_tag + "");
                } else {
                    o.setUpdate_tag(content2);
                }
            } else {
                o.setUpdate_result(content1);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:" + lastRdd.count());
        eqAoiRdd.unpersist();

        return lastRdd;
    }

    public static String fixnulltoStr(String str) {
        if (str == null || str.trim().toLowerCase().equals("null")) {
            return "";
        }
        return str;
    }


    public static JavaRDD<BottomcorrectedVillageAddr> get80Aoi(SparkSession spark, JavaSparkContext sc, JavaRDD<BottomcorrectedVillageAddr> rdd) {
        String aoi_sql = "select aoi_code,aoi_id from dm_gis.cms_aoi_sch group by aoi_code,aoi_id";
        JavaPairRDD<String, String> aoiRdd = DataUtil.loadData(spark, sc, aoi_sql, CmsAoiSch.class).mapToPair(o -> new Tuple2<>(o.getAoi_code(), o.getAoi_id())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiRdd cnt:" + aoiRdd.count());
        JavaRDD<BottomcorrectedVillageAddr> aoi80Rdd = rdd.mapToPair(o -> new Tuple2<>(o.getAoi_code_80(), o)).leftOuterJoin(aoiRdd).map(tp -> {
            BottomcorrectedVillageAddr o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                String aoi_id = tp._2._2.get();
                o.setAoi_id_80(aoi_id);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoi80Rdd cnt:" + aoi80Rdd.count());
        rdd.unpersist();
        aoiRdd.unpersist();
        return aoi80Rdd;
    }

    public static JavaRDD<BottomcorrectedVillageAddr> getData(SparkSession spark, JavaSparkContext sc, String date, String before3Date) {
        String sql1 = String.format("select\n" +
                "  waybillno,\n" +
                "  city_code,\n" +
                "  org_code,\n" +
                "  req_addresseeaddr,\n" +
                "  req_comp_name,\n" +
                "  finalaoicode,\n" +
                "  finalaoiid,\n" +
                "  gis_aoi_name,\n" +
                "  finalzc,\n" +
                "  gis_to_sys_groupid,\n" +
                "  gisaoisrc,\n" +
                "  tag1,\n" +
                "  tag2,\n" +
                "  tag3,\n" +
                "  bottomcorrected,\n" +
                "  r_aoi,\n" +
                "  key_word,\n" +
                "  key_tag,\n" +
                "  80_aoi_code,\n" +
                "  80_aoi_name,\n" +
                "  mapa_aoicode,\n" +
                "  gd_aoicode,\n" +
                "  splitresult,\n" +
                "  gj_aoicode_t,\n" +
                "  errortype,\n" +
                "  finalresult,\n" +
                "  case\n" +
                "    when (get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseephone') is not null and get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseephone') <>'') \n" +
                "    then get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseephone')\n" +
                "    when (get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseemobile') is not null and get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseemobile') <>'')\n" +
                "    then get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseemobile')\n" +
                "    else '' end as phone,\n" +
                "    inc_day\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      *,\n" +
                "      row_number() over(\n" +
                "        partition by if(\n" +
                "          gisaoisrc = 'norm',\n" +
                "          gis_to_sys_groupid,\n" +
                "          req_addresseeaddr\n" +
                "        ),80_aoi_code\n" +
                "        order by waybillno desc\n" +
                "      ) rank\n" +
                "    from\n" +
                "      dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and length(city_code) < 50\n" +
                "      and finalaoicode <> ''\n" +
                "      and gisaoisrc != 'chke_cur'\n" +
                "      and (\n" +
                "        80_aoi_code != ''\n" +
                "        and 80_aoi_code is not null\n" +
                "      )\n" +
                "      and finalaoicode != 80_aoi_code\n" +
                "      and city_code in ('557','555', '562', '527', '558', '554','566', '550', '516', '563', '564','518', '556', '552', '553', '561','551', '559', '052','088','311','352','354','357','374','376','377','396','398','411','412','418','421','427','452','455','457','458','468','469','475','482','483','514','517','519','523','530','531','532','535','536','539','546','570','572','574','575','577','591','598','631','635','662','668','692','710','713','715','717','730','743','744','745','753','756','770','774','796','799','855','870','874','875','876','877','883','887','898','911','930','933','936','953','970','979','8982','8983','025')\n" +
                "      and (\n" +
                "        finalzc RLIKE concat(city_code, 'D\\\\d{3}')\n" +
                "        OR finalzc RLIKE concat(city_code, 'DLD\\\\d{3}')\n" +
                "      )\n" +
                "      and finalresult = 'right'\n" +
                "      and errortype in ('norm', 'norm-reject')\n" +
                "      and tag2 not in(\n" +
                "        'info_in_gis',\n" +
                "        'correct_f',\n" +
                "        'correct_t1',\n" +
                "        '613_in_gis'\n" +
                "      )\n" +
                "  ) t\n" +
                "where\n" +
                "  t.rank = 1", date);
        JavaRDD<BottomcorrectedVillageAddr> rdd1 = DataUtil.loadData(spark, sc, sql1, BottomcorrectedVillageAddr.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd1 cnt:" + rdd1.count());

        String sql2 = String.format("select a.* from (\n" +
                "select\n" +
                "  waybillno,\n" +
                "  city_code,\n" +
                "  org_code,\n" +
                "  req_addresseeaddr,\n" +
                "  req_comp_name,\n" +
                "  finalaoicode,\n" +
                "  finalaoiid,\n" +
                "  gis_aoi_name,\n" +
                "  finalzc,\n" +
                "  gis_to_sys_groupid,\n" +
                "  gisaoisrc,\n" +
                "  tag1,\n" +
                "  tag2,\n" +
                "  tag3,\n" +
                "  bottomcorrected,\n" +
                "  r_aoi,\n" +
                "  key_word,\n" +
                "  key_tag,\n" +
                "  80_aoi_code,\n" +
                "  80_aoi_name,\n" +
                "  mapa_aoicode,\n" +
                "  gd_aoicode,\n" +
                "  splitresult,\n" +
                "  gj_aoicode_t,\n" +
                "  errortype,\n" +
                "  finalresult,\n" +
                "  case\n" +
                "    when (get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseephone') is not null and get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseephone') <>'') \n" +
                "    then get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseephone')\n" +
                "    when (get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseemobile') is not null and get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseemobile') <>'')\n" +
                "    then get_json_object(regexp_replace(req_waybillno, '\\\\\\\\', ''),'$.req_addresseemobile')\n" +
                "    else '' end as phone,\n" +
                "    inc_day\n" +
                "from\n" +
                "  (\n" +
                "    select\n" +
                "      *,\n" +
                "      row_number() over(\n" +
                "        partition by if(\n" +
                "          gisaoisrc = 'norm',\n" +
                "          gis_to_sys_groupid,\n" +
                "          req_addresseeaddr\n" +
                "        ),80_aoi_code\n" +
                "        order by waybillno desc\n" +
                "      ) rank\n" +
                "    from\n" +
                "      dm_gis.aoi_real_acctury_rate_judge_wrong_operation_bottomcorrected\n" +
                "    where\n" +
                "      inc_day = '%s'\n" +
                "      and length(city_code) < 50\n" +
                "      and finalaoicode <> ''\n" +
                "      and gisaoisrc != 'chke_cur'\n" +
                "      and (\n" +
                "        80_aoi_code != ''\n" +
                "        and 80_aoi_code is not null\n" +
                "      )\n" +
                "      and finalaoicode != 80_aoi_code\n" +
                "      and city_code in ('557','555', '562', '527', '558', '554','566', '550', '516', '563', '564','518', '556', '552', '553', '561','551', '559', '052','088','311','352','354','357','374','376','377','396','398','411','412','418','421','427','452','455','457','458','468','469','475','482','483','514','517','519','523','530','531','532','535','536','539','546','570','572','574','575','577','591','598','631','635','662','668','692','710','713','715','717','730','743','744','745','753','756','770','774','796','799','855','870','874','875','876','877','883','887','898','911','930','933','936','953','970','979','8982','8983','025')\n" +
                "      and finalresult = 'right'\n" +
                "      and errortype in ('norm', 'norm-reject')\n" +
                "      and tag2 not in(\n" +
                "        'info_in_gis',\n" +
                "        'correct_f',\n" +
                "        'correct_t1',\n" +
                "        '613_in_gis'\n" +
                "      )\n" +
                "  ) t\n" +
                "where\n" +
                "  t.rank = 1\n" +
                ") a join (select aoi_id from dm_gis.emap_district_village_aoi where inc_day ='%s' and class_code='220' and (aoi_id is not null and aoi_id <>'') group by aoi_id) b on a.finalaoiid = b.aoi_id", date, before3Date);
        JavaRDD<BottomcorrectedVillageAddr> rdd2 = DataUtil.loadData(spark, sc, sql2, BottomcorrectedVillageAddr.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd2 cnt:" + rdd2.count());

        JavaRDD<BottomcorrectedVillageAddr> unionRdd = rdd1.union(rdd2).mapToPair(o -> {
            String gisaoisrc = o.getGisaoisrc();
            String key = StringUtils.equals(gisaoisrc, "norm") ? (o.getGis_to_sys_groupid() + "_" + o.getAoi_code_80()) : (o.getReq_addresseeaddr() + "_" + o.getAoi_code_80());
            return new Tuple2<>(key, o);
        }).reduceByKey((o1, o2) -> o1).map(tp -> tp._2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("unionRdd cnt:" + unionRdd.count());
        rdd1.unpersist();
        rdd2.unpersist();

        logger.error("将关联上历史的数据剔除掉");
        JavaRDD<BottomcorrectedVillageAddr> normRdd = unionRdd.filter(o -> StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<BottomcorrectedVillageAddr> noEqNormRdd = unionRdd.filter(o -> !StringUtils.equals(o.getGisaoisrc(), "norm")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normRdd cnt:" + normRdd.count());
        logger.error("noEqNormRdd cnt:" + noEqNormRdd.count());
        unionRdd.unpersist();

        String before30Date = DateUtil.getDaysBefore(date, 30);
        String his_sql = String.format("select gisaoisrc,req_addresseeaddr,gis_to_sys_groupid from dm_gis.bottomcorrected_village_addr_misjudgment_correcte where inc_day between '%s' and '%s'", before30Date, date);
        JavaRDD<BottomcorrectedVillageAddr> hisRdd = DataUtil.loadData(spark, sc, his_sql, BottomcorrectedVillageAddr.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("hisRdd cnt:" + hisRdd.count());

        JavaRDD<BottomcorrectedVillageAddr> normLastRdd = normRdd.mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).leftOuterJoin(hisRdd.filter(o -> StringUtils.isNotEmpty(o.getGis_to_sys_groupid())).mapToPair(o -> new Tuple2<>(o.getGis_to_sys_groupid(), o)).reduceByKey((o1, o2) -> o1)).filter(tp -> {
            return tp._2._2 == null || !tp._2._2.isPresent();
        }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("normLastRdd cnt:" + normLastRdd.count());
        normRdd.unpersist();

        JavaRDD<BottomcorrectedVillageAddr> lastRdd = noEqNormRdd.mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr(), o)).leftOuterJoin(hisRdd.filter(o -> StringUtils.isNotEmpty(o.getReq_addresseeaddr())).mapToPair(o -> new Tuple2<>(o.getReq_addresseeaddr(), o)).reduceByKey((o1, o2) -> o1)).filter(tp -> {
            return tp._2._2 == null || !tp._2._2.isPresent();
        }).map(tp -> tp._2._1).union(normLastRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastRdd cnt:" + lastRdd.count());
        noEqNormRdd.unpersist();
        hisRdd.unpersist();
        normLastRdd.unpersist();

        return lastRdd;
    }
}
