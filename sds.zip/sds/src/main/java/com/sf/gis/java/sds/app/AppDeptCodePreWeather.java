package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.DeptCodePreWeatherController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 需求：异常天气数据统计
 * 需求方：段嫦慧（01425247）
 * 研发：匡仁衡（01399581）
 * 任务id:774520
 */
public class AppDeptCodePreWeather {
    private static Logger logger = LoggerFactory.getLogger(AppDeptCodePreWeather.class);

    public static void main(String[] args) {
        String date = args[0];
        String hour = args[1];
        String[] split = hour.split("#");
        hour = split[0] + " " + split[1];
        logger.error("date:{},hour:{}", date, hour);
        logger.error("run start");
        new DeptCodePreWeatherController().start(date, hour);
        logger.error("run end");
    }
}
