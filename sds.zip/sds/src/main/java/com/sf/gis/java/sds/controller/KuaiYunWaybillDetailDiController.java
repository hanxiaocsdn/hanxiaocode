package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.KeyInfo;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.constant.HttpConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.KuaiYunWaybillDetailDi;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import com.sf.gis.java.sds.utils.UrlUtil;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

public class KuaiYunWaybillDetailDiController implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(KuaiYunWaybillDetailDiController.class);
    public static String atdispatchliteUrl = "http://gis-rundata-gw.int.sfcloud.local:1080/atdispatch/api?address=%s&city=%s&ak=12797991c7e64fadb1272910d9d01aef&opt=norm";
    public static String precisionGdUrl = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?ak=c2ee00ecb0164098b58569b5bdffe60d&opt=gd2&address=%s&city=%s";
    public static String precisionMapaUrl = "http://gis-int2.int.sfdc.com.cn:1080/geo/api?ak=c2ee00ecb0164098b58569b5bdffe60d&opt=ma1&address=%s&city=%s";
    public static String coorUrl = "http://gis-int2.int.sfdc.com.cn:1080/efsms/checks_depot_data?sys_type=KY&lng=%s&lat=%s&ak=8cb19f422db34736922479ba0bc848f4";

    // ak每分钟限速 / 并发数
    private static int limitMin1 = 60000 / 100;

    // ak每秒钟限速 / 并发数
    private static int limitMin2 = 20000 / 100;

    public void start(String startDate, String endDate) {
        //初始化spark
//        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getName());
//        SparkSession spark = sparkInfo.getSession();
//        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = Spark.getSparkSession("KuaiYunWaybillDetailDiController", null, false, 2);
        JavaSparkContext sc = JavaSparkContext.fromSparkContext(spark.sparkContext());

        Set<Integer> acLimitCodeSet = Arrays.stream(HttpConstant.AC_LIMIT_CODE.split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCodeSet);

        String today = DateUtil.getDaysBefore(0, "yyyyMMdd");
        logger.error("today:{}", today);

        logger.error("取一个月内reTeamCode不为空的运单数据");
        JavaRDD<KuaiYunWaybillDetailDi> kuaiYunWaybillDetailDiRdd = loadData(spark, sc, startDate, endDate).map(o -> {
            String id = UUID.randomUUID().toString().replaceAll("-", "");
            o.setId(id);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("kuaiYunWaybillDetailDiRdd cnt:{}", kuaiYunWaybillDetailDiRdd.count());

        JavaRDD<KuaiYunWaybillDetailDi> addrRdd = kuaiYunWaybillDetailDiRdd.filter(o -> StringUtils.isNotEmpty(o.getReqAddress())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<KuaiYunWaybillDetailDi> empAddrRdd = kuaiYunWaybillDetailDiRdd.filter(o -> StringUtils.isEmpty(o.getReqAddress())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("addrRdd cnt:{}", addrRdd.count());
        logger.error("empAddrRdd cnt:{}", empAddrRdd.count());
        kuaiYunWaybillDetailDiRdd.unpersist();

        logger.error("跑at派服务,获取字段【key_word】、【aoiId】、【splitResult】");
        JavaRDD<KuaiYunWaybillDetailDi> atdispatchRdd = addrRdd.mapPartitions(iter -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<KuaiYunWaybillDetailDi> list = new ArrayList<>();
            while (iter.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin1) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin1, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                KuaiYunWaybillDetailDi o = iter.next();
                String reqAddress = o.getReqAddress();
                String citycode = o.getCitycode();
                if (StringUtils.isNotEmpty(reqAddress)) {
                    String content = run(atdispatchliteUrl, reqAddress, citycode, acLimitCodeSetBc.value());
                    if (StringUtils.isNotEmpty(content)) {
                        JSONObject jsonObject = JSON.parseObject(content);
                        if (jsonObject != null) {
                            if (jsonObject.getInteger("status") == 0) {
                                JSONObject result = jsonObject.getJSONObject("result");
                                JSONArray tcs = result.getJSONArray("tcs");
                                if (tcs.size() > 0) {
                                    JSONObject jsonObject1 = tcs.getJSONObject(0);
                                    String keyWord = jsonObject1.getString("keyWord");
                                    String aoiid = jsonObject1.getString("aoiid");
                                    logger.error("keyWord:{}", keyWord);
                                    logger.error("aoiid:{}", aoiid);
                                    o.setAoiid(aoiid);
                                }
                                JSONObject other = result.getJSONObject("other");
                                if (other != null) {
                                    JSONObject normresp = other.getJSONObject("normresp");
                                    if (normresp != null) {
                                        JSONObject result1 = normresp.getJSONObject("result");
                                        if (result1 != null) {
                                            String splitResult = result1.getString("splitResult");
                                            logger.error("splitResult:{}", splitResult);
                                            o.setSplitResult(splitResult);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                list.add(o);
            }
            return list.iterator();
        }).union(empAddrRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("atdispatchRdd cnt:{}", atdispatchRdd.count());
        addrRdd.unpersist();
        empAddrRdd.unpersist();

        logger.error("获取aoi,aoi_name信息");
        JavaPairRDD<String, CmsAoiSch> cmsAoiSchRdd = getCmsAoiSch(spark, sc).mapToPair(o -> new Tuple2<>(o.getAoi_id(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiSchRdd cnt:{}", cmsAoiSchRdd.count());

        logger.error("补充aoi_name");
        JavaRDD<KuaiYunWaybillDetailDi> noEmpAoiRdd = atdispatchRdd.filter(o -> StringUtils.isNotEmpty(o.getAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<KuaiYunWaybillDetailDi> empAoiRdd = atdispatchRdd.filter(o -> StringUtils.isEmpty(o.getAoiid())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpAoiRdd cnt:{}", noEmpAoiRdd.count());
        logger.error("empAoiRdd cnt:{}", empAoiRdd.count());
        atdispatchRdd.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> aoiNameRdd = noEmpAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoiid(), o))
                .leftOuterJoin(cmsAoiSchRdd)
                .map(tp -> {
                    KuaiYunWaybillDetailDi o = tp._2._1;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        CmsAoiSch cmsAoiSch = tp._2._2.get();
                        o.setAoiName(cmsAoiSch.getAoi_name());
                    }
                    return o;
                }).union(empAoiRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("aoiNameRdd cnt:{}", aoiNameRdd.count());
        noEmpAoiRdd.unpersist();
        empAoiRdd.unpersist();
        cmsAoiSchRdd.unpersist();

        logger.error("分词结果调提主体服务获取字段");
        JavaRDD<KuaiYunWaybillDetailDi> keyRdd = aoiNameRdd.map(o -> {
            String splitResult = o.getSplitResult();
            if (StringUtils.isNotEmpty(splitResult)) {
                KeyInfo keyInfo = new KeyInfo(splitResult.split(";")[0]);
                Map<String, String> keyResult = keyInfo.pick_key();
                String key_tag = keyResult.get("key_tag");
                String key_word = keyResult.get("key_word");
                o.setKey_tag(key_tag);
                o.setKey_word(key_word);
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("keyRdd cnt:{}", keyRdd.count());
        aoiNameRdd.unpersist();

        logger.error("计算【key_tag】+【key_word】以及对应【reTeamCode】的组合去重后的频次【count】");
        JavaRDD<KuaiYunWaybillDetailDi> keyNoEmpRdd = keyRdd.filter(o -> StringUtils.isNotEmpty(o.getKey_tag()) && StringUtils.isNotEmpty(o.getKey_word())).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<KuaiYunWaybillDetailDi> keyEmpRdd = keyRdd.filter(o -> !(StringUtils.isNotEmpty(o.getKey_tag()) && StringUtils.isNotEmpty(o.getKey_word()))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("keyNoEmpRdd cnt:{}", keyNoEmpRdd.count());
        logger.error("keyEmpRdd cnt:{}", keyEmpRdd.count());
        keyRdd.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> countRdd = keyNoEmpRdd.mapToPair(o -> new Tuple2<>(o.getKey_tag() + "_" + o.getKey_word(), o))
                .groupByKey()
                .flatMap(tp -> {
                    List<KuaiYunWaybillDetailDi> list = Lists.newArrayList(tp._2);
                    int size = list.stream()
                            .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(KuaiYunWaybillDetailDi::getReTeamCode))), ArrayList::new))
                            .size();
                    list = list.stream().peek(o -> {
                        o.setCount(size);
                    }).collect(Collectors.toList());
                    return list.iterator();
                }).union(keyEmpRdd).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("countRdd cnt:{}", countRdd.count());
        keyNoEmpRdd.unpersist();
        keyEmpRdd.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> eqRdd = countRdd.filter(o -> o.getCount() == 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<KuaiYunWaybillDetailDi> noEqRdd = countRdd.filter(o -> o.getCount() != 1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("eqRdd cnt:{}", eqRdd.count());
        logger.error("noEqRdd cnt:{}", noEqRdd.count());
        countRdd.unpersist();

        logger.error("存入标杆库tag记为无效");
        JavaRDD<KuaiYunWaybillDetailDi> lastNoEqRdd = noEqRdd.map(o -> {
            o.setTag("无效");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("lastNoEqRdd cnt:{}", lastNoEqRdd.count());
        noEqRdd.unpersist();

        String executeSql = "truncate table dm_gis.kuaiyun_wyabill_norm_di_from";
        logger.error("executeSql :{}", executeSql);
        spark.sql(executeSql);
        saveData(spark, lastNoEqRdd, today);
        lastNoEqRdd.unpersist();

        logger.error("调高德服务获取字段【gd_x】，【gd_y】，【precision_gd】");
        JavaRDD<KuaiYunWaybillDetailDi> gdRdd = eqRdd.map(o -> {
            String reqAddress = o.getReqAddress();
            String citycode = o.getCitycode();
            if (StringUtils.isNotEmpty(reqAddress)) {
                String content = run(precisionGdUrl, reqAddress, citycode, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        if (jsonObject.getInteger("status") == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            if (result != null) {
                                String xcoord = result.getString("xcoord");
                                String ycoord = result.getString("ycoord");
                                String precision = result.getString("precision");
                                logger.error("xcoord:{}", xcoord);
                                logger.error("ycoord:{}", ycoord);
                                logger.error("precision:{}", precision);
                                o.setGd_x(xcoord);
                                o.setGd_y(ycoord);
                                o.setPrecision_gd(precision);
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdRdd cnt:{}", gdRdd.count());
        eqRdd.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> gdPrecisionEq2 = gdRdd.filter(o -> StringUtils.isNotEmpty(o.getPrecision_gd()) && Double.parseDouble(o.getPrecision_gd()) == 2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<KuaiYunWaybillDetailDi> gdPrecisionNoEq2 = gdRdd.filter(o -> !(StringUtils.isNotEmpty(o.getPrecision_gd()) && Double.parseDouble(o.getPrecision_gd()) == 2)).map(o -> {
            o.setTag("无效");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdPrecisionEq2 cnt:{}", gdPrecisionEq2.count());
        logger.error("gdPrecisionNoEq2 cnt:{}", gdPrecisionNoEq2.count());
        gdRdd.unpersist();
        saveData(spark, gdPrecisionNoEq2, today);
        gdPrecisionNoEq2.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> gdTcRdd = gdPrecisionEq2.filter(o -> StringUtils.isNotEmpty(o.getGd_x()) && StringUtils.isNotEmpty(o.getGd_y())).mapPartitions(iter -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<KuaiYunWaybillDetailDi> list = new ArrayList<>();
            while (iter.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin2) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin2, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }

                try {
                    KuaiYunWaybillDetailDi o = iter.next();
                    String x = o.getGd_x();
                    String y = o.getGd_y();
                    if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                        String content = runTc(coorUrl, x, y, acLimitCodeSetBc.value());
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = JSON.parseObject(content);
                            if (jsonObject != null) {
                                if (jsonObject.getInteger("status") == 0) {
                                    JSONObject result = jsonObject.getJSONObject("result");
                                    if (result != null) {
                                        JSONArray map_data = result.getJSONArray("map_data");
                                        if (map_data != null) {
                                            if (map_data.size() > 0) {
                                                for (int i = 0; i < map_data.size(); i++) {
                                                    JSONObject jsonObject1 = map_data.getJSONObject(i);
                                                    String level = jsonObject1.getString("level");
                                                    String code = jsonObject1.getString("code");
                                                    logger.error("level:{}", level);
                                                    logger.error("code:{}", code);
                                                    if (StringUtils.equals(level, "3")) {
                                                        o.setGd_tc(code);
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    list.add(o);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return list.iterator();
        }).union(gdPrecisionEq2.filter(o -> !(StringUtils.isNotEmpty(o.getGd_x()) && StringUtils.isNotEmpty(o.getGd_y())))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("gdTcRdd cnt:{}", gdTcRdd.count());
        gdPrecisionEq2.unpersist();

        logger.error("调mapa服务获取字段【mapa_x】，【mapa_y】，【precision_mapa】");
        JavaRDD<KuaiYunWaybillDetailDi> mapaRdd = gdTcRdd.map(o -> {
            String reqAddress = o.getReqAddress();
            String citycode = o.getCitycode();
            if (StringUtils.isNotEmpty(reqAddress)) {
                String content = run(precisionMapaUrl, reqAddress, citycode, acLimitCodeSetBc.value());
                if (StringUtils.isNotEmpty(content)) {
                    JSONObject jsonObject = JSON.parseObject(content);
                    if (jsonObject != null) {
                        if (jsonObject.getInteger("status") == 0) {
                            JSONObject result = jsonObject.getJSONObject("result");
                            if (result != null) {
                                String xcoord = result.getString("xcoord");
                                String ycoord = result.getString("ycoord");
                                String precision = result.getString("precision");
                                logger.error("xcoord:{}", xcoord);
                                logger.error("ycoord:{}", ycoord);
                                logger.error("precision:{}", precision);
                                o.setMapa_x(xcoord);
                                o.setMapa_y(ycoord);
                                o.setPrecision_mapa(precision);
                            }
                        }
                    }
                }
            }
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("mapaRdd cnt:{}", mapaRdd.count());
        gdTcRdd.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> mapaPrecisionEq2 = mapaRdd.filter(o -> StringUtils.isNotEmpty(o.getPrecision_mapa()) && Double.valueOf(o.getPrecision_mapa()) == 2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<KuaiYunWaybillDetailDi> mapaPrecisionNoEq2 = mapaRdd.filter(o -> !(StringUtils.isNotEmpty(o.getPrecision_mapa()) && Double.valueOf(o.getPrecision_mapa()) == 2)).map(o -> {
            o.setTag("无效");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("mapaPrecisionEq2 cnt:{}", mapaPrecisionEq2.count());
        logger.error("mapaPrecisionNoEq2 cnt:{}", mapaPrecisionNoEq2.count());
        saveData(spark, mapaPrecisionNoEq2, today);
        mapaPrecisionNoEq2.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> mapaTcRdd = mapaPrecisionEq2.filter(o -> StringUtils.isNotEmpty(o.getMapa_x()) && StringUtils.isNotEmpty(o.getMapa_y())).mapPartitions(iter -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<KuaiYunWaybillDetailDi> list = new ArrayList<>();
            while (iter.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin2) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin2, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }

                try {
                    KuaiYunWaybillDetailDi o = iter.next();
                    String x = o.getMapa_x();
                    String y = o.getMapa_y();
                    if (StringUtils.isNotEmpty(x) && StringUtils.isNotEmpty(y)) {
                        String content = runTc(coorUrl, x, y, acLimitCodeSetBc.value());
                        if (StringUtils.isNotEmpty(content)) {
                            JSONObject jsonObject = JSON.parseObject(content);
                            if (jsonObject != null) {
                                if (jsonObject.getInteger("status") == 0) {
                                    JSONObject result = jsonObject.getJSONObject("result");
                                    if (result != null) {
                                        JSONArray map_data = result.getJSONArray("map_data");
                                        if (map_data != null) {
                                            if (map_data.size() > 0) {
                                                for (int i = 0; i < map_data.size(); i++) {
                                                    JSONObject jsonObject1 = map_data.getJSONObject(i);
                                                    String level = jsonObject1.getString("level");
                                                    String code = jsonObject1.getString("code");
                                                    logger.error("level:{}", level);
                                                    logger.error("code:{}", code);
                                                    if (StringUtils.equals(level, "3")) {
                                                        o.setMapa_tc(code);
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    list.add(o);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            return list.iterator();
        }).union(mapaPrecisionEq2.filter(o -> !(StringUtils.isNotEmpty(o.getMapa_x()) && StringUtils.isNotEmpty(o.getMapa_y())))).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("mapaTcRdd cnt:{}", mapaTcRdd.count());
        mapaPrecisionEq2.unpersist();

//        logger.error("将gd mapa关联");
//        JavaRDD<KuaiYunWaybillDetailDi> joinRdd = gdTcRdd.mapToPair(o -> new Tuple2<>(o.getId() + "_" + o.getReqWaybillNo(), o))
//                .leftOuterJoin(mapaTcRdd.mapToPair(o -> new Tuple2<>(o.getId() + "_" + o.getReqWaybillNo(), o)))
//                .map(tp -> {
//                    KuaiYunWaybillDetailDi o = tp._2._1;
//                    if (tp._2._2 != null && tp._2._2.isPresent()) {
//                        KuaiYunWaybillDetailDi kuaiYunWaybillDetailDi = tp._2._2.get();
//                        String mapa_tc = kuaiYunWaybillDetailDi.getMapa_tc();
//                        o.setMapa_tc(mapa_tc);
//                    }
//                    return o;
//                }).persist(StorageLevel.MEMORY_AND_DISK_SER());
//        logger.error("joinRdd cnt:{}", joinRdd.count());
//        joinRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
//        gdTcRdd.unpersist();
//        mapaTcRdd.unpersist();

        JavaRDD<KuaiYunWaybillDetailDi> finalEqRdd = mapaTcRdd.filter(o -> StringUtils.isNotEmpty(o.getGd_tc()) && StringUtils.isNotEmpty(o.getMapa_tc()) && StringUtils.equals(o.getGd_tc(), o.getMapa_tc()) && StringUtils.equals(o.getGd_tc(), o.getReTeamCode())).map(o -> {
            o.setTag("有效");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<KuaiYunWaybillDetailDi> finalNoEqRdd = mapaTcRdd.filter(o -> !(StringUtils.isNotEmpty(o.getGd_tc()) && StringUtils.isNotEmpty(o.getMapa_tc()) && StringUtils.equals(o.getGd_tc(), o.getMapa_tc()) && StringUtils.equals(o.getGd_tc(), o.getReTeamCode()))).map(o -> {
            o.setTag("无效");
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("finalEqRdd cnt:{}", finalEqRdd.count());
        logger.error("finalNoEqRdd cnt:{}", finalNoEqRdd.count());
        mapaTcRdd.unpersist();

        saveData(spark, finalNoEqRdd, today);
        finalNoEqRdd.unpersist();

        saveData(spark, finalEqRdd, today);
        finalEqRdd.unpersist();
        spark.stop();
    }

    public void saveData(SparkSession spark, JavaRDD<KuaiYunWaybillDetailDi> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getId(), o.getCitycode(), o.getKey_word() + "@" + o.getKey_tag(), o.getAoiid(), o.getAoiName(), o.getReTeamCode(), o.getTag(), o.getStatDate()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "md5", "citycode", "keyword", "aoiid", "aoiname", "tc", "status", "statdate"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "kuaiyun_wyabill_norm_di_from_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.kuaiyun_wyabill_norm_di_from";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s " +
                "select * from %s", targetTable, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public JavaRDD<KuaiYunWaybillDetailDi> loadData(SparkSession spark, JavaSparkContext sc, String startDate, String endDate) {
        String sql = SqlUtil.getSqlStr("tmp_kuaiyun_wyabill_detail_di.sql", startDate, endDate);
        logger.error("tmp_kuaiyun_wyabill_detail_di sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, KuaiYunWaybillDetailDi.class);
    }


    public JavaRDD<CmsAoiSch> getCmsAoiSch(SparkSession spark, JavaSparkContext sc) {
        String sql = "select aoi_id,aoi_name from dm_gis.cms_aoi_sch";
        logger.error("cms_aoi_sch sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CmsAoiSch.class);
    }

    public String run(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String runTc(String urlPattern, String x, String y, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, x, y);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }
}
