package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.ComputePartUtil;
import com.sf.gis.java.base.util.DataUtil;
import com.sf.gis.java.base.util.DateUtil;
import com.sf.gis.java.base.util.SparkUtil;
import com.sf.gis.java.sds.pojo.AoiRealAccturyRateJudgeWrongOperation;
import com.sf.gis.java.sds.pojo.CghsResultData;
import com.sf.gis.java.sds.pojo.KySbClear;
import com.sf.gis.java.sds.pojo.TcAoiRelationshipInitNewDi;
import com.sf.gis.java.sds.utils.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.types.DataType;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class KySbClearControlle2 implements Serializable {
    private static Logger logger = LoggerFactory.getLogger(KySbClearControlle2.class);

    // ak每分钟限速 / 并发数
    private static int limitMin3 = 2000 / 50;

    public void start(String date1, String date2) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        Broadcast<String> updateSbUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/ky/his/add?address=%s&cityCode=%s&ak=8cb19f422db34736922479ba0bc848f4&showserver=true&tc=%s&aoiId=%s");
        Broadcast<String> deleteSbUrlBc = sc.broadcast("http://gis-int2.int.sfdc.com.cn:1080/ky/his/del?ak=8cb19f422db34736922479ba0bc848f4&address=%s&cityCode=%s&showserver=true");
        Set<Integer> acLimitCode = Arrays.stream("109,110,111,112".split(",")).map(code -> Integer.valueOf(code.trim())).collect(Collectors.toSet());
        Broadcast<Set<Integer>> acLimitCodeSetBc = sc.broadcast(acLimitCode);

        String today = DateUtil.getDaysBefore(0, FixedConstant.DATE_FROMAT_YYYYMMDD_GAPLESS);
        String tomorrow = DateUtil.getDaysBefore(-1, FixedConstant.DATE_FROMAT_YYYYMMDD_GAPLESS);
        String beforeDay = DateUtil.getDaysBefore(31, FixedConstant.DATE_FROMAT_YYYYMMDD_GAPLESS);
        logger.error("today:{}, tomorrow:{}, beforeDay:{}", today, tomorrow, beforeDay);

        JavaRDD<KySbClear> kySbClearRdd = loadData(spark, sc, date1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("kySbClearRdd cnt:{}", kySbClearRdd.count());
        kySbClearRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<KySbClear> huiShouRdd = loadDataHuiShou(spark, sc, date2).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("huiShouRdd cnt:{}", huiShouRdd.count());
        huiShouRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

        JavaRDD<KySbClear> filterRdd = kySbClearRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o))
                .leftOuterJoin(huiShouRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1))
                .filter(tp -> {
                    boolean flag = true;
                    if (tp._2._2 != null && tp._2._2.isPresent()) {
                        flag = false;
                    }
                    return flag;
                }).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());
        filterRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
        kySbClearRdd.unpersist();
        huiShouRdd.unpersist();

        if (filterRdd.count() != 0) {
            JavaRDD<KySbClear> processRdd = sc.parallelize(filterRdd.take(3000)).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("processRdd cnt:{}", processRdd.count());
            filterRdd.unpersist();

            JavaRDD<KySbClear> deptRdd = processRdd.mapToPair(o -> new Tuple2<>(o.getZno_code(), o)).groupByKey().flatMap(tp -> {
                List<KySbClear> list = Lists.newArrayList(tp._2);
                List<KySbClear> lastList = new ArrayList<>();
                if (list.size() > 50) {
                    for (int i = 0; i < 50; i++) {
                        lastList.add(list.get(i));
                    }
                } else {
                    for (KySbClear kySbClear : list) {
                        lastList.add(kySbClear);
                    }
                }
                return lastList.iterator();
            });
            logger.error("deptRdd cnt:{}", deptRdd.count());
            deptRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            processRdd.unpersist();

            JavaRDD<AoiRealAccturyRateJudgeWrongOperation> shuntRdd = loadData(spark, sc, beforeDay, today).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("shuntRdd cnt:{}", shuntRdd.count());
            shuntRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<KySbClear> flagRdd = deptRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).leftOuterJoin(shuntRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
                KySbClear o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    o.setTempFlag("flag");
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            deptRdd.unpersist();
            shuntRdd.unpersist();

            JavaRDD<KySbClear> noEmptyRdd = flagRdd.filter(o -> StringUtils.isNotEmpty(o.getTempFlag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<KySbClear> emptyRdd = flagRdd.filter(o -> StringUtils.isEmpty(o.getTempFlag())).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("noEmptyRdd cnt:{}", noEmptyRdd.count());
            logger.error("emptyRdd cnt:{}", emptyRdd.count());
            flagRdd.unpersist();

            JavaRDD<CghsResultData> cghsResultRdd = loadCghsResultData(spark, sc, beforeDay, today).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("cghsResultRdd cnt:{}", cghsResultRdd.count());
            cghsResultRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<KySbClear> checkRdd = noEmptyRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).leftOuterJoin(cghsResultRdd.mapToPair(o -> new Tuple2<>(o.getAddress(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
                KySbClear o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    CghsResultData cghsResultData = tp._2._2.get();
                    o.setCheck_aoi_id(cghsResultData.getCheck_aoi_id());
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("checkRdd cnt:{}", checkRdd.count());
            noEmptyRdd.unpersist();
            cghsResultRdd.unpersist();

            JavaRDD<TcAoiRelationshipInitNewDi> tcAoiRelationshipInitNewDiRdd = loadData(spark, sc).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("tcAoiRelationshipInitNewDiRdd cnt:{}", tcAoiRelationshipInitNewDiRdd.count());
            tcAoiRelationshipInitNewDiRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));

            JavaRDD<KySbClear> checkTcRdd = checkRdd.mapToPair(o -> new Tuple2<>(o.getCheck_aoi_id(), o)).leftOuterJoin(tcAoiRelationshipInitNewDiRdd.mapToPair(o -> new Tuple2<>(o.getAoi(), o)).reduceByKey((o1, o2) -> o1)).map(tp -> {
                KySbClear o = tp._2._1;
                if (tp._2._2 != null && tp._2._2.isPresent()) {
                    TcAoiRelationshipInitNewDi tcAoiRelationshipInitNewDi = tp._2._2.get();
                    o.setCheck_tc(tcAoiRelationshipInitNewDi.getTccode());
                }
                return o;
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("checkTcRdd cnt:{}", checkTcRdd.count());
            checkTcRdd.take(1).forEach(o -> logger.error(JSON.toJSONString(o)));
            checkRdd.unpersist();
            tcAoiRelationshipInitNewDiRdd.unpersist();

            saveData(spark, checkTcRdd, date2);
            JavaRDD<KySbClear> update1Rdd = checkTcRdd.mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<KySbClear> list = new ArrayList<>();
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMin3) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin3, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    KySbClear o = itr.next();

                    String address = o.getAddress();
                    String city_code = o.getCity_code();
                    String check_aoi_id = o.getCheck_aoi_id();
                    String check_tc = o.getCheck_tc();
                    String content = updateSb(updateSbUrlBc.value(), address, city_code, check_tc, check_aoi_id, acLimitCodeSetBc.value());
                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("update1Rdd cnt:{}", update1Rdd.count());
            update1Rdd.unpersist();
            checkTcRdd.unpersist();

            JavaRDD<KySbClear> kyRdd = emptyRdd.filter(o -> StringUtils.isNotEmpty(o.getAddress()) && o.getAddress().contains("快运")).persist(StorageLevel.MEMORY_AND_DISK_SER());
            JavaRDD<KySbClear> noKyRdd = emptyRdd.filter(o -> !(StringUtils.isNotEmpty(o.getAddress()) && o.getAddress().contains("快运"))).persist(StorageLevel.MEMORY_AND_DISK_SER());
            logger.error("kyRdd cnt:{}", kyRdd.count());
            logger.error("noKyRdd cnt:{}", noKyRdd.count());
            emptyRdd.unpersist();

            saveData(spark, kyRdd, date2);
            JavaRDD<KySbClear> deleteRdd = kyRdd.mapPartitions(itr -> {
                int cnt = 0;
                long startTime = System.currentTimeMillis();
                List<KySbClear> list = new ArrayList<>();
                while (itr.hasNext()) {
                    cnt = cnt + 1;
                    if (cnt == limitMin3) {
                        long endTime = System.currentTimeMillis() - startTime;
                        if (endTime < 60000) {
                            logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin3, 60000 - endTime);
                            Thread.sleep(60000 - endTime);
                        }
                        startTime = System.currentTimeMillis();
                        cnt = 0;
                    }
                    KySbClear o = itr.next();

                    String address = o.getAddress();
                    String city_code = o.getCity_code();
                    String content = deleteSb(deleteSbUrlBc.value(), address, city_code, acLimitCodeSetBc.value());
                    list.add(o);
                }
                return list.iterator();
            }).persist(StorageLevel.MEMORY_AND_DISK_SER());
            deleteRdd.unpersist();
            kyRdd.unpersist();

            saveCgcsData(spark, noKyRdd, tomorrow);
            saveData(spark, noKyRdd, date2);
            noKyRdd.unpersist();
        } else {
            logger.error("☆☆☆☆☆☆☆☆快运审补数据已清理完毕!☆☆☆☆☆☆☆☆");
        }
        spark.stop();
    }

    public void saveData(SparkSession spark, JavaRDD<KySbClear> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getAddress(), o.getTag()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "address", "tag"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "kuaiyun_shenbu_clear_huishou_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.kuaiyun_shenbu_clear_huishou";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public void saveCgcsData(SparkSession spark, JavaRDD<KySbClear> inRdd, String date) {
        JavaRDD<Row> rows = inRdd.map(o -> {
            return RowFactory.create(
                    o.getCity_code(), o.getZno_code(), o.getAddress()
            );
        }).repartition(ComputePartUtil.computePart(inRdd.count() + 1));

        List<StructField> structFieldList = new ArrayList<>();
        String[] columnNames = new String[]{
                "city_code", "zno_code", "address"
        };
        DataType stringType = DataTypes.StringType;
        for (String columnName : columnNames) {
            structFieldList.add(DataTypes.createStructField(columnName, stringType, true));
        }
        StructType structType = DataTypes.createStructType(structFieldList);
        Dataset<Row> ds = spark.createDataFrame(rows, structType);
        String tempTable = "sxky_task_to_cgcs_" + System.currentTimeMillis();
        ds.createOrReplaceTempView(tempTable);
        String targetTable = "dm_gis.sxky_task_to_cgcs";
        logger.error("targetTable:{}", targetTable);
        spark.sql(String.format("insert into %s partition(inc_day = '%s')" +
                "select * from %s", targetTable, date, tempTable));
        spark.catalog().dropTempView(tempTable);

    }

    public JavaRDD<KySbClear> loadDataHuiShou(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select * from dm_gis.kuaiyun_shenbu_clear_huishou where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, KySbClear.class);
    }

    public JavaRDD<KySbClear> loadData(SparkSession spark, JavaSparkContext sc, String date) {
        String sql = String.format("select citycode,address,zno_code from dm_gis.kuaiyun_shenbu_clear where inc_day = '%s' and tag = '输出文件' and zno_code <>''", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, KySbClear.class);
    }

    public JavaRDD<AoiRealAccturyRateJudgeWrongOperation> loadData(SparkSession spark, JavaSparkContext sc, String beforeDay, String today) {
        String sql = String.format("select address from dm_gis.cgcss_misclassification_data_shunt where operate_date between '%s' and '%s'", beforeDay, today);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, AoiRealAccturyRateJudgeWrongOperation.class);
    }

    public JavaRDD<CghsResultData> loadCghsResultData(SparkSession spark, JavaSparkContext sc, String beforeDay, String today) {
        String sql = String.format("select address,check_aoi_id from dm_gis.cghs_result_data where inc_day between '%s' and '%s' and source in ('chkn_WRONG_AOI_PN', 'norm_WRONG_AOI_PN', 'norm_WRONG_AOI_SAME')", beforeDay, today);
        logger.error("cghs_result_data sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, CghsResultData.class);
    }

    public JavaRDD<TcAoiRelationshipInitNewDi> loadData(SparkSession spark, JavaSparkContext sc) {
        String sql = "select * from dm_gis.tcAoi_relationship_init_new_di";
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(spark, sc, sql, TcAoiRelationshipInitNewDi.class);
    }

    public String updateSb(String urlPattern, String address, String cityCode, String tc, String
            aoiId, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode, tc, aoiId);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public String deleteSb(String urlPattern, String address, String cityCode, Set<Integer> acLimitCodeSet) {
        String url = null;
        String content = "";
        try {
            url = String.format(urlPattern, URLEncoder.encode(address, "UTF-8"), cityCode);
            content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_THREE);
            if (org.apache.commons.lang.StringUtils.isEmpty(content)) {
                return content;
            }
            JSONObject json = JSON.parseObject(content);
            while (isAcTime(json, acLimitCodeSet)) {  //超配额，休眠后重试
                Thread.sleep(5000);
                content = UrlUtil.sendGet(url, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                json = JSON.parseObject(content);
            }
        } catch (Exception e) {
            logger.error("request error. url: {}", url);
            e.printStackTrace();
        }
        return content;
    }

    public boolean isAcTime(JSONObject json, Set<Integer> acLimitCodeSet) {
        int status = json.getInteger("status");
        if (status != 1) {
            return false;
        }
        try {
            JSONObject result = json.getJSONObject("result");
            String msg = result.getString("msg");
            Integer err = result.getInteger("err");
            return (err != null && acLimitCodeSet.contains(err)) && (msg != null && (msg.startsWith("访问限制,访问量已超过") || msg.startsWith("访问限制,服务访问过快")));
        } catch (Exception e) {
            logger.error("is ac time error, {}", json.toJSONString(), e);
            return false;
        }
    }
}
