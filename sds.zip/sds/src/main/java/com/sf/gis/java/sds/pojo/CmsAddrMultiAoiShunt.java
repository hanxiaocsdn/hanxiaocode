package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class CmsAddrMultiAoiShunt implements Serializable {
    @Column(name = "address")
    private String address;
    @Column(name = "address_id")
    private String address_id;
    @Column(name = "address_md5")
    private String address_md5;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoi_name")
    private String aoi_name;
    @Column(name = "type")
    private String type;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "extend_attach2")
    private String extend_attach2;
    @Column(name = "tag")
    private String tag;

    @Column(name = "aoi_type")
    private String aoi_type;
    @Column(name = "aoi_name_split")
    private String aoi_name_split;
    @Column(name = "aoi_name_new")
    private String aoi_name_new;
    @Column(name = "aoi_cnt")
    private String aoi_cnt;
    @Column(name = "type_cnt")
    private String type_cnt;
    @Column(name = "address_split")
    private String address_split;
    @Column(name = "split_contain")
    private String split_contain;

    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "city_code")
    private String city_code;

    public String getSplit_contain() {
        return split_contain;
    }

    public void setSplit_contain(String split_contain) {
        this.split_contain = split_contain;
    }

    public String getAddress_split() {
        return address_split;
    }

    public void setAddress_split(String address_split) {
        this.address_split = address_split;
    }

    public String getAoi_cnt() {
        return aoi_cnt;
    }

    public void setAoi_cnt(String aoi_cnt) {
        this.aoi_cnt = aoi_cnt;
    }

    public String getType_cnt() {
        return type_cnt;
    }

    public void setType_cnt(String type_cnt) {
        this.type_cnt = type_cnt;
    }

    public String getAoi_name_new() {
        return aoi_name_new;
    }

    public void setAoi_name_new(String aoi_name_new) {
        this.aoi_name_new = aoi_name_new;
    }

    public String getAoi_type() {
        return aoi_type;
    }

    public void setAoi_type(String aoi_type) {
        this.aoi_type = aoi_type;
    }

    public String getAoi_name_split() {
        return aoi_name_split;
    }

    public void setAoi_name_split(String aoi_name_split) {
        this.aoi_name_split = aoi_name_split;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress_id() {
        return address_id;
    }

    public void setAddress_id(String address_id) {
        this.address_id = address_id;
    }

    public String getAddress_md5() {
        return address_md5;
    }

    public void setAddress_md5(String address_md5) {
        this.address_md5 = address_md5;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getExtend_attach2() {
        return extend_attach2;
    }

    public void setExtend_attach2(String extend_attach2) {
        this.extend_attach2 = extend_attach2;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
