package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class VillageKdsmResStat implements Serializable {
    @Column(name = "area_code")
    private String area_code;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "zone_code")
    private String zone_code;
    @Column(name = "xzc_cnt")
    private String xzc_cnt;
    @Column(name = "valid_cnt")
    private String valid_cnt;
    @Column(name = "cover_rate")
    private String cover_rate;
    @Column(name = "inc_day")
    private String inc_day;

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getZone_code() {
        return zone_code;
    }

    public void setZone_code(String zone_code) {
        this.zone_code = zone_code;
    }

    public String getXzc_cnt() {
        return xzc_cnt;
    }

    public void setXzc_cnt(String xzc_cnt) {
        this.xzc_cnt = xzc_cnt;
    }

    public String getValid_cnt() {
        return valid_cnt;
    }

    public void setValid_cnt(String valid_cnt) {
        this.valid_cnt = valid_cnt;
    }

    public String getCover_rate() {
        return cover_rate;
    }

    public void setCover_rate(String cover_rate) {
        this.cover_rate = cover_rate;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
