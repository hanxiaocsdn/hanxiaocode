package com.sf.gis.java.sds.pojo.waybillaoi;

import javax.persistence.Column;
import javax.persistence.Table;

import java.io.Serializable;

@Table
public class CmsAoiSch implements Serializable, Comparable<CmsAoiSch> {
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "aoi_name")
    private String aoi_name;
    @Column(name = "aoi_code")
    private String aoi_code;
    @Column(name = "fa_type")
    private String fa_type;
    @Column(name = "zno_code")
    private String zno_code;

    private String similarity;
    private String jiti;
    private String aoi_count;

    private String sp_jiti;
    private String qd_jiti;
    private String dept_code;

    private String pick_wage_level;
    private String send_wage_level;
    private String subPickWageLevel;
    private String subSendWageLevel;

    private String pick_wage_aoi_id;
    private String send_wage_aoi_id;

    public String getPick_wage_level() {
        return pick_wage_level;
    }

    public void setPick_wage_level(String pick_wage_level) {
        this.pick_wage_level = pick_wage_level;
    }

    public String getSend_wage_level() {
        return send_wage_level;
    }

    public void setSend_wage_level(String send_wage_level) {
        this.send_wage_level = send_wage_level;
    }

    public String getSubPickWageLevel() {
        return subPickWageLevel;
    }

    public void setSubPickWageLevel(String subPickWageLevel) {
        this.subPickWageLevel = subPickWageLevel;
    }

    public String getSubSendWageLevel() {
        return subSendWageLevel;
    }

    public void setSubSendWageLevel(String subSendWageLevel) {
        this.subSendWageLevel = subSendWageLevel;
    }

    public String getPick_wage_aoi_id() {
        return pick_wage_aoi_id;
    }

    public void setPick_wage_aoi_id(String pick_wage_aoi_id) {
        this.pick_wage_aoi_id = pick_wage_aoi_id;
    }

    public String getSend_wage_aoi_id() {
        return send_wage_aoi_id;
    }

    public void setSend_wage_aoi_id(String send_wage_aoi_id) {
        this.send_wage_aoi_id = send_wage_aoi_id;
    }

    public String getZno_code() {
        return zno_code;
    }

    public void setZno_code(String zno_code) {
        this.zno_code = zno_code;
    }

    public String getDept_code() {
        return dept_code;
    }

    public void setDept_code(String dept_code) {
        this.dept_code = dept_code;
    }

    public String getSp_jiti() {
        return sp_jiti;
    }

    public void setSp_jiti(String sp_jiti) {
        this.sp_jiti = sp_jiti;
    }

    public String getQd_jiti() {
        return qd_jiti;
    }

    public void setQd_jiti(String qd_jiti) {
        this.qd_jiti = qd_jiti;
    }

    public String getAoi_count() {
        return aoi_count;
    }

    public void setAoi_count(String aoi_count) {
        this.aoi_count = aoi_count;
    }

    public String getJiti() {
        return jiti;
    }

    public void setJiti(String jiti) {
        this.jiti = jiti;
    }

    public String getSimilarity() {
        return similarity;
    }

    public void setSimilarity(String similarity) {
        this.similarity = similarity;
    }

    public String getFa_type() {
        return fa_type;
    }

    public void setFa_type(String fa_type) {
        this.fa_type = fa_type;
    }

    public String getAoi_code() {
        return aoi_code;
    }

    public void setAoi_code(String aoi_code) {
        this.aoi_code = aoi_code;
    }

    public String getAoi_name() {
        return aoi_name;
    }

    public void setAoi_name(String aoi_name) {
        this.aoi_name = aoi_name;
    }

    public String getAoi_id() {
        return aoi_id;
    }

    public void setAoi_id(String aoi_id) {
        this.aoi_id = aoi_id;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    @Override
    public int compareTo(CmsAoiSch o) {
        String aoi_count = this.getAoi_count();
        String aoi_count1 = o.getAoi_count();
        if (Integer.parseInt(aoi_count) > Integer.parseInt(aoi_count1)) {
            return 1;
        } else if (Integer.parseInt(aoi_count) < Integer.parseInt(aoi_count1)) {
            return -1;
        }
        return 0;
    }
}
