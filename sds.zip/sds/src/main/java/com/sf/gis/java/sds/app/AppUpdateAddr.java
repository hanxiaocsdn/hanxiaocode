package com.sf.gis.java.sds.app;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.UpdateAddr;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class AppUpdateAddr {
    private static Logger logger = LoggerFactory.getLogger(AppUpdateAddr.class);
    private static String updateStdAddrUrl = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/updateNormAddrTcZc";
    private static String updateSbAddrUrl = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/rgsbAdd";

    private static int limitMin = 3000 / 20;
    private static String account = "01399581";
    private static String taskId = "642785";
    private static String taskName = "按核实人工号更新库中aoi";

    /**
     * 需求：【壹竿项目-SD】按核实人工号更新库中aoi
     * 需求方：喻少丰(01424110)
     * 研发：匡仁衡（01399581）
     * 任务id：642785
     *
     * @param args
     */
    public static void main(String[] args) {
        String date = args[0];
        logger.error("date:{}", date);

        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark("AppUpdateAddr");

        JavaRDD<UpdateAddr> stdRdd = loadStdData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdRdd cnt:{}", stdRdd.count());

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, "642785", "按核实人工号更新库中aoi", "按核实人工号更新库中aoi", updateStdAddrUrl, "7577390e76cc40b6ad6542640edd9d84", stdRdd.count(), 20);
        JavaRDD<UpdateAddr> stdRespRdd = stdRdd.map(o -> {
            String opersouce = o.getOpersouce();
            String operusername = o.getOperusername();
            JSONObject param = new JSONObject();
            param.put("ak", "7577390e76cc40b6ad6542640edd9d84");
            param.put("operSource", opersouce);
            param.put("operUserName", operusername);

            JSONObject sub_param = new JSONObject();
            String citycode = o.getCitycode();
            String znocode = o.getZnocode();
            String addressid = o.getAddressid();
            String aoiid = o.getAoiid();
            String aoisource = o.getAoisource();
            sub_param.put("cityCode", citycode);
            sub_param.put("znoCode", znocode);
            sub_param.put("addressId", addressid);
            sub_param.put("aoiId", aoiid);
            sub_param.put("aoiSource", aoisource);
            param.put("addressUpdate", sub_param);

            String response = HttpInvokeUtil.sendPost(updateStdAddrUrl, param.toJSONString());
            o.setResponse(response);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("stdRespRdd cnt:{}", stdRespRdd.count());
        stdRespRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        stdRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);
        sparkInfo.getSession().sql(String.format("alter table dm_gis.update_addr_result drop if EXISTS partition(inc_day='%s')", date));
        DataUtil.saveInto(sparkInfo, "dm_gis.update_addr_result", UpdateAddr.class, stdRespRdd, "inc_day");
        stdRespRdd.unpersist();

        JavaRDD<UpdateAddr> sbRdd = loadSbData(sparkInfo, date).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sbRdd cnt:{}", sbRdd.count());

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(sparkInfo.getSession(), account, "642785", "按核实人工号更新库中aoi", "按核实人工号更新库中aoi", updateSbAddrUrl, "7577390e76cc40b6ad6542640edd9d84", sbRdd.count(), 20);
        JavaRDD<UpdateAddr> sbRespRdd = sbRdd.mapPartitions(itr -> {
            int cnt = 0;
            long startTime = System.currentTimeMillis();
            List<UpdateAddr> list = new ArrayList<>();
            while (itr.hasNext()) {
                cnt = cnt + 1;
                if (cnt == limitMin) {
                    long endTime = System.currentTimeMillis() - startTime;
                    if (endTime < 60000) {
                        logger.error("每分钟访问量超过限制:{},休眠:{}ms中", limitMin, 60000 - endTime);
                        Thread.sleep(60000 - endTime);
                    }
                    startTime = System.currentTimeMillis();
                    cnt = 0;
                }
                UpdateAddr o = itr.next();
                String opersouce = o.getOpersouce();
                String operusername = o.getOperusername();
                JSONObject param = new JSONObject();
                param.put("ak", "7577390e76cc40b6ad6542640edd9d84");
                param.put("operSource", opersouce);
                param.put("operUserName", operusername);

                JSONObject sub_param = new JSONObject();
                String citycode = o.getCitycode();
                String address = o.getAddress();
                String znocode = o.getZnocode();
                String aoiid = o.getAoiid();
                String aoisource = o.getAoisource();
                String unitid = o.getUnitid();
                String type = o.getType();
                if (StringUtils.equals(type, "0") || StringUtils.equals(type, "2") || StringUtils.isEmpty(type)) {
                    type = "2";
                } else if (StringUtils.equals(type, "1")) {
                    type = "1";
                }

                sub_param.put("cityCode", citycode);
                sub_param.put("address", address);
                sub_param.put("znoCode", znocode);
                sub_param.put("aoiId", aoiid);
                sub_param.put("aoiSource", aoisource);
                sub_param.put("unitId", unitid);
                sub_param.put("type", type);
                sub_param.put("src", "1");

                param.put("addressSave", sub_param);
                String response = HttpInvokeUtil.sendPost(updateSbAddrUrl, param.toJSONString());
                o.setResponse(response);
                list.add(o);
            }
            return list.iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sbRespRdd cnt:{}", sbRespRdd.count());
        sbRespRdd.take(2).forEach(o -> logger.error(JSON.toJSONString(o)));
        sbRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);

        DataUtil.saveInto(sparkInfo, "dm_gis.update_addr_result", UpdateAddr.class, sbRespRdd, "inc_day");
        sbRespRdd.unpersist();

        sparkInfo.getContext().stop();
        logger.error("process end");

    }

    public static JavaRDD<UpdateAddr> loadStdData(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.update_std_addr where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, UpdateAddr.class);
    }

    public static JavaRDD<UpdateAddr> loadSbData(SparkInfo si, String date) {
        String sql = String.format("select * from dm_gis.update_sb_addr where inc_day = '%s'", date);
        logger.error("sql: {}", sql);
        //加载数据
        return DataUtil.loadData(si, sql, UpdateAddr.class);
    }
}
