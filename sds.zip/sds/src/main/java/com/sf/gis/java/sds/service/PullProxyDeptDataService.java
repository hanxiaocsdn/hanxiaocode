package com.sf.gis.java.sds.service;


import com.sf.gis.java.sds.pojo.ProxyDept;
import com.sf.gis.scala.base.spark.Spark;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.List;

public class PullProxyDeptDataService implements Serializable {

    private static final Logger logger = LoggerFactory.getLogger(PullProxyDeptDataService.class);

    /**
     *
     */
    private static final long serialVersionUID = 8028863965782523787L;
    private SparkSession sparkSession;
    private String GIS_TOADDR_STAT_NEW = "dm_gis.gis_toaddr_stat_new2";

    public PullProxyDeptDataService() {
        sparkSession = Spark.getSparkSession(PullProxyDeptDataService.class.getSimpleName(), null, false, 2);
    }

    public void pullDataByDay(String[] dates) {
        for (String date : dates) {
            logger.error("date:" + date);
            try {
                parser(date);
            } catch (Exception e) {
                e.printStackTrace();
                logger.error("Exception:" + e.getMessage());
            }
        }
    }

    private void parser(String inc_day) throws Exception {
        String sql = "select inc_day,citycode,waybillno, address,log_gisdeptcode,zonecode,xiaoge_no,xiaoge_zonecode,"
                + "gis_to_sys_src,groupid" + " from " + GIS_TOADDR_STAT_NEW + " where inc_day ='" + inc_day + "' "
                + " and zonecode <> '' and zonecode <>'null' and log_gisdeptcode <> '' and log_gisdeptcode<> 'null' "
                + " and length(zonecode)>=7 "
                + " and zonecode regexp '[0-9]D[0-9]' and log_gisdeptcode not regexp '[0-9]D[0-9]'";
        logger.error(sql);
        JavaRDD<ProxyDept> dataRdd = sparkSession.sql(sql).javaRDD().persist(StorageLevel.MEMORY_AND_DISK_SER())
                .map(x -> new ProxyDept(x.getString(0), x.getString(1), x.getString(2), x.getString(3), x.getString(4),
                        x.getString(5), x.getString(6), x.getString(7), x.getString(8), x.getString(9)));
        save_to_db(dataRdd.collect(), inc_day);
        // parserAllData(city, dataRdd, ftpClient, configMap);
    }

    /**
     * 保存到数据库
     *
     * @throws Exception
     */
    private void save_to_db(List<ProxyDept> list, String inc_day) throws Exception {
        ProxyDeptDbService proxyDeptDbService = new ProxyDeptDbService();
        proxyDeptDbService.delete_day(inc_day);
        proxyDeptDbService.insertBatch(list);
    }

}