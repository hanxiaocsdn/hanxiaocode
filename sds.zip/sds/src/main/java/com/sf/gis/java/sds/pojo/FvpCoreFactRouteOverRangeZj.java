package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class FvpCoreFactRouteOverRangeZj implements Serializable {
    @Column(name = "mainwaybillno")
    private String mainwaybillno;
    @Column(name = "zonecode")
    private String zonecode;
    @Column(name = "provinct_name")
    private String provinct_name;
    @Column(name = "city_name")
    private String city_name;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "order_no")
    private String order_no;
    @Column(name = "order_id")
    private String order_id;
    @Column(name = "freight_monthly_acct_code")
    private String freight_monthly_acct_code;
    @Column(name = "src_sys_name")
    private String src_sys_name;
    @Column(name = "tt_inc_day")
    private String tt_inc_day;
    @Column(name = "if_contract")
    private String if_contract;
    @Column(name = "if_ziqu")
    private String if_ziqu;
    @Column(name = "inc_day")
    private String inc_day;

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getTt_inc_day() {
        return tt_inc_day;
    }

    public void setTt_inc_day(String tt_inc_day) {
        this.tt_inc_day = tt_inc_day;
    }

    public String getIf_contract() {
        return if_contract;
    }

    public void setIf_contract(String if_contract) {
        this.if_contract = if_contract;
    }

    public String getIf_ziqu() {
        return if_ziqu;
    }

    public void setIf_ziqu(String if_ziqu) {
        this.if_ziqu = if_ziqu;
    }

    public String getMainwaybillno() {
        return mainwaybillno;
    }

    public void setMainwaybillno(String mainwaybillno) {
        this.mainwaybillno = mainwaybillno;
    }

    public String getZonecode() {
        return zonecode;
    }

    public void setZonecode(String zonecode) {
        this.zonecode = zonecode;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getProvinct_name() {
        return provinct_name;
    }

    public void setProvinct_name(String provinct_name) {
        this.provinct_name = provinct_name;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public String getFreight_monthly_acct_code() {
        return freight_monthly_acct_code;
    }

    public void setFreight_monthly_acct_code(String freight_monthly_acct_code) {
        this.freight_monthly_acct_code = freight_monthly_acct_code;
    }

    public String getSrc_sys_name() {
        return src_sys_name;
    }

    public void setSrc_sys_name(String src_sys_name) {
        this.src_sys_name = src_sys_name;
    }
}
