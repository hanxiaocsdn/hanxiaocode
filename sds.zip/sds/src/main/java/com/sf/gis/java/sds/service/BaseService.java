package com.sf.gis.java.sds.service;

import com.sf.gis.java.sds.db.IDbManager;
import com.sf.gis.java.sds.db.ResultSetMapper;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class BaseService {
    public IDbManager dbManager;
    private static final Logger logger = LoggerFactory.getLogger(BaseService.class);

    public BaseService(IDbManager dbManager) {
        this.dbManager = dbManager;
    }
    public BaseService(SparkSession sparkSession) {
        this.sparkSession = sparkSession;
    }
    protected SparkSession sparkSession;
    public BaseService() {
    }
    @SuppressWarnings("rawtypes")
    public void excuBatch(List list, int batchSize, ExcuBatchListener listener) throws SQLException {
        // LogUtil.d(list.size());
        String sql = listener.createSql();
        logger.error(sql);
        Connection conn = null;
        try {
            conn = dbManager.getConnection();
            conn.setAutoCommit(false);
            PreparedStatement stmt = null;
            int i = 1;
            for (Object item : list) {
                if (i == 1) {
                    stmt = conn.prepareStatement(sql);
                }
                listener.prepareParameters(stmt, item);
                stmt.addBatch();
                if (i % batchSize == 0) {
                    stmt.executeBatch();
                    conn.commit();
                    logger.error("insert into :" + batchSize);
                    i = 1;
                    continue;
                }
                i++;
            }
            if (i > 1) {
                stmt.executeBatch();
                conn.commit();
                logger.error("insert into :" + (i - 1));
            }
        } catch (Exception e) {
            if (conn != null) {
                conn.rollback();
            }
            logger.error(e.getMessage());
        } finally {
            conn.close();
        }
    }

    public String crateIgnoreInsertSqlWithOutValue(String[] columns, String tableName) {
        StringBuilder sql = new StringBuilder("insert ignore into " + tableName + "(");
        for (String column : columns) {
            sql.append(column + ",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(") values(");
        for (@SuppressWarnings("unused") String column : columns) {
            sql.append("?,");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        return sql.toString();
    }

    public String crateInsertSqlWithOutValue(String[] columns, String tableName) {
        StringBuilder sql = new StringBuilder("insert into " + tableName + "(");
        for (String column : columns) {
            sql.append(column + ",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(") values(");
        for (@SuppressWarnings("unused") String column : columns) {
            sql.append("?,");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        return sql.toString();
    }

    public String crateSetSqlWithOutValue(String[] columns) {
        StringBuilder sql = new StringBuilder();
        for (String column : columns) {
            sql.append(column + "=?,");
        }
        sql.deleteCharAt(sql.length() - 1);
        return sql.toString();
    }

    public String crateInsertSqlWithValue(HashMap<String, Object> map, String[] columns, String tableName) {
        StringBuilder sql = new StringBuilder("insert into " + tableName + "(");
        for (String column : columns) {
            sql.append(column + ",");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(") values(");
        for (String column : columns) {
            sql.append("'" + map.get(column) + "',");
        }
        sql.deleteCharAt(sql.length() - 1);
        sql.append(")");
        return sql.toString();
    }

    @SuppressWarnings("rawtypes")
    public void excuMutilSqlBatch(List list, int batchSize, ExcuMutilSqlBatchListener listener) throws Exception {
        // LogUtil.d(list.size());
        Connection conn = null;
        try {
            conn = dbManager.getConnection();
            conn.setAutoCommit(false);
            Statement stmt = null;
            int i = 1;
            for (Object item : list) {
                if (stmt == null) {
                    stmt = conn.createStatement();
                }
                listener.addBatch(stmt, item);

                if (i % batchSize == 0) {
                    stmt.executeBatch();
                    conn.commit();
                    logger.error("sql excu  :" + batchSize);
                    stmt = null;
                    i = 1;
                    continue;
                }
                i++;
            }
            if (stmt != null) {
                stmt.executeBatch();
                conn.commit();
                stmt = null;
                logger.error("sql excu  :" + (i - 1));
            }
            conn.close();
        } catch (Exception e) {
            if (conn != null) {
                conn.rollback();
                conn.close();
            }
            logger.error(e.getMessage());
            throw e;
        }
    }

    @SuppressWarnings("rawtypes")
    public List queryList(Class<?> resultClass, QueryListener listener) {
        try (Connection conn = dbManager.getConnection();) {
            ResultSetMapper resultSetMapper = new ResultSetMapper();
            PreparedStatement ps = listener.prepareSql(conn);
            ResultSet resultSet = ps.executeQuery();
            List resultList = resultSetMapper.mapRersultSetToObject(resultSet, resultClass);
            resultSet.close();
            ps.close();
            return resultList;
        } catch (SQLException e) {
            e.printStackTrace();
            logger.error("Get deptcode mapper Error :" + e.getMessage());
        }
        return new ArrayList<>();
    }

    public interface QueryListener {
        public PreparedStatement prepareSql(Connection conn) throws SQLException;
    }

    public interface ExcuBatchListener {
        public String createSql();

        public void prepareParameters(PreparedStatement stmt, Object data) throws Exception;
    }

    public interface ExcuMutilSqlBatchListener {
        public void addBatch(Statement stmt, Object data) throws Exception;
    }
    protected long countBySql(String sql){
        Dataset<Row> gisSssDept = sparkSession
                .sql(sql);
        List<Row> tmp = gisSssDept.javaRDD().collect();
        return tmp.get(0).getLong(0);
    }
}
