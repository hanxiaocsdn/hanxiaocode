package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TbOrder implements Serializable {
    @Column(name = "order_category")
    private String order_category;
    @Column(name = "order_no")
    private String order_no;
    @Column(name = "order_time")
    private String order_time;
    @Column(name = "move_in_address")
    private String move_in_address;
    @Column(name = "move_out_address")
    private String move_out_address;
    @Column(name = "total_fee")
    private String total_fee;
    @Column(name = "actual_mileage_fee")
    private String actual_mileage_fee;
    @Column(name = "actual_order_payment")
    private String actual_order_payment;
    @Column(name = "place")
    private String place;
    @Column(name = "month_settlement_card")
    private String month_settlement_card;
    @Column(name = "company_name")
    private String company_name;
    @Column(name = "year")
    private String year;
    @Column(name = "vas_total")
    private String vas_total;
    @Column(name = "destination_city")
    private String destination_city;
    @Column(name = "total_weight")
    private String total_weight;
    @Column(name = "total_num")
    private String total_num;
    @Column(name = "customer_name")
    private String customer_name;
    @Column(name = "business_city")
    private String business_city;

    @Column(name = "place_citycode")
    private String place_citycode;
    @Column(name = "destination_citycode")
    private String destination_citycode;
    @Column(name = "move_in_address_new")
    private String move_in_address_new;
    @Column(name = "move_out_address_new")
    private String move_out_address_new;
    @Column(name = "move_in_address_aoi")
    private String move_in_address_aoi;
    @Column(name = "move_out_address_aoi")
    private String move_out_address_aoi;

    @Column(name = "inc_day")
    private String inc_day;

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getPlace_citycode() {
        return place_citycode;
    }

    public void setPlace_citycode(String place_citycode) {
        this.place_citycode = place_citycode;
    }

    public String getDestination_citycode() {
        return destination_citycode;
    }

    public void setDestination_citycode(String destination_citycode) {
        this.destination_citycode = destination_citycode;
    }

    public String getMove_in_address_new() {
        return move_in_address_new;
    }

    public void setMove_in_address_new(String move_in_address_new) {
        this.move_in_address_new = move_in_address_new;
    }

    public String getMove_out_address_new() {
        return move_out_address_new;
    }

    public void setMove_out_address_new(String move_out_address_new) {
        this.move_out_address_new = move_out_address_new;
    }

    public String getMove_out_address_aoi() {
        return move_out_address_aoi;
    }

    public void setMove_out_address_aoi(String move_out_address_aoi) {
        this.move_out_address_aoi = move_out_address_aoi;
    }

    public String getMove_in_address_aoi() {
        return move_in_address_aoi;
    }

    public void setMove_in_address_aoi(String move_in_address_aoi) {
        this.move_in_address_aoi = move_in_address_aoi;
    }

    public String getOrder_category() {
        return order_category;
    }

    public void setOrder_category(String order_category) {
        this.order_category = order_category;
    }

    public String getOrder_no() {
        return order_no;
    }

    public void setOrder_no(String order_no) {
        this.order_no = order_no;
    }

    public String getOrder_time() {
        return order_time;
    }

    public void setOrder_time(String order_time) {
        this.order_time = order_time;
    }

    public String getMove_in_address() {
        return move_in_address;
    }

    public void setMove_in_address(String move_in_address) {
        this.move_in_address = move_in_address;
    }

    public String getMove_out_address() {
        return move_out_address;
    }

    public void setMove_out_address(String move_out_address) {
        this.move_out_address = move_out_address;
    }

    public String getTotal_fee() {
        return total_fee;
    }

    public void setTotal_fee(String total_fee) {
        this.total_fee = total_fee;
    }

    public String getActual_mileage_fee() {
        return actual_mileage_fee;
    }

    public void setActual_mileage_fee(String actual_mileage_fee) {
        this.actual_mileage_fee = actual_mileage_fee;
    }

    public String getActual_order_payment() {
        return actual_order_payment;
    }

    public void setActual_order_payment(String actual_order_payment) {
        this.actual_order_payment = actual_order_payment;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getMonth_settlement_card() {
        return month_settlement_card;
    }

    public void setMonth_settlement_card(String month_settlement_card) {
        this.month_settlement_card = month_settlement_card;
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getVas_total() {
        return vas_total;
    }

    public void setVas_total(String vas_total) {
        this.vas_total = vas_total;
    }

    public String getDestination_city() {
        return destination_city;
    }

    public void setDestination_city(String destination_city) {
        this.destination_city = destination_city;
    }

    public String getTotal_weight() {
        return total_weight;
    }

    public void setTotal_weight(String total_weight) {
        this.total_weight = total_weight;
    }

    public String getTotal_num() {
        return total_num;
    }

    public void setTotal_num(String total_num) {
        this.total_num = total_num;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getBusiness_city() {
        return business_city;
    }

    public void setBusiness_city(String business_city) {
        this.business_city = business_city;
    }
}
