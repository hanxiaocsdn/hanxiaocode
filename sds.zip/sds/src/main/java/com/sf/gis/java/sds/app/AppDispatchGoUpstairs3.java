package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.DispatchGoUpstairsController3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AppDispatchGoUpstairs3 {
    private static Logger logger = LoggerFactory.getLogger(AppDispatchGoUpstairs3.class);

    public static void main(String[] args) {
        String startDate = args[0];
        String endDate = args[1];
        String nowdate = args[2];
        logger.error("startDate:{}, endDate:{}, nowdate:{}", startDate, endDate, nowdate);
        logger.error("run start");
        new DispatchGoUpstairsController3().start(startDate, endDate, nowdate);
        logger.error("run end");
    }
}
