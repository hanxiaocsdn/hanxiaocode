package com.sf.gis.java.sds.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.clearspring.analytics.util.Lists;
import com.sf.gis.java.base.constant.FixedConstant;
import com.sf.gis.java.base.dto.SparkInfo;
import com.sf.gis.java.base.util.*;
import com.sf.gis.java.sds.pojo.SjSameAddrIntoTelWhite;
import com.sf.gis.java.sds.pojo.waybillaoi.CmsAoiSch;
import org.apache.commons.lang3.StringUtils;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.storage.StorageLevel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import scala.Tuple2;

import java.io.Serializable;
import java.net.URLEncoder;
import java.util.*;
import java.util.stream.Collectors;

public class SjSameAddrIntoTelWhiteListController implements Serializable {
    private static String teltc = "http://gis-int.int.sfdc.com.cn:1080/teltc/whitelist/save";
    private static String rgsbadd = "http://gisasscmsbgintface.int.sfcloud.local:1080/cms/api/address/rgsbAdd";
    private static String byaddr = "http://gis-int2.int.sfdc.com.cn:1080/atconsignee/team/byaddr?address=%s&province=&cityName=&district=&city=%s&tel=&mobile=&company=&ak=3eb300d2e06947f7945cd02530a32fd2&opt=zh&callDispatch=1&isNotUnderCall=1&needAoiArea=1&contacts=";
    private static String account = "01399581";
    private static String taskId = "769766";
    private static String taskName = "收件下柯缺失的重复地址入电话白名单库";

    private static Logger logger = LoggerFactory.getLogger(SjSameAddrIntoTelWhiteListController.class);

    public void start(String date) {
        //初始化spark
        SparkInfo sparkInfo = SparkUtil.getSpark(this.getClass().getSimpleName());
        JavaSparkContext sc = sparkInfo.getContext();
        SparkSession spark = sparkInfo.getSession();

        String before1Day = DateUtil.getDaysBefore(date, 1);
        String before2Day = DateUtil.getDaysBefore(date, 2);
        String before32Day = DateUtil.getDaysBefore(date, 32);
        String before35Day = DateUtil.getDaysBefore(date, 35);

        String bsp_sql = String.format("select\n" +
                "  waybillno,\n" +
                "  city_code,\n" +
                "  org_code,\n" +
                "  userid,\n" +
                "  req_address,\n" +
                "  finalaoicode,\n" +
                "  gj_aoicode_t,\n" +
                "  tag1,\n" +
                "  tag2,\n" +
                "  r_aoi,\n" +
                "  isnotundercall,\n" +
                "  req_comp_name,\n" +
                "  finalzc,\n" +
                "  finalaoiid,\n" +
                "  groupid,\n" +
                "  extra\n" +
                "from\n" +
                "  dm_gis.aoi_accuracy_54_aoiname_ret_bsp\n" +
                "where\n" +
                "  inc_day between '%s'\n" +
                "  and '%s'\n" +
                "  and isnotundercall != '1'\n" +
                "  and get_json_object(extra, '$.aoisrc') = 'chke_cur' and zonecode = finalzc", before32Day, before2Day);

        JavaRDD<SjSameAddrIntoTelWhite> rdd = DataUtil.loadData(spark, sc, bsp_sql, SjSameAddrIntoTelWhite.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("rdd cnt:{}", rdd.count());

        JavaRDD<SjSameAddrIntoTelWhite> telRdd = rdd.map(o -> {
            String extra = o.getExtra();
            String tel = "";
            if (StringUtils.isNotEmpty(extra)) {
                String mobile = JSON.parseObject(extra).getString("mobile");
                if (StringUtils.isNotEmpty(mobile)) {
                    tel = mobile;
                } else {
                    tel = JSON.parseObject(extra).getString("phone");
                }
            }
            o.setTel(tel);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("telRdd cnt:{}", telRdd.count());
        rdd.unpersist();

        JavaRDD<SjSameAddrIntoTelWhite> sameAddrRdd = telRdd.mapToPair(o -> new Tuple2<>(o.getReq_address(), o)).groupByKey().filter(tp -> {
            List<SjSameAddrIntoTelWhite> list = Lists.newArrayList(tp._2);
            return list.size() > 1;
        }).flatMap(tp -> Lists.newArrayList(tp._2).iterator()).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("sameAddrRdd cnt:{}", sameAddrRdd.count());
        telRdd.unpersist();


        String omsfrom_sql = String.format("select\n" +
                "    address req_address\n" +
                "from\n" +
                "  dm_gis.gis_rds_omsfrom_press_result\n" +
                "where\n" +
                "  inc_day between '%s' and '%s' \n" +
                "  and flag = 'true'\n" +
                "union\n" +
                "select\n" +
                "    req_address\n" +
                "from\n" +
                "  dm_gis.gis_rds_omsfrom_telwhitelist_result\n" +
                "where\n" +
                "  inc_day between '20230615' and '%s'\n" +
                "  and result = 'success'", before35Day, date, before1Day);

        JavaPairRDD<String, SjSameAddrIntoTelWhite> omsfromAddrRdd = DataUtil.loadData(spark, sc, omsfrom_sql, SjSameAddrIntoTelWhite.class).mapToPair(o -> new Tuple2<>(o.getReq_address(), o)).reduceByKey((o1, o2) -> o1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("omsfromAddrRdd cnt:{}", omsfromAddrRdd.count());

        JavaRDD<SjSameAddrIntoTelWhite> filterRdd = sameAddrRdd.mapToPair(o -> new Tuple2<>(o.getReq_address(), o)).leftOuterJoin(omsfromAddrRdd).filter(tp -> tp._2._2 == null || !tp._2._2.isPresent()).map(tp -> tp._2._1).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("filterRdd cnt:{}", filterRdd.count());
        sameAddrRdd.unpersist();
        omsfromAddrRdd.unpersist();

        JavaRDD<SjSameAddrIntoTelWhite> correctnessRdd = filterRdd.map(o -> {
            String tag2 = o.getTag2();
            String correctness = "";
            if (Arrays.asList("correct_t1,monthAcc,613_in_gis,split14_in_gis,14_in_gis,info_in_gis,special_aoi,correct_f,mapa_gd_gj_54_gis,mapa_gd_gis,min_aoi_gj,multi_four_54,cms_correct,final_54,final_aoiname,bsp_correct,zy_correct,com_ph_correct,addr_correct,is_gd".split(",")).contains(tag2)) {
                correctness = "true";
            } else {
                if (StringUtils.equals(tag2, "step_45")) {
                    correctness = "unknown";
                } else {
                    correctness = "false";
                }
            }
            o.setCorrectness(correctness);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("correctnessRdd cnt:{}", correctnessRdd.count());
        filterRdd.unpersist();

        JavaRDD<SjSameAddrIntoTelWhite> tagRdd = correctnessRdd.mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getTel(), o)).groupByKey().flatMap(tp -> {
            List<SjSameAddrIntoTelWhite> list = Lists.newArrayList(tp._2);
            String tag = "";
            if (judge(list)) {
                tag = "unique";
            } else {
                tag = "other";
            }
            String finalTag = tag;
            return list.stream().peek(o -> o.setTag(finalTag)).collect(Collectors.toList()).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tagRdd cnt:{}", tagRdd.count());
        correctnessRdd.unpersist();

        JavaRDD<SjSameAddrIntoTelWhite> uniqueRdd = tagRdd.filter(o -> StringUtils.equals(o.getTag(), "unique")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SjSameAddrIntoTelWhite> otherRdd = tagRdd.filter(o -> StringUtils.equals(o.getTag(), "other")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueRdd cnt:{}", uniqueRdd.count());
        logger.error("otherRdd cnt:{}", otherRdd.count());
        tagRdd.unpersist();

        String id1 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", teltc, "3847482cb9844067b0e41767e1acf01f", uniqueRdd.count(), 10);
        JavaRDD<SjSameAddrIntoTelWhite> uniqueResponseRdd = uniqueRdd.mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getTel(), o)).groupByKey().flatMap(tp -> {
            List<SjSameAddrIntoTelWhite> list = Lists.newArrayList(tp._2);
            List<SjSameAddrIntoTelWhite> addrTelList = list.stream().peek(o -> o.setGongyi("AddrTel")).collect(Collectors.toList());

            SjSameAddrIntoTelWhite sjSameAddrIntoTelWhite = addrTelList.get(0);
            String city_code = sjSameAddrIntoTelWhite.getCity_code();
            String req_address = sjSameAddrIntoTelWhite.getReq_address();
            String finalzc = sjSameAddrIntoTelWhite.getFinalzc();
            String tel = sjSameAddrIntoTelWhite.getTel();
            String finalaoiid = sjSameAddrIntoTelWhite.getFinalaoiid();
            String finalaoicode = sjSameAddrIntoTelWhite.getFinalaoicode();

            JSONObject param = new JSONObject();
            param.put("city", city_code);
            param.put("ak", "3847482cb9844067b0e41767e1acf01f");

            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("address", req_address);
            jsonObject.put("citycode", city_code);
            jsonObject.put("deptcode", finalzc);
            jsonObject.put("tel", tel);
            jsonObject.put("aoiId", finalaoiid);
            jsonObject.put("aoiCode", finalaoicode);
            jsonArray.add(jsonObject);
            param.put("dataList", jsonArray);
            String result = "";
            String response = HttpInvokeUtil.sendPost(teltc, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
            if (StringUtils.isNotEmpty(response)) {
                int status = JSON.parseObject(response).getInteger("status");
                if (status == 0) {
                    result = "success";
                }
            }

            String finalResult = result;
            return addrTelList.stream().map(o -> {
                o.setTeltc_response(response);
                o.setResult(finalResult);
                return o;
            }).collect(Collectors.toList()).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("uniqueResponseRdd cnt:{}", uniqueResponseRdd.count());
        uniqueRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id1);

        String cms_aoi_sql = String.format("select aoi_code,aoi_id,zno_code from dm_gis.cms_aoi where inc_day = '%s'", before1Day);
        JavaRDD<CmsAoiSch> cmsAoiRdd = DataUtil.loadData(spark, sc, cms_aoi_sql, CmsAoiSch.class).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("cmsAoiRdd cnt:{}", cmsAoiRdd.count());


        JavaRDD<SjSameAddrIntoTelWhite> tempFlagRdd = otherRdd.mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getTel(), o)).groupByKey().flatMap(tp -> {
            List<SjSameAddrIntoTelWhite> list = Lists.newArrayList(tp._2);

            long cnt = list.stream().filter(o -> StringUtils.isNotEmpty(o.getR_aoi())).map(SjSameAddrIntoTelWhite::getR_aoi).distinct().count();
            String temp_flag = "";
            if (cnt == 1) {
                temp_flag = "1";
            } else {
                temp_flag = "0";
            }
            String finalTemp_flag = temp_flag;
            return list.stream().peek(o -> o.setTemp_flag(finalTemp_flag)).collect(Collectors.toList()).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("tempFlagRdd cnt:{}", tempFlagRdd.count());
        otherRdd.unpersist();

        JavaRDD<SjSameAddrIntoTelWhite> noEmpRaoiRdd = tempFlagRdd.filter(o -> StringUtils.equals(o.getTemp_flag(), "1")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        JavaRDD<SjSameAddrIntoTelWhite> empRaoiRdd = tempFlagRdd.filter(o -> StringUtils.equals(o.getTemp_flag(), "0")).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpRaoiRdd cnt:{}", noEmpRaoiRdd.count());
        logger.error("empRaoiRdd cnt:{}", empRaoiRdd.count());
        tempFlagRdd.unpersist();

        String id2 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", teltc, "3847482cb9844067b0e41767e1acf01f", noEmpRaoiRdd.count(), 10);
        String id3 = BdpTaskRecordUtil.startRunNetworkInterface(spark, account, taskId, taskName, "", rgsbadd, "7577390e76cc40b6ad6542640edd9d84", noEmpRaoiRdd.count(), 10);
        JavaRDD<SjSameAddrIntoTelWhite> noEmpRaoiResponseRdd = noEmpRaoiRdd.mapToPair(o -> new Tuple2<>(o.getR_aoi(), o)).leftOuterJoin(cmsAoiRdd.mapToPair(o -> new Tuple2<>(o.getAoi_code(), o))).map(tp -> {
            SjSameAddrIntoTelWhite o = tp._2._1;
            if (tp._2._2 != null && tp._2._2.isPresent()) {
                CmsAoiSch cmsAoiSch = tp._2._2.get();
                o.setR_aoiid(cmsAoiSch.getAoi_id());
                o.setR_zc(cmsAoiSch.getZno_code());
            }
            return o;
        }).mapToPair(o -> new Tuple2<>(o.getReq_address() + "_" + o.getTel(), o)).groupByKey().flatMap(tp -> {
            List<SjSameAddrIntoTelWhite> list = Lists.newArrayList(tp._2);

            SjSameAddrIntoTelWhite o = list.get(0);
            String city_code = o.getCity_code();
            String req_address = o.getReq_address();
            String r_zc = o.getR_zc();
            String r_aoiid = o.getR_aoiid();

            String aoi = "";
            if (!(StringUtils.isNotEmpty(req_address) && (req_address.endsWith("工业园") || req_address.endsWith("工业区") || req_address.endsWith("工业园区") || req_address.endsWith("街") || req_address.endsWith("段") || req_address.endsWith("路") ||
                    req_address.endsWith("驻地") || req_address.endsWith("经济开发区") || req_address.endsWith("产业园") || req_address.endsWith("国际商贸城") || req_address.endsWith("直发基地") || req_address.endsWith("基地") ||
                    req_address.endsWith("顺丰速运") || req_address.endsWith("顺丰快递") || req_address.endsWith("顺丰")))) {

                aoi = getAoi(city_code, req_address);
                if (StringUtils.isEmpty(aoi)) {

                    String rgsb_response = getResult(city_code, req_address, r_zc, r_aoiid);
                    if (StringUtils.isNotEmpty(rgsb_response)) {
                        Boolean success = JSON.parseObject(rgsb_response).getBoolean("success");
                        if (success) {
                            String addressMd5 = JSON.parseObject(rgsb_response).getJSONObject("data").getString("addressMd5");
                            String finalAoi1 = aoi;
                            return list.stream().peek(t -> {
                                t.setGongyi("Press_raoi");
                                t.setRgsbadd_response(rgsb_response);
                                t.setResult("success");
                                t.setPress_groupid(addressMd5);
                                t.setCheck_aoi(finalAoi1);
                            }).collect(Collectors.toList()).iterator();
                        }
                    }
                }
            } else {
                String req_comp_name = o.getReq_comp_name();
                if (StringUtils.isNotEmpty(req_comp_name) && req_comp_name.length() > 3) {
                    aoi = getAoi(city_code, req_address + req_comp_name);
                    if (StringUtils.isEmpty(aoi)) {
                        String rgsb_response = getResult(city_code, req_address + req_comp_name, r_zc, r_aoiid);
                        if (StringUtils.isNotEmpty(rgsb_response)) {
                            Boolean success = JSON.parseObject(rgsb_response).getBoolean("success");
                            if (success) {
                                String addressMd5 = JSON.parseObject(rgsb_response).getJSONObject("data").getString("addressMd5");
                                String finalAoi2 = aoi;
                                return list.stream().peek(t -> {
                                    t.setGongyi("Press_raoi");
                                    t.setRgsbadd_response(rgsb_response);
                                    t.setResult("success");
                                    t.setPress_groupid(addressMd5);
                                    t.setCheck_aoi(finalAoi2);
                                }).collect(Collectors.toList()).iterator();
                            }
                        }
                    }
                }
            }

            String tel = o.getTel();
            String r_aoi = o.getR_aoi();

            JSONObject param_2 = new JSONObject();
            param_2.put("city", city_code);
            param_2.put("ak", "3847482cb9844067b0e41767e1acf01f");

            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObject_2 = new JSONObject();
            jsonObject_2.put("address", req_address);
            jsonObject_2.put("citycode", city_code);
            jsonObject_2.put("deptcode", r_zc);
            jsonObject_2.put("tel", tel);
            jsonObject_2.put("aoiId", r_aoiid);
            jsonObject_2.put("aoiCode", r_aoi);
            jsonArray.add(jsonObject_2);
            param_2.put("dataList", jsonArray);
            String tel_response = HttpInvokeUtil.sendPost(teltc, param_2.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
            String result = "";
            if (StringUtils.isNotEmpty(tel_response)) {
                int status = JSON.parseObject(tel_response).getInteger("status");
                if (status == 0) {
                    result = "success";
                }
            }

            String finalResult = result;
            String finalAoi = aoi;
            return list.stream().peek(t -> {
                t.setGongyi("AddrTel_raoi");
                t.setTeltc_response(tel_response);
                t.setResult(finalResult);
                t.setCheck_aoi(finalAoi);
            }).iterator();
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("noEmpRaoiResponseRdd cnt:{}", noEmpRaoiResponseRdd.count());
        noEmpRaoiRdd.unpersist();
        cmsAoiRdd.unpersist();
        BdpTaskRecordUtil.endNetworkInterface(account, id2);
        BdpTaskRecordUtil.endNetworkInterface(account, id3);

        JavaRDD<SjSameAddrIntoTelWhite> resultRdd = uniqueResponseRdd.union(noEmpRaoiResponseRdd).union(empRaoiRdd).map(o -> {
            o.setInc_day(date);
            return o;
        }).persist(StorageLevel.MEMORY_AND_DISK_SER());
        logger.error("resultRdd cnt:{}", resultRdd.count());
        uniqueResponseRdd.unpersist();
        noEmpRaoiResponseRdd.unpersist();
        empRaoiRdd.unpersist();

        DataUtil.saveOverwrite(spark, sc, "dm_gis.gis_rds_omsfrom_telwhitelist_result", SjSameAddrIntoTelWhite.class, resultRdd, "inc_day");
        resultRdd.unpersist();
        sc.stop();
    }

    public boolean judge(List<SjSameAddrIntoTelWhite> list) {
        int finalzc_size = list.stream().filter(o -> StringUtils.isNotEmpty(o.getFinalzc()))
                .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(SjSameAddrIntoTelWhite::getFinalzc))), ArrayList::new))
                .size();

        int finalaoicode_size = list.stream().filter(o -> StringUtils.isNotEmpty(o.getFinalaoicode()))
                .collect(Collectors.collectingAndThen(Collectors.toCollection(() -> new TreeSet<>(Comparator.comparing(SjSameAddrIntoTelWhite::getFinalaoicode))), ArrayList::new))
                .size();

        int allCount = list.size();
        int trueCount = list.stream().filter(o -> StringUtils.equals(o.getCorrectness(), "true")).collect(Collectors.toList()).size();
        int unknownCount = list.stream().filter(o -> StringUtils.equals(o.getCorrectness(), "unknown")).collect(Collectors.toList()).size();

        if (finalzc_size == 1 && finalaoicode_size == 1 && (allCount == trueCount || (trueCount >= 1 && (trueCount + unknownCount) == allCount))) {
            return true;
        }
        return false;
    }

    public String getResult(String city_code, String req_address, String r_zc, String r_aoiid) {
        JSONObject param = new JSONObject();
        param.put("ak", "7577390e76cc40b6ad6542640edd9d84");
        param.put("operSource", "Press-raoi");
        param.put("operUserName", "01421176");

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("cityCode", city_code);
        jsonObject.put("address", req_address);
        jsonObject.put("znoCode", r_zc);
        jsonObject.put("aoiId", r_aoiid);
        jsonObject.put("type", "1");
        jsonObject.put("src", "1");
        param.put("addressSave", jsonObject);

        return HttpInvokeUtil.sendPost(rgsbadd, param.toJSONString(), FixedConstant.MAX_TRY_TIME_ONCE);
    }

    public String getAoi(String city_code, String addr) {
        String aoi = "";
        try {
            if (StringUtils.isNotEmpty(addr)) {
                String req = String.format(byaddr, URLEncoder.encode(addr, "UTF-8"), city_code);
                String content = HttpInvokeUtil.sendGet(req, "UTF-8", FixedConstant.MAX_TRY_TIME_ONCE);
                aoi = JSON.parseObject(content).getJSONObject("result").getJSONArray("tcs").getJSONObject(0).getString("aoiid");
                logger.error("aoi:{}", aoi);
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return aoi;
    }

}
