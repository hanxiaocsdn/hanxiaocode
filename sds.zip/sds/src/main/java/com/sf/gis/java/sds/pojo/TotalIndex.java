package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TotalIndex implements Serializable {
    @Column(name = "task_area_code")
    private String task_area_code;
    @Column(name = "task_area_name")
    private String task_area_name;
    @Column(name = "line_area")
    private String line_area;
    @Column(name = "line_code")
    private String line_code;
    @Column(name = "inc_month")
    private String inc_month;
    @Column(name = "day")
    private String day;
    @Column(name = "inc_day")
    private String inc_day;
    @Column(name = "task_id")
    private String task_id;
    @Column(name = "conduct_type")
    private String conduct_type;
    @Column(name = "is_db")
    private String is_db;
    @Column(name = "actual_run_time")
    private String actual_run_time;
    @Column(name = "diff_etc_tolls")
    private String diff_etc_tolls;


    private int task_count;
    private int exe_count;
    private int exe_count_1;
    private int exe_count_2;
    private int no_exe_count;
    private int db_count;
    private int exe_db_count;
    private int exe_db_count_1;
    private int exe_db_count_2;
    private int noexe_db_count;
    private double save_money;
    private double time;
    private double exe_time;
    private double exe_time_1;
    private double exe_time_2;
    private double noexe_time;

    private String stat_type;
    private String stat_type_content;

    public String getStat_type() {
        return stat_type;
    }

    public void setStat_type(String stat_type) {
        this.stat_type = stat_type;
    }

    public String getStat_type_content() {
        return stat_type_content;
    }

    public void setStat_type_content(String stat_type_content) {
        this.stat_type_content = stat_type_content;
    }

    public int getTask_count() {
        return task_count;
    }

    public void setTask_count(int task_count) {
        this.task_count = task_count;
    }

    public int getExe_count() {
        return exe_count;
    }

    public void setExe_count(int exe_count) {
        this.exe_count = exe_count;
    }

    public int getExe_count_1() {
        return exe_count_1;
    }

    public void setExe_count_1(int exe_count_1) {
        this.exe_count_1 = exe_count_1;
    }

    public int getExe_count_2() {
        return exe_count_2;
    }

    public void setExe_count_2(int exe_count_2) {
        this.exe_count_2 = exe_count_2;
    }

    public int getNo_exe_count() {
        return no_exe_count;
    }

    public void setNo_exe_count(int no_exe_count) {
        this.no_exe_count = no_exe_count;
    }

    public int getDb_count() {
        return db_count;
    }

    public void setDb_count(int db_count) {
        this.db_count = db_count;
    }

    public int getExe_db_count() {
        return exe_db_count;
    }

    public void setExe_db_count(int exe_db_count) {
        this.exe_db_count = exe_db_count;
    }

    public int getExe_db_count_1() {
        return exe_db_count_1;
    }

    public void setExe_db_count_1(int exe_db_count_1) {
        this.exe_db_count_1 = exe_db_count_1;
    }

    public int getExe_db_count_2() {
        return exe_db_count_2;
    }

    public void setExe_db_count_2(int exe_db_count_2) {
        this.exe_db_count_2 = exe_db_count_2;
    }

    public int getNoexe_db_count() {
        return noexe_db_count;
    }

    public void setNoexe_db_count(int noexe_db_count) {
        this.noexe_db_count = noexe_db_count;
    }

    public double getSave_money() {
        return save_money;
    }

    public void setSave_money(double save_money) {
        this.save_money = save_money;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getExe_time() {
        return exe_time;
    }

    public void setExe_time(double exe_time) {
        this.exe_time = exe_time;
    }

    public double getExe_time_1() {
        return exe_time_1;
    }

    public void setExe_time_1(double exe_time_1) {
        this.exe_time_1 = exe_time_1;
    }

    public double getExe_time_2() {
        return exe_time_2;
    }

    public void setExe_time_2(double exe_time_2) {
        this.exe_time_2 = exe_time_2;
    }

    public double getNoexe_time() {
        return noexe_time;
    }

    public void setNoexe_time(double noexe_time) {
        this.noexe_time = noexe_time;
    }

    public String getDiff_etc_tolls() {
        return diff_etc_tolls;
    }

    public void setDiff_etc_tolls(String diff_etc_tolls) {
        this.diff_etc_tolls = diff_etc_tolls;
    }

    public String getTask_area_code() {
        return task_area_code;
    }

    public void setTask_area_code(String task_area_code) {
        this.task_area_code = task_area_code;
    }

    public String getTask_area_name() {
        return task_area_name;
    }

    public void setTask_area_name(String task_area_name) {
        this.task_area_name = task_area_name;
    }

    public String getLine_area() {
        return line_area;
    }

    public void setLine_area(String line_area) {
        this.line_area = line_area;
    }

    public String getLine_code() {
        return line_code;
    }

    public void setLine_code(String line_code) {
        this.line_code = line_code;
    }

    public String getInc_month() {
        return inc_month;
    }

    public void setInc_month(String inc_month) {
        this.inc_month = inc_month;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getTask_id() {
        return task_id;
    }

    public void setTask_id(String task_id) {
        this.task_id = task_id;
    }

    public String getConduct_type() {
        return conduct_type;
    }

    public void setConduct_type(String conduct_type) {
        this.conduct_type = conduct_type;
    }

    public String getIs_db() {
        return is_db;
    }

    public void setIs_db(String is_db) {
        this.is_db = is_db;
    }

    public String getActual_run_time() {
        return actual_run_time;
    }

    public void setActual_run_time(String actual_run_time) {
        this.actual_run_time = actual_run_time;
    }
}
