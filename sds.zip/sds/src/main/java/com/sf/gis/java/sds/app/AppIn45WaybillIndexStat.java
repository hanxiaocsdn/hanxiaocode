package com.sf.gis.java.sds.app;

import com.sf.gis.java.sds.controller.In45WaybillIndexStatController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class AppIn45WaybillIndexStat {
    private static Logger logger = LoggerFactory.getLogger(AppIn45WaybillIndexStat.class);


    public static void main(String[] args) {
        String date1 = args[0];
        String date2 = args[1];
        logger.error("date1:{},date2:{}", date1, date2);
        new In45WaybillIndexStatController().process(date1, date2);
        logger.error("process end");
    }
}
