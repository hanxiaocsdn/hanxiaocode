package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class SssMisclassificationOnlinePlatformModifyMonitor implements Serializable {
    @Column(name = "waybillno")
    private String waybillno;
    @Column(name = "delivered_emp_code")
    private String delivered_emp_code;
    @Column(name = "customeraccount")
    private String customeraccount;
    @Column(name = "req_address")
    private String req_address;
    @Column(name = "req_mobile")
    private String req_mobile;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "citycode")
    private String citycode;
    @Column(name = "req_city")
    private String req_city;
    @Column(name = "req_province")
    private String req_province;
    @Column(name = "req_region")
    private String req_region;
    @Column(name = "req_area")
    private String req_area;
    @Column(name = "adcode")
    private String adcode;
    @Column(name = "splitresult")
    private String splitresult;
    @Column(name = "gis_to_sys_zc")
    private String gis_to_sys_zc;
    @Column(name = "gis_to_sys_src")
    private String gis_to_sys_src;
    @Column(name = "gis_to_sys_by")
    private String gis_to_sys_by;
    @Column(name = "groupid")
    private String groupid;
    @Column(name = "arss_zc")
    private String arss_zc;
    @Column(name = "finalzc")
    private String finalzc;
    @Column(name = "depart_finalzc")
    private String depart_finalzc;
    @Column(name = "finalsrc")
    private String finalsrc;
    @Column(name = "finalretby")
    private String finalretby;
    @Column(name = "delivered_zc")
    private String delivered_zc;
    @Column(name = "depart_delivered_zc")
    private String depart_delivered_zc;
    @Column(name = "task_tag")
    private String task_tag;
    @Column(name = "data_time")
    private String data_time;
    @Column(name = "delivery_xy_zc")
    private String delivery_xy_zc;
    @Column(name = "depart_delivery_xy_zc")
    private String depart_delivery_xy_zc;

    @Column(name = "before_new_src")
    private String before_new_src;
    @Column(name = "before_new_dept")
    private String before_new_dept;
    @Column(name = "before_new_groupid")
    private String before_new_groupid;
    @Column(name = "before_depart_new_dept")
    private String before_depart_new_dept;
    @Column(name = "before_is_modify")
    private String before_is_modify;
    @Column(name = "send_time")
    private String send_time;
    @Column(name = "source")
    private String source;

    @Column(name = "done_time")
    private String done_time;
    @Column(name = "is_done")
    private String is_done;
    @Column(name = "receive_time")
    private String receive_time;
    @Column(name = "is_receive")
    private String is_receive;
    @Column(name = "invald_time")
    private String invald_time;

    @Column(name = "run_time")
    private String run_time;
    @Column(name = "new_test_groupid")
    private String new_test_groupid;
    @Column(name = "new_test_dept")
    private String new_test_dept;
    @Column(name = "depart_new_test_dept")
    private String depart_new_test_dept;

    @Column(name = "new_zh_src")
    private String new_zh_src;
    @Column(name = "new_zh_dept")
    private String new_zh_dept;
    @Column(name = "depart_new_zh_dept")
    private String depart_new_zh_dept;
    @Column(name = "new_src")
    private String new_src;
    @Column(name = "depart_new_dept")
    private String depart_new_dept;

    @Column(name = "is_modify")
    private String is_modify;
    @Column(name = "modify_type")
    private String modify_type;
    @Column(name = "chang_valid")
    private String chang_valid;
    @Column(name = "delivery_fit")
    private String delivery_fit;
    @Column(name = "new_opt_src")
    private String new_opt_src;
    @Column(name = "new_opt_dept")
    private String new_opt_dept;
    @Column(name = "depart_new_opt_dept")
    private String depart_new_opt_dept;
    @Column(name = "id")
    private String id;
    @Column(name = "depart_gis_dept")
    private String depart_gis_dept;

    @Column(name = "flag")
    private String flag;
    @Column(name = "standard")
    private String standard;
    @Column(name = "sflag")
    private String sflag;
    @Column(name = "match_x")
    private String match_x;
    @Column(name = "match_y")
    private String match_y;
    @Column(name = "gl_level")
    private String gl_level;
    @Column(name = "score")
    private String score;
    @Column(name = "match_info")
    private String match_info;
    @Column(name = "gis_aoicode")
    private String gis_aoicode;
    @Column(name = "gis_aoiid")
    private String gis_aoiid;
    @Column(name = "gis_keyword")
    private String gis_keyword;
    @Column(name = "gis_splitresult")
    private String gis_splitresult;
    @Column(name = "gis_aoi_unit")
    private String gis_aoiUnit;
    @Column(name = "req_city_orig")
    private String req_city_orig;
    @Column(name = "req_time")
    private String req_time;
    @Column(name = "rerun_source")
    private String rerun_source;
    @Column(name = "geo_resp")
    private String geo_resp;
    @Column(name = "queryredis_resp")
    private String queryredis_resp;
    @Column(name = "atp_resp")
    private String atp_resp;
    @Column(name = "inc_day")
    private String inc_day;

    public String getGeo_resp() {
        return geo_resp;
    }

    public void setGeo_resp(String geo_resp) {
        this.geo_resp = geo_resp;
    }

    public String getQueryredis_resp() {
        return queryredis_resp;
    }

    public void setQueryredis_resp(String queryredis_resp) {
        this.queryredis_resp = queryredis_resp;
    }

    public String getAtp_resp() {
        return atp_resp;
    }

    public void setAtp_resp(String atp_resp) {
        this.atp_resp = atp_resp;
    }

    public String getRerun_source() {
        return rerun_source;
    }

    public void setRerun_source(String rerun_source) {
        this.rerun_source = rerun_source;
    }

    public String getReq_city_orig() {
        return req_city_orig;
    }

    public void setReq_city_orig(String req_city_orig) {
        this.req_city_orig = req_city_orig;
    }

    public String getReq_time() {
        return req_time;
    }

    public void setReq_time(String req_time) {
        this.req_time = req_time;
    }

    public String getGis_aoiUnit() {
        return gis_aoiUnit;
    }

    public void setGis_aoiUnit(String gis_aoiUnit) {
        this.gis_aoiUnit = gis_aoiUnit;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getSflag() {
        return sflag;
    }

    public void setSflag(String sflag) {
        this.sflag = sflag;
    }

    public String getMatch_x() {
        return match_x;
    }

    public void setMatch_x(String match_x) {
        this.match_x = match_x;
    }

    public String getMatch_y() {
        return match_y;
    }

    public void setMatch_y(String match_y) {
        this.match_y = match_y;
    }

    public String getGl_level() {
        return gl_level;
    }

    public void setGl_level(String gl_level) {
        this.gl_level = gl_level;
    }

    public String getMatch_info() {
        return match_info;
    }

    public void setMatch_info(String match_info) {
        this.match_info = match_info;
    }

    public String getGis_aoicode() {
        return gis_aoicode;
    }

    public void setGis_aoicode(String gis_aoicode) {
        this.gis_aoicode = gis_aoicode;
    }

    public String getGis_aoiid() {
        return gis_aoiid;
    }

    public void setGis_aoiid(String gis_aoiid) {
        this.gis_aoiid = gis_aoiid;
    }

    public String getGis_keyword() {
        return gis_keyword;
    }

    public void setGis_keyword(String gis_keyword) {
        this.gis_keyword = gis_keyword;
    }

    public String getGis_splitresult() {
        return gis_splitresult;
    }

    public void setGis_splitresult(String gis_splitresult) {
        this.gis_splitresult = gis_splitresult;
    }

    public String getDepart_gis_dept() {
        return depart_gis_dept;
    }

    public void setDepart_gis_dept(String depart_gis_dept) {
        this.depart_gis_dept = depart_gis_dept;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDepart_new_opt_dept() {
        return depart_new_opt_dept;
    }

    public void setDepart_new_opt_dept(String depart_new_opt_dept) {
        this.depart_new_opt_dept = depart_new_opt_dept;
    }

    public String getNew_opt_dept() {
        return new_opt_dept;
    }

    public void setNew_opt_dept(String new_opt_dept) {
        this.new_opt_dept = new_opt_dept;
    }

    public String getNew_opt_src() {
        return new_opt_src;
    }

    public void setNew_opt_src(String new_opt_src) {
        this.new_opt_src = new_opt_src;
    }

    public String getIs_modify() {
        return is_modify;
    }

    public void setIs_modify(String is_modify) {
        this.is_modify = is_modify;
    }

    public String getModify_type() {
        return modify_type;
    }

    public void setModify_type(String modify_type) {
        this.modify_type = modify_type;
    }

    public String getChang_valid() {
        return chang_valid;
    }

    public void setChang_valid(String chang_valid) {
        this.chang_valid = chang_valid;
    }

    public String getDelivery_fit() {
        return delivery_fit;
    }

    public void setDelivery_fit(String delivery_fit) {
        this.delivery_fit = delivery_fit;
    }

    public String getNew_src() {
        return new_src;
    }

    public void setNew_src(String new_src) {
        this.new_src = new_src;
    }

    public String getDepart_new_dept() {
        return depart_new_dept;
    }

    public void setDepart_new_dept(String depart_new_dept) {
        this.depart_new_dept = depart_new_dept;
    }

    public String getDepart_new_zh_dept() {
        return depart_new_zh_dept;
    }

    public void setDepart_new_zh_dept(String depart_new_zh_dept) {
        this.depart_new_zh_dept = depart_new_zh_dept;
    }

    public String getNew_zh_src() {
        return new_zh_src;
    }

    public void setNew_zh_src(String new_zh_src) {
        this.new_zh_src = new_zh_src;
    }

    public String getNew_zh_dept() {
        return new_zh_dept;
    }

    public void setNew_zh_dept(String new_zh_dept) {
        this.new_zh_dept = new_zh_dept;
    }

    public String getDepart_new_test_dept() {
        return depart_new_test_dept;
    }

    public void setDepart_new_test_dept(String depart_new_test_dept) {
        this.depart_new_test_dept = depart_new_test_dept;
    }

    public String getNew_test_dept() {
        return new_test_dept;
    }

    public void setNew_test_dept(String new_test_dept) {
        this.new_test_dept = new_test_dept;
    }

    public String getNew_test_groupid() {
        return new_test_groupid;
    }

    public void setNew_test_groupid(String new_test_groupid) {
        this.new_test_groupid = new_test_groupid;
    }

    public String getRun_time() {
        return run_time;
    }

    public void setRun_time(String run_time) {
        this.run_time = run_time;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getDone_time() {
        return done_time;
    }

    public void setDone_time(String done_time) {
        this.done_time = done_time;
    }

    public String getIs_done() {
        return is_done;
    }

    public void setIs_done(String is_done) {
        this.is_done = is_done;
    }

    public String getReceive_time() {
        return receive_time;
    }

    public void setReceive_time(String receive_time) {
        this.receive_time = receive_time;
    }

    public String getIs_receive() {
        return is_receive;
    }

    public void setIs_receive(String is_receive) {
        this.is_receive = is_receive;
    }

    public String getInvald_time() {
        return invald_time;
    }

    public void setInvald_time(String invald_time) {
        this.invald_time = invald_time;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSend_time() {
        return send_time;
    }

    public void setSend_time(String send_time) {
        this.send_time = send_time;
    }

    public String getBefore_is_modify() {
        return before_is_modify;
    }

    public void setBefore_is_modify(String before_is_modify) {
        this.before_is_modify = before_is_modify;
    }

    public String getBefore_depart_new_dept() {
        return before_depart_new_dept;
    }

    public void setBefore_depart_new_dept(String before_depart_new_dept) {
        this.before_depart_new_dept = before_depart_new_dept;
    }

    public String getBefore_new_src() {
        return before_new_src;
    }

    public void setBefore_new_src(String before_new_src) {
        this.before_new_src = before_new_src;
    }

    public String getBefore_new_dept() {
        return before_new_dept;
    }

    public void setBefore_new_dept(String before_new_dept) {
        this.before_new_dept = before_new_dept;
    }

    public String getBefore_new_groupid() {
        return before_new_groupid;
    }

    public void setBefore_new_groupid(String before_new_groupid) {
        this.before_new_groupid = before_new_groupid;
    }

    public String getWaybillno() {
        return waybillno;
    }

    public void setWaybillno(String waybillno) {
        this.waybillno = waybillno;
    }

    public String getDelivered_emp_code() {
        return delivered_emp_code;
    }

    public void setDelivered_emp_code(String delivered_emp_code) {
        this.delivered_emp_code = delivered_emp_code;
    }

    public String getCustomeraccount() {
        return customeraccount;
    }

    public void setCustomeraccount(String customeraccount) {
        this.customeraccount = customeraccount;
    }

    public String getReq_address() {
        return req_address;
    }

    public void setReq_address(String req_address) {
        this.req_address = req_address;
    }

    public String getReq_mobile() {
        return req_mobile;
    }

    public void setReq_mobile(String req_mobile) {
        this.req_mobile = req_mobile;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getCitycode() {
        return citycode;
    }

    public void setCitycode(String citycode) {
        this.citycode = citycode;
    }

    public String getReq_city() {
        return req_city;
    }

    public void setReq_city(String req_city) {
        this.req_city = req_city;
    }

    public String getReq_province() {
        return req_province;
    }

    public void setReq_province(String req_province) {
        this.req_province = req_province;
    }

    public String getReq_region() {
        return req_region;
    }

    public void setReq_region(String req_region) {
        this.req_region = req_region;
    }

    public String getReq_area() {
        return req_area;
    }

    public void setReq_area(String req_area) {
        this.req_area = req_area;
    }

    public String getAdcode() {
        return adcode;
    }

    public void setAdcode(String adcode) {
        this.adcode = adcode;
    }

    public String getSplitresult() {
        return splitresult;
    }

    public void setSplitresult(String splitresult) {
        this.splitresult = splitresult;
    }

    public String getGis_to_sys_zc() {
        return gis_to_sys_zc;
    }

    public void setGis_to_sys_zc(String gis_to_sys_zc) {
        this.gis_to_sys_zc = gis_to_sys_zc;
    }

    public String getGis_to_sys_src() {
        return gis_to_sys_src;
    }

    public void setGis_to_sys_src(String gis_to_sys_src) {
        this.gis_to_sys_src = gis_to_sys_src;
    }

    public String getGis_to_sys_by() {
        return gis_to_sys_by;
    }

    public void setGis_to_sys_by(String gis_to_sys_by) {
        this.gis_to_sys_by = gis_to_sys_by;
    }

    public String getGroupid() {
        return groupid;
    }

    public void setGroupid(String groupid) {
        this.groupid = groupid;
    }

    public String getArss_zc() {
        return arss_zc;
    }

    public void setArss_zc(String arss_zc) {
        this.arss_zc = arss_zc;
    }

    public String getFinalzc() {
        return finalzc;
    }

    public void setFinalzc(String finalzc) {
        this.finalzc = finalzc;
    }

    public String getDepart_finalzc() {
        return depart_finalzc;
    }

    public void setDepart_finalzc(String depart_finalzc) {
        this.depart_finalzc = depart_finalzc;
    }

    public String getFinalsrc() {
        return finalsrc;
    }

    public void setFinalsrc(String finalsrc) {
        this.finalsrc = finalsrc;
    }

    public String getFinalretby() {
        return finalretby;
    }

    public void setFinalretby(String finalretby) {
        this.finalretby = finalretby;
    }

    public String getDelivered_zc() {
        return delivered_zc;
    }

    public void setDelivered_zc(String delivered_zc) {
        this.delivered_zc = delivered_zc;
    }

    public String getDepart_delivered_zc() {
        return depart_delivered_zc;
    }

    public void setDepart_delivered_zc(String depart_delivered_zc) {
        this.depart_delivered_zc = depart_delivered_zc;
    }

    public String getTask_tag() {
        return task_tag;
    }

    public void setTask_tag(String task_tag) {
        this.task_tag = task_tag;
    }

    public String getData_time() {
        return data_time;
    }

    public void setData_time(String data_time) {
        this.data_time = data_time;
    }

    public String getDelivery_xy_zc() {
        return delivery_xy_zc;
    }

    public void setDelivery_xy_zc(String delivery_xy_zc) {
        this.delivery_xy_zc = delivery_xy_zc;
    }

    public String getDepart_delivery_xy_zc() {
        return depart_delivery_xy_zc;
    }

    public void setDepart_delivery_xy_zc(String depart_delivery_xy_zc) {
        this.depart_delivery_xy_zc = depart_delivery_xy_zc;
    }
}
