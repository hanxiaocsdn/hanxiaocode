package com.sf.gis.java.sds.pojo;


import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TalsGisRdsOmsto implements Serializable {
    @Column(name = "req_waybillno")
    private String req_waybillno;
    @Column(name = "req_destcitycode")
    private String req_destcitycode;
    @Column(name = "req_addresseeaddr")
    private String req_addresseeaddr;
    @Column(name = "req_comp_name")
    private String req_comp_name;
    @Column(name = "at_pai_body")
    private String at_pai_body;
    @Column(name = "ks_re_body")
    private String ks_re_body;
    @Column(name = "gis_to_sys_groupid")
    private String gis_to_sys_groupid;
    @Column(name = "groupids")
    private String groupids;
    @Column(name = "matchids")
    private String matchids;
    @Column(name = "filters")
    private String filters;
    @Column(name = "keywords")
    private String keywords;
    @Column(name = "gisaoicode")
    private String gisaoicode;
    @Column(name = "re_body_latest")
    private String re_body_latest;
    @Column(name = "inc_day")
    private String inc_day;

    @Column(name = "atdept")
    private String atdept;
    @Column(name = "atdept_src")
    private String atdept_src;
    @Column(name = "ataoi_src")
    private String ataoi_src;
    @Column(name = "deptcode")
    private String deptcode;
    @Column(name = "at_abnormsrc")
    private String at_abnormSrc;

    @Column(name = "ksdept_src")
    private String ksdept_src;
    @Column(name = "ksaoi_src")
    private String ksaoi_src;
    @Column(name = "dept_ks")
    private String dept_ks;
    @Column(name = "aoi_ks")
    private String aoi_ks;


    @Column(name = "groupids_chkn")
    private String groupids_chkn;
    @Column(name = "filters_chkn")
    private String filters_chkn;
    @Column(name = "dept_chkn")
    private String dept_chkn;
    @Column(name = "groupid_chkn")
    private String groupid_chkn;
    @Column(name = "aoi_chkn")
    private String aoi_chkn;
    @Column(name = "ys_dept_chkn")
    private String ys_dept_chkn;
    @Column(name = "ys_atdept")
    private String ys_atdept;
    @Column(name = "ys_deptcode")
    private String ys_deptcode;
    @Column(name = "region")
    private String region;
    @Column(name = "req_city")
    private String req_city;

    @Column(name = "area")
    private String area;
    @Column(name = "typecode")
    private String typecode;
    @Column(name = "dept_hp")
    private String dept_hp;
    @Column(name = "aoi_hp")
    private String aoi_hp;
    @Column(name = "dept_phone")
    private String dept_phone;
    @Column(name = "aoi_phone")
    private String aoi_phone;
    @Column(name = "resp")
    private String resp;

    public String getResp() {
        return resp;
    }

    public void setResp(String resp) {
        this.resp = resp;
    }

    public String getDept_ks() {
        return dept_ks;
    }

    public void setDept_ks(String dept_ks) {
        this.dept_ks = dept_ks;
    }

    public String getAoi_ks() {
        return aoi_ks;
    }

    public void setAoi_ks(String aoi_ks) {
        this.aoi_ks = aoi_ks;
    }

    public String getKsdept_src() {
        return ksdept_src;
    }

    public void setKsdept_src(String ksdept_src) {
        this.ksdept_src = ksdept_src;
    }

    public String getKsaoi_src() {
        return ksaoi_src;
    }

    public void setKsaoi_src(String ksaoi_src) {
        this.ksaoi_src = ksaoi_src;
    }

    public String getKs_re_body() {
        return ks_re_body;
    }

    public void setKs_re_body(String ks_re_body) {
        this.ks_re_body = ks_re_body;
    }

    public String getAt_abnormSrc() {
        return at_abnormSrc;
    }

    public void setAt_abnormSrc(String at_abnormSrc) {
        this.at_abnormSrc = at_abnormSrc;
    }

    public String getRe_body_latest() {
        return re_body_latest;
    }

    public void setRe_body_latest(String re_body_latest) {
        this.re_body_latest = re_body_latest;
    }

    public String getDept_hp() {
        return dept_hp;
    }

    public void setDept_hp(String dept_hp) {
        this.dept_hp = dept_hp;
    }

    public String getAoi_hp() {
        return aoi_hp;
    }

    public void setAoi_hp(String aoi_hp) {
        this.aoi_hp = aoi_hp;
    }

    public String getDept_phone() {
        return dept_phone;
    }

    public void setDept_phone(String dept_phone) {
        this.dept_phone = dept_phone;
    }

    public String getAoi_phone() {
        return aoi_phone;
    }

    public void setAoi_phone(String aoi_phone) {
        this.aoi_phone = aoi_phone;
    }

    public String getTypecode() {
        return typecode;
    }

    public void setTypecode(String typecode) {
        this.typecode = typecode;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getAtaoi_src() {
        return ataoi_src;
    }

    public void setAtaoi_src(String ataoi_src) {
        this.ataoi_src = ataoi_src;
    }

    public String getAoi_chkn() {
        return aoi_chkn;
    }

    public void setAoi_chkn(String aoi_chkn) {
        this.aoi_chkn = aoi_chkn;
    }

    public String getGisaoicode() {
        return gisaoicode;
    }

    public void setGisaoicode(String gisaoicode) {
        this.gisaoicode = gisaoicode;
    }

    public String getReq_city() {
        return req_city;
    }

    public void setReq_city(String req_city) {
        this.req_city = req_city;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getGis_to_sys_groupid() {
        return gis_to_sys_groupid;
    }

    public void setGis_to_sys_groupid(String gis_to_sys_groupid) {
        this.gis_to_sys_groupid = gis_to_sys_groupid;
    }

    public String getYs_dept_chkn() {
        return ys_dept_chkn;
    }

    public void setYs_dept_chkn(String ys_dept_chkn) {
        this.ys_dept_chkn = ys_dept_chkn;
    }

    public String getYs_atdept() {
        return ys_atdept;
    }

    public void setYs_atdept(String ys_atdept) {
        this.ys_atdept = ys_atdept;
    }

    public String getYs_deptcode() {
        return ys_deptcode;
    }

    public void setYs_deptcode(String ys_deptcode) {
        this.ys_deptcode = ys_deptcode;
    }

    public String getGroupids_chkn() {
        return groupids_chkn;
    }

    public void setGroupids_chkn(String groupids_chkn) {
        this.groupids_chkn = groupids_chkn;
    }

    public String getFilters_chkn() {
        return filters_chkn;
    }

    public void setFilters_chkn(String filters_chkn) {
        this.filters_chkn = filters_chkn;
    }

    public String getDept_chkn() {
        return dept_chkn;
    }

    public void setDept_chkn(String dept_chkn) {
        this.dept_chkn = dept_chkn;
    }

    public String getGroupid_chkn() {
        return groupid_chkn;
    }

    public void setGroupid_chkn(String groupid_chkn) {
        this.groupid_chkn = groupid_chkn;
    }

    public String getReq_comp_name() {
        return req_comp_name;
    }

    public void setReq_comp_name(String req_comp_name) {
        this.req_comp_name = req_comp_name;
    }

    public String getReq_addresseeaddr() {
        return req_addresseeaddr;
    }

    public void setReq_addresseeaddr(String req_addresseeaddr) {
        this.req_addresseeaddr = req_addresseeaddr;
    }

    public String getDeptcode() {
        return deptcode;
    }

    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }

    public String getReq_waybillno() {
        return req_waybillno;
    }

    public void setReq_waybillno(String req_waybillno) {
        this.req_waybillno = req_waybillno;
    }

    public String getReq_destcitycode() {
        return req_destcitycode;
    }

    public void setReq_destcitycode(String req_destcitycode) {
        this.req_destcitycode = req_destcitycode;
    }

    public String getAt_pai_body() {
        return at_pai_body;
    }

    public void setAt_pai_body(String at_pai_body) {
        this.at_pai_body = at_pai_body;
    }

    public String getGroupids() {
        return groupids;
    }

    public void setGroupids(String groupids) {
        this.groupids = groupids;
    }

    public String getMatchids() {
        return matchids;
    }

    public void setMatchids(String matchids) {
        this.matchids = matchids;
    }

    public String getFilters() {
        return filters;
    }

    public void setFilters(String filters) {
        this.filters = filters;
    }

    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getAtdept() {
        return atdept;
    }

    public void setAtdept(String atdept) {
        this.atdept = atdept;
    }

    public String getAtdept_src() {
        return atdept_src;
    }

    public void setAtdept_src(String atdept_src) {
        this.atdept_src = atdept_src;
    }
}
