package com.sf.gis.java.sds.pojo;

import java.io.Serializable;

public class StatNormTtPai implements Serializable {
    private String id;
    private long tt_num;
    private long chkn_num;
    private long other_num;
    private long log_norm_num;
    private long chkn_norm_num;
    private long log_muti_group_num;
    private long chkn_muti_group_num;
    private long log_zc_num;
    private long log_zc_num_new;
    private long chkn_zc_num;
    private long log_zc_correct_num;
    private long log_zc_correct_num_new;
    private long chkn_zc_correct_num;
    private long log_aoi_num;
    private long chkn_aoi_num;
    private long other_num_aoi;
    private long chkn_num_aoi;
    private long hp_zc_num;
    private long hp_aoi_num;
    private long phone_zc_num;
    private long phone_aoi_num;

    private long ks_zc_num;
    private long ks_aoi_num;

    private String region;
    private String cityCode;
    private String inc_day;
    private String stat_type;
    private String stat_type_content;
    private String stat_date;
    private String city;
    private String area;

    public long getKs_zc_num() {
        return ks_zc_num;
    }

    public void setKs_zc_num(long ks_zc_num) {
        this.ks_zc_num = ks_zc_num;
    }

    public long getKs_aoi_num() {
        return ks_aoi_num;
    }

    public void setKs_aoi_num(long ks_aoi_num) {
        this.ks_aoi_num = ks_aoi_num;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getTt_num() {
        return tt_num;
    }

    public void setTt_num(long tt_num) {
        this.tt_num = tt_num;
    }

    public long getChkn_num() {
        return chkn_num;
    }

    public void setChkn_num(long chkn_num) {
        this.chkn_num = chkn_num;
    }

    public long getOther_num() {
        return other_num;
    }

    public void setOther_num(long other_num) {
        this.other_num = other_num;
    }

    public long getLog_norm_num() {
        return log_norm_num;
    }

    public void setLog_norm_num(long log_norm_num) {
        this.log_norm_num = log_norm_num;
    }

    public long getChkn_norm_num() {
        return chkn_norm_num;
    }

    public void setChkn_norm_num(long chkn_norm_num) {
        this.chkn_norm_num = chkn_norm_num;
    }

    public long getLog_muti_group_num() {
        return log_muti_group_num;
    }

    public void setLog_muti_group_num(long log_muti_group_num) {
        this.log_muti_group_num = log_muti_group_num;
    }

    public long getChkn_muti_group_num() {
        return chkn_muti_group_num;
    }

    public void setChkn_muti_group_num(long chkn_muti_group_num) {
        this.chkn_muti_group_num = chkn_muti_group_num;
    }

    public long getLog_zc_num() {
        return log_zc_num;
    }

    public void setLog_zc_num(long log_zc_num) {
        this.log_zc_num = log_zc_num;
    }

    public long getLog_zc_num_new() {
        return log_zc_num_new;
    }

    public void setLog_zc_num_new(long log_zc_num_new) {
        this.log_zc_num_new = log_zc_num_new;
    }

    public long getChkn_zc_num() {
        return chkn_zc_num;
    }

    public void setChkn_zc_num(long chkn_zc_num) {
        this.chkn_zc_num = chkn_zc_num;
    }

    public long getLog_zc_correct_num() {
        return log_zc_correct_num;
    }

    public void setLog_zc_correct_num(long log_zc_correct_num) {
        this.log_zc_correct_num = log_zc_correct_num;
    }

    public long getLog_zc_correct_num_new() {
        return log_zc_correct_num_new;
    }

    public void setLog_zc_correct_num_new(long log_zc_correct_num_new) {
        this.log_zc_correct_num_new = log_zc_correct_num_new;
    }

    public long getChkn_zc_correct_num() {
        return chkn_zc_correct_num;
    }

    public void setChkn_zc_correct_num(long chkn_zc_correct_num) {
        this.chkn_zc_correct_num = chkn_zc_correct_num;
    }

    public long getLog_aoi_num() {
        return log_aoi_num;
    }

    public void setLog_aoi_num(long log_aoi_num) {
        this.log_aoi_num = log_aoi_num;
    }

    public long getChkn_aoi_num() {
        return chkn_aoi_num;
    }

    public void setChkn_aoi_num(long chkn_aoi_num) {
        this.chkn_aoi_num = chkn_aoi_num;
    }

    public long getOther_num_aoi() {
        return other_num_aoi;
    }

    public void setOther_num_aoi(long other_num_aoi) {
        this.other_num_aoi = other_num_aoi;
    }

    public long getChkn_num_aoi() {
        return chkn_num_aoi;
    }

    public void setChkn_num_aoi(long chkn_num_aoi) {
        this.chkn_num_aoi = chkn_num_aoi;
    }

    public long getHp_zc_num() {
        return hp_zc_num;
    }

    public void setHp_zc_num(long hp_zc_num) {
        this.hp_zc_num = hp_zc_num;
    }

    public long getHp_aoi_num() {
        return hp_aoi_num;
    }

    public void setHp_aoi_num(long hp_aoi_num) {
        this.hp_aoi_num = hp_aoi_num;
    }

    public long getPhone_zc_num() {
        return phone_zc_num;
    }

    public void setPhone_zc_num(long phone_zc_num) {
        this.phone_zc_num = phone_zc_num;
    }

    public long getPhone_aoi_num() {
        return phone_aoi_num;
    }

    public void setPhone_aoi_num(long phone_aoi_num) {
        this.phone_aoi_num = phone_aoi_num;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }

    public String getStat_type() {
        return stat_type;
    }

    public void setStat_type(String stat_type) {
        this.stat_type = stat_type;
    }

    public String getStat_type_content() {
        return stat_type_content;
    }

    public void setStat_type_content(String stat_type_content) {
        this.stat_type_content = stat_type_content;
    }

    public String getStat_date() {
        return stat_date;
    }

    public void setStat_date(String stat_date) {
        this.stat_date = stat_date;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
