package com.sf.gis.java.sds.pojo.aoicompletion;

import com.alibaba.fastjson.JSONArray;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class TtAppointAdditionKafka implements Serializable {
    @Column(name = "txid")
    private String txid;
    @Column(name = "express_info_list")
    private String express_info_list;

    private String longitude;
    private String latitude;

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getTxid() {
        return txid;
    }

    public void setTxid(String txid) {
        this.txid = txid;
    }

    public String getExpress_info_list() {
        return express_info_list;
    }

    public void setExpress_info_list(String express_info_list) {
        this.express_info_list = express_info_list;
    }
}
