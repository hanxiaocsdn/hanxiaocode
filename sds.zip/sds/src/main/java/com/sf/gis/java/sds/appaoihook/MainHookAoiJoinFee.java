package com.sf.gis.java.sds.appaoihook;

import com.sf.gis.java.sds.controller.HookAoiJoinFeeController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MainHookAoiJoinFee {
    private static final Logger logger = LoggerFactory.getLogger(MainHookAoiJoinFee.class);

    public static void main(String[] args) throws Exception {
        logger.error("start");
        String arg = null;
        if(args.length>=1){
            arg = args[0];
        }
        HookAoiJoinFeeController tmpController = new HookAoiJoinFeeController(null);
        tmpController.start(arg);
    }

}
