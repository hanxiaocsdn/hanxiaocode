package com.sf.gis.java.sds.pojo;

import javax.persistence.Column;
import javax.persistence.Table;
import java.io.Serializable;

@Table
public class BuildingIdentifyStat implements Serializable {
    @Column(name = "stat_date")
    private String stat_date;
    @Column(name = "area")
    private String area;
    @Column(name = "region")
    private String region;
    @Column(name = "city")
    private String city;
    @Column(name = "city_code")
    private String city_code;
    @Column(name = "spj_type")
    private String spj_type;
    @Column(name = "fei_call")
    private String fei_call;
    @Column(name = "is_complete")
    private String is_complete;

    @Column(name = "aoi_num")
    private String aoi_num;
    @Column(name = "waybillno_num")
    private String waybillno_num;
    @Column(name = "res_num")
    private String res_num;
    @Column(name = "lvl14_num")
    private String lvl14_num;
    @Column(name = "lvl14_res_num")
    private String lvl14_res_num;
    @Column(name = "no_lvl14_num")
    private String no_lvl14_num;
    @Column(name = "no_lvl14_res_num")
    private String no_lvl14_res_num;
    @Column(name = "lvl14_allkeywordmatch_num")
    private String lvl14_allkeywordmatch_num;
    @Column(name = "lvl14_somekeywordmatch_num")
    private String lvl14_somekeywordmatch_num;
    @Column(name = "lvl14_pmatch_num")
    private String lvl14_pmatch_num;
    @Column(name = "lvl15_allkeywordmatch_num")
    private String lvl15_allkeywordmatch_num;
    @Column(name = "lvl15_somekeywordmatch_num")
    private String lvl15_somekeywordmatch_num;
    @Column(name = "lvl15_pmatch_num")
    private String lvl15_pmatch_num;
    @Column(name = "lvl13_pmatch_num")
    private String lvl13_pmatch_num;
    @Column(name = "lvl13_escape_match_num")
    private String lvl13_escape_match_num;
    @Column(name = "lvl13_pinyin_pmatch_num")
    private String lvl13_pinyin_pmatch_num;
    @Column(name = "lvl13_pinyin_pmatch2_num")
    private String lvl13_pinyin_pmatch2_num;
    @Column(name = "singlebd_num")
    private String singlebd_num;
    @Column(name = "zno_code")
    private String zno_code;
    @Column(name = "aoi_id")
    private String aoi_id;
    @Column(name = "aoi_src")
    private String aoi_src;
    @Column(name = "inc_day")
    private String inc_day;


    public String getZno_code() {return zno_code;}

    public String getAoi_src() {
        return aoi_src;
    }

    public void setAoi_src(String aoi_src) {
        this.aoi_src = aoi_src;
    }

    public void setZno_code(String zno_code) {this.zno_code = zno_code;}

    public String getAoi_id() {return aoi_id;}

    public void setAoi_id(String aoi_id) {this.aoi_id = aoi_id;}

    public String getStat_date() {
        return stat_date;
    }

    public void setStat_date(String stat_date) {
        this.stat_date = stat_date;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity_code() {
        return city_code;
    }

    public void setCity_code(String city_code) {
        this.city_code = city_code;
    }

    public String getSpj_type() {
        return spj_type;
    }

    public void setSpj_type(String spj_type) {
        this.spj_type = spj_type;
    }

    public String getFei_call() {
        return fei_call;
    }

    public void setFei_call(String fei_call) {
        this.fei_call = fei_call;
    }

    public String getIs_complete() {
        return is_complete;
    }

    public void setIs_complete(String is_complete) {
        this.is_complete = is_complete;
    }

    public String getAoi_num() {
        return aoi_num;
    }

    public void setAoi_num(String aoi_num) {
        this.aoi_num = aoi_num;
    }

    public String getWaybillno_num() {
        return waybillno_num;
    }

    public void setWaybillno_num(String waybillno_num) {
        this.waybillno_num = waybillno_num;
    }

    public String getRes_num() {
        return res_num;
    }

    public void setRes_num(String res_num) {
        this.res_num = res_num;
    }

    public String getLvl14_num() {
        return lvl14_num;
    }

    public void setLvl14_num(String lvl14_num) {
        this.lvl14_num = lvl14_num;
    }

    public String getLvl14_res_num() {
        return lvl14_res_num;
    }

    public void setLvl14_res_num(String lvl14_res_num) {
        this.lvl14_res_num = lvl14_res_num;
    }

    public String getNo_lvl14_num() {
        return no_lvl14_num;
    }

    public void setNo_lvl14_num(String no_lvl14_num) {
        this.no_lvl14_num = no_lvl14_num;
    }

    public String getNo_lvl14_res_num() {
        return no_lvl14_res_num;
    }

    public void setNo_lvl14_res_num(String no_lvl14_res_num) {
        this.no_lvl14_res_num = no_lvl14_res_num;
    }

    public String getLvl14_allkeywordmatch_num() {
        return lvl14_allkeywordmatch_num;
    }

    public void setLvl14_allkeywordmatch_num(String lvl14_allkeywordmatch_num) {
        this.lvl14_allkeywordmatch_num = lvl14_allkeywordmatch_num;
    }

    public String getLvl14_somekeywordmatch_num() {
        return lvl14_somekeywordmatch_num;
    }

    public void setLvl14_somekeywordmatch_num(String lvl14_somekeywordmatch_num) {
        this.lvl14_somekeywordmatch_num = lvl14_somekeywordmatch_num;
    }

    public String getLvl14_pmatch_num() {
        return lvl14_pmatch_num;
    }

    public void setLvl14_pmatch_num(String lvl14_pmatch_num) {
        this.lvl14_pmatch_num = lvl14_pmatch_num;
    }

    public String getLvl15_allkeywordmatch_num() {
        return lvl15_allkeywordmatch_num;
    }

    public void setLvl15_allkeywordmatch_num(String lvl15_allkeywordmatch_num) {
        this.lvl15_allkeywordmatch_num = lvl15_allkeywordmatch_num;
    }

    public String getLvl15_somekeywordmatch_num() {
        return lvl15_somekeywordmatch_num;
    }

    public void setLvl15_somekeywordmatch_num(String lvl15_somekeywordmatch_num) {
        this.lvl15_somekeywordmatch_num = lvl15_somekeywordmatch_num;
    }

    public String getLvl15_pmatch_num() {
        return lvl15_pmatch_num;
    }

    public void setLvl15_pmatch_num(String lvl15_pmatch_num) {
        this.lvl15_pmatch_num = lvl15_pmatch_num;
    }

    public String getLvl13_pmatch_num() {
        return lvl13_pmatch_num;
    }

    public void setLvl13_pmatch_num(String lvl13_pmatch_num) {
        this.lvl13_pmatch_num = lvl13_pmatch_num;
    }

    public String getLvl13_escape_match_num() {
        return lvl13_escape_match_num;
    }

    public void setLvl13_escape_match_num(String lvl13_escape_match_num) {
        this.lvl13_escape_match_num = lvl13_escape_match_num;
    }

    public String getLvl13_pinyin_pmatch_num() {
        return lvl13_pinyin_pmatch_num;
    }

    public void setLvl13_pinyin_pmatch_num(String lvl13_pinyin_pmatch_num) {
        this.lvl13_pinyin_pmatch_num = lvl13_pinyin_pmatch_num;
    }

    public String getLvl13_pinyin_pmatch2_num() {
        return lvl13_pinyin_pmatch2_num;
    }

    public void setLvl13_pinyin_pmatch2_num(String lvl13_pinyin_pmatch2_num) {
        this.lvl13_pinyin_pmatch2_num = lvl13_pinyin_pmatch2_num;
    }

    public String getSinglebd_num() {
        return singlebd_num;
    }

    public void setSinglebd_num(String singlebd_num) {
        this.singlebd_num = singlebd_num;
    }

    public String getInc_day() {
        return inc_day;
    }

    public void setInc_day(String inc_day) {
        this.inc_day = inc_day;
    }
}
