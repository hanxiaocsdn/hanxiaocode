package com.sf.gis.java.sds.app;

import com.sf.gis.java.base.util.ConfigUtil;
import com.sf.gis.java.sds.controller.StdMarkingController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 地址库标记流程
 * @author 01370539 Created On: Jun.18 2021
 */
public class StdMarkingApp {
    private static final Logger logger = LoggerFactory.getLogger(StdMarkingApp.class);

    public static void main(String[] args) {
        String[] citys = new String[0];
        if (args != null && args.length >= 1) {
            citys = args[0].split(",");
        }

        if (citys.length == 0) {
            logger.error("param not match, citys - {}", citys);
            System.exit(0);
        }
        new StdMarkingController().process(citys);
    }
}
